# Evidence-query contract — revisions 0505–0507

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Recipient views in revision 0526

Explicitly imported subscription sources are queried using their authenticated provider issuer and separately authorized target scope. Rows include distinct subscribed_source provenance and original payload length; no local_authorship is invented. Metadata/payload permission remains current and exact. See [recipient view contract](SUBSCRIBED-SOURCE-VIEWS.md).

## V10 scoped successor

Revision 0506 adds exact UID/issuer/scope METADATA/PAYLOAD delegation, response V2, policy-bound NEC2 cursors, authorized-selection ordinals and a derivative domain index. [Scoped reads](SCOPED-READS.md) is the authoritative V10 contract. The CLI/NEQ1 input remains unchanged. The following V9 compatibility description remains exact; its node-wide grants and response V1 do **not** describe V10.

## V9 scope and authority

`evidence-query` reads only evidence already admitted by this recipient. Pending outbound records, rejected peer submissions, and action execution ledgers are not query rows. Evidence that requested an action remains an evidence record, however. The API is local Unix control, not a new remotely callable peer operation.

Use configuration V9 to grant reads explicitly:

```text
NATRAV_OVERLAY_CONFIG_V9
runtime_generation=node-a-reads-1
# ...the usual complete node configuration...
local_control=1000,INSPECT,SUBMIT,ACTION,MAINTENANCE,CONFIGURATION,SHUTDOWN,EVIDENCE_READ,EVIDENCE_PAYLOAD
local_control=1001,EVIDENCE_READ
local_control=1002,EVIDENCE_READ,EVIDENCE_PAYLOAD
```

These are excerpts, not standalone configurations. EVIDENCE_READ allows metadata for all locally admitted evidence. EVIDENCE_PAYLOAD additionally permits payload slices and requires EVIDENCE_READ. Neither requires INSPECT. These grants are deliberately **node-wide** in V9 compatibility mode. Issuer/scope query filters are NOT access-control rules.

ALL remains exactly INSPECT, SUBMIT, ACTION, MAINTENANCE, CONFIGURATION, and SHUTDOWN forever. It cannot be combined with another class in one grant. To grant administrative and read authority to one UID, spell out the eight classes as above. Old ALL, INSPECT, and V6/V7 owner defaults gain no new access. V8 rejects the new classes; V9 must be explicitly activated or bootstrapped. Canonical prior V8 policy bytes and digests remain unchanged.

The application obtains SO_PEERCRED before reading a frame, rejects an unlisted UID, decodes a bounded request, then rechecks the current accepted read policy under a configuration lease. Both metadata and requested payload permission are checked. That lease remains held through the state selection and response encoding. It is released before socket writes: already authorized bounded bytes can finish transmitting after a policy publication, but subsequent queries must use the new policy. Filesystem access to the owner-created socket is a separate deployment prerequisite.

Successful queries are observational and do not append journal records. Decoding and authorization denials use the existing local-control journal audit. An authorized query's execution errors (for example a stale cursor or invalid payload range) return typed failures and increment control-error counters; there is no separate complete payload-access receipt log yet.

## Command

```text
evidence-query --control PATH
  [--view current|history]
  [--issuer ID] [--scope S] [--operation HEX64]
  [--limit 1..128] [--max-bytes 4096..60000]
  [--payload yes|no] [--payload-offset 0..60000]
  [--payload-length 1..16384] [--cursor TOKEN]
  [--deadline-ms N] [--read-quantum N] [--write-quantum N] [--receive-limit N]
```

Defaults are current, any issuer/scope/operation, 32 records, 60,000 JSON bytes, and no payload. Payload mode defaults to a 4,096-byte slice per returned record. Without payload mode, offset and length must be zero. A nonzero offset requires an exact operation selector. Offset may equal the payload size (empty terminal slice), but may not exceed it.

All filters are conjunctive and exact. Omitted issuer/scope/operation means no restriction on that field. There are no prefixes, SQL, regular expressions, joins, filesystem paths, sorting expressions, or arbitrary execution.

`current` means every unsuperseded correction-chain head. Independent observations in one scope all remain current; no newest-timestamp or truth winner is selected. `history` includes original and corrected records in increasing recipient admission sequence. An exact operation selector never silently follows its correction: a superseded original returns no current row but remains retrievable in history.

## Response and payload slices

The response format is NATRAV_OVERLAY_EVIDENCE_QUERY_V1. It reports the exact filters/view, selection and query digests, accepted configuration generation/digest, selected count, returned count, rows, and next_cursor. The existing control annotation adds kernel UID/GID/PID, command class, and request ID.

Each row includes recipient admission sequence, operation ID, issuer, recipient, scope, immutable record digest, payload size, direct corrects/superseded_by links, and the stored admission authorization account (peer node/generation, policy/rule digests, recipient decision time). Authorization is null for legacy unaccounted admissions; they are not relabeled as authenticated admissions.

Without payload mode no payload_hex field is returned. Payload mode adds payload_offset, payload_returned_bytes, payload_more, and exact lowercase hexadecimal bytes. Binary NULs and non-UTF-8 data are supported. Retrieve a large record with repeated exact-operation queries and increasing offsets. Because the record is immutable, a correction cannot replace its payload in place.

`--max-bytes` governs the complete UTF-8 JSON body INCLUDING principal annotation, but excludes the four-byte outer frame length and five-byte NOR1 response header. The serializer reserves envelope/annotation space before page building and checks the actual complete response. It limits row count and checks prospective byte use BEFORE hexadecimal expansion. It never emits a partial row.

If the next row does not fit after some returned rows, the page ends with a continuation cursor. If no row can fit, EVIDENCE_QUERY_PAGE_TOO_SMALL is returned: increase max-bytes or reduce payload-length and start a fresh query. The record is not skipped. The conservative envelope reserve means not every nominal byte of the requested budget is filled.

## Stable selection and cursors

The selection digest is a deterministic SHA-256 chain over the node/view/exact filters and the selected canonical metadata rows. Rows bind the immutable record digest, which includes payload content, as well as correction and authorization metadata. The root is independent of page shaping, payload inclusion, process counters, local audit entries, outbox retries, physical journal layout, and owner-path relocation. It is a consistency digest, not a signature, proof of truth, or freshness anchor.

Revision 0507 replaces whole-selection temporary scans with ordered indexes and a bounded 32-entry root cache. Cold hashes use batches of at most 128 metadata rows and release the state mutex between nonfinal batches; relevant concurrent changes fail explicitly without partial results. There is no 65,536-record ceiling. Warm pages reuse exact roots and seek instead of rehashing the selection. V9 filters can still skip unrelated node-wide records. Complete configured deadlines and page/payload bounds remain. See [Indexed pagination](INDEXED-PAGINATION.md).

A continuation cursor is 304 lowercase hexadecimal characters encoding 152 bytes. Its body contains NEC1, UID, complete query digest, selected root, accepted configuration digest, last returned admission sequence, and absolute monotonic expiry; a 32-byte HMAC-SHA-256 tag follows. The MAC domain is NATRAV_OVERLAY_EVIDENCE_CURSOR_V1. A separate 32-byte RAND_priv_bytes secret is initialized once per process and never stored in the journal, configuration, or backups. MAC return values are checked and tags are compared with CRYPTO_memcmp.

The cursor binds ALL query options, including page count/bytes and payload shaping. Repeat them on continuation. A cursor is not a grant: current permissions are rechecked every time. It can be replayed read-only by the same UID while its context remains valid. A different CLI PID is allowed; a different UID is not.

Cursors expire five minutes after the first page's cursor issuance; later pages keep the original deadline. No historical view is retained. Selected evidence changes return EVIDENCE_CURSOR_STALE. Unrelated evidence outside the exact selection and representation-only compaction do not invalidate a cursor in the same process. Any accepted configuration digest change returns EVIDENCE_CURSOR_CONTEXT_MISMATCH, even when the change would not otherwise affect the filter. Forged/malformed tokens and tokens from a restarted process return EVIDENCE_CURSOR_INVALID. Expired authenticated tokens return EVIDENCE_CURSOR_EXPIRED. A new process or restored node starts a new query; its reconstructed selection digest can still equal the previous one.

Tokens are authenticated, not encrypted, and should be treated as opaque context-bearing data. Continuous writes can repeatedly stale a broad query; the API does not claim starvation-free snapshot pagination or silently retry until it gets one.

## Wire encoding

One NOC1 control request uses kind 15. Its remaining payload is:

```text
NEQ1                         4 bytes
history, include_payload     two u8 booleans, exactly 0 or 1
issuer, scope                each: u16 big-endian byte length + ASCII bytes
has_operation                u8, exactly 0 or 1
operation_id                 32 bytes only when has_operation == 1
maximum_records              u32 big-endian
maximum_response_bytes       u32 big-endian
payload_offset               u32 big-endian
payload_length               u32 big-endian
cursor                       u16 big-endian byte length + ASCII bytes
```

Strict decoding rejects unknown versions/modes, over-limit strings/numbers, zero operation IDs, illegal payload combinations, incomplete bodies, and trailing bytes in the request. Errors use the existing NOR1 wrapper. TCP/TLS/HELLO/NOS1 peer messages are unchanged.

## Evidence and limitations

The retained six-case V9 suite exercises V8→V9 live adoption and restart, raw independent wire encoding, two actual authenticated issuers, plural current heads and immutable history, all 60,000 binary bytes in bounded slices, exact limits, absent payload fields, successful-read nonmutation, real different-UID metadata/payload enforcement, slow-connection live revocation, independently reproduced selection/query digests, cursor tamper/context/stale/restart handling, concurrent writers/readers, byte-bound pagination, compaction, state-authentication migration, signed encrypted restore, relocation, and resumed delivery. A separate opt-in test waits the actual five-minute monotonic lifetime; it is not hidden inside the normal 180-second-per-suite wrapper.

See [Testing](TESTING.md) and [current validation](../validation/VALIDATION.json) for completed measurements and the detected MAC-verification negative control. No external cryptographic audit, evidence-truth guarantee, full-text search, retained snapshots, remote query protocol, or durable successful-read log is claimed.

OpenSSL primitive references, checked October 4, 2026: [HMAC EVP_MAC](https://docs.openssl.org/3.0/man7/EVP_MAC-HMAC/), [RAND_bytes/RAND_priv_bytes](https://docs.openssl.org/3.0/man3/RAND_bytes/), [CRYPTO_memcmp](https://docs.openssl.org/3.0/man3/CRYPTO_memcmp/). The measured library/compiler versions are in the current environment record; these references specify primitive API behavior, not an audit of this application protocol.

## Incremental consumption

For original/correction admissions added after a continuation boundary, revision 0508 provides [evidence-feed](EVIDENCE-FEED.md). It uses exact V10 read domains and the same derived history indexes but deliberately does not construct a changing selection root. This does not change existing query or pagination semantics.
