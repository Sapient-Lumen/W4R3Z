# Command-scoped source preparation — revision 0557 contract, current at 0560

## Contract and lifetime

Ordinary manual and automatic NST3 issuance/acknowledgment may share a private `NodeState::SourceProgressPreparation` only inside the originating locked command. The object owns one normally parsed accepted configuration and, for issuance, one selected source envelope. It is a stack-owned optional value, passed through const pointers to preflight and semantic application. NodeState stores no preparation; no global/thread-local preparation cache exists. The existing thread-local work counters remain observation only.

The factory requires the actual retained predecessor object, immutable subscription instance, revision and process-derived structural commitment, and the currently active accepted configuration event and digest. It reconstructs the selected locally authored source through the ordinary exact ancestry path and obtains the initial recipient generation/SPKI-bound delivery policy. It checks current disclosure eligibility and initial outbox admission. The parsed configuration comes from accepted canonical history through the normal parser, not a caller-supplied assertion.

The preparation expires when the coherent command scope ends, whether the command succeeds or throws. A later command, new source, changed configuration, retry, state reconstruction or worker iteration cannot inherit it. Empty polls and idempotent retries do not manufacture an ordinary progress preparation. It never enters request bytes, a journal, a checkpoint, a backup, a peer envelope, or a response.

## Checks that remain live

Revision 0559 lets preflight and application share one [private immutable strict NST3 parse](PARSED-SOURCE-PROGRESS.md), bound to the exact committed bytes. Both semantic passes still run independently. Each requires the exact state owner and predecessor object, grant, instance, revision, structural root, active configuration event/digest, timestamp and issue/ack shape. Each still validates current disclosure, manual request or exact finite automatic-grant consequence, allowed predecessor shape, source order, record and byte budgets, and revision/schedule consequences.

For issuance, each use rechecks selected canonical source position and inbound index, stored record digest, full local-authorship metadata and current policy. The decoded transaction's entire envelope and policy must equal the prepared source and derived policy; source/delivery operations, record digest and raw-payload accounting must agree. Outbox absence and capacity are **checked again**, not cached as a reusable successful admission. The nested outbox mutation uses the shared admission checks; revision 0560 reuses only its exact-byte-bound record syntax inside the same command. Normal policy parsing and untrusted replay remain independent. See [nested admission](SOURCE-OUTBOUND-ADMISSION.md).

For acknowledgment, the preparation owns only the parsed configuration. Each semantic pass still finds the actual outstanding operation and its real durable receipt, and checks operation, record digest, recipient, recorder, generation/SPKI and exact receipt commitment. A receipt is never stored in preparation or replaced by a boolean. Manual progress remains atomic with its outbox consequence; automatic progress advances exactly one existing finite allowance in that same transaction.

## Replay and canonical validation are independent

Preparation is explicitly rejected when replaying, when attached to an unrelated journal kind, or when attached to a complete-state source transition. Ordinary replay receives no preparation and reconstructs the source and parses accepted configuration itself. Creation, scheduling changes, termination, succession, reconciliation and checkpoint loading retain complete canonical semantic validation.

The diagnostic `reference` build additionally runs complete source-history validation after each ordinary progress check and compares the incremental selector and ancestry index against full reconstruction. The `independent` diagnostic build disables command preparation and restores separate candidate/preflight/application reconstruction while retaining the same NST3 writer. These are isolated test builds, not alternate distributed runtimes. The Python NSS1–NSS6 decoder remains a separate structural-commitment implementation.

No NSR1–NSR6 request, NSS1–NSS6 canonical subscription, NST1–NST3 transaction, source envelope, logical-state encoding, permission class, configuration version, storage schema or product limit changes. New preparation-work fields are observational diagnostics under the existing additional current INSPECT requirement. Legacy response and selector semantics remain unchanged. Revision 0556 can read histories written by this revision; revision 0555 still cannot understand NSR6 mutation provenance.

## Measured manual boundary

The same scenario is freshly exercised with the actual revision-0556 executable and the new executable: native provider and recipient, 64 originals followed by 64 corrections, 128-byte raw source payloads, 128 admitted sources and exactly 16,384 accounted source-payload bytes. The table describes the calling thread at ordinary manual source 128, not transport or total process allocations.

| Work | Actual 0556 ISSUE | 0557 ISSUE | Actual 0556 ACK | 0557 ACK |
|---|---:|---:|---:|---:|
| Selected source constructions | 3 | 1 | 0 | 0 |
| Accepted source-configuration parses | 2 | 1 | 2 | 1 |
| Indexed correction-parent lookups | 3 | 1 | 0 | 0 |
| Raw source bytes encoded | 384 | 128 | 0 | 0 |
| Complete subscription-state encodes (compact response) | 0 | 0 | 0 | 0 |
| Retained ancestry entries scanned | 0 | 0 | 0 | 0 |
| Exact durable-receipt checks | 0 | 0 | 2 | 2 |
| Ordinary transaction bytes | 887 | 887 | 229 | 229 |

All 256 ordinary compact ISSUE/ACK responses are checked, not only the last sample. In the new manual ISSUE, construction creates one preparation; preflight and application each use it once and each recheck the source binding. Neither reconstructs a second envelope or reparses configuration. ACK creates one configuration-only preparation and keeps both receipt checks. Multi-lease corrections preserve independently recomputed canonical lineage and structural selectors.

This reduces computation, not the embedded source payload delivered to a peer. Decoding, selected-envelope copies/comparisons, record hashing, outbox admission, journal synchronization and response construction still cost work. New diagnostic fields can increase complete JSON response size. Legacy responses still encode complete NSS state to calculate the original `state_digest`. Full lifecycle/checkpoint work stays history-dependent. The acknowledged ancestry index and its allocator overhead are unchanged.

## Automatic boundary: the remaining duplicate is explicit

A focused native worker probe measures actual AUTO_ISSUE and AUTO_ACK, with a real recipient TLS receipt between them and the existing process-kill pause before automatic acknowledgment. Both transitions consume exactly one step of an existing two-step grant; the grant ends EXHAUSTED.

Revision 0558 retains the permanent oversize classification before transient route/capacity decisions but removes its second envelope construction. A successful classifier now produces one [single-use same-iteration eligibility object](AUTOMATIC-SOURCE-ELIGIBILITY.md), which is moved into this preparation. Normal AUTO_ISSUE therefore measures one source reconstruction, one eligibility reuse and zero preparation reconstruction. AUTO_ACK constructs no source and still checks the real receipt twice. Replay of the exact committed bytes constructs independently and creates neither object.

Some observational automatic-status paths may still reconstruct a preview. That observation never becomes worker authority and is not cached across polls. The one-construction result applies to successful ordinary manual and automatic ISSUE, not every read-only preview or complete canonical boundary.

## Private boundary test and negative control

An isolated native test build adds diagnostic-only private friends; normal product headers and binaries have no such access. It executes 37 native checks, including rejection of 33 independently changed preparation, transaction or authoritative-state facts: owner, predecessor object, grant, instance, revision/root, event/digest/time/shape, source/order/authorship/digest, policy and envelope, manual/automatic provenance, replay/unrelated/complete-state misuse, changed canonical source/configuration and changed outbox absence/capacity. Valid preflight and unprepared replay leave journal bytes and logical state unchanged. This is a boundary test on owned state, not proof against arbitrary process memory corruption.

The negative build omits only the selected-source-record-digest comparison. It must fail with `preparation boundary accepted: source-record-digest`. All other decoders, authority, receipts and outbox checks remain enabled. The failing probe exit is the desired negative-control result; it is not counted as a passing weakened product. Only its narrow patch and failure account are retained, never its source tree, objects or executable.

See [fresh validation](../validation/VALIDATION.json), [measurements](../validation/METRICS-SUMMARY.json), [attempts](../validation/ATTEMPTS.md), [selector contract](STRUCTURAL-SOURCE-SELECTORS.md) and [compact journal contract](COMPACT-SOURCE-PROGRESS.md). All evidence is one-kernel laboratory evidence; authentication alone still does not establish freshness.
