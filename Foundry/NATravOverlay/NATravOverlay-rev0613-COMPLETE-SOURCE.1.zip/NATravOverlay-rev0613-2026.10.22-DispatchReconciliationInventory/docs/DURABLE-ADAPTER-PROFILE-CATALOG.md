# Durable adapter-profile catalog

## Purpose and boundary

`DURABLE_ADAPTER_PROFILE_CATALOG_V1` is the bounded persistence and exact-
generation resolution layer for operator-pinned external packet adapters.

It does not decide who is an owner or administrator. The existing authenticated
configuration boundary supplies opaque authority evidence and a verifier. The
catalog calls that verifier before activating any profile or endpoint record,
retains only SHA-256 of the authority evidence, and records a bounded rejection
event when a canonical request is denied.

The catalog is carrier policy. It does not identify a remote NATravOverlay
peer, grant application authority, manufacture a receipt, accept custody, or
turn an adapter process into a trusted principal.

## Objects

The catalog retains two versioned object families.

### Operator-pinned profiles

Profiles use the canonical `NATRAV_ADAPTER_PROFILE_V1` record defined in
`ADAPTER-PROFILES.md`. Every generation remains in history. Creation requires
generation 1 and a zero predecessor. Replacement requires the same stable
identifier, exactly the next generation, and SHA-256 of the predecessor's full
canonical record.

### Configured adapter endpoints

An endpoint uses this canonical record:

```text
NATRAV_ADAPTER_ENDPOINT_V1
id=<stable-lowercase-id>
generation=<nonzero-u64>
previous=<64-lowercase-hex>
role=<route|listener>
locator=adapter-v1|profile=<id>|generation=<u64>|link=<16-lowercase-hex>|epoch=<u32>
profile-sha256=<64-lowercase-hex>
```

Endpoint creation and replacement follow the same exact predecessor rule as a
profile. A stable endpoint identifier cannot change between route and listener
roles. A replacement may select a different exact profile generation, link, or
epoch only through a separately authorized endpoint generation.

The `profile-sha256` field binds the endpoint to the exact canonical profile
record. A matching profile identifier and generation with different bytes is
rejected as stale rather than guessed.

## Authority adapter

The catalog accepts an integration-supplied verifier:

```text
(operation, canonical-object-bytes, opaque-authority-evidence) -> decision
```

The operation is one of profile create, profile replace, endpoint create, or
endpoint replace. The verifier is where the complete product must connect its
existing authenticated owner/admin policy.

Raw authority evidence is never stored by this bounded core. The durable event
retains its SHA-256, the object digest, the operation, and a bounded canonical
rejection code. A denied or structurally invalid canonical request remains
evidence and never becomes active configuration.

An empty verifier, empty evidence, oversized evidence, malformed verifier
result, or exhausted rejection-evidence bound is a hard failure.

## Append-only journal

The owner-private catalog is an append-only hash-chained journal.

The file starts with the fixed `NAPCAT01` header. Every event frame contains:

- `NAPREC01` record magic;
- canonical payload length;
- monotonically increasing sequence;
- SHA-256 of the prior complete record;
- SHA-256 of the event payload;
- the canonical event payload;
- SHA-256 of the complete record header and payload; and
- `NAPEND01` commit trailer.

The replay engine verifies the complete chain, payload digests, record digests,
sequence, canonical event text, profile and endpoint succession, exact profile
resolution, and all configured resource bounds.

A complete frame with a bad digest, chain, trailer, object transition, or
canonical encoding is corruption and is never repaired automatically.

A partial final frame is treated differently. When all prior frames are valid,
the catalog may truncate only that incomplete tail and immediately append a
canonical recovery event binding the exact discarded byte count and SHA-256.
A strict audit mode refuses the tail without changing it.

## Filesystem rules

The catalog path must be canonical and absolute. Parent components are opened
without following symlinks. The final parent directory must be owned by the
effective user and inaccessible to group and other users.

The catalog itself must be one owner-private regular file with no hard-link
aliases. Operations take an exclusive file lock, replay current state under
that lock, verify that the configured pathname still names the opened device
and inode, append one bounded frame, `fsync`, and check the pathname again.

The same-UID operating-system race between a pathname check and a hostile
rename cannot be eliminated by POSIX file APIs alone. The implementation keeps
that interval small and fails if replacement is observed; it does not claim a
complete hostile-same-UID sandbox.

## Finite limits

The catalog has explicit bounds for:

- total bytes;
- total records;
- retained profile generations;
- retained endpoint generations;
- rejection evidence; and
- opaque authority evidence supplied to one operation.

When a bound is exhausted, the catalog refuses further mutation. It does not
drop accepted history, silently compact authorization evidence, or grow
without limit.

## Configured preparation

`prepare_configured_external_adapter_endpoint()` performs the narrow bridge to
the supervised adapter:

1. replay and resolve one exact endpoint identifier and generation;
2. resolve the exact retained profile generation;
3. verify the endpoint's bound profile digest;
4. call `external_packet_adapter_options_from_profile()`;
5. recheck that every pinned profile and executable digest matches; and
6. return the endpoint coordinates plus immutable launch options.

No configured path may construct `ExternalPacketAdapterOptions` from arbitrary
command-line fields.

A prepared sealed image may survive later pathname replacement or disappearance
within the bounded carrier lifetime. A new node process reopens the durable
catalog and revalidates the configured executable path and digest, so the same
replacement is detected across restart unless an authorized successor profile
and endpoint generation were recorded.

## Current assurance boundary

The revision-0592 bounded delta exercises canonical records, authorization
rejection, durable replay, incomplete-tail recovery, corruption rejection,
exact-generation resolution, sealed-image preparation, process death, bounded
carrier reconstruction, and restart-style path revalidation using local
fixtures.

It is not the complete product integration. The complete source tree, real
owner/admin command handler, persistent route/listener registry, two full
nodes, TLS/HELLO/NOS1 lifecycle, full matrices, and release rebuild remain
mandatory gates before a product `PASS` may be recorded.
