# Conditional outbox administration

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

Revision 0531 adds optional semantic compare-and-act to the existing `cancel`, `retry`, and `rebind` commands. The running native C++ state owner verifies the selected operation and current local authority. It commits the ordinary delivery transition and an exact command receipt together. There is no new remote administrative endpoint.

## Select, then act

First use an exact query, not the generic truncated status list:

```sh
./node/bin/natrav-overlay outbox-query \
  --control state-a/control.sock --operation HEX64 --history-limit 0
```

Read `records[0].condition.state_digest` and the top-level `configuration_digest`. Both optional arguments must then be supplied together:

```sh
./node/bin/natrav-overlay cancel \
  --control state-a/control.sock --operation HEX64 \
  --expected-state SELECTED_STATE_HEX64 \
  --expected-configuration SELECTED_CONFIGURATION_HEX64 \
  --reason 'stop the exact selected obligation'

./node/bin/natrav-overlay retry \
  --control state-a/control.sock --operation HEX64 \
  --expected-state SELECTED_STATE_HEX64 \
  --expected-configuration SELECTED_CONFIGURATION_HEX64 \
  --reason 'recipient policy deliberately changed'

./node/bin/natrav-overlay rebind \
  --control state-a/control.sock --operation HEX64 --generation b-next \
  --expected-state SELECTED_STATE_HEX64 \
  --expected-configuration SELECTED_CONFIGURATION_HEX64 \
  --reason 'use the separately accepted replacement key'
```

These are templates: `HEX64` names must be replaced with actual returned values. Absence of both expectation arguments selects the unchanged legacy command. One missing argument is an error, never a downgrade to legacy behavior. Conditional actions require V8 or later durable local-control policy; older states still support legacy commands.

## Semantic selection and authority

The exact-operation query's additive `condition` account commits the immutable operation and record digest, queue sequence, complete durable receipt, complete delivery policy, attempts, last attempt and next-attempt anchors, errors, expiry, cancellation, and full transition history. It also binds applicable source/epoch lineage restrictions and the most recent conditional receipt root. It excludes payload bytes, process-local index counters, routing telemetry, maintenance representation, and wall-clock passage without a journal transition.

A new receipt, begun attempt, failed attempt, retry, rebind, rejection, cancellation, expiry, or conditional action changes the selected state. Adoption as a publication-epoch predecessor also changes its restriction bits even when the old outbox record itself is unchanged. Unrelated operations and successful inspection do not.

The selected configuration digest binds effective canonical configuration, not a process-local lease pointer or an inspection revision. The actual accepted event is retained in the action receipt. A canonical configuration changed and later restored identically can match again; this is a semantic comparison, not an assertion that no configuration activation intervened.

Outbox administration remains node-wide for authorized maintenance principals; a per-UID action identity is not a new per-author ownership rule. A digest is not permission. The daemon obtains `SO_PEERCRED` before request reading, then rechecks the actual UID's current `MAINTENANCE` authority under a stable configuration after decoding. `INSPECT` alone cannot mutate; possession of an expectation or another UID's command digest cannot confer authority. Quiesce/drain restrictions continue to apply.

New actions reject a changed configuration with `OUTBOX_CONFIGURATION_CONFLICT` and changed operation state with `OUTBOX_STATE_CONFLICT`. They do not silently refresh selectors or retry against newer state. Current operation and target-key rules still apply after comparison. A fresh digest cannot cancel a receipt, revive an adopted predecessor, rebind a subscription beyond its grant, or target a non-ACTIVE generation. Conditional retry additionally requires the existing exact recipient generation/pin to remain configured and nonrevoked. Cancellation remains available for otherwise eligible obligations whose key has been revoked.

The daemon retains the peer's transition mutex and the journal mutex through comparison and commit. This orders the decision against a bounded in-flight delivery and other state transitions. It is not a hard real-time or wait-free operation.

## Durable idempotency

`APPLIED` means an ordinary transition and its receipt were synchronized in one event. `ALREADY_APPLIED` confirms the same prior command and does not apply it again. The response separates the accepted action from `current_outcome`; a retried operation may already have been rejected again or acknowledged when its older command is repeated.

Identity covers exact action, operation, expected state, expected configuration, target generation, reason, and kernel UID. Request PID and execution time are provenance but not idempotency inputs. A different reason is a different decision. An exact repeat is checked before new-action state comparison, but after current authentication and authority; it writes no successful event. It can confirm history after compaction, restart, encrypted restore, and path relocation without rewriting the prior accepted configuration.

This is a receipt for an internal administrative mutation, not a peer delivery receipt or proof of external effect. The current state in the response may differ from the immediate post-action state, whose metadata commitment remains retained.

## Formats

Local control kind 24 contains strict `OCA1`:

```text
magic OCA1
u8 action: 1 CANCEL, 2 RETRY, 3 REBIND
operation[32], expected_state[32], expected_configuration[32]
u16-length target_generation (empty except REBIND)
u16-length printable reason (1..256 bytes)
exact EOF
```

The payload-free `OCM1` metadata encoding is the magic, operation digest, record digest, big-endian u64 queue sequence, optional ordinary application receipt, and optional existing canonical delivery-state encoding. The implementation and independent baseline encoder in `run_conditional_outbox.py` specify the lengths and markers exactly. Metadata hashes commit free-form reasons/errors without disclosing their contents in the query.

```text
state_digest = SHA256(
  "NATRAV_OVERLAY_OUTBOX_SELECTION_V1" || 0x00 ||
  u32(metadata_size) || OCM1 || u8(restrictions) || previous_action_root)

request_digest = SHA256(
  "NATRAV_OVERLAY_OUTBOX_ADMIN_REQUEST_V1" || 0x00 || u32(kernel_uid) || OCA1)
```

Restriction bits are 1 for a source-subscription delivery, 2 for an adopted publication-epoch terminal, and 4 for a delivery in an adopted subscription predecessor. These are retained-state relationships, not scope permissions. `previous_action_root` is zero before any conditional action, otherwise SHA256 of its last canonical `OAT1` event.

Journal kind 35 carries `OAT1`: request, actual UID/GID/PID/time, accepted configuration event, request digest, preceding receipt root, selected metadata, restriction bits, and source-derived resulting metadata digest. One append commits the action through the existing rebind/cancel/retry semantic decoder. Conditional actors use a reserved `CONDITIONAL_UID_` transition marker; replay rejects stripping the conditional wrapper from the ordinary transition.

The optional logical checkpoint extension `NOA2` retains conditional events in acceptance order. Loading validates their command digests, configuration permissions, receipt chain, immutable record/policy bindings, ordinary transition prefixes, and reconstructed result. Removing a receipt while keeping its tagged transition fails closed. Existing state without conditional actions keeps its preceding logical encoding. Older executables reject kind 35 or `NOA2` rather than discard them. Storage schema 2, configuration versions, and peer protocols are unchanged.

`outbox-query` exact rows expose the latest action and count. Offline `inspect` adds `conditional_outbox_actions` when present, containing administrative receipts without private before-state bytes or free-form reason text. Existing offline state inspection itself can expose payloads and must still be protected.

## Bounds and costs

The new receipt registry permits at most 1,024 accepted conditional actions globally and 32 per operation. Before-state metadata is limited to 32,768 bytes and 256 retained delivery transitions. Limits are not refunded by compaction or an unrelated new configuration. An exact previously committed command can still return its receipt after the registry is full.

For an operation exceeding the metadata limit, the exact query returns `condition.available=false` with `OUTBOX_ADMIN_HISTORY_LIMIT`; ordinary bounded metadata/history inspection and legacy administration remain available. No payload collection is copied. Exact commitment computation is linear in this bounded transition history and scans the already bounded source/channel registries for lineage restrictions; broad outbox pages remain on their preceding index-only path. The ordinary exact-page response byte limit remains in force, and a too-small row budget is rejected.

There is no receipt pruning, global successful-read log, bulk mutation, automatic stale-command retry, or durable read snapshot. The registry can consume bounded additional storage; old histories are not erased to make room. Legacy commands remain intentionally unconditional unless their own ordinary semantics forbid an action.

## Testing and remaining trust boundary

The tests independently encode selected pending metadata and requests, race identical callers, deliver a real receipt between selection and cancellation, exercise new rejection/legacy changes, exact rebind, real UID denial and live revocation, source-grant and epoch protections, the 32-action boundary, pre/post-commit `SIGKILL`, semantic corruption with recomputed checksums, and authenticated compaction/encrypted restore/relocation. Current completed profiles are recorded in [validation](../validation/VALIDATION.json); failures are in [attempts](../validation/ATTEMPTS.md).

A valid old snapshot can restore older actions and receipts. This is not freshness, distributed ownership, split-brain protection, a transaction with the remote recipient, cancellation recall, or universal power-loss proof. Complete authenticated journal chains protect their contents under key custody, not against rollback of every trusted head. Tests run on one Linux kernel with controlled local endpoints.

## Action-result recipient protection (0544)

Generic and conditional rebind refuse action-result operations with OUTBOUND_ACTION_RESULT_BOUND. New reserved result selections include restriction bit 8. The exact key is part of the admitted disclosure contract and NAC1 payload. Rejection retry retains that key and reacquires current ordinary quota; it does not create a new future result reservation. See [result-capacity contract](RESULT-CAPACITY.md).
