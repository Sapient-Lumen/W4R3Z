# Removable-media packet adapter — revision 0600

Revision 0600 adds one explicitly configured, operator-pinned complete-datagram
adapter role to the existing `natrav-overlay` executable:

```text
removable-media-packet-adapter
```

The role is launched only through an accepted V19 adapter profile and the
supervised descriptor-3 `NAPA0001` boundary. It opens no node identity,
journal, local-control endpoint, or peer key. It is carrier plumbing only.

## Explicit directory authority

A profile pins three canonical absolute directories and their exact device and
inode observations:

- inbound complete bundles;
- outbound complete bundles;
- bounded quarantine evidence.

Every component is opened without following symlinks. Each final directory
must be owned by the effective user, owner-readable/writable/searchable, and
inaccessible to group and other users. The three directories and their object
identities must be distinct. A cooperative exclusive `flock` prevents two
adapter processes from claiming the same directory object simultaneously.

The adapter periodically revalidates each pinned object. Replacement,
permission drift, or pathname/object disagreement fails the carrier. It never
scans mount tables, volume labels, USB identifiers, sibling directories, or
arbitrary devices.

## Canonical bundle

One complete datagram is encoded as one `NRMB0001` bundle:

```text
magic[8] | reserved[4] | link[8] | epoch[4]
created_ms[8] | expires_ms[8] | payload_bytes[4]
payload[payload_bytes] | sha256[32]
```

The lowercase content digest is also the canonical filename:

```text
<64 lowercase hexadecimal digits>.nrmb
```

The digest covers every byte before the digest trailer. It detects corruption;
it is not peer authentication. Link and carrier epoch are explicit finite
coordinates, not node identity.

Publication uses an owner-private same-directory temporary file, complete
write, file `fsync`, `renameat2(RENAME_NOREPLACE)`, and directory `fsync`.
Readers admit only complete canonical regular files. Malformed, expired,
wrong-link, wrong-epoch, or digest-mismatched files are removed with bounded
quarantine evidence. Incomplete copy and publication names are ignored until
they exceed the declared lifetime, then retired with evidence.

## Finite work and storage

The profile explicitly bounds:

- datagram MTU;
- queued bytes and files;
- directory entries examined;
- entries processed per scan;
- bundle lifetime and polling interval;
- quarantine bytes and files;
- duplicate-history entries.

Outbound pressure returns NAPA `BUSY` without partial publication. Inbound
pressure leaves the complete file for a later bounded scan. Local publication
or queue admission is not an application receipt.

## Carrier incarnation isolation

Persistent files can outlive the adapter process that created or expected them.
A new configured outbound carrier therefore selects a fresh nonzero NPL1 packet
epoch. A listener starts unbound and binds once to the first valid frame for its
configured stream identifier; later frames with other epochs are ignored for
that stream lifetime.

This finite epoch is an anti-confusion namespace, not a cryptographic identity.
TLS 1.3 and HELLO still authenticate the peer. A party that can inject the
first valid packet may cause bounded denial of service, but cannot gain overlay
authority or forge an application receipt.

## Assurance boundary

The deterministic lifecycle uses owner-controlled local directories to model
copying files between removable media endpoints. It exercises interrupted
copies, corruption, duplication, delay, loss, stale files, directory
replacement, process death, node restart, fresh authentication, pending work,
and exact receipt reconciliation.

It does not establish USB or SD hardware behavior, filesystem durability under
physical power loss, flash endurance, mount or unmount semantics, independent
hosts, or a human courier. Those are verification debts, not reasons to leave
the bounded protocol and durable state machine unbuilt.
