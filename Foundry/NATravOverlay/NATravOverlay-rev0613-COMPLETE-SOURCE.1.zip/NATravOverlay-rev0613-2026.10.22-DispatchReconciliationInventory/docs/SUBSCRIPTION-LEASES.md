# Finite subscription leases and authenticated withdrawal — revision 0524

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

**Revision 0525 addition:** [explicit terminal receipt reconciliation](TERMINAL-RECONCILIATION.md) can adopt an exact stored late receipt without altering the original withdrawal/expiry or scheduling allowance. It uses local `NSR4` and reconciled `NSS6` state in existing journal kind 32; it adds no peer request or automatic authority. Ordinary unreconciled state and old format semantics remain unchanged.


## Implemented boundary

Revision 0523 adds an explicit lifetime and terminal-withdrawal boundary to the retained source-subscription machinery. It does not create a new transport or disclosure authority. Source delivery still uses explicit local authorship, accepted provider disclosure policy, canonical `NSE1` envelopes, the durable outbox, multi-route TLS, recipient admission, and receipt-gated progress.

V15 indefinite subscriptions remain readable. V16 supplies the finite lease semantics described here.

## V16 disclosure rule

A V16 rule has eleven fields:

```text
source_disclosure=
  grant-id,
  manager-UID,
  source-author-UID,
  subscriber-node,
  subscriber-key-generation,
  exact-scope,
  maximum-records,
  maximum-source-payload-bytes,
  lease-generation,
  lease-duration-ms,
  RETAIN|CANCEL
```

The lease duration is bounded from 100 ms through 604,800,000 ms. Lease generations are immutable identifiers and unique within one accepted policy. The accepted provider policy—not the remote request—chooses the lifetime, budgets, source domain, subscriber key, and pending-operation disposition.

The lease begins when the provider synchronizes the accepted subscription admission. Its absolute expiry time is stored in the subscription state. Reconnecting, changing a request ID, restarting, restoring, or reactivating the same policy does not extend it.

## Authenticated remote withdrawal

The subscriber command is:

```text
source-subscription-withdraw \
  --config subscriber.conf \
  --provider A \
  --grant grant-id \
  --request-id HEX64 \
  --lease-generation lease-g1 \
  --instance HEX64 \
  --expected-revision N \
  --reason TEXT
```

The provider requires agreement among:

- mutual-TLS authenticated peer node;
- exact configured peer key generation and SPKI;
- HELLO node identity;
- accepted disclosure rule;
- immutable lease generation;
- retained remote-admission account;
- exact subscription instance and revision;
- bounded withdrawal request ID and reason.

Another authenticated peer, another key generation, or a stale revision cannot withdraw the instance. The terminal account records the real remote actor rather than inventing a local UID or PID.

An exact retry of the same accepted withdrawal returns `ALREADY_WITHDRAWN` and creates no second terminal event.

## Natural expiry

A leased subscription is terminal when the stored absolute expiry is reached. Expiry is committed when a mutating local command, authenticated remote request/status/withdrawal, or automatic-source worker encounters the elapsed lease.

Local `source-subscription-status` remains observational: merely inspecting a stopped node does not append an expiry transition. The returned state still exposes the lease clock so an operator can distinguish elapsed time from a committed terminal account.

The expiry actor is the provider lease mechanism, not the subscriber. It records the accepted configuration event, exact lease generation, time, reason, and pending disposition.

## Pending operation disposition

Withdrawal and expiry stop future source selection. They do not rewrite the acknowledged frontier or source mappings.

| Accepted policy | Exact terminal behavior |
|---|---|
| `RETAIN` | Keep the current ordinary outbox obligation. It may later deliver or reach its ordinary rejection/cancellation/expiry outcome. |
| `CANCEL` | If the current delivery is pending, cancel that exact operation in the same synchronized journal transition as lease termination. |

`CANCEL` does not fabricate a receipt, retract recipient state, or prove that bytes were never observed. `RETAIN` does not permit issuing another source after termination.

The terminal account retains `NONE`, `RETAIN`, or `CANCEL` and the exact cancelled operation when applicable.

## Automatic-delivery consequence

If an automatic source-delivery grant exists, withdrawal or expiry terminalizes it in the same semantic transition:

```text
SOURCE_SUBSCRIPTION_WITHDRAWN
SOURCE_SUBSCRIPTION_LEASE_EXPIRED
```

The old grant cannot silently resume after policy restoration. A terminal subscription also rejects manual steps, automatic enable/pause, and other stale mutations.

## Durable representation

Current leased state is `NSS4`. It retains:

- accepted disclosure rule and digest;
- remote-admission provenance;
- lease start and expiry;
- optional terminal account;
- source mappings and acknowledged frontier;
- record and byte usage;
- automatic-grant history.

The source-subscription transaction remains journal kind 32. `NST1` covers transitions without an embedded outbox cancellation; `NST2` additionally carries and binds an exact cancellation.

Semantic replay checks the historical V16 rule, lease clock, authenticated actor, request digest, exact pending operation, cancellation actor/reason/key binding, and automatic-grant consequence before applying state.

The remote application protocol uses strict kinds 7 and 8 for leased requests and responses. Legacy V15 kinds 5 and 6 remain strict and readable. See [protocol](PROTOCOL.md).

## Tested behavior

The revision-specific suite covers:

- strict V16 parsing and V15 incompatibility with lease fields;
- exact authenticated request and withdrawal;
- wrong peer, generation, lease, instance, and revision rejection;
- idempotent withdrawal retry;
- pending `RETAIN` followed by ordinary later delivery;
- pending `CANCEL` coupled to the exact outbox operation;
- natural expiry coupled to automatic-grant termination;
- no later source selection after termination;
- real `SIGKILL` before and after synchronized withdrawal;
- keyed-state migration, authenticated compaction, signed encrypted backup, restore, relocation, and restart reconstruction.

## Limits

A lease is a provider-enforced subscription boundary, not a distributed clock or recall mechanism. A subscriber clock is not authoritative. A valid older backup can restore an older lease state, because journal authentication still does not establish freshness against complete rollback.

Withdrawal does not prove that the subscriber never saw pending bytes. Expiry does not erase source records or remote admissions. Revision 0524 adds provider-controlled [acknowledged lease succession](LEASE-SUCCESSION.md) under a fresh accepted finite rule. It requires a fully acknowledged terminal predecessor and exact selected commitments. Unacknowledged predecessors still cannot continue this way; reconnecting or changing request IDs is not succession authority.
