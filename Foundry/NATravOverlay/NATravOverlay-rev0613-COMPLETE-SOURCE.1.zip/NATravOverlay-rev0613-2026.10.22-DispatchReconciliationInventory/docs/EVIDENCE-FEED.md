# Durable consumption is now available

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Recipient materialization

Revision 0526 imports appear as ordinary target-domain admissions only after explicit local validation. Immutable feed rows retain subscribed_source provenance. Raw envelope admission by itself is not materialization, and feed authority does not enable import. [Recipient view semantics](SUBSCRIBED-SOURCE-VIEWS.md).

The process-local feed contract below remains unchanged. Revision 0509 also supplies [durable consumers](DURABLE-CONSUMERS.md) through separate explicit V11 grants. Applications needing restartable issued pages and acknowledged progress should use that API. Neither API makes arbitrary external effects exactly-once.

# Evidence feed — revision 0508

`evidence-feed` is a native, bounded, observational polling command for recipient-admitted evidence. It lets an application consume originals and corrections as new admissions without restarting full-selection hashing after every append. It is not a subscription socket, durable consumer offset, evidence-truth judgment, or exactly-once effect guarantee.

## Commands and explicit starting points

```sh
./node/bin/natrav-overlay evidence-feed \
  --control /owned/state/control.sock \
  --issuer A --scope observations/temperature --limit 32 --max-bytes 60000
```

Without a cursor, the default is `--start beginning`: return retained authorized admissions from the beginning. `--start now` instead returns no records and adopts the current authorized tail. Both successful responses always contain `next_cursor`, even for an empty selection. Continue with that cursor and the same filters, payload options, and resource limits:

```sh
./node/bin/natrav-overlay evidence-feed \
  --control /owned/state/control.sock \
  --issuer A --scope observations/temperature --limit 32 --max-bytes 60000 \
  --cursor TOKEN_FROM_PREVIOUS_RESPONSE
```

Do not combine `--start` and `--cursor`. Initialization mode is not part of continuing selection. A new scope can begin empty and later receive records without requiring a new token, provided the accepted read policy has not changed.

Optional `--payload yes --payload-length N` includes at most N bytes from the start of each payload. The default enabled length is 4096; the maximum is 16384. `payload_more` explicitly reports truncation. Fetch later bytes through an exact-operation `evidence-query --view history --operation HEX64 --payload yes --payload-offset N`. The feed itself has no arbitrary payload offset or exact-operation selector. Changing payload mode or requested length changes feed context and requires explicit restart.

## Authority before selection

This new command requires an explicitly adopted V10 exact-domain policy. Earlier V9 node-wide read configurations keep their existing `evidence-query` behavior; they do not acquire the new feed implicitly.

The kernel UID must have `EVIDENCE_READ` and exact `evidence_read=UID,ISSUER,SCOPE,METADATA|PAYLOAD` domains. Payload mode additionally requires `EVIDENCE_PAYLOAD` and a PAYLOAD domain. It does not emit metadata-only domains in the payload feed. Existing ALL and INSPECT grants do not grant evidence reading. Filesystem reachability and application authority remain separate.

As with `evidence-query`, the daemon obtains SO_PEERCRED before reading request bytes. After decoding the bounded request it acquires the current accepted configuration lease, authorizes the UID/classes/domains, and retains that configuration through selection and encoding. A connection opened before revocation cannot finish its request later and rely on earlier authority. Configuration publication does not retract already encoded authorized response bytes.

Issuer and scope filters are exact and conjunctive; they never grant access. Authority is applied before domain counts, position lookup, row construction, payload access, and byte-limit decisions. Hidden records neither create sequence gaps nor consume record visits. Counts and remaining-work accounts cover only the authorized selection in its requested metadata/payload mode. A scope filter matching no permitted domain returns an empty feed rather than revealing whether another domain exists.

## Immutable admission events

Every selected original produces `EVIDENCE_ADMITTED`; every selected correction produces `CORRECTION_ADMITTED`. Rows contain:

- authorized admission ordinal, immutable operation ID, issuer, recipient and scope;
- immutable record digest and payload size;
- correction predecessor operation ID, or null;
- stored admission authorization account, or null for compatible legacy data;
- an optional explicitly bounded payload prefix.

There is deliberately no mutable `superseded_by` or current-head flag. A later correction is another event, not a rewrite of a prior event. Replaying an earlier token therefore returns the same earlier event metadata even after a correction arrives. Current views remain available through `evidence-query`.

Correction invariants require the same issuer, recipient, and scope as the predecessor, so exact-domain authority does not expose a link into another hidden domain. Starting at `now` can nevertheless encounter a correction whose predecessor predates the adopted tail. Retrieve that predecessor by operation ID under the same current authority; absence from a consumer's local history is not evidence that the predecessor never existed.

`sequence` is a one-based ordinal in the authorized, filtered admission history. It is not a global journal offset, timestamp, durable consumer identity, or cross-policy ordering authority. Operation IDs and record digests remain stable across reconstruction. Duplicate peer deliveries do not create additional admission events. Denials, pending outbound operations, action completions, key events, and administrative events are not this evidence feed.

## Continuation contract

`NET1` tokens are 152 binary bytes rendered as 304 canonical lowercase hexadecimal characters. They authenticate:

| Field | Meaning |
|---|---|
| UID | The actual kernel principal |
| Feed digest | Node ID, exact filters, payload mode/length, and requested row/byte limits |
| Configuration digest | The accepted effective runtime configuration |
| Read-authority digest | Effective exact-domain access for this UID |
| After position | Number of authorized selected admissions already returned or explicitly skipped by `start now` |
| Expiry | Monotonic time at which this particular token expires |

HMAC-SHA-256 uses OpenSSL EVP_MAC with checked return values and CRYPTO_memcmp for tag comparison. The 256-bit random secret is initialized with RAND_priv_bytes and is separate from query-cursor, state-authentication, TLS, and backup keys. No token secret or table is persisted. Supported primitive API references: [EVP_MAC-HMAC](https://docs.openssl.org/3.0/man7/EVP_MAC-HMAC/), [CRYPTO_memcmp](https://docs.openssl.org/3.0/man3/CRYPTO_memcmp/), [RAND_bytes](https://docs.openssl.org/3.0/man3/RAND_bytes/).

A token does not authorize access; every poll is reauthorized. New visible records append after its position and do not stale it. Hidden writes do not change its position or validity. Same-process compaction preserves token meaning. Each successful poll, including an empty one, returns a token with a fresh five-minute lifetime. The old token remains replayable until its own expiry. There is no irreversible server-side advancement when a response is sent.

| Condition | Required behavior |
|---|---|
| Altered token, foreign process, restart, restore, or relocation restart | `EVIDENCE_FEED_CURSOR_INVALID` |
| Different UID, node, filter, resource option, payload option, authority or accepted configuration | `EVIDENCE_FEED_CONTEXT_MISMATCH` |
| Token's own five-minute lifetime elapsed | `EVIDENCE_FEED_CURSOR_EXPIRED` |
| Authorized retained history shorter than the accepted position | `EVIDENCE_FEED_RESET_REQUIRED` |
| Existing read classes revoked | `LOCAL_CONTROL_CLASS_DENIED` before selection |
| V9/earlier node-wide policy | `EVIDENCE_FEED_SCOPED_POLICY_REQUIRED` |

A current implementation never prunes admitted history; the explicit short-history check protects future extensions. It is not a tested arbitrary-history-removal service. Any accepted configuration digest change invalidates continuation, including changes unrelated to the reader. A caller must explicitly choose beginning or now after a reset; the daemon does not invent continuity.

## Bounds, work and backpressure

A request permits 1..128 rows and 4096..60000 complete annotated JSON bytes. The transport frame is outside that JSON budget. Payload expansion is checked before hexadecimal encoding. If the first row cannot fit, `EVIDENCE_FEED_PAGE_TOO_SMALL` returns no token advancement; restart with different limits or smaller prefixes. If a later row cannot fit, the nonempty page ends immediately before it. There is no silent skipping.

Only the existing exact-domain history indexes are used. At most 256 configured domain grants are considered. Each page merges ordered domain indexes and seeks to the authorized union rank without walking prior pages. The global index used internally is never emitted in cursors, rows, roots, or work counters.

There is no selection-root hashing, full payload/history snapshot, server cursor forest, blocking poll, or event reactor. A caught-up poll reads index sizes but visits zero evidence records. A normal page visits at most its returned rows plus one row that did not fit. Memory for the request is bounded by configured domains, at most 128 returned rows and the JSON byte budget; existing persistent indexes remain proportional to retained evidence.

Selection and bounded response construction use the state mutex for one coherent page. Global-index binary-search timing and shared-resource contention are not concealed. HMAC, configuration hashing, authorization lookup, index-size checks and control transport still consume work; zero *record visits* does not mean zero CPU or allocation.

`caught_up` and `remaining_records` refer to the observation while this page was constructed. Another writer may append immediately afterward. There is no promise that caught-up state remains true. The normal control deadline applies, with the existing small response-transmission reserve. `EVIDENCE_FEED_DEADLINE` returns no partial successful response or advancement. Arbitrary operating-system scheduling cannot be turned into a hard real-time guarantee.

## Observational and consumer semantics

Authorized feed reads, including empty polls, do not append journal entries or modify the application logical digest. Existing denial/protocol audit behavior still applies. Feeds remain available while quiesced or draining as inspection operations, until shutdown actually closes service. There is no durable successful-read log.

Clients should process rows by immutable operation ID and retain their own duplicate handling. Losing a response or retrying an old token can replay events. Saving a token before a non-idempotent external effect can lose that effect; saving it afterward can replay the effect. This API does not solve that transaction boundary. After a server restart, explicit beginning replay plus application deduplication is the continuity option; `now` deliberately abandons unread retained history. Neither option is silently selected.

Authenticated state and encrypted backups preserve event content, read policies, and ordered reconstruction, not process-local token secrets. Those protections do not establish evidence truth, snapshot freshness, host-compromise resistance, or split-brain prevention. Metadata can itself be sensitive; authorized hashes, sizes and provenance are intentional disclosures.

## Reproduction

```sh
./node/build.sh static
PYTHONDONTWRITEBYTECODE=1 python3 node/tests/run_evidence_feed.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-feed-new
```

Six normal integrated cases exercise independent NEF1 encoding, strict bounds, MAC and context binding, real UID separation, live revocation on a partially transmitted request, append/correction replay, observational empty polls, concurrent readers/writers, compaction, restart, keyed migration, signed encrypted restore, relocation and subsequent delivery. A synthetic 68,558-record store supplies 65,557 authorized records and 3,001 hidden records, enumerated completely in 513 pages against an independent operation-order reference. A real C++ peer then supplies the next admission. This is a stored-fixture test, not thousands of network peers.

The optional `--case renewable_monotonic_expiry` uses the actual clock: renew after 150 seconds, reject the original token after its 300-second lifetime, and accept the renewed token. It runs separately from the normal matrix and must not be implied by a normal suite pass.

Current completed evidence, compiler hashes and negative controls are recorded in [validation](../validation/VALIDATION.json), with failed or partial attempts distinguished in [ATTEMPTS.md](../validation/ATTEMPTS.md).
