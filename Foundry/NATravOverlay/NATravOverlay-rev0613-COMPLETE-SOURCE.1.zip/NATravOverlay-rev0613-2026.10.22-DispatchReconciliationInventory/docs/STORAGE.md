# Durable consumer state — revision 0509

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Revision 0526 — source-derived recipient admission

Journal kind 33 carries NSV1 provenance plus its ordinary evidence record in one synchronized append. Checkpoint inbound marker 3 reconstructs the subscribed record, original outer authentication and source-derived contents; marker 1 peer admission and marker 2 local authorship retain their meanings. Authenticated audit recognizes kind 33. Materialized usage and indexes rebuild from admitted records. View rules and target reservations persist through accepted configuration history. No imported record enters the local-authored-source index. See [subscribed views](SUBSCRIBED-SOURCE-VIEWS.md).

**Revision 0525 addition:** [explicit terminal receipt reconciliation](TERMINAL-RECONCILIATION.md) can adopt an exact stored late receipt without altering the original withdrawal/expiry or scheduling allowance. It uses local `NSR4` and reconciled `NSS6` state in existing journal kind 32; it adds no peer request or automatic authority. Ordinary unreconciled state and old format semantics remain unchanged.


## Revision 0519 local sources

Kind 31 atomically commits `NLA1` local-authorship provenance followed by one ordinary evidence record. Checkpoint inbound discriminator 2 carries the account; 0 and 1 retain legacy/remote semantics. Replay verifies historical exact UID/scope authority, self-identity, record commitment, same-owner parent and immutable correction ancestry. No remote receipt or remote authorization is invented. Local authored records cannot be corrected or deduplicated as peer admissions. Older binaries fail closed on the new kind/marker. See [local source storage contract](LOCAL-EVIDENCE.md).

Journal kind 27 (consumer_update) and optional NDC1 logical checkpoint material preserve bounded consumer identity, selection, authority-adoption/reset history, current issued page, acknowledged position and last acknowledged batch. The transition is self-bound to a configuration event and kernel UID/PID/time. Exact prior-state validation prevents fabricated position movement. NDC1 is absent when no consumers exist. Both file replay and authenticated-prefix replay recognize kind 27; old unsupported binaries fail closed. Consumer state participates in logical digest, compaction retained-object counts, keyed validation, backup/restore and relocation. See [Durable consumers](DURABLE-CONSUMERS.md).

# Storage note — revision 0507

Revision 0507 adds [indexed pagination](INDEXED-PAGINATION.md) without changing this authority or durable format. Caches and ordered indexes are reconstructed, never independent state.

Scoped evidence reads add no journal record kind, checkpoint version or application schema. V10 read domains are existing accepted-configuration content. The exact issuer/scope index is derivative: normal admission, journal replay and checkpoint reconstruction populate it. It is not exported as a second authority database. Application state and original recipient admission sequences remain unchanged; only V10 query responses use authorized-selection ordinals.

Scoped policy and evidence survive keyed compaction, signed encrypted backup, restore and relocation. Relocation cannot change domains or command bits. Cursor keys remain process-local and are not backed up. Fresh authorized roots survive representation-only changes; old process tokens do not. [Scoped reads](SCOPED-READS.md).

# Storage and maintenance contract

## State ownership

A state directory contains:

```text
state.lock
node.meta
state.journal
control.sock      # while the daemon runs
```

`state.lock` is the stable exclusive ownership boundary. The journal inode may be atomically replaced during compaction without creating a second-owner gap.

Storage schema remains version 2. In unkeyed compatibility, complete corruption fails closed and a bounded incomplete final record may be truncated with recovery provenance. **Authenticated state never applies this tail repair:** every incomplete authenticated header/record fails closed without truncation. Explicit migration also requires a complete source.

## Journal additions in revision 0501

Two checksum-framed entry kinds were added:

```text
25  local_control_event
26  lifecycle_event
```

A local-control event retains request digest, kernel UID/GID/PID, command, class, active configuration event, time, decision, and typed error. A lifecycle event retains transition kind, request digest, UID/PID, active configuration event, time, deadline, pending counts, and reason.

The canonical logical-state extension marker is:

```text
NLC1
```

It carries local-control and lifecycle history through checkpoint, compaction, backup, restore, relocation, and offline inspection.

Successful read-only status calls are not journaled. This keeps observation from mutating the logical state. Denied requests are durable security events in V8.

## Checkpoint revision

Revision 0501 emits:

```text
NCP3
```

`NCP3` includes a marker that states whether the stored compaction publication measurements describe the current checkpoint frame.

- A live compaction candidate sets the marker and validates its exact current byte/record account.
- A backup checkpoint clears the marker while preserving historical compaction facts as history.

This fixes a case where backup creation after compaction plus later lifecycle events could incorrectly require old compaction byte measurements to equal the new backup checkpoint's physical size. `NCP2` remains readable for predecessor state and backups.

## Lifecycle reconstruction

The latest durable lifecycle chain reconstructs service mode:

- `QUIESCED` → `QUIESCED`;
- `RESUMED` → `RUNNING`;
- `DRAIN_STARTED` without a later terminal event → `QUIESCED` with interrupted drain;
- `DRAIN_COMPLETED`, `DRAIN_DEADLINE`, or ordinary `SHUTDOWN_REQUESTED` → next startup `RUNNING`, unless an earlier unresolved quiesce remains authoritative.

V6/V7 lifecycle is process-local. V8 binds every durable lifecycle event to an accepted configuration event.

## Optional authenticated representation in 0503

`NOAUTH01` wraps the epoch header and `NAR1` authenticates each exact `NOJ1` frame with HMAC-SHA-256, sequence and predecessor chaining. The first frame is a canonical checkpoint. All MACs verify before normal application replay; semantic invariants remain mandatory. Keyed paths require explicit `--state-auth-key`, protected existing schema-2 files and the ordinary stable state lock. The key is loaded once at process startup and never stored in accepted configuration or exported state.

Migration and rotation validate an actual synchronized on-disk sibling with the normal authenticated checkpoint decoder before publication. Live compaction uses the same decoder, accounts for physical authentication overhead in NCP3, preserves key history and parent-root provenance, and resumes keyed appends. The unkeyed application logical digest remains representation-independent, so changing epochs/keys does not change an obligation's meaning.

The inner backup manifest's checkpoint digest, backup ID and optional signature bind the complete authenticated checkpoint, including its root/generation. Encryption remains an independent outer layer. Keyed backup verification requires the explicit state key even when encryption or signing checks pass. Restore writes a keyed journal and appends restore provenance under that key. Relocation and V8 lifecycle use the same authenticated replay/append path.

Unkeyed compatibility remains available without a process key. Its checksums do not protect against an adversary able to replace semantically valid content. Supplying a process key refuses that representation rather than silently certifying it. Full authenticated-chain replacement by an older valid chain remains possible without a separately protected freshness anchor. No live-file encryption, symmetric-key-holder isolation, split-brain prevention or universal physical durability is claimed.

See [State authentication](STATE-AUTHENTICATION.md) for the exact format, custody, strict incomplete-tail refusal, key rotation and expected-head boundary, and [Encrypted backups](ENCRYPTED-BACKUPS.md) for export confidentiality.

## Revision 0504: explicit authenticated prefix adoption

`state-auth-audit` opens existing locks/files without creation, cleanup or mutation. `state-auth-recover` accepts only an explicitly selected maximal verified prefix followed by plausible incomplete terminal framing, never a complete bad MAC. It requires exact source SHA-256/root/count/byte selection and an owner-only no-overwrite copy of the entire source outside the state tree. A validated authenticated checkpoint is atomically published under stable ownership. Header version 2 retains key-bound source/discarded-byte provenance; application logical state is unchanged. Normal startup still fails closed. See [Authenticated recovery](AUTHENTICATED-RECOVERY.md).

## Incremental feed reconstruction (0508)

The evidence feed adds no journal record or checkpoint format. It reads the existing derived exact-domain history indexes and immutable admission records. Successful and empty polling are observational. Keyed replay, compaction, encrypted restore and relocation reconstruct event content but never persist process-local feed token secrets or consumer offsets. [Evidence feed](EVIDENCE-FEED.md).

## Projected consumer state (0510)

Ordinary consumers retain NCS1. A projected consumer uses NCS2 with a length-bounded NPR1 result extension. One kind-27 PROJECT event advances the exact issued page and changes its result; REBUILD atomically records a zero frontier/result and retired summary. There is no separate effect/ACK commit. NDC1 checkpoints carry the complete projected state and reconstruct its results from retained source records before acceptance. The application logical digest covers these fields. State schema 2, NCP3 and keyed authentication remain unchanged. Older decoders reject unknown NCS2 rather than stripping it. See [projections](PROJECTIONS.md).

## Numeric projected state (0511)

NCS2 now accepts NPR2 for NUMERIC_SUMMARY_V1; metadata NPR1 remains byte-compatible. Exact unit/scale/budgets, numeric totals, latest outcome codes and bounded prior results are validated against retained payloads on ordinary replay and checkpoint load. Journal kind 27/NDC1 still commits result and progress together. Older readers reject NPR2; no silent projection dropping occurs. See [numeric format](NUMERIC-PROJECTIONS.md).

## Automatic projection state (0512)

Journal kind 28 (NAU1) carries a complete next scheduling grant and, for a successful step, its source-validated AUTO_PROJECT consumer. One synchronized frame commits result, progress and page allowance. NAS1 is an optional schedule extension after NDC1; absent schedules leave older logical states unchanged. Normal and authenticated-prefix decoders recognize kind 28. Checkpoint reconstruction validates grant ownership/authority/history/bounds and independently recomputes projection results. Old executables reject new schedule material. Original grant PID/UID and daemon execution PID/UID are distinct. See [automatic processing](AUTOMATIC-PROJECTIONS.md).

## Revision 0513 — retirement

Kind 29 (`NRT1`) freezes a consumer and its final optional schedule together. Retired consumers use `NCS3`, wrapping one exact NCS1/NCS2 state plus terminal provenance. Checkpoints containing any retirement use `NDC2`, with separately enforced active and retired quotas. No-retirement states keep their old encoding. Registry reconstruction and final-state/source checks occur through the normal decoder, including authenticated audit and backup verification. See [storage contract for retirement](CONSUMER-RETIREMENT.md).

## Publication-channel state (0515)

Journal entry kind **30** carries strict `NCT1`. It contains one complete backward-readable `NCH1`, `NCH2`, or current `NCH3` channel state and may contain the existing ordinary evidence-plus-policy composite or one exact ordinary cancellation. The channel state and embedded obligation are validated as one transition before either is applied.

`NPH1` is the optional logical/checkpoint extension for active and retired publication-channel registries. It retains immutable channel identity, creation provenance, every bounded publication revision, epoch and terminal lineage, recipient key bindings, same-epoch correction ancestry, transition provenance, and terminal retirement. Replay validates each publication against retained projection and outbox state; a channel cannot advance unless the predecessor has a durable receipt.

Active and retired channels have separate finite registry limits. Retirement never reclaims a name or erases a prior result. Compaction may fold journal transitions into `NPH1`, but it must preserve the same channel history and ordinary outbox obligations.

See [publication channels](PUBLICATION-CHANNELS.md).


## Automatic publication grants (0516)

Current channel encoding `NCH2` adds a monotonically increasing schedule revision, up to 32 finite grant records, transition actor UID, and per-publication automatic generation. `NCH1` remains readable.

Enable, pause, source-derived block, retirement stop, and automatic publication remain kind-30 `NCT1` transitions. An `AUTO_PUBLISH` transaction contains the revised channel and the existing outbound evidence/policy composite. Semantic replay verifies the exact prior channel, grant count, allowance, projection result, active recipient generation, channel operation, and current authority. A fabricated block reason or detached allowance increment is journal corruption.

Checkpoint extension `NPH1` preserves active/retired channels and their complete bounded grant histories. Compaction, backup, restore, and relocation do not rewrite the grant generation or publication attribution. [Automatic publication contract](AUTOMATIC-PUBLICATION.md).


## Publication epochs (0517)

Current channel encoding `NCH3` adds a monotonically increasing epoch to each publication revision and, for an epoch-opening original, the exact terminal predecessor operation/outcome, reason, and actor. `NCH1` and `NCH2` remain readable.

A `NEW_EPOCH` kind-30 `NCT1` transaction contains the complete next channel state and the ordinary evidence-plus-delivery-policy composite for one `NPC2` original. If an automatic grant is enabled, the same channel state closes it as blocked. Replay derives the predecessor's terminal state from the already applied outbox history, verifies exact lineage and monotonic epoch, and rejects use of the evidence `corrects` field across the discontinuity.

`NPH1` checkpoints preserve all bounded epochs. Compaction, authenticated audit/recovery, backup, restore, and relocation cannot relabel a terminal predecessor or turn it into an acknowledged correction parent. [Publication epoch contract](PUBLICATION-EPOCHS.md).

## Revision 0520 — source subscription state

Journal kind 32 / NST1 couples full bounded NSS1 provider-subscription state with the established kind-24 outbox composite. Creation, issue, acknowledgment and retirement are attributable, generation-bound transitions. An issued source spends allowance; only a durable receipt permits its frontier to advance. A cancelled or rejected delivery does not refund disclosure allowance. NSB1 is an optional canonical checkpoint extension after existing consumer/projection/channel extensions; it can exist with none of those collections. Validation reconstructs authored-source order, envelope digests, correction mapping, delivery policy and receipt accounts. Never-used states keep their prior encoding. See [source subscriptions](SOURCE-SUBSCRIPTIONS.md).

## Revision 0555 — compact source-progress transactions

Existing journal kind 32 now also accepts `NST3` for ordinary ISSUE, ACK, AUTO_ISSUE and AUTO_ACK. The record contains an exact predecessor revision/commitment and only the changed source/outbox or durable-receipt account, plus active configuration and optional automatic allowance provenance. Replay derives the next complete subscription from already validated state; no complete supplied after-state is accepted.

`NST1`/`NST2` remain readable and remain the writer format for creation, scheduling changes, retirement, lease termination, succession and reconciliation. Canonical checkpoints still carry complete source-subscription state and rebuild the process-local commitment only after full validation. Storage schema 2 and journal kind numbering do not change. Older binaries reject unknown `NST3`; they do not silently apply it. [Compact progress contract](COMPACT-SOURCE-PROGRESS.md).

## NSS5 successor references (0524)

Kind 32 / `NST1` may atomically create a finite `NSS5` successor referencing exact terminal predecessor state, acknowledged mapping root, and cumulative frontier. No second owner-path file or separate adoption write exists. Full checkpoint decoding verifies retained ancestry and one-successor uniqueness; old states keep their old encodings. See [lease succession](LEASE-SUCCESSION.md).

## Recipient import automation (0527)

Kind 34/NIE1 couples source-derived materialization, scan/dependency state and allowance in one append. Automatic provenance is NSV2; manual provenance remains NSV1. Optional NIS1/NIH1 checkpoint histories retain at most 1,024 events per scheduled view, reconstructing each decision at its original inbound prefix. Automatic effects without their exact scheduling event are invalid. Journal and authenticated-audit decoders recognize kind 34. Unscheduled state has no new extension. Full actor and decision history appears in offline inspect; live scheduling status is bounded and observational. [Contract](AUTOMATIC-IMPORTS.md).

## Revision 0528 administrative review

[Import decision review and selective retry](IMPORT-DECISIONS.md) add bounded administrative pages and an exact one-source reconsideration command under existing V17 SOURCE_IMPORT authority. New NIR2 requests and NIE2/NSV3 state retain explicit local-manager provenance. Earlier durable encodings remain readable; no new read permission, peer protocol or configuration version is implied.

## Recipient-view terminal lifecycle

Recipient-view retirement uses NIE3 inside existing journal kind 34 and the existing NIH1/NIS1 retained history. It commits final evidence/schedule commitments and retained-unprocessed dependencies. Normal replay rejects later imports; checkpoint validation additionally checks that no imported record follows the selected terminal inbound prefix. Unretired encodings remain unchanged. See [retirement storage contract](VIEW-RETIREMENT.md).

## Outbox inspection (0530)

Revision 0530 adds no durable format. Exact-operation/recipient/outcome inspection indexes and immutable source/channel issuance links are reconstructed from normal semantic replay and checkpoints. Query revision counters and HMAC cursor secrets are process-local; they do not enter the logical-state digest or constitute a freshness anchor. [Outbox contract](OUTBOX-INSPECTION.md).

## Conditional administration (revision 0531)

Journal kind 35 stores `OAT1`: exact selected state/configuration, owner-bound request identity, real local principal, preceding receipt root, bounded before metadata, and the recomputed ordinary cancel/retry/rebind effect commitment. Mutation and action receipt share one synchronized append. The optional `NOA2` logical-state extension preserves these accounts during checkpointing. Validation requires their tagged ordinary transition prefixes and accepted maintenance policy; missing or altered receipts fail closed. States without this extension keep the preceding representation. See [conditional contract](CONDITIONAL-OUTBOX.md) for exact bounds and rollback limitations.

## Derived pending-capacity accounting

Revision 0535 adds no durable state. Global/recipient pending counts and payload bytes are rebuilt through the shared outbox decoder hook, including composite transitions and checkpoint replay. Snapshots summarize those derived totals instead of scanning operations again. Zero-byte pending records still reserve a count; terminal state releases once and explicit reopening reacquires. Nothing changes canonical logical-state bytes, backup identities or lower-limit policy rejection. [Contract](PENDING-CAPACITY.md).

## Ordinary runtime status (0536)

[Runtime status](RUNTIME-STATUS.md) now observes bounded metadata rather than
copying a `StateSnapshot`. Its ordinary logical-state digest is explicitly null;
`--logical-digest yes` computes the same canonical digest as before. Offline
inspection and backup/checkpoint digest meanings are unchanged. Authorized
admission/action outcome totals and pending generation-binding cardinalities
are derived during ordinary validated replay, never accepted from independent
persisted counters. No storage schema or journal-kind change is required.

## Retained configuration inspection (0538)

[configuration-history](CONFIGURATION-HISTORY.md) supplies exact event/binding lookup and bounded retained-prefix pages under current INSPECT. It omits canonical contents, reason text and relocation paths while preserving their commitments. Prefix selection does not grant authority or establish freshness. Runtime-bound mutation bindings are an explicitly described subset, not the entire effect or local-control audit log. Local request kind 27 (NHC1) introduces no new persistent encoding or peer protocol.

## Derived local-control history indexes (0539)

After semantic acceptance at existing append/checkpoint sites, decision and lifecycle accounts update derived prefix and ordinal-filter indexes. They bind the exact serialized event and referenced configuration-history prefix. No new persisted encoding or logical-state material is introduced. See [memory, replay and prefix limits](CONTROL-HISTORY.md).

## Conditional action administration (0542)

Journal kind 36 stores `AAT1`: the exact `ACA1` action-cancellation request, actual UID/GID/PID, accepted configuration event, UID-bound request digest, preceding action-administration root, complete bounded before-state metadata and source-derived resulting action metadata digest.

The kind-36 semantic transition applies the ordinary action cancellation and appends its administrative receipt together. Conditional cancellation marks the action with `ACTION_CANCELLED_CONDITIONAL`; checkpoint validation requires the corresponding receipt and rejects detached markers, changed source/authorization/configuration commitments or a forged result.

Optional logical-state extension `NAA1` preserves up to 1,024 receipts globally and one terminal receipt per action. States without conditional action receipts retain their preceding logical encoding. Compaction, authenticated audit/recovery, signed/encrypted backup, restore and relocation preserve the same action and receipt meaning. See [conditional action contract](ACTION-ADMINISTRATION.md).

## Durable action-result return (0543)

V18 action admission may retain an `ActionResultBinding` inside the authorized inbound/action record. Pending and terminal bindings are carried by the optional `NRA1` checkpoint extension.

Terminal executed, cancelled and expired actions use journal kind 37 and `NAT1`. One semantic transition contains the ordinary action terminal payload plus a complete `outbound_queued_with_policy` composite for the canonical `NAC1` result record. Replay derives and compares the terminal action, result record, operation ID and delivery policy before applying either component.

Checkpoint reconstruction independently reopens the accepted historical V18 configuration in deferred identity mode and verifies the exact action-result rule, peer generation/SPKI and delivery limits. It then reconstructs the expected result record and requires the exact ordinary outbox operation. The resulting source-action association is derived; it is not another trusted persisted registry.

Action-result capacity pressure is not an automatic truncation or dropped result. The action remains pending until the atomic transaction can be committed. This revision does not persist a separate future-capacity reservation before terminalization. See [action-result contract](ACTION-RESULTS.md).

## Reserved result representation (0544)

Authorized action marker 3 stores an exact bound; NRA2 checkpoints reconstruct it. AAT2 in existing kind 36 combines a conditional administrative receipt and NAT1 terminal result. Old marker 2/NRA1 and local-only actions retain their earlier encoding. State without these features does not change. The reservation indexes are derived, never separately persisted. See [result-capacity contract](RESULT-CAPACITY.md).

## Derived review-history summaries (0548)

Owner/request/provider/scope review-history indexes and cached immutable record summaries are reconstructed only after validated NRR1 admission or NRV1 replay. They are not additional persisted authority and do not change the logical-state encoding. Prefix commitments and summary rows survive representation changes; listing itself creates no event. [Contract](REVIEW-HISTORY.md).
