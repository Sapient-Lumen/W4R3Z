# Recipient subscribed-source views — revision 0527

Current view discovery: [manager-scoped source-view inventory](SOURCE-VIEW-INVENTORY.md) exposes retained administrative summaries without changing import or read authority.

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Purpose and explicit boundary

`source-view-import` is a manually invoked recipient-local materialization operation. It selects one already stored, authenticated provider NSE1/NSE2 envelope and creates ordinary indexed evidence containing the embedded original payload in a distinct, policy-reserved scope. The manual command introduces no remote operation, transport, plugin or implicit federation. A separate opt-in worker is described in [automatic imports](AUTOMATIC-IMPORTS.md).

The original outer record remains retained. Its provider admission, the embedded source claims, and the local import decision are separate facts. Imported records have `subscribed_source` provenance, **no local_authorship**, and no invented peer authorization receipt for their local materialization. Source-disclosure eligibility still requires real local-authorship provenance, so import does not enable re-export through source subscriptions.

## V17 recipient policy

```text
NATRAV_OVERLAY_CONFIG_V17
local_control=1000,SOURCE_IMPORT
source_view=temperature,1000,A,a-g1,2000,observations/temperature,received/temperature,1000,1000000
source_view_binding=temperature,temperature-c-g1,INSTANCE_HEX64,GRANT_DIGEST_HEX64,-
```

The nine `source_view` fields are ID, manager UID, provider node, exact provider key generation, claimed source-author UID, exact source scope, distinct target scope, maximum retained records and maximum retained raw payload bytes.

The five binding fields are view ID, provider grant ID, exact subscription instance, exact provider-grant digest and either `-` for NSE1 or an exact lineage digest for NSE2. The latter is:

```text
SHA-256("NATRAV_OVERLAY_SOURCE_VIEW_LINEAGE_V1" || 0x00 || exact NSE2 succession suffix)
```

`source-envelope-inspect` now reports this digest alongside its existing structurally decoded fields. It remains `STRUCTURAL_ONLY`. Copying values out of an untrusted file does not make them approved values; acceptance of the complete recipient configuration is the local trust decision.

V17 permits at most 32 views and 256 exact bindings, across accepted history. Each view needs at least one binding. Each SOURCE_IMPORT principal needs a view; every view manager needs SOURCE_IMPORT. A binding is unique per view/grant. Rules and bindings are sorted and hashed canonically. Their identifiers cannot be repurposed or their budgets enlarged through later configuration. New grant/instance lineage needs a separately accepted binding.

Record limits are 1..65,536; raw-byte limits are 1..67,108,864. The normal million-inbound-record and journal limits still apply. Historical reservations and cumulative use survive correction, removal/readdition of policy, compaction, restart and restore. There is no reclamation or automatic allowance renewal.

An exact provider key generation must exist. New imports require that both the historical admission key and the current import key are nonrevoked and have the same SPKI. A retired key may support deliberate historical import. There is no silent key-generation migration.

Source and target must be distinct non-action scopes. Target domains `(provider, target scope)` are unique across retained view history and cannot also be another view's envelope-source domain. Activating a rule over existing ordinary target records is refused. Once reserved, ordinary peer admission into that target is refused even after policy removal. This prevents a permitted network sender from impersonating derived records in the view domain.

## Read permission is separate

The import manager does not automatically acquire evidence-read classes. The result contains bounded import/provenance metadata, not payload bytes. Readers require their existing exact grants, for example:

```text
local_control=1001,EVIDENCE_READ,EVIDENCE_PAYLOAD,CONSUMER,PROJECTION
# Provider identity stays A; the materialized scope is distinct.
evidence_read=1001,A,received/temperature,PAYLOAD
```

Metadata-only readers cannot retrieve embedded bytes. They need no permission for the raw envelope scope to read an authorized target. Numeric processing additionally requires payload authority. ALL, INSPECT, authorship, source disclosure and ordinary SUBMIT do not imply SOURCE_IMPORT or read authority.

## Command and response

```sh
./node/bin/natrav-overlay source-view-import \
  --control state-c/control.sock \
  --view temperature \
  --operation EXACT_OUTER_OPERATION_HEX64
```

The local NOC1 request kind is 21 and its strict payload starts NVI1. Actual SO_PEERCRED is checked before reading, and accepted current V17 policy is rechecked after decoding. The generation lease and journal mutex make import validation/admission consistent with concurrent policy publication. Quiesce/drain deny this mutation. The response is `NATRAV_OVERLAY_SOURCE_IMPORT_RESULT_V1` with IMPORTED or ALREADY_IMPORTED, materialized operation/digest/scope, `network_used:false`, and subscribed provenance.

## Validation sequence

1. Locate the exact stored outer operation. Require a peer authorization account, no local authorship and no earlier import marker. Match provider, source scope, recipient and admitted key generation.
2. Locate its exact runtime-bound kind-11 accepted admission event. Re-evaluate historical peer authorization and compare policy/rule digests. Resolve historical and current provider keys.
3. Strictly parse NSE1/NSE2, ordinary embedded record, bounds and EOF. Verify source record digest, provider-local source issuer/recipient, expected source author/scope, local subscriber identity generation/SPKI, outer operation hash and outer mapped-parent field.
4. Require the exact accepted view/grant/instance/grant-digest/lineage-digest binding. The provider grant digest pins its finite policy/lease commitment; this implementation does not independently reconstruct the provider's grant configuration or check a current provider lease clock.
5. Derive the target operation and correction parent. Require the imported parent to be the exact source predecessor and exact acknowledged outer mapping declared by the envelope.
6. Check cumulative view count/bytes, unique subscription ordinal, current correction head, overall state bounds; append one synchronized materialized record plus provenance.

Parsing alone is not authority. Even a well-formed self-issuer record inserted through the legacy path is not eligible. Malformed or denied envelopes remain ordinary stored evidence; import never deletes them.

## Identity, correction and replay

The materialized operation is:

```text
SHA-256("NATRAV_OVERLAY_SOURCE_VIEW_OPERATION_V1" || 0x00
        || immutable view-rule digest || original source operation ID)
```

Its issuer is the authenticated provider, recipient the local node, scope the reserved target, and payload the original bytes. The optional correction points to the similarly derived parent. Independent originals remain plural. Parent import must precede correction import. The optional bounded import worker can defer a missing parent; an existing mismatched parent is rejected as SOURCE_VIEW_PARENT_BINDING_REJECTED.

The same outer record under current matching authority returns ALREADY_IMPORTED and does not append another successful event or consume capacity. Another outer record trying to alias an already imported source is a conflict, not a silently merged subscription. A reused subscription ordinal is also rejected. Existing completed imports are not removed by provider revocation or import-rule removal; separate current read policy controls access to them.

NSE2 can continue the same view across leases when its exact new binding is accepted. Its source correction must still refer to the previously imported recipient mapping. A lineage digest is a pinned provider commitment, not proof that the provider's predecessor had no other effects.

## Durability and provenance

Journal kind 33 contains NSV1 plus the ordinary materialized record. The NSV1 account records local importer UID/GID/PID/time/configuration; outer provider operation/digest/admission-event/key; embedded source ID/digest/parent, **claimed** author UID/time, source scope; and grant, subscription instance, ordinal and optional lineage digest.

The two distinct records and both accepted configurations remain available. Journal replay and checkpoint loading derive expected materialization/provenance again and reject impossible results even when an ordinary checksum was recomputed. The checkpoint inbound marker is 3. Older executables reject unknown state; unaffected existing record encodings remain unchanged. The authenticated-journal verifier recognizes kind 33 before semantic replay. No migration command is needed before the first import.

Source-derived usage/indexes reconstruct under restart, compaction, authenticated audit, signed encrypted backup/restore and explicit relocation. Old identity paths are not reopened for historical validation; active identity remains normally checked. Restoring an old complete valid snapshot can restore older imports and capacity use. No freshness authority is added.

## Bounds and limitations

An import decodes at most one ordinary 60,000-byte envelope and retains an additional copy of its embedded payload. Both raw and derived records count toward storage. Views use ordinary proportional-memory indexes, not a constant-memory database. Historical configuration/admission lookup and reconstruction can be substantial; no timing or hostile shared-resource isolation is promised.

Automatic imports require a separate finite recipient grant; they are never implicit. No remote view query, provider pin discovery, lineage alias merge, source-key migration, record deletion, retention-window cleanup or third-party proof system is present. Existing query/feed cursor restart and read-policy rules remain intact. Reserved-domain network errors use the ordinary peer error/retry machinery.

Provider authentication proves the connection key and retained admission, not physical authorship, author consent, evidence truth, completeness or freshness. Provider-local UIDs and authored timestamps are labeled claims, not portable kernel credentials. Raw NSV1 provenance and query metadata may disclose those claims to authorized metadata readers. Live files are not encrypted; host compromise and full valid rollback remain outside this boundary.

See [test scope](TESTING.md), [validation](../validation/VALIDATION.json) and [next construction](BUILD-PLAN.md).

## Automatic provenance compatibility

Manual imports retain NSV1. Automated imports use NSV2, retaining the delegating manager, actual daemon actor and exact scheduling revision. Their kind-34 decision, effect and allowance are one transaction; a standalone kind-33 automatic admission is rejected. See [automation durability](AUTOMATIC-IMPORTS.md).

## Revision 0528 administrative review

[Import decision review and selective retry](IMPORT-DECISIONS.md) add bounded administrative pages and an exact one-source reconsideration command under existing V17 SOURCE_IMPORT authority. New NIR2 requests and NIE2/NSV3 state retain explicit local-manager provenance. Earlier durable encodings remain readable; no new read permission, peer protocol or configuration version is implied.

## Recipient-view terminal lifecycle

[Explicit retirement](VIEW-RETIREMENT.md) now rejects all further direct imports, including old duplicate-import commands, while retaining admitted evidence, read authority and target reservations. Automatic selection and manual reconsideration stop in the same terminal account.


## Revision 0553 binding inspection

The read-only [source-view-bindings API](VIEW-BINDINGS.md) exposes complete current and retained pins for one exact manager-owned view. Current SOURCE_IMPORT is required; no payload permission, import eligibility, provider consent or lease validity is inferred. New first-acceptance indexes are derived through validated replay. Existing configuration and storage representations are unchanged.
