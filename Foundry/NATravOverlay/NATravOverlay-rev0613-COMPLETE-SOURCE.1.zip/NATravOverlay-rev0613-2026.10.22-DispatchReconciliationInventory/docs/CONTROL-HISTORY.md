# Local-control and lifecycle history — revision 0539

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Purpose and authority

`control-history` is a node-wide administrative metadata API over the actual retained local-control decisions and service-lifecycle accounts. It requires the connected kernel UID's current **INSPECT** after bounded decoding, and holds the accepted configuration through selection and response encoding. SUBMIT alone, evidence-read permission, and knowledge of a request ID do not confer inspection. Successful reads do not append journal or successful audit events; denials retain existing audit behavior. Inspection is available while RUNNING, QUIESCED, or DRAINING while the control endpoint remains alive.

The current response principal identifies the inspector. Row principals identify the actors actually stored in the historical account. The Linux [unix(7) SO_PEERCRED contract](https://man7.org/linux/man-pages/man7/unix.7.html) reports credentials at connection time; this revision uses that existing boundary rather than trusting request-supplied UIDs. Lifecycle accounts never stored GID, so lifecycle rows return `gid: null` and `gid_semantics: NOT_RECORDED`. They do not infer it from a neighboring account.

## Command and selections

```sh
./node/bin/natrav-overlay control-history \
  --control state-a/control.sock --section decisions --limit 16 --max-bytes 8192

./node/bin/natrav-overlay control-history \
  --control state-a/control.sock --section lifecycle --ordinal 2

./node/bin/natrav-overlay control-history \
  --control state-a/control.sock --request-id HEX64

./node/bin/natrav-overlay control-history \
  --control state-a/control.sock --uid 65534
```

`--section` is `decisions` (default) or `lifecycle`. `--ordinal` selects an exact one-based ordinal in that section. An optional **single** indexed filter is `--uid`, `--request-id`, or `--event` (accepted configuration-event ordinal). An exact ordinal can be combined conjunctively with that filter, but cannot use nonzero offset. Multiple indexed filters are deliberately rejected rather than requiring an unbounded intersection scan. Missing ordinals/filter keys yield empty selections. UID zero is valid.

Request IDs are **not unique invocation identifiers**. For decoded requests they commit to exact request bytes, not UID, PID or invocation time. Repeated bytes and different principals may therefore share an ID. Pre-decode denials may carry synthetic IDs under the existing producer rules. A drain's started and terminal accounts also share its ID. Lookup returns all matching records in the chosen section. The API never promises a one-to-one decision/effect correlation or invents a global ordering across sections.

## Stable retained-prefix pagination

The first page captures the section's retained count as `through` and returns `prefix_digest`. Continue with:

```sh
./node/bin/natrav-overlay control-history \
  --control state-a/control.sock --section decisions \
  --through COUNT --prefix-digest HEX64 --offset NEXT_OFFSET \
  --limit 16 --max-bytes 8192
```

Repeat the original filter for ordinary continuation. Deliberately changing filters selects another subset of the same committed prefix. Offset is zero-based within that subset. Both `through` and `prefix-digest` are required together (including explicit empty prefix zero); nonzero offset requires them. An offset equal to selected total returns an empty page; excess offsets fail.

Prefixes are content comparisons, not capabilities, authenticated cursors, effect receipts, or mutation preconditions. They have no process-secret expiry. Current authority is rechecked every time, so another currently authorized inspector can compare the same prefix. Later appends and unchanged compaction/restart/restore preserve it. Missing retained history returns `CONTROL_HISTORY_PREFIX_UNAVAILABLE`; different content returns `CONTROL_HISTORY_PREFIX_MISMATCH`. A valid old snapshot still containing the selected prefix may pass. There is no external freshness anchor or claim that later unselected events never existed.

`retained_count_observed` and `active_event_observed` are current observations, while `through` selects a historical section prefix. They can refer to different moments. Each response is one state-mutex observation; successive pages do not freeze the entire application or live counters.

## Rows and redaction

`NATRAV_OVERLAY_CONTROL_HISTORY_V1` includes rows, exact selected total, returned count, next offset, more, prefix and current observations.

Decision rows retain UID/GID/PID, request ID, command, class, stored timestamp, AUTHORIZED or DENIED, typed error, and exact accepted configuration reference. `effect_completed` is **null**: authorization is a permission decision, not proof the mutation completed. An authorized command may subsequently fail semantics or be interrupted. A denial does not prove that no earlier invocation had an effect. Successful observations are intentionally not logged, so their absence is expected. The API is not a complete command-execution or effect ledger.

Lifecycle rows retain QUIESCED, RESUMED, DRAIN_STARTED, DRAIN_COMPLETED, DRAIN_DEADLINE, or SHUTDOWN_REQUESTED, actual stored UID/PID/request ID, time, configured drain duration, recorded pending counts, and configuration provenance. Reason text is omitted; its exact byte length and domain-separated digest are returned. A shutdown-request record is not a proof that shutdown completed. Drain completion/deadline are actual recorded lifecycle outcomes, not invented correlations.

Rows bind their referred configuration's canonical digest and exact history prefix. Historical canonical contents and owner/identity paths are not parsed or copied into this response. No application payload or request bytes are exposed. Stored command/class labels, numeric principals, times, counts, request commitments, generations, and reason digests remain sensitive administrative metadata. Hashes do not conceal low-entropy input from guessing. Configuration event labels do not substitute for historical principal records.

Coverage begins with the durable V8 local-principal policy. V6/V7 process-local accounts are not retroactively fabricated. The sections have separate ordinal spaces and do not include all domain-specific receipts, actions, remote actors, offline administration, or runtime-bound mutations. Use the corresponding APIs for those records. A matching request ID alone is not sufficient evidence to join accounts into an exactly-once external effect.

## Bounds and costs

Limits are 1–64 rows, 2,048–60,000 complete annotated JSON bytes, and the existing one-million retained-record ceiling **per section**. Nonfitting rows are never skipped or partially emitted: a later one ends the page; a first one gives `CONTROL_HISTORY_PAGE_TOO_SMALL`. Deadline failure returns `CONTROL_HISTORY_DEADLINE` without partial success; scheduling or transport delays can still prevent any reply reaching the client.

Exact ordinal lookup is indexed. Request-ID, UID and configuration-event indexes retain ordered ordinal lists, supporting binary prefix-bound searches and exact selected totals. At most the requested rows plus one nonfitting row are visited. Empty filters/prefixes visit zero records. The method holds the state mutex for selection and rendering; it is not wait-free.

The index retains a 32-byte prefix and three 32-bit ordinal contributions per record, plus maps, key storage, vector capacity and allocator overhead. These contents alone are about 42 MiB per million-record section; many unique request IDs add substantial overhead beyond that. Both sections can grow independently. The large fixture adds 8,192 synthetic decisions and 1,024 synthetic lifecycle records to one real shutdown decision and one real shutdown lifecycle account: 8,193 and 1,025 enumerated rows. It does not approach the maximum million-record limits. No history is deleted or reclaimed by this increment.

`work.scope` is `LOCKED_CONTROL_HISTORY_PAGE`. `rows_visited` counts rendered/considered historical rows. `ordinal_search_comparisons` counts vector binary-search comparisons, not ordered-map lookup comparisons. `prefix_reads` counts the selected `through` lookup, not all cached references used in rows. Zero canonical/application-payload reads and snapshots apply to this method, not startup, config authorization/canonicalization, journal replay, source parsing, transport, other threads, or all allocations.

## Derived commitment format

Let `H(domain, data) = SHA256(ASCII(domain) || 00 || data)`. Integer encodings are unsigned big-endian; text16 prefixes its UTF-8/ASCII bytes with a 16-bit byte count. The exact existing event encoders remain unchanged.

```
section = 1 (decisions) or 2 (lifecycle)
seed = H(NATRAV_OVERLAY_CONTROL_HISTORY_SEED_V1, text16(node) || u8(section))
item = H(NATRAV_OVERLAY_CONTROL_DECISION_ITEM_V1 or NATRAV_OVERLAY_LIFECYCLE_ITEM_V1,
         referred_configuration_history_prefix[32] || exact_existing_event_payload)
prefix[i] = H(NATRAV_OVERLAY_CONTROL_HISTORY_LINK_V1,
              prefix[i-1][32] || u64(i) || item[32])
prefix[0] = seed
```

Local decisions retain the existing payload: request digest; u32 UID/GID/PID; text16 command/class; u64 configuration event/time; u8 decision; text16 error. Lifecycle payloads retain u8 kind; request digest; u32 UID/PID; u64 configuration event/time; u32 drain deadline; u64 pending outbox/actions; text16 reason. Tests independently hash these bytes from real journal records, not rows copied back into the same implementation.

The normal semantic decoder updates derived indexes only after accepting records, at both append and checkpoint-load boundaries. No new journal kind, checkpoint field, storage schema, or logical-state encoding is introduced. State authentication and backup signatures remain separate protections. Replacing historical configuration attribution while retaining identical canonical settings changes referenced account prefixes too.

## Local wire boundary

New local control kind **28** carries `NHA1`: magic, u8 section, optional-u64 ordinal, optional-u64 UID (validated against uint32), optional-digest request ID, optional-u64 configuration event, u64 offset, u32 limit, u32 maximum bytes, optional-u64 through, and its mandatory digest when present. Optional flags must be exactly 0/1; strict EOF applies. Unknown kinds are rejected by old binaries. Peer formats, permission classes and configuration versions are unchanged.

## Tests and related contracts

Eight integrated cases cover actual allowed/denied accounts and independently reconstructed hashes; request-ID multiplicity and failed effects after authorization; strict independent NHA1 encoding; page/byte/prefix bounds; real UIDs and partial-request revocation; actual drain started/deadline records; concurrent appends and checkpoint/hard restart; authenticated audit, encrypted signed restore and relocation after obsolete key removal; complete large synthetic enumeration and indexed filters; altered referenced configuration provenance; and explicit absence of legacy ephemeral history. Synthetic accounts are labeled and never claimed to represent thousands of real clients or lifecycle incidents.

See [configuration history](CONFIGURATION-HISTORY.md), [local administration](LOCAL-ADMINISTRATION.md), [control authorization](CONTROL-AUTHORIZATION.md), [storage](STORAGE.md), [testing](TESTING.md), and [actual validation](../validation/VALIDATION.json).

## Correlated stop selection (0568)

NOC1 kinds 44/45 bind a canonical caller token into the existing request identity without storing the token text. The operator can independently derive the 32-byte request ID from the documented exact wire bytes and pass it to `--request-id`. Immediate shutdown selects `SHUTDOWN_REQUESTED`; a drain selects `DRAIN_STARTED` plus `DRAIN_COMPLETED` or `DRAIN_DEADLINE`.

Revision 0569 kinds 46/47 use the same identity discipline for deferred terminal-head requests. Their lifecycle rows have the same selection behavior; the final authenticated head remains a separate response/offline-state fact and is not copied into lifecycle history. Duplicate exact terminal requests remain multiple rows under one request ID.

Request IDs remain non-unique invocation identifiers. Reusing identical correlated request bytes produces multiple rows under one ID; the exact indexed query reports all selected rows within its ordinary pagination and response bounds. See [correlated stopping](CORRELATED-STOPPING.md).

## Offline exact-request selection (0570)

`correlated-stop-audit` reuses the replay-derived `by_request` indexes and retained prefix commitments after complete keyed authentication and semantic replay. It selects all matching control-decision and lifecycle ordinals for one exact request ID. The command can derive that ID from an explicit correlated kind-44/45/46/47 request shape through the normal strict encoder, or accept the digest directly.

Unlike online paginated history, the offline report is all-or-fail within explicit limits: no matching row is silently skipped, and duplicates remain visible. It includes the current replay-derived pending obligations and exact current authenticated head, while omitting payloads and free-text reasons. The request ID remains a selector, not permission, idempotency, response-receipt proof, recovery authority, or freshness. [Contract](OFFLINE-CORRELATED-STOP-AUDIT.md).
