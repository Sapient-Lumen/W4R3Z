# Owner-scoped result-review history — revision 0548

`action-result-review-history` locates retained review IDs and historical conclusions from an original request, expected provider and exact result scope. It does not re-evaluate a report, acknowledge an action, create a review, consume review capacity, or confer authority for another effect. The ordinary [review](RESULT-REVIEWS.md) and [discovery](RESULT-DISCOVERY.md) contracts remain distinct.

## Commands and current authority

```sh
./node/bin/natrav-overlay action-result-review-history \
  --control state-a/control.sock --request ACTION_HEX64 \
  --provider B --scope results/counter --limit 8 --max-bytes 32768

./node/bin/natrav-overlay action-result-review-history \
  --control state-a/control.sock --request ACTION_HEX64 \
  --provider B --scope results/counter --review REVIEW_HEX64
```

The request/provider/scope triple is required. Optional `--review` is an exact additional conjunctive filter, not a way to inspect a review from another owner or domain. A missing review and a hidden review both return an empty selection. The complete candidate rows and a current-state comparison remain available through `action-result-review-status --review HEX64`.

The daemon obtains the caller's real Unix peer credentials. Current INSPECT, EVIDENCE_READ and EVIDENCE_PAYLOAD, including payload permission for the exact provider/scope, are required after decoding. The generation guard is retained through authority checking and page construction. MAINTENANCE is not required to list an existing review; it remains required to create one. No ALL or INSPECT shortcut implies payload access. Domain authorization is checked before registry lookup, even when there are no reviews.

Reviews belong to their creating kernel UID. Counts, ordinals, roots and rows describe only that UID's exact selection. An unrelated owner's review does not create a gap or invalidate the selected prefix. Source record IDs and request IDs are not identity credentials. Offline file ownership and host-compromise boundaries remain unchanged.

## Retained-prefix pages

The first response returns `through`, `prefix_digest`, `next_offset`, `has_more`, and the current `retained_selected_total`. Continue by repeating the exact domain and optional review filter with:

```text
--offset NEXT_OFFSET --through THROUGH --prefix-digest PREFIX_HEX64
```

`through` and the prefix must be supplied together; nonzero offset requires them. Offset cannot exceed the selected through count. Row count (1–16) and total JSON budget (2,048–60,000 bytes) may change between pages. Defaults are eight rows and 32,768 bytes.

Ordinals are one-based positions within the owned exact selection, explicitly `OWNED_EXACT_SELECTION_ORDINAL`. They are not global journal positions. An exact-ID selection therefore has zero or one row and, when present, ordinal one. Rows remain in original review-commit order, not lexical ID or timestamp order.

New reviews can append without changing an earlier prefix. Another request, scope or owner does not affect that prefix. A changed accepted configuration requires current authorization but does not by itself change a stored-history root. Same history survives compaction, restart, authenticated restore and relocation. A requested prefix absent from the retained state returns RESULT_REVIEW_HISTORY_PREFIX_UNAVAILABLE. Different content or selectors return RESULT_REVIEW_HISTORY_PREFIX_MISMATCH. A saved zero-length prefix remains a valid empty historical selection after later appends; the separately observed current selected count can be larger.

The prefix is a content commitment, not a secret bearer token, permission grant, freshness authority, global sequence counter, or mutation condition. A valid older state still containing the prefix may match it. Changed owner/selector fields cannot reuse it. No retention lease, durable cursor key, expiry clock or snapshot object is allocated.

## Historical rows, not a changing verdict

Rows contain the exact review ID and SHA-256 of the complete validated NRR1 record, original request/provider/scope, recorded UID/GID/PID and time, accepted configuration event and digest, reason length and SHA-256, original key generation/SPKI and receipt-presence flag, candidate count/root, request binding, source-derived conclusion/counts, and unique report ID only when the stored result was unique.

Reason text, candidate-report payloads, per-candidate arrays, canonical configurations and obsolete identity paths are omitted. The record digest commits all those original stored fields, not only the displayed summary. Reasons and low-entropy values may still be guessable from commitments; redaction is not encryption. Returned actor IDs, scope names and timestamps remain sensitive administrative metadata. The current inspector annotation is separate from each historical actor.

Rows explicitly use `STORED_ONLY_USE_REVIEW_STATUS`. No CURRENT_SELECTION classification is computed while listing. New conflicting candidates, late original receipts, key rebinding or current configuration changes never rewrite rows or their roots. The separate exact-status command can mark the same account HISTORICAL using current facts. Listing a unique historical report does not reassert present uniqueness. All replies retain `execution_verified_locally: false` and `freshness: NOT_ESTABLISHED`.

## Work and bounds

A derived map keyed by UID/provider/scope/original request holds indices and cached summaries of validated review records. Prefix links, complete-record digests, reason digests, consistent counts and the optional unique identity are computed only after full semantic admission or checkpoint replay. This derivative never serializes into logical state and is not a second trusted storage authority.

Ordinary page selection performs one group lookup and visits at most the row limit plus one nonfitting row. Exact-ID filtering compares at most the 16 retained group IDs. No other owner's registry is scanned. A page does not parse historical configurations, revalidate candidates, encode NRR1 records, copy payloads or compute the application's logical state. The response contains counters scoped to the locked page method; they exclude current configuration processing, transport, tree comparisons, startup and other threads. Whole-state snapshot instrumentation remains active within that scope.

The complete response, including conservative space for kernel-principal annotation, must fit the caller's limit. Nonfitting rows are never split or skipped. A nonfitting first row yields RESULT_REVIEW_HISTORY_PAGE_TOO_SMALL; otherwise continuation resumes at the unconsumed row. An empty page visits no review row. Current configuration protection and one state mutex cover each page; these are bounded operations, not wait-free or allocation-free ones.

The underlying review registry remains 128 globally and 16 per UID, unreclaimed. Index memory is proportional to those retained reviews. It keeps indices/commitments/counts, not copies of candidate vectors. Startup/checkpoint replay still validates the original reports and can be expensive. Listing does not refund capacity or create new interpretations.

## Wire and compatibility

Local control kind 35 carries `RRH1`:

```text
magic[4]
original request digest[32]
provider: BE16 length + ASCII
scope: BE16 length + ASCII
optional exact review: U8 0/1, then digest[32] when present
offset: BE64
limit: BE32
max response bytes: BE32
optional prefix: U8 0/1, then through BE64 + digest[32] when present
exact EOF
```

Empty provider/scope, zero request/exact-review identities, unsupported magic, nonboolean flags, truncated or trailing bytes and invalid numeric bounds fail strict validation. Existing request encodings, peer protocols, journal kind 38, NRR1/NRV1 and storage schema remain unchanged. Old daemons reject the new local kind; they do not reinterpret it as a mutation.

The empty prefix is SHA-256 of `NATRAV_OVERLAY_RESULT_REVIEW_HISTORY_SEED_V1`, zero delimiter, BE16+node bytes, BE32 owner UID, original-request digest, BE16+provider bytes, BE16+scope bytes, and optional exact-review flag/digest. Each link is SHA-256 of `NATRAV_OVERLAY_RESULT_REVIEW_HISTORY_LINK_V1`, zero delimiter, preceding digest, BE64 selected ordinal, review ID and SHA-256 of the complete validated NRR1 bytes. Changing page size or byte budget does not change the root.

## Validation and limits

[Current validation](../validation/VALIDATION.json) labels completed final-code profiles; [attempts](../validation/ATTEMPTS.md) records failures separately. Independent Python checks wire encoding, raw journal-record hashes, prefix roots and stored summary fields. Controlled C++ nodes exercise real request/result admissions, lost-response lookup, complete owner capacity, concurrent review commits, UID isolation, live revocation, quiesce/drain, keyed audit, compaction, signed encrypted restore, relocation and obsolete key-path removal.

The negative control removes only exact prefix equality. Accepting a false caller expectation must be detected. No weakened executable is shipped. Controlled one-kernel experiments do not establish independent-host failure domains, universal physical power-loss durability, evidence truth, newest-state proof or split-brain prevention.
