# Encrypted backup contract — revision 0504

**Current extension (0564):** [External state expectations](EXTERNAL-STATE-EXPECTATIONS.md) add an optional exact, separately supplied input-head condition. Historical statements below about intrinsic authentication freshness remain true: no managed latest-head anchor exists, and an old expectation paired with its old valid state still matches.

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Scope and independent properties

The existing native backup export, verification, and restore commands now support an optional authenticated-encryption envelope. Product execution remains C++20 with OpenSSL; no shell, Python, external key service, or NATrav binary participates in encryption or restore.

`NOBENC01` encrypts **the entire existing `NOBACK01` file**, including sensitive manifest fields, node and identity names, checkpoint, certificate, and optional Ed25519 signature. Inner checksums, backup ID, signature, and canonical state replay remain independently mandatory where applicable.

An encrypted unsigned backup authenticates possession of its symmetric encryption key, not a distinct signer. Anyone possessing that key can construct another unsigned encrypted backup. A signature verified against an explicitly supplied trusted certificate is a separate signer binding. Neither property proves that an unkeyed source journal had not been replaced before export. Result `state_authentication` is `UNKEYED` for legacy checkpoints or `HMAC_SHA256_CHAIN_V1` after explicit state migration and keyed verification. Neither is inferred from encryption alone.

Legacy exports remain plaintext unless `--encrypt-key` is supplied. This revision does not encrypt live node files or retroactively encrypt old archives.

## Key creation and custody

```sh
mkdir -m 700 private-backup-keys
./node/bin/natrav-overlay backup-key-init \
  --output private-backup-keys/archive-g1.key --generation archive-g1
```

The command generates 32 random secret bytes using checked OpenSSL `RAND_priv_bytes`. A generation is 1–64 bytes using the existing strict generation grammar. Output contains generation, non-secret key ID, 256-bit size, and purpose `BACKUP_ENCRYPTION`; it contains no raw key, passphrase, or PEM.

Key files use exact mode `0600`, one hard link, effective-user ownership, and a bounded binary format. Reads use nonblocking no-follow descriptors and reject nonregular files before reading, including FIFOs. Parent traversal is descriptor-relative with `O_DIRECTORY|O_NOFOLLOW`; the final parent must be effective-user-owned and not writable by group/others. Dot-dot and unsafe filenames are rejected. Creation synchronizes a randomly named sibling, publishes with `renameat2(RENAME_NOREPLACE)`, and synchronizes the parent. No existing destination is replaced.

There is no password interface or password KDF. This format is for a generated high-entropy secret. Store key material separately from distributed archives and preserve the exact old key while old archives are needed. Loss of the key means the encrypted archive cannot be recovered by this tool. Re-encryption does not destroy other copies or make a compromised old key harmless.

A killed initializer may leave an owner-only unpublished `.natrav-backup-key-*.tmp` secret candidate. Its name is not an accepted key destination; inspect and remove that candidate under exclusive administrative control. No automatic deletion of unknown files occurs.

### Key file format

All integers are unsigned big endian. Exact EOF is required.

| Field | Bytes |
|---|---:|
| ASCII `NOBKEY01` | 8 |
| Version `1` | 4 |
| Generation byte length | 2 |
| Generation | 1–64 |
| Random master key | 32 |

Total size is 47–110 bytes. The non-secret key ID is SHA-256 of the ASCII domain `NATRAV_OVERLAY_BACKUP_KEY_ID_V1`, the two-byte generation length, generation bytes, and master key bytes. Generation labels are not a globally managed registry; the key ID binds the actual high-entropy material as well as its label.

## Export, verify, and restore

```sh
./node/bin/natrav-overlay backup-export \
  --state state-a --node A --generation a-g1 --output backups/a.nob \
  --encrypt-key private-backup-keys/archive-g1.key \
  --sign-key private/node-a-g1/key.pem --sign-cert private/node-a-g1/cert.pem

./node/bin/natrav-overlay backup-verify \
  --input backups/a.nob --node A --generation a-g1 \
  --decrypt-key private-backup-keys/archive-g1.key --require-encryption yes \
  --trusted-cert private/node-a-g1/cert.pem --require-signature yes

./node/bin/natrav-overlay backup-restore \
  --input backups/a.nob --destination restored-a --node A --generation a-g1 \
  --decrypt-key private-backup-keys/archive-g1.key --require-encryption yes \
  --trusted-cert private/node-a-g1/cert.pem --require-signature yes
```

The parent directories must already exist and satisfy normal backup ownership/path checks. Export acquires exclusive state ownership; it is an offline operation. Restore never overwrites a destination. Existing V7/V8 owner paths remain authoritative; making a restored copy operational elsewhere still requires [explicit relocation](CONFIGURATION.md).

Encrypted input without `--decrypt-key` fails with `BACKUP_DECRYPTION_KEY_REQUIRED`. Supplying a decryption key, or `--require-encryption yes`, rejects plaintext as `BACKUP_ENCRYPTION_REQUIRED`. Unknown versions/suites, nonzero flags, extra bytes, impossible lengths, mismatched generation/ID, wrong key, altered salt/nonce/header/ciphertext/tag, and invalid inner state fail closed. A failed encrypted decode never retries the bytes as a plaintext format.

Export self-checks the encrypted candidate bytes before writing them. The sibling file contains ciphertext, not the inner plaintext backup. Authentication must succeed before decrypted bytes enter the backup parser. Normal checkpoint validation then occurs in memory through `NodeState::validate_checkpoint_image`; it creates no temporary plaintext validation tree. It accepts exactly one complete checksum-valid checkpoint frame and invokes the same canonical checkpoint loader used by ordinary journal reconstruction. It does not apply incomplete-tail recovery to imports.

Successful restore deliberately writes ordinary owner-restricted plaintext state into its staging directory. It is not encrypted local storage. Crashed restore staging may contain verified plaintext; this is the same intentional materialization boundary as an unencrypted restore.

## Envelope format and primitive contract

The fixed header is 106 bytes plus the generation length; all integers are unsigned big endian. No field has an implicit host-endian representation.

| Field | Bytes |
|---|---:|
| ASCII `NOBENC01` | 8 |
| Envelope version `1` | 4 |
| Suite `1`: AES-256-GCM / HKDF-SHA-256 | 4 |
| Flags `0` | 4 |
| Key generation length | 2 |
| Key generation | 1–64 |
| Non-secret key ID | 32 |
| Fresh random salt | 32 |
| Fresh random nonce | 12 |
| Ciphertext/inner-backup byte count | 8 |
| Ciphertext | Declared count |
| Authentication tag | 16 |

The per-archive 32-byte key is HKDF-SHA-256 in extract-and-expand mode: input key material is the generated master key; salt is the header's random salt; info is ASCII `NATRAV_OVERLAY_BACKUP_AES256GCM_HKDF_V1` followed immediately by the complete encoded header. The AES-256-GCM nonce is the 12-byte header nonce. Additional authenticated data is the complete header. The tag is always 16 bytes. All randomness and EVP return codes are checked. The implementation uses OpenSSL's fetched AES-256-GCM and HKDF providers, not a home-written cipher, MAC, or KDF.

Only the format, suite, encryption-generation label, non-secret key ID, random fields, and inner byte count are public. Length and repeated use of a key ID are observable; there is no padding or traffic-analysis claim. Do not put sensitive information in public generation labels.

Input is bounded by the configured maximum journal size (1 KiB–1 GiB), a 2 MiB inner-format allowance, and at most 256 bytes of envelope allowance. This is an in-memory implementation, not streaming; decoding/checkpoint reconstruction can require multiple copies and substantially more memory than the file size. Exact vector/key buffers are cleansed where owned by the crypto boundary, but the whole process is not locked against swapping or core dumps. Host compromise and memory-remanence resistance are not claimed.

## Re-encryption without resigning

```sh
./node/bin/natrav-overlay backup-key-init \
  --output private-backup-keys/archive-g2.key --generation archive-g2
./node/bin/natrav-overlay backup-reencrypt \
  --input backups/a.nob --output backups/a-g2.nob \
  --decrypt-key private-backup-keys/archive-g1.key \
  --encrypt-key private-backup-keys/archive-g2.key \
  --node A --generation a-g1 \
  --trusted-cert private/node-a-g1/cert.pem --require-signature yes
```

The source must already be encrypted. It is completely authenticated, signature-checked under requested policy, and semantically decoded before rewrapping. A different generation and key are required. Inner bytes, backup ID, original signature, and checkpoint identity remain unchanged. Fresh salt/nonce and the new key protect the new envelope. The source archive and all key files remain unchanged. No signing private key is needed. Publication remains no-overwrite.

This is an explicit archive transformation, not a state-authentication-key rotation, a key-retirement registry, or a revocation protocol. A retained old archive still opens with its retained old key. `previous_encryption_key_generation` in the response is an account of this invocation; it is not a new event inserted into the signed original backup.

## Verification output

Existing `NATRAV_OVERLAY_BACKUP_V1` JSON gains additive fields: `encrypted`, `encryption_authenticated`, `encryption_suite`, `encryption_key_generation`, `encryption_key_id`, `previous_encryption_key_generation`, `inner_file_bytes`, and `state_authentication`. `file_bytes` is the actual outer file size; `inner_file_bytes` is the decrypted `NOBACK01` size. `signed`, `signature_valid`, and `trusted_signer` retain their distinct meanings.

Do not infer freshness from successful verification: a previously valid entire backup remains valid. Neither an unkeyed digest nor an AEAD tag alone establishes that the backup is the latest state. Split-brain prevention is unchanged.

## Primary implementation references

The checked OpenSSL APIs document authenticated-finalization requirements, fetched cipher/parameter APIs, HKDF extract-and-expand inputs, and mandatory randomness error checking. The public documentation was consulted on October 4, 2026; the measured installed library version is retained in `validation/ENVIRONMENT.json`.

```text
https://docs.openssl.org/3.0/man3/EVP_EncryptInit/
https://docs.openssl.org/3.0/man7/EVP_KDF-HKDF/
https://docs.openssl.org/3.0/man3/RAND_bytes/
```

## Authenticated journal checkpoints

For state migrated with `state-auth-migrate`, add `--state-auth-key FILE` to each export, verify, restore or re-encrypt command above. The separate backup-encryption key does not unlock or replace the state-authentication key. Supplying a state key requires an authenticated checkpoint and rejects unkeyed input; an authenticated checkpoint without its state key fails even when signature and encryption checks succeed.

The manifest checkpoint digest binds the full keyed checkpoint, including root, epoch, generation and transition history; its backup ID/signature inherit that binding. Verification authenticates the complete checkpoint before normal semantic reconstruction. Restore preserves the keyed representation and appends restore provenance with the state key. Node files remain plaintext, now with keyed integrity. A newly launched restored daemon and offline relocation need the state key again.

Backup results include an additive `state_authentication_account` describing the verified root, generation, epoch and history where present. Successful encryption authentication or signer verification is not journal-authentication evidence without that separate check.

`backup-reencrypt` preserves the original state-key generation inside the unchanged inner backup. Use the state key that authenticated that archive, not necessarily the latest live key. To export a new state-key epoch, rotate the state explicitly and create a new export. See [State authentication](STATE-AUTHENTICATION.md), [Testing](TESTING.md), and [Build plan](BUILD-PLAN.md).

## Authenticated recovery continuation

Revision 0504 recovery history is protected by the NOAUTH01 version-2 header. Existing keyed signed/encrypted export, verification, re-encryption, restore and relocation preserve that extension without dropping its source/root/key bindings. Recovery evidence itself is a separate owner-only plaintext source copy, not an encrypted backup. See [Authenticated recovery](AUTHENTICATED-RECOVERY.md).
