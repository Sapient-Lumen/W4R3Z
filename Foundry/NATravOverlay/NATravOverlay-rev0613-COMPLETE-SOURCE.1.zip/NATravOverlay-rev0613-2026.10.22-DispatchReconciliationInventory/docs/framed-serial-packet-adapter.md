# Framed serial packet adapter — revision 0599

`FRAMED_SERIAL_PACKET_ADAPTER_V1` is a supervised role of the existing
`node/bin/natrav-overlay` ELF, not a second product binary. Pin that exact ELF
with the existing immutable V19 adapter profile. Its argv selects
`serial-packet-adapter`; the same executable's ordinary `run` role retains
identity, TLS, authorization, journal, retries, operations and receipts.

## Explicit invocation and policy

The complete argv, including every bound below, belongs in the operator-pinned
profile. The inherited descriptor-3 Unix `SOCK_SEQPACKET` endpoint and
`NATRAV_ADAPTER_PROTOCOL=NAPA0001`/`NATRAV_ADAPTER_FD=3` environment are provided
by the existing supervisor. The command refuses an ordinary terminal or an
unconnected/non-seqpacket descriptor. No configuration or state directory is
opened in this role.

```text
serial-packet-adapter
--serial serial-v1|path=/dev/ttyS0|baud=115200|data=8|parity=none|stop=1|flow=none
--mtu 512
--link 0000000000000001
--epoch 1
--queue-bytes 65536
--queue-frames 64
--frame-timeout-ms 5000
--io-quantum 4096
```

Revision 0599 retains the exact NSP1 bytes and adds an explicit lower bound on
frame lifetime. The profile must allow enough time to serialize one worst-case
escaped frame at the configured baud and character format; an impossible
combination is rejected as `SERIAL_PACKET_TIMEOUT_TOO_SHORT` before TTY
ownership. See [serial model succession](SERIAL-MODEL-SUCCESSION.md).

The arguments above are separate literal argv entries, not a shell command.
The `serial-v1` argument follows the existing canonical percent-encoded path
syntax. Decimal values must have their shortest spelling; link is exactly
sixteen lowercase hexadecimal digits and must be nonzero. Epoch is a nonzero
32-bit unsigned integer. Link and epoch are explicit carrier demultiplexing
coordinates; use the intended values consistently at both serial ends and in
the corresponding endpoint policy. They are **not identity or authority**.

This binary framing requires eight data bits. Seven-bit operation is explicitly
rejected, not silently truncated. Existing supported baud rates, parity,
stop-bit and flow-control selections remain available. All control octets,
including XON and XOFF, are escaped on the wire. An explicit TTY is opened with
component-by-component no-follow traversal, character-device and terminal
validation, an acceptable owner (effective UID or root), no world-write bit,
one link, a crash-released cooperative `flock` lease. Existing direct serial
stream routes retain their predecessor path policy, `TIOCEXCL`, and bytes.
The supervised packet role deliberately does not set or clear `TIOCEXCL`:
local testing showed that the exclusive flag can outlive SIGKILL and prevent
reopening while a PTY master or another holder remains. The descriptor-owned
`flock` is released by the kernel on child death. A noncooperating process can
ignore that advisory lock; OS device permissions and overlay TLS are still
necessary boundaries.

The OS still decides device access. No directory scan, USB-ID matching,
automatic attachment, device discovery, source learning, arbitrary executable
path in route text, transparent forwarding or relay is introduced. Profiles
are authorized through V19; routes continue to use exact
`adapter-endpoint-v1|id=<id>|generation=<u64>` references.

## NSP1 wire format

A physical frame is `0x7e`, canonical escaped content, then `0x7e`. Repeated
empty delimiters are idle boundaries. The unescaped content is:

| Offset | Bytes | Meaning |
|---|---:|---|
| 0 | 4 | Literal ASCII `NSP1` |
| 4 | 8 | Nonzero link identifier, big endian |
| 12 | 4 | Nonzero epoch, big endian |
| 16 | 2 | Nonzero complete-datagram length, big endian |
| 18 | length | Complete datagram; never more than negotiated MTU |
| 18 + length | 4 | CRC-32, big endian, over all preceding unescaped content |

CRC-32 uses reflected polynomial `0xedb88320`, initial value `0xffffffff` and
final complement. The check vector `123456789` yields `cbf43926`. This checksum
is accidental-corruption detection, **not authentication**.

Every byte below `0x20`, plus `0x7d`, `0x7e` and `0x7f`, is emitted as `0x7d`
followed by the byte XOR `0x20`. Other bytes must not be escaped. The decoder
rejects over-escaping, bare protected bytes, dangling escapes, wrong magic,
wrong link/epoch, inconsistent length, oversized frames and checksum failure.
Only a complete valid frame reaches the NAPA receive queue. A physical duplicate
remains a duplicate datagram; the existing finite packet service performs
retransmission, acknowledgement, duplicate suppression and ordered delivery.

This is a **new physical-carrier framing**, not a change to NAPA, NPL1, TLS,
HELLO, NOS1, application operations, receipts, local-control or durable formats.

## Bounds and progress

MTU is 256..4096 bytes. The unescaped decoder retains at most `MTU + 22` bytes;
a worst-case encoded frame occupies at most `2 * (MTU + 22) + 2` bytes. A bad
frame is discarded through the next delimiter without scanning backwards or
retaining arbitrary noise. Resynchronization work is linear in received bytes.

The explicit combined queue is 1024..1,048,576 bytes (and must hold at least
one worst-case encoded frame), with 1..256 total queued transmit/receive
records. Complete transmit backing buffers count until fully written, not
merely their unwritten suffixes. Receive queues retain decoded payloads. Fixed
parser, NAPA, I/O and one encoding scratch buffer are additional bounded memory,
not falsely counted as queue payload. No unbounded event log is kept.

Each event-loop turn attempts at most one short TTY write and one short TTY
read, each capped by `--io-quantum` (1..4096) and a one-millisecond absolute
wait budget, then handles at most one local NAPA request. There is no child
thread or hidden retransmission loop. Short writes resume at their exact
previous offset. The child progresses serial queues independently of the
parent issuing RECEIVE requests, preventing a full-duplex pumping deadlock.

A complete datagram is accepted for transmission only when both queue bounds
permit it; otherwise NAPA returns `BUSY` with no partial admission. A receive
queue at capacity drops the whole newly completed datagram, leaving loss
recovery to the finite packet service. A queued outbound frame that cannot finish by its explicit lifetime terminates
the carrier; it cannot hold resources forever. The configured value remains
bounded to 100..60000 ms, but revision 0599 additionally requires it to be at
least `ceil((2 * (MTU + 22) + 2) * character_bits * 1000 / baud)`. An
incomplete inbound frame has the same bounded lifetime and is discarded before
resynchronizing. Complete receive datagrams remain bounded in the receive queue
until requested or endpoint teardown. Some slow-line/large-MTU combinations
therefore have no admissible value within the 60-second cap and are rejected.

NAPA responses use a zero deadline field. A new child accepts the supervisor's
first nonzero request sequence (which can survive earlier failed launch
attempts) and then requires exact increments. Malformed, repeated/out-of-order,
truncated, oversized, unsupported or noncanonical local requests terminate the
endpoint rather than becoming physical bytes. The exact requested MTU and
finite NAPA capabilities must agree with the child's explicit options.

## Failure and shutdown semantics

`TRANSMIT_RESPONSE/OK` means acceptance into a bounded **local carrier queue**.
It is not a wire-delivery guarantee, an application receipt or custody transfer.
The same remains true if the process dies after that response.

TTY EOF/hangup, unrecoverable I/O failure, malformed local NAPA, transmit expiry,
or local protocol closure ends this carrier. The core must build a new child
and a fresh TLS/HELLO session for subsequent attempts. This child never opens a
replacement device or resurrects a failed encrypted session itself.

Orderly NAPA shutdown acknowledges local endpoint retirement, then discards
remaining carrier queues, restores the observed original termios and releases
the owned TTY. NOS1/TLS/finite-packet close semantics stay above it. SIGKILL,
physical power loss or kernel failure cannot promise user-space restoration.
Inherited/restored line state, DTR/HUPCL effects and exclusive-mode behavior on
real drivers remain explicit verification debt. The `flock` lease is advisory and coordinates participating packet-adapter
instances only. A nonparticipating process, including the unchanged direct
serial carrier, can ignore it. An operator must not assign the same TTY to
unrelated profiles or carriers. A same-UID or privileged hostile
process is not sandboxed by this role or by `TIOCEXCL`/`flock`.

## Verification and operational limits

The executable tests in `node/tests/run_serial_packet_adapter.py` use actual
PTY character devices, actual descriptor-3 NAPA, the pinned same-binary child,
and two complete persistent nodes. They are not a simulated TLS or application
protocol. The fixture supplies bounded replaceable null-modem links and predetermined
loss, corruption, duplication, delay, truncation, noise, and complete-frame
reordering. It replaces an actual route-side PTY under exact authorized profile
and endpoint succession, while an unrelated TCP peer progresses. Full-duplex
session setup, pending obligations, process death, fresh authentication, exact
receipts, whole-datagram queue exhaustion, and node restart are checked above
those links.

PTYs do not establish UART baud clocks, parity-error handling in hardware,
voltage levels, flow-control wiring, USB-UART behavior, EMI, RF range, real
latency, driver reliability, DTR behavior or physical power-loss recovery.
Existing finite-packet and peer deadlines may be too short for a very slow
real line. Select an explicit profile and budget; no automatic baud tuning or
hardware-success claim is made. There is no shame in this missing access and
it is not a construction veto.

## Reference material checked during construction

- Linux man-pages, `termios(3)`: https://man7.org/linux/man-pages/man3/termios.3.html
  (raw input, character width, software flow control and nonblocking semantics).
- Linux man-pages, `TIOCEXCL(2const)`:
  https://man7.org/linux/man-pages/man2/TIOCEXCL.2const.html
  (exclusive mode is bypassable by `CAP_SYS_ADMIN`, not a hostile-process sandbox).
- Linux man-pages, `flock(2)`: https://man7.org/linux/man-pages/man2/flock.2.html
  (advisory open-file-description locks and release on closing all references).
- Linux man-pages, `pty(7)`: https://man7.org/linux/man-pages/man7/pty.7.html
  (the master/slave virtual-terminal model and asynchronous byte flow).

The Open Group's current termios pages returned HTTP 403 during this run;
no content from those unavailable pages is used as evidence.
