# Owner-scoped consumer and projection inventory

Current owner-scoped channel discovery is documented in [publication inventory](PUBLICATION-INVENTORY.md); existing exact and mutating command semantics remain separate.

Revision 0549, October 10, 2026. The persistent C++ runtime adds `consumer-inventory`. This is a current metadata listing, not processing, acknowledgment, a new grant, a retained snapshot, or a mutation precondition.

## Command

```sh
./node/bin/natrav-overlay consumer-inventory \
  --control state-b/control.sock --limit 16 --max-bytes 32768
```

`--kind all|consumer|projection|metadata|numeric` selects plain consumers, either projection type, or one built-in type. `--lifecycle all|active|retired` selects terminality. Optional `--name`, `--instance`, `--issuer`, and `--scope` are exact conjunctive filters. Issuer/scope filters match the **registered filters**, not an expanded evidence collection: a broad consumer with no issuer filter does not match `--issuer A` merely because it can read A. Names are ordered by ASCII byte order within the selected caller-owned inventory. No UID-selection argument is provided.

The response is `NATRAV_OVERLAY_CONSUMER_INVENTORY_V1`. Rows carry owner, name, immutable instance, kind, lifecycle, computation and lifecycle revisions, epoch, acknowledged position/count, pending and last-acknowledged page IDs/bounds, fixed feed limits, latest consumer transition provenance, and a bounded terminal-retirement account. Projections supply their immutable definition digest and admission limit, **not result values, source-operation lists, unit values, or retired result histories**. Pending IDs are not acknowledgment grants. Use existing exact consumer/projection status for complete accounts, and exact projection schedule status for automatic grants. Schedule details are intentionally not part of this inventory. The row field `payload_included` describes the registered consumer's page mode; this inventory never includes payload bytes. Row PID/time fields are the stored last-transition observations, which can describe a daemon executor rather than a currently connected owner client. The inspecting principal is separately annotated at response level.

## Current authority and conservative visibility

V11-or-newer explicit `CONSUMER` and `EVIDENCE_READ` are required after complete request decoding, even for empty selections. `INSPECT`, `ALL`, and `CONSUMER_ADMIN` alone do not imply these permissions. Projected rows additionally require V12 `PROJECTION`. Payload consumers and numeric projections require current payload permission as well as an eligible exact domain. Authorization remains generation-stable through page construction. Successful reads append no journal or successful audit entry and are admitted during quiescence and drain while the control endpoint is alive.

Only the creating kernel UID's map range is visited. Before filters, counts, ordinals, summaries, or commitments are constructed, each entry must have current command/domain authority **and its entire adopted read-authority digest must still equal the caller's effective read authority**. This deliberately conservative rule prevents old broad-consumer positions or page bounds from disclosing previously permitted domains. It can hide even an exact-domain consumer after an unrelated change to that UID's read grants. An existing explicit reset/rebuild can adopt new authority for active work; listing never performs it. Retired names with mismatching authority remain hidden from this read inventory. This is not the existing narrow retirement-administration API.

Other owners' entries and inaccessible consumers introduce no visible counts, ordinal gaps, roots, or hidden-scan counters. An inaccessible exact name/instance has the same absence fields as a missing one. The selection commitment includes the supplied filters, so two different filter strings need not have the same empty digest. Timing and shared-resource contention are not hidden. A configuration change, including an unrelated principal's policy update, changes the accepted configuration context and requires a fresh selection.

## Bounded current pagination

The first page supplies `selection_digest`, `selected_total`, `next_offset`, and `has_more`. Continue with the same filters:

```sh
./node/bin/natrav-overlay consumer-inventory \
  --control state-b/control.sock --offset 16 --selection HEX64 \
  --limit 16 --max-bytes 32768
```

Limits: 1–32 rows and 2,048–60,000 bytes of complete annotated JSON. Page size and byte budget can change between pages. A nonfitting row is never partially returned or silently consumed. If the first row does not fit, `CONSUMER_INVENTORY_PAGE_TOO_SMALL` requires a larger byte allowance. Nonzero offsets require a selection digest.

One state lock protects each page's visible selection and metadata. The digest binds node, kernel UID, accepted configuration, current read authority, exact filters, selected count, and every returned-summary field of the full eligible selection. Changed selected progress, pending-page identity, creation, or retirement causes `CONSUMER_INVENTORY_SELECTION_MISMATCH`. Changes outside the selection, or incoming evidence not yet consumed, do not by themselves change the commitment. A schedule-only change does not imply consumer progress and is not included.

Same-state compaction and restart preserve the selection when configuration and consumer summaries are unchanged. Relocation changes accepted configuration and therefore requires a fresh selection, although consumer identities and progress remain unchanged. A matching old snapshot can still match an old digest: this is neither freshness proof nor irreversible generation token. There is no implicit historical snapshot, lifetime, token registry, or authority in possession of a digest. Current permission is checked every time.

## Work and storage

The existing finite consumer registry permits 16 active plus 64 retired instances per UID. The implementation uses its owner-keyed ordered map to avoid traversing other owners. It inspects at most 80 owned entries, serializes **only authorized selected summaries**, and hashes at most those 80 bounded metadata summaries per request. It does not serialize full consumers, adoptions, projection results or histories; read evidence; build a `StateSnapshot`; or compute the application logical digest. All returned rows and references are copied while locked; no borrowed pointer survives unlocking.

`work` reports selected-summary hashing and output-row visits, never counts of hidden entries. The counter scope is the locked inventory method, excluding configuration processing, authentication, transport and other threads. Zero-evidence/history-read counts describe these explicit paths, not whole-process allocation. A warm page still recomputes bounded selection summaries. This is not a constant-time, allocation-free or lock-free database. No new persisted index or journal format is needed; validated state reconstruction supplies the existing registry.

## Wire and commitments

The local envelope is `NOC1`, kind 36, followed by `CIN1`. In order: u16-length ASCII kind, lifecycle, name, issuer, scope; optional u8-marker/32-byte instance; big-endian u32 offset, row limit and byte limit; optional marker/32-byte selection. Markers must be 0 or 1; EOF is exact. Unknown formats, extra arguments, trailing material and out-of-bound fields fail closed.

The seed is SHA-256 over `NATRAV_OVERLAY_CONSUMER_INVENTORY_SELECTION_V1`, NUL, u16-length node, u32 UID, configuration and read-authority digests, five u16-length filter strings, optional instance, and u32 selected count. Each next digest hashes `NATRAV_OVERLAY_CONSUMER_INVENTORY_ROW_V1`, NUL, prior digest, u32 row-JSON byte length and the exact canonical row bytes. Tests reconstruct this independently. No secret key is needed: the commitment only detects changed expected content, not unauthorized possession.

## Validation and limits

Fresh results are in [validation](../validation/VALIDATION.json) and [attempts](../validation/ATTEMPTS.md). Tests use real C++ daemons, ordinary peer admission, automatic projection processing, actual Linux UIDs, exact wire generation, full owned registry, and authenticated backup/restore. They are one-kernel laboratory results, not independent-host, physical-power-loss or side-channel proofs. Listing never creates grants, acknowledges pages, computes results, retires work, reclaims history, or changes the existing permanent name reservation.
