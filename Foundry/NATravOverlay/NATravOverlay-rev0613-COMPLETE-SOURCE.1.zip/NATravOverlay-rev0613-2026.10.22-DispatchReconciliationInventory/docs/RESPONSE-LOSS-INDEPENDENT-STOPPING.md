# Response-loss-independent stopping — revision 0567

## Scope

Revision 0567 closes one inherited control-plane correctness defect. The default
`shutdown` and `drain-shutdown` requests already made durable lifecycle decisions,
but their worker cleared its process-stop return value when the Unix-socket reply
could not be written. A client that disconnected after sending a complete,
authorized request could therefore leave the daemon running in `DRAINING` mode
after it had accepted the stop.

The response channel is no longer part of stop acceptance. Once the existing
authorized durable boundary has completed, later response construction, framing,
write, half-close, or peer reception cannot revoke the process stop.

No request or response encoding changed. Normal successful JSON remains:

```json
{"format":"NATRAV_OVERLAY_CONTROL_SHUTDOWN_V2","ok":true}
```

or the existing `NATRAV_OVERLAY_CONTROL_DRAIN_SHUTDOWN_V1` account.

## Exact acceptance boundaries

### Immediate shutdown

The default immediate stop becomes irrevocable only after:

1. The complete strict NOC1 request has been decoded.
2. The actual connected UID has current `SHUTDOWN` authority.
3. The existing authorized local-control decision has been recorded.
4. `SHUTDOWN_REQUESTED` has been durably appended.
5. The live service mode has been published as `DRAINING`.

The handler then marks process-local stop intent before constructing or writing the
reply. A failed reply increments the existing runtime control-error counter but
does not return the node to service.

### Draining shutdown

The existing `DRAIN_STARTED` event and `DRAINING` mode begin the bounded drain,
but they are not yet the final stop boundary. The worker retains the existing
wait, deadline and pending-work rules. The default drain becomes irrevocable only
after one of these existing terminal events has been durably appended:

- `DRAIN_COMPLETED`
- `DRAIN_DEADLINE`

Stop intent is set immediately after that append and before response construction.
A lost response cannot erase the terminal event, cancel pending work, acknowledge
an operation, execute an action, extend a deadline, or change the completion
classification.

The opt-in terminal-head kinds 42 and 43, and revision-0569 correlated terminal kinds 46 and 47, retain their separate coordinator-owned
reply path and current `INSPECT` requirement. Revision 0567 changes the inherited
default kinds 4 and 14.

## Failures before acceptance remain non-stops

The change does not turn transport activity into authority. None of the following
can create stop intent:

- A connection that sends no complete frame.
- A declared frame that ends early.
- A malformed or trailing request.
- An unknown request kind.
- A request from a UID without current `SHUTDOWN` authority.
- A request whose authority is revoked before decoding finishes.
- Failure to record the required lifecycle transition.
- A poisoned journal writer or other failure before the durable terminal boundary.

Those paths keep the existing typed errors, denial audit behavior and conservative
lifecycle recovery. A `DRAIN_STARTED` event without a terminal event still
reconstructs as an interrupted drain and does not silently reopen mutations.

## Reply loss is not a receipt

The server attempts the same bounded response as before. A successful write is not
proof that the client received the bytes, and a failed write is not proof that the
request was rejected. After a destructive request, the client must treat transport
loss as ambiguous and establish process exit or inspect the stopped state rather
than blindly retrying.

Revision 0567 deliberately adds no journal event for reply delivery. Recording such
an event would require a write after the stop boundary and would still not prove
client receipt. It also adds no caller-supplied UID, new permission class, external
anchor update, or automatic recovery action.

## Obligations and restart

A response-lost completed drain can stop with zero pending outbound/action work. A
response-lost deadline drain can stop with either category still pending. Those
obligations remain exact and reconstruct normally. Restart after `DRAIN_COMPLETED`
or `DRAIN_DEADLINE` returns to ordinary `RUNNING` service; restart after an
interrupted drain remains conservatively `QUIESCED`.

Immediate shutdown provenance likewise reconstructs without manufacturing an
interrupted drain. Signal-driven stopping remains separate and does not fabricate a
local shutdown request.

## Validation boundary

The dedicated native-process suite uses forced Unix-socket reset after complete
requests and covers:

- Default immediate shutdown.
- Empty completed drain.
- Deadline drain with an unreachable outbound obligation.
- Deadline drain with a real authenticated, deferred action.
- Malformed, partial and unauthorized requests.
- Current-policy revocation while a request is partially transmitted.
- A competing lifecycle denial during an accepted drain.
- Signal-driven stopping.

Keyed cases independently authenticate the exact stopped journal and then perform
complete native replay and restart. The predecessor executable is expected to fail
the immediate response-loss case by remaining alive. A narrow negative-control
build restores only the old `stop_intent_committed = false` behavior after reply
failure; the same regression must detect it.

These tests run on one Linux kernel with Unix sockets and configured loopback peers.
They do not establish physical power-loss behavior, independent-host operation,
client receipt, separately protected expectation custody, or static-link
portability.

## Exact attempt correlation (0568)

Revision 0568 adds separate opt-in request kinds carrying a canonical caller token. They retain every stop-acceptance boundary documented above, but change the exact request bytes and therefore the durable request identity. This allows a caller to distinguish an intended attempt from an older byte-identical default request after independently establishing process exit and inspecting authenticated provenance. The token remains provenance only and is not a receipt or idempotency key. [Correlated stopping](CORRELATED-STOPPING.md).
