# Bounded outbox inspection — revision 0530

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Interface and authority

`outbox-query` reads the existing state owner through its kernel-authenticated Unix control socket. It requires current `INSPECT`, the existing node-wide administrative metadata class. `SUBMIT` alone does not grant it; evidence metadata/payload permissions are not required and are not conferred. There is no implicit per-creator isolation in this administrative API.

```sh
./node/bin/natrav-overlay outbox-query --control state-a/control.sock \
  --operation HEX64 --history-limit 4

./node/bin/natrav-overlay outbox-query --control state-a/control.sock \
  --peer B --state REJECTED --limit 16 --max-bytes 32768 --history-limit 2
```

`--operation`, `--peer` and `--state` are exact conjunctive selectors. The outcome spelling is one of `PENDING`, `ACKED`, `REJECTED`, `CANCELLED`, `EXPIRED`. A missing operation, an operation excluded by another filter, or an unknown/removed recipient with no matching retained work returns an empty selection, not a missing-obligation claim based on summary truncation. Historical obligations remain inspectable after route removal. No scope wildcard, payload switch, remote query or mutation is added.

Authorization is rechecked after the bounded request is decoded. The active configuration is held stable through selection and encoding. Already authorized bounded bytes may finish transmission after that lease is released. Quiesce/drain permit this observational command. Successful and empty queries append neither outbox state nor successful control-audit records; current-run counters still advance. Existing denial auditing remains in effect.

## Rows and disclosure boundary

The response format is `NATRAV_OVERLAY_OUTBOX_QUERY_V1`. Rows preserve the durable one-based `queue_sequence` and include operation identity, issuer, recipient, scope, correction parent, record digest, payload length and authoritative outcome. They report exact pending record/payload reservation, delivery policy, current application-attempt count, retry time, expiry/cancellation times, and receipt recipient/recorder/sequence/disposition/record digest.

Transition windows retain rejection, retry, rebind and cancellation metadata. Free-form error detail and transition-reason text are omitted; displayed transitions include the exact reason byte length and SHA-256 of its bytes. Rejection entries explicitly distinguish the policy digest from a replacement key pin. Active rejection metadata is separately available even with history suppressed. No record payload is decoded, hashed or copied by a query; no private identity pathname is emitted. Administrative names, scopes, identity commitments, times, sizes and actor fields remain sensitive metadata.

The `attempts` field is the current durable application-attempt account, not a lifetime sum and not a route-probe counter. Explicit retry/rebind may reset that account as specified by existing governance. Runtime route probe/cooldown statistics remain in ordinary status, not reconstructed as durable application attempts. Full per-attempt historical timing was never retained and is not invented here.

A non-null `association` is reconstructed from the durable source-subscription or publication-channel registry, not guessed from payload magic. It contains immutable issuance metadata: source grant/lease/instance/source operation, or channel/epoch/sequence/projection commitments, plus the governing issuance configuration event. It is not a live subscription or channel-lifecycle summary. Other obligations, including standalone publication, have `null` unless linked by those registries. No current source or channel lookup is replaced by that immutable association.

## Page and history bounds

| Resource | Bound |
|---|---:|
| Returned operation rows | 1–64 requested; default 32 |
| Complete annotated JSON response | 4,096–60,000 bytes; default 60,000 |
| Transition entries per row | 0–16; default 4 |
| Cursor | Exactly 128 bytes, encoded as 256 lowercase hex characters |
| Cursor lifetime | Five minutes from first page; continuation does not extend it |

The JSON bound includes the real local-principal annotation, excluding the length/NOR1 framing. The encoder reserves bounded envelope space before committing a complete row. If the first row does not fit, `OUTBOX_QUERY_PAGE_TOO_SMALL` requires a larger byte budget or smaller history window; later nonfitting rows end the page without being skipped. `history_more` never implies that unreturned transitions were absent.

For a list query, `next_cursor` continues operation rows. Each row shows its initial transition window. To enumerate one operation's complete transitions, repeat an **exact-operation query** with its returned `next_cursor` and unchanged options; that cursor advances the transition offset while reprinting coherent operation metadata. `--history-limit 0` suppresses history and exact history continuation, but still reports its total and omission. A list may show `history_more` while its top-level `more` is false; they describe different dimensions.

The implementation visits at most the requested rows plus one nonfitting row, and at most the selected history window plus one active-rejection record for each visited row. Exact lookups visit at most one operation. Empty polling visits zero records. Response `work` counts actual visited rows, transition records and association lookups, and reports zero payload bytes read. Tree comparisons, configuration canonicalization and cryptographic metadata operations are additional bounded work, not included in those counters.

## Coherence, cursors and staleness

Every page is selected and encoded under the state mutex. Queue order is stable, but outcome membership and metadata may change. The implementation does not retain historical snapshots or silently return a mixture after mutation.

Each semantic outbox append or update touches reconstructed exact-operation and recipient/outcome selection revisions. Rejection, acknowledgment, cancellation, expiry, policy attachment, begun attempts, failures, retry and rebind all participate, including source/channel composite transactions. An exact query token checks only that operation; list tokens check the selected recipient/outcome bucket. Leaving and later rejoining a bucket still invalidates the prior revision. Changes outside a filtered bucket do not invalidate it.

`OBC1` tokens authenticate the actual UID, node/query specification, active configuration digest, selection revision, position and monotonic expiry with a separate random process-local HMAC-SHA-256 key. The token is not a permission grant, durable checkpoint, content digest or freshness authority. It uses OpenSSL EVP_MAC and CRYPTO_memcmp; no custom hash primitive is introduced. Primary API references: `https://docs.openssl.org/3.0/man3/EVP_MAC/` and `https://docs.openssl.org/3.0/man3/CRYPTO_memcmp/`.

| Event | Result |
|---|---|
| Selected metadata or membership changes | `OUTBOX_CURSOR_STALE`; restart |
| UID, query options or active configuration differs | `OUTBOX_CURSOR_CONTEXT_MISMATCH` |
| Altered token or another issuing process | `OUTBOX_CURSOR_INVALID` |
| Five-minute lifetime elapsed | `OUTBOX_CURSOR_EXPIRED` |
| Same-process compaction without selected mutation | Token remains usable |
| Unrelated peer/outcome mutation outside the chosen bucket | Token remains usable |

Rollback to exactly the same accepted configuration digest is not a new token authority; current permission is always rechecked. Restart invalidates tokens even if reconstructed revision counters happen to match. Under continuous selected delivery activity, broad enumeration may repeatedly become stale. Narrow filters and exact lookup remain available; no stable-snapshot service is claimed. `OUTBOX_QUERY_DEADLINE` fails explicitly before a partial success, retaining bounded time for response transmission; severe scheduling delay can still close the connection at its I/O deadline.

## Storage and compatibility

This adds local control kind 23 and the strict `OBQ1` request, not a peer protocol, journal kind or storage migration. Existing command encodings are unchanged. Request flags, lengths, outcome names and EOF are checked independently of CLI parsing.

The existing operation-ID map is reused. Additional queue-order sets and selection versions are derived from authoritative state during semantic replay, checkpoint loading and normal mutation. Immutable association lookup is derived from retained registries. Index memory is proportional to retained operations; this is not a constant-memory database. It stores no additional payload copies and no separately trusted file. Compaction does not reset the live indexes; a newly opened state reconstructs them from validated data.

## Evidence and boundaries

The dedicated suite independently enumerates 150 queued operations, including records omitted from generic status, five outcomes, history beyond one page, malformed wire requests, current-policy revocation, real different UIDs, selective staleness, hard restart, authenticated compaction, encrypted signed restore, relocation, and native source/channel links. A separate differential program checks index ordering and revisions against vector/set references. Completed profiles and actual counters are in [validation](../validation/VALIDATION.json); [attempts](../validation/ATTEMPTS.md) preserves adverse results.

No remote query, payload access, automatic repair, command-side cancellation, durable snapshot cursor, hidden-write timing confidentiality, external freshness anchor or host-compromise protection is added. Tests use owned local processes on one kernel. Static OpenSSL linking retains its portability warnings.

## Conditional administration (revision 0531)

Exact-operation rows now add `condition`, a durable semantic digest and latest conditional-action receipt. Use its `state_digest` together with the response `configuration_digest` for optional [conditional cancel/retry/rebind](CONDITIONAL-OUTBOX.md). This is separate from the process-local `selection_version`; that cursor version is never action authority. Broad listings remain on the preceding metadata-only indexed path. Oversized conditional histories return `condition.available=false` without preventing ordinary history inspection. Exact cursor validity additionally detects changes to retained adoption restrictions.
