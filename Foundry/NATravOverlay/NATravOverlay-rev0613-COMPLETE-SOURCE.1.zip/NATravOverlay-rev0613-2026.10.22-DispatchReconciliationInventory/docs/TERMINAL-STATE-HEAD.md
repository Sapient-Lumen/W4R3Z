# Terminal authenticated-head handoff — revision 0566

## Explicit request; separate authority

```sh
./node/bin/natrav-overlay shutdown --control state-a/control.sock \
  --final-state-head yes --deadline-ms 20000

./node/bin/natrav-overlay drain-shutdown --control state-a/control.sock \
  --reason 'stop for an explicit head capture' --drain-deadline-ms 5000 \
  --final-state-head yes --deadline-ms 20000
```

The new option accepts exactly `yes` or `no`, defaulting to `no`. It is valid only on these two existing stop commands. No authentication key, claimed UID, state path, external selector or user-selected response ceiling enters the control request. Linux connection credentials identify the actual caller.

Both current **SHUTDOWN** and **INSPECT** are required after complete request decoding. SHUTDOWN alone does not grant authenticated-head visibility, and INSPECT alone cannot stop the process. A partially transmitted request uses the policy current when decoding completes, not its connection-opening policy. Existing permission, denial-audit and lifecycle gates remain.

An admitted stop retains its accepted-configuration lease through the stopping decision. The deferred connection does **not** carry a configuration lease across thread joins: an already queued configuration writer must be able to finish or reject rather than deadlock shutdown. After all workers have joined, the coordinator separately rechecks INSPECT against the final accepted configuration before exposing metadata. Stop authorization already consumed at admission is not retroactively converted into a read grant.

The default stop requests and responses are unchanged. Explicit `no` selects the existing wire kind. This revision does not silently attach a head to old shutdown replies.

## Wire and ownership boundary

The outer NOC1/NOR1 framing is unchanged. The strict requests are:

| Request | Encoding |
|---|---|
| Immediate terminal handoff | `NOC1`, kind **42**, no body. |
| Draining terminal handoff | `NOC1`, kind **43**, existing big-endian uint32 drain deadline and uint16-length printable reason. |

Drain limits remain 1–600,000 milliseconds and a 1–256-byte printable reason. Truncation, trailing bytes, invalid reasons and out-of-range deadlines fail closed. Old binaries reject the new kinds/options; they cannot silently disregard the requested handoff.

There is exactly one deferred, owned reply connection per process stop. Its metadata contains the actual principal, exact request digest, existing I/O options and optional pending drain lifecycle event. It is never persisted. Control workers access the slot under the existing lifecycle transition mutex; the coordinator accesses it only after joining all control workers. A second final-handoff request is rejected. The requesting worker transfers the connection and returns; it does not block waiting for a join that includes itself.

## Stop ordering

1. Decode and authorize against current policy; perform the existing authorized control accounting.
2. For immediate stopping, append the existing SHUTDOWN_REQUESTED lifecycle record. For draining, append DRAIN_STARTED and use the existing bounded completion/deadline rules.
3. Enter draining mode, defer the reply, and request process stopping independently of subsequent client response delivery.
4. Stop accepting work and close the bounded queues. Already queued control requests are still processed or rejected under their existing rules, including denial audits.
5. Join **all** control workers, dynamically registered peer schedulers, action/projection/publication/source/import schedulers, and inbound peer workers. A returned terminal head cannot precede a late receipt, queued denial, or in-flight compaction.
6. Reject a recorded fatal scheduler exit before claiming completion. For a healthy opt-in drain, append DRAIN_COMPLETED or DRAIN_DEADLINE **after the joins**, using the stopped pending-work account. The completion/deadline classification remains the one selected at the original wait boundary; late outcomes can reduce the final remainder without rewriting that classification.
7. Recheck current INSPECT, refuse poisoned state, then seal and sample the state under one mutex.
8. Attempt one bounded reply, without any subsequent journal or successful read-audit append. Finish the existing process teardown and release state ownership.

An immediate stop does not acquire a new durable lifecycle type or promise delivery completion. Its existing SHUTDOWN_REQUESTED record may precede final worker writes; the separate terminal pending account is sampled after those writes. The opt-in drain's terminal lifecycle event follows all workers. Earlier configuration formats without durable lifecycle events preserve their process-local compatibility semantics.

## Response contract

`NATRAV_OVERLAY_TERMINAL_STATE_HEAD_V1` reuses the exact existing NASH1 selector construction and opening-expectation account. Complete annotated JSON is capped at **4,096 bytes**; an oversized result fails rather than exposing a partial selector. The current response contains only fixed metadata and the normal actual-principal/request annotations.

`state_head` retains `NOT_CHECKED_HERE`, `NOT_ESTABLISHED`, and `automatic_update: false`. Keyed state includes generation, key ID, epoch, root, record count and physical journal-byte account. Unkeyed state returns null authentication and selector; checksums are not promoted into authenticated heads.

`observation` states one-lock consistency and replay/live-application validation, with `disk_reaudit: false` and `may_advance_after_sample: false`. The latter is scoped by `terminal.scope: THIS_PROCESS_STOP_ONLY`. It is **not** a promise that no replacement process or out-of-band actor will subsequently change the files. `replacement_writer_excluded` is false.

The terminal object reports indexed `pending_outbound` and `pending_actions`. `obligations_complete` covers only these existing drain categories (`OUTBOUND_AND_ACTIONS_ONLY`), not every projection backlog, paused schedule, source subscription, unresolved imported dependency, business objective, or future allowance. A deadline stop can return a valid terminal selector while obligations remain pending. Nothing cancels, acknowledges, refunds, or revives those obligations merely to complete the handoff.

The shutdown account identifies IMMEDIATE or DRAIN, confirms writer joins and final lifecycle accounting, and separately reports `drain_completed_at_wait_boundary` and `drain_deadline_reached`. The two are null for immediate shutdown. `delivery_confirmation` remains `NOT_ESTABLISHED`; a socket write is not a client receipt.

An actually matched opening expectation remains historical. Authorized appends, denial audits, compaction, and stop lifecycle events may make its `matches_observation` false. The new terminal sample never becomes a refreshed expectation automatically.

## Process-local seal and failure handling

After building a successful terminal snapshot, NodeState sets a process-local terminal seal. The append path, compaction and authentication changes reject later mutation with `STATE_TERMINAL`; repeated sealing also refuses. The seal changes no durable bytes or logical-state encoding and is absent after independent replay. Runtime join ordering, not a persisted flag, establishes the terminal boundary.

Both a failed journal write and partial application after a synchronized append poison the writer. Terminal sampling refuses them with `STATE_RESTART_REQUIRED`, just as live head observation does. A separately retained scheduler-failure account causes `TERMINAL_HEAD_RUNTIME_FAILED`; a root alone does not prove a healthy orderly runtime stop. An incomplete final drain account is not fabricated after failure, so existing interrupted-drain restart semantics remain conservative.

Errors during final accounting or sampling produce no successful head and cause a nonzero daemon exit. A response failure after a successfully accepted **opt-in** stop does not cancel that stop or trigger another append. The process's ordinary stop diagnostic records only `SENT_UNCONFIRMED`, `RESPONSE_LOST`, `FAILED`, `FAILED_RESPONSE_LOST`, or `NOT_REQUESTED`, never the head itself. Even SENT_UNCONFIRMED is not proof that the client received, retained or protected the selector.

Revision 0567 separately repaired the existing default (non-opt-in) handler: once its existing durable immediate or terminal-drain boundary is accepted, reply loss cannot revoke process stop. The terminal-handoff path remains distinct because it joins writers, seals state and exposes an authenticated head under additional current `INSPECT` authority. See [response-loss-independent stopping](RESPONSE-LOSS-INDEPENDENT-STOPPING.md).

## Timing and external custody

The fixed bound applies to response size and one five-second server write attempt **after** joins. It is not a new end-to-end latency guarantee. Existing worker I/O, queued controls and drain deadlines remain bounded by their existing settings. The CLI's `--deadline-ms` continues to bound its entire exchange (at most 60,000 milliseconds), not the server's lifetime. A long drain or join sequence can outlive the client deadline. Losing the response is therefore an explicitly permitted outcome, not a reason to cancel the accepted opt-in stop or manufacture a selector from an earlier live sample.

Reception of the handoff can precede process exit and release of the exclusive state lock by the remaining read-only teardown. Establish process exit before reopening state. For a complete disk check, run the existing keyed offline audit against those stopped bytes. Tests authenticate every returned selector independently from raw HMAC framing, then require complete native semantic replay to agree without changing the journal.

The operator must explicitly select and protect the terminal value outside rollbackable state before relying on `--expected-state-head` at the next open. A matching old snapshot plus its old selector remains a match. This feature does not manage custody, establish global latestness, authorize recovery, skip semantic replay, prove power-cut durability, reauthenticate disk tampering behind the live process, or exclude another host or later writer. See [external expectations](EXTERNAL-STATE-EXPECTATIONS.md) and [live observations](LIVE-STATE-HEAD.md).

## Verification

The independent suite is `node/tests/run_terminal_state_head.py`. It covers current real-UID permissions, revocation/grant during partial requests, queued configuration publication, deferred reply ownership, malformed requests, default/unkeyed behavior, real TLS receipts, pending work after deadline, a delayed denial after that deadline, response loss, compaction and expected-head restart. Optional `--previous-binary` compares the actual predecessor on the exact stopped representations.

The private source failure probe also refuses terminal sampling on both publication-failure boundaries and verifies sealing blocks later append/compaction/authentication. A separately prepared runtime-failure build checks nonzero exit and interrupted-drain restart. The negative control omits only the terminal INSPECT rule; its failure is evidence that the regression detects that omission, not a passing weakened runtime. Exact completed and excluded profiles are recorded in [validation](../validation/VALIDATION.json).

## Correlated terminal extension (0569)

Revision 0569 permits `--correlation TOKEN` together with `--final-state-head yes` through separate strict kinds 46/47. Those requests inherit this entire deferred writer-join, final-accounting, final-`INSPECT`, sealing, and `NASH1` contract while adding exact request provenance. Kinds 42/43 and their successful response remain unchanged. No response from any stop protocol proves client receipt. [Correlated terminal heads](CORRELATED-TERMINAL-STATE-HEAD.md); [ordinary correlated stopping](CORRELATED-STOPPING.md).
