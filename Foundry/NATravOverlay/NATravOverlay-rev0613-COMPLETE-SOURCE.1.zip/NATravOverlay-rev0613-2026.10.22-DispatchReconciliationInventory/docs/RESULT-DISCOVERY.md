# Request-centric action-result discovery — revision 0546

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

`action-result-discover` starts from one exact retained original counter request, expected provider and result scope. It returns bounded pages of received candidate classifications using the same strict validator as `action-result-query`. No report operation ID is needed in advance. This is an observational native C++ path, not execution verification, an interpreted durable view, acknowledgment, or administrative mutation.

## Command and current authority

```sh
./node/bin/natrav-overlay action-result-discover \
  --control state-a/control.sock --request ORIGINAL_ACTION_HEX64 \
  --provider B --scope results/counter --limit 8 --max-bytes 32768
```

Repeat the original arguments with `--cursor TOKEN` for the next page. Limit is 1–32 validations and complete annotated JSON is 4,096–60,000 bytes. Exact request/provider/scope are mandatory. Unsupported options, versions, trailing bytes, zero IDs and invalid limits are rejected. Local control kind 32 contains `ARD1`; configuration V18, stored evidence, peer protocols and storage schema remain unchanged.

Current kernel UID must hold INSPECT, EVIDENCE_READ and EVIDENCE_PAYLOAD, with payload permission for the exact provider/scope. This is the same dual administrative/read boundary as correlation. Domain authorization precedes original-request lookup. Authority is checked after decoding and protected through selection and encoding. Successful reads create no successful control audit or journal event; denied access retains existing audit behavior. Observation is permitted during quiescence and drain while the endpoint remains available. Already authorized response bytes may finish transmission after later publication.

The original must be a retained locally issued, uncorrected counter action addressed to the chosen provider and durably bound to a key generation/SPKI. Its 16-byte request is decoded even when no candidates exist. Missing originals produce ACTION_RESULT_REQUEST_NOT_FOUND; invalid original bindings produce ACTION_RESULT_REQUEST_MISMATCH.

## Coverage and classifications

Candidates have a retained peer-authorization marker, are neither local-authored nor subscribed-source materializations, and contain at least 37 bytes beginning `NAC1`, sufficient to locate the claimed action ID. The derived index is keyed by exact provider/scope/claimed request. Its membership does not validate a report. Unknown magic, shorter bytes and other provider/scope/request domains are outside this association mechanism. Completeness is limited to that stated domain, not all stored bytes or global provider equivocation.

Every returned row contains the retained outer operation ID, immutable record digest, admission sequence, and classification. CONSISTENT_AUTHENTICATED_REPORT includes bounded validated claim fields. INVALID_REPORT includes a typed rejection code and `report: null`; malformed bytes are never presented as accepted report fields. Original evidence is not removed or rewritten.

The shared validator checks actual historical admission authority, historical provider generation/SPKI against the original request, full canonical payload/operation identity, local recipient binding, original record digest and amount, optional original receipt, outcome fields, checked arithmetic and effect commitment. All starts must be between admission and terminal time and respect the requested defer interval. The last rule now applies to cancelled and expired reports as well as execution. No clocks on different machines are compared. Historical configuration parsing does not reopen obsolete identity paths.

Final statuses are NO_CANDIDATES, NO_CONSISTENT_REPORTS, UNIQUE_AUTHENTICATED_REPORT and CONFLICTING_REPORTS. Until every candidate is consumed, status is INCOMPLETE and `unique_operation_id` is null—even when an early page contains exactly one good report. Conflicts are never resolved by timestamp, admission order or counter magnitude.

`execution_verified_locally` is false and freshness is NOT_ESTABLISHED. Provider policy hashes and configuration ordinal remain claims. `NAC1` carries no provider administrative receipt; that field is null. The local incoming admission, original provider-admission receipt and claimed local effect are different facts. A missing original receipt remains null; receipt arrival can invalidate a continuation and change the classification. A consistent effect hash is not proof that a dishonest provider really performed it.

## Stable selection, not a retained snapshot

ADC1 is a 240-byte authenticated cursor encoded as 480 lowercase hexadecimal characters. It contains UID; configuration and query commitments; original-request validation binding; candidate root/count; next position; cumulative consistent/invalid counts; first consistent operation; and expiry. HMAC-SHA-256 uses a separate process-local random secret and constant-time tag comparison. All cryptographic return values are checked. It is not possible to supply unprotected cumulative counts through the command.

The query commitment binds node, request, provider, scope, limit and response-byte ceiling. Changing any option requires restarting. The original-request commitment binds the immutable request, issuer/recipient, current durable provider generation/SPKI and optional complete original receipt. Mere retry-attempt counters and unrelated state are not validation facts. `original_request.delivery_state` is a current per-page observation, not a frozen cross-page state.

Each candidate root is derived on index append:

```text
root_0 = 32 zero bytes
root_i = SHA256("NATRAV_OVERLAY_RESULT_CANDIDATE_CHAIN_V1" || 0x00 ||
                root_(i-1) || BE64(i) || outer_operation_id || outer_record_digest)
```

Records are immutable and ordered by retained admission. Each page reads the current stored root, not every earlier candidate. It authenticates the token before comparing context, expiry, and current candidate/request bindings. Changed selected candidates or receipt/key facts produce ACTION_RESULT_DISCOVERY_STALE. Context changes produce ACTION_RESULT_DISCOVERY_CONTEXT_MISMATCH. Alteration or restart produces ACTION_RESULT_DISCOVERY_CURSOR_INVALID. Fixed five-minute expiry produces ACTION_RESULT_DISCOVERY_CURSOR_EXPIRED; continuation does not renew it. Missing original state still fails explicitly rather than synthesizing a selection.

Same-process compaction preserves matching continuations. Unrelated reports do not stale the selected domain. Restart invalidates all prior process tokens even when the root reconstructs identically. No token is persisted in node state. No current-policy check is skipped because a MAC verifies.

## Whole-row byte accounting and work bounds

The response reports selected candidate count/root, original-request binding, `scan.from`, `scan.after`, cumulative examined/consistent/invalid counts, returned rows and next cursor. Completed responses have no next cursor. At most `limit` candidates are validated per call, including any candidate inspected but not consumed because its complete row did not fit. A nonfitting first row returns ACTION_RESULT_DISCOVERY_PAGE_TOO_SMALL; otherwise continuation resumes at that candidate. No row is split or silently skipped.

The complete trailer, token, work counters and a conservative 384-byte principal allowance are included in sizing; the dispatcher checks the actual annotated length again. There is at most one state observation under the mutex. Deadline checks occur between bounded operations, with time reserved by the dispatcher for an error response; there is no hard real-time preemption of one configuration parse.

A page parses at most 32 reports (571 bytes each) and 32 distinct historical configurations, and hashes no preceding candidate list. Empty results parse neither reports nor historical configurations. Work counters describe the locked page method including a nonfitting candidate, not transport, startup, outside configuration work, other threads or total allocations. Candidate-root indexing adds one 32-byte digest per candidate group; retained index positions still scale with candidate count. Startup/index rebuilding is linear. Historical parsing blocks writers under the state mutex. Continuous relevant arrivals or the fixed lifetime may prevent a full enumeration from completing.

## Existing interface and test boundaries

The exact known-operation `action-result-query` retains its 32-total-candidate ceiling and detailed report interface; it shares the strengthened timeline validation. Discovery is not a replacement for an exact execution receipt or a durable review account.

[Tests](TESTING.md) describe fresh selected matrices, actual versus simulated inputs, real UID enforcement, independent wire/root references, no-receipt validation, real-clock expiry, key revocation, and encrypted restore/relocation. [Validation](../validation/VALIDATION.json) and [attempts](../validation/ATTEMPTS.md) contain only this build's observed results. The [provenance record](PROVENANCE.json) identifies this revision's verified input; discovery's original construction evidence remains in the predecessor archives.

The implementation uses the existing OpenSSL EVP_MAC HMAC interface. Primary API references: <https://docs.openssl.org/3.0/man3/EVP_MAC/> and <https://docs.openssl.org/3.0/man3/CRYPTO_memcmp/>. These primitive APIs are not an independent audit of the product's surrounding protocol.
