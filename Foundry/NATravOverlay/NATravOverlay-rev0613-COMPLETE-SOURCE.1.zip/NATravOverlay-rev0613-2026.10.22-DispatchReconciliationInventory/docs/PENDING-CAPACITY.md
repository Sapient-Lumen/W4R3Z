# Exact pending-capacity aggregates

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

Revision 0535 replaces whole-outbox quota scans with derived exact global and per-recipient aggregates. Ordinary enqueue, publication/source composite enqueue, explicit retry, rejection-reopening rebind, and conditional administration use the same accounting. No configuration, command, permission, peer format, journal kind, storage schema or logical-state encoding changes.

## Authority and meaning

The accepted journal and its semantic decoder remain authoritative. A pending operation contributes exactly one record and the byte length of its immutable application evidence payload:

```
pending records = count(status == PENDING)
pending payload bytes = sum(record.payload.size() where status == PENDING)
```

Counts are global and per exact recipient. A zero-byte payload still contributes one record. Source envelopes and publication payloads count at their actual encoded evidence-payload length; this is distinct from source-disclosure raw-byte allowances. TLS, TCP, journal framing, transition metadata and allocator overhead are not pending-payload bytes.

Unbound historical operations remain pending. Delayed work, unavailable routes, revoked/removed key bindings, elapsed wall-clock expiry not yet committed, or an exhausted attempt account not yet terminalized still reserve capacity. Only an accepted terminal transition releases it. No route/configuration edit silently deletes an obligation.

| Transition | Reservation behavior |
|---|---|
| New queue / atomic queue-with-policy | Acquire once |
| Initial policy, begun attempt, transient failure | Unchanged |
| Rebind while pending | Unchanged |
| Receipt, authenticated rejection, cancellation, committed expiry | Release once |
| Explicit retry or rebind reopening rejection | Check capacity, then reacquire once |
| Valid repeated submission, receipt or cancellation | No second acquisition or release |
| Conditional administration and source/channel composites | The same inner decoder hook applies |

Existing error order is retained: global record limit, peer record limit, global payload limit, peer payload limit. Valid duplicate confirmation precedes new-capacity checks. Failed admission cannot manufacture a reservation. Live configuration still refuses a candidate whose limits are below durable pending usage; historical work is not reinterpreted to fit a smaller number.

## Implementation

`PendingCapacityIndex` stores global totals, an ordered recipient-to-totals map, and the previous contribution of each still-pending queue position. No record payload, receipt, error text, policy or transition history is stored in this index. `NodeState::index_outbound` updates it from the resulting authoritative operation outcome alongside existing query/readiness indexes.

Repeated hook notifications are deliberately idempotent. A queue-plus-policy composite reaches the hook twice but acquires only one reservation. Pending-to-pending changes do not subtract and re-add a reservation. Last-release removes an empty recipient bucket and the settled operation's contribution. Rejected work can acquire a contribution again only when it becomes pending through its accepted retry/rebind transition.

The normal decoder calls the hook for queue, policy, attempt, failure, receipt, rejection, retry, rebind, cancellation and expiry. Channel, subscription, lease, automatic and conditional transactions apply those same inner transitions. Single-operation conditional-validation scratch states seed their derivatives before applying the candidate transition. Ordinary replay and checkpoint loading reconstruct the same index through those hooks.

Every quota check reads one global pair and one exact recipient pair. It does not build a summary vector or visit other recipients or retained operations. Recipient lookup is logarithmic in recipients with pending work; updates also locate the pending queue position. Index memory is proportional to pending operations plus recipients with pending work, not constant-memory and not a reduction of retained application storage.

Generic state snapshots now obtain queue summaries by enumerating pending recipient buckets. They still copy/hash broader application state for other reasons. Configuration validation still uses its existing broad snapshot. This increment does not claim those paths have become bounded small-page operations.

The previous `outbound_queue_usage` full scan remains an independent test reference and is no longer called by production quota admission or snapshot accounting. It retains its actual visited-record instrumentation, enabling a deliberate reference scan to demonstrate that zero production visits are not a disabled counter.

## Synchronization, failure and durability

All updates and capacity decisions execute under the existing state mutex. Capacity checking precedes journal mutation; accepted changes and derivative updates are serialized with receipt delivery and administrative operations. There is no separately authoritative reservation file or independently synchronized budget update.

Checked addition/subtraction detects overflow, mismatched immutable contributor identity/length, and impossible release. The index prepares allocations and checked arithmetic before publishing changed totals. Failure injection verifies that an unsuccessful insertion leaves the prior index unchanged. If an actual journal application fails after durable writing, the existing writer-poison/restart mechanism remains in force; the new index does not pretend to roll back a synchronized application event.

Compaction changes representation, not logical reservations. Signed/encrypted backup carries authoritative state, not a trusted cached total. Normal authenticated replay/restore reconstructs the totals from validated operations. No new freshness anchor is introduced. A valid older snapshot can still restore older pending obligations.

## Measured work

`SubmissionWork` remains per calling thread and covers enqueue/reply metadata, not decoding, earlier authorization/audit, other threads, transport or every allocator operation. Work is returned only to principals already authorized for `INSPECT`; submit-only access does not gain node-wide diagnostics.

* `capacity_records_visited`: entries visited by the deliberately retained full-scan reference; zero in production enqueue/reply.
* `capacity_aggregate_reads`: actual logical global and exact-recipient reads; two for one new-capacity check, not every map comparison or CPU memory load.
* `capacity_entries_touched`: actual indexing-hook notifications in this scope.
* `capacity_acquires` / `capacity_releases`: exact contribution changes, not every semantic transition.

A new ordinary operation with initial policy normally reports two aggregate reads, two hook notifications, one acquisition, zero releases and zero full-scan visits. An established exact duplicate normally reports no capacity check or contribution change. Counters are not persisted and do not grant authority.

The integration fixture combines 8,192 unrelated inbound records (16 MiB of payload), 4,096 settled outbound records, and actual newly submitted work. A 17-byte operation and a 60,000-byte operation each require two aggregate reads with zero retained-record visits. Conditional cancellation and an actual C++ recipient receipt release their exact reservations. The old snapshot/payload-copy counters remain zero in enqueue/reply. These are location-specific work measurements, not a wall-clock speedup, process-wide allocation total, maximum capacity benchmark, or independent-host experiment.

## Tests and independent references

See [actual validation](../validation/VALIDATION.json), [attempts](../validation/ATTEMPTS.md), and [test commands](TESTING.md).

`test_pending_capacity.cpp` drives the production index through 50,000 deterministic random updates of 1,024 positions, comparing every result to an independent full scan. It exercises zero bytes, settled cleanup, unsigned-range boundaries, immutable contributor mismatch and each allocation-failure boundary of a new-recipient insertion. Its extreme numeric boundary is an index arithmetic test, not a claim that an application can admit a 2^64-byte record.

`test_pending_state.cpp` links the complete production `NodeState` and maintains a separate status/amount model across 1,264 actions, 390 retained operations, ordinary and atomic policy enqueue, receipt/duplicate receipt, transient attempt/failure, rejection, retry, pending/reopening rebind, cancellation, expiry, checkpoint publication and restart. Twenty-four actual threads compete at an eight-record/eighty-byte limit. Its deliberately broad reference scan must register the actual retained-record visits.

The integration suite tests large settled history, exact terminal release and retry reacquisition, zero-byte capacity, concurrent controls, lower-limit configuration rejection, hard-kill reconstruction, keyed compaction, encrypted signed restore, relocation and later release.

`run_capacity_variant.py --variant oracle` builds an isolated test version that checks the aggregate against the independent full scan after every authoritative indexing notification. It exercises real conditional administration and source/channel/lease composite transactions. That diagnostic version intentionally performs extra work and is not a performance profile or shipped binary.

`--variant no-cancel-release` deliberately treats cancelled operations as still reserved. The normal regression must fail at the post-cancellation exact count/byte assertion. Only the patch and failing account are retained; no weakened runtime is delivered.

## Remaining scope

This change preserves, rather than replaces, generation-stable local authorization, source/recipient constraints, terminal receipt semantics, route selection and exact conditional actions. Mutex contention, complete-state startup/status costs, journal/checkpoint replay work, retained payload storage, static OpenSSL portability limits and the one-kernel test boundary remain. It adds no admission bypass, external freshness, distributed lease, split-brain protection or recall guarantee.

## Future action results (0544)

The ordinary index still counts only actual PENDING outbound records. A second derived index tracks new V18 pending action-result commitments. Admission, enqueue, retry and rejected-work reopening compare combined global/per-peer usage. Status reports the two components and their sum, not fabricated outbound rows. A terminal action converts exactly its own contribution in the same journal commit as the result. See [reservation semantics](RESULT-CAPACITY.md).
