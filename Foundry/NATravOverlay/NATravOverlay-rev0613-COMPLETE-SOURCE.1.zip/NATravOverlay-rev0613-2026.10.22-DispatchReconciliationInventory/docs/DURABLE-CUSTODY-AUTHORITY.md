# V21 durable custody authority and evidence

Revision 0606 connects the private `NHCE0001` / `NHCR0001` custody state
machine to NATravOverlay's existing authenticated configuration history and
owner-private journal.  It does not make ordinary peer routes relay traffic.
The release marker remains:

```text
configured_custody_relay: false
```

## Authority

`NATRAV_OVERLAY_CONFIG_V21` accepts canonical `custody_grant_hex` records.  A
grant names one exact transition:

- origin node and signing generation;
- final recipient node and signing generation;
- current custodian node and signing generation;
- exact next-hop node and signing generation;
- envelope lifetime, hop, active-case and capsule-byte bounds;
- immutable grant id, generation and predecessor commitment;
- monotonic `ACTIVE`, `RETIRED` or `REVOKED` state.

Every named signing generation must already be retained by the ordinary
configuration.  Grant admission uses the existing owner or delegated
`CONFIGURATION` authority and the existing authenticated configuration journal.
There is no second authority ledger.

An active grant may originate a new transfer offer.  Retired grants may explain
historical evidence but cannot originate a new offer.  Revoked grants cannot be
used.  Accepted grant generations cannot be erased, redefined or moved to a
more permissive state.  A stale seed configuration cannot undo accepted
history after restart.

## Durable evidence

The existing `NodeState` journal now retains bounded custody events:

```text
REGISTERED
RECORD
UNCERTAINTY
EXPIRED
IMPORTED
```

A registration binds the exact envelope, unchanged capsule, one exact grant
reference per hop and the accepted configuration event that authorized it.
Transfer and acceptance records continue to be checked by the signed custody
state machine.  Uncertainty is permitted only while one exact transfer offer
awaits acceptance.  Expiry and final import are separate terminal observations.

The logical checkpoint contains the same canonical events.  Restart and
compaction reconstruct the same custody cases and reject broken authority,
configuration provenance, event chains or conflicting duplicates.

## Owner-only commands

The normal executable provides explicit offline commands:

```text
custody-create
custody-offer
custody-accept
custody-uncertain
custody-expire
custody-status
custody-final-import
```

They require exclusive state ownership and owner `MAINTENANCE` authority.  A
route file contains exact signed handoff bindings in canonical order.  A
`NHCB0001` bundle carries the immutable envelope, opaque capsule, exact grant
references and signed custody records.  Publication is bounded and no-replace.

The final recipient may invoke `custody-final-import` only after its signed
custody acceptance is durable and before expiry.  Import then reuses the
existing one-hop handoff admission or receipt-reconciliation path.

## Meaning

Custody acceptance is not application admission.  Capsule import is not action
execution.  Application admission is not final delivery.  Only the existing
exact authenticated receipt can complete an obligation.

A transfer response may be lost.  The current custodian can retain bounded
uncertainty evidence and retry reconstruction without manufacturing an
acceptance.  Exact duplicate evidence is idempotent; conflicting evidence is
rejected.

## Deliberate non-features

Revision 0606 adds no automatic route forwarding, discovery, opportunistic
relay, route learning, transparent bridging, global consensus or second normal
executable.  Ordinary peer routes still do not consume custody bundles.

Same-host deterministic evidence does not establish independent physical
custody, hostile carriers, hardware media, power interruption or globally fresh
configuration.  Those remain verification debts, not construction vetoes.
