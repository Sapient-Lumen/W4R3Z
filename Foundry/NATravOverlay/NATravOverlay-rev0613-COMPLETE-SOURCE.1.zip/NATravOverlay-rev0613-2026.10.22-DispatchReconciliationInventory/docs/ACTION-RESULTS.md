# Durable action-result return — revision 0544

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

Revision 0543 returns terminal counter-action outcomes through the ordinary authenticated evidence outbox.  The executing node does not create a second callback transport or equate the peer's admission receipt with the later local counter effect.

## V18 disclosure policy

Configuration V18 adds one exact rule form:

```text
NATRAV_OVERLAY_CONFIG_V18
action_result=PEER,GENERATION,counter.add,RESULT_SCOPE
```

The peer and generation must be the exact active routed generation.  The result scope is an ordinary evidence scope.  Rules are canonicalized, sorted and hashed independently of input order.

A V18 node accepts a new `counter.add` action only when the authenticated action issuer and key generation have a matching rule.  Missing policy fails before action admission with `ACTION_RESULT_POLICY_REQUIRED`.  V6–V17 remain readable and retain their local-only counter-action behavior; they are not silently reinterpreted as granting disclosure.

Action admission stores an immutable result binding containing:

```text
result scope
policy and rule digests
accepted configuration event
issuer key generation and SPKI
maximum attempts and backoff
result-delivery expiry
```

Later configuration changes do not retarget an accepted action.

## Atomic terminal transition and outbox obligation

The terminal action transition and initial result obligation are encoded in one `NAT1` transaction, journal kind 37.  Semantic replay derives the expected terminal action, canonical result record and exact delivery policy before applying either component.

The transition is accepted only when both are valid:

```text
EXECUTED | CANCELLED | EXPIRED action state
+
ordinary evidence record with initial recipient policy
```

A crash cannot leave a terminal result binding without its outbox operation, or queue the result without the matching terminal action state.

Executed actions apply the counter effect only inside this synchronized transaction.  The local effect is therefore not committed before the result obligation can be durably represented.

## Canonical NAC1 result

The result payload begins with `NAC1`.  It binds:

```text
terminal outcome
source action ID and immutable record digest
source admission sequence
source authorization policy/rule and decision time
result policy/rule and accepted configuration event
result scope
recipient generation and SPKI
amount, admission time and terminal time
attempt count and latest synchronized start
local effect receipt and counter before/after, when executed
terminal reason length and domain-separated digest, when cancelled or expired
```

Free-form cancellation and expiry reasons are not copied into the remote payload.

The result operation ID is:

```text
SHA-256(
  "NATRAV_OVERLAY_ACTION_RESULT_OPERATION_V1"
  || 0x00
  || NAC1
)
```

The result is an ordinary immutable evidence original issued by the executing node to the action issuer.  It uses the configured exact result scope.  Recipient authorization remains independent and can accept or reject it normally.

## Two different receipts

An executed result can contain the action's local effect receipt:

```text
ACTION_RECEIPT_V1
```

The later outbox operation can separately receive an ordinary remote delivery receipt.

These prove different facts:

| Receipt | Meaning |
|---|---|
| Local effect receipt | The bounded local counter transition was committed in the action state |
| Remote delivery receipt | The recipient durably admitted or deduplicated the NAC1 evidence record |

A remote delivery rejection does not undo the local counter effect.  A missing remote receipt does not imply that the counter effect did not occur.

## Ordinary outbox behavior

Result operations inherit existing machinery:

```text
exact generation/SPKI binding
multi-route TLS delivery
reusable NOS1 sessions
pending quotas
retry and backoff
terminal authenticated rejection
cancellation, expiry and explicit same-binding retry; result-key rebind is forbidden
lost-receipt duplicate replay
compaction, backup, restore and relocation
```

`action-query` exposes the result binding, terminal outcome, result operation ID and record digest.  `outbox-query` identifies the association as `ACTION_RESULT` and names the source action and outcome.

## Reserved capacity and conditional cancellation

New V18 admissions reserve one future result record and its format-derived maximum payload bytes before accepting the action. All enqueue and reopening checks include those reservations. Terminalization atomically converts its own reserved contribution into the actual result; it does not compete with unrelated ordinary work for that already promised queue capacity.

Conditional cancellation now uses one `AAT2` journal record containing the administrative receipt and complete terminal/result conversion. Legacy marker-2 V18 actions remain explicitly unreserved and still need actual free ordinary quota. See [reserved-capacity contract](RESULT-CAPACITY.md) for exact accounting, limits and compatibility.

Queue reservation is not journal/disk/memory preallocation or a promise of remote acceptance. Legacy unreserved capacity pressure remains a nonfatal worker wait. Reserved actions can still encounter non-quota storage failures.

## Checkpoint and replay validation

Checkpoint extension `NRA2` retains reserved bindings; `NRA1` remains the legacy unreserved representation. Both retain each pending or terminal result binding.  Loading a checkpoint independently reconstructs:

- the historical V18 policy and exact rule;
- the active key generation and SPKI recorded at admission;
- the result-delivery limits;
- the terminal NAC1 record and operation ID;
- the ordinary outbox policy and retained operation;
- the source-action association.

A result cannot survive checkpoint reconstruction when its action, source admission, historical rule, result record, policy, terminal outcome or outbox operation differs.

## Security and product boundary

Action authority is not disclosure authority.  V18 requires both the existing authenticated action rule and an exact action-result rule.

NAC1 is an attributable report by the executing node.  It does not establish that the original action request was wise, that the source evidence was true, that the recipient is fresh, or that another complete state copy has not diverged.

A cancelled result reports an attributable cancellation decision; it is not proof that arbitrary external effects never occurred.  The built-in counter action remains the only action sink.

Recipient-side `action-result-query` now provides explicit observational NAC1/request correlation under INSPECT plus result-payload read authority. It never conflates remote claims with local effects. See [correlation contract](ACTION-RESULT-CORRELATION.md).
