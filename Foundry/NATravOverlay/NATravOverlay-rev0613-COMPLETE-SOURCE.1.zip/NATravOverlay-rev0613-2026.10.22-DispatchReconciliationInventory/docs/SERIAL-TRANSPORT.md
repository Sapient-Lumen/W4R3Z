# Explicit POSIX serial/TTY carrier — revision 0580

Revision 0580 adds the first externally configured non-IP carrier to the
existing `natrav-overlay` executable. It is a POSIX serial/TTY implementation of
`OrderedByteStream`; it does not add a peer protocol, identity mechanism, relay,
or second daemon.

## Canonical locator

The exact configured representation is:

```text
serial-v1|path=<percent-encoded-absolute-path>|baud=<rate>|data=<7|8>|parity=<none|even|odd>|stop=<1|2>|flow=<none|software|hardware>
```

Fields appear once, in that order. The parser decodes the path, validates every
setting, re-encodes the locator, and requires byte equality with the supplied
text. Unsafe path bytes are uppercase percent escapes. Control bytes, relative
paths, missing fields, alternate field order, unsupported rates, oversized
paths, and noncanonical decimal or escape forms fail closed.

Supported baud rates are the rates represented by the build platform from the
bounded set 1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200, and 230400.
The latter three are accepted only when the platform exposes their POSIX/Linux
speed constants.

Bare numeric IPv4/IPv6 endpoint text remains the canonical TCP representation.
Thus every predecessor TCP configuration byte is unchanged. A locator beginning
with `serial-v1|` selects serial explicitly; there is no carrier probing or
fallback.

## Device ownership

Serial acquisition:

- opens the exact configured path with `O_NOFOLLOW`, `O_NOCTTY`, `O_NONBLOCK`,
  and `O_CLOEXEC`;
- rejects a final symlink and every non-character device;
- requires a usable `termios` interface;
- obtains exclusive TTY ownership with `TIOCEXCL`;
- records the requested path and bounded acquired character-device observation
  for error diagnostics;
- applies explicit raw line settings, including speed, character width, parity,
  stop bits, and flow control; and
- restores the exact prior `termios` state and clears exclusivity before close.

The path, inode, and device numbers are reachability observations only. They do
not become a node ID, certificate name, generation, SPKI pin, authorization
principal, or application identity.

There is no `/dev` scan, USB-ID inference, Bluetooth discovery, automatic
attachment, or inheritance of ambient line settings.

## Stream behavior

Reads and writes use absolute deadlines and nonblocking `poll`. Interrupted
system calls are retried and counted. No single carrier operation moves more
than 4096 bytes, so progress remains finite even if a higher layer supplies a
larger span. Hangup and reset-like device errors remain distinguishable from a
successful operation.

A TTY does not provide TCP's write-half shutdown. Serial advertises
`can_shutdown_write = false`, and `shutdown_write()` fails explicitly with
`TRANSPORT_HALF_CLOSE_UNSUPPORTED`. The reusable peer path closes semantically
with NOS1 CLOSE/CLOSE_ACK and TLS close-notify before the carrier is released.
Carrier teardown alone is never evidence that a peer received an application
operation.

## Listener and dialing roles

A serial listener owns one configured point-to-point device. The first inbound
byte makes it ready; acceptance transfers exclusive ownership to one
`OrderedByteStream`. The listener remains unavailable while that stream is
active and reacquires the device only after stream destruction.

One local serial device path cannot simultaneously be the process listener and
an outbound route, and one physical path cannot be assigned to multiple routes
under different line settings. That conservative first increment avoids two
independent TLS initiators racing on one undemultiplexed byte stream. Use a
distinct device for the opposite initiation direction. A future link service
may multiplex roles only with an explicit finite framing and arbitration
protocol.

The simple legacy plaintext `offer`, `flush`, and `serve` commands remain TCP
only because their one-operation protocol relies on TCP write-half shutdown.
The production serial carrier is available through persistent TLS runtime
configuration, where NOS1 and TLS provide semantic close.

## Authenticated stack

Serial changes only carrier establishment and byte movement:

```text
serial-v1 locator
→ SerialTransportConnector / SerialTransportListener
→ OrderedByteStream / ByteChannel
→ owned OpenSSL BIO
→ TLS 1.3 mutual authentication and exact generation/SPKI validation
→ HELLO
→ NOS1 reusable session
→ application operations, receipts, authorization, and durable state
```

No serial address or line setting bypasses TLS or changes peer authority.

## Verification boundary

The focal revision-0580 probe uses bounded POSIX pseudoterminal pairs. It covers
canonical locators, malformed forms, symlink and regular-file rejection,
termios application and restoration, short progress, deadline expiry,
interruption, listener ownership, reconnect, hangup, and a real two-operation
TLS/HELLO/NOS1/receipt session over a PTY bridge.

PTY evidence is local model evidence. It does not establish UART voltage or
clock behavior, USB-adapter quality, cable faults, hardware flow control,
Bluetooth or radio behavior, EMI susceptibility, range, power use, driver
reliability, independent-host behavior, or physical power interruption. Those
are explicit verification debts, not construction vetoes.
