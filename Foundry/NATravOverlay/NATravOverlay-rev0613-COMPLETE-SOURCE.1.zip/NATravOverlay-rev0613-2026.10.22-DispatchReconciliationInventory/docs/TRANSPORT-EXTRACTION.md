# Internal TCP transport extraction — revision 0577

Revision 0577 makes the existing TCP path the first implementation of a narrow
carrier-neutral transport boundary. It is an internal ownership refactor, not a
new carrier and not a protocol revision.

## Result

Higher peer layers now describe reachability with `TransportLocator`, obtain
outbound connections through `TransportConnector`, accept inbound connections
through `TransportListener`, and own connected carriers as
`OrderedByteStream`. Revision 0577 accepted only `tcp`; revision 0580 adds the
explicit production `serial` kind. Every unknown textual or internal kind still
fails with `TRANSPORT_KIND_UNSUPPORTED`, and the private virtual kind remains
unparseable.

The concrete TCP implementation is concentrated in `node/src/transport.cpp`:

- numeric IPv4/IPv6 parsing and host/service rendering;
- nonblocking socket creation, connect, bind, listen, and accept;
- `TCP_NODELAY` setup;
- readiness polling and existing deadline/error classifications;
- owned TCP byte-stream reads, writes, counters, and write-half shutdown; and
- bound-listener host/service reporting.

`node.cpp`, `daemon.cpp`, `peer_session.cpp`, configuration, runtime reporting,
and source-subscription delivery consume the abstract locator, connector,
listener, or stream contracts. They no longer create or configure peer TCP
sockets directly.

## Internal contracts

### Transport kind

```text
TransportKind::tcp = 1
TransportKind::serial = 2
TransportKind::virtual_link = 255  # fixture-private, not configurable
```

No numeric value is persisted or emitted on a wire. The values are internal
bounded discriminators. The configured parser accepts only the canonical names
`tcp` and `serial`; there is no fallback, implicit default, private-virtual
escape, or extension catch-all.

### Locator

A TCP locator contains:

```text
kind = tcp
host = numeric IPv4 or IPv6 text
service = unsigned 16-bit TCP service/port
```

Existing external endpoint text remains exactly:

```text
127.0.0.1:443
[::1]:443
```

Listener service `0` remains permitted for ephemeral binding. Dial service `0`
remains rejected. DNS names remain rejected. Existing TCP configuration keys, `peer=` and `peer_route=` fields, legacy CLI
`--listen`/`--connect` arguments, JSON field names, canonical configuration
output, and persisted route provenance remain unchanged; they map into the
internal TCP locator without migration. Persistent V13+ routes and the runtime
listener may additionally use the explicit `serial-v1|...` locator described in
[`SERIAL-TRANSPORT.md`](SERIAL-TRANSPORT.md).

### Owned ordered stream

`OrderedByteStream` retains the existing `ByteChannel` read/write contract and
adds only carrier ownership facts needed by the present product:

- exact transport kind; and
- an explicit write-half-shutdown operation whose availability is reported by
  `TransportCapabilities`.

TCP supports write half-close. Serial reports that it does not and rejects the
operation rather than pretending carrier teardown has TCP semantics.

Revision 0578 removed the temporary native TLS handle. OpenSSL now consumes the
stream through the owned custom BIO described in
[`TLS-BYTE-CHANNEL.md`](TLS-BYTE-CHANNEL.md). The transport interface therefore
contains no peer-TLS descriptor escape hatch.

### Connector and listener

`TransportConnector::connect` returns one owned `OrderedByteStream` or one
existing bounded failure. `TransportListener` owns the listening carrier,
exposes a readiness handle to the current poll loop, reports its bound locator,
and returns owned accepted streams until the nonblocking listener is drained.

Queues now own complete stream objects rather than bare peer file descriptors.
That makes carrier lifetime explicit and keeps accepted-carrier destruction on
the same bounded queue and worker paths as before.

## Preserved behavior

Revision 0577 deliberately preserves:

- all peer, TLS, HELLO, NOS1, application, local-control, journal, checkpoint,
  backup, custody, configuration, and storage bytes;
- TLS 1.3 mutual authentication, exact generation/SPKI pinning, ALPN, and
  certificate validation;
- numeric endpoint grammar and canonical rendering;
- nonblocking connect/listen/accept behavior;
- `TCP_NODELAY`, deadlines, `poll` accounting, short-I/O accounting, EOF,
  reset, write-closed, shutdown, and error classifications;
- route priority/order, cooldown, retry, session reuse, and failover semantics;
- runtime JSON names such as `endpoint`, `host`, `port`, and `listen`; and
- one normal product executable, `node/bin/natrav-overlay`.

The Unix local-control socket remains a separate local IPC boundary. Its raw
file-descriptor operations in `socket.cpp` and `daemon.cpp` are intentional and
are not peer-carrier leakage.

## Descriptor boundary after revision 0578

The peer connection path no longer has a native descriptor seam. `TlsChannel`
receives `ByteChannel&`, and the custom OpenSSL BIO delegates bounded reads and
writes to that contract.

The daemon poll loop still receives a concrete listener readiness handle. For
TCP it identifies an accept socket; for serial it identifies the exclusively
opened point-to-point TTY while no accepted stream is active. The handle
supplies no peer identity, TLS authority, route authority, or application
semantics. A future non-file-descriptor listener may add a bounded
wakeup/readiness contract without reopening connected-stream TLS design.

## Verification contract

`node/tests/test_transport_extraction.cpp` and
`node/tests/run_transport_extraction.py` cover:

- canonical kind and locator vectors;
- fail-closed unknown textual, enum, locator, connector, and listener kinds;
- IPv4/IPv6 round trips and unchanged zero-service/DNS rejection;
- bound-listener reporting and drained nonblocking accept;
- connector/listener stream ownership and bidirectional exact bytes;
- write-half shutdown and EOF;
- raw TCP client to extracted listener compatibility;
- extracted connector to raw TCP listener compatibility;
- unchanged connect, listen, backlog, and zero-service error classes; and
- source ownership checks that higher peer layers do not instantiate or
  configure TCP sockets.

The registered integration, TLS-security, peer-session, multi-route,
live-configuration, and runtime-inventory suites remain the behavioral
regression boundary for the complete product.

## Non-claims

Revision 0577 itself did not add the custom OpenSSL BIO; revision 0578 added
that adapter, revision 0579 added a private virtual carrier, and revision 0580
added a configured POSIX serial/TTY stream. None of these revisions adds USB
protocol logic, Bluetooth, radio, datagram or packet reliability, relay,
discovery, tunneling, or a transparent bridge. PTY evidence does not establish
hardware portability, independent-host behavior, electrical correctness,
range, interference response, flow-control wiring, or physical-media
performance.

The absence of those environments is recorded verification debt, not a reason
to defer the completed source boundary.

## Revision 0579 proof of the boundary

The carrier-neutral boundary now has a second implementation used only by deterministic fixtures. Unlike TCP, the virtual implementation has no configured locator, connector, or listener registration. Real TLS and reusable peer sessions consume it solely through the extracted stream contract. This validates the boundary before a production non-IP carrier is added.


## Revision 0580 production proof of the boundary

The serial implementation is the first externally configured non-IP stream. It
uses the same locator, connector, listener, ordered-stream, OpenSSL BIO, TLS,
HELLO, and NOS1 contracts as TCP. Its PTY focal suite exercises the production
implementation without exposing a native descriptor above the carrier.

Serial-specific device opening, termios state, deadlines, finite quanta,
hangup, exclusivity, and restoration remain in `serial_transport.cpp`. Higher
peer layers know only the typed locator and `OrderedByteStream`.
