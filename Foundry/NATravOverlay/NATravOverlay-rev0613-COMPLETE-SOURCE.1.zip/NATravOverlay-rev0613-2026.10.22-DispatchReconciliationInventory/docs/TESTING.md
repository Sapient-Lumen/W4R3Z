# Revision 0613 verification focus

The owner-dispatch reconciliation tests exercise exact status, finite
cursor-bounded inventory, complete current V24→V23→V22→V21 authority and retained
state-chain validation, malformed/conflicting/zero/symlinked state, real-UID
authorization, restart, quiesce, drain, lost local-control responses, concurrent
ordinary traffic, lifecycle and expiry metadata, and proof of zero filesystem
mutation and zero peer connections. Static and ASan/UBSan focal runs, the
risk-adjacent matrix, and the complete registered matrix are recorded under
`validation/revision-0613/` and in external delivery evidence. Same-host
process death is not physical power-loss evidence.

---

# Revision 0612 verification focus

The owner-dispatch tests exercise canonical V24 authority, exact retained
current-custodian proof, one durable request reservation before network I/O,
exact duplicate replay without a second connection, fresh-request retry after
peer-response loss, process death and stale-seed recovery, lifecycle changes,
and concurrent ordinary traffic. Sanitizer, risk-adjacent, and complete matrix
results are recorded under `validation/revision-0612/`. Same-host process death
is not physical power-loss evidence.

---

# Testing revision 0606

From the complete source root:

```sh
bash node/build.sh static

PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_custody_authority.py \
  --binary node/bin/natrav-overlay \
  --output /tmp/natrav-0606-custody

PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_matrix.py \
  --binary node/bin/natrav-overlay \
  --output /tmp/natrav-0606-matrix \
  --native-profile focused --timeout 600

bash node/build.sh sanitize
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_custody_authority.py \
  --binary node/bin/natrav-overlay-sanitize \
  --output /tmp/natrav-0606-custody-sanitized --sanitize-probe
```

Every output directory must not already exist. The registered matrix's `focused` native profile runs all checked-in suites while not implying every optional exhaustive native subprofile.

The custody tests use same-host owner-only state directories and generated identities. They exercise exact V21 authority, canonical bundles, durable registration, transfer, acceptance, uncertainty, expiry, restart reconstruction, revocation, final import and exact receipt recovery. They do not establish physical custody, independent-host or hardware behavior.
