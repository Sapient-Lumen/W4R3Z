# Protocol and format boundary — revision 0524

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

**Revision 0525 addition:** [explicit terminal receipt reconciliation](TERMINAL-RECONCILIATION.md) can adopt an exact stored late receipt without altering the original withdrawal/expiry or scheduling allowance. It uses local `NSR4` and reconciled `NSS6` state in existing journal kind 32; it adds no peer request or automatic authority. Ordinary unreconciled state and old format semantics remain unchanged.


## Revision 0519 local control addition

`NOC1` command kind 19 carries one complete NOA1 local source record. It is accepted only through the kernel-authenticated control plane under V14 authoring authority. Issuer and recipient must equal the configured node, and actions are excluded. `evidence-author` / `evidence-amend` return an NATRAV_OVERLAY_LOCAL_AUTHOR_RESULT_V1 local commit account. Peer NOA1/NOS1/TLS formats and admission grants are unchanged; this is not a remote subscribe message. See [local sources](LOCAL-EVIDENCE.md).

## Protected peer stack

The persistent peer path remains:

```text
TCP
→ TLS 1.3 mutual possession proof and exact SPKI generation assignment
→ HELLO/HELLO_ACK node binding
→ NOS1 bounded reusable sequential session
→ NOA1 evidence, correction, receipt, and typed error messages
```

Revision 0517 does **not** add a new peer message. Projection publications remain ordinary NOA1 evidence operations. Epoch-1 publication bytes remain canonical `NPC1`; an explicit replacement epoch uses canonical `NPC2` to retain terminal lineage while the outer evidence record remains a new original. The recipient applies the same authenticated issuer binding, exact evidence-scope authorization, duplicate admission, receipt, rejection, correction, session, and replay rules as any other evidence record.

The explicit one-operation compatibility branch remains separate. Plaintext `serve`/`offer`/`correct`/`flush` are development seams, not persistent-product downgrade modes.

## Unix control protocol

The running control plane uses one length-prefixed request and response per Unix connection:

```text
NOC1 request
NOR1 response
```

The request bytes are not an authentication authority. The daemon obtains Linux `SO_PEERCRED` before reading an untrusted request and applies the accepted exact-UID command policy after bounded decoding. Successful and typed-error JSON may be annotated with the observed UID/GID/PID and required class.

Consumer/projection operations use NOC1 kind 17. The strict inner envelopes are:

| Envelope | Purpose |
|---|---|
| `NCR1` | ordinary consumer and metadata-projection lifecycle |
| `NCR2` | numeric projection creation |
| `NCR3` | automatic projection scheduling |
| `NCR4` | terminal consumer/projection retirement |
| `NCR5` | explicit projection-result publication |

`NCR5` carries command 15 and exactly: consumer name, immutable instance, expected consumer revision, expected processed position, expected projection-result digest, recipient node, and output scope. Strict EOF is required; another consumer command inside NCR5, or publication inside an older envelope, is rejected.

The successful response is:

```text
NATRAV_OVERLAY_PROJECTION_PUBLICATION_V1
```

It reports the stable operation ID, payload/result/source commitments, exact selected frontier, recipient generation/SPKI, current local configuration event, request PID, and current outbox disposition. The current configuration event is operational provenance; it is not placed in the stable NPP1 payload.

## NPP1 projection-result evidence

`NPP1` is a bounded canonical binary payload carried inside ordinary evidence. It binds:

- definition kind (`DOMAIN_SUMMARY_V1` or `NUMERIC_SUMMARY_V1`);
- active or retired lifecycle and immutable projection instance;
- consumer revision, epoch, acknowledged frontier, and acknowledgment count;
- definition, result, source, read-authority, and publication-authority digests;
- source consumer, issuer, and scope;
- recipient node, exact key generation/SPKI, and output scope;
- admission budget and complete source-derived result counters;
- exact numeric unit, scale, sum budget, and interpretation counters when numeric;
- terminal retirement revision/time/final-state commitments when retired.

It contains no source payloads, private paths, requester PID, wall-clock request time, or local owner-path-sensitive runtime configuration digest. The operation ID is:

```text
SHA-256("NATRAV_OVERLAY_PROJECTION_PUBLICATION_OPERATION_V1" || 0x00 || NPP1)
```

The publication-authority digest binds the kernel owner UID, effective read authority, recipient node/generation/SPKI, and output scope. The journal separately binds the mutation to the accepted local configuration event. This separation preserves the same publication identity through compaction, signed/encrypted restore, and explicit owner-path relocation when the result, authority, and target have not changed.

NPP1 is a derived account at a processed frontier. It does not claim physical truth, selection freshness beyond that frontier, or inclusion of source payloads.


## NPC1/NPC2 durable publication channels (0515–0517)

Revision 0517 retains NOC1 kind 18 and advances the strict inner request envelope to `PCR3`. It adds explicit new-epoch selection while continuing to decode strict `PCR1` create/publish/status/retire and `PCR2` automatic scheduling requests. Exact EOF remains mandatory.

A channel publication remains an ordinary NOA1 evidence or correction operation. Epoch-1 publications without terminal lineage retain `NPC1`. Epoch-aware `NPC2` adds the exact epoch and optional terminal-predecessor lineage while preserving the canonical `NPP1` result, channel instance, sequence, finite budget, optional same-epoch predecessor, authority digest, and name. Its operation ID is:

```text
SHA-256("NATRAV_OVERLAY_PUBLICATION_CHANNEL_OPERATION_V1" || 0x00 || NPC1_or_NPC2)
```

The first publication in each epoch is an original. Later publications in that epoch use the ordinary evidence `corrects` field and require a durable predecessor receipt. A replacement epoch is permitted only after an exact durable `REJECTED`, `CANCELLED`, or `EXPIRED` head; its first `NPC2` record has no `corrects` parent and carries explicit terminal lineage instead. No new peer message or downgrade branch is introduced.

Local persistence uses backward-readable `NCH1`/`NCH2` and current `NCH3` channel state inside `NCT1` transactions. `NCH2` adds schedule history; `NCH3` adds epoch and terminal-lineage fields. A transaction may embed the existing ordinary evidence-plus-policy composite or an exact pending-head cancellation. Checkpoint extension `NPH1` preserves the registry. See [publication channels](PUBLICATION-CHANNELS.md) and [publication epochs](PUBLICATION-EPOCHS.md).

## Current public formats

```text
Executable version                  0518
Configuration                       NATRAV_OVERLAY_CONFIG_V13
Runtime status                      NATRAV_OVERLAY_RUNTIME_STATUS_V13
Offline inspection                  NATRAV_OVERLAY_STATE_V7
Local request/response              NOC1 / NOR1
Evidence query                      NEQ1 / response V1 or V2 / NEC1 or NEC2
Incremental feed                    NEF1 / NET1
Consumer/projection requests        NCR1..NCR5
Publication-channel control         NOC1 kind 18 / PCR1, PCR2 or PCR3
Projection publication              NPP1 / response NATRAV_OVERLAY_PROJECTION_PUBLICATION_V1
Publication-channel evidence        NPC1 or NPC2 wrapping NPP1
Publication-channel state/tx        NCH1, NCH2 or NCH3 / NCT1 / checkpoint extension NPH1
Checkpoint emitted                  NCP3
Logical application state           NLS2 plus bounded optional extensions
Authenticated journal               NOAUTH01 / NAR1
Backup container                    NOBACK01
Encrypted backup envelope           NOBENC01
Relocation output                   NATRAV_OVERLAY_STATE_RELOCATION_V1
```

V6–V12 configuration and predecessor checkpoint/state encodings remain readable only where their documented compatibility contract requires it. Older executables reject unfamiliar consumer, retirement, scheduling, or publication material rather than silently dropping its meaning.

## Other local protocol additions retained

- NOC1 kind 15 carries strict `NEQ1` evidence queries.
- NOC1 kind 16 carries strict `NEF1` incremental feed requests.
- NOC1 kind 17 carries durable consumers, projections, schedules, retirement, and one-shot publication.
- NOC1 kind 18 carries strict `PCR1`/`PCR2`/`PCR3` publication-channel requests.
- NOC1 kinds 42/43 carry uncorrelated terminal state-head shutdown/drain.
- NOC1 kinds 44/45 carry ordinary correlated shutdown/drain.
- NOC1 kinds 46/47 carry correlated terminal state-head shutdown/drain.
- `NOSKEY01`, `NOAUTH01`, and `NAR1` are local key/journal formats, not peer negotiation.
- `NOBENC01` is an offline backup envelope, not a transport mode.
- `QUIESCE`, `RESUME`, and `DRAIN_SHUTDOWN` remain bounded local lifecycle requests.

Malformed/trailing requests fail closed. Unknown UIDs are rejected before frame read; listed UIDs without the exact class are denied before command dispatch. Lifecycle gates are checked before mutation. Denial records do not retain request payloads.

See [projection publication](PROJECTION-PUBLICATION.md), [publication channels](PUBLICATION-CHANNELS.md), [configuration](CONFIGURATION.md), [local administration](LOCAL-ADMINISTRATION.md), and [testing](TESTING.md).


## Revision 0516 — automatic publication scheduling

`PCR2` commands 5–7 are automatic enable, pause, and narrow schedule status. Enable/pause carry exact channel instance, channel revision, schedule revision, and grant generation selectors. Enable also carries finite successful-publication and minimum-interval bounds.

`NCH2` retains at most 32 grant generations and marks each automatically created publication with its grant generation. The `AUTO_PUBLISH` `NCT1` transaction embeds the ordinary evidence-plus-policy composite and increments allowance in the same authenticated record. `AUTO_BLOCK` reasons are recomputed during semantic replay from accepted configuration, authority, projection, and predecessor state. No peer wire format changes; generated records remain ordinary `NPC1` evidence/corrections. See [automatic publication](AUTOMATIC-PUBLICATION.md).


## Revision 0517 — explicit publication epochs

`PCR3` command 8 selects the exact channel instance/revision/epoch, exact terminal operation and outcome, exact projection frontier/result, and a bounded reason. Pending and acknowledged heads are ineligible.

`NCH3` stores the epoch for every publication. An epoch-opening revision additionally stores the prior terminal operation, `REJECTED`/`CANCELLED`/`EXPIRED` outcome, actor, and reason. Its `NPC2` evidence is an original with no ordinary correction parent. Later revisions in that epoch remain corrections behind durably acknowledged heads.

The `NEW_EPOCH` `NCT1` transaction contains the revised channel, `NPC2` original, ordinary active-generation delivery policy, and any automatic-grant block. Semantic replay derives the terminal outcome from durable outbox state and rejects altered or detached lineage. Epoch-1 `NPC1` bytes and operation identities remain unchanged. See [publication epochs](PUBLICATION-EPOCHS.md).

## Revision 0518 — route selection below the peer protocol

No peer wire format changed. V13 route selection occurs below TCP/TLS/HELLO/NOS1 and does not create a new peer message or downgrade branch.

A reusable outbound session binds one selected route ID, endpoint, peer node, key generation, and SPKI contract. Another route is eligible only if it authenticates as the same configured peer and selected durable key. A route presenting a different valid certificate fails authentication for that peer.

V13 may attempt several route candidates before an application request is issued. Those connection/session-open probes do not create several durable application attempts. Once the NOA1 request is issued, existing exact response binding, receipt, rejection, duplicate replay, and retry semantics apply unchanged.

Runtime status V12 adds bounded run-scoped route observations. They are operational telemetry, not journal records or proof of physically independent paths. See [multi-route reachability](MULTI-ROUTE.md).

## Revisions 0520–0521 — source delivery and authenticated requests

Local NOC1 control kind 20 carries strict NSR1 provider-manager source-subscription commands. NSE1 is an opaque, bounded source-provenance envelope carried as an ordinary recipient-scoped NOA1 original or correction over TLS/HELLO/NOS1. Corrections name the acknowledged mapped recipient operation, while the embedded original retains its provider-side predecessor. The native `source-envelope-inspect` command validates encoding and digests, not peer identity. See [the exact envelope](SOURCE-SUBSCRIPTIONS.md).

Revision 0521 adds two strict NOA1 application kinds on the already authenticated peer session:

```text
kind 5  authenticated source-subscription request or status request
kind 6  bounded source-subscription response
```

The outer NOS1 operation ID and the request's 32-byte request ID must agree. A response is bound to that same operation. Remote requests carry only a command, immutable grant ID, request ID, and bounded reason; all source, scope, subscriber-key and budget authority comes from the provider's current accepted V15 configuration. Ordinary evidence, receipt, typed-error, TLS, HELLO and session formats are unchanged. See [subscriber requests](SUBSCRIBER-REQUESTS.md).


## Revision 0522 — local automation state, no peer-wire expansion

Revision 0522 adds no peer application kind and changes no TLS, HELLO, NOS1, NOA1, NSE1, or remote subscriber-request encoding.

Local source-subscription requests use `NSR2` for automatic enable, pause and status. Scheduled subscription state uses `NSS3`; legacy `NSR1`, `NSS1`, and `NSS2` remain readable. Existing journal kind 32 / `NST1` atomically carries automatic ISSUE/ACK progress and finite allowance use. The daemon worker invokes the same semantic transition used by persistent replay; it does not bypass the journal or create a second transport protocol.


## Revision 0523 — leased source-subscription peer kinds

The NOA1 application-kind boundary now includes:

| Kind | Strict payload |
|---:|---|
| 5 | V15 source-subscription request/status |
| 6 | V15 response |
| 7 | V16 leased request/status/withdrawal |
| 8 | V16 leased response |

The V16 request adds one immutable lease generation. `WITHDRAW` additionally requires the exact subscription instance, expected revision, bounded reason, and a request ID equal to the containing NOS1 operation ID.

The V16 response format is `NATRAV_OVERLAY_REMOTE_SOURCE_SUBSCRIPTION_RESPONSE_V2`. It adds lease expiry, withdrawal policy, optional terminal kind, pending disposition, exact cancelled operation, and terminal reason. Strict EOF and inner/outer operation binding remain mandatory.

Durable leased state is `NSS4`. Source-subscription journal transactions remain kind 32. `NST2` is used only when the same transition embeds an exact ordinary outbox cancellation; semantic replay binds that cancellation to the retained subscription head, peer generation/SPKI, actor and reason.

## Source succession formats (0524)

Strict local `NSR3` adds command 8, acknowledged lease succession. Ordinary `NSR1/NSR2` encodings are unchanged. `NSE2` successor evidence adds exact predecessor lineage and cumulative position under a distinct operation-digest domain. `NSE1` retains its original bounds. TLS/HELLO/NOA1/NOS1 and remote request kinds are unchanged. See [lease succession](LEASE-SUCCESSION.md).

## Outbox inspection (0530)

Local control kind 23 wraps OBQ1: four-byte magic; length-prefixed recipient and outcome; one-byte optional-operation marker and optional 32-byte operation; uint32 row, complete JSON byte and history limits; length-prefixed cursor; exact EOF. OBC1 binds UID, configuration digest, query/node digest, selected revision, position, expiry, then a 32-byte HMAC tag. No peer wire format changes. [Full metadata and continuation contract](OUTBOX-INSPECTION.md).

## Runtime status mode boundary (0536)

Ordinary local kind 2 remains an empty-body, strict-EOF status request. It now
returns V13 metadata with `storage.logical_state_digest: null` and
`logical_state_digest_mode: NOT_REQUESTED`. Explicit `status --logical-digest yes`
uses new empty-body local kind 25 and computes the unchanged full application
digest under the same state lock as metadata. Both require `INSPECT`. Unknown
kinds and trailing material fail; there is no peer-wire change. Bounded rows and
separate state/configuration/runtime observation fields are described in the
[runtime status contract](RUNTIME-STATUS.md).

## Retained configuration inspection (0538)

[configuration-history](CONFIGURATION-HISTORY.md) supplies exact event/binding lookup and bounded retained-prefix pages under current INSPECT. It omits canonical contents, reason text and relocation paths while preserving their commitments. Prefix selection does not grant authority or establish freshness. Runtime-bound mutation bindings are an explicitly described subset, not the entire effect or local-control audit log. Local request kind 27 (NHC1) introduces no new persistent encoding or peer protocol.

## Local control-history inspection (0539)

Control kind 28 carries strict NHA1 for bounded actual decision/lifecycle inspection. [Control-history format](CONTROL-HISTORY.md) defines exact ordinals, one indexed principal/request/configuration filter, retained-prefix comparison, and response bounds. Existing wire kinds and peer protocols are unchanged.

## Counter-action terminal results (0543)

No new TLS, HELLO, NOS1 or NOA1 message kind is introduced. A terminal counter-action result is an ordinary evidence record whose payload begins `NAC1` and whose scope comes from an accepted V18 action-result rule. Its operation ID is derived from the complete canonical payload.

The result uses the existing outbox, session, response binding, receipt and authenticated terminal-rejection rules. A peer that can transport ordinary evidence needs no action-result-specific framing extension; the recipient must still have an exact evidence authorization rule for the result scope. The embedded local effect receipt is distinct from the outer evidence-delivery receipt. [Complete payload contract](ACTION-RESULTS.md).

## Owner-scoped review history (0548)

Local control kind 35 carries strict `RRH1` observational requests. Required request/provider/scope selection and optional exact review ID return owner-bound immutable summaries and retained-prefix pages. No peer wire format changes. [Wire, authority and page contract](REVIEW-HISTORY.md).

## Revision 0570 — no local-control or peer-wire expansion

`correlated-stop-audit` is an offline CLI operation. Explicit-shape selection invokes the existing strict NOC1 encoders for kinds 44–47 solely to derive the exact established request ID; it does not send a request or add a kind. Exact-ID selection reads the same retained request index after complete authenticated replay.

No NOC1, TLS, HELLO, NOS1, NOA1, journal, checkpoint, backup, application logical-state, permission, configuration, or storage-schema encoding changes in revision 0570. The response is local process JSON format `NATRAV_OVERLAY_OFFLINE_CORRELATED_STOP_AUDIT_V1`. [Contract](OFFLINE-CORRELATED-STOP-AUDIT.md).

## Revision 0572 — CLI-only backup audit and detached custody file

`backup-correlated-stop-audit` is an offline CLI operation. It sends no local or
peer request. Explicit-shape selection invokes the existing strict NOC1 encoders
for kinds 44–47 only to derive the established request ID. The report format is
`NATRAV_OVERLAY_BACKUP_CORRELATED_STOP_AUDIT_V1`.

Detached custody is also outside local-control and peer protocols. Its separate
file format is `NHCUST01` version 1 and is described in
[Detached state-head custody](DETACHED-STATE-HEAD-CUSTODY.md). It is never
embedded in a journal, checkpoint, backup, request, or response.

Revision 0572 adds no NOC1, TLS, HELLO, NOS1, NOA1, journal, checkpoint, backup,
application logical-state, permission, configuration, or storage-schema
encoding. Older binaries reject the new CLI commands rather than reinterpreting
them.

## Revision 0573 — CLI-only custody-constrained opening

The detached custody adapter adds no local-control or peer request kind. It
reads one explicitly named external `NHCUST01` version-1 file, extracts its
exact `NASH1` selector after strict verification, and supplies that selector to
the existing authenticated-state expectation path.

Revision 0573 changes no NOC1, TLS, HELLO, NOS1, NOA1, journal, authenticated
header, checkpoint, backup, application logical-state, permission,
configuration, or storage-schema encoding. Revision 0572 rejects the new CLI
options rather than ignoring or reinterpreting them. [Contract](CUSTODY-CONSTRAINED-STATE-OPENING.md).

## Revision 0574 — CLI-only custody promotion

`state-head-custody-promote` is an offline CLI operation. It sends no local-
control or peer request and adds no request kind. It consumes the existing
external `NHCUST01` version-1 record and existing authenticated state, checkpoint,
and encrypted-backup encodings. The successful process response format is
`NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_V1`.

The replacement selector is derived by the existing canonical `NASH1` encoder
from a completely authenticated and semantically replayed state directory or
signed encrypted backup. No selector supplied by a caller enters publication.

Revision 0574 changes no NOC1, TLS, HELLO, NOS1, NOA1, journal, authenticated
header, checkpoint, encrypted-backup, application logical-state, permission,
configuration, storage-schema, or product-limit encoding. Revision 0573 rejects
the new command as unknown. [Contract](CUSTODY-PROMOTION.md).


## Revision 0575 — CLI-only custody-promotion outcome audit

`state-head-custody-promotion-audit` is an offline CLI operation. It sends no
local-control or peer request and adds no request kind. It consumes existing
`NHCUST01`, `NASH1`, authenticated-journal, checkpoint, and signed encrypted-
backup encodings. The successful response format is
`NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_OUTCOME_AUDIT_V1`.

The derived successor selector and deterministic successor custody record are
constructed internally after complete source authentication and semantic
replay. The operation performs no compare-and-swap and writes no durable state.

Revision 0575 changes no NOC1, TLS, HELLO, NOS1, NOA1, journal, authenticated
header, checkpoint, encrypted-backup, application logical-state, permission,
configuration, storage-schema, custody, state-head, or product-limit encoding.
Revision 0574 rejects the new command as unknown.
[Contract](CUSTODY-PROMOTION-OUTCOME-AUDIT.md).

## Revision 0576 — CLI-only detached custody-promotion intent

`state-head-custody-promotion-intent-create` is an offline CLI operation. It
sends no local-control or peer request and adds no request kind. Its output file
is the separate external canonical format `NHCPI001` version 1, described in
[Detached custody-promotion intent](CUSTODY-PROMOTION-INTENT.md).

The format binds complete old `NHCUST01` bytes, intended generation, exact
authenticated source representation and trust identities, verified successor
relationship, and an internally derived `NASH1`. It is never embedded in a
journal, checkpoint, backup, local-control request, peer message, or response.
It is evidence only; promotion and outcome audit revalidate the source, custody,
and complete intent.

`state-head-custody-promote` and
`state-head-custody-promotion-audit` accept `--intent FILE` as a CLI-level
alternative to their complete inline old-account forms. No new successful peer
or local-control response format is introduced. Detached promotion retains
`NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_V1`; detached audit
retains
`NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_OUTCOME_AUDIT_V1` and
marks `input_mode` as `DETACHED_INTENT`.

Revision 0576 changes no NOC1, TLS, HELLO, NOS1, NOA1, journal, authenticated
header, checkpoint, encrypted-backup, application logical-state, permission,
configuration, storage-schema, `NHCUST01`, `NASH1`, or product-limit encoding.
Revision 0575 rejects the new creation command and detached-consumption syntax.

## Revision 0577 — internal TCP transport extraction only

Revision 0577 introduces no protocol or persisted representation. The internal
`TransportKind`, `TransportLocator`, `TransportConnector`, `TransportListener`,
and `OrderedByteStream` types are not serialized into peer messages, local
control, journals, checkpoints, backups, custody artifacts, or configuration.

Existing external endpoint text remains the same numeric IPv4/IPv6 host and
service syntax. Runtime JSON retains existing `endpoint`, `listen`, `host`, and
`port` field names and values. TLS 1.3 records, ALPN, certificate verification,
HELLO exchange, NOS1 sessions, application frames, and close behavior retain
their existing encodings.

Revision 0577 changes no NOC1, NOR1, TLS, HELLO, NOS1, NOA1, journal,
authenticated header, checkpoint, backup, logical-state, configuration,
permission, storage-schema, `NHCUST01`, `NHCPI001`, `NASH1`, or product-limit
encoding. Revision 0576 and revision 0577 therefore interoperate over the same
configured TCP route subject to their existing identity and authorization
rules. The new version/feature account is process metadata, not a peer-wire
negotiation.

[Internal transport contract](TRANSPORT-EXTRACTION.md).


## Revision 0578 — TLS transport plumbing only

Revision 0578 introduces no peer, local-control, or persisted representation.
The custom OpenSSL BIO is an in-process adapter between the existing
`ByteChannel` contract and the existing TLS 1.3 state machine. It does not add a
TLS extension, ALPN value, carrier marker, route field, negotiation bit, or
fallback mode.

TLS records, certificate presentation, `natrav-overlay/1` ALPN, HELLO, NOS1,
application frames, receipts, close-notify, and all authenticated and durable
encodings remain unchanged. Revision 0577 and revision 0578 therefore
interoperate over the same configured TCP route subject to the same identity,
generation, authorization, and storage rules. The new
`tls_byte_channel = OPENSSL_BYTE_CHANNEL_BIO_V1` account is local process
metadata, not a wire capability.

[Internal TLS adapter contract](TLS-BYTE-CHANNEL.md).

## Verification formats are not peer-wire formats

`NVCS0001` deterministic schedules and `NVTR0001` operation traces are local verification artifacts. They never traverse TLS, HELLO, NOS1, or application frames and do not change any peer-wire encoding.

## Revision 0580 — configured serial carrier, no peer-wire revision

Revision 0580 adds the external configuration locator
`serial-v1|path=...|baud=...|data=...|parity=...|stop=...|flow=...` and an
in-process POSIX TTY implementation of `OrderedByteStream`. The locator and its
line settings are local reachability policy. They are not serialized into TLS,
HELLO, NOS1, application frames, receipts, journals, checkpoints, backups,
custody artifacts, or logical state.

Existing numeric TCP locator bytes remain unchanged. Serial and TCP both enter
the same OpenSSL BIO and TLS 1.3 state machine. Certificate proof, exact peer
node, key generation, SPKI pin, ALPN, HELLO, session, application, receipt,
authorization, and durable-state semantics are unchanged. No line path, device
number, baud rate, or adapter observation becomes peer identity.

A serial stream reports no TCP-style write-half shutdown. Persistent sessions
close with the existing NOS1 CLOSE/CLOSE_ACK and TLS close-notify exchange;
carrier teardown alone is not a receipt. The legacy plaintext one-shot commands
remain TCP-only.

Revision 0580 changes no NOC1, NOR1, TLS, ALPN, HELLO, NOS1, NOA1, journal,
authenticated header, checkpoint, backup, logical-state, permission,
storage-schema, `NHCUST01`, `NHCPI001`, `NASH1`, or product-limit encoding.
Revision 0579 rejects the serial locator rather than interpreting it as TCP.

[Serial carrier contract](SERIAL-TRANSPORT.md).
