# Read-only owner dispatch reconciliation

Revision 0613 adds two authenticated local-control observations over the durable
V24 owner-dispatch state created in revision 0612. They exist so an owner can
reconcile a lost local-control response without submitting another mutating
request.

## Commands

```text
natrav-overlay custody-dispatch-status \
  --control PATH \
  --activation ID --activation-generation N \
  --dispatch-request HEX64 [--deadline-ms N]

natrav-overlay custody-dispatch-inventory \
  --control PATH \
  --activation ID --activation-generation N \
  [--cursor HEX64] [--limit N] [--max-bytes N] [--deadline-ms N]
```

The default inventory page limit is 32 records; the implementation accepts at
most 64. The default JSON ceiling is 32,768 bytes and the absolute ceiling is
60,000 bytes. Status output is bounded to 16,384 bytes. Existing local-control
frame, deadline, read-quantum, write-quantum, receive, UID, class, quiesce, and
drain constraints continue to apply.

## Exact authority and state chain

Each operation leases the current accepted configuration and resolves the named
V24 activation at the exact generation. It proves the activation's immutable
V23 receiver, outbound V22 rule, V21 grant, enabled route commitment, local and
peer signing generations, certificate commitments, finite limits, expiry, and
lifecycle.

Status then follows the named canonical dispatch identity through exactly one
regular, nonsymlink dispatch-index entry to exactly one V22 case. It validates
the owner-dispatch record, retained signed offer, custody-envelope digest,
reverse envelope index, attempt reservation, local result metadata, and any
retained acceptance metadata. Missing, malformed, zero, noncanonical,
conflicting, cross-bound, or symlinked state fails closed.

Inventory validates all bounded entries before pagination, sorts canonical
request identities lexicographically, and returns only records strictly after an
optional cursor. A cursor is an observation position, not a retry token or
snapshot guarantee. Revision 0614 is reserved for explicit cross-page snapshot
commitments.

Historical dispatch records remain observable after later explicit requests
advance the shared V22 attempt counter. A pending record may account only for
the exact one-increment durability boundary between request reservation and
attempt publication; wider disagreement is rejected.

## Lifecycle behavior

ACTIVE, RETIRED, expired, and REVOKED V24 authority can be reported as metadata.
Observation does not weaken the mutating policy. In particular, REVOKED state
never permits remote-acceptance replay or returns retained acceptance bytes.
The output identifies durable result and acceptance state through bounded
metadata and cryptographic commitments only.

## Negative authority

Neither observation operation can:

- open a peer connection or send a NOS1 message;
- reserve, increment, retry, or repair an attempt;
- create a directory, record, index entry, temporary file, or journal event;
- select, discover, replace, or fail over a route;
- export or import custody/application bytes;
- schedule onward custody or forwarding; or
- claim application success, an exact application receipt, or delivery.

The implementation uses read-only regular-file and directory validation rather
than the existing repairing lookup path. Tests compare the full state-tree
snapshot before and after observation and hold a zero-connection peer listener
to prove both boundaries.

## Verification boundary

The focused runtime suite covers exact lookup, single-record cursor pages,
malformed and conflicting state, symlinks, real-UID denial, restart,
quiesce/drain, lost-response reconciliation, concurrent ordinary traffic,
lifecycle transitions, expiry, zero mutation, and zero network attempts. Static
source-authority checks additionally reject repair and transport call paths.

These results are same-host evidence. Process death by SIGKILL is not abrupt
physical power loss, and the release has no independent security audit or formal
protocol proof.
