# Bounded pending-delivery selection — revision 0532

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

The persistent C++ peer scheduler selects work without a full `StateSnapshot`, logical-state hash, inbound-evidence copy, consumer/subscription copy, or whole-outbox payload copy. This is an internal implementation change: commands, accepted configuration versions, peer protocols, journal kinds, checkpoint envelopes and storage schema 2 are unchanged.

## Derived readiness, not another state authority

Every ordinary outbox-index update also updates `DeliveryIndex`. Pending records occupy per-recipient metadata indexes; a receipt, rejection, cancellation or expiry removes the record. Policy attachment, begun attempts, failures, retry and rebind update it. Existing composite enqueue/cancel transitions use the same decoder hooks. Normal journal replay and checkpoint decoding rebuild the indexes. Compaction does not persist them as another independently trusted file.

Each peer has an expiry index, policy-initialization and exhausted-attempt sets, and a readiness index for each pending generation/SPKI binding. Each time index is an AVL tree ordered by stable queue position and augmented with the minimum eligible time below each node. A search follows one bounded-height path to the earliest queued eligible item. It does not walk every delayed predecessor or promote an unbounded collection from a future-time heap.

Readiness considers only the peer's currently configured nonrevoked generations, at most eight under the existing parser bound. Unknown or removed generations remain unresolved rather than being redirected; expiry is indexed independently. Retired-but-trusted generations preserve their existing delivery semantics. Configured identity remains authoritative, never the route endpoint.

Tree time comparisons are evaluated afresh against the supplied wall-clock value. The index does not assume that time only moves forward. This does not repair the existing system-wide wall-clock sensitivity of persisted expiry and backoff anchors.

A nonempty selection returns at most one payload-free metadata ticket. If policy initialization, elapsed expiry or exhausted attempts require maintenance, at most one such transition occurs that turn. The oldest queued maintenance item takes precedence; otherwise the earliest eligible queued operation is selected. A removed route no longer triggers a sweep of the entire outbox. Peers retain their independent threads and transition locks.

The pending predicate and outbound component of lifecycle pending counts use the derived index's exact cardinality. They no longer scan all historical outbox entries. Action counting remains separate.

## Selected state is rechecked, not trusted

The ticket binds the stable slot and operation identity, immutable record digest, recipient, current run-scoped operation version, bounded policy and attempt metadata, and accepted configuration-event reference. It contains no payload, error text, receipt, or transition-history vector. It is an internal value, not a wire token, durable administrative selection, or permission grant.

The scheduler retains the existing immutable configuration lease and peer-transition mutex. It checks the selected pending state before route work, checks it again while beginning the durable application attempt, and checks it before copying the record. A cancellation, receipt, rebind or other operation-version change invalidates the ticket. The next turn selects again. This is distinct from the durable semantic commitments used by [conditional outbox administration](CONDITIONAL-OUTBOX.md).

The final copy contains only the selected record. No transition history is copied. Session opening uses the existing operation-ID overload, and reusable-session capacity checks use the exact validated NOA1 encoded length without serializing payload bytes.

V13 and later retain this ordering:

```
metadata selection and current-state check
→ bounded configured route probes
→ TCP / mutual TLS / pinned generation / HELLO / NOS1 opening
→ selected-state and expiry revalidation
→ synchronized begun application attempt
→ exact selected record copy
→ application exchange and ordinary durable outcome
```

Consequently, unavailable routes cause neither payload copies nor issued application attempts. V6–V12 still begin their legacy durable attempt before route establishment, but also avoid payload copies when establishment fails. Neither path changes backoff, attempt limits, response correlation, recipient receipts, terminal-error classification, cancellation/rebind ordering or quotas.

A copy is not an external-effect guarantee. The existing peer-transition lock remains held across the bounded exchange; cancellation cannot recall already transmitted bytes. Configuration publication remains subject to the existing bounded lease wait. This increment is neither lock-free nor multiplexed transport.

## Work observations

Each routed peer's existing runtime status has a new additive `delivery_selection` object:

| Field | Measured scope |
|---|---|
| `calls` | Nonempty-peer selection calls |
| `tree_nodes_visited` | Search-loop node visits across expiry/readiness AVL searches |
| `key_buckets_checked` | Currently permitted generation buckets examined |
| `metadata_records_read` | Authoritative records accessed to construct selection tickets; zero or one per call |
| `payload_records_copied`, `payload_bytes_copied` | Selected record copies immediately before actual application exchange |
| `stale_selections` | Tickets rejected by a current-state/time check |
| `maintenance_transitions` | Policy, expiry or attempt-limit transitions accepted from selected metadata |

These are run-scoped, independently sampled diagnostic counters, not durable quotas or a transactionally coherent metrics snapshot. Search-loop visits are not every memory load. Direct revalidation of the same selected record, configuration lookup, map comparisons, journal application, TLS encoding/copies, outbox transmission, startup replay, status rendering and other application workers are not included in the selection counters.

The API does not claim that the whole daemon avoids every snapshot: generic `status`, initial configuration validation, some legacy control actions, final shutdown reporting and other retained paths still do broader work. The scoped improvement is the ordinary peer-delivery loop and pending predicates.

## Tests and measured limits

`run_delivery_selection.py` exercises:

* A sender with 8,192 independently encoded unrelated inbound records (16 MiB payload), 4,096 settled outbox entries, and real live work for two peers. Failed route probes copy no payload; successful exchanges copy only the 20 and four selected records respectively.
* 4,096 delayed pending records followed by one ready record. One authoritative metadata record is selected, its 64-byte payload is copied, and the delayed records remain pending. Compaction/restart rebuild readiness without promoting them.
* A real conditional cancellation between selection and dispatch, followed by progress for the next queued operation. A separate race rebinds a selected retired generation to the configured active generation before route establishment.
* Expiry after route removal, terminal membership after checkpoint replay, and actual pending delivery after keyed audit, compaction, signed encrypted restore, relocation and route activation.

The large histories are synthetic legacy fixtures processed by the normal decoder; they are not claims of thousands of live authenticated network admissions. Their startup replay allowance is declared separately (30 seconds), while the ordinary 2-second V13 fixture control/I/O settings remain unchanged. No timed pause is active in work measurements.

`test_delivery_index.cpp` uses independent ordered-map/vector references across 65,537 time-index entries, 20,000 time mutations, 4,096 queue records and 12,000 membership/policy mutations. It covers backwards clock movement, equal deadlines, maximum unsigned time, removal, rebind-equivalent bucket movement, revoked/absent bindings, maintenance precedence and AVL invariants. All ordinary index nodes are exercised, not a parallel imitation of the production algorithm.

The opt-in `NATRAV_OVERLAY_TEST_DELIVERY_SELECTION_PAUSE_MS` hook pauses the first ready ticket for a peer and temporarily releases its transition mutex so the race test can apply a real administrative action. It is absent in ordinary operation; no source-validity, key, receipt or deadline check is bypassed. Final revalidation must reject the stale ticket.

The negative control deliberately fails to remove terminal records from readiness. Correct state revalidation still prevents sending those records, but their stale queue head can hide later eligible work. The regression must detect the resulting loss of progress; it is not represented as a successful unauthorized send.

## Boundaries

Index storage grows with pending records, in addition to existing all-operation inspection indexes. There is no new retention reclamation or constant-memory database claim. Each tree update is bounded by tree height, while generation selection has the existing eight-key bound. An arbitrarily large number of expired records needs multiple cooperative turns, not one atomic sweep.

Selection still shares the state mutex and configuration/peer synchronization. Startup, checkpoint verification and administrative commitments retain broader costs. Ordinary status now uses [bounded metadata](RUNTIME-STATUS.md), and outbox quota admission uses [exact derived aggregates](PENDING-CAPACITY.md). This work does not establish independent host failure domains, physical power-loss behavior, freshness, split-brain prevention, remote recall or universal static-binary portability. See [current validation](../validation/VALIDATION.json) and [attempts](../validation/ATTEMPTS.md) for completed versus interrupted observations.

## Subsequent response work

Revision 0533 also removes the broad ordinary submission-reply snapshot. See [submission responses](SUBMISSION-RESPONSES.md). The delivery-selection contract and its accounting are unchanged; broader startup/status costs remain. Revision 0535 also removes retained-history scans from quota admission through [exact pending-capacity aggregates](PENDING-CAPACITY.md).
