# Private finite packet-link service

Status: **private construction boundary; not a configured NATravOverlay carrier**.

The service converts a finite packet port into an ordered, reliable byte-bearing
stream core. It does not define peer identity, trust, authority, discovery, routing,
or relay policy. A packet address, interface identifier, device path, or adapter
identity is reachability metadata only. TLS and the authenticated overlay remain
above this service.

## Canonical records

`NPL1` frames use a 40-byte big-endian header, a finite payload, and an IEEE CRC-32
over the header with the CRC field zeroed plus the payload. Canonical frame kinds
are DATA, ACKNOWLEDGEMENT, FINISH, and RESET. Reserved fields are zero and malformed,
noncanonical, oversized, or integrity-failing frames are rejected.

`NPLS0001` fault schedules are sorted, duplicate-free, bounded records keyed by
direction and packet ordinal. `NPLT0001` traces bind each deterministic disposition
to direction, ordinal, due tick, packet size, and packet CRC. These encodings are
private verification artifacts in revision 0581; they are not yet a public wire
compatibility promise.

## Finite ownership

Every allocation has a declared limit: MTU, message size, aggregate reassembly,
delivery buffering, in-flight data, control frames, receive work per pump, retry
count, expiry, packet queue, schedule length, duplicate-suppression history, and
trace length. Exhaustion produces backpressure, expiry, reset, or a recorded terminal
failure; it does not silently allocate without bound.

## Reliability model

Application writes are fragmented into canonical DATA frames. Each fragment is
acknowledged independently. Unacknowledged frames are retransmitted only within a
finite retry and age budget. Reassembly tolerates packet loss, duplication, delay,
corruption, and reordering while delivering complete messages in order. FINISH binds
the first message identifier that may not appear after closure, so an early FINISH
does not overtake already-sent data.

## Negative controls

Revision 0581 does not add a route locator, connector, listener, device scanner,
peer discovery mechanism, relay, second executable, or transparent forwarding.
Normal configuration cannot select this service. The next boundary is an owned
`OrderedByteStream` adapter exercised beneath the existing OpenSSL BIO, TLS 1.3,
HELLO, NOS1, application, receipt, and close paths.

## Assurance boundary

The deterministic model can establish canonical encoding, finite state, replay, and
algorithmic recovery within the executed cases. It cannot establish radio range,
interference behavior, modem firmware quality, electrical correctness, airtime
fairness, regulatory compliance, power consumption, independent-host scheduling,
or physical power-loss behavior. Missing access to those facilities is verification
debt, not shame and not a construction veto. Unsupported assurance claims remain
forbidden; continued construction remains mandatory.
