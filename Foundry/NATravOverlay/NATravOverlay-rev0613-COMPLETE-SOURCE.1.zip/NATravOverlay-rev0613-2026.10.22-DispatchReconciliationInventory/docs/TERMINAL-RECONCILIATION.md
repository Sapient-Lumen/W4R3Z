# Explicit terminal receipt reconciliation — revision 0525

Revision 0556 adds [explicit structural selector alternatives](STRUCTURAL-SOURCE-SELECTORS.md) and opt-in compact responses. The legacy complete-state selections documented below retain their exact meaning. Structural input is a distinct committed request type, not a renamed legacy digest.


Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Purpose and exact boundary

`source-subscription-reconcile` is a provider-local administrative transition. It adopts one **already durable, exact outbox receipt** into one withdrawn or expired finite subscription that still has exactly one issued but unacknowledged source. It does not poll the recipient, issue evidence, cancel an operation, infer delivery from a successful connection, or accept a caller-supplied receipt as proof.

Ordinary terminal subscriptions remain frozen. Neither an arriving receipt nor an authenticated remote status/request/withdrawal automatically advances them. Reconciliation is separate from succession: after explicit reconciliation, the existing `source-subscription-succeed` may adopt the now fully acknowledged terminal frontier under a distinct accepted grant.

## Select then commit

Read the provider's owner-only `source-subscription-status`. It now includes an exact `terminal_digest`, the latest durable `head_receipt` when present, and optional `reconciliation` provenance.

```text
source-subscription-reconcile --control PATH --grant ID
  --instance HEX64 --expected-revision N
  --state-digest HEX64 --terminal-digest HEX64
  --source-operation HEX64 --delivery-operation HEX64
  --receipt-digest HEX64 --reason TEXT
```

`state_digest` commits the complete observed terminal subscription; it is not the node's complete logical-state digest. `terminal_digest` separately commits the original withdrawal/expiry account. Source operation and recipient-specific delivery operation are intentionally different identities. `receipt-digest` selects the receipt that the provider has already synchronized, including its disposition, recipient sequence, recorder, and record digest.

The actual kernel UID must own the subscription and retain current explicit `SOURCE_DISCLOSE` permission and the unchanged exact disclosure rule. Its retained subscriber generation and SPKI must still exist and must not be revoked. A retired-but-not-revoked configured key can remain valid for reconciliation. No active network route is needed to read a previously committed receipt. `ALL`, `INSPECT`, source authoring, and remote subscriber identity do not confer this local authority.

Permission is checked after complete request decoding under a stable accepted configuration; state selection and commit share the state mutex. Current policy, not authority at socket opening, governs the operation. There is no new configuration version.

## Receipt and result semantics

Only one outstanding mapping is possible in this subscription design. Reconciliation requires its actual durable receipt to bind the exact delivery operation, recipient/recorder, evidence-record digest, and retained delivery-policy generation/SPKI. Pending, rejected, cancelled, expired, and missing receipts cannot be acknowledged by assertion. The receipt is not accepted from the command's payload.

One synchronized kind-32 `NST1` transition named `RECONCILE_RECEIPT`:

- increments subscription revision and acknowledged position by one;
- attaches local acknowledgment event/time/PID to the exact retained source mapping;
- clears the outstanding flag;
- records the preceding complete-state commitment, terminal commitment, source/delivery identities, receipt commitment, current configuration event, actual manager UID/PID, request digest, reason, and time.

The original `termination` object is unchanged. Lease clock, terminal state, issue history, used bytes, grant limits, remote-admission identity, and every automatic-grant field are unchanged. There is no new successful automatic step, no refund, no new source selection, and no fabricated historical acknowledgment time. The new time is the local adoption time, not a claim about when the recipient received bytes.

An exact retry before successor adoption returns `ALREADY_RECONCILED` without a second successful state transition. Different selectors or intent conflict. After a successor has adopted the terminal instance, even that old reconciliation request is rejected with `SOURCE_RECONCILIATION_ADOPTED`; the predecessor's committed meaning cannot change beneath its successor. Current authority is required for idempotent retries too.

## Retained representation and strict replay

`NSR4`, local source-command value 9, adds the five exact 32-byte commitments after the common instance/revision fields, followed by the bounded reason. It is accepted only for reconciliation. `NSR1` through `NSR3` retain their preceding encodings. No peer wire kind or network transport changes.

Only reconciled state uses `NSS6`. It extends the finite leased encoding with an explicit optional succession marker and one immutable reconciliation account. States without reconciliation retain `NSS1` through `NSS5`. The existing `NST1` transaction and checkpoint subscription collection carry the new encoding. Older executables reject it, rather than dropping the adoption history.

Validation reconstructs the exact **pre-reconciliation** terminal state, checks its original legacy invariants and full digest, and recomputes the only permitted acknowledged-state change. The normal checkpoint decoder performs the same validation against the actual retained outbox receipt. Neither outer checksums nor a supplied receipt digest bypass semantic validation. The old automatic allowance and original withdrawal/expiry request still reconstruct exactly.

The reconstructed original terminal state is temporary bounded validation work, not a second persisted history tree. One reconciliation account is retained per terminal subscription. Registry, disclosure, payload, and encoded-subscription size limits are unchanged.

## Independent commitments

The receipt commitment is SHA-256 of `NATRAV_OVERLAY_SOURCE_DURABLE_RECEIPT_V1`, a zero byte, and the strict canonical NOA1 delivery-receipt encoding. The terminal-account commitment uses domain `NATRAV_OVERLAY_SOURCE_TERMINAL_ACCOUNT_V1` and a zero byte, then the strict terminal fields in their stored order: kind, lease generation, configuration event, time, pending disposition and optional cancellation, actor node/generation/SPKI, optional request ID, request digest, and reason. Text is 16-bit length-prefixed; counters are big-endian.

These commitments are exact selectors and integrity bindings, not portable signatures. The already admitted receipt relies on the existing authenticated delivery path and the provider's durable state. Unkeyed state does not resist a hostile writer replacing complete consistent history. Keyed state authentication still requires independent freshness expectations to detect valid rollback.

## Tested continuation

The new suite uses real compiled nodes and a controlled reply-drop hook: a recipient synchronizes a source but its first reply is lost. Duplicate-safe replay returns the original receipt sequence without another recipient admission. Eight concurrent exact adoption requests have one committing winner. A newly accepted successor then delivers a correction pointing to that same acknowledged recipient operation.

Other cases cover exact selector changes, real different UID ownership, independently encoded NSR4 requests crossing live revocation, missing/cancelled/rejected receipt refusal, natural expiry, terminal automatic-grant preservation and key revocation, reconciliation of a successor that itself inherits an older frontier, real process kills, semantic journal/checkpoint corruption with recomputed checksums, keyed audit, compaction, signed encrypted backup/restore, and relocation. See [validation](../validation/VALIDATION.json) and [attempts](../validation/ATTEMPTS.md) for completed profiles and adverse attempts.

## Deliberate limits

Cancellation does not create a receipt or a recipient correction parent. This command cannot repair a genuinely unacknowledged cancelled/expired/rejected source and does not silently skip it. An explicit discontinuity design would be a separate operation.

The original subscriber's withdrawal remains withdrawn. Administrative receipt adoption does not renew its consent, lease, budgets, or automation. A successor still requires its own newly accepted finite grant. Acknowledgment is evidence of the recipient's earlier durable admission, not assurance that a recipient restored to an older snapshot still retains that record.

No remote reconciliation command, key-policy migration, registry reclamation, evidence-truth guarantee, snapshot freshness authority, distributed ownership, split-brain protection, or physical-power-loss guarantee is added. Tests use one Linux kernel and owned laboratory resources.
