# Serial model succession and heterogeneous progress — revision 0599

Revision 0599 strengthens the existing `FRAMED_SERIAL_PACKET_ADAPTER_V1`
without changing NSP1, NAPA0001, NPL1, TLS, HELLO, NOS1, application, receipt,
local-control, journal, checkpoint, backup, custody, or storage encodings.

## Exact line-rate budget

For a complete datagram of `N` bytes, the NSP1 unescaped size is `N + 22`.
Canonical escaping can double every unescaped byte, and two delimiters are
required, so the exact upper bound is:

```text
maximum_wire_bytes(N) = 2 * (N + 22) + 2
```

For an explicitly configured line with `B` bits per character and baud `R`,
the lower bound on worst-case serialization time is:

```text
ceil(maximum_wire_bytes(N) * B * 1000 / R) milliseconds
```

The adapter now rejects a frame lifetime shorter than that lower bound with
`SERIAL_PACKET_TIMEOUT_TOO_SHORT`. This prevents an operator from authorizing a
profile that cannot serialize one worst-case frame even in the idealized line
model. Flow-control stalls, kernel scheduling, driver latency, USB buffering,
and physical signaling remain additional debt; the computed value is a lower
bound, not a delivery promise.

At 8N1, a 256-byte packet at 1,200 baud requires at least 4,650 milliseconds.
A 512-byte packet at 115,200 baud requires at least 93 milliseconds. These exact
vectors are checked by the native framing probe and by the supervised adapter
boundary.

## Deterministic whole-frame reordering

The PTY null-modem fixture now holds one complete canonical NSP1 frame and
releases it after the following frame. This is genuine datagram reordering,
not merely delayed bytes. The finite packet service above NSP1 remains
responsible for packet ordering and duplicate suppression. The physical
framing layer does not acquire retransmission or peer identity authority.

The same bounded fixture still injects loss, corruption, duplication, delay,
truncation, and noise. Every action is keyed by a finite frame ordinal and
recorded as structural evidence. TLS ciphertext is not used as replay identity.

## Actual PTY replacement under exact authority

The complete-node fixture replaces the route-side PTY object while leaving the
opposite listener-side PTY open. It allocates a new PTY before closing the old
master, proving that the replacement has a distinct pathname. Closing the old
master causes the old adapter carrier to fail. The node is not permitted to use
the new path until the owner accepts:

- adapter profile generation 2 with the exact predecessor profile digest;
- endpoint generation 2 with the exact predecessor endpoint digest; and
- a route reference to that exact endpoint generation.

Recovery then requires a different child process, a new carrier, and fresh
TLS/HELLO authentication. A stale startup file cannot roll the accepted
successor back after node restart. The old path is not rediscovered or reused.

## Heterogeneous carrier progress

During the serial replacement interval, the same node retains an unrelated
ordinary TCP route to a third authenticated peer. That obligation completes and
receives an exact receipt while the serial peer is unavailable. This establishes
independent scheduler progress across heterogeneous configured carriers. It does
not make one peer reachable through an unconfigured fallback and does not add
carrier negotiation, transparent forwarding, or relay.

## Queue exhaustion

The one-record receive-queue test presents two complete frames. The first is
retained; the second is dropped whole under the declared finite bound. No
partial datagram becomes visible. After the first is consumed, retransmission
of the second can be accepted. Outbound admission likewise returns `BUSY`
without partial queue ownership, and an unfinished queued frame expires rather
than consuming resources indefinitely.

## Evidence and assurance boundary

The focal suite uses actual PTY character devices, the descriptor-3 NAPA
boundary, the pinned product ELF, three complete persistent nodes, real TLS 1.3
mutual authentication, durable obligations, and exact receipts. PTY replacement
and line-rate arithmetic are model evidence only.

They do not establish UART clock accuracy, USB-adapter buffering, electrical
levels, parity-error reporting, flow-control wiring, modem-control behavior,
driver reliability, interference, range, power consumption, or physical power
loss. Missing access to those environments is verification debt, not a reason
to stop construction and not permission to claim assurance that was not
observed.
