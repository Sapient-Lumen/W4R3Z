# Bounded configuration history — revision 0538

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Purpose and authority

`configuration-history` reads retained configuration events and runtime-mutation bindings from the running state owner. It does not construct a full `StateSnapshot`, serialize the logical application, reopen obsolete identity paths, or copy evidence payloads. It is observational and requires the connected kernel UID's **current INSPECT** after bounded request decoding. The common configuration-publication lease is retained through selection and response encoding; the state mutex protects the entire page. It is available during RUNNING, QUIESCED, and DRAINING while the control endpoint remains alive. No new permission or configuration version is introduced.

The API is **node-wide administrative metadata**, not per-author scoped evidence access. SUBMIT alone is insufficient. Every request reauthorizes; a saved prefix is not a capability, policy, mutation condition, or permission to activate/roll back. Already authorized bounded bytes may finish transmitting after a later revocation, as with the existing control plane.

## Commands and selections

```sh
./node/bin/natrav-overlay configuration-history \
  --control state-a/control.sock --section events --limit 16 --max-bytes 8192

./node/bin/natrav-overlay configuration-history \
  --control state-a/control.sock --section events --ordinal 2

./node/bin/natrav-overlay configuration-history \
  --control state-a/control.sock --section bindings --event 2 --limit 16
```

`--section` is `events` (default) or `bindings`. `--ordinal` selects exactly one one-based event/binding in its section. `--event` is an exact configuration-event filter **only for bindings**; it is conjunctive with an optional binding ordinal. Missing exact ordinals and rejected events with no bindings return an empty selection, not an invented event. Exact ordinal and nonzero offset cannot be combined.

A first page captures its section's retained length as `through` and returns `prefix_digest`. Continue using:

```sh
./node/bin/natrav-overlay configuration-history \
  --control state-a/control.sock --section bindings \
  --through COUNT --prefix-digest HEX64 --offset NEXT_OFFSET \
  --limit 16 --max-bytes 8192
```

Both `--through` and `--prefix-digest` are required together, including when selecting an explicit empty prefix (`through=0`). A nonzero offset requires that pair. Offset is zero-based within the selected/filter-matching prefix. Repeat filters for ordinary continuation; deliberately changing filters on the same prefix creates a different selection, not a changed historical prefix. Row/byte budgets may change. An authorized second principal may use the same content prefix: current INSPECT, not a UID hidden in a token, controls access.

## Response and budgets

`NATRAV_OVERLAY_CONFIGURATION_HISTORY_V1` contains `rows`, exact `selected_total`, `returned`, `next_offset`, `more`, `through`, and `prefix_digest`. `retained_count_observed` and `active_event_observed` describe the current observation; `prefix_active_event` describes the selected event prefix and is null for binding pages. These quantities need not refer to the same time. Rows retain their global section ordinals.

Bounds are 1–64 rows, 2,048–60,000 complete annotated JSON bytes, 256 retained configuration events, and the existing one-million mutation-binding ceiling. The small reply reservation includes the current kernel principal/request annotation. A nonfitting later row ends the page **before** that row; it is not skipped. A nonfitting first row produces `CONFIGURATION_HISTORY_PAGE_TOO_SMALL`. Empty pages visit no event/binding row. Offset equal to selected size returns an empty page; larger offsets fail.

Exact lookup is direct indexed access. Binding filtering uses the existing semantically validated monotonically ordered configuration-event references and binary search. It does not scan all bindings to count matches. Other than one lookahead for a nonfitting row, at most the requested rows are rendered.

`work` describes only `LOCKED_HISTORY_PAGE`: row visits, filter comparisons, a selected-prefix lookup, and full-snapshot instrumentation. `prefix_reads` counts the single selected-prefix lookup at `through`, not every cached commitment accessed while rendering a row. Zero canonical/payload reads and historical parses refer to this method, not startup, accepted-configuration parsing, journal replay, control authorization, transport, other threads, or all process allocation.

## Event rows and deliberate redaction

Each event retains kind, accepted/rejected status, generation, recorded configuration digest, canonical byte length, time, actor **as actually stored**, reason byte length/digest, error code, previous accepted-event ordinal, active-event ordinal after the event, and full item/prefix commitments.

BOOTSTRAP, ACTIVATE, ROLLBACK, RELOCATE, and REJECTED remain distinct. REJECTED does not become active. Its configuration digest can be zero if no candidate digest was obtained; it is not proof of a validated or accepted candidate. ROLLBACK is a new accepted historical event, not deletion of later history. RELOCATE names its previous accepted event and preserves opaque full-event commitments.

Canonical contents, all relocation path strings, and **free-text reasons** are deliberately omitted. Reasons can contain private paths, so the stored reason is represented by a domain-separated digest and exact byte length rather than copied into the new administrative reply. `reason_text`, `canonical_contents`, and `relocation_paths` are explicit nulls; `redaction` describes the omission. The original strings remain in the authenticated/ordinary durable history and offline inspection. This API does not erase or change them.

Historical configuration events use tags such as LOCAL_STARTUP, LOCAL_CONTROL, and LOCAL_OFFLINE_RELOCATION. The API does not infer a real principal that was never stored in that field. Separate local-control accounts contain UID/GID/PID and request identity. The current request's principal annotation identifies the inspector, **not** the actor responsible for every historical row. Event generation names, timestamps, sizes and cryptographic commitments remain sensitive metadata; digests do not conceal low-entropy text from guessing.

## Mutation bindings are not the entire journal

Binding rows identify the accepted configuration event and its item/prefix commitment, journal kind, inner mutation-payload digest, and optional operation ID. The binding's own digest includes the referred configuration prefix, not merely its canonical settings digest. An alternative history with identical active settings but changed attribution therefore changes both commitments.

This stream represents **runtime-bound mutation wrappers**, currently ordinary kinds 1–16, 20, 21 and 24. It is not an exhaustive event/effect log. Configuration events, local-control decisions, lifecycle, consumers, projections, publication channels, authoring, subscriptions, import decisions and conditional administration retain their own configuration references in separate structures. Absence from this stream does not establish that no effect happened. A payload digest is of the inner encoded semantic mutation, not just its application payload. Binding records do not contain a separate actor/time; none is fabricated. The two streams have separate ordinals, and this API does not invent a global interleaving against rejected candidates, local-control decisions or other journal events.

## Append-stable commitments

The new derivatives are rebuilt only through the normal verified append and checkpoint-load paths. They are not serialized as trusted application state and do not change existing logical-state digests, journal kinds, checkpoint schemas or signatures.

Let `H(domain, bytes) = SHA256(ASCII(domain) || 00 || bytes)`. Unsigned integers are big-endian. Node strings use a 16-bit byte length. Section IDs are 1 for events and 2 for bindings.

```
seed = H(NATRAV_OVERLAY_CONFIGURATION_HISTORY_SEED_V1,
         text16(node) || u8(section))

configuration item = H(NATRAV_OVERLAY_CONFIGURATION_EVENT_ITEM_V1,
                       exact existing serialized RuntimeConfigurationEvent)

binding item = H(NATRAV_OVERLAY_CONFIGURATION_BINDING_ITEM_V1,
                 referred-configuration-prefix[32] ||
                 u64(configuration_event) || u8(journal_kind) ||
                 payload_digest[32] || u8(has_operation) || [operation_id[32]])

prefix[i] = H(NATRAV_OVERLAY_CONFIGURATION_HISTORY_LINK_V1,
              prefix[i-1][32] || u64(i) || item[i][32])
prefix[0] = seed
```

Existing event serialization is text16(kind), text16(generation), recorded digest[32], u32(canonical length), canonical bytes, u64(time), text16(actor), text16(reason), text16(error code). Independent tests hash the actual journal bytes, not API output copied back into itself.

A chosen prefix remains valid through later appends, compaction, keyed migration, restart, signed encrypted restore, and relocation **when those records are retained unchanged**. A missing prefix gives `CONFIGURATION_HISTORY_PREFIX_UNAVAILABLE`; a different prefix at the selected length gives `CONFIGURATION_HISTORY_PREFIX_MISMATCH`. Current configuration may change while the historical selection remains valid, provided the caller is still authorized. There are no cursor objects, clock expiry, or process-local secret tokens.

A valid old snapshot containing the chosen prefix may pass. There is no external freshness anchor, signature by this query API, or proof that omitted later events never existed. Existing keyed journal authentication remains separate. An arbitrary party able to replace both state and the caller's expected prefix can replace that comparison too.

## Cost and lifetime

The derivative retains one item/prefix/active-ordinal record per configuration event and one 32-byte prefix per binding. The latter is about 30.5 MiB of digest contents at one million bindings, plus vector capacity/allocator overhead. Replay and accepted appends perform the hashing; small reads do not rehash historical canonical configurations. Initial loading is still linear and ordinary semantic validation retains its prior costs.

Pages use existing mutex-based serialization, not a wait-free snapshot service. The complete retained one-million history is not stress-tested in this increment. The new large fixture independently encodes 256 events and 8,192 semantically valid recovery bindings; it is explicitly synthetic, not thousands of real failures or network admissions. Its complete enumeration and checkpoint reconstruction are tested along with real concurrent submissions, publication, credentials and maintenance.

## Related boundaries

No change to peer transport, authorization grants, or the distinction between AUTHORIZED and a completed effect is made. This increment additionally fixes runtime-inventory's missing observational classification during DRAINING: it was already inspection, but the lifecycle allowlist omitted it. Both inventory and history remain inspectable while the drain control endpoint is alive.

See [active inventories](RUNTIME-INVENTORIES.md), [status](RUNTIME-STATUS.md), [generation-stable authorization](CONTROL-AUTHORIZATION.md), [storage](STORAGE.md), [testing](TESTING.md), and [actual validation](../validation/VALIDATION.json).

## Related actual-principal records

Use [control-history](CONTROL-HISTORY.md) for the separate durable decision and lifecycle streams. These preserve their real recorded principals and bind referenced configuration prefixes; they do not retroactively assign principals to coarse configuration actor tags or invent cross-stream effect correlations.
