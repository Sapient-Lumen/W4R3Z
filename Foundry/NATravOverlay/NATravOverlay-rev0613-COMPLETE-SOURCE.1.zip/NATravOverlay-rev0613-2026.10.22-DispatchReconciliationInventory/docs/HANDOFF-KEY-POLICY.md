# Durable handoff-key policy (V20)

Revision 0604 adds policy for the dedicated X25519 handoff keys used by the
[offline capsule](OFFLINE-HANDOFF.md). It changes configuration, not NHKB0001,
NHCP0001, TLS, the journal envelope, storage schema, or application receipts.
The existing authenticated configuration history is the ONLY policy ledger.

## Authority and compatibility

V6–V19 parsing, canonical configuration bytes and JSON remain unchanged. Those
versions retain the explicit operator-selected binding-digest behavior of 0602.
V20 requires exact local and remote signed binding records for every capsule
export or import. An empty V20 policy disables use; it does not mean “trust any
valid signature.” `handoff-key-init` still only prepares owner-private external
key material; it neither admits policy nor grants authority.

Accepting V20 is a one-way policy-mode transition for an initialized state:
activation, rollback and replay cannot downgrade it, even when the policy is
empty. The runtime reconstructs the accepted configuration before offline
handoff. A stale seed or an older configuration file cannot bypass revocation.
Configuration commands retain the existing owner/delegated CONFIGURATION
admission boundary. Parsing only verifies public data. No key directory is
opened, private key is generated, or adapter is launched by config-check.

## One canonical record

Repeat `handoff_key_hex=<lowercase hexadecimal of the ASCII record below>`:

```text
NATRAV_HANDOFF_KEY_POLICY_V1
sequence=1
predecessor_sha256=<64 lowercase hexadecimal digits>
binding_hex=<complete signed NHKB0001 public binding, lowercase hexadecimal>
state=ACTIVE
```

The final newline is mandatory. Fields have this exact order; extra fields,
trailing bytes, noncanonical numbers, invalid signatures and upper-case hex are
rejected. The signed binding supplies node, signing generation, handoff-generation
label, signing public key and encryption public key. Its signing pin must match
an exact configured identity generation (or the local identity). Associated old
signing records must therefore be retained in configuration, even when revoked.
That does NOT make them usable: current signing-key policy is checked separately.

`sequence` is a numeric ordering within a node's handoff-key history; it is NOT
an alias for the signed handoff-generation label. Sequence one has an all-zero
predecessor. Every following sequence is exactly one greater and commits to the
preceding immutable record. Labels cannot be reused. The X25519 public key cannot
be reused anywhere in the retained policy under a new name or signing generation.

The immutable commitment is SHA-256 over this exact ASCII transcript:

```text
NATRAV_HANDOFF_KEY_COMMITMENT_V1
sequence=<canonical decimal>
predecessor_sha256=<64 lowercase hexadecimal digits>
binding_hex=<complete signed binding, lowercase hexadecimal>
```

It includes the final newline and excludes `state`. Retirement consequently does
not break existing predecessor links. The full canonical configuration digest
AUTHENTICATES state as well as all immutable fields. Neither the immutable
commitment nor the binding digest by itself authorizes a transition.

Records are sorted by node and numeric sequence during canonicalization. Bounds
are 128 records globally, 16 per node, 1,500 decoded ASCII bytes per policy record,
and the unchanged 65,536-byte configuration limit. These are simultaneous limits;
a long record or other configuration content can reach the byte limit first.
No history pruning is implemented. Capacity exhaustion requires explicit future
migration design, not silent removal of security history.

## State and exact use

| State | Export as origin or recipient | Import as origin or recipient |
|---|---|---|
| ACTIVE | Allowed subject to other policy | Allowed subject to other policy |
| RETIRED | Rejected | Allowed for delayed capsule recovery |
| REVOKED | Rejected | Rejected, including otherwise valid duplicates |

ACTIVE → RETIRED → REVOKED is monotonic. Direct ACTIVE → REVOKED is permitted for
emergency revocation. No reverse transition is allowed. At most the latest record
for a node can be ACTIVE. A successor does not implicitly retire its predecessor:
the authorized candidate must explicitly retire or revoke the old key. Bootstrap
policy may retain only retired/revoked historical keys and have no active key.

Retirement is NOT proof that a capsule predates retirement. A holder of still-valid
signing material can construct another unexpired capsule naming a retired key;
import permits it subject to current authorization. Use REVOKED, not RETIRED,
when all further use must stop. Current signing-generation revocation and scope
policy can independently reject a capsule even when its handoff key is ACTIVE.

Receipts continue to bind the original operation and authenticated identity
signing generation. Rotating the separate encryption binding does not rewrite
that operation. An old operation may be imported using a retired recipient key,
then receive a receipt exported from a new ACTIVE binding and addressed to the
origin's new ACTIVE binding. Import reconciles that receipt with the original
outbox, never with a parallel ledger. This does not authorize migration across
a revoked or different Ed25519 signing generation.

## Operator workflow

Stop the daemon before preparing external key material. Keep the exact private
directory under protected custody; application-state backups do not contain it.
Use the normal `handoff-key-init` command, then draft a public record:

```sh
python3 tools/handoff_key_record.py --binding /private/new-key/binding.nhkb --sequence 1
```

The helper returns a config line, signed-binding digest and immutable commitment.
It only formats public data; the product performs authentication and validation.
For a successor, pass `--sequence 2 --predecessor-sha256 <old-commitment>` and use a
new key binding. Regenerate the predecessor's line with `--state RETIRED` or
`--state REVOKED`, keeping every immutable field unchanged. Retain all historical
lines, change the runtime generation, and select CONFIG_V20 in the candidate.

Run `config-check` and submit through ordinary `config-activate` with current
CONFIGURATION authority. Neither copying a binding into a directory nor printing
a config line admits policy. Both nodes must accept the intended exact records.
No automatic exchange, discovery, “latest key,” or trust-on-first-use is added.

Revocation is local accepted policy, not a global revocation oracle. A disconnected
node cannot know an update it has not accepted. Do not imply distributed consensus
or immediate revocation propagation. The same-host tests cover lost activation
response after durable commit, restart and checkpoint; they do not prove physical
power-loss behavior, hostile custody or independent-host operation.

## Security and future work

This increment does not change the custom capsule construction or claim formal
cryptographic proof, independent security review, forward secrecy after recipient
key compromise, or hostile same-UID confinement. It also does not revoke an already
admitted operation or undo an action. Operation authorization and cancellation
remain separate existing state transitions. Key-policy failures do not create a
second durable denial ledger or manufacture a completion receipt.

See `validation/revision-0604/STATUS.json` for observed gates. Historical status
records describe older artifacts, not this executable. A full source tree and its
verified manifests are mandatory handoff material; a status-only ZIP is not a
release.

A stale *seed* is different from replacing the entire durable state with an older
otherwise authentic snapshot. This increment prevents seed/activation rollback
against retained history, not rollback of all external knowledge. Existing
state-head/custody and backup controls remain necessary; cryptographic validity
alone does not establish global freshness.
