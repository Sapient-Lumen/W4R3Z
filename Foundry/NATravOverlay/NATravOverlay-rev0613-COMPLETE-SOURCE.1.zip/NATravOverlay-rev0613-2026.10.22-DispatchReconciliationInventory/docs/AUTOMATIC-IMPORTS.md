# Finite recipient import automation — revision 0527

Current view discovery: [manager-scoped source-view inventory](SOURCE-VIEW-INVENTORY.md) exposes retained administrative summaries without changing import or read authority.

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Explicit authority, not implicit federation

The persistent C++ node can schedule recipient-side import for one already accepted V17 source view. A configured view, incoming peer request, `SOURCE_IMPORT` class, or valid envelope alone never enables the worker. `source-view-auto-enable` is a separate finite local decision by the view's exact kernel-authenticated manager UID.

The existing view rule and subscription pins remain authoritative. Original peer admission, embedded source claims, recipient policy, and imported evidence remain distinct. Import grants confer no metadata/payload-query permission, source authorship, re-export permission, or provider authority over the recipient's scheduler.

## Commands

```sh
./node/bin/natrav-overlay source-view-auto-status \
  --control state-c/control.sock --view temperature

./node/bin/natrav-overlay source-view-auto-enable \
  --control state-c/control.sock --view temperature \
  --expected-revision 0 --max-imports 32 --max-decisions 128 \
  --minimum-interval-ms 100 --reason 'process reviewed source bindings'

./node/bin/natrav-overlay source-view-auto-pause \
  --control state-c/control.sock --view temperature \
  --expected-revision CURRENT_REVISION --reason 'stop automatic selection'
```

All three commands require the exact owner and explicit `SOURCE_IMPORT`. Pause/status can use the retained owner record after the view is removed, but still require the current command class. Enable requires the actual current V17 rule, pins, and nonrevoked provider generation. No capability is added to `ALL` or `INSPECT`.

The local control kind is 22; strict request format is `NIR1`. Unknown versions, malformed bounds and trailing material fail closed. Configuration V17 and all network formats are unchanged. Old binaries reject unfamiliar commands or durable formats; they do not drop the grant.

Every mutation selects the exact observed scheduling revision. A lost response is resolved through status; resending an old enable cannot replenish allowance or affect a later grant. The same revision cannot be consumed twice. New enable while already enabled is refused. Enabling after pause, exhaustion, or a policy block is explicit and never rewinds selection.

## Two independent finite allowances

* Successful imports: 1–128 per grant.
* Classified inspections: 1–256 per grant.
* Minimum interval: 10–60,000 milliseconds, process-local pacing.

A new grant resets only its own counters. Retention use, admission identities, cursor position, deferred dependencies and all prior grant events remain retained. Existing per-view record/raw-byte quotas, total inbound capacity and journal ceiling still apply.

The registry uses at most the existing 32 historical views. Each schedule permits 32 grant generations, 64 deferred dependencies, and 1,024 retained events. Before the event history fills, the worker durably blocks; new enable is then refused. There is no garbage collection, hidden renewal, or identity reuse. The complete bounded event history survives compaction.

## Selection, outcomes and progress

One native cooperative worker rotates through enabled views and performs at most one semantic transition per turn. It selects from the existing exact `(provider, source scope)` admission-order index. It never copies the full journal or scans earlier source pages on an idle poll. Caught-up checks inspect domain counts and at most the bounded deferred set. Scheduling events contain administrative positions in that provider/source domain, not read-authorized evidence-feed positions.

| Observation | Durable effect |
|---|---|
| Valid, new source | Import the record and provenance; advance position; spend one import and one inspection |
| Exact already-imported source | Record `DUPLICATE`, advance position, spend one inspection only |
| Malformed, denied, conflicting or mismapped source | Record its typed outcome, advance position, spend one inspection only |
| Missing materialized correction parent | Record a deferred dependency, advance scan position, spend one inspection only |
| Deferred parent still missing | No event, allowance use, or repeated parsing |
| Deferred parent becomes available | Revalidate from current authority; import or reject once, spending the corresponding inspection/import allowance |
| View record/byte limit or dependency capacity reached | Block without advancing the unprocessed candidate or spending successful-import allowance |
| No new candidate | No event or allowance use |
| Quiesced or draining service | No new automatic transition |
| Journal capacity temporarily unavailable | Wait without consuming allowance; state corruption or a poisoned writer remains fatal |

A deferred source does not block later independent originals. A mismatched existing parent is **not** a missing dependency: it produces `SOURCE_VIEW_PARENT_BINDING_REJECTED` and cannot make the worker repeatedly retry an impossible mapping. Sources remain stored even when skipped; this is not deletion or a claim that their bytes are false.

Skipped records are not automatically reconsidered when new pins are accepted. A manager may deliberately import one using the existing exact-operation manual command. Manual import remains allowed while automation is enabled; the shared state mutex serializes them, and automation recognizes an already imported record without spending successful-import allowance. There is no automatic alias merge or reset/rewind API. Revision 0528 additionally supports [bounded decision review and explicit one-source retry](IMPORT-DECISIONS.md) while automation is paused, blocked or exhausted; it never rewinds the scan or replenishes the grant.

## Policy publication and service lifecycle

A grant adopts a canonical commitment to the immutable view rule and exact subscription bindings, not owner filesystem paths. Current manager authority, exact pins and provider key state are checked before every worker step under a stable accepted-configuration lease.

Rule removal or revoked authority/key stops the grant. Binding-set changes require a new explicit grant; restoration of old permission does not resume a blocked schedule by itself. An unrelated configuration change or explicit path relocation need not change the adopted authority. Already admitted records remain governed by their separate current read grants.

The durable states are `ENABLED`, `PAUSED`, `BLOCKED`, and `EXHAUSTED`, with a typed stopping reason. A schedule can be enabled and caught up. Quiesce/drain suspend new work but do not delete grants or include import backlog in drain completion. Provider delivery of raw envelopes may continue according to the existing lifecycle rules.

A minimum interval is not a durable wall-clock quota. On restart pacing begins again, but spent allowances and selected positions do not reset. Remote peers have no scheduler enable, pause, grant-renewal or pin-adoption operation.

## One journal boundary

Journal kind **34** carries `NIE1`, a deterministic import decision. It binds prior schedule digest/revision, exact accepted configuration event, actual actor UID/GID/PID, time, source-domain ordinal, and exact pre-transition inbound prefix. It also carries the selected outcome and, for enable, finite limits and reason.

The common reducer reconstructs the candidate, validates its original authenticated admission and current historical import policy, then derives the result. One synchronized append therefore commits the materialized record, provenance, scan/dependency progress and spent allowance together. There is no separate acknowledgment, import append, or budget append that can survive alone.

Automatic materializations use `NSV2`. Its `import_uid` is the **delegating manager**; `execution_actor` is `DAEMON_IMPORT_WORKER`, `executor_uid` is the actual daemon UID, and import GID/PID are the actual executor's values. The scheduling revision identifies the exact delegation-derived transition. This is not fabricated `SO_PEERCRED` for a disconnected manager. Manual imports keep `NSV1` and `LOCAL_PRINCIPAL` behavior.

The optional `NIS1` logical-state extension retains each complete bounded `NIH1` event history. Checkpoint loading replays decisions against their original inbound prefixes: a parent imported later cannot retroactively change an earlier missing-parent outcome. It checks each automatic effect against its exact historical event, and rejects missing grants, forged outcomes, detached automatic provenance, or mismatching effects. State without import automation retains its preceding logical encoding.

`source-view-auto-status` is bounded and observational and no longer copies its complete retained event vector. `source-view-decisions` provides bounded live access to a selected immutable prefix; `source-view-retry` records a separate finite manual classification. See [decision review](IMPORT-DECISIONS.md). Offline `inspect` additionally exposes every retained event and its actor, position, outcome, configuration and limits; protect that output like the rest of the state. Successful polls do not append audit traffic. Denied local commands retain ordinary bounded security audit behavior.

## Validation and honest limits

The dedicated suite uses compiled provider/recipient processes, actual different UIDs, independent raw control/envelope encoding, malformed authenticated outer evidence, incorrect mapped parents, metadata and numeric projections, finite grants, two competing recipient views, and retained missing dependencies. It kills the process before/after both grant commit and actual import commit, and exercises keyed audit, compaction, signed encrypted backup, restore and relocation. Counts and completed compiler profiles are in [validation](../validation/VALIDATION.json); adverse attempts are in [attempts](../validation/ATTEMPTS.md).

These tests do not establish truth, author consent, physical-host independence, arbitrary power-loss safety, or freshness of a restored snapshot. A valid older snapshot can restore older grants and progress. Normal keyed startup still fails on incomplete authenticated tails; use explicit audit/recovery rather than automatic truncation.

Full history replay is bounded but not constant-time. Historical validation may revisit target metadata and accepted configurations. The shared state mutex and cooperative worker are not CPU, storage or timing isolation. Administrative scheduling counters can reveal candidate activity within the selected provider/source domain; they are not a metadata-oblivious query interface. No payload bytes appear in scheduling status.

Both original envelope and materialized payload remain stored. Retention reclamation, alias resolution, key migration, remote view queries and automatic pin approval remain separate construction opportunities. Selective reconsideration is explicitly manual, not automatic rescan. [Next build](BUILD-PLAN.md).

## Recipient-view terminal lifecycle

Explicit [view retirement](VIEW-RETIREMENT.md) now makes a view terminal. Its enabled grant stops in the same event, with counters and deferred dependencies preserved. Neither later policy nor a new grant can reopen it. The ordinary 1,024-event ceiling has one additional reserved terminal slot; it is not extra processing allowance.
