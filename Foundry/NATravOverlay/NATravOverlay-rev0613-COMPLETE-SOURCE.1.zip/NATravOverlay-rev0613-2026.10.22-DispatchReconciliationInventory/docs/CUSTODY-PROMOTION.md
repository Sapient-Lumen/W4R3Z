# Offline authenticated state-head custody promotion

Revision 0574 adds one explicit offline transaction that advances a detached
`NHCUST01` custody record only to the exact authenticated head derived from one
operator-named input.

The command accepts either a stopped keyed state directory:

```sh
./node/bin/natrav-overlay state-head-custody-promote \
  --record /protected-anchor/A.head \
  --expect-node A \
  --expect-domain primary-operations \
  --expect-generation 7 \
  --expect-head 'NASH1:A:...' \
  --expect-digest 64_lowercase_hex \
  --new-generation 8 \
  --state /srv/natrav/state-a \
  --state-auth-key /protected-keys/state-a-g1.key
```

or one signed encrypted backup:

```sh
./node/bin/natrav-overlay state-head-custody-promote \
  --record /protected-anchor/A.head \
  --expect-node A \
  --expect-domain primary-operations \
  --expect-generation 7 \
  --expect-head 'NASH1:A:...' \
  --expect-digest 64_lowercase_hex \
  --new-generation 8 \
  --input /offline-backups/A.nob \
  --generation a-g1 \
  --state-auth-key /protected-keys/state-a-g1.key \
  --decrypt-key /protected-keys/backup-g1.key \
  --trusted-cert /trusted-signers/a-g1.crt \
  --require-signature yes \
  --require-encryption yes \
  --expected-backup-id 64_lowercase_hex
```

Exactly one of `--state` and `--input` is required. The caller cannot supply a
new state-head selector. `--new-head` is rejected. The replacement selector is
constructed only from the completely validated input.

## Exact old custody condition

The custody side retains the revision-0572 compare-and-swap boundary. Before
examining the candidate source, the process:

1. opens the explicitly named custody parent without following symbolic links;
2. takes its nonblocking exclusive advisory lock;
3. opens and strictly decodes the bounded canonical `NHCUST01` record;
4. requires the exact old node, custody domain, custody generation, selector,
   and complete-file SHA-256 supplied by the caller; and
5. requires the new custody generation to be strictly greater.

The parent lock remains held through source authentication, semantic replay,
source recheck, old-record recheck, atomic exchange, directory synchronization,
and final published-record verification.

A second exact attempt after a winner is not idempotent. It fails because the
old custody condition no longer matches.

## State-directory source

State promotion is intentionally offline. It opens the existing state directory
through no-follow traversal and requires the directory to be owned by the
effective user with exact mode `0700`. It takes nonblocking exclusive locks on
both `state.lock` and `state.journal`, requires private owner-only single-link
state files, and reads the complete journal within the explicit size ceiling.

The command then:

- authenticates the complete journal and rejects incomplete tails;
- semantically replays every authenticated application frame;
- derives the exact application digest and final `NASH1` selector;
- rechecks the journal pathname, inode, metadata, length, and complete bytes
  before custody publication; and
- opens no filesystem writer and starts no worker.

The journal bytes are never changed.

## Signed encrypted backup source

Backup promotion retains one exact read-only file snapshot while applying the
normal backup verifier. The verifier requires:

- authenticated encryption with the explicitly supplied decryption key;
- a valid embedded signature;
- an explicitly trusted signer certificate;
- the exact expected node and identity generation;
- the optional exact signed backup identity when supplied;
- the embedded checkpoint authentication key; and
- complete semantic replay of the embedded checkpoint.

The outer encrypted-file byte count and SHA-256 returned by verification must
match the retained snapshot exactly. This binds authentication to the same
file that remains open for the prepublication pathname, inode, metadata, and
byte recheck. A pathname replacement cannot cause one backup to be verified
while another backup supplies the publication lifetime.

The operation does not restore or publish a state directory.

## Accepted successor relationships

Promotion is not a general "trust this newer-looking value" operation. The
validated input must prove one of two relationships to the exact old custody
head.

### Verified append-only extension

When authentication generation, key ID, and epoch are unchanged, the candidate
must have larger authenticated record and physical-byte counts. The process
extracts the old byte prefix from the candidate, authenticates it independently,
semantically replays it independently, and requires all seven old `NASH1`
accounts to match exactly.

A longer same-epoch divergent branch therefore fails even when it is otherwise
a valid authenticated state.

### Verified authenticated checkpoint successor

A checkpoint representation must carry the old authenticated root as its
`parent_root`.

- `ROTATE` additionally requires retained old-key lineage and an exact rotation
  transition from the old root.
- `COMPACT`, `BACKUP`, and `RECOVER` must retain the old authentication key and
  generation.
- Other checkpoint purposes are rejected.

The checkpoint itself is still completely authenticated and semantically
replayed. The parent relation does not bypass any state validation.

An input equal to the old custody head is rejected with
`STATE_HEAD_CUSTODY_PROMOTION_NOOP`. An older input is rejected as stale. A
valid but unrelated authenticated branch is rejected as divergent.

## Atomic publication boundary

After successful source validation, the product derives the candidate selector
with the normal canonical `NASH1` encoder. It stages a new canonical custody
record in the same directory and synchronizes it.

Immediately before publication it rechecks:

- the exact old custody path, inode, metadata, digest, and bytes; and
- the exact retained state journal or encrypted backup source.

It then uses `renameat2(..., RENAME_EXCHANGE)` and verifies that the displaced
name contains the exact old custody inode and bytes. An unexpected displaced
record triggers an atomic restoration attempt. Successful publication is
followed by parent-directory synchronization, removal of the displaced old
record, a second directory synchronization, and complete verification of the
new published record.

The existing private prepublication failure hook demonstrates that a failure
after complete validation but before exchange leaves the old custody file
byte-for-byte unchanged.

## Response account

A successful response uses:

```text
NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_V1
```

It reports:

- source kind and immutable source byte identity;
- complete-authentication and semantic-replay status;
- logical-state or signed-backup accounts;
- the verified successor relationship;
- the exact previous custody record;
- the exact resulting custody record; and
- the internally derived state-head selector.

The response explicitly states that the caller did not supply the replacement
selector and that no node state was mutated, no backup was restored, and no
workers were started.

## What promotion does not mean

A successful promotion means that this process explicitly compared and replaced
one custody record after verifying one authenticated successor input. It is not:

- node, local-control, restore, or recovery permission;
- a retry or idempotency instruction;
- proof that a command response was received;
- a remote witness or global clock;
- proof that no other authenticated branch exists; or
- an automatically maintained freshness service.

The operator still chooses and protects the custody file, authentication keys,
backup keys, signer trust, input path, and new custodian generation. The product
never discovers a source or custody path and never advances custody as a side
effect of another command.

## Compatibility

Revision 0574 adds one CLI-only offline operation and one internal exact-backup
snapshot-verification helper. It changes no local-control request kind, peer
protocol, journal, authenticated header, checkpoint, encrypted-backup format,
NSS/NST encoding, application logical state, permission class, configuration,
storage schema, or product limit.

Revision 0573 rejects `state-head-custody-promote` as an unknown command. It can
still read the resulting unchanged `NHCUST01` record and use it through the
revision-0573 custody-constrained opening adapter.
