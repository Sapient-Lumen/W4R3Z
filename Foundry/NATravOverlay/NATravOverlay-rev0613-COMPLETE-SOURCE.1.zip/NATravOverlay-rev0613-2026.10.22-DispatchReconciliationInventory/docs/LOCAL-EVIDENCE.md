# Local evidence sources — revision 0519

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

The persistent native C++ node now accepts explicit local originals and corrections without a peer connection. This is the source-admission prerequisite for remote evidence subscriptions, not a remote subscription implementation.

## Explicit V14 authority

```text
NATRAV_OVERLAY_CONFIG_V14
local_control=1001,EVIDENCE_AUTHOR
evidence_author=1001,observations/temperature
```

`EVIDENCE_AUTHOR` is a new exact-UID command class. It is not implied by `ALL`, `SUBMIT`, `INSPECT`, consumer, projection, or publication privileges. Each author-capable UID requires at least one exact scope rule; each rule requires that UID's explicit class. At most 256 rules are accepted. Duplicate rules, wildcard scopes, noncanonical UIDs, unknown principals, and `actions/` scopes are rejected. Canonical rule and policy digests are independent of text order. V6–V13 cannot use the new class or rules.

Authorship grants do not grant read access, change someone else's source, send records, subscribe a peer, invoke the counter action, or publish a projection. Separately configured finite automation may of course react to new admissions under its existing authority. Read access still requires the existing exact issuer/scope and metadata/payload grants. No filesystem permissions are broadened by configuration.

V14 retains V13 numeric-route grammar. A local source needs an identity and a configured listener for the ordinary persistent process, but needs no configured peer, route, NATrav binary, self connection, or remote receipt.

## Native commands

```sh
./node/bin/natrav-overlay evidence-author \
  --control state-a/control.sock --node A \
  --scope observations/temperature --operation HEX64 \
  --numeric-ticks 2150 --numeric-unit degC --numeric-scale 2

./node/bin/natrav-overlay evidence-amend \
  --control state-a/control.sock --node A \
  --scope observations/temperature --operation NEW_HEX64 --corrects HEX64 \
  --numeric-ticks 2125 --numeric-unit degC --numeric-scale 2
```

Use exactly one existing payload producer: `--payload-text`, `--payload-file`, or the complete numeric triple. Arbitrary binary payloads remain bounded to 60,000 bytes. Numeric production retains the exact `NNO1` contract; it is not floating-point text parsing. Operation IDs are explicit nonzero 32-byte identities. The command has no `--peer` or alternate-recipient option.

The daemon obtains `SO_PEERCRED` before reading the request, then rechecks the current V14 UID/class/scope policy after complete decoding. Its configuration lease remains held through admission. A slow client cannot use grants revoked while its request was being received. Issuer and recipient must both equal the configured local node.

The result is `NATRAV_OVERLAY_LOCAL_AUTHOR_RESULT_V1`: `AUTHORED` or `ALREADY_AUTHORED`, operation ID, ordinary record digest, `network_used:false`, and the immutable local-authorship account. It is a local commit account, not a recipient receipt or a claim of remote observation.

## Immutable ownership and correction semantics

An exact repeat by the same current authorized UID returns the original account, even after restart, compaction, configuration change or relocation. It writes no duplicate source or successful control event. The same operation ID cannot be repurposed for different content, another owner, or an existing nonlocal admission. Idempotency does not bypass current authorization.

A correction must name a preceding locally authored record owned by the same UID, in the same exact scope and local node. It cannot correct a third-party record, an unmarked legacy self-claim, another local principal's original, or a nonexistent parent. These cases share `LOCAL_AUTHOR_PARENT_REJECTED`. Independent authors in one scope may still create independent originals. Competing corrections serialize; only one child can win. A second child is `LOCAL_AUTHOR_BRANCH_REJECTED`.

Locally authored records enter the existing evidence store and ordered domain/history/current indexes. Existing query, feed, consumer, metadata/numeric projection and finite scheduling machinery can process them. Current views remain plural. An amendment supersedes its own predecessor, never unrelated observations.

The reserved `actions/` namespace cannot be locally authored by this API. Network and plaintext development admission paths cannot impersonate an existing local source or correct its chain. This is not a general restriction on legitimate peer evidence in other domains.

## Atomic provenance and replay

One synchronized journal entry, kind **31**, contains a versioned **NLA1** account followed by the ordinary `NOA1` record. It binds the real UID/GID/PID, authoring time, exact accepted configuration event and digest, exact author policy/rule digests, and a domain-separated digest of the full authored request. No remote key, TLS handshake, peer authorization account, or delivery receipt is invented.

Before replay inserts the record, it validates the accepted historical configuration, exact UID/scope grant, record binding, self-identity, and same-owner correction ancestry. Current-policy validation is required for a new append; historical grants are used only to explain already accepted state. Historical key paths are not reopened.

In memory, the optional account is held as immutable shared metadata only on locally authored records; ordinary remote records do not carry an inline 160-byte local account.

Checkpoint inbound provenance marker **2** carries the same NLA1 account. Markers 0 (legacy) and 1 (authenticated remote) retain their preceding encoding. Full checkpoint reconstruction validates local accounts and correction ownership. State lacking local authorship preserves its old canonical bytes. Older binaries reject marker 2, entry 31, or V14 rather than silently ignoring them.

Queries, feeds, consumer rows, and offline inspection add `local_authorship` only for genuinely authored records. The ordinary record digest still commits to NOA1 content; logical-state and row-selection digests also cover the added provenance. Existing nonlocal row encoding remains unchanged. Successful read access deliberately discloses this bounded metadata, including UID/PID—not private keys or file paths.

Accepted source and provenance share one commit. Denied source commands use the bounded local-control denial account and create no evidence. A failure to record a denial does not grant the source operation. Quiesce and drain reject new source mutations. Admission wakes the existing projection/publication scheduling machinery, without granting it new authority.

## Loss, capacity, and maintenance

Commands obey the configured journal ceiling and a one-million retained-inbound-admission ceiling. This is a count/space bound, not a per-author rate quota. There is no source deletion, UID ownership transfer, revision rewrite, or retention eviction.

Hard-kill tests bracket synchronized append: before commit neither record nor account exists; after commit both exist and exact retry returns ALREADY_AUTHORED. Arbitrary incomplete authenticated writes still fail closed and use the explicit audit/recovery facility. This is not universal physical power-loss proof.

Keyed audit, compaction, signed encrypted backup, restore and explicit relocation preserve authorship. A new post-relocation record binds the new configuration event; earlier account fields remain unchanged. Restoring a valid old snapshot can still restore old history. No freshness authority, split-brain prevention, physical sensor authentication, or protection after key/host compromise is added.

## Boundary for the next subscriber implementation

Only records carrying **validated local_authorship** are eligible local source candidates. `issuer == local node` by itself is not that proof. Existing outbox payloads, derived publications, remote records and unmarked historical self-claims must not be promoted merely because their bytes are available. This revision does not add an authored-only remote query or export flag.

A remote subscriber will still need a separate accepted disclosure rule, finite grant, key binding, receipt-gated frontier, correction mapping, and atomic outbox accounting. Local authoring is neither disclosure consent nor evidence truth. See [next construction](BUILD-PLAN.md).
