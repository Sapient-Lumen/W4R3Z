# Structural source selectors — revision 0556 contract, current at 0559

## Two explicit digest types

The default provider source-subscription response is unchanged: its `state_digest` is SHA-256 over the `NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_STATE_V1` domain, a zero byte, and the complete canonical NSS encoding. Existing status, succession and reconciliation clients keep their complete-state digest semantics.

An explicit compact response returns the already maintained exact structural source-progress commitment without serializing the growing NSS state:

```sh
./node/bin/natrav-overlay source-subscription-status \
  --control /path/to/state/control.sock --grant first \
  --response-format compact
```

```json
{
  "format": "NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_COMPACT_V1",
  "state_selector": "SPSC1:<64 hexadecimal digits>",
  "state_selector_kind": "NATRAV_OVERLAY_SOURCE_PROGRESS_STATE_V1",
  "freshness": "NOT_ESTABLISHED"
}
```

This is an excerpt, not the entire response. The compact format deliberately omits `state_digest`; it does not put a new meaning under an old field. `--response-format legacy` is the explicit default. Both preferences apply to create, step, status, retire, automatic enable/pause/status, succeed and reconcile. Remote subscriber requests and peer envelopes are unchanged.

The response still includes the existing administrative metadata, latest source/delivery account, stored scheduling/lease state, observed head receipt, and acknowledged mapping commitment. Full histories and source payloads are not added. Successful status reads do not append progress or audit records; invalid control requests can still append the existing denial audit.

## Exact selection, not authority

A successor may select the predecessor using either the existing `--predecessor-state-digest HEX64` or the new `--predecessor-selector SPSC1:HEX64`:

```sh
./node/bin/natrav-overlay source-subscription-succeed \
  --control /path/to/state/control.sock \
  --grant next --successor-lease lease-next \
  --predecessor-grant first --predecessor-lease lease-first \
  --instance PREDECESSOR_INSTANCE_HEX64 --expected-revision REVISION \
  --predecessor-selector SPSC1:STRUCTURAL_HEX64 \
  --expected-frontier FRONTIER --mapping-digest MAPPING_HEX64 \
  --reason 'explicit successor admission' --response-format compact
```

Likewise, terminal receipt reconciliation accepts either the existing `--state-digest HEX64` or `--state-selector SPSC1:HEX64`. The terminal, source-operation, delivery-operation and actual durable-receipt selections remain required. All examples use placeholders that must be replaced with exact observed values, not literal authority tokens.

Only one digest type may be supplied. Unknown prefixes, zero digests, malformed lengths, mixed alternatives and mismatching values fail closed. A structural root without its type is not a canonical state digest. Switching type changes the committed mutation request; switching only response preference does not.

The actual kernel UID must still be the manager and hold current SOURCE_DISCLOSE after decoding. An accepted successor grant, exact instance/revision, unchanged recipient generation/SPKI, complete acknowledged frontier and all existing lifecycle checks are still mandatory. Reconciliation still requires the actual exact durable receipt. Neither selector supplies permission, replenishes allowance, acknowledges an absent receipt, reopens a lease or grants source-payload access. Diagnostic work fields additionally require current INSPECT.

The selector commits the subscription's canonical facts, not all response annotations. An outbox receipt arriving before explicit source acknowledgment can change `head_receipt` without changing this selector. Current configuration and `adopted_by` can change independently as well. This is not a frozen response snapshot, cursor, clock, signature, external expected head or freshness proof. A valid older journal prefix restores its older selector; the test deliberately demonstrates this rollback behavior.

## Structural commitment contract

The digest is the existing revision-0555 `NATRAV_OVERLAY_SOURCE_PROGRESS_STATE_V1` root, now explicitly exposed as `SPSC1`. Its algorithm is not redefined by this revision. Domain-separated SHA-256 components commit:

* immutable grant/instance, peer pin, creation and remote-admission provenance, finite lease, succession, terminal, reconciliation and retirement accounts;
* the exact delivery chain, including every source/delivery/record binding, payload count, issue and acknowledgment provenance and automatic generations;
* automatic-grant history, finite consumption and stopping accounts;
* current revision, acknowledged count, spent bytes, transition, reason, configuration event, time, PID, request digest and schedule revision.

The canonical order and primitive encodings are implemented by `source_progress_base_commitment`, `source_delivery_commitment`, `source_automatic_commitment` and `source_progress_root` in [the native implementation](../node/src/source_subscription.cpp). The delivery and automatic chains have domain-separated empty seeds, indexed prefix links and a separately committed mutable tail. ISSUE folds the prior delivery tail into the prefix and commits the new tail. ACK replaces only the exact tail. An automatic step also replaces the exact current automatic-grant tail. Full canonical transitions reconstruct all components.

[An independent Python decoder](../node/tests/source_selector_reference.py) reads complete NSS1–NSS6 bytes and reconstructs the root without invoking the native helper or accepting a cached digest. Absent fields in earlier encodings contribute their defined zero/empty values. The public native `source_subscription_structural_digest` helper likewise performs full canonical recomputation, not cache lookup. Its result still depends on the SHA-256 collision-resistance assumption; it is not mathematical proof of source truth.

## Local request versions and durable provenance

NSR1 through NSR4 are unchanged. NSR5 is a response-preference envelope: four-byte `NSR5`, big-endian 32-bit inner length, and exactly one complete original source request. Its inner body is bounded at 2,048 bytes. It accepts NSR1–NSR4 or NSR6, rejects nested NSR5, trailing data and unknown versions, and changes only response construction.

NSR6 denotes structural selection for command 8 (succession) or 9 (reconciliation). It has the same remaining field order as the corresponding NSR3 or NSR4 request, with the selected state's 32-byte structural root occupying the former state-selection position. The request version, not a heuristic about digest contents, defines its type. All fields retain their original bounds. NSR6 cannot encode ordinary status, create, step or automatic commands.

The durable request digest is computed from the canonical inner request. NSR5 is excluded because presentation is not mutation intent. NSR6 is included: its different version and actual structural value are committed. Idempotent retry may change legacy/compact output without changing its original request identity. It may not switch the original selector type and expect an identical request identity.

Canonical NSS5 `predecessor_state_digest` and NSS6 `preceding_state_digest` remain complete-state digests. They are not replaced with structural values. Complete validation reconstructs the exact original predecessor and accepts a request commitment only if it equals either the exact legacy request or the exact NSR6 request using a full canonical structural recomputation. No persisted selector flag or new canonical state field is introduced. The test independently encodes and hashes NSR6 to verify the actual stored request commitment.

Revisions 0556–0559 read legacy journals and selectors. Revision 0559 shares an exact command-local transaction parse without changing any selector or durable encoding. Revisions 0557 and 0558 introduce no new encoding, and actual revision-0556 reads of its ordinary, succession and reconciliation journal/checkpoint histories reproduce equal logical-state digests. A revision-0555 binary can read progress requested with NSR5 compact output when the underlying mutation intent remains legacy; the envelope never enters the journal. An older binary will reject history whose succession/reconciliation provenance commits NSR6, because it cannot reconstruct that new request type. This is intentional fail-closed semantic compatibility, not a claim that every newly produced history opens in an older executable. Canonical checkpoint layout, application logical-state encoding, storage schema, configuration versions, permission classes and NSE1/NSE2 peer envelopes do not change.

## Derived acknowledged ancestry index

Each retained subscription has a process-local index containing its immutable instance, acknowledged absolute frontier, existing canonical acknowledged-mapping digest, and a source-operation lookup. Entries reference canonical grant/instance/delivery-position accounts; they do not copy source payloads or retain another authoritative delivery history.

Full canonical validation precedes reconstruction at creation, full-state transitions and checkpoint load. The builder walks acknowledged ancestors, rejects cycles/duplicates/missing instances, and checks exact frontier cardinality. Ordinary ISSUE adds no acknowledged entry. Ordinary ACK adds exactly one reference and hashes exactly one existing `NATRAV_OVERLAY_SOURCE_MAPPING_LINK_V1` link. Reconciliation rebuilds only after its complete receipt and old-state checks. Terminal predecessors cannot change beneath an adopted successor.

Indexed correction lookup is allowed only for the exact retained subscription object, never an unvalidated candidate copy. It checks the selected index instance/frontier and dereferences the canonical ancestor's exact grant, instance, acknowledged position, source operation, local manager, author, scope, recipient generation/SPKI and nonzero acknowledgment before selecting that recipient's delivery operation. The required source must precede the new absolute source position. No missing-parent fallback, ordinal guessing, synthetic receipt or source-operation-only substitution is permitted.

Full source validation retains the original complete ancestry walk and source/receipt reconstruction. It does not consult this optimization. Diagnostic reference builds additionally compare all incremental commitment components and the entire index against full canonical reconstruction after each accepted ordinary progress transition. The normal process never persists or accepts a caller-provided cache assertion.

The map is logarithmic lookup, not constant-time access. Its cumulative ancestry is bounded by existing 64-subscription/128-record limits but can duplicate references across a long successor chain. The reported `response_index_fixed_bytes` is only `sizeof(index)` plus fixed key/value payloads. It excludes tree nodes, allocator overhead and external string capacity and must not be described as total heap use. No retention or payload limit is enlarged.

## Measured boundary and tests

The dedicated suite delivers 64 originals and 64 corrections with 128-byte raw payloads between real native provider/recipient processes. Across all 256 compact ISSUE/ACK responses, no complete NSS state is encoded and no retained ancestry is scanned. At correction 128, revision 0556 performed three exact indexed parent lookups (construction, preflight and application); revision 0557 performs one through [command-scoped preparation](SOURCE-PREPARATION.md); ACK hashes one mapping link, checks the actual receipt twice, and reconstructs no source payload. The same final legacy status still serializes the complete 18,214-byte NSS fixture and hashes 128 acknowledged mapping entries. The compact response is not a claim of dramatically smaller network JSON: the old response already exposed only a hash while computing it by full serialization.

The suite verifies multi-lease corrections with mixed selector types, terminal reconciliation, automatic finite allowance, independent NSR5/NSR6 producers, real UID ownership, live policy revocation, valid rollback, canonical ancestry corruption, uncompacted replay, compaction, keyed prefix recovery, signed encrypted restore, relocation and continued correction delivery. [Fresh results](../validation/VALIDATION.json) distinguish completed profiles, reference comparisons, negative controls and [adverse attempts](../validation/ATTEMPTS.md).

Legacy responses and complete lifecycle/checkpoint operations intentionally remain history-dependent. Revision 0557 reduces ordinary manual ISSUE to one source construction and ordinary ISSUE/ACK to one source-specific accepted configuration parse. Revision 0558 also reduces successful AUTO_ISSUE to one construction by moving its same-iteration eligibility envelope into preparation, while retaining exact checks and independent replay. Observational automatic status may still reconstruct a nonreusable preview. Counters cover calling-thread source work, not transport, every allocation, other threads or whole-program throughput. Tests use one Linux kernel and loopback peers; independently protected freshness and physical-failure evidence are not supplied by this change.
