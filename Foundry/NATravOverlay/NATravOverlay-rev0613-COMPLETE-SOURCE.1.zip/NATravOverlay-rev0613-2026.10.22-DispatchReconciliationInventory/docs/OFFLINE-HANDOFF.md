> Revision 0604: [V20 durable handoff-key policy](HANDOFF-KEY-POLICY.md) adds
> explicit commitments, succession, retirement and revocation. The earlier
> external-binding-only behavior below remains the V6–V19 compatibility mode.

# One-hop authenticated offline handoff — revision 0602

This is an **owner-invoked offline operation**, not a new live carrier, automatic
router, or relay. It moves exactly one existing durable operation or one exact
receipt between two named nodes. Both nodes need not be online at the same time.
The daemon must be stopped on the node whose state an import, export, or key
initialization command opens. The existing state lock enforces that boundary.

Export is not delivery. Possession is not authority. Decryption is not success.
Only `NodeState::record_outbound_receipt` can reconcile an exported operation as
acknowledged. An operation import reuses the existing authorization and inbound
admission paths. A counter action is queued under the ordinary action policy;
importing it does not execute it or manufacture an action-result receipt.

## Explicit workflow

Use an initialized private state directory and an accepted V7-or-later runtime
configuration. `--config` may be an accepted stale seed: the active configuration
is reconstructed from the existing journal before checking identity or policy.
V6 startup-only trust is not accepted for this offline feature. The caller must
own the state directory and have MAINTENANCE authority in the active policy.
This is not a delegated local-control command.

Create one immutable handoff-key directory for each explicitly selected local
handoff generation. The parent directory must already exist, be owned by the
caller, and have no group/other permissions. The command atomically publishes
both the private X25519 key and its Ed25519-signed identity binding:

```sh
node/bin/natrav-overlay handoff-key-init \
  --config /absolute/A.conf --key-directory /private/keys/A-h1 --generation h1
```

The JSON result contains the SHA-256 commitment to `binding.nhkb`. Transfer that
**public binding only** to the sending operator. Never transfer `private.nhks`.
Every export requires the exact binding file and its explicit SHA-256 commitment,
and verifies the binding against the currently active configured Ed25519 peer
pin and signing-key generation. It does not trust a public key merely because a
capsule or binding file supplied it.

For a pending operation already queued in A's ordinary outbox, use:

```sh
node/bin/natrav-overlay handoff-export \
  --config /absolute/A.conf --key-directory /private/keys/A-h1 \
  --recipient-binding /private/transfer/B-binding.nhkb \
  --recipient-binding-sha256 BINDING_SHA256 \
  --operation-id OPERATION_SHA256 --kind operation \
  --expires-ms EXPIRATION_UNIX_MILLISECONDS --output /private/transfer/op.nhcp
```

Expiration is explicit, strictly later than creation, at most 30 days later, and
cannot extend the durable outbound obligation's expiry. Export does not alter
the delivery attempt counter, acknowledgement, or journaled operation. A
cancelled, rejected, exhausted, expired, or acknowledged obligation cannot be
exported as pending work. A different bound recipient signing generation
requires the existing explicit rebind workflow, not a capsule shortcut.

Carry the complete capsule bytes by an explicitly chosen medium. At B:

```sh
node/bin/natrav-overlay handoff-import \
  --config /absolute/B.conf --key-directory /private/keys/B-h1 \
  --input /private/transfer/op.nhcp
```

Admission is `COMMITTED` or `DUPLICATE`. Current peer trust and scope/action
policy are rechecked even for a duplicate. The result is not a receipt capsule.
To return the exact stored admission receipt, B explicitly exports `--kind
receipt` for that operation using A's exact public binding. A then imports that
receipt capsule. The only completion path is the existing exact operation,
recipient, recorder, digest, and sequence receipt binding. Re-importing the same
receipt is idempotent; conflicting existing receipts are not silently replaced.

Receipt export always describes the original committed inbound journal event.
It does not invent a new sequence after duplicate import. If another transport
has already recorded a different receipt representation (for example a
`DUPLICATE` disposition instead of `COMMITTED`), the existing conflict rejection
is preserved rather than hidden. Receipts for local authored/materialized source
records cannot be forged through this interface.

State-opening handoff commands support the existing `--state-auth-key FILE` and
exact state-head expectation options. Keyed-state integrity and external freshness
are separate claims. An unkeyed legacy state remains unkeyed; a capsule signature
does not upgrade its local storage protection.

## Key policy, retention, and revocation

The dedicated X25519 key is **not derived from the Ed25519 signing seed**. Its
public binding is signed by the node's current configured Ed25519 identity and
contains node ID, signing generation, explicit handoff-generation label, and
both public keys. A private key file includes the exact signed-binding digest.

The full binding commitment, not its label or pathname alone, selects a key.
There is no automatic `latest` handoff key, no on-import key learning, and no
cross-node key-directory discovery. Changing the local key directory selects a
different exact binding and rejects old-key capsules. Export requires an exact
operator-provided binding commitment. Revoking or retiring an origin signing
key in accepted configuration rejects its capsules, including replayed ones.

This increment does **not** create a durable registry that bans all reuse of a
handoff-generation label across independent key directories, or automatically
revokes every old X25519 key under a still-active Ed25519 identity. Use unique
labels and exact commitments. Automated handoff-key succession/revocation and
distribution remain a later explicit policy feature. Do not describe the label
as a globally unique identity or as evidence of freshness.

The key directory is external identity material, like the TLS identity files,
and is not silently included in a state backup. Back it up separately under
owner custody. Loss of `private.nhks` makes its capsules undecryptable. Retaining
that key permits explicitly selected old-key imports while the signing identity
remains active and the capsules remain unexpired. Same-user/root compromise of
the host is outside this feature's confinement model.

## Canonical formats and limits

All integers are unsigned big-endian. Text identifiers have a u16 byte length,
are at most 64 bytes, and use the product's node/generation syntax. Unknown
kinds, reserved bits, aliases, trailing bytes, length inconsistencies, and
noncanonical encodings are rejected.

`NHKB0001` binding:

```text
magic[8]
node:text16 | signing_generation:text16 | handoff_generation:text16
Ed25519 public key[32] | X25519 public key[32]
Ed25519 signature[64]
```

The binding signature input is the ASCII domain
`NATravOverlay/handoff-binding/v1`, one NUL byte, then every preceding binding
byte. Maximum binding length is 512 bytes. X25519 coordinates must be canonical
u-coordinates less than 2^255-19; all-zero and low-order shared secrets are
rejected. This format is stricter about coordinate aliases than RFC 7748.

`NHKS0001` owner-private key file is exactly 72 bytes:

```text
magic[8] | raw private X25519 material[32] | SHA256(complete binding)[32]
```

`NHCP0001` capsule:

```text
magic[8] | kind:u8 (1 operation, 2 receipt) | reserved[3] (zero)
created_ms:u64 | expires_ms:u64 | fresh capsule nonce[32]
fresh ephemeral X25519 public key[32] | AES-GCM nonce[12]
origin binding:blob16 | recipient binding:blob16 | encrypted_length:u32
ciphertext[encrypted_length] | AES-GCM tag[16] | Ed25519 signature[64]
```

The header ends after `encrypted_length`. The plaintext is the SHA-256 digest
of one canonical existing application message followed by that message. The
digest is **inside encryption**, not a public low-entropy payload fingerprint.

The key schedule is X25519(ephemeral, recipient key), followed by HKDF-SHA-256
extract-and-expand with salt `SHA256(header)` and info
`NATravOverlay/handoff-key/v1` followed by one NUL byte, producing 32 key bytes.
AES-256-GCM uses the header as associated data. The outer Ed25519 signature
covers `NATravOverlay/handoff-signature/v1`, one NUL byte, and the complete
header, ciphertext, and authentication tag. The capsule ID is SHA-256 of the
entire signed capsule. Independent encryption uses fresh ephemeral material,
capsule nonce, and GCM nonce; equal operations do not imply equal capsules.

The importer verifies exact local binding, current origin pin, and signatures
before ECDH/decryption, then verifies AEAD, the encrypted digest, the canonical
application record, and application identity bindings before journal admission.
The total capsule is at most 68,000 bytes; canonical application bytes are at
most 65,536. Lifetimes are at most 30 days, with no future-creation tolerance.
Clock trust is an explicit host assumption; a signature is not a trusted clock.

This is a versioned project-specific envelope, **not an implementation of RFC
9180 HPKE** and not an independently audited cryptographic protocol. It uses
OpenSSL primitives; the independent test encoder may share OpenSSL beneath its
Python cryptography bindings. It is independent encoding/key-schedule evidence,
not an independent cryptographic implementation or formal security proof.
Recipient-private-key compromise can decrypt retained capsules addressed to
that key. This asynchronous scheme does not claim forward secrecy against such
compromise. Length, identities, generations, and timing remain visible.

## Finite filesystem and crash boundaries

One invocation handles one explicit file. There is no automatic import scan or
additional durable outbox. Duplicate suppression and quota-limited durable
admission come from the existing journal and operation IDs, not a new replay
ledger. Failed cryptographic imports produce typed command errors; they do not
consume inbound operation IDs. Authorized-but-disallowed operations reuse the
existing bounded authorization-denial account.

Output publication locks the exact selected private parent directory among
cooperating writers, scans at most 256 entries, and refuses projected regular
file bytes above 32 MiB. The cap includes interrupted staging files. A full
parent fails closed without silently deleting someone else's content. It does
not recurse or discover devices. Nonparticipating same-UID writers are not
confined by this advisory lock or quota check.

Input opening is component-by-component no-follow; regular-file ownership,
permissions, single link, finite size, and stable read observations are checked.
Secret material requires owner-only permissions. Output uses a same-directory
private temporary, complete write, file fsync, `renameat2(RENAME_NOREPLACE)`, and
parent-directory fsync. Key initialization atomically publishes a complete
private directory. A post-rename sync error is uncertainty, not permission to
remove an already published key.

A crash before publication may leave one owner-private `.nhc-part-*` object.
Those names are not accepted as import targets. No automatic scavenger guesses
whether an unknown file is safe to delete. The owner may preserve or explicitly
remove such leftovers after inspecting the failed command's outcome. Repeating
export never overwrites an existing destination. A crash after admission but
before its response is recovered by re-import: the existing journal returns a
duplicate and receipt export reconstructs the same original commit.

Tests use bounded `NATRAV_TEST_HANDOFF_BEFORE_PUBLISH_MS` and
`NATRAV_TEST_HANDOFF_AFTER_IMPORT_MS` pauses (0..5,000 ms) solely to terminate
owned fixture processes at known boundaries. They create no authority or bypass.

## References and assurance

The implementation follows the documented OpenSSL Ed25519, X25519, HKDF, and
AES-GCM APIs. Relevant primary references: OpenSSL 3.0 `EVP_PKEY-X25519`,
`EVP_SIGNATURE-ED25519`, `EVP_KDF-HKDF`, and `EVP_EncryptInit`; RFC 7748, RFC 5869,
and RFC 8032. RFC 9180 was reviewed as a design reference, not a compatibility
claim. Canonical encodings, key agreement, KDF/AAD binding, active trust, and
receipt semantics have separate negative tests.

No independent-host, named removable-media device, electrical, controller,
physical custody, filesystem power-loss, or compromised-host assurance is
claimed. Missing hardware is verification debt, not a construction veto.

## Primary implementation references

These specify primitive/API behavior, not a security proof of NHCP0001:

- RFC 7748, X25519 and the independent public-key known-answer vector:
  https://www.rfc-editor.org/rfc/rfc7748.html
- RFC 5869, HKDF extract-and-expand and context binding:
  https://www.rfc-editor.org/rfc/rfc5869.html
- OpenSSL EVP_SIGNATURE-ED25519, pure Ed25519 one-shot operation:
  https://docs.openssl.org/3.0/man7/EVP_SIGNATURE-ED25519/
- OpenSSL EVP_PKEY-X25519:
  https://docs.openssl.org/3.0/man7/EVP_PKEY-X25519/
- RFC 9180 is a comparison only; this custom framing is not an HPKE suite:
  https://www.rfc-editor.org/rfc/rfc9180.html

References checked October 19, 2026. Runtime and API evidence also comes from the
actual recorded OpenSSL build. The test harness uses a separate Python encoder
and decoder but may share OpenSSL as an underlying library; it is implementation
cross-checking, not complete cryptographic-library independence.

Filesystem operations have finite sizes and work budgets, but the operating
system may block open/read/write/fsync on a stalled device or filesystem. This
release does not claim a hard wall-clock deadline for those maintenance syscalls.
The CLI is explicit and offline; it is not a daemon ingestion queue. Rejected
cryptographic or filesystem input produces a typed command failure, not a new
persistent quarantine/receipt ledger. Existing authorization denials use the
ordinary bounded journal. Locally chosen rejected files remain operator-owned.
