# Configuration — revision 0524

Current view discovery: [manager-scoped source-view inventory](SOURCE-VIEW-INVENTORY.md) exposes retained administrative summaries without changing import or read authority.

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Current V18 — exact counter-action result disclosure

V18 retains V17 semantics and adds an exact `action_result=PEER,GENERATION,counter.add,RESULT_SCOPE` rule. Newly admitted V18 counter actions require a matching rule for the authenticated issuer generation. The rule is separate from inbound action authorization and from the recipient's later evidence-admission policy. Accepted actions retain the exact policy/rule digests, configuration event, generation/SPKI and delivery limits; later configuration changes do not retarget them. See [durable action results](ACTION-RESULTS.md) and [the V18 example](../node/examples/node-b-action-results.conf).

## V17 — recipient subscribed-source views

V17 retains V16 semantics and adds explicit SOURCE_IMPORT, nine-field source_view rules and five-field source_view_binding pins. Existing administrative ALL excludes this class. View identity/budgets, provider target-domain reservations and exact grant bindings are immutable across accepted history. Read and payload grants remain separate. See [complete grammar and security boundary](SUBSCRIBED-SOURCE-VIEWS.md) and [recipient template](../node/examples/node-c-source-view.conf).

## V14 local evidence-authoring policy

V14 retains V13 route grammar and adds explicit `EVIDENCE_AUTHOR` plus repeated `evidence_author=UID,exact-scope`. Each class grant needs a scope; each rule needs the class. `ALL` stays the six legacy administrative classes. At most 256 authoring rules are accepted. Read, action, send, compute and disclosure permissions are unchanged. Existing V6–V13 canonical encoding is unchanged. See [complete local source contract](LOCAL-EVIDENCE.md) and [V14 template](../node/examples/node-a-local-source.conf).

V11 retains V10 exact read domains and adds explicit CONSUMER and CONSUMER_ADMIN command bits. Both require EVIDENCE_READ; CONSUMER_ADMIN requires CONSUMER. ALL remains exactly the six original administration bits. No older header accepts these new classes. Registrations and every read/ACK use current read authority; a changed domain union requires an attributable reset rather than reinterpretation of stored ordinals. Full grammar and operational semantics: [Durable consumers](DURABLE-CONSUMERS.md).

## Scoped-read and indexed-query lineage

Revision 0507 adds [indexed pagination](INDEXED-PAGINATION.md) without changing this authority or durable format. Caches and ordered indexes are reconstructed, never independent state.

V10 adds `evidence_read=UID,ISSUER,SCOPE,METADATA|PAYLOAD`. Command classes remain necessary but no longer suffice for V10 evidence access. Rules are exact, sorted, bounded and retained in accepted canonical configuration. [Scoped reads](SCOPED-READS.md) defines validation, compatibility, reader-policy digests, publication and information boundaries. Live V9→V10 activation and restart from an earlier accepted seed are tested. Read-policy changes do not retire unrelated remote peer sessions. Rollback to accepted V9 deliberately restores its node-wide grants.

# Configuration contract

## Formats

Supported formats are:

```text
NATRAV_OVERLAY_CONFIG_V6   startup-only compatibility
NATRAV_OVERLAY_CONFIG_V7   durable live configuration generations
NATRAV_OVERLAY_CONFIG_V8   V7 plus explicit durable local-control policy
NATRAV_OVERLAY_CONFIG_V9   V8 plus explicit node-wide evidence-read classes
NATRAV_OVERLAY_CONFIG_V10  V9 plus mandatory exact domains for read-capable UIDs
NATRAV_OVERLAY_CONFIG_V11  V10 plus durable consumer and consumer-admin classes
NATRAV_OVERLAY_CONFIG_V12  V11 plus explicit projection authority
NATRAV_OVERLAY_CONFIG_V13  V12 plus explicit bounded peer routes
NATRAV_OVERLAY_CONFIG_V14  V13 plus exact local evidence-authoring domains
NATRAV_OVERLAY_CONFIG_V15  V14 plus finite source-disclosure grants
NATRAV_OVERLAY_CONFIG_V16  V15 plus immutable finite subscription leases
```

Use V12 for projections, V13 for explicit bounded routes, V14 for local authorship, V15 for indefinite finite-budget source grants, and V16 for finite leases and authenticated withdrawal. Earlier versions remain explicit compatibility formats; accepted canonical content is not silently reinterpreted.

## V8 local-control field

V8 requires one or more repeated records:

```text
local_control=UID,CLASS[,CLASS...]
```

Examples:

```text
local_control=1000,ALL
local_control=1001,INSPECT,SUBMIT
local_control=1002,MAINTENANCE,CONFIGURATION
```

Rules:

- UID is an exact unsigned 32-bit numeric UID.
- At most 64 UID grants are accepted.
- A UID may appear once.
- A class may appear once in a grant.
- `ALL` must be the only class token in its record.
- Classes are `INSPECT`, `SUBMIT`, `ACTION`, `MAINTENANCE`, `CONFIGURATION`, and `SHUTDOWN`.
- There is no group, username, UID range, wildcard UID, prefix, or deny-rule inference.

The canonical configuration sorts grants by UID and class bitset. Source order and comments do not change the local policy or complete runtime digest.

V6/V7 reject `local_control=` and synthesize an exact effective-owner `ALL` grant at load time. Their canonical historical formats remain unchanged.

## Live activation

A V8 candidate uses a fresh `runtime_generation` and is fully parsed before publication. Candidate identity material is revalidated. Queue/action obligations, historical key assignments, peer-registry capacity, and fixed owner/service boundaries are checked before the accepted event is synchronized.

A local-policy change is a real configuration change:

- it changes the canonical runtime digest;
- it requires `CONFIGURATION` authorization under the currently active policy;
- accepted and denied subsequent mutating requests bind to the accepted event;
- unchanged peer session contracts are not retired merely because local administrators changed.

A generation ID cannot be reused for different canonical content. Startup follows the last accepted journal generation; editing a seed file is not activation.

## Relocation

`state-relocate` remains offline and accepts V7–V16 versioned state. It may change only runtime generation and the state/control/certificate/private-key paths while preserving the exact effective behavior and identity.

For V8–V16 that includes exact preservation of:

- every local-control UID grant;
- every command-class bit;
- the local-control policy digest;
- V10+ exact evidence-read domains and access modes;
- V11 consumer/consumer-admin classes;
- V12 projection authority;
- V14 evidence-authoring domains;
- V15/V16 disclosure grants, budgets, subscriber-key bindings, and lease policy.

Relocation cannot be used to broaden administration. Use live V8 activation before backup or after startup for a deliberate policy change.

## Filesystem access and V8 authorization

`local_control=` does not modify filesystem modes. The daemon creates the state directory and control socket as owner-only. A second authorized UID therefore needs separately deliberate path/socket access. This separation prevents a configuration typo from automatically exposing the socket.

The test suite uses a real different effective UID and temporarily changes only the test state/socket modes so the kernel-authenticated policy can be exercised. Production deployment should prefer narrowly scoped ACLs or an equivalent deliberate access mechanism.

## Fixed and bounded fields

Existing strict bounds remain in force for:

- identity and peer generations;
- exact SPKI assignments;
- authorization rules;
- queue record/payload quotas;
- action budget, increment, defer, and expiry;
- session operation/byte/lifetime/idle limits;
- worker, queue, backlog, I/O, and journal limits;
- accepted configuration history and historical peer registry.

Unknown or duplicate fields fail closed. Every route locator is explicit and
canonical. Bare numeric IPv4/IPv6 endpoint text selects TCP. Revision 0580 adds
the self-describing `serial-v1|...` form. Revision 0584 adds the self-describing
`udp-v1|...` form. No carrier is guessed from a path, device type, DNS name,
packet source, or environment.

Revision 0577 introduced the internal TCP `TransportLocator` without changing
configuration bytes. Revision 0580 extended the configured locator parser while
preserving every predecessor TCP byte and canonical rendering. Revision 0584
extends it again with:

```text
udp-v1|local=<numeric-endpoint>|remote=<numeric-endpoint>|mtu=<decimal>|link=<16-lowercase-hex>|epoch=<decimal>|profile=1
```

The serial form binds the complete device path and line settings. The UDP form
binds exact numeric local and remote endpoints, receive MTU, nonzero finite-link
identifier, nonzero epoch, and versioned resource profile. Both fail closed in
older executables. UDP permits no DNS, broadcast, multicast, discovery,
source-address learning, path migration, forwarding, or carrier-derived
identity. There is no discovery, fallback, or downgrade.

## Backup encryption in 0502

V8 and its live configuration semantics are unchanged. Backup encryption uses explicit offline CLI key paths, not new runtime configuration defaults. It does not become authority to reinterpret accepted owner paths, identity generations, or local-control grants. See [Encrypted backups](ENCRYPTED-BACKUPS.md).


## State-key launch contract in 0503

`run --config FILE --state-auth-key KEYFILE` loads one separate state-authentication key before worker startup. This is a trusted process-launch requirement, not a new accepted V8 configuration field. No key material/path is written into canonical configuration, status or backups. Ordinary startup requires an already authenticated schema-2 journal, and unkeyed input is never implicitly migrated.

Live activation, rollback, peer-registry evolution, authorization and lifecycle changes continue under the existing configuration rules; their journal records inherit the current state MAC chain. Changing the state key requires explicit offline `state-auth-rotate`, followed by startup with the replacement key. TLS identity generations and state-authentication generations are independent.

Keyed offline `inspect`, backup operations and `state-relocate` also require `--state-auth-key`. Historical configuration decoding still does not reopen obsolete identity paths. A restored/relocated daemon must have access to its active TLS identity and separately provisioned state key. Protect the launch policy itself; removing the requirement and substituting an entirely unkeyed state is not a defended deployment boundary. See [State authentication](STATE-AUTHENTICATION.md).

Revision 0504 audit/recovery commands also require the explicit state-key option. They do not introduce a configuration field, key-path history, new UID grant or automatic startup-repair flag. Source key generation and accepted configuration history retain their existing meaning. See [Authenticated recovery](AUTHENTICATED-RECOVERY.md).

## Revision 0508 feed boundary

No new configuration version is introduced. `evidence-feed` requires V10 exact read domains and the existing EVIDENCE_READ/EVIDENCE_PAYLOAD classes. A V9 node-wide reader retains evidence-query but is explicitly refused feed access until V10 adoption. Feed cursors bind the accepted configuration and current effective authority; any digest change requires explicit continuation reset. See [Evidence feed](EVIDENCE-FEED.md).

## V12 native projections

NATRAV_OVERLAY_CONFIG_V12 adds PROJECTION. It must be explicitly accompanied by CONSUMER and EVIDENCE_READ; exact V10-style domains still apply. CONSUMER_ADMIN is additionally needed for projection-rebuild. ALL is unchanged. The parser rejects these grants in V6–V11 and inconsistent prerequisites. V12 uses the existing canonical generation/digest, live activation, key revocation, owner boundary and relocation machinery. No new peer/session settings are needed. The new example is node/examples/node-b-projection.conf. See [definition and authority](PROJECTIONS.md).

## Numeric interpretation in revision 0511

Configuration V12 remains current. NUMERIC_SUMMARY_V1 additionally requires EVIDENCE_PAYLOAD and an exact PAYLOAD grant alongside PROJECTION/CONSUMER/EVIDENCE_READ. No implicit numeric access is added to ALL, INSPECT or metadata domains. The definition/unit/scale/budgets are immutable consumer state, not mutable configuration settings. See [numeric projections](NUMERIC-PROJECTIONS.md).

## Explicit automatic processing (0512)

No format increment: V12 CONSUMER_ADMIN plus CONSUMER/PROJECTION and adopted exact read authority can explicitly enable a bounded run on that owner's projection. Numeric runs require payload access. Merely changing configuration never creates a scheduling grant. Current grants are rechecked for every step; any effective read-authority change conservatively blocks until explicit rebuild/adoption. Administrative schedule status/pause exposes only owned scheduling metadata and does not require evidence access. See [automatic projections](AUTOMATIC-PROJECTIONS.md).

## Revision 0513 — retirement

`consumer-retire` and `consumer-retirement-status` use existing V11/V12 CONSUMER_ADMIN authority for the exact kernel owner; no V13 or automatic grant is added. The administrative view does not require projection/payload permission and cannot reveal the corresponding result. Full result status still uses current read authority. [Retirement contract](CONSUMER-RETIREMENT.md).

## Revision 0514 — projection disclosure and submission

No configuration-format increment is introduced. `projection-publish` requires a V12 principal that currently has all of:

```text
PROJECTION
CONSUMER
SUBMIT
EVIDENCE_READ
```

The exact source issuer/scope must remain in the principal's read domains. `NUMERIC_SUMMARY_V1` additionally requires `EVIDENCE_PAYLOAD` and a `PAYLOAD` domain. The configured recipient route must have one active key generation, and the output scope is subject to the recipient's independent peer/scope authorization after delivery.

`CONSUMER_ADMIN`, `ALL`, `INSPECT`, an automatic projection grant, or possession of a retired-result tombstone does not imply publication authority. Configuration activation can revoke disclosure immediately for new requests; a partially transmitted request is checked under the configuration accepted when dispatch occurs. The request retains a generation-stable configuration lease through validation and atomic outbox enqueue.

The canonical NPP1 payload binds stable effective read/disclosure authority and exact recipient key assignment. It deliberately excludes owner-path-sensitive runtime configuration fields. The ordinary runtime-bound journal mutation still records the exact accepted configuration event under which enqueue was authorized. Relocation may therefore preserve an identical publication operation while retaining local decision provenance. See [projection publication](PROJECTION-PUBLICATION.md).

## Revision 0515 — publication-channel authority

No configuration-format increment is introduced. Publication channels require V12 and the kernel owner must currently hold:

```text
PROJECTION
CONSUMER
SUBMIT
```

The exact read domains required by the bound projection remain mandatory; numeric channels require payload permission. `ALL`, `INSPECT`, `CONSUMER_ADMIN`, automatic internal-processing grants, or retirement access do not imply channel publication authority.

A channel fixes one recipient and output scope, but its `ACTIVE_AT_PUBLISH` policy selects the recipient's active key generation each time a new revision is enqueued. That revision is then durably bound to the selected generation and SPKI. Configuration changes cannot reinterpret an existing obligation.

Current authorization is rechecked for create, publish, status, and retirement. The recipient independently applies authenticated issuer/scope policy after delivery. See [publication channels](PUBLICATION-CHANNELS.md).


## Revision 0516 — automatic publication authority

No configuration-format increment is introduced. Automatic channel enable and every worker step require V12 `PROJECTION`, `CONSUMER`, `SUBMIT`, and the exact adopted evidence-read domain. Numeric channel disclosure requires payload authority.

The grant records the effective read-authority digest accepted at enable time. Any later authority/adoption change closes the grant as `BLOCKED`; restoring configuration does not silently resurrect that generation. Automatic pause/status remain narrow owner operations and do not disclose the projection result.

The recipient route and active key are evaluated for each new publication. A queued operation retains its exact generation and SPKI. Missing route, temporary quota pressure, or unavailable transport do not spend the automatic allowance. See [automatic publication](AUTOMATIC-PUBLICATION.md).


## Revision 0517 — publication-channel epochs

No configuration-format increment is introduced. `publication-channel-new-epoch` requires the same current V12 `PROJECTION`, `CONSUMER`, `SUBMIT`, and exact source-read authority as an ordinary channel publication. Numeric results still require payload-read authority.

The transition additionally requires a currently configured recipient route with one active key generation because its replacement original and delivery policy commit together. The active generation and SPKI are selected at enqueue time and become durable operation meaning; later configuration cannot reinterpret them.

A terminal channel head, knowledge of its operation ID, `CONSUMER_ADMIN`, `ALL`, `INSPECT`, or an older automatic-publication grant does not confer epoch authority. The command selects the exact channel instance, channel revision, epoch, terminal operation/outcome, projection revision/position/result digest, and a bounded reason under one accepted configuration lease.

An enabled automatic grant is blocked by the epoch transition and a previously blocked grant remains blocked. No configuration change automatically creates a replacement epoch or a new automatic disclosure grant. See [publication epochs](PUBLICATION-EPOCHS.md).

## Revision 0518 — V13 bounded peer routes

V13 changes only the routed-peer declaration. The legacy V6–V12 form remains readable and synthesizes one enabled route named `primary`:

```text
peer=B,127.0.0.1:41002,250,5000,20,86400000
```

V13 separates delivery policy from route candidates:

```text
peer=B,250,5000,20,86400000
peer_route=B,preferred-v4,0,ENABLED,127.0.0.1:41002
peer_route=B,secondary-v6,10,ENABLED,[::1]:42002
```

Each routed peer requires one through eight routes. Route IDs are strict stable identifiers. Priority is an unsigned integer; lower values are preferred and route ID breaks ties. State is exactly `ENABLED` or `DISABLED`. V13 originally admitted numeric IPv4/IPv6 endpoints; revision 0580 also admits an explicit canonical serial locator:

```text
peer_route=B,field-link,20,ENABLED,serial-v1|path=/dev/ttyUSB0|baud=115200|data=8|parity=none|stop=1|flow=none
```

The parser rejects duplicate IDs, duplicate locator assignments, duplicate serial device paths even when line settings differ, unknown peer owners, absent routes, and over-capacity route sets. One serial path cannot simultaneously be the local listener and an outbound route. Accepted configuration history prevents one locator from later being silently reassigned to another peer identity. The same peer may add, remove, disable, move, or reprioritize routes through ordinary validated live activation.

Route changes do not rewrite durable application obligations. An active session whose selected route contract changes is retired; unaffected peers and sessions remain usable. See [multi-route reachability](MULTI-ROUTE.md).

## Revision 0520 — V15 finite source disclosure

V15 adds the exact SOURCE_DISCLOSE command class and repeated `source_disclosure=grant-id,manager-UID,source-author-UID,subscriber,subscriber-generation,scope,max-records,max-source-payload-bytes` rules. Each immutable accepted grant ID names one retained provider-managed subscription. It cannot be redefined or recreated with fresh allowance, including after removal or retirement. Limits are 64 historical grant IDs, 16 retained instances per manager UID, 128 records, and 7,680,000 raw payload bytes per grant.

SOURCE_DISCLOSE does not follow from ALL, SUBMIT, EVIDENCE_AUTHOR, INSPECT or projection permission. It explicitly authorizes disclosure from one local author/scope, independently of whether the manager can query payloads. A manager may retain the class without a current data grant so status/retirement remain possible after revocation. A route may be absent while the exact peer-key definition remains; creation and new issuance require its ACTIVE generation and a route. Queued work keeps its prior exact binding.

See [source subscriptions](SOURCE-SUBSCRIPTIONS.md) for receipt-gated progress, terminal handling, metadata, and the explicit not-yet-remote request boundary.

## Revision 0521 — remote use of a V15 disclosure grant

No new configuration version is introduced. The existing V15 `source_disclosure` rule is also the complete authority boundary for an authenticated subscriber request. The provider compares the TLS/HELLO peer node, active key generation and SPKI with the rule's subscriber fields, confirms the named manager UID still has `SOURCE_DISCLOSE`, and uses the current accepted configuration event. A request cannot supply replacement scope, author, budget, key generation or start position.

Initial remote admission requires the exact active recipient key and a current route so the retained instance has a usable delivery policy. Later route loss does not erase or replenish the instance. Removing the rule blocks later remote request/status and provider ISSUE/ACK transitions under current policy, but does not recall an already synchronized outbox operation. Reconnection and new request IDs do not create another subscription for the same immutable grant. See [authenticated subscriber requests](SUBSCRIBER-REQUESTS.md).


## Revision 0522 — automation uses current V15 authority

No new configuration version is introduced. Automatic source delivery is an operational grant over one retained V15 subscription; it does not add a configuration rule or reinterpret `source_disclosure`.

Before every automatic ISSUE or ACK, the daemon confirms that the provider manager still has `SOURCE_DISCLOSE`, that the exact immutable disclosure rule remains current, and that the subscriber peer/generation/SPKI policy still matches. Removing or changing that authority durably blocks future automatic transitions but does not recall an already synchronized ordinary outbox operation.

The remote subscriber cannot enable or replenish automation through a peer request. Enable and pause remain kernel-authenticated local-control operations. See [automatic source delivery](AUTOMATIC-SOURCE-DELIVERY.md).


## Revision 0523 — V16 finite subscription leases

V16 retains the V15 `SOURCE_DISCLOSE` class and extends each `source_disclosure` rule from eight to eleven fields:

```text
source_disclosure=grant,manager_uid,author_uid,subscriber,subscriber_generation,scope,
                  max_records,max_payload_bytes,lease_generation,lease_duration_ms,RETAIN|CANCEL
```

Lease duration is bounded from 100 through 604,800,000 milliseconds. Lease generations use the strict generation grammar and are unique within one accepted policy. The accepted provider policy owns duration and pending disposition; the subscriber request cannot override them.

V15 rules remain indefinite and cannot use remote withdrawal. V16 rules create `NSS4` state with an absolute expiry anchored at synchronized admission. Reconnect, changed request ID, restart, restore, or policy reappearance does not extend that clock.

Live removal of the grant stops new request/progression authority but does not recall an ordinary outbox obligation. Historical rule immutability and exact subscriber key assignment remain enforced. See [subscription leases](SUBSCRIPTION-LEASES.md).

## Acknowledged succession in V16 (0524)

V16 syntax is unchanged. A currently accepted, unused finite successor disclosure rule may be selected by the provider manager through `source-subscription-succeed`. This is an explicit local transition, not renewal through policy reappearance or remote reconnect. It requires unchanged manager/source/subscriber/key identity and a fully acknowledged terminal predecessor. See [lease succession](LEASE-SUCCESSION.md).

## V16 terminal receipt reconciliation

Revision 0525 adds no configuration version or implicit class grant. `source-subscription-reconcile` requires the actual owner UID's current `SOURCE_DISCLOSE` class, the exact unchanged disclosure rule, and the retained subscriber generation/SPKI in a non-revoked state. It does not require an active network route to adopt a previously durable receipt. Removing that rule or revoking the key blocks reconciliation, including idempotent requests. Ordinary observational owner status remains available under its existing narrower rule. See [terminal reconciliation](TERMINAL-RECONCILIATION.md).

## Recipient import scheduling (0527; V17 unchanged)

SOURCE_IMPORT and exact source_view/source_view_binding policy authorize manual import, not automatic execution. The manager separately creates a finite local scheduling grant. Binding changes or revocation block existing grants; adopting new pins requires another explicit enable. Existing read grants do not change. See [automatic imports](AUTOMATIC-IMPORTS.md).

## Revision 0528 administrative review

[Import decision review and selective retry](IMPORT-DECISIONS.md) add bounded administrative pages and an exact one-source reconsideration command under existing V17 SOURCE_IMPORT authority. New NIR2 requests and NIE2/NSV3 state retain explicit local-manager provenance. Earlier durable encodings remain readable; no new read permission, peer protocol or configuration version is implied.

## Recipient-view terminal lifecycle

Recipient-view retirement does not require a new configuration version. V17 `SOURCE_IMPORT` and exact historical ownership authorize it. Accepted configuration rollback cannot override retained retirement. Immutable view IDs, budgets and target reservations remain intact; no reuse is introduced. See [view retirement](VIEW-RETIREMENT.md).

## Outbox inspection (0530)

No configuration version or grant was added for revision 0530. `outbox-query` uses existing node-wide INSPECT authority; it does not require or confer evidence-read permission. [Inspection contract](OUTBOX-INSPECTION.md).

## Current local-control publication authority (0534)

No configuration grammar changes. Every decoded ordinary control uses the active generation for authorization, audit and execution. Activation and rollback cannot retain the shared gate across their own exclusive publication: they reauthorize after serialized waiting before candidate preparation and again at publication. The active predecessor authorizes a change, never the candidate. Revoked waiters are denied; a still-authorized administrator can remove its own grant, and the next request uses the changed policy. A quiesce during preparation blocks publication. See [control authorization](CONTROL-AUTHORIZATION.md).

## Retained configuration inspection (0538)

[configuration-history](CONFIGURATION-HISTORY.md) supplies exact event/binding lookup and bounded retained-prefix pages under current INSPECT. It omits canonical contents, reason text and relocation paths while preserving their commitments. Prefix selection does not grant authority or establish freshness. Runtime-bound mutation bindings are an explicitly described subset, not the entire effect or local-control audit log. Local request kind 27 (NHC1) introduces no new persistent encoding or peer protocol.


## V18 action-result policy (0543)

V18 accepts at most 256 exact action-result rules. One peer generation may have only one result scope for `counter.add`. The peer must be routed and the generation must be its exact active generation at configuration acceptance. The result scope must be a valid evidence scope and cannot be the reserved counter-action request scope.

A V18 action request without a matching result rule is rejected before admission with `ACTION_RESULT_POLICY_REQUIRED`. V6–V17 action behavior remains local-only and is not rewritten by this format. Removing or changing a rule affects future admissions; an existing action retains the rule and route commitments accepted with it.

## V18 reserved obligations (0544)

Existing queue ceilings now include future result capacity for newly admitted V18 actions. Live configuration refuses lower limits beneath combined actual and future usage. Existing unreserved V18 actions are not retroactively charged. No new settings, grants, versions, or implicit disclosure permission are added. See [result-capacity contract](RESULT-CAPACITY.md).


## Revision 0553 binding inspection

The read-only [source-view-bindings API](VIEW-BINDINGS.md) exposes complete current and retained pins for one exact manager-owned view. Current SOURCE_IMPORT is required; no payload permission, import eligibility, provider consent or lease validity is inferred. New first-acceptance indexes are derived through validated replay. Existing configuration and storage representations are unchanged.


## Carrier and TLS mapping through revision 0580

Revision 0578 adds no configuration version, key, locator grammar, or implicit
carrier. All V6–V18 numeric TCP endpoints continue to map to the revision-0577
TCP `TransportLocator`, and the connected stream enters TLS through the custom
`ByteChannel` BIO.

Revision 0580 adds no configuration version or peer/durable encoding. It adds
one explicit self-describing locator grammar:

```text
serial-v1|path=<encoded absolute path>|baud=<rate>|data=<7|8>|parity=<mode>|stop=<1|2>|flow=<mode>
```

Fields are ordered and complete. The path is reachability only and never peer
identity. A serial listener owns one point-to-point device; the same path cannot
be an outbound route in that process. See [the serial contract](SERIAL-TRANSPORT.md).

## Private virtual carrier is not configurable

`virtual_link`/`virtual-link-private`, `NVCS0001`, and virtual fault schedules
are not configuration tokens. The configured parser recognizes only the
documented production `tcp` and `serial` forms. Supplying a private virtual kind
through configuration is unsupported and rejected.
