# Owner-scoped publication-channel inventory — revision 0550

## Scope

`publication-channel-inventory` locates retained channel names and immutable instances without publishing, enabling, replenishing, retrying, adopting an epoch, retiring, or acknowledging anything. It is an observational local C++ control operation. Configuration versions, durable encodings, peer protocols, and existing mutation semantics are unchanged.

```sh
./node/bin/natrav-overlay publication-channel-inventory \
  --control state-b/control.sock --limit 16 --max-bytes 32768
```

All selectors are exact and conjunctive:

- `--lifecycle all|active|retired`.
- `--schedule all|none|enabled|paused|blocked|exhausted`: the latest retained grant's durable state, independently of channel retirement.
- `--outcome all|none|pending|acked|rejected|cancelled|expired`: the latest channel operation's actual durable outbox outcome.
- `--name NAME`, `--instance HEX64`, `--projection NAME`, `--peer NODE`, `--scope OUTPUT_SCOPE`.

Projection names select the registered owner-scoped projection, not its input issuer or scope. An absent or filtered-out instance returns an empty selection. Removed routes do not remove retained channels. No destination reachability probe occurs.

## Authority

The actual connected kernel UID must hold V12-or-later `PROJECTION`, `CONSUMER`, and `EVIDENCE_READ`. The exact source domain of the registered projection must still be readable. Numeric projections and payload-consuming definitions additionally require payload permission. The complete current evidence-read authority must match the projection's latest adopted authority before any associated channel contributes a row, count, ordinal, or commitment.

This deliberately conservative rule also hides an old exact-domain channel after an unrelated change to that UID's broader read authority. An existing explicit projection rebuild can adopt current authority for active work; the inventory never performs that mutation. Retired projection histories are not silently rebound to new domains.

`SUBMIT` is **not** required for this read operation. Listing reveals no new right to publish: channel mutations retain their existing disclosure checks. `ALL`, `INSPECT`, and `CONSUMER_ADMIN` alone do not confer inventory access. No request argument chooses another UID. The existing exact `publication-channel-auto-status` and pause/retirement controls retain their separate stopping-administration contract; this inventory is not an administrative read-domain bypass.

Authorization happens after full bounded request decoding, with accepted configuration protection retained through selection and JSON construction. The state mutex gives channel, projection, grant and outbox metadata one coherent observation. Successful reads append no journal or successful control audit; denials retain the existing audit behavior. Quiescence and drain permit reads while the control endpoint is alive.

## Rows

Rows identify the owner, channel name/instance, active or retired lifecycle, channel revision, epoch, bound projection name/instance/definition, projection lifecycle/revision/processed frontier, recipient, output scope, key policy, publication counts and finite budget.

The latest head includes sequence, epoch, operation and record digest, correction parent, prior-epoch terminal operation/outcome, published projection revision/frontier, generation/SPKI selected at publication, and actual current outbox outcome. Bounded current delivery metadata separately reports its present generation/SPKI, application attempts, latest start, next retry, expiry and cancellation markers, typed error code and transition count. A receipt summary exists only when the authoritative outbox has a receipt. Route probes are not presented as application attempts.

Keeping publication-time and current outbox binding separate prevents a generic valid rebinding from silently relabeling the original disclosure record. Head identifiers and scope are sensitive authorized-owner metadata; they are not recipient acknowledgment or cancellation authority by themselves.

Schedule rows expose the retained schedule revision, number of grants, and only the latest finite grant: generation, configured maximum, spent and remaining publication allowance, minimum interval, typed stop code, and accepted/ended configuration references. This is **durable grant state, not current execution eligibility**. An enabled grant may be caught up, waiting for a predecessor, without a route, or service-suspended. A retired channel is terminal even if its last already-paused or exhausted grant retains that historical label.

Retirement reports the terminal revision, time, configuration reference and exact cancellation disposition. Already admitted evidence and source/projection histories are not changed. Full result values, source payloads, source-operation lists, result/source commitment chains, free-text reasons, and complete publication/grant histories are omitted. Existing exact commands remain the interfaces for separately authorized detail.

## Pagination and comparison

Pages permit 1–32 rows and 2,048–60,000 bytes for the complete annotated JSON response. Nonfitting rows are never partially emitted or skipped. A nonfitting first row returns `PUBLICATION_INVENTORY_PAGE_TOO_SMALL`; otherwise continuation starts at that row.

Responses return `selected_total`, `selection_digest`, `next_offset` and `has_more`. Continue with the same filters and:

```text
--offset NEXT_OFFSET --selection SELECTION_HEX64
```

The page size and byte budget may change. An offset above zero requires a digest. The digest commits the actual owner, node, accepted configuration, read authority, exact filters, and every selected summary in authorized owner-name order. Ordinals are one-based within that selected collection, not global journal offsets.

New selected membership, changed projection progress, channel revisions, head receipts/attempts/outcomes, grant use/state, epoch transitions, retirement, or accepted configuration invalidate continuation with `PUBLICATION_INVENTORY_SELECTION_MISMATCH`. Changes wholly outside the selected channel/projection summaries do not. A shared projection changing can invalidate several channels bound to that same projection, even when only one has published.

A change only to omitted reason/detail text need not invalidate a selection. This is current comparison, not a retained snapshot, freshness anchor or action precondition. Each page recomputes the selected metadata. A same-state compaction or restart can preserve the digest; relocation changes the accepted configuration and requires reselection. Returning to identical accepted facts may reproduce the digest. Continuous selected activity can prevent stable multi-page enumeration.

## Work bounds and format

Only the actual owner's ordered map range is traversed: at most 16 active plus 64 retired channels. Each is checked against one exact registered projection. Only visible filter-compatible channels are summarized; head lookup uses the existing operation-ID index. No payload, full result, full channel/consumer history, logical state or `StateSnapshot` is copied. Up to 80 bounded summaries are built and hashed per request; at most the requested rows plus one nonfitting row are tested for output fit. No separate persisted inventory/index is added.

Reported work counters cover the locked page method, not configuration processing, tree comparisons, startup, transport, incidental metadata allocation or other threads. Hidden/other-owner traversal counts are not exposed. This is not constant-time, lock-free, allocation-free or timing-confidential. Memory is bounded here by registry and row limits; underlying retained evidence is not constant-memory.

Control kind 37 carries `PIN1`: magic; seven u16-length text fields (lifecycle, schedule, outcome, name, projection, recipient, output scope); optional instance; u32 offset, limit and maximum JSON bytes; optional selection digest; strict EOF. Optional digests have a 0/1 marker followed by 32 bytes when present. All integers are big-endian. Names, endpoints, options and limits use strict validation; there is no wildcard UID or payload-return option.

Selection seed: domain `NATRAV_OVERLAY_PUBLICATION_INVENTORY_SELECTION_V1` plus NUL, u16-length node, u32 UID, configuration digest, authority digest, the seven filters, optional instance, u32 selected count. Hash it with SHA-256. For each canonical row in order, hash domain `NATRAV_OVERLAY_PUBLICATION_INVENTORY_ROW_V1` plus NUL, preceding digest, u32 row byte length, and exact unannotated row JSON. The independent test re-encodes this commitment. It is unkeyed comparison, never a bearer credential.

## Evidence and remaining boundary

[Current validation](../validation/VALIDATION.json) distinguishes selected fresh profiles from inherited test source. The new runner exercises real C++ deliveries and receipts, independent PIN1/root encoding, live automatic grants and epochs, actual different UIDs, revoked read and disclosure grants, all five outbox outcomes, full 80-channel owner capacity, quiescence/drain, keyed compaction, signed encrypted restore, relocation and continued correction delivery. The negative control removes only selected-metadata equality and must accept an invalidated page, causing the regression to fail.

No names, grants, budget, slot, publication, result, receipt, retirement or read authority is created or recycled by inventory. No result truth, remote execution proof, freshness, split-brain barrier or independent-host failure domain is established. [Existing channels](PUBLICATION-CHANNELS.md), [automatic publication](AUTOMATIC-PUBLICATION.md), [consumer inventory](CONSUMER-INVENTORY.md).
