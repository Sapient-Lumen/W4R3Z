# Consumer and projection retirement — revision 0513

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Purpose and scope

`consumer-retire` makes an existing consumer terminal, releases its active-registry slot, preserves its final attributable state, and stops an enabled projection grant in the same journal commit. It applies to ordinary consumers and both built-in projection definitions. Nothing is deleted from the evidence store, outbound queue, or recipient state.

Names are permanently reserved **within the retained state lineage**. Creating new work requires a new name. No-instance legacy create/read/process/ack/reset/enable requests cannot accidentally address a replacement object. There is deliberately no replacement under an old name, deletion command, tombstone expiry, or automatic archive pruning.

Retirement is not acknowledgment. The final processed or acknowledged frontier stays exactly where it was. Unread evidence remains unacknowledged. Retirement does not assert that any external effect has completed, been cancelled, or been undone.

## Commands

Obtain a narrow administrative observation first:

```sh
./node/bin/natrav-overlay consumer-retirement-status \
  --control /owned/b/control.sock --consumer temperatures
```

Its `consumer` object includes `instance`, `consumer_revision`, `schedule_revision`, `state`, acknowledged position, and any issued batch ID. This operation does not expose payloads, projection results, input operation IDs, or selected evidence domains.

Select the exact observed active instance and both revisions:

```sh
./node/bin/natrav-overlay consumer-retire \
  --control /owned/b/control.sock --consumer temperatures \
  --instance HEX64 --expected-revision 7 --schedule-revision 4 \
  --pending require-empty --reason 'retire obsolete application definition'
```

All selectors and the reason are required. For a consumer that has never had a schedule, the schedule revision is zero. This is the schedule's **revision**, not its grant-generation count. The instance is its random immutable identifier, not a batch ID.

`--pending require-empty` refuses an outstanding issued page. `--pending abandon` is permitted only when such a page exists and records `ABANDONED_UNACKNOWLEDGED`. Its batch ID, boundaries, source-row digest and issuance provenance remain stored in the frozen consumer. No consumer position, numeric result, acknowledgment count or grant allowance advances.

A concurrent process step, read, reset, enable or pause can make either observed revision stale. The result is `CONSUMER_RETIREMENT_CONFLICT`; reread the active instance and deliberately select the new boundary. Retirement does not silently retry against a moving frontier.

An exact repeated request returns `ALREADY_RETIRED` without another successful journal event. It must retain the original selectors, disposition and reason. After a retirement that stopped an enabled grant, status shows the final schedule revision; `retirement.previous_schedule_revision` preserves the original request selector. A newly invented terminal decision is rejected.

The returned format is `NATRAV_OVERLAY_CONSUMER_RETIREMENT_V1`. The base consumer's `revision` remains its last computation/progress revision; the separate `retirement.lifecycle_revision` is exactly one greater. This distinction permits the original final consumer encoding to remain attributable byte-for-byte.

## Authority and service mode

Both commands require current explicit `CONSUMER_ADMIN` under V11 or V12, in the connected kernel UID's own namespace. No new configuration version is introduced. They do not require current projection or payload access: stopping one's obsolete work must remain possible after processing permission is removed. Administrative authority itself is still mandatory. These commands neither impersonate another UID nor grant result-read permission.

Existing `consumer-status` and `projection-status` can show frozen final results only under their normal current read and projection authority checks. A revoked reader does not gain result access through retirement. Full result replies retain the existing 60,000-byte bound and typed response-limit failure; retirement does not promise unbounded history in one control reply. Full offline `inspect` retains all state and remains sensitive.

`consumer-retirement-status` is observational, including during quiesce and drain. Retirement is a mutation and follows the existing lifecycle gate: it is rejected while quiesced or draining. After explicit resume, an authorized caller can retire. Historical retirement accounts bind accepted configuration, kernel owner UID, actual PID, time and printable reason.

## Atomic boundary and pending work

The state mutex serializes manual commands, the automatic worker, source admission and retirement. Before journal append, the implementation validates the proposed complete transaction against the actual current state, exact owner authority and archive quota.

If a grant is `ENABLED`, retirement changes its final state to `RETIRED`, records who stopped it and why, and preserves spent pages and source frontier. Previously `PAUSED`, `BLOCKED` or `EXHAUSTED` grants remain unchanged historical accounts; the containing retired consumer is terminal regardless of that old grant label.

One synchronized kind-29 `NRT1` record contains the frozen consumer plus retirement metadata and the final optional schedule. It never writes “stop” and “retire” as independent durable operations. The worker excludes retired instances and replay refuses later ordinary or automatic mutations of them. Manual mutation of an enabled projection ordinarily requires pause; this explicit retirement transaction is the bounded atomic stop exception.

Complete pre/post-commit process-kill tests establish the chosen journal boundary. Arbitrary incomplete keyed appends retain the existing fail-closed audit/recovery requirements. The commit is not an external side-effect transaction or universal physical-power-loss guarantee.

## Storage representation and semantic verification

Active consumer encodings `NCS1` and `NCS2` remain unchanged. A retired consumer uses `NCS3`: a length-bounded single active encoding followed by terminal metadata. Nested retirement wrappers are rejected. A domain-separated SHA-256 commitment binds the frozen encoding; a second binds the final schedule, or is all zeroes when no schedule existed.

Retirement metadata contains the terminal revision, accepted configuration-event ordinal, PID/time/reason, previous schedule revision, explicit pending disposition and the two final-state commitments. Owner UID and instance remain in the frozen consumer. The resulting wrapper is bounded to 65,536 bytes; its inner consumer remains bounded to 60,000 bytes, and a schedule to 32,000 bytes.

The checkpoint consumer extension becomes `NDC2` only when retirement is present. It preserves both active and retired consumers. State without retirement keeps `NDC1` and its previous logical encoding. Existing schema 2, `NCP3`, authenticated epochs, encrypted backups and peer protocols are unchanged. Older executables reject the new record/wrapper/extension rather than stripping its meaning.

Journal replay compares the frozen consumer to the precise previous state and derives the only permitted final schedule. Checkpoint replay validates source-derived results, adoption and batch provenance, retirement commitments, historical administrative authority, terminal schedules and registry counts. Unknown or impossible transitions fail closed even when an unkeyed outer checksum was recomputed.

These semantic checks are not hostile-host protection for unkeyed state. Keyed authenticity remains separate, and even a valid authentication chain does not establish freshness.

## Active quotas versus retained archive

| Registry | Global limit | Per-UID limit |
|---|---:|---:|
| Active consumers/projections | 128 | 16 |
| Retired consumers/projections | 256 | 64 |

Retirement exchanges one active slot for one retired slot. The source and its history remain retained, not compressed into an unverifiable “done” bit. At most 384 consumer objects and associated schedules can be stored under these bounds. Current result history, adoption history, schedule grants and source evidence remain attributable under their existing per-object limits.

The archive limit is deliberate. If full, retirement returns `CONSUMER_RETIREMENT_LIMIT` **before mutation**; the active object remains usable. An automatic projection can still use the existing pause command. Nothing drops an old name or result to make room. Names are not recovered by compaction, reset, restart or restoring a post-retirement backup.

The administrative response reports the caller's active/retired counts and fixed limits, not other UIDs' utilization. Full normal offline inspection remains the owner-controlled cross-registry reconstruction path.

Retired state still consumes memory, journal/checkpoint bytes and replay work. Full projection verification can revisit source history. This increment reclaims finite **active slots**, not disk space or an unbounded lifetime namespace. A future archive/pruning protocol would need its own exact ownership, evidence and stale-identity contract.

## Tested behavior

`node/tests/run_consumer_retirement.py` exercises strict independent NCR4 encoding; incorrect instance/revision/schedule selectors; active-slot reuse under new names; stale old commands; explicit abandonment; final numeric result preservation; automatic-worker races; unaffected processor progress; actual UIDs; revocation; both commit-side SIGKILLs; keyed authentication audit; compaction; signed encrypted restore; relocation; semantic corruption; and all 256 retired entries across four actual owner UIDs.

The capacity scenario keeps five active consumers after exhausting the archive and shows that existing reads remain operational. A negative-control build removes the exact requested-instance comparison and must fail the wrong-instance test. Actual results are in [validation](../validation/VALIDATION.json), not inferred from predecessor revisions.

## Limits that remain

Restoring a valid snapshot from **before** retirement can restore an active instance because that snapshot contains no retirement. There is no separately protected freshness authority, distributed ownership service or split-brain prevention. Running two independently copied states can diverge. A tombstone in one state cannot revoke another complete copy.

No secure erasure, source deletion, remote cancellation, external-effect reconciliation, automatic record purge, result archive exporter or name reuse is implemented here. The narrow administrative view and full result view remain separate. Shared-kernel tests do not establish independent-host failures, timing isolation or arbitrary storage power-loss behavior.

## Revision 0514 — publishing a frozen final result

A retired projection may be published only when the owner still has current `PROJECTION`, `CONSUMER`, `SUBMIT`, and exact source-read authority. Numeric results still require payload authority. Retirement administration alone is insufficient.

The NPP1 payload binds terminal retirement revision/time and final consumer/schedule commitments. Publication does not reactivate the projection, acknowledge abandoned input, or change its final result. Identical retries use the same operation ID. See [projection publication](PROJECTION-PUBLICATION.md).

## Discovering retained instances

Revision 0549 adds [owner-scoped current inventory](CONSUMER-INVENTORY.md). It does not change this contract's mutation semantics, read grants, final results or permanent name reservations. The inventory's conservative adopted-authority check may hide an old instance after read-policy changes; it does not reset or delete it.
