# Bounded action inspection — revision 0540

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

`action-query` observes the existing native `counter.add` action sink through the running state owner. It does not admit, execute, acknowledge, cancel, retry, or modify an action. Product runtime remains C++20. The source is `node/src/action_query.cpp`.

## Command and authority

```sh
./node/bin/natrav-overlay action-query --control state-b/control.sock \
  --action EXACT_ACTION_HEX64
./node/bin/natrav-overlay action-query --control state-b/control.sock \
  --issuer A --state PENDING --limit 16 --max-bytes 60000
```

An action ID is its admitted source operation ID. `--action`, `--issuer`, and `--state` are exact, conjunctive selectors. A nonexistent or filtered-out action yields an empty selection. Supported outcomes are `PENDING`, `EXECUTED`, `CANCELLED`, and `EXPIRED`. Denied or malformed action requests never admitted to the action registry are not fabricated as rejected action rows.

The actual Unix-socket UID requires current `INSPECT`, checked after decoding and held through construction under the accepted configuration. This is node-wide administrative metadata authority, not a per-author private view. `SUBMIT` or `ACTION` alone does not confer inspection. Amounts, limits, source identities/scopes, policy commitments, result values, and timestamps are sensitive metadata already in the administrative action model. Evidence payload-read permission is neither acquired nor required. No source payload, free-form reason, private-key path, or canonical configuration is returned.

The method remains observational during quiescence and draining while the control endpoint is alive. Successful and empty queries append neither state nor successful control-audit events; rejected requests retain the ordinary denial-account behavior. The response's principal annotation identifies the current inspector, not the historical executor.

## Retained facts, not invented history

Each row reports stable action queue order, immutable source record digest, issuer/generation, admitted/not-before/expiry times, original execution limits, amount, reservation, attempt count, latest start, current durable outcome, terminal timestamps, and the recorded local-counter result receipt.

`PENDING` includes an unstarted admission and a begun but not completed attempt. `execution_phase` distinguishes `ADMITTED` from `STARTED_UNRESOLVED`. The provisional `ACTION_ATTEMPT_INTERRUPTED` marker is written before execution; seeing it does not prove that a currently running attempt has crashed. Observation never expires work merely because wall time passed.

The stored action state retains only the count and latest start, not the complete per-attempt timeline. `attempt_history` therefore reports `COUNT_AND_LATEST_START_ONLY`. Executor and terminal-principal fields are null and explicitly `NOT_RECORDED`/`NOT_RECORDED_IN_ACTION`; no UID/PID is guessed from a neighboring authorization account. The existing bounded [control-history](CONTROL-HISTORY.md) API can inspect separately retained controls but is not an invented one-to-one effect join.

`effect_completed` means the durable action state contains a verified local counter completion. `result.kind=LOCAL_COUNTER_COMMIT` distinguishes its before/after values and result digest from the peer's source-admission receipt. A peer receipt establishes evidence admission, not counter execution. A local `AUTHORIZED` decision also does not establish effect completion. Prior valid snapshots, unkeyed state replacement, and host compromise retain their existing boundaries.

A pending action reserves its exact amount. Every terminal outcome reserves zero. Original limits describe its admission contract, not a newly substituted configuration. The sink totals in `sink_observation` concern all retained actions at this page's state observation, not just the selected issuer/outcome. Those totals can change between otherwise valid pages when unrelated actions change.

Cancellation and expiry reasons are replaced with byte length and:

```
SHA256("NATRAV_OVERLAY_ACTION_REASON_V1" || 0x00 || exact_reason_bytes)
```

A digest does not conceal a low-entropy reason against guessing.

## Actual source and configuration references

`source_admission` is obtained by exact operation-ID lookup into stored inbound evidence. It retains the actual admitted sequence, issuer, recipient, scope, immutable digest, payload size, and authorization account: peer generation, operation class/resource, policy/rule digests, decision time, and typed reason. It is not reconstructed by parsing the payload again. The account does not itself store an SPKI or executor identity; the API does not substitute current keys or invent them.

`mutation_bindings` identifies up to four actual retained runtime wrappers: admission, latest start, completion, and terminal cancellation/expiry. Each supplies the binding ordinal, journal kind, configuration-event ordinal/generation/digest, and inner-payload digest. These can be inspected using [configuration-history](CONFIGURATION-HISTORY.md). Older unbound states report null references rather than backfilling current configuration. Compaction preserves the actual references.

These are bounded latest-state references, not a full action transition log. Binding memory is at most four ordinals per action having retained references. Checkpoint reconstruction links retained bindings in a linear startup pass; queries never scan all bindings or reopen historical identity files.

## Pages and coherent continuation

Response format: `NATRAV_OVERLAY_ACTION_QUERY_V1`.

Rows: 1–64; default 16. Complete annotated JSON: 2,048–60,000 bytes; default 60,000. A whole nonfitting row ends a nonempty page. A nonfitting first row produces `ACTION_QUERY_PAGE_TOO_SMALL`; no row is truncated or skipped. The cap includes the principal annotation but not the outer length prefix or control-response framing.

List order is stable `ACTION_QUEUE_SEQUENCE`. `selected_total`, `returned`, `more`, and `next_cursor` account for the complete filtered registry, not the generic preview. An exact action request returns at most one row and no history cursor.

Continue with the returned cursor and identical filters, row limit, and byte budget. The authenticated `ACQ1` token binds actual UID, node/query, accepted configuration digest, derived selection revision, queue position, and a five-minute monotonic expiry anchored at the first page. Page reads do not extend that expiry. Cursor HMAC uses its own random process-local secret and `NATRAV_OVERLAY_ACTION_CURSOR_V1` domain. It cannot be substituted for an outbox token.

- Changed selected action content/membership: `ACTION_CURSOR_STALE`.
- Changed principal, configuration, or query options: `ACTION_CURSOR_CONTEXT_MISMATCH`.
- Altered token or restarted/restored daemon: `ACTION_CURSOR_INVALID`.
- Elapsed token lifetime: `ACTION_CURSOR_EXPIRED`.

Unrelated issuer/outcome changes need not invalidate the filtered selection. Same-process compaction can preserve a cursor because it does not rebuild the live derivative. There is no retained multi-page historical snapshot. Continuous selected execution can force the caller to restart enumeration. Derived revisions are run-local metadata, not durable action authority or a freshness commitment.

## Derived work and synchronization

The API reuses the production ordered inspection-index implementation with separate action issuer/outcome buckets. Admission, begin, completion, cancellation, and expiry all notify it through the ordinary semantic decoder's `index_action` hook. Validated checkpoints rebuild it. No journal kind, checkpoint field, storage schema, or logical-state digest changes.

Each page visits at most its row limit plus one nonfitting action, the same number of exact source entries, and at most four binding references per visited action. Exact lookup visits at most one action. Empty pages visit none. No whole `StateSnapshot`, logical serialization, payload copy, or historical canonical parse occurs in the page method. Work fields count those locations; they do not measure total process allocations, map comparisons, authorization/configuration processing, transport, or another thread's work.

Rows are encoded under one state mutex and one accepted configuration lease. Index memory grows with actions; ordered lookups are not constant-time and mutex scheduling is not wait-free. Successful observation is not a transactional condition for a later cancellation.

## Strict local wire

The new NOC1 request kind is 29. Its body is `AQY1`, two length-prefixed issuer/state strings, a strict optional nonzero 32-byte action ID, big-endian u32 row and byte bounds, and a length-prefixed cursor. Exact EOF is required. Cursor size is exactly 128 bytes encoded as 256 lowercase hexadecimal characters. Unknown outcomes, invalid optional markers, zero IDs, unsupported versions, and trailing data are rejected. Existing control kinds and peer protocols are unchanged.

## Validation scope

`node/tests/run_action_inspection.py` exercises 150 actual C++ admissions, complete beyond-preview enumeration, exact filtered lookups, independent action-receipt reconstruction, duplicate delivery, all four durable outcomes, real interrupted attempts, cursor integrity/staleness/restart, independent wire encoding, real UID denial and post-decode revocation, quiescence/drain, compaction, keyed signed encrypted restore, relocation, and explicit absence of legacy bindings. Actual completed profiles and adverse attempts appear in [validation](../validation/VALIDATION.json) and [attempts](../validation/ATTEMPTS.md). Five-minute expiry is a code contract; the separate wall-clock expiry test is not claimed unless recorded as executed.

## Conditional action selection (0542)

Exact-action rows now include `condition`, a bounded `ACTION_SEMANTIC_SELECTION_V1` commitment. It binds the complete durable action state, exact source-admission/authorization commitments, retained configuration bindings and preceding conditional-administration root. List rows return `condition: null`; a durable administrative mutation must deliberately select one exact action.

The condition is consumed by [conditional action administration](ACTION-ADMINISTRATION.md) together with the response-level accepted configuration digest. It is not a cursor, permission token, freshness proof or general mutation receipt. A later action/configuration change makes it conflict; a fresh commitment still cannot override terminal action rules.

## Action-result links (0543)

`action-query` rows now include `action_result` when an admitted V18 action has an exact result binding. The object exposes the accepted result scope, policy/rule digests, configuration event, recipient generation/SPKI and—after terminalization—the result outcome, operation ID and record digest.

The link is inspection metadata, not proof that the result was remotely delivered. Use `outbox-query` on the result operation to inspect its independent pending, acknowledged, rejected, cancelled or expired delivery state. The local action receipt and remote delivery receipt remain separate facts. [Durable result return](ACTION-RESULTS.md).

## Reservation inspection (0544)

The result account additionally reports reserved_payload_bytes and capacity_state: RESERVED, CONVERTED or LEGACY_UNRESERVED. The retained maximum remains provenance after conversion; it is not a still-held reservation. Result-bound conditional state now uses ACM2, binding this account. See [result-capacity contract](RESULT-CAPACITY.md).

Recipient-side `action-result-query` now provides explicit observational NAC1/request correlation under INSPECT plus result-payload read authority. It never conflates remote claims with local effects. See [correlation contract](ACTION-RESULT-CORRELATION.md).
