# Authenticated subscriber requests — revision 0524

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Peer path

Subscriber request, status, and withdrawal travel through the existing persistent peer stack:

```text
numeric route candidate
→ TCP
→ mutual TLS 1.3
→ exact configured generation/SPKI verification
→ HELLO node binding
→ NOS1 bounded reusable session
→ strict NOA1 application request/response
```

There is no separate listener, plaintext fallback, or remote-query protocol.

## Request and status

`source-subscription-request` asks the provider to instantiate one already accepted grant. `source-subscription-remote-status` returns a bounded private account to that exact authenticated subscriber.

For V16, both commands include `--lease-generation`. The provider derives every other authority field from its accepted configuration. A request cannot select author UID, scope, budgets, key policy, lease duration, withdrawal policy, or starting position.

Changing request IDs or reconnecting cannot create another instance or replenish budgets. Exact request retry is idempotent.

## Authenticated withdrawal

`source-subscription-withdraw` is available only for V16 leased grants. It selects the exact grant, lease generation, instance, revision, request ID, and reason.

The provider checks the current accepted disclosure rule and the authenticated peer node/generation/SPKI before mutation. Another peer cannot inspect or withdraw the instance. A stale revision cannot terminalize newer state.

A successful response uses `NATRAV_OVERLAY_REMOTE_SOURCE_SUBSCRIPTION_RESPONSE_V2` and includes lease expiry, provider-selected withdrawal policy, terminal kind, terminal pending disposition, and exact cancelled operation when applicable.

## Strict wire kinds

| NOA1 kind | Meaning |
|---:|---|
| 5 | V15 remote source-subscription request/status |
| 6 | V15 response |
| 7 | V16 leased request/status/withdrawal |
| 8 | V16 leased response |

The inner request ID must equal the containing NOS1 operation ID. Trailing material, unknown commands, invalid reasons, mismatched operation identities, and malformed lease selectors fail closed.

## Security boundary

TLS key possession and configured identity do not themselves grant disclosure. The provider's accepted grant and current manager policy remain authoritative.

Request acceptance is not a source delivery receipt and spends no record or byte budget. Withdrawal is not recall. An already queued retained operation may still deliver; a cancelled pending operation may already have been observed elsewhere.

No subscriber-side command can enable provider automation, advance source progress, reset a frontier, replace a key, enlarge a budget, or create a successor lease.

## Provider-controlled succession (0524)

The new local successor command does not extend this remote protocol or fabricate a remote request account. Old request IDs remain bound to the predecessor. A remotely requested grant cannot overwrite a provider-managed successor, and remote status/withdrawal for that successor is not added. See [lease succession](LEASE-SUCCESSION.md).
