> Revision 0606 connects this state machine to exact V21 configuration grants and the existing authenticated journal. See [V21 durable custody authority and evidence](DURABLE-CUSTODY-AUTHORITY.md). Ordinary routes remain non-relaying.

# Private finite custody-envelope model

Revision 0605 adds a private, bounded model for transferring custody of one
unchanged `NHCP0001` capsule across an explicit ordered route. Its translation unit is compiled by the ordinary product build and the normal executable reports the feature marker. It is deliberately
not registered with configuration, transports, the daemon, or durable state.
`configured_custody_relay` remains false.

This increment proves a state machine and its negative controls. It does not
make a node a relay.

## Authority boundary

The model receives an ordered route containing the origin, zero or more named
custodians, and the final recipient. Each party record contains an exact node
identifier, signing-generation identifier, and raw Ed25519 public key. The
origin signs the immutable envelope. Each transfer and acceptance is separately
signed by the exact actor named at that route position.

Those keys are explicit cryptographic inputs, not self-authenticating policy.
A future durable integration must bind them to accepted configuration before
using the model as relay authority. Merely decoding a valid envelope does not
admit a route or authorize custody.

## Canonical formats

The envelope format is `NHCE0001`. It binds:

- one opaque capsule byte length and SHA-256 digest;
- creation and expiry times;
- an ordered, loop-free route of 2 through 16 parties;
- an exact hop bound equal to the number of route transitions;
- every party's node, signing generation, and Ed25519 public key;
- the origin's Ed25519 signature over the complete unsigned envelope.

The capsule is never decrypted or re-encoded by the custody layer. Exact bytes
must match the bound length and digest.

The record format is `NHCR0001`. Records alternate strictly:

```text
current custodian TRANSFER -> exact next route party
exact next route party ACCEPT -> current custodian
```

Each record binds the envelope digest, capsule digest, exact sequence, route hop,
actor, counterparty, event time, and prior-record digest, then carries the
actor's Ed25519 signature.

## Finite state

At most 15 route transitions and 30 distinct records are possible. The state is:

- current route position;
- whether an acceptance is pending;
- next exact sequence number;
- last event time and record digest;
- a bounded set of accepted record digests.

Exact record replay is idempotent. A conflicting record at an already consumed
sequence is rejected. Records cannot skip hops, move backward, name another next
hop, reuse a party, reuse a signing key, exceed expiry, move time backward, or
continue after the final recipient has accepted custody.

Final custody acceptance is deliberately not called delivery. The final
recipient still must decrypt and import the opaque capsule through the existing
one-hop policy and application/receipt machinery. Custody evidence cannot create
an application receipt.

## Deliberate non-features

Revision 0605 adds no configured route or listener, durable custody journal,
automatic route selection, discovery, opportunistic forwarding, open relay,
capsule decryption by custodians, global consensus, or second executable.

The next integration must first bind route parties and next-hop permission to
accepted configuration, then persist envelope and record transitions under the
existing authenticated durable-state boundary. Until that work is complete,
ordinary nodes cannot relay custody envelopes.

See `validation/revision-0605/STATUS.json` for observed source, build, test, and
assurance gates. Same-host model evidence is not independent-host, hostile-custody,
or physical-media verification.
