# Exact nested source outbound admission — revision 0560

## Scope and ownership

Ordinary manual `ISSUE` and native `AUTO_ISSUE` reuse the evidence record already produced by the strict NST3 decoder. This is internal construction work: there is no new command, flag, request encoding or peer message.

`ParsedSourceProgress` still owns immutable transaction bytes, their SHA-256 digest and the normal strict decoder result. It is private, stack-owned, noncopyable and nonmovable. Its new read-only record slice points only into that object's const `transaction.outgoing` buffer; it never borrows a caller's mutable input. Construction reads the 36-byte operation/length header once. The span measures 16 bytes on the tested host, not the size of all retained preparation or allocator overhead.

An ACK parse has no record slice. The slice and record disappear with the originating locked command. They cannot enter a subsequent worker turn, status result, persisted record, checkpoint assertion or caller-controlled preparation handle.

## Exact bytes at both inner boundaries

The existing outer transaction bindings are unchanged: complete length/content/SHA-256 equality at preflight, before frame publication and at live application, plus the initial immutable snapshot hash.

The composite admission helper requires its complete supplied bytes to equal the strictly decoded object's owned composite. Its inner record helper separately requires the supplied record bytes to equal the owned record slice. Equality uses length and every byte, not pointer identity or a hash surrogate. Equal bytes in different storage are accepted; changed, truncated, extended, malformed or substituted bytes cannot select the retained record.

Each selection rechecks state owner, the exact retained predecessor object, subscription instance/revision/structural commitment, active accepted configuration event/digest and queue limits. Replaying, acknowledging, selecting an unknown part and supplying a preparation through the generic dispatcher are rejected. The prepared admission helpers also require the live runtime-bound mutation context.

No additional payload snapshot, re-encoding or hash is introduced for these bindings. Their cost is two complete byte comparisons plus the small framing slice. They do not confer authority or freshness.

## Syntax is shared, admission decisions are not

Both source preflight and live application retain their independent checks of predecessor shape, current disclosure authority, source order and local authorship, expected complete source envelope and policy, source/delivery operations, record digest, payload budget, current outbox absence/capacity, manual request identity or exact finite automatic-grant consequence. Neither inner binding substitutes for those predicates.

The old generic composite and record admission bodies now reside in common private helpers. The prepared path selects a const record and calls `validate_evidence_record` at each stage, replacing the same validation previously reached through the decoder. It still checks composite operation/policy binding, local issuer, duplicate operation index, canonical store digest and queue sequence, then invokes the unchanged outbox indexing hook. The policy bytes still pass through the ordinary independent policy decoder and its receipt, duplicate-policy, time, attempts, backoff, generation and SPKI checks.

The normal path invokes those same helpers with no preparation and still uses `decode_application_message` twice. There is no forked "validated admission" implementation. The source-level semantic passes still perform their own current outbox capacity checks; a preparation stores no successful absence/capacity verdict.

ACK performs no nested admission work. Both semantic passes still find and bind the actual durable receipt, including recipient, recorder, operation, record, generation/SPKI and receipt commitment. Single-use automatic eligibility and permanent oversize blocking before transient route/capacity outcomes remain unchanged.

## Replay and compatibility

Untrusted source replay rejects live preparation, independently decodes NST3, reconstructs the selected source and independently decodes the nested record twice. Full-state source lifecycle transitions and checkpoint loading do not select prepared admission. Generic outbound writers—including publication and action-result paths—retain their existing decoder path.

No request, journal, NSS/NST encoding, logical digest, peer envelope, permission class, configuration version, storage schema or size limit changes. Revision 0559's actual binary reads identical new journal and checkpoint inputs with the same logical digests as the new normal, reference and forced-independent-admission builds. Existing older NSR6 compatibility boundaries are not broadened.

## Measurement preceded reuse

The actual revision-0559 archive and 357 manifest entries verified. Its unchanged executable was freshly tested on the 128-source and 58,000-byte source fixtures. New nested counters were separately added to an **instrumentation-only predecessor build**, preserving its ordinary decoder path. Those new counters must not be attributed to the unchanged predecessor binary.

| Named work at ISSUE | Instrumented 0559, source 128 | 0560, source 128 | Instrumented 0559, large source | 0560, large source |
|---|---:|---:|---:|---:|
| Nested evidence-record decodes | 2 | 0 | 2 | 0 |
| Nested encoded record bytes decoded | 1,032 | 0 | 116,584 | 0 |
| Nested payload bytes decoded | 846 | 0 | 116,462 | 0 |
| Exact nested binding comparisons | 0 | 2 | 0 | 2 |
| Bytes compared by those bindings | 0 | 1,166 | 0 | 116,718 |
| Inner evidence validations | 2 | 2 | 2 | 2 |
| Policy decodes | 1 | 1 | 1 | 1 |
| Canonical store payload bytes copied | 423 | 423 | 58,231 | 58,231 |
| Canonical store digest calls | 1 | 1 | 1 | 1 |

The 128-source fixture delivers 64 originals followed by 64 corrections, each carrying 128 raw source bytes: 16,384 accounted bytes and 128 actual recipient admissions. All 256 compact ISSUE/ACK responses are checked. At source 128, the evidence record is 516 bytes, composite 650 bytes, ISSUE transaction 887 bytes and ACK transaction 229 bytes. The normally decoded policy remains 98 bytes.

The large source contains 58,000 raw bytes, wrapped in a 58,231-byte evidence payload. Its encoded record is 58,292 bytes, composite 58,426 bytes and transaction 58,663 bytes. Added comparisons cover composite plus record. The 36-byte slice header is read once; no new hash is charged to inner binding.

The current `independent-outbound` diagnostic build disables only nested record reuse. Outer NST3 parsing, source/configuration preparation and automatic eligibility remain active. It reproduces the nested work of the instrumented predecessor on equivalent fixtures and agrees on identical journal/checkpoint inputs.

These are exact named calling-thread work counts, not every copy, allocation, hash, transport byte or process-wide cost. Compared-byte counters describe the input lengths covered by equality, not processor memory loads; a library can optimize identical spans. Existing composite-return copying is now separately counted and remains one evidence payload. Canonical store hashing still encodes/hashes metadata and a domain separator as well as payload; `outbound_store_digest_payload_bytes` names only its payload contribution. No end-to-end latency, throughput or peak-memory claim follows from these counts.

## Tests and negative control

The private native probe executes 48 checks: 36 rejection boundaries and 12 positive/accounting comparisons. It tests equal content at different addresses, the immutable owned slice, changed bytes/lengths/types/operation/recipient/issuer/policy, ACK misuse, replay/unbound/generic/checkpoint misuse, changed state/configuration/queue origin, actual outbox occupancy and pending capacity at both semantic passes, and failed preflight with no original mutation. Full canonical reconstruction creates separate memory states for live application, replay and generic admission comparisons. The original journal and logical state remain unchanged.

The real-peer regression independently alters 53 original/correction nested accounts and recomputes outer lengths/checksums. Normal startup rejects every changed journal and leaves its bytes unchanged. The large-source case retains the previous 14 malformed NST3 replay checks. Existing process-kill, receipt, allowance, succession, policy removal, keyed recovery, restore and relocation cases remain in the validation profiles.

The narrow negative control removes only complete nested bytes-to-owned-record equality. The same probe then fails with `source outbound boundary accepted: composite-byte-snapshot`; the wrapper confirms that the original journal remains unchanged. Detection is a successful negative-control result, not a correct weakened product. Weakened source, objects and executables are excluded from the package.

See [validation](../validation/VALIDATION.json), [measurements](../validation/METRICS-SUMMARY.json), [testing](TESTING.md), [outer transaction contract](PARSED-SOURCE-PROGRESS.md), [source preparation](SOURCE-PREPARATION.md) and [automatic eligibility](AUTOMATIC-SOURCE-ELIGIBILITY.md).
