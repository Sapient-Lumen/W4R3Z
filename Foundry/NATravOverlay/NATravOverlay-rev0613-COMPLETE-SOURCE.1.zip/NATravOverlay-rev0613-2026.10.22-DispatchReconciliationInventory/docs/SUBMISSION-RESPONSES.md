# Narrow ordinary submission responses — revision 0533

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Scope

Persistent `submit`, `revise` and `action-submit` use the same native `ControlSubmit` path. Revision 0533 removes two unnecessary copies: the payload-bearing `StoredOutbound` returned by enqueue, and the complete `state.snapshot()` taken solely to locate the just-enqueued operation for its reply. Configuration formats, peer protocols, journal kinds and storage schema 2 do not change.

`NATRAV_OVERLAY_CONTROL_SUBMIT_V1` retains its existing fields and adds `status_basis`. Authorized inspectors additionally receive bounded per-request `work` metadata. There is no new command or mandatory flag. Legacy one-shot delivery still receives its bounded duplicate receipt; one-shot projection publication still reports its enqueue-time outcome.

## Two facts, not one transaction spanning the network

`queue_disposition` describes the synchronized enqueue decision: `QUEUED`, `ALREADY_PENDING`, `ALREADY_ACKED` or `ALREADY_REJECTED`.

`status` describes a later coherent exact-operation observation under the state mutex, identified by `status_basis: POST_ENQUEUE_OBSERVATION`. Between those two owner-locked observations, a receipt, cancellation, expiry or other legitimate transition may commit. Thus `QUEUED` with `ACKED`, `CANCELLED` or `EXPIRED` is valid. It does not claim those transitions happened together. The outcome may change again after observation and before the client receives bytes.

Neither reply is itself a recipient receipt, a durable conditional-action selector, an exactly-once external-effect guarantee, or a retained snapshot. Use `outbox-query` for delivery metadata and current conditional-administration commitments.

A lost response is not proof that enqueue failed. Existing immutable operation IDs and duplicate semantics remain the recovery mechanism. The test kills the actual daemon after synchronized enqueue but before its response; restart and exact retry recover `ALREADY_PENDING` without a second operation.

## Bounded metadata, stable lifetimes

`QueueResult` now contains an operation ID, immutable record digest, scalar disposition/status, a policy-present flag and an optional bounded `DeliveryReceipt`. It owns no evidence payload, full delivery policy, error detail or transition-history vector.

`NodeState::observe_submission` uses the exact operation-ID index under the owner mutex. It verifies the immutable record digest against the enqueue result, then copies only recipient and resource strings plus scalar identity/class/outcome metadata. No pointer or reference into a replaceable state vector survives unlock. Status string views refer only to static literal names.

The result/observation identities are compared again at reply construction. An absent or mismatched record fails explicitly rather than constructing a success from another entry. The existing status precedence remains receipt, cancellation, expiry, active rejection, then pending. Every admitted delivery-history transition either sets rejection or clears it, so the last transition suffices for scalar status; error text and older transitions need not be traversed or copied.

## Atomic enqueue and policy preservation

New persistent submissions retain the single kind-24 evidence-plus-initial-policy append. No scheduler or restart can observe a newly accepted operation without its initial recipient generation and SPKI.

A duplicate never rewrites an existing policy, timestamp, receipt, rejection or key binding merely because current configuration changed. Expired and cancelled duplicates retain typed errors. Changed content under an existing operation ID remains `OUTBOUND_OPERATION_CONFLICT`.

Where an older, otherwise admissible unbound queue record receives an explicit initial policy through the `NodeState` API, initialization now occurs while the enqueue lock is still held. It cannot race a second initializer with a different timestamp between a copied result and `ensure_outbound_policy`. The isolated native test runs 16 initializers against one actual unbound journal entry, requires one policy append, and replays the result. This does not relax the existing live-mode refusal to adopt unbound historical state implicitly.

Prospective queue capacity checks remain in force before new admission. Duplicate lookup precedes those checks, so a valid duplicate can still be confirmed at full capacity. Revision 0535 replaces that scan with exact derived global/recipient aggregates; payload hashing, serialization and durable writing still perform their required work. See [pending capacity](PENDING-CAPACITY.md).

## Current-principal authorization

The daemon still obtains Linux `SO_PEERCRED` before reading a bounded frame. Ordinary submissions now acquire a generation lease after decoding and use that same accepted configuration for class authorization, audit binding, route/policy selection, enqueue and reply metadata. A slow pre-revocation connection cannot retain the earlier submission permission.

`SUBMIT` does not imply `INSPECT` or evidence-read authority; action submissions still require their original action class. No additional read permission was added. Work counters are returned only to callers who also hold current `INSPECT`, because work counters can disclose administrative accounting behavior. A submit-only principal receives the ordinary operation response without `work`.

This correction is specific to ordinary ControlSubmit dispatch. It is not a claim that every older control handler was redesigned or audited in this increment.

## Measured work

The request-local `SubmissionWorkScope` spans enqueue, exact reply observation and JSON construction on that calling thread. It excludes request decoding, pre-enqueue authorization/audit, other threads, final principal annotation and socket/TLS framing. Counters are observational and never journaled.

- `digest_payload_bytes`: bytes in the submitted payload passed to the direct enqueue record-digest computation. This is not all cryptographic work in replay or transport.
- `encoded_application_bytes`: actual direct application serialization for a new enqueue. Duplicates encode no new application record here.
- `enqueue_journal_payload_bytes`: actual unframed evidence/policy body supplied to the enqueue append. Runtime wrappers, authentication records and filesystem writes are additional work.
- `queue_metadata_records` and `observation_metadata_records`: records read at the bounded return and exact observation sites.
- `receipt_text_bytes_copied` and `observation_text_bytes_copied`: bounded string content copied at those sites, excluding scalar storage, allocator overhead and JSON expansion.
- `capacity_records_visited`: actual entries visited by the independent full-scan reference while this calling-thread scope is active. Production admission no longer calls it; tests deliberately demonstrate nonzero reference visits.
- `snapshot_calls`, `snapshot_evidence_payload_bytes`, `snapshot_logical_bytes`: actual calls to the complete snapshot site, core inbound/outbound payload bytes copied there, and canonical logical bytes built there. The native test intentionally calls a snapshot under instrumentation and verifies nonzero values; the ordinary response cases require all three to remain zero.

The large fixture contains 8,192 unrelated inbound records with 16 MiB of payload plus 4,096 settled outbox entries. Current 14-byte and 60,000-byte submissions use actual native control and peer paths. The stored background history is independently encoded legacy state, not thousands of authenticated peer deliveries. A 30-second startup allowance belongs only to large-fixture reconstruction; product control and I/O deadlines are unchanged.

Response sizes are measured by the test after principal annotation. Under the tested maximum binary input, the metadata response remains below 2,048 bytes. This is a bounded fixture result, not a general throughput or universal latency claim.

## Tests and safety boundary

`run_submission_responses.py` covers large unrelated history, maximum binary inputs, corrections, pending/acknowledged/rejected/cancelled/expired duplicates, atomic concurrent duplicates, real receipt/cancel/expiry interleavings, policy preservation, quotas, actual delegated UIDs and revocation, lost reply, keyed compaction, signed encrypted restore and relocation.

The opt-in `NATRAV_OVERLAY_TEST_SUBMIT_AFTER_QUEUE_PAUSE_MS` test hook is bounded to 1,500 ms and disabled by default. It pauses only after enqueue, with no state lock held, so actual peer delivery or administration can win before observation. It does not bypass policy, identity, receipt or state checks and is disabled in work measurements.

The independent native entrypoint `test_submission_metadata.cpp` links the exact production state implementation. It verifies the missing-policy race, receipt compatibility, immutable observation binding, snapshot-counter instrumentation, rejection/retry status and restart. Its executable is a test output and is not shipped.

The negative control substitutes cached enqueue status for the later observation. The actual receipt-race regression must fail: a delivered operation cannot be reported as still pending merely because enqueue originally saw it pending.

## Remaining limits

Startup validation, legacy administrative reply paths, offline snapshots and canonical checkpoint construction remain broad. Ordinary status now uses [bounded metadata](RUNTIME-STATUS.md); full logical-state hashing is explicit. Enqueue still digests its payload, serializes actual durable input and checks exact derived pending-capacity totals. The current state mutex is not lock-free. This revision does not establish timing confidentiality, arbitrary-host static-binary portability, external freshness, split-brain prevention or physical-power-loss durability. Static OpenSSL/glibc portability warnings remain relevant.

## Pending-accounting work since revision 0535

`capacity_aggregate_reads` counts actual logical global and exact-peer reads. `capacity_entries_touched`, `capacity_acquires` and `capacity_releases` distinguish idempotent decoder notifications from changed contributions. New queue-plus-policy admission normally reads two pairs and acquires once; duplicate confirmation does neither. These are per-call work counters, not persisted quotas or every map comparison. [Contract](PENDING-CAPACITY.md).
