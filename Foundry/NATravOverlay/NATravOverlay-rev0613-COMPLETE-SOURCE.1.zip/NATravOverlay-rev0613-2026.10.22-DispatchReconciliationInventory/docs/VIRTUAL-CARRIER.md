# Deterministic private virtual carrier

Revision 0579 adds an internal, carrier-neutral `OrderedByteStream` pair used to exercise the real TLS, HELLO, NOS1, application-message, receipt, and clean-close paths under replayable adversity.

The virtual carrier is a verification instrument. It is not a configured route, a peer-wire protocol, a discovery mechanism, a production transport, or a substitute for physical-carrier testing. Normal configuration recognizes only production carriers explicitly registered by the transport parser. Revision 0580 registers TCP and serial; the virtual kind remains unavailable.

## Authority boundary

`TransportKind::virtual_link` is deliberately assigned the private value `255`. It has a name and stream capability for diagnostics, but:

- `parse_transport_kind()` does not accept it;
- it has no locator syntax;
- connector and listener registries reject it;
- runtime configuration does not expose it; and
- only a fixture that owns both endpoints can construct it with `make_virtual_link()`.

`OutboundPeerSession::open_connected()` is the corresponding injected-stream seam. It does not bypass TLS, peer identity, key-generation state, SPKI pinning, HELLO, NOS1, application framing, receipts, quotas, or clean close. It bypasses only route lookup and carrier connection establishment after a fixture has already supplied an owned `OrderedByteStream`.

## Canonical schedule

A schedule is encoded as `NVCS0001`. Multi-byte integers are unsigned big-endian values.

The 40-byte header contains:

| Offset | Size | Meaning |
|---:|---:|---|
| 0 | 8 | ASCII magic `NVCS0001` |
| 8 | 2 | version, exactly `1` |
| 10 | 2 | flags |
| 12 | 8 | deterministic seed |
| 20 | 4 | per-direction queue capacity |
| 24 | 4 | default read chunk |
| 28 | 4 | default write chunk |
| 32 | 4 | MTU ceiling |
| 36 | 4 | event count |

Flag bit 0 enables half-duplex arbitration. Bit 1 records that an initial grant is present. Bit 2 selects the second endpoint when an initial grant is present. All other bits are rejected.

Each 24-byte event contains endpoint, operation, fault, one reserved byte, one-based operation index, deterministic delay steps, a maximum-byte override, a fault parameter, and four reserved bytes. Events are canonicalized by endpoint, operation, and operation index. Duplicate keys, unknown values, nonzero reserved fields, noncanonical order, trailing bytes, and out-of-bound fields are rejected.

The implementation imposes finite limits:

- at most 4,096 events;
- at most 1 MiB queued in either direction;
- chunks and MTU no larger than 65,536 bytes; and
- at most 1,000,000 deterministic delay steps per event.

The schedule digest is SHA-256 over the exact canonical encoding.

## Stream and queue semantics

Each endpoint owns one side of a shared link. Each direction has a finite byte queue, deterministic segment boundaries, optional held reorder segment, write-half state, and lifetime state.

A successful write returns no more than the configured write chunk, MTU, event maximum, and remaining queue capacity. A successful read returns no more than the configured read chunk, event maximum, caller buffer, and the first queued segment boundary. Segment boundaries prevent thread timing from changing replay results: a read cannot opportunistically merge bytes from a later write merely because that write happened to run first on one execution.

A reorder event reserves at least one queue byte for the following segment. The selected segment is held, the next segment is enqueued first, and the held segment is enqueued afterward. If the writer half-closes before a following segment exists, the held segment is flushed before EOF rather than silently lost.

Half-close is directional. Once queued bytes drain, the reader receives EOF while the reverse direction can remain usable. Endpoint destruction performs an orderly disconnect of the owned endpoint. Explicit reset is distinct and is observed as reset by both sides.

Half-duplex mode grants one endpoint permission to write. The grant remains with that endpoint until its queued direction drains, then becomes available to the opposite endpoint. There is no hidden process-global clock, queue, fault index, or grant.

## Fault controls

Events are indexed independently for each endpoint and operation class (`read`, `write`, and `shutdown-write`). Supported controls are:

- `none`: optional deterministic delay and maximum-byte override;
- `timeout`: fail the selected operation with the normal I/O timeout classification;
- `reset`: reset the complete link;
- `disconnect`: orderly-disconnect the selected peer;
- `drop`: accept a bounded write without delivering its bytes;
- `duplicate`: deliver one to three configured extra copies;
- `corrupt`: flip one deterministic byte with a deterministic nonzero mask derived from the schedule seed and operation identity; and
- `reorder`: exchange the selected segment with the following segment in the same direction.

Loss, duplication, corruption, and reordering are valid only for writes. Delay steps do not sleep; they advance exposed deterministic wait counters. A real deadline expiration while waiting for peer progress remains a deadline expiration and is recorded separately.

## Replay evidence

The link emits canonical `NVTR0001` trace bytes. Each record binds:

- endpoint and operation;
- one-based operation index;
- result classification;
- canonical event index, when one applied;
- deterministic delay steps;
- requested byte count; and
- resulting byte count.

Trace records are ordered by a link-local monotonic sequence assigned under the link lock. The trace and public I/O counters are expected to replay exactly for the same schedule and the same deterministic operation script.

Revision 0579's focal regression materializes every schedule before using it, authenticates two real TLS peers over the private stream, performs HELLO and NOS1 open, exchanges two evidence operations and committed receipts over one reusable session, performs NOS1 close and TLS close-notify, and repeats the complete run. The two resulting `NVTR0001` artifacts and all exposed counters must be byte-for-byte identical.

The same regression injects timeout, reset, loss, duplication, corruption, and reordering into the first TLS carrier write. None may yield an authenticated application session. It also distinguishes orderly TLS close from raw carrier EOF, which remains `TLS_TRUNCATED_EOF`.

## What this evidence does not establish

The virtual carrier establishes implementation and model evidence for carrier-neutral code paths. It cannot establish electrical behavior, driver behavior, serial line configuration, radio range, interference response, antenna behavior, USB reliability, Bluetooth behavior, power consumption, independent-host scheduling, or physical power-loss behavior.

Those are verification debts, not construction vetoes. They must be recorded honestly while implementation continues.

## Next bounded carrier

The next production-facing carrier should be an explicitly configured POSIX serial/TTY ordered-byte stream. It should reuse `OrderedByteStream`, TLS, identity, HELLO, NOS1, retry, receipt, and custody machinery unchanged. It should add no discovery and confer no identity from a device path. A pseudoterminal fixture can verify termios configuration, ownership, half-close limitations, interruption, bounded reads and writes, reconnect behavior, and protocol preservation before physical serial hardware is available.
