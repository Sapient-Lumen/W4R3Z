# Same-iteration automatic source eligibility — revision 0558

## Purpose

Automatic source delivery has to decide whether the next selected source is permanently impossible before it considers transient route or outbox capacity. Revision 0557 therefore constructed an envelope once in the permanent-block classifier and a second time when preparing `AUTO_ISSUE`.

Revision 0558 preserves that decision order while removing the second construction. A successful permanent-block classification can now produce one private, single-use eligibility object. The same locked worker iteration moves its exact bounded envelope into the existing source-progress preparation. No status call, later worker turn, caller, journal record, checkpoint or replay path can provide or retain this object.

This is an internal computation change. It adds no command, permission, peer message, journal encoding, canonical source-subscription encoding or storage-schema version.

## Exact origin bindings

An eligibility object is produced only after the ordinary classifier has selected and reconstructed the next canonical source envelope. It binds:

- the owning `NodeState` and exact retained predecessor object;
- grant, immutable subscription instance, revision and current structural commitment;
- active accepted configuration event and configuration digest;
- relative delivery position and exact inbound-record position;
- canonical source-record digest, local-authorship account, source operation and raw payload count;
- the complete selected envelope and its evidence-record digest.

Preparation reparses the active configuration normally, verifies all of those bindings against authoritative state, verifies the canonical source record still hashes to its stored digest, and checks the envelope issuer, recipient, scope, correction shape, operation commitment and record digest. It then moves the envelope into preparation and marks the eligibility object unavailable. A second use is rejected.

Revision 0559 shares one [exact-byte-bound strict NST3 parse](PARSED-SOURCE-PROGRESS.md) between preflight and live application. Both passes independently recheck predecessor, source order, local authorship, policy, payload accounting, operation and record digests, outbox absence/capacity, finite automatic grant accounting and active configuration. `AUTO_ACK` still locates and validates the actual durable receipt twice. Eligibility is not a generic “already validated” flag.

## Outcome ordering is unchanged

The worker still evaluates permanent or terminal conditions before transient delivery availability. In particular, it preserves:

1. retired/expired/disabled state and current disclosure/key policy;
2. the actual outstanding delivery and receipt/rejection/cancellation/expiry state;
3. finite record and raw-payload budgets;
4. construction of the next source envelope, including permanent oversize detection;
5. enabled-route availability;
6. current outbox admission/capacity;
7. atomic `AUTO_ISSUE` plus one finite step.

A permanently oversized source therefore commits `AUTO_BLOCK` even when its route is disabled and the outbox is simultaneously full. A valid small source under those same transient conditions consumes no step. Enabling the route while capacity remains exhausted still consumes no step; restoring capacity permits a fresh iteration to construct and issue once.

A candidate is discarded when route selection returns transiently unavailable. Preparation consumes it even if a later outbox-capacity check throws; the whole local iteration then ends without commit, and the next turn must classify and reconstruct from current state. Configuration, predecessor or source changes cannot reuse an earlier object.

## Replay, status and manual commands

Untrusted replay never receives eligibility or command preparation. It parses accepted configuration and reconstructs the selected source from canonical state. Complete checkpoints and lifecycle transitions retain complete independent validation.

Automatic status remains observational and may independently construct a preview to report current eligibility. That preview is never returned as reusable authority. Empty polls do not create a progress preparation or spend allowance.

Manual ordinary `ISSUE` keeps revision 0557’s one-construction preparation path. Manual and automatic `ACK` reconstruct no source and require the exact durable receipt.

## Measured work

The retained verified revision-0557 focused original-source measurement reconstructed two source envelopes for `AUTO_ISSUE`. The revision-0558 native probe uses the actual worker routine on an owned provider state:

| Calling-thread source work | 0557 original `AUTO_ISSUE` | 0558 original `AUTO_ISSUE` | 0558 `AUTO_ACK` |
|---|---:|---:|---:|
| Source records reconstructed | 2 | **1** | 0 |
| Raw source bytes encoded | 74 | **37** | 0 |
| Envelope bytes constructed | 536 | **268** | 0 |
| Eligibility candidates / reuses | not present | **1 / 1** | 0 / 0 |
| Preparation source reconstructions | 1 | **0** | 0 |
| Accepted source-configuration parses | 1 | 1 | 1 |
| Preflight / application preparation uses | 1 / 1 | 1 / 1 | 1 / 1 |
| Actual durable-receipt checks | 0 | 0 | **2** |

A separate successor-lease correction fixture measures one source reconstruction, one indexed parent lookup and hit, zero retained ancestry visits, 20 raw source bytes encoded and a 433-byte selected envelope. The independent replay of its committed `NST3` reconstructs canonically and produces the same logical-state digest.

These counters cover named source-specific work on the calling thread. They exclude transport, other workers, all allocations and copies, unrelated authorization, journal synchronization and whole-program throughput. Moving the envelope avoids a second construction; it does not make delivery free or constant-time.

## Boundary and negative control

The isolated private probe rejects 31 independently changed eligibility or authoritative-state facts, including changed owner/predecessor/configuration/source/order/authorship/envelope accounts, acknowledgment misuse and second use. Valid preparation consumes the object exactly once and changes neither durable bytes nor logical state.

The narrow weakened build removes only the eligibility-to-canonical source-record-digest comparison. Its probe then accepts that one changed binding and fails with:

```text
eligibility boundary accepted: eligibility-source-record-digest
```

The wrapper treats detection of that deliberately failing build as the successful negative-control outcome. The weakened source tree, objects and executable are not distributed.

See [testing](TESTING.md), [source preparation](SOURCE-PREPARATION.md), [automatic delivery](AUTOMATIC-SOURCE-DELIVERY.md), [fresh validation](../validation/VALIDATION.json) and [measurements](../validation/METRICS-SUMMARY.json).
