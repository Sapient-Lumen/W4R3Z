# Exact-domain evidence reads — revision 0507

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Subscribed-source target domains

Recipient import policy is distinct from local read policy. A UID may import without querying bytes; another may read target metadata without raw-envelope or payload access. The target issuer remains the real provider. Imported corrections share the same view domain and mapped source chain. [Subscribed-source views](SUBSCRIBED-SOURCE-VIEWS.md).

## Authority is applied before data selection

Configuration V10 delegates exact local UID / evidence issuer / evidence scope domains. It applies to the existing native `evidence-query` operation on the kernel-authenticated Unix control socket. It does not expose a new remote endpoint or trust an identity supplied in request bytes.

Both layers must permit access: the UID's `local_control` command classes and its `evidence_read` domains. Payload permission requires EVIDENCE_READ and EVIDENCE_PAYLOAD plus a PAYLOAD domain. A PAYLOAD domain also grants metadata. There are no wildcard UIDs, wildcard issuers, prefix scopes, deny ordering, group inference or automatic owner bypasses.

A partial configuration example is:

```text
NATRAV_OVERLAY_CONFIG_V10
runtime_generation=reader-policy-2
# Supply the normal complete identity, paths, listener and service configuration.
local_control=1000,INSPECT,SUBMIT,ACTION,MAINTENANCE,CONFIGURATION,SHUTDOWN
local_control=1001,EVIDENCE_READ,EVIDENCE_PAYLOAD
local_control=1002,EVIDENCE_READ

evidence_read=1001,A,observations/temperature,PAYLOAD
evidence_read=1001,C,observations/temperature,METADATA
evidence_read=1002,C,observations/temperature,METADATA
```

UID 1001 may read A's temperature payloads and C's temperature metadata, but not C's payloads or other scopes. UID 1002 may read only C's temperature metadata. UID 1000 is an administrator, not implicitly an evidence reader. A separately granted administrator can deliberately activate a broader policy; the read boundary does not defend against an authorized configuration administrator or a compromised daemon UID.

ALL permanently means the six historical administrative command classes. It does not grant evidence reads. V9 explicit EVIDENCE_READ/EVIDENCE_PAYLOAD grants retain their original **node-wide** behavior and response V1. Old accepted canonical bytes and configuration digests are not reinterpreted. V10 is a deliberate accepted transition; it has no implicit broad domain. Deliberately rolling back to an accepted V9 policy restores that policy's broad authority.

## Strict rule construction

`evidence_read=UID,ISSUER,SCOPE,METADATA|PAYLOAD` has exactly four fields. IDs and scopes use the same exact bounded syntax as admitted evidence; UIDs are numeric unsigned 32-bit integers. At most 256 domains exist across at most 64 local-control principals. One mode is allowed per UID/issuer/scope; duplicates are rejected, including simultaneous METADATA and PAYLOAD for one domain. Use PAYLOAD once to grant both. Each domain requires the corresponding command classes. Every V10 read-capable UID must have a metadata-capable domain, and every payload-capable UID must have a PAYLOAD domain. Empty policies are valid only without read-capable UIDs.

Sorted rules are canonical accepted configuration content. `config-check` and authorized runtime status expose the complete policy and its digest. Queries expose only the requesting UID's effective read-authority digest, not other principals' rules. The reader digest includes its UID, scoped/broad mode, read and payload command bits, and sorted exact domains. It excludes unrelated administrative bits and owner paths. Python tests independently reproduce the digest.

Activating a read-policy change uses the existing fully validated, durably recorded live configuration transition. The lease covering post-read authorization, selection and response encoding prevents a slow old-policy connection from using revoked domains. It is released before transmission: already authorized bounded response bytes may finish after publication. Local read-policy changes do not themselves alter a remote peer-session contract.

## Query semantics and information boundary

The CLI and strict NEQ1 request wire are unchanged; see [Evidence queries](EVIDENCE-QUERIES.md). Omitted filters mean all domains currently allowed for the requested access mode, not all node evidence. Exact issuer/scope/operation filters further intersect that authority. A payload query selects only PAYLOAD domains, omitting metadata-only domains entirely rather than selectively emitting unrequested metadata rows.

An inaccessible exact operation is indistinguishable at the record-result/error boundary from a nonexistent operation queried with the same options. It returns an empty selection, not a forbidden-operation or payload-range error. Authority is checked before payload length, page sizing, counts, roots or row materialization. The response may echo caller-supplied filters; they are not confirmation that a hidden record exists.

V10 responses use `NATRAV_OVERLAY_EVIDENCE_QUERY_V2`. V1 fields remain except that `sequence` is now a **one-based authorized-selection ordinal**, not the global admission sequence. `sequence_semantics=AUTHORIZED_SELECTION_ORDINAL` makes this explicit. It cannot be used as a durable journal position. Hidden admissions therefore do not leak through number gaps or perturb the selection root. Stable operation IDs, immutable digests, relative admission ordering, payload size, and the actual stored peer/policy authorization account remain attributable.

Current returns all unsuperseded correction-chain heads; history retains originals and corrections. Journal validation already requires a correction and its predecessor to share issuer, recipient and scope. Exact-domain authority therefore admits the entire correction chain or none of it. Current/history links do not cross an inaccessible domain; they remain visible even when a caller's narrower *selection filter* excludes the linked row. Selection filters are not a second access policy.

Metadata contains record hashes, payload lengths, timestamps and authorization history. Those are intentionally disclosed by METADATA grants and can be sensitive, including allowing guesses about low-entropy payloads. This is not a cryptographic concealment promise for content whose digest has been disclosed.

## Ordered derivative indexes and cached roots

The state reconstructs exact-domain history/current rank/select indexes through normal admission and checkpoint replay. The 65,536-record scan ceiling is removed. At most 128 metadata rows are retained per cold-root batch, at most 32 roots are cached, and scoped warm pages seek to their authorized ordinal rather than enumerating preceding pages. Payloads remain in their ordinary record store.

Root cache versions use only matching authorized domains for the requested access mode. Hidden writes and metadata-only domains in a payload request do not change them. Current indexes skip superseded ancestors. Eviction rebuilds the same root; compaction/replay reconstructs ordinary index invariants. See [Indexed pagination](INDEXED-PAGINATION.md) for precise memory/work bounds, cooperative invalidation and measurements.

Cold hashing is still linear in selected metadata. Hashing releases the state mutex between bounded batches; relevant concurrent writes cause EVIDENCE_QUERY_CHANGED with no partial output. The accepted configuration lease remains held through selection/encoding. No snapshot, wait-free publication, timing noninterference or production-throughput guarantee is implied. V9 keeps node-wide authority/digests but also loses the old broad-scan ceiling.

## Scoped selection roots and cursors

The V2 selection root is a SHA-256 chain. Its seed is the ASCII domain `NATRAV_OVERLAY_EVIDENCE_SELECTION_V2`, u16-length node, u8 history flag, u16-length issuer filter, u16-length scope filter, u8 operation-presence and optional 32-byte operation, 32-byte effective reader digest, and u8 payload flag. Integers are big-endian. Each ordered canonical metadata row extends the root with previous root, u32 UTF-8 JSON length, and exact metadata JSON. The new authorized ordinal replaces the global sequence in each row. Payload content remains bound by the immutable record digest. Page limits, cursor tokens and payload slice offsets do not change the selection root; they remain bound by the separate NEQ1 query-specification digest.

A scoped cursor is 184 binary bytes / 368 lowercase hexadecimal characters:

```text
NEC2                          4 bytes
kernel UID                    u32
query specification digest    32 bytes
selected evidence root        32 bytes
accepted configuration digest 32 bytes
effective reader digest       32 bytes
after-selection ordinal       u64
monotonic expiry milliseconds  u64
HMAC-SHA-256 tag               32 bytes
```

The existing separate-purpose process-local random key and HMAC domain `NATRAV_OVERLAY_EVIDENCE_CURSOR_V1` authenticate the whole body, including its version. V9 continues to use NEC1 with no additional policy field. A version/policy mismatch cannot become a fallback. The five-minute monotonic lifetime and strict tag verification remain. A token is neither a read grant nor an encrypted secret.

Changed selected evidence yields EVIDENCE_CURSOR_STALE; a relevant write during cooperative cold construction yields EVIDENCE_QUERY_CHANGED before partial output. Changed UID, query options, mode, read policy or accepted configuration yields EVIDENCE_CURSOR_CONTEXT_MISMATCH. Invalid MAC/version or a previous process's token yields EVIDENCE_CURSOR_INVALID. Expiry yields EVIDENCE_CURSOR_EXPIRED. There is no retained historical snapshot. Hidden writes do not change the visible root or cursor anchor. Compaction in the same process preserves the cursor; restart needs a fresh query. Config changes still invalidate tokens even when they affect unrelated users; no concealment of global configuration activity is promised.

## Administration, persistence and limits

Successful reads remain observational. Class denials use the existing durable local-control account and accepted configuration-event binding. Filtered-out hidden records are not separate per-record denial events, and authorized query execution errors do not create a complete access log. Policy authority survives authenticated storage, compaction, signed encrypted backup, restore and relocation. Relocation rejects attempts to broaden domains. Scoped roots survive relocation because path/configuration digests are not the selection seed; live cursors remain configuration-bound and process-local.

Filesystem reachability remains separate: granting a UID does not change owner-only socket/state permissions. Delegated users should not also receive offline state files or broader INSPECT/CONFIGURATION authority unless those exposures are deliberate. Tests use real UIDs 65534 and 65533 and temporarily expose only disposable test control endpoints.

There is no wildcard policy, conditional consent, rate-window limit, durable successful-read receipt log, remote query protocol, subscription, persistent snapshot, physical-host isolation or evidence-truth claim. Existing keyed-state freshness remains NOT_ESTABLISHED without a separately protected expectation.

Primary API references checked October 4, 2026: [Linux unix(7), SO_PEERCRED](https://man7.org/linux/man-pages/man7/unix.7.html), [OpenSSL HMAC](https://docs.openssl.org/3.0/man7/EVP_MAC-HMAC/), [CRYPTO_memcmp](https://docs.openssl.org/3.3/man3/CRYPTO_memcmp/). These describe operating-system/primitive behavior, not an independent audit of this application.

## Incremental consumption

For original/correction admissions added after a continuation boundary, revision 0508 provides [evidence-feed](EVIDENCE-FEED.md). It uses exact V10 read domains and the same derived history indexes but deliberately does not construct a changing selection root. This does not change existing query or pagination semantics.
