# Durable recipient result reviews — revision 0547

A result review is an explicit, immutable recipient account of a source-derived conclusion about one exact completed candidate set. It is not an execution receipt, evidence admission, acknowledgment of the original action, remote truth, newest-state proof, or authority for another effect. The product uses the existing strict NAC1 validator; it does not trust a caller-supplied classification or a discovery cursor.

## Commands and authority

First obtain the request binding, candidate count/root, and accepted configuration from `action-result-discover`. The discovery page need not finish before requesting a review: the review command independently validates the **entire selected set** within its own bounds. No incomplete discovery counters are accepted as evidence.

```sh
./node/bin/natrav-overlay action-result-discover \
  --control state-a/control.sock --request ACTION_HEX64 \
  --provider B --scope results/counter

./node/bin/natrav-overlay action-result-review \
  --control state-a/control.sock --request ACTION_HEX64 \
  --provider B --scope results/counter \
  --candidate-count COUNT --candidate-root CANDIDATE_ROOT_HEX64 \
  --request-binding REQUEST_BINDING_HEX64 \
  --expected-configuration CONFIGURATION_HEX64 \
  --reason 'record the exact received report set'

./node/bin/natrav-overlay action-result-review-status \
  --control state-a/control.sock --review REVIEW_HEX64
```

The creator needs current kernel-authenticated INSPECT, MAINTENANCE, EVIDENCE_READ, and EVIDENCE_PAYLOAD, including payload authority for the exact provider and scope. Status needs current INSPECT and the same read domain, but not MAINTENANCE. Records are owner-bound: another UID receives RESULT_REVIEW_NOT_FOUND even when it holds administrative inspection. Existing ALL includes MAINTENANCE/INSPECT, not the evidence-read classes. A reader does not silently acquire permission to write reviews.

The generation-stable control guard checks authority after complete request decoding and holds accepted configuration protection through effect. Candidate, original receipt/key, and configuration changes between inspection and commit produce typed conflicts. Creation is prohibited during quiesce and drain; review status remains observational while the endpoint lives. Current permission is checked even for an exact retry. No command impersonates a connected principal.

## Selected facts, complete conclusions

RRQ1 selects one original request, expected provider/scope, candidate count/root, original-request validation binding, accepted configuration, and a 1–256 printable-byte reason. Original key and optional admission receipt facts use exactly the discovery binding. The node does not acknowledge the original request because a result exists.

Creation re-evaluates every selected candidate. The stored rows contain outer operation identity and record digest plus either a consistent classification or the validator's exact rejection code. The conclusion is derived from those rows: NO_CANDIDATES, NO_CONSISTENT_REPORTS, UNIQUE_AUTHENTICATED_REPORT, or CONFLICTING_REPORTS. Unique operation identity is returned only for one consistent report after complete validation. Conflicts have no chosen winner.

Coverage is the same identifiable, retained peer-authorized NAC1 provider/scope/request domain as [discovery](RESULT-DISCOVERY.md). Unknown formats, insufficient prefixes and other scopes are outside that association. The canonical report's policy hashes remain provider claims. Local incoming admission, original request admission, reported effect, and this recipient review are separate accounts.

One set may contain at most **128 candidates**, including invalid candidates, and at most **32 distinct historical provider configurations**. The review stores classifications, not copies of report payloads. Larger sets still support paginated discovery, but this bounded review command refuses them; it never persists a partial uniqueness claim. Validation runs under the state mutex. Preflight checks the configured control deadline; synchronized append and its semantic application are not preempted mid-commit. A slow commit can outlive the response deadline, so absence of a reply is not absence of a review. Exact retry resolves that ambiguity. There is no resumable durable review builder yet.

## Identity and retries

A review ID is SHA-256 of `NATRAV_OVERLAY_RESULT_REVIEW_ID_V1`, a zero delimiter, BE32 kernel UID, and canonical RRQ1 bytes. The reason is part of the explicit decision. PID and time are provenance, not retry identity.

One new decision returns REVIEWED. An exact repeat by the same currently permitted UID returns ALREADY_REVIEWED with the original record digest, even when later evidence has made its conclusion historical. Changing the reason or selected facts requests a different review, subject to current conditions and capacity. Old exact retry never performs a new evaluation. Identical concurrent calls have one committing winner.

The registry has **128 records globally and 16 per UID**, with no deletion, automatic renewal or slot reuse. A new reviewed selection consumes a new slot. Exact retries work at capacity. The tests exercise the per-UID limit and candidate limit; the global maximum is a declared implementation cap, not a claim of a 128-owner deployment test.

## One commit and strict replay

Journal kind **38** carries **NRR1**; optional checkpoint extension **NRV1** retains the registry. A record is at most 32,768 bytes. State without reviews retains its former logical encoding. Earlier binaries reject the unfamiliar record/extension rather than drop the account. No configuration, peer protocol or storage schema number changes.

The synchronized record binds canonical selection, actual UID/GID/PID, time, accepted configuration event, original generation/SPKI and optional receipt, source inbound cutoff, immutable mutation-prefix commitment, original transition-prefix length and per-candidate classifications. The original source and report evidence are not rewritten.

Journal replay requires the exact current observation at that transition. Checkpoint loading instead reconstructs its retained historical prefixes. Both recompute classifications from original evidence and historical accepted provider policy; both require exact equality with saved rows. Checkpoint validation reconstructs the selected historical key from the retained delivery transition prefix. A saved original receipt must match the actual retained receipt and its runtime mutation commitment. A reviewed absence remains absent only when the receipt's first retained mutation falls after the recorded prefix. Unattributed legacy receipts without that mutation witness are not eligible for this durable review; discovery remains available.

Preflight and semantic application each perform a bounded classification pass. Thus a new commit can validate up to 256 candidate occurrences and parse up to 32 distinct historical configurations **per pass**, rather than claiming that the whole commit performs only one pass. Loading up to 128 retained reviews repeats bounded validation for each and can be expensive. Ordinary current-status comparison does not reclassify the reports.

Incomplete authenticated appends continue to require explicit [audit/recovery](AUTHENTICATED-RECOVERY.md). The kill tests bracket synchronization; they do not prove physical power-loss behavior for every storage stack. A lost command response remains ambiguous until exact retry or state reconstruction.

## Historical status is explicit

The response retains reviewed conclusion, candidate rows/root, request binding, original key/receipt facts, exact actor/configuration, and reason length/digest. Reason text is stored privately in the journal but redacted from status. It separately compares current candidate facts, request receipt/key facts, and accepted configuration. All matching yields CURRENT_SELECTION; any mismatch yields HISTORICAL. Neither status implies independent execution or freshness.

New candidates never rewrite an old review. A late real receipt may make a previously self-consistent alternative invalid on a **new** review; the preceding conclusion stays attributable. Revocation can remove the owner's ability to read either account. Relocation changes configuration while preserving the review and source bindings, so configuration mismatch can make a review historical even when selected evidence is unchanged.

The reply includes at most 128 bounded rows and is checked against 60,000 bytes including a conservative principal allowance. Revision 0548 adds [owner-scoped review history](REVIEW-HISTORY.md) to locate IDs through an exact request/provider/scope. That API lists stored summaries only; current comparison and complete candidate rows remain this exact-status endpoint. Status performs exact index access plus bounded metadata rendering, not full-state snapshot construction. Receipt-ordinal witnesses form a derived map proportional to retained receipt operations; they are rebuilt from existing mutation bindings rather than persisted independently.

## Testing and security limits

[Validation](../validation/VALIDATION.json) labels every newly completed selected matrix. [Attempts](../validation/ATTEMPTS.md) retains actual failed or interrupted invocations. The new cases cover concurrent exact creation, empty and mixed classifications, 75- and 128-candidate sets, excessive sets, late receipts, real UIDs and live revocation, finite owner history, source-derived journal/checkpoint corruption, real SIGKILL, keyed audit, encrypted signed restore, removal of obsolete identity paths, relocation and continued request/result exchanges.

The negative control removes only per-candidate source-derived classification equality. A forged history that swaps the good and bad classification must be rejected by the normal executable and detected when the check is removed. No weakened binary is delivered.

Keyed state integrity, recipient review, signer identity and backup confidentiality remain distinct. A complete valid older snapshot can restore earlier reviews and availability; there is no external freshness anchor or split-brain protection. Controlled tests run on one Linux kernel. Nothing here changes evidence truth, creates external action authority, or supplies a receipt for remote execution.
