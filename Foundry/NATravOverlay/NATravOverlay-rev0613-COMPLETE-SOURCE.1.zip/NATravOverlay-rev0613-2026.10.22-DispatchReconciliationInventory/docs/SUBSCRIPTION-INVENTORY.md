# Provider source-subscription inventory

Revision 0551 adds `source-subscription-inventory`, an observational, kernel-manager-scoped view of existing provider subscriptions. It creates no source, subscription, lease, disclosure, receipt, grant, cancellation, succession or reconciliation. Runtime implementation is C++20.

## Authority and historical visibility

V15 or newer and the actual connected UID's current explicit `SOURCE_DISCLOSE` class are required after request decoding. The accepted configuration is protected through selection and response construction. Neither `ALL`, `INSPECT`, source authorship nor evidence-read permission alone confers inventory access. There is no arbitrary manager-UID parameter.

Every row belongs to the manager UID stored in the accepted subscription grant. Historical subscriptions remain visible to that manager when a particular disclosure rule is removed, or its subscriber generation is revoked, provided the current command class is still granted. This is deliberately administrative metadata access, not present authority to issue another source. `policy_current` compares the exact retained grant with the active rule. Key state and exact pin matching are separate fields. A new active generation does not rewrite an old subscription's binding.

The existing configuration parser still requires a SOURCE_DISCLOSE principal to have at least one current grant. To inspect a removed historical grant, that principal can retain a different accepted grant. No parser exception or implicit stopping authority was added.

Source read authority is not required or conferred. Managers already authorized to administer the retained grant can see its author UID, source scope, subscriber, operation commitments, counters and bounded actor provenance. They receive no payloads, free-text reasons, private identity paths, full delivery lists or full automatic-grant histories. Another manager's rows do not affect visible counts or ordinals; its creations and transitions under an unchanged configuration do not change the selected root. Timing and shared-resource confidentiality are not claimed.

## Command

```sh
./node/bin/natrav-overlay source-subscription-inventory \
  --control state-a/control.sock --limit 8 --max-bytes 32768
```

All selectors are exact and conjunctive:

| Option | Values / meaning |
|---|---|
| `--grant` | Exact retained grant ID, not an uninstantiated configuration rule |
| `--instance` | Exact immutable subscription instance |
| `--peer` | Exact subscriber node |
| `--scope` | Exact registered source scope |
| `--author-uid` | Exact registered source-author UID; this is not the manager selector |
| `--lifecycle` | `all`, `active`, `retired` |
| `--lease` | `all`, `unleased`, `open`, `withdrawn`, `expired`; stored lease state only |
| `--schedule` | `all`, `none`, `enabled`, `paused`, `blocked`, `exhausted` |
| `--outcome` | `all`, `none`, `pending`, `acked`, `rejected`, `cancelled`, `expired`; latest actual outbox operation |

A foreign instance and a nonexistent instance produce the same empty owned selection. A leased subscription retired manually can still have an `OPEN` stored lease account: lifecycle and lease termination are different fields. Likewise a terminal subscription's latest grant can retain its preceding `PAUSED` or `EXHAUSTED` state.

Each page permits 1–16 rows and 2,048–60,000 complete annotated JSON bytes. It never emits a partial row or skips a nonfitting row. A nonfitting first row returns `SUBSCRIPTION_INVENTORY_PAGE_TOO_SMALL`. A later nonfitting row ends a nonempty page with usable continuation. The ordinary outer framing is outside the JSON-byte count.

## Coherence and selection

The response is `NATRAV_OVERLAY_SUBSCRIPTION_INVENTORY_V1`. Subscription, latest grant, succession reference, and latest outbox state are observed under one state mutex. Records are sorted by grant ID and assigned one-based positions within the owned filtered selection, not global admission ordinals.

The first page returns `selection_digest`, `selected_total`, `next_offset`, and `has_more`. Continuation repeats filters and passes `--offset` and `--selection`. Page size and response budget may change. The digest binds node ID, actual UID, accepted configuration digest, all filters and all selected summary rows. New selected subscriptions, issues, acknowledgments, receipts, retries, committed lease termination, reconciliation, adoption, automatic grants, retirement, or configuration changes invalidate the old selection with `SUBSCRIPTION_INVENTORY_SELECTION_MISMATCH`.

A current but filtered-out subscription may change without invalidating an unrelated exact selection. A newly accepted successor is reflected in its predecessor's `adopted_by` summary even though the predecessor's own revision was not rewritten. Same-state compaction and restart can preserve the selection. Relocation changes the accepted configuration and requires a fresh selection while preserving historical subscription metadata.

This is current-content comparison, not a retained snapshot, permission token, expected-state condition for mutation, or freshness authority. Changes limited to omitted historical details need not alter the summary. A valid old state and accepted configuration can match a previously selected digest. Mutations require their own ordinary exact selectors.

## Lease time is not silently mutated

`lease_state` is derived only from the persisted lease and its persisted termination. `observed_unix_ms` is a separate top-level clock observation, excluded from the selection digest. Compare it with `lease_expires_unix_ms` to see elapsed time. Merely reaching the deadline does not cause this read to append EXPIRED, cancel an outbox operation, block a grant, or advance a revision.

`OPEN` is not a statement of current eligibility. Likewise `ENABLED` is the stored automatic-grant state, not proof that its worker is running or currently permitted to select a source. Status does not call the mutating lease encounter path or the source-selection/eligibility path.

## Receipts, budgets and lineage

The latest delivery contains source and recipient operation identities, record digest, original source payload length, issue and acknowledgment provenance, actual outbox outcome, current generation/SPKI policy, attempt account, and a receipt only when the outbox retains one.

`acknowledged_by_subscription` and the subscription frontier are independent of that receipt. A late receipt after withdrawal can leave `outbound_status: ACKED` alongside `acknowledged: 0`. Reading does not reconcile it. Explicit reconciliation remains required; the inventory then shows its retained receipt/terminal commitments without rewriting withdrawal. Succession shows the inherited frontier and mapping digest; its own spent record and byte budgets still begin at zero under a separately accepted grant. The returned mapping commitment is retained provenance, not a freshly recomputed full mapping on every page.

Remaining disclosure counts are maximum minus issued/source-payload use, not a fresh source query. Failed delivery, receipt, cancellation, retirement, and inspection do not refund disclosure budgets. A source result envelope remains different from recipient-local authorship.

Remote admission includes the actual authenticated peer, generation, SPKI, request ID and accepted configuration event. `creation_manager_pid` is null for remote admission: no remote principal is presented as a local Unix client. Locally created or succeeded subscriptions retain their actual creation manager PID. Execution PID fields retain their recorded provenance; they do not claim the source author's process identity. Zero last-step event/time denotes no recorded automatic step; default executor UID/PID zeroes in that case are not a claim that UID 0 executed work.

## Work and limits

The implementation scans only grant identities and manager UIDs in the existing registry, whose total cap is 64. It builds at most 16 manager-owned summaries. No other manager's source record or outbox head is dereferenced. Hidden scan counts are not exposed. Within owned summaries it uses exact outbox-map lookup and reads only the last delivery and last automatic grant. Succession reverse references are assembled from at most 16 owned records; complete source mappings are not reconstructed.

No complete subscription encoder, application snapshot, full source payload, eligibility computation, logical-state hash or full grant/delivery history is used. Work counters describe only the locked page method. Metadata allocation, bounded configuration processing, lock waits, startup replay, and transport remain real costs. Indexing is not allocation-free or timing-confidential.

The read is allowed during quiescence and actual draining while the endpoint exists. Successful calls, including empty polls, append no journal or successful audit event. Permission failures retain the existing denial-audit behavior. There is no registry reclamation, source catch-up scan, remote inventory endpoint, schedule reset or background resumption in this command.

## Selection encoding

Local control kind 38 carries `SIN1`: seven length-prefixed texts (lifecycle, lease, schedule, outcome, grant, recipient, scope), optional big-endian u32 author UID, optional 32-byte instance, u32 offset/limit/maximum JSON bytes, and optional 32-byte selection. Optional flags are exactly 0 or 1 and EOF is mandatory.

The selection seed is SHA-256 over `NATRAV_OVERLAY_SUBSCRIPTION_INVENTORY_SELECTION_V1`, a zero byte, text16 node, u32 manager UID, configuration digest, the seven texts, optional UID/instance, and u32 selected count. Every row updates it using `NATRAV_OVERLAY_SUBSCRIPTION_INVENTORY_ROW_V1`, a zero byte, previous root, u32 row length and exact UTF-8 row JSON. Page bounds and clock observation are excluded. Independent tests reconstruct this encoding.

## Validation and continuation

[Current validation](../validation/VALIDATION.json) records completed and selected profiles; [attempts](../validation/ATTEMPTS.md) preserves failures. The test runner is `node/tests/run_subscription_inventory.py`. Scope includes real peer delivery and remote actors, receipt/frontier separation, elapsed lease non-mutation, real UID isolation, removed rules and revoked keys, reconciliation and succession, full 64-instance/four-manager capacity, automatic progress, compaction, keyed audit, encrypted restore/relocation and actual draining. [Next construction](BUILD-PLAN.md) remains native product work.
