# Deterministic UDP datagram adversary

## Scope

Revision 0585 adds a fixture-owned user-space datagram adversary around the
configured numeric UDP carrier. The adversary is not linked into
`natrav-overlay`, is not accepted by `TransportLocator`, and cannot be selected
by a production configuration.

It exists to exercise two complete persistent node processes through the real
stack:

```text
persistent scheduler and UDP route
→ bounded user-space datagram adversary
→ configured UDP listener
→ finite packet service
→ PacketLinkOrderedByteStream
→ OpenSSL BIO over ByteChannel
→ TLS 1.3 mutual authentication
→ HELLO
→ NOS1
→ application operation and durable receipt
```

The relay never interprets TLS, HELLO, NOS1, application, receipt, journal, or
authorization data. It handles opaque UDP datagrams and records bounded
evidence about the faults it deliberately applied.

## Explicit topology

The fixture owns two independent point-to-point relay paths:

- `ab`, used by A's outbound route and B's listener; and
- `ba`, used by B's outbound route and A's listener.

Each path has two bound relay sockets and two exact expected node source
endpoints. A datagram from any other source is rejected and cannot teach the
fixture or product a new endpoint. The ordinary connected UDP sockets retain
their own fixed-remote filtering. Neither mechanism is authentication; pinned
TLS identity remains decisive.

## Canonical schedule

The schedule format is `NATRAV_UDP_ADVERSARY_SCHEDULE_V1`. Its canonical JSON
encoding uses sorted keys, no insignificant whitespace, one trailing newline,
and exact fields for:

- schedule name;
- default action (`PASS` or `DROP`);
- maximum datagram bytes;
- maximum pending events;
- maximum trace records; and
- an ordered finite rule list.

A rule binds one relay path, overlay direction, one-based ingress ordinal,
action, and bounded delay. Supported explicit actions are:

- `PASS`;
- `DROP`;
- `DUPLICATE`;
- `CORRUPT`;
- `DELAY`; and
- `REORDER`.

Rules must be canonical and unique by path, direction, and ordinal. Malformed,
unknown, noncanonical, oversized, duplicated, or unsorted schedules fail
closed.

## Bounded execution

The adversary has no unbounded work queue. It enforces:

- the declared maximum complete datagram size;
- the declared pending-event count;
- one reorder hold per path and direction;
- a finite rule count;
- finite delay values; and
- the declared trace-record count.

Exhausting the datagram, pending-event, or trace bound stops the fixture with an
explicit error. The focal suite exercises those negative controls.

`REORDER` holds one datagram until the next datagram in the same direction is
scheduled, then emits the newer datagram first. A finite release deadline
prevents a held datagram from becoming an unbounded dependency.

## Canonical trace

The trace format is `NATRAV_UDP_ADVERSARY_TRACE_V1`. It records finite phase,
ingress, and emission events with monotonically increasing sequence numbers.
Ingress records bind path, direction, ordinal, selected action, byte count, and
input SHA-256. Emission records bind the resulting datagram digest, byte count,
copy number, and the originating ordinal.

The trace is evidence about the fixture's actions. It is not authenticated peer
evidence and it is not persisted product state.

## Persistent lifecycle exercised

The revision-0585 suite launches two ordinary persistent nodes with both UDP
listeners and outbound routes. It verifies:

- canonical configuration acceptance;
- scheduler dialing through the relay;
- TLS 1.3 identity and HELLO binding under datagram adversity;
- application admission and exact durable receipt binding;
- duplicate suppression under duplicated datagrams;
- listener lease retirement and a later reconnect;
- bidirectional route use;
- rejection of a captured datagram injected from an unconfigured source;
- an all-drop phase producing typed route failure without falsely consuming an
  application attempt before authentication;
- preservation of the pending obligation across orderly shutdown;
- restart, explicit wake, eventual delivery, and receipt;
- reconstruction of acknowledged state without resend; and
- a fresh post-restart session and admission.

The distinction between route failure and application attempt is intentional.
A TLS handshake that never authenticates the peer can fail repeatedly while
the durable application attempt count remains zero. The obligation is still
retained and retried after reachability returns.

## Replay boundary

For the same schedule and equal-length authenticated work, revision 0585
requires the same scheduled path, direction, ordinal, action, and packet-size
structure. It also requires the same authorization class and successful
receipt outcome.

It does not require the packet SHA-256 values from independent TLS handshakes to
match. Fresh cryptographic randomness is expected and is retained.

## Negative controls

Revision 0585 adds no:

- product relay or forwarding mode;
- configured adversary locator;
- DNS, broadcast, multicast, discovery, endpoint learning, or migration;
- carrier-derived peer identity;
- second executable;
- peer-wire, local-control, journal, checkpoint, backup, custody,
  authorization, or storage-schema change.

## Assurance boundary

The fixture uses local UDP sockets and local processes. It can establish
bounded fault scheduling and persistent lifecycle behavior in that model. It
cannot establish independent-host scheduling, NAT or firewall behavior,
wireless or radio behavior, driver quality, electrical correctness, range,
interference, power consumption, or physical power-loss behavior.
