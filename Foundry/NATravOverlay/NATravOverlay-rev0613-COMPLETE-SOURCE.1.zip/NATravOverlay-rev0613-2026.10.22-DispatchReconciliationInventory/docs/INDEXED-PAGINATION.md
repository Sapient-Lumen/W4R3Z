# Indexed evidence pagination — revision 0507

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Product boundary

The persistent C++ `evidence-query` command now supports authorized selections larger than 65,536 records without collecting the whole selection or hashing it again for every page. Exact V10 UID/issuer/scope and payload authority, V9 node-wide compatibility, original selection digests, NEQ1 requests, response V1/V2 and NEC1/NEC2 cursors retain their meaning. The response adds bounded `query_work` diagnostics. No new configuration, journal, peer-wire or cursor version is required.

The 65,536-record broad-query ceiling is removed, not raised. Existing journal capacity, metadata/payload sizes, configured control deadlines, 128-row page limit, 60,000-byte complete JSON limit, 16,384-byte payload slice limit and 256-domain policy limit still apply. A root that cannot be completed within a configured deadline is not an unlimited computation promise. Query construction reserves up to 50 ms (at most one quarter of the control budget) for a typed EVIDENCE_QUERY_DEADLINE response rather than deliberately spending the entire budget before error transmission. Transport scheduling can still fail independently. Timed-out partial roots are not cached.

## Reconstructed ordered indexes

Ordinary admission and checkpoint replay update one admission-order index for the node and one for each exact issuer/scope. Each contains an ordered vector of record indices and a Fenwick tree of current-head bits. A correction appends its own position and clears its predecessor's live bit; unrelated heads remain live. Parent membership and active status are checked. Current rank/select skips superseded history in logarithmic index operations instead of walking an entire correction chain. History remains in original relative admission order.

The index contains no payload copies and is never persisted as an independent authority. Application replay still validates every record and correction. Memory is proportional to all retained admissions, not just a requested page: the global and domain indexes each retain two geometrically grown machine-word arrays. The focused native test measures 2,097,152 allocated array bytes for one 100,000-admission index; an actual node also has its domain indexes and ordinary record store. This number is not total process memory or a constant-space storage claim.

For V10, a heap merges at most 256 granted, filter-compatible domain indexes. Payload mode excludes metadata-only domains before selecting indexes. A continuation ordinal is located using rank/select across these domains, without rewalking prior pages and without putting a global admission offset into a cursor. Exact operation lookup continues to authorize before range checks and materialization. V9 unfiltered reads use the global index; legacy filtered reads may still skip nonmatching records in bounded batches.

## Bounded root cache

A state owner keeps at most **32 fixed-size root-cache entries**. Each stores a key, a selected-domain version, the complete root, selected count and LRU use stamp. The target Linux x86-64 build allocates 2,816 bytes for this entry array; vector bookkeeping and temporary query memory are additional. There are no cached payloads, record forests, snapshots, per-cursor maps or growing query-key strings.

The key binds the selection seed and effective reader-authority digest. Page size and slice offsets need not create another root: those remain bound by the ordinary query-specification digest and cursor. Every request independently checks current authority under the accepted configuration lease. Cache presence is not a grant.

Invalidation uses the sum of append-only history sizes in the authorized domains compatible with the requested filter and access mode. A correction mutates predecessor metadata only in the same domain and necessarily appends a child, so it also changes this version. Hidden admissions cannot change the version. Exact-operation selections depend only on that eligible operation and its correction child, not other domain activity. Version checks are made under the state mutex before cache use and after each cooperative cold-root batch.

An LRU eviction drops only computation. The next request streams and verifies the same root again. An otherwise valid cursor remains usable after eviction or same-process compaction. Restart reconstructs indexes, discards the cache and invalidates process-local cursors as before. Accepted policy changes still invalidate cursors through their configuration binding.

## Cold roots cooperate with writers

On a miss, the node collects at most **128 bounded metadata rows** at a time, hashes the batch, then proceeds to the next batch. No full eligible-index vector is constructed. Between nonfinal batches, hashing occurs outside the state mutex. After reacquiring it the node checks that the relevant domain version is unchanged. Small selections retain the original single-lock behavior.

If selected-domain evidence changed while the mutex was released, the request returns `EVIDENCE_QUERY_CHANGED` without rows or a partial root. The caller must restart the query; there is no hidden retry loop or alleged retained snapshot. Hidden writes can proceed without invalidating a scoped root. A selected change completed before the request is detected through the rebuilt root and existing `EVIDENCE_CURSOR_STALE` behavior.

The accepted configuration lease remains held during query construction. A writer can interleave at a metadata batch boundary, but configuration activation may still wait for the bounded query to finish. This is not wait-free publication. Cold construction remains O(number of selected metadata rows), and sustained visible writes can prevent completion. Cache eviction can cause that cost again. Warm pages do not pay it.

A warm V10 page normally visits at most its requested row count plus one lookahead, up to 129 index entries, while root hashing is zero. Rank and domain lookup work are additional and are not counted as visited records. Payload-range and complete JSON bounds are checked exactly as before. Legacy filters can require more skipped-record work.

## Query-local observability

`query_work` reports `root_cache_hit`, `root_records_hashed`, `index_records_visited`, `root_batches`, `maximum_batch_records` (128), and `maximum_root_cache_entries` (32). It does not expose global cache occupancy, other principals' domains, hidden counts, process memory or internal global offsets. These are algorithmic-work counters, not CPU instructions or network-byte measurements. Shared-cache eviction and timing remain resource side channels; no timing noninterference is claimed.

The optional `NATRAV_OVERLAY_TEST_QUERY_AFTER_BATCH_MS` laboratory hook sleeps once after a cold batch releases the mutex (1..2000 ms) and emits an explicit marker. It changes scheduling only, never policy, authentication or data. It is unset during ordinary operation and performance measurement. The concurrent test uses it to prove real peer admission while hashing is outside the lock.

## Evidence and limits

The five new integrated cases cover both views above the removed ceiling, independent complete enumeration/digest reconstruction, cache eviction/rebuild, exact hidden/payload isolation, visible correction invalidation, real concurrent C++ peer admissions, many superseded records, live compaction, checkpoint replay and explicit V9 compatibility. Existing scoped-read suites still cover real UIDs, live revocation, authenticated state and signed encrypted restore/relocation.

The large fixture has 65,837 independently encoded legacy records: 65,580 authorized historical records, 65,560 authorized current heads, and 257 hidden records. Each view is fully enumerated in 513 bounded pages and checked against its original record/ancestry reference. This is not a network-node count. The declared fixture uses 30-second startup and 20-second daemon control bounds; small inherited tests keep their existing bounds. The predecessor revision retains the measured cold/warm timings and Linux memory observations. They are one-container synthetic measurements, not production throughput or a controlled comparison against the old executable; the current compact validation replaces rather than duplicates that historical evidence.

The native index/cache differential test applies 100,000 admissions including corrections and compares rank, select, counts and bounded eviction against independent vector references. Its error adapter is test-local; integrated tests use the full daemon. A negative-control build bypasses only the cached-version comparison and must fail when a correction incorrectly leaves an old cursor usable.

No full-text search, remote query, retained snapshot, durable incremental feed, complete successful-read receipt log, offline-file concealment, host-compromise protection or independent physical failure-domain guarantee is added. Freshness remains NOT_ESTABLISHED without a protected expectation. See [Status](STATUS.md), [Testing](TESTING.md) and [Scoped reads](SCOPED-READS.md).

## Incremental consumption

For original/correction admissions added after a continuation boundary, revision 0508 provides [evidence-feed](EVIDENCE-FEED.md). It uses exact V10 read domains and the same derived history indexes but deliberately does not construct a changing selection root. This does not change existing query or pagination semantics.
