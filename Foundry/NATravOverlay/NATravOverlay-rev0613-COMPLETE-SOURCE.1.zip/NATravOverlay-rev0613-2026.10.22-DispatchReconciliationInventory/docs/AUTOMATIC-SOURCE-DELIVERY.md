# Automatic source delivery — revision 0524

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.


**Revision 0558 implementation note:** permanent oversize classification still precedes transient route/capacity availability. A successful classification now yields a private [single-use same-iteration envelope](AUTOMATIC-SOURCE-ELIGIBILITY.md) that ordinary `AUTO_ISSUE` preparation consumes, removing duplicate construction without changing allowance, receipt or blocking semantics.

**Revision 0525 addition:** [explicit terminal receipt reconciliation](TERMINAL-RECONCILIATION.md) can adopt an exact stored late receipt without altering the original withdrawal/expiry or scheduling allowance. It uses local `NSR4` and reconciled `NSS6` state in existing journal kind 32; it adds no peer request or automatic authority. Ordinary unreconciled state and old format semantics remain unchanged.


## Implemented boundary

One provider-side C++ worker can fairly advance explicitly enabled finite source subscriptions. It emits the same `NSE1` source records and uses the same durable outbox, routes, TLS, quotas, retries, rejection semantics, and receipts as manual stepping.

The provider manager controls:

```text
source-subscription-auto-enable
source-subscription-auto-pause
source-subscription-auto-status
```

The remote subscriber has no corresponding automation authority.

## Separate finite grant

Enable binds the exact subscription instance/revision, manager UID, accepted disclosure rule, subscriber generation, prior schedule revision, grant generation, finite successful-step allowance, minimum interval, actor, reason, and time.

Accepted bounds remain 1–10,000 successful steps, 10–60,000 ms process-local interval, and 32 retained automatic grants. Source record/byte budgets remain separate.

A successful automatic `ISSUE` or receipt-gated `ACK` and its spent allowance share one synchronized source-subscription transition. Caught-up, pending, route-unavailable, queue-limited, quiesced, and draining observations consume no step.

## Fair worker and policy recheck

One worker rotates through the bounded registry and performs at most one semantic transition per subscription turn. Network delivery remains in the ordinary peer scheduler.

Current manager `SOURCE_DISCLOSE` authority, exact grant, subscriber key policy, subscription lifecycle, lease state, budgets, outbox outcome, and service lifecycle are checked before each step.

Temporary route or quota pressure waits. Rejection, cancellation, delivery expiry, policy/key loss, source-budget exhaustion, oversized envelopes, local retirement, remote withdrawal, or lease expiry stop the grant with an inspectable durable reason.

## V16 lease interaction

For leased subscriptions, the worker refuses to select a source after the stored expiry. Encountering expiry commits terminal `EXPIRED` subscription state and ends an enabled automatic grant in the same semantic transition.

Authenticated remote withdrawal likewise ends the grant atomically. Restoring a removed policy does not restart it. A terminal subscription cannot be re-enabled or manually stepped.

A provider-selected `RETAIN` policy may leave the current outbox delivery active after lease termination. A `CANCEL` policy may cancel only that exact pending operation in the same transaction. The worker never fabricates acknowledgment.

## Limits

The interval is process-local pacing, not durable cron or a distributed lease clock. Automation does not establish exactly-once external effects, truth, freshness, recall, or split-brain prevention. A valid older backup can restore older progress and grant usage.

## Successor scheduling (0524)

A newly accepted successor inherits acknowledged source position, not any automatic grant. A provider must explicitly enable a new finite schedule. Selection adds the inherited prefix; source budgets and automatic-step counts remain local to the new lease. Current-policy and receipt checks remain required. See [lease succession](LEASE-SUCCESSION.md).
