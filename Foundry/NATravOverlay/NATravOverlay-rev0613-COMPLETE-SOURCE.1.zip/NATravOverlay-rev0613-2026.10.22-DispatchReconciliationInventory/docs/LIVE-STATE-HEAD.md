# Live authenticated-head observation — revision 0565

## Contract

`state-head --control PATH` samples the running node's exact committed authenticated-head account through its existing kernel-authenticated local control plane. It requires the actual connected UID's **current INSPECT permission**. The immutable accepted-configuration lease is retained from post-decode authorization through response construction; a single state mutex covers node identity, authentication generation/key, epoch, root, record count, physical journal-byte account, and the opening-expectation comparison. It does not copy a full state snapshot or traverse evidence, authentication histories, recovery reasons, or source payloads.

The response is an observation, not an authentication key, permission, recovery selection, mutation precondition, latest-head proof, or managed anchor. Successful reads append no journal or successful audit event and do not alter logical state. Ordinary in-memory control counters still advance. Denied or malformed requests retain the existing bounded denial-audit behavior and can therefore advance the head.

The command reads the process's validated committed account; it **does not reread or reauthenticate the disk**. Startup authenticated and semantically replayed the input, and subsequent accepted operations used normal durable publication and semantic application. A host actor bypassing the state lock or modifying files behind the running process is outside this observation's guarantee. An offline complete audit remains the disk-verification workflow.

## Request and bound

```sh
./node/bin/natrav-overlay state-head --control state-a/control.sock
```

Only the existing transport bounds (`--deadline-ms`, `--read-quantum`, `--write-quantum`, `--receive-limit`) are optional. There is no key, state-directory, node, UID, selector, logical-digest, or user-selected response-limit parameter. The caller need not possess the daemon's state-authentication key.

The request is exactly the existing `NOC1` magic followed by one byte, kind **41**, with no body. Truncated, extended, concatenated, and wrong-magic requests are rejected by the normal strict decoder. The existing NOR1 response framing is unchanged. Complete successful JSON, including normal principal/request annotations, is capped at **4,096 bytes**. An unexpectedly oversized result fails `STATE_HEAD_RESPONSE_LIMIT`, rather than emitting a partial head. This is a size bound, not a wait-free or latency guarantee: the read can wait behind a state mutation or compaction under existing I/O deadlines.

## Response accounts

`NATRAV_OVERLAY_LIVE_STATE_HEAD_V1` contains only fixed metadata and the ordinary request/principal annotations:

| Field | Meaning |
|---|---|
| `node`, `mode`, `journal_bytes` | Node identity, keyed/unkeyed mode, and the coherent committed physical-byte account. |
| `authentication` | Exact generation, key ID, epoch, root, and record count; null for unkeyed state. No secret or history is returned. |
| `state_head` | Existing `NATRAV_OVERLAY_STATE_HEAD_V1` construction, using the unchanged NASH1 grammar. It reports `NOT_CHECKED_HERE` and `NOT_ESTABLISHED`. |
| `opening_expectation` | Whether this actual disk open successfully matched an explicit expectation, and whether that same exact input still equals this observation. |
| `observation` | `ONE_STATE_LOCK`, `REPLAY_AND_LIVE_APPLICATION`, `disk_reaudit: false`, and `may_advance_after_sample: true`. |
| `automatic_update` | Always false. No external anchor is written or advanced. |

Normal annotations identify the request digest, actual UID/GID/PID, and `command_class: INSPECT`. No evidence payload, key material, identity path, configuration text, free-text reason, application logical-state digest, history list, or external-anchor file is exposed.

For keyed state, `state_head.selector` reuses the exact existing construction:

```text
NASH1:<node>:<generation>:<key_id>:<epoch>:<root>:<records>:<journal_bytes>
```

The separately displayed authentication fields and byte count come from the same mutex-protected sample. This is not a new selector meaning. Unkeyed state returns a null selector and null authentication account; checksums are not relabeled as authenticated roots.

## Opening expectation is historical, not continuously refreshed

The process records `opening_expectation` only after its real disk constructor has authenticated, completely replayed, and successfully matched `--expected-state-head`. In-memory replay and checkpoint candidates do not inherit that fact. Nothing is persisted as an opening expectation.

With an expectation:

```json
{
  "result": "MATCHED_AT_OPEN",
  "scope": "PROCESS_OPEN_INPUT_ONLY",
  "matches_observation": false
}
```

The boolean is true only while all seven opening accounts still equal the sampled live head. Ordinary appends or compaction can make it false without invalidating the historical fact that startup matched. The endpoint does not turn the new head into a newly supplied expectation, and its freshness remains `NOT_ESTABLISHED` even when the boolean is true.

Without an expectation, `result` is `NOT_SUPPLIED` and `matches_observation` is null. Restarting without the option does not recover an earlier process's expectation from the journal. Restarting with a stale expectation continues to fail the normal exact-input check. See [external expectations](EXTERNAL-STATE-EXPECTATIONS.md).

## Concurrency and failed writers

Post-decode current authorization is the shared control-plane rule. A UID revoked while transmitting a partial request is denied; a grant accepted before decoding completes may authorize it. Once authorized, the retained configuration lease prevents publication of a different policy until the sample has been built. As with other bounded reads, already authorized response bytes may finish transmitting after subsequent policy publication.

Append, live application, and compaction hold the same state mutex as the observation. A returned account therefore precedes or follows those operations; it cannot mix an old root with a new byte count or a new epoch with an old count. Observations do not acquire a new journal lock or reopen a candidate. A poisoned writer returns `STATE_RESTART_REQUIRED`, including both failed writes before publication and partial in-memory application after successful durable publication. A durable root alone is not sufficient to advertise a healthy live observation after partial application.

Quiescence and draining permit this read under the same current INSPECT check. The endpoint cannot resume, cancel, retry, acknowledge, compact, replenish an allowance, reset a deadline, or revive work.

## Bounded capture workflow

For a running node, capture the whole response and check success, format, keyed mode, and non-null selector. Treat that selector as a sample that may already have been superseded. Select and protect it in separately managed storage only through an explicit operator procedure. The product does not select a custody mechanism or attest to its independence.

**Quiesce is not a freeze.** Existing delivery obligations and peer admissions can still append. The tests demonstrate an acknowledged receipt changing the head while the provider remains quiesced. A draining sample is also not a final shutdown head: delivery, attempts, denial audits, and the drain's terminal lifecycle record can follow it.

For a stable post-stop capture, complete a bounded `drain-shutdown` (or an explicit shutdown), establish that the owning process and its workers have exited and no replacement writer has started, then use the existing complete keyed offline audit:

```sh
./node/bin/natrav-overlay state-auth-audit \
  --state state-a --node A --state-auth-key /private-keys/state-g1.key
```

The audit's successful complete-state selector identifies that stopped representation. A timed-out drain can leave pending obligations; the selector proves neither delivery completion nor application success. An incomplete journal requires the existing explicit recovery workflow, not a live sample or matching prefix. Protecting an old snapshot together with its old selector still permits rollback; independent custody, trusted launch policy, and deliberate selection remain external responsibilities.

## Compatibility and evidence

No durable journal, authenticated header, NSS/NST, logical-state, checkpoint, backup, peer, permission-class, configuration, or storage-schema encoding changes. There is one new local control kind and a new versioned JSON response. Older executables reject the new command or wire kind; ordinary persisted state remains independently readable.

The independent suite authenticates raw bytes rather than deriving its expected value from product JSON. It checks response bounds and exact fields, read-only file accounts, strict requests, real UID grant/revocation during partial transmission, an authorized read ahead of queued policy publication, startup/restart expectations, real peer-delivery prefix sampling, compaction publication blocking, and quiesce/drain behavior. A separate private source-failure probe checks poisoned-state refusal. The narrow negative control omits only INSPECT enforcement for this request; its detection and all fresh/excluded profiles are recorded in [validation](../validation/VALIDATION.json) and [attempts](../validation/ATTEMPTS.md).

The scope remains one Linux kernel and configured loopback peers. No independent physical-host, physical power-cut, hostile-host, independent custody, or static-link portability guarantee is established.


## Revision 0566: optional terminal handoff

An explicitly requested `--final-state-head yes` on shutdown or drain-shutdown defers the reply until all writer joins and final lifecycle accounting. It requires both SHUTDOWN and current INSPECT and does not turn a live sample into a terminal one. The exact NASH1 selector and external-custody limits are unchanged. [Terminal contract](TERMINAL-STATE-HEAD.md).
