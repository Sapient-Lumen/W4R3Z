# Authenticated audit and explicit recovery — revision 0504

**Current extension (0564):** [External state expectations](EXTERNAL-STATE-EXPECTATIONS.md) add an optional exact, separately supplied input-head condition. Historical statements below about intrinsic authentication freshness remain true: no managed latest-head anchor exists, and an old expectation paired with its old valid state still matches.

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Contract

`state-auth-audit` is a bounded, offline, noncreating inspection of an existing authenticated state. `state-auth-recover` is an explicit adoption of the **maximal verified, semantically valid prefix** of a journal with a structurally plausible incomplete final record. It is never called automatically by startup. A complete invalid tag is not a recoverable tail.

The recovery command does not prove that truncation was accidental or harmless. It cannot know which lost operations a remote party observed, or reconstruct bytes that are not present. It preserves every obligation, receipt, effect and configuration represented in the selected prefix. Any effects or obligations absent from that prefix remain outside its knowledge. The caller authorizes this specific loss boundary, rather than requesting generic repair.

All commands are native C++20. They need the separate state key, not a backup-encryption or TLS key. No owner CLI, external machine or sibling NATrav binary is required for implementation or testing.

## Read-only audit

```sh
./node/bin/natrav-overlay state-auth-audit \
  --state state-a --node A --state-auth-key private-state-keys/state-g1.key
```

The command opens existing schema-2 metadata, `state.lock` and `state.journal` without creating files, changing modes, cleaning candidates or truncating data. It walks state ancestry descriptor-relatively without following symlinks. The state directory must be effective-user owned, mode `0700`; metadata, journal and lock must be single-link regular files owned by that user, mode `0600`. Both existing locks are acquired exclusively and nonblocking. A running state owner produces `STATE_BUSY`. A missing lock is an error, not an invitation to create one. Source file descriptors use `O_NOATIME`; unrelated directory/key access-time behavior is not a forensic guarantee.

The scanner shares the ordinary loader's authentication path. It verifies the header before interpreting it, checks each complete record's MAC and chain, and stops at the first failure. It never skips over a bad record looking for later valid material. For a partial frame it checks every available magic/sequence/predecessor byte and, when available, agreement between inner and outer lengths. Obviously malformed fragments are `INVALID`, not torn writes.

The last complete prefix is then replayed **in memory**, after authentication, through the ordinary application entry decoder. The initial checkpoint digest, checksums, kind bounds, configuration bindings, action/receipt invariants and other semantics remain mandatory. Neither the partial frame nor application state following an invalid record is applied. Audit creates no temporary plaintext state.

The JSON format is `NATRAV_OVERLAY_STATE_AUTH_AUDIT_V1`. It reports:

| Field | Meaning |
|---|---|
| `status` | `COMPLETE`, `INCOMPLETE_TAIL`, or `INVALID` |
| `source_bytes`, `source_sha256` | Size and SHA-256 of the complete observed file |
| `verified_bytes`, `prefix_sha256` | Exact last verified boundary and its prefix digest |
| `unverified_bytes`, `unverified_sha256` | Size/digest of everything after that boundary |
| `prefix_semantics_valid`, `logical_state_digest` | Whether normal replay accepts the selected prefix, and its application-state digest |
| `state_authentication` | Verified key generation, epoch, root, record count and histories; `null` when no header is authenticated |
| `recovery_eligible` | True only for an incomplete terminal frame after a valid checkpoint and valid application prefix, without an expected-head mismatch |
| `code` | Typed first authentication/semantic error or expected-head failure |

A complete valid audit exits 0. An incomplete, invalid or expected-head-mismatched audit exits 3 but retains its structured report. Path/key-loading/ownership failures use the normal typed error envelope. Header-only state and an incomplete first checkpoint are not recoverable.

`--max-journal-bytes N` retains the normal bounded input ceiling, accepted within 1,024 bytes through 1 GiB. Verification is in memory and may hold several copies plus reconstructed logical state. The upper format limit is not a memory-capacity guarantee; operators should choose a limit appropriate to available memory.

## Optional expected head

Supply the pair together:

```sh
./node/bin/natrav-overlay state-auth-audit \
  --state state-a --node A --state-auth-key private-state-keys/state-g1.key \
  --expected-root "$EXPECTED_ROOT" --expected-records "$EXPECTED_RECORDS"
```

The comparison is exact, not an ancestry proof. The result is `MATCH`, `MISMATCH` or `NOT_SUPPLIED`. A mismatch causes exit 3 even if the current bytes form a valid authenticated journal. A mismatch can also mean legitimate later appends or a different valid checkpoint, not necessarily an attack.

The caller must protect and correctly associate the expected head. Copying the head from the same untrusted snapshot does not establish freshness. A valid old complete prefix or whole snapshot remains cryptographically valid without such an independent authority. Every account continues to state `freshness: NOT_ESTABLISHED`; no monotonic storage, distributed lease, rollback guarantee or split-brain prevention is invented.

## Explicit source selection and preservation

After inspecting the audit, supply its exact values deliberately:

```sh
./node/bin/natrav-overlay state-auth-recover \
  --state state-a --node A --state-auth-key private-state-keys/state-g1.key \
  --source-sha256 "$SOURCE_SHA256" \
  --prefix-root "$PREFIX_ROOT" --prefix-records "$PREFIX_RECORDS" \
  --prefix-bytes "$PREFIX_BYTES" \
  --preserve-source recovery-evidence/original.journal \
  --reason 'adopt the explicitly selected verified prefix'
```

All five selection values—source digest, prefix root, prefix count, prefix bytes and source node—must agree with a new audit performed while exclusively owning the source. The prefix must be the last verified one, not an earlier selectable rollback point. A complete valid source needs no recovery and is rejected. A complete bad-MAC frame, wrong key, semantic corruption, malformed partial header, missing checkpoint, source change or selection mismatch is rejected without replacement.

`--preserve-source` is mandatory. Its parent must already exist, be effective-user owned and not group/other writable; no component may be a symbolic link. The filename uses bounded safe ASCII. The destination must be outside the live state directory tree, avoiding names that maintenance could later interpret as stale candidates. No existing destination is overwritten, including a symlink. Evidence is an independent mode-0600 single-link copy of **every original byte**, read back for equality, synchronized and published with `RENAME_NOREPLACE`. Its directory is synchronized before the journal is replaced.

Evidence is retained once published even if the subsequent transition fails. It is plaintext authenticated-journal material and may contain sensitive evidence/configuration paths. Protect it separately. Its digest is retained in the accepted recovery history; its potentially sensitive filesystem pathname is not.

## Publication and crash boundary

Recovery constructs a plain canonical checkpoint only after normal replay of the selected prefix. It creates a fresh authenticated epoch using the same active state key. The selected application digest remains unchanged; new recovery provenance belongs to the authenticated representation, not to the application digest.

A random mode-0600 sibling is written and synchronized. The actual on-disk candidate passes `NodeState::validate_checkpoint_image`, including HMAC and semantic validation; its root and logical digest must equal the constructed values. The source descriptor, inode, size, mode, owner and contents are rechecked before evidence publication and immediately before replacement. Cooperative state owners are excluded by the stable lock; these checks do not make a malicious same-UID writer or compromised kernel safe.

After the complete source evidence is durably published, the candidate atomically replaces `state.journal`, followed by directory `fsync`. Normal source metadata and the stable lock are not rewritten. The command exits without starting a scheduler.

A real kill before journal publication leaves the original incomplete source authoritative. The evidence copy already exists, so retry requires a fresh no-overwrite evidence destination. A kill after publication/directory sync leaves the recovered checkpoint authoritative even when no success response reached the client. A sync failure after publication requires audit; it is not reported as an unchanged source.

A hard kill may leave owner-only `.natrav-recovery-*.tmp` siblings. They are never automatically adopted or deleted by audit. They are nonauthoritative candidates, not a second current journal. Ordinary caught pre-publication failures clean only the current process's unpublished candidate. Preserve and inspect abandoned material before deliberate offline cleanup. Neither test kills nor atomic rename establish universal physical power-loss behavior.

## Authenticated provenance format

`NOAUTH01` authentication header version 1 remains readable. A state with recovery history uses header version 2; its existing header fields and generation history are followed by `u16 recovery_count` (1..64) and that many recovery records. The existing 65,536-byte header ceiling still applies to combined key and recovery histories. Earlier revision-0503 binaries reject version 2 rather than dropping its history.

All integers are big endian. Each recovery record contains:

```text
source_sha256[32]
discarded_sha256[32]
prefix_sha256[32]
selected_root[32]
selected_epoch[32]
text16 state_key_generation
state_key_id[32]
u64 selected_records
u64 source_bytes
u64 prefix_bytes
u64 unix_ms
u32 effective_uid
u32 process_id
text16 reason                   # 1..512 printable ASCII bytes
```

`source_bytes` must exceed `prefix_bytes`; a checkpoint and nonzero selected root/epoch must exist. The generation and key ID must refer to retained key history. A `RECOVER` header's parent root and active key must match its newest recovery entry. Invalid metadata fails even if a test recomputes a correct HMAC. The header MAC authenticates the entire extension. `NAR1`, `NOJ1`, `NLS2`, `NCP3`, configuration V8 and peer wire protocols are unchanged.

The transition records `decision: EXPLICIT_PREFIX_ADOPTION` and `cause: NOT_ESTABLISHED`. It retains actual effective UID, PID, time and bounded reason. Compaction, backup, restore and rotation copy this history under the current authenticated header; rotation does not relabel an earlier recovery's key generation. Up to 64 recovery entries are retained with no pruning. Header size can bind before both histories reach their individual count limits.

## Validation boundary

The new seven-case suite covers independently reproduced roots and recovery fields, read-only file accounts, expected-head comparison, partial-frame boundaries, complete bad-MAC rejection, strict selection, evidence collisions/paths, invalid semantic prefixes with valid MACs, candidate corruption, competing owners, actual pre/post-publication kills, an actual partial C++ append interrupted by `SIGKILL`, and further keyed operation.

The integrated scenario preserves a completed counter effect of 7, a terminal rejection and pending delivery. After recovery, it compacts, performs signed encrypted export/verification/restore, relocates, delivers pending work, rejects duplicate execution by returning the old receipt, rotates the state key and delivers new work. The recipient ends with two records for two distinct operations. This demonstrates continuation of the selected prefix—not recovery of anything missing from it.

Python independently encodes and decodes authentication framing and recovery metadata; its primitive backend may share OpenSSL. It is not independent cryptanalysis. Actual completed matrices and the detected recovery-policy negative control are retained in [validation](../validation/VALIDATION.json). [Testing](TESTING.md) describes reproduction.

## Primary references

Consulted October 4, 2026: Linux `rename(2)` specifies atomic replacement and no-replace publication; `fsync(2)` distinguishes file synchronization from directory-entry synchronization. OpenSSL supplies the checked HMAC primitive. These API contracts are not empirical proof about every filesystem/device.

```text
https://man7.org/linux/man-pages/man2/rename.2.html
https://man7.org/linux/man-pages/man2/fsync.2.html
https://docs.openssl.org/3.0/man7/EVP_MAC-HMAC/
```
