# Bounded pending-action selection

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

Revision 0541 replaces the counter-action worker's copied pending vector with replay-derived readiness and expiry indexes.  This is an internal scheduling change: the durable action formats, action-query contract, counter semantics, permissions and configuration versions are unchanged.

## Authoritative source and derived indexes

The journal remains the authority.  Normal admission, start, completion, cancellation, expiry, checkpoint loading and journal replay call the same action-index update hook.

Every pending action contributes its stable queue position to two augmented ordered trees:

```text
readiness tree: queue position -> not-before time
expiry tree:    queue position -> expiry time
```

A terminal transition removes the action from both trees.  A begun but unfinished attempt remains pending and ready, preserving the existing restart-retry behavior.

The trees are ordered by stable action queue position and carry subtree-minimum times.  Selection therefore finds the earliest queued due item without walking an earlier delayed prefix.  If the same action is both ready and expired, expiry wins.  Between different due actions, the lower queue position wins.

The indexes contain deadlines, queue positions and process-local revision counters.  They do not copy action payloads, source records, authorization accounts, transition histories or completed results.  They are not persisted as a separately trusted structure.

## Narrow selection and revalidation

One scheduler turn obtains at most one payload-free `ActionSelection`:

```text
action ID and immutable record digest
stable queue sequence
process-local action revision
admission, not-before and expiry times
amount and recorded attempt count
selection kind: READY or EXPIRED
next wake time and bounded work counters
```

Before journal mutation, `NodeState` rechecks the exact action ID, queue sequence, immutable record digest, revision, timing, amount, attempt count and pending state under the state mutex.

The action transition mutex serializes this sequence with local action cancellation:

```text
metadata selection
-> exact pending-state check
-> synchronized begun-attempt record
-> bounded counter effect
-> synchronized completion record
```

Expiry likewise revalidates the selected action immediately before appending its terminal transition.  A stale in-memory selection returns no effect and prompts another scheduler turn.

The worker no longer calls `pending_actions()` and reports:

```text
actions.selection_work.calls
actions.selection_work.index_nodes_visited
actions.selection_work.metadata_records_read
actions.selection_work.pending_vector_copies = 0
actions.selection_work.stale_selections
```

These are run-scoped observations, not durable accounting.

## Preserved semantics

Revision 0541 preserves:

- queue-position fairness among due actions;
- original not-before, expiry, amount and admitted-limit contracts;
- one synchronized begun record before the local counter effect;
- one synchronized completion record after the effect;
- interrupted-attempt reconstruction and retry after restart;
- exact action reservations and aggregate action counts;
- cancellation ordering through the existing action transition mutex;
- action inspection, source-admission and configuration-attribution semantics;
- ordinary compaction and checkpoint reconstruction.

An action begun before its deadline retains the existing bounded execution contract even when its completion timestamp falls after the deadline.  A still-unbegun action whose deadline elapses is selected for expiry before execution.

## Measured work

The compiled-process regression places one ready action at queue position 129 behind 128 delayed actions.  The transition from the pre-admission observation to completed execution reads one selected metadata record, visits 11 index nodes and copies no pending vector.

A separate native differential test builds 65,536 delayed entries followed by one ready entry.  That selection visits 18 tree nodes.  Across 50,000 deterministic randomized insert/update/remove operations, the production index agrees with an independent ordered reference in 250,505 checks; the maximum observed selection path is 28 nodes.

Those measurements cover the explicit index-selection locations.  They are not process-wide allocation counts, throughput benchmarks or maximum deployment-scale claims.  Journal replay and index memory remain proportional to retained actions.

## Tested failure and recovery boundaries

The integrated tests establish:

- a cancelled first action cannot remain in the index and hide a later ready action;
- an unbegun action can expire while another begun action occupies the serialized worker, after which later work still progresses;
- a begun action interrupted by `SIGKILL` is selected after restart, records a second attempt and commits the counter effect once;
- compaction and restart rebuild terminal removal and completed result state through the ordinary decoder;
- a deliberately weakened build that leaves terminal actions indexed is detected because the stale head prevents later progress.

These are specified process/journal boundaries on one Linux kernel.  They are not universal physical-power-loss proof, hard real-time scheduling, independent-host testing or evidence of parallel action execution.

## Remaining boundary

There is one cooperative counter-action worker and one outstanding local effect at a time.  Selection and transitions remain mutex-based.  Index construction during startup is linear in retained actions.  The action-cancel response still uses a broader state path and does not yet bind its mutation to an exact inspected semantic state; that is the next construction target.
