# Explicit publication-channel epochs — revision 0517

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

Revision 0517 lets an operator continue a durable projection-publication channel after its current correction line ends in an exact terminal outcome:

```text
REJECTED
CANCELLED
EXPIRED
```

The transition does **not** pretend that the terminal operation was acknowledged. It does not use the terminal operation as an evidence `corrects` parent. The first publication in the replacement epoch is a new evidence original whose canonical payload retains an explicit lineage account for the prior terminal epoch.

## Command

```text
publication-channel-new-epoch
  --control PATH
  --channel NAME
  --instance HEX64
  --expected-channel-revision N
  --expected-epoch N
  --terminal-operation HEX64
  --terminal-outcome rejected|cancelled|expired
  --expected-projection-revision N
  --expected-position N
  --result-digest HEX64
  --reason TEXT
```

The request must select the exact kernel-owned channel instance, current channel revision, terminal head, terminal outcome, projection revision, processed position, and canonical result digest. It requires the same current V12 `PROJECTION`, `CONSUMER`, `SUBMIT`, and exact source-read authority as ordinary channel publication.

Pending and acknowledged heads are ineligible. A rejected head may instead use the existing attributable outbox retry path; choosing a new epoch is a separate operator decision. Retired channels cannot start another epoch.

## Epoch semantics

A channel begins in epoch 1. Within an epoch, the established linear rule is unchanged:

```text
first publication in epoch = evidence original
later publication in epoch = correction of the prior durably acknowledged head
```

A replacement epoch increments the epoch exactly once and begins with a new original. The durable publication revision records:

- new epoch number;
- terminal predecessor operation;
- terminal outcome;
- actor UID and reason;
- accepted configuration event;
- selected projection frontier and result digest;
- active recipient key generation and SPKI at enqueue time.

The channel retains at most 32 epochs and at most the finite publication count fixed at channel creation. Reaching either bound fails closed without deleting older lineage.

## Canonical `NPC2` evidence

Epoch-aware publications use `NPC2`. It extends the existing `NPC1` wrapper with:

- monotonically increasing epoch;
- optional terminal predecessor operation;
- terminal predecessor outcome.

The operation ID remains derived from the complete wrapper:

```text
SHA-256(
  "NATRAV_OVERLAY_PUBLICATION_CHANNEL_OPERATION_V1"
  || 0x00
  || NPC2
)
```

The first record of a later epoch has:

```text
corrects = absent
prior_epoch_terminal_operation = exact terminal head
prior_epoch_terminal_outcome = REJECTED | CANCELLED | EXPIRED
```

Later records in that epoch have ordinary correction ancestry and no repeated terminal-lineage field. Epoch-1 publications without lineage remain byte-compatible `NPC1`, preserving existing recipients and operation identities.

`NPC2` contains the complete canonical `NPP1` result account but does not copy source evidence payloads. The lineage reference is attributable context; it is not remote acknowledgment and is not an evidence correction link.

## Atomicity and exact retry

The `NEW_EPOCH` transition remains journal kind 30 inside `NCT1`. One synchronized record contains:

```text
NCH3 channel revision
+ canonical NPC2 original evidence
+ active recipient-generation delivery policy
+ terminal-head lineage
+ automatic-grant consequence
```

There is no accepted epoch head without its ordinary outbox obligation.

A retry that repeats the exact prior selectors, reason, projection frontier, and result digest returns `ALREADY_STARTED`, even if the projection has since advanced. A stale or altered selector cannot reinterpret the accepted transition.

Real kill-boundary tests establish:

| Interruption | Reconstructed state |
|---|---|
| Before synchronized append | Prior terminal epoch remains authoritative; exact retry queues one replacement |
| After synchronized append | Replacement epoch and outbox operation reconstruct together; exact retry returns `ALREADY_STARTED` |

## Automatic-publication interaction

An enabled automatic-publication grant is never silently carried into a manually selected replacement epoch. If it is still enabled when the epoch transition commits, the same transaction closes it as:

```text
BLOCKED
PUBLICATION_CHANNEL_NEW_EPOCH_REQUIRES_NEW_GRANT
```

A grant already blocked by the terminal predecessor remains blocked. The owner must create a new finite grant explicitly before automatic corrections can continue in the replacement epoch.

The internal projection scheduler is independent and may continue computing results. Computation authority still does not imply remote disclosure authority.

## Recipient and key behavior

The replacement original uses the recipient route and active key generation that are current at enqueue time. That generation and SPKI are durably bound to the outbox operation. Later route, key, or configuration changes do not reinterpret it.

The recipient independently applies its normal mutually authenticated issuer/scope policy. A new epoch does not bypass a previous authorization denial; the replacement original can itself become durably `REJECTED`.

## Persistence and recovery

Current channel encoding is `NCH3`. It extends backward-readable `NCH1`/`NCH2` publication revisions with epoch and terminal-lineage fields. Local request envelope `PCR3` extends strict `PCR1`/`PCR2` decoding with the epoch command. Checkpoint extension `NPH1` remains the registry carrier.

Semantic replay verifies:

- exact prior channel revision and terminal head;
- terminal outcome from durable outbox state;
- monotonic epoch and publication sequence;
- absence of `corrects` on an epoch-opening original;
- canonical `NPC2` operation and record digests;
- selected projection result and source commitment;
- exact active recipient generation and SPKI;
- explicit automatic-grant blocking when required.

Compaction, keyed authentication audit, signed encrypted backup, restore, relocation, and later correction delivery preserve the same lineage. Arbitrarily incomplete authenticated records still use the explicit audit-and-recovery path.

## Tested boundaries

The dedicated suite covers:

- cancelled, rejected, and expired heads;
- refusal for pending and acknowledged heads;
- nonzero wrong terminal-operation selectors;
- exact retry after the projection advances;
- recipient denial of a replacement original;
- explicit automatic-grant re-enable;
- pre/post-commit `SIGKILL`;
- keyed compaction, signed encrypted restore, relocation, and continuation;
- the 32-epoch capacity boundary.

A negative-control build removes the exact terminal-operation binding from command validation, channel-state validation, and semantic replay. It then accepts a fabricated terminal operation, and the selected regression fails. The weakened executable is not delivered.

## Nonclaims

Epochs preserve a discontinuity; they do not repair it. They do not prove why delivery ended, whether a recipient observed an unacknowledged effect, whether source evidence is true, or whether a restored snapshot is fresh. They do not merge independent node histories or prevent split brain.
