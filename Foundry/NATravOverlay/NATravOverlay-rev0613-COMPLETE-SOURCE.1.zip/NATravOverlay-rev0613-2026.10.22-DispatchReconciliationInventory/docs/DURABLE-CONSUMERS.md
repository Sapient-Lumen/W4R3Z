# Durable evidence consumers — revision 0509

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Contract and trust boundary

The persistent C++ node supports `consumer-create`, `consumer-read`, `consumer-ack`, `consumer-status` and `consumer-reset`. These use the existing Linux Unix control socket, not a second service, Python runtime or external broker. Read domains are checked against the kernel UID captured by SO_PEERCRED; request bytes cannot select an owner UID. Names are local to that UID. The same name for two UIDs denotes two different objects.

Registration and checkpoint advancement are durable application state. A checkpoint is **not** an authorization grant, evidence-truth claim, freshness proof, or transaction with an external effect. A client should process immutable operation IDs idempotently or commit its own effect and deduplication state together before acknowledging. A crash between an external effect and acknowledgment can replay that effect's input.

## Explicit V11 adoption

```
NATRAV_OVERLAY_CONFIG_V11
# Other required identity, listener, state and resource settings are unchanged.
local_control=1001,EVIDENCE_READ,EVIDENCE_PAYLOAD,CONSUMER,CONSUMER_ADMIN
evidence_read=1001,A,observations/temperature,PAYLOAD
```

`CONSUMER` permits registration, bounded reading, acknowledgment and inspection of the caller's own consumers. It requires EVIDENCE_READ and at least one exact read domain. `CONSUMER_ADMIN` additionally permits an explicit reset of that same UID's consumers. It requires CONSUMER. It does not permit impersonation, cross-owner takeover or a read-policy bypass. Payload mode also requires EVIDENCE_PAYLOAD and a payload-enabled domain.

ALL remains the original six administrative classes; neither new consumer class is implied. V6–V10 remain readable and retain their earlier behavior. They cannot opt into consumer commands accidentally: V11 is required. A currently accepted V11 configuration can be activated through the existing explicit live-configuration path. Offline historical replay does not load obsolete identity files.

Filesystem reachability is separate from application authorization. The normal state directory and socket remain owner-restricted; granting a UID does not itself publish the socket to that UID. Tests expose only disposable owned endpoints for actual different-UID clients.

## Fixed selection, bounded objects

Registration fixes the exact issuer and scope filters (either may be omitted), metadata versus payload-prefix mode, row bound, response bound and payload-prefix size. These cannot be edited in place. It also adopts the effective exact-domain read-authority digest for that UID. This includes the UID's whole domain union and metadata/payload command permissions, not just the currently populated records.

Hard bounds:

| Resource | Bound |
|---|---:|
| Registered consumers | 128 total, 16 per UID |
| Name | 1–64 ASCII letters, digits, `_`, `-`, `.`; not `.` or `..` |
| Outstanding pages | One per consumer |
| Page records | 1–128 |
| Annotated JSON reply | At most 60,000 bytes, excluding outer control framing |
| Payload prefix per row | 0–16,384 bytes, explicit payload mode required |
| Creation plus reset accounts | At most 32 per consumer |
| Reason | 1–256 printable ASCII characters |
| Revision and acknowledgment counters | Unsigned 64-bit, revision exhaustion rejected |

An immutable page budget must be at least **8192 + 2 × payload_length** bytes. This conservatively reserves space for a maximum metadata row, its encoded payload prefix, consumer accounts and the principal annotation. An undersized registration fails before allocating a consumer, avoiding a later permanently unsendable first row. Default response size is 60,000 and default row count is 32.

There is no delete, expiry, automatic slot reclamation or name reuse. Explicit [retirement](CONSUMER-RETIREMENT.md) releases an active slot into a separately bounded retained archive while permanently reserving its name. A name has one random 256-bit instance identity throughout accepted history. At an active-registry or reset-history cap, new construction/reset fails; existing active readers and acknowledgments continue. Empty active consumers count toward active capacity.

## Lifecycle

### Register

```sh
./node/bin/natrav-overlay consumer-create \
  --control /owned/state/control.sock --consumer temperature-view \
  --issuer A --scope observations/temperature --limit 32 \
  --payload yes --payload-length 4096 \
  --start beginning --reason 'initialize the temperature projection'
```

`beginning` adopts position zero. `now` deliberately skips to the current authorized tail without enumerating or hashing history. This initial position does not mean the application processed earlier events. The adoption record preserves that choice and reason.

Repeating registration of the same name with the same fixed selection returns ALREADY_EXISTS and the existing identity/progress. It never silently resets or skips, even if the retry says `now`. A different selection under that name fails. A lost creation reply therefore does not create a second consumer. A changed authority must be explicitly reset/readopted, not bypassed by recreating the same name.

### Read and replay

```sh
./node/bin/natrav-overlay consumer-read \
  --control /owned/state/control.sock --consumer temperature-view
```

When work exists and no page is outstanding, the node selects a bounded page under the state mutex, generates a random 256-bit batch ID, records the exact from/through authorized ordinals and a domain-separated digest of the immutable returned rows, and synchronizes ISSUE before returning success.

A read does not advance the acknowledged position. Subsequent reads replay the same batch ID, boundaries and immutable rows until acknowledgment or explicit reset. Visible appends and corrections do not change the issued rows; corrections are later immutable admission events. Remaining-count and caught-up metadata may change as later evidence arrives. Issued pages have no wall-clock expiry and need no process-local secret to survive restart.

A lost read response is recoverable by another read. A client disconnect does not consume work. The node stores the bounded boundary and row digest, not a duplicate of the payload collection. Append-only evidence reconstructs the page on replay.

Caught-up polls return EMPTY with no batch and do not append journal or successful-control-audit entries. Replaying an outstanding page likewise creates no new state. These requests still check current authority and their bounded deadlines.

### Acknowledge

```sh
./node/bin/natrav-overlay consumer-ack \
  --control /owned/state/control.sock --consumer temperature-view \
  --batch HEX64_FROM_PENDING_BATCH_ID
```

Only the exact outstanding issued batch can advance progress. The caller does not supply a sequence number. UID ownership, current consumer/read grants, adopted authority and the random batch ID must agree. Forged and cross-consumer/cross-owner IDs fail without advancement.

ACK synchronizes the position change, clears the outstanding page and retains the last acknowledged batch. Eight simultaneous acknowledgments have one committing winner; the others observe ALREADY_ACKNOWLEDGED. A repeated acknowledgment of the **most recently acknowledged** batch remains idempotent across restart and even after another page is issued. Older acknowledged IDs are not an unbounded receipt table and return CONSUMER_ACK_INVALID. A reset clears this duplicate-ack window.

The last page is retained as metadata/digest, not as a second payload copy. Successful acknowledgment does not prove what the client did with those bytes.

### Inspect, freeze and reset

```sh
./node/bin/natrav-overlay consumer-status \
  --control /owned/state/control.sock --consumer temperature-view

./node/bin/natrav-overlay consumer-reset \
  --control /owned/state/control.sock --consumer temperature-view \
  --expected-revision CURRENT_REVISION --start beginning \
  --reason 'rebuild the local projection under the reviewed read policy'
```

Status exposes only the caller's named consumer, not a global consumer listing. Complete offline inspect includes all private consumer provenance and remains a separate owner/file-access boundary.

Every read and acknowledgment is reauthorized after decoding the complete control request, under a stable accepted configuration. Removing access denies the operation. Changing the effective read-authority digest freezes reads/ACKs with CONSUMER_POLICY_CHANGED. It does not reinterpret a saved ordinal over a different domain union. Surviving grants allow inspection of the caller's own frozen metadata. Fully revoked access does not permit payload or consumer-state retrieval.

An explicit reset requires CONSUMER_ADMIN, current read authority, the exact current revision, a reason, and a choice of beginning or now. It advances the epoch, retains old/new positions and old/new authority through the adoption history, records the abandoned batch ID, and clears outstanding/last-ack state. A stale repeated reset cannot skip more newly arrived work: it fails CONSUMER_REVISION_CONFLICT, so the client must inspect the committed result. Filters and resource options remain fixed.

Route-only changes, policy changes for another UID, and relocation can preserve consumer continuity when the effective reader authority is unchanged. Revoking only CONSUMER_ADMIN does not prevent ordinary acknowledgment. Configuration changes are never inferred as authorization to reset.

## Work, locking and lifecycle

The implementation shares the production feed's ordered exact-domain selection. It neither scans already consumed admissions nor hashes a full-history root. Empty reads visit zero evidence records. Pages hold the state mutex for bounded selection/serialization; ISSUE and ACK hold it through synchronized journal append. The existing configuration lease protects the policy-to-commit boundary. This is not wait-free processing.

Response `consumer_work` distinguishes page index visits from semantic-validation record visits. Before and during replay, the validator may reconstruct at most the current outstanding and last-acknowledged bounded pages. A committing operation can therefore validate up to four bounded pages; these visits are reported rather than hidden behind the page-only counter. No historical selection hash is computed. Configuration parsing and bounded adoption-history checks still cost CPU. Per-command checkpoint validation is bounded by stored page limits, not by all retained evidence.

Consumer read is potentially mutating because it may ISSUE a page. Quiesce/drain therefore rejects consumer creation/read/ACK/reset, even if a particular read would have been empty or a replay. Consumer status remains observational. Existing durable consumer state is not a delegated action or pending outbound obligation and does not prevent drain from completing. Resume restores service without losing it.

## Durable format and replay

NOC1 local control kind 17 carries strict NCR1: a command byte, bounded name and only that command's fields. Unknown commands, malformed lengths, invalid flags and trailing bytes fail closed. Neither UID nor an arbitrary acknowledged offset is a wire field.

Journal kind **27**, consumer_update, carries a canonical NCS1 full bounded consumer state. It is self-bound to an accepted configuration event, owner UID, PID, time and CREATE/ISSUE/ACK/RESET transition, rather than a free-form administrative note. Normal replay checks the exact preceding revision/state, immutable identity/selection, capacity, adopted historical authority, available authorized history, issued/acknowledged row digests, monotonic ACK progression and reset history. Recomputing the old checksum does not make an impossible transition valid. Keyed records additionally authenticate the complete event before semantic replay.

NLS2 checkpoints gain optional **NDC1** after configuration/local-administration extensions. It stores consumers in canonical UID/name order. It is absent for states without consumers. Storage schema remains 2 and NCP3 remains the checkpoint envelope. Old binaries reject unsupported nonempty consumer state rather than silently dropping it. All normal file replay, in-memory checkpoint replay, audit/recovery prefix replay, migration, rotation, compaction and backup validation paths understand kind 27 and NDC1.

Compaction preserves current progress, pending/last-ack boundaries, counts and every bounded adoption/reset account. It folds intermediate ISSUE/ACK events into this current consumer state; it does not retain an unbounded chronological list of all previous ACK receipts. Backups copy durable consumer state but not filesystem identity/key material. Restore may replay earlier accepted progress if an old valid backup is deliberately selected: freshness remains NOT_ESTABLISHED without a protected reference.

Hard-kill tests cover immediately before and after synchronized ACK. Before commit, the outstanding page survives; after commit, progress survives even without a success response. Arbitrary partial authenticated appends still fail normal startup and require explicit audited recovery or restore; the new feature does not weaken that boundary. A restored second complete copy can diverge from another live copy; no distributed lease or split-brain prevention is claimed.

## Evidence and remaining work

`run_consumers.py` covers independent NCR1 encoding, permissions and capacity, actual UIDs, slow-request revocation, concurrent readers/ACKs, lost replies, corrections and hidden writes, explicit reset and limits, semantic corruption with recomputed checksums, hard kills, keyed audit, compaction, signed encrypted restore/relocation and renewed peer delivery. A large independently encoded fixture tests tail adoption and empty polling without consuming the whole retained history. It is stored synthetic data, not a network-scale experiment.

The negative control bypasses the exact issued-batch comparison while retaining ownership, read authority and durable semantic checks. The forged-ack scenario must then fail because fabricated acknowledgment is accepted. The weakened executable is never shipped.

An integrated native projection whose bounded state update commits in the same journal transition as consumption is the next application opportunity. This checkpoint API alone does not establish exactly-once arbitrary external side effects.

References for the underlying operating-system/library contracts: Linux man-pages `unix(7)` SO_PEERCRED, `fsync(2)`/fdatasync, and OpenSSL `RAND_bytes(3)`/RAND_priv_bytes. Current execution evidence and measured compiler/library versions are retained in validation, not inferred from those documents.

## Configuration template

[Node B consumer template](../node/examples/node-b-consumers.conf) shows separate metadata and payload consumer owners. Replace template UIDs, pins and paths intentionally; no generated credentials are shipped. Filesystem reachability and application grants are independent.

## V12 projected consumers

Revision 0510 adds the explicit PROJECTION class and a bounded metadata definition. Projected consumers share the same UID namespace, page issuance, registry and adoption limits, but ordinary ACK/reset are forbidden. projection-process commits result and progress together; projection-rebuild resets both with retained result provenance. Generic consumer-read/status require the projection grant for these objects. Normal NCS1/V11 consumers and their external-effect limitations are unchanged. See [native projections](PROJECTIONS.md).

## Numeric projected consumers (0511)

Numeric results reuse the single result/progress transition and explicit rebuild history. NCR2 registration and NPR2 state extend the allowlisted registry, not arbitrary code execution. Generic acknowledgments and resets cannot bypass result/progress coupling. The selection explicitly includes a bounded payload prefix; current payload authority is required. See [numeric projections](NUMERIC-PROJECTIONS.md).

## Automatic projected consumers (0512)

Explicitly enabled projections can adopt an existing issued batch or create and consume one page atomically with their result and scheduling budget. Normal consumers remain manual. While enabled, a projected consumer rejects manual mutating commands; pause first. Grant, result and checkpoint semantics are described in [automatic processing](AUTOMATIC-PROJECTIONS.md).

## Revision 0513 — retirement

A consumer may now be explicitly retired under exact owner instance/revision selection. It retains its final state and any explicitly abandoned unacknowledged batch, frees its active slot, and permanently reserves its old name within the retained lineage. The separate archive is bounded. See [consumer retirement](CONSUMER-RETIREMENT.md).

## Discovering retained instances

Revision 0549 adds [owner-scoped current inventory](CONSUMER-INVENTORY.md). It does not change this contract's mutation semantics, read grants, final results or permanent name reservations. The inventory's conservative adopted-authority check may hide an old instance after read-policy changes; it does not reset or delete it.
