# Exact-byte-bound source progress — revision 0559 contract, extended in 0560

## What changed

Ordinary manual `ISSUE`/`ACK` and automatic `AUTO_ISSUE`/`AUTO_ACK` now parse their strict NST3 transaction once within the originating locked mutation. Semantic preflight and live application use that immutable decoder result, but independently execute the existing predecessor, configuration, source, policy, outbox, allowance and actual-receipt predicates.

This is syntax reuse, not reuse of a conclusion that a mutation is valid. No command, permission, request encoding, journal encoding, canonical subscription format, checkpoint representation, application logical-state encoding, configuration version or peer envelope changed. There is no new option. Both compact and default legacy responses use the same progress path; only compact output avoids complete-state serialization for its response selector.

## Construction and lifetime

`NodeState::ParsedSourceProgress` is private, stack-owned, noncopyable and nonmovable. Its members are immutable. Its only constructor accepts owned bytes and invokes the unchanged strict NST3 decoder. There is no constructor accepting an independently supplied decoded transaction, no borrowed mutable byte storage, and no persisted or caller-visible preparation handle.

The object contains the exact transaction bytes, their SHA-256 digest, the normally decoded transaction, the state owner and retained predecessor identity, the accepted configuration digest, the preceding journal byte count and the queue-limit account. The transaction itself binds the grant, instance, predecessor revision/root, active configuration event, timestamp, PID, manual request or finite automatic grant consequence, and either the complete selected outbox consequence or the exact durable-receipt commitment.

The two existing locked command paths call a common commit helper. That helper owns the preparation through preflight, append and application, then destroys it. Every exception also destroys it. No member of `NodeState`, thread-local cache, status result, later worker iteration or public API retains the object. Empty polls and idempotent retries never reach the helper.

The source/configuration preparation and single-use automatic eligibility remain separate. Parsing a transaction neither manufactures disclosure authority nor constructs an eligible source. Automatic classification still precedes transient route and capacity decisions.

## Exact bytes before durable publication

The binding check requires equal length, exact byte-for-byte equality, and matching SHA-256. Equal bytes in different storage are accepted; pointer identity is insufficient. Truncated, extended or otherwise changed bytes cannot select an older decoder result.

The check runs at semantic preflight, before journal frame construction/write, and at live application. Each use also requires the same state owner, retained predecessor object, instance, revision, structural commitment, active accepted configuration digest and queue limits. Preflight and the pre-append check additionally require the original journal byte count. Application occurs after the normal synchronized append, so it checks the still-unadvanced subscription and configuration rather than requiring the pre-append file length.

All actual durable state mutations advance the journal and cannot occur between these stages while the command holds the mutex. The private diagnostic additionally changes individual bindings inside that lock to test rejection. A failed byte/origin check before append writes no frame and does not poison an otherwise clean writer. The normal append path still poisons the writer on write, synchronization or post-append application failure, requiring reconstruction on restart.

The preparation is not a stored freshness anchor. An authenticated rollback still restores an older valid state. No freshness or split-brain guarantee is introduced.

## Semantic work is still independent

Both semantic uses execute the existing checks of current predecessor commitment, active disclosure configuration, source order/local authorship, finite count and payload budgets, exact operation and record digests, initial policy, outbox absence and capacity, manual request identity or finite automatic allowance, and the resulting subscription revision/schedule.

For ACK, neither the parsed transaction nor source preparation owns a substitute receipt. Each semantic pass looks up the outstanding operation and checks its actual durable receipt, including recipient, recorder, generation/SPKI, record and operation identities and receipt commitment. The receipt check count remains two.

Revision 0559 left nested `outbound_queued_with_policy` evidence decoding independent. Revision 0560 now shares only that immutable evidence-record syntax for the same locked source command, with separate exact composite/record bindings and unchanged inner semantic predicates. Policy parsing, generic writers and untrusted replay remain independent. See [the nested admission contract](SOURCE-OUTBOUND-ADMISSION.md). Complete lifecycle and checkpoint validation still reconstruct canonical history independently.

## Replay and compatibility

Untrusted replay explicitly rejects either live source preparation or parsed transaction preparation, even one whose bytes would match. It independently parses NST3 and reconstructs the selected source or verifies the real durable receipt. Unrelated journal kinds, complete-state NST1/NST2 transitions and checkpoints reject parsed preparation.

Historical NST1/NST2 records and NSS1–NSS6 canonical subscriptions remain readable. The actual revision-0558 reader, the full-canonical reference build, and the forced-independent-decoding build reconstruct equal logical state from the same newly generated 128-source journal and its checkpoint, without changing their bytes. This does not expand revision 0555's previously documented NSR6 compatibility boundary.

## Measurements

The actual verified revision-0558 executable was freshly exercised, delivering 64 originals and 64 corrections, each with a 128-byte raw source payload. At source 128 it decoded NST3 twice: 1,774 bytes for ISSUE and 458 bytes for ACK. Revision 0559 decodes once: 887 and 229 bytes respectively. All 256 ordinary compact responses are checked, not only the final sample.

Both semantic passes remain present. Manual and automatic ISSUE retain one selected source-envelope construction; ACK constructs none and checks the actual receipt twice. Compact output performs no complete subscription-state encode or retained ancestry scan. A separate 58,000-byte raw source exercises a large legal transaction. Independent replay rejects 14 malformed NST3 variants with correctly recomputed outer checksums and leaves each rejected journal unchanged.

New counters distinguish NST3 parses, the outgoing composite bytes copied by that parser, selected record payload bytes decoded, parsed-preparation uses, and exact byte-binding comparisons/hashes. There are three full byte comparisons and three binding hashes, plus one initial snapshot hash at construction. The initial hash is not included in `transaction_binding_bytes_hashed`; its input length is the one encoded transaction length. The immutable parsed object also remains alive through append/application rather than ending after preflight.

These are named calling-thread work counts, not total copies, peak memory, transport bytes, allocation counts or throughput. A forced-independent-decoding build preserves source preparation while decoding NST3 twice and supplies a controlled comparison for the new copy counters. The nested outbox decoder, journal frame construction, source hashing, synchronization, default legacy response digest and complete canonical validation still do work. No latency or portable speedup is claimed.

## Boundary and negative control

The private native transaction probe executes 39 checks, including rejection of 35 changed or malformed boundaries: exact bytes at all three stages, truncation/extension, bad syntax and lengths, source/manual/automatic shape confusion, replay/checkpoint/unrelated-kind misuse, stale state/configuration/queue/journal bindings, changed actual outbox absence, and failed preflight without publication. A separate fresh preparation then succeeds without durable mutation, and unprepared replay reconstructs independently. Compile-time assertions confirm the object is neither copyable nor movable.

The new negative control removes only the exact bytes-to-decoded binding comparison. The same independently valid but different PID bytes are then incorrectly accepted in preflight, and the probe fails with `parsed transaction boundary accepted: changed-byte-preflight`. The wrapper records detection as the successful negative-control outcome; it does not call the weakened product correct. Weakened source and executables are excluded from distribution.

See [fresh validation](../validation/VALIDATION.json), [measurements](../validation/METRICS-SUMMARY.json), [testing](TESTING.md), [source preparation](SOURCE-PREPARATION.md) and [automatic eligibility](AUTOMATIC-SOURCE-ELIGIBILITY.md).
