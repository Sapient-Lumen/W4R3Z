# Build plan — after revision 0613

## Current completed boundary

Revision 0613 adds authenticated read-only reconciliation for the existing V24
owner-dispatch ledger. Exact status follows one canonical dispatch identity
through the dispatch index, V22 case, owner request record, signed offer,
envelope reverse index, attempt reservation, result, and acceptance metadata.
Inventory validates the same chain for every bounded entry before sorting and
cursor pagination.

The operations lease current accepted configuration and prove the exact
V24→V23→V22→V21 authority, route commitment, signing generations, and certificate
commitments. They return metadata only and perform no network exchange, attempt,
retry, mutation, repair, route search, fallback, export, import, forwarding, or
delivery inference.

## Next bounded construction target

Build revision 0614 as stable read-only inventory snapshots, not another attempt
or forwarding surface.

1. Add an optional exact snapshot commitment to inventory requests and return a
   canonical commitment over the current authority, accepted configuration,
   sorted validated dispatch identities, and metadata rows.
2. A first page may establish the commitment. Later pages supplying it must fail
   closed if any relevant authority, index, record, offer, envelope, attempt,
   result, or acceptance metadata changed; never combine pages from different
   observed states.
3. Preserve finite scan, row, cursor, JSON, deadline, and control-frame bounds.
   Snapshot computation must stay read-only, avoid long-lived mutation locks,
   and leave ordinary daemon progress available.
4. Treat the commitment only as observation evidence. It is not a receipt,
   acceptance, delivery claim, retry token, forwarding grant, or authority to
   disclose retained acceptance bytes.
5. Test changes between pages, lifecycle/configuration changes, malformed and
   symlinked state, restart, lost local-control responses, real-UID
   authorization, drain, bounded capacity, exact duplicate pages, and concurrent
   ordinary traffic while proving zero mutation and zero network attempts.
6. Repeat source authority, strict static and ASan/UBSan builds, focused and
   risk-adjacent suites, the complete matrix, exact predecessor reconstruction,
   frozen-source extraction, and byte-identical clean rebuilding before
   promotion.

Independent hosts, hostile physical carriers, real power interruption, formal
protocol proof, and independent security review remain later verification debt.
