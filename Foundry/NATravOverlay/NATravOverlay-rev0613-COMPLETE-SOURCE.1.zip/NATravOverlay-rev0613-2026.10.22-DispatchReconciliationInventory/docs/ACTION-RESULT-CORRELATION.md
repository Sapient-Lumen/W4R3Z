# Recipient action-result correlation — revision 0545

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

`action-result-query` correlates one received `NAC1` report with an exact retained local outbound counter request. It is observational: it does not execute an action, acknowledge the original request, materialize a view, or create an administrative receipt. The product path is C++20.

## Explicit exact selection

```sh
./node/bin/natrav-overlay action-result-query \
  --control state-a/control.sock \
  --operation RESULT_OPERATION_HEX64 \
  --request ORIGINAL_ACTION_HEX64 \
  --provider B --scope results/counter \
  --max-bytes 16384 --deadline-ms 5000
```

All four selectors are required. The result scope is an expected exact domain, not a guess inferred from payload bytes. A missing result, wrong outer provider, wrong outer scope, or wrong recipient returns `NOT_FOUND`; a missing original request is an explicit correlation failure after authorized lookup. The local protocol is control kind 31 followed by strict `ARQ1`, two digests, bounded provider/scope strings and a maximum response size. Trailing material and unknown versions are rejected. No peer protocol, configuration version, durable journal kind or schema changes.

## Read and administrative authority

Current kernel-authenticated `INSPECT`, `EVIDENCE_READ` and `EVIDENCE_PAYLOAD` are all required. The selected provider/scope must permit payload access under the existing read policy. V10 and later use exact UID/issuer/scope grants; older explicitly node-wide read semantics are not silently narrowed or broadened.

`INSPECT` alone must not unwrap evidence payloads. Payload authority alone must not inspect the local outbound registry. Domain authorization is checked before evidence lookup, so an unauthorized requested scope has the same denial whether the named record exists or not. No new class is implied by `ALL`.

The runtime's post-decode generation lease remains held through authorization, state selection and encoding. The command is observational during normal service, quiescence and draining while the control endpoint remains alive. Successful reads append no journal or successful control-audit record; existing error/denial auditing remains separate. Already authorized response bytes can finish transmitting after later policy publication.

## Checks performed

The reader requires an ordinary independently peer-authorized evidence original. Local-authored, subscribed-source-materialized and legacy unmarked records are not authenticated reports. It follows the exact retained inbound authorization configuration, re-evaluates that policy and obtains the historical provider generation/SPKI. That generation and pin must equal the original request's retained durable delivery binding. A request subsequently rebound to another key may therefore cease to correlate with an older report; no historic attempt is guessed.

The complete `NAC1` payload must commit to the outer operation ID, expected scope, exact local identity generation/SPKI at admission, original request operation and immutable record digest, and original counter amount. Strict decoding checks the 571-byte maximum, exact EOF, optional markers, nonzero identities, source/admission time agreement, attempt/latest-start consistency, outcome-dependent field presence, checked counter addition, and the executed-effect receipt digest. A reported start must respect the original requested defer duration and must not follow terminal time for any outcome, including cancellation and expiry (tightened in revision 0546). It never compares clocks on different nodes.

If the original outbound request has a durable source-admission receipt, the reported source sequence, recorder, recipient, operation and record digest must match it. If that receipt is absent, correlation can still validate the retained request and authenticated report, but the receipt stays null and the original outbox status remains unchanged. A report is not itself an acknowledgment. Result admission can arrive before the original request receipt.

Historical key acceptance is distinct from present trust. Revocation or removal does not erase an already validated admission. `current_provider_key_state` reports `ACTIVE`, `RETIRED`, `REVOKED` or `NOT_CONFIGURED` alongside the historical pin. Current local read authority is still mandatory. Historical configurations are parsed with identity-file access deferred; obsolete private paths need not exist. This validates retained provenance, not a stored TLS transcript or a fresh live handshake.

## Claims, receipts and conflicts

A successful unique exact correlation returns:

```text
status: CORRELATED
verification: AUTHENTICATED_PROVIDER_REPORT
execution_verified_locally: false
freshness: NOT_ESTABLISHED
```

It separates the original request's ordinary provider-admission receipt, the recipient's local authenticated result admission, and the provider's claimed local counter-effect receipt. Provider authorization/result-policy digests and configuration ordinals are retained claims: the recipient does not possess that remote journal and cannot independently validate them. Recomputing a reported effect hash establishes self-consistency, not truthful execution. `NAC1` carries no conditional-administration receipt; that field is null, not synthesized. Amount and before/after counters are decimal strings to preserve exact unsigned values in JSON clients. Reasons remain lengths/digests, never echoed plaintext.

The derived candidate index is keyed by exact provider, result scope and claimed original action ID. It recognizes only enough untrusted `NAC1` prefix to locate candidates; index presence never confers authentication. At most 32 retained candidates can be inspected for one query. Every matching candidate is independently revalidated under the same state observation. Two distinct individually consistent authenticated reports return `CONFLICTING_REPORTS`, `correlated: false` and no selected report body. Invalid alternatives remain stored evidence and are not treated as valid effects. Above 32 candidates the command fails with `ACTION_RESULT_SCAN_LIMIT`, not an incomplete uniqueness claim.

Conflict coverage is exactly the selected provider/scope/request domain and current original request binding. It is not cross-scope discovery, global provider equivocation detection, an unbounded search, or a permanent promise that no later report will arrive. A current `CORRELATED` observation can change after a new report. No conflict is silently resolved by preferring the first, latest or highest counter.

## Bounded work and persistence

The complete principal-annotated JSON response is limited to 2,048–16,384 bytes. A complete response that cannot fit returns `ACTION_RESULT_RESPONSE_LIMIT`; fields are not silently dropped. The selected query has one exact outbound lookup, indexed candidate lookups, at most 32 report decodes, and at most 32 distinct bounded historical-configuration parses. It copies no whole application snapshot and serializes no application logical state. These are bounds, not zero-allocation, constant-time, lock-free, or latency guarantees.

The result-candidate index and inbound-authorization configuration map are replay-derived. Memory grows with retained candidates and authorized admissions, respectively. They do not serialize into a second trusted storage authority. The normal checkpoint load path reconstructs both. Each query uses one state mutex, so historical parsing can delay writers; deadlines are checked between bounded steps, not a hard real-time preemption guarantee.

Work counters cover only the locked correlation method, excluding pre-read authorization, current-config processing outside that scope, transport, other threads and startup. They report candidate visits, bytes decoded, actual historical configurations parsed and bytes parsed, admission-binding lookups, full snapshot calls and logical serialization.

## Tested continuation and limits

The feature suite uses actual C++ counter execution, cancellation, expiry and mutual-TLS result delivery, independently encoded malformed and dishonest-provider reports, kernel UIDs, partial-request revocation, duplicate admission, a deliberately lost original receipt, historical provider revocation, exact candidate bounds, compaction, keyed audit, signed encrypted restore and relocation. Old identity files are removed after relocation; historical correlation and new result delivery continue.

The original data remains unchanged by successful correlation. Invalid reports are not removed, rewritten, imported or upgraded into local actions. Authentication cannot establish evidence truth, newest state, recipient freshness, absence of external effects, or protection after local-key/host compromise. Old valid snapshots can restore older reports or omit later conflicts; complete copied states can diverge. Tests run on one Linux kernel, not independent physical failure domains.

## Configuration example

[node-a-action-correlation.conf](../node/examples/node-a-action-correlation.conf) pairs with the existing provider example. The complete example set is validated with disposable identities during packaging; that validates grammar and identity loading, not deployment-specific trust.

## Request-centric discovery

`action-result-discover` now supplies bounded pagination beyond the exact reader's 32-total-candidate ceiling. It shares this validator without changing this command's contract. A partial scan cannot claim uniqueness; see [discovery](RESULT-DISCOVERY.md).
