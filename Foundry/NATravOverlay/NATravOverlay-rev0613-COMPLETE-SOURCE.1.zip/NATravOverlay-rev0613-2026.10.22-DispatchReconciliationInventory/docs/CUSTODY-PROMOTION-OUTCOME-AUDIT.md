# Read-only authenticated custody-promotion outcome audit

Revision 0575 adds one offline, observational command for resolving a lost
`state-head-custody-promote` response without retrying promotion:

```sh
./node/bin/natrav-overlay state-head-custody-promotion-audit \
  --record /protected-anchor/A.head \
  --expect-node A \
  --expect-domain primary-operations \
  --expect-generation 7 \
  --expect-head 'NASH1:A:...' \
  --expect-digest 64_lowercase_hex \
  --new-generation 8 \
  --state /srv/natrav/state-a \
  --state-auth-key /protected-keys/state-a-g1.key
```

The source may instead be one signed encrypted backup:

```sh
./node/bin/natrav-overlay state-head-custody-promotion-audit \
  --record /protected-anchor/A.head \
  --expect-node A \
  --expect-domain primary-operations \
  --expect-generation 7 \
  --expect-head 'NASH1:A:...' \
  --expect-digest 64_lowercase_hex \
  --new-generation 8 \
  --input /offline-backups/A.nob \
  --generation a-g1 \
  --state-auth-key /protected-keys/state-a-g1.key \
  --decrypt-key /protected-keys/backup-g1.key \
  --trusted-cert /trusted-signers/a-g1.crt \
  --require-signature yes \
  --require-encryption yes \
  --expected-backup-id 64_lowercase_hex
```

Exactly one source is required. The caller supplies the complete intended old
custody account and a strictly greater intended generation. The caller cannot
supply the derived successor selector.

## Complete source validation

The command shares revision 0574's source-authentication and successor-proof
implementation. A stopped keyed state directory is opened read-only under the
existing nonblocking exclusive state and journal locks. Its complete journal is
authenticated and semantically replayed; incomplete tails are rejected. A
signed encrypted backup is authenticated, decrypted, signature-checked against
the explicitly trusted certificate, bound to the expected node and identity
generation, and its embedded checkpoint is completely authenticated and
semantically replayed. No restore directory is created.

The source is then assessed against the exact old `NASH1` head:

- a same-epoch candidate must be a strict append extension containing the exact
  independently authenticated and semantically replayed old byte prefix;
- a representation-changing candidate must be a direct authenticated
  checkpoint successor with the required key lineage; and
- exact no-ops, stale inputs, unrelated branches, unsupported checkpoint
  transitions, wrong keys or signers, incomplete inputs, and changed source
  files are reported or rejected without publication.

Source eligibility is evidence, not a mutation instruction. The audit never
invokes the custody compare-and-swap.

## Exact intended records

The complete old account is canonicalized by deterministically re-encoding its
`NHCUST01` bytes and requiring the supplied whole-file digest to identify those
exact bytes. After source validation, the product derives the candidate
`NASH1` selector internally and deterministically constructs the exact intended
successor record from:

- the old node;
- the old custody domain;
- the caller's strictly greater intended generation; and
- the derived authenticated source head.

This prevents a record with the same node, generation, and head but a different
custody domain or canonical byte representation from being reported as the
intended winner.

## Classification

The response format is:

```text
NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_OUTCOME_AUDIT_V1
```

It returns one of four classifications:

```text
NOT_APPLIED_EXACT_OLD_RECORD
APPLIED_EXACT_DERIVED_SUCCESSOR
CURRENT_CUSTODY_DIVERGED
SOURCE_STALE_OR_DIVERGENT
```

The classification does not replace the underlying accounts. The report also
includes:

- the complete intended old canonical record;
- the intended new custody generation;
- the internally derived `NASH1` selector;
- the complete deterministic intended-successor record;
- the complete current custody record and current file identity;
- source kind, authenticated byte identity, and replay account;
- the exact successor relationship or underlying promotion ineligibility code;
- exact-old and exact-successor byte-match booleans; and
- explicit no-mutation, no-retry, no-restore, no-worker, no-receipt, and
  no-global-freshness labels.

`SOURCE_STALE_OR_DIVERGENT` takes precedence when the source cannot prove an
eligible promotion relationship. The current custody record is still returned
so the operator can distinguish source ineligibility from custody state.

## Coherent read-only boundary

The custody parent is held under a shared advisory lock. The initially opened
current record is subject to the same no-follow, owner, exact-mode, link-count,
regular-file, size, canonical-decoding, commitment, and pathname/inode rules as
other custody reads.

Before success, the command performs:

```text
source exact recheck
    ↓
current custody exact recheck
    ↓
source exact recheck
```

A source or custody pathname, inode, metadata, length, digest, or byte change
suppresses the apparent success. The source and current custody are never
modified or repaired.

## Duplicate attempts and response loss

The audit is observational. Repeating it does not retry promotion and does not
make a destructive attempt idempotent. A result of
`APPLIED_EXACT_DERIVED_SUCCESSOR` means only that the currently named custody
file is the exact deterministic result of the stated old account, intended
new generation, and derived source head. It is not proof that a particular
process response was received.

Likewise, `NOT_APPLIED_EXACT_OLD_RECORD` means the exact old canonical record is
still named at the final recheck. It is not permission to retry automatically;
the operator must decide whether the original attempt is still active or any
other process may act.

## What the audit does not do

The command does not:

- advance or replace custody;
- retry promotion;
- open a node-state writer;
- repair an incomplete tail;
- select a recovery prefix;
- restore, recover, compact, relocate, or rotate state;
- start listeners, schedulers, peers, or workers;
- accept a caller-supplied candidate selector;
- discover a custody or source path;
- grant node permission or recovery authority;
- prove response receipt or remote witnessing; or
- establish global latestness.

An old authenticated source, old custody record, and corresponding old intent
remain an authentic old evidence set. The operator remains responsible for
protecting and selecting the intended inputs.

## Compatibility

Revision 0575 adds a CLI-only offline operation and refactors the existing
successor proof into a shared read-only assessment. It changes no local-control
request kind, peer protocol, journal, authenticated header, checkpoint,
encrypted-backup format, NSS/NST encoding, application logical state,
permission class, configuration, storage schema, custody format, state-head
format, or product limit.

Revision 0574 rejects the new command as unknown. It can still read the same
state, backup, and custody records because no durable format changed.
