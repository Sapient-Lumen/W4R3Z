# Local administration contract

Current view discovery: [manager-scoped source-view inventory](SOURCE-VIEW-INVENTORY.md) exposes retained administrative summaries without changing import or read authority.

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

Kernel-authenticated local administration and reconstructable service lifecycle remain active. Revision 0534 applies the post-decode current-generation guard to every control and gives activation/rollback an explicit reauthorization handoff. See [generation-stable control contract](CONTROL-AUTHORIZATION.md).

V9/V10 add separately granted evidence reads and exact domains; V11 adds consumers; later explicit projection, authorship, source-disclosure and import classes remain separate from ALL. Their contracts below and in the linked documents remain authoritative.

## Authentication boundary

For every accepted Unix connection, the daemon calls Linux `getsockopt(SOL_SOCKET, SO_PEERCRED)` **before reading the framed request**. The resulting numeric UID, GID, and PID are fixed by the kernel at connection time.

The node does not:

- trust a UID sent in application bytes;
- resolve user or group names;
- infer authority from supplementary groups;
- apply UID ranges, prefixes, or wildcards;
- fall back to filesystem mode as the authorization decision.

Filesystem permissions remain a separate earlier access boundary. The daemon creates the state directory as `0700` and the control socket as `0600`. A delegated UID cannot reach that socket unless deployment deliberately provides traversal/socket access. The V8 policy then decides what that connected UID may do.

## V8 policy

`NATRAV_OVERLAY_CONFIG_V8` requires one or more exact grants:

```text
local_control=1000,ALL
local_control=1001,INSPECT,SUBMIT
local_control=1002,MAINTENANCE
```

At most 64 UIDs may be listed. Duplicate UIDs or duplicate classes are rejected. The canonical policy is sorted by UID and has a stable SHA-256 digest independent of input order.

| Class | Bound commands |
|---|---|
| `INSPECT` | `status`, `outbox-query` |
| `SUBMIT` | `submit`, `revise` |
| `ACTION` | `action-submit`, `action-cancel` |
| `MAINTENANCE` | `wake`, `compact`, `rebind`, `retry`, outbound `cancel` |
| `CONFIGURATION` | `config-activate`, `config-rollback` |
| `SHUTDOWN` | `quiesce`, `resume`, `drain-shutdown`, `shutdown` |

`ALL` is an explicit shorthand for all six classes. It is not a wildcard UID.

V6 and V7 remain explicit compatibility formats. They synthesize an exact `ALL` grant for the effective startup UID. They use `SO_PEERCRED`, but their policy and lifecycle do not become new durable logical state; durable administration provenance begins with V8.

## Decision order

The running control path is:

```text
accept Unix connection
→ SO_PEERCRED
→ exact UID membership
→ bounded frame read
→ strict NOC1 decode
→ current accepted configuration lease
→ command-class authorization
→ lifecycle admission gate
→ durable authorization account for mutation
→ command execution
→ NOR1 response
```

Configuration activation/rollback release that shared lease, reauthorize after serialization and again under exclusive publication, and audit the actual predecessor generation. Ordinary mutations retain their generation through execution; observational status captures the authorized configuration and stable registry pointers, then releases the gate before narrow state observation. Full logical hashing is now explicitly requested; see [runtime status](RUNTIME-STATUS.md).

An unlisted UID is rejected before frame read. A listed UID without the command class is rejected before dispatch. Malformed material from a listed UID is rejected without retaining the payload.

## Provenance

V8 records accepted mutating requests and denied requests with:

- stable request digest, or a synthetic pre-decode identifier when no valid request exists;
- numeric UID, GID, and PID observed by the kernel;
- command and command class;
- accepted configuration-event ordinal;
- decision time;
- `AUTHORIZED` or `DENIED`;
- typed denial code when applicable.

Request payloads, evidence payloads, candidate file contents, and private-key paths are not copied into denial accounts.

Successful `status` is intentionally observational. It advances only current-run counters and does not append a journal record or alter the logical-state digest. A denied read is a security event and is durable in V8.

## Lifecycle

### `RUNNING`

Local mutations, local submissions, and peer admissions are accepted subject to their ordinary policies. Durable outbound delivery and action execution run.

### `QUIESCED`

New local mutations are rejected with `SERVICE_QUIESCED`, except lifecycle commands and immediate shutdown. `status` remains available. Inbound peer admission, durable outbound delivery, and already admitted actions continue.

A V8 quiesce is durable. Ordinary shutdown and restart preserve it until an authorized `resume` event.

### `DRAINING`

New local mutations and new peer application admission are stopped. Already durable outbound records and actions continue. The daemon waits until:

- pending outbound count is zero;
- pending action count is zero;
- the peer-connection queue is empty;
- active peer handlers are zero;

or until the caller's bounded deadline expires. It appends `DRAIN_COMPLETED` or `DRAIN_DEADLINE`, responds with the remainder account, and exits.

A normal terminal drain restarts in `RUNNING`. A hard kill after durable `DRAIN_STARTED` but before a terminal drain record reconstructs as `QUIESCED` with `interrupted_drain=true`; it never silently reopens mutation admission.

## Health and readiness

`NATRAV_OVERLAY_RUNTIME_STATUS_V11` separates:

- process live;
- state owned;
- ready;
- local mutations accepted;
- local submissions accepted;
- peer admissions accepted;
- quiesced;
- draining;
- interrupted drain.

This is an operational account, not an external uptime or availability guarantee.

## Offline commands

`inspect`, `backup-export`, `backup-verify`, `backup-restore`, and `state-relocate` do not travel through the running control socket. They are therefore outside the V8 `SO_PEERCRED` command classes. Their boundary is exclusive state locking, effective-user ownership, restrictive modes, no-follow path checks, trusted certificates/keys where applicable, strict parsing, and no-overwrite publication.

A later revision may add an explicit offline principal/ACL model. The current product does not pretend these commands are covered by the daemon's socket policy.


## Keyed storage beneath administration

Under `run --state-auth-key FILE`, accepted V8 local-principal decisions, configuration events and lifecycle events use the same authenticated append path as application events. Local clients do not receive or send the state key; the daemon loaded it at startup. `state-auth-migrate` and `state-auth-rotate` are explicit offline owner operations, not Unix control commands, and retain effective UID/time/reason in authenticated transition history. They require exclusive state ownership and separate key custody. This does not extend SO_PEERCRED to offline commands or defend against another process compromising the daemon UID.

## Early refusal on the client

An unlisted UID can be rejected before the client finishes writing its frame. If that write closes early, the native control client reads only within its original bounds and may return an already queued complete negative response from the same socket. It never retries a partial command or treats a success response after failed transmission as success. Incomplete or malformed replies preserve the original write failure. The cross-UID regression exercises a 60,000-byte submission with one-byte writes and requires the typed UID denial, not a timing-dependent broken pipe.

## Incremental reads

The nonmutating `evidence-feed` command uses EVIDENCE_READ, plus EVIDENCE_PAYLOAD for prefixes, and requires V10 exact domains. Like evidence-query it reauthorizes after request decoding under a stable current configuration. It is admitted as inspection while quiesced or draining; successful polling does not append control decision records. See [Evidence feed](EVIDENCE-FEED.md).

## Projection command class (V12)

PROJECTION is explicit and requires CONSUMER plus EVIDENCE_READ. It gates create/process/status for the caller's exact UID namespace. Rebuild also requires CONSUMER_ADMIN. Generic consumer-read/status cannot bypass the grant on a projected consumer. A stored result never grants read permission. Quiesce/drain deny new processing/creation/rebuild and issuance while allowing authorized status. See [projections](PROJECTIONS.md).

## Numeric projections (0511)

PROJECTION is necessary but not sufficient to interpret payloads. Numeric consumers fix payload mode and require current exact PAYLOAD read authority on create/read/process/status/rebuild, including generic consumer routes. Revoked payload grants cannot expose saved sums. Metadata DOMAIN_SUMMARY_V1 remains metadata-only. No new command class or automatic owner grant is introduced. See [numeric authorization](NUMERIC-PROJECTIONS.md).

## Automatic execution (0512)

Schedule controls belong to CONSUMER_ADMIN for the actual UID's own projection. Enable additionally rechecks CONSUMER, PROJECTION and exact evidence authority; status/pause do not disclose results. Automatic work identifies the actual daemon executor under the stored grant, not an absent kernel client. Quiesce/drain serialize with a bounded step and suspend future automatic work; projection backlog is not part of drain completion. [Contract](AUTOMATIC-PROJECTIONS.md).

## Revision 0513 — retirement

`consumer-retire` is an exact-owner CONSUMER_ADMIN mutation; `consumer-retirement-status` is its observational administrative view. Both are reauthorized against the accepted configuration after decoding. Retirement follows quiesce/drain mutation restrictions. Results/payloads are not disclosed through the administrative view. [Command contract](CONSUMER-RETIREMENT.md).

## V15 source disclosure administration

SOURCE_DISCLOSE is an explicit exact-UID class, not part of ALL. The source-subscription controls reauthorize after request decoding under one accepted configuration. Create/step require a matching current disclosure grant; status/retirement require ownership and the class but may operate after the data grant is removed. No manager UID is inferred from a remote peer. Mutations obey quiesce/drain; status remains observational. See [source subscriptions](SOURCE-SUBSCRIPTIONS.md).

Terminal receipt reconciliation is also provider-local and uses current kernel-owner `SOURCE_DISCLOSE` plus the exact retained grant/key policy. It is a mutating control operation subject to quiesce/drain. It neither impersonates a remote subscriber nor confers evidence-read access; its receipt is selected from durable outbox state, not supplied as proof by the client. See [reconciliation](TERMINAL-RECONCILIATION.md).

## Revision 0528 administrative review

[Import decision review and selective retry](IMPORT-DECISIONS.md) add bounded administrative pages and an exact one-source reconsideration command under existing V17 SOURCE_IMPORT authority. New NIR2 requests and NIE2/NSV3 state retain explicit local-manager provenance. Earlier durable encodings remain readable; no new read permission, peer protocol or configuration version is implied.

## Recipient-view terminal lifecycle

`source-view-retire` is a SOURCE_IMPORT mutation and obeys quiesce/drain admission gates. `source-view-retirement-status` is observational. Both require the exact historically accepted view manager and current class; retirement grants no payload-read permission. See [recipient-view lifecycle](VIEW-RETIREMENT.md).

## Exact outbox metadata inspection (0530)

`outbox-query` is node-wide administrative metadata inspection under current INSPECT authority after decoding. It adds no payload grant and remains available in quiesce/drain. Successful/empty queries append no audit record. Continuations are reauthorized and bound to UID/configuration/selection; bounded bytes may finish transmission after authorization is released. See [outbox contract](OUTBOX-INSPECTION.md).

## Conditional outbox administration (revision 0531)

Paired `--expected-state` and `--expected-configuration` options select the local `OCA1` request (control kind 24) for cancel/retry/rebind. It requires current `MAINTENANCE`, not merely `INSPECT`, and V8-or-later durable local policy. Successful action provenance is included atomically in its own journal transition; exact repeat confirmations add no successful event. Denial auditing and lifecycle restrictions remain. See [conditional outbox](CONDITIONAL-OUTBOX.md).

## Retained configuration inspection (0538)

[configuration-history](CONFIGURATION-HISTORY.md) supplies exact event/binding lookup and bounded retained-prefix pages under current INSPECT. It omits canonical contents, reason text and relocation paths while preserving their commitments. Prefix selection does not grant authority or establish freshness. Runtime-bound mutation bindings are an explicitly described subset, not the entire effect or local-control audit log. Local request kind 27 (NHC1) introduces no new persistent encoding or peer protocol.

## Actual retained control accounts (0539)

[control-history](CONTROL-HISTORY.md) exposes decisions and lifecycle transitions under current INSPECT. Historical UID/GID/PID and request identity are reported as stored; lifecycle GID is absent. AUTHORIZED is not effect completion and repeated request bytes can yield repeated IDs. Successful pages remain journal-free, including during quiescence and drain.

Complete action metadata beyond the status preview is available through [action-query](ACTION-INSPECTION.md). It preserves current INSPECT and does not infer execution from control authorization.

Recipient-side `action-result-query` now provides explicit observational NAC1/request correlation under INSPECT plus result-payload read authority. It never conflates remote claims with local effects. See [correlation contract](ACTION-RESULT-CORRELATION.md).

## Review-history inspection (0548)

`action-result-review-history` requires the current connected UID's `INSPECT`, `EVIDENCE_READ`, and `EVIDENCE_PAYLOAD` authority for the selected provider/scope. It does not require `MAINTENANCE`, does not inspect another owner, and remains observational during quiescence/drain while the endpoint lives. Historical actors remain distinct from the current inspector. [Contract](REVIEW-HISTORY.md).


## Revision 0553 binding inspection

The read-only [source-view-bindings API](VIEW-BINDINGS.md) exposes complete current and retained pins for one exact manager-owned view. Current SOURCE_IMPORT is required; no payload permission, import eligibility, provider consent or lease validity is inferred. New first-acceptance indexes are derived through validated replay. Existing configuration and storage representations are unchanged.


## Revision 0566: optional terminal handoff

An explicitly requested `--final-state-head yes` on shutdown or drain-shutdown defers the reply until all writer joins and final lifecycle accounting. It requires both SHUTDOWN and current INSPECT and does not turn a live sample into a terminal one. The exact NASH1 selector and external-custody limits are unchanged. [Terminal contract](TERMINAL-STATE-HEAD.md).

## Response-loss-independent stopping (0567)

For the existing default NOC1 kinds 4 (`shutdown`) and 14 (`drain-shutdown`), successful response delivery is not part of stop acceptance. Immediate stop intent becomes irrevocable only after `SHUTDOWN_REQUESTED` is durably appended and live mode is published as `DRAINING`. Drain stop intent becomes irrevocable only after `DRAIN_COMPLETED` or `DRAIN_DEADLINE` is durably appended. A later Unix-socket reset or failed response write increments the ordinary control-error account but cannot clear the accepted stop.

This does not make an incomplete connection authoritative. Strict decoding, actual `SO_PEERCRED` UID, current `SHUTDOWN`, lifecycle admission and durable publication all precede stop intent. Malformed, partial, unauthorized, post-decode-revoked and pre-publication failed requests remain non-stops. A response-lost deadline drain retains pending outbound and action obligations exactly. Transport loss is ambiguous to the caller and is not a rejection receipt; establish process exit or inspect stopped authenticated state before deciding what occurred. See [response-loss-independent stopping](RESPONSE-LOSS-INDEPENDENT-STOPPING.md).

## Correlated destructive stopping (0568)

A caller may add `--correlation TOKEN` to `shutdown` or `drain-shutdown`. The token is canonical lowercase ASCII, 1–64 bytes, and uses only alphanumerics plus `.`, `_`, and `-`, with alphanumeric edges. It selects new strict NOC1 kind 44 for immediate shutdown or kind 45 for draining shutdown. Kinds 4/14 remain unchanged when the option is absent.

The exact token-bearing request bytes feed the existing `NATRAV_OVERLAY_CONTROL_REQUEST_ID_V1` calculation. That request ID is already recorded in the authorized control decision and lifecycle event. The token itself is not copied into journal history. After response loss, an operator can independently derive the ID and use bounded `control-history --section lifecycle --request-id ...` under current `INSPECT` to identify matching rows. [Encoding and derivation](CORRELATED-STOPPING.md).

Correlation does not grant `SHUTDOWN`, suppress duplicate attempts, make retries idempotent, prove reply receipt, establish freshness, or update an external expectation. Identical request bytes deliberately select multiple independently authorized history rows. With `--final-state-head yes`, separate kinds 46/47 preserve the terminal protocol's additional current and final `INSPECT` checks, writer joins, sealing, and exact authenticated-head sampling. [Correlated terminal contract](CORRELATED-TERMINAL-STATE-HEAD.md).

## Correlated terminal authenticated-head handoff (0569)

Combining `--correlation TOKEN` with `--final-state-head yes` selects strict NOC1 kind 46 for immediate shutdown or kind 47 for draining shutdown. The exact token-bearing bytes feed the ordinary request-ID calculation, while the deferred coordinator path still requires current `SHUTDOWN` plus `INSPECT`, rechecks `INSPECT` after all writers join, completes final drain accounting, seals the process state, and samples the exact `NASH1` head.

The response echoes the token only as `PROVENANCE_ONLY_NOT_IDEMPOTENCY_OR_RECEIPT`. Durable history stores the request ID, not token text. Response loss cannot cancel an accepted stop and cannot prove receipt. Duplicate exact requests remain multiple independently authorized attempts under one ID. See [the complete correlated terminal contract](CORRELATED-TERMINAL-STATE-HEAD.md).

## Offline correlated-stop handoff audit (0570)

`correlated-stop-audit` is deliberately outside the running local-control plane. It accepts an existing state directory, node ID, and explicit state-authentication key, obtains exclusive ownership of the existing state files, and performs complete authenticated semantic replay in memory. It opens no control socket, creates no writer, starts no worker, and consults no caller-supplied UID.

The offline authority boundary is therefore possession of the protected state representation and its separately managed authentication key—not a current online permission grant. The resulting token or request ID does not grant `SHUTDOWN`, `INSPECT`, recovery, or any other command class. The report is bounded and redacted; see [the complete contract](OFFLINE-CORRELATED-STOP-AUDIT.md).
