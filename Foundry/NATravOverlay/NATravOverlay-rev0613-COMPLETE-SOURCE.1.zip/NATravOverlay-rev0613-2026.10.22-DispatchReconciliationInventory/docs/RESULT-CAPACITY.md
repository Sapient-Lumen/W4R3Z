# Reserved action-result capacity — revision 0544

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

New V18 counter-action admissions reserve one future result record and a fixed maximum NAC1 payload allowance. The admission, immutable result-disclosure binding and reservation are one journal record. An action is not admitted if its future result would exceed the executing node's current global or recipient limits.

This is queue governance, not disk preallocation. It does not reserve journal file bytes, memory, physical storage, a network connection, or recipient admission. The existing action execution budget remains independent.

## Two kinds of outstanding obligation

The derived accounts are separate:

```text
pending_records / pending_payload_bytes
    actual PENDING outbound evidence records
future_result_records / future_result_payload_bytes
    admitted PENDING actions with a reserved but not yet produced result
committed_records / committed_payload_bytes
    sum of those two accounts
```

All normal enqueue and rejection-reopening retry/rebind capacity checks use combined totals globally and for the exact recipient. Zero-byte pending evidence occupies a record. A delayed or already begun action retains its future reservation. Route removal, key retirement or revocation, restart, receipt of unrelated evidence, and compaction cannot release it.

The future index contains action identities and scalar contributions, not a second payload or result. It is updated and reconstructed by the ordinary semantic decoder. No aggregate is an independently trusted persisted counter.

Status, offline inspection and per-peer status distinguish actual pending work and future results. No fabricated outbox row or operation ID exists before terminalization. `action-query` reports the binding's `reserved_payload_bytes` and `capacity_state` (`RESERVED`, `CONVERTED`, or `LEGACY_UNRESERVED`).

## Canonical bounded reservation

The maximum NAC1 representation is the executed result, with latest-start time, effect receipt, and both counter values present. Its exact maximum payload length is:

```text
379 + result_scope byte length + recipient_generation byte length
```

At the accepted 128-byte scope and 64-byte generation maxima this is **571 bytes**. It covers NAC1 payload bytes, not outer NOA1 framing, TLS/TCP traffic, or journal framing. Free-form reasons are represented by a fixed digest and bounded length, not copied text.

For `results/counter` and generation `a-g1`, the bound is 398 bytes. An unbegun cancelled result uses 342 bytes and returns the 56-byte surplus at conversion. The independent wire test verifies both values and the 571-byte maximum.

The reservation does not grant disclosure authority. A matching accepted V18 action-result rule and exact authenticated action issuer remain mandatory. The new field must match the format-derived bound on replay; it is not a caller-selected larger allowance.

## Atomic conversion

For a reserved action, ordinary completion, cancellation or expiry uses its existing synchronized `NAT1` result transaction. Capacity validation credits only the exact pending action's matching reservation. The transaction terminalizes the action, removes its future contribution and queues the actual immutable result with its initial delivery policy under one state lock and one durable record.

The committed record count is unchanged; bytes decrease by any deterministic unused allowance. No other action's reservation may be borrowed. A full ordinary queue cannot consume capacity promised to admitted reserved actions.

Once queued, the result follows ordinary delivery semantics. Receipt, authenticated rejection, cancellation or expiry releases its actual pending reservation; it never revives the future reservation or undoes the local counter effect. Explicit retry of a rejected result must reacquire current ordinary quota. No action, source, publication or scheduling budget is replenished.

## Conditional cancellation

Existing `action-cancel --expected-state HEX64 --expected-configuration HEX64` now accepts result-bound actions. Current kernel `ACTION` permission, the accepted configuration guard, and the action-transition mutex remain required. Fresh inspection conditions cover the full result binding, reserved capacity, current action/attempt state and preceding administrative receipt.

One kind-36 `AAT2` record contains the existing `AAT1` administrative receipt and the exact `NAT1` cancellation/result conversion. Semantic replay derives both before applying either. Detaching the result, changing its binding, altering the selected state, or presenting an undersized reservation fails closed.

A success returns `APPLIED`. An exact same-UID retry under current authority returns `ALREADY_APPLIED` with the original receipt and a current bounded observation, including the same result operation. Receipt arrival does not repeat cancellation. A changed configuration or action before first commit produces the existing typed conflict. Already executed, cancelled and expired actions remain terminal even with fresh selectors.

The selected metadata uses `ACM2` only for result-bound actions; legacy action metadata remains `ACM1`. No condition flag or permission changed. Reasons remain locally attributable; remote NAC1 contains only reason length and digest.

## Immutable result recipient key

An admitted result's exact generation and SPKI are part of its canonical payload and accepted disclosure authority. Generic and conditional outbox `rebind` now refuse action-result operations with `OUTBOUND_ACTION_RESULT_BOUND`. Explicit same-binding retry after rejection remains available.

The preceding implementation could accept such a rebind then reject its own state at checkpoint validation. The new restriction closes that inconsistent path. A reservation survives rotation, but delivery under a revoked or removed old key can remain unresolved. Result-specific key migration is not implemented; permission for a replacement identity cannot be inferred from a new active key.

New reserved results bind this restriction as bit 8 of conditional outbox selection. Legacy unreserved result selections retain their earlier digest representation; their live rebind path is nevertheless forbidden. A predecessor journal that already contains an invalid result-key rebind is not silently repaired.

## Storage and compatibility

New reserved admissions use authorized-inbound action marker **3**, followed by the existing binding and one unsigned 64-bit reservation field. Marker 2 remains the old unreserved V18 encoding. V6–V17 local-only actions are unchanged.

Checkpoint extension **NRA2** carries explicit bounds when any reserved binding is present; an all-unreserved history retains **NRA1**. Mixed state can retain zero for genuine legacy bindings. Checkpoint replay rederives pending reservations from actions and validates every terminal result and policy. The new aggregate itself is not stored.

Existing legacy V18 admissions are **not retroactively charged or upgraded**. They retain safe ordinary-capacity waiting behavior. Their conditional cancellation now works when actual free quota exists, but gets no invented conversion credit. A fixture independently removes the new field and uses marker 2 to exercise this compatibility path through restart and compaction.

No configuration version, peer protocol, NAC1 bytes, journal kind or storage-schema number changes. Old executables reject new markers/extensions rather than discard their meaning. An action must use the same newer implementation after new state is written.

## Recovery and limits

Pre/post-synchronization SIGKILL tests establish that conditional receipt, cancellation, reservation conversion and result operation recover together. Keyed authentication audit, compaction, signed encrypted backup, restore and explicit relocation preserve both still-reserved actions and queued results. Full logical-state equality is checked at the offline restore boundary.

These do not prove physical power-loss behavior across arbitrary filesystems. Journal-capacity exhaustion, I/O failure and allocation failure remain possible. A reserved result is not guaranteed remote acceptance or eventual delivery; it protects queue capacity, not route/key availability. The single counter worker and existing locks remain. Verification/replay and result-policy reconstruction have history-dependent costs.

A valid old backup can restore older allowances and state, and copied nodes can diverge. No freshness anchor, host-compromise defense or distributed lease is added. Local effect receipts, administrative receipts and remote evidence-admission receipts remain three separate facts.

See [action results](ACTION-RESULTS.md), [conditional action administration](ACTION-ADMINISTRATION.md), [pending capacity](PENDING-CAPACITY.md), [validation](../validation/VALIDATION.json), and [attempts](../validation/ATTEMPTS.md).

Recipient-side `action-result-query` now provides explicit observational NAC1/request correlation under INSPECT plus result-payload read authority. It never conflates remote claims with local effects. See [correlation contract](ACTION-RESULT-CORRELATION.md).
