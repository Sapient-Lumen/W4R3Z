# External authenticated-state expectations — revision 0564

## Contract and trust boundary

`--expected-state-head NASH1:...` is an optional exact-input condition, supplied on the command line independently of the state being opened. It binds node ID, state-authentication generation and key ID, epoch, final authenticated chain root, authenticated record count, and physical journal/checkpoint byte length. It is not a key, signed assertion, authorization, latest-head service, recovery selection, or claim about time.

The normal state key is still mandatory. Complete authentication and ordinary semantic replay precede matching. A matching token cannot legalize an invalid record, skip receipt checks, bypass configuration or permissions, adopt unkeyed state, or repair a truncated journal. An exact token is accepted only for the representation to which it refers. A valid older, newer, differently compacted, rotated, recovered, or divergent representation is not an exact match.

The caller must select and protect the expectation separately from rollbackable state and backups. The program cannot verify that custody. Reading a head from the state currently under suspicion and immediately passing it back adds no rollback assurance. **An old token plus the corresponding old authenticated state still matches.** The tests demonstrate that boundary explicitly.

There is no product-managed anchor, clock, automatic update, implicit configuration field, remote witness, or environmental fallback. Revision 0572 adds an explicitly named detached record, but the operator—not the node—creates, protects, selects, and advances it. The token is non-secret but includes public node/key-generation identifiers and commitments; ordinary command-line visibility applies. State-key custody and trusted executable/launch policy remain necessary.

## Exact selector grammar

The selector is at most 512 ASCII bytes and has exactly eight colon-separated fields:

```text
NASH1:<node>:<generation>:<key_id>:<epoch>:<root>:<records>:<journal_bytes>
```

Node and generation use the existing 1–64-character ID grammars. The three hashes are exactly 64 lowercase hexadecimal characters and may not be all zero. Counts are positive canonical decimal integers, each at most 1,073,741,824; leading zeroes, signs, whitespace, and overflow are rejected. Actual journal limits and strict authentication constrain the representation further. Unknown versions, empty or extra fields, malformed hashes, and noncanonical numbers fail `STATE_HEAD_EXPECTATION_INVALID` before opening state. Missing `--state-auth-key` fails `STATE_AUTH_KEY_REQUIRED`.

The token does not contain its own MAC. The root is obtained only from the normal authenticated journal chain; matching is not used to authenticate unverified input. Binding the epoch and active key account prevents conflating representations or generations. Exact root binding distinguishes valid equal-length, equal-count branches of the same epoch.

## Obtaining and supplying an expectation

A successful keyed offline inspection or complete keyed audit returns a `state_head` account. An audit avoids a complete application payload listing:

```sh
./node/bin/natrav-overlay state-auth-audit \
  --state state-a --node A --state-auth-key /private-keys/state-g1.key
```

Record its `state_head.selector` through a separately protected operator procedure. The product does not write that record. For a later open, a shell can read a previously selected one-line token from separately managed storage:

```sh
read -r EXPECTED < /separate-anchor-store/A.head
./node/bin/natrav-overlay inspect \
  --state state-a --node A --state-auth-key /private-keys/state-g1.key \
  --expected-state-head "$EXPECTED"

./node/bin/natrav-overlay run --config node-a.conf \
  --state-auth-key /private-keys/state-g1.key \
  --expected-state-head "$EXPECTED"
```

These paths are illustrative. Neither a filename nor an environment variable is automatically interpreted as an expectation by the product. Reading a local file from the same rollback domain is not protected custody.

The new account is explicitly versioned:

```json
{
  "format": "NATRAV_OVERLAY_STATE_HEAD_V1",
  "selector": "NASH1:...",
  "expectation": "MATCH",
  "freshness": "MATCHED_SUPPLIED_EXPECTATION",
  "trust": "CALLER_MUST_PROTECT_EXPECTATION_SEPARATELY",
  "automatic_update": false
}
```

`MATCHED_SUPPLIED_EXPECTATION` means only equality to the caller's supplied expectation for that exact checked representation. It does not mean the system proved the expectation was the latest independently observed head. Without an expectation the account reports `NOT_SUPPLIED` and `NOT_ESTABLISHED`. An unauthenticated state has a null selector. Newly produced output heads use `NOT_CHECKED_HERE` and `NOT_ESTABLISHED`; the input expectation is not relabeled as an expectation of the output.

The older `state_authentication.freshness` field remains `NOT_ESTABLISHED`, because chain authentication by itself establishes no freshness. Unrelated inventory, source-state, and result selectors are unchanged.

## Command scopes

| Command | Exact input compared | Result boundary |
|---|---|---|
| `run`, `serve`, `offer`, `correct`, `flush`, `inspect` | Existing complete authenticated state under the normal exclusive state lock | Comparison occurs after complete semantic replay and before command-driven mutation. |
| `backup-export` | Complete source state | The exported authenticated checkpoint has a new head; it is returned separately, not self-anchored. |
| `backup-verify`, `backup-reencrypt`, `backup-restore` | Exact authenticated checkpoint embedded in the backup | Normal signature/encryption requirements and semantic checkpoint validation still apply. Mismatch occurs before output publication or restore staging. |
| `state-relocate` | Complete source state before accepted relocation configuration | Input and resulting heads are separate. Existing relocation permission/path/identity checks remain. |
| `state-auth-rotate` | Complete old-key state | The new key/epoch head is returned without silently updating the expectation. |
| `state-auth-audit` | Complete source, or explicitly labeled maximal verified prefix for incomplete/invalid tails | Audit remains observational; invalid/incomplete input never becomes a complete successful audit. |
| `state-auth-recover` | Maximal authenticated and semantically valid selected prefix | All existing source digest, root/count/byte selection, incomplete-tail-only policy, reason, preservation, and publication checks remain. |

The option is rejected on other commands, including migration from unkeyed state and local control commands. The old audit `--expected-root` / `--expected-records` alternative remains supported; combining it with the new typed selector is rejected.

### Startup and mutation

This is a **per-open precondition**, not a continuous compare-and-swap condition on every future daemon append. A successfully opened daemon may execute normally authorized work, compact, and advance its journal. The supplied expectation never advances with it. Restart against the same old selector fails once the representation has changed. There is no new permission class or ability to invoke control actions.

A mismatching open does not clean a stale compaction candidate first. Existing candidate cleanup occurs only after the expected state has been replayed and matched. Stable lock acquisition and normal protected path checks remain. Normal no-expectation startup retains its previous behavior.

### Backup representation and restore

A source-state head is not the head of an exported checkpoint, even when application logical state agrees. Supply the exported checkpoint selector to backup verification/restore. Signature or encrypted-envelope rewrapping does not change the embedded checkpoint, so its selector survives `backup-reencrypt`. Restoring appends ordinary restore provenance to the checkpoint; the returned `restored_state_head` identifies that resulting journal. It is not silently substituted for the input pin.

### Compaction, rotation, relocation, and recovery

These operations can produce a new epoch, root, count, or byte length. Old selectors then fail exact matching; logical equality alone is insufficient. Obtain and deliberately protect the new resulting selector for subsequent opens. Old authentication keys and old snapshots do not match a new-generation expectation.

Normal startup rejects a plausible incomplete final record even when the maximal prefix matches the expectation. Audit reports `VERIFIED_PREFIX_ONLY`; its overall freshness stays `NOT_ESTABLISHED`. Recovery still needs all explicit selection and custody arguments. A correct prefix selector cannot authorize dropping complete invalid records, select an earlier prefix, suppress source preservation, or replace source-digest validation. A recovered checkpoint has a newly reported, unanchored head.

## Implementation boundaries

The expectation is parsed and configured once at process entry before workers start. It is immutable thereafter and is not placed in `NodeState`'s canonical state. Disk state opens enforce it after `load_journal`; in-memory candidate/checkpoint reconstruction does not inherit an input-state comparison. Backup readers enforce the expectation explicitly after strict checkpoint validation. Recovery enforces it against the selected verified prefix before preserving or publishing output.

No journal, NSS/NST, authenticated header, checkpoint, backup, peer-envelope, logical-state, storage-schema, permission, configuration, or size-limit encoding changes. New CLI and observational JSON fields are the compatibility boundary. A predecessor executable rejects the unknown option rather than ignoring it.

## Evidence and remaining limits

The independent Python suite reconstructs selectors from raw authenticated bytes, exercises all seven bound accounts and 29 malformed selectors, creates valid equal-size same-epoch divergent histories, tests old and later heads, supplies a correctly MACed but semantically invalid duplicate record, and covers startup, live compaction, key rotation, prefix recovery, signed encrypted backup, re-encryption, restore, and relocation. The precise completed profiles are in [validation](../validation/VALIDATION.json).

A narrow diagnostic mutation removes only the expected-root comparison. The equal-length divergence case must then fail because the weakened program accepts the wrong branch. Alternate binaries, generated keys, state, and identities are never included in the package.

No physical-host independence, power-cut guarantee, trusted clock, external anchor service, credential isolation from the same UID, complete cryptographic audit, or portable static-linkage guarantee is claimed. This increment closes an exact external-input check, not all deployment or freshness assurance. See [state authentication](STATE-AUTHENTICATION.md), [authenticated recovery](AUTHENTICATED-RECOVERY.md), and [encrypted backups](ENCRYPTED-BACKUPS.md).

## Live observation added in revision 0565

The dedicated [`state-head` control](LIVE-STATE-HEAD.md) obtains a bounded live NASH1 sample under current INSPECT authority without opening state offline. It keeps actual startup matching separate from current sampling; live freshness remains `NOT_ESTABLISHED`. It neither reads a new caller expectation nor updates one.


## Revision 0566: optional terminal handoff

An explicitly requested `--final-state-head yes` on shutdown or drain-shutdown defers the reply until all writer joins and final lifecycle accounting. It requires both SHUTDOWN and current INSPECT and does not turn a live sample into a terminal one. The exact NASH1 selector and external-custody limits are unchanged. [Terminal contract](TERMINAL-STATE-HEAD.md).

## Detached-record input adapter (0573)

Revision 0573 accepts one explicit detached custody record as an alternative to
copying its selector into `--expected-state-head`. The complete group is:

```text
--expected-state-head-custody FILE
--expected-custody-domain LABEL
--expected-custody-generation N
--expected-custody-digest HEX64
```

The record is verified under the revision-0572 no-follow, ownership, exact-mode,
link-count, canonical-decoding, and exact-file-identity rules. Only its exact
selector is passed to the existing expectation matcher. Raw and detached
alternatives cannot be mixed, and a failed custody comparison never falls back
to an unconditioned open.

The adapter does not change this document's freshness boundary. An old record
paired with its old authentic state still matches. See
[Custody-constrained state opening](CUSTODY-CONSTRAINED-STATE-OPENING.md).
