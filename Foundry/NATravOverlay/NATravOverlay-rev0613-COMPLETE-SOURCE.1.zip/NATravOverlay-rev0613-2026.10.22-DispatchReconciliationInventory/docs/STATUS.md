# NATravOverlay status — revision 0613

Recorded state: **PASS — promoted verified release**.

Revision 0613 adds authenticated, read-only owner reconciliation for durable V24
custody-dispatch records. Exact status names one activation and dispatch request.
Inventory scans and validates the existing finite dispatch index, sorts canonical
identities lexicographically, and returns cursor-bounded metadata pages. Both
operations prove the current V24→V23→V22→V21 authority chain and exact retained
index, dispatch record, signed offer, custody envelope, attempt, result, and
acceptance bindings.

The observation path performs no network I/O, attempt, retry, filesystem
mutation, index repair, route discovery, fallback, export, import, forwarding,
or delivery inference. ACTIVE, RETIRED, expired, and REVOKED authority remain
observable as metadata; revocation never replays acceptance bytes.

Observed promotion gates:

- Source authority: **162/162 checks passed** (30 native session, 33 passive receiver, 38 owner dispatch, 61 reconciliation).
- Focused static custody matrix: **39/39 cases**, 6,671 assertions and 456 commands.
- Focused ASan/UBSan custody matrix: **39/39 cases**, 6,669 assertions and 454 commands.
- Risk-adjacent static matrix: **13 suites, 84/84 cases**, 19,736 assertions and 1,295 commands.
- Complete registered matrix: **103 suites, 720/720 cases**, 512,094 assertions and 20,158 commands.

The tested executable is the single static x86-64 ELF at
`node/bin/natrav-overlay`, size 15,501,344 bytes, SHA-256
`8a21b2d93ea1fae9a516e01cec3e811f287cc63f50da1cb3ea13457c0f0a616e`, and
Build ID `0434b2897002f4a03b0fbdcb66b94c3083467b11`. Frozen-source extraction,
manifest verification, byte-identical clean rebuilding, exact predecessor
reconstruction, canonical two-file ZIP read-back, and delivery checks are
recorded in the external evidence.

All observed builds and tests are local to one host/toolchain family.
Deterministic SIGKILL boundaries do not establish physical storage behavior
under abrupt power loss. No independent-host reproduction, hostile physical
carrier, independent security audit, formal protocol proof, or production
operational certification is claimed.
