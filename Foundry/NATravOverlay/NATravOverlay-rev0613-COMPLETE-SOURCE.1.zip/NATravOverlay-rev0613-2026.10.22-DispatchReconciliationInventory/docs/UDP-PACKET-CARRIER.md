# Numeric point-to-point UDP packet carrier

## Scope

Revision 0584 adds one explicitly configured UDP carrier to the existing
`natrav-overlay` executable. UDP is not exposed as an application protocol and
does not replace TLS, HELLO, NOS1, receipts, authorization, or durable state.
It supplies bounded datagrams to the finite packet service, which reconstructs
the `OrderedByteStream` consumed by the existing OpenSSL `ByteChannel` BIO.

```text
numeric connected UDP socket
→ finite packet service (NPL1)
→ reliable ordered byte stream
→ OpenSSL BIO over ByteChannel
→ TLS 1.3 mutual authentication
→ HELLO identity binding
→ NOS1 reusable session
→ application operations and bound receipts
```

An IP address, UDP port, link identifier, epoch, or packet source is a locator
or link coordinate only. None is peer identity, authority, or proof of
authorship. The configured TLS identity and pinned key-generation policy remain
decisive.

## Canonical locator

The only accepted UDP locator spelling is:

```text
udp-v1|local=<numeric-endpoint>|remote=<numeric-endpoint>|mtu=<decimal>|link=<16-lowercase-hex>|epoch=<decimal>|profile=1
```

Example:

```text
udp-v1|local=127.0.0.1:41000|remote=127.0.0.1:41001|mtu=1200|link=5544505445535431|epoch=7|profile=1
```

IPv6 endpoints use brackets:

```text
udp-v1|local=[::1]:41000|remote=[::1]:41001|mtu=1200|link=5544505445535431|epoch=7|profile=1
```

The parser rejects any spelling that does not round-trip byte-for-byte through
the canonical formatter. It accepts numeric IPv4 and IPv6 only. DNS names,
service names, unspecified addresses, IPv4 limited broadcast, multicast, and
IPv6 scoped link-local addresses are outside `udp-v1`.

The fields mean:

- `local`: exact numeric address and nonzero port to own with `bind(2)`;
- `remote`: exact numeric address and nonzero port selected with `connect(2)`;
- `mtu`: maximum complete UDP datagram accepted or emitted, 256 through 65507;
- `link`: nonzero 64-bit finite-link identifier, rendered as exactly sixteen
  lowercase hexadecimal digits;
- `epoch`: nonzero 32-bit finite-link epoch used to reject stale link traffic;
- `profile`: versioned finite-link resource and retry profile; revision 0584
  supports only profile 1.

Local and remote endpoints must use one address family and must differ. Every
behavior-affecting value is explicit. The host environment does not supply an
implicit interface, service, MTU, link identifier, epoch, or profile.

## Socket ownership and filtering

Each established endpoint owns exactly one `SOCK_DGRAM` socket. Construction:

1. creates the socket with close-on-exec;
2. forces IPv6-only behavior for IPv6 locators;
3. disables broadcast;
4. requests finite send and receive socket buffers;
5. binds the exact local endpoint;
6. connects the exact remote endpoint; and
7. enables nonblocking operation.

Connected UDP gives the kernel a fixed destination and filters incoming
traffic to the selected remote tuple on supported platforms. That is useful
reachability hygiene. It is not authentication, authorization, replay
protection, or evidence of peer identity.

The implementation performs no `recvfrom`-based source learning, rebinding,
path migration, interface scan, discovery, multicast join, broadcast, or DNS
resolution.

## Finite packet profile 1

Profile 1 uses the configured UDP MTU and the existing finite packet-link state
machine. Its revision-0584 bounds are:

| Resource | Bound |
|---|---:|
| maximum logical message | 256 KiB |
| aggregate reassembly bytes | 2 MiB |
| completed-delivery bytes | 2 MiB |
| in-flight data frames | 512 |
| control frames | 512 |
| receive packets per pump | 512 |
| retransmission delay | 5 logical ticks |
| retry limit | 20 |
| message expiry | 2,000 logical ticks |
| logical tick interval | 10 ms |
| requested socket send buffer | 262,144 bytes |
| requested socket receive buffer | 262,144 bytes |
| semantic finish budget | 2 seconds |

The finite packet service retains canonical framing, integrity detection,
fragmentation, reassembly, acknowledgments, retransmission, duplicate
suppression, expiry, backpressure, and bounded work. UDP does not bypass or
reimplement those rules.

A datagram larger than the configured MTU is detected using `recvmsg` with
`MSG_TRUNC` and rejected as `UDP_DATAGRAM_TRUNCATED`; it is never silently
accepted as a prefix. Nonblocking send backpressure is retained and retried
under the caller's absolute I/O deadline.

## Listener model

UDP has no TCP-style accept operation. NATravOverlay therefore gives one
configured listener socket a single active stream lease:

- readiness means a datagram from the fixed connected remote is pending;
- accepting transfers ownership of that socket into one ordered stream;
- no second stream can be accepted while that lease is active;
- destruction releases the lease; and
- the listener reopens the exact canonical locator after a bounded delay.

This model is deliberately point-to-point. It does not learn a peer from the
first datagram and does not multiplex arbitrary remote endpoints on one local
port.

Configuration rejects one local UDP endpoint being used by both the listener
and an outbound route, or by multiple outbound routes. It also rejects an
outbound route whose remote endpoint is the node's own listener endpoint.
Those rules prevent two independently owned sockets from silently competing
for one configured local address.

## Failure vocabulary

The carrier preserves distinct classes where the platform permits:

- malformed or noncanonical locator;
- unsupported endpoint or profile;
- bind/connect/configuration failure;
- send or receive failure;
- explicit datagram truncation;
- poll or descriptor failure;
- deadline expiry;
- reset or unreachable indication;
- finite-link integrity, retry, expiry, or resource failure;
- semantic EOF after finite-link finish.

TLS callback handling classifies `UDP_*` failures as transport failures while
preserving the original bounded error account.

## Negative controls

Revision 0584 adds none of the following:

- DNS or service-name lookup;
- broadcast or multicast;
- automatic peer or device discovery;
- source-address learning;
- NAT rebinding or path migration;
- transparent forwarding;
- multi-hop relay;
- carrier-derived peer identity;
- a second executable;
- peer-wire, journal, checkpoint, backup, custody, authorization, or storage
  encoding changes.

## Verification boundary

Loopback UDP can establish parser behavior, ownership, fixed-peer filtering,
truncation handling, deadlines, fragmentation, ordered reconstruction, TLS
identity, HELLO, NOS1, operations, receipts, and close on the available kernel.
The retained deterministic packet fixture can establish finite-state behavior
under controlled loss, duplication, corruption, delay, and reordering.

Neither establishes independent-host, NAT, firewall, Wi-Fi, cellular,
satellite, radio, hardware driver, electrical, power, range, interference, or
physical power-loss behavior. Those are explicit verification debts, not a
reason to leave the carrier unbuilt.

## Revision 0585 persistent adversity

Revision 0585 leaves the production carrier and locator unchanged. A
fixture-owned deterministic datagram adversary now runs between two complete
persistent nodes and injects bounded loss, duplication, corruption, delay, and
reordering. It verifies reconnect, duplicate suppression, durable receipts,
pending-work restart, and fixed-source negative controls without adding a
product relay or forwarding mode. See
[Deterministic UDP datagram adversary](UDP-DATAGRAM-ADVERSARY.md).

## Revision 0586 packet-port extraction

Revision 0586 leaves the canonical `udp-v1` locator, socket policy, finite
profile, listener lease, error classes, and authenticated behavior unchanged.
It moves the UDP endpoint behind
`OwnedCompleteDatagramPacketPort` and moves the finite packet-to-ordered-stream
loop into the reusable packet-port adapter.

The UDP implementation continues to own:

- numeric endpoint parsing and canonicalization;
- bind/connect and connected-source filtering;
- socket options and nonblocking mode;
- complete datagram send/receive;
- truncation detection;
- carrier polling and UDP-specific failures; and
- listener descriptor and lease lifecycle.

The generic adapter now owns:

- finite packet stream construction;
- logical packet time;
- ordered reads and writes;
- semantic finish;
- deadline handoff to the concrete port; and
- destruction ordering between finite state and carrier ownership.

No UDP endpoint, link identifier, epoch, or socket fact becomes identity or
authority. The extraction adds no Unix-datagram product route; the Unix socket
pair used by the focal probe is fixture-only.
