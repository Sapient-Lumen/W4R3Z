# Recipient view-binding inspection — revision 0553

`source-view-bindings` reads the exact subscription pins accepted for one recipient view. It is a native, observational manager interface, not a pin-approval mechanism, provider query, lease verifier, or evidence reader. A pin remains a local accepted expectation; its hashes do not independently establish source truth or consent.

## Commands and exact selection

```sh
./node/bin/natrav-overlay source-view-bindings \
  --control state-c/control.sock --view temperature \
  --limit 16 --max-bytes 32768
```

The view ID is required. Optional exact filters are `--grant`, `--instance`, `--grant-digest`, `--binding-digest`, and `--lineage-digest`. `--presence all|configured|historical` and `--envelope all|nse1|nse2` select membership and envelope type. All filters are conjunctive. No substring, wildcard, or prefix matching occurs. Selecting NSE1 with a lineage digest is invalid, not an ignored option.

Bindings are sorted by grant ID, with one-based ordinals within the owned, filtered view selection. A removed accepted pin is HISTORICAL. A present pin remains CONFIGURED even when the view is retired or its provider key is revoked. View configuration presence, terminal lifecycle, and current key validity are returned separately.

An exact unknown view and another manager's view both produce a null view account and zero bindings. A known owned view with no matching pins returns its authorized view metadata and an empty selection. Total retained and configured pin counts in that response describe the owned view, while `selected_total` describes the applied filters.

## Authority before observation

The actual Linux Unix-socket principal must hold current V17-or-later SOURCE_IMPORT. Permission is checked after bounded decoding and remains protected through row selection and encoding. Ownership uses the historical accepted view manager, not a user-supplied UID. ALL, INSPECT, evidence-read permission and the daemon's UID do not bypass it.

A removed view remains visible to its historical manager while that principal still has the current command class. The existing parser requires an import-capable principal to retain at least one current view; this increment does not remove that rule. Revoked-key history can be inspected without making it eligible for imports. An import-only principal gains no payload-query authority.

Successful and empty reads append no journal or successful control-audit event. Existing denial accounting still applies. Quiescence and draining permit the read while the control endpoint remains available. Listing does not start a worker, classify a source, charge retention, amend a pin, create a grant, or resolve a dependency.

## Returned evidence, and evidence not returned

Each pin row includes its exact view/grant, subscription instance, grant digest, optional succession-lineage digest, canonical binding digest, expected NSE1/NSE2 format, current/historical presence, and first accepted configuration event (ordinal, runtime generation and canonical digest).

The view account includes its immutable definition digest, manager UID, first accepted configuration reference, provider node/generation/SPKI, current key state and pin match, source-author UID claim, source and target scopes, target reservation and terminal lifecycle.

First acceptance is derived from the real accepted event stream. Rejected candidates and config-check/preparation cannot create pin history. Removing and restoring a pin does not rewrite its first acceptance. This is not a full add/remove timeline; other events can be read through the separately authorized configuration-history interface.

No source payload, free-text reason, identity pathname, source operation, import decision history, or complete canonical configuration is returned. Provider grant and instance hashes are not independently verified provider journals. NSE2 lineage is an exact opaque commitment, not proof of a currently valid lease. `verification` is `RECIPIENT_ACCEPTED_PINS_NOT_PROVIDER_LEASE_PROOF` and `freshness` remains `NOT_ESTABLISHED`.

The row's binding digest retains the existing definition:

```text
SHA256("NATRAV_OVERLAY_SOURCE_VIEW_BINDING_V1" || 00 ||
       UTF8(view,grant,instance_hex,grant_digest_hex,lineage_hex_or_dash))
```

All five comma-separated fields are canonical as in accepted `source_view_binding=` policy. The new API does not recalculate a different binding identity.

## Coherent content-selected pages

The first page returns `selection_digest`, `next_offset` and `has_more`. Continue with the same filters:

```sh
./node/bin/natrav-overlay source-view-bindings \
  --control state-c/control.sock --view temperature \
  --offset NEXT_OFFSET --selection SELECTION_HEX64 \
  --limit 32 --max-bytes 60000
```

Page length is 1..32 rows; annotated JSON is 2,048..60,000 bytes. These bytes exclude outer control framing. A conservative 384-byte allowance is reserved for the actual principal annotation. Rows are never partially emitted or skipped. `VIEW_BINDINGS_PAGE_TOO_SMALL` means the first row or required metadata does not fit. A nonfitting later row remains the next row on continuation.

The selection binds node, actual UID, accepted configuration digest, all exact filters, complete displayed view account, and every selected pin row. Offset, page size and byte budget are excluded so pagination parameters can change. Nonzero offsets require a selection. A mismatch returns `VIEW_BINDINGS_SELECTION_MISMATCH` before rows; this is a content comparison, not a secret capability or mutation condition.

Current-policy changes invalidate the selection, including unrelated accepted configuration changes. A view retirement changes its displayed lifecycle and invalidates the selection. Ordinary imports, reads, grant counters and source arrivals do not alter pins or lifecycle and do not themselves invalidate it. Same-state compaction and restart reproduce it. Relocation changes current configuration and requires reselection, but does not rewrite the historical pin records. An exact configuration rollback can recover a prior selection when the selected rows and displayed view account are unchanged. View-wide retained/configured counts are current observations, not extra filtered-selection members: newly retained pins outside a filter can change those totals after rollback without changing the filtered selection.

There is no retained multi-page snapshot or irreversible freshness sequence. An older valid complete state can match its old digest. Current authority is checked on every request.

## Independent selection encoding

All integers are big-endian. Text is UTF-8 preceded by u16 length. An optional digest is a one-byte 0/1 marker followed by 32 bytes when present. Filters encode, in order:

```text
text(view), text(presence), text(grant), text(envelope),
optional(instance), optional(grant_digest), optional(binding_digest), optional(lineage_digest)
```

Let `V` be the compact UTF-8 JSON of the displayed view account (or `null`). The initial root is:

```text
SHA256("NATRAV_OVERLAY_VIEW_BINDINGS_SELECTION_V1" || 00 || text(node) || u32(uid) ||
       configuration_digest || filters || u32(len(V)) || V || u32(selected_count))
```

For each selected row in grant order, with compact row JSON `R`, update:

```text
SHA256("NATRAV_OVERLAY_VIEW_BINDINGS_ROW_V1" || 00 || prior_root || u32(len(R)) || R)
```

The request is `NOC1`, control kind 40, then `VBI1`, the filter fields, u32 offset/limit/maximum-bytes, and optional selection. EOF is mandatory. Zero digest selectors, malformed optional markers, unknown format, and invalid text/limits are rejected. Older daemons reject the unfamiliar local kind. No peer wire change is involved.

## Derived registry and measured work

The existing replay-derived view registry now retains one first-event ordinal for each accepted immutable binding. Its 32-view/256-historical-binding limits are unchanged. There is no new persisted registry or logical-state field. The normal semantic decoder supplies this index after validated acceptance and reconstructs it from checkpoints in historical order.

The reader performs one exact `(manager UID, view ID)` lookup. For a found view, it compares bounded active policy metadata, visits up to that view's 256 retained pins, constructs and hashes only matching row summaries, and follows direct configuration-event references. It does not parse historical configurations, open identity files, read source records, copy payloads, serialize histories or construct an application snapshot. A missing owned view visits zero pins. Exact filters currently still examine the view's bounded pin map; this is not constant-time lookup for every filter.

`work` counters cover the locked method, excluding earlier current-configuration processing, principal handling, transport, allocations, startup and reconstruction. Each page rehashes its selected summaries; memory is bounded by pin count and encoded metadata but not allocation-free. Index storage is proportional to retained bindings, with one additional map entry per pin. The node's existing synchronization and journal correctness remain authoritative.

## Validation scope

The runnable `run_view_bindings.py` tests independent request/root/pin encoding, filters and byte limits; rejected and preparation-only configurations; exact first-event provenance including a rejected event between acceptances; removed/restored pins; actual Linux UIDs and slow-request revocation; all 256 retained pins in one view with mixed NSE1/NSE2 expectations; an actual NSE2 lease succession and mapped correction; retirement and concurrent reads; keyed audit, compaction, signed encrypted restore, relocation with removed old identity files, new imports and real nonempty draining.

Synthetic maximum-capacity pins are not 256 communicating subscriptions. Actual source delivery and succession are tested separately. Fresh selected profiles and failures are recorded in [validation](../validation/VALIDATION.json) and [attempts](../validation/ATTEMPTS.md); retained historical contracts are not claims of fresh reruns. A negative control removes only selected-content equality and must be detected by the false-selection regression.
