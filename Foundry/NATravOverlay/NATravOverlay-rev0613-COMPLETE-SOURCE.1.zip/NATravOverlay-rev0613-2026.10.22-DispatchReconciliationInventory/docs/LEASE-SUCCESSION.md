# Acknowledged lease succession — revision 0524

Revision 0556 adds [explicit structural selector alternatives](STRUCTURAL-SOURCE-SELECTORS.md) and opt-in compact responses. The legacy complete-state selections documented below retain their exact meaning. Structural input is a distinct committed request type, not a renamed legacy digest.


Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Implemented boundary

`source-subscription-succeed` is a provider-manager operation that creates a fresh finite V16 lease from the **fully acknowledged** frontier of one exact withdrawn or expired predecessor. It preserves recipient correction mappings and old budgets. It neither reopens the old lease nor manufactures subscriber consent.

This increment deliberately refuses every predecessor that has an issued but subscription-unacknowledged delivery, including one that was cancelled, expired, rejected, or acquired a late outbox receipt. Atomic cancellation and remote successor admission are not implemented. A late receipt can now be adopted by the separate [explicit reconciliation](TERMINAL-RECONCILIATION.md) command before ordinary succession. A successful successor is provider-managed and requires its own explicit automatic-delivery grant.

## Authority and exact selection

The connected kernel UID needs current `SOURCE_DISCLOSE` and an unused, accepted, finite V16 successor `source_disclosure` rule. The manager UID, author UID, exact scope, subscriber node, subscriber key generation, and SPKI must match the predecessor. The new grant and lease generation differ from the direct predecessor. Key rotation is not inferred from succession.

For example, a provider may explicitly accept both rules (with the real deployment UIDs and identity):

```text
source_disclosure=first,1001,1000,C,c-g1,observations/temperature,64,1000000,lease-first,60000,RETAIN
source_disclosure=next,1001,1000,C,c-g1,observations/temperature,32,500000,lease-next,120000,RETAIN
```

The second rule is new finite authority, not a refund of the first allowance. Configuration V16 is unchanged. A rule alone does not adopt an old frontier or enable automation.

Read the terminal predecessor with the normal owner-only administrative command:

```text
source-subscription-status --control PATH --grant first
```

Then select the exact observed account:

```text
source-subscription-succeed --control PATH
  --grant next --successor-lease lease-next
  --predecessor-grant first --predecessor-lease lease-first
  --instance HEX64 --expected-revision N
  --predecessor-state-digest HEX64
  --expected-frontier N --mapping-digest HEX64
  --reason TEXT
```

The instance and revision name the **predecessor**, not the new instance. `state_digest`, `acknowledged_source_position`, and `acknowledged_mapping_digest` come from its status. The state digest commits the complete retained terminal account, including its remote request, withdrawal/expiry, budgets, mappings, and automation history.

The command rechecks current authority after request decoding under the accepted configuration gate and owns the state mutex through validation and commit. A request connected before policy removal cannot retain the old rule. Another authorized UID cannot adopt a manager's predecessor. Administrative `ALL`, read permission, and knowledge of digests do not supply `SOURCE_DISCLOSE`.

## Fully acknowledged means more than probable delivery

The predecessor must be durably terminal with kind `WITHDRAWN` or `EXPIRED`, and its acknowledged count must equal all of its issued records. Each acknowledged mapping already requires its exact durable outbox receipt. A manually retired non-lease, active lease, terminal unacknowledged head, or missing state is ineligible.

A late receipt received after withdrawal does not silently change subscription progress. Even when generic outbox status says `ACKED`, succession is refused until the manager explicitly commits [terminal receipt reconciliation](TERMINAL-RECONCILIATION.md). That operation preserves the original terminal account and adopts only the exact durable receipt; it does not invent acknowledgment for cancellation or missing evidence.

No source is skipped and no predecessor operation is retried, cancelled, rebound, or modified by the succession command. Explicit receipt reconciliation, when needed, must finish before a successor adopts the predecessor.

## Immutable lineage, new allowance

One kind-32 `NST1` append commits an `NSS5` successor containing:

- the new accepted grant, instance, finite lease start/expiry, local manager UID/PID, event, reason, and command digest;
- the exact predecessor grant, lease generation, instance, revision, and complete-state digest;
- the inherited acknowledged frontier and recipient mapping-chain digest;
- initially empty current-lease delivery history, zero spent record/byte allowance, and no automatic grant.

The predecessor's encoded state is unchanged. Its `adopted_by` status annotation is reconstructed from the successor registry. A predecessor has at most one successor; journal and checkpoint replay reject forks, cycles, missing ancestors, changed commitments, or identity reinterpretation. All ancestors remain necessary retained state.

With current manager authority and the matching accepted successor rule, an exact repeat returns `ALREADY_SUCCEEDED`, even after the successor has progressed, expired, or been relocated. It does not alter the original lease clock, revision, budgets, or automation. Changed intent, another existing admission under the target grant, or a second target grant adopting the same predecessor fails.

The registry remains at most 64 retained subscriptions and 16 per manager UID. Successors consume ordinary retained slots. No name, grant, history slot, or old budget is recycled. There is no unbounded lineage service.

## Progress and budget terminology

For a successor, `issued`, `acknowledged`, and `used_payload_bytes` describe only work performed under **that new lease**. `inherited_acknowledged` is the adopted prefix. `acknowledged_source_position` is their cumulative acknowledged frontier.

Selecting a source uses the inherited prefix plus the new lease's local position. Current record and payload limits apply only to new issues. Automatic `AUTO_ISSUE` and `AUTO_ACK` still consume their separate finite successful-step allowance. No predecessor automation is inherited or resumed.

Original sources, hidden-record isolation, one outstanding issue, exact recipient policy, outbox quotas, retries, and receipt-gated acknowledgment otherwise retain their prior semantics.

## Correction mappings and NSE2

The provider uses retained acknowledged predecessor mappings when a later source corrects an earlier source. The outgoing correction points to the recipient-specific **old delivery operation**, not to the provider-private source ID and not to a new copy of the old original.

Successor deliveries use `NSE2`, a versioned opaque evidence payload. It has the existing source-envelope fields followed by predecessor grant/lease, predecessor instance/state digest, acknowledged mapping root, and inherited frontier. Its ordinal is cumulative within the eligible source domain. The within-lease offset is bounded to 128; the inherited bound is the retained registry limit times 128. `NSE1` retains its original 1–128 ordinal constraint.

The operation is `SHA-256("NATRAV_OVERLAY_SOURCE_DELIVERY_V2" || NUL || NSE2)`. Ordinary non-successor `NSE1` operations retain the V1 digest domain and byte encoding. The recipient admits the envelope as ordinary evidence/correction over unchanged TLS/HELLO/NOA1/NOS1 transport. Older recipients may store opaque payloads; their older inspector does not understand `NSE2`.

The added lineage fields count toward the ordinary envelope/payload bound. A source that cannot fit is rejected without truncation, skipping, or budget consumption; successor lineage does not enlarge that bound.

`source-envelope-inspect` reads both versions. Its answer remains `STRUCTURAL_ONLY`: hashes and lineage fields in a supplied file are not independent proof of source authenticity, recipient acknowledgment, or evidence truth.

## Mapping commitment

The initial domain-separated mapping root includes subscriber node, key generation, SPKI, source-author UID, and exact scope. Each acknowledged link includes the prior root, cumulative position, source/delivery/record digests, source bytes, issue and acknowledgment event/time/PID, and automatic-generation provenance. A successor begins with its predecessor's verified root and extends it only for new acknowledged mappings.

The bounded reference stores no duplicate ancestral payload or delivery vector. Replay retains and checks the predecessor chain. Lookup of a cross-lease correction walks at most the retained registry bound. Independent Python format tests reconstruct both mapping roots and `NSE2` operation identities; that is not an independent cryptographic audit.

## Remote actors and service lifecycle

The successor records `LOCAL_SOURCE_MANAGER`, not a fictitious remote request or borrowed Unix credential. Existing authenticated requests and withdrawal IDs continue to address the predecessor. A remote request to the already reserved successor grant returns the existing provider-managed boundary; remote status/withdrawal for locally created successors is not added in this revision.

The successor lease can naturally expire, can be locally managed or retired under existing rules, and can receive a new explicit finite automatic grant. Quiesce/drain retain their existing mutation restrictions. The local subscriber cannot convert creation retries into automatic enabling.

## Persistence and validation

The local request uses strict `NSR3`; ordinary `NSR1/NSR2` remain byte-compatible. `NSS5` adds a compact immutable succession reference to the preceding finite-state encoding. `NST1`, journal kind 32, authenticated audit, checkpoints, and backups carry the new state through their normal strict decoders. Old subscription states preserve their old encodings. Revision-0523 state readers fail closed on `NSS5`.

The test suite covers exact selectors and real UID ownership; no forks; pending RETAIN/CANCEL and late-receipt refusal; concurrent identical requests; live grant revocation with independent request encoding; two-level correction lineage; cumulative ordinal 129 after a fully delivered 128-record lease; wrong mapping/predecessor with recomputed journal checksums; checkpoint reconstruction; real pre/post-commit `SIGKILL`; 16 retained generations in non-topological checkpoint order; and keyed compaction, signed encrypted restore, relocation, and fresh explicit automatic processing.

Actual build/profile counts and adverse attempts are in [validation](../validation/VALIDATION.json) and [attempts](../validation/ATTEMPTS.md). Complete and selected profiles are distinguished; optional inherited long-running tests are not implicitly counted.

## Limits

This is acknowledged-frontier succession, not complete resolution of every terminal obligation. Unacknowledged predecessors remain blocked; there is no atomic pending cancellation/adoption, remote successor request, key-policy migration, slot reclamation, or distributed lease service.

A valid old backup can restore a pre-adoption registry. Authentication does not establish freshness or prevent two full copies from diverging. Receiver rollback can also make a previously acknowledged correction parent unavailable; ordinary delivery then reports that condition rather than inventing a new mapping. Tests use one Linux kernel and controlled processes, not independent physical hosts or universal power-loss behavior.
