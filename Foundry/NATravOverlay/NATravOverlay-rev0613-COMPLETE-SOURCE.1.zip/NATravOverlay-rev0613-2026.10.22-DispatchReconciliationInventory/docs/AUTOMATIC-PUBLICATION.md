# Finite automatic publication — revision 0516

Current owner-scoped channel discovery is documented in [publication inventory](PUBLICATION-INVENTORY.md); existing exact and mutating command semantics remain separate.

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

Revision 0516 adds a bounded scheduler for existing durable projection-publication channels. It does not create channels, projections, permissions, routes, or recipient trust. A kernel-authenticated owner must create those objects and explicitly grant one finite automatic-publication generation.

This grant is separate from the internal automatic-projection grant. Automatic computation and automatic remote disclosure can be enabled, paused, exhausted, or blocked independently.

## Commands

```text
publication-channel-auto-enable
  --control PATH
  --channel NAME
  --instance HEX64
  --expected-channel-revision N
  --expected-schedule-revision N
  --expected-grant-generation N
  --max-automatic-publications 1..10000
  --min-interval-ms 10..60000
  --reason TEXT

publication-channel-auto-pause
  --control PATH
  --channel NAME
  --instance HEX64
  --expected-channel-revision N
  --expected-schedule-revision N
  --expected-grant-generation N
  --reason TEXT

publication-channel-auto-status
  --control PATH
  --channel NAME
```

The schedule status is deliberately narrow. It exposes channel identity, revisions, lifecycle, current grant state, finite bounds, spent allowance, accepted configuration event, reason, and terminal error. It does not expose source payloads or substitute for ordinary projection/channel status authority.

## Exact grant identity

A grant retains:

- owner UID and immutable channel instance;
- observed channel revision;
- monotonically increasing grant generation;
- monotonically increasing schedule revision;
- accepted configuration event;
- adopted read-authority digest;
- finite successful-publication allowance;
- minimum interval;
- start sequence, completed-publication count, reason, time, and PID;
- terminal state, error, configuration event, UID, PID, and time when stopped.

At most 32 grant generations are retained per channel. Exhausting that history prevents another enable; it never overwrites older provenance. Pausing an already stopped grant is idempotent and remains available even when the history is full.

Enable and pause use exact observed selectors. A stale command cannot replenish, pause, or reinterpret another grant or a newer channel revision.

## Authority before every step

A step requires current V12:

```text
PROJECTION
CONSUMER
SUBMIT
```

It also requires the exact read domain adopted by the projection; numeric projections require payload authority. The grant's authority digest must still match the projection's latest explicit adoption.

`ALL`, `INSPECT`, `CONSUMER_ADMIN`, an internal automatic-projection grant, or an earlier successful publication does not grant automatic disclosure.

The recipient independently applies its normal mutually authenticated issuer/scope policy. Local scheduling cannot compel remote admission.

## One bounded fair worker

The daemon runs one automatic-publication worker for the bounded channel registry. It rotates among eligible channel keys. No channel owns a thread.

Each turn attempts at most one publication. The worker obtains one stable active-configuration lease, checks service lifecycle, derives the current recipient route and active key when available, and asks the journal owner to perform one semantic step.

The minimum interval is retained in the grant, but its monotonic pacing clock is process-local. Restart may make a caught-up or newly eligible channel observable immediately; unchanged results and unresolved predecessors still prevent publication.

Actual peer delivery remains the ordinary per-peer outbox scheduler. A slow or unavailable recipient therefore leaves its channel head pending while another channel can enqueue and deliver independently.

## Changed-result rule

Only a changed selected projection result can consume one allowance.

The worker appends nothing when:

- the latest channel publication already carries the projection's current canonical result digest, even if restore or relocation advanced bookkeeping revision metadata;
- the predecessor is still pending;
- no current route/active key can be derived;
- global or per-peer outbox capacity is temporarily full;
- ordinary state capacity is temporarily unavailable;
- service mode is quiesced or draining.

These are observational or transient conditions. They do not create an unbounded history of repeated failures.

When publication succeeds, one `NCT1` transaction contains:

```text
revised NCH2 or NCH3 channel state
+ canonical NPC1/NPC2 evidence or correction
+ ordinary outbound delivery policy
+ incremented grant usage
```

The channel revision, outbox operation, and spent allowance therefore share one synchronized journal boundary. If the allowance reaches its finite maximum, the same transaction closes the grant as `EXHAUSTED`.

## Predecessor and recipient behavior

The acknowledged-predecessor rule is unchanged:

| Head outcome | Automatic behavior |
|---|---|
| No head | Queue the first changed result as an original |
| `ACKED` | Queue a changed result as a correction to the acknowledged head |
| `PENDING` | Wait without spending allowance |
| `REJECTED` | Close the grant as `BLOCKED` |
| `CANCELLED` | Close the grant as `BLOCKED` |
| `EXPIRED` | Close the grant as `BLOCKED` |

A lost receipt is recovered by the existing duplicate-safe delivery/replay path. The channel advances only after the sender has the durable receipt.

Authenticated recipient rejection belongs to the ordinary outbox outcome first. On the next scheduler observation, the finite grant becomes durably blocked. An operator may use the existing attributable outbox retry for a rejected head and then explicitly enable a new grant; neither action silently resumes the old grant.

## Canonical change detection

The worker decides whether a result changed by comparing the canonical projection-result digest retained by the channel head. It does not use the projection's bookkeeping revision as the disclosure criterion.

This distinction was found during sanitizer testing: restore/relocation can legitimately create a later projection revision while preserving the same processed frontier and canonical result. Treating that revision alone as change produced a redundant correction before newly arriving evidence. Revision 0516 now remains caught up until the canonical result digest changes, and the restored-maintenance test holds the node in that state before admitting the next correction.

## Durable stopping states

```text
ENABLED
PAUSED
BLOCKED
EXHAUSTED
```

`BLOCKED` reasons are derived from current retained facts during command processing and semantic replay. Current reasons include missing required local classes, denied read domain, projection conflict, changed adopted authority, missing channel head, rejected/cancelled/expired predecessor, channel budget exhaustion, and channel retirement.

A source-derived block is appended once and removes the channel from scheduler candidates. Replaying a made-up block reason fails semantic journal validation.

Caught-up, predecessor-pending, missing-route, unavailable-peer, and temporary quota conditions are not terminal grant states.

## Lifecycle, crash, and maintenance

Quiesce and drain suspend new automatic publication. Durable grants remain present, and publication backlog does not extend drain completion. Authorized resume makes an eligible `ENABLED` grant runnable again.

The tests kill the daemon before and after the synchronized automatic-publication commit. Before commit, the old channel and allowance reconstruct. After commit, the channel head, outbox operation, and spent allowance reconstruct together even if the command observer received no success response.

Grant and channel history survive ordinary restart, authenticated audit, live compaction, signed encrypted backup, verified restore, and explicit relocation. The stable recipient operation identity remains independent of owner-path relocation.

## Formats and compatibility

The local request envelope advances from `PCR1` to `PCR2`; the decoder retains strict `PCR1` compatibility for revision-0515 commands.

Channel state advanced from `NCH1` to `NCH2` in revision 0516. `NCH2` adds schedule revision, grant history, automatic-publication attribution, and transition actor. Revision 0517 adds backward-readable `NCH3` epoch lineage without changing the finite grant model. Checkpoint extension `NPH1` remains the registry container.

No peer message branch changes: epoch-1 publications remain ordinary `NPC1` evidence/corrections over `NOA1` and `NOS1`; an explicit later epoch uses `NPC2`. Automatic workers never create that epoch themselves.

## Boundaries

Automatic publication is finite and opt-in. It is not a general trigger engine, plugin system, durable wall-clock scheduler, remote exactly-once transaction, truth guarantee, or freshness authority.

A grant blocked by a rejected, cancelled, or expired predecessor cannot create a new channel epoch. Revision 0517 adds an explicit owner command for that discontinuity; the old grant remains blocked and a new finite grant is required afterward.

The worker shares process, storage, and CPU resources with other node functions. Round-robin turns and bounded work prevent one channel from owning a thread; they do not provide hard real-time or resource isolation.

## Revision 0517 interaction with explicit epochs

Automatic publication never invents a replacement epoch. A rejected, cancelled, or expired channel head still blocks the active grant according to its ordinary source-derived rule.

When an owner explicitly starts a later epoch while a grant is still `ENABLED`, the same `NEW_EPOCH` transaction closes that grant as:

```text
BLOCKED
PUBLICATION_CHANNEL_NEW_EPOCH_REQUIRES_NEW_GRANT
```

A grant that was already blocked remains historical and blocked. The epoch-opening original is owner-invoked and consumes no old automatic allowance. A new finite grant must be enabled with the replacement channel revision before automatic same-epoch corrections may continue.

This prevents an earlier disclosure decision from silently crossing a terminal publication discontinuity.
