# Native transactional projections — revision 0511

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Subscribed-source inputs

Revision 0526 permits native computation over original payloads after explicit source-view-import. Use the provider/target-scope selection and ordinary read permissions. The input retains subscribed_source rather than local_authorship. Raw NSE1/NSE2 bytes are not implicitly interpreted as embedded observations. [Recipient import contract](SUBSCRIBED-SOURCE-VIEWS.md).

Revision 0511 additionally implements [NUMERIC_SUMMARY_V1](NUMERIC-PROJECTIONS.md). The metadata-specific format and semantics below continue to describe DOMAIN_SUMMARY_V1 unchanged. Numeric processing adds explicit payload authority; it is not enabled by metadata permission.

## Definition and authority

`DOMAIN_SUMMARY_V1` is one built-in metadata processor over exactly one issuer and scope. It counts admitted records without parsing their payloads. Every valid stored payload, including empty, non-UTF-8 or malformed application-specific content, is a byte sequence for this definition. There is no shell, executable, plugin, file destination, remote sink or external effect.

V12 adds explicit `PROJECTION` authority:

```text
NATRAV_OVERLAY_CONFIG_V12
local_control=1001,EVIDENCE_READ,CONSUMER,CONSUMER_ADMIN,PROJECTION
evidence_read=1001,A,observations/temperature,METADATA
```

`PROJECTION` requires `CONSUMER` and `EVIDENCE_READ`. Rebuild additionally requires `CONSUMER_ADMIN`. `ALL` remains the original six administrative classes. Metadata authority suffices: the processor examines record lengths and stored digests, never payload contents. Names live in the actual SO_PEERCRED UID's consumer namespace. An existing ordinary consumer cannot be silently converted or commandeered.

Every command rechecks current authority after request decoding. Generic `consumer-read/status` also requires `PROJECTION` when the named consumer carries a projection; they cannot bypass a revoked grant. Changed effective read authority freezes result inspection and processing until an authorized rebuild. The exact source domain must still be permitted. V6–V11 retain their previous behavior and cannot grant the new class.

## Commands

```sh
natrav-overlay projection-create --control PATH --consumer NAME \
  --issuer ID --scope S --reason TEXT [--limit 1..128] \
  [--max-admissions 1..1000000]
natrav-overlay consumer-read --control PATH --consumer NAME
natrav-overlay projection-process --control PATH --consumer NAME --batch HEX64
natrav-overlay projection-status --control PATH --consumer NAME
natrav-overlay projection-rebuild --control PATH --consumer NAME \
  --expected-revision N --reason TEXT
```

Standard finite control I/O options remain available. Creation fixes the selection, definition and admission budget. Default budget is 100,000; maximum is 1,000,000. Start is always the beginning, metadata only, with a fixed 60,000-byte annotated reply budget. Input pages contain at most 128 rows. Repeating creation with the same definition is idempotent; changing the immutable definition under the same name is rejected.

The node must already be running with accepted V12 grants. The example `node/examples/node-b-projection.conf` illustrates policy, not a provisioned identity.

## Result meaning

| Field | Meaning at the processed frontier |
|---|---|
| admissions | Originals plus corrections processed in this epoch |
| originals | Independent original chains admitted |
| corrections | Corrections admitted; never additional independent chains |
| current_heads | Number of independent original chains, not a truth ranking |
| historical_payload_bytes | Sum of the payload lengths of every processed admission |
| current_payload_bytes | Sum of the lengths of the current heads within the consumed prefix |
| source_digest | Ordered commitment to the consumed operation IDs and record digests |

A correction subtracts its predecessor's payload length and adds its replacement length. It does not subtract unrelated observations. Parent existence, order and exact domain are validated against the retained evidence. Later, unprocessed corrections do not retroactively change the stored result. Consumers can use the existing query/feed APIs to inspect attributable sources.

For example, two originals of 3 and 5 bytes, followed by corrections replacing the first with 7 and then 2 bytes, produce 4 admissions, 2 originals, 2 corrections, 2 current heads, 17 historical bytes and 7 current bytes. The independent integration interpreter checks those exact values.

`last_source_operations` identifies at most the most recent 128 processed inputs. Earlier sources remain in retained evidence and are committed by the chained digest. The processor does not retain an unbounded second source list or an unlimited chronological result log.

## One result/position commit

`consumer-read` retains the existing durable issuance behavior. Processing checks the exact outstanding batch, current authority, admitted source records, definition, epoch, limits and prior result. It constructs the next complete consumer **with** its result and appends one checksum-framed journal kind-27 record. The authenticated writer wraps it when keyed state is in use.

There is no separately committed effect followed by `consumer-ack`. Ordinary ACK and reset return `PROJECTION_ATOMIC_TRANSITION_REQUIRED`. Semantic replay deterministically reinterprets the bounded source page and compares the complete expected result/consumer transition. Removing the issued page, changing the effect, skipping the position or swapping a definition fails replay even when ordinary checksums are recomputed.

Concurrent processors serialize under the state mutex. One wins; others presenting the same most-recent batch observe `ALREADY_ACKNOWLEDGED`. A lost reply can be retried without another internal effect. As with ordinary consumers, only the most recent acknowledged batch is retained for idempotence; older IDs are not an unlimited receipt service.

Admission-budget failure leaves the outstanding page, result and progress unchanged. No partial page is processed merely to fit the remaining allowance. A name with an exhausted immutable budget requires a new explicitly configured consumer to process more history; rebuild does not enlarge the old budget.

## Explicit rebuild

Rebuild requires the exact current revision, current read and projection authority, separate reset authority, and a reason. It commits zero result and position together, clears any pending batch, retains the preceding result, and appends an adoption account containing actor PID/UID, configuration event, reason, old/new authority, positions and abandoned batch identity.

Rebuild always starts at the beginning; skipping to `now` would give misleading complete-head semantics and is not supported. Previous counters/digests are not erased or presented as current. At most 32 creation/rebuild accounts and 31 retired results are retained. Active-registry limits remain 128 consumers globally and 16 per UID, shared with ordinary consumers. Explicit [retirement](CONSUMER-RETIREMENT.md) releases an active slot while retaining the full final state under a separate 256-global/64-per-UID archive ceiling. Names are never recycled.

## Encoding and provenance

The existing NCR1 control family adds commands 6=create projection, 7=process, 8=status and 9=rebuild. These use ControlKind 17; no peer wire changes occur. Create additionally encodes a u64 admission budget; process supplies the exact 32-byte batch ID; rebuild uses an expected revision, reason and canonical beginning flag. Unknown, malformed and trailing material is rejected.

Ordinary consumers retain NCS1. Projected consumers use NCS2 with an NPR1 bounded result extension inside the existing NDC1 checkpoint collection. Journal kind 27 and storage schema 2 remain. Old binaries reject NCS2 rather than silently dropping the result. Optional projection objects are returned inside the existing versioned consumer JSON envelope.

The definition digest is SHA-256 of `NATRAV_OVERLAY_DOMAIN_SUMMARY_V1`, a zero byte, big-endian u32 UID, 32-byte consumer instance, big-endian u64 budget, and canonical encoded NEF1 selection. Initial source root equals that digest. For each admission, the next root hashes `NATRAV_OVERLAY_PROJECTION_SOURCE_V1`, a zero byte, previous root, big-endian u64 admission ordinal, 32-byte operation ID, and 32-byte immutable record digest. The consumer instance, epoch/adoption history, exact batch, active configuration event, PID and time provide the remaining transaction binding. Digests are commitments, not evidence-truth or freshness guarantees.

## Bounded work and replies

Processing visits at most one source page per evaluation, plus bounded semantic/source-reference checks. The reported `projection_work.source_records_visited` includes those checks; normal successful processing currently visits at most four pages. Status and duplicate processing perform no projection-source traversal. Empty reads append no successful consumer event.

Projection reads reserve 12,288 additional bytes before selecting rows, covering prior source IDs, definition and result metadata. This avoids issuing a page that cannot be replayed inside its fixed annotated response limit. The 240-record real-peer test fills multiple pages with authorization metadata; every response remains within 60,000 bytes. Existing normal-consumer pagination is unchanged.

Checkpoint validation performs one forward source pass per projection through the greatest current or retired frontier, comparing all retained summaries along the way. It does not multiply the prefix scan by the number of rebuilds. It is still linear in that frontier, and multiple projections can revisit the same evidence. Live compaction holds the state mutex; no constant-time, constant-memory or arbitrary-scale claim is made. The underlying evidence/index storage remains proportional to retained state.

## Persistence, compatibility and boundaries

Keyed audit, compaction, signed encrypted backup/restore and explicit relocation carry the complete projected consumer. Checkpoint loading independently reconstructs counters and source roots from retained source records, not merely from the saved result. Result inspection after restore remains subject to current exact read policy. Quiesce/drain block create/process/rebuild and durable read issuance; status remains observational.

Real hard kills bracket the synchronized result/position append. Before commit, both remain old with the same outstanding page. After commit, both are new even if the client saw no success. Arbitrary partial authenticated appends still require the existing explicit recovery path; these tests do not prove physical power-loss durability.

This establishes repeat-safe **internal** processing in one authoritative state, not exactly-once external effects. An old valid backup may replay older history; independent copies can diverge; compromised state keys/UIDs/hosts are outside the guarantee. Payload truth, numeric semantics, automatic scheduling, general materialized views, external side effects, distributed ownership and freshness are not implemented by this definition.

## Opt-in automatic service (0512)

[Automatic scheduling](AUTOMATIC-PROJECTIONS.md) reuses this source-derived result transition while atomically accounting finite work allowance. Enabled projected consumers reject manual read/process/rebuild mutation until paused. Schedule status is separate from evidence result status. A stored grant cannot bypass current read authority, definitions or sum budgets.

## Revision 0513 — retirement

[Terminal retirement](CONSUMER-RETIREMENT.md) freezes a projection result/frontier, preserves its source and rebuild history, and atomically stops enabled automatic work. Retirement is not rebuild, ACK or source deletion. New definitions use new names; full result access retains current read permission.

## Revision 0514 — explicit result publication

`projection-publish` selects one exact active or retired result by immutable instance, consumer revision, processed frontier, and `projection_result_digest`. The owner must retain the definition's current read authority and separately hold `SUBMIT`; computation permission is not disclosure permission.

The node encodes the complete source-derived account as canonical `NPP1` evidence and atomically queues it with the recipient's active generation policy through the existing durable outbox. Retrying the same result/target returns the same operation. A later result is currently a distinct original publication; it is not yet an automatic correction chain. See [projection publication](PROJECTION-PUBLICATION.md).

## Discovering retained instances

Revision 0549 adds [owner-scoped current inventory](CONSUMER-INVENTORY.md). It does not change this contract's mutation semantics, read grants, final results or permanent name reservations. The inventory's conservative adopted-authority check may hide an old instance after read-policy changes; it does not reset or delete it.
