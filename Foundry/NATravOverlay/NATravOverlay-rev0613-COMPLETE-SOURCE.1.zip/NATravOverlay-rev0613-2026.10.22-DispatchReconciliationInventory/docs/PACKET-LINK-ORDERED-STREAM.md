# Private packet-link ordered stream

Revision 0582 places the real authenticated NATravOverlay stack over the finite
packet-link service introduced in revision 0581.

The adapter is deliberately fixture-owned and unavailable to normal route
configuration.  It proves the architectural seam before any hardware or UDP
packet carrier is admitted.

## Stack under test

```text
finite packet service
    -> PacketLinkOrderedByteStream
    -> custom OpenSSL BIO
    -> TLS 1.3 mutual authentication
    -> HELLO identity binding
    -> NOS1 reusable session
    -> application operation and bound receipt
    -> NOS1 close and TLS close-notify
```

`PacketLinkOrderedByteStream` implements the same `OrderedByteStream` contract
used by TCP and POSIX serial.  It does not implement a second TLS path, a mock
HELLO exchange, or a packet-specific application protocol.

## Ownership and authority

`make_packet_link_stream_pair()` creates two stream endpoints and one explicit
control object.  The control object owns the deterministic packet network,
finite queues, logical clock, and canonical evidence.  Destruction of an
endpoint is visible to the shared fixture and cannot leave a hidden global
carrier behind.

The private transport kind is not accepted by `parse_transport_kind()`, has no
locator syntax, cannot be dialed through `transport_connector()`, and cannot be
bound through `transport_listener()`.  Packet addresses, stream identifiers,
link identifiers, and schedule ordinals are reachability and test metadata;
none is peer identity or authorization.

TLS identity and pinned SPKI validation remain above the packet service.

## Finite progress

Each read or write:

1. checks its absolute wall-clock deadline;
2. gives the finite sender/receiver state machines bounded logical work;
3. transfers at most the declared operation quantum;
4. waits only for the configured finite progress interval when no work is
   currently possible;
5. returns progress, EOF, timeout, reset, or a bounded carrier error.

The adapter does not create a scheduler thread.  The caller performing stream
I/O owns progress, while a mutex and condition variable provide safe
bidirectional use by the TLS client and server threads.

The finite core still owns MTU, fragmentation, reassembly, acknowledgment,
retransmission, duplicate suppression, expiry, queue, and trace bounds.

## Deterministic evidence boundary

For fixed raw bytes and a fixed `NPLS0001` schedule, two runs must produce
byte-identical canonical `NPLT0001` traces.

Independent TLS handshakes intentionally contain fresh cryptographic
randomness.  Their ciphertext-bearing packet CRC fields and logical timing can
therefore differ even when the same authenticated application work succeeds.
The regression consequently verifies both facts rather than weakening either:

- raw-link replay is byte-identical;
- independent faulted TLS runs preserve packet direction, injected-fault
  disposition, per-direction ordinal, packet-size structure, authenticated
  operations, and bound receipts.

NATravOverlay does not normalize away TLS randomness merely to manufacture a
stronger-looking replay claim.

## Revision-0581 repair

The revision-0581 delivery was correctly classified `REPAIR_REQUIRED`: its
strict build rejected an explicit constructor carrying a default argument.
Revision 0582 gives `FaultSchedule` a true default constructor, retains the
explicit rule-list constructor, moves the implementation into an ordinary
`finite_packet_link.cpp` translation unit, and reruns the original 16-case core
probe before exercising the adapter.

The prior failure record remains under
`validation/attempts/revision-0581-repair-required/`.

## Deliberate exclusions

Revision 0582 adds no:

- configured packet route;
- packet locator;
- UDP, radio, Bluetooth, or hardware driver;
- device discovery or opportunistic attachment;
- transparent forwarding;
- multi-hop relay;
- carrier-derived identity;
- second product executable;
- peer-wire, local-control, journal, checkpoint, backup, custody, or storage
  encoding change.

## Verification boundary

Deterministic memory-backed packet delivery is model evidence, not physical
packet-hardware evidence.  It cannot establish RF range, interference
behavior, electrical correctness, driver quality, real MTU behavior, power
consumption, independent-host scheduling, or physical power-loss recovery.
Those are recorded verification debts and do not veto further construction.

The next bounded carrier target is an explicitly configured numeric UDP
packet port beneath this same finite service and ordered-stream adapter.  UDP
endpoints will remain locators, never identity.  Discovery and relay remain
separate later protocol work.

## Revision 0583 evidence repair

Revision 0583 does not alter this adapter's product semantics. It repairs two
verification predicates that confused source spelling with behavior: canonical
magic arrays were represented as character arrays rather than string literals,
and the private-boundary script still named an earlier limit vocabulary. The
repaired gates check the owned symbols, actual finite fields, executable
canonical vectors, and the continuing absence of configured packet parsing,
connectors, or listeners. Revision 0582 remains recorded as non-passing.
