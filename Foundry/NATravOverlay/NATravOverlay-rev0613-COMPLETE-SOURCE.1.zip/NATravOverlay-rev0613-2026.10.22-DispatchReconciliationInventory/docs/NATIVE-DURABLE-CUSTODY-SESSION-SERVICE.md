# Native durable custody-session service

Revision 0613 keeps the live custody exchange inside the ordinary authenticated
peer-session stack, retains revision 0611's passive receiver, and adds one
default-off, explicitly owner-invoked dispatch through the ordinary daemon. The same
`natrav-overlay` executable carries
`CustodyTransferOffer` and `CustodyTransferAcceptance` as bounded NOA1
application messages inside a reusable NOS1 session. There is no custody-only
socket protocol, TLS context, frame parser, peer-authentication path, daemon, or
second executable.

The capability markers are:

```text
native_custody_session: NATIVE_DURABLE_CUSTODY_SESSION_SERVICE_V1
custody_retained_export: EXPLICIT_CURRENT_CUSTODIAN_BUNDLE_EXPORT_V1
custody_session_transport: NOS1_BOUNDED_REUSE_V1
custody_receiver_policy: V23_PASSIVE_DAEMON_CUSTODY_RECEIVER_V1
custody_dispatch_policy: V24_EXPLICIT_OWNER_CUSTODY_DISPATCH_V1
custody_dispatch_reconciliation: READ_ONLY_STATUS_AND_CURSOR_INVENTORY_V1
passive_daemon_custody_receiver: true
explicit_owner_custody_dispatch: true
configured_custody_relay: true
automatic_custody_sender: false
automatic_route_relay: false
open_relay: false
```

`configured_custody_relay: true` means that an operator can explicitly invoke
one exact configured custody transition. It does **not** mean that an ordinary
peer route forwards custody automatically. The service never discovers a next
hop, changes route after failure, accepts arbitrary relay work, imports final
application evidence, or claims delivery.

## Accepted authority

A live transition requires an accepted `NATRAV_OVERLAY_CONFIG_V22`
configuration containing one canonical `custody_service_hex` rule. The V22 rule
commits:

- one exact immutable V21 grant id, generation, and commitment;
- the exact DER-certificate SHA-256 of the current custodian and next hop;
- finite pending-case, bundle-byte, attempt, and transfer-window limits;
- a finite authority expiry; and
- monotonic `ACTIVE`, `RETIRED`, or `REVOKED` lifecycle state.

The shared rule deliberately contains no route id, carrier type, host, port,
discovery hint, failover order, or forwarding instruction. At invocation, the
sender must name one enabled route id. The offer then binds that exact route,
the accepted sender-configuration digest, the V22 rule and V21 grant, both
certificate commitments, the finite time window, and the complete canonical
`NHCB0001` bundle. A retained unresolved offer cannot switch routes.

The receiver resolves the same V22/V21 authority from its own accepted
configuration. Mutual TLS authenticates the NOS1 peer, and the service compares
the peer's exact DER-certificate SHA-256 with the V22 commitment in addition to
the existing generation and SPKI checks. Carrier coordinates remain locators,
not identity or authority.

## Passive ordinary-daemon receiver

An ordinary daemon remains custody-disabled unless its accepted configuration is
V23 and contains one canonical `custody_receiver_hex` activation. The activation
commits one exact immutable V22 rule id, generation, and commitment, a finite
in-flight offer bound, a finite expiry, and monotonic `ACTIVE`, `RETIRED`, or
`REVOKED` state. It is accepted only when the local identity and signing
generation are the exact V21 next-hop endpoint, its expiry does not exceed V22,
and its concurrency bound leaves at least one ordinary peer worker available.

The daemon installs one `PassiveCustodyReceiver` callback in the existing NOS1
listener. It creates no listener, protocol frame, TLS context, thread-owned
service, daemon, executable, state directory, queue, or authority ledger. The
callback acquires the current runtime configuration lease for each custody
operation. Consequently an already-open mutually authenticated session observes
live V23 activation on its next operation, while retirement waits for an
in-flight durable operation to release its lease.

`ACTIVE` V23 authority may admit a new exact offer through the existing V22/V21
receiver state machine. `RETIRED` or time-expired V23 authority may return only a
byte-identical acceptance already retained for that exact request. `REVOKED`
authority returns no acceptance, including a retained one. The V22 rule,
certificate commitments, authenticated peer identity, finite service limits,
signed offer and acceptance, and authenticated custody journal remain mandatory;
V23 cannot weaken or replace them.

The receiver is passive. It cannot originate an offer, export a bundle, select
or discover a route, retry, fail over, schedule onward custody, create an
ordinary outbox item, import final-recipient application evidence, or infer
success or delivery. Existing `send`, `serve`, `status`, and `export` commands
remain explicit owner maintenance operations and are not called by receipt.

## Explicit owner dispatch inside the ordinary daemon

Ordinary-daemon sending remains disabled unless the accepted configuration is
V24 and contains one canonical `custody_dispatch_hex` activation. V24 commits
one exact immutable local V23 receiver activation, one exact outbound V22 rule,
one explicitly named enabled route commitment, finite concurrent-dispatch and
attempt limits, finite expiry, and monotonic `ACTIVE`, `RETIRED`, or `REVOKED`
state. It is accepted only when the local identity is both the V23 receiver's
next-hop endpoint and the outbound V22 custodian, all referenced authorities are
current and exact, the route is enabled with matching peer and locator bytes,
and the limits remain subordinate to V23/V22 and ordinary worker capacity.

The authenticated local-control command is:

```text
natrav-overlay custody-dispatch \
  --control PATH \
  --activation ID --activation-generation N \
  --receiver-request HEX64 --dispatch-request HEX64 \
  --reason TEXT [--deadline-ms N]
```

The owner cannot supply a bundle, route, peer, locator, certificate, V22 rule,
or retry switch. The daemon resolves all of them from accepted authority and
retained state. It first validates the exact signed first-hop offer and
acceptance, then proves through the authenticated custody journal that the local
node remains current nonterminal custodian and that the envelope, opaque
capsule, grants, and record prefix are byte-identical. An unresolved prior local
outbound transfer remains eligible for another explicit owner request against
the same retained V22 offer; it does not authorize a new offer identity.

Each owner request has a fresh dispatch request id. Before the V22 attempt
counter or any connection, the daemon durably stores a canonical request record
binding that id to the receiver request, V24/V23/V22/configuration commitments,
outbound request id, and bounded reason. A bounded index maps the dispatch id to
its colocated V22 case. Exact duplicates validate the same bytes and return the
retained result without carrier I/O. A conflicting reuse fails closed. Restart
after reservation recovers an unresolved local result and cannot spend a second
attempt for the same owner request.

One fresh owner request may commit at most one V22 NOS1 attempt. Carrier, TLS,
session, response, or clean-close failure remains unresolved. A later attempt
requires another fresh authenticated owner request and still obeys the same
V22 finite attempt counter. `RETIRED` or expired V24 may recover only an exact
already retained local result; `REVOKED` permits neither a new attempt nor
remote-acceptance replay. Per-operation configuration leases make live policy
changes govern the next operation without invalidating one in-flight durable
boundary.

This is not autonomous forwarding. Passive receipt never calls the dispatcher.
The daemon creates no forwarding queue, scheduler, background worker, timer,
route search, discovery, fallback, second protocol, second listener, second
daemon, or second executable. Dispatch acceptance remains custody evidence, not
final-recipient import, application success, an exact application receipt, or
delivery.

## Read-only owner reconciliation

Revision 0613 adds authenticated `custody-dispatch-status` and
`custody-dispatch-inventory` commands over the existing V24 durable records.
They validate current accepted authority and exact retained state before
returning bounded metadata. They do not invoke the V22 sender, repair an index,
reserve or increment an attempt, open a connection, replay acceptance bytes, or
create forwarding or delivery authority. See `docs/DISPATCH-RECONCILIATION.md`
for the exact contract.

## Canonical messages

The signed offer format is `NHCSO001`. Its request id is SHA-256 over a
versioned domain and the complete byte-identical signed offer. The signed
acceptance format is `NHCSA001`. It binds the request id, offer digest, exact
V22 and V21 authority, receiver accepted-configuration digest, both certificate
commitments, acceptance time, and the complete signed `NHCR0001` custody
acceptance record.

Both messages are bounded by the native application-message limit. Signatures
use the exact handoff signing parties already authorized by the V20/V21 custody
model. A request id reused with different offer bytes is a hard conflict. One
custody envelope cannot be rebound to a second request id.

## Durable crash boundaries

Service state is owner-private under:

```text
STATE/custody-session-v1/RULE_ID/RULE_GENERATION/
  cases/REQUEST_ID/
  envelope-index/ENVELOPE_SHA256
```

The sender durably writes the exact signed offer, envelope index, zero attempt
count, and unresolved state before carrier use. Before every connection attempt
it atomically increments and fsyncs the persistent attempt counter. Carrier,
TLS, session, response, or clean-close failure never becomes acceptance.

The receiver durably writes the exact offer before admission. It separately
signs and durably writes the byte-identical acceptance before returning a NOS1
response, then records the acceptance through the existing authenticated
`NodeState` custody journal. A response lost after receiver commit leaves the
sender unresolved. Restart or retry may return only the retained exact
acceptance. The sender durably retains that acceptance before applying the same
journal transition locally.

Revision 0610's retained fixture controls external process death with
bounded environment pauses before and after offer publication, envelope-index
reconstruction, attempt increment, receiver acceptance publication, receiver
journal commit, sender acceptance publication, and sender journal commit.
The process is killed by the test harness. The product exposes no crash-injection
or fault-schedule command.

The existing authenticated configuration journal and `NodeState` custody
journal remain the authority and evidence ledgers. The service directory is a
bounded crash-recovery cache of exact protocol bytes and counters; it is not a
parallel custody ledger.

## Retained current-custodian export

An owner can materialize the exact bundle already held by a receiver:

```text
natrav-overlay custody-service-v1-export \
  --config FILE --rule ID --rule-generation N \
  --request HEX64 --output NEWFILE
```

The command validates the retained signed offer and acceptance against the exact
V22/V21/configuration/certificate authority, then reads the authenticated
custody case. It succeeds only when the local node is the exact current
nonterminal custodian and the journal's envelope, capsule, grants, record prefix,
and last acceptance match the retained protocol bytes. It does not mutate the
authenticated custody journal or retained service case, writes only the new
owner-selected output file, performs no network I/O, and selects no route.
Once an onward acceptance moves custody away, the same export is rejected.

## Explicit two-transition composition

`A → R → B` is not one relay instruction. It is two independent transitions:

1. A names an explicit route and invokes an ACTIVE A-to-R V22 rule bound to its
   exact V21 grant and endpoint certificates.
2. R receives and durably records the first acceptance. That fact creates no
   B connection, no second service case, and no background work.
3. While R remains current custodian, an owner explicitly exports the exact
   authenticated retained bundle.
4. The owner separately invokes an ACTIVE R-to-B V22 rule with its own V21
   grant, certificate commitments, route, limits, offer, and acceptance.

The two request identities, service cases, authorities, attempts, and signed
acceptances are distinct. Response loss and retry on the second transition
recover only its exact retained acceptance. Route switching, certificate
mismatch, capacity or attempt exhaustion, expiry, retirement, revocation, and
stale configuration are rejected under the same finite authority rules.

## Lifecycle

- `ACTIVE` V21 and V22 authority may create a new offer.
- `RETIRED` authority may reconstruct a local accepted fact and may recover an
  already retained exact receiver acceptance, but it cannot create a new offer.
- `REVOKED` authority cannot listen, originate, retry, export, or return a
  retained acceptance. Already durable local historical facts are not erased.

Accepted V22 generations cannot be removed, redefined, downgraded, or moved to
a less restrictive lifecycle state during activation or journal replay.

## Commands

All commands are subcommands of the single normal executable:

```text
natrav-overlay custody-service-v1-send \
  --config FILE --rule ID --rule-generation N --route ROUTE_ID --bundle FILE

natrav-overlay custody-service-v1-serve \
  --config FILE --rule ID --rule-generation N [--once yes|no]

natrav-overlay custody-service-v1-status \
  --config FILE --rule ID --rule-generation N [--bundle FILE]

natrav-overlay custody-service-v1-export \
  --config FILE --rule ID --rule-generation N \
  --request HEX64 --output NEWFILE

natrav-overlay custody-service-v1-version

natrav-overlay custody-dispatch \
  --control PATH \
  --activation ID --activation-generation N \
  --receiver-request HEX64 --dispatch-request HEX64 \
  --reason TEXT [--deadline-ms N]
```

`custody-dispatch` is synchronous and performs at most one newly committed
network attempt for one fresh authenticated owner request. Exact duplicate
requests recover the retained result and do not connect. `send` is synchronous
and performs at most one newly committed network attempt
per invocation. An unresolved case requires another explicit invocation. There
is no background retry worker. `serve` exposes only the configured local
listener and the native authenticated peer-session callback. `status` and
`export` perform no network I/O and do not select a route.

## Non-goals and negative authority

A custody acceptance transfers responsibility for one exact custody transition.
It is not final-recipient capsule import, application admission, action
execution, an exact application receipt, or evidence of delivery. The service
does not add peer discovery, route search, automatic failover, opportunistic
forwarding, transparent bridging, onward scheduling, global consensus, or an
open relay. Two configured routes remain two separately named choices; failure
of one never authorizes the other.

The revision-0612 focal suites retain every V21-V23 durability and explicit
A-to-R-to-B check and add canonical V24 validation, exact route commitment,
authenticated owner dispatch, duplicate idempotency, one-attempt reservation,
peer-response loss, fresh-request retry discipline, process death after durable
reservation, stale-seed restart, concurrent ordinary application progress,
retirement, revocation, downgrade rejection, and explicit absence of automatic
sending or forwarding.
