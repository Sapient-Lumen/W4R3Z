# Deterministic configured-adapter adversity — revision 0597

## Purpose and authority boundary

Revision 0597 verifies the configured V19 adapter path under bounded packet and
process faults. It does not add a new production carrier and does not give a
test fixture any identity, authorization, receipt, custody, discovery,
forwarding, or relay authority.

Two complete persistent `natrav-overlay` nodes still resolve exact immutable
endpoint and profile generations, verify and seal the operator-pinned adapter
ELF, supervise it over `NAPA0001`, reconstruct an ordered stream through the
finite packet service, and authenticate the remote node with TLS 1.3 and
HELLO. Application completion still requires the exact authenticated receipt.

## Packet schedule

Packet faults use the existing canonical
`NATRAV_UDP_ADVERSARY_SCHEDULE_V1` fixture. The schedule has explicit finite
bounds for datagram bytes, pending emissions, trace records and fault rules.
The two-path relay injects:

- loss;
- duplication;
- corruption;
- bounded delay; and
- bounded reordering.

Its canonical trace records path, direction, ordinal, action, size and input
hash. Structural replay compares path, direction, ordinal, action and size.
It deliberately does not require independent TLS handshakes to produce the
same encrypted bytes.

## Process schedule

The independently compiled pinned adapter fixture accepts only this canonical
line-oriented schedule:

```text
NATRAV_CONFIGURED_ADAPTER_PROCESS_SCHEDULE_V1
feature=DETERMINISTIC_CONFIGURED_ADAPTER_PROCESS_ADVERSARY_V1
name=<lowercase-slug>
maximum-trace-records=<16..4096>
startup-action=<PASS|FAIL|SILENT>
startup-count=<0..64>
startup-silence-ms=<0..60000>
silent-transmit-ordinal=<0..1000000>
silent-receive-ordinal=<0..1000000>
silent-response-ms=<0..60000>
crash-transmit-ordinal=<0..1000000>
```

Field order, decimal spelling, trailing newline, relationships between fields,
and all bounds are exact. The fixture reloads the schedule before each request
but rejects any live change to the trace bound. A locked canonical launch-state
file supplies the launch ordinal. Each process writes a bounded canonical
`NATRAV_CONFIGURED_ADAPTER_PROCESS_TRACE_V1` account through atomic replacement.
The product does not parse either file.

## Lifecycle semantics exercised

The complete-node focal work distinguishes three outcomes:

1. **Startup budget exhaustion before authentication.** Three silent adapter
   starts exhaust the profile's bounded launch attempts. The durable obligation
   remains pending and its application-attempt count remains zero.
2. **Silent NAPA response after authentication.** A response is withheld on an
   exact transmit ordinal of an existing authenticated session. The attempted
   application write may consume one application attempt; the obligation
   remains pending. Recovery requires a new process, carrier, TLS handshake and
   HELLO before an exact receipt can complete it.
3. **Runtime process death after authentication.** The fixture exits on an exact
   transmit ordinal. The old carrier and encrypted session are retired. The
   obligation remains durable and completes only after fresh authentication and
   an exact receipt.

Packet duplication does not duplicate application admission. Packet faults do
not become application receipts. Route failure before authentication and a
failed application write after authentication remain separately accounted.

## CPU-contention replay boundary

The same fixed packet schedule is run once normally and once with two bounded
CPU burners. Both complete bidirectional authenticated operations, and the
non-pass fault signature is required to match in path, direction, ordinal,
action and packet size. Ciphertext hashes are excluded because fresh TLS
randomness is intentional.

## Verification limits

This is same-host model evidence using local processes, loopback UDP and
generated test identities. It is not independent-host or hardware evidence. It
does not verify serial electrical characteristics, USB adapter behavior, radio,
Bluetooth, EMI, range, power consumption, device drivers or physical power
loss. The adapter is also not a complete hostile same-UID sandbox.
