# Design summary

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Recipient provenance boundary

The current recipient path distinguishes network authentication, original envelope storage, explicit import authority, embedded source claims and later local read/computation authority. One native import transaction materializes original bytes without relabeling remote evidence as local authorship. [View design](SUBSCRIBED-SOURCE-VIEWS.md).

NATravOverlay is a persistent C++ node, not merely a NAT adapter. Its architecture separates:

1. **Identity and transport** — pinned mutual TLS, HELLO binding, reusable bounded sessions.
2. **Application state** — immutable evidence, corrections, receipts, authorization, and a narrow action kernel.
3. **Durable obligations** — governed outbox outcomes, retries, quotas, cancellation, expiry, and replay.
4. **Configuration and membership** — accepted generations, rollback, key generations, and a bounded historical peer registry.
5. **Storage and operations** — stable ownership, journal recovery, checkpoints, compaction, backup/restore, and explicit relocation.
6. **Local administration** — kernel-authenticated Unix principals, exact command classes, durable security decisions, and reconstructable service lifecycle.

The current product preserves several important separations:

- filesystem reachability is not command authorization;
- successful inspection is not a state mutation;
- quiescing local mutation does not cancel durable network obligations;
- a drain deadline is not proof that all work completed;
- process death during drain is not permission to reopen mutation admission;
- moving storage is not rotating identity or broadening administrators;
- backup signing is not backup encryption;
- unkeyed corruption detection is not hostile-writer authentication.

Explicit journal authentication and backup confidentiality are now separate optional layers. A trusted key-required launch verifies all record MACs before semantic replay; a valid old complete chain still carries no latest-head guarantee.

The product uses explicit bounded sets of configured numeric endpoints per authenticated peer. NATrav can later be one route provider without replacing durable identity, delivery, administration, or storage machinery.

## Revision 0577 — carrier-neutral connection ownership

Revision 0577 leaves every accepted endpoint and protocol byte unchanged while
separating peer connectivity from the TCP implementation. Configuration and
route policy now carry a typed `TransportLocator`; outbound construction passes
through `TransportConnector`; listening and acceptance pass through
`TransportListener`; and queues own `OrderedByteStream` instances rather than
bare peer socket descriptors. The sole accepted transport kind remains `tcp`,
and unknown kinds fail closed.

This revision established the ownership boundary but still left a temporary
native TLS descriptor. Revision 0578 closes that historical seam with an owned
OpenSSL BIO over `ByteChannel`, preserving exception containment, deadlines,
short-I/O counters, shutdown ordering, mutual-authentication policy, and exact
wire bytes. See [the extraction contract](TRANSPORT-EXTRACTION.md) and
[the TLS adapter contract](TLS-BYTE-CHANNEL.md).

## Revision 0578 — TLS over the carrier-neutral byte channel

Revision 0578 removes the remaining native-socket assumption from peer TLS.
`TlsChannel` receives `ByteChannel&`; a private owned custom OpenSSL BIO performs
bounded carrier reads and writes using the caller's absolute deadline. Callback
state is per TLS channel, all C callbacks are nonthrowing, and the first exact
C++ failure is retained and rethrown only after OpenSSL returns.

The SSL object owns and frees its BIO while the adapter callback state remains
alive, and the caller-owned stream outlives the TLS channel. TLS 1.3 policy,
ALPN, generation/SPKI identity selection, framing, close semantics, and every
external or persisted byte remain unchanged. This makes a deterministic
non-descriptor carrier possible without introducing a second TLS stack. See
[the TLS/ByteChannel contract](TLS-BYTE-CHANNEL.md).

## Storage trust layers

The canonical application state preserves evidence, obligations and policy provenance independently of physical representation. `NOAUTH01` authenticates node/schema, key history, checkpoint binding and each subsequent event using a separate state key. `NOBACK01` signs/binds an exported checkpoint where selected; `NOBENC01` encrypts that entire container with a separate backup key. An encryption key, signing certificate and state key confer different checks and are not interchangeable.

Migration explicitly adopts preexisting unkeyed state. Authentication does not retroactively establish its truth. Key rotation records a verified transition and changes the storage epoch without changing the application logical digest. A valid old snapshot still verifies; stronger expected-head checks need a deliberately protected reference, not a replaceable file mislabeled as an external truth source.

Normal startup rejects every incomplete authenticated tail. Revision 0504 adds a noncreating audit and explicit maximal-prefix adoption with exact source selection, mandatory original-source preservation, validated checkpoint publication and authenticated recovery provenance. This does not weaken startup's verify-before-apply boundary or prove the cause of truncation. State verification remains bounded but in memory. Runtime authority includes the actual executable, protected key custody, and the process-launch requirement, not just a pathname stored beside mutable state.

## Evidence reads (0505–0507)

The local query path reauthorizes kernel UID command and domain authority after request decoding under an accepted-generation lease. V9 retains explicit node-wide compatibility; V10 intersects exact domains before counts, roots, links or payload errors. Hidden writes do not perturb scoped metadata positions or cursor roots. Derived ordered history/current indexes and a fixed 32-entry root cache avoid repeated settled-selection hashing. Cold work streams bounded metadata batches and checks for relevant changes after releasing the state mutex. Payloads are never copied into a query snapshot; normal replay remains authoritative. The next step is bounded incremental evidence consumption. [Scoped reads](SCOPED-READS.md).

## Internal transactional processing

Revision 0510 adds one explicit native metadata projection. Its materialized result is part of the durable consumer, not an external side effect and not a second database. Result, source batch and progress are validated and committed together; checkpoint replay independently reconstructs source-derived totals. See [projection contract](PROJECTIONS.md).

## Payload-authorized internal processing (0511)

The numeric definition demonstrates useful internal computation on the result/progress transaction: strict fixed-point schema, opaque exact units, finite arithmetic budgets and attributable invalid inputs. Metadata authority is not numeric authority. No external action or general-purpose evaluator is added. Opt-in bounded scheduling now supplies explicit attribution and active-policy checks without an external Python loop. See [numeric contract](NUMERIC-PROJECTIONS.md).

## Native ongoing computation (0512)

A single bounded round-robin worker performs explicitly delegated internal projection steps. Permission, consumer epoch, source-derived result, progress and finite work accounting share a durable boundary; scheduling is not a general external action executor. Admission wakeups and observational empty checks replace required client polling. [Contract](AUTOMATIC-PROJECTIONS.md).

## Revision 0513 — retirement

An irreversible local retirement records the selected final consumer state and terminal schedule as one transaction. Active-slot reclamation is separated from history retention: names stay reserved, the archive has its own finite quota, and no old client can bind to a replacement. This preserves identity safety without claiming infinite storage or cross-snapshot freshness. [Design contract](CONSUMER-RETIREMENT.md).

## Explicit derived-evidence disclosure (0514)

Projection computation and disclosure are separate authorities. One selected source-derived result becomes a canonical NPP1 evidence record only after current owner, read, projection, consumer, submission, recipient-route, and key-generation checks. The stable record binds result and authority semantics; the local journal separately binds the accepted runtime configuration event. Enqueue reuses the existing atomic evidence-plus-policy record and every existing outbox outcome. [Contract](PROJECTION-PUBLICATION.md).

## Durable derived-result correction channels (0515)

Revision 0515 turns repeated disclosure of one projection to one recipient/scope into a first-class linear lifecycle. It preserves three separations:

- internal computation authority is not remote-disclosure authority;
- queuing a derived result is not remote admission;
- a socket-level success or failure is not an acknowledged correction predecessor.

The first channel record is an original. A later result becomes an ordinary correction only after the prior outbox operation has a durable receipt. Channel provenance and the new outbox obligation share one journal transition. This keeps recipient current-view semantics aligned with sender durable state without creating a second transport or mutable remote object.

Retirement is terminal and may atomically cancel one pending head, but it never rewrites an admitted record, treats rejected work as acknowledged, or recycles the channel name. [Contract](PUBLICATION-CHANNELS.md).


## Finite automatic disclosure (0516)

Automatic remote publication is modeled as a separate finite delegation, not as a side effect of automatic internal computation. One fair worker rotates through channel candidates; durable outbox schedulers still own transport and delivery retry.

The load-bearing boundary is one journal transaction containing channel advancement, ordinary evidence-plus-policy enqueue, and grant consumption. Caught-up observations are nonmutating. Source-derived terminal blocks stop one grant without converting another channel's delay into global failure. [Contract](AUTOMATIC-PUBLICATION.md).


## Terminal publication discontinuities

Remote result channels are linear only within one explicit epoch. A durable receipt is still required before a correction can extend that line. When the head is rejected, cancelled, or expired, revision 0517 requires an owner-selected epoch transition and emits a new original carrying canonical terminal-lineage metadata. The design preserves the broken line instead of fabricating acknowledgment or silently rebasing automatic disclosure.


## Revision 0518 — bounded route sets

Peer identity and application obligation are no longer conflated with one socket address. V13 binds one peer and durable delivery policy to one through eight stable numeric route candidates. Every candidate must complete the same TLS key-generation and HELLO identity checks.

Route selection sits below the peer protocol. TCP/TLS/HELLO/session-open failures may move to another candidate before the application request is issued, so path probing does not multiply durable application attempts. Once the request is sent, ordinary receipt/replay/rejection semantics remain authoritative.

Route configuration is durable accepted policy; failure counters, cooldown and current selection are run-scoped observations. Reusable sessions bind a selected route contract and are selectively retired when that contract changes. This provides a seam for later NATrav, relay or discovery inputs without making any of them product prerequisites. [Contract](MULTI-ROUTE.md).

## Exact pending accounting

Derived global and per-recipient pending count/byte aggregates share the authoritative outbox indexing hook. Admission reads the global and target-peer totals; composite transitions use the same release/reacquisition semantics. Only pending contributors occupy this derivative. Replay and checkpoints reconstruct it; the full scan remains an independent test reference, not an admission path. [Contract](PENDING-CAPACITY.md).

## Counter-action result plane (0543)

V18 separates authenticated action admission from disclosure of the terminal result. The admitted action retains a historical result rule and exact return-key binding. One semantic transaction commits the local terminal counter state and a canonical result evidence obligation through the existing delivery plane. Local effect receipts and remote delivery receipts remain distinct. See [ACTION-RESULTS.md](ACTION-RESULTS.md).

## Request-centric action-result discovery

The [bounded discovery reader](RESULT-DISCOVERY.md) uses the exact report validator and replay-derived candidate roots. Ephemeral authenticated cursors carry cumulative classifications, never durable authority or proof of execution. Changes to selected evidence or the original receipt/key facts require restarting the scan. No report is materialized as a local effect by inspection.

## Private deterministic carrier boundary

Revision 0579 proves that the extracted transport and OpenSSL BIO boundaries are usable without a native TCP descriptor. A fixture-owned virtual link supplies two `OrderedByteStream` endpoints, while the production peer stack remains unchanged. Canonical schedule and trace formats are verification artifacts only and are not peer-wire protocols. See [VIRTUAL-CARRIER.md](VIRTUAL-CARRIER.md).

## Explicit POSIX serial carrier boundary

Revision 0580 turns the carrier-neutral seam into a production non-IP path. A
canonical `serial-v1` locator binds one absolute device path and complete line
settings. `serial_transport.cpp` owns final-symlink rejection, character-device
validation, exclusivity, termios application/restoration, finite I/O quanta,
deadlines, interruption, hangup, and reconnect classification.

The serial path is reachability only. It supplies no identity, trust,
authorization, routing authority, or receipt. The same OpenSSL BIO, TLS 1.3
generation/SPKI checks, HELLO, NOS1, application framing, durable obligation,
and receipt machinery used over TCP run unchanged above it. A TTY explicitly
lacks TCP write-half-close capability; semantic closure is NOS1 plus TLS
close-notify. See [SERIAL-TRANSPORT.md](SERIAL-TRANSPORT.md).
