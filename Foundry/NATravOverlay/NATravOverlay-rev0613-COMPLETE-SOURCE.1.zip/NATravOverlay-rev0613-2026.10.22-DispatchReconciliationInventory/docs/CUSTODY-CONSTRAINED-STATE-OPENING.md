# Custody-constrained authenticated-state opening

Revision 0573 lets commands that already accept an exact external `NASH1`
condition consume that condition directly from one explicitly named detached
`NHCUST01` custody record.

The strict alternative is:

```text
--expected-state-head-custody FILE
--expected-custody-domain LABEL
--expected-custody-generation N
--expected-custody-digest HEX64
```

All four options are required together. They are mutually exclusive with a raw
`--expected-state-head` and, for audit or recovery, with the legacy
`--expected-root` / `--expected-records` pair.

The adapter applies only to commands that already accepted an external exact
head: `run`, `serve`, `offer`, `correct`, `flush`, `inspect`, `backup-export`,
`backup-verify`, `backup-restore`, `backup-reencrypt`, `state-relocate`,
`state-auth-rotate`, `state-auth-audit`, `state-auth-recover`,
`correlated-stop-audit`, and `backup-correlated-stop-audit`.

## One expectation implementation

The custody path does not add a second authenticated-state comparison.
Process entry:

1. opens the explicitly named custody parent without following symbolic links;
2. takes a nonblocking shared advisory lock on that parent;
3. opens and completely reads the named record through the retained parent
   descriptor;
4. requires a regular, singly linked, effective-user-owned file with exact mode
   `0600` and the existing 1,024-byte ceiling;
5. strictly decodes the canonical `NHCUST01` record and recomputes both its
   content commitment and complete-file SHA-256;
6. requires the exact caller-supplied custody domain, positive decimal custody
   generation, and complete-file digest; and
7. configures the existing process-wide `NASH1` expectation from the record's
   exact selector.

The existing state or checkpoint reader then performs complete authentication
and semantic replay. Only after that existing validation succeeds can its exact
node, authentication generation, key ID, epoch, chain root, record count, and
physical byte count match the extracted `NASH1` selector.

Custody therefore cannot legalize a malformed journal, bypass source or receipt
checks, approve a backup signer, select a recovery prefix, repair an incomplete
tail, or replace the state-authentication key.

## Coherent rechecks

The initially opened custody inode, metadata, complete bytes, and SHA-256 are
retained for the command. The same parent descriptor and filename are reopened
and compared exactly:

- after authenticated input matching; and
- again immediately before a finite command emits an apparently successful
  response.

A path, inode, metadata, length, digest, or byte change fails with
`STATE_HEAD_CUSTODY_REPLACEMENT_RACE`. A failed comparison never falls back to
an unconditioned open.

The custody record is an input condition, not a transaction participant. A
finite command such as rotation, recovery, restore, relocation, or backup
publication can have completed its separately durable product operation before
the final custody recheck detects a later record replacement. In that case the
command suppresses success and reports the custody race; it does not roll back
or conceal the already durable operation. Operators must inspect the resulting
authenticated state before deciding whether to advance custody.

## Daemon startup boundary

`run` and `serve` retain the shared custody lock through state authentication,
semantic reconstruction, listener creation, and the final startup-acceptance
recheck. The process releases the custody descriptor and lock before starting
worker threads or advertising readiness.

After acceptance, the daemon retains only the immutable fact that the exact
opening expectation matched. Normal authorized writes and compaction can
advance the journal. The custody file is not a continuously held lease and is
not updated automatically. A later restart against the unchanged old record
fails once the authenticated representation has advanced.

## Audit, recovery, and backup scope

For a complete state, audit compares the exact final authenticated head. For an
incomplete tail, the existing audit can report a verified maximal prefix and
recovery eligibility, but custody does not authorize repair. Recovery still
requires the existing source digest, prefix root/count/byte boundary, preserved
source path, reason, and eligible tail shape.

Backup readers compare custody with the completely authenticated embedded
checkpoint, not the outer encrypted-file representation. Backup identity,
signer verification, authenticated decryption, and exact optional backup-ID
checks remain separate requirements.

Restore and relocation use custody only as the exact input condition. Their
resulting state heads are reported separately and are never written to the
custody file.

## Meaning and limitations

The adapter proves only that the fully validated input equals the selector in
one explicitly selected, separately managed custody record whose exact
custodian account also matched.

It is not:

- node or local-control permission;
- recovery, restore, retry, or destructive-operation authorization;
- a state-authentication or backup-decryption key;
- a response receipt or idempotency key;
- a global clock or remote witness;
- proof that no divergent authenticated branch exists; or
- proof that the selected record is the newest record an operator has ever
  accepted.

A valid old state and its corresponding old custody record still match. The
operator remains responsible for separately protecting and selecting the
intended custody file and for explicitly advancing it after reviewing a new
head.

## Compatibility

Revision 0573 changes no journal, authenticated header, checkpoint, encrypted
backup, NSS/NST, application logical-state, peer, local-control, permission,
configuration, storage-schema, or product-limit encoding. It adds only CLI
input handling and command-local custody verification.

Revision 0572 rejects the new options as unknown arguments. It does not ignore
or reinterpret them.
