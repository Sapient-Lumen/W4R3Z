# Supervised external packet-adapter boundary — revision 0589 with revision-0591 profile delta

Revision 0589 adds a private process boundary for complete-datagram carriers
that should not be linked into the NATravOverlay authority process.

The boundary is deliberately below peer identity and application authority:

```text
explicitly selected adapter process
→ inherited Unix SOCK_SEQPACKET descriptor 3
→ canonical NAPA0001 request/response protocol
→ OwnedCompleteDatagramPacketPort
→ finite NPL1 packet service
→ PacketPortOrderedByteStream
→ OpenSSL BIO → TLS 1.3 → HELLO → NOS1 → application operations and receipts
```

The adapter is carrier plumbing. It may negotiate a bounded profile and MTU,
transmit one complete datagram, return one complete datagram, report finite
backpressure, or fail. It cannot assert a NATravOverlay peer identity,
authorization, application success, durable receipt, custody state, route
policy, or relay permission.

## Launch boundary

The core accepts one canonical absolute executable path and one exact argument
vector. It rejects symlink executables, non-regular files, files writable by
group or other users, executables not owned by the effective user or root, and
unbounded argument vectors.

The child receives only:

- standard descriptors 0, 1, and 2 redirected to `/dev/null`;
- the core-created `SOCK_SEQPACKET` endpoint at descriptor 3; and
- the exact environment variables `NATRAV_ADAPTER_FD=3`,
  `NATRAV_ADAPTER_PROTOCOL=NAPA0001`, `LANG=C`, `LC_ALL=C`, and
  `PYTHONDONTWRITEBYTECODE=1`.

The child closes unrelated descriptors, sets a parent-death signal, enables
`no_new_privs`, and runs under an owner-only umask. Startup has a finite attempt
count and bounded exponential backoff. Runtime death fails the current carrier
rather than silently resurrecting an authenticated stream.

This is a protocol and descriptor-isolation boundary, not a complete hostile
same-UID sandbox. A process running under the same operating-system identity
may retain filesystem and process-inspection powers allowed by that operating
system. A future configured adapter profile must add explicit privilege and
executable-image policy rather than claiming this debt has disappeared.

## Operator-pinned profile and exact image

The revision-0591 bounded delta defines `OPERATOR_PINNED_ADAPTER_PROFILE_V1`.
A canonical profile binds a stable identifier and generation to the exact
absolute executable path, exact executable SHA-256 digest, exact argument
vector, negotiated carrier bounds, deadlines, launch budget, and restart
policy. A successor must use the next generation and name the SHA-256 of the
predecessor's complete canonical record.

A profile-backed launch opens every path component without following symlinks,
hashes the exact opened bytes, rejects unsafe ownership or mode, copies the
approved ELF image into a sealed `memfd`, and executes that descriptor with
`execveat(..., AT_EMPTY_PATH)`. The supervisor therefore never validates one
pathname object and later launches another. Path replacement or deletion after
preparation does not change the image used for bounded restarts.

The profile-backed options retain the canonical profile digest and compare every
launch field before `fork`. Any mutation is rejected as `ADAPTER_PROFILE_DRIFT`.
The legacy unpinned options path remains only for the private revision-0589
fixture compatibility surface; persistent configured routes must use the
profile factory after the durable configuration integration is complete.

See [Operator-pinned external adapter profiles](ADAPTER-PROFILES.md).

## NAPA0001

Every frame has a fixed 36-byte big-endian header:

- eight-byte magic `NAPA0001`;
- frame type, flags, and reserved field;
- nonzero request sequence;
- request deadline budget in milliseconds;
- status;
- payload length; and
- CRC-32 over the canonical header prefix and payload.

The protocol defines bounded HELLO, transmit, receive, ping, shutdown, and
fault frames. One request may be outstanding. The negotiated profile cannot
exceed the core's requested MTU, maximum frame bytes, queued bytes, or
outstanding-request count. Truncation, malformed encodings, unexpected
sequence identifiers, unsolicited frames, partial `SOCK_SEQPACKET` writes,
invalid statuses, and capability expansion fail closed.

## Supervision and uncertainty

A startup crash or malformed HELLO may consume one of the finite launch
attempts. Backoff is bounded. Once a port has entered service, adapter death,
protocol reset, timeout, or malformed output becomes an explicit carrier
failure. The current stream is not transparently reconstructed because doing
so could erase uncertainty about which encrypted bytes reached the medium.

Durable application obligations remain above the carrier. A later route retry
may construct a fresh adapter process and a fresh authenticated session without
claiming that the failed session completed.

Runtime EOF, hangup, or reset-like descriptor failure records one bounded
`child_exit` event before `PEER_RESET` is exposed. If the kernel reports the
protocol endpoint terminal before `waitpid(WNOHANG)` exposes a wait status, the
event uses status `UINT32_MAX` to mean "status not yet observable". Later
reaping and destruction do not increment the exit count again. This preserves
the failure evidence without claiming a wait status that was not available.

## Fixture evidence

The revision-0589 fixture translates adapter datagrams through two explicit
Unix datagram paths and supports deterministic ordinal schedules for:

- backpressure;
- loss;
- duplication;
- corruption;
- delay;
- reordering;
- startup crash;
- runtime crash;
- resource exhaustion;
- malformed HELLO and runtime output; and
- orderly shutdown.

The focal profile keeps retransmission finite while allowing 2.56 seconds for
process scheduling (`4` logical ticks × `5 ms` × `128` attempts). This avoids
misclassifying ordinary same-host scheduling delay as deterministic packet
loss while retaining a hard retry bound.

The focal probe carries the real finite packet service, ordered stream, TLS
1.3 mutual authentication, HELLO, NOS1, two application operations, exact
bound receipts, and authenticated close through two supervised child
processes. A second run constructs fresh children and a fresh authenticated
session.

The fixture is not a radio, Bluetooth, USB, acoustic, satellite, or other
physical-medium verification. It proves only the recorded local process,
protocol, packet, and authenticated-stack behavior.

## Non-goals

Revision 0589 does not add a configured adapter locator, dynamic shared-object
loading, hardware discovery, directory scanning, source learning, transparent
forwarding, relay, or a second product executable.
