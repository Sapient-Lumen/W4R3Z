# V19 durable adapter configuration — revision 0595

## What is implemented

`NATRAV_OVERLAY_CONFIG_V19` adds retained operator-pinned adapter profiles and
endpoint records to the ordinary versioned runtime configuration. It uses the
existing `config-activate` command, kernel-authenticated local-control principal,
`CONFIGURATION` permission, serialized admission, authenticated configuration
journal, checkpoint, and restart reconstruction. It does not create a second
owner database or a second authoritative catalog file.

This increment is **policy integration, not configured adapter execution**.
TCP, serial, UDP, and Unix datagrams remain the configured carriers. The private
supervised adapter remains private. Both `version` and V19 `config-check` expose
that limitation explicitly with a false configured-transport flag.

## Canonical representation

V19 accepts these repeatable fields:

```text
adapter_profile_hex=<lowercase hexadecimal of complete NATRAV_ADAPTER_PROFILE_V1 record>
adapter_endpoint_hex=<lowercase hexadecimal of complete NATRAV_ADAPTER_ENDPOINT_V1 record>
```

Encode every byte of the existing canonical record, including its final newline.
The inner record encodings do not change. The outer hexadecimal envelope makes
line separators and percent-escaped argument bytes unambiguous inside the
existing line-oriented configuration. No shell or command interpolation occurs.

A reproducible encoding example, applied to an already-canonical record file:

```sh
python3 -B -c 'from pathlib import Path; print("adapter_profile_hex=" + Path("profile.txt").read_bytes().hex())'
```

The input record must be nonempty canonical ASCII without NUL; hexadecimal must
be lowercase and even-length. The decoded envelope is bounded to 32,768 bytes;
existing profile/endpoint parsers impose their tighter record-specific limits.
The entire configuration remains limited to 65,536 bytes. At most 64 retained
profile generations and 64 retained endpoint generations are accepted, and the
whole-configuration byte bound may bind first. Older versions reject the new
fields rather than ignore them.

Profiles are normalized by stable identifier and numeric generation. Endpoint
records are normalized the same way. Input line ordering and comments therefore
do not alter the canonical configuration digest. Duplicate exact generations
are errors even when their contents are identical.

## Exact history and authorization

Every identifier begins at generation one and an all-zero predecessor digest.
Successors advance by exactly one and bind the complete predecessor's canonical
SHA-256. Endpoint role is immutable. Every endpoint resolves the exact retained
profile generation and verifies its complete canonical digest. Adding profile
generation two does not upgrade an endpoint that names generation one.

Initial policy is admitted through the existing explicit local-startup
configuration boundary. Later changes require the existing owner or delegated
`CONFIGURATION` principal. Admission is rechecked under the publication gate.
Accepted canonical bytes and their digest become part of the ordinary durable
configuration event. Unauthorized clients cannot create a configuration event;
authorized but invalid proposals use the existing bounded rejection record and
do not publish their candidate text or reserve a generation.

The accepted adapter record history is append-only across configuration events.
Every previously accepted profile and endpoint generation must still be present
with identical contents. This is checked at activation and on restart against
all retained accepted events. Rejected proposals are not part of that history.

Explicit rollback cannot remove adapter history or redefine a generation. An
old V18 file cannot erase V19 records. A rollback to an older V19 configuration
that lacks later accepted records is also rejected. To restore other policy,
submit a new configuration generation retaining all accepted adapter records.
This is intentionally more conservative than silently resurrecting an old
executable policy. Record retention is not endpoint activation or revocation;
those execution semantics are the next bounded integration step.

## Authority and storage decision

The separate `DurableAdapterProfileCatalog` from the earlier bounded delta is
retained as a tested component. It is not made a second runtime authority.
Maintaining independently committed catalog and configuration journals would
introduce a publication/recovery ambiguity. The product's existing authenticated
configuration event already supplies durable admission and an exact commitment
for these relatively small bounded records. V19 therefore uses that event as
the authority and reuses the catalog's record and transition validators.

No adapter process is started by parsing, inspecting, admitting, replaying, or
checkpointing these records. An absent executable is permissible as retained
policy; it must be reopened, hashed, sealed, and matched to the exact accepted
profile at the later configured-launch boundary. The existing private exact-image
and supervised-process implementations remain available for that work.

Inspection exposes identifiers, generations and record digests, not adapter
executable paths or argument vectors. Configuration files themselves and the
owner-private authenticated state still contain the full canonical records.
Do not place credentials in adapter argument vectors; their bytes are durable
operator policy, not a secret-storage mechanism.

## Verification and limits

`run_runtime_adapter_configuration.py` exercises the real product: V6–V18
compatibility, V19 canonicalization, malformed records, duplicate generations,
record bounds, real kernel UID authority, authorized succession, forbidden
historical rewriting and erasure, forced process stop, restart, checkpoint,
offline authenticated inspection, and pending TCP work with an exact receipt.

`run_runtime_adapter_configuration_sanitizer.py` exercises the exact policy
translation units with ASan, UBSan, and leak detection. It does not instrument
the entire daemon or claim a physical power-loss experiment.

No configured adapter route, adapter-backed persistent-node lifecycle, radio,
Bluetooth, USB packet device, independent physical host, or electrical behavior
is established by this increment. The TCP pending-work case is not an adapter
transport test. Missing hardware is verification debt, not a construction veto.

## Mandatory next integration

Resolve an explicit endpoint identifier and generation from the active immutable
V19 configuration lease. Verify its profile digest, derive launch options only
through the pinned-profile preparation path, and attach that immutable prepared
context to the owned connector/listener. Do not accept arbitrary executables in
transport locators or consult an unanchored filesystem catalog to override the
active configuration. Preserve the existing fixed-listener boundary unless a
separately bounded activation mechanism is implemented and verified.

Then exercise two complete nodes through fixture adapters: startup failure,
process death, bounded reconstruction, fresh TLS/HELLO authentication, pending
obligations, exact receipts, shutdown and restart. Keep route failures before
authentication distinct from application delivery attempts. No other physical
carrier or relay work should displace this remaining integration.
