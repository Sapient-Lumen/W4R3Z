# V19 exact configured adapter execution — revision 0596 (adversity verified in 0597)

## Authority and activation

Revision 0595 stored immutable retained adapter policy. Revision 0596 makes
explicit routes and listeners consume that policy. The authority remains the
ordinary authenticated RuntimeConfiguration / NodeState configuration event,
not an independent mutable catalog file. Configuration checking, parsing,
checkpoint replay and policy acceptance do not open an executable or spawn a
process. An unreferenced profile remains inert even when its image is absent.

The new carrier locator refers to an **endpoint**, not directly to a program:

```text
adapter-endpoint-v1|id=radio-out|generation=1
```

The identifier begins with a lowercase ASCII letter, contains only lowercase
letters, digits, hyphen and underscore, and is at most 64 bytes. The generation
is an exact nonzero canonical decimal uint64, without leading zeroes. The
complete locator is bounded to 160 bytes. No arguments, executable paths,
profile substitution, `latest`, source learning or discovery are accepted.
The retained endpoint's existing inner `adapter-v1|profile=...` record and
profile commitment remain unchanged.

Example placements in a complete V19 configuration:

```text
listen=adapter-endpoint-v1|id=radio-in|generation=1
peer_route=REMOTE,radio,0,ENABLED,adapter-endpoint-v1|id=radio-out|generation=1
```

These lines do not suffice on their own. The same accepted configuration must
retain the matching canonical endpoint and profile records in
`adapter_endpoint_hex` and `adapter_profile_hex`. Normal TLS identity, trust,
authorization, quotas and peer policy remain required. The listener must resolve
a listener-role endpoint; outbound routes must resolve route-role endpoints.
Missing or wrong generations, wrong roles, stale commitments and duplicate
active uses of the same endpoint identifier are rejected before execution.
Distinct endpoint identifiers are not proof that an external physical resource
is distinct; adapters still own their explicit device/port exclusivity rules.

## Exact immutable snapshot

The outbound scheduler holds its existing RuntimeConfiguration generation
lease through selection and establishment. The connector factory copies the
exact resolved canonical endpoint and profile from that accepted snapshot.
The connector rejects use with a different locator. It never reads authority
from a sidecar catalog and never constructs options from arbitrary route text.

All launch options derive through `external_packet_adapter_options_from_profile`.
Each new carrier reopens, checks, hashes and seals the pinned executable image;
it does not borrow a previously cached image after an adapter failure. Bounded
startup retries within that one preparation may reuse the already sealed image.
Runtime death retires the carrier and TLS session. A later scheduler attempt
requires a new image preparation, adapter process, TLS handshake and HELLO.

Historical profile and endpoint records remain immutable. Selecting generation
two is an explicit route change; retaining it does not upgrade a generation-one
route. Existing listener service-layout immutability is retained. No hot listener
replacement is added by this revision.

## Ownership and deadlines

A configured listener admits at most one owned stream at a time. A nonblocking,
close-on-exec CLOCK_MONOTONIC timer descriptor supplies at most two admission
opportunities per second. An admission represents a local carrier lease, not an
authenticated peer. Expirations are drained even while a lease is active.

The main accept/control thread never hashes an image, forks a child or waits
for NAPA. It hands a deferred stream to an existing bounded peer worker. That
worker starts the carrier on its first TLS byte operation. Destruction reaps
the child and releases the image before releasing the listener lease.

Configured startup and retry backoff are capped by the caller's absolute
operation deadline. Configured process-backed finite packet streams opt into
propagating that same deadline to every synchronous NAPA request. This is an
explicit `PacketPortOrderedStreamOptions` option. Legacy private fixtures retain
their previous per-RPC timeout behavior; enabling the tighter option there would
change their intentional short-slice raw pumping semantics. UDP and Unix
socket ports retain their nonblocking packet operations.

A timed-out configured protocol exchange is terminal for that carrier: late
responses are never treated as a fresh request or a resurrected TLS session.
Cleanup has its separately bounded shutdown policy. Deadline checks do not
claim hard real-time guarantees for OS scheduling or uninterruptible filesystem
I/O during exact-image preparation.

The fixed configured finite-stream profile uses the pinned MTU, 64 KiB maximum
messages, 256 KiB each for reassembly and delivery, 16 in-flight frames, 64
control frames, 16 receive packets per pump, a 10 ms logical tick, retransmission
after 50 ticks, eight retries, and expiry after 3,000 ticks. NPL1 and NAPA wire
encodings are unchanged. The profile is finite, not a model of a named radio.

## Error and obligation semantics

Image absence, digest mismatch and startup failure are carrier failures, not
proof that a remote operation happened. Pre-authentication route failure does
not consume an application delivery attempt. By contrast, a write attempted on
an already authenticated session can legitimately consume one attempt even if
its adapter has just died. The receiver's exact authenticated receipt, not an
adapter success response, determines application completion.

The original unprepared `connect_transport` and `listen_transport` entry points
reject this kind with `ADAPTER_AUTHORIZED_CONTEXT_REQUIRED`. Only the persistent
runtime's accepted-policy factories provide configured adapter execution.

## Verification and limits

`node/tests/run_configured_adapter_transport.py` compiles an independent,
test-only C++ NAPA fixture and drives two whole product processes. The fixture
forwards bounded loopback UDP datagrams, knows no TLS keys, and cannot invent
application operations or receipts. The suite covers canonical negatives,
startup failure, bidirectional TLS/HELLO/NOS1 delivery, process death, image
drift, exact-generation succession, immutable listener layout, pending work,
stale-seed restart, receipt binding and local-control responsiveness during a
silent startup. The original execution results live under `validation/revision-0596`.
Deterministic packet/process adversity results live under
`validation/revision-0597`; see `CONFIGURED-ADAPTER-ADVERSITY.md`. Historical
records are not current gates.

No physical hardware or independent host is verified. Main-image pinning does
not pin dynamic libraries, interpreters' script inputs, firmware or drivers.
Descriptor/environment isolation and `no_new_privs` are not a hostile same-UID
sandbox. A same-UID adapter can still access resources available to that UID;
root execution is not privilege separation. Deployments requiring confinement
must add an independently reviewed OS boundary. No confidentiality against a
hostile same-UID process is claimed.

## Primary platform references consulted

Linux timer descriptors, readiness and expiration reads:
https://man7.org/linux/man-pages/man2/timerfd_create.2.html

Linux `no_new_privs` semantics and limitations:
https://docs.kernel.org/userspace-api/no_new_privs.html

These references inform the platform boundary, not product test results.
