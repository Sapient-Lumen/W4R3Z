# Command-local source-composite slices — revision 0562

## Scope

Revision 0562 removes one complete outgoing-composite copy from the live manual and automatic NST3 source-ISSUE command path.

`ParsedSourceProgress` already owns the exact immutable NST3 bytes for the duration of one locked command. Its strict parser now records the outgoing composite's offset and length and exposes a read-only `View` into that owner. The command-local decoded `SourceProgressTransaction` retains its decoded evidence record and policy, but its `outgoing` vector remains empty.

This is deliberately not the generic transaction representation. Independent replay and standalone callers continue to use `decode_source_progress_transaction`, which returns a fully owned transaction and copies the outgoing composite normally.

## Ownership and lifetime

The command object is noncopyable and nonmovable. Its members are declared in lifetime order:

1. Complete owned NST3 bytes.
2. Their digest.
3. Strict decoded syntax and decoder-produced offsets.
4. References and views into those owners.
5. Exact state, predecessor, configuration, journal-position and queue-limit bindings.

The views cannot outlive the object. The object is created only inside `commit_source_progress_locked` while the state mutex is held and is destroyed on success or every exception, including semantic preflight failure and durable append failure. No request, response, journal, checkpoint, backup, status object, worker cache or caller API can carry the slice.

## Bounds and byte binding

The strict parser still reads the declared composite length, enforces the unchanged 66,000-byte composite ceiling, consumes exactly that many bytes and requires end of transaction. It records the offset only after parsing the preceding fixed and variable fields.

Before selecting the command-local view, the implementation independently rechecks:

- Nonzero composite length.
- Offset within the exact owned NST3 bytes.
- Length within the remaining bytes.
- Offset plus length equal to the end of the transaction.
- Absence of an unexpected owned outgoing vector.

A diagnostic forced-owned build stores a private copy instead. Even there, the selected value is accepted only after exact equality with the strict slice.

These slice checks complement, rather than replace, the existing outer transaction bindings. Preflight, pre-append and live application each require exact length and byte equality with the immutable NST3 owner, a matching SHA-256 digest, the exact state owner and predecessor object, subscription instance and revision, structural commitment, active accepted configuration, queue limits and—before append—the original journal position.

Prepared outbound admission still performs its two independent nested byte comparisons and evidence-record validations. Source preflight and live application still independently recheck source order, local authorship, correction ancestry, operation and record identities, policy, payload accounting, actual outbox absence and current capacity, and the exact manual request or finite automatic-grant consequence. ACK still locates and validates the actual durable receipt in both semantic passes.

## Measured copy boundary

The normal and forced-owned executables are built from the same revision-0562 source. The control defines only `NATRAV_SOURCE_PROGRESS_OWNED_OUTGOING`.

| ISSUE fixture | Normal command path | Forced-owned control |
|---|---:|---:|
| Source 128 outgoing composite | 0 owned copies; one 650-byte slice | one 650-byte owned copy; no slice |
| 58,000-byte raw source | 0 owned copies; one 58,426-byte slice | one 58,426-byte owned copy; no slice |

ACK has neither outgoing copy nor outgoing slice. The compact transaction remains 887 bytes at source 128, 58,663 bytes at the large-source boundary and 229 bytes for ACK.

The change removes one explicitly measured vector copy. It does not remove decoding of the evidence record and policy, exact nested comparisons, canonical outbox payload storage and hashing, journal framing and synchronization, or the default legacy response's complete-state digest. It is not claimed as a demonstrated end-to-end latency, allocation-count or peak-memory improvement.

## Replay, failure and compatibility

Untrusted replay receives no command preparation and retains the fully owned generic decode. Checkpoint reconstruction and complete-state lifecycle transitions do not use the slice. Generic publication and action-result writers retain independent outbound decoding.

A private boundary probe closes the journal descriptor only after constructing a valid source command. The semantic preflight succeeds, the real append fails with `JOURNAL_WRITE_FAILED`, the writer becomes poisoned, a retry fails with `STATE_RESTART_REQUIRED`, and neither journal bytes nor logical state advance. Restart reconstructs the unchanged predecessor.

The actual revision-0561 executable reads newly generated revision-0562 uncompacted NST3 history and the subsequent canonical checkpoint, leaves each input unchanged and produces the same corresponding logical-state digest.

No request, journal, NSS/NST, application logical-state, checkpoint, peer-envelope, permission, configuration, storage-schema or size-limit encoding changed.

## Corruption boundary

The private probe independently changes the decoder-produced offset, length, ownership flag and owned bytes, and also exercises malformed lengths, truncation, extension, wrong kinds and wrong-stage use. All are rejected.

The negative-control build removes only the requirement that the outgoing slice end exactly at the end of the strict transaction. It then accepts an offset shifted one byte before the parsed composite. The retained detector fails with:

```text
parsed transaction boundary accepted: outgoing-offset-before-strict-field
```

The weakened source tree and executable are not distributed.
