> Revision 0537 update: the active output format is V14. Configured inventories below are now bounded previews with explicit total/returned/truncated fields; use `runtime-inventory` for complete pages. See [runtime inventories](RUNTIME-INVENTORIES.md) for limits, current-policy checks, continuation and counters-only fallback. The V13 behavior described below is retained only where unchanged (narrow state totals and explicit full hashing).

# Narrow runtime status — revision 0536

## Operation and compatibility

`status --control PATH` returns `NATRAV_OVERLAY_RUNTIME_STATUS_V13`. It requires the actual kernel UID's current `INSPECT` permission; `SUBMIT` and evidence-read grants do not imply it. The common post-decode authorization boundary remains in place. Successful status, including explicit digest inspection, is observational: it appends no successful authorization or application event. Existing denials remain auditable.

The default is a metadata response. `storage.logical_state_digest` is `null`, and `logical_state_digest_mode` is `NOT_REQUESTED`. This is an explicit response-contract change, not a differently defined or cached application digest.

```sh
./node/bin/natrav-overlay status --control /owned/a/control.sock
./node/bin/natrav-overlay status --control /owned/a/control.sock --logical-digest yes
```

The second form computes the complete canonical application representation under the same state mutex as the returned durable metadata. It returns the existing domain-separated logical-state digest with mode `COMPUTED_AT_STATE_OBSERVATION`. No cache is used. It remains linear in retained application state, allocates the full canonical representation, may exceed a configured I/O deadline, and does not claim zero payload-copy work. Use it deliberately for exact reconstruction checks, not as cheap monitoring. Offline `inspect`, checkpoint, backup, and their logical-digest contracts are unchanged.

Legacy control kind 2 remains strict and accepts no trailing material. Explicit full-digest status uses new local control kind 25, also with an empty body and strict EOF. Older binaries reject the unknown request kind rather than silently ignoring the request. The CLI accepts only `yes` or `no`; no peer protocol, permission class, configuration version, journal kind, or storage schema changed.

## One durable-state observation, not one whole-program snapshot

`NodeState::runtime_status_metadata` owns the state mutex while reading exact totals and encoding bounded metadata. It does not construct `StateSnapshot`, copy evidence records or payload vectors, copy consumer/projection/subscription registries, or serialize the application unless explicitly asked for its digest.

The immutable configuration authorizing a status request is captured after decoding. Before releasing that generation lease, the handler copies at most 64 stable peer-statistic pointers. It never traverses the appendable registry container after releasing its publication protection. Pointees remain alive until all control workers are joined. This fixes the prior unsafe registry-container traversal during live peer addition.

Status then releases the configuration publication lease before taking its state observation. An intervening activation can therefore make the state configuration newer than the authorized configuration. `observation.authorized_configuration_digest` and `configuration_state_match` identify that distinction; `runtime_configuration` is the configuration history seen with the durable state. Lifecycle and run counters are separately sampled, explicitly labeled `INDEPENDENT_RUN_OBSERVATIONS`. They are not all sampled atomically with state or with one another. Already authorized bytes may finish transmission after a later revocation.

A controlled race test publishes a new peer after status captures its authorized configuration/registry and before state observation. The reply retains its original three-peer snapshot, reports the new state's accepted generation, and marks the mismatch. The next request sees all four peers. This is an executed concurrency case, not a whole-program race-detector proof.

## Exact totals without whole-history scans

Outbox outcome counts use the existing recipient/outcome ordered indexes. Global and per-recipient pending record/byte totals use `PendingCapacityIndex`. Resolvable pending counts use derived exact generation/SPKI cardinalities in `DeliveryIndex`, including entries whose attempt allowance is exhausted but whose expiry transition has not yet committed. A missing policy, absent route, absent/mismatched generation, or revoked key remains unresolved. A configured but disabled route retains the preceding semantic meaning: its binding is resolved even though that route cannot currently connect.

Authorized inbound admission count and four action-outcome totals are derived through normal admission/action replay hooks. Local authorship and subscribed-source materialization are not relabeled as authorized peer admission. Action completion, cancellation, expiry, and checkpoint reconstruction update the same totals. Repeated action-index notifications are idempotent.

All these structures derive from already validated durable state; no independently trusted summary is serialized. Restart, compaction, and restore reconstruct them. A poisoned writer refuses status rather than exposing a partially applied derivative as healthy. Index memory grows with retained records or pending bindings; counts and summaries are not a constant-memory database.

## Bounded detail and honest truncation

Outbox and action arrays retain first-in-queue-order semantics. They show at most 64 rows each, subject additionally to 24,576 bytes of outbox row JSON and 8,192 bytes of action row JSON. `entries_returned` states the actual number. `entries_truncated` compares it with the exact total, including byte-budget truncation. Nonfitting rows are removed whole, never partially returned. Work may include one inspected nonfitting row.

Each displayed outbox row shows at most its last 16 transitions. The active rejection is computed from only the final validated transition, not by rehashing every historical rejection. Per-operation exact lookup and complete transition pagination remain available through [outbox-query](OUTBOX-INSPECTION.md).

Configuration history retains its last eight events and sixteen mutation bindings, with real total counts and truncation markers. Status formats those directly from state rather than copying canonical configuration vectors. Relocation path provenance retains its preceding redaction rules.

Keyed-state status shows at most the latest four key-history accounts and four recovery accounts, with total counts and truncation flags. Offline inspection still returns its full retained history. The current authentication root is not the application logical digest and still reports `freshness: NOT_ESTABLISHED`.

The complete status before principal annotation is capped at 64,000 bytes, below the existing 65,000-byte control cap. Exceptionally large accepted policy or route inventories can still exceed that budget and produce the typed `STATUS_RESPONSE_LIMIT`; no response limit is silently enlarged. Dedicated bounded inventory APIs are a next construction opportunity. These arrays are summaries, not complete enumeration promises.

## Work observations

`status_work` is scoped to the calling thread's locked state-selection method. It counts displayed/nonfitting outbox and action metadata visits, tail transition and active-rejection reads, aggregate/binding lookups, full snapshot calls/payload copies, and explicitly requested logical bytes/encodings. It excludes request decode, authorization, accepted-configuration processing, live route/statistic rendering, transport framing, other threads, and incidental metadata string allocation. Zero `snapshot_payload_bytes` proves no full snapshot at that instrumented boundary, not zero total process allocation.

The large independent fixture has 8,192 inbound records (16 MiB of payload) and 4,096 settled operations. Twelve ordinary polls serialize zero logical bytes and invoke zero snapshots. Its large maintenance fixture explicitly allows 30 seconds for control/compaction, after an initial sanitizer compaction exceeded five seconds; ordinary status requests still use a five-second client deadline. The independent standalone offline replay has a 60-second test-process allowance after a ten-second sanitizer wrapper timeout. Other fixtures and product defaults are unchanged. Explicit full mode produces a nonnull digest that matches offline decoding of captured, unchanged state. This is retained synthetic history, not thousands of networked peers and not a wall-clock speedup comparison.

Other cases exercise all five outbox outcomes, transition-tail truncation, zero-byte reservations, removed routes, actual counter completion/cancellation/expiry, 64 real concurrent peer deliveries, strict independent request encoding, real UIDs, live revocation, registry publication, keyed audit/compaction, signed encrypted restore, relocation and later releases. The production binding-cardinality differential test independently counts policy-bearing bindings after randomized notifications, including exhausted attempts and missing policies.

## Boundaries

Mutex synchronization is not wait-free. Full digest mode remains expensive. Authenticated-tail recovery, unkeyed compatibility, complete-valid-snapshot rollback, copied-state divergence and host compromise are unchanged. Testing uses local controlled processes on one Linux kernel, not independent physical hosts or universal power-loss conditions. Static OpenSSL/glibc portability warnings remain applicable.

## Retained configuration inspection (0538)

[configuration-history](CONFIGURATION-HISTORY.md) supplies exact event/binding lookup and bounded retained-prefix pages under current INSPECT. It omits canonical contents, reason text and relocation paths while preserving their commitments. Prefix selection does not grant authority or establish freshness. Runtime-bound mutation bindings are an explicitly described subset, not the entire effect or local-control audit log. Local request kind 27 (NHC1) introduces no new persistent encoding or peer protocol.

Complete action metadata beyond the status preview is available through [action-query](ACTION-INSPECTION.md). It preserves current INSPECT and does not infer execution from control authorization.

## Future result accounting (0544)

Global and peer queue accounts now distinguish future_result_records/future_result_payload_bytes from actual pending operations, plus their committed sum. Inspecting capacity does not synthesize a result operation before its terminal transaction. See [result-capacity contract](RESULT-CAPACITY.md).
