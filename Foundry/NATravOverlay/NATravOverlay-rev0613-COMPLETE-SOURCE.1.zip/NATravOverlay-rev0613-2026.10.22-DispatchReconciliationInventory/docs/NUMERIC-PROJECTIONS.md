# Numeric projections — definition 0511, scheduling integration 0512

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Explicit subscribed observations

An authorized recipient view now exposes the original NNO1 bytes to this numeric definition. Import pins provider admission, subscription and source lineage; projection separately requires exact target-domain payload access. It does not recursively unwrap arbitrary envelopes or validate physical measurements. [Subscribed-source view contract](SUBSCRIBED-SOURCE-VIEWS.md).

`NUMERIC_SUMMARY_V1` is a deliberately bounded fixed-point interpretation over one exact issuer/scope. It reuses the result/progress transaction from [metadata projections](PROJECTIONS.md). It is not a plugin, expression engine, truth evaluator, unit-conversion service, or arbitrary external action. Optional automatic execution is provided separately by the [bounded native scheduler](AUTOMATIC-PROJECTIONS.md).

## Native producer and registration

```sh
./node/bin/natrav-overlay submit --control /owned/a/control.sock \
  --node A --peer B --scope observations/temperature --operation HEX64 \
  --numeric-ticks 2150 --numeric-unit degC --numeric-scale 2

./node/bin/natrav-overlay projection-create --control /owned/b/control.sock \
  --consumer temperatures --definition NUMERIC_SUMMARY_V1 \
  --issuer A --scope observations/temperature --unit degC --scale 2 \
  --max-abs-sum 1000000000 --max-admissions 100000 --limit 32 \
  --reason 'maintain this exact fixed-point summary'

./node/bin/natrav-overlay consumer-read --control /owned/b/control.sock \
  --consumer temperatures
./node/bin/natrav-overlay projection-process --control /owned/b/control.sock \
  --consumer temperatures --batch HEX64
./node/bin/natrav-overlay projection-status --control /owned/b/control.sock \
  --consumer temperatures
```

`revise` supports the same numeric payload options plus `--corrects`. Numeric options are mutually exclusive with `--payload-text` and `--payload-file`; all three numeric options are required. Decimal ticks are canonical signed integers: no plus sign, leading zeroes, negative zero, whitespace, decimal point, exponent, locale, floating-point or NaN coercion. The ordinary binary-file input remains useful for independent encoders and invalid-input tests. Native one-shot development producers also accept the numeric options; they do not become the protected persistent runtime.

2150 with scale 2 denotes exactly 21.50 units. Units are opaque, case-sensitive identifiers, not physically validated measurements. The implementation never converts `degC` to `K`, or scale 2 to scale 3. It never merges evidence from different issuers/scopes into this definition.

## Exact NNO1 payload

All multibyte integers are big endian. The only accepted encoding is:

| Field | Bytes | Meaning |
|---|---:|---|
| Magic | 4 | ASCII `NNO1` |
| Scale | 1 | Decimal fractional digits, 0..9 |
| Unit length | 1 | 1..32 |
| Unit | unit length | `[A-Za-z][A-Za-z0-9_./%\-]{0,31}` |
| Ticks | 8 | Signed two's-complement integer |

The total length must be exactly `14 + unit_length` (15..46 bytes). Every decoded accepted value is within **-10^12 through +10^12 ticks**, inclusive. Even though the wire uses a signed 64-bit integer, larger magnitudes are explicitly rejected. Trailing bytes, truncated fields, other versions, invalid unit bytes and scales outside 0..9 are malformed. No value is read beyond the provided buffer.

Interpretation precedence is stable: structural/schema validity, exact unit, exact scale, then value range. For example, a structurally valid wrong-unit payload yields UNIT_MISMATCH, regardless of its value. The independent Python interpreter and native differential test specify this order.

## Authority is payload authority

V12 remains the explicit projection-adoption boundary; no configuration version or implied grant changes. The owner must have PROJECTION, CONSUMER, EVIDENCE_READ and EVIDENCE_PAYLOAD, and an exact PAYLOAD domain matching the registered issuer/scope. Metadata-only permission cannot create, process, inspect, or indirectly expose the result through `consumer-status`. Rebuild additionally requires CONSUMER_ADMIN.

The stored selection uses payload mode and a 46-byte prefix, sufficient for every valid NNO1 payload. Interpretation checks the full immutable stored payload length/content, not a truncated numeric value. Oversized malformed payloads therefore have bounded preview material and an explicit MALFORMED outcome. Every local operation uses the current kernel UID and current scoped authority; automatic operations instead identify the real daemon acting under a rechecked durable owner grant; changed authority freezes processing/result access until explicit authorized rebuild. Opening a socket before revocation does not preserve old authority. Offline inspect/state-file access remains a separate filesystem trust boundary.

## Results, invalid inputs and corrections

The existing metadata totals and ordered source digest remain. The additional `numeric` result contains cumulative accepted/rejected admissions, current valid/invalid heads, exact signed `sum_ticks` as a **decimal JSON string**, and cumulative rejection counts by four codes:

* MALFORMED: invalid or unsupported byte schema.
* UNIT_MISMATCH or SCALE_MISMATCH: incompatible with the immutable definition.
* VALUE_RANGE: ticks outside +/-10^12.

The latest bounded page retains one outcome code for each `last_source_operations` ID, in matching order. The underlying evidence is not erased, denied at transport admission, or silently omitted. Historical outcomes outside that page remain reconstructable from evidence, definition and the ordered source commitment; there is no unbounded per-input outcome list in the result.

An invalid original contributes an invalid current head, not a numeric zero. An invalid correction supersedes its valid predecessor and removes that predecessor's contribution; it does not silently retain the old measurement. Correcting an invalid head with a valid observation replaces it with a valid contribution. Valid-to-valid and invalid-to-invalid corrections are handled explicitly. Independent originals remain plural.

`sum_ticks` is the sum of current **valid** heads at the processed frontier. `valid_heads` is its denominator for an application computing a rational mean; no rounded/floating mean is computed by this definition. With zero valid heads, sum zero is an empty aggregate, not a measurement of zero. Later unprocessed corrections do not retroactively alter the saved result. Source IDs and digests identify the exact processed evidence; they do not establish observation truth.

## Arithmetic and failure boundary

A definition fixes exact unit/scale, the existing 1..1,000,000 admission budget and a new `maximum_absolute_sum_ticks` in 1..10^18. The default is 10^18. Unit, scale, sum budget, selection, admission budget, UID and consumer instance enter its definition digest.

Counts and signed arithmetic are checked before update. Removing a correction predecessor and adding its successor form one per-admission sum transition. After each admission, the corrected sum must fit the immutable absolute budget. A violating intermediate admission fails even if a later record in the same page would cancel it. This avoids page-size-dependent results. Invalid schema/unit/value outcomes are consumed with explicit rejection accounting; **aggregate budget exhaustion is different**: it returns PROJECTION_NUMERIC_SUM_LIMIT and leaves the entire pending page, result and acknowledged position unchanged.

Generic consumer ACK/reset cannot skip a violating record or detach result from progress. Rebuild recomputes under the same immutable definition, not a larger budget. Selecting a larger budget requires another named definition/consumer; [Explicit retirement](CONSUMER-RETIREMENT.md) can release an active slot under a new-name-only, bounded retained-archive contract. No automatic policy enlargement or silent input dropping occurs.

The maximum individual magnitude and admission count imply a maximum mathematical magnitude of 10^18 for a well-formed result, within signed 64-bit range. Runtime arithmetic checks remain in place and are tested directly with deliberately inconsistent near-limit candidates.

## Storage and compatibility

Ordinary metadata `DOMAIN_SUMMARY_V1` keeps exact NPR1 bytes and its existing digest contract. Numeric state uses NPR2 inside existing NCS2 consumer state, journal kind 27 and NDC1 checkpoint material. NPR2 includes the numeric definition, per-frontier numeric counters and sum, bounded retired results, source IDs and per-source latest outcome codes. Retained result history uses the same definition across at most 32 epochs.

Numeric registration uses exact NCR2; only projection-create is legal in NCR2 and requires a numeric definition. Other consumer requests retain NCR1. Older executables fail closed on NCR2/NPR2 instead of silently downgrading or dropping numeric results. Metadata and ordinary-consumer encoding remains backward-readable.

Journal replay recomputes each numeric result from the exact issued page. Checkpoint loading reconstructs the current and retired frontiers from retained evidence. The normal authenticated decoder performs these semantic checks after MAC verification. A valid unkeyed checksum or keyed MAC is not a substitute for source/result coupling.

Creation, issue, process and rebuild preserve the existing atomic journal boundary, duplicate handling and owner/configuration provenance. One synchronized consumer update carries numeric result and acknowledged position together. Rebuild resets both while retaining the preceding result and adoption reason. The latest acknowledged page is idempotent; this is not an unlimited receipt history.

## Bounded response and computation

The existing 128-global / 16-per-UID active consumer registry, 128-input pages and 60,000-byte annotated JSON limit remain. Numeric page selection reserves 24,576 bytes for preceding result/source/outcome metadata **before** issuance. Every valid numeric input fits in the fixed 46-byte payload preview. The remaining page budget can reduce rows below the requested limit; no partial row is silently skipped.

Status and ordinary duplicate process responses scan no whole input history. Processing and transition validation make bounded source/parent visits. Checkpoint/rebuild validation remains linear through the largest retained frontier per projection, not constant time. State and indexes remain memory resident. [Explicit automatic scheduling](AUTOMATIC-PROJECTIONS.md) is available under a separate finite owner grant. There is no streaming numeric input, variance, extrema, time window, cross-domain join, currency conversion or arbitrary expression language.

## Validation and limitations

[Testing](TESTING.md) and the [validation account](../validation/VALIDATION.json) identify completed fresh runs. Nine new integrated cases use real C++ TLS producers and independent encoders/interpreters; exact signed edges, invalid replacements, immutable budgets, real UID payload revocation, concurrent processors, lost replies, before/after-commit SIGKILL, keyed compaction, signed encrypted restore/relocation, source/result corruption and complete history/response bounds. A separate native test exercises 100,000 random admissions/corrections, one million maximum-valued originals, direct overflow candidates and 50,000 arbitrary payloads.

The internal journal transaction is not exactly-once arbitrary external effects. Restoring an old valid state can replay prior progress; no freshness oracle, split-brain prevention, host-compromise protection or universal physical-power-loss proof is added. Failed partial authenticated writes continue to require explicit audit/recovery. Python is test machinery only. No owner CLI, NATrav executable or outside machine is required to build the next increment.
