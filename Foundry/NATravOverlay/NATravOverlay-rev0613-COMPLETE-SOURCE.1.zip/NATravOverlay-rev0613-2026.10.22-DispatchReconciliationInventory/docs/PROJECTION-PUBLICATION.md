# Projection-result publication — revision 0514

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

Revision 0514 adds explicit, owner-authorized publication of a built-in projection result through the ordinary durable evidence outbox.

This is not a plugin, a remote query, an automatic disclosure rule, or a second transport. It selects one exact local result, constructs one bounded canonical evidence record, and reuses the existing recipient-key binding, queue governance, TLS session, application admission, receipt, rejection, retry, compaction, and backup machinery.

## Command

```text
projection-publish
  --control PATH
  --consumer NAME
  --instance HEX64
  --expected-revision N
  --expected-position N
  --result-digest HEX64
  --peer NODE
  --scope SCOPE
```

The request uses strict `NCR5` under the existing local-control consumer variant. The command is mutating and follows the ordinary quiesce/drain gate.

The exact selectors are obtained from `projection-status`:

- immutable projection instance;
- current consumer revision;
- acknowledged/processed position;
- `projection_result_digest`;
- projection name owned by the kernel-authenticated UID.

A changed revision, frontier, digest, instance, or owner fails before queue mutation. The caller must observe the new result and make another explicit publication decision.

## Authority boundary

A successful publication requires all of the following under the accepted active V12 configuration:

1. Linux `SO_PEERCRED` identifies the owner UID.
2. That UID holds `PROJECTION`.
3. That UID holds `CONSUMER`.
4. That UID holds `SUBMIT`.
5. Current exact evidence-read policy still permits the projection's source issuer and scope.
6. Numeric projections still have payload-read authority.
7. The chosen recipient has a configured active route and exact key generation.
8. The output scope is syntactically valid and is not the built-in action-request scope.

`ALL`, `INSPECT`, `CONSUMER_ADMIN`, retirement inspection, and an automatic internal processing grant do not imply result-disclosure authority.

The recipient independently applies its authenticated peer/scope admission policy. A terminal recipient denial becomes the existing durable sender-side `REJECTED` state and creates no recipient evidence record.

## Canonical `NPP1` payload

`NPP1` is an ordinary binary evidence payload carried inside the existing `NOA1` record. It is not a new peer message kind.

The payload binds, in canonical order:

- projection definition kind: `DOMAIN_SUMMARY_V1` or `NUMERIC_SUMMARY_V1`;
- lifecycle kind: active or retired final;
- owner UID;
- immutable consumer/projection instance;
- consumer revision, epoch, processed position, and acknowledgment count;
- immutable definition digest;
- exact projection-result digest;
- source commitment;
- current read-authority digest;
- publication-authority digest;
- consumer name and exact source issuer/scope;
- recipient node, recipient key generation, and exact SPKI digest;
- output evidence scope;
- immutable admission budget;
- admissions, originals, corrections, historical bytes, current-head bytes, and source digest;
- for numeric results: accepted/rejected counts, valid/invalid heads, signed tick sum, rejection counts, exact unit, scale, and sum budget;
- for retired results: terminal lifecycle revision/time and final consumer/schedule commitments.

Source evidence payloads are not copied into `NPP1`. The result is a derived claim at a defined processed frontier, not a claim that the source observations are true, fresh, complete, or representative.

### Stable authority versus local configuration provenance

The payload uses stable read/disclosure-authority digests rather than the path-sensitive runtime-configuration digest. This keeps an unchanged publication identical across compaction, encrypted backup/restore, and explicit owner-path relocation.

The exact accepted local configuration event that authorized the enqueue remains durable through the existing `runtime_bound_mutation` journal wrapper. The command response also reports that event and configuration digest. Thus path relocation does not multiply recipient evidence, while local audit retains the decision boundary.

## Stable identity and atomic enqueue

The operation ID is:

```text
SHA-256(
  "NATRAV_OVERLAY_PROJECTION_PUBLICATION_OPERATION_V1" || 0x00 || NPP1
)
```

The ordinary evidence-record digest then covers that operation ID, issuer, recipient, scope, and payload.

The node holds the state mutex while it verifies the selected result and calls the existing atomic `outbound_queued_with_policy` path. One synchronized journal record publishes both:

- the immutable evidence record; and
- its exact initial recipient generation/SPKI, retry, expiry, and backoff policy.

There is no intermediate publication account that can exist without the outbox obligation. The `NPP1` evidence record is the attributable publication account.

A retry returns one of the existing queue dispositions:

```text
QUEUED
ALREADY_PENDING
ALREADY_ACKED
ALREADY_REJECTED
```

A retry does not append another operation when the canonical publication is unchanged. Existing expiry and cancellation terminal states remain terminal.

## Result evolution and retirement

A changed processed result produces a different canonical payload and operation ID. Revision 0514 does not automatically link successive publications with an evidence-correction edge. They remain independent attributable publications.

A retired final result may be published only under the same current projection/read/submission authority as an active result. Retirement administrative access alone is insufficient. The terminal lifecycle commitments are included, making an active publication and a later retired-final publication distinct.

## Queue and transport behavior

Publication inherits the existing bounds and states:

- global and per-peer pending-record limits;
- global and per-peer pending-payload-byte limits;
- exact recipient key generation and SPKI binding;
- independent per-peer scheduling;
- reusable bounded TLS 1.3 sessions;
- authenticated typed rejection;
- retry/backoff, attempt budget, expiry, cancellation, and explicit retry/rebind transitions;
- duplicate-safe recipient admission and receipts.

An unavailable recipient leaves a pending obligation. Quota exhaustion fails before mutation. A later receipt, rejection, cancellation, or expiry releases its reservation under the existing rules.

## Crash, maintenance, and recovery behavior

The integration tests kill the publisher immediately before and immediately after the synchronized enqueue boundary.

- Before commit, restart contains no publication; the exact retry queues it once.
- After commit, restart reconstructs the pending publication; the exact retry returns `ALREADY_PENDING`.

Pending and acknowledged publications survive ordinary restart, authenticated-state migration, compaction, signed encrypted backup, restore, and explicit relocation. The restored node delivers the exact original operation and duplicate publication remains idempotent.

Arbitrarily incomplete authenticated journal tails still require the existing explicit audit/recovery procedure. A valid older backup can restore older outbox state; no external freshness anchor or split-brain prevention is added here.

## Explicit limits

- Publication is explicitly invoked. Automatic projection schedules remain internal-only.
- There is no publication-channel registry, refresh schedule, or automatic correction chain.
- The local `SUBMIT` grant is command-level; recipient scope authorization is enforced by the authenticated recipient.
- The deterministic payload excludes request PID and wall-clock time. The response reports the current PID; local journal policy and runtime-binding accounts retain enqueue time and configuration provenance.
- `NPP1` is bounded by the ordinary evidence-payload limit and is constructed in memory.
- Publishing a result does not create an exactly-once transaction with arbitrary external effects.
- Keyed state authenticity still does not establish freshness or single ownership.

## Relationship to revision 0515 channels

The one-shot `projection-publish` command remains available and unchanged. Revision 0515 adds a separate [publication-channel lifecycle](PUBLICATION-CHANNELS.md) for repeated disclosures that must form one acknowledged correction chain.

A channel wraps the same canonical `NPP1` result in `NPC1`, derives a channel-specific operation ID, and commits channel provenance with the ordinary outbox obligation. One-shot publications remain independent originals and are not retroactively adopted into a channel.
