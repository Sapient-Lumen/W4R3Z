# Owner-controlled Unix-domain datagram packet carrier

Revision 0588 adds `unix-dgram-v1` as the second production implementation of
`OwnedCompleteDatagramPacketPort`. It is a local carrier with filesystem
ownership rules; it is not a peer identity mechanism and it is not a general
local IPC replacement.

## Canonical locator

```text
unix-dgram-v1|local=<path>|remote=<path>|mtu=<256..65507>|link=<16-lowercase-hex>|epoch=<nonzero-u32>|profile=1
```

Both paths are percent-encoded canonical absolute paths. The parser rejects
empty components, `.` and `..`, trailing separators, control bytes,
noncanonical escapes, abstract-namespace addresses, and paths that cannot fit
in `sockaddr_un::sun_path`.

The local and remote fields name reachability coordinates only. The link and
epoch fields scope the finite packet service. None is peer identity, authority,
or proof of delivery.

## Path ownership

Before use, the carrier opens every parent component with `O_NOFOLLOW`. The
final parent must:

- be a directory;
- be owned by the effective user;
- grant no group or other permissions; and
- grant owner write and execute permission.

The local leaf must not exist. The carrier does not automatically remove a
pre-existing socket, regular file, symlink, or other occupant. This avoids
turning a guessed stale path into destructive authority.

After binding, the socket node is mode `0600`. The carrier records the parent
and socket device/inode pairs. It rechecks path identity during use and removes
the local node only when the exact observed object remains present.

The remote path must already name an owner-controlled Unix socket in an
owner-controlled parent. A listener accepts datagrams only from the exact
configured remote path and matching effective-user credentials, then connects
the socket to that fixed peer. This is reachability hygiene, not
cryptographic authentication.

## Datagram and stream behavior

The Unix socket is nonblocking and preserves complete datagram boundaries.
The port rejects datagrams reported with `MSG_TRUNC` and enforces the declared
MTU. Bounded polling uses caller-supplied absolute deadlines.

Above the port, the unchanged finite packet service owns:

- NPL1 framing and integrity;
- fragmentation and reassembly;
- acknowledgments and bounded retransmission;
- duplicate suppression;
- expiry and backpressure;
- logical packet time; and
- semantic stream finish.

The resulting `PacketPortOrderedByteStream` carries the existing OpenSSL BIO,
TLS 1.3 mutual authentication, HELLO, NOS1, application operations, receipts,
and authenticated shutdown.

## Listener ownership

One listener object owns one local path. At most one accepted stream lease is
active at a time. Destruction releases the lease and exact owned path. Reopen
uses a bounded delay and repeats all path and ownership checks.

Configuration rejects duplicate local-path ownership, listener/route role
conflicts, and routes whose remote path aliases the local listener path.

## Negative controls

Revision 0588 exercises rejection of:

- noncanonical locators;
- unsafe or symlinked parents;
- pre-existing local occupants;
- path aliases and duplicate leases;
- unauthorized source paths and credentials;
- oversized/truncated datagrams;
- local path replacement;
- deadline expiry; and
- cleanup when the path no longer names the object created by the carrier.

## Residual race and assurance boundary

POSIX path APIs do not provide a single operation that both proves the current
filesystem name still identifies the recorded socket and unlinks precisely that
inode. A hostile same-UID process may race the final check. The implementation
uses directory descriptors, no-follow traversal, device/inode comparisons,
owner-only directories, and a narrow check-to-unlink interval, but does not
claim the residual race is impossible.

Same-host Unix datagram tests establish local path-policy and packet-port model
behavior. They do not establish behavior over Bluetooth, radio, USB packet
devices, independent hosts, electrical faults, range, interference, drivers,
power consumption, or physical power interruption.
