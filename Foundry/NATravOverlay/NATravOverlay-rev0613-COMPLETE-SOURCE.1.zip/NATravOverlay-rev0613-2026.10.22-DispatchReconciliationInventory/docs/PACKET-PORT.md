# Owned complete-datagram packet port

Revision 0586 extracts the smallest reusable ownership boundary beneath the
finite packet service and above a concrete complete-datagram carrier.

```text
concrete complete-datagram carrier
→ OwnedCompleteDatagramPacketPort
→ FinitePacketStream
→ PacketPortOrderedByteStream
→ OrderedByteStream / ByteChannel
→ OpenSSL BIO
→ TLS 1.3, HELLO, NOS1, operations, receipts, close
```

The marker is:

```text
OWNED_COMPLETE_DATAGRAM_PACKET_PORT_V1
```

## Contract

`OwnedCompleteDatagramPacketPort` owns one carrier endpoint for its entire
lifetime. It extends the finite packet state machine's minimal `PacketPort`
callback with only the information needed to turn that callback into an owned,
deadline-bounded ordered stream:

- the concrete `TransportKind`;
- the exact receive/transmit MTU;
- complete packet send and receive operations; and
- a bounded progress wait with an absolute scheduled wake time and an absolute
  caller operation deadline.

The boundary deliberately does not expose peer identity, authorization,
application messages, receipts, relay policy, a universal address type, or a
native socket descriptor.

A concrete port retains its own addressing, source filtering, readiness,
duplex, timing, and failure semantics. The generic adapter does not reinterpret
those properties.

## Ownership

`make_packet_port_ordered_byte_stream()` takes a
`std::unique_ptr<OwnedCompleteDatagramPacketPort>`. The resulting ordered stream
therefore has exclusive carrier ownership.

Destruction order is intentional:

1. destroy `FinitePacketStream` state;
2. destroy generic ordered-stream state; and
3. destroy the concrete port and release its carrier lease or descriptor.

For a listener-originated UDP stream, the UDP port itself owns the active
listener lease. If generic stream construction fails, destruction of the port
releases that lease. No UDP-specific release callback is stored in the generic
adapter.

## Responsibilities above the port

The reusable adapter keeps these behaviors above every concrete packet carrier:

- canonical `NPL1` framing;
- finite fragmentation and reassembly;
- acknowledgments and bounded retransmission;
- duplicate suppression;
- message expiry;
- finite control, in-flight, delivery, and reassembly queues;
- semantic finish and ordered EOF;
- constant-work logical-clock catch-up; and
- reconstruction of `OrderedByteStream` for the unchanged TLS/session stack.

A carrier implementation must not duplicate or bypass those behaviors.

## UDP preservation

`UdpPacketPort` is the first production implementation of the boundary. The
extraction does not change:

- the canonical `udp-v1` locator grammar or bytes;
- numeric-only IPv4/IPv6 parsing;
- bind and connected-source filtering;
- `IPV6_V6ONLY`, disabled broadcast, or socket-buffer policy;
- nonblocking operation;
- MTU and truncation rejection;
- finite packet profile values;
- logical tick interval or shutdown budget;
- listener single-lease and reopen behavior;
- UDP-specific error classifications; or
- any authenticated or persisted protocol outcome.

`udp_transport.cpp` now owns UDP endpoint parsing, socket construction, complete
datagram I/O, polling, errors, and listener lifecycle. It no longer contains a
second `FinitePacketStream`/`OrderedByteStream` reconstruction loop.

## Fixture proof

The focal packet-port probe supplies the same interface with an owned
`AF_UNIX` datagram socket pair. This fixture is not a configured product
carrier. It proves that the seam can be consumed by a second complete-datagram
implementation without importing UDP locators or IP policy.

The probe covers:

- fragmented full-duplex ordered transfer;
- semantic finish and ordered EOF;
- absolute wall-clock deadlines;
- exact MTU agreement between carrier and finite profile; and
- destruction of both owned endpoints, including failed construction.

The configured UDP focal and persistent adversary suites separately exercise
the real TLS, HELLO, NOS1, operation, receipt, close, stop, restart, and recovery
paths through the extracted seam.

## Authority boundary

A port proves only possession of a carrier endpoint and the ability to exchange
complete datagrams. UDP addresses, future Unix paths, link identifiers, epochs,
and fixture descriptors remain reachability coordinates.

Pinned TLS identity and overlay authorization remain above the packet port.

## Assurance boundary

This refactor is not a new physical carrier and does not improve hardware
assurance by itself. An `AF_UNIX` socket pair and loopback UDP cannot establish
radio behavior, independent-host scheduling, NAT/firewall traversal, driver or
electrical correctness, range, interference, power consumption, or physical
power-loss recovery.

Those are verification debts, not construction vetoes.
