# Bounded import decision review and explicit reconsideration

Current view discovery: [manager-scoped source-view inventory](SOURCE-VIEW-INVENTORY.md) exposes retained administrative summaries without changing import or read authority.

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

Revision 0528 adds two native local commands to the persistent node. They use the existing kernel-authenticated Unix control socket and exact V17 `SOURCE_IMPORT` owner policy. The network protocol, configuration version and journal entry kind are unchanged.

## Administrative review is not evidence-read permission

```sh
./node/bin/natrav-overlay source-view-decisions \
  --control state-c/control.sock --view temperature \
  --limit 16 --max-bytes 32768
```

The response format is `NATRAV_OVERLAY_IMPORT_DECISIONS_V1`. It returns bounded administrative events: decision revision and digest, action, typed outcome, accepted configuration event/digest, time, actor UID/GID/PID, reason, source-domain ordinal and exact outer operation identity. Administrative grant/pause events have no outer operation. Manual reconsiderations additionally name their selected earlier decision.

No source bytes, derived payloads, source-author details, projection results, or filesystem identity paths are copied into this surface. Operation identifiers, counts, reasons, timing, and source-domain activity are administrative metadata and are intentionally visible to the view manager. This is not a metadata-oblivious interface. Import permission does not confer `EVIDENCE_READ` or `EVIDENCE_PAYLOAD`; neither `ALL` nor `INSPECT` confers `SOURCE_IMPORT`.

Current kernel UID and command permission are checked after request decoding and retained through selection. The exact retained owner may review a removed view while still holding the command class through another accepted view. A different principal, including the daemon UID, cannot substitute for the owner.

## Stable bounded pagination

Rows are ordered by the one-based retained decision revision. `--after-revision` defaults to zero. A fresh response reports `through_revision` and `history_digest`, selecting an immutable prefix of the append-only history. To continue that prefix:

```sh
./node/bin/natrav-overlay source-view-decisions \
  --control state-c/control.sock --view temperature \
  --after-revision NEXT_AFTER_REVISION \
  --through-revision THROUGH_REVISION --history-digest HEX64 \
  --limit 16 --max-bytes 32768
```

The two prefix selectors must be supplied together. They are commitments to retained state, not bearer authorization. Every page reauthorizes its caller. Later events do not change the selected prefix; the response separately reports `current_revision`. Compaction, restart, and verified restore preserve the prefix while its original events remain present. A different prefix fails with `IMPORT_REVIEW_PREFIX_CONFLICT`. A restored older state that lacks the selected prefix cannot manufacture it. This comparison does not establish global freshness or prevent valid-state rollback.

Limits are 1–32 events per page and 2,048–60,000 bytes for the complete annotated JSON response. Whole rows only are returned. A nonfitting later row ends the page; a nonfitting first row returns `IMPORT_REVIEW_PAGE_TOO_SMALL`. `next_after_revision` identifies the last returned event. An empty page visits zero events. No full history/payload copy or whole-journal scan is used: event selection is direct indexed access, with at most the requested rows plus one byte-sizing lookahead. Original operation identities are resolved through each event's exact configuration and original inbound prefix.

The per-page `decisions_visited` includes byte-sizing lookahead. Accepted configuration parsing and original-domain index lookup still have finite cost; this is not a latency or constant-memory guarantee. Successful review, including empty polling, writes no journal or successful audit record. Ordinary denied requests retain the existing security-audit behavior.

## One exact selective retry

First stop enabled automation with the existing exact-revision pause command. Read the selected decision and the latest schedule/configuration metadata. Then:

```sh
./node/bin/natrav-overlay source-view-retry \
  --control state-c/control.sock --view temperature \
  --expected-revision CURRENT_REVISION \
  --decision-revision SELECTED_EVENT_REVISION --decision-digest HEX64 \
  --operation EXACT_OUTER_OPERATION_HEX64 --view-digest HEX64 \
  --configuration-digest CURRENT_ACCEPTED_CONFIG_HEX64 \
  --reason 'explicitly reconsider this source after approving its binding'
```

The node verifies the owner, immutable view definition, exact original event and outer record, current accepted configuration digest, current provider key and current import policy. The event must have previously skipped or deferred its source; successful imports, duplicates, grant/pause events and unadvanced capacity-blocked scan heads are not retry selections. The ordinary source validator performs all authenticated admission, envelope, exact pin, retained quota, alias/conflict and correction-parent checks.

A new command is refused while automation is `ENABLED`, including caught-up automation. `PAUSED`, `EXHAUSTED`, and `BLOCKED` schedules may be reconsidered under current manager/view/key authority. This command does not adopt new automatic policy or resume the worker. A stale history revision, decision commitment, operation, view or configuration cannot be silently interpreted against new state. A slow request crossing a policy change must satisfy the policy accepted when decoding completes.

### Independent finite manual work allowance

There are at most **64 classified manual reconsiderations per retained view schedule**, derived from history. Each accepted attempt spends one, including an unchanged rejection, duplicate or still-missing dependency. It does not spend or replenish the paused automatic grant's import/inspection counters. Existing ordinary `source-view-import` remains its own explicit manual API; this new bound is not a universal cap on all administrative imports.

The original event and outcome remain immutable. A new `MANUAL_RETRY` event records the new source-derived outcome and the selected earlier event. The existing 1,024-event history ceiling and 64-dependency ceiling also apply. New grants, compaction, restart and relocation never refund manual retries.

An imported source is admitted once under normal retention limits. Exact duplicates remain duplicates. A still-missing parent retains/adds a bounded dependency without busy retrying. Resolved or permanently rejected dependencies are removed; capacity-blocked dependencies are retained. No scan position is rewound or advanced. No source is aliased to a different outer operation. No source payload is returned by this command.

The response is `NATRAV_OVERLAY_IMPORT_RETRY_V1` with `RECONSIDERED`, the new administrative event, and bounded schedule status. Success means the reconsideration was durably classified, not necessarily that import was permitted: inspect its `outcome`.

## Idempotency and concurrent work

An exact repeat selects the same original expected revision, earlier decision, operation, view, accepted configuration and reason. The recorded event at that revision is looked up directly. Under current owner/class/view/key authority it returns `ALREADY_RECONSIDERED`, even after later schedule events or relocation. It is historical confirmation, not a second revalidation, import, allowance charge or automatic resume.

A changed reason or other selector is not that same request. To deliberately reconsider again, use the current revision and configuration and spend another bounded manual attempt. Concurrent identical requests have one committing winner. Current policy removal still denies access; a saved commitment is not a capability.

Service quiescence and drain permit review but reject new manual reconsideration. Automatic and manual state changes serialize under the ordinary state mutex. A successful materialization wakes existing application workers; it does not grant permission to read, compute, or re-export the record.

## Durability, provenance and compatibility

New commands use strict local `NIR2`; the three existing commands retain `NIR1`. New manual decisions use `NIE2` within existing journal kind 34, adding the selected prior revision/digest, outer operation, immutable view digest, and requested accepted configuration digest. Existing `NIE1` bytes remain identical.

One synchronized append derives and commits the import, provenance, dependency change and spent manual allowance. Source replay is shared with normal import; there is no unchecked envelope-unwrapping path. Manual decision effects use `NSV3` with `LOCAL_IMPORT_RETRY`, the actual connected UID/GID/PID, and the exact decision revision. They are not labeled `DAEMON_IMPORT_WORKER` and never acquire local authorship.

The existing bounded `NIH1`/`NIS1` history containers can carry the versioned events. Checkpoint reconstruction evaluates them against their original inbound prefixes and accepted configurations, verifies exact source-derived effects, and recomputes manual usage. Older executables reject unfamiliar `NIE2`/`NSV3` material rather than silently losing its meaning. Never-reconsidered states retain prior durable encodings.

Actual `SIGKILL` tests bracket the synchronized manual commit. Before it, neither effect nor charge exists; after it, both reconstruct together. Exact retry recovers a lost response. Recomputed unkeyed checksums cannot make a forged selected-decision commitment acceptable. Keyed audit, compaction, encrypted signed backup, restore and relocation retain these accounts.

## Remaining boundaries

There is no bulk retry queue, implicit rescan, history deletion, durable review cursor allocation, unlimited idempotency request store, or permission to bypass a conflict. The history and manual bounds are not reclaimable in this increment. Parent import ordering and conflicts remain explicit. Successful administrative reasons and operation commitments are retained sensitive metadata.

A valid older snapshot can restore older progress and allowances. Authentication does not establish freshness, evidence truth, physical independence, or absence of outside effects. Incomplete authenticated tails still fail closed and require explicit audit/recovery. Tests use real local C++ processes and owned storage on one kernel, not independent hosts or universal power-loss conditions.

See [validation](../validation/VALIDATION.json), [attempts](../validation/ATTEMPTS.md), and the [next construction plan](BUILD-PLAN.md).

## Recipient-view terminal lifecycle

A [retired view](VIEW-RETIREMENT.md) remains reviewable by its current authorized owner, but selective retry is refused, including old exact retry requests. Review can include the terminal event at revision 1,025; ordinary processing retains its original history bound.
