# Backup-contained correlated-stop audit

Revision 0571 adds one offline, read-only command for selecting correlated
stopping provenance directly from a signed encrypted backup. It does not
restore or publish a state directory.

```text
natrav-overlay backup-correlated-stop-audit \
  --input stopped-state.nob \
  --node A \
  --generation a-g1 \
  --state-auth-key /protected/state-a-g1.key \
  --decrypt-key /protected/backup-g1.key \
  --trusted-cert /protected/a-g1.crt \
  --correlation ops-20261012-a01 \
  --stop immediate \
  --final-state-head yes
```

The selection may instead use an exact 64-character lowercase request ID.
Exactly one selection form is accepted. The explicit shape is encoded through
the same strict NOC1 functions used by the online correlated-stop commands and
then passed through the existing request-ID construction.

## Verification boundary

A successful report follows this order:

1. Open the existing regular backup file without following a final symlink.
2. Enforce the encryption envelope and supplied decryption-key identity.
3. Authenticate the entire AEAD envelope and decrypt it.
4. Parse the complete inner backup with no trailing bytes.
5. Require a signature, validate it, and bind it to the supplied trusted
   certificate.
6. Require the exact node and identity generation.
7. Recompute and verify the backup identity and embedded-checkpoint digest.
8. Authenticate and semantically validate the entire embedded checkpoint with
   the separately supplied state-authentication key.
9. Enforce an optional exact embedded `NASH1` expectation.
10. Independently replay the checkpoint for the selected request ID and check
    that its authenticated account agrees with the already verified checkpoint.
11. Build one complete bounded report or fail without truncating matches.
12. Reopen and compare the backup size and SHA-256 before returning success.

The command constructs no state writer, restore staging directory, control
endpoint, peer listener, scheduler, or background worker. It performs no tail
repair, recovery, restore, relocation, compaction, re-encryption, or external
expectation update.

## Required inputs

The command requires all of the following:

- `--input FILE`
- `--node ID`
- `--generation ID`
- `--state-auth-key FILE`
- `--decrypt-key FILE`
- `--trusted-cert FILE`
- An exact request ID or an explicit correlated-stop shape

Plaintext and unsigned backups are rejected for this operation. General backup
verification remains available separately for deployments that deliberately
permit either property.

Two independent optional exact conditions are available:

- `--expected-backup-id HEX64` binds the signed inner backup identity.
- `--expected-state-head NASH1:...` binds the embedded authenticated
  checkpoint representation.

Re-encryption preserves the signed inner backup identity and checkpoint head
while changing the outer encrypted file bytes. The report therefore keeps the
outer file digest, backup identity, and embedded state head as three separate
accounts.

## Report

A successful response uses:

```text
NATRAV_OVERLAY_BACKUP_CORRELATED_STOP_AUDIT_V1
```

It contains:

- Exact outer file byte count and SHA-256.
- Backup ID and optional expectation result.
- Encryption-key generation and key ID.
- Signature validation and trusted-signer account.
- Exact node and identity generation.
- Embedded checkpoint byte count and digest.
- Embedded logical-state digest.
- Exact authenticated `NASH1` checkpoint head and optional expectation result.
- Every retained matching authorization-decision row.
- Every retained matching lifecycle row.
- Aggregate stop classification.
- Replay-derived pending outbound and pending action counts.
- Explicit no-writer, no-worker, no-restore, no-mutation, no-freshness, and
  no-automatic-anchor-update labels.

Lifecycle reason text, evidence and source payloads, keys, certificate paths,
identity paths, relocation paths, and recovery reasons are not disclosed.
Reason length and its domain-separated digest remain available through the
shared correlated-stop audit representation.

## Bounds

```text
--max-matches  1..64       default 64
--max-bytes    4096..60000 default 60000
```

The match limit covers authorization and lifecycle rows together. If all rows
do not fit, the command fails with `CORRELATED_STOP_AUDIT_MATCH_LIMIT` or
`CORRELATED_STOP_AUDIT_RESPONSE_TOO_LARGE`. It never silently paginates,
truncates, or deduplicates identical attempts.

## Trust semantics

A request ID or correlation token is provenance only. It is not permission,
idempotency, retry authorization, proof of response receipt, recovery
authority, or a freshness anchor.

Possession of a backup is not enough to produce a successful report. The
operator must also supply the decryption key, the exact state-authentication
key, and a certificate that trusts the backup signer. Those inputs authenticate
what the backup contains; they do not prove that it is the newest separately
observed backup or state.

The product does not record, protect, or advance an external expectation. A
caller that supplies an old valid backup together with its matching old
expectations will receive a matching report. Freshness still depends on
separately protected custody chosen by the operator.

## Failure behavior

The command fails closed for wrong or missing keys, an untrusted signer,
invalid signatures, changed outer or inner bytes, malformed framing, an
unexpected node or generation, an invalid authenticated checkpoint, an
incomplete checkpoint, a mismatching backup ID, a mismatching state head,
invalid selection, excessive matches, or an oversized report.

No output state directory is accepted or created. Failed and successful audits
leave the input backup byte-for-byte unchanged.
