# Compact exact source progress — revision 0555

Contract retained from revision 0555. Its standalone replay measurements and negative-control observations are historical unless explicitly listed in [current validation](../validation/VALIDATION.json). Revision 0556 adds [typed structural response selectors and indexed ancestry](STRUCTURAL-SOURCE-SELECTORS.md) without changing NST3 semantics. Revision 0557 adds [private command-scoped preparation](SOURCE-PREPARATION.md), reducing live manual issuance to one construction. Revision 0558 adds [single-use automatic eligibility reuse](AUTOMATIC-SOURCE-ELIGIBILITY.md), reducing successful AUTO_ISSUE to one construction while preserving ordering and independent replay.

Revision 0559 adds [exact-byte-bound command-local NST3 parsing](PARSED-SOURCE-PROGRESS.md). It shares syntax between live semantic passes, not their independent checks; replay remains independent.

## Product boundary

Ordinary provider-side source progress uses a strict `NST3` transaction inside existing journal kind 32:

- manual `ISSUE`;
- manual `ACK`;
- `AUTO_ISSUE`;
- `AUTO_ACK`.

Creation and all nonordinary lifecycle transitions continue to carry a complete canonical source-subscription state in `NST1` or `NST2`. `NST2` remains the terminal transition form that can carry an outbox cancellation. The storage schema, journal framing, configuration format, peer protocol and permission classes do not change.

`NST3` is not a generic patch language. It names one exact predecessor and one of four closed transition kinds. A decoder derives the resulting state; no supplied complete “after” state is trusted.

## Exact transaction account

Every compact transaction contains:

| Account | Binding |
|---|---|
| Kind | ISSUE, ACK, AUTO_ISSUE or AUTO_ACK |
| Subscription | Exact grant ID and immutable instance digest |
| Predecessor | Exact nonzero revision and process-derived progress commitment |
| Authority | Accepted configuration-event ordinal that must be active at that journal position |
| Provenance | Monotonic time, actual writer PID and either manual request digest or automatic worker account |
| ISSUE | Exact source operation, delivery operation, record digest, raw source-payload byte count, and complete evidence-plus-initial-policy outbox composite |
| ACK | Exact outstanding delivery operation, record digest and digest of the actual durable receipt |
| Automatic | Exact current finite-grant generation, next spent-step count, next schedule revision, executor UID and ENABLED/EXHAUSTED consequence |

The binary decoder rejects unknown kinds, trailing bytes, oversized composites, zero identities, manual/automatic field mixing, issue records with acknowledgment fields, and acknowledgments that carry source/outbox material.

## Predecessor commitment

The node retains a private `SourceSubscriptionCommitment` beside each validated source subscription. It consists of:

- a digest of immutable grant, instance, peer pin, creation, lease, lineage, terminal/reconciliation and retirement facts;
- a domain-separated chain over all complete delivery accounts except the mutable tail, plus the exact tail digest and count;
- a parallel chain over complete automatic-grant accounts except the mutable tail, plus its exact tail digest and count;
- a root over those components and current revision/frontier/budget/transition/provenance fields.

The split prefix/tail form permits exactly two ordinary changes: append one new delivery, or add receipt provenance to the one outstanding tail. Automatic progress may additionally replace only the current automatic-grant tail. A compact record cannot alter an older source, acknowledgment, automatic grant, lease, lineage or budget without changing the predecessor root or failing derived-state checks.

This commitment is **process-local derived metadata**. It is rebuilt from a completely validated canonical state after creation, every full-state transition and checkpoint loading. It is never stored in a checkpoint as a separate assertion, accepted from a caller, granted authority, or treated as freshness proof.

## ISSUE validation and atomicity

Replay requires an acknowledged predecessor, remaining record/byte capacity, the exact next source in the local authored-source order and current disclosure authority. It reconstructs the selected source envelope and canonical delivery policy, then checks:

- local author UID and source scope;
- correction ancestry and recipient-specific mapping;
- source, delivery and record identities;
- source payload byte count;
- subscriber peer, generation and SPKI;
- delivery limits and outbox capacity;
- absence of an existing operation with the same ID.

The ordinary outbox composite and source-subscription progress remain one journal transaction. Semantic preflight uses validate-only application; it does not mutate the in-memory outbox or subscription before the durable append. Replay applies the outbox component and derived progress under the same runtime-bound mutation boundary.

## ACK validation

ACK selects the subscription's single outstanding head. Replay finds the exact ordinary outbox operation and requires its stored durable receipt. It checks operation and record digests, recipient and recorder, and the original generation/SPKI-bound delivery policy. The transaction's receipt commitment must equal the digest of that exact retained receipt.

A transport attempt, terminal failure, queued record or claimed receipt digest is not enough. Missing or changed durable receipt material fails closed. Acknowledgment does not refund source bytes, records or automatic allowance.

## Automatic progress

AUTO_ISSUE and AUTO_ACK require the exact current enabled finite grant. The compact transaction must spend precisely one step, advance the schedule revision once, preserve the grant generation, record the executor UID/PID and become EXHAUSTED exactly at the configured maximum. Its manual request digest must be zero.

A manual step requires the canonical digest of the exact STEP request selecting the predecessor revision and may not spend automatic allowance. The two actor forms cannot be exchanged by editing a flag or adding fields.

## Configuration chronology

The referenced accepted configuration must be the active accepted configuration at the journal position, not merely an older still-retained event. The current disclosure rule must still exactly match the subscription's retained grant and key binding. This check applies to compact progress and historical full-state ordinary progress.

Moving an otherwise valid ACK behind a later accepted policy removal therefore fails. Reordering accepted history or recomputing an unkeyed outer checksum does not turn stale authority into a valid transition.

## Backward decoding and checkpoints

New code reads historical `NST1`/`NST2` full-state records through their original derived-prior-state and semantic validation path. A test-only legacy writer can still emit that representation for comparison. Older binaries do not understand `NST3` and fail closed on the unknown transaction magic.

Compaction emits the existing canonical checkpoint with complete source-subscription states. Checkpoint loading validates every retained source, mapping, outbox policy, receipt, automatic grant, lease and lineage before rebuilding progress commitments. Signed/encrypted backup, restore, authenticated audit/recovery and relocation operate on that canonical state; no compact cache becomes a second storage authority.

## Measured 128-source boundary

The product scenario delivers 64 independent 128-byte originals followed by 64 corrections through actual provider and recipient C++ processes. It reaches 128 acknowledged records and 16,384 spent source-payload bytes.

| Final ordinary transition | Compact transaction | Complete state still encoded for response | Complete state decoded for progress | Retained deliveries copied/compared |
|---|---:|---:|---:|---:|
| ISSUE 128 | 887 bytes | 18,211 bytes | 0 | 0 / 0 |
| ACK 128 | 229 bytes | 18,209 bytes | 0 | 0 / 0 |

All 128 ACK transactions are 229 bytes. ISSUE grows only with the one selected evidence/policy composite; in this fixture it begins at 791 bytes and remains below 1 KiB. The legacy full-state control's last progress transaction is 18,218 bytes.

At ordinary ISSUE/ACK, command preflight and semantic application each validate one changed delivery. Revision 0557 preparation reduces manual ISSUE to one selected-source construction; revision 0558 same-iteration eligibility reuse does the same for successful AUTO_ISSUE. ACK reconstructs no source payload and checks the exact receipt twice. These are calling-thread counters, not whole-process allocation or throughput guarantees.

Uncompacted compact replay decodes one canonical creation state and 256 NST3 records. A same-source full-validator probe can replay those compact records while running complete history checks after each transition; a normal probe can replay 257 legacy full-state records. Logical-state equality, not timing, is the required result. See [fresh machine-readable evidence](../validation/VALIDATION.json).

## Corruption and recovery boundary

Independent owned-fixture mutations with recomputed unkeyed frame checksums reject:

- missing durable head receipt;
- deleted prior issuance;
- changed predecessor commitment;
- forged source-payload accounting;
- forged receipt commitment;
- progress moved behind disclosure removal;
- false automatic allowance;
- automatic progress carrying a manual request;
- wrong configuration event;
- corrupted canonical checkpoint mapping.

Inherited source/lease tests exercise process termination before and after the synchronized append. Authenticated-state, compaction, backup/restore, relocation and post-restore correction paths reconstruct the same obligations. A deliberate build that omits only the compact ACK receipt prerequisite is detected by the missing-receipt regression and is not shipped.

## Limits

The complete bounded subscription still exists in memory and canonical checkpoints. Default legacy responses serialize it to compute the complete-state digest. Revision 0556 adds [explicit compact structural responses and indexed ordinary correction ancestry](STRUCTURAL-SOURCE-SELECTORS.md), without changing the NST3 contract. Complete checkpoint validation remains history-dependent by design. The progress commitment is neither collision-free proof beyond its SHA-256 assumptions nor an external freshness/split-brain anchor.

Testing uses generated identities and loopback peers on one Linux kernel. One-host replay times are diagnostic observations, not portable performance guarantees. [Testing scope](TESTING.md), [attempt register](../validation/ATTEMPTS.md).
