# Source composite ownership transfer — revision 0561

## Scope

Ordinary manual and automatic source ISSUE, untrusted NST3 replay, and every other strict source-composite parse call the same private `read_composite` decoder. Revision 0560 removed two later nested evidence-record decodes but left one local copy at this decoder boundary: the decoder owned a mutable application-message variant, selected its `EvidenceRecord`, then returned a value copied from that record before the caller moved it into `SourceProgressTransaction`.

Revision 0561 returns a private move-only `DecodedSourceComposite`. The strict decoder moves the already-owned `EvidenceRecord` and `OutboundPolicy` into that object; its caller then moves them into the transaction. No caller receives a pointer, cache handle, validated flag, or borrowed mutable payload.

This is an ownership change, not a new semantic path.

## Lifetime and failure boundary

`DecodedSourceComposite` is internal to `source_subscription.cpp`:

- Copy construction and copy assignment are deleted.
- Move construction and move assignment are permitted.
- Its record and policy own their strings and byte vectors.
- The decoded application-message variant remains alive until the move is complete.
- The returned object is consumed before `decode_source_progress_transaction` returns.
- A decoding or validation exception publishes no journal frame and leaves the caller without a partially usable preparation.

The private native probe enforces those type properties at compile time and checks after the decoder returns that the moved record, payload, policy, and canonical encoding remain exact. Sanitizer execution exercises the same return lifetime.

## Checks that remain

The ownership transfer does not remove or remember any admission verdict. The strict decoder still checks:

- The outer operation identifier and both operation prefixes.
- The evidence-message encoding and size bound.
- The delivery policy fields, generation, SPKI, and end-of-input.
- The NST3 delivery operation, record digest, source payload account, and transaction shape.

Prepared source admission still performs two exact nested byte bindings and two evidence-record validations. Source preflight and live application remain independent. Actual outbox absence/capacity, current disclosure configuration, local source authorship, source order, correction ancestry, finite automatic allowance, and canonical store digest/copy remain.

ACK still performs no source-composite decode and both semantic passes still locate and validate the actual durable receipt.

Untrusted replay does not receive the command-local parsed/prepared objects. It performs its own strict NST3 and source-composite parse. It uses the same move-only return only to avoid copying the record that its own independent decoder already owns.

Generic outbound writers retain their independent admission decoder and do not receive `DecodedSourceComposite` or source preparations.

## Measured ownership account

The actual verified revision-0560 executable was freshly run on both fixtures. A same-source control compiled with only `NATRAV_SOURCE_COMPOSITE_COPY_RETURN` restores the former copy while retaining revision-0561 parsing, preparation, and admission behavior.

| ISSUE boundary | Actual 0560 | 0561 normal | Forced-copy control | Canonical store copy retained |
|---|---:|---:|---:|---:|
| Source 128, decoded evidence payload | 423 bytes copied | **0 copied; 423 moved** | 423 bytes copied | 423 bytes |
| 58,000-byte raw source | 58,231 bytes copied | **0 copied; 58,231 moved** | 58,231 bytes copied | 58,231 bytes |

At source 128 the outbound composite remains 650 bytes inside an 887-byte NST3 transaction. At the large boundary it remains 58,426 bytes inside a 58,663-byte NST3 transaction. The existing complete-composite and encoded-record comparisons cover 1,166 and 116,718 input bytes respectively. No format or limit changed.

The change removes one explicit nonempty `std::vector` payload-copy construction per strict source-composite parse. It does not claim a measured allocator-call count: allocator implementation details were not instrumented.

Whole-fixture elapsed observations include Python orchestration, process creation, Unix control, TLS peers, journal synchronization, polling, and shutdown. Fresh single-run observations overlap and do not demonstrate an end-to-end speedup. The attributable result is the exact removed payload copy above, not a throughput claim.

## Compatibility

No request, journal, NSS/NST, application logical-state, checkpoint, peer-envelope, permission, configuration, storage-schema, or size-limit encoding changed. In separate fresh comparisons, revision 0560, the full-canonical reference build, and the forced-independent-outbound build each read exact newly generated uncompacted-journal and checkpoint inputs without changing them and agreed with revision 0561 on the corresponding logical-state digest. These comparisons use the exact input within each run; they are not presented as one shared cross-run byte sequence.

The new diagnostic counters are observational and remain available only through the existing additional current `INSPECT` authority. They are not persisted and do not enter any selector or logical digest.

## Remaining work

The strict NST3 decoder still copies the complete outgoing composite from the reader view into `SourceProgressTransaction::outgoing`: 650 bytes at source 128 and 58,426 bytes at the large boundary. That copy also provides independent ownership for ordinary replay callers. A later change must therefore be narrower than changing the generic transaction type: command-local `ParsedSourceProgress` may retain strict slice offsets into its own immutable NST3 byte owner, while replay and standalone decoders keep owned values. Such work must preserve all pre-append and live-application byte bindings and both semantic passes.
