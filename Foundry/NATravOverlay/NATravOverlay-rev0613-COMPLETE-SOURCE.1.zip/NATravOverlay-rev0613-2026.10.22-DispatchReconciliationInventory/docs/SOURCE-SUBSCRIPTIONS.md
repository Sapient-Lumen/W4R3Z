# Source subscriptions — revision 0524

Revision 0556 adds [explicit structural selector alternatives](STRUCTURAL-SOURCE-SELECTORS.md) and opt-in compact responses. The legacy complete-state selections documented below retain their exact meaning. Structural input is a distinct committed request type, not a renamed legacy digest.


## Compact ordinary progress (revision 0555)

ISSUE, ACK, AUTO_ISSUE and AUTO_ACK now use strict `NST3` transactions bound to the exact predecessor commitment, active accepted configuration, changed source/outbox or durable receipt, and one finite automatic step. Full-state `NST1`/`NST2` remains for creation and complex lifecycle transitions; canonical checkpoints remain complete. Historical records are readable. [Contract](COMPACT-SOURCE-PROGRESS.md).



## Administrative inventory (revision 0551)

`source-subscription-inventory` lists retained provider subscriptions under the actual manager UID and current `SOURCE_DISCLOSE`, without remembered grant IDs. It preserves removed grants as historical metadata and does not step, acknowledge, expire, renew or retire anything. Source payload access is separate. [Inventory contract](SUBSCRIPTION-INVENTORY.md).

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Recipient use in revision 0526

The recipient may explicitly materialize NSE1/NSE2 payloads under its own V17 policy. This does not change provider grant, lease, receipt or local-source eligibility rules. Imported records never receive recipient-local authorship. [Subscribed-source views](SUBSCRIBED-SOURCE-VIEWS.md).

**Revision 0525 addition:** [explicit terminal receipt reconciliation](TERMINAL-RECONCILIATION.md) can adopt an exact stored late receipt without altering the original withdrawal/expiry or scheduling allowance. It uses local `NSR4` and reconciled `NSS6` state in existing journal kind 32; it adds no peer request or automatic authority. Ordinary unreconciled state and old format semantics remain unchanged.


## Product boundary

A source subscription is one provider-managed, finite disclosure of explicitly locally authored evidence in one exact scope to one exact authenticated subscriber key generation.

The machinery reuses the ordinary evidence store, correction model, durable outbox, peer sessions, routes, quotas, retries, terminal outcomes, and receipts. It is not an unrestricted remote query and does not make third-party evidence or ordinary outbound payloads subscription sources.

Eligible source records require validated `local_authorship` provenance for the configured source-author UID and scope. Recipient-facing corrections map the source predecessor to the subscriber's acknowledged delivery of that predecessor.

## Authority layers

The following remain distinct:

1. local authorship permission;
2. local read or projection permission;
3. accepted `SOURCE_DISCLOSE` rule;
4. authenticated subscriber request;
5. provider-manager stepping or automation;
6. subscriber-side authenticated evidence admission.

No layer silently implies another.

## Finite budgets and progress

A disclosure rule fixes maximum record count and raw source-payload bytes. Budgets are spent at enqueue and are not refunded after receipt, rejection, cancellation, expiry, retirement, withdrawal, or lease expiry.

At most one issued source may remain unacknowledged. A later semantic step either:

- issues the next eligible source;
- waits for the current outbox outcome;
- advances the acknowledged source frontier after a durable receipt;
- preserves an unresolved terminal delivery outcome;
- reports caught up or budget exhausted.

The canonical `NSE1` envelope carries the complete original source record and source-lineage commitments. The outer recipient-specific evidence record uses ordinary correction ancestry based on acknowledged subscriber history.

## V15 indefinite and V16 leased grants

V15 uses eight fields and retains the subscription until local retirement or policy loss:

```text
source_disclosure=grant,manager_uid,author_uid,peer,generation,scope,max_records,max_bytes
```

V16 appends:

```text
lease_generation,lease_duration_ms,RETAIN|CANCEL
```

A V16 lease can end through authenticated remote withdrawal or natural expiry. Both stop future selection and automatic steps. `RETAIN` leaves a current pending outbox operation intact; `CANCEL` cancels that exact operation atomically with terminal subscription state. See [subscription leases](SUBSCRIPTION-LEASES.md).

## Commands

Provider local commands:

```text
source-subscription-create
source-subscription-step
source-subscription-status
source-subscription-retire
source-subscription-auto-enable
source-subscription-auto-pause
source-subscription-auto-status
```

Subscriber-side peer commands:

```text
source-subscription-request
source-subscription-remote-status
source-subscription-withdraw   # V16 leased subscriptions only
```

`source-envelope-inspect` decodes an `NSE1` envelope structurally. It is not independent proof of authorship or truth.

## Persistence

Current state uses backward-readable `NSS1`–`NSS4`. `NSS2` adds remote admission, `NSS3` automatic-grant state, and `NSS4` finite lease/terminal state. Journal kind 32 stores each source-subscription transition. `NST2` binds an optional exact outbox cancellation.

State survives normal restart, keyed authentication/audit, compaction, signed encrypted backup, restore, and explicit relocation. Incomplete authenticated tails still require explicit audit/recovery.

## Limits

The registry remains bounded to 64 subscriptions and 16 per manager UID. A subscription carries at most 128 source mappings, one current unacknowledged delivery, 32 automatic-grant generations, and finite accepted disclosure budgets.

The remote subscriber cannot advance, reset, retire, automate, or enlarge the provider's subscription. A lease terminal event cannot recall synchronized or admitted evidence. An older valid backup can restore older progress because no external freshness anchor or split-brain barrier exists.

## Acknowledged successors (0524)

An explicitly selected fully acknowledged terminal lease can seed a provider-managed successor under a fresh finite rule. Own `issued`, `acknowledged`, and byte counters stay per lease; `inherited_acknowledged` and `acknowledged_source_position` expose cumulative position. `NSS5` and `NSE2` retain exact ancestry. Unacknowledged deliveries block adoption. See [lease succession](LEASE-SUCCESSION.md).
