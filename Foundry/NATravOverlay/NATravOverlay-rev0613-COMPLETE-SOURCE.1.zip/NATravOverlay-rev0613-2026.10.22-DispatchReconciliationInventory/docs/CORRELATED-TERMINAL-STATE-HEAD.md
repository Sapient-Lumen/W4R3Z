# Correlated terminal authenticated-state handoff

Revision 0569 adds a strictly opt-in correlation token to the deferred terminal authenticated-head protocols introduced in revision 0566. It solves a narrow provenance problem: byte-identical terminal-head requests have the same request ID, so after a lost reply an operator cannot distinguish a newly intended attempt from an older identical attempt using lifecycle history alone.

Correlation changes the exact request bytes and therefore the existing request ID. It does **not** change stop authority, make a retry idempotent, prove receipt of the response, establish freshness, or update an external expected head.

## Commands

Immediate terminal handoff:

```sh
./node/bin/natrav-overlay shutdown \
  --control state-a/control.sock \
  --correlation ops-20261012-terminal-a01 \
  --final-state-head yes \
  --deadline-ms 20000
```

Draining terminal handoff:

```sh
./node/bin/natrav-overlay drain-shutdown \
  --control state-a/control.sock \
  --reason 'bounded maintenance stop' \
  --drain-deadline-ms 5000 \
  --correlation ops-20261012-terminal-a02 \
  --final-state-head yes \
  --deadline-ms 20000
```

The protocol selection is explicit:

| Options | NOC1 kind | Response |
|---|---:|---|
| `shutdown` | 4 | Existing ordinary shutdown |
| `drain-shutdown` | 14 | Existing ordinary draining shutdown |
| `--final-state-head yes` | 42 / 43 | Existing uncorrelated terminal head |
| `--correlation TOKEN` | 44 / 45 | Correlated ordinary stop |
| `--correlation TOKEN --final-state-head yes` | **46 / 47** | Correlated terminal head |

Kinds 4, 14, 42, 43, 44, and 45 retain their exact wire bytes and successful response formats.

## Canonical token

The token uses the revision-0568 grammar:

```text
[a-z0-9](?:[a-z0-9._-]{0,62}[a-z0-9])?
```

It is 1–64 ASCII bytes, begins and ends alphanumerically, and may contain lowercase letters, digits, `.`, `_`, and `-` internally. Empty, uppercase, non-ASCII, slash-containing, oversized, truncated, extended, or otherwise noncanonical requests fail strict decoding before stop admission.

The token is a public operator label, not a secret. A successful correlated response echoes it. Durable control and lifecycle records retain only the resulting request ID.

## Strict wire and request identity

Immediate correlated terminal shutdown is:

```text
"NOC1" || 0x2e || BE16(token_length) || token
```

Correlated terminal drain is:

```text
"NOC1" || 0x2f ||
BE32(drain_deadline_ms) ||
BE16(reason_length) || reason ||
BE16(token_length) || token
```

The request ID remains the existing exact-byte commitment:

```text
SHA256(
  "NATRAV_OVERLAY_CONTROL_REQUEST_ID_V1" || 0x00 ||
  BE64(length(control_payload)) ||
  control_payload
)
```

An operator can therefore derive the expected ID before transmission. Accepted immediate shutdown records `SHUTDOWN_REQUESTED`. Accepted drain shutdown records `DRAIN_STARTED` and then exactly one of `DRAIN_COMPLETED` or `DRAIN_DEADLINE`, all under that same ID.

## Authority and deferred execution

A complete kind-46 or kind-47 request requires the actual connected kernel UID to hold current `SHUTDOWN` **and** current `INSPECT` when strict decoding completes. Partial requests are not authority leases: removal before decoding completes denies the request and leaves the service running.

After acceptance, the requesting worker transfers one owned reply connection and returns. The shutdown coordinator then:

1. Stops admissions and joins all control, peer, and scheduler writers.
2. Rejects a recorded fatal runtime failure.
3. Appends final drain accounting when the request is a drain.
4. Rechecks `INSPECT` against the final accepted configuration.
5. Seals this process's state against later durable mutation.
6. Samples one exact authenticated `NASH1` head under the state lock.
7. Attempts one bounded response write.

No configuration lease is retained across joins. The terminal response therefore cannot deadlock an already queued configuration operation. A private final-boundary probe forces the post-join `INSPECT` result to deny and requires a failed response with no head while preserving the already accepted stop.

## Response

A successful correlated handoff uses:

```json
{
  "format": "NATRAV_OVERLAY_CORRELATED_TERMINAL_STATE_HEAD_V1",
  "correlation_token": "ops-20261012-terminal-a01",
  "correlation_semantics": "PROVENANCE_ONLY_NOT_IDEMPOTENCY_OR_RECEIPT"
}
```

Those fields are added to the existing terminal-state-head account. The response still includes:

- The exact request ID and actual local principal.
- The sealed process-local terminal account.
- The exact keyed `NASH1` selector, or a null selector for unkeyed state.
- Writer-join and final-lifecycle accounts.
- Pending outbound and action counts.
- Drain completion or deadline classification.
- `delivery_confirmation: NOT_ESTABLISHED`.
- `freshness: NOT_ESTABLISHED` and `automatic_update: false`.

The complete annotated JSON remains capped at 4,096 bytes. In the revision-0569 focal suite, the largest observed response was 1,966 bytes with a 64-byte token.

## Response loss and duplicate attempts

Stop acceptance is independent of response delivery. Once the existing durable stop boundary has been crossed, a Unix-socket reset cannot revoke the stop. It also cannot prove that the caller received or protected the head.

Reusing the same complete request produces the same request ID and another independently authorized lifecycle row. The server does not suppress the request, return a cached response, infer retry safety, or reserve a token globally. Operators needing per-attempt distinction must choose a fresh token before every transmission.

After response loss, an operator can:

1. Confirm that the process stopped.
2. Authenticate and semantically replay the stopped state with the state-authentication key.
3. Derive the exact request ID from the protected token and request parameters.
4. Use the existing bounded lifecycle-history selector after a controlled restart, or inspect the replayed lifecycle account directly.
5. Obtain the current stopped `NASH1` head through complete offline inspection.

Reading an expected value from the state being checked and immediately passing it back does not create freshness. External custody remains separate.

## Obligations and failure boundaries

Correlation never changes pending work. A terminal deadline can return a valid final head while reporting pending outbound or action obligations. `obligations_complete` means only that the two existing drain backlog categories are zero.

A fatal joined worker refuses a healthy terminal response. A poisoned writer or failed publication similarly cannot expose a successful head. The revision-0569 private runtime-failure probe requires `TERMINAL_HEAD_RUNTIME_FAILED` and no `state_head` or token field.

## Compatibility

Revision 0569 changes only the live local-control protocol through strict NOC1 kinds 46 and 47. It changes no journal, authenticated header, lifecycle event, checkpoint, backup, NSS/NST, application logical-state, peer, permission-class, configuration, storage-schema, or product-limit encoding.

The actual revision-0568 CLI rejects the combined options, and its daemon rejects kinds 46 and 47 without stopping. Its offline reader nevertheless replays a revision-0569 correlated-terminal stopped journal, derives the same logical-state digest and authenticated head, and leaves the bytes unchanged.

## Explicit limits

A returned head is final only for the stopped process. It does not exclude a replacement writer. A successful socket write does not prove client receipt. A matching authenticated head does not prove freshness without a separately protected expected value. The product still does not establish physical-host, physical-power-loss, or static-link portability guarantees through this feature.
