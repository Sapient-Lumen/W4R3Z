# Recipient source-view inventory — revision 0552

`source-view-inventory` locates configured, historical and retired recipient views for the actual connected manager UID. It reads bounded administrative metadata; it does not import, retry, enable, pause, retire, reserve a new target, inspect source bytes, or decide worker eligibility. The product runtime is C++20. No configuration version, permission class, peer protocol, journal kind or logical-state format changes.

## Command and ownership

```sh
./node/bin/natrav-overlay source-view-inventory \
  --control state-c/control.sock --limit 16 --max-bytes 32768
```

Current V17-or-later explicit `SOURCE_IMPORT` is required. The owner is obtained from the existing kernel-authenticated control connection, not an argument. Permission is checked after decoding, and accepted configuration protection is retained through page construction. `INSPECT`, `ALL`, read permissions and another manager's identity do not confer this permission. An import manager need not hold payload-read authority and does not gain it by inspecting this inventory.

An accepted historical definition remains visible to its recorded manager while that UID retains the current class. Rule removal, key revocation and terminal retirement do not erase metadata or restore import eligibility. The existing V17 parser still requires an import-capable principal to have at least one current exact view; tests keep a distinct valid view when removing another. There is no cross-manager selector. Hidden owners do not contribute rows, counts, ordinals or exposed scan counters.

## Exact selectors

| Option | Values or meaning |
|---|---|
| `--presence` | `all`, `configured`, `historical` |
| `--lifecycle` | `all`, `active`, `retired` |
| `--schedule` | `all`, `never-enabled`, `enabled`, `paused`, `blocked`, `exhausted`, `retired` |
| `--view` | Exact immutable view ID |
| `--provider`, `--generation` | Exact provider node and key generation in the view definition |
| `--author-uid` | Exact provider-claimed source author UID in the definition; not the manager |
| `--source-scope`, `--target-scope` | Exact registered source and materialized scopes |

Selectors are conjunctive. Unknown values and unsupported options are errors. A missing, filtered-out or differently owned exact view returns an empty selection. Retired names and target domains are never recycled.

`CONFIGURED` means the immutable rule is present in the selected accepted configuration. `HISTORICAL` means it is absent there but retained from accepted history. `ACTIVE` means no terminal recipient-view retirement was recorded; it does not promise permission or readiness to import. A configured view can be retired. `policy_current` compares the immutable view definition only; current versus retained subscription-binding commitments are reported separately.

## Bounded metadata rows

Rows carry the view ID, manager, immutable rule digest and first accepted configuration event; provider and exact historical SPKI/generation, current generation state and pin match; source-author UID and source/target scopes; immutable record/byte ceilings, retained use and arithmetic remaining capacity; and current/retained exact-binding counts and commitments.

Where a schedule exists, the row reports its stored state, revision, history head and adopted authority commitment, generation, scan position, successful imports and inspection limits, manual retries, deferred count, typed error and latest decision's recorded actor/time/configuration. No schedule is created to render `NEVER_ENABLED`.

Retirement summaries reuse the actual final-state and retained-record commitments, exact deferred disposition and terminal actor/time/configuration. They do not recompute the full record mapping or make deferred work appear processed. `RETAINED_UNPROCESSED` remains explicitly unprocessed.

Free reasons, full binding lists, deferred parent operation IDs, source payloads, evidence rows, result values and complete decision histories are omitted. Counts and commitments are administrative metadata and can still be sensitive. Their hashes are not encryption or an independent truth authority. [Import decisions](IMPORT-DECISIONS.md), [retirement](VIEW-RETIREMENT.md) and [exact import](SUBSCRIBED-SOURCE-VIEWS.md) retain their separate contracts.

`retained_records` and `retained_payload_bytes` count materialized admissions, including superseded corrections, not raw incoming envelopes. Usage comes from the existing semantic import indexes. Supersession, retirement, compaction and removal do not refund it. Raw arrival alone changes neither those counters nor import scan state; actual automatic decisions may subsequently change the inventory.

A schedule state such as `ENABLED` is a stored grant label, not proof of execution or eligibility. Listing does not compare deadlines, reauthorize a grant on behalf of the worker, or append blocking decisions. It remains observational during quiescence and drain while the endpoint is alive. Normal denied-request auditing remains separate.

## Coherent pages and changed-selection behavior

Pages permit 1–16 records and 2,048–60,000 bytes of complete principal-annotated JSON. Each page is selected under one state mutex. The reply includes `selection_digest`, `selected_total`, `returned`, `next_offset` and `has_more`. Ordinals are one-based positions within the owned filtered view-ID order.

Continue with the same selectors:

```sh
./node/bin/natrav-overlay source-view-inventory \
  --control state-c/control.sock --offset NEXT_OFFSET --selection SELECTION_HEX64
```

Page size and byte budget can change; a nonzero offset requires the selection digest. A nonfitting first row returns `SOURCE_VIEW_INVENTORY_PAGE_TOO_SMALL`. A later nonfitting row ends a nonempty page and is not skipped. Selected metadata or context changes return `SOURCE_VIEW_INVENTORY_SELECTION_MISMATCH`. Invalid bounds use `SOURCE_VIEW_INVENTORY_INVALID`. Deadline exhaustion uses `SOURCE_VIEW_INVENTORY_DEADLINE`.

The digest binds node, kernel UID, canonical accepted configuration, exact selectors and complete displayed summaries. Direct imports invalidate usage even when no automatic revision changes. Automatic progress, retries, retirement, current binding changes and configuration changes likewise require reselection. Raw arrivals and other managers' materialization outside the selected summaries need not invalidate it. Changes within omitted history are represented only to the extent committed by displayed digests; this is not a full-state condition.

Same-state compaction and restart preserve content selection. Relocation changes the accepted configuration and requires a new selection while preserving historical rows. A digest is neither a bearer permission nor a retirement/import condition. It does not establish freshness against replay of an older complete valid state. There is no retained snapshot or cursor expiration registry.

## Derived registry and commitments

A new bounded in-memory registry is populated only during application of validated accepted configurations, including the ordinary checkpoint reconstruction path. Rejected candidates and commit-free preflight cannot populate it. Historical owners, immutable rules, original provider pins and the union of exact subscription bindings are retained. Existing semantic history rules enforce at most 32 historical views and 256 historical bindings globally.

The registry is not independently serialized, trusted from a cache, or included in the application logical-state digest. Pages never call the historical configuration parser. The ordinary source-view target reservation and usage index remain authoritative for their respective facts.

The binding-set digest is SHA-256 of:

```
NATRAV_OVERLAY_VIEW_INVENTORY_BINDINGS_V1 || 00
|| u32(count)
|| each (u16-length UTF-8 grant ID || 32-byte binding digest) in grant order
```

Selection starts with SHA-256 of:

```
NATRAV_OVERLAY_SOURCE_VIEW_INVENTORY_SELECTION_V1 || 00
|| text(node) || u32(manager UID) || 32-byte configuration digest
|| text(presence,lifecycle,schedule,view,provider,generation,source_scope,target_scope)
|| u8(author UID present) [u32(author UID)] || u32(selected count)
```

Each canonical compact JSON row extends the digest with SHA-256 of `NATRAV_OVERLAY_SOURCE_VIEW_INVENTORY_ROW_V1 || 00 || previous digest || u32(row byte length) || row bytes`. Integers use network byte order; `text` uses a u16 byte length. Page offset/limit/byte budget do not enter the selection. The local control request is kind 39, `VIN1`, with the same selector encoding followed by u32 offset, limit and byte budget and a strict optional digest. Trailing or truncated material is rejected.

## Work, tests and limits

The query visits only its manager's at-most-32 registry range. It reads bounded current policy metadata and exact per-view usage and scheduling accounts. Each page recomputes the selected summary commitment. The displayed work counters cover the locked inventory method, not config processing, transport, startup, reconstruction or every allocation. The implementation uses no source-envelope parsing, record scan, history encoder, retirement final-account recomputation, full snapshot or application logical serialization for a page. It does read a single latest decision where available.

The current tests independently encode `VIN1`, binding and selection commitments; enumerate all 32 views with 256 synthetic policy pins; exercise actual C++ subscriptions, original/correction imports, manual retries, deferred parents, retained retirement, exact limits and numerical continuation; use actual UIDs; and reconstruct through keyed audit, compaction, encrypted signed backup, restore and relocation. A 32-view policy fixture is not 32 communicating providers. [Actual validation](../validation/VALIDATION.json) and [attempts](../validation/ATTEMPTS.md) distinguish completed profiles from failures and unrun suites.

This API is not a full pin-history browser, payload-query API, import policy editor, resource reclamation mechanism or confidentiality boundary against timing/host compromise. Existing one-kernel testing, valid-state rollback, split-brain and static OpenSSL portability limits remain.


## Revision 0553 binding inspection

The read-only [source-view-bindings API](VIEW-BINDINGS.md) exposes complete current and retained pins for one exact manager-owned view. Current SOURCE_IMPORT is required; no payload permission, import eligibility, provider consent or lease validity is inferred. New first-acceptance indexes are derived through validated replay. Existing configuration and storage representations are unchanged.
