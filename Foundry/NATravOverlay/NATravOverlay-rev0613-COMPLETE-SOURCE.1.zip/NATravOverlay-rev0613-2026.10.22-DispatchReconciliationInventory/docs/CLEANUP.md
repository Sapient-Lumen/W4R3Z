# Working-set policy — revision 0564

Keep current C++ source, one normal executable, runnable independent tests, active contracts/examples, compact actual validation, a complete checksum manifest and extracted-package reconstruction. The owner retains predecessor ZIPs; they are provenance, not build dependencies.

Replace predecessor raw validation rather than accumulating historical forests. The current validation separates the final complete/selected matrices, actual predecessor reader comparison, the narrow expected-root negative control, and reconstruction. The one retained 0563 source-work metrics summary is explicitly historical, not a fresh performance claim.

Generated keys, identities, state, backups, temporary files, bytecode, objects, caches, alternate executables, symlinks and nested archives are excluded. Negative variants are built in owned scratch trees; neither their source tree nor executable is shipped. All twelve foundation files remain unchanged from the verified revision-0563 archive. [Provenance](PROVENANCE.json) records the actual parent; current evidence is described in [testing](TESTING.md).
