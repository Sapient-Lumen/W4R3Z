# Source-subscription transition validation — revision 0558

## Layered validation boundary

Revision 0554 introduced changed-entry semantic validation for ordinary ISSUE, ACK, AUTO_ISSUE and AUTO_ACK. Revision 0555 keeps that boundary and changes their journal representation from a complete supplied “after” state to a strict `NST3` transaction. The decoder now derives the next state itself from the exact retained predecessor. [Compact transaction contract](COMPACT-SOURCE-PROGRESS.md).

Both command preflight and untrusted sequential replay still perform mandatory semantic checks. There is no replay flag that trusts progress, no persisted “already validated” marker, and no caller-supplied cache root. Creation, scheduling changes, retirement, lease termination, succession, reconciliation and checkpoint import retain the complete subscription validator.

## Changed-entry checks

ISSUE reconstructs the one selected source envelope from exact local-authorship provenance and ordered source position. It verifies operation and record digests, payload count, recipient identity, mapped correction parent and canonical initial delivery policy. The candidate must not already occupy an outbox entry. Its acknowledgment fields are derived as zero. The whole evidence record, initial policy and source progress remain one synchronized journal transaction.

ACK rechecks the exact outstanding outbox operation and its actual durable receipt, including recipient, recorder, operation, record digest and retained generation/SPKI binding. It does not reconstruct earlier source payloads. A missing receipt fails closed. Acknowledgment does not refund source-disclosure bytes, record allowance or automatic steps.

Automatic progress retains the exact current finite grant, advances one successful step and source progress together, and records worker provenance. Vector shape is checked before any supplied automatic tail could be dereferenced. Manual and automatic actor forms are distinct.

The active accepted configuration at the journal position is mandatory. An older accepted event is not sufficient after a newer accepted policy change. Current disclosure authority, original key binding and exact retained grant still have to match.

## Live command preparation

Revision 0557 shares one private stack-owned parsed configuration and selected envelope only within the originating locked command. Revision 0558 lets successful automatic permanent-block classification supply that same preparation through a private single-use object, removing its second envelope construction without moving the classifier. Both semantic passes still decode NST3 and recheck exact predecessor/source/configuration/policy/outbox bindings; ACK still checks the actual receipt twice. Replay rejects both objects and reconstructs independently. [Preparation](SOURCE-PREPARATION.md) and [automatic eligibility](AUTOMATIC-SOURCE-ELIGIBILITY.md).

## Full validation and configuration memo

The complete validator reconstructs every retained delivery, source mapping, outbox policy, receipt, automatic grant and lineage account. It runs at complete-state transitions and checkpoint import. A call-scoped configuration memo shares normally parsed accepted `RuntimeConfig` objects across one locked complete validation pass. Nested reconciliation checks and one checkpoint registry pass can reuse a parsed event.

The memo never survives the pass, enters the journal/checkpoint, grants authority or replaces a predicate. It is bounded by accepted configuration history and stores parsed policy, not source payloads. Other subsystems may parse configurations independently.

## Work observation

Successful local source-subscription responses include `validation_work` only when the current manager also holds INSPECT. SOURCE_DISCLOSE alone does not grant diagnostic node metadata. Counters are process-local observations and are not persisted or sent to peers.

The scope records changed/full/reference validations, configuration parses/memo hits, delivery and receipt checks, source reconstruction, payload/envelope bytes, correction-mapping visits, state and compact-transaction encode/decode work, retained-vector copies/comparisons, and progress-commitment rebuilds/updates. It excludes transport, other threads, all allocations and unrelated serializers.

At source 128, normal ISSUE and ACK each perform two changed-entry validations—preflight and semantic application—with zero full validations, zero complete-state decodes and zero retained-delivery copies/comparisons. ISSUE's one NST3 transaction is 887 bytes; ACK's is 229 bytes. Default legacy responses still encode approximately 18.2 KiB of canonical state at this boundary. Revision 0556 adds [typed compact responses and indexed correction ancestry](STRUCTURAL-SOURCE-SELECTORS.md): opt-in compact progress encodes no complete NSS state and scans no retained mapping history. Full validation still independently reconstructs ancestry.

## Slow controls

The isolated `reference` build uses the delivered compact writer/reader and then invokes the complete validator after every ordinary progress check. After accepted progress it additionally compares structural components and the entire acknowledged ancestry index with full canonical reconstruction. It verifies agreement on the exercised cases; it is not an independent implementation or whole-program proof.

The isolated `full` build defines:

```text
NATRAV_SOURCE_SUBSCRIPTION_FORCE_FULL
NATRAV_SOURCE_SUBSCRIPTION_UNCACHED_CONFIG
NATRAV_SOURCE_SUBSCRIPTION_LEGACY_PROGRESS
```

It emits historical complete-state NST1 progress and uses complete validation without source-specific configuration memoization. This is a same-final-source counterfactual, not an actual predecessor executable. Neither alternate binary is shipped.

Normal and full-validator replay probes load exact owned state with the ordinary `NodeState` constructor, report source-specific construction work, compute the application logical-state digest afterward and verify that the input journal bytes did not change. The normal probe must reconstruct legacy NST1 journals; the full-validator probe must reconstruct compact NST3 journals. Equality of logical meaning is required. Timings are one-host diagnostics only.

## Corruption and negative control

Independent mutations with recomputed unkeyed outer checksums cover missing durable receipt, deleted issuance, predecessor commitment change, forged payload/receipt accounting, stale accepted authority, false automatic allowance, wrong actor/configuration and checkpoint mapping corruption. Keyed state additionally authenticates exact frames before these semantic checks.

Earlier receipt, structural-tail and preparation mutations remain historical unless explicitly rerun. Revision 0558's fresh narrow negative control removes only the eligibility-to-canonical source-record-digest comparison; the private probe must detect the invalid candidate. See [fresh validation](../validation/VALIDATION.json), [measurements](../validation/METRICS-SUMMARY.json) and [attempts](../validation/ATTEMPTS.md). Retained diagnostic programs do not imply their complete predecessor experiment matrix was rerun.

## Reproduce isolated controls

```sh
python3 node/tests/build_source_validation_diagnostic.py \
  --output /tmp/source-full-check --mode static --variant full
python3 node/tests/run_subscription_validation.py \
  --binary /tmp/source-full-check/source/node/bin/natrav-overlay \
  --validation-mode full --output /tmp/source-full-results

python3 node/tests/build_source_validation_diagnostic.py \
  --output /tmp/source-reference-check --mode static --variant reference
python3 node/tests/run_subscription_validation.py \
  --binary /tmp/source-reference-check/source/node/bin/natrav-overlay \
  --validation-mode reference --output /tmp/source-reference-results
```

Build and result directories belong outside the source workspace. Generated identities, state, keys and alternate executables are not distribution artifacts.
