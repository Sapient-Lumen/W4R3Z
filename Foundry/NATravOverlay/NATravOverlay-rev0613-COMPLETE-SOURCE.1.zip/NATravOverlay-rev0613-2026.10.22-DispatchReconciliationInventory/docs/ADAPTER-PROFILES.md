# Operator-pinned external adapter profiles

## Purpose

`OPERATOR_PINNED_ADAPTER_PROFILE_V1` turns the private supervised packet-adapter
boundary into a configuration object that can be authorized, retained, audited,
and restarted without reinterpreting an arbitrary executable path.

The profile is carrier policy. It is **not** peer identity. The adapter remains
untrusted complete-datagram plumbing beneath the finite packet service, TLS 1.3,
HELLO identity binding, NOS1, durable obligations, and exact receipts.

## Canonical profile record

The canonical record is newline-terminated UTF-8/ASCII data in this exact order:

```text
NATRAV_ADAPTER_PROFILE_V1
id=<stable-lowercase-id>
generation=<nonzero-u64>
previous=<64-lowercase-hex>
executable=<uppercase-percent-encoded-absolute-path>
sha256=<64-lowercase-hex>
argument-count=<canonical-u64>
argument=<uppercase-percent-encoded-bytes>
...
mtu=<256..65507>
capability-profile=1
max-frame-bytes=<bounded-size>
max-queued-bytes=<bounded-size>
max-outstanding-requests=1
max-evidence-events=<16..4096>
max-launch-attempts=<1..8>
startup-timeout-ms=<10..60000>
request-timeout-ms=<1..30000>
shutdown-timeout-ms=<1..30000>
initial-restart-backoff-ms=<1..10000>
maximum-restart-backoff-ms=<initial..30000>
```

Numbers have no leading zeroes. SHA-256 text is lowercase. Percent escapes use
uppercase hexadecimal and are rejected when the byte could have appeared
unescaped. The parser accepts only a byte-exact canonical re-encoding.

A profile identifier begins with a lowercase letter, ends with a lowercase
letter or digit, contains only lowercase letters, digits, and hyphens, and is at
most 64 bytes.

## Authorized succession

A new profile is structurally valid only when:

- creation uses generation `1` and an all-zero predecessor digest; or
- replacement retains the stable profile identifier;
- replacement increments the generation by exactly one; and
- `previous` equals SHA-256 of the predecessor's complete canonical record.

These rules prevent silent history rewriting. They do not replace the existing
owner/admin authorization boundary. The command that records a creation or
replacement must still be an authenticated, explicitly authorized configuration
transition.

Several generations may remain in durable history. A route resolves the exact
`profile_id` and `generation`; another generation with the same stable identifier
is not ambiguous.

## Canonical carrier locator

The private adapter transport locator is:

```text
adapter-v1|profile=<id>|generation=<u64>|link=<16-lowercase-hex>|epoch=<nonzero-u32>
```

The profile reference chooses operator-approved carrier policy. `link` and
`epoch` remain packet-link coordinates. None of these fields identifies or
authorizes a remote NATravOverlay peer.

## Exact-image preparation

A profile-backed launch performs the following sequence:

1. Traverse the absolute path component by component with `openat` and
   `O_NOFOLLOW`.
2. Require a nonempty regular file owned by the effective user or root.
3. Reject group/other-writable and set-id files.
4. Require an executable mode and a bounded size (at most 128 MiB).
5. Hash the exact opened bytes with SHA-256 and compare them in constant time
   with the profile digest.
6. Require an ELF image.
7. Copy those exact bytes into a private `memfd`.
8. Mark the copy executable and apply write, grow, shrink, and seal seals.
9. Retain only the sealed image for bounded launches and restarts.
10. Execute that descriptor with `execveat(..., AT_EMPTY_PATH)` without
    resolving the configured path again.

After preparation, renaming, replacing, deleting, or mutating the path cannot
change the bytes used by that prepared profile. A new node process still
reopens and revalidates the recorded path and digest, so replacement is detected
across node restart unless an authorized successor profile was recorded.

The sealed descriptor is `CLOEXEC`; it is consumed to establish the process
image and is not inherited by the adapter. The adapter receives only file
descriptors `0`, `1`, `2`, and the `SOCK_SEQPACKET` protocol endpoint at `3`, plus
the existing fixed five-entry environment.

## Launch-option drift

`ExternalPacketAdapterOptions` retains:

- the canonical profile record;
- SHA-256 of that record;
- the sealed executable image; and
- the exact options derived from the record.

Before any fork, the supervisor recomputes the profile digest and checks every
launch bound, argument, timeout, capability, and executable digest. Mutation of
either carrier settings or profile metadata is rejected as
`ADAPTER_PROFILE_DRIFT`.

The legacy unpinned constructor remains only to keep the private revision-0589
fixture API source-compatible. Ordinary persistent routes must be constructed
through `external_packet_adapter_options_from_profile`.

## Restart meaning

One prepared options object may be reused across the finite launch budget and
across later carrier reconstruction. This provides stable exact-image behavior
when the configured path disappears or is replaced after preparation.

An adapter process failure still destroys the carrier and its TLS session. Work
may retry only through a newly launched adapter and a fresh TLS/HELLO session.
The adapter cannot claim that an application operation succeeded and cannot
manufacture a receipt.

## Explicit limits

The profile pins the main ELF file, not every dynamically loaded library,
kernel driver, firmware image, or physical device behind it. A fully hermetic
adapter should therefore be statically linked or use a separately documented
and verified dependency policy. `no_new_privs`, descriptor closure, and a minimal
environment are meaningful containment measures, but they are not a complete
hostile-same-UID sandbox.

No same-host model establishes radio range, interference behavior, electrical
correctness, driver reliability, power consumption, independent-host behavior,
or physical power-loss recovery. Those are verification debts, not reasons to
omit the architecture or fabricate assurance.

## Durable catalog and endpoint generations

Revision 0592 adds an apply-ready bounded persistence layer around these
profiles. `DURABLE_ADAPTER_PROFILE_CATALOG_V1` stores accepted generations in an
owner-private append-only hash chain, calls an integration-supplied owner/admin
verifier before activation, retains only the authority-evidence digest, and
records bounded rejected attempts without making them active.

Configured carrier policy is represented by a separate canonical
`NATRAV_ADAPTER_ENDPOINT_V1` record. It binds a stable endpoint identifier and
route/listener role to one exact adapter locator and to SHA-256 of the exact
retained profile record. Endpoint replacement is itself versioned and
predecessor-bound; a route never silently follows the newest profile merely
because the stable profile identifier matches.

See `DURABLE-ADAPTER-PROFILE-CATALOG.md` for journal framing, recovery,
filesystem controls, limits, and the configured preparation boundary.

## Whole-product policy integration in revision 0595

The profile records now enter V19 through the ordinary authenticated runtime
configuration journal. See [V19 policy semantics](RUNTIME-ADAPTER-CONFIGURATION.md).
This supersedes the former missing-whole-source limitation for policy storage,
not the still-open configured adapter execution and persistent adapter lifecycle.
