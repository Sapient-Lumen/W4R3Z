# Bounded multi-route peer reachability — revision 0518

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

Revision 0518 lets one authenticated peer have a finite, explicitly ordered set of numeric IPv4/IPv6 connection candidates. Routes improve reachability; they do not define identity. The configured peer node, key generation, exact SPKI pin, TLS proof of possession, and HELLO claim remain authoritative on every route.

## Configuration V13

`NATRAV_OVERLAY_CONFIG_V13` separates a peer's delivery policy from its routes:

```text
peer=B,50,5000,20,86400000
peer_route=B,lan-v4,0,ENABLED,192.0.2.10:41002
peer_route=B,loopback-v6,10,ENABLED,[::1]:41002
peer_key=B,b-g1,ACTIVE,<SPKI_SHA256>
```

Each routed peer has one through eight `peer_route` entries. A route contains:

```text
peer node
stable route ID
integer priority
ENABLED or DISABLED
numeric IPv4/IPv6 endpoint
```

Lower priority values are preferred. Equal priorities are ordered by route ID, never by text-file order. Route IDs are 1–32 safe ASCII characters and are unique within the peer. One candidate configuration cannot assign one endpoint to multiple routes. An accepted endpoint cannot later be silently reassigned to another peer identity; historical configuration replay enforces that provenance.

V6–V12 retain their original `peer=NODE,ENDPOINT,...` syntax and synthesize one enabled route named `primary`. Their canonical bytes and legacy application-attempt accounting remain unchanged.

## Selection and cooldown

For V13, the per-peer scheduler:

1. retains a reusable authenticated session while its selected route contract remains enabled and unchanged;
2. otherwise gathers enabled routes whose cooldown has elapsed;
3. orders them by priority then route ID;
4. attempts TCP, TLS 1.3 mutual authentication, HELLO, and `NOS1` session opening;
5. moves to the next eligible route after a bounded pre-application failure;
6. issues the application operation only after a session is authenticated and open.

A failed route receives exponential cooldown using the peer's configured initial and maximum backoff. Successful session opening clears that route's failure streak. A successful application response also clears the selected route's cooldown account.

The scheduler does not preempt a healthy reusable session merely because a more preferred route has recovered or was newly added. The preferred route is reconsidered when the current session retires, fails, or its exact route contract changes. This avoids silent oscillation while still giving deterministic preferred-route recovery.

## Application-attempt accounting

For V13, failed TCP, TLS, HELLO, or session-open probes occur before `begin_outbound_attempt`. Trying another configured route therefore does not multiply the durable application's attempt count.

Once an application request is issued, the existing delivery rules remain authoritative:

- a receipt acknowledges the durable operation;
- an authenticated terminal peer decision creates `REJECTED`;
- a transient response or transport loss consumes the issued attempt and follows durable retry/backoff;
- replay after response loss remains duplicate-safe at the recipient.

This distinction is visible in status: route connection attempts can increase while an unavailable operation retains zero durable application attempts.

Legacy V6–V12 nodes keep their historical behavior, in which opening the single configured route is part of the durable attempt.

## Live configuration and session scope

V13 routes use the existing accepted-generation activation and rollback machinery. A candidate may add, remove, disable, or reprioritize routes while preserving pending peer-bound obligations.

An outbound session is bound to:

```text
peer identity and generation
selected route ID and endpoint
selected route priority/state
TLS/session policy and relevant peer authorization contract
```

Changing or removing that selected route retires the session before reuse. Changing an unrelated peer or an unused route does not force every session to reopen. Adding a more preferred route does not interrupt a healthy session; it becomes eligible at the next normal selection boundary.

If no route is enabled or reachable, obligations remain pending until expiry, cancellation, a route/configuration change, or later recovery. Other peer schedulers continue independently.

## Runtime status

`NATRAV_OVERLAY_RUNTIME_STATUS_V13` exposes, for every configured route:

```text
route ID and endpoint
priority and ENABLED/DISABLED state
active-session indicator
selections and connection attempts this run
successful opens this run
consecutive failure count
last failure code and time
last success time
cooldown deadline and remaining duration
```

Peer status also reports the selected route and the route ID bound to the reusable session.

These are run-scoped operational observations. They intentionally reset after process restart; the accepted route configuration, key provenance, pending operations, attempts already issued, receipts, and other durable application state do not. Persisting every failed connection probe would turn transient network diagnosis into unbounded journal churn. A future bounded operational-history facility can be added explicitly if field use demonstrates that need.

## Security boundary

A route is never authority. Every candidate must still authenticate as the exact durable peer generation and SPKI expected by the operation. A listener presenting another node's valid certificate is rejected before the application request and the scheduler may try another route.

The implementation does not add hostname resolution, discovery, proxy configuration, UPnP, relay service, general NAT traversal, or a NATrav runtime dependency. A test-only transparent TCP relay exercises alternate local paths; it is not product machinery.

Multiple loopback addresses or relays on one kernel are not proof of independent physical paths. Route status describes observed connection behavior in the measured process environment.

## Revision 0577 internal carrier mapping

Revision 0577 preserves every V6–V18 endpoint byte and every route-selection
rule above. Internally, each accepted numeric endpoint is represented as a TCP
`TransportLocator`, and route probing asks the registered TCP connector to
produce an owned `OrderedByteStream`. Listener acceptance produces the same
abstract stream type. TCP address parsing, socket construction, `TCP_NODELAY`,
nonblocking connect/listen/accept, and write-half shutdown are consequently
owned by the TCP transport implementation rather than by route, daemon, or
session code.

This does not make a route transport-agnostic in the durable configuration
format, and it adds no carrier negotiation or discovery. A later configuration
revision may introduce explicit non-TCP locator syntax only with canonical
encoding, migration, authorization, quota, and downgrade rules. Peer identity,
TLS/HELLO authentication, durable attempt accounting, cooldown, and route
provenance remain above the carrier boundary.



## Revision 0578 descriptor-free TLS mapping

Route selection still produces the same ordered TCP locator and one owned
`OrderedByteStream`. Revision 0578 passes that stream directly into
`TlsChannel`; TLS no longer asks the route or carrier for a native descriptor.
The selected route ID, exact expected peer generation/SPKI, cooldown, durable
attempt authority, session reuse, and runtime route evidence remain above the
carrier boundary and are unchanged.

This does not add mixed-carrier routes or carrier negotiation. A later
configuration revision must make each non-TCP locator explicit and canonical;
there is no silent downgrade or device discovery.

## Tested behavior

The revision-specific suite exercises:

- unavailable preferred IPv4 followed by authenticated IPv6 success;
- a valid but wrong TLS identity on one route followed by the correct peer;
- all routes unavailable while another peer progresses;
- pending work through hard restart and later route recovery;
- deterministic preferred-route recovery;
- response loss, route failover, and duplicate-safe recipient replay;
- live route removal/reprioritization with selective session retirement;
- historical endpoint-to-peer provenance rejection;
- the eight-route bound and malformed V13 configurations;
- authenticated compaction, signed encrypted backup/restore, relocation, and continued delivery.

See [testing](TESTING.md), [configuration](CONFIGURATION.md), [protocol](PROTOCOL.md), and the retained [validation account](../validation/VALIDATION.json).
