# Generation-stable control authorization — revision 0534

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Scope

All successfully decoded local controls now take a common current-configuration lease before command-class authorization. This closes the split between the old pre-read policy and a newer execution policy in legacy status, wake, cancellation, retry, rebind, action cancellation, compaction and lifecycle handlers. The existing modern query, submission, conditional-action and domain-specific controls use the same common boundary; their additional domain/ownership checks remain in their normal handlers.

The runtime remains native C++20. No command flag, permission, configuration version, control/peer encoding, journal kind or storage schema changes. Existing configurations are not granted additional access. `MAINTENANCE` does not accidentally acquire an evidence-read requirement merely because its handler now owns a generation lease.

## Credentials versus current authority

Linux `SO_PEERCRED` supplies the connected client's UID/GID/PID before any request frame is read. It describes credentials at connection creation, not a client-provided identity or a promise to track later process credential changes. The authoritative API reference is the Linux man-pages `unix(7)` SO_PEERCRED section: `https://man7.org/linux/man-pages/man7/unix.7.html`.

The pre-read snapshot remains useful only for rejecting UIDs absent from the policy and enforcing bounded I/O. It is not authority for a subsequently decoded command. An unknown UID still receives a typed denial without sending a frame. Filesystem traversal and socket permissions remain a separate earlier boundary; production defaults remain owner-only.

Ordinary decoded requests follow:

```text
kernel credentials and conservative pre-read membership
→ bounded strict decoding
→ current accepted configuration lease
→ command class and operation-specific authority
→ lifecycle admission
→ audit and existing command mutation under that same generation
→ release before response transmission
```

This allows a listed UID to use a newly granted class after connecting, but rejects a class revoked while the request is incomplete. The accepted configuration cannot change between ordinary authorization and mutation. A command admitted first may finish before a waiting configuration removes its permission; that is the explicit ordering, not a revocation bypass.

Successful generic status uses the same post-decode policy snapshot for authorization and rendering. It captures stable peer-registry pointers and releases the publication gate before the narrow durable-state observation. Full logical-state hashing is now explicitly requested; see [runtime status](RUNTIME-STATUS.md). It remains observational; it is not promised to be an atomic global configuration-plus-state snapshot. Already authorized response bytes may finish after a later policy change.

## Configuration activation and rollback

`config-activate` and `config-rollback` cannot hold a shared generation lock while waiting for their own exclusive publication lock. The control handler releases its initial post-decode lease and hands its real principal, request metadata and audit callback to the runtime publication routine.

The serialized routine checks current class and lifecycle again after acquiring its activation mutex, before reading or preparing the candidate. A request that waited behind revocation cannot use its older permission to open candidate files or roll back the new policy.

Candidate syntax, identity files, historical keys, quotas and registry preparation retain their existing checks. New peer workers remain parked until accepted publication. Under exclusive generation access, the routine checks authority and lifecycle again, validates the final candidate, and records the authorized control decision immediately before the accepted configuration event. The exclusive gate prevents another accepted generation or lifecycle transition from intervening at that commit boundary.

The governing authority is the active **predecessor**, not the candidate. A currently authorized administrator can publish a policy that removes its own CONFIGURATION class. Its next request is denied. A waiting administrator whose class remains granted can publish normally; an intervening generation alone is not a denial.

Failed candidate validation retains bounded rejection accounting under the actual current generation. A revoked waiter creates a denial, not an accepted audit or candidate configuration event. Preparation resources are cancelled/joined on failure. No shared-to-exclusive recursive lock upgrade is attempted.

The existing five-second exclusive publication-drain limit remains. Activation serialization, file validation and ordinary control I/O retain their existing bounds and may still exceed a client's shorter deadline. A missing response never establishes that no operation committed.

## Audit and replay

V8 and later control decisions identify the actual kernel principal, command, request ID and the configuration event that governed the decision. Ordinary mutation wrappers are generated under the same protected generation. Configuration activation's authorization account binds the predecessor that permitted publication, not the startup file or replacement policy.

Malformed/trailing requests are rejected as before; when decoding fails after a policy change, the denial samples the current accepted generation without retaining raw bytes. Successful status remains nonjournaled. Existing composite commands keep their own atomic audit/effect contracts.

A legacy AUTHORIZED control account is an authorization decision, **not** a successful effect receipt. The authorized audit and underlying mutation remain separate records where that was already the format; a later semantic rejection or interrupted append can leave an authorization account without a completed effect. No new crash-atomic audit format is claimed. Exact conditional outbox action receipts retain their stronger existing contract.

## Regression coverage

`run_control_authorization.py` uses real controlled processes, Linux UIDs 65534/65533 and an independent bounded NOC1/NOR1 client. It covers:

- Partial requests across revocation for thirteen legacy controls, with typed denial, no forbidden effect, and exact new-generation denial attribution.
- Newly granted authority and a successful cancellation whose audit and actual mutation refer to the same new generation; status remains observational after restart and compaction.
- Activation and rollback queued behind another publication that removes their class; neither can restore old authority.
- An authorized queued activation, self-removal, later denial, and owner-authorized rollback without a lock-upgrade deadlock.
- An already authorized cancellation ordered before a waiting revocation, with matching audit/mutation generation.
- Quiescence established during candidate preparation, rejected at exclusive publication, followed by successful explicit retry after resume.
- Unknown-UID denial before any request bytes, and current-generation malformed-request audit.

Owned-test markers and optional bounded pauses are disabled during ordinary operation. They coordinate existing synchronization boundaries; they never supply authority. The negative control bypasses only the runtime publication authority check and must be caught by the queued-revocation scenario.

The current [validation account](../validation/VALIDATION.json) distinguishes complete and selected profiles from [attempts](../validation/ATTEMPTS.md). Existing backup, relocation, authenticated journal and configuration replay suites remain runnable and are counted only when a profile actually ran them.

## Remaining boundaries

No remote authorization rule, grant ownership, payload/read separation, conditional-action selector, lease, or source lineage changes. Revocation does not recall bytes or undo already committed work. Ordinary controls retain their existing lifecycle-concurrency semantics; this revision does not make all shared-lease operations mutually exclusive with each other.

Legacy administration and candidate validation can still build broad snapshots. Ordinary status now uses bounded metadata, with explicitly requested full logical hashing; pending capacity admission uses exact derived aggregates. Fairness is not wait-free scheduling, and this increment is not a whole-program race or cryptographic audit. Old valid state rollback, split brain, compromised host/key, one-kernel tests, incomplete authenticated tails and static OpenSSL portability boundaries remain.
