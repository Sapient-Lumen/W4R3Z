# Automatic projections — 0512 with 0513 retirement

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

One native C++ worker can keep explicitly enabled DOMAIN_SUMMARY_V1 and NUMERIC_SUMMARY_V1 results current. Scheduling is optional. Creating a projection, starting the node or adding read permission never creates or replenishes an automatic grant. A previously enabled durable grant may resume after restart under current authority. There is no Python loop, shell execution, network action plugin, or fabricated local-socket principal in this path.

## Commands and authority

Use the existing V12 owner grants. Enable requires CONSUMER_ADMIN, CONSUMER, PROJECTION, EVIDENCE_READ and the adopted exact issuer/scope domain. Numeric processing additionally requires EVIDENCE_PAYLOAD and a PAYLOAD domain. ALL and INSPECT imply none of these newer permissions. No configuration version or peer protocol changes.

```sh
./node/bin/natrav-overlay projection-enable \
  --control /owned/b/control.sock --consumer temperatures \
  --expected-generation 0 --reason 'bounded native processing' \
  --max-pages 100 --min-interval-ms 100

./node/bin/natrav-overlay projection-schedule-status \
  --control /owned/b/control.sock --consumer temperatures

./node/bin/natrav-overlay projection-pause \
  --control /owned/b/control.sock --consumer temperatures \
  --expected-generation 1 --reason 'stop automatic work'
```

Names remain scoped to the kernel-observed UID. Status and pause require CONSUMER_ADMIN for that owner's projection, but not evidence payload access. This permits stopping and inspecting scheduling metadata after a read or processing grant has been removed while administrative authority remains. It does not expose a result or another UID's schedule. Offline inspect is separately protected by state ownership and, where configured, the state-authentication key.

Generation counts accepted enable grants, not processing steps. Zero denotes no previous grant; every accepted enable increments it. Enable/pause require the exact observed generation. An active grant cannot be replaced or replenished: pause it first. A lost enable reply is resolved by status; retrying an old generation fails rather than granting additional work. Repeated pause for the same already-stopped generation is observational. A stale pause cannot stop a later generation.

NCR3 is the exact local request envelope for these three commands. Old envelopes carrying new commands, truncated input, extra fields and out-of-range limits are rejected. Other consumer and projection request formats are unchanged.

## Finite durable delegation

Each projection can retain 32 grants. One grant specifies 1–10,000 successful pages and a minimum interval of 10–60,000 ms; defaults are 100 pages and 100 ms. The existing immutable consumer page size (at most 128 records), response/payload limits, projection admission budget and numeric sum budget still apply. These grants do not enlarge any definition.

Each grant retains owner, consumer instance and epoch, accepted configuration event, adopted read-authority digest, time, actual requesting PID, reason, initial and completed positions, page allowance and use, interval, final state and stopping provenance. A subsequent enable preserves the preceding grant. Full history prohibits another enable, but never prevents pausing the final active grant. There is no grant deletion or slot reclamation in this revision.

| Durable state | Meaning |
|---|---|
| ENABLED | May process under current authority; may also be caught up or service-suspended |
| PAUSED | Owner explicitly stopped this grant |
| BLOCKED | A checked authority, definition or bounded-page failure stopped it |
| EXHAUSTED | Its finite successful-page allowance has been consumed |
| RETIRED | An enabled grant was atomically stopped by terminal consumer retirement |

Caught-up waiting is not a durable transition. Empty probes, schedule status and duplicate stops append no successful journal record. Revoked/blocked/exhausted schedules are not repeatedly retried. Restoring a permission does not silently restart a blocked grant: explicitly rebuild when its adopted read authority changed, then enable a fresh grant. Every effective reader-domain change conservatively requires adoption, including a new permitted domain outside this projection's fixed selection.

Minimum intervals are monotonic process-local pacing between successful attempts. Restart reconstructs the finite remaining page budget, but not the previous process's timer. This is not a durable rate-window quota or an exact wall-clock schedule.

## One transaction, not a detached acknowledgment

Each automatic turn processes at most one bounded page. If an already issued manual page exists, its exact batch ID, boundaries and source commitment are preserved. Otherwise the worker selects a page and includes its new receipt directly in the automatic transaction; there is no independent issuance record that can strand budget between steps.

Journal kind 28 contains NAU1: the complete next schedule and, for STEP, the complete next projected consumer. AUTO_PROJECT advances the source-derived result, consumer position, latest receipt and grant's consumed page allowance in one synchronized record. Replay verifies the active accepted configuration, original grant, source page, exact prior states and recomputed effect before accepting it. An AUTO_PROJECT state cannot be replayed as an ordinary unbound consumer update.

Manual consumer-read, projection-process and rebuild mutations are rejected while a grant remains ENABLED. Inspection is allowed. Pause first to change the manual processing boundary. The state mutex orders pause against an in-progress bounded step; after a successful pause reply no subsequent step runs under that grant. A step that completed before pause is not undone.

Automatic STEP/BLOCK records identify DAEMON_PROJECTION_WORKER with the daemon's real UID/PID. The grant retains the real connected owner's UID/PID separately. The worker never invents SO_PEERCRED or claims that the original client is still connected. Restored history preserves those past observations; it does not assert that an old PID still identifies a live process.

## Current permission and failures

Each step holds one accepted runtime-configuration lease, then the lifecycle transition mutex, then the state mutex. It rechecks current administrative/consumer/projection authority and exact metadata or payload access. Publication cannot cross its decision/commit boundary.

An interpretation-invalid numeric input is processed according to NUMERIC_SUMMARY_V1, not treated as a scheduler error. Aggregate sum or admission exhaustion instead records a typed BLOCKED account without advancing result, position or page allowance. A preexisting pending page remains intact. When an unissued automatic selection fails, its source records remain after the unchanged frontier; no batch or input is silently acknowledged.

The scheduler isolates checked application/budget failures. Corrupt state, a poisoned writer, failure to persist a blocked account, allocation failure or another unexpected exception is fatal to the daemon rather than hidden as successful per-projection progress. There is no reserved emergency journal capacity. Shared filesystem/CPU failure domains remain shared.

## Fairness and lifecycle

One worker services the active bounded registry (128 consumers globally, 16 per UID; retired objects are excluded). A rotating key order selects at most one successful or blocked page attempt per turn. Each turn releases the configuration, lifecycle and state locks. No thread is created per projection. Process-local timers and candidate lists are bounded by that registry.

Peer admission, enable/pause, configuration change and lifecycle resume notify the worker. A bounded 500-ms fallback covers lost wakeups. Caught-up probes read domain-index counts, not historical records or full payload snapshots. Registry/configuration checks still have bounded cost; zero historical record visits is not zero CPU cost. The worker yields between busy turns; this is finite work/fair service, not real-time scheduling or timing confidentiality.

Quiesce and drain suspend new automatic steps under the same lifecycle mutex. Their persisted grants remain enabled for an authorized later RUNNING state. Already durable peer deliveries and counter actions retain their previous lifecycle behavior. Projection backlog does not delay drain completion. Interrupted drain reconstructs quiesced before this worker can act. A clean drain followed by restart follows the existing RUNNING restart rule and may resume enabled grants.

The configured per-page work includes bounded replay/source validation, not just one returned-record visit. No cold full-selection root is computed for scheduling. Checkpoint verification still reconstructs retained results and can be linear in their processed frontiers.

## Checkpoint, recovery and compatibility

NAS1 is an optional logical-state extension containing schedules. Empty/never-scheduled states retain their previous logical encoding. Counts, grant history and results participate in the logical digest, compaction accounting, authenticated replay, encrypted signed backups, restore and explicit relocation. Offline inspect adds projection_schedules; runtime status exposes a registered count and whether service mode suspends the worker. Per-owner schedule status contains full grant metadata. Existing result responses are not inflated by the grant history.

Older binaries reject journal kind 28, NAS1 and automatic result transitions. This is an explicit new-state compatibility boundary, not an in-place downgrade path. Existing V12 configurations, manual consumers/projections, peer TLS and application frames continue unchanged.

Kill tests bracket synchronized STEP publication: before commit, result/progress/budget remain old; after commit all three reconstruct as advanced even if a caller saw no result. Arbitrarily incomplete authenticated records still require explicit audit/recovery. Automatic recovery is not weakened. Old valid snapshots can replay older work; this increment supplies no freshness authority, external-effect transaction or split-brain protection.

See [testing](TESTING.md), [numeric definition](NUMERIC-PROJECTIONS.md), [projection semantics](PROJECTIONS.md), [storage](STORAGE.md) and actual [validation](../validation/VALIDATION.json).

## Revision 0513 — retirement

[Consumer retirement](CONSUMER-RETIREMENT.md) is an explicit atomic stop exception to the usual pause-before-manual-mutation rule. Enabled grants become RETIRED; already stopped grants remain frozen history. Old enable/pause/process requests cannot revive the consumer. Retirement does not refund spent pages or acknowledge pending work.
