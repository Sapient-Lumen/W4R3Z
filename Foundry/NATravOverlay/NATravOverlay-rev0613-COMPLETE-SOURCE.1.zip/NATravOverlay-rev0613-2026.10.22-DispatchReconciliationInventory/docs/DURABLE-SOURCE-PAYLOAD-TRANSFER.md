# Durable source-payload ownership transfer — revision 0563

## Scope

Revision 0563 removes the remaining decoded evidence-payload copy from the live manual and automatic NST3 source-ISSUE command path.

The command-local strict parser already owns one decoded `EvidenceRecord` inside noncopyable `ParsedSourceProgress`. After semantic preflight and successful journal synchronization, final outbox application now moves that record into canonical `StoredOutbound` state. The move is available only to the exact locked command that produced and durably published the matching NST3 bytes.

This is deliberately not a generic admission shortcut. Independent replay, checkpoint reconstruction, complete-state transitions, publication writers, action-result writers and standalone decoding continue to construct their own owned values and use the ordinary copying path.

## Publication and single-use boundary

A record cannot be moved during parsing or preflight. `append_entry` first:

1. Rechecks the exact NST3 bytes, SHA-256, state owner, retained predecessor, subscription instance and revision, structural commitment, active configuration, queue limits and original journal position.
2. Builds the complete journal frame.
3. Writes the frame and successfully calls `fdatasync`.
4. Advances the in-process journal byte account and authenticated chain.
5. Marks the command-local parse with the exact resulting journal position.

Only then may final application request ownership. The transfer re-runs the exact nested record-slice byte comparison, rechecks the command origin, requires the publication marker to equal the current journal position, and consumes the record once. A second transfer, replay use, ACK use, unrelated journal kind, changed predecessor/configuration/limits or use before publication fails closed.

The marker and consumed bit are process-local. Neither is serialized, accepted from a caller, returned in a response or retained after the command frame exits.

## Semantic checks retained

The move does not replace either semantic pass. Preflight and live application still independently verify:

- The permitted successor state and predecessor commitment.
- The current accepted disclosure configuration.
- Source order, scope, local authorship and correction ancestry.
- Delivery operation and evidence-record identity.
- Recipient generation and SPKI.
- Outbound policy.
- Source-payload accounting.
- Actual outbox absence and current capacity.
- The exact manual request or finite automatic-grant consequence.

Prepared outbound admission still performs both nested byte bindings and both evidence-record validations. Canonical storage still calculates and retains the evidence-record digest. ACK still locates and validates the actual durable receipt in both semantic passes.

## Failure boundary

A failed preflight cannot mark publication or move the record. A failed write or `fdatasync` poisons the writer and leaves the predecessor unchanged.

A private test-only build also injects a failure after the synchronized frame and record move but before policy application. The in-process state is intentionally partial and the writer is poisoned; retry returns `STATE_RESTART_REQUIRED`. Restart ignores that partial memory and independently replays the complete durable NST3 frame into a complete source issue.

No attempt is made to roll back moved in-memory state after durable publication. The journal is authoritative, and any post-publication application failure requires restart.

## Measured ownership boundary

The normal executable and forced-copy control are built from the same revision-0563 source. The control defines only `NATRAV_SOURCE_OUTBOUND_COPY_STORE`.

| ISSUE fixture | Normal live path | Forced-copy control |
|---|---:|---:|
| Source 128 decoded evidence payload | 0 canonical payload copies; one 423-byte transfer | one 423-byte copy; no transfer |
| 58,000-byte raw source | 0 canonical payload copies; one 58,231-byte transfer | one 58,231-byte copy; no transfer |

Both paths still perform one canonical evidence-record digest. ACK has neither a storage copy nor an ownership transfer.

This is an attributable removal of one payload-vector copy per live ISSUE. It is not a claim of measured end-to-end latency, allocator-call, peak-memory, transport or whole-program throughput improvement.

## Compatibility

No request, journal, NSS/NST, application logical-state, checkpoint, peer-envelope, permission, configuration, storage-schema or size-limit encoding changes. An older reader sees the same bytes. Untrusted replay remains independent and fully owned.
