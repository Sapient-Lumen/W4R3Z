# Bounded runtime inventories — revision 0537

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Scope

`runtime-inventory` reads accepted configured membership and policy through the actual persistent C++ control socket. It requires current kernel-authenticated `INSPECT`, after bounded request decoding, and retains the shared configuration-publication lease through row selection and JSON construction. This is node-wide administrative metadata, not an evidence-read grant or a remote query interface. `SUBMIT`, evidence permissions, and request-supplied UIDs cannot substitute for `INSPECT`. Quiescence permits the command. Successful reads, including empty pages, append no journal or successful control-audit event; the existing denial audit still applies.

No configuration version, durable schema, journal kind or peer protocol changes. The added local command kind is 26 with an explicit `NRI1` body. Older nodes reject the unknown kind. Response format is `NATRAV_OVERLAY_RUNTIME_INVENTORY_V1`.

## CLI

```sh
./node/bin/natrav-overlay runtime-inventory --control state-a/control.sock \
  --section routes --limit 16 --max-bytes 8192

./node/bin/natrav-overlay runtime-inventory --control state-a/control.sock \
  --section routes --peer B --id primary
```

Sections: `peers`, `routes`, `keys`, `local-control`, `evidence-read`, `evidence-author`, `authorization`, `source-disclosure`, `source-views`, `source-bindings`, and `configuration`.

`peers` includes the full accepted historical identity registry, with `ROUTED`, `INBOUND_ONLY` or `HISTORICAL` roles. It includes the current routed peer's delivery policy and finite pending limits. These roles do not confer trust, key validity or scope authority. `routes` enumerates every configured route separately, including disabled routes; `keys` enumerates every active, retired and revoked generation.

The policy sections expose exact configured grants and commitments. `configuration` returns named `service`, `sessions`, `io`, `actions`, `policy`, and `outbox-limits` rows. It deliberately omits owner paths, certificate/key paths, candidate text, historical configuration events and mutation accounts. It is not a copy of the complete canonical configuration file. Source grants and bindings contain policy metadata, never delivered source/evidence payloads.

### Selectors and row identity

All filters are exact and conjunctive. `--peer` applies to peers/routes/keys/authorization, the issuer in evidence-read, the subscriber in source-disclosure, and the provider in source-views. `--uid` applies to local-control/evidence-read/evidence-author and manager UIDs in source-disclosure/source-views. A filter in an undefined section is rejected, not ignored. `--id` selects the row's displayed ID. Names and digests are case sensitive.

Rows sort lexically by peer identity, then row ID. Routes sort by stable route ID, not priority or input-file order. Key rows use generation IDs; local-control IDs are decimal UIDs; read-domain IDs combine UID, issuer and scope; author-domain IDs combine UID and scope. Authorization and binding rows use their canonical digests. Order is not a liveness or trust preference.

### Continuation

The reply contains `total`, `returned`, `offset`, `has_more`, `next_offset`, `configuration_digest`, `registry_digest`, and `selection_digest`. For another page, repeat the section and filters and pass the returned next offset and selection:

```sh
./node/bin/natrav-overlay runtime-inventory --control state-a/control.sock \
  --section routes --offset 16 --selection SELECTED_DIGEST --limit 16
```

A nonzero offset without a selection digest is rejected. An offset equal to the exact total returns an empty page; beyond the total is an error. At most 64 rows and 60,000 complete annotated JSON bytes may be requested; the minimum byte budget is 2,048. A nonfitting row ends a nonempty page without being skipped, and a nonfitting first row returns `RUNTIME_INVENTORY_PAGE_TOO_SMALL`. The byte budget includes the bounded kernel-principal annotation, not outer transport framing. Limits and byte budgets may change between pages without changing the selection.

The selection is a domain-separated digest of node, canonical accepted configuration, sorted historical membership, exact section/filters and actual requesting UID. It excludes positions, page sizing, runtime counters and process instance. It is an unsigned context comparison, not an opaque capability, MAC-authenticated bearer token, content freshness proof or condition for administrative mutation. A caller may intentionally choose another offset after current authorization. No server cursor objects, expirations or per-read state exist.

An accepted configuration or historical membership change returns `RUNTIME_INVENTORY_CONTEXT_MISMATCH` for an earlier selection. Exact canonical rollback with unchanged historical membership can restore that same selection. Rollback after accepting an additional historical identity cannot. Compaction and restart preserve a selection when those configured facts remain identical. Restoring a valid older complete state is not detected as rollback by this mechanism. Every page rechecks current INSPECT, regardless of saved selection.

## Exact local encoding

The existing outer length-framed control payload is `NOC1`, kind byte 26, followed by `NRI1`. The body contains big-endian 16-bit-length section/peer/ID texts (limits 32/64/256 bytes); a strict 0-or-1 UID flag and optional big-endian uint32 UID; uint32 offset, limit and maximum JSON bytes; then a strict 0-or-1 selection flag and optional 32-byte digest. Exact EOF is required. There are no ignored trailing fields or unknown-section fallbacks.

Registry commitment: SHA-256 of `NATRAV_OVERLAY_RUNTIME_REGISTRY_V1`, one zero byte, a big-endian uint32 count and sorted length-16 ASCII node IDs. Selection commitment: SHA-256 of `NATRAV_OVERLAY_RUNTIME_INVENTORY_SELECTION_V1`, one zero byte, length-16 texts for local node, lowercase configuration hash, lowercase registry hash, section, peer and row ID; then uint32 actual principal UID, an optional-filter-UID flag and its uint32 value when present. Independent test code reconstructs both digests. They are deterministic unsigned context commitments, not cryptographic identity proof.

## Telemetry and observation boundary

Configuration and membership stay stable throughout one page. Peer atomic counters are independent observations; route telemetry is copied under that route's mutex and is returned only when route ID, endpoint, priority and enabled state match the selected configuration. Otherwise route telemetry is `null`, not relabeled counters from another contract. The command does not open connections or modify route observations. `process_instance` distinguishes daemon runs (PID and a process-local monotonic marker initialized on first inventory use); it is not an identity authority.

Counters, active-session flags, failure/cooldown timestamps and process instance may differ between pages and after restart without invalidating the configuration selection. There is no multi-page snapshot of the running process and no promise that a healthy route at observation time remains healthy.

## Work limits

The request constructs bounded metadata references for one accepted section, applies filters and sorts them; configured membership remains capped at 64, eight routes/generations per identity, and the existing 65,536-byte configuration ceiling. It renders only the requested rows plus a possible nonfitting row. It does not call NodeState snapshot or copy application payloads. `work.references_considered` reports section metadata considered; `rows_serialized` reports actual render calls. Empty selections render zero rows but still perform authorization, canonical configuration hashing and metadata filtering. This is not constant-time, allocation-free or a hard real-time guarantee.

## Bounded health previews

`status` advances to `NATRAV_OVERLAY_RUNTIME_STATUS_V14`. Exact state totals and explicit full-digest semantics remain. Peer registry, peers, key generations, local-control and evidence-read arrays are now bounded previews with exact total/returned/truncated accounts; `inventory_api` identifies the complete observational surface. Per-policy previews are capped at eight rows and 2,048 encoded bytes before their added total/returned/truncated labels. Registry and top-level key previews contain at most eight rows. Peer previews contain at most eight peers and 12,288 encoded bytes, with at most eight routes and generations per peer.

If retained histories plus the ordinary metadata preview still exceed the 64,000-byte pre-annotation ceiling, status takes a second coherent state observation with outbox/action rows and configuration-event detail omitted. It labels `COUNTERS_ONLY_SIZE_FALLBACK`, preserves exact totals and truncation indicators, and never silently returns a partial JSON row. The fallback may recompute a requested full digest; `status_work` explicitly describes the **final state observation**, not discarded first-pass work. The digest in the reply describes that final observation. Ordinary status never hashes full application state.

State, authorizing configuration and live telemetry remain separately labeled observations. The status path also no longer calls the mutating route synchronizer with an old captured configuration. Missing/mismatched route preview telemetry is marked `telemetry_available:false`. Local authorization counters are correctly attached to `local_control`, not the adjacent evidence-read policy object.

## Validation boundary

The new tests independently construct configurations and wire packets, enumerate all rows at byte/page boundaries, exercise 64 identities/512 routes and a separate 512-key configuration, compare configured fields, perform an actual C++ TLS delivery, revoke INSPECT during an incomplete request, and test rollback, additional historical membership, compaction and restart. Maximum-membership pins are synthetic; this is not 64 communicating independent machines. Native old product regression and selected sanitizer/alternate-compiler profiles are recorded in [validation](../validation/VALIDATION.json). Output directories remain outside the source tree.

The negative control disables selection-context comparison and must fail the live-configuration continuation test. No weakened binary or generated credential is delivered. Existing one-kernel, old-valid-snapshot, external-freshness, host-compromise, mutex-contention, and static OpenSSL portability limitations remain.

## Retained configuration inspection (0538)

[configuration-history](CONFIGURATION-HISTORY.md) supplies exact event/binding lookup and bounded retained-prefix pages under current INSPECT. It omits canonical contents, reason text and relocation paths while preserving their commitments. Prefix selection does not grant authority or establish freshness. Runtime-bound mutation bindings are an explicitly described subset, not the entire effect or local-control audit log. Local request kind 27 (NHC1) introduces no new persistent encoding or peer protocol.
