# State authentication — revision 0504

**Current extension (0564):** [External state expectations](EXTERNAL-STATE-EXPECTATIONS.md) add an optional exact, separately supplied input-head condition. Historical statements below about intrinsic authentication freshness remain true: no managed latest-head anchor exists, and an old expectation paired with its old valid state still matches.

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

## Purpose, trust, and compatibility

`NOAUTH01` authenticates a node's schema-2 journal with a separate random state key. The native implementation uses checked OpenSSL EVP_MAC HMAC-SHA-256 and constant-time tag comparison. It does not implement its own hash or MAC primitive. Existing `NOJ1` records, canonical `NLS2` logical state, `NCP3` checkpoints, configuration V8, peer TLS/HELLO/NOS1, and application semantics remain unchanged inside the authenticated storage representation.

Unkeyed compatibility is intentional. A daemon or offline command launched with `--state-auth-key FILE` requires authentication; it never falls back to unkeyed input. An authenticated header without an explicit key fails `STATE_AUTH_KEY_REQUIRED`. A wrong secret fails `STATE_AUTH_TAG_MISMATCH`. State key paths are neither configuration fields nor journal/backup contents. The key is loaded once before workers start and remains immutable for the process lifetime.

The security boundary assumes an intact verifier, protected state-key custody, and a trusted launch policy that requires the key. Anyone who holds the symmetric state key can forge another authenticated history. An attacker able to replace the executable, remove the launch requirement, read the daemon's memory, or compromise its UID/kernel is outside this claim. Owner-only files are not isolation from other processes with the same UID.

**Authentication is not freshness.** No protected latest-head anchor exists. Removing complete final records to leave a previously valid prefix, replaying a valid whole snapshot, or deliberately supplying an old key with its valid old snapshot remains possible. Status reports `freshness: NOT_ESTABLISHED`. Tests positively demonstrate these limits rather than expecting an impossible rejection.

## Key creation and custody

```sh
mkdir -m 700 private-state-keys
./node/bin/natrav-overlay state-auth-key-init \
  --output private-state-keys/state-g1.key --generation state-g1
```

This generates 32 secret bytes with checked `RAND_priv_bytes`. The result identifies purpose `STATE_AUTHENTICATION`, generation, and a non-secret key ID. Key buffers are cleansed where owned by this boundary; memory locking, swap/core-dump protection, and complete process-memory erasure are not provided.

Reads require a regular, single-link, effective-user-owned file with exact mode `0600`. Key ancestry is opened descriptor-relatively without following symbolic links; dot-dot and unsafe final names are rejected. The final parent must be effective-user owned and not group/other writable. A synchronized mode-0600 sibling is published with `renameat2(RENAME_NOREPLACE)`, then its parent is synchronized. Existing output is never overwritten. Interrupted creation can leave a mode-0600 unpublished `.natrav-state-key-*.tmp`; preserve custody and inspect that material explicitly.

All integers are big endian. The exact key format is:

```text
"NOSKEY01" | u32 version=1 | u16 generation_length | generation | secret[32]
```

Generation length is 1–64 using the existing generation grammar; total size is 47–110 bytes with exact EOF. The key ID is:

```text
SHA256("NATRAV_OVERLAY_STATE_AUTH_KEY_ID_V1" || u16(len(generation)) || generation || secret)
```

There is no password interface or password-derived key. `NOBKEY01` backup keys and PEM TLS keys are not accepted as state keys. Use independently generated material; changing a purpose label is not key separation. Keep state keys separately from shared state/backups. Missing keys cannot be reconstructed from their IDs. Retain each old key while an old journal/backup matters.

## Explicit migration

```sh
./node/bin/natrav-overlay state-auth-migrate \
  --state state-a --node A --new-key private-state-keys/state-g1.key \
  --reason 'adopt the verified offline source'
```

The source must exist, have exact owner directory mode `0700` and protected regular mode-0600 metadata/journal/lock files, and use storage schema 2. Protected path traversal rejects symlinks. The ordinary stable state lock excludes a running daemon, backup exporter, and other state owners. A missing source is not created. Downgraded metadata is rejected before legacy schema migration can run.

Migration loads a complete valid unkeyed source without incomplete-tail repair. It creates a complete canonical checkpoint, retains its application logical digest, records the SHA-256 of the original source journal, and attaches an attributable `MIGRATE` event with time, effective UID, generation, key ID, and bounded reason. This is deliberate adoption of the source—not proof that the earlier unkeyed history was genuine.

The authenticated sibling is written and synchronized. The actual on-disk sibling is read through the normal strict authenticated checkpoint decoder. Its logical digest and authenticated root must match the constructed candidate before rename and directory synchronization. Only then does it become `state.journal`. Failure before publication removes the candidate and leaves the source authoritative. Failure after publication poisons the in-process writer; restart reconstructs the published journal. A pre-publication kill leaves the old representation; a post-publication/directory-sync kill leaves the new one. Stale candidates are removed only under stable state ownership.

Migration is not necessarily size-neutral. The authenticated representation and every later append remain bounded by the journal ceiling.

## Epoch and record format

An authenticated journal begins with this epoch header:

```text
"NOAUTH01" | u32 body_length | header_body | header_tag[32]
```

`body_length` is at most 65,536. `text16` means a big-endian two-byte length and the exact text. The body contains, in order:

```text
u32 authentication_version=1   # version 2 adds the recovery extension below
u32 storage_schema=2
text16 node_id
text16 key_generation
key_id[32]
random_epoch[32]
parent_root[32]
checkpoint_logical_digest[32]
text16 purpose                 # MIGRATE, ROTATE, COMPACT, BACKUP, or RECOVER
u16 transition_count          # 1..64
transition[transition_count]
```

Each transition is:

```text
u8 kind                       # 1 MIGRATE, 2 ROTATE
text16 generation
key_id[32]
u64 unix_ms
u32 effective_uid
text16 reason                 # 1..512 printable ASCII bytes
source_root[32]
```

The first transition must be migration; later transitions must be rotations. Generation IDs and key IDs are unique in this bounded history. The final transition must match the active key. Prior generations are exposed as `RETIRED`, the final generation as `ACTIVE`. There is no online multi-key lookup or separate revocation service.

The header tag is HMAC-SHA-256 over:

```text
"NATRAV_OVERLAY_STATE_AUTH_HEADER_V1\0" || encoded_magic_length_and_body
```

Each subsequent authenticated record is:

```text
"NAR1" | u32 inner_frame_length | u64 sequence | predecessor_tag[32]
       | one_complete_NOJ1_frame | record_tag[32]
```

Sequence starts at one, increases exactly by one, and may not skip. The first predecessor is the header tag; thereafter it is the previous record tag. The first record is a checkpoint (inner kind 18). Each wrapper contains exactly one complete existing frame, including its record kind, configuration binding, body and original checksum. Per-record overhead is 80 bytes in addition to the inner frame.

The record tag is HMAC-SHA-256 over:

```text
"NATRAV_OVERLAY_STATE_AUTH_RECORD_V1\0" || header_tag
    || encoded_record_magic_length_sequence_predecessor_and_inner_frame
```

A fresh random epoch and a header-tag binding prevent an ordinary record from being transplanted into a different epoch, including another checkpoint with the same node/key. Node and schema are authenticated in the header, not inferred from a pathname. The current root is the final tag. Header/record lengths, exact framing, chain order and EOF are checked; no host-endian representation is used.

The header MAC is verified before interpreting its fields. The entire record chain is authenticated before the ordinary journal decoder applies any application state. Semantic validation remains mandatory after authentication: a party holding the key cannot bypass the product's record-kind, configuration, receipt, action, checkpoint, or obligation invariants simply by computing valid tags.

## Ordinary appends, compaction, and rotation

A normal append serializes the existing event including configuration provenance, adds its next sequence/predecessor/tag, enforces physical-byte limits, writes and synchronizes it, and only then advances the in-memory cursor and applies the event. A failed append poisons the writer and requires restart.

Live compaction creates one authenticated checkpoint in a fresh epoch, binds its parent to the preceding verified root, preserves key-transition history, and checks exact physical-byte accounting including authentication overhead. Candidate validation uses the normal in-memory checkpoint decoder on bytes actually read from disk. Publishing keeps the stable state lock. Subsequent live appends remain authenticated.

Explicit offline rotation uses a fresh separate secret and generation:

```sh
./node/bin/natrav-overlay state-auth-key-init \
  --output private-state-keys/state-g2.key --generation state-g2
./node/bin/natrav-overlay state-auth-rotate \
  --state state-a --node A --state-auth-key private-state-keys/state-g1.key \
  --new-key private-state-keys/state-g2.key --reason 'replace state authentication key'
```

Rotation verifies the existing state with the old key, preserves all application state, appends a `ROTATE` history account, and atomically publishes a checkpoint under the new key. Reusing any historical generation/key ID or relabeling the identical current secret is rejected. History is capped at 64 transitions and has no pruning yet.

Restart now requires the new key. The old key remains able to verify old snapshots; `RETIRED` is a history description, not deletion or revocation of those copies. Only the current key is needed for the newly compacted chain. Its MAC protects the retained old transition accounts, but does not let a new-key-only verifier independently reverify discarded old-key records; retain old archives/keys when that evidence is needed.

## Checkpoints, backup, restore, relocation

The application logical digest excludes representation-only authentication headers, key/recovery history, generations, and roots. Recovery provenance remains authenticated in header version 2 and survives compaction, rotation and backups; see [the extension contract](AUTHENTICATED-RECOVERY.md). Migration, rotation, compaction, backup and restore must preserve that digest while their authentication roots may legitimately change. Authentication history is still protected by the header MAC, not discarded.

The existing backup manifest's checkpoint digest binds the complete authenticated checkpoint bytes. Its backup ID and optional Ed25519 signature transitively bind the root, generation, epoch and history; no duplicate unauthenticated root authority is introduced. `NOBENC01` can encrypt that entire signed or unsigned inner backup with the independent encryption key.

For keyed state, add `--state-auth-key FILE` to export, verify, restore, re-encrypt, inspect, and relocate. Verification without that key fails even when the backup-encryption key or trusted signing certificate is present. A supplied state key also rejects an unkeyed checkpoint instead of certifying it. Restore preserves the authenticated checkpoint and appends its restore provenance with the same key. Startup and relocation continue through the ordinary authenticated loader. State-key bytes and pathnames are not exported.

Example verification of all three independent properties:

```sh
./node/bin/natrav-overlay backup-verify \
  --input backups/a.nob --node A --generation a-g1 \
  --state-auth-key private-state-keys/state-g1.key \
  --decrypt-key private-backup-keys/archive-g1.key --require-encryption yes \
  --trusted-cert private/node-a-g1/cert.pem --require-signature yes
```

Backup re-encryption preserves the original inner bytes, including the original state-key binding; it does not rekey that checkpoint. Use its original state key to verify it even after the live node rotates. To export under the new state key, rotate the verified live/offline state and make a new export.

## Failure and recovery boundary

**Every incomplete authenticated header or record fails closed; no authenticated tail is automatically truncated.** Complete invalid records, checksum-recomputed modifications, sequence gaps, reordering, inserted duplicates, and cross-epoch splices also fail without journal repair. A partial append makes normal keyed startup unavailable. Revision 0504 adds an offline read-only audit and explicit maximal-prefix recovery; it does not weaken startup into automatic repair. Complete invalid records remain ineligible. See [Authenticated recovery](AUTHENTICATED-RECOVERY.md) for exact selection, mandatory source preservation, expected-head comparison and publication semantics.

Ordinary unkeyed compatibility retains its existing tail-recovery behavior. Explicit migration refuses a torn unkeyed source, so migration cannot silently discard data and then certify the remainder.

There is no trusted monotonic head, full-snapshot rollback defense, split-brain prevention, live-file encryption, or host-compromise protection. Record tags do not prove evidence truth. Tests exercise actual local files, processes, synchronization, rename, and SIGKILL, not arbitrary physical power loss. Verification is bounded but in memory; raw bytes, decoded frames and logical state may coexist and consume substantially more RAM than the file size.

## Primary API references

OpenSSL provider HMAC/digest selection, checked EVP_MAC operations, constant-time comparison, and randomness error handling were consulted on October 4, 2026. Installed versions are recorded separately in the validation environment.

```text
https://docs.openssl.org/3.0/man7/EVP_MAC-HMAC/
https://docs.openssl.org/3.0/man3/EVP_MAC/
https://docs.openssl.org/3.0/man3/CRYPTO_memcmp/
https://docs.openssl.org/3.0/man3/RAND_bytes/
```

See [Testing](TESTING.md), [Storage](STORAGE.md), and [the next build plan](BUILD-PLAN.md).

## Offline correlated-stop audit (0570)

The offline correlated-stop audit shares the complete authenticated-prefix replay implementation used to construct a verified checkpoint, but returns only bounded redacted control/lifecycle provenance and current pending counts. Verification of the authenticated header, every record chain link, every inner frame checksum, checkpoint logical binding, and all application semantics precedes request selection.

The command holds the existing state lock and journal exclusively and read-only, then verifies source identity and byte equality before returning. It does not accept incomplete tails, perform recovery, open a journal writer, or update an external expectation. `--expected-state-head` remains an optional exact-input constraint checked after full replay. See [the audit contract](OFFLINE-CORRELATED-STOP-AUDIT.md).

## Detached expected-head custody (0572)

Revision 0572 can retain an exact canonical `NASH1` selector in a separately
named `NHCUST01` custody record. The custody file is not part of the
authenticated node journal and is never updated as a side effect of node work.
Its content digest detects malformed record material but is not a MAC; the
operator's separate filesystem custody remains the trust boundary.

Creation and advancement are explicit. Advancement requires the exact old
node, custody domain, custody generation, `NASH1`, and complete-file digest,
then publishes a strictly newer generation through a same-directory synced
atomic exchange. See [Detached state-head custody](DETACHED-STATE-HEAD-CUSTODY.md).

A custody record does not change the meaning of state authentication. A valid
old journal and its corresponding old record still match. The record supplies
an operator-selected expected value; it does not independently establish that
the value is newest.

## Direct backup-contained correlated-stop audit (0571/0572 delivery)

The direct backup audit authenticates the encrypted outer representation,
trusted signer, signed backup identity, embedded checkpoint digest, complete
state-authentication chain, and all checkpoint semantics before selecting
correlated-stop history. It accepts the existing optional exact embedded
`NASH1` expectation and never restores or advances an external anchor. See
[Backup-contained correlated-stop audit](BACKUP-CORRELATED-STOP-AUDIT.md).

## Direct detached-custody input condition (0573)

Commands that already accept an exact external `NASH1` selector can instead
name one detached `NHCUST01` record plus its exact custody domain, generation,
and complete-file digest. The product verifies that record through the same
strict filesystem and canonical-decoding boundary, extracts its selector, and
then invokes the unchanged complete authenticated-state matcher.

Finite commands recheck the exact custody inode and bytes before reporting
success. Daemon startup performs its final recheck before workers and readiness,
then releases the custody lock; custody is not held as a continuous lease and is
never advanced automatically. See [Custody-constrained state opening](CUSTODY-CONSTRAINED-STATE-OPENING.md).
