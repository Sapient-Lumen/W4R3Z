# Recipient-view retirement

Current view discovery: [manager-scoped source-view inventory](SOURCE-VIEW-INVENTORY.md) exposes retained administrative summaries without changing import or read authority.

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

Revision 0529 adds one explicit terminal lifecycle to a subscribed-source view. It uses the existing kernel-authenticated Unix control plane and V17 `SOURCE_IMPORT` class. It does not modify peer protocols, subscription grants, ordinary read policy, or previously admitted evidence.

## Select, then retire

First obtain a coherent administrative selection:

```sh
./node/bin/natrav-overlay source-view-retirement-status \
  --control state-c/control.sock --view temperature
```

The `NATRAV_OVERLAY_VIEW_RETIREMENT_V1` reply contains the immutable view digest, current accepted configuration digest, scheduling/decision revision, history commitment, retained-record and payload-byte counts, records commitment, and complete final-account digest. It does not return source payloads, source operation lists, private paths, or projection results. Counts and commitments are deliberately administrative metadata, not a metadata-oblivious interface.

Then submit the exact observed selection:

```sh
./node/bin/natrav-overlay source-view-retire \
  --control state-c/control.sock --view temperature \
  --expected-revision OBSERVED_REVISION \
  --view-digest HEX64 --configuration-digest HEX64 \
  --final-state-digest HEX64 --deferred require-empty \
  --reason 'stop future recipient materialization; preserve accepted evidence'
```

Reason text is nonempty printable ASCII, at most 256 bytes. The selectors have distinct purposes. The view digest fixes the historically immutable name, owner, provider/key policy, source and target domains, and retention budgets. The configuration digest fixes the accepted administrative context. The scheduling revision fixes the decision/grant history. The final-account digest additionally fixes all retained imports. A direct manual import does not increment scheduling revision, but it changes this final account and therefore invalidates a stale retirement request.

Selection and mutation execute under the state mutex while the control handler holds a stable accepted configuration. A completed worker step, new direct import, reconsideration, changed policy, or newer grant cannot be silently substituted for the selected state. Conflicts return `SOURCE_VIEW_RETIREMENT_CONFLICT`; the caller must inspect and deliberately select again. No automatic retry is performed against newer state.

Unrelated inbound evidence does not invalidate a selection. This is a commitment to the selected view, not an assertion that the entire node stopped changing.

## Authority is stopping authority, not data access

The caller must be the exact historically accepted manager UID and currently hold explicit `SOURCE_IMPORT`. Credentials come from the existing kernel socket check, not request bytes. `ALL`, `INSPECT`, read permission, and the daemon UID do not bypass ownership.

A retained view can be retired even when its particular rule is no longer active or its provider key is revoked. This is an administrative stopping operation, not permission to process more input. Existing V17 configuration validation still requires each import-capable principal to have at least one current exact view. To stop a removed view, the owner therefore needs to retain the class through another accepted view, or keep the retiring view configured while stopping it. This revision does not weaken that parser rule.

Current class and ownership are rechecked after request decoding. A slow connection opened before revocation cannot retain its previous administrative authority. Retirement status, terminal retry, and historical decision review also require current owner/class authority.

All ordinary lifecycle gates apply: retirement is a mutation and is refused while the node is quiesced or draining. Those modes already suspend new automatic imports. This revision adds no lifecycle bypass.

## Terminal means no new imports through any path

The accepted event changes the view's derived scheduling state to `RETIRED`. Direct imports, old duplicate-import requests, selective retries (including old exact requests), automatic enable, and pause mutations subsequently fail with `SOURCE_VIEW_RETIRED`. The worker excludes terminal views and rechecks under the state mutex when executing an earlier candidate snapshot.

An enabled grant stops in the same commit. Its generation, successful imports, classified inspections, manual attempts, pacing settings, and scan position remain unchanged. The retirement account retains its preceding scheduling state. Never-enabled, paused, exhausted, and blocked views can also be retired; no new automation grant is required.

A new or rolled-back configuration cannot reactivate the view. Names, immutable definitions, provider/target domains, and all retention budgets remain historically reserved. No slot reuse, payload deletion, source alias creation, or budget refund is introduced.

The ordinary peer-admission target-domain reservation remains effective after retirement. Even an otherwise authorized provider cannot submit raw evidence into the materialized target as a replacement for the retired importer.

## Deferred work has an explicit disposition

`--deferred require-empty` refuses when a missing-parent dependency remains.

`--deferred retain` accepts retirement while preserving the exact dependency map, recorded as `RETAIN_UNPROCESSED`. Remaining work is explicitly `RETAINED_UNPROCESSED`. It is not imported, acknowledged, cancelled at the provider, or treated as harmless. A later parent arrival does not cause a terminal importer to resume. Scan position and original decision outcomes remain unchanged.

Unissued future input is likewise not processed. Incoming raw envelopes can still be admitted by the peer policy; retiring their local view does not withdraw the remote subscription, cancel queued network operations, or recall delivered bytes. Those are separate explicit product operations.

## Existing evidence and reads remain intact

Queries, incremental feeds, durable consumers, and projections continue to use retained materialized evidence under their separate current read permissions. Retirement does not reset a projection, erase a correction, strip subscribed-source provenance, or relabel anything as recipient-local authorship. Continuous processing of already retained evidence is possible when separately authorized.

After retirement, `source-view-decisions` still pages through the retained immutable history, including the new terminal event. Prefixes selected before retirement retain their meaning. `source-view-auto-status` remains administrative inspection, with the final counters and deferred map available. An observational request does not append a successful event merely because the manager inspected it; existing denied-request auditing remains in effect.

## Atomic representation and exact retry

`NIR3` is the local request version for command 6 (retire) and command 7 (retirement status). Older `NIR1` and `NIR2` commands retain strict decoding. Requests require exact EOF and bounded fields.

Journal kind 34 carries a new `NIE3` action, `RETIRE`. It includes the existing event chain, actual UID/GID/PID and time, accepted configuration event, immutable view digest, selected final-state digest, reason, and deferred disposition. The existing `NIH1` history and `NIS1` checkpoint extension retain that terminal event. Unretired state encodings are unchanged. Earlier binaries reject the unfamiliar terminal event rather than losing it silently.

One reserved terminal slot is available after the existing 1,024 ordinary-event ceiling: retained history can contain at most 1,025 events, and only retirement can occupy that final slot. Ordinary grant, worker, and retry allowances are not expanded. Review selectors can name the terminal slot. The implementation retains the existing 32-view historical configuration ceiling; this is not an archive-reclamation operation.

The reducer reconstructs the final account from its exact historical inbound prefix and preceding event state before accepting retirement. The view-record commitment uses immutable operation/record digests and complete subscribed-source provenance digests; it copies no payloads. A separately domain-separated commitment binds node, view, owner, history head, counters, limits, dependencies, and that record root.

Normal journal replay rejects imports or further events after retirement. Checkpoint loading initially reconstructs evidence before decision histories, so a separate final check forbids materialized records beyond a retired view's selected prefix. This prevents placing an otherwise valid direct import after the retained terminal event in a forged checkpoint.

An exact repeated retirement returns `ALREADY_RETIRED`, with the original terminal account and current administrative context. It creates no new event, charge, or stopping decision. It must retain the original owner, view, revision, selected digests, reason, and disposition. Current owner/class authority remains mandatory, but accepted relocation does not change what the earlier command meant. A different reason or selector conflicts.

## Persistence, tests, and limits

The independent `run_view_retirement.py` exercises strict request encoding; stale direct-import and worker selectors; concurrent retirement; genuine different Linux UIDs; policy revocation during request transmission; removed-rule stopping; actual configuration rollback; deferred dependencies; pre/post-commit process kills; forged final accounts; direct admission placed after a valid terminal event; checkpoint semantic verification; keyed audit; signed encrypted restore; relocation; separately authorized retained numeric computation; and retirement after grant-generation exhaustion.

The maximum 1,025-event terminal history is an implemented bound, not a claim that the integrated scenario filled all 1,025 events. The suite does exhaust the 32-grant generation allowance and verify retirement remains available. Final validation reports completed full and selected profiles separately in [the validation account](../validation/VALIDATION.json).

Active retirement selection scans only the view's retained target-domain metadata under the state mutex, with memory bounded independently of payload size. It is linear in retained records, not a latency guarantee or lock-free snapshot. A slow command may commit despite its client losing the reply; exact retry resolves the accepted decision. Arbitrarily incomplete authenticated appends still require explicit audit/recovery.

A valid old backup from before retirement can restore older active state. No external freshness anchor, remote recall, distributed ownership, split-brain prevention, host-compromise protection, or physical power-loss guarantee is added. Source truth and provider claims remain unchanged by recipient administration.
