# Durable projection-publication channels — revision 0517

Current owner-scoped channel discovery is documented in [publication inventory](PUBLICATION-INVENTORY.md); existing exact and mutating command semantics remain separate.

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

A channel repeatedly publishes one built-in projection to one recipient and scope. The first result in an epoch is an original evidence record. Later selected results in that epoch are attributable evidence corrections to the prior durably acknowledged channel head.

Revision 0517 retains the owner-invoked and finite automatic lifecycles and adds explicit replacement epochs after exact terminal heads. All paths use the same canonical result, ordinary outbox, recipient authorization, receipt, retry, rejection, compaction, backup, restore, and relocation machinery.

## Commands

```text
publication-channel-create
publication-channel-publish
publication-channel-status
publication-channel-retire
publication-channel-auto-enable
publication-channel-auto-pause
publication-channel-auto-status
publication-channel-new-epoch
```

A channel binds the actual kernel owner UID, immutable channel/projection identities, recipient, output scope, `ACTIVE_AT_PUBLISH` key policy, finite channel-publication budget, creation configuration event, and permanently reserved owner-scoped name.

Create/publish/new-epoch/retire require current V12 `PROJECTION`, `CONSUMER`, and `SUBMIT`, plus the exact read authority required by the projection. Numeric results require payload authority. Recipient admission remains independent.

## Linear correction rule inside an epoch

The first publication in epoch 1 is an original. A later publication in the same epoch requires a durable receipt on the preceding channel operation and becomes an ordinary evidence correction whose `corrects` field names that predecessor.

Pending, rejected, cancelled, and expired outcomes are distinct; none is treated as acknowledgment.

Exact retries return the already queued/acknowledged/rejected operation even after the projection has advanced. Retirement may require no pending head or atomically cancel the exact pending head. A retired name cannot be reused.

## Explicit replacement epochs

A channel head that is durably `REJECTED`, `CANCELLED`, or `EXPIRED` may be selected by `publication-channel-new-epoch` together with the exact channel revision/epoch and exact projection frontier.

The replacement increments the epoch and queues a new evidence original. It does not set `corrects` to the terminal predecessor. Instead, `NPC2` carries explicit terminal-lineage fields. Later acknowledged results in the replacement epoch resume ordinary corrections behind that new original.

Pending and acknowledged heads are ineligible. A rejected operation may instead use ordinary attributable retry. A new epoch is an explicit alternative, not an inferred fallback.

An enabled automatic-publication grant is blocked in the epoch transaction. A grant already blocked by the terminal head remains blocked. A separate finite grant must be enabled explicitly for automatic corrections in the new epoch. See [publication epochs](PUBLICATION-EPOCHS.md).

## Automatic publication

An automatic grant is separate from the internal projection-processing schedule. It has an exact generation and schedule revision, finite successful-publication allowance, retained minimum interval, current authority digest, reason, and terminal state. See [automatic publication](AUTOMATIC-PUBLICATION.md).

One fair daemon worker rotates through enabled channels. A changed result can consume one allowance only when all ordinary same-epoch publication invariants hold. Caught-up work, pending predecessors, absent routes, unavailable peers, and temporary quota pressure spend nothing. Channel state, outbox obligation, and allowance consumption commit in one journal transaction.

Automatic work never starts a replacement epoch.

## Canonical evidence

### `NPC1`

Epoch-1 publications without terminal lineage retain the existing wrapper:

- immutable channel instance and name;
- channel sequence and finite budget;
- optional acknowledged predecessor operation;
- channel-specific authority digest;
- complete canonical `NPP1` projection result.

### `NPC2`

Epoch-aware publications add:

- monotonically increasing epoch;
- optional prior terminal-epoch operation;
- terminal outcome.

An epoch-opening `NPC2` has no ordinary correction predecessor. Later publications in that epoch have ordinary `corrects` ancestry and omit terminal lineage.

For either wrapper, the operation ID is:

```text
SHA-256(
  "NATRAV_OVERLAY_PUBLICATION_CHANNEL_OPERATION_V1"
  || 0x00
  || canonical NPC bytes
)
```

Source evidence payloads are not copied into the publication. The local accepted configuration event remains in the journal wrapper rather than owner-path-sensitive stable payload material.

## Persistence

Publication-channel transitions use journal kind 30 and transaction envelope `NCT1`.

Current `NCH3` channel state retains:

- immutable definition;
- bounded publication history and exact epoch for each revision;
- terminal lineage, reason, and actor on epoch openings;
- exact recipient generations and SPKI pins;
- same-epoch correction ancestry and result/source digests;
- schedule revision and at most 32 automatic grants;
- active/retired lifecycle and optional exact pending cancellation;
- transition actor, time, PID, and accepted configuration event.

`NCH1` and `NCH2` remain readable. `NPH1` carries active and retired channel registries in checkpoints. Semantic replay checks exact prior state, projection result, authority, recipient key policy, outbox operation, predecessor receipt or terminal outcome, monotonic epoch, grant consequence, and cancellation target.

The strict local request envelope is now `PCR3`; strict `PCR1` and `PCR2` remain readable. No peer session or application-message branch changed.

## Capacity

| Resource | Bound |
|---|---:|
| Active channels | 128 globally, 16 per UID |
| Retired channels | 256 globally, 64 per UID |
| Channel publications | 1–128, fixed at creation |
| Epochs | 32 per channel |
| Automatic grant generations | 32 per channel |
| Successful automatic publications per grant | 1–10,000 |
| Automatic minimum interval | 10–60,000 ms |

Ordinary global/per-peer outbox count and payload quotas also apply. Retirement releases an active slot but retains history and name reservation.

## Boundaries

A channel is one linear acknowledged correction chain **within each epoch**. Epoch transitions retain terminal discontinuities; they do not repair them or prove remote effects absent.

A publication is an attributable derived account at a processed frontier. It does not establish source truth, freshness, completeness, representativeness, or independent verification.
