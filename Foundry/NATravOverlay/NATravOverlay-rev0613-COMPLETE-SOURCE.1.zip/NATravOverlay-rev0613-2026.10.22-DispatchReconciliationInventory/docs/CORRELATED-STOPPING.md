# Correlated destructive stopping — revision 0568

Revision 0568 adds **strictly opt-in caller correlation** to immediate and draining shutdown. It solves one provenance problem left after response-loss-independent stopping: two byte-identical stop requests have the same request ID, so an operator inspecting stopped state cannot distinguish a new intended attempt from an identical older attempt.

The new token changes the request bytes and therefore the existing durable request identity. It does not change stop authority, stop acceptance, lifecycle semantics, or response-delivery guarantees.

## Commands

```sh
./node/bin/natrav-overlay shutdown \
  --control state-a/control.sock \
  --correlation ops-20261012-a01 \
  --deadline-ms 2000
```

```sh
./node/bin/natrav-overlay drain-shutdown \
  --control state-a/control.sock \
  --reason 'bounded maintenance stop' \
  --drain-deadline-ms 5000 \
  --correlation ops-20261012-a02 \
  --deadline-ms 10000
```

`--correlation` is optional. Without it, the existing kinds 4 and 14 and their existing success JSON remain unchanged.

Without `--final-state-head yes`, correlation selects ordinary kinds 44/45 and the response timing described here. Revision 0569 adds separate kinds 46/47 when the two options are combined. Those correlated terminal requests retain the deferred reply, writer joins, state sealing, exact `NASH1`, and additional current `INSPECT` requirements of kinds 42/43. They are specified separately in [Correlated terminal authenticated-state handoff](CORRELATED-TERMINAL-STATE-HEAD.md).

## Canonical token

A correlation token is:

- 1 through 64 ASCII bytes;
- lowercase only;
- composed of `a`–`z`, `0`–`9`, `.`, `_`, and `-`;
- started and ended by `a`–`z` or `0`–`9`.

Examples:

```text
ops-20261012-a01
maintenance.window_7
3f89c81b
```

Empty, uppercase, non-ASCII, slash-containing, leading-punctuation, trailing-punctuation, oversized, truncated, extended, or otherwise noncanonical inputs fail closed before lifecycle admission.

The token is an operator-selected public correlation label, not a secret. The successful correlated response echoes it. Durable control and lifecycle history store only the request ID, not the token text.

## Wire encoding

The outer length-framed local-control protocol remains `NOC1`/`NOR1`. Two new strict request kinds are defined:

| Operation | Kind | Body |
|---|---:|---|
| Correlated immediate shutdown | 44 (`0x2c`) | big-endian `uint16` token length, then exact token bytes |
| Correlated draining shutdown | 45 (`0x2d`) | existing big-endian `uint32` drain deadline, existing `uint16` reason length and reason bytes, then `uint16` token length and exact token bytes |

Exact EOF is required. The outer four-byte socket frame length is not part of the control payload or request ID.

Successful responses are explicitly versioned:

```text
NATRAV_OVERLAY_CONTROL_CORRELATED_SHUTDOWN_V1
NATRAV_OVERLAY_CONTROL_CORRELATED_DRAIN_SHUTDOWN_V1
```

They include:

```json
{
  "correlation_token": "ops-20261012-a01",
  "correlation_semantics": "PROVENANCE_ONLY_NOT_IDEMPOTENCY_OR_RECEIPT"
}
```

The normal principal, request-ID, and command-class annotations remain.

## Deterministic request identity

The existing request identity is unchanged:

```text
SHA256(
  "NATRAV_OVERLAY_CONTROL_REQUEST_ID_V1" || 0x00 ||
  BE64(length(control_payload)) || control_payload
)
```

For immediate shutdown, `control_payload` is:

```text
"NOC1" || 0x2c || BE16(length(token)) || token
```

For draining shutdown, it is:

```text
"NOC1" || 0x2d || BE32(deadline_ms) ||
BE16(length(reason)) || reason || BE16(length(token)) || token
```

An independent Python reference for an immediate request is:

```python
import hashlib, struct

token = b"ops-20261012-a01"
payload = b"NOC1" + bytes([44]) + struct.pack("!H", len(token)) + token
request_id = hashlib.sha256(
    b"NATRAV_OVERLAY_CONTROL_REQUEST_ID_V1\0"
    + struct.pack("!Q", len(payload))
    + payload
).hexdigest()
print(request_id)
```

The operator can calculate and protect that ID before transmission. After an ambiguous reply loss, first establish whether the process stopped. On a later authorized open, exact lifecycle selection is available through the existing bounded history API:

```sh
./node/bin/natrav-overlay control-history \
  --control state-a/control.sock \
  --section lifecycle \
  --request-id "$REQUEST_ID" \
  --offset 0 --limit 4 --max-bytes 32768
```

An immediate accepted attempt contributes `SHUTDOWN_REQUESTED`. An accepted drain contributes `DRAIN_STARTED` followed by `DRAIN_COMPLETED` or `DRAIN_DEADLINE`, all under the same exact request ID. Current `INSPECT` authority is required for that lookup.

## Duplicate tokens are not idempotency

The request ID identifies exact request bytes, not a unique invocation. Reusing the same token with the same immediate request, or the same token/deadline/reason drain, yields the same request ID. Every complete attempt is nevertheless decoded, authorized, admitted, and recorded independently.

History can therefore contain multiple control decisions and multiple lifecycle rows selected by one request ID. The server does not suppress, coalesce, replay, automatically retry, or refund duplicate correlated requests.

Operators seeking per-attempt distinction must choose a new token before each transmission and preserve the intended token/request-ID pair outside the rollbackable state.

## Authority and failure boundaries

Correlation grants no permission. The actual kernel-authenticated connected UID still needs current `SHUTDOWN`. A partially transmitted request is checked against the configuration current when decoding completes. Revocation before completion denies the request and creates no stop intent.

The response-loss-independent boundaries from revision 0567 remain:

- Immediate stop intent becomes irrevocable only after durable `SHUTDOWN_REQUESTED` and live `DRAINING` publication.
- Drain stop intent becomes irrevocable only after durable `DRAIN_COMPLETED` or `DRAIN_DEADLINE`.
- Malformed, incomplete, unauthorized, revoked, lifecycle-rejected, append-failed, or poisoned-writer requests before those boundaries are non-stops.
- Response write failure after those boundaries cannot revoke accepted stopping.
- Pending outbound and action obligations remain exact at a drain deadline.

Correlation is not a permission, idempotency key, freshness anchor, replay exemption, recovery selector, client receipt, or proof that the selected state is globally latest. A lost response remains ambiguous until process exit and authenticated provenance are established.

## Replay, compaction, and compatibility

No journal or checkpoint field was added. Existing lifecycle and local-control events already bind the 32-byte request ID. Complete replay, keyed authentication, compaction, backup, restore, relocation, and recovery retain that identity through their existing canonical paths.

Revision 0567 does not understand kinds 44 or 45. It rejects both new wire kinds and the new CLI option, and it does not silently treat them as ordinary shutdown. Because no durable encoding changed, the actual revision-0567 offline reader also accepts a revision-0568 correlated stopped journal and produces the same logical-state digest as the current reader.

The revision-0568 negative control omits only the kind-44 token from request-ID hashing. Independent derivation immediately detects the weakened identity. The weakened executable is not distributed.
