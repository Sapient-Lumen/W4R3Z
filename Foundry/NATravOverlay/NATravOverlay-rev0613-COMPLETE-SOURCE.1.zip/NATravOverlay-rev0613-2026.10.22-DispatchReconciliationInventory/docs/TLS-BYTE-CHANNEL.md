# OpenSSL over `ByteChannel` — revision 0578

Revision 0578 removes the last peer-TLS dependency on a native TCP descriptor.
The authenticated stack can now run over any live `ByteChannel` that supplies
bounded reads and writes with the existing deadline and counter contract.

## Boundary

`TlsChannel::connect` and `TlsChannel::accept` receive `ByteChannel&`. They do
not receive an integer descriptor and do not inspect the concrete carrier.
`OrderedByteStream` remains the owned connected-carrier abstraction, but it no
longer exposes `native_tls_handle()`.

`TlsByteChannelBio` is the only adapter between OpenSSL and `ByteChannel`. It:

- creates one custom `BIO_METHOD` with source/sink semantics;
- owns the `BIO*` until it transfers that BIO to one `SSL*` with `SSL_set_bio`;
- retains per-channel callback state beside the `SSL*`;
- keeps the backing `ByteChannel` non-owning and lifetime-bounded;
- is destroyed only after `SSL_free` has released the BIO; and
- has no descriptor, socket BIO, process-global current stream, or hidden
  fallback path.

Call sites construct the carrier stream before `TlsChannel`, so normal reverse
destruction destroys SSL/BIO before the stream. Server handling likewise keeps
the accepted stream outside and alive through the entire secure connection.

## Callback safety

OpenSSL invokes BIO functions through a C ABI. Every revision-0578 callback is
`noexcept` and catches all C++ exceptions. The first failure is retained as an
exact `std::exception_ptr` in that BIO's callback state. The callback returns a
conservative failure result; after the OpenSSL call returns to C++,
`complete_operation()` merges bounded carrier wait counters, clears callback
state, and rethrows the captured exception.

No exception crosses a C callback, and no global exception slot can mix
concurrent channels.

Each OpenSSL operation establishes exactly one callback context containing:

- the live backing channel;
- the caller's absolute deadline;
- isolated carrier counters;
- a bounded operation label; and
- the retained callback failure.

Nested or missing operations fail closed with `TLS_BIO_STATE_INVALID`.
Cleanup is nonthrowing.

## I/O semantics

The backing `ByteChannel` already owns waiting, interruption handling, and the
absolute deadline. The BIO therefore performs one bounded carrier read or write
per callback. It does not create an independent poll loop or replace the
caller's deadline.

A positive write must make finite progress. A read may return zero only for
carrier EOF. Short progress is accepted and returned exactly to OpenSSL.
Carrier exceptions are retained and rethrown after OpenSSL returns.

The adapter implements only the controls required by the current TLS 1.3 path:

- `BIO_CTRL_FLUSH` succeeds because there is no separate BIO buffer;
- `BIO_CTRL_GET_CLOSE` reports `BIO_NOCLOSE`;
- `BIO_CTRL_SET_CLOSE` is accepted without transferring backing-channel
  ownership;
- EOF and pending-byte queries conservatively report zero; and
- unknown controls and callback controls conservatively return zero.

The BIO never closes the backing channel.

## Counters

Public TLS counters retain their pre-revision meaning. TLS read/write call
counts and plaintext byte counts remain accounted at the TLS/framing layer.
Encrypted carrier read/write calls and ciphertext byte counts stay internal to
the adapter. Carrier wait facts—poll calls, interruptions, and would-block
observations—are merged into the exposed operation counters.

This prevents double-counting while retaining the diagnostics previously
visible when TLS polled the TCP descriptor directly.

## TLS policy preserved

Revision 0578 does not change:

- TLS 1.3 minimum and maximum;
- mutual certificate presentation;
- `natrav-overlay/1` ALPN;
- exact local identity loading and certificate/private-key matching;
- certificate validity-time checks;
- configured generation and SPKI pin selection;
- revoked-key rejection and ambiguous-pin rejection;
- early-data, ticket, compression, renegotiation, and session-cache policy;
- HELLO identity binding;
- close-notify handling; or
- application framing and durable semantics above TLS.

A clean TLS close returns EOF. A carrier EOF without close-notify remains
`TLS_TRUNCATED_EOF` where the read API observes it. Timeouts remain
`IO_TIMEOUT`; reset/read/write carrier failures are translated at the same TLS
operation boundary as before; certificate and protocol failures remain TLS
failures.

## Compatibility and non-goals

No peer byte, configuration byte, persisted byte, or external endpoint syntax
changed. TCP remains the only configured carrier. Listener readiness still uses
the concrete listener's readiness handle; that is a bounded accept-loop
mechanism, not peer identity or TLS authority.

This revision does not add a virtual carrier, serial/TTY, USB, Bluetooth,
radio, packet reliability, discovery, relay, routing, forwarding, tunneling, or
a helper process.

## Verification boundary

The registered `tls_byte_channel` suite checks revision metadata and source
negative controls, compiles the focused probe with production warning policy,
and exercises:

- BIO short read/write progress and conservative controls;
- EOF, timeout, retained callback exception, and invalid operation state;
- explicit backing-channel lifetime behavior;
- TLS 1.3 mutual authentication and exact application bytes over a segmented
  in-memory channel exposing no descriptor;
- bidirectional close-notify and clean EOF; and
- handshake early EOF, timeout, and reset classification.

The existing TLS-security, generation identity, persistent state, peer-session,
live-configuration, multi-route, runtime-inventory, and complete registered
matrices remain the broader regression boundary. Exact executed evidence is in
`validation/`.

No independent host or physical carrier was exercised. Revision 0578 is not a
hardware-behavior claim.
