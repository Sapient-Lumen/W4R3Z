# Exact conditional action administration — revision 0542

Contract retained; revision-specific testing described below is historical unless included in the [current validation scope](TESTING.md). Predecessor archives retain earlier raw evidence.

Revision 0542 adds an exact conditional form of `action-cancel`.  It binds the administrative decision to the durable action state and accepted configuration that the operator actually inspected, then commits the cancellation and an attributable administrative receipt in one journal record.

The runtime remains C++20.  No peer protocol, configuration version, storage schema, or action definition changed.

## Inspect, then act

An exact [`action-query`](ACTION-INSPECTION.md) row now contains:

```json
"condition": {
  "format": "ACTION_SEMANTIC_SELECTION_V1",
  "state_digest": "…",
  "metadata_digest": "…",
  "metadata_bytes": 354,
  "previous_action_root": "…",
  "retained_actions": 0,
  "latest_action": null
}
```

The response-level `configuration_digest` and row-level `condition.state_digest` are the two conditions for the mutation:

```sh
./node/bin/natrav-overlay action-cancel \
  --control state-b/control.sock \
  --action ACTION_HEX64 \
  --expected-state SELECTED_STATE_HEX64 \
  --expected-configuration SELECTED_CONFIGURATION_HEX64 \
  --reason 'cancel the inspected obligation'
```

Both optional conditions must be present together.  Omitting both selects the retained legacy cancellation command; supplying only one is rejected.  A process-local query cursor or action revision is never accepted as durable mutation authority.

## Semantic state commitment

The selected state commits to the bounded canonical `ACM1` action metadata and the preceding conditional-administration receipt root.  The metadata includes:

- immutable action/source identity, record digest, issuer, peer generation, stable queue sequence and original limits;
- current pending, started, completed, cancelled or expired action state;
- current reservation, attempt count, latest start, terminal times and result receipt;
- exact source-admission sequence, record digest and authorization-account digest;
- up to four retained configuration-binding commitments for admission, latest start, completion and terminal state.

Payload bytes and free-form reasons are not copied into the selection.  The source record digest and authorization digest bind them indirectly where applicable.  The metadata limit is 32,768 bytes.

The condition is recomputed under the action-state mutex immediately before mutation.  A completion, expiry, legacy cancellation, changed attempt account, changed source/configuration commitment, or prior conditional action produces:

```text
ACTION_STATE_CONFLICT
```

A changed accepted configuration produces:

```text
ACTION_CONFIGURATION_CONFLICT
```

A fresh selection still cannot override terminal action rules.  Completed, expired and cancelled actions remain terminal.

## Current authority and serialization

The kernel-authenticated Unix-socket UID must hold current `ACTION` authority in V8 or later.  Authorization occurs after strict request decoding, and the accepted configuration is retained through comparison and commit.

The same action-transition mutex used by the worker and ordinary cancellation serializes:

```text
post-decode authorization
→ exact condition comparison
→ terminal-rule check
→ semantic transition validation
→ synchronized journal append
```

The worker therefore either wins first and invalidates the selected state, or the cancellation wins and the worker observes terminal state.  No stale selection can apply an effect.

## Atomic receipt

The local request body is `ACA1`.  Journal kind **36** stores `AAT1`, containing:

- the exact request and its UID-bound digest;
- real UID, GID and PID;
- accepted configuration-event ordinal;
- decision time;
- preceding administrative root;
- complete bounded before-state metadata;
- source-derived resulting metadata digest.

The ordinary action cancellation and the receipt are applied by one semantic kind-36 transition.  A checkpoint cannot retain the `ACTION_CANCELLED_CONDITIONAL` marker without the matching receipt, and cannot retain a receipt whose before state, source, bindings or resulting action differ.

The optional logical-state extension `NAA1` preserves the bounded receipts during checkpointing, compaction, backup, restore and relocation.  States without conditional action receipts retain their preceding logical encoding.

The current limits are:

| Resource | Limit |
|---|---:|
| Conditional action receipts globally | 1,024 |
| Conditional receipts for one action | 1 |
| Selected before-state metadata | 32,768 bytes |

One receipt per action is sufficient because cancellation is terminal.  No history is silently reclaimed.

## Exact retry and bounded response

The request identity commits to the action, selected state, selected configuration, reason and actual UID.  One successful command returns `APPLIED`; exact repeats by the same currently authorized UID return `ALREADY_APPLIED` without a second journal append.

The receipt returns reason length and SHA-256, not the reason text.  Its observation is an exact bounded lookup of the affected action; it does not construct a whole application snapshot.

An exact retry may recover the original receipt after restart, compaction, encrypted restore or owner-path relocation.  It does not prove freshness against replacement with an older complete valid state.

The retained legacy `action-cancel` response remains compatible at its top level while also including the same narrow current-action observation.  Legacy cancellation does not create a conditional receipt and invalidates any earlier semantic selection.

## Crash and corruption boundaries

Real test hooks bracket the synchronized kind-36 append:

- killed before commit: neither cancellation nor receipt is authoritative;
- killed after commit: both reconstruct together, even if the client missed the reply.

Normal authenticated-tail rules remain unchanged.  An arbitrarily incomplete keyed record still requires explicit audit/recovery.

Tests alter the selected state in ordinary journal records and checkpoint material while recomputing the unkeyed outer checksums.  Semantic replay still rejects the forged state.  A negative-control build that omits the state comparison is required to fail the selected regression.

## Boundaries

Conditional cancellation is local administration, not remote recall.  It cannot prove that another effect outside this bounded local sink never occurred, and it cannot reverse an already completed counter commit.  The action model still records only attempt count and latest start—not a complete attempt timeline.  Valid old-state rollback, copied-state divergence, host compromise and universal physical-power-loss behavior remain outside this guarantee.

## Result-bound actions (0544)

Conditional cancellation now supports V18 result-bound actions. `ACM2` semantic selection includes the immutable result policy, exact key, reserved capacity and outcome. One kind-36 `AAT2` record couples the administrative `AAT1` receipt with the exact `NAT1` terminal result and queue conversion. Legacy local-only `ACM1`/`AAT1` behavior is unchanged.

A reserved action converts only its own capacity. A legacy unreserved action still requires ordinary free quota. Terminal semantics, current `ACTION` authority, post-decode configuration stability, exact retry, and action-worker serialization remain enforced. See [result capacity](RESULT-CAPACITY.md).
