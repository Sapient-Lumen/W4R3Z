# Offline authenticated correlated-stop audit

Revision 0570 adds one read-only command for the operator workflow that follows a lost correlated stop response:

```sh
./node/bin/natrav-overlay correlated-stop-audit \
  --state state-a \
  --node A \
  --state-auth-key /separate-keys/state-a-g1.key \
  --correlation ops-20261012-a01 \
  --stop immediate \
  --final-state-head yes
```

The command acquires the existing state lock and journal exclusively, opens both existing files read-only with no-follow/no-atime protections, authenticates the complete keyed journal, performs complete semantic replay in memory, derives the exact existing NOC1 request identity, and selects the matching durable local-control and lifecycle accounts. It does not construct a filesystem writer, start workers, repair a tail, compact, recover, relocate, restore, or change any supplied byte.

The response format is:

```text
NATRAV_OVERLAY_OFFLINE_CORRELATED_STOP_AUDIT_V1
```

## Selection alternatives

Exactly one selection form is required.

### Explicit correlated request shape

Immediate stop:

```sh
./node/bin/natrav-overlay correlated-stop-audit \
  --state state-a --node A --state-auth-key state-a-g1.key \
  --correlation ops-20261012-a01 \
  --stop immediate \
  --final-state-head yes
```

Drain stop:

```sh
./node/bin/natrav-overlay correlated-stop-audit \
  --state state-a --node A --state-auth-key state-a-g1.key \
  --correlation ops-20261012-a02 \
  --stop drain \
  --final-state-head yes \
  --drain-deadline-ms 5000 \
  --reason 'bounded maintenance stop'
```

`--final-state-head no` selects correlated ordinary kinds 44/45. `yes` selects correlated terminal kinds 46/47. The implementation invokes the same strict request encoder and existing request-ID function used by the online control path. It does not maintain a second request-shape registry or guess an identity from lifecycle rows.

The canonical correlation token is 1–64 lowercase ASCII bytes, uses only `a-z`, `0-9`, `.`, `_`, and `-`, and starts and ends alphanumerically. Drain deadlines remain 1–600,000 milliseconds and reasons remain 1–256 bytes under the existing strict request encoder.

### Exact request ID

```sh
./node/bin/natrav-overlay correlated-stop-audit \
  --state state-a --node A --state-auth-key state-a-g1.key \
  --request-id 64_LOWERCASE_HEX_DIGITS
```

Exact-ID selection does not recover or disclose the caller’s token. It can also select a denied attempt, a missing ID, or an ID belonging to another command. Such results are labelled rather than silently treated as an accepted correlated stop.

Shape fields and `--request-id` cannot be mixed.

## Authentication and replay boundary

A successful report follows this order:

```text
safe existing-directory traversal
    ↓
exclusive nonblocking ownership of existing lock and journal
    ↓
complete authenticated-header and record-chain verification
    ↓
complete semantic replay of every authenticated application frame
    ↓
optional exact NASH1 expectation comparison
    ↓
derived-index consistency checks
    ↓
exact request-ID selection
    ↓
complete bounded JSON construction
    ↓
source identity, mode, size, and byte equality recheck
```

An incomplete tail is not audited as a successful stopped state, even when its maximal verified prefix contains the selected request. The existing explicit recovery command remains the only path for eligible incomplete-tail adoption. A valid MAC over semantically invalid application state also fails; the selector cannot bypass replay.

`--expected-state-head NASH1:...` is supported as an additional exact-input precondition. It is checked after authentication and semantic replay. It does not authorize the read, repair state, or update itself.

The command requires keyed state and an explicit state-authentication key. The key, path names, authentication transition reasons, and recovery history are not emitted.

## Report contents

A complete response includes:

- the exact current authenticated `NASH1` state-head selector for the supplied representation;
- the keyed authentication generation, key ID, epoch, root, record count, and purpose;
- the independently derived or explicitly supplied request ID;
- every matching retained authorization-decision row;
- every matching retained lifecycle row;
- an aggregate stop-outcome classification;
- current replay-derived pending outbound and pending action counts;
- complete source byte count and SHA-256 for change detection;
- explicit statements that no writer or worker was opened, no state was mutated, freshness is not established, and no external expectation was updated.

Decision rows include retained principal numbers, command/class, decision, error code, exact accepted-configuration reference, and history-prefix commitment. Lifecycle rows include their kind, timestamp, recorded pending counts, deadline, accepted-configuration reference, and history-prefix commitment.

Free-text lifecycle reasons are not returned. The report carries only their byte count and a domain-separated SHA-256 commitment:

```text
SHA256("NATRAV_OVERLAY_LIFECYCLE_REASON_V1" || 0x00 || reason_bytes)
```

That commitment permits comparison with a caller-supplied explicit drain shape; it is not confidentiality for a guessable reason. Evidence payloads, source payloads, secrets, certificate or key paths, relocation paths, and identity-file paths are absent.

`retained_obligations` describes the current completely replayed state, not necessarily the counts captured in a historical lifecycle row. Later authenticated work, compaction, restore provenance, or relocation can change the current head or retained counts while preserving the selected stop rows.

## Duplicate and adverse outcomes

The command preserves all matching rows in retained order. It does not invent one invocation per request ID. Repeated byte-identical correlated requests intentionally share one request ID and can contribute multiple decision and lifecycle rows.

Aggregate classifications include:

```text
NOT_FOUND
DENIED
ACCEPTED_IMMEDIATE
ACCEPTED_DRAIN_COMPLETED
ACCEPTED_DRAIN_DEADLINE
DRAIN_STARTED_WITHOUT_TERMINAL_BOUNDARY
AUTHORIZED_WITHOUT_LIFECYCLE_BOUNDARY
EXPLICIT_REQUEST_SHAPE_CONFLICT
REQUEST_ID_MATCHES_NON_CORRELATED_STOP_HISTORY
MIXED_DUPLICATE_OUTCOMES
```

The complete rows remain authoritative for interpretation. A classification is not permission, idempotency, retry authorization, proof that a response arrived, recovery authority, or a freshness anchor.

## Bounds

```text
--max-matches  1..64       default 64
--max-bytes    4096..60000 default 60000
```

The match limit applies to the combined decision and lifecycle rows. If all matching rows do not fit, the command fails with `CORRELATED_STOP_AUDIT_MATCH_LIMIT` or `CORRELATED_STOP_AUDIT_RESPONSE_TOO_LARGE`. It never truncates, paginates, or silently skips duplicate attempts.

The complete state journal remains subject to `--max-journal-bytes` and the existing 1 GiB ceiling.

## Concurrency and mutation boundary

A running daemon or other state owner causes `STATE_BUSY`. The audit does not fall back to a live control request or read an unlocked journal. It obtains no current online `INSPECT` grant because there is no connected control principal; possession of the separately managed state directory and state-authentication key is the offline trust boundary.

The existing owner/mode/single-link/no-symlink checks apply. The source is reread and compared before success. Corruption, wrong keys, malformed frames, invalid application transitions, and incomplete tails fail closed and leave the source unchanged.

## Operator workflow after a lost terminal response

1. Choose and protect a fresh canonical correlation token before transmission.
2. Derive or record the exact request ID and request shape.
3. Send the correlated stop or correlated terminal-head request.
4. If the response is lost, independently establish that the process stopped and no replacement writer owns the state.
5. Run this offline command with the separately held state-authentication key and, when available, a separately protected expected `NASH1` value.
6. Inspect all matching rows, the aggregate outcome, and retained obligations.
7. Protect any newly observed head through the operator’s external custody procedure; the product does not update it automatically.

A successful report proves only what the supplied authenticated representation and complete semantic replay establish. It does not prove that the representation is the latest one ever produced unless the caller supplies and protects an appropriate external expectation.

## Compatibility

Revision 0570 adds a CLI-only offline operation. It changes no NOC1 kind, journal record, authenticated header, checkpoint, backup, NSS/NST, application logical state, peer message, permission class, configuration version, storage schema, or product limit.

Revision 0569 does not recognize the new CLI command. It continues to replay the same durable stopped states because their representation is unchanged.
