# Detached authenticated-state-head custody

Revision 0572 adds an explicitly managed record for retaining an expected
`NASH1` authenticated-state head outside a node's rollbackable state
directory. The record is not discovered, followed, or updated automatically.

The feature has three offline commands:

```text
natrav-overlay state-head-custody-create \
  --record /protected-anchor/A.head \
  --node A \
  --domain primary-operations \
  --generation 1 \
  --head NASH1:...

natrav-overlay state-head-custody-read \
  --record /protected-anchor/A.head \
  [--expect-node A] \
  [--expect-domain primary-operations] \
  [--expect-generation 1] \
  [--expect-head NASH1:...] \
  [--expect-digest 64_lowercase_hex]

natrav-overlay state-head-custody-advance \
  --record /protected-anchor/A.head \
  --expect-node A \
  --expect-domain primary-operations \
  --expect-generation 1 \
  --expect-head NASH1:... \
  --expect-digest 64_lowercase_hex \
  --new-generation 2 \
  --new-head NASH1:...
```

`state-head-custody-advance` is an exact compare-and-swap. It requires every
old account shown above and refuses to publish unless the path still identifies
the exact inode and bytes that were originally read. A generation must advance
strictly; it is a custodian-managed sequence, not a journal record count or an
authentication generation.

## Canonical record

The record is a bounded canonical binary object:

```text
magic                  8 bytes   "NHCUST01"
version                 u32       1
node                    text16
custody domain          text16
custody generation      u64
exact NASH1 selector    text16
content digest          32 bytes
```

The content digest is:

```text
SHA256(
  "NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_RECORD_V1" || 0x00 ||
  all preceding record bytes
)
```

The response also returns `record_digest`, the SHA-256 of the complete file.
The complete record is limited to 1,024 bytes. The custody domain is 1–64
canonical lowercase ASCII bytes using the same bounded token shape as the
correlated-stop token grammar. The `NASH1` selector must be canonical and its
node must equal the custody record's node.

The content digest catches malformed or accidentally changed record material.
It is not a MAC or signature. Filesystem custody and the operator's protection
of the detached record remain part of the trust boundary.

## Filesystem and publication boundary

Each command traverses the explicit parent path component by component without
following symbolic links. The final parent must be owned by the effective user
and must not be writable by group or other. A retained record must be:

- a regular file;
- owned by the effective user;
- mode `0600`;
- singly linked; and
- no larger than the fixed record ceiling.

Creation writes and verifies an owner-only same-directory staging file, syncs
it, publishes with `renameat2(..., RENAME_NOREPLACE)`, syncs the parent
directory, and reopens the published path to compare its exact bytes with the
candidate before reporting success. It never overwrites an existing destination.

Advancement writes and verifies the replacement in the same directory, syncs
it, reopens and compares the exact old path immediately before publication,
then uses `renameat2(..., RENAME_EXCHANGE)`. The displaced name must contain
the stable inode account and exact old bytes. The directory is synced after
publication and again after removal of the displaced old record.

An advisory lock serializes cooperating custody commands in one parent
directory. The exact byte/inode recheck remains necessary because an unrelated
process need not honor that advisory lock.

A failed expectation, malformed input, injected prepublication failure,
postpublication create replacement, or detected advancement race returns an
error and never reports success. A
separate process that wins a replacement race remains authoritative at the
path; the custody command does not overwrite that winner.

## Meaning and limitations

The record means only:

> this custodian explicitly retained this exact authenticated-state head under
> this domain and custody generation.

It does not mean that the head is currently present, latest, reachable, or
semantically acceptable. It is not:

- a node permission or local-control credential;
- a state-authentication key;
- recovery or restore authorization;
- an idempotency key;
- a confirmed response receipt;
- proof that a terminal head was received; or
- a managed freshness service.

No command opens node state, starts a worker, reads a journal, or updates an
external record automatically. To constrain a node open in revision 0572, the
operator reads and independently selects the retained `state_head.selector`,
then supplies that exact selector through the existing
`--expected-state-head` option. That separation is deliberate.

A valid old state supplied together with its corresponding old detached record
still matches. Freshness depends on protecting and selecting the intended
custody record outside rollbackable node state.

## Validation boundary

The revision-0572 suite independently decodes the binary record and recomputes
both digests. It covers creation, exact readback, successful compare-and-swap,
every old binding, nonadvancing generations, malformed and noncanonical
records, loose modes, hard links, symbolic links, unsafe parents, an injected
prepublication failure, a path-replacement race, destination collision, and
strict no-state/no-worker behavior.

The deliberately weakened control omits only the complete-file digest from the
old-account comparison. The exact wrong-digest case must then be accepted by
the weakened binary and detected by the test.

## Direct consumption by state-opening commands (0573)

Revision 0573 removes the need to copy `state_head.selector` through shell text.
Commands that already accept a raw external expectation may instead provide the
complete custody option group described in
[Custody-constrained state opening](CUSTODY-CONSTRAINED-STATE-OPENING.md).

This does not add automatic discovery or update. The explicitly named record is
verified and rechecked as an immutable input condition, while creation and
advancement remain separate `state-head-custody-*` operations. New output heads
must still be reviewed and advanced explicitly.
