# Detached custody-promotion intent — revision 0576

## Purpose

`NHCPI001` is a canonical detached record of one fully validated custody-
promotion candidate. It lets an operator create a bounded account before the
destructive compare-and-swap, then use that exact account for promotion or a
read-only outcome audit.

The record is **evidence, not authority**. Possession of an intent does not grant
permission, select a source, establish freshness, authenticate a key or signer,
make a duplicate attempt idempotent, prove that a response was received, or
cause automatic promotion. Every use requires the caller to supply the source
and trust material again. The product re-authenticates the source and reproduces
the exact account recorded in the intent.

## Operations

### Create from a stopped keyed state directory

```sh
./node/bin/natrav-overlay state-head-custody-promotion-intent-create \
  --intent /protected-intents/A-to-8.intent \
  --record /protected-anchor/A.head \
  --expect-node A \
  --expect-domain primary-operations \
  --expect-generation 7 \
  --expect-head 'NASH1:A:...' \
  --expect-digest 64_lowercase_hex \
  --new-generation 8 \
  --state /srv/natrav/state-a \
  --state-auth-key /protected-keys/state-a-g1.key
```

The state directory must be stopped, schema 2, owned by the effective user, and
mode `0700`. Its `state.lock`, `node.meta`, and `state.journal` files must satisfy
the existing private-file rules. The command acquires the existing nonblocking
exclusive state and journal locks, authenticates the complete journal,
semantically replays it, proves the old authenticated prefix or direct
checkpoint-parent relation, derives the candidate `NASH1`, and rechecks the
exact journal before and after intent publication.

### Create from a signed encrypted backup

```sh
./node/bin/natrav-overlay state-head-custody-promotion-intent-create \
  --intent /protected-intents/A-to-8.intent \
  --record /protected-anchor/A.head \
  --expect-node A \
  --expect-domain primary-operations \
  --expect-generation 7 \
  --expect-head 'NASH1:A:...' \
  --expect-digest 64_lowercase_hex \
  --new-generation 8 \
  --input /protected-backups/A.nob \
  --generation a-g1 \
  --decrypt-key /protected-keys/backup-a-g1.key \
  --trusted-cert /protected-identities/A-a-g1.crt \
  --require-signature yes \
  --require-encryption yes \
  --expected-backup-id 64_lowercase_hex \
  --state-auth-key /protected-keys/state-a-g1.key
```

The backup path is opened as one exact owner-private immutable input. Creation
requires authenticated encryption, a valid signature by the explicitly trusted
certificate, the expected node and identity generation, an optional exact
backup ID, complete embedded checkpoint authentication, and semantic replay.
The intent binds both the outer backup representation and the authenticated
checkpoint account.

### Promote with an intent

State source:

```sh
./node/bin/natrav-overlay state-head-custody-promote \
  --intent /protected-intents/A-to-8.intent \
  --record /protected-anchor/A.head \
  --state /srv/natrav/state-a \
  --state-auth-key /protected-keys/state-a-g1.key
```

Backup source:

```sh
./node/bin/natrav-overlay state-head-custody-promote \
  --intent /protected-intents/A-to-8.intent \
  --record /protected-anchor/A.head \
  --input /protected-backups/A.nob \
  --generation a-g1 \
  --decrypt-key /protected-keys/backup-a-g1.key \
  --trusted-cert /protected-identities/A-a-g1.crt \
  --require-signature yes \
  --require-encryption yes \
  --expected-backup-id 64_lowercase_hex \
  --state-auth-key /protected-keys/state-a-g1.key
```

The currently named custody file must be byte-for-byte the old record bound by
the intent. The revalidated source must reproduce the exact source account,
relationship, and derived selector. The product then performs the existing
same-directory synchronized atomic custody exchange. Reusing the intent after a
successful promotion fails because the exact old custody record is no longer
present; the intent is not an idempotency token.

### Audit with an intent

Use the same source arguments with:

```sh
./node/bin/natrav-overlay state-head-custody-promotion-audit \
  --intent /protected-intents/A-to-8.intent \
  --record /protected-anchor/A.head \
  --state /srv/natrav/state-a \
  --state-auth-key /protected-keys/state-a-g1.key
```

The audit does not retry promotion. After exact source, intent, and custody
rechecks it returns one of:

```text
NOT_APPLIED_EXACT_OLD_RECORD
APPLIED_EXACT_DERIVED_SUCCESSOR
CURRENT_CUSTODY_DIVERGED
```

An intent can only have been created from an eligible successor. If the
explicitly supplied source no longer reproduces the recorded source account or
successor, the audit fails closed with an intent source mismatch rather than
reclassifying the old intent around new evidence.

## Inline and detached forms are alternatives

The original inline promotion and outcome-audit forms remain available. A
caller must choose either:

- `--intent FILE` plus `--record FILE` and one complete source; or
- the complete inline old custody account, intended new generation,
  `--record FILE`, and one complete source.

Mixing `--intent` with any inline old-account or new-generation field is
rejected with `STATE_HEAD_CUSTODY_PROMOTION_INTENT_ARGUMENT_CONFLICT`.

## Canonical `NHCPI001` encoding

All integers are unsigned big-endian. Text values are UTF-8 byte strings with a
16-bit big-endian length. Digests are 32 raw bytes. Optional text uses length
zero for absent; optional digests use 32 zero bytes for absent. Strict EOF and
canonical re-encoding are required.

| Field | Encoding |
|---|---|
| magic | 8 bytes: `NHCPI001` |
| version | `u32`, value `1` |
| canonical custody path | `text16`, at most 4096 bytes |
| complete old `NHCUST01` bytes | `u16` length plus bytes, at most 1024 |
| old whole-file digest | 32-byte SHA-256 |
| intended new custody generation | `u64`, strictly greater than old |
| source kind | `u8`: `1` state directory, `2` signed encrypted backup |
| canonical source path | `text16`, at most 4096 bytes |
| source representation length | `u64` |
| source representation digest | 32-byte SHA-256 |
| authenticated journal/checkpoint length | `u64` |
| authenticated journal/checkpoint digest | 32-byte SHA-256 |
| logical-state digest | 32 bytes |
| identity generation | optional `text16`, at most 128 bytes |
| backup ID | optional 32-byte digest |
| signer SPKI SHA-256 | optional 32-byte digest |
| encryption-key generation | optional `text16`, at most 128 bytes |
| encryption-key ID | optional 32-byte digest |
| successor relationship | `text16`, at most 64 bytes |
| derived `NASH1` selector | `text16`, at most 512 bytes |
| content commitment | 32 bytes |

The whole record is at most 16,384 bytes. The content commitment is:

```text
SHA-256(
  "NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_INTENT_V1"
  || 0x00
  || every preceding encoded byte
)
```

For a state-directory source, representation and authenticated bytes/digests are
the exact complete journal and all backup-only identity fields are absent.

For a signed encrypted backup, representation fields identify the exact outer
backup file. Authenticated fields identify the verified embedded checkpoint.
The backup identity generation, backup ID, signer SPKI digest, encryption-key
generation, and encryption-key ID are all present and exact.

Supported successor relationships are:

```text
VERIFIED_APPEND_ONLY_EXTENSION
VERIFIED_AUTHENTICATED_CHECKPOINT_SUCCESSOR
```

## Filesystem and publication boundary

The intent path and custody path are explicit and distinct. Dot-dot components,
unsafe filenames, symlinked path components, unsafe parent ownership or
writability, and noncanonical absolute paths are rejected.

An existing intent must be a regular file owned by the effective user, exact
mode `0600`, with link count one and bounded nonzero size. Creation:

1. opens and locks the intent parent;
2. reads and validates the exact old custody file;
3. validates and retains the exact source;
4. encodes the complete intent;
5. creates a random owner-only staging file in the destination directory;
6. writes, `fsync`s, rereads, and verifies the staging bytes;
7. rechecks custody and source;
8. publishes with Linux `renameat2(..., RENAME_NOREPLACE)`;
9. `fsync`s the parent directory; and
10. rereads and rechecks the published intent, source, and custody.

A post-publication recheck failure can leave a correctly encoded but stale
intent artifact. That is intentionally safe: the artifact has no authority and
all later uses must revalidate and reproduce every bound account. Operators may
retain it as evidence or remove it explicitly.

Promotion and audit lock and snapshot the explicit intent, verify canonical
bytes, require its bound custody path to equal the explicit `--record` path,
revalidate the source, and recheck the exact intent identity at the final
boundary. Path replacement suppresses apparent success.

## Trust and freshness exclusions

`NHCPI001` does not establish:

- global latestness or absence of another authenticated branch;
- current authorization or permission;
- control over the state-authentication, decryption, signing, or encryption
  keys named by its account;
- delivery, remote observation, or response receipt;
- automatic discovery or automatic promotion;
- idempotency or duplicate suppression;
- recovery authority;
- an authenticated peer identity; or
- safe use with a path, source representation, custody record, domain,
  generation, signer, or key different from the exact bound account.

Custody freshness remains the custodian's explicit selection and protection
responsibility.

## Validation boundary

`node/tests/run_custody_promotion_intent.py` independently decodes the binary
format and verifies its commitment. The focal predecessor-aware run covers:

- state-directory create, pending audit, promote, applied audit, and duplicate;
- exact source-path and source-byte binding;
- stale and divergent source rejection during creation;
- source and custody replacement during creation before publication;
- atomic no-replace publication;
- intent replacement during consumption;
- exact `0600`/single-link requirements;
- signed encrypted backup creation and use;
- wrong state key, decryption key, and signer;
- strict detached-versus-inline argument separation;
- corruption rejection; and
- revision-0575 fail-closed behavior.

These tests are local deterministic evidence. They do not establish physical
power-loss durability, independent-host operation, confirmed response receipt,
or hardware-carrier behavior.
