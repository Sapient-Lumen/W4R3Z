#!/bin/sh
set -eu
cd "$(dirname "$0")"

mode=${1:-static}
jobs=${JOBS:-2}
case "$jobs" in
  ''|*[!0-9]*) echo 'JOBS must be a positive integer' >&2; exit 2 ;;
esac
if [ "$jobs" -lt 1 ] || [ "$jobs" -gt 8 ]; then
  echo 'JOBS must be between 1 and 8' >&2
  exit 2
fi

compiler=${CXX:-/usr/bin/g++}
compile_extra=
link_extra=
warning_extra=
optimization=-O1
case "$mode" in
  static)
    link_extra=-static
    output=bin/natrav-overlay
    ;;
  sanitize)
    optimization=-O0
    compile_extra='-fsanitize=address,undefined -fno-omit-frame-pointer -fno-pie'
    link_extra='-fsanitize=address,undefined -fno-omit-frame-pointer -fno-pie -no-pie'
    output=bin/natrav-overlay-sanitize
    ;;
  clang)
    compiler=/usr/local/swift/usr/bin/clang++
    link_extra=-static
    warning_extra=-Wno-unused-const-variable
    output=bin/natrav-overlay-clang
    ;;
  *)
    echo 'mode: static | sanitize | clang' >&2
    exit 2
    ;;
esac

sources='src/main.cpp
src/common.cpp
src/protocol.cpp
src/authorization.cpp
src/local_control.cpp
src/local_author.cpp
src/subscribed_source.cpp
src/import_scheduler.cpp
src/import_review.cpp
src/import_retirement.cpp
src/source_subscription.cpp
src/journal.cpp
src/socket.cpp
src/transport.cpp
src/serial_transport.cpp
src/serial_packet_framing.cpp
src/serial_packet_adapter.cpp
src/removable_media_bundle.cpp
src/removable_media_packet_adapter.cpp
src/udp_transport.cpp
src/unix_datagram_transport.cpp
src/virtual_transport.cpp
src/finite_packet_link.cpp
src/packet_port.cpp
src/adapter_profile.cpp
src/adapter_profile_catalog.cpp
src/adapter_configuration.cpp
src/adapter_transport.cpp
src/configured_adapter_endpoint.cpp
src/external_packet_adapter.cpp
src/packet_link_transport.cpp
src/node.cpp
src/peer_session.cpp
src/tls.cpp
src/tls_bio.cpp
src/config.cpp
src/runtime.cpp
src/runtime_status.cpp
src/runtime_inventory.cpp
src/configuration_history.cpp
src/control_history.cpp
src/control.cpp
src/evidence_query.cpp
src/outbox_query.cpp
src/action_query.cpp
src/action_result_query.cpp
src/result_review_history.cpp
src/action_selection.cpp
src/action_admin.cpp
src/outbox_admin.cpp
src/evidence_feed.cpp
src/consumer.cpp
src/consumer_inventory.cpp
src/publication_inventory.cpp
src/subscription_inventory.cpp
src/source_view_inventory.cpp
src/view_bindings.cpp
src/consumer_retirement.cpp
src/publication_channel.cpp
src/projection.cpp
src/projection_scheduler.cpp
src/numeric.cpp
src/evidence_index.cpp
src/delivery_index.cpp
src/pending_capacity.cpp
src/read_policy.cpp
src/identity.cpp
src/handoff_capsule.cpp
src/custody_envelope.cpp
src/custody_policy.cpp
src/custody_session_policy.cpp
src/custody_receiver_policy.cpp
src/custody_dispatch_policy.cpp
src/custody_session_service.cpp
src/custody_state.cpp
src/custody_authority.cpp
src/custody_bundle.cpp
src/custody_runtime.cpp
src/handoff_policy.cpp
src/handoff_io.cpp
src/handoff_runtime.cpp
src/backup.cpp
src/backup_crypto.cpp
src/state_auth.cpp
src/state_head_custody.cpp
src/custody_promotion.cpp
src/state_recovery.cpp
src/relocation.cpp
src/daemon.cpp
../foundation/src/core.cpp
../foundation/src/natrav_peer_session.cpp
../foundation/src/natrav_peer_stream.cpp
../foundation/src/natrav_peer_message.cpp
../foundation/src/natrav_peer_handshake.cpp'

common_flags="-D_GNU_SOURCE -std=c++20 $optimization -g0 -ffunction-sections -fdata-sections -Wall -Wextra -Wpedantic -Wconversion -Wsign-conversion -Wshadow -Wformat=2 -Werror -pthread $warning_extra $compile_extra -I../foundation/include -Isrc"
build_dir=$(mktemp -d "${TMPDIR:-/tmp}/natrav-overlay-build-$mode.XXXXXX")
mkdir -p bin
trap 'rm -rf "$build_dir"' EXIT HUP INT TERM

objects=
# Compile serially.  The large translation units are bounded in memory, and a
# foreground compiler cannot outlive cleanup of its object directory.  JOBS is
# retained as a validated compatibility input; deterministic handoff builds do
# not require parallel compilation.
for source in $sources; do
  object_name=$(printf '%s' "$source" | sed 's|^\.\./||; s|/|__|g; s|\.cpp$|.o|')
  object="$build_dir/$object_name"
  objects="$objects $object"
  # shellcheck disable=SC2086
  "$compiler" $common_flags -c "$source" -o "$object"
done

link_output="$build_dir/natrav-overlay"
# shellcheck disable=SC2086
"$compiler" -pthread $link_extra $objects \
  -Wl,--gc-sections -lssl -lcrypto -lz -lzstd -ldl -o "$link_output"
install -m 755 "$link_output" "$output"
sha256sum "$output"
