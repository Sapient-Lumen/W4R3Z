#include "peer_session.hpp"
#include "protocol.hpp"
#include "socket.hpp"
#include "tls.hpp"
#include "virtual_transport.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <thread>
#include <tuple>
#include <utility>
#include <vector>

namespace {

using natrav_overlay::AppError;
using natrav_overlay::Deadline;
using natrav_overlay::DeliveryReceipt;
using natrav_overlay::EvidenceRecord;
using natrav_overlay::FramedReader;
using natrav_overlay::IoCounters;
using natrav_overlay::IoOptions;
using natrav_overlay::KeyGenerationState;
using natrav_overlay::OutboundPeerSession;
using natrav_overlay::PeerSessionFrame;
using natrav_overlay::PeerSessionFrameKind;
using natrav_overlay::PeerSessionLimits;
using natrav_overlay::ReceiptDisposition;
using natrav_overlay::TlsChannel;
using natrav_overlay::TlsContext;
using natrav_overlay::TlsIdentityFiles;
using natrav_overlay::TlsTrustedGeneration;
using natrav_overlay::TlsTrustedIdentity;
using natrav_overlay::VirtualCarrierSchedule;
using natrav_overlay::VirtualEndpoint;
using natrav_overlay::VirtualFault;
using natrav_overlay::VirtualOperation;
using natrav_overlay::VirtualScheduleEvent;

struct CaseRecord final {
    std::string name;
    std::size_t assertions{0U};
};

struct ScheduleRecord final {
    std::string name;
    std::uint64_t seed{0U};
    std::string digest;
    std::size_t bytes{0U};
};

class Probe final {
public:
    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_code(
        Function&& function,
        const std::string_view code,
        const std::string_view detail) {
        bool observed = false;
        try {
            std::forward<Function>(function)();
        } catch (const AppError& error) {
            observed = error.code() == code;
        }
        check(observed, detail);
    }

    template <typename Function>
    void expect_app_error(Function&& function, const std::string_view detail) {
        bool observed = false;
        try {
            std::forward<Function>(function)();
        } catch (const AppError&) {
            observed = true;
        }
        check(observed, detail);
    }

    template <typename Function>
    void run_case(std::string name, Function&& function) {
        const auto before = assertions_;
        std::forward<Function>(function)();
        cases_.push_back(CaseRecord{
            .name = std::move(name),
            .assertions = assertions_ - before,
        });
    }

    void record_schedule(
        const std::filesystem::path& output,
        const std::string& name,
        const VirtualCarrierSchedule& schedule) {
        const auto bytes = natrav_overlay::encode_virtual_carrier_schedule(schedule);
        const auto digest = datacube::sha256(bytes);
        const auto path = output / (name + ".nvcs");
        std::ofstream stream(path, std::ios::binary | std::ios::trunc);
        if (!stream) {
            throw std::runtime_error("could not create canonical schedule artifact");
        }
        stream.write(
            reinterpret_cast<const char*>(bytes.data()),
            static_cast<std::streamsize>(bytes.size()));
        stream.close();
        if (!stream) {
            throw std::runtime_error("could not finish canonical schedule artifact");
        }
        schedules_.push_back(ScheduleRecord{
            .name = name,
            .seed = schedule.seed,
            .digest = datacube::hex_lower(digest),
            .bytes = bytes.size(),
        });
    }

    [[nodiscard]] std::size_t assertions() const noexcept { return assertions_; }
    [[nodiscard]] const std::vector<CaseRecord>& cases() const noexcept {
        return cases_;
    }
    [[nodiscard]] const std::vector<ScheduleRecord>& schedules() const noexcept {
        return schedules_;
    }

private:
    std::size_t assertions_{0U};
    std::vector<CaseRecord> cases_;
    std::vector<ScheduleRecord> schedules_;
};

[[nodiscard]] Deadline test_deadline(
    const std::chrono::milliseconds duration = std::chrono::seconds(5)) {
    return std::chrono::steady_clock::now() + duration;
}

[[nodiscard]] TlsIdentityFiles identity(
    const char* certificate,
    const char* private_key,
    const char* pin) {
    return TlsIdentityFiles{
        .certificate = certificate,
        .private_key = private_key,
        .expected_spki_sha256 = natrav_overlay::parse_spki_sha256(pin),
    };
}

[[nodiscard]] datacube::Digest32 operation_id(const std::string_view label) {
    return datacube::sha256(datacube::text_octets(
        std::string("NATRAV_VIRTUAL_CARRIER_TEST_OPERATION_V1\0", 41U) +
        std::string(label)));
}

[[nodiscard]] EvidenceRecord record(
    const std::string_view label,
    const std::string_view payload) {
    return EvidenceRecord{
        .operation_id = operation_id(label),
        .issuer = "CLIENT",
        .recipient = "SERVER",
        .scope = "virtual/session",
        .corrects = std::nullopt,
        .payload = datacube::text_octets(payload),
    };
}

[[nodiscard]] auto counter_tuple(const IoCounters& value) noexcept {
    return std::tuple(
        value.poll_calls,
        value.read_calls,
        value.write_calls,
        value.read_bytes,
        value.write_bytes,
        value.short_reads,
        value.short_writes,
        value.interrupted,
        value.would_block,
        value.frames_read);
}

[[nodiscard]] std::string counter_text(const IoCounters& value) {
    return std::to_string(value.poll_calls) + "/" +
        std::to_string(value.read_calls) + "/" +
        std::to_string(value.write_calls) + "/" +
        std::to_string(value.read_bytes) + "/" +
        std::to_string(value.write_bytes) + "/" +
        std::to_string(value.short_reads) + "/" +
        std::to_string(value.short_writes) + "/" +
        std::to_string(value.interrupted) + "/" +
        std::to_string(value.would_block) + "/" +
        std::to_string(value.frames_read);
}

[[nodiscard]] VirtualCarrierSchedule canonical_vector_schedule() {
    return VirtualCarrierSchedule{
        .seed = 0x0102030405060708ULL,
        .queue_capacity = 64U,
        .default_read_chunk = 7U,
        .default_write_chunk = 11U,
        .mtu = 13U,
        .half_duplex = true,
        .initial_grant = VirtualEndpoint::second,
        .events = {
            VirtualScheduleEvent{
                .endpoint = VirtualEndpoint::second,
                .operation = VirtualOperation::read,
                .fault = VirtualFault::timeout,
                .operation_index = 2U,
                .delay_steps = 3U,
                .maximum_bytes = 5U,
                .parameter = 0U,
            },
            VirtualScheduleEvent{
                .endpoint = VirtualEndpoint::first,
                .operation = VirtualOperation::write,
                .fault = VirtualFault::duplicate,
                .operation_index = 1U,
                .delay_steps = 2U,
                .maximum_bytes = 7U,
                .parameter = 1U,
            },
        },
    };
}

[[nodiscard]] VirtualCarrierSchedule session_schedule() {
    return VirtualCarrierSchedule{
        .seed = 0x8f43d1a9572bc601ULL,
        .queue_capacity = 65'536U,
        .default_read_chunk = 13U,
        .default_write_chunk = 17U,
        .mtu = 19U,
        .half_duplex = true,
        .initial_grant = VirtualEndpoint::first,
        .events = {
            VirtualScheduleEvent{
                .endpoint = VirtualEndpoint::first,
                .operation = VirtualOperation::write,
                .fault = VirtualFault::none,
                .operation_index = 1U,
                .delay_steps = 2U,
                .maximum_bytes = 5U,
                .parameter = 0U,
            },
            VirtualScheduleEvent{
                .endpoint = VirtualEndpoint::second,
                .operation = VirtualOperation::read,
                .fault = VirtualFault::none,
                .operation_index = 1U,
                .delay_steps = 1U,
                .maximum_bytes = 3U,
                .parameter = 0U,
            },
        },
    };
}

[[nodiscard]] VirtualCarrierSchedule fault_schedule(const VirtualFault fault) {
    std::uint32_t parameter = 0U;
    if (fault == VirtualFault::duplicate) {
        parameter = 1U;
    }
    return VirtualCarrierSchedule{
        .seed = 0x61f4aa702bd95519ULL +
            static_cast<std::uint64_t>(static_cast<std::uint8_t>(fault)),
        .queue_capacity = 65'536U,
        .default_read_chunk = 23U,
        .default_write_chunk = 29U,
        .mtu = 31U,
        .half_duplex = false,
        .initial_grant = std::nullopt,
        .events = {VirtualScheduleEvent{
            .endpoint = VirtualEndpoint::first,
            .operation = VirtualOperation::write,
            .fault = fault,
            .operation_index = 1U,
            .delay_steps = 1U,
            .maximum_bytes = 11U,
            .parameter = parameter,
        }},
    };
}

struct SessionRun final {
    std::array<DeliveryReceipt, 2U> receipts;
    datacube::Octets trace;
    IoCounters client_tls;
    IoCounters client_handshake;
    IoCounters client_session;
    IoCounters client_application;
    IoCounters server_tls;
    IoCounters server_io;
    std::size_t server_operations{0U};
    bool clean_close{false};
};

[[nodiscard]] SessionRun run_reusable_session(
    const VirtualCarrierSchedule& schedule,
    const TlsIdentityFiles& client_identity,
    const TlsIdentityFiles& server_identity) {
    auto link = natrav_overlay::make_virtual_link(schedule);
    auto server_stream = std::move(link.second);
    TlsContext client_context(client_identity);
    TlsContext server_context(server_identity);
    const std::vector<TlsTrustedIdentity> trusted_client{{
        .node_id = "CLIENT",
        .generations = {TlsTrustedGeneration{
            .generation = "client-g1",
            .spki_sha256 = client_identity.expected_spki_sha256,
            .state = KeyGenerationState::active,
        }},
    }};
    const IoOptions io{
        .timeout = std::chrono::seconds(8),
        .read_quantum = 47U,
        .write_quantum = 43U,
        .maximum_received_bytes = 1'048'576U,
    };
    const PeerSessionLimits limits{
        .maximum_operations = 4U,
        .maximum_bytes = 1'048'576U,
        .maximum_lifetime_ms = 20'000U,
        .idle_timeout_ms = 8'000U,
    };
    const std::array<EvidenceRecord, 2U> records{
        record("session-one", "alpha through the deterministic carrier"),
        record("session-two", "beta through the same authenticated session"),
    };

    IoCounters server_tls;
    IoCounters server_io;
    std::size_t server_operations = 0U;
    bool server_clean_close = false;
    std::exception_ptr server_failure;
    std::thread server([&] {
        try {
            const auto deadline = test_deadline(std::chrono::seconds(8));
            auto channel = TlsChannel::accept(
                server_context, *server_stream, trusted_client,
                deadline, server_tls);
            FramedReader reader(io);
            const auto hello = natrav_overlay::perform_server_handshake(
                channel, "SERVER", reader, deadline, io);
            if (hello.remote_artifact_digest !=
                natrav_overlay::node_artifact_digest("CLIENT")) {
                throw std::runtime_error("server HELLO identity mismatch");
            }
            const auto open = natrav_overlay::decode_peer_session_frame(
                reader.read_frame(channel, deadline, server_io));
            if (open.kind != PeerSessionFrameKind::open ||
                !open.limits.has_value()) {
                throw std::runtime_error("server did not receive NOS1 OPEN");
            }
            const PeerSessionFrame acknowledgement{
                .kind = PeerSessionFrameKind::open_ack,
                .flags = 0U,
                .session_id = open.session_id,
                .sequence = 0U,
                .operation_id = {},
                .limits = *open.limits,
                .payload = {},
            };
            const auto encoded_ack =
                natrav_overlay::encode_peer_session_frame(acknowledgement);
            natrav_overlay::write_frame(
                channel, encoded_ack, deadline, io, server_io);

            for (std::uint32_t sequence = 1U; sequence <= 2U; ++sequence) {
                const auto request = natrav_overlay::decode_peer_session_frame(
                    reader.read_frame(channel, deadline, server_io));
                if (request.kind != PeerSessionFrameKind::request ||
                    request.session_id != open.session_id ||
                    request.sequence != sequence) {
                    throw std::runtime_error("server request envelope mismatch");
                }
                const auto message = natrav_overlay::decode_application_message(
                    request.payload);
                const auto* evidence = std::get_if<EvidenceRecord>(&message);
                if (evidence == nullptr ||
                    evidence->operation_id != request.operation_id) {
                    throw std::runtime_error("server application binding mismatch");
                }
                ++server_operations;
                const DeliveryReceipt receipt{
                    .operation_id = evidence->operation_id,
                    .recipient = evidence->recipient,
                    .recorder = evidence->recipient,
                    .disposition = ReceiptDisposition::committed,
                    .sequence = sequence,
                    .record_digest = natrav_overlay::evidence_record_digest(*evidence),
                };
                const auto application =
                    natrav_overlay::encode_application_message(receipt);
                const PeerSessionFrame response{
                    .kind = PeerSessionFrameKind::response,
                    .flags = 0U,
                    .session_id = open.session_id,
                    .sequence = sequence,
                    .operation_id = evidence->operation_id,
                    .limits = std::nullopt,
                    .payload = application,
                };
                const auto encoded =
                    natrav_overlay::encode_peer_session_frame(response);
                natrav_overlay::write_frame(
                    channel, encoded, deadline, io, server_io);
            }

            const auto close = natrav_overlay::decode_peer_session_frame(
                reader.read_frame(channel, deadline, server_io));
            if (close.kind != PeerSessionFrameKind::close ||
                close.session_id != open.session_id || close.sequence != 3U) {
                throw std::runtime_error("server clean-close envelope mismatch");
            }
            const PeerSessionFrame close_ack{
                .kind = PeerSessionFrameKind::close_ack,
                .flags = 0U,
                .session_id = open.session_id,
                .sequence = close.sequence,
                .operation_id = {},
                .limits = std::nullopt,
                .payload = {},
            };
            const auto encoded_close =
                natrav_overlay::encode_peer_session_frame(close_ack);
            natrav_overlay::write_frame(
                channel, encoded_close, deadline, io, server_io);
            std::array<std::uint8_t, 1U> tls_eof{};
            const auto tls_close = channel.read_some(
                tls_eof, deadline, server_tls,
                "server waits for client TLS close-notify");
            if (tls_close != 0U) {
                throw std::runtime_error(
                    "server received application bytes after NOS1 close");
            }
            channel.close_notify(deadline, server_tls);
            server_clean_close = true;
        } catch (...) {
            server_failure = std::current_exception();
            link.control->reset_link();
        }
    });

    std::array<DeliveryReceipt, 2U> receipts;
    IoCounters client_tls;
    IoCounters client_handshake;
    IoCounters client_session;
    IoCounters client_application;
    bool client_clean_close = false;
    bool server_joined = false;
    std::exception_ptr client_failure;
    try {
        auto session = OutboundPeerSession::open_connected(
            client_context,
            "CLIENT",
            "SERVER",
            "server-g1",
            KeyGenerationState::active,
            server_identity.expected_spki_sha256,
            std::move(link.first),
            records[0U].operation_id,
            io,
            limits);
        client_tls = session.open_counters().tls;
        client_handshake = session.open_counters().handshake;
        client_session = session.open_counters().session;
        receipts[0U] = session.exchange(records[0U], io);
        receipts[1U] = session.exchange(records[1U], io);
        client_application = session.application_counters();
        client_clean_close = session.close_cleanly(io);
        server.join();
        server_joined = true;
    } catch (...) {
        client_failure = std::current_exception();
        link.control->reset_link();
    }
    if (!server_joined) {
        server.join();
    }
    if (client_failure) {
        std::rethrow_exception(client_failure);
    }
    if (server_failure) {
        std::rethrow_exception(server_failure);
    }
    if (!client_clean_close || !server_clean_close) {
        throw std::runtime_error("authenticated session did not close cleanly");
    }
    const auto snapshot = link.control->snapshot();
    return SessionRun{
        .receipts = receipts,
        .trace = natrav_overlay::encode_virtual_trace(snapshot.trace),
        .client_tls = client_tls,
        .client_handshake = client_handshake,
        .client_session = client_session,
        .client_application = client_application,
        .server_tls = server_tls,
        .server_io = server_io,
        .server_operations = server_operations,
        .clean_close = client_clean_close && server_clean_close,
    };
}

struct FaultRun final {
    bool client_failed{false};
    bool server_failed{false};
    bool server_authenticated{false};
    datacube::Octets trace;
};

[[nodiscard]] FaultRun run_tls_fault(
    const VirtualCarrierSchedule& schedule,
    const TlsIdentityFiles& client_identity,
    const TlsIdentityFiles& server_identity) {
    auto link = natrav_overlay::make_virtual_link(schedule);
    auto server_stream = std::move(link.second);
    TlsContext client_context(client_identity);
    TlsContext server_context(server_identity);
    const std::vector<TlsTrustedIdentity> trusted_client{{
        .node_id = "CLIENT",
        .generations = {TlsTrustedGeneration{
            .generation = "client-g1",
            .spki_sha256 = client_identity.expected_spki_sha256,
            .state = KeyGenerationState::active,
        }},
    }};
    std::atomic<bool> server_authenticated{false};
    std::atomic<bool> server_failed{false};
    std::thread server([&] {
        try {
            IoCounters counters;
            auto channel = TlsChannel::accept(
                server_context, *server_stream, trusted_client,
                test_deadline(std::chrono::milliseconds(700)), counters);
            server_authenticated.store(true);
            std::array<std::uint8_t, 1U> ignored{};
            static_cast<void>(channel.read_some(
                ignored, test_deadline(std::chrono::milliseconds(100)), counters,
                "fault fixture post-handshake read"));
        } catch (...) {
            server_failed.store(true);
        }
    });

    bool client_failed = false;
    try {
        IoCounters counters;
        static_cast<void>(TlsChannel::connect(
            client_context,
            *link.first,
            "SERVER",
            "server-g1",
            KeyGenerationState::active,
            server_identity.expected_spki_sha256,
            test_deadline(std::chrono::milliseconds(700)),
            counters));
    } catch (...) {
        client_failed = true;
    }
    link.control->reset_link();
    server.join();
    const auto snapshot = link.control->snapshot();
    return FaultRun{
        .client_failed = client_failed,
        .server_failed = server_failed.load(),
        .server_authenticated = server_authenticated.load(),
        .trace = natrav_overlay::encode_virtual_trace(snapshot.trace),
    };
}

[[nodiscard]] std::string app_error_code(const std::exception_ptr& failure) {
    if (!failure) {
        return {};
    }
    try {
        std::rethrow_exception(failure);
    } catch (const AppError& error) {
        return error.code();
    } catch (...) {
        return "OTHER";
    }
}

}  // namespace

int main(int argc, char* argv[]) {
    try {
        if (argc != 8) {
            throw std::runtime_error(
                "expected client cert/key/pin, server cert/key/pin, and schedule output directory");
        }
        const std::filesystem::path schedule_output(argv[7]);
        std::filesystem::create_directories(schedule_output);
        Probe probe;
        const auto client_identity = identity(argv[1], argv[2], argv[3]);
        const auto server_identity = identity(argv[4], argv[5], argv[6]);

        probe.run_case("canonical schedule vector and malformed rejection", [&] {
            const auto schedule = canonical_vector_schedule();
            probe.record_schedule(schedule_output, "canonical-vector", schedule);
            const auto encoded = natrav_overlay::encode_virtual_carrier_schedule(schedule);
            constexpr std::string_view expected =
                "4e56435330303031000100070102030405060708"
                "00000040000000070000000b0000000d00000002"
                "010205000000000100000002000000070000000100000000"
                "020101000000000200000003000000050000000000000000";
            probe.check(datacube::hex_lower(encoded) == expected,
                "canonical binary vector is exact");
            const auto decoded =
                natrav_overlay::decode_virtual_carrier_schedule(encoded);
            probe.check(
                natrav_overlay::encode_virtual_carrier_schedule(decoded) == encoded,
                "canonical schedule round-trips byte for byte");
            probe.check(decoded.events.front().endpoint == VirtualEndpoint::first &&
                        decoded.events.back().endpoint == VirtualEndpoint::second,
                "encoder sorts events by endpoint, operation, and index");
            probe.check(
                natrav_overlay::virtual_carrier_schedule_digest(decoded) ==
                    datacube::sha256(encoded),
                "schedule digest binds canonical bytes");

            auto malformed = encoded;
            malformed[0U] ^= 1U;
            probe.expect_app_error([&] {
                static_cast<void>(
                    natrav_overlay::decode_virtual_carrier_schedule(malformed));
            }, "invalid magic is rejected");
            malformed = encoded;
            malformed[10U] = 0x80U;
            probe.expect_app_error([&] {
                static_cast<void>(
                    natrav_overlay::decode_virtual_carrier_schedule(malformed));
            }, "unknown schedule flags are rejected");
            malformed = encoded;
            malformed.push_back(0U);
            probe.expect_app_error([&] {
                static_cast<void>(
                    natrav_overlay::decode_virtual_carrier_schedule(malformed));
            }, "trailing bytes are rejected");
            malformed = encoded;
            std::swap_ranges(
                malformed.begin() + 40,
                malformed.begin() + 64,
                malformed.begin() + 64);
            probe.expect_app_error([&] {
                static_cast<void>(
                    natrav_overlay::decode_virtual_carrier_schedule(malformed));
            }, "noncanonical event order is rejected");
            malformed = encoded;
            malformed[43U] = 1U;
            probe.expect_app_error([&] {
                static_cast<void>(
                    natrav_overlay::decode_virtual_carrier_schedule(malformed));
            }, "nonzero reserved event byte is rejected");
            malformed = encoded;
            std::fill(malformed.begin() + 20, malformed.begin() + 24, 0U);
            probe.expect_app_error([&] {
                static_cast<void>(
                    natrav_overlay::decode_virtual_carrier_schedule(malformed));
            }, "zero queue capacity is rejected");
            auto duplicate = schedule;
            duplicate.events.push_back(duplicate.events.front());
            probe.expect_code([&] {
                static_cast<void>(
                    natrav_overlay::encode_virtual_carrier_schedule(duplicate));
            }, "VIRTUAL_SCHEDULE_INVALID", "duplicate event keys are rejected");
        });

        probe.run_case("bounded queues, half-close, and endpoint ownership", [&] {
            VirtualCarrierSchedule schedule{
                .seed = 0U,
                .queue_capacity = 4U,
                .default_read_chunk = 2U,
                .default_write_chunk = 4U,
                .mtu = 4U,
                .half_duplex = false,
                .initial_grant = std::nullopt,
                .events = {},
            };
            probe.record_schedule(schedule_output, "bounded-stream", schedule);
            auto link = natrav_overlay::make_virtual_link(schedule);
            probe.check(link.first->transport_kind() ==
                        natrav_overlay::TransportKind::virtual_link,
                "endpoint reports the private virtual transport kind");
            const std::array<std::uint8_t, 6U> input{1U, 2U, 3U, 4U, 5U, 6U};
            IoCounters first_counters;
            IoCounters second_counters;
            const auto written = link.first->write_some(
                input, test_deadline(), first_counters, "bounded write");
            probe.check(written == 4U, "write is shortened at queue capacity");
            probe.check(link.control->snapshot().first_to_second_queued == 4U,
                "queue never exceeds its declared four-byte capacity");
            std::array<std::uint8_t, 3U> read_one{};
            const auto first_read = link.second->read_some(
                read_one, test_deadline(), second_counters, "bounded read one");
            probe.check(first_read == 2U && read_one[0U] == 1U && read_one[1U] == 2U,
                "read chunk ceiling is exact");
            std::array<std::uint8_t, 3U> read_two{};
            const auto second_read = link.second->read_some(
                read_two, test_deadline(), second_counters, "bounded read two");
            probe.check(second_read == 2U && read_two[0U] == 3U && read_two[1U] == 4U,
                "queued bytes retain order");
            link.first->shutdown_write();
            std::array<std::uint8_t, 1U> eof{};
            probe.check(link.second->read_some(
                    eof, test_deadline(), second_counters, "half close read") == 0U,
                "write-half close becomes EOF after queued bytes drain");
            const std::array<std::uint8_t, 2U> reply{'o', 'k'};
            probe.check(link.second->write_some(
                    reply, test_deadline(), second_counters, "reverse write") == 2U,
                "opposite direction remains writable after half-close");
            std::array<std::uint8_t, 2U> reply_read{};
            probe.check(link.first->read_some(
                    reply_read, test_deadline(), first_counters, "reverse read") == 2U &&
                    reply_read == reply,
                "half-close preserves reverse-direction bytes");
            link.first.reset();
            probe.expect_code([&] {
                static_cast<void>(link.second->write_some(
                    reply, test_deadline(), second_counters,
                    "write after peer destruction"));
            }, "SOCKET_WRITE_CLOSED", "endpoint destruction closes peer writes");
            const auto snapshot = link.control->snapshot();
            probe.check(!snapshot.first_alive && snapshot.second_alive,
                "destruction changes only the owned endpoint lifetime");
        });

        probe.run_case("scheduled timeout, reset, and disconnect", [&] {
            VirtualCarrierSchedule timeout{
                .seed = 1U,
                .queue_capacity = 16U,
                .default_read_chunk = 8U,
                .default_write_chunk = 8U,
                .mtu = 8U,
                .half_duplex = false,
                .initial_grant = std::nullopt,
                .events = {VirtualScheduleEvent{
                    .endpoint = VirtualEndpoint::first,
                    .operation = VirtualOperation::read,
                    .fault = VirtualFault::timeout,
                    .operation_index = 1U,
                    .delay_steps = 3U,
                    .maximum_bytes = 0U,
                    .parameter = 0U,
                }},
            };
            probe.record_schedule(schedule_output, "explicit-timeout", timeout);
            auto timeout_link = natrav_overlay::make_virtual_link(timeout);
            IoCounters timeout_counters;
            std::array<std::uint8_t, 1U> byte{};
            probe.expect_code([&] {
                static_cast<void>(timeout_link.first->read_some(
                    byte, test_deadline(), timeout_counters, "scheduled timeout"));
            }, "IO_TIMEOUT", "explicit timeout preserves the IO boundary");
            probe.check(timeout_counters.poll_calls == 3U &&
                        timeout_counters.would_block == 3U,
                "virtual delay consumes deterministic counter steps without sleeping");

            VirtualCarrierSchedule reset = timeout;
            reset.seed = 2U;
            reset.events = {VirtualScheduleEvent{
                .endpoint = VirtualEndpoint::first,
                .operation = VirtualOperation::write,
                .fault = VirtualFault::reset,
                .operation_index = 1U,
                .delay_steps = 0U,
                .maximum_bytes = 0U,
                .parameter = 0U,
            }};
            probe.record_schedule(schedule_output, "explicit-reset", reset);
            auto reset_link = natrav_overlay::make_virtual_link(reset);
            IoCounters reset_counters;
            const std::array<std::uint8_t, 1U> one{1U};
            probe.expect_code([&] {
                static_cast<void>(reset_link.first->write_some(
                    one, test_deadline(), reset_counters, "scheduled reset"));
            }, "SOCKET_WRITE_CLOSED", "write-side reset fails closed");
            probe.expect_code([&] {
                static_cast<void>(reset_link.second->read_some(
                    byte, test_deadline(), reset_counters, "reset peer read"));
            }, "PEER_RESET", "peer observes the same reset state");
            probe.check(reset_link.control->snapshot().reset,
                "reset remains visible in bounded link evidence");

            VirtualCarrierSchedule disconnect = timeout;
            disconnect.seed = 3U;
            disconnect.events = {VirtualScheduleEvent{
                .endpoint = VirtualEndpoint::first,
                .operation = VirtualOperation::read,
                .fault = VirtualFault::disconnect,
                .operation_index = 1U,
                .delay_steps = 0U,
                .maximum_bytes = 0U,
                .parameter = 0U,
            }};
            probe.record_schedule(schedule_output, "explicit-disconnect", disconnect);
            auto disconnect_link = natrav_overlay::make_virtual_link(disconnect);
            IoCounters disconnect_counters;
            probe.check(disconnect_link.first->read_some(
                    byte, test_deadline(), disconnect_counters,
                    "scheduled disconnect") == 0U,
                "orderly disconnect produces EOF");
            probe.check(!disconnect_link.control->snapshot().second_alive,
                "disconnect event records the selected peer as absent");
        });

        probe.run_case("loss, duplication, corruption, and reordering controls", [&] {
            const std::array<std::uint8_t, 4U> payload{'a', 'b', 'c', 'd'};
            for (const auto fault : {
                    VirtualFault::drop,
                    VirtualFault::duplicate,
                    VirtualFault::corrupt,
                    VirtualFault::reorder}) {
                auto schedule = fault_schedule(fault);
                schedule.default_write_chunk = 4U;
                schedule.mtu = 4U;
                schedule.events.front().maximum_bytes = 2U;
                const auto name = std::string("direct-") +
                    std::string(natrav_overlay::virtual_fault_name(fault));
                probe.record_schedule(schedule_output, name, schedule);
                auto link = natrav_overlay::make_virtual_link(schedule);
                IoCounters counters;
                const auto first = link.first->write_some(
                    payload, test_deadline(), counters, "fault write one");
                probe.check(first == 2U, "fault event accepts its bounded segment");
                if (fault == VirtualFault::drop) {
                    link.first->shutdown_write();
                    std::array<std::uint8_t, 1U> output{};
                    probe.check(link.second->read_some(
                            output, test_deadline(), counters, "drop read") == 0U,
                        "loss control accepts bytes without delivering them");
                } else if (fault == VirtualFault::duplicate) {
                    std::array<std::uint8_t, 4U> output{};
                    probe.check(link.second->read_some(
                            output, test_deadline(), counters, "duplicate read") == 4U &&
                            output == std::array<std::uint8_t, 4U>{'a', 'b', 'a', 'b'},
                        "duplication control emits the configured extra copy");
                } else if (fault == VirtualFault::corrupt) {
                    std::array<std::uint8_t, 2U> output{};
                    probe.check(link.second->read_some(
                            output, test_deadline(), counters, "corrupt read") == 2U,
                        "corrupted segment remains bounded");
                    probe.check(output[0U] != 'a' && output[1U] == 'b',
                        "corruption flips the deterministic selected byte only");
                } else {
                    probe.check(link.control->snapshot().first_to_second_queued == 0U,
                        "reorder control holds the selected segment");
                    const auto second = link.first->write_some(
                        datacube::OctetView(payload.data() + 2U, 2U),
                        test_deadline(), counters, "fault write two");
                    probe.check(second == 2U, "reorder flush accepts a following segment");
                    std::array<std::uint8_t, 2U> current{};
                    std::array<std::uint8_t, 2U> held{};
                    const auto current_read = link.second->read_some(
                        current, test_deadline(), counters, "reorder current read");
                    const auto held_read = link.second->read_some(
                        held, test_deadline(), counters, "reorder held read");
                    probe.check(current_read == 2U && held_read == 2U &&
                            current == std::array<std::uint8_t, 2U>{'c', 'd'} &&
                            held == std::array<std::uint8_t, 2U>{'a', 'b'},
                        "reordering is exact and direction-local");
                }
                const auto snapshot = link.control->snapshot();
                probe.check(snapshot.first_to_second_queued <= schedule.queue_capacity,
                    "fault controls preserve the declared finite queue bound");
                probe.check(!snapshot.trace.empty() &&
                            snapshot.trace.front().event_index.has_value(),
                    "fault trace binds the canonical event index");
            }

            auto tight = fault_schedule(VirtualFault::reorder);
            tight.queue_capacity = 2U;
            tight.default_read_chunk = 2U;
            tight.default_write_chunk = 2U;
            tight.mtu = 2U;
            tight.events.front().maximum_bytes = 2U;
            probe.record_schedule(
                schedule_output, "reorder-capacity-boundary", tight);
            auto tight_link = natrav_overlay::make_virtual_link(tight);
            IoCounters tight_counters;
            const std::array<std::uint8_t, 2U> tight_payload{'a', 'b'};
            probe.check(tight_link.first->write_some(
                    tight_payload, test_deadline(), tight_counters,
                    "tight reorder hold") == 1U,
                "reorder reserves one queue byte for the following segment");
            probe.check(tight_link.first->write_some(
                    datacube::OctetView(tight_payload.data() + 1U, 1U),
                    test_deadline(), tight_counters,
                    "tight reorder following write") == 1U,
                "reserved queue capacity admits the following segment");
            std::array<std::uint8_t, 1U> tight_current{};
            std::array<std::uint8_t, 1U> tight_held{};
            probe.check(tight_link.second->read_some(
                    tight_current, test_deadline(), tight_counters,
                    "tight reorder current read") == 1U &&
                    tight_link.second->read_some(
                    tight_held, test_deadline(), tight_counters,
                    "tight reorder held read") == 1U &&
                    tight_current[0U] == 'b' && tight_held[0U] == 'a',
                "tight reorder remains lossless and exactly reversed");
            probe.check(tight_link.control->snapshot().first_to_second_queued == 0U,
                "tight reordered queue drains completely");

            auto flush_link = natrav_overlay::make_virtual_link(tight);
            IoCounters flush_counters;
            probe.check(flush_link.first->write_some(
                    tight_payload, test_deadline(), flush_counters,
                    "reorder before half-close") == 1U,
                "terminal reordered segment is held before close");
            flush_link.first->shutdown_write();
            std::array<std::uint8_t, 1U> flushed{};
            probe.check(flush_link.second->read_some(
                    flushed, test_deadline(), flush_counters,
                    "reordered shutdown flush") == 1U && flushed[0U] == 'a',
                "half-close flushes a terminal reordered segment instead of dropping it");
            probe.check(flush_link.second->read_some(
                    flushed, test_deadline(), flush_counters,
                    "reordered shutdown eof") == 0U,
                "flushed terminal reorder is followed by EOF");
        });

        probe.run_case("exact replay through real TLS, HELLO, NOS1, and receipts", [&] {
            const auto schedule = session_schedule();
            probe.record_schedule(schedule_output, "authenticated-session", schedule);
            const auto first = run_reusable_session(
                schedule, client_identity, server_identity);
            const auto second = run_reusable_session(
                schedule, client_identity, server_identity);
            probe.check(first.clean_close && second.clean_close,
                "both authenticated sessions close with NOS1 and TLS close-notify");
            probe.check(first.server_operations == 2U && second.server_operations == 2U,
                "each run carries two operations through one reusable session");
            probe.check(first.receipts == second.receipts,
                "application receipts are identical across replay");
            probe.check(first.receipts[0U].disposition == ReceiptDisposition::committed &&
                        first.receipts[1U].sequence == 2U,
                "real application responses preserve committed sequencing");
            {
                std::ofstream first_trace(
                    schedule_output / "replay-first.nvtr",
                    std::ios::binary | std::ios::trunc);
                first_trace.write(
                    reinterpret_cast<const char*>(first.trace.data()),
                    static_cast<std::streamsize>(first.trace.size()));
                std::ofstream second_trace(
                    schedule_output / "replay-second.nvtr",
                    std::ios::binary | std::ios::trunc);
                second_trace.write(
                    reinterpret_cast<const char*>(second.trace.data()),
                    static_cast<std::streamsize>(second.trace.size()));
            }
            probe.check(first.trace == second.trace,
                "canonical carrier operation trace replays byte for byte");
            const bool counters_match =
                counter_tuple(first.client_tls) == counter_tuple(second.client_tls) &&
                counter_tuple(first.client_handshake) == counter_tuple(second.client_handshake) &&
                counter_tuple(first.client_session) == counter_tuple(second.client_session) &&
                counter_tuple(first.client_application) == counter_tuple(second.client_application) &&
                counter_tuple(first.server_tls) == counter_tuple(second.server_tls) &&
                counter_tuple(first.server_io) == counter_tuple(second.server_io);
            if (!counters_match) {
                std::cerr << "counter mismatch client_tls "
                          << counter_text(first.client_tls) << " | "
                          << counter_text(second.client_tls) << '\n'
                          << "client_handshake "
                          << counter_text(first.client_handshake) << " | "
                          << counter_text(second.client_handshake) << '\n'
                          << "client_session "
                          << counter_text(first.client_session) << " | "
                          << counter_text(second.client_session) << '\n'
                          << "client_application "
                          << counter_text(first.client_application) << " | "
                          << counter_text(second.client_application) << '\n'
                          << "server_tls "
                          << counter_text(first.server_tls) << " | "
                          << counter_text(second.server_tls) << '\n'
                          << "server_io "
                          << counter_text(first.server_io) << " | "
                          << counter_text(second.server_io) << '\n';
            }
            probe.check(counters_match,
                "replay reproduces all exposed operation counters");
            probe.check(!first.trace.empty(),
                "replay evidence contains finite carrier operations");
        });

        probe.run_case("TLS faults fail before authenticated application state", [&] {
            for (const auto fault : {
                    VirtualFault::timeout,
                    VirtualFault::reset,
                    VirtualFault::drop,
                    VirtualFault::duplicate,
                    VirtualFault::corrupt,
                    VirtualFault::reorder}) {
                const auto schedule = fault_schedule(fault);
                const auto name = std::string("tls-") +
                    std::string(natrav_overlay::virtual_fault_name(fault));
                probe.record_schedule(schedule_output, name, schedule);
                const auto result = run_tls_fault(
                    schedule, client_identity, server_identity);
                probe.check(result.client_failed || result.server_failed,
                    "faulted TLS run produces an explicit failure");
                probe.check(!result.server_authenticated,
                    "fault control cannot create an authenticated application session");
                probe.check(!result.trace.empty(),
                    "faulted TLS run retains replayable operation evidence");
            }
        });

        probe.run_case("TLS distinguishes clean close from truncated carrier EOF", [&] {
            VirtualCarrierSchedule schedule{
                .seed = std::numeric_limits<std::uint64_t>::max(),
                .queue_capacity = 65'536U,
                .default_read_chunk = 37U,
                .default_write_chunk = 41U,
                .mtu = 43U,
                .half_duplex = false,
                .initial_grant = std::nullopt,
                .events = {},
            };
            probe.record_schedule(schedule_output, "tls-truncated-eof", schedule);
            auto link = natrav_overlay::make_virtual_link(schedule);
            auto server_stream = std::move(link.second);
            TlsContext client_context(client_identity);
            TlsContext server_context(server_identity);
            const std::vector<TlsTrustedIdentity> trusted_client{{
                .node_id = "CLIENT",
                .generations = {TlsTrustedGeneration{
                    .generation = "client-g1",
                    .spki_sha256 = client_identity.expected_spki_sha256,
                    .state = KeyGenerationState::active,
                }},
            }};
            std::exception_ptr server_failure;
            std::string server_code;
            std::thread server([&] {
                try {
                    IoCounters counters;
                    auto channel = TlsChannel::accept(
                        server_context, *server_stream, trusted_client,
                        test_deadline(), counters);
                    std::array<std::uint8_t, 1U> value{};
                    static_cast<void>(channel.read_some(
                        value, test_deadline(), counters,
                        "truncated TLS application read"));
                } catch (...) {
                    server_failure = std::current_exception();
                    server_code = app_error_code(server_failure);
                }
            });
            IoCounters client_counters;
            auto client = TlsChannel::connect(
                client_context,
                *link.first,
                "SERVER",
                "server-g1",
                KeyGenerationState::active,
                server_identity.expected_spki_sha256,
                test_deadline(),
                client_counters);
            link.first->shutdown_write();
            server.join();
            probe.check(server_failure != nullptr,
                "raw carrier EOF without TLS shutdown is rejected");
            probe.check(server_code == "TLS_TRUNCATED_EOF",
                "truncated EOF retains its exact TLS classification");
            client.close_notify(test_deadline(), client_counters);
        });

        std::cout << "{\"format\":\"NATRAV_VIRTUAL_CARRIER_PROBE_V1\","
                  << "\"status\":\"PASS\",\"cases\":[";
        for (std::size_t index = 0U; index < probe.cases().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            const auto& item = probe.cases()[index];
            std::cout << "{\"name\":" << natrav_overlay::json_string(item.name)
                      << ",\"assertions\":" << item.assertions << '}';
        }
        std::cout << "],\"schedules\":[";
        for (std::size_t index = 0U; index < probe.schedules().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            const auto& item = probe.schedules()[index];
            std::cout << "{\"name\":" << natrav_overlay::json_string(item.name)
                      << ",\"seed\":" << item.seed
                      << ",\"sha256\":" << natrav_overlay::json_string(item.digest)
                      << ",\"bytes\":" << item.bytes << '}';
        }
        std::cout << "],\"assertions\":" << probe.assertions() << "}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
