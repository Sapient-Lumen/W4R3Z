#!/usr/bin/env python3
"""Exact native submission replies: bounded copies, actual races and durable replay.
Large retained history is independently encoded legacy test state, not fabricated
network admissions. Timing hooks only coordinate owned test processes.
"""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import time

from run_persistent import Harness, operation, raw_control, receive_exact
from run_delivery_selection import fixture, topology, frame
from run_integration import encode_record
from run_outbox_inspection import setup, query, wait_outcome
from run_conditional_outbox import selection, apply
from run_live_configuration import candidate, activate
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_state_authentication import new_key, migrate, start as start_keyed, inspect


def arguments(state: Path, label: str, *, peer='C', scope='test/three', text='tiny',
              payload: Path | None = None, op: str | None = None, parent: str | None = None):
    a=['revise' if parent else 'submit','--control',str(state/'control.sock'),
       '--node','A','--peer',peer,'--scope',scope,'--operation',op or operation(label),'--deadline-ms','5000']
    if parent:a+=['--corrects',parent]
    a+=['--payload-file',str(payload)] if payload is not None else ['--payload-text',text]
    return a


def check_reply(h: Harness, q: dict, op: str, peer: str, scope: str, n: int, *, new: bool):
    h.check(q['format']=='NATRAV_OVERLAY_CONTROL_SUBMIT_V1' and q['ok'], 'existing submission format')
    h.check(q['operation_id']==op and q['recipient']==peer and q['resource']==scope, 'exact operation and recipient/resource binding')
    h.check(q['operation_class']=='EVIDENCE', 'ordinary evidence class')
    h.check(q['status_basis']=='POST_ENQUEUE_OBSERVATION', 'enqueue fact is distinct from later observed outcome')
    w=q['work']
    h.check(w['scope']=='ENQUEUE_AND_REPLY_METADATA','counters have explicit call-site scope')
    h.check(w['snapshot_calls']==w['snapshot_evidence_payload_bytes']==w['snapshot_logical_bytes']==0,
            'no full-state snapshot, unrelated payload copy or logical hash in enqueue/reply scope')
    h.check(w['queue_metadata_records']==1 and w['observation_metadata_records']==1,
            'one narrow enqueue result and one exact metadata observation')
    h.check(w['digest_payload_bytes']==n,'only submitted payload enters the enqueue digest call')
    h.check(w['observation_text_bytes_copied']==len(peer)+len(scope),'reply copies only bounded identity/resource strings')
    h.check(w['encoded_application_bytes']>n if new else w['encoded_application_bytes']==0,
            'new evidence encoded for durable enqueue; duplicate does not encode another application record')
    h.check('payload' not in q and 'payload_hex' not in q and 'delivery' not in q, 'no payload, policy or history in submission response')
    h.check(len(json.dumps(q,separators=(',',':')).encode())<2048,'bounded complete annotated response')
    return q


def issue(h: Harness,label: str,state: Path,**kw):
    expected=kw.pop('expected',0)
    q=h.run(label,arguments(state,label,**kw),expected=expected)
    if expected==0:
        n=kw['payload'].stat().st_size if kw.get('payload') else len(kw.get('text','tiny').encode())
        check_reply(h,q,kw.get('op',operation(label)),kw.get('peer','C'),kw.get('scope','test/three'),n,
                    new=q['queue_disposition']=='QUEUED')
    return q


def all_cases(h: Harness, selected):
    def case(name,fn):
        if not selected or name in selected:h.case(name,fn)

    def large():
        a,_,_=fixture(h,'large-submission',unrelated=8192,settled=4096,ready_b=0)
        ac,bc,cc,ad,bd,cd,b,c=topology(h,'large-submission',a,online_b=True,large=True)
        # C unavailable, B actual mutually authenticated service. No hook in measurements.
        tiny=issue(h,'large-small',a,text='small response',peer='C')
        dup=issue(h,'large-small-duplicate',a,text='small response',peer='C',op=tiny['operation_id'])
        payload=h.work/'large-binary.bin';payload.write_bytes(bytes(range(256))*234+bytes(range(96)))
        h.check(payload.stat().st_size==60000,'maximum binary input fixture size')
        big=issue(h,'large-binary',a,payload=payload,peer='B')
        wait_outcome(h,'large-binary-receipt',a,big['operation_id'],'ACKED')
        ack=issue(h,'large-binary-repeat',a,payload=payload,peer='B',op=big['operation_id'])
        h.check(ack['queue_disposition']=='ALREADY_ACKED' and ack['status']=='ACKED','acknowledged duplicate uses bounded metadata')
        h.check(dup['work']['capacity_records_visited']==0,'existing duplicate avoids new-capacity scan')
        h.check(tiny['work']['capacity_records_visited']==0 and tiny['work']['capacity_aggregate_reads']==2,'admission reads exact global and target-peer totals without retained-history scan')
        row=query(h,'large-exact-binary',a,op=big['operation_id'])['records'][0]
        h.check(row['payload_bytes']==60000,'full original binary payload remains durable')
        (h.output/'LARGE-RESPONSES.json').write_text(json.dumps({'unrelated_inbound_records':8192,
            'unrelated_inbound_payload_bytes':8192*2048,'settled_outbound_records':4096,
            'fixture_origin':'Independently encoded retained legacy state; only current submissions use real peer delivery.',
            'small':tiny,'duplicate':dup,'binary':big,'acknowledged_duplicate':ack},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('small_and_maximum_binary_submissions_beside_16MiB_unrelated_history',large)

    def outcomes():
        a,b,ac,bc,ad,bd=setup(h,'response-outcomes',online=True)
        original=issue(h,'outcome-original',a,peer='B',text='original')
        wait_outcome(h,'outcome-original-ack',a,original['operation_id'],'ACKED')
        correction=issue(h,'outcome-correct',a,peer='B',parent=original['operation_id'],text='corrected')
        wait_outcome(h,'outcome-correct-ack',a,correction['operation_id'],'ACKED')
        repeated=issue(h,'outcome-repeat-correction',a,peer='B',parent=original['operation_id'],text='corrected',op=correction['operation_id'])
        h.check(repeated['queue_disposition']=='ALREADY_ACKED','correction duplicate retains receipt')
        conflict=issue(h,'outcome-conflict',a,peer='B',op=original['operation_id'],text='different',expected=3)
        h.check(conflict['code']=='OUTBOUND_OPERATION_CONFLICT','same ID cannot reinterpret immutable content')
        denied=issue(h,'outcome-denied',a,peer='B',scope='test/denied')
        wait_outcome(h,'outcome-rejected',a,denied['operation_id'],'REJECTED')
        again=issue(h,'outcome-denied-again',a,peer='B',scope='test/denied',op=denied['operation_id'])
        h.check(again['queue_disposition']=='ALREADY_REJECTED' and again['status']=='REJECTED','rejection duplicate is not reopened')
        cancelled=issue(h,'outcome-cancel',a)
        h.run('cancel-response-operation',['cancel','--control',str(a/'control.sock'),'--operation',cancelled['operation_id'],'--reason','explicit terminal'])
        err=issue(h,'outcome-cancel-again',a,op=cancelled['operation_id'],expected=3)
        h.check(err['code']=='OUTBOUND_CANCELLED','cancelled duplicate stays a typed failure')
        expired=issue(h,'outcome-expire',a,peer='D')
        wait_outcome(h,'outcome-expired',a,expired['operation_id'],'EXPIRED')
        err=issue(h,'outcome-expire-again',a,peer='D',op=expired['operation_id'],expected=3)
        h.check(err['code']=='OUTBOUND_EXPIRED','expired duplicate stays a typed failure')
        # Rebinding an existing pending operation must not be overwritten by duplicate's fresh policy.
        pending=issue(h,'binding-original',a)
        old=query(h,'binding-before',a,op=pending['operation_id'])['records'][0]['delivery']['policy']
        updated=candidate(h,ac,'binding-config','binding-config-g2',lambda s:s.replace('peer=C,50,100,100,600000','peer=C,75,150,90,500000'))
        activate(h,'binding-activate',a,updated)
        same=issue(h,'binding-duplicate',a,op=pending['operation_id'])
        now=query(h,'binding-after',a,op=pending['operation_id'])['records'][0]['delivery']['policy']
        h.check(old==now and same['queue_disposition']=='ALREADY_PENDING','new configured timestamps/settings do not overwrite original durable policy')
        # Native action uses ControlSubmit too, but with its own class/resource.
        action=h.run('action-response',['action-submit','--control',str(a/'control.sock'),'--node','A','--peer','B','--operation',operation('action-response'),'--amount','1','--defer-ms','0'])
        h.check(action['operation_class']=='ACTION' and action['resource']=='counter.add','action submission metadata classification retained')
        h.check(action['work']['snapshot_calls']==0,'action response shares narrow machinery')
        ad.shutdown();bd.shutdown()
    case('duplicate_terminal_correction_action_and_policy_semantics',outcomes)

    def races():
        a,b,ac,bc,ad,bd=setup(h,'response-races',online=True)
        ad.shutdown();ad=h.start('response-races-paused',ac,a,{'NATRAV_OVERLAY_TEST_SUBMIT_AFTER_QUEUE_PAUSE_MS':'1200'})
        observed=[]
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            f=pool.submit(issue,h,'race-receipt',a,peer='B',text='real delivered bytes')
            op=operation('race-receipt')
            h.wait('reply paused after enqueue',lambda:'SUBMISSION_QUEUED '+op in ad.stderr_path.read_text())
            wait_outcome(h,'receipt-before-reply',a,op,'ACKED')
            response=f.result(timeout=10)
            h.check(response['queue_disposition']=='QUEUED' and response['status']=='ACKED','enqueue QUEUED and later real receipt ACKED are separate accurate facts')
            observed.append(response)
            f=pool.submit(issue,h,'race-cancel',a,peer='C')
            op=operation('race-cancel');h.wait('cancel reply window',lambda:'SUBMISSION_QUEUED '+op in ad.stderr_path.read_text())
            row,cfg=selection(h,'cancel-window-selection',a,op);apply(h,'cancel-during-reply',a,'cancel',row,cfg)
            response=f.result(timeout=10)
            h.check(response['queue_disposition']=='QUEUED' and response['status']=='CANCELLED','later conditional cancellation observed, not cached enqueue outcome')
            observed.append(response)
            f=pool.submit(issue,h,'race-expiry',a,peer='D')
            response=f.result(timeout=10)
            h.check(response['queue_disposition']=='QUEUED' and response['status']=='EXPIRED','expiry may win before the coherent reply observation')
            observed.append(response)
        (h.output/'REPLY-RACES.json').write_text(json.dumps(observed,indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('real_receipt_conditional_cancellation_and_expiry_between_enqueue_and_reply',races)

    def concurrent_case():
        a,b,ac,bc,ad,bd=setup(h,'response-concurrent',online=True)
        payload=h.work/'concurrent-binary.bin';payload.write_bytes(bytes(range(256))*234+bytes(range(96)))
        op=operation('response-single-duplicate')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            replies=list(pool.map(lambda i:issue(h,'duplicate-concurrent-'+str(i),a,peer='C',payload=payload,op=op),range(16)))
        h.check(sum(q['queue_disposition']=='QUEUED' for q in replies)==1,'one atomic enqueue winner across sixteen duplicate clients')
        h.check(all(q['queue_disposition'] in ('QUEUED','ALREADY_PENDING') for q in replies),'remaining concurrent clients observe the same pending identity')
        h.check(query(h,'one-queued-duplicate',a,peer='C')['selected_total']==1,'no duplicate durable operation')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            rows=list(pool.map(lambda i:issue(h,'distinct-concurrent-'+str(i),a,peer='B' if i%2 else 'C',text=str(i)),range(24)))
        h.check(len({q['operation_id'] for q in rows})==24,'distinct concurrent operations keep exact response identities')
        h.wait('all actual B receipts',lambda:query(h,'concurrent-b-count',a,peer='B',outcome='ACKED',limit=1)['selected_total']==12)
        h.check(all(q['work']['digest_payload_bytes']==len(str(i)) for i,q in enumerate(rows)),'per-thread work is not another client or scheduler delta')
        (h.output/'CONCURRENT.json').write_text(json.dumps({'duplicate_clients':16,'committing_winners':1,'distinct_operations':24,'actual_peer_receipts':12},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('concurrent_duplicate_and_distinct_binary_submissions',concurrent_case)

    def quotas_auth():
        a,b,ac,bc,ad,bd=setup(h,'response-authority',delegates=True)
        first=issue(h,'quota-first',a,text='12345678')
        limited=candidate(h,ac,'quota-limit','quota-limit-g2',lambda s:s.replace('outbox_peer_max_records=1024','outbox_peer_max_records=1').replace('outbox_peer_max_payload_bytes=16777216','outbox_peer_max_payload_bytes=8'))
        activate(h,'quota-limit-activate',a,limited)
        issue(h,'quota-duplicate-still-valid',a,text='12345678',op=first['operation_id'])
        failed=issue(h,'quota-excess',a,expected=3)
        h.check(failed['code']=='OUTBOX_PEER_RECORD_LIMIT','prospective capacity refused before record admission')
        h.check(query(h,'quota-excess-absent',a,op=operation('quota-excess'))['records']==[],'quota refusal created no operation')
        expose_control_for_uid(a)
        args=arguments(a,'inspect-only-denied',peer='B')
        denied=run_as_uid(h,'inspect-cannot-submit',65534,65534,args,3)
        h.check(denied['code']=='LOCAL_CONTROL_CLASS_DENIED','INSPECT cannot submit')
        allowed=run_as_uid(h,'submit-only-valid',65533,65533,arguments(a,'delegated-success',peer='B'),0)
        h.check(allowed['ok'] and 'work' not in allowed, 'submit-only success exposes no node-wide work counters')
        # Kernel UID 65533 has SUBMIT. Request is held incomplete across revocation.
        import subprocess,sys
        packet=b'NOC1\x01'+encode_record(operation('slow-submit'),'A','B','test/three',b'x')
        script="""import socket,struct,sys,json,time
s=socket.socket(socket.AF_UNIX);s.settimeout(5);s.connect(sys.argv[1]);p=bytes.fromhex(sys.argv[2]);s.sendall(struct.pack('!I',len(p))+p[:5]);print('PARTIAL',flush=True);sys.stdin.readline();s.sendall(p[5:]);s.shutdown(socket.SHUT_WR)
def take(n):
 b=b''
 while len(b)<n:
  x=s.recv(n-len(b))
  if not x:raise RuntimeError('EOF')
  b+=x
 return b
n=struct.unpack('!I',take(4))[0];r=take(n);print(r[5:].decode(),flush=True)
"""
        proc=subprocess.Popen(['/usr/bin/setpriv','--reuid=65533','--regid=65533','--clear-groups',sys.executable,'-c',script,str(a/'control.sock'),packet.hex()],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            h.check(proc.stdout.readline().strip()=='PARTIAL','actual delegated UID connected before policy change')
            revoked=candidate(h,limited,'revoke-submit','revoke-submit-g3',lambda s:s.replace('local_control=65533,SUBMIT','local_control=65533,INSPECT'))
            activate(h,'revoke-connected-submission',a,revoked)
            out,err=proc.communicate('\n',timeout=10)
            response=json.loads(out.strip())
            (h.output/'SLOW-REQUEST.json').write_text(json.dumps(response,indent=2)+'\n')
            h.check(proc.returncode==0 and response.get('code')=='LOCAL_CONTROL_CLASS_DENIED','slow request uses current class authority')
            h.check(query(h,'revoked-submit-not-queued',a,op=operation('slow-submit'))['records']==[], 'denied slow request created no operation')
        finally:
            if proc.poll() is None:proc.kill();proc.wait()
        restore_owner_only_control(a)
        ad.shutdown()
    case('unchanged_capacity_and_live_kernel_principal_authorization',quotas_auth)

    def recovery():
        a,b,ac,bc,ad,bd=setup(h,'response-recovery')
        ad.shutdown();ad=h.start('response-kill-window',ac,a,{'NATRAV_OVERLAY_TEST_SUBMIT_AFTER_QUEUE_PAUSE_MS':'1200'})
        op=operation('response-lost-reply')
        # Raw client permits a lost reply without pretending it was a failed enqueue.
        sock=socket.socket(socket.AF_UNIX);sock.settimeout(5);sock.connect(str(a/'control.sock'))
        packet=b'NOC1\x01'+encode_record(op,'A','C','test/three',b'survives')
        sock.sendall(struct.pack('!I',len(packet))+packet);sock.shutdown(socket.SHUT_WR)
        h.wait('kill after durable enqueue',lambda:'SUBMISSION_QUEUED '+op in ad.stderr_path.read_text());ad.kill();sock.close()
        ad=h.start('response-after-kill',ac,a)
        recovered=issue(h,'lost-reply-repeat',a,op=op,text='survives')
        h.check(recovered['queue_disposition']=='ALREADY_PENDING','lost reply does not multiply synchronized evidence-plus-policy')
        before=query(h,'before-keying',a,op=op)['records'][0]
        ad.shutdown();key=new_key(h,h.work,'submission-state');migrate(h,'submission-migrate',a,key)
        ad=start_keyed(h,'submission-keyed',ac,a,key)
        h.run('submission-compact',['compact','--control',str(a/'control.sock')]);ad.shutdown()
        ident=h.identity('A');crypt=h.work/'submission-archive.key';archive=h.work/'submission.nob'
        h.run('submission-encryption-key',['backup-key-init','--output',str(crypt),'--generation','submission-archive'])
        plain=inspect(h,'submission-offline-before',a,key)
        h.run('submission-export',['backup-export','--state',str(a),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--output',str(archive),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'submission-restored'
        h.run('submission-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'submission-offline-restored',restored,key)
        h.check(plain['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'reply metadata introduces no durable-format change')
        moved=candidate(h,ac,'submission-relocated','submission-relocated-g3',lambda s:s.replace('state='+str(a),'state='+str(restored)))
        h.run('submission-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','owned continuation','--state-auth-key',str(key)])
        ad=start_keyed(h,'submission-restored-owner',moved,restored,key)
        duplicate=issue(h,'restore-repeat',restored,op=op,text='survives')
        stored=query(h,'restored-exact-policy',restored,op=op)['records'][0]
        h.check(stored['delivery']['policy']==before['delivery']['policy'],'duplicate after relocation preserves exact original policy')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'reply':duplicate,'logical_digest':after['storage']['logical_state_digest'],'policy':stored['delivery']['policy']},indent=2)+'\n')
        ad.shutdown()
    case('lost_reply_keyed_compaction_encrypted_restore_and_relocation',recovery)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    try:
        all_cases(h,set(a.case) if a.case else None)
        if not h.cases:raise ValueError('no matching cases')
        ok=True
    except BaseException as exc:
        (h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(f'FAIL: {type(exc).__name__}: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup()
        summary={'format':'NATRAV_OVERLAY_SUBMISSION_RESPONSE_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:
            (h.output/(name+'.json')).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
