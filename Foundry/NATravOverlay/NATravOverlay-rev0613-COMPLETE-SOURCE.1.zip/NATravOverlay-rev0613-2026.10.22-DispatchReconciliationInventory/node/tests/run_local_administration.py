#!/usr/bin/env python3
"""Kernel-authenticated local administration and lifecycle integration tests."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import pwd
import shutil
import signal
import socket
import stat
import subprocess
import time
from typing import Any

from run_persistent import Harness, Daemon, free_port, operation, raw_control


def v8_config(
    h: Harness,
    name: str,
    node: str,
    state: Path,
    port: int,
    runtime_generation: str,
    grants: list[tuple[int, list[str]]],
    peers: list[tuple[str, int]] | None = None,
    inbound: list[str] | None = None,
    identity_label: str | None = None,
    identity_directory: Path | None = None,
    deadline_ms: int = 300,
) -> Path:
    path = h.work / f"{name}.conf"
    identity = h.identity(identity_label or node)
    certificate = identity.certificate
    private_key = identity.private_key
    if identity_directory is not None:
        certificate = identity_directory / "cert.pem"
        private_key = identity_directory / "key.pem"
    lines = [
        "NATRAV_OVERLAY_CONFIG_V8",
        f"runtime_generation={runtime_generation}",
        f"node={node}",
        f"state={state}",
        f"listen=127.0.0.1:{port}",
        "control=control.sock",
        f"identity_cert={certificate}",
        f"identity_key={private_key}",
        f"identity_pin={identity.spki_sha256}",
        f"identity_generation={node.lower()}-g1",
        f"deadline_ms={deadline_ms}",
        "peer_workers=4",
        "peer_queue_capacity=64",
        "control_workers=4",
        "control_queue_capacity=64",
    ]
    for uid, classes in grants:
        lines.append(f"local_control={uid},{','.join(classes)}")
    configured: set[str] = set()
    for peer, peer_port in peers or []:
        peer_identity = h.identity(peer)
        lines.extend([
            f"peer={peer},127.0.0.1:{peer_port},75,150,100,60000",
            f"peer_key={peer},{peer.lower()}-g1,ACTIVE,{peer_identity.spki_sha256}",
        ])
        configured.add(peer)
    for peer in inbound or []:
        if peer in configured:
            continue
        peer_identity = h.identity(peer)
        lines.append(
            f"peer_key={peer},{peer.lower()}-g1,ACTIVE,{peer_identity.spki_sha256}"
        )
        configured.add(peer)
    for peer in sorted(configured):
        lines.append(f"authorize={peer},*,EVIDENCE,admin/test")
    path.write_text("\n".join(lines) + "\n")
    path.chmod(0o644)
    return path


def inspect(h: Harness, label: str, state: Path, node: str) -> dict[str, Any]:
    value = h.run(label, ["inspect", "--state", str(state), "--node", node])
    assert value is not None
    return value


def run_as_uid(
    h: Harness,
    label: str,
    uid: int,
    gid: int,
    args: list[str],
    expected: int,
    timeout: float = 10.0,
) -> dict[str, Any] | None:
    started = time.time()
    command = [
        "/usr/bin/setpriv",
        f"--reuid={uid}",
        f"--regid={gid}",
        "--clear-groups",
        str(h.binary),
        *args,
    ]
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        timeout=timeout,
        env=os.environ.copy(),
    )
    record = {
        "label": label,
        "args": command[1:],
        "returncode": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
        "elapsed_seconds": time.time() - started,
    }
    h.commands.append(record)
    (h.logs / f"{len(h.commands):03d}-{label}.stdout.txt").write_text(completed.stdout)
    (h.logs / f"{len(h.commands):03d}-{label}.stderr.txt").write_text(completed.stderr)
    h.check(
        completed.returncode == expected,
        f"{label}: return {completed.returncode}, expected {expected}; "
        f"stdout={completed.stdout!r} stderr={completed.stderr!r}",
    )
    lines = [line for line in completed.stdout.splitlines() if line.strip()]
    if not lines:
        return None
    return json.loads(lines[-1])


def expose_control_for_uid(state: Path) -> None:
    state.chmod(0o711)
    (state / "control.sock").chmod(0o666)


def restore_owner_only_control(state: Path) -> None:
    if (state / "control.sock").exists():
        (state / "control.sock").chmod(0o600)
    state.chmod(0o700)


def wait_process_exit(h: Harness, daemon: Daemon, label: str) -> None:
    assert daemon.process is not None
    daemon.process.wait(timeout=8)
    h.check(daemon.process.returncode == 0, f"{label} exits cleanly")
    daemon._close_files()
    h.check(not daemon.control.exists(), f"{label} removes control socket")


def run_suite(h: Harness) -> None:
    owner_uid = os.geteuid()
    nobody = pwd.getpwnam("nobody")
    nobody_uid = nobody.pw_uid
    nobody_gid = nobody.pw_gid
    unknown_uid = 65533 if nobody_uid != 65533 else 65532

    def strict_policy_and_credentials() -> None:
        root = h.runtime / "credentials"
        root.mkdir()
        state = root / "state"
        port = free_port()
        config = v8_config(
            h, "credentials", "A", state, port, "a-admin-1",
            [(nobody_uid, ["INSPECT"]), (owner_uid, ["ALL"])],
        )
        checked = h.run("credentials-config", ["config-check", "--config", str(config)])
        assert checked is not None
        h.check(checked["format"] == "NATRAV_OVERLAY_CONFIG_V8", "V8 accepted")
        h.check(checked["local_control"]["legacy_owner_default"] is False, "V8 policy explicit")
        h.check([g["uid"] for g in checked["local_control"]["grants"]] == sorted([owner_uid, nobody_uid]), "grants canonicalized by UID")

        reversed_config = v8_config(
            h, "credentials-reversed", "A", root / "unused", free_port(), "a-admin-1",
            [(owner_uid, ["ALL"]), (nobody_uid, ["INSPECT"])],
        )
        reversed_checked = h.run(
            "credentials-config-reversed", ["config-check", "--config", str(reversed_config)])
        assert reversed_checked is not None
        h.check(
            checked["local_control"]["digest"] == reversed_checked["local_control"]["digest"],
            "policy digest independent of grant order",
        )

        missing = config.with_name("missing-policy.conf")
        missing.write_text(config.read_text().replace(f"local_control={nobody_uid},INSPECT\n", "").replace(f"local_control={owner_uid},ALL\n", ""))
        denied = h.run("credentials-missing-policy", ["config-check", "--config", str(missing)], expected=3)
        h.check(denied is not None and denied["code"] == "CONFIG_MISSING_FIELD", "V8 policy required")

        duplicate = config.with_name("duplicate-policy.conf")
        duplicate.write_text(config.read_text() + f"local_control={owner_uid},INSPECT\n")
        denied = h.run("credentials-duplicate-uid", ["config-check", "--config", str(duplicate)], expected=3)
        h.check(denied is not None and denied["code"] == "CONFIG_LOCAL_CONTROL_DUPLICATE_UID", "duplicate UID rejected")

        unknown = config.with_name("unknown-class.conf")
        unknown.write_text(config.read_text().replace(f"local_control={nobody_uid},INSPECT", f"local_control={nobody_uid},EXECUTE"))
        denied = h.run("credentials-unknown-class", ["config-check", "--config", str(unknown)], expected=3)
        h.check(denied is not None and denied["code"] == "CONFIG_LOCAL_CONTROL_CLASS_INVALID", "unknown class rejected")

        daemon = h.start("credentials", config, state)
        root_status = h.status("credentials-root-status", state)
        h.check(root_status["principal_uid"] == owner_uid, "owner SO_PEERCRED visible")
        h.check(root_status["lifecycle"]["state_owned"] is True, "state ownership health visible")
        h.check(root_status["lifecycle"]["local_mutations_accepted"] is True, "mutation readiness visible")
        h.check(stat.S_IMODE(daemon.control.stat().st_mode) == 0o600, "owner-only filesystem default retained")

        expose_control_for_uid(state)
        delegated = run_as_uid(
            h, "credentials-nobody-status", nobody_uid, nobody_gid,
            ["status", "--control", str(daemon.control), "--deadline-ms", "2000"], 0)
        assert delegated is not None
        h.check(delegated["principal_uid"] == nobody_uid, "kernel reports delegated UID")
        h.check(delegated["command_class"] == "INSPECT", "delegated read mapped to INSPECT")

        denied = run_as_uid(
            h, "credentials-nobody-compact", nobody_uid, nobody_gid,
            ["compact", "--control", str(daemon.control), "--deadline-ms", "2000"], 3)
        h.check(denied is not None and denied["code"] == "LOCAL_CONTROL_CLASS_DENIED", "delegated mutation denied")

        denied = run_as_uid(
            h, "credentials-unknown-status", unknown_uid, unknown_uid,
            ["status", "--control", str(daemon.control), "--deadline-ms", "2000"], 3)
        h.check(denied is not None and denied["code"] == "LOCAL_CONTROL_UID_DENIED", "unlisted UID rejected before dispatch")

        # Force a long fragmented client write while the server denies this UID
        # before reading it. The queued typed denial must survive early close;
        # the client must never retry or report a partial mutation as successful.
        denied = run_as_uid(
            h, "credentials-unknown-large-submit", unknown_uid, unknown_uid,
            ["submit", "--control", str(daemon.control), "--node", "A", "--peer", "B",
             "--scope", "admin/test", "--operation", operation("early-uid-denial"),
             "--payload-text", "x" * 60000, "--write-quantum", "1", "--deadline-ms", "2000"], 3)
        h.check(denied is not None and denied["code"] == "LOCAL_CONTROL_UID_DENIED", "early-close denial preserved during partial request write")

        ok, malformed = raw_control(daemon.control, b"BAD!\x02")
        h.check(not ok and malformed.get("code") == "CONTROL_PROTOCOL_REJECTED", "malformed owner frame rejected")
        restore_owner_only_control(state)
        daemon.shutdown()

        offline = inspect(h, "credentials-inspect", state, "A")
        events = offline["local_control"]["entries"]
        h.check(any(e["uid"] == nobody_uid and e["error_code"] == "LOCAL_CONTROL_CLASS_DENIED" for e in events), "class denial durable")
        h.check(any(e["uid"] == unknown_uid and e["error_code"] == "LOCAL_CONTROL_UID_DENIED" for e in events), "UID denial durable")
        h.check(any(e["command"] == "MALFORMED" and e["decision"] == "DENIED" for e in events), "protocol denial durable without payload")
        h.check(all("payload" not in e for e in events), "denial accounts retain no secret request payload")

    h.case("strict_v8_policy_and_kernel_credentials", strict_policy_and_credentials)

    def quiesce_resume_and_peer_progress() -> None:
        root = h.runtime / "quiesce"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        grants = [(owner_uid, ["ALL"])]
        a_config = v8_config(
            h, "quiesce-a", "A", a_state, a_port, "a-admin-1", grants,
            peers=[("B", b_port)], deadline_ms=250)
        b_config = v8_config(
            h, "quiesce-b", "B", b_state, b_port, "b-admin-1", grants,
            inbound=["A"], deadline_ms=250)
        a = h.start("quiesce-a-1", a_config, a_state)
        first = operation("quiesce-first")
        h.run("quiesce-submit-first", [
            "submit", "--control", str(a.control), "--node", "A", "--peer", "B",
            "--scope", "admin/test", "--operation", first,
            "--payload-text", "queued before quiesce",
        ])
        q = h.run("quiesce-enter", [
            "quiesce", "--control", str(a.control), "--reason", "maintenance window",
            "--deadline-ms", "2000",
        ])
        h.check(q is not None and q["service_mode"] == "QUIESCED", "quiesce accepted")
        status = h.status("quiesce-status", a_state)
        h.check(status["lifecycle"]["local_mutations_accepted"] is False, "quiesce closes local mutation admission")
        h.check(status["lifecycle"]["peer_admissions_accepted"] is True, "quiesce preserves peer service")

        blocked = h.run("quiesce-submit-blocked", [
            "submit", "--control", str(a.control), "--node", "A", "--peer", "B",
            "--scope", "admin/test", "--operation", operation("quiesce-blocked"),
            "--payload-text", "must not be admitted",
        ], expected=3)
        h.check(blocked is not None and blocked["code"] == "SERVICE_QUIESCED", "new submission blocked")
        blocked = h.run("quiesce-compact-blocked", [
            "compact", "--control", str(a.control), "--deadline-ms", "2000",
        ], expected=3)
        h.check(blocked is not None and blocked["code"] == "SERVICE_QUIESCED", "maintenance mutation blocked")

        b = h.start("quiesce-b", b_config, b_state)
        h.wait(
            "durable obligation progresses while local mutations are quiesced",
            lambda: h.status("quiesce-wait-ack", a_state)["outbox"]["acked"] == 1,
            10.0,
        )
        h.check(h.status("quiesce-b-admission", b_state)["inbound_records"] == 1, "recipient admits once")

        a.shutdown()
        a2 = h.start("quiesce-a-2", a_config, a_state)
        restored = h.status("quiesce-restored", a_state)
        h.check(restored["lifecycle"]["mode"] == "QUIESCED", "ordinary shutdown does not erase quiescence")
        h.check(restored["lifecycle"]["local_mutations_accepted"] is False, "restart remains read-only locally")
        resumed = h.run("quiesce-resume", [
            "resume", "--control", str(a2.control), "--reason", "maintenance complete",
            "--deadline-ms", "2000",
        ])
        h.check(resumed is not None and resumed["service_mode"] == "RUNNING", "resume accepted")
        second = operation("quiesce-second")
        h.run("quiesce-submit-second", [
            "submit", "--control", str(a2.control), "--node", "A", "--peer", "B",
            "--scope", "admin/test", "--operation", second,
            "--payload-text", "admitted after resume",
        ])
        h.wait(
            "post-resume operation delivered",
            lambda: h.status("quiesce-wait-second", a_state)["outbox"]["acked"] == 2,
            8.0,
        )
        a2.shutdown(); b.shutdown()
        offline = inspect(h, "quiesce-inspect", a_state, "A")
        kinds = [e["kind"] for e in offline["lifecycle"]["events"]]
        h.check("QUIESCED" in kinds and "RESUMED" in kinds, "lifecycle transitions reconstruct")

    h.case("quiesce_resume_restart_and_peer_progress", quiesce_resume_and_peer_progress)

    def bounded_drain_and_interrupted_recovery() -> None:
        root = h.runtime / "drain"
        root.mkdir()
        grants = [(owner_uid, ["ALL"])]

        empty_state = root / "empty"
        empty_config = v8_config(h, "drain-empty", "E", empty_state, free_port(), "e-admin-1", grants)
        empty = h.start("drain-empty", empty_config, empty_state)
        result = h.run("drain-empty-command", [
            "drain-shutdown", "--control", str(empty.control), "--reason", "clean maintenance stop",
            "--drain-deadline-ms", "1000", "--deadline-ms", "3000",
        ])
        h.check(result is not None and result["completed"] is True, "empty drain completes")
        wait_process_exit(h, empty, "empty drain")

        pending_state = root / "pending"
        absent_port = free_port()
        pending_config = v8_config(
            h, "drain-pending", "P", pending_state, free_port(), "p-admin-1", grants,
            peers=[("Z", absent_port)], deadline_ms=100)
        pending = h.start("drain-pending-1", pending_config, pending_state)
        pending_op = operation("drain-pending")
        h.run("drain-pending-submit", [
            "submit", "--control", str(pending.control), "--node", "P", "--peer", "Z",
            "--scope", "admin/test", "--operation", pending_op,
            "--payload-text", "remains durable past drain deadline",
        ])
        result = h.run("drain-pending-command", [
            "drain-shutdown", "--control", str(pending.control), "--reason", "bounded unavailable-peer stop",
            "--drain-deadline-ms", "150", "--deadline-ms", "3000",
        ])
        h.check(result is not None and result["deadline_reached"] is True, "drain deadline is explicit")
        h.check(result["pending_outbound"] == 1, "deadline reports durable remainder")
        wait_process_exit(h, pending, "deadline drain")
        pending2 = h.start("drain-pending-2", pending_config, pending_state)
        status = h.status("drain-pending-restored", pending_state)
        h.check(status["lifecycle"]["mode"] == "RUNNING", "completed deadline stop restarts running")
        h.check(status["outbox"]["pending"] == 1, "pending obligation survives drain")
        pending2.shutdown()

        killed_state = root / "killed"
        killed_config = v8_config(
            h, "drain-killed", "K", killed_state, free_port(), "k-admin-1", grants,
            peers=[("Y", free_port())], deadline_ms=100)
        killed = h.start(
            "drain-killed-1", killed_config, killed_state,
            {"NATRAV_OVERLAY_TEST_DRAIN_AFTER_START_MS": "5000"})
        h.run("drain-killed-submit", [
            "submit", "--control", str(killed.control), "--node", "K", "--peer", "Y",
            "--scope", "admin/test", "--operation", operation("drain-killed"),
            "--payload-text", "survives interrupted drain",
        ])
        client = subprocess.Popen(
            [str(h.binary), "drain-shutdown", "--control", str(killed.control),
             "--reason", "interrupted drain", "--drain-deadline-ms", "10000",
             "--deadline-ms", "12000"],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            env=os.environ.copy())
        h.wait(
            "drain enters durable DRAINING mode",
            lambda: h.status("drain-killed-status", killed_state)["lifecycle"]["mode"] == "DRAINING",
            5.0,
        )
        killed.kill()
        stdout, stderr = client.communicate(timeout=8)
        h.commands.append({
            "label": "drain-killed-client", "args": ["drain-shutdown"],
            "returncode": client.returncode, "stdout": stdout, "stderr": stderr,
            "elapsed_seconds": 0.0,
        })
        h.check(client.returncode != 0, "drain client does not report success after daemon kill")
        recovered = h.start("drain-killed-2", killed_config, killed_state)
        status = h.status("drain-killed-restored", killed_state)
        h.check(status["lifecycle"]["mode"] == "QUIESCED", "interrupted drain recovers quiesced")
        h.check(status["lifecycle"]["interrupted_drain"] is True, "interrupted drain visible")
        h.check(status["lifecycle"]["local_mutations_accepted"] is False, "interrupted drain does not silently reopen")
        h.run("drain-killed-resume", [
            "resume", "--control", str(recovered.control), "--reason", "operator reviewed interrupted drain",
            "--deadline-ms", "2000",
        ])
        recovered.shutdown()

    h.case("bounded_drain_deadline_and_hard_kill_recovery", bounded_drain_and_interrupted_recovery)

    def live_policy_compaction_backup_and_relocation() -> None:
        root = h.runtime / "preservation"
        root.mkdir()
        state = root / "state"
        port = free_port()
        initial_grants = [(owner_uid, ["ALL"]), (nobody_uid, ["INSPECT"])]
        expanded_grants = [(owner_uid, ["ALL"]), (nobody_uid, ["INSPECT", "MAINTENANCE"])]
        initial = v8_config(h, "preserve-initial", "R", state, port, "r-admin-1", initial_grants)
        candidate = v8_config(h, "preserve-candidate", "R", state, port, "r-admin-2", expanded_grants)
        daemon = h.start("preserve-1", initial, state)
        activated = h.run("preserve-activate", [
            "config-activate", "--control", str(daemon.control),
            "--candidate", str(candidate), "--reason", "delegate bounded maintenance",
            "--deadline-ms", "10000",
        ])
        assert activated is not None
        h.check(activated["generation"] == "r-admin-2", "new local policy generation activated")
        status = h.status("preserve-status-after-activate", state)
        active_digest = status["local_control"]["digest"]

        expose_control_for_uid(state)
        compacted = run_as_uid(
            h, "preserve-delegated-compact", nobody_uid, nobody_gid,
            ["compact", "--control", str(daemon.control), "--deadline-ms", "10000"], 0,
            timeout=15.0)
        h.check(compacted is not None and compacted["generation"] == 1, "delegated maintenance executes after policy activation")
        restore_owner_only_control(state)
        h.run("preserve-quiesce", [
            "quiesce", "--control", str(daemon.control), "--reason", "record lifecycle after compaction",
            "--deadline-ms", "2000",
        ])
        h.run("preserve-resume", [
            "resume", "--control", str(daemon.control), "--reason", "resume before backup",
            "--deadline-ms", "2000",
        ])
        daemon.shutdown()

        identity = h.identity("R")
        backup = root / "r-signed.nob"
        exported = h.run("preserve-backup-export", [
            "backup-export", "--state", str(state), "--node", "R",
            "--generation", "r-g1", "--output", str(backup),
            "--sign-key", str(identity.private_key), "--sign-cert", str(identity.certificate),
        ])
        assert exported is not None
        verified = h.run("preserve-backup-verify", [
            "backup-verify", "--input", str(backup), "--node", "R",
            "--generation", "r-g1", "--trusted-cert", str(identity.certificate),
            "--require-signature", "yes",
        ])
        h.check(verified is not None and verified["logical_state_digest"] == exported["logical_state_digest"], "post-compaction lifecycle backup verifies")

        restored = root / "restored"
        h.run("preserve-backup-restore", [
            "backup-restore", "--input", str(backup), "--destination", str(restored),
            "--node", "R", "--generation", "r-g1",
            "--trusted-cert", str(identity.certificate), "--require-signature", "yes",
        ])
        restored_offline = inspect(h, "preserve-restored-inspect", restored, "R")
        h.check(restored_offline["local_control"]["count"] >= 5, "local-control provenance survives restore")
        h.check(restored_offline["lifecycle"]["count"] >= 3, "lifecycle provenance survives restore")

        relocated_identity = root / "relocated-identity"
        shutil.copytree(identity.certificate.parent, relocated_identity)
        (relocated_identity / "key.pem").chmod(0o600)
        relocated = v8_config(
            h, "preserve-relocated", "R", restored, port, "r-admin-3",
            expanded_grants, identity_directory=relocated_identity)
        relocation = h.run("preserve-relocate", [
            "state-relocate", "--state", str(restored), "--node", "R",
            "--candidate", str(relocated), "--reason", "promote verified administrative restore",
        ])
        assert relocation is not None
        h.check(relocation["to_generation"] == "r-admin-3", "relocation generation accepted")
        relocated_daemon = h.start("preserve-relocated", relocated, restored)
        relocated_status = h.status("preserve-relocated-status", restored)
        h.check(relocated_status["local_control"]["digest"] == active_digest, "relocation preserves exact local policy")
        h.check(relocated_status["lifecycle"]["mode"] == "RUNNING", "relocated lifecycle reconstructs")
        relocated_daemon.shutdown()

    h.case("live_policy_compaction_backup_restore_and_relocation", live_policy_compaction_backup_and_relocation)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, default=Path("node/bin/natrav-overlay"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output directory must not exist")
    harness = Harness(args.binary, args.output)
    started = time.time()
    status = "FAIL"
    return_code = 1
    try:
        run_suite(harness)
        status = "PASS"
        return_code = 0
    except BaseException as exc:
        (harness.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_LOCAL_ADMINISTRATION_TESTS_V1",
            "status": status,
            "binary": str(harness.binary),
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "started_unix": started,
            "elapsed_seconds": time.time() - started,
        }
        (harness.output / "SUMMARY.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
        (harness.output / "CASES.json").write_text(json.dumps(harness.cases, indent=2, sort_keys=True) + "\n")
        (harness.output / "COMMANDS.json").write_text(json.dumps(harness.commands, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary, sort_keys=True))
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
