#!/usr/bin/env python3
"""Bounded sequential validation; each test suite runs in its own process group."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

SUITES = ("custody_envelope", "custody_authority", "native_durable_custody_session", "passive_daemon_custody_receiver", "explicit_two_hop_custody", "owner_custody_dispatch", "handoff_key_policy", "handoff_capsule", "transport_extraction", "tls_byte_channel", "virtual_carrier", "serial_transport", "packet_port", "packet_link_transport", "udp_transport", "unix_datagram_transport", "external_packet_adapter", "udp_adversary", "integration", "persistent", "tls_security", "identity_generations",
          "authorization_actions", "maintenance", "delivery_governance", "peer_sessions",
          "live_configuration", "runtime_adapter_configuration", "configured_adapter_transport", "configured_adapter_adversary", "serial_packet_adapter", "removable_media_packet_adapter", "peer_registry", "multi_route", "relocation", "local_administration",
          "encrypted_backups", "state_authentication", "authenticated_recovery", "state_expectations", "live_state_head", "terminal_state_head", "response_loss_stopping", "correlated_stopping", "correlated_terminal_state_head", "correlated_stop_audit", "backup_correlated_stop_audit", "state_head_custody", "custody_state_opening", "custody_promotion", "custody_promotion_audit", "custody_promotion_intent", "evidence_queries", "scoped_reads", "local_evidence", "indexed_pagination", "evidence_feed", "consumers", "projections", "numeric_projection", "automatic_projections", "consumer_retirement", "projection_publication", "publication_channels", "automatic_publication_channels", "publication_epochs", "source_subscriptions", "subscriber_requests", "automatic_source_delivery", "subscription_leases", "lease_succession", "terminal_reconciliation", "subscribed_source_views", "import_automation", "import_review", "view_retirement", "outbox_inspection", "conditional_outbox", "delivery_selection", "submission_responses", "control_authorization", "pending_capacity", "runtime_status", "runtime_inventory", "configuration_history", "control_history", "action_inspection", "action_selection", "conditional_action", "action_results", "reserved_action_results", "action_result_correlation", "result_discovery", "result_reviews", "result_review_history", "consumer_inventory", "publication_inventory", "subscription_inventory", "source_view_inventory", "view_bindings", "subscription_validation", "source_selectors", "source_outbound_admission")

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--native-profile", choices=("full", "focused"), default="focused")
    parser.add_argument("--suite", action="append", choices=SUITES)
    parser.add_argument("--timeout", type=int, default=180)
    args = parser.parse_args()
    if args.output.exists() or not 10 <= args.timeout <= 600:
        parser.error("output must not exist; per-suite timeout must be 10..600 seconds")
    binary = args.binary.resolve(strict=True)
    root = args.output.resolve()
    root.mkdir(parents=True)
    started = time.time()
    runs = []
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    for name in args.suite or SUITES:
        command = [sys.executable, str(Path(__file__).resolve().parent / f"run_{name}.py"),
                   "--binary", str(binary), "--output", str(root / name)]
        if name == "integration":
            command += ["--profile", args.native_profile]
        begin = time.time()
        # A daemon can briefly inherit a suite's descriptors. Capture directly
        # to bounded-suite evidence files instead of waiting for pipe EOF from
        # every descendant after the test process has already returned.
        with (root / f"{name}.stdout.txt").open("w") as stdout_file, (root / f"{name}.stderr.txt").open("w") as stderr_file:
            process = subprocess.Popen(command, stdout=stdout_file, stderr=stderr_file,
                                       text=True, env=environment, start_new_session=True)
            timed_out = False
            try:
                process.wait(timeout=args.timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=10)
        record = {"suite": name, "returncode": process.returncode, "timed_out": timed_out,
                  "elapsed_seconds": time.time()-begin, "summary": None}
        summary_path = root / name / "SUMMARY.json"
        if summary_path.exists():
            record["summary"] = json.loads(summary_path.read_text())
        runs.append(record)
        print(json.dumps(record), flush=True)
        # Preserve evidence but never mistake an incomplete suite for a pass.
        if process.returncode != 0 or timed_out:
            break
    success = (len(runs) == len(args.suite or SUITES) and
               all(r["returncode"] == 0 and r["summary"] and r["summary"]["status"] == "PASS" for r in runs))
    result = {"format": "NATRAV_OVERLAY_VALIDATION_MATRIX_V1", "status": "PASS" if success else "FAIL",
              "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
              "native_profile": args.native_profile, "elapsed_seconds": time.time()-started,
              "suites": runs}
    for field in ("cases_passed", "cases_total", "assertions", "commands"):
        result[field] = sum(r["summary"].get(field, 0) for r in runs if r["summary"])
    (root / "MATRIX.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k:v for k,v in result.items() if k != "suites"}), flush=True)
    return 0 if success else 1

if __name__ == "__main__":
    raise SystemExit(main())
