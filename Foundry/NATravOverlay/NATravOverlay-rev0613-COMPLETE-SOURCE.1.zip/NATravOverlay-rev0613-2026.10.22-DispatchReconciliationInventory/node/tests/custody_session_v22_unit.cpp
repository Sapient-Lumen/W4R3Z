#include "adapter_configuration.hpp"
#include "custody_session_policy.hpp"
#include "protocol.hpp"

#include <cstdint>
#include <exception>
#include <iostream>
#include <string>

namespace {

datacube::Digest32 digest(const std::uint8_t seed) {
    datacube::Digest32 value{};
    for (std::size_t index = 0U; index < value.octets.size(); ++index) {
        value.octets[index] = static_cast<std::uint8_t>(seed +
            static_cast<std::uint8_t>(index));
    }
    return value;
}

void require(const bool condition, const char* label) {
    if (!condition) {
        std::cerr << "FAIL " << label << '\n';
        std::exit(1);
    }
}

} // namespace

int main() {
    using namespace natrav_overlay;

    CustodySessionRule rule{
        .id = "native-custody-a",
        .generation = 1U,
        .predecessor = {},
        .state = CustodySessionRuleState::active,
        .grant = CustodyGrantReference{
            .id = "relay-grant-a",
            .generation = 1U,
            .commitment = digest(3U),
        },
        .custodian_certificate_sha256 = digest(41U),
        .next_hop_certificate_sha256 = digest(83U),
        .maximum_pending_cases = 8U,
        .maximum_bundle_bytes = 16'384U,
        .maximum_attempts = 4U,
        .maximum_transfer_window_ms = 60'000U,
        .authority_expires_unix_ms = 4'102'444'800'000U,
    };

    CustodySessionPolicy policy{rule};
    normalize_custody_session_policy(policy);
    const auto text = custody_session_rule_text(policy.front());
    const auto parsed = parse_custody_session_rule(
        adapter_configuration_record_hex(text));
    require(custody_session_rule_text(parsed) == text,
        "canonical V22 round trip");
    require(custody_session_rule_commitment(parsed) ==
            custody_session_rule_commitment(rule),
        "stable V22 commitment");

    auto retired = policy;
    retired.front().state = CustodySessionRuleState::retired;
    require_custody_session_history_preserved(policy, retired);

    bool rollback_rejected = false;
    try {
        require_custody_session_history_preserved(retired, policy);
    } catch (const std::exception&) {
        rollback_rejected = true;
    }
    require(rollback_rejected, "retirement rollback rejection");

    CustodyTransferOffer offer{
        .request_id = digest(121U),
        .signed_offer = datacube::Octets{1U, 2U, 3U, 4U},
    };
    const ApplicationMessage wire_offer = offer;
    const auto encoded_offer = encode_application_message(wire_offer);
    const auto decoded_offer = decode_application_message(encoded_offer);
    require(std::get<CustodyTransferOffer>(decoded_offer) == offer,
        "native NOS1 offer round trip");
    require(application_message_operation_id(decoded_offer) ==
            offer.request_id,
        "offer request id binding");

    CustodyTransferAcceptance acceptance{
        .request_id = offer.request_id,
        .signed_acceptance = datacube::Octets{9U, 8U, 7U},
    };
    const ApplicationMessage wire_acceptance = acceptance;
    const auto encoded_acceptance = encode_application_message(wire_acceptance);
    const auto decoded_acceptance = decode_application_message(
        encoded_acceptance);
    require(std::get<CustodyTransferAcceptance>(decoded_acceptance) ==
            acceptance,
        "native NOS1 acceptance round trip");

    bool oversized_rejected = false;
    try {
        CustodyTransferOffer oversized = offer;
        oversized.signed_offer.assign(
            kMaximumCustodySessionWireBytes + 1U, 0U);
        static_cast<void>(encode_application_message(
            ApplicationMessage{std::move(oversized)}));
    } catch (const std::exception&) {
        oversized_rejected = true;
    }
    require(oversized_rejected, "custody wire byte bound");

    std::cout << "PASS native custody V22 unit\n";
    return 0;
}
