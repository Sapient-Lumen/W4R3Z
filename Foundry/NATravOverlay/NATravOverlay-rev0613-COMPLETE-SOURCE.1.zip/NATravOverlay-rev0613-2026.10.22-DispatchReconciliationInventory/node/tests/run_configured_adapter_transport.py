#!/usr/bin/env python3
"""Configured V19 adapters: full nodes, exact policy, image drift and restart.
The independently compiled NAPA fixture forwards only bounded loopback datagrams.
It has no TLS keys, configuration authority, receipts or product routing logic.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
from urllib.parse import quote

from run_persistent import Harness, free_port, operation
from run_peer_sessions import submit, outbox_entry
from run_live_configuration import candidate, activate
from run_runtime_adapter_configuration import profile, endpoint, records, upgrade, write, digest
from run_udp_adversary import exact_outbox_record
from run_unix_datagram_transport import run_external


def ref(identifier, generation=1):
    return f'adapter-endpoint-v1|id={identifier}|generation={generation}'


def image_profile(identifier, executable, arguments, generation=1, previous='0'*64):
    original=profile(identifier,generation,previous,hashlib.sha256(executable.read_bytes()).hexdigest())
    lines=[]
    for line in original.splitlines():
        if line.startswith('executable='): lines.append('executable='+quote(str(executable),safe='-_.~'))
        elif line.startswith('argument-count='):
            lines.append('argument-count='+str(len(arguments)))
            lines += ['argument='+quote(str(arg),safe='-_.~') for arg in arguments]
        elif line.startswith('argument='): continue
        else: lines.append(line)
    return '\n'.join(lines)+'\n'


def peer(status, identifier):
    return next(p for p in status['peers'] if p['node']==identifier)


def reports(prefix):
    result=[]
    for p in prefix.parent.glob(prefix.name+'.*.txt'):
        values=dict(line.split('=',1) for line in p.read_text().splitlines() if '=' in line)
        result.append(values)
    return result


def live_pids(prefix):
    result=[]
    for v in reports(prefix):
        pid=int(v['pid'])
        try:
            target=os.readlink(f'/proc/{pid}/exe')
            if 'memfd:' in target: result.append(pid)
        except OSError: pass
    return result


def wait_entry(h,state,op,expected='ACKED',timeout=35):
    last={}
    def ready():
        last.clear();last.update(h.status('poll-'+op[:8],state,logical_digest=False))
        return outbox_entry(last,op)['status']==expected
    h.wait('configured adapter operation '+expected,ready,timeout)
    return last


def assert_receipt(h,state,op,recipient):
    entry=exact_outbox_record(h,'bound-receipt-'+op[:8],state,op)
    receipt=entry['receipt']
    h.check(entry['status']=='ACKED' and receipt is not None and
            receipt['operation_id']==op and receipt['recorder']==recipient and
            receipt['recipient']==recipient and receipt['disposition'] in ('COMMITTED','DUPLICATE'),
            'exact authenticated operation and recipient binding')


def suite(h,selected):
    root=Path(__file__).resolve().parents[2]
    fixture=h.work/'configured-adapter-fixture'
    def case(name,fn):
        if selected is None or selected==name:h.case(name,fn)
    def compile_fixture():
        flags=['-D_GNU_SOURCE','-std=c++20','-O1','-Wall','-Wextra','-Wpedantic',
               '-Wconversion','-Wsign-conversion','-Wshadow','-Wformat=2','-Werror']
        result=run_external(h,'compile-fixture',['/usr/bin/g++',*flags,
            str(root/'node/tests/configured_adapter_fixture.cpp'),'-o',str(fixture)],timeout=60)
        h.check(result.returncode==0,'independent fixture compiles under strict warnings: '+result.stderr)
        fixture.chmod(0o700)
    # Preparation is a recorded command even for a selected lifecycle case.
    compile_fixture()

    def boundary():
        version=h.run('version',['version'])
        h.check(version['version']=='0613' and version['configured_adapter_transport'] is True,'release capability is explicit')
        transport=(root/'node/src/transport.cpp').read_text()
        adapter=(root/'node/src/adapter_transport.cpp').read_text()
        daemon=(root/'node/src/daemon.cpp').read_text()
        h.check('ADAPTER_AUTHORIZED_CONTEXT_REQUIRED' in transport,'unprepared registry cannot spawn')
        h.check('external_packet_adapter_options_from_profile(binding_.profile)' in adapter,'accepted exact profile factory only')
        h.check('DurableAdapterProfileCatalog' not in adapter,'no independently mutable catalog authority')
        h.check('make_configured_adapter_connector(config, route.locator)' in daemon,'scheduler consumes leased active configuration')
        h.check('timerfd_create' in adapter and 'stream->ensure' not in adapter[adapter.index('accept_ready()'):],
                'main accept path has no hash/launch/handshake work')
        state=h.runtime/'parse';cfg=h.config('parse','A',state,free_port(),[('B',free_port(),100,200,20,60000)])
        base=upgrade(cfg.read_text(),'parse');p=profile();e=endpoint(p)
        route=next(l for l in base.splitlines() if l.startswith('peer_route='))
        valid=base.replace(route,'peer_route=B,default,0,ENABLED,'+ref('radio-out'))+records([p],[e])
        write(cfg,valid)
        before=list(h.work.glob('*.txt'))
        h.run('check-inert-missing-image',['config-check','--config',str(cfg)])
        h.check(before==list(h.work.glob('*.txt')),'config-check does not execute or prepare missing image')
        invalid=[
            ('missing',valid.replace(ref('radio-out'),ref('absent')),'CONFIG_ADAPTER_ENDPOINT_NOT_FOUND'),
            ('generation',valid.replace(ref('radio-out'),ref('radio-out',2)),'CONFIG_ADAPTER_ENDPOINT_NOT_FOUND'),
            ('leading-zero',valid.replace(ref('radio-out'),ref('radio-out').replace('generation=1','generation=01')),'ADAPTER_ENDPOINT_LOCATOR_INVALID'),
            ('uppercase-id',valid.replace(ref('radio-out'),ref('Radio-out')),'ADAPTER_ENDPOINT_LOCATOR_INVALID'),
            ('extra-field',valid.replace(ref('radio-out'),ref('radio-out')+'|exec=anything'),'ADAPTER_ENDPOINT_LOCATOR_INVALID'),
            ('role',valid.replace(e.encode().hex(),endpoint(p,role='listener').encode().hex()),'CONFIG_ADAPTER_ENDPOINT_ROLE'),
            ('duplicate',valid+'peer_route=B,second,1,ENABLED,'+ref('radio-out')+'\n','CONFIG_PEER_ROUTE_ENDPOINT_AMBIGUOUS'),
            ('old-version',valid.replace('CONFIG_V19','CONFIG_V18'),'CONFIG_VERSION_REJECTED'),
        ]
        for name,text,expected in invalid:
            bad=write(h.work/(name+'.conf'),text)
            reply=h.run('reject-'+name,['config-check','--config',str(bad)],expected=3)
            h.check(reply['code']==expected,f'{name}: {reply}')
    case('accepted_policy_and_side_effect_free_validation',boundary)

    def lifecycle():
        astate,bstate=h.runtime/'a',h.runtime/'b'
        ports=[free_port() for _ in range(4)]
        # A-in pairs with B-out; B-in pairs with A-out.
        prefixes={name:h.logs/name for name in ('a-in','a-out','b-in','b-out')}
        images={}
        ps={};es={}
        marker=h.work/'first-startup-fails'
        for name,local,remote in [('a-in',ports[0],ports[3]),('a-out',ports[1],ports[2]),
                                  ('b-in',ports[2],ports[1]),('b-out',ports[3],ports[0])]:
            exe=h.work/(name+'-image');shutil.copy2(fixture,exe);exe.chmod(0o700);images[name]=exe
            args=[local,remote,prefixes[name],marker if name=='a-out' else '-']
            ps[name]=image_profile(name,exe,args)
            es[name]=endpoint(ps[name],identifier=name,role='listener' if name.endswith('in') else 'route')
        ac=h.config('node-a','A',astate,free_port(),[('B',free_port(),150,400,100,120000)],deadline_ms=2500)
        bc=h.config('node-b','B',bstate,free_port(),[('A',free_port(),150,400,100,120000)],deadline_ms=2500)
        for node,cfg in [('a',ac),('b',bc)]:
            text=upgrade(cfg.read_text(),node+'-base');lines=[]
            for line in text.splitlines():
                if line.startswith('listen='):line='listen='+ref(node+'-in')
                if line.startswith('peer_route='):line=','.join(line.split(',')[:4])+','+ref(node+'-out')
                lines.append(line)
            text='\n'.join(lines)+'\n'+records([ps[node+'-in'],ps[node+'-out']],[es[node+'-in'],es[node+'-out']])
            text+='session_max_operations=32\nsession_idle_timeout_ms=1000\n'
            write(cfg,text);h.run('check-'+node,['config-check','--config',str(cfg)])
        b=h.start('b',bc,bstate);a=h.start('a',ac,astate)
        one,two=operation('adapter-first'),operation('adapter-reverse')
        submit(h,'first',a.control,'A','B','test/three',one,'real TLS over supervised adapter')
        first=wait_entry(h,astate,one);assert_receipt(h,astate,one,'B')
        h.check(marker.exists() and len(reports(prefixes['a-out']))>=2,'one failed startup then bounded retry observed')
        h.check(h.status('b-first',bstate)['inbound_records']==1,'one durable admission, not packet duplicates')
        opened=peer(first,'B')['session']['opened']
        h.check(opened>=1,'adapter route completed TLS/HELLO/NOS1')
        submit(h,'reverse',b.control,'B','A','test/three',two,'reverse authenticated path')
        wait_entry(h,bstate,two);assert_receipt(h,bstate,two,'A')

        # Kill a running, sealed adapter; this cannot revive its TLS session.
        h.wait('live route adapter',lambda:bool(live_pids(prefixes['a-out'])),5)
        dead=live_pids(prefixes['a-out'])[-1];os.kill(dead,signal.SIGKILL)
        three=operation('adapter-after-death')
        submit(h,'after-death',a.control,'A','B','test/three',three,'new carrier new handshake')
        after=wait_entry(h,astate,three);assert_receipt(h,astate,three,'B')
        h.check(peer(after,'B')['session']['opened']>opened,'fresh authenticated session after adapter death')
        h.check(any(int(v['pid'])!=dead and v.get('hello')=='1' for v in reports(prefixes['a-out'])),
                'different child negotiated the NAPA protocol')

        # Drift must be checked on the next carrier, not hidden by a cached image.
        original=images['a-out'].read_bytes()
        images['a-out'].write_bytes(original[:-1]+bytes([original[-1]^1]));images['a-out'].chmod(0o700)
        for pid in live_pids(prefixes['a-out']):os.kill(pid,signal.SIGKILL)
        # Wait for the old authenticated session to retire. A write attempted
        # on that already-open session would legitimately consume one durable
        # application attempt, even when its carrier had just died.
        h.wait('old session retired before fresh-image negative',lambda:
            peer(h.status('wait-old-retirement',astate,logical_digest=False),'B')['session']['state']=='DISCONNECTED',8)
        drift=operation('adapter-image-drift')
        submit(h,'image-drift',a.control,'A','B','test/three',drift,'pending until image is verified again')
        def drift_failed():
            s=h.status('drift-poll',astate,logical_digest=False)
            return 'ADAPTER_EXECUTABLE_DIGEST_MISMATCH' in json.dumps(s)
        h.wait('typed exact-image failure',drift_failed,15)
        entry=outbox_entry(h.status('drift-pending',astate),drift)
        h.check(entry['status']=='PENDING' and entry['attempts']==0,'pre-auth carrier failure does not consume application attempt')
        images['a-out'].write_bytes(original);images['a-out'].chmod(0o700)
        wait_entry(h,astate,drift);assert_receipt(h,astate,drift,'B')

        # Exact endpoint succession is explicit. Listener replacement is not hot.
        p2=image_profile('a-out',images['a-out'],[ports[1],ports[2],prefixes['a-out'],marker],2,digest(ps['a-out']))
        e2=endpoint(p2,identifier='a-out',generation=2,previous=digest(es['a-out']))
        nextconf=candidate(h,ac,'a-successor','a-successor',lambda text:
            text.replace(ref('a-out'),ref('a-out',2))+records([p2],[e2]))
        activated=activate(h,'authorize-successor',astate,nextconf)
        h.check(activated.get('ok') is True,'owner accepts exact route/profile succession')
        hot=candidate(h,nextconf,'hot-listener','hot-listener',lambda text:text.replace(ref('a-in'),ref('a-out',2)))
        rejected=h.run('deny-hot-listener',['config-activate','--control',str(a.control),'--candidate',str(hot),
            '--reason','must-not-change-listener','--deadline-ms','10000'],expected=3,timeout=15)
        h.check(rejected['code'] in ('CONFIG_ADAPTER_ENDPOINT_ROLE','CONFIG_OWNER_BOUNDARY_CHANGED'),
                'listener layout cannot be implicitly replaced')

        # Keep an obligation pending through an absent peer and two process restarts.
        b.shutdown()
        for pid in live_pids(prefixes['a-out']):os.kill(pid,signal.SIGKILL)
        pending=operation('adapter-pending-restart')
        submit(h,'pending',a.control,'A','B','test/three',pending,'durable across node restart')
        h.check(outbox_entry(h.status('pending-before-stop',astate),pending)['status']=='PENDING','work remains pending while peer is absent')
        a.shutdown()
        # Seed is deliberately stale: accepted successor comes from durable state.
        a=h.start('a-restarted',ac,astate);b=h.start('b-restarted',bc,bstate)
        recovered=wait_entry(h,astate,pending,timeout=40);assert_receipt(h,astate,pending,'B')
        h.check(recovered['runtime_configuration']['generation']=='a-successor','restart recovered accepted exact policy rather than stale seed')
        h.check(h.status('b-final',bstate)['inbound_records']==4,'exactly four distinct A-to-B obligations admitted')
        a.shutdown();b.shutdown()
        for name,prefix in prefixes.items():
            values=reports(prefix)
            h.check(bool(values) and all(v['no-new-privs']=='1' and v['extra-fd-count']=='0' for v in values),
                    name+': actual child privilege/descriptor boundary')
            h.check(not live_pids(prefix),name+': no orphaned owned adapter after shutdown')
    case('two_persistent_nodes_failure_succession_and_recovery',lifecycle)

    def slow_listener():
        state=h.runtime/'slow';cfg=h.config('slow','A',state,free_port(),[],deadline_ms=200,trusted=['B'])
        prefix=h.logs/'silent';p=image_profile('silent',fixture,[free_port(),free_port(),prefix,'-','silent'])
        e=endpoint(p,identifier='silent',role='listener')
        text=upgrade(cfg.read_text(),'silent')+records([p],[e])
        text='\n'.join('listen='+ref('silent') if line.startswith('listen=') else line for line in text.splitlines())+'\n'
        write(cfg,text);d=h.start('silent',cfg,state)
        h.wait('silent child launched',lambda:bool(reports(prefix)),3)
        start=time.monotonic();h.status('responsive-local-control',state);elapsed=time.monotonic()-start
        h.check(elapsed<1,'silent startup does not block main local-control admission')
        # Multiple retries must not each consume the profile's full two seconds.
        time.sleep(.8)
        h.check(len(reports(prefix))>=2,'short outer deadlines retire/reopen the silent endpoint')
        d.shutdown();h.check(not live_pids(prefix),'silent child reaped on shutdown')
    case('listener_deadlines_and_control_responsiveness',slow_listener)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--case');args=parser.parse_args()
    if args.output.exists():parser.error('output must not exist')
    h=Harness(args.binary,args.output);started=time.monotonic();code=1
    try:
        suite(h,args.case)
        if not h.cases:raise ValueError('unknown case')
        code=0
    except BaseException as error:
        (h.output/'FAILURE.txt').write_text(f'{type(error).__name__}: {error}\n')
        print(f'FAIL: {type(error).__name__}: {error}',file=sys.stderr)
    finally:
        h.cleanup()
        summary={'format':'NATRAV_CONFIGURED_ADAPTER_TRANSPORT_TESTS_V1','status':'PASS' if code==0 else 'FAIL',
            'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),
            'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.monotonic()-started}
        for name,obj in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:
            (h.output/(name+'.json')).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary))
    return code
if __name__=='__main__':raise SystemExit(main())
