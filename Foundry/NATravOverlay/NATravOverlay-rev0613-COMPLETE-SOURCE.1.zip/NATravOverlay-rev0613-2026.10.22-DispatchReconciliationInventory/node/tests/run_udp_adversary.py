#!/usr/bin/env python3
"""Deterministic UDP adversity across two complete persistent node processes."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import time
from typing import Any, Callable

from run_multi_route import peer_status, write_v13_config
from run_peer_sessions import outbox_entry, submit
from run_persistent import Harness, operation
from udp_datagram_adversary import (
    FEATURE,
    TRACE_FORMAT,
    AdversaryError,
    DatagramAdversary,
    FaultRule,
    FaultSchedule,
    RelayPath,
    fault_signature,
)


EXPECTED_REVISION = "0613"

_allocated_udp_ports: set[int] = set()


def free_udp_port() -> int:
    for _ in range(2_048):
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.bind(("127.0.0.1", 0))
            candidate = int(probe.getsockname()[1])
        if candidate not in _allocated_udp_ports:
            _allocated_udp_ports.add(candidate)
            return candidate
    raise RuntimeError("unable to allocate a distinct loopback UDP port")


def locator(local: int, remote: int, link: str, epoch: int) -> str:
    return (
        f"udp-v1|local=127.0.0.1:{local}|remote=127.0.0.1:{remote}|"
        f"mtu=512|link={link}|epoch={epoch}|profile=1"
    )


def canonical_json(value: Any) -> bytes:
    return (
        json.dumps(value, ensure_ascii=True, separators=(",", ":"), sort_keys=True)
        + "\n"
    ).encode("utf-8")


def wait_for(
    h: Harness,
    detail: str,
    predicate: Callable[[], bool],
    *,
    timeout: float = 20.0,
) -> None:
    h.wait(detail, predicate, timeout)


def exact_outbox_record(
    h: Harness, label: str, state: Path, operation_id: str
) -> dict[str, Any]:
    result = h.run(
        label,
        [
            "outbox-query", "--control", str(state / "control.sock"),
            "--operation", operation_id, "--limit", "1",
            "--max-bytes", "60000", "--history-limit", "4",
            "--deadline-ms", "5000",
        ],
    )
    h.check(result is not None and result.get("format") ==
            "NATRAV_OVERLAY_OUTBOX_QUERY_V1",
            f"{label}: exact outbox query format")
    assert result is not None
    records = result.get("records")
    h.check(isinstance(records, list) and len(records) == 1,
            f"{label}: exact outbox record exists")
    return records[0]


def schedule_vectors(output: Path) -> tuple[FaultSchedule, FaultSchedule, FaultSchedule]:
    rules = (
        FaultRule("ab", "A_TO_B", 1, "DROP"),
        FaultRule("ab", "A_TO_B", 2, "CORRUPT"),
        FaultRule("ab", "A_TO_B", 3, "REORDER", 35),
        FaultRule("ab", "B_TO_A", 1, "DUPLICATE", 3),
        FaultRule("ab", "B_TO_A", 2, "DELAY", 30),
        FaultRule("ba", "A_TO_B", 1, "DUPLICATE", 3),
        FaultRule("ba", "A_TO_B", 2, "DELAY", 30),
        FaultRule("ba", "B_TO_A", 1, "DROP"),
        FaultRule("ba", "B_TO_A", 2, "CORRUPT"),
        FaultRule("ba", "B_TO_A", 3, "REORDER", 35),
    )
    adversity = FaultSchedule(
        name="adversity",
        default_action="PASS",
        max_datagram_bytes=512,
        max_pending_events=128,
        max_trace_records=16_384,
        rules=rules,
    )
    outage = FaultSchedule(
        name="outage",
        default_action="DROP",
        max_datagram_bytes=512,
        max_pending_events=128,
        max_trace_records=16_384,
    )
    recovery = FaultSchedule(
        name="recovery",
        default_action="PASS",
        max_datagram_bytes=512,
        max_pending_events=128,
        max_trace_records=16_384,
    )
    for item in (adversity, outage, recovery):
        (output / f"{item.name}-schedule.json").write_bytes(item.encode())
    return adversity, outage, recovery


def run_suite(h: Harness) -> dict[str, Any]:
    source_root = Path(__file__).resolve().parents[2]
    evidence: dict[str, Any] = {}

    def revision_and_private_boundary() -> None:
        version = h.run("udp-adversary-version", ["version"])
        h.check(version is not None and version.get("version") == EXPECTED_REVISION,
                "revision marker is 0595")
        h.check(version is not None and version.get("udp_transport") ==
                "NUMERIC_POINT_TO_POINT_UDP_PACKET_CARRIER_V1",
                "configured UDP carrier marker is retained")
        h.check(version is not None and version.get("packet_link_core") ==
                "FINITE_PACKET_LINK_SERVICE_V1",
                "finite packet service marker is retained")
        h.check(version is not None and version.get("packet_link_stream") ==
                "PACKET_LINK_ORDERED_BYTE_STREAM_ADAPTER_V1",
                "packet ordered-stream marker is retained")
        h.check(version is not None and version.get("tls_byte_channel") ==
                "OPENSSL_BYTE_CHANNEL_BIO_V1",
                "TLS remains above ByteChannel")

        fixture = source_root / "node/tests/udp_datagram_adversary.py"
        runner = source_root / "node/tests/run_udp_adversary.py"
        matrix = (source_root / "node/tests/run_matrix.py").read_text()
        product_text = "\n".join(
            path.read_text(errors="strict")
            for path in sorted((source_root / "node/src").glob("*"))
            if path.suffix in {".cpp", ".hpp"}
        ) + (source_root / "node/build.sh").read_text()
        h.check(fixture.is_file() and runner.is_file(),
                "adversary implementation and persistent exercise are fixture-owned")
        h.check('"udp_adversary"' in matrix,
                "the complete registered matrix includes the adversary suite")
        h.check("udp_datagram_adversary" not in product_text and FEATURE not in product_text,
                "product sources and build have no relay-fixture dependency")
        h.check("SOCK_DGRAM" in fixture.read_text() and "sendto" in fixture.read_text(),
                "the fixture is a real user-space datagram relay")
        h.check("peer_route" not in fixture.read_text() and "TransportKind" not in fixture.read_text(),
                "the relay cannot register itself as a product route")

    h.case("revision metadata and private fixture boundary", revision_and_private_boundary)

    adversity, outage, recovery = schedule_vectors(h.output)

    def canonical_schedule_and_negative_controls() -> None:
        encoded = adversity.encode()
        h.check(FaultSchedule.decode(encoded) == adversity,
                "canonical schedule round-trips byte exactly")
        h.check(hashlib.sha256(encoded).hexdigest() == adversity.sha256(),
                "canonical schedule digest is independently reproducible")
        h.check(encoded == (h.output / "adversity-schedule.json").read_bytes(),
                "persisted schedule equals the canonical vector")
        h.check(len(adversity.rules) == 10,
                "both configured directions carry all five fault classes")
        h.check({rule.action for rule in adversity.rules} ==
                {"DROP", "DUPLICATE", "CORRUPT", "DELAY", "REORDER"},
                "loss duplication corruption delay and reordering are explicit")
        h.check(adversity.max_pending_events == 128 and
                adversity.max_trace_records == 16_384 and
                adversity.max_datagram_bytes == 512,
                "datagram event and trace resources are finite")

        malformed: list[bytes] = []
        malformed.append(json.dumps(adversity.object(), indent=2, sort_keys=True).encode() + b"\n")
        unknown = adversity.object(); unknown["unknown"] = 1
        malformed.append(canonical_json(unknown))
        unsorted = adversity.object(); unsorted["rules"] = list(reversed(unsorted["rules"]))
        malformed.append(canonical_json(unsorted))
        duplicate = adversity.object(); duplicate["rules"] = [duplicate["rules"][0], duplicate["rules"][0]]
        malformed.append(canonical_json(duplicate))
        too_small = adversity.object(); too_small["max_datagram_bytes"] = 255
        malformed.append(canonical_json(too_small))
        bad_default = adversity.object(); bad_default["default_action"] = "CORRUPT"
        malformed.append(canonical_json(bad_default))
        for index, vector in enumerate(malformed):
            try:
                FaultSchedule.decode(vector)
            except ValueError:
                pass
            else:
                raise AssertionError(f"malformed schedule vector {index} was accepted")
            h.check(True, f"malformed schedule vector {index} rejected")

        h.check(outage.default_action == "DROP" and not outage.rules,
                "outage is one canonical finite default-drop phase")
        h.check(recovery.default_action == "PASS" and not recovery.rules,
                "recovery is one canonical finite pass phase")

    h.case("canonical schedules bounds and malformed rejection",
           canonical_schedule_and_negative_controls)

    def relay_paths_for_bound_test() -> tuple[RelayPath, RelayPath]:
        ports = [free_udp_port() for _ in range(8)]
        return (
            RelayPath(
                name="ab",
                left_bind=("127.0.0.1", ports[1]),
                left_source=("127.0.0.1", ports[0]),
                right_bind=("127.0.0.1", ports[2]),
                right_source=("127.0.0.1", ports[3]),
                left_to_right="A_TO_B",
                right_to_left="B_TO_A",
            ),
            RelayPath(
                name="ba",
                left_bind=("127.0.0.1", ports[5]),
                left_source=("127.0.0.1", ports[4]),
                right_bind=("127.0.0.1", ports[6]),
                right_source=("127.0.0.1", ports[7]),
                left_to_right="B_TO_A",
                right_to_left="A_TO_B",
            ),
        )

    def expect_relay_failure(
        schedule: FaultSchedule, payload: bytes, expected_detail: str
    ) -> None:
        paths = relay_paths_for_bound_test()
        relay = DatagramAdversary(paths)
        relay.start()
        observed = False
        try:
            relay.install(schedule)
            source = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                source.bind(paths[0].left_source)
                source.sendto(payload, paths[0].left_bind)
            finally:
                source.close()
            deadline = time.monotonic() + 2.0
            while time.monotonic() < deadline:
                try:
                    relay.assert_healthy()
                except AdversaryError as exc:
                    observed = expected_detail in str(exc)
                    break
                time.sleep(0.01)
        finally:
            try:
                relay.close()
            except AdversaryError as exc:
                observed = observed or expected_detail in str(exc)
        h.check(observed, f"relay fails closed on {expected_detail}")

    def runtime_bound_enforcement() -> None:
        expect_relay_failure(
            FaultSchedule(
                name="trace-bound", default_action="PASS",
                max_datagram_bytes=512, max_pending_events=4,
                max_trace_records=1,
            ),
            b"bounded-trace",
            "trace bound exhausted",
        )
        expect_relay_failure(
            FaultSchedule(
                name="event-bound", default_action="PASS",
                max_datagram_bytes=512, max_pending_events=1,
                max_trace_records=64,
                rules=(FaultRule("ab", "A_TO_B", 1, "DUPLICATE", 10),),
            ),
            b"bounded-events",
            "pending-event bound exhausted",
        )
        expect_relay_failure(
            FaultSchedule(
                name="datagram-bound", default_action="PASS",
                max_datagram_bytes=256, max_pending_events=4,
                max_trace_records=64,
            ),
            bytes(300),
            "input exceeded the declared datagram bound",
        )

    h.case("runtime datagram event and trace bounds fail closed",
           runtime_bound_enforcement)

    def persistent_lifecycle() -> None:
        root = h.runtime / "udp-adversary"
        root.mkdir(parents=True)
        a_state, b_state = root / "a", root / "b"
        ports = [free_udp_port() for _ in range(8)]
        (
            a_route_port,
            relay_ab_left,
            relay_ab_right,
            b_listen_port,
            b_route_port,
            relay_ba_left,
            relay_ba_right,
            a_listen_port,
        ) = ports

        paths = (
            RelayPath(
                name="ab",
                left_bind=("127.0.0.1", relay_ab_left),
                left_source=("127.0.0.1", a_route_port),
                right_bind=("127.0.0.1", relay_ab_right),
                right_source=("127.0.0.1", b_listen_port),
                left_to_right="A_TO_B",
                right_to_left="B_TO_A",
            ),
            RelayPath(
                name="ba",
                left_bind=("127.0.0.1", relay_ba_left),
                left_source=("127.0.0.1", b_route_port),
                right_bind=("127.0.0.1", relay_ba_right),
                right_source=("127.0.0.1", a_listen_port),
                left_to_right="B_TO_A",
                right_to_left="A_TO_B",
            ),
        )
        relay = DatagramAdversary(paths)
        relay.start()
        try:
            relay.install(adversity, phase="adversity-one")
            scope_ab = "udp-adversary/a-to-b"
            scope_ba = "udp-adversary/b-to-a"
            link_ab = "5544504144563031"
            link_ba = "5544504144563032"
            a_listen = locator(a_listen_port, relay_ba_right, link_ba, 12)
            a_route = locator(a_route_port, relay_ab_left, link_ab, 11)
            b_listen = locator(b_listen_port, relay_ab_right, link_ab, 11)
            b_route = locator(b_route_port, relay_ba_left, link_ba, 12)

            a_conf = write_v13_config(
                h,
                "udp-adversary-a",
                "A",
                a_state,
                a_listen,
                "udp-adversary-a-v1",
                [("B", [("udp-ab", 0, "ENABLED", a_route)], 100, 400, 40, 60_000)],
                authorizations=[("B", scope_ba)],
                deadline_ms=2_500,
                session_operations=1,
                session_idle_ms=1_000,
            )
            b_conf = write_v13_config(
                h,
                "udp-adversary-b",
                "B",
                b_state,
                b_listen,
                "udp-adversary-b-v1",
                [("A", [("udp-ba", 0, "ENABLED", b_route)], 100, 400, 40, 60_000)],
                authorizations=[("A", scope_ab)],
                deadline_ms=2_500,
                session_operations=1,
                session_idle_ms=1_000,
            )
            h.check(h.run("udp-adversary-config-a", ["config-check", "--config", str(a_conf)]) is not None,
                    "A canonical UDP listener and route configuration is accepted")
            h.check(h.run("udp-adversary-config-b", ["config-check", "--config", str(b_conf)]) is not None,
                    "B canonical UDP listener and route configuration is accepted")

            b = h.start("udp-adversary-b-1", b_conf, b_state)
            a = h.start("udp-adversary-a-1", a_conf, a_state)

            op_one = operation("udp-adversary-replay-one")
            op_two = operation("udp-adversary-replay-two")
            op_reverse = operation("udp-adversary-reverse")
            op_pending = operation("udp-adversary-pending-restart")
            op_after_restart = operation("udp-adversary-after-restart")
            payload_one = "equal-length-adversity-payload-one"
            payload_two = "equal-length-adversity-payload-two"
            h.check(len(payload_one) == len(payload_two),
                    "replay payloads have identical cleartext size")

            submit(h, "udp-adversary-submit-one", a.control, "A", "B",
                   scope_ab, op_one, payload_one)
            first_status: dict[str, Any] = {}

            def first_acked() -> bool:
                first_status.clear()
                first_status.update(h.status("udp-adversary-wait-one", a_state,
                                             logical_digest=False))
                return outbox_entry(first_status, op_one)["status"] == "ACKED"

            wait_for(h, "first adversarial UDP obligation acknowledged", first_acked)
            first_entry = exact_outbox_record(
                h, "udp-adversary-receipt-one", a_state, op_one)
            h.check(first_entry["status"] == "ACKED" and
                    first_entry["receipt"] is not None and
                    first_entry["receipt"]["recorder"] == "B" and
                    first_entry["receipt"]["recipient"] == "B" and
                    first_entry["receipt"]["operation_id"] == op_one and
                    first_entry["receipt"]["disposition"] in {"COMMITTED", "DUPLICATE"},
                    "first durable receipt remains bound to B and the operation above UDP")
            b_first = h.status("udp-adversary-b-first", b_state, logical_digest=False)
            h.check(b_first["inbound_records"] == 1,
                    "duplicated and retransmitted datagrams admit one operation")

            def first_closed() -> bool:
                sender = h.status("udp-adversary-close-one-a", a_state,
                                  logical_digest=False)
                receiver = h.status("udp-adversary-close-one-b", b_state,
                                    logical_digest=False)
                return (
                    peer_status(sender, "B")["session"]["state"] == "DISCONNECTED"
                    and peer_status(sender, "B")["session"]["retired"] >= 1
                    and receiver["service"]["peer_active"] == 0
                    and receiver["service"]["peer_session_retirements"] >= 1
                )

            wait_for(h, "operation-cap session releases the UDP listener lease",
                     first_closed)
            relay.wait_quiet(timeout=5.0)
            first_signature = fault_signature(relay.trace_records(), "adversity-one")
            h.check(len(first_signature) == 5 and
                    {item[3] for item in first_signature} ==
                    {"DROP", "DUPLICATE", "CORRUPT", "DELAY", "REORDER"},
                    "first session exercises every scheduled datagram fault")

            captured = relay.captured("ab", "A_TO_B")
            before_attack = h.status("udp-adversary-before-attack", b_state,
                                     logical_digest=False)
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as attacker:
                attacker.bind(("127.0.0.1", free_udp_port()))
                attacker.sendto(captured, ("127.0.0.1", b_listen_port))
            time.sleep(0.25)
            after_attack = h.status("udp-adversary-after-attack", b_state,
                                    logical_digest=False)
            h.check(after_attack["inbound_records"] == before_attack["inbound_records"],
                    "unconfigured-source packet cannot create an admission")
            h.check(after_attack["service"]["peer_session_connections"] ==
                    before_attack["service"]["peer_session_connections"],
                    "unconfigured source cannot activate or migrate the fixed UDP listener")

            relay.install(adversity, phase="adversity-two")
            submit(h, "udp-adversary-submit-two", a.control, "A", "B",
                   scope_ab, op_two, payload_two)

            def second_acked() -> bool:
                status = h.status("udp-adversary-wait-two", a_state,
                                  logical_digest=False)
                return outbox_entry(status, op_two)["status"] == "ACKED"

            wait_for(h, "replayed schedule delivers a second obligation", second_acked)

            def second_closed() -> bool:
                status = h.status("udp-adversary-close-two", a_state,
                                  logical_digest=False)
                return peer_status(status, "B")["session"]["state"] == "DISCONNECTED" and \
                    peer_status(status, "B")["session"]["retired"] >= 2

            wait_for(h, "second operation-cap session retires", second_closed)
            relay.wait_quiet(timeout=5.0)
            second_signature = fault_signature(relay.trace_records(), "adversity-two")
            h.check(second_signature == first_signature,
                    "replayed schedule preserves direction ordinal action and packet-size structure")
            first_faults = {
                (item["path"], item["direction"], item["ordinal"], item["action"]):
                    item["input_sha256"]
                for item in relay.trace_records("adversity-one")
                if item.get("kind") == "INGRESS" and item.get("action") != "PASS"
            }
            second_faults = {
                (item["path"], item["direction"], item["ordinal"], item["action"]):
                    item["input_sha256"]
                for item in relay.trace_records("adversity-two")
                if item.get("kind") == "INGRESS" and item.get("action") != "PASS"
            }
            h.check(first_faults.keys() == second_faults.keys(),
                    "replay targets the exact same canonical fault coordinates")
            h.check(any(first_faults[key] != second_faults[key] for key in first_faults),
                    "independent TLS handshakes retain fresh ciphertext randomness")
            h.check(h.status("udp-adversary-b-two", b_state,
                             logical_digest=False)["inbound_records"] == 2,
                    "replay does not multiply recipient admission")

            relay.install(adversity, phase="reverse-adversity")
            submit(h, "udp-adversary-submit-reverse", b.control, "B", "A",
                   scope_ba, op_reverse, "reverse-direction-adversity")

            def reverse_acked() -> bool:
                status = h.status("udp-adversary-wait-reverse", b_state,
                                  logical_digest=False)
                return outbox_entry(status, op_reverse)["status"] == "ACKED"

            wait_for(h, "reverse configured UDP route is acknowledged", reverse_acked)
            h.check(h.status("udp-adversary-a-reverse", a_state,
                             logical_digest=False)["inbound_records"] == 1,
                    "A listener admits exactly one reverse operation")
            relay.wait_quiet(timeout=5.0)
            reverse_signature = fault_signature(relay.trace_records(),
                                                 "reverse-adversity")
            h.check(len(reverse_signature) == 5 and
                    all(item[0] == "ba" for item in reverse_signature),
                    "reverse route exercises the bounded BA relay path")

            before_outage = h.status(
                "udp-adversary-before-outage", a_state, logical_digest=False)
            baseline_route_attempts = peer_status(before_outage, "B")["routes"][0][
                "connection_attempts_this_run"]
            relay.install(outage, phase="outage")
            submit(h, "udp-adversary-submit-pending", a.control, "A", "B",
                   scope_ab, op_pending, "durable-pending-during-outage")
            pending_status: dict[str, Any] = {}

            def failed_attempt_visible() -> bool:
                pending_status.clear()
                pending_status.update(h.status("udp-adversary-wait-failure", a_state,
                                               logical_digest=False))
                item = outbox_entry(pending_status, op_pending)
                route = peer_status(pending_status, "B")["routes"][0]
                return (
                    item["status"] == "PENDING"
                    and item["attempts"] == 0
                    and route["connection_attempts_this_run"] > baseline_route_attempts
                    and route["last_failure_code"] is not None
                )

            wait_for(h,
                     "deterministic outage records scheduler failure while preserving durable work",
                     failed_attempt_visible, timeout=15.0)
            failed_entry = outbox_entry(pending_status, op_pending)
            failed_route = peer_status(pending_status, "B")["routes"][0]
            h.check(failed_route["last_failure_code"] in {
                    "TLS_HANDSHAKE_FAILED", "IO_TIMEOUT",
                    "PACKET_LINK_RETRY_EXHAUSTED", "HANDSHAKE_EOF",
                    "PEER_RESET", "UDP_RECEIVE_FAILED", "UDP_SEND_FAILED"},
                    "outage failure is typed rather than guessed success")
            h.check(failed_entry["attempts"] == 0 and
                    failed_entry["last_error_code"] is None,
                    "pre-authentication route failure does not consume an application attempt")
            a.shutdown()
            relay.wait_quiet(timeout=5.0)
            offline_a = h.run("udp-adversary-offline-pending",
                              ["inspect", "--state", str(a_state), "--node", "A"])
            h.check(offline_a is not None and
                    outbox_entry(offline_a, op_pending)["status"] == "PENDING",
                    "orderly stop preserves the unresolved obligation")

            relay.install(recovery, phase="recovery-after-pending")
            a2 = h.start("udp-adversary-a-2", a_conf, a_state)
            h.run("udp-adversary-wake-pending",
                  ["wake", "--control", str(a2.control), "--peer", "B"])

            def recovered() -> bool:
                status = h.status("udp-adversary-wait-recovery", a_state,
                                  logical_digest=False)
                return outbox_entry(status, op_pending)["status"] == "ACKED"

            wait_for(h, "pending obligation is acknowledged after restart and recovery",
                     recovered, timeout=20.0)
            recovered_a = h.status("udp-adversary-recovered-a", a_state,
                                   logical_digest=False)
            recovered_b = h.status("udp-adversary-recovered-b", b_state,
                                   logical_digest=False)
            recovered_record = exact_outbox_record(
                h, "udp-adversary-receipt-recovered", a_state, op_pending)
            h.check(recovered_record["status"] == "ACKED" and
                    recovered_record["receipt"] is not None and
                    recovered_record["receipt"]["recorder"] == "B" and
                    recovered_record["receipt"]["operation_id"] == op_pending,
                    "recovered obligation has a durable receipt bound to B and the operation")
            h.check(recovered_b["inbound_records"] == 3,
                    "recipient has exactly three distinct A-to-B operations")
            h.check(any(item.get("kind") == "INGRESS" and
                        item.get("phase") == "outage" and
                        item.get("action") == "DROP"
                        for item in relay.trace_records()),
                    "outage trace proves deterministic datagram loss occurred")

            a2.shutdown(); b.shutdown()
            offline_a_final = h.run("udp-adversary-offline-a-final",
                                    ["inspect", "--state", str(a_state), "--node", "A"])
            offline_b_final = h.run("udp-adversary-offline-b-final",
                                    ["inspect", "--state", str(b_state), "--node", "B"])
            h.check(offline_a_final is not None and
                    offline_a_final["outbox"]["acked"] == 3 and
                    offline_a_final["outbox"]["pending"] == 0,
                    "A durable receipts survive orderly two-node stop")
            h.check(offline_b_final is not None and
                    offline_b_final["outbox"]["acked"] == 1 and
                    offline_b_final["inbound"]["count"] == 3,
                    "B reverse receipt and inbound history survive orderly stop")

            relay.wait_quiet(timeout=5.0)
            relay.install(recovery, phase="post-restart")
            b2 = h.start("udp-adversary-b-2", b_conf, b_state)
            a3 = h.start("udp-adversary-a-3", a_conf, a_state)
            restored_a = h.status("udp-adversary-restored-a", a_state,
                                  logical_digest=False)
            restored_b = h.status("udp-adversary-restored-b", b_state,
                                  logical_digest=False)
            h.check(restored_a["outbox"]["acked"] == 3 and
                    restored_b["outbox"]["acked"] == 1,
                    "both persistent nodes reconstruct terminal receipts")
            h.check(peer_status(restored_a, "B")["attempts_this_run"] == 0 and
                    peer_status(restored_b, "A")["attempts_this_run"] == 0,
                    "restart does not resend acknowledged obligations")

            submit(h, "udp-adversary-submit-after-restart", a3.control, "A", "B",
                   scope_ab, op_after_restart, "post-restart-listener-reopen")

            def after_restart_acked() -> bool:
                status = h.status("udp-adversary-wait-after-restart", a_state,
                                  logical_digest=False)
                return outbox_entry(status, op_after_restart)["status"] == "ACKED"

            wait_for(h, "post-restart UDP listener and scheduler deliver new work",
                     after_restart_acked)
            h.check(h.status("udp-adversary-b-after-restart", b_state,
                             logical_digest=False)["inbound_records"] == 4,
                    "post-restart delivery is admitted exactly once")
            a3.shutdown(); b2.shutdown()
            relay.wait_quiet(timeout=5.0)

            trace_path = h.output / "udp-adversary-trace.json"
            relay.write_trace(trace_path)
            encoded_trace = trace_path.read_bytes()
            decoded_trace = json.loads(encoded_trace)
            h.check(decoded_trace.get("format") == TRACE_FORMAT and
                    decoded_trace.get("feature") == FEATURE,
                    "trace format and feature are explicit")
            h.check(encoded_trace == canonical_json(decoded_trace),
                    "trace is canonical replayable JSON")
            h.check(len(decoded_trace["records"]) <=
                    decoded_trace["max_trace_records"],
                    "trace remains within its declared finite bound")
            h.check(any(item.get("kind") == "EMIT" and item.get("copy") == 1
                        for item in decoded_trace["records"]),
                    "trace proves a duplicate datagram was emitted")
            h.check(any(item.get("kind") == "EMIT" and
                        item.get("scheduled_delay_ms", 0) >= 30
                        for item in decoded_trace["records"]),
                    "trace proves delayed or reorder-held progress")

            evidence.update({
                "schedule_sha256": adversity.sha256(),
                "trace_sha256": hashlib.sha256(encoded_trace).hexdigest(),
                "trace_records": len(decoded_trace["records"]),
                "first_signature": first_signature,
                "second_signature": second_signature,
                "reverse_signature": reverse_signature,
                "operations": {
                    "first": op_one,
                    "replay": op_two,
                    "reverse": op_reverse,
                    "pending_restart": op_pending,
                    "after_restart": op_after_restart,
                },
            })
        finally:
            try:
                relay.write_trace(h.output / "udp-adversary-trace-partial.json")
            except BaseException:
                pass
            relay.close()

    h.case("persistent two-node UDP adversity retry stop and restart",
           persistent_lifecycle)
    return evidence


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source_root = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    binary = args.binary.resolve(strict=True)
    if output.exists() or output == source_root or source_root in output.parents:
        parser.error("output must be new and outside the source tree")
    harness = Harness(binary, output)
    started = time.monotonic()
    status = "FAIL"
    failure: str | None = None
    evidence: dict[str, Any] = {}
    try:
        evidence = run_suite(harness)
        status = "PASS"
    except BaseException as exc:
        failure = f"{type(exc).__name__}: {exc}"
        (output / "FAILURE.txt").write_text(failure + "\n")
        print(f"FAIL: {failure}", file=os.sys.stderr, flush=True)
    finally:
        harness.cleanup()
        summary: dict[str, Any] = {
            "assertions": harness.assertions,
            "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
            "cases_passed": sum(item["status"] == "PASS" for item in harness.cases),
            "cases_total": len(harness.cases),
            "commands": len(harness.commands),
            "elapsed_seconds": time.monotonic() - started,
            "feature": FEATURE,
            "format": "NATRAV_UDP_ADVERSARY_SUITE_V1",
            "hardware_verified": False,
            "independent_host_verified": False,
            "status": status,
            "evidence": evidence,
        }
        if failure is not None:
            summary["failure"] = failure
        (output / "SUMMARY.json").write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n"
        )
        (output / "CASES.json").write_text(
            json.dumps(harness.cases, indent=2, sort_keys=True) + "\n"
        )
        (output / "COMMANDS.json").write_text(
            json.dumps(harness.commands, indent=2, sort_keys=True) + "\n"
        )
        print(json.dumps({key: value for key, value in summary.items()
                          if key != "evidence"}, sort_keys=True), flush=True)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
