#include "custody_envelope.hpp"

#include <cstdint>
#include <functional>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

using namespace natrav_overlay;

namespace {
using KeyPtr = std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)>;
std::size_t assertions = 0U;

void check(bool condition, const char* detail) {
    ++assertions;
    if (!condition) throw std::runtime_error(detail);
}

void reject(const std::function<void()>& action, std::string_view code = {}) {
    try { action(); }
    catch (const AppError& error) {
        check(code.empty() || error.code() == code, error.what());
        return;
    }
    check(false, "expected rejection");
}

KeyPtr key(std::uint8_t byte) {
    CustodySigningKey seed{};
    seed.fill(byte);
    auto* value = EVP_PKEY_new_raw_private_key(
        EVP_PKEY_ED25519, nullptr, seed.data(), seed.size());
    if (value == nullptr) throw std::runtime_error("test key creation failed");
    return KeyPtr(value, EVP_PKEY_free);
}

datacube::Digest32 filled_digest(std::uint8_t byte) {
    datacube::Digest32 result;
    result.octets.fill(byte);
    return result;
}
} // namespace

int main() {
    try {
        auto origin_key = key(1U);
        auto relay_one_key = key(2U);
        auto relay_two_key = key(3U);
        auto recipient_key = key(4U);
        auto unrelated_key = key(5U);
        std::vector<CustodyParty> route{
            make_custody_party("origin", "g1", origin_key.get()),
            make_custody_party("relay-one", "g7", relay_one_key.get()),
            make_custody_party("relay-two", "g3", relay_two_key.get()),
            make_custody_party("recipient", "g9", recipient_key.get()),
        };
        datacube::Octets capsule(2048U);
        for (std::size_t i = 0U; i < capsule.size(); ++i) {
            capsule[i] = static_cast<std::uint8_t>((i * 37U) & 0xffU);
        }

        const auto envelope = make_custody_envelope(
            route, capsule, 1000U, 100000U, origin_key.get());
        const auto decoded = decode_custody_envelope(envelope.canonical);
        check(decoded.route == route, "route roundtrip");
        check(decoded.hop_limit == 3U, "hop bound");
        check(decoded.capsule_bytes == capsule.size(), "capsule size");
        check(decoded.capsule_sha256 == datacube::sha256(capsule), "capsule digest");
        require_custody_capsule(decoded, capsule);
        auto changed_capsule = capsule;
        changed_capsule[17U] ^= 0x40U;
        reject([&] { require_custody_capsule(decoded, changed_capsule); },
               "CUSTODY_CAPSULE_REJECTED");

        for (std::size_t n = 0U; n < envelope.canonical.size(); ++n) {
            reject([&] { (void)decode_custody_envelope(
                datacube::OctetView(envelope.canonical.data(), n)); });
        }
        for (std::size_t i = 0U; i < envelope.canonical.size(); ++i) {
            auto bytes = envelope.canonical;
            bytes[i] ^= 1U;
            reject([&] { (void)decode_custody_envelope(bytes); });
        }

        auto loop = route;
        loop[2U] = loop[0U];
        reject([&] { (void)make_custody_envelope(
            loop, capsule, 1000U, 2000U, origin_key.get()); }, "CUSTODY_ROUTE_LOOP");
        auto reused = route;
        reused[2U].signing_public = reused[0U].signing_public;
        reject([&] { (void)make_custody_envelope(
            reused, capsule, 1000U, 2000U, origin_key.get()); },
            "CUSTODY_ROUTE_KEY_REUSE");
        reject([&] { (void)make_custody_envelope(
            std::span<const CustodyParty>(route.data(), 1U), capsule,
            1000U, 2000U, origin_key.get()); }, "CUSTODY_ROUTE_REJECTED");
        reject([&] { (void)make_custody_envelope(
            route, {}, 1000U, 2000U, origin_key.get()); }, "CUSTODY_CAPSULE_REJECTED");
        reject([&] { (void)make_custody_envelope(
            route, capsule, 1000U, 1000U + kCustodyEnvelopeLifetimeLimitMs + 1U,
            origin_key.get()); }, "CUSTODY_TIME_REJECTED");
        reject([&] { (void)make_custody_envelope(
            route, capsule, 1000U, 2000U, unrelated_key.get()); },
            "CUSTODY_SIGNING_KEY_REJECTED");

        std::vector<KeyPtr> max_keys;
        std::vector<CustodyParty> max_route;
        for (std::size_t i = 0U; i < kCustodyRoutePartyLimit; ++i) {
            max_keys.push_back(key(static_cast<std::uint8_t>(20U + i)));
            max_route.push_back(make_custody_party(
                "node-" + std::to_string(i), "g-" + std::to_string(i + 1U),
                max_keys.back().get()));
        }
        const auto maximum = make_custody_envelope(
            max_route, capsule, 1000U, 2000U, max_keys.front().get());
        check(maximum.hop_limit == kCustodyRoutePartyLimit - 1U,
              "maximum route accepted");
        auto too_many = max_route;
        auto extra = key(99U);
        too_many.push_back(make_custody_party("extra", "g-extra", extra.get()));
        reject([&] { (void)make_custody_envelope(
            too_many, capsule, 1000U, 2000U, max_keys.front().get()); },
            "CUSTODY_ROUTE_REJECTED");

        auto progress = initial_custody_progress(envelope);
        check(progress.current_party_index == 0U && !progress.awaiting_acceptance,
              "origin initially holds custody");
        check(!progress.final_custody_accepted(envelope), "not final delivery");
        reject([&] { (void)make_custody_acceptance(
            envelope, progress, 1500U, relay_one_key.get()); }, "CUSTODY_STATE_REJECTED");
        reject([&] { (void)make_custody_transfer(
            envelope, progress, 1500U, unrelated_key.get()); },
            "CUSTODY_SIGNING_KEY_REJECTED");

        std::vector<datacube::Octets> records;
        const auto transfer_one = make_custody_transfer(
            envelope, progress, 2000U, origin_key.get());
        check(apply_custody_record(envelope, transfer_one, progress) ==
              CustodyApplyResult::applied, "transfer one");
        records.push_back(transfer_one.canonical);
        check(apply_custody_record(envelope, transfer_one, progress) ==
              CustodyApplyResult::duplicate, "exact duplicate");
        reject([&] { (void)make_custody_transfer(
            envelope, progress, 2001U, origin_key.get()); }, "CUSTODY_STATE_REJECTED");

        for (std::size_t n = 0U; n < transfer_one.canonical.size(); ++n) {
            reject([&] { (void)decode_custody_record(envelope,
                datacube::OctetView(transfer_one.canonical.data(), n)); });
        }
        for (std::size_t i = 0U; i < transfer_one.canonical.size(); ++i) {
            auto bytes = transfer_one.canonical;
            bytes[i] ^= 1U;
            reject([&] { (void)decode_custody_record(envelope, bytes); });
        }

        auto drift = transfer_one;
        drift.actor_index = 1U;
        auto clean = initial_custody_progress(envelope);
        reject([&] { (void)apply_custody_record(envelope, drift, clean); },
               "CUSTODY_ENCODING_REJECTED");

        auto initial_again = initial_custody_progress(envelope);
        const auto conflict = make_custody_transfer(
            envelope, initial_again, 2001U, origin_key.get());
        reject([&] { (void)apply_custody_record(envelope, conflict, progress); },
               "CUSTODY_SEQUENCE_REJECTED");

        auto invalid_progress = progress;
        invalid_progress.last_record_sha256 = filled_digest(42U);
        reject([&] { (void)make_custody_acceptance(
            envelope, invalid_progress, 2100U, relay_one_key.get()); },
            "CUSTODY_STATE_REJECTED");

        auto fake_time = progress;
        fake_time.last_event_ms = envelope.created_ms;
        const auto backward = make_custody_acceptance(
            envelope, fake_time, 1500U, relay_one_key.get());
        reject([&] { (void)apply_custody_record(envelope, backward, progress); },
               "CUSTODY_TIME_REJECTED");

        const auto accept_one = make_custody_acceptance(
            envelope, progress, 2100U, relay_one_key.get());
        auto out_of_order = initial_custody_progress(envelope);
        reject([&] { (void)apply_custody_record(envelope, accept_one, out_of_order); },
               "CUSTODY_SEQUENCE_REJECTED");
        check(apply_custody_record(envelope, accept_one, progress) ==
              CustodyApplyResult::applied, "accept one");
        records.push_back(accept_one.canonical);
        check(progress.current_party_index == 1U && !progress.awaiting_acceptance,
              "relay one custody");

        const auto transfer_two = make_custody_transfer(
            envelope, progress, 3000U, relay_one_key.get());
        check(apply_custody_record(envelope, transfer_two, progress) ==
              CustodyApplyResult::applied, "transfer two");
        records.push_back(transfer_two.canonical);
        const auto accept_two = make_custody_acceptance(
            envelope, progress, 3100U, relay_two_key.get());
        check(apply_custody_record(envelope, accept_two, progress) ==
              CustodyApplyResult::applied, "accept two");
        records.push_back(accept_two.canonical);
        const auto transfer_final = make_custody_transfer(
            envelope, progress, 4000U, relay_two_key.get());
        check(apply_custody_record(envelope, transfer_final, progress) ==
              CustodyApplyResult::applied, "final transfer");
        records.push_back(transfer_final.canonical);
        const auto accept_final = make_custody_acceptance(
            envelope, progress, 4100U, recipient_key.get());
        check(apply_custody_record(envelope, accept_final, progress) ==
              CustodyApplyResult::applied, "final acceptance");
        records.push_back(accept_final.canonical);
        check(progress.final_custody_accepted(envelope),
              "final custody is distinct from application delivery");
        check(progress.current_party_index == 3U &&
              progress.accepted_record_sha256.size() == 6U &&
              progress.next_sequence == 7U, "bounded terminal state");
        reject([&] { (void)make_custody_transfer(
            envelope, progress, 4200U, recipient_key.get()); }, "CUSTODY_FINAL_STATE");
        check(apply_custody_record(envelope, transfer_one, progress) ==
              CustodyApplyResult::duplicate, "old duplicate remains bounded");

        auto replay = records;
        replay.insert(replay.begin() + 1, transfer_one.canonical);
        replay.push_back(accept_final.canonical);
        const auto reconstructed = reconstruct_custody_progress(envelope, replay);
        check(reconstructed.final_custody_accepted(envelope) &&
              reconstructed.last_record_sha256 == progress.last_record_sha256,
              "reconstruction tolerates exact duplicate evidence");

        auto other_capsule = capsule;
        other_capsule.push_back(0x7fU);
        const auto other_envelope = make_custody_envelope(
            route, other_capsule, 1000U, 100000U, origin_key.get());
        reject([&] { (void)decode_custody_record(
            other_envelope, transfer_one.canonical); }, "CUSTODY_ENVELOPE_MISMATCH");

        auto expiring = initial_custody_progress(envelope);
        reject([&] { (void)make_custody_transfer(
            envelope, expiring, envelope.expires_ms, origin_key.get()); },
            "CUSTODY_TIME_REJECTED");

        std::cout << "{\"status\":\"PASS\",\"case_groups\":10,\"assertions\":"
                  << assertions << "}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
