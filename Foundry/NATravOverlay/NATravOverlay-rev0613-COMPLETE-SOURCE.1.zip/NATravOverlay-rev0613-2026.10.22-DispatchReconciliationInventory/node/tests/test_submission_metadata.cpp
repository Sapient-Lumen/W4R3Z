// Link this test in place of node/src/main.cpp in a disposable source copy.
// It calls the real NodeState, including journal replay, not a mock queue.
#include "journal.hpp"

#include <barrier>
#include <cstdlib>
#include <exception>
#include <filesystem>
#include <iostream>
#include <thread>
#include <type_traits>
#include <vector>

namespace no = natrav_overlay;
namespace {
std::uint64_t checks = 0;
void check(bool value, const char* message) {
    ++checks;
    if (!value) throw std::runtime_error(message);
}
template<class T> concept HasEntry = requires(T a) { a.entry; };
template<class T> concept HasPayload = requires(T a) { a.payload; };
static_assert(!HasEntry<no::QueueResult> && !HasPayload<no::QueueResult>);
static_assert(!HasEntry<no::SubmissionObservation> && !HasPayload<no::SubmissionObservation>);

struct Directory final {
    std::filesystem::path path;
    Directory() {
        char pattern[] = "/tmp/natrav-submission-native-XXXXXX";
        char* name = ::mkdtemp(pattern);
        if (!name) throw std::runtime_error("mkdtemp failed");
        path = name;
    }
    ~Directory() { std::error_code ignored; std::filesystem::remove_all(path, ignored); }
};

datacube::Digest32 digest(const std::string_view text) {
    return datacube::sha256(datacube::text_octets(text));
}

no::OutboundPolicy policy(std::uint64_t created) {
    return no::OutboundPolicy{
        .created_unix_ms=created, .expires_unix_ms=2'000'000U+created,
        .maximum_attempts=5U, .initial_backoff_ms=10U, .maximum_backoff_ms=100U,
        .peer_spki_sha256=digest("B-key"), .peer_generation="b-g1"};
}
}

int main() {
    try {
        Directory root;
        std::uint64_t snapshot_bytes=0;
        {
            no::NodeState state(root.path/"state", "A", 16U*1024U*1024U);
            no::EvidenceRecord record{.operation_id=digest("native-unbound"), .issuer="A", .recipient="B",
                .scope="test/native", .corrects=std::nullopt, .payload=datacube::Octets(60'000U, 42U)};
            no::QueueResult first;
            no::SubmissionWork initial_work;
            {
                no::SubmissionWorkScope scoped(initial_work);
                first=state.queue_outbound(record);
            }
            check(first.disposition==no::QueueDisposition::queued && !first.has_delivery_policy,"legacy queue has no initial policy");
            check(first.operation_id==record.operation_id && first.status=="PENDING","bounded result identity");
            check(initial_work.snapshot_calls==0 && initial_work.digest_payload_bytes==60000U,"enqueue no full state copy");
            constexpr std::size_t count=16U;
            std::barrier start(static_cast<std::ptrdiff_t>(count));
            std::vector<std::thread> workers;
            std::vector<std::exception_ptr> failures(count);
            std::vector<no::QueueResult> results(count);
            std::vector<no::SubmissionWork> work(count);
            for(std::size_t i=0;i<count;++i) workers.emplace_back([&,i] {
                try {
                    start.arrive_and_wait();
                    no::SubmissionWorkScope scoped(work[i]);
                    results[i]=state.queue_outbound(record,policy(2000U+i));
                    const auto observed=state.observe_submission(results[i].operation_id,results[i].record_digest);
                    if(observed.operation_id!=record.operation_id || observed.status!="PENDING") throw std::runtime_error("wrong exact observation");
                } catch(...) { failures[i]=std::current_exception(); }
            });
            for(auto& worker:workers) worker.join();
            std::size_t policy_writers=0;
            for(std::size_t i=0;i<count;++i) {
                if(failures[i]) std::rethrow_exception(failures[i]);
                check(results[i].disposition==no::QueueDisposition::already_pending && results[i].has_delivery_policy,"all concurrent initializers converge");
                check(work[i].queue_metadata_records==1 && work[i].observation_metadata_records==1,"exact result and observation visits");
                check(work[i].snapshot_calls==0 && work[i].encoded_application_bytes==0,"duplicate neither snapshots nor reencodes application for enqueue");
                if(work[i].enqueue_journal_payload_bytes) ++policy_writers;
            }
            check(policy_writers==1,"one synchronized missing-policy initializer, no timestamp conflict");
            const auto saved=state.snapshot();
            check(saved.outbound.size()==1 && saved.outbound[0].delivery.has_value(),"single durable record and policy");
            const auto created=saved.outbound[0].delivery->policy.created_unix_ms;
            check(created>=2000U && created<2000U+count,"one exact proposed policy wins");
            const auto later=state.queue_outbound(record,policy(9000U));
            check(later.has_delivery_policy && state.snapshot().outbound[0].delivery->policy.created_unix_ms==created,"duplicate never changes established policy");
            bool wrong_digest=false;
            try { static_cast<void>(state.observe_submission(first.operation_id,digest("wrong"))); }
            catch(const no::AppError& e) {wrong_digest=e.code()=="SUBMISSION_OBSERVATION_CONFLICT";}
            check(wrong_digest,"wrong immutable record binding is rejected");
            state.record_outbound_receipt(no::DeliveryReceipt{.operation_id=record.operation_id,.recipient="B",.recorder="B",
                .disposition=no::ReceiptDisposition::committed,.sequence=1U,.record_digest=first.record_digest});
            const auto acknowledged=state.queue_outbound(record,policy(10000U));
            check(acknowledged.disposition==no::QueueDisposition::already_acked && acknowledged.receipt.has_value(),"bounded offline duplicate receipt retained");
            check(first.status=="PENDING" && state.observe_submission(first.operation_id,first.record_digest).status=="ACKED","enqueue fact is not a later observation");
            no::SubmissionWork deliberately_broad;
            {
                no::SubmissionWorkScope scoped(deliberately_broad);
                static_cast<void>(state.snapshot());
            }
            snapshot_bytes=deliberately_broad.snapshot_evidence_payload_bytes;
            check(deliberately_broad.snapshot_calls==1 && snapshot_bytes==60000U && deliberately_broad.snapshot_logical_bytes>60000U,"instrumentation detects actual snapshot copying");
            // Last transition determines rejection; old error history need not be copied.
            record.operation_id=digest("native-rejection");record.payload={1U,2U};
            auto pending=state.queue_outbound(record,policy(3000U));
            state.begin_outbound_attempt(record.operation_id,4000U,5000U);
            state.record_outbound_rejection(record.operation_id,"AUTHORIZATION_DENIED","bounded test",4001U,"b-g1",digest("B-key"));
            auto rejected=state.queue_outbound(record,policy(5000U));
            check(rejected.status=="REJECTED" && rejected.disposition==no::QueueDisposition::already_rejected,"active rejection result preserved");
            state.retry_outbound(record.operation_id,5000U,"LOCAL_CONTROL","explicit retry");
            check(state.observe_submission(pending.operation_id,pending.record_digest).status=="PENDING" && rejected.status=="REJECTED","clearing rejection does not alter prior metadata value");
        }
        {
            no::NodeState replay(root.path/"state","A",16U*1024U*1024U);
            auto state=replay.snapshot();
            check(state.outbound.size()==2 && state.outbound[0].receipt.has_value(),"replay retains exact receipt and policy");
            check(no::outbound_status_name(state.outbound[1])=="PENDING","retry history reconstructs same scalar outcome");
        }
        std::cout << "{\"format\":\"NATRAV_SUBMISSION_METADATA_NATIVE_V1\",\"status\":\"PASS\",\"checks\":" << checks
                  << ",\"concurrent_policy_initializers\":16,\"policy_records_committed\":1,\"deliberate_snapshot_payload_bytes\":" << snapshot_bytes << "}\n";
        return 0;
    } catch(const std::exception& e) {
        std::cerr << e.what() << '\n';return 1;
    }
}
