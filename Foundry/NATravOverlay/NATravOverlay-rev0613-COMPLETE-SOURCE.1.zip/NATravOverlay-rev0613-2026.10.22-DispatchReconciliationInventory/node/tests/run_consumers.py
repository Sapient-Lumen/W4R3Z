#!/usr/bin/env python3
"""Durable credential-bound consumer pages: real C++ peers, replay and maintenance."""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
import time
from typing import Any
from run_persistent import Harness, Daemon, free_port, operation, raw_control, receive_exact
from run_scoped_reads import scoped_config, send, UID, SECOND_UID
from run_evidence_queries import config as writer_config, OWNER_CLASSES, READ_CLASSES
from run_evidence_feed import wire_feed
from run_local_administration import run_as_uid, expose_control_for_uid
from run_live_configuration import candidate, activate, wait_state
from run_peer_sessions import revise
from run_state_authentication import new_key, migrate, start as start_keyed
from run_indexed_pagination import fixture

PERMISSIONS = OWNER_CLASSES + READ_CLASSES + ['CONSUMER','CONSUMER_ADMIN']

def config(h: Harness,name: str,state: Path,port: int,extra: bool=False) -> Path:
    rules=[(os.geteuid(),'A','query/series','PAYLOAD'),(os.geteuid(),'A','query/other','METADATA')]
    grants=[(os.geteuid(),PERMISSIONS)]
    if extra:
        rules += [(UID,'A','query/series','METADATA'),(SECOND_UID,'A','query/series','METADATA')]
        grants += [(UID,['EVIDENCE_READ','CONSUMER']),(SECOND_UID,['EVIDENCE_READ','CONSUMER','CONSUMER_ADMIN'])]
    p=scoped_config(h,name,'B',state,port,rules,inbound=['A','C'],grants=grants)
    p.write_text(p.read_text().replace('CONFIG_V10','CONFIG_V11'));p.chmod(0o600);return p

def trio(h: Harness,name: str,extra: bool=False):
    a,b,c=(h.runtime/(name+'-'+s) for s in ('a','b','c'));bp=free_port()
    bc=config(h,name+'-b',b,bp,extra)
    ac=writer_config(h,name+'-a','A',a,free_port(),[('B',bp)])
    cc=writer_config(h,name+'-c','C',c,free_port(),[('B',bp)])
    bd=h.start(name+'-b',bc,b);ad=h.start(name+'-a',ac,a);cd=h.start(name+'-c',cc,c)
    return a,b,c,ac,bc,cc,ad,bd,cd

def args(state: Path,cmd: str,name: str='worker',**kw: Any)->list[str]:
    a=['consumer-'+cmd,'--control',str(state/'control.sock'),'--consumer',name,'--deadline-ms','4000']
    for k,v in kw.items():a += ['--'+k.replace('_','-'),str(v)]
    return a

def call(h: Harness,label: str,state: Path,cmd: str,name: str='worker',expected: int=0,uid: int|None=None,**kw: Any)->dict[str,Any]:
    a=args(state,cmd,name,**kw)
    r=h.run(label,a,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,a,expected)
    assert r is not None
    if expected==0:
        h.check(r['format']=='NATRAV_OVERLAY_CONSUMER_V1','versioned native consumer response')
        h.check(r['consumer']['owner_uid']==(os.geteuid() if uid is None else uid),'kernel owner bound')
        h.check(r['sequence_semantics']=='AUTHORIZED_ADMISSION_ORDINAL','authorized ordinal only')
        h.check(r['consumer_work']['validation_records_visited'] <= 4*r['consumer']['limit'], 'replay validation is bounded by at most four pages, not full retained history')
    return r

def wire(cmd: int,name: str,tail: bytes=b'')->bytes:
    n=name.encode();return b'NOC1\x11NCR1'+bytes([cmd])+struct.pack('!H',len(n))+n+tail

def cases(h: Harness,selected: set[str]|None=None)->None:
    def case(name: str,fn: Any):
        if selected is None or name in selected:h.case(name,fn)

    def strict():
        b=h.runtime/'strict';bc=config(h,'strict',b,free_port())
        checked=h.run('v11',['config-check','--config',str(bc)])
        h.check(checked['format']=='NATRAV_OVERLAY_CONFIG_V11','explicit V11')
        for label,change in [('old-version',lambda s:s.replace('CONFIG_V11','CONFIG_V10')),
            ('admin-without-consumer',lambda s:s.replace(',CONSUMER,CONSUMER_ADMIN',',CONSUMER_ADMIN'))]:
            p=bc.with_name(label+'.conf');p.write_text(change(bc.read_text()));p.chmod(0o600)
            h.run(label,['config-check','--config',str(p)],expected=3)
        d=h.start('strict',bc,b)
        def blob(b: bytes)->bytes:return struct.pack('!I',len(b))+b
        reason=b'independent consumer wire'
        body=wire(1,'worker',blob(wire_feed()[5:])+struct.pack('!H',len(reason))+reason)
        ok,response=raw_control(d.control,body)
        h.check(ok and response['disposition']=='CREATED','independent NCR1 registration encoding')
        h.check(call(h,'unsafe-fixed-page-budget',b,'create','bad-page',expected=3,max_bytes=8192,payload='yes',payload_length=4096,reason='cannot encode a complete future row')['code']=='CONSUMER_PAGE_BUDGET_INVALID','immutable consumer cannot be registered with an unsendable row budget')
        created=call(h,'create-empty',b,'create',reason='initialize owned consumer')
        again=call(h,'repeat-create',b,'create',reason='retry a lost registration reply',start='now')
        h.check(again['consumer']['instance']==created['consumer']['instance'] and again['disposition']=='ALREADY_EXISTS','create replay never resets progress')
        for label,body in [('unknown-op',wire(9,'worker')),('trailing',wire(4,'worker',b'x')),
            ('bad-name',wire(4,'../other')),('truncated',wire(3,'worker',bytes(31))),('zero-id',wire(3,'worker',bytes(32))),('bad-magic',wire(4,'worker').replace(b'NCR1',b'NCR9'))]:
            ok,error=raw_control(d.control,body);h.check(not ok and 'consumer' not in error,'strict request '+label)
        before=(b/'state.journal').read_bytes()
        for i in range(12):
            page=call(h,f'empty-{i}',b,'read')
            h.check(page['returned_records']==0 and page['consumer']['pending_batch'] is None and page['feed_work']['index_records_visited']==0,'empty poll no issued object/no visits')
        h.check((b/'state.journal').read_bytes()==before and page['consumer_work']['validation_records_visited']==0,'empty polls are observational with zero validation record visits')
        for i in range(1,16):call(h,f'capacity-{i}',b,'create',f'worker{i}',reason='bounded consumer capacity')
        h.check(call(h,'capacity-first-excess',b,'create','excess',3,reason='no extra slot')['code']=='CONSUMER_LIMIT','per UID count bound')
        st=call(h,'state-for-reset',b,'status')
        for i in range(31):
            st=call(h,f'reset-{i}',b,'reset',start='beginning',expected_revision=st['consumer']['revision'],reason=f'explicit reset {i}')
        h.check(call(h,'reset-history-limit',b,'reset',expected=3,start='now',expected_revision=st['consumer']['revision'],reason='over limit')['code']=='CONSUMER_HISTORY_LIMIT','finite adoption history')
        h.run('strict-compact',['compact','--control',str(d.control)]);d.shutdown()
        d=h.start('strict-restart',bc,b);after=call(h,'strict-replay-state',b,'status')
        h.check(len(after['consumer']['adoptions'])==32,'all bounded resets survive compaction and restart')
        d.shutdown()
    case('strict_protocol_capacity_and_empty_poll',strict)

    def replay():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'replay')
        first=send(h,'first',a,'A');send(h,'hidden',c,'C')
        call(h,'create-one',b,'create',limit=1,payload='yes',reason='application one')
        call(h,'create-two',b,'create','other',limit=1,payload='yes',reason='application two')
        page=call(h,'first-read',b,'read');token=page['consumer']['pending_batch']['id']
        material=','.join(json.dumps(row,separators=(',',':'),ensure_ascii=False) for row in page['records']).encode()
        h.check(hashlib.sha256(b'NATRAV_OVERLAY_CONSUMER_PAGE_V1\0'+material).hexdigest()==page['consumer']['pending_batch']['rows_digest'],'independent bounded page digest reconstruction')
        other=call(h,'other-read',b,'read','other');other_token=other['consumer']['pending_batch']['id']
        h.check(page['records'][0]['operation_id']==first and token!=other_token,'separate durable page identities')
        h.check(call(h,'forged-ack',b,'ack',expected=3,batch=operation('not-issued'))['code']=='CONSUMER_ACK_INVALID','forged advancement denied')
        h.check(call(h,'cross-consumer-ack',b,'ack',expected=3,batch=other_token)['code']=='CONSUMER_ACK_INVALID','cross-consumer boundary denied')
        second=send(h,'second',a,'A')
        correction=operation('correction');revise(h,'correction',ad.control,'A','B','query/series',correction,first,'corrected');wait_state(h,a,correction,'ACKED','corrected-ack')
        re=call(h,'replayed-first',b,'read')
        h.check(re['records']==page['records'] and re['consumer']['pending_batch']==page['consumer']['pending_batch'],'lost read returns exact issued page despite append/correction')
        before=(b/'state.journal').read_bytes();call(h,'replay-read-again',b,'read')
        h.check((b/'state.journal').read_bytes()==before,'read replay appends no state')
        ack=call(h,'ack-first',b,'ack',batch=token)
        h.check(ack['consumer']['acknowledged_sequence']==1,'only ack commits progress')
        before=(b/'state.journal').read_bytes();dup=call(h,'duplicate-ack',b,'ack',batch=token)
        h.check(dup['disposition']=='ALREADY_ACKNOWLEDGED' and (b/'state.journal').read_bytes()==before,'lost ack response is idempotent and observational')
        page2=call(h,'read-second',b,'read');h.check(page2['records'][0]['operation_id']==second,'contiguous visible history')
        h.run('replay-compact',['compact','--control',str(bd.control)]);bd.shutdown();bd=h.start('replay-restart',bc,b)
        replay2=call(h,'read-after-restart',b,'read')
        h.check(replay2['records']==page2['records'] and replay2['consumer']['pending_batch']==page2['consumer']['pending_batch'],'issued page persists through checkpoint restart')
        call(h,'ack-after-restart',b,'ack',batch=page2['consumer']['pending_batch']['id'])
        corr=call(h,'read-correction',b,'read');h.check(corr['records'][0]['operation_id']==correction and corr['records'][0]['corrects']==first,'correction is next immutable admission')
        before_reset=corr['consumer'];reset=call(h,'explicit-replay-reset',b,'reset',start='beginning',expected_revision=before_reset['revision'],reason='rebuild application projection')
        h.check(reset['consumer']['acknowledged_sequence']==0 and reset['consumer']['epoch']==2,'explicit reset adopts new epoch')
        h.check(call(h,'old-batch-after-reset',b,'ack',expected=3,batch=corr['consumer']['pending_batch']['id'])['code']=='CONSUMER_ACK_INVALID','reset invalidates abandoned issue')
        st=call(h,'reset-provenance',b,'status')
        h.check(st['consumer']['adoptions'][-1]['abandoned_batch']==corr['consumer']['pending_batch']['id'],'reset records abandoned unacked work')
        h.check(call(h,'old-reset-revision',b,'reset',expected=3,start='now',expected_revision=before_reset['revision'],reason='repeat reset')['code']=='CONSUMER_REVISION_CONFLICT','reset compare-and-swap avoids lost-response double reset')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('issued_pages_ack_replay_restart_and_reset',replay)

    def principals():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'principals',True);send(h,'principal-evidence',a,'A')
        expose_control_for_uid(b)
        own=call(h,'owner-register',b,'create',reason='owner consumer')
        delegated=call(h,'delegated-register',b,'create',uid=UID,reason='delegated metadata application')
        h.check(delegated['consumer']['instance']!=own['consumer']['instance'],'same names are separate UID namespaces')
        page=call(h,'delegated-read',b,'read',uid=UID)
        other=call(h,'owner-page',b,'read')
        h.check(call(h,'delegated-cross-owner-ack',b,'ack',expected=3,uid=UID,batch=other['consumer']['pending_batch']['id'])['code']=='CONSUMER_ACK_INVALID','issued ID alone is not authority')
        h.check(call(h,'delegated-payload-create',b,'create','payload',expected=3,uid=UID,payload='yes',reason='not granted')['code']=='LOCAL_CONTROL_CLASS_DENIED','metadata consumer cannot gain payloads')
        h.check(call(h,'delegated-reset-denied',b,'reset',expected=3,uid=UID,start='now',expected_revision=page['consumer']['revision'],reason='not an administrator')['code']=='LOCAL_CONTROL_CLASS_DENIED','reset has separate command grant')
        changed=candidate(h,bc,'expanded-authority','expanded-authority-g1',lambda s:s+f'evidence_read={os.geteuid()},C,query/series,METADATA\n')
        activate(h,'activate-expanded',b,changed)
        h.check(call(h,'frozen-owner-read',b,'read',expected=3)['code']=='CONSUMER_POLICY_CHANGED','changed union cannot reinterpret numeric progress')
        h.check(call(h,'frozen-owner-ack',b,'ack',expected=3,batch=other['consumer']['pending_batch']['id'])['code']=='CONSUMER_POLICY_CHANGED','ack reauthorizes stored contract')
        replay=call(h,'unaffected-delegated',b,'read',uid=UID)
        h.check(replay['consumer']['pending_batch']==page['consumer']['pending_batch'],'unrelated UID policy changes do not freeze this principal')
        frozen=call(h,'frozen-status',b,'status');h.check(frozen['policy_changed'],'owner can inspect its frozen consumer metadata')
        call(h,'readopt-expanded',b,'reset',start='now',expected_revision=frozen['consumer']['revision'],reason='explicitly adopt expanded authority')
        send(h,'visible-in-new-domain',c,'C');new=call(h,'read-expanded-domain',b,'read')
        h.check(new['records'][0]['issuer']=='C','new epoch uses deliberately adopted union')
        revoked=candidate(h,changed,'revoke-delegated','revoke-delegated-g1',lambda s:'\n'.join(l for l in s.splitlines() if not l.startswith(f'evidence_read={UID},') and not l.startswith(f'local_control={UID},'))+'\n')
        # Actual delegated process opens the socket and only sends half its ACK.
        partial=wire(3,'worker',bytes.fromhex(page['consumer']['pending_batch']['id']))
        program='import socket,struct,sys; s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM); s.connect(sys.argv[1]); b=bytes.fromhex(sys.argv[2]); s.sendall(struct.pack("!I",len(b))+b[:5]); print("READY",flush=True); sys.stdin.readline(); s.sendall(b[5:]); data=b"";\nwhile True:\n t=s.recv(65536)\n if not t:break\n data+=t\nprint(data.hex(),flush=True)'
        slow=subprocess.Popen(['setpriv',f'--reuid={UID}',f'--regid={UID}','--clear-groups',os.sys.executable,'-c',program,str(bd.control),partial.hex()],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        h.check(slow.stdout.readline().strip()=='READY','real UID slow ACK connection established')
        activate(h,'revoke-delegated',b,revoked)
        output,error=slow.communicate('go\n',timeout=5)
        h.check(slow.returncode==0 and b'LOCAL_CONTROL_CLASS_DENIED' in bytes.fromhex(output.strip()),'slow ACK is reauthorized after request decoding under revoked configuration')
        h.check(call(h,'revoked-ack',b,'ack',expected=3,uid=UID,batch=page['consumer']['pending_batch']['id'])['code']=='LOCAL_CONTROL_UID_DENIED','revoked kernel principal cannot acknowledge')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('kernel_principals_and_policy_readoption',principals)

    def concurrent_case():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'concurrent');op=send(h,'concurrent-one',a,'A')
        call(h,'concurrent-create',b,'create',reason='shared application worker')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            pages=list(pool.map(lambda i:call(h,f'parallel-read-{i}',b,'read'),range(8)))
        ids={p['consumer']['pending_batch']['id'] for p in pages}
        h.check(len(ids)==1 and all(p['records'][0]['operation_id']==op for p in pages),'one durable outstanding page under concurrent reads')
        token=ids.pop()
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            acks=list(pool.map(lambda i:call(h,f'parallel-ack-{i}',b,'ack',batch=token),range(8)))
        h.check(sum(p['disposition']=='ACKNOWLEDGED' for p in acks)==1,'one winner commits concurrent acknowledgment')
        st=call(h,'parallel-status',b,'status');h.check(st['consumer']['acknowledgments']==1 and st['consumer']['acknowledged_sequence']==1,'no multiply advanced consumption')
        # Actual lost read response: request fully transmitted, client disappears.
        send(h,'lost-read-evidence',a,'A')
        s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);s.connect(str(bd.control));body=wire(2,'worker');s.sendall(struct.pack('!I',len(body))+body);s.close()
        h.wait('lost read committed',lambda:call(h,'lost-read-check',b,'status')['consumer']['pending_batch'] is not None)
        replay=call(h,'lost-read-replay',b,'read');h.check(replay['disposition']=='REPLAY' and len(replay['records'])==1,'closed client does not silently consume or lose page')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('concurrent_read_ack_and_lost_response',concurrent_case)

    def maintenance():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'maintenance')
        first=send(h,'maintenance-first',a,'A');second=send(h,'maintenance-second',a,'A')
        call(h,'maintenance-create',b,'create',limit=1,payload='yes',reason='projection progress')
        page=call(h,'maintenance-read-first',b,'read');call(h,'maintenance-ack-first',b,'ack',batch=page['consumer']['pending_batch']['id'])
        pending=call(h,'maintenance-read-second',b,'read');bd.shutdown()
        keys=h.runtime/'consumer-keys';keys.mkdir(mode=0o700);key=new_key(h,keys,'consumer-state-g1');migrate(h,'consumer-migrate',b,key,'B')
        bd=start_keyed(h,'consumer-keyed',bc,b,key)
        call(h,'keyed-extra-consumer',b,'create','audit-worker',start='now',reason='exercise keyed consumer records')
        bd.shutdown()
        audit=h.run('consumer-keyed-audit',['state-auth-audit','--state',str(b),'--node','B','--state-auth-key',str(key)])
        h.check(audit['status']=='COMPLETE','auditor replays newly appended keyed consumer updates')
        bd=start_keyed(h,'consumer-keyed-again',bc,b,key)
        h.run('consumer-compact',['compact','--control',str(bd.control)]);bd.shutdown()
        crypt=keys/'backup.key';archive=keys/'backup.nob';identity=h.identity('B')
        h.run('consumer-backup-key',['backup-key-init','--output',str(crypt),'--generation','consumer-backup-g1'])
        h.run('consumer-export',['backup-export','--state',str(b),'--node','B','--generation','b-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        before=h.run('consumer-offline-before',['inspect','--state',str(b),'--node','B','--state-auth-key',str(key)])
        restored=h.runtime/'consumer-restored'
        h.run('consumer-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','B','--generation','b-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=h.run('consumer-offline-restored',['inspect','--state',str(restored),'--node','B','--state-auth-key',str(key)])
        h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'exact offline logical equality through authenticated encrypted restore')
        relocated=candidate(h,bc,'consumer-relocated','consumer-relocated-g1',lambda s:s.replace(f'state={b}',f'state={restored}'))
        h.run('consumer-relocate',['state-relocate','--state',str(restored),'--node','B','--candidate',str(relocated),'--reason','verified consumer relocation','--state-auth-key',str(key)])
        bd=start_keyed(h,'consumer-restored',relocated,restored,key)
        replay=call(h,'consumer-restored-page',restored,'read')
        h.check(replay['records']==pending['records'] and replay['consumer']['pending_batch']==pending['consumer']['pending_batch'],'durable issued boundary survives relocation without re-reading first record')
        call(h,'consumer-restored-ack',restored,'ack',batch=pending['consumer']['pending_batch']['id'])
        new=send(h,'consumer-new-delivery',a,'A');next_page=call(h,'consumer-new-page',restored,'read')
        h.check([r['operation_id'] for r in next_page['records']]==[new] and next_page['consumer']['acknowledged_sequence']==2,'post-restore real delivery continues at saved progress')
        h.run('consumer-restored-compact',['compact','--control',str(bd.control)])
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('keyed_checkpoint_encrypted_restore_and_relocation',maintenance)

    def kills():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'kills');send(h,'kill-evidence',a,'A');call(h,'kill-create',b,'create',reason='durable acknowledgment')
        issued=call(h,'kill-read',b,'read');token=issued['consumer']['pending_batch']['id'];bd.shutdown()
        for phase,expected_position in [('BEFORE',0),('AFTER',1)]:
            env={f'NATRAV_OVERLAY_TEST_CONSUMER_ACK_{phase}_COMMIT_MS':'20000'}
            bd=h.start('kill-'+phase,bc,b,env);initial=(b/'state.journal').stat().st_size
            client=subprocess.Popen([str(h.binary),*args(b,'ack',batch=token)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            try:
                if phase=='AFTER':h.wait('ack commit grows journal',lambda:(b/'state.journal').stat().st_size>initial,timeout=5)
                else:time.sleep(0.4)
                bd.kill();client.communicate(timeout=5)
            finally:
                if client.poll() is None:client.kill();client.communicate()
            bd=h.start('after-kill-'+phase,bc,b);st=call(h,'reconstructed-'+phase,b,'status')
            h.check(st['consumer']['acknowledged_sequence']==expected_position,'deterministic '+phase+' synchronized ack boundary')
            if phase=='BEFORE':h.check(call(h,'replay-after-precommit-kill',b,'read')['consumer']['pending_batch']['id']==token,'precommit kill preserves issued page')
            else:h.check(call(h,'repeat-ack-after-postcommit-kill',b,'ack',batch=token)['disposition']=='ALREADY_ACKNOWLEDGED','postcommit lost response resolves idempotently')
            bd.shutdown()
        cd.shutdown();ad.shutdown()
    case('hard_kill_ack_commit_boundaries',kills)

    def corruption():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'corrupt');send(h,'corrupt-first',a,'A');send(h,'corrupt-second',a,'A')
        call(h,'corrupt-register',b,'create',limit=1,reason='semantic replay checks')
        first=call(h,'corrupt-read',b,'read');call(h,'corrupt-ack',b,'ack',batch=first['consumer']['pending_batch']['id'])
        bd.shutdown();journal=b/'state.journal';original=journal.read_bytes()
        frames=[];off=0
        while off<len(original):
            n=struct.unpack_from('!I',original,off+4)[0];frames.append((off,n,original[off+8:off+8+n]));off+=40+n
        updates=[f for f in frames if f[2][0]==27]
        h.check(len(updates)==3,'three independently identified native consumer transitions')
        def rewrite(index: int,mutate: Any):
            offset,n,body=updates[index];body=bytearray(body);mutate(body)
            # Existing journal checksum is domain-separated; obtain exact format from independent fixture support.
            domain=b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'
            checksum=hashlib.sha256(domain+body).digest()
            h.check(checksum==original[offset+8+n:offset+40+n] if bytes(body)==updates[index][2] else True,'independent checksum domain')
            return original[:offset+8]+body+checksum+original[offset+40+n:]
        # Locate current position after fixed name/UID/instance/selection/revision.
        def position_offset(body: bytearray)->int:
            cursor=1+4;n=struct.unpack_from('!H',body,cursor)[0];cursor+=2+n+4+32
            n=struct.unpack_from('!I',body,cursor)[0];cursor+=4+n+8
            return cursor
        # First confirm the independent checksum calculation before changing bytes.
        h.check(rewrite(2,lambda b:None)==original,'independent writer preserves exact checksum')
        def advance(body: bytearray):
            off=position_offset(body);struct.pack_into('!Q',body,off,2)
        journal.write_bytes(rewrite(2,advance))
        h.check(h.run('semantic-consumer-overadvance',['inspect','--state',str(b),'--node','B'],expected=3)['code']=='JOURNAL_CORRUPT','recomputed checksum cannot authorize advancement beyond issued page')
        journal.write_bytes(original)
        # Delete ISSUE but retain ACK: no issued receipt may be reconstructed.
        off,n,_=updates[1];journal.write_bytes(original[:off]+original[off+40+n:])
        h.check(h.run('semantic-consumer-missing-issue',['inspect','--state',str(b),'--node','B'],expected=3)['code']=='JOURNAL_CORRUPT','ACK cannot replay without its issuance')
        journal.write_bytes(original)
        bd=h.start('corrupt-restored',bc,b);h.run('consumer-corruption-compact',['compact','--control',str(bd.control)]);bd.shutdown()
        compact=journal.read_bytes()
        # The instance survives canonical checkpoint serialization; no object deletion by omission is accepted if digest unchanged.
        state=h.run('consumer-corruption-inspect',['inspect','--state',str(b),'--node','B'])
        h.check(state['consumers'][0]['acknowledged_sequence']==1,'original remains reconstructable after rejected mutations')
        cd.shutdown();ad.shutdown()
    case('semantic_consumer_journal_corruption',corruption)

    def large():
        state,allrows=fixture(h,'large-consumer',65540,17,hidden=3001)
        port=free_port();cfg=config(h,'large-consumer',state,port)
        cfg.write_text(cfg.read_text().replace('deadline_ms=2000','deadline_ms=20000'))
        d=Daemon(h,'large-consumer',cfg,state,readiness_timeout=30);h.daemons.append(d);d.start()
        tail=call(h,'large-tail-register',state,'create',start='now',limit=128,reason='explicitly skip retained history')
        h.check(tail['consumer']['acknowledged_sequence']==sum(r['issuer']=='A' for r in allrows),'tail adopts only authorized history without hashing')
        before=(state/'state.journal').read_bytes();times=[]
        for i in range(32):
            start=time.perf_counter();p=call(h,f'large-empty-{i}',state,'read');times.append(time.perf_counter()-start)
            h.check(p['feed_work']['index_records_visited']==0,'large empty poll has no history record visits')
        h.check((state/'state.journal').read_bytes()==before,'large empty polls do not create durable audit objects')
        a=h.runtime/'large-writer';ac=writer_config(h,'large-writer','A',a,free_port(),[('B',port)]);ad=h.start('large-writer',ac,a)
        op=send(h,'large-new',a,'A');page=call(h,'large-new-page',state,'read')
        h.check([r['operation_id'] for r in page['records']]==[op] and page['feed_work']['index_records_visited']==1,'new record read visits one rather than retained history')
        ack=call(h,'large-new-ack',state,'ack',batch=page['consumer']['pending_batch']['id']);position=ack['consumer']['acknowledged_sequence']
        d.shutdown();d=Daemon(h,'large-consumer-restarted',cfg,state,readiness_timeout=30);h.daemons.append(d);d.start()
        h.check(call(h,'large-restart-empty',state,'read')['consumer']['acknowledged_sequence']==position,'large durable position survives restart')
        (h.output/'LARGE-CONSUMER.json').write_text(json.dumps({'stored_records':len(allrows),'authorized_tail':tail['consumer']['acknowledged_sequence'],
            'empty_polls':32,'empty_record_visits':0,'new_page_record_visits':1,'new_page_validation_records':page['consumer_work']['validation_records_visited'],'ack_validation_records':ack['consumer_work']['validation_records_visited'],'final_position':position,'median_empty_cli_seconds':sorted(times)[16],
            'synthetic_stored_fixture_not_network_scale':True},indent=2)+'\n')
        ad.shutdown();d.shutdown()
    case('large_retained_history_tail_and_empty_work',large)

    def registry_capacity():
        b=h.runtime/'registry-capacity';bc=config(h,'registry-capacity',b,free_port())
        uids=list(range(60001,60009))
        text=bc.read_text()
        for uid in uids:
            text+=f'local_control={uid},EVIDENCE_READ,CONSUMER\nevidence_read={uid},A,query/series,METADATA\n'
        bc.write_text(text);d=h.start('registry-capacity',bc,b);expose_control_for_uid(b)
        for uid in [os.geteuid(),*uids[:7]]:
            for i in range(16):
                call(h,f'register-{uid}-{i}',b,'create',f'worker{i}',uid=uid if uid!=os.geteuid() else None,reason='exercise exact global bound')
        h.check(call(h,'global-first-excess',b,'create',expected=3,uid=uids[-1],reason='no remaining slot')['code']=='CONSUMER_LIMIT','129th consumer rejected at global cap')
        h.check(call(h,'existing-at-full-capacity',b,'create','worker0',reason='lost response retry at full capacity')['disposition']=='ALREADY_EXISTS','idempotent registration does not consume another slot')
        d.shutdown()
        inspected=h.run('full-consumer-inspection',['inspect','--state',str(b),'--node','B'])
        h.check(len(inspected['consumers'])==128,'all capacity slots reconstruct exactly')
        (h.output/'REGISTRY-CAPACITY.json').write_text(json.dumps({'registered':128,'per_uid':16,'kernel_uids_used':9,'first_excess_rejected':True},indent=2)+'\n')
    case('global_registry_capacity_real_uids',registry_capacity)


def main()->int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);start=time.time();success=False
    try:cases(h,set(a.case) if a.case else None);success=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {type(e).__name__}: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_DURABLE_CONSUMER_TESTS_V1','status':'PASS' if success else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,v in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:
            (h.output/(name+'.json')).write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if success else 1
if __name__=='__main__':raise SystemExit(main())
