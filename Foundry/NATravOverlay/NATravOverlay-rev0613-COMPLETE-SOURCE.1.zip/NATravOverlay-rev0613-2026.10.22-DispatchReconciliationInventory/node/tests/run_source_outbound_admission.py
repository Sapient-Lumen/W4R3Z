#!/usr/bin/env python3
"""Independent nested-source encoding corruption on owned native peer fixtures.

Every mutation re-encodes outer lengths and ordinary journal checksums. The
reader must reject the *inner* inconsistency without changing the owned journal.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
from run_persistent import Harness
from run_source_selectors import pair, compact, received, dump
from run_source_subscriptions import Reader, journal_frames
from run_subscription_validation import progress_layout, source_transaction
from run_local_evidence import author
from run_state_authentication import inspect, checksum_frame
from source_outbound_work import check_outbound_work


def layout(composite: bytes) -> dict:
    """Independent offsets for the existing evidence/policy formats."""
    encoded_length = int.from_bytes(composite[32:36], 'big')
    record = composite[36:36 + encoded_length]
    policy = composite[36 + encoded_length:]
    r = Reader(record)
    assert r.get(4) == b'NOA1'
    kind = r.number(1)
    assert kind in (1, 2)
    offsets = {'operation': r.i}; r.get(32)
    for name in ('issuer', 'recipient', 'scope'):
        length = r.number(2); offsets[name] = r.i; r.get(length)
    if kind == 2:
        offsets['parent'] = r.i; r.get(32)
    offsets['payload_length'] = r.i
    length = r.number(4); offsets['payload'] = r.i; r.get(length); r.eof()
    p = Reader(policy); po = {'operation': p.i}; p.get(32)
    for name, size in [('created', 8), ('expires', 8), ('attempts', 4), ('initial_backoff', 4), ('maximum_backoff', 4)]:
        po[name] = p.i; p.get(size)
    po['spki'] = p.i; p.get(32)
    length = p.number(2); po['generation'] = p.i; p.get(length); p.eof()
    return {'record': record, 'policy': policy, 'record_offsets': offsets, 'policy_offsets': po}


def variations(composite: bytes) -> dict[str, bytes]:
    decoded = layout(composite)
    record, policy = decoded['record'], decoded['policy']
    ro, po = decoded['record_offsets'], decoded['policy_offsets']
    def frame(r: bytes = record, p: bytes = policy, op: bytes = composite[:32]) -> bytes:
        return op + len(r).to_bytes(4, 'big') + r + p
    def flip(data: bytes, offset: int) -> bytes:
        changed = bytearray(data); changed[offset] ^= 1; return bytes(changed)
    result = {
        'empty-composite': b'',
        'truncated-composite-header': composite[:35],
        'trailing-composite': composite + b'\0',
        'wrong-composite-operation': frame(op=flip(composite[:32], 0)),
        'zero-record-length': composite[:32] + b'\0' * 4 + composite[36:],
        'overflow-record-length': composite[:32] + b'\xff' * 4 + composite[36:],
        'truncated-record': frame(r=record[:-1]),
        'trailing-record': frame(r=record+b'\0'),
        'bad-record-magic': frame(r=b'BAD1'+record[4:]),
        'wrong-record-kind': frame(r=record[:4]+b'\x03'+record[5:]),
        'empty-policy': frame(p=b''),
        'truncated-policy': frame(p=policy[:-1]),
        'zero-policy-attempts': frame(p=policy[:po['attempts']]+b'\0'*4+policy[po['attempts']+4:]),
    }
    for field in ('operation', 'issuer', 'recipient', 'scope', 'payload_length', 'payload', 'parent'):
        if field in ro: result['changed-record-'+field] = frame(r=flip(record, ro[field]))
    for field in ('operation', 'created', 'expires', 'initial_backoff', 'maximum_backoff', 'spki', 'generation'):
        result['changed-policy-'+field] = frame(p=flip(policy, po[field]))
    return result


def run_cases(h: Harness, mode: str) -> None:
    def inner_replay() -> None:
        a,c,pa,pc,ad,cd = pair(h, 'inner', 8)
        original = author(h, 'inner-original', a, value='owned original')['operation_id']
        author(h, 'inner-correction', a, value='owned correction', parent=original)
        sub = compact(h, 'inner-create', a, 'create')
        for i in range(2):
            issue = compact(h, f'inner-issue-{i}', a, 'step', previous=sub)
            sub = received(h, f'inner-ack-{i}', a, issue)
            check_outbound_work(h, issue['validation_work'], sub['validation_work'], mode)
        ad.shutdown(); cd.shutdown()
        frames = journal_frames(a/'state.journal')
        selected = [i for i,f in enumerate(frames) if f[8] == 32 and source_transaction(f)[:5] == b'NST3\x01']
        h.check(len(selected) == 2, 'real original and correction each commit one compact issuance')
        observations = []
        for ordinal, pos in enumerate(selected):
            encoded = source_transaction(frames[pos]); info = progress_layout(frames[pos])
            start, length_pos = int(info['outbox_offset']), int(info['outbox_length_offset'])
            original_inner = encoded[start:start+int(info['outbox_length'])]
            for label, inner in variations(original_inner).items():
                body = b'\x20' + encoded[:length_pos] + len(inner).to_bytes(4, 'big') + inner
                replacement = checksum_frame(b'NOJ1'+len(body).to_bytes(4, 'big')+body+b'\0'*32)
                changed = frames.copy(); changed[pos] = replacement; journal = b''.join(changed)
                target = h.runtime/f'reject-{ordinal}-{label}'
                shutil.copytree(a,target); (target/'state.journal').write_bytes(journal)
                result = inspect(h,f'reject-{ordinal}-{label}',target,expected=3)
                h.check(result['code'] == 'JOURNAL_CORRUPT', 'strict independent nested replay rejects '+label)
                h.check((target/'state.journal').read_bytes() == journal, 'rejected nested replay never changes original bytes')
                observations.append({'source_ordinal':ordinal+1,'mutation':label,'status':'REJECTED',
                                     'code':result['code'],'journal_sha256':hashlib.sha256(journal).hexdigest()})
        frozen = (a/'state.journal').read_bytes()
        h.check(inspect(h,'inner-original-still-valid',a)['source_subscriptions'][0]['acknowledged']==2,
                'unmodified journal remains independently readable')
        h.check((a/'state.journal').read_bytes()==frozen,'valid independent inspection is also read-only')
        dump(h,'INNER-REJECTIONS',observations)
    h.case('strict_inner_original_and_correction_replay', inner_replay)


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--binary',type=Path,required=True); p.add_argument('--output',type=Path,required=True)
    p.add_argument('--validation-mode',choices=('delta','copy-return','owned-outgoing','copy-store','reference','independent-outbound'),default='delta')
    args=p.parse_args()
    if args.output.exists():p.error('output must not exist')
    h=Harness(args.binary,args.output);start=time.time();ok=False
    try:
        run_cases(h,args.validation_mode);ok=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n')
        print(f'FAIL: {type(e).__name__}: {e}',file=os.sys.stderr)
    finally:
        h.cleanup()
        summary={'format':'NATRAV_OVERLAY_SOURCE_OUTBOUND_ADMISSION_TESTS_V1','status':'PASS' if ok else 'FAIL',
                 'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),
                 'cases_total':len(h.cases),'cases_passed':sum(x['status']=='PASS' for x in h.cases),
                 'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:dump(h,name,data)
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1

if __name__=='__main__':raise SystemExit(main())
