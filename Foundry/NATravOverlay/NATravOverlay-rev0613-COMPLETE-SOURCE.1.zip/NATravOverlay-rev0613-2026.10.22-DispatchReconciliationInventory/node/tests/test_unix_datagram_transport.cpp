#include "peer_session.hpp"
#include "protocol.hpp"
#include "socket.hpp"
#include "tls.hpp"
#include "transport.hpp"
#include "unix_datagram_transport.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstring>
#include <cstdlib>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <iostream>
#include <memory>
#include <optional>
#include <filesystem>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <poll.h>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/socket.h>
#include <thread>
#include <unistd.h>
#include <utility>
#include <variant>
#include <vector>

namespace {

using natrav_overlay::AppError;
using natrav_overlay::Deadline;
using natrav_overlay::DeliveryReceipt;
using natrav_overlay::EvidenceRecord;
using natrav_overlay::FramedReader;
using natrav_overlay::IoCounters;
using natrav_overlay::IoOptions;
using natrav_overlay::KeyGenerationState;
using natrav_overlay::OutboundPeerSession;
using natrav_overlay::PeerSessionFrame;
using natrav_overlay::PeerSessionFrameKind;
using natrav_overlay::PeerSessionLimits;
using natrav_overlay::ReceiptDisposition;
using natrav_overlay::TlsChannel;
using natrav_overlay::TlsContext;
using natrav_overlay::TlsIdentityFiles;
using natrav_overlay::TlsTrustedGeneration;
using natrav_overlay::TlsTrustedIdentity;
using natrav_overlay::TransportKind;
using natrav_overlay::TransportLocator;

struct CaseRecord final {
    std::string name;
    std::size_t assertions{0U};
};

class Probe final {
public:
    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_code(
        Function&& function,
        const std::string_view code,
        const std::string_view detail) {
        bool observed = false;
        try {
            std::forward<Function>(function)();
        } catch (const AppError& error) {
            observed = error.code() == code;
        }
        check(observed, detail);
    }

    template <typename Function>
    void run_case(std::string name, Function&& function) {
        const auto before = assertions_;
        std::forward<Function>(function)();
        cases_.push_back(CaseRecord{
            .name = std::move(name),
            .assertions = assertions_ - before,
        });
    }

    [[nodiscard]] std::size_t assertions() const noexcept { return assertions_; }
    [[nodiscard]] const std::vector<CaseRecord>& cases() const noexcept {
        return cases_;
    }

private:
    std::size_t assertions_{0U};
    std::vector<CaseRecord> cases_;
};

[[nodiscard]] Deadline test_deadline(
    const std::chrono::milliseconds duration = std::chrono::seconds(8)) {
    return std::chrono::steady_clock::now() + duration;
}

[[nodiscard]] TlsIdentityFiles identity(
    const char* certificate,
    const char* private_key,
    const char* pin) {
    return TlsIdentityFiles{
        .certificate = certificate,
        .private_key = private_key,
        .expected_spki_sha256 = natrav_overlay::parse_spki_sha256(pin),
    };
}

[[nodiscard]] datacube::Digest32 operation_id(const std::string_view label) {
    std::string input("NATRAV_UNIX_DATAGRAM_PACKET_CARRIER_TEST_OPERATION_V1");
    input.push_back('\0');
    input.append(label);
    return datacube::sha256(datacube::text_octets(input));
}

[[nodiscard]] EvidenceRecord record(
    const std::string_view label,
    const std::string_view payload) {
    return EvidenceRecord{
        .operation_id = operation_id(label),
        .issuer = "CLIENT",
        .recipient = "SERVER",
        .scope = "unix-dgram/session",
        .corrects = std::nullopt,
        .payload = datacube::text_octets(payload),
    };
}

class TempRoot final {
public:
    TempRoot() {
        std::array<char, 40U> pattern{};
        const std::string prefix = "/tmp/natrav-unix-dgram-XXXXXX";
        std::copy(prefix.begin(), prefix.end(), pattern.begin());
        char* created = ::mkdtemp(pattern.data());
        if (created == nullptr) {
            throw std::runtime_error("could not create Unix datagram test directory");
        }
        path_ = created;
        if (::chmod(path_.c_str(), S_IRWXU) != 0) {
            throw std::runtime_error("could not secure Unix datagram test directory");
        }
    }

    ~TempRoot() { std::filesystem::remove_all(path_); }
    TempRoot(const TempRoot&) = delete;
    TempRoot& operator=(const TempRoot&) = delete;

    [[nodiscard]] std::filesystem::path path() const { return path_; }

private:
    std::filesystem::path path_;
};

[[nodiscard]] std::string locator_text(
    const std::filesystem::path& local,
    const std::filesystem::path& remote,
    const std::uint16_t mtu = 512U,
    const std::string_view link = "5544585445535431",
    const std::uint32_t epoch = 7U) {
    return natrav_overlay::unix_datagram_transport_locator_text(
        natrav_overlay::UnixDatagramTransportLocator{
            .local_path = local.string(),
            .remote_path = remote.string(),
            .mtu = mtu,
            .link_id = [&] {
                std::uint64_t value = 0U;
                for (const char digit : link) {
                    const auto nibble = digit >= '0' && digit <= '9' ?
                        static_cast<std::uint8_t>(digit - '0') :
                        static_cast<std::uint8_t>(10 + digit - 'a');
                    value = (value << 4U) | static_cast<std::uint64_t>(nibble);
                }
                return value;
            }(),
            .epoch = epoch,
            .profile = 1U,
        });
}

[[nodiscard]] sockaddr_un unix_address(const std::filesystem::path& path) {
    const auto text = path.string();
    if (text.size() >= sizeof(sockaddr_un{}.sun_path)) {
        throw std::runtime_error("Unix test path exceeds sun_path");
    }
    sockaddr_un result{};
    result.sun_family = AF_UNIX;
    std::memcpy(result.sun_path, text.data(), text.size());
    result.sun_path[text.size()] = '\0';
    return result;
}

[[nodiscard]] socklen_t unix_address_length(const std::filesystem::path& path) {
    return static_cast<socklen_t>(
        offsetof(sockaddr_un, sun_path) + path.string().size() + 1U);
}

class RawUnixSender final {
public:
    explicit RawUnixSender(std::filesystem::path source)
        : source_(std::move(source)) {
        const int raw = ::socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
        if (raw < 0) {
            throw std::runtime_error("raw Unix datagram socket creation failed");
        }
        fd_ = datacube::Fd(raw);
        const auto address = unix_address(source_);
        if (::bind(
                fd_.get(), reinterpret_cast<const sockaddr*>(&address),
                unix_address_length(source_)) != 0 ||
            ::chmod(source_.c_str(), S_IRUSR | S_IWUSR) != 0) {
            throw std::runtime_error("raw Unix datagram source bind failed");
        }
    }

    ~RawUnixSender() {
        fd_.reset();
        static_cast<void>(::unlink(source_.c_str()));
    }
    RawUnixSender(const RawUnixSender&) = delete;
    RawUnixSender& operator=(const RawUnixSender&) = delete;

    void send(const std::filesystem::path& target, const std::size_t bytes) {
        std::vector<std::uint8_t> payload(bytes, 0x5aU);
        const auto address = unix_address(target);
        const ssize_t sent = ::sendto(
            fd_.get(), payload.data(), payload.size(), 0,
            reinterpret_cast<const sockaddr*>(&address),
            unix_address_length(target));
        if (sent < 0 || static_cast<std::size_t>(sent) != payload.size()) {
            throw std::runtime_error("raw Unix datagram send failed");
        }
    }

private:
    datacube::Fd fd_;
    std::filesystem::path source_;
};

void write_all(
    natrav_overlay::OrderedByteStream& stream,
    const std::span<const std::uint8_t> bytes,
    const Deadline deadline,
    IoCounters& counters) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto progress = stream.write_some(
            datacube::OctetView(bytes.data() + offset, bytes.size() - offset),
            deadline,
            counters,
            "Unix datagram ordered write");
        if (progress == 0U || progress > bytes.size() - offset) {
            throw std::runtime_error("Unix datagram ordered write made invalid progress");
        }
        offset += progress;
    }
}

[[nodiscard]] std::vector<std::uint8_t> read_exact(
    natrav_overlay::OrderedByteStream& stream,
    const std::size_t size,
    const Deadline deadline,
    IoCounters& counters) {
    std::vector<std::uint8_t> result(size);
    std::size_t offset = 0U;
    while (offset < result.size()) {
        const auto progress = stream.read_some(
            std::span<std::uint8_t>(result).subspan(offset),
            deadline,
            counters,
            "Unix datagram ordered read");
        if (progress == 0U || progress > result.size() - offset) {
            throw std::runtime_error("Unix datagram ordered read ended early");
        }
        offset += progress;
    }
    return result;
}

[[nodiscard]] std::unique_ptr<natrav_overlay::OrderedByteStream> accept_with_deadline(
    natrav_overlay::TransportListener& listener,
    const Deadline deadline) {
    while (std::chrono::steady_clock::now() < deadline) {
        const int handle = listener.readiness_handle();
        if (handle < 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(5));
            continue;
        }
        pollfd item{.fd = handle, .events = POLLIN, .revents = 0};
        const int result = ::poll(&item, 1U, 20);
        if (result < 0 && errno == EINTR) {
            continue;
        }
        if (result < 0) {
            throw std::runtime_error("Unix datagram listener poll failed");
        }
        if (result != 0 && (item.revents & POLLIN) != 0) {
            auto stream = listener.accept_ready();
            if (stream) {
                return stream;
            }
        }
    }
    throw std::runtime_error("Unix datagram listener did not become ready");
}

struct SessionRun final {
    std::array<DeliveryReceipt, 2U> receipts;
    std::size_t server_operations{0U};
    bool clean_close{false};
};

[[nodiscard]] SessionRun run_authenticated_session(
    const TransportLocator& client_locator,
    const TransportLocator& server_locator,
    const TlsIdentityFiles& client_identity,
    const TlsIdentityFiles& server_identity) {
    auto listener = natrav_overlay::listen_transport(server_locator, 4);
    TlsContext client_context(client_identity);
    TlsContext server_context(server_identity);
    const std::vector<TlsTrustedIdentity> trusted_client{{
        .node_id = "CLIENT",
        .generations = {TlsTrustedGeneration{
            .generation = "client-g1",
            .spki_sha256 = client_identity.expected_spki_sha256,
            .state = KeyGenerationState::active,
        }},
    }};
    const IoOptions io{
        .timeout = std::chrono::seconds(8),
        .read_quantum = 257U,
        .write_quantum = 251U,
        .maximum_received_bytes = 1'048'576U,
    };
    const PeerSessionLimits limits{
        .maximum_operations = 4U,
        .maximum_bytes = 1'048'576U,
        .maximum_lifetime_ms = 20'000U,
        .idle_timeout_ms = 8'000U,
    };
    const std::array<EvidenceRecord, 2U> records{
        record("session-one", "alpha over numeric UDP and finite packet reconstruction"),
        record("session-two", std::string(4'000U, 'b')),
    };

    std::size_t server_operations = 0U;
    bool server_clean_close = false;
    std::exception_ptr server_failure;
    std::thread server([&] {
        try {
            auto server_stream = accept_with_deadline(*listener, test_deadline());
            IoCounters server_tls;
            IoCounters server_io;
            const auto deadline = test_deadline();
            auto channel = TlsChannel::accept(
                server_context, *server_stream, trusted_client,
                deadline, server_tls);
            FramedReader reader(io);
            const auto hello = natrav_overlay::perform_server_handshake(
                channel, "SERVER", reader, deadline, io);
            if (hello.remote_artifact_digest !=
                natrav_overlay::node_artifact_digest("CLIENT")) {
                throw std::runtime_error("server HELLO identity mismatch");
            }
            const auto open = natrav_overlay::decode_peer_session_frame(
                reader.read_frame(channel, deadline, server_io));
            if (open.kind != PeerSessionFrameKind::open || !open.limits.has_value()) {
                throw std::runtime_error("server did not receive NOS1 OPEN");
            }
            const PeerSessionFrame acknowledgement{
                .kind = PeerSessionFrameKind::open_ack,
                .flags = 0U,
                .session_id = open.session_id,
                .sequence = 0U,
                .operation_id = {},
                .limits = *open.limits,
                .payload = {},
            };
            natrav_overlay::write_frame(
                channel,
                natrav_overlay::encode_peer_session_frame(acknowledgement),
                deadline,
                io,
                server_io);

            for (std::uint32_t sequence = 1U; sequence <= 2U; ++sequence) {
                const auto request = natrav_overlay::decode_peer_session_frame(
                    reader.read_frame(channel, deadline, server_io));
                if (request.kind != PeerSessionFrameKind::request ||
                    request.session_id != open.session_id ||
                    request.sequence != sequence) {
                    throw std::runtime_error("server request envelope mismatch");
                }
                const auto message = natrav_overlay::decode_application_message(
                    request.payload);
                const auto* evidence = std::get_if<EvidenceRecord>(&message);
                if (evidence == nullptr || evidence->operation_id != request.operation_id) {
                    throw std::runtime_error("server application binding mismatch");
                }
                ++server_operations;
                const DeliveryReceipt receipt{
                    .operation_id = evidence->operation_id,
                    .recipient = evidence->recipient,
                    .recorder = evidence->recipient,
                    .disposition = ReceiptDisposition::committed,
                    .sequence = sequence,
                    .record_digest = natrav_overlay::evidence_record_digest(*evidence),
                };
                const PeerSessionFrame response{
                    .kind = PeerSessionFrameKind::response,
                    .flags = 0U,
                    .session_id = open.session_id,
                    .sequence = sequence,
                    .operation_id = evidence->operation_id,
                    .limits = std::nullopt,
                    .payload = natrav_overlay::encode_application_message(receipt),
                };
                natrav_overlay::write_frame(
                    channel,
                    natrav_overlay::encode_peer_session_frame(response),
                    deadline,
                    io,
                    server_io);
            }

            const auto close = natrav_overlay::decode_peer_session_frame(
                reader.read_frame(channel, deadline, server_io));
            if (close.kind != PeerSessionFrameKind::close ||
                close.session_id != open.session_id || close.sequence != 3U) {
                throw std::runtime_error("server clean-close envelope mismatch");
            }
            const PeerSessionFrame close_ack{
                .kind = PeerSessionFrameKind::close_ack,
                .flags = 0U,
                .session_id = open.session_id,
                .sequence = close.sequence,
                .operation_id = {},
                .limits = std::nullopt,
                .payload = {},
            };
            natrav_overlay::write_frame(
                channel,
                natrav_overlay::encode_peer_session_frame(close_ack),
                deadline,
                io,
                server_io);
            std::array<std::uint8_t, 1U> eof{};
            if (channel.read_some(
                    eof, deadline, server_tls,
                    "server waits for UDP TLS close-notify") != 0U) {
                throw std::runtime_error("application bytes followed NOS1 close");
            }
            channel.close_notify(deadline, server_tls);
            server_clean_close = true;
        } catch (...) {
            server_failure = std::current_exception();
        }
    });

    std::array<DeliveryReceipt, 2U> receipts;
    bool client_clean_close = false;
    std::exception_ptr client_failure;
    try {
        IoCounters connect_counters;
        auto client_stream = natrav_overlay::connect_transport(
            client_locator, test_deadline(), connect_counters);
        auto session = OutboundPeerSession::open_connected(
            client_context,
            "CLIENT",
            "SERVER",
            "server-g1",
            KeyGenerationState::active,
            server_identity.expected_spki_sha256,
            std::move(client_stream),
            records[0U].operation_id,
            io,
            limits);
        receipts[0U] = session.exchange(records[0U], io);
        receipts[1U] = session.exchange(records[1U], io);
        client_clean_close = session.close_cleanly(io);
    } catch (...) {
        client_failure = std::current_exception();
    }
    server.join();
    if (client_failure) {
        std::rethrow_exception(client_failure);
    }
    if (server_failure) {
        std::rethrow_exception(server_failure);
    }
    if (!client_clean_close || !server_clean_close) {
        throw std::runtime_error("authenticated UDP session did not close cleanly");
    }
    return SessionRun{
        .receipts = receipts,
        .server_operations = server_operations,
        .clean_close = true,
    };
}

}  // namespace

int main(int argc, char* argv[]) {
    try {
        if (argc != 7) {
            throw std::runtime_error(
                "usage: test_unix_datagram_transport CLIENT_CERT CLIENT_KEY CLIENT_PIN SERVER_CERT SERVER_KEY SERVER_PIN");
        }
        const auto client_identity = identity(argv[1], argv[2], argv[3]);
        const auto server_identity = identity(argv[4], argv[5], argv[6]);
        Probe probe;
        TempRoot temp;
        const auto root = temp.path();

        probe.run_case("canonical owner-controlled locator and authority boundary", [&] {
            const auto local = root / "canonical-local.sock";
            const auto remote = root / "canonical-remote.sock";
            const auto text = locator_text(local, remote, 1200U);
            const auto locator =
                natrav_overlay::parse_unix_datagram_transport_locator(text);
            probe.check(locator.kind == TransportKind::unix_datagram,
                "unix-dgram-v1 selects the configured Unix datagram carrier");
            probe.check(natrav_overlay::transport_locator_text(locator) == text,
                "Unix datagram locator round-trips canonically");
            probe.check(
                natrav_overlay::parse_configured_transport_locator(text, false).kind ==
                    TransportKind::unix_datagram,
                "configured locator parser recognizes unix-dgram-v1");
            probe.check(
                natrav_overlay::parse_transport_kind("unix-dgram") ==
                    TransportKind::unix_datagram,
                "transport kind parser exposes explicit Unix datagrams");
            const auto capabilities = natrav_overlay::transport_capabilities(
                TransportKind::unix_datagram);
            probe.check(capabilities.reliable_stream && capabilities.ordered &&
                    capabilities.full_duplex && capabilities.can_dial &&
                    capabilities.can_listen && capabilities.can_shutdown_write,
                "finite packet service reconstructs an ordered full-duplex stream");
            auto leading_zero = text;
            const auto mtu = leading_zero.find("|mtu=1200|");
            leading_zero.replace(mtu, std::string("|mtu=1200|").size(), "|mtu=01200|");
            probe.expect_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::parse_unix_datagram_transport_locator(
                            leading_zero));
                },
                "UNIX_DATAGRAM_LOCATOR_NONCANONICAL",
                "numeric leading zeros are rejected as noncanonical");
            auto escaped = text;
            const auto local_field = escaped.find("canonical-local");
            escaped.replace(local_field, std::string("canonical").size(), "canonic%61l");
            probe.expect_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::parse_unix_datagram_transport_locator(
                            escaped));
                },
                "UNIX_DATAGRAM_LOCATOR_NONCANONICAL",
                "unnecessary path escapes are rejected as noncanonical");
            probe.expect_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::parse_unix_datagram_transport_locator(
                            "unix-dgram-v1|local=relative.sock|remote=/tmp/remote.sock|"
                            "mtu=512|link=5544585445535431|epoch=7|profile=1"));
                },
                "UNIX_DATAGRAM_LOCATOR_INVALID",
                "relative filesystem locators are rejected");
            probe.expect_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::parse_unix_datagram_transport_locator(
                            locator_text(local, local)));
                },
                "UNIX_DATAGRAM_PATH_ALIAS",
                "one filesystem coordinate cannot be both local and remote");
        });

        probe.run_case("parent symlink permission and stale-occupant controls", [&] {
            const auto real = root / "real";
            const auto unsafe = root / "unsafe";
            std::filesystem::create_directory(real);
            std::filesystem::create_directory(unsafe);
            ::chmod(real.c_str(), S_IRWXU);
            ::chmod(unsafe.c_str(), S_IRWXU | S_IRGRP | S_IXGRP);
            const auto link = root / "link";
            std::filesystem::create_directory_symlink(real, link);

            probe.expect_code(
                [&] {
                    const auto locator =
                        natrav_overlay::parse_unix_datagram_transport_locator(
                            locator_text(link / "local.sock", real / "remote.sock"));
                    static_cast<void>(natrav_overlay::listen_transport(locator, 4));
                },
                "UNIX_DATAGRAM_PARENT_INVALID",
                "symlink path components are rejected before bind");
            probe.expect_code(
                [&] {
                    const auto locator =
                        natrav_overlay::parse_unix_datagram_transport_locator(
                            locator_text(unsafe / "local.sock", real / "remote.sock"));
                    static_cast<void>(natrav_overlay::listen_transport(locator, 4));
                },
                "UNIX_DATAGRAM_PARENT_UNSAFE",
                "group-accessible parent directories are rejected");

            const auto occupied = real / "occupied.sock";
            RawUnixSender occupant(occupied);
            const auto locator =
                natrav_overlay::parse_unix_datagram_transport_locator(
                    locator_text(occupied, real / "remote.sock"));
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::listen_transport(locator, 4));
                },
                "UNIX_DATAGRAM_PATH_OCCUPIED",
                "pre-existing socket nodes are never unlinked as guessed stale state");
            probe.check(std::filesystem::exists(occupied),
                "failed bind leaves the pre-existing socket object untouched");
        });

        probe.run_case("fragmented ordered bytes listener lease cleanup and semantic finish", [&] {
            const auto client_path = root / "stream-client.sock";
            const auto server_path = root / "stream-server.sock";
            const auto client_locator =
                natrav_overlay::parse_unix_datagram_transport_locator(
                    locator_text(client_path, server_path));
            const auto server_locator =
                natrav_overlay::parse_unix_datagram_transport_locator(
                    locator_text(server_path, client_path));
            auto listener = natrav_overlay::listen_transport(server_locator, 4);
            IoCounters connect_counters;
            auto client = natrav_overlay::connect_transport(
                client_locator, test_deadline(), connect_counters);
            std::vector<std::uint8_t> payload(50'000U);
            for (std::size_t index = 0U; index < payload.size(); ++index) {
                payload[index] = static_cast<std::uint8_t>((index * 29U + 7U) & 0xffU);
            }
            IoCounters client_io;
            write_all(*client, payload, test_deadline(), client_io);
            auto server = accept_with_deadline(*listener, test_deadline());
            probe.check(server->transport_kind() == TransportKind::unix_datagram &&
                            listener->readiness_handle() == -1,
                "accepted packet stream owns the one configured Unix listener lease");
            IoCounters server_io;
            const std::vector<std::uint8_t> response(4'097U, 0xa5U);
            std::vector<std::uint8_t> received;
            std::exception_ptr server_failure;
            std::thread server_worker([&] {
                try {
                    received = read_exact(
                        *server, payload.size(), test_deadline(), server_io);
                    write_all(*server, response, test_deadline(), server_io);
                } catch (...) {
                    server_failure = std::current_exception();
                }
            });
            const auto client_response = read_exact(
                *client, response.size(), test_deadline(), client_io);
            server_worker.join();
            if (server_failure) {
                std::rethrow_exception(server_failure);
            }
            probe.check(
                received == payload,
                "finite fragmentation and reassembly preserve ordered application bytes");
            probe.check(
                client_response == response,
                "the fixed Unix datagram pair remains full duplex");
            client->shutdown_write();
            std::array<std::uint8_t, 1U> eof{};
            probe.check(server->read_some(
                    eof, test_deadline(), server_io,
                    "Unix datagram finish receive") == 0U,
                "finite packet FIN becomes ordered-stream EOF");
            server.reset();
            client.reset();
            probe.check(!std::filesystem::exists(client_path),
                "outbound destruction removes only its owned local socket path");
            std::this_thread::sleep_for(std::chrono::milliseconds(120));
            probe.check(listener->readiness_handle() >= 0 &&
                    std::filesystem::exists(server_path),
                "listener reopens its exact path after lease destruction");
        });

        probe.run_case("unauthorized source path is drained without learning", [&] {
            const auto client_path = root / "filter-client.sock";
            const auto server_path = root / "filter-server.sock";
            const auto attacker_path = root / "filter-attacker.sock";
            const auto server_locator =
                natrav_overlay::parse_unix_datagram_transport_locator(
                    locator_text(server_path, client_path));
            auto listener = natrav_overlay::listen_transport(server_locator, 4);
            RawUnixSender attacker(attacker_path);
            attacker.send(server_path, 64U);
            pollfd ready{.fd = listener->readiness_handle(), .events = POLLIN, .revents = 0};
            probe.check(::poll(&ready, 1U, 100) == 1,
                "an unauthorized datagram is visible only to bounded listener filtering");
            probe.check(!listener->accept_ready(),
                "an unconfigured source path cannot create a session");

            const auto client_locator =
                natrav_overlay::parse_unix_datagram_transport_locator(
                    locator_text(client_path, server_path));
            IoCounters counters;
            auto client = natrav_overlay::connect_transport(
                client_locator, test_deadline(), counters);
            const std::array<std::uint8_t, 1U> byte{0x42U};
            static_cast<void>(client->write_some(
                byte, test_deadline(), counters, "source-filter trigger"));
            auto accepted = accept_with_deadline(*listener, test_deadline());
            probe.check(accepted->transport_kind() == TransportKind::unix_datagram,
                "the exact configured source path can activate the listener");
        });

        probe.run_case("oversize datagrams are rejected rather than truncated", [&] {
            const auto client_path = root / "trunc-client.sock";
            const auto server_path = root / "trunc-server.sock";
            const auto server_locator =
                natrav_overlay::parse_unix_datagram_transport_locator(
                    locator_text(server_path, client_path, 256U));
            auto listener = natrav_overlay::listen_transport(server_locator, 4);
            RawUnixSender sender(client_path);
            sender.send(server_path, 400U);
            auto accepted = accept_with_deadline(*listener, test_deadline());
            IoCounters counters;
            std::array<std::uint8_t, 1U> byte{};
            probe.expect_code(
                [&] {
                    static_cast<void>(accepted->read_some(
                        byte, test_deadline(), counters,
                        "Unix datagram truncation probe"));
                },
                "UNIX_DATAGRAM_TRUNCATED",
                "recvmsg MSG_TRUNC becomes an explicit carrier error");
        });

        probe.run_case("deadlines local ownership and replacement-safe cleanup", [&] {
            const auto client_path = root / "ownership-client.sock";
            const auto server_path = root / "ownership-server.sock";
            const auto client_locator =
                natrav_overlay::parse_unix_datagram_transport_locator(
                    locator_text(client_path, server_path));
            const auto server_locator =
                natrav_overlay::parse_unix_datagram_transport_locator(
                    locator_text(server_path, client_path));
            auto listener = natrav_overlay::listen_transport(server_locator, 4);
            IoCounters first_counters;
            auto first = natrav_overlay::connect_transport(
                client_locator, test_deadline(), first_counters);
            IoCounters duplicate_counters;
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::connect_transport(
                        client_locator, test_deadline(), duplicate_counters));
                },
                "UNIX_DATAGRAM_PATH_OCCUPIED",
                "one process cannot silently alias an owned local socket path");
            const std::array<std::uint8_t, 1U> trigger{0x13U};
            static_cast<void>(first->write_some(
                trigger, test_deadline(), first_counters,
                "ownership listener trigger"));
            auto accepted = accept_with_deadline(*listener, test_deadline());
            std::array<std::uint8_t, 1U> byte{};
            probe.expect_code(
                [&] {
                    static_cast<void>(first->read_some(
                        byte,
                        test_deadline(std::chrono::milliseconds(40)),
                        first_counters,
                        "Unix datagram idle timeout"));
                },
                "IO_TIMEOUT",
                "idle packet stream obeys the caller absolute deadline");

            if (::unlink(client_path.c_str()) != 0) {
                throw std::runtime_error("could not replace owned Unix datagram path");
            }
            RawUnixSender replacement(client_path);
            probe.expect_code(
                [&] {
                    static_cast<void>(first->read_some(
                        byte, test_deadline(), first_counters,
                        "Unix datagram replacement probe"));
                },
                "UNIX_DATAGRAM_PATH_REPLACED",
                "path replacement is detected before further carrier progress");
            first.reset();
            probe.check(std::filesystem::exists(client_path),
                "destruction never unlinks a replacement socket it did not create");
            accepted.reset();
        });

        probe.run_case("real TLS HELLO NOS1 operations receipts and close", [&] {
            const auto client_path = root / "tls-client.sock";
            const auto server_path = root / "tls-server.sock";
            const auto client_locator =
                natrav_overlay::parse_unix_datagram_transport_locator(
                    locator_text(client_path, server_path, 1200U));
            const auto server_locator =
                natrav_overlay::parse_unix_datagram_transport_locator(
                    locator_text(server_path, client_path, 1200U));
            const auto run = run_authenticated_session(
                client_locator, server_locator, client_identity, server_identity);
            probe.check(run.clean_close,
                "real authenticated Unix datagram session closes with NOS1 and TLS close-notify");
            probe.check(run.server_operations == 2U,
                "one reusable Unix datagram session carries two operations");
            probe.check(
                run.receipts[0U].disposition == ReceiptDisposition::committed &&
                    run.receipts[1U].sequence == 2U,
                "receipts remain bound above filesystem and packet metadata");
        });

        std::cout << "{\"format\":\"NATRAV_UNIX_DATAGRAM_TRANSPORT_PROBE_V1\","
                  << "\"status\":\"PASS\",\"cases\":[";
        for (std::size_t index = 0U; index < probe.cases().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            const auto& item = probe.cases()[index];
            std::cout << "{\"name\":" << natrav_overlay::json_string(item.name)
                      << ",\"assertions\":" << item.assertions << '}';
        }
        std::cout << "],\"assertions\":" << probe.assertions() << "}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
