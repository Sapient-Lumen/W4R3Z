#!/usr/bin/env python3
"""Exact pending reservations, real quota races, and representation reconstruction.
Large background history is independent synthetic retained state, not network load.
"""
from __future__ import annotations
import argparse,concurrent.futures,hashlib,json,os,subprocess,time
from pathlib import Path
from run_persistent import Harness,operation
from run_delivery_selection import fixture,topology
from run_submission_responses import issue,arguments
from run_outbox_inspection import setup,query,wait_outcome
from run_conditional_outbox import selection,apply
from run_live_configuration import candidate,activate
from run_state_authentication import new_key,migrate,start as start_keyed,inspect


def usage(h,label,a,records,bytes_):
    v=h.status(label,a)['outbox']['reservations']
    h.check(v['pending_records']==records and v['pending_payload_bytes']==bytes_,label+' exact global pending count/bytes')
    return v


def cases(h,selected):
    def case(name,fn):
        if not selected or name in selected:h.case(name,fn)
    def large():
        a,_,_=fixture(h,'capacity-large',unrelated=8192,settled=4096,ready_b=0)
        ac,bc,cc,ad,bd,cd,b,c=topology(h,'capacity-large',a,large=True)
        small=issue(h,'capacity-small',a,peer='C',text='x'*17)
        p=h.work/'maximum.bin';p.write_bytes(bytes(range(256))*234+bytes(range(96)))
        big=issue(h,'capacity-large-payload',a,peer='B',payload=p)
        duplicate=issue(h,'capacity-duplicate',a,peer='B',payload=p,op=big['operation_id'])
        for r in (small,big):
            w=r['work'];h.check(w['capacity_records_visited']==0 and w['capacity_aggregate_reads']==2,'one global and one peer aggregate read, zero retained-record visits')
            h.check(w['capacity_entries_touched']==2 and w['capacity_acquires']==1 and w['capacity_releases']==0,'queue-plus-policy touches but charges once')
        h.check(duplicate['work']['capacity_aggregate_reads']==0 and duplicate['work']['capacity_acquires']==0,'exact duplicate performs no capacity admission or charge')
        usage(h,'capacity-large-both',a,2,60017)
        row,cfg=selection(h,'capacity-cancel-select',a,small['operation_id']);apply(h,'capacity-cancel',a,'cancel',row,cfg)
        usage(h,'capacity-after-cancel',a,1,60000)
        bd=h.start('capacity-real-b',bc,b);wait_outcome(h,'capacity-real-receipt',a,big['operation_id'],'ACKED')
        usage(h,'capacity-after-receipt',a,0,0)
        repeat=issue(h,'capacity-acked-repeat',a,peer='B',payload=p,op=big['operation_id'])
        h.check(repeat['queue_disposition']=='ALREADY_ACKED','receipt duplicate does not reacquire')
        usage(h,'capacity-repeat-still-zero',a,0,0)
        (h.output/'LARGE-CAPACITY.json').write_text(json.dumps({'retained_inbound_records':8192,'retained_inbound_payload_bytes':8192*2048,'settled_outbox_records':4096,'fixture_origin':'independently encoded retained history; B receipt is an actual C++ peer exchange','small':small,'maximum':big,'duplicate':duplicate,'after_receipt':repeat},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('constant_admission_work_beside_large_settled_history',large)

    def releases():
        a,b,ac,bc,ad,bd=setup(h,'capacity-terminal',online=True)
        limits=candidate(h,ac,'capacity-two','capacity-two-g2',lambda s:s.replace('outbox_global_max_records=4096','outbox_global_max_records=2').replace('outbox_peer_max_records=1024','outbox_peer_max_records=2').replace('outbox_global_max_payload_bytes=67108864','outbox_global_max_payload_bytes=20').replace('outbox_peer_max_payload_bytes=16777216','outbox_peer_max_payload_bytes=20'))
        activate(h,'capacity-activate-two',a,limits)
        rejected=issue(h,'capacity-denied',a,peer='B',scope='test/denied',text='x'*7)
        wait_outcome(h,'capacity-is-rejected',a,rejected['operation_id'],'REJECTED');usage(h,'capacity-rejection-releases',a,0,0)
        first=issue(h,'capacity-fill-one',a,peer='C',text='x'*10);second=issue(h,'capacity-fill-two',a,peer='C',text='y'*10)
        usage(h,'capacity-full',a,2,20)
        row,cfg=selection(h,'capacity-retry-select-full',a,rejected['operation_id'])
        denied=apply(h,'capacity-retry-full',a,'retry',row,cfg,expected=3)
        h.check(denied['code']=='OUTBOX_GLOBAL_RECORD_LIMIT','rejected retry must reacquire count before mutation')
        usage(h,'capacity-retry-no-drift',a,2,20)
        row,cfg=selection(h,'capacity-cancel-one-select',a,first['operation_id']);apply(h,'capacity-cancel-one',a,'cancel',row,cfg)
        usage(h,'capacity-one-released',a,1,10)
        bd.shutdown()
        row,cfg=selection(h,'capacity-retry-now-select',a,rejected['operation_id']);apply(h,'capacity-retry-now',a,'retry',row,cfg)
        usage(h,'capacity-reacquired',a,2,17)
        bd=h.start('capacity-recipient-again',bc,b);wait_outcome(h,'capacity-rejected-again',a,rejected['operation_id'],'REJECTED')
        usage(h,'capacity-second-release',a,1,10)
        # A zero-byte operation still spends a record reservation.
        zero=issue(h,'capacity-zero',a,peer='C',text='');usage(h,'capacity-zero-count',a,2,10)
        row,cfg=selection(h,'capacity-zero-select',a,zero['operation_id']);apply(h,'capacity-zero-cancel',a,'cancel',row,cfg)
        usage(h,'capacity-zero-release',a,1,10)
        too_many=issue(h,'capacity-bytes-over',a,peer='C',text='z'*11,expected=3)
        h.check(too_many['code']=='OUTBOX_GLOBAL_PAYLOAD_LIMIT','byte limit checked after exact record count boundary')
        usage(h,'capacity-byte-denial-unchanged',a,1,10)
        ad.shutdown();bd.shutdown()
        s=h.run('capacity-offline-reference',['inspect','--state',str(a),'--node','A'])
        h.check(s['outbox']['reservations']['peers']==[{'peer':'C','pending_records':1,'pending_payload_bytes':10,'future_result_records':0,'future_result_payload_bytes':0}],'only still-pending peer remains in rebuilt summary')
    case('terminal_release_exact_retry_reacquisition_and_zero_byte_counts',releases)

    def concurrent_admission():
        a,b,ac,bc,ad,bd=setup(h,'capacity-race')
        limited=candidate(h,ac,'capacity-race-limited','capacity-race-g2',lambda s:s.replace('outbox_global_max_records=4096','outbox_global_max_records=8').replace('outbox_peer_max_records=1024','outbox_peer_max_records=8').replace('outbox_global_max_payload_bytes=67108864','outbox_global_max_payload_bytes=80').replace('outbox_peer_max_payload_bytes=16777216','outbox_peer_max_payload_bytes=80'))
        activate(h,'capacity-race-activate',a,limited)
        def client(i):
            args=arguments(a,'capacity-racer-'+str(i),text='x'*10,peer='C')
            r=subprocess.run([str(h.binary),*args],capture_output=True,text=True,timeout=10)
            return i,args,r,json.loads(r.stdout)
        with concurrent.futures.ThreadPoolExecutor(max_workers=24) as pool:out=list(pool.map(client,range(24)))
        accepted=[]
        for i,args,r,q in out:
            h.commands.append({'label':'capacity-racer-'+str(i),'args':args,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
            h.check(r.returncode in (0,3),'concurrent bounded return')
            if r.returncode==0:
                accepted.append(q);h.check(q['work']['capacity_records_visited']==0 and q['work']['capacity_acquires']==1,'concurrent successful enqueue charges once')
            else:h.check(q['code']=='OUTBOX_GLOBAL_RECORD_LIMIT','excess racer observes exact global boundary')
        h.check(len(accepted)==8,'exactly eight of 24 concurrent submissions fit')
        usage(h,'capacity-concurrent-full',a,8,80)
        below=candidate(h,limited,'capacity-too-low','capacity-too-low-g3',lambda s:s.replace('outbox_global_max_records=8','outbox_global_max_records=7').replace('outbox_peer_max_records=8','outbox_peer_max_records=7'))
        bad=activate(h,'capacity-too-low-denied',a,below,expected=3)
        h.check(bad['code']=='CONFIG_OUTBOX_BELOW_USAGE','live lower limit fails before authority changes')
        usage(h,'capacity-after-invalid-config',a,8,80)
        ad.kill();ad=h.start('capacity-after-hard-kill',limited,a);usage(h,'capacity-reconstructed',a,8,80)
        h.run('capacity-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000']);usage(h,'capacity-compacted',a,8,80)
        (h.output/'CONCURRENCY.json').write_text(json.dumps({'clients':24,'accepted':len(accepted),'pending_records':8,'pending_payload_bytes':80,'accepted_responses':accepted},indent=2)+'\n')
        ad.shutdown()
    case('concurrent_exact_capacity_live_limit_rejection_and_kill_restart',concurrent_admission)

    def maintenance():
        a,b,ac,bc,ad,bd=setup(h,'capacity-maintenance')
        records=[issue(h,'capacity-retained-'+str(n),a,peer='C',text='v'*n) for n in (0,5,9)]
        row,cfg=selection(h,'capacity-maintenance-cancel-select',a,records[1]['operation_id']);apply(h,'capacity-maintenance-cancel',a,'cancel',row,cfg)
        usage(h,'capacity-before-maintenance',a,2,9);ad.shutdown()
        key=new_key(h,h.work,'capacity-state');migrate(h,'capacity-migrate',a,key)
        ad=start_keyed(h,'capacity-keyed',ac,a,key);usage(h,'capacity-keyed-usage',a,2,9)
        h.run('capacity-keyed-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000']);ad.shutdown()
        before=inspect(h,'capacity-offline-before',a,key);ident=h.identity('A');crypt=h.work/'capacity-backup.key';archive=h.work/'capacity.nob'
        h.run('capacity-encryption-key',['backup-key-init','--output',str(crypt),'--generation','capacity-archive'])
        h.run('capacity-export',['backup-export','--state',str(a),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--output',str(archive),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'capacity-restored'
        h.run('capacity-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'capacity-offline-after',restored,key)
        h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'derived aggregates never alter canonical logical state')
        h.check(before['outbox']['reservations']==after['outbox']['reservations'],'all per-peer reservations reconstructed through encrypted restore')
        moved=candidate(h,ac,'capacity-relocated','capacity-relocated-g2',lambda s:s.replace('state='+str(a),'state='+str(restored)))
        h.run('capacity-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','owned aggregate continuity','--state-auth-key',str(key)])
        ad=start_keyed(h,'capacity-restored-owner',moved,restored,key);usage(h,'capacity-relocated-counts',restored,2,9)
        row,cfg=selection(h,'capacity-final-cancel-select',restored,records[2]['operation_id']);apply(h,'capacity-final-cancel',restored,'cancel',row,cfg)
        usage(h,'capacity-zero-only',restored,1,0)
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'before':before['outbox']['reservations'],'restored':after['outbox']['reservations'],'logical_digest':after['storage']['logical_state_digest'],'final_pending_records':1,'final_pending_payload_bytes':0},indent=2)+'\n');ad.shutdown()
    case('authenticated_compaction_encrypted_restore_relocation_and_continuing_release',maintenance)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);start=time.time();ok=False
    try:
        cases(h,set(a.case) if a.case else None)
        if not h.cases:raise ValueError('no cases selected')
        ok=True
    except BaseException as e:(h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_PENDING_CAPACITY_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
