#!/usr/bin/env python3
"""Independent detached authenticated-state-head custody/CAS validation."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import subprocess
import sys
import time
from typing import Any

from run_persistent import Harness

CASES = (
    "create_read_independent_decode",
    "exact_compare_and_swap",
    "wrong_old_accounts",
    "malformed_and_noncanonical",
    "path_and_permission_boundaries",
    "injected_prepublish_failure",
    "create_postpublication_replacement",
    "replacement_race",
    "strict_cli_and_no_automatic_update",
)
MAGIC = b"NHCUST01"
DOMAIN = b"NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_RECORD_V1"



def digest(byte: int) -> str:
    return (bytes([byte]) * 32).hex()


def head(node: str, root_byte: int, records: int, size: int) -> str:
    return f"NASH1:{node}:a-g1:{digest(0x11)}:{digest(0x22)}:{digest(root_byte)}:{records}:{size}"


def parse_record(raw: bytes) -> dict[str, Any]:
    assert len(raw) <= 1024 and raw[:8] == MAGIC
    at = 8
    version = struct.unpack_from(">I", raw, at)[0]; at += 4
    assert version == 1
    def text(limit: int) -> str:
        nonlocal at
        n = struct.unpack_from(">H", raw, at)[0]; at += 2
        assert 0 < n <= limit
        value = raw[at:at+n].decode("ascii"); at += n
        return value
    node = text(64)
    domain = text(64)
    generation = struct.unpack_from(">Q", raw, at)[0]; at += 8
    selector = text(512)
    stored = raw[at:at+32]; at += 32
    assert at == len(raw)
    calculated = hashlib.sha256(DOMAIN + b"\0" + raw[:-32]).digest()
    assert stored == calculated
    return {
        "node": node, "domain": domain, "generation": generation,
        "selector": selector, "content_digest": stored.hex(),
        "record_digest": hashlib.sha256(raw).hexdigest(), "bytes": len(raw),
    }


def create(h: Harness, label: str, path: Path, selector: str, *, domain: str = "primary-anchor", generation: int = 1, expected: int = 0) -> dict[str, Any]:
    value = h.run(label, ["state-head-custody-create", "--record", str(path),
        "--node", "A", "--domain", domain, "--generation", str(generation),
        "--head", selector], expected=expected)
    assert value is not None
    return value


def exact_args(path: Path, record: dict[str, Any]) -> list[str]:
    return ["--record", str(path), "--expect-node", record["node"],
        "--expect-domain", record["domain"], "--expect-generation", str(record["generation"]),
        "--expect-head", record["selector"], "--expect-digest", record["record_digest"]]


def run_with_env(h: Harness, label: str, args: list[str], env: dict[str, str], expected: int = 0) -> dict[str, Any] | None:
    started = time.time()
    completed = subprocess.run([str(h.binary), *args], capture_output=True, text=True,
        timeout=10, env=dict(os.environ, **env))
    record = {"label": label, "args": args, "returncode": completed.returncode,
        "stdout": completed.stdout, "stderr": completed.stderr,
        "elapsed_seconds": time.time() - started, "environment": sorted(env)}
    h.commands.append(record)
    (h.logs / f"{len(h.commands):03d}-{label}.stdout.txt").write_text(completed.stdout)
    (h.logs / f"{len(h.commands):03d}-{label}.stderr.txt").write_text(completed.stderr)
    h.check(completed.returncode == expected,
        f"{label}: return {completed.returncode}, expected {expected}; stdout={completed.stdout!r} stderr={completed.stderr!r}")
    lines = [x for x in completed.stdout.splitlines() if x.strip()]
    return json.loads(lines[-1]) if lines else None


def run_suite(h: Harness, selected: set[str] | None) -> None:
    def case(name: str, fn: Any) -> None:
        if selected is None or name in selected:
            h.case(name, fn)

    def newdir(name: str) -> Path:
        path = h.work / name
        path.mkdir(mode=0o700)
        return path

    def create_read_independent_decode() -> None:
        root = newdir("create")
        path = root / "A.head"
        selector = head("A", 0x33, 7, 4096)
        value = create(h, "custody-create", path, selector)
        raw = path.read_bytes(); independent = parse_record(raw)
        h.check(value["format"] == "NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_V1", "versioned outer response")
        h.check(value["operation"] == "CREATE" and value["publication"] == "ATOMIC_NO_REPLACE", "create uses no-replace publication")
        h.check(independent["selector"] == selector and independent["generation"] == 1, "independent decoder reconstructs exact record")
        h.check(value["result"]["record_digest"] == independent["record_digest"], "product and independent whole-file digest agree")
        h.check(value["result"]["content_digest"] == independent["content_digest"], "product and independent content digest agree")
        mode = stat.S_IMODE(path.stat().st_mode)
        h.check(mode == 0o600 and path.stat().st_nlink == 1, "record is owner-only and singly linked")
        read = h.run("custody-read-exact", ["state-head-custody-read", *exact_args(path, independent)])
        assert read
        h.check(read["record"]["state_head"]["selector"] == selector, "read returns exact head")
        h.check(read["mutation"] == "NONE" and read["automatic_update"] is False, "read is observational")
        before = raw
        collision = create(h, "custody-create-collision", path, selector, expected=3)
        h.check(collision["code"] == "STATE_HEAD_CUSTODY_DESTINATION_EXISTS", "create never overwrites")
        h.check(path.read_bytes() == before, "collision preserves exact bytes")

    case("create_read_independent_decode", create_read_independent_decode)

    def exact_compare_and_swap() -> None:
        root = newdir("advance")
        path = root / "A.head"
        first = head("A", 0x31, 3, 1200); second = head("A", 0x32, 4, 1400)
        create(h, "advance-create", path, first)
        old = parse_record(path.read_bytes()); old_inode = path.stat().st_ino
        value = h.run("advance-exact", ["state-head-custody-advance", *exact_args(path, old),
            "--new-generation", "2", "--new-head", second])
        assert value
        current = parse_record(path.read_bytes())
        h.check(value["operation"] == "COMPARE_AND_SWAP_ADVANCE", "explicit CAS operation returned")
        h.check(value["old_identity_rechecked_immediately_before_publication"] is True, "old identity recheck is reported")
        h.check(current["generation"] == 2 and current["selector"] == second, "candidate became exact current record")
        h.check(current["record_digest"] != old["record_digest"] and path.stat().st_ino != old_inode, "CAS replaces exact inode and bytes")
        h.check(not list(root.glob(".*.custody-*.tmp")), "successful CAS leaves no staging record")
        stale = h.run("advance-stale-old", ["state-head-custody-advance", *exact_args(path, old),
            "--new-generation", "3", "--new-head", head("A", 0x34, 5, 1600)], expected=3)
        assert stale
        h.check(stale["code"] == "STATE_HEAD_CUSTODY_EXPECTATION_MISMATCH", "old CAS input cannot be reused")

    case("exact_compare_and_swap", exact_compare_and_swap)

    def wrong_old_accounts() -> None:
        root = newdir("wrong")
        path = root / "A.head"; initial = head("A", 0x41, 9, 1900)
        create(h, "wrong-create", path, initial, domain="ops-primary", generation=7)
        exact = parse_record(path.read_bytes()); before = path.read_bytes()
        variants = {
            "node": {**exact, "node": "B"},
            "domain": {**exact, "domain": "ops-secondary"},
            "generation": {**exact, "generation": 6},
            "head": {**exact, "selector": head("A", 0x42, 9, 1900)},
            "digest": {**exact, "record_digest": digest(0x77)},
        }
        for name, old in variants.items():
            value = h.run(f"wrong-{name}", ["state-head-custody-advance", *exact_args(path, old),
                "--new-generation", "8", "--new-head", head("A", 0x43, 10, 2100)], expected=3)
            assert value
            h.check(value["code"] in ("STATE_HEAD_CUSTODY_EXPECTATION_MISMATCH", "STATE_HEAD_CUSTODY_EXPECTATION_INVALID"), f"wrong {name} fails closed")
            h.check(path.read_bytes() == before, f"wrong {name} preserves exact old bytes")
        for generation in ("7", "6"):
            value = h.run(f"nonadvancing-{generation}", ["state-head-custody-advance", *exact_args(path, exact),
                "--new-generation", generation, "--new-head", head("A", 0x44, 11, 2200)], expected=3)
            assert value
            h.check(value["code"] == "STATE_HEAD_CUSTODY_GENERATION_INVALID", "custody generation strictly advances")
        value = h.run("new-head-node-mismatch", ["state-head-custody-advance", *exact_args(path, exact),
            "--new-generation", "8", "--new-head", head("B", 0x45, 11, 2200)], expected=3)
        assert value
        h.check(value["code"] == "STATE_HEAD_CUSTODY_HEAD_MISMATCH", "new NASH1 remains bound to custody node")
        h.check(path.read_bytes() == before, "all failed comparisons preserve bytes")

    case("wrong_old_accounts", wrong_old_accounts)

    def malformed_and_noncanonical() -> None:
        root = newdir("malformed")
        path = root / "A.head"; selector = head("A", 0x51, 2, 800)
        create(h, "malformed-create", path, selector)
        good = path.read_bytes()
        mutations: list[tuple[str, bytes, int, tuple[str, ...]]] = [
            ("magic", b"X" + good[1:], 3, ("STATE_HEAD_CUSTODY_RECORD_INVALID",)),
            ("version", good[:8] + (2).to_bytes(4, "big") + good[12:], 3, ("STATE_HEAD_CUSTODY_RECORD_INVALID",)),
            ("truncated", good[:-1], 4, ("truncated-field",)),
            ("extended", good + b"x", 4, ("trailing-material",)),
            ("digest", good[:-1] + bytes([good[-1] ^ 1]), 3, ("STATE_HEAD_CUSTODY_RECORD_INVALID",)),
            ("oversized", good + b"x" * 800, 3, ("STATE_HEAD_CUSTODY_FILE_INVALID",)),
        ]
        for name, raw, status, codes in mutations:
            path.write_bytes(raw); path.chmod(0o600)
            value = h.run(f"malformed-{name}", ["state-head-custody-read", "--record", str(path)], expected=status)
            assert value
            h.check(value["code"] in codes, f"{name} record rejected")
            h.check(path.read_bytes() == raw, f"{name} rejection does not repair or rewrite")
        path.write_bytes(good); path.chmod(0o600)
        invalid_domains = ("", "UPPER", "-leading", "trailing-", "slash/value", "x" * 65)
        for i, domain in enumerate(invalid_domains):
            other = root / f"invalid-domain-{i}.head"
            value = create(h, f"invalid-domain-{i}", other, selector, domain=domain, expected=3)
            h.check(value["code"] == "STATE_HEAD_CUSTODY_DOMAIN_INVALID" and not other.exists(), "noncanonical domain rejected before publication")
        for text in ("01", "+1", "0", "-1"):
            value = h.run("invalid-generation-" + text.replace("/", "_"), ["state-head-custody-create", "--record", str(root / ("g" + text.replace("-", "m") + ".head")),
                "--node", "A", "--domain", "primary", "--generation", text, "--head", selector], expected=3)
            assert value
            h.check(value["code"] in ("STATE_HEAD_CUSTODY_GENERATION_INVALID", "INVALID_INTEGER", "INVALID_ARGUMENT"), "generation syntax canonical")

    case("malformed_and_noncanonical", malformed_and_noncanonical)

    def path_and_permission_boundaries() -> None:
        root = newdir("paths"); selector = head("A", 0x61, 2, 700)
        record = root / "A.head"; create(h, "paths-create", record, selector)
        before = record.read_bytes()
        record.chmod(0o640)
        value = h.run("paths-file-mode", ["state-head-custody-read", "--record", str(record)], expected=3); assert value
        h.check(value["code"] == "STATE_HEAD_CUSTODY_FILE_PERMISSIONS_INVALID", "loose record mode rejected")
        record.chmod(0o4600)
        value = h.run("paths-file-special-mode", ["state-head-custody-read", "--record", str(record)], expected=3); assert value
        h.check(value["code"] == "STATE_HEAD_CUSTODY_FILE_PERMISSIONS_INVALID", "set-ID record mode rejected")
        record.chmod(0o600)
        link = root / "hard.head"; os.link(record, link)
        value = h.run("paths-hardlink", ["state-head-custody-read", "--record", str(record)], expected=3); assert value
        h.check(value["code"] == "STATE_HEAD_CUSTODY_FILE_PERMISSIONS_INVALID", "multiply linked record rejected")
        link.unlink()
        symlink = root / "sym.head"; symlink.symlink_to(record.name)
        value = h.run("paths-symlink", ["state-head-custody-read", "--record", str(symlink)], expected=3); assert value
        h.check(value["code"] in ("STATE_HEAD_CUSTODY_OPEN_FAILED", "STATE_HEAD_CUSTODY_FILE_INVALID"), "final symlink rejected")
        loose = newdir("loose"); loose.chmod(0o770)
        value = create(h, "paths-parent-mode", loose / "A.head", selector, expected=3)
        h.check(value["code"] == "STATE_HEAD_CUSTODY_PARENT_PERMISSIONS_INVALID", "writable parent rejected")
        loose.chmod(0o700)
        target = newdir("target")
        parent_link = h.work / "parent-link"; parent_link.symlink_to(target, target_is_directory=True)
        value = create(h, "paths-parent-symlink", parent_link / "A.head", selector, expected=3)
        h.check(value["code"] == "STATE_HEAD_CUSTODY_PARENT_OPEN_FAILED", "symlinked parent component rejected")
        h.check(record.read_bytes() == before and stat.S_IMODE(record.stat().st_mode) == 0o600, "path attacks preserve original")

    case("path_and_permission_boundaries", path_and_permission_boundaries)

    def injected_prepublish_failure() -> None:
        root = newdir("injected")
        path = root / "A.head"; first = head("A", 0x71, 4, 900)
        create(h, "injected-create", path, first)
        old = parse_record(path.read_bytes()); before = path.read_bytes(); inode = path.stat().st_ino
        value = run_with_env(h, "injected-before-publish", ["state-head-custody-advance", *exact_args(path, old),
            "--new-generation", "2", "--new-head", head("A", 0x72, 5, 1000)],
            {"NATRAV_OVERLAY_TEST_CUSTODY_FAIL_BEFORE_PUBLISH": "yes"}, expected=3)
        assert value
        h.check(value["code"] == "STATE_HEAD_CUSTODY_TEST_PREPUBLICATION_FAILURE", "test boundary fires before exchange")
        h.check(path.read_bytes() == before and path.stat().st_ino == inode, "injected failure preserves exact old inode and bytes")
        h.check(not list(root.glob(".*.custody-*.tmp")), "injected failure cleans staging file")

    case("injected_prepublish_failure", injected_prepublish_failure)

    def create_postpublication_replacement() -> None:
        root = newdir("create-postpublication")
        path = root / "A.head"; replacement = root / "replacement.head"
        candidate_head = head("A", 0x79, 4, 950)
        create(h, "create-postpublication-winner", replacement,
            head("A", 0x7A, 5, 975), generation=2)
        winner = replacement.read_bytes()
        args = [str(h.binary), "state-head-custody-create", "--record", str(path),
            "--node", "A", "--domain", "primary-anchor", "--generation", "1",
            "--head", candidate_head]
        begin = time.time()
        process = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            env=dict(os.environ, NATRAV_OVERLAY_TEST_CUSTODY_PAUSE_AFTER_CREATE_PUBLISH_MS="800"))
        deadline = time.time() + 5
        while not path.exists() and time.time() < deadline:
            time.sleep(0.01)
        h.check(path.exists(), "candidate path is published before the test replacement")
        os.replace(replacement, path)
        stdout, stderr = process.communicate(timeout=10)
        record = {"label": "create-postpublication-replacement", "args": args[1:],
            "returncode": process.returncode, "stdout": stdout, "stderr": stderr,
            "elapsed_seconds": time.time()-begin,
            "environment": ["NATRAV_OVERLAY_TEST_CUSTODY_PAUSE_AFTER_CREATE_PUBLISH_MS"]}
        h.commands.append(record)
        (h.logs / f"{len(h.commands):03d}-create-postpublication-replacement.stdout.txt").write_text(stdout)
        (h.logs / f"{len(h.commands):03d}-create-postpublication-replacement.stderr.txt").write_text(stderr)
        h.check(process.returncode == 3, "create detects replacement after no-replace publication")
        value = json.loads([x for x in stdout.splitlines() if x.strip()][-1])
        h.check(value["code"] == "STATE_HEAD_CUSTODY_POSTCONDITION_FAILED",
            "create replacement has an explicit postcondition failure")
        h.check(path.read_bytes() == winner, "create never overwrites the independent postpublication winner")
        h.check(not list(root.glob(".*.custody-*.tmp")), "create replacement leaves no staging record")

    case("create_postpublication_replacement", create_postpublication_replacement)

    def replacement_race() -> None:
        root = newdir("race")
        path = root / "A.head"; replacement = root / "replacement.head"
        create(h, "race-create", path, head("A", 0x81, 5, 1100))
        create(h, "race-replacement-create", replacement, head("A", 0x82, 6, 1200), generation=2)
        old = parse_record(path.read_bytes()); winner = replacement.read_bytes()
        args = [str(h.binary), "state-head-custody-advance", *exact_args(path, old),
            "--new-generation", "3", "--new-head", head("A", 0x83, 7, 1300)]
        begin = time.time()
        process = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            env=dict(os.environ, NATRAV_OVERLAY_TEST_CUSTODY_PAUSE_BEFORE_RECHECK_MS="500"))
        time.sleep(0.15)
        os.replace(replacement, path)
        stdout, stderr = process.communicate(timeout=10)
        record = {"label": "replacement-race", "args": args[1:], "returncode": process.returncode,
            "stdout": stdout, "stderr": stderr, "elapsed_seconds": time.time()-begin,
            "environment": ["NATRAV_OVERLAY_TEST_CUSTODY_PAUSE_BEFORE_RECHECK_MS"]}
        h.commands.append(record)
        (h.logs / f"{len(h.commands):03d}-replacement-race.stdout.txt").write_text(stdout)
        (h.logs / f"{len(h.commands):03d}-replacement-race.stderr.txt").write_text(stderr)
        h.check(process.returncode == 3, "replacement race is rejected")
        value = json.loads([x for x in stdout.splitlines() if x.strip()][-1])
        h.check(value["code"] == "STATE_HEAD_CUSTODY_REPLACEMENT_RACE", "race has explicit failure code")
        h.check(path.read_bytes() == winner, "CAS never overwrites the independently replaced winner")
        h.check(not list(root.glob(".*.custody-*.tmp")), "race rejection cleans candidate staging files")

    case("replacement_race", replacement_race)

    def strict_cli_and_no_automatic_update() -> None:
        root = newdir("strict")
        path = root / "A.head"; selector = head("A", 0x91, 1, 600)
        create(h, "strict-create", path, selector)
        before = path.read_bytes(); record = parse_record(before)
        read = h.run("strict-read-no-expectations", ["state-head-custody-read", "--record", str(path)]); assert read
        h.check(read["record"]["freshness"] == "CUSTODIAN_EXPLICIT_UPDATE_DISCIPLINE_ONLY", "custody labels limited freshness meaning")
        h.check(read["automatic_update"] is False and read["state_opened"] is False and read["workers_started"] is False, "record access is detached and manual")
        unknown = h.run("strict-unknown-option", ["state-head-custody-read", "--record", str(path), "--state", str(root)], expected=3); assert unknown
        h.check(unknown["code"] == "UNKNOWN_ARGUMENT", "custody reader cannot be redirected into state opening")
        missing = h.run("strict-advance-incomplete-old", ["state-head-custody-advance", "--record", str(path),
            "--expect-node", "A", "--new-generation", "2", "--new-head", head("A", 0x92, 2, 650)], expected=3); assert missing
        h.check(missing["code"] in ("MISSING_ARGUMENT", "STATE_HEAD_CUSTODY_EXPECTATION_REQUIRED"), "advance requires complete exact old account")
        h.check(path.read_bytes() == before and parse_record(path.read_bytes())["record_digest"] == record["record_digest"], "observations and parser errors never auto-advance")

    case("strict_cli_and_no_automatic_update", strict_cli_and_no_automatic_update)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append", choices=CASES)
    args = parser.parse_args()
    if args.output.exists(): parser.error("output already exists")
    h = Harness(args.binary, args.output); begin = time.time(); code = 1
    try:
        run_suite(h, set(args.case) if args.case else None); code = 0
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
    finally:
        h.cleanup()
        summary = {"format": "NATRAV_OVERLAY_STATE_HEAD_CUSTODY_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(c["status"] == "PASS" for c in h.cases),
            "cases_total": len(h.cases), "assertions": h.assertions,
            "commands": len(h.commands), "elapsed_seconds": time.time()-begin}
        for name, obj in (("SUMMARY.json", summary), ("CASES.json", h.cases), ("COMMANDS.json", h.commands)):
            (h.output / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
