#include "adapter_profile_catalog.hpp"
#include "common.hpp"
#include "configured_adapter_endpoint.hpp"
#include "external_packet_adapter.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <csignal>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>
#include <utility>
#include <vector>

namespace {

using natrav_overlay::AdapterCatalogAuthorityDecision;
using natrav_overlay::AdapterCatalogOperation;
using natrav_overlay::AdapterEndpointRole;
using natrav_overlay::AdapterSha256;
using natrav_overlay::AppError;
using natrav_overlay::ConfiguredAdapterEndpoint;
using natrav_overlay::DurableAdapterProfileCatalog;
using natrav_overlay::ExternalPacketAdapterOptions;
using natrav_overlay::OperatorPinnedAdapterProfile;

struct CaseRecord final {
    std::string name;
    std::size_t assertions{0U};
};

class Probe final {
public:
    template <typename Function>
    void run_case(std::string name, Function&& function) {
        const auto before = assertions_;
        function();
        cases_.push_back(CaseRecord{
            .name = std::move(name),
            .assertions = assertions_ - before,
        });
    }

    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_app_code(
        Function&& function,
        const std::string_view expected,
        const std::string_view detail) {
        ++assertions_;
        try {
            function();
        } catch (const AppError& error) {
            if (error.code() == expected) {
                return;
            }
            throw std::runtime_error(
                std::string(detail) + ": expected " + std::string(expected) +
                ", observed " + error.code());
        }
        throw std::runtime_error(std::string(detail) + ": no error");
    }

    [[nodiscard]] std::size_t assertions() const noexcept { return assertions_; }
    [[nodiscard]] const std::vector<CaseRecord>& cases() const noexcept {
        return cases_;
    }

private:
    std::size_t assertions_{0U};
    std::vector<CaseRecord> cases_{};
};

class TempDirectory final {
public:
    TempDirectory() {
        std::array<char, 128U> pattern{};
        const std::string value = "/tmp/natrav-adapter-catalog-int-XXXXXX";
        std::copy(value.begin(), value.end(), pattern.begin());
        char* created = ::mkdtemp(pattern.data());
        if (created == nullptr) {
            throw std::runtime_error("mkdtemp failed");
        }
        path_ = created;
        if (::chmod(path_.c_str(), S_IRWXU) != 0) {
            throw std::runtime_error("chmod temp directory failed");
        }
    }
    TempDirectory(const TempDirectory&) = delete;
    TempDirectory& operator=(const TempDirectory&) = delete;
    ~TempDirectory() { std::filesystem::remove_all(path_); }
    [[nodiscard]] const std::filesystem::path& path() const noexcept { return path_; }
private:
    std::filesystem::path path_{};
};

[[nodiscard]] std::vector<std::uint8_t> read_bytes(
    const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        throw std::runtime_error("file open failed: " + path.string());
    }
    return std::vector<std::uint8_t>(
        std::istreambuf_iterator<char>(input),
        std::istreambuf_iterator<char>());
}

[[nodiscard]] std::string read_text(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        throw std::runtime_error("report open failed: " + path.string());
    }
    return std::string(
        std::istreambuf_iterator<char>(input),
        std::istreambuf_iterator<char>());
}

[[nodiscard]] bool contains_line(
    const std::string_view text,
    const std::string_view line) {
    return text.find(std::string(line) + '\n') != std::string_view::npos;
}

void copy_executable(
    const std::filesystem::path& source,
    const std::filesystem::path& destination) {
    std::filesystem::copy_file(
        source, destination, std::filesystem::copy_options::overwrite_existing);
    if (::chmod(destination.c_str(), S_IRUSR | S_IWUSR | S_IXUSR) != 0) {
        throw std::runtime_error("chmod copied executable failed");
    }
}

[[nodiscard]] OperatorPinnedAdapterProfile make_profile(
    const std::uint64_t generation,
    const AdapterSha256& previous,
    const std::filesystem::path& executable,
    const AdapterSha256& digest,
    const std::filesystem::path& report) {
    OperatorPinnedAdapterProfile profile;
    profile.profile_id = "persistent-adapter";
    profile.generation = generation;
    profile.previous_profile_sha256 = previous;
    profile.executable = executable;
    profile.executable_sha256 = digest;
    profile.arguments = {report.string()};
    profile.mtu = 1'200U;
    profile.capability_profile = 1U;
    profile.max_frame_bytes = 65'536U;
    profile.max_queued_bytes = 1'048'576U;
    profile.max_outstanding_requests = 1U;
    profile.max_evidence_events = 256U;
    profile.max_launch_attempts = 3U;
    profile.startup_timeout = std::chrono::milliseconds(2'000);
    profile.request_timeout = std::chrono::milliseconds(500);
    profile.shutdown_timeout = std::chrono::milliseconds(500);
    profile.initial_restart_backoff = std::chrono::milliseconds(5);
    profile.maximum_restart_backoff = std::chrono::milliseconds(20);
    return profile;
}

[[nodiscard]] ConfiguredAdapterEndpoint make_endpoint(
    const std::uint64_t generation,
    const AdapterSha256& previous,
    const OperatorPinnedAdapterProfile& profile,
    const std::uint32_t epoch) {
    ConfiguredAdapterEndpoint endpoint;
    endpoint.endpoint_id = "persistent-route";
    endpoint.generation = generation;
    endpoint.previous_endpoint_sha256 = previous;
    endpoint.role = AdapterEndpointRole::route;
    endpoint.locator.profile_id = profile.profile_id;
    endpoint.locator.profile_generation = profile.generation;
    endpoint.locator.link_id = 0xa0b0c0d0e0f00123ULL;
    endpoint.locator.epoch = epoch;
    endpoint.profile_sha256 =
        natrav_overlay::operator_pinned_adapter_profile_sha256(profile);
    return endpoint;
}

[[nodiscard]] std::vector<std::uint8_t> authority() {
    const std::string token = "authenticated-owner-command";
    return std::vector<std::uint8_t>(token.begin(), token.end());
}

[[nodiscard]] natrav_overlay::AdapterCatalogAuthorityVerifier verifier() {
    return [](
        const AdapterCatalogOperation,
        const std::span<const std::uint8_t>,
        const std::span<const std::uint8_t> evidence) {
        const std::string token(evidence.begin(), evidence.end());
        return AdapterCatalogAuthorityDecision{
            .authorized = token == "authenticated-owner-command",
            .rejection_code = token == "authenticated-owner-command"
                ? std::string{}
                : std::string("OWNER_AUTHORITY_REJECTED"),
        };
    };
}

void exchange_one_packet(
    ExternalPacketAdapterOptions options,
    Probe& probe,
    const std::string_view expected_marker,
    const std::filesystem::path& report) {
    {
        auto adapter = natrav_overlay::make_supervised_external_packet_adapter(
            std::move(options));
        const natrav::packet_link::Bytes packet{
            0x10U, 0x20U, 0x30U, 0x40U, 0xfeU, 0xffU};
        probe.check(adapter.port->send_packet(packet),
                    "configured adapter accepts bounded datagram");
        const auto received = adapter.port->receive_packet();
        probe.check(received.has_value() && *received == packet,
                    "configured adapter returns exact datagram");
        const auto snapshot = adapter.control->snapshot();
        probe.check(snapshot.running && snapshot.launch_attempts == 1U,
                    "configured adapter launch is recorded");
        probe.check(snapshot.pinned_profile_id == "persistent-adapter" &&
                        snapshot.pinned_profile_generation != 0U,
                    "snapshot binds durable profile identity and generation");
        const auto startup = read_text(report);
        probe.check(contains_line(
                        startup,
                        std::string("marker=") + std::string(expected_marker)),
                    "executed image marker matches authorized bytes");
        probe.check(contains_line(startup, "environment-count=5") &&
                        contains_line(startup, "extra-fd-count=0") &&
                        contains_line(startup, "no-new-privs=1"),
                    "configured launch preserves descriptor and environment isolation");
    }
    probe.check(contains_line(read_text(report), "shutdown=1"),
                "configured adapter completes bounded shutdown");
}

}  // namespace

int main(int argc, char* argv[]) {
    Probe probe;
    try {
        if (argc != 3) {
            throw std::runtime_error("expected adapter fixture A and B");
        }
        const auto fixture_a = std::filesystem::absolute(argv[1]);
        const auto fixture_b = std::filesystem::absolute(argv[2]);
        const auto digest_a = natrav_overlay::adapter_sha256(read_bytes(fixture_a));
        const auto digest_b = natrav_overlay::adapter_sha256(read_bytes(fixture_b));
        TempDirectory temporary;
        const auto executable = temporary.path() / "adapter";
        const auto old_executable = temporary.path() / "adapter-old";
        const auto report_a = temporary.path() / "report-a.txt";
        const auto report_b = temporary.path() / "report-b.txt";
        const auto catalog_path = temporary.path() / "profiles.catalog";
        copy_executable(fixture_a, executable);

        DurableAdapterProfileCatalog catalog(catalog_path);
        const auto auth = authority();
        const auto profile_one = make_profile(
            1U, AdapterSha256{}, executable, digest_a, report_a);
        const auto endpoint_one = make_endpoint(
            1U, AdapterSha256{}, profile_one, 1U);
        static_cast<void>(catalog.commit_profile(profile_one, auth, verifier()));
        static_cast<void>(catalog.commit_endpoint(endpoint_one, auth, verifier()));

        natrav_overlay::PreparedConfiguredAdapterEndpoint prepared_one;
        probe.run_case("durable exact endpoint prepares only profile-derived options", [&] {
            prepared_one =
                natrav_overlay::prepare_configured_external_adapter_endpoint(
                    catalog, "persistent-route", 1U);
            probe.check(prepared_one.endpoint == endpoint_one,
                        "prepared endpoint is exact durable generation");
            probe.check(prepared_one.profile_sha256 ==
                            natrav_overlay::operator_pinned_adapter_profile_sha256(
                                profile_one),
                        "prepared endpoint binds exact profile record digest");
            probe.check(prepared_one.options.pinned_profile.has_value() &&
                            prepared_one.options.pinned_profile.value() == profile_one &&
                            prepared_one.options.verified_executable != nullptr,
                        "launch options are produced only from pinned profile factory");
        });

        probe.run_case("sealed prepared route survives path replacement", [&] {
            std::filesystem::rename(executable, old_executable);
            copy_executable(fixture_b, executable);
            exchange_one_packet(prepared_one.options, probe, "A", report_a);
        });

        probe.run_case("node-style reopen detects executable replacement", [&] {
            DurableAdapterProfileCatalog reopened(catalog_path);
            probe.expect_app_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::prepare_configured_external_adapter_endpoint(
                            reopened, "persistent-route", 1U));
                },
                "ADAPTER_EXECUTABLE_DIGEST_MISMATCH",
                "fresh preparation refuses replaced executable bytes");
        });

        const auto profile_two = make_profile(
            2U,
            natrav_overlay::operator_pinned_adapter_profile_sha256(profile_one),
            executable,
            digest_b,
            report_b);
        const auto endpoint_two = make_endpoint(
            2U,
            natrav_overlay::configured_adapter_endpoint_sha256(endpoint_one),
            profile_two,
            2U);
        static_cast<void>(catalog.commit_profile(profile_two, auth, verifier()));
        static_cast<void>(catalog.commit_endpoint(endpoint_two, auth, verifier()));

        natrav_overlay::PreparedConfiguredAdapterEndpoint prepared_two;
        probe.run_case("authorized successor activates new image and generation", [&] {
            prepared_two =
                natrav_overlay::prepare_configured_external_adapter_endpoint(
                    catalog, "persistent-route", 2U);
            probe.check(prepared_two.endpoint.locator.profile_generation == 2U &&
                            prepared_two.options.pinned_profile->generation == 2U,
                        "successor endpoint resolves successor profile exactly");
            exchange_one_packet(prepared_two.options, probe, "B", report_b);
        });

        probe.run_case("runtime death cannot manufacture success", [&] {
            auto adapter = natrav_overlay::make_supervised_external_packet_adapter(
                prepared_two.options);
            const auto before = adapter.control->snapshot();
            probe.check(before.running && before.process_id > 0,
                        "adapter process is running before fault");
            if (::kill(static_cast<pid_t>(before.process_id), SIGKILL) != 0) {
                throw std::runtime_error("kill adapter failed");
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(25));
            probe.expect_app_code(
                [&] {
                    const natrav::packet_link::Bytes packet{0x55U};
                    static_cast<void>(adapter.port->send_packet(packet));
                },
                "PEER_RESET",
                "dead adapter terminates current carrier");
            const auto after = adapter.control->snapshot();
            probe.check(!after.running && after.child_exits == 1U &&
                            after.transmitted_packets == 0U,
                        "death is accounted once without a false packet success");
        });

        probe.run_case("bounded carrier reconstruction uses fresh process", [&] {
            auto rebuilt =
                natrav_overlay::prepare_configured_external_adapter_endpoint(
                    catalog, "persistent-route", 2U);
            exchange_one_packet(rebuilt.options, probe, "B", report_b);
            probe.check(rebuilt.options.verified_executable !=
                            prepared_two.options.verified_executable,
                        "reconstruction creates a fresh verified-image owner");
        });

        probe.run_case("prepared successor survives disappearance but restart revalidates", [&] {
            std::filesystem::remove(executable);
            exchange_one_packet(prepared_two.options, probe, "B", report_b);
            DurableAdapterProfileCatalog restarted(catalog_path);
            probe.expect_app_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::prepare_configured_external_adapter_endpoint(
                            restarted, "persistent-route", 2U));
                },
                "ADAPTER_EXECUTABLE_OPEN_FAILED",
                "new node process must reopen and revalidate configured path");
            copy_executable(fixture_b, executable);
            auto restored =
                natrav_overlay::prepare_configured_external_adapter_endpoint(
                    restarted, "persistent-route", 2U);
            exchange_one_packet(restored.options, probe, "B", report_b);
        });

        probe.run_case("exact old endpoint remains explicit and replacement-sensitive", [&] {
            probe.expect_app_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::prepare_configured_external_adapter_endpoint(
                            catalog, "persistent-route", 1U));
                },
                "ADAPTER_EXECUTABLE_DIGEST_MISMATCH",
                "old retained endpoint does not silently upgrade to new image");
            const auto old = catalog.resolve_endpoint("persistent-route", 1U);
            const auto current = catalog.resolve_endpoint("persistent-route", 2U);
            probe.check(old.profile.generation == 1U &&
                            current.profile.generation == 2U,
                        "catalog preserves exact historical generations without guessing");
        });

        std::cout
            << "{\"format\":\"NATRAV_ADAPTER_CATALOG_INTEGRATION_V1\","
            << "\"status\":\"PASS\",\"cases\":" << probe.cases().size()
            << ",\"assertions\":" << probe.assertions()
            << ",\"case_records\":[";
        for (std::size_t index = 0U; index < probe.cases().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            std::cout << "{\"name\":\"" << probe.cases()[index].name
                      << "\",\"assertions\":"
                      << probe.cases()[index].assertions << '}';
        }
        std::cout << "]}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cout
            << "{\"format\":\"NATRAV_ADAPTER_CATALOG_INTEGRATION_V1\","
            << "\"status\":\"FAIL\",\"assertions\":" << probe.assertions()
            << ",\"detail\":\"" << error.what() << "\"}\n";
        return 1;
    }
}
