#!/usr/bin/env python3
"""DOMAIN_SUMMARY_V1: independently interpreted internal result/checkpoint transactions."""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, socket, struct, subprocess, time
from pathlib import Path
from typing import Any
from run_persistent import Harness, free_port, operation, raw_control
from run_consumers import config as consumer_config, call as consumer_call, wire
from run_evidence_queries import config as writer_config
from run_scoped_reads import send, UID, SECOND_UID
from run_local_administration import run_as_uid, expose_control_for_uid
from run_live_configuration import candidate, activate, wait_state
from run_peer_sessions import revise, submit
from run_evidence_feed import wire_feed
from run_state_authentication import new_key, migrate, start as start_keyed


def config(h: Harness,name: str,state: Path,port: int,extra: bool=False)->Path:
    p=consumer_config(h,name,state,port,extra)
    lines=p.read_text().replace('CONFIG_V11','CONFIG_V12').splitlines()
    p.write_text('\n'.join(x+',PROJECTION' if x.startswith('local_control=') and 'CONSUMER' in x else x for x in lines)+'\n')
    return p

def trio(h: Harness,name: str,extra: bool=False):
    a,b,c=(h.runtime/(name+'-'+x) for x in ('a','b','c'));bp=free_port()
    bc=config(h,name+'-b',b,bp,extra)
    ac=writer_config(h,name+'-a','A',a,free_port(),[('B',bp)])
    cc=writer_config(h,name+'-c','C',c,free_port(),[('B',bp)])
    bd=h.start(name+'-b',bc,b);ad=h.start(name+'-a',ac,a);cd=h.start(name+'-c',cc,c)
    return a,b,c,ac,bc,cc,ad,bd,cd

def pargs(state: Path,cmd: str,name: str='summary',**kw: Any)->list[str]:
    args=['projection-'+cmd,'--control',str(state/'control.sock'),'--consumer',name,'--deadline-ms','4000']
    for k,v in kw.items():args+=['--'+k.replace('_','-'),str(v)]
    return args

def call(h: Harness,label: str,state: Path,cmd: str,name: str='summary',expected: int=0,uid: int|None=None,**kw: Any)->dict[str,Any]:
    args=pargs(state,cmd,name,**kw)
    r=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    assert r is not None
    if expected==0:
        p=r['consumer']['projection'];h.check(p['definition']=='DOMAIN_SUMMARY_V1','exact built-in definition')
        h.check(r['consumer']['owner_uid']==(os.geteuid() if uid is None else uid),'actual kernel UID namespace')
        h.check(p['result']['admissions']==r['consumer']['acknowledged_sequence'],'result and progress agree')
    return r

def create(h: Harness,label: str,b: Path,name: str='summary',**kw: Any)->dict[str,Any]:
    return call(h,label,b,'create',name,issuer='A',scope='query/series',reason='explicit metadata projection',**kw)

def read(h: Harness,label: str,b: Path,name: str='summary',**kw: Any)->dict[str,Any]:
    return consumer_call(h,label,b,'read',name,**kw)

def expected(definition: str,rows: list[dict[str,Any]])->dict[str,Any]:
    root=bytes.fromhex(definition);heads={};historical=0;originals=0;corrections=0
    for i,row in enumerate(rows,1):
        historical+=row['payload_size']
        if row['corrects'] is not None:
            assert row['corrects'] in heads
            del heads[row['corrects']];corrections+=1
        else:originals+=1
        heads[row['operation_id']]=row['payload_size']
        root=hashlib.sha256(b'NATRAV_OVERLAY_PROJECTION_SOURCE_V1\0'+root+struct.pack('!Q',i)+bytes.fromhex(row['operation_id'])+bytes.fromhex(row['record_digest'])).digest()
    return {'admissions':len(rows),'originals':originals,'corrections':corrections,'current_heads':len(heads),
            'historical_payload_bytes':historical,'current_payload_bytes':sum(heads.values()),'source_digest':root.hex()}

def check_result(h: Harness,r: dict[str,Any],rows: list[dict[str,Any]])->None:
    p=r['consumer']['projection']
    h.check(p['result']==expected(p['definition_digest'],rows),'independent map interpreter and source-chain agree')
    c=r['consumer']
    feed=wire_feed(issuer=c['issuer_filter'],scope=c['scope_filter'],limit=c['limit'],max_bytes=c['max_bytes'])[5:]
    definition=hashlib.sha256(b'NATRAV_OVERLAY_DOMAIN_SUMMARY_V1\0'+struct.pack('!I',c['owner_uid'])+bytes.fromhex(c['instance'])+struct.pack('!Q',p['maximum_admissions'])+feed).hexdigest()
    h.check(definition==p['definition_digest'],'independent immutable definition binding')


def cases(h: Harness,selected: set[str]|None=None)->None:
    def case(name: str,fn: Any):
        if selected is None or name in selected:h.case(name,fn)

    def strict():
        b=h.runtime/'strict';cfg=config(h,'strict',b,free_port())
        h.check(h.run('v12-check',['config-check','--config',str(cfg)])['format']=='NATRAV_OVERLAY_CONFIG_V12','explicit policy V12')
        for label,change in [('old-format',lambda s:s.replace('CONFIG_V12','CONFIG_V11')),
            ('missing-consumer',lambda s:s.replace(',CONSUMER,',',')),('missing-read',lambda s:s.replace(',EVIDENCE_READ,',','))]:
            p=cfg.with_name(label+'.conf');p.write_text(change(cfg.read_text()));p.chmod(0o600)
            h.run(label,['config-check','--config',str(p)],expected=3)
        d=h.start('strict',cfg,b)
        r=create(h,'create',b,limit=2);check_result(h,r,[])
        h.check(create(h,'create-again',b,limit=2)['disposition']=='ALREADY_EXISTS','lost creation response never resets')
        h.check(create(h,'different-budget',b,limit=2,max_admissions=1,expected=3)['code']=='CONSUMER_EXISTS','immutable definition budget')
        h.check(call(h,'missing-exact-domain',b,'create','invalid',issuer='A',scope='',reason='invalid',expected=3)['code']=='PROJECTION_DEFINITION_INVALID','one exact domain required')
        h.check(consumer_call(h,'wrong-reset',b,'reset','summary',expected=3,expected_revision=r['consumer']['revision'],start='now',reason='cannot skip')['code']=='PROJECTION_ATOMIC_TRANSITION_REQUIRED','ordinary reset cannot detach result')
        for body in [wire(7,'summary',bytes(31)),wire(8,'summary',b'x'),wire(10,'summary')]:
            ok,err=raw_control(d.control,body);h.check(not ok and 'consumer' not in err,'strict extended request')
        before=(b/'state.journal').read_bytes()
        for i in range(8):
            r=call(h,f'observe-{i}',b,'status');h.check(r['projection_work']['source_records_visited']==0,'status scans no source')
            h.check(read(h,f'empty-{i}',b)['returned_records']==0,'empty read issues no page')
        h.check((b/'state.journal').read_bytes()==before,'successful empty/status observations append nothing')
        for i in range(31):
            r=call(h,f'bounded-rebuild-{i}',b,'rebuild',expected_revision=r['consumer']['revision'],reason='explicit bounded zero-result rebuild')
        h.check(call(h,'rebuild-history-excess',b,'rebuild',expected_revision=r['consumer']['revision'],reason='past history bound',expected=3)['code']=='CONSUMER_HISTORY_LIMIT','projection shares finite 32-epoch history')
        final=call(h,'full-rebuild-history',b,'status');h.check(len(final['consumer']['projection']['retired_results'])==31,'bounded historical results remain inspectable')
        h.run('empty-history-compact',['compact','--control',str(d.control)])
        d.shutdown()
    case('strict_definition_permission_and_empty_work',strict)

    def semantics():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'semantics')
        first=send(h,'one',a,'A',data='abc');send(h,'hidden',c,'C',data='not readable')
        send(h,'two',a,'A',data='12345');third=operation('correction-one')
        revise(h,'correct-one',a/'control.sock','A','B','query/series',third,first,'1234567');wait_state(h,a,third,'ACKED','correct-one-ack')
        fourth=operation('correction-two');revise(h,'correct-two',a/'control.sock','A','B','query/series',fourth,third,'xy');wait_state(h,a,fourth,'ACKED','correct-two-ack')
        r=create(h,'summary-create',b,limit=2);allrows=[]
        for i in range(2):
            page=read(h,f'page-{i}',b);allrows+=page['records'];batch=page['consumer']['pending_batch']['id']
            h.check(consumer_call(h,f'ordinary-ack-{i}',b,'ack','summary',expected=3,batch=batch)['code']=='PROJECTION_ATOMIC_TRANSITION_REQUIRED','cannot acknowledge without projection')
            r=call(h,f'project-{i}',b,'process',batch=batch);check_result(h,r,allrows)
            h.check(r['consumer']['projection']['last_source_operations']==[x['operation_id'] for x in page['records']],'exact bounded input references')
            same=call(h,f'project-replay-{i}',b,'process',batch=batch)
            h.check(same['disposition']=='ALREADY_ACKNOWLEDGED' and same['consumer']==r['consumer'],'duplicate process no effect')
        h.check(r['consumer']['projection']['result']['current_payload_bytes']==7,'current bytes replace corrected head only')
        old=r['consumer']['projection']['result'];revision=r['consumer']['revision']
        rebuilt=call(h,'rebuild',b,'rebuild',expected_revision=revision,reason='explicitly reconstruct from retained history')
        h.check(rebuilt['consumer']['projection']['result']['admissions']==0,'atomic rebuild clears result and progress')
        h.check(call(h,'stale-rebuild',b,'rebuild',expected_revision=revision,reason='repeat stale request',expected=3)['code']=='CONSUMER_REVISION_CONFLICT','stale reset cannot skip later work')
        for i in range(2):
            p=read(h,f'rebuild-read-{i}',b);r=call(h,f'rebuild-project-{i}',b,'process',batch=p['consumer']['pending_batch']['id'])
        final=call(h,'rebuilt-status',b,'status');h.check(final['consumer']['projection']['result']==old,'independent repeat-safe rebuild')
        h.check(final['consumer']['projection']['retired_results']==[old],'old result retained beside adoption provenance')
        h.run('compact-summary',['compact','--control',str(bd.control)]);bd.shutdown();bd=h.start('summary-restart',bc,b)
        h.check(call(h,'checkpoint-summary',b,'status')['consumer']==final['consumer'],'checkpoint replay preserves complete result and reset history')
        (h.output/'SUMMARY-RESULT.json').write_text(json.dumps({'input_rows':allrows,'final_consumer':final['consumer']},indent=2)+'\n')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('independent_summary_corrections_and_rebuild',semantics)

    def budgets():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'budget');create(h,'small-budget',b,max_admissions=1,limit=1)
        send(h,'budget-one',a,'A',data='arbitrary-not-json');p=read(h,'budget-one-page',b)
        one=call(h,'budget-one-project',b,'process',batch=p['consumer']['pending_batch']['id'])
        send(h,'budget-two',a,'A',data='unsupported schema is still metadata');p=read(h,'budget-two-page',b)
        before=call(h,'budget-before',b,'status')['consumer']
        h.check(call(h,'budget-exceeded',b,'process',batch=p['consumer']['pending_batch']['id'],expected=3)['code']=='PROJECTION_ADMISSION_LIMIT','finite admission ceiling')
        after=call(h,'budget-after',b,'status')['consumer'];h.check(after==before and after['acknowledged_sequence']==1,'budget failure leaves result and issued page unchanged')
        h.check(call(h,'forged-projection',b,'process',batch='01'*32,expected=3)['code']=='CONSUMER_ACK_INVALID','forged page cannot progress')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('budget_and_forged_page_no_partial_effect',budgets)

    def concurrent_case():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'concurrent');send(h,'parallel-original',a,'A',data='abcdef');create(h,'parallel-create',b)
        page=read(h,'parallel-page',b);batch=page['consumer']['pending_batch']['id']
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda i:call(h,f'parallel-process-{i}',b,'process',batch=batch),range(8)))
        h.check(sum(r['disposition']=='PROJECTED' for r in results)==1,'exactly one result/progress commit wins')
        st=call(h,'parallel-result',b,'status');check_result(h,st,page['records'])
        send(h,'lost-reply-source',a,'A');nextpage=read(h,'lost-reply-page',b);token=nextpage['consumer']['pending_batch']['id']
        s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);s.connect(str(bd.control));body=wire(7,'summary',bytes.fromhex(token));s.sendall(struct.pack('!I',len(body))+body);s.close()
        h.wait('lost reply commit',lambda:call(h,'lost-reply-observe',b,'status')['consumer']['acknowledged_sequence']==2)
        retry=call(h,'lost-reply-repeat',b,'process',batch=token)
        h.check(retry['disposition']=='ALREADY_ACKNOWLEDGED','lost response replay does not duplicate result')
        check_result(h,retry,page['records']+nextpage['records'])
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('concurrent_process_and_lost_response',concurrent_case)

    def principals():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'principals',True);expose_control_for_uid(b)
        send(h,'uid-source',a,'A');r=create(h,'uid-create',b,uid=UID)
        page=read(h,'uid-read',b,uid=UID);token=page['consumer']['pending_batch']['id']
        h.check(call(h,'other-uid-name',b,'status',uid=SECOND_UID,expected=3)['code']=='CONSUMER_NOT_FOUND','name and batch are not authority')
        call(h,'uid-project',b,'process',uid=UID,batch=token)
        h.check(call(h,'uid-no-rebuild',b,'rebuild',uid=UID,expected=3,expected_revision=r['consumer']['revision'],reason='not permitted')['code']=='LOCAL_CONTROL_CLASS_DENIED','reset needs administration')
        revoked=candidate(h,bc,'projection-revoked','projection-policy-g2',lambda s:s.replace(f'local_control={UID},EVIDENCE_READ,CONSUMER,PROJECTION',f'local_control={UID},EVIDENCE_READ,CONSUMER'))
        activate(h,'revoke-projection',b,revoked)
        h.check(call(h,'revoked-projection-status',b,'status',uid=UID,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','current explicit result authority required')
        h.check(consumer_call(h,'consumer-status-no-bypass',b,'status','summary',expected=3,uid=UID)['code']=='LOCAL_CONTROL_CLASS_DENIED','ordinary consumer status cannot bypass projection grant')
        restored=candidate(h,revoked,'projection-regranted','projection-policy-g3',lambda s:s.replace(f'local_control={UID},EVIDENCE_READ,CONSUMER',f'local_control={UID},EVIDENCE_READ,CONSUMER,PROJECTION'))
        activate(h,'regrant-projection',b,restored)
        h.check(call(h,'result-regranted',b,'status',uid=UID)['consumer']['acknowledged_sequence']==1,'unrelated projection permission edit does not reinterpret domain')
        # A changed read domain freezes result inspection, even through generic consumer status.
        broader=candidate(h,restored,'projection-domain-change','projection-policy-g4',lambda s:s+f'evidence_read={UID},A,query/other,METADATA\n')
        activate(h,'change-authority',b,broader)
        h.check(call(h,'policy-frozen',b,'status',uid=UID,expected=3)['code']=='CONSUMER_POLICY_CHANGED','changed read authority requires explicit rebuild')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('real_uid_ownership_and_live_policy',principals)

    def kills():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'kills');send(h,'kill-source',a,'A');create(h,'kill-create',b)
        page=read(h,'kill-page',b);batch=page['consumer']['pending_batch']['id'];bd.shutdown()
        for phase,position in [('BEFORE',0),('AFTER',1)]:
            bd=h.start('projection-kill-'+phase,bc,b,{f'NATRAV_OVERLAY_TEST_PROJECTION_{phase}_COMMIT_MS':'20000'})
            initial=(b/'state.journal').stat().st_size
            client=subprocess.Popen([str(h.binary),*pargs(b,'process',batch=batch)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            try:
                if phase=='AFTER':h.wait('project journal committed',lambda:(b/'state.journal').stat().st_size>initial,timeout=5)
                else:h.wait('projection before-commit marker',lambda:'PROJECTION_TEST_BOUNDARY' in bd.stderr_path.read_text(),timeout=5)
                bd.kill();client.communicate(timeout=5)
            finally:
                if client.poll() is None:client.kill();client.communicate()
            bd=h.start('projection-restart-'+phase,bc,b);st=call(h,'reconstruct-'+phase,b,'status')
            h.check(st['consumer']['acknowledged_sequence']==position and st['consumer']['projection']['result']['admissions']==position,'result and progress recover together at '+phase)
            if phase=='AFTER':
                check_result(h,st,page['records']);h.check(call(h,'killed-client-retry',b,'process',batch=batch)['disposition']=='ALREADY_ACKNOWLEDGED','postcommit response loss is idempotent')
            else:h.check(read(h,'precommit-page-survives',b)['consumer']['pending_batch']['id']==batch,'precommit retains exact outstanding batch')
            bd.shutdown()
        cd.shutdown();ad.shutdown()
    case('hard_kill_atomic_result_progress',kills)

    def maintenance():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'maintenance');send(h,'maintenance-first',a,'A',data='aaa');send(h,'maintenance-second',a,'A',data='bbbb')
        create(h,'maintenance-create',b,limit=1);p=read(h,'maintenance-read',b);result=call(h,'maintenance-project',b,'process',batch=p['consumer']['pending_batch']['id'])
        pending=read(h,'maintenance-pending',b);bd.shutdown()
        keys=h.runtime/'projection-keys';keys.mkdir(mode=0o700);key=new_key(h,keys,'projection-state-g1');migrate(h,'projection-migrate',b,key,'B')
        bd=start_keyed(h,'projection-keyed',bc,b,key)
        h.run('projection-compact',['compact','--control',str(bd.control)]);bd.shutdown()
        h.check(h.run('projection-auth-audit',['state-auth-audit','--state',str(b),'--node','B','--state-auth-key',str(key)])['status']=='COMPLETE','keyed semantic replay validates result')
        crypt=keys/'backup.key';archive=keys/'projection.nob';identity=h.identity('B')
        h.run('projection-backup-key',['backup-key-init','--output',str(crypt),'--generation','projection-backup-g1'])
        h.run('projection-export',['backup-export','--state',str(b),'--node','B','--generation','b-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        before=h.run('projection-before-restore',['inspect','--state',str(b),'--node','B','--state-auth-key',str(key)])
        restored=h.runtime/'projection-restored'
        h.run('projection-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','B','--generation','b-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=h.run('projection-restored-inspect',['inspect','--state',str(restored),'--node','B','--state-auth-key',str(key)])
        h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'exact offline state equality through signed encrypted restore')
        moved=candidate(h,bc,'projection-relocated','projection-relocated-g1',lambda s:s.replace(f'state={b}',f'state={restored}'))
        h.run('projection-relocate',['state-relocate','--state',str(restored),'--node','B','--candidate',str(moved),'--reason','verified projection relocation','--state-auth-key',str(key)])
        bd=start_keyed(h,'projection-restored',moved,restored,key)
        replay=read(h,'projection-restored-page',restored)
        h.check(replay['records']==pending['records'] and replay['consumer']['pending_batch']==pending['consumer']['pending_batch'],'restored page and result agree before processing')
        r=call(h,'projection-restored-process',restored,'process',batch=pending['consumer']['pending_batch']['id']);check_result(h,r,p['records']+pending['records'])
        send(h,'projection-post-restore',a,'A',data='123456');last=read(h,'projection-post-page',restored)
        r=call(h,'projection-post-process',restored,'process',batch=last['consumer']['pending_batch']['id']);check_result(h,r,p['records']+pending['records']+last['records'])
        h.run('projection-post-compact',['compact','--control',str(bd.control)]);bd.shutdown()
        h.check(h.run('projection-post-audit',['state-auth-audit','--state',str(restored),'--node','B','--state-auth-key',str(key)])['status']=='COMPLETE','post-continuation authenticated checkpoint')
        cd.shutdown();ad.shutdown()
    case('keyed_compaction_encrypted_restore_and_continuation',maintenance)

    def large():
        from run_indexed_pagination import fixture
        from run_persistent import Daemon
        state,source=fixture(h,'projection-large',2048,128,hidden=512)
        cfg=config(h,'projection-large',state,free_port())
        d=h.start('projection-large',cfg,state)
        r=create(h,'large-project-create',state,limit=128,max_admissions=10000)
        rows=[];pages=0;visits=0
        while True:
            page=read(h,f'large-projection-page-{pages}',state)
            if not page['records']:break
            rows.extend(page['records'])
            r=call(h,f'large-projection-process-{pages}',state,'process',batch=page['consumer']['pending_batch']['id'])
            check_result(h,r,rows);visits+=r['projection_work']['source_records_visited'];pages+=1
            h.check(r['projection_work']['source_records_visited']<=4*128,'bounded current-batch validation, not all consumed records')
            for label in (f'large-projection-page-{pages-1}',f'large-projection-process-{pages-1}'):
                raw=next(c['stdout'] for c in reversed(h.commands) if c['label']==label)
                h.check(len(raw.strip().encode())<=60000,'annotated projection responses honor byte ceiling')
        h.check(len(rows)==sum(x['issuer']=='A' for x in source),'entire selected history including corrections processed')
        h.run('large-projection-compact',['compact','--control',str(d.control)]);d.shutdown()
        d=h.start('large-projection-restart',cfg,state);check_result(h,call(h,'large-projection-replayed',state,'status'),rows)
        (h.output/'LARGE-PROJECTION.json').write_text(json.dumps({'stored_records':len(source),'processed_records':len(rows),'pages':pages,'process_source_record_visits':visits,'result':r['consumer']['projection']['result'],'synthetic_stored_fixture':True},indent=2)+'\n')
        d.shutdown()
    case('bounded_pages_and_checkpoint_reference',large)

    def annotated_pages():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'annotated')
        for i in range(240):
            label=f'annotated-{i}'
            submit(h,label,a/'control.sock','A','B','query/series',operation(label),'metadata')
            h.wait('aggregate annotated receipt',lambda:h.status('annotated-aggregate',a)['peers'][0]['acked']>=i+1)

        create(h,'annotated-create',b,limit=128)
        rows=[];pages=0
        while True:
            page=read(h,f'annotated-read-{pages}',b)
            if not page['records']:break
            rows+=page['records'];r=call(h,f'annotated-process-{pages}',b,'process',batch=page['consumer']['pending_batch']['id']);check_result(h,r,rows);pages+=1
        h.check(len(rows)==240 and pages>=2,'full authorization metadata plus previous source IDs fit bounded multi-page read')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('full_authorization_metadata_response_budget',annotated_pages)

    def corruption():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'corrupt');send(h,'corrupt-source',a,'A',data='abcdef');create(h,'corrupt-create',b)
        p=read(h,'corrupt-read',b);call(h,'corrupt-process',b,'process',batch=p['consumer']['pending_batch']['id']);bd.shutdown()
        journal=b/'state.journal';original=journal.read_bytes();frames=[];off=0
        while off<len(original):
            n=struct.unpack_from('!I',original,off+4)[0];body=original[off+8:off+8+n];frames.append((off,n,body));off+=40+n
        updates=[x for x in frames if x[2][0]==27];h.check(len(updates)==3,'one CREATE, ISSUE, atomic PROJECT record')
        at,n,body=updates[-1];body=bytearray(body);start=body.rfind(b'NPR1');h.check(start>0,'independent projection encoding located')
        historical=start+4+8+32+3*8
        struct.pack_into('!Q',body,historical,7) # was 6; valid structural range but wrong input effect
        checksum=hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest()
        journal.write_bytes(original[:at+8]+body+checksum+original[at+40+n:])
        h.check(h.run('projection-forged-effect',['inspect','--state',str(b),'--node','B'],expected=3)['code']=='JOURNAL_CORRUPT','valid checksum cannot decouple effect from consumed sources')
        journal.write_bytes(original)
        at,n,_=updates[1];journal.write_bytes(original[:at]+original[at+40+n:])
        h.check(h.run('projection-missing-issue',['inspect','--state',str(b),'--node','B'],expected=3)['code']=='JOURNAL_CORRUPT','atomic effect cannot replay without exact issued page')
        journal.write_bytes(original);bd=h.start('projection-corruption-restored',bc,b);h.run('projection-corrupt-compact',['compact','--control',str(bd.control)]);bd.shutdown()
        compact=journal.read_bytes();n=struct.unpack_from('!I',compact,4)[0];body=bytearray(compact[8:8+n])
        h.check(body[:5]==b'\x12NCP3','native full-state checkpoint format')
        cursor=1+4+1+4+8
        flag=body[cursor];cursor+=1+(8 if flag else 0)
        cursor+=24
        flag=body[cursor];cursor+=1+(32 if flag else 0)
        marker=body[cursor];cursor+=1
        if marker:
            size=struct.unpack_from('!H',body,cursor)[0];cursor+=2+size+8
        digest_offset=cursor;logical_start=cursor+32+8+8
        h.check(body[logical_start:logical_start+4]==b'NLS2','independent checkpoint field offsets')
        start=body.rfind(b'NPR1');struct.pack_into('!Q',body,start+4+8+32+3*8,7)
        body[digest_offset:digest_offset+32]=hashlib.sha256(b'NATRAV_OVERLAY_LOGICAL_STATE_V2\0'+body[logical_start:]).digest()
        journal.write_bytes(compact[:8]+body+hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest())
        h.check(h.run('checkpoint-forged-effect',['inspect','--state',str(b),'--node','B'],expected=3)['code']=='JOURNAL_CORRUPT','checkpoint counters checked against retained sources after both checksums recomputed')
        journal.write_bytes(compact)
        cd.shutdown();ad.shutdown()
    case('semantic_result_and_issue_corruption',corruption)


def main()->int:
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--binary',required=True,type=Path);parser.add_argument('--output',required=True,type=Path);parser.add_argument('--case',action='append');a=parser.parse_args()
    if a.output.exists():parser.error('output must not exist')
    h=Harness(a.binary,a.output);begin=time.time();passed=False
    try:cases(h,set(a.case) if a.case else None);passed=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {type(e).__name__}: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_PROJECTION_TESTS_V1','status':'PASS' if passed else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-begin}
        for name,value in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:
            (h.output/(name+'.json')).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
