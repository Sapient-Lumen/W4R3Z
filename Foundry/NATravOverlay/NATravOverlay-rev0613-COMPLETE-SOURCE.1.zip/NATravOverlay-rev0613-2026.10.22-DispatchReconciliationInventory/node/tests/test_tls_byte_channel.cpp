#include "tls.hpp"
#include "tls_bio.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <exception>
#include <functional>
#include <iostream>
#include <memory>
#include <mutex>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>

#include <openssl/bio.h>

namespace {

using natrav_overlay::AppError;
using natrav_overlay::ByteChannel;
using natrav_overlay::Deadline;
using natrav_overlay::IoCounters;
using natrav_overlay::KeyGenerationState;
using natrav_overlay::TlsByteChannelBio;
using natrav_overlay::TlsChannel;
using natrav_overlay::TlsContext;
using natrav_overlay::TlsIdentityFiles;
using natrav_overlay::TlsTrustedGeneration;
using natrav_overlay::TlsTrustedIdentity;

struct CaseRecord final {
    std::string name;
    std::size_t assertions{0U};
};

class Probe final {
public:
    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_code(
        Function&& function,
        const std::string_view code,
        const std::string_view detail) {
        bool observed = false;
        try {
            std::forward<Function>(function)();
        } catch (const AppError& error) {
            observed = error.code() == code;
        }
        check(observed, detail);
    }

    template <typename Function>
    void run_case(std::string name, Function&& function) {
        const auto before = assertions_;
        std::forward<Function>(function)();
        cases_.push_back(CaseRecord{
            .name = std::move(name),
            .assertions = assertions_ - before,
        });
    }

    [[nodiscard]] std::size_t assertions() const noexcept { return assertions_; }
    [[nodiscard]] const std::vector<CaseRecord>& cases() const noexcept {
        return cases_;
    }

private:
    std::size_t assertions_{0U};
    std::vector<CaseRecord> cases_;
};

[[nodiscard]] Deadline deadline_after_test(
    const std::chrono::milliseconds duration = std::chrono::seconds(5)) {
    return std::chrono::steady_clock::now() + duration;
}

class ScriptedChannel final : public ByteChannel {
public:
    std::deque<std::uint8_t> readable;
    std::vector<std::uint8_t> written;
    std::size_t maximum_read{3U};
    std::size_t maximum_write{2U};
    bool eof{false};
    std::string read_error;
    std::string write_error;

    [[nodiscard]] std::size_t read_some(
        const std::span<std::uint8_t> buffer,
        Deadline,
        IoCounters& counters,
        std::string_view) override {
        ++counters.poll_calls;
        ++counters.read_calls;
        if (!read_error.empty()) {
            natrav_overlay::app_fail(read_error, "scripted read failure");
        }
        if (readable.empty()) {
            if (eof) {
                return 0U;
            }
            natrav_overlay::app_fail("IO_TIMEOUT", "scripted read timeout");
        }
        const auto count = std::min({
            buffer.size(), maximum_read, readable.size()});
        for (std::size_t index = 0U; index < count; ++index) {
            buffer[index] = readable.front();
            readable.pop_front();
        }
        return count;
    }

    [[nodiscard]] std::size_t write_some(
        const datacube::OctetView bytes,
        Deadline,
        IoCounters& counters,
        std::string_view) override {
        ++counters.poll_calls;
        ++counters.write_calls;
        if (!write_error.empty()) {
            natrav_overlay::app_fail(write_error, "scripted write failure");
        }
        const auto count = std::min(bytes.size(), maximum_write);
        written.insert(written.end(), bytes.begin(), bytes.begin() +
            static_cast<std::ptrdiff_t>(count));
        return count;
    }
};

class LifetimeChannel final : public ByteChannel {
public:
    explicit LifetimeChannel(bool& destroyed) noexcept : destroyed_(destroyed) {}
    ~LifetimeChannel() override { destroyed_ = true; }

    [[nodiscard]] std::size_t read_some(
        std::span<std::uint8_t>, Deadline, IoCounters&, std::string_view) override {
        return 0U;
    }

    [[nodiscard]] std::size_t write_some(
        datacube::OctetView bytes,
        Deadline,
        IoCounters&,
        std::string_view) override {
        return bytes.size();
    }

private:
    bool& destroyed_;
};

struct Direction final {
    std::mutex mutex;
    std::condition_variable condition;
    std::deque<std::uint8_t> bytes;
    bool closed{false};
    bool reset{false};
};

class SegmentedChannel final : public ByteChannel {
public:
    SegmentedChannel(
        std::shared_ptr<Direction> incoming,
        std::shared_ptr<Direction> outgoing,
        const std::size_t read_limit,
        const std::size_t write_limit)
        : incoming_(std::move(incoming)),
          outgoing_(std::move(outgoing)),
          read_limit_(read_limit),
          write_limit_(write_limit) {}

    ~SegmentedChannel() override {
        close_write();
    }

    [[nodiscard]] std::size_t read_some(
        const std::span<std::uint8_t> buffer,
        const Deadline deadline,
        IoCounters& counters,
        std::string_view operation) override {
        std::unique_lock<std::mutex> lock(incoming_->mutex);
        while (incoming_->bytes.empty() && !incoming_->closed &&
               !incoming_->reset) {
            ++counters.poll_calls;
            if (incoming_->condition.wait_until(lock, deadline) ==
                std::cv_status::timeout) {
                natrav_overlay::app_fail("IO_TIMEOUT", operation);
            }
        }
        if (incoming_->reset) {
            natrav_overlay::app_fail("PEER_RESET", operation);
        }
        ++counters.read_calls;
        if (incoming_->bytes.empty()) {
            return 0U;
        }
        const auto count = std::min({
            buffer.size(), read_limit_, incoming_->bytes.size()});
        for (std::size_t index = 0U; index < count; ++index) {
            buffer[index] = incoming_->bytes.front();
            incoming_->bytes.pop_front();
        }
        return count;
    }

    [[nodiscard]] std::size_t write_some(
        const datacube::OctetView bytes,
        Deadline,
        IoCounters& counters,
        std::string_view operation) override {
        std::lock_guard<std::mutex> lock(outgoing_->mutex);
        if (outgoing_->closed || outgoing_->reset) {
            natrav_overlay::app_fail("SOCKET_WRITE_CLOSED", operation);
        }
        const auto count = std::min(bytes.size(), write_limit_);
        if (count == 0U) {
            natrav_overlay::app_fail("SOCKET_WRITE_CLOSED", operation);
        }
        outgoing_->bytes.insert(
            outgoing_->bytes.end(), bytes.begin(), bytes.begin() +
                static_cast<std::ptrdiff_t>(count));
        ++counters.write_calls;
        outgoing_->condition.notify_all();
        return count;
    }

    void close_write() noexcept {
        if (!outgoing_) {
            return;
        }
        std::lock_guard<std::mutex> lock(outgoing_->mutex);
        outgoing_->closed = true;
        outgoing_->condition.notify_all();
    }

private:
    std::shared_ptr<Direction> incoming_;
    std::shared_ptr<Direction> outgoing_;
    std::size_t read_limit_{1U};
    std::size_t write_limit_{1U};
};

struct ChannelPair final {
    std::shared_ptr<Direction> client_to_server = std::make_shared<Direction>();
    std::shared_ptr<Direction> server_to_client = std::make_shared<Direction>();
    SegmentedChannel client{
        server_to_client, client_to_server, 5U, 7U};
    SegmentedChannel server{
        client_to_server, server_to_client, 3U, 11U};
};

void tls_write_all(
    TlsChannel& channel,
    const std::string_view text,
    IoCounters& counters) {
    std::size_t offset = 0U;
    while (offset < text.size()) {
        const auto* begin = reinterpret_cast<const std::uint8_t*>(text.data());
        const auto count = channel.write_some(
            datacube::OctetView(begin + offset, text.size() - offset),
            deadline_after_test(), counters, "segmented TLS write");
        if (count == 0U || count > text.size() - offset) {
            throw std::runtime_error("invalid TLS write progress");
        }
        offset += count;
    }
}

[[nodiscard]] std::string tls_read_exact(
    TlsChannel& channel,
    const std::size_t length,
    IoCounters& counters) {
    std::string result(length, '\0');
    std::size_t offset = 0U;
    while (offset < length) {
        auto* begin = reinterpret_cast<std::uint8_t*>(result.data());
        const auto count = channel.read_some(
            std::span<std::uint8_t>(begin + offset, length - offset),
            deadline_after_test(), counters, "segmented TLS read");
        if (count == 0U || count > length - offset) {
            throw std::runtime_error("unexpected TLS EOF or progress");
        }
        offset += count;
    }
    return result;
}

[[nodiscard]] TlsIdentityFiles identity(
    const char* certificate,
    const char* private_key,
    const char* pin) {
    return TlsIdentityFiles{
        .certificate = certificate,
        .private_key = private_key,
        .expected_spki_sha256 = natrav_overlay::parse_spki_sha256(pin),
    };
}

}  // namespace

int main(int argc, char* argv[]) {
    try {
        if (argc != 7) {
            throw std::runtime_error(
                "expected client cert/key/pin and server cert/key/pin");
        }
        Probe probe;
        const auto client_identity = identity(argv[1], argv[2], argv[3]);
        const auto server_identity = identity(argv[4], argv[5], argv[6]);

        probe.run_case("BIO short progress and controls", [&] {
            ScriptedChannel channel;
            channel.readable = {0x10U, 0x11U, 0x12U, 0x13U};
            TlsByteChannelBio bio(channel);
            probe.check(bio.get() != nullptr, "custom BIO allocated");
            probe.check(BIO_ctrl(bio.get(), BIO_CTRL_FLUSH, 0L, nullptr) == 1L,
                "flush control is explicitly supported");
            probe.check(BIO_ctrl(bio.get(), BIO_CTRL_PENDING, 0L, nullptr) == 0L,
                "pending control is conservative");
            probe.check(BIO_ctrl(bio.get(), 0x7fff, 0L, nullptr) == 0L,
                "unknown control is rejected");

            IoCounters counters;
            std::array<char, 8U> read_buffer{};
            std::size_t read_bytes = 0U;
            bio.begin_operation(deadline_after_test(), counters, "direct BIO read");
            const int read_result = BIO_read_ex(
                bio.get(), read_buffer.data(), read_buffer.size(), &read_bytes);
            bio.complete_operation();
            probe.check(read_result == 1 && read_bytes == 3U,
                "read callback preserves short progress");
            probe.check(static_cast<unsigned char>(read_buffer[0]) == 0x10U &&
                        static_cast<unsigned char>(read_buffer[2]) == 0x12U,
                "read callback preserves exact bytes");

            constexpr std::array<char, 4U> written{{'a', 'b', 'c', 'd'}};
            std::size_t written_bytes = 0U;
            bio.begin_operation(deadline_after_test(), counters, "direct BIO write");
            const int write_result = BIO_write_ex(
                bio.get(), written.data(), written.size(), &written_bytes);
            bio.complete_operation();
            probe.check(write_result == 1 && written_bytes == 2U,
                "write callback preserves short progress");
            probe.check(channel.written == std::vector<std::uint8_t>({'a', 'b'}),
                "write callback preserves exact bytes");
            probe.check(counters.poll_calls == 2U,
                "carrier wait observations are merged");
            probe.check(counters.read_calls == 0U && counters.write_calls == 0U,
                "record-level calls do not redefine public TLS call counters");
        });

        probe.run_case("BIO EOF, timeout, and callback exception", [&] {
            ScriptedChannel channel;
            channel.eof = true;
            TlsByteChannelBio bio(channel);
            IoCounters counters;
            std::array<char, 4U> buffer{};
            std::size_t count = 99U;
            bio.begin_operation(deadline_after_test(), counters, "direct EOF");
            const int eof_result = BIO_read_ex(
                bio.get(), buffer.data(), buffer.size(), &count);
            bio.complete_operation();
            probe.check(eof_result == 0 && count == 0U,
                "raw EOF is reported without a callback exception");

            channel.eof = false;
            probe.expect_code([&] {
                std::size_t ignored = 0U;
                bio.begin_operation(deadline_after_test(), counters, "direct timeout");
                const int result = BIO_read_ex(
                    bio.get(), buffer.data(), buffer.size(), &ignored);
                probe.check(result == 0, "timeout did not cross C callback");
                bio.complete_operation();
            }, "IO_TIMEOUT", "timeout rethrows after OpenSSL returns");

            channel.read_error = "BIO_TEST_EXCEPTION";
            probe.expect_code([&] {
                std::size_t ignored = 0U;
                bio.begin_operation(deadline_after_test(), counters, "direct exception");
                const int result = BIO_read_ex(
                    bio.get(), buffer.data(), buffer.size(), &ignored);
                probe.check(result == 0, "exception did not cross C callback");
                bio.complete_operation();
            }, "BIO_TEST_EXCEPTION", "exact callback exception is retained");

            channel.read_error.clear();
            channel.eof = true;
            bio.begin_operation(deadline_after_test(), counters, "post-failure reuse");
            const int reused = BIO_read_ex(
                bio.get(), buffer.data(), buffer.size(), &count);
            bio.complete_operation();
            probe.check(reused == 0, "operation state clears after rethrow");
        });

        probe.run_case("BIO backing-channel lifetime", [&] {
            bool destroyed = false;
            auto channel = std::make_unique<LifetimeChannel>(destroyed);
            {
                TlsByteChannelBio bio(*channel);
                BIO* owned = bio.release();
                probe.check(owned != nullptr, "BIO ownership transfers explicitly");
                BIO_free(owned);
                probe.check(!destroyed,
                    "BIO destruction does not destroy the backing channel");
            }
            probe.check(!destroyed,
                "adapter destruction leaves caller-owned channel alive");
            channel.reset();
            probe.check(destroyed,
                "backing channel remains independently owned and bounded");
        });

        probe.run_case("descriptor-free segmented TLS handshake", [&] {
            ChannelPair pair;
            TlsContext client_context(client_identity);
            TlsContext server_context(server_identity);
            const std::vector<TlsTrustedIdentity> trusted_client{{
                .node_id = "CLIENT",
                .generations = {TlsTrustedGeneration{
                    .generation = "client-g1",
                    .spki_sha256 = client_identity.expected_spki_sha256,
                    .state = KeyGenerationState::active,
                }},
            }};
            IoCounters client_tls;
            IoCounters server_tls;
            IoCounters client_application;
            IoCounters server_application;
            std::exception_ptr server_failure;
            std::string server_peer;
            std::string server_request;
            std::size_t server_close_result = 1U;

            std::thread server([&] {
                try {
                    auto channel = TlsChannel::accept(
                        server_context, pair.server, trusted_client,
                        deadline_after_test(), server_tls);
                    server_peer = channel.session().peer_node;
                    server_request = tls_read_exact(
                        channel, std::string_view("client-payload").size(),
                        server_application);
                    tls_write_all(channel, "server-payload", server_application);
                    std::array<std::uint8_t, 1U> eof_buffer{};
                    server_close_result = channel.read_some(
                        eof_buffer, deadline_after_test(), server_application,
                        "server close-notify read");
                    channel.close_notify(deadline_after_test(), server_tls);
                } catch (...) {
                    server_failure = std::current_exception();
                }
            });

            auto client = TlsChannel::connect(
                client_context,
                pair.client,
                "SERVER",
                "server-g1",
                KeyGenerationState::active,
                server_identity.expected_spki_sha256,
                deadline_after_test(),
                client_tls);
            probe.check(client.session().peer_node == "SERVER",
                "client session binds configured peer identity");
            probe.check(client.session().protocol == "TLSv1.3",
                "segmented channel negotiates TLS 1.3");
            tls_write_all(client, "client-payload", client_application);
            probe.check(tls_read_exact(
                    client, std::string_view("server-payload").size(),
                    client_application) == "server-payload",
                "server plaintext traverses segmented channel exactly");
            client.close_notify(deadline_after_test(), client_tls);
            std::array<std::uint8_t, 1U> eof_buffer{};
            const auto client_close_result = client.read_some(
                eof_buffer, deadline_after_test(), client_application,
                "client close-notify read");

            server.join();
            if (server_failure) {
                std::rethrow_exception(server_failure);
            }
            probe.check(server_peer == "CLIENT",
                "server session selects trusted generation by SPKI");
            probe.check(server_request == "client-payload",
                "client plaintext traverses segmented channel exactly");
            probe.check(server_close_result == 0U && client_close_result == 0U,
                "bidirectional close-notify is distinguished from truncation");
            probe.check(client_tls.poll_calls > 0U && server_tls.poll_calls > 0U,
                "TLS used the ByteChannel wait contract");
            probe.check(client_application.read_calls > 0U &&
                        client_application.write_calls > 0U &&
                        server_application.read_calls > 0U &&
                        server_application.write_calls > 0U,
                "plaintext TLS calls retain bounded accounting");
        });

        probe.run_case("handshake early EOF, timeout, and reset", [&] {
            TlsContext client_context(client_identity);
            auto expected_pin = server_identity.expected_spki_sha256;

            ScriptedChannel eof_channel;
            eof_channel.eof = true;
            eof_channel.maximum_write = 4096U;
            IoCounters eof_counters;
            probe.expect_code([&] {
                static_cast<void>(TlsChannel::connect(
                    client_context, eof_channel, "SERVER", "server-g1",
                    KeyGenerationState::active, expected_pin,
                    deadline_after_test(), eof_counters));
            }, "TLS_HANDSHAKE_FAILED", "early EOF has handshake classification");

            ScriptedChannel timeout_channel;
            timeout_channel.maximum_write = 4096U;
            IoCounters timeout_counters;
            probe.expect_code([&] {
                static_cast<void>(TlsChannel::connect(
                    client_context, timeout_channel, "SERVER", "server-g1",
                    KeyGenerationState::active, expected_pin,
                    deadline_after_test(), timeout_counters));
            }, "IO_TIMEOUT", "backing timeout remains explicit");

            ScriptedChannel reset_channel;
            reset_channel.read_error = "PEER_RESET";
            reset_channel.maximum_write = 4096U;
            IoCounters reset_counters;
            probe.expect_code([&] {
                static_cast<void>(TlsChannel::connect(
                    client_context, reset_channel, "SERVER", "server-g1",
                    KeyGenerationState::active, expected_pin,
                    deadline_after_test(), reset_counters));
            }, "TLS_HANDSHAKE_FAILED", "carrier reset maps to handshake failure");
        });

        std::cout << "{\"format\":\"NATRAV_TLS_BYTE_CHANNEL_PROBE_V1\","
                  << "\"status\":\"PASS\",\"cases\":[";
        for (std::size_t index = 0U; index < probe.cases().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            const auto& record = probe.cases()[index];
            std::cout << "{\"name\":\"" << record.name
                      << "\",\"assertions\":" << record.assertions << '}';
        }
        std::cout << "],\"assertions\":" << probe.assertions() << "}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
