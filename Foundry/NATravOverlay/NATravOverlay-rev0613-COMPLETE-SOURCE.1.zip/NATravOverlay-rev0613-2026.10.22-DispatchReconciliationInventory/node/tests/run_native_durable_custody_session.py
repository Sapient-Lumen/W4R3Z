#!/usr/bin/env python3
"""Focused native NOS1 durable custody-session integration and negative controls."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import socket
import ssl
import struct
import subprocess
import sys
import time
from typing import Any

from run_persistent import Harness, free_port, operation
from run_peer_sessions import (
    SESSION_OPEN, SESSION_OPEN_ACK, SESSION_REQUEST, SESSION_RESPONSE,
    decode_session, encode_session, frame, receive_frame, submit,
)
from run_integration import hello
from run_live_configuration import candidate, activate
from run_runtime_adapter_configuration import upgrade, write
from run_handoff_key_policy import record as handoff_record

ZERO = "0" * 64
RULE_ID = "a-r-native"
RULE_GENERATION = 1
DROP_AFTER_ADMISSION = "NATRAV_OVERLAY_TEST_SESSION_DROP_AFTER_ADMISSION_OPERATION"


def cert_sha256(path: Path) -> str:
    der = subprocess.check_output([
        "openssl", "x509", "-in", str(path), "-outform", "DER"
    ])
    return hashlib.sha256(der).hexdigest()


def grant(*, state: str = "ACTIVE", maximum_active: int = 8,
          maximum_lifetime_ms: int = 600_000) -> str:
    return "\n".join([
        "NATRAV_CUSTODY_RELAY_GRANT_V1",
        "id=a-r",
        "generation=1",
        f"predecessor_sha256={ZERO}",
        "origin=A",
        "origin_signing_generation=a-g1",
        "final_recipient=R",
        "final_signing_generation=r-g1",
        "custodian=A",
        "custodian_signing_generation=a-g1",
        "next_hop=R",
        "next_hop_signing_generation=r-g1",
        f"maximum_envelope_lifetime_ms={maximum_lifetime_ms}",
        "maximum_hops=1",
        f"maximum_active_envelopes={maximum_active}",
        "maximum_capsule_bytes=68000",
        f"state={state}",
        "",
    ])


def grant_commitment_text(record: str) -> str:
    lines = record.splitlines()
    assert lines[0] == "NATRAV_CUSTODY_RELAY_GRANT_V1"
    assert lines[-1].startswith("state=")
    return "NATRAV_CUSTODY_RELAY_GRANT_COMMITMENT_V1\n" + \
        "\n".join(lines[1:-1]) + "\n"


def grant_commitment(record: str) -> str:
    return hashlib.sha256(grant_commitment_text(record).encode("ascii")).hexdigest()


def service_rule(*, relay_grant: str, a_certificate: str, r_certificate: str,
                 state: str = "ACTIVE", maximum_pending: int = 8,
                 maximum_bundle_bytes: int = 60_000,
                 maximum_attempts: int = 4,
                 maximum_window_ms: int = 180_000,
                 expiry_ms: int | None = None) -> str:
    if expiry_ms is None:
        expiry_ms = int(time.time() * 1000) + 600_000
    return "\n".join([
        "NATRAV_CUSTODY_SESSION_RULE_V1",
        f"id={RULE_ID}",
        f"generation={RULE_GENERATION}",
        f"predecessor_sha256={ZERO}",
        "grant_id=a-r",
        "grant_generation=1",
        f"grant_commitment_sha256={grant_commitment(relay_grant)}",
        f"custodian_certificate_sha256={a_certificate}",
        f"next_hop_certificate_sha256={r_certificate}",
        f"maximum_pending_cases={maximum_pending}",
        f"maximum_bundle_bytes={maximum_bundle_bytes}",
        f"maximum_attempts={maximum_attempts}",
        f"maximum_transfer_window_ms={maximum_window_ms}",
        f"authority_expires_unix_ms={expiry_ms}",
        f"state={state}",
        "",
    ])


def policy_lines(bindings: list[bytes], relay_grant: str,
                 rule: str) -> str:
    return "".join(
        f"handoff_key_hex={handoff_record(binding).encode('ascii').hex()}\n"
        for binding in bindings
    ) + f"custody_grant_hex={relay_grant.encode('ascii').hex()}\n" + \
        f"custody_service_hex={rule.encode('ascii').hex()}\n"


def replace_service_rule(text: str, rule: str) -> str:
    lines = [line for line in text.splitlines()
             if not line.startswith("custody_service_hex=")]
    return "\n".join(lines) + "\n" + \
        f"custody_service_hex={rule.encode('ascii').hex()}\n"


def route(path: Path, bindings: list[bytes]) -> Path:
    path.write_text(
        "NATRAV_CUSTODY_ROUTE_V1\n" +
        "".join(f"binding_hex={binding.hex()}\n" for binding in bindings)
    )
    path.chmod(0o600)
    return path


def sha_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def launch_server(h: Harness, label: str, config: Path,
                  environment: dict[str, str] | None = None) -> subprocess.Popen[str]:
    env = os.environ.copy()
    if environment:
        env.update(environment)
    stdout_path = h.logs / f"{label}.stdout.txt"
    stderr_path = h.logs / f"{label}.stderr.txt"
    process = subprocess.Popen(
        [str(h.binary), "custody-service-v1-serve", "--config", str(config),
         "--rule", RULE_ID, "--rule-generation", str(RULE_GENERATION),
         "--once", "yes"],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env,
    )
    assert process.stdout is not None
    ready, _, _ = select.select([process.stdout], [], [], 8.0)
    if not ready:
        process.kill()
        out, err = process.communicate(timeout=5)
        stdout_path.write_text(out)
        stderr_path.write_text(err)
        raise AssertionError(f"{label}: receiver did not report ready: {out!r} {err!r}")
    first = process.stdout.readline()
    try:
        decoded = json.loads(first)
    except json.JSONDecodeError as exc:
        process.kill()
        out, err = process.communicate(timeout=5)
        raise AssertionError(f"{label}: invalid readiness: {first!r} {out!r} {err!r}") from exc
    if decoded.get("format") != "NATRAV_NATIVE_CUSTODY_SESSION_READY_V1":
        process.kill()
        out, err = process.communicate(timeout=5)
        raise AssertionError(f"{label}: not ready: {decoded!r} {out!r} {err!r}")
    setattr(process, "_natrav_ready", first)
    setattr(process, "_natrav_stdout_path", stdout_path)
    setattr(process, "_natrav_stderr_path", stderr_path)
    return process


def finish_server(process: subprocess.Popen[str], timeout: float = 12.0) -> tuple[int, str, str]:
    out, err = process.communicate(timeout=timeout)
    complete = getattr(process, "_natrav_ready", "") + out
    Path(getattr(process, "_natrav_stdout_path")).write_text(complete)
    Path(getattr(process, "_natrav_stderr_path")).write_text(err)
    assert process.returncode is not None
    return process.returncode, complete, err


def service_root(state: Path) -> Path:
    return state / "custody-session-v1" / RULE_ID / str(RULE_GENERATION)


def service_cases(state: Path) -> list[Path]:
    root = service_root(state) / "cases"
    if not root.exists():
        return []
    return sorted(path for path in root.iterdir() if path.is_dir())


def send_command(config: Path, bundle: Path, route_id: str = "default") -> list[str]:
    return [
        "custody-service-v1-send", "--config", str(config),
        "--rule", RULE_ID, "--rule-generation", str(RULE_GENERATION),
        "--route", route_id, "--bundle", str(bundle),
    ]


def isolated_config(base: Path, output: Path, state: Path,
                    generation: str, rule: str) -> Path:
    state.mkdir(parents=True, mode=0o700)
    state.chmod(0o700)
    lines: list[str] = []
    for line in base.read_text().splitlines():
        if line.startswith("runtime_generation=") or \
                line.startswith("custody_service_hex="):
            continue
        if line.startswith("state="):
            lines.append(f"state={state}")
        else:
            lines.append(line)
    lines.append(f"custody_service_hex={rule.encode('ascii').hex()}")
    lines.append(f"runtime_generation={generation}")
    output.write_text("\n".join(lines) + "\n")
    output.chmod(0o600)
    return output


def parse_protocol_error(payload: bytes) -> dict[str, str]:
    if len(payload) < 6 or payload[:5] != b"NOA1\x04":
        raise AssertionError(f"expected protocol error, got {payload[:16]!r}")
    offset = 5
    present = payload[offset]
    offset += 1
    operation_hex = ""
    if present == 1:
        if len(payload) < offset + 32:
            raise AssertionError("short protocol error operation")
        operation_hex = payload[offset:offset + 32].hex()
        offset += 32
    elif present != 0:
        raise AssertionError("invalid protocol error operation marker")

    def text16() -> str:
        nonlocal offset
        if len(payload) < offset + 2:
            raise AssertionError("short protocol error text length")
        size = struct.unpack("!H", payload[offset:offset + 2])[0]
        offset += 2
        if len(payload) < offset + size:
            raise AssertionError("short protocol error text")
        value = payload[offset:offset + size].decode("utf-8")
        offset += size
        return value

    code = text16()
    detail = text16()
    if offset != len(payload):
        raise AssertionError("trailing protocol error bytes")
    return {"operation": operation_hex, "code": code, "detail": detail}


def replay_conflict(h: Harness, port: int, request_id: str,
                    offer_path: Path) -> dict[str, str]:
    offer = bytearray(offer_path.read_bytes())
    if not offer:
        raise AssertionError("empty retained offer")
    offer[-1] ^= 1
    request = bytes.fromhex(request_id)
    app = b"NOA1" + bytes([9]) + request + struct.pack("!I", len(offer)) + bytes(offer)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.maximum_version = ssl.TLSVersion.TLSv1_3
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    identity = h.identity("A")
    context.load_cert_chain(str(identity.certificate), str(identity.private_key))
    context.set_alpn_protocols(["natrav-overlay/1"])
    with socket.create_connection(("127.0.0.1", port), timeout=4) as raw:
        with context.wrap_socket(raw, server_hostname=None) as channel:
            channel.settimeout(4)
            hello_request = operation("rev0610-replay-conflict-hello")
            channel.sendall(frame(hello("A", hello_request)))
            ack = json.loads(receive_frame(channel))
            if ack.get("kind") != "HELLO_ACK" or \
                    ack.get("request_id") != hello_request:
                raise AssertionError(f"HELLO_ACK mismatch: {ack!r}")
            session_id = hashlib.sha256(b"rev0610-replay-conflict-session").digest()
            limits = (4, 4_194_304, 30_000, 2_000)
            channel.sendall(frame(encode_session(
                SESSION_OPEN, session_id, 0, b"\0" * 32, limits=limits)))
            opened = decode_session(receive_frame(channel))
            if opened["kind"] != SESSION_OPEN_ACK or \
                    opened["session"] != session_id:
                raise AssertionError(f"NOS1 OPEN_ACK mismatch: {opened!r}")
            channel.sendall(frame(encode_session(
                SESSION_REQUEST, session_id, 1, request, app)))
            response = decode_session(receive_frame(channel))
            if response["kind"] != SESSION_RESPONSE or \
                    response["operation"] != request:
                raise AssertionError(f"NOS1 response mismatch: {response!r}")
            decoded = parse_protocol_error(response["payload"])
            channel.sendall(frame(encode_session(
                5, session_id, 2, b"\0" * 32)))
            closed = decode_session(receive_frame(channel))
            if closed["kind"] != 6 or closed["sequence"] != 2:
                raise AssertionError(f"NOS1 CLOSE_ACK mismatch: {closed!r}")
            return decoded


def suite(h: Harness) -> None:
    h.work.chmod(0o700)
    values: dict[str, Any] = {}

    def initialize() -> None:
        a_state = h.runtime / "a"
        r_state = h.runtime / "r"
        a_port, r_port, dead_port = free_port(), free_port(), free_port()
        a_seed = h.config("a-seed", "A", a_state, a_port,
                          [("R", r_port, 50, 250, 8, 600_000)], trusted=["R"])
        r_seed = h.config("r-seed", "R", r_state, r_port,
                          [("A", a_port, 50, 250, 8, 600_000)], trusted=["A"])
        write(a_seed, upgrade(a_seed.read_text(), "a-v19", 19))
        write(r_seed, upgrade(r_seed.read_text(), "r-v19", 19))

        r = h.start("initialize-r", r_seed, r_state)
        r.shutdown()
        a = h.start("initialize-a", a_seed, a_state)
        operations: dict[str, str] = {}
        for name in ("normal", "loss", "route", "repair-sender",
                     "repair-receiver", "spare-one", "spare-two"):
            op = operation(f"rev0610-native-custody-{name}")
            operations[name] = op
            submit(h, f"queue-{name}", a.control, "A", "R", "test/three",
                   op, f"native durable custody session {name}")
        a.shutdown()

        for node, seed in (("A", a_seed), ("R", r_seed)):
            key = h.work / f"{node.lower()}-handoff"
            result = h.run(f"handoff-key-{node}", [
                "handoff-key-init", "--config", str(seed),
                "--key-directory", str(key),
                "--generation", f"{node.lower()}-h1",
            ])
            binding = (key / "binding.nhkb").read_bytes()
            h.check(result is not None and
                    result["binding_sha256"] == hashlib.sha256(binding).hexdigest(),
                    f"{node} exact handoff binding")
            values[f"{node}key"] = key
            values[f"{node}binding"] = binding

        relay = grant()
        a_cert = cert_sha256(h.identity("A").certificate)
        r_cert = cert_sha256(h.identity("R").certificate)
        authority_expiry = int(time.time() * 1000) + 600_000
        rule = service_rule(
            relay_grant=relay, a_certificate=a_cert, r_certificate=r_cert,
            expiry_ms=authority_expiry,
        )
        records = policy_lines(
            [values["Abinding"], values["Rbinding"]], relay, rule)
        for node, seed, state in (("A", a_seed, a_state), ("R", r_seed, r_state)):
            def modify(text: str, *, node: str = node) -> str:
                extra = ""
                if node == "A":
                    extra = f"peer_route=R,dead,1,ENABLED,127.0.0.1:{dead_port}\n"
                return text.replace("CONFIG_V19", "CONFIG_V22") + extra + records
            config = candidate(
                h, seed, f"{node.lower()}-v22", f"{node.lower()}-v22", modify)
            checked = h.run(f"check-{node}-v22", [
                "config-check", "--config", str(config)
            ])
            h.check(checked is not None and
                    checked["format"] == "NATRAV_OVERLAY_CONFIG_V22" and
                    len(checked["custody_session_policy"]["rules"]) == 1,
                    f"{node} accepts exact V22 authority")
            daemon = h.start(f"activate-{node}-v22", seed, state)
            activate(h, f"activate-{node}-v22", state, config)
            daemon.shutdown()
            values[f"{node}v22"] = config

        route_file = route(h.work / "a-r-route.txt",
                           [values["Abinding"], values["Rbinding"]])

        def build_bundle(name: str) -> Path:
            capsule = h.work / f"{name}.nhcp"
            exported = h.run(f"handoff-export-{name}", [
                "handoff-export", "--config", str(a_seed),
                "--key-directory", str(values["Akey"]),
                "--recipient-binding", str(values["Rkey"] / "binding.nhkb"),
                "--recipient-binding-sha256", sha_file(values["Rkey"] / "binding.nhkb"),
                "--operation-id", operations[name], "--kind", "operation",
                "--expires-ms", str(int(time.time() * 1000) + 300_000),
                "--output", str(capsule),
            ])
            h.check(exported is not None and
                    exported["status"] == "EXPORTED_NOT_DELIVERED",
                    f"{name} export remains distinct from delivery")
            bundle = h.work / f"{name}.nhcb"
            now = int(time.time() * 1000)
            created = h.run(f"custody-create-{name}", [
                "custody-create", "--config", str(a_seed),
                "--route", str(route_file), "--capsule", str(capsule),
                "--created-ms", str(now), "--expires-ms", str(now + 240_000),
                "--output", str(bundle),
            ])
            h.check(created is not None and
                    created["status"] == "CREATED_CUSTODY_HELD",
                    f"{name} canonical custody bundle created")
            return bundle

        bundles = {name: build_bundle(name) for name in operations}
        values.update({
            "Aseed": a_seed, "Rseed": r_seed,
            "Astate": a_state, "Rstate": r_state,
            "a_port": a_port, "r_port": r_port, "dead_port": dead_port,
            "operations": operations, "bundles": bundles,
            "route": route_file, "relay": relay, "rule": rule,
            "a_cert": a_cert, "r_cert": r_cert,
            "authority_expiry": authority_expiry,
        })

    h.case("accepted_v22_authority_and_bundles", initialize)

    def normal_exchange() -> None:
        server = launch_server(h, "normal-receiver", values["Rseed"])
        sent = h.run("normal-send", send_command(
            values["Aseed"], values["bundles"]["normal"]), timeout=15)
        rc, out, err = finish_server(server)
        h.check(rc == 0, f"receiver completed cleanly: {out!r} {err!r}")
        h.check(sent is not None and sent["status"] == "ACCEPTED" and
                sent["attempts"] == 1 and sent["acceptance_durable"] is True,
                "native NOS1 sender reached durable acceptance")
        request = sent["request_id"]
        a_case = service_root(values["Astate"]) / "cases" / request
        r_case = service_root(values["Rstate"]) / "cases" / request
        h.check(a_case.is_dir() and r_case.is_dir(),
                "one exact request case retained at both endpoints")
        h.check((a_case / "offer.bin").read_bytes() ==
                (r_case / "offer.bin").read_bytes(),
                "both endpoints retain byte-identical offer")
        h.check((a_case / "acceptance.bin").read_bytes() ==
                (r_case / "acceptance.bin").read_bytes(),
                "sender retains byte-identical receiver acceptance")
        status = h.run("normal-status", [
            "custody-service-v1-status", "--config", str(values["Aseed"]),
            "--rule", RULE_ID, "--rule-generation", str(RULE_GENERATION),
            "--bundle", str(values["bundles"]["normal"]),
        ])
        h.check(status is not None and status["acceptance_durable"] is True,
                "stale seed reconstructs durable service status")
        values.update({"normal_request": request, "normal_a_case": a_case,
                       "normal_r_case": r_case})

    h.case("native_nos1_offer_and_acceptance", normal_exchange)

    def response_loss() -> None:
        first = h.run("loss-first-no-receiver", send_command(
            values["Aseed"], values["bundles"]["loss"]), expected=4, timeout=15)
        h.check(first is not None and first["status"] == "UNRESOLVED" and
                first["attempts"] == 1 and not first["acceptance_durable"],
                "carrier failure preserves unresolved first attempt")
        request = first["request_id"]
        server = launch_server(
            h, "loss-drop-receiver", values["Rseed"],
            {DROP_AFTER_ADMISSION: request})
        second = h.run("loss-response-dropped", send_command(
            values["Aseed"], values["bundles"]["loss"]), expected=4, timeout=15)
        rc, out, err = finish_server(server)
        h.check(second is not None and second["status"] == "UNRESOLVED" and
                second["attempts"] == 2 and not second["acceptance_durable"],
                "lost response remains explicitly unresolved")
        h.check(rc == 3 and "TEST_SESSION_DROP_AFTER_ADMISSION" in err,
                f"receiver fault boundary was exercised: {out!r} {err!r}")
        r_case = service_root(values["Rstate"]) / "cases" / request
        a_case = service_root(values["Astate"]) / "cases" / request
        h.check((r_case / "acceptance.bin").is_file() and
                not (a_case / "acceptance.bin").exists(),
                "receiver acceptance is durable before lost response")
        values.update({
            "loss_request": request, "loss_a_case": a_case,
            "loss_r_case": r_case,
            "loss_acceptance": (r_case / "acceptance.bin").read_bytes(),
        })

    h.case("response_loss_preserves_uncertainty", response_loss)

    def replay_conflict_case() -> None:
        before = (values["normal_r_case"] / "acceptance.bin").read_bytes()
        server = launch_server(h, "replay-conflict-receiver", values["Rseed"])
        decoded = replay_conflict(
            h, values["r_port"], values["normal_request"],
            values["normal_a_case"] / "offer.bin")
        rc, out, err = finish_server(server)
        h.check(decoded["code"] == "CUSTODY_SESSION_REPLAY_CONFLICT" and
                decoded["operation"] == values["normal_request"],
                f"same request id with different bytes is a hard conflict: {decoded}")
        h.check(rc == 3 and '"rejected":true' in out,
                f"receiver records rejected replay without transport ambiguity: {out!r} {err!r}")
        h.check((values["normal_r_case"] / "acceptance.bin").read_bytes() == before,
                "conflicting duplicate cannot alter retained acceptance")

    h.case("request_id_complete_offer_conflict", replay_conflict_case)

    def incomplete_offer_index_recovery() -> None:
        # Sender crash boundary: offer.bin is the first durable artifact. Remove
        # every later sidecar to model death before envelope metadata/index.
        sender_state = h.runtime / "repair-sender"
        sender_config = isolated_config(
            values["Av22"], h.work / "repair-sender.conf", sender_state,
            "repair-sender", values["rule"])
        first = h.run("repair-sender-first", send_command(
            sender_config, values["bundles"]["repair-sender"], "dead"),
            expected=4, timeout=15)
        h.check(first is not None and first["status"] == "UNRESOLVED",
                "sender created one durable offer before simulated crash")
        request = first["request_id"]
        directory = service_root(sender_state) / "cases" / request
        envelope = (directory / "envelope_sha256").read_text().strip()
        offer = (directory / "offer.bin").read_bytes()
        for path in list(directory.iterdir()):
            if path.name != "offer.bin":
                path.unlink()
        index = service_root(sender_state) / "envelope-index" / envelope
        index.unlink(missing_ok=True)

        switched = h.run("repair-sender-route-switch", send_command(
            sender_config, values["bundles"]["repair-sender"], "default"),
            expected=3)
        h.check(switched is not None and
                switched["code"] == "CUSTODY_SESSION_ROUTE_CONFLICT",
                "offer-only sender recovery preserves the original explicit route")
        h.check(len(service_cases(sender_state)) == 1 and
                (directory / "offer.bin").read_bytes() == offer,
                "offer-only sender recovery cannot mint a second request identity")
        h.check((directory / "envelope_sha256").read_text().strip() == envelope and
                index.read_text().strip() == request,
                "sender reconstructs derived envelope metadata and reverse index")

        # Receiver crash boundary: retain only a valid signed offer from one
        # sender incarnation, then present a second independently valid request
        # for the same envelope. The retained offer must win before admission.
        source_one_state = h.runtime / "repair-receiver-source-one"
        source_one = isolated_config(
            values["Av22"], h.work / "repair-receiver-source-one.conf",
            source_one_state, "repair-receiver-source-one", values["rule"])
        prepared = h.run("repair-receiver-source-one", send_command(
            source_one, values["bundles"]["repair-receiver"], "dead"),
            expected=4, timeout=15)
        h.check(prepared is not None and prepared["status"] == "UNRESOLVED",
                "first sender produced a valid retained receiver offer")
        first_request = prepared["request_id"]
        source_case = service_root(source_one_state) / "cases" / first_request
        receiver_root = service_root(values["Rstate"])
        receiver_case = receiver_root / "cases" / first_request
        receiver_case.mkdir(mode=0o700)
        retained_offer = source_case / "offer.bin"
        receiver_offer = receiver_case / "offer.bin"
        receiver_offer.write_bytes(retained_offer.read_bytes())
        receiver_offer.chmod(0o600)
        receiver_envelope = (source_case / "envelope_sha256").read_text().strip()
        receiver_index = receiver_root / "envelope-index" / receiver_envelope
        receiver_index.unlink(missing_ok=True)

        source_two_state = h.runtime / "repair-receiver-source-two"
        source_two = isolated_config(
            values["Av22"], h.work / "repair-receiver-source-two.conf",
            source_two_state, "repair-receiver-source-two", values["rule"])
        server = launch_server(h, "repair-receiver", values["Rseed"])
        rejected = h.run("repair-receiver-source-two", send_command(
            source_two, values["bundles"]["repair-receiver"], "default"),
            expected=4, timeout=15)
        rc, out, err = finish_server(server)
        h.check(rejected is not None and rejected["status"] == "UNRESOLVED" and
                "already bound" in rejected.get("detail", ""),
                "receiver rejects a second valid request for the recovered envelope")
        second_request = rejected["request_id"]
        h.check(second_request != first_request and rc == 3 and
                '"rejected":true' in out,
                f"receiver surfaced exact envelope replay conflict: {out!r} {err!r}")
        h.check(not (receiver_root / "cases" / second_request).exists() and
                len([p for p in (receiver_root / "cases").iterdir()
                     if p.is_dir() and
                     (p / "envelope_sha256").is_file() and
                     (p / "envelope_sha256").read_text().strip() ==
                     receiver_envelope]) == 1,
                "receiver retains only one request identity for the envelope")
        h.check((receiver_case / "envelope_sha256").read_text().strip() ==
                receiver_envelope and receiver_index.read_text().strip() ==
                first_request,
                "receiver reconstructs metadata and index from signed offer bytes")

    h.case("offer_only_crash_index_recovery", incomplete_offer_index_recovery)

    def explicit_route_and_attempt_bound() -> None:
        before_receiver_cases = len(service_cases(values["Rstate"]))
        server = launch_server(h, "default-route-held-open", values["Rseed"])
        first = h.run("dead-route-attempt-1", send_command(
            values["Aseed"], values["bundles"]["route"], "dead"),
            expected=4, timeout=15)
        h.check(first is not None and first["status"] == "UNRESOLVED" and
                first["attempts"] == 1,
                "explicit dead route remains unresolved")
        time.sleep(0.15)
        h.check(server.poll() is None,
                "available default listener was not selected as automatic fallback")
        server.send_signal(signal.SIGTERM)
        rc, out, err = finish_server(server)
        h.check(rc == 0 and '"accepted_connections":0' in out,
                f"default route received no fallback connection: {out!r} {err!r}")
        for attempt in range(2, 5):
            result = h.run(f"dead-route-attempt-{attempt}", send_command(
                values["Aseed"], values["bundles"]["route"], "dead"),
                expected=4, timeout=15)
            h.check(result is not None and result["attempts"] == attempt and
                    result["status"] == "UNRESOLVED",
                    f"attempt {attempt} persisted before carrier I/O")
        exhausted = h.run("dead-route-exhausted", send_command(
            values["Aseed"], values["bundles"]["route"], "dead"),
            expected=4, timeout=15)
        h.check(exhausted is not None and
                exhausted["status"] == "UNRESOLVED_ATTEMPTS_EXHAUSTED" and
                exhausted["attempts"] == 4,
                "finite total attempt bound survives invocation restart")
        conflict = h.run("route-switch-conflict", send_command(
            values["Aseed"], values["bundles"]["route"], "default"),
            expected=3)
        h.check(conflict is not None and
                conflict["code"] == "CUSTODY_SESSION_ROUTE_CONFLICT",
                "retained offer cannot silently switch carriers")
        request = first["request_id"]
        a_case = service_root(values["Astate"]) / "cases" / request
        r_case = service_root(values["Rstate"]) / "cases" / request
        h.check((a_case / "attempts").read_text().strip() == "4" and
                not (a_case / "acceptance.bin").exists(),
                "attempt exhaustion manufactures no acceptance")
        h.check(not r_case.exists() and
                len(service_cases(values["Rstate"])) == before_receiver_cases,
                "unselected live route admitted no custody offer")
        values.update({"route_request": request, "route_a_case": a_case})

    h.case("two_routes_are_explicit_not_failover", explicit_route_and_attempt_bound)

    def certificate_commitments() -> None:
        wrong_local_rule = service_rule(
            relay_grant=values["relay"], a_certificate="11" * 32,
            r_certificate=values["r_cert"],
            expiry_ms=values["authority_expiry"])
        wrong_local = isolated_config(
            values["Av22"], h.work / "wrong-local-cert.conf",
            h.runtime / "wrong-local-cert", "wrong-local-cert", wrong_local_rule)
        h.run("check-wrong-local-cert", ["config-check", "--config", str(wrong_local)])
        rejected = h.run("wrong-local-cert-status", [
            "custody-service-v1-status", "--config", str(wrong_local),
            "--rule", RULE_ID, "--rule-generation", str(RULE_GENERATION),
        ], expected=3)
        h.check(rejected is not None and
                rejected["code"] == "CUSTODY_SESSION_LOCAL_CERTIFICATE_MISMATCH",
                "invocation binds exact local DER certificate commitment")

        wrong_peer_rule = service_rule(
            relay_grant=values["relay"], a_certificate=values["a_cert"],
            r_certificate="22" * 32,
            expiry_ms=values["authority_expiry"])
        wrong_peer_state = h.runtime / "wrong-peer-cert"
        wrong_peer = isolated_config(
            values["Av22"], h.work / "wrong-peer-cert.conf",
            wrong_peer_state, "wrong-peer-cert", wrong_peer_rule)
        h.run("check-wrong-peer-cert", ["config-check", "--config", str(wrong_peer)])
        before_receiver_cases = len(service_cases(values["Rstate"]))
        server = launch_server(h, "wrong-peer-cert-receiver", values["Rseed"])
        sent = h.run("wrong-peer-cert-send", send_command(
            wrong_peer, values["bundles"]["spare-one"]),
            expected=4, timeout=15)
        rc, out, err = finish_server(server)
        h.check(sent is not None and sent["status"] == "UNRESOLVED" and
                "certificate" in sent.get("detail", "").lower(),
                "authenticated peer DER mismatch cannot become acceptance")
        h.check(rc == 3 and len(service_cases(values["Rstate"])) ==
                before_receiver_cases,
                f"peer mismatch transmitted no custody application: {out!r} {err!r}")
        isolated_cases = service_cases(wrong_peer_state)
        h.check(len(isolated_cases) == 1 and
                not (isolated_cases[0] / "acceptance.bin").exists(),
                "wrong peer commitment retains only unresolved local evidence")

    h.case("exact_local_and_peer_certificate_commitments", certificate_commitments)

    def finite_capacity_and_time() -> None:
        capacity_rule = service_rule(
            relay_grant=values["relay"], a_certificate=values["a_cert"],
            r_certificate=values["r_cert"], maximum_pending=1,
            expiry_ms=values["authority_expiry"])
        capacity_state = h.runtime / "capacity-one"
        capacity = isolated_config(
            values["Av22"], h.work / "capacity-one.conf", capacity_state,
            "capacity-one", capacity_rule)
        first = h.run("capacity-first", send_command(
            capacity, values["bundles"]["spare-one"], "dead"),
            expected=4, timeout=15)
        h.check(first is not None and first["status"] == "UNRESOLVED",
                "first pending case occupies exact capacity")
        second = h.run("capacity-second", send_command(
            capacity, values["bundles"]["spare-two"], "dead"), expected=3)
        h.check(second is not None and
                second["code"] == "CUSTODY_SESSION_PENDING_LIMIT" and
                len(service_cases(capacity_state)) == 1,
                "pending-case capacity rejects before a second offer")

        short_rule = service_rule(
            relay_grant=values["relay"], a_certificate=values["a_cert"],
            r_certificate=values["r_cert"], maximum_window_ms=1_000,
            expiry_ms=values["authority_expiry"])
        short_state = h.runtime / "short-window"
        short = isolated_config(
            values["Av22"], h.work / "short-window.conf", short_state,
            "short-window", short_rule)
        initial = h.run("short-window-first", send_command(
            short, values["bundles"]["spare-one"], "dead"),
            expected=4, timeout=15)
        h.check(initial is not None and initial["attempts"] == 1,
                "short-window first attempt is durably counted")
        time.sleep(1.15)
        expired = h.run("short-window-expired", send_command(
            short, values["bundles"]["spare-one"], "dead"),
            expected=4, timeout=15)
        h.check(expired is not None and
                expired["status"] == "UNRESOLVED_EXPIRED" and
                expired["attempts"] == 1,
                "expired retained offer is never retransmitted")

        expired_rule = service_rule(
            relay_grant=values["relay"], a_certificate=values["a_cert"],
            r_certificate=values["r_cert"],
            expiry_ms=int(time.time() * 1000) - 1)
        expired_config = isolated_config(
            values["Av22"], h.work / "expired-authority.conf",
            h.runtime / "expired-authority", "expired-authority", expired_rule)
        authority = h.run("expired-authority-send", send_command(
            expired_config, values["bundles"]["spare-two"], "dead"), expected=3)
        h.check(authority is not None and
                authority["code"] == "CUSTODY_SESSION_AUTHORITY_EXPIRED",
                "expired V22 authority cannot originate an offer")

    h.case("finite_pending_attempt_window_and_expiry", finite_capacity_and_time)

    def activate_lifecycle(name: str, lifecycle: str) -> None:
        replacement = values["rule"].replace("state=ACTIVE\n", f"state={lifecycle}\n")
        for node in ("A", "R"):
            config = candidate(
                h, values[f"{node}v22"], f"{node.lower()}-{name}",
                f"{node.lower()}-{name}",
                lambda text, replacement=replacement:
                    replace_service_rule(text, replacement),
            )
            checked = h.run(f"check-{node}-{name}", [
                "config-check", "--config", str(config)])
            h.check(checked is not None and
                    checked["custody_session_policy"]["rules"][0]["state"] == lifecycle,
                    f"{node} canonical {lifecycle} lifecycle")
            daemon = h.start(f"activate-{node}-{name}", values[f"{node}seed"],
                             values[f"{node}state"])
            activate(h, f"activate-{node}-{name}", values[f"{node}state"], config)
            daemon.shutdown()
            values[f"{node}{name}"] = config

    def retired_and_revoked() -> None:
        activate_lifecycle("retired", "RETIRED")
        server = launch_server(h, "retired-duplicate-receiver", values["Rseed"])
        recovered = h.run("retired-loss-retry", send_command(
            values["Aseed"], values["bundles"]["loss"]), timeout=15)
        rc, out, err = finish_server(server)
        h.check(rc == 0 and recovered is not None and
                recovered["status"] == "ACCEPTED" and recovered["attempts"] == 3,
                f"retired authority replays only retained acceptance: {out!r} {err!r}")
        h.check((values["loss_r_case"] / "acceptance.bin").read_bytes() ==
                values["loss_acceptance"] and
                (values["loss_a_case"] / "acceptance.bin").read_bytes() ==
                values["loss_acceptance"],
                "restart retry recovers byte-identical retained acceptance")
        local = h.run("retired-local-recovery", send_command(
            values["Aseed"], values["bundles"]["loss"]))
        h.check(local is not None and local["status"] == "ACCEPTED" and
                local["attempts"] == 3,
                "local retained acceptance needs no carrier after restart")
        denied = h.run("retired-new-offer", send_command(
            values["Aseed"], values["bundles"]["spare-two"]), expected=3)
        h.check(denied is not None and denied["code"] == "CUSTODY_SESSION_RETIRED",
                "retired authority cannot create a new offer")
        status = h.run("retired-status", [
            "custody-service-v1-status", "--config", str(values["Aseed"]),
            "--rule", RULE_ID, "--rule-generation", str(RULE_GENERATION)])
        h.check(status is not None and status["rule_state"] == "RETIRED",
                "status reconstructs monotonic retirement")

        activate_lifecycle("revoked", "REVOKED")
        serve = h.run("revoked-serve", [
            "custody-service-v1-serve", "--config", str(values["Rseed"]),
            "--rule", RULE_ID, "--rule-generation", str(RULE_GENERATION),
            "--once", "yes"], expected=3)
        h.check(serve is not None and serve["code"] == "CUSTODY_SESSION_REVOKED",
                "revoked receiver cannot expose a listener")
        retry = h.run("revoked-unresolved-retry", send_command(
            values["Aseed"], values["bundles"]["route"], "dead"), expected=3)
        h.check(retry is not None and retry["code"] == "CUSTODY_SESSION_REVOKED" and
                (values["route_a_case"] / "attempts").read_text().strip() == "4",
                "revocation blocks unresolved retry without changing attempts")
        historical = h.run("revoked-local-durable-fact", send_command(
            values["Aseed"], values["bundles"]["normal"]))
        h.check(historical is not None and historical["status"] == "ACCEPTED",
                "revocation does not erase an already retained local acceptance")
        revoked_status = h.run("revoked-status", [
            "custody-service-v1-status", "--config", str(values["Aseed"]),
            "--rule", RULE_ID, "--rule-generation", str(RULE_GENERATION)])
        h.check(revoked_status is not None and
                revoked_status["rule_state"] == "REVOKED",
                "status reconstructs monotonic revocation")

    h.case("retired_duplicate_recovery_and_revoked_block", retired_and_revoked)

    def no_application_delivery_or_relay() -> None:
        receiver = h.run("receiver-offline-inspect", [
            "inspect", "--state", str(values["Rstate"]), "--node", "R"])
        h.check(receiver is not None and receiver["inbound"]["count"] == 0,
                "custody acceptance does not import application evidence")
        aggregate = h.run("final-aggregate-status", [
            "custody-service-v1-status", "--config", str(values["Aseed"]),
            "--rule", RULE_ID, "--rule-generation", str(RULE_GENERATION)])
        h.check(aggregate is not None and
                aggregate["automatic_route_relay"] is False,
                "service status never claims automatic routing")
        forbidden: list[Path] = []
        for state in (values["Astate"], values["Rstate"]):
            root = service_root(state)
            if root.exists():
                forbidden.extend(path for path in root.rglob("*")
                                 if "delivery" in path.name.lower() or
                                 "application-success" in path.name.lower())
        h.check(not forbidden,
                "custody service creates no delivery-receipt or application-success sidecar")
        version = h.run("service-version-final", ["custody-service-v1-version"])
        h.check(version is not None and
                version["transport"] == "NOS1_BOUNDED_REUSE_V1" and
                version["configured_custody_relay"] is True and
                version["automatic_route_relay"] is False and
                version["open_relay"] is False and
                version["application_delivery_inferred"] is False,
                "version surface distinguishes explicit service from automatic or open relay")

    h.case("no_application_delivery_or_open_relay", no_application_delivery_or_relay)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not exist")
    h = Harness(args.binary, args.output)
    started = time.monotonic()
    code = 1
    try:
        suite(h)
        code = 0
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
    finally:
        h.cleanup()
        report = {
            "format": "NATRAV_NATIVE_DURABLE_CUSTODY_SESSION_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "assertions": h.assertions,
            "cases": h.cases,
            "commands": h.commands,
            "elapsed_seconds": time.monotonic() - started,
        }
        (h.output / "RESULT.json").write_text(
            json.dumps(report, indent=2, sort_keys=True) + "\n")
        summary = {
            "format": report["format"],
            "status": report["status"],
            "binary_sha256": report["binary_sha256"],
            "assertions": report["assertions"],
            "cases": report["cases"],
            "cases_passed": sum(case.get("status") == "PASS"
                                for case in report["cases"]),
            "cases_total": len(report["cases"]),
            "commands": len(report["commands"]),
            "elapsed_seconds": report["elapsed_seconds"],
            "failure": None if code == 0 else
                (h.output / "FAILURE.txt").read_text().strip(),
        }
        (h.output / "SUMMARY.json").write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n")
        print(json.dumps({
            "format": report["format"], "status": report["status"],
            "assertions": report["assertions"],
            "cases_passed": summary["cases_passed"],
            "cases_total": summary["cases_total"],
            "commands": summary["commands"],
        }, sort_keys=True))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
