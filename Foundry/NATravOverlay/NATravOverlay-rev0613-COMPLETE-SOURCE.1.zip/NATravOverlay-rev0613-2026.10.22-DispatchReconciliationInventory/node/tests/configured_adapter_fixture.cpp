#include <algorithm>
#include <arpa/inet.h>
#include <array>
#include <cerrno>
#include <charconv>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <fcntl.h>
#include <fstream>
#include <limits>
#include <memory>
#include <netinet/in.h>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/file.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>
#include <utility>
#include <vector>

#ifndef NATRAV_FIXTURE_MARKER
#define NATRAV_FIXTURE_MARKER "UNSET"
#endif

extern char** environ;

namespace {

using Bytes = std::vector<std::uint8_t>;

inline constexpr std::array<std::uint8_t, 8U> kMagic{
    'N', 'A', 'P', 'A', '0', '0', '0', '1'};
inline constexpr std::size_t kHeaderBytes = 36U;
inline constexpr std::string_view kProcessScheduleFormat =
    "NATRAV_CONFIGURED_ADAPTER_PROCESS_SCHEDULE_V1";
inline constexpr std::string_view kProcessScheduleFeature =
    "DETERMINISTIC_CONFIGURED_ADAPTER_PROCESS_ADVERSARY_V1";
inline constexpr std::string_view kProcessTraceFormat =
    "NATRAV_CONFIGURED_ADAPTER_PROCESS_TRACE_V1";
inline constexpr std::string_view kLaunchStateFormat =
    "NATRAV_CONFIGURED_ADAPTER_LAUNCH_STATE_V1";

class Fd final {
public:
    explicit Fd(const int value = -1) noexcept : value_(value) {}
    ~Fd() { if (value_ >= 0) { ::close(value_); } }
    Fd(const Fd&) = delete;
    Fd& operator=(const Fd&) = delete;
    Fd(Fd&& other) noexcept : value_(std::exchange(other.value_, -1)) {}
    Fd& operator=(Fd&& other) noexcept {
        if (this != &other) {
            if (value_ >= 0) { ::close(value_); }
            value_ = std::exchange(other.value_, -1);
        }
        return *this;
    }
    [[nodiscard]] int get() const noexcept { return value_; }
private:
    int value_;
};

enum class FrameType : std::uint8_t {
    hello_request = 1U,
    hello_response = 2U,
    transmit_request = 3U,
    transmit_response = 4U,
    receive_request = 5U,
    receive_response = 6U,
    ping_request = 7U,
    ping_response = 8U,
    shutdown_request = 9U,
    shutdown_response = 10U,
    fault = 11U,
};

enum class Status : std::uint32_t {
    ok = 0U,
    no_data = 1U,
    busy = 2U,
    malformed = 3U,
};

struct Frame final {
    FrameType type{FrameType::fault};
    std::uint64_t sequence{0U};
    std::uint32_t deadline_ms{0U};
    Status status{Status::ok};
    Bytes payload{};
};

struct ProcessSchedule final {
    std::string name{};
    std::size_t maximum_trace_records{256U};
    std::string startup_action{"PASS"};
    std::uint64_t startup_count{0U};
    std::uint64_t startup_silence_ms{0U};
    std::uint64_t silent_transmit_ordinal{0U};
    std::uint64_t silent_receive_ordinal{0U};
    std::uint64_t silent_response_ms{0U};
    std::uint64_t crash_transmit_ordinal{0U};
};

struct TraceRecord final {
    std::uint64_t sequence{0U};
    std::string kind{};
    std::uint64_t ordinal{0U};
    std::string action{};
    std::size_t bytes{0U};
    std::string schedule{};
};

[[nodiscard]] std::uint32_t crc32(
    const std::span<const std::uint8_t> bytes) noexcept {
    std::uint32_t value = 0xffffffffU;
    for (const auto byte : bytes) {
        value ^= byte;
        for (std::size_t bit = 0U; bit < 8U; ++bit) {
            const std::uint32_t mask =
                static_cast<std::uint32_t>(0U - (value & 1U));
            value = (value >> 1U) ^ (0xedb88320U & mask);
        }
    }
    return ~value;
}

void append_be16(Bytes& out, const std::uint16_t value) {
    out.push_back(static_cast<std::uint8_t>((value >> 8U) & 0xffU));
    out.push_back(static_cast<std::uint8_t>(value & 0xffU));
}

void append_be32(Bytes& out, const std::uint32_t value) {
    for (int shift = 24; shift >= 0; shift -= 8) {
        out.push_back(static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(shift)) & 0xffU));
    }
}

void append_be64(Bytes& out, const std::uint64_t value) {
    for (int shift = 56; shift >= 0; shift -= 8) {
        out.push_back(static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(shift)) & 0xffU));
    }
}

[[nodiscard]] std::uint32_t read_be32(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) {
    if (offset > bytes.size() || bytes.size() - offset < 4U) {
        throw std::runtime_error("truncated u32");
    }
    std::uint32_t value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
        value = (value << 8U) | bytes[offset + index];
    }
    return value;
}

[[nodiscard]] std::uint64_t read_be64(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) {
    if (offset > bytes.size() || bytes.size() - offset < 8U) {
        throw std::runtime_error("truncated u64");
    }
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value = (value << 8U) | bytes[offset + index];
    }
    return value;
}

[[nodiscard]] Bytes encode(const Frame& frame) {
    Bytes output;
    output.reserve(kHeaderBytes + frame.payload.size());
    output.insert(output.end(), kMagic.begin(), kMagic.end());
    output.push_back(static_cast<std::uint8_t>(frame.type));
    output.push_back(0U);
    append_be16(output, 0U);
    append_be64(output, frame.sequence);
    append_be32(output, frame.deadline_ms);
    append_be32(output, static_cast<std::uint32_t>(frame.status));
    append_be32(output, static_cast<std::uint32_t>(frame.payload.size()));
    Bytes checksum_input(output);
    checksum_input.insert(
        checksum_input.end(), frame.payload.begin(), frame.payload.end());
    append_be32(output, crc32(checksum_input));
    output.insert(output.end(), frame.payload.begin(), frame.payload.end());
    return output;
}

[[nodiscard]] Frame decode(const std::span<const std::uint8_t> bytes) {
    if (bytes.size() < kHeaderBytes ||
        !std::equal(kMagic.begin(), kMagic.end(), bytes.begin()) ||
        bytes[9U] != 0U || bytes[10U] != 0U || bytes[11U] != 0U) {
        throw std::runtime_error("invalid frame prefix");
    }
    const auto payload_size = read_be32(bytes, 28U);
    if (payload_size != bytes.size() - kHeaderBytes) {
        throw std::runtime_error("invalid frame length");
    }
    Bytes checksum_input(bytes.begin(), bytes.begin() + 32);
    checksum_input.insert(
        checksum_input.end(),
        bytes.begin() + static_cast<std::ptrdiff_t>(kHeaderBytes),
        bytes.end());
    if (crc32(checksum_input) != read_be32(bytes, 32U)) {
        throw std::runtime_error("invalid frame checksum");
    }
    return Frame{
        .type = static_cast<FrameType>(bytes[8U]),
        .sequence = read_be64(bytes, 12U),
        .deadline_ms = read_be32(bytes, 20U),
        .status = static_cast<Status>(read_be32(bytes, 24U)),
        .payload = Bytes(
            bytes.begin() + static_cast<std::ptrdiff_t>(kHeaderBytes), bytes.end()),
    };
}

void send_frame(const int descriptor, const Frame& frame) {
    const auto bytes = encode(frame);
    ssize_t count = -1;
    do {
        count = ::send(descriptor, bytes.data(), bytes.size(), MSG_NOSIGNAL);
    } while (count < 0 && errno == EINTR);
    if (count < 0 || static_cast<std::size_t>(count) != bytes.size()) {
        throw std::runtime_error("frame send failed");
    }
}

[[nodiscard]] Frame receive_frame(const int descriptor) {
    Bytes bytes(1'048'576U);
    ssize_t count = -1;
    do {
        count = ::recv(descriptor, bytes.data(), bytes.size(), 0);
    } while (count < 0 && errno == EINTR);
    if (count <= 0) {
        throw std::runtime_error("frame receive failed");
    }
    bytes.resize(static_cast<std::size_t>(count));
    return decode(bytes);
}

[[nodiscard]] std::size_t environment_count() noexcept {
    std::size_t count = 0U;
    if (environ != nullptr) {
        while (environ[count] != nullptr) { ++count; }
    }
    return count;
}

[[nodiscard]] std::vector<int> open_extra_descriptors() {
    std::vector<int> descriptors;
    for (int descriptor = 4; descriptor < 64; ++descriptor) {
        if (::fcntl(descriptor, F_GETFD, 0) >= 0 || errno != EBADF) {
            descriptors.push_back(descriptor);
        }
    }
    return descriptors;
}

void write_report(
    const std::string& path,
    const int argc,
    char* argv[],
    const bool shutdown) {
    const auto environment_entries = environment_count();
    const auto extra_descriptors = open_extra_descriptors();
    const int no_new_privileges =
        ::prctl(PR_GET_NO_NEW_PRIVS, 0L, 0L, 0L, 0L);
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output) { throw std::runtime_error("report open failed"); }
    output << "marker=" << NATRAV_FIXTURE_MARKER << '\n';
    output << "argc=" << argc << '\n';
    for (int index = 1; index < argc; ++index) {
        output << "argv=" << argv[index] << '\n';
    }
    output << "environment-count=" << environment_entries << '\n';
    output << "extra-fd-count=" << extra_descriptors.size() << '\n';
    output << "no-new-privs=" << no_new_privileges << '\n';
    output << "shutdown=" << (shutdown ? 1 : 0) << '\n';
}

void append_report(const std::string& path, const std::string& line) {
    std::ofstream output(path, std::ios::binary | std::ios::app);
    if (!output) { throw std::runtime_error("report append failed"); }
    output << line << '\n';
    output.flush();
}

[[nodiscard]] std::string read_bounded_file(
    const std::string& path,
    const std::size_t maximum) {
    std::ifstream input(path, std::ios::binary | std::ios::ate);
    if (!input) { throw std::runtime_error("schedule open failed"); }
    const auto end = input.tellg();
    if (end <= 0 || static_cast<std::uintmax_t>(end) > maximum) {
        throw std::runtime_error("schedule size invalid");
    }
    input.seekg(0, std::ios::beg);
    std::string value(static_cast<std::size_t>(end), '\0');
    input.read(value.data(), static_cast<std::streamsize>(value.size()));
    if (!input || static_cast<std::size_t>(input.gcount()) != value.size()) {
        throw std::runtime_error("schedule read failed");
    }
    return value;
}

[[nodiscard]] std::vector<std::string> canonical_lines(const std::string& value) {
    if (value.empty() || value.back() != '\n' || value.find('\r') != std::string::npos) {
        throw std::runtime_error("schedule newline invalid");
    }
    std::vector<std::string> lines;
    std::size_t begin = 0U;
    while (begin < value.size()) {
        const auto end = value.find('\n', begin);
        if (end == std::string::npos) { throw std::runtime_error("schedule line invalid"); }
        lines.push_back(value.substr(begin, end - begin));
        begin = end + 1U;
    }
    return lines;
}

[[nodiscard]] std::uint64_t parse_unsigned(
    const std::string_view value,
    const std::uint64_t maximum,
    const std::string_view label) {
    if (value.empty() || (value.size() > 1U && value.front() == '0')) {
        throw std::runtime_error(std::string(label) + " is noncanonical");
    }
    std::uint64_t parsed = 0U;
    const auto result = std::from_chars(
        value.data(), value.data() + value.size(), parsed, 10);
    if (result.ec != std::errc{} || result.ptr != value.data() + value.size() ||
        parsed > maximum) {
        throw std::runtime_error(std::string(label) + " is invalid");
    }
    return parsed;
}

[[nodiscard]] bool canonical_slug(const std::string_view value) noexcept {
    if (value.empty() || value.size() > 32U || value.front() < 'a' || value.front() > 'z') {
        return false;
    }
    return std::all_of(value.begin() + 1, value.end(), [](const char ch) {
        return (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '-';
    });
}

[[nodiscard]] std::string schedule_text(const ProcessSchedule& schedule) {
    return std::string(kProcessScheduleFormat) + "\n" +
        "feature=" + std::string(kProcessScheduleFeature) + "\n" +
        "name=" + schedule.name + "\n" +
        "maximum-trace-records=" + std::to_string(schedule.maximum_trace_records) + "\n" +
        "startup-action=" + schedule.startup_action + "\n" +
        "startup-count=" + std::to_string(schedule.startup_count) + "\n" +
        "startup-silence-ms=" + std::to_string(schedule.startup_silence_ms) + "\n" +
        "silent-transmit-ordinal=" + std::to_string(schedule.silent_transmit_ordinal) + "\n" +
        "silent-receive-ordinal=" + std::to_string(schedule.silent_receive_ordinal) + "\n" +
        "silent-response-ms=" + std::to_string(schedule.silent_response_ms) + "\n" +
        "crash-transmit-ordinal=" + std::to_string(schedule.crash_transmit_ordinal) + "\n";
}

[[nodiscard]] ProcessSchedule parse_schedule_text(const std::string& text) {
    const auto lines = canonical_lines(text);
    if (lines.size() != 11U || lines[0] != kProcessScheduleFormat) {
        throw std::runtime_error("schedule header or field count invalid");
    }
    const std::array<std::string_view, 10U> keys{
        "feature", "name", "maximum-trace-records", "startup-action",
        "startup-count", "startup-silence-ms", "silent-transmit-ordinal",
        "silent-receive-ordinal", "silent-response-ms",
        "crash-transmit-ordinal"};
    std::array<std::string, 10U> values{};
    for (std::size_t index = 0U; index < keys.size(); ++index) {
        const std::string prefix = std::string(keys[index]) + "=";
        if (!lines[index + 1U].starts_with(prefix)) {
            throw std::runtime_error("schedule fields are not canonical ordered");
        }
        values[index] = lines[index + 1U].substr(prefix.size());
    }
    if (values[0] != kProcessScheduleFeature || !canonical_slug(values[1])) {
        throw std::runtime_error("schedule feature or name invalid");
    }
    ProcessSchedule schedule{
        .name = values[1],
        .maximum_trace_records = static_cast<std::size_t>(
            parse_unsigned(values[2], 4'096U, "trace bound")),
        .startup_action = values[3],
        .startup_count = parse_unsigned(values[4], 64U, "startup count"),
        .startup_silence_ms = parse_unsigned(values[5], 60'000U, "startup silence"),
        .silent_transmit_ordinal = parse_unsigned(values[6], 1'000'000U, "silent transmit ordinal"),
        .silent_receive_ordinal = parse_unsigned(values[7], 1'000'000U, "silent receive ordinal"),
        .silent_response_ms = parse_unsigned(values[8], 60'000U, "silent response"),
        .crash_transmit_ordinal = parse_unsigned(values[9], 1'000'000U, "crash transmit ordinal"),
    };
    if (schedule.maximum_trace_records < 16U ||
        (schedule.startup_action != "PASS" && schedule.startup_action != "FAIL" &&
         schedule.startup_action != "SILENT")) {
        throw std::runtime_error("schedule bounds or startup action invalid");
    }
    if (schedule.startup_action == "PASS") {
        if (schedule.startup_count != 0U || schedule.startup_silence_ms != 0U) {
            throw std::runtime_error("PASS startup schedule invalid");
        }
    } else if (schedule.startup_action == "FAIL") {
        if (schedule.startup_count == 0U || schedule.startup_silence_ms != 0U) {
            throw std::runtime_error("FAIL startup schedule invalid");
        }
    } else if (schedule.startup_count == 0U || schedule.startup_silence_ms == 0U) {
        throw std::runtime_error("SILENT startup schedule invalid");
    }
    const bool runtime_silence = schedule.silent_transmit_ordinal != 0U ||
        schedule.silent_receive_ordinal != 0U;
    if (runtime_silence != (schedule.silent_response_ms != 0U) ||
        (schedule.crash_transmit_ordinal != 0U &&
         schedule.crash_transmit_ordinal == schedule.silent_transmit_ordinal)) {
        throw std::runtime_error("runtime process schedule invalid");
    }
    if (schedule_text(schedule) != text) {
        throw std::runtime_error("schedule is valid but noncanonical");
    }
    return schedule;
}

[[nodiscard]] ProcessSchedule read_schedule(const std::string& path) {
    return parse_schedule_text(read_bounded_file(path, 4'096U));
}

void write_all(const int descriptor, const std::string& value) {
    std::size_t offset = 0U;
    while (offset < value.size()) {
        const auto count = ::pwrite(
            descriptor,
            value.data() + static_cast<std::ptrdiff_t>(offset),
            value.size() - offset,
            static_cast<off_t>(offset));
        if (count < 0 && errno == EINTR) { continue; }
        if (count <= 0) { throw std::runtime_error("launch state write failed"); }
        offset += static_cast<std::size_t>(count);
    }
    if (::ftruncate(descriptor, static_cast<off_t>(value.size())) != 0 ||
        ::fsync(descriptor) != 0) {
        throw std::runtime_error("launch state commit failed");
    }
}

[[nodiscard]] std::uint64_t next_launch_ordinal(const std::string& path) {
    Fd descriptor(::open(path.c_str(), O_RDWR | O_CREAT | O_CLOEXEC | O_NOFOLLOW, 0600));
    if (descriptor.get() < 0 || ::flock(descriptor.get(), LOCK_EX) != 0) {
        throw std::runtime_error("launch state open or lock failed");
    }
    std::array<char, 256U> buffer{};
    ssize_t count = -1;
    do {
        count = ::pread(descriptor.get(), buffer.data(), buffer.size(), 0);
    } while (count < 0 && errno == EINTR);
    if (count < 0 || static_cast<std::size_t>(count) == buffer.size()) {
        throw std::runtime_error("launch state read failed");
    }
    std::uint64_t launches = 0U;
    if (count > 0) {
        const std::string current(buffer.data(), static_cast<std::size_t>(count));
        const auto lines = canonical_lines(current);
        if (lines.size() != 2U || lines[0] != kLaunchStateFormat ||
            !lines[1].starts_with("launches=")) {
            throw std::runtime_error("launch state is noncanonical");
        }
        launches = parse_unsigned(lines[1].substr(9U), 1'000'000U, "launch count");
        if (current != std::string(kLaunchStateFormat) + "\nlaunches=" +
                std::to_string(launches) + "\n") {
            throw std::runtime_error("launch state is valid but noncanonical");
        }
    }
    if (launches == 1'000'000U) { throw std::runtime_error("launch count exhausted"); }
    ++launches;
    write_all(descriptor.get(), std::string(kLaunchStateFormat) +
        "\nlaunches=" + std::to_string(launches) + "\n");
    if (::flock(descriptor.get(), LOCK_UN) != 0) {
        throw std::runtime_error("launch state unlock failed");
    }
    return launches;
}

class TraceWriter final {
public:
    TraceWriter(
        std::string path,
        const std::uint64_t launch_ordinal,
        const std::size_t maximum_records)
        : path_(std::move(path)),
          launch_ordinal_(launch_ordinal),
          maximum_records_(maximum_records) {
        write();
    }

    void require_maximum(const std::size_t value) const {
        if (value != maximum_records_) {
            throw std::runtime_error("live schedule changed trace bound");
        }
    }

    void record(
        const std::string& kind,
        const std::uint64_t ordinal,
        const std::string& action,
        const std::size_t bytes,
        const std::string& schedule) {
        if (records_.size() >= maximum_records_) {
            terminal_ = "TRACE_EXHAUSTED";
            write();
            throw std::runtime_error("process trace bound exhausted");
        }
        records_.push_back(TraceRecord{
            .sequence = static_cast<std::uint64_t>(records_.size() + 1U),
            .kind = kind,
            .ordinal = ordinal,
            .action = action,
            .bytes = bytes,
            .schedule = schedule,
        });
        write();
    }

    void terminal(std::string value) {
        terminal_ = std::move(value);
        write();
    }

private:
    void write() const {
        const std::string temporary = path_ + ".tmp." + std::to_string(::getpid());
        std::ofstream output(temporary, std::ios::binary | std::ios::trunc);
        if (!output) { throw std::runtime_error("process trace open failed"); }
        output << kProcessTraceFormat << '\n';
        output << "launch-ordinal=" << launch_ordinal_ << '\n';
        output << "maximum-records=" << maximum_records_ << '\n';
        output << "record-count=" << records_.size() << '\n';
        output << "terminal=" << terminal_ << '\n';
        for (const auto& record : records_) {
            output << "record=" << record.sequence << '|' << record.kind << '|'
                   << record.ordinal << '|' << record.action << '|'
                   << record.bytes << '|' << record.schedule << '\n';
        }
        output.flush();
        if (!output) { throw std::runtime_error("process trace write failed"); }
        output.close();
        if (::rename(temporary.c_str(), path_.c_str()) != 0) {
            ::unlink(temporary.c_str());
            throw std::runtime_error("process trace replace failed");
        }
    }

    std::string path_;
    std::uint64_t launch_ordinal_;
    std::size_t maximum_records_;
    std::vector<TraceRecord> records_{};
    std::string terminal_{"RUNNING"};
};

[[nodiscard]] std::uint64_t canonical_port(const std::string_view text) {
    const auto value = parse_unsigned(text, 65'535U, "port");
    if (value == 0U) { throw std::runtime_error("port is zero"); }
    return value;
}

[[nodiscard]] std::chrono::milliseconds bounded_ms(const std::uint64_t value) {
    return std::chrono::milliseconds(static_cast<std::chrono::milliseconds::rep>(value));
}

}  // namespace

// Test-only numeric loopback packet fixture. This is not a product carrier.
int main(int argc, char* argv[]) {
    std::unique_ptr<TraceWriter> trace;
    std::string report_path;
    try {
        const bool adversary = argc == 7 && std::string_view(argv[1]) == "--adversary-v1";
        if (!adversary && argc != 5 && argc != 6) { return 70; }
        const int local_index = adversary ? 2 : 1;
        const int remote_index = adversary ? 3 : 2;
        const int prefix_index = adversary ? 4 : 3;
        const int marker_index = adversary ? -1 : 4;
        const auto local_number = canonical_port(argv[local_index]);
        const auto remote_number = canonical_port(argv[remote_index]);
        report_path = std::string(argv[prefix_index]) + "." +
            std::to_string(::getpid()) + ".txt";
        const std::string& report = report_path;
        write_report(report, argc, argv, false);
        append_report(report, "pid=" + std::to_string(::getpid()));

        ProcessSchedule initial_schedule{};
        std::string schedule_path;
        std::uint64_t launch_ordinal = 0U;
        if (adversary) {
            schedule_path = argv[5];
            initial_schedule = read_schedule(schedule_path);
            launch_ordinal = next_launch_ordinal(argv[6]);
            const std::string trace_path = std::string(argv[prefix_index]) + "." +
                std::to_string(::getpid()) + ".trace";
            trace = std::make_unique<TraceWriter>(
                trace_path, launch_ordinal, initial_schedule.maximum_trace_records);
            append_report(report, "launch-ordinal=" + std::to_string(launch_ordinal));
            append_report(report, "schedule-name=" + initial_schedule.name);
            append_report(report, "trace=" + trace_path);
            if (launch_ordinal <= initial_schedule.startup_count) {
                if (initial_schedule.startup_action == "FAIL") {
                    trace->record("STARTUP", launch_ordinal, "FAIL", 0U, initial_schedule.name);
                    trace->terminal("STARTUP_FAIL");
                    append_report(report, "startup=FAIL");
                    return 75;
                }
                if (initial_schedule.startup_action == "SILENT") {
                    trace->record("STARTUP", launch_ordinal, "SILENT", 0U, initial_schedule.name);
                    trace->terminal("STARTUP_SILENT");
                    append_report(report, "startup=SILENT");
                    std::this_thread::sleep_for(bounded_ms(initial_schedule.startup_silence_ms));
                    return 81;
                }
            }
            trace->record("STARTUP", launch_ordinal, "RESPOND", 0U, initial_schedule.name);
        } else if (std::string_view(argv[marker_index]) != "-") {
            const int marker = ::open(
                argv[marker_index],
                O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC,
                0600);
            if (marker >= 0) { ::close(marker); return 75; }
            if (errno != EEXIST) { return 76; }
        }

        const int port = ::socket(AF_INET, SOCK_DGRAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
        if (port < 0) { return 77; }
        Fd port_owner(port);
        sockaddr_in local{};
        local.sin_family = AF_INET;
        local.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        local.sin_port = htons(static_cast<std::uint16_t>(local_number));
        auto remote = local;
        remote.sin_port = htons(static_cast<std::uint16_t>(remote_number));
        if (::bind(port, reinterpret_cast<const sockaddr*>(&local), sizeof(local)) != 0 ||
            ::connect(port, reinterpret_cast<const sockaddr*>(&remote), sizeof(remote)) != 0) {
            return 78;
        }

        std::size_t mtu = 512U;
        std::uint64_t transmit_ordinal = 0U;
        std::uint64_t receive_ordinal = 0U;
        std::uint64_t ping_ordinal = 0U;
        std::uint64_t hello_ordinal = 0U;
        for (std::size_t request_ordinal = 0U; request_ordinal < 500'000U; ++request_ordinal) {
            const auto request = receive_frame(3);
            ProcessSchedule schedule = initial_schedule;
            if (adversary) {
                schedule = read_schedule(schedule_path);
                trace->require_maximum(schedule.maximum_trace_records);
            }
            Frame response{
                .type = FrameType::fault,
                .sequence = request.sequence,
                .status = Status::malformed,
            };
            switch (request.type) {
                case FrameType::hello_request: {
                    ++hello_ordinal;
                    if (!adversary && argc == 6 && std::string_view(argv[5]) == "silent") {
                        ::sleep(5U);
                    }
                    if (request.payload.size() != 20U) { return 72; }
                    const auto profile = read_be32(request.payload, 0U);
                    mtu = read_be32(request.payload, 4U);
                    const auto frames = read_be32(request.payload, 8U);
                    const auto queued = read_be32(request.payload, 12U);
                    const auto outstanding = read_be32(request.payload, 16U);
                    if (profile != 1U || mtu < 256U || mtu > 65'507U ||
                        frames < mtu + kHeaderBytes || queued < mtu || outstanding != 1U) {
                        return 73;
                    }
                    response.type = FrameType::hello_response;
                    response.status = Status::ok;
                    response.payload = request.payload;
                    append_report(report, "hello=1");
                    if (trace) {
                        trace->record("HELLO", hello_ordinal, "RESPOND",
                            request.payload.size(), schedule.name);
                    }
                    break;
                }
                case FrameType::transmit_request: {
                    ++transmit_ordinal;
                    if (request.payload.empty() || request.payload.size() > mtu) { return 74; }
                    if (trace && schedule.silent_transmit_ordinal == transmit_ordinal) {
                        trace->record("TRANSMIT", transmit_ordinal, "SILENT",
                            request.payload.size(), schedule.name);
                        trace->terminal("RUNTIME_SILENT");
                        append_report(report, "runtime-silent-transmit=" +
                            std::to_string(transmit_ordinal));
                        std::this_thread::sleep_for(bounded_ms(schedule.silent_response_ms));
                        return 82;
                    }
                    if (trace && schedule.crash_transmit_ordinal == transmit_ordinal) {
                        trace->record("TRANSMIT", transmit_ordinal, "CRASH",
                            request.payload.size(), schedule.name);
                        trace->terminal("RUNTIME_CRASH");
                        append_report(report, "runtime-crash-transmit=" +
                            std::to_string(transmit_ordinal));
                        ::_exit(83);
                    }
                    const auto count = ::send(
                        port,
                        request.payload.data(),
                        request.payload.size(),
                        MSG_DONTWAIT | MSG_NOSIGNAL);
                    response.type = FrameType::transmit_response;
                    response.status = count == static_cast<ssize_t>(request.payload.size()) ?
                        Status::ok : Status::busy;
                    if (trace) {
                        trace->record("TRANSMIT", transmit_ordinal, "RESPOND",
                            request.payload.size(), schedule.name);
                    }
                    break;
                }
                case FrameType::receive_request: {
                    ++receive_ordinal;
                    if (trace && schedule.silent_receive_ordinal == receive_ordinal) {
                        trace->record("RECEIVE", receive_ordinal, "SILENT", 0U, schedule.name);
                        trace->terminal("RUNTIME_SILENT");
                        append_report(report, "runtime-silent-receive=" +
                            std::to_string(receive_ordinal));
                        std::this_thread::sleep_for(bounded_ms(schedule.silent_response_ms));
                        return 82;
                    }
                    Bytes packet(mtu + 1U);
                    const auto count = ::recv(port, packet.data(), packet.size(), MSG_DONTWAIT);
                    response.type = FrameType::receive_response;
                    response.status = Status::no_data;
                    if (count > 0 && static_cast<std::size_t>(count) <= mtu) {
                        packet.resize(static_cast<std::size_t>(count));
                        response.payload = std::move(packet);
                        response.status = Status::ok;
                    }
                    if (trace) {
                        trace->record("RECEIVE", receive_ordinal, "RESPOND",
                            response.payload.size(), schedule.name);
                    }
                    break;
                }
                case FrameType::ping_request:
                    ++ping_ordinal;
                    response.type = FrameType::ping_response;
                    response.status = Status::ok;
                    if (trace) {
                        trace->record("PING", ping_ordinal, "RESPOND", 0U, schedule.name);
                    }
                    break;
                case FrameType::shutdown_request:
                    response.type = FrameType::shutdown_response;
                    response.status = Status::ok;
                    if (trace) {
                        trace->record("SHUTDOWN", 1U, "RESPOND", 0U, schedule.name);
                    }
                    send_frame(3, response);
                    append_report(report, "shutdown=1");
                    if (trace) { trace->terminal("SHUTDOWN"); }
                    return 0;
                default:
                    break;
            }
            send_frame(3, response);
        }
        if (trace) { trace->terminal("REQUEST_BOUND_EXHAUSTED"); }
        return 79;
    } catch (const std::exception& error) {
        if (trace) {
            try { trace->terminal("ERROR"); } catch (...) {}
        }
        if (!report_path.empty()) {
            try { append_report(report_path, std::string("error=") + error.what()); }
            catch (...) {}
        }
        return 80;
    }
}
