#include "peer_session.hpp"
#include "protocol.hpp"
#include "serial_transport.hpp"
#include "socket.hpp"
#include "tls.hpp"
#include "transport.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <csignal>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <exception>
#include <fcntl.h>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <optional>
#include <poll.h>
#include <pthread.h>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <termios.h>
#include <thread>
#include <unistd.h>
#include <utility>
#include <vector>

namespace {

using natrav_overlay::AppError;
using natrav_overlay::Deadline;
using natrav_overlay::DeliveryReceipt;
using natrav_overlay::EvidenceRecord;
using natrav_overlay::FramedReader;
using natrav_overlay::IoCounters;
using natrav_overlay::IoOptions;
using natrav_overlay::KeyGenerationState;
using natrav_overlay::OrderedByteStream;
using natrav_overlay::OutboundPeerSession;
using natrav_overlay::PeerSessionFrame;
using natrav_overlay::PeerSessionFrameKind;
using natrav_overlay::PeerSessionLimits;
using natrav_overlay::ReceiptDisposition;
using natrav_overlay::SerialFlowControl;
using natrav_overlay::SerialParity;
using natrav_overlay::SerialTransportLocator;
using natrav_overlay::TlsChannel;
using natrav_overlay::TlsContext;
using natrav_overlay::TlsIdentityFiles;
using natrav_overlay::TlsTrustedGeneration;
using natrav_overlay::TlsTrustedIdentity;
using natrav_overlay::TransportKind;
using natrav_overlay::TransportLocator;

struct CaseRecord final {
    std::string name;
    std::size_t assertions{0U};
};

class Probe final {
public:
    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_code(
        Function&& function,
        const std::string_view code,
        const std::string_view detail) {
        bool observed = false;
        try {
            std::forward<Function>(function)();
        } catch (const AppError& error) {
            observed = error.code() == code;
        }
        check(observed, detail);
    }

    template <typename Function>
    void run_case(std::string name, Function&& function) {
        const auto before = assertions_;
        std::forward<Function>(function)();
        cases_.push_back(CaseRecord{
            .name = std::move(name),
            .assertions = assertions_ - before,
        });
    }

    [[nodiscard]] std::size_t assertions() const noexcept { return assertions_; }
    [[nodiscard]] const std::vector<CaseRecord>& cases() const noexcept {
        return cases_;
    }

private:
    std::size_t assertions_{0U};
    std::vector<CaseRecord> cases_;
};

[[nodiscard]] Deadline deadline_after(
    const std::chrono::milliseconds duration = std::chrono::seconds(5)) {
    return std::chrono::steady_clock::now() + duration;
}

[[nodiscard]] TlsIdentityFiles identity(
    const char* certificate,
    const char* private_key,
    const char* pin) {
    return TlsIdentityFiles{
        .certificate = certificate,
        .private_key = private_key,
        .expected_spki_sha256 = natrav_overlay::parse_spki_sha256(pin),
    };
}

[[nodiscard]] datacube::Digest32 operation_id(const std::string_view label) {
    return datacube::sha256(datacube::text_octets(
        std::string("NATRAV_SERIAL_CARRIER_TEST_OPERATION_V1\0", 40U) +
        std::string(label)));
}

[[nodiscard]] EvidenceRecord record(
    const std::string_view label,
    const std::string_view payload) {
    return EvidenceRecord{
        .operation_id = operation_id(label),
        .issuer = "CLIENT",
        .recipient = "SERVER",
        .scope = "serial/session",
        .corrects = std::nullopt,
        .payload = datacube::text_octets(payload),
    };
}

[[nodiscard]] TransportLocator serial_locator(
    const std::string& path,
    const std::uint32_t baud = 115'200U,
    const std::uint8_t data_bits = 8U,
    const SerialParity parity = SerialParity::none,
    const std::uint8_t stop_bits = 1U,
    const SerialFlowControl flow = SerialFlowControl::none) {
    const SerialTransportLocator serial{
        .path = path,
        .baud = baud,
        .data_bits = data_bits,
        .parity = parity,
        .stop_bits = stop_bits,
        .flow_control = flow,
    };
    return natrav_overlay::parse_serial_transport_locator(
        natrav_overlay::serial_transport_locator_text(serial));
}

class PtyEndpoint final {
public:
    static PtyEndpoint create(const bool keep_slave) {
        const int master_raw = ::posix_openpt(
            O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC);
        if (master_raw < 0) {
            throw std::runtime_error("posix_openpt failed");
        }
        datacube::Fd master(master_raw);
        if (::grantpt(master.get()) != 0 || ::unlockpt(master.get()) != 0) {
            throw std::runtime_error("grantpt/unlockpt failed");
        }
        std::array<char, 256U> path_buffer{};
        if (::ptsname_r(master.get(), path_buffer.data(), path_buffer.size()) != 0) {
            throw std::runtime_error("ptsname_r failed");
        }
        std::string path(path_buffer.data());
        datacube::Fd slave;
        if (keep_slave) {
            const int slave_raw = ::open(
                path.c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC);
            if (slave_raw < 0) {
                throw std::runtime_error("PTY slave open failed");
            }
            slave.reset(slave_raw);
        }
        return PtyEndpoint(std::move(master), std::move(slave), std::move(path));
    }

    PtyEndpoint(PtyEndpoint&&) noexcept = default;
    PtyEndpoint& operator=(PtyEndpoint&&) noexcept = default;
    PtyEndpoint(const PtyEndpoint&) = delete;
    PtyEndpoint& operator=(const PtyEndpoint&) = delete;

    [[nodiscard]] int master_fd() const noexcept { return master_.get(); }
    [[nodiscard]] int slave_fd() const noexcept { return slave_.get(); }
    [[nodiscard]] const std::string& path() const noexcept { return path_; }
    void close_master() noexcept { master_.reset(); }
    void close_slave() noexcept { slave_.reset(); }

private:
    PtyEndpoint(datacube::Fd master, datacube::Fd slave, std::string path)
        : master_(std::move(master)),
          slave_(std::move(slave)),
          path_(std::move(path)) {}

    datacube::Fd master_;
    datacube::Fd slave_;
    std::string path_;
};

void write_fd_all(
    const int fd,
    const datacube::OctetView bytes,
    const std::chrono::milliseconds timeout = std::chrono::seconds(5)) {
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const ssize_t count = ::write(fd, bytes.data() + offset, bytes.size() - offset);
        if (count > 0) {
            offset += static_cast<std::size_t>(count);
            continue;
        }
        if (count < 0 && errno == EINTR) {
            continue;
        }
        if (count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
            const auto now = std::chrono::steady_clock::now();
            if (now >= deadline) {
                throw std::runtime_error("PTY write timeout");
            }
            pollfd item{.fd = fd, .events = POLLOUT, .revents = 0};
            static_cast<void>(::poll(&item, 1U, 10));
            continue;
        }
        throw std::runtime_error("PTY write failed");
    }
}

[[nodiscard]] datacube::Octets read_fd_exact(
    const int fd,
    const std::size_t bytes,
    const std::chrono::milliseconds timeout = std::chrono::seconds(5)) {
    datacube::Octets result(bytes);
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    std::size_t offset = 0U;
    while (offset < bytes) {
        const ssize_t count = ::read(fd, result.data() + offset, bytes - offset);
        if (count > 0) {
            offset += static_cast<std::size_t>(count);
            continue;
        }
        if (count < 0 && errno == EINTR) {
            continue;
        }
        if (count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
            const auto now = std::chrono::steady_clock::now();
            if (now >= deadline) {
                throw std::runtime_error("PTY read timeout");
            }
            pollfd item{.fd = fd, .events = POLLIN, .revents = 0};
            static_cast<void>(::poll(&item, 1U, 10));
            continue;
        }
        throw std::runtime_error("PTY read failed");
    }
    return result;
}

class PtyBridge final {
public:
    PtyBridge(const int first, const int second)
        : first_(first), second_(second), worker_([this] { run(); }) {}

    ~PtyBridge() { stop(); }
    PtyBridge(const PtyBridge&) = delete;
    PtyBridge& operator=(const PtyBridge&) = delete;

    void stop() noexcept {
        stop_.store(true, std::memory_order_release);
        if (worker_.joinable()) {
            worker_.join();
        }
    }

private:
    void forward(const int source, const int target) {
        std::array<std::uint8_t, 4096U> buffer{};
        while (!stop_.load(std::memory_order_acquire)) {
            const ssize_t count = ::read(source, buffer.data(), buffer.size());
            if (count > 0) {
                write_fd_all(
                    target,
                    datacube::OctetView(
                        buffer.data(), static_cast<std::size_t>(count)),
                    std::chrono::seconds(2));
                return;
            }
            if (count < 0 && errno == EINTR) {
                continue;
            }
            if (count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
                return;
            }
            return;
        }
    }

    void run() noexcept {
        try {
            while (!stop_.load(std::memory_order_acquire)) {
                std::array<pollfd, 2U> items{
                    pollfd{.fd = first_, .events = POLLIN, .revents = 0},
                    pollfd{.fd = second_, .events = POLLIN, .revents = 0},
                };
                const int result = ::poll(items.data(), items.size(), 10);
                if (result < 0) {
                    if (errno == EINTR) {
                        continue;
                    }
                    return;
                }
                if ((items[0U].revents & POLLIN) != 0) {
                    forward(first_, second_);
                }
                if ((items[1U].revents & POLLIN) != 0) {
                    forward(second_, first_);
                }
            }
        } catch (...) {
            failed_.store(true, std::memory_order_release);
        }
    }

    int first_{-1};
    int second_{-1};
    std::atomic<bool> stop_{false};
    std::atomic<bool> failed_{false};
    std::thread worker_;
};

[[nodiscard]] bool same_termios(
    const termios& left,
    const termios& right) noexcept {
    return left.c_iflag == right.c_iflag &&
        left.c_oflag == right.c_oflag &&
        left.c_cflag == right.c_cflag &&
        left.c_lflag == right.c_lflag &&
        ::cfgetispeed(&left) == ::cfgetispeed(&right) &&
        ::cfgetospeed(&left) == ::cfgetospeed(&right) &&
        std::equal(
            std::begin(left.c_cc), std::end(left.c_cc), std::begin(right.c_cc));
}

volatile sig_atomic_t signal_observed = 0;

extern "C" void test_signal_handler(int) noexcept {
    signal_observed = 1;
}

struct SessionResult final {
    std::array<DeliveryReceipt, 2U> receipts;
    std::size_t server_operations{0U};
    bool clean_close{false};
};

[[nodiscard]] SessionResult run_authenticated_session(
    PtyEndpoint& client_pty,
    PtyEndpoint& server_pty,
    const TlsIdentityFiles& client_identity,
    const TlsIdentityFiles& server_identity) {
    auto listener = natrav_overlay::listen_transport(
        serial_locator(server_pty.path()), 1);
    IoCounters connect_counters;
    auto client_stream = natrav_overlay::connect_transport(
        serial_locator(client_pty.path()),
        deadline_after(std::chrono::seconds(8)),
        connect_counters);
    PtyBridge bridge(client_pty.master_fd(), server_pty.master_fd());

    TlsContext client_context(client_identity);
    TlsContext server_context(server_identity);
    const std::vector<TlsTrustedIdentity> trusted_client{{
        .node_id = "CLIENT",
        .generations = {TlsTrustedGeneration{
            .generation = "client-g1",
            .spki_sha256 = client_identity.expected_spki_sha256,
            .state = KeyGenerationState::active,
        }},
    }};
    const IoOptions io{
        .timeout = std::chrono::seconds(8),
        .read_quantum = 257U,
        .write_quantum = 251U,
        .maximum_received_bytes = 1'048'576U,
    };
    const PeerSessionLimits limits{
        .maximum_operations = 4U,
        .maximum_bytes = 1'048'576U,
        .maximum_lifetime_ms = 20'000U,
        .idle_timeout_ms = 8'000U,
    };
    const std::array<EvidenceRecord, 2U> records{
        record("serial-one", "alpha through a PTY-backed serial carrier"),
        record("serial-two", "beta through the same authenticated session"),
    };

    std::size_t server_operations = 0U;
    bool server_clean_close = false;
    std::exception_ptr server_failure;
    std::thread server([&] {
        try {
            const int ready = listener->readiness_handle();
            if (ready < 0) {
                throw std::runtime_error("serial listener has no readiness handle");
            }
            pollfd item{.fd = ready, .events = POLLIN, .revents = 0};
            const int polled = ::poll(&item, 1U, 8'000);
            if (polled != 1 ||
                (item.revents & (POLLIN | POLLHUP | POLLERR)) == 0) {
                throw std::runtime_error("serial listener did not become ready");
            }
            auto server_stream = listener->accept_ready();
            if (!server_stream) {
                throw std::runtime_error("serial listener did not accept ready stream");
            }
            IoCounters server_tls;
            IoCounters server_io;
            const auto deadline = deadline_after(std::chrono::seconds(8));
            auto channel = TlsChannel::accept(
                server_context, *server_stream, trusted_client,
                deadline, server_tls);
            FramedReader reader(io);
            const auto hello = natrav_overlay::perform_server_handshake(
                channel, "SERVER", reader, deadline, io);
            if (hello.remote_artifact_digest !=
                natrav_overlay::node_artifact_digest("CLIENT")) {
                throw std::runtime_error("server HELLO identity mismatch");
            }
            const auto open = natrav_overlay::decode_peer_session_frame(
                reader.read_frame(channel, deadline, server_io));
            if (open.kind != PeerSessionFrameKind::open ||
                !open.limits.has_value()) {
                throw std::runtime_error("server did not receive NOS1 OPEN");
            }
            const PeerSessionFrame acknowledgement{
                .kind = PeerSessionFrameKind::open_ack,
                .flags = 0U,
                .session_id = open.session_id,
                .sequence = 0U,
                .operation_id = {},
                .limits = *open.limits,
                .payload = {},
            };
            natrav_overlay::write_frame(
                channel,
                natrav_overlay::encode_peer_session_frame(acknowledgement),
                deadline,
                io,
                server_io);

            for (std::uint32_t sequence = 1U; sequence <= 2U; ++sequence) {
                const auto request = natrav_overlay::decode_peer_session_frame(
                    reader.read_frame(channel, deadline, server_io));
                if (request.kind != PeerSessionFrameKind::request ||
                    request.session_id != open.session_id ||
                    request.sequence != sequence) {
                    throw std::runtime_error("server request envelope mismatch");
                }
                const auto message = natrav_overlay::decode_application_message(
                    request.payload);
                const auto* evidence = std::get_if<EvidenceRecord>(&message);
                if (evidence == nullptr ||
                    evidence->operation_id != request.operation_id) {
                    throw std::runtime_error("server application binding mismatch");
                }
                ++server_operations;
                const DeliveryReceipt receipt{
                    .operation_id = evidence->operation_id,
                    .recipient = evidence->recipient,
                    .recorder = evidence->recipient,
                    .disposition = ReceiptDisposition::committed,
                    .sequence = sequence,
                    .record_digest =
                        natrav_overlay::evidence_record_digest(*evidence),
                };
                const PeerSessionFrame response{
                    .kind = PeerSessionFrameKind::response,
                    .flags = 0U,
                    .session_id = open.session_id,
                    .sequence = sequence,
                    .operation_id = evidence->operation_id,
                    .limits = std::nullopt,
                    .payload = natrav_overlay::encode_application_message(receipt),
                };
                natrav_overlay::write_frame(
                    channel,
                    natrav_overlay::encode_peer_session_frame(response),
                    deadline,
                    io,
                    server_io);
            }

            const auto close = natrav_overlay::decode_peer_session_frame(
                reader.read_frame(channel, deadline, server_io));
            if (close.kind != PeerSessionFrameKind::close ||
                close.session_id != open.session_id || close.sequence != 3U) {
                throw std::runtime_error("server clean-close envelope mismatch");
            }
            const PeerSessionFrame close_ack{
                .kind = PeerSessionFrameKind::close_ack,
                .flags = 0U,
                .session_id = open.session_id,
                .sequence = close.sequence,
                .operation_id = {},
                .limits = std::nullopt,
                .payload = {},
            };
            natrav_overlay::write_frame(
                channel,
                natrav_overlay::encode_peer_session_frame(close_ack),
                deadline,
                io,
                server_io);
            std::array<std::uint8_t, 1U> tls_eof{};
            if (channel.read_some(
                    tls_eof, deadline, server_tls,
                    "server waits for serial TLS close-notify") != 0U) {
                throw std::runtime_error("bytes followed NOS1 close");
            }
            channel.close_notify(deadline, server_tls);
            server_clean_close = true;
        } catch (...) {
            server_failure = std::current_exception();
        }
    });

    std::array<DeliveryReceipt, 2U> receipts;
    bool client_clean_close = false;
    std::exception_ptr client_failure;
    try {
        auto session = OutboundPeerSession::open_connected(
            client_context,
            "CLIENT",
            "SERVER",
            "server-g1",
            KeyGenerationState::active,
            server_identity.expected_spki_sha256,
            std::move(client_stream),
            records[0U].operation_id,
            io,
            limits);
        receipts[0U] = session.exchange(records[0U], io);
        receipts[1U] = session.exchange(records[1U], io);
        client_clean_close = session.close_cleanly(io);
    } catch (...) {
        client_failure = std::current_exception();
        client_pty.close_master();
        server_pty.close_master();
    }
    server.join();
    bridge.stop();
    if (client_failure) {
        std::rethrow_exception(client_failure);
    }
    if (server_failure) {
        std::rethrow_exception(server_failure);
    }
    return SessionResult{
        .receipts = receipts,
        .server_operations = server_operations,
        .clean_close = client_clean_close && server_clean_close,
    };
}

}  // namespace

int main(int argc, char* argv[]) {
    try {
        if (argc != 8) {
            throw std::runtime_error(
                "expected client cert/key/pin, server cert/key/pin, and scratch directory");
        }
        const auto client_identity = identity(argv[1], argv[2], argv[3]);
        const auto server_identity = identity(argv[4], argv[5], argv[6]);
        const std::filesystem::path scratch(argv[7]);
        std::filesystem::create_directories(scratch);
        Probe probe;

        probe.run_case("canonical locator and capability boundary", [&] {
            const SerialTransportLocator value{
                .path = "/dev/tty test,one|two%three",
                .baud = 115'200U,
                .data_bits = 7U,
                .parity = SerialParity::even,
                .stop_bits = 2U,
                .flow_control = SerialFlowControl::software,
            };
            const auto text = natrav_overlay::serial_transport_locator_text(value);
            const auto parsed = natrav_overlay::parse_serial_transport_locator(text);
            probe.check(parsed.kind == TransportKind::serial,
                "serial locator has the serial kind");
            probe.check(parsed.serial.path == value.path &&
                        parsed.serial.baud == value.baud &&
                        parsed.serial.data_bits == value.data_bits &&
                        parsed.serial.parity == value.parity &&
                        parsed.serial.stop_bits == value.stop_bits &&
                        parsed.serial.flow_control == value.flow_control,
                "canonical locator round-trips every line setting");
            probe.check(text.find("%20") != std::string::npos &&
                        text.find("%2C") != std::string::npos &&
                        text.find("%7C") != std::string::npos &&
                        text.find("%25") != std::string::npos,
                "unsafe path bytes are canonically escaped");
            probe.check(
                natrav_overlay::parse_configured_transport_locator(
                    text, false).kind == TransportKind::serial,
                "self-describing configured locator selects serial");
            probe.check(
                natrav_overlay::parse_configured_transport_locator(
                    "127.0.0.1:443", false).kind == TransportKind::tcp,
                "predecessor TCP locator remains unchanged");
            probe.check(
                natrav_overlay::parse_transport_kind("serial") ==
                    TransportKind::serial,
                "serial is an explicit production transport kind");
            const auto capabilities =
                natrav_overlay::transport_capabilities(TransportKind::serial);
            probe.check(capabilities.ordered && capabilities.full_duplex &&
                        capabilities.can_dial && capabilities.can_listen &&
                        !capabilities.reliable_stream &&
                        !capabilities.can_shutdown_write,
                "serial capabilities do not promise reliability or half-close");
            probe.expect_code(
                [&] { static_cast<void>(natrav_overlay::parse_serial_transport_locator(
                    "serial-v1|path=/dev/ttyS0|baud=0115200|data=8|parity=none|stop=1|flow=none")); },
                "SERIAL_LOCATOR_NONCANONICAL",
                "noncanonical decimal spelling is rejected");
            probe.expect_code(
                [&] { static_cast<void>(natrav_overlay::parse_serial_transport_locator(
                    "serial-v1|path=dev/ttyS0|baud=115200|data=8|parity=none|stop=1|flow=none")); },
                "SERIAL_LOCATOR_INVALID",
                "relative device paths are rejected");
            probe.expect_code(
                [&] { static_cast<void>(natrav_overlay::parse_serial_transport_locator(
                    "serial-v1|path=/dev/ttyS0|baud=12345|data=8|parity=none|stop=1|flow=none")); },
                "SERIAL_SETTING_UNSUPPORTED",
                "unsupported baud rates are rejected");
        });

        probe.run_case("path safety and character-device validation", [&] {
            const auto regular = scratch / "not-a-device";
            {
                std::ofstream out(regular);
                out << "not a tty\n";
            }
            IoCounters counters;
            probe.expect_code(
                [&] { static_cast<void>(natrav_overlay::connect_transport(
                    serial_locator(regular.string()), deadline_after(), counters)); },
                "SERIAL_DEVICE_NOT_CHARACTER",
                "regular files cannot become serial carriers");

            auto pty = PtyEndpoint::create(true);
            const auto alias = scratch / "tty-symlink";
            std::filesystem::create_symlink(pty.path(), alias);
            probe.expect_code(
                [&] { static_cast<void>(natrav_overlay::connect_transport(
                    serial_locator(alias.string()), deadline_after(), counters)); },
                "SERIAL_PATH_SYMLINK_REJECTED",
                "the final device path component is not followed through a symlink");
        });

        probe.run_case("owned termios, finite quanta, deadline, interruption, and restore", [&] {
            auto pty = PtyEndpoint::create(true);
            termios original {};
            probe.check(::tcgetattr(pty.slave_fd(), &original) == 0,
                "original PTY termios is observable");
            IoCounters counters;
            auto stream = natrav_overlay::connect_transport(
                serial_locator(
                    pty.path(), 115'200U, 8U, SerialParity::none, 1U,
                    SerialFlowControl::none),
                deadline_after(), counters);
            termios configured {};
            probe.check(::tcgetattr(pty.slave_fd(), &configured) == 0,
                "configured PTY termios is observable");
            probe.check(::cfgetispeed(&configured) == B115200 &&
                        ::cfgetospeed(&configured) == B115200,
                "input and output baud are explicitly applied");
            probe.check((configured.c_cflag & CSIZE) == CS8 &&
                        (configured.c_cflag & (PARENB | CSTOPB)) == 0 &&
                        (configured.c_cflag & (CLOCAL | CREAD)) ==
                            (CLOCAL | CREAD),
                "8N1 and local receiver ownership are explicitly applied");
            probe.check((configured.c_lflag & (ECHO | ICANON | ISIG | IEXTEN)) == 0 &&
                        (configured.c_oflag & OPOST) == 0 &&
                        configured.c_cc[VMIN] == 1 && configured.c_cc[VTIME] == 0,
                "raw noncanonical line discipline is explicitly applied");
            probe.expect_code(
                [&] { stream->shutdown_write(); },
                "TRANSPORT_HALF_CLOSE_UNSUPPORTED",
                "serial does not pretend to support TCP write half-close");

            const auto inbound = datacube::text_octets("serial-inbound");
            write_fd_all(pty.master_fd(), inbound);
            std::array<std::uint8_t, 64U> read_buffer{};
            const auto read_count = stream->read_some(
                read_buffer, deadline_after(), counters, "serial inbound read");
            probe.check(read_count == inbound.size() &&
                        std::equal(inbound.begin(), inbound.end(), read_buffer.begin()),
                "bytes written at the PTY master reach the ordered stream exactly");

            const auto outbound = datacube::text_octets("serial-outbound");
            const auto write_count = stream->write_some(
                outbound, deadline_after(), counters, "serial outbound write");
            probe.check(write_count == outbound.size() &&
                        read_fd_exact(pty.master_fd(), outbound.size()) == outbound,
                "ordered-stream writes reach the PTY master exactly");

            datacube::Octets large(5'000U, static_cast<std::uint8_t>('x'));
            const auto bounded = stream->write_some(
                large, deadline_after(), counters, "serial bounded write");
            probe.check(bounded == 4'096U,
                "one serial write is capped at the finite carrier quantum");
            static_cast<void>(read_fd_exact(pty.master_fd(), bounded));

            probe.expect_code(
                [&] {
                    std::array<std::uint8_t, 1U> value{};
                    static_cast<void>(stream->read_some(
                        value,
                        deadline_after(std::chrono::milliseconds(40)),
                        counters,
                        "serial deadline"));
                },
                "IO_TIMEOUT",
                "serial reads honor the absolute deadline");

            struct sigaction action {};
            action.sa_handler = test_signal_handler;
            ::sigemptyset(&action.sa_mask);
            action.sa_flags = 0;
            probe.check(::sigaction(SIGUSR1, &action, nullptr) == 0,
                "test interruption signal is installed without restart");
            IoCounters interrupted_counters;
            std::uint8_t interrupted_value = 0U;
            std::exception_ptr interrupted_failure;
            std::atomic<bool> reader_started{false};
            std::thread reader([&] {
                try {
                    reader_started.store(true, std::memory_order_release);
                    std::array<std::uint8_t, 1U> value{};
                    const auto count = stream->read_some(
                        value, deadline_after(std::chrono::seconds(2)),
                        interrupted_counters, "serial interrupted read");
                    if (count == 1U) {
                        interrupted_value = value[0U];
                    }
                } catch (...) {
                    interrupted_failure = std::current_exception();
                }
            });
            while (!reader_started.load(std::memory_order_acquire)) {
                std::this_thread::yield();
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(40));
            for (int attempt = 0; attempt < 3; ++attempt) {
                static_cast<void>(::pthread_kill(reader.native_handle(), SIGUSR1));
                std::this_thread::sleep_for(std::chrono::milliseconds(20));
            }
            const std::array<std::uint8_t, 1U> wake{static_cast<std::uint8_t>('I')};
            write_fd_all(pty.master_fd(), wake);
            reader.join();
            if (interrupted_failure) {
                std::rethrow_exception(interrupted_failure);
            }
            probe.check(signal_observed != 0 &&
                        interrupted_counters.interrupted >= 1U &&
                        interrupted_value == static_cast<std::uint8_t>('I'),
                "EINTR is counted and the same bounded read resumes successfully");

            stream.reset();
            termios restored {};
            probe.check(::tcgetattr(pty.slave_fd(), &restored) == 0 &&
                        same_termios(original, restored),
                "destruction restores the exact preexisting termios state");
        });

        probe.run_case("listener ownership and reconnect", [&] {
            auto pty = PtyEndpoint::create(false);
            auto listener = natrav_overlay::listen_transport(
                serial_locator(pty.path()), 64);
            probe.check(listener->transport_kind() == TransportKind::serial &&
                        listener->readiness_handle() >= 0,
                "serial listener owns one configured point-to-point device");
            const std::array<std::uint8_t, 1U> value{static_cast<std::uint8_t>('L')};
            write_fd_all(pty.master_fd(), value);
            pollfd item{
                .fd = listener->readiness_handle(),
                .events = POLLIN,
                .revents = 0,
            };
            probe.check(::poll(&item, 1U, 1'000) == 1,
                "incoming serial bytes make the listener ready");
            auto accepted = listener->accept_ready();
            probe.check(accepted != nullptr &&
                        listener->readiness_handle() == -1,
                "accept transfers exclusive stream ownership");
            IoCounters counters;
            std::array<std::uint8_t, 1U> received{};
            probe.check(accepted->read_some(
                    received, deadline_after(), counters,
                    "accepted serial byte") == 1U && received == value,
                "the accepted stream receives the triggering byte");
            accepted.reset();
            probe.check(listener->readiness_handle() >= 0,
                "listener reopens only after the prior stream is destroyed");

            IoCounters competing_counters;
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::connect_transport(
                        serial_locator(pty.path()), deadline_after(),
                        competing_counters));
                },
                "SERIAL_DEVICE_BUSY",
                "listener exclusivity prevents a simultaneous dial");

            listener.reset();
            IoCounters first_counters;
            auto first = natrav_overlay::connect_transport(
                serial_locator(pty.path()), deadline_after(), first_counters);
            probe.check(first->transport_kind() == TransportKind::serial,
                "device can be reacquired after listener destruction");
            first.reset();
            IoCounters second_counters;
            auto second = natrav_overlay::connect_transport(
                serial_locator(pty.path()), deadline_after(), second_counters);
            probe.check(second->transport_kind() == TransportKind::serial,
                "serial device reconnect succeeds after stream destruction");
        });

        probe.run_case("hangup and reset-like device failure", [&] {
            auto pty = PtyEndpoint::create(false);
            IoCounters counters;
            auto stream = natrav_overlay::connect_transport(
                serial_locator(pty.path()), deadline_after(), counters);
            pty.close_master();
            std::array<std::uint8_t, 1U> value{};
            bool explicit_disconnect = false;
            try {
                explicit_disconnect = stream->read_some(
                    value, deadline_after(std::chrono::milliseconds(500)),
                    counters, "serial hangup read") == 0U;
            } catch (const AppError& error) {
                explicit_disconnect = error.code() == "SERIAL_DISCONNECTED";
            }
            probe.check(explicit_disconnect,
                "PTY hangup is retained as EOF or an explicit serial disconnect");
            probe.expect_code(
                [&] {
                    const auto byte = datacube::text_octets("x");
                    static_cast<void>(stream->write_some(
                        byte, deadline_after(std::chrono::milliseconds(500)),
                        counters, "serial hangup write"));
                },
                "SERIAL_DISCONNECTED",
                "writes after PTY hangup retain reset-like failure semantics");
        });

        probe.run_case("authenticated TLS, HELLO, NOS1, receipts, and semantic close", [&] {
            auto client_pty = PtyEndpoint::create(false);
            auto server_pty = PtyEndpoint::create(false);
            const auto result = run_authenticated_session(
                client_pty, server_pty, client_identity, server_identity);
            probe.check(result.clean_close,
                "NOS1 and TLS close semantically without serial half-close");
            probe.check(result.server_operations == 2U,
                "one PTY-backed authenticated session carries multiple operations");
            probe.check(result.receipts[0U].disposition ==
                            ReceiptDisposition::committed &&
                        result.receipts[0U].sequence == 1U &&
                        result.receipts[1U].sequence == 2U,
                "exact application receipts survive the serial carrier");
        });

        std::cout << "{\"format\":\"NATRAV_SERIAL_TRANSPORT_PROBE_V1\","
                  << "\"status\":\"PASS\",\"cases\":[";
        for (std::size_t index = 0U; index < probe.cases().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            const auto& item = probe.cases()[index];
            std::cout << "{\"name\":"
                      << natrav_overlay::json_string(item.name)
                      << ",\"assertions\":" << item.assertions << '}';
        }
        std::cout << "],\"assertions\":" << probe.assertions() << "}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
