#!/usr/bin/env python3
"""Native authorized evidence reads, bounded pages, cursor safety and continuity."""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import struct
import time
from typing import Any

from run_persistent import Harness, free_port, operation, raw_control, receive_exact
from run_local_administration import v8_config, run_as_uid, expose_control_for_uid
from run_live_configuration import candidate, activate, wait_state
from run_peer_sessions import submit, revise
from run_state_authentication import new_key, migrate, start as start_keyed

OWNER_CLASSES = ["INSPECT", "SUBMIT", "ACTION", "MAINTENANCE", "CONFIGURATION", "SHUTDOWN"]
READ_CLASSES = ["EVIDENCE_READ", "EVIDENCE_PAYLOAD"]


def config(h: Harness, name: str, node: str, state: Path, port: int,
           peers: list[tuple[str, int]] | None = None,
           inbound: list[str] | None = None,
           grants: list[tuple[int, list[str]]] | None = None) -> Path:
    path = v8_config(h, name, node, state, port, name + "-g1",
                     grants or [(os.geteuid(), OWNER_CLASSES + READ_CLASSES)], peers, inbound,
                     deadline_ms=2000)
    text = path.read_text().replace("CONFIG_V8", "CONFIG_V9")
    for peer in sorted(set([p for p, _ in peers or []] + (inbound or []))):
        for scope in ["query/series", "query/other", "query/binary", "query/concurrent"]:
            text += f"authorize={peer},*,EVIDENCE,{scope}\n"
    path.write_text(text)
    path.chmod(0o600)
    return path


def query_args(state: Path, **kwargs: Any) -> list[str]:
    result = ["evidence-query", "--control", str(state / "control.sock"), "--deadline-ms", "4000"]
    for key, value in kwargs.items():
        result += ["--" + key.replace("_", "-"), str(value)]
    return result


def query(h: Harness, label: str, state: Path, expected: int = 0, **kwargs: Any) -> dict[str, Any]:
    result = h.run(label, query_args(state, **kwargs), expected=expected)
    assert result is not None
    if expected == 0:
        h.check(result["format"] == "NATRAV_OVERLAY_EVIDENCE_QUERY_V1", "versioned query response")
        h.check(result["returned_records"] == len(result["records"]), "exact record account")
        # h.run retains the original JSON, not a reserialized size estimate.
        raw = next(c["stdout"] for c in reversed(h.commands) if c["label"] == label).strip()
        h.check(len(raw.encode()) <= int(kwargs.get("max_bytes", 60000)), "complete annotated JSON within caller byte budget")
    return result


def pair(h: Harness, prefix: str, extra_grants: list[tuple[int, list[str]]] | None = None, other_issuer: bool = False) -> tuple[Any, ...]:
    a, b = h.runtime / (prefix + "-a"), h.runtime / (prefix + "-b")
    ap, bp = free_port(), free_port()
    ac = config(h, prefix + "-a", "A", a, ap, [("B", bp)])
    grants = [(os.geteuid(), OWNER_CLASSES + READ_CLASSES)] + (extra_grants or [])
    bc = config(h, prefix + "-b", "B", b, bp, inbound=["A", "C"] if other_issuer else ["A"], grants=grants)
    bd = h.start(prefix + "-b", bc, b)
    ad = h.start(prefix + "-a", ac, a)
    return a, b, ac, bc, ad, bd


def send(h: Harness, label: str, a: Path, value: str = "evidence", scope: str = "query/series") -> str:
    op = operation(label)
    submit(h, label, a / "control.sock", "A", "B", scope, op, value)
    wait_state(h, a, op, "ACKED", label + "-ack")
    return op


def wire_query(*, history: bool = False, payload: bool = False, issuer: str = "", scope: str = "",
               op: str | None = None, limit: int = 32, max_bytes: int = 60000,
               offset: int = 0, length: int = 0, cursor: str = "") -> bytes:
    def txt(s: str) -> bytes:
        v = s.encode(); return struct.pack("!H", len(v)) + v
    return (b"NOC1\x0fNEQ1" + bytes([history, payload]) + txt(issuer) + txt(scope) +
            bytes([op is not None]) + (bytes.fromhex(op) if op else b"") +
            struct.pack("!IIII", limit, max_bytes, offset, length) + txt(cursor))


def cases(h: Harness, selected: set[str] | None = None) -> None:
    def case(name: str, f: Any) -> None:
        if selected is None or name in selected: h.case(name, f)

    def policy_and_wire() -> None:
        state = h.runtime / "policy"
        old = v8_config(h, "legacy-policy", "P", state, free_port(), "policy-g1", [(os.geteuid(), ["ALL"])])
        d = h.start("legacy-policy", old, state)
        q = query(h, "legacy-all-not-read", state, 3)
        h.check(q["code"] == "LOCAL_CONTROL_CLASS_DENIED", "legacy ALL never gains evidence reads")
        h.check(h.status("legacy-still-status", state)["ok"], "legacy metadata status remains available")
        upgraded=candidate(h,old,"legacy-explicit-v9","policy-upgrade-g1",lambda s:s.replace("CONFIG_V8","CONFIG_V9").replace(
            f"local_control={os.geteuid()},ALL",f"local_control={os.geteuid()},"+",".join(OWNER_CLASSES+READ_CLASSES)))
        activate(h,"explicit-v9-adoption",state,upgraded)
        h.check(query(h,"explicit-v9-read",state)["records"]==[],"V8 state explicitly adopts V9 through running daemon")
        d.shutdown()
        d=h.start("upgraded-original-seed",old,state)
        h.check(query(h,"v9-restart-original-seed",state)["configuration_generation"]=="policy-upgrade-g1","accepted read policy survives original-seed restart")
        d.shutdown()
        bad = candidate(h, old, "v8-new-class", "policy-g2",
                        lambda s:s.replace(f"local_control={os.geteuid()},ALL", f"local_control={os.geteuid()},EVIDENCE_READ"))
        h.check(h.run("v8-new-class-rejected", ["config-check", "--config", str(bad)], expected=3)["code"] == "CONFIG_VERSION_REJECTED", "new grants require explicit V9 adoption")
        fresh = h.runtime / "policy-v9"
        conf = config(h, "policy-v9", "P", fresh, free_port())
        bad = candidate(h, conf, "payload-only", "policy-bad", lambda s:s.replace(",EVIDENCE_READ,EVIDENCE_PAYLOAD", ",EVIDENCE_PAYLOAD"))
        h.check(h.run("payload-only-denied", ["config-check", "--config", str(bad)], expected=3)["code"] == "CONFIG_EVIDENCE_READ_REQUIRED", "payload privilege cannot stand alone")
        reordered = h.work / "policy-reordered.conf"
        lines = conf.read_text().splitlines(); reordered.write_text(lines[0]+"\n"+"\n".join(reversed(lines[1:]))+"\n");reordered.chmod(0o600)
        first = h.run("policy-canonical", ["config-check", "--config", str(conf)])
        second = h.run("policy-canonical-order", ["config-check", "--config", str(reordered)])
        h.check(first["local_control"] == second["local_control"], "read grant digest independent of order")
        d = h.start("policy-v9", conf, fresh)
        raw = wire_query()
        ok, empty = raw_control(d.control, raw)
        h.check(ok and empty["records"] == [] and empty["next_cursor"] is None, "independent NEQ1 request encoding")
        for label, data in [("zero-limit", wire_query(limit=0)), ("over-limit", wire_query(limit=129)),
                            ("response-too-small",wire_query(max_bytes=4095)), ("payload-too-large",wire_query(payload=True,length=16385)),
                            ("invalid-mode", b"NOC1\x0fNEQ1\x02"+raw[10:]), ("trailing",raw+b"x"),
                            ("short",raw[:-1]),("short-cursor",wire_query(cursor="aa"))]:
            before=(fresh/"state.journal").stat().st_size
            ok, response=raw_control(d.control,data)
            h.check(not ok and "records" not in response, label + " is rejected without evidence")
            h.check((fresh/"state.journal").stat().st_size > before, label + " denied read retained in local audit")
        d.shutdown()
    case("policy_compatibility_and_independent_wire", policy_and_wire)

    def views_and_payloads() -> None:
        a,b,ac,bc,ad,bd=pair(h,"views",other_issuer=True)
        c=h.runtime/"views-c"
        bp=int(next(line for line in bc.read_text().splitlines() if line.startswith("listen=")).rsplit(":",1)[1])
        cc=config(h,"views-c","C",c,free_port(),[("B",bp)])
        cd=h.start("views-c",cc,c)
        c_op=operation("views-c-operation")
        submit(h,"views-c-submit",cd.control,"C","B","query/series",c_op,"other issuer")
        wait_state(h,c,c_op,"ACKED","views-c-ack")
        original=send(h,"views-original",a,"initial")
        extra=send(h,"views-independent",a,"independent")
        revised=operation("views-correction")
        revise(h,"views-correct",ad.control,"A","B","query/series",revised,original,"corrected")
        wait_state(h,a,revised,"ACKED","views-correction-ack")
        send(h,"views-other",a,"excluded","query/other")
        before=(b/"state.journal").read_bytes()
        current=query(h,"views-current",b,issuer="A",scope="query/series")
        history=query(h,"views-history",b,view="history",issuer="A",scope="query/series")
        h.check([r["operation_id"] for r in current["records"]] == [extra,revised], "current view returns correction heads, not an arbitrary latest-per-scope record")
        h.check([r["operation_id"] for r in history["records"]] == [original,extra,revised], "history is attributable admission order")
        mixed=query(h,"views-mixed-issuers",b,scope="query/series")
        h.check({r["issuer"] for r in mixed["records"]}=={"A","C"}, "two actual authenticated issuers share one scope")
        h.check([r["operation_id"] for r in query(h,"views-exact-C",b,issuer="C")["records"]]==[c_op],"exact issuer separates two real senders")
        h.check(history["records"][0]["superseded_by"] == revised and history["records"][2]["corrects"] == original, "bidirectional correction links")
        h.check(all(r["authorization"]["peer_generation"]=="a-g1" and r["authorization"]["rule_digest"] for r in history["records"]), "admission generation and policy provenance")
        h.check(all("payload_hex" not in r for r in history["records"]), "metadata query does not include payload")
        h.check(query(h,"exact-old-current",b,operation=original)["records"] == [], "exact operation does not silently follow a correction")
        h.check(query(h,"exact-old-history",b,view="history",operation=original)["returned_records"] == 1, "history exact selector retrieves superseded original")
        h.check(query(h,"wrong-issuer",b,issuer="D")["records"]==[], "issuer filter exact")
        h.check(query(h,"wrong-scope-prefix",b,scope="query/ser")["records"]==[], "scope filter is not prefix matching")
        # Reproduce the exact selection digest with Python hashlib and an
        # independently described canonical metadata representation.
        def txt(value: str) -> bytes:
            data=value.encode();return struct.pack("!H",len(data))+data
        seed=b"NATRAV_OVERLAY_EVIDENCE_SELECTION_V1"+txt("B")+b"\x01"+txt("A")+txt("query/series")+b"\x00"
        digest=hashlib.sha256(seed).digest()
        fields=("sequence","operation_id","issuer","recipient","scope","record_digest","payload_size","corrects","superseded_by","authorization")
        for row in history["records"]:
            leaf=json.dumps({f:row[f] for f in fields},separators=(",",":"),ensure_ascii=True).encode()
            digest=hashlib.sha256(digest+struct.pack("!I",len(leaf))+leaf).digest()
        h.check(digest.hex()==history["selection_digest"],"independently reproduced selected-view digest")
        spec=wire_query(history=True,issuer="A",scope="query/series")[5:-2]
        h.check(hashlib.sha256(spec).hexdigest()==history["query_digest"],"independent request specification digest")
        h.check((b/"state.journal").read_bytes()==before, "successful evidence reads do not mutate journal")
        data=bytes(range(256))*234 + bytes(range(96))
        h.check(len(data)==60000,"maximum accepted binary payload fixture")
        payload=h.work/"binary-payload.bin";payload.write_bytes(data)
        op=operation("views-binary")
        h.run("submit-binary",["submit","--control",str(ad.control),"--node","A","--peer","B","--scope","query/binary","--operation",op,"--payload-file",str(payload),"--deadline-ms","4000"])
        wait_state(h,a,op,"ACKED","binary-ack")
        assembled=bytearray()
        for offset in range(0,len(data),16384):
            result=query(h,f"binary-chunk-{offset}",b,operation=op,payload="yes",payload_offset=offset,payload_length=16384)
            row=result["records"][0];chunk=bytes.fromhex(row["payload_hex"]);assembled+=chunk
            h.check(row["payload_returned_bytes"]==len(chunk) and row["payload_size"]==60000,"exact binary slice accounting")
        h.check(bytes(assembled)==data and not row["payload_more"],"reconstructed all 60000 binary bytes exactly")
        h.check(query(h,"payload-range-reject",b,3,operation=original,view="history",payload="yes",payload_offset=100)["code"]=="EVIDENCE_PAYLOAD_RANGE","out-of-range slices fail explicitly")
        h.check(query(h,"page-too-small",b,3,operation=op,payload="yes",payload_length=16384,max_bytes=4096)["code"]=="EVIDENCE_QUERY_PAGE_TOO_SMALL","oversize first record is never silently skipped")
        h.run("quiesce-query",["quiesce","--control",str(bd.control),"--reason","query during maintenance"])
        quiesced=query(h,"quiesced-query",b,operation=op,payload="yes",payload_length=1)
        h.check(quiesced["records"][0]["payload_hex"]=="00","authorized reads remain available while quiesced")
        cd.shutdown();ad.shutdown();bd.shutdown()
    case("current_history_binary_payload_and_quiescence",views_and_payloads)

    def cursors() -> None:
        a,b,ac,bc,ad,bd=pair(h,"cursors")
        ops=[send(h,f"cursor-record-{i}",a,str(i)) for i in range(6)]
        first=query(h,"cursor-first",b,scope="query/series",limit=2)
        token=first["next_cursor"];h.check(isinstance(token,str) and len(token)==304,"fixed bounded authenticated cursor")
        damaged=token[:-1]+("0" if token[-1]!="0" else "1")
        h.check(query(h,"cursor-bad-mac",b,3,scope="query/series",limit=2,cursor=damaged)["code"]=="EVIDENCE_CURSOR_INVALID","altered cursor authentication rejected")
        h.check(query(h,"cursor-changed-filter",b,3,scope="query/other",limit=2,cursor=token)["code"]=="EVIDENCE_CURSOR_CONTEXT_MISMATCH","cursor cannot select different filter")
        h.check(query(h,"cursor-changed-limit",b,3,scope="query/series",limit=3,cursor=token)["code"]=="EVIDENCE_CURSOR_CONTEXT_MISMATCH","cursor includes response shaping contract")
        h.run("cursor-compact",["compact","--control",str(bd.control)])
        second=query(h,"cursor-after-compaction",b,scope="query/series",limit=2,cursor=token)
        h.check(second["selection_digest"]==first["selection_digest"],"compaction leaves selected evidence root stable")
        send(h,"cursor-unrelated-write",a,"outside selection","query/other")
        third=query(h,"cursor-final",b,scope="query/series",limit=2,cursor=second["next_cursor"])
        h.check([r["operation_id"] for p in [first,second,third] for r in p["records"]]==ops and third["next_cursor"] is None,"complete paging without duplicate or omission despite unrelated mutation")
        replay=query(h,"cursor-replay",b,scope="query/series",limit=2,cursor=token)
        h.check(replay["records"]==second["records"],"read-only cursor replay is deterministic")
        revised=operation("cursor-correction")
        revise(h,"cursor-correct",ad.control,"A","B","query/series",revised,ops[0],"changed")
        wait_state(h,a,revised,"ACKED","cursor-correct-ack")
        h.check(query(h,"cursor-selected-write-stale",b,3,scope="query/series",limit=2,cursor=token)["code"]=="EVIDENCE_CURSOR_STALE","selected correction explicitly invalidates old page")
        refreshed=query(h,"cursor-refresh",b,scope="query/series",limit=1)
        changed=candidate(h,bc,"cursor-config-change","cursors-b-g2",lambda s:s.replace("deadline_ms=2000","deadline_ms=1900"))
        activate(h,"cursor-activate",b,changed)
        h.check(query(h,"cursor-config-mismatch",b,3,scope="query/series",limit=1,cursor=refreshed["next_cursor"])["code"]=="EVIDENCE_CURSOR_CONTEXT_MISMATCH","accepted generation binds cursor")
        fresh=query(h,"cursor-before-restart",b,scope="query/series",limit=1)
        bd.shutdown();bd=h.start("cursor-restart",bc,b)
        h.check(query(h,"cursor-restart-invalid",b,3,scope="query/series",limit=1,cursor=fresh["next_cursor"])["code"]=="EVIDENCE_CURSOR_INVALID","restart invalidates ephemeral cursor")
        h.check(query(h,"cursor-restarted-root",b,scope="query/series",limit=1)["selection_digest"]==fresh["selection_digest"],"fresh query reconstructs identical root after restart")
        ad.shutdown();bd.shutdown()
    case("cursor_authentication_staleness_and_maintenance",cursors)

    def principals() -> None:
        if os.geteuid()!=0 or not Path("/usr/bin/setpriv").exists():
            raise RuntimeError("real UID tests require root and setpriv in this container")
        uid=65534; gid=65534
        a,b,ac,bc,ad,bd=pair(h,"principals",[(uid,["INSPECT","EVIDENCE_READ"])])
        send(h,"principal-record-1",a);send(h,"principal-record-2",a)
        expose_control_for_uid(b)
        read=run_as_uid(h,"uid-metadata",uid,gid,query_args(b,limit=1),0)
        h.check(read["principal_uid"]==uid and read["principal_gid"]==gid and read["returned_records"]==1,"real kernel-observed UID and GID read")
        denied=run_as_uid(h,"uid-payload-denied",uid,gid,query_args(b,payload="yes"),3)
        h.check(denied["code"]=="LOCAL_CONTROL_CLASS_DENIED" and "records" not in denied,"metadata permission does not disclose payload")
        owner=query(h,"owner-token",b,limit=1)
        switched=run_as_uid(h,"uid-cursor-transfer",uid,gid,query_args(b,limit=1,cursor=owner["next_cursor"]),3)
        h.check(switched["code"]=="EVIDENCE_CURSOR_CONTEXT_MISMATCH","cursor cannot be transferred between authorized UIDs")
        # Connection is opened under the preceding policy, but decoding finishes
        # only after live revocation. Kernel UID stays the same; active policy wins.
        wire=wire_query()
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as slow:
            slow.settimeout(5);slow.connect(str(bd.control))
            framed=struct.pack("!I",len(wire))+wire
            slow.sendall(framed[:3]);time.sleep(0.05)
            changed=candidate(h,bc,"principals-revoke","principals-b-g2",lambda s:s.replace(",EVIDENCE_READ,EVIDENCE_PAYLOAD", ""))
            activate(h,"principals-revoke-active",b,changed)
            slow.sendall(framed[3:]);slow.shutdown(socket.SHUT_WR)
            size=struct.unpack("!I",receive_exact(slow,4))[0];response=receive_exact(slow,size)
            parsed=json.loads(response[5:])
            h.check(response[4]==1 and parsed["code"]=="LOCAL_CONTROL_CLASS_DENIED","slow pre-activation connection cannot use revoked read grant")
        h.check(query(h,"owner-revoked",b,3)["code"]=="LOCAL_CONTROL_CLASS_DENIED","future queries denied after grant revocation")
        # Explicit delegation to this UID may remain while owner read is revoked.
        h.check(run_as_uid(h,"uid-still-metadata",uid,gid,query_args(b),0)["returned_records"]==2,"exact principal grants remain independent")
        (b/"control.sock").chmod(0o600);b.chmod(0o700)
        ad.shutdown();bd.shutdown()
    case("kernel_principal_payload_and_live_revocation",principals)

    def concurrent_reads() -> None:
        a,b,ac,bc,ad,bd=pair(h,"concurrent")
        seed=send(h,"concurrent-seed",a,"seed","query/concurrent")
        start_page=query(h,"concurrent-start",b,scope="query/concurrent",limit=1)
        def write(i: int) -> str:
            label=f"concurrent-write-{i}";op=operation(label)
            submit(h,label,ad.control,"A","B","query/concurrent",op,str(i));return op
        def read(i: int) -> dict[str,Any]:
            return query(h,f"concurrent-read-{i}",b,scope="query/concurrent",max_bytes=4096)
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            writes=[pool.submit(write,i) for i in range(12)]
            reads=[pool.submit(read,i) for i in range(12)]
            ids=[f.result() for f in writes];pages=[f.result() for f in reads]
        for op in ids:wait_state(h,a,op,"ACKED","concurrent-complete-"+op[:8])
        for page in pages:
            h.check(page["selected_records"]>=len(page["records"]) and len({r["operation_id"] for r in page["records"]})==len(page["records"]),"each concurrent page is coherent and nonduplicating")
        allrows=[];token=None;root=None
        while True:
            opts={"scope":"query/concurrent","max_bytes":4096}
            if token:opts["cursor"]=token
            page=query(h,"concurrent-final-page-"+str(len(allrows)),b,**opts)
            if root is None:root=page["selection_digest"]
            h.check(page["selection_digest"]==root,"settled pagination holds one exact root")
            allrows+=page["records"];token=page["next_cursor"]
            if token is None:break
        h.check({r["operation_id"] for r in allrows}==set([seed]+ids) and len(allrows)==13,"all concurrent admissions paged exactly once")
        ad.shutdown();bd.shutdown()
    case("concurrent_reads_writes_and_byte_paging",concurrent_reads)

    def protected_restore() -> None:
        a,b,ac,bc,ad,bd=pair(h,"restore")
        op=send(h,"restore-original",a,"retained")
        correction=operation("restore-correction")
        revise(h,"restore-correct",ad.control,"A","B","query/series",correction,op,"corrected")
        wait_state(h,a,correction,"ACKED","restore-correct-ack")
        before=query(h,"restore-query-before",b,view="history",scope="query/series",payload="yes")
        bd.shutdown()
        keyroot=h.runtime/"query-keys";keyroot.mkdir(mode=0o700)
        key=new_key(h,keyroot,"query-state-g1");migrate(h,"query-state-adopt",b,key,"B")
        bd=start_keyed(h,"query-keyed",bc,b,key)
        keyed=query(h,"query-keyed-read",b,view="history",scope="query/series",payload="yes")
        h.check(keyed["records"]==before["records"] and keyed["selection_digest"]==before["selection_digest"],"state authentication migration preserves query view")
        h.run("query-keyed-compact",["compact","--control",str(bd.control)])
        h.check(query(h,"query-compacted-read",b,view="history",scope="query/series",payload="yes")["selection_digest"]==before["selection_digest"],"keyed compaction preserves evidence root")
        bd.shutdown()
        bkey=keyroot/"backup.key"
        h.run("query-backup-key",["backup-key-init","--output",str(bkey),"--generation","query-backup-g1"])
        archive=keyroot/"query-backup.nob";identity=h.identity("B")
        h.run("query-export",["backup-export","--state",str(b),"--node","B","--generation","b-g1","--output",str(archive),"--state-auth-key",str(key),"--encrypt-key",str(bkey),"--sign-key",str(identity.private_key),"--sign-cert",str(identity.certificate)])
        restored=h.runtime/"query-restored"
        h.run("query-restore",["backup-restore","--input",str(archive),"--destination",str(restored),"--node","B","--generation","b-g1","--state-auth-key",str(key),"--decrypt-key",str(bkey),"--trusted-cert",str(identity.certificate),"--require-signature","yes","--require-encryption","yes"])
        relocated=candidate(h,bc,"query-relocated","query-relocated-g1",lambda s:s.replace(f"state={b}",f"state={restored}"))
        h.run("query-relocate",["state-relocate","--state",str(restored),"--node","B","--candidate",str(relocated),"--reason","query verified restore","--state-auth-key",str(key)])
        bd=start_keyed(h,"query-restored",relocated,restored,key)
        after=query(h,"query-restored-view",restored,view="history",scope="query/series",payload="yes")
        h.check(after["selection_digest"]==before["selection_digest"] and after["records"]==before["records"],"exact evidence and provenance across signed encrypted restore and relocation")
        send(h,"query-after-restore-delivery",a,"new work")
        h.check(query(h,"query-restored-new-record",restored,view="history",scope="query/series")["selected_records"]==3,"restored node admits and queries new delivery")
        ad.shutdown();bd.shutdown()
    case("authenticated_encrypted_restore_relocation_continuation",protected_restore)

    # Opt-in real-clock test: intentionally not hidden inside the ordinary
    # 180-second matrix wrapper. No fake clock or production bypass is used.
    if selected and "cursor_expiry" in selected:
        def cursor_expiry() -> None:
            a,b,ac,bc,ad,bd=pair(h,"expiry")
            send(h,"expiry-one",a);send(h,"expiry-two",a)
            page=query(h,"expiry-cursor-issued",b,limit=1)
            token=page["next_cursor"]
            expiry=struct.unpack("!Q",bytes.fromhex(token)[112:120])[0]/1000.0
            remaining=expiry-time.monotonic()
            h.check(290.0 < remaining <= 300.1,"encoded deadline is the real five-minute lifetime")
            time.sleep(max(0.0,remaining)+0.05)
            expired=query(h,"expiry-cursor-rejected",b,3,limit=1,cursor=token)
            h.check(expired["code"]=="EVIDENCE_CURSOR_EXPIRED","real monotonic expiry rejects a formerly valid unchanged-view cursor")
            fresh=query(h,"expiry-fresh-query",b,limit=1)
            h.check(fresh["selection_digest"]==page["selection_digest"] and fresh["next_cursor"]!=token,"expiry is independent of evidence mutation; fresh pagination works")
            ad.shutdown();bd.shutdown()
        case("cursor_expiry",cursor_expiry)


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary",type=Path,required=True);parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--case",action="append")
    args=parser.parse_args()
    if args.output.exists():parser.error("output must not exist")
    h=Harness(args.binary,args.output);begin=time.time();success=False
    try:
        cases(h,set(args.case) if args.case else None);success=True
    except BaseException as exc:
        (h.output/"FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}",file=os.sys.stderr)
    finally:
        h.cleanup()
        summary={"format":"NATRAV_OVERLAY_EVIDENCE_QUERY_TESTS_V1","status":"PASS" if success else "FAIL",
                 "binary_sha256":hashlib.sha256(h.binary.read_bytes()).hexdigest(),
                 "cases_total":len(h.cases),"cases_passed":sum(c["status"]=="PASS" for c in h.cases),
                 "assertions":h.assertions,"commands":len(h.commands),"elapsed_seconds":time.time()-begin}
        for name,value in [("SUMMARY",summary),("CASES",h.cases),("COMMANDS",h.commands)]:
            (h.output/(name+".json")).write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")
        print(json.dumps(summary),flush=True)
    return 0 if success else 1
if __name__=="__main__":raise SystemExit(main())
