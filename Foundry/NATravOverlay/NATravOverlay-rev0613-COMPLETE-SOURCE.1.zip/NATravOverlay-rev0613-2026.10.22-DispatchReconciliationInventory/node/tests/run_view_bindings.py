#!/usr/bin/env python3
"""Exact recipient pin inspection through the actual C++ node and kernel UIDs.
Synthetic pins establish bounded policy enumeration, not communicating providers.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, shutil, struct, subprocess, sys, time
from pathlib import Path
from run_persistent import Harness, operation, raw_control
from run_subscribed_source_views import setup, emit, materialize, SCOPE, TARGET
from run_source_view_inventory import extra_view
from run_live_configuration import candidate, activate
from run_local_administration import run_as_uid, expose_control_for_uid
from run_view_retirement import status as retire_status, retire
from run_state_authentication import new_key, migrate, start as start_keyed, inspect

FORMAT='NATRAV_OVERLAY_VIEW_BINDINGS_V1'

def save(h,name,value): (h.output/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')
def text(value):
    b=value.encode(); return struct.pack('!H',len(b))+b

def filters(kw):
    b=b''.join(text(kw.get(k,default)) for k,default in [('view','temps'),('presence','all'),('grant',''),('envelope','all')])
    for k in ('instance','grant_digest','binding_digest','lineage_digest'):
        b+=b'\1'+bytes.fromhex(kw[k]) if k in kw else b'\0'
    return b

def wire(**kw):
    return b'NOC1\x28VBI1'+filters(kw)+struct.pack('!III',kw.get('offset',0),kw.get('limit',16),kw.get('max_bytes',32768))+(b'\1'+bytes.fromhex(kw['selection']) if 'selection' in kw else b'\0')

def root_for(response,rows,**kw):
    view=json.dumps(response['view'],separators=(',',':'),ensure_ascii=False).encode()
    b=b'NATRAV_OVERLAY_VIEW_BINDINGS_SELECTION_V1\0'+text(response['node'])+struct.pack('!I',response['manager_uid'])+bytes.fromhex(response['authorized_configuration_digest'])+filters(kw)+struct.pack('!I',len(view))+view+struct.pack('!I',len(rows))
    root=hashlib.sha256(b).digest()
    for row in rows:
        b=json.dumps(row,separators=(',',':'),ensure_ascii=False).encode()
        root=hashlib.sha256(b'NATRAV_OVERLAY_VIEW_BINDINGS_ROW_V1\0'+root+struct.pack('!I',len(b))+b).digest()
    return root.hex()

def query(h,label,c,uid=None,expected=0,**kw):
    kw.setdefault('view','temps')
    args=['source-view-bindings','--control',str(c/'control.sock'),'--deadline-ms','5000']
    for k,v in kw.items():args+=['--'+k.replace('_','-'),str(v)]
    r=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    if expected==0:
        h.check(r['format']==FORMAT and r['manager_uid']==(os.geteuid() if uid is None else uid),'exact kernel manager')
        h.check(len(json.dumps(r,separators=(',',':')).encode())<=kw.get('max_bytes',32768),'complete response byte limit')
        for f in ('source_records_read','payload_bytes_copied','histories_serialized','historical_configurations_parsed','snapshot_calls','logical_bytes_serialized'):
            h.check(r['work'][f]==0,'no unrelated work '+f)
        h.check(not any(s in json.dumps(r) for s in ('payload_hex','key.pem','private_key','reason_text": true')),'no payload or secret pathname')
        for row in r['records']:
            canonical=','.join([row['view'],row['grant'],row['subscription_instance'],row['grant_digest'],row['lineage_digest'] or '-'])
            h.check(hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_VIEW_BINDING_V1\0'+canonical.encode()).hexdigest()==row['binding_digest'],'independent exact pin digest')
    return r

def pin(view,grant,lineage=None):
    return f'source_view_binding={view},{grant},{operation(view+grant+"instance")},{operation(view+grant+"grant")},{lineage or "-"}\n'

def run_cases(h,selected):
    def case(name,fn):
        if selected is None or name in selected:h.case(name,fn)
    def basic():
        a,c,ac,cc,ad,cd,s=setup(h,'basic')
        first=query(h,'initial',c)
        h.check(first['records'][0]['first_accepted_configuration']['ordinal']==1,'initial pin bound to first accepted event')
        # A syntactically valid pin in config-check and a subsequently rejected
        # activation must not populate the retained registry.
        ghost=candidate(h,cc,'ghost','ghost-g1',lambda t:t+pin('temps','ghost'))
        h.run('ghost-preflight',['config-check','--config',str(ghost)])
        h.check(query(h,'no-preflight-ghost',c,grant='ghost')['records']==[],'preflight is not acceptance')
        bad=candidate(h,cc,'bad-pin','bad-pin-g1',lambda t:t.replace(s['grant_digest'],operation('changed-grant'))+pin('temps','ghost'))
        h.run('reject-rebinding',['config-activate','--control',str(c/'control.sock'),'--candidate',str(bad),'--reason','not accepted'],expected=3)
        h.check(query(h,'rejected-unchanged',c,selection=first['selection_digest'])['records']==first['records'],'rejected history cannot contaminate retained pins')
        added=candidate(h,cc,'pins','pins-g1',lambda t:t+pin('temps','zulu',operation('lineage-z'))+pin('temps','alpha'))
        activate(h,'accept-pins',c,added)
        full=query(h,'all-pins',c,limit=32,max_bytes=60000);rows=full['records']
        h.check([r['grant'] for r in rows]==['alpha','g1','zulu'] and root_for(full,rows)==full['selection_digest'],'sorted pins and independent selection root')
        h.check(rows[1]['first_accepted_configuration']['ordinal']==1 and rows[0]['first_accepted_configuration']['ordinal']==3,'rejected event occupies ordinal but not pin provenance')
        h.check(rows[0]['first_accepted_configuration']['generation']=='pins-g1','new pin attributed to actual accepted generation')
        p=query(h,'page-one',c,limit=1);q=query(h,'page-two',c,offset=p['next_offset'],selection=p['selection_digest'],limit=32,max_bytes=60000)
        h.check(p['records']+q['records']==rows,'changed page size preserves selection')
        for i,(kw,n) in enumerate([({'presence':'configured'},3),({'presence':'historical'},0),({'envelope':'nse1'},2),({'envelope':'nse2'},1),({'grant':'alpha'},1),({'instance':rows[0]['subscription_instance']},1),({'grant_digest':rows[0]['grant_digest']},1),({'binding_digest':rows[0]['binding_digest']},1),({'lineage_digest':rows[2]['lineage_digest']},1),({'grant':'g1','envelope':'nse2'},0)]):
            r=query(h,'filter-'+str(i),c,**kw);h.check(r['selected_total']==n and r['selection_digest']==root_for(r,r['records'],**kw),'exact conjunctive selectors')
        h.check(query(h,'false-selection',c,selection='42'*32,expected=3)['code']=='VIEW_BINDINGS_SELECTION_MISMATCH','false selection rejected')
        h.check(query(h,'unbound-offset',c,offset=1,expected=3)['code']=='VIEW_BINDINGS_SELECTION_REQUIRED','no implicit unbound continuation')
        h.check(query(h,'first-too-small',c,max_bytes=2048,expected=3)['code']=='VIEW_BINDINGS_PAGE_TOO_SMALL','first row not truncated')
        clipped=query(h,'byte-limited',c,max_bytes=3072)
        h.check(0<clipped['returned']<3 and clipped['has_more'],'nonfitting row remains available')
        ok,ind=raw_control(c/'control.sock',wire(limit=2));h.check(ok and ind['records']==rows[:2],'independent VBI1 local wire')
        for raw in (wire()+b'x',wire()[:-1],wire().replace(b'VBI1',b'VBI2'),wire(presence='invalid'),wire(selection='00'*32),wire(envelope='nse1',lineage_digest='11'*32),wire(view='')):
            ok,error=raw_control(c/'control.sock',raw);h.check(not ok and error['code']=='VIEW_BINDINGS_INVALID','strict malformed request')
        removed=candidate(h,added,'removed','removed-g1',lambda t:'\n'.join(l for l in t.splitlines() if not l.startswith('source_view_binding=temps,alpha,'))+'\n')
        activate(h,'remove-pin',c,removed)
        historical=query(h,'removed-pin',c,presence='historical');h.check(len(historical['records'])==1 and historical['records'][0]['grant']=='alpha','removed accepted pin retained')
        h.check(query(h,'changed-selected',c,selection=full['selection_digest'],expected=3)['code']=='VIEW_BINDINGS_SELECTION_MISMATCH','config publication invalidates continuation')
        h.run('rollback-pins',['config-rollback','--control',str(c/'control.sock'),'--generation','pins-g1','--reason','restore exact selection'])
        h.check(query(h,'rollback-selection',c,selection=full['selection_digest'])['records']==rows,'content selection valid again on exact rollback')
        before=(c/'state.journal').read_bytes()
        for i in range(4):
            empty=query(h,'empty-'+str(i),c,view='absent');h.check(empty['view'] is None and empty['work']['owned_bindings_examined']==0 and not empty['records'],'missing view reads zero pins')
        h.check(before==(c/'state.journal').read_bytes(),'success does not journal')
        save(h,'BASIC',{'initial':first,'complete':full,'byte_limited':clipped,'historical':historical,'independent':ind});cd.shutdown();ad.shutdown()
    case('strict_wire_exact_filters_byte_limits_and_accepted_pin_provenance',basic)

    def principals():
        a,c,ac,cc,ad,cd,s=setup(h,'principals',delegates=True)
        expanded=candidate(h,cc,'principals-more','principals-more-g1',lambda t:t+extra_view(s,'keep',65534)+extra_view(s,'other',65533))
        expanded.write_text(expanded.read_text().replace('local_control=65533,EVIDENCE_READ','local_control=65533,EVIDENCE_READ,SOURCE_IMPORT'))
        activate(h,'accept-managers',c,expanded);expose_control_for_uid(c)
        own=query(h,'root',c);u=query(h,'delegated',c,uid=65534,view='delegated');v=query(h,'other',c,uid=65533,view='other')
        absent=query(h,'hidden',c,uid=65534);missing=query(h,'missing',c,uid=65534,view='absent')
        h.check(absent['view'] is missing['view'] is None and absent['records']==missing['records']==[] and absent['retained_binding_count']==0,'other owner indistinguishable from unknown exact view')
        h.check(query(h,'foreign-selection',c,uid=65533,view='delegated',selection=u['selection_digest'],expected=3)['code']=='VIEW_BINDINGS_SELECTION_MISMATCH','selection cannot cross owner')
        src,s,row=emit(h,'principal-source',a,c,s,ticks=9)
        materialize(h,'import-only',c,row,view='delegated',uid=65534)
        denied=run_as_uid(h,'no-payload-grant',65534,65534,['evidence-query','--control',str(c/'control.sock'),'--issuer','A','--scope','subscribed/delegated','--payload','yes'],3)
        h.check(denied['code']=='LOCAL_CONTROL_CLASS_DENIED','binding access not payload access')
        h.check(query(h,'import-does-not-change-pins',c,uid=65534,view='delegated',selection=u['selection_digest'])['records']==u['records'],'materialization does not change pin selection')
        def remove(t):
            return '\n'.join(l.replace('peer_key=A,a-g1,ACTIVE,','peer_key=A,a-g1,REVOKED,') for l in t.splitlines() if not l.startswith(('source_view=delegated,','source_view_binding=delegated,','peer=A,','peer_route=A,','authorize=A,')))+'\n'
        removed=candidate(h,expanded,'principals-removed','principals-removed-g1',remove);activate(h,'remove-and-revoke',c,removed)
        hist=query(h,'retained-delegated',c,uid=65534,view='delegated',presence='historical')
        h.check(hist['view']['presence']=='HISTORICAL' and hist['view']['provider_generation_state']=='REVOKED' and len(hist['records'])==1,'historical pins and revoked state visible without restored authority')
        h.check(materialize(h,'cannot-reimport',c,row,view='delegated',uid=65534,expected=3)['code']=='SOURCE_VIEW_POLICY_DENIED','reading pin is not import authority')
        rendezvous=h.runtime/'principal-markers';rendezvous.mkdir();rendezvous.chmod(0o777)
        script=h.work/'slow_bindings.py';sent=rendezvous/'sent';go=rendezvous/'go';out=rendezvous/'result'
        script.write_text('import socket,struct,time,sys,os\ns=socket.socket(socket.AF_UNIX);s.settimeout(10);s.connect(sys.argv[1]);b=bytes.fromhex(sys.argv[2]);s.sendall(struct.pack("!I",len(b))+b[:1]);open(sys.argv[3],"w").close()\nwhile not os.path.exists(sys.argv[4]):time.sleep(.01)\ns.sendall(b[1:]);s.shutdown(socket.SHUT_WR)\ndef exact(n):\n b=b""\n while len(b)<n:\n  v=s.recv(n-len(b))\n  if not v:raise RuntimeError("unexpected EOF")\n  b+=v\n return b\nr=exact(struct.unpack("!I",exact(4))[0]);open(sys.argv[5],"wb").write(r)\n')
        h.work.chmod(0o755);script.chmod(0o644)
        proc=subprocess.Popen(['setpriv','--reuid=65534','--regid=65534','--clear-groups',sys.executable,str(script),str(c/'control.sock'),wire(view='delegated').hex(),str(sent),str(go),str(out)],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        try:
            h.wait('slow request connected',lambda:sent.exists(),3)
            revoked=candidate(h,removed,'principals-revoked','principals-revoked-g1',lambda t:'\n'.join(l for l in t.splitlines() if not l.startswith(('local_control=65534,','source_view=keep,','source_view_binding=keep,')))+'\n')
            activate(h,'revoke-import-class',c,revoked);go.touch();_,err=proc.communicate(timeout=12)
            h.check(proc.returncode==0,'real delegated client: '+err.decode());raw=out.read_bytes();reply=json.loads(raw[5:]);h.check(raw[4]==1 and reply['code']=='LOCAL_CONTROL_CLASS_DENIED','post-decode current authority')
        finally:
            if proc.poll() is None:proc.kill();proc.wait()
        save(h,'PRINCIPALS',{'root':own,'delegated':u,'other':v,'historical':hist,'revoked':reply});cd.shutdown();ad.shutdown()
    case('real_uid_isolation_historical_pins_revoked_keys_and_slow_request_revocation',principals)

    def capacity():
        a,c,ac,cc,ad,cd,s=setup(h,'capacity')
        extra=''.join(pin('temps',f'pin{i:03}',operation('lineage'+str(i)) if i%2 else None) for i in range(1,256))
        cfg=candidate(h,cc,'full-pins','full-pins-g1',lambda t:t+extra)
        h.check(cfg.stat().st_size<65536,'256 complete exact pins fit unchanged config ceiling')
        activate(h,'accept-256',c,cfg)
        expected={}
        for line in cfg.read_text().splitlines():
            if line.startswith('source_view_binding=temps,'):
                fields=line.split('=',1)[1].split(',');expected[fields[1]]=fields
        rows=[];pages=[];offset=0;sel=None
        while True:
            p=query(h,'capacity-'+str(offset),c,limit=17,max_bytes=32768,**({'offset':offset,'selection':sel} if sel else {}));pages.append(p);rows+=p['records'];sel=p['selection_digest']
            if not p['has_more']:break
            offset=p['next_offset']
        h.check(len(rows)==256 and len(pages)==16 and [r['ordinal'] for r in rows]==list(range(1,257)),'all 256 pins enumerated without gaps')
        for row in rows:
            f=expected[row['grant']];h.check(row['subscription_instance']==f[2] and row['grant_digest']==f[3] and row['lineage_digest']==(None if f[4]=='-' else f[4]),'all independent source fields exact')
        h.check(root_for(pages[0],rows)==sel,'independent full-capacity root')
        h.check(query(h,'last-exact',c,grant='pin255')['returned']==1,'last pin directly located')
        over=candidate(h,cfg,'over-pins','over-pins-g1',lambda t:t+pin('temps','excess'))
        h.run('reject-257',['config-check','--config',str(over)],expected=3)
        # Retain a sparse live subset, preserving all accepted pins and original first-events.
        removed=candidate(h,cfg,'sparse-pins','sparse-pins-g1',lambda t:'\n'.join(l for l in t.splitlines() if not (l.startswith('source_view_binding=temps,pin') and int(l.split(',')[1][3:])%2))+'\n')
        activate(h,'remove-128',c,removed)
        hist=query(h,'history-first',c,presence='historical',limit=32,max_bytes=60000)
        h.check(hist['selected_total']==128 and hist['retained_binding_count']==256 and hist['configured_binding_count']==128,'absence is historical membership not deletion')
        h.check(hist['records'][0]['first_accepted_configuration']['generation']=='full-pins-g1','first acceptance not rewritten on removal')
        before=(c/'state.journal').read_bytes()
        for i in range(6):query(h,'capacity-empty-'+str(i),c,grant='absent')
        h.check(before==(c/'state.journal').read_bytes(),'empty reads no mutation')
        h.run('capacity-compact',['compact','--control',str(c/'control.sock'),'--deadline-ms','10000']);cd.shutdown();cd=h.start('capacity-restart',removed,c)
        again=query(h,'history-replayed',c,presence='historical',selection=hist['selection_digest'],limit=32,max_bytes=60000)
        h.check(again['records']==hist['records'],'derived provenance and selection reconstruct')
        save(h,'CAPACITY',{'bindings':256,'pages':len(pages),'config_bytes':cfg.stat().st_size,'first':pages[0],'historical':hist,'replayed':again});cd.shutdown();ad.shutdown()
    case('all_256_bindings_complete_enumeration_sparse_current_set_and_replay',capacity)

    def retirement():
        a,c,ac,cc,ad,cd,s=setup(h,'retirement')
        src,s,row=emit(h,'before-import',a,c,s,ticks=100);first=query(h,'pins-before-import',c)
        materialize(h,'import-source',c,row)
        h.check(query(h,'same-pins',c,selection=first['selection_digest'])['records']==first['records'],'source records and usage omitted from pin selection')
        terminal=retire(h,'retire-view',c,retire_status(h,'select-final',c))
        h.check(query(h,'retirement-stale',c,selection=first['selection_digest'],expected=3)['code']=='VIEW_BINDINGS_SELECTION_MISMATCH','terminal lifecycle change explicit')
        after=query(h,'retired-pins',c)
        h.check(after['view']['lifecycle']=='RETIRED' and after['records']==first['records'],'pins remain configured even after retirement')
        before=(c/'state.journal').read_bytes()
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:pages=list(pool.map(lambda i:query(h,'reader-'+str(i),c,selection=after['selection_digest']),range(8)))
        h.check(len({x['selection_digest'] for x in pages})==1 and before==(c/'state.journal').read_bytes(),'concurrent readers do not revive or mutate retired view')
        save(h,'RETIREMENT',{'before':first,'after':after,'terminal':terminal});cd.shutdown();ad.shutdown()
    case('import_progress_does_not_change_pins_retirement_does_not_erase_them',retirement)

    def succession():
        from run_lease_succession import setup as lease_setup, add_grant, withdraw, succeed, received
        from run_subscription_leases import local
        from run_local_evidence import author
        from run_scoped_reads import query as read_evidence
        from run_source_subscriptions import Reader
        a,c,ac,cc,ad,cd,remote=lease_setup(h,'succession');old=local(h,'old-status',a,'status')
        def upgrade(t):
            out=[]
            for line in t.splitlines():
                if line.startswith('NATRAV_OVERLAY_CONFIG_'):out.append('NATRAV_OVERLAY_CONFIG_V17')
                elif line.startswith(f'local_control={os.geteuid()},'):out.append(line+',SOURCE_IMPORT')
                elif line.startswith('peer=') and len(line[5:].split(','))==6:
                    f=line[5:].split(',');out+=['peer='+','.join([f[0]]+f[2:]),f'peer_route={f[0]},primary,0,ENABLED,{f[1]}']
                else:out.append(line)
            out += [f'evidence_read={os.geteuid()},A,{TARGET},PAYLOAD',f'source_view=temps,{os.geteuid()},A,a-g1,{os.geteuid()},{SCOPE},{TARGET},128,1000000',f'source_view_binding=temps,g1,{old["instance"]},{old["grant_digest"]},-']
            return '\n'.join(out)+'\n'
        viewcfg=candidate(h,cc,'leased-view','leased-view-g1',upgrade);activate(h,'accept-old-pin',c,viewcfg)
        one=author(h,'first-source',a,ticks=100);issued=local(h,'first-issue',a,'step',previous=old);old=received(h,'first-receipt',a,issued)
        first_import=materialize(h,'first-import',c,issued['latest']['operation_id'])
        terminal=withdraw(h,'withdraw-old',a,cc,old);add_grant(h,ac,a,'new-lease');successor=succeed(h,'succeed',a,terminal)
        author(h,'next-source',a,ticks=150,parent=one['operation_id']);issue=local(h,'next-issue',a,'step',grant='g2',previous=successor);received(h,'next-receipt',a,issue)
        record=read_evidence(h,'get-envelope',c,issuer='A',scope=SCOPE,operation=issue['latest']['operation_id'],view='history',payload='yes',payload_length=16384)['records'][0]
        raw=bytes.fromhex(record['payload_hex']);r=Reader(raw);assert r.get(4)==b'NSE2';r.text();r.get(64);r.text();r.text();r.get(32);r.get(8+4+8+32)
        if r.number(1):r.get(32)
        r.get(r.number(4));lineage=hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_VIEW_LINEAGE_V1\0'+raw[r.i:]).hexdigest()
        h.check(query(h,'before-pin',c,grant='g2')['records']==[],'received envelope not self-authorizing')
        nextcfg=candidate(h,viewcfg,'new-pin','new-pin-g1',lambda t:t+f'source_view_binding=temps,g2,{successor["instance"]},{successor["grant_digest"]},{lineage}\n')
        activate(h,'accept-lineage',c,nextcfg)
        pinned=query(h,'exact-lineage',c,grant='g2',lineage_digest=lineage,envelope='nse2')
        h.check(pinned['returned']==1 and pinned['records'][0]['subscription_instance']==successor['instance'],'actual successor exact fields and independently hashed lineage')
        imported=materialize(h,'correction-import',c,record)
        current=read_evidence(h,'current-view',c,issuer='A',scope=TARGET,view='current')['records']
        h.check(len(current)==1 and current[0]['corrects']==first_import['operation_id'],'inspection does not replace normal parent validation')
        save(h,'SUCCESSION',{'binding':pinned,'lineage':lineage,'first_import':first_import,'correction_import':imported});cd.shutdown();ad.shutdown()
    case('actual_successor_NSE2_binding_and_recipient_correction_continuity',succession)

    def maintenance():
        a,c,ac,cc,ad,cd,s=setup(h,'maintenance')
        _,s,row=emit(h,'maint-source',a,c,s,ticks=125);materialize(h,'maint-import',c,row)
        first=query(h,'before-maintenance',c)
        h.run('quiesce',['quiesce','--control',str(c/'control.sock'),'--reason','inspection test'])
        h.check(query(h,'quiesced-bindings',c,selection=first['selection_digest'])['records']==first['records'],'quiesced observational path')
        h.run('resume',['resume','--control',str(c/'control.sock'),'--reason','continue']);cd.shutdown()
        key=new_key(h,h.work,'bindings-g1');migrate(h,'migrate',c,key,node='C');cd=start_keyed(h,'keyed',cc,c,key)
        h.run('keyed-compact',['compact','--control',str(c/'control.sock')]);h.check(query(h,'keyed-bindings',c,selection=first['selection_digest'])['records']==first['records'],'compaction same selection');cd.shutdown()
        h.run('audit',['state-auth-audit','--state',str(c),'--node','C','--state-auth-key',str(key)])
        before=inspect(h,'before-backup',c,key,node='C');crypt=h.work/'bindings.key';h.run('backup-key',['backup-key-init','--output',str(crypt),'--generation','bindings-encryption'])
        ident=h.identity('C');archive=h.work/'bindings.nob'
        h.run('export',['backup-export','--state',str(c),'--node','C','--generation','c-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'bindings-restored';h.run('restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','C','--generation','c-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'restored-state',restored,key,node='C');h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'restored logical-state equality')
        new=h.work/'moved-identity';new.mkdir(mode=0o700);cert=new/'cert.pem';secret=new/'key.pem';shutil.copyfile(ident.certificate,cert);shutil.copyfile(ident.private_key,secret);cert.chmod(0o644);secret.chmod(0o600)
        moved=candidate(h,cc,'relocated','relocated-g1',lambda t:t.replace('state='+str(c),'state='+str(restored)).replace(str(ident.certificate),str(cert)).replace(str(ident.private_key),str(secret)))
        h.run('relocate',['state-relocate','--state',str(restored),'--node','C','--candidate',str(moved),'--reason','same identity new paths','--state-auth-key',str(key)])
        ident.certificate.unlink();ident.private_key.unlink();cd=start_keyed(h,'relocated',moved,restored,key)
        page=query(h,'relocated-bindings',restored)
        h.check(page['records']==first['records'] and page['view']==first['view'],'historical first-acceptance metadata without obsolete paths')
        h.check(query(h,'relocation-stale',restored,selection=first['selection_digest'],expected=3)['code']=='VIEW_BINDINGS_SELECTION_MISMATCH','new config explicit reselection')
        _,s,later=emit(h,'continued',a,restored,s,ticks=5);materialize(h,'continued-import',restored,later)
        h.check(query(h,'continued-pins',restored,selection=page['selection_digest'])['records']==page['records'],'new import does not alter bindings')
        ad.shutdown();h.run('drain-blocker',['submit','--control',str(restored/'control.sock'),'--node','C','--peer','A','--scope',SCOPE,'--operation',operation('bindings-drain'),'--payload-text','unavailable'])
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            drain=pool.submit(h.run,'drain',['drain-shutdown','--control',str(restored/'control.sock'),'--drain-deadline-ms','2500','--reason','inspection during nonempty drain'])
            h.wait('draining',lambda:h.status('drain-status',restored,logical_digest=False)['lifecycle']['draining'])
            dpage=query(h,'draining-bindings',restored,selection=page['selection_digest']);h.check(dpage['records']==page['records'],'observational during real drain');h.check(drain.result(timeout=8)['deadline_reached'],'inspection did not complete work')
        cd.process.wait(timeout=8)
        save(h,'MAINTENANCE',{'before':first,'relocated':page,'draining':dpage,'logical_digest':after['storage']['logical_state_digest']})
    case('keyed_replay_signed_encrypted_restore_relocation_and_draining',maintenance)

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--binary',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--case',action='append');args=parser.parse_args()
    if args.output.exists():parser.error('output must not exist')
    h=Harness(args.binary,args.output);start=time.time();ok=False
    try:run_cases(h,set(args.case) if args.case else None);ok=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {type(e).__name__}: {e}',file=sys.stderr)
    finally:
        h.cleanup();result={'format':'NATRAV_OVERLAY_VIEW_BINDINGS_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,value in [('SUMMARY',result),('CASES',h.cases),('COMMANDS',h.commands)]:save(h,name,value)
        print(json.dumps(result),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
