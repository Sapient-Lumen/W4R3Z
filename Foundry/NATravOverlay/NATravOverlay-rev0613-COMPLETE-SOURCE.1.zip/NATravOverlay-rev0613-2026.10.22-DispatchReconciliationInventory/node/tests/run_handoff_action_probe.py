#!/usr/bin/env python3
"""Supplemental V18 offline bounded-action/result integration; no network delivery."""
from pathlib import Path
import argparse, hashlib, json, time, traceback
from run_persistent import Harness, free_port, operation
from run_action_results import config, submit_action, wait_action
from run_maintenance import inspect


def suite(h):
    h.work.chmod(0o700)
    astate,bstate,cstate=(h.runtime/name for name in ('a','b','missing'))
    ac=config(h,'oa','A',astate,free_port(),'B',free_port(),receive_action=False,allow_result=False)
    bc=config(h,'ob','B',bstate,free_port(),'A',free_port(),receive_action=True,allow_result=True)
    cc=config(h,'missing','B',cstate,free_port(),'A',free_port(),receive_action=True,allow_result=False)
    a=h.start('oa',ac,astate);b=h.start('ob',bc,bstate);c=h.start('missing',cc,cstate)
    op=operation('offline-counter-v18')
    submit_action(h,'queue-action',astate,op,7)
    a.shutdown();b.shutdown();c.shutdown()
    keys={}
    for tag,cfg in [('a',ac),('b',bc),('c',cc)]:
        keys[tag]=h.work/('key-'+tag)
        h.run('key-'+tag,['handoff-key-init','--config',str(cfg),'--key-directory',str(keys[tag]),'--generation','offline-h1'])
    def export(cfg,k,peer,operation_id,name,kind='operation'):
        p=h.work/name;binding=keys[peer]/'binding.nhkb'
        h.run('export-'+name,['handoff-export','--config',str(cfg),'--key-directory',str(keys[k]),
            '--recipient-binding',str(binding),'--recipient-binding-sha256',hashlib.sha256(binding.read_bytes()).hexdigest(),
            '--operation-id',operation_id,'--kind',kind,'--expires-ms',str(int(time.time()*1000)+60000),'--output',str(p)])
        return p
    def imp(cfg,k,p,label,expected=0):
        return h.run(label,['handoff-import','--config',str(cfg),'--key-directory',str(keys[k]),'--input',str(p)],expected=expected)
    bad=export(ac,'a','c',op,'missing.nhcp')
    rejected=imp(cc,'c',bad,'missing-result-policy',3)
    h.check(rejected['code']=='ACTION_RESULT_POLICY_REQUIRED','V18 cannot admit an action without the ordinary result policy')
    good=export(ac,'a','b',op,'action.nhcp')
    h.check(imp(bc,'b',good,'admit-action')['status']=='COMMITTED','offline counter operation admitted')
    snap=inspect(h,'before-action-execution',bstate,'B')
    h.check(snap['actions']['pending']==1 and snap['actions']['counter_value']==0,'offline import queues; it does not execute')
    receipt=export(bc,'b','a',op,'admission-receipt.nhcp','receipt')
    h.check(imp(ac,'a',receipt,'admission-ack')['status']=='ACKNOWLEDGED','admission receipt is not action completion')
    b=h.start('ob-execute',bc,bstate)
    action=wait_action(h,'counter-executed',bstate,op,'EXECUTED')
    result=action['action_result']['operation_id']
    h.check(action['result']['counter_after']==7,'ordinary action scheduler performed exactly one bounded increment')
    b.shutdown()
    h.check(imp(bc,'b',good,'duplicate-action')['status']=='DUPLICATE','post-execution duplicate not readmitted')
    result_file=export(bc,'b','a',result,'result.nhcp')
    h.check(imp(ac,'a',result_file,'import-action-result')['status']=='COMMITTED','ordinary correlated result admitted')
    receipt=export(ac,'a','b',result,'result-receipt.nhcp','receipt')
    h.check(imp(bc,'b',receipt,'result-ack')['status']=='ACKNOWLEDGED','result return has its own exact receipt')
    b=h.start('ob-restart',bc,bstate)
    h.check(h.status('counter-restarted',bstate)['actions']['counter_value']==7,'restart does not execute the action twice')
    b.shutdown()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();root=Path(__file__).resolve().parents[2];out=args.output.resolve()
    if out.exists() or out==root or root in out.parents:parser.error('output must be new and outside source')
    h=Harness(args.binary,out);start=time.monotonic();status='FAIL';failure=None
    try:h.case('V18_offline_action_and_correlated_result',lambda:suite(h));status='PASS'
    except Exception as e:failure=repr(e);traceback.print_exc()
    finally:
        h.cleanup()
        report=dict(format='NATRAV_HANDOFF_ACTION_PROBE_V1',status=status,failure=failure,cases=h.cases,
            assertions=h.assertions,commands=len(h.commands),elapsed_seconds=time.monotonic()-start,
            binary_sha256=hashlib.sha256(h.binary.read_bytes()).hexdigest())
        (out/'SUMMARY.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
    return 0 if status=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
