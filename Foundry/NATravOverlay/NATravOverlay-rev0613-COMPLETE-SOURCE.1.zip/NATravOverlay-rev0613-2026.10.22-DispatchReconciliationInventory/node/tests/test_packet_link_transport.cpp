#include "packet_link_transport.hpp"
#include "peer_session.hpp"
#include "protocol.hpp"
#include "socket.hpp"
#include "tls.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <variant>
#include <vector>

namespace {

using natrav::packet_link::Direction;
using natrav::packet_link::FaultAction;
using natrav::packet_link::FaultRule;
using natrav::packet_link::FaultSchedule;
using natrav_overlay::AppError;
using natrav_overlay::Deadline;
using natrav_overlay::DeliveryReceipt;
using natrav_overlay::EvidenceRecord;
using natrav_overlay::FramedReader;
using natrav_overlay::IoCounters;
using natrav_overlay::IoOptions;
using natrav_overlay::KeyGenerationState;
using natrav_overlay::OutboundPeerSession;
using natrav_overlay::PacketLinkSnapshot;
using natrav_overlay::PacketLinkStreamOptions;
using natrav_overlay::PeerSessionFrame;
using natrav_overlay::PeerSessionFrameKind;
using natrav_overlay::PeerSessionLimits;
using natrav_overlay::ReceiptDisposition;
using natrav_overlay::TlsChannel;
using natrav_overlay::TlsContext;
using natrav_overlay::TlsIdentityFiles;
using natrav_overlay::TlsTrustedGeneration;
using natrav_overlay::TlsTrustedIdentity;

struct CaseRecord final {
    std::string name;
    std::size_t assertions{0U};
};

class Probe final {
public:
    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_code(
        Function&& function,
        const std::string_view code,
        const std::string_view detail) {
        bool observed = false;
        try {
            std::forward<Function>(function)();
        } catch (const AppError& error) {
            observed = error.code() == code;
        }
        check(observed, detail);
    }

    template <typename Function>
    void run_case(std::string name, Function&& function) {
        const auto before = assertions_;
        std::forward<Function>(function)();
        cases_.push_back(CaseRecord{
            .name = std::move(name),
            .assertions = assertions_ - before,
        });
    }

    [[nodiscard]] std::size_t assertions() const noexcept { return assertions_; }
    [[nodiscard]] const std::vector<CaseRecord>& cases() const noexcept {
        return cases_;
    }

private:
    std::size_t assertions_{0U};
    std::vector<CaseRecord> cases_;
};

[[nodiscard]] Deadline test_deadline(
    const std::chrono::milliseconds duration = std::chrono::seconds(8)) {
    return std::chrono::steady_clock::now() + duration;
}

[[nodiscard]] TlsIdentityFiles identity(
    const char* certificate,
    const char* private_key,
    const char* pin) {
    return TlsIdentityFiles{
        .certificate = certificate,
        .private_key = private_key,
        .expected_spki_sha256 = natrav_overlay::parse_spki_sha256(pin),
    };
}

[[nodiscard]] datacube::Digest32 operation_id(const std::string_view label) {
    std::string input("NATRAV_PACKET_LINK_ADAPTER_TEST_OPERATION_V1");
    input.push_back('\0');
    input.append(label);
    return datacube::sha256(datacube::text_octets(input));
}

[[nodiscard]] EvidenceRecord record(
    const std::string_view label,
    const std::string_view payload) {
    return EvidenceRecord{
        .operation_id = operation_id(label),
        .issuer = "CLIENT",
        .recipient = "SERVER",
        .scope = "packet-link/session",
        .corrects = std::nullopt,
        .payload = datacube::text_octets(payload),
    };
}

[[nodiscard]] PacketLinkStreamOptions packet_options(
    FaultSchedule schedule = {},
    const std::size_t queue_capacity_packets = 4096U) {
    PacketLinkStreamOptions options;
    options.limits.mtu = 512U;
    options.limits.max_message_bytes = 64U * 1024U;
    options.limits.max_reassembly_bytes = 256U * 1024U;
    options.limits.max_delivery_bytes = 256U * 1024U;
    options.limits.max_inflight_frames = 256U;
    options.limits.max_control_frames = 256U;
    options.limits.max_receive_packets_per_pump = 512U;
    options.limits.retransmit_after_ticks = 3U;
    options.limits.retry_limit = 12U;
    options.limits.message_expiry_ticks = 512U;
    options.schedule = std::move(schedule);
    options.stream_id = 0x5041434b45544c31ULL;
    options.epoch = 7U;
    options.queue_capacity_packets = queue_capacity_packets;
    options.trace_capacity_events = 1'000'000U;
    options.progress_interval = std::chrono::milliseconds(1);
    return options;
}

void write_all(
    natrav_overlay::OrderedByteStream& stream,
    const std::span<const std::uint8_t> bytes,
    const Deadline deadline,
    IoCounters& counters) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto progress = stream.write_some(
            datacube::OctetView(bytes.data() + offset, bytes.size() - offset),
            deadline,
            counters,
            "packet-link raw write");
        if (progress == 0U || progress > bytes.size() - offset) {
            throw std::runtime_error("packet-link raw write made invalid progress");
        }
        offset += progress;
    }
}

[[nodiscard]] std::vector<std::uint8_t> read_exact(
    natrav_overlay::OrderedByteStream& stream,
    const std::size_t size,
    const Deadline deadline,
    IoCounters& counters) {
    std::vector<std::uint8_t> result(size);
    std::size_t offset = 0U;
    while (offset < result.size()) {
        const auto progress = stream.read_some(
            std::span<std::uint8_t>(result).subspan(offset),
            deadline,
            counters,
            "packet-link raw read");
        if (progress == 0U || progress > result.size() - offset) {
            throw std::runtime_error("packet-link raw read ended early");
        }
        offset += progress;
    }
    return result;
}

[[nodiscard]] bool has_magic(
    const natrav::packet_link::Bytes& bytes,
    const std::array<std::uint8_t, 8U>& magic) {
    return bytes.size() >= magic.size() &&
        std::equal(magic.begin(), magic.end(), bytes.begin());
}

struct SessionRun final {
    std::array<DeliveryReceipt, 2U> receipts;
    natrav::packet_link::Bytes trace;
    PacketLinkSnapshot snapshot;
    std::size_t server_operations{0U};
    bool clean_close{false};
};

[[nodiscard]] SessionRun run_reusable_session(
    PacketLinkStreamOptions options,
    const TlsIdentityFiles& client_identity,
    const TlsIdentityFiles& server_identity) {
    auto link = natrav_overlay::make_packet_link_stream_pair(std::move(options));
    auto server_stream = std::move(link.second);
    TlsContext client_context(client_identity);
    TlsContext server_context(server_identity);
    const std::vector<TlsTrustedIdentity> trusted_client{{
        .node_id = "CLIENT",
        .generations = {TlsTrustedGeneration{
            .generation = "client-g1",
            .spki_sha256 = client_identity.expected_spki_sha256,
            .state = KeyGenerationState::active,
        }},
    }};
    const IoOptions io{
        .timeout = std::chrono::seconds(8),
        .read_quantum = 257U,
        .write_quantum = 251U,
        .maximum_received_bytes = 1'048'576U,
    };
    const PeerSessionLimits limits{
        .maximum_operations = 4U,
        .maximum_bytes = 1'048'576U,
        .maximum_lifetime_ms = 20'000U,
        .idle_timeout_ms = 8'000U,
    };
    const std::array<EvidenceRecord, 2U> records{
        record("session-one", "alpha through the finite packet adapter"),
        record("session-two", "beta through the same authenticated session"),
    };

    IoCounters server_tls;
    IoCounters server_io;
    std::size_t server_operations = 0U;
    bool server_clean_close = false;
    std::exception_ptr server_failure;
    std::thread server([&] {
        try {
            const auto deadline = test_deadline();
            auto channel = TlsChannel::accept(
                server_context, *server_stream, trusted_client,
                deadline, server_tls);
            FramedReader reader(io);
            const auto hello = natrav_overlay::perform_server_handshake(
                channel, "SERVER", reader, deadline, io);
            if (hello.remote_artifact_digest !=
                natrav_overlay::node_artifact_digest("CLIENT")) {
                throw std::runtime_error("server HELLO identity mismatch");
            }
            const auto open = natrav_overlay::decode_peer_session_frame(
                reader.read_frame(channel, deadline, server_io));
            if (open.kind != PeerSessionFrameKind::open ||
                !open.limits.has_value()) {
                throw std::runtime_error("server did not receive NOS1 OPEN");
            }
            const PeerSessionFrame acknowledgement{
                .kind = PeerSessionFrameKind::open_ack,
                .flags = 0U,
                .session_id = open.session_id,
                .sequence = 0U,
                .operation_id = {},
                .limits = *open.limits,
                .payload = {},
            };
            const auto encoded_ack =
                natrav_overlay::encode_peer_session_frame(acknowledgement);
            natrav_overlay::write_frame(
                channel, encoded_ack, deadline, io, server_io);

            for (std::uint32_t sequence = 1U; sequence <= 2U; ++sequence) {
                const auto request = natrav_overlay::decode_peer_session_frame(
                    reader.read_frame(channel, deadline, server_io));
                if (request.kind != PeerSessionFrameKind::request ||
                    request.session_id != open.session_id ||
                    request.sequence != sequence) {
                    throw std::runtime_error("server request envelope mismatch");
                }
                const auto message = natrav_overlay::decode_application_message(
                    request.payload);
                const auto* evidence = std::get_if<EvidenceRecord>(&message);
                if (evidence == nullptr ||
                    evidence->operation_id != request.operation_id) {
                    throw std::runtime_error("server application binding mismatch");
                }
                ++server_operations;
                const DeliveryReceipt receipt{
                    .operation_id = evidence->operation_id,
                    .recipient = evidence->recipient,
                    .recorder = evidence->recipient,
                    .disposition = ReceiptDisposition::committed,
                    .sequence = sequence,
                    .record_digest = natrav_overlay::evidence_record_digest(*evidence),
                };
                const auto application =
                    natrav_overlay::encode_application_message(receipt);
                const PeerSessionFrame response{
                    .kind = PeerSessionFrameKind::response,
                    .flags = 0U,
                    .session_id = open.session_id,
                    .sequence = sequence,
                    .operation_id = evidence->operation_id,
                    .limits = std::nullopt,
                    .payload = application,
                };
                const auto encoded =
                    natrav_overlay::encode_peer_session_frame(response);
                natrav_overlay::write_frame(
                    channel, encoded, deadline, io, server_io);
            }

            const auto close = natrav_overlay::decode_peer_session_frame(
                reader.read_frame(channel, deadline, server_io));
            if (close.kind != PeerSessionFrameKind::close ||
                close.session_id != open.session_id || close.sequence != 3U) {
                throw std::runtime_error("server clean-close envelope mismatch");
            }
            const PeerSessionFrame close_ack{
                .kind = PeerSessionFrameKind::close_ack,
                .flags = 0U,
                .session_id = open.session_id,
                .sequence = close.sequence,
                .operation_id = {},
                .limits = std::nullopt,
                .payload = {},
            };
            const auto encoded_close =
                natrav_overlay::encode_peer_session_frame(close_ack);
            natrav_overlay::write_frame(
                channel, encoded_close, deadline, io, server_io);
            std::array<std::uint8_t, 1U> tls_eof{};
            const auto tls_close = channel.read_some(
                tls_eof, deadline, server_tls,
                "server waits for client TLS close-notify");
            if (tls_close != 0U) {
                throw std::runtime_error(
                    "server received application bytes after NOS1 close");
            }
            channel.close_notify(deadline, server_tls);
            server_clean_close = true;
        } catch (...) {
            server_failure = std::current_exception();
            link.control->reset_link();
        }
    });

    std::array<DeliveryReceipt, 2U> receipts;
    bool client_clean_close = false;
    bool server_joined = false;
    std::exception_ptr client_failure;
    try {
        auto session = OutboundPeerSession::open_connected(
            client_context,
            "CLIENT",
            "SERVER",
            "server-g1",
            KeyGenerationState::active,
            server_identity.expected_spki_sha256,
            std::move(link.first),
            records[0U].operation_id,
            io,
            limits);
        receipts[0U] = session.exchange(records[0U], io);
        receipts[1U] = session.exchange(records[1U], io);
        client_clean_close = session.close_cleanly(io);
        server.join();
        server_joined = true;
    } catch (...) {
        client_failure = std::current_exception();
        link.control->reset_link();
    }
    if (!server_joined) {
        server.join();
    }
    if (client_failure) {
        std::rethrow_exception(client_failure);
    }
    if (server_failure) {
        std::rethrow_exception(server_failure);
    }
    if (!client_clean_close || !server_clean_close) {
        throw std::runtime_error("authenticated packet-link session did not close cleanly");
    }
    auto snapshot = link.control->snapshot();
    return SessionRun{
        .receipts = receipts,
        .trace = snapshot.canonical_trace,
        .snapshot = std::move(snapshot),
        .server_operations = server_operations,
        .clean_close = client_clean_close && server_clean_close,
    };
}

[[nodiscard]] FaultSchedule recovery_schedule() {
    return FaultSchedule({
        FaultRule{Direction::a_to_b, FaultAction::drop, 1U, 0U},
        FaultRule{Direction::a_to_b, FaultAction::corrupt, 5U, 17U},
        FaultRule{Direction::a_to_b, FaultAction::delay, 9U, 4U},
        FaultRule{Direction::b_to_a, FaultAction::duplicate, 1U, 0U},
        FaultRule{Direction::b_to_a, FaultAction::reorder, 4U, 0U},
    });
}

struct PacketTraceShape final {
    std::uint8_t direction{0U};
    std::uint8_t disposition{0U};
    std::uint64_t ordinal{0U};
    std::uint32_t packet_size{0U};

    friend bool operator==(const PacketTraceShape&, const PacketTraceShape&) = default;
};

[[nodiscard]] std::uint32_t trace_u32(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) {
    if (offset > bytes.size() || bytes.size() - offset < 4U) {
        throw std::runtime_error("truncated canonical packet trace");
    }
    return (static_cast<std::uint32_t>(bytes[offset]) << 24U) |
        (static_cast<std::uint32_t>(bytes[offset + 1U]) << 16U) |
        (static_cast<std::uint32_t>(bytes[offset + 2U]) << 8U) |
        static_cast<std::uint32_t>(bytes[offset + 3U]);
}

[[nodiscard]] std::uint64_t trace_u64(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) {
    if (offset > bytes.size() || bytes.size() - offset < 8U) {
        throw std::runtime_error("truncated canonical packet trace");
    }
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value = (value << 8U) | static_cast<std::uint64_t>(bytes[offset + index]);
    }
    return value;
}

[[nodiscard]] std::vector<PacketTraceShape> packet_trace_shape(
    const std::span<const std::uint8_t> bytes) {
    constexpr std::array<std::uint8_t, 8U> magic{
        'N', 'P', 'L', 'T', '0', '0', '0', '1'};
    if (bytes.size() < 16U ||
        !std::equal(magic.begin(), magic.end(), bytes.begin())) {
        throw std::runtime_error("invalid canonical packet trace magic");
    }
    const auto count = static_cast<std::size_t>(trace_u32(bytes, 8U));
    constexpr std::size_t event_size = 28U;
    if (count > (std::numeric_limits<std::size_t>::max() - 16U) / event_size ||
        bytes.size() != 12U + count * event_size + 4U) {
        throw std::runtime_error("invalid canonical packet trace size");
    }
    std::vector<PacketTraceShape> result;
    result.reserve(count);
    std::size_t offset = 12U;
    for (std::size_t index = 0U; index < count; ++index) {
        result.push_back(PacketTraceShape{
            .direction = bytes[offset],
            .disposition = bytes[offset + 1U],
            .ordinal = trace_u64(bytes, offset + 4U),
            .packet_size = trace_u32(bytes, offset + 20U),
        });
        offset += event_size;
    }
    return result;
}

[[nodiscard]] natrav::packet_link::Bytes run_raw_replay(
    PacketLinkStreamOptions options,
    const std::span<const std::uint8_t> payload) {
    auto pair = natrav_overlay::make_packet_link_stream_pair(std::move(options));
    IoCounters write_counters;
    IoCounters read_counters;
    const auto deadline = test_deadline();
    write_all(*pair.first, payload, deadline, write_counters);
    const auto received = read_exact(
        *pair.second, payload.size(), deadline, read_counters);
    if (!std::equal(received.begin(), received.end(), payload.begin(), payload.end())) {
        throw std::runtime_error("raw packet replay changed application bytes");
    }
    pair.first->shutdown_write();
    std::array<std::uint8_t, 1U> eof{};
    if (pair.second->read_some(
            eof, deadline, read_counters, "raw replay EOF") != 0U) {
        throw std::runtime_error("raw packet replay did not finish exactly");
    }
    return pair.control->snapshot().canonical_trace;
}

void write_artifact(
    const std::filesystem::path& path,
    const std::span<const std::uint8_t> bytes) {
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output) {
        throw std::runtime_error("could not create packet-link evidence artifact");
    }
    output.write(
        reinterpret_cast<const char*>(bytes.data()),
        static_cast<std::streamsize>(bytes.size()));
    output.close();
    if (!output) {
        throw std::runtime_error("could not finish packet-link evidence artifact");
    }
}

}  // namespace

int main(int argc, char* argv[]) {
    try {
        if (argc != 8) {
            throw std::runtime_error(
                "usage: probe client-cert client-key client-pin server-cert server-key server-pin output");
        }
        const auto client_identity = identity(argv[1], argv[2], argv[3]);
        const auto server_identity = identity(argv[4], argv[5], argv[6]);
        const std::filesystem::path output(argv[7]);
        std::filesystem::create_directories(output);
        Probe probe;

        probe.run_case("raw ordered bytes and semantic finish", [&] {
            auto pair = natrav_overlay::make_packet_link_stream_pair(packet_options());
            std::vector<std::uint8_t> payload(12'345U);
            for (std::size_t index = 0U; index < payload.size(); ++index) {
                payload[index] = static_cast<std::uint8_t>((index * 29U + 7U) & 0xffU);
            }
            IoCounters write_counters;
            IoCounters read_counters;
            const auto deadline = test_deadline();
            write_all(*pair.first, payload, deadline, write_counters);
            const auto received = read_exact(
                *pair.second, payload.size(), deadline, read_counters);
            probe.check(received == payload, "raw adapter preserves exact byte order");
            pair.first->shutdown_write();
            std::array<std::uint8_t, 1U> eof{};
            probe.check(
                pair.second->read_some(eof, deadline, read_counters, "packet-link eof") == 0U,
                "packet-link FINISH becomes ordered-stream EOF");
            const auto snapshot = pair.control->snapshot();
            probe.check(
                snapshot.first_stats.accepted_application_bytes == payload.size(),
                "sender accounts exact accepted application bytes");
            probe.check(
                snapshot.second_stats.delivered_application_bytes == payload.size(),
                "receiver accounts exact delivered application bytes");
            probe.check(!snapshot.reset, "lossless raw stream does not reset");
            probe.check(has_magic(
                snapshot.canonical_schedule,
                std::array<std::uint8_t, 8U>{'N','P','L','S','0','0','0','1'}),
                "adapter retains canonical NPLS schedule bytes");
            probe.check(has_magic(
                snapshot.canonical_trace,
                std::array<std::uint8_t, 8U>{'N','P','L','T','0','0','0','1'}),
                "adapter retains canonical NPLT trace bytes");
        });

        probe.run_case("finite faults recover below the stream", [&] {
            for (const auto action : {
                    FaultAction::drop,
                    FaultAction::duplicate,
                    FaultAction::corrupt,
                    FaultAction::delay,
                    FaultAction::reorder}) {
                const auto argument = action == FaultAction::delay ? 5U :
                    action == FaultAction::corrupt ? 17U : 0U;
                auto pair = natrav_overlay::make_packet_link_stream_pair(
                    packet_options(FaultSchedule({FaultRule{
                        Direction::a_to_b, action, 1U, argument}})));
                std::vector<std::uint8_t> payload(4097U, 0x5aU);
                payload.front() = static_cast<std::uint8_t>(action);
                payload.back() = 0xa5U;
                IoCounters write_counters;
                IoCounters read_counters;
                const auto deadline = test_deadline();
                write_all(*pair.first, payload, deadline, write_counters);
                const auto received = read_exact(
                    *pair.second, payload.size(), deadline, read_counters);
                probe.check(received == payload,
                    "finite fault is hidden below exact ordered bytes");
                const auto snapshot = pair.control->snapshot();
                probe.check(!snapshot.reset,
                    "recoverable finite fault does not reset the stream");
                probe.check(!snapshot.canonical_trace.empty(),
                    "recoverable finite fault produces trace evidence");
                if (action == FaultAction::drop || action == FaultAction::corrupt) {
                    probe.check(snapshot.first_stats.retransmissions != 0U,
                        "loss or corruption produces bounded retransmission");
                }
                if (action == FaultAction::duplicate) {
                    probe.check(snapshot.second_stats.duplicate_data_packets != 0U,
                        "duplicate packet is suppressed exactly once");
                }
                if (action == FaultAction::corrupt) {
                    probe.check(snapshot.second_stats.integrity_failures != 0U,
                        "corruption is rejected before stream delivery");
                }
            }
        });

        probe.run_case("finite backpressure still makes ordered progress", [&] {
            auto pair = natrav_overlay::make_packet_link_stream_pair(
                packet_options({}, 2U));
            std::vector<std::uint8_t> payload(32'000U);
            for (std::size_t index = 0U; index < payload.size(); ++index) {
                payload[index] = static_cast<std::uint8_t>(index & 0xffU);
            }
            IoCounters write_counters;
            IoCounters read_counters;
            const auto deadline = test_deadline();
            write_all(*pair.first, payload, deadline, write_counters);
            const auto received = read_exact(
                *pair.second, payload.size(), deadline, read_counters);
            const auto snapshot = pair.control->snapshot();
            probe.check(received == payload,
                "two-packet network capacity preserves complete stream data");
            probe.check(snapshot.first_stats.backpressure_events != 0U,
                "finite packet queue exposes bounded backpressure internally");
            probe.check(snapshot.queued_packets <= 2U,
                "network queue never exceeds its declared packet capacity");
        });

        probe.run_case("deadline reset and exhaustion remain distinct", [&] {
            {
                auto pair = natrav_overlay::make_packet_link_stream_pair(packet_options());
                IoCounters counters;
                std::array<std::uint8_t, 1U> byte{};
                probe.expect_code(
                    [&] {
                        static_cast<void>(pair.first->read_some(
                            byte,
                            test_deadline(std::chrono::milliseconds(25)),
                            counters,
                            "packet-link timeout"));
                    },
                    "IO_TIMEOUT",
                    "idle adapter read obeys the absolute deadline");
            }
            {
                auto pair = natrav_overlay::make_packet_link_stream_pair(packet_options());
                pair.control->reset_link();
                IoCounters counters;
                std::array<std::uint8_t, 1U> byte{};
                probe.expect_code(
                    [&] {
                        static_cast<void>(pair.first->read_some(
                            byte, test_deadline(), counters,
                            "packet-link reset"));
                    },
                    "PEER_RESET",
                    "explicit fixture reset is not misclassified as timeout or EOF");
            }
            {
                std::vector<FaultRule> drops;
                for (std::uint64_t ordinal = 1U; ordinal <= 32U; ++ordinal) {
                    drops.push_back(FaultRule{
                        Direction::a_to_b, FaultAction::drop, ordinal, 0U});
                }
                auto options = packet_options(FaultSchedule(std::move(drops)));
                options.limits.retry_limit = 3U;
                options.limits.message_expiry_ticks = 32U;
                auto pair = natrav_overlay::make_packet_link_stream_pair(
                    std::move(options));
                IoCounters write_counters;
                IoCounters read_counters;
                const std::array<std::uint8_t, 4U> bytes{1U, 2U, 3U, 4U};
                write_all(*pair.first, bytes, test_deadline(), write_counters);
                std::array<std::uint8_t, 4U> received{};
                probe.expect_code(
                    [&] {
                        static_cast<void>(pair.second->read_some(
                            received, test_deadline(), read_counters,
                            "packet-link exhaustion"));
                    },
                    "PEER_RESET",
                    "bounded retry exhaustion becomes an explicit reset");
                const auto snapshot = pair.control->snapshot();
                probe.check(snapshot.reset,
                    "retry exhaustion marks the shared adapter state failed");
                probe.check(snapshot.first_stats.expired_messages != 0U,
                    "retry exhaustion is counted as finite expiry");
            }
        });

        probe.run_case("deterministic raw packet replay", [&] {
            std::vector<std::uint8_t> payload(9'001U);
            for (std::size_t index = 0U; index < payload.size(); ++index) {
                payload[index] = static_cast<std::uint8_t>((index * 17U + 3U) & 0xffU);
            }
            const auto first = run_raw_replay(
                packet_options(recovery_schedule()), payload);
            const auto second = run_raw_replay(
                packet_options(recovery_schedule()), payload);
            probe.check(first == second,
                "fixed bytes and schedule reproduce byte-identical canonical NPLT evidence");
            probe.check(!first.empty(),
                "deterministic replay retains finite packet evidence");
            write_artifact(output / "raw-replay-first.nplt", first);
            write_artifact(output / "raw-replay-second.nplt", second);
        });

        probe.run_case("real TLS HELLO NOS1 operations receipts and close", [&] {
            const auto run = run_reusable_session(
                packet_options(), client_identity, server_identity);
            probe.check(run.clean_close,
                "real authenticated session closes with NOS1 and TLS close-notify");
            probe.check(run.server_operations == 2U,
                "one reusable session carries two application operations");
            probe.check(
                run.receipts[0U].disposition == ReceiptDisposition::committed &&
                run.receipts[1U].sequence == 2U,
                "real bound receipts preserve committed sequencing");
            probe.check(run.snapshot.first_stats.accepted_application_bytes != 0U &&
                        run.snapshot.second_stats.delivered_application_bytes != 0U,
                "TLS records traverse the finite packet state machine");
            probe.check(!run.snapshot.reset,
                "lossless authenticated stack does not reset the adapter");
            write_artifact(output / "lossless.nplt", run.trace);
        });

        probe.run_case("real authenticated stack recovers deterministic packet faults", [&] {
            const auto first = run_reusable_session(
                packet_options(recovery_schedule()),
                client_identity,
                server_identity);
            const auto second = run_reusable_session(
                packet_options(recovery_schedule()),
                client_identity,
                server_identity);
            probe.check(first.clean_close && second.clean_close,
                "both faulted authenticated sessions close cleanly");
            probe.check(first.receipts == second.receipts,
                "faulted replay preserves exact application receipts");
            write_artifact(output / "faulted-first.nplt", first.trace);
            write_artifact(output / "faulted-second.nplt", second.trace);
            probe.check(
                packet_trace_shape(first.trace) == packet_trace_shape(second.trace),
                "independent TLS runs preserve packet direction, fault disposition, ordinal, and size structure");
            probe.check(first.snapshot.first_stats.retransmissions != 0U,
                "faulted authenticated stack performs bounded retransmission");
            probe.check(first.snapshot.second_stats.integrity_failures != 0U,
                "corrupted packet is rejected below TLS");
            probe.check(first.snapshot.first_stats.duplicate_data_packets != 0U ||
                        first.snapshot.second_stats.duplicate_data_packets != 0U,
                "duplicated packet is suppressed below TLS");
            const auto schedule = recovery_schedule().encode();
            write_artifact(output / "faulted.npls", schedule);
        });

        std::cout << "{\"format\":\"NATRAV_PACKET_LINK_ADAPTER_PROBE_V1\","
                  << "\"status\":\"PASS\",\"cases\":[";
        for (std::size_t index = 0U; index < probe.cases().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            const auto& item = probe.cases()[index];
            std::cout << "{\"name\":" << natrav_overlay::json_string(item.name)
                      << ",\"assertions\":" << item.assertions << '}';
        }
        std::cout << "],\"assertions\":" << probe.assertions() << "}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
