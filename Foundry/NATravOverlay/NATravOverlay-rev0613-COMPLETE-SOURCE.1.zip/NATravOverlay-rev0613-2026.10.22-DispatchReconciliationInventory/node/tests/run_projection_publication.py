#!/usr/bin/env python3
"""Durable projection-result publication through the ordinary peer outbox."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
import time
from typing import Any

from run_persistent import Harness, free_port, operation
from run_evidence_queries import config as v9_config, query, OWNER_CLASSES, READ_CLASSES
from run_numeric_projection import create as numeric_create, produce, consume, call as numeric_call
from run_projections import create as metadata_create, read as projection_read, call as projection_call, check_result
from run_peer_sessions import submit
from run_consumer_retirement import call as retirement_status, retire
from run_live_configuration import candidate, activate, wait_state
from run_state_authentication import new_key, migrate, start as start_keyed

OWNER_PROJECTION_CLASSES = OWNER_CLASSES + READ_CLASSES + [
    "CONSUMER", "CONSUMER_ADMIN", "PROJECTION"
]
OUTPUT_SCOPE = "derived/projection"
DENIED_SCOPE = "derived/private"


def publisher_config(
    h: Harness,
    name: str,
    state: Path,
    port: int,
    recipient_port: int,
    *,
    records: int = 4096,
    payload_bytes: int = 67_108_864,
) -> Path:
    path = v9_config(
        h, name, "B", state, port,
        peers=[("C", recipient_port)], inbound=["A"],
        grants=[(os.geteuid(), OWNER_PROJECTION_CLASSES)],
    )
    text = path.read_text().replace("CONFIG_V9", "CONFIG_V12")
    text += f"evidence_read={os.geteuid()},A,query/series,PAYLOAD\n"
    text += f"outbox_global_max_records={records}\n"
    text += f"outbox_global_max_payload_bytes={payload_bytes}\n"
    text += f"outbox_peer_max_records={records}\n"
    text += f"outbox_peer_max_payload_bytes={payload_bytes}\n"
    path.write_text(text)
    path.chmod(0o600)
    return path


def recipient_config(h: Harness, name: str, state: Path, port: int,
                     *, allow_output: bool = True) -> Path:
    path = v9_config(h, name, "C", state, port, inbound=["B"])
    if allow_output:
        path.write_text(path.read_text() + f"authorize=B,*,EVIDENCE,{OUTPUT_SCOPE}\n")
    path.chmod(0o600)
    return path


def source_config(h: Harness, name: str, state: Path, port: int,
                  publisher_port: int) -> Path:
    return v9_config(h, name, "A", state, port, peers=[("B", publisher_port)])


def topology(h: Harness, name: str, *, start_recipient: bool = True,
             allow_output: bool = True, records: int = 4096,
             payload_bytes: int = 67_108_864):
    a, b, c = (h.runtime / f"{name}-{node.lower()}" for node in ("A", "B", "C"))
    ap, bp, cp = free_port(), free_port(), free_port()
    ac = source_config(h, name + "-a", a, ap, bp)
    bc = publisher_config(h, name + "-b", b, bp, cp,
                          records=records, payload_bytes=payload_bytes)
    cc = recipient_config(h, name + "-c", c, cp, allow_output=allow_output)
    cd = h.start(name + "-c", cc, c) if start_recipient else None
    bd = h.start(name + "-b", bc, b)
    ad = h.start(name + "-a", ac, a)
    return a, b, c, ac, bc, cc, ad, bd, cd


def publish_args(state: Path, status: dict[str, Any], *, scope: str = OUTPUT_SCOPE,
                 peer: str = "C", name: str = "numeric", deadline_ms: int = 4000) -> list[str]:
    consumer = status["consumer"]
    return [
        "projection-publish", "--control", str(state / "control.sock"),
        "--consumer", name,
        "--instance", consumer["instance"],
        "--expected-revision", str(consumer["revision"]),
        "--expected-position", str(consumer["acknowledged_sequence"]),
        "--result-digest", consumer["projection_result_digest"],
        "--peer", peer,
        "--scope", scope,
        "--deadline-ms", str(deadline_ms),
    ]


def publish(h: Harness, label: str, state: Path, status: dict[str, Any],
            *, scope: str = OUTPUT_SCOPE, peer: str = "C", name: str = "numeric",
            expected: int = 0, deadline_ms: int = 4000) -> dict[str, Any]:
    result = h.run(label, publish_args(state, status, scope=scope, peer=peer,
                                      name=name, deadline_ms=deadline_ms), expected=expected)
    assert result is not None
    if expected == 0:
        h.check(result["format"] == "NATRAV_OVERLAY_PROJECTION_PUBLICATION_V1",
                "versioned projection publication receipt")
        h.check(result["payload_format"] == "NPP1", "canonical NPP1 result evidence")
        h.check(result["result_digest"] == status["consumer"]["projection_result_digest"],
                "receipt binds selected result digest")
        h.check(result["processed_frontier"] == status["consumer"]["acknowledged_sequence"],
                "receipt binds exact processed frontier")
    return result


class Reader:
    def __init__(self, data: bytes):
        self.data = data
        self.at = 0

    def take(self, count: int) -> bytes:
        if self.at + count > len(self.data):
            raise AssertionError("truncated NPP1")
        value = self.data[self.at:self.at + count]
        self.at += count
        return value

    def u8(self) -> int: return self.take(1)[0]
    def u16(self) -> int: return struct.unpack("!H", self.take(2))[0]
    def u32(self) -> int: return struct.unpack("!I", self.take(4))[0]
    def u64(self) -> int: return struct.unpack("!Q", self.take(8))[0]
    def i64_bits(self) -> int: return struct.unpack("!q", self.take(8))[0]
    def digest(self) -> str: return self.take(32).hex()
    def text(self) -> str:
        return self.take(self.u16()).decode("utf-8")


def decode_npp1(payload: bytes) -> dict[str, Any]:
    r = Reader(payload)
    if r.take(4) != b"NPP1":
        raise AssertionError("wrong projection publication payload")
    definition_kind = r.u8()
    lifecycle_kind = r.u8()
    if r.u16() != 0:
        raise AssertionError("NPP1 reserved field")
    value: dict[str, Any] = {
        "definition": {1: "DOMAIN_SUMMARY_V1", 2: "NUMERIC_SUMMARY_V1"}[definition_kind],
        "lifecycle": {1: "ACTIVE", 2: "RETIRED"}[lifecycle_kind],
        "owner_uid": r.u32(),
        "instance": r.digest(),
        "revision": r.u64(),
        "epoch": r.u64(),
        "position": r.u64(),
        "acknowledgments": r.u64(),
        "definition_digest": r.digest(),
        "result_digest": r.digest(),
        "source_digest": r.digest(),
        "read_authority_digest": r.digest(),
        "publication_authority_digest": r.digest(),
        "consumer": r.text(),
        "source_issuer": r.text(),
        "source_scope": r.text(),
        "recipient": r.text(),
        "recipient_generation": r.text(),
        "recipient_spki": r.digest(),
        "output_scope": r.text(),
        "maximum_admissions": r.u64(),
    }
    result = {
        "admissions": r.u64(),
        "originals": r.u64(),
        "corrections": r.u64(),
        "historical_payload_bytes": r.u64(),
        "current_payload_bytes": r.u64(),
        "source_digest": r.digest(),
    }
    if definition_kind == 2:
        result["numeric"] = {
            "accepted": r.u64(),
            "rejected": r.u64(),
            "valid_heads": r.u64(),
            "invalid_heads": r.u64(),
            "sum_ticks": r.i64_bits(),
            "errors": [r.u64() for _ in range(4)],
        }
        encoded_size = r.u32()
        encoded = Reader(r.take(encoded_size))
        unit = encoded.take(encoded.u8()).decode("ascii")
        result["numeric_definition"] = {
            "unit": unit,
            "scale": encoded.u8(),
            "maximum_absolute_sum_ticks": encoded.u64(),
        }
        if encoded.at != len(encoded.data):
            raise AssertionError("numeric definition trailing bytes")
    if lifecycle_kind == 2:
        value["retirement"] = {
            "revision": r.u64(),
            "unix_ms": r.u64(),
            "final_consumer_digest": r.digest(),
            "final_schedule_digest": r.digest(),
        }
    if r.at != len(payload):
        raise AssertionError(f"NPP1 trailing bytes: {len(payload)-r.at}")
    value["result"] = result
    return value


def recipient_record(h: Harness, label: str, state: Path, operation_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    response = query(h, label, state, operation=operation_id, view="history",
                     payload="yes", payload_length=16384)
    h.check(len(response["records"]) == 1, "recipient admitted one exact result evidence record")
    row = response["records"][0]
    return row, decode_npp1(bytes.fromhex(row["payload_hex"]))


def cases(h: Harness, selected: set[str] | None = None) -> None:
    def case(name: str, fn: Any) -> None:
        if selected is None or name in selected:
            h.case(name, fn)

    def semantics() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(h, "semantics")
        assert cd is not None
        values: dict[str, bytes] = {}
        first = produce(h, "publication-first", a, values, ticks=100)
        produce(h, "publication-correction", a, values, ticks=125, corrects=first)
        numeric_create(h, "publication-create", b, limit=8)
        status, rows = consume(h, "publication-consume", b, values)
        h.check(status["consumer"]["projection"]["result"]["numeric"]["sum_ticks"] == "125",
                "selected corrected numeric result")

        result = publish(h, "publish-active", b, status)
        operation_id = result["operation_id"]
        wait_state(h, b, operation_id, "ACKED", "publish-active-acked")
        row, decoded = recipient_record(h, "recipient-active", c, operation_id)
        h.check(row["issuer"] == "B" and row["recipient"] == "C" and row["scope"] == OUTPUT_SCOPE,
                "ordinary scoped evidence delivery carries the result")
        h.check(decoded["definition"] == "NUMERIC_SUMMARY_V1" and decoded["lifecycle"] == "ACTIVE",
                "typed definition and lifecycle are explicit")
        h.check(decoded["result_digest"] == result["result_digest"] and
                decoded["source_digest"] == result["source_commitment"],
                "payload binds result and source commitments")
        h.check(decoded["read_authority_digest"] == result["read_authority_digest"] and
                decoded["publication_authority_digest"] == result["publication_authority_digest"],
                "payload binds stable read and disclosure authority")
        h.check(decoded["position"] == len(rows) and decoded["result"]["numeric"]["sum_ticks"] == 125,
                "independent NPP1 decoder reconstructs the exact processed result")
        independent_operation = hashlib.sha256(
            b"NATRAV_OVERLAY_PROJECTION_PUBLICATION_OPERATION_V1\0" +
            bytes.fromhex(row["payload_hex"])
        ).hexdigest()
        h.check(independent_operation == operation_id, "stable operation identity derives from canonical payload")

        before = (b / "state.journal").read_bytes()
        duplicate = publish(h, "publish-active-repeat", b, status)
        h.check(duplicate["queue_disposition"] == "ALREADY_ACKED" and
                duplicate["operation_id"] == operation_id,
                "lost publication reply cannot multiply an acknowledged result")
        h.check((b / "state.journal").read_bytes() == before,
                "duplicate acknowledged publication is observational")

        newer = produce(h, "publication-new-result", a, values, ticks=5)
        new_status, rows = consume(h, "publication-consume-new", b, values, rows=rows)
        stale = publish(h, "publish-stale-result", b, status, expected=3)
        h.check(stale["code"] == "PROJECTION_PUBLICATION_REVISION_CONFLICT",
                "changed projection cannot reinterpret an old selector")
        second = publish(h, "publish-new-result", b, new_status)
        h.check(second["operation_id"] != operation_id, "changed result has a distinct operation identity")
        wait_state(h, b, second["operation_id"], "ACKED", "publish-new-acked")
        _, decoded2 = recipient_record(h, "recipient-new", c, second["operation_id"])
        h.check(decoded2["position"] == len(rows) and decoded2["result"]["numeric"]["sum_ticks"] == 130,
                "new result is independently attributable")

        observed = retirement_status(h, "publish-retire-observe", b, "numeric")
        retired = retire(h, "publish-retire", b, "numeric", account=observed)
        final_status = numeric_call(h, "publish-retired-status", b, "status")
        h.check(final_status["consumer"]["lifecycle"] == "RETIRED",
                "final result remains inspectable after retirement")
        final = publish(h, "publish-retired-final", b, final_status)
        h.check(final["lifecycle"] == "RETIRED" and final["operation_id"] != second["operation_id"],
                "retired final publication is explicit and distinct")
        wait_state(h, b, final["operation_id"], "ACKED", "publish-retired-acked")
        _, decoded3 = recipient_record(h, "recipient-retired", c, final["operation_id"])
        h.check(decoded3["lifecycle"] == "RETIRED" and
                decoded3["result_digest"] == final_status["consumer"]["projection_result_digest"],
                "retired payload preserves exact final result")
        h.check(retired["consumer"]["retirement"]["pending_disposition"] == "NO_ISSUED_PAGE",
                "retirement did not fabricate a pending-page disposition")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("canonical_numeric_publication_duplicate_change_and_retired_final", semantics)

    def metadata_definition() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(h, "metadata")
        assert cd is not None
        op = operation("metadata-publication-source")
        submit(h, "metadata-publication-source", ad.control, "A", "B",
               "query/series", op, "metadata projection input")
        wait_state(h, a, op, "ACKED", "metadata-publication-source-acked")
        metadata_create(h, "metadata-publication-create", b, limit=8)
        page = projection_read(h, "metadata-publication-read", b)
        status = projection_call(
            h, "metadata-publication-process", b, "process",
            batch=page["consumer"]["pending_batch"]["id"])
        check_result(h, status, page["records"])
        result = publish(h, "metadata-publication", b, status, name="summary")
        wait_state(h, b, result["operation_id"], "ACKED", "metadata-publication-acked")
        _, decoded = recipient_record(h, "metadata-publication-recipient", c,
                                      result["operation_id"])
        h.check(decoded["definition"] == "DOMAIN_SUMMARY_V1" and
                "numeric" not in decoded["result"],
                "metadata definition has no invented numeric interpretation")
        h.check(decoded["result"]["admissions"] == 1 and
                decoded["result"]["current_payload_bytes"] == len("metadata projection input"),
                "metadata result totals survive ordinary evidence delivery")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("canonical_metadata_projection_publication", metadata_definition)

    def authority_and_rejection() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(h, "authority")
        assert cd is not None
        values: dict[str, bytes] = {}
        produce(h, "authority-source", a, values, ticks=77)
        numeric_create(h, "authority-create", b)
        status, _ = consume(h, "authority-consume", b, values)

        no_submit = candidate(h, bc, "publication-no-submit", "authority-b-g2",
                              lambda s: s.replace(",SUBMIT,", ","))
        activate(h, "publication-revoke-submit", b, no_submit)
        denied = publish(h, "publication-without-submit", b, status, expected=3)
        h.check(denied["code"] == "LOCAL_CONTROL_CLASS_DENIED",
                "projection/read authority alone cannot disclose a result")

        restored = candidate(h, no_submit, "publication-submit-restored", "authority-b-g3",
                             lambda s: s.replace(",INSPECT,ACTION,", ",INSPECT,SUBMIT,ACTION,"))
        # The exact class ordering can differ when canonicalized; if the targeted insertion
        # did not match, replace the full local-control line deterministically.
        text = restored.read_text()
        if ",SUBMIT," not in next(x for x in text.splitlines() if x.startswith("local_control=")):
            lines = []
            for line in text.splitlines():
                if line.startswith("local_control="):
                    line = f"local_control={os.geteuid()}," + ",".join(OWNER_PROJECTION_CLASSES)
                lines.append(line)
            restored.write_text("\n".join(lines) + "\n")
        activate(h, "publication-restore-submit", b, restored)
        rejected = publish(h, "publication-recipient-denial", b, status, scope=DENIED_SCOPE)
        wait_state(h, b, rejected["operation_id"], "REJECTED", "publication-denied-terminal")
        repeat = publish(h, "publication-recipient-denial-repeat", b, status, scope=DENIED_SCOPE)
        h.check(repeat["queue_disposition"] == "ALREADY_REJECTED",
                "authenticated recipient denial is terminal and idempotent")
        h.check(query(h, "denied-not-admitted", c, operation=rejected["operation_id"],
                      view="history", payload="yes")["records"] == [],
                "recipient denial creates no evidence admission")

        no_read = candidate(h, restored, "publication-no-read", "authority-b-g4",
                            lambda s: s.replace(",EVIDENCE_READ,EVIDENCE_PAYLOAD", ",EVIDENCE_READ")
                            .replace(f"evidence_read={os.geteuid()},A,query/series,PAYLOAD",
                                     f"evidence_read={os.geteuid()},A,query/series,METADATA"))
        activate(h, "publication-revoke-read", b, no_read)
        read_denied = publish(h, "publication-without-result-read", b, status, expected=3)
        h.check(read_denied["code"] in {"LOCAL_CONTROL_CLASS_DENIED", "EVIDENCE_READ_DENIED",
                                        "EVIDENCE_READ_DOMAIN_DENIED", "CONSUMER_POLICY_CHANGED"},
                "publication rechecks current result authority")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("local_disclosure_authority_and_authenticated_recipient_rejection", authority_and_rejection)

    def quota_and_unavailable() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "quota", start_recipient=False, records=1, payload_bytes=65536)
        values: dict[str, bytes] = {}
        produce(h, "quota-source-one", a, values, ticks=1)
        numeric_create(h, "quota-create", b)
        first_status, rows = consume(h, "quota-consume-one", b, values)
        first = publish(h, "quota-first-publication", b, first_status)
        wait_state(h, b, first["operation_id"], "PENDING", "quota-first-pending")

        produce(h, "quota-source-two", a, values, ticks=2)
        second_status, rows = consume(h, "quota-consume-two", b, values, rows=rows)
        full = publish(h, "quota-second-publication", b, second_status, expected=3)
        h.check(full["code"] in {"OUTBOX_GLOBAL_RECORD_LIMIT", "OUTBOX_PEER_RECORD_LIMIT"},
                "publication obeys existing pending-record governance")

        cd = h.start("quota-c", cc, c)
        wait_state(h, b, first["operation_id"], "ACKED", "quota-first-released")
        second = publish(h, "quota-second-after-release", b, second_status)
        wait_state(h, b, second["operation_id"], "ACKED", "quota-second-acked")
        recipient_record(h, "quota-second-recipient", c, second["operation_id"])
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("unavailable_recipient_and_outbox_quota_release", quota_and_unavailable)

    def commit_kills() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(h, "kills", start_recipient=False)
        values: dict[str, bytes] = {}
        produce(h, "kill-source", a, values, ticks=456)
        numeric_create(h, "kill-create", b)
        status, _ = consume(h, "kill-consume", b, values)
        bd.shutdown()
        for phase, expected_disposition in (("BEFORE", "QUEUED"), ("AFTER", "ALREADY_PENDING")):
            environment = {f"NATRAV_OVERLAY_TEST_PROJECTION_PUBLICATION_{phase}_COMMIT_MS": "20000"}
            bd = h.start("publication-kill-" + phase.lower(), bc, b, environment)
            client = subprocess.Popen([str(h.binary), *publish_args(b, status, deadline_ms=15000)],
                                      text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                h.wait("publication commit marker " + phase,
                       lambda: f"TEST_PROJECTION_PUBLICATION_{phase}_COMMIT_MS" in bd.stderr_path.read_text(),
                       timeout=6)
                bd.kill()
                client.communicate(timeout=5)
            finally:
                if client.poll() is None:
                    client.kill(); client.communicate()
            bd = h.start("publication-restart-" + phase.lower(), bc, b)
            replay = publish(h, "publication-retry-" + phase.lower(), b, status)
            h.check(replay["queue_disposition"] == expected_disposition,
                    "publication commit boundary " + phase)
            status = numeric_call(h, "publication-selector-" + phase.lower(), b, "status")
            bd.shutdown()
        cd = h.start("kills-c", cc, c)
        bd = h.start("kills-b-final", bc, b)
        final = publish(h, "publication-final-retry", b, status)
        wait_state(h, b, final["operation_id"], "ACKED", "publication-kill-final-acked")
        recipient_record(h, "publication-kill-recipient", c, final["operation_id"])
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("hard_kill_before_and_after_atomic_outbox_commit", commit_kills)

    def maintenance() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(h, "maintenance", start_recipient=False)
        values: dict[str, bytes] = {}
        produce(h, "maintenance-source", a, values, ticks=250)
        numeric_create(h, "maintenance-create", b)
        status, _ = consume(h, "maintenance-consume", b, values)
        publication = publish(h, "maintenance-publish", b, status)
        wait_state(h, b, publication["operation_id"], "PENDING", "maintenance-pending")
        bd.shutdown()

        keys = h.runtime / "publication-keys"; keys.mkdir(mode=0o700)
        state_key = new_key(h, keys, "publication-state-g1")
        migrate(h, "publication-migrate", b, state_key, "B")
        bd = start_keyed(h, "publication-keyed", bc, b, state_key)
        h.run("publication-compact", ["compact", "--control", str(bd.control)])
        bd.shutdown()

        crypt = keys / "backup.key"
        archive = keys / "publication.nob"
        identity = h.identity("B")
        h.run("publication-backup-key", ["backup-key-init", "--output", str(crypt),
                                         "--generation", "publication-backup-g1"])
        h.run("publication-export", ["backup-export", "--state", str(b), "--node", "B",
                                      "--generation", "b-g1", "--output", str(archive),
                                      "--state-auth-key", str(state_key), "--encrypt-key", str(crypt),
                                      "--sign-key", str(identity.private_key),
                                      "--sign-cert", str(identity.certificate)])
        restored = h.runtime / "publication-restored"
        h.run("publication-restore", ["backup-restore", "--input", str(archive),
                                       "--destination", str(restored), "--node", "B",
                                       "--generation", "b-g1", "--state-auth-key", str(state_key),
                                       "--decrypt-key", str(crypt), "--trusted-cert", str(identity.certificate),
                                       "--require-signature", "yes", "--require-encryption", "yes"])
        moved = candidate(h, bc, "publication-relocated", "maintenance-b-relocated",
                          lambda s: s.replace(f"state={b}", f"state={restored}"))
        h.run("publication-relocate", ["state-relocate", "--state", str(restored),
                                        "--node", "B", "--candidate", str(moved),
                                        "--reason", "restore projection publication outbox",
                                        "--state-auth-key", str(state_key)])
        cd = h.start("maintenance-c", cc, c)
        bd = start_keyed(h, "maintenance-restored-b", moved, restored, state_key)
        wait_state(h, restored, publication["operation_id"], "ACKED", "maintenance-restored-acked")
        row, decoded = recipient_record(h, "maintenance-restored-recipient", c, publication["operation_id"])
        h.check(decoded["result_digest"] == publication["result_digest"],
                "compaction and encrypted restore preserve publication account")
        h.check(row["operation_id"] == publication["operation_id"],
                "restored outbox delivers the exact original operation")
        duplicate = publish(h, "maintenance-restored-repeat", restored, status)
        h.check(duplicate["queue_disposition"] == "ALREADY_ACKED" and
                duplicate["operation_id"] == publication["operation_id"],
                "restored duplicate publication remains idempotent")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("keyed_compaction_encrypted_restore_relocation_and_delivery", maintenance)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--case", action="append")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not exist")
    h = Harness(args.binary, args.output)
    began = time.time(); passed = False
    try:
        cases(h, set(args.case) if args.case else None)
        passed = True
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=os.sys.stderr)
    finally:
        h.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_PROJECTION_PUBLICATION_TESTS_V1",
            "status": "PASS" if passed else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "cases_total": len(h.cases),
            "cases_passed": sum(case["status"] == "PASS" for case in h.cases),
            "assertions": h.assertions,
            "commands": len(h.commands),
            "elapsed_seconds": time.time() - began,
        }
        for name, value in (("SUMMARY", summary), ("CASES", h.cases), ("COMMANDS", h.commands)):
            (h.output / f"{name}.json").write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")
        print(json.dumps(summary), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
