#!/usr/bin/env python3
"""Deterministic packet/process adversity around configured adapter nodes.

The pinned fixture and UDP relay are untrusted test plumbing.  They have no
peer keys, configuration authority, application receipts, custody, forwarding,
or relay permission.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
from typing import Any

from configured_adapter_process_schedule import (
    FEATURE as PROCESS_FEATURE,
    ProcessSchedule,
    nonresponse_signature,
    parse_trace,
)
from run_configured_adapter_transport import (
    assert_receipt,
    image_profile,
    peer,
    ref,
    wait_entry,
)
from run_peer_sessions import outbox_entry, submit
from run_persistent import Harness, free_port, operation
from run_runtime_adapter_configuration import endpoint, records, upgrade, write
from run_udp_adversary import free_udp_port
from run_unix_datagram_transport import run_external
from udp_datagram_adversary import (
    FEATURE as PACKET_FEATURE,
    DatagramAdversary,
    FaultRule,
    FaultSchedule,
    RelayPath,
    fault_signature,
)


EXPECTED_REVISION = "0613"


def profile_with_bounds(identifier: str, executable: Path, arguments: list[object], **bounds: int) -> str:
    text = image_profile(identifier, executable, arguments)
    replacements = {
        "max-launch-attempts": bounds.get("max_launch_attempts", 3),
        "startup-timeout-ms": bounds.get("startup_timeout_ms", 2_000),
        "request-timeout-ms": bounds.get("request_timeout_ms", 500),
        "shutdown-timeout-ms": bounds.get("shutdown_timeout_ms", 500),
        "initial-restart-backoff-ms": bounds.get("initial_restart_backoff_ms", 10),
        "maximum-restart-backoff-ms": bounds.get("maximum_restart_backoff_ms", 250),
    }
    lines = []
    for line in text.splitlines():
        key = line.split("=", 1)[0]
        lines.append(f"{key}={replacements[key]}" if key in replacements else line)
    return "\n".join(lines) + "\n"


def trace_files(prefix: Path) -> list[Path]:
    return sorted(prefix.parent.glob(prefix.name + ".*.trace"))


def parsed_traces(prefix: Path) -> list[dict[str, object]]:
    return [parse_trace(path) for path in trace_files(prefix)]


def launch_count(path: Path) -> int:
    if not path.exists():
        return 0
    lines = path.read_text().splitlines()
    if lines[:1] != ["NATRAV_CONFIGURED_ADAPTER_LAUNCH_STATE_V1"] or len(lines) != 2:
        raise AssertionError("noncanonical launch-state fixture file")
    return int(lines[1].removeprefix("launches="))


def live_trace(prefix: Path) -> dict[str, object]:
    traces = parsed_traces(prefix)
    if not traces:
        raise AssertionError("no process trace exists")
    return max(traces, key=lambda item: int(item["launch_ordinal"]))


def maximum_ordinal(trace: dict[str, object], kind: str) -> int:
    records = trace["records"]
    assert isinstance(records, list)
    return max((int(item["ordinal"]) for item in records if item["kind"] == kind), default=0)


def packet_schedule(name: str = "configured-adversity") -> FaultSchedule:
    return FaultSchedule(
        name=name,
        default_action="PASS",
        max_datagram_bytes=512,
        max_pending_events=128,
        max_trace_records=16_384,
        rules=(
            FaultRule("ab", "A_TO_B", 1, "DROP"),
            FaultRule("ab", "A_TO_B", 2, "CORRUPT"),
            FaultRule("ab", "A_TO_B", 3, "REORDER", 35),
            FaultRule("ab", "B_TO_A", 1, "DUPLICATE", 3),
            FaultRule("ab", "B_TO_A", 2, "DELAY", 30),
            FaultRule("ba", "A_TO_B", 1, "DUPLICATE", 3),
            FaultRule("ba", "A_TO_B", 2, "DELAY", 30),
            FaultRule("ba", "B_TO_A", 1, "DROP"),
            FaultRule("ba", "B_TO_A", 2, "CORRUPT"),
            FaultRule("ba", "B_TO_A", 3, "REORDER", 35),
        ),
    )


def compile_fixture(h: Harness, root: Path) -> Path:
    fixture = h.work / "configured-adapter-adversary-fixture"
    flags = [
        "-D_GNU_SOURCE", "-std=c++20", "-O1", "-Wall", "-Wextra",
        "-Wpedantic", "-Wconversion", "-Wsign-conversion", "-Wshadow",
        "-Wformat=2", "-Werror",
    ]
    result = run_external(
        h,
        "compile-configured-adversary-fixture",
        ["/usr/bin/g++", *flags, str(root / "node/tests/configured_adapter_fixture.cpp"), "-o", str(fixture)],
        timeout=90,
    )
    h.check(result.returncode == 0, "strict configured-adversary fixture compile: " + result.stderr)
    fixture.chmod(0o700)
    return fixture


def adapter_arguments(
    local: int,
    remote: int,
    prefix: Path,
    schedule: Path,
    launch_state: Path,
) -> list[object]:
    return ["--adversary-v1", local, remote, prefix, schedule, launch_state]


def node_config(
    h: Harness,
    fixture: Path,
    label: str,
    node: str,
    peer_id: str,
    state: Path,
    incoming: tuple[int, int],
    outgoing: tuple[int, int],
    schedules: dict[str, Path],
    prefixes: dict[str, Path],
    launch_states: dict[str, Path],
    *,
    profile_bounds: dict[str, int] | None = None,
) -> tuple[Path, dict[str, str]]:
    lower = node.lower()
    endpoint_names = (f"{lower}-in", f"{lower}-out")
    ports = {endpoint_names[0]: incoming, endpoint_names[1]: outgoing}
    profiles: dict[str, str] = {}
    endpoint_records: dict[str, str] = {}
    for name in endpoint_names:
        image = h.work / f"{label}-{name}-image"
        shutil.copy2(fixture, image)
        image.chmod(0o700)
        local, remote = ports[name]
        profiles[name] = profile_with_bounds(
            name,
            image,
            adapter_arguments(local, remote, prefixes[name], schedules[name], launch_states[name]),
            **(profile_bounds or {}),
        )
        endpoint_records[name] = endpoint(
            profiles[name],
            identifier=name,
            role="listener" if name.endswith("-in") else "route",
        )
    config = h.config(
        f"{label}-{lower}",
        node,
        state,
        free_port(),
        [(peer_id, free_port(), 100, 400, 100, 120_000)],
        deadline_ms=2_500,
    )
    text = upgrade(config.read_text(), f"{label}-{lower}-base")
    lines = []
    for line in text.splitlines():
        if line.startswith("listen="):
            line = "listen=" + ref(f"{lower}-in")
        if line.startswith("peer_route="):
            line = ",".join(line.split(",")[:4]) + "," + ref(f"{lower}-out")
        lines.append(line)
    text = "\n".join(lines) + "\n"
    text += records(list(profiles.values()), list(endpoint_records.values()))
    text += "session_max_operations=64\nsession_idle_timeout_ms=10000\n"
    write(config, text)
    h.run(f"check-{label}-{lower}", ["config-check", "--config", str(config)])
    return config, profiles


def start_burners(count: int) -> list[subprocess.Popen[bytes]]:
    burners = []
    command = [
        sys.executable,
        "-c",
        "import os; os.nice(5); x=1\nwhile True: x=((x*1103515245)+12345)&0x7fffffff",
    ]
    for _ in range(count):
        burners.append(subprocess.Popen(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        ))
    return burners


def stop_burners(burners: list[subprocess.Popen[bytes]]) -> None:
    for process in burners:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    for process in burners:
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pass


def suite(h: Harness, selected: str | None) -> None:
    root = Path(__file__).resolve().parents[2]
    fixture = compile_fixture(h, root)

    def case(name: str, function: Any) -> None:
        if selected is None or selected == name:
            h.case(name, function)

    def canonical_and_boundary() -> None:
        version = h.run("configured-adversary-version", ["version"])
        h.check(version is not None and version.get("version") == EXPECTED_REVISION,
                "revision 0613 is explicit")
        h.check(version is not None and version.get("configured_adapter_adversity") ==
                "DETERMINISTIC_CONFIGURED_ADAPTER_ADVERSITY_V1",
                "configured-adapter adversity marker is explicit")
        h.check(version is not None and version.get("configured_adapter_transport") is True,
                "configured adapter transport remains enabled")
        healthy = ProcessSchedule(name="healthy")
        h.check(ProcessSchedule.decode(healthy.encode()) == healthy,
                "canonical process schedule round-trips byte exactly")
        variants = [
            healthy.encode()[:-1],
            healthy.encode().replace(b"maximum-trace-records=256", b"maximum-trace-records=0256"),
            healthy.encode().replace(b"startup-action=PASS", b"startup-action=UNKNOWN"),
            healthy.encode().replace(b"feature=" + PROCESS_FEATURE.encode(), b"feature=OTHER"),
            healthy.encode().replace(b"name=healthy", b"name=Healthy"),
        ]
        for encoded in variants:
            rejected = False
            try:
                ProcessSchedule.decode(encoded)
            except ValueError:
                rejected = True
            h.check(rejected, "malformed or noncanonical process schedule is rejected")
        invalid = h.work / "invalid-process-schedule.txt"
        invalid.write_bytes(variants[1])
        completed = run_external(
            h,
            "fixture-rejects-noncanonical-process-schedule",
            [str(fixture), "--adversary-v1", str(free_udp_port()), str(free_udp_port()),
             str(h.logs / "invalid-fixture"), str(invalid),
             str(h.work / "invalid-launch-state")],
            timeout=5,
        )
        h.check(completed.returncode == 80,
                "independent pinned fixture rejects the same noncanonical schedule")
        matrix = (root / "node/tests/run_matrix.py").read_text()
        build = (root / "node/build.sh").read_text()
        product = "\n".join(
            path.read_text(errors="strict")
            for path in sorted((root / "node/src").glob("*"))
            if path.suffix in {".cpp", ".hpp"}
        )
        h.check("configured_adapter_adversary" in matrix,
                "adversity suite is registered")
        h.check("configured_adapter_fixture.cpp" not in build and
                PROCESS_FEATURE not in product and PACKET_FEATURE not in product,
                "fault schedulers remain fixture-only and outside product authority")
    case("canonical_process_schedule_and_private_boundary", canonical_and_boundary)

    def run_packet_exchange(label: str, contention: bool) -> list[tuple[Any, ...]]:
        run_root = h.runtime / label
        run_root.mkdir(parents=True)
        ports = [free_udp_port() for _ in range(8)]
        (
            a_out, relay_ab_left, relay_ab_right, b_in,
            b_out, relay_ba_left, relay_ba_right, a_in,
        ) = ports
        paths = (
            RelayPath(
                name="ab",
                left_bind=("127.0.0.1", relay_ab_left),
                left_source=("127.0.0.1", a_out),
                right_bind=("127.0.0.1", relay_ab_right),
                right_source=("127.0.0.1", b_in),
                left_to_right="A_TO_B",
                right_to_left="B_TO_A",
            ),
            RelayPath(
                name="ba",
                left_bind=("127.0.0.1", relay_ba_left),
                left_source=("127.0.0.1", b_out),
                right_bind=("127.0.0.1", relay_ba_right),
                right_source=("127.0.0.1", a_in),
                left_to_right="B_TO_A",
                right_to_left="A_TO_B",
            ),
        )
        relay = DatagramAdversary(paths)
        relay.start()
        phase = "contention" if contention else "baseline"
        schedule = packet_schedule("configured-" + phase)
        (h.work / f"{label}-packet-schedule.json").write_bytes(schedule.encode())
        relay.install(schedule, phase=phase)
        endpoint_ports = {
            "a-in": (a_in, relay_ba_right),
            "a-out": (a_out, relay_ab_left),
            "b-in": (b_in, relay_ab_right),
            "b-out": (b_out, relay_ba_left),
        }
        prefixes = {name: h.logs / f"{label}-{name}" for name in endpoint_ports}
        schedules = {}
        launch_states = {}
        for name in endpoint_ports:
            schedules[name] = ProcessSchedule(name="healthy").write(
                h.work / f"{label}-{name}-process-schedule.txt")
            launch_states[name] = h.work / f"{label}-{name}-launch-state.txt"
        a_config, _ = node_config(
            h, fixture, label, "A", "B", run_root / "a",
            endpoint_ports["a-in"], endpoint_ports["a-out"],
            schedules, prefixes, launch_states,
        )
        b_config, _ = node_config(
            h, fixture, label, "B", "A", run_root / "b",
            endpoint_ports["b-in"], endpoint_ports["b-out"],
            schedules, prefixes, launch_states,
        )
        burners = start_burners(2 if contention else 0)
        a = b = None
        try:
            b = h.start(f"{label}-b", b_config, run_root / "b")
            a = h.start(f"{label}-a", a_config, run_root / "a")
            forward = operation(label + "-forward")
            reverse = operation(label + "-reverse")
            submit(h, label + "-submit-forward", a.control, "A", "B", "test/three",
                   forward, "configured-adapter-adversity-forward")
            forward_status = wait_entry(h, run_root / "a", forward, timeout=45)
            assert_receipt(h, run_root / "a", forward, "B")
            submit(h, label + "-submit-reverse", b.control, "B", "A", "test/three",
                   reverse, "configured-adapter-adversity-reverse")
            reverse_status = wait_entry(h, run_root / "b", reverse, timeout=45)
            assert_receipt(h, run_root / "b", reverse, "A")
            h.check(peer(forward_status, "B")["session"]["opened"] >= 1 and
                    peer(reverse_status, "A")["session"]["opened"] >= 1,
                    label + ": both directions used authenticated sessions")
            h.check(h.status(label + "-b-status", run_root / "b")["inbound_records"] == 1,
                    label + ": packet duplicates did not duplicate A-to-B admission")
            h.check(h.status(label + "-a-status", run_root / "a")["inbound_records"] == 1,
                    label + ": packet duplicates did not duplicate B-to-A admission")
            relay.wait_quiet(timeout=10)
            records = relay.trace_records(phase)
            signature = fault_signature(records, phase)
            h.check(len(signature) == len(schedule.rules),
                    label + ": every scheduled packet fault was exercised exactly once")
            h.check({item[3] for item in signature} ==
                    {"DROP", "DUPLICATE", "CORRUPT", "DELAY", "REORDER"},
                    label + ": all five packet fault classes are present")
            relay.write_trace(h.output / f"{label}-packet-trace.json")
            for name, prefix in prefixes.items():
                traces = parsed_traces(prefix)
                h.check(bool(traces), label + ": process trace exists for " + name)
                h.check(nonresponse_signature(traces) == [],
                        label + ": packet-only phase caused no process fault for " + name)
            return signature
        finally:
            if a is not None:
                a.shutdown()
            if b is not None:
                b.shutdown()
            stop_burners(burners)
            relay.close()

    def packet_replay_under_contention() -> None:
        first = run_packet_exchange("packet-replay-one", False)
        second = run_packet_exchange("packet-replay-two", True)
        h.check(first == second,
                "fixed packet schedule has the same path/direction/ordinal/action/size structure under CPU contention")
    case("packet_fault_replay_under_cpu_contention", packet_replay_under_contention)

    def process_failure_and_attempt_accounting() -> None:
        run_root = h.runtime / "process-adversity"
        run_root.mkdir(parents=True)
        ports = [free_udp_port() for _ in range(4)]
        endpoint_ports = {
            "a-in": (ports[0], ports[3]),
            "a-out": (ports[1], ports[2]),
            "b-in": (ports[2], ports[1]),
            "b-out": (ports[3], ports[0]),
        }
        prefixes = {name: h.logs / f"process-{name}" for name in endpoint_ports}
        schedules = {}
        launch_states = {}
        for name in endpoint_ports:
            schedule = ProcessSchedule(name="healthy")
            if name == "a-out":
                schedule = ProcessSchedule(
                    name="startup-silent",
                    startup_action="SILENT",
                    startup_count=64,
                    startup_silence_ms=1_000,
                )
            schedules[name] = schedule.write(h.work / f"process-{name}-schedule.txt")
            launch_states[name] = h.work / f"process-{name}-launch-state.txt"
        bounds = {
            "max_launch_attempts": 3,
            "startup_timeout_ms": 150,
            "request_timeout_ms": 180,
            "shutdown_timeout_ms": 180,
            "initial_restart_backoff_ms": 10,
            "maximum_restart_backoff_ms": 20,
        }
        a_config, _ = node_config(
            h, fixture, "process", "A", "B", run_root / "a",
            endpoint_ports["a-in"], endpoint_ports["a-out"],
            schedules, prefixes, launch_states, profile_bounds=bounds,
        )
        b_config, _ = node_config(
            h, fixture, "process", "B", "A", run_root / "b",
            endpoint_ports["b-in"], endpoint_ports["b-out"],
            schedules, prefixes, launch_states, profile_bounds=bounds,
        )
        b = h.start("process-b", b_config, run_root / "b")
        a = h.start("process-a", a_config, run_root / "a")
        try:
            preauth = operation("configured-adapter-startup-budget")
            submit(h, "process-submit-preauth", a.control, "A", "B", "test/three",
                   preauth, "pending through exhausted startup budget")
            last: dict[str, Any] = {}

            def budget_exhausted() -> bool:
                last.clear()
                last.update(h.status("process-wait-budget", run_root / "a", logical_digest=False))
                return (
                    launch_count(launch_states["a-out"]) >= 3
                    and "ADAPTER_START_FAILED" in json.dumps(last)
                )

            h.wait("configured adapter startup budget exhausted", budget_exhausted, 20)
            preauth_entry = outbox_entry(last, preauth)
            h.check(preauth_entry["status"] == "PENDING" and preauth_entry["attempts"] == 0,
                    "pre-authentication process failure is a route failure and consumes no application attempt")
            silent_traces = parsed_traces(prefixes["a-out"])
            h.check(len([item for item in silent_traces if item["terminal"] == "STARTUP_SILENT"]) >= 3,
                    "all bounded startup attempts have canonical silent-response evidence")

            ProcessSchedule(name="startup-recovered").write(schedules["a-out"])
            recovered = wait_entry(h, run_root / "a", preauth, timeout=45)
            assert_receipt(h, run_root / "a", preauth, "B")
            opened_before = peer(recovered, "B")["session"]["opened"]
            h.check(opened_before >= 1, "recovered path established a fresh authenticated session")

            current = live_trace(prefixes["a-out"])
            next_transmit = maximum_ordinal(current, "TRANSMIT") + 1
            ProcessSchedule(
                name="runtime-silent",
                silent_transmit_ordinal=next_transmit,
                silent_response_ms=1_000,
            ).write(schedules["a-out"])
            runtime = operation("configured-adapter-runtime-silence")
            submit(h, "process-submit-runtime", a.control, "A", "B", "test/three",
                   runtime, "authenticated write faces silent NAPA response")

            def runtime_silenced() -> bool:
                return any(item["terminal"] == "RUNTIME_SILENT"
                           for item in parsed_traces(prefixes["a-out"]))

            h.wait("runtime NAPA response is deterministically silent", runtime_silenced, 12)
            during = outbox_entry(h.status("process-runtime-pending", run_root / "a"), runtime)
            h.check(during["status"] == "PENDING" and during["attempts"] >= 1,
                    "failure of an authenticated application write consumes an application attempt")
            ProcessSchedule(name="runtime-recovered").write(schedules["a-out"])
            after = wait_entry(h, run_root / "a", runtime, timeout=45)
            assert_receipt(h, run_root / "a", runtime, "B")
            h.check(peer(after, "B")["session"]["opened"] > opened_before,
                    "runtime silence retires the old carrier and requires a fresh authenticated session")

            current = live_trace(prefixes["a-out"])
            next_crash = maximum_ordinal(current, "TRANSMIT") + 1
            ProcessSchedule(
                name="runtime-crash",
                crash_transmit_ordinal=next_crash,
            ).write(schedules["a-out"])
            crashed = operation("configured-adapter-runtime-crash")
            submit(h, "process-submit-crash", a.control, "A", "B", "test/three",
                   crashed, "authenticated write faces deterministic child death")

            def process_crashed() -> bool:
                return any(item["terminal"] == "RUNTIME_CRASH"
                           for item in parsed_traces(prefixes["a-out"]))

            h.wait("runtime adapter process crash is recorded", process_crashed, 12)
            crash_pending = outbox_entry(h.status("process-crash-pending", run_root / "a"), crashed)
            h.check(crash_pending["status"] == "PENDING" and crash_pending["attempts"] >= 1,
                    "authenticated-session process death preserves pending work and honest attempt accounting")
            ProcessSchedule(name="crash-recovered").write(schedules["a-out"])
            final = wait_entry(h, run_root / "a", crashed, timeout=45)
            assert_receipt(h, run_root / "a", crashed, "B")
            h.check(peer(final, "B")["session"]["opened"] > peer(after, "B")["session"]["opened"],
                    "process death also requires a new TLS/HELLO session")
            signatures = nonresponse_signature(parsed_traces(prefixes["a-out"]))
            h.check(any(item[3] == "SILENT" for item in signatures) and
                    any(item[3] == "CRASH" for item in signatures),
                    "bounded process traces retain both silent-response and crash evidence")
        finally:
            a.shutdown()
            b.shutdown()
    case("startup_budget_runtime_silence_and_attempt_accounting", process_failure_and_attempt_accounting)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not exist")
    harness = Harness(args.binary, args.output)
    started = time.monotonic()
    code = 1
    try:
        suite(harness, args.case)
        if not harness.cases:
            raise ValueError("unknown case")
        code = 0
    except BaseException as error:
        (harness.output / "FAILURE.txt").write_text(f"{type(error).__name__}: {error}\n")
        print(f"FAIL: {type(error).__name__}: {error}", file=sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_CONFIGURED_ADAPTER_ADVERSARY_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_total": len(harness.cases),
            "cases_passed": sum(item["status"] == "PASS" for item in harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "elapsed_seconds": time.monotonic() - started,
        }
        for name, value in (
            ("SUMMARY", summary),
            ("CASES", harness.cases),
            ("COMMANDS", harness.commands),
        ):
            (harness.output / f"{name}.json").write_text(
                json.dumps(value, indent=2, sort_keys=True) + "\n"
            )
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
