#!/usr/bin/env python3
"""Focused no-receipt request-binding regression using owned mutually authenticated peers."""
import argparse,hashlib,json,sys,time
from pathlib import Path
from run_action_result_correlation import (Harness,operation,setup,candidate,activate,submit_action,
    wait_action,wait_outbox,evidence_query,decode_nac1,encode_nac,emit,query)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    def probe():
        action=operation('absent-receipt-binding')
        root,port,_,ac,bc,ad,bd=setup(h,'binding',environment={'NATRAV_OVERLAY_TEST_SESSION_DROP_AFTER_ADMISSION_OPERATION':action})
        slow=candidate(h,ac,'long-binding-retry','binding-g2',lambda t:t.replace('peer=B,50,250,50,120000','peer=B,10000,10000,50,120000'))
        activate(h,'slow-binding-retry',root/'a',slow)
        submit_action(h,'original-binding-request',root/'a',action,5)
        executed=wait_action(h,'executed-binding',root/'b',action,'EXECUTED');result=executed['action_result']['operation_id']
        wait_outbox(h,'returned-binding-result',root/'b',result,'ACKED')
        original=query(h,'receipt-really-absent',root/'a',result,action)
        h.check(original['original_request']['source_admission_receipt'] is None,'test requires actual absence, not a redundant receipt comparison')
        payload=bytes.fromhex(evidence_query(h,'raw-binding-result',root/'a',result)['payload_hex'])
        report=decode_nac1(payload);report['source_record_digest']='77'*32
        fabricated=emit(h,port,encode_nac(report))
        denied=query(h,'no-receipt-wrong-request-digest',root/'a',fabricated,action,expected=3)
        h.check(denied['code']=='ACTION_RESULT_REQUEST_MISMATCH','original immutable request must bind independently of optional receipt')
        (h.output/'OBSERVATION.json').write_text(json.dumps({'original':original,'altered_report_denial':denied},indent=2)+'\n')
        bd.shutdown();ad.shutdown()
    try:h.case('missing_source_receipt_does_not_relax_original_record_binding',probe);ok=True
    except BaseException as exc:(h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(str(exc),file=sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_RESULT_BINDING_PROBE_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,value in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]: (h.output/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')
        print(json.dumps(summary))
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
