#!/usr/bin/env python3
"""Peer/scope authorization and durable bounded-action integration tests."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import time
from typing import Any, Callable

from run_integration import decode_app, encode_record, frame, hello, recv_frame_bytes
from run_persistent import Harness, free_port, operation
from run_tls_security import client_context


def generation(label: str) -> str:
    return "g-" + label.lower()


def action_payload(amount: int, defer_ms: int = 0) -> bytes:
    return b"NCA1" + struct.pack("!QI", amount, defer_ms)


def write_config(
    h: Harness,
    name: str,
    node: str,
    state: Path,
    port: int,
    identity_label: str,
    routes: list[tuple[str, int, str]],
    keys: list[tuple[str, str, str, str]],
    rules: list[tuple[str, str, str, str]],
    *,
    counter_budget: int = 1000,
    maximum_increment: int = 100,
    maximum_defer_ms: int = 60_000,
    action_expiry_ms: int = 86_400_000,
    deadline_ms: int = 700,
) -> Path:
    identity = h.identity(identity_label)
    lines = [
        "NATRAV_OVERLAY_CONFIG_V6",
        f"node={node}",
        f"state={state}",
        f"listen=127.0.0.1:{port}",
        "control=control.sock",
        f"identity_cert={identity.certificate}",
        f"identity_key={identity.private_key}",
        f"identity_pin={identity.spki_sha256}",
        f"identity_generation={generation(identity_label)}",
        f"deadline_ms={deadline_ms}",
        "peer_workers=4",
        "peer_queue_capacity=64",
        "control_workers=2",
        "control_queue_capacity=64",
        f"action_counter_budget={counter_budget}",
        f"action_max_increment={maximum_increment}",
        f"action_max_defer_ms={maximum_defer_ms}",
        f"action_expiry_ms={action_expiry_ms}",
    ]
    for peer, peer_port, _identity in routes:
        lines.append(f"peer={peer},127.0.0.1:{peer_port},50,250,20,30000")
    for peer, key_generation, state_name, peer_identity in keys:
        lines.append(
            f"peer_key={peer},{key_generation},{state_name},"
            f"{h.identity(peer_identity).spki_sha256}"
        )
    for peer, key_generation, operation_class, resource in rules:
        lines.append(
            f"authorize={peer},{key_generation},{operation_class},{resource}"
        )
    path = h.work / f"{name}.conf"
    path.write_text("\n".join(lines) + "\n")
    path.chmod(0o644)
    return path


def independent_record(
    h: Harness,
    port: int,
    identity_label: str,
    claimed_node: str,
    recipient: str,
    operation_id: str,
    scope: str,
    payload: bytes,
) -> dict[str, Any]:
    context = client_context(h, identity_label)
    with socket.create_connection(("127.0.0.1", port), timeout=3) as raw:
        with context.wrap_socket(raw, server_hostname=None) as channel:
            h.check(channel.version() == "TLSv1.3", "independent replay uses TLS 1.3")
            h.check(
                channel.selected_alpn_protocol() == "natrav-overlay/1",
                "independent replay uses exact ALPN",
            )
            request = operation("authorization-action-request-" + operation_id)
            channel.sendall(frame(hello(claimed_node, request)))
            _, ack = recv_frame_bytes(channel)
            decoded_ack = json.loads(ack)
            h.check(decoded_ack["kind"] == "HELLO_ACK", "independent replay handshake accepted")
            channel.sendall(frame(encode_record(
                operation_id, claimed_node, recipient, scope, payload
            )))
            _, response = recv_frame_bytes(channel)
            return decode_app(response)


def submit_evidence(
    h: Harness,
    label: str,
    control: Path,
    issuer: str,
    recipient: str,
    scope: str,
    operation_id: str,
    payload: str,
) -> dict[str, Any]:
    value = h.run(
        label,
        [
            "submit", "--control", str(control), "--node", issuer,
            "--peer", recipient, "--scope", scope,
            "--operation", operation_id, "--payload-text", payload,
            "--deadline-ms", "2000",
        ],
    )
    assert value is not None
    return value


def submit_action(
    h: Harness,
    label: str,
    control: Path,
    issuer: str,
    recipient: str,
    operation_id: str,
    amount: int,
    defer_ms: int = 0,
) -> dict[str, Any]:
    value = h.run(
        label,
        [
            "action-submit", "--control", str(control), "--node", issuer,
            "--peer", recipient, "--operation", operation_id,
            "--amount", str(amount), "--defer-ms", str(defer_ms),
            "--deadline-ms", "2000",
        ],
    )
    assert value is not None
    return value


def outbox_entry(status: dict[str, Any], operation_id: str) -> dict[str, Any]:
    return next(
        entry for entry in status["outbox"]["entries"]
        if entry["operation_id"] == operation_id
    )


def action_entry(status: dict[str, Any], action_id: str) -> dict[str, Any]:
    return next(
        entry for entry in status["actions"]["entries"]
        if entry["action_id"] == action_id
    )


def run_suite(h: Harness, selected: set[str] | None = None) -> None:
    def run_case(name: str, function: Callable[[], None]) -> None:
        if selected is None or name in selected:
            h.case(name, function)

    def policy_configuration() -> None:
        root = h.runtime / "policy-config"
        root.mkdir()
        keys = [
            ("B", "b1", "ACTIVE", "B"),
            ("C", "c1", "ACTIVE", "C"),
        ]
        rules = [
            ("B", "*", "EVIDENCE", "weather/current"),
            ("B", "*", "ACTION", "counter.add"),
        ]
        first = write_config(
            h, "policy-first", "A", root / "state-a", free_port(), "A",
            [], keys, rules,
            counter_budget=25, maximum_increment=10,
            maximum_defer_ms=5000, action_expiry_ms=10000,
        )
        second = write_config(
            h, "policy-second", "A", root / "state-b", free_port(), "A",
            [], list(reversed(keys)), list(reversed(rules)),
            counter_budget=25, maximum_increment=10,
            maximum_defer_ms=5000, action_expiry_ms=10000,
        )
        a = h.run("policy-config-first", ["config-check", "--config", str(first)])
        b = h.run("policy-config-second", ["config-check", "--config", str(second)])
        assert a is not None and b is not None
        h.check(a["format"] == "NATRAV_OVERLAY_CONFIG_V6", "V6 config reported")
        h.check(
            a["authorization"]["digest"] == b["authorization"]["digest"],
            "authorization policy digest is independent of input ordering",
        )
        h.check(len(a["authorization"]["rules"]) == 2, "two exact policy rules retained")
        h.check(
            a["authorization"]["action_limits"]["counter_budget"] == 25,
            "action budget reported",
        )

        ambiguous = write_config(
            h, "policy-ambiguous", "A", root / "state-c", free_port(), "A",
            [], keys,
            rules + [("B", "b1", "EVIDENCE", "weather/current")],
        )
        rejected = h.run(
            "policy-ambiguous-rejected",
            ["config-check", "--config", str(ambiguous)],
            expected=3,
        )
        h.check(
            rejected is not None and rejected["code"] == "AUTHORIZATION_RULE_AMBIGUOUS",
            "overlapping peer-wide and generation-specific rule rejected",
        )

    run_case("strict_stable_authorization_policy", policy_configuration)

    def authorization_boundary() -> None:
        root = h.runtime / "authorization-boundary"
        root.mkdir()
        a_state, b_state, c_state = root / "a", root / "b", root / "c"
        a_port, b_port, c_port = free_port(), free_port(), free_port()
        a_conf = write_config(
            h, "auth-a", "A", a_state, a_port, "A", [],
            [
                ("B", "b1", "ACTIVE", "B"),
                ("C", "c1", "ACTIVE", "C"),
            ],
            [("B", "*", "EVIDENCE", "weather/current")],
        )
        b_conf = write_config(
            h, "auth-b", "B", b_state, b_port, "B",
            [("A", a_port, "A")],
            [("A", "a1", "ACTIVE", "A")], [],
        )
        c_conf = write_config(
            h, "auth-c", "C", c_state, c_port, "C",
            [("A", a_port, "A")],
            [("A", "a1", "ACTIVE", "A")], [],
        )
        a = h.start("auth-a", a_conf, a_state)
        b = h.start("auth-b", b_conf, b_state)
        c = h.start("auth-c", c_conf, c_state)

        allowed = operation("authorized-weather")
        submit_evidence(
            h, "authorized-submit", b.control, "B", "A",
            "weather/current", allowed, "clear",
        )
        h.wait(
            "authorized evidence acknowledged",
            lambda: h.status("authorized-wait", b_state)["outbox"]["acked"] == 1,
        )
        denied = operation("denied-weather")
        submit_evidence(
            h, "denied-submit", c.control, "C", "A",
            "weather/current", denied, "forbidden",
        )

        denied_status: dict[str, Any] = {}
        def denied_visible() -> bool:
            denied_status.clear()
            denied_status.update(h.status("denied-wait", c_state))
            return outbox_entry(denied_status, denied)["last_error_code"] == "AUTHORIZATION_DENIED"
        h.wait("authorization denial returned to sender", denied_visible)

        a_status = h.status("authorization-recipient-status", a_state)
        h.check(a_status["inbound_records"] == 1, "denied evidence not admitted")
        h.check(a_status["authorization"]["denied"] == 1, "denial account is durable")
        h.check(a_status["service"]["peer_authorization_denied"] >= 1, "denial counted")

        replay = independent_record(
            h, a_port, "B", "B", "A", allowed,
            "weather/current", b"clear",
        )
        h.check(replay["kind"] == "receipt", "authorized replay receives receipt")
        h.check(replay["disposition"] == 2, "authorized replay classified duplicate")
        after = h.status("authorization-replay-status", a_state)
        h.check(after["inbound_records"] == 1, "replay does not multiply admission")
        h.check(after["authorization"]["denied"] == 1, "replay does not multiply denials")

        c.shutdown(); b.shutdown(); a.shutdown()
        inspected = h.run(
            "authorization-inspect",
            ["inspect", "--state", str(a_state), "--node", "A"],
        )
        assert inspected is not None
        admitted = inspected["inbound"]["history"][0]["authorization"]
        h.check(admitted["decision"] == "ADMITTED", "admission retains decision")
        h.check(admitted["peer"] == "B" and admitted["generation"] == "b1", "admission retains authenticated generation")
        h.check(admitted["policy_digest"] == a_status["authorization"]["policy_digest"], "admission binds policy digest")
        h.check(inspected["authorization_denials"]["count"] == 1, "offline denial reconstructed")
        denial = inspected["authorization_denials"]["entries"][0]
        h.check(denial["issuer"] == "C" and denial["reason_code"] == "AUTHORIZATION_DENIED", "offline denial attribution retained")

    run_case("authorized_admission_and_typed_denial", authorization_boundary)

    def action_execution_replay_cancel_and_limits() -> None:
        root = h.runtime / "action-lifecycle"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        a_conf = write_config(
            h, "action-a", "A", a_state, a_port, "A", [],
            [("B", "b1", "ACTIVE", "B")],
            [("B", "*", "ACTION", "counter.add")],
            counter_budget=10, maximum_increment=10,
            maximum_defer_ms=5000, action_expiry_ms=10000,
        )
        b_conf = write_config(
            h, "action-b", "B", b_state, b_port, "B",
            [("A", a_port, "A")],
            [("A", "a1", "ACTIVE", "A")], [],
        )
        a = h.start("action-a", a_conf, a_state)
        b = h.start("action-b", b_conf, b_state)

        first = operation("counter-seven")
        submitted = submit_action(
            h, "action-seven-submit", b.control, "B", "A", first, 7,
        )
        h.check(submitted["operation_class"] == "ACTION", "action submission classified")
        final: dict[str, Any] = {}
        def executed() -> bool:
            final.clear(); final.update(h.status("action-seven-wait", a_state))
            return final["actions"]["executed"] == 1
        h.wait("counter action executes", executed)
        h.check(final["actions"]["counter_value"] == 7, "counter advanced by authorized amount")
        first_entry = action_entry(final, first)
        h.check(first_entry["attempts"] == 1, "action started once")
        h.check(first_entry["receipt_digest"] is not None, "durable action receipt recorded")

        replay = independent_record(
            h, a_port, "B", "B", "A", first,
            "actions/counter.add/v1", action_payload(7),
        )
        h.check(replay["kind"] == "receipt" and replay["disposition"] == 2, "action replay receives duplicate admission receipt")
        replayed = h.status("action-replay-status", a_state)
        h.check(replayed["actions"]["count"] == 1, "action replay does not multiply queue")
        h.check(replayed["actions"]["counter_value"] == 7, "action replay does not multiply effect")

        cancelled = operation("counter-cancelled")
        submit_action(
            h, "action-cancel-submit", b.control, "B", "A",
            cancelled, 2, 3000,
        )
        h.wait(
            "deferred action admitted",
            lambda: any(
                item["action_id"] == cancelled
                for item in h.status("action-cancel-wait", a_state)["actions"]["entries"]
            ),
        )
        cancellation = h.run(
            "action-cancel-control",
            [
                "action-cancel", "--control", str(a.control),
                "--action", cancelled, "--reason", "operator withdrew mandate",
                "--deadline-ms", "2000",
            ],
        )
        assert cancellation is not None
        h.check(cancellation["status"] == "CANCELLED", "deferred action cancelled")
        after_cancel = h.status("action-cancel-status", a_state)
        h.check(after_cancel["actions"]["counter_value"] == 7, "cancelled action has no effect")
        h.check(action_entry(after_cancel, cancelled)["status"] == "CANCELLED", "cancellation reconstructable live")

        over_budget = operation("counter-over-budget")
        submit_action(
            h, "action-over-budget-submit", b.control, "B", "A",
            over_budget, 4,
        )
        budget_sender: dict[str, Any] = {}
        def budget_denied() -> bool:
            budget_sender.clear(); budget_sender.update(h.status("action-budget-wait", b_state))
            return outbox_entry(budget_sender, over_budget)["last_error_code"] == "ACTION_BUDGET_EXHAUSTED"
        h.wait("counter budget denial reaches sender", budget_denied)
        recipient = h.status("action-budget-recipient", a_state)
        h.check(recipient["actions"]["count"] == 2, "budget denial creates no action")
        h.check(recipient["inbound_records"] == 2, "budget denial creates no evidence record")
        h.check(recipient["authorization"]["denied"] == 1, "budget denial account retained")

        malformed = operation("counter-malformed")
        submit_evidence(
            h, "action-malformed-submit", b.control, "B", "A",
            "actions/counter.add/v1", malformed, "not-an-action",
        )
        malformed_sender: dict[str, Any] = {}
        def malformed_denied() -> bool:
            malformed_sender.clear(); malformed_sender.update(h.status("action-malformed-wait", b_state))
            return outbox_entry(malformed_sender, malformed)["last_error_code"] == "ACTION_REQUEST_INVALID"
        h.wait("malformed action rejected", malformed_denied)
        stable = h.status("action-malformed-recipient", a_state)
        h.check(stable["actions"]["count"] == 2, "malformed payload creates no action")
        h.check(stable["inbound_records"] == 2, "malformed payload creates no evidence")

        b.shutdown(); a.shutdown()
        inspected = h.run(
            "action-lifecycle-inspect",
            ["inspect", "--state", str(a_state), "--node", "A"],
        )
        assert inspected is not None
        h.check(inspected["actions"]["counter_value"] == 7, "counter reconstructs offline")
        statuses = {item["action_id"]: item["status"] for item in inspected["actions"]["entries"]}
        h.check(statuses[first] == "EXECUTED" and statuses[cancelled] == "CANCELLED", "action terminal states reconstruct")

    run_case("durable_exactly_once_action_cancel_and_limits", action_execution_replay_cancel_and_limits)

    def expiry_behind_bounded_execution() -> None:
        root = h.runtime / "action-expiry"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        a_conf = write_config(
            h, "expiry-action-a", "A", a_state, a_port, "A", [],
            [("B", "b1", "ACTIVE", "B")],
            [("B", "*", "ACTION", "counter.add")],
            counter_budget=10, maximum_increment=5,
            maximum_defer_ms=100, action_expiry_ms=300,
        )
        b_conf = write_config(
            h, "expiry-action-b", "B", b_state, b_port, "B",
            [("A", a_port, "A")],
            [("A", "a1", "ACTIVE", "A")], [],
        )
        a = h.start(
            "expiry-action-a", a_conf, a_state,
            {"NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS": "800"},
        )
        b = h.start("expiry-action-b", b_conf, b_state)
        first = operation("slow-first-action")
        second = operation("expires-behind-first")
        submit_action(h, "slow-action-submit", b.control, "B", "A", first, 1)
        h.wait(
            "first action durably begins",
            lambda: (
                h.status("slow-action-started", a_state)["actions"]["count"] == 1
                and action_entry(h.status("slow-action-started-2", a_state), first)["attempts"] == 1
            ),
        )
        submit_action(h, "expiring-action-submit", b.control, "B", "A", second, 1)
        result: dict[str, Any] = {}
        def terminal() -> bool:
            result.clear(); result.update(h.status("expiring-action-wait", a_state))
            return result["actions"]["executed"] == 1 and result["actions"]["expired"] == 1
        h.wait("second action expires behind bounded execution", terminal, 6.0)
        h.check(result["actions"]["counter_value"] == 1, "expired action has no effect")
        h.check(action_entry(result, second)["status"] == "EXPIRED", "expiry status visible")
        b.shutdown(); a.shutdown()

    run_case("bounded_action_expiry", expiry_behind_bounded_execution)

    def interrupted_action_restart() -> None:
        root = h.runtime / "action-restart"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        a_conf = write_config(
            h, "restart-action-a", "A", a_state, a_port, "A", [],
            [("B", "b1", "ACTIVE", "B")],
            [("B", "*", "ACTION", "counter.add")],
            counter_budget=20, maximum_increment=10,
            maximum_defer_ms=100, action_expiry_ms=15000,
        )
        b_conf = write_config(
            h, "restart-action-b", "B", b_state, b_port, "B",
            [("A", a_port, "A")],
            [("A", "a1", "ACTIVE", "A")], [],
        )
        a = h.start(
            "restart-action-a-1", a_conf, a_state,
            {"NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS": "5000"},
        )
        b = h.start("restart-action-b", b_conf, b_state)
        action_id = operation("interrupted-counter-action")
        submit_action(
            h, "interrupted-action-submit", b.control, "B", "A",
            action_id, 3,
        )
        before: dict[str, Any] = {}
        def begun() -> bool:
            before.clear(); before.update(h.status("interrupted-action-wait", a_state))
            if before["actions"]["count"] != 1:
                return False
            entry = action_entry(before, action_id)
            return entry["attempts"] == 1 and entry["last_error_code"] == "ACTION_ATTEMPT_INTERRUPTED"
        h.wait("action start persisted before kill", begun)
        h.check(before["actions"]["counter_value"] == 0, "begin record has no premature effect")
        a.kill()

        a2 = h.start("restart-action-a-2", a_conf, a_state)
        restored: dict[str, Any] = {}
        def recovered() -> bool:
            restored.clear(); restored.update(h.status("interrupted-action-recover", a_state))
            return restored["actions"]["executed"] == 1
        h.wait("interrupted action executes after restart", recovered)
        entry = action_entry(restored, action_id)
        h.check(entry["attempts"] == 2, "restart consumes a second durable attempt")
        h.check(restored["actions"]["counter_value"] == 3, "effect occurs exactly once after restart")
        h.check(restored["actions"]["count"] == 1, "restart does not multiply action")
        b.shutdown(); a2.shutdown()

        inspected = h.run(
            "interrupted-action-inspect",
            ["inspect", "--state", str(a_state), "--node", "A"],
        )
        assert inspected is not None
        offline = inspected["actions"]["entries"][0]
        h.check(offline["attempts"] == 2 and offline["status"] == "EXECUTED", "restart history reconstructs offline")
        h.check(inspected["actions"]["counter_value"] == 3, "offline counter is exact")

    run_case("hard_kill_restart_action_recovery", interrupted_action_restart)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, default=Path("node/bin/natrav-overlay"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--case",
        action="append",
        choices=[
            "strict_stable_authorization_policy",
            "authorized_admission_and_typed_denial",
            "durable_exactly_once_action_cancel_and_limits",
            "bounded_action_expiry",
            "hard_kill_restart_action_recovery",
        ],
    )
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output directory must not exist")
    harness = Harness(args.binary, args.output)
    started = time.time()
    status = "FAIL"
    return_code = 1
    try:
        run_suite(harness, set(args.case) if args.case else None)
        status = "PASS"
        return_code = 0
    except BaseException as exc:
        (harness.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_AUTHORIZATION_ACTION_TESTS_V1",
            "status": status,
            "binary": str(harness.binary),
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "selected_cases": args.case or [],
            "started_unix": started,
            "elapsed_seconds": time.time() - started,
        }
        (harness.output / "SUMMARY.json").write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n"
        )
        (harness.output / "CASES.json").write_text(
            json.dumps(harness.cases, indent=2, sort_keys=True) + "\n"
        )
        (harness.output / "COMMANDS.json").write_text(
            json.dumps(harness.commands, indent=2, sort_keys=True) + "\n"
        )
        print(json.dumps(summary, sort_keys=True))
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
