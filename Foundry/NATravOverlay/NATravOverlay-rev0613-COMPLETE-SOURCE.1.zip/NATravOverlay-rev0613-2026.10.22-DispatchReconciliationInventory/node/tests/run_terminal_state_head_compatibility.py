#!/usr/bin/env python3
"""Actual predecessor rejection of new terminal-head options and wire kinds."""
from __future__ import annotations
import argparse
import hashlib
import json
import time
import traceback
from pathlib import Path
from run_persistent import Harness, raw_control
from run_control_authorization import packet, text
from run_terminal_state_head import setup
import struct

def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--binary',type=Path,required=True)
    p.add_argument('--predecessor-binary',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();h=Harness(a.binary,a.output);release=h.binary
    previous=a.predecessor_binary.resolve(strict=True);begin=time.time();code=1
    try:
        def boundary():
            h.binary=previous
            state,key,conf,d=setup(h,'actual-predecessor')
            for command in ('shutdown','drain-shutdown'):
                argv=[command,'--control',str(d.control),'--final-state-head','yes']
                if command=='drain-shutdown':argv+=['--reason','unknown terminal option','--drain-deadline-ms','100']
                value=h.run('old-cli-rejects-'+command,argv,expected=3)
                h.check(value and value['code']=='UNKNOWN_ARGUMENT','old CLI does not ignore explicit head requirement')
                h.check(d.process is not None and d.process.poll() is None,'rejected option does not stop predecessor')
            for kind,body in ((42,b''),(43,struct.pack('!I',100)+text('unknown terminal wire kind'))):
                ok,value=raw_control(d.control,packet(kind,body))
                h.check(not ok and value['code']=='CONTROL_PROTOCOL_REJECTED' and 'state_head' not in value,'old server rejects unknown terminal kind')
                h.check(d.process is not None and d.process.poll() is None,'rejected wire kind does not stop predecessor')
            value=h.run('old-default-still-stops',['shutdown','--control',str(d.control)])
            h.check(value and value['format']=='NATRAV_OVERLAY_CONTROL_SHUTDOWN_V2' and 'state_head' not in value,'original stop protocol still works')
            assert d.process;d.process.wait(timeout=8)
            h.check(d.process.returncode==0,'predecessor normal stop exits successfully');d._close_files()
        h.case('actual_predecessor_cli_and_wire_rejection',boundary);code=0
    except BaseException:
        (h.output/'FAILURE.txt').write_text(traceback.format_exc())
    finally:
        h.binary=release;h.cleanup()
        summary={'format':'NATRAV_OVERLAY_TERMINAL_HEAD_COMPATIBILITY_V1','status':'PASS' if code==0 else 'FAIL',
            'binary_sha256':hashlib.sha256(release.read_bytes()).hexdigest(),'predecessor_sha256':hashlib.sha256(previous.read_bytes()).hexdigest(),
            'cases_passed':sum(x['status']=='PASS' for x in h.cases),'cases_total':len(h.cases),
            'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-begin}
        for filename,data in [('SUMMARY.json',summary),('CASES.json',h.cases),('COMMANDS.json',h.commands)]:
            (h.output/filename).write_text(json.dumps(data,indent=2)+'\n')
        print(json.dumps(summary))
    return code
if __name__=='__main__':raise SystemExit(main())
