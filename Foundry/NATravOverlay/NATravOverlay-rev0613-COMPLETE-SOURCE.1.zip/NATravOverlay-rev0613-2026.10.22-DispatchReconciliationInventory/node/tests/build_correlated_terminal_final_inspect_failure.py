#!/usr/bin/env python3
"""Prepare an isolated build that forces the final correlated INSPECT recheck to deny."""
from __future__ import annotations

import argparse
import difflib
import json
from pathlib import Path
import shutil


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    out = args.output.resolve()
    if out.exists() or out == root or root in out.parents:
        parser.error("output must be a new path outside the product")
    tree = out / "source"
    tree.mkdir(parents=True)
    for part in ("node/src", "foundation/src", "foundation/include"):
        shutil.copytree(root / part, tree / part)
    shutil.copy2(root / "node/build.sh", tree / "node/build.sh")
    path = tree / "node/src/daemon.cpp"
    before = path.read_text()
    anchor = '''        const auto lease = runtime.lease();
        // Stop authority was checked when committing the stop. Head disclosure
        // additionally requires INSPECT in the FINAL accepted configuration.
        if (!terminal_head_inspection_allowed(*lease->config, handoff.principal.uid)) {'''
    replacement = '''        const auto lease = runtime.lease();
        // PRIVATE FAILURE PROBE: model final INSPECT revocation after writer joins.
        if (handoff.correlation.has_value()) {
            app_fail("LOCAL_CONTROL_CLASS_DENIED",
                "private final correlated INSPECT denial");
        }
        // Stop authority was checked when committing the stop. Head disclosure
        // additionally requires INSPECT in the FINAL accepted configuration.
        if (!terminal_head_inspection_allowed(*lease->config, handoff.principal.uid)) {'''
    if before.count(anchor) != 1:
        raise SystemExit("final INSPECT boundary not found exactly once")
    after = before.replace(anchor, replacement, 1)
    path.write_text(after)
    patch = out / "FORCE-FINAL-CORRELATED-INSPECT-DENIAL.patch"
    patch.write_text("".join(difflib.unified_diff(
        before.splitlines(True), after.splitlines(True),
        fromfile="normal/daemon.cpp", tofile="private/daemon.cpp",
    )))
    print(json.dumps({
        "format": "NATRAV_OVERLAY_CORRELATED_TERMINAL_FINAL_INSPECT_PREPARATION_V1",
        "status": "PREPARED_NOT_BUILT",
        "source": str(tree),
        "patch": str(patch),
    }))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
