"""Exact named work checks for nested source outbound admission.

This is test code, not a runtime dependency. Counts deliberately distinguish
record decoding, byte binding, canonical storage copying and policy parsing.
"""
from __future__ import annotations


def check_outbound_work(h, issue: dict, ack: dict, mode: str = 'delta') -> None:
    shared = mode not in ('independent-outbound', 'independent-decoding', 'full')
    parse_count = 2 if mode == 'independent-decoding' else 1
    return_count = parse_count
    copied_return = mode == 'copy-return'
    owned_outgoing = mode in ('owned-outgoing', 'independent-decoding')
    transferred_store = shared and mode != 'copy-store'
    payload = issue['outbound_store_digest_payload_bytes']
    outgoing_account = (issue['progress_outgoing_bytes_copied'] +
                        issue['progress_outgoing_slice_bytes'])
    h.check(outgoing_account % parse_count == 0,
            'outgoing composite accounting divides exactly across strict parses')
    composite = outgoing_account // parse_count
    policy = issue['outbound_policy_bytes_decoded']
    record = composite - 36 - policy
    h.check(payload > 0 and record > payload and policy > 32,
            'independently account composite framing, encoded record and policy sizes')
    h.check(issue['progress_outgoing_owned_copies'] == (parse_count if owned_outgoing else 0) and
            issue['progress_outgoing_bytes_copied'] == (parse_count * composite if owned_outgoing else 0),
            'only generic decoding or the forced-owned control copies the full composite')
    h.check(issue['progress_outgoing_slices'] == (0 if owned_outgoing else parse_count) and
            issue['progress_outgoing_slice_bytes'] == (0 if owned_outgoing else parse_count * composite),
            'normal command parsing retains one exact immutable composite slice per parse')
    h.check(issue['outbound_composite_frames'] == 1 and issue['outbound_policy_decodes'] == 1,
            'atomic framing and normal policy decoding remain')
    h.check(issue['outbound_record_decodes'] == (0 if shared else 2) and
            issue['outbound_record_bytes_decoded'] == (0 if shared else 2 * record),
            'nested record syntax is reused twice or independently decoded by control')
    h.check(issue['outbound_record_payload_bytes_decoded'] == (0 if shared else 2 * payload),
            'two named payload decoder copies disappear only on the prepared path')
    h.check(issue['outbound_record_reuses'] == issue['outbound_binding_checks'] == (2 if shared else 0),
            'each syntax reuse requires an exact independent byte binding')
    h.check(issue['outbound_binding_bytes_compared'] == (composite + record if shared else 0),
            'measure both full composite and record byte comparisons')
    h.check(issue['outbound_prepared_slices'] == (1 if shared else 0) and
            issue['outbound_slice_header_bytes_read'] == (36 if shared else 0),
            'one owned immutable slice reads only framing and copies no payload')
    h.check(issue['source_composite_return_payload_bytes_copied'] ==
            (return_count * payload if copied_return else 0),
            'decoded composite return copies payload only in the forced-copy control')
    h.check(issue['source_composite_return_ownership_transfers'] ==
            (0 if copied_return else return_count) and
            issue['source_composite_return_payload_bytes_transferred'] ==
            (0 if copied_return else return_count * payload),
            'normal composite decoding transfers one locally owned payload per strict parse')
    h.check(issue['outbound_record_validations'] == 2 and
            issue['outbound_store_digest_calls'] == 1 and
            issue['outbound_store_digest_payload_bytes'] == payload,
            'record semantics and independent canonical storage digest remain')
    h.check(issue['outbound_store_payload_bytes_copied'] ==
            (0 if transferred_store else payload),
            'only generic decoding or the forced-copy control copies canonical source payload')
    h.check(issue['outbound_store_ownership_transfers'] ==
            (1 if transferred_store else 0) and
            issue['outbound_store_payload_bytes_transferred'] ==
            (payload if transferred_store else 0) and
            issue['outbound_store_publication_checks'] ==
            (1 if transferred_store else 0),
            'normal live source issuance transfers one exact post-publication record owner')
    h.check(all(value == 0 for key, value in ack.items() if key.startswith('outbound_')),
            'acknowledgment performs no nested outbound admission work')
    h.check(ack['progress_outgoing_owned_copies'] == 0 and
            ack['progress_outgoing_bytes_copied'] == 0 and
            ack['progress_outgoing_slices'] == 0 and
            ack['progress_outgoing_slice_bytes'] == 0,
            'acknowledgment owns or slices no outgoing source composite')
    h.check(ack['source_composite_return_payload_bytes_copied'] == 0 and
            ack['source_composite_return_ownership_transfers'] == 0 and
            ack['source_composite_return_payload_bytes_transferred'] == 0,
            'acknowledgment decodes no source outbound composite')
    h.check(ack['receipt_checks'] >= 2,
            'actual receipt predicates remain independent of record syntax reuse')
