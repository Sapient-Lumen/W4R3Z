#!/usr/bin/env python3
"""Build an owned local negative-control binary; never use it for real state.

Copies only node/foundation into a temporary tree, removes one root comparison,
uses the unmodified static build script, exports only the diagnostic executable,
and deletes the temporary tree. The real source tree is never edited.
"""
from __future__ import annotations
import argparse
import difflib
from pathlib import Path
import shutil
import subprocess
import tempfile


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--patch-output', type=Path, required=True)
    a = p.parse_args()
    if a.output.exists() or a.patch_output.exists(): p.error('outputs must not exist')
    root = Path(__file__).resolve().parents[2]
    with tempfile.TemporaryDirectory(prefix='natrav-expectation-negative-') as tmp:
        work = Path(tmp)
        for name in ('node', 'foundation'):
            shutil.copytree(root / name, work / name, ignore=shutil.ignore_patterns('bin', '__pycache__', '*.pyc'))
        source = work / 'node/src/state_auth.cpp'
        old = source.read_text()
        needle = 'expected.root == authentication.root && expected.records == authentication.records'
        assert old.count(needle) == 1
        new = old.replace(needle, 'expected.records == authentication.records', 1)
        source.write_text(new)
        a.patch_output.parent.mkdir(parents=True, exist_ok=True)
        a.patch_output.write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
            fromfile='a/node/src/state_auth.cpp', tofile='b/node/src/state_auth.cpp')))
        subprocess.run(['sh', 'node/build.sh', 'static'], cwd=work, check=True)
        a.output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(work / 'node/bin/natrav-overlay', a.output)
    return 0

if __name__ == '__main__': raise SystemExit(main())
