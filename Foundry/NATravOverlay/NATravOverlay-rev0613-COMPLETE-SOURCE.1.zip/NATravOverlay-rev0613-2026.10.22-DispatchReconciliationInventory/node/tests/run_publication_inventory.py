#!/usr/bin/env python3
"""Owner-scoped channel metadata: native C++ state, real TLS, independent PIN1/root checks."""
from __future__ import annotations
import argparse, concurrent.futures, contextlib, hashlib, json, os, shutil, socket, struct, subprocess, sys, time
from pathlib import Path
from run_persistent import Harness, free_port, raw_control
from run_projection_publication import publisher_config, source_config, recipient_config, OUTPUT_SCOPE
from run_publication_channels import channel_create, channel_status, channel_publish, channel_retire
from run_automatic_publication_channels import auto_enable, auto_pause, wait_publications
from run_publication_epochs import new_epoch, cancel_head
from run_projections import create as metadata_create
from run_numeric_projection import create as numeric_create, produce, consume
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_live_configuration import candidate, activate, wait_state
from run_state_authentication import new_key, migrate, start as keyed_start, inspect

FORMAT = 'NATRAV_OVERLAY_PUBLICATION_INVENTORY_V1'

def topology(h, name, *, start_recipient=True, allow_output=True, records=4096, payload_bytes=67_108_864):
    # Reserve distinct listener ports concurrently until each process starts.
    # Repeated bind(0)/close calls may return the same port within one topology.
    a,b,c=(h.runtime/(name+'-'+node) for node in ['a','b','c'])
    with contextlib.ExitStack() as stack:
        sockets=[stack.enter_context(socket.socket(socket.AF_INET,socket.SOCK_STREAM)) for _ in range(3)]
        for sock in sockets:sock.bind(('127.0.0.1',0))
        ap,bp,cp=[sock.getsockname()[1] for sock in sockets]
        ac=source_config(h,name+'-a',a,ap,bp)
        bc=publisher_config(h,name+'-b',b,bp,cp,records=records,payload_bytes=payload_bytes)
        cc=recipient_config(h,name+'-c',c,cp,allow_output=allow_output)
        sockets[2].close();cd=h.start(name+'-c',cc,c) if start_recipient else None
        sockets[1].close();bd=h.start(name+'-b',bc,b)
        sockets[0].close();ad=h.start(name+'-a',ac,a)
    return a,b,c,ac,bc,cc,ad,bd,cd
def save(h, name, data): (h.output / (name + '.json')).write_text(json.dumps(data, indent=2) + '\n')
def query(h, label, state, expected=0, uid=None, **kw):
    args = ['publication-channel-inventory','--control',str(state/'control.sock'),'--deadline-ms','4000']
    for k,v in kw.items(): args += ['--'+k.replace('_','-'),str(v)]
    r = h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    if expected == 0:
        h.check(r['format']==FORMAT and r['owner_uid']==(os.geteuid() if uid is None else uid),'format and actual owner')
        h.check(r['returned']==len(r['records']) and r['next_offset']==r['offset']+r['returned'],'whole page positions')
        h.check(all(x['owner_uid']==r['owner_uid'] for x in r['records']),'owner isolation')
        w=r['work'];h.check(all(w[x]==0 for x in ['payload_bytes_copied','histories_serialized','projection_results_computed','snapshot_calls','snapshot_payload_bytes','logical_bytes_serialized']),'no payload/result/history/snapshot work')
        h.check(len(json.dumps(r,separators=(',',':')).encode())<=int(kw.get('max_bytes',32768)),'whole annotated JSON fits')
    return r

def txt(s): b=s.encode();return struct.pack('!H',len(b))+b
def opt(s): return b'\1'+bytes.fromhex(s) if s else b'\0'
def wire(*,lifecycle='all',schedule='all',outcome='all',name='',projection='',peer='',scope='',instance=None,offset=0,limit=16,max_bytes=32768,selection=None):
    return b'NOC1'+bytes([37])+b'PIN1'+b''.join(txt(s) for s in [lifecycle,schedule,outcome,name,projection,peer,scope])+opt(instance)+struct.pack('!III',offset,limit,max_bytes)+opt(selection)
def root_for(r,rows,**kw):
    b=b'NATRAV_OVERLAY_PUBLICATION_INVENTORY_SELECTION_V1\0'+txt(r['node'])+struct.pack('!I',r['owner_uid'])+bytes.fromhex(r['authorized_configuration_digest'])+bytes.fromhex(r['read_authority_digest'])
    b+=b''.join(txt(kw.get(k,'all' if k in ['lifecycle','schedule','outcome'] else '')) for k in ['lifecycle','schedule','outcome','name','projection','peer','scope'])+opt(kw.get('instance'))+struct.pack('!I',len(rows))
    root=hashlib.sha256(b).digest()
    for row in rows:
        encoded=json.dumps(row,separators=(',',':'),ensure_ascii=False).encode()
        root=hashlib.sha256(b'NATRAV_OVERLAY_PUBLICATION_INVENTORY_ROW_V1\0'+root+struct.pack('!I',len(encoded))+encoded).digest()
    return root.hex()

def check_channel(h,row,c):
    for target,source in [('name','name'),('instance','instance'),('channel_revision','revision'),('projection_name','projection_consumer'),('projection_instance','projection_instance'),('recipient','recipient'),('scope','scope'),('publications','publication_count')]:
        h.check(row[target]==c[source],f'actual channel {target}')
    h.check('creation_reason' not in row and 'projection_result' not in row and 'result_digest' not in row,'no free reasons or computed result')
    h.check(row['lifecycle']==c['lifecycle'],'lifecycle matches actual channel')

def own_create(h,label,b,p,name='shared',uid=None,scope=OUTPUT_SCOPE):
    c=p['consumer'];args=['publication-channel-create','--control',str(b/'control.sock'),'--channel',name,'--consumer',c['name'],'--projection-instance',c['instance'],'--peer','C','--scope',scope,'--max-publications','16','--reason','owned disclosure channel']
    return h.run(label,args) if uid is None else run_as_uid(h,label,uid,uid,args,0)

def cases(h,selected=None):
    def case(name,f):
        if selected is None or name in selected:h.case(name,f)
    def basic():
        b=h.runtime/'basic';cfg=publisher_config(h,'basic',b,free_port(),free_port());d=h.start('basic',cfg,b)
        meta=metadata_create(h,'meta',b,'meta');num=numeric_create(h,'numeric',b)
        objects={}
        for name,p in [('alpha',meta),('beta',meta),('numeric',num),('retired',meta)]:objects[name]=channel_create(h,'create-'+name,b,p,name=name)['channel']
        objects['retired']=channel_retire(h,'retire-basic',b,objects['retired'],name='retired')['channel']
        allrows=query(h,'basic-all',b)
        h.check([r['name'] for r in allrows['records']]==sorted(objects),'name order with retained retired entry')
        h.check(root_for(allrows,allrows['records'])==allrows['selection_digest'],'independent complete-selection root')
        for row in allrows['records']:check_channel(h,row,objects[row['name']])
        first=query(h,'basic-first',b,limit=2);second=query(h,'basic-second',b,offset=first['next_offset'],selection=first['selection_digest'],limit=32)
        h.check(first['records']+second['records']==allrows['records'],'continuation can change page size')
        for filters,count in [({'lifecycle':'retired'},1),({'schedule':'none'},4),({'outcome':'none'},4),({'projection':'meta'},3),({'peer':'C'},4),({'scope':OUTPUT_SCOPE},4),({'name':'alpha','instance':objects['alpha']['instance']},1),({'name':'alpha','instance':'12'*32},0),({'peer':'A'},0),({'scope':'derived'},0)]:
            r=query(h,'filter-'+str(h.assertions),b,**filters);h.check(r['selected_total']==count,'exact conjunctive filters');h.check(root_for(r,r['records'],**filters)==r['selection_digest'],'filter commitment')
        before=(b/'state.journal').read_bytes()
        for i in range(8):query(h,'empty-'+str(i),b,name='missing')
        h.check(before==(b/'state.journal').read_bytes(),'empty polls append nothing')
        ok,r=raw_control(d.control,wire());h.check(ok and r['records']==allrows['records'],'independent PIN1 request')
        for bad in [wire()+b'x',wire()[:-1],wire().replace(b'PIN1',b'PIN2'),wire(lifecycle='*'),wire(schedule='running'),wire(outcome='done'),wire(limit=0),wire(limit=33),wire(max_bytes=2047),wire(max_bytes=60001),wire(offset=1),wire(name='..'),wire(instance='00'*32)]:
            ok,r=raw_control(d.control,bad);h.check(not ok,'strict malformed request refusal')
        h.check(query(h,'false-selection',b,selection='22'*32,expected=3)['code']=='PUBLICATION_INVENTORY_SELECTION_MISMATCH','selection bound')
        h.check(query(h,'small-row',b,name='numeric',max_bytes=2048,expected=3)['code']=='PUBLICATION_INVENTORY_PAGE_TOO_SMALL','no partial first row')
        bytepage=query(h,'byte-page',b,limit=32,max_bytes=4096);h.check(0<bytepage['returned']<4,'byte-bound continuation preserves nonfitting row')
        h.run('basic-compact',['compact','--control',str(d.control)]);d.shutdown();d=h.start('basic-restart',cfg,b)
        again=query(h,'same-restart-selection',b,selection=allrows['selection_digest']);h.check(again['records']==allrows['records'],'durable metadata selection stable across compaction/restart')
        save(h,'BASIC',{'all':allrows,'byte_page':bytepage,'restart':again});d.shutdown()
    case('strict_wire_filters_bounded_pages_and_independent_digest',basic)

    def progress():
        a,b,c,ac,bc,cc,ad,bd,cd=topology(h,'progress',start_recipient=False)
        values={};first_source=produce(h,'source-one',a,values,ticks=100)
        numeric_create(h,'p-numeric',b,limit=8);p,rows=consume(h,'p-consume',b,values)
        idle_projection=metadata_create(h,'p-idle',b,'idle')
        first=channel_create(h,'progress-main',b,p,name='main')['channel'];channel_create(h,'progress-unrelated',b,idle_projection,name='unrelated')
        idle=query(h,'unrelated-selected',b,name='unrelated');empty=query(h,'no-head',b,name='main')
        pub=channel_publish(h,'publish-one',b,first,p,name='main')
        pending=query(h,'pending-head',b,name='main');h.check(pending['records'][0]['head']['outbound_status']=='PENDING','pending actual outbox state')
        h.check(query(h,'new-head-stale',b,name='main',selection=empty['selection_digest'],expected=3)['code']=='PUBLICATION_INVENTORY_SELECTION_MISMATCH','new head changes selection')
        cd=h.start('progress-c',cc,c);wait_state(h,b,pub['operation_id'],'ACKED','first-receipt')
        h.check(query(h,'receipt-stale',b,name='main',selection=pending['selection_digest'],expected=3)['code']=='PUBLICATION_INVENTORY_SELECTION_MISMATCH','real receipt invalidates continuation')
        acked=query(h,'acked-head',b,name='main');h.check(acked['records'][0]['head']['receipt']['sequence']>0,'actual admission receipt visible')
        produce(h,'source-correction',a,values,ticks=150,corrects=first_source);p,rows=consume(h,'consume-correction',b,values,rows=rows)
        h.check(query(h,'projection-progress-stale',b,name='main',selection=acked['selection_digest'],expected=3)['code']=='PUBLICATION_INVENTORY_SELECTION_MISMATCH','selected projection frontier changes')
        h.check(query(h,'other-channel-progress-isolated',b,name='unrelated',selection=idle['selection_digest'])['records']==idle['records'],'unselected projection/outbox mutations do not affect exact selection')
        second=channel_publish(h,'publish-correction',b,channel_status(h,'before-second',b,'main')['channel'],p,name='main');wait_state(h,b,second['operation_id'],'ACKED','second-receipt')
        q=query(h,'current-correction',b,outcome='acked');h.check(q['selected_total']==1 and q['records'][0]['head']['corrects']==pub['operation_id'],'correct acknowledged ancestry')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:parallel=list(pool.map(lambda i:query(h,'parallel-'+str(i),b),range(8)))
        h.check(all(x['records']==parallel[0]['records'] for x in parallel),'concurrent coherent pure observations')
        term=channel_retire(h,'retire-main',b,channel_status(h,'pre-retire-main',b,'main')['channel'],name='main')
        final=query(h,'retired-main',b,lifecycle='retired');check_channel(h,final['records'][0],term['channel'])
        journal=(b/'state.journal').read_bytes();query(h,'retired-read-again',b,lifecycle='retired');h.check(journal==(b/'state.journal').read_bytes(),'retired read no revival or audit append')
        save(h,'PROGRESS',{'pending':pending,'acknowledged':acked,'correction':q,'retired':final});cd.shutdown();ad.shutdown();bd.shutdown()
    case('real_delivery_receipts_projection_progress_and_retirement',progress)

    def grants_epoch():
        a,b,c,ac,bc,cc,ad,bd,cd=topology(h,'grant-epoch')
        values={};produce(h,'g-source',a,values,ticks=12);numeric_create(h,'g-projection',b);p,rows=consume(h,'g-consume',b,values)
        created=channel_create(h,'g-create',b,p)['channel'];pub=channel_publish(h,'g-first',b,created,p);wait_state(h,b,pub['operation_id'],'ACKED','g-receipt')
        zero=query(h,'no-grant',b);auto_enable(h,'g-enable',b,channel_status(h,'g-current',b)['channel'],maximum=1,interval=10)
        enabled=query(h,'enabled-grant',b,schedule='enabled');h.check(enabled['records'][0]['grant']['used_publications']==0,'caught-up grant unspent')
        h.check(query(h,'grant-stale',b,selection=zero['selection_digest'],expected=3)['code']=='PUBLICATION_INVENTORY_SELECTION_MISMATCH','enabled grant invalidates')
        auto_pause(h,'g-pause',b,channel_status(h,'g-before-pause',b)['channel']);paused=query(h,'paused-grant',b,schedule='paused');h.check(paused['selected_total']==1,'explicit paused state')
        auto_enable(h,'g-enable-two',b,channel_status(h,'g-before-enable2',b)['channel'],maximum=1,interval=10)
        produce(h,'g-source2',a,values,ticks=3);p,rows=consume(h,'g-consume2',b,values,rows=rows);head=wait_publications(h,b,2);wait_state(h,b,head['head_operation'],'ACKED','g-automatic-receipt')
        exhausted=query(h,'exhausted-grant',b,schedule='exhausted');h.check(exhausted['records'][0]['grant']['used_publications']==1 and exhausted['records'][0]['head']['automatic'],'spent allowance and actual automatic head')
        cd.shutdown();produce(h,'g-source3',a,values,ticks=4);p,rows=consume(h,'g-consume3',b,values,rows=rows)
        pub3=channel_publish(h,'g-pending3',b,channel_status(h,'g-current3',b)['channel'],p);cancel_head(h,'g-cancel3',b,pub3['operation_id'])
        cancelled=query(h,'cancelled-head',b,outcome='cancelled');h.check(cancelled['selected_total']==1,'current terminal outcome separately observed')
        epoch=new_epoch(h,'g-epoch',b,channel_status(h,'g-before-epoch',b)['channel'],p,outcome='CANCELLED',reason='explicit replacement line')
        ep=query(h,'epoch-two',b);r=ep['records'][0];h.check(r['epoch']==2 and r['head']['corrects'] is None and r['head']['prior_epoch_terminal_operation']==pub3['operation_id'],'new original and exact terminal lineage remain distinct')
        h.check(query(h,'epoch-stale',b,selection=cancelled['selection_digest'],outcome='cancelled',expected=3)['code']=='PUBLICATION_INVENTORY_SELECTION_MISMATCH','epoch invalidates selected terminal membership')
        save(h,'GRANTS-EPOCH',{'enabled':enabled,'paused':paused,'exhausted':exhausted,'cancelled':cancelled,'epoch':ep,'epoch_operation':epoch['operation_id']});ad.shutdown();bd.shutdown()
    case('finite_grant_changes_automatic_publication_and_replacement_epoch',grants_epoch)

    def rejection_expiry():
        a,b,c,ac,bc,cc,ad,bd,cd=topology(h,'rejection',allow_output=False)
        values={};produce(h,'reject-source',a,values,ticks=19);numeric_create(h,'reject-projection',b);p,_=consume(h,'reject-consume',b,values)
        ch=channel_create(h,'reject-channel',b,p)['channel'];auto_enable(h,'reject-auto',b,ch,maximum=3,interval=10)
        h.wait('durable blocked automatic grant',lambda:channel_status(h,'reject-status',b)['channel']['automatic_grant']['state']=='BLOCKED')
        r=query(h,'blocked-rejection',b,schedule='blocked',outcome='rejected');h.check(r['selected_total']==1,'blocked and rejected are distinct selected dimensions')
        row=r['records'][0];h.check(row['head']['delivery']['last_error_code']=='AUTHORIZATION_DENIED' and row['head']['receipt'] is None,'recipient denial is not admission receipt')
        h.check(row['grant']['used_publications']==1,'failed delivery still spent published obligation allowance')
        cd.shutdown();ad.shutdown();bd.shutdown()
        state=h.runtime/'expiry';cfg=publisher_config(h,'expiry',state,free_port(),free_port())
        lines=cfg.read_text().splitlines();lines=[','.join(line.split(',')[:-1]+['500']) if line.startswith('peer=C,') else line for line in lines];cfg.write_text('\n'.join(lines)+'\n')
        d=h.start('expiry',cfg,state);m=metadata_create(h,'expire-projection',state,'meta');ch=channel_create(h,'expire-channel',state,m)['channel']
        pub=channel_publish(h,'expire-publish',state,ch,m);wait_state(h,state,pub['operation_id'],'EXPIRED','expired-obligation')
        e=query(h,'expired-head',state,outcome='expired');h.check(e['selected_total']==1 and e['records'][0]['head']['delivery']['expired_unix_ms'] is not None,'expiry actual terminal observation')
        save(h,'TERMINAL-OUTCOMES',{'rejected':r,'expired':e});d.shutdown()
    case('authenticated_rejection_blocking_and_committed_expiry',rejection_expiry)

    def principals():
        b=h.runtime/'owners';cfg=publisher_config(h,'owners',b,free_port(),free_port())
        cfg.write_text(cfg.read_text()+'local_control=65534,EVIDENCE_READ,CONSUMER,PROJECTION,SUBMIT\nevidence_read=65534,A,query/series,METADATA\nlocal_control=65533,EVIDENCE_READ,EVIDENCE_PAYLOAD,CONSUMER,PROJECTION,SUBMIT\nevidence_read=65533,A,query/series,PAYLOAD\n')
        d=h.start('owners',cfg,b);expose_control_for_uid(b)
        p1=metadata_create(h,'owner-meta',b,'input',uid=65534);p2=numeric_create(h,'owner-number',b,'input',uid=65533)
        own_create(h,'owner-first',b,p1,uid=65534);one=query(h,'owner-one',b,uid=65534)
        own_create(h,'owner-second',b,p2,uid=65533);two=query(h,'owner-two',b,uid=65533)
        h.check(query(h,'owner-hidden-append',b,uid=65534,selection=one['selection_digest'])['records']==one['records'],'other owner no count/root change')
        for val in [two['records'][0]['instance'],'41'*32]:
            hidden=query(h,'hidden-'+val[:5],b,uid=65534,instance=val);h.check(hidden['selected_total']==hidden['returned']==hidden['work']['authorized_summaries_hashed']==0,'other owner exact equals absence')
        h.check(query(h,'other-owner-selection',b,uid=65533,selection=one['selection_digest'],expected=3)['code']=='PUBLICATION_INVENTORY_SELECTION_MISMATCH','UID-bound selection')
        no_submit=candidate(h,cfg,'without-submit','owners-g2',lambda t:t.replace('local_control=65534,EVIDENCE_READ,CONSUMER,PROJECTION,SUBMIT','local_control=65534,EVIDENCE_READ,CONSUMER,PROJECTION'))
        activate(h,'revoke-submit',b,no_submit);reader=query(h,'read-without-disclosure',b,uid=65534);h.check(reader['selected_total']==1,'listing does not require disclosure permission')
        denied=run_as_uid(h,'no-mutation-authority',65534,65534,['publication-channel-create','--control',str(d.control),'--channel','forbidden','--consumer','input','--projection-instance',p1['consumer']['instance'],'--peer','C','--scope',OUTPUT_SCOPE,'--reason','not permitted'],3)
        h.check(denied['code']=='LOCAL_CONTROL_CLASS_DENIED','read does not grant publish/create')
        no_payload=candidate(h,no_submit,'without-payload','owners-g3',lambda t:t.replace('local_control=65533,EVIDENCE_READ,EVIDENCE_PAYLOAD,CONSUMER,PROJECTION,SUBMIT','local_control=65533,EVIDENCE_READ,CONSUMER,PROJECTION,SUBMIT').replace('evidence_read=65533,A,query/series,PAYLOAD','evidence_read=65533,A,query/series,METADATA'))
        activate(h,'revoke-payload',b,no_payload);h.check(query(h,'numeric-hidden',b,uid=65533)['selected_total']==0,'numeric history hidden under changed payload authority')
        script="""import socket,struct,sys,json
s=socket.socket(socket.AF_UNIX);s.settimeout(8);s.connect(sys.argv[1]);p=bytes.fromhex(sys.argv[2]);s.sendall(struct.pack('!I',len(p))+p[:2]);print('READY',flush=True);sys.stdin.readline();s.sendall(p[2:]);s.shutdown(socket.SHUT_WR)
def read(n):
 b=b''
 while len(b)<n:
  x=s.recv(n-len(b))
  if not x:raise RuntimeError('EOF')
  b+=x
 return b
r=read(struct.unpack('!I',read(4))[0]);print(json.dumps({'ok':r[4]==0,'body':json.loads(r[5:])}))
"""
        proc=subprocess.Popen(['/usr/bin/setpriv','--reuid=65534','--regid=65534','--clear-groups',sys.executable,'-c',script,str(d.control),wire().hex()],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            h.check(proc.stdout.readline().strip()=='READY','real partial principal request')
            revoked=candidate(h,no_payload,'without-projection','owners-g4',lambda t:t.replace('local_control=65534,EVIDENCE_READ,CONSUMER,PROJECTION','local_control=65534,EVIDENCE_READ,CONSUMER'))
            activate(h,'revoke-projection',b,revoked);out,err=proc.communicate('\n',timeout=10);denial=json.loads(out.splitlines()[-1])
            h.check(proc.returncode==0 and not denial['ok'] and denial['body']['code']=='LOCAL_CONTROL_CLASS_DENIED','post-decode current permission')
        finally:
            if proc.poll() is None:proc.kill();proc.wait()
        restore_owner_only_control(b);save(h,'PRINCIPALS',{'one':one,'two':two,'read_without_submit':reader,'slow_denial':denial});d.shutdown()
    case('actual_uid_isolation_read_disclosure_separation_and_live_revocation',principals)

    def capacity():
        b=h.runtime/'capacity';cfg=publisher_config(h,'capacity',b,free_port(),free_port());d=h.start('capacity',cfg,b)
        p=metadata_create(h,'capacity-projection',b,'meta')
        for i in range(64):
            name=f'retired-{i:02}';c=channel_create(h,'make-'+name,b,p,name=name)['channel'];channel_retire(h,'stop-'+name,b,c,name=name)
        for i in range(16):channel_create(h,f'active-{i:02}',b,p,name=f'active-{i:02}')
        page=query(h,'capacity-first',b,limit=32,max_bytes=60000);first=page;rows=list(page['records']);pages=1
        while page['has_more']:
            page=query(h,'capacity-next-'+str(pages),b,offset=page['next_offset'],selection=first['selection_digest'],limit=32,max_bytes=60000);rows+=page['records'];pages+=1
        h.check(len(rows)==80 and len({r['instance'] for r in rows})==80,'full 64-retired 16-active owned registry')
        h.check([r['ordinal'] for r in rows]==list(range(1,81)) and [r['name'] for r in rows]==sorted(r['name'] for r in rows),'complete stable order and ordinals')
        h.check(root_for(first,rows)==first['selection_digest'],'independent capacity selection commitment')
        h.run('capacity-compact',['compact','--control',str(d.control)]);d.shutdown();d=h.start('capacity-restart',cfg,b)
        end=query(h,'capacity-after-restart',b,offset=64,selection=first['selection_digest'],limit=32,max_bytes=60000)
        h.check(end['records']==rows[64:],'derived owner range reconstructed after compaction/restart')
        save(h,'CAPACITY',{'active':16,'retired':64,'pages':pages,'first':first,'final':end,'distinct_instances':len(rows)});d.shutdown()
    case('complete_per_owner_active_and_retired_capacity',capacity)

    def maintenance():
        a,b,c,ac,bc,cc,ad,bd,cd=topology(h,'maintenance');values={};produce(h,'m-source',a,values,ticks=125)
        numeric_create(h,'m-projection',b);p,prows=consume(h,'m-consume',b,values)
        ch=channel_create(h,'m-active',b,p)['channel'];pub=channel_publish(h,'m-publish',b,ch,p);wait_state(h,b,pub['operation_id'],'ACKED','m-receipt')
        stopped=channel_create(h,'m-retired',b,p,name='retired')['channel'];channel_retire(h,'m-retire',b,stopped,name='retired')
        first=query(h,'m-first',b);bd.shutdown()
        key=new_key(h,h.work,'channel-inventory-state');migrate(h,'m-migrate',b,key,node='B');bd=keyed_start(h,'m-keyed',bc,b,key)
        h.check(query(h,'m-migration-selection',b,selection=first['selection_digest'])['records']==first['records'],'keyed representation no semantic change')
        h.run('m-compact',['compact','--control',str(bd.control)]);bd.shutdown();h.run('m-audit',['state-auth-audit','--state',str(b),'--node','B','--state-auth-key',str(key)])
        before=inspect(h,'m-before-backup',b,key,node='B');crypt=h.work/'m-crypt.key';h.run('m-key',['backup-key-init','--output',str(crypt),'--generation','inventory-encryption'])
        identity=h.identity('B');archive=h.work/'m.nob';h.run('m-export',['backup-export','--state',str(b),'--node','B','--generation','b-g1','--state-auth-key',str(key),'--output',str(archive),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'m-restored';h.run('m-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','B','--generation','b-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'m-after-restore',restored,key,node='B');h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'exact restored logical state')
        new=h.runtime/'m-identity';new.mkdir(mode=0o700);cert=new/'cert.pem';secret=new/'key.pem';shutil.copyfile(identity.certificate,cert);shutil.copyfile(identity.private_key,secret);secret.chmod(0o600)
        moved=candidate(h,bc,'m-moved','m-moved-g2',lambda t:t.replace('state='+str(b),'state='+str(restored)).replace(str(identity.certificate),str(cert)).replace(str(identity.private_key),str(secret)))
        h.run('m-relocate',['state-relocate','--state',str(restored),'--node','B','--candidate',str(moved),'--reason','explicit channel owner-path move','--state-auth-key',str(key)])
        identity.certificate.unlink();identity.private_key.unlink();bd=keyed_start(h,'m-moved',moved,restored,key)
        h.check(query(h,'m-old-selection',restored,selection=first['selection_digest'],expected=3)['code']=='PUBLICATION_INVENTORY_SELECTION_MISMATCH','relocated configuration requires reselection')
        final=query(h,'m-new-selection',restored);h.check(final['records']==first['records'],'channel/head/grant metadata survives relocation unchanged')
        produce(h,'m-new-source',a,values,ticks=7);p,prows=consume(h,'m-new-consume',restored,values,rows=prows)
        nextpub=channel_publish(h,'m-new-publication',restored,channel_status(h,'m-before-next',restored)['channel'],p);wait_state(h,restored,nextpub['operation_id'],'ACKED','m-next-ack')
        continued=query(h,'m-continued',restored,name='channel');h.check(continued['records'][0]['head']['corrects']==pub['operation_id'],'actual correction delivery continues after restore')
        save(h,'MAINTENANCE',{'before':first,'after':final,'continued':continued,'logical_state_equal_at_restore':True,'old_identity_files_removed':True});cd.shutdown();ad.shutdown();bd.shutdown()

    def drain():
        b=h.runtime/'drain';cfg=publisher_config(h,'drain',b,free_port(),free_port());d=h.start('drain',cfg,b)
        p=metadata_create(h,'d-projection',b,'meta');ch=channel_create(h,'d-channel',b,p)['channel']
        h.run('d-quiesce',['quiesce','--control',str(d.control),'--reason','inspection only']);before=(b/'state.journal').read_bytes();q=query(h,'d-quiesced',b);h.check(before==(b/'state.journal').read_bytes(),'quiesced listing observational')
        h.run('d-resume',['resume','--control',str(d.control),'--reason','drain next']);channel_publish(h,'d-pending',b,ch,p)
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future=pool.submit(h.run,'d-start',['drain-shutdown','--control',str(d.control),'--reason','actual pending channel drain','--drain-deadline-ms','1500'])
            h.wait('draining',lambda:h.status('d-health',b,logical_digest=False)['lifecycle']['draining'])
            during=query(h,'d-inventory',b);h.check(during['selected_total']==1 and d.process.poll() is None,'actual nonempty drain permits listing')
            done=future.result()
        d.process.wait(timeout=5);save(h,'DRAIN',{'quiesced':q,'draining':during,'drain':done});d.shutdown()
    case('observational_listing_during_quiescence_and_nonempty_drain',drain)
    case('authenticated_compaction_encrypted_restore_relocation_and_publication',maintenance)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);begin=time.time();ok=False
    try:
        cases(h,set(a.case) if a.case else None)
        if not h.cases:raise ValueError('no selected cases')
        ok=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {e}',file=sys.stderr)
    finally:
        h.cleanup();s={'format':'NATRAV_PUBLICATION_INVENTORY_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-begin}
        for n,v in [('SUMMARY',s),('CASES',h.cases),('COMMANDS',h.commands)]:save(h,n,v)
        print(json.dumps(s),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
