#!/usr/bin/env python3
"""Exact terminal recipient-view lifecycle on owned processes and local test peers."""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, signal, socket, struct, subprocess, time
from pathlib import Path
from run_persistent import Harness, operation, raw_control, receive_exact
from run_subscribed_source_views import setup, emit, materialize, SCOPE, TARGET, fields
from run_import_automation import auto, until, allrows
from run_import_review import review, retry, denied_setup, frames
from run_source_subscriptions import command, ack
from run_local_evidence import author
from run_local_administration import run_as_uid, expose_control_for_uid
from run_live_configuration import candidate, activate, wait_state
from run_scoped_reads import query
from run_state_authentication import new_key, migrate, start as start_keyed, inspect, checksum_frame


def status(h,label,c,view='temps',uid=None,expected=0):
    args=['source-view-retirement-status','--control',str(c/'control.sock'),'--view',view,'--deadline-ms','5000']
    return h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)


def retire_args(c,s,reason='explicit terminal view adoption',deferred='require-empty'):
    return ['source-view-retire','--control',str(c/'control.sock'),'--view',s['view'],
            '--expected-revision',str(s['revision']),'--view-digest',s['view_digest'],
            '--configuration-digest',s['configuration_digest'],'--final-state-digest',s['final_state_digest'],
            '--deferred',deferred,'--reason',reason,'--deadline-ms','5000']


def retire(h,label,c,s,uid=None,expected=0,**kw):
    args=retire_args(c,s,**kw)
    return h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)


def wire_retire(s,reason='independent retirement',disposition='REQUIRE_EMPTY'):
    text=lambda t:struct.pack('!H',len(t))+t.encode()
    return b'NOC1\x16NIR3\x06'+text(s['view'])+struct.pack('!Q',s['revision'])+text(reason)+text(disposition)+b''.join(bytes.fromhex(s[k]) for k in ('view_digest','configuration_digest','final_state_digest'))


def durable(x):
    return {k:v for k,v in x.items() if k!='principal_pid'}

def run_cases(h,selected):
    def case(name,fn):
        if selected is None or name in selected:h.case(name,fn)

    def direct():
        a,c,ac,cc,ad,cd,s=setup(h,'direct')
        first,s,row=emit(h,'direct-first',a,c,s,ticks=100)
        initial=status(h,'empty-selector',c)
        h.check(initial['revision']==0 and initial['retained_records']==0,'never-enabled view can be explicitly selected')
        original=materialize(h,'direct-import',c,row)
        h.check(retire(h,'stale-direct-admission',c,initial,expected=3)['code']=='SOURCE_VIEW_RETIREMENT_CONFLICT','direct import invalidates final account without a schedule revision')
        current=status(h,'current-selector',c)
        h.check(current['revision']==0 and current['retained_records']==1 and current['final_state_digest']!=initial['final_state_digest'],'retained evidence is part of terminal commitment')
        for field in ('view_digest','configuration_digest','final_state_digest'):
            bad=dict(current,**{field:'01'*32})
            h.check(retire(h,'wrong-'+field,c,bad,expected=3)['code']=='SOURCE_VIEW_RETIREMENT_CONFLICT','exact '+field+' required')
        h.check(retire(h,'wrong-revision',c,dict(current,revision=1),expected=3)['code']=='SOURCE_VIEW_RETIREMENT_CONFLICT','exact scheduling/decision revision required')
        request=wire_retire(current)
        for name,raw in [('trailing',request+b'x'),('short',request[:-1]),('version',request.replace(b'NIR3',b'NIR1'))]:
            ok,error=raw_control(c/'control.sock',raw);h.check(not ok,'strict retirement protocol '+name)
        ok,done=raw_control(c/'control.sock',request)
        h.check(ok and done['status']=='RETIRED' and done['retirement']['actor_pid']==os.getpid(),'independent wire records actual peer credentials')
        size=(c/'state.journal').stat().st_size
        ok,again=raw_control(c/'control.sock',request)
        h.check(ok and again['status']=='ALREADY_RETIRED' and (c/'state.journal').stat().st_size==size,'exact retry does not append')
        h.check(retire(h,'changed-reason',c,current,expected=3)['code']=='SOURCE_VIEW_RETIREMENT_CONFLICT','different terminal intent conflicts')
        second,s,row2=emit(h,'direct-later',a,c,s,ticks=25)
        for name,r in [('old-duplicate',row),('new-import',row2)]:
            h.check(materialize(h,name,c,r,expected=3)['code']=='SOURCE_VIEW_RETIRED','direct import is closed including old idempotent commands')
        h.check(auto(h,'retired-enable',c,'enable',previous={'revision':1},expected=3)['code']=='SOURCE_VIEW_RETIRED','new automatic grant cannot reopen')
        h.check(auto(h,'retired-pause',c,'pause',previous={'revision':1},expected=3)['code']=='SOURCE_VIEW_RETIRED','old mutation cannot change terminal account')
        rows=allrows(h,'retained-readable',c)
        h.check(len(rows)==1 and rows[0]['operation_id']==original['operation_id'],'separate read authority survives')
        page=review(h,'retirement-review',c)
        h.check(len(page['events'])==1 and page['events'][0]['action']=='RETIRE','terminal event participates in immutable review prefix')
        h.run('direct-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown();cd=h.start('direct-restart',cc,c)
        recovered=status(h,'direct-reconstructed',c)
        h.check(recovered['retirement']==done['retirement'] and recovered['records_digest']==done['records_digest'],'exact terminal account survives checkpoint')
        # Ordinary peer authority cannot counterfeit imported records into a reserved target.
        op=operation('after-retire-forged-target')
        h.run('forged-target',['submit','--control',str(a/'control.sock'),'--node','A','--peer','C','--scope',TARGET,'--operation',op,'--payload-text','not imported'])
        h.wait('retired target remains reserved',lambda:any(e.get('last_error_code')=='SOURCE_VIEW_DOMAIN_RESERVED' for e in h.status('target-outbox',a)['outbox']['entries']))
        h.check(len(allrows(h,'still-one',c))==1,'retirement does not release target namespace')
        (h.output/'DIRECT.json').write_text(json.dumps({'before':current,'retired':done,'restored':recovered},indent=2)+'\n')
        cd.shutdown();ad.shutdown()
    case('unscheduled_direct_import_exact_commitments_and_reserved_target',direct)

    def fair():
        a,c,ac,cc,ad,cd,s=setup(h,'fair',delegates=True)
        expose_control_for_uid(c)
        auto(h,'fair-enable',c,'enable',previous=auto(h,'fair-initial',c),imports=16)
        auto(h,'fair-other-enable',c,'enable',previous=auto(h,'fair-other-initial',c,view='delegated',uid=65534),view='delegated',uid=65534,imports=3)
        first,s,row=emit(h,'fair-first',a,c,s,ticks=100)
        before=until(h,'fair-one',c,lambda v:v['imports']==1)
        until(h,'fair-other-one',c,lambda v:v['imports']==1,view='delegated',uid=65534)
        old=status(h,'fair-old',c)
        second,s,row2=emit(h,'fair-second',a,c,s,ticks=25)
        until(h,'fair-two',c,lambda v:v['imports']==2)
        h.check(retire(h,'worker-won-selector',c,old,expected=3)['code']=='SOURCE_VIEW_RETIREMENT_CONFLICT','completed worker changes exact retirement selection')
        current=status(h,'fair-current',c)
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda i:retire(h,'concurrent-retire-'+str(i),c,current),range(8)))
        h.check(sum(r['status']=='RETIRED' for r in results)==1 and sum(r['status']=='ALREADY_RETIRED' for r in results)==7,'one retirement commit and seven exact observations')
        retired=next(r for r in results if r['status']=='RETIRED')
        h.check(retired['retirement']['previous_schedule_state']=='ENABLED','enabled grant stops atomically')
        final=auto(h,'fair-frozen',c)
        third,s,row3=emit(h,'fair-third',a,c,s,ticks=5)
        healthy=until(h,'other-keeps-progress',c,lambda v:v['state']=='EXHAUSTED',view='delegated',uid=65534)
        time.sleep(.15)
        frozen=auto(h,'fair-no-work',c)
        h.check(durable(frozen)==durable(final) and healthy['imports']==3,'retired view does not progress while independent manager completes')
        h.check(len(allrows(h,'fair-retained',c))==2,'no new import or refund in terminal view')
        size=(c/'state.journal').stat().st_size;status(h,'fair-observational',c);review(h,'fair-review',c)
        h.check((c/'state.journal').stat().st_size==size,'retirement status/review do not append')
        (h.output/'FAIRNESS.json').write_text(json.dumps({'terminal':retired,'frozen':frozen,'healthy':healthy},indent=2)+'\n')
        cd.shutdown();ad.shutdown()
    case('enabled_worker_exact_race_concurrent_retirement_and_fair_progress',fair)

    def deferred():
        a,c,ac,cc,cc2,ad,cd,sub,src,parent_decision,stopped=denied_setup(h,'deferred')
        activate(h,'deferred-pin',c,cc2)
        auto(h,'deferred-enable',c,'enable',previous=stopped,imports=8)
        child=author(h,'deferred-child',a,ticks=175,parent=src['operation_id'])
        issue=command(h,'deferred-child-issue',a,'step',grant='g2',previous=sub);sub=ack(h,'deferred-child-ack',a,issue,grant='g2')
        waiting=until(h,'one-dependency',c,lambda v:len(v['deferred'])==1)
        picked=status(h,'deferred-picked',c)
        h.check(retire(h,'no-disposition',c,picked,expected=3)['code']=='SOURCE_VIEW_DEFERRED_PENDING','unresolved work cannot silently disappear')
        done=retire(h,'retain-unprocessed',c,picked,deferred='retain')
        final=auto(h,'deferred-frozen',c)
        for key in ['deferred','imports','decisions','manual_retries','generation','next_position']:
            h.check(final[key]==waiting[key],'retirement preserves '+key)
        h.check(final['retirement']['disposition']=='RETAINED_UNPROCESSED','retention is not an imported or acknowledged disposition')
        p=review(h,'deferred-review',c)
        h.check(retry(h,'retired-manual-retry',c,p,parent_decision,expected=3)['code']=='SOURCE_VIEW_RETIRED','selective retry cannot restore progress')
        h.check(materialize(h,'retired-parent-direct',c,parent_decision['outer_operation'],expected=3)['code']=='SOURCE_VIEW_RETIRED','direct parent cannot wake retired dependency')
        h.run('deferred-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown();cd=h.start('deferred-checkpoint',cc2,c)
        h.check(durable(auto(h,'deferred-restored',c))==durable(final),'original missing-parent decision and terminal disposition reconstruct')
        (h.output/'DEFERRED.json').write_text(json.dumps({'before':waiting,'terminal':done,'after':final},indent=2)+'\n')
        cd.shutdown();ad.shutdown()
    case('explicit_deferred_disposition_and_all_import_paths_closed',deferred)

    def principals():
        a,c,ac,cc,ad,cd,s=setup(h,'owners',delegates=True)
        expose_control_for_uid(c)
        own=status(h,'delegated-status',c,view='delegated',uid=65534)
        h.check(status(h,'foreign-owner',c,view='delegated',expected=3)['code']=='SOURCE_VIEW_RETIREMENT_DENIED','daemon UID not an owner bypass')
        h.check(status(h,'reader-not-manager',c,view='delegated',uid=65533,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','metadata class does not imply retirement')
        done=retire(h,'delegated-retire',c,own,uid=65534)
        h.check(done['retirement']['actor_uid']==65534 and 'payload' not in json.dumps(done).replace('retained_payload_bytes',''),'actual owner and no payload reply')
        # Slow connection must be checked against post-read policy, not its opening policy.
        old=status(h,'slow-selector',c)
        wire=wire_retire(old,'slow retirement after revocation')
        sock=socket.socket(socket.AF_UNIX);sock.settimeout(5);sock.connect(str(c/'control.sock'))
        sock.sendall(struct.pack('!I',len(wire))+wire[:1])
        def remove(t):
            lines=[]
            for line in t.splitlines():
                if line.startswith('source_view=temps,') or line.startswith('source_view_binding=temps,'):continue
                if line.startswith(f'local_control={os.geteuid()},'):line=line.replace(',SOURCE_IMPORT','')
                lines.append(line)
            return '\n'.join(lines)+'\n'
        revoked=candidate(h,cc,'owner-revoked','owner-revoked-g1',remove)
        activate(h,'owner-revoke',c,revoked)
        sock.sendall(wire[1:]);sock.shutdown(socket.SHUT_WR)
        reply=receive_exact(sock,struct.unpack('!I',receive_exact(sock,4))[0]);sock.close()
        h.check(reply[4]!=0 and json.loads(reply[5:])['code']=='LOCAL_CONTROL_CLASS_DENIED','connected request cannot retain revoked administrative class')
        # Restore only the administrative class, NOT the view or provider import authority.
        anchor_rule=next(l for l in cc.read_text().splitlines() if l.startswith('source_view=temps,')).replace('source_view=temps,','source_view=admin-anchor,').replace(TARGET,'subscribed/admin-anchor')
        anchor_pin=next(l for l in cc.read_text().splitlines() if l.startswith('source_view_binding=temps,')).replace('source_view_binding=temps,','source_view_binding=admin-anchor,')
        restored=candidate(h,revoked,'owner-admin-only','owner-admin-only-g1',lambda t:t.replace(f'local_control={os.geteuid()},',f'local_control={os.geteuid()},SOURCE_IMPORT,')+anchor_rule+'\n'+anchor_pin+'\n')
        activate(h,'owner-admin-only',c,restored)
        selected=status(h,'historical-owner-can-stop',c)
        h.check(selected['view_digest']==old['view_digest'],'historical immutable view can be selected without processing permission')
        retired=retire(h,'historical-view-retire',c,selected)
        h.check(retired['status']=='RETIRED','removing a view does not prevent explicit administrative retirement')
        back=candidate(h,cc,'restore-old-rules','restore-old-rules-g1',lambda t:t)
        activate(h,'restore-old-rules',c,back)
        first,s,row=emit(h,'after-old-rule-return',a,c,s,ticks=50)
        h.check(materialize(h,'old-policy-no-revive',c,row,expected=3)['code']=='SOURCE_VIEW_RETIRED','accepted old policy does not resurrect terminal view')
        # Actual accepted rollback also preserves terminal state.
        original_generation=next(l.split('=',1)[1] for l in cc.read_text().splitlines() if l.startswith('runtime_generation='))
        h.run('rollback-original-config',['config-rollback','--control',str(c/'control.sock'),'--generation',original_generation,'--reason','test rollback does not resurrect'])
        h.check(auto(h,'rollback-enable-denied',c,'enable',previous={'revision':1},expected=3)['code']=='SOURCE_VIEW_RETIRED','configuration rollback is not lifecycle rollback')
        cd.shutdown();cd=h.start('owner-restart',cc,c)
        h.check(status(h,'owner-restart-terminal',c)['lifecycle']=='RETIRED','original seed cannot bypass journal authority')
        cd.shutdown();ad.shutdown()
    case('real_principals_revocation_removed_policy_and_rollback',principals)

    def kills():
        for point in ('BEFORE','AFTER'):
            a,c,ac,cc,ad,cd,s=setup(h,'kill-'+point)
            _,s,row=emit(h,'kill-source-'+point,a,c,s,ticks=7)
            materialize(h,'kill-materialize-'+point,c,row)
            chosen=status(h,'kill-select-'+point,c);original=(c/'state.journal').read_bytes();cd.shutdown()
            cd=h.start('kill-retire-'+point,cc,c,environment={f'NATRAV_OVERLAY_TEST_VIEW_RETIRE_{point}_COMMIT_MS':'1500'})
            proc=subprocess.Popen([str(h.binary),*retire_args(c,chosen)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            if point=='AFTER':h.wait('retirement commit visible',lambda:b'NIE3' in (c/'state.journal').read_bytes(),5)
            else:time.sleep(.3)
            cd.kill();proc.communicate(timeout=8)
            raw=(c/'state.journal').read_bytes()
            h.check((b'NIE3' in raw)==(point=='AFTER'),'actual pre/post synchronized terminal publication')
            cd=h.start('kill-recover-'+point,cc,c)
            recovered=status(h,'kill-status-'+point,c)
            h.check(recovered['lifecycle']==('RETIRED' if point=='AFTER' else 'ACTIVE'),'restart terminal state matches commit')
            answer=retire(h,'kill-retry-'+point,c,chosen)
            h.check(answer['status']==('ALREADY_RETIRED' if point=='AFTER' else 'RETIRED'),'lost response does not multiply terminal events')
            h.check(len(allrows(h,'kill-retained-'+point,c))==1,'no lost evidence or artificial receipt')
            cd.shutdown();ad.shutdown()
    case('real_pre_post_commit_kills_and_exact_retry',kills)

    def corruption():
        a,c,ac,cc,ad,cd,s=setup(h,'corruption')
        _,s,r1=emit(h,'corrupt-source-1',a,c,s,ticks=77)
        _,s,r2=emit(h,'corrupt-source-2',a,c,s,ticks=3)
        materialize(h,'corrupt-import-1',c,r1)
        chosen=status(h,'corrupt-select',c);retire(h,'corrupt-retire',c,chosen);cd.shutdown()
        original=(c/'state.journal').read_bytes();fs=frames(original);idx=next(i for i,f in enumerate(fs) if b'NIE3' in f)
        fake=fs.copy();fake[idx]=checksum_frame(fake[idx].replace(bytes.fromhex(chosen['final_state_digest']),b'\x42'*32))
        (c/'state.journal').write_bytes(b''.join(fake))
        h.run('forged-final-account',['inspect','--state',str(c),'--node','C'],expected=3)
        # Build one legitimate direct-admission frame in a disposable alternate
        # history, then place it after the valid terminal event. Never external input.
        prior=b''.join(fs[:idx]);(c/'state.journal').write_bytes(prior)
        cd=h.start('branch-without-retire',cc,c);materialize(h,'branch-import-2',c,r2);cd.shutdown()
        extra=frames((c/'state.journal').read_bytes())[len(frames(prior)):]
        h.check(any(b'NSV1' in f for f in extra),'actual valid direct import captured')
        (c/'state.journal').write_bytes(original+b''.join(extra))
        error=h.run('post-terminal-direct-replay',['inspect','--state',str(c),'--node','C'],expected=3)
        h.check(error['code']=='JOURNAL_CORRUPT' and 'SOURCE_VIEW_RETIRED' in error['detail'],'ordinary journal cannot append a valid direct import after retirement')
        (c/'state.journal').write_bytes(original);cd=h.start('valid-terminal-restored',cc,c)
        h.run('corruption-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown()
        checkpoint=(c/'state.journal').read_bytes();f=frames(checkpoint)[0]
        h.check(b'NIE3' in f,'checkpoint retains actual terminal event')
        bad=f.replace(bytes.fromhex(chosen['final_state_digest']),b'\x43'*32)
        # Repair logical and outer hashes to reach semantic validation rather than
        # claiming that a plain checksum mismatch exercises retirement invariants.
        pos=bad.index(b'NLS2');logical=bad[pos:-32]
        oldlogical=f[f.index(b'NLS2'):-32]
        domain=b'NATRAV_OVERLAY_LOGICAL_STATE_V2\0'
        oldhash=hashlib.sha256(domain+oldlogical).digest()
        h.check(oldhash in bad[:pos],'independent checkpoint logical commitment located')
        bad=bad[:pos].replace(oldhash,hashlib.sha256(domain+logical).digest())+bad[pos:]
        (c/'state.journal').write_bytes(checksum_frame(bad))
        error=h.run('checkpoint-forged-final-account',['inspect','--state',str(c),'--node','C'],expected=3)
        h.check(error['code']=='JOURNAL_CORRUPT' and 'SOURCE_VIEW_RETIREMENT_CONFLICT' in error['detail'],'checkpoint semantic terminal commitment enforced')
        (c/'state.journal').write_bytes(checkpoint)
        h.check(h.run('valid-checkpoint',['inspect','--state',str(c),'--node','C'])['import_automation'][0]['state']=='RETIRED','valid checkpoint still readable')
        ad.shutdown()
    case('semantic_journal_and_checkpoint_terminal_validation',corruption)

    def maintenance():
        a,c,ac,cc,ad,cd,s=setup(h,'maintenance')
        _,s,row=emit(h,'maint-original',a,c,s,ticks=125)
        auto(h,'maint-enable',c,'enable',previous=auto(h,'maint-start',c),imports=1)
        exhausted=until(h,'maint-exhausted',c,lambda v:v['state']=='EXHAUSTED')
        chosen=status(h,'maint-select',c);cd.shutdown()
        key=new_key(h,h.work,'view-retire-g1');migrate(h,'retire-migrate',c,key,node='C')
        cd=start_keyed(h,'retire-keyed',cc,c,key)
        retired=retire(h,'keyed-retire',c,chosen)
        h.run('retire-keyed-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown()
        h.run('retire-auth-audit',['state-auth-audit','--state',str(c),'--node','C','--state-auth-key',str(key)])
        before=inspect(h,'retire-pre-backup',c,key,node='C')
        crypt=h.work/'retire.key';h.run('retire-backup-key',['backup-key-init','--output',str(crypt),'--generation','retire-backup'])
        ident=h.identity('C');archive=h.work/'retire.nob'
        h.run('retire-export',['backup-export','--state',str(c),'--node','C','--generation','c-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'view-retired-restore'
        h.run('retire-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','C','--generation','c-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'retire-restored-digest',restored,key,node='C')
        h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'restore logical equality including frozen grant and terminal account')
        moved=candidate(h,cc,'retire-moved','retire-moved-g1',lambda t:t.replace('state='+str(c),'state='+str(restored)))
        h.run('retire-relocate',['state-relocate','--state',str(restored),'--node','C','--candidate',str(moved),'--reason','owned state relocation','--state-auth-key',str(key)])
        cd=start_keyed(h,'retire-relocated-node',moved,restored,key)
        again=retire(h,'retire-idempotent-relocated',restored,chosen)
        h.check(again['status']=='ALREADY_RETIRED' and again['retirement']==retired['retirement'],'exact terminal request survives explicit relocation')
        _,s,row2=emit(h,'retire-future-source',a,restored,s,ticks=50)
        h.check(materialize(h,'retired-after-restore',restored,row2,expected=3)['code']=='SOURCE_VIEW_RETIRED','new input cannot reopen a restored retired view')
        rows=allrows(h,'retired-data-readable',restored)
        h.check(len(rows)==1,'existing evidence retains read authority')
        from run_numeric_projection import call,consume
        call(h,'retired-result-create',restored,'create','read-retired',definition='NUMERIC_SUMMARY_V1',issuer='A',scope=TARGET,unit='degC',scale=2,reason='explicit processing of retained evidence')
        result,_=consume(h,'retired-result-consume',restored,{r['operation_id']:bytes.fromhex(r['payload_hex']) for r in rows},name='read-retired')
        h.check(result['consumer']['projection']['result']['numeric']['sum_ticks']=='125','retirement is not evidence deletion or read revocation')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'before':before['storage']['logical_state_digest'],'restored':after['storage']['logical_state_digest'],'retirement':again,'numeric_sum':'125'},indent=2)+'\n')
        cd.shutdown();ad.shutdown()
    case('keyed_audit_encrypted_restore_relocation_and_retained_computation',maintenance)

    def generations():
        a,c,ac,cc,ad,cd,s=setup(h,'grants')
        state=auto(h,'grant-empty',c)
        for i in range(32):
            state=auto(h,f'enable-{i}',c,'enable',previous=state,imports=1,decisions=1)
            state=auto(h,f'pause-{i}',c,'pause',previous=state)
        h.check(auto(h,'no-33rd-grant',c,'enable',previous=state,expected=3)['code']=='IMPORT_AUTO_GRANT_LIMIT','existing finite grant cap unchanged')
        chosen=status(h,'finite-retire-select',c);retired=retire(h,'finite-retire',c,chosen)
        h.check(retired['retirement']['previous_schedule_state']=='PAUSED' and retired['revision']==65,'retirement does not require new automatic allowance')
        h.run('finite-retired-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown();cd=h.start('finite-retired-restart',cc,c)
        h.check(auto(h,'finite-retired-after',c)['generation']==32,'retirement refunds no grant generations')
        # A blocked schedule also has an administrative stopping path.
        cd.shutdown();ad.shutdown()
        a,c,ac,cc,ad,cd,s=setup(h,'blocked',records=1)
        auto(h,'blocked-enable',c,'enable',previous=auto(h,'blocked-empty',c),imports=8)
        _,s,row=emit(h,'blocked-one',a,c,s,ticks=1);_,s,row=emit(h,'blocked-two',a,c,s,ticks=2)
        blocked=until(h,'blocked-full',c,lambda v:v['state']=='BLOCKED')
        retired=retire(h,'blocked-retire',c,status(h,'blocked-select',c))
        final=auto(h,'blocked-final',c)
        h.check(retired['retirement']['previous_schedule_state']=='BLOCKED' and final['imports']==blocked['imports'],'terminal operation preserves blocked work and usage')
        cd.shutdown();ad.shutdown()
    case('paused_blocked_and_exhausted_grant_retirement_without_refund',generations)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    try:run_cases(h,set(a.case) if a.case else None);ok=True
    except BaseException as exc:(h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(f'FAIL: {type(exc).__name__}: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup();s={'format':'NATRAV_OVERLAY_VIEW_RETIREMENT_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,data in [('SUMMARY',s),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
        print(json.dumps(s),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
