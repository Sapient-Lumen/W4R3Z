#!/usr/bin/env python3
"""Generation-stable local controls using owned nodes and real kernel UIDs.
The independent client sends one bounded local request. No remote targets,
credential impersonation fields, or scanning are part of this regression.
"""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import select
import socket
import struct
import subprocess
import sys
import time

from run_persistent import Harness, free_port, operation, raw_control
from run_local_administration import v8_config, expose_control_for_uid, restore_owner_only_control, run_as_uid
from run_live_configuration import candidate, activate, rollback
from run_outbox_inspection import query

UID=65534
READER_UID=65533


def text(value: str) -> bytes:
    raw=value.encode('ascii'); return struct.pack('!H',len(raw))+raw


def packet(kind: int, *parts: bytes) -> bytes:
    return b'NOC1'+bytes([kind])+b''.join(parts)


def client_mode(control: str, payload: str, split: str) -> None:
    # This process changes identity before connect through setpriv, so the
    # server obtains the real UID/GID/PID from SO_PEERCRED.
    data=bytes.fromhex(payload)
    with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as s:
        s.settimeout(12); s.connect(control)
        framed=struct.pack('!I',len(data))+data
        if split=='yes':
            s.sendall(framed[:-1]); print('PARTIAL',flush=True); sys.stdin.readline(); s.sendall(framed[-1:])
        else:
            s.sendall(framed); print('SENT',flush=True)
        s.shutdown(socket.SHUT_WR)
        def receive(n: int) -> bytes:
            b=b''
            while len(b)<n:
                x=s.recv(n-len(b))
                if not x: raise AssertionError('control EOF without a complete response')
                b+=x
            return b
        n=struct.unpack('!I',receive(4))[0]
        if not 5<=n<=65536: raise AssertionError('unbounded response')
        response=receive(n)
        if response[:4]!=b'NOR1' or response[4] not in (0,1): raise AssertionError('response envelope')
        print(json.dumps({'wire_ok':response[4]==0,'response':json.loads(response[5:])}),flush=True)


class Client:
    def __init__(self,h: Harness,d,label: str,data: bytes,uid=UID,split=True):
        self.h,self.label,self.data=h,label,data
        self.released = not split
        self.before=d.stderr_path.read_text().count('CONTROL_READ_READY '+str(uid)+'\n')
        self.p=subprocess.Popen(['/usr/bin/setpriv',f'--reuid={uid}',f'--regid={uid}','--clear-groups',sys.executable,
            str(Path(__file__).resolve()),'--client',str(d.control),data.hex(),'yes' if split else 'no'],
            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,
            env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
        ready,_,_=select.select([self.p.stdout],[],[],8)
        h.check(bool(ready),'independent local client starts within bound')
        line=self.p.stdout.readline().strip()
        h.check(line==('PARTIAL' if split else 'SENT'),f'{label} client boundary: {line}')
        h.wait(label+' actually entered server read',lambda:d.stderr_path.read_text().count('CONTROL_READ_READY '+str(uid)+'\n')>self.before)
        self.started=time.monotonic()
    def release(self):
        if not self.released:
            self.p.stdin.write('\n'); self.p.stdin.flush(); self.released = True
    def finish(self):
        out,err=self.p.communicate(None if self.released else '\n',timeout=15)
        self.h.commands.append({'label':self.label,'kind':'independent_local_control','payload_sha256':hashlib.sha256(self.data).hexdigest(),
            'returncode':self.p.returncode,'stdout':out,'stderr':err,'elapsed_seconds':time.monotonic()-self.started})
        self.h.check(self.p.returncode==0,f'{self.label}: local client failed: {out!r} {err!r}')
        parsed=json.loads(out.strip().splitlines()[-1]); result=parsed['response']
        self.h.check(parsed['wire_ok']==result.get('ok'),self.label+' wire and JSON status agree')
        return result
    def close(self):
        if self.p.poll() is None:self.p.kill();self.p.wait(timeout=5)


def setup(h: Harness,name: str,classes='ALL',extra_env=None):
    state=h.runtime/name
    ports=[]
    while len(ports)<2:
        p=free_port()
        if p not in ports:ports.append(p)
    conf=v8_config(h,name,'A',state,ports[0],name+'-g1',
        [(os.geteuid(),['ALL']),(UID,classes.split(',')),(READER_UID,['INSPECT'])],
        peers=[('B',ports[1])],deadline_ms=3000)
    conf.write_text(conf.read_text().replace(',75,150,100,60000', ',1000,2000,100,600000'))
    env={'NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER':'1'};env.update(extra_env or {})
    d=h.start(name,conf,state,env);expose_control_for_uid(state)
    return state,conf,d


def grants(h: Harness,base: Path,state: Path,label: str,classes: str,activate_now=True):
    def change(s):
        return '\n'.join(f'local_control={UID},{classes}' if x.startswith(f'local_control={UID},') else x for x in s.splitlines())+'\n'
    c=candidate(h,base,label,label+'-g',change)
    if activate_now:activate(h,label,state,c)
    return c


def offline(h,label,state):
    return h.run(label,['inspect','--state',str(state),'--node','A'])


def selected_events(result,uid=UID):
    return [e for e in result['local_control']['entries'] if e['uid']==uid]


def all_cases(h: Harness,only):
    def case(name,f):
        if not only or name in only:h.case(name,f)

    def revoke_legacy():
        a,conf,d=setup(h,'legacy-revoke')
        op=operation('legacy-preserved')
        h.run('preserved-pending',['submit','--control',str(d.control),'--node','A','--peer','B','--scope','admin/test','--operation',op,'--payload-text','kept'])
        replacement=candidate(h,conf,'not-authorized-candidate','never-activated')
        reason=text('owned regression')
        requests=[('WAKE',packet(3,text('B'))),('STATUS',packet(2)),('COMPACT',packet(8)),
            ('CANCEL',packet(6,bytes.fromhex(op),reason)),('RETRY',packet(9,bytes.fromhex(op),reason)),
            ('REBIND',packet(5,bytes.fromhex(op),text('b-g1'),reason)),
            ('ACTION_CANCEL',packet(7,bytes.fromhex(operation('not-admitted-action')),reason)),
            ('QUIESCE',packet(12,reason)),('RESUME',packet(13,reason)),
            ('DRAIN_SHUTDOWN',packet(14,struct.pack('!I',100),reason)),('SHUTDOWN',packet(4)),
            ('CONFIG_ACTIVATE',packet(10,text(str(replacement)),reason)),
            ('CONFIG_ROLLBACK',packet(11,text('legacy-revoke-g1'),reason))]
        decisions=[]
        for i,(command,data) in enumerate(requests):
            permitted=grants(h,conf,a,f'permit-{i}','ALL')
            c=Client(h,d,'revoked-'+command,data)
            try:
                current=grants(h,permitted,a,f'revoke-{i}','SUBMIT' if command=='STATUS' else 'INSPECT')
                denied=c.finish()
                h.check(denied.get('code')=='LOCAL_CONTROL_CLASS_DENIED',command+' uses current post-decode permission')
                status=h.status('still-running-'+str(i),a)
                h.check(status['lifecycle']['mode']=='RUNNING',command+' did not change lifecycle')
                decisions.append({'command':command,'request_id':denied['request_id'],'generation':f'revoke-{i}-g','response':denied})
                conf=current
            finally:c.close()
        h.check(query(h,'pending-after-denials',a,op=op)['records'][0]['status']=='PENDING','denied maintenance leaves pending record intact')
        restore_owner_only_control(a);d.shutdown();state=offline(h,'denial-audit',a)
        events=selected_events(state)
        history=state['runtime_configuration']['events']
        for expected in decisions:
            matches=[e for e in events if e['request_id']==expected['request_id'] and e['decision']=='DENIED']
            h.check(len(matches)==1,'one durable denial per rejected request')
            event=matches[0]
            h.check(history[event['configuration_event']-1]['generation']==expected['generation'],'denial names actual post-decode generation')
        h.check(not any(e['generation']=='never-activated' for e in history),'revoked config request creates no candidate event')
        (h.output/'LEGACY-REVOCATION.json').write_text(json.dumps(decisions,indent=2)+'\n')
    case('post_decode_revocation_for_thirteen_legacy_controls',revoke_legacy)

    def grant_and_attribution():
        a,conf,d=setup(h,'current-attribution','INSPECT')
        c=Client(h,d,'newly-granted-wake',packet(3,text('B')))
        try:
            newer=grants(h,conf,a,'grant-after-read','INSPECT,MAINTENANCE')
            response=c.finish();h.check(response.get('ok') is True,'new permission after connection is usable')
        finally:c.close()
        op=operation('attribution-cancel')
        h.run('attribution-submit',['submit','--control',str(d.control),'--node','A','--peer','B','--scope','admin/test','--operation',op,'--payload-text','cancel exactly'])
        c=Client(h,d,'cancel-current-generation',packet(6,bytes.fromhex(op),text('current accepted policy')))
        try:
            latest=candidate(h,newer,'unrelated-generation','attribution-g3')
            activate(h,'unrelated-activate',a,latest)
            cancelled=c.finish();h.check(cancelled.get('status')=='CANCELLED','maintenance alone works without evidence-read permission')
        finally:c.close()
        # Successful status is observational; avoid scheduler churn by cancelling its only operation first.
        restore_owner_only_control(a);d.shutdown();before=offline(h,'attribution-before',a)
        d=h.start('attribution-restart',conf,a,{'NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER':'1'})
        expose_control_for_uid(a)
        for i in range(3):run_as_uid(h,'read-only-status-'+str(i),UID,UID,['status','--control',str(d.control)],0)
        h.run('attribution-compact',['compact','--control',str(d.control)])
        restore_owner_only_control(a);d.shutdown();after=offline(h,'attribution-after',a)
        audit=selected_events(after)
        h.check([e for e in audit if e['command']=='STATUS']==[],'successful status appends no local-control events')
        for response,generation in [(response,'grant-after-read-g'),(cancelled,'attribution-g3')]:
            e=next(e for e in audit if e['request_id']==response['request_id'])
            h.check(e['decision']=='AUTHORIZED' and after['runtime_configuration']['events'][e['configuration_event']-1]['generation']==generation,'accepted audit retains exact policy generation after checkpoint/restart')
        bindings=after['runtime_configuration']['bindings']
        h.check(any(e.get('operation_id')==op and e['journal_kind']==10 and after['runtime_configuration']['events'][e['configuration_event']-1]['generation']=='attribution-g3' for e in bindings),'actual cancellation mutation agrees with audit generation')
        h.check(selected_events(before)==audit,'inspection/restart/compaction preserves delegated audit history')
        (h.output/'ATTRIBUTION.json').write_text(json.dumps({'delegated_events':audit,'binding':bindings},indent=2)+'\n')
    case('new_grants_exact_mutation_attribution_and_observational_status',grant_and_attribution)

    def queued_configuration():
        observations=[]
        for rollback_case in (False,True):
            suffix='rollback' if rollback_case else 'activate'
            a,conf,d=setup(h,'queued-'+suffix,'INSPECT,CONFIGURATION',
                {'NATRAV_OVERLAY_TEST_CONFIG_AFTER_VALIDATION_MS':'1000'})
            remove=grants(h,conf,a,'queued-remove-'+suffix,'INSPECT',False)
            # An allowed but now-revoked waiter must fail before opening this
            # candidate. The candidate is real and valid; the old policy would restore its own authority.
            replacement=candidate(h,conf,'queued-second-'+suffix,'queued-second-'+suffix)
            data=packet(11,text('queued-'+suffix+'-g1'),text('queued rollback')) if rollback_case else packet(10,text(str(replacement)),text('queued activation'))
            # Start the real delegated process before the one-second publication
            # window. Keep its request incomplete, then release the last byte
            # only after the first candidate is prepared. This tests the same
            # serialized handoff without spending the window importing Python.
            c=Client(h,d,'queued-delegated-'+suffix,data,split=True)
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                f=pool.submit(activate,h,'first-revokes-'+suffix,a,remove)
                h.wait('first activation prepared',lambda:'NATRAV_OVERLAY_TEST_CONFIG_AFTER_VALIDATION_MS' in d.stderr_path.read_text())
                c.release()
                try:
                    h.wait('delegated handoff precedes revocation commit',lambda:f'CONTROL_CONFIGURATION_HANDOFF {UID}' in d.stderr_path.read_text())
                    f.result(timeout=12)
                    denied=c.finish()
                    h.check(denied.get('code')=='LOCAL_CONTROL_CLASS_DENIED','queued '+suffix+' reauthorizes after serialized activation')
                    status=h.status('queued-final-'+suffix,a)
                    h.check(status['runtime_configuration']['generation']=='queued-remove-'+suffix+'-g','revoked waiter cannot republish old authority')
                finally:c.close()
            restore_owner_only_control(a);d.shutdown();state=offline(h,'queued-audit-'+suffix,a)
            matched=[e for e in selected_events(state) if e['request_id']==denied['request_id']]
            h.check(len(matched)==1 and matched[0]['decision']=='DENIED','no phantom authorized config audit before waiting')
            event=matched[0]['configuration_event']
            h.check(state['runtime_configuration']['events'][event-1]['generation']=='queued-remove-'+suffix+'-g','waiter denial records current configuration')
            observations.append({'request':suffix,'response':denied,'audit':matched[0]})
        (h.output/'QUEUED-PUBLICATION.json').write_text(json.dumps(observations,indent=2)+'\n')
    case('queued_activation_and_rollback_reauthorize_after_prior_publication',queued_configuration)

    def config_still_authorized():
        a,conf,d=setup(h,'queued-allowed','INSPECT,CONFIGURATION',{'NATRAV_OVERLAY_TEST_CONFIG_AFTER_VALIDATION_MS':'700'})
        one=candidate(h,conf,'queued-allowed-first','allowed-g2')
        # The second candidate removes its own actor's CONFIGURATION permission;
        # authorization is intentionally from the current predecessor, not candidate.
        two=grants(h,conf,a,'self-removal','INSPECT',False)
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            f=pool.submit(activate,h,'allowed-first',a,one)
            h.wait('first prepare marker',lambda:'NATRAV_OVERLAY_TEST_CONFIG_AFTER_VALIDATION_MS' in d.stderr_path.read_text())
            c=Client(h,d,'allowed-second',packet(10,text(str(two)),text('self remove after wait')),split=False)
            try:
                h.wait('allowed handoff',lambda:f'CONTROL_CONFIGURATION_HANDOFF {UID}' in d.stderr_path.read_text())
                f.result(timeout=10);response=c.finish();h.check(response.get('ok') is True,'still-authorized queued publication succeeds without lock upgrade deadlock')
            finally:c.close()
        denied=run_as_uid(h,'removed-config-class',UID,UID,['config-rollback','--control',str(d.control),'--generation','allowed-g2','--reason','must not restore'],3)
        h.check(denied.get('code')=='LOCAL_CONTROL_CLASS_DENIED','self-removal takes effect on next command')
        restore_owner_only_control(a);d.shutdown();state=offline(h,'allowed-audit',a)
        event=next(e for e in selected_events(state) if e['request_id']==response['request_id'])
        h.check(state['runtime_configuration']['events'][event['configuration_event']-1]['generation']=='allowed-g2','publication accepted audit binds actual predecessor, not pre-read or candidate config')
        h.check(state['runtime_configuration']['generation']=='self-removal-g','published self-removal remains authoritative')
        # Root-authorized rollback remains supported and does not deadlock.
        d=h.start('allowed-restart',conf,a)
        rollback(h,'root-rollback',a,'allowed-g2');d.shutdown()
        (h.output/'PUBLICATION-ATTRIBUTION.json').write_text(json.dumps({'response':response,'audit':event},indent=2)+'\n')
    case('queued_authorized_publication_self_removal_and_rollback',config_still_authorized)

    def commit_before_revocation():
        a,conf,d=setup(h,'commit-before-revocation','INSPECT,MAINTENANCE',
            {'NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_COMMAND':'CANCEL','NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_PAUSE_MS':'1200'})
        op=operation('cancel-held-generation')
        h.run('held-submit',['submit','--control',str(d.control),'--node','A','--peer','B','--scope','admin/test','--operation',op,'--payload-text','held'])
        remove=grants(h,conf,a,'remove-while-committing','INSPECT',False)
        c=Client(h,d,'already-authorized-cancel',packet(6,bytes.fromhex(op),text('ordered before policy removal')),split=False)
        try:
            h.wait('cancel retains generation gate',lambda:'CONTROL_AUTHORIZED CANCEL' in d.stderr_path.read_text())
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                f=pool.submit(activate,h,'wait-for-admitted-cancel',a,remove)
                response=c.finish();h.check(response.get('status')=='CANCELLED','admitted cancellation commits under held generation')
                f.result(timeout=12)
        finally:c.close()
        current=query(h,'held-cancel-current',a,op=op)['records'][0]
        h.check(current['status']=='CANCELLED','unrelated publication does not overwrite cancellation')
        restore_owner_only_control(a);d.shutdown();state=offline(h,'held-audit',a)
        event=next(e for e in selected_events(state) if e['request_id']==response['request_id'])
        h.check(state['runtime_configuration']['events'][event['configuration_event']-1]['generation']=='commit-before-revocation-g1','accepted audit retains predecessor that actually governed commit')
        mutation=next(e for e in state['runtime_configuration']['bindings'] if e.get('operation_id')==op and e['journal_kind']==10)
        h.check(mutation['configuration_event']==event['configuration_event'],'publication cannot split authorization from mutation')
    case('authorized_legacy_mutation_finishes_before_waiting_revocation',commit_before_revocation)

    def lifecycle_during_prepare():
        a,conf,d=setup(h,'prepare-quiesce','INSPECT,CONFIGURATION',{'NATRAV_OVERLAY_TEST_CONFIG_AFTER_VALIDATION_MS':'1000'})
        new=candidate(h,conf,'quiesced-candidate','must-not-publish')
        c=Client(h,d,'prepared-config-quiesce',packet(10,text(str(new)),text('preparation interleaving')),split=False)
        try:
            h.wait('candidate validated',lambda:'NATRAV_OVERLAY_TEST_CONFIG_AFTER_VALIDATION_MS' in d.stderr_path.read_text())
            h.run('quiesce-during-prepare',['quiesce','--control',str(d.control),'--reason','stop before publication'])
            denied=c.finish();h.check(denied.get('code')=='SERVICE_QUIESCED','exclusive publication rechecks lifecycle after fallible preparation')
        finally:c.close()
        h.check(h.status('still-original',a)['runtime_configuration']['generation']=='prepare-quiesce-g1','quiesced candidate did not publish')
        h.run('resume-after-rejected-candidate',['resume','--control',str(d.control),'--reason','explicit restart'])
        activate(h,'retry-after-resume',a,new)
        restore_owner_only_control(a);d.shutdown();state=offline(h,'lifecycle-audit',a)
        denied_events=[e for e in selected_events(state) if e['request_id']==denied['request_id']]
        h.check(len(denied_events)==1 and denied_events[0]['decision']=='DENIED','no authorized publication audit for rejected quiesced candidate')
        h.check([e['kind'] for e in state['lifecycle']['events']][:2]==['QUIESCED','RESUMED'],'lifecycle remains journaled')
    case('lifecycle_change_during_configuration_preparation_blocks_publication',lifecycle_during_prepare)

    def malformed_and_early_denial():
        a,conf,d=setup(h,'bounded-denials','INSPECT')
        c=Client(h,d,'malformed-after-policy',b'NOC1\x02\x00')
        try:
            newer=grants(h,conf,a,'malformed-new-generation','INSPECT')
            denied=c.finish();h.check(denied.get('code')=='trailing-material','strict control decoding retained')
        finally:c.close()
        # No application request is sent: an unlisted UID must receive a
        # complete denial before the server attempts a frame read.
        script='''import socket,struct,json,sys
s=socket.socket(socket.AF_UNIX);s.settimeout(3);s.connect(sys.argv[1])
def take(n):
 b=b''
 while len(b)<n:
  x=s.recv(n-len(b))
  if not x:raise RuntimeError('early EOF')
  b+=x
 return b
n=struct.unpack('!I',take(4))[0];v=take(n);print(v[5:].decode())
'''
        p=subprocess.run(['/usr/bin/setpriv','--reuid=65532','--regid=65532','--clear-groups',sys.executable,'-c',script,str(d.control)],capture_output=True,text=True,timeout=5)
        h.check(p.returncode==0,'unlisted principal receives denial without sending bytes')
        early=json.loads(p.stdout);h.check(early['code']=='LOCAL_CONTROL_UID_DENIED','pre-read exact UID rejection unchanged')
        restore_owner_only_control(a);d.shutdown();state=offline(h,'bounded-denials-audit',a)
        e=next(e for e in selected_events(state) if e['request_id']==denied['request_id'])
        h.check(e['command']=='MALFORMED' and state['runtime_configuration']['events'][e['configuration_event']-1]['generation']=='malformed-new-generation-g','malformed audit uses post-read current generation without request data')
        h.check(all('payload' not in e for e in state['local_control']['entries']),'audit omits rejected raw bytes')
    case('pre_read_uid_rejection_and_post_read_malformed_audit',malformed_and_early_denial)


def main():
    if len(sys.argv)>1 and sys.argv[1]=='--client':
        client_mode(*sys.argv[2:]);return 0
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    h=Harness(a.binary,a.output);start=time.monotonic();ok=False
    try:
        h.check(os.geteuid()==0 and Path('/usr/bin/setpriv').exists(),'test requires actual owned UID switching, not simulated credentials')
        all_cases(h,a.case);ok=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(repr(e)+'\n');print('FAIL:',repr(e),file=sys.stderr,flush=True)
    finally:
        h.cleanup()
        summary={'format':'NATRAV_CONTROL_AUTHORIZATION_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.monotonic()-start}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:
            (h.output/(name+'.json')).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
