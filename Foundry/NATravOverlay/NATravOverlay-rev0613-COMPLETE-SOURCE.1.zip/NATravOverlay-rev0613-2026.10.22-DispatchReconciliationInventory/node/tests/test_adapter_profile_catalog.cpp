#include "adapter_profile_catalog.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <csignal>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace {

using natrav_overlay::AdapterCatalogAuthorityDecision;
using natrav_overlay::AdapterCatalogError;
using natrav_overlay::AdapterCatalogOperation;
using natrav_overlay::AdapterEndpointRole;
using natrav_overlay::AdapterSha256;
using natrav_overlay::ConfiguredAdapterEndpoint;
using natrav_overlay::DurableAdapterProfileCatalog;
using natrav_overlay::OperatorPinnedAdapterProfile;

struct CaseRecord final {
    std::string name;
    std::size_t assertions{0U};
};

class Probe final {
public:
    template <typename Function>
    void run_case(std::string name, Function&& function) {
        const auto before = assertions_;
        function();
        cases_.push_back(CaseRecord{
            .name = std::move(name),
            .assertions = assertions_ - before,
        });
    }

    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_catalog_code(
        Function&& function,
        const std::string_view expected,
        const std::string_view detail) {
        ++assertions_;
        try {
            function();
        } catch (const AdapterCatalogError& error) {
            if (error.code() == expected) {
                return;
            }
            throw std::runtime_error(
                std::string(detail) + ": expected " + std::string(expected) +
                ", observed " + error.code());
        }
        throw std::runtime_error(std::string(detail) + ": no error");
    }

    [[nodiscard]] std::size_t assertions() const noexcept { return assertions_; }
    [[nodiscard]] const std::vector<CaseRecord>& cases() const noexcept {
        return cases_;
    }

private:
    std::size_t assertions_{0U};
    std::vector<CaseRecord> cases_{};
};

class TempDirectory final {
public:
    TempDirectory() {
        std::array<char, 128U> pattern{};
        const std::string value = "/tmp/natrav-adapter-catalog-XXXXXX";
        std::copy(value.begin(), value.end(), pattern.begin());
        char* created = ::mkdtemp(pattern.data());
        if (created == nullptr) {
            throw std::runtime_error("mkdtemp failed");
        }
        path_ = created;
        if (::chmod(path_.c_str(), S_IRWXU) != 0) {
            throw std::runtime_error("chmod temp directory failed");
        }
    }
    TempDirectory(const TempDirectory&) = delete;
    TempDirectory& operator=(const TempDirectory&) = delete;
    ~TempDirectory() { std::filesystem::remove_all(path_); }
    [[nodiscard]] const std::filesystem::path& path() const noexcept { return path_; }
private:
    std::filesystem::path path_{};
};

[[nodiscard]] std::vector<std::uint8_t> read_bytes(
    const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        throw std::runtime_error("file open failed: " + path.string());
    }
    return std::vector<std::uint8_t>(
        std::istreambuf_iterator<char>(input),
        std::istreambuf_iterator<char>());
}

[[nodiscard]] OperatorPinnedAdapterProfile make_profile(
    const std::string& id,
    const std::uint64_t generation,
    const AdapterSha256& previous,
    const std::filesystem::path& executable,
    const AdapterSha256& digest,
    const std::string& argument) {
    OperatorPinnedAdapterProfile profile;
    profile.profile_id = id;
    profile.generation = generation;
    profile.previous_profile_sha256 = previous;
    profile.executable = executable;
    profile.executable_sha256 = digest;
    profile.arguments = {argument};
    profile.mtu = 1'200U;
    profile.capability_profile = 1U;
    profile.max_frame_bytes = 65'536U;
    profile.max_queued_bytes = 1'048'576U;
    profile.max_outstanding_requests = 1U;
    profile.max_evidence_events = 256U;
    profile.max_launch_attempts = 3U;
    profile.startup_timeout = std::chrono::milliseconds(2'000);
    profile.request_timeout = std::chrono::milliseconds(500);
    profile.shutdown_timeout = std::chrono::milliseconds(500);
    profile.initial_restart_backoff = std::chrono::milliseconds(5);
    profile.maximum_restart_backoff = std::chrono::milliseconds(20);
    return profile;
}

[[nodiscard]] ConfiguredAdapterEndpoint make_endpoint(
    const std::string& id,
    const std::uint64_t generation,
    const AdapterSha256& previous,
    const AdapterEndpointRole role,
    const OperatorPinnedAdapterProfile& profile,
    const std::uint64_t link,
    const std::uint32_t epoch) {
    ConfiguredAdapterEndpoint endpoint;
    endpoint.endpoint_id = id;
    endpoint.generation = generation;
    endpoint.previous_endpoint_sha256 = previous;
    endpoint.role = role;
    endpoint.locator.profile_id = profile.profile_id;
    endpoint.locator.profile_generation = profile.generation;
    endpoint.locator.link_id = link;
    endpoint.locator.epoch = epoch;
    endpoint.profile_sha256 =
        natrav_overlay::operator_pinned_adapter_profile_sha256(profile);
    return endpoint;
}

[[nodiscard]] std::vector<std::uint8_t> evidence(const std::string_view text) {
    return std::vector<std::uint8_t>(text.begin(), text.end());
}

[[nodiscard]] natrav_overlay::AdapterCatalogAuthorityVerifier verifier() {
    return [](
        const AdapterCatalogOperation,
        const std::span<const std::uint8_t> object,
        const std::span<const std::uint8_t> authority) {
        const std::string token(authority.begin(), authority.end());
        if (object.empty()) {
            return AdapterCatalogAuthorityDecision{
                .authorized = false,
                .rejection_code = "EMPTY_OBJECT",
            };
        }
        if (token == "owner-allow") {
            return AdapterCatalogAuthorityDecision{.authorized = true};
        }
        return AdapterCatalogAuthorityDecision{
            .authorized = false,
            .rejection_code = "OWNER_AUTHORITY_REJECTED",
        };
    };
}

void append_tail(
    const std::filesystem::path& path,
    const std::span<const std::uint8_t> bytes) {
    std::ofstream output(path, std::ios::binary | std::ios::app);
    if (!output) {
        throw std::runtime_error("tail append open failed");
    }
    output.write(
        reinterpret_cast<const char*>(bytes.data()),
        static_cast<std::streamsize>(bytes.size()));
    output.flush();
    if (!output) {
        throw std::runtime_error("tail append failed");
    }
}

}  // namespace

int main(int argc, char* argv[]) {
    Probe probe;
    try {
        if (argc != 3) {
            throw std::runtime_error("expected adapter fixture A and B");
        }
        const auto fixture_a = std::filesystem::absolute(argv[1]);
        const auto fixture_b = std::filesystem::absolute(argv[2]);
        const auto digest_a = natrav_overlay::adapter_sha256(read_bytes(fixture_a));
        const auto digest_b = natrav_overlay::adapter_sha256(read_bytes(fixture_b));
        TempDirectory temporary;
        const auto catalog_path = temporary.path() / "profiles.catalog";
        DurableAdapterProfileCatalog catalog(catalog_path);
        const auto allow = evidence("owner-allow");
        const auto deny = evidence("owner-deny");

        const auto profile_one = make_profile(
            "field-radio",
            1U,
            AdapterSha256{},
            fixture_a,
            digest_a,
            "alpha");
        auto profile_two = make_profile(
            "field-radio",
            2U,
            natrav_overlay::operator_pinned_adapter_profile_sha256(profile_one),
            fixture_b,
            digest_b,
            "bravo");

        probe.run_case("empty owner-private catalog", [&] {
            const auto state = catalog.snapshot();
            probe.check(state.last_sequence == 0U && state.profiles.empty() &&
                            state.endpoints.empty() && state.rejections.empty(),
                        "new catalog is empty");
            struct stat status {};
            probe.check(::stat(catalog_path.c_str(), &status) == 0,
                        "catalog file exists");
            probe.check(S_ISREG(status.st_mode) &&
                            (status.st_mode & static_cast<mode_t>(0077)) == 0 &&
                            status.st_nlink == 1,
                        "catalog is one owner-private regular file");
        });

        probe.run_case("canonical endpoint record", [&] {
            const auto endpoint = make_endpoint(
                "uplink-route", 1U, AdapterSha256{}, AdapterEndpointRole::route,
                profile_one, 0x0123456789abcdefULL, 7U);
            const auto text =
                natrav_overlay::configured_adapter_endpoint_text(endpoint);
            probe.check(
                natrav_overlay::parse_configured_adapter_endpoint(text) == endpoint,
                "endpoint canonical text round trips");
            probe.check(text.find("role=route\n") != std::string::npos &&
                            text.find("adapter-v1|profile=field-radio|") !=
                                std::string::npos,
                        "endpoint binds role and exact profile generation locator");
        });

        probe.run_case("authorized profile creation is durable", [&] {
            const auto accepted = catalog.commit_profile(
                profile_one, allow, verifier());
            probe.check(accepted.profile == profile_one && accepted.sequence == 1U,
                        "profile generation one is accepted");
            probe.check(accepted.authority_evidence_sha256 ==
                            natrav_overlay::adapter_sha256(allow),
                        "only authority evidence digest is retained");
            const DurableAdapterProfileCatalog reopened(catalog_path);
            const auto state = reopened.snapshot_strict();
            probe.check(state.profiles.size() == 1U &&
                            state.profiles.front() == accepted,
                        "accepted profile survives catalog reopen");
        });

        probe.run_case("unauthorized successor remains inactive", [&] {
            probe.expect_catalog_code(
                [&] {
                    static_cast<void>(catalog.commit_profile(
                        profile_two, deny, verifier()));
                },
                "ADAPTER_CATALOG_UNAUTHORIZED",
                "owner rejection is enforced");
            const auto state = catalog.snapshot_strict();
            probe.check(state.profiles.size() == 1U &&
                            state.rejections.size() == 1U,
                        "unauthorized object is evidence but not active configuration");
            probe.check(state.rejections.front().operation ==
                            AdapterCatalogOperation::profile_replace &&
                            state.rejections.front().code ==
                                "OWNER_AUTHORITY_REJECTED",
                        "rejection records operation and bounded code");
        });

        probe.run_case("authorized profile succession is exact", [&] {
            const auto accepted = catalog.commit_profile(
                profile_two, allow, verifier());
            probe.check(accepted.profile.generation == 2U &&
                            accepted.profile.previous_profile_sha256 ==
                                natrav_overlay::operator_pinned_adapter_profile_sha256(
                                    profile_one),
                        "successor binds exact predecessor record");
            auto skipped = profile_two;
            skipped.generation = 4U;
            skipped.previous_profile_sha256 =
                natrav_overlay::operator_pinned_adapter_profile_sha256(profile_two);
            probe.expect_catalog_code(
                [&] {
                    static_cast<void>(catalog.commit_profile(
                        skipped, allow, verifier()));
                },
                "ADAPTER_CATALOG_PROFILE_REJECTED",
                "generation skip is rejected");
            const auto state = catalog.snapshot_strict();
            probe.check(state.profiles.size() == 2U &&
                            state.rejections.size() == 2U,
                        "structural rejection is retained without activation");
        });

        ConfiguredAdapterEndpoint endpoint_one = make_endpoint(
            "uplink-route", 1U, AdapterSha256{}, AdapterEndpointRole::route,
            profile_one, 0x0123456789abcdefULL, 7U);
        probe.run_case("exact retained profile endpoint resolves", [&] {
            const auto accepted = catalog.commit_endpoint(
                endpoint_one, allow, verifier());
            probe.check(accepted.endpoint == endpoint_one,
                        "route endpoint generation one is accepted");
            const auto resolved = catalog.resolve_endpoint("uplink-route", 1U);
            probe.check(resolved.endpoint == endpoint_one &&
                            resolved.profile == profile_one,
                        "endpoint resolves exact retained profile generation");
            probe.check(resolved.profile_sha256 == endpoint_one.profile_sha256,
                        "resolution rechecks bound profile digest");
        });

        probe.run_case("missing and stale profiles cannot activate", [&] {
            auto missing = endpoint_one;
            missing.endpoint_id = "missing-route";
            missing.locator.profile_id = "absent-profile";
            missing.profile_sha256 = digest_a;
            probe.expect_catalog_code(
                [&] {
                    static_cast<void>(catalog.commit_endpoint(
                        missing, allow, verifier()));
                },
                "ADAPTER_CATALOG_MISSING_PROFILE",
                "missing profile is rejected");
            auto stale = endpoint_one;
            stale.endpoint_id = "stale-route";
            stale.profile_sha256 = digest_b;
            probe.expect_catalog_code(
                [&] {
                    static_cast<void>(catalog.commit_endpoint(
                        stale, allow, verifier()));
                },
                "ADAPTER_CATALOG_STALE_PROFILE",
                "mismatched profile digest is rejected");
            const auto state = catalog.snapshot_strict();
            probe.check(state.endpoints.size() == 1U &&
                            state.rejections.size() == 4U,
                        "rejected endpoints are not active");
        });

        ConfiguredAdapterEndpoint endpoint_two = make_endpoint(
            "uplink-route",
            2U,
            natrav_overlay::configured_adapter_endpoint_sha256(endpoint_one),
            AdapterEndpointRole::route,
            profile_two,
            0xfedcba9876543210ULL,
            8U);
        probe.run_case("endpoint succession selects new profile exactly", [&] {
            const auto accepted = catalog.commit_endpoint(
                endpoint_two, allow, verifier());
            probe.check(accepted.endpoint == endpoint_two,
                        "authorized endpoint replacement is accepted");
            const auto old_resolved = catalog.resolve_endpoint("uplink-route", 1U);
            const auto new_resolved = catalog.resolve_endpoint("uplink-route", 2U);
            probe.check(old_resolved.profile.generation == 1U &&
                            new_resolved.profile.generation == 2U,
                        "old and new exact generations remain independently resolvable");
            auto role_change = endpoint_two;
            role_change.generation = 3U;
            role_change.previous_endpoint_sha256 =
                natrav_overlay::configured_adapter_endpoint_sha256(endpoint_two);
            role_change.role = AdapterEndpointRole::listener;
            probe.expect_catalog_code(
                [&] {
                    static_cast<void>(catalog.commit_endpoint(
                        role_change, allow, verifier()));
                },
                "ADAPTER_CATALOG_ENDPOINT_REJECTED",
                "stable endpoint id cannot change route/listener role");
        });

        probe.run_case("concurrent writers serialize through the locked journal", [&] {
            const auto concurrent_one = make_profile(
                "parallel-a", 1U, AdapterSha256{}, fixture_a, digest_a, "one");
            const auto concurrent_two = make_profile(
                "parallel-b", 1U, AdapterSha256{}, fixture_b, digest_b, "two");
            std::array<pid_t, 2U> children{-1, -1};
            children[0U] = ::fork();
            if (children[0U] == 0) {
                try {
                    DurableAdapterProfileCatalog child_catalog(catalog_path);
                    static_cast<void>(child_catalog.commit_profile(
                        concurrent_one, allow, verifier()));
                    ::_exit(0);
                } catch (...) {
                    ::_exit(2);
                }
            }
            if (children[0U] < 0) {
                throw std::runtime_error("first fork failed");
            }
            children[1U] = ::fork();
            if (children[1U] == 0) {
                try {
                    DurableAdapterProfileCatalog child_catalog(catalog_path);
                    static_cast<void>(child_catalog.commit_profile(
                        concurrent_two, allow, verifier()));
                    ::_exit(0);
                } catch (...) {
                    ::_exit(2);
                }
            }
            if (children[1U] < 0) {
                static_cast<void>(::kill(children[0U], SIGKILL));
                throw std::runtime_error("second fork failed");
            }
            for (const auto child : children) {
                int status = 0;
                pid_t result = -1;
                do {
                    result = ::waitpid(child, &status, 0);
                } while (result < 0 && errno == EINTR);
                probe.check(result == child && WIFEXITED(status) &&
                                WEXITSTATUS(status) == 0,
                            "concurrent writer exits successfully");
            }
            const auto state = catalog.snapshot_strict();
            const auto has_a = std::any_of(
                state.profiles.begin(), state.profiles.end(),
                [](const auto& record) {
                    return record.profile.profile_id == "parallel-a";
                });
            const auto has_b = std::any_of(
                state.profiles.begin(), state.profiles.end(),
                [](const auto& record) {
                    return record.profile.profile_id == "parallel-b";
                });
            probe.check(has_a && has_b,
                        "both concurrent authorized writes are retained exactly once");
        });

        probe.run_case("interrupted append is recovered with evidence", [&] {
            const std::array<std::uint8_t, 7U> tail{
                0x4eU, 0x41U, 0x50U, 0x52U, 0x45U, 0x43U, 0x30U};
            append_tail(catalog_path, tail);
            probe.expect_catalog_code(
                [&] { static_cast<void>(catalog.snapshot_strict()); },
                "ADAPTER_CATALOG_INCOMPLETE_TAIL",
                "strict audit refuses incomplete tail");
            const auto recovered = catalog.snapshot();
            probe.check(recovered.recoveries.size() == 1U &&
                            recovered.recoveries.front().discarded_bytes == tail.size(),
                        "automatic recovery is represented by a durable record");
            probe.check(recovered.recoveries.front().discarded_sha256 ==
                            natrav_overlay::adapter_sha256(tail),
                        "recovery binds exact discarded bytes");
            probe.check(catalog.snapshot_strict() == recovered,
                        "recovered journal is canonical and stable");
        });

        probe.run_case("complete-record corruption is never repaired", [&] {
            const auto corrupt_path = temporary.path() / "corrupt.catalog";
            std::filesystem::copy_file(catalog_path, corrupt_path);
            if (::chmod(corrupt_path.c_str(), S_IRUSR | S_IWUSR) != 0) {
                throw std::runtime_error("chmod corrupt copy failed");
            }
            std::fstream file(
                corrupt_path,
                std::ios::binary | std::ios::in | std::ios::out);
            file.seekg(16 + 88 + 10);
            char byte = 0;
            file.read(&byte, 1);
            byte = static_cast<char>(byte ^ 0x01);
            file.seekp(16 + 88 + 10);
            file.write(&byte, 1);
            file.close();
            DurableAdapterProfileCatalog corrupt(corrupt_path);
            probe.expect_catalog_code(
                [&] { static_cast<void>(corrupt.snapshot()); },
                "ADAPTER_CATALOG_CORRUPT",
                "digest mismatch is hard corruption");
        });

        probe.run_case("path and permission hazards are rejected", [&] {
            const auto unsafe = temporary.path() / "unsafe";
            std::filesystem::create_directory(unsafe);
            if (::chmod(unsafe.c_str(), S_IRWXU | S_IRGRP | S_IXGRP) != 0) {
                throw std::runtime_error("chmod unsafe directory failed");
            }
            DurableAdapterProfileCatalog unsafe_catalog(unsafe / "catalog");
            probe.expect_catalog_code(
                [&] { static_cast<void>(unsafe_catalog.snapshot()); },
                "ADAPTER_CATALOG_UNSAFE_PARENT",
                "group-accessible parent is rejected");

            const auto target = temporary.path() / "target.catalog";
            DurableAdapterProfileCatalog target_catalog(target);
            static_cast<void>(target_catalog.snapshot());
            const auto link = temporary.path() / "linked.catalog";
            std::filesystem::create_symlink(target, link);
            DurableAdapterProfileCatalog linked(link);
            probe.expect_catalog_code(
                [&] { static_cast<void>(linked.snapshot()); },
                "ADAPTER_CATALOG_OPEN_FAILED",
                "symlink catalog path is rejected");

            const auto alias = temporary.path() / "alias.catalog";
            std::filesystem::create_hard_link(target, alias);
            probe.expect_catalog_code(
                [&] { static_cast<void>(target_catalog.snapshot()); },
                "ADAPTER_CATALOG_UNSAFE_FILE",
                "hard-linked catalog is rejected");
        });

        probe.run_case("rejection evidence has a hard bound", [&] {
            const auto bounded_dir = temporary.path() / "bounded";
            std::filesystem::create_directory(bounded_dir);
            if (::chmod(bounded_dir.c_str(), S_IRWXU) != 0) {
                throw std::runtime_error("chmod bounded directory failed");
            }
            natrav_overlay::AdapterCatalogLimits limits;
            limits.maximum_rejections = 1U;
            DurableAdapterProfileCatalog bounded(
                bounded_dir / "catalog", limits);
            probe.expect_catalog_code(
                [&] {
                    static_cast<void>(bounded.commit_profile(
                        profile_one, deny, verifier()));
                },
                "ADAPTER_CATALOG_UNAUTHORIZED",
                "first rejection is retained");
            probe.expect_catalog_code(
                [&] {
                    static_cast<void>(bounded.commit_profile(
                        profile_one, deny, verifier()));
                },
                "ADAPTER_CATALOG_EVIDENCE_EXHAUSTED",
                "catalog refuses unbounded rejection growth");
            probe.check(bounded.snapshot_strict().rejections.size() == 1U,
                        "rejection count remains bounded");
        });

        probe.run_case("independent catalog handles serialize current state", [&] {
            DurableAdapterProfileCatalog first(catalog_path);
            DurableAdapterProfileCatalog second(catalog_path);
            const auto first_state = first.snapshot_strict();
            const auto second_state = second.snapshot_strict();
            probe.check(first_state == second_state &&
                            first_state.last_sequence > 0U,
                        "independent handles replay one locked journal state");
        });

        std::cout << "{\"format\":\"NATRAV_ADAPTER_CATALOG_PROBE_V1\","
                  << "\"status\":\"PASS\",\"cases\":" << probe.cases().size()
                  << ",\"assertions\":" << probe.assertions()
                  << ",\"case_records\":[";
        for (std::size_t index = 0U; index < probe.cases().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            std::cout << "{\"name\":\"" << probe.cases()[index].name
                      << "\",\"assertions\":"
                      << probe.cases()[index].assertions << '}';
        }
        std::cout << "]}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cout << "{\"format\":\"NATRAV_ADAPTER_CATALOG_PROBE_V1\","
                  << "\"status\":\"FAIL\",\"assertions\":"
                  << probe.assertions() << ",\"detail\":\"" << error.what()
                  << "\"}\n";
        return 1;
    }
}
