// Focused deterministic differential test of the exact production index/cache.
// This standalone binary supplies only a throwing app_fail adapter; integrated
// tests execute the complete daemon's ordinary error and persistence paths.
#include "evidence_index.hpp"
#include <algorithm>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
namespace natrav_overlay {
[[noreturn]] void app_fail(std::string_view code, std::string_view detail) {
    throw std::runtime_error(std::string(code) + ":" + std::string(detail));
}
}
int main() {
    using namespace natrav_overlay;
    std::uint64_t checks = 0U;
    auto check = [&](bool value) { ++checks; if (!value) { throw std::runtime_error("index differential mismatch"); } };
    try {
        std::mt19937_64 rng(0x507U);
        EvidenceOrderedIndex index;
        std::vector<std::size_t> history, current;
        std::size_t global = 0U;
        for (std::size_t n = 0U; n < 100000U; ++n) {
            global += 1U + static_cast<std::size_t>(rng() % 7U);
            std::optional<std::size_t> parent;
            if (!current.empty() && rng() % 3U != 0U) {
                const auto position = static_cast<std::size_t>(rng() % current.size());
                parent = current[position]; current.erase(current.begin() + static_cast<std::ptrdiff_t>(position));
            }
            index.append(global, parent); history.push_back(global); current.push_back(global);
            check(index.size(true) == history.size()); check(index.size(false) == current.size());
            for (int sample = 0; sample < 6; ++sample) {
                const auto h = static_cast<std::size_t>(rng() % history.size());
                const auto c = static_cast<std::size_t>(rng() % current.size());
                check(index.at(h,true) == history[h]); check(index.at(c,false) == current[c]);
                const auto point = static_cast<std::size_t>(rng() % (global + 3U));
                check(index.before(point,true) == static_cast<std::size_t>(std::lower_bound(history.begin(),history.end(),point)-history.begin()));
                check(index.before(point,false) == static_cast<std::size_t>(std::lower_bound(current.begin(),current.end(),point)-current.begin()));
            }
        }
        for (std::size_t i = 0U; i < current.size(); ++i) { check(index.at(i,false) == current[i]); }
        bool rejected = false;
        try { index.append(global,std::nullopt); } catch (const std::runtime_error&) { rejected = true; }
        check(rejected);
        EvidenceRootCache cache;
        for (std::uint64_t n = 1U; n <= 10000U; ++n) {
            datacube::Digest32 key{}; key.octets[0]=static_cast<unsigned char>(n&255U);key.octets[1]=static_cast<unsigned char>((n>>8U)&255U);
            cache.put(EvidenceRootCacheEntry{.key=key,.version=n,.root=key,.selected=n,.used=0U});
            check(cache.get(key,n).has_value()); check(!cache.get(key,n+1U).has_value());
            check(cache.allocated_bytes() == EvidenceRootCache::capacity * sizeof(EvidenceRootCacheEntry));
        }
        datacube::Digest32 first{};first.octets[0]=1U;check(!cache.get(first,1U).has_value());
        std::cout << "{\"status\":\"PASS\",\"checks\":" << checks
            << ",\"admissions\":" << history.size() << ",\"current_heads\":" << current.size()
            << ",\"index_allocated_array_bytes\":" << index.allocated_bytes()
            << ",\"cache_entries_bound\":" << EvidenceRootCache::capacity
            << ",\"cache_allocated_array_bytes\":" << cache.allocated_bytes() << "}\n";
        return 0;
    } catch (const std::exception& ex) { std::cerr << ex.what() << '\n'; return 1; }
}
