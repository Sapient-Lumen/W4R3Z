#!/usr/bin/env python3
"""Indexed pending-action selection against real compiled peers and durable state."""
from __future__ import annotations
import argparse, hashlib, json, time
from pathlib import Path
from run_persistent import Harness, free_port, operation
from run_authorization_actions import write_config, generation, submit_action
from run_action_inspection import setup, query, wait_row


def sender(h: Harness, name: str, recipient_port: int):
    state=h.runtime/(name+'-a')
    cfg=write_config(h,name+'-a','A',state,free_port(),'A',
        [('B',recipient_port,'B')],[('B',generation('B'),'ACTIVE','B')],[],deadline_ms=3000)
    return state,cfg,h.start(name+'-a',cfg,state)


def selection_work(h: Harness, label: str, state: Path) -> dict:
    status=h.status(label,state,logical_digest=False)
    work=status['actions']['selection_work']
    h.check(work['pending_vector_copies']==0,'ordinary scheduler never copies pending vector')
    return work


def submit(h: Harness,label: str,state: Path,amount: int,defer: int) -> str:
    op=operation(label)
    reply=submit_action(h,label,state/'control.sock','A','B',op,amount,defer)
    h.check(reply['queue_disposition'] in ('QUEUED','ALREADY_PENDING'),'durable action submission queued')
    return op


def run_cases(h: Harness, selected: set[str] | None) -> None:
    def case(name, fn):
        if not selected or name in selected:
            h.case(name, fn)

    def delayed_head():
        b,bc,bp,bd=setup(h,'indexed-delayed',expiry=900000)
        a,ac,ad=sender(h,'indexed-delayed',bp)
        delayed=[]
        for i in range(128):
            delayed.append(submit(h,f'delayed-{i}',a,1,600000))
        h.wait('all delayed actions admitted',lambda:query(h,'delayed-total',b,limit=1)['selected_total']==128,timeout=30)
        before=selection_work(h,'selection-before-ready',b)
        ready=submit(h,'deep-ready',a,7,0)
        completed=wait_row(h,'deep-ready-executed',b,ready,'EXECUTED')
        after=selection_work(h,'selection-after-ready',b)
        h.check(completed['queue_sequence']==129 and completed['result']['counter_after']==7,
            'ready action behind delayed prefix executes once')
        h.check(query(h,'delayed-still-pending',b,action=delayed[0])['records'][0]['status']=='PENDING',
            'earlier delayed work remains pending')
        metadata_delta=after['metadata_records_read']-before['metadata_records_read']
        node_delta=after['index_nodes_visited']-before['index_nodes_visited']
        h.check(1<=metadata_delta<=2,'one selected action plus at most one concurrent terminal observation')
        h.check(node_delta<=96,'deep ready action selected with bounded index work')
        (h.output/'DELAYED-HEAD.json').write_text(json.dumps({
            'delayed_actions':128,'ready_queue_sequence':129,
            'metadata_records_read_delta':metadata_delta,'index_nodes_visited_delta':node_delta,
            'before':before,'after':after},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('ready_action_behind_128_delayed_actions_uses_narrow_index',delayed_head)

    def cancelled_head():
        b,bc,bp,bd=setup(h,'cancelled-head',expiry=5000)
        a,ac,ad=sender(h,'cancelled-head',bp)
        first=submit(h,'cancelled-first',a,5,700)
        second=submit(h,'ready-second',a,9,700)
        h.wait('both delayed actions admitted',lambda:query(h,'cancel-total',b,limit=1)['selected_total']==2)
        h.run('cancel-first',['action-cancel','--control',str(b/'control.sock'),'--action',first,'--reason','remove stale head'])
        one=wait_row(h,'cancelled-first-row',b,first,'CANCELLED')
        two=wait_row(h,'second-progress',b,second,'EXECUTED')
        work=selection_work(h,'cancel-progress-work',b)
        h.check(one['status']=='CANCELLED' and two['result']['counter_after']==9,
            'terminal head removal cannot hide later eligible action')
        h.check(work['stale_selections']==0,'ordinary terminal update removed stale index entry')
        (h.output/'CANCELLED-HEAD.json').write_text(json.dumps({'first':one,'second':two,'selection_work':work},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('cancelled_ready_head_is_removed_and_later_action_progresses',cancelled_head)

    def expiry_order():
        b,bc,bp,bd=setup(h,'expiry-order',expiry=400,
            environment={'NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS':'800'})
        a,ac,ad=sender(h,'expiry-order',bp)
        blocker=submit(h,'expiry-blocker',a,6,0)
        h.wait('blocker began before deadline',lambda:query(h,'blocker-begun',b,action=blocker)['records'][0]['attempts']==1,timeout=10)
        expires=submit(h,'expires-while-blocked',a,4,100)
        done=wait_row(h,'expiry-blocker-done',b,blocker,'EXECUTED')
        dead=wait_row(h,'blocked-action-expired',b,expires,'EXPIRED')
        later=submit(h,'later-ready-after-expiry',a,3,0)
        later_done=wait_row(h,'later-ready-progress',b,later,'EXECUTED')
        h.check(done['result']['counter_after']==6 and later_done['result']['counter_after']==9,
            'completed blocker and later ready work each commit once')
        h.check(dead['attempts']==0 and dead['last_error_code']=='ACTION_EXPIRED',
            'pending action expires without beginning an execution attempt')
        (h.output/'EXPIRY-ORDER.json').write_text(json.dumps({'blocker':done,'expired':dead,'later':later_done,'selection_work':selection_work(h,'expiry-work',b)},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('expired_pending_action_is_removed_and_later_ready_work_progresses',expiry_order)

    def interrupted():
        b,bc,bp,bd=setup(h,'indexed-interrupted',environment={'NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS':'5000'},expiry=60000)
        a,ac,ad=sender(h,'indexed-interrupted',bp)
        op=submit(h,'indexed-interrupted-action',a,11,0)
        h.wait('first synchronized begin',lambda:query(h,'begun',b,action=op)['records'][0]['attempts']==1,timeout=12)
        bd.kill()
        bd=h.start('indexed-interrupted-restart',bc,b)
        done=wait_row(h,'indexed-interrupted-complete',b,op,'EXECUTED')
        h.check(done['attempts']==2 and done['result']['counter_before']==0 and done['result']['counter_after']==11,
            'begun action is selected again after restart and effect commits once')
        h.run('indexed-action-compact',['compact','--control',str(b/'control.sock'),'--deadline-ms','10000'],timeout=20)
        bd.shutdown();bd=h.start('indexed-after-compact',bc,b)
        rebuilt=query(h,'indexed-rebuilt',b,action=op)['records'][0]
        h.check(rebuilt['attempts']==2 and rebuilt['result']==done['result'],
            'checkpoint reconstruction preserves completed action and index terminal removal')
        (h.output/'INTERRUPTED.json').write_text(json.dumps({'completed':done,'rebuilt':rebuilt,'selection_work':selection_work(h,'interrupted-work',b)},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('interrupted_begun_action_retries_after_restart_and_compaction',interrupted)


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--case',action='append')
    args=parser.parse_args()
    if args.output.exists():parser.error('output must not exist')
    h=Harness(args.binary,args.output);started=time.time();ok=False
    try:
        run_cases(h,set(args.case) if args.case else None)
        if not h.cases:raise ValueError('no selected cases')
        ok=True
    except BaseException as error:
        (h.output/'FAILURE.txt').write_text(f'{type(error).__name__}: {error}\n')
        print(f'FAIL: {error}',file=__import__('sys').stderr)
    finally:
        h.cleanup()
        summary={'format':'NATRAV_ACTION_SELECTION_TESTS_V1','status':'PASS' if ok else 'FAIL',
                 'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),
                 'cases_total':len(h.cases),'cases_passed':sum(x['status']=='PASS' for x in h.cases),
                 'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,value in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:
            (h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1

if __name__=='__main__':raise SystemExit(main())
