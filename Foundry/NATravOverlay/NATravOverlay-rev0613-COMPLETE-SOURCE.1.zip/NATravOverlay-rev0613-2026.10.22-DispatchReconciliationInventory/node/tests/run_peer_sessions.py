#!/usr/bin/env python3
"""Persistent authenticated peer-session integration and adversarial regression."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import ssl
import struct
import sys
import threading
import time
from typing import Any, Callable

# Reuse the process/control harness and independent legacy-wire primitives. They
# remain separate from the C++ product implementation.
from run_persistent import Blackhole, Harness, free_port, operation
from run_integration import (
    CAPABILITIES,
    PROTOCOL,
    TARGET,
    VERSION,
    canonical,
    encode_receipt,
    hello_ack,
    node_artifact,
    record_digest,
)

SESSION_MAGIC = b"NOS1"
SESSION_VERSION = 1
SESSION_HEADER = 100
SESSION_OPEN = 1
SESSION_OPEN_ACK = 2
SESSION_REQUEST = 3
SESSION_RESPONSE = 4


def frame(payload: bytes) -> bytes:
    if not 2 <= len(payload) <= 131_072:
        raise AssertionError(f"invalid outer frame payload size {len(payload)}")
    return struct.pack("!I", len(payload)) + payload


def receive_exact(channel: socket.socket | ssl.SSLSocket, count: int) -> bytes:
    output = bytearray()
    while len(output) < count:
        part = channel.recv(count - len(output))
        if not part:
            raise EOFError(f"short read {len(output)}/{count}")
        output.extend(part)
    return bytes(output)


def receive_frame(channel: socket.socket | ssl.SSLSocket) -> bytes:
    size = struct.unpack("!I", receive_exact(channel, 4))[0]
    if not 2 <= size <= 131_072:
        raise AssertionError(f"invalid outer frame length {size}")
    return receive_exact(channel, size)


def decode_session(payload: bytes) -> dict[str, Any]:
    if len(payload) < SESSION_HEADER or payload[:4] != SESSION_MAGIC:
        raise AssertionError("invalid NOS1 frame")
    if payload[4] != SESSION_VERSION:
        raise AssertionError("unexpected NOS1 version")
    length = struct.unpack("!I", payload[96:100])[0]
    if len(payload) != SESSION_HEADER + length:
        raise AssertionError("NOS1 payload length mismatch")
    return {
        "kind": payload[5],
        "flags": struct.unpack("!H", payload[6:8])[0],
        "session": payload[8:40],
        "sequence": struct.unpack("!I", payload[40:44])[0],
        "operation": payload[44:76],
        "max_operations": struct.unpack("!I", payload[76:80])[0],
        "max_bytes": struct.unpack("!Q", payload[80:88])[0],
        "max_lifetime_ms": struct.unpack("!I", payload[88:92])[0],
        "idle_timeout_ms": struct.unpack("!I", payload[92:96])[0],
        "payload": payload[100:],
    }


def encode_session(
    kind: int,
    session: bytes,
    sequence: int,
    operation_id: bytes,
    payload: bytes = b"",
    *,
    flags: int = 0,
    limits: tuple[int, int, int, int] | None = None,
) -> bytes:
    if len(session) != 32 or len(operation_id) != 32:
        raise AssertionError("invalid NOS1 identifiers")
    max_operations, max_bytes, lifetime, idle = limits or (0, 0, 0, 0)
    header = (
        SESSION_MAGIC
        + bytes([SESSION_VERSION, kind])
        + struct.pack("!H", flags)
        + session
        + struct.pack("!I", sequence)
        + operation_id
        + struct.pack("!I", max_operations)
        + struct.pack("!Q", max_bytes)
        + struct.pack("!I", lifetime)
        + struct.pack("!I", idle)
        + struct.pack("!I", len(payload))
    )
    if len(header) != SESSION_HEADER:
        raise AssertionError(f"NOS1 header length {len(header)}")
    return header + payload


def record_recipient(record: bytes) -> str:
    if len(record) < 37 or record[:4] != b"NOA1" or record[4] not in (1, 2):
        raise AssertionError("unexpected evidence record")
    offset = 37
    issuer_length = struct.unpack("!H", record[offset : offset + 2])[0]
    offset += 2 + issuer_length
    recipient_length = struct.unpack("!H", record[offset : offset + 2])[0]
    offset += 2
    return record[offset : offset + recipient_length].decode()


class MisbindingTlsPeer:
    """Independent peer that returns a valid receipt in the wrong NOS1 envelope."""

    def __init__(self, h: Harness, port: int):
        self.h = h
        self.port = port
        self.ready = threading.Event()
        self.done = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.error: BaseException | None = None
        self.request_operation: str | None = None

    def start(self) -> None:
        self.thread.start()
        if not self.ready.wait(5):
            raise AssertionError("misbinding TLS peer did not become ready")
        if self.error is not None:
            raise self.error

    def wait(self) -> None:
        if not self.done.wait(8):
            raise AssertionError("misbinding TLS peer did not finish")
        self.thread.join(timeout=2)
        if self.error is not None:
            raise self.error

    def _run(self) -> None:
        try:
            a = self.h.identity("A")
            b = self.h.identity("B")
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.minimum_version = ssl.TLSVersion.TLSv1_3
            context.maximum_version = ssl.TLSVersion.TLSv1_3
            context.set_alpn_protocols(["natrav-overlay/1"])
            context.load_cert_chain(str(b.certificate), str(b.private_key))
            context.load_verify_locations(cafile=str(a.certificate))
            context.verify_mode = ssl.CERT_REQUIRED
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
                listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                listener.bind(("127.0.0.1", self.port))
                listener.listen(4)
                listener.settimeout(8)
                self.ready.set()
                raw, _ = listener.accept()
                with raw:
                    with context.wrap_socket(raw, server_side=True) as channel:
                        channel.settimeout(5)
                        if channel.version() != "TLSv1.3":
                            raise AssertionError("fixture did not negotiate TLS 1.3")
                        if channel.selected_alpn_protocol() != "natrav-overlay/1":
                            raise AssertionError("fixture ALPN mismatch")
                        hello = json.loads(receive_frame(channel))
                        if hello.get("kind") != "HELLO":
                            raise AssertionError("fixture expected HELLO")
                        if hello.get("required_capabilities") != CAPABILITIES:
                            raise AssertionError("fixture capability mismatch")
                        channel.sendall(frame(hello_ack("B", hello["request_id"])))

                        opened = decode_session(receive_frame(channel))
                        if opened["kind"] != SESSION_OPEN:
                            raise AssertionError("fixture expected NOS1 OPEN")
                        selected = (
                            opened["max_operations"],
                            opened["max_bytes"],
                            opened["max_lifetime_ms"],
                            opened["idle_timeout_ms"],
                        )
                        channel.sendall(frame(encode_session(
                            SESSION_OPEN_ACK,
                            opened["session"],
                            0,
                            b"\0" * 32,
                            limits=selected,
                        )))

                        request = decode_session(receive_frame(channel))
                        if request["kind"] != SESSION_REQUEST or request["sequence"] != 1:
                            raise AssertionError("fixture expected first NOS1 request")
                        operation_hex = request["operation"].hex()
                        self.request_operation = operation_hex
                        recipient = record_recipient(request["payload"])
                        receipt = encode_receipt(
                            operation_hex,
                            recipient,
                            1,
                            1,
                            record_digest(request["payload"]),
                        )
                        wrong = hashlib.sha256(b"deliberately-wrong-session-operation").digest()
                        if wrong == request["operation"]:
                            raise AssertionError("wrong-operation fixture collision")
                        response = encode_session(
                            SESSION_RESPONSE,
                            request["session"],
                            request["sequence"],
                            wrong,
                            receipt,
                        )
                        channel.sendall(frame(response))
                        time.sleep(0.05)
        except BaseException as exc:
            self.error = exc
            self.ready.set()
        finally:
            self.done.set()


def write_config(
    h: Harness,
    name: str,
    node: str,
    state: Path,
    port: int,
    routes: list[tuple[str, int, int, int, int, int]],
    *,
    trusts: list[str] | None = None,
    authorizations: list[tuple[str, str]] | None = None,
    deadline_ms: int = 500,
    session_operations: int = 32,
    session_bytes: int = 4_194_304,
    session_lifetime_ms: int = 30_000,
    session_idle_ms: int = 2_000,
    global_records: int = 4096,
    global_bytes: int = 67_108_864,
    peer_records: int = 1024,
    peer_bytes: int = 16_777_216,
    peer_workers: int = 4,
) -> Path:
    identity = h.identity(node)
    path = h.work / f"{name}.conf"
    lines = [
        "NATRAV_OVERLAY_CONFIG_V6",
        f"node={node}",
        f"state={state}",
        f"listen=127.0.0.1:{port}",
        "control=control.sock",
        f"identity_cert={identity.certificate}",
        f"identity_key={identity.private_key}",
        f"identity_pin={identity.spki_sha256}",
        f"identity_generation={node.lower()}-g1",
        f"deadline_ms={deadline_ms}",
        f"peer_workers={peer_workers}",
        "peer_queue_capacity=64",
        "control_workers=3",
        "control_queue_capacity=64",
        f"session_max_operations={session_operations}",
        f"session_max_bytes={session_bytes}",
        f"session_max_lifetime_ms={session_lifetime_ms}",
        f"session_idle_timeout_ms={session_idle_ms}",
        f"outbox_global_max_records={global_records}",
        f"outbox_global_max_payload_bytes={global_bytes}",
        f"outbox_peer_max_records={peer_records}",
        f"outbox_peer_max_payload_bytes={peer_bytes}",
    ]
    configured: set[str] = set()
    for peer, peer_port, initial, maximum, attempts, expiry in routes:
        peer_identity = h.identity(peer)
        lines.append(
            f"peer={peer},127.0.0.1:{peer_port},{initial},{maximum},{attempts},{expiry}"
        )
        lines.append(
            f"peer_key={peer},{peer.lower()}-g1,ACTIVE,{peer_identity.spki_sha256}"
        )
        configured.add(peer)
    for peer in trusts or []:
        if peer in configured:
            continue
        peer_identity = h.identity(peer)
        lines.append(
            f"peer_key={peer},{peer.lower()}-g1,ACTIVE,{peer_identity.spki_sha256}"
        )
        configured.add(peer)
    for peer, scope in authorizations or []:
        lines.append(f"authorize={peer},*,EVIDENCE,{scope}")
    path.write_text("\n".join(lines) + "\n")
    path.chmod(0o600)
    return path


def submit(
    h: Harness,
    label: str,
    control: Path,
    issuer: str,
    recipient: str,
    scope: str,
    operation_id: str,
    payload: str,
    *,
    expected: int = 0,
) -> dict[str, Any] | None:
    return h.run(
        label,
        [
            "submit", "--control", str(control), "--node", issuer,
            "--peer", recipient, "--scope", scope,
            "--operation", operation_id, "--payload-text", payload,
            "--deadline-ms", "2000",
        ],
        expected=expected,
    )


def revise(
    h: Harness,
    label: str,
    control: Path,
    issuer: str,
    recipient: str,
    scope: str,
    operation_id: str,
    parent: str,
    payload: str,
) -> dict[str, Any] | None:
    return h.run(
        label,
        [
            "revise", "--control", str(control), "--node", issuer,
            "--peer", recipient, "--scope", scope,
            "--operation", operation_id, "--corrects", parent,
            "--payload-text", payload, "--deadline-ms", "2000",
        ],
    )


def outbox_entry(status: dict[str, Any], operation_id: str) -> dict[str, Any]:
    return next(
        item for item in status["outbox"]["entries"]
        if item["operation_id"] == operation_id
    )


def run_suite(h: Harness) -> None:
    def strict_configuration_and_operation_cap() -> None:
        root = h.runtime / "session-bounds"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        scope = "sessions/operation-cap"
        b_conf = write_config(
            h, "bounds-b", "B", b_state, b_port, [],
            trusts=["A"], authorizations=[("A", scope)],
            session_operations=3, session_idle_ms=3000,
        )
        a_conf = write_config(
            h, "bounds-a", "A", a_state, a_port,
            [("B", b_port, 50, 100, 20, 30_000)],
            session_operations=3, session_idle_ms=3000,
        )
        checked = h.run("bounds-config-valid", ["config-check", "--config", str(a_conf)])
        h.check(checked is not None and checked["format"] == "NATRAV_OVERLAY_CONFIG_V6", "session configuration version is explicit")
        h.check(checked["sessions"]["protocol"] == "NOS1", "config-check reports NOS1 contract")
        h.check(checked["sessions"]["maximum_operations"] == 3, "operation cap is inspectable")

        invalid = h.work / "bounds-invalid.conf"
        invalid.write_text(a_conf.read_text().replace(
            "session_max_lifetime_ms=30000\n", "session_max_lifetime_ms=100\n"
        ).replace(
            "session_idle_timeout_ms=3000\n", "session_idle_timeout_ms=200\n"
        ))
        invalid.chmod(0o600)
        rejected = h.run(
            "bounds-config-invalid",
            ["config-check", "--config", str(invalid)],
            expected=3,
        )
        h.check(rejected is not None and rejected.get("code") == "SESSION_LIMIT_INVALID", "idle timeout cannot exceed session lifetime")

        b = h.start("bounds-b", b_conf, b_state)
        a = h.start("bounds-a", a_conf, a_state)
        operations = [operation(f"session-operation-cap-{index}") for index in range(7)]
        for index, op_id in enumerate(operations):
            submit(h, f"bounds-submit-{index}", a.control, "A", "B", scope, op_id, f"bounded-{index}")
        h.wait(
            "operation cap retires and replaces sessions",
            lambda: h.status("bounds-wait", a_state)["outbox"]["acked"] == 7,
        )
        a_status = h.status("bounds-a-status", a_state)
        b_status = h.status("bounds-b-status", b_state)
        session = a_status["peers"][0]["session"]
        h.check(session["opened"] == 3, "seven operations at cap three require three sessions")
        h.check(session["retired"] >= 2, "operation-bound sessions retire explicitly")
        h.check(session["failed"] == 0, "operation-cap retirement is clean")
        h.check(b_status["service"]["peer_session_connections"] == 3, "receiver observed the bounded connection count")
        h.check(b_status["service"]["peer_session_operations"] == 7, "receiver observed every capped operation")
        a.shutdown(); b.shutdown()

    h.case("strict_session_configuration_and_operation_cap", strict_configuration_and_operation_cap)

    def batching_idle_and_operation_retirement() -> None:
        root = h.runtime / "batching"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        scope = "sessions/batch"
        b_conf = write_config(
            h, "batch-b", "B", b_state, b_port, [],
            trusts=["A"], authorizations=[("A", scope)],
            session_operations=16, session_idle_ms=800,
        )
        a_conf = write_config(
            h, "batch-a", "A", a_state, a_port,
            [("B", b_port, 50, 200, 30, 30_000)],
            session_operations=16, session_idle_ms=800,
        )
        b = h.start("batch-b", b_conf, b_state)
        a = h.start("batch-a", a_conf, a_state)
        first_operations = [operation(f"session-batch-first-{index}") for index in range(12)]
        for index, op_id in enumerate(first_operations):
            submit(h, f"batch-submit-{index}", a.control, "A", "B", scope, op_id, f"batch-{index}")
        h.wait(
            "twelve operations acknowledged over reusable session",
            lambda: h.status("batch-wait", a_state)["outbox"]["acked"] == 12,
        )
        a_status = h.status("batch-a-active", a_state)
        b_status = h.status("batch-b-active", b_state)
        peer = a_status["peers"][0]
        h.check(peer["session"]["opened"] == 1, "twelve operations used one outbound session")
        h.check(peer["session"]["reused"] >= 11, "session reuse counted for later operations")
        h.check(peer["session"]["operations"] == 12, "outbound session operations counted exactly")
        h.check(b_status["service"]["peer_session_connections"] == 1, "receiver observed one NOS1 session")
        h.check(b_status["service"]["peer_session_operations"] == 12, "receiver observed all session operations")
        h.check(b_status["inbound_records"] == 12, "receiver admitted twelve records")

        retired: dict[str, Any] = {}
        def idle_retired() -> bool:
            retired.clear(); retired.update(h.status("batch-idle-wait", a_state))
            session = retired["peers"][0]["session"]
            return session["state"] == "DISCONNECTED" and session["retired"] >= 1
        h.wait("idle session retires cleanly", idle_retired, 5.0)
        h.check(retired["peers"][0]["session"]["failed"] == 0, "idle retirement is not a failed session")
        h.wait(
            "receiver observed clean session close",
            lambda: h.status("batch-close-wait", b_state)["service"]["peer_session_clean_closes"] >= 1,
            5.0,
        )

        later = [operation(f"session-batch-later-{index}") for index in range(5)]
        for index, op_id in enumerate(later):
            submit(h, f"batch-later-{index}", a.control, "A", "B", scope, op_id, f"later-{index}")
        h.wait(
            "later work opens a replacement session",
            lambda: h.status("batch-later-wait", a_state)["outbox"]["acked"] == 17,
        )
        final = h.status("batch-final", a_state)
        h.check(final["peers"][0]["session"]["opened"] == 2, "post-idle work opened exactly one replacement")
        h.check(final["outbox"]["acked"] == 17, "all batched work has durable receipts")
        a.shutdown(); b.shutdown()

    h.case("many_operations_fewer_handshakes_and_idle_retirement", batching_idle_and_operation_retirement)

    def mixed_results_on_one_session() -> None:
        root = h.runtime / "mixed"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        allowed = "sessions/allowed"
        correction_scope = "sessions/correction"
        denied_scope = "sessions/denied"
        b_conf = write_config(
            h, "mixed-b", "B", b_state, b_port, [],
            trusts=["A"],
            authorizations=[("A", allowed), ("A", correction_scope)],
            session_idle_ms=3000,
        )
        a_conf = write_config(
            h, "mixed-a", "A", a_state, a_port,
            [("B", b_port, 1000, 1000, 20, 30_000)],
            session_idle_ms=3000,
        )
        b = h.start("mixed-b", b_conf, b_state)
        a = h.start("mixed-a", a_conf, a_state)
        ok_one = operation("session-mixed-ok-one")
        denied = operation("session-mixed-denied")
        transient = operation("session-mixed-transient")
        missing_parent = operation("session-mixed-missing-parent")
        ok_two = operation("session-mixed-ok-two")
        submit(h, "mixed-ok-one", a.control, "A", "B", allowed, ok_one, "one")
        submit(h, "mixed-denied", a.control, "A", "B", denied_scope, denied, "denied")
        revise(h, "mixed-transient", a.control, "A", "B", correction_scope, transient, missing_parent, "missing")
        submit(h, "mixed-ok-two", a.control, "A", "B", allowed, ok_two, "two")

        latest: dict[str, Any] = {}
        def mixed_visible() -> bool:
            latest.clear(); latest.update(h.status("mixed-wait", a_state))
            return (
                latest["outbox"]["acked"] == 2
                and latest["outbox"]["rejected"] == 1
                and outbox_entry(latest, transient)["last_error_code"] == "CORRECTION_PARENT_NOT_FOUND"
            )
        h.wait("mixed ACK, terminal rejection, and transient response", mixed_visible)
        peer = latest["peers"][0]
        h.check(peer["session"]["opened"] == 1, "mixed outcomes shared one authenticated session")
        h.check(peer["session"]["operations"] >= 4, "mixed session accounted each response")
        h.check(outbox_entry(latest, denied)["status"] == "REJECTED", "authorization denial is exact terminal outcome")
        h.check(outbox_entry(latest, transient)["status"] == "PENDING", "missing parent remains transient and pending")
        b_status = h.status("mixed-b-status", b_state)
        h.check(b_status["inbound_records"] == 2, "denied/transient records were not admitted")
        h.check(b_status["authorization"]["denied"] == 1, "authorization denial retained once")
        h.check(b_status["service"]["peer_session_connections"] == 1, "receiver kept one mixed-result session")
        h.check(b_status["service"]["peer_session_operations"] >= 4, "receiver counted mixed session operations")
        cancelled = h.run(
            "mixed-cancel-transient",
            ["cancel", "--control", str(a.control), "--operation", transient,
             "--reason", "test cleanup after transient classification"],
        )
        h.check(cancelled is not None and cancelled.get("ok") is True, "pending transient can be cancelled explicitly")
        a.shutdown(); b.shutdown()

    h.case("mixed_receipt_rejection_and_transient_results", mixed_results_on_one_session)

    def lost_response_reconnects_without_duplicate_admission() -> None:
        root = h.runtime / "lost-response"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        scope = "sessions/lost-response"
        op_id = operation("session-lost-response-operation")
        b_conf = write_config(
            h, "lost-b", "B", b_state, b_port, [],
            trusts=["A"], authorizations=[("A", scope)],
            session_idle_ms=3000,
        )
        a_conf = write_config(
            h, "lost-a", "A", a_state, a_port,
            [("B", b_port, 50, 100, 20, 20_000)],
            session_idle_ms=3000,
        )
        b = h.start(
            "lost-b", b_conf, b_state,
            {"NATRAV_OVERLAY_TEST_SESSION_DROP_AFTER_ADMISSION_OPERATION": op_id},
        )
        a = h.start("lost-a", a_conf, a_state)
        submit(h, "lost-submit", a.control, "A", "B", scope, op_id, "committed-before-response-loss")
        h.wait(
            "lost response is recovered by replay",
            lambda: h.status("lost-wait", a_state)["outbox"]["acked"] == 1,
            8.0,
        )
        a_status = h.status("lost-a-status", a_state)
        b_status = h.status("lost-b-status", b_state)
        entry = outbox_entry(a_status, op_id)
        h.check(entry["attempts"] >= 2, "lost response consumed at least two durable attempts")
        h.check(a_status["peers"][0]["session"]["opened"] >= 2, "sender reopened after mid-session loss")
        h.check(a_status["peers"][0]["session"]["failed"] >= 1, "failed session is accounted")
        h.check(b_status["inbound_records"] == 1, "replay did not multiply recipient admission")
        h.check(b_status["service"]["peer_duplicate"] >= 1, "recipient observed duplicate replay")
        h.check("TEST_SESSION_DROP_AFTER_ADMISSION" in b.stderr_path.read_text(), "fault hook was exercised and retained")
        a.shutdown(); b.shutdown()

    h.case("mid_session_response_loss_and_duplicate_safe_reconnect", lost_response_reconnects_without_duplicate_admission)

    def misbound_response_is_rejected_then_real_peer_recovers() -> None:
        root = h.runtime / "misbound"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        scope = "sessions/misbound"
        op_id = operation("session-misbound-operation")
        fixture = MisbindingTlsPeer(h, b_port)
        fixture.start()
        a_conf = write_config(
            h, "misbound-a", "A", a_state, a_port,
            [("B", b_port, 500, 500, 20, 30_000)],
            session_idle_ms=3000,
        )
        a = h.start("misbound-a", a_conf, a_state)
        submit(h, "misbound-submit", a.control, "A", "B", scope, op_id, "bind-me-exactly")

        observed: dict[str, Any] = {}
        def binding_failure() -> bool:
            observed.clear(); observed.update(h.status("misbound-wait", a_state))
            return outbox_entry(observed, op_id)["last_error_code"] == "SESSION_RESPONSE_BINDING_REJECTED"
        h.wait("misbound response remains transient and pending", binding_failure, 7.0)
        fixture.wait()
        h.check(fixture.request_operation == op_id, "fixture observed intended operation")
        h.check(outbox_entry(observed, op_id)["status"] == "PENDING", "misbound response did not acknowledge work")
        h.check(observed["peers"][0]["session"]["failed"] >= 1, "binding failure retired the session")

        b_conf = write_config(
            h, "misbound-b", "B", b_state, b_port, [],
            trusts=["A"], authorizations=[("A", scope)],
            session_idle_ms=3000,
        )
        b = h.start("misbound-b", b_conf, b_state)
        h.wait(
            "real peer receives work after malicious response",
            lambda: h.status("misbound-recovery", a_state)["outbox"]["acked"] == 1,
            8.0,
        )
        final = h.status("misbound-final", a_state)
        h.check(final["peers"][0]["session"]["opened"] >= 2, "replacement authenticated session opened")
        h.check(h.status("misbound-b-final", b_state)["inbound_records"] == 1, "real peer admitted operation once")
        a.shutdown(); b.shutdown()

    h.case("misbound_session_response_rejected_and_recovered", misbound_response_is_rejected_then_real_peer_recovers)

    def quota_fairness_kill_restart_and_compaction() -> None:
        root = h.runtime / "governed"
        root.mkdir()
        a_state, b_state, c_state = root / "a", root / "b", root / "c"
        a_port, b_port, c_port = free_port(), free_port(), free_port()
        b_scope, c_scope = "sessions/governed-b", "sessions/governed-c"
        b_conf = write_config(
            h, "governed-b", "B", b_state, b_port, [],
            trusts=["A"], authorizations=[("A", b_scope)],
            session_operations=16,
        )
        c_conf = write_config(
            h, "governed-c", "C", c_state, c_port, [],
            trusts=["A"], authorizations=[("A", c_scope)],
            session_operations=16,
        )
        a_conf = write_config(
            h, "governed-a", "A", a_state, a_port,
            [
                ("B", b_port, 100, 200, 50, 60_000),
                ("C", c_port, 50, 200, 50, 60_000),
            ],
            deadline_ms=700,
            session_operations=16,
            peer_records=3,
            global_records=32,
        )
        c = h.start("governed-c", c_conf, c_state)
        blackhole = Blackhole(b_port)
        blackhole.start()
        a = h.start("governed-a-1", a_conf, a_state)
        b_ops = [operation(f"governed-b-{index}") for index in range(4)]
        for index in range(3):
            submit(h, f"governed-b-submit-{index}", a.control, "A", "B", b_scope, b_ops[index], f"b-{index}")
        excess = submit(
            h, "governed-b-excess", a.control, "A", "B", b_scope, b_ops[3], "b-excess", expected=3,
        )
        h.check(excess is not None and excess.get("code") == "OUTBOX_PEER_RECORD_LIMIT", "per-peer quota rejects first excess record")

        c_ops = [operation(f"governed-c-{index}") for index in range(8)]
        for index, op_id in enumerate(c_ops):
            # The configured per-peer queue admits exactly three pending records.
            # Wait for the previous C batch to release its reservations before
            # crossing that intentional limit; B remains full and stalled.
            if index in (3, 6):
                h.wait(
                    f"C batch through {index} releases per-peer capacity",
                    lambda expected=index: h.status(
                        f"governed-c-batch-{expected}", a_state
                    )["outbox"]["acked"] == expected,
                    8.0,
                )
            submit(h, f"governed-c-submit-{index}", a.control, "A", "C", c_scope, op_id, f"c-{index}")
        h.wait(
            "C progresses while B TLS session stalls",
            lambda: h.status("governed-c-progress", a_state)["outbox"]["acked"] == 8,
            8.0,
        )
        before_kill = h.status("governed-before-kill", a_state)
        b_peer = next(peer for peer in before_kill["peers"] if peer["node"] == "B")
        c_peer = next(peer for peer in before_kill["peers"] if peer["node"] == "C")
        h.check(b_peer["pending"] == 3, "stalled B retains three governed obligations")
        h.check(c_peer["acked"] == 8, "C received all work independently")
        h.check(c_peer["session"]["opened"] == 1, "C batch used one session")
        h.check(blackhole.accepted.wait(3), "blackhole accepted B connection")

        a.kill()
        blackhole.close()
        b = h.start("governed-b", b_conf, b_state)
        a2 = h.start("governed-a-2", a_conf, a_state)
        h.wait(
            "restart delivers governed B obligations",
            lambda: h.status("governed-restart-wait", a_state)["outbox"]["acked"] == 11,
            10.0,
        )
        restored = h.status("governed-restored", a_state)
        h.check(restored["outbox"]["pending"] == 0, "all pre-kill obligations resolved")
        h.check(h.status("governed-b-status", b_state)["inbound_records"] == 3, "B admitted queued records once")
        h.check(h.status("governed-c-status", c_state)["inbound_records"] == 8, "C retained exactly eight records")

        digest_before = restored["storage"]["logical_state_digest"]
        compacted = h.run("governed-compact", ["compact", "--control", str(a2.control)])
        h.check(compacted is not None and compacted.get("ok") is True, "live compaction succeeds with session history")
        after_compact = h.status("governed-after-compact", a_state)
        h.check(after_compact["storage"]["logical_state_digest"] == digest_before, "compaction preserves governed logical state")

        submit(h, "governed-b-after-release", a2.control, "A", "B", b_scope, b_ops[3], "capacity-released")
        h.wait(
            "released quota admits and delivers replacement work",
            lambda: h.status("governed-release-wait", a_state)["outbox"]["acked"] == 12,
            8.0,
        )
        h.check(h.status("governed-b-after", b_state)["inbound_records"] == 4, "released capacity delivered one additional record")
        a2.shutdown(); b.shutdown(); c.shutdown()

    h.case("session_quota_fairness_kill_restart_and_compaction", quota_fairness_kill_restart_and_compaction)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, default=Path("node/bin/natrav-overlay"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output directory must not exist")
    harness = Harness(args.binary, args.output)
    # The imported harness uses a historical temporary-directory label only;
    # replace it so simultaneous revision tests cannot collide.
    replacement = Path("/tmp") / f"natrav-overlay-0497-session-tests-{os.getpid()}"
    if harness.runtime.exists():
        shutil.rmtree(harness.runtime)
    harness.runtime = replacement
    harness.runtime.mkdir()
    started = time.time()
    status = "FAIL"
    return_code = 1
    try:
        run_suite(harness)
        status = "PASS"
        return_code = 0
    except BaseException as exc:
        (harness.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_PEER_SESSION_TESTS_V1",
            "status": status,
            "binary": str(harness.binary),
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "started_unix": started,
            "elapsed_seconds": time.time() - started,
        }
        (harness.output / "SUMMARY.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
        (harness.output / "CASES.json").write_text(json.dumps(harness.cases, indent=2, sort_keys=True) + "\n")
        (harness.output / "COMMANDS.json").write_text(json.dumps(harness.commands, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary, sort_keys=True))
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
