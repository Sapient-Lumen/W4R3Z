#!/usr/bin/env python3
"""Explicit numeric point-to-point UDP packet carrier regression."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from typing import Any

from tls_test_support import IdentityFactory


EXPECTED_FEATURE = "NUMERIC_POINT_TO_POINT_UDP_PACKET_CARRIER_V1"


def run_command(
    command: list[str],
    *,
    stdout_path: Path,
    stderr_path: Path,
    timeout: float,
    environment: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        timeout=timeout,
        env=environment,
    )
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)
    return completed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    source_root = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    binary = args.binary.resolve(strict=True)
    if output.exists() or output == source_root or source_root in output.parents:
        parser.error("output must be new and outside the source tree")
    output.mkdir(parents=True)

    started = time.monotonic()
    assertions = 0
    commands: list[dict[str, Any]] = []
    cases: list[dict[str, Any]] = []

    def check(condition: bool, detail: str) -> None:
        nonlocal assertions
        assertions += 1
        if not condition:
            raise AssertionError(detail)

    def record_case(name: str, before: int, begin: float) -> None:
        cases.append(
            {
                "name": name,
                "status": "PASS",
                "assertions": assertions - before,
                "elapsed_seconds": time.monotonic() - begin,
            }
        )

    def udp_locator(local: str, remote: str, link: str = "5544505445535431") -> str:
        return (
            f"udp-v1|local={local}|remote={remote}|mtu=1200|"
            f"link={link}|epoch=7|profile=1"
        )

    status = "FAIL"
    failure: str | None = None
    try:
        before = assertions
        begin = time.monotonic()
        version_run = run_command(
            [str(binary), "version"],
            stdout_path=output / "version.stdout.txt",
            stderr_path=output / "version.stderr.txt",
            timeout=10,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append(
            {"label": "version", "returncode": version_run.returncode,
             "args": ["version"]}
        )
        check(version_run.returncode == 0, "version command succeeds")
        lines = [line for line in version_run.stdout.splitlines() if line.strip()]
        check(len(lines) == 1, "version emits one JSON line")
        version = json.loads(lines[0])
        check(version.get("version") == "0613", "revision is 0613")
        check(version.get("udp_transport") == EXPECTED_FEATURE,
              "UDP packet-carrier marker is exact")
        check(version.get("packet_link_stream") ==
              "PACKET_LINK_ORDERED_BYTE_STREAM_ADAPTER_V1",
              "finite packet-link ordered-stream marker is retained")
        check(version.get("packet_link_core") ==
              "FINITE_PACKET_LINK_SERVICE_V1",
              "finite packet-link core marker is retained")
        check(version.get("packet_port") ==
              "OWNED_COMPLETE_DATAGRAM_PACKET_PORT_V1",
              "owned complete-datagram packet-port marker is exact")
        check(version.get("tls_byte_channel") == "OPENSSL_BYTE_CHANNEL_BIO_V1",
              "descriptor-free TLS marker is retained")
        check(version.get("serial_transport") ==
              "POSIX_SERIAL_TTY_ORDERED_BYTE_STREAM_V1",
              "serial carrier marker is retained")
        record_case("revision metadata", before, begin)

        before = assertions
        begin = time.monotonic()
        transport_header = (source_root / "node/src/transport.hpp").read_text()
        udp_header = (source_root / "node/src/udp_transport.hpp").read_text()
        udp_source = (source_root / "node/src/udp_transport.cpp").read_text()
        packet_port_header = (source_root / "node/src/packet_port.hpp").read_text()
        packet_port_source = (source_root / "node/src/packet_port.cpp").read_text()
        transport_source = (source_root / "node/src/transport.cpp").read_text()
        config_source = (source_root / "node/src/config.cpp").read_text()
        tls_source = (source_root / "node/src/tls.cpp").read_text()
        node_source = (source_root / "node/src/node.cpp").read_text()
        build_script = (source_root / "node/build.sh").read_text()
        check("udp = 3U" in transport_header and "UdpTransportLocator" in transport_header,
              "UDP is an explicit typed production carrier")
        check("udp-v1|" in udp_source and "UDP_LOCATOR_NONCANONICAL" in udp_source,
              "UDP locator has a versioned canonical grammar")
        check("inet_pton" in udp_source and "inet_ntop" in udp_source and
              "getaddrinfo" not in udp_source,
              "UDP endpoints are numeric-only and canonicalized without DNS")
        check("SOCK_DGRAM" in udp_source and "::bind" in udp_source and
              "::connect" in udp_source and "O_NONBLOCK" in udp_source and
              "make_udp_nonblocking" in udp_source,
              "UDP owns a bound connected nonblocking datagram socket")
        check("MSG_TRUNC" in udp_source and "UDP_DATAGRAM_TRUNCATED" in udp_source,
              "oversize datagrams are rejected explicitly")
        check("SO_BROADCAST" in udp_source and "IN6_IS_ADDR_MULTICAST" in udp_source and
              "INADDR_BROADCAST" in udp_source,
              "broadcast and multicast endpoints are rejected or disabled")
        check("OwnedCompleteDatagramPacketPort" in packet_port_header and
              "FinitePacketStream" in packet_port_source and
              "make_packet_port_ordered_byte_stream" in udp_source,
              "UDP enters the finite packet service through the owned packet-port seam")
        check("FinitePacketStream" not in udp_source and
              "UdpPacketLinkOrderedByteStream" not in udp_source,
              "UDP no longer owns packet reconstruction or the ordered-stream loop")
        check("kUdpSocketBufferBytes" in udp_source and
              "max_reassembly_bytes" in udp_source and
              "max_inflight_frames" in udp_source,
              "socket, reassembly, and in-flight resources are explicitly bounded")
        check("elapsed_intervals" in packet_port_source and
              "while (now >= next_tick_)" not in packet_port_source,
              "logical clock catch-up remains constant work after long suspension")
        check("source address" not in udp_header.lower() and
              "identity" not in udp_header.lower() and "tls" not in udp_header.lower(),
              "carrier declarations do not derive peer identity or trust")
        check("CONFIG_UDP_ROLE_CONFLICT" in config_source and
              "CONFIG_UDP_SELF_ROUTE" in config_source,
              "persistent configuration rejects conflicting local UDP ownership")
        check('code.starts_with("UDP_")' in tls_source and
              'error.code().starts_with("UDP_")' in node_source,
              "UDP callback failures retain transport-error classification")
        check("src/udp_transport.cpp" in build_script and
              "src/finite_packet_link.cpp" in build_script and
              "src/packet_port.cpp" in build_script,
              "normal product build links UDP, the owned port, and the finite packet service")
        parse_start = transport_source.index("TransportKind parse_transport_kind")
        parse_end = transport_source.index("std::string_view transport_kind_name")
        parse_body = transport_source[parse_start:parse_end]
        check('text == "tcp"' in parse_body and 'text == "serial"' in parse_body and
              'text == "udp"' in parse_body and "packet_link" not in parse_body and
              "virtual_link" not in parse_body,
              "configured parser exposes TCP, serial, UDP, and Unix datagrams but not private fixtures")
        record_case("source authority and ownership boundary", before, begin)

        identities = IdentityFactory(output / "identities")
        client = identities.identity("udp-client")
        server = identities.identity("udp-server")

        def write_v13_config(
            path: Path,
            *,
            listen: str,
            routes: list[tuple[str, str, str]],
        ) -> None:
            lines = [
                "NATRAV_OVERLAY_CONFIG_V13",
                "runtime_generation=udp-test-v1",
                "node=CLIENT",
                f"state={output / ('state-' + path.stem)}",
                f"listen={listen}",
                "control=control.sock",
                f"identity_cert={client.certificate}",
                f"identity_key={client.private_key}",
                f"identity_pin={client.spki_sha256}",
                "identity_generation=client-g1",
                "deadline_ms=500",
                "peer_workers=2",
                "peer_queue_capacity=8",
                "control_workers=1",
                "control_queue_capacity=8",
                "session_max_operations=8",
                "session_max_bytes=1048576",
                "session_max_lifetime_ms=10000",
                "session_idle_timeout_ms=3000",
                "outbox_global_max_records=32",
                "outbox_global_max_payload_bytes=1048576",
                "outbox_peer_max_records=16",
                "outbox_peer_max_payload_bytes=524288",
                f"local_control={os.geteuid()},ALL",
                "peer=SERVER,10,100,3,10000",
                f"peer_key=SERVER,server-g1,ACTIVE,{server.spki_sha256}",
                "authorize=SERVER,*,EVIDENCE,udp/test",
            ]
            for route_id, priority, locator in routes:
                lines.append(
                    f"peer_route=SERVER,{route_id},{priority},ENABLED,{locator}"
                )
            path.write_text("\n".join(lines) + "\n")
            path.chmod(0o600)

        before = assertions
        begin = time.monotonic()
        listener = udp_locator("127.0.0.1:45100", "127.0.0.1:45101")
        route_a = udp_locator("127.0.0.1:45102", "127.0.0.1:45103")
        route_b = udp_locator(
            "127.0.0.1:45104", "127.0.0.1:45105", "5544505445535432")
        valid_config = output / "udp-valid.conf"
        write_v13_config(
            valid_config, listen=listener,
            routes=[("udp-a", "0", route_a), ("udp-b", "1", route_b)],
        )
        valid_run = run_command(
            [str(binary), "config-check", "--config", str(valid_config)],
            stdout_path=output / "config-valid.stdout.txt",
            stderr_path=output / "config-valid.stderr.txt",
            timeout=15,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append({"label": "config-valid", "returncode": valid_run.returncode,
                         "args": ["config-check", "--config", str(valid_config)]})
        check(valid_run.returncode == 0, "canonical UDP listener and routes are accepted")
        valid_json = json.loads(valid_run.stdout.strip())
        check(valid_json["listen"] == listener,
              "configuration JSON retains the exact canonical UDP listener")
        endpoints = [item["endpoint"] for item in valid_json["peers"][0]["routes"]]
        check(endpoints == [route_a, route_b],
              "configuration JSON retains canonical ordered UDP routes")

        role_config = output / "udp-role-conflict.conf"
        write_v13_config(
            role_config, listen=listener,
            routes=[("udp", "0", udp_locator(
                "127.0.0.1:45100", "127.0.0.1:45106", "5544505445535433"))],
        )
        role_run = run_command(
            [str(binary), "config-check", "--config", str(role_config)],
            stdout_path=output / "config-role-conflict.stdout.txt",
            stderr_path=output / "config-role-conflict.stderr.txt",
            timeout=15,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append({"label": "config-role-conflict",
                         "returncode": role_run.returncode,
                         "args": ["config-check", "--config", str(role_config)]})
        role_json = json.loads(role_run.stdout.strip())
        check(role_run.returncode == 3 and
              role_json.get("code") == "CONFIG_UDP_ROLE_CONFLICT",
              "one local UDP endpoint cannot be listener and outbound route")

        self_config = output / "udp-self-route.conf"
        write_v13_config(
            self_config, listen=listener,
            routes=[("udp", "0", udp_locator(
                "127.0.0.1:45107", "127.0.0.1:45100", "5544505445535434"))],
        )
        self_run = run_command(
            [str(binary), "config-check", "--config", str(self_config)],
            stdout_path=output / "config-self-route.stdout.txt",
            stderr_path=output / "config-self-route.stderr.txt",
            timeout=15,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append({"label": "config-self-route", "returncode": self_run.returncode,
                         "args": ["config-check", "--config", str(self_config)]})
        self_json = json.loads(self_run.stdout.strip())
        check(self_run.returncode == 3 and
              self_json.get("code") == "CONFIG_UDP_SELF_ROUTE",
              "an outbound UDP route cannot target the local listener endpoint")

        duplicate_config = output / "udp-duplicate-local.conf"
        write_v13_config(
            duplicate_config, listen=listener,
            routes=[
                ("udp-a", "0", udp_locator(
                    "127.0.0.1:45108", "127.0.0.1:45109", "5544505445535435")),
                ("udp-b", "1", udp_locator(
                    "127.0.0.1:45108", "127.0.0.1:45110", "5544505445535436")),
            ],
        )
        duplicate_run = run_command(
            [str(binary), "config-check", "--config", str(duplicate_config)],
            stdout_path=output / "config-duplicate-local.stdout.txt",
            stderr_path=output / "config-duplicate-local.stderr.txt",
            timeout=15,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append({"label": "config-duplicate-local",
                         "returncode": duplicate_run.returncode,
                         "args": ["config-check", "--config", str(duplicate_config)]})
        duplicate_json = json.loads(duplicate_run.stdout.strip())
        check(duplicate_run.returncode == 3 and
              duplicate_json.get("code") == "CONFIG_PEER_ROUTE_ENDPOINT_AMBIGUOUS",
              "one local UDP endpoint cannot be assigned to multiple routes")
        record_case("persistent UDP configuration boundary", before, begin)

        probe = output / "udp-transport-probe"
        compile_command = [
            "/usr/bin/g++",
            "-D_GNU_SOURCE",
            "-std=c++20",
            "-O1",
            "-g0",
            "-Wall",
            "-Wextra",
            "-Wpedantic",
            "-Wconversion",
            "-Wsign-conversion",
            "-Wshadow",
            "-Wformat=2",
            "-Werror",
            "-pthread",
            f"-I{source_root / 'foundation/include'}",
            f"-I{source_root / 'node/src'}",
            str(source_root / "node/tests/test_udp_transport.cpp"),
            str(source_root / "node/src/udp_transport.cpp"),
            str(source_root / "node/src/unix_datagram_transport.cpp"),
            str(source_root / "node/src/finite_packet_link.cpp"),
            str(source_root / "node/src/packet_port.cpp"),
            str(source_root / "node/src/transport.cpp"),
            str(source_root / "node/src/serial_transport.cpp"),
            str(source_root / "node/src/peer_session.cpp"),
            str(source_root / "node/src/tls.cpp"),
            str(source_root / "node/src/tls_bio.cpp"),
            str(source_root / "node/src/socket.cpp"),
            str(source_root / "node/src/protocol.cpp"),
            str(source_root / "node/src/common.cpp"),
            str(source_root / "foundation/src/core.cpp"),
            str(source_root / "foundation/src/natrav_peer_session.cpp"),
            str(source_root / "foundation/src/natrav_peer_stream.cpp"),
            str(source_root / "foundation/src/natrav_peer_message.cpp"),
            str(source_root / "foundation/src/natrav_peer_handshake.cpp"),
            "-lssl",
            "-lcrypto",
            "-lz",
            "-lzstd",
            "-ldl",
            "-o",
            str(probe),
        ]
        before = assertions
        begin = time.monotonic()
        compile_run = run_command(
            compile_command,
            stdout_path=output / "probe-build.stdout.txt",
            stderr_path=output / "probe-build.stderr.txt",
            timeout=300,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append(
            {"label": "probe-build", "returncode": compile_run.returncode,
             "args": compile_command}
        )
        check(compile_run.returncode == 0, "strict-warning UDP probe compiles")
        check(probe.is_file() and os.access(probe, os.X_OK),
              "UDP probe executable is materialized")
        record_case("probe build", before, begin)

        before = assertions
        begin = time.monotonic()
        probe_command = [
            str(probe),
            str(client.certificate),
            str(client.private_key),
            client.spki_sha256,
            str(server.certificate),
            str(server.private_key),
            server.spki_sha256,
        ]
        probe_run = run_command(
            probe_command,
            stdout_path=output / "probe.stdout.txt",
            stderr_path=output / "probe.stderr.txt",
            timeout=180,
            environment=dict(os.environ, TERM="dumb", PYTHONDONTWRITEBYTECODE="1"),
        )
        commands.append(
            {"label": "probe", "returncode": probe_run.returncode,
             "args": [str(probe), "<ephemeral test identities>"]}
        )
        check(probe_run.returncode == 0, "loopback UDP packet-carrier probe succeeds")
        probe_lines = [line for line in probe_run.stdout.splitlines() if line.strip()]
        check(len(probe_lines) == 1, "UDP probe emits one JSON line")
        result = json.loads(probe_lines[0])
        check(result.get("format") == "NATRAV_UDP_TRANSPORT_PROBE_V1",
              "UDP probe format is exact")
        check(result.get("status") == "PASS", "UDP probe reports PASS")
        check(result.get("assertions") == 23,
              "UDP probe exact assertion account is retained")
        probe_cases = result.get("cases")
        check(isinstance(probe_cases, list) and len(probe_cases) == 6,
              "UDP probe covers six locator, datagram, stream, and authenticated-stack cases")
        for item in probe_cases:
            check(isinstance(item, dict) and int(item.get("assertions", 0)) > 0,
                  "every UDP probe case contributes assertions")
            cases.append(
                {
                    "name": f"UDP transport probe: {item['name']}",
                    "status": "PASS",
                    "assertions": int(item["assertions"]),
                    "elapsed_seconds": 0.0,
                }
            )
        check(sum(int(item["assertions"]) for item in probe_cases) == 23,
              "UDP probe per-case accounting is exact")
        assertions += int(result["assertions"])
        record_case("probe execution", before + int(result["assertions"]), begin)

        status = "PASS"
    except BaseException as error:  # preserve bounded evidence on any failure
        failure = f"{type(error).__name__}: {error}"
        cases.append(
            {
                "name": "suite failure",
                "status": "FAIL",
                "assertions": 0,
                "elapsed_seconds": 0.0,
                "detail": failure,
            }
        )

    summary = {
        "format": "NATRAV_UDP_TRANSPORT_SUITE_V1",
        "status": status,
        "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "cases_passed": sum(item["status"] == "PASS" for item in cases),
        "cases_total": len(cases),
        "assertions": assertions,
        "commands": len(commands),
        "elapsed_seconds": time.monotonic() - started,
        "feature": EXPECTED_FEATURE,
        "independent_host_verified": False,
        "hardware_verified": False,
        "cases": cases,
        "command_records": commands,
    }
    if failure is not None:
        summary["failure"] = failure
    (output / "SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps({key: value for key, value in summary.items()
                      if key not in {"cases", "command_records"}}, sort_keys=True),
          flush=True)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
