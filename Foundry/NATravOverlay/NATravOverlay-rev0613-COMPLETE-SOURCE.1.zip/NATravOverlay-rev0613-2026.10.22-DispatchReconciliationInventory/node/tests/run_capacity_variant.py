#!/usr/bin/env python3
"""Rebuild isolated oracle or deliberately weakened accounting; never edit the product tree."""
from __future__ import annotations
import argparse,difflib,hashlib,json,os,shutil,subprocess,time
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True,type=Path)
    p.add_argument('--variant',required=True,choices=('oracle','no-cancel-release'));a=p.parse_args()
    root=Path(__file__).resolve().parents[2];out=a.output.resolve()
    if out.exists() or out==root or root in out.parents:p.error('output must be new and outside the product tree')
    source=out/'source';source.mkdir(parents=True)
    for name in ('node/src','node/tests','foundation/src','foundation/include'):shutil.copytree(root/name,source/name)
    shutil.copy2(root/'node/build.sh',source/'node/build.sh')
    f=source/'node/src/outbox_query.cpp';old=f.read_text()
    if a.variant=='oracle':
        needle='    if (active_submission_work) {\n        ++active_submission_work->capacity_entries_touched;'
        replacement='''    // Test-only independent full scan after every authoritative indexing hook.
    if (pending_capacity_.snapshot() != outbound_queue_usage(outbound_)) {
        app_fail("TEST_PENDING_CAPACITY_MISMATCH", "aggregate differs from complete authoritative outbox scan");
    }
'''+needle
    else:
        needle='static_cast<std::uint64_t>(entry.record.payload.size()), outcome == "PENDING");'
        replacement='static_cast<std::uint64_t>(entry.record.payload.size()), outcome == "PENDING" || outcome == "CANCELLED");'
    if old.count(needle)!=1:raise RuntimeError('expected exact accounting patch location')
    new=old.replace(needle,replacement);f.write_text(new)
    (out/'PATCH.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='node/src/outbox_query.cpp',tofile='test-variant/node/src/outbox_query.cpp')))
    env=dict(os.environ,JOBS='2',PYTHONDONTWRITEBYTECODE='1');start=time.monotonic()
    with (out/'BUILD.log').open('w') as log:build=subprocess.run(['./node/build.sh','static'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
    result={'format':'NATRAV_CAPACITY_VARIANT_V1','variant':a.variant,'build_returncode':build.returncode,'status':'FAIL'}
    if build.returncode==0:
        binary=source/'node/bin/natrav-overlay';result['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
        if a.variant=='oracle':
            cmd=['python','node/tests/run_matrix.py','--binary',str(binary),'--output',str(out/'tests'),'--timeout','240']
            for name in ('delivery_governance','conditional_outbox','publication_channels','automatic_publication_channels','publication_epochs','source_subscriptions','automatic_source_delivery','subscription_leases','lease_succession'):cmd+=['--suite',name]
        else:
            cmd=['python','node/tests/run_pending_capacity.py','--binary',str(binary),'--output',str(out/'tests'),'--case','constant_admission_work_beside_large_settled_history']
        with (out/'TEST.log').open('w') as log:run=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
        result['returncode']=run.returncode
        if a.variant=='oracle':
            result['status']='PASS' if run.returncode==0 else 'FAIL'
            path=out/'tests/MATRIX.json'
            if path.exists():result['matrix']=json.loads(path.read_text())
        else:
            path=out/'tests/FAILURE.txt';failure=path.read_text() if path.exists() else ''
            result['failure']=failure;result['status']='DETECTED' if run.returncode!=0 and 'capacity-after-cancel exact global pending count/bytes' in failure else 'NOT_DETECTED'
    result['elapsed_seconds']=time.monotonic()-start;(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='matrix'}),flush=True)
    return 0 if result['status'] in ('PASS','DETECTED') else 1
if __name__=='__main__':raise SystemExit(main())
