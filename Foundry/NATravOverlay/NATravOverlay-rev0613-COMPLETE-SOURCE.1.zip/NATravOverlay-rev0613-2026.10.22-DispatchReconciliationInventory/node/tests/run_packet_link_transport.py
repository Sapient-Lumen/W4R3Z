#!/usr/bin/env python3
"""Private finite packet-link OrderedByteStream and authenticated-stack regression."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from typing import Any

from tls_test_support import IdentityFactory


EXPECTED_FEATURE = "PACKET_LINK_ORDERED_BYTE_STREAM_ADAPTER_V1"


def run_command(
    command: list[str],
    *,
    stdout_path: Path,
    stderr_path: Path,
    timeout: float,
    environment: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        timeout=timeout,
        env=environment,
    )
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)
    return completed


def nplt_shape(payload: bytes) -> list[tuple[int, int, int, int]]:
    if len(payload) < 16 or not payload.startswith(b"NPLT0001"):
        raise AssertionError("canonical packet trace magic/length is invalid")
    count = int.from_bytes(payload[8:12], "big")
    if len(payload) != 12 + count * 28 + 4:
        raise AssertionError("canonical packet trace size is invalid")
    result: list[tuple[int, int, int, int]] = []
    offset = 12
    for _ in range(count):
        result.append(
            (
                payload[offset],
                payload[offset + 1],
                int.from_bytes(payload[offset + 4:offset + 12], "big"),
                int.from_bytes(payload[offset + 20:offset + 24], "big"),
            )
        )
        offset += 28
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    source_root = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    binary = args.binary.resolve(strict=True)
    if output.exists() or output == source_root or source_root in output.parents:
        parser.error("output must be new and outside the source tree")
    output.mkdir(parents=True)

    started = time.monotonic()
    assertions = 0
    commands: list[dict[str, Any]] = []
    cases: list[dict[str, Any]] = []

    def check(condition: bool, detail: str) -> None:
        nonlocal assertions
        assertions += 1
        if not condition:
            raise AssertionError(detail)

    def record_case(name: str, before: int, begin: float) -> None:
        cases.append(
            {
                "name": name,
                "status": "PASS",
                "assertions": assertions - before,
                "elapsed_seconds": time.monotonic() - begin,
            }
        )

    status = "FAIL"
    failure: str | None = None
    try:
        before = assertions
        begin = time.monotonic()
        version_run = run_command(
            [str(binary), "version"],
            stdout_path=output / "version.stdout.txt",
            stderr_path=output / "version.stderr.txt",
            timeout=10,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append(
            {"label": "version", "returncode": version_run.returncode,
             "args": ["version"]}
        )
        check(version_run.returncode == 0, "version command succeeds")
        lines = [line for line in version_run.stdout.splitlines() if line.strip()]
        check(len(lines) == 1, "version emits one JSON line")
        version = json.loads(lines[0])
        check(version.get("version") == "0613", "revision is 0613")
        check(version.get("packet_link_stream") == EXPECTED_FEATURE,
              "packet-link ordered-stream marker is exact")
        check(version.get("tls_byte_channel") == "OPENSSL_BYTE_CHANNEL_BIO_V1",
              "descriptor-free TLS marker is retained")
        check(version.get("serial_transport") ==
              "POSIX_SERIAL_TTY_ORDERED_BYTE_STREAM_V1",
              "serial ordered-stream marker is retained")
        record_case("revision metadata", before, begin)

        before = assertions
        begin = time.monotonic()
        header = (source_root / "node/src/packet_link_transport.hpp").read_text()
        implementation = (source_root / "node/src/packet_link_transport.cpp").read_text()
        core_header = (source_root / "node/src/finite_packet_link.hpp").read_text()
        core_source = (source_root / "node/src/finite_packet_link.cpp").read_text()
        transport_header = (source_root / "node/src/transport.hpp").read_text()
        transport_source = (source_root / "node/src/transport.cpp").read_text()
        session_header = (source_root / "node/src/peer_session.hpp").read_text()
        build_script = (source_root / "node/build.sh").read_text()
        configured_sources = "\n".join(
            (source_root / path).read_text()
            for path in (
                "node/src/config.cpp",
                "node/src/runtime.cpp",
                "node/src/daemon.cpp",
            )
        )
        check(EXPECTED_FEATURE in header,
              "adapter marker is declared at the owned boundary")
        check("class PacketLinkControl" in header and
              "make_packet_link_stream_pair" in header,
              "fixture has an explicit owned pair and control contract")
        check("FinitePacketStream" in implementation and
              "DeterministicPacketNetwork" in implementation,
              "ordered stream consumes the finite packet state machine")
        check("condition_variable" in implementation and
              "progress_interval" in implementation,
              "bounded logical progress is synchronized under wall deadlines")
        check("thread_local" not in implementation,
              "packet fixture state is not process-global or thread-local")
        check("packet_link = 254U" in transport_header,
              "private packet transport kind is explicit and non-default")
        parse_start = transport_source.index("TransportKind parse_transport_kind")
        parse_end = transport_source.index("std::string_view transport_kind_name")
        parse_body = transport_source[parse_start:parse_end]
        check('text == "tcp"' in parse_body and 'text == "serial"' in parse_body and
              'text == "udp"' in parse_body and 'text == "unix-dgram"' in parse_body and
              "packet" not in parse_body,
              "configured kind parser exposes production carriers but not the private packet link")
        check("packet-v1" not in configured_sources and
              "packet-link-private" not in configured_sources,
              "normal route configuration has no packet-link locator")
        check("cannot dial routes" in transport_source and
              "cannot listen" in transport_source,
              "connector and listener registries reject fixture-owned packet links")
        check("src/finite_packet_link.cpp" in build_script and
              "src/packet_link_transport.cpp" in build_script,
              "normal product build compiles the core and adapter translation units")
        check("open_connected" in session_header,
              "real reusable session accepts the fixture-owned ordered stream")
        check("kScheduleMagic" in core_source and "kTraceMagic" in core_source and
              "FINITE_PACKET_LINK_SERVICE_V1" in core_header,
              "canonical schedule/trace symbols and finite-core marker are retained")
        record_case("private authority and ownership boundary", before, begin)

        before = assertions
        begin = time.monotonic()
        probe = output / "packet-link-transport-probe"
        compile_command = [
            "/usr/bin/g++",
            "-D_GNU_SOURCE",
            "-std=c++20",
            "-O1",
            "-g0",
            "-Wall",
            "-Wextra",
            "-Wpedantic",
            "-Wconversion",
            "-Wsign-conversion",
            "-Wshadow",
            "-Wformat=2",
            "-Werror",
            "-pthread",
            f"-I{source_root / 'foundation/include'}",
            f"-I{source_root / 'node/src'}",
            str(source_root / "node/tests/test_packet_link_transport.cpp"),
            str(source_root / "node/src/packet_link_transport.cpp"),
            str(source_root / "node/src/finite_packet_link.cpp"),
            str(source_root / "node/src/packet_port.cpp"),
            str(source_root / "node/src/transport.cpp"),
            str(source_root / "node/src/serial_transport.cpp"),
            str(source_root / "node/src/udp_transport.cpp"),
            str(source_root / "node/src/unix_datagram_transport.cpp"),
            str(source_root / "node/src/peer_session.cpp"),
            str(source_root / "node/src/tls.cpp"),
            str(source_root / "node/src/tls_bio.cpp"),
            str(source_root / "node/src/socket.cpp"),
            str(source_root / "node/src/protocol.cpp"),
            str(source_root / "node/src/common.cpp"),
            str(source_root / "foundation/src/core.cpp"),
            str(source_root / "foundation/src/natrav_peer_session.cpp"),
            str(source_root / "foundation/src/natrav_peer_stream.cpp"),
            str(source_root / "foundation/src/natrav_peer_message.cpp"),
            str(source_root / "foundation/src/natrav_peer_handshake.cpp"),
            "-lssl",
            "-lcrypto",
            "-lz",
            "-lzstd",
            "-ldl",
            "-o",
            str(probe),
        ]
        compile_run = run_command(
            compile_command,
            stdout_path=output / "probe-build.stdout.txt",
            stderr_path=output / "probe-build.stderr.txt",
            timeout=240,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append(
            {"label": "probe-build", "returncode": compile_run.returncode,
             "args": compile_command}
        )
        check(compile_run.returncode == 0, "strict-warning adapter probe compiles")
        check(probe.is_file() and os.access(probe, os.X_OK),
              "adapter probe executable is materialized")
        record_case("probe build", before, begin)

        before = assertions
        begin = time.monotonic()
        identities = IdentityFactory(output / "identities")
        client = identities.identity("packet-client")
        server = identities.identity("packet-server")
        evidence = output / "evidence"
        evidence.mkdir()
        probe_command = [
            str(probe),
            str(client.certificate),
            str(client.private_key),
            client.spki_sha256,
            str(server.certificate),
            str(server.private_key),
            server.spki_sha256,
            str(evidence),
        ]
        probe_run = run_command(
            probe_command,
            stdout_path=output / "probe.stdout.txt",
            stderr_path=output / "probe.stderr.txt",
            timeout=240,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append(
            {"label": "probe", "returncode": probe_run.returncode,
             "args": [str(probe), "<ephemeral test identities>", str(evidence)]}
        )
        check(probe_run.returncode == 0,
              "packet-link ordered-stream probe succeeds")
        probe_lines = [line for line in probe_run.stdout.splitlines() if line.strip()]
        check(len(probe_lines) == 1, "probe emits one JSON result")
        result = json.loads(probe_lines[0])
        check(result.get("format") == "NATRAV_PACKET_LINK_ADAPTER_PROBE_V1",
              "probe format is exact")
        check(result.get("status") == "PASS", "probe reports PASS")
        check(result.get("assertions", 0) >= 47,
              "probe retains the bounded assertion floor")
        probe_cases = result.get("cases")
        check(isinstance(probe_cases, list) and len(probe_cases) == 7,
              "probe covers seven finite-link and authenticated-stack cases")
        for item in probe_cases:
            check(isinstance(item, dict) and item.get("assertions", 0) > 0,
                  "every probe case contributes explicit assertions")
            cases.append(
                {
                    "name": f"packet-link probe: {item['name']}",
                    "status": "PASS",
                    "assertions": int(item["assertions"]),
                    "elapsed_seconds": 0.0,
                }
            )
        assertions += int(result["assertions"])
        record_case("probe execution", before, begin)

        before = assertions
        begin = time.monotonic()
        expected = {
            "lossless.nplt": b"NPLT0001",
            "faulted-first.nplt": b"NPLT0001",
            "faulted-second.nplt": b"NPLT0001",
            "faulted.npls": b"NPLS0001",
            "raw-replay-first.nplt": b"NPLT0001",
            "raw-replay-second.nplt": b"NPLT0001",
        }
        materialized: dict[str, bytes] = {}
        for name, magic in expected.items():
            path = evidence / name
            check(path.is_file(), f"{name} is materialized")
            payload = path.read_bytes()
            materialized[name] = payload
            check(payload.startswith(magic), f"{name} has canonical magic")
            check(16 <= len(payload) < 1_000_000,
                  f"{name} remains finite and nonempty")
        check(materialized["raw-replay-first.nplt"] ==
              materialized["raw-replay-second.nplt"],
              "fixed raw input replays to byte-identical canonical traces")
        check(nplt_shape(materialized["faulted-first.nplt"]) ==
              nplt_shape(materialized["faulted-second.nplt"]),
              "independent TLS runs preserve schedule/ordinal/size trace structure")
        check(materialized["faulted.npls"] ==
              (evidence / "faulted.npls").read_bytes(),
              "canonical fault schedule is stable on reread")
        record_case("canonical evidence and replay boundary", before, begin)

        status = "PASS"
    except BaseException as error:
        failure = f"{type(error).__name__}: {error}"
        cases.append(
            {
                "name": "suite failure",
                "status": "FAIL",
                "assertions": 0,
                "elapsed_seconds": 0.0,
                "detail": failure,
            }
        )

    summary = {
        "format": "NATRAV_PACKET_LINK_TRANSPORT_SUITE_V1",
        "status": status,
        "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "cases_passed": sum(item["status"] == "PASS" for item in cases),
        "cases_total": len(cases),
        "assertions": assertions,
        "commands": len(commands),
        "elapsed_seconds": time.monotonic() - started,
        "feature": EXPECTED_FEATURE,
        "cases": cases,
        "command_records": commands,
    }
    if failure is not None:
        summary["failure"] = failure
    (output / "SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(
        json.dumps(
            {key: value for key, value in summary.items()
             if key not in {"cases", "command_records"}},
            sort_keys=True,
        ),
        flush=True,
    )
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
