#!/usr/bin/env python3
"""Authenticated delivery outcomes and durable outbox-governance tests."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import time
from typing import Any, Callable

from run_persistent import Harness, free_port, operation


def generation(label: str) -> str:
    return label.lower() + "1"


def write_config(
    h: Harness,
    name: str,
    node: str,
    state: Path,
    port: int,
    identity_label: str,
    routes: list[tuple[str, int, int, int, int, int]],
    keys: list[tuple[str, str, str, str]],
    rules: list[tuple[str, str, str, str]],
    *,
    deadline_ms: int = 250,
    global_records: int = 4096,
    global_bytes: int = 67_108_864,
    peer_records: int = 1024,
    peer_bytes: int = 16_777_216,
) -> Path:
    identity = h.identity(identity_label)
    lines = [
        "NATRAV_OVERLAY_CONFIG_V6",
        f"node={node}",
        f"state={state}",
        f"listen=127.0.0.1:{port}",
        "control=control.sock",
        f"identity_cert={identity.certificate}",
        f"identity_key={identity.private_key}",
        f"identity_pin={identity.spki_sha256}",
        f"identity_generation={generation(identity_label)}",
        f"deadline_ms={deadline_ms}",
        "peer_workers=4",
        "peer_queue_capacity=64",
        "control_workers=2",
        "control_queue_capacity=64",
        f"outbox_global_max_records={global_records}",
        f"outbox_global_max_payload_bytes={global_bytes}",
        f"outbox_peer_max_records={peer_records}",
        f"outbox_peer_max_payload_bytes={peer_bytes}",
    ]
    for peer, peer_port, initial, maximum, attempts, expiry in routes:
        lines.append(
            f"peer={peer},127.0.0.1:{peer_port},"
            f"{initial},{maximum},{attempts},{expiry}"
        )
    for peer, key_generation, state_name, peer_identity in keys:
        lines.append(
            f"peer_key={peer},{key_generation},{state_name},"
            f"{h.identity(peer_identity).spki_sha256}"
        )
    for peer, key_generation, operation_class, resource in rules:
        lines.append(
            f"authorize={peer},{key_generation},{operation_class},{resource}"
        )
    path = h.work / f"{name}.conf"
    path.write_text("\n".join(lines) + "\n")
    path.chmod(0o644)
    return path


def submit(
    h: Harness,
    label: str,
    control: Path,
    issuer: str,
    recipient: str,
    scope: str,
    operation_id: str,
    payload: str,
    *,
    expected: int = 0,
) -> dict[str, Any]:
    result = h.run(
        label,
        [
            "submit", "--control", str(control), "--node", issuer,
            "--peer", recipient, "--scope", scope,
            "--operation", operation_id, "--payload-text", payload,
            "--deadline-ms", "2000",
        ],
        expected=expected,
    )
    assert result is not None
    return result


def revise(
    h: Harness,
    label: str,
    control: Path,
    issuer: str,
    recipient: str,
    scope: str,
    operation_id: str,
    parent_id: str,
    payload: str,
) -> dict[str, Any]:
    result = h.run(
        label,
        [
            "revise", "--control", str(control), "--node", issuer,
            "--peer", recipient, "--scope", scope,
            "--operation", operation_id, "--corrects", parent_id,
            "--payload-text", payload, "--deadline-ms", "2000",
        ],
    )
    assert result is not None
    return result


def entry(status: dict[str, Any], operation_id: str) -> dict[str, Any]:
    return next(
        item for item in status["outbox"]["entries"]
        if item["operation_id"] == operation_id
    )


def reservations(status: dict[str, Any]) -> tuple[int, int]:
    value = status["outbox"]["reservations"]
    return int(value["pending_records"]), int(value["pending_payload_bytes"])


def run_suite(h: Harness, selected: set[str] | None = None) -> None:
    def run_case(name: str, function: Callable[[], None]) -> None:
        if selected is None or name in selected:
            h.case(name, function)

    def terminal_and_transient_classification() -> None:
        root = h.runtime / "classification"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port, c_port = free_port(), free_port(), free_port()
        a_conf = write_config(
            h, "classification-a", "A", a_state, a_port, "A", [],
            [("B", "b1", "ACTIVE", "B")],
            [("B", "*", "EVIDENCE", "allowed/missing-parent")],
        )
        b_conf = write_config(
            h, "classification-b", "B", b_state, b_port, "B",
            [
                ("A", a_port, 300, 500, 50, 60_000),
                ("C", c_port, 300, 500, 50, 60_000),
            ],
            [
                ("A", "a1", "ACTIVE", "A"),
                ("C", "c1", "ACTIVE", "C"),
            ],
            [],
        )
        a = h.start("classification-a", a_conf, a_state)
        b = h.start("classification-b", b_conf, b_state)

        denied = operation("governance-terminal-denial")
        submit(
            h, "classification-denied-submit", b.control, "B", "A",
            "denied/scope", denied, "terminal",
        )
        terminal: dict[str, Any] = {}

        def terminal_visible() -> bool:
            terminal.clear(); terminal.update(h.status("classification-denied-wait", b_state))
            return entry(terminal, denied)["status"] == "REJECTED"

        h.wait("authenticated authorization denial becomes terminal", terminal_visible)
        denied_entry = entry(terminal, denied)
        h.check(denied_entry["attempts"] == 1, "terminal denial consumes one begun attempt")
        h.check(denied_entry["last_error_code"] == "AUTHORIZATION_DENIED", "terminal code retained")
        h.check(denied_entry["rejection"]["peer_generation"] == "a1", "rejection binds generation")
        h.check(
            denied_entry["rejection"]["peer_spki_sha256"] == h.identity("A").spki_sha256,
            "rejection binds exact authenticated public key",
        )
        h.check(len(denied_entry["rejection"]["policy_digest"]) == 64, "rejection binds delivery policy")
        h.check(reservations(terminal) == (0, 0), "terminal rejection releases reservation")
        attempts = denied_entry["attempts"]
        time.sleep(0.7)
        stable = h.status("classification-denied-stable", b_state)
        h.check(entry(stable, denied)["attempts"] == attempts, "terminal rejection stops automatic retry")
        duplicate = submit(
            h, "classification-denied-resubmit", b.control, "B", "A",
            "denied/scope", denied, "terminal",
        )
        h.check(duplicate["queue_disposition"] == "ALREADY_REJECTED", "resubmit does not reopen rejection")
        h.check(duplicate["status"] == "REJECTED", "rejected status remains terminal")

        missing_parent = operation("governance-missing-parent-correction")
        revise(
            h, "classification-transient-revise", b.control, "B", "A",
            "allowed/missing-parent", missing_parent,
            operation("governance-never-delivered-parent"), "later",
        )
        transient: dict[str, Any] = {}

        def transient_visible() -> bool:
            transient.clear(); transient.update(h.status("classification-transient-wait", b_state))
            item = entry(transient, missing_parent)
            return item["last_error_code"] == "CORRECTION_PARENT_NOT_FOUND"

        h.wait("authenticated ordering failure remains retryable", transient_visible)
        transient_entry = entry(transient, missing_parent)
        h.check(transient_entry["status"] == "PENDING", "missing parent is not terminal")
        h.check(transient_entry["rejection"] is None, "transient peer error has no rejection account")
        transient_attempts = transient_entry["attempts"]
        h.wait(
            "transient peer decision retries",
            lambda: entry(h.status("classification-transient-retry", b_state), missing_parent)["attempts"] > transient_attempts,
            timeout=4.0,
        )

        unavailable = operation("governance-unavailable-peer")
        submit(
            h, "classification-unavailable-submit", b.control, "B", "C",
            "transport/unavailable", unavailable, "offline",
        )
        transport: dict[str, Any] = {}

        def transport_visible() -> bool:
            transport.clear(); transport.update(h.status("classification-transport-wait", b_state))
            item = entry(transport, unavailable)
            return item["attempts"] >= 1 and item["last_error_code"] is not None

        h.wait("transport failure recorded", transport_visible)
        transport_entry = entry(transport, unavailable)
        h.check(transport_entry["status"] == "PENDING", "transport failure cannot create terminal rejection")
        h.check(transport_entry["rejection"] is None, "transport failure has no authenticated rejection")
        h.check(reservations(transport) == (2, len("later") + len("offline")), "only retryable obligations reserve capacity")

        b.shutdown(); a.shutdown()
        inspected = h.run(
            "classification-inspect",
            ["inspect", "--state", str(b_state), "--node", "B"],
        )
        assert inspected is not None
        h.check(inspected["format"] == "NATRAV_OVERLAY_STATE_V7", "offline schema exposes governance state")
        h.check(inspected["outbox"]["rejected"] == 1, "offline rejection reconstructs")
        h.check(inspected["outbox"]["reservations"]["pending_records"] == 2, "offline reservations reconstruct")

    run_case("terminal_and_transient_classification", terminal_and_transient_classification)

    def explicit_retry_after_policy_change() -> None:
        root = h.runtime / "explicit-retry"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        deny_conf = write_config(
            h, "retry-a-deny", "A", a_state, a_port, "A", [],
            [("B", "b1", "ACTIVE", "B")], [],
        )
        allow_conf = write_config(
            h, "retry-a-allow", "A", a_state, a_port, "A", [],
            [("B", "b1", "ACTIVE", "B")],
            [("B", "*", "EVIDENCE", "retry/scope")],
        )
        b_conf = write_config(
            h, "retry-b", "B", b_state, b_port, "B",
            [("A", a_port, 100, 300, 20, 30_000)],
            [("A", "a1", "ACTIVE", "A")], [],
        )
        a = h.start("retry-a-deny", deny_conf, a_state)
        b = h.start("retry-b", b_conf, b_state)
        op = operation("governance-explicit-retry")
        submit(h, "retry-submit", b.control, "B", "A", "retry/scope", op, "retry-me")
        h.wait(
            "initial policy denial terminal",
            lambda: entry(h.status("retry-denied-wait", b_state), op)["status"] == "REJECTED",
        )
        a.shutdown()
        a2 = h.start("retry-a-allow", allow_conf, a_state)
        retried = h.run(
            "retry-control",
            [
                "retry", "--control", str(b.control), "--operation", op,
                "--reason", "recipient policy was deliberately amended",
                "--deadline-ms", "2000",
            ],
        )
        assert retried is not None
        h.check(retried["status"] == "PENDING", "explicit retry reopens obligation")
        acknowledged: dict[str, Any] = {}

        def retry_acked() -> bool:
            acknowledged.clear(); acknowledged.update(h.status("retry-acked-wait", b_state))
            return entry(acknowledged, op)["status"] == "ACKED"

        h.wait("explicitly reopened operation acknowledged", retry_acked)
        final_entry = entry(acknowledged, op)
        kinds = [item["kind"] for item in final_entry["transitions"]]
        h.check(kinds == ["REJECTED", "RETRIED"], "attributable rejection and retry order retained")
        h.check(final_entry["attempts"] == 1, "retry begins a fresh bounded attempt account")
        h.check(reservations(acknowledged) == (0, 0), "acknowledgment releases reopened reservation")
        recipient = h.status("retry-recipient-status", a_state)
        h.check(recipient["inbound_records"] == 1, "recipient admits operation after policy change")
        h.check(recipient["authorization"]["denied"] == 1, "historical denial remains attributable")

        b.shutdown(); a2.shutdown()
        inspected = h.run(
            "retry-inspect",
            ["inspect", "--state", str(b_state), "--node", "B"],
        )
        assert inspected is not None
        offline = next(item for item in inspected["outbox"]["entries"] if item["operation_id"] == op)
        h.check(offline["status"] == "ACKED", "retry result reconstructs offline")
        h.check(
            [item["kind"] for item in offline["delivery"]["transitions"]] == ["REJECTED", "RETRIED"],
            "offline transition provenance retained",
        )

    run_case("explicit_retry_after_policy_change", explicit_retry_after_policy_change)

    def exact_record_and_payload_limits() -> None:
        root = h.runtime / "quota-boundaries"
        root.mkdir()
        ports = {name: free_port() for name in ("A", "C", "D", "R", "Q")}
        key_rows = [(name, name.lower() + "1", "ACTIVE", name) for name in ("A", "C", "D")]
        route_rows = [
            (name, ports[name], 1000, 1000, 100, 60_000)
            for name in ("A", "C", "D")
        ]

        record_state = root / "records"
        record_conf = write_config(
            h, "quota-records", "R", record_state, ports["R"], "R",
            route_rows, key_rows, [], global_records=2, global_bytes=100,
            peer_records=1, peer_bytes=100,
        )
        record_daemon = h.start("quota-records", record_conf, record_state)
        a1 = operation("quota-record-a1")
        c1 = operation("quota-record-c1")
        d1 = operation("quota-record-d1")
        submit(h, "quota-record-a1", record_daemon.control, "R", "A", "quota/records", a1, "aaa")
        peer_full = submit(
            h, "quota-record-a2-rejected", record_daemon.control, "R", "A",
            "quota/records", operation("quota-record-a2"), "b", expected=3,
        )
        h.check(peer_full["code"] == "OUTBOX_PEER_RECORD_LIMIT", "per-peer record boundary enforced")
        submit(h, "quota-record-c1", record_daemon.control, "R", "C", "quota/records", c1, "cccc")
        global_full = submit(
            h, "quota-record-d1-rejected", record_daemon.control, "R", "D",
            "quota/records", d1, "d", expected=3,
        )
        h.check(global_full["code"] == "OUTBOX_GLOBAL_RECORD_LIMIT", "global record boundary enforced")
        full_status = h.status("quota-record-full-status", record_state)
        h.check(reservations(full_status) == (2, 7), "record boundary accounting exact")
        cancelled = h.run(
            "quota-record-cancel-a",
            [
                "cancel", "--control", str(record_daemon.control),
                "--operation", a1, "--reason", "release record quota",
                "--deadline-ms", "2000",
            ],
        )
        assert cancelled is not None
        h.check(cancelled["status"] == "CANCELLED", "cancellation is terminal")
        submit(h, "quota-record-d1-after-release", record_daemon.control, "R", "D", "quota/records", d1, "d")
        released = h.status("quota-record-released-status", record_state)
        h.check(reservations(released) == (2, 5), "cancelled record releases exact bytes and count")
        record_daemon.shutdown()

        payload_state = root / "payloads"
        payload_conf = write_config(
            h, "quota-payloads", "Q", payload_state, ports["Q"], "Q",
            route_rows, key_rows, [], global_records=10, global_bytes=10,
            peer_records=10, peer_bytes=6,
        )
        payload_daemon = h.start("quota-payloads", payload_conf, payload_state)
        pa = operation("quota-payload-a")
        pc = operation("quota-payload-c")
        pd = operation("quota-payload-d")
        submit(h, "quota-payload-a-six", payload_daemon.control, "Q", "A", "quota/bytes", pa, "123456")
        peer_bytes = submit(
            h, "quota-payload-a-over", payload_daemon.control, "Q", "A",
            "quota/bytes", operation("quota-payload-a-over"), "x", expected=3,
        )
        h.check(peer_bytes["code"] == "OUTBOX_PEER_PAYLOAD_LIMIT", "per-peer payload boundary enforced")
        submit(h, "quota-payload-c-four", payload_daemon.control, "Q", "C", "quota/bytes", pc, "7890")
        global_bytes = submit(
            h, "quota-payload-d-over", payload_daemon.control, "Q", "D",
            "quota/bytes", pd, "z", expected=3,
        )
        h.check(global_bytes["code"] == "OUTBOX_GLOBAL_PAYLOAD_LIMIT", "global payload boundary enforced")
        payload_full = h.status("quota-payload-full-status", payload_state)
        h.check(reservations(payload_full) == (2, 10), "payload boundary accounting exact")
        h.run(
            "quota-payload-cancel-a",
            [
                "cancel", "--control", str(payload_daemon.control),
                "--operation", pa, "--reason", "release payload quota",
                "--deadline-ms", "2000",
            ],
        )
        submit(h, "quota-payload-d-six-after-release", payload_daemon.control, "Q", "D", "quota/bytes", pd, "abcdef")
        payload_released = h.status("quota-payload-released-status", payload_state)
        h.check(reservations(payload_released) == (2, 10), "released payload capacity reusable at exact boundary")
        payload_daemon.shutdown()

        invalid = write_config(
            h, "quota-invalid-config", "Q", root / "invalid", free_port(), "Q",
            [], [], [], global_records=1, global_bytes=10,
            peer_records=2, peer_bytes=10,
        )
        invalid_result = h.run(
            "quota-invalid-config-check",
            ["config-check", "--config", str(invalid)],
            expected=3,
        )
        h.check(
            invalid_result is not None and invalid_result["code"] == "CONFIG_OUTBOX_LIMIT_INVALID",
            "per-peer limits cannot exceed global limits",
        )

    run_case("exact_record_and_payload_limits", exact_record_and_payload_limits)

    def terminal_release_and_peer_progress() -> None:
        root = h.runtime / "outcomes-progress"
        root.mkdir()
        s_state, a_state, r_state = root / "s", root / "a", root / "r"
        ports = {name: free_port() for name in ("S", "A", "R", "U")}
        a_conf = write_config(
            h, "progress-a", "A", a_state, ports["A"], "A", [],
            [("S", "s1", "ACTIVE", "S")],
            [("S", "*", "EVIDENCE", "progress/scope")],
        )
        r_conf = write_config(
            h, "progress-r", "R", r_state, ports["R"], "R", [],
            [("S", "s1", "ACTIVE", "S")], [],
        )
        s_conf = write_config(
            h, "progress-s", "S", s_state, ports["S"], "S",
            [
                ("A", ports["A"], 100, 250, 20, 30_000),
                ("R", ports["R"], 100, 250, 20, 30_000),
                ("U", ports["U"], 100, 250, 20, 500),
            ],
            [
                ("A", "a1", "ACTIVE", "A"),
                ("R", "r1", "ACTIVE", "R"),
                ("U", "u1", "ACTIVE", "U"),
            ],
            [], global_records=2, global_bytes=10, peer_records=1, peer_bytes=5,
        )
        a = h.start("progress-a", a_conf, a_state)
        r = h.start("progress-r", r_conf, r_state)
        s = h.start("progress-s", s_conf, s_state)

        unavailable = operation("progress-unavailable")
        submit(h, "progress-unavailable-submit", s.control, "S", "U", "progress/scope", unavailable, "12345")
        h.wait(
            "unavailable peer occupies its reservation",
            lambda: entry(h.status("progress-unavailable-wait", s_state), unavailable)["attempts"] >= 1,
        )
        accepted = operation("progress-authorized")
        rejected = operation("progress-rejected")
        submit(h, "progress-authorized-submit", s.control, "S", "A", "progress/scope", accepted, "abcde")
        h.wait(
            "reachable peer progresses around unavailable peer",
            lambda: entry(h.status("progress-accepted-wait", s_state), accepted)["status"] == "ACKED",
        )
        after_ack = h.status("progress-after-ack", s_state)
        h.check(reservations(after_ack) == (1, 5), "acknowledgment releases only its reservation")
        submit(h, "progress-rejected-submit", s.control, "S", "R", "progress/scope", rejected, "vwxyz")
        h.wait(
            "rejecting peer resolves independently",
            lambda: entry(h.status("progress-rejected-wait", s_state), rejected)["status"] == "REJECTED",
        )
        after_reject = h.status("progress-after-reject", s_state)
        h.check(reservations(after_reject) == (1, 5), "rejection releases its reservation")
        h.check(after_reject["outbox"]["acked"] == 1, "authorized peer acknowledged")
        h.check(after_reject["outbox"]["rejected"] == 1, "denied peer terminally rejected")
        h.wait(
            "unavailable obligation expires",
            lambda: entry(h.status("progress-expiry-wait", s_state), unavailable)["status"] == "EXPIRED",
            timeout=5.0,
        )
        after_expiry = h.status("progress-after-expiry", s_state)
        h.check(reservations(after_expiry) == (0, 0), "expiry releases final reservation")

        cancellable = operation("progress-cancellable")
        submit(h, "progress-cancellable-submit", s.control, "S", "U", "progress/scope", cancellable, "zzzzz")
        h.run(
            "progress-cancellable-cancel",
            [
                "cancel", "--control", str(s.control), "--operation", cancellable,
                "--reason", "explicit operator release", "--deadline-ms", "2000",
            ],
        )
        after_cancel = h.status("progress-after-cancel", s_state)
        h.check(entry(after_cancel, cancellable)["status"] == "CANCELLED", "cancellation terminal state visible")
        h.check(reservations(after_cancel) == (0, 0), "cancellation releases reservation")

        s.shutdown(); r.shutdown(); a.shutdown()

    run_case("terminal_release_and_peer_progress", terminal_release_and_peer_progress)

    def compaction_backup_restore_accounting() -> None:
        root = h.runtime / "maintenance-accounting"
        root.mkdir()
        a_state, b_state, restored_state = root / "a", root / "b", root / "restored-b"
        a_port, b_port, c_port = free_port(), free_port(), free_port()
        a_conf = write_config(
            h, "maintenance-accounting-a", "A", a_state, a_port, "A", [],
            [("B", "b1", "ACTIVE", "B")], [],
        )
        b_conf = write_config(
            h, "maintenance-accounting-b", "B", b_state, b_port, "B",
            [
                ("A", a_port, 500, 500, 100, 60_000),
                ("C", c_port, 500, 500, 100, 60_000),
            ],
            [
                ("A", "a1", "ACTIVE", "A"),
                ("C", "c1", "ACTIVE", "C"),
            ],
            [], global_records=2, global_bytes=20, peer_records=2, peer_bytes=20,
        )
        a = h.start("maintenance-accounting-a", a_conf, a_state)
        b = h.start("maintenance-accounting-b", b_conf, b_state)
        rejected = operation("maintenance-accounting-rejected")
        pending = operation("maintenance-accounting-pending")
        submit(h, "maintenance-accounting-rejected-submit", b.control, "B", "A", "denied/maintenance", rejected, "reject")
        h.wait(
            "maintenance rejection durable",
            lambda: entry(h.status("maintenance-rejected-wait", b_state), rejected)["status"] == "REJECTED",
        )
        submit(h, "maintenance-accounting-pending-submit", b.control, "B", "C", "pending/maintenance", pending, "pending")
        h.wait(
            "maintenance pending attempt durable",
            lambda: entry(h.status("maintenance-pending-wait", b_state), pending)["attempts"] >= 1,
        )
        before = h.status("maintenance-before-compact", b_state)
        h.check(reservations(before) == (1, len("pending")), "pre-compaction reservation exact")
        before_digest = before["storage"]["logical_state_digest"]
        compacted = h.run(
            "maintenance-compact",
            ["compact", "--control", str(b.control), "--deadline-ms", "5000"],
        )
        assert compacted is not None
        h.check(compacted["logical_state_digest"] == before_digest, "compaction preserves logical digest")
        after = h.status("maintenance-after-compact", b_state)
        h.check(after["storage"]["logical_state_digest"] == before_digest, "post-compaction digest stable")
        h.check(reservations(after) == (1, len("pending")), "compaction preserves reservations")
        h.check(entry(after, rejected)["status"] == "REJECTED", "compaction preserves rejection")

        b.shutdown(); a.shutdown()
        backup = root / "b-signed.nob"
        b_identity = h.identity("B")
        exported = h.run(
            "maintenance-backup-export",
            [
                "backup-export", "--state", str(b_state), "--node", "B",
                "--generation", "b1", "--output", str(backup),
                "--sign-key", str(b_identity.private_key),
                "--sign-cert", str(b_identity.certificate),
            ],
        )
        assert exported is not None
        h.check(exported["logical_state_digest"] == before_digest, "signed backup binds logical digest")
        verified = h.run(
            "maintenance-backup-verify",
            [
                "backup-verify", "--input", str(backup), "--node", "B",
                "--generation", "b1", "--trusted-cert", str(b_identity.certificate),
                "--require-signature", "yes",
            ],
        )
        assert verified is not None
        h.check(verified["logical_state_digest"] == before_digest, "signature verification preserves state identity")
        restored = h.run(
            "maintenance-backup-restore",
            [
                "backup-restore", "--input", str(backup),
                "--destination", str(restored_state), "--node", "B",
                "--generation", "b1", "--trusted-cert", str(b_identity.certificate),
                "--require-signature", "yes",
            ],
        )
        assert restored is not None
        h.check(restored["logical_state_digest"] == before_digest, "restore reports same logical state")

        # Exact equality is an offline reconstruction property. Once run starts,
        # the restored pending obligation may legitimately consume another retry,
        # changing its logical digest before the first control status response.
        offline_restored = h.run(
            "maintenance-restored-offline",
            ["inspect", "--state", str(restored_state), "--node", "B"],
        )
        assert offline_restored is not None
        h.check(offline_restored["storage"]["logical_state_digest"] == before_digest,
                "offline restored decoder reconstructs identical logical state")

        restored_conf = write_config(
            h, "maintenance-accounting-restored", "B", restored_state, free_port(), "B",
            [
                ("A", a_port, 500, 500, 100, 60_000),
                ("C", c_port, 500, 500, 100, 60_000),
            ],
            [
                ("A", "a1", "ACTIVE", "A"),
                ("C", "c1", "ACTIVE", "C"),
            ],
            [], global_records=2, global_bytes=20, peer_records=2, peer_bytes=20,
        )
        restored_daemon = h.start("maintenance-accounting-restored", restored_conf, restored_state)
        restored_status = h.status("maintenance-restored-status", restored_state)
        h.check(entry(restored_status, pending)["attempts"] >= entry(after, pending)["attempts"],
                "restored scheduler preserves or advances the durable attempt count")
        for field in ("peer_generation", "peer_spki_sha256", "expires_unix_ms"):
            h.check(entry(restored_status, pending)[field] == entry(after, pending)[field],
                    "resumed retry preserves original pending " + field)
        h.check(entry(restored_status, rejected)["rejection"] == entry(after, rejected)["rejection"],
                "resumed scheduler cannot rewrite terminal rejection provenance")
        h.check(reservations(restored_status) == (1, len("pending")), "restore reconstructs exact reservations")
        h.check(entry(restored_status, rejected)["status"] == "REJECTED", "restore reconstructs rejection")
        h.check(entry(restored_status, pending)["status"] == "PENDING", "restore reconstructs pending obligation")

        too_low_conf = write_config(
            h, "maintenance-accounting-restored-low", "B", restored_state, free_port(), "B",
            [
                ("A", a_port, 500, 500, 100, 60_000),
                ("C", c_port, 500, 500, 100, 60_000),
            ],
            [
                ("A", "a1", "ACTIVE", "A"),
                ("C", "c1", "ACTIVE", "C"),
            ],
            [], global_records=1, global_bytes=len("pending"), peer_records=1, peer_bytes=len("pending"),
        )
        # Existing obligations are never discarded merely because a later limit is lower.
        # New admission is blocked at the reconstructed boundary.
        restored_daemon.shutdown()
        low = h.start("maintenance-accounting-restored-low", too_low_conf, restored_state)
        low_status = h.status("maintenance-restored-low-status", restored_state)
        h.check(reservations(low_status) == (1, len("pending")), "lower startup limits retain existing obligation")
        denied_new = submit(
            h, "maintenance-restored-low-new-rejected", low.control, "B", "A",
            "denied/maintenance", operation("maintenance-low-new"), "x", expected=3,
        )
        h.check(denied_new["code"] == "OUTBOX_GLOBAL_RECORD_LIMIT", "lower limit blocks new reservation without dropping old work")
        low.shutdown()

    run_case("compaction_backup_restore_accounting", compaction_backup_restore_accounting)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, default=Path("node/bin/natrav-overlay"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--case", action="append", choices=[
            "terminal_and_transient_classification",
            "explicit_retry_after_policy_change",
            "exact_record_and_payload_limits",
            "terminal_release_and_peer_progress",
            "compaction_backup_restore_accounting",
        ],
    )
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output directory must not exist")
    harness = Harness(args.binary, args.output)
    started = time.time()
    status = "FAIL"
    return_code = 1
    try:
        run_suite(harness, set(args.case) if args.case else None)
        status = "PASS"
        return_code = 0
    except BaseException as exc:
        (harness.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_DELIVERY_GOVERNANCE_TESTS_V1",
            "status": status,
            "binary": str(harness.binary),
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "selected_cases": args.case or [],
            "started_unix": started,
            "elapsed_seconds": time.time() - started,
        }
        (harness.output / "SUMMARY.json").write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n"
        )
        (harness.output / "CASES.json").write_text(
            json.dumps(harness.cases, indent=2, sort_keys=True) + "\n"
        )
        (harness.output / "COMMANDS.json").write_text(
            json.dumps(harness.commands, indent=2, sort_keys=True) + "\n"
        )
        print(json.dumps(summary, sort_keys=True))
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
