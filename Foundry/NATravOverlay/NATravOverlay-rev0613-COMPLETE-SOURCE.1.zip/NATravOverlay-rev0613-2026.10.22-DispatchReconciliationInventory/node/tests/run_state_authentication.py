#!/usr/bin/env python3
"""Keyed journal: independent HMAC framing, tampering, atomic migration, and runtime continuation.

Fixtures attack only disposable local state. Python hmac independently encodes
and verifies the framing; its underlying SHA implementation may share OpenSSL.
No claim of independent cryptanalysis or trusted freshness is made.
"""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import hmac
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import struct
import subprocess
import time
from typing import Any

from run_persistent import Harness, Daemon, operation, free_port
from run_local_administration import v8_config
from run_live_configuration import candidate, activate
from run_authorization_actions import submit_evidence, submit_action, outbox_entry, independent_record, action_payload

HEADER_DOMAIN = b"NATRAV_OVERLAY_STATE_AUTH_HEADER_V1\0"
RECORD_DOMAIN = b"NATRAV_OVERLAY_STATE_AUTH_RECORD_V1\0"
CHECKSUM_DOMAIN = b"NATRAV_OVERLAY_JOURNAL_RECORD_V1\0"
KEY_DOMAIN = b"NATRAV_OVERLAY_STATE_AUTH_KEY_ID_V1"


def key_parts(path: Path) -> tuple[bytes, bytes, bytes]:
    b = path.read_bytes()
    assert b[:12] == b"NOSKEY01" + struct.pack("!I", 1)
    n = struct.unpack("!H", b[12:14])[0]
    generation, secret = b[14:14+n], b[14+n:]
    assert 1 <= n <= 64 and len(secret) == 32
    return generation, secret, hashlib.sha256(KEY_DOMAIN + struct.pack("!H", n) + generation + secret).digest()


def independent_open(raw: bytes, key: Path) -> tuple[bytes, list[bytes], bytes, list[bytes]]:
    """Returns authenticated header, plain frames, root, and original outer records."""
    _, secret, _ = key_parts(key)
    assert raw[:8] == b"NOAUTH01"
    n = struct.unpack("!I", raw[8:12])[0]
    head_end = 12 + n
    header = raw[:head_end+32]
    tag = header[-32:]
    assert hmac.compare_digest(hmac.digest(secret, HEADER_DOMAIN + raw[:head_end], "sha256"), tag)
    previous, offset, plain, records, seq = tag, len(header), [], [], 1
    while offset < len(raw):
        assert raw[offset:offset+4] == b"NAR1"
        length, sequence = struct.unpack("!IQ", raw[offset+4:offset+16])
        assert sequence == seq and raw[offset+16:offset+48] == previous
        end = offset + 48 + length
        actual = raw[end:end+32]
        assert hmac.compare_digest(hmac.digest(secret, RECORD_DOMAIN + tag + raw[offset:end], "sha256"), actual)
        frame = raw[offset+48:end]
        assert frame[:4] == b"NOJ1"
        assert struct.unpack("!I", frame[4:8])[0] + 40 == len(frame)
        assert hashlib.sha256(CHECKSUM_DOMAIN + frame[8:-32]).digest() == frame[-32:]
        plain.append(frame); records.append(raw[offset:end+32])
        previous, offset, seq = actual, end+32, seq+1
    assert offset == len(raw) and plain and plain[0][8] == 18
    return header, plain, previous, records


def independent_seal(header: bytes, frames: list[bytes], key: Path) -> bytes:
    _, secret, _ = key_parts(key)
    tag, previous, out = header[-32:], header[-32:], bytearray(header)
    for seq, frame in enumerate(frames, 1):
        record = b"NAR1" + struct.pack("!IQ", len(frame), seq) + previous + frame
        previous = hmac.digest(secret, RECORD_DOMAIN + tag + record, "sha256")
        out += record + previous
    return bytes(out)


def checksum_frame(frame: bytes) -> bytes:
    return frame[:-32] + hashlib.sha256(CHECKSUM_DOMAIN + frame[8:-32]).digest()


def inspect(h: Harness, label: str, state: Path, key: Path | None = None,
            expected: int = 0, node: str = "A") -> dict[str, Any]:
    args = ["inspect", "--state", str(state), "--node", node]
    if key: args += ["--state-auth-key", str(key)]
    value = h.run(label, args, expected=expected)
    assert value is not None
    return value


def new_key(h: Harness, root: Path, generation: str) -> Path:
    path = root / (generation + ".key")
    value = h.run("key-" + generation, ["state-auth-key-init", "--output", str(path), "--generation", generation])
    assert value
    _, secret, key_id = key_parts(path)
    h.check(value["purpose"] == "STATE_AUTHENTICATION" and value["key_id"] == key_id.hex(), "separate purpose and independently reproduced key ID")
    h.check(stat.S_IMODE(path.stat().st_mode) == 0o600 and secret.hex() not in json.dumps(value), "private key mode and no secret in result")
    return path


def migrate(h: Harness, label: str, state: Path, key: Path, node: str = "A") -> dict[str, Any]:
    value = h.run(label, ["state-auth-migrate", "--state", str(state), "--node", node,
                          "--new-key", str(key), "--reason", label])
    assert value
    return value


class KeyedDaemon(Daemon):
    def __init__(self, h: Harness, name: str, config: Path, state: Path, key: Path,
                 environment: dict[str, str] | None = None):
        super().__init__(h, name, config, state, environment)
        self.key = key

    def start(self) -> None:
        self.stdout_file, self.stderr_file = self.stdout_path.open("w"), self.stderr_path.open("w")
        self.process = subprocess.Popen([str(self.harness.binary), "run", "--config", str(self.config),
                                         "--state-auth-key", str(self.key)],
            stdout=self.stdout_file, stderr=self.stderr_file, text=True,
            env=dict(os.environ, **self.environment))
        def ready() -> bool:
            return bool(self.process and self.process.poll() is None and self.control.is_socket() and
                        "RUNTIME_READY" in self.stdout_path.read_text())
        try:
            self.harness.wait("keyed daemon " + self.name, ready, 8)
        except BaseException:
            self.cleanup()
            raise AssertionError(self.stdout_path.read_text() + self.stderr_path.read_text())
        self.harness.check(stat.S_IMODE(self.control.stat().st_mode) == 0o600, "keyed control mode")


def start(h: Harness, name: str, config: Path, state: Path, key: Path,
          environment: dict[str, str] | None = None) -> KeyedDaemon:
    d = KeyedDaemon(h, name, config, state, key, environment)
    h.daemons.append(d)
    d.start()
    return d


def run_suite(h: Harness, selected: set[str] | None) -> None:
    def case(name: str, fn: Any) -> None:
        if selected is None or name in selected: h.case(name, fn)

    def keys_and_explicit_migration() -> None:
        root = h.runtime / "keyed-basics"; root.mkdir(mode=0o700)
        state = root / "state"
        before = inspect(h, "unkeyed-initial", state)
        original = (state / "state.journal").read_bytes()
        key = new_key(h, root, "state-g1")
        denied = inspect(h, "explicit-key-rejects-unkeyed", state, key, 3)
        h.check(denied["code"] in ("STATE_AUTH_REQUIRED", "STATE_AUTH_TRUNCATED"), "no implicit migration or downgrade")
        h.check((state / "state.journal").read_bytes() == original, "refusal does not alter journal")
        invalid_args = ["state-auth-migrate", "--state", str(state), "--node", "A", "--new-key", str(key), "--reason", "candidate must verify"]
        child = subprocess.run([str(h.binary), *invalid_args], capture_output=True, text=True, timeout=10,
            env=dict(os.environ, NATRAV_OVERLAY_TEST_STATE_AUTH_CORRUPT_CANDIDATE="1"))
        h.commands.append({"label":"corrupt-actual-candidate", "args":invalid_args, "returncode":child.returncode, "stdout":child.stdout, "stderr":child.stderr})
        h.check(child.returncode == 3 and json.loads(child.stdout)["code"] == "STATE_AUTH_TAG_MISMATCH", "on-disk candidate must verify before publication")
        h.check((state/"state.journal").read_bytes() == original and not (state/"state.journal.compact.tmp").exists(), "bad candidate leaves source unchanged and no staging")
        migrated = migrate(h, "explicit-source-adoption", state, key)
        after = inspect(h, "keyed-initial", state, key)
        h.check(before["storage"]["logical_state_digest"] == after["storage"]["logical_state_digest"] == migrated["logical_state_digest"], "migration preserves application state")
        metadata = (state / "node.meta").read_bytes()
        downgraded = b"NATRAV_OVERLAY_NODE_STATE_V1\nA\n"
        (state / "node.meta").write_bytes(downgraded)
        h.check(inspect(h, "metadata-schema-downgrade", state, key, 3)["code"] == "STATE_AUTH_SCHEMA_REQUIRED", "keyed metadata cannot enter legacy schema migration")
        h.check((state / "node.meta").read_bytes() == downgraded, "metadata refusal is not silent repair")
        (state / "node.meta").write_bytes(metadata)
        raw = (state / "state.journal").read_bytes()
        _, _, root_tag, _ = independent_open(raw, key)
        h.check(root_tag.hex() == after["storage"]["state_authentication"]["root"], "independent journal HMAC root")
        denied = inspect(h, "missing-state-key", state, None, 3)
        h.check(denied["code"] == "STATE_AUTH_KEY_REQUIRED", "missing key fails closed")
        wrong = new_key(h, root, "state-wrong")
        h.check(inspect(h, "wrong-state-key", state, wrong, 3)["code"] == "STATE_AUTH_TAG_MISMATCH", "wrong secret rejected")
        for mode in (0o644, 0o400):
            key.chmod(mode)
            h.check(inspect(h, f"unsafe-key-mode-{mode}", state, key, 3)["code"] == "STATE_AUTH_KEY_FILE_UNSAFE", "key permissions exact")
        key.chmod(0o600)
        link = root / "linked.key"; link.symlink_to(key)
        h.check(inspect(h, "symlink-key", state, link, 3)["code"] == "STATE_AUTH_KEY_OPEN_FAILED", "final symlink key rejected")
        parent = root / "parent"; parent.symlink_to(root, target_is_directory=True)
        h.check(inspect(h, "parent-symlink-key", state, parent/key.name, 3)["code"] == "STATE_AUTH_KEY_PATH_INVALID", "parent symlink rejected")
        linked = root / "hard.key"; os.link(key, linked)
        h.check(inspect(h, "hardlink-key", state, key, 3)["code"] == "STATE_AUTH_KEY_FILE_UNSAFE", "hardlink key rejected")
        linked.unlink()
        backup_key = root / "backup.key"
        h.run("different-purpose-key", ["backup-key-init", "--output", str(backup_key), "--generation", "backup-g1"])
        h.check(inspect(h, "reject-backup-key", state, backup_key, 3)["code"] == "STATE_AUTH_KEY_FORMAT_INVALID", "backup key cannot be repurposed")
        target = root / "racing.key"
        def initialize(i: int) -> int:
            return subprocess.run([str(h.binary), "state-auth-key-init", "--output", str(target), "--generation", f"race-{i}"],
                                  capture_output=True, timeout=10).returncode
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            codes = list(pool.map(initialize, range(8)))
        h.commands.append({"label": "eight-racing-key-initializers", "returncodes": codes})
        h.check(codes.count(0) == 1 and codes.count(3) == 7, "exactly one no-replace initializer wins")
        key_parts(target)
        torn = root / "torn"; inspect(h, "unkeyed-torn-init", torn)
        (torn / "state.journal").write_bytes(b"NOJ1")
        h.run("reject-torn-migration", ["state-auth-migrate", "--state", str(torn), "--node", "A", "--new-key", str(key), "--reason", "do not repair"], expected=3)
        h.check((torn / "state.journal").read_bytes() == b"NOJ1", "strict migration never discards source tail")
    case("keys_and_explicit_migration", keys_and_explicit_migration)

    def authenticated_tampering_and_rollback_boundary() -> None:
        root = h.runtime / "tamper"; root.mkdir(mode=0o700)
        state = root / "state"; inspect(h, "tamper-initialize", state)
        key = new_key(h, root, "tamper-g1")
        migrate(h, "tamper-migrate", state, key)
        initial = (state / "state.journal").read_bytes()
        for i in range(3):
            h.run(f"append-{i}", ["offer", "--state", str(state), "--node", "A", "--peer", "B", "--connect", f"127.0.0.1:{free_port()}",
                  "--scope", "admin/test", "--operation", operation(f"tamper-{i}"), "--payload-text", f"tamper-value-{i}",
                  "--deadline-ms", "100", "--state-auth-key", str(key)], expected=3)
        good = (state / "state.journal").read_bytes()
        header, frames, _, records = independent_open(good, key)
        h.check(len(records) == 4, "one checkpoint and three independently verified records")
        def rejected(label: str, raw: bytes, code: str | None = None) -> None:
            (state / "state.journal").write_bytes(raw)
            value = inspect(h, label, state, key, 3)
            if code: h.check(value["code"] == code, f"{label}: exact failure {value}")
            h.check((state / "state.journal").read_bytes() == raw, label + ": no repair mutation")
        # Negative control selection fails here if MAC verification is removed.
        changed = good[:-1] + bytes([good[-1] ^ 1])
        rejected("altered-final-tag", changed, "STATE_AUTH_TAG_MISMATCH")
        changed = bytearray(records[-1]); changed[48+10] ^= 1
        f = checksum_frame(bytes(changed[48:-32])); changed[48:-32] = f
        rejected("recomputed-unkeyed-checksum", header + b"".join(records[:-1]) + changed, "STATE_AUTH_TAG_MISMATCH")
        rejected("middle-deletion", header + records[0] + records[2] + records[3], "STATE_AUTH_CHAIN_MISMATCH")
        rejected("middle-reordering", header + records[0] + records[2] + records[1] + records[3], "STATE_AUTH_CHAIN_MISMATCH")
        rejected("inserted-duplicate", header + records[0] + records[1] + records[1] + records[2] + records[3], "STATE_AUTH_CHAIN_MISMATCH")
        changed = bytearray(good); changed[25] ^= 1
        rejected("header-alteration", changed, "STATE_AUTH_TAG_MISMATCH")
        rejected("unkeyed-downgrade", b"".join(frames), "STATE_AUTH_REQUIRED")
        for n in (0, 1, 7, 11, len(header)-1, len(header), len(header)+2, len(good)-1):
            rejected(f"truncated-{n}", good[:n])
        # An independently signed bad semantic record still fails the normal decoder.
        bad = bytearray(frames[1]); bad[8] = 99; bad = checksum_frame(bytes(bad))
        semantically_bad = independent_seal(header, [frames[0], bad, *frames[2:]], key)
        rejected("valid-mac-invalid-kind", semantically_bad, "JOURNAL_CORRUPT")
        rejected("verify-all-before-apply", semantically_bad[:-1] + bytes([semantically_bad[-1] ^ 1]), "STATE_AUTH_TAG_MISMATCH")
        # Splicing another epoch of the same node/key must not share a chain.
        (state / "state.journal").write_bytes(good)
        backup = root / "epoch.nob"
        h.run("make-other-epoch", ["backup-export", "--state", str(state), "--node", "A", "--generation", "a-g1", "--output", str(backup), "--state-auth-key", str(key)])
        other = root / "other"
        h.run("other-epoch-restore", ["backup-restore", "--input", str(backup), "--destination", str(other), "--node", "A", "--generation", "a-g1", "--state-auth-key", str(key)])
        other_header, _, _, other_records = independent_open((other/"state.journal").read_bytes(), key)
        rejected("same-key-different-epoch-splice", other_header + records[0], "STATE_AUTH_CHAIN_MISMATCH")
        # Positive controls for the explicitly NOT established freshness property.
        for label, valid in (("valid-complete-prefix", header+b"".join(records[:-1])), ("whole-valid-old-snapshot", initial)):
            (state / "state.journal").write_bytes(valid)
            value = inspect(h, label, state, key)
            h.check(value["storage"]["state_authentication"]["freshness"] == "NOT_ESTABLISHED", "no invented rollback resistance")
        (state / "state.journal").write_bytes(independent_seal(header, frames, key))
        h.check(inspect(h, "independent-reencode", state, key)["outbox"]["pending"] == 3, "independent encoding accepted")
    case("authenticated_tampering_and_rollback_boundary", authenticated_tampering_and_rollback_boundary)

    def rotation_and_history() -> None:
        root = h.runtime / "rotation"; root.mkdir(mode=0o700)
        state = root / "state"; inspect(h, "rotate-initialize", state)
        key = new_key(h, root, "rotate-g1"); key2 = new_key(h, root, "rotate-g2")
        migrate(h, "rotation-migrate", state, key)
        before = inspect(h, "rotation-before", state, key)
        old = (state/"state.journal").read_bytes()
        args = ["state-auth-rotate", "--state", str(state), "--node", "A", "--state-auth-key", str(key), "--new-key", str(key2), "--reason", "explicit retirement"]
        rotated = h.run("rotation", args); assert rotated
        after = inspect(h, "rotation-after", state, key2)
        h.check(after["storage"]["logical_state_digest"] == before["storage"]["logical_state_digest"], "rotation preserves obligations")
        h.check([v["state"] for v in after["storage"]["state_authentication"]["history"]] == ["RETIRED", "ACTIVE"], "history has explicit active and retired generations")
        h.check(inspect(h, "retired-key-current-state", state, key, 3)["code"] == "STATE_AUTH_TAG_MISMATCH", "old key cannot authenticate current epoch")
        h.run("generation-reuse-denied", ["state-auth-rotate", "--state", str(state), "--node", "A", "--state-auth-key", str(key2), "--new-key", str(key), "--reason", "invalid reuse"], expected=3)
        reused = root / "same-secret.key"
        generation, secret, _ = key_parts(key2)
        generation = b"new-name-same-secret"
        reused.write_bytes(b"NOSKEY01" + struct.pack("!IH", 1, len(generation)) + generation + secret); reused.chmod(0o600)
        result = h.run("secret-reuse-denied", ["state-auth-rotate", "--state", str(state), "--node", "A", "--state-auth-key", str(key2), "--new-key", str(reused), "--reason", "not a key rotation"], expected=3)
        h.check(result and result["code"] == "STATE_AUTH_ROTATION_REUSES_KEY", "new label alone is not fresh secret")
        independent_open((state/"state.journal").read_bytes(), key2)
        archived = root/"archived"; shutil.copytree(state, archived); (archived/"state.journal").write_bytes(old)
        h.check(inspect(h, "old-state-explicit-old-key", archived, key)["storage"]["state_authentication"]["generation"] == "rotate-g1", "retirement does not erase old-key archives")
    case("rotation_and_history", rotation_and_history)

    def publication_kill_boundaries() -> None:
        root = h.runtime / "publication"; root.mkdir(mode=0o700)
        key = new_key(h, root, "kill-g1"); key2 = new_key(h, root, "kill-g2")
        for rotate in (False, True):
            for before in (True, False):
                label = ("rotate" if rotate else "migrate") + ("-before" if before else "-after")
                state = root/label; inspect(h, label+"-initialize", state)
                if rotate: migrate(h, label+"-prepare", state, key)
                original = (state/"state.journal").read_bytes()
                args = ["state-auth-rotate" if rotate else "state-auth-migrate", "--state", str(state), "--node", "A",
                        "--new-key", str(key2 if rotate else key), "--reason", label]
                if rotate: args += ["--state-auth-key", str(key)]
                point = "BEFORE_PUBLISH" if before else "AFTER_PUBLISH"
                log = h.logs/(label+".stderr.txt")
                with log.open("w") as err:
                    child = subprocess.Popen([str(h.binary), *args], stdout=subprocess.DEVNULL, stderr=err,
                        env=dict(os.environ, **{f"NATRAV_OVERLAY_TEST_STATE_AUTH_{point}_MS":"10000"}))
                    try:
                        h.wait(label+" marker", lambda: ("STATE_AUTH_TEST_PAUSE " + point) in log.read_text(), 8)
                        h.check((state/"state.journal").read_bytes() == original if before else (state/"state.journal").read_bytes() != original, "exact publication boundary")
                        held = inspect(h, label+"-busy", state, key if rotate else None, 3)
                        h.check(held["code"] == "STATE_BUSY", "stable state ownership during publication")
                        child.kill(); child.wait(timeout=5)
                        h.check(child.returncode == -signal.SIGKILL, "actual SIGKILL")
                        h.commands.append({"label": label+"-kill", "args": args, "returncode": child.returncode, "point":point})
                    finally:
                        if child.poll() is None: child.kill(); child.wait(timeout=5)
                active = (key if rotate else None) if before else (key2 if rotate else key)
                inspect(h, label+"-recovered", state, active)
                h.check(not (state/"state.journal.compact.tmp").exists(), "unpublished sibling cleanup under state lock")
                if before:
                    h.run(label+"-retry", args)
                    inspect(h, label+"-retry-reconstructed", state, key2 if rotate else key)
    case("publication_kill_boundaries", publication_kill_boundaries)

    def live_delivery_actions_configuration_encrypted_restore() -> None:
        root = h.runtime / "continuation"; root.mkdir(mode=0o700)
        a, b, c = root/"a", root/"b", root/"c"
        ap, bp, cp = free_port(), free_port(), free_port()
        grants = [(os.geteuid(), ["ALL"])]
        ac = v8_config(h, "auth-a", "A", a, ap, "a-initial", grants, peers=[("B",bp),("C",cp)])
        ac.write_text(ac.read_text()+"authorize=B,*,ACTION,counter.add\n")
        bc = v8_config(h, "auth-b", "B", b, bp, "b-initial", grants, peers=[("A",ap)])
        cc = v8_config(h, "auth-c", "C", c, cp, "c-initial", grants, inbound=["A"])
        for state, node in ((a,"A"),(b,"B")):
            inspect(h, "initialize-"+node, state, node=node)
        ak, bk = new_key(h,root,"node-a-auth-1"), new_key(h,root,"node-b-auth-1")
        da, db = h.start("before-auth-a",ac,a), h.start("before-auth-b",bc,b)
        action, pending, rejected = operation("keyed-action"), operation("keyed-pending"), operation("keyed-rejected")
        submit_action(h,"keyed-action",db.control,"B","A",action,7)
        h.wait("keyed action completes",lambda:h.status("action-status",a)["actions"]["counter_value"]==7)
        submit_evidence(h,"keyed-pending",da.control,"A","C","admin/test",pending,"pending-byte-obligation")
        submit_evidence(h,"keyed-rejected",da.control,"A","B","forbidden/scope",rejected,"deny me")
        h.wait("keyed rejection",lambda:outbox_entry(h.status("rejection-status",a),rejected)["status"]=="REJECTED")
        da.shutdown(); db.shutdown()
        source = inspect(h,"nonempty-migration-before",a)
        migrate(h,"migrate-A",a,ak); migrate(h,"migrate-B",b,bk,"B")
        adopted = inspect(h,"nonempty-migration-after",a,ak)
        h.check(source["storage"]["logical_state_digest"] == adopted["storage"]["logical_state_digest"], "nonempty migration preserves complete obligations and effects")
        da, db = start(h,"auth-a",ac,a,ak), start(h,"auth-b",bc,b,bk)
        next_conf = candidate(h,ac,"auth-a-next","a-second",lambda text:text+"session_max_operations=8\n")
        activate(h,"keyed-config-activation",a,next_conf)
        compacted = h.run("keyed-live-compact",["compact","--control",str(da.control),"--deadline-ms","10000"]); assert compacted
        live = h.status("keyed-live-status",a)
        h.check(live["storage"]["state_authentication"]["purpose"]=="COMPACT", "live compaction remains authenticated")
        h.check(live["runtime_configuration"]["generation"]=="a-second", "live configuration is journaled under key")
        # Terminate a daemon after the synchronized drain record, not a synthetic state edit.
        log = h.logs/"drain-client.err"
        with log.open("w") as err:
            client = subprocess.Popen([str(h.binary),"drain-shutdown","--control",str(da.control),"--reason","kill-test","--drain-deadline-ms","10000","--deadline-ms","2000"], stdout=subprocess.DEVNULL,stderr=err)
            try:
                h.wait("durable drain",lambda:h.status("drain-status",a)["lifecycle"]["mode"]=="DRAINING")
                da.kill(); client.wait(timeout=5)
                h.commands.append({"label":"keyed-interrupted-drain","returncode":client.returncode})
            finally:
                if client.poll() is None: client.kill();client.wait(timeout=5)
        before = inspect(h,"keyed-before-backup",a,ak)
        independent_open((a/"state.journal").read_bytes(),ak)
        enc = root/"backup.key"
        h.run("encryption-key",["backup-key-init","--output",str(enc),"--generation","backup-1"])
        ident=h.identity("A"); archive=root/"keyed-encrypted.nob"
        exported=h.run("keyed-encrypted-export",["backup-export","--state",str(a),"--node","A","--generation","a-g1","--output",str(archive),
            "--sign-key",str(ident.private_key),"--sign-cert",str(ident.certificate),"--encrypt-key",str(enc),"--state-auth-key",str(ak)])
        h.check(exported and exported["state_authentication"]=="HMAC_SHA256_CHAIN_V1" and exported["encrypted"], "separate state and encryption result")
        verify_args=["backup-verify","--input",str(archive),"--decrypt-key",str(enc),"--trusted-cert",str(ident.certificate),"--require-signature","yes"]
        denied=h.run("encrypted-backup-needs-state-key",verify_args,expected=3)
        h.check(denied and denied["code"]=="STATE_AUTH_KEY_REQUIRED", "encryption key cannot replace state key")
        h.run("keyed-backup-verify",verify_args+["--state-auth-key",str(ak)])
        dest=root/"moved"
        h.run("keyed-backup-restore",["backup-restore","--input",str(archive),"--destination",str(dest),"--node","A","--generation","a-g1",
            "--decrypt-key",str(enc),"--trusted-cert",str(ident.certificate),"--require-signature","yes","--state-auth-key",str(ak)])
        restored=inspect(h,"keyed-restored",dest,ak)
        h.check(restored["storage"]["logical_state_digest"]==before["storage"]["logical_state_digest"],"backup restore logical equality before scheduler starts")
        moved_conf=candidate(h,next_conf,"keyed-moved","a-moved",lambda text:text.replace(f"state={a}",f"state={dest}"))
        h.run("keyed-relocation",["state-relocate","--state",str(dest),"--node","A","--candidate",str(moved_conf),"--reason","keyed relocation","--state-auth-key",str(ak)])
        moved=start(h,"auth-a-moved",moved_conf,dest,ak)
        status=h.status("keyed-after-restart",dest)
        h.check(status["lifecycle"]["mode"]=="QUIESCED" and status["lifecycle"]["interrupted_drain"],"interrupted lifecycle preserved through keyed restore")
        dc=h.start("keyed-c",cc,c)
        h.run("keyed-resume",["resume","--control",str(moved.control),"--reason","resume after restore"])
        h.wait("resumed queued delivery",lambda:outbox_entry(h.status("keyed-pending-status",dest),pending)["status"]=="ACKED")
        reply=independent_record(h,ap,"B","B","A",action,"actions/counter.add/v1",action_payload(7))
        h.check(reply["kind"] == "receipt" and reply["disposition"] == 2,"completed action replay returns duplicate receipt")
        h.check(h.status("keyed-counter-after-replay",dest)["actions"]["counter_value"]==7,"counter effect did not repeat")
        moved.shutdown(); db.shutdown(); dc.shutdown()
        ak2=new_key(h,root,"node-a-auth-2")
        h.run("rotate-live-history",["state-auth-rotate","--state",str(dest),"--node","A","--state-auth-key",str(ak),"--new-key",str(ak2),"--reason","retire old state key"])
        again=start(h,"keyed-a-rotated",moved_conf,dest,ak2)
        restarted_c=h.start("keyed-c-restarted",cc,c)
        later=operation("keyed-later")
        submit_evidence(h,"keyed-new-work",again.control,"A","C","admin/test",later,"new work under new state key")
        h.wait("new key delivery",lambda:outbox_entry(h.status("keyed-new-status",dest),later)["status"]=="ACKED")
        again.shutdown();restarted_c.shutdown()
        final=inspect(h,"keyed-final",dest,ak2)
        receiver=inspect(h,"keyed-c-final",c,node="C")
        h.check(receiver["inbound"]["count"]==2,"recipient has two distinct records exactly once")
        h.check(final["actions"]["counter_value"]==7 and len(final["storage"]["state_authentication"]["history"])==2,"effects and key history preserved")
        independent_open((dest/"state.journal").read_bytes(),ak2)
    case("live_delivery_actions_configuration_encrypted_restore",live_delivery_actions_configuration_encrypted_restore)

    def keyed_compaction_boundaries() -> None:
        root=h.runtime/"compaction-kills";root.mkdir(mode=0o700)
        key=new_key(h,root,"compact-key")
        for before in (True,False):
            label="compact-before" if before else "compact-after"
            state=root/label; inspect(h,label+"-init",state);migrate(h,label+"-migrate",state,key)
            conf=h.config(label,"A",state,free_port(),[])
            point="BEFORE" if before else "AFTER"
            daemon=start(h,label,conf,state,key,{f"NATRAV_OVERLAY_TEST_COMPACT_{point}_PUBLISH_MS":"10000"})
            journal=state/"state.journal";original=journal.read_bytes();old_inode=journal.stat().st_ino
            child=subprocess.Popen([str(h.binary),"compact","--control",str(daemon.control),"--deadline-ms","10000"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            try:
                if before: h.wait(label,lambda:(state/"state.journal.compact.tmp").exists(),8)
                else: h.wait(label,lambda:journal.stat().st_ino!=old_inode,8)
                daemon.kill();child.wait(timeout=5)
                h.commands.append({"label":label+"-client","returncode":child.returncode})
            finally:
                if child.poll() is None:child.kill();child.wait(timeout=5)
            if before:h.check(journal.read_bytes()==original,"old keyed journal authoritative before publication")
            snapshot=inspect(h,label+"-inspect",state,key)
            h.check(snapshot["storage"]["maintenance_generation"]==(0 if before else 1),"exact keyed compaction generation after kill")
            independent_open(journal.read_bytes(),key)
            h.check(not (state/"state.journal.compact.tmp").exists(),"stale candidate cleanup")
            reopened=start(h,label+"-reopened",conf,state,key);reopened.shutdown()
    case("keyed_compaction_boundaries",keyed_compaction_boundaries)


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--binary",type=Path,required=True);p.add_argument("--output",type=Path,required=True)
    p.add_argument("--case",action="append",choices=["keys_and_explicit_migration","authenticated_tampering_and_rollback_boundary","rotation_and_history",
        "publication_kill_boundaries","live_delivery_actions_configuration_encrypted_restore","keyed_compaction_boundaries"])
    a=p.parse_args()
    if a.output.exists():p.error("output already exists")
    h=Harness(a.binary,a.output);started=time.time();code=1
    try:
        run_suite(h,set(a.case) if a.case else None);code=0
    except BaseException as exc:
        (h.output/"FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}",file=os.sys.stderr)
    finally:
        h.cleanup()
        summary={"format":"NATRAV_OVERLAY_STATE_AUTH_TESTS_V1","status":"PASS" if code==0 else "FAIL",
            "binary_sha256":hashlib.sha256(h.binary.read_bytes()).hexdigest(),"cases_passed":sum(c["status"]=="PASS" for c in h.cases),
            "cases_total":len(h.cases),"assertions":h.assertions,"commands":len(h.commands),"elapsed_seconds":time.time()-started}
        for name,obj in (("SUMMARY.json",summary),("CASES.json",h.cases),("COMMANDS.json",h.commands)):
            (h.output/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+"\n")
        print(json.dumps(summary))
    return code
if __name__=="__main__":raise SystemExit(main())
