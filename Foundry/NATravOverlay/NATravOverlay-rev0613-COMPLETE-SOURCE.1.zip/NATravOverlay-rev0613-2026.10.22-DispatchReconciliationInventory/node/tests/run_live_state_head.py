#!/usr/bin/env python3
"""Bounded live authenticated heads on owned native processes and loopback peers.

The independent verifier authenticates raw bytes, including every candidate
prefix; it never trusts the product selector as its own expected answer.
"""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import select
import socket
import subprocess
import time
from typing import Any

from run_persistent import Harness, free_port, operation, raw_control
from run_state_authentication import inspect, new_key, migrate, start, independent_open
from run_state_expectations import selector, start_expected
from run_local_administration import (v8_config, expose_control_for_uid,
    restore_owner_only_control, run_as_uid)
from run_live_configuration import candidate, activate
from run_control_authorization import Client, packet
from run_authenticated_recovery import file_accounts

UID, OTHER = 65534, 65533
CASES = ('keyed_observation', 'unkeyed_and_strict_protocol', 'current_inspect_authority',
    'opening_expectation_and_restart', 'concurrent_receipts', 'compaction_linearization',
    'quiesce_and_drain', 'authorization_lease_boundary')


def setup(h: Harness, name: str, *, env=None, keyed=True, peers=None, inbound=None):
    root = h.runtime / name; root.mkdir(mode=0o755)
    state = root / 'state'
    inspect(h, name+'-initialize', state)
    key = new_key(h, root, name+'-key') if keyed else None
    if key: migrate(h, name+'-migrate', state, key)
    conf = v8_config(h, name, 'A', state, free_port(), name+'-g1',
        [(os.geteuid(), ['ALL']), (UID, ['INSPECT', 'SUBMIT']), (OTHER, ['SUBMIT'])],
        peers=peers, inbound=inbound, deadline_ms=3000)
    if key: daemon = start(h, name, conf, state, key, env)
    else: daemon = h.start(name, conf, state, env)
    return root, state, key, conf, daemon


def head(h: Harness, label: str, d) -> dict[str, Any]:
    value = h.run(label, ['state-head', '--control', str(d.control)])
    assert value
    check_shape(h, value)
    return value


def check_shape(h: Harness, value: dict[str, Any]) -> None:
    h.check(value['ok'] and value['format'] == 'NATRAV_OVERLAY_LIVE_STATE_HEAD_V1', 'versioned successful observation')
    h.check(value['command_class'] == 'INSPECT', 'normal control annotation requires INSPECT')
    h.check(len(json.dumps(value, separators=(',', ':')).encode()) <= 4096, 'complete annotated JSON fits fixed limit')
    h.check(value['state_head']['expectation'] == 'NOT_CHECKED_HERE' and
        value['state_head']['freshness'] == 'NOT_ESTABLISHED', 'live head never inherits an opening freshness claim')
    h.check(value['observation'] == {'consistency':'ONE_STATE_LOCK', 'validation':'REPLAY_AND_LIVE_APPLICATION',
        'disk_reaudit':False, 'may_advance_after_sample':True, 'freshness':'NOT_ESTABLISHED'}, 'sample and disk-reverification limits explicit')
    h.check(value['automatic_update'] is False and value['state_head']['automatic_update'] is False, 'no anchor update')
    h.check(set(value) == {'format','ok','node','mode','journal_bytes','state_head','authentication',
        'opening_expectation','observation','automatic_update','request_id','principal_uid','principal_gid','principal_pid','command_class'},
        'only fixed metadata and normal request/principal annotations escape')
    if value['authentication'] is not None:
        a=value['authentication']
        h.check(set(a) == {'generation','key_id','epoch','root','records'}, 'no authentication histories, reasons, or paths')
        h.check(value['state_head']['selector'] == ':'.join(('NASH1', value['node'], a['generation'],
            a['key_id'], a['epoch'], a['root'], str(a['records']), str(value['journal_bytes']))), 'all displayed fields form one exact selector')


def check_raw(h: Harness, value, state: Path, key: Path):
    raw=(state/'state.journal').read_bytes()
    h.check(selector(raw, key) == value['state_head']['selector'], 'independent HMAC and raw fields equal live selector')
    return raw


def async_cli(h, label, args):
    before=time.monotonic()
    p=subprocess.Popen([str(h.binary), *args], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    def finish(expected=0):
        stdout,stderr=p.communicate(timeout=12)
        h.commands.append({'label':label, 'args':args, 'returncode':p.returncode, 'stdout':stdout,
            'stderr':stderr, 'elapsed_seconds':time.monotonic()-before})
        h.check(p.returncode==expected, f'{label}: {p.returncode}, expected {expected}: {stdout!r} {stderr!r}')
        return json.loads(stdout.strip().splitlines()[-1])
    return p,finish


def run_suite(h: Harness, selected: set[str] | None) -> None:
    def case(name, fn):
        if selected is None or name in selected: h.case(name,fn)

    def keyed_observation():
        _,state,key,_,d=setup(h,'stable'); assert key
        before=file_accounts(state); samples=[]
        for i in range(8):
            value=head(h, f'stable-{i}', d); check_raw(h,value,state,key);samples.append(value)
            h.check(value['opening_expectation'] == {'result':'NOT_SUPPLIED','scope':'PROCESS_OPEN_INPUT_ONLY',
                'matches_observation':None}, 'no synthetic process-opening expectation')
        h.check(file_accounts(state)==before, 'successful observations change no regular state file, inode, mode, mtime or content')
        # A separate client fragments every byte; no local secret key is needed.
        value=h.run('fragmented-head',['state-head','--control',str(d.control),'--read-quantum','1','--write-quantum','1'])
        assert value;check_shape(h,value);check_raw(h,value,state,key)
        h.check(file_accounts(state)==before, 'fragmentation remains observational')
        d.kill(); audited=inspect(h,'stable-offline',state,key)
        h.check(audited['state_head']['selector']==samples[-1]['state_head']['selector'], 'offline complete replay agrees after observation-only process kill')
        h.check(not any(e['command']=='STATE_HEAD' for e in audited['local_control']['entries']), 'no successful head-observation event persisted')
        (h.output/'OBSERVATION.json').write_text(json.dumps(samples[-1],indent=2)+'\n')
    case('keyed_observation',keyed_observation)

    def unkeyed_and_strict_protocol():
        _,state,_,_,d=setup(h,'unkeyed',keyed=False)
        before=file_accounts(state)
        value=head(h,'unkeyed-head',d)
        h.check(value['mode']=='UNKEYED' and value['authentication'] is None and
            value['state_head']['selector'] is None, 'unkeyed state cannot fabricate an authenticated selector')
        h.check(file_accounts(state)==before, 'unkeyed observation also writes nothing')
        for i,data in enumerate((packet(41,b'\0'), packet(41,b'x'*512),packet(41,packet(41)),b'NOC1',b'NOC2'+bytes([41]))):
            ok,error=raw_control(d.control,data)
            h.check(not ok and error.get('ok') is False and 'state_head' not in error, f'malformed request {i} yields no observation')
        for option,value in (('--node','other'),('--state',str(state)),('--expected-state-head','NASH1:fake'),
            ('--state-auth-key','/no/key'),('--principal-uid',str(UID)),('--max-bytes','99999'),('--logical-digest','yes')):
            error=h.run('head-reject-'+option[2:],['state-head','--control',str(d.control),option,value],expected=3)
            h.check(error and error['code']=='UNKNOWN_ARGUMENT', 'head accepts neither impersonation, state inputs, nor semantic alternatives')
        d.shutdown()
    case('unkeyed_and_strict_protocol',unkeyed_and_strict_protocol)

    def current_inspect_authority():
        _,state,key,conf,d=setup(h,'authority',env={'NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER':'1'}); assert key
        expose_control_for_uid(state)
        allowed=run_as_uid(h,'inspect-only-head',UID,UID,['state-head','--control',str(d.control)],0)
        assert allowed;check_shape(h,allowed)
        h.check(allowed['principal_uid']==UID, 'actual SO_PEERCRED principal, not owner impersonation')
        denied=run_as_uid(h,'submit-only-head',OTHER,OTHER,['state-head','--control',str(d.control)],3)
        h.check(denied and denied['code']=='LOCAL_CONTROL_CLASS_DENIED', 'SUBMIT alone does not grant head inspection')
        def grants(base,label,classes):
            c=candidate(h,base,label,label+'-g',lambda text: text.replace(f'local_control={UID},INSPECT,SUBMIT',
                f'local_control={UID},{classes}').replace(f'local_control={UID},SUBMIT\n',f'local_control={UID},{classes}\n'))
            activate(h,label,state,c);return c
        client=Client(h,d,'head-revoked-during-read',packet(41))
        try:
            revoked=grants(conf,'head-revoked','SUBMIT')
            rejected=client.finish()
            h.check(rejected.get('code')=='LOCAL_CONTROL_CLASS_DENIED' and 'state_head' not in rejected,
                'revoked INSPECT during partial request cannot expose head')
        finally:client.close()
        client=Client(h,d,'head-granted-during-read',packet(41))
        try:
            grants(revoked,'head-granted','INSPECT,SUBMIT')
            newly=client.finish();check_shape(h,newly);check_raw(h,newly,state,key)
        finally:client.close()
        restore_owner_only_control(state);d.kill()
        result=inspect(h,'head-authority-replay',state,key)
        events=result['local_control']['entries'];history=result['runtime_configuration']['events']
        matches=[e for e in events if e['request_id']==rejected['request_id'] and e['uid']==UID]
        h.check(len(matches)==1 and matches[0]['decision']=='DENIED' and matches[0]['command']=='STATE_HEAD', 'one normal denied event, no false success')
        h.check(history[matches[0]['configuration_event']-1]['generation']=='head-revoked-g', 'denial belongs to policy accepted after request started')
        h.check(not any(e['command']=='STATE_HEAD' and e['decision']=='AUTHORIZED' for e in events), 'successful head reads remain nonjournaled')
    case('current_inspect_authority',current_inspect_authority)

    def opening_expectation_and_restart():
        _,state,key,conf,d=setup(h,'opening');assert key;d.shutdown()
        pin=selector((state/'state.journal').read_bytes(),key)
        expected=start_expected(h,'opening-matched',conf,state,key,pin)
        first=head(h,'opening-first-head',expected);check_raw(h,first,state,key)
        h.check(first['opening_expectation']['result']=='MATCHED_AT_OPEN' and
            first['opening_expectation']['matches_observation'] is True,'actual successful input match is retained separately')
        h.run('opening-compact',['compact','--control',str(expected.control)])
        later=head(h,'opening-after-compact',expected);check_raw(h,later,state,key)
        h.check(later['state_head']['selector']!=pin and later['opening_expectation']['result']=='MATCHED_AT_OPEN' and
            later['opening_expectation']['matches_observation'] is False,'compaction does not silently re-anchor opening expectation')
        expected.kill()
        denied=h.run('opening-restart-old',['run','--config',str(conf),'--state-auth-key',str(key),'--expected-state-head',pin],expected=3)
        h.check(denied and denied['code']=='STATE_HEAD_EXPECTATION_MISMATCH','old startup selector cannot reopen later compacted state')
        fresh_pin=selector((state/'state.journal').read_bytes(),key)
        reopened=start_expected(h,'opening-current',conf,state,key,fresh_pin)
        current=head(h,'opening-current-head',reopened)
        h.check(current['opening_expectation']['matches_observation'] is True,'deliberate new per-open input matches')
        reopened.kill()
        plain=start(h,'opening-no-expectation',conf,state,key)
        observed=head(h,'opening-absent-after-restart',plain)
        h.check(observed['opening_expectation']['result']=='NOT_SUPPLIED','opening expectation is not persisted into restart')
        plain.shutdown()
    case('opening_expectation_and_restart',opening_expectation_and_restart)

    def concurrent_receipts():
        _,state,key,conf,a=setup(h,'receipts',inbound=['B']);assert key
        port=int(next(x for x in conf.read_text().splitlines() if x.startswith('listen=')).split(':')[-1])
        bstate=h.runtime/'sender'
        bconf=v8_config(h,'sender','B',bstate,free_port(),'sender-g1',[(os.geteuid(),['ALL'])],peers=[('A',port)],deadline_ms=3000)
        b=h.start('sender',bconf,bstate)
        baseline=(state/'state.journal').read_bytes();samples=[]
        def submit_many():
            for i in range(18):
                h.run(f'concurrent-submit-{i}',['submit','--control',str(b.control),'--node','B','--peer','A',
                    '--scope','admin/test','--operation',operation(f'live-head-{i}'),'--payload-text','PRIVATE-EVIDENCE-'+('x'*8192)])
                time.sleep(0.012)
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future=pool.submit(submit_many)
            while not future.done() or len(samples)<30:
                ok,value=raw_control(a.control,packet(41));h.check(ok,'sample during real TLS delivery succeeds')
                check_shape(h,value);samples.append(value);time.sleep(0.006)
                if len(samples)>1000:raise AssertionError('concurrent sampling exceeded bound')
            future.result(timeout=10)
        h.wait('all real peer receipts',lambda:h.status('sender-wait',bstate,logical_digest=False)['outbox']['acked']==18)
        final=head(h,'concurrent-final-head',a);samples.append(final)
        raw=check_raw(h,final,state,key)
        header,frames,_,records=independent_open(raw,key)
        prefix=header;valid={}
        # Header identity comes from the independent selector; every record's
        # HMAC and plain checksum have already been checked by independent_open.
        fields=selector(raw,key).split(':')
        for i,record in enumerate(records,1):
            prefix+=record
            fields[5]=record[-32:].hex();fields[6]=str(i);fields[7]=str(len(prefix))
            valid[':'.join(fields)]=len(prefix)
        for sample in samples:
            token=sample['state_head']['selector']
            h.check(token in valid and valid[token]==sample['journal_bytes'],'every sample is an actual complete authenticated prefix, never mixed fields')
        h.check(len({v['state_head']['selector'] for v in samples})>=2,'live samples actually span progress')
        h.check(len(raw)>len(baseline),'real inbound evidence advances authenticated journal')
        h.check(all('PRIVATE-EVIDENCE' not in json.dumps(v) for v in samples),'head never returns evidence payload')
        (h.output/'CONCURRENT-SAMPLES.json').write_text(json.dumps({'samples':len(samples),'distinct_heads':len({v['state_head']['selector'] for v in samples}),
            'maximum_response_bytes':max(len(json.dumps(v,separators=(',',':')).encode()) for v in samples),
            'final_selector':final['state_head']['selector'],'independent_prefixes':len(frames),'tls_deliveries':18},indent=2)+'\n')
        a.kill();b.shutdown()
    case('concurrent_receipts',concurrent_receipts)

    def compaction_linearization():
        _,state,key,_,d=setup(h,'compact-lock',env={'NATRAV_OVERLAY_TEST_COMPACT_AFTER_PUBLISH_MS':'700',
            'NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER':'1'});assert key
        old=head(h,'before-racing-compact',d);inode=(state/'state.journal').stat().st_ino
        p,finish=async_cli(h,'racing-compact',['compact','--control',str(d.control)])
        try:
            h.wait('compaction renamed but retains state mutex',lambda:(state/'state.journal').stat().st_ino!=inode)
            q,head_finish=async_cli(h,'blocked-compaction-head',['state-head','--control',str(d.control)])
            try:
                time.sleep(0.12)
                h.check(q.poll() is None and not select.select([q.stdout],[],[],0)[0], 'head does not escape while compaction publication account is incomplete')
                finish();value=head_finish();check_shape(h,value);check_raw(h,value,state,key)
                h.check(value['authentication']['epoch']!=old['authentication']['epoch'],'returned account uses the new complete epoch')
            finally:
                if q.poll() is None:q.kill();q.wait(timeout=5)
        finally:
            if p.poll() is None:p.kill();p.wait(timeout=5)
        d.shutdown()
    case('compaction_linearization',compaction_linearization)

    def quiesce_and_drain():
        # Reserve unavailable endpoints owned by this test; never scan or use an
        # arbitrary remote service. B later becomes a real configured TLS peer.
        with socket.socket() as b_reserved, socket.socket() as c_reserved:
            b_reserved.bind(('127.0.0.1',0));bp=b_reserved.getsockname()[1]
            c_reserved.bind(('127.0.0.1',0));cp=c_reserved.getsockname()[1]
            _,state,key,_,a=setup(h,'lifecycle',peers=[('B',bp),('C',cp)]);assert key
            h.run('before-quiesce-submit',['submit','--control',str(a.control),'--node','A','--peer','B','--scope','admin/test',
                '--operation',operation('quiesced-obligation'),'--payload-text','prior durable obligation'])
            h.run('enter-quiesce',['quiesce','--control',str(a.control),'--reason','capture is not a freeze'])
            before=head(h,'quiesced-head',a)
            b_reserved.close()
            bstate=h.runtime/'lifecycle-b'
            bc=v8_config(h,'lifecycle-b','B',bstate,bp,'life-b-g1',[(os.geteuid(),['ALL'])],inbound=['A'])
            b=h.start('lifecycle-b',bc,bstate)
            h.wait('prior obligation delivered while quiesced',lambda:h.status('quiesced-progress',state,logical_digest=False)['outbox']['acked']==1)
            after=head(h,'quiesced-after-receipt',a)
            h.check(before['state_head']['selector']!=after['state_head']['selector'],'quiescence permits durable obligation progress, so capture is not stable by definition')
            h.check(h.status('still-quiesced',state,logical_digest=False)['lifecycle']['mode']=='QUIESCED','head sampling does not resume local mutations')
            h.run('resume-for-drain',['resume','--control',str(a.control),'--reason','prepare pending drain'])
            h.run('drain-pending',['submit','--control',str(a.control),'--node','A','--peer','C','--scope','admin/test',
                '--operation',operation('drain-unavailable'),'--payload-text','preserved pending'])
            p,finish=async_cli(h,'drain-with-observation',['drain-shutdown','--control',str(a.control),
                '--reason','bounded capture','--drain-deadline-ms','1500','--deadline-ms','5000'])
            try:
                h.wait('actual nonempty drain',lambda:h.status('drain-mode',state,logical_digest=False)['lifecycle']['mode']=='DRAINING')
                for i in range(4):head(h,f'draining-head-{i}',a)
                result=finish();h.check(result['deadline_reached'] is True and result['completed'] is False,'inspection neither drains work nor removes the existing deadline')
                assert a.process;a.process.wait(timeout=5);h.check(a.process.returncode==0,'drain exits normally');a._close_files()
            finally:
                if p.poll() is None:p.kill();p.wait(timeout=5)
            final=inspect(h,'drain-final',state,key)
            h.check(not any(e['command']=='STATE_HEAD' for e in final['local_control']['entries']),'quiesce and drain observation adds no successful events')
            b.shutdown()
    case('quiesce_and_drain',quiesce_and_drain)

    def authorization_lease_boundary():
        _,state,key,conf,d=setup(h,'lease',env={'NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER':'1',
            'NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_COMMAND':'STATE_HEAD',
            'NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_PAUSE_MS':'650'});assert key
        expose_control_for_uid(state)
        client=Client(h,d,'authorized-head-before-revoke',packet(41),split=False)
        activation=None
        try:
            h.wait('authorized head retaining configuration lease',lambda:f'CONTROL_AUTHORIZED STATE_HEAD {UID}' in d.stderr_path.read_text())
            raw=(state/'state.journal').read_bytes();old=selector(raw,key)
            revoked=candidate(h,conf,'lease-revocation','lease-g2',lambda text:text.replace(f'local_control={UID},INSPECT,SUBMIT',f'local_control={UID},SUBMIT'))
            activation,finish=async_cli(h,'queued-head-revocation',['config-activate','--control',str(d.control),'--candidate',str(revoked),'--reason','remove inspection'])
            h.wait('configuration request reached publication handoff',lambda:'CONTROL_CONFIGURATION_HANDOFF' in d.stderr_path.read_text())
            h.check(activation.poll() is None,'accepted-generation lease blocks competing publication through sample')
            value=client.finish();check_shape(h,value)
            h.check(value['state_head']['selector']==old,'sample precedes queued configuration publication')
            finish()
            denied=run_as_uid(h,'head-after-lease-revoke',UID,UID,['state-head','--control',str(d.control)],3)
            h.check(denied and denied['code']=='LOCAL_CONTROL_CLASS_DENIED','later command uses newly revoked permission')
        finally:
            client.close()
            if activation is not None and activation.poll() is None:activation.kill();activation.wait(timeout=5)
        restore_owner_only_control(state);d.shutdown()
    case('authorization_lease_boundary',authorization_lease_boundary)


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--case',action='append',choices=CASES)
    args=parser.parse_args()
    if args.output.exists():parser.error('output already exists')
    h=Harness(args.binary,args.output);begin=time.time();code=1
    try:
        run_suite(h,set(args.case) if args.case else None);code=0
    except BaseException as exc:
        import traceback
        (h.output/'FAILURE.txt').write_text(traceback.format_exc());print(f'FAIL: {type(exc).__name__}: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup()
        summary={'format':'NATRAV_OVERLAY_LIVE_STATE_HEAD_TESTS_V1','status':'PASS' if code==0 else 'FAIL',
            'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_passed':sum(c['status']=='PASS' for c in h.cases),
            'cases_total':len(h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-begin}
        for name,obj in (('SUMMARY.json',summary),('CASES.json',h.cases),('COMMANDS.json',h.commands)):
            (h.output/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary))
    return code

if __name__=='__main__':raise SystemExit(main())
