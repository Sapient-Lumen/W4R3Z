#!/usr/bin/env python3
"""Bounded deterministic UDP relay fixture for persistent-node validation.

This module is test infrastructure only. It is intentionally not imported by
product code and does not provide a configured NATravOverlay transport.
"""
from __future__ import annotations

from dataclasses import dataclass
import errno
import hashlib
import heapq
import json
import re
import selectors
import socket
import threading
import time
from pathlib import Path
from typing import Any, Iterable


FEATURE = "DETERMINISTIC_UDP_DATAGRAM_ADVERSARY_V1"
SCHEDULE_FORMAT = "NATRAV_UDP_ADVERSARY_SCHEDULE_V1"
TRACE_FORMAT = "NATRAV_UDP_ADVERSARY_TRACE_V1"

_PATHS = ("ab", "ba")
_DIRECTIONS = ("A_TO_B", "B_TO_A")
_ACTIONS = ("PASS", "DROP", "DUPLICATE", "CORRUPT", "DELAY", "REORDER")
_SLUG = re.compile(r"[a-z][a-z0-9-]{0,31}\Z")


class AdversaryError(RuntimeError):
    """Typed fixture failure; never a product error classification."""


@dataclass(frozen=True, order=True)
class FaultRule:
    path: str
    direction: str
    ordinal: int
    action: str
    delay_ms: int = 0

    def validate(self) -> None:
        if self.path not in _PATHS:
            raise ValueError("adversary rule path must be ab or ba")
        if self.direction not in _DIRECTIONS:
            raise ValueError("adversary rule direction is invalid")
        if not 1 <= self.ordinal <= 1_000_000:
            raise ValueError("adversary rule ordinal is outside the finite bound")
        if self.action not in _ACTIONS:
            raise ValueError("adversary rule action is invalid")
        if self.action in {"DUPLICATE", "DELAY", "REORDER"}:
            if not 1 <= self.delay_ms <= 1_000:
                raise ValueError("timed adversary actions require delay_ms 1..1000")
        elif self.delay_ms != 0:
            raise ValueError("untimed adversary actions require delay_ms=0")

    def object(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "delay_ms": self.delay_ms,
            "direction": self.direction,
            "ordinal": self.ordinal,
            "path": self.path,
        }


@dataclass(frozen=True)
class FaultSchedule:
    name: str
    default_action: str
    max_datagram_bytes: int
    max_pending_events: int
    max_trace_records: int
    rules: tuple[FaultRule, ...] = ()

    def validate(self) -> None:
        if _SLUG.fullmatch(self.name) is None:
            raise ValueError("adversary schedule name is not canonical")
        if self.default_action not in {"PASS", "DROP"}:
            raise ValueError("adversary default action must be PASS or DROP")
        if not 256 <= self.max_datagram_bytes <= 65_507:
            raise ValueError("adversary datagram bound must be 256..65507")
        if not 1 <= self.max_pending_events <= 512:
            raise ValueError("adversary pending-event bound must be 1..512")
        if not 1 <= self.max_trace_records <= 65_536:
            raise ValueError("adversary trace bound must be 1..65536")
        if len(self.rules) > 256:
            raise ValueError("adversary schedule has too many rules")
        previous_key: tuple[int, int, int] | None = None
        seen: set[tuple[str, str, int]] = set()
        previous_reorder: tuple[str, str, int] | None = None
        for rule in self.rules:
            rule.validate()
            key = (_PATHS.index(rule.path), _DIRECTIONS.index(rule.direction), rule.ordinal)
            if previous_key is not None and key <= previous_key:
                raise ValueError("adversary rules must be strictly canonical-sorted")
            previous_key = key
            identity = (rule.path, rule.direction, rule.ordinal)
            if identity in seen:
                raise ValueError("adversary rule ordinal is duplicated")
            seen.add(identity)
            if (
                previous_reorder is not None
                and previous_reorder[0] == rule.path
                and previous_reorder[1] == rule.direction
                and previous_reorder[2] + 1 == rule.ordinal
                and rule.action == "REORDER"
            ):
                raise ValueError("adjacent reorder holds are not canonical")
            previous_reorder = identity if rule.action == "REORDER" else None

    def object(self) -> dict[str, Any]:
        self.validate()
        return {
            "default_action": self.default_action,
            "feature": FEATURE,
            "format": SCHEDULE_FORMAT,
            "max_datagram_bytes": self.max_datagram_bytes,
            "max_pending_events": self.max_pending_events,
            "max_trace_records": self.max_trace_records,
            "name": self.name,
            "rules": [rule.object() for rule in self.rules],
        }

    def encode(self) -> bytes:
        return _canonical_json(self.object())

    def sha256(self) -> str:
        return hashlib.sha256(self.encode()).hexdigest()

    @classmethod
    def decode(cls, encoded: bytes) -> "FaultSchedule":
        if not encoded.endswith(b"\n"):
            raise ValueError("canonical adversary schedule requires one trailing newline")
        try:
            value = json.loads(encoded)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("adversary schedule is not valid UTF-8 JSON") from exc
        if not isinstance(value, dict):
            raise ValueError("adversary schedule root must be an object")
        expected = {
            "default_action",
            "feature",
            "format",
            "max_datagram_bytes",
            "max_pending_events",
            "max_trace_records",
            "name",
            "rules",
        }
        if set(value) != expected:
            raise ValueError("adversary schedule fields are not exact")
        if value["format"] != SCHEDULE_FORMAT or value["feature"] != FEATURE:
            raise ValueError("adversary schedule format or feature is unsupported")
        if not isinstance(value["rules"], list):
            raise ValueError("adversary rules must be an array")
        rules: list[FaultRule] = []
        for raw in value["rules"]:
            if not isinstance(raw, dict) or set(raw) != {
                "action", "delay_ms", "direction", "ordinal", "path"
            }:
                raise ValueError("adversary rule fields are not exact")
            if any(isinstance(raw[key], bool) for key in ("delay_ms", "ordinal")):
                raise ValueError("adversary numeric rule fields cannot be booleans")
            rules.append(
                FaultRule(
                    path=_require_str(raw["path"], "rule path"),
                    direction=_require_str(raw["direction"], "rule direction"),
                    ordinal=_require_int(raw["ordinal"], "rule ordinal"),
                    action=_require_str(raw["action"], "rule action"),
                    delay_ms=_require_int(raw["delay_ms"], "rule delay"),
                )
            )
        schedule = cls(
            name=_require_str(value["name"], "schedule name"),
            default_action=_require_str(value["default_action"], "default action"),
            max_datagram_bytes=_require_int(
                value["max_datagram_bytes"], "maximum datagram bytes"
            ),
            max_pending_events=_require_int(
                value["max_pending_events"], "maximum pending events"
            ),
            max_trace_records=_require_int(
                value["max_trace_records"], "maximum trace records"
            ),
            rules=tuple(rules),
        )
        schedule.validate()
        if schedule.encode() != encoded:
            raise ValueError("adversary schedule is valid but noncanonical")
        return schedule


@dataclass(frozen=True)
class RelayPath:
    name: str
    left_bind: tuple[str, int]
    left_source: tuple[str, int]
    right_bind: tuple[str, int]
    right_source: tuple[str, int]
    left_to_right: str
    right_to_left: str

    def validate(self) -> None:
        if self.name not in _PATHS:
            raise ValueError("relay path must be ab or ba")
        if self.left_to_right not in _DIRECTIONS or self.right_to_left not in _DIRECTIONS:
            raise ValueError("relay path directions are invalid")
        if self.left_to_right == self.right_to_left:
            raise ValueError("relay path directions must oppose each other")
        endpoints = (self.left_bind, self.left_source, self.right_bind, self.right_source)
        if len(set(endpoints)) != len(endpoints):
            raise ValueError("relay path endpoints must be distinct")
        for host, port in endpoints:
            if host != "127.0.0.1" or not 1 <= port <= 65_535:
                raise ValueError("fixture relay accepts explicit IPv4 loopback endpoints only")


@dataclass
class _Emission:
    due: float
    sequence: int
    egress: socket.socket
    target: tuple[str, int]
    payload: bytes
    phase: str
    path: str
    direction: str
    ordinal: int
    copy: int
    scheduled_delay_ms: int


@dataclass
class _Held:
    deadline: float
    egress: socket.socket
    target: tuple[str, int]
    payload: bytes
    phase: str
    path: str
    direction: str
    ordinal: int
    delay_ms: int


class DatagramAdversary:
    """Two-path bounded UDP relay with deterministic ordinal fault injection."""

    def __init__(self, paths: Iterable[RelayPath]):
        self._paths = tuple(paths)
        if {item.name for item in self._paths} != set(_PATHS):
            raise ValueError("the persistent fixture requires exactly ab and ba relay paths")
        for item in self._paths:
            item.validate()
        all_endpoints = [
            endpoint
            for item in self._paths
            for endpoint in (item.left_bind, item.left_source, item.right_bind, item.right_source)
        ]
        if len(set(all_endpoints)) != len(all_endpoints):
            raise ValueError("all relay and node UDP endpoints must be globally distinct")

        self._selector = selectors.DefaultSelector()
        self._sockets: list[socket.socket] = []
        self._bindings: dict[int, tuple[RelayPath, bool]] = {}
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._ready = threading.Event()
        self._thread = threading.Thread(target=self._run, name="udp-adversary", daemon=True)
        self._error: BaseException | None = None
        self._schedule: FaultSchedule | None = None
        self._phase = ""
        self._rules: dict[tuple[str, str, int], FaultRule] = {}
        self._ordinals: dict[tuple[str, str], int] = {}
        self._pending: list[tuple[float, int, _Emission]] = []
        self._held: dict[tuple[str, str], _Held] = {}
        self._trace: list[dict[str, Any]] = []
        self._trace_sequence = 0
        self._emission_sequence = 0
        self._last_activity = time.monotonic()
        self._captured: dict[tuple[str, str], bytes] = {}

    def start(self) -> None:
        for path in self._paths:
            left = self._open(path.left_bind)
            right = self._open(path.right_bind)
            self._register(left, path, True)
            self._register(right, path, False)
        self._thread.start()
        if not self._ready.wait(5.0):
            raise AdversaryError("UDP adversary did not become ready")
        self.assert_healthy()

    def _open(self, endpoint: tuple[str, int]) -> socket.socket:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.setblocking(False)
            sock.bind(endpoint)
        except BaseException:
            sock.close()
            raise
        self._sockets.append(sock)
        return sock

    def _register(self, sock: socket.socket, path: RelayPath, is_left: bool) -> None:
        self._bindings[sock.fileno()] = (path, is_left)
        self._selector.register(sock, selectors.EVENT_READ)

    def install(self, schedule: FaultSchedule, *, phase: str | None = None) -> None:
        schedule.validate()
        phase_name = phase or schedule.name
        if _SLUG.fullmatch(phase_name) is None:
            raise ValueError("adversary phase name is not canonical")
        with self._lock:
            self._raise_locked()
            if self._pending or self._held:
                raise AdversaryError("cannot replace adversary schedule with pending events")
            self._schedule = schedule
            self._phase = phase_name
            self._rules = {
                (rule.path, rule.direction, rule.ordinal): rule
                for rule in schedule.rules
            }
            self._ordinals = {
                (path, direction): 0 for path in _PATHS for direction in _DIRECTIONS
            }
            self._record_locked(
                {
                    "kind": "PHASE",
                    "name": phase_name,
                    "schedule_name": schedule.name,
                    "schedule_sha256": schedule.sha256(),
                }
            )
            self._last_activity = time.monotonic()

    def schedule(self) -> FaultSchedule:
        with self._lock:
            if self._schedule is None:
                raise AdversaryError("no adversary schedule is installed")
            return self._schedule

    def assert_healthy(self) -> None:
        with self._lock:
            self._raise_locked()

    def wait_quiet(self, *, quiet_seconds: float = 0.15, timeout: float = 5.0) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self._lock:
                self._raise_locked()
                quiet = (
                    not self._pending
                    and not self._held
                    and time.monotonic() - self._last_activity >= quiet_seconds
                )
            if quiet:
                return
            time.sleep(0.01)
        raise AdversaryError("UDP adversary did not become quiet within the bound")

    def trace_records(self, phase: str | None = None) -> list[dict[str, Any]]:
        with self._lock:
            self._raise_locked()
            records = [dict(item) for item in self._trace]
        if phase is None:
            return records
        return [item for item in records if item.get("phase") == phase or item.get("name") == phase]

    def captured(self, path: str, direction: str) -> bytes:
        with self._lock:
            self._raise_locked()
            try:
                return bytes(self._captured[(path, direction)])
            except KeyError as exc:
                raise AdversaryError("no matching relay datagram has been captured") from exc

    def write_trace(self, path: Path) -> None:
        with self._lock:
            self._raise_locked()
            maximum = max(
                (self._schedule.max_trace_records if self._schedule else 0),
                len(self._trace),
            )
            value = {
                "feature": FEATURE,
                "format": TRACE_FORMAT,
                "max_trace_records": maximum,
                "records": self._trace,
            }
            encoded = _canonical_json(value)
        path.write_bytes(encoded)

    def close(self) -> None:
        self._stop.set()
        self._thread.join(timeout=5.0)
        for sock in self._sockets:
            try:
                self._selector.unregister(sock)
            except Exception:
                pass
            sock.close()
        self._selector.close()
        if self._thread.is_alive():
            raise AdversaryError("UDP adversary thread did not stop")
        self.assert_healthy()

    def _run(self) -> None:
        try:
            self._ready.set()
            while not self._stop.is_set():
                now = time.monotonic()
                self._release_due(now)
                timeout = 0.01
                with self._lock:
                    if self._pending:
                        timeout = min(timeout, max(0.0, self._pending[0][0] - now))
                    if self._held:
                        timeout = min(
                            timeout,
                            max(0.0, min(item.deadline for item in self._held.values()) - now),
                        )
                for key, _ in self._selector.select(timeout):
                    self._receive(key.fileobj)
                self._release_due(time.monotonic())
        except BaseException as exc:
            with self._lock:
                self._error = exc
            self._stop.set()
            self._ready.set()

    def _receive(self, sock: socket.socket) -> None:
        path, is_left = self._bindings[sock.fileno()]
        expected_source = path.left_source if is_left else path.right_source
        direction = path.left_to_right if is_left else path.right_to_left
        egress = self._socket_for(path, not is_left)
        target = path.right_source if is_left else path.left_source
        schedule = self.schedule()
        try:
            payload, _, flags, source = sock.recvmsg(
                schedule.max_datagram_bytes,
                0,
                socket.MSG_DONTWAIT | socket.MSG_TRUNC,
            )
        except BlockingIOError:
            return
        if flags & socket.MSG_TRUNC:
            raise AdversaryError("relay input exceeded the declared datagram bound")
        source_pair = (str(source[0]), int(source[1]))
        with self._lock:
            self._raise_locked()
            self._last_activity = time.monotonic()
            if source_pair != expected_source:
                self._record_locked(
                    {
                        "bytes": len(payload),
                        "direction": direction,
                        "input_sha256": hashlib.sha256(payload).hexdigest(),
                        "kind": "SOURCE_REJECT",
                        "path": path.name,
                        "source": f"{source_pair[0]}:{source_pair[1]}",
                    }
                )
                return
            ordinal_key = (path.name, direction)
            ordinal = self._ordinals.get(ordinal_key, 0) + 1
            self._ordinals[ordinal_key] = ordinal
            self._captured[ordinal_key] = bytes(payload)
            rule = self._rules.get((path.name, direction, ordinal))
            action = rule.action if rule is not None else schedule.default_action
            delay_ms = rule.delay_ms if rule is not None else 0
            phase = self._phase
            self._record_locked(
                {
                    "action": action,
                    "bytes": len(payload),
                    "direction": direction,
                    "input_sha256": hashlib.sha256(payload).hexdigest(),
                    "kind": "INGRESS",
                    "ordinal": ordinal,
                    "path": path.name,
                    "phase": phase,
                }
            )
            held_key = (path.name, direction)
            prior = self._held.get(held_key)
            self._apply_locked(
                action=action,
                delay_ms=delay_ms,
                egress=egress,
                target=target,
                payload=bytes(payload),
                phase=phase,
                path=path.name,
                direction=direction,
                ordinal=ordinal,
            )
            if prior is not None:
                if self._held.get(held_key) is prior:
                    del self._held[held_key]
                self._queue_locked(
                    prior.egress,
                    prior.target,
                    prior.payload,
                    due=time.monotonic() + 0.001,
                    phase=prior.phase,
                    path=prior.path,
                    direction=prior.direction,
                    ordinal=prior.ordinal,
                    copy=0,
                    scheduled_delay_ms=prior.delay_ms,
                )

    def _apply_locked(
        self,
        *,
        action: str,
        delay_ms: int,
        egress: socket.socket,
        target: tuple[str, int],
        payload: bytes,
        phase: str,
        path: str,
        direction: str,
        ordinal: int,
    ) -> None:
        now = time.monotonic()
        if action == "DROP":
            return
        if action == "PASS":
            self._queue_locked(
                egress, target, payload, due=now, phase=phase, path=path,
                direction=direction, ordinal=ordinal, copy=0, scheduled_delay_ms=0,
            )
            return
        if action == "CORRUPT":
            if not payload:
                raise AdversaryError("cannot corrupt an empty UDP datagram")
            damaged = bytearray(payload)
            damaged[-1] ^= 0x01
            self._queue_locked(
                egress, target, bytes(damaged), due=now, phase=phase, path=path,
                direction=direction, ordinal=ordinal, copy=0, scheduled_delay_ms=0,
            )
            return
        if action == "DUPLICATE":
            self._queue_locked(
                egress, target, payload, due=now, phase=phase, path=path,
                direction=direction, ordinal=ordinal, copy=0, scheduled_delay_ms=0,
            )
            self._queue_locked(
                egress, target, payload, due=now + delay_ms / 1000.0,
                phase=phase, path=path, direction=direction, ordinal=ordinal,
                copy=1, scheduled_delay_ms=delay_ms,
            )
            return
        if action == "DELAY":
            self._queue_locked(
                egress, target, payload, due=now + delay_ms / 1000.0,
                phase=phase, path=path, direction=direction, ordinal=ordinal,
                copy=0, scheduled_delay_ms=delay_ms,
            )
            return
        if action == "REORDER":
            key = (path, direction)
            if key in self._held:
                raise AdversaryError("adversary reorder hold already occupied")
            self._held[key] = _Held(
                deadline=now + delay_ms / 1000.0,
                egress=egress,
                target=target,
                payload=payload,
                phase=phase,
                path=path,
                direction=direction,
                ordinal=ordinal,
                delay_ms=delay_ms,
            )
            return
        raise AdversaryError("unknown adversary action")

    def _queue_locked(
        self,
        egress: socket.socket,
        target: tuple[str, int],
        payload: bytes,
        *,
        due: float,
        phase: str,
        path: str,
        direction: str,
        ordinal: int,
        copy: int,
        scheduled_delay_ms: int,
    ) -> None:
        schedule = self._schedule
        if schedule is None:
            raise AdversaryError("no adversary schedule is installed")
        if len(self._pending) >= schedule.max_pending_events:
            raise AdversaryError("adversary pending-event bound exhausted")
        self._emission_sequence += 1
        emission = _Emission(
            due=due,
            sequence=self._emission_sequence,
            egress=egress,
            target=target,
            payload=payload,
            phase=phase,
            path=path,
            direction=direction,
            ordinal=ordinal,
            copy=copy,
            scheduled_delay_ms=scheduled_delay_ms,
        )
        heapq.heappush(self._pending, (due, emission.sequence, emission))

    def _release_due(self, now: float) -> None:
        emissions: list[_Emission] = []
        with self._lock:
            self._raise_locked()
            expired = [key for key, item in self._held.items() if item.deadline <= now]
            for key in expired:
                item = self._held.pop(key)
                self._queue_locked(
                    item.egress,
                    item.target,
                    item.payload,
                    due=now,
                    phase=item.phase,
                    path=item.path,
                    direction=item.direction,
                    ordinal=item.ordinal,
                    copy=0,
                    scheduled_delay_ms=item.delay_ms,
                )
            while self._pending and self._pending[0][0] <= now:
                _, _, emission = heapq.heappop(self._pending)
                emissions.append(emission)
        for item in emissions:
            try:
                sent = item.egress.sendto(item.payload, item.target)
            except OSError as exc:
                if exc.errno in {errno.EINTR, errno.EAGAIN, errno.EWOULDBLOCK}:
                    with self._lock:
                        self._queue_locked(
                            item.egress,
                            item.target,
                            item.payload,
                            due=time.monotonic() + 0.001,
                            phase=item.phase,
                            path=item.path,
                            direction=item.direction,
                            ordinal=item.ordinal,
                            copy=item.copy,
                            scheduled_delay_ms=item.scheduled_delay_ms,
                        )
                    continue
                raise AdversaryError(f"UDP adversary send failed: {exc}") from exc
            if sent != len(item.payload):
                raise AdversaryError("UDP adversary observed partial datagram send")
            with self._lock:
                self._last_activity = time.monotonic()
                self._record_locked(
                    {
                        "bytes": len(item.payload),
                        "copy": item.copy,
                        "direction": item.direction,
                        "kind": "EMIT",
                        "ordinal": item.ordinal,
                        "output_sha256": hashlib.sha256(item.payload).hexdigest(),
                        "path": item.path,
                        "phase": item.phase,
                        "scheduled_delay_ms": item.scheduled_delay_ms,
                    }
                )

    def _socket_for(self, path: RelayPath, left: bool) -> socket.socket:
        for fd, (candidate, is_left) in self._bindings.items():
            if candidate.name == path.name and is_left == left:
                for sock in self._sockets:
                    if sock.fileno() == fd:
                        return sock
        raise AdversaryError("relay socket ownership is incomplete")

    def _record_locked(self, record: dict[str, Any]) -> None:
        schedule = self._schedule
        bound = schedule.max_trace_records if schedule is not None else 65_536
        if len(self._trace) >= bound:
            raise AdversaryError("adversary trace bound exhausted")
        self._trace_sequence += 1
        entry = dict(record)
        entry["sequence"] = self._trace_sequence
        self._trace.append(entry)

    def _raise_locked(self) -> None:
        if self._error is not None:
            raise AdversaryError(f"UDP adversary failed: {self._error}") from self._error


def _canonical_json(value: Any) -> bytes:
    return (
        json.dumps(value, ensure_ascii=True, separators=(",", ":"), sort_keys=True)
        + "\n"
    ).encode("utf-8")


def _require_str(value: Any, label: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{label} must be a string")
    return value


def _require_int(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{label} must be an integer")
    return value


def fault_signature(records: Iterable[dict[str, Any]], phase: str) -> list[tuple[Any, ...]]:
    """Stable schedule/result facts; deliberately excludes TLS ciphertext hashes."""
    return [
        (
            item["path"],
            item["direction"],
            item["ordinal"],
            item["action"],
            item["bytes"],
        )
        for item in records
        if item.get("kind") == "INGRESS"
        and item.get("phase") == phase
        and item.get("action") != "PASS"
    ]
