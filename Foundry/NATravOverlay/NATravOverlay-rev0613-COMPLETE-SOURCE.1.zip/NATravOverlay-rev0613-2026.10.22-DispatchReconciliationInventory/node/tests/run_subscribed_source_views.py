#!/usr/bin/env python3
"""Recipient source materialization through real configured native peers and normal replay.
No external endpoints. Pin provisioning here is an explicit recipient test-policy decision.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, shutil, socket, struct, subprocess, time
from pathlib import Path
from typing import Any
from run_persistent import Harness, free_port, operation, raw_control, receive_exact
from run_local_administration import v8_config, run_as_uid, expose_control_for_uid
from run_local_evidence import author
from run_source_subscriptions import config as provider_config, command, ack, decode_envelope
from run_scoped_reads import query
from run_evidence_queries import OWNER_CLASSES, READ_CLASSES
from run_live_configuration import candidate, activate, wait_state
from run_numeric_projection import call as numeric_call, consume, payload as numeric_payload
from run_state_authentication import new_key, migrate, start as start_keyed, inspect, checksum_frame
from run_peer_sessions import submit
from run_integration import encode_record, record_digest

SCOPE='query/series';TARGET='subscribed/temperature';UID=65534;OTHER=65533

def recipient(h:Harness,name:str,state:Path,port:int,provider_port:int,subscription:dict,
              *,records:int=128,maximum_bytes:int=1000000,delegates:bool=False)->Path:
    classes=OWNER_CLASSES+READ_CLASSES+['CONSUMER','CONSUMER_ADMIN','PROJECTION','SOURCE_IMPORT']
    grants=[(os.geteuid(),classes)]
    if delegates:grants += [(UID,['SOURCE_IMPORT']),(OTHER,['EVIDENCE_READ'])]
    cfg=v8_config(h,name,'C',state,port,name+'-g1',grants,[('A',provider_port)],['B'],deadline_ms=3000)
    lines=cfg.read_text().replace('CONFIG_V8','CONFIG_V17').splitlines();out=[]
    for line in lines:
        if line.startswith('peer='):
            f=line[5:].split(',');out+=['peer='+','.join([f[0]]+f[2:]),f'peer_route={f[0]},primary,0,ENABLED,{f[1]}']
        else:out.append(line)
    out += [f'authorize=A,*,EVIDENCE,{SCOPE}',f'authorize=B,*,EVIDENCE,{SCOPE}',
            f'authorize=A,*,EVIDENCE,{TARGET}',
            f'evidence_read={os.geteuid()},A,{SCOPE},PAYLOAD',f'evidence_read={os.geteuid()},A,{TARGET},PAYLOAD',
            f'evidence_read={os.geteuid()},B,{SCOPE},PAYLOAD',
            f'source_view=temps,{os.geteuid()},A,a-g1,{os.geteuid()},{SCOPE},{TARGET},{records},{maximum_bytes}',
            f'source_view_binding=temps,g1,{subscription["instance"]},{subscription["grant_digest"]},-']
    if delegates:
        out += [f'source_view=delegated,{UID},A,a-g1,{os.geteuid()},{SCOPE},subscribed/delegated,128,1000000',
                f'source_view_binding=delegated,g1,{subscription["instance"]},{subscription["grant_digest"]},-',
                f'evidence_read={OTHER},A,{TARGET},METADATA']
    cfg.write_text('\n'.join(out)+'\n');cfg.chmod(0o600);return cfg

def setup(h:Harness,name:str,**kw:Any)->tuple:
    a=h.runtime/(name+'-a');c=h.runtime/(name+'-c');ap=free_port();cp=free_port()
    while cp==ap:cp=free_port()
    ac=provider_config(h,name+'-a',a,ports={'C':cp},rules=[f'g1,{os.geteuid()},{os.geteuid()},C,c-g1,{SCOPE},128,1000000'])
    ad=h.start(name+'-a',ac,a)
    subscription=command(h,name+'-subscription',a,'create')
    cc=recipient(h,name+'-c',c,cp,ap,subscription,**kw)
    cd=h.start(name+'-c',cc,c)
    return a,c,ac,cc,ad,cd,subscription

def emit(h:Harness,label:str,a:Path,c:Path,subscription:dict,**kw:Any)->tuple[dict,dict,dict]:
    src=author(h,label+'-source',a,**kw)
    issued=command(h,label+'-issue',a,'step',previous=subscription)
    after=ack(h,label+'-ack',a,issued)
    q=query(h,label+'-outer',c,issuer='A',scope=SCOPE,operation=issued['latest']['operation_id'],view='history',payload='yes',payload_length=16384)
    h.check(len(q['records'])==1,'exact outer admission stored once')
    row=q['records'][0];h.check(row.get('authorization') is not None and 'local_authorship' not in row,'outer remains authenticated peer evidence')
    return src,after,row

def import_args(c:Path,op:str,view:str='temps')->list[str]:
    return ['source-view-import','--control',str(c/'control.sock'),'--view',view,'--operation',op,'--deadline-ms','5000']

def materialize(h:Harness,label:str,c:Path,row:dict|str,*,view:str='temps',expected:int=0,uid:int|None=None)->dict:
    op=row if isinstance(row,str) else row['operation_id'];args=import_args(c,op,view)
    result=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    assert result is not None
    if expected==0:
        h.check(result['format']=='NATRAV_OVERLAY_SOURCE_IMPORT_RESULT_V1' and result['network_used'] is False,'explicit native import, no self-connect')
        h.check(result['subscribed_source']['import_uid']==(os.geteuid() if uid is None else uid),'actual importing kernel UID')
    return result

def fields(q:dict)->list[dict]:
    return q['records']

def run_cases(h:Harness,selected:set[str]|None)->None:
    def case(name,fn):
        if selected is None or name in selected:h.case(name,fn)

    def policies():
        a,c,ac,cc,ad,cd,s=setup(h,'policy')
        good=h.run('view-config',['config-check','--config',str(cc)])
        lines=cc.read_text().splitlines();reordered=h.work/'reordered.conf';reordered.write_text(lines[0]+'\n'+'\n'.join(reversed(lines[1:]))+'\n');reordered.chmod(0o600)
        canonical=h.run('view-reordered',['config-check','--config',str(reordered)])
        h.check(good['runtime_digest']==canonical['runtime_digest'],'canonical policy independent of rule ordering')
        p=good['source_view_policy'];rr=p['views'][0]
        h.check(rr['digest']==hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_VIEW_RULE_V1\0'+rr['rule'].encode()).hexdigest(),'independent immutable rule digest')
        bb=p['bindings'][0]
        h.check(bb['digest']==hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_VIEW_BINDING_V1\0'+bb['binding'].encode()).hexdigest(),'independent exact binding digest')
        variants=[
            ('older',lambda t:t.replace('CONFIG_V17','CONFIG_V16'),'CONFIG_VERSION_REJECTED'),
            ('no-class',lambda t:t.replace(',SOURCE_IMPORT',''),'CONFIG_SOURCE_VIEW_CLASS_REQUIRED'),
            ('no-binding',lambda t:'\n'.join(l for l in t.splitlines() if not l.startswith('source_view_binding='))+'\n','CONFIG_SOURCE_VIEW_BINDING_REQUIRED'),
            ('duplicate',lambda t:t+next(l for l in t.splitlines() if l.startswith('source_view='))+'\n','CONFIG_SOURCE_VIEW_DUPLICATE'),
            ('same-scope',lambda t:t.replace(','+TARGET+',128,',','+SCOPE+',128,'),'CONFIG_SOURCE_VIEW_INVALID'),
            ('wildcard',lambda t:t.replace('A,a-g1,0,'+SCOPE,'A,a-g1,0,query/*'),'CONFIG_SOURCE_VIEW_INVALID'),
            ('unknown-key',lambda t:t.replace('A,a-g1,0,','A,unknown-g1,0,'),'CONFIG_SOURCE_VIEW_KEY_REQUIRED'),
        ]
        for name,change,code in variants:
            cfg=candidate(h,cc,'bad-'+name,'bad-'+name+'-g1',change)
            h.check(h.run('policy-'+name,['config-check','--config',str(cfg)],expected=3)['code']==code,'strict '+name)
        first,s,row=emit(h,'policy-source',a,c,s,ticks=100)
        raw=b'NOC1\x15NVI1'+struct.pack('!H',5)+b'temps'+bytes.fromhex(row['operation_id'])
        ok,res=raw_control(c/'control.sock',raw);h.check(ok and res['subscribed_source']['import_pid']==os.getpid(),'independent wire uses actual socket PID')
        for name,wire in [('trailing',raw+b'x'),('partial',raw[:-1]),('version',raw.replace(b'NVI1',b'NVI2'))]:
            ok,error=raw_control(c/'control.sock',wire);h.check(not ok and 'subscribed_source' not in error,'strict request '+name)
        # Raw peer authorization is deliberately present for the target; importer domain reservation takes priority.
        forged=operation('target-injection')
        h.run('target-injection',['submit','--control',str(a/'control.sock'),'--node','A','--peer','C','--scope',TARGET,
            '--operation',forged,'--payload-text','not imported'])
        h.wait('reserved target rejects raw admission',lambda:any(e.get('last_error_code')=='SOURCE_VIEW_DOMAIN_RESERVED' for e in h.status('reserved-state',a)['outbox']['entries']))
        q=query(h,'reserved-query',c,issuer='A',scope=TARGET,view='history');h.check(len(fields(q))==1,'reserved scope contains only materialized evidence')
        # Removing a rule does not release its protected target domain or let the ID change budget.
        changed=candidate(h,cc,'changed-budget','changed-budget-g1',lambda t:t.replace(','+TARGET+',128,1000000',','+TARGET+',129,1000000'))
        response=h.run('immutable-view',['config-activate','--control',str(c/'control.sock'),'--candidate',str(changed),'--reason','invalid reinterpretation'],expected=3)
        h.check(response['code']=='SOURCE_VIEW_POLICY_CONFLICT','view IDs cannot replenish budgets or change semantics')
        cd.shutdown();ad.shutdown()
    case('strict_policy_independent_wire_and_reserved_domain',policies)

    def numeric():
        a,c,ac,cc,ad,cd,s=setup(h,'numeric')
        one,s,r1=emit(h,'one',a,c,s,ticks=100)
        two,s,r2=emit(h,'two',a,c,s,ticks=25)
        corrected,s,r3=emit(h,'corrected',a,c,s,ticks=150,parent=one['operation_id'])
        h.check(materialize(h,'parent-before-import',c,r3,expected=3)['code']=='SOURCE_VIEW_PARENT_REQUIRED','correction cannot invent mapped parent')
        results=[materialize(h,'import-one',c,r1),materialize(h,'import-two',c,r2),materialize(h,'import-correction',c,r3)]
        b=(c/'state.journal').read_bytes();again=materialize(h,'exact-retry',c,r1)
        h.check(again['disposition']=='ALREADY_IMPORTED' and (c/'state.journal').read_bytes()==b,'exact retry is journal-observational')
        rows=fields(query(h,'materialized-history',c,issuer='A',scope=TARGET,view='history',payload='yes',payload_length=46))
        h.check(len(rows)==3,'three imported originals/correction')
        rule=h.run('numeric-rule',['config-check','--config',str(cc)])['source_view_policy']['views'][0]['digest']
        for row,src,outer,ticks in zip(rows,[one,two,corrected],[r1,r2,r3],[100,25,150]):
            h.check(row['operation_id']==hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_VIEW_OPERATION_V1\0'+bytes.fromhex(rule)+bytes.fromhex(src['operation_id'])).hexdigest(),'independent materialized operation identity')
            h.check('local_authorship' not in row and row['authorization'] is None and row['subscribed_source']['origin']=='SUBSCRIBED_SOURCE','two provenance layers, no invented local author or peer receipt')
            h.check(row['subscribed_source']['source_operation']==src['operation_id'] and row['subscribed_source']['outer_operation']==outer['operation_id'],'source and delivery operation remain distinct')
            h.check(bytes.fromhex(row['payload_hex'])==numeric_payload(ticks),'unwrapped source is exact numeric bytes')
        current=fields(query(h,'plural-current',c,issuer='A',scope=TARGET))
        h.check({r['operation_id'] for r in current}=={results[1]['operation_id'],results[2]['operation_id']},'independent heads retained; own mapped predecessor corrected')
        numeric_call(h,'create-numeric',c,'create','subscribed',definition='NUMERIC_SUMMARY_V1',issuer='A',scope=TARGET,
            unit='degC',scale=2,limit=2,reason='explicit imported data computation')
        values={r['operation_id']:numeric_payload(t) for r,t in zip(results,[100,25,150])}
        final,consumed=consume(h,'compute-subscribed',c,values,name='subscribed')
        h.check(final['consumer']['projection']['result']['numeric']['sum_ticks']=='175','recipient native projection computes corrected source sum')
        h.check(all('subscribed_source' in r for r in consumed),'consumer/feed rows preserve import provenance')
        h.run('compact-materialized',['compact','--control',str(c/'control.sock')]);cd.shutdown();cd=h.start('replay-materialized',cc,c)
        after=fields(query(h,'restored-view-rows',c,issuer='A',scope=TARGET,view='history',payload='yes',payload_length=46))
        h.check(after==rows,'checkpoint rebuild preserves result rows and provenance')
        materialize(h,'post-restart-retry',c,r1)
        cd.shutdown();snap=h.run('offline-materialized',['inspect','--state',str(c),'--node','C'])
        h.check(sum('subscribed_source' in r for r in snap['inbound']['history'])==3,'offline view accounts retained')
        ad.shutdown()
        (h.output/'NUMERIC-RESULT.json').write_text(json.dumps({'source_ticks':[100,25,150],'materialized_rows':rows,'sum_ticks':'175','projection':final['consumer']['projection']['result']},indent=2)+'\n')
    case('native_projection_corrections_duplicates_and_checkpoint',numeric)

    def principals():
        a,c,ac,cc,ad,cd,s=setup(h,'principals',delegates=True)
        one,s,row=emit(h,'principals-one',a,c,s,ticks=5)
        expose_control_for_uid(c)
        denied=materialize(h,'foreign-manager',c,row,expected=3,uid=UID)
        h.check(denied['code']=='SOURCE_VIEW_POLICY_DENIED','name not authority for another manager')
        materialize(h,'own-manager',c,row,uid=UID,view='delegated')
        h.check(query(h,'import-does-not-read',c,3,uid=UID,issuer='A',scope='subscribed/delegated')['code']=='LOCAL_CONTROL_CLASS_DENIED','import class is not read class')
        materialize(h,'owner-view',c,row)
        visible=query(h,'metadata-delegate',c,uid=OTHER,issuer='A',scope=TARGET,view='history')
        h.check(len(fields(visible))==1,'explicit metadata authority reads only authorized target')
        h.check(query(h,'payload-denied',c,3,uid=OTHER,issuer='A',scope=TARGET,payload='yes')['code']=='LOCAL_CONTROL_CLASS_DENIED','metadata not payload')
        h.check(fields(query(h,'hidden-outer',c,uid=OTHER,issuer='A',scope=SCOPE,view='history'))==[],'view reader need not see original envelope domain')
        # Revoke IMPORT during a half-transmitted request. No stale connected grant.
        two,s,row2=emit(h,'principals-two',a,c,s,ticks=10)
        raw=b'NOC1\x15NVI1'+struct.pack('!H',5)+b'temps'+bytes.fromhex(row2['operation_id'])
        remove=lambda t:'\n'.join(l.replace(',SOURCE_IMPORT','') if l.startswith(f'local_control={os.geteuid()},') else l for l in t.splitlines() if not l.startswith('source_view=temps,') and not l.startswith('source_view_binding=temps,'))+'\n'
        revoked=candidate(h,cc,'import-revoked','import-revoked-g1',remove)
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as sock:
            sock.settimeout(8);sock.connect(str(c/'control.sock'));sock.sendall(struct.pack('!I',len(raw))+raw[:5])
            activate(h,'revoke-import',c,revoked);sock.sendall(raw[5:]);size=struct.unpack('!I',receive_exact(sock,4))[0];reply=receive_exact(sock,size)
            h.check(reply[:5]==b'NOR1\1' and json.loads(reply[5:])['code']=='LOCAL_CONTROL_CLASS_DENIED','new accepted policy governs completed request')
        h.check(len(fields(query(h,'existing-still-queryable',c,issuer='A',scope=TARGET,view='history')))==1,'revocation stops new imports, does not erase existing view')
        cd.shutdown();ad.shutdown()
    case('kernel_principals_hidden_domains_and_live_revocation',principals)

    def quotas():
        a,c,ac,cc,ad,cd,s=setup(h,'quotas',records=2,maximum_bytes=3)
        one,s,r1=emit(h,'byte-one',a,c,s,value='ab');two,s,r2=emit(h,'byte-two',a,c,s,value='cd')
        three,s,r3=emit(h,'byte-three',a,c,s,value='x');four,s,r4=emit(h,'byte-four',a,c,s,value='')
        materialize(h,'quota-first',c,r1)
        h.check(materialize(h,'byte-limit',c,r2,expected=3)['code']=='SOURCE_VIEW_BYTE_LIMIT','exact raw byte budget enforced before mutation')
        materialize(h,'quota-boundary',c,r3)
        h.check(materialize(h,'record-limit',c,r4,expected=3)['code']=='SOURCE_VIEW_RECORD_LIMIT','retained record quota not released by history')
        cd.shutdown();cd=h.start('quota-restart',cc,c)
        h.check(materialize(h,'restart-record-limit',c,r4,expected=3)['code']=='SOURCE_VIEW_RECORD_LIMIT','quota reconstructed not reset')
        h.run('quota-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown();cd=h.start('quota-checkpoint',cc,c)
        h.check(materialize(h,'checkpoint-byte-limit',c,r2,expected=3)['code']=='SOURCE_VIEW_RECORD_LIMIT','checkpoint preserves spent retention quota')
        cd.shutdown();ad.shutdown()
    case('finite_retention_budgets_survive_restart',quotas)


    def invalid_envelopes():
        a,c,ac,cc,ad,cd,subscription=setup(h,'invalid')
        src,subscription,row=emit(h,'valid-envelope',a,c,subscription,ticks=77)
        good=decode_envelope(bytes.fromhex(row['payload_hex']))
        def text(v:str)->bytes:
            b=v.encode();return struct.pack('!H',len(b))+b
        def encode(x:dict,source:bytes|None=None)->bytes:
            raw=source or encode_record(x['source_operation'],x['issuer'],x['source_recipient'],x['scope'],bytes.fromhex(x['payload_hex']),x['source_corrects'])
            return b'NSE1'+text(x['grant'])+bytes.fromhex(x['instance'])+bytes.fromhex(x['grant_digest'])+text(x['recipient'])+text(x['generation'])+bytes.fromhex(x['spki'])+struct.pack('!QIQ',x['ordinal'],x['author_uid'],x['authored_unix_ms'])+record_digest(raw)+bytes([x['mapped_corrects'] is not None])+(bytes.fromhex(x['mapped_corrects']) if x['mapped_corrects'] else b'')+struct.pack('!I',len(raw))+raw
        h.check(encode(good)==bytes.fromhex(row['payload_hex']),'independent NSE1 serialization')
        changes=[('unknown-grant',{'grant':'not-accepted'}),('wrong-instance',{'instance':operation('not-instance')}),
                 ('wrong-grant-digest',{'grant_digest':operation('not-rule')}),('wrong-author',{'author_uid':12345}),
                 ('wrong-recipient',{'recipient':'B'}),('wrong-local-key',{'spki':operation('not-recipient-key')}),
                 ('wrong-source-scope',{'scope':'query/other'}),('wrong-source-node',{'issuer':'B','source_recipient':'B'})]
        for label,change in changes:
            x=dict(good);x.update(change);raw=encode(x);op=hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_DELIVERY_V1\0'+raw).hexdigest()
            f=h.runtime/(label+'.bin');f.write_bytes(raw)
            h.run('deliver-'+label,['submit','--control',str(a/'control.sock'),'--node','A','--peer','C','--scope',SCOPE,'--operation',op,'--payload-file',str(f)])
            wait_state(h,a,op,'ACKED',label+'-outer-ack')
            rejected=materialize(h,'reject-'+label,c,op,expected=3)
            h.check(rejected['code'].startswith('SOURCE_VIEW_'),'inconsistent envelope kept as ordinary evidence but not imported: '+label)
        for label,raw in [('trailing',bytes.fromhex(row['payload_hex'])+b'x'),('wrong-magic',b'NOT1'+bytes.fromhex(row['payload_hex'])[4:]),('truncated',b'NSE1\0')]:
            op=hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_DELIVERY_V1\0'+raw).hexdigest();f=h.runtime/(label+'.bin');f.write_bytes(raw)
            h.run('deliver-'+label,['submit','--control',str(a/'control.sock'),'--node','A','--peer','C','--scope',SCOPE,'--operation',op,'--payload-file',str(f)])
            wait_state(h,a,op,'ACKED',label+'-ack');materialize(h,'reject-'+label,c,op,expected=3)
        # A second real TLS identity cannot reuse A's otherwise valid envelope policy.
        bp=free_port();cp=int(next(l for l in cc.read_text().splitlines() if l.startswith('listen=')).rsplit(':',1)[1])
        b=h.runtime/'invalid-b';bc=v8_config(h,'invalid-b','B',b,bp,'invalid-b-g1',[(os.geteuid(),['ALL'])],[('C',cp)],deadline_ms=3000);bd=h.start('invalid-b',bc,b)
        x=dict(good);x['source_operation']=operation('wrong-provider-source');raw=encode(x);op=hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_DELIVERY_V1\0'+raw).hexdigest();f=h.runtime/'wrong-provider.bin';f.write_bytes(raw)
        h.run('wrong-provider-delivery',['submit','--control',str(b/'control.sock'),'--node','B','--peer','C','--scope',SCOPE,'--operation',op,'--payload-file',str(f)])
        wait_state(h,b,op,'ACKED','wrong-provider-ack')
        h.check(materialize(h,'wrong-provider-import',c,op,expected=3)['code']=='SOURCE_VIEW_OUTER_REJECTED','actual authenticated outer provider is mandatory')
        h.check(fields(query(h,'no-invalid-materialization',c,issuer='A',scope=TARGET,view='history'))==[],'no invalid record entered materialized view')
        materialize(h,'valid-after-denials',c,row)
        h.check(len(fields(query(h,'originals-remain-stored',c,issuer='A',scope=SCOPE,view='history')))==12,'denials do not delete stored outer evidence')
        cd.shutdown();bd.shutdown()
        # Independently encoded legacy/unmarked evidence is valid stored state,
        # but it cannot supply a TLS admission proof for source materialization.
        snapshot=h.run('legacy-source-snapshot',['inspect','--state',str(c),'--node','C'])
        event=len(snapshot['runtime_configuration']['events'])
        x=dict(good);x['source_operation']=operation('unmarked-source');raw=encode(x)
        op=hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_DELIVERY_V1\0'+raw).hexdigest()
        encoded=encode_record(op,'A','C',SCOPE,raw)
        body=bytes([23])+struct.pack('!Q',event)+bytes([1])+encoded
        frame=b'NOJ1'+struct.pack('!I',len(body))+body+hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest()
        with (c/'state.journal').open('ab') as f:f.write(frame)
        cd=h.start('unmarked-compatibility-state',cc,c)
        h.check(materialize(h,'unmarked-source-denied',c,op,expected=3)['code']=='SOURCE_VIEW_OUTER_REJECTED',
            'valid structural source and local issuer claim do not establish authenticated peer admission')
        cd.shutdown();ad.shutdown()
    case('independent_envelopes_wrong_bindings_and_real_wrong_provider',invalid_envelopes)

    def kills_and_races():
        for boundary in ('BEFORE','AFTER'):
            a,c,ac,cc,ad,cd,sub=setup(h,'kill-'+boundary.lower())
            src,sub,row=emit(h,'kill-'+boundary.lower(),a,c,sub,ticks=23);cd.shutdown()
            cd=h.start('stopped-'+boundary,cc,c,{'NATRAV_OVERLAY_TEST_SOURCE_IMPORT_'+boundary+'_COMMIT_MS':'1500'})
            baseline=(c/'state.journal').stat().st_size
            log=h.output/('kill-'+boundary+'.txt')
            with log.open('w') as f:
                p=subprocess.Popen([str(h.binary),*import_args(c,row['operation_id'])],stdout=f,stderr=f)
                if boundary=='AFTER':h.wait('synchronized import exists',lambda:(c/'state.journal').stat().st_size>baseline,5)
                else:time.sleep(.25)
                cd.kill();p.wait(timeout=8)
            state=h.run('kill-offline-'+boundary,['inspect','--state',str(c),'--node','C'])
            count=sum('subscribed_source' in x for x in state['inbound']['history'])
            h.check(count==(1 if boundary=='AFTER' else 0),'source and import account share one kill boundary')
            cd=h.start('recovered-'+boundary,cc,c)
            r=materialize(h,'retry-killed-'+boundary,c,row)
            h.check(r['disposition']==('ALREADY_IMPORTED' if boundary=='AFTER' else 'IMPORTED'),'safe lost-response retry')
            cd.shutdown();ad.shutdown()
        a,c,ac,cc,ad,cd,sub=setup(h,'races');src,sub,row=emit(h,'race-source',a,c,sub,ticks=3)
        def client(i:int)->dict:
            p=subprocess.run([str(h.binary),*import_args(c,row['operation_id'])],capture_output=True,text=True,timeout=10)
            assert p.returncode==0,(p.stdout,p.stderr)
            return json.loads(p.stdout)
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:out=list(pool.map(client,range(8)))
        h.check(sum(x['disposition']=='IMPORTED' for x in out)==1 and sum(x['disposition']=='ALREADY_IMPORTED' for x in out)==7,'one concurrent import commit; seven idempotent observers')
        h.check(len(fields(query(h,'races-final',c,issuer='A',scope=TARGET,view='history')))==1,'no duplicate admissions from races')
        (h.output/'CONCURRENT-IMPORTS.json').write_text(json.dumps(out,indent=2)+'\n');cd.shutdown();ad.shutdown()
    case('real_commit_kills_and_concurrent_idempotency',kills_and_races)

    def semantic_replay():
        a,c,ac,cc,ad,cd,sub=setup(h,'semantic');one,sub,r1=emit(h,'semantic-original',a,c,sub,ticks=77)
        imported=materialize(h,'semantic-import',c,r1);cd.shutdown()
        original=(c/'state.journal').read_bytes();frames=[];at=0
        while at<len(original):
            n=struct.unpack('!I',original[at+4:at+8])[0];frames.append(original[at:at+40+n]);at+=40+n
        indices=[i for i,f in enumerate(frames) if f[8]==33];h.check(len(indices)==1,'dedicated subscribed-source journal kind')
        i=indices[0];frame=frames[i]
        for label,needle in [('import-rule',bytes.fromhex(imported['subscribed_source']['view_digest'])),
                             ('source-digest',bytes.fromhex(imported['subscribed_source']['source_record_digest'])),
                             ('outer-digest',bytes.fromhex(imported['subscribed_source']['outer_record_digest']))]:
            at=frame.find(needle);h.check(at>=9,'commitment present in actual journal')
            changed=bytearray(frame);changed[at]^=1;bad=list(frames);bad[i]=checksum_frame(bytes(changed));(c/'state.journal').write_bytes(b''.join(bad))
            rejected=h.run('forged-'+label,['inspect','--state',str(c),'--node','C'],expected=3)
            h.check(rejected['code']=='JOURNAL_CORRUPT','ordinary checksum cannot justify '+label)
        # Recompute the record digest/checksum after forging the projected source bytes.
        changed=bytearray(frame);changed[-33]^=1;bad=list(frames);bad[i]=checksum_frame(bytes(changed));(c/'state.journal').write_bytes(b''.join(bad))
        h.check(h.run('forged-materialized-payload',['inspect','--state',str(c),'--node','C'],expected=3)['code']=='JOURNAL_CORRUPT','replay recomputes payload from original authenticated envelope')
        # Removing the original authenticated admission leaves no authority for import.
        without=[f for f in frames if not (f[8]==23 and f[17]==11 and bytes.fromhex(r1['operation_id']) in f)]
        h.check(len(without)==len(frames)-1,'removed exact underlying peer admission')
        (c/'state.journal').write_bytes(b''.join(without));h.run('missing-outer',['inspect','--state',str(c),'--node','C'],expected=3)
        (c/'state.journal').write_bytes(original);cd=h.start('semantic-valid',cc,c);h.run('semantic-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown()
        compact=(c/'state.journal').read_bytes();pos=compact.find(b'NSV1');h.check(pos>0,'checkpoint retains import marker')
        # Alter import metadata while keeping the envelope, application bytes,
        # canonical logical hash, and ordinary frame checksum consistent.
        n=struct.unpack('!I',compact[4:8])[0];body=bytearray(compact[8:8+n]);marker=body.find(b'NSV1')
        pos=body.find(bytes.fromhex(imported['subscribed_source']['source_record_digest']),marker)
        h.check(pos>=marker,'checkpoint source commitment retained in provenance')
        body[pos]^=1;logical=body.find(b'NLS2');h.check(logical>48,'canonical logical checkpoint image')
        body[logical-48:logical-16]=hashlib.sha256(b'NATRAV_OVERLAY_LOGICAL_STATE_V2\0'+body[logical:]).digest()
        bad=checksum_frame(compact[:8]+bytes(body)+compact[8+n:])
        (c/'state.journal').write_bytes(bad)
        h.check(h.run('forged-checkpoint-provenance',['inspect','--state',str(c),'--node','C'],expected=3)['code']=='JOURNAL_CORRUPT',
            'recomputed logical digest and checksum cannot justify forged imported provenance')
        (c/'state.journal').write_bytes(compact)
        h.run('valid-compacted-source',['inspect','--state',str(c),'--node','C']);ad.shutdown()
    case('source_derived_replay_rejects_semantic_forgery',semantic_replay)

    def maintenance():
        a,c,ac,cc,ad,cd,sub=setup(h,'maintenance');src,sub,row=emit(h,'maintenance-original',a,c,sub,ticks=125)
        first=materialize(h,'maintenance-import',c,row);cd.shutdown()
        key=new_key(h,h.work,'view-state-g1');migrate(h,'view-keyed-migration',c,key,node='C');cd=start_keyed(h,'view-keyed',cc,c,key)
        amended,sub,row2=emit(h,'maintenance-correction',a,c,sub,ticks=-75,parent=src['operation_id'])
        second=materialize(h,'keyed-new-import',c,row2);cd.shutdown()
        h.run('view-auth-audit',['state-auth-audit','--state',str(c),'--node','C','--state-auth-key',str(key)])
        cd=start_keyed(h,'view-compact',cc,c,key);h.run('view-keyed-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown()
        snapshot=inspect(h,'view-before-backup',c,key,node='C')
        crypt=h.work/'view-backup.key';h.run('view-backup-key',['backup-key-init','--output',str(crypt),'--generation','view-backup-g1'])
        identity=h.identity('C');archive=h.work/'view.nob'
        h.run('view-backup-export',['backup-export','--state',str(c),'--node','C','--generation','c-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'restored-view'
        h.run('view-backup-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','C','--generation','c-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'restored-view-offline',restored,key,node='C')
        h.check(snapshot['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'signed encrypted restore preserves logical state including both provenance layers')
        moved=candidate(h,cc,'view-relocated','view-relocated-g1',lambda t:t.replace('state='+str(c),'state='+str(restored)))
        h.run('relocate-view',['state-relocate','--state',str(restored),'--node','C','--candidate',str(moved),'--reason','move owned imported view','--state-auth-key',str(key)])
        cd=start_keyed(h,'view-restored-daemon',moved,restored,key)
        again=materialize(h,'restored-idempotent-import',restored,row2)
        h.check(again['disposition']=='ALREADY_IMPORTED' and again['subscribed_source']==second['subscribed_source'],'old import keeps historical account across relocation')
        newest,sub,row3=emit(h,'post-restore-correction',a,restored,sub,ticks=200,parent=amended['operation_id'])
        third=materialize(h,'new-restored-import',restored,row3)
        h.check(third['subscribed_source']['configuration_event']>second['subscribed_source']['configuration_event'],'new import bound to relocated generation')
        rows=fields(query(h,'restored-current',restored,issuer='A',scope=TARGET,payload='yes',payload_length=46))
        h.check(len(rows)==1 and bytes.fromhex(rows[0]['payload_hex'])==numeric_payload(200),'continued native corrected view after authenticated restore')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'before_logical_digest':snapshot['storage']['logical_state_digest'],'restored_logical_digest':after['storage']['logical_state_digest'],'latest_import':third,'current_records':rows},indent=2)+'\n')
        cd.shutdown();ad.shutdown()
    case('authenticated_audit_encrypted_restore_relocation_continuation',maintenance)

    def succession():
        from run_lease_succession import setup as lease_setup, add_grant, withdraw, succeed, received
        from run_subscription_leases import local
        a,c,ac,cc,ad,cd,remote=lease_setup(h,'succession')
        old=local(h,'succession-full-state',a,'status')
        # Explicit recipient upgrade pins the already admitted lease instance and digest.
        def upgrade(t:str)->str:
            out=[]
            for line in t.splitlines():
                if line.startswith('NATRAV_OVERLAY_CONFIG_'):out.append('NATRAV_OVERLAY_CONFIG_V17')
                elif line.startswith('local_control='):
                    if line.startswith(f'local_control={os.geteuid()},'):
                        line+=',SOURCE_IMPORT'
                    out.append(line)
                elif line.startswith('peer=') and len(line[5:].split(','))==6:
                    f=line[5:].split(',');out += ['peer='+','.join([f[0]]+f[2:]),f'peer_route={f[0]},primary,0,ENABLED,{f[1]}']
                else:out.append(line)
            out += [f'evidence_read={os.geteuid()},A,{TARGET},PAYLOAD',
                    f'source_view=temps,{os.geteuid()},A,a-g1,{os.geteuid()},{SCOPE},{TARGET},128,1000000',
                    f'source_view_binding=temps,g1,{old["instance"]},{old["grant_digest"]},-']
            return '\n'.join(out)+'\n'
        viewcfg=candidate(h,cc,'leased-view','leased-view-g1',upgrade);activate(h,'adopt-leased-view',c,viewcfg)
        one=author(h,'leased-original',a,ticks=100);issued=local(h,'leased-issue',a,'step',previous=old);old=received(h,'leased-receipt',a,issued)
        q=fields(query(h,'leased-envelope',c,issuer='A',scope=SCOPE,operation=issued['latest']['operation_id'],view='history',payload='yes',payload_length=16384))[0]
        first=materialize(h,'leased-import',c,q)
        terminal=withdraw(h,'withdraw-for-view',a,cc,old);newcfg=add_grant(h,ac,a,'second-grant');successor=succeed(h,'view-successor',a,terminal)
        correction=author(h,'successor-correction',a,ticks=150,parent=one['operation_id']);next_issue=local(h,'successor-issue',a,'step',grant='g2',previous=successor);received(h,'successor-receipt',a,next_issue)
        q2=fields(query(h,'successor-envelope',c,issuer='A',scope=SCOPE,operation=next_issue['latest']['operation_id'],view='history',payload='yes',payload_length=16384))[0]
        h.check(materialize(h,'unaccepted-successor',c,q2,expected=3)['code']=='SOURCE_VIEW_SUBSCRIPTION_DENIED','new lease not silently authorized')
        raw=bytes.fromhex(q2['payload_hex']);path=h.work/'successor.nse';path.write_bytes(raw)
        decoded=h.run('inspect-lineage-pin',['source-envelope-inspect','--payload-file',str(path)])
        from run_source_subscriptions import Reader
        reader=Reader(raw);assert reader.get(4)==b'NSE2';reader.text();reader.get(64);reader.text();reader.text();reader.get(32);reader.get(8+4+8+32)
        if reader.number(1):reader.get(32)
        reader.get(reader.number(4));suffix=raw[reader.i:]
        expected=hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_VIEW_LINEAGE_V1\0'+suffix).hexdigest()
        h.check(decoded['lineage_digest']==expected,'independent exact succession suffix commitment')
        wrong=candidate(h,viewcfg,'wrong-lineage','wrong-lineage-g1',lambda t:t+f'source_view_binding=temps,g2,{successor["instance"]},{successor["grant_digest"]},{operation("wrong-lineage")}\n')
        # A bad policy pin is well-formed but cannot justify this source. Do not accept it historically: use a fresh third test view would be needed to revise a pin.
        h.run('wellformed-wrong-lineage',['config-check','--config',str(wrong)])
        nextview=candidate(h,viewcfg,'accept-successor','accept-successor-g1',lambda t:t+f'source_view_binding=temps,g2,{successor["instance"]},{successor["grant_digest"]},{expected}\n')
        activate(h,'accept-exact-successor-binding',c,nextview)
        second=materialize(h,'import-successor-correction',c,q2)
        rows=fields(query(h,'succession-current-view',c,issuer='A',scope=TARGET,payload='yes',payload_length=46))
        h.check(len(rows)==1 and rows[0]['corrects']==first['operation_id'] and bytes.fromhex(rows[0]['payload_hex'])==numeric_payload(150),'NSE2 correction maps to acknowledged imported predecessor without relabeling source')
        h.run('succession-view-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown();cd=h.start('succession-view-restart',nextview,c)
        h.check(materialize(h,'succession-retry',c,q2)['operation_id']==second['operation_id'],'succession import reconstructs')
        cd.shutdown();ad.shutdown()
        (h.output/'SUCCESSION.json').write_text(json.dumps({'lineage_digest':expected,'first':first,'second':second,'current':rows},indent=2)+'\n')
    case('explicit_NSE2_succession_pin_and_mapped_correction',succession)


def main()->int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    try:run_cases(h,set(a.case) if a.case else None);ok=True
    except BaseException as exc:
        (h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(f'FAIL: {type(exc).__name__}: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_SUBSCRIBED_SOURCE_VIEW_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(x['status']=='PASS' for x in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,value in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]: (h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
