#!/usr/bin/env python3
"""Revision 0565: actual predecessor readers and the live-command boundary."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import time
from run_persistent import Harness
from run_state_authentication import inspect, new_key
from run_authenticated_recovery import setup, incomplete_next, audit, recover_args
from run_state_expectations import selector, append


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--binary', type=Path, required=True); p.add_argument('--predecessor-binary', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    if a.output.exists(): p.error('output exists')
    h = Harness(a.binary, a.output); predecessor = a.predecessor_binary.resolve(strict=True)
    release = h.binary; comparisons = []; start = time.time(); code = 1
    def previous(label: str, args: list[str], expected: int = 0):
        h.binary = predecessor
        try: return h.run(label, args, expected=expected)
        finally:
            h.commands[-1]['executable'] = str(predecessor)
            h.binary = release
    def compare(label: str, state: Path, key: Path):
        journal = state/'state.journal'; before = journal.read_bytes()
        old = previous(label+'-predecessor', ['inspect','--state',str(state),'--node','A','--state-auth-key',str(key)])
        current = inspect(h,label+'-current',state,key)
        assert old and current
        h.check(old['storage']['logical_state_digest']==current['storage']['logical_state_digest'], 'same-input application logical digest agrees')
        h.check(old['storage']['state_authentication']==current['storage']['state_authentication'], 'same-input complete authentication account agrees')
        h.check(journal.read_bytes()==before, 'both readers leave exact journal bytes unchanged')
        h.check(current['state_head']['selector']==selector(before,key), 'current selector matches independent authenticated bytes')
        comparisons.append({'representation':label,'journal_sha256':hashlib.sha256(before).hexdigest(),'journal_bytes':len(before),
            'logical_state_digest':current['storage']['logical_state_digest'],'root':current['storage']['state_authentication']['root'],
            'readers_agree':True,'input_unchanged':True})
    try:
        root,state,key=setup(h,'compatibility');append(h,state,key,'compat-work')
        def ordinary():
            compare('ordinary-journal',state,key)
            result=previous('predecessor-rejects-live-command',['state-head','--control',str(state/'control.sock')],3)
            h.check(result and result['code']=='UNKNOWN_COMMAND','predecessor fails closed on unknown live observation command')
        h.case('ordinary_journal_and_cli_boundary',ordinary)
        def recovery():
            journal=state/'state.journal';raw=journal.read_bytes();pin=selector(raw,key)
            journal.write_bytes(incomplete_next(raw,key))
            report=audit(h,'compat-torn-audit',state,key,3,['--expected-state-head',pin])
            h.run('compat-recover',recover_args(state,key,report,root/'preserved.bin')+['--expected-state-head',pin])
            compare('recovered-journal',state,key)
        h.case('recovered_journal',recovery)
        backup=root/'checkpoint.nob'; backup_pin=''
        def checkpoint():
            nonlocal backup_pin
            exported=h.run('compat-backup-export',['backup-export','--state',str(state),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--output',str(backup),
                '--expected-state-head',selector((state/'state.journal').read_bytes(),key)])
            assert exported;backup_pin=exported['state_head']['selector'];before=backup.read_bytes()
            args=['backup-verify','--input',str(backup),'--node','A','--generation','a-g1','--state-auth-key',str(key)]
            old=previous('compat-backup-predecessor',args);new=h.run('compat-backup-current',args+['--expected-state-head',backup_pin]);assert old and new
            for field in ['checkpoint_digest','logical_state_digest','backup_id','state_authentication_account']:
                h.check(old[field]==new[field],'checkpoint readers agree on '+field)
            h.check(backup.read_bytes()==before,'backup input unchanged')
            comparisons.append({'representation':'backup-checkpoint','backup_sha256':hashlib.sha256(before).hexdigest(),
                'checkpoint_sha256':new['checkpoint_digest'],'logical_state_digest':new['logical_state_digest'],'readers_agree':True,'input_unchanged':True})
        h.case('backup_checkpoint',checkpoint)
        restored=root/'restored'
        def restore():
            h.run('compat-restore',['backup-restore','--input',str(backup),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--expected-state-head',backup_pin])
            compare('restored-journal',restored,key)
        h.case('restored_journal',restore)
        def rotation():
            newkey=new_key(h,root,'compat-rotation')
            h.run('compat-rotate',['state-auth-rotate','--state',str(restored),'--node','A','--state-auth-key',str(key),'--new-key',str(newkey),'--reason','expected predecessor',
                '--expected-state-head',selector((restored/'state.journal').read_bytes(),key)])
            compare('rotated-journal',restored,newkey)
        h.case('rotated_journal',rotation)
        code=0
    except BaseException as exc:
        (h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(str(exc),file=os.sys.stderr)
    finally:
        h.cleanup()
        summary={'format':'NATRAV_OVERLAY_STATE_HEAD_READER_COMPARISON_V1','status':'PASS' if code==0 else 'FAIL',
            'binary_sha256':hashlib.sha256(release.read_bytes()).hexdigest(),'predecessor_sha256':hashlib.sha256(predecessor.read_bytes()).hexdigest(),
            'cases_passed':sum(c['status']=='PASS' for c in h.cases),'cases_total':len(h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,data in [('SUMMARY.json',summary),('CASES.json',h.cases),('COMPARISONS.json',comparisons)]:
            (h.output/name).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary))
    return code
if __name__=='__main__':raise SystemExit(main())
