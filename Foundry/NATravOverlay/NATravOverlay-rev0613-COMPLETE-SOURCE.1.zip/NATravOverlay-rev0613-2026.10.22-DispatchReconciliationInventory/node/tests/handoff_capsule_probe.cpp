#include "handoff_capsule.hpp"
#include <algorithm>
#include <functional>
#include <iostream>
#include <memory>
#include <openssl/evp.h>

using namespace natrav_overlay;
namespace {
std::size_t checks = 0U;
void check(bool yes, const char* reason) { ++checks; if (!yes) { throw std::runtime_error(reason); } }
void rejected(const std::function<void()>& fn, const std::string& code = {}) {
    bool rejected = false;
    try { fn(); } catch (const AppError& e) { rejected = code.empty() || e.code() == code; }
    check(rejected, "expected typed rejection");
}
HandoffKeyBytes key_hex(std::string_view s) {
    HandoffKeyBytes r{};
    const auto nibble = [](char c) -> unsigned { return c <= '9' ? static_cast<unsigned>(c - '0') : static_cast<unsigned>(c - 'a') + 10U; };
    for (std::size_t i = 0U; i < r.size(); ++i) { r[i] = static_cast<std::uint8_t>((nibble(s[2U*i]) << 4U) | nibble(s[2U*i+1U])); }
    return r;
}
void resign(datacube::Octets& capsule, EVP_PKEY* signer) {
    constexpr std::string_view d = "NATravOverlay/handoff-signature/v1";
    datacube::Octets signed_bytes(d.begin(), d.end()); signed_bytes.push_back(0U);
    signed_bytes.insert(signed_bytes.end(), capsule.begin(), capsule.end()-64);
    std::unique_ptr<EVP_MD_CTX, decltype(&EVP_MD_CTX_free)> ctx(EVP_MD_CTX_new(), EVP_MD_CTX_free);
    check(EVP_DigestSignInit(ctx.get(), nullptr, nullptr, nullptr, signer) == 1, "signature context");
    std::size_t n = 64U;
    check(EVP_DigestSign(ctx.get(), capsule.data()+capsule.size()-64U, &n, signed_bytes.data(), signed_bytes.size()) == 1 && n == 64U, "resign");
}
}
int main() {
    try {
        // RFC 7748 section 6.1, Alice public-key known answer.
        const auto alice_secret = key_hex("77076d0a7318a57d3c16c17251b26645df4c2f87ebc0992ab177fba51db92c2a");
        check(handoff_x25519_public(alice_secret) == key_hex("8520f0098930a754748b7ddcb43ef75a0dbf3a0d26381af4eba4a98eaa9b4e6a"), "RFC7748 vector");
        HandoffKeyBytes aseed{}, bseed{}, ax{}, bx{}, bad{};
        aseed.fill(11U); bseed.fill(12U); ax.fill(13U); bx.fill(14U); bad.fill(15U);
        std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)> a(EVP_PKEY_new_raw_private_key(EVP_PKEY_ED25519, nullptr, aseed.data(), aseed.size()), EVP_PKEY_free);
        std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)> b(EVP_PKEY_new_raw_private_key(EVP_PKEY_ED25519, nullptr, bseed.data(), bseed.size()), EVP_PKEY_free);
        auto ab = make_handoff_binding("A", "a-g1", "a-h1", a.get(), handoff_x25519_public(ax));
        auto bb = make_handoff_binding("B", "b-g1", "b-h1", b.get(), handoff_x25519_public(bx));
        check(decode_handoff_binding(ab.canonical).canonical == ab.canonical, "binding canonical roundtrip");
        auto corrupt_binding = ab.canonical; corrupt_binding.back() ^= 1U;
        rejected([&] { (void)decode_handoff_binding(corrupt_binding); }, "HANDOFF_SIGNATURE_REJECTED");
        auto drift = ab; drift.handoff_generation = "a-h2";
        rejected([&] { require_handoff_binding(drift, "A", "a-g1", handoff_signing_pin(ab)); }, "HANDOFF_IDENTITY_REJECTED");
        constexpr std::uint64_t now = 1'700'000'000'000ULL;
        EvidenceRecord record; record.operation_id.octets.fill(99U); record.issuer = "A"; record.recipient = "B";
        record.scope = "test/three"; record.payload = {'s','e','c','r','e','t','-','p','a','y','l','o','a','d'};
        const auto capsule = seal_handoff_capsule(ab, a.get(), bb, record, now, now+60'000U);
        const auto open = [&](const datacube::Octets& data, std::uint64_t time = 1'700'000'000'000ULL) {
            return open_handoff_capsule(data, bb, bx, "A", "a-g1", handoff_signing_pin(ab), time);
        };
        check(std::get<EvidenceRecord>(open(capsule).message) == record, "encrypted operation roundtrip");
        check(std::search(capsule.begin(), capsule.end(), record.payload.begin(), record.payload.end()) == capsule.end(), "no cleartext payload");
        check(seal_handoff_capsule(ab, a.get(), bb, record, now, now+60'000U) != capsule, "fresh randomness");
        check(open(capsule).capsule_id == datacube::sha256(capsule), "complete capsule identifier");
        DeliveryReceipt receipt{record.operation_id, "B", "B", ReceiptDisposition::committed, 7U, evidence_record_digest(record)};
        auto reply = seal_handoff_capsule(bb, b.get(), ab, receipt, now, now+60'000U);
        check(std::get<DeliveryReceipt>(open_handoff_capsule(reply, ab, ax, "B", "b-g1", handoff_signing_pin(bb), now).message) == receipt, "receipt roundtrip");
        // Every byte, every truncated prefix: mutation cannot release plaintext.
        for (std::size_t i=0U; i<capsule.size(); ++i) {
            auto damaged=capsule; damaged[i] ^= 1U; rejected([&] { (void)open(damaged); });
            auto short_file=datacube::Octets(capsule.begin(), capsule.begin()+static_cast<std::ptrdiff_t>(i));
            rejected([&] { (void)open(short_file); });
        }
        auto trailing = capsule; trailing.push_back(0U); rejected([&] { (void)open(trailing); });
        rejected([&] { (void)open(capsule, now-1U); }, "HANDOFF_NOT_YET_VALID");
        rejected([&] { (void)open(capsule, now+60'000U); }, "HANDOFF_EXPIRED");
        rejected([&] { (void)seal_handoff_capsule(ab, a.get(), bb, record, now, now); });
        rejected([&] { (void)seal_handoff_capsule(ab, a.get(), bb, record, now, now+kHandoffLifetimeLimitMs+1U); });
        rejected([&] { (void)open_handoff_capsule(capsule, bb, bad, "A", "a-g1", handoff_signing_pin(ab), now); }, "HANDOFF_RECIPIENT_REJECTED");
        rejected([&] { (void)open_handoff_capsule(capsule, bb, bx, "A", "a-g2", handoff_signing_pin(ab), now); }, "HANDOFF_IDENTITY_REJECTED");
        rejected([&] { (void)open_handoff_capsule(capsule, bb, bx, "A", "a-g1", handoff_signing_pin(bb), now); }, "HANDOFF_IDENTITY_REJECTED");
        auto retag = capsule; retag[retag.size()-65U] ^= 1U; resign(retag, a.get());
        rejected([&] { (void)open(retag); }, "HANDOFF_AEAD_REJECTED");
        auto aad = capsule; aad[92U] ^= 1U; resign(aad, a.get());
        rejected([&] { (void)open(aad); }, "HANDOFF_AEAD_REJECTED");
        auto low = capsule; std::fill(low.begin()+60, low.begin()+92, 0U); low[60] = 1U; resign(low, a.get());
        rejected([&] { (void)open(low); }, "HANDOFF_KEY_REJECTED");
        auto noncanonical = capsule; noncanonical[91U] |= 128U; resign(noncanonical, a.get());
        rejected([&] { (void)open(noncanonical); }, "HANDOFF_KEY_REJECTED");
        auto wrong = record; wrong.issuer = "C";
        rejected([&] { (void)seal_handoff_capsule(ab, a.get(), bb, wrong, now, now+60'000U); }, "HANDOFF_PAYLOAD_REJECTED");
        rejected([&] { (void)seal_handoff_capsule(ab, b.get(), bb, record, now, now+60'000U); }, "HANDOFF_IDENTITY_REJECTED");
        ProtocolError error{std::nullopt, "BAD_REQUEST", "no arbitrary envelope"};
        rejected([&] { (void)seal_handoff_capsule(ab, a.get(), bb, error, now, now+60'000U); }, "HANDOFF_PAYLOAD_REJECTED");
        auto big=record; big.payload.assign(kMaximumEvidencePayloadBytes, 0xA5U);
        const auto maximum=seal_handoff_capsule(ab,a.get(),bb,big,now,now+60'000U);
        check(std::get<EvidenceRecord>(open(maximum).message) == big, "maximum evidence payload roundtrip");
        check(maximum.size() <= kHandoffCapsuleLimit, "encoded maximum remains bounded");
        std::cout << "{\"status\":\"PASS\",\"case_groups\":7,\"assertions\":" << checks << "}\n";
        return 0;
    } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
