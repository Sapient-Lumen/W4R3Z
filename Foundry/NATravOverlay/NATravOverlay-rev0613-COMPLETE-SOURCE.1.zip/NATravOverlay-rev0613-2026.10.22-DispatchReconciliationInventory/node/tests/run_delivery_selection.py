#!/usr/bin/env python3
"""Narrow pending delivery against real owned C++ peers and independently encoded state.
Synthetic history is labeled, not claimed to be authenticated network admission.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, struct, time
from pathlib import Path
from run_persistent import Harness, Daemon, operation, free_port
from run_integration import encode_record, record_digest, encode_receipt
from run_multi_route import write_v13_config, peer_status
from run_outbox_inspection import setup, submit, query, wait_outcome
from run_conditional_outbox import selection, apply
from run_live_configuration import candidate, activate
from run_state_authentication import new_key, migrate, start as start_keyed, inspect


def frame(kind: int, payload: bytes) -> bytes:
    body=bytes([kind])+payload
    return b'NOJ1'+struct.pack('!I',len(body))+body+hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest()


def text(s: str) -> bytes:
    b=s.encode();return struct.pack('!H',len(b))+b


def fixture(h: Harness, name: str, *, unrelated: int=0, settled: int=0, delayed: int=0,
            ready_b: int=1, ready_c: int=0, expired: int=0) -> tuple[Path,list[str],list[str]]:
    state=h.runtime/name;state.mkdir(mode=0o700)
    (state/'node.meta').write_text('NATRAV_OVERLAY_NODE_STATE_V2\nnode=A\nstorage_schema=2\n')
    (state/'node.meta').chmod(0o600);(state/'state.lock').touch(mode=0o600)
    now=int(time.time()*1000); bops=[];cops=[]
    with (state/'state.journal').open('wb') as f:
        for i in range(unrelated):
            raw=encode_record(operation(name+'-in-'+str(i)),'H','A','retained/unrelated',bytes([i%251])*2048)
            f.write(frame(1,raw))
        for i in range(settled):
            op=operation(name+'-old-'+str(i));raw=encode_record(op,'A','H','retained/old',b'x'*64)
            f.write(frame(2,raw));f.write(frame(3,encode_receipt(op,'H',1,i+1,record_digest(raw))))
        def queued(peer: str,label: str,*,future: bool=False,past: bool=False):
            op=operation(name+label);raw=encode_record(op,'A',peer,'test/three',b'p'*64)
            f.write(frame(2,raw))
            created=now-10000 if past else now
            expiry=now-1000 if past else now+1200000
            policy=bytes.fromhex(op)+struct.pack('!QQIII',created,expiry,5,50,100)+bytes.fromhex(h.identity(peer).spki_sha256)+text(peer.lower()+'-g1')
            f.write(frame(5,policy))
            if future:f.write(frame(6,bytes.fromhex(op)+struct.pack('!IQQ',1,now,now+600000)))
            return op
        for i in range(delayed):queued('B','-delayed-'+str(i),future=True)
        for i in range(expired):queued('B','-expired-'+str(i),past=True)
        for i in range(ready_b):bops.append(queued('B','-ready-b-'+str(i)))
        for i in range(ready_c):cops.append(queued('C','-ready-c-'+str(i)))
    (state/'state.journal').chmod(0o600)
    return state,bops,cops


def topology(h: Harness,name: str,state: Path,*,online_b=False,online_c=False, large=False, control_timeout_ms=2000):
    ports=[]
    while len(ports)<3:
        p=free_port()
        if p not in ports:ports.append(p)
    ap,bp,cp=ports;b=h.runtime/(name+'-b');c=h.runtime/(name+'-c')
    routes=[(peer,[('primary',0,'ENABLED',f'127.0.0.1:{port}')],50,100,100,1200000) for peer,port in [('B',bp),('C',cp)]]
    ac=write_v13_config(h,name+'-a','A',state,f'127.0.0.1:{ap}',name+'-a-g1',routes,deadline_ms=control_timeout_ms)
    ac.write_text(ac.read_text().replace('outbox_global_max_records=4096','outbox_global_max_records=10000').replace('outbox_peer_max_records=1024','outbox_peer_max_records=10000'))
    bc=write_v13_config(h,name+'-b','B',b,f'127.0.0.1:{bp}',name+'-b-g1',[],trusts=['A'],authorizations=[('A','test/three')],deadline_ms=2000)
    cc=write_v13_config(h,name+'-c','C',c,f'127.0.0.1:{cp}',name+'-c-g1',[],trusts=['A'],authorizations=[('A','test/three')],deadline_ms=2000)
    bd=h.start(name+'-b',bc,b) if online_b else None;cd=h.start(name+'-c',cc,c) if online_c else None
    # Explicit large-fixture replay allowance. Product control/I/O settings stay
    # identical to the ordinary V13 fixture; no deadline test is relaxed.
    ad=Daemon(h,name+'-a',ac,state,readiness_timeout=30 if large else 5);h.daemons.append(ad);ad.start()
    return ac,bc,cc,ad,bd,cd,b,c


def work(h: Harness,label: str,state: Path,peer='B'):
    return peer_status(h.status(label,state),peer)['delivery_selection']


def cases(h: Harness,only):
    def case(name,fn):
        if not only or name in only:h.case(name,fn)

    def unrelated():
        a,bops,cops=fixture(h,'large',unrelated=8192,settled=4096,ready_b=20,ready_c=4)
        ac,bc,cc,ad,bd,cd,b,c=topology(h,'large',a,online_c=True,large=True)
        wait_outcome(h,'other-peer-progress',a,cops[-1],'ACKED')
        h.wait('multiple failing route probes',lambda:peer_status(h.status('route-progress',a),'B')['routes'][0]['connection_attempts_this_run']>=2)
        before=work(h,'before-recipient',a)
        h.check(before['payload_records_copied']==0 and before['payload_bytes_copied']==0,'no selected payload copied for route-open failures')
        h.check(query(h,'pending-no-attempt',a,op=bops[0])['records'][0]['delivery']['attempts']==0,'V13 probes spend no application attempts')
        bd=h.start('large-live-b',bc,b)
        wait_outcome(h,'all-b-receipts',a,bops[-1],'ACKED')
        bwork=work(h,'final-large-b',a);cwork=work(h,'final-large-c',a,'C')
        h.check(bwork['payload_records_copied']==20 and bwork['payload_bytes_copied']==20*64,'only the 20 selected payloads were copied, not unrelated retained bytes')
        h.check(cwork['payload_records_copied']==4 and cwork['payload_bytes_copied']==4*64,'independent peer copied exactly its four selected records')
        for measured in (bwork,cwork):h.check(measured['metadata_records_read']<=measured['calls'],'at most one authoritative metadata record per selection call')
        h.check(query(h,'all-b-query',a,peer='B',outcome='ACKED',limit=1)['selected_total']==20,'all B outcomes indexed after delivery')
        (h.output/'LARGE-STATE.json').write_text(json.dumps({'unrelated_inbound_records':8192,'unrelated_inbound_payload_bytes':8192*2048,'settled_outbound_records':4096,'settled_outbound_payload_bytes':4096*64,'origin':'Independent legacy fixture decoded by the normal C++ node; not live network admissions.','before_provider':before,'peer_B':bwork,'peer_C':cwork},indent=2)+'\n')
        ad.shutdown();bd.shutdown();cd.shutdown()
    case('small_peers_beside_large_unrelated_payload_history_and_failed_routes',unrelated)

    def delayed():
        a,bops,_=fixture(h,'delayed',delayed=4096,ready_b=1)
        ac,bc,cc,ad,bd,cd,b,c=topology(h,'delayed',a,online_b=True)
        wait_outcome(h,'last-queue-ready',a,bops[0],'ACKED')
        measured=work(h,'delayed-work',a)
        h.check(measured['payload_records_copied']==1 and measured['payload_bytes_copied']==64,'delayed predecessors copy no payloads')
        h.check(measured['metadata_records_read']==1,'4096 earlier delayed records are not scanned as candidate metadata')
        h.check(measured['tree_nodes_visited']<=measured['calls']*32,'AVL visits bounded by tree height rather than delayed history length')
        h.check(query(h,'still-delayed',a,peer='B',outcome='PENDING',limit=1)['selected_total']==4096,'backoff obligations remain pending')
        h.run('delayed-compact',['compact','--control',str(a/'control.sock')]);ad.shutdown();ad=h.start('delayed-restart',ac,a)
        after=work(h,'delayed-rebuilt',a)
        h.check(after['metadata_records_read']==0 and after['payload_records_copied']==0,'checkpoint reconstructs readiness without scanning delayed records')
        (h.output/'DELAYED-HEAD.json').write_text(json.dumps({'delayed_records':4096,'ready_queue_sequence':4097,'work':measured,'after_restart':after},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('eligible_queue_tail_skips_4096_delayed_predecessors_and_rebuilds',delayed)

    def cancellation():
        a,b,ac,bc,ad,bd=setup(h,'selected-cancel',online=True);ad.shutdown()
        ad=h.start('selected-paused',ac,a,{'NATRAV_OVERLAY_TEST_DELIVERY_SELECTION_PAUSE_MS':'1500'})
        first=submit(h,'cancel-selected-first',a,peer='B')
        h.wait('selected ticket exposed',lambda:'DELIVERY_SELECTED '+first in ad.stderr_path.read_text())
        row,cfg=selection(h,'selected-before-cancel',a,first)
        apply(h,'cancel-after-selection',a,'cancel',row,cfg)
        second=submit(h,'still-deliver-second',a,peer='B')
        wait_outcome(h,'second-after-cancelled-head',a,second,'ACKED')
        cancelled=query(h,'cancelled-before-copy',a,op=first)['records'][0]
        h.check(cancelled['status']=='CANCELLED' and cancelled['delivery']['attempts']==0,'cancelled selection spends no attempt and is never sent')
        observed=work(h,'stale-work',a)
        h.check(observed['stale_selections']>=1 and observed['payload_records_copied']==1,'exact revalidation rejects stale ticket and next eligible record still progresses')
        h.check(h.status('recipient-only-second',b)['inbound_records']==1,'receiver admitted only the surviving second operation')
        (h.output/'STALE-SELECTION.json').write_text(json.dumps({'cancelled':first,'delivered':second,'work':observed},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('conditional_cancellation_between_selection_and_dispatch_preserves_later_work',cancellation)

    def rebound_selection():
        a,bops,_=fixture(h,'rebound-ticket',ready_b=1)
        b=h.runtime/'rebound-recipient';bp=free_port()
        replacement=h.identity('BNEW')
        ac=write_v13_config(h,'rebound-a','A',a,f'127.0.0.1:{free_port()}','rebound-a-g1',[
            ('B',[('primary',0,'ENABLED',f'127.0.0.1:{bp}')],50,100,100,600000)],deadline_ms=2000)
        ac.write_text(ac.read_text().replace('peer_key=B,b-g1,ACTIVE,','peer_key=B,b-g1,RETIRED,')+
            f'peer_key=B,b-g2,ACTIVE,{replacement.spki_sha256}\n')
        bc=write_v13_config(h,'rebound-b','B',b,f'127.0.0.1:{bp}','rebound-b-g1',[],trusts=['A'],authorizations=[('A','test/three')],deadline_ms=2000)
        old=h.identity('B')
        bc.write_text(bc.read_text().replace(str(old.certificate),str(replacement.certificate)).replace(str(old.private_key),str(replacement.private_key)).replace(old.spki_sha256,replacement.spki_sha256).replace('identity_generation=b-g1','identity_generation=b-g2'))
        bd=h.start('rebound-recipient',bc,b)
        ad=h.start('rebound-owner',ac,a,{'NATRAV_OVERLAY_TEST_DELIVERY_SELECTION_PAUSE_MS':'1500'})
        h.wait('old generation selected',lambda:'DELIVERY_SELECTED '+bops[0] in ad.stderr_path.read_text())
        row,cfg=selection(h,'old-binding-selected',a,bops[0])
        apply(h,'rebind-between-selection-and-probe',a,'rebind',row,cfg,generation='b-g2')
        done=wait_outcome(h,'new-generation-delivered',a,bops[0],'ACKED')
        measured=work(h,'rebind-work',a)
        h.check(done['delivery']['policy']['peer_generation']=='b-g2' and done['delivery']['attempts']==1,'only newly selected recipient binding is issued')
        h.check(measured['stale_selections']>=1 and measured['payload_records_copied']==1 and measured['payload_bytes_copied']==64,'old generation ticket is rejected without a payload copy')
        ad.shutdown();bd.shutdown()
    case('exact_generation_rebind_between_metadata_selection_and_route_establishment',rebound_selection)

    def removed_expiry():
        a,b,ac,bc,ad,bd=setup(h,'removed-expiry')
        ops=[submit(h,'removed-expiry-'+str(i),a,peer='D') for i in range(12)]
        removed=candidate(h,ac,'removed-routes','removed-g2',lambda t:'\n'.join(line for line in t.splitlines() if not line.startswith(('peer=D,','peer_route=D,')))+'\n')
        activate(h,'remove-expiring-route',a,removed)
        h.wait('removed peer expiries',lambda:query(h,'expiry-count',a,peer='D',outcome='EXPIRED',limit=1)['selected_total']==12)
        for op in (ops[0],ops[-1]):
            row=query(h,'expiry-exact',a,op=op)['records'][0]
            h.check(row['delivery']['expiry_reason']=='DELIVERY_EXPIRED' and row['delivery']['attempts']==0,'removed-route expiry without application attempt')
        h.run('expired-compact',['compact','--control',str(a/'control.sock')]);ad.shutdown();ad=h.start('expired-restart',ac,a)
        h.check(query(h,'expired-reconstructed',a,peer='D',outcome='EXPIRED',limit=1)['selected_total']==12,'expired entries do not reenter pending after reconstruction')
        ad.shutdown()
    case('removed_route_expiry_is_incremental_and_terminal_index_rebuilds',removed_expiry)

    def maintenance():
        a,b,ac,bc,ad,bd=setup(h,'delivery-maintenance')
        ops=[submit(h,'restore-pending-'+str(i),a,peer='B') for i in range(4)]
        doomed=submit(h,'restore-cancelled',a,peer='B');row,cfg=selection(h,'doomed-selected',a,doomed);apply(h,'doomed-cancel',a,'cancel',row,cfg)
        ad.shutdown();key=new_key(h,h.work,'delivery-key');migrate(h,'delivery-migrate',a,key)
        ad=start_keyed(h,'delivery-keyed',ac,a,key);h.run('delivery-compact',['compact','--control',str(a/'control.sock')]);ad.shutdown()
        audit=h.run('delivery-audit',['state-auth-audit','--state',str(a),'--node','A','--state-auth-key',str(key)])
        before=inspect(h,'delivery-before-backup',a,key)
        archive=h.work/'delivery.nob';crypt=h.work/'delivery-archive.key'
        h.run('delivery-backup-key',['backup-key-init','--output',str(crypt),'--generation','delivery-archive'])
        ident=h.identity('A')
        h.run('delivery-export',['backup-export','--state',str(a),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--output',str(archive),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'delivery-restored'
        h.run('delivery-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'delivery-after-backup',restored,key)
        h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'derived delivery indexes introduce no durable representation change')
        moved=candidate(h,ac,'delivery-moved','delivery-moved-g2',lambda t:t.replace('state='+str(a),'state='+str(restored)))
        h.run('delivery-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','owned restore continuation','--state-auth-key',str(key)])
        ad=start_keyed(h,'delivery-restored-owner',moved,restored,key);bd=h.start('delivery-restored-peer',bc,b)
        enabled=candidate(h,moved,'delivery-enabled','delivery-enabled-g3',lambda t:t.replace('peer_route=B,primary,0,DISABLED','peer_route=B,primary,0,ENABLED'))
        activate(h,'delivery-enable-restored',restored,enabled)
        wait_outcome(h,'delivery-restored-all',restored,ops[-1],'ACKED')
        measured=work(h,'restored-selection-work',restored)
        h.check(measured['payload_records_copied']==4 and measured['payload_bytes_copied']==4*len('bounded test metadata'),'only reconstructed pending records selected after restore')
        h.check(query(h,'cancelled-still-terminal',restored,op=doomed)['records'][0]['status']=='CANCELLED','cancelled entry stays absent from readiness')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'logical_digest':after['storage']['logical_state_digest'],'work':measured,'audit':audit},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('keyed_compaction_encrypted_restore_relocation_and_actual_pending_delivery',maintenance)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    try:
        cases(h,set(a.case) if a.case else None)
        if not h.cases:raise ValueError("no matching test case")
        ok=True
    except BaseException as exc:(h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(f'FAIL: {type(exc).__name__}: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_DELIVERY_SELECTION_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
