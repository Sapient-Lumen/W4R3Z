#!/usr/bin/env python3
"""Action inspection against owned native peers and independent wire/receipt references.
No arbitrary effects: only the product's bounded counter.add sink is exercised.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, shutil, socket, struct, time
from pathlib import Path
from run_persistent import Harness, free_port, operation, raw_control, receive_exact
from run_authorization_actions import write_config, generation, action_payload, independent_record, submit_action
from run_live_configuration import candidate, activate
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_state_authentication import new_key, migrate, start as start_keyed, inspect


def arguments(state, *, action=None, issuer='', outcome='', limit=16, maximum=60000, cursor=None):
    out=['action-query','--control',str(state/'control.sock'),'--limit',str(limit),'--max-bytes',str(maximum),'--deadline-ms','5000']
    for flag,value in [('--action',action),('--issuer',issuer),('--state',outcome),('--cursor',cursor)]:
        if value:out += [flag,value]
    return out


def query(h,label,state,*,uid=None,expected=0,**kw):
    args=arguments(state,**kw)
    q=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    if expected==0:
        h.check(q['format']=='NATRAV_OVERLAY_ACTION_QUERY_V1','explicit metadata format')
        h.check(q['returned']==len(q['records']) and q['returned']<=kw.get('limit',16),'returned rows bounded')
        w=q['work'];h.check(w['action_records_visited']<=kw.get('limit',16)+1 and w['source_records_visited']==w['action_records_visited'],'bounded action/source visits')
        h.check(w['binding_records_visited']<=4*w['action_records_visited'],'at most four retained binding references per row')
        h.check(w['payload_bytes_read']==w['historical_configurations_parsed']==w['snapshot_calls']==w['logical_bytes_serialized']==0,'no payload, config parse or application snapshot work')
        h.check(len(json.dumps(q,separators=(',',':')).encode())<=kw.get('maximum',60000),'annotated JSON fits bound')
        for row in q['records']:
            h.check(row['reserved_amount']==(row['amount'] if row['status']=='PENDING' else 0),'reservation from actual terminal state')
            h.check(row['effect_completed']==(row['status']=='EXECUTED'),'completion means committed counter effect')
            h.check((row['result'] is not None)==row['effect_completed'],'no manufactured result before completion')
            h.check('payload' not in row['source_admission'] and 'payload_hex' not in row['source_admission'],'metadata API omits bytes')
            h.check(row['executor_identity'] is None and row['terminal_principal'] is None,'missing historical principals are not guessed')
    return q


def wire(*,action=None,issuer='',outcome='',limit=16,maximum=60000,cursor=''):
    text=lambda s:struct.pack('!H',len(s))+s.encode()
    return b'NOC1\x1dAQY1'+text(issuer)+text(outcome)+(b'\x01'+bytes.fromhex(action) if action else b'\x00')+struct.pack('!II',limit,maximum)+text(cursor)


def setup(h,name,*,delegates=False,environment=None,legacy=False,expiry=86400000):
    b=h.runtime/(name+'-b');bp=free_port()
    cfg=write_config(h,name+'-b','B',b,bp,'B',[],
        [('A',generation('A'),'ACTIVE','A'),('C',generation('C'),'ACTIVE','C')],
        [('A','*','ACTION','counter.add'),('C','*','ACTION','counter.add')],
        counter_budget=1000000,maximum_increment=1000,maximum_defer_ms=600000,action_expiry_ms=expiry,deadline_ms=3000)
    if not legacy:
        cfg.write_text(cfg.read_text().replace('CONFIG_V6','CONFIG_V8')+f'runtime_generation={name}-g1\nlocal_control={os.geteuid()},ALL\n'+
            ('local_control=65534,INSPECT\nlocal_control=65533,SUBMIT\n' if delegates else ''))
    d=h.start(name+'-b',cfg,b,environment)
    return b,cfg,bp,d


def incoming(h,label,port,*,issuer='A',amount=1,defer=600000):
    op=operation(label)
    r=independent_record(h,port,issuer,issuer,'B',op,'actions/counter.add/v1',action_payload(amount,defer))
    h.check(r.get('kind')=='receipt',f'authenticated action admission returns receipt: {r}')
    return op,r


def wait_row(h,label,b,op,state):
    saved={}
    def ready():
        q=query(h,label,b,action=op)
        if not q['records']:return False
        saved.update(q['records'][0]);return saved['status']==state
    h.wait(label,ready,timeout=12);return saved


def enumerate_rows(h,label,state,**kw):
    token=None;rows=[];pages=0
    while True:
        q=query(h,label+'-'+str(pages),state,cursor=token,**kw);rows += q['records'];pages+=1
        if not q['more']:return rows,pages
        h.check(q['next_cursor'] is not None,'more means continuation');token=q['next_cursor']
        if pages>1024:raise AssertionError('non-progressing cursor')


def stable(rows):return [{k:v for k,v in row.items() if k!='action_revision'} for row in rows]


def run_cases(h,selected):
    def case(name,fn):
        if not selected or name in selected:h.case(name,fn)

    def complete():
        b,bc,bp,bd=setup(h,'complete');senders={};daemons=[]
        for node in ('A','C'):
            st=h.runtime/('complete-'+node.lower())
            cfg=write_config(h,'complete-'+node,node,st,free_port(),node,[('B',bp,'B')],[('B',generation('B'),'ACTIVE','B')],[],deadline_ms=3000)
            senders[node]=st;daemons.append(h.start('sender-'+node,cfg,st))
        expected=[]
        for i in range(150):
            issuer='A' if i%2==0 else 'C';op=operation('complete-'+str(i));amount=i%9+1
            submit_action(h,'enqueue-'+str(i),senders[issuer]/'control.sock',issuer,'B',op,amount,600000)
            expected.append((op,issuer,amount))
        h.wait('all 150 real native admissions',lambda:query(h,'total',b,limit=1)['selected_total']==150,timeout=25)
        preview=h.status('preview',b)['actions'];h.check(preview['count']==150 and preview['entries_truncated'] and len(preview['entries'])<150,'generic preview does not contain complete registry')
        last=query(h,'exact-last',b,action=expected[-1][0])['records'][0];h.check(last['action_id']==expected[-1][0],'exact beyond summary')
        rows,pages=enumerate_rows(h,'all',b,limit=7)
        h.check(len(rows)==150 and len({x['action_id'] for x in rows})==150,'all actual admissions once')
        h.check([x['queue_sequence'] for x in rows]==list(range(1,151)),'durable admission order')
        ref={op:(issuer,amount) for op,issuer,amount in expected}
        for row in rows:
            h.check((row['issuer'],row['amount'])==ref[row['action_id']],'independent amount and issuer reference')
            h.check(row['status']=='PENDING' and row['attempts']==0 and row['execution_phase']=='ADMITTED','deferred admission not execution')
            h.check(row['source_admission']['authorization']['decision']=='ADMITTED' and row['source_admission']['payload_bytes']==16,'actual admission provenance')
            h.check(row['mutation_bindings']['admission']['journal_kind']==11,'real source configuration binding')
        for issuer in ('A','C'):
            filtered,_=enumerate_rows(h,'filter-'+issuer,b,issuer=issuer,outcome='PENDING',limit=11)
            h.check(len(filtered)==75 and all(x['issuer']==issuer for x in filtered),'exact issuer/state selection')
        h.check(query(h,'absent',b,action='01'*32)['records']==[],'missing action empty')
        h.check(query(h,'conjunction',b,action=last['action_id'],issuer='A')['records']==[],'exact filters conjunctive')
        size=(b/'state.journal').stat().st_size
        for i in range(12):
            q=query(h,'empty-'+str(i),b,issuer='UNKNOWN');h.check(q['work']['action_records_visited']==0,'empty page visits no actions')
        h.check((b/'state.journal').stat().st_size==size,'successful inspection writes nothing')
        h.run('compact',['compact','--control',str(b/'control.sock'),'--deadline-ms','10000'],timeout=15)
        bd.shutdown();bd=h.start('complete-restart',bc,b)
        reconstructed,_=enumerate_rows(h,'reconstructed',b,limit=16)
        h.check(stable(reconstructed)==stable(rows),'checkpoint rebuild preserves all actual metadata and config links')
        (h.output/'ENUMERATION.json').write_text(json.dumps({'actual_cpp_admissions':150,'pages':pages,'generic_returned':len(preview['entries']),'exact_last':last,'all_pending_amount':sum(v for _,_,v in expected),'empty_polls':12},indent=2)+'\n')
        for d in daemons:d.shutdown()
        bd.shutdown()
    case('complete_native_admissions_beyond_preview_filtered_order_and_checkpoint',complete)

    def outcomes():
        b,bc,bp,bd=setup(h,'outcomes',environment={'NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS':'800'})
        one,receipt=incoming(h,'executed',bp,amount=7,defer=0);done=wait_row(h,'executed',b,one,'EXECUTED')
        expected=hashlib.sha256(b'NATRAV_OVERLAY_COUNTER_ACTION_RECEIPT_V1\0'+bytes.fromhex(one)+struct.pack('!IQQQ',done['attempts'],done['completed_unix_ms'],0,7)).hexdigest()
        h.check(done['result']['counter_before']==0 and done['result']['counter_after']==7 and done['result']['receipt_digest']==expected,'independent effect receipt reconstruction')
        h.check(done['source_admission']['sequence']==receipt['sequence'],'admission receipt is distinct from local effect receipt')
        replay=independent_record(h,bp,'A','A','B',one,'actions/counter.add/v1',action_payload(7));h.check(replay['disposition']==2,'duplicate source returns duplicate receipt')
        h.check(query(h,'no-repeat-effect',b,action=one)['sink_observation']['counter_value']==7,'duplicate admission does not repeat effect')
        two,_=incoming(h,'cancelled',bp,amount=5);secret='do-not-echo /private/key.pem'
        h.run('cancel',['action-cancel','--control',str(b/'control.sock'),'--action',two,'--reason',secret])
        cancel=wait_row(h,'cancelled',b,two,'CANCELLED');h.check(secret not in json.dumps(cancel) and cancel['cancellation_reason']['digest']==hashlib.sha256(b'NATRAV_OVERLAY_ACTION_REASON_V1\0'+secret.encode()).hexdigest(),'reason redacted with independent digest')
        new=candidate(h,bc,'short-expiry','outcomes-g2',lambda t:t.replace('action_expiry_ms=86400000','action_expiry_ms=200'))
        activate(h,'change-expiry',b,new)
        blocker,_=incoming(h,'expiry-blocker',bp,amount=1,defer=0)
        h.wait('blocker started',lambda:query(h,'blocker-start',b,action=blocker)['records'][0]['attempts']==1)
        three,_=incoming(h,'expired',bp,amount=3,defer=100);expired=wait_row(h,'expired',b,three,'EXPIRED')
        h.check(expired['attempts']==0 and expired['expired_unix_ms'] is not None and expired['result'] is None,'unstarted expiry is not an executed effect')
        new2=candidate(h,bc,'long-expiry','outcomes-g3');activate(h,'longer-expiry',b,new2)
        four,_=incoming(h,'pending',bp,amount=2)
        q=query(h,'four-states',b);h.check({x['status'] for x in q['records']}=={'PENDING','EXECUTED','CANCELLED','EXPIRED'},'all durable states represented')
        h.check(q['sink_observation']['counter_value']==8 and q['sink_observation']['reserved_amount']==2,'counter and remaining reservation exact')
        # A malformed admitted peer request never becomes an admitted action.
        denied=operation('malformed-action');err=independent_record(h,bp,'A','A','B',denied,'actions/counter.add/v1',b'bad')
        h.check(err['kind']=='error' and query(h,'denied-not-action',b,action=denied)['records']==[],'request failure not manufactured action')
        h.run('quiesce',['quiesce','--control',str(b/'control.sock'),'--reason','inspection remains available']);query(h,'quiesced',b)
        h.run('resume',['resume','--control',str(b/'control.sock'),'--reason','test resume'])
        h.run('drain',['drain-shutdown','--control',str(b/'control.sock'),'--reason','pending action keeps drain active','--drain-deadline-ms','1500'])
        query(h,'draining',b)
        bd.process.wait(timeout=6);bd._close_files()
        (h.output/'OUTCOMES.json').write_text(json.dumps(q,indent=2)+'\n')
    case('actual_effect_receipt_replay_cancellation_expiry_admission_and_lifecycle',outcomes)

    def cursors():
        b,bc,bp,bd=setup(h,'cursors')
        ids=[incoming(h,'cursor-'+str(i),bp)[0] for i in range(6)]
        p=query(h,'first',b,issuer='A',limit=2);token=p['next_cursor']
        q=query(h,'second',b,issuer='A',limit=2,cursor=token);h.check([r['action_id'] for r in q['records']]==ids[2:4],'indexed continuation exact')
        incoming(h,'other-issuer',bp,issuer='C')
        h.check(query(h,'unrelated',b,issuer='A',limit=2,cursor=token)['records']==q['records'],'unrelated issuer does not stale selected metadata')
        bad=token[:-1]+('0' if token[-1]!='0' else '1')
        h.check(query(h,'bad-tag',b,issuer='A',limit=2,cursor=bad,expected=3)['code']=='ACTION_CURSOR_INVALID','altered MAC rejected')
        h.check(query(h,'context',b,issuer='A',limit=3,cursor=token,expected=3)['code']=='ACTION_CURSOR_CONTEXT_MISMATCH','all query options bound')
        h.run('change',['action-cancel','--control',str(b/'control.sock'),'--action',ids[-1],'--reason','selected mutation'])
        h.check(query(h,'selected-stale',b,issuer='A',limit=2,cursor=token,expected=3)['code']=='ACTION_CURSOR_STALE','selected mutation cannot silently straddle pages')
        p=query(h,'compact-first',b,issuer='A',limit=2);h.run('compact-cursor',['compact','--control',str(b/'control.sock')]);query(h,'compact-continued',b,issuer='A',limit=2,cursor=p['next_cursor'])
        nc=candidate(h,bc,'cursor-config','cursors-g2');activate(h,'new-config',b,nc)
        h.check(query(h,'changed-config',b,issuer='A',limit=2,cursor=p['next_cursor'],expected=3)['code']=='ACTION_CURSOR_CONTEXT_MISMATCH','accepted config bound')
        p=query(h,'restart-first',b,issuer='A',limit=2);bd.shutdown();bd=h.start('cursor-restart',nc,b)
        h.check(query(h,'old-process',b,issuer='A',limit=2,cursor=p['next_cursor'],expected=3)['code']=='ACTION_CURSOR_INVALID','old process tokens invalid')
        small=query(h,'byte-page',b,maximum=6000,limit=64);h.check(small['more'] and 0<small['returned']<6,'byte cap ends on complete row')
        h.check(query(h,'first-too-small',b,maximum=2048,expected=3)['code']=='ACTION_QUERY_PAGE_TOO_SMALL','explicit nonfitting first row')
        good=wire(action=ids[0]);ok,q=raw_control(b/'control.sock',good);h.check(ok and q['records'][0]['action_id']==ids[0],'independent AQY1 control encoding')
        for label,bad in [('tail',good+b'x'),('short',good[:-1]),('magic',good.replace(b'AQY1',b'AQY9')),('rows',wire(limit=65)),('state',wire(outcome='ACKED')),('zero-id',wire(action='00'*32))]:
            ok,_=raw_control(b/'control.sock',bad);h.check(not ok,'strict query rejection '+label)
        bd.shutdown()
    case('authenticated_cursor_mutation_context_restart_compaction_and_strict_wire',cursors)

    def interrupted():
        b,bc,bp,bd=setup(h,'interrupted',environment={'NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS':'5000'})
        op,_=incoming(h,'real-interrupted',bp,amount=11,defer=0);saved={}
        def begun():
            row=query(h,'started',b,action=op)['records'][0];saved.update(row);return row['attempts']==1
        h.wait('synchronized action start visible',begun)
        h.check(saved['status']=='PENDING' and saved['execution_phase']=='STARTED_UNRESOLVED' and saved['result'] is None and saved['last_error_code']=='ACTION_ATTEMPT_INTERRUPTED','provisional marker is not proof of completion or a separate final state')
        h.check(saved['mutation_bindings']['latest_start']['journal_kind']==13,'actual start configuration reference')
        bd.kill();bd=h.start('after-start-kill',bc,b);done=wait_row(h,'restart-executed',b,op,'EXECUTED')
        h.check(done['attempts']==2 and done['result']['counter_before']==0 and done['result']['counter_after']==11,'restart retries internal action once; two begun attempts one committed result')
        h.check(done['attempt_history']=='COUNT_AND_LATEST_START_ONLY','old per-attempt timeline not invented')
        h.run('interrupted-compact',['compact','--control',str(b/'control.sock')]);bd.shutdown();bd=h.start('after-completion-rebuild',bc,b)
        h.check(stable(query(h,'rebuilt',b,action=op)['records'])==stable([done]),'latest attempt and actual bindings survive checkpoint')
        (h.output/'INTERRUPTED.json').write_text(json.dumps({'started':saved,'completed':done},indent=2)+'\n');bd.shutdown()
    case('real_hard_kill_after_start_reconstructed_attempt_and_single_counter_effect',interrupted)

    def authority():
        b,bc,bp,bd=setup(h,'authority',delegates=True)
        for i in range(3):incoming(h,'auth-'+str(i),bp)
        expose_control_for_uid(b)
        q=query(h,'uid-inspector',b,uid=65534,limit=1)
        h.check(query(h,'wrong-class',b,uid=65533,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','SUBMIT does not inspect action results')
        h.check(query(h,'other-uid-cursor',b,limit=1,cursor=q['next_cursor'],expected=3)['code']=='ACTION_CURSOR_CONTEXT_MISMATCH','cursor binds actual UID')
        p=wire();sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);sock.settimeout(5);sock.connect(str(b/'control.sock'));sock.sendall(struct.pack('!I',len(p))+p[:-1])
        changed=candidate(h,bc,'revoke-inspect','authority-g2',lambda t:t.replace(f'local_control={os.geteuid()},ALL',f'local_control={os.geteuid()},SUBMIT,MAINTENANCE,CONFIGURATION,SHUTDOWN'))
        activate(h,'revoke',b,changed);sock.sendall(p[-1:]);sock.shutdown(socket.SHUT_WR);n=struct.unpack('!I',receive_exact(sock,4))[0];raw=receive_exact(sock,n);sock.close()
        h.check(raw[4]==1 and json.loads(raw[5:])['code']=='LOCAL_CONTROL_CLASS_DENIED','partial request reauthorized under current generation')
        query(h,'retained-inspector',b,uid=65534);restore_owner_only_control(b);bd.shutdown()
    case('real_principals_cross_uid_cursor_and_live_post_decode_revocation',authority)

    def maintenance():
        b,bc,bp,bd=setup(h,'maintenance');one,_=incoming(h,'maint-done',bp,amount=9,defer=0);wait_row(h,'maint-executed',b,one,'EXECUTED')
        two,_=incoming(h,'maint-pending',bp,amount=3);before=query(h,'before-key',b);bd.shutdown()
        key=new_key(h,h.work,'action-state-g1');migrate(h,'migrate-action-state',b,key,node='B')
        bd=start_keyed(h,'keyed-actions',bc,b,key)
        h.run('keyed-compact',['compact','--control',str(b/'control.sock'),'--deadline-ms','5000']);bd.shutdown()
        offline=inspect(h,'before-export',b,key,node='B');crypt=h.work/'archive.key';archive=h.work/'actions.nob';ident=h.identity('B')
        h.run('crypt-key',['backup-key-init','--output',str(crypt),'--generation','action-backup'])
        h.run('export',['backup-export','--state',str(b),'--node','B','--generation',generation('B'),'--state-auth-key',str(key),'--output',str(archive),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'actions-restored';h.run('restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','B','--generation',generation('B'),'--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'restored',restored,key,node='B');h.check(offline['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'exact restored logical state before scheduling')
        relocated=candidate(h,bc,'relocated','actions-relocated-g2',lambda t:t.replace('state='+str(b),'state='+str(restored)))
        h.run('relocate',['state-relocate','--state',str(restored),'--node','B','--candidate',str(relocated),'--state-auth-key',str(key),'--reason','inspect restored action state'])
        bd=start_keyed(h,'relocated-owner',relocated,restored,key)
        q=query(h,'restored-records',restored);h.check(stable(q['records'])==stable(before['records']),'actual action/source/config metadata remains after restore and relocation')
        h.run('cancel-after-restore',['action-cancel','--control',str(restored/'control.sock'),'--action',two,'--reason','cancel restored obligation'])
        row=query(h,'cancelled-restored',restored,action=two)['records'][0]
        h.check(row['status']=='CANCELLED' and row['mutation_bindings']['terminal']['configuration_generation']=='actions-relocated-g2','new terminal reference uses relocated generation; old admission not rewritten')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'before_digest':offline['storage']['logical_state_digest'],'restored_digest':after['storage']['logical_state_digest'],'before':before,'after':q,'later_cancel':row},indent=2)+'\n');bd.shutdown()
    case('keyed_compaction_encrypted_backup_restore_relocation_and_later_action',maintenance)

    def legacy():
        b,bc,bp,bd=setup(h,'legacy',legacy=True);op,_=incoming(h,'legacy-action',bp,amount=2,defer=0);row=wait_row(h,'legacy-executed',b,op,'EXECUTED')
        h.check(all(x is None for x in row['mutation_bindings'].values()),'legacy absent config binding not invented')
        h.check(row['source_admission']['authorization']['peer_generation']==generation('A'),'actual legacy admission account preserved')
        bd.shutdown()
    case('legacy_action_provenance_absence_is_not_backfilled',legacy)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);start=time.time();ok=False
    try:
        run_cases(h,set(a.case) if a.case else None)
        if not h.cases:raise ValueError('no selected cases')
        ok=True
    except BaseException as e:(h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_ACTION_INSPECTION_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(x['status']=='PASS' for x in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,value in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
