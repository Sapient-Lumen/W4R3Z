#!/usr/bin/env python3
"""Manager-scoped observational inventory using real C++ providers and recipients."""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
import sys
import time
from run_persistent import Harness, free_port, operation, raw_control
from run_source_subscriptions import config, command, ack, SCOPE
from run_local_evidence import author
from run_evidence_queries import config as peer_config
from run_live_configuration import candidate, activate
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_subscription_leases import local, remote
from run_lease_succession import setup, add_grant, succeed, received
from run_terminal_reconciliation import late, reconcile
from run_automatic_source_delivery import automatic, wait_automatic
from run_state_authentication import new_key, migrate, start as start_keyed, inspect

FORMAT='NATRAV_OVERLAY_SUBSCRIPTION_INVENTORY_V1'
def save(h,name,value): (h.output/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')
def text(s):
    b=s.encode();return struct.pack('!H',len(b))+b
def opt(s):return b'\1'+bytes.fromhex(s) if s else b'\0'
def fields(kw):
    out=b''.join(text(kw.get(k,'all' if k in ('lifecycle','lease','schedule','outcome') else ''))
        for k in ('lifecycle','lease','schedule','outcome','grant','peer','scope'))
    out+=b'\0' if kw.get('author_uid') is None else b'\1'+struct.pack('!I',kw['author_uid'])
    return out+opt(kw.get('instance'))
def wire(**kw):
    return b'NOC1'+bytes([38])+b'SIN1'+fields(kw)+struct.pack('!III',kw.get('offset',0),kw.get('limit',16),kw.get('max_bytes',32768))+opt(kw.get('selection'))
def root_for(response,rows,**kw):
    raw=b'NATRAV_OVERLAY_SUBSCRIPTION_INVENTORY_SELECTION_V1\0'+text(response['node'])+struct.pack('!I',response['manager_uid'])+bytes.fromhex(response['authorized_configuration_digest'])+fields(kw)+struct.pack('!I',len(rows))
    root=hashlib.sha256(raw).digest()
    for row in rows:
        value=json.dumps(row,separators=(',',':'),ensure_ascii=False).encode()
        root=hashlib.sha256(b'NATRAV_OVERLAY_SUBSCRIPTION_INVENTORY_ROW_V1\0'+root+struct.pack('!I',len(value))+value).digest()
    return root.hex()
def query(h,label,state,expected=0,uid=None,**kw):
    args=['source-subscription-inventory','--control',str(state/'control.sock'),'--deadline-ms','5000']
    for key,value in kw.items():args+=['--'+key.replace('_','-'),str(value)]
    result=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    assert result is not None
    if expected==0:
        h.check(result['format']==FORMAT and result['manager_uid']==(os.geteuid() if uid is None else uid),'format and actual kernel manager')
        h.check(result['returned']==len(result['records']) and result['next_offset']==result['offset']+result['returned'],'whole-row continuation')
        h.check(all(row['manager_uid']==result['manager_uid'] for row in result['records']),'no cross-manager rows')
        w=result['work'];h.check(all(w[x]==0 for x in ('payload_bytes_copied','histories_serialized','source_records_read','snapshot_calls','snapshot_payload_bytes','logical_bytes_serialized')),'metadata-only bounded observation')
        h.check(len(json.dumps(result,separators=(',',':')).encode())<=int(kw.get('max_bytes',32768)),'complete annotated response byte limit')
    return result

def run_cases(h,selected=None):
    def case(name,f):
        if selected is None or name in selected:h.case(name,f)
    def basic():
        a=h.runtime/'basic';cp=free_port()
        rules=[f'{g},{os.geteuid()},{os.geteuid()},C,c-g1,{s},8,10000' for g,s in [('alpha',SCOPE),('beta',SCOPE),('other','query/other')]]
        cfg=config(h,'basic',a,ports={'C':cp},rules=rules);d=h.start('basic',cfg,a)
        empty=query(h,'empty',a);h.check(empty['selected_total']==0 and root_for(empty,[])==empty['selection_digest'],'empty commitment reference')
        before=(a/'state.journal').read_bytes()
        for i in range(4):query(h,'empty-poll-'+str(i),a)
        h.check(before==(a/'state.journal').read_bytes(),'successful empty reads are observational')
        subs={g:command(h,'create-'+g,a,'create',grant=g) for g in ['beta','other','alpha']}
        subs['beta']=command(h,'retire-beta',a,'retire',grant='beta',previous=subs['beta'])
        whole=query(h,'all',a,max_bytes=60000);rows=whole['records']
        h.check([x['grant'] for x in rows]==['alpha','beta','other'],'owned grant order not creation order')
        h.check(root_for(whole,rows)==whole['selection_digest'],'independent selected root')
        for row in rows:
            s=subs[row['grant']]
            h.check(row['instance']==s['instance'] and row['revision']==s['revision'],'actual stored instance and revision')
            h.check(row['head'] is None and row['lease_state']=='UNLEASED' and row['schedule_state']=='NONE','unissued unleased state')
            h.check(row['remote_admission'] is None and row['creation_manager_pid']>0,'local creator not fabricated remote actor')
            h.check('reason' not in json.dumps(row) and 'payload_hex' not in json.dumps(row),'no reason text or payload')
        first=query(h,'page-first',a,limit=1);second=query(h,'page-second',a,limit=2,offset=1,selection=first['selection_digest'],max_bytes=60000)
        h.check(first['records']+second['records']==rows,'page size and byte budget can change')
        for kw,count in [({'lifecycle':'retired'},1),({'lease':'unleased'},3),({'lease':'expired'},0),({'schedule':'none'},3),({'outcome':'none'},3),({'scope':SCOPE},2),({'grant':'alpha','lifecycle':'retired'},0),({'author_uid':os.geteuid()},3),({'instance':subs['beta']['instance']},1)]:
            result=query(h,'filter-'+str(kw).replace('/','_'),a,**kw);h.check(result['selected_total']==count,'exact conjunctive filter')
            h.check(root_for(result,result['records'],**kw)==result['selection_digest'],'independent filtered root')
        h.check(query(h,'false-selection',a,selection='42'*32,expected=3)['code']=='SUBSCRIPTION_INVENTORY_SELECTION_MISMATCH','false selection rejected')
        h.check(query(h,'offset-needs-selection',a,offset=1,expected=3)['code']=='SUBSCRIPTION_INVENTORY_SELECTION_REQUIRED','unguarded continuation refused')
        h.check(query(h,'small-first-row',a,max_bytes=2048,expected=3)['code']=='SUBSCRIPTION_INVENTORY_PAGE_TOO_SMALL','complete first row never truncated')
        clipped=query(h,'byte-limited',a,max_bytes=5000);h.check(0<clipped['returned']<3 and clipped['has_more'],'byte limit produces usable continuation')
        ok,independent=raw_control(d.control,wire(limit=2,max_bytes=60000));h.check(ok and independent['records']==rows[:2],'independent SIN1 encoding')
        for body in [wire()+b'x',wire()[:-1],wire(lease='nonsense'),wire(instance='00'*32),wire(author_uid=0)[:-1]+b'\2']:
            ok,error=raw_control(d.control,body);h.check(not ok and error['code']=='SUBSCRIPTION_INVENTORY_INVALID','malformed protocol rejected')
        save(h,'BASIC',{'all':whole,'byte_page':clipped,'independent':independent});d.shutdown()
    case('strict_filters_independent_wire_commitment_and_bounded_pages',basic)

    def receipts_and_automatic():
        a,c=h.runtime/'delivery-a',h.runtime/'delivery-c';cp=free_port()
        cfg=config(h,'delivery',a,ports={'C':cp});cc=peer_config(h,'delivery-c','C',c,cp,inbound=['A']);d=h.start('delivery',cfg,a)
        author(h,'first-source',a,value='first');created=command(h,'delivery-create',a,'create');before=query(h,'before-issue',a)
        issued=command(h,'delivery-issue',a,'step',previous=created);pending=query(h,'pending-head',a,outcome='pending')
        h.check(pending['selected_total']==1 and pending['records'][0]['head']['receipt'] is None,'pending outbox obligation without fabricated receipt')
        h.check(query(h,'issue-stale',a,selection=before['selection_digest'],expected=3)['code']=='SUBSCRIPTION_INVENTORY_SELECTION_MISMATCH','issue invalidates selected metadata')
        cd=h.start('delivery-c',cc,c)
        h.wait('actual peer durable receipt',lambda:command(h,'receipt-wait',a,'status')['delivery_status']=='ACKED')
        receipted=query(h,'outbox-acked-source-unacked',a);row=receipted['records'][0]
        h.check(row['revision']==issued['revision'] and row['acknowledged']==0 and not row['head']['acknowledged_by_subscription'] and row['head']['receipt'] is not None,'receipt does not advance source frontier')
        acknowledged=command(h,'advance-receipt',a,'step',previous=issued)
        h.check(query(h,'ack-stale',a,selection=receipted['selection_digest'],expected=3)['code']=='SUBSCRIPTION_INVENTORY_SELECTION_MISMATCH','subscription ACK invalidates independently')
        author(h,'second-source',a,value='second')
        automatic(h,'enable-auto',a,'enable',previous=acknowledged,maximum=2,interval=10)
        wait_automatic(h,'two-steps',a,lambda v:v['automatic_current']['state']=='EXHAUSTED')
        done=query(h,'exhausted-auto',a,schedule='exhausted');s=done['records'][0]
        h.check(s['acknowledged']==2 and s['automatic_grant']['steps']==2 and s['head']['acknowledge_automatic_generation']==1,'actual AUTO_ISSUE and AUTO_ACK observed')
        stopped=command(h,'freeze-subscription',a,'retire',previous=command(h,'retire-read',a,'status'))
        journal=(a/'state.journal').read_bytes()
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: answers=list(pool.map(lambda i:query(h,'reader-'+str(i),a),range(8)))
        h.check(len({x['selection_digest'] for x in answers})==1 and journal==(a/'state.journal').read_bytes(),'concurrent observations do not mutate settled state')
        h.check(stopped['state']=='RETIRED' and answers[0]['records'][0]['schedule_state']=='EXHAUSTED','retirement not inferred from old grant label')
        save(h,'DELIVERY',{'pending':pending,'late_outbox_receipt':receipted,'automatic':done,'retired':answers[0]});d.shutdown();cd.shutdown()
    case('actual_receipts_distinct_from_frontier_and_finite_automatic_progress',receipts_and_automatic)

    def terminal_outcomes():
        a,c=h.runtime/'terminal-a',h.runtime/'terminal-c';cp=free_port()
        rules=[f'{g},{os.geteuid()},{os.geteuid()},C,c-g1,{SCOPE},8,10000' for g in ['rejected','cancelled','expired']]
        cfg=config(h,'terminal',a,ports={'C':cp},rules=rules);cc=peer_config(h,'terminal-c','C',c,cp,inbound=['A'])
        cc.write_text('\n'.join(line for line in cc.read_text().splitlines() if not line.startswith('authorize=A,*,EVIDENCE,'+SCOPE))+'\n')
        d=h.start('terminal-a',cfg,a);cd=h.start('terminal-c',cc,c);author(h,'terminal-source',a,value='source')
        rejected=command(h,'rejected-create',a,'create',grant='rejected');issued=command(h,'rejected-issue',a,'step',grant='rejected',previous=rejected)
        h.wait('recipient denies source',lambda:command(h,'rejected-receipt',a,'status',grant='rejected')['delivery_status']=='REJECTED')
        automatic(h,'rejection-enable',a,'enable',grant='rejected',previous=issued,maximum=2,interval=10)
        wait_automatic(h,'rejection-blocked',a,lambda x:x['automatic_current']['state']=='BLOCKED',grant='rejected')
        denial=query(h,'rejected-head-inventory',a,grant='rejected',outcome='rejected',schedule='blocked')
        h.check(denial['selected_total']==1 and denial['records'][0]['head']['delivery']['last_error_code']=='AUTHORIZATION_DENIED' and denial['records'][0]['head']['receipt'] is None,'actual recipient denial not receipt')
        def disable(text):
            lines=[]
            for line in text.splitlines():
                if line.startswith('peer=C,'):line=','.join(line.split(',')[:-1]+['1000'])
                if line.startswith('peer_route=C,'):line=line.replace(',ENABLED,',',DISABLED,')
                lines.append(line)
            return '\n'.join(lines)+'\n'
        disabled=candidate(h,cfg,'terminal-disabled','terminal-g2',disable);activate(h,'disable-terminal-route',a,disabled);cd.shutdown()
        x=command(h,'cancelled-create',a,'create',grant='cancelled');x=command(h,'cancelled-issue',a,'step',grant='cancelled',previous=x)
        h.run('cancel-source-obligation',['cancel','--control',str(d.control),'--operation',x['latest']['operation_id'],'--reason','explicit cancellation'])
        cancelled=query(h,'cancelled-head',a,grant='cancelled',outcome='cancelled')
        h.check(cancelled['selected_total']==1 and cancelled['records'][0]['acknowledged']==0 and cancelled['records'][0]['head']['receipt'] is None,'cancelled remains unacknowledged')
        x=command(h,'expired-create',a,'create',grant='expired');command(h,'expired-issue',a,'step',grant='expired',previous=x)
        h.wait('ordinary outbox expiry',lambda:command(h,'expired-poll',a,'status',grant='expired')['delivery_status']=='EXPIRED')
        expired=query(h,'expired-head',a,grant='expired',outcome='expired')
        h.check(expired['selected_total']==1 and expired['records'][0]['lease_state']=='UNLEASED' and expired['records'][0]['head']['delivery']['expired_unix_ms'] is not None,'delivery expiry is not lease expiry')
        save(h,'TERMINAL-OUTCOMES',{'rejected':denial,'cancelled':cancelled,'expired':expired});d.shutdown()
    case('recipient_rejection_cancellation_and_delivery_expiry_are_distinct',terminal_outcomes)

    def clocks():
        a,c,pa,pc,d,cd,_=setup(h,'clock',duration=800)
        first=query(h,'open-lease',a);row=first['records'][0]
        h.check(row['creation_actor_kind']=='AUTHENTICATED_SUBSCRIBER' and row['creation_manager_pid'] is None and row['remote_admission']['peer']=='C','remote principal is not a local manager PID')
        before=(a/'state.journal').read_bytes();sleep=max(0,row['lease_expires_unix_ms']/1000-time.time())+.1;time.sleep(sleep)
        elapsed=query(h,'elapsed-open-observation',a,selection=first['selection_digest'],lease='all')
        h.check(elapsed['observed_unix_ms']>row['lease_expires_unix_ms'] and elapsed['records']==first['records'],'clock passage is not stored lease termination')
        h.check(before==(a/'state.journal').read_bytes(),'listing elapsed lease creates no expiry journal event')
        current=local(h,'clock-local',a,'status');local(h,'clock-expire-step',a,'step',previous=current)
        expired=query(h,'committed-expiry',a,lease='expired');h.check(expired['selected_total']==1 and expired['records'][0]['lifecycle']=='RETIRED','expiry observed only after actual transition')
        h.check(query(h,'expiry-stale',a,selection=first['selection_digest'],expected=3)['code']=='SUBSCRIPTION_INVENTORY_SELECTION_MISMATCH','committed expiry changes selection')
        save(h,'LEASE-CLOCK',{'before':first,'elapsed':elapsed,'terminal':expired});d.shutdown();cd.shutdown()
    case('remote_actor_and_elapsed_lease_inspection_never_materializes_expiry',clocks)

    def principals():
        a=h.runtime/'owners';cp=free_port();u,v=65534,65533
        rules=[f'root,{os.geteuid()},{os.geteuid()},C,c-g1,{SCOPE},8,10000',f'one,{u},{os.geteuid()},C,c-g1,{SCOPE},8,10000',f'keep,{u},{os.geteuid()},C,c-g1,{SCOPE},8,10000',f'two,{v},{os.geteuid()},C,c-g1,{SCOPE},8,10000']
        cfg=config(h,'owners',a,ports={'C':cp},rules=rules)
        cfg.write_text(cfg.read_text()+f'local_control={u},SOURCE_DISCLOSE\nlocal_control={v},SOURCE_DISCLOSE\n')
        d=h.start('owners',cfg,a);expose_control_for_uid(a)
        one=command(h,'create-one',a,'create',grant='one',uid=u);query1=query(h,'owner-one',a,uid=u)
        two=command(h,'create-two',a,'create',grant='two',uid=v);query2=query(h,'owner-two',a,uid=v)
        h.check(query(h,'hidden-new-owner',a,uid=u,selection=query1['selection_digest'])['records']==query1['records'],'other manager creates no count or commitment change')
        for hidden in [two['instance'],'22'*32]:
            x=query(h,'hidden-instance-'+hidden[:4],a,uid=u,instance=hidden);h.check(x['selected_total']==x['returned']==x['work']['owned_summaries_hashed']==0,'foreign instance indistinguishable from absent')
        h.check(query(h,'foreign-root',a,uid=v,selection=query1['selection_digest'],expected=3)['code']=='SUBSCRIPTION_INVENTORY_SELECTION_MISMATCH','principal bound comparison')
        denied=run_as_uid(h,'no-read-grant',u,u,['evidence-query','--control',str(d.control)],3);h.check(denied['code']=='LOCAL_CONTROL_CLASS_DENIED','management inventory does not confer payload or metadata read authority')
        removed=candidate(h,cfg,'removed-one','owners-g2',lambda t:'\n'.join(x for x in t.splitlines() if not x.startswith('source_disclosure=one,'))+'\n')
        activate(h,'remove-rule',a,removed);retained=query(h,'removed-rule-visible',a,uid=u)
        h.check(retained['selected_total']==1 and not retained['records'][0]['policy_current'],'historical exact manager can locate revoked disclosure rule without ability to disclose')
        denied_step=command(h,'removed-rule-no-step',a,'step',grant='one',previous=one,uid=u,expected=3);h.check(denied_step['code']=='SOURCE_DISCLOSURE_DENIED','listing does not restore removed grant')
        alt=h.identity('C-alt')
        revoked=candidate(h,removed,'revoked-key','owners-g3',lambda t:t.replace('peer_key=C,c-g1,ACTIVE,','peer_key=C,c-g1,REVOKED,')+f'peer_key=C,c-g2,ACTIVE,{alt.spki_sha256}\n')
        activate(h,'revoke-key',a,revoked);keygone=query(h,'revoked-key-visible',a,uid=u)
        h.check(keygone['records'][0]['subscriber_generation_state']=='REVOKED' and keygone['records'][0]['subscriber_spki_sha256']==one['peer_spki_sha256'],'bound key retained independently of current active generation')
        script="""import socket,struct,sys,json
s=socket.socket(socket.AF_UNIX);s.settimeout(8);s.connect(sys.argv[1]);p=bytes.fromhex(sys.argv[2]);s.sendall(struct.pack('!I',len(p))+p[:2]);print('READY',flush=True);sys.stdin.readline();s.sendall(p[2:]);s.shutdown(socket.SHUT_WR)
def read(n):
 b=b''
 while len(b)<n:
  x=s.recv(n-len(b))
  if not x:raise RuntimeError('EOF')
  b+=x
 return b
r=read(struct.unpack('!I',read(4))[0]);print(json.dumps({'ok':r[4]==0,'body':json.loads(r[5:])}))
"""
        proc=subprocess.Popen(['/usr/bin/setpriv',f'--reuid={u}',f'--regid={u}','--clear-groups',sys.executable,'-c',script,str(d.control),wire().hex()],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            h.check(proc.stdout.readline().strip()=='READY','real partial kernel principal request')
            revoked_class=candidate(h,revoked,'removed-class','owners-g4',lambda t:'\n'.join(x.replace(f'local_control={u},SOURCE_DISCLOSE',f'local_control={u},INSPECT') for x in t.splitlines() if not x.startswith('source_disclosure=keep,'))+'\n')
            activate(h,'remove-class',a,revoked_class);out,err=proc.communicate('\n',timeout=10);answer=json.loads(out.splitlines()[-1])
            h.check(proc.returncode==0 and not answer['ok'] and answer['body']['code']=='LOCAL_CONTROL_CLASS_DENIED','current post-decode authority required')
        finally:
            if proc.poll() is None:proc.kill();proc.wait()
        restore_owner_only_control(a);save(h,'PRINCIPALS',{'one':query1,'two':query2,'removed_grant':retained,'revoked_key':keygone,'slow_denial':answer});d.shutdown()
    case('real_uid_isolation_historical_grants_and_live_revocation',principals)

    def reconciliation():
        a,c,pa,pc,d,cd,old,source=late(h,'inventory-reconcile',lost=True)
        first=query(h,'late-receipt-terminal',a);row=first['records'][0]
        h.check(row['lifecycle']=='RETIRED' and row['lease_state']=='WITHDRAWN' and row['head']['receipt'] is not None and row['acknowledged']==0,'actual late receipt separate from terminal source frontier')
        done=reconcile(h,'inventory-reconcile-commit',a,old);after=query(h,'reconciled',a)
        h.check(after['records'][0]['termination']==row['termination'] and after['records'][0]['acknowledged']==1 and after['records'][0]['reconciliation']['receipt_digest']==old['head_receipt']['digest'],'reconciliation observed without rewriting original withdrawal')
        h.check(query(h,'reconcile-stale',a,selection=first['selection_digest'],expected=3)['code']=='SUBSCRIPTION_INVENTORY_SELECTION_MISMATCH','reconciliation invalidates prior selection')
        pa2=add_grant(h,pa,a,'inventory-successor');preceding=query(h,'before-adoption',a,grant='g1')
        successor=succeed(h,'inventory-succeed',a,done);adopted=query(h,'adopted',a)
        by={r['grant']:r for r in adopted['records']}
        h.check(by['g1']['adopted_by']['instance']==successor['instance'] and by['g2']['inherited_acknowledged']==1 and by['g2']['issued']==0,'verified predecessor mapping without allowance refund')
        h.check(query(h,'adoption-stale',a,grant='g1',selection=preceding['selection_digest'],expected=3)['code']=='SUBSCRIPTION_INVENTORY_SELECTION_MISMATCH','adoption changes predecessor summary even without preceding revision mutation')
        author(h,'inventory-successor-source',a,parent=source,value='corrected')
        issued=local(h,'inventory-successor-issue',a,'step',grant='g2',previous=successor);received(h,'inventory-successor-receipt',a,issued)
        final=query(h,'successor-delivered',a,grant='g2');h.check(final['records'][0]['acknowledged_source_position']==2,'absolute inherited frontier plus this grant receipts')
        save(h,'SUCCESSION',{'late':first,'reconciled':after,'adopted':adopted,'continued':final});d.shutdown();cd.shutdown()
    case('late_receipt_reconciliation_succession_and_correction_frontier',reconciliation)

    def capacity():
        a=h.runtime/'capacity';uids=[os.geteuid(),65534,65533,65532];rules=[]
        for u in uids:
            for i in range(16):rules.append(f'u{u}-g{i:02},{u},{os.geteuid()},C,c-g1,{SCOPE},8,10000')
        cfg=config(h,'capacity',a,ports={'C':free_port()},rules=rules)
        cfg.write_text(cfg.read_text()+''.join(f'local_control={u},SOURCE_DISCLOSE\n' for u in uids[1:]));d=h.start('capacity',cfg,a);expose_control_for_uid(a)
        for u in uids:
            for i in range(16):
                g=f'u{u}-g{i:02}';x=command(h,'create-'+g,a,'create',grant=g,uid=u if u else None)
                if i%2==0:command(h,'retire-'+g,a,'retire',grant=g,previous=x,uid=u if u else None)
            if u==uids[0]:own_before=query(h,'before-hidden-creation',a)
        h.check(query(h,'hidden-capacity-unchanged',a,selection=own_before['selection_digest'])['records']==own_before['records'],'other manager population does not enter selection')
        allaccounts=[]
        for u in uids:
            page=query(h,'capacity-first-'+str(u),a,uid=u if u else None,limit=5,max_bytes=60000);first=page;rows=list(page['records']);pages=1
            while page['has_more']:
                page=query(h,f'capacity-next-{u}-{pages}',a,uid=u if u else None,offset=page['next_offset'],selection=first['selection_digest'],limit=5,max_bytes=60000);rows+=page['records'];pages+=1
            h.check(len(rows)==16 and len({r['instance'] for r in rows})==16 and sum(r['lifecycle']=='RETIRED' for r in rows)==8,'complete retained owner capacity')
            h.check([r['ordinal'] for r in rows]==list(range(1,17)) and [r['grant'] for r in rows]==sorted(r['grant'] for r in rows),'no hidden ordinal gaps')
            h.check(root_for(first,rows)==first['selection_digest'],'independent capacity commitment')
            allaccounts.append({'uid':u,'pages':pages,'first':first,'last':page})
        restore_owner_only_control(a);h.run('capacity-compact',['compact','--control',str(d.control)]);d.shutdown();d=h.start('capacity-restart',cfg,a)
        restored=query(h,'capacity-reconstructed',a,selection=own_before['selection_digest']);h.check(restored['records']==own_before['records'],'index-free metadata reconstructed from compact state')
        save(h,'CAPACITY',{'retained_global':64,'per_manager':16,'owners':allaccounts,'reconstructed':restored});d.shutdown()
    case('complete_64_instance_registry_four_real_managers',capacity)

    def maintenance():
        a,c=h.runtime/'maint-a',h.runtime/'maint-c';cp=free_port();cfg=config(h,'maint',a,ports={'C':cp});cc=peer_config(h,'maint-c','C',c,cp,inbound=['A'])
        d=h.start('maint',cfg,a);cd=h.start('maint-c',cc,c)
        original=author(h,'maint-source',a,value='retained');created=command(h,'maint-create',a,'create');issued=command(h,'maint-issue',a,'step',previous=created);done=ack(h,'maint-ack',a,issued)
        first=query(h,'maint-inventory',a);h.run('maint-quiesce',['quiesce','--control',str(d.control),'--reason','read-only lifecycle'])
        journal=(a/'state.journal').read_bytes();quiet=query(h,'quiesced-inventory',a,selection=first['selection_digest']);h.check(journal==(a/'state.journal').read_bytes(),'quiesced inventory is observational')
        h.run('maint-resume',['resume','--control',str(d.control),'--reason','continue']);d.shutdown()
        key=new_key(h,h.work,'inventory-auth-g1');migrate(h,'inventory-migrate',a,key);d=start_keyed(h,'maint-keyed',cfg,a,key)
        h.run('inventory-compact',['compact','--control',str(d.control)]);h.check(query(h,'same-process-compact',a,selection=first['selection_digest'])['records']==first['records'],'compaction not inventory mutation');d.shutdown()
        before=inspect(h,'inventory-pre-backup',a,key);h.run('inventory-audit',['state-auth-audit','--state',str(a),'--node','A','--state-auth-key',str(key)])
        crypt=h.work/'inventory-backup.key';h.run('inventory-crypt-key',['backup-key-init','--output',str(crypt),'--generation','inventory-backup-g1']);identity=h.identity('A');archive=h.work/'inventory.nob'
        h.run('inventory-export',['backup-export','--state',str(a),'--node','A','--generation','a-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'restored-inventory'
        h.run('inventory-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'inventory-restored-inspect',restored,key);h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'exact restore state before restart')
        moved=candidate(h,cfg,'inventory-relocated','inventory-moved-g1',lambda t:t.replace('state='+str(a),'state='+str(restored)))
        h.run('inventory-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','move restored owned state','--state-auth-key',str(key)])
        d=start_keyed(h,'inventory-relocated',moved,restored,key);listed=query(h,'relocated-inventory',restored)
        h.check(listed['records']==first['records'],'historical summaries unchanged under owner-path relocation')
        h.check(query(h,'relocation-reselection',restored,selection=first['selection_digest'],expected=3)['code']=='SUBSCRIPTION_INVENTORY_SELECTION_MISMATCH','new configuration requires fresh selection')
        author(h,'continued-source',restored,parent=original['operation_id'],value='continued');issued2=command(h,'continued-issue',restored,'step',previous=done);ack(h,'continued-ack',restored,issued2)
        cd.shutdown()
        h.run('drain-blocker',['submit','--control',str(d.control),'--node','A','--peer','C','--scope',SCOPE,'--operation',operation('inventory-drain'),'--payload-text','pending during drain'])
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            draining_call=pool.submit(h.run,'inventory-drain',['drain-shutdown','--control',str(d.control),'--drain-deadline-ms','2500','--reason','actual nonempty drain'])
            h.wait('actual draining lifecycle',lambda:h.status('drain-state',restored,logical_digest=False)['lifecycle']['draining'])
            draining=query(h,'during-drain',restored)
            h.check(draining['records'][0]['acknowledged']==2,'history remains inspectable during actual drain')
            h.check(draining_call.result(timeout=8)['deadline_reached'],'pending unrelated obligation is not acknowledged by inventory')
        d.process.wait(timeout=8)
        save(h,'MAINTENANCE',{'before':first,'quiesced':quiet,'relocated':listed,'continued_draining':draining,'restore_digest':after['storage']['logical_state_digest']})
    case('keyed_compaction_encrypted_restore_relocation_and_drain',maintenance)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--binary',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--case',action='append');args=parser.parse_args()
    if args.output.exists():parser.error('output must not exist')
    h=Harness(args.binary,args.output);start=time.time();ok=False
    try:run_cases(h,set(args.case) if args.case else None);ok=True
    except BaseException as exc:
        (h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(f'FAIL: {type(exc).__name__}: {exc}',file=sys.stderr)
    finally:
        h.cleanup();result={'format':'NATRAV_OVERLAY_SUBSCRIPTION_INVENTORY_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(x['status']=='PASS' for x in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,value in [('SUMMARY',result),('CASES',h.cases),('COMMANDS',h.commands)]:save(h,name,value)
        print(json.dumps(result),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
