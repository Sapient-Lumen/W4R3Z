#!/usr/bin/env python3
"""Finite V16 source-subscription leases and authenticated withdrawal."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
from typing import Any

from run_persistent import Harness, free_port, operation
from run_subscriber_requests import provider_config, subscriber_config
from run_local_evidence import author
from run_live_configuration import candidate, activate
from run_subscriber_requests import recipient_record
from run_automatic_source_delivery import automatic, wait_automatic
from run_state_authentication import new_key, migrate, inspect

SCOPE = "query/series"


def leased_provider_config(
    h: Harness,
    name: str,
    state: Path,
    provider_port: int,
    subscriber_route_port: int,
    *,
    lease_generation: str = "lease-g1",
    duration_ms: int = 60_000,
    policy: str = "RETAIN",
    maximum_records: int = 8,
    maximum_bytes: int = 10_000,
    extra_inbound: list[str] | None = None,
) -> Path:
    path = provider_config(
        h, name, state, provider_port, subscriber_route_port,
        extra_inbound=extra_inbound,
        maximum_records=maximum_records,
        maximum_bytes=maximum_bytes,
    )
    lines: list[str] = []
    for line in path.read_text().splitlines():
        if line == "NATRAV_OVERLAY_CONFIG_V15":
            line = "NATRAV_OVERLAY_CONFIG_V16"
        elif line.startswith("source_disclosure="):
            line += f",{lease_generation},{duration_ms},{policy}"
        lines.append(line)
    path.write_text("\n".join(lines) + "\n")
    path.chmod(0o600)
    return path


def remote(
    h: Harness,
    label: str,
    config: Path,
    command: str,
    request_id: str,
    *,
    lease: str = "lease-g1",
    instance: str | None = None,
    revision: int | None = None,
    reason: str = "finite lease command",
    provider: str = "A",
    grant: str = "g1",
    expected: int = 0,
    timeout: float = 10.0,
) -> dict[str, Any]:
    args = [f"source-subscription-{command}", "--config", str(config),
            "--provider", provider, "--grant", grant,
            "--request-id", request_id, "--lease-generation", lease,
            "--deadline-ms", "5000"]
    if command == "request":
        args += ["--reason", reason]
    elif command == "withdraw":
        assert instance is not None and revision is not None
        args += ["--instance", instance, "--expected-revision", str(revision),
                 "--reason", reason]
    result = h.run(label, args, expected=expected, timeout=timeout)
    assert result is not None
    if expected == 0:
        h.check(result["format"] == "NATRAV_OVERLAY_REMOTE_SOURCE_SUBSCRIPTION_RESPONSE_V2",
                "leased remote response uses explicit V2 format")
    return result


def local(
    h: Harness,
    label: str,
    state: Path,
    command: str,
    *,
    previous: dict[str, Any] | None = None,
    grant: str = "g1",
    expected: int = 0,
) -> dict[str, Any]:
    args = [f"source-subscription-{command}", "--control", str(state / "control.sock"),
            "--grant", grant, "--deadline-ms", "5000"]
    if command == "step":
        assert previous is not None
        args += ["--instance", previous["instance"],
                 "--expected-revision", str(previous["revision"])]
    result = h.run(label, args, expected=expected)
    assert result is not None
    if expected == 0:
        h.check(result["format"] == "NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_V2",
                "leased provider state uses explicit V2 format")
    return result


def wait_local(h: Harness, label: str, state: Path, predicate: Any,
               timeout: float = 10.0) -> dict[str, Any]:
    latest: dict[str, Any] = {}
    def ready() -> bool:
        nonlocal latest
        latest = local(h, label + "-poll", state, "status")
        return bool(predicate(latest))
    h.wait(label, ready, timeout)
    return latest


def run_cases(h: Harness, selected: set[str] | None = None) -> None:
    def case(name: str, function: Any) -> None:
        if selected is None or name in selected:
            h.case(name, function)

    def strict_configuration() -> None:
        a = h.runtime / "config-a"
        ap, cp = free_port(), free_port()
        valid = leased_provider_config(h, "config-valid", a, ap, cp)
        checked = h.run("config-v16-valid", ["config-check", "--config", str(valid)])
        assert checked is not None
        h.check(checked["format"] == "NATRAV_OVERLAY_CONFIG_V16" and
                checked["source_disclosure_policy"]["format"] ==
                    "NATRAV_OVERLAY_SOURCE_DISCLOSURE_POLICY_V2",
                "V16 exposes finite lease policy")

        def altered(name: str, transform: Any, code: str) -> None:
            path = h.work / f"{name}.conf"
            path.write_text(transform(valid.read_text())); path.chmod(0o600)
            result = h.run(name, ["config-check", "--config", str(path)], expected=3)
            assert result is not None
            h.check(result["code"] == code, f"strict lease configuration rejects {name}")

        altered("config-v15-extra-fields",
                lambda text: text.replace("CONFIG_V16", "CONFIG_V15", 1),
                "SOURCE_DISCLOSURE_INVALID")
        altered("config-v16-missing-fields",
                lambda text: "\n".join(
                    line.rsplit(",", 3)[0] if line.startswith("source_disclosure=") else line
                    for line in text.splitlines()) + "\n",
                "SOURCE_DISCLOSURE_INVALID")
        altered("config-short-lease",
                lambda text: text.replace(",60000,RETAIN", ",99,RETAIN"),
                "INVALID_ARGUMENT")
        altered("config-invalid-policy",
                lambda text: text.replace(",60000,RETAIN", ",60000,RECALL"),
                "SOURCE_DISCLOSURE_INVALID")
        altered("config-duplicate-lease",
                lambda text: text + text.split("source_disclosure=", 1)[1].splitlines()[0]
                    .replace("g1,", "g2,", 1).join(("source_disclosure=", "\n")),
                "SOURCE_DISCLOSURE_DUPLICATE")
    case("strict_v16_lease_configuration", strict_configuration)

    def authenticated_withdrawal() -> None:
        a, c, d = (h.runtime / name for name in ("auth-a", "auth-c", "auth-d"))
        ap, cp, dp = free_port(), free_port(), free_port()
        pa = leased_provider_config(h, "auth-a", a, ap, cp, extra_inbound=["D"])
        pc = subscriber_config(h, "auth-c", c, "C", cp, ap)
        pd = subscriber_config(h, "auth-d", d, "D", dp, ap)
        ad = h.start("auth-a", pa, a); cd = h.start("auth-c", pc, c); dd = h.start("auth-d", pd, d)
        wrong = remote(h, "auth-wrong-peer", pd, "request", operation("auth-wrong-peer"), expected=3)
        h.check(wrong["code"] == "SOURCE_SUBSCRIPTION_REMOTE_DENIED",
                "another authenticated peer cannot claim the lease")
        wrong_lease = remote(h, "auth-wrong-lease", pc, "request", operation("auth-wrong-lease"),
                             lease="lease-other", expected=3)
        h.check(wrong_lease["code"] == "SOURCE_SUBSCRIPTION_LEASE_GENERATION_MISMATCH",
                "request must select exact lease generation")
        request_id = operation("auth-request")
        accepted = remote(h, "auth-request", pc, "request", request_id,
                          reason="subscriber adopts finite lease")
        h.check(accepted["disposition"] == "ACCEPTED" and accepted["state"] == "ACTIVE" and
                accepted["lease_generation"] == "lease-g1" and
                accepted["lease_expires_unix_ms"] > accepted["accepted_unix_ms"],
                "exact authenticated subscriber receives finite lease")
        conflict = remote(h, "auth-withdraw-wrong-revision", pc, "withdraw",
                          operation("auth-withdraw-wrong-revision"), instance=accepted["instance"],
                          revision=accepted["revision"] + 1, expected=3)
        h.check(conflict["code"] == "SOURCE_SUBSCRIPTION_WITHDRAWAL_CONFLICT",
                "withdrawal selects exact revision")
        withdraw_id = operation("auth-withdraw")
        withdrawn = remote(h, "auth-withdraw", pc, "withdraw", withdraw_id,
                           instance=accepted["instance"], revision=accepted["revision"],
                           reason="subscriber no longer wants future source selection")
        h.check(withdrawn["disposition"] == "WITHDRAWN" and withdrawn["state"] == "RETIRED" and
                withdrawn["terminal_kind"] == "WITHDRAWN" and
                withdrawn["terminal_pending_disposition"] == "NONE",
                "authenticated withdrawal creates terminal account")
        again = remote(h, "auth-withdraw-retry", pc, "withdraw", withdraw_id,
                       instance=accepted["instance"], revision=accepted["revision"],
                       reason="subscriber no longer wants future source selection")
        h.check(again["disposition"] == "ALREADY_WITHDRAWN" and
                again["revision"] == withdrawn["revision"],
                "exact withdrawal retry is idempotent")
        ad.shutdown(); cd.shutdown(); dd.shutdown()
    case("authenticated_exact_withdrawal", authenticated_withdrawal)

    def pending_cancel() -> None:
        a, c = h.runtime / "cancel-a", h.runtime / "cancel-c"
        ap, cp, dead = free_port(), free_port(), free_port()
        pa = leased_provider_config(h, "cancel-a", a, ap, dead,
                                    lease_generation="lease-cancel", policy="CANCEL")
        pc = subscriber_config(h, "cancel-c", c, "C", cp, ap)
        ad = h.start("cancel-a", pa, a); cd = h.start("cancel-c", pc, c)
        accepted = remote(h, "cancel-request", pc, "request", operation("cancel-request"),
                          lease="lease-cancel", reason="finite cancel lease")
        author(h, "cancel-source", a, value="pending source")
        issued = local(h, "cancel-issue", a, "step", previous=local(h, "cancel-status", a, "status"))
        h.check(issued["delivery_status"] == "PENDING" and issued["issued"] == 1,
                "unreachable route leaves exact pending source")
        withdrawn = remote(h, "cancel-withdraw", pc, "withdraw", operation("cancel-withdraw"),
                           lease="lease-cancel", instance=accepted["instance"],
                           revision=issued["revision"], reason="withdraw and cancel exact pending head")
        h.check(withdrawn["terminal_pending_disposition"] == "CANCEL" and
                withdrawn["terminal_cancelled_operation"] == issued["latest"]["operation_id"],
                "withdrawal atomically binds exact pending cancellation")
        state = local(h, "cancel-final", a, "status")
        h.check(state["state"] == "RETIRED" and state["delivery_status"] == "CANCELLED" and
                state["termination"]["actor_peer"] == "C" and
                state["termination"]["request_id"] == operation("cancel-withdraw"),
                "cancelled outbox and authenticated terminal actor reconstruct together")
        ad.shutdown(); cd.shutdown()
    case("pending_cancel_commits_with_withdrawal", pending_cancel)

    def pending_retain() -> None:
        a, c = h.runtime / "retain-a", h.runtime / "retain-c"
        ap, cp, dead = free_port(), free_port(), free_port()
        pa = leased_provider_config(h, "retain-a", a, ap, dead,
                                    lease_generation="lease-retain", policy="RETAIN")
        pc = subscriber_config(h, "retain-c", c, "C", cp, ap)
        ad = h.start("retain-a", pa, a); cd = h.start("retain-c", pc, c)
        accepted = remote(h, "retain-request", pc, "request", operation("retain-request"),
                          lease="lease-retain")
        author(h, "retain-source", a, value="retained pending source")
        issued = local(h, "retain-issue", a, "step", previous=local(h, "retain-status", a, "status"))
        withdrawn = remote(h, "retain-withdraw", pc, "withdraw", operation("retain-withdraw"),
                           lease="lease-retain", instance=accepted["instance"],
                           revision=issued["revision"], reason="stop selection but retain queued bytes")
        h.check(withdrawn["terminal_pending_disposition"] == "RETAIN" and
                withdrawn["terminal_cancelled_operation"] is None,
                "retain policy does not fabricate cancellation")
        live = candidate(h, pa, "retain-live-route", "retain-live-route-g1",
                         lambda text: text.replace(f"127.0.0.1:{dead}", f"127.0.0.1:{cp}"))
        activate(h, "retain-activate-route", a, live)
        h.wait("retained outbox delivers after terminal withdrawal",
               lambda: h.status("retain-recipient-poll", c)["inbound_records"] == 1, 12.0)
        final = local(h, "retain-final", a, "status")
        h.check(final["state"] == "RETIRED" and final["delivery_status"] == "ACKED" and
                final["acknowledged"] == 0,
                "ordinary outbox may deliver retained bytes without advancing retired frontier")
        decoded = recipient_record(h, "retain-recipient-record", c, issued)
        h.check(decoded["source_operation"] == issued["latest"]["source_operation"],
                "retained pending operation is admitted once with original source mapping")
        ad.shutdown(); cd.shutdown()
    case("pending_retain_survives_terminal_withdrawal", pending_retain)

    def expiry_and_automation() -> None:
        a, c = h.runtime / "expiry-a", h.runtime / "expiry-c"
        ap, cp = free_port(), free_port()
        pa = leased_provider_config(h, "expiry-a", a, ap, cp,
                                    lease_generation="lease-short", duration_ms=300,
                                    policy="RETAIN")
        pc = subscriber_config(h, "expiry-c", c, "C", cp, ap)
        ad = h.start("expiry-a", pa, a); cd = h.start("expiry-c", pc, c)
        accepted = remote(h, "expiry-request", pc, "request", operation("expiry-request"),
                          lease="lease-short")
        provider = local(h, "expiry-provider", a, "status")
        enabled = automatic(h, "expiry-enable", a, "enable", previous=provider,
                            maximum=4, interval=10)
        h.check(enabled["automatic_current"]["state"] == "ENABLED",
                "finite automatic grant starts before lease expiry")
        time.sleep(0.45)
        expired = remote(h, "expiry-remote-status", pc, "remote-status",
                         operation("expiry-status"), lease="lease-short")
        h.check(expired["state"] == "RETIRED" and expired["disposition"] == "STATUS" and
                expired["terminal_kind"] == "EXPIRED",
                "remote status observes and durably commits natural expiry")
        final = local(h, "expiry-final", a, "status")
        h.check(final["termination"]["kind"] == "EXPIRED" and
                final["automatic_current"]["state"] == "RETIRED" and
                final["automatic_current"]["error"] == "SOURCE_SUBSCRIPTION_LEASE_EXPIRED",
                "expiry and automatic-grant termination commit together")
        author(h, "expiry-late-source", a, value="must remain undisclosed")
        time.sleep(0.25)
        unchanged = local(h, "expiry-unchanged", a, "status")
        h.check(unchanged["issued"] == 0 and h.status("expiry-recipient", c)["inbound_records"] == 0,
                "expired lease cannot select later sources")
        ad.shutdown(); cd.shutdown()
    case("natural_expiry_stops_automation", expiry_and_automation)

    def withdrawal_kill_boundaries() -> None:
        def run_boundary(label: str, hook: str, expect_retired: bool) -> None:
            a, c = h.runtime / f"kill-{label}-a", h.runtime / f"kill-{label}-c"
            ap, cp = free_port(), free_port()
            pa = leased_provider_config(h, f"kill-{label}-a", a, ap, cp,
                                        lease_generation=f"lease-{label}")
            pc = subscriber_config(h, f"kill-{label}-c", c, "C", cp, ap)
            ad = h.start(f"kill-{label}-a", pa, a, {hook: "5000"})
            cd = h.start(f"kill-{label}-c", pc, c)
            accepted = remote(h, f"kill-{label}-request", pc, "request",
                              operation(f"kill-{label}-request"), lease=f"lease-{label}")
            request_id = operation(f"kill-{label}-withdraw")
            args = [str(h.binary), "source-subscription-withdraw", "--config", str(pc),
                    "--provider", "A", "--grant", "g1", "--request-id", request_id,
                    "--lease-generation", f"lease-{label}", "--instance", accepted["instance"],
                    "--expected-revision", str(accepted["revision"]), "--reason", f"kill {label}",
                    "--deadline-ms", "10000"]
            client = subprocess.Popen(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            time.sleep(0.35)
            ad.kill()
            try:
                client.communicate(timeout=3)
            except subprocess.TimeoutExpired:
                client.kill(); client.communicate(timeout=3)
            ad = h.start(f"kill-{label}-restart", pa, a)
            observed = local(h, f"kill-{label}-status", a, "status")
            h.check((observed["state"] == "RETIRED") == expect_retired,
                    f"{label} synchronization boundary reconstructs exact terminal state")
            if expect_retired:
                h.check(observed["termination"]["request_id"] == request_id,
                        "post-commit kill retains authenticated withdrawal request")
                retry = remote(h, f"kill-{label}-retry", pc, "withdraw", request_id,
                               lease=f"lease-{label}", instance=accepted["instance"],
                               revision=accepted["revision"], reason=f"kill {label}")
                h.check(retry["disposition"] == "ALREADY_WITHDRAWN",
                        "post-commit lost response recovers idempotently")
            else:
                retry = remote(h, f"kill-{label}-retry", pc, "withdraw", request_id,
                               lease=f"lease-{label}", instance=accepted["instance"],
                               revision=accepted["revision"], reason=f"kill {label}")
                h.check(retry["disposition"] == "WITHDRAWN",
                        "pre-commit kill leaves withdrawal available exactly once")
            ad.shutdown(); cd.shutdown()

        run_boundary("before", "NATRAV_OVERLAY_TEST_REMOTE_SOURCE_WITHDRAW_BEFORE_COMMIT_MS", False)
        run_boundary("after", "NATRAV_OVERLAY_TEST_REMOTE_SOURCE_WITHDRAW_AFTER_COMMIT_MS", True)
    case("withdrawal_pre_and_post_commit_kills", withdrawal_kill_boundaries)

    def authenticated_compaction_restart() -> None:
        a, c = h.runtime / "maintenance-a", h.runtime / "maintenance-c"
        ap, cp = free_port(), free_port()
        pa = leased_provider_config(h, "maintenance-a", a, ap, cp,
                                    lease_generation="lease-maintenance", policy="CANCEL")
        pc = subscriber_config(h, "maintenance-c", c, "C", cp, ap)
        ad = h.start("maintenance-a", pa, a); cd = h.start("maintenance-c", pc, c)
        accepted = remote(h, "maintenance-request", pc, "request", operation("maintenance-request"),
                          lease="lease-maintenance")
        withdrawn = remote(h, "maintenance-withdraw", pc, "withdraw",
                           operation("maintenance-withdraw"), lease="lease-maintenance",
                           instance=accepted["instance"], revision=accepted["revision"],
                           reason="preserve terminal lease across maintenance")
        ad.shutdown(); cd.shutdown()
        key_root = h.work / "maintenance-state-key"
        key_root.mkdir(mode=0o700)
        key = new_key(h, key_root, "state-g1")
        migrate(h, "maintenance-migrate", a, key)
        before = inspect(h, "maintenance-before", a, key)
        h.check(before["source_subscriptions"][0]["termination"]["kind"] == "WITHDRAWN",
                "keyed migration retains lease terminal history")
        from run_state_authentication import start as start_keyed
        ad = start_keyed(h, "maintenance-keyed", pa, a, key)
        h.run("maintenance-compact", ["compact", "--control", str(ad.control)])
        ad.shutdown()
        after = inspect(h, "maintenance-after", a, key)
        h.check(before["source_subscriptions"] == after["source_subscriptions"],
                "authenticated compaction preserves exact lease state")

        encryption_root = h.work / "maintenance-backup-key"
        encryption_root.mkdir(mode=0o700)
        encryption = encryption_root / "backup-g1.key"
        h.run("maintenance-backup-key", ["backup-key-init", "--output", str(encryption),
              "--generation", "backup-g1"])
        identity = h.identity("A")
        archive = h.work / "maintenance-lease.nob"
        h.run("maintenance-export", ["backup-export", "--state", str(a), "--node", "A",
              "--generation", "a-g1", "--output", str(archive),
              "--state-auth-key", str(key), "--encrypt-key", str(encryption),
              "--sign-key", str(identity.private_key),
              "--sign-cert", str(identity.certificate)])
        restored = h.runtime / "maintenance-restored"
        h.run("maintenance-restore", ["backup-restore", "--input", str(archive),
              "--destination", str(restored), "--node", "A", "--generation", "a-g1",
              "--state-auth-key", str(key), "--decrypt-key", str(encryption),
              "--trusted-cert", str(identity.certificate), "--require-signature", "yes",
              "--require-encryption", "yes"])
        restored_before = inspect(h, "maintenance-restored-before", restored, key)
        h.check(after["source_subscriptions"] == restored_before["source_subscriptions"],
                "signed encrypted restore retains exact lease state")
        moved = candidate(h, pa, "maintenance-moved", "maintenance-moved-g1",
                          lambda text: text.replace("state=" + str(a),
                                                    "state=" + str(restored)))
        h.run("maintenance-relocate", ["state-relocate", "--state", str(restored),
              "--node", "A", "--candidate", str(moved),
              "--reason", "relocate finite lease state",
              "--state-auth-key", str(key)])
        ad = start_keyed(h, "maintenance-restored", moved, restored, key)
        rebuilt = local(h, "maintenance-live", restored, "status")
        h.check(rebuilt["revision"] == withdrawn["revision"] and
                rebuilt["termination"]["request_id"] == operation("maintenance-withdraw"),
                "restore and relocation reconstruct exact authenticated withdrawal provenance")
        ad.shutdown()
        (h.output / "MAINTENANCE.json").write_text(
            json.dumps(rebuilt, indent=2, sort_keys=True) + "\n")
    case("authenticated_compaction_and_restart", authenticated_compaction_restart)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not already exist")
    h = Harness(args.binary, args.output)
    started = time.time(); ok = False
    try:
        run_cases(h, set(args.case) if args.case else None)
        ok = True
    finally:
        h.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_SUBSCRIPTION_LEASE_TESTS_V1",
            "status": "PASS" if ok else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "cases_total": len(h.cases),
            "cases_passed": sum(c["status"] == "PASS" for c in h.cases),
            "assertions": h.assertions,
            "commands": len(h.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (("SUMMARY", summary), ("CASES", h.cases), ("COMMANDS", h.commands)):
            (h.output / (name + ".json")).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary), flush=True)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
