#!/usr/bin/env python3
"""V20 key policy through real authority, offline capsules, commit loss and replay."""
from __future__ import annotations
import argparse, hashlib, json, os, signal, subprocess, sys, time
from pathlib import Path
from run_persistent import Harness, free_port, operation
from run_peer_sessions import submit
from run_live_configuration import candidate, activate, rollback
from run_local_administration import expose_control_for_uid, restore_owner_only_control, run_as_uid
from run_runtime_adapter_configuration import upgrade, write
from run_maintenance import inspect, compact
from run_handoff_capsule import independent_open, independent_seal, private_file

ZERO='0'*64

def immutable(binding: bytes, sequence=1, previous=ZERO) -> str:
    return f'NATRAV_HANDOFF_KEY_COMMITMENT_V1\nsequence={sequence}\npredecessor_sha256={previous}\nbinding_hex={binding.hex()}\n'

def commitment(binding: bytes, sequence=1, previous=ZERO) -> str:
    return hashlib.sha256(immutable(binding,sequence,previous).encode('ascii')).hexdigest()

def record(binding: bytes, sequence=1, previous=ZERO, state='ACTIVE') -> str:
    return immutable(binding,sequence,previous).replace('COMMITMENT','POLICY')+f'state={state}\n'

def policy_lines(records) -> str:
    return ''.join('handoff_key_hex='+r.encode('ascii').hex()+'\n' for r in records)

def replace_policy(text, records):
    return '\n'.join(l for l in text.splitlines() if not l.startswith('handoff_key_hex='))+'\n'+policy_lines(records)

def suite(h, baseline=None, sanitize_probe=False):
    root=Path(__file__).resolve().parents[2];h.work.chmod(0o700);s={}
    def native():
        flags=['-D_GNU_SOURCE','-std=c++20','-O1','-g0','-Wall','-Wextra','-Wpedantic','-Wconversion','-Wsign-conversion','-Wshadow','-Wformat=2','-Werror','-pthread']
        if sanitize_probe:flags+=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie']
        sources=['node/tests/handoff_policy_probe.cpp','node/src/handoff_policy.cpp','node/src/handoff_capsule.cpp','node/src/common.cpp','node/src/protocol.cpp']
        sources += ['foundation/src/'+n for n in ['core.cpp','natrav_peer_session.cpp','natrav_peer_stream.cpp','natrav_peer_message.cpp','natrav_peer_handshake.cpp']]
        cmd=['g++',*flags,'-I'+str(root/'foundation/include'),'-I'+str(root/'node/src'),*[str(root/p) for p in sources],'-lssl','-lcrypto','-lz','-lzstd','-o',str(h.work/'probe')]
        (h.logs/'native-command.json').write_text(json.dumps(cmd,indent=2))
        r=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
        (h.logs/'native-compile.stdout').write_text(r.stdout);(h.logs/'native-compile.stderr').write_text(r.stderr)
        h.check(r.returncode==0,r.stderr)
        r=subprocess.run([str(h.work/'probe')],capture_output=True,text=True,timeout=60)
        (h.logs/'native.stdout').write_text(r.stdout);(h.logs/'native.stderr').write_text(r.stderr)
        h.check(r.returncode==0,r.stderr);report=json.loads(r.stdout);h.check(report['status']=='PASS','native policy model')
        h.assertions+=report['assertions']
    h.case('native_canonical_history_bounds_and_uses',native)
    def setup():
        version=h.run('version',['version'])
        h.check(version['version']=='0613' and version['handoff_key_policy']=='V20_DURABLE_HANDOFF_KEY_POLICY_V1','current capability')
        for node,peer in [('a','b'),('b','a')]:
            st=h.runtime/node
            seed=h.config(node,node.upper(),st,free_port(),[(peer.upper(),free_port(),200,400,1000,900000)])
            write(seed,upgrade(seed.read_text(),node+'-seed',19)+f'local_control=65534,INSPECT\n')
            d=h.start(node,seed,st)
            if node=='a':
                for label,scope in [('late','test/three'),('new','test/three'),('denied','test/forbidden')]:
                    op=operation('v20-'+label);s[label]=op
                    submit(h,'queue-'+label,d.control,'A','B',scope,op,'v20-'+label)
            d.shutdown();s[node+'seed']=seed;s[node+'state']=st
            for num in (1,2,3):
                key=h.work/f'{node}-key-{num}'
                r=h.run(f'init-{node}-{num}',['handoff-key-init','--config',str(seed),'--key-directory',str(key),'--generation',f'{node}-h{num}'])
                b=(key/'binding.nhkb').read_bytes();h.check(r['binding_sha256']==hashlib.sha256(b).hexdigest(),'exact signed binding')
                s[f'{node}key{num}']=key;s[f'{node}binding{num}']=b
        clone=h.work/'a-key-clone'
        h.run('init-same-label-not-authority',['handoff-key-init','--config',str(s['aseed']),'--key-directory',str(clone),'--generation','a-h1'])
        s['aclone']=(clone/'binding.nhkb').read_bytes()
        s['records1']=[record(s['abinding1']),record(s['bbinding1'])]
    h.case('existing_state_and_external_key_preparation',setup)
    def config_for(node,name,records,original=None):
        return candidate(h,original or s[node+'seed'],node+'-'+name,node+'-'+name,
                         lambda t:replace_policy(t.replace('CONFIG_V19','CONFIG_V20'),records))
    def canonical():
        cfg=config_for('a','public-only',s['records1'])
        c=h.run('canonical-policy',['config-check','--config',str(cfg)])
        view=c['handoff_key_policy']['records'];h.check(len(view)==2,'two exact commitments')
        h.check(view[0]['commitment_sha256']==commitment(s['abinding1']),'independent commitment encoding')
        h.check(view[1]['binding_sha256']==hashlib.sha256(s['bbinding1']).hexdigest(),'exact recipient commitment')
        reverse=config_for('a','public-only',list(reversed(s['records1'])))
        h.check(h.run('reordered-policy',['config-check','--config',str(reverse)])['runtime_digest']==c['runtime_digest'],'outer order canonical')
        original=h.config('compat','A',h.runtime/'compat',free_port(),[])
        for v in range(6,20):
            cfg=write(h.work/f'compat-{v}.conf',upgrade(original.read_text(),'compat',v))
            r=h.run(f'compat-{v}',['config-check','--config',str(cfg)])
            h.check('handoff_key_policy' not in r,'no added output field in predecessor config')
            if baseline:
                prior=subprocess.run([str(baseline),'config-check','--config',str(cfg)],capture_output=True,text=True,check=True,timeout=10)
                h.check(json.loads(prior.stdout)==r,'exact V6-V19 predecessor canonical JSON and digest')
        variants=[
            ('old-format',s['aseed'].read_text()+policy_lines(s['records1']),'CONFIG_VERSION_REJECTED'),
            ('duplicate',config_for('a','dup',s['records1']+[s['records1'][0]]).read_text(),'CONFIG_HANDOFF_GENERATION_CONFLICT'),
            ('skip',config_for('a','skip',[record(s['abinding2'],2)]).read_text(),'CONFIG_HANDOFF_PREDECESSOR'),
            ('active-conflict',config_for('a','two-active',[*s['records1'],record(s['abinding2'],2,commitment(s['abinding1']))]).read_text(),'CONFIG_HANDOFF_ACTIVE_CONFLICT'),
            ('bad-state',config_for('a','bad-state',[record(s['abinding1'],state='active')]).read_text(),'CONFIG_HANDOFF_STATE'),
            ('trailing',config_for('a','trailing',[s['records1'][0]+'unknown=1\n']).read_text(),'CONFIG_HANDOFF_RECORD_NONCANONICAL')]
        for label,text,code in variants:
            cfg=write(h.work/(label+'.conf'),text)
            h.check(h.run(label,['config-check','--config',str(cfg)],expected=3)['code']==code,label)
    h.case('canonical_public_records_negatives_and_compatibility',canonical)
    def authority():
        h.check(os.geteuid()==0 and Path('/usr/bin/setpriv').exists(),'real UID test requires root/setpriv')
        d=h.start('authority',s['aseed'],s['astate']);expose_control_for_uid(s['astate'])
        c=config_for('a','policy1',s['records1'])
        count=h.status('authority-before',s['astate'])['runtime_configuration']['event_count']
        denied=run_as_uid(h,'uid-denied',65534,65534,['config-activate','--control',str(d.control),'--candidate',str(c),'--reason','denied'],3)
        h.check(denied['code']=='LOCAL_CONTROL_CLASS_DENIED','binding possession is not CONFIGURATION authority')
        h.check(h.status('authority-after',s['astate'])['runtime_configuration']['event_count']==count,'unauthorized candidate makes no durable mutation')
        grant=candidate(h,s['aseed'],'admin-grant','admin-grant',lambda t:t.replace('local_control=65534,INSPECT','local_control=65534,INSPECT,CONFIGURATION'))
        activate(h,'owner-grants-admin',s['astate'],grant)
        c=config_for('a','policy1',s['records1'],grant)
        allowed=run_as_uid(h,'uid-authorized',65534,65534,['config-activate','--control',str(d.control),'--candidate',str(c),'--reason','authorized','--deadline-ms','10000'],0)
        h.check(allowed['ok'],'existing delegated CONFIGURATION authority commits policy')
        s['apolicy1']=c
        redefine=config_for('a','redefine',[record(s['aclone']),record(s['bbinding1'])],c)
        activate(h,'reject-signed-redefinition',s['astate'],redefine,3,'CONFIG_HANDOFF_GENERATION_CONFLICT')
        h.check(h.status('after-redefinition-rejection',s['astate'])['runtime_configuration']['generation']=='a-policy1','new signed file cannot redefine accepted generation')
        restore_owner_only_control(s['astate']);d.shutdown()
        d=h.start('b-policy',s['bseed'],s['bstate']);c=config_for('b','policy1',s['records1'])
        activate(h,'b-owner-policy',s['bstate'],c);s['bpolicy1']=c;d.shutdown()
    h.case('real_kernel_uid_and_existing_configuration_authority',authority)
    def export(node,keynum,peer,peernum,op,path,kind='operation'):
        b=s[f'{peer}key{peernum}']/'binding.nhkb'
        return ['handoff-export','--config',str(s[node+'seed']),'--key-directory',str(s[f'{node}key{keynum}']),
                '--recipient-binding',str(b),'--recipient-binding-sha256',hashlib.sha256(b.read_bytes()).hexdigest(),
                '--operation-id',op,'--kind',kind,'--expires-ms',str(int(time.time()*1000)+300000),'--output',str(path)]
    def imp(node,keynum,path):
        return ['handoff-import','--config',str(s[node+'seed']),'--key-directory',str(s[f'{node}key{keynum}']),'--input',str(path)]
    def lifecycle():
        for label,args in [('uncommitted-local',export('a',2,'b',1,s['late'],h.work/'bad1')),
                           ('uncommitted-peer',export('a',1,'b',2,s['late'],h.work/'bad2'))]:
            h.check(h.run(label,args,expected=3)['code']=='HANDOFF_KEY_NOT_COMMITTED','exact generation must be committed')
        old=h.work/'old-operation.nhcp';denied=h.work/'denied.nhcp'
        before=inspect(h,'before-export',s['astate'],'A')['outbox']
        h.run('export-old',export('a',1,'b',1,s['late'],old));h.run('export-denied',export('a',1,'b',1,s['denied'],denied))
        h.check(inspect(h,'after-export',s['astate'],'A')['outbox']==before,'export leaves durable attempts and receipts unchanged')
        s['old']=old
        s['records2']=[record(s['abinding1'],state='RETIRED'),record(s['abinding2'],2,commitment(s['abinding1'])),
                       record(s['bbinding1'],state='RETIRED'),record(s['bbinding2'],2,commitment(s['bbinding1']))]
        for node in ('a','b'):
            d=h.start(node+'-rotate',s[node+'seed'],s[node+'state'])
            c=config_for(node,'policy2',s['records2'],s[node+'policy1']);activate(h,node+'-accept-successor',s[node+'state'],c)
            h.check(h.run(node+'-successor-check',['config-check','--config',str(c)])['handoff_key_policy']['records'][1]['predecessor_sha256']==commitment(s['abinding1']),'predecessor survives explicit retirement')
            rollback(h,node+'-reject-reactivation',s[node+'state'],node+'-policy1',3,'CONFIG_HANDOFF_STATE_ROLLBACK')
            d.shutdown();s[node+'policy2']=c
        h.check(h.run('retired-origin-export',export('a',1,'b',2,s['new'],h.work/'retired-origin'),expected=3)['code']=='HANDOFF_KEY_RETIRED','no new origin export with retired key')
        h.check(h.run('retired-recipient-export',export('a',2,'b',1,s['new'],h.work/'retired-peer'),expected=3)['code']=='HANDOFF_KEY_RETIRED','no new export to retired recipient')
        r=h.run('delayed-old-import',imp('b',1,old));h.check(r['status']=='COMMITTED','both retired ends allow delayed recovery')
        h.check(h.run('delayed-duplicate',imp('b',1,old))['status']=='DUPLICATE','existing journal suppresses duplicate')
        h.check(h.run('signature-not-permission',imp('b',1,denied),expected=3)['code']=='AUTHORIZATION_DENIED','valid retained keys do not authorize scope')
        receipt=h.work/'new-key-receipt.nhcp'
        h.run('new-key-receipt-export',export('b',2,'a',2,s['late'],receipt,'receipt'))
        h.check(h.run('new-key-receipt-import',imp('a',2,receipt))['status']=='ACKNOWLEDGED','exact receipt reconciles across authorized handoff-key change')
        s['receipt']=receipt
        new=h.work/'new-operation.nhcp';h.run('new-key-export',export('a',2,'b',2,s['new'],new));s['newfile']=new
        s['payload']=independent_open(old.read_bytes(),s['bkey1'])[0]
    h.case('retirement_delayed_import_and_successor_receipt_recovery',lifecycle)
    def commit_loss():
        records=[r.replace('state=RETIRED','state=REVOKED') if f'binding_hex={s["bbinding1"].hex()}' in r else r for r in s['records2']]
        c=config_for('b','revoked-local',records,s['bpolicy2']);s['brevoked']=c;s['revoked_records']=records
        d=h.start('commit-loss',s['bseed'],s['bstate'],{'NATRAV_OVERLAY_TEST_CONFIG_AFTER_COMMIT_MS':'60000'})
        args=[str(h.binary),'config-activate','--control',str(d.control),'--candidate',str(c),'--reason','lost-response','--deadline-ms','10000']
        with (h.logs/'lost-response.stdout').open('w') as so,(h.logs/'lost-response.stderr').open('w') as se:
            p=subprocess.Popen(args,stdout=so,stderr=se)
            try:
                h.wait('configuration durable boundary',lambda:'NATRAV_OVERLAY_TEST_CONFIG_AFTER_COMMIT_MS' in d.stderr_path.read_text(),15)
                d.kill();p.wait(timeout=15)
                h.check(p.returncode!=0,'caller has no success response despite committed revocation')
            finally:
                if p.poll() is None:p.kill();p.wait(timeout=10)
        d=h.start('stale-seed-after-loss',s['bseed'],s['bstate'])
        h.check(h.status('committed-revocation',s['bstate'])['runtime_configuration']['generation']=='b-revoked-local','replay recovers committed revocation after lost response')
        compact(h,'policy-checkpoint',d.control);d.shutdown()
        h.check(h.run('revoked-old-key-import',imp('b',1,s['old']),expected=3)['code']=='HANDOFF_KEY_REVOKED','old seed cannot undo decryption-key revocation even for duplicate')
        h.check(h.run('active-successor-import',imp('b',2,s['newfile']))['status']=='COMMITTED','current successor unaffected by predecessor revocation')
        d=h.start('checkpoint-stale-seed',s['bseed'],s['bstate'])
        h.check(h.status('checkpoint-policy',s['bstate'])['runtime_configuration']['generation']=='b-revoked-local','checkpoint retains lifecycle')
        rollback(h,'no-reactivation-after-checkpoint',s['bstate'],'b-policy2',3,'CONFIG_HANDOFF_STATE_ROLLBACK')
        rollback(h,'no-version-downgrade',s['bstate'],'b-seed',3,'CONFIG_HANDOFF_DOWNGRADE')
        erase=config_for('b','erase',[],c);activate(h,'no-erasure',s['bstate'],erase,3,'CONFIG_HANDOFF_HISTORY_REMOVED')
        d.shutdown()
    h.case('lost_commit_response_revocation_checkpoint_and_stale_seed',commit_loss)
    def origin_revocation():
        # Independently constructed, signed capsule still needs current retained
        # origin policy; AEAD or signature validity is not revocation authority.
        forged=h.work/'retired-origin-current-recipient.nhcp'
        private_file(forged,independent_seal(s['payload'],s['abinding1'],s['bbinding2'],h.identity('A').private_key))
        h.check(h.run('retired-origin-delayed-allowed',imp('b',2,forged))['status']=='DUPLICATE','retirement is not a creation-time proof')
        records=[r.replace('state=RETIRED','state=REVOKED') if f'binding_hex={s["abinding1"].hex()}' in r else r for r in s['revoked_records']]
        d=h.start('revoke-origin',s['bseed'],s['bstate']);c=config_for('b','revoked-origin',records,s['brevoked'])
        activate(h,'commit-origin-revocation',s['bstate'],c);d.shutdown()
        before=inspect(h,'before-origin-rejection',s['bstate'],'B')['inbound']['count']
        h.check(h.run('revoked-origin-rejected',imp('b',2,forged),expected=3)['code']=='HANDOFF_KEY_REVOKED','cryptographically valid revoked origin rejected')
        h.check(inspect(h,'after-origin-rejection',s['bstate'],'B')['inbound']['count']==before,'rejection makes no application admission')
        # Existing exact receipt remains usable at A, whose currently accepted
        # policy still authorizes both successor bindings.
        h.check(h.run('durable-receipt-idempotence',imp('a',2,s['receipt']))['status']=='DUPLICATE_RECEIPT','no alternate receipt ledger')
    h.case('current_origin_revocation_and_unchanged_receipt_semantics',origin_revocation)

    def empty_policy():
        st=h.runtime/'empty-mode';seed=h.config('empty-mode','A',st,free_port(),[])
        write(seed,upgrade(seed.read_text(),'empty-seed',19));d=h.start('empty-mode',seed,st)
        c=candidate(h,seed,'empty-v20','empty-v20',lambda t:t.replace('CONFIG_V19','CONFIG_V20'))
        activate(h,'accept-empty-v20',st,c)
        rollback(h,'empty-cannot-downgrade',st,'empty-seed',3,'CONFIG_HANDOFF_DOWNGRADE')
        d.kill();d=h.start('empty-stale-restart',seed,st)
        h.check(h.status('empty-replayed',st)['runtime_configuration']['generation']=='empty-v20','empty policy still latches V20 mode')
        d.shutdown()
        args=export('a',1,'b',1,s['late'],h.work/'empty-rejected.nhcp')
        args[args.index('--config')+1]=str(seed)
        h.check(h.run('empty-rejects-uncommitted',args,expected=3)['code']=='HANDOFF_KEY_NOT_COMMITTED','empty policy is deny-all, not signature-only fallback')
    h.case('empty_policy_is_fail_closed_and_irreversible',empty_policy)
    def authenticated_state():
        key=h.work/'state-auth.key'
        h.run('state-auth-key-init',['state-auth-key-init','--output',str(key),'--generation','v20-mac1'])
        h.run('state-auth-migrate',['state-auth-migrate','--state',str(s['astate']),'--node','A','--new-key',str(key),'--reason','v20-authenticated-state'])
        args=imp('a',2,s['receipt'])
        h.run('keyed-state-without-key',args,expected=3)
        h.check(h.run('keyed-policy-replay',args+['--state-auth-key',str(key)])['status']=='DUPLICATE_RECEIPT','same key policy and exact receipt under MAC-authenticated state replay')
    h.case('existing_authenticated_state_boundary',authenticated_state)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--baseline-binary',type=Path);p.add_argument('--sanitize-probe',action='store_true');a=p.parse_args()
    root=Path(__file__).resolve().parents[2]
    if a.output.exists() or root in a.output.resolve().parents:p.error('output must be new and outside source')
    h=Harness(a.binary,a.output);start=time.monotonic();failure=None;status='FAIL'
    try:suite(h,a.baseline_binary,a.sanitize_probe);status='PASS'
    except BaseException as e:
        failure=repr(e);import traceback;traceback.print_exc();(h.output/'FAILURE.txt').write_text(failure+'\n')
    finally:
        h.cleanup();r={'format':'NATRAV_HANDOFF_KEY_POLICY_TEST_V1','status':status,'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            'cases':h.cases,'cases_passed':sum(x['status']=='PASS' for x in h.cases),'cases_total':len(h.cases),'assertions':h.assertions,
            'commands':len(h.commands),'elapsed_seconds':time.monotonic()-start,'failure':failure,'sanitized_native_probe':a.sanitize_probe,'baseline_comparison':a.baseline_binary is not None}
        (h.output/'SUMMARY.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='cases'}))
    return 0 if status=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
