// Exact production binding cardinalities versus an independent retained vector.
#include "delivery_index.hpp"
#include <iostream>
#include <random>
#include <stdexcept>
using namespace natrav_overlay;
int main() {
    std::uint64_t checks=0U;auto check=[&](bool v){++checks;if(!v)throw std::runtime_error("binding cardinality differs from full scan");};
    DeliveryIndex index;std::mt19937_64 rng(536U);
    const std::vector<DeliveryBinding> keys={{"g1","pin1"},{"g2","pin2"},{"revoked","pin3"},{"",""}};
    std::vector<std::optional<DeliveryIndexEntry>> expected(4096U);
    for(std::size_t step=0;step<20000U;++step) {
        const auto i=static_cast<std::size_t>(rng()%expected.size());
        if(step%5U==0U)expected[i].reset();
        else expected[i]=DeliveryIndexEntry{"peer-"+std::to_string(rng()%8U),keys[static_cast<std::size_t>(rng()%keys.size())],rng()%7U!=0U,rng()%3U==0U,rng()%100U,rng()%100U};
        index.touch(i,expected[i]);
        if(step%3U==0U)index.touch(i,expected[i]); // repeat notification cannot double charge
        const auto peer="peer-"+std::to_string(rng()%8U);std::size_t count=0U;
        for(const auto& key:keys){std::size_t bound=0U;for(const auto& entry:expected)if(entry&&entry->peer==peer&&entry->has_policy&&entry->binding==key)++bound;
            check(index.bound_pending(peer,key)==bound);count+=bound;}
        std::size_t total=0U,missing=0U;for(const auto& entry:expected)if(entry&&entry->peer==peer){++total;if(!entry->has_policy)++missing;}
        check(count+missing==total);check(index.pending(peer)==total);
        if(step%200U==0U)check(index.valid());
    }
    check(index.bound_pending("absent",keys[0])==0U);
    for(std::size_t i=0;i<expected.size();++i)index.touch(i,std::nullopt);
    check(index.pending()==0U&&index.valid());
    std::cout<<"{\"status\":\"PASS\",\"checks\":"<<checks<<",\"slots\":4096,\"mutations\":20000,\"reference\":\"independent full scan including exhausted and missing-policy entries\"}\n";
}
