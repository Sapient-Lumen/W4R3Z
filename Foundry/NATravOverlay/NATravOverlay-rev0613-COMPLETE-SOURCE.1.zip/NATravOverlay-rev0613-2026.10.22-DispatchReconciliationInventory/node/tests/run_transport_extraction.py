#!/usr/bin/env python3
"""Bounded TCP transport-boundary and legacy-interoperability regression."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from typing import Any


EXPECTED_FEATURE = "TCP_ORDERED_BYTE_STREAM_BOUNDARY_V1"


def run_command(
    command: list[str],
    *,
    stdout_path: Path,
    stderr_path: Path,
    timeout: float,
    environment: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        timeout=timeout,
        env=environment,
    )
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)
    return completed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    source_root = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    binary = args.binary.resolve(strict=True)
    if output.exists() or output == source_root or source_root in output.parents:
        parser.error("output must be new and outside the source tree")
    output.mkdir(parents=True)

    started = time.monotonic()
    assertions = 0
    commands: list[dict[str, Any]] = []
    cases: list[dict[str, Any]] = []

    def check(condition: bool, detail: str) -> None:
        nonlocal assertions
        assertions += 1
        if not condition:
            raise AssertionError(detail)

    def record_case(name: str, before: int, begin: float) -> None:
        cases.append(
            {
                "name": name,
                "status": "PASS",
                "assertions": assertions - before,
                "elapsed_seconds": time.monotonic() - begin,
            }
        )

    status = "FAIL"
    failure: str | None = None
    try:
        before = assertions
        begin = time.monotonic()
        version_run = run_command(
            [str(binary), "version"],
            stdout_path=output / "version.stdout.txt",
            stderr_path=output / "version.stderr.txt",
            timeout=10,
        )
        commands.append(
            {
                "label": "version",
                "returncode": version_run.returncode,
                "args": ["version"],
            }
        )
        check(version_run.returncode == 0, "version command succeeds")
        version_lines = [line for line in version_run.stdout.splitlines() if line.strip()]
        check(len(version_lines) == 1, "version emits one JSON line")
        version = json.loads(version_lines[0])
        check(version.get("version") == "0613", "revision is 0613")
        check(
            version.get("transport_extraction") == EXPECTED_FEATURE,
            "transport extraction feature marker is exact",
        )
        record_case("revision metadata", before, begin)

        before = assertions
        begin = time.monotonic()
        transport_header = (source_root / "node/src/transport.hpp").read_text()
        transport_source = (source_root / "node/src/transport.cpp").read_text()
        socket_header = (source_root / "node/src/socket.hpp").read_text()
        node_source = (source_root / "node/src/node.cpp").read_text()
        daemon_source = (source_root / "node/src/daemon.cpp").read_text()
        peer_session_source = (source_root / "node/src/peer_session.cpp").read_text()
        build_script = (source_root / "node/build.sh").read_text()
        check("enum class TransportKind" in transport_header, "transport kind is explicit")
        check("class OrderedByteStream" in transport_header, "owned stream boundary exists")
        check("native_tls_handle" not in transport_header + transport_source,
              "ordered stream exposes no native TLS descriptor")
        check("class TransportConnector" in transport_header, "connector interface exists")
        check("class TransportListener" in transport_header, "listener interface exists")
        check("TRANSPORT_KIND_UNSUPPORTED" in transport_source, "unknown kinds fail closed")
        check("src/transport.cpp" in build_script, "product build includes transport implementation")
        check("struct Endpoint" not in socket_header, "legacy endpoint type left socket boundary")
        check("connect_tcp" not in node_source + daemon_source + peer_session_source,
              "peer call sites do not own raw TCP connect")
        check("IPPROTO_TCP" not in node_source + daemon_source + peer_session_source,
              "peer call sites do not configure TCP sockets")
        check("netinet/tcp.h" not in node_source + daemon_source + peer_session_source,
              "peer call sites do not include TCP implementation headers")
        check("OrderedByteStream&" in node_source, "inbound peer path consumes ordered stream")
        check("connect_transport" in peer_session_source, "persistent sessions use connector boundary")
        check("listen_transport" in daemon_source, "daemon uses listener boundary")
        record_case("source ownership boundary", before, begin)

        probe = output / "transport-extraction-probe"
        compile_command = [
            "/usr/bin/g++",
            "-D_GNU_SOURCE",
            "-std=c++20",
            "-O1",
            "-g0",
            "-Wall",
            "-Wextra",
            "-Wpedantic",
            "-Wconversion",
            "-Wsign-conversion",
            "-Wshadow",
            "-Wformat=2",
            "-Werror",
            "-pthread",
            f"-I{source_root / 'foundation/include'}",
            f"-I{source_root / 'node/src'}",
            str(source_root / "node/tests/test_transport_extraction.cpp"),
            str(source_root / "node/src/transport.cpp"),
            str(source_root / "node/src/serial_transport.cpp"),
            str(source_root / "node/src/udp_transport.cpp"),
            str(source_root / "node/src/unix_datagram_transport.cpp"),
            str(source_root / "node/src/finite_packet_link.cpp"),
            str(source_root / "node/src/packet_port.cpp"),
            str(source_root / "node/src/common.cpp"),
            str(source_root / "foundation/src/core.cpp"),
            "-lcrypto",
            "-lz",
            "-lzstd",
            "-ldl",
            "-o",
            str(probe),
        ]
        before = assertions
        begin = time.monotonic()
        compile_run = run_command(
            compile_command,
            stdout_path=output / "probe-build.stdout.txt",
            stderr_path=output / "probe-build.stderr.txt",
            timeout=120,
        )
        commands.append(
            {
                "label": "probe-build",
                "returncode": compile_run.returncode,
                "args": compile_command,
            }
        )
        check(compile_run.returncode == 0, "transport probe compiles with production warnings")
        check(probe.is_file(), "transport probe executable exists")
        record_case("probe build", before, begin)

        before = assertions
        begin = time.monotonic()
        probe_run = run_command(
            [str(probe)],
            stdout_path=output / "probe.stdout.txt",
            stderr_path=output / "probe.stderr.txt",
            timeout=30,
            environment=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
        )
        commands.append(
            {
                "label": "probe",
                "returncode": probe_run.returncode,
                "args": [str(probe)],
            }
        )
        check(probe_run.returncode == 0, "transport probe succeeds")
        probe_lines = [line for line in probe_run.stdout.splitlines() if line.strip()]
        check(len(probe_lines) == 1, "transport probe emits one JSON line")
        probe_result = json.loads(probe_lines[0])
        check(probe_result.get("status") == "PASS", "transport probe reports PASS")
        probe_cases = probe_result.get("cases")
        check(isinstance(probe_cases, list) and len(probe_cases) == 6,
              "transport probe case count is exact")
        check(probe_result.get("assertions") == 65,
              "transport probe assertion count is exact")
        check(
            sum(int(item["assertions"]) for item in probe_cases) == 65,
            "transport probe per-case accounting is exact",
        )
        assertions += int(probe_result["assertions"])
        cases.extend(
            {
                "name": f"transport probe: {item['name']}",
                "status": "PASS",
                "assertions": int(item["assertions"]),
                "elapsed_seconds": 0.0,
            }
            for item in probe_cases
        )
        record_case("probe accounting", before + int(probe_result["assertions"]), begin)
        status = "PASS"
    except BaseException as error:  # preserve bounded evidence on any failure
        failure = f"{type(error).__name__}: {error}"
        cases.append(
            {
                "name": "suite failure",
                "status": "FAIL",
                "assertions": 0,
                "elapsed_seconds": 0.0,
                "detail": failure,
            }
        )

    summary = {
        "format": "NATRAV_TRANSPORT_EXTRACTION_SUITE_V1",
        "status": status,
        "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "cases_passed": sum(item["status"] == "PASS" for item in cases),
        "cases_total": len(cases),
        "assertions": assertions,
        "commands": len(commands),
        "elapsed_seconds": time.monotonic() - started,
        "feature": EXPECTED_FEATURE,
        "cases": cases,
        "command_records": commands,
    }
    if failure is not None:
        summary["failure"] = failure
    (output / "SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps({key: value for key, value in summary.items()
                      if key not in {"cases", "command_records"}}, sort_keys=True), flush=True)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
