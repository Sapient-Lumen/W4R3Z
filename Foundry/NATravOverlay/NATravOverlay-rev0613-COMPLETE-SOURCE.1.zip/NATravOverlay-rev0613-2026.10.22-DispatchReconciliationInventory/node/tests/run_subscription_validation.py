#!/usr/bin/env python3
"""Inductive source-progress validation, exact work, and untrusted replay rejection.

Only disposable owned states and explicitly configured local peers are used.
The full-history and reference builds are test-only comparison executables.
"""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, struct, subprocess, time
from pathlib import Path
from run_persistent import Harness, free_port
from run_source_subscriptions import config, command, ack, journal_frames, Reader, SCOPE
from run_local_evidence import author
from run_evidence_queries import config as peer_config, query
from run_state_authentication import inspect, checksum_frame
from run_live_configuration import candidate, activate


def dump(h: Harness, name: str, value: object) -> None:
    (h.output/(name+'.json')).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')


def source_transaction(frame: bytes) -> bytes:
    assert frame[:4] == b'NOJ1' and frame[8] == 32
    assert int.from_bytes(frame[4:8], 'big') == len(frame) - 40
    return frame[9:-32]


def progress_layout(frame: bytes) -> dict[str, int | str]:
    transaction = source_transaction(frame)
    r = Reader(transaction)
    assert r.get(4) == b'NST3'
    kind = r.number(1)
    assert kind in (1, 2, 3, 4)
    grant = r.text(); r.get(32)
    preceding_revision_offset = r.i; preceding_revision = r.number(8)
    preceding_commitment_offset = r.i; r.get(32)
    configuration_event_offset = r.i; configuration_event = r.number(8)
    unix_ms_offset = r.i; r.get(8)
    pid_offset = r.i; r.get(4)
    request_digest_offset = r.i; r.get(32)
    result: dict[str, int | str] = {
        'kind': kind, 'grant': grant,
        'preceding_revision': preceding_revision,
        'preceding_revision_offset': preceding_revision_offset,
        'preceding_commitment_offset': preceding_commitment_offset,
        'configuration_event': configuration_event,
        'configuration_event_offset': configuration_event_offset,
        'unix_ms_offset': unix_ms_offset, 'pid_offset': pid_offset,
        'request_digest_offset': request_digest_offset,
        'transaction_bytes': len(transaction),
    }
    if kind in (3, 4):
        result['automatic_generation_offset'] = r.i; result['automatic_generation'] = r.number(8)
        result['automatic_steps_after_offset'] = r.i; result['automatic_steps_after'] = r.number(8)
        result['automatic_schedule_revision_after_offset'] = r.i
        result['automatic_schedule_revision_after'] = r.number(8)
        result['automatic_executor_uid_offset'] = r.i; result['automatic_executor_uid'] = r.number(4)
        result['automatic_state_after_offset'] = r.i; result['automatic_state_after'] = r.number(1)
    if kind in (1, 3):
        result['source_operation_offset'] = r.i; r.get(32)
        result['delivery_operation_offset'] = r.i; r.get(32)
        result['record_digest_offset'] = r.i; r.get(32)
        result['payload_bytes_offset'] = r.i; result['payload_bytes'] = r.number(4)
        result['outbox_length_offset'] = r.i; size = r.number(4)
        result['outbox_length'] = size; result['outbox_offset'] = r.i; r.get(size)
    else:
        result['delivery_operation_offset'] = r.i; r.get(32)
        result['record_digest_offset'] = r.i; r.get(32)
        result['receipt_digest_offset'] = r.i; r.get(32)
    r.eof()
    return result


def mutate_transaction(frame: bytes, offset: int, replacement: bytes) -> bytes:
    changed = bytearray(frame)
    start = 9 + offset
    changed[start:start+len(replacement)] = replacement
    return checksum_frame(bytes(changed))


def run_cases(h: Harness, selected: set[str] | None, mode: str, probes: list[Path], readers: list[Path]) -> None:
    def case(name, fn):
        if selected is None or name in selected: h.case(name, fn)

    def full_boundary():
        a,c=h.runtime/'work-a',h.runtime/'work-c'; cp=free_port(); uid=os.geteuid()
        pa=config(h,'work-a',a,ports={'C':cp},rules=[f'g1,{uid},{uid},C,c-g1,{SCOPE},128,65536'])
        pc=peer_config(h,'work-c','C',c,cp,inbound=['A']); ad=h.start('work-a',pa,a); cd=h.start('work-c',pc,c)
        sources=[]
        for i in range(128):
            # Independent originals followed by corrections to earlier branches.
            parent=sources[i-64] if i>=64 else None
            value=f'{i:04d}:'+('x'*123)
            sources.append(author(h,f'work-author-{i}',a,value=value,parent=parent)['operation_id'])
        sub=command(h,'work-create',a,'create'); rows=[]
        for i in range(128):
            begin=time.monotonic()
            issued=command(h,f'work-issue-{i}',a,'step',previous=sub)
            acknowledged=ack(h,f'work-ack-{i}',a,issued)
            iw,aw=issued['validation_work'],acknowledged['validation_work']
            if mode != 'full':
                from source_outbound_work import check_outbound_work
                check_outbound_work(h, iw, aw, mode)
            if mode in ('delta','copy-return','owned-outgoing','copy-store','reference','independent-outbound'):
                for w in (iw,aw):
                    h.check(w['delta_validations']==2,'two changed-entry validations run before and during commit')
                    h.check(w['progress_transaction_encodes']==1 and w['progress_transaction_decodes']==1,'one compact transaction encoded and parsed once in its originating command')
                    h.check(w['commitment_updates']==1 and w['commitment_full_rebuilds']==(1 if mode=='reference' else 0),'ordinary progress updates one commitment; only the reference build independently rebuilds it once')
                    h.check(w['state_decodes']==0,'ordinary compact progress decodes no complete subscription state')
                    h.check(w['transaction_preparations_created']==w['preflight_transaction_uses']==w['application_transaction_uses']==1,
                            'one immutable parse reused by both independent semantic passes')
                    h.check(w['transaction_byte_binding_checks']==3 and w['progress_transaction_bytes_decoded']==w['progress_transaction_bytes_encoded'],
                            'exact byte binding checked at preflight, before append and application')
                if mode in ('delta','copy-return','owned-outgoing','copy-store','independent-outbound'):
                    for w in (iw,aw):
                        h.check(w['configuration_parses']==1 and w['delivery_validations']==2,'normal product validates current config and only the changed delivery per preflight/apply')
                        h.check(w['full_validations']==0 and w['reference_validations']==0,'normal product performs no slow full-history validation')
                        h.check(w['copied_delivery_entries']==0 and w['compared_delivery_entries']==0,'normal compact path copies and compares no retained delivery vector')
                    h.check(iw['source_records_reconstructed']==1,'issue prepares one command record and rechecks its exact binding twice')
                    h.check(aw['source_records_reconstructed']==0 and aw['source_payload_bytes_encoded']==0,'ack copies/re-encodes no source payload')
                    h.check(aw['receipt_checks']==2,'both semantic passes require the durable head receipt')
                else:
                    for w in (iw,aw):
                        h.check(w['reference_validations']==2 and w['full_validations']==2,'diagnostic slow validator accepts every compact transition')
                        h.check(w['configuration_parses']==3 and w['delivery_validations']==2*(i+2),'reference profile adds two complete independent historical validations to prepared compact checks')
                    h.check(iw['source_records_reconstructed']>=3 and aw['receipt_checks']>=2,'slow oracle adds work without replacing exact compact checks')
            else:
                h.check(iw['full_validations']==2 and aw['full_validations']==2,'counterfactual uses original full validator')
                h.check(iw['delivery_validations']==2*(i+1) and aw['delivery_validations']==2*(i+1),'full path revisits all historical deliveries')
                for w in (iw,aw):
                    h.check(w['progress_transaction_encodes']==0 and w['progress_transaction_decodes']==0,'legacy counterfactual journals complete NST1 states')
            h.check(issued['latest']['source_operation']==sources[i] and acknowledged['acknowledged']==i+1,'exact source order and receipt frontier')
            rows.append({'ordinal':i+1,'issue':iw,'ack':aw,'elapsed_seconds':time.monotonic()-begin})
            sub=acknowledged
        h.check(sub['used_payload_bytes']==16384 and sub['revision']==257,'exact finite byte, count and revision accounts')
        before=(a/'state.journal').stat().st_size
        for i in range(4):
            observed=command(h,f'caught-up-{i}',a,'step',previous=sub)
            h.check(observed['disposition']=='RECORD_BUDGET_EXHAUSTED','finite cap unchanged')
        h.check((a/'state.journal').stat().st_size==before,'no progress or telemetry journal writes on exhaustion')
        ad.shutdown(); cd.shutdown()
        frames=journal_frames(a/'state.journal'); source_frames=[f for f in frames if f[8]==32]
        magics=[source_transaction(f)[:4].decode('ascii') for f in source_frames]
        encoding={'mode':mode,'source_frames':len(source_frames),'magics':{m:magics.count(m) for m in sorted(set(magics))}}
        h.check(len(source_frames)==257,'one creation plus exactly 256 ordinary progress records')
        if mode in ('delta','copy-return','owned-outgoing','copy-store','reference','independent-outbound'):
            progress=[progress_layout(f) for f in source_frames if source_transaction(f)[:4]==b'NST3']
            issue_bytes=[int(x['transaction_bytes']) for x in progress if x['kind']==1]
            ack_bytes=[int(x['transaction_bytes']) for x in progress if x['kind']==2]
            h.check(magics.count('NST1')==1 and len(progress)==256,'creation remains canonical NST1 and all ordinary progress uses NST3')
            h.check(len(issue_bytes)==128 and len(ack_bytes)==128,'compact journal has exact issue and acknowledgment counts')
            h.check(max(issue_bytes)<1024 and set(ack_bytes)=={229},'source-128 compact ISSUE stays below 1 KiB and ACK is fixed at 229 bytes')
            encoding.update({'issue_transaction_bytes':{'first':issue_bytes[0],'last':issue_bytes[-1],'maximum':max(issue_bytes)},
                             'ack_transaction_bytes':{'first':ack_bytes[0],'last':ack_bytes[-1],'unique':sorted(set(ack_bytes))}})
        else:
            h.check(set(magics)=={'NST1'},'slow counterfactual emits only backward-compatible complete NST1 records')
            transaction_bytes=[len(source_transaction(f)) for f in source_frames]
            h.check(transaction_bytes[-1]>transaction_bytes[1],'legacy complete-state journal records grow with retained history')
            encoding['legacy_transaction_bytes']={'creation':transaction_bytes[0],'first_progress':transaction_bytes[1],'last_progress':transaction_bytes[-1]}
        started=time.monotonic(); raw=inspect(h,'uncompacted-replay',a); replay_s=time.monotonic()-started
        h.check(raw['source_subscriptions'][0]['acknowledged']==128,'full ordinary replay reconstructs frontier')
        replay_observations=[]
        checksum=hashlib.sha256((a/'state.journal').read_bytes()).hexdigest()
        for probe in probes:
            observed=subprocess.run([str(probe.resolve()),str(a),'A'],capture_output=True,text=True,timeout=60)
            h.check(observed.returncode==0,'native reconstruction probe succeeds')
            account=json.loads(observed.stdout);replay_observations.append({'probe_name':probe.name,**account})
            h.check(account['logical_state_digest']==raw['storage']['logical_state_digest'],'full and inductive replay reproduce the exact same logical state')
            h.check(hashlib.sha256((a/'state.journal').read_bytes()).hexdigest()==checksum,'probe does not change source journal bytes')
        for reader in readers:
            binary = reader.resolve()
            observed = subprocess.run([str(binary), 'inspect', '--state', str(a), '--node', 'A'],
                                      capture_output=True, text=True, timeout=60)
            h.check(observed.returncode == 0, 'independent native reader accepts the same complete journal')
            account = json.loads(observed.stdout)
            h.check(account['storage']['logical_state_digest'] == raw['storage']['logical_state_digest'],
                    'independent native readers reconstruct the exact same logical state from identical bytes')
            h.check(hashlib.sha256((a/'state.journal').read_bytes()).hexdigest() == checksum,
                    'independent native reader leaves the source journal byte unchanged')
            replay_observations.append({'reader': str(binary),
                'reader_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                'journal_sha256': checksum, 'status': 'PASS',
                'logical_state_digest': account['storage']['logical_state_digest'],
                'acknowledged': account['source_subscriptions'][0]['acknowledged']})
        if replay_observations:dump(h,'REPLAY-COMPARISON',replay_observations)
        h.check(inspect(h,'recipient-count',c,node='C')['inbound']['count']==128,'actual recipient has 128 records')
        ad=h.start('work-restart',pa,a)
        h.run('work-compact',['compact','--control',str(ad.control)])
        ad.shutdown()
        after=inspect(h,'checkpoint-replay',a)
        h.check(after['source_subscriptions']==raw['source_subscriptions'],'full checkpoint reconstruction preserves exact state')
        checkpoint_bytes=(a/'state.journal').read_bytes()
        for reader in readers:
            observed=subprocess.run([str(reader.resolve()),'inspect','--state',str(a),'--node','A'],
                                    capture_output=True,text=True,timeout=60)
            h.check(observed.returncode==0,'independent reader accepts new canonical checkpoint')
            account=json.loads(observed.stdout)
            h.check(account['storage']['logical_state_digest']==after['storage']['logical_state_digest'],
                    'same checkpoint yields identical logical state in each reader')
            h.check((a/'state.journal').read_bytes()==checkpoint_bytes,'checkpoint reader leaves bytes unchanged')
            replay_observations.append({'reader':str(reader.resolve()),'representation':'checkpoint',
                'reader_sha256':hashlib.sha256(reader.read_bytes()).hexdigest(),
                'journal_sha256':hashlib.sha256(checkpoint_bytes).hexdigest(),'status':'PASS',
                'logical_state_digest':account['storage']['logical_state_digest']})
        if replay_observations:dump(h,'REPLAY-COMPARISON',replay_observations)
        dump(h,'WORK-128',{'mode':mode,'records':128,'payload_bytes':16384,'work':rows,'journal_encoding':encoding,
              'uncompacted_replay_seconds':replay_s,'ordinary_tls_deliveries':True,'first':rows[0],'last':rows[-1]})
    case('128_sources_delta_work_and_uncompacted_replay',full_boundary)

    def strict_parsing():
        a,c=h.runtime/'parse-a',h.runtime/'parse-c'; cp=free_port(); uid=os.geteuid()
        pa=config(h,'parse-a',a,ports={'C':cp},rules=[f'g1,{uid},{uid},C,c-g1,{SCOPE},8,65536'])
        pc=peer_config(h,'parse-c','C',c,cp,inbound=['A'])
        ad=h.start('parse-a',pa,a);cd=h.start('parse-c',pc,c)
        source=author(h,'parse-large-source',a,value='x'*58000)
        sub=command(h,'parse-create',a,'create')
        issued=command(h,'parse-large-issue',a,'step',previous=sub)
        final=ack(h,'parse-large-ack',a,issued)
        h.check(final['acknowledged']==1 and final['used_payload_bytes']==58000,
                'large legal selected source retains exact payload accounting')
        iw,aw=issued['validation_work'],final['validation_work']
        if mode != 'full':
            from source_outbound_work import check_outbound_work
            check_outbound_work(h, iw, aw, mode)
            for work in (iw,aw):
                h.check(work['progress_transaction_decodes']==work['transaction_preparations_created']==1,
                        'large legal transaction parsed once with normal strict decoder')
                h.check(work['preflight_transaction_uses']==work['application_transaction_uses']==1 and
                        work['transaction_byte_binding_checks']==3,
                        'large transaction preserves both semantic uses and pre-append binding')
            h.check(iw['progress_record_payload_bytes_decoded']>58000 and
                    iw['progress_outgoing_bytes_copied'] + iw['progress_outgoing_slice_bytes'] >
                        iw['progress_record_payload_bytes_decoded'],
                    'separate exact selected payload and composite copy-or-slice work')
            h.check(aw['receipt_checks'] >= 2 and
                    aw['progress_outgoing_bytes_copied']==aw['progress_outgoing_slice_bytes']==0,
                    'ACK retains durable receipt predicates without outbox-payload parsing')
        ad.shutdown();cd.shutdown()
        frames=journal_frames(a/'state.journal')
        selected=[i for i,f in enumerate(frames) if f[8]==32]
        if mode == 'full': return
        position=selected[1]; original=source_transaction(frames[position]); layout=progress_layout(frames[position])
        mutations={'empty':b'', 'short-magic':b'NST', 'truncated':original[:-1],
                   'trailing':original+b'\0', 'wrong-magic':b'NST9'+original[4:]}
        for kind in (0,5,255,2,3):
            mutations['kind-'+str(kind)]=original[:4]+bytes([kind])+original[5:]
        for length in (0,66001,0xffffffff):
            off=int(layout['outbox_length_offset'])
            mutations['outbox-length-'+str(length)]=original[:off]+length.to_bytes(4,'big')+original[off+4:]
        mutations['grant-length']=original[:5]+b'\xff\xff'+original[7:]
        observations=[]
        for label,payload in mutations.items():
            body=b'\x20'+payload
            frame=checksum_frame(b'NOJ1'+len(body).to_bytes(4,'big')+body+b'\0'*32)
            material=frames.copy();material[position]=frame
            dest=h.runtime/('bad-parse-'+label);shutil.copytree(a,dest)
            journal=b''.join(material);(dest/'state.journal').write_bytes(journal)
            result=inspect(h,'bad-parse-'+label,dest,expected=3)
            h.check(result['code']=='JOURNAL_CORRUPT','independent replay rejects malformed NST3 '+label)
            h.check((dest/'state.journal').read_bytes()==journal,'rejected startup leaves original bytes unchanged')
            observations.append({'mutation':label,'code':result['code']})
        dump(h,'PARSED-PROGRESS',{'large_payload_bytes':58000,'issue_work':iw,'ack_work':aw,
             'source_operation':source['operation_id'],'malformed_rejections':observations})
    case('strict_nst3_parse_large_payload_and_malformed_replay',strict_parsing)

    def corrupt():
        a,c=h.runtime/'corrupt-a',h.runtime/'corrupt-c'; cp=free_port(); uid=os.geteuid()
        rules=[f'g1,{uid},{uid},C,c-g1,{SCOPE},8,10000',f'g2,{uid},{uid},C,c-g1,{SCOPE},1,1000']
        pa=config(h,'corrupt-a',a,ports={'C':cp},rules=rules); pc=peer_config(h,'corrupt-c','C',c,cp,inbound=['A'])
        ad=h.start('corrupt-a',pa,a); cd=h.start('corrupt-c',pc,c)
        original=author(h,'corrupt-original',a,value='validated original')
        author(h,'corrupt-child',a,value='validated correction',parent=original['operation_id'])
        sub=command(h,'corrupt-create',a,'create'); one=command(h,'corrupt-first',a,'step',previous=sub); one=ack(h,'corrupt-first-ack',a,one)
        two=command(h,'corrupt-second',a,'step',previous=one); ack(h,'corrupt-second-ack',a,two)
        removed=candidate(h,pa,'corrupt-policy-removed','corrupt-policy-removed',
            lambda x:'\n'.join(line for line in x.splitlines() if not line.startswith('source_disclosure=g1,'))+'\n')
        activate(h,'corrupt-remove-g1',a,removed)
        ad.shutdown();cd.shutdown(); frames=journal_frames(a/'state.journal')
        subframes=[i for i,f in enumerate(frames) if f[8]==32]
        h.check(len(subframes)==5,'creation, two compact issues and two compact acknowledgments')
        h.check(source_transaction(frames[subframes[0]])[:4]==b'NST1','creation keeps the canonical complete-state representation')
        layouts=[progress_layout(frames[i]) for i in subframes[1:]]
        h.check([x['kind'] for x in layouts]==[1,2,1,2],'ordinary source progress uses exact compact issue/ack sequence')
        def inner_kind(f:bytes)->int:
            # Runtime-bound wrapper: accepted event u64, then inner kind.
            if f[8]==23:
                return f[17]
            return f[8]
        receipt_indices=[i for i,f in enumerate(frames) if inner_kind(f)==3]
        h.check(len(receipt_indices)==2,'two exact durable receipts')
        def rejected(label:str, material:list[bytes]):
            dest=h.runtime/label;shutil.copytree(a,dest);(dest/'state.journal').write_bytes(b''.join(material))
            r=inspect(h,label,dest,expected=3)
            h.check(r['code']=='JOURNAL_CORRUPT',label+' is a semantic rejection')
            return {'case':label,'code':r['code'],'detail':r}
        def flipped(frame:bytes, offset:int)->bytes:
            value=source_transaction(frame)[offset]^1
            return mutate_transaction(frame,offset,bytes([value]))
        observations=[]
        observations.append(rejected('missing-durable-head-receipt',[f for i,f in enumerate(frames) if i!=receipt_indices[-1]]))
        observations.append(rejected('deleted-prior-issue',[f for i,f in enumerate(frames) if i!=subframes[-2]]))
        final_ack=frames[subframes[-1]]; final_ack_layout=progress_layout(final_ack)
        altered=frames.copy(); altered[subframes[-1]]=flipped(final_ack,int(final_ack_layout['preceding_commitment_offset']))
        observations.append(rejected('changed-predecessor-commitment',altered))
        second_issue=frames[subframes[-2]]; second_issue_layout=progress_layout(second_issue)
        forged_payload=int(second_issue_layout['payload_bytes'])+1
        altered=frames.copy(); altered[subframes[-2]]=mutate_transaction(second_issue,int(second_issue_layout['payload_bytes_offset']),forged_payload.to_bytes(4,'big'))
        observations.append(rejected('forged-new-source-payload',altered))
        altered=frames.copy(); altered[subframes[-1]]=flipped(final_ack,int(final_ack_layout['receipt_digest_offset']))
        observations.append(rejected('forged-durable-receipt-commitment',altered))
        h.check(subframes[-1] < len(frames)-1,'accepted policy removal follows the final source acknowledgment')
        stale=frames.copy(); stale_ack=stale.pop(subframes[-1]); stale.append(stale_ack)
        observations.append(rejected('stale-disclosure-configuration-after-removal',stale))
        # Checkpoint trust boundary still does full source and receipt validation.
        ad=h.start('corrupt-compact',removed,a);h.run('corrupt-compact',['compact','--control',str(ad.control)]);ad.shutdown()
        snapframes=journal_frames(a/'state.journal'); checkpoint=bytearray(snapframes[0]); marker=bytes.fromhex(two['latest']['record_digest'])
        h.check(bytes(checkpoint).count(marker)>=2,'checkpoint independently contains source mapping and outbox digest')
        at=bytes(checkpoint).rfind(marker);checkpoint[at]^=1
        dest=h.runtime/'forged-checkpoint';shutil.copytree(a,dest);(dest/'state.journal').write_bytes(checksum_frame(bytes(checkpoint))+b''.join(snapframes[1:]))
        r=inspect(h,'forged-checkpoint',dest,expected=3);h.check(r['code']=='JOURNAL_CORRUPT','checkpoint rejects changed mapping')
        dump(h,'CORRUPTION',observations+[{'case':'forged-checkpoint','code':r['code']}])
    case('untrusted_journal_and_checkpoint_keep_full_semantics',corrupt)

    def automatic_shape():
        from run_automatic_source_delivery import automatic, wait_automatic
        a,c=h.runtime/'auto-shape-a',h.runtime/'auto-shape-c';cp=free_port()
        pa=config(h,'auto-shape-a',a,ports={'C':cp});pc=peer_config(h,'auto-shape-c','C',c,cp,inbound=['A'])
        ad=h.start('auto-shape-a',pa,a);cd=h.start('auto-shape-c',pc,c)
        author(h,'auto-shape-source',a,value='x');created=command(h,'auto-shape-create',a,'create')
        automatic(h,'auto-shape-enable',a,'enable',previous=created,maximum=2)
        wait_automatic(h,'auto-shape-done',a,lambda x:x['acknowledged']==1)
        ad.shutdown();cd.shutdown();frames=journal_frames(a/'state.journal')
        index=next(i for i,f in enumerate(frames) if f[8]==32 and source_transaction(f)[:4]==b'NST3' and progress_layout(f)['kind']==3)
        frame=frames[index];layout=progress_layout(frame)
        h.check(layout['automatic_steps_after']==1 and layout['automatic_state_after']==1,'first automatic issue spends exactly one enabled step')
        def rejected(label:str, changed:bytes)->dict:
            material=frames.copy();material[index]=changed
            dest=h.runtime/label;shutil.copytree(a,dest);(dest/'state.journal').write_bytes(b''.join(material))
            result=inspect(h,label,dest,expected=3)
            h.check(result['code']=='JOURNAL_CORRUPT',label+' rejected during strict compact replay')
            return {'case':label,'code':result['code'],'detail':result}
        false_steps=int(layout['automatic_steps_after'])+1
        allowance=mutate_transaction(frame,int(layout['automatic_steps_after_offset']),false_steps.to_bytes(8,'big'))
        manual_actor=mutate_transaction(frame,int(layout['request_digest_offset']),b'\x01'+b'\0'*31)
        wrong_event=int(layout['configuration_event'])+1
        configuration=mutate_transaction(frame,int(layout['configuration_event_offset']),wrong_event.to_bytes(8,'big'))
        observations=[rejected('false-automatic-allowance',allowance),
                      rejected('automatic-progress-carries-manual-actor-request',manual_actor),
                      rejected('automatic-progress-wrong-configuration',configuration)]
        dump(h,'AUTOMATIC-SHAPE',observations)
    case('compact_automatic_allowance_actor_and_configuration_rejected',automatic_shape)

    def visibility():
        from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
        a=h.runtime/'delegate'; uid=65534
        pa=config(h,'delegate',a,ports={'C':free_port()},delegates=True,
                  rules=[f'g1,{uid},{uid},C,c-g1,{SCOPE},2,20'])
        ad=h.start('delegate',pa,a);expose_control_for_uid(a)
        r=command(h,'delegate-create',a,'create',uid=uid)
        h.check('validation_work' not in r,'SOURCE_DISCLOSE does not grant node-wide diagnostic work')
        restore_owner_only_control(a);ad.shutdown()
    case('work_telemetry_requires_current_inspection_authority',visibility)


def main()->int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--case',action='append');p.add_argument('--replay-reader',type=Path,action='append',default=[]);p.add_argument('--replay-probe',type=Path,action='append',default=[]);p.add_argument('--validation-mode',choices=('delta','copy-return','owned-outgoing','copy-store','full','reference','independent-outbound'),default='delta');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    try:run_cases(h,set(a.case) if a.case else None,a.validation_mode,a.replay_probe,a.replay_reader);ok=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {type(e).__name__}: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_SUBSCRIPTION_VALIDATION_TESTS_V1','status':'PASS' if ok else 'FAIL',
            'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),
            'cases_passed':sum(x['status']=='PASS' for x in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:dump(h,name,data)
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
