#!/usr/bin/env python3
"""Build and exercise the durable adapter-profile catalog boundary."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

STRICT_FLAGS = [
    "-std=c++20",
    "-O2",
    "-g",
    "-Wall",
    "-Wextra",
    "-Wpedantic",
    "-Wconversion",
    "-Wsign-conversion",
    "-Wshadow",
    "-Wformat=2",
    "-Werror",
]
SANITIZER_FLAGS = [
    "-std=c++20",
    "-O1",
    "-g3",
    "-fno-omit-frame-pointer",
    "-Wall",
    "-Wextra",
    "-Wpedantic",
    "-Wconversion",
    "-Wsign-conversion",
    "-Wshadow",
    "-Wformat=2",
    "-Werror",
    "-fsanitize=address,undefined",
]


def run(
    command: list[str],
    cwd: Path,
    stdout: Path,
    stderr: Path,
    environment: dict[str, str] | None = None,
) -> float:
    start = time.monotonic()
    with stdout.open("wb") as out, stderr.open("wb") as err:
        completed = subprocess.run(
            command,
            cwd=cwd,
            env=environment,
            stdout=out,
            stderr=err,
            check=False,
        )
    elapsed = time.monotonic() - start
    if completed.returncode != 0:
        raise RuntimeError(
            f"command failed ({completed.returncode}): {' '.join(command)}"
        )
    return elapsed


def parse_pass(path: Path) -> dict[str, object]:
    record = json.loads(path.read_text())
    if record.get("status") != "PASS":
        raise RuntimeError(f"non-passing probe: {path}")
    return record


def compile_command(
    compiler: str,
    flags: list[str],
    includes: list[Path],
    sources: list[Path],
    output: Path,
    definitions: list[str] | None = None,
    link: list[str] | None = None,
) -> list[str]:
    command = [compiler, *flags, "-D_GNU_SOURCE"]
    for definition in definitions or []:
        command.append(f"-D{definition}")
    for include in includes:
        command.extend(["-I", str(include)])
    command.extend(str(source) for source in sources)
    command.extend(link or [])
    command.extend(["-o", str(output)])
    return command


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--stub-root", type=Path)
    parser.add_argument("--sanitize", action="store_true")
    parser.add_argument("--stress-runs", type=int, default=0)
    parser.add_argument("--compiler", default=os.environ.get("CXX", "g++"))
    args = parser.parse_args()

    source_root = args.source_root.resolve()
    output = args.output.resolve()
    if output.exists():
        shutil.rmtree(output)
    (output / "logs").mkdir(parents=True)
    build = output / "build"
    build.mkdir()

    src = source_root / "node" / "src"
    tests = source_root / "node" / "tests"
    required = [
        src / "adapter_profile.cpp",
        src / "adapter_profile.hpp",
        src / "adapter_profile_catalog.cpp",
        src / "adapter_profile_catalog.hpp",
        src / "configured_adapter_endpoint.cpp",
        src / "configured_adapter_endpoint.hpp",
        src / "external_packet_adapter.cpp",
        src / "external_packet_adapter.hpp",
        tests / "adapter_profile_fixture.cpp",
        tests / "adapter_protocol_fixture.cpp",
        tests / "test_adapter_profile_catalog.cpp",
        tests / "test_adapter_profile_catalog_integration.cpp",
    ]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise RuntimeError("missing source files: " + ", ".join(missing))

    flags = SANITIZER_FLAGS if args.sanitize else STRICT_FLAGS
    includes = [src]
    if args.stub_root is not None:
        includes.append(args.stub_root.resolve())

    commands: list[dict[str, object]] = []

    def compile_one(name: str, command: list[str]) -> None:
        stdout = output / "logs" / f"{name}.stdout.txt"
        stderr = output / "logs" / f"{name}.stderr.txt"
        elapsed = run(command, source_root, stdout, stderr)
        commands.append(
            {
                "name": name,
                "command": command,
                "elapsed_seconds": elapsed,
                "stderr_bytes": stderr.stat().st_size,
            }
        )

    for marker in ("A", "B"):
        compile_one(
            f"compile-profile-fixture-{marker.lower()}",
            compile_command(
                args.compiler,
                STRICT_FLAGS,
                [],
                [tests / "adapter_profile_fixture.cpp"],
                build / f"adapter-profile-fixture-{marker.lower()}",
                [f'NATRAV_FIXTURE_MARKER="{marker}"'],
            ),
        )
        compile_one(
            f"compile-protocol-fixture-{marker.lower()}",
            compile_command(
                args.compiler,
                STRICT_FLAGS,
                [],
                [tests / "adapter_protocol_fixture.cpp"],
                build / f"adapter-protocol-fixture-{marker.lower()}",
                [f'NATRAV_FIXTURE_MARKER="{marker}"'],
            ),
        )

    link = ["-lcrypto", "-pthread"]
    if args.sanitize:
        link.append("-fsanitize=address,undefined")

    compile_one(
        "compile-catalog-probe",
        compile_command(
            args.compiler,
            flags,
            includes,
            [
                src / "adapter_profile.cpp",
                src / "adapter_profile_catalog.cpp",
                tests / "test_adapter_profile_catalog.cpp",
            ],
            build / "test-adapter-profile-catalog",
            link=link,
        ),
    )
    compile_one(
        "compile-catalog-integration-probe",
        compile_command(
            args.compiler,
            flags,
            includes,
            [
                src / "adapter_profile.cpp",
                src / "adapter_profile_catalog.cpp",
                src / "external_packet_adapter.cpp",
                src / "configured_adapter_endpoint.cpp",
                tests / "test_adapter_profile_catalog_integration.cpp",
            ],
            build / "test-adapter-profile-catalog-integration",
            link=link,
        ),
    )

    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    if args.sanitize:
        environment["ASAN_OPTIONS"] = (
            "detect_leaks=1:halt_on_error=1:abort_on_error=1:strict_string_checks=1"
        )
        environment["UBSAN_OPTIONS"] = "halt_on_error=1:print_stacktrace=1"

    catalog_stdout = output / "catalog.json"
    catalog_stderr = output / "catalog.stderr.txt"
    catalog_elapsed = run(
        [
            str(build / "test-adapter-profile-catalog"),
            str(build / "adapter-profile-fixture-a"),
            str(build / "adapter-profile-fixture-b"),
        ],
        source_root,
        catalog_stdout,
        catalog_stderr,
        environment,
    )
    integration_stdout = output / "integration.json"
    integration_stderr = output / "integration.stderr.txt"
    integration_elapsed = run(
        [
            str(build / "test-adapter-profile-catalog-integration"),
            str(build / "adapter-protocol-fixture-a"),
            str(build / "adapter-protocol-fixture-b"),
        ],
        source_root,
        integration_stdout,
        integration_stderr,
        environment,
    )
    catalog = parse_pass(catalog_stdout)
    integration = parse_pass(integration_stdout)
    if catalog_stderr.stat().st_size != 0 or integration_stderr.stat().st_size != 0:
        raise RuntimeError("probe emitted stderr")

    stress_assertions = 0
    stress_cases = 0
    for index in range(args.stress_runs):
        run_stdout = output / "logs" / f"stress-{index + 1:04d}.json"
        run_stderr = output / "logs" / f"stress-{index + 1:04d}.stderr.txt"
        run(
            [
                str(build / "test-adapter-profile-catalog-integration"),
                str(build / "adapter-protocol-fixture-a"),
                str(build / "adapter-protocol-fixture-b"),
            ],
            source_root,
            run_stdout,
            run_stderr,
            environment,
        )
        record = parse_pass(run_stdout)
        if run_stderr.stat().st_size != 0:
            raise RuntimeError("stress probe emitted stderr")
        stress_assertions += int(record["assertions"])
        stress_cases += int(record["cases"])

    summary = {
        "format": "NATRAV_ADAPTER_PROFILE_CATALOG_RUNNER_V1",
        "status": "PASS",
        "sanitized": args.sanitize,
        "catalog": catalog,
        "integration": integration,
        "catalog_elapsed_seconds": catalog_elapsed,
        "integration_elapsed_seconds": integration_elapsed,
        "stress_runs": args.stress_runs,
        "stress_case_executions": stress_cases,
        "stress_assertion_executions": stress_assertions,
        "commands": commands,
    }
    (output / "SUMMARY.json").write_text(
        json.dumps(summary, sort_keys=True, indent=2) + "\n"
    )
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:  # noqa: BLE001 - retain exact failure
        print(f"adapter-profile-catalog runner failed: {exc}", file=sys.stderr)
        raise
