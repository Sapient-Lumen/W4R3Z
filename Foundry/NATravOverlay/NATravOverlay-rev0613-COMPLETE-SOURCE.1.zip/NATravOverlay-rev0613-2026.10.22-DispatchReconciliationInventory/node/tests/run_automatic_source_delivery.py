#!/usr/bin/env python3
"""Finite fair provider-side automatic source delivery over durable subscriptions."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
from typing import Any

from run_persistent import Harness, free_port, operation
from run_source_subscriptions import config, command, journal_frames, SCOPE
from run_evidence_queries import config as peer_config
from run_local_evidence import author, args as author_args
from run_live_configuration import candidate, activate, wait_state
from run_state_authentication import inspect
from run_peer_sessions import submit


def automatic(h: Harness, label: str, state: Path, kind: str, *, grant: str = "g1",
              previous: dict[str, Any] | None = None, maximum: int = 100,
              interval: int = 10, reason: str = "finite provider automation",
              expected: int = 0) -> dict[str, Any]:
    args = [f"source-subscription-auto-{kind}", "--control", str(state / "control.sock"),
            "--grant", grant, "--deadline-ms", "5000"]
    if kind in ("enable", "pause"):
        assert previous is not None
        args += ["--instance", previous["instance"],
                 "--expected-revision", str(previous["revision"]),
                 "--expected-schedule-revision", str(previous["automatic_schedule_revision"]),
                 "--expected-grant-generation", str(previous["automatic_generation"]),
                 "--reason", reason]
    if kind == "enable":
        args += ["--max-automatic-steps", str(maximum),
                 "--min-interval-ms", str(interval)]
    result = h.run(label, args, expected=expected)
    assert result is not None
    if expected == 0:
        h.check(result["format"] in ("NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_V1",
                                      "NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_V2"),
                "versioned automatic source response")
    return result


def wait_automatic(h: Harness, label: str, state: Path, predicate: Any,
                   grant: str = "g1", timeout: float = 10.0) -> dict[str, Any]:
    latest: dict[str, Any] = {}
    def ready() -> bool:
        nonlocal latest
        latest = automatic(h, label + "-poll", state, "status", grant=grant)
        return bool(predicate(latest))
    h.wait(label, ready, timeout)
    return latest


def run_cases(h: Harness, selected: set[str] | None = None) -> None:
    def case(name: str, function: Any) -> None:
        if selected is None or name in selected:
            h.case(name, function)

    def finite_allowance() -> None:
        a, c = h.runtime / "finite-a", h.runtime / "finite-c"
        cp = free_port()
        ac = config(h, "finite-a", a, ports={"C": cp})
        cc = peer_config(h, "finite-c", "C", c, cp, inbound=["A"])
        ad = h.start("finite-a", ac, a)
        cd = h.start("finite-c", cc, c)
        created = command(h, "finite-create", a, "create")
        enabled = automatic(h, "finite-enable", a, "enable", previous=created,
                            maximum=4, interval=10)
        before = (a / "state.journal").stat().st_size
        time.sleep(0.25)
        caught = automatic(h, "finite-caught-up", a, "status")
        h.check(caught["automatic_observation"] == "CAUGHT_UP" and
                caught["automatic_current"]["steps"] == 0,
                "caught-up automation spends no allowance")
        h.check((a / "state.journal").stat().st_size == before,
                "caught-up automation appends no polling events")
        author(h, "finite-source-1", a, value="a")
        author(h, "finite-source-2", a, value="b")
        exhausted = wait_automatic(h, "finite-exhausted", a,
            lambda value: value["acknowledged"] == 2 and
                value["automatic_current"]["state"] == "EXHAUSTED")
        h.check(exhausted["automatic_current"]["steps"] == 4 and
                exhausted["issued"] == 2,
                "two issue/ack pairs consume exactly four finite steps")
        h.check(h.status("finite-recipient", c)["inbound_records"] == 2,
                "recipient admits both automatically issued sources")
        second = automatic(h, "finite-enable-second", a, "enable", previous=exhausted,
                           maximum=3, interval=10, reason="caught-up grant")
        h.check(second["automatic_current"]["steps"] == 0,
                "new finite grant does not inherit spent allowance")
        blocked = command(h, "finite-manual-blocked", a, "step", previous=second, expected=3)
        h.check(blocked["code"] == "SOURCE_SUBSCRIPTION_AUTOMATION_ENABLED",
                "manual progression cannot race enabled automation")
        paused = automatic(h, "finite-pause", a, "pause", previous=second,
                           reason="explicit operator pause")
        h.check(paused["automatic_current"]["state"] == "PAUSED" and
                paused["automatic_current"]["steps"] == 0,
                "pause is durable without spending an empty step")
        h.run("finite-compact", ["compact", "--control", str(ad.control)])
        ad.shutdown(); cd.shutdown()
        offline = inspect(h, "finite-offline", a)
        subscription = offline["source_subscriptions"][0]
        h.check(subscription["automatic_current"]["state"] == "PAUSED" and
                subscription["acknowledged"] == 2,
                "compaction reconstructs finite grants and progress")
        ad = h.start("finite-restart", ac, a)
        rebuilt = automatic(h, "finite-rebuilt", a, "status")
        h.check(rebuilt["automatic_current"]["state"] == "PAUSED" and
                rebuilt["acknowledged"] == 2,
                "restart preserves paused automation and progress")
        ad.shutdown()
        (h.output / "FINITE-GRANT.json").write_text(json.dumps({
            "issued": exhausted["issued"], "acknowledged": exhausted["acknowledged"],
            "spent_steps": exhausted["automatic_current"]["steps"],
            "second_grant_state": paused["automatic_current"]["state"]}, indent=2) + "\n")
    case("finite_allowance_caught_up_pause_compaction_restart", finite_allowance)

    def fairness() -> None:
        a, c, d = (h.runtime / name for name in ("fair-a", "fair-c", "fair-d"))
        cp, dp = free_port(), free_port(); uid = os.geteuid()
        rules = [f"slow,{uid},{uid},C,c-g1,{SCOPE},8,10000",
                 f"fast,{uid},{uid},D,d-g1,{SCOPE},8,10000"]
        ac = config(h, "fair-a", a, ports={"C": cp, "D": dp}, rules=rules)
        cc = peer_config(h, "fair-c", "C", c, cp, inbound=["A"])
        dc = peer_config(h, "fair-d", "D", d, dp, inbound=["A"])
        ad = h.start("fair-a", ac, a)
        dd = h.start("fair-d", dc, d)
        author(h, "fair-source", a, value="one")
        slow = command(h, "fair-slow-create", a, "create", grant="slow")
        fast = command(h, "fair-fast-create", a, "create", grant="fast")
        automatic(h, "fair-slow-enable", a, "enable", grant="slow", previous=slow,
                  maximum=2, interval=10)
        automatic(h, "fair-fast-enable", a, "enable", grant="fast", previous=fast,
                  maximum=2, interval=10)
        fast_done = wait_automatic(h, "fair-fast-done", a,
            lambda value: value["acknowledged"] == 1 and
                value["automatic_current"]["state"] == "EXHAUSTED",
            grant="fast")
        slow_pending = wait_automatic(h, "fair-slow-pending", a,
            lambda value: value["issued"] == 1 and value["acknowledged"] == 0,
            grant="slow")
        h.check(fast_done["automatic_current"]["steps"] == 2,
                "reachable peer progresses while another is absent")
        h.check(slow_pending["automatic_current"]["steps"] == 1 and
                slow_pending["automatic_observation"] == "PENDING",
                "pending delivery spends only its successful issuance step")
        time.sleep(0.35)
        still = automatic(h, "fair-slow-still", a, "status", grant="slow")
        h.check(still["automatic_current"]["steps"] == 1,
                "pending polling does not consume finite allowance")
        cd = h.start("fair-c", cc, c)
        slow_done = wait_automatic(h, "fair-slow-done", a,
            lambda value: value["acknowledged"] == 1 and
                value["automatic_current"]["state"] == "EXHAUSTED",
            grant="slow")
        h.check(slow_done["automatic_current"]["steps"] == 2,
                "delayed peer receipt consumes one later acknowledgment step")
        h.check(h.status("fair-c-state", c)["inbound_records"] == 1 and
                h.status("fair-d-state", d)["inbound_records"] == 1,
                "both peers admit the source once")
        ad.shutdown(); cd.shutdown(); dd.shutdown()
        (h.output / "FAIRNESS.json").write_text(json.dumps({
            "slow_steps_while_unavailable": 1,
            "fast_acknowledged": fast_done["acknowledged"],
            "slow_final_steps": slow_done["automatic_current"]["steps"]}, indent=2) + "\n")
    case("fair_service_around_pending_unavailable_peer", fairness)

    def terminal_states() -> None:
        a, c = h.runtime / "terminal-a", h.runtime / "terminal-c"
        cp = free_port(); uid = os.geteuid()
        rules = [f"denied,{uid},{uid},C,c-g1,{SCOPE},8,10000",
                 f"revoked,{uid},65534,C,c-g1,{SCOPE},8,10000"]
        ac = config(h, "terminal-a", a, ports={"C": cp}, rules=rules)
        cc = peer_config(h, "terminal-c", "C", c, cp, inbound=["A"])
        # Keep mutual trust but remove recipient authorization for the selected scope.
        cc.write_text("\n".join(line for line in cc.read_text().splitlines()
            if line != f"authorize=A,*,EVIDENCE,{SCOPE}") + "\n")
        cc.chmod(0o600)
        ad = h.start("terminal-a", ac, a); cd = h.start("terminal-c", cc, c)
        author(h, "terminal-source", a, value="recipient denies")
        denied = command(h, "terminal-denied-create", a, "create", grant="denied")
        automatic(h, "terminal-denied-enable", a, "enable", grant="denied",
                  previous=denied, maximum=4, interval=10)
        denied_done = wait_automatic(h, "terminal-denied-blocked", a,
            lambda value: value["automatic_current"]["state"] == "BLOCKED",
            grant="denied")
        h.check(denied_done["automatic_current"]["steps"] == 1 and
                denied_done["automatic_current"]["error"] == "SOURCE_SUBSCRIPTION_DELIVERY_REJECTED",
                "recipient rejection blocks after exactly one issuance step")
        h.check(h.status("terminal-recipient", c)["inbound_records"] == 0,
                "recipient denial creates no source admission")
        revoked = command(h, "terminal-revoked-create", a, "create", grant="revoked")
        automatic(h, "terminal-revoked-enable", a, "enable", grant="revoked",
                  previous=revoked, maximum=4, interval=10)
        removed = candidate(h, ac, "terminal-remove", "terminal-remove-g1",
            lambda text: "\n".join(line for line in text.splitlines()
                if not line.startswith("source_disclosure=revoked,")) + "\n")
        activate(h, "terminal-remove-grant", a, removed)
        revoked_done = wait_automatic(h, "terminal-policy-blocked", a,
            lambda value: value["automatic_current"]["state"] == "BLOCKED",
            grant="revoked")
        h.check(revoked_done["automatic_current"]["steps"] == 0 and
                revoked_done["automatic_current"]["error"] == "SOURCE_DISCLOSURE_DENIED",
                "revoked disclosure blocks without consuming allowance")
        ad.shutdown(); cd.shutdown()
        ad = h.start("terminal-restart", ac, a)
        denied_rebuilt = automatic(h, "terminal-denied-rebuilt", a, "status", grant="denied")
        revoked_rebuilt = automatic(h, "terminal-revoked-rebuilt", a, "status", grant="revoked")
        h.check(denied_rebuilt["automatic_current"]["state"] == "BLOCKED" and
                revoked_rebuilt["automatic_current"]["state"] == "BLOCKED",
                "terminal automatic states survive semantic journal replay")
        ad.shutdown()
    case("terminal_rejection_and_live_policy_revocation", terminal_states)


    def quota_without_spend() -> None:
        a, c = h.runtime / "quota-a", h.runtime / "quota-c"
        cp = free_port()
        ac = config(h, "quota-a", a, ports={"C": cp})
        ac.write_text(ac.read_text() +
            "outbox_global_max_records=1\noutbox_peer_max_records=1\n")
        cc = peer_config(h, "quota-c", "C", c, cp, inbound=["A"])
        ad = h.start("quota-a", ac, a)
        blocker = operation("automatic-source-quota-blocker")
        submit(h, "quota-blocker", ad.control, "A", "C", SCOPE, blocker,
               "occupy the one-record outbox")
        author(h, "quota-source", a, value="waiting behind quota")
        created = command(h, "quota-create", a, "create")
        automatic(h, "quota-enable", a, "enable", previous=created,
                  maximum=2, interval=10)
        time.sleep(0.3)
        blocked = automatic(h, "quota-observe", a, "status")
        h.check(blocked["issued"] == 0 and blocked["automatic_current"]["steps"] == 0 and
                blocked["automatic_observation"] in ("OUTBOX_GLOBAL_RECORD_LIMIT", "OUTBOX_PEER_RECORD_LIMIT"),
                "outbox pressure spends neither disclosure nor automatic allowance")
        h.run("quota-release", ["cancel", "--control", str(ad.control),
            "--operation", blocker, "--reason", "release automatic source fixture capacity"])
        issued = wait_automatic(h, "quota-issued", a,
            lambda value: value["issued"] == 1 and value["automatic_current"]["steps"] == 1)
        h.check(issued["acknowledged"] == 0, "released quota permits exactly one issue")
        cd = h.start("quota-c", cc, c)
        final = wait_automatic(h, "quota-complete", a,
            lambda value: value["automatic_current"]["state"] == "EXHAUSTED")
        h.check(final["acknowledged"] == 1 and final["automatic_current"]["steps"] == 2,
                "receipt completes the finite grant after capacity returns")
        ad.shutdown(); cd.shutdown()
    case("outbox_quota_pressure_spends_no_allowance", quota_without_spend)

    def eligibility_priority_and_refresh() -> None:
        uid = os.geteuid()
        # Permanent envelope-size failure remains authoritative even when both
        # route service and outbox capacity are unavailable.
        oversized = h.runtime / "eligibility-oversized-a"
        port = free_port()
        rules = [f"g1,{uid},{uid},C,c-g1,{SCOPE},8,120000"]
        oversized_config = config(h, "eligibility-oversized-a", oversized,
                                  ports={"C": port}, rules=rules)
        oversized_config.write_text(oversized_config.read_text().replace(
            "peer_route=C,primary,0,ENABLED",
            "peer_route=C,primary,0,DISABLED") +
            "outbox_global_max_records=1\noutbox_peer_max_records=1\n")
        daemon = h.start("eligibility-oversized-a", oversized_config, oversized)
        blocker = operation("eligibility-oversized-blocker")
        submit(h, "eligibility-oversized-blocker", daemon.control,
               "A", "C", SCOPE, blocker, "occupy capacity during permanent classification")
        payload = h.work / "eligibility-oversized.bin"
        payload.write_bytes(bytes(range(256)) * 234 + bytes(range(96)))
        h.check(payload.stat().st_size == 60000,
                "automatic oversize fixture uses the maximum source payload")
        authored = author_args(oversized, "eligibility-oversized-source")
        i = authored.index("--payload-text")
        authored[i:i + 2] = ["--payload-file", str(payload)]
        h.run("eligibility-oversized-source", authored)
        created = command(h, "eligibility-oversized-create", oversized, "create")
        automatic(h, "eligibility-oversized-enable", oversized, "enable",
                  previous=created, maximum=2, interval=10)
        blocked = wait_automatic(h, "eligibility-oversized-blocked", oversized,
            lambda value: value["automatic_current"]["state"] == "BLOCKED")
        h.check(blocked["automatic_current"]["steps"] == 0 and
                blocked["issued"] == 0 and
                blocked["automatic_current"]["error"] ==
                    "SOURCE_SUBSCRIPTION_ENVELOPE_TOO_LARGE",
                "permanent oversize wins before unavailable route and full outbox")
        daemon.shutdown()

        # Route and capacity remain transient. A newly accepted configuration
        # and later capacity release cause a fresh classification/preparation;
        # neither stale preview nor failed preparation spends a finite step.
        a, c = h.runtime / "eligibility-refresh-a", h.runtime / "eligibility-refresh-c"
        cp = free_port()
        disabled = config(h, "eligibility-refresh-a", a, ports={"C": cp})
        disabled.write_text(disabled.read_text().replace(
            "peer_route=C,primary,0,ENABLED",
            "peer_route=C,primary,0,DISABLED") +
            "outbox_global_max_records=1\noutbox_peer_max_records=1\n")
        recipient_config = peer_config(h, "eligibility-refresh-c", "C", c, cp,
                                       inbound=["A"])
        ad = h.start("eligibility-refresh-a", disabled, a)
        held = operation("eligibility-refresh-blocker")
        submit(h, "eligibility-refresh-blocker", ad.control,
               "A", "C", SCOPE, held, "retain one outbox slot")
        author(h, "eligibility-refresh-source", a, value="retry after current facts change")
        current = command(h, "eligibility-refresh-create", a, "create")
        automatic(h, "eligibility-refresh-enable", a, "enable",
                  previous=current, maximum=2, interval=10)
        time.sleep(0.2)
        unavailable = automatic(h, "eligibility-refresh-route", a, "status")
        h.check(unavailable["issued"] == 0 and
                unavailable["automatic_current"]["steps"] == 0 and
                unavailable["automatic_current"]["state"] == "ENABLED" and
                unavailable["automatic_observation"] == "ROUTE_UNAVAILABLE",
                "disabled route is retryable and spends no source or step")
        enabled_config = candidate(h, disabled, "eligibility-route-enabled",
            "eligibility-route-enabled-g1", lambda text: text.replace(
                "peer_route=C,primary,0,DISABLED",
                "peer_route=C,primary,0,ENABLED"))
        activate(h, "eligibility-route-activate", a, enabled_config)
        time.sleep(0.2)
        full = automatic(h, "eligibility-refresh-capacity", a, "status")
        h.check(full["issued"] == 0 and
                full["automatic_current"]["steps"] == 0 and
                full["automatic_current"]["state"] == "ENABLED" and
                full["automatic_observation"] in
                    ("OUTBOX_GLOBAL_RECORD_LIMIT", "OUTBOX_PEER_RECORD_LIMIT"),
                "fresh enabled-route classification reaches capacity without spending")
        h.run("eligibility-refresh-release", ["cancel", "--control", str(ad.control),
            "--operation", held, "--reason", "release transient eligibility fixture"])
        issued = wait_automatic(h, "eligibility-refresh-issued", a,
            lambda value: value["issued"] == 1 and
                          value["automatic_current"]["steps"] == 1)
        h.check(issued["acknowledged"] == 0,
                "capacity release permits exactly one fresh automatic issuance")
        cd = h.start("eligibility-refresh-c", recipient_config, c)
        finished = wait_automatic(h, "eligibility-refresh-finished", a,
            lambda value: value["automatic_current"]["state"] == "EXHAUSTED")
        h.check(finished["acknowledged"] == 1 and
                finished["automatic_current"]["steps"] == 2,
                "actual receipt consumes only the remaining finite step")
        ad.shutdown(); cd.shutdown()
    case("eligibility_priority_route_capacity_and_refresh",
         eligibility_priority_and_refresh)

    def lifecycle_suspension() -> None:
        a, c = h.runtime / "lifecycle-a", h.runtime / "lifecycle-c"
        cp = free_port()
        ac = config(h, "lifecycle-a", a, ports={"C": cp})
        cc = peer_config(h, "lifecycle-c", "C", c, cp, inbound=["A"])
        ad = h.start("lifecycle-a", ac, a)
        author(h, "lifecycle-source", a, value="durable while quiesced")
        created = command(h, "lifecycle-create", a, "create")
        automatic(h, "lifecycle-enable", a, "enable", previous=created,
                  maximum=2, interval=10)
        pending = wait_automatic(h, "lifecycle-pending", a,
            lambda value: value["issued"] == 1 and value["acknowledged"] == 0)
        h.run("lifecycle-quiesce", ["quiesce", "--control", str(ad.control),
            "--reason", "suspend new automatic source semantics"])
        cd = h.start("lifecycle-c", cc, c)
        wait_state(h, a, pending["latest"]["operation_id"], "ACKED", "lifecycle-receipt")
        time.sleep(0.3)
        suspended = automatic(h, "lifecycle-suspended", a, "status")
        h.check(suspended["acknowledged"] == 0 and
                suspended["automatic_current"]["steps"] == 1 and
                suspended["automatic_observation"] == "ACK_READY",
                "quiesce permits durable delivery but suspends automatic acknowledgment")
        h.run("lifecycle-resume", ["resume", "--control", str(ad.control),
            "--reason", "resume automatic source semantics"])
        final = wait_automatic(h, "lifecycle-complete", a,
            lambda value: value["automatic_current"]["state"] == "EXHAUSTED")
        h.check(final["acknowledged"] == 1 and final["automatic_current"]["steps"] == 2,
                "resume advances the receipt-gated frontier once")
        ad.shutdown(); cd.shutdown()
    case("quiesce_suspends_new_steps_while_outbox_delivery_continues", lifecycle_suspension)

    def commit_boundaries() -> None:
        def source_frame_count(state: Path) -> int:
            return sum(frame[8] == 32 for frame in journal_frames(state / "state.journal"))

        def setup(prefix: str, pause_name: str) -> tuple[Path, Path, Path, Path, Any, dict[str, Any], int]:
            a, c = h.runtime / (prefix + "-a"), h.runtime / (prefix + "-c")
            cp = free_port(); ac = config(h, prefix + "-a", a, ports={"C": cp})
            cc = peer_config(h, prefix + "-c", "C", c, cp, inbound=["A"])
            ad = h.start(prefix + "-prepare", ac, a)
            author(h, prefix + "-source", a, value="kill boundary")
            created = command(h, prefix + "-create", a, "create")
            ad.shutdown()
            baseline = source_frame_count(a)
            ad = h.start(prefix + "-paused", ac, a, {pause_name: "5000"})
            enabled = automatic(h, prefix + "-enable", a, "enable", previous=created,
                                maximum=2, interval=10)
            return a, c, ac, cc, ad, enabled, baseline

        a, c, ac, cc, ad, enabled, baseline = setup("before", "NATRAV_OVERLAY_TEST_AUTOMATIC_SOURCE_BEFORE_COMMIT_MS")
        time.sleep(0.25)
        h.check(source_frame_count(a) == baseline + 1,
                "precommit pause leaves the automatic issue unpublished")
        ad.kill()
        offline = inspect(h, "before-offline", a)
        sub = offline["source_subscriptions"][0]
        h.check(sub["issued"] == 0 and sub["automatic_current"]["steps"] == 0,
                "kill before commit preserves old source and allowance state")
        cd = h.start("before-c", cc, c)
        ad = h.start("before-restart", ac, a)
        wait_automatic(h, "before-recovered", a,
            lambda value: value["automatic_current"]["state"] == "EXHAUSTED")
        ad.shutdown(); cd.shutdown()

        a, c, ac, cc, ad, enabled, baseline = setup("after", "NATRAV_OVERLAY_TEST_AUTOMATIC_SOURCE_AFTER_COMMIT_MS")
        h.wait("after commit visible on disk", lambda: source_frame_count(a) >= baseline + 2)
        ad.kill()
        offline = inspect(h, "after-offline", a)
        sub = offline["source_subscriptions"][0]
        h.check(sub["issued"] == 1 and sub["acknowledged"] == 0 and
                sub["automatic_current"]["steps"] == 1,
                "kill after commit preserves issue and spent allowance together")
        cd = h.start("after-c", cc, c)
        ad = h.start("after-restart", ac, a)
        final = wait_automatic(h, "after-recovered", a,
            lambda value: value["automatic_current"]["state"] == "EXHAUSTED")
        h.check(final["acknowledged"] == 1 and final["automatic_current"]["steps"] == 2,
                "restart consumes only the remaining acknowledgment step")
        ad.shutdown(); cd.shutdown()
    case("real_kills_before_and_after_atomic_automatic_step", commit_boundaries)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not already exist")
    h = Harness(args.binary, args.output)
    started = time.time(); ok = False
    try:
        run_cases(h, set(args.case) if args.case else None)
        ok = True
    except BaseException as error:
        (h.output / "FAILURE.txt").write_text(f"{type(error).__name__}: {error}\n")
        print(f"FAIL: {type(error).__name__}: {error}", file=os.sys.stderr)
    finally:
        h.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_AUTOMATIC_SOURCE_DELIVERY_TESTS_V1",
            "status": "PASS" if ok else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "cases_total": len(h.cases),
            "cases_passed": sum(case["status"] == "PASS" for case in h.cases),
            "assertions": h.assertions,
            "commands": len(h.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, data in (("SUMMARY", summary), ("CASES", h.cases), ("COMMANDS", h.commands)):
            (h.output / f"{name}.json").write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary), flush=True)
    return 0 if ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
