#!/usr/bin/env python3
"""Orderly-stop handoffs on owned C++ nodes; independently authenticate stopped bytes."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
import time
from typing import Any

from run_persistent import Harness, free_port, operation, raw_control
from run_state_authentication import inspect, new_key, migrate, start, independent_open
from run_state_expectations import selector, selected, start_expected
from run_local_administration import v8_config, expose_control_for_uid, restore_owner_only_control, run_as_uid
from run_live_configuration import candidate, activate
from run_control_authorization import Client, packet, text
from run_live_state_head import async_cli

UID, STOP_ONLY, READ_ONLY = 65534, 65533, 65532
CASES = ('keyed_immediate', 'unkeyed_and_legacy', 'strict_protocol', 'separate_authority',
    'partial_request_revocation', 'queued_configuration_and_controls', 'drain_receipts',
    'drain_timeout_and_response_loss', 'compaction_expectation_restart')


def setup(h: Harness, name: str, *, keyed=True, peers=None, env=None):
    root=h.runtime/name;root.mkdir(mode=0o755);state=root/'state'
    inspect(h,name+'-initialize',state)
    key=new_key(h,root,name+'-key') if keyed else None
    if key:migrate(h,name+'-migrate',state,key)
    conf=v8_config(h,name,'A',state,free_port(),name+'-g1',
        [(os.geteuid(),['ALL']),(UID,['INSPECT','SHUTDOWN']),(STOP_ONLY,['SHUTDOWN']),(READ_ONLY,['INSPECT'])],
        peers=peers,deadline_ms=3000)
    d=start(h,name,conf,state,key,env) if key else h.start(name,conf,state,env)
    return state,key,conf,d


def args(d, drain: int | None = None):
    result=['shutdown' if drain is None else 'drain-shutdown','--control',str(d.control),
        '--final-state-head','yes','--deadline-ms','12000']
    if drain is not None:result+=['--reason','explicit terminal handoff','--drain-deadline-ms',str(drain)]
    return result


def shape(h: Harness, value: dict[str,Any], drain: bool):
    h.check(value['ok'] and value['format']=='NATRAV_OVERLAY_TERMINAL_STATE_HEAD_V1','versioned terminal result, not a pre-stop response')
    h.check(value['command_class']=='SHUTDOWN' and value['shutdown']['required_head_class']=='INSPECT','separate mutation and metadata permissions')
    h.check(value['state_head']['freshness']=='NOT_ESTABLISHED' and value['state_head']['expectation']=='NOT_CHECKED_HERE','terminal sample is not an external freshness proof')
    h.check(value['state_head']['automatic_update'] is False and value['automatic_update'] is False,'no automatic external anchor update')
    h.check(value['observation']=={'consistency':'ONE_STATE_LOCK','validation':'REPLAY_AND_LIVE_APPLICATION','disk_reaudit':False,
        'may_advance_after_sample':False,'freshness':'NOT_ESTABLISHED'},'same-process writer closure, not a disk re-audit')
    t=value['terminal'];s=value['shutdown']
    h.check(t['state_sealed'] and t['scope']=='THIS_PROCESS_STOP_ONLY' and t['replacement_writer_excluded'] is False,'seal is process-local, never a claim excluding future owners')
    h.check(t['backlog_scope']=='OUTBOUND_AND_ACTIONS_ONLY' and
        t['obligations_complete']==(t['pending_outbound']==0 and t['pending_actions']==0),'only existing drain backlog categories are called complete')
    h.check(s['writers_joined'] and s['final_lifecycle_accounting']=='COMPLETE' and
        s['delivery_confirmation']=='NOT_ESTABLISHED','reply follows joins and final lifecycle, with no receipt claim')
    h.check(s['requested']==('DRAIN' if drain else 'IMMEDIATE'),'request type retained')
    h.check(len(json.dumps(value,separators=(',',':')).encode())<=4096,'complete annotated response within fixed byte ceiling')
    h.check(set(value)=={'format','ok','node','mode','journal_bytes','state_head','authentication','opening_expectation',
        'observation','automatic_update','terminal','shutdown','request_id','principal_uid','principal_gid','principal_pid','command_class'},'no payloads, histories, keys, reasons or identity paths')


def stopped(h: Harness, label: str, d, state: Path, key: Path | None, value, drain=False):
    shape(h,value,drain)
    assert d.process
    d.process.wait(timeout=12);h.check(d.process.returncode==0,'terminal handoff completes process stop');d._close_files()
    h.check(not d.control.exists(),'control path removed on process exit')
    # Cross-UID exposure is test-only and must end before protected offline open.
    restore_owner_only_control(state)
    raw=(state/'state.journal').read_bytes()
    h.check(len(raw)==value['journal_bytes'],'terminal physical byte account equals final stopped file')
    if key:
        independent_open(raw,key)
        h.check(selector(raw,key)==value['state_head']['selector'],'independent complete raw HMAC replay exactly matches returned selector')
    else:h.check(value['authentication'] is None and value['state_head']['selector'] is None,'unkeyed terminal has no fabricated authenticated selector')
    snapshot=inspect(h,label+'-offline',state,key)
    h.check(snapshot['state_head']['selector']==value['state_head']['selector'],'full native semantic replay agrees with stopped head')
    h.check((state/'state.journal').read_bytes()==raw,'complete offline validation changes no journal bytes')
    previous=getattr(h,'previous_binary',None)
    if previous:
        request=[str(previous),'inspect','--state',str(state),'--node','A']
        if key:request+=['--state-auth-key',str(key)]
        result=subprocess.run(request,capture_output=True,text=True,timeout=12)
        h.commands.append({'label':label+'-actual-predecessor','args':request,'returncode':result.returncode,
            'stdout':result.stdout,'stderr':result.stderr})
        h.check(result.returncode==0,'actual predecessor completely replays the same terminal representation')
        prior=json.loads(result.stdout)
        h.check(prior['storage']['logical_state_digest']==snapshot['storage']['logical_state_digest'] and
            prior['state_head']['selector']==value['state_head']['selector'],'actual predecessor logical and authenticated accounts agree')
        h.check((state/'state.journal').read_bytes()==raw,'actual predecessor leaves exact input unchanged')
    report={'terminal_response':value,'journal_sha256':hashlib.sha256(raw).hexdigest(),
        'logical_state_digest':snapshot['storage']['logical_state_digest'],'raw_bytes':len(raw)}
    (h.output/(label+'-HEAD.json')).write_text(json.dumps(report,indent=2)+'\n')
    return snapshot


def run_suite(h: Harness, only):
    def case(name,fn):
        if not only or name in only:h.case(name,fn)

    def keyed_immediate():
        state,key,_,d=setup(h,'immediate');assert key
        live=h.run('before-terminal',['state-head','--control',str(d.control)]);assert live
        value=h.run('immediate-final',args(d));assert value
        snap=stopped(h,'immediate',d,state,key,value)
        h.check(live['state_head']['selector']!=value['state_head']['selector'],'stop authorization/lifecycle are included after prior live sample')
        h.check(value['shutdown']['drain_completed_at_wait_boundary'] is None and value['shutdown']['drain_deadline_reached'] is None,'immediate stop is not a successful drain')
        h.check(value['terminal']['obligations_complete'],'empty fixture has no pending drain obligations')
        h.check(snap['lifecycle']['events'][-1]['kind']=='SHUTDOWN_REQUESTED','existing immediate stop provenance retained')
        h.check(value['opening_expectation']['result']=='NOT_SUPPLIED','no synthetic opening expectation')
    case('keyed_immediate',keyed_immediate)

    def unkeyed_and_legacy():
        state,_,_,d=setup(h,'unkeyed',keyed=False)
        value=h.run('unkeyed-final',args(d));assert value;stopped(h,'unkeyed',d,state,None,value)
        state,key,_,d=setup(h,'legacy');expose_control_for_uid(state)
        # SHUTDOWN alone remains enough for the unchanged default operation.
        value=run_as_uid(h,'legacy-stop-only',STOP_ONLY,STOP_ONLY,
            ['shutdown','--control',str(d.control),'--final-state-head','no','--deadline-ms','5000'],0)
        h.check(value and value['format']=='NATRAV_OVERLAY_CONTROL_SHUTDOWN_V2' and 'state_head' not in value,'default response/authority do not gain head disclosure')
        assert d.process;d.process.wait(timeout=8);h.check(d.process.returncode==0,'legacy shutdown exits');d._close_files();restore_owner_only_control(state)
        state,key,_,d=setup(h,'empty-drain')
        value=h.run('empty-drain-final',args(d,500));assert value;stopped(h,'empty-drain',d,state,key,value,True)
        h.check(value['shutdown']['drain_completed_at_wait_boundary'] is True,'empty drain completes')
    case('unkeyed_and_legacy',unkeyed_and_legacy)

    def strict_protocol():
        state,key,_,d=setup(h,'strict')
        malformed=[packet(42,b'x'),packet(42,packet(42)),b'NOC1',b'NOC2'+bytes([42]),
            packet(43),packet(43,struct.pack('!I',0),text('no')),
            packet(43,struct.pack('!I',600001),text('too long')),
            packet(43,struct.pack('!I',10),text('')),
            packet(43,struct.pack('!I',10),text('ok'),b'x'),
            packet(43,struct.pack('!I',10),b'\x01\x01'+b'x'*257)]
        for i,payload in enumerate(malformed):
            ok,v=raw_control(d.control,payload)
            h.check(not ok and 'state_head' not in v,'malformed final request cannot reveal a head')
            h.check(d.process is not None and d.process.poll() is None,'malformed final request cannot stop the node')
        for command in ('shutdown','drain-shutdown'):
            request=['shutdown','--control',str(d.control)] if command=='shutdown' else ['drain-shutdown','--control',str(d.control),'--reason','test','--drain-deadline-ms','10']
            invalid=h.run('invalid-final-option-'+command,request+['--final-state-head','true'],expected=3)
            h.check(invalid and invalid['code']=='INVALID_ARGUMENT','explicit opt-in accepts only yes/no')
        value=h.run('strict-valid-final',args(d));assert value;stopped(h,'strict',d,state,key,value)
    case('strict_protocol',strict_protocol)

    def separate_authority():
        state,key,_,d=setup(h,'authority');expose_control_for_uid(state)
        for uid in (STOP_ONLY,READ_ONLY):
            for drain in (None,50):
                denied=run_as_uid(h,f'denied-{uid}-{drain}',uid,uid,args(d,drain),3)
                h.check(denied and denied['code']=='LOCAL_CONTROL_CLASS_DENIED' and 'state_head' not in denied,'neither command class alone grants final handoff')
                h.check(d.process is not None and d.process.poll() is None,'authority denial cannot stop the daemon')
        state_status=h.status('still-running-after-class-denials',state,logical_digest=False)
        h.check(state_status['lifecycle']['mode']=='RUNNING','denied handoffs leave lifecycle unchanged')
        value=run_as_uid(h,'both-classes-final',UID,UID,args(d),0);assert value
        h.check(value['principal_uid']==UID,'head is exposed to actual kernel-authenticated client')
        stopped(h,'authority',d,state,key,value)
    case('separate_authority',separate_authority)

    def partial_request_revocation():
        for i,kind in enumerate((42,43)):
            state,key,conf,d=setup(h,'revoke-'+str(kind),env={'NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER':'1'})
            expose_control_for_uid(state)
            payload=packet(kind) if kind==42 else packet(kind,struct.pack('!I',50),text('explicit stop'))
            client=Client(h,d,'partial-final-'+str(kind),payload)
            try:
                revoked=candidate(h,conf,'revoked-final-'+str(kind),'revoked-'+str(kind),lambda t:t.replace(
                    f'local_control={UID},INSPECT,SHUTDOWN',f'local_control={UID},SHUTDOWN'))
                activate(h,'remove-final-inspect-'+str(kind),state,revoked)
                result=client.finish()
                h.check(result.get('code')=='LOCAL_CONTROL_CLASS_DENIED' and 'state_head' not in result,'partial request rechecks current INSPECT after decode')
                h.check(d.process is not None and d.process.poll() is None,'revoked final request does not stop')
            finally:client.close()
            # Grant after connect also applies to the completed request.
            client=Client(h,d,'partial-grant-'+str(kind),payload)
            try:
                granted=candidate(h,revoked,'granted-final-'+str(kind),'granted-'+str(kind),lambda t:t.replace(
                    f'local_control={UID},SHUTDOWN',f'local_control={UID},SHUTDOWN,INSPECT'))
                activate(h,'restore-final-inspect-'+str(kind),state,granted)
                value=client.finish();stopped(h,'revoke-'+str(kind),d,state,key,value,kind==43)
            finally:client.close()
    case('partial_request_revocation',partial_request_revocation)

    def queued_configuration_and_controls():
        state,key,conf,d=setup(h,'queued',env={'NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER':'1',
            'NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_COMMAND':'SHUTDOWN','NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_PAUSE_MS':'650'})
        expose_control_for_uid(state)
        client=Client(h,d,'authorized-final',packet(42),split=False)
        activation=None
        try:
            h.wait('terminal request authorized under leased config',lambda:f'CONTROL_AUTHORIZED SHUTDOWN {UID}' in d.stderr_path.read_text())
            revoked=candidate(h,conf,'queued-revocation','queued-g2',lambda t:t.replace(f'local_control={UID},INSPECT,SHUTDOWN',f'local_control={UID},SHUTDOWN'))
            activation,finish=async_cli(h,'queued-activation',['config-activate','--control',str(d.control),'--candidate',str(revoked),'--reason','queued at stop'])
            h.wait('configuration publication reached handoff',lambda:'CONTROL_CONFIGURATION_HANDOFF' in d.stderr_path.read_text())
            h.check(activation.poll() is None,'configuration waits behind authorized terminal request lease')
            result=finish(3)
            h.check(result['code'] in ('SERVICE_DRAINING','CONFIG_RUNTIME_STOPPING'),'queued configuration rejected after stop, without join deadlock')
            value=client.finish();snap=stopped(h,'queued',d,state,key,value)
            h.check(any(e['command']=='CONFIG_ACTIVATE' and e['decision']=='DENIED' for e in snap['local_control']['entries']),'final stopped head includes queued configuration denial audit')
        finally:
            client.close()
            if activation is not None and activation.poll() is None:activation.kill();activation.wait(timeout=5)
    case('queued_configuration_and_controls',queued_configuration_and_controls)

    def drain_receipts():
        with socket.socket() as reserve:
            reserve.bind(('127.0.0.1',0));port=reserve.getsockname()[1]
            state,key,_,a=setup(h,'receipts',peers=[('B',port)])
            for i in range(8):
                h.run('submit-drain-'+str(i),['submit','--control',str(a.control),'--node','A','--peer','B','--scope','admin/test',
                    '--operation',operation('terminal-receipt-'+str(i)),'--payload-text','retained before stop'])
            proc,finish=async_cli(h,'drain-real-receipts',args(a,3500))
            b=None
            try:
                h.wait('nonempty drain active',lambda:h.status('drain-progress',state,logical_digest=False)['lifecycle']['mode']=='DRAINING')
                before=h.run('earlier-draining-sample',['state-head','--control',str(a.control)]);assert before
                reserve.close();bstate=h.runtime/'receipt-peer';bc=v8_config(h,'receipt-peer','B',bstate,port,'b-g1',[(os.geteuid(),['ALL'])],inbound=['A'])
                b=h.start('receipt-peer',bc,bstate)
                value=finish();snap=stopped(h,'receipts',a,state,key,value,True)
                h.check(value['shutdown']['drain_completed_at_wait_boundary'] is True and value['terminal']['pending_outbound']==0,'real receipt obligations complete before terminal sample')
                h.check(before['state_head']['selector']!=value['state_head']['selector'],'draining observation superseded by receipts and final lifecycle')
                h.check(snap['outbox']['acked']==8,'all eight native TLS receipts remain durable')
                h.check(snap['lifecycle']['events'][-1]['kind']=='DRAIN_COMPLETED','final lifecycle follows all worker writes')
            finally:
                if proc.poll() is None:proc.kill();proc.wait(timeout=5)
                if b:b.shutdown()
    case('drain_receipts',drain_receipts)

    def drain_timeout_and_response_loss():
        with socket.socket() as reserve:
            reserve.bind(('127.0.0.1',0));port=reserve.getsockname()[1]
            state,key,_,d=setup(h,'timeout',peers=[('B',port)],env={'NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER':'1'})
            h.run('pending-timeout',['submit','--control',str(d.control),'--node','A','--peer','B','--scope','admin/test',
                '--operation',operation('terminal-timeout'),'--payload-text','not delivered'])
            expose_control_for_uid(state)
            # This queued reader keeps a control worker alive past the drain deadline.
            delayed=Client(h,d,'delayed-denial',packet(42),uid=READ_ONLY)
            proc,finish=async_cli(h,'timeout-final',args(d,100))
            try:
                time.sleep(.25)
                h.check(proc.poll() is None,'no terminal reply while a partially read control worker can still append')
                denied=delayed.finish();h.check(denied.get('code')=='LOCAL_CONTROL_CLASS_DENIED','late partial control contributes a denial, never another stop')
                value=finish();snap=stopped(h,'timeout',d,state,key,value,True)
                h.check(value['shutdown']['drain_deadline_reached'] is True and value['terminal']['pending_outbound']==1 and not value['terminal']['obligations_complete'],'deadline stop preserves and labels pending obligations')
                h.check(snap['lifecycle']['events'][-1]['kind']=='DRAIN_DEADLINE','terminal drain record follows queued denial and joins')
            finally:
                delayed.close()
                if proc.poll() is None:proc.kill();proc.wait(timeout=5)
        state,key,_,d=setup(h,'lost-response',env={'NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER':'1',
            'NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_COMMAND':'SHUTDOWN','NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_PAUSE_MS':'350'})
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as s:
            s.connect(str(d.control));p=packet(42);s.sendall(struct.pack('!I',len(p))+p);s.shutdown(socket.SHUT_WR)
            h.wait('lost response request authorized',lambda:'CONTROL_AUTHORIZED SHUTDOWN' in d.stderr_path.read_text())
            s.setsockopt(socket.SOL_SOCKET,socket.SO_LINGER,struct.pack('ii',1,0))
        assert d.process;d.process.wait(timeout=10);h.check(d.process.returncode==0,'accepted explicit stop is not cancelled by reply loss');d._close_files()
        snap=inspect(h,'response-loss-replay',state,key)
        assert key;h.check(snap['state_head']['selector']==selector((state/'state.journal').read_bytes(),key),'lost handoff still leaves independently replayable final state')
        log=[json.loads(x) for x in d.stdout_path.read_text().splitlines() if x.startswith('{')][-1]
        h.check(log['terminal_head_handoff'] in ('RESPONSE_LOST','SENT_UNCONFIRMED'),'server never labels an unacknowledged response as received')
    case('drain_timeout_and_response_loss',drain_timeout_and_response_loss)

    def compaction_expectation_restart():
        state,key,conf,d=setup(h,'expectation');assert key
        first=h.run('first-final',args(d));assert first;stopped(h,'expectation-first',d,state,key,first)
        d=start_expected(h,'expected-start',conf,state,key,first['state_head']['selector'])
        h.run('compact-before-final',['compact','--control',str(d.control),'--deadline-ms','5000'])
        value=h.run('second-final',args(d,500));assert value;stopped(h,'expectation-second',d,state,key,value,True)
        h.check(value['opening_expectation']['result']=='MATCHED_AT_OPEN' and value['opening_expectation']['matches_observation'] is False,'opening match remains historical after compaction and stop')
        old=selected(h,'stale-opening-pin',state,key,first['state_head']['selector'],3)
        h.check(old['code']=='STATE_HEAD_EXPECTATION_MISMATCH','previous process head is not automatically refreshed')
        selected(h,'explicit-new-head',state,key,value['state_head']['selector'])
        d=start_expected(h,'new-terminal-start',conf,state,key,value['state_head']['selector'])
        d.shutdown()
    case('compaction_expectation_restart',compaction_expectation_restart)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append',choices=CASES)
    p.add_argument('--previous-binary',type=Path)
    a=p.parse_args()
    if a.output.exists():p.error('output already exists')
    h=Harness(a.binary,a.output);begin=time.time();code=1
    h.previous_binary=a.previous_binary.resolve(strict=True) if a.previous_binary else None
    try:run_suite(h,set(a.case) if a.case else None);code=0
    except BaseException as e:
        import traceback
        (h.output/'FAILURE.txt').write_text(traceback.format_exc());print(f'FAIL: {type(e).__name__}: {e}',file=os.sys.stderr)
    finally:
        h.cleanup()
        summary={'format':'NATRAV_OVERLAY_TERMINAL_STATE_HEAD_TESTS_V1','status':'PASS' if code==0 else 'FAIL',
            'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_passed':sum(c['status']=='PASS' for c in h.cases),
            'cases_total':len(h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-begin}
        for n,o in (('SUMMARY.json',summary),('CASES.json',h.cases),('COMMANDS.json',h.commands)):(h.output/n).write_text(json.dumps(o,indent=2)+'\n')
        print(json.dumps(summary))
    return code
if __name__=='__main__':raise SystemExit(main())
