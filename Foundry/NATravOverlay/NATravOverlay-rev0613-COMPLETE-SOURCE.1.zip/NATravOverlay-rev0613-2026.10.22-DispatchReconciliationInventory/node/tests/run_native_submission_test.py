#!/usr/bin/env python3
"""Build the production NodeState with a native test main in an isolated copy."""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, subprocess, time
from pathlib import Path


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',required=True,type=Path)
    p.add_argument('--mode',choices=('static','sanitize'),default='static')
    a=p.parse_args();root=Path(__file__).resolve().parents[2];out=a.output.resolve()
    if out.exists() or out==root or root in out.parents:p.error('output must be new and outside the source workspace')
    source=out/'source';source.mkdir(parents=True)
    for name in ('node/src','foundation/src','foundation/include'):
        shutil.copytree(root/name,source/name)
    shutil.copy2(root/'node/build.sh',source/'node/build.sh')
    shutil.copy2(root/'node/tests/test_submission_metadata.cpp',source/'node/src/main.cpp')
    env=dict(os.environ,JOBS='2',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    started=time.monotonic()
    with (out/'BUILD.log').open('w') as f:
        build=subprocess.run(['./node/build.sh',a.mode],cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
    result={'format':'NATRAV_NATIVE_SUBMISSION_BUILD_V1','mode':a.mode,'build_returncode':build.returncode,'status':'FAIL','source_test_sha256':hashlib.sha256((root/'node/tests/test_submission_metadata.cpp').read_bytes()).hexdigest()}
    if build.returncode==0:
        binary=source/'node/bin'/('natrav-overlay' if a.mode=='static' else 'natrav-overlay-sanitize')
        run=subprocess.run([str(binary)],env=env,text=True,capture_output=True,timeout=60)
        (out/'stdout.txt').write_text(run.stdout);(out/'stderr.txt').write_text(run.stderr)
        result.update(returncode=run.returncode,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
        if run.returncode==0:
            result['test']=json.loads(run.stdout);result['status']='PASS'
    result['elapsed_seconds']=time.monotonic()-started
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
    return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
