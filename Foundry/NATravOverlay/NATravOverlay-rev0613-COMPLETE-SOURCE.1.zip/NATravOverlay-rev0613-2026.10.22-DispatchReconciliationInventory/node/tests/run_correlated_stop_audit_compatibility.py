#!/usr/bin/env python3
"""Actual revision-0569 rejection of the offline audit command and replay compatibility."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time
import traceback

from run_persistent import Harness
from run_correlated_stopping import request_id
from run_correlated_terminal_state_head import (
    correlated_terminal_shutdown,
    setup_keyed,
    terminal_args,
)
from run_response_loss_stopping import wait_stopped
from run_state_authentication import inspect
from run_correlated_stop_audit import audit, check_common, shape_immediate


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--predecessor-binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    harness = Harness(args.binary, args.output)
    release = harness.binary
    predecessor = args.predecessor_binary.resolve(strict=True)
    started = time.time()
    code = 1
    try:
        def compatibility() -> None:
            token = "offline-audit-compat-0570"
            expected_id = request_id(correlated_terminal_shutdown(token))
            _, state, key, _, daemon = setup_keyed(harness, "offline-audit-compat")
            terminal = harness.run(
                "current-correlated-terminal-stop",
                terminal_args(daemon.control, token),
                timeout=20,
            )
            assert terminal is not None
            wait_stopped(harness, daemon, "offline audit compatibility source")
            before = (state / "state.journal").read_bytes()
            current = audit(
                harness,
                "current-offline-correlated-stop-audit",
                state,
                key,
                shape_immediate(token),
            )
            check_common(harness, current, expected_id)
            current_snapshot = inspect(
                harness,
                "current-offline-compatibility-inspect",
                state,
                key,
            )

            harness.binary = predecessor
            rejected = harness.run(
                "predecessor-rejects-offline-audit-command",
                ["correlated-stop-audit"],
                expected=3,
            )
            harness.check(
                rejected is not None and rejected.get("code") == "UNKNOWN_COMMAND",
                "revision 0569 fails closed on the new CLI command",
            )
            previous_snapshot = inspect(
                harness,
                "predecessor-replays-current-stopped-state",
                state,
                key,
            )
            harness.check(
                previous_snapshot["storage"]["logical_state_digest"] ==
                current_snapshot["storage"]["logical_state_digest"],
                "predecessor and current release derive the same logical state",
            )
            harness.check(
                previous_snapshot["state_head"]["selector"] ==
                current["state_head"]["selector"],
                "predecessor and current release derive the same authenticated head",
            )
            harness.check(
                (state / "state.journal").read_bytes() == before,
                "predecessor rejection and replay leave exact bytes unchanged",
            )

        harness.case("actual_revision_0569_cli_and_durable_replay", compatibility)
        code = 0
    except BaseException:
        (harness.output / "FAILURE.txt").write_text(traceback.format_exc())
    finally:
        harness.binary = release
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_CORRELATED_STOP_AUDIT_COMPATIBILITY_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(release.read_bytes()).hexdigest(),
            "predecessor_sha256": hashlib.sha256(predecessor.read_bytes()).hexdigest(),
            "cases_passed": sum(item["status"] == "PASS" for item in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (
            ("SUMMARY.json", summary),
            ("CASES.json", harness.cases),
            ("COMMANDS.json", harness.commands),
        ):
            (harness.output / name).write_text(json.dumps(value, indent=2) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
