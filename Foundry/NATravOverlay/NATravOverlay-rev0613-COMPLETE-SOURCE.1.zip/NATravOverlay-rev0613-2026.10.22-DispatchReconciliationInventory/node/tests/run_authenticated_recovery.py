#!/usr/bin/env python3
"""Read-only audit, deliberate verified-prefix adoption, and real C++ recovery.

All corruption and process kills are confined to owned disposable fixtures.
Independent Python HMAC framing is not an independent cryptographic audit.
"""
from __future__ import annotations
import argparse
import hashlib
import hmac
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import struct
import subprocess
import time
from typing import Any

from run_persistent import Harness, operation, free_port
from run_state_authentication import (inspect, new_key, migrate, start,
                                     independent_open, independent_seal, checksum_frame, key_parts, HEADER_DOMAIN)
from run_authorization_actions import (submit_evidence, submit_action, outbox_entry,
                                       independent_record, action_payload)
from run_local_administration import v8_config
from run_live_configuration import candidate

CASES = ["audit_and_expected_head", "incomplete_and_invalid_boundaries", "explicit_selection_and_source_custody",
         "semantic_invalid_prefix", "publication_kills_and_exclusive_ownership", "native_partial_append_kill",
         "delivery_actions_compaction_encrypted_restore"]


def audit(h: Harness, label: str, state: Path, key: Path, expected: int = 0,
          extra: list[str] | None = None, node: str = "A") -> dict[str, Any]:
    value = h.run(label, ["state-auth-audit", "--state", str(state), "--node", node,
                          "--state-auth-key", str(key), *(extra or [])], expected=expected)
    assert value is not None
    return value


def recover_args(state: Path, key: Path, report: dict[str, Any], evidence: Path) -> list[str]:
    return ["state-auth-recover", "--state", str(state), "--node", "A", "--state-auth-key", str(key),
            "--source-sha256", report["source_sha256"], "--prefix-bytes", str(report["verified_bytes"]),
            "--prefix-records", str(report["state_authentication"]["records"]),
            "--prefix-root", report["state_authentication"]["root"],
            "--preserve-source", str(evidence), "--reason", "explicitly adopt the selected verified prefix"]


def incomplete_next(raw: bytes, key: Path, count: int = 60) -> bytes:
    header, frames, _, _ = independent_open(raw, key)
    # The unverified frame is intentionally only a plausible append. No claim is
    # made that its body could be applied if it had reached disk completely.
    extended = independent_seal(header, frames + [frames[-1]], key)
    assert len(extended) > len(raw) + count
    return raw + extended[len(raw):len(raw)+count]


def setup(h: Harness, name: str, with_appends: bool = False) -> tuple[Path, Path, Path]:
    root = h.runtime / name
    root.mkdir(mode=0o700)
    state = root / "state"
    inspect(h, name+"-init", state)
    key = new_key(h, root, name+"-key")
    migrate(h, name+"-migrate", state, key)
    if with_appends:
        conf = h.config(name, "A", state, free_port(), [("B", free_port(), 100, 100, 10, 60000)])
        d = start(h, name, conf, state, key)
        submit_evidence(h, name+"-queue", d.control, "A", "B", "test/data", operation(name), "preserved pending bytes")
        d.shutdown()
    return root, state, key


def file_accounts(directory: Path) -> dict[str, Any]:
    return {p.name: (p.stat().st_ino, stat.S_IMODE(p.stat().st_mode), p.stat().st_mtime_ns,
                     hashlib.sha256(p.read_bytes()).hexdigest())
            for p in directory.iterdir() if p.is_file()}


def independent_recovery_history(raw: bytes, key: Path) -> tuple[list[dict[str, Any]], int]:
    header, _, _, _ = independent_open(raw, key)
    body = header[12:-32]; at = 0
    def take(n: int) -> bytes:
        nonlocal at
        value = body[at:at+n]; assert len(value) == n; at += n
        return value
    def integer(n: int) -> int: return int.from_bytes(take(n), "big")
    def text() -> str: return take(integer(2)).decode("ascii")
    assert integer(4) == 2 and integer(4) == 2
    text(); text(); take(128); text()
    for _ in range(integer(2)):
        integer(1); text(); take(32); integer(8); integer(4); text(); take(32)
    result = []; source_offset = 0
    for _ in range(integer(2)):
        value = {field:take(32).hex() for field in
                 ("source_sha256","discarded_sha256","prefix_sha256","selected_root","selected_epoch")}
        value["generation"] = text(); value["key_id"] = take(32).hex()
        value["selected_records"] = integer(8)
        source_offset = 12 + at
        value["source_bytes"] = integer(8); value["prefix_bytes"] = integer(8)
        value["unix_ms"] = integer(8); value["uid"] = integer(4); value["pid"] = integer(4)
        value["reason"] = text(); result.append(value)
    assert at == len(body) and result
    return result, source_offset


def run_suite(h: Harness, selected: set[str] | None) -> None:
    def case(name: str, fn: Any) -> None:
        if selected is None or name in selected:
            h.case(name, fn)

    def audit_and_expected_head() -> None:
        root, state, key = setup(h, "audit", True)
        raw = (state/"state.journal").read_bytes()
        header, frames, root_hash, outer = independent_open(raw, key)
        stale = state/"state.journal.compact.tmp"; stale.write_bytes(b"unpublished candidate must remain untouched")
        os.chmod(stale, 0o600)
        before = file_accounts(state)
        result = audit(h, "audit-complete", state, key)
        h.check(result["status"] == "COMPLETE" and result["verified_bytes"] == len(raw), "exact complete boundary")
        h.check(result["state_authentication"]["root"] == root_hash.hex() and result["state_authentication"]["records"] == len(frames), "independently matched root and sequence")
        h.check(result["source_sha256"] == hashlib.sha256(raw).hexdigest(), "independent source digest")
        exact = ["--expected-root", root_hash.hex(), "--expected-records", str(len(frames))]
        h.check(audit(h, "expected-exact", state, key, extra=exact)["expected_head"] == "MATCH", "exact expected head match")
        wrong = audit(h, "expected-wrong", state, key, 3, ["--expected-root", "11"*32, "--expected-records", str(len(frames))])
        h.check(wrong["code"] == "STATE_AUTH_EXPECTED_HEAD_MISMATCH", "independently supplied head mismatch")
        h.check(file_accounts(state) == before, "audit does not change file set, inode, mode, mtime, or bytes; leaves stale candidate")
        wrongkey = new_key(h, root, "wrong-audit-key")
        denied = audit(h, "audit-wrong-key", state, wrongkey, 3)
        h.check(denied["status"] == "INVALID" and denied["verified_bytes"] == 0 and not denied["recovery_eligible"], "wrong key never exposes a selected authenticated prefix")
        h.check(file_accounts(state) == before, "wrong key also nonmutating")
        saved_lock = (state/"state.lock").read_bytes(); (state/"state.lock").unlink()
        denied=audit(h,"audit-missing-lock",state,key,3)
        h.check(denied["code"]=="STATE_AUTH_SOURCE_UNSAFE" and not (state/"state.lock").exists(),"audit never creates a missing lock")
        (state/"state.lock").write_bytes(saved_lock);os.chmod(state/"state.lock",0o600)
        # A valid old prefix is not intrinsically fresh. An independent exact head can detect it.
        older = header + b"".join(outer[:-1]); assert len(outer) >= 2
        (state/"state.journal").write_bytes(older)
        h.check(audit(h, "old-valid-prefix", state, key)["freshness"] == "NOT_ESTABLISHED", "valid old prefix is not freshness proof")
        h.check(audit(h, "old-prefix-vs-head", state, key, 3, exact)["expected_head"] == "MISMATCH", "retained exact head detects selected old prefix")
        (state/"state.journal").write_bytes(raw)
    case("audit_and_expected_head", audit_and_expected_head)

    def incomplete_and_invalid_boundaries() -> None:
        root, state, key = setup(h, "boundaries", True)
        journal = state/"state.journal"; original = journal.read_bytes()
        header, frames, _, records = independent_open(original, key)
        prefix = header + b"".join(records[:-1]); last = records[-1]
        # Exercise the outer header, inner header/body and tag boundaries independently.
        cuts = sorted(set([1,2,3,4,5,7,8,9,15,16,17,31,32,47,48,49,51,52,55,56,57,60,
                           len(last)-33,len(last)-32,len(last)-31,len(last)-1]))
        for cut in cuts:
            if not 0 < cut < len(last): continue
            journal.write_bytes(prefix + last[:cut])
            result = audit(h, f"incomplete-{cut}", state, key, 3)
            h.check(result["status"] == "INCOMPLETE_TAIL" and result["recovery_eligible"], f"plausible incomplete tail at {cut}")
            h.check(result["verified_bytes"] == len(prefix) and result["state_authentication"]["records"] == len(records)-1, "exact maximal verified prefix")
            h.check(journal.read_bytes() == prefix+last[:cut], "audit never truncates")
        bad = bytearray(original); bad[-1] ^= 1
        journal.write_bytes(bad)
        result = audit(h, "complete-bad-tag", state, key, 3)
        h.check(result["status"] == "INVALID" and result["code"] == "STATE_AUTH_TAG_MISMATCH" and not result["recovery_eligible"], "complete MAC failure is not a recoverable tail")
        rejected = h.run("never-recover-bad-tag", recover_args(state, key, result, root/"forbidden-source.bin"), expected=3)
        h.check(rejected and rejected["code"] == "STATE_AUTH_RECOVERY_NOT_ELIGIBLE", "recovery policy rejects complete invalid MAC")
        h.check(journal.read_bytes() == bad and not (root/"forbidden-source.bin").exists(), "bad MAC remains intact; no evidence/candidate published")
        for label, broken in [("partial-wrong-sequence", prefix + last[:8] + b"\xff"),
                              ("wrong-magic", prefix+b"X"),
                              ("no-checkpoint", header+records[0][:20]),
                              ("partial-header", original[:20])]:
            journal.write_bytes(broken)
            result = audit(h, label, state, key, 3)
            h.check(result["status"] == "INVALID" and not result["recovery_eligible"], label+" is not recoverable")
        journal.write_bytes(original)
        full = audit(h, "complete-not-recovery", state, key)
        denied = h.run("reject-complete-recovery", recover_args(state,key,full,root/"unneeded.bin"),expected=3)
        h.check(denied and denied["code"] == "STATE_AUTH_RECOVERY_NOT_ELIGIBLE", "complete valid state cannot be rolled back through recovery")
    case("incomplete_and_invalid_boundaries", incomplete_and_invalid_boundaries)

    def explicit_selection_and_source_custody() -> None:
        root, state, key = setup(h, "selection", True)
        journal = state/"state.journal"; good = journal.read_bytes()
        before = inspect(h, "selected-before", state, key)
        source = incomplete_next(good, key); journal.write_bytes(source)
        report = audit(h, "select-prefix", state, key, 3)
        evidence = root/"original.bin"
        command = recover_args(state, key, report, evidence)
        for field, value in [("--source-sha256","22"*32),("--prefix-root","33"*32),
                             ("--prefix-bytes",str(len(good)-1)),("--prefix-records","999999")]:
            broken = list(command); broken[broken.index(field)+1] = value
            denied = h.run("selection-mismatch-"+field[2:],broken,expected=3)
            h.check(denied and denied["code"] == "STATE_AUTH_RECOVERY_SELECTION_MISMATCH", "exact selection required")
            h.check(journal.read_bytes() == source and not evidence.exists(), "selection refusal changes nothing")
        evidence.write_bytes(b"do not overwrite"); os.chmod(evidence,0o600)
        denied=h.run("evidence-no-overwrite",command,expected=3)
        h.check(denied and denied["code"]=="STATE_AUTH_EVIDENCE_EXISTS" and evidence.read_bytes()==b"do not overwrite", "evidence publication no overwrite")
        h.check(journal.read_bytes()==source,"source intact on evidence collision")
        evidence.unlink()
        for label, path in (("inside-state", state/"state.journal.compact.tmp"),
                            ("symlink-parent", root/"linked"/"source.bin")):
            if label == "symlink-parent": (root/"linked").symlink_to(root, target_is_directory=True)
            badpath = recover_args(state,key,report,path)
            denied = h.run("unsafe-evidence-"+label,badpath,expected=3)
            h.check(denied and denied["code"] in ("STATE_AUTH_EVIDENCE_PATH_INVALID","STATE_AUTH_SOURCE_UNSAFE"),"unsafe source custody is rejected")
            h.check(journal.read_bytes()==source,"unsafe custody never replaces source")
        changed = subprocess.run([str(h.binary),*command],capture_output=True,text=True,timeout=10,
            env=dict(os.environ,NATRAV_OVERLAY_TEST_STATE_AUTH_RECOVERY_CORRUPT_CANDIDATE="1"))
        h.commands.append({"label":"corrupt-recovery-candidate","args":command,"returncode":changed.returncode,"stdout":changed.stdout,"stderr":changed.stderr})
        h.check(changed.returncode==3 and json.loads(changed.stdout)["code"]=="STATE_AUTH_TAG_MISMATCH", "actual on-disk recovery candidate must authenticate")
        h.check(journal.read_bytes()==source and not evidence.exists(),"candidate rejection leaves source and evidence untouched")
        recovered=h.run("adopt-selected-prefix",command); assert recovered
        h.check(recovered["logical_state_digest"]==before["storage"]["logical_state_digest"],"application state preserved exactly")
        h.check(evidence.read_bytes()==source and stat.S_IMODE(evidence.stat().st_mode)==0o600 and evidence.stat().st_nlink==1,"entire source preserved mode0600 single-link")
        h.check(journal.stat().st_ino != evidence.stat().st_ino,"evidence is a separate copy, not journal hardlink")
        now=inspect(h,"adopted-inspect",state,key)
        entry=now["storage"]["state_authentication"]["recoveries"][-1]
        h.check(entry["source_sha256"]==hashlib.sha256(source).hexdigest() and entry["prefix_sha256"]==hashlib.sha256(good).hexdigest(),"source and selected prefix digests retained")
        h.check(entry["discarded_sha256"]==hashlib.sha256(source[len(good):]).hexdigest() and entry["discarded_bytes"]==60,"discarded-byte provenance")
        h.check(entry["uid"]==os.geteuid() and entry["pid"]>0 and entry["cause"]=="NOT_ESTABLISHED","kernel actor and honest cause")
        repaired = journal.read_bytes()
        decoded, source_offset = independent_recovery_history(repaired,key)
        h.check(all(entry[k]==v for k,v in decoded[-1].items()),"independent V2 recovery-field decoder matches native provenance")
        h.check(entry["generation"]=="selection-key", "recovery retains exact historical key generation")
        # Authentic bytes with impossible provenance must fail semantic header validation.
        header, frames, _, _ = independent_open(repaired,key)
        corrupted = bytearray(header)
        corrupted[source_offset:source_offset+8] = struct.pack("!Q",entry["prefix_bytes"])
        _, secret, _ = key_parts(key)
        corrupted[-32:] = hmac.digest(secret,HEADER_DOMAIN+bytes(corrupted[:-32]),"sha256")
        journal.write_bytes(independent_seal(bytes(corrupted),frames,key))
        bad_history=audit(h,"authenticated-invalid-recovery-history",state,key,3)
        h.check(bad_history["code"]=="STATE_AUTH_RECOVERY_HISTORY_INVALID" and not bad_history["recovery_eligible"],"valid MAC cannot excuse impossible recovery provenance")
        journal.write_bytes(repaired)
        h.check(audit(h,"adopted-audit",state,key)["status"]=="COMPLETE","new authenticated representation is complete")
    case("explicit_selection_and_source_custody", explicit_selection_and_source_custody)

    def semantic_invalid_prefix() -> None:
        root,state,key=setup(h,"semantic")
        journal=state/"state.journal"
        header,frames,_,_=independent_open(journal.read_bytes(),key)
        invalid=bytearray(frames[0]);invalid[8]=255
        forged=independent_seal(header,frames+[checksum_frame(bytes(invalid))],key)
        journal.write_bytes(incomplete_next(forged,key))
        result=audit(h,"authenticated-but-semantically-invalid",state,key,3)
        h.check(result["status"]=="INVALID" and not result["prefix_semantics_valid"] and not result["recovery_eligible"],"valid HMAC does not waive semantic replay")
        denied=h.run("semantic-recovery-denied",recover_args(state,key,result,root/"invalid.bin"),expected=3)
        h.check(denied and denied["code"]=="STATE_AUTH_RECOVERY_NOT_ELIGIBLE", "cannot bless malformed application state")
    case("semantic_invalid_prefix", semantic_invalid_prefix)

    def publication_kills_and_exclusive_ownership() -> None:
        for when in ("BEFORE","AFTER"):
            root,state,key=setup(h,"publish-"+when.lower())
            journal=state/"state.journal";good=journal.read_bytes();source=incomplete_next(good,key);journal.write_bytes(source)
            selected=audit(h,"publication-selection-"+when,state,key,3)
            command=recover_args(state,key,selected,root/"preserved.bin")
            log=h.logs/("recovery-"+when+".stderr")
            with log.open("w") as err:
                child=subprocess.Popen([str(h.binary),*command],stdout=subprocess.DEVNULL,stderr=err,
                    env=dict(os.environ,**{f"NATRAV_OVERLAY_TEST_STATE_AUTH_RECOVERY_{when}_PUBLISH_MS":"10000"}))
                try:
                    h.wait("recovery publication pause "+when,lambda:("RECOVERY_"+when+"_PUBLISH") in log.read_text(),8)
                    denied=audit(h,"audit-owner-contention-"+when,state,key,3)
                    h.check(denied["code"]=="STATE_BUSY","audit respects stable ownership")
                    competing=h.run("recovery-owner-contention-"+when,command,expected=3)
                    h.check(competing and competing["code"]=="STATE_BUSY","competing recovery cannot publish")
                    child.send_signal(signal.SIGKILL);child.wait(timeout=5)
                    h.check(child.returncode==-signal.SIGKILL,"actual publication kill")
                    h.commands.append({"label":"recovery-kill-"+when,"args":command,"returncode":child.returncode})
                finally:
                    if child.poll() is None:child.kill();child.wait(timeout=5)
            h.check((root/"preserved.bin").read_bytes()==source,"original evidence survives either kill boundary")
            if when=="BEFORE":
                h.check(journal.read_bytes()==source,"before publication source remains authoritative")
                audit(h,"still-incomplete-after-before-kill",state,key,3)
                h.run("retry-after-before-kill",recover_args(state,key,selected,root/"retry-evidence.bin"))
            else:
                h.check(journal.read_bytes()!=source,"after publication fresh checkpoint authoritative")
            result=audit(h,"after-publication-kill-"+when,state,key)
            h.check(len(result["state_authentication"]["recoveries"])==1,"exactly one accepted recovery")
    case("publication_kills_and_exclusive_ownership",publication_kills_and_exclusive_ownership)

    def native_partial_append_kill() -> None:
        root,state,key=setup(h,"native-torn")
        conf=h.config("native-torn","A",state,free_port(),[("B",free_port(),100,100,10,60000)])
        before=audit(h,"before-native-torn",state,key)
        d=start(h,"native-torn",conf,state,key,{"NATRAV_OVERLAY_TEST_STATE_AUTH_PARTIAL_APPEND_MS":"10000"})
        command=["submit","--control",str(d.control),"--node","A","--peer","B","--scope","test/data",
                 "--operation",operation("native-torn"),"--payload-text","uncommitted submission","--deadline-ms","10000"]
        client=subprocess.Popen([str(h.binary),*command],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        try:
            h.wait("native synchronized partial append",lambda:"STATE_AUTH_TEST_PAUSE PARTIAL_APPEND" in d.stderr_path.read_text(),8)
            d.kill();client.wait(timeout=5)
            h.commands.append({"label":"native-partial-append-client","args":command,"returncode":client.returncode})
        finally:
            if client.poll() is None:client.kill();client.wait(timeout=5)
        failed=inspect(h,"normal-start-still-fails-closed",state,key,3)
        h.check(failed["code"]=="STATE_AUTH_TRUNCATED","normal opening does not automatically truncate")
        report=audit(h,"native-partial-audit",state,key,3)
        h.check(report["verified_bytes"]==before["verified_bytes"] and report["unverified_bytes"]==60,"real partial append boundary")
        h.run("native-explicit-recovery",recover_args(state,key,report,root/"actual-crash-source.bin"))
        reopened=start(h,"native-after-recovery",conf,state,key)
        submit_evidence(h,"native-new-work",reopened.control,"A","B","test/data",operation("native-new"),"durably queued after recovery")
        reopened.shutdown()
        final=inspect(h,"native-recovered-final",state,key)
        h.check(final["outbox"]["count"]==1,"incomplete admission not invented; new work queued once")
        independent_open((state/"state.journal").read_bytes(),key)
    case("native_partial_append_kill",native_partial_append_kill)

    def delivery_actions_compaction_encrypted_restore() -> None:
        root=h.runtime/"recovery-continuation";root.mkdir(mode=0o700)
        a,b,c=root/"a",root/"b",root/"c"
        ap,bp,cp=free_port(),free_port(),free_port();grants=[(os.geteuid(),["ALL"])]
        ac=v8_config(h,"recovery-a","A",a,ap,"a-initial",grants,peers=[("B",bp),("C",cp)])
        ac.write_text(ac.read_text()+"authorize=B,*,ACTION,counter.add\n")
        bc=v8_config(h,"recovery-b","B",b,bp,"b-initial",grants,peers=[("A",ap)])
        cc=v8_config(h,"recovery-c","C",c,cp,"c-initial",grants,inbound=["A"])
        da,db=h.start("recovery-a-unkeyed",ac,a),h.start("recovery-b",bc,b)
        action,pending,rejected=map(operation,["recover-action","recover-pending","recover-rejected"])
        submit_action(h,"recovery-action",db.control,"B","A",action,7)
        h.wait("pre-recovery action completed",lambda:h.status("action-before",a)["actions"]["counter_value"]==7)
        submit_evidence(h,"recovery-pending",da.control,"A","C","admin/test",pending,"durable pending payload")
        submit_evidence(h,"recovery-rejected",da.control,"A","B","forbidden/scope",rejected,"denied")
        h.wait("pre-recovery terminal rejection",lambda:outbox_entry(h.status("rejected-before",a),rejected)["status"]=="REJECTED")
        da.shutdown();db.shutdown()
        key=new_key(h,root,"recovered-auth-1");migrate(h,"migrate-rich-state",a,key)
        good=(a/"state.journal").read_bytes();before=inspect(h,"rich-prefix-before",a,key)
        (a/"state.journal").write_bytes(incomplete_next(good,key))
        selected=audit(h,"rich-prefix-select",a,key,3)
        h.run("rich-prefix-recover",recover_args(a,key,selected,root/"rich-source.bin"))
        h.check(inspect(h,"rich-prefix-after",a,key)["storage"]["logical_state_digest"]==before["storage"]["logical_state_digest"],"rich evidence, actions, rejections and obligations preserved")
        da=start(h,"rich-recovered-a",ac,a,key)
        h.run("rich-compact",["compact","--control",str(da.control),"--deadline-ms","10000"])
        da.shutdown()
        snapshot=inspect(h,"rich-before-export",a,key)
        enc=root/"enc.key";h.run("recovery-backup-key",["backup-key-init","--output",str(enc),"--generation","backup-1"])
        ident=h.identity("A");archive=root/"recovered.nob"
        h.run("recovery-signed-encrypted-export",["backup-export","--state",str(a),"--node","A","--generation","a-g1","--output",str(archive),
            "--sign-key",str(ident.private_key),"--sign-cert",str(ident.certificate),"--encrypt-key",str(enc),"--state-auth-key",str(key)])
        verify=["--input",str(archive),"--node","A","--generation","a-g1","--decrypt-key",str(enc),"--trusted-cert",str(ident.certificate),"--require-signature","yes","--state-auth-key",str(key)]
        h.run("recovery-backup-verify",["backup-verify",*verify])
        moved=root/"moved";h.run("recovery-backup-restore",["backup-restore",*verify,"--destination",str(moved)])
        restored=inspect(h,"recovery-restored",moved,key)
        h.check(restored["storage"]["logical_state_digest"]==snapshot["storage"]["logical_state_digest"],"exact offline restored logical equality")
        h.check(restored["storage"]["state_authentication"]["recoveries"]==snapshot["storage"]["state_authentication"]["recoveries"],"recovery provenance survives compaction and encrypted signed backup")
        relocated=candidate(h,ac,"recovered-moved","a-moved",lambda text:text.replace(f"state={a}",f"state={moved}"))
        h.run("recovery-relocation",["state-relocate","--state",str(moved),"--node","A","--candidate",str(relocated),"--reason","recovery continuation","--state-auth-key",str(key)])
        dc=h.start("recovery-c",cc,c);da=start(h,"recovered-moved",relocated,moved,key)
        h.wait("recovered pending delivery",lambda:outbox_entry(h.status("recovery-delivery",moved),pending)["status"]=="ACKED")
        reply=independent_record(h,ap,"B","B","A",action,"actions/counter.add/v1",action_payload(7))
        h.check(reply["kind"]=="receipt" and reply["disposition"]==2,"completed action replay duplicate receipt")
        h.check(h.status("recovery-counter",moved)["actions"]["counter_value"]==7,"recovery never duplicates committed counter effect")
        da.shutdown()
        key2=new_key(h,root,"recovered-auth-2")
        h.run("recovered-key-rotate",["state-auth-rotate","--state",str(moved),"--node","A","--state-auth-key",str(key),"--new-key",str(key2),"--reason","rotate after recovery"])
        da=start(h,"recovered-rotated",relocated,moved,key2)
        later=operation("after-recovery-rotation")
        submit_evidence(h,"new-after-recovery",da.control,"A","C","admin/test",later,"new work after recovery and rotation")
        h.wait("new recovered delivery",lambda:outbox_entry(h.status("new-recovery-status",moved),later)["status"]=="ACKED")
        da.shutdown();dc.shutdown()
        final=inspect(h,"recovery-final",moved,key2);receiver=inspect(h,"recovery-recipient",c,node="C")
        h.check(receiver["inbound"]["count"]==2,"two distinct records admitted exactly once")
        h.check(final["actions"]["counter_value"]==7 and len(final["storage"]["state_authentication"]["recoveries"])==1,"effect and recovery history survive rotation and new appends")
        h.check(final["storage"]["state_authentication"]["recoveries"][0]["generation"]=="recovered-auth-1", "rotation does not relabel historical recovery key")
        independent_open((moved/"state.journal").read_bytes(),key2)
    case("delivery_actions_compaction_encrypted_restore",delivery_actions_compaction_encrypted_restore)


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--binary",type=Path,required=True);p.add_argument("--output",type=Path,required=True)
    p.add_argument("--case",action="append",choices=CASES)
    a=p.parse_args()
    if a.output.exists():p.error("output already exists")
    h=Harness(a.binary,a.output);started=time.time();code=1
    try:
        run_suite(h,set(a.case) if a.case else None);code=0
    except BaseException as exc:
        (h.output/"FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}",file=os.sys.stderr)
    finally:
        h.cleanup()
        summary={"format":"NATRAV_OVERLAY_AUTH_RECOVERY_TESTS_V1","status":"PASS" if code==0 else "FAIL",
                 "binary_sha256":hashlib.sha256(h.binary.read_bytes()).hexdigest(),
                 "cases_passed":sum(c["status"]=="PASS" for c in h.cases),"cases_total":len(h.cases),
                 "assertions":h.assertions,"commands":len(h.commands),"elapsed_seconds":time.time()-started}
        for name,obj in (("SUMMARY.json",summary),("CASES.json",h.cases),("COMMANDS.json",h.commands)):
            (h.output/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+"\n")
        print(json.dumps(summary))
    return code
if __name__=="__main__":raise SystemExit(main())
