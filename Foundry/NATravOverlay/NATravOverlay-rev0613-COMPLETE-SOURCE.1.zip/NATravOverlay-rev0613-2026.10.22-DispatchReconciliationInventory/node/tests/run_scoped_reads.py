#!/usr/bin/env python3
"""Exact-domain read delegation on real C++ peers and Linux local principals."""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import time
from typing import Any

from run_persistent import Harness, Daemon, free_port, operation, receive_exact
from run_evidence_queries import config as v9_config, query_args, wire_query, OWNER_CLASSES, READ_CLASSES
from run_local_administration import run_as_uid, expose_control_for_uid
from run_live_configuration import candidate, activate, wait_state
from run_peer_sessions import submit, revise
from run_state_authentication import new_key, migrate, start as start_keyed

UID = 65534
SECOND_UID = 65533
Rule = tuple[int, str, str, str]


def scoped_config(h: Harness, name: str, node: str, state: Path, port: int,
                  rules: list[Rule], *, inbound: list[str] | None = None,
                  grants: list[tuple[int, list[str]]] | None = None) -> Path:
    path = v9_config(h, name, node, state, port, inbound=inbound, grants=grants)
    text = path.read_text().replace('CONFIG_V9', 'CONFIG_V10')
    text += ''.join(f'evidence_read={uid},{issuer},{scope},{mode}\n' for uid, issuer, scope, mode in rules)
    path.write_text(text); path.chmod(0o600)
    return path


def query(h: Harness, label: str, state: Path, expected: int = 0, *, uid: int | None = None,
          **kwargs: Any) -> dict[str, Any]:
    args = query_args(state, **kwargs)
    result = h.run(label, args, expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    assert result is not None
    if expected == 0:
        h.check(result['format'] == 'NATRAV_OVERLAY_EVIDENCE_QUERY_V2', 'versioned scoped response')
        h.check(result['sequence_semantics'] == 'AUTHORIZED_SELECTION_ORDINAL', 'no global admission sequence exposed')
        h.check(result['returned_records'] == len(result['records']), 'exact visible row count')
        h.check(len(result['read_policy_digest']) == 64, 'stable reader authority digest')
        # The original annotated response body, not a serialization estimate.
        command = next(c for c in reversed(h.commands) if c['label']==label)
        h.check(len(command['stdout'].strip().encode()) <= int(kwargs.get('max_bytes',60000)), 'full JSON byte bound')
    return result


def trio(h: Harness, name: str, *, extra: bool = False) -> tuple[Any, ...]:
    a,b,c = (h.runtime/(name+'-'+x) for x in ('a','b','c'))
    ap,bp,cp = free_port(),free_port(),free_port()
    rules: list[Rule] = [(os.geteuid(),'A','query/series','PAYLOAD'),(os.geteuid(),'A','query/other','METADATA')]
    grants = [(os.geteuid(), OWNER_CLASSES+READ_CLASSES)]
    if extra:
        rules += [(UID,'C','query/series','METADATA'),(UID,'A','query/other','PAYLOAD'),
                  (SECOND_UID,'A','query/series','METADATA')]
        grants += [(UID,READ_CLASSES),(SECOND_UID,['EVIDENCE_READ'])]
    bc=scoped_config(h,name+'-b','B',b,bp,rules,inbound=['A','C'],grants=grants)
    ac=v9_config(h,name+'-a','A',a,ap,[('B',bp)])
    cc=v9_config(h,name+'-c','C',c,cp,[('B',bp)])
    bd=h.start(name+'-b',bc,b); ad=h.start(name+'-a',ac,a); cd=h.start(name+'-c',cc,c)
    return a,b,c,ac,bc,cc,ad,bd,cd


def send(h: Harness, label: str, state: Path, issuer: str, scope: str='query/series', data: str='evidence') -> str:
    op=operation(label)
    submit(h,label,state/'control.sock',issuer,'B',scope,op,data)
    wait_state(h,state,op,'ACKED',label+'-ack')
    return op


def cases(h: Harness, selected: set[str] | None = None) -> None:
    def case(name: str, fn: Any) -> None:
        if selected is None or name in selected: h.case(name,fn)

    def policy() -> None:
        state=h.runtime/'policy'
        rules=[(os.geteuid(),'A','query/series','PAYLOAD'),(os.geteuid(),'C','query/series','METADATA')]
        cfg=scoped_config(h,'policy','B',state,free_port(),rules)
        first=h.run('policy-valid',['config-check','--config',str(cfg)])
        reverse=candidate(h,cfg,'policy-reordered','policy-g1',lambda s:'\n'.join(s.splitlines()[:-2]+list(reversed(s.splitlines()[-2:])))+'\n')
        same=h.run('policy-reordered',['config-check','--config',str(reverse)])
        h.check(first['runtime_digest']==same['runtime_digest'],'canonical configuration independent of rule order')
        h.check(first['evidence_read_policy']==same['evidence_read_policy'],'canonical read policy independent of order')
        modifications=[
            ('legacy-format',lambda s:s.replace('CONFIG_V10','CONFIG_V9'),'CONFIG_VERSION_REJECTED'),
            ('duplicate',lambda s:s+f'evidence_read={os.geteuid()},A,query/series,PAYLOAD\n','CONFIG_EVIDENCE_READ_DUPLICATE'),
            ('ambiguous',lambda s:s+f'evidence_read={os.geteuid()},A,query/series,METADATA\n','CONFIG_EVIDENCE_READ_DUPLICATE'),
            ('wildcard-issuer',lambda s:s.replace(',A,query/series,',',*,query/series,'),'CONFIG_EVIDENCE_READ_INVALID'),
            ('wildcard-scope',lambda s:s.replace('query/series','query/*'),'CONFIG_EVIDENCE_READ_INVALID'),
            ('unknown-uid',lambda s:s+f'evidence_read={UID},A,query/series,METADATA\n','CONFIG_EVIDENCE_READ_CLASS_REQUIRED'),
            ('no-domains',lambda s:'\n'.join(x for x in s.splitlines() if not x.startswith('evidence_read='))+'\n','CONFIG_EVIDENCE_READ_DOMAIN_REQUIRED'),
            ('no-payload-domain',lambda s:s.replace(',PAYLOAD',',METADATA'),'CONFIG_EVIDENCE_READ_DOMAIN_REQUIRED'),
            ('no-read-class',lambda s:s.replace(',EVIDENCE_READ,EVIDENCE_PAYLOAD',''),'CONFIG_EVIDENCE_READ_CLASS_REQUIRED'),
            ('unknown-mode',lambda s:s.replace(',PAYLOAD',',READ_ALL'),'CONFIG_EVIDENCE_READ_INVALID'),
        ]
        for name,mutate,code in modifications:
            bad=candidate(h,cfg,'policy-'+name,'policy-'+name,mutate)
            result=h.run('reject-'+name,['config-check','--config',str(bad)],expected=3)
            h.check(result['code']==code,'strict rejection: '+name)
        text='\n'.join(x for x in cfg.read_text().splitlines() if not x.startswith('evidence_read='))+'\n'
        text+=''.join(f'evidence_read={os.geteuid()},A,scope/{i},PAYLOAD\n' for i in range(256))
        maximum=h.work/'max-rules.conf';maximum.write_text(text);maximum.chmod(0o600)
        h.run('maximum-rules',['config-check','--config',str(maximum)])
        maximum.write_text(text+f'evidence_read={os.geteuid()},A,scope/overflow,PAYLOAD\n')
        h.check(h.run('too-many-rules',['config-check','--config',str(maximum)],expected=3)['code']=='CONFIG_EVIDENCE_READ_LIMIT','exact domain ceiling')
        # V9 remains node-wide; adoption of V10 without domains is rejected.
        legacy=v9_config(h,'legacy','L',h.runtime/'legacy',free_port())
        daemon=h.start('legacy',legacy,h.runtime/'legacy')
        h.check(h.run('legacy-read',query_args(h.runtime/'legacy'))['format']=='NATRAV_OVERLAY_EVIDENCE_QUERY_V1','V9 read behavior preserved')
        upgrade=candidate(h,legacy,'legacy-upgrade','legacy-g2',lambda s:s.replace('CONFIG_V9','CONFIG_V10')+f'evidence_read={os.geteuid()},A,query/series,PAYLOAD\n')
        activate(h,'explicit-v10',h.runtime/'legacy',upgrade)
        query(h,'v10-explicit-read',h.runtime/'legacy')
        daemon.shutdown();daemon=h.start('legacy-seed-restart',legacy,h.runtime/'legacy')
        query(h,'accepted-v10-on-old-seed',h.runtime/'legacy');daemon.shutdown()
    case('strict_rules_and_v9_compatibility',policy)

    def noninterference() -> None:
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'visibility')
        hidden=send(h,'hidden-first',c,'C',data='secret-c')
        one=send(h,'visible-one',a,'A',data='visible-one')
        hidden_other=send(h,'hidden-other',a,'A','query/binary','secret-other')
        two=send(h,'visible-two',a,'A',data='visible-two')
        meta=send(h,'metadata-only',a,'A','query/other','secret-metadata-payload')
        first=query(h,'initial-visible',b,view='history',limit=1)
        h.check(first['selected_records']==3 and first['records'][0]['sequence']==1,'only visible count and gap-free positions')
        token=first['next_cursor'];h.check(len(token)==368,'versioned cursor carries explicit authority digest')
        hc=operation('hidden-correction')
        revise(h,'hidden-correction',cd.control,'C','B','query/series',hc,hidden,'changed secret')
        wait_state(h,c,hc,'ACKED','hidden-correction-ack')
        send(h,'hidden-new',c,'C',data='more hidden')
        second=query(h,'page-after-hidden-changes',b,view='history',limit=1,cursor=token)
        h.check(second['selection_digest']==first['selection_digest'],'hidden writes/corrections do not stale visible root')
        allrows=query(h,'visible-history',b,view='history')
        h.check([r['operation_id'] for r in allrows['records']]==[one,two,meta],'issuer and scope authority intersection')
        h.check([r['sequence'] for r in allrows['records']]==[1,2,3],'hidden admission gaps absent')
        body=json.dumps(allrows)
        h.check(hidden not in body and hc not in body and hidden_other not in body,'hidden operation and correction links absent')
        payload=query(h,'payload-subset',b,view='history',payload='yes')
        h.check([r['operation_id'] for r in payload['records']]==[one,two],'payload selection excludes metadata-only domains')
        for label,op in [('hidden-operation',hidden),('metadata-payload',meta),('missing-operation',operation('absent'))]:
            empty=query(h,label,b,view='history',operation=op,payload='yes',payload_offset=60000,max_bytes=4096)
            h.check(empty['records']==[] and empty['selected_records']==0,'unauthorized/absent operation reveals no range or page error')
        h.check(query(h,'hidden-filter',b,issuer='C')['records']==[],'caller filter never widens authority')
        h.check(query(h,'scope-prefix',b,scope='query/ser')['records']==[],'no implicit prefix grant')
        corrected=operation('visible-corrected')
        revise(h,'visible-correct',ad.control,'A','B','query/series',corrected,one,'correction')
        wait_state(h,a,corrected,'ACKED','visible-correction-ack')
        h.check(query(h,'visible-change-stale',b,3,view='history',limit=1,cursor=token)['code']=='EVIDENCE_CURSOR_STALE','visible change invalidates cursor')
        current=query(h,'visible-current',b)
        history=query(h,'visible-correct-history',b,view='history')
        h.check(one not in [r['operation_id'] for r in current['records']],'current omits corrected predecessor')
        h.check(history['records'][0]['superseded_by']==corrected and history['records'][-1]['corrects']==one,'authorized correction ancestry preserved')
        h.check(history['records'][0]['authorization']['peer_generation']=='a-g1','stored admission provenance preserved')
        # Independently reproduce per-UID authority and selected metadata roots.
        def txt(value: str) -> bytes:
            encoded=value.encode();return struct.pack('!H',len(encoded))+encoded
        rules=[('A','query/other',False),('A','query/series',True)]
        encoded=b'NATRAV_OVERLAY_EVIDENCE_READ_ACCESS_V1'+struct.pack('!I',os.geteuid())+b'\x01\x01\x01'+struct.pack('!I',len(rules))
        for issuer,scope,access in rules:encoded+=struct.pack('!I',os.geteuid())+txt(issuer)+txt(scope)+bytes([access])
        access_digest=hashlib.sha256(encoded).digest()
        h.check(access_digest.hex()==history['read_policy_digest'],'independent exact-principal read policy digest')
        seed=b'NATRAV_OVERLAY_EVIDENCE_SELECTION_V2'+txt('B')+b'\x01'+txt('')+txt('')+b'\x00'+access_digest+b'\x00'
        root=hashlib.sha256(seed).digest()
        fields=('sequence','operation_id','issuer','recipient','scope','record_digest','payload_size','corrects','superseded_by','authorization')
        for row in history['records']:
            leaf=json.dumps({f:row[f] for f in fields},separators=(',',':')).encode()
            root=hashlib.sha256(root+struct.pack('!I',len(leaf))+leaf).digest()
        h.check(root.hex()==history['selection_digest'],'independent authorized selection digest')
        before=(b/'state.journal').read_bytes();query(h,'observational',b,view='history')
        h.check((b/'state.journal').read_bytes()==before,'successful scoped read is observational')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('issuer_scope_payload_noninterference',noninterference)

    def principals() -> None:
        if os.geteuid()!=0:raise RuntimeError('real UID test requires root in this laboratory')
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'principals',extra=True)
        send(h,'principal-a1',a,'A');send(h,'principal-a2',a,'A')
        c1=send(h,'principal-c1',c,'C');c2=send(h,'principal-c2',c,'C')
        other=send(h,'principal-other',a,'A','query/other')
        expose_control_for_uid(b)
        page=query(h,'uid-scope-metadata',b,uid=UID,limit=1)
        h.check(page['principal_uid']==UID and page['selected_records']==3,'actual UID domain intersection')
        payload=query(h,'uid-scope-payload',b,uid=UID,payload='yes')
        h.check([r['operation_id'] for r in payload['records']]==[other],'mixed metadata and payload domains independent')
        h.check(query(h,'uid-denied-domain-payload',b,uid=UID,payload='yes',operation=c1)['records']==[],'metadata domain does not grant payload')
        h.check(query(h,'uid-class-denied',b,3,uid=SECOND_UID,payload='yes')['code']=='LOCAL_CONTROL_CLASS_DENIED','metadata-only class denies payload')
        h.check(query(h,'uid-cursor-owner',b,3,limit=1,cursor=page['next_cursor'])['code']=='EVIDENCE_CURSOR_CONTEXT_MISMATCH','cursor cannot cross actual UID')
        h.check(query(h,'uid-cursor-filter',b,3,uid=UID,limit=1,issuer='A',cursor=page['next_cursor'])['code']=='EVIDENCE_CURSOR_CONTEXT_MISMATCH','filters cannot widen cursor')
        damaged=page['next_cursor'][:-1]+('0' if page['next_cursor'][-1]!='0' else '1')
        h.check(query(h,'uid-cursor-tamper',b,3,uid=UID,limit=1,cursor=damaged)['code']=='EVIDENCE_CURSOR_INVALID','scoped token tag checked')
        # Keep owner read command bits; narrow only its exact domains while a
        # prior connection is stalled before completing its bounded request.
        wire=wire_query()
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as slow:
            slow.settimeout(6);slow.connect(str(b/'control.sock'))
            framed=struct.pack('!I',len(wire))+wire;slow.sendall(framed[:3]);time.sleep(.05)
            changed=candidate(h,bc,'principals-narrow','principals-b-g2',lambda s:s.replace(
                f'evidence_read={os.geteuid()},A,query/series,PAYLOAD\n','').replace(
                f'evidence_read={os.geteuid()},A,query/other,METADATA',f'evidence_read={os.geteuid()},A,query/other,PAYLOAD'))
            activate(h,'narrow-owner-domains',b,changed)
            slow.sendall(framed[3:]);slow.shutdown(socket.SHUT_WR)
            size=struct.unpack('!I',receive_exact(slow,4))[0];response=receive_exact(slow,size)
            parsed=json.loads(response[5:])
            h.check(response[4]==0 and [r['operation_id'] for r in parsed['records']]==[other],'slow connection uses current domain policy not old grants')
        h.check(query(h,'uid-config-bound-cursor',b,3,uid=UID,limit=1,cursor=page['next_cursor'])['code']=='EVIDENCE_CURSOR_CONTEXT_MISMATCH','configuration still binds unchanged principal token')
        h.check(query(h,'uid-independent-read',b,uid=UID)['selected_records']==3,'narrowing owner does not alter delegated authority')
        (b/'control.sock').chmod(0o600);b.chmod(0o700)
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('real_uids_cursor_and_live_revocation',principals)

    def concurrent_case() -> None:
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'concurrent')
        first=send(h,'concurrent-initial',a,'A')
        def write(issuer: str,i: int) -> str:
            return send(h,f'concurrent-{issuer}-{i}',a if issuer=='A' else c,issuer,data=str(i))
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            writers=[pool.submit(write,issuer,i) for i in range(8) for issuer in ['A','C']]
            readers=[pool.submit(query,h,f'concurrent-read-{i}',b,max_bytes=4096) for i in range(8)]
            ids=[f.result() for f in writers];pages=[f.result() for f in readers]
        h.check(all(r['issuer']=='A' for p in pages for r in p['records']),'concurrent readers never see hidden writer')
        visible={first}|set(ids[::2]);rows=[];token=None;root=None
        while True:
            kwargs={'max_bytes':4096,'view':'history'}
            if token:kwargs['cursor']=token
            page=query(h,'settled-page-'+str(len(rows)),b,**kwargs)
            if root is None:root=page['selection_digest']
            h.check(page['selection_digest']==root,'settled authorized root stable')
            rows+=page['records'];token=page['next_cursor']
            if token is None:break
        h.check({r['operation_id'] for r in rows}==visible and len(rows)==9,'all nine authorized admissions exactly once')
        h.check([r['sequence'] for r in rows]==list(range(1,10)),'no global sequence gaps under interleaved writers')
        page=query(h,'before-compaction',b,limit=1)
        h.run('scoped-compact',['compact','--control',str(bd.control)])
        query(h,'cursor-after-scoped-compact',b,limit=1,cursor=page['next_cursor'])
        bd.shutdown();bd=h.start('scoped-index-rebuild',bc,b)
        h.check(query(h,'after-index-rebuild',b,view='history')['selection_digest']==root,'domain index rebuilt from checkpoint with same root')
        h.check(query(h,'process-cursor-invalid',b,3,limit=1,cursor=page['next_cursor'])['code']=='EVIDENCE_CURSOR_INVALID','process-local cursor not durable')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('concurrent_domains_bounded_pages_and_index_rebuild',concurrent_case)

    def protected() -> None:
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'restore',extra=True)
        visible=send(h,'restore-visible',a,'A');send(h,'restore-hidden',c,'C')
        before=query(h,'restore-before',b,view='history',payload='yes')
        bd.shutdown()
        keys=h.runtime/'scoped-keys';keys.mkdir(mode=0o700)
        key=new_key(h,keys,'scoped-state-g1');migrate(h,'scoped-migrate',b,key,'B')
        bd=start_keyed(h,'scoped-keyed',bc,b,key)
        h.run('scoped-keyed-compact',['compact','--control',str(bd.control)]);bd.shutdown()
        crypt=keys/'backup.key';archive=keys/'backup.nob';identity=h.identity('B')
        h.run('scoped-backup-key',['backup-key-init','--output',str(crypt),'--generation','scoped-backup-g1'])
        h.run('scoped-export',['backup-export','--state',str(b),'--node','B','--generation','b-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'scoped-restored'
        h.run('scoped-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','B','--generation','b-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        relocated=candidate(h,bc,'scoped-relocated','scoped-relocated-g1',lambda s:s.replace(f'state={b}',f'state={restored}'))
        # Path relocation is not an authority-widening channel.
        widened=candidate(h,relocated,'scoped-relocation-widen','scoped-relocated-g2',lambda s:s+f'evidence_read={os.geteuid()},C,query/series,PAYLOAD\n')
        h.check(h.run('scoped-relocation-denied',['state-relocate','--state',str(restored),'--node','B','--candidate',str(widened),'--reason','not just relocation','--state-auth-key',str(key)],expected=3)['code']=='RELOCATION_SCOPE_CHANGED','offline relocation cannot widen read delegation')
        h.run('scoped-relocate',['state-relocate','--state',str(restored),'--node','B','--candidate',str(relocated),'--reason','verified scoped restore','--state-auth-key',str(key)])
        bd=start_keyed(h,'scoped-restored',relocated,restored,key)
        after=query(h,'scoped-restored-read',restored,view='history',payload='yes')
        h.check(after['records']==before['records'] and after['selection_digest']==before['selection_digest'],'authorized view preserved through keyed encrypted relocation')
        h.check(after['read_policy_digest']==before['read_policy_digest'],'same read authority after owner path relocation')
        expose_control_for_uid(restored)
        delegated=query(h,'restored-real-uid',restored,uid=UID)
        h.check(delegated['selected_records']==1 and delegated['records'][0]['issuer']=='C','delegated UID authority reconstructed')
        (restored/'control.sock').chmod(0o600);restored.chmod(0o700)
        send(h,'restored-hidden-continuation',c,'C')
        h.check(query(h,'hidden-continuation-isolated',restored,view='history',payload='yes')['selection_digest']==after['selection_digest'],'new hidden delivery cannot perturb restored visible view')
        send(h,'restored-visible-continuation',a,'A')
        h.check(query(h,'restored-visible-new',restored)['selected_records']==2,'restored domain index includes new admitted work')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('keyed_encrypted_restore_relocation_and_continuation',protected)

    def scan_isolation() -> None:
        # Independently encoded unkeyed LEGACY storage load, not 65537 network
        # peers or authenticated admissions. The normal C++ decoder rebuilds
        # the exact-domain index before the persistent query path uses it.
        from run_integration import encode_record
        state=h.runtime/'indexed-load';state.mkdir(mode=0o700)
        (state/'node.meta').write_text('NATRAV_OVERLAY_NODE_STATE_V2\nnode=B\nstorage_schema=2\n')
        (state/'node.meta').chmod(0o600)
        (state/'state.lock').touch(mode=0o600)
        journal=state/'state.journal'
        hidden_count=65537
        visible=[]
        with journal.open('wb') as f:
            for i in range(hidden_count+4):
                issuer='A' if i in (1,200,1000,hidden_count+3) else 'C'
                op=operation('indexed-load-'+str(i))
                if issuer=='A':visible.append(op)
                body=b'\x01'+encode_record(op,issuer,'B','query/series',b'x')
                f.write(b'NOJ1'+struct.pack('!I',len(body))+body+
                        hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest())
        journal.chmod(0o600)
        cfg=scoped_config(h,'indexed-load','B',state,free_port(),[(os.geteuid(),'A','query/series','PAYLOAD')])
        # The old test rejected the broad request before hashing. It now asks
        # for a complete 65k root, so give that workload an explicit 20s budget.
        cfg.write_text(cfg.read_text().replace('deadline_ms=2000','deadline_ms=20000'))
        # Large offline replay is not the small-state startup timing test.
        # Default five-second bounds remain unchanged for all other daemons.
        begin=time.monotonic()
        daemon=Daemon(h,'indexed-load',cfg,state,readiness_timeout=20.0)
        h.daemons.append(daemon);daemon.start()
        (h.output/'INDEXED-REPLAY.json').write_text(json.dumps({
            'fixture_records':hidden_count+4,'hidden_records':hidden_count,
            'visible_records':4,'startup_seconds':time.monotonic()-begin,
            'startup_harness_deadline_seconds':20.0,'network_nodes_claimed':False},indent=2)+'\n')
        result=query(h,'hidden-above-legacy-ceiling',state,view='history')
        h.check(result['selected_records']==4 and [r['operation_id'] for r in result['records']]==visible,
                '65537 hidden records do not consume visible scan ceiling')
        h.check([r['sequence'] for r in result['records']]==[1,2,3,4], 'large hidden population exposes no sequence gaps')
        broad=candidate(h,cfg,'indexed-grant-hidden','indexed-load-g2',lambda s:s+f'evidence_read={os.geteuid()},C,query/series,METADATA\n')
        activate(h,'indexed-authorize-larger-domain',state,broad)
        args=query_args(state,view='history',limit=1);args[4]='30000'
        large=h.run('authorized-indexed-page',args,timeout=40)
        assert large is not None
        h.check(large['format']=='NATRAV_OVERLAY_EVIDENCE_QUERY_V2', 'large versioned read response')
        h.check(len(h.commands[-1]['stdout'].strip().encode())<=60000, 'large cold page keeps exact JSON limit')
        measurement=json.loads((h.output/'INDEXED-REPLAY.json').read_text())
        measurement.update({'large_control_deadline_ms':20000,'authorized_cold_root_seconds':h.commands[-1]['elapsed_seconds']})
        (h.output/'INDEXED-REPLAY.json').write_text(json.dumps(measurement,indent=2)+'\n')
        h.check(large['selected_records']==hidden_count+4 and large['returned_records']==1,
                'authorized large domain is paginated rather than rejected by the retired scan ceiling')
        following=query(h,'authorized-indexed-page-cached',state,view='history',limit=1,cursor=large['next_cursor'])
        h.check(following['query_work']['root_records_hashed']==0 and following['query_work']['index_records_visited']<=2,
                'next small page neither hashes nor enumerates the full authorized population')
        exact=query(h,'authorized-indexed-exact',state,operation=operation('indexed-load-0'))
        h.check(exact['selected_records']==1 and exact['records'][0]['issuer']=='C','exact operation lookup remains bounded beyond broad ceiling')
        # A payload read does not scan the metadata-only C domain.
        h.check(query(h,'payload-scan-ceiling-isolated',state,payload='yes')['selected_records']==4,
                'payload mode does not charge metadata-only domain scan')
        daemon.shutdown()
    case('authorized_domain_scan_ceiling_not_global_population',scan_isolation)


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--case',action='append');args=parser.parse_args()
    if args.output.exists():parser.error('output must not exist')
    h=Harness(args.binary,args.output);begin=time.time();success=False
    try:cases(h,set(args.case) if args.case else None);success=True
    except BaseException as exc:
        (h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n')
        print(f'FAIL: {type(exc).__name__}: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup()
        summary={'format':'NATRAV_OVERLAY_SCOPED_READ_TESTS_V1','status':'PASS' if success else 'FAIL',
                 'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),
                 'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),
                 'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-begin}
        for name,value in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:
            (h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if success else 1
if __name__=='__main__':raise SystemExit(main())
