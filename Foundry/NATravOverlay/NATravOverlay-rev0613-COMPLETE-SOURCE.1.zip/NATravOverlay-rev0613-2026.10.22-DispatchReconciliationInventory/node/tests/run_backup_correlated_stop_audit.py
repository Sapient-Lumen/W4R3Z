#!/usr/bin/env python3
"""Direct signed-encrypted-backup correlated-stop audit validation."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time
from typing import Any, Callable

from run_persistent import Harness, free_port, operation
from run_correlated_terminal_state_head import (
    correlated_terminal_drain,
    correlated_terminal_shutdown,
    setup_keyed,
    terminal_args,
)
from run_correlated_stopping import request_id
from run_response_loss_stopping import wait_stopped
from run_correlated_stop_audit import (
    audit as directory_audit,
    shape_drain,
    shape_immediate,
    lifecycle_reason_digest,
    mutated_selector,
)
from run_state_authentication import start

CASES = (
    "explicit_shape_and_exact_request_id",
    "deadline_obligation_and_redaction",
    "duplicate_attempts_preserved",
    "trust_expectation_and_corruption_boundaries",
    "reencryption_preserves_embedded_state",
    "strict_read_only_interface",
)


def backup_key(h: Harness, root: Path, label: str, generation: str) -> Path:
    path = root / f"{label}.backup-key"
    value = h.run(label + "-key-init", ["backup-key-init", "--output", str(path), "--generation", generation])
    assert value
    return path


def export_backup(h: Harness, label: str, state: Path, state_key: Path, encryption: Path) -> tuple[Path, dict[str, Any]]:
    identity = h.identity("A")
    archive = state.parent / f"{label}.nob"
    value = h.run(label + "-export", ["backup-export", "--state", str(state), "--node", "A",
        "--generation", "a-g1", "--output", str(archive), "--state-auth-key", str(state_key),
        "--sign-key", str(identity.private_key), "--sign-cert", str(identity.certificate),
        "--encrypt-key", str(encryption)], timeout=30)
    assert value
    return archive, value


def audit(h: Harness, label: str, archive: Path, state_key: Path | None,
          encryption: Path, certificate: Path, selection: list[str], *,
          expected: int = 0, expected_backup_id: str | None = None,
          expected_head: str | None = None, max_matches: int = 64,
          max_bytes: int = 60000, extra: list[str] | None = None) -> dict[str, Any]:
    args = ["backup-correlated-stop-audit", "--input", str(archive), "--node", "A",
        "--generation", "a-g1", "--decrypt-key", str(encryption),
        "--trusted-cert", str(certificate), "--max-matches", str(max_matches),
        "--max-bytes", str(max_bytes), *selection]
    if state_key is not None:
        args += ["--state-auth-key", str(state_key)]
    if expected_backup_id is not None:
        args += ["--expected-backup-id", expected_backup_id]
    if expected_head is not None:
        args += ["--expected-state-head", expected_head]
    if extra:
        args += extra
    value = h.run(label, args, expected=expected, timeout=30)
    assert value is not None
    return value


def check_common(h: Harness, value: dict[str, Any], expected_id: str) -> None:
    h.check(value["format"] == "NATRAV_OVERLAY_BACKUP_CORRELATED_STOP_AUDIT_V1" and value["ok"] is True,
        "direct backup audit has explicit format")
    h.check(value["selection"]["request_id"] == expected_id, "exact request identity selected")
    source = value["source"]
    h.check(source["status"] == "COMPLETE_SIGNED_ENCRYPTED_BACKUP_AUTHENTICATED_SEMANTIC_REPLAY",
        "complete trust and replay boundary reported")
    h.check(source["signed"] and source["signature_valid"] and source["trusted_signer"],
        "explicit trusted signature required")
    h.check(source["encrypted"] and source["encryption_authenticated"],
        "authenticated encryption required")
    h.check(source["restore_performed"] is False and source["writer_opened"] is False and
        source["workers_started"] is False and source["state_mutated"] is False,
        "direct audit neither restores nor starts a writer")
    h.check(value["mutation"] == "NONE" and value["automatic_expectation_update"] is False,
        "report is read-only and never advances an anchor")
    h.check(value["freshness"] == "NOT_ESTABLISHED" and
        value["outcome"]["response_receipt"] == "NOT_ESTABLISHED",
        "backup possession/history are not freshness or receipt proof")
    h.check(value["redaction"] == "NO_PAYLOADS_SECRETS_REASON_TEXT_OR_IDENTITY_PATHS",
        "report uses shared narrow redaction")


def stop_immediate(h: Harness, name: str, token: str) -> tuple[Path, Path, str]:
    _, state, key, _, daemon = setup_keyed(h, name)
    response = h.run(name + "-stop", terminal_args(daemon.control, token), timeout=20)
    assert response
    wait_stopped(h, daemon, name + " stopped")
    return state, key, request_id(correlated_terminal_shutdown(token))


def run_suite(h: Harness, selected: set[str] | None) -> None:
    def case(name: str, fn: Callable[[], None]) -> None:
        if selected is None or name in selected:
            h.case(name, fn)

    def explicit_shape_and_exact_request_id() -> None:
        token = "backup-audit-explicit-01"
        state, key, expected_id = stop_immediate(h, "backup-audit-explicit", token)
        enc = backup_key(h, state.parent, "backup-audit-explicit", "enc-g1")
        archive, exported = export_backup(h, "backup-audit-explicit", state, key, enc)
        before = archive.read_bytes(); identity = h.identity("A")
        direct = audit(h, "backup-audit-shape", archive, key, enc, identity.certificate,
            shape_immediate(token), expected_backup_id=exported["backup_id"])
        check_common(h, direct, expected_id)
        h.check(direct["selection"]["method"] == "EXPLICIT_REQUEST_SHAPE" and
            direct["selection"]["shape"]["correlation_token"] == token,
            "explicit shape derives and reports exact intended attempt")
        h.check(direct["outcome"]["classification"] == "ACCEPTED_IMMEDIATE" and
            direct["matches"]["decision_count"] == 1 and direct["matches"]["lifecycle_count"] == 1,
            "accepted immediate stop reconstructed")
        h.check(direct["source"]["file_sha256"] == hashlib.sha256(before).hexdigest(),
            "outer encrypted bytes independently identified")
        exact = audit(h, "backup-audit-exact-id", archive, key, enc, identity.certificate,
            ["--request-id", expected_id], expected_head=direct["state_head"]["selector"])
        check_common(h, exact, expected_id)
        h.check(exact["selection"]["method"] == "EXACT_REQUEST_ID" and exact["selection"]["shape"] is None,
            "exact-ID path recovers no token text")
        h.check(exact["matches"] == direct["matches"] and exact["outcome"] == direct["outcome"],
            "shape and exact-ID paths share one report interpretation")
        directory = directory_audit(h, "backup-audit-directory-reference", state, key,
            ["--request-id", expected_id])
        h.check(directory["matches"] == direct["matches"] and directory["outcome"] == direct["outcome"],
            "directory and embedded-checkpoint audits share selected provenance semantics")
        h.check(archive.read_bytes() == before, "all direct audits preserve exact archive bytes")

    case("explicit_shape_and_exact_request_id", explicit_shape_and_exact_request_id)

    def deadline_obligation_and_redaction() -> None:
        token = "backup-audit.deadline-02"; reason = "private backup audit drain reason"; deadline = 150
        expected_id = request_id(correlated_terminal_drain(deadline, reason, token))
        unavailable = free_port()
        _, state, key, _, daemon = setup_keyed(h, "backup-audit-deadline", peers=[("B", unavailable)])
        secret = "private retained payload for direct backup audit"
        h.run("backup-audit-pending-submit", ["submit", "--control", str(daemon.control),
            "--node", "A", "--peer", "B", "--scope", "admin/test",
            "--operation", operation("backup-audit-pending"), "--payload-text", secret,
            "--deadline-ms", "2000"])
        response = h.run("backup-audit-deadline-stop", terminal_args(daemon.control, token, deadline, reason), timeout=20)
        assert response
        wait_stopped(h, daemon, "backup audit deadline")
        enc = backup_key(h, state.parent, "backup-audit-deadline", "enc-g1")
        archive, _ = export_backup(h, "backup-audit-deadline", state, key, enc)
        before = archive.read_bytes()
        value = audit(h, "backup-audit-deadline-report", archive, key, enc, h.identity("A").certificate,
            shape_drain(token, deadline, reason))
        check_common(h, value, expected_id)
        h.check(value["outcome"]["classification"] == "ACCEPTED_DRAIN_DEADLINE", "deadline outcome retained")
        h.check([x["kind"] for x in value["matches"]["lifecycle"]] == ["DRAIN_STARTED", "DRAIN_DEADLINE"],
            "both drain boundaries retained")
        h.check(value["retained_obligations"]["pending_outbound"] == 1 and
            value["retained_obligations"]["complete"] is False,
            "pending outbound remains explicit")
        h.check(all(x["reason_text"] is None and x["reason_digest"] == lifecycle_reason_digest(reason)
            for x in value["matches"]["lifecycle"]), "free-text reason is redacted but committed")
        rendered = json.dumps(value, separators=(",", ":"))
        h.check(secret not in rendered and reason not in rendered, "payload and reason text do not enter report")
        h.check(archive.read_bytes() == before, "deadline audit preserves archive")

    case("deadline_obligation_and_redaction", deadline_obligation_and_redaction)

    def duplicate_attempts_preserved() -> None:
        token = "backup-audit-duplicate-03"; expected_id = request_id(correlated_terminal_shutdown(token))
        _, state, key, config, daemon = setup_keyed(h, "backup-audit-duplicates")
        for ordinal in range(2):
            value = h.run(f"backup-audit-duplicate-stop-{ordinal}", terminal_args(daemon.control, token), timeout=20)
            assert value
            wait_stopped(h, daemon, f"backup audit duplicate {ordinal}")
            if ordinal == 0:
                daemon = start(h, "backup-audit-duplicate-restart", config, state, key)
        enc = backup_key(h, state.parent, "backup-audit-duplicates", "enc-g1")
        archive, _ = export_backup(h, "backup-audit-duplicates", state, key, enc)
        value = audit(h, "backup-audit-duplicates-report", archive, key, enc, h.identity("A").certificate,
            ["--request-id", expected_id], max_matches=4)
        check_common(h, value, expected_id)
        h.check(value["matches"]["decision_count"] == 2 and value["matches"]["lifecycle_count"] == 2,
            "all exact duplicate attempts preserved")
        h.check(value["outcome"]["authorized_decisions"] == 2 and value["outcome"]["shutdown_requested"] == 2,
            "duplicate request identity is not idempotency")
        limited = audit(h, "backup-audit-duplicates-limit", archive, key, enc, h.identity("A").certificate,
            ["--request-id", expected_id], max_matches=3, expected=3)
        h.check(limited["code"] == "CORRELATED_STOP_AUDIT_MATCH_LIMIT", "matching rows never silently truncated")
        too_small = audit(h, "backup-audit-duplicates-byte-limit", archive, key, enc,
            h.identity("A").certificate, ["--request-id", expected_id],
            max_matches=4, max_bytes=4096, expected=3)
        h.check(too_small["code"] == "CORRELATED_STOP_AUDIT_RESPONSE_TOO_LARGE",
            "byte ceiling fails rather than omitting duplicate rows")

    case("duplicate_attempts_preserved", duplicate_attempts_preserved)

    def trust_expectation_and_corruption_boundaries() -> None:
        token = "backup-audit-trust-04"
        state, key, expected_id = stop_immediate(h, "backup-audit-trust", token)
        enc = backup_key(h, state.parent, "backup-audit-trust", "enc-g1")
        archive, exported = export_backup(h, "backup-audit-trust", state, key, enc)
        identity = h.identity("A"); before = archive.read_bytes()
        good = audit(h, "backup-audit-trust-good", archive, key, enc, identity.certificate,
            ["--request-id", expected_id])
        check_common(h, good, expected_id)
        wrong_id = ("1" if exported["backup_id"][0] != "1" else "2") + exported["backup_id"][1:]
        value = audit(h, "backup-audit-wrong-backup-id", archive, key, enc, identity.certificate,
            ["--request-id", expected_id], expected_backup_id=wrong_id, expected=3)
        h.check(value["code"] == "BACKUP_ID_EXPECTATION_MISMATCH", "signed backup expectation enforced")
        value = audit(h, "backup-audit-wrong-head", archive, key, enc, identity.certificate,
            ["--request-id", expected_id], expected_head=mutated_selector(good["state_head"]["selector"]), expected=3)
        h.check(value["code"] == "STATE_HEAD_EXPECTATION_MISMATCH", "embedded checkpoint expectation enforced")
        wrong_key = backup_key(h, state.parent, "backup-audit-wrong", "enc-g2")
        value = audit(h, "backup-audit-wrong-decryption", archive, key, wrong_key, identity.certificate,
            ["--request-id", expected_id], expected=3)
        h.check(value["code"] in ("BACKUP_DECRYPTION_FAILED", "BACKUP_KEY_MISMATCH", "BACKUP_ENCRYPTION_KEY_MISMATCH"), "wrong encryption key rejected")
        other = h.identity("B")
        value = audit(h, "backup-audit-untrusted-signer", archive, key, enc, other.certificate,
            ["--request-id", expected_id], expected=3)
        h.check(value["code"] == "BACKUP_SIGNER_NOT_TRUSTED", "explicit signer trust enforced")
        value = audit(h, "backup-audit-no-state-key", archive, None, enc, identity.certificate,
            ["--request-id", expected_id], expected=3)
        h.check(value["code"] == "STATE_AUTH_KEY_REQUIRED", "backup possession is not checkpoint authentication authority")
        corrupt = state.parent / "corrupt.nob"; changed = bytearray(before); changed[len(changed)//2] ^= 1
        corrupt.write_bytes(changed); corrupt.chmod(0o600)
        value = audit(h, "backup-audit-corrupt", corrupt, key, enc, identity.certificate,
            ["--request-id", expected_id], expected=3)
        h.check(value["code"] in ("BACKUP_DECRYPTION_FAILED", "BACKUP_AUTHENTICATION_FAILED", "BACKUP_FORMAT_INVALID", "BACKUP_CHECKPOINT_DIGEST_MISMATCH"),
            "corrupted encrypted archive rejected")
        h.check(archive.read_bytes() == before and corrupt.read_bytes() == changed, "all trust failures leave both inputs unchanged")

    case("trust_expectation_and_corruption_boundaries", trust_expectation_and_corruption_boundaries)

    def reencrypt_preserves_embedded_state() -> None:
        token = "backup-audit-reencrypt-05"
        state, key, expected_id = stop_immediate(h, "backup-audit-reencrypt", token)
        enc1 = backup_key(h, state.parent, "backup-audit-reencrypt-one", "enc-g1")
        archive, exported = export_backup(h, "backup-audit-reencrypt", state, key, enc1)
        cert = h.identity("A").certificate
        first = audit(h, "backup-audit-reencrypt-first", archive, key, enc1, cert,
            ["--request-id", expected_id])
        enc2 = backup_key(h, state.parent, "backup-audit-reencrypt-two", "enc-g2")
        second_archive = state.parent / "backup-audit-reencrypted.nob"
        value = h.run("backup-audit-reencrypt", ["backup-reencrypt", "--input", str(archive),
            "--output", str(second_archive), "--decrypt-key", str(enc1), "--encrypt-key", str(enc2),
            "--state-auth-key", str(key), "--node", "A", "--generation", "a-g1",
            "--trusted-cert", str(cert), "--require-signature", "yes"], timeout=30)
        assert value
        second = audit(h, "backup-audit-reencrypt-second", second_archive, key, enc2, cert,
            ["--request-id", expected_id], expected_backup_id=exported["backup_id"])
        h.check(first["state_head"] == second["state_head"] and first["matches"] == second["matches"] and
            first["retained_obligations"] == second["retained_obligations"],
            "re-encryption preserves embedded authenticated state and selected history")
        h.check(first["source"]["file_sha256"] != second["source"]["file_sha256"],
            "outer encrypted representation identity changes")
        h.check(first["source"]["backup_id"] == second["source"]["backup_id"] == exported["backup_id"],
            "signed inner backup identity remains stable across encryption rotation")

    case("reencryption_preserves_embedded_state", reencrypt_preserves_embedded_state)

    def strict_read_only_interface() -> None:
        token = "backup-audit-strict-06"
        state, key, expected_id = stop_immediate(h, "backup-audit-strict", token)
        enc = backup_key(h, state.parent, "backup-audit-strict", "enc-g1")
        archive, _ = export_backup(h, "backup-audit-strict", state, key, enc)
        before = archive.read_bytes(); cert = h.identity("A").certificate
        destination = state.parent / "must-not-exist"
        value = audit(h, "backup-audit-destination-rejected", archive, key, enc, cert,
            ["--request-id", expected_id], extra=["--destination", str(destination)], expected=3)
        h.check(value["code"] == "UNKNOWN_ARGUMENT" and not destination.exists(), "audit exposes no restore destination")
        value = audit(h, "backup-audit-mixed-selection", archive, key, enc, cert,
            ["--request-id", expected_id, *shape_immediate(token)], expected=3)
        h.check(value["code"] == "CORRELATED_STOP_AUDIT_SELECTION_INVALID", "selection forms cannot be mixed")
        bounded = audit(h, "backup-audit-minimum-budget", archive, key, enc, cert,
            ["--request-id", expected_id], max_bytes=4096)
        h.check(len(json.dumps(bounded, separators=(",", ":"))) <= 4096 and
            bounded["limits"]["maximum_json_bytes"] == 4096,
            "complete compact report fits the minimum supported budget")
        h.check(archive.read_bytes() == before and not destination.exists(), "strict failures and bounded reads mutate and publish nothing")

    case("strict_read_only_interface", strict_read_only_interface)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append", choices=CASES)
    args = parser.parse_args()
    if args.output.exists(): parser.error("output already exists")
    h = Harness(args.binary, args.output); begin = time.time(); code = 1
    try:
        run_suite(h, set(args.case) if args.case else None); code = 0
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
    finally:
        h.cleanup()
        summary = {"format": "NATRAV_OVERLAY_BACKUP_CORRELATED_STOP_AUDIT_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(c["status"] == "PASS" for c in h.cases),
            "cases_total": len(h.cases), "assertions": h.assertions,
            "commands": len(h.commands), "elapsed_seconds": time.time()-begin}
        for name, obj in (("SUMMARY.json", summary), ("CASES.json", h.cases), ("COMMANDS.json", h.commands)):
            (h.output / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
