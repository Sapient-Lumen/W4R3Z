#!/usr/bin/env python3
"""Detached custody-promotion intent construction and consumption validation."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import subprocess
import sys
import time
from typing import Any, Callable

from run_persistent import Harness
from run_authenticated_recovery import setup
from run_state_expectations import selector, append
from run_state_head_custody import parse_record, exact_args
from run_custody_state_opening import create_anchor
from run_backup_correlated_stop_audit import backup_key, export_backup
from run_state_authentication import new_key

CASES = (
    "state_intent_lifecycle",
    "exact_source_and_custody_binding",
    "creation_source_eligibility_and_races",
    "intent_publication_and_replacement_races",
    "backup_intent_lifecycle_and_trust",
    "strict_cli_and_predecessor_fail_closed",
)
INTENT_MAGIC = b"NHCPI001"
INTENT_DOMAIN = b"NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_INTENT_V1"


def take_text(raw: bytes, at: int, maximum: int) -> tuple[str, int]:
    size = struct.unpack_from(">H", raw, at)[0]
    at += 2
    assert 0 < size <= maximum
    value = raw[at:at + size].decode("utf-8")
    return value, at + size


def take_optional_text(raw: bytes, at: int, maximum: int) -> tuple[str | None, int]:
    size = struct.unpack_from(">H", raw, at)[0]
    at += 2
    if size == 0:
        return None, at
    assert size <= maximum
    value = raw[at:at + size].decode("utf-8")
    return value, at + size


def take_optional_digest(raw: bytes, at: int) -> tuple[str | None, int]:
    value = raw[at:at + 32]
    assert len(value) == 32
    return (None if value == bytes(32) else value.hex()), at + 32


def parse_intent(raw: bytes) -> dict[str, Any]:
    assert len(raw) <= 16_384 and raw[:8] == INTENT_MAGIC
    at = 8
    assert struct.unpack_from(">I", raw, at)[0] == 1
    at += 4
    custody_path, at = take_text(raw, at, 4096)
    old_size = struct.unpack_from(">H", raw, at)[0]
    at += 2
    assert 0 < old_size <= 1024
    old_bytes = raw[at:at + old_size]
    at += old_size
    old_digest = raw[at:at + 32]
    at += 32
    assert hashlib.sha256(old_bytes).digest() == old_digest
    new_generation = struct.unpack_from(">Q", raw, at)[0]
    at += 8
    kind = raw[at]
    at += 1
    assert kind in (1, 2)
    source_path, at = take_text(raw, at, 4096)
    representation_bytes = struct.unpack_from(">Q", raw, at)[0]
    at += 8
    representation_digest = raw[at:at + 32].hex()
    at += 32
    authenticated_bytes = struct.unpack_from(">Q", raw, at)[0]
    at += 8
    authenticated_digest = raw[at:at + 32].hex()
    at += 32
    logical_digest = raw[at:at + 32].hex()
    at += 32
    identity_generation, at = take_optional_text(raw, at, 128)
    backup_id, at = take_optional_digest(raw, at)
    signer, at = take_optional_digest(raw, at)
    encryption_generation, at = take_optional_text(raw, at, 128)
    encryption_id, at = take_optional_digest(raw, at)
    relationship, at = take_text(raw, at, 64)
    derived_selector, at = take_text(raw, at, 512)
    commitment = raw[at:at + 32]
    at += 32
    assert at == len(raw)
    assert hashlib.sha256(INTENT_DOMAIN + b"\0" + raw[:-32]).digest() == commitment
    return {
        "custody_path": custody_path,
        "old": parse_record(old_bytes),
        "old_digest": old_digest.hex(),
        "new_generation": new_generation,
        "kind": kind,
        "source_path": source_path,
        "representation_bytes": representation_bytes,
        "representation_digest": representation_digest,
        "authenticated_bytes": authenticated_bytes,
        "authenticated_digest": authenticated_digest,
        "logical_state_digest": logical_digest,
        "identity_generation": identity_generation,
        "backup_id": backup_id,
        "signer": signer,
        "encryption_generation": encryption_generation,
        "encryption_id": encryption_id,
        "relationship": relationship,
        "derived_selector": derived_selector,
        "commitment": commitment.hex(),
        "file_digest": hashlib.sha256(raw).hexdigest(),
    }


def create_state_args(intent: Path, record_path: Path, record: dict[str, Any],
                      generation: int, state: Path, key: Path) -> list[str]:
    return ["state-head-custody-promotion-intent-create", "--intent", str(intent),
        *exact_args(record_path, record), "--new-generation", str(generation),
        "--state", str(state), "--state-auth-key", str(key)]


def use_state_args(command: str, intent: Path, record_path: Path,
                   state: Path, key: Path) -> list[str]:
    return [command, "--intent", str(intent), "--record", str(record_path),
        "--state", str(state), "--state-auth-key", str(key)]


def create_backup_args(intent: Path, record_path: Path, record: dict[str, Any],
                       generation: int, archive: Path, state_key: Path,
                       decrypt_key: Path, certificate: Path,
                       backup_id: str | None = None) -> list[str]:
    args = ["state-head-custody-promotion-intent-create", "--intent", str(intent),
        *exact_args(record_path, record), "--new-generation", str(generation),
        "--input", str(archive), "--generation", "a-g1",
        "--state-auth-key", str(state_key), "--decrypt-key", str(decrypt_key),
        "--trusted-cert", str(certificate), "--require-signature", "yes",
        "--require-encryption", "yes"]
    if backup_id is not None:
        args += ["--expected-backup-id", backup_id]
    return args


def use_backup_args(command: str, intent: Path, record_path: Path,
                    archive: Path, state_key: Path, decrypt_key: Path,
                    certificate: Path, backup_id: str | None = None) -> list[str]:
    args = [command, "--intent", str(intent), "--record", str(record_path),
        "--input", str(archive), "--generation", "a-g1",
        "--state-auth-key", str(state_key), "--decrypt-key", str(decrypt_key),
        "--trusted-cert", str(certificate), "--require-signature", "yes",
        "--require-encryption", "yes"]
    if backup_id is not None:
        args += ["--expected-backup-id", backup_id]
    return args


def run_with_environment(h: Harness, label: str, args: list[str],
                         environment: dict[str, str], expected: int = 0,
                         timeout: int = 30) -> dict[str, Any] | None:
    started = time.time()
    completed = subprocess.run([str(h.binary), *args], capture_output=True,
        text=True, timeout=timeout, env=dict(os.environ, **environment))
    h.commands.append({"label": label, "args": args,
        "returncode": completed.returncode, "stdout": completed.stdout,
        "stderr": completed.stderr, "elapsed_seconds": time.time() - started,
        "environment": sorted(environment)})
    (h.logs / f"{len(h.commands):03d}-{label}.stdout.txt").write_text(completed.stdout)
    (h.logs / f"{len(h.commands):03d}-{label}.stderr.txt").write_text(completed.stderr)
    h.check(completed.returncode == expected,
        f"{label}: return {completed.returncode}, expected {expected}; "
        f"stdout={completed.stdout!r} stderr={completed.stderr!r}")
    lines = [line for line in completed.stdout.splitlines() if line.strip()]
    return json.loads(lines[-1]) if lines else None


def run_external(h: Harness, label: str, binary: Path, args: list[str],
                 expected_nonzero: bool = True) -> dict[str, Any] | None:
    started = time.time()
    completed = subprocess.run([str(binary), *args], capture_output=True,
        text=True, timeout=30, env=os.environ.copy())
    h.commands.append({"label": label, "binary": str(binary), "args": args,
        "returncode": completed.returncode, "stdout": completed.stdout,
        "stderr": completed.stderr, "elapsed_seconds": time.time() - started})
    (h.logs / f"{len(h.commands):03d}-{label}.stdout.txt").write_text(completed.stdout)
    (h.logs / f"{len(h.commands):03d}-{label}.stderr.txt").write_text(completed.stderr)
    if expected_nonzero:
        h.check(completed.returncode != 0, f"{label}: predecessor unexpectedly accepted new interface")
    lines = [line for line in completed.stdout.splitlines() if line.strip()]
    return json.loads(lines[-1]) if lines else None


def run_suite(h: Harness, selected: set[str] | None,
              predecessor: Path | None) -> None:
    def case(name: str, fn: Callable[[], None]) -> None:
        if selected is None or name in selected:
            h.case(name, fn)

    def state_intent_lifecycle() -> None:
        root, state, key = setup(h, "intent-state")
        old_head = selector((state / "state.journal").read_bytes(), key)
        record_path, old = create_anchor(h, "intent-state-anchor", root / "anchors",
            old_head, generation=7)
        append(h, state, key, "intent-state-next")
        new_head = selector((state / "state.journal").read_bytes(), key)
        intent_dir = root / "intents"
        intent_dir.mkdir(mode=0o700)
        intent = intent_dir / "A.intent"
        before = record_path.read_bytes()
        created = h.run("intent-state-create",
            create_state_args(intent, record_path, old, 8, state, key), timeout=30)
        assert created
        decoded = parse_intent(intent.read_bytes())
        h.check(created["format"] ==
            "NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_INTENT_CREATION_V1" and
            created["authority"] == "NONE_REVALIDATION_REQUIRED",
            "creation reports an explicit evidence-only detached intent")
        h.check(stat.S_IMODE(intent.stat().st_mode) == 0o600 and
            intent.stat().st_nlink == 1,
            "intent is an owner-private single-link regular file")
        h.check(decoded["custody_path"] == str(record_path.resolve()) and
            decoded["old_digest"] == old["record_digest"] and
            decoded["new_generation"] == 8,
            "independent decoder recovers the exact old custody account and intended generation")
        h.check(decoded["kind"] == 1 and decoded["source_path"] == str(state.resolve()) and
            decoded["derived_selector"] == new_head and
            decoded["relationship"] == "VERIFIED_APPEND_ONLY_EXTENSION",
            "intent binds exact state-directory representation and verified successor")
        h.check(record_path.read_bytes() == before,
            "intent creation does not advance custody")
        pending = h.run("intent-state-audit-pending",
            use_state_args("state-head-custody-promotion-audit", intent,
                record_path, state, key), timeout=30)
        assert pending
        h.check(pending["classification"] == "NOT_APPLIED_EXACT_OLD_RECORD" and
            pending["input_mode"] == "DETACHED_INTENT",
            "detached audit distinguishes a validated but unapplied intent")
        promoted = h.run("intent-state-promote",
            use_state_args("state-head-custody-promote", intent,
                record_path, state, key), timeout=30)
        assert promoted
        current = parse_record(record_path.read_bytes())
        h.check(promoted["input_mode"] == "DETACHED_INTENT" and
            promoted["derived_state_head"] == new_head and
            current["generation"] == 8 and current["selector"] == new_head,
            "promotion revalidates source and publishes the exact derived successor")
        applied = h.run("intent-state-audit-applied",
            use_state_args("state-head-custody-promotion-audit", intent,
                record_path, state, key), timeout=30)
        assert applied
        h.check(applied["classification"] == "APPLIED_EXACT_DERIVED_SUCCESSOR" and
            applied["mutation"] == "NONE",
            "read-only audit reconstructs an applied outcome without retrying")
        duplicate = h.run("intent-state-duplicate-promote",
            use_state_args("state-head-custody-promote", intent,
                record_path, state, key), expected=3, timeout=30)
        h.check(duplicate and duplicate["code"] ==
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_CUSTODY_MISMATCH",
            "intent is not an idempotency token or permission to overwrite a successor")

    case("state_intent_lifecycle", state_intent_lifecycle)

    def exact_source_and_custody_binding() -> None:
        root, state, key = setup(h, "intent-binding")
        old_head = selector((state / "state.journal").read_bytes(), key)
        record_path, old = create_anchor(h, "intent-binding-anchor", root / "anchors", old_head)
        append(h, state, key, "intent-binding-next")
        intents = root / "intents"; intents.mkdir(mode=0o700)
        intent = intents / "binding.intent"
        h.run("intent-binding-create", create_state_args(intent, record_path, old,
            2, state, key), timeout=30)
        record_before = record_path.read_bytes()

        clone = root / "state-clone"
        shutil.copytree(state, clone)
        path_mismatch = h.run("intent-binding-source-path",
            use_state_args("state-head-custody-promote", intent, record_path,
                clone, key), expected=3, timeout=30)
        h.check(path_mismatch and path_mismatch["code"] ==
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_SOURCE_MISMATCH",
            "byte-identical source at a different explicit path cannot satisfy the intent")

        append(h, state, key, "intent-binding-later")
        changed = h.run("intent-binding-source-changed",
            use_state_args("state-head-custody-promote", intent, record_path,
                state, key), expected=3, timeout=30)
        h.check(changed and changed["code"] ==
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_SOURCE_MISMATCH" and
            record_path.read_bytes() == record_before,
            "later valid source state cannot silently retarget the detached intent")

        # Build a fresh fixture for divergent-current-custody classification.
        droot, dstate, dkey = setup(h, "intent-custody-diverged")
        dhead = selector((dstate / "state.journal").read_bytes(), dkey)
        dpath, dold = create_anchor(h, "intent-custody-diverged-anchor",
            droot / "anchors", dhead)
        append(h, dstate, dkey, "intent-custody-diverged-next")
        dintents = droot / "intents"; dintents.mkdir(mode=0o700)
        dintent = dintents / "diverged.intent"
        h.run("intent-custody-diverged-create", create_state_args(
            dintent, dpath, dold, 2, dstate, dkey), timeout=30)
        candidate_head = selector((dstate / "state.journal").read_bytes(), dkey)
        winner, _ = create_anchor(h, "intent-custody-diverged-winner",
            droot / "anchors", candidate_head, domain="independent-winner",
            generation=99, filename="winner.head")
        os.replace(winner, dpath)
        diverged = h.run("intent-custody-diverged-audit",
            use_state_args("state-head-custody-promotion-audit", dintent,
                dpath, dstate, dkey), timeout=30)
        assert diverged
        h.check(diverged["classification"] == "CURRENT_CUSTODY_DIVERGED" and
            diverged["current_custody"]["custody_generation"] == 99,
            "audit preserves and reports an independently selected current custody winner")

    case("exact_source_and_custody_binding", exact_source_and_custody_binding)

    def creation_source_eligibility_and_races() -> None:
        # An authenticated source older than the exact custody head must not
        # be converted into a durable intent.
        sroot, sstate, skey = setup(h, "intent-create-stale")
        stale = sroot / "stale-state"
        shutil.copytree(sstate, stale)
        append(h, sstate, skey, "intent-create-stale-new")
        shead = selector((sstate / "state.journal").read_bytes(), skey)
        spath, sold = create_anchor(h, "intent-create-stale-anchor",
            sroot / "anchors", shead)
        sintents = sroot / "intents"; sintents.mkdir(mode=0o700)
        sintent = sintents / "stale.intent"
        stale_value = h.run("intent-create-stale-source", create_state_args(
            sintent, spath, sold, 2, stale, skey), expected=3, timeout=30)
        h.check(stale_value and stale_value["code"] ==
            "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_STALE" and not sintent.exists(),
            "stale authenticated source cannot publish a detached intent")

        # A longer authenticated branch that does not contain the exact old
        # prefix is divergent, not a successor.
        droot, left, dkey = setup(h, "intent-create-divergent")
        right = droot / "right-branch"
        shutil.copytree(left, right)
        append(h, left, dkey, "intent-create-left")
        left_head = selector((left / "state.journal").read_bytes(), dkey)
        dpath, dold = create_anchor(h, "intent-create-divergent-anchor",
            droot / "anchors", left_head)
        append(h, right, dkey, "intent-create-right-1")
        append(h, right, dkey, "intent-create-right-2")
        dintents = droot / "intents"; dintents.mkdir(mode=0o700)
        dintent = dintents / "divergent.intent"
        divergent = h.run("intent-create-divergent-source", create_state_args(
            dintent, dpath, dold, 2, right, dkey), expected=3, timeout=30)
        h.check(divergent and divergent["code"] ==
            "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_DIVERGENT" and
            not dintent.exists(),
            "divergent authenticated source cannot publish a detached intent")

        # Replace the journal pathname with a byte-identical fresh inode after
        # validation and staging. Exact source identity, not merely content,
        # must survive through publication.
        rroot, rstate, rkey = setup(h, "intent-create-source-race")
        rhead = selector((rstate / "state.journal").read_bytes(), rkey)
        rpath, rold = create_anchor(h, "intent-create-source-race-anchor",
            rroot / "anchors", rhead)
        append(h, rstate, rkey, "intent-create-source-race-next")
        rintents = rroot / "intents"; rintents.mkdir(mode=0o700)
        rintent = rintents / "source-race.intent"
        rargs = create_state_args(rintent, rpath, rold, 2, rstate, rkey)
        started = time.time()
        process = subprocess.Popen([str(h.binary), *rargs], stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, env=dict(os.environ,
                NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_INTENT_PAUSE_CREATE_MS="700"))
        deadline = time.time() + 5
        while time.time() < deadline and not list(rintents.glob(
                f".{rintent.name}.promotion-intent-*.tmp")):
            time.sleep(0.01)
        replacement = rstate / "state.journal.replacement"
        shutil.copy2(rstate / "state.journal", replacement)
        os.chmod(replacement, 0o600)
        os.replace(replacement, rstate / "state.journal")
        stdout, stderr = process.communicate(timeout=30)
        h.commands.append({"label": "intent-create-source-replacement-race",
            "args": rargs, "returncode": process.returncode, "stdout": stdout,
            "stderr": stderr, "elapsed_seconds": time.time() - started,
            "environment": [
                "NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_INTENT_PAUSE_CREATE_MS"]})
        (h.logs / f"{len(h.commands):03d}-intent-create-source-replacement-race.stdout.txt").write_text(stdout)
        (h.logs / f"{len(h.commands):03d}-intent-create-source-replacement-race.stderr.txt").write_text(stderr)
        h.check(process.returncode == 3,
            "state-journal pathname replacement is rejected during intent creation")
        source_race = json.loads(
            [line for line in stdout.splitlines() if line.strip()][-1])
        h.check(source_race["code"] == "STATE_AUTH_SOURCE_CHANGED" and
            not rintent.exists(),
            "source replacement fails before detached-intent publication")

        # Independently replace the custody path while the candidate is
        # staged. The unrelated winner must remain and no intent may appear.
        croot, cstate, ckey = setup(h, "intent-create-custody-race")
        chead = selector((cstate / "state.journal").read_bytes(), ckey)
        cpath, cold = create_anchor(h, "intent-create-custody-race-anchor",
            croot / "anchors", chead)
        append(h, cstate, ckey, "intent-create-custody-race-next")
        winner_path, _ = create_anchor(h, "intent-create-custody-race-winner",
            croot / "anchors", selector((cstate / "state.journal").read_bytes(), ckey),
            domain="independent-winner", generation=99, filename="winner.head")
        winner_bytes = winner_path.read_bytes()
        cintents = croot / "intents"; cintents.mkdir(mode=0o700)
        cintent = cintents / "custody-race.intent"
        cargs = create_state_args(cintent, cpath, cold, 2, cstate, ckey)
        started = time.time()
        process = subprocess.Popen([str(h.binary), *cargs], stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, env=dict(os.environ,
                NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_INTENT_PAUSE_CREATE_MS="700"))
        deadline = time.time() + 5
        while time.time() < deadline and not list(cintents.glob(
                f".{cintent.name}.promotion-intent-*.tmp")):
            time.sleep(0.01)
        os.replace(winner_path, cpath)
        stdout, stderr = process.communicate(timeout=30)
        h.commands.append({"label": "intent-create-custody-replacement-race",
            "args": cargs, "returncode": process.returncode, "stdout": stdout,
            "stderr": stderr, "elapsed_seconds": time.time() - started,
            "environment": [
                "NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_INTENT_PAUSE_CREATE_MS"]})
        (h.logs / f"{len(h.commands):03d}-intent-create-custody-replacement-race.stdout.txt").write_text(stdout)
        (h.logs / f"{len(h.commands):03d}-intent-create-custody-replacement-race.stderr.txt").write_text(stderr)
        h.check(process.returncode == 3,
            "custody pathname replacement is rejected during intent creation")
        custody_race = json.loads(
            [line for line in stdout.splitlines() if line.strip()][-1])
        h.check(custody_race["code"] == "STATE_HEAD_CUSTODY_REPLACEMENT_RACE" and
            not cintent.exists() and cpath.read_bytes() == winner_bytes,
            "custody replacement fails before publication and preserves the independent winner")

    case("creation_source_eligibility_and_races",
         creation_source_eligibility_and_races)

    def intent_publication_and_replacement_races() -> None:
        root, state, key = setup(h, "intent-race")
        old_head = selector((state / "state.journal").read_bytes(), key)
        record_path, old = create_anchor(h, "intent-race-anchor", root / "anchors", old_head)
        append(h, state, key, "intent-race-next")
        intents = root / "intents"; intents.mkdir(mode=0o700)
        intent = intents / "race.intent"
        create_args = create_state_args(intent, record_path, old, 2, state, key)
        h.run("intent-race-create", create_args, timeout=30)
        before = intent.read_bytes()
        duplicate = h.run("intent-race-duplicate-create", create_args,
            expected=3, timeout=30)
        h.check(duplicate and duplicate["code"] ==
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_DESTINATION_EXISTS" and
            intent.read_bytes() == before,
            "creation is atomic no-replace and never aliases an existing artifact")

        replacement = intents / "replacement.intent"
        replacement.write_bytes(before)
        os.chmod(replacement, 0o600)
        args = use_state_args("state-head-custody-promotion-audit", intent,
            record_path, state, key)
        started = time.time()
        process = subprocess.Popen([str(h.binary), *args], stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, env=dict(os.environ,
                NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_INTENT_PAUSE_CONSUME_MS="700"))
        time.sleep(0.2)
        os.replace(replacement, intent)
        stdout, stderr = process.communicate(timeout=30)
        h.commands.append({"label": "intent-race-replacement", "args": args,
            "returncode": process.returncode, "stdout": stdout, "stderr": stderr,
            "elapsed_seconds": time.time() - started,
            "environment": ["NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_INTENT_PAUSE_CONSUME_MS"]})
        (h.logs / f"{len(h.commands):03d}-intent-race-replacement.stdout.txt").write_text(stdout)
        (h.logs / f"{len(h.commands):03d}-intent-race-replacement.stderr.txt").write_text(stderr)
        h.check(process.returncode == 3,
            "intent pathname replacement suppresses apparent audit success")
        value = json.loads([line for line in stdout.splitlines() if line.strip()][-1])
        h.check(value["code"] ==
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_REPLACEMENT_RACE",
            "replacement race has a precise fail-closed outcome")

        os.chmod(intent, 0o644)
        permissions = h.run("intent-race-permissions",
            use_state_args("state-head-custody-promote", intent, record_path,
                state, key), expected=3, timeout=30)
        h.check(permissions and permissions["code"] ==
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_FILE_PERMISSIONS_INVALID",
            "consumption requires exact owner-private intent permissions")

    case("intent_publication_and_replacement_races",
         intent_publication_and_replacement_races)

    def backup_intent_lifecycle_and_trust() -> None:
        root, state, key = setup(h, "intent-backup")
        old_head = selector((state / "state.journal").read_bytes(), key)
        record_path, old = create_anchor(h, "intent-backup-anchor",
            root / "anchors", old_head, domain="backup-intent", generation=4)
        encryption = backup_key(h, root, "intent-backup", "enc-g1")
        archive, exported = export_backup(h, "intent-backup", state, key, encryption)
        intents = root / "intents"; intents.mkdir(mode=0o700)
        intent = intents / "backup.intent"
        certificate = h.identity("A").certificate
        created = h.run("intent-backup-create", create_backup_args(intent,
            record_path, old, 5, archive, key, encryption, certificate,
            exported["backup_id"]), timeout=30)
        assert created
        decoded = parse_intent(intent.read_bytes())
        h.check(decoded["kind"] == 2 and decoded["backup_id"] == exported["backup_id"] and
            decoded["identity_generation"] == "a-g1" and decoded["signer"] is not None and
            decoded["encryption_id"] is not None,
            "backup intent binds outer representation, embedded checkpoint, signer, and encryption identity")
        pending = h.run("intent-backup-pending", use_backup_args(
            "state-head-custody-promotion-audit", intent, record_path,
            archive, key, encryption, certificate, exported["backup_id"]), timeout=30)
        assert pending
        h.check(pending["classification"] == "NOT_APPLIED_EXACT_OLD_RECORD",
            "backup intent can be audited before application")

        wrong_key = new_key(h, root, "intent-backup-wrong-state")
        wrong_decrypt = backup_key(h, root, "intent-backup-wrong-decrypt", "enc-g2")
        attempts = [
            ("state-key", wrong_key, encryption, certificate),
            ("decrypt", key, wrong_decrypt, certificate),
            ("signer", key, encryption, h.identity("B").certificate),
        ]
        before = record_path.read_bytes()
        for label, state_key, decrypt, cert in attempts:
            denied = h.run("intent-backup-wrong-" + label, use_backup_args(
                "state-head-custody-promote", intent, record_path, archive,
                state_key, decrypt, cert, exported["backup_id"]), expected=3,
                timeout=30)
            h.check(denied and denied.get("ok") is False and
                record_path.read_bytes() == before,
                "wrong backup trust material cannot convert intent evidence into authority")

        promoted = h.run("intent-backup-promote", use_backup_args(
            "state-head-custody-promote", intent, record_path, archive,
            key, encryption, certificate, exported["backup_id"]), timeout=30)
        assert promoted
        applied = h.run("intent-backup-applied", use_backup_args(
            "state-head-custody-promotion-audit", intent, record_path,
            archive, key, encryption, certificate, exported["backup_id"]), timeout=30)
        assert applied
        h.check(promoted["source"]["kind"] == "SIGNED_ENCRYPTED_BACKUP" and
            applied["classification"] == "APPLIED_EXACT_DERIVED_SUCCESSOR",
            "signed encrypted backup intent revalidates and reaches the exact successor")

    case("backup_intent_lifecycle_and_trust", backup_intent_lifecycle_and_trust)

    def strict_cli_and_predecessor_fail_closed() -> None:
        root, state, key = setup(h, "intent-strict")
        old_head = selector((state / "state.journal").read_bytes(), key)
        record_path, old = create_anchor(h, "intent-strict-anchor", root / "anchors", old_head)
        append(h, state, key, "intent-strict-next")
        intents = root / "intents"; intents.mkdir(mode=0o700)
        intent = intents / "strict.intent"
        h.run("intent-strict-create", create_state_args(intent, record_path,
            old, 2, state, key), timeout=30)
        before_record = record_path.read_bytes()
        conflict = h.run("intent-strict-inline-conflict", [
            *use_state_args("state-head-custody-promote", intent, record_path, state, key),
            "--expect-node", "A"], expected=3)
        h.check(conflict and conflict["code"] ==
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_ARGUMENT_CONFLICT",
            "detached and inline authority descriptions cannot be mixed")
        no_key = use_state_args("state-head-custody-promote", intent,
            record_path, state, key)
        at = no_key.index("--state-auth-key")
        del no_key[at:at + 2]
        missing_key = h.run("intent-strict-no-state-key", no_key, expected=3)
        h.check(missing_key and missing_key["code"] == "STATE_AUTH_KEY_REQUIRED",
            "intent never substitutes for the exact state authentication key")
        corrupt = bytearray(intent.read_bytes())
        corrupt[-1] ^= 1
        intent.write_bytes(corrupt)
        os.chmod(intent, 0o600)
        malformed = h.run("intent-strict-corrupt", use_state_args(
            "state-head-custody-promote", intent, record_path, state, key),
            expected=3, timeout=30)
        h.check(malformed and malformed["code"] ==
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID" and
            record_path.read_bytes() == before_record,
            "noncanonical or corrupted intent bytes fail before custody mutation")

        if predecessor is not None:
            old_command = run_external(h, "intent-strict-predecessor-command",
                predecessor, create_state_args(root / "old.intent", record_path,
                    old, 2, state, key))
            h.check(old_command and old_command.get("code") in
                {"UNKNOWN_COMMAND", "UNKNOWN_ARGUMENT", "INVALID_ARGUMENT"},
                "predecessor rejects the unknown intent-creation operation")
            old_use = run_external(h, "intent-strict-predecessor-use",
                predecessor, use_state_args("state-head-custody-promote",
                    root / "missing.intent", record_path, state, key))
            h.check(old_use and old_use.get("ok") is False and
                record_path.read_bytes() == before_record,
                "predecessor fails closed on detached-intent consumption syntax")

    case("strict_cli_and_predecessor_fail_closed",
         strict_cli_and_predecessor_fail_closed)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--predecessor", type=Path)
    parser.add_argument("--case", action="append", choices=CASES)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    harness = Harness(args.binary, args.output)
    started = time.time(); code = 1
    try:
        run_suite(harness, set(args.case) if args.case else None,
                  args.predecessor.resolve() if args.predecessor else None)
        code = 0
    except BaseException as error:
        (harness.output / "FAILURE.txt").write_text(
            f"{type(error).__name__}: {error}\n")
        print(f"FAIL: {type(error).__name__}: {error}", file=sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_CUSTODY_PROMOTION_INTENT_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "predecessor_sha256": hashlib.sha256(args.predecessor.read_bytes()).hexdigest()
                if args.predecessor else None,
            "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (("SUMMARY.json", summary),
                ("CASES.json", harness.cases), ("COMMANDS.json", harness.commands)):
            (harness.output / name).write_text(
                json.dumps(value, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
