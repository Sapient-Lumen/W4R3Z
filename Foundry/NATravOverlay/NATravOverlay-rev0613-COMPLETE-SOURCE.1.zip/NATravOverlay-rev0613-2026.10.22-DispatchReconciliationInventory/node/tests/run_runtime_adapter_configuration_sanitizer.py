#!/usr/bin/env python3
"""Strict ASan/UBSan/leak probe for the exact V19 policy translation units."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,time

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    a=parser.parse_args();r=a.source_root.resolve();o=a.output.resolve()
    if o.exists():parser.error('output must not exist')
    o.mkdir(parents=True);build=o/'build';build.mkdir();commands=[];start=time.monotonic();rc=1;error=None
    flags=['-D_GNU_SOURCE','-std=c++20','-O1','-g','-fno-omit-frame-pointer','-ffunction-sections','-fdata-sections',
           '-Wall','-Wextra','-Wpedantic','-Wconversion','-Wsign-conversion','-Wshadow','-Wformat=2','-Werror',
           '-fsanitize=address,undefined','-fno-pie',f'-I{r}/foundation/include',f'-I{r}/node/src']
    sources=['node/src/adapter_profile.cpp','node/src/adapter_profile_catalog.cpp','node/src/adapter_configuration.cpp',
             'node/src/common.cpp','foundation/src/core.cpp','node/tests/test_runtime_adapter_configuration.cpp']
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    def run(name,cmd):
        begin=time.monotonic()
        with (o/(name+'.stdout')).open('wb') as out,(o/(name+'.stderr')).open('wb') as err:
            result=subprocess.run(cmd,cwd=r,env=env,stdout=out,stderr=err,timeout=300,check=False)
        commands.append({'name':name,'command':cmd,'returncode':result.returncode,'elapsed_seconds':time.monotonic()-begin})
        if result.returncode:raise RuntimeError(name+' failed')
    try:
        objects=[]
        for index,source in enumerate(sources):
            obj=build/(str(index)+'.o');run('compile-'+str(index),['g++',*flags,'-c',str(r/source),'-o',str(obj)]);objects.append(str(obj))
        exe=build/'probe';run('link',['g++',*objects,'-fsanitize=address,undefined','-no-pie','-pthread','-Wl,--gc-sections','-lcrypto','-lz','-lzstd','-o',str(exe)])
        run('probe',[str(exe)]);probe=json.loads((o/'probe.stdout').read_text())
        if probe.get('status')!='PASS' or (o/'probe.stderr').stat().st_size:raise RuntimeError('probe did not pass cleanly')
        rc=0
    except BaseException as e:error=repr(e);probe=None
    summary={'status':'PASS' if rc==0 else 'FAIL','error':error,'probe':probe,'commands':commands,'elapsed_seconds':time.monotonic()-start,
             'source_sha256':{s:hashlib.sha256((r/s).read_bytes()).hexdigest() for s in sources}}
    (o/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ('commands','source_sha256')}));return rc
if __name__=='__main__':raise SystemExit(main())
