#include "handoff_policy.hpp"
#include <functional>
#include <iostream>
#include <memory>
using namespace natrav_overlay;
namespace {
std::size_t checks = 0U;
void check(bool value, const char* reason) { ++checks; if (!value) { throw std::runtime_error(reason); } }
void reject(const std::function<void()>& fn, std::string_view code = {}) {
    try { fn(); } catch (const AppError& e) { check(code.empty() || e.code() == code, e.what()); return; }
    check(false, "expected rejection");
}
std::string hex(std::string_view t) { return hex_bytes(datacube::OctetView(reinterpret_cast<const std::uint8_t*>(t.data()),t.size())); }
}
int main() {
    try {
        HandoffKeyBytes seed{}; seed.fill(9U);
        std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)> signer(EVP_PKEY_new_raw_private_key(EVP_PKEY_ED25519,nullptr,seed.data(),seed.size()),EVP_PKEY_free);
        const auto make = [&](std::string node, std::uint8_t key, std::uint64_t sequence, datacube::Digest32 previous = {}) {
            HandoffKeyBytes secret{}; secret.fill(key);
            return HandoffKeyPolicyRecord{sequence,previous,make_handoff_binding(node,"g1","h"+std::to_string(sequence),signer.get(),handoff_x25519_public(secret)),HandoffKeyState::active};
        };
        auto one=make("A",1U,1U);
        const auto text=handoff_key_policy_text(one);
        check(handoff_key_policy_text(parse_handoff_key_policy(hex(text)))==text,"policy canonical roundtrip");
        auto retired=one;retired.state=HandoffKeyState::retired;
        auto revoked=one;revoked.state=HandoffKeyState::revoked;
        check(handoff_key_commitment(one)==handoff_key_commitment(retired) && handoff_key_commitment(one)==handoff_key_commitment(revoked),"immutable commitment excludes lifecycle status");
        check(text!=handoff_key_policy_text(retired),"state still changes canonical config record");
        auto two=make("A",2U,2U,handoff_key_commitment(one));
        HandoffKeyPolicy p{two,retired};normalize_handoff_key_policy(p);
        check(p.front().sequence==1U && p.back().sequence==2U,"sort numeric sequence");
        require_handoff_key_history_preserved({one},p);check(true,"authorized succession");
        require_handoff_key_history_preserved({one},{revoked});check(true,"direct emergency revocation allowed");
        require_handoff_key_use(p,one.binding,false);check(true,"retirement permits delayed import");
        require_handoff_key_use(p,two.binding,true);check(true,"active successor used exactly");
        reject([&]{require_handoff_key_use(p,one.binding,true);},"HANDOFF_KEY_RETIRED");
        reject([&]{require_handoff_key_use({revoked},one.binding,false);},"HANDOFF_KEY_REVOKED");
        reject([&]{require_handoff_key_use({},one.binding,false);},"HANDOFF_KEY_NOT_COMMITTED");
        auto drift=make("A",3U,1U);
        reject([&]{require_handoff_key_use(p,drift.binding,false);},"HANDOFF_KEY_NOT_COMMITTED");
        reject([&]{require_handoff_key_history_preserved({one},{drift});},"CONFIG_HANDOFF_GENERATION_CONFLICT");
        reject([&]{require_handoff_key_history_preserved({one},{});},"CONFIG_HANDOFF_HISTORY_REMOVED");
        reject([&]{require_handoff_key_history_preserved({retired},{one});},"CONFIG_HANDOFF_STATE_ROLLBACK");
        reject([&]{require_handoff_key_history_preserved({revoked},{retired});},"CONFIG_HANDOFF_STATE_ROLLBACK");
        auto normalize=[](HandoffKeyPolicy r){normalize_handoff_key_policy(r);};
        reject([&]{normalize({one,two});},"CONFIG_HANDOFF_ACTIVE_CONFLICT");
        reject([&]{normalize({two});},"CONFIG_HANDOFF_PREDECESSOR");
        auto wrong=two;wrong.predecessor={};reject([&]{normalize({retired,wrong});},"CONFIG_HANDOFF_PREDECESSOR");
        wrong=two;wrong.sequence=3U;reject([&]{normalize({retired,wrong});},"CONFIG_HANDOFF_PREDECESSOR");
        reject([&]{normalize({one,one});},"CONFIG_HANDOFF_GENERATION_CONFLICT");
        auto reused=make("B",1U,1U);reject([&]{normalize({one,reused});},"CONFIG_HANDOFF_KEY_REUSE");
        auto fabricated=one;fabricated.binding.handoff_generation="other";reject([&]{normalize({fabricated});},"HANDOFF_IDENTITY_REJECTED");
        for(std::size_t i=0U;i<text.size();++i){reject([&]{(void)parse_handoff_key_policy(hex(std::string_view(text).substr(0,i)));});}
        reject([&]{(void)parse_handoff_key_policy(hex(text+"extra\n"));},"CONFIG_HANDOFF_RECORD_NONCANONICAL");
        auto leading=text;leading.replace(leading.find("sequence=1"),10U,"sequence=01");
        reject([&]{(void)parse_handoff_key_policy(hex(leading));});
        reject([&]{(void)parse_handoff_key_policy("A0");},"CONFIG_HANDOFF_RECORD_NONCANONICAL");
        reject([&]{(void)parse_handoff_key_policy("1");},"CONFIG_HANDOFF_RECORD_INVALID");
        reject([&]{(void)parse_handoff_key_policy(std::string(3002U,'0'));},"CONFIG_HANDOFF_RECORD_INVALID");
        auto signature=text;const auto bpos=signature.find("binding_hex=")+12U;signature[bpos+100U]=signature[bpos+100U]=='0'?'1':'0';
        reject([&]{(void)parse_handoff_key_policy(hex(signature));});
        HandoffKeyPolicy bounded;
        for(std::uint64_t i=1U;i<=kHandoffPolicyPerNodeLimit;++i){
            auto r=make("A",static_cast<std::uint8_t>(i),i,bounded.empty()?datacube::Digest32{}:handoff_key_commitment(bounded.back()));
            r.state=HandoffKeyState::retired;bounded.push_back(r);
        }
        normalize(bounded);check(true,"maximum per-node chain accepted");
        bounded.push_back(make("A",17U,17U,handoff_key_commitment(bounded.back())));
        reject([&]{normalize(bounded);},"CONFIG_HANDOFF_SEQUENCE");
        reject([&]{normalize(HandoffKeyPolicy(kHandoffPolicyRecordLimit+1U,one));},"CONFIG_HANDOFF_CAPACITY");
        std::cout << "{\"status\":\"PASS\",\"case_groups\":8,\"assertions\":" << checks << "}\n";
    } catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
