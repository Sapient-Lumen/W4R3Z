#!/usr/bin/env python3
"""Static authority audit for revision 0613 explicit owner custody dispatch."""
from pathlib import Path

root = Path(__file__).resolve().parents[2]
source = root / "node/src"
policy_h = (source / "custody_dispatch_policy.hpp").read_text()
policy_c = (source / "custody_dispatch_policy.cpp").read_text()
config_h = (source / "config.hpp").read_text()
config_c = (source / "config.cpp").read_text()
runtime_c = (source / "runtime.cpp").read_text()
service_h = (source / "custody_session_service.hpp").read_text()
service_c = (source / "custody_session_service.cpp").read_text()
control_h = (source / "control.hpp").read_text()
control_c = (source / "control.cpp").read_text()
daemon_c = (source / "daemon.cpp").read_text()
main_c = (source / "main.cpp").read_text()
build = (root / "node/build.sh").read_text()
matrix = (root / "node/tests/run_matrix.py").read_text()
integration = (root / "node/tests/run_owner_custody_dispatch.py").read_text()

dispatch_body = service_c.split(
    "CustodySessionServiceResult CustodyOwnerDispatcher::dispatch_once", 1)[1].split(
    "CustodySessionServiceResult run_custody_session_send", 1)[0]
source_body = service_c.split(
    "CustodyBundle retained_dispatch_source", 1)[1].split(
    "CustodySessionServiceResult perform_committed_attempt", 1)[0]
attempt_body = service_c.split(
    "CustodySessionServiceResult perform_committed_attempt", 1)[1].split(
    "struct OwnerDispatchRecord", 1)[0]
cli_body = main_c.split('if (command == "custody-dispatch")', 1)[1].split(
    'if (command == "cancel")', 1)[0]
handler_body = daemon_c.split(
    "[[nodiscard]] bool handle_control_connection", 1)[1].split(
    "int run_persistent_node", 1)[0]
fresh_dispatch_body = dispatch_body.split(
    "const OwnerDispatchRecord record", 1)[1]

required = {
    "V24 feature name":
        "V24_EXPLICIT_OWNER_CUSTODY_DISPATCH_V1" in policy_h,
    "V24 configuration header":
        "NATRAV_OVERLAY_CONFIG_V24" in config_c,
    "canonical V24 record":
        "custody_dispatch_hex" in config_c and
        "NATRAV_CUSTODY_DISPATCH_ACTIVATION_V1" in policy_c,
    "default-off retained policy":
        "CustodyDispatchPolicy custody_dispatch" in config_h and
        "CUSTODY_DISPATCH_DISABLED" in dispatch_body,
    "exact V23 and V22 commitments": all(token in policy_h for token in (
        "receiver_activation_id", "receiver_activation_generation",
        "receiver_activation_commitment", "outbound_session_rule_id",
        "outbound_session_rule_generation",
        "outbound_session_rule_commitment")),
    "exact named route commitment":
        "route_id" in policy_h and "route_commitment" in policy_h and
        "custody_dispatch_route_commitment" in policy_c,
    "finite activation bounds": all(token in policy_h for token in (
        "kCustodyDispatchActivationLimit",
        "kCustodyDispatchActivationPerIdLimit",
        "kCustodyDispatchMaximumConcurrent",
        "kCustodyDispatchMaximumAttempts")),
    "explicit lifecycle": all(token in policy_h for token in (
        "active = 1U", "retired = 2U", "revoked = 3U")),
    "monotonic lifecycle history":
        "require_custody_dispatch_history_preserved" in policy_c and
        "CONFIG_CUSTODY_DISPATCH_STATE_ROLLBACK" in policy_c,
    "V24 downgrade rejection":
        runtime_c.count("CONFIG_CUSTODY_DISPATCH_DOWNGRADE") >= 2,
    "accepted history replay":
        runtime_c.count("require_custody_dispatch_history_preserved") >= 2,
    "exact local receiver and sender roles":
        "CONFIG_CUSTODY_DISPATCH_LOCAL_ROLE" in config_c and
        "exact local V23 receiver and outbound V22 custodian roles" in config_c,
    "V24 bounds subordinate to V23 and V22":
        "activation.maximum_dispatch_attempts >" in config_c and
        "receiver.activation_expires_unix_ms" in config_c and
        "outbound_rule.authority_expires_unix_ms" in config_c,
    "ordinary control-worker reservation":
        "CONFIG_CUSTODY_DISPATCH_FAIRNESS" in config_c and
        "activation.maximum_concurrent_dispatches >=\n                config.control_workers" in config_c,
    "active route is exact and enabled":
        "PeerRouteState::enabled" in config_c and
        "custody_dispatch_route_commitment(" in config_c and
        "CONFIG_CUSTODY_DISPATCH_ROUTE" in config_c,
    "bounded control kind":
        "custody_dispatch = 48U" in control_h and
        "struct ControlCustodyDispatch" in control_h,
    "canonical control codec":
        control_c.count("ControlKind::custody_dispatch") >= 2 and
        "reader.require_eof(\"custody dispatch request\")" in control_c and
        "append_text16(payload, dispatch->reason, 256U" in control_c,
    "authenticated maintenance operation":
        'command = "CUSTODY_DISPATCH"' in daemon_c and
        "LocalControlClass::maintenance" in daemon_c and
        "CUSTODY_DISPATCH_POLICY_VERSION_REQUIRED" in daemon_c,
    "current configuration lease reaches dispatcher":
        "custody_dispatcher.dispatch_once(\n                config" in handler_body,
    "one daemon dispatcher reuses ordinary TLS context":
        daemon_c.count("CustodyOwnerDispatcher custody_owner_dispatcher") == 1 and
        "CustodyOwnerDispatcher custody_owner_dispatcher(state, tls);" in daemon_c,
    "no dispatcher-owned listener scheduler timer or thread": all(
        token not in dispatch_body for token in (
            "listen_transport", "listen_tcp", "listen_unix", "std::thread",
            "sleep_for", "scheduler_signal", "peer_queue")),
    "exact authenticated retained source":
        "validate_offer(authority, message, true)" in source_body and
        "validate_acceptance(authority" in source_body and
        "require_case(state, envelope_sha256)" in source_body and
        "owner dispatch requires the exact current nonterminal custodian" in source_body,
    "unresolved prior transfer remains owner-retryable":
        "retained_unresolved_local_transfer" in source_body and
        "CustodyRecordKind::transfer" in source_body and
        "same retained offer" in source_body,
    "V22 NOS1 sender is reused":
        "OutboundPeerSession::open" in attempt_body and
        ".exchange_message(" in attempt_body and
        "perform_committed_attempt" in dispatch_body,
    "durable dispatch idempotency record":
        "NATRAV_CUSTODY_OWNER_DISPATCH_RECORD_V1" in service_c and
        "request_commitment_sha256" in service_c and
        "dispatch-index" in service_c and "dispatches" in service_c,
    "reservation precedes attempt":
        'persist_exact(record_path' in fresh_dispatch_body and
        'atomic_write_text(dispatch_index_path(' in fresh_dispatch_body and
        'atomic_write_text(prepared.directory / "attempts"' in fresh_dispatch_body and
        fresh_dispatch_body.index('persist_exact(record_path') <
            fresh_dispatch_body.index('atomic_write_text(prepared.directory / "attempts"'),
    "duplicate result precedes new-attempt authority":
        "find_dispatch_outbound_request(" in dispatch_body and
        "return recover_record(authority, prepared);" in dispatch_body and
        dispatch_body.index("find_dispatch_outbound_request(") <
            dispatch_body.index("activation->state == CustodyDispatchActivationState::active"),
    "retirement exact replay and revocation no replay":
        "CUSTODY_DISPATCH_RETIRED" in dispatch_body and
        "CUSTODY_DISPATCH_REVOKED" in dispatch_body and
        dispatch_body.index("CUSTODY_DISPATCH_REVOKED") <
            dispatch_body.index("find_dispatch_outbound_request("),
    "one network attempt per owner request":
        dispatch_body.count("perform_committed_attempt(") == 1 and
        r'automatic_retry\":false' in service_c,
    "finite per-case dispatch requests":
        "dispatch_record_count(" in dispatch_body and
        "maximum_dispatch_attempts" in dispatch_body and
        "CUSTODY_DISPATCH_ATTEMPTS_EXHAUSTED" in dispatch_body,
    "durability cutpoints are externally killable": all(
        f'custody_session_test_pause("{phase}")' in service_c for phase in (
            "BEFORE_DISPATCH_RESERVATION", "AFTER_DISPATCH_RESERVATION",
            "BEFORE_ATTEMPT_INCREMENT", "AFTER_ATTEMPT_INCREMENT")),
    "CLI exposes no route override or retry flag":
        '"custody-dispatch"' in main_c and
        '"--receiver-request"' in cli_body and
        '"--dispatch-request"' in cli_body and
        '"--route"' not in cli_body and '"--retry"' not in cli_body,
    "negative authority markers": all(token in main_c for token in (
        r'\"explicit_owner_custody_dispatch\":true',
        r'\"automatic_custody_sender\":false',
        r'\"automatic_route_relay\":false', r'\"open_relay\":false')),
    "service negative markers": all(token in service_c for token in (
        r'\"automatic_retry\":false',
        r'\"automatic_route_relay\":false',
        r'\"application_delivery_inferred\":false')),
    "single binary build":
        "src/custody_dispatch_policy.cpp" in build and
        "bin/natrav-overlay" in build,
    "registered integration suite":
        '"owner_custody_dispatch"' in matrix,
    "required live loss crash and lifecycle coverage": all(
        token in integration for token in (
            "accepted_v24_policy_and_negative_controls",
            "explicit_dispatch_duplicate_and_no_auto_forward",
            "response_loss_needs_fresh_owner_request",
            "process_death_after_dispatch_reservation_and_stale_seed",
            "concurrent_application_progress_and_monotonic_lifecycle")),
    "revision identity":
        r'\"version\":\"0613\"' in main_c and
        r'\"revision\":\"0613\"' in service_c,
}

failed = [name for name, passed in required.items() if not passed]
if failed:
    raise SystemExit("FAIL: " + ", ".join(failed))
print(f"PASS: {len(required)} owner custody dispatch authority checks")
