#include "transport.hpp"

#include <arpa/inet.h>
#include <array>
#include <cerrno>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <functional>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/socket.h>
#include <thread>
#include <unistd.h>
#include <utility>
#include <vector>

namespace {

using natrav_overlay::AppError;
using natrav_overlay::Deadline;
using natrav_overlay::IoCounters;
using natrav_overlay::OrderedByteStream;
using natrav_overlay::TransportKind;
using natrav_overlay::TransportLocator;

inline constexpr auto kUnknownTransportKind = static_cast<TransportKind>(253U);
static_assert(kUnknownTransportKind != TransportKind::tcp);
static_assert(kUnknownTransportKind != TransportKind::serial);
static_assert(kUnknownTransportKind != TransportKind::udp);
static_assert(kUnknownTransportKind != TransportKind::unix_datagram);
static_assert(kUnknownTransportKind != TransportKind::packet_link);
static_assert(kUnknownTransportKind != TransportKind::virtual_link);

class Probe final {
public:
    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_code(
        Function&& function,
        const std::string_view expected,
        const std::string_view detail) {
        ++assertions_;
        try {
            std::invoke(std::forward<Function>(function));
        } catch (const AppError& error) {
            if (error.code() == expected) {
                return;
            }
            throw std::runtime_error(
                std::string(detail) + ": expected " + std::string(expected) +
                ", observed " + error.code());
        }
        throw std::runtime_error(
            std::string(detail) + ": operation unexpectedly succeeded");
    }

    struct CaseRecord final {
        std::string name;
        std::size_t assertions{0U};
    };

    template <typename Function>
    void run_case(const std::string_view name, Function&& function) {
        const auto before = assertions_;
        try {
            std::invoke(std::forward<Function>(function));
            cases_.push_back(CaseRecord{
                .name = std::string(name),
                .assertions = assertions_ - before,
            });
        } catch (const std::exception& error) {
            throw std::runtime_error(
                std::string(name) + ": " + error.what());
        }
    }

    [[nodiscard]] std::size_t assertions() const noexcept {
        return assertions_;
    }

    [[nodiscard]] const std::vector<CaseRecord>& cases() const noexcept {
        return cases_;
    }

private:
    std::size_t assertions_{0U};
    std::vector<CaseRecord> cases_;
};

[[nodiscard]] Deadline deadline() {
    return std::chrono::steady_clock::now() + std::chrono::seconds(3);
}

[[nodiscard]] datacube::OctetView view(const std::string_view value) {
    return datacube::OctetView(
        reinterpret_cast<const std::uint8_t*>(value.data()), value.size());
}

void stream_write_all(
    OrderedByteStream& stream,
    const std::string_view value,
    IoCounters& counters) {
    const auto bytes = view(value);
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto count = stream.write_some(
            bytes.subspan(offset), deadline(), counters, "probe write");
        if (count == 0U || count > bytes.size() - offset) {
            throw std::runtime_error("stream write made invalid progress");
        }
        offset += count;
    }
}

[[nodiscard]] std::string stream_read_exact(
    OrderedByteStream& stream,
    const std::size_t size,
    IoCounters& counters) {
    std::vector<std::uint8_t> bytes(size);
    std::size_t offset = 0U;
    while (offset < size) {
        const auto count = stream.read_some(
            std::span<std::uint8_t>(bytes).subspan(offset),
            deadline(), counters, "probe read");
        if (count == 0U || count > size - offset) {
            throw std::runtime_error("stream ended before exact payload");
        }
        offset += count;
    }
    return std::string(
        reinterpret_cast<const char*>(bytes.data()), bytes.size());
}

void raw_write_all(const int fd, const std::string_view value) {
    std::size_t offset = 0U;
    while (offset < value.size()) {
        const ssize_t count = ::send(
            fd, value.data() + offset, value.size() - offset, MSG_NOSIGNAL);
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            throw std::runtime_error("raw send failed: " + std::string(std::strerror(errno)));
        }
        if (count == 0) {
            throw std::runtime_error("raw send made no progress");
        }
        offset += static_cast<std::size_t>(count);
    }
}

[[nodiscard]] std::string raw_read_exact(
    const int fd,
    const std::size_t size) {
    std::string result(size, '\0');
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t count = ::recv(
            fd, result.data() + offset, size - offset, 0);
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            throw std::runtime_error("raw recv failed: " + std::string(std::strerror(errno)));
        }
        if (count == 0) {
            throw std::runtime_error("raw socket ended before exact payload");
        }
        offset += static_cast<std::size_t>(count);
    }
    return result;
}

void configure_raw_timeout(const int fd) {
    timeval timeout{.tv_sec = 3, .tv_usec = 0};
    if (::setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout)) != 0 ||
        ::setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout)) != 0) {
        throw std::runtime_error("raw socket timeout configuration failed");
    }
}

struct RawListener final {
    datacube::Fd fd;
    std::uint16_t port{0U};
};

[[nodiscard]] RawListener raw_listener() {
    const int raw = ::socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, IPPROTO_TCP);
    if (raw < 0) {
        throw std::runtime_error("raw listener socket failed");
    }
    datacube::Fd fd(raw);
    const int enabled = 1;
    static_cast<void>(::setsockopt(
        fd.get(), SOL_SOCKET, SO_REUSEADDR, &enabled, sizeof(enabled)));
    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_port = htons(0U);
    if (::inet_pton(AF_INET, "127.0.0.1", &address.sin_addr) != 1) {
        throw std::runtime_error("loopback parse failed");
    }
    if (::bind(
            fd.get(), reinterpret_cast<const sockaddr*>(&address),
            static_cast<socklen_t>(sizeof(address))) != 0 ||
        ::listen(fd.get(), 8) != 0) {
        throw std::runtime_error("raw listener bind/listen failed");
    }
    socklen_t length = static_cast<socklen_t>(sizeof(address));
    if (::getsockname(
            fd.get(), reinterpret_cast<sockaddr*>(&address), &length) != 0) {
        throw std::runtime_error("raw listener getsockname failed");
    }
    configure_raw_timeout(fd.get());
    return RawListener{.fd = std::move(fd), .port = ntohs(address.sin_port)};
}

[[nodiscard]] datacube::Fd raw_connect(const std::uint16_t port) {
    const int raw = ::socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, IPPROTO_TCP);
    if (raw < 0) {
        throw std::runtime_error("raw connector socket failed");
    }
    datacube::Fd fd(raw);
    configure_raw_timeout(fd.get());
    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    if (::inet_pton(AF_INET, "127.0.0.1", &address.sin_addr) != 1 ||
        ::connect(
            fd.get(), reinterpret_cast<const sockaddr*>(&address),
            static_cast<socklen_t>(sizeof(address))) != 0) {
        throw std::runtime_error("raw connector failed");
    }
    return fd;
}

[[nodiscard]] datacube::Fd raw_accept(const int listener) {
    while (true) {
        const int raw = ::accept4(listener, nullptr, nullptr, SOCK_CLOEXEC);
        if (raw >= 0) {
            datacube::Fd fd(raw);
            configure_raw_timeout(fd.get());
            return fd;
        }
        if (errno != EINTR) {
            throw std::runtime_error("raw accept failed");
        }
    }
}

[[nodiscard]] std::unique_ptr<OrderedByteStream> extracted_accept(
    natrav_overlay::TransportListener& listener) {
    for (std::size_t attempt = 0U; attempt < 300U; ++attempt) {
        auto stream = listener.accept_ready();
        if (stream) {
            return stream;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    throw std::runtime_error("extracted listener did not accept connection");
}

[[nodiscard]] TransportLocator loopback_locator(const std::uint16_t port) {
    return natrav_overlay::parse_tcp_transport_locator(
        "127.0.0.1:" + std::to_string(port), true);
}

}  // namespace

int main() {
    try {
        Probe probe;

        probe.run_case("kind registry", [&] {
            probe.check(
                natrav_overlay::parse_transport_kind("tcp") == TransportKind::tcp,
                "canonical TCP kind parses");
            probe.check(
                natrav_overlay::transport_kind_name(TransportKind::tcp) == "tcp",
                "canonical TCP kind renders");
            probe.check(
                natrav_overlay::parse_transport_kind("serial") ==
                    TransportKind::serial,
                "canonical serial kind parses");
            probe.check(
                natrav_overlay::transport_kind_name(TransportKind::serial) ==
                    "serial",
                "canonical serial kind renders");
            const auto capabilities =
                natrav_overlay::transport_capabilities(TransportKind::tcp);
            probe.check(capabilities.reliable_stream, "TCP is reliable stream");
            probe.check(capabilities.ordered, "TCP is ordered");
            probe.check(capabilities.full_duplex, "TCP is full duplex");
            probe.check(capabilities.can_dial, "TCP can dial");
            probe.check(capabilities.can_listen, "TCP can listen");
            probe.check(capabilities.can_shutdown_write,
                "TCP can perform write half-close");
            probe.check(
                natrav_overlay::parse_transport_kind("udp") == TransportKind::udp,
                "canonical UDP kind parses");
            probe.check(
                natrav_overlay::transport_kind_name(TransportKind::udp) == "udp",
                "canonical UDP kind renders");
            const auto udp_capabilities =
                natrav_overlay::transport_capabilities(TransportKind::udp);
            probe.check(udp_capabilities.reliable_stream,
                "finite packet service reconstructs a reliable UDP stream");
            probe.check(udp_capabilities.ordered,
                "finite packet service reconstructs ordered UDP bytes");
            probe.check(udp_capabilities.full_duplex, "UDP adapter is full duplex");
            probe.check(udp_capabilities.can_dial, "UDP adapter can dial");
            probe.check(udp_capabilities.can_listen, "UDP adapter can listen");
            probe.check(udp_capabilities.can_shutdown_write,
                "UDP adapter has semantic write finish");
            probe.check(
                natrav_overlay::parse_transport_kind("unix-dgram") ==
                    TransportKind::unix_datagram,
                "canonical Unix datagram kind parses");
            probe.check(
                natrav_overlay::transport_kind_name(
                    TransportKind::unix_datagram) == "unix-dgram",
                "canonical Unix datagram kind renders");
            const auto unix_datagram_capabilities =
                natrav_overlay::transport_capabilities(
                    TransportKind::unix_datagram);
            probe.check(unix_datagram_capabilities.reliable_stream,
                "finite packet service reconstructs a reliable Unix datagram stream");
            probe.check(unix_datagram_capabilities.ordered,
                "finite packet service reconstructs ordered Unix datagram bytes");
            probe.check(unix_datagram_capabilities.full_duplex,
                "Unix datagram adapter is full duplex");
            probe.check(unix_datagram_capabilities.can_dial,
                "Unix datagram adapter can dial");
            probe.check(unix_datagram_capabilities.can_listen,
                "Unix datagram adapter can listen");
            probe.check(unix_datagram_capabilities.can_shutdown_write,
                "Unix datagram adapter has semantic write finish");
            probe.expect_code(
                [] { static_cast<void>(natrav_overlay::parse_transport_kind("sctp")); },
                "TRANSPORT_KIND_UNSUPPORTED", "unknown text kind fails closed");
            const auto unknown = kUnknownTransportKind;
            probe.expect_code(
                [unknown] { static_cast<void>(natrav_overlay::transport_kind_name(unknown)); },
                "TRANSPORT_KIND_UNSUPPORTED", "unknown enum name fails closed");
            probe.expect_code(
                [unknown] { static_cast<void>(natrav_overlay::transport_capabilities(unknown)); },
                "TRANSPORT_KIND_UNSUPPORTED", "unknown enum capabilities fail closed");
            probe.expect_code(
                [unknown] {
                    static_cast<void>(natrav_overlay::parse_transport_locator(
                        unknown, "127.0.0.1:1", false));
                },
                "TRANSPORT_KIND_UNSUPPORTED", "unknown locator parser fails closed");
            probe.expect_code(
                [unknown] { static_cast<void>(natrav_overlay::transport_connector(unknown)); },
                "TRANSPORT_KIND_UNSUPPORTED", "unknown connector fails closed");
        });

        probe.run_case("canonical locators", [&] {
            const auto ipv4 = natrav_overlay::parse_transport_locator(
                TransportKind::tcp, "127.0.0.1:443", false);
            probe.check(ipv4.kind == TransportKind::tcp, "IPv4 locator kind");
            probe.check(ipv4.tcp.host == "127.0.0.1", "IPv4 locator host");
            probe.check(ipv4.tcp.service == 443U, "IPv4 locator service");
            probe.check(
                natrav_overlay::transport_locator_text(ipv4) == "127.0.0.1:443",
                "IPv4 locator round trip");
            const auto ipv6 = natrav_overlay::parse_tcp_transport_locator(
                "[::1]:65535", false);
            probe.check(ipv6.tcp.host == "::1", "IPv6 locator host");
            probe.check(ipv6.tcp.service == 65'535U, "IPv6 locator service");
            probe.check(
                natrav_overlay::transport_locator_text(ipv6) == "[::1]:65535",
                "IPv6 locator round trip");
            const auto zero = natrav_overlay::parse_tcp_transport_locator(
                "127.0.0.1:0", true);
            probe.check(zero.tcp.service == 0U, "listener permits ephemeral service");
            probe.expect_code(
                [] {
                    static_cast<void>(natrav_overlay::parse_tcp_transport_locator(
                        "127.0.0.1:0", false));
                },
                "INVALID_ARGUMENT", "dial parser rejects zero service");
            probe.expect_code(
                [] {
                    static_cast<void>(natrav_overlay::parse_tcp_transport_locator(
                        "localhost:443", false));
                },
                "ENDPOINT_RESOLUTION_FAILED", "DNS names remain rejected");
            probe.expect_code(
                [] {
                    static_cast<void>(natrav_overlay::parse_tcp_transport_locator(
                        "127.0.0.1", false));
                },
                "INVALID_ENDPOINT", "missing service remains rejected");
            TransportLocator forged{
                .kind = kUnknownTransportKind,
                .tcp = {.host = "127.0.0.1", .service = 1U},
                .serial = {},
                .udp = {},
                .unix_datagram = {},
            };
            probe.expect_code(
                [&forged] {
                    static_cast<void>(natrav_overlay::transport_locator_text(forged));
                },
                "TRANSPORT_KIND_UNSUPPORTED", "forged locator fails closed");
        });

        probe.run_case("extracted listener and connector", [&] {
            auto listener = natrav_overlay::listen_transport(
                loopback_locator(0U), 8);
            probe.check(listener->transport_kind() == TransportKind::tcp,
                "listener exposes TCP kind");
            probe.check(listener->readiness_handle() >= 0,
                "listener exposes readiness handle");
            probe.check(!listener->accept_ready(),
                "drained nonblocking listener returns null");
            const auto bound = listener->bound_locator();
            probe.check(bound.tcp.host == "127.0.0.1",
                "bound locator preserves configured host");
            probe.check(bound.tcp.service != 0U,
                "bound locator reports assigned service");

            IoCounters client_counters;
            auto client = natrav_overlay::connect_transport(
                bound, deadline(), client_counters);
            auto server = extracted_accept(*listener);
            probe.check(client->transport_kind() == TransportKind::tcp,
                "connector returns TCP stream");
            probe.check(server->transport_kind() == TransportKind::tcp,
                "accept returns TCP stream");
            IoCounters server_counters;
            constexpr std::string_view request = "extracted-request";
            constexpr std::string_view response = "extracted-response";
            stream_write_all(*client, request, client_counters);
            probe.check(
                stream_read_exact(*server, request.size(), server_counters) == request,
                "extracted client to server bytes are exact");
            stream_write_all(*server, response, server_counters);
            probe.check(
                stream_read_exact(*client, response.size(), client_counters) == response,
                "extracted server to client bytes are exact");
            probe.check(client_counters.write_calls > 0U,
                "outbound stream counts writes");
            probe.check(client_counters.read_calls > 0U,
                "outbound stream counts reads");
            client->shutdown_write();
            std::array<std::uint8_t, 1U> byte{};
            const auto eof = server->read_some(
                byte, deadline(), server_counters, "probe eof");
            probe.check(eof == 0U, "ordered stream preserves write-half shutdown");
        });

        probe.run_case("raw client compatibility", [&] {
            auto listener = natrav_overlay::listen_transport(
                loopback_locator(0U), 8);
            const auto bound = listener->bound_locator();
            auto raw = raw_connect(bound.tcp.service);
            auto extracted = extracted_accept(*listener);
            constexpr std::string_view request = "raw-client-request";
            constexpr std::string_view response = "extracted-listener-response";
            raw_write_all(raw.get(), request);
            IoCounters counters;
            probe.check(
                stream_read_exact(*extracted, request.size(), counters) == request,
                "raw client bytes reach extracted listener unchanged");
            stream_write_all(*extracted, response, counters);
            probe.check(
                raw_read_exact(raw.get(), response.size()) == response,
                "extracted listener bytes reach raw client unchanged");
        });

        probe.run_case("raw listener compatibility", [&] {
            auto listener = raw_listener();
            IoCounters counters;
            auto extracted = natrav_overlay::connect_transport(
                loopback_locator(listener.port), deadline(), counters);
            auto raw = raw_accept(listener.fd.get());
            constexpr std::string_view request = "extracted-client-request";
            constexpr std::string_view response = "raw-listener-response";
            stream_write_all(*extracted, request, counters);
            probe.check(
                raw_read_exact(raw.get(), request.size()) == request,
                "extracted client bytes reach raw listener unchanged");
            raw_write_all(raw.get(), response);
            probe.check(
                stream_read_exact(*extracted, response.size(), counters) == response,
                "raw listener bytes reach extracted client unchanged");
        });

        probe.run_case("error mapping", [&] {
            probe.expect_code(
                [] {
                    static_cast<void>(natrav_overlay::listen_transport(
                        loopback_locator(0U), 0));
                },
                "INVALID_LISTEN_BACKLOG", "invalid backlog classification");

            auto occupied = raw_listener();
            probe.expect_code(
                [&occupied] {
                    static_cast<void>(natrav_overlay::listen_transport(
                        loopback_locator(occupied.port), 8));
                },
                "LISTEN_FAILED", "occupied service classification");

            std::uint16_t closed_port = 0U;
            {
                auto temporary = raw_listener();
                closed_port = temporary.port;
            }
            IoCounters counters;
            probe.expect_code(
                [closed_port, &counters] {
                    static_cast<void>(natrav_overlay::connect_transport(
                        loopback_locator(closed_port), deadline(), counters));
                },
                "CONNECT_FAILED", "refused dial classification");

            const TransportLocator zero = loopback_locator(0U);
            probe.expect_code(
                [&zero, &counters] {
                    static_cast<void>(natrav_overlay::connect_transport(
                        zero, deadline(), counters));
                },
                "INVALID_ENDPOINT", "zero-service dial classification");

            const TransportLocator unknown{
                .kind = kUnknownTransportKind,
                .tcp = {.host = "127.0.0.1", .service = 1U},
                .serial = {},
                .udp = {},
                .unix_datagram = {},
            };
            probe.expect_code(
                [&unknown, &counters] {
                    static_cast<void>(natrav_overlay::connect_transport(
                        unknown, deadline(), counters));
                },
                "TRANSPORT_KIND_UNSUPPORTED", "unknown dial kind fails closed");
            probe.expect_code(
                [&unknown] {
                    static_cast<void>(natrav_overlay::listen_transport(
                        unknown, 8));
                },
                "TRANSPORT_KIND_UNSUPPORTED", "unknown listen kind fails closed");
        });

        std::cout << "{\"format\":\"NATRAV_TRANSPORT_EXTRACTION_PROBE_V1\","
                  << "\"status\":\"PASS\",\"cases\":[";
        for (std::size_t index = 0U; index < probe.cases().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            const auto& record = probe.cases()[index];
            std::cout << "{\"name\":\"" << record.name
                      << "\",\"assertions\":" << record.assertions << '}';
        }
        std::cout << "],\"assertions\":" << probe.assertions() << "}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
