#!/usr/bin/env python3
"""Canonical bounded process-fault schedules for configured-adapter tests.

Test infrastructure only.  The product never parses these files and the
fixture has no identity, authorization, receipt, custody, or routing authority.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os
import re


FEATURE = "DETERMINISTIC_CONFIGURED_ADAPTER_PROCESS_ADVERSARY_V1"
SCHEDULE_FORMAT = "NATRAV_CONFIGURED_ADAPTER_PROCESS_SCHEDULE_V1"
TRACE_FORMAT = "NATRAV_CONFIGURED_ADAPTER_PROCESS_TRACE_V1"
_SLUG = re.compile(r"[a-z][a-z0-9-]{0,31}\Z")
_ACTIONS = {"PASS", "FAIL", "SILENT"}


@dataclass(frozen=True)
class ProcessSchedule:
    name: str
    maximum_trace_records: int = 256
    startup_action: str = "PASS"
    startup_count: int = 0
    startup_silence_ms: int = 0
    silent_transmit_ordinal: int = 0
    silent_receive_ordinal: int = 0
    silent_response_ms: int = 0
    crash_transmit_ordinal: int = 0

    def validate(self) -> None:
        if _SLUG.fullmatch(self.name) is None:
            raise ValueError("process schedule name is not canonical")
        if not 16 <= self.maximum_trace_records <= 4096:
            raise ValueError("process trace bound must be 16..4096")
        if self.startup_action not in _ACTIONS:
            raise ValueError("process startup action is invalid")
        if not 0 <= self.startup_count <= 64:
            raise ValueError("process startup count must be 0..64")
        if not 0 <= self.startup_silence_ms <= 60_000:
            raise ValueError("process startup silence must be 0..60000 ms")
        for value, label in (
            (self.silent_transmit_ordinal, "silent transmit ordinal"),
            (self.silent_receive_ordinal, "silent receive ordinal"),
            (self.crash_transmit_ordinal, "crash transmit ordinal"),
        ):
            if not 0 <= value <= 1_000_000:
                raise ValueError(f"{label} must be 0..1000000")
        if not 0 <= self.silent_response_ms <= 60_000:
            raise ValueError("silent response must be 0..60000 ms")
        if self.startup_action == "PASS":
            if self.startup_count != 0 or self.startup_silence_ms != 0:
                raise ValueError("PASS startup requires zero count and silence")
        elif self.startup_action == "FAIL":
            if self.startup_count == 0 or self.startup_silence_ms != 0:
                raise ValueError("FAIL startup requires count and zero silence")
        else:
            if self.startup_count == 0 or self.startup_silence_ms == 0:
                raise ValueError("SILENT startup requires count and silence")
        has_runtime_silence = (
            self.silent_transmit_ordinal != 0 or self.silent_receive_ordinal != 0
        )
        if has_runtime_silence != (self.silent_response_ms != 0):
            raise ValueError("runtime silence ordinals and duration must agree")
        if (
            self.crash_transmit_ordinal != 0
            and self.crash_transmit_ordinal == self.silent_transmit_ordinal
        ):
            raise ValueError("one transmit ordinal cannot be both silent and crash")

    def encode(self) -> bytes:
        self.validate()
        lines = [
            SCHEDULE_FORMAT,
            f"feature={FEATURE}",
            f"name={self.name}",
            f"maximum-trace-records={self.maximum_trace_records}",
            f"startup-action={self.startup_action}",
            f"startup-count={self.startup_count}",
            f"startup-silence-ms={self.startup_silence_ms}",
            f"silent-transmit-ordinal={self.silent_transmit_ordinal}",
            f"silent-receive-ordinal={self.silent_receive_ordinal}",
            f"silent-response-ms={self.silent_response_ms}",
            f"crash-transmit-ordinal={self.crash_transmit_ordinal}",
        ]
        return ("\n".join(lines) + "\n").encode("ascii")

    @classmethod
    def decode(cls, encoded: bytes) -> "ProcessSchedule":
        if len(encoded) > 4096 or not encoded.endswith(b"\n"):
            raise ValueError("process schedule size or trailing newline is invalid")
        try:
            text = encoded.decode("ascii")
        except UnicodeDecodeError as exc:
            raise ValueError("process schedule must be ASCII") from exc
        lines = text.splitlines()
        if len(lines) != 11 or lines[0] != SCHEDULE_FORMAT:
            raise ValueError("process schedule header or field count is invalid")
        expected = [
            "feature",
            "name",
            "maximum-trace-records",
            "startup-action",
            "startup-count",
            "startup-silence-ms",
            "silent-transmit-ordinal",
            "silent-receive-ordinal",
            "silent-response-ms",
            "crash-transmit-ordinal",
        ]
        values: dict[str, str] = {}
        for line, key in zip(lines[1:], expected, strict=True):
            if not line.startswith(key + "="):
                raise ValueError("process schedule fields are not canonical ordered")
            values[key] = line[len(key) + 1 :]
        if values["feature"] != FEATURE:
            raise ValueError("process schedule feature is unsupported")

        def number(key: str) -> int:
            value = values[key]
            if not value or (len(value) > 1 and value.startswith("0")) or not value.isdigit():
                raise ValueError(f"{key} is not a canonical unsigned integer")
            return int(value)

        schedule = cls(
            name=values["name"],
            maximum_trace_records=number("maximum-trace-records"),
            startup_action=values["startup-action"],
            startup_count=number("startup-count"),
            startup_silence_ms=number("startup-silence-ms"),
            silent_transmit_ordinal=number("silent-transmit-ordinal"),
            silent_receive_ordinal=number("silent-receive-ordinal"),
            silent_response_ms=number("silent-response-ms"),
            crash_transmit_ordinal=number("crash-transmit-ordinal"),
        )
        schedule.validate()
        if schedule.encode() != encoded:
            raise ValueError("process schedule is valid but noncanonical")
        return schedule

    def write(self, path: Path) -> Path:
        encoded = self.encode()
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".tmp")
        temporary.write_bytes(encoded)
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
        return path


def parse_trace(path: Path) -> dict[str, object]:
    raw = path.read_bytes()
    if len(raw) > 1_048_576 or not raw.endswith(b"\n"):
        raise ValueError("process trace size or newline is invalid")
    text = raw.decode("ascii")
    lines = text.splitlines()
    if len(lines) < 6 or lines[0] != TRACE_FORMAT:
        raise ValueError("process trace header is invalid")
    fixed = {}
    for line, key in zip(lines[1:5], ("launch-ordinal", "maximum-records", "record-count", "terminal"), strict=True):
        if not line.startswith(key + "="):
            raise ValueError("process trace fixed fields are not canonical")
        fixed[key] = line[len(key) + 1 :]
    if not fixed["launch-ordinal"].isdigit() or not fixed["maximum-records"].isdigit() or not fixed["record-count"].isdigit():
        raise ValueError("process trace numeric fields are invalid")
    count = int(fixed["record-count"])
    records = []
    for line in lines[5:]:
        if not line.startswith("record="):
            raise ValueError("process trace record prefix is invalid")
        parts = line[7:].split("|")
        if len(parts) != 6:
            raise ValueError("process trace record field count is invalid")
        sequence, kind, ordinal, action, byte_count, schedule = parts
        if not all(value.isdigit() for value in (sequence, ordinal, byte_count)):
            raise ValueError("process trace record numeric field is invalid")
        records.append({
            "sequence": int(sequence),
            "kind": kind,
            "ordinal": int(ordinal),
            "action": action,
            "bytes": int(byte_count),
            "schedule": schedule,
        })
    if len(records) != count:
        raise ValueError("process trace count does not match records")
    maximum = int(fixed["maximum-records"])
    if not 16 <= maximum <= 4096 or count > maximum:
        raise ValueError("process trace bound is invalid")
    if [item["sequence"] for item in records] != list(range(1, count + 1)):
        raise ValueError("process trace sequence is noncanonical")
    return {
        "format": TRACE_FORMAT,
        "launch_ordinal": int(fixed["launch-ordinal"]),
        "maximum_records": maximum,
        "terminal": fixed["terminal"],
        "records": records,
    }


def nonresponse_signature(traces: list[dict[str, object]]) -> list[tuple[object, ...]]:
    result: list[tuple[object, ...]] = []
    for trace in traces:
        launch = trace["launch_ordinal"]
        for record in trace["records"]:  # type: ignore[index]
            if record["action"] != "RESPOND":  # type: ignore[index]
                result.append((
                    launch,
                    record["kind"],  # type: ignore[index]
                    record["ordinal"],  # type: ignore[index]
                    record["action"],  # type: ignore[index]
                    record["bytes"],  # type: ignore[index]
                    record["schedule"],  # type: ignore[index]
                ))
    return result
