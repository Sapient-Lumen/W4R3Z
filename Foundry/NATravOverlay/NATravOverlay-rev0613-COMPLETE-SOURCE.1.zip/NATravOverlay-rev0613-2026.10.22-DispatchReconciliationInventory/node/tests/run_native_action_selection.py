#!/usr/bin/env python3
"""Build and run the production action-selection index outside the source tree."""
from __future__ import annotations
import argparse, hashlib, json, os, subprocess, time
from pathlib import Path

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--mode',choices=('static','sanitize'),default='static')
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[2]
    output=args.output.resolve()
    if output.exists() or output==root or root in output.parents:
        parser.error('output must be new and outside source')
    output.mkdir(parents=True)
    binary=output/'action-selection-test'
    command=['/usr/bin/g++','-std=c++20','-O1','-g0','-Wall','-Wextra','-Wpedantic',
             '-Wconversion','-Wsign-conversion','-Wshadow','-Werror',
             '-I'+str(root/'foundation/include'),'-I'+str(root/'node/src')]
    if args.mode=='sanitize':
        command += ['-O0','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie']
    else:
        command += ['-static']
    command += [str(root/'node/tests/test_action_selection.cpp'),
                str(root/'node/src/action_selection.cpp'),
                str(root/'node/src/delivery_index.cpp'),'-o',str(binary)]
    env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',
             UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    result={'format':'NATRAV_NATIVE_ACTION_SELECTION_V1','status':'FAIL','mode':args.mode,'command':command}
    started=time.monotonic()
    with (output/'BUILD.log').open('w') as log:
        build=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    result['build_returncode']=build.returncode
    if build.returncode==0:
        run=subprocess.run([str(binary)],env=env,capture_output=True,text=True,timeout=240)
        (output/'stdout.txt').write_text(run.stdout)
        (output/'stderr.txt').write_text(run.stderr)
        result.update(returncode=run.returncode,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
        if run.returncode==0:
            result.update(status='PASS',result=json.loads(run.stdout))
    result['elapsed_seconds']=time.monotonic()-started
    (output/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result),flush=True)
    return 0 if result['status']=='PASS' else 1

if __name__=='__main__':
    raise SystemExit(main())
