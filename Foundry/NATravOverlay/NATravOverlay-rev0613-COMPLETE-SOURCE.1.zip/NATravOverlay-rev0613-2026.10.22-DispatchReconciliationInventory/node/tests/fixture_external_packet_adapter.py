#!/usr/bin/python3
"""Deterministic untrusted complete-datagram adapter fixture for revision 0589."""
from __future__ import annotations

import argparse
import errno
import fcntl
import json
import os
from pathlib import Path
import socket
import struct
import sys
import time
import zlib

MAGIC = b"NAPA0001"
HEADER = 36
HELLO_REQUEST = 1
HELLO_RESPONSE = 2
TRANSMIT_REQUEST = 3
TRANSMIT_RESPONSE = 4
RECEIVE_REQUEST = 5
RECEIVE_RESPONSE = 6
PING_REQUEST = 7
PING_RESPONSE = 8
SHUTDOWN_REQUEST = 9
SHUTDOWN_RESPONSE = 10
FAULT = 11

OK = 0
NO_DATA = 1
BUSY = 2
MALFORMED = 3
RESOURCE_EXHAUSTED = 4
RESET = 5
DEADLINE_EXCEEDED = 6
UNSUPPORTED = 7


def open_fds() -> list[int]:
    result: list[int] = []
    for descriptor in range(64):
        try:
            fcntl.fcntl(descriptor, fcntl.F_GETFD)
        except OSError as exc:
            if exc.errno != errno.EBADF:
                raise
        else:
            result.append(descriptor)
    return result


def encode_frame(
    frame_type: int,
    sequence: int,
    status: int = OK,
    payload: bytes = b"",
    deadline_ms: int = 0,
) -> bytes:
    prefix = (
        MAGIC
        + struct.pack(">BBHQIII", frame_type, 0, 0, sequence, deadline_ms, status, len(payload))
    )
    checksum = zlib.crc32(prefix + payload) & 0xFFFFFFFF
    return prefix + struct.pack(">I", checksum) + payload


def decode_frame(raw: bytes, maximum: int) -> tuple[int, int, int, int, bytes]:
    if len(raw) < HEADER or len(raw) > maximum:
        raise ValueError("frame size")
    if raw[:8] != MAGIC:
        raise ValueError("magic")
    frame_type, flags, reserved, sequence, deadline_ms, status, payload_size = struct.unpack(
        ">BBHQIII", raw[8:32]
    )
    expected_crc = struct.unpack(">I", raw[32:36])[0]
    payload = raw[36:]
    if not 1 <= frame_type <= 11:
        raise ValueError("type")
    if flags != 0 or reserved != 0 or sequence == 0 or not 0 <= status <= 7:
        raise ValueError("canonical fields")
    if payload_size != len(payload):
        raise ValueError("payload length")
    if (zlib.crc32(raw[:32] + payload) & 0xFFFFFFFF) != expected_crc:
        raise ValueError("crc")
    return frame_type, sequence, deadline_ms, status, payload


def parse_schedule(text: str) -> dict[int, tuple[str, int]]:
    result: dict[int, tuple[str, int]] = {}
    if not text:
        return result
    for item in text.split(","):
        ordinal_text, action_text = item.split("=", 1)
        ordinal = int(ordinal_text)
        if ordinal <= 0 or ordinal in result:
            raise ValueError("noncanonical schedule ordinal")
        if ":" in action_text:
            action, argument_text = action_text.split(":", 1)
            argument = int(argument_text)
        else:
            action = action_text
            argument = 0
        if action not in {
            "drop", "duplicate", "corrupt", "delay", "reorder",
            "busy", "crash", "exhaust", "malformed",
        }:
            raise ValueError("unknown schedule action")
        if action == "delay" and not 1 <= argument <= 1024:
            raise ValueError("delay bound")
        if action != "delay" and argument != 0:
            raise ValueError("unexpected schedule argument")
        result[ordinal] = (action, argument)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--local", required=True)
    parser.add_argument("--remote", required=True)
    parser.add_argument("--mtu", type=int, default=512)
    parser.add_argument("--schedule", default="")
    parser.add_argument("--evidence", required=True)
    parser.add_argument("--startup-crash-state")
    parser.add_argument("--malformed-hello", action="store_true")
    args = parser.parse_args()

    inherited = open_fds()
    initial_environment = dict(os.environ)
    evidence_path = Path(args.evidence)
    evidence: dict[str, object] = {
        "format": "NATRAV_EXTERNAL_PACKET_ADAPTER_FIXTURE_V1",
        "argv": sys.argv,
        "environment": initial_environment,
        "inherited_fds": inherited,
        "requests": 0,
        "transmit_requests": 0,
        "receive_requests": 0,
        "physical_send_accepted": 0,
        "physical_send_busy": 0,
        "physical_receive_deliveries": 0,
        "unauthorized_sources": 0,
        "actions": [],
        "shutdown": False,
    }

    def write_evidence() -> None:
        temporary = evidence_path.with_suffix(evidence_path.suffix + ".tmp")
        temporary.write_text(json.dumps(evidence, sort_keys=True) + "\n")
        os.replace(temporary, evidence_path)

    if args.startup_crash_state:
        marker = Path(args.startup_crash_state)
        if not marker.exists():
            marker.write_text("crashed-once\n")
            evidence["startup_crash"] = True
            write_evidence()
            return 71

    descriptor_text = os.environ.get("NATRAV_ADAPTER_FD")
    protocol = os.environ.get("NATRAV_ADAPTER_PROTOCOL")
    if descriptor_text != "3" or protocol != "NAPA0001":
        evidence["startup_error"] = "descriptor or protocol environment"
        write_evidence()
        return 70
    control = socket.socket(fileno=3)
    if (control.type & socket.SOCK_SEQPACKET) != socket.SOCK_SEQPACKET:
        evidence["startup_error"] = "not seqpacket"
        write_evidence()
        return 70

    local = Path(args.local)
    remote = Path(args.remote)
    if not local.is_absolute() or not remote.is_absolute() or local == remote:
        evidence["startup_error"] = "invalid physical paths"
        write_evidence()
        return 70
    if local.exists():
        evidence["startup_error"] = "local path already exists"
        write_evidence()
        return 70

    medium = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM | socket.SOCK_NONBLOCK)
    medium.bind(str(local))
    os.chmod(local, 0o600)
    schedule = parse_schedule(args.schedule)
    delayed: list[tuple[int, bytes]] = []
    held: bytes | None = None
    step = 0
    tx_ordinal = 0
    negotiated_frame = 65536
    negotiated_mtu = args.mtu

    def physical_send(payload: bytes) -> bool:
        try:
            medium.sendto(payload, str(remote))
            evidence["physical_send_accepted"] = (
                int(evidence["physical_send_accepted"]) + 1
            )
            return True
        except (FileNotFoundError, ConnectionRefusedError, BlockingIOError):
            # Backpressure and a not-yet-present peer are retryable carrier states.
            evidence["physical_send_busy"] = int(evidence["physical_send_busy"]) + 1
            return False

    def flush_due() -> None:
        nonlocal delayed
        retained: list[tuple[int, bytes]] = []
        for due, payload in delayed:
            if due > step or not physical_send(payload):
                retained.append((due, payload))
        delayed = retained

    try:
        raw = control.recv(1_048_576)
        if args.malformed_hello:
            evidence["malformed_hello"] = True
            write_evidence()
            control.send(b"not-a-canonical-adapter-frame")
            time.sleep(0.05)
            return 73
        frame_type, sequence, _deadline, status, payload = decode_frame(raw, 1_048_576)
        if frame_type != HELLO_REQUEST or status != OK or len(payload) != 20:
            raise ValueError("hello request")
        profile, requested_mtu, requested_frame, requested_queue, outstanding = struct.unpack(
            ">IIIII", payload
        )
        if profile != 1 or not 256 <= requested_mtu <= 65507 or outstanding != 1:
            raise ValueError("hello capabilities")
        negotiated_mtu = min(requested_mtu, args.mtu)
        negotiated_frame = min(requested_frame, max(HEADER + negotiated_mtu, 4096))
        accepted_queue = min(requested_queue, max(negotiated_mtu * 64, negotiated_mtu))
        response_payload = struct.pack(
            ">IIIII", 1, negotiated_mtu, negotiated_frame, accepted_queue, 1
        )
        control.send(encode_frame(HELLO_RESPONSE, sequence, OK, response_payload))
        evidence["hello"] = {
            "profile": 1,
            "mtu": negotiated_mtu,
            "max_frame_bytes": negotiated_frame,
            "max_queued_bytes": accepted_queue,
            "max_outstanding_requests": 1,
        }
        write_evidence()

        while True:
            raw = control.recv(negotiated_frame)
            frame_type, sequence, _deadline, status, payload = decode_frame(
                raw, negotiated_frame
            )
            if status != OK:
                control.send(
                    encode_frame(FAULT, sequence, MALFORMED, b"request status must be zero")
                )
                continue
            step += 1
            flush_due()
            evidence["requests"] = int(evidence["requests"]) + 1

            if frame_type == TRANSMIT_REQUEST:
                tx_ordinal += 1
                evidence["transmit_requests"] = int(evidence["transmit_requests"]) + 1
                if not payload or len(payload) > negotiated_mtu:
                    control.send(
                        encode_frame(FAULT, sequence, MALFORMED, b"transmit payload bound")
                    )
                    continue
                action, argument = schedule.get(tx_ordinal, ("send", 0))
                cast_actions = evidence["actions"]
                assert isinstance(cast_actions, list)
                cast_actions.append({"ordinal": tx_ordinal, "action": action, "bytes": len(payload)})
                if len(cast_actions) > 256:
                    del cast_actions[:-256]
                if action == "busy":
                    control.send(encode_frame(TRANSMIT_RESPONSE, sequence, BUSY))
                elif action == "crash":
                    evidence["runtime_crash"] = tx_ordinal
                    write_evidence()
                    os._exit(72)
                elif action == "exhaust":
                    control.send(
                        encode_frame(
                            TRANSMIT_RESPONSE,
                            sequence,
                            RESOURCE_EXHAUSTED,
                            b"fixture queue exhausted",
                        )
                    )
                elif action == "malformed":
                    evidence["malformed_runtime"] = tx_ordinal
                    write_evidence()
                    control.send(b"malformed-runtime-response")
                else:
                    accepted = True
                    if action == "drop":
                        pass
                    elif action == "duplicate":
                        accepted = physical_send(payload)
                        if accepted:
                            physical_send(payload)
                    elif action == "corrupt":
                        corrupted = bytearray(payload)
                        corrupted[-1] ^= 0x01
                        accepted = physical_send(bytes(corrupted))
                    elif action == "delay":
                        if len(delayed) >= 256:
                            control.send(
                                encode_frame(
                                    TRANSMIT_RESPONSE,
                                    sequence,
                                    RESOURCE_EXHAUSTED,
                                    b"fixture delayed queue exhausted",
                                )
                            )
                            write_evidence()
                            continue
                        delayed.append((step + argument, payload))
                    elif action == "reorder":
                        if held is None:
                            held = payload
                        else:
                            accepted = physical_send(payload)
                            if accepted and physical_send(held):
                                held = None
                    else:
                        accepted = physical_send(payload)
                        if accepted and held is not None and physical_send(held):
                            held = None
                    control.send(
                        encode_frame(
                            TRANSMIT_RESPONSE,
                            sequence,
                            OK if accepted else BUSY,
                        )
                    )
                write_evidence()
                continue

            if frame_type == RECEIVE_REQUEST:
                evidence["receive_requests"] = int(evidence["receive_requests"]) + 1
                if payload:
                    control.send(
                        encode_frame(FAULT, sequence, MALFORMED, b"receive payload must be empty")
                    )
                    continue
                flush_due()
                delivered: bytes | None = None
                for _ in range(16):
                    try:
                        data, _ancillary, flags, source = medium.recvmsg(
                            negotiated_mtu,
                            0,
                            socket.MSG_DONTWAIT | socket.MSG_TRUNC,
                        )
                    except BlockingIOError:
                        break
                    if flags & socket.MSG_TRUNC or len(data) > negotiated_mtu:
                        control.send(
                            encode_frame(FAULT, sequence, MALFORMED, b"physical datagram truncated")
                        )
                        delivered = b""
                        break
                    if source != str(remote):
                        evidence["unauthorized_sources"] = int(
                            evidence["unauthorized_sources"]
                        ) + 1
                        continue
                    delivered = data
                    evidence["physical_receive_deliveries"] = (
                        int(evidence["physical_receive_deliveries"]) + 1
                    )
                    break
                if delivered == b"":
                    write_evidence()
                    continue
                if delivered is None:
                    control.send(encode_frame(RECEIVE_RESPONSE, sequence, NO_DATA))
                else:
                    control.send(encode_frame(RECEIVE_RESPONSE, sequence, OK, delivered))
                write_evidence()
                continue

            if frame_type == PING_REQUEST:
                if payload:
                    control.send(
                        encode_frame(FAULT, sequence, MALFORMED, b"ping payload must be empty")
                    )
                else:
                    control.send(encode_frame(PING_RESPONSE, sequence, OK))
                write_evidence()
                continue

            if frame_type == SHUTDOWN_REQUEST:
                if payload:
                    control.send(
                        encode_frame(FAULT, sequence, MALFORMED, b"shutdown payload must be empty")
                    )
                    continue
                if held is not None and physical_send(held):
                    held = None
                flush_due()
                control.send(encode_frame(SHUTDOWN_RESPONSE, sequence, OK))
                evidence["shutdown"] = True
                write_evidence()
                return 0

            control.send(
                encode_frame(FAULT, sequence, UNSUPPORTED, b"unsupported request frame")
            )
            write_evidence()
    except (BrokenPipeError, ConnectionResetError):
        evidence["control_reset"] = True
        write_evidence()
        return 0
    except Exception as exc:  # fixture evidence must preserve failures
        evidence["exception"] = f"{type(exc).__name__}: {exc}"
        write_evidence()
        return 74
    finally:
        medium.close()
        try:
            local.unlink()
        except FileNotFoundError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
