#!/usr/bin/env python3
"""Explicit local source admissions: real credentials, replay, projections and maintenance."""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import struct
import subprocess
import time
from typing import Any
from run_persistent import Harness, free_port, operation, raw_control, receive_exact
from run_local_administration import v8_config, run_as_uid, expose_control_for_uid
from run_evidence_queries import OWNER_CLASSES, READ_CLASSES
from run_scoped_reads import query
from run_live_configuration import candidate, activate, wait_state
from run_integration import encode_record, record_digest
from run_numeric_projection import create as numeric_create, consume, payload as numeric_payload
from run_projections import read as projection_read
from run_state_authentication import new_key, migrate, start as start_keyed, inspect as inspect_state, checksum_frame
from run_projection_publication import publish, decode_npp1
from run_evidence_queries import config as peer_config, query as legacy_query
from run_peer_sessions import submit

UID, OTHER = 65534, 65533
SCOPES = ('query/series', 'query/binary', 'query/other')
AUTHOR_CLASSES = OWNER_CLASSES + READ_CLASSES + ['CONSUMER', 'CONSUMER_ADMIN', 'PROJECTION', 'EVIDENCE_AUTHOR']

def config(h: Harness, name: str, state: Path, *, node: str='A', port: int|None=None,
           peers: list[tuple[str,int]]|None=None, inbound: list[str]|None=None,
           delegates: bool=False) -> Path:
    grants=[(os.geteuid(), AUTHOR_CLASSES)]
    if delegates: grants += [(UID,['EVIDENCE_AUTHOR']), (OTHER,['EVIDENCE_AUTHOR','EVIDENCE_READ'])]
    p=v8_config(h,name,node,state,port or free_port(),name+'-g1',grants,peers,inbound,deadline_ms=3000)
    lines=p.read_text().replace('CONFIG_V8','CONFIG_V14').splitlines()
    out=[]
    for line in lines:
        if line.startswith('peer='):
            fields=line[5:].split(',');out.append('peer='+','.join([fields[0]]+fields[2:]))
            out.append('peer_route='+fields[0]+',primary,0,ENABLED,'+fields[1])
        else: out.append(line)
    for scope in SCOPES:
        out += [f'evidence_author={os.geteuid()},{scope}',f'evidence_read={os.geteuid()},{node},{scope},PAYLOAD']
    if delegates:
        out += [f'evidence_author={UID},query/series',f'evidence_author={OTHER},query/series',
                f'evidence_read={OTHER},{node},query/series,METADATA']
    p.write_text('\n'.join(out)+'\n');p.chmod(0o600)
    return p

def args(state: Path, label: str, *, node: str='A', scope: str='query/series',
         parent: str|None=None, value: str='local evidence', ticks: int|None=None,
         op: str|None=None) -> list[str]:
    a=['evidence-amend' if parent else 'evidence-author','--control',str(state/'control.sock'),
       '--node',node,'--scope',scope,'--operation',op or operation(label),'--deadline-ms','5000']
    if parent: a += ['--corrects',parent]
    if ticks is None: a += ['--payload-text',value]
    else: a += ['--numeric-ticks',str(ticks),'--numeric-unit','degC','--numeric-scale','2']
    return a

def author(h:Harness,label:str,state:Path,expected:int=0,uid:int|None=None,**kw:Any)->dict:
    a=args(state,label,**kw)
    r=h.run(label,a,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,a,expected)
    assert r is not None
    if expected==0:
        h.check(r['format']=='NATRAV_OVERLAY_LOCAL_AUTHOR_RESULT_V1','explicit local result')
        h.check(r['network_used'] is False,'no route or simulated remote receipt')
        h.check(r['local_authorship']['uid']==(os.geteuid() if uid is None else uid),'actual author UID')
        h.check(r['local_authorship']['origin']=='LOCAL_AUTHORED','explicit provenance discriminator')
    return r

def inspect(h:Harness,label:str,state:Path,expected:int=0,key:Path|None=None)->dict:
    return inspect_state(h,label,state,key,expected,node='A')

def cases(h:Harness,selected:set[str]|None=None)->None:
    def case(name,fn):
        if selected is None or name in selected:h.case(name,fn)

    def policy():
        s=h.runtime/'policy';c=config(h,'policy',s)
        a=h.run('valid-policy',['config-check','--config',str(c)])
        lines=c.read_text().splitlines();ordered=h.work/'ordered.conf';ordered.write_text(lines[0]+'\n'+'\n'.join(reversed(lines[1:]))+'\n');ordered.chmod(0o600)
        b=h.run('ordered-policy',['config-check','--config',str(ordered)])
        h.check(a['runtime_digest']==b['runtime_digest'],'canonical author policy independent of order')
        rules=a['evidence_author_policy']['grants']
        for rule in rules:
            scope=rule['scope'].encode();expected=hashlib.sha256(b'NATRAV_OVERLAY_LOCAL_AUTHOR_RULE_V1\0'+struct.pack('!I',rule['uid'])+struct.pack('!H',len(scope))+scope).hexdigest()
            h.check(rule['digest']==expected,'independent exact-scope rule encoding')
        for name,change,code in [
            ('old-version',lambda x:x.replace('CONFIG_V14','CONFIG_V13'),'CONFIG_VERSION_REJECTED'),
            ('duplicate',lambda x:x+f'evidence_author={os.geteuid()},query/series\n','CONFIG_AUTHOR_DUPLICATE'),
            ('wildcard',lambda x:x.replace('evidence_author=0,query/series','evidence_author=0,query/*'),'CONFIG_AUTHOR_INVALID'),
            ('action',lambda x:x.replace('evidence_author=0,query/series','evidence_author=0,actions/counter.add/v1'),'CONFIG_AUTHOR_INVALID'),
            ('absent-class',lambda x:x.replace(',EVIDENCE_AUTHOR',''),'CONFIG_AUTHOR_CLASS_REQUIRED'),
            ('absent-domain',lambda x:'\n'.join(y for y in x.splitlines() if not y.startswith('evidence_author='))+'\n','CONFIG_AUTHOR_DOMAIN_REQUIRED'),
            ('unknown-author',lambda x:x+f'evidence_author={UID},query/series\n','CONFIG_AUTHOR_CLASS_REQUIRED')]:
            p=candidate(h,c,name,name+'-g1',change)
            h.check(h.run('policy-'+name,['config-check','--config',str(p)],expected=3)['code']==code,'strict '+name)
        d=h.start('policy',c,s)
        wrong=author(h,'not-local',s,3,node='X');h.check(wrong['code']=='LOCAL_AUTHOR_IDENTITY_REJECTED','cannot spoof node')
        denied=author(h,'not-scope',s,3,scope='other/scope');h.check(denied['code']=='LOCAL_AUTHOR_SCOPE_DENIED','scope exact')
        op=operation('independent-author');wire=b'NOC1\x13'+encode_record(op,'A','A','query/series',b'raw')
        ok,result=raw_control(d.control,wire)
        h.check(ok and result['local_authorship']['pid']==os.getpid(),'independent control encoding captures actual socket PID')
        h.check(result['local_authorship']['request_digest']==hashlib.sha256(b'NATRAV_OVERLAY_LOCAL_AUTHOR_REQUEST_V1\0'+wire[5:]).hexdigest(),'independent source request digest')
        for label,raw in [('trailing',wire+b'x'),('short',wire[:-1]),('recipient',b'NOC1\x13'+encode_record(operation('wrong-recipient'),'A','B','query/series',b'x'))]:
            ok,r=raw_control(d.control,raw);h.check(not ok,label+' rejected')
        d.shutdown()
        snap=inspect(h,'policy-state',s);h.check(snap['inbound']['count']==1 and snap['outbox']['count']==0,'no failed source admissions or outbox creations')
        plain=h.runtime/'all-only';plainconf=v8_config(h,'all-only','A',plain,free_port(),'all-only-g1',[(os.geteuid(),['ALL'])],deadline_ms=3000)
        plainconf.write_text(plainconf.read_text().replace('CONFIG_V8','CONFIG_V14'))
        pd=h.start('all-only',plainconf,plain)
        h.check(author(h,'all-does-not-author',plain,3)['code']=='LOCAL_CONTROL_CLASS_DENIED','ALL does not imply local authorship')
        pd.shutdown()
    case('strict_policy_and_independent_wire',policy)

    def semantics():
        s=h.runtime/'semantics';c=config(h,'semantics',s);d=h.start('semantics',c,s)
        one=author(h,'original-one',s,ticks=125);two=author(h,'original-two',s,ticks=-25)
        changed=author(h,'correct-one',s,parent=one['operation_id'],ticks=150)
        before=(s/'state.journal').read_bytes()
        again=author(h,'retry-original',s,op=one['operation_id'],ticks=125)
        h.check(again['disposition']=='ALREADY_AUTHORED' and again['local_authorship']==one['local_authorship'],'idempotency retains original author event')
        h.check((s/'state.journal').read_bytes()==before,'exact successful retry appends nothing')
        q=query(h,'source-history',s,issuer='A',scope='query/series',view='history',payload='yes',payload_length=46)
        h.check(len(q['records'])==3 and all(r.get('local_authorship') for r in q['records']),'authored provenance in normal read API')
        h.check(all(r['authorization'] is None for r in q['records']),'no invented peer authorization')
        for row,ticks,parent in zip(q['records'],[125,-25,150],[None,None,one['operation_id']]):
            payload=encode_record(row['operation_id'],'A','A','query/series',numeric_payload(ticks),parent)
            h.check(row['record_digest']==record_digest(payload).hex(),'ordinary record digest unchanged')
        current=query(h,'source-current',s,issuer='A',scope='query/series')
        h.check({r['operation_id'] for r in current['records']}=={two['operation_id'],changed['operation_id']},'plural correction heads')
        h.check(author(h,'collision',s,3,op=one['operation_id'],ticks=999)['code']=='LOCAL_AUTHOR_OPERATION_CONFLICT','operation cannot change')
        h.check(author(h,'branch',s,3,parent=one['operation_id'])['code']=='LOCAL_AUTHOR_BRANCH_REJECTED','no branch')
        h.check(author(h,'unknown-parent',s,3,parent=operation('missing'))['code']=='LOCAL_AUTHOR_PARENT_REJECTED','no absent ancestry')
        blob=bytes(range(256))*234+bytes(range(96));h.check(len(blob)==60000,'maximum binary fixture')
        f=h.runtime/'binary.bin';f.write_bytes(blob)
        a=args(s,'binary',scope='query/binary');a=a[:-2]+['--payload-file',str(f)]
        r=h.run('maximum-binary',a)
        result=b''
        for off in range(0,len(blob),16000):
            p=query(h,f'binary-{off}',s,issuer='A',scope='query/binary',operation=r['operation_id'],payload='yes',payload_offset=off,payload_length=min(16000,len(blob)-off))
            result+=bytes.fromhex(p['records'][0]['payload_hex'])
        h.check(result==blob,'arbitrary maximum payload reconstructs')
        # No network is configured. This supplies source data directly to the actual numeric processor.
        numeric_create(h,'local-numeric',s,limit=2)
        values={one['operation_id']:numeric_payload(125),two['operation_id']:numeric_payload(-25),changed['operation_id']:numeric_payload(150)}
        result,rows=consume(h,'local-computation',s,values)
        h.check(result['consumer']['projection']['result']['numeric']['sum_ticks']=='125','locally produced evidence drives repeat-safe computation')
        (h.output/'SOURCE-RESULT.json').write_text(json.dumps({'source_operations':list(values),'result':result['consumer']['projection']['result'],'network_peers':0},indent=2)+'\n')
        h.run('source-compact',['compact','--control',str(d.control)])
        d.shutdown();d=h.start('source-restart',c,s)
        after=query(h,'source-after-replay',s,issuer='A',scope='query/series',view='history',payload='yes',payload_length=46)
        h.check(after['records']==q['records'],'authorship and query row bytes reconstruct through compaction')
        d.shutdown()
    case('originals_corrections_binary_and_local_projection',semantics)

    def principals():
        s=h.runtime/'principals';c=config(h,'principals',s,delegates=True);d=h.start('principals',c,s)
        expose_control_for_uid(s)
        first=author(h,'uid-original',s,uid=UID)
        a=args(s,'other-correction',parent=first['operation_id'])
        bad=run_as_uid(h,'cross-uid-correction',OTHER,OTHER,a,3)
        h.check(bad['code']=='LOCAL_AUTHOR_PARENT_REJECTED','a scope grant does not authorize editing another principal\'s chain')
        h.check(author(h,'uid-self-correction',s,uid=UID,parent=first['operation_id'])['disposition']=='AUTHORED','owner may correct')
        r=query(h,'uid-cannot-read',s,3,uid=UID);h.check(r['code']=='LOCAL_CONTROL_CLASS_DENIED','author grant is not read grant')
        h.check(author(h,'uid-hidden-scope',s,3,uid=UID,scope='query/binary')['code']=='LOCAL_AUTHOR_SCOPE_DENIED','exact scope for different UID')
        same=author(h,'other-original',s,uid=OTHER);h.check(same['disposition']=='AUTHORED','independent original in same scope allowed')
        # Slow in-flight request from owner is reauthorized after policy publication.
        raw=b'NOC1\x13'+encode_record(operation('slow-owner'),'A','A','query/series',b'slow')
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as sock:
            sock.settimeout(8);sock.connect(str(d.control));sock.sendall(struct.pack('!I',len(raw))+raw[:5])
            revoke=candidate(h,c,'author-revoked','author-g2',lambda t:t.replace(',EVIDENCE_AUTHOR','',1).replace('evidence_author=0,query/series\n','').replace('evidence_author=0,query/binary\n','').replace('evidence_author=0,query/other\n',''))
            activate(h,'live-author-revocation',s,revoke)
            sock.sendall(raw[5:]);n=struct.unpack('!I',receive_exact(sock,4))[0];reply=receive_exact(sock,n)
            h.check(reply[:5]==b'NOR1\1','slow previously opened connection denied')
            h.check(json.loads(reply[5:])['code']=='LOCAL_CONTROL_CLASS_DENIED','current UID class used after full read')
        q=query(h,'still-readable',s,issuer='A',scope='query/series',view='history')
        h.check(len(q['records'])==3,'revoked slow command creates no evidence')
        d.shutdown()
    case('kernel_principals_and_live_revocation',principals)

    def concurrency():
        s=h.runtime/'concurrent';c=config(h,'concurrent',s);d=h.start('concurrent',c,s)
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            values=list(pool.map(lambda i:author(h,f'parallel-{i}',s,value=str(i)),range(16)))
        op=operation('same-op')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            retries=list(pool.map(lambda i:author(h,f'same-op-{i}',s,op=op,value='same'),range(8)))
        h.check(sum(v['disposition']=='AUTHORED' for v in retries)==1,'concurrent exact retry has one commit')
        root=values[0]['operation_id']
        def competing(i):
            p=subprocess.run([str(h.binary),*args(s,f'branch-{i}',parent=root)],capture_output=True,text=True,timeout=8)
            return p.returncode,json.loads(p.stdout)
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: branches=list(pool.map(competing,range(8)))
        h.check(sum(code==0 for code,_ in branches)==1,'one competing correction wins')
        h.check(all(code==0 or v['code']=='LOCAL_AUTHOR_BRANCH_REJECTED' for code,v in branches),'losers do not poison state')
        q=query(h,'parallel-state',s,view='history',issuer='A',scope='query/series',limit=128)
        h.check(len(q['records'])==18 and len({r['operation_id'] for r in q['records']})==18,'all accepted operations unique')
        h.run('author-quiesce',['quiesce','--control',str(d.control),'--reason','source maintenance'])
        h.check(author(h,'quiesced-source',s,3)['code']=='SERVICE_QUIESCED','new source mutation obeys lifecycle')
        d.shutdown();d=h.start('source-quiesced-restart',c,s)
        h.check(author(h,'still-quiesced-source',s,3)['code']=='SERVICE_QUIESCED','durable service quiescence')
        h.run('author-resume',['resume','--control',str(d.control),'--reason','resume source'])
        author(h,'after-resume',s);d.shutdown()
    case('concurrent_idempotency_and_lifecycle',concurrency)

    def kills():
        for boundary in ('BEFORE','AFTER'):
            s=h.runtime/('kill-'+boundary);c=config(h,'kill-'+boundary,s)
            d=h.start('kill-'+boundary,c,s,environment={f'NATRAV_OVERLAY_TEST_LOCAL_AUTHOR_{boundary}_COMMIT_MS':'1500'})
            baseline=(s/'state.journal').stat().st_size
            log=h.logs/('pending-'+boundary+'.txt')
            with log.open('w') as output:
                p=subprocess.Popen([str(h.binary),*args(s,'kill-'+boundary)],stdout=output,stderr=output)
                if boundary=='AFTER':h.wait('actual authored frame synchronized',lambda:(s/'state.journal').stat().st_size>baseline,4)
                else:time.sleep(0.35)
                d.kill();p.wait(timeout=8)
            snap=inspect(h,'kill-inspect-'+boundary,s)
            h.check(snap['inbound']['count']==(1 if boundary=='AFTER' else 0),'exact source/provenance commit boundary')
            d=h.start('recover-'+boundary,c,s)
            r=author(h,'kill-'+boundary,s)
            h.check(r['disposition']==('ALREADY_AUTHORED' if boundary=='AFTER' else 'AUTHORED'),'lost response safe retry')
            d.shutdown()
    case('real_pre_and_post_commit_kills',kills)

    def tamper():
        s=h.runtime/'tamper';c=config(h,'tamper',s,delegates=True);d=h.start('tamper',c,s)
        first=author(h,'tamper-original',s);author(h,'tamper-correction',s,parent=first['operation_id']);d.shutdown()
        original=(s/'state.journal').read_bytes()
        frames=[];at=0
        while at<len(original):
            n=struct.unpack('!I',original[at+4:at+8])[0];frames.append(original[at:at+40+n]);at+=40+n
        indexes=[i for i,f in enumerate(frames) if f[8]==31]
        h.check(len(indexes)==2,'dedicated authored records, no forged remote accounts')
        for name,offset,value in [('rule',73,1),('request',137,1),('configuration',33,1),('uid',16,1)]:
            bad=bytearray(frames[indexes[-1]]);bad[offset]^=value
            changed=list(frames);changed[indexes[-1]]=checksum_frame(bytes(bad));(s/'state.journal').write_bytes(b''.join(changed))
            r=inspect(h,'semantic-'+name,s,3);h.check(r['code']=='JOURNAL_CORRUPT','recomputed checksum cannot justify '+name)
        (s/'state.journal').write_bytes(original)
        d=h.start('tamper-good',c,s);h.run('tamper-compact',['compact','--control',str(d.control)]);d.shutdown()
        checkpoint=(s/'state.journal').read_bytes();pos=checkpoint.find(b'NLA1');h.check(pos>=0,'checkpoint preserves explicit author account')
        # Full strict replay is independently tested above; authenticated root tested below.
        inspect(h,'untampered-compact',s)
    case('independent_semantic_corruption',tamper)

    def maintenance():
        s=h.runtime/'maintenance';c=config(h,'maintenance',s);d=h.start('maintenance',c,s)
        first=author(h,'maint-original',s,ticks=125);d.shutdown()
        key=new_key(h,h.work,'author-state-g1');migrate(h,'author-migration',s,key,node='A');d=start_keyed(h,'maint-keyed',c,s,key)
        second=author(h,'maint-correction',s,parent=first['operation_id'],ticks=-75)
        h.run('authored-keyed-compact',['compact','--control',str(d.control)]);d.shutdown()
        snapshot=inspect(h,'authored-keyed-state',s,key=key)
        h.run('authored-keyed-audit',['state-auth-audit','--state',str(s),'--node','A','--state-auth-key',str(key)])
        crypt=h.work/'author-backup.key';h.run('author-backup-key',['backup-key-init','--output',str(crypt),'--generation','author-backup-g1'])
        ident=h.identity('A');archive=h.work/'source.nob'
        h.run('author-export',['backup-export','--state',str(s),'--node','A','--generation','a-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'restored-source'
        h.run('author-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        again=inspect(h,'author-restored-state',restored,key=key)
        h.check(snapshot['storage']['logical_state_digest']==again['storage']['logical_state_digest'],'exact logical state after encrypted signed restore')
        moved=candidate(h,c,'source-relocated','source-relocated-g1',lambda t:t.replace('state='+str(s),'state='+str(restored)))
        h.run('author-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','local evidence source relocation','--state-auth-key',str(key)])
        d=start_keyed(h,'source-restored',moved,restored,key)
        again=author(h,'maint-correction',restored,parent=first['operation_id'],ticks=-75)
        h.check(again['disposition']=='ALREADY_AUTHORED' and again['local_authorship']==second['local_authorship'],'retry preserves original authority after relocation')
        third=author(h,'post-relocation',restored,parent=second['operation_id'],ticks=200)
        h.check(third['local_authorship']['configuration_event']>second['local_authorship']['configuration_event'],'new source mutation binds relocated generation')
        d.shutdown()
    case('keyed_compaction_encrypted_restore_and_relocation',maintenance)


    def pipeline():
        a,b,c=(h.runtime/('pipeline-'+x) for x in ('a','b','c'));ap,bp,cp=free_port(),free_port(),free_port()
        ac=config(h,'pipeline-a',a,port=ap,peers=[('C',cp)],inbound=['B'])
        ac.write_text(ac.read_text()+f'evidence_read={os.geteuid()},B,query/series,METADATA\n'+
            'authorize=B,*,EVIDENCE,query/series\n')
        bc=peer_config(h,'pipeline-b','B',b,bp,peers=[('A',ap)])
        cc=peer_config(h,'pipeline-c','C',c,cp,inbound=['A'])
        cc.write_text(cc.read_text()+'authorize=A,*,EVIDENCE,derived/local-summary\n')
        cd=h.start('pipeline-c',cc,c);ad=h.start('pipeline-a',ac,a);bd=h.start('pipeline-b',bc,b)
        foreign=operation('foreign-stored')
        submit(h,'foreign-stored',bd.control,'B','A','query/series',foreign,'third-party input')
        wait_state(h,b,foreign,'ACKED','foreign-ack')
        q=query(h,'foreign-visible',a,issuer='B',scope='query/series',view='history')
        h.check(len(q['records'])==1 and 'local_authorship' not in q['records'][0],
            'remote evidence never acquires local source provenance')
        h.check(author(h,'foreign-cannot-correct',a,3,parent=foreign)['code']=='LOCAL_AUTHOR_PARENT_REJECTED',
            'source command cannot rewrite third-party evidence')
        vals={}
        for name,ticks in [('source-first',100),('source-second',25)]:
            authored=author(h,name,a,ticks=ticks);vals[authored['operation_id']]=numeric_payload(ticks)
        numeric_create(h,'pipeline-projection',a,limit=2)
        result,rows=consume(h,'pipeline-process',a,vals)
        h.check(len(rows)==2 and result['consumer']['projection']['result']['numeric']['sum_ticks']=='125',
            'own source selected; stored third-party evidence excluded')
        outgoing=publish(h,'pipeline-publish',a,result,scope='derived/local-summary',peer='C')
        op=outgoing['operation_id'];wait_state(h,a,op,'ACKED','pipeline-receipt')
        repeat=publish(h,'pipeline-publish-retry',a,result,scope='derived/local-summary',peer='C')
        h.check(repeat['operation_id']==op,'exact derived publication identity reused')
        remote=legacy_query(h,'pipeline-recipient',c,operation=op,view='history',payload='yes',payload_length=16384)
        encoded=bytes.fromhex(remote['records'][0]['payload_hex']);decoded=decode_npp1(encoded)
        h.check(decoded['source_issuer']=='A' and decoded['result']['numeric']['sum_ticks']==125,
            'recipient receives native fixed-point result from local source')
        h.check(all('local_authorship' not in row for row in remote['records']),
            'derived result remains a remote admission, not recipient-local authorship')
        ad.shutdown();bd.shutdown();cd.shutdown()
        source=inspect(h,'pipeline-source-state',a)
        h.check(source['inbound']['count']==3 and source['outbox']['count']==1,
            'recipient-addressed publication is not reimported into the local source')
        recipient=h.run('pipeline-recipient-state',['inspect','--state',str(c),'--node','C'])
        h.check(recipient['inbound']['count']==1,'duplicate publication never multiplies admission')
        (h.output/'PIPELINE.json').write_text(json.dumps({'local_sources':2,'stored_third_party':1,
            'result_sum_ticks':125,'recipient_admissions':1,'result_operation':op,'decoded_result':decoded},indent=2)+'\n')
    case('local_numeric_source_to_authenticated_result_delivery',pipeline)

def main()->int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    try:cases(h,set(a.case) if a.case else None);ok=True
    except BaseException as exc:
        (h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(f'FAIL: {type(exc).__name__}: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_LOCAL_EVIDENCE_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(x['status']=='PASS' for x in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,v in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
