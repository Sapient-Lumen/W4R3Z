#!/usr/bin/env python3
"""Exact report correlation on owned C++ nodes, with independent NAC1/wire mutations.
Fixtures using provider private keys are deliberate dishonest-provider simulations,
not third-party traffic or proof that a correctly encoded claim is true.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, shutil, socket, struct, subprocess, sys, time
from pathlib import Path
from run_persistent import Harness, free_port, operation, raw_control, receive_exact
from run_action_results import config, submit_action, wait_action, wait_outbox, evidence_query, decode_nac1, RESULT_SCOPE
from run_authorization_actions import independent_record
from run_live_configuration import candidate, activate
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_state_authentication import new_key, migrate, start as keyed_start, inspect
from run_integration import encode_record


def arguments(state, result, action, *, provider='B', scope=RESULT_SCOPE, maximum=16384):
    return ['action-result-query','--control',str(state/'control.sock'),'--operation',result,'--request',action,
            '--provider',provider,'--scope',scope,'--max-bytes',str(maximum),'--deadline-ms','5000']


def query(h,label,state,result,action,*,expected=0,uid=None,**kw):
    args=arguments(state,result,action,**kw)
    q=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    assert q
    if expected==0:
        h.check(q['format']=='NATRAV_OVERLAY_ACTION_RESULT_QUERY_V1','explicit observational result format')
        h.check(len(json.dumps(q,separators=(',',':')).encode())<=kw.get('maximum',16384),'complete annotated response bounded')
        h.check(q['work']['snapshot_calls']==q['work']['logical_bytes_serialized']==0,'no application snapshot or logical serialization')
        h.check(q['work']['candidate_records_visited']<=32,'bounded candidate scan')
        if q['status']=='CORRELATED':
            h.check(q['correlated'] and not q['execution_verified_locally'],'correlation is not local execution proof')
            h.check(q['report']['provider_administrative_receipt'] is None,'NAC1 has no administrative receipt to invent')
            h.check(q['result_admission']['operation_id']!=q['original_request']['operation_id'],'request and result admissions remain distinct')
    return q


def wire(result,action,provider='B',scope=RESULT_SCOPE,maximum=16384):
    text=lambda s:struct.pack('!H',len(s.encode()))+s.encode()
    return b'NOC1\x1fARQ1'+bytes.fromhex(result)+bytes.fromhex(action)+text(provider)+text(scope)+struct.pack('!I',maximum)


def encode_nac(r):
    text=lambda s:struct.pack('!H',len(s.encode()))+s.encode()
    number=lambda n:struct.pack('!Q',n)
    d=lambda s:bytes.fromhex(s)
    ou=lambda n:b'\0' if n is None else b'\1'+number(n)
    od=lambda n:b'\0' if n is None else b'\1'+d(n)
    return (b'NAC1'+bytes([r['outcome']])+d(r['action_id'])+d(r['source_record_digest'])+number(r['source_sequence'])+
        d(r['source_policy_digest'])+d(r['source_rule_digest'])+number(r['source_decided_unix_ms'])+
        d(r['result_policy_digest'])+d(r['result_rule_digest'])+number(r['configuration_event'])+
        text(r['scope'])+text(r['peer_generation'])+d(r['peer_spki_sha256'])+number(r['amount'])+
        number(r['admitted_unix_ms'])+number(r['terminal_unix_ms'])+struct.pack('!I',r['attempts'])+
        ou(r['last_started_unix_ms'])+od(r['local_receipt_digest'])+ou(r['counter_before'])+ou(r['counter_after'])+
        struct.pack('!H',r['reason_bytes'])+d(r['reason_digest']))


def effect(r):
    return hashlib.sha256(b'NATRAV_OVERLAY_COUNTER_ACTION_RECEIPT_V1\0'+bytes.fromhex(r['action_id'])+
        struct.pack('!IQQQ',r['attempts'],r['terminal_unix_ms'],r['counter_before'],r['counter_after'])).hexdigest()


def result_id(payload):
    return hashlib.sha256(b'NATRAV_OVERLAY_ACTION_RESULT_OPERATION_V1\0'+payload).hexdigest()


def setup(h,name,*,environment=None,delegates=False,preseed=False):
    root=h.runtime/name;root.mkdir()
    ap,bp=free_port(),free_port()
    while ap==bp:bp=free_port()
    ac=config(h,name+'-a','A',root/'a',ap,'B',bp,receive_action=False,allow_result=False,read_results=True)
    bc=config(h,name+'-b','B',root/'b',bp,'A',ap,receive_action=True,allow_result=True)
    if delegates:
        ac.write_text(ac.read_text()+
            'local_control=65534,INSPECT,EVIDENCE_READ,EVIDENCE_PAYLOAD\n'+
            f'evidence_read=65534,B,{RESULT_SCOPE},PAYLOAD\n'+
            'local_control=65533,INSPECT,EVIDENCE_READ\n'+f'evidence_read=65533,B,{RESULT_SCOPE},METADATA\n'+
            'local_control=65532,EVIDENCE_READ,EVIDENCE_PAYLOAD\n'+f'evidence_read=65532,B,{RESULT_SCOPE},PAYLOAD\n')
    if preseed:
        s=root/'a';s.mkdir(mode=0o700)
        (s/'node.meta').write_text('NATRAV_OVERLAY_NODE_STATE_V2\nnode=A\nstorage_schema=2\n');(s/'node.meta').chmod(0o600)
        (s/'state.lock').touch(mode=0o600)
        body=b'\x01'+encode_record(operation('unmarked-result'),'B','A',RESULT_SCOPE,b'NAC1'+b'\0'*394)
        (s/'state.journal').write_bytes(b'NOJ1'+struct.pack('!I',len(body))+body+hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest())
        (s/'state.journal').chmod(0o600)
    ad=h.start(name+'-a',ac,root/'a');bd=h.start(name+'-b',bc,root/'b',environment)
    return root,ap,bp,ac,bc,ad,bd


def completed(h,label,root,amount=7,defer=0):
    action=operation(label);submit_action(h,label+'-submit',root/'a',action,amount,defer)
    row=wait_action(h,label+'-effect',root/'b',action,'EXECUTED')
    result=row['action_result']['operation_id'];wait_outbox(h,label+'-result',root/'b',result,'ACKED')
    payload=bytes.fromhex(evidence_query(h,label+'-raw',root/'a',result)['payload_hex'])
    h.check(result_id(payload)==result and encode_nac(decode_nac1(payload))==payload,'independent canonical NAC1 and operation identity')
    return action,result,payload


def emit(h,port,payload,*,identity='B',provider='B',scope=RESULT_SCOPE,op=None):
    op=op or result_id(payload)
    r=independent_record(h,port,identity,provider,'A',op,scope,payload)
    h.check(r.get('kind')=='receipt','malformed or dishonest report still receives ordinary authorized evidence admission')
    return op


def cases(h,selected):
    def case(name,fn):
        if selected is None or name in selected:h.case(name,fn)

    def pipeline():
        root,ap,bp,ac,bc,a,b=setup(h,'pipeline')
        action,result,payload=completed(h,'pipeline-executed',root)
        q=query(h,'correlate-executed',root/'a',result,action);r=decode_nac1(payload)
        h.check(q['report']['counter_after']=='7' and q['report']['counter_before']=='0','exact string counters from independent reference')
        h.check(q['report']['local_effect_receipt_digest']==r['local_receipt_digest']==effect(r),'effect commitment independent recomputation')
        h.check(q['original_request']['source_admission_receipt']['sequence']==r['source_sequence'],'original durable admission receipt agrees')
        h.check(q['report']['result_policy_digest']==r['result_policy_digest'] and q['report']['provider_configuration_event']==r['configuration_event'],'provider policy fields are retained claims')
        before=h.status('observation-before',root/'a')['storage']['logical_state_digest']
        for i in range(6):query(h,'observe-'+str(i),root/'a',result,action)
        after=h.status('observation-after',root/'a')['storage']['logical_state_digest']
        h.check(before==after,'successful correlation is observational')
        emit(h,ap,payload)
        h.check(query(h,'duplicate-report',root/'a',result,action)['work']['candidate_records_visited']==1,'duplicate outer delivery does not multiply candidates')
        h.check(query(h,'small-response',root/'a',result,action,maximum=2048,expected=3)['code']=='ACTION_RESULT_RESPONSE_LIMIT','no partial row on small response')
        missing=operation('missing-result')
        h.check(query(h,'missing',root/'a',missing,action)['status']=='NOT_FOUND','absent result is explicit')
        pending=operation('cancelled-source');submit_action(h,'cancel-source',root/'a',pending,3,30000)
        wait_action(h,'pending-to-cancel',root/'b',pending,'PENDING')
        h.run('cancel-on-provider',['action-cancel','--control',str(root/'b'/'control.sock'),'--action',pending,'--reason','private cancellation reason'])
        row=wait_action(h,'cancelled',root/'b',pending,'CANCELLED');cancelled=row['action_result']['operation_id'];wait_outbox(h,'cancelled-result',root/'b',cancelled,'ACKED')
        c=query(h,'correlate-cancelled',root/'a',cancelled,pending)
        h.check(c['report']['counter_after'] is None and c['report']['local_effect_receipt_digest'] is None,'cancelled has no executed counter effect')
        h.check('private cancellation reason' not in json.dumps(c),'private reason not echoed')
        independent=raw_control(root/'a'/'control.sock',wire(result,action))
        h.check(independent[0] and independent[1]['status']=='CORRELATED','independent control encoding works')
        for bad in [wire(result,action)+b'X',wire(result,action)[:-1],wire(result,action).replace(b'ARQ1',b'ARQ2')]:
            ok,err=raw_control(root/'a'/'control.sock',bad);h.check(not ok and err['code']=='ACTION_RESULT_QUERY_INVALID','strict request EOF/version')
        (h.output/'PIPELINE.json').write_text(json.dumps({'executed':q,'cancelled':c,'independent':r},indent=2)+'\n')
        b.shutdown();a.shutdown()
    case('real_execution_cancellation_duplicates_and_bounded_protocol',pipeline)

    def invalid_reports():
        root,ap,bp,ac,bc,a,b=setup(h,'invalid',preseed=True)
        action,result,payload=completed(h,'invalid-reference',root)
        h.check(query(h,'unmarked-not-authenticated',root/'a',operation('unmarked-result'),action,expected=3)['code']=='ACTION_RESULT_ADMISSION_INVALID','legacy unmarked self-claim cannot be authenticated by parsing')
        r=decode_nac1(payload)
        mutations=[]
        def changed(name,key,value,code,fix_effect=False):
            v=dict(r);v[key]=value
            if fix_effect:
                v['counter_after']=v['counter_before']+v['amount'];v['local_receipt_digest']=effect(v)
            mutations.append((name,encode_nac(v),code))
        changed('wrong-request-digest','source_record_digest','77'*32,'ACTION_RESULT_REQUEST_MISMATCH')
        changed('wrong-action','action_id','78'*32,'ACTION_RESULT_REQUEST_MISMATCH',True)
        changed('wrong-amount','amount',8,'ACTION_RESULT_REQUEST_MISMATCH',True)
        changed('wrong-source-sequence','source_sequence',r['source_sequence']+100,'ACTION_RESULT_SOURCE_RECEIPT_MISMATCH')
        changed('wrong-recipient-generation','peer_generation','another-generation','ACTION_RESULT_RECIPIENT_BINDING_MISMATCH')
        changed('wrong-recipient-pin','peer_spki_sha256','79'*32,'ACTION_RESULT_RECIPIENT_BINDING_MISMATCH')
        changed('wrong-embedded-scope','scope','results/other','ACTION_RESULT_RECIPIENT_BINDING_MISMATCH')
        changed('wrong-effect','local_receipt_digest','80'*32,'ACTION_RESULT_EFFECT_RECEIPT_MISMATCH')
        changed('wrong-outcome','outcome',2,'ACTION_RESULT_REPORT_INVALID')
        changed('unknown-outcome','outcome',99,'ACTION_RESULT_REPORT_INVALID')
        changed('wrong-arithmetic','counter_after',r['counter_after']+1,'ACTION_RESULT_REPORT_INVALID')
        changed('bad-source-time','source_decided_unix_ms',r['source_decided_unix_ms']+1,'ACTION_RESULT_REPORT_INVALID')
        mutations.extend([('truncated',payload[:-1],'ACTION_RESULT_FORMAT_INVALID'),('trailing',payload+b'x','ACTION_RESULT_FORMAT_INVALID'),('oversized',b'NAC1'+b'x'*600,'ACTION_RESULT_FORMAT_INVALID')])
        results=[]
        for name,p,expected in mutations:
            op=emit(h,ap,p)
            denied=query(h,name,root/'a',op,action,expected=3)
            h.check(denied['code']==expected,name+' must fail exact binding');results.append([name,denied['code']])
        wrongop=emit(h,ap,payload,op=operation('noncanonical-operation'))
        h.check(query(h,'wrong-outer-operation',root/'a',wrongop,action,expected=3)['code']=='ACTION_RESULT_OPERATION_MISMATCH','outer operation commits full report')
        h.check(query(h,'original-still-correlates',root/'a',result,action)['status']=='CORRELATED','invalid reports stay evidence without validating as conflicting results')
        h.check(query(h,'missing-request',root/'a',result,operation('not-stored-request'),expected=3)['code']=='ACTION_RESULT_REQUEST_NOT_FOUND','no guessed request association')
        b.shutdown();a.shutdown();a=h.start('invalid-reconstructed',ac,root/'a')
        h.check(query(h,'invalids-after-restart',root/'a',result,action)['status']=='CORRELATED','derived candidate and admission indexes reconstruct')
        (h.output/'INVALID-REPORTS.json').write_text(json.dumps(results,indent=2)+'\n');a.shutdown()
    case('malformed_semantic_misbinding_and_unmarked_reports',invalid_reports)

    def permission():
        root,ap,bp,ac,bc,a,b=setup(h,'permission',delegates=True)
        action,result,payload=completed(h,'permission-result',root)
        expose_control_for_uid(root/'a')
        query(h,'full-delegated-reader',root/'a',result,action,uid=65534)
        for uid in [65533,65532]:
            h.check(query(h,'class-denied-'+str(uid),root/'a',result,action,uid=uid,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','metadata/inspect-only is not payload correlation authority')
        for op in [result,operation('not-visible')]:
            h.check(query(h,'hidden-scope-'+op[:5],root/'a',op,action,uid=65534,scope='results/private',expected=3)['code']=='ACTION_RESULT_READ_DENIED','domain permission checked before evidence presence')
        # Connect as the real delegated UID and pause a partially transmitted frame.
        script="""import socket,struct,sys,json
s=socket.socket(socket.AF_UNIX);s.settimeout(10);s.connect(sys.argv[1]);p=bytes.fromhex(sys.argv[2]);s.sendall(struct.pack('!I',len(p))+p[:2]);print('CONNECTED',flush=True);sys.stdin.readline();s.sendall(p[2:]);s.shutdown(socket.SHUT_WR)
def get(n):
 b=b''
 while len(b)<n:
  x=s.recv(n-len(b))
  if not x: raise RuntimeError('early EOF')
  b+=x
 return b
n=struct.unpack('!I',get(4))[0];r=get(n);print(json.dumps({'ok':r[4]==0,'body':json.loads(r[5:])}),flush=True)
"""
        proc=subprocess.Popen(['/usr/bin/setpriv','--reuid=65534','--regid=65534','--clear-groups',sys.executable,'-c',script,str(root/'a'/'control.sock'),wire(result,action).hex()],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        h.check(proc.stdout.readline().strip()=='CONNECTED','actual UID request connected before revoke')
        changed=candidate(h,ac,'permission-revoked','permission-revoked-g2',lambda t:t.replace('local_control=65534,INSPECT,EVIDENCE_READ,EVIDENCE_PAYLOAD','local_control=65534,INSPECT,EVIDENCE_READ').replace(f'evidence_read=65534,B,{RESULT_SCOPE},PAYLOAD',f'evidence_read=65534,B,{RESULT_SCOPE},METADATA'))
        activate(h,'revoke-payload',root/'a',changed)
        out,err=proc.communicate('\n',timeout=12)
        response=json.loads(out.splitlines()[-1]);h.check(proc.returncode==0 and not response['ok'] and response['body']['code']=='LOCAL_CONTROL_CLASS_DENIED','partially transmitted request uses revoked current generation')
        (h.output/'PRINCIPALS.json').write_text(json.dumps(response,indent=2)+'\n')
        restore_owner_only_control(root/'a');b.shutdown();a.shutdown()
    case('real_uid_payload_authority_and_live_revocation',permission)

    def keys():
        root,ap,bp,ac,bc,a,b=setup(h,'keys')
        action,result,payload=completed(h,'key-original',root)
        pin=h.identity('B2').spki_sha256
        changed=candidate(h,ac,'rotated-provider','keys-g2',lambda t:t.replace('peer_key=B,b-g1,ACTIVE,','peer_key=B,b-g1,REVOKED,').replace(f'authorize=B,b-g1,EVIDENCE,{RESULT_SCOPE}\n','')+
            f'peer_key=B,b-g2,ACTIVE,{pin}\nauthorize=B,b-g2,EVIDENCE,{RESULT_SCOPE}\n')
        activate(h,'rotate-provider',root/'a',changed)
        old=query(h,'historical-authentication',root/'a',result,action)
        h.check(old['original_request']['current_provider_key_state']=='REVOKED','revocation does not rewrite historical admission; current trust labeled separately')
        r=decode_nac1(payload);r['terminal_unix_ms']+=1;r['local_receipt_digest']=effect(r)
        op=emit(h,ap,encode_nac(r),identity='B2')
        h.check(query(h,'wrong-executor-generation',root/'a',op,action,expected=3)['code']=='ACTION_RESULT_PROVIDER_BINDING_MISMATCH','new valid provider key cannot answer original key-bound request')
        h.check(query(h,'old-still-valid',root/'a',result,action)['status']=='CORRELATED','different key report is excluded rather than replacing history')
        b.shutdown();a.shutdown()
    case('exact_executor_generation_and_historical_revocation',keys)

    def conflicts():
        root,ap,bp,ac,bc,a,b=setup(h,'conflicts')
        action,result,payload=completed(h,'conflicting-original',root)
        r=decode_nac1(payload);r['terminal_unix_ms']+=1;r['local_receipt_digest']=effect(r)
        other=emit(h,ap,encode_nac(r))
        q=query(h,'two-authenticated-claims',root/'a',result,action)
        h.check(q['status']=='CONFLICTING_REPORTS' and not q['correlated'] and q['report'] is None,'two locally consistent but differing reports are not verified as unique effect')
        h.check(set(q['conflicting_operations'])=={result,other},'both exact report operations retained')
        h.run('conflict-compact',['compact','--control',str(root/'a'/'control.sock'),'--deadline-ms','5000']);a.shutdown();a=h.start('conflict-restart',ac,root/'a')
        h.check(query(h,'reconstructed-conflict',root/'a',other,action)['status']=='CONFLICTING_REPORTS','conflict index reconstructs through checkpoint')
        # Thirty additional malformed candidates reach the bound exactly; one
        # more makes the scope/request-specific scan fail closed.
        for i in range(30):
            candidate_payload=b'NAC1\x01'+bytes.fromhex(action)+bytes([i])*40
            emit(h,ap,candidate_payload)
        h.check(query(h,'exact-candidate-boundary',root/'a',result,action)['status']=='CONFLICTING_REPORTS','exact 32-candidate ceiling permits complete bounded classification')
        emit(h,ap,b'NAC1\x01'+bytes.fromhex(action)+b'z'*40)
        limited=query(h,'candidate-ceiling',root/'a',result,action,expected=3)
        h.check(limited['code']=='ACTION_RESULT_SCAN_LIMIT','untrusted candidate flood cannot cause unbounded correlation')
        (h.output/'CONFLICTS.json').write_text(json.dumps({'conflict':q,'bounded_failure':limited},indent=2)+'\n')
        b.shutdown();a.shutdown()
    case('conflicting_claims_and_candidate_ceiling',conflicts)

    def absent_receipt():
        action=operation('lost-source-receipt')
        root,ap,bp,ac,bc,a,b=setup(h,'lost',environment={'NATRAV_OVERLAY_TEST_SESSION_DROP_AFTER_ADMISSION_OPERATION':action})
        # Long source retry backoff makes absence an observed durable fact, not
        # a race won by aggressive polling.
        slow=candidate(h,ac,'slow-request-retry','lost-g2',lambda t:t.replace('peer=B,50,250,50,120000','peer=B,10000,10000,50,120000'))
        activate(h,'source-retry-backoff',root/'a',slow)
        submit_action(h,'lost-request',root/'a',action,9)
        row=wait_action(h,'lost-execution',root/'b',action,'EXECUTED');result=row['action_result']['operation_id']
        wait_outbox(h,'lost-result-delivery',root/'b',result,'ACKED')
        q=query(h,'report-before-source-receipt',root/'a',result,action)
        h.check(q['original_request']['source_admission_receipt'] is None and q['original_request']['delivery_state']=='PENDING','report does not fabricate a missing original request receipt or acknowledgment')
        h.check(q['report']['counter_after']=='9','returned report is still correlated to exact durable original request')
        (h.output/'LOST-RECEIPT.json').write_text(json.dumps(q,indent=2)+'\n');b.shutdown();a.shutdown()
    case('report_precedes_original_receipt_without_fabricated_acknowledgment',absent_receipt)

    def expired():
        root,ap,bp,ac,bc,a,b=setup(h,'expiry',environment={'NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS':'1000'})
        changed=candidate(h,bc,'short-expiry','expiry-g2',lambda t:t.replace('action_expiry_ms=60000','action_expiry_ms=500').replace('action_max_defer_ms=30000','action_max_defer_ms=400'))
        activate(h,'short-action-expiry',root/'b',changed)
        first=operation('occupy-counter');submit_action(h,'blocking-counter',root/'a',first,1)
        def begun():return wait_action(h,'blocking-start',root/'b',first,'PENDING')['attempts']>0
        h.wait('blocking action has synchronized begin',begun,timeout=5)
        second=operation('expired-result');submit_action(h,'expires-unbegun',root/'a',second,4,200)
        row=wait_action(h,'expired-local',root/'b',second,'EXPIRED');result=row['action_result']['operation_id']
        wait_outbox(h,'expired-return',root/'b',result,'ACKED');q=query(h,'correlate-expired',root/'a',result,second)
        h.check(q['report']['outcome']=='EXPIRED' and q['report']['attempts']==0 and q['report']['counter_after'] is None,'expired report is not executed effect')
        b.shutdown();a.shutdown()
    case('real_unbegun_expired_result',expired)

    def maintenance():
        root,ap,bp,ac,bc,a,b=setup(h,'maintenance')
        action,result,payload=completed(h,'maintenance-result',root,11)
        original=query(h,'before-keyed-maintenance',root/'a',result,action)
        a.shutdown();key=new_key(h,h.work,'correlation-state');migrate(h,'correlation-migrate',root/'a',key,node='A')
        a=keyed_start(h,'correlation-keyed',ac,root/'a',key)
        h.check(query(h,'keyed-query',root/'a',result,action)['report']==original['report'],'keyed reader derives same claims')
        h.run('correlation-compact',['compact','--control',str(root/'a'/'control.sock'),'--deadline-ms','5000']);a.shutdown()
        h.run('correlation-audit',['state-auth-audit','--state',str(root/'a'),'--node','A','--state-auth-key',str(key)])
        before=inspect(h,'correlation-offline',root/'a',key,node='A')
        crypt=h.work/'correlation-backup.key';h.run('archive-key',['backup-key-init','--output',str(crypt),'--generation','correlation-archive'])
        identity=h.identity('A');archive=h.work/'correlation.nob'
        h.run('correlation-export',['backup-export','--state',str(root/'a'),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--output',str(archive),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'correlation-restored'
        h.run('correlation-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'correlation-restored-state',restored,key,node='A')
        h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'exact logical state preserved at offline restore')
        relocated_identity=h.runtime/'correlation-identity';relocated_identity.mkdir(mode=0o700)
        new_cert=relocated_identity/'cert.pem';new_secret=relocated_identity/'key.pem'
        shutil.copyfile(identity.certificate,new_cert);shutil.copyfile(identity.private_key,new_secret);new_secret.chmod(0o600)
        moved=candidate(h,ac,'correlation-moved','correlation-moved-g2',lambda t:t.replace('state='+str(root/'a'),'state='+str(restored)).replace(str(identity.certificate),str(new_cert)).replace(str(identity.private_key),str(new_secret)))
        h.run('correlation-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','continue observed results','--state-auth-key',str(key)])
        identity.certificate.unlink();identity.private_key.unlink()
        a=keyed_start(h,'correlation-relocated',moved,restored,key)
        q=query(h,'relocated-query',restored,result,action)
        h.check(q['report']==original['report'] and q['result_admission']==original['result_admission'],'historical admission stays same through relocation')
        # A subsequent request/result is truly delivered to the restored recipient.
        newaction=operation('post-restore-result');submit_action(h,'post-restore-source',restored,newaction,2)
        row=wait_action(h,'post-restore-execute',root/'b',newaction,'EXECUTED');newresult=row['action_result']['operation_id'];wait_outbox(h,'post-restore-receive',root/'b',newresult,'ACKED')
        newer=query(h,'post-restore-correlate',restored,newresult,newaction)
        h.check(newer['report']['counter_after']=='13','new report after restore uses exact new request')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'before':original,'after':q,'new':newer,'logical_digest':after['storage']['logical_state_digest']},indent=2)+'\n')
        b.shutdown();a.shutdown()
    case('authenticated_compaction_encrypted_restore_relocation_and_continuation',maintenance)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--binary',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--case',action='append');args=parser.parse_args()
    if args.output.exists():parser.error('output must not exist')
    h=Harness(args.binary,args.output);started=time.time();ok=False
    try:
        cases(h,set(args.case) if args.case else None)
        if not h.cases:raise ValueError('no selected cases')
        ok=True
    except BaseException as exc:
        (h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(f'FAIL: {exc}',file=sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_ACTION_RESULT_CORRELATION_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,value in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]: (h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1

if __name__=='__main__':raise SystemExit(main())
