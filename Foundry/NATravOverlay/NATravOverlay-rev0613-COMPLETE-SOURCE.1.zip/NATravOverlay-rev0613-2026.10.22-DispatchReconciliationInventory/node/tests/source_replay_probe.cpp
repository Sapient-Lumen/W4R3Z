#include "journal.hpp"
#include "source_validation_work.hpp"
#include <chrono>
#include <iostream>
#include <memory>
#include <string>
using namespace natrav_overlay;
// Test executable only. Opens an existing owned complete state through NodeState;
// exposes counters for reconstruction without changing production command surface.
int main(int argc, char** argv) {
    if (argc != 3) { std::cerr << "usage: source-replay-probe STATE NODE\n"; return 2; }
    try {
        SourceValidationWork work;
        const auto begin = std::chrono::steady_clock::now();
        std::unique_ptr<NodeState> state;
        {
            SourceValidationWorkScope scope(work);
            state = std::make_unique<NodeState>(argv[1], argv[2], 268435456U);
        }
        const auto elapsed = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - begin).count();
        const auto snapshot = state->snapshot();
        auto measured = source_validation_work_json(work);
        const std::string ordinary_scope = "CALLING_THREAD_SOURCE_COMMAND";
        measured.replace(measured.find(ordinary_scope), ordinary_scope.size(),
                         "NODESTATE_CONSTRUCTION_SOURCE_VALIDATION");
        std::cout << "{\"format\":\"SOURCE_REPLAY_WORK_V1\",\"elapsed_seconds\":" << elapsed
                  << ",\"work\":" << measured
                  << ",\"logical_state_digest\":" << json_string(datacube::hex_lower(snapshot.logical_state_digest))
                  << "}\n";
        return 0;
    } catch (const AppError& e) {
        std::cerr << e.code() << ": " << e.what() << '\n'; return 3;
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n'; return 4;
    }
}
