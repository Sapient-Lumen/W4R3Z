#!/usr/bin/env python3
"""Exercise serial build-failure cleanup with a deliberately failing compiler.

This checks temporary object-directory lifetime and removal, not C++ compilation
or product behavior. All synthetic compiler files and objects are confined to a
temporary directory.
"""
from pathlib import Path
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-script', type=Path,
                        default=Path(__file__).resolve().parents[1] / 'build.sh')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error('output must not already exist')
    with tempfile.TemporaryDirectory(prefix='natrav-build-cleanup-') as directory:
        root = Path(directory)
        node = root / 'node'
        node.mkdir()
        shutil.copy2(args.build_script, node / 'build.sh')
        observation = root / 'child.json'
        compiler = root / 'fake-compiler'
        compiler.write_text('#!' + sys.executable + '\n' + '''
from pathlib import Path
import json,os,sys
args=sys.argv[1:]
source=args[args.index('-c')+1]
output=Path(args[args.index('-o')+1])
Path(os.environ['CLEANUP_OBSERVATION']).write_text(json.dumps({
    'failing_source': source,
    'object_directory_exists_during_failure': output.parent.is_dir()}))
sys.exit(2)
''')
        compiler.chmod(0o700)
        result = subprocess.run(['sh', str(node / 'build.sh'), 'static'],
            capture_output=True, text=True, timeout=10,
            env=dict(os.environ, JOBS='2', CXX=str(compiler),
                     CLEANUP_OBSERVATION=str(observation)))
        child = json.loads(observation.read_text()) if observation.exists() else {}
        record = {'format': 'NATRAV_BUILD_CLEANUP_TEST_V2', **child,
                  'build_exit': result.returncode,
                  'temporary_directories_remaining': len(list(node.glob('.build-*'))),
                  'scope': 'Controlled serial fake-compiler failure and temporary-directory cleanup only.'}
        passed = (record.get('failing_source') == 'src/main.cpp'
                  and record.get('object_directory_exists_during_failure') is True
                  and result.returncode != 0
                  and record['temporary_directories_remaining'] == 0)
        record['status'] = 'PASS' if passed else 'FAIL'
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
