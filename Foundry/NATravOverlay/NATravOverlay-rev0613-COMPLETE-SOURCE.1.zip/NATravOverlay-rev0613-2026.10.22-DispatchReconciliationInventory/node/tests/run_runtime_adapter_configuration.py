#!/usr/bin/env python3
"""V19 policy through real configuration admission, durable history and restart.
Adapter execution is deliberately not registered by this increment.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from run_persistent import Harness, free_port, operation
from run_live_configuration import candidate, activate, rollback, wait_state
from run_local_administration import v8_config, expose_control_for_uid, restore_owner_only_control, run_as_uid
from run_peer_sessions import submit, outbox_entry
from run_maintenance import inspect, compact

ZERO='0'*64
CLASSES=['INSPECT','SUBMIT','ACTION','MAINTENANCE','CONFIGURATION','SHUTDOWN']

def digest(s): return hashlib.sha256(s.encode('ascii')).hexdigest()

def profile(identifier='radio',generation=1,previous=ZERO,image='11'*32):
    return '\n'.join([
        'NATRAV_ADAPTER_PROFILE_V1',f'id={identifier}',f'generation={generation}',f'previous={previous}',
        'executable=%2Fnot-present%2Fnatrav-adapter',f'sha256={image}',
        'argument-count=1','argument=--literal%3Dno-shell','mtu=512','capability-profile=1',
        'max-frame-bytes=65536','max-queued-bytes=1048576','max-outstanding-requests=1',
        'max-evidence-events=256','max-launch-attempts=3','startup-timeout-ms=2000',
        'request-timeout-ms=500','shutdown-timeout-ms=500','initial-restart-backoff-ms=10',
        'maximum-restart-backoff-ms=250',''])

def endpoint(p,identifier='radio-out',generation=1,previous=ZERO,role='route'):
    v=dict(line.split('=',1) for line in p.splitlines()[1:])
    return '\n'.join(['NATRAV_ADAPTER_ENDPOINT_V1',f'id={identifier}',f'generation={generation}',
        f'previous={previous}',f'role={role}',
        f"locator=adapter-v1|profile={v['id']}|generation={v['generation']}|link=0000000000000001|epoch=1",
        f'profile-sha256={digest(p)}',''])

def records(ps,es):
    return ''.join('adapter_profile_hex='+p.encode('ascii').hex()+'\n' for p in ps)+''.join(
        'adapter_endpoint_hex='+e.encode('ascii').hex()+'\n' for e in es)

def upgrade(text,generation,version=19):
    lines=[f'NATRAV_OVERLAY_CONFIG_V{version}']
    for line in text.splitlines()[1:]:
        if line.startswith('runtime_generation='): continue
        if line.startswith('peer=') and version>=13:
            f=line[5:].split(',')
            if len(f)==6:
                lines+=['peer='+','.join([f[0],*f[2:]]),f'peer_route={f[0]},default,0,ENABLED,{f[1]}'];continue
        lines.append(line)
    if version>=7: lines.append('runtime_generation='+generation)
    if version>=8 and not any(l.startswith('local_control=') for l in lines):
        lines.append(f'local_control={os.geteuid()},'+','.join(CLASSES))
    return '\n'.join(lines)+'\n'

def write(p,t): p.write_text(t);p.chmod(0o600);return p

def suite(h,selected,baseline):
    def case(name,fn):
        if selected is None or name==selected:h.case(name,fn)
    def compatibility():
        original=h.config('compat','A',h.runtime/'compat',free_port(),[])
        for v in range(6,19):
            cfg=write(h.work/f'compat-{v}.conf',upgrade(original.read_text(),'compat',v))
            current=h.run(f'check-v{v}',['config-check','--config',str(cfg)])
            h.check(current['format']==f'NATRAV_OVERLAY_CONFIG_V{v}','old format preserved')
            h.check('adapter_configuration' not in current,'no added field in old config output')
            if baseline:
                result=subprocess.run([str(baseline),'config-check','--config',str(cfg)],text=True,capture_output=True,timeout=10,check=True)
                h.check(json.loads(result.stdout)==current,'exact predecessor config-check JSON')
        v=h.run('version',['version'])
        h.check(v.get('adapter_configuration')=='V19_DURABLE_ADAPTER_CONFIGURATION_V1','product marker present')
        h.check(v.get('configured_adapter_transport') is True,'configured adapter capability present')
    case('legacy_compatibility',compatibility)

    def canonical():
        state=h.runtime/'canonical';cfg=h.config('canonical','A',state,free_port(),[])
        p1=profile();p2=profile(generation=2,previous=digest(p1),image='22'*32);e1=endpoint(p1)
        write(cfg,upgrade(cfg.read_text(),'canonical')+records([p2,p1],[e1]))
        check=h.run('v19-canonical',['config-check','--config',str(cfg)]);view=check['adapter_configuration']
        h.check([p['generation'] for p in view['profiles']]==[1,2],'records sorted by id and numeric generation')
        h.check(view['endpoints'][0]['profile_sha256']==digest(p1),'old endpoint never implicitly upgrades')
        h.check(view['configured_transport_enabled'] is True,'capability present; inert policy still does not launch')
        h.check('/not-present/' not in json.dumps(check) and 'literal' not in json.dumps(check),'inspection omits executable path and argv')
        lines=cfg.read_text().splitlines();rev=write(h.work/'reverse.conf',lines[0]+'\n'+'\n'.join(reversed(lines[1:]))+'\n')
        other=h.run('canonical-reorder',['config-check','--config',str(rev)])
        h.check(other['runtime_digest']==check['runtime_digest'],'outer line ordering does not change canonical digest')
        d=h.start('canonical',cfg,state)
        h.check(h.status('canonical-active',state)['runtime_configuration']['generation']=='canonical','missing executable accepted only as inert policy')
        d.shutdown()
    case('canonical_policy_without_implicit_execution',canonical)

    def negatives():
        cfg=h.config('negative','A',h.runtime/'negative',free_port(),[]);base=upgrade(cfg.read_text(),'negative');p=profile();e=endpoint(p)
        variants=[
            ('old-format',base.replace('CONFIG_V19','CONFIG_V18')+records([p],[]),'CONFIG_VERSION_REJECTED'),
            ('odd-hex',base+'adapter_profile_hex=1\n','CONFIG_ADAPTER_RECORD_INVALID'),
            ('uppercase',base+'adapter_profile_hex='+p.encode().hex().upper()+'\n','CONFIG_ADAPTER_RECORD_NONCANONICAL'),
            ('nul',base+'adapter_profile_hex=00\n','CONFIG_ADAPTER_RECORD_NONCANONICAL'),
            ('duplicate-profile',base+records([p,p],[]),'CONFIG_ADAPTER_DUPLICATE_GENERATION'),
            ('duplicate-endpoint',base+records([p],[e,e]),'CONFIG_ADAPTER_DUPLICATE_GENERATION'),
            ('skip-generation',base+records([profile(generation=2)],[]),'ADAPTER_PROFILE_TRANSITION_UNAUTHORIZED'),
            ('missing-profile',base+records([],[e]),'ADAPTER_PROFILE_NOT_FOUND'),
            ('wrong-digest',base+records([p],[e.replace(digest(p),'22'*32)]),'CONFIG_ADAPTER_PROFILE_DIGEST_MISMATCH'),
            ('role-change',base+records([p],[e,endpoint(p,generation=2,previous=digest(e),role='listener')]),'ADAPTER_ENDPOINT_INVALID_TRANSITION'),
            ('record-bound',base+records([p],[endpoint(p,identifier=f'endpoint-{i}') for i in range(65)]),'CONFIG_ADAPTER_CAPACITY')]
        for name,text,code in variants:
            c=write(h.work/(name+'.conf'),text);r=h.run(name,['config-check','--config',str(c)],expected=3)
            h.check(r.get('code')==code,f'{name}: {r}')
    case('canonical_and_bounded_negative_controls',negatives)

    def durability():
        state=h.runtime/'durable';seed=h.config('durable','A',state,free_port(),[])
        write(seed,upgrade(seed.read_text(),'seed',18));d=h.start('durable',seed,state)
        p1=profile();e1=endpoint(p1)
        one=candidate(h,seed,'first-policy','policy-1',lambda t:t.replace('CONFIG_V18','CONFIG_V19')+records([p1],[e1]))
        activate(h,'accept-policy-1',state,one)
        wrong=candidate(h,one,'bad-successor','policy-2',lambda t:t+records([profile(generation=2,previous='33'*32)],[]))
        activate(h,'reject-bad-successor',state,wrong,3,'ADAPTER_PROFILE_TRANSITION_UNAUTHORIZED')
        p2=profile(generation=2,previous=digest(p1),image='22'*32)
        two=candidate(h,one,'good-successor','policy-2',lambda t:t+records([p2],[endpoint(p2,generation=2,previous=digest(e1))]))
        activate(h,'accept-policy-2',state,two)
        rollback(h,'reject-downgrade',state,'seed',3,'CONFIG_ADAPTER_HISTORY_REMOVED')
        rollback(h,'reject-historical-erasure',state,'policy-1',3,'CONFIG_ADAPTER_HISTORY_REMOVED')
        conflict=candidate(h,seed,'redefinition','redefine',lambda t:t.replace('CONFIG_V18','CONFIG_V19')+records([profile(image='44'*32)],[]))
        activate(h,'reject-redefinition',state,conflict,3,'CONFIG_ADAPTER_GENERATION_CONFLICT')
        drop=candidate(h,two,'drop-endpoints','drop',lambda t:'\n'.join(l for l in t.splitlines() if not l.startswith('adapter_endpoint_hex='))+'\n')
        activate(h,'reject-endpoint-removal',state,drop,3,'CONFIG_ADAPTER_HISTORY_REMOVED')
        h.check(h.status('after-rejections',state)['runtime_configuration']['generation']=='policy-2','rejections leave active generation unchanged')
        d.kill();d=h.start('durable-restart',seed,state)
        h.check(h.status('restart-active',state)['runtime_configuration']['generation']=='policy-2','old startup seed cannot roll back journal')
        compact(h,'compact-v19',d.control);d.shutdown();d=h.start('checkpoint-restart',seed,state)
        h.check(h.status('checkpoint-active',state)['runtime_configuration']['generation']=='policy-2','checkpoint preserves V19 policy')
        rollback(h,'checkpoint-erasure',state,'policy-1',3,'CONFIG_ADAPTER_HISTORY_REMOVED')
        d.shutdown();state_json=inspect(h,'offline-v19',state,'A')
        h.check(state_json['runtime_configuration']['generation']=='policy-2','authenticated offline replay preserves V19')
    case('activation_restart_and_checkpoint',durability)

    def authority():
        uid=65534;h.check(os.geteuid()==0 and Path('/usr/bin/setpriv').exists(),'requires real UID switching')
        state=h.runtime/'authority'
        cfg=v8_config(h,'authority','A',state,free_port(),'authority-seed',[(os.geteuid(),CLASSES),(uid,['INSPECT'])])
        write(cfg,upgrade(cfg.read_text(),'authority-seed'));d=h.start('authority',cfg,state);expose_control_for_uid(state)
        proposed=candidate(h,cfg,'proposed-profile','profile',lambda t:t+records([profile()],[]))
        count=h.status('authority-before',state)['runtime_configuration']['event_count']
        denied=run_as_uid(h,'denied-uid',uid,uid,['config-activate','--control',str(d.control),'--candidate',str(proposed),'--reason','denied'],3)
        h.check(denied['code']=='LOCAL_CONTROL_CLASS_DENIED','unprivileged UID cannot use CONFIGURATION')
        h.check(h.status('authority-denied',state)['runtime_configuration']['event_count']==count,'unauthorized candidate does not create config event')
        granted=candidate(h,cfg,'grant-admin','grant-admin',lambda t:t.replace(f'local_control={uid},INSPECT',f'local_control={uid},INSPECT,CONFIGURATION'))
        activate(h,'owner-grants-admin',state,granted)
        proposed=candidate(h,granted,'admin-profile','admin-profile',lambda t:t+records([profile()],[]))
        allowed=run_as_uid(h,'authorized-admin',uid,uid,['config-activate','--control',str(d.control),'--candidate',str(proposed),'--reason','authorized','--deadline-ms','5000'],0)
        h.check(allowed.get('ok') is True,'existing delegated authority accepts exact policy')
        restore_owner_only_control(state);d.shutdown()
    case('real_kernel_uid_authority',authority)

    def pending():
        a,b=h.runtime/'pending-a',h.runtime/'pending-b';bp=free_port()
        ac=h.config('pending-a','A',a,free_port(),[('B',bp,30,60,100,60000)])
        bc=h.config('pending-b','B',b,bp,[],trusted=['A']);write(ac,upgrade(ac.read_text(),'a-v19'))
        ad=h.start('pending-a',ac,a);op=operation('v19-pending')
        submit(h,'queue-pending',ad.control,'A','B','test/three',op,'durable obligation')
        h.check(outbox_entry(h.status('pending-before',a),op)['status']=='PENDING','absent peer leaves pending obligation')
        one=candidate(h,ac,'pending-policy','a-policy',lambda t:t+records([profile()],[]))
        activate(h,'accept-policy-with-pending',a,one);ad.shutdown();ad=h.start('pending-restart',ac,a);bd=h.start('pending-b',bc,b)
        final=wait_state(h,a,op,'ACKED','recover-receipt')
        h.check(final['runtime_configuration']['generation']=='a-policy','pending work recovers under accepted policy')
        h.check(h.status('receiver-once',b)['inbound_records']==1,'exactly one authenticated admission')
        ad.shutdown();bd.shutdown()
    case('pending_work_and_receipt_recovery',pending)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--baseline-binary',type=Path);p.add_argument('--case');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);start=time.monotonic();code=1
    try:
        suite(h,a.case,a.baseline_binary)
        if not h.cases:raise ValueError('unknown case')
        code=0
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {type(e).__name__}: {e}',file=sys.stderr)
    finally:
        h.cleanup();s={'format':'NATRAV_OVERLAY_RUNTIME_ADAPTER_CONFIGURATION_TESTS_V1','status':'PASS' if code==0 else 'FAIL',
            'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'baseline_comparison':a.baseline_binary is not None,
            'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),
            'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.monotonic()-start}
        for n,v in [('SUMMARY',s),('CASES',h.cases),('COMMANDS',h.commands)]: (h.output/(n+'.json')).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
        print(json.dumps(s,sort_keys=True))
    return code
if __name__=='__main__':raise SystemExit(main())
