#!/usr/bin/env python3
"""Offline versioned-state relocation, owner-path provenance, and crash-boundary tests."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
from typing import Any, Callable

from run_persistent import Harness, free_port, operation
from run_live_configuration import v7, wait_state
from run_peer_sessions import submit, outbox_entry
from run_maintenance import inspect


def relocated_config(
    original: Path,
    destination: Path,
    certificate: Path,
    private_key: Path,
    generation: str,
    output: Path,
    modify: Callable[[str], str] = lambda text: text,
) -> Path:
    text = original.read_text()
    old_state = next(line.split("=", 1)[1] for line in text.splitlines()
                     if line.startswith("state="))
    old_cert = next(line.split("=", 1)[1] for line in text.splitlines()
                    if line.startswith("identity_cert="))
    old_key = next(line.split("=", 1)[1] for line in text.splitlines()
                   if line.startswith("identity_key="))
    lines = [line for line in text.splitlines()
             if not line.startswith("runtime_generation=")]
    changed = "\n".join(lines) + "\n"
    changed = changed.replace(f"state={old_state}\n", f"state={destination}\n")
    changed = changed.replace(f"identity_cert={old_cert}\n",
                              f"identity_cert={certificate}\n")
    changed = changed.replace(f"identity_key={old_key}\n",
                              f"identity_key={private_key}\n")
    output.write_text(modify(changed) + f"runtime_generation={generation}\n")
    output.chmod(0o600)
    return output


def copy_identity(source_cert: Path, source_key: Path, destination: Path) -> tuple[Path, Path]:
    destination.mkdir(mode=0o700)
    certificate = destination / "cert.pem"
    private_key = destination / "key.pem"
    shutil.copyfile(source_cert, certificate)
    shutil.copyfile(source_key, private_key)
    certificate.chmod(0o644)
    private_key.chmod(0o600)
    return certificate, private_key


def signed_backup(h: Harness, label: str, state: Path, output: Path,
                  certificate: Path, private_key: Path) -> dict[str, Any]:
    result = h.run(label, [
        "backup-export", "--state", str(state), "--node", "A",
        "--generation", "a-g1", "--output", str(output),
        "--sign-key", str(private_key), "--sign-cert", str(certificate),
    ], timeout=20)
    assert result is not None
    return result


def restore(h: Harness, label: str, backup: Path, destination: Path,
            certificate: Path) -> dict[str, Any]:
    result = h.run(label, [
        "backup-restore", "--input", str(backup), "--destination", str(destination),
        "--node", "A", "--generation", "a-g1",
        "--trusted-cert", str(certificate), "--require-signature", "yes",
    ], timeout=20)
    assert result is not None
    return result


def relocate(h: Harness, label: str, state: Path, candidate: Path,
             expected: int = 0, code: str | None = None) -> dict[str, Any]:
    result = h.run(label, [
        "state-relocate", "--state", str(state), "--node", "A",
        "--candidate", str(candidate), "--reason", label,
    ], expected=expected, timeout=20)
    assert result is not None
    if code is not None:
        h.check(result.get("code") == code, f"{label}: expected {code}, got {result}")
    return result


def wait_attempt(h: Harness, state: Path, op: str) -> None:
    h.wait("outbound attempt recorded", lambda: outbox_entry(
        h.status("relocation-attempt", state), op)["attempts"] >= 1, timeout=8)


def cases(h: Harness, only: str | None) -> None:
    def signed_restore_resume_and_second_backup() -> None:
        old_state = h.runtime / "accept-old-a"
        new_state = h.runtime / "accept-relocated-a"
        b_state = h.runtime / "accept-b"
        a_port, b_port = free_port(), free_port()
        old_config = v7(h.config(
            "accept-old-a", "A", old_state, a_port,
            [("B", b_port, 50, 100, 50, 120000)], deadline_ms=250), "accept-1")
        b_config = v7(h.config(
            "accept-b", "B", b_state, b_port, [], deadline_ms=500,
            trusted=["A"]), "accept-b1")
        a_identity = h.identity("A")
        a = h.start("accept-old-a", old_config, old_state)
        pending = operation("relocation-pending")
        submit(h, "relocation-pending", a.control, "A", "B", "test/three",
               pending, "queued before backup")
        wait_attempt(h, old_state, pending)
        a.shutdown()
        before_export = inspect(h, "relocation-before-export", old_state, "A")
        first_backup = h.work / "relocation-first.nob"
        signed_backup(h, "relocation-first-backup", old_state, first_backup,
                      a_identity.certificate, a_identity.private_key)
        restored = restore(h, "relocation-first-restore", first_backup, new_state,
                           a_identity.certificate)
        restored_inspect = inspect(h, "relocation-restored-before-transition", new_state, "A")
        h.check(restored_inspect["storage"]["logical_state_digest"] ==
                before_export["storage"]["logical_state_digest"],
                "signed restore is logically exact before scheduler restart")
        h.check(restored["logical_state_digest"] ==
                before_export["storage"]["logical_state_digest"],
                "restore result reports the preserved logical digest")

        new_identity_dir = h.work / "relocated-identity-A"
        new_cert, new_key = copy_identity(
            a_identity.certificate, a_identity.private_key, new_identity_dir)
        new_config = relocated_config(
            old_config, new_state, new_cert, new_key, "accept-relocated-2",
            h.work / "accept-relocated.conf")
        moved = relocate(h, "relocation-commit", new_state, new_config)
        h.check(moved["from_generation"] == "accept-1" and
                moved["to_generation"] == "accept-relocated-2",
                "relocation appends a fresh accepted generation")
        h.check(moved["logical_state_before"] != moved["logical_state_after"],
                "attributable relocation provenance changes logical history")
        original_identity_dir = a_identity.certificate.parent
        retired_identity_dir = h.work / "retired-original-identity-A"
        original_identity_dir.rename(retired_identity_dir)

        b = h.start("accept-b", b_config, b_state)
        a = h.start("accept-relocated-a", new_config, new_state)
        wait_state(h, new_state, pending, "ACKED", "relocation-pending-acked")
        h.check(h.status("relocation-B-first-count", b_state)["inbound_records"] == 1,
                "pre-relocation obligation is admitted exactly once")
        new_operation = operation("relocation-new-work")
        submit(h, "relocation-new-work", a.control, "A", "B", "test/three",
               new_operation, "created at relocated owner")
        wait_state(h, new_state, new_operation, "ACKED", "relocation-new-acked")
        h.check(h.status("relocation-B-second-count", b_state)["inbound_records"] == 2,
                "new relocated work is admitted once")
        status = h.status("relocation-live-provenance", new_state)
        events = status["runtime_configuration"]["events"]
        relocation_event = next(event for event in events if event["kind"] == "RELOCATE")
        h.check(relocation_event["relocation"]["new_state"] == str(new_state),
                "live status reconstructs relocated state path")
        h.check(relocation_event["relocation"]["new_private_key"] is None,
                "bounded live status does not disclose private-key path")
        h.run("relocation-compact", ["compact", "--control", str(a.control)], timeout=30)
        a.shutdown()
        a = h.start("accept-relocated-restart", new_config, new_state)
        h.check(h.status("relocation-restart-status", new_state)
                ["runtime_configuration"]["generation"] == "accept-relocated-2",
                "restart uses the durable relocated generation without old identity files")
        a.shutdown()

        offline = inspect(h, "relocation-offline-provenance", new_state, "A")
        offline_event = next(event for event in offline["runtime_configuration"]["events"]
                             if event["kind"] == "RELOCATE")
        h.check(offline_event["relocation"]["old_state"] == str(old_state) and
                offline_event["relocation"]["new_private_key"] == str(new_key),
                "offline inspection reconstructs complete old/new owner-path provenance")
        second_backup = h.work / "relocation-second.nob"
        exported = signed_backup(h, "relocation-second-backup", new_state,
                                 second_backup, new_cert, new_key)
        h.run("relocation-second-verify", [
            "backup-verify", "--input", str(second_backup), "--node", "A",
            "--generation", "a-g1", "--trusted-cert", str(new_cert),
            "--require-signature", "yes",
        ], timeout=20)
        second_restore = h.runtime / "accept-second-restore"
        restore(h, "relocation-second-restore", second_backup, second_restore, new_cert)
        reconstructed = inspect(h, "relocation-second-inspect", second_restore, "A")
        h.check(reconstructed["storage"]["logical_state_digest"] ==
                offline["storage"]["logical_state_digest"] == exported["logical_state_digest"],
                "compacted relocated state survives another signed backup and restore")
        h.check(any(event["kind"] == "RELOCATE" for event in
                    reconstructed["runtime_configuration"]["events"]),
                "second restore retains relocation provenance")
        retired_identity_dir.rename(original_identity_dir)
        b.shutdown()

    def invalid_identity_scope_paths_and_overwrite() -> None:
        old_state = h.runtime / "reject-old"
        restored_state = h.runtime / "reject-restored"
        config = v7(h.config("reject-old", "A", old_state, free_port(), []),
                    "reject-1")
        daemon = h.start("reject-old", config, old_state)
        daemon.shutdown()
        identity = h.identity("A")
        backup = h.work / "reject.nob"
        signed_backup(h, "reject-backup", old_state, backup,
                      identity.certificate, identity.private_key)
        restore(h, "reject-restore", backup, restored_state, identity.certificate)
        correct_dir = h.work / "reject-correct-identity"
        cert, key = copy_identity(identity.certificate, identity.private_key, correct_dir)

        wrong = h.identity("A-wrong-relocation")
        wrong_config = relocated_config(
            config, restored_state, wrong.certificate, wrong.private_key,
            "reject-wrong-key", h.work / "reject-wrong-key.conf",
            lambda text: text.replace(
                f"identity_pin={identity.spki_sha256}",
                f"identity_pin={wrong.spki_sha256}"))
        relocate(h, "relocation-wrong-key", restored_state, wrong_config,
                 3, "RELOCATION_IDENTITY_CHANGED")

        scope_config = relocated_config(
            config, restored_state, cert, key, "reject-scope",
            h.work / "reject-scope.conf",
            lambda text: text + "session_max_operations=7\n")
        relocate(h, "relocation-scope-change", restored_state, scope_config,
                 3, "RELOCATION_SCOPE_CHANGED")

        linked_parent = h.work / "linked-identity"
        linked_parent.symlink_to(correct_dir, target_is_directory=True)
        unsafe_config = relocated_config(
            config, restored_state, linked_parent / "cert.pem",
            linked_parent / "key.pem", "reject-link",
            h.work / "reject-link.conf")
        relocate(h, "relocation-symlink-parent", restored_state, unsafe_config,
                 3, "RELOCATION_PATH_SYMLINK_REJECTED")
        linked_parent.unlink()

        control = restored_state / "control.sock"
        control.write_text("do not replace")
        overwrite_config = relocated_config(
            config, restored_state, cert, key, "reject-overwrite",
            h.work / "reject-overwrite.conf")
        relocate(h, "relocation-control-overwrite", restored_state,
                 overwrite_config, 3, "RELOCATION_CONTROL_EXISTS")
        control.unlink()

        reused_config = relocated_config(
            config, restored_state, cert, key, "reject-1",
            h.work / "reject-reused-generation.conf")
        relocate(h, "relocation-generation-overwrite", restored_state,
                 reused_config, 3, "RELOCATION_GENERATION_EXISTS")
        state = inspect(h, "relocation-rejections-leave-history", restored_state, "A")
        h.check(state["runtime_configuration"]["event_count"] == 1,
                "failed relocation attempts do not mutate accepted history")

    def concurrent_owner_is_rejected() -> None:
        old_state = h.runtime / "busy-old"
        new_state = h.runtime / "busy-new"
        config = v7(h.config("busy-old", "A", old_state, free_port(), []), "busy-1")
        old = h.start("busy-old", config, old_state); old.shutdown()
        ident = h.identity("A"); backup = h.work / "busy.nob"
        signed_backup(h, "busy-backup", old_state, backup,
                      ident.certificate, ident.private_key)
        restore(h, "busy-restore", backup, new_state, ident.certificate)
        new_dir = h.work / "busy-identity"
        cert, key = copy_identity(ident.certificate, ident.private_key, new_dir)
        relocated = relocated_config(config, new_state, cert, key, "busy-2",
                                     h.work / "busy-2.conf")
        relocate(h, "busy-relocate", new_state, relocated)
        running = h.start("busy-running", relocated, new_state)
        again = relocated_config(relocated, new_state, cert, key, "busy-3",
                                 h.work / "busy-3.conf")
        relocate(h, "busy-concurrent-owner", new_state, again, 3, "STATE_BUSY")
        running.shutdown()

    def kill_boundaries() -> None:
        for boundary, committed in (("BEFORE_COMMIT", False), ("AFTER_COMMIT", True)):
            old_state = h.runtime / f"kill-old-{boundary}"
            new_state = h.runtime / f"kill-new-{boundary}"
            config = v7(h.config(f"kill-old-{boundary}", "A", old_state,
                                 free_port(), []), f"kill-{boundary}-1")
            daemon = h.start(f"kill-old-{boundary}", config, old_state)
            daemon.shutdown()
            ident = h.identity("A")
            backup = h.work / f"kill-{boundary}.nob"
            signed_backup(h, f"kill-backup-{boundary}", old_state, backup,
                          ident.certificate, ident.private_key)
            restore(h, f"kill-restore-{boundary}", backup, new_state,
                    ident.certificate)
            identity_dir = h.work / f"kill-identity-{boundary}"
            cert, key = copy_identity(ident.certificate, ident.private_key,
                                      identity_dir)
            candidate = relocated_config(
                config, new_state, cert, key, f"kill-{boundary}-2",
                h.work / f"kill-{boundary}-2.conf")
            marker = f"NATRAV_OVERLAY_TEST_RELOCATION_{boundary}_MS"
            stderr_path = h.logs / f"relocation-kill-{boundary}.stderr.txt"
            stdout_path = h.logs / f"relocation-kill-{boundary}.stdout.txt"
            env = os.environ.copy(); env[marker] = "10000"
            with stdout_path.open("w") as stdout, stderr_path.open("w") as stderr:
                process = subprocess.Popen([
                    str(h.binary), "state-relocate", "--state", str(new_state),
                    "--node", "A", "--candidate", str(candidate),
                    "--reason", f"kill boundary {boundary}",
                ], stdout=stdout, stderr=stderr, text=True, env=env)
                h.wait(f"relocation marker {boundary}",
                       lambda: marker in stderr_path.read_text(), timeout=8)
                process.send_signal(signal.SIGKILL)
                process.wait(timeout=5)
                h.check(process.returncode == -signal.SIGKILL,
                        f"relocation process killed at {boundary}")
            observed = inspect(h, f"relocation-kill-inspect-{boundary}",
                               new_state, "A")
            generation = observed["runtime_configuration"]["generation"]
            if committed:
                h.check(generation == f"kill-{boundary}-2",
                        "post-sync kill retains the relocation event")
                started = h.start(f"relocation-kill-start-{boundary}",
                                  candidate, new_state)
                started.shutdown()
            else:
                h.check(generation == f"kill-{boundary}-1",
                        "precommit kill retains the old accepted owner paths")
                relocate(h, f"relocation-after-kill-{boundary}",
                         new_state, candidate)

    names = [
        ("signed_restore_resume_and_second_backup",
         signed_restore_resume_and_second_backup),
        ("invalid_identity_scope_paths_and_overwrite",
         invalid_identity_scope_paths_and_overwrite),
        ("concurrent_owner_is_rejected", concurrent_owner_is_rejected),
        ("kill_boundaries", kill_boundaries),
    ]
    for name, function in names:
        if only is None or name == only:
            h.case(name, function)
    if only is not None and not any(name == only for name, _ in names):
        raise ValueError("unknown case")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path,
                        default=Path("node/bin/natrav-overlay"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not exist")
    h = Harness(args.binary, args.output)
    started = time.time(); code = 1
    try:
        cases(h, args.case); code = 0
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(
            f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
    finally:
        h.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_STATE_RELOCATION_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "cases_total": len(h.cases),
            "cases_passed": sum(case["status"] == "PASS" for case in h.cases),
            "assertions": h.assertions,
            "commands": len(h.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (("SUMMARY", summary), ("CASES", h.cases),
                            ("COMMANDS", h.commands)):
            (h.output / f"{name}.json").write_text(
                json.dumps(value, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary, sort_keys=True))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
