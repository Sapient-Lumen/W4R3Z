"""Independent structural commitment reconstruction from strict canonical NSS bytes.

Tests only: no runtime import and no persisted index trusted. This decoder covers
NSS1--NSS6, including old states with implicit zero automation/lease fields.
"""
from __future__ import annotations
import hashlib
import re
import struct
from run_source_subscriptions import Reader


def h(domain: str, body: bytes) -> bytes:
    return hashlib.sha256(domain.encode('ascii') + b'\0' + body).digest()


def u64(n: int) -> bytes:
    return struct.pack('!Q', n)


def chain(entries: list[bytes], family: str) -> bytes:
    root = h(f'NATRAV_OVERLAY_SOURCE_PROGRESS_{family}_CHAIN_SEED_V1', b'\0')
    for i, entry in enumerate(entries[:-1]):
        root = h(f'NATRAV_OVERLAY_SOURCE_PROGRESS_{family}_CHAIN_LINK_V1', root + u64(i) + entry)
    return root + bytes([bool(entries)]) + (entries[-1] if entries else b'')


def decode(raw: bytes) -> dict:
    r = Reader(raw)
    version = r.get(4)
    assert version in [f'NSS{i}'.encode() for i in range(1, 7)]
    leased = version in (b'NSS4', b'NSS5', b'NSS6')
    extended = leased or version == b'NSS3'
    grant = r.text(); r.get(8); r.text()
    generation_offset = r.i; r.text(); r.text(); r.get(12)
    if leased: r.text(); r.get(9)
    r.get(64)
    pin_offset = r.i; r.get(32)
    r.get(20); r.text()
    base = raw[4:r.i]
    remote = r.number(1) if extended else int(version == b'NSS2')
    assert remote in (0, 1)
    start = r.i
    if remote:
        r.get(32); r.text(); r.text(); r.get(48); r.text(); r.get(32)
    base += bytes([remote]) + raw[start:r.i]
    revision = r.get(8)
    delivery_count = r.number(4)
    assert delivery_count <= 128
    deliveries = []; delivery_offsets = []
    for _ in range(delivery_count):
        delivery_offsets.append(r.i)
        entry = r.get(156 if extended else 140)
        if not extended: entry += b'\0' * 16
        deliveries.append(h('NATRAV_OVERLAY_SOURCE_PROGRESS_DELIVERY_V1', entry))
    acknowledged = r.get(8); spent = r.get(8)
    retired = r.get(2); assert all(x in (0, 1) for x in retired)
    start = r.i
    r.text(); r.text(); r.get(20)
    request_offset = r.i; r.get(32)
    mutable = raw[start:r.i]
    schedule = r.get(8) if extended else b'\0' * 8
    automatic_count = r.number(4) if extended else 0
    assert automatic_count <= 32
    automatic = []
    for _ in range(automatic_count):
        start = r.i
        r.get(80); r.text(); r.get(24)
        r.text(); r.text(); r.text(); r.get(48)
        automatic.append(h('NATRAV_OVERLAY_SOURCE_PROGRESS_AUTOMATIC_GRANT_V1', raw[start:r.i]))
    lease = r.get(16) if leased else b'\0' * 16
    terminal = r.number(1) if leased else 0
    assert terminal in (0, 1)
    start = r.i
    if terminal:
        r.text(); r.text(); r.get(16); r.text()
        marker = r.number(1); assert marker in (0, 1)
        if marker: r.get(32)
        r.text(); r.text(); r.get(32)
        marker = r.number(1); assert marker in (0, 1)
        if marker: r.get(32)
        r.get(32); r.text()
    terminal_bytes = raw[start:r.i]
    succession = r.number(1) if version == b'NSS6' else int(version == b'NSS5')
    assert succession in (0, 1)
    start = r.i
    if succession: r.text(); r.text(); r.get(144)
    succession_bytes = raw[start:r.i]
    reconciliation = int(version == b'NSS6')
    reconciliation_bytes = r.get(172) if reconciliation else b''
    r.eof()
    base += lease + bytes([terminal]) + terminal_bytes
    base += bytes([succession]) + succession_bytes
    base += bytes([reconciliation]) + reconciliation_bytes + retired
    root_material = h('NATRAV_OVERLAY_SOURCE_PROGRESS_BASE_V1', base)
    root_material += revision + u64(delivery_count) + chain(deliveries, 'DELIVERY')
    root_material += acknowledged + spent + mutable + schedule
    root_material += u64(automatic_count) + chain(automatic, 'AUTOMATIC')
    root = h('NATRAV_OVERLAY_SOURCE_PROGRESS_STATE_V1', root_material)
    return {'grant': grant, 'selector': 'SPSC1:' + root.hex(),
            'state_digest': h('NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_STATE_V1', raw).hex(),
            'version': version.decode(), 'canonical_bytes': len(raw),
            'delivery_offsets': delivery_offsets, 'pin_offset': pin_offset,
            'generation_offset': generation_offset, 'request_offset': request_offset}


def canonical_states(journal: bytes) -> dict[str, dict]:
    result = {}
    # Canonical subscriptions are length-prefixed inside checkpoints/full states.
    # Fixture payloads contain no NSS magic; strict length and EOF validation
    # nevertheless reject incidental substring matches.
    for match in re.finditer(b'NSS[1-6]', journal):
        pos = match.start()
        if pos < 4: continue
        size = int.from_bytes(journal[pos - 4:pos], 'big')
        if not 4 <= size <= 65536 or pos + size > len(journal): continue
        raw = journal[pos:pos+size]
        try: account = decode(raw)
        except (AssertionError, UnicodeError): continue
        result[account['grant']] = {**account, 'offset': pos, 'raw': raw}
    assert result, 'no strict canonical subscription in fixture'
    return result
