#include "packet_port.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <memory>
#include <optional>
#include <poll.h>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/socket.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace {

using natrav_overlay::AppError;
using natrav_overlay::Deadline;
using natrav_overlay::IoCounters;
using natrav_overlay::OwnedCompleteDatagramPacketPort;
using natrav_overlay::PacketPortOrderedStreamOptions;
using natrav_overlay::TransportKind;

struct CaseRecord final {
    std::string name;
    std::size_t assertions{0U};
};

class Probe final {
public:
    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_code(
        Function&& function,
        const std::string_view code,
        const std::string_view detail) {
        bool observed = false;
        try {
            std::forward<Function>(function)();
        } catch (const AppError& error) {
            observed = error.code() == code;
        }
        check(observed, detail);
    }

    template <typename Function>
    void run_case(std::string name, Function&& function) {
        const auto before = assertions_;
        std::forward<Function>(function)();
        cases_.push_back(CaseRecord{
            .name = std::move(name),
            .assertions = assertions_ - before,
        });
    }

    [[nodiscard]] std::size_t assertions() const noexcept { return assertions_; }
    [[nodiscard]] const std::vector<CaseRecord>& cases() const noexcept {
        return cases_;
    }

private:
    std::size_t assertions_{0U};
    std::vector<CaseRecord> cases_{};
};

[[nodiscard]] int poll_timeout_ms(const Deadline deadline) {
    const auto now = std::chrono::steady_clock::now();
    if (now >= deadline) {
        return 0;
    }
    const auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(
        deadline - now);
    const auto count = std::max<std::chrono::milliseconds::rep>(
        remaining.count(), 1);
    return static_cast<int>(std::min<std::chrono::milliseconds::rep>(
        count, static_cast<std::chrono::milliseconds::rep>(INT_MAX)));
}

class UnixDatagramFixturePort final : public OwnedCompleteDatagramPacketPort {
public:
    UnixDatagramFixturePort(
        const int fd,
        const std::size_t mtu,
        std::shared_ptr<std::atomic<std::size_t>> destructions) noexcept
        : fd_(fd), mtu_(mtu), destructions_(std::move(destructions)) {}

    ~UnixDatagramFixturePort() override {
        if (fd_ >= 0) {
            static_cast<void>(::close(fd_));
        }
        if (destructions_) {
            destructions_->fetch_add(1U, std::memory_order_relaxed);
        }
    }

    [[nodiscard]] TransportKind transport_kind() const noexcept override {
        return TransportKind::packet_link;
    }

    [[nodiscard]] std::size_t mtu() const noexcept override { return mtu_; }

    [[nodiscard]] bool send_packet(
        const natrav::packet_link::Bytes& packet) override {
        if (fd_ < 0 || packet.empty() || packet.size() > mtu_) {
            natrav_overlay::app_fail(
                "FIXTURE_PACKET_INVALID", "fixture outbound datagram is invalid");
        }
        while (true) {
            const auto count = ::send(
                fd_, packet.data(), packet.size(), MSG_DONTWAIT | MSG_NOSIGNAL);
            if (count >= 0) {
                if (static_cast<std::size_t>(count) != packet.size()) {
                    natrav_overlay::app_fail(
                        "FIXTURE_SEND_FAILED", "fixture datagram send was partial");
                }
                write_blocked_ = false;
                return true;
            }
            if (errno == EINTR) {
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                write_blocked_ = true;
                return false;
            }
            natrav_overlay::app_fail(
                "FIXTURE_SEND_FAILED", std::strerror(errno));
        }
    }

    [[nodiscard]] std::optional<natrav::packet_link::Bytes>
    receive_packet() override {
        natrav::packet_link::Bytes packet(mtu_);
        iovec vector{
            .iov_base = packet.data(),
            .iov_len = packet.size(),
        };
        msghdr message{};
        message.msg_iov = &vector;
        message.msg_iovlen = 1U;
        while (true) {
            message.msg_flags = 0;
            const auto count = ::recvmsg(fd_, &message, MSG_DONTWAIT | MSG_TRUNC);
            if (count >= 0) {
                if ((message.msg_flags & MSG_TRUNC) != 0 ||
                    static_cast<std::size_t>(count) > mtu_) {
                    natrav_overlay::app_fail(
                        "FIXTURE_DATAGRAM_TRUNCATED",
                        "fixture datagram exceeded its receive MTU");
                }
                packet.resize(static_cast<std::size_t>(count));
                return packet;
            }
            if (errno == EINTR) {
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                return std::nullopt;
            }
            natrav_overlay::app_fail(
                "FIXTURE_RECEIVE_FAILED", std::strerror(errno));
        }
    }

    void wait_for_progress(
        const Deadline wake_deadline,
        const Deadline operation_deadline,
        IoCounters& counters,
        const std::string_view operation) override {
        if (std::chrono::steady_clock::now() >= operation_deadline) {
            natrav_overlay::app_fail("IO_TIMEOUT", operation);
        }
        pollfd item{
            .fd = fd_,
            .events = static_cast<short>(POLLIN | (write_blocked_ ? POLLOUT : 0)),
            .revents = 0,
        };
        ++counters.poll_calls;
        int result = 0;
        do {
            result = ::poll(&item, 1U, poll_timeout_ms(wake_deadline));
            if (result < 0 && errno == EINTR) {
                ++counters.interrupted;
            }
        } while (result < 0 && errno == EINTR);
        if (result < 0) {
            natrav_overlay::app_fail("FIXTURE_POLL_FAILED", std::strerror(errno));
        }
        if (result == 0) {
            ++counters.would_block;
            if (std::chrono::steady_clock::now() >= operation_deadline) {
                natrav_overlay::app_fail("IO_TIMEOUT", operation);
            }
            return;
        }
        if ((item.revents & POLLNVAL) != 0) {
            natrav_overlay::app_fail("FIXTURE_SOCKET_INVALID", operation);
        }
        if ((item.revents & POLLOUT) != 0) {
            write_blocked_ = false;
        }
        if ((item.revents & (POLLERR | POLLHUP)) != 0 &&
            (item.revents & POLLIN) == 0) {
            natrav_overlay::app_fail("PEER_RESET", operation);
        }
    }

private:
    int fd_{-1};
    std::size_t mtu_{0U};
    std::shared_ptr<std::atomic<std::size_t>> destructions_{};
    bool write_blocked_{false};
};

struct PortPair final {
    std::unique_ptr<OwnedCompleteDatagramPacketPort> first;
    std::unique_ptr<OwnedCompleteDatagramPacketPort> second;
    std::shared_ptr<std::atomic<std::size_t>> destructions;
};

[[nodiscard]] PortPair make_port_pair(
    const std::size_t first_mtu = 256U,
    const std::size_t second_mtu = 256U) {
    std::array<int, 2U> descriptors{-1, -1};
    if (::socketpair(
            AF_UNIX,
            SOCK_DGRAM | SOCK_CLOEXEC | SOCK_NONBLOCK,
            0,
            descriptors.data()) != 0) {
        throw std::runtime_error(std::string("socketpair: ") + std::strerror(errno));
    }
    auto destructions = std::make_shared<std::atomic<std::size_t>>(0U);
    return PortPair{
        .first = std::make_unique<UnixDatagramFixturePort>(
            descriptors[0U], first_mtu, destructions),
        .second = std::make_unique<UnixDatagramFixturePort>(
            descriptors[1U], second_mtu, destructions),
        .destructions = std::move(destructions),
    };
}

[[nodiscard]] PacketPortOrderedStreamOptions stream_options(
    const std::size_t mtu = 256U,
    const std::uint32_t epoch = 11U,
    const bool bind_epoch = false) {
    PacketPortOrderedStreamOptions options;
    options.limits.mtu = mtu;
    options.limits.max_message_bytes = 64U * 1024U;
    options.limits.max_reassembly_bytes = 256U * 1024U;
    options.limits.max_delivery_bytes = 256U * 1024U;
    options.limits.max_inflight_frames = 128U;
    options.limits.max_control_frames = 128U;
    options.limits.max_receive_packets_per_pump = 256U;
    options.limits.retransmit_after_ticks = 3U;
    options.limits.retry_limit = 12U;
    options.limits.message_expiry_ticks = 512U;
    options.stream_id = 0x504f52545345414dULL;
    options.epoch = epoch;
    options.bind_epoch_from_first_packet = bind_epoch;
    options.tick_interval = std::chrono::milliseconds(1);
    options.shutdown_budget = std::chrono::seconds(2);
    options.invalid_stream_code = "FIXTURE_STREAM_INVALID";
    options.logical_clock_invalid_code = "FIXTURE_CLOCK_INVALID";
    options.logical_clock_exhausted_code = "FIXTURE_CLOCK_EXHAUSTED";
    options.shutdown_operation = "fixture packet-port shutdown";
    return options;
}

void write_all(
    natrav_overlay::OrderedByteStream& stream,
    const std::span<const std::uint8_t> bytes,
    const Deadline deadline,
    IoCounters& counters) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto progress = stream.write_some(
            datacube::OctetView(bytes.data() + offset, bytes.size() - offset),
            deadline,
            counters,
            "fixture packet-port write");
        if (progress == 0U || progress > bytes.size() - offset) {
            throw std::runtime_error("invalid fixture packet-port write progress");
        }
        offset += progress;
    }
}

[[nodiscard]] std::vector<std::uint8_t> read_exact(
    natrav_overlay::OrderedByteStream& stream,
    const std::size_t size,
    const Deadline deadline,
    IoCounters& counters) {
    std::vector<std::uint8_t> result(size);
    std::size_t offset = 0U;
    while (offset < result.size()) {
        const auto progress = stream.read_some(
            std::span<std::uint8_t>(result).subspan(offset),
            deadline,
            counters,
            "fixture packet-port read");
        if (progress == 0U || progress > result.size() - offset) {
            throw std::runtime_error("fixture packet-port read ended early");
        }
        offset += progress;
    }
    return result;
}

}  // namespace

int main() {
    Probe probe;
    try {
        probe.run_case("marker and ownership contract", [&] {
            probe.check(
                std::string_view(natrav_overlay::kOwnedCompleteDatagramPacketPortMarker) ==
                    "OWNED_COMPLETE_DATAGRAM_PACKET_PORT_V1",
                "packet-port marker is exact");
            probe.check(
                natrav_overlay::owned_complete_datagram_packet_port_revision_abi() == 1,
                "packet-port ABI anchor is one");
        });

        probe.run_case("fragmented full-duplex ordered transfer", [&] {
            auto ports = make_port_pair();
            const auto destructions = ports.destructions;
            auto first = natrav_overlay::make_packet_port_ordered_byte_stream(
                std::move(ports.first), stream_options());
            auto second = natrav_overlay::make_packet_port_ordered_byte_stream(
                std::move(ports.second), stream_options());
            probe.check(first->transport_kind() == TransportKind::packet_link,
                        "first stream preserves the concrete port kind");
            probe.check(second->transport_kind() == TransportKind::packet_link,
                        "second stream preserves the concrete port kind");

            std::vector<std::uint8_t> forward(4'097U);
            for (std::size_t index = 0U; index < forward.size(); ++index) {
                forward[index] = static_cast<std::uint8_t>((index * 29U) & 0xffU);
            }
            const std::vector<std::uint8_t> reverse{
                'r', 'e', 'v', 'e', 'r', 's', 'e', '-', 'p', 'a', 't', 'h'};
            IoCounters first_counters;
            IoCounters second_counters;
            const auto deadline = std::chrono::steady_clock::now() +
                std::chrono::seconds(4);
            write_all(*first, forward, deadline, first_counters);
            const auto received_forward = read_exact(
                *second, forward.size(), deadline, second_counters);
            write_all(*second, reverse, deadline, second_counters);
            const auto received_reverse = read_exact(
                *first, reverse.size(), deadline, first_counters);
            probe.check(received_forward == forward,
                        "fragmented forward bytes are exact and ordered");
            probe.check(received_reverse == reverse,
                        "reverse bytes are exact and ordered");
            probe.check(first_counters.write_calls != 0U &&
                            first_counters.read_calls != 0U &&
                            second_counters.write_calls != 0U &&
                            second_counters.read_calls != 0U,
                        "both streams account for read and write progress");
            first.reset();
            second.reset();
            probe.check(destructions->load(std::memory_order_relaxed) == 2U,
                        "ordered streams release both owned packet ports");
        });

        probe.run_case("listener epoch binding and stale epoch rejection", [&] {
            auto ports = make_port_pair();
            auto* first_port = ports.first.get();
            auto first = natrav_overlay::make_packet_port_ordered_byte_stream(
                std::move(ports.first), stream_options(256U, 0x10203040U));
            auto second = natrav_overlay::make_packet_port_ordered_byte_stream(
                std::move(ports.second), stream_options(256U, 0U, true));
            IoCounters first_counters;
            IoCounters second_counters;
            const auto deadline = std::chrono::steady_clock::now() +
                std::chrono::seconds(4);
            const std::array<std::uint8_t, 5U> first_payload{
                'b', 'i', 'n', 'd', '1'};
            write_all(*first, first_payload, deadline, first_counters);
            const auto first_received = read_exact(
                *second, first_payload.size(), deadline, second_counters);
            probe.check(std::equal(first_received.begin(), first_received.end(),
                                   first_payload.begin()),
                        "listener binds to the connector's first valid epoch");

            natrav::packet_link::Frame stale{};
            stale.kind = natrav::packet_link::FrameKind::data;
            stale.stream_id = 0x504f52545345414dULL;
            stale.epoch = 0x1020303fU;
            stale.sequence = 700U;
            stale.message_id = 700U;
            stale.fragment_count = 1U;
            stale.payload = {'s', 't', 'a', 'l', 'e'};
            probe.check(first_port->send_packet(
                            natrav::packet_link::FrameCodec::encode(stale)),
                        "stale-epoch frame enters the carrier for rejection");

            const std::array<std::uint8_t, 5U> second_payload{
                'b', 'i', 'n', 'd', '2'};
            write_all(*first, second_payload, deadline, first_counters);
            const auto second_received = read_exact(
                *second, second_payload.size(), deadline, second_counters);
            probe.check(std::equal(second_received.begin(), second_received.end(),
                                   second_payload.begin()),
                        "bound listener ignores a different stale epoch");
        });

        probe.run_case("semantic finish and write closure", [&] {
            auto ports = make_port_pair();
            auto first = natrav_overlay::make_packet_port_ordered_byte_stream(
                std::move(ports.first), stream_options());
            auto second = natrav_overlay::make_packet_port_ordered_byte_stream(
                std::move(ports.second), stream_options());
            IoCounters first_counters;
            IoCounters second_counters;
            const std::array<std::uint8_t, 5U> payload{'c', 'l', 'o', 's', 'e'};
            const auto deadline = std::chrono::steady_clock::now() +
                std::chrono::seconds(4);
            write_all(*first, payload, deadline, first_counters);
            first->shutdown_write();
            const auto received = read_exact(
                *second, payload.size(), deadline, second_counters);
            probe.check(std::equal(received.begin(), received.end(), payload.begin()),
                        "payload preceding semantic finish is retained");
            std::array<std::uint8_t, 1U> eof{};
            const auto progress = second->read_some(
                eof, deadline, second_counters, "fixture waits for semantic EOF");
            probe.check(progress == 0U, "remote semantic finish becomes ordered EOF");
            probe.expect_code(
                [&] {
                    static_cast<void>(first->write_some(
                        datacube::OctetView(payload.data(), payload.size()),
                        deadline,
                        first_counters,
                        "write after packet-port finish"));
                },
                "SOCKET_WRITE_CLOSED",
                "writes after semantic finish are rejected");
        });

        probe.run_case("absolute deadline", [&] {
            auto ports = make_port_pair();
            auto first = natrav_overlay::make_packet_port_ordered_byte_stream(
                std::move(ports.first), stream_options());
            auto second = natrav_overlay::make_packet_port_ordered_byte_stream(
                std::move(ports.second), stream_options());
            static_cast<void>(second);
            IoCounters counters;
            std::array<std::uint8_t, 1U> byte{};
            const auto begin = std::chrono::steady_clock::now();
            probe.expect_code(
                [&] {
                    static_cast<void>(first->read_some(
                        byte,
                        begin + std::chrono::milliseconds(20),
                        counters,
                        "fixture absolute deadline"));
                },
                "IO_TIMEOUT",
                "idle packet-port read respects the caller deadline");
            const auto elapsed = std::chrono::steady_clock::now() - begin;
            probe.check(elapsed < std::chrono::seconds(1),
                        "deadline timeout remains bounded in wall-clock time");
            probe.check(counters.poll_calls != 0U && counters.would_block != 0U,
                        "deadline path records bounded carrier waits");
        });

        probe.run_case("MTU contract mismatch", [&] {
            auto ports = make_port_pair(512U, 256U);
            probe.expect_code(
                [&] {
                    auto invalid = natrav_overlay::make_packet_port_ordered_byte_stream(
                        std::move(ports.first), stream_options(256U));
                    static_cast<void>(invalid);
                },
                "FIXTURE_STREAM_INVALID",
                "port and finite-profile MTUs must match exactly");
            ports.second.reset();
            probe.check(
                ports.destructions->load(std::memory_order_relaxed) == 2U,
                "failed stream construction releases all fixture descriptors");
        });

        std::cout << "{\"format\":\"NATRAV_PACKET_PORT_PROBE_V1\","
                  << "\"status\":\"PASS\",\"cases\":" << probe.cases().size()
                  << ",\"assertions\":" << probe.assertions() << ",\"case_records\":[";
        for (std::size_t index = 0U; index < probe.cases().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            const auto& record = probe.cases()[index];
            std::cout << "{\"name\":\"" << record.name << "\",\"assertions\":"
                      << record.assertions << '}';
        }
        std::cout << "]}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cout << "{\"format\":\"NATRAV_PACKET_PORT_PROBE_V1\","
                  << "\"status\":\"FAIL\",\"assertions\":" << probe.assertions()
                  << ",\"detail\":\"" << error.what() << "\"}\n";
        return 1;
    }
}
