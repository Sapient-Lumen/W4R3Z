#!/usr/bin/env python3
"""Bounded live peer membership: real C++ nodes, staged workers and durable recovery."""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from typing import Any

from run_persistent import Harness, free_port, operation
from run_peer_sessions import submit, outbox_entry
from run_maintenance import inspect
from run_live_configuration import v7, candidate, activate, rollback, wait_state, peers


def peer_text(h: Harness, node: str, port: int | None) -> str:
    pin = h.identity(node).spki_sha256
    route = f"peer={node},127.0.0.1:{port},40,100,500,120000\n" if port is not None else ""
    return (route + f"peer_key={node},{node.lower()}-g1,ACTIVE,{pin}\n"
            + f"authorize={node},*,EVIDENCE,test/three\n")


def without_peer(text: str, node: str) -> str:
    return "\n".join(line for line in text.splitlines()
                     if not any(line.startswith(prefix + node + ",")
                                for prefix in ("peer=", "peer_key=", "authorize="))) + "\n"


def registry(status: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {entry["node"]: entry for entry in status["peer_registry"]["entries"]}


def complete_registry(h: Harness, label: str, state: Path) -> dict[str, dict[str, Any]]:
    # Runtime status is a bounded preview, not an exhaustive registry promise.
    rows = []; offset = 0; selected = None
    while True:
        args = ["runtime-inventory", "--control", str(state / "control.sock"),
                "--section", "peers", "--offset", str(offset), "--limit", "16"]
        if selected is not None: args += ["--selection", selected]
        result = h.run(label + "-" + str(offset), args)
        rows.extend(result["rows"]); selected = result["selection_digest"]
        if not result["has_more"]: break
        offset = result["next_offset"]
    h.check(len(rows) == result["total"], "complete explicitly selected historical membership")
    return {row["node"]: row for row in rows}


def process_resources(pid: int) -> tuple[int, int]:
    return len(list(Path(f"/proc/{pid}/task").iterdir())), len(list(Path(f"/proc/{pid}/fd").iterdir()))


def activation_process(h: Harness, state: Path, cfg: Path) -> subprocess.Popen[str]:
    return subprocess.Popen([str(h.binary), "config-activate", "--control", str(state / "control.sock"),
                             "--candidate", str(cfg), "--reason", "registry test boundary",
                             "--deadline-ms", "30000"], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, env=os.environ.copy())


def collect(h: Harness, label: str, process: subprocess.Popen[str], expected: int | None) -> None:
    out, err = process.communicate(timeout=15)
    h.commands.append({"label": label, "args": process.args[1:], "returncode": process.returncode,
                       "stdout": out, "stderr": err})
    if expected is not None:
        h.check(process.returncode == expected, f"{label}: {out!r} {err!r}")
    else:
        h.check(process.returncode != 0, label + ": killed connection must not claim success")


def cases(h: Harness, only: str | None) -> None:
    def fourth_peer_sessions_and_recovery() -> None:
        a, b, c, d = (h.runtime / n for n in ("grow-a", "grow-b", "grow-c", "grow-d"))
        bp, cp, dp = free_port(), free_port(), free_port()
        ac = v7(h.config("grow-a", "A", a, free_port(),
                       [("B", bp, 40, 100, 500, 120000), ("C", cp, 40, 100, 500, 120000)]), "grow-1")
        bc = v7(h.config("grow-b", "B", b, bp, [], trusted=["A"]), "b-1")
        cc = v7(h.config("grow-c", "C", c, cp, [], trusted=["A"]), "c-1")
        dc = v7(h.config("grow-d", "D", d, dp, [], trusted=["A"]), "d-1")
        for cfg in (ac, bc, cc, dc):
            cfg.write_text(cfg.read_text() + "session_idle_timeout_ms=10000\n")
        bd = h.start("grow-b", bc, b); cd = h.start("grow-c", cc, c); ad = h.start("grow-a", ac, a)
        for node in ("B", "C"):
            op = operation("grow-warm-" + node)
            submit(h, "grow-warm-" + node, ad.control, "A", node, "test/three", op, "warm")
            wait_state(h, a, op, "ACKED", "grow-warm-ack-" + node)
        old = peers(h.status("grow-original", a))
        dd = h.start("grow-later-d", dc, d)
        added = candidate(h, ac, "grow-added", "grow-2", lambda t: t + peer_text(h, "D", dp))
        activate(h, "grow-add-D", a, added)
        for node in ("C", "D"):
            op = operation("grow-new-" + node)
            submit(h, "grow-new-" + node, ad.control, "A", node, "test/three", op, "after addition")
            now = wait_state(h, a, op, "ACKED", "grow-new-ack-" + node)
        h.check(set(registry(now)) == {"B", "C", "D"}, "genuinely new D is published exactly once")
        h.check(peers(now)["C"]["session"]["opened"] == old["C"]["session"]["opened"], "C session survives addition")
        h.check(peers(now)["C"]["opened_configuration_event"] == 1, "C keeps original opening event")
        h.check(h.status("grow-D-once", d)["inbound_records"] == 1, "new compiled D admits once")
        # Deliberate endpoint outage. Its 10s idle session outlives the generic
        # harness's 5s graceful-stop wait; use an actual crash for this scenario.
        dd.kill()
        owed = operation("grow-owed")
        submit(h, "grow-owed", ad.control, "A", "D", "test/three", owed, "preserve on removal")
        h.wait("D has a durable attempt", lambda: outbox_entry(h.status("grow-attempt", a), owed)["attempts"] >= 1)
        removed = candidate(h, added, "grow-removed", "grow-3", lambda t: without_peer(t, "D"))
        activate(h, "grow-remove-D", a, removed)
        removed_status = h.status("grow-removed-status", a)
        h.check(registry(removed_status)["D"]["role"] == "HISTORICAL", "removed identity retains a historical slot")
        h.check(removed_status["outbox"]["unresolved"] == 1, "pending obligation remains unresolved")
        tries = outbox_entry(removed_status, owed)["attempts"]
        time.sleep(.15)
        h.check(outbox_entry(h.status("grow-not-attempted", a), owed)["attempts"] == tries, "removed route consumes no attempts")
        h.run("grow-compact", ["compact", "--control", str(ad.control)])
        before_backup = h.status("grow-compacted", a)
        ad.kill(); ad = h.start("grow-restart-seed", ac, a)
        recovered = h.status("grow-recovered", a)
        h.check(recovered["runtime_configuration"]["generation"] == "grow-3", "seed cannot undo accepted removal")
        h.check(set(registry(recovered)) == {"B", "C", "D"}, "historical union reconstructs after compacted restart")
        ad.shutdown()
        ident = h.identity("A"); backup = h.work / "registry.nob"
        h.run("grow-backup", ["backup-export", "--state", str(a), "--node", "A", "--generation", "a-g1",
                             "--output", str(backup), "--sign-key", str(ident.private_key), "--sign-cert", str(ident.certificate)])
        h.run("grow-verify", ["backup-verify", "--input", str(backup), "--node", "A", "--generation", "a-g1",
                             "--trusted-cert", str(ident.certificate), "--require-signature", "yes"])
        a.rename(h.runtime / "grow-original")
        h.run("grow-restore", ["backup-restore", "--input", str(backup), "--destination", str(a), "--node", "A",
                              "--generation", "a-g1", "--trusted-cert", str(ident.certificate), "--require-signature", "yes"])
        saved = inspect(h, "grow-restored-inspect", a, "A")
        h.check(saved["storage"]["logical_state_digest"] == before_backup["storage"]["logical_state_digest"],
                "signed restore preserves obligations and full accepted membership history")
        ad = h.start("grow-restored-daemon", ac, a)
        dd = h.start("grow-D-return", dc, d)
        rollback(h, "grow-restore-route", a, "grow-2")
        wait_state(h, a, owed, "ACKED", "grow-complete-obligation")
        h.check(h.status("grow-D-records", d)["inbound_records"] == 2, "restored route finishes without duplicate admission")
        rollback(h, "grow-pre-D-rollback", a, "grow-1")
        h.check(registry(h.status("grow-historical-D", a))["D"]["role"] == "HISTORICAL", "rollback cannot forget accepted membership")
        ad.shutdown(); bd.shutdown(); cd.shutdown(); dd.shutdown()
        bindings = inspect(h, "grow-final-offline", a, "A")["runtime_configuration"]["bindings"]
        h.check(any(x["operation_id"] == owed and x["journal_kind"] == 24 and x["configuration_event"] == 2 for x in bindings),
                "old D obligation retains its original admission generation")

    def preparation_failure_cleanup() -> None:
        a = h.runtime / "failure-a"
        ac = v7(h.config("failure-a", "A", a, free_port(), []), "fail-1")
        ad = h.start("failure-a", ac, a, {"NATRAV_OVERLAY_TEST_REGISTRY_FAIL_PEER": "E"})
        assert ad.process is not None
        h.status("failure-warm-status", a); time.sleep(.05)
        baseline = process_resources(ad.process.pid)
        cfg = candidate(h, ac, "failure-candidate", "fail-2", lambda t: t + peer_text(h, "D", None) + peer_text(h, "E", None))
        for index in range(3):
            activate(h, f"failure-repeated-{index}", a, cfg, 3, "CONFIG_PEER_PREPARATION_FAILED")
            st = h.status(f"failure-unchanged-{index}", a)
            h.check(st["peer_registry"]["registered"] == 0 and st["runtime_configuration"]["generation"] == "fail-1",
                    "partially prepared D/E does not publish membership or generation")
            h.wait("no leaked staged thread or descriptor", lambda: process_resources(ad.process.pid) == baseline)
        # A fully prepared D worker must also be reclaimed on later validation failure.
        conflict = candidate(h, ac, "failure-late-check", "fail-1", lambda t: t + peer_text(h, "D", None))
        activate(h, "failure-after-preparation", a, conflict, 3, "CONFIG_GENERATION_CONFLICT")
        h.wait("late-validation cleanup", lambda: process_resources(ad.process.pid) == baseline)
        successful = candidate(h, ac, "failure-recover", "fail-3", lambda t: t + peer_text(h, "F", None))
        activate(h, "failure-independent-addition", a, successful)
        st = h.status("failure-recovered-service", a)
        h.check(set(registry(st)) == {"F"}, "failed candidates consume no registry capacity")
        ad.shutdown()
        ad = h.start("failure-restart-without-hook", ac, a)
        activate(h, "failure-retry-preparation", a, cfg)
        h.check(set(registry(h.status("failure-full-union", a))) == {"D", "E", "F"}, "same rejected generation can later be prepared and accepted")
        ad.shutdown()

    def historical_capacity_boundary() -> None:
        a = h.runtime / "capacity-a"
        ac = v7(h.config("capacity-a", "A", a, free_port(), []), "cap-1")
        # Synthetic pins exercise membership capacity only; no claim of 63 TLS peers.
        dormant = "".join(f"peer_key=P{i:02},g1,ACTIVE,{hashlib.sha256(('capacity-'+str(i)).encode()).hexdigest()}\n" for i in range(63))
        ac.write_text(ac.read_text() + dormant)
        ad = h.start("capacity-a", ac, a)
        added = candidate(h, ac, "capacity-64", "cap-2", lambda t: t + peer_text(h, "D", None))
        activate(h, "capacity-exact-64", a, added)
        st = h.status("capacity-full", a)
        h.check(st["peer_registry"]["registered"] == 64 and st["peer_registry"]["remaining"] == 0,
                "exact historical capacity is accepted")
        over = candidate(h, added, "capacity-65", "cap-3", lambda t: t + peer_text(h, "E", None))
        activate(h, "capacity-65-refused", a, over, 3, "CONFIG_TOO_MANY_TRUSTED_PEERS")
        rollback(h, "capacity-remove-D-by-rollback", a, "cap-1")
        replacement = candidate(h, ac, "capacity-replacement", "cap-4", lambda t: t + peer_text(h, "E", None))
        activate(h, "capacity-history-not-reusable", a, replacement, 3, "CONFIG_PEER_REGISTRY_LIMIT")
        st = h.status("capacity-historical", a)
        full_registry = complete_registry(h, "capacity-inventory", a)
        h.check(full_registry["D"]["role"] == "HISTORICAL" and len(full_registry) == 64,
                "removal does not recycle identity slots")
        ad.kill(); ad = h.start("capacity-restart", ac, a)
        h.check(len(complete_registry(h, "capacity-restored", a)) == 64, "accepted historical union bounds restart too")
        activate(h, "capacity-after-restart", a, replacement, 3, "CONFIG_PEER_REGISTRY_LIMIT")
        ad.shutdown()

    def prepared_visibility_and_concurrent_submissions() -> None:
        a, c, d = (h.runtime / n for n in ("race-a", "race-c", "race-d")); cp, dp = free_port(), free_port()
        ac = v7(h.config("registry-race-a", "A", a, free_port(), [("C", cp, 40, 100, 500, 120000)]), "race-1")
        cc = v7(h.config("registry-race-c", "C", c, cp, [], trusted=["A"]), "c-1")
        dc = v7(h.config("registry-race-d", "D", d, dp, [], trusted=["A"]), "d-1")
        for p in (ac, cc, dc): p.write_text(p.read_text() + "session_idle_timeout_ms=10000\n")
        cd = h.start("registry-race-c", cc, c); dd = h.start("registry-race-d", dc, d)
        ad = h.start("registry-race-a", ac, a, {"NATRAV_OVERLAY_TEST_REGISTRY_AFTER_PREPARE_MS": "1800"})
        warm = operation("registry-race-warm")
        submit(h, "registry-race-warm", ad.control, "A", "C", "test/three", warm, "warm")
        old = wait_state(h, a, warm, "ACKED", "registry-race-warm-ack")
        cfg = candidate(h, ac, "registry-race-add", "race-2", lambda t: t + peer_text(h, "D", dp))
        process = activation_process(h, a, cfg)
        try:
            h.wait("prepared worker parked", lambda: "NATRAV_OVERLAY_TEST_REGISTRY_AFTER_PREPARE_MS" in ad.stderr_path.read_text())
            staged = h.status("registry-race-staged", a)
            h.check(set(registry(staged)) == {"C"} and staged["runtime_configuration"]["generation"] == "race-1",
                    "prepared D invisible before accepted publication")
            rejected = h.run("registry-race-early-D", ["submit", "--control", str(ad.control), "--node", "A", "--peer", "D",
                        "--scope", "test/three", "--operation", operation("too-early-D"), "--payload-text", "not yet"], expected=3)
            h.check(rejected is not None and rejected["code"] == "PEER_NOT_CONFIGURED", "unpublished peer cannot receive local admission")
            def send(index: int) -> dict[str, Any]:
                args = ["submit", "--control", str(ad.control), "--node", "A", "--peer", "C", "--scope", "test/three",
                        "--operation", operation(f"registry-race-{index}"), "--payload-text", str(index), "--deadline-ms", "5000"]
                done = subprocess.run([str(h.binary), *args], capture_output=True, text=True, timeout=8, env=os.environ.copy())
                return {"label": f"registry-concurrent-{index}", "args": args, "returncode": done.returncode,
                        "stdout": done.stdout, "stderr": done.stderr}
            with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
                results = list(pool.map(send, range(16)))
            h.commands.extend(results)
            h.check(all(x["returncode"] == 0 for x in results), "old peer accepts 16 concurrent submissions during registry preparation")
            collect(h, "registry-race-publication", process, 0)
            new = operation("registry-race-D")
            submit(h, "registry-race-new-D", ad.control, "A", "D", "test/three", new, "published")
            final = wait_state(h, a, new, "ACKED", "registry-race-new-ack")
            h.wait("C concurrent work acknowledged", lambda: h.status("registry-race-drained", a)["outbox"]["acked"] == 18)
            h.check(peers(final)["C"]["session"]["opened"] == peers(old)["C"]["session"]["opened"], "C retains session during staged creation")
            h.check(h.status("registry-race-C-records", c)["inbound_records"] == 17, "concurrent C work admitted exactly once")
            h.check(h.status("registry-race-D-records", d)["inbound_records"] == 1, "new D work admitted exactly once")
        finally:
            if process.poll() is None: process.kill(); process.wait()
        ad.shutdown(); cd.shutdown(); dd.shutdown()
        stamps = inspect(h, "registry-race-bindings", a, "A")["runtime_configuration"]["bindings"]
        h.check(any(x["journal_kind"] == 24 and x["operation_id"] == new and x["configuration_event"] == 2 for x in stamps),
                "new peer submission binds accepted membership generation")

    def staged_and_durable_kill_boundaries() -> None:
        for stage in ("BEFORE_COMMIT", "AFTER_DURABLE"):
            a, d = h.runtime / ("kill-a-" + stage), h.runtime / ("kill-d-" + stage); dp = free_port()
            ac = v7(h.config("registry-kill-a-" + stage, "A", a, free_port(), []), "kill-1")
            dc = v7(h.config("registry-kill-d-" + stage, "D", d, dp, [], trusted=["A"]), "d-1")
            cfg = candidate(h, ac, "registry-kill-next-" + stage, "kill-2", lambda t: t + peer_text(h, "D", dp))
            marker = "NATRAV_OVERLAY_TEST_REGISTRY_" + stage + "_MS"
            ad = h.start("registry-kill-" + stage, ac, a, {marker: "10000"})
            process = activation_process(h, a, cfg)
            try:
                h.wait("registry kill marker " + stage, lambda: marker in ad.stderr_path.read_text(), 8)
                ad.kill(); collect(h, "registry-killed-activation-" + stage, process, None)
            finally:
                if process.poll() is None: process.kill(); process.wait()
            dd = h.start("registry-kill-D-" + stage, dc, d)
            ad = h.start("registry-restart-" + stage, ac, a)
            st = h.status("registry-kill-reconstruct-" + stage, a)
            if stage == "BEFORE_COMMIT":
                h.check(st["runtime_configuration"]["generation"] == "kill-1" and len(registry(st)) == 0,
                        "precommit kill leaves no accepted membership")
                activate(h, "registry-after-precommit-kill", a, cfg)
            else:
                h.check(st["runtime_configuration"]["generation"] == "kill-2" and set(registry(st)) == {"D"},
                        "journal commit reconstructs D even before in-memory publication")
            op = operation("registry-kill-delivery-" + stage)
            submit(h, "registry-kill-delivery-" + stage, ad.control, "A", "D", "test/three", op, "after restart")
            wait_state(h, a, op, "ACKED", "registry-kill-ack-" + stage)
            h.check(h.status("registry-kill-D-count-" + stage, d)["inbound_records"] == 1, "reconstructed worker is functional")
            ad.shutdown(); dd.shutdown()

    def inbound_only_promotion_and_revocation() -> None:
        a, d = h.runtime / "inbound-a", h.runtime / "inbound-d"; ap, dp = free_port(), free_port()
        ac = v7(h.config("registry-inbound-a", "A", a, ap, []), "inbound-1")
        dc = v7(h.config("registry-inbound-d", "D", d, dp, [("A", ap, 40, 100, 500, 120000)]), "d-1")
        ad = h.start("registry-inbound-a", ac, a); dd = h.start("registry-inbound-d", dc, d)
        incoming = candidate(h, ac, "registry-inbound-add", "inbound-2", lambda t: t + peer_text(h, "D", None))
        activate(h, "registry-inbound-add", a, incoming)
        st = h.status("registry-inbound-role", a)
        h.check(registry(st)["D"]["role"] == "INBOUND_ONLY", "new inbound identity is registered without a route")
        op = operation("registry-inbound-evidence")
        submit(h, "registry-inbound-evidence", dd.control, "D", "A", "test/three", op, "authenticated new inbound peer")
        wait_state(h, d, op, "ACKED", "registry-inbound-ack")
        h.check(h.status("registry-inbound-count", a)["inbound_records"] == 1, "new key and authorization work on native receiver")
        promoted = candidate(h, incoming, "registry-promoted", "inbound-3", lambda t: t + f"peer=D,127.0.0.1:{dp},40,100,500,120000\n")
        activate(h, "registry-promote-route", a, promoted)
        h.check(h.status("registry-promote-size", a)["peer_registry"]["registered"] == 1, "promotion reuses the stable identity slot")
        reverse = operation("registry-promoted-delivery")
        submit(h, "registry-promoted-delivery", ad.control, "A", "D", "test/three", reverse, "two directions")
        wait_state(h, a, reverse, "ACKED", "registry-promoted-ack")
        revoked = candidate(h, incoming, "registry-revoked", "inbound-4", lambda t: t.replace("peer_key=D,d-g1,ACTIVE,", "peer_key=D,d-g1,REVOKED,").replace("authorize=D,*,EVIDENCE,test/three\n", ""))
        activate(h, "registry-revoke-new-peer", a, revoked)
        rollback(h, "registry-revocation-monotonic", a, "inbound-2", 3, "CONFIG_REVOCATION_ROLLBACK")
        absent = candidate(h, ac, "registry-absent", "inbound-5")
        activate(h, "registry-remove-key", a, absent)
        altered = candidate(h, ac, "registry-reassign", "inbound-6", lambda t: t + peer_text(h, "D", None).replace(h.identity("D").spki_sha256, h.identity("E").spki_sha256))
        activate(h, "registry-history-key-immutable", a, altered, 3, "CONFIG_HISTORICAL_KEY_CONFLICT")
        ad.kill(); ad = h.start("registry-inbound-restart", ac, a)
        h.check(registry(h.status("registry-inbound-history", a))["D"]["role"] == "HISTORICAL", "removed inbound peer remains in accepted union after restart")
        ad.shutdown(); dd.shutdown()

    names = [("fourth_peer_sessions_and_recovery", fourth_peer_sessions_and_recovery),
             ("preparation_failure_cleanup", preparation_failure_cleanup),
             ("historical_capacity_boundary", historical_capacity_boundary),
             ("prepared_visibility_and_concurrent_submissions", prepared_visibility_and_concurrent_submissions),
             ("staged_and_durable_kill_boundaries", staged_and_durable_kill_boundaries),
             ("inbound_only_promotion_and_revocation", inbound_only_promotion_and_revocation)]
    for name, function in names:
        if only is None or name == only: h.case(name, function)
    if only and not any(name == only for name, _ in names): raise ValueError("unknown case")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, default=Path("node/bin/natrav-overlay"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case")
    args = parser.parse_args()
    if args.output.exists(): parser.error("output must not exist")
    h = Harness(args.binary, args.output); started = time.time(); code = 1
    try:
        cases(h, args.case); code = 0
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
    finally:
        h.cleanup()
        summary = {"format": "NATRAV_OVERLAY_PEER_REGISTRY_TESTS_V1", "status": "PASS" if code == 0 else "FAIL",
                   "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(), "cases_total": len(h.cases),
                   "cases_passed": sum(c["status"] == "PASS" for c in h.cases), "assertions": h.assertions,
                   "commands": len(h.commands), "elapsed_seconds": time.time() - started}
        for name, value in (("SUMMARY", summary), ("CASES", h.cases), ("COMMANDS", h.commands)):
            (h.output / (name + ".json")).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary, sort_keys=True))
    return code


if __name__ == "__main__": raise SystemExit(main())
