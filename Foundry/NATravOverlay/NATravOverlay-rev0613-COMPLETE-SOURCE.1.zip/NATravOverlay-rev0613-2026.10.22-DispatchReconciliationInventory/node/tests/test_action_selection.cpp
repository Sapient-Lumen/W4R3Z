#include "action_selection.hpp"

#include <algorithm>
#include <cstdint>
#include <iostream>
#include <limits>
#include <map>
#include <optional>
#include <random>
#include <stdexcept>
#include <vector>

using namespace natrav_overlay;

namespace {
std::uint64_t checks = 0U;
void check(const bool value, const char* message) {
    ++checks;
    if (!value) {
        throw std::runtime_error(message);
    }
}
}

int main() {
    try {
        ActionSelectionIndex index;
        constexpr std::size_t delayed = 65'536U;
        for (std::size_t i = 0U; i < delayed; ++i) {
            index.touch(i, ActionSelectionIndexEntry{
                .not_before_unix_ms = 10'000U + static_cast<std::uint64_t>(i),
                .expires_unix_ms = 1'000'000U + static_cast<std::uint64_t>(i),
            });
        }
        index.touch(delayed, ActionSelectionIndexEntry{
            .not_before_unix_ms = 1U,
            .expires_unix_ms = 2'000'000U,
        });
        auto choice = index.select(1U);
        check(choice.kind == ActionSelectionKind::ready,
            "ready action behind delayed entries selected");
        check(choice.index == delayed,
            "deep ready action selected by stable queue position");
        check(choice.tree_nodes_visited <= 40U,
            "deep ready selection remains logarithmic");
        check(index.pending() == delayed + 1U && index.valid(),
            "large action index remains valid");
        const auto delayed_seek_nodes = choice.tree_nodes_visited;

        // An earlier ready operation wins over a later expired operation; an
        // earlier expired operation wins over a later ready operation.
        ActionSelectionIndex ordering;
        ordering.touch(0U, ActionSelectionIndexEntry{.not_before_unix_ms=1U,.expires_unix_ms=100U});
        ordering.touch(1U, ActionSelectionIndexEntry{.not_before_unix_ms=1U,.expires_unix_ms=1U});
        choice = ordering.select(1U);
        check(choice.kind == ActionSelectionKind::ready && choice.index == 0U,
            "queue order preserves earlier ready work before later expiry");
        ordering.touch(0U, ActionSelectionIndexEntry{.not_before_unix_ms=100U,.expires_unix_ms=1U});
        choice = ordering.select(1U);
        check(choice.kind == ActionSelectionKind::expired && choice.index == 0U,
            "earlier expired work selected before later ready work");

        // Differential randomized updates against a simple ordered reference.
        constexpr std::size_t records = 8'192U;
        ActionSelectionIndex random_index;
        std::vector<std::optional<ActionSelectionIndexEntry>> reference(records);
        std::mt19937_64 rng(0x0541A11CEULL);
        std::uint64_t maximum_nodes = 0U;
        std::uint64_t revisions_observed = 0U;
        for (std::size_t iteration = 0U; iteration < 50'000U; ++iteration) {
            const auto slot = static_cast<std::size_t>(rng() % records);
            if (iteration % 5U == 0U) {
                reference[slot].reset();
            } else {
                const auto ready = rng() % 100'000U;
                const auto expires = rng() % 100'000U;
                reference[slot] = ActionSelectionIndexEntry{
                    .not_before_unix_ms = ready,
                    .expires_unix_ms = expires,
                };
            }
            random_index.touch(slot, reference[slot]);
            const auto revision = random_index.revision(slot);
            check(revision != 0U && revision > revisions_observed,
                "each touched action receives a monotonic revision");
            revisions_observed = revision;

            const auto now = rng() % 100'000U;
            std::optional<std::size_t> expected_expired;
            std::optional<std::size_t> expected_ready;
            std::optional<std::uint64_t> expected_wake;
            std::size_t expected_pending = 0U;
            for (std::size_t i = 0U; i < records; ++i) {
                if (!reference[i].has_value()) {
                    continue;
                }
                ++expected_pending;
                const auto& entry = *reference[i];
                if (!expected_wake.has_value() ||
                    entry.not_before_unix_ms < *expected_wake) {
                    expected_wake = entry.not_before_unix_ms;
                }
                if (entry.expires_unix_ms < *expected_wake) {
                    expected_wake = entry.expires_unix_ms;
                }
                if (!expected_expired.has_value() &&
                    entry.expires_unix_ms <= now) {
                    expected_expired = i;
                }
                if (!expected_ready.has_value() &&
                    entry.not_before_unix_ms <= now) {
                    expected_ready = i;
                }
            }
            ActionSelectionKind expected_kind = ActionSelectionKind::none;
            std::optional<std::size_t> expected_index;
            if (expected_expired.has_value() &&
                (!expected_ready.has_value() ||
                 *expected_expired <= *expected_ready)) {
                expected_kind = ActionSelectionKind::expired;
                expected_index = expected_expired;
            } else if (expected_ready.has_value()) {
                expected_kind = ActionSelectionKind::ready;
                expected_index = expected_ready;
            }
            const auto got = random_index.select(now);
            check(got.kind == expected_kind && got.index == expected_index,
                "randomized action selection matches ordered reference");
            check(got.next_wake_unix_ms == expected_wake,
                "randomized next wake matches reference");
            check(random_index.pending() == expected_pending,
                "pending cardinality matches reference");
            check(got.tree_nodes_visited <= 64U,
                "bounded tree search under randomized mutation");
            maximum_nodes = std::max(maximum_nodes, got.tree_nodes_visited);
            if (iteration % 101U == 0U) {
                check(random_index.valid(),
                    "action index invariants survive randomized mutation");
            }
        }

        ActionSelectionIndex edge;
        edge.touch(7U, ActionSelectionIndexEntry{
            .not_before_unix_ms = std::numeric_limits<std::uint64_t>::max(),
            .expires_unix_ms = std::numeric_limits<std::uint64_t>::max(),
        });
        choice = edge.select(0U);
        check(choice.kind == ActionSelectionKind::none &&
              choice.next_wake_unix_ms == std::numeric_limits<std::uint64_t>::max(),
            "maximum timestamp stays delayed");
        choice = edge.select(std::numeric_limits<std::uint64_t>::max());
        check(choice.kind == ActionSelectionKind::expired && choice.index == 7U,
            "expiry wins at the exact shared boundary");
        edge.touch(7U, std::nullopt);
        check(edge.pending() == 0U && edge.valid(),
            "terminal removal clears both action trees");

        std::cout << "{\"status\":\"PASS\",\"checks\":" << checks
                  << ",\"large_delayed_records\":" << delayed
                  << ",\"random_mutations\":50000"
                  << ",\"delayed_head_seek_nodes\":" << delayed_seek_nodes
                  << ",\"maximum_seek_nodes\":" << maximum_nodes << "}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
