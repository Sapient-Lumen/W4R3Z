#!/usr/bin/env python3
"""Finite recipient automation: real configured C++ peers, durable replay and faults."""
from __future__ import annotations
import argparse,concurrent.futures,hashlib,json,os,struct,subprocess,time
from pathlib import Path
from run_persistent import Harness,operation,raw_control
from run_subscribed_source_views import setup,emit,materialize,SCOPE,TARGET,fields
from run_source_subscriptions import command,ack
from run_local_evidence import author
from run_scoped_reads import query
from run_local_administration import run_as_uid,expose_control_for_uid
from run_live_configuration import candidate,activate
from run_state_authentication import new_key,migrate,start as start_keyed,inspect,checksum_frame


def auto(h,label,c,kind='status',previous=None,view='temps',imports=16,decisions=64,interval=10,uid=None,expected=0,revision=None):
    args=['source-view-auto-'+kind,'--control',str(c/'control.sock'),'--view',view,'--deadline-ms','5000']
    if kind!='status':
        args+=['--expected-revision',str(revision if revision is not None else previous['revision']),'--reason','explicit bounded recipient import']
    if kind=='enable':args+=['--max-imports',str(imports),'--max-decisions',str(decisions),'--minimum-interval-ms',str(interval)]
    return h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)

def until(h,label,c,test,**kw):
    result={}
    def probe():
        nonlocal result
        result=auto(h,label,c,**kw);return test(result)
    h.wait(label,probe,8);return result

def allrows(h,label,c,scope=TARGET):return fields(query(h,label,c,issuer='A',scope=scope,view='history',payload='yes',payload_length=46))

def run_cases(h,selected):
    def case(name,fn):
        if selected is None or name in selected:h.case(name,fn)

    def basic():
        a,c,ac,cc,ad,cd,s=setup(h,'finite')
        first,s,row=emit(h,'first',a,c,s,ticks=100)
        status=auto(h,'never',c);h.check(status['state']=='NEVER_ENABLED' and len(allrows(h,'empty',c))==0,'incoming envelope grants no automatic authority')
        h.check(auto(h,'wrong-revision',c,'enable',previous=status,revision=999,expected=3)['code']=='IMPORT_AUTO_REVISION_CONFLICT','exact revision required')
        enabled=auto(h,'enable',c,'enable',previous=status,imports=3)
        until(h,'one-import',c,lambda v:v['imports']==1)
        second,s,row2=emit(h,'second',a,c,s,ticks=25)
        correction,s,row3=emit(h,'correction',a,c,s,ticks=150,parent=first['operation_id'])
        final=until(h,'exhausted',c,lambda v:v['state']=='EXHAUSTED')
        h.check(final['imports']==3 and final['decisions']==3 and final['next_position']==3,'successful allowance and progress coupled')
        history=allrows(h,'three-history',c);current=fields(query(h,'two-heads',c,issuer='A',scope=TARGET,payload='yes',payload_length=46))
        h.check(len(history)==3 and len(current)==2,'originals remain plural and correction replaces only its parent')
        h.check(all(x['subscribed_source']['execution_actor']=='DAEMON_IMPORT_WORKER' and 'local_authorship' not in x for x in history),'distinct worker provenance, no local authorship')
        from run_numeric_projection import call,consume
        created=call(h,'numeric-create',c,'create','automatic',definition='NUMERIC_SUMMARY_V1',issuer='A',scope=TARGET,unit='degC',scale=2,reason='explicit numeric projection')
        numeric,_=consume(h,'numeric-process',c,{r['operation_id']:bytes.fromhex(r['payload_hex']) for r in history},name='automatic')
        h.check(numeric['consumer']['projection']['result']['numeric']['sum_ticks']=='175','numeric projection consumes actual imported original bytes')
        oldbytes=(c/'state.journal').stat().st_size;time.sleep(.6);auto(h,'exhausted-idle',c)
        h.check((c/'state.journal').stat().st_size==oldbytes,'stopped polls append nothing')
        cd.shutdown();cd=h.start('finite-restart',cc,c)
        h.check(auto(h,'restart-exhausted',c)['imports']==3,'restart does not replenish')
        h.run('finite-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown();cd=h.start('finite-checkpoint',cc,c)
        h.check(auto(h,'compacted',c)['history_digest']==final['history_digest'],'checkpoint replays exact decision history')
        fresh=auto(h,'enable-new',c,'enable',previous=auto(h,'old-grant',c),imports=1)
        more,s,r=emit(h,'fourth',a,c,s,ticks=5);later=until(h,'second-exhausted',c,lambda v:v['state']=='EXHAUSTED')
        h.check(later['generation']==2 and later['next_position']==4 and later['imports']==1,'new grant retains prior scan frontier')
        (h.output/'NUMERIC.json').write_text(json.dumps({'first_grant':final,'history':history,'numeric':numeric,'second_grant':later},indent=2)+'\n')
        cd.shutdown();ad.shutdown()
    case('opt_in_finite_numeric_corrections_restart_checkpoint',basic)

    def rejects():
        a,c,ac,cc,ad,cd,s=setup(h,'rejects')
        # Peer-authenticated garbage is ordinary evidence, but not source material.
        bad=operation('bad-import-envelope')
        h.run('bad-submit',['submit','--control',str(a/'control.sock'),'--node','A','--peer','C','--scope',SCOPE,'--operation',bad,'--payload-text','not an NSE envelope'])
        h.wait('bad outer delivered',lambda:any(e['operation_id']==bad and e['status']=='ACKED' for e in h.status('bad-outbox',a)['outbox']['entries']))
        first,s,row=emit(h,'valid-after-bad',a,c,s,ticks=7)
        materialize(h,'manual-first',c,row)
        before=auto(h,'before-rejects',c);auto(h,'enable-rejects',c,'enable',previous=before,imports=2,decisions=2)
        stopped=until(h,'inspection-exhausted',c,lambda x:x['state']=='EXHAUSTED')
        h.check(stopped['imports']==0 and stopped['decisions']==2 and stopped['next_position']==2,'malformed and duplicate consume decisions not import allowance')
        h.check(len(allrows(h,'not-multiplied',c))==1,'duplicate and malformed cannot create records')
        cd.shutdown();offline=h.run('reject-offline',['inspect','--state',str(c),'--node','C'])
        h.check(offline['import_automation'][0]['decisions']==2,'decisions survive ordinary journal replay')
        cd=h.start('reject-restart',cc,c);auto(h,'new-reject-grant',c,'enable',previous=stopped,imports=1,decisions=8)
        src,s,row=emit(h,'later-valid',a,c,s,ticks=8);until(h,'valid-progress',c,lambda x:x['imports']==1)
        h.check(len(allrows(h,'still-two',c))==2,'later valid source progresses past malformed record')
        cd.shutdown();ad.shutdown()
    case('malformed_duplicate_inspection_allowance_and_continuation',rejects)

    def dependencies():
        a,c,ac,cc,ad,cd,s=setup(h,'parents')
        cfg=candidate(h,ac,'g2-provider','g2-provider-v1',lambda t:t+f'source_disclosure=g2,{os.geteuid()},{os.geteuid()},C,c-g1,{SCOPE},128,1000000\n');activate(h,'accept-g2',a,cfg)
        sub=command(h,'create-g2',a,'create',grant='g2')
        parent=author(h,'g2-parent',a,ticks=10)
        issue=command(h,'g2-issue-parent',a,'step',grant='g2',previous=sub);sub=ack(h,'g2-ack-parent',a,issue,grant='g2');parent_outer=issue['latest']['operation_id']
        auto(h,'start-without-g2-pin',c,'enable',previous=auto(h,'initial-parents',c),imports=8,decisions=16)
        skipped=until(h,'g2-not-approved',c,lambda x:x['next_position']==1)
        h.check(skipped['imports']==0 and skipped['last_decision']['outcome']=='SOURCE_VIEW_SUBSCRIPTION_DENIED','unapproved source is attributable skip, not imported')
        paused=auto(h,'pause-adoption',c,'pause',previous=skipped)
        nextcfg=candidate(h,cc,'g2-view','g2-view-v1',lambda t:t+f'source_view_binding=temps,g2,{sub["instance"]},{sub["grant_digest"]},-\n');activate(h,'accept-g2-view',c,nextcfg)
        auto(h,'enable-exact-new-pins',c,'enable',previous=paused,imports=4,decisions=16)
        child=author(h,'g2-child',a,ticks=30,parent=parent['operation_id']);issue=command(h,'g2-child-issue',a,'step',grant='g2',previous=sub);sub=ack(h,'g2-child-ack',a,issue,grant='g2')
        waiting=until(h,'parent-deferred',c,lambda x:len(x['deferred'])==1)
        independent=author(h,'g2-independent',a,ticks=5);issue=command(h,'independent-issue',a,'step',grant='g2',previous=sub);sub=ack(h,'independent-ack',a,issue,grant='g2')
        until(h,'independent-continues',c,lambda x:x['imports']==1)
        stable=auto(h,'still-deferred',c);time.sleep(.6);h.check(auto(h,'no-retry-spam',c)['revision']==stable['revision'],'unresolved dependency does not busy-retry or journal poll')
        materialize(h,'explicit-parent-import',c,parent_outer)
        completed=until(h,'deferred-retried',c,lambda x:x['imports']==2 and not x['deferred'])
        h.check(len(allrows(h,'parent-history',c))==3,'explicit parent unlocks deferred correction without losing independent progress')
        h.run('dependency-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown();cd=h.start('dependency-replay',nextcfg,c)
        h.check(auto(h,'dependency-reconstructed',c)['history_digest']==completed['history_digest'],'historical missing-parent decision is replayed at original prefix, not present state')
        cd.shutdown();ad.shutdown()
    case('deferred_parent_independent_progress_and_historical_replay',dependencies)

    def wrong_parent():
        from run_source_subscriptions import decode_envelope
        from run_integration import encode_record,record_digest
        from run_live_configuration import wait_state
        a,c,ac,cc,ad,cd,s=setup(h,'parent-binding')
        src,s,r1=emit(h,'mapping-first',a,c,s,ticks=10)
        second,s,r2=emit(h,'mapping-other',a,c,s,ticks=20)
        auto(h,'mapping-enable',c,'enable',previous=auto(h,'mapping-before',c),imports=4)
        until(h,'mapping-imported-parents',c,lambda v:v['imports']==2)
        e=decode_envelope(bytes.fromhex(r1['payload_hex']))
        source=encode_record(operation('inconsistent-source-child'),'A','A',SCOPE,bytes.fromhex(e['payload_hex']),src['operation_id'])
        def text(v):b=v.encode();return struct.pack('!H',len(b))+b
        raw=b'NSE1'+text(e['grant'])+bytes.fromhex(e['instance'])+bytes.fromhex(e['grant_digest'])+text(e['recipient'])+text(e['generation'])+bytes.fromhex(e['spki'])+struct.pack('!QIQ',3,e['author_uid'],e['authored_unix_ms'])+record_digest(source)+b'\x01'+bytes.fromhex(r2['operation_id'])+struct.pack('!I',len(source))+source
        op=hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_DELIVERY_V1\0'+raw).hexdigest();f=h.work/'mismapped.nse';f.write_bytes(raw)
        h.run('deliver-inconsistent-parent',['revise','--control',str(a/'control.sock'),'--node','A','--peer','C','--scope',SCOPE,'--operation',op,'--corrects',r2['operation_id'],'--payload-file',str(f)])
        wait_state(h,a,op,'ACKED','mapping-outer-admitted')
        skipped=until(h,'invalid-mapping-skipped',c,lambda v:v['next_position']==3)
        h.check(skipped['imports']==2 and not skipped['deferred'] and skipped['last_decision']['outcome']=='SOURCE_VIEW_PARENT_BINDING_REJECTED','existing mismatched parent is not a missing dependency or fatal worker error')
        third,s,r3=emit(h,'mapping-next-valid',a,c,s,ticks=30);until(h,'mapping-keeps-working',c,lambda v:v['imports']==3)
        h.check(len(allrows(h,'mapping-unchanged-target',c))==3,'invalid parent never mutates target; later valid work continues')
        h.run('mapping-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown();cd=h.start('mapping-replay',cc,c)
        h.check(auto(h,'mapping-final',c)['imports']==3,'skip classification survives checkpoint replay')
        cd.shutdown();ad.shutdown()
    case('wrong_parent_mapping_is_rejected_not_deferred_or_fatal',wrong_parent)

    def uid_revoke():
        a,c,ac,cc,ad,cd,s=setup(h,'uid',delegates=True);expose_control_for_uid(c)
        first,s,row=emit(h,'uid-first',a,c,s,ticks=12)
        old=auto(h,'delegated-state',c,view='delegated',uid=65534)
        auto(h,'other-cannot-enable',c,'enable',previous=old,view='delegated',uid=65533,expected=3)
        auto(h,'delegated-enable',c,'enable',previous=old,view='delegated',uid=65534)
        until(h,'delegated-import',c,lambda x:x['imports']==1,view='delegated',uid=65534)
        # Removal of the view and class is valid; accepted history reserves identity.
        def revoke(t):return '\n'.join(l for l in t.splitlines() if not l.startswith(('local_control=65534,','source_view=delegated,','source_view_binding=delegated,')))+'\n'
        removed=candidate(h,cc,'uid-revoked','uid-revoked-g1',revoke);activate(h,'remove-import-policy',c,removed)
        time.sleep(.7);cd.shutdown();offline=h.run('uid-revoked-offline',['inspect','--state',str(c),'--node','C'])
        schedule=next(x for x in offline['import_automation'] if x['view']=='delegated');h.check(schedule['state']=='BLOCKED','revocation commits blocked grant')
        proofs=[x['subscribed_source'] for x in offline['inbound']['history'] if x.get('subscribed_source')]
        h.check(proofs[0]['import_uid']==65534 and proofs[0]['executor_uid']==os.geteuid() and proofs[0]['execution_actor']=='DAEMON_IMPORT_WORKER','delegating real UID distinct from actual daemon executor')
        cd=h.start('uid-revoked-restart',removed,c)
        restored=candidate(h,cc,'uid-restored','uid-restored-g1',lambda t:t);activate(h,'restore-import-policy',c,restored);expose_control_for_uid(c)
        h.check(auto(h,'restored-still-blocked',c,view='delegated',uid=65534)['state']=='BLOCKED','policy restoration does not silently resume')
        cd.shutdown();ad.shutdown()
    case('real_uid_delegation_live_revocation_no_automatic_resume',uid_revoke)

    def kills():
        for point in ('BEFORE','AFTER'):
            a,c,ac,cc,ad,cd,s=setup(h,'kill-'+point.lower());first,s,row=emit(h,'kill-source-'+point,a,c,s,ticks=9)
            # Configure while quiesced? Enable is disallowed in quiescence. Start
            # empty schedule then use worker-only fault boundaries after enable.
            cd.shutdown();cd=h.start('kill-'+point+'-daemon',cc,c,{f'NATRAV_OVERLAY_TEST_IMPORT_AUTO_{point}_COMMIT_MS':'1500'})
            logfile=h.output/('kill-'+point+'.txt');base=(c/'state.journal').stat().st_size
            args=['source-view-auto-enable','--control',str(c/'control.sock'),'--view','temps','--expected-revision','0','--reason','kill grant commit','--max-imports','1','--max-decisions','8','--minimum-interval-ms','10','--deadline-ms','5000']
            with logfile.open('w') as f:
                p=subprocess.Popen([str(h.binary),*args],stdout=f,stderr=f)
                if point=='AFTER':
                    # Wait for kind34, not merely the separate authorization event.
                    def committed():
                        data=(c/'state.journal').read_bytes();at=0
                        while at+40<=len(data):
                            n=int.from_bytes(data[at+4:at+8],'big')
                            if at+40+n>len(data):return False
                            if data[at+8]==34:return True
                            at+=40+n
                        return False
                    h.wait('automation commit visible',committed,5)
                else:time.sleep(.3)
                cd.kill();p.wait(timeout=10)
            cd=h.start('kill-recovered-'+point,cc,c)
            state=auto(h,'kill-state-'+point,c)
            if point=='BEFORE':h.check(state['state']=='NEVER_ENABLED','killed before commit does not create grant');auto(h,'kill-enable-retry',c,'enable',previous=state,imports=1)
            final=until(h,'kill-completed-'+point,c,lambda x:x['state']=='EXHAUSTED')
            h.check(final['imports']==1 and len(allrows(h,'kill-exactly-one-'+point,c))==1,'grant and eventual import reconstruct without duplicate')
            cd.shutdown();ad.shutdown()
    case('grant_commit_kills_and_safe_restart',kills)

    def import_kills():
        for point in ('BEFORE','AFTER'):
            a,c,ac,cc,ad,cd,s=setup(h,'effect-'+point.lower());src,s,row=emit(h,'effect-source-'+point,a,c,s,ticks=99)
            cd.shutdown();cd=h.start('effect-hook-'+point,cc,c,{f'NATRAV_OVERLAY_TEST_IMPORT_STEP_{point}_COMMIT_MS':'1500'})
            # ENABLE itself is unpaused; only the actual import transition stops.
            enabled=auto(h,'effect-enable-'+point,c,'enable',previous={'revision':0},imports=1)
            if point=='AFTER':
                def committed():
                    data=(c/'state.journal').read_bytes();at=0
                    while at+40<=len(data):
                        n=int.from_bytes(data[at+4:at+8],'big')
                        if at+n+40>len(data):return False
                        if data[at+8]==34 and b'IMPORTED' in data[at+9:at+n+8]:return True
                        at+=n+40
                    return False
                h.wait('import and allowance synchronized',committed,5)
            else:time.sleep(.3)
            cd.kill()
            state=h.run('effect-offline-'+point,['inspect','--state',str(c),'--node','C'])
            record_count=sum(bool(x.get('subscribed_source')) for x in state['inbound']['history']);schedule=state['import_automation'][0]
            h.check(record_count==schedule['imports']==(1 if point=='AFTER' else 0),'actual import and spent allowance share kill boundary')
            cd=h.start('effect-restart-'+point,cc,c);final=until(h,'effect-completes-'+point,c,lambda v:v['state']=='EXHAUSTED')
            h.check(final['imports']==1 and len(allrows(h,'effect-no-duplicates-'+point,c))==1,'interrupted import recovery never duplicates')
            cd.shutdown();ad.shutdown()
    case('actual_import_commit_kills_couple_effect_and_allowance',import_kills)

    def fairness_limits():
        a,c,ac,cc,ad,cd,s=setup(h,'fairness',delegates=True,records=1)
        expose_control_for_uid(c)
        auto(h,'limited-enable',c,'enable',previous=auto(h,'limited-status',c),imports=8)
        auto(h,'healthy-enable',c,'enable',previous=auto(h,'healthy-status',c,view='delegated',uid=65534),view='delegated',uid=65534,imports=3)
        for i in range(3):src,s,row=emit(h,'fair-source-'+str(i),a,c,s,ticks=i+1)
        limited=until(h,'one-view-blocked',c,lambda v:v['state']=='BLOCKED')
        healthy=until(h,'other-view-progress',c,lambda v:v['state']=='EXHAUSTED',view='delegated',uid=65534)
        h.check(limited['imports']==1 and limited['error']=='SOURCE_VIEW_RECORD_LIMIT' and limited['next_position']==1,'full view retains unprocessed candidate')
        h.check(healthy['imports']==3,'blocked view cannot prevent another owner view from progressing')
        revision=limited['revision'];time.sleep(.6);h.check(auto(h,'blocked-stable',c)['revision']==revision,'blocked polls do not flood journal')
        cd.shutdown();state=h.run('fairness-offline',['inspect','--state',str(c),'--node','C'])
        h.check(len([x for x in state['inbound']['history'] if x.get('subscribed_source')])==4,'exact four imports across independent budgets')
        (h.output/'FAIRNESS.json').write_text(json.dumps({'limited':limited,'healthy':healthy},indent=2)+'\n');ad.shutdown()

        a,c,ac,cc,ad,cd,s=setup(h,'grants')
        state=auto(h,'grants-initial',c)
        for i in range(32):
            state=auto(h,f'grant-{i}',c,'enable',previous=state,imports=1,decisions=1)
            state=auto(h,f'pause-{i}',c,'pause',previous=state)
        h.check(state['generation']==32 and state['next_position']==0,'32 finite grants do not invent source progress')
        h.check(auto(h,'grant-33',c,'enable',previous=state,expected=3)['code']=='IMPORT_AUTO_GRANT_LIMIT','generation history ceiling enforced')
        h.check(auto(h,'stale-pause',c,'pause',previous={'revision':0},expected=3)['code']=='IMPORT_AUTO_REVISION_CONFLICT','stale command cannot retarget current grant')
        raw=b'NOC1\x16NIR1\x03'+struct.pack('!H',5)+b'temps'
        ok,r=raw_control(c/'control.sock',raw);h.check(ok and r['generation']==32,'independent strict local wire')
        for wire in (raw+b'x',raw[:-1],raw.replace(b'NIR1',b'NIR2')):
            ok,r=raw_control(c/'control.sock',wire);h.check(not ok,'strict version/EOF enforcement')
        cd.shutdown();ad.shutdown()
    case('fair_view_service_record_limit_and_grant_history_bounds',fairness_limits)

    def replay():
        a,c,ac,cc,ad,cd,s=setup(h,'replay');src,s,row=emit(h,'replay-source',a,c,s,ticks=77)
        auto(h,'replay-enable',c,'enable',previous=auto(h,'replay-before',c),imports=1)
        final=until(h,'replay-exhausted',c,lambda v:v['state']=='EXHAUSTED');cd.shutdown()
        original=(c/'state.journal').read_bytes();frames=[];at=0
        while at<len(original):n=int.from_bytes(original[at+4:at+8],'big');frames.append(original[at:at+n+40]);at+=n+40
        indices=[i for i,f in enumerate(frames) if f[8]==34];h.check(len(indices)==2,'grant and import are exactly two kind34 transitions')
        bad=frames.copy();bad.pop(indices[0]);(c/'state.journal').write_bytes(b''.join(bad));h.run('missing-grant',['inspect','--state',str(c),'--node','C'],expected=3)
        bad=frames.copy();i=indices[-1];h.check(b'IMPORTED' in bad[i],'derived outcome stored');bad[i]=checksum_frame(bad[i].replace(b'IMPORTED',b'DUPLICAT'));(c/'state.journal').write_bytes(b''.join(bad))
        h.check(h.run('forged-outcome',['inspect','--state',str(c),'--node','C'],expected=3)['code']=='JOURNAL_CORRUPT','recomputed checksum cannot change source-derived decision')
        (c/'state.journal').write_bytes(original);cd=h.start('valid-replay',cc,c);h.run('valid-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown()
        after=h.run('checkpoint-replay',['inspect','--state',str(c),'--node','C']);h.check(after['import_automation'][0]['history_digest']==final['history_digest'],'checkpoint retains whole bounded decision history')
        ad.shutdown()
    case('source_derived_journal_and_checkpoint_validation',replay)

    def maintenance():
        a,c,ac,cc,ad,cd,s=setup(h,'maintenance');src,s,row=emit(h,'maint-source',a,c,s,ticks=125)
        auto(h,'maint-enable',c,'enable',previous=auto(h,'maint-initial',c),imports=8)
        first=until(h,'maint-first',c,lambda x:x['imports']==1);cd.shutdown()
        key=new_key(h,h.work,'import-state-g1');migrate(h,'import-migrate',c,key,node='C');cd=start_keyed(h,'import-keyed',cc,c,key)
        h.run('quiesce-import',['quiesce','--control',str(c/'control.sock'),'--reason','maintenance'])
        amended,s,row2=emit(h,'maint-correction',a,c,s,ticks=-75,parent=src['operation_id']);time.sleep(.6)
        h.check(auto(h,'quiesced-import',c)['imports']==1,'quiescence suspends new automatic imports, not peer delivery')
        h.run('resume-import',['resume','--control',str(c/'control.sock'),'--reason','maintenance completed']);second=until(h,'maint-second',c,lambda x:x['imports']==2)
        h.run('compact-import',['compact','--control',str(c/'control.sock')]);cd.shutdown();h.run('audit-import',['state-auth-audit','--state',str(c),'--node','C','--state-auth-key',str(key)])
        snapshot=inspect(h,'before-import-backup',c,key,node='C');crypt=h.work/'crypt.key';h.run('crypt-init',['backup-key-init','--output',str(crypt),'--generation','import-backup-g1']);ident=h.identity('C');archive=h.work/'import.nob'
        h.run('export-import',['backup-export','--state',str(c),'--node','C','--generation','c-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'import-restored';h.run('restore-import',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','C','--generation','c-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'import-restored-state',restored,key,node='C');h.check(after['storage']['logical_state_digest']==snapshot['storage']['logical_state_digest'],'encrypted restore exact logical equality')
        moved=candidate(h,cc,'import-relocated','import-relocated-g1',lambda t:t.replace('state='+str(c),'state='+str(restored)))
        h.run('relocate-import',['state-relocate','--state',str(restored),'--node','C','--candidate',str(moved),'--reason','owned path move','--state-auth-key',str(key)]);cd=start_keyed(h,'restored-import-worker',moved,restored,key)
        h.check(auto(h,'restored-allowance',restored)['imports']==2,'restore never replenishes allowance')
        src3,s,row3=emit(h,'after-restore',a,restored,s,ticks=200,parent=amended['operation_id']);last=until(h,'continued-import',restored,lambda x:x['imports']==3)
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'before':snapshot['storage']['logical_state_digest'],'after':after['storage']['logical_state_digest'],'schedule':last},indent=2)+'\n')
        cd.shutdown();ad.shutdown()
    case('keyed_audit_compaction_encrypted_restore_relocation',maintenance)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);start=time.time();ok=False
    try:run_cases(h,set(a.case) if a.case else None);ok=True
    except BaseException as exc:(h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(f'FAIL: {type(exc).__name__}: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_IMPORT_AUTOMATION_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(x['status']=='PASS' for x in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,value in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
