#!/usr/bin/env python3
"""Owned complete-datagram packet-port seam regression."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from typing import Any


EXPECTED_FEATURE = "OWNED_COMPLETE_DATAGRAM_PACKET_PORT_V1"
EXPECTED_REVISION = "0613"


def run_command(
    command: list[str],
    *,
    stdout_path: Path,
    stderr_path: Path,
    timeout: float,
    environment: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        timeout=timeout,
        env=environment,
    )
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)
    return completed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    source_root = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    binary = args.binary.resolve(strict=True)
    if output.exists() or output == source_root or source_root in output.parents:
        parser.error("output must be new and outside the source tree")
    output.mkdir(parents=True)

    started = time.monotonic()
    assertions = 0
    commands: list[dict[str, Any]] = []
    cases: list[dict[str, Any]] = []

    def check(condition: bool, detail: str) -> None:
        nonlocal assertions
        assertions += 1
        if not condition:
            raise AssertionError(detail)

    def record_case(name: str, before: int, begin: float) -> None:
        cases.append(
            {
                "name": name,
                "status": "PASS",
                "assertions": assertions - before,
                "elapsed_seconds": time.monotonic() - begin,
            }
        )

    status = "FAIL"
    failure: str | None = None
    probe_summary: dict[str, Any] | None = None
    try:
        before = assertions
        begin = time.monotonic()
        version_run = run_command(
            [str(binary), "version"],
            stdout_path=output / "version.stdout.txt",
            stderr_path=output / "version.stderr.txt",
            timeout=10,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append(
            {"label": "version", "returncode": version_run.returncode,
             "args": ["version"]}
        )
        check(version_run.returncode == 0, "version command succeeds")
        lines = [line for line in version_run.stdout.splitlines() if line.strip()]
        check(len(lines) == 1, "version emits one JSON line")
        version = json.loads(lines[0])
        check(version.get("version") == EXPECTED_REVISION,
              "revision marker is 0613")
        check(version.get("packet_port") == EXPECTED_FEATURE,
              "owned packet-port marker is exact")
        check(version.get("udp_transport") ==
              "NUMERIC_POINT_TO_POINT_UDP_PACKET_CARRIER_V1",
              "UDP carrier marker is retained")
        check(version.get("packet_link_core") ==
              "FINITE_PACKET_LINK_SERVICE_V1",
              "finite packet service marker is retained")
        record_case("revision metadata", before, begin)

        before = assertions
        begin = time.monotonic()
        header = (source_root / "node/src/packet_port.hpp").read_text()
        implementation = (source_root / "node/src/packet_port.cpp").read_text()
        udp_source = (source_root / "node/src/udp_transport.cpp").read_text()
        udp_header = (source_root / "node/src/udp_transport.hpp").read_text()
        finite_header = (source_root / "node/src/finite_packet_link.hpp").read_text()
        build_script = (source_root / "node/build.sh").read_text()
        configured_sources = "\n".join(
            (source_root / path).read_text()
            for path in (
                "node/src/config.cpp",
                "node/src/runtime.cpp",
                "node/src/daemon.cpp",
                "node/src/transport.cpp",
            )
        )
        check(EXPECTED_FEATURE in header and
              "class OwnedCompleteDatagramPacketPort" in header,
              "owned complete-datagram boundary is explicit and versioned")
        check("public natrav::packet_link::PacketPort" in header,
              "owned port supplies the finite packet callback contract")
        check("virtual std::size_t mtu()" in header and
              "wait_for_progress" in header and
              "Deadline wake_deadline" in header and
              "Deadline operation_deadline" in header,
              "seam exposes only MTU, complete packets, bounded progress, and deadlines")
        check("std::unique_ptr<OwnedCompleteDatagramPacketPort>" in header and
              "make_packet_port_ordered_byte_stream" in header,
              "ordered reconstruction takes exclusive port ownership")
        check("FinitePacketStream" in implementation and
              "maximum_write_bytes" in implementation and
              "elapsed_intervals" in implementation,
              "generic adapter owns finite reconstruction and constant-work logical time")
        forbidden_generic = (
            "SOCK_DGRAM", "sockaddr", "recvmsg", "sendmsg", "::send(",
            "::recv", "pollfd", "AF_INET", "AF_UNIX", "udp-v1|",
        )
        check(not any(token in implementation for token in forbidden_generic),
              "generic packet-port adapter contains no concrete socket or locator policy")
        check("class UdpPacketPort final : public OwnedCompleteDatagramPacketPort" in
              udp_source,
              "UDP implements the owned packet-port seam")
        check("make_packet_port_ordered_byte_stream" in udp_source and
              "FinitePacketStream" not in udp_source and
              "UdpPacketLinkOrderedByteStream" not in udp_source,
              "UDP no longer duplicates finite reconstruction or ordered-stream ownership")
        check("udp-v1|" in udp_source and
              "NUMERIC_POINT_TO_POINT_UDP_PACKET_CARRIER_V1" in udp_header,
              "UDP locator bytes and carrier marker remain unchanged")
        check("class PacketPort" in finite_header and
              "send_packet" in finite_header and "receive_packet" in finite_header,
              "finite packet state machine retains its minimal packet callback")
        check("src/packet_port.cpp" in build_script and
              "src/udp_transport.cpp" in build_script and
              "src/finite_packet_link.cpp" in build_script,
              "normal product build links all three ownership layers")
        check("unix-dgram-v1" in configured_sources and
              "packet-port-v1" not in configured_sources,
              "Unix datagrams reuse the seam while no generic packet-port locator exists")
        record_case("source ownership and authority boundary", before, begin)

        before = assertions
        begin = time.monotonic()
        probe = output / "packet-port-probe"
        compile_command = [
            "/usr/bin/g++",
            "-D_GNU_SOURCE",
            "-std=c++20",
            "-O1",
            "-g0",
            "-Wall",
            "-Wextra",
            "-Wpedantic",
            "-Wconversion",
            "-Wsign-conversion",
            "-Wshadow",
            "-Wformat=2",
            "-Werror",
            "-pthread",
            f"-I{source_root / 'foundation/include'}",
            f"-I{source_root / 'node/src'}",
            str(source_root / "node/tests/test_packet_port.cpp"),
            str(source_root / "node/src/packet_port.cpp"),
            str(source_root / "node/src/finite_packet_link.cpp"),
            str(source_root / "node/src/common.cpp"),
            str(source_root / "foundation/src/core.cpp"),
            str(source_root / "foundation/src/natrav_peer_handshake.cpp"),
            "-lssl",
            "-lcrypto",
            "-lz",
            "-lzstd",
            "-ldl",
            "-o",
            str(probe),
        ]
        compile_run = run_command(
            compile_command,
            stdout_path=output / "probe-build.stdout.txt",
            stderr_path=output / "probe-build.stderr.txt",
            timeout=240,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append(
            {"label": "probe-build", "returncode": compile_run.returncode,
             "args": compile_command}
        )
        check(compile_run.returncode == 0,
              "strict-warning packet-port probe compiles")
        check(probe.is_file() and os.access(probe, os.X_OK),
              "packet-port probe executable is materialized")
        probe_run = run_command(
            [str(probe)],
            stdout_path=output / "probe.stdout.txt",
            stderr_path=output / "probe.stderr.txt",
            timeout=30,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append(
            {"label": "probe", "returncode": probe_run.returncode,
             "args": [str(probe)]}
        )
        check(probe_run.returncode == 0, "packet-port probe succeeds")
        probe_lines = [line for line in probe_run.stdout.splitlines() if line.strip()]
        check(len(probe_lines) == 1, "packet-port probe emits one JSON line")
        probe_summary = json.loads(probe_lines[0])
        check(probe_summary.get("status") == "PASS",
              "packet-port probe reports PASS")
        check(probe_summary.get("format") == "NATRAV_PACKET_PORT_PROBE_V1",
              "packet-port probe format is exact")
        check(probe_summary.get("cases") == 6,
              "packet-port probe executes all owned-port cases")
        check(probe_summary.get("assertions", 0) >= 15,
              "packet-port probe records bounded behavioral assertions")
        assertions += int(probe_summary.get("assertions", 0))
        record_case("owned port behavioral probe", before, begin)

        status = "PASS"
    except Exception as error:  # noqa: BLE001 - evidence must retain exact failure
        failure = f"{type(error).__name__}: {error}"

    summary = {
        "format": "NATRAV_PACKET_PORT_SUITE_V1",
        "status": status,
        "feature": EXPECTED_FEATURE,
        "revision": EXPECTED_REVISION,
        "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "cases_passed": len(cases),
        "cases_total": 3,
        "assertions": assertions,
        "commands": len(commands),
        "elapsed_seconds": time.monotonic() - started,
        "cases": cases,
        "commands_run": commands,
        "probe": probe_summary,
        "failure": failure,
        "independent_host_verified": False,
        "hardware_verified": False,
    }
    (output / "SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, sort_keys=True))
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
