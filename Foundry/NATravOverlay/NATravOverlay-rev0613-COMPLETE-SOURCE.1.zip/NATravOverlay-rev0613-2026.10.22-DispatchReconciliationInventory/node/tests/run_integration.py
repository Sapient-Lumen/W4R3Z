#!/usr/bin/env python3
"""Native C++ node integration and independent-wire regression."""
from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time
from typing import Any, Callable

CAPABILITIES = [
    "AUTHORIZATION_POLICY_V1",
    "BOUNDED_PEER_SESSIONS_V1",
    "CANONICAL_CHECKPOINT_V2",
    "CORRECTION_CHAIN_V1",
    "DURABLE_COUNTER_ACTION_V1",
    "DURABLE_OBLIGATION_RESOLUTION_V1",
    "DURABLE_RECEIPT_V1",
    "DURABLE_REJECTION_V1",
    "KEY_GENERATIONS_V1",
    "LIVE_COMPACTION_V1",
    "NATIVE_TCP_V1",
    "OFFLINE_STATE_RELOCATION_V1",
    "RECIPIENT_SCOPED_EVIDENCE_V1",
    "RESERVED_OUTBOX_QUOTAS_V1",
    "STORAGE_SCHEMA_V2",
    "TLS13_MUTUAL_SPKI_PIN_V1",
    "VERIFIABLE_BACKUP_V1",
]
PROTOCOL = {"id": "NATRAV_OVERLAY_PEER", "major": 1, "minor": 0}
TARGET = "x86_64-unknown-linux-gnu"
VERSION = "natrav-overlay-node-0502"


def canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def frame(payload: bytes) -> bytes:
    if not 2 <= len(payload) <= 65536:
        raise AssertionError(f"frame payload size {len(payload)}")
    return struct.pack("!I", len(payload)) + payload


def recv_exact(sock: socket.socket, count: int) -> bytes:
    data = bytearray()
    while len(data) < count:
        part = sock.recv(count - len(data))
        if not part:
            raise EOFError(f"short socket read {len(data)}/{count}")
        data.extend(part)
    return bytes(data)


def recv_frame_bytes(sock: socket.socket) -> tuple[bytes, bytes]:
    header = recv_exact(sock, 4)
    size = struct.unpack("!I", header)[0]
    if not 2 <= size <= 65536:
        raise AssertionError(f"invalid frame size {size}")
    payload = recv_exact(sock, size)
    return header + payload, payload


def node_artifact(node: str) -> str:
    return hashlib.sha256(b"NATRAV_OVERLAY_NODE_ARTIFACT_V1\0" + node.encode()).hexdigest()


def op(label: str) -> str:
    value = hashlib.sha256(label.encode()).hexdigest()
    if set(value) == {"0"}:
        raise AssertionError("reserved operation")
    return value


def pack_text(value: str) -> bytes:
    encoded = value.encode()
    return struct.pack("!H", len(encoded)) + encoded


def encode_record(
    operation: str,
    issuer: str,
    recipient: str,
    scope: str,
    payload: bytes,
    corrects: str | None = None,
) -> bytes:
    kind = 2 if corrects else 1
    result = bytearray(b"NOA1" + bytes([kind]) + bytes.fromhex(operation))
    result.extend(pack_text(issuer))
    result.extend(pack_text(recipient))
    result.extend(pack_text(scope))
    if corrects:
        result.extend(bytes.fromhex(corrects))
    result.extend(struct.pack("!I", len(payload)))
    result.extend(payload)
    return bytes(result)


def record_digest(record_payload: bytes) -> bytes:
    return hashlib.sha256(b"NATRAV_OVERLAY_EVIDENCE_RECORD_V1\0" + record_payload).digest()


def encode_receipt(
    operation: str,
    recipient: str,
    disposition: int,
    sequence: int,
    digest: bytes,
) -> bytes:
    return (
        b"NOA1"
        + bytes([3])
        + bytes.fromhex(operation)
        + pack_text(recipient)
        + pack_text(recipient)
        + bytes([disposition])
        + struct.pack("!Q", sequence)
        + digest
    )


class ByteReader:
    def __init__(self, data: bytes):
        self.data = data
        self.offset = 0

    def take(self, count: int) -> bytes:
        if self.offset + count > len(self.data):
            raise AssertionError("truncated app payload")
        value = self.data[self.offset : self.offset + count]
        self.offset += count
        return value

    def u8(self) -> int:
        return self.take(1)[0]

    def u16(self) -> int:
        return struct.unpack("!H", self.take(2))[0]

    def u64(self) -> int:
        return struct.unpack("!Q", self.take(8))[0]

    def text(self) -> str:
        return self.take(self.u16()).decode()

    def done(self) -> None:
        if self.offset != len(self.data):
            raise AssertionError("trailing app payload")


def decode_app(payload: bytes) -> dict[str, Any]:
    reader = ByteReader(payload)
    if reader.take(4) != b"NOA1":
        raise AssertionError("app magic")
    kind = reader.u8()
    if kind == 3:
        operation = reader.take(32).hex()
        recipient = reader.text()
        recorder = reader.text()
        disposition = reader.u8()
        sequence = reader.u64()
        digest = reader.take(32).hex()
        reader.done()
        return {
            "kind": "receipt",
            "operation": operation,
            "recipient": recipient,
            "recorder": recorder,
            "disposition": disposition,
            "sequence": sequence,
            "digest": digest,
        }
    if kind == 4:
        has_operation = reader.u8()
        operation = reader.take(32).hex() if has_operation else None
        code = reader.text()
        detail = reader.text()
        reader.done()
        return {"kind": "error", "operation": operation, "code": code, "detail": detail}
    raise AssertionError(f"unexpected app kind {kind}")


def hello(node: str, request: str) -> bytes:
    return canonical(
        {
            "artifact": {"sha256": node_artifact(node), "target": TARGET, "version": VERSION},
            "kind": "HELLO",
            "protocol": PROTOCOL,
            "request_id": request,
            "required_capabilities": CAPABILITIES,
        }
    )


def hello_ack(node: str, request: str) -> bytes:
    return canonical(
        {
            "artifact": {"sha256": node_artifact(node), "target": TARGET, "version": VERSION},
            "available_capabilities": CAPABILITIES,
            "kind": "HELLO_ACK",
            "protocol": PROTOCOL,
            "request_id": request,
        }
    )


class Harness:
    def __init__(self, binary: Path, output: Path, profile: str):
        self.binary = binary.resolve()
        self.output = output.resolve()
        self.profile = profile
        self.work = self.output / "work"
        self.logs = self.output / "logs"
        self.output.mkdir(parents=True)
        self.work.mkdir()
        self.logs.mkdir()
        self.commands: list[dict[str, Any]] = []
        self.cases: list[dict[str, Any]] = []
        self.assertions = 0
        self.current_case = "setup"
        self.env = os.environ.copy()

    def check(self, condition: bool, detail: str) -> None:
        self.assertions += 1
        if not condition:
            raise AssertionError(detail)

    def run(
        self,
        label: str,
        arguments: list[str],
        ok: bool | None = True,
        timeout: float = 15,
        env: dict[str, str] | None = None,
    ) -> tuple[subprocess.CompletedProcess[str], dict[str, Any] | None]:
        command = [str(self.binary), *arguments]
        completed = subprocess.run(
            command,
            text=True,
            capture_output=True,
            timeout=timeout,
            env=env or self.env,
        )
        safe = f"{len(self.commands):03d}-{label}".replace("/", "_")
        (self.logs / f"{safe}.stdout.txt").write_text(completed.stdout)
        (self.logs / f"{safe}.stderr.txt").write_text(completed.stderr)
        parsed = None
        if completed.stdout.strip():
            try:
                parsed = json.loads(completed.stdout.strip().splitlines()[-1])
            except json.JSONDecodeError:
                parsed = None
        self.commands.append(
            {
                "case": self.current_case,
                "label": label,
                "argv": arguments,
                "returncode": completed.returncode,
                "stdout_file": f"logs/{safe}.stdout.txt",
                "stderr_file": f"logs/{safe}.stderr.txt",
                "json": parsed,
            }
        )
        if ok is True:
            self.check(completed.returncode == 0, f"{label} failed: {completed.stdout} {completed.stderr}")
            self.check(isinstance(parsed, dict), f"{label} did not emit JSON")
            self.check(parsed.get("ok", True) is not False, f"{label} emitted failure JSON")
        elif ok is False:
            self.check(completed.returncode != 0, f"{label} unexpectedly succeeded")
            self.check(isinstance(parsed, dict) and parsed.get("ok") is False, f"{label} failure JSON absent")
        return completed, parsed

    def inspect(self, label: str, state: Path, node: str) -> dict[str, Any]:
        _, parsed = self.run(label, ["inspect", "--state", str(state), "--node", node])
        assert parsed is not None
        return parsed

    def case(self, name: str, function: Callable[[], None]) -> None:
        self.current_case = name
        started = time.monotonic()
        try:
            function()
            self.cases.append({"name": name, "status": "PASS", "elapsed_ms": int((time.monotonic()-started)*1000)})
        except Exception as exc:
            self.cases.append(
                {"name": name, "status": "FAIL", "elapsed_ms": int((time.monotonic()-started)*1000),
                 "error": f"{type(exc).__name__}: {exc}"}
            )
            raise


class Server:
    def __init__(
        self,
        harness: Harness,
        label: str,
        state: Path,
        node: str,
        maximum_connections: int,
        extra: list[str] | None = None,
    ):
        self.harness = harness
        self.label = label
        extra = list(extra or [])
        args = [
            str(harness.binary), "serve", "--state", str(state), "--node", node,
            "--listen", "127.0.0.1:0", "--max-connections", str(maximum_connections),
        ]
        if "--deadline-ms" not in extra:
            args.extend(["--deadline-ms", "3000"])
        args.extend(extra)
        self.process = subprocess.Popen(
            args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            bufsize=1, env=harness.env,
        )
        assert self.process.stdout is not None
        ready_handles, _, _ = select.select([self.process.stdout], [], [], 5)
        if not ready_handles:
            self.process.kill()
            raise AssertionError(f"server {label} did not become ready")
        self.ready_line = self.process.stdout.readline()
        try:
            self.ready = json.loads(self.ready_line)
        except json.JSONDecodeError as exc:
            self.process.kill()
            raise AssertionError(f"server {label} bad ready line {self.ready_line!r}") from exc
        harness.check(self.ready.get("format") == "NATRAV_OVERLAY_SERVER_READY_V1", f"{label} ready format")
        self.port = int(self.ready["port"])
        self.finished = False

    def finish(self, timeout: float = 15) -> dict[str, Any]:
        if self.finished:
            raise AssertionError("server already finished")
        self.finished = True
        try:
            stdout_rest, stderr = self.process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            self.process.kill()
            stdout_rest, stderr = self.process.communicate()
            raise AssertionError(f"server {self.label} did not stop: {stderr}")
        stdout = self.ready_line + stdout_rest
        safe = f"server-{self.label}".replace("/", "_")
        (self.harness.logs / f"{safe}.stdout.txt").write_text(stdout)
        (self.harness.logs / f"{safe}.stderr.txt").write_text(stderr)
        lines = [line for line in stdout.splitlines() if line.strip()]
        self.harness.check(self.process.returncode == 0, f"server {self.label} return {self.process.returncode}: {stderr}")
        self.harness.check(len(lines) >= 2, f"server {self.label} stop line absent")
        stop = json.loads(lines[-1])
        self.harness.commands.append(
            {
                "case": self.harness.current_case,
                "label": f"server-{self.label}",
                "argv": ["serve"],
                "returncode": self.process.returncode,
                "stdout_file": f"logs/{safe}.stdout.txt",
                "stderr_file": f"logs/{safe}.stderr.txt",
                "json": stop,
            }
        )
        return stop

    def terminate(self) -> dict[str, Any]:
        self.process.terminate()
        return self.finish()

    def cleanup(self) -> None:
        if not self.finished and self.process.poll() is None:
            self.process.kill()
            self.process.communicate()


def offer_args(
    state: Path,
    node: str,
    peer: str,
    port: int,
    operation: str,
    payload: str,
    scope: str = "test/evidence",
    recipient: str | None = None,
    correction: str | None = None,
    extra: list[str] | None = None,
) -> list[str]:
    command = "correct" if correction else "offer"
    args = [
        command, "--state", str(state), "--node", node, "--peer", peer,
        "--connect", f"127.0.0.1:{port}", "--recipient", recipient or peer,
        "--scope", scope, "--operation", operation, "--payload-text", payload,
    ]
    if correction:
        args.extend(["--corrects", correction])
    if extra:
        args.extend(extra)
    return args


def python_deliver(
    port: int,
    issuer: str,
    recipient: str,
    operation: str,
    payload: bytes,
    scope: str = "independent/test",
    hello_node: str | None = None,
    coalesced: bool = False,
) -> tuple[dict[str, Any], dict[str, Any]]:
    request = op(f"hello-{operation}")
    app = encode_record(operation, issuer, recipient, scope, payload)
    with socket.create_connection(("127.0.0.1", port), timeout=3) as conn:
        conn.settimeout(3)
        first = frame(hello(hello_node or issuer, request))
        if coalesced:
            conn.sendall(first + frame(app))
        else:
            conn.sendall(first)
        _, ack_payload = recv_frame_bytes(conn)
        ack = json.loads(ack_payload)
        if canonical(ack) != ack_payload:
            raise AssertionError("noncanonical HELLO_ACK")
        if ack.get("kind") != "HELLO_ACK" or ack.get("request_id") != request:
            raise AssertionError("HELLO_ACK mismatch")
        if not coalesced:
            conn.sendall(frame(app))
        conn.shutdown(socket.SHUT_WR)
        _, response_payload = recv_frame_bytes(conn)
    return ack, decode_app(response_payload)


class LostReceiptProxy:
    def __init__(self, upstream_port: int):
        self.listener = socket.socket()
        self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.listener.bind(("127.0.0.1", 0))
        self.listener.listen(1)
        self.port = self.listener.getsockname()[1]
        self.error: BaseException | None = None
        self.thread = threading.Thread(target=self._run, args=(upstream_port,), daemon=True)
        self.thread.start()

    def _run(self, upstream_port: int) -> None:
        try:
            downstream, _ = self.listener.accept()
            with downstream, socket.create_connection(("127.0.0.1", upstream_port), timeout=3) as upstream:
                downstream.settimeout(3)
                upstream.settimeout(3)
                hello_frame, _ = recv_frame_bytes(downstream)
                upstream.sendall(hello_frame)
                ack_frame, _ = recv_frame_bytes(upstream)
                downstream.sendall(ack_frame)
                app_frame, _ = recv_frame_bytes(downstream)
                upstream.sendall(app_frame)
                upstream.shutdown(socket.SHUT_WR)
                recv_frame_bytes(upstream)  # Receipt exists, but is deliberately lost.
        except BaseException as exc:
            self.error = exc
        finally:
            self.listener.close()

    def finish(self) -> None:
        self.thread.join(5)
        if self.thread.is_alive():
            raise AssertionError("lost-receipt proxy did not stop")
        if self.error:
            raise self.error


class StallServer:
    def __init__(self):
        self.listener = socket.socket()
        self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.listener.bind(("127.0.0.1", 0))
        self.listener.listen(1)
        self.port = self.listener.getsockname()[1]
        self.accepted = threading.Event()
        self.release = threading.Event()
        self.error: BaseException | None = None
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self) -> None:
        try:
            connection, _ = self.listener.accept()
            with connection:
                self.accepted.set()
                self.release.wait(5)
        except BaseException as exc:
            self.error = exc
        finally:
            self.listener.close()

    def finish(self) -> None:
        self.release.set()
        self.thread.join(5)
        if self.thread.is_alive():
            raise AssertionError("stall server did not stop")
        if self.error:
            raise self.error


class IndependentServer:
    def __init__(self, peer: str):
        self.peer = peer
        self.listener = socket.socket()
        self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.listener.bind(("127.0.0.1", 0))
        self.listener.listen(1)
        self.port = self.listener.getsockname()[1]
        self.error: BaseException | None = None
        self.observed: dict[str, Any] = {}
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self) -> None:
        try:
            connection, _ = self.listener.accept()
            with connection:
                connection.settimeout(3)
                _, hello_payload = recv_frame_bytes(connection)
                message = json.loads(hello_payload)
                if canonical(message) != hello_payload:
                    raise AssertionError("C++ HELLO is noncanonical")
                if message["kind"] != "HELLO" or message["required_capabilities"] != CAPABILITIES:
                    raise AssertionError("C++ HELLO schema")
                request = message["request_id"]
                connection.sendall(frame(hello_ack(self.peer, request)))
                _, app = recv_frame_bytes(connection)
                if app[:4] != b"NOA1" or app[4] not in (1, 2):
                    raise AssertionError("C++ app record")
                operation = app[5:37].hex()
                digest = record_digest(app)
                self.observed = {"operation": operation, "record_digest": digest.hex(), "hello": message}
                response = encode_receipt(operation, self.peer, 1, 1, digest)
                connection.sendall(frame(response))
        except BaseException as exc:
            self.error = exc
        finally:
            self.listener.close()

    def finish(self) -> None:
        self.thread.join(5)
        if self.thread.is_alive():
            raise AssertionError("independent server did not stop")
        if self.error:
            raise self.error


def run_suite(h: Harness) -> None:
    _, version = h.run("version", ["version"])
    h.check(version and version["version"] == "0613", "version value")
    h.check(version and version["custody_promotion_intent"] ==
        "NHCPI001_EXPLICIT_REVALIDATED_INPUT_V1",
        "detached custody-promotion intent feature marker")
    h.check(version and version["transport_extraction"] ==
        "TCP_ORDERED_BYTE_STREAM_BOUNDARY_V1",
        "carrier-neutral TCP transport extraction feature marker")
    h.check(version and version["tls_byte_channel"] ==
        "OPENSSL_BYTE_CHANNEL_BIO_V1",
        "descriptor-free OpenSSL ByteChannel BIO feature marker")
    h.check(version and version["projection_publication"] == "NPP1_DURABLE_OUTBOX_V1",
            "projection publication capability")
    h.check(version and version["publication_channels"] == "NPC2_EXPLICIT_CHANNEL_EPOCHS_V1",
            "durable publication-channel capability")
    h.check(version and version["source_progress_journal"] == "NST3_COMPACT_EXACT_TRANSITIONS_V1",
            "compact exact source-progress journal capability")
    h.check(version and version["peer_routes"] == "V13_BOUNDED_MULTI_ROUTE_V1",
            "bounded multi-route capability")
    h.check(version["evidence_feed"] == "NEF1_SCOPED_INCREMENTAL_ADMISSIONS", "native feed capability")

    def basic() -> None:
        a = h.work / "basic-a"
        b = h.work / "basic-b"
        operation1 = op("basic-original")
        operation2 = op("basic-correction")
        operation3 = op("basic-branch")
        binary_payload = h.work / "basic-payload.bin"
        binary_payload.write_bytes(b"\x00alpha\xff")
        server = Server(h, "basic-1", b, "B", 1)
        try:
            args = [
                "offer", "--state", str(a), "--node", "A", "--peer", "B",
                "--connect", f"127.0.0.1:{server.port}", "--scope", "lab/basic",
                "--operation", operation1, "--payload-file", str(binary_payload),
            ]
            _, sent = h.run("basic-offer", args)
            h.check(sent and sent["receipt_disposition"] == "COMMITTED", "first commit receipt")
            stop = server.finish()
            h.check(stop["committed"] == 1, "first server commit")
        finally:
            server.cleanup()
        server = Server(h, "basic-2", b, "B", 1)
        try:
            _, corrected = h.run(
                "basic-correction",
                offer_args(a, "A", "B", server.port, operation2, "updated", "lab/basic", correction=operation1),
            )
            h.check(corrected and corrected["receipt_disposition"] == "COMMITTED", "correction commit")
            server.finish()
        finally:
            server.cleanup()
        server = Server(h, "basic-branch", b, "B", 1)
        try:
            _, rejected = h.run(
                "basic-branch-reject",
                offer_args(a, "A", "B", server.port, operation3, "branch", "lab/basic", correction=operation1),
                ok=False,
            )
            h.check(rejected and rejected["code"] == "CORRECTION_BRANCH_REJECTED", "branch rejection")
            stop = server.finish()
            h.check(stop["rejected"] == 1, "branch server rejection")
        finally:
            server.cleanup()
        b_state = h.inspect("basic-inspect-b", b, "B")
        h.check(b_state["inbound"]["count"] == 2, "two inbound records")
        h.check(b_state["inbound"]["current"][0]["current_operation_id"] == operation2, "correction current view")
        h.check(b_state["inbound"]["history"][0]["payload_hex"] == "00616c706861ff", "binary payload retained")
        a_state = h.inspect("basic-inspect-a", a, "A")
        h.check(a_state["outbox"]["acked"] == 2 and a_state["outbox"]["pending"] == 1, "outbox durable states")
        _, local_conflict = h.run(
            "basic-local-conflict",
            offer_args(a, "A", "B", 1, operation1, "different", "lab/basic"),
            ok=False,
        )
        h.check(local_conflict and local_conflict["code"] == "OUTBOUND_OPERATION_CONFLICT", "local conflict before network")
        restart = Server(h, "basic-restart", b, "B", 0, ["--idle-timeout-ms", "60"])
        try:
            stop = restart.finish()
            h.check(stop["inbound_records"] == 2, "restart reconstructed records")
        finally:
            restart.cleanup()

    h.case("durable_offer_correction_restart", basic)

    def lost_receipt() -> None:
        a = h.work / "lost-a"
        b = h.work / "lost-b"
        operation = op("lost-receipt")
        server = Server(h, "lost-1", b, "B", 1)
        proxy = LostReceiptProxy(server.port)
        try:
            args = offer_args(a, "A", "B", proxy.port, operation, "commit-before-lost-receipt")
            _, failed = h.run("lost-first-send", args, ok=False)
            h.check(failed and failed["code"] in {"PEER_CLOSED", "PEER_RESET", "INCOMPLETE_FRAME_EOF"}, "lost response failure")
            proxy.finish()
            stop = server.finish()
            h.check(stop["committed"] == 1, "recipient committed before lost receipt")
        finally:
            server.cleanup()
        a_state = h.inspect("lost-inspect-pending", a, "A")
        h.check(a_state["outbox"]["pending"] == 1, "lost receipt remains pending")
        server = Server(h, "lost-2", b, "B", 1)
        try:
            _, replay = h.run("lost-replay", offer_args(a, "A", "B", server.port, operation, "commit-before-lost-receipt"))
            h.check(replay and replay["queue_disposition"] == "ALREADY_PENDING", "replay uses durable outbox")
            h.check(replay and replay["receipt_disposition"] == "DUPLICATE", "duplicate receipt recovered")
            stop = server.finish()
            h.check(stop["duplicate"] == 1 and stop["committed"] == 0, "recipient deduplicated replay")
        finally:
            server.cleanup()
        b_state = h.inspect("lost-inspect-b", b, "B")
        h.check(b_state["inbound"]["count"] == 1, "replay did not multiply admission")
        _, cached = h.run("lost-already-acked", offer_args(a, "A", "B", 1, operation, "commit-before-lost-receipt"))
        h.check(cached and cached["network_used"] is False, "acked operation skips unavailable network")

    h.case("lost_receipt_replay", lost_receipt)

    def rejection_paths() -> None:
        wrong_a, wrong_b = h.work / "wrong-a", h.work / "wrong-b"
        server = Server(h, "wrong-recipient", wrong_b, "B", 1)
        try:
            _, error = h.run(
                "wrong-recipient-send",
                offer_args(wrong_a, "A", "B", server.port, op("wrong-recipient"), "x", recipient="C"),
                ok=False,
            )
            h.check(error and error["code"] == "WRONG_RECIPIENT", "wrong recipient code")
            server.finish()
        finally:
            server.cleanup()
        h.check(h.inspect("wrong-recipient-state", wrong_b, "B")["inbound"]["count"] == 0, "wrong recipient not stored")

        missing_a, missing_b = h.work / "missing-a", h.work / "missing-b"
        server = Server(h, "missing-parent", missing_b, "B", 1)
        try:
            _, error = h.run(
                "missing-parent-send",
                offer_args(missing_a, "A", "B", server.port, op("missing-child"), "x", correction=op("absent-parent")),
                ok=False,
            )
            h.check(error and error["code"] == "CORRECTION_PARENT_NOT_FOUND", "missing parent code")
            server.finish()
        finally:
            server.cleanup()

        cap_a, cap_b = h.work / "capacity-a", h.work / "capacity-b"
        server = Server(h, "capacity", cap_b, "B", 1, ["--max-journal-bytes", "1024"])
        try:
            _, error = h.run(
                "capacity-send",
                offer_args(cap_a, "A", "B", server.port, op("capacity"), "z" * 2000),
                ok=False,
            )
            h.check(error and error["code"] == "STATE_CAPACITY_EXCEEDED", "capacity code")
            stop = server.finish()
            h.check(stop["inbound_records"] == 0, "capacity did not append")
        finally:
            server.cleanup()

    h.case("recipient_parent_and_capacity_rejections", rejection_paths)

    def conflicts() -> None:
        b = h.work / "conflict-b"
        operation = op("recipient-conflict")
        server = Server(h, "recipient-conflict", b, "B", 2)
        try:
            h.run("conflict-first", offer_args(h.work / "conflict-a1", "A", "B", server.port, operation, "one"))
            _, error = h.run(
                "conflict-second",
                offer_args(h.work / "conflict-a2", "A", "B", server.port, operation, "two"),
                ok=False,
            )
            h.check(error and error["code"] == "INBOUND_OPERATION_CONFLICT", "recipient conflict code")
            stop = server.finish()
            h.check(stop["committed"] == 1 and stop["rejected"] == 1, "conflict server counts")
        finally:
            server.cleanup()
        h.check(h.inspect("conflict-state", b, "B")["inbound"]["count"] == 1, "conflict did not overwrite")

    h.case("operation_identity_conflict", conflicts)

    def offline_queue() -> None:
        holder = socket.socket()
        holder.bind(("127.0.0.1", 0))
        port = holder.getsockname()[1]
        holder.close()
        state = h.work / "offline-a"
        _, error = h.run(
            "offline-send",
            offer_args(state, "A", "B", port, op("offline"), "queued while offline"),
            ok=False,
        )
        h.check(error and error["code"] == "CONNECT_FAILED", "offline connect code")
        snapshot = h.inspect("offline-state", state, "A")
        h.check(snapshot["outbox"]["pending"] == 1, "offline record persisted before connect")

    h.case("offline_outbox", offline_queue)

    def queued_flush() -> None:
        a, b, c = h.work / "flush-a", h.work / "flush-b", h.work / "flush-c"
        original = op("flush-original")
        correction = op("flush-correction")
        other_peer = op("flush-other-peer")
        holder = socket.socket()
        holder.bind(("127.0.0.1", 0))
        offline_port = holder.getsockname()[1]
        holder.close()
        _, first_error = h.run(
            "flush-queue-original",
            offer_args(a, "A", "B", offline_port, original, "original", "flush/scope"),
            ok=False,
        )
        h.check(first_error and first_error["code"] == "CONNECT_FAILED", "original queued offline")
        _, second_error = h.run(
            "flush-queue-correction",
            offer_args(
                a, "A", "B", offline_port, correction, "corrected",
                "flush/scope", correction=original),
            ok=False,
        )
        h.check(second_error and second_error["code"] == "CONNECT_FAILED", "correction queued offline")
        _, third_error = h.run(
            "flush-queue-other-peer",
            offer_args(a, "A", "C", offline_port, other_peer, "for-c", "flush/other"),
            ok=False,
        )
        h.check(third_error and third_error["code"] == "CONNECT_FAILED", "other peer queued offline")
        queued = h.inspect("flush-queued-state", a, "A")
        h.check(queued["outbox"]["pending"] == 3, "three durable pending records")

        first_server = Server(h, "flush-first", b, "B", 1)
        try:
            _, first = h.run(
                "flush-first-run",
                [
                    "flush", "--state", str(a), "--node", "A",
                    "--peer", "B", "--connect", f"127.0.0.1:{first_server.port}",
                    "--max-records", "1",
                ],
            )
            h.check(first and first["pending_before"] == 2, "flush sees complete peer queue")
            h.check(first and first["attempted"] == 1 and first["pending_after"] == 1, "bounded flush")
            h.check(first and first["acknowledged_operations"] == [original], "queue sequence preserved")
            stop = first_server.finish()
            h.check(stop["committed"] == 1, "first queued record committed")
        finally:
            first_server.cleanup()

        second_server = Server(h, "flush-second", b, "B", 1)
        try:
            _, second = h.run(
                "flush-second-run",
                [
                    "flush", "--state", str(a), "--node", "A",
                    "--peer", "B", "--connect", f"127.0.0.1:{second_server.port}",
                ],
            )
            h.check(second and second["pending_before"] == 1, "second flush sees remainder")
            h.check(second and second["attempted"] == 1 and second["pending_after"] == 0, "remainder flushed")
            h.check(second and second["acknowledged_operations"] == [correction], "correction delivered second")
            stop = second_server.finish()
            h.check(stop["committed"] == 1, "correction committed")
        finally:
            second_server.cleanup()

        sender_mid = h.inspect("flush-mid-a", a, "A")
        h.check(sender_mid["outbox"]["acked"] == 2 and sender_mid["outbox"]["pending"] == 1, "unrelated peer remains pending")
        recipient = h.inspect("flush-final-b", b, "B")
        h.check(recipient["inbound"]["count"] == 2, "recipient retained correction history")
        h.check(recipient["inbound"]["current"][0]["current_operation_id"] == correction, "recipient current view corrected")

        third_server = Server(h, "flush-third-peer", c, "C", 1)
        try:
            _, third = h.run(
                "flush-third-peer-run",
                [
                    "flush", "--state", str(a), "--node", "A",
                    "--peer", "C", "--connect", f"127.0.0.1:{third_server.port}",
                ],
            )
            h.check(third and third["pending_before"] == 1 and third["pending_after"] == 0, "peer-specific queue flushed")
            h.check(third and third["acknowledged_operations"] == [other_peer], "other peer operation selected")
            stop = third_server.finish()
            h.check(stop["committed"] == 1, "other peer committed")
        finally:
            third_server.cleanup()

        sender = h.inspect("flush-final-a", a, "A")
        h.check(sender["outbox"]["acked"] == 3 and sender["outbox"]["pending"] == 0, "all peer receipts durable")
        h.check(h.inspect("flush-final-c", c, "C")["inbound"]["count"] == 1, "other recipient durable")
        _, empty = h.run(
            "flush-empty-no-network",
            [
                "flush", "--state", str(a), "--node", "A",
                "--peer", "B", "--connect", f"127.0.0.1:{offline_port}",
            ],
        )
        h.check(empty and empty["attempted"] == 0 and empty["pending_after"] == 0, "empty flush skips network")

    h.case("durable_offline_flush", queued_flush)

    def killed_after_queue_commit() -> None:
        a, b = h.work / "kill-a", h.work / "kill-b"
        operation = op("kill-after-queue")
        stall = StallServer()
        arguments = offer_args(
            a, "A", "B", stall.port, operation,
            "durable-before-network-completion", "kill/boundary",
            extra=["--deadline-ms", "10000"],
        )
        process = subprocess.Popen(
            [str(h.binary), *arguments],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=h.env,
        )
        h.check(stall.accepted.wait(5), "client reached stalled peer")
        process.kill()
        stdout, stderr = process.communicate(timeout=5)
        safe = f"{len(h.commands):03d}-kill-after-queue-process"
        (h.logs / f"{safe}.stdout.txt").write_text(stdout)
        (h.logs / f"{safe}.stderr.txt").write_text(stderr)
        h.commands.append({
            "case": h.current_case,
            "label": "kill-after-queue-process",
            "argv": arguments,
            "returncode": process.returncode,
            "stdout_file": f"logs/{safe}.stdout.txt",
            "stderr_file": f"logs/{safe}.stderr.txt",
            "json": None,
        })
        stall.finish()
        h.check(process.returncode == -9, "client killed at selected boundary")
        queued = h.inspect("kill-queued-state", a, "A")
        h.check(queued["outbox"]["pending"] == 1, "fdatasynced queue survives process kill")
        server = Server(h, "kill-recovery", b, "B", 1)
        try:
            _, flushed = h.run(
                "kill-recovery-flush",
                [
                    "flush", "--state", str(a), "--node", "A",
                    "--peer", "B", "--connect", f"127.0.0.1:{server.port}",
                ],
            )
            h.check(flushed and flushed["acknowledged"] == 1, "killed operation replayed")
            stop = server.finish()
            h.check(stop["committed"] == 1, "killed operation committed once")
        finally:
            server.cleanup()
        h.check(h.inspect("kill-final-a", a, "A")["outbox"]["acked"] == 1, "replayed receipt durable")
        h.check(h.inspect("kill-final-b", b, "B")["inbound"]["count"] == 1, "replayed evidence durable")

    h.case("process_kill_after_durable_queue", killed_after_queue_commit)

    def journal_recovery() -> None:
        a = h.work / "recovery-a"
        base = h.work / "recovery-base"
        server = Server(h, "recovery-seed", base, "B", 1)
        try:
            h.run("recovery-seed-send", offer_args(a, "A", "B", server.port, op("recovery-seed"), "seed"))
            server.finish()
        finally:
            server.cleanup()
        corrupt = h.work / "recovery-corrupt"
        shutil.copytree(base, corrupt)
        journal = base / "state.journal"
        with journal.open("ab") as stream:
            stream.write(b"NOJ1\x00\x00")
        recovered = h.inspect("recovery-tail", base, "B")
        h.check(recovered["inbound"]["count"] == 1, "tail recovery preserved prefix")
        h.check(recovered["recoveries"][-1]["discarded_tail_bytes"] == 6, "tail recovery byte count")

        damaged = bytearray((corrupt / "state.journal").read_bytes())
        body_size = struct.unpack("!I", damaged[4:8])[0]
        checksum_offset = 8 + body_size
        damaged[checksum_offset] ^= 1
        (corrupt / "state.journal").write_bytes(damaged)
        _, error = h.run("recovery-checksum", ["inspect", "--state", str(corrupt), "--node", "B"], ok=False)
        h.check(error and error["code"] == "JOURNAL_CORRUPT", "checksum corruption fails closed")

    h.case("journal_tail_recovery_and_corruption", journal_recovery)

    def fragmentation() -> None:
        a, b = h.work / "fragment-a", h.work / "fragment-b"
        server = Server(
            h, "fragment", b, "B", 1,
            ["--read-quantum", "1", "--write-quantum", "1", "--deadline-ms", "10000"],
        )
        try:
            _, result = h.run(
                "fragment-send",
                offer_args(
                    a, "A", "B", server.port, op("fragment"), "f" * 1024,
                    extra=["--read-quantum", "1", "--write-quantum", "1", "--deadline-ms", "10000"],
                ),
                timeout=20,
            )
            h.check(result and result["handshake_io"]["write_calls"] > 100, "handshake fragmented writes")
            h.check(result and result["application_io"]["write_calls"] > 1000, "application fragmented writes")
            server.finish(timeout=20)
        finally:
            server.cleanup()

    h.case("one_byte_socket_fragmentation", fragmentation)

    def truncated() -> None:
        b = h.work / "truncated-b"
        server = Server(h, "truncated", b, "B", 1, ["--deadline-ms", "500"])
        try:
            with socket.create_connection(("127.0.0.1", server.port), timeout=2) as conn:
                conn.sendall(b"\x00\x00")
            stop = server.finish()
            h.check(stop["rejected"] == 1 and stop["transport_errors"] == 1, "truncated connection classified")
        finally:
            server.cleanup()
        h.check(h.inspect("truncated-state", b, "B")["inbound"]["count"] == 0, "truncated connection stored nothing")

    h.case("incomplete_socket_eof", truncated)

    def bounded_framing() -> None:
        malformed_state = h.work / "malformed-b"
        server = Server(h, "malformed-frame", malformed_state, "B", 1)
        try:
            with socket.create_connection(("127.0.0.1", server.port), timeout=2) as conn:
                conn.sendall(struct.pack("!I", 70_000))
                conn.shutdown(socket.SHUT_WR)
            stop = server.finish()
            h.check(stop["rejected"] == 1, "oversized frame rejected")
            h.check(stop["inbound_records"] == 0, "oversized frame stored nothing")
        finally:
            server.cleanup()

        limit_state = h.work / "receive-limit-b"
        server = Server(h, "receive-limit", limit_state, "B", 1, ["--receive-limit", "64"])
        try:
            request = op("receive-limit-hello")
            with socket.create_connection(("127.0.0.1", server.port), timeout=2) as conn:
                conn.sendall(frame(hello("A", request)))
                conn.shutdown(socket.SHUT_WR)
            stop = server.finish()
            h.check(stop["rejected"] == 1, "received-byte ceiling rejected handshake")
            h.check(stop["read_bytes"] == 0, "over-limit chunk not admitted to counters")
        finally:
            server.cleanup()
        h.check(h.inspect("receive-limit-state", limit_state, "B")["inbound"]["count"] == 0, "receive limit stored nothing")

    h.case("bounded_frame_and_receive_limits", bounded_framing)

    def independent_wire() -> None:
        b = h.work / "independent-b"
        server = Server(h, "independent-python-client", b, "B", 1)
        operation = op("python-to-cpp")
        try:
            ack, response = python_deliver(
                server.port, "PyA", "B", operation, b"python-wire", coalesced=True)
            h.check(ack["artifact"]["sha256"] == node_artifact("B"), "server artifact identity")
            h.check(response["kind"] == "receipt" and response["disposition"] == 1, "python client committed")
            server.finish()
        finally:
            server.cleanup()
        h.check(h.inspect("independent-b-state", b, "B")["inbound"]["count"] == 1, "python record durable")

        a = h.work / "independent-a"
        peer = IndependentServer("B")
        operation2 = op("cpp-to-python")
        _, result = h.run(
            "cpp-to-python-send",
            offer_args(a, "A", "B", peer.port, operation2, "cpp-wire"),
        )
        peer.finish()
        h.check(result and result["receipt_disposition"] == "COMMITTED", "C++ accepted independent receipt")
        h.check(peer.observed["operation"] == operation2, "independent server parsed operation")
        h.check(h.inspect("independent-a-state", a, "A")["outbox"]["acked"] == 1, "independent receipt durable")

        mismatch_b = h.work / "issuer-mismatch-b"
        server = Server(h, "issuer-mismatch", mismatch_b, "B", 1)
        try:
            _, response = python_deliver(
                server.port, "A", "B", op("issuer-mismatch"), b"x", hello_node="X")
            h.check(response["kind"] == "error" and response["code"] == "ISSUER_HANDSHAKE_MISMATCH", "issuer/HELLO binding")
            server.finish()
        finally:
            server.cleanup()

    h.case("independent_wire_and_coalescing", independent_wire)

    def locking() -> None:
        state = h.work / "busy-b"
        server = Server(h, "busy", state, "B", 0, ["--idle-timeout-ms", "2000"])
        try:
            _, busy = h.run("busy-inspect", ["inspect", "--state", str(state), "--node", "B"], ok=False)
            h.check(busy and busy["code"] == "STATE_BUSY", "process lock")
            server.terminate()
        finally:
            server.cleanup()
        _, mismatch = h.run("metadata-mismatch", ["inspect", "--state", str(state), "--node", "C"], ok=False)
        h.check(mismatch and mismatch["code"] == "STATE_NODE_MISMATCH", "state node binding")

    h.case("state_lock_and_node_binding", locking)

    if h.profile == "full":
        def concurrent_case() -> None:
            b = h.work / "concurrent-b"
            count = 32
            server = Server(h, "concurrent", b, "B", count, ["--workers", "8", "--queue-capacity", "64"])
            try:
                def one(index: int) -> tuple[int, str, str]:
                    operation = op(f"concurrent-{index}")
                    args = offer_args(
                        h.work / f"concurrent-a{index}", f"A{index}", "B",
                        server.port, operation, f"payload-{index}")
                    completed = subprocess.run(
                        [str(h.binary), *args], text=True, capture_output=True,
                        timeout=15, env=h.env,
                    )
                    return completed.returncode, completed.stdout, completed.stderr

                with concurrent.futures.ThreadPoolExecutor(max_workers=count) as pool:
                    results = list(pool.map(one, range(count)))
                for index, (returncode, stdout, stderr) in enumerate(results):
                    h.check(returncode == 0, f"concurrent client {index}: {stdout} {stderr}")
                    h.check(json.loads(stdout)["ok"] is True, f"concurrent JSON {index}")
                stop = server.finish()
                h.check(stop["committed"] == count and stop["completed"] == count, "concurrent server progress")
            finally:
                server.cleanup()
            snapshot = h.inspect("concurrent-state", b, "B")
            h.check(snapshot["inbound"]["count"] == count, "all concurrent records durable")

        h.case("bounded_concurrent_clients", concurrent_case)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, default=Path("node/bin/natrav-overlay"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--profile", choices=("full", "focused"), default="full")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output directory must not exist")
    harness = Harness(args.binary, args.output, args.profile)
    started = time.time()
    try:
        run_suite(harness)
        status = "PASS"
        return_code = 0
    except BaseException as exc:
        status = "FAIL"
        return_code = 1
        (harness.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
    summary = {
        "format": "NATRAV_OVERLAY_NATIVE_TESTS_V1",
        "status": status,
        "profile": args.profile,
        "binary": str(harness.binary),
        "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
        "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
        "cases_total": len(harness.cases),
        "assertions": harness.assertions,
        "commands": len(harness.commands),
        "started_unix": started,
        "elapsed_seconds": time.time() - started,
    }
    (harness.output / "SUMMARY.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    (harness.output / "CASES.json").write_text(json.dumps(harness.cases, indent=2, sort_keys=True) + "\n")
    (harness.output / "COMMANDS.json").write_text(json.dumps(harness.commands, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, sort_keys=True))
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
