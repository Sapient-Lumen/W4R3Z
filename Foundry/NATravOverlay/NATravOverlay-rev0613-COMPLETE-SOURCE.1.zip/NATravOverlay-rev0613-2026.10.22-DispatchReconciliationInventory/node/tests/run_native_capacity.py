#!/usr/bin/env python3
"""Build and run exact production accounting tests outside the product tree."""
from __future__ import annotations
import argparse,hashlib,json,os,shutil,subprocess,time
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--mode',choices=('static','sanitize'),default='static');p.add_argument('--test',choices=('index','state'),default='index');a=p.parse_args()
    root=Path(__file__).resolve().parents[2];out=a.output.resolve()
    if out.exists() or out==root or root in out.parents:p.error('output must be new and outside the source tree')
    out.mkdir(parents=True);env=dict(os.environ,JOBS='2',PYTHONDONTWRITEBYTECODE='1',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    start=time.monotonic();test=root/'node/tests'/('test_pending_capacity.cpp' if a.test=='index' else 'test_pending_state.cpp')
    result={'format':'NATRAV_NATIVE_CAPACITY_TEST_V1','status':'FAIL','test':a.test,'mode':a.mode,'source_test_sha256':hashlib.sha256(test.read_bytes()).hexdigest()}
    if a.test=='index':
        binary=out/'capacity-test';cmd=['/usr/bin/g++','-std=c++20','-O1','-g0','-Wall','-Wextra','-Wpedantic','-Wconversion','-Wsign-conversion','-Wshadow','-Werror','-ffunction-sections','-fdata-sections','-I'+str(root/'foundation/include'),'-I'+str(root/'node/src')]
        if a.mode=='sanitize':cmd+=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie']
        cmd += [str(test),str(root/'node/src/pending_capacity.cpp'),str(root/'node/src/common.cpp'),'-Wl,--gc-sections','-o',str(binary)]
        cwd=root
    else:
        source=out/'source';source.mkdir()
        for name in ('node/src','foundation/src','foundation/include'):shutil.copytree(root/name,source/name)
        shutil.copy2(root/'node/build.sh',source/'node/build.sh');shutil.copy2(test,source/'node/src/main.cpp')
        cmd=['./node/build.sh',a.mode];cwd=source;binary=source/'node/bin'/('natrav-overlay-sanitize' if a.mode=='sanitize' else 'natrav-overlay')
    with (out/'BUILD.log').open('w') as f:build=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
    result['build_returncode']=build.returncode
    if build.returncode==0:
        run=subprocess.run([str(binary)],env=env,text=True,capture_output=True,timeout=180)
        (out/'stdout.txt').write_text(run.stdout);(out/'stderr.txt').write_text(run.stderr)
        result.update(returncode=run.returncode,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
        if run.returncode==0:result['result']=json.loads(run.stdout);result['status']='PASS'
    result['elapsed_seconds']=time.monotonic()-start;(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
    return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
