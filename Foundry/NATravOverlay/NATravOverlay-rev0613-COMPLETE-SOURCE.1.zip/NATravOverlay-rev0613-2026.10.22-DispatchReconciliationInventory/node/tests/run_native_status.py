#!/usr/bin/env python3
"""Build the production binding-cardinality test outside the source tree."""
from __future__ import annotations
import argparse, hashlib, json, os, subprocess, time
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--mode',choices=('static','sanitize'),default='static');a=p.parse_args()
    root=Path(__file__).resolve().parents[2];out=a.output.resolve()
    if out.exists() or out==root or root in out.parents:p.error('output must be new and outside source')
    out.mkdir(parents=True);binary=out/'status-bindings';start=time.monotonic()
    command=['/usr/bin/g++','-std=c++20','-O1','-g0','-Wall','-Wextra','-Wpedantic','-Wconversion','-Wsign-conversion','-Wshadow','-Werror','-I'+str(root/'node/src')]
    if a.mode=='sanitize':command+=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie']
    else:command+=['-static']
    command += [str(root/'node/tests/test_status_bindings.cpp'),str(root/'node/src/delivery_index.cpp'),'-o',str(binary)]
    environment=os.environ|{'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
    result={'format':'NATRAV_NATIVE_STATUS_BINDINGS_V1','status':'FAIL','mode':a.mode,'command':command}
    with (out/'BUILD.log').open('w') as log:build=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    result['build_returncode']=build.returncode
    if build.returncode==0:
        run=subprocess.run([str(binary)],env=environment,capture_output=True,text=True,timeout=240)
        (out/'stdout.txt').write_text(run.stdout);(out/'stderr.txt').write_text(run.stderr)
        result.update(returncode=run.returncode,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
        if run.returncode==0:result.update(status='PASS',result=json.loads(run.stdout))
    result['elapsed_seconds']=time.monotonic()-start;(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
    return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
