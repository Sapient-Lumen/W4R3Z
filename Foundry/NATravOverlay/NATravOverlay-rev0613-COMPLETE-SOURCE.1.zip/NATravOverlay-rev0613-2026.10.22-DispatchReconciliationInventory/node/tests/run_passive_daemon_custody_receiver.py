#!/usr/bin/env python3
"""V23 passive custody receipt through the ordinary authenticated NOS1 daemon."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import ssl
import struct
import subprocess
import sys
import threading
import time
from typing import Any

from run_persistent import Harness, free_port, operation
from run_peer_sessions import (
    SESSION_OPEN, SESSION_OPEN_ACK, SESSION_REQUEST, SESSION_RESPONSE,
    decode_session, encode_session, frame, receive_frame, submit, outbox_entry,
)
from run_integration import hello
from run_live_configuration import candidate, activate, rollback, wait_state
from run_runtime_adapter_configuration import upgrade, write
from run_handoff_key_policy import record as handoff_record
from run_native_durable_custody_session import (
    RULE_ID, RULE_GENERATION, cert_sha256, grant, service_rule, route,
    sha_file, send_command, service_root, parse_protocol_error,
)

ZERO = "0" * 64
ACTIVATION_ID = "r-passive"
PAUSE_BEFORE_ACCEPTANCE = (
    "NATRAV_OVERLAY_TEST_CUSTODY_SESSION_"
    "BEFORE_RECEIVER_ACCEPTANCE_PUBLICATION_MS"
)
PAUSE_AFTER_ACCEPTANCE = (
    "NATRAV_OVERLAY_TEST_CUSTODY_SESSION_"
    "AFTER_RECEIVER_ACCEPTANCE_PUBLICATION_MS"
)
PAUSE_BEFORE_JOURNAL = (
    "NATRAV_OVERLAY_TEST_CUSTODY_SESSION_"
    "BEFORE_RECEIVER_JOURNAL_COMMIT_MS"
)
DROP_AFTER_ADMISSION = "NATRAV_OVERLAY_TEST_SESSION_DROP_AFTER_ADMISSION_OPERATION"


def rule_commitment_text(record: str) -> str:
    lines = record.splitlines()
    assert lines[0] == "NATRAV_CUSTODY_SESSION_RULE_V1"
    assert lines[-1].startswith("state=")
    return "NATRAV_CUSTODY_SESSION_RULE_COMMITMENT_V1\n" + \
        "\n".join(lines[1:-1]) + "\n"


def rule_commitment(record: str) -> str:
    return hashlib.sha256(rule_commitment_text(record).encode("ascii")).hexdigest()


def activation(*, rule: str, state: str = "ACTIVE",
               maximum_inflight: int = 1,
               expiry_ms: int | None = None,
               rule_generation: int = RULE_GENERATION,
               commitment: str | None = None) -> str:
    if expiry_ms is None:
        values = dict(line.split("=", 1) for line in rule.splitlines()[1:])
        expiry_ms = int(values["authority_expires_unix_ms"])
    return "\n".join([
        "NATRAV_CUSTODY_RECEIVER_ACTIVATION_V1",
        f"id={ACTIVATION_ID}",
        "generation=1",
        f"predecessor_sha256={ZERO}",
        f"session_rule_id={RULE_ID}",
        f"session_rule_generation={rule_generation}",
        f"session_rule_commitment_sha256={commitment or rule_commitment(rule)}",
        f"maximum_inflight_offers={maximum_inflight}",
        f"activation_expires_unix_ms={expiry_ms}",
        f"state={state}",
        "",
    ])


def receiver_line(record: str) -> str:
    return f"custody_receiver_hex={record.encode('ascii').hex()}\n"


def policy_lines(bindings: list[bytes], relay_grant: str, rule: str) -> str:
    return "".join(
        f"handoff_key_hex={handoff_record(binding).encode('ascii').hex()}\n"
        for binding in bindings
    ) + f"custody_grant_hex={relay_grant.encode('ascii').hex()}\n" + \
        f"custody_service_hex={rule.encode('ascii').hex()}\n"


def with_receiver(text: str, record: str) -> str:
    lines = [line for line in text.splitlines()
             if not line.startswith("custody_receiver_hex=")]
    if lines[0] == "NATRAV_OVERLAY_CONFIG_V22":
        lines[0] = "NATRAV_OVERLAY_CONFIG_V23"
    if lines[0] != "NATRAV_OVERLAY_CONFIG_V23":
        raise AssertionError(f"receiver policy requires V23, got {lines[0]}")
    return "\n".join(lines) + "\n" + receiver_line(record)


def without_receiver_v22(text: str) -> str:
    lines = [line for line in text.splitlines()
             if not line.startswith("custody_receiver_hex=")]
    if lines[0] == "NATRAV_OVERLAY_CONFIG_V23":
        lines[0] = "NATRAV_OVERLAY_CONFIG_V22"
    return "\n".join(lines) + "\n"


def parse_json_output(stdout: str) -> dict[str, Any]:
    lines = [line for line in stdout.splitlines() if line.strip()]
    if not lines:
        raise AssertionError(f"missing JSON output: {stdout!r}")
    return json.loads(lines[-1])


def finish_process(h: Harness, label: str, process: subprocess.Popen[str],
                   timeout: float = 20.0) -> tuple[int, dict[str, Any], str]:
    stdout, stderr = process.communicate(timeout=timeout)
    (h.logs / f"process-{label}.stdout.txt").write_text(stdout)
    (h.logs / f"process-{label}.stderr.txt").write_text(stderr)
    assert process.returncode is not None
    return process.returncode, parse_json_output(stdout), stderr


def launch_command(h: Harness, args: list[str],
                   environment: dict[str, str] | None = None) -> subprocess.Popen[str]:
    env = os.environ.copy()
    if environment:
        env.update(environment)
    return subprocess.Popen(
        [str(h.binary), *args], text=True, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, env=env,
    )


def encode_offer(request_id: str, signed_offer: bytes) -> bytes:
    return b"NOA1" + bytes([9]) + bytes.fromhex(request_id) + \
        struct.pack("!I", len(signed_offer)) + signed_offer


def decode_acceptance(payload: bytes, request_id: str) -> bytes:
    if len(payload) < 41 or payload[:5] != b"NOA1\x0a":
        raise AssertionError(f"expected custody acceptance, got {payload[:16]!r}")
    if payload[5:37].hex() != request_id:
        raise AssertionError("custody acceptance request identity mismatch")
    size = struct.unpack("!I", payload[37:41])[0]
    if len(payload) != 41 + size or size == 0:
        raise AssertionError("custody acceptance byte length mismatch")
    return payload[41:]


class RawCustodySession:
    """Independent TLS/NOS1 client used to hold a session across live V23 changes."""

    def __init__(self, h: Harness, port: int, label: str):
        self.h = h
        self.label = label
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.minimum_version = ssl.TLSVersion.TLSv1_3
        context.maximum_version = ssl.TLSVersion.TLSv1_3
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        identity = h.identity("A")
        context.load_cert_chain(str(identity.certificate), str(identity.private_key))
        context.set_alpn_protocols(["natrav-overlay/1"])
        raw = socket.create_connection(("127.0.0.1", port), timeout=5)
        self.channel = context.wrap_socket(raw, server_hostname=None)
        self.channel.settimeout(8)
        hello_request = operation(f"rev0613-{label}-hello")
        self.channel.sendall(frame(hello("A", hello_request)))
        ack = json.loads(receive_frame(self.channel))
        if ack.get("kind") != "HELLO_ACK" or ack.get("request_id") != hello_request:
            raise AssertionError(f"HELLO_ACK mismatch: {ack!r}")
        self.session_id = hashlib.sha256(
            f"rev0613-{label}-session".encode("ascii")).digest()
        self.sequence = 0
        limits = (16, 4_194_304, 30_000, 8_000)
        self.channel.sendall(frame(encode_session(
            SESSION_OPEN, self.session_id, 0, b"\0" * 32, limits=limits)))
        opened = decode_session(receive_frame(self.channel))
        if opened["kind"] != SESSION_OPEN_ACK or opened["session"] != self.session_id:
            raise AssertionError(f"NOS1 OPEN_ACK mismatch: {opened!r}")

    def exchange(self, request_id: str, signed_offer: bytes) -> dict[str, Any]:
        self.sequence += 1
        request = bytes.fromhex(request_id)
        self.channel.sendall(frame(encode_session(
            SESSION_REQUEST, self.session_id, self.sequence, request,
            encode_offer(request_id, signed_offer))))
        response = decode_session(receive_frame(self.channel))
        if response["kind"] != SESSION_RESPONSE or \
                response["session"] != self.session_id or \
                response["sequence"] != self.sequence or \
                response["operation"] != request:
            raise AssertionError(f"NOS1 response mismatch: {response!r}")
        payload = response["payload"]
        if payload[:5] == b"NOA1\x0a":
            return {"kind": "acceptance",
                    "bytes": decode_acceptance(payload, request_id)}
        if payload[:5] == b"NOA1\x04":
            return {"kind": "error", **parse_protocol_error(payload)}
        raise AssertionError(f"unexpected application response: {payload[:16]!r}")

    def close(self) -> None:
        if self.channel is None:
            return
        try:
            self.sequence += 1
            self.channel.sendall(frame(encode_session(
                5, self.session_id, self.sequence, b"\0" * 32)))
            closed = decode_session(receive_frame(self.channel))
            if closed["kind"] != 6 or closed["sequence"] != self.sequence:
                raise AssertionError(f"NOS1 CLOSE_ACK mismatch: {closed!r}")
        finally:
            self.channel.close()
            self.channel = None  # type: ignore[assignment]


def case_directory(state: Path, request_id: str) -> Path:
    return service_root(state) / "cases" / request_id


def suite(h: Harness) -> None:
    h.work.chmod(0o700)
    values: dict[str, Any] = {}

    def initialize_and_validate_policy() -> None:
        version = h.run("version", ["version"])
        h.check(version is not None and version["version"] == "0613",
                "revision 0613 identity")
        h.check(version["custody_receiver_policy"] ==
                "V23_PASSIVE_DAEMON_CUSTODY_RECEIVER_V1" and
                version["passive_daemon_custody_receiver"] is True,
                "V23 passive receiver capability is explicit")
        h.check(version["automatic_custody_sender"] is False and
                version["automatic_route_relay"] is False and
                version["open_relay"] is False,
                "ordinary daemon receives only and gains no relay authority")

        a_state, r_state, c_state = (
            h.runtime / "a", h.runtime / "r", h.runtime / "c")
        a_port, r_port, c_port, dead_port = (
            free_port(), free_port(), free_port(), free_port())
        a_seed = h.config(
            "a-seed", "A", a_state, a_port,
            [("R", r_port, 50, 250, 16, 600_000)],
            deadline_ms=5_000, trusted=["R"])
        r_seed = h.config(
            "r-seed", "R", r_state, r_port,
            [("A", a_port, 50, 250, 16, 600_000),
             ("C", c_port, 50, 250, 16, 600_000)],
            deadline_ms=5_000, trusted=["A", "C"])
        c_seed = h.config(
            "c-seed", "C", c_state, c_port,
            [("R", r_port, 50, 250, 16, 600_000)],
            deadline_ms=5_000, trusted=["R"])
        for node, seed in (("A", a_seed), ("R", r_seed), ("C", c_seed)):
            write(seed, upgrade(seed.read_text(), f"{node.lower()}-v19", 19))
            daemon = h.start(f"initialize-{node}", seed,
                             {"A": a_state, "R": r_state, "C": c_state}[node])
            if node == "A":
                for name in (
                    "disabled", "capacity-one", "capacity-two", "loss",
                    "crash", "retire", "retired-new", "expired",
                ):
                    op = operation(f"rev0613-passive-custody-{name}")
                    submit(h, f"queue-{name}", daemon.control, "A", "R",
                           "test/three", op, f"passive custody {name}")
                    values[f"operation-{name}"] = op
            daemon.shutdown()

        for node, seed in (("A", a_seed), ("R", r_seed)):
            key = h.work / f"{node.lower()}-handoff"
            initialized = h.run(f"handoff-key-{node}", [
                "handoff-key-init", "--config", str(seed),
                "--key-directory", str(key),
                "--generation", f"{node.lower()}-h1",
            ])
            binding = (key / "binding.nhkb").read_bytes()
            h.check(initialized is not None and
                    initialized["binding_sha256"] == hashlib.sha256(binding).hexdigest(),
                    f"{node} exact handoff binding")
            values[f"{node}key"] = key
            values[f"{node}binding"] = binding

        relay = grant(maximum_active=16, maximum_lifetime_ms=900_000)
        authority_expiry = int(time.time() * 1000) + 900_000
        rule = service_rule(
            relay_grant=relay,
            a_certificate=cert_sha256(h.identity("A").certificate),
            r_certificate=cert_sha256(h.identity("R").certificate),
            maximum_pending=16,
            maximum_window_ms=600_000,
            expiry_ms=authority_expiry,
        )
        records = policy_lines(
            [values["Abinding"], values["Rbinding"]], relay, rule)
        for node, seed, state in (
            ("A", a_seed, a_state), ("R", r_seed, r_state)):
            def modify(text: str, *, node: str = node) -> str:
                extra = ""
                if node == "A":
                    extra = (
                        f"peer_route=R,dead,1,ENABLED,127.0.0.1:{dead_port}\n")
                return text.replace("CONFIG_V19", "CONFIG_V22", 1) + extra + records
            config = candidate(
                h, seed, f"{node.lower()}-v22", f"{node.lower()}-v22", modify)
            checked = h.run(f"check-{node}-v22", [
                "config-check", "--config", str(config)])
            h.check(checked is not None and
                    checked["format"] == "NATRAV_OVERLAY_CONFIG_V22",
                    f"{node} exact V22 policy accepted")
            daemon = h.start(f"activate-{node}-v22", seed, state)
            activate(h, f"activate-{node}-v22", state, config)
            daemon.shutdown()
            values[f"{node}v22"] = config

        active_record = activation(
            rule=rule, state="ACTIVE", maximum_inflight=1,
            expiry_ms=authority_expiry - 1_000)
        r_active = candidate(
            h, values["Rv22"], "r-v23-active", "r-v23-active",
            lambda text: with_receiver(text, active_record))
        checked = h.run("check-r-v23-active", [
            "config-check", "--config", str(r_active)])
        h.check(checked is not None and
                checked["format"] == "NATRAV_OVERLAY_CONFIG_V23" and
                checked["custody_receiver_policy"]["activations"][0]["state"] == "ACTIVE" and
                checked["custody_receiver_policy"]["activations"][0]["maximum_inflight_offers"] == 1,
                "canonical V23 receiver activation is inspectable")

        # V23 is rejected in an older format.
        old = candidate(
            h, values["Rv22"], "receiver-old-format", "receiver-old-format",
            lambda text: text + receiver_line(active_record))
        rejected = h.run("receiver-old-format", [
            "config-check", "--config", str(old)], expected=3)
        h.check(rejected is not None and rejected["code"] == "CONFIG_VERSION_REJECTED",
                "V23 record cannot enter V22")

        wrong_generation = candidate(
            h, values["Rv22"], "receiver-wrong-generation",
            "receiver-wrong-generation",
            lambda text: with_receiver(text, activation(
                rule=rule, rule_generation=2,
                expiry_ms=authority_expiry - 1_000)))
        rejected = h.run("receiver-wrong-generation", [
            "config-check", "--config", str(wrong_generation)], expected=3)
        h.check(rejected is not None and
                rejected["code"] == "CONFIG_CUSTODY_RECEIVER_RULE",
                "V23 cannot name an absent V22 generation")

        wrong_commitment = candidate(
            h, values["Rv22"], "receiver-wrong-commitment",
            "receiver-wrong-commitment",
            lambda text: with_receiver(text, activation(
                rule=rule, commitment="11" * 32,
                expiry_ms=authority_expiry - 1_000)))
        rejected = h.run("receiver-wrong-commitment", [
            "config-check", "--config", str(wrong_commitment)], expected=3)
        h.check(rejected is not None and
                rejected["code"] == "CONFIG_CUSTODY_RECEIVER_RULE",
                "V23 commits the exact immutable V22 rule")

        wrong_role = candidate(
            h, values["Av22"], "receiver-wrong-role", "receiver-wrong-role",
            lambda text: with_receiver(text, active_record))
        rejected = h.run("receiver-wrong-role", [
            "config-check", "--config", str(wrong_role)], expected=3)
        h.check(rejected is not None and
                rejected["code"] == "CONFIG_CUSTODY_RECEIVER_LOCAL_ROLE",
                "V23 is accepted only at the exact V21 next hop")

        unfair = candidate(
            h, values["Rv22"], "receiver-unfair", "receiver-unfair",
            lambda text: with_receiver(text, activation(
                rule=rule, maximum_inflight=4,
                expiry_ms=authority_expiry - 1_000)))
        rejected = h.run("receiver-unfair", [
            "config-check", "--config", str(unfair)], expected=3)
        h.check(rejected is not None and
                rejected["code"] == "CONFIG_CUSTODY_RECEIVER_FAIRNESS",
                "receiver concurrency reserves an ordinary peer worker")

        too_late = candidate(
            h, values["Rv22"], "receiver-expiry-too-late",
            "receiver-expiry-too-late",
            lambda text: with_receiver(text, activation(
                rule=rule, expiry_ms=authority_expiry + 1)))
        rejected = h.run("receiver-expiry-too-late", [
            "config-check", "--config", str(too_late)], expected=3)
        h.check(rejected is not None and
                rejected["code"] == "CONFIG_CUSTODY_RECEIVER_LIMIT",
                "V23 expiry cannot outlive V22")

        route_file = route(h.work / "a-r-route.txt",
                           [values["Abinding"], values["Rbinding"]])

        def build_bundle(name: str) -> Path:
            capsule = h.work / f"{name}.nhcp"
            exported = h.run(f"handoff-export-{name}", [
                "handoff-export", "--config", str(a_seed),
                "--key-directory", str(values["Akey"]),
                "--recipient-binding", str(values["Rkey"] / "binding.nhkb"),
                "--recipient-binding-sha256",
                sha_file(values["Rkey"] / "binding.nhkb"),
                "--operation-id", values[f"operation-{name}"],
                "--kind", "operation",
                "--expires-ms", str(int(time.time() * 1000) + 300_000),
                "--output", str(capsule),
            ])
            h.check(exported is not None and
                    exported["status"] == "EXPORTED_NOT_DELIVERED",
                    f"{name} capsule export does not imply delivery")
            bundle = h.work / f"{name}.nhcb"
            now = int(time.time() * 1000)
            created = h.run(f"custody-create-{name}", [
                "custody-create", "--config", str(a_seed),
                "--route", str(route_file), "--capsule", str(capsule),
                "--created-ms", str(now),
                "--expires-ms", str(now + 240_000),
                "--output", str(bundle),
            ])
            h.check(created is not None and
                    created["status"] == "CREATED_CUSTODY_HELD",
                    f"{name} canonical custody bundle created")
            return bundle

        bundles = {name: build_bundle(name) for name in (
            "disabled", "capacity-one", "capacity-two", "loss",
            "crash", "retire", "retired-new", "expired",
        )}
        values.update({
            "Aseed": a_seed, "Rseed": r_seed, "Cseed": c_seed,
            "Astate": a_state, "Rstate": r_state, "Cstate": c_state,
            "r_port": r_port, "rule": rule, "relay": relay,
            "authority_expiry": authority_expiry,
            "active_record": active_record, "Ractive": r_active,
            "bundles": bundles,
        })

    h.case("accepted_v23_policy_and_negative_controls", initialize_and_validate_policy)

    def unresolved_offer(name: str, route_id: str = "default") -> tuple[str, Path, dict[str, Any]]:
        result = h.run(f"prepare-{name}", send_command(
            values["Aseed"], values["bundles"][name], route_id),
            expected=4, timeout=15)
        h.check(result is not None and result["status"] == "UNRESOLVED" and
                result["acceptance_durable"] is False,
                f"{name} offer remains explicit unresolved custody")
        request = result["request_id"]
        directory = case_directory(values["Astate"], request)
        h.check((directory / "offer.bin").is_file() and
                not (directory / "acceptance.bin").exists(),
                f"{name} retains exact offer without invented acceptance")
        return request, directory, result

    def default_off_and_live_activation_on_open_session() -> None:
        r = h.start("receiver-disabled", values["Rseed"], values["Rstate"])
        c = h.start("ordinary-c-disabled", values["Cseed"], values["Cstate"])
        disabled = h.run("disabled-custody-send", send_command(
            values["Aseed"], values["bundles"]["disabled"]),
            expected=4, timeout=15)
        h.check(disabled is not None and disabled["status"] == "UNRESOLVED" and
                "CUSTODY_RECEIVER_DISABLED" in disabled["detail"],
                "V22 ordinary daemon is default-off for custody")
        request = disabled["request_id"]
        a_case = case_directory(values["Astate"], request)
        signed_offer = (a_case / "offer.bin").read_bytes()

        ordinary = operation("rev0613-disabled-ordinary-operation")
        submit(h, "disabled-ordinary-submit", c.control, "C", "R",
               "test/three", ordinary, "ordinary semantics while custody disabled")
        wait_state(h, values["Cstate"], ordinary, "ACKED",
                   "disabled-ordinary-acked")
        r_status = h.status("disabled-r-status", values["Rstate"])
        h.check(r_status["inbound_records"] == 1,
                "disabled custody does not affect ordinary application admission")

        session = RawCustodySession(h, values["r_port"], "live-enable")
        activate(h, "activate-r-v23-active", values["Rstate"], values["Ractive"])
        response = session.exchange(request, signed_offer)
        h.check(response["kind"] == "acceptance",
                "already-open NOS1 session observes newly active V23 per operation")
        acceptance = response["bytes"]
        session.close()

        recovered = h.run("active-exact-recovery", send_command(
            values["Aseed"], values["bundles"]["disabled"]), timeout=15)
        h.check(recovered is not None and recovered["status"] == "ACCEPTED" and
                recovered["attempts"] == 2,
                "explicit sender recovers the daemon-retained acceptance")
        r_case = case_directory(values["Rstate"], request)
        h.check((a_case / "acceptance.bin").read_bytes() == acceptance and
                (r_case / "acceptance.bin").read_bytes() == acceptance,
                "live activation recovery is byte-identical at both endpoints")
        after = h.status("active-r-status", values["Rstate"])
        h.check(after["runtime_configuration"]["generation"] == "r-v23-active" and
                after["inbound_records"] == 1,
                "custody receipt changes neither application records nor delivery semantics")
        values["disabled_request"] = request
        values["disabled_acceptance"] = acceptance
        c.shutdown(); r.shutdown()

    h.case("default_off_and_live_activation_on_existing_session",
           default_off_and_live_activation_on_open_session)

    def bounded_fairness_and_concurrent_ordinary_progress() -> None:
        first_request, first_case, _ = unresolved_offer("capacity-one")
        second_request, second_case, _ = unresolved_offer("capacity-two")
        r = h.start("receiver-capacity", values["Rseed"], values["Rstate"],
                    {PAUSE_BEFORE_ACCEPTANCE: "1200"})
        c = h.start("ordinary-c-capacity", values["Cseed"], values["Cstate"])

        first_session = RawCustodySession(
            h, values["r_port"], "capacity-first")
        first_result: dict[str, Any] = {}
        first_error: list[BaseException] = []

        def exchange_first() -> None:
            try:
                first_result.update(first_session.exchange(
                    first_request, (first_case / "offer.bin").read_bytes()))
            except BaseException as exc:
                first_error.append(exc)

        first_thread = threading.Thread(target=exchange_first, daemon=True)
        first_thread.start()
        h.wait("first custody offer reaches bounded receiver", lambda:
               PAUSE_BEFORE_ACCEPTANCE in r.stderr_path.read_text(), 8)

        second_session = RawCustodySession(
            h, values["r_port"], "capacity-second")
        second = second_session.exchange(
            second_request, (second_case / "offer.bin").read_bytes())
        h.check(second["kind"] == "error" and
                second["code"] == "CUSTODY_RECEIVER_BUSY",
                "finite V23 concurrency rejects a second simultaneous offer")

        ordinary = operation("rev0613-capacity-ordinary-operation")
        submit(h, "capacity-ordinary-submit", c.control, "C", "R",
               "test/three", ordinary, "ordinary progress beside paused custody")
        ordinary_status = wait_state(
            h, values["Cstate"], ordinary, "ACKED", "capacity-ordinary-acked")
        h.check(outbox_entry(ordinary_status, ordinary)["status"] == "ACKED",
                "reserved peer worker preserves ordinary application progress")
        h.check(first_thread.is_alive(),
                "ordinary operation completed while custody admission remained in flight")

        first_thread.join(timeout=12)
        h.check(not first_thread.is_alive() and not first_error and
                first_result.get("kind") == "acceptance",
                f"first bounded custody operation completes: {first_error!r} {first_result!r}")
        first_session.close(); second_session.close()

        first_recovery = h.run("capacity-first-recovery", send_command(
            values["Aseed"], values["bundles"]["capacity-one"]), timeout=15)
        h.check(first_recovery is not None and
                first_recovery["status"] == "ACCEPTED" and
                first_recovery["attempts"] == 2,
                "explicit sender recovers first daemon acceptance")
        retry = h.run("capacity-second-retry", send_command(
            values["Aseed"], values["bundles"]["capacity-two"]), timeout=20)
        h.check(retry is not None and retry["status"] == "ACCEPTED" and
                retry["attempts"] == 2,
                "busy response preserves exact unresolved offer for explicit retry")
        h.check((first_case / "acceptance.bin").is_file() and
                (second_case / "acceptance.bin").is_file() and
                case_directory(values["Rstate"], first_request).is_dir() and
                case_directory(values["Rstate"], second_request).is_dir(),
                "both bounded cases retain exact durable evidence")
        r_status = h.status("capacity-r-status", values["Rstate"])
        h.check(r_status["outbox"]["pending"] == 0 and
                r_status["outbox"]["unresolved"] == 0,
                "passive receipt schedules no sender or automatic second hop")
        c.shutdown(); r.shutdown()

    h.case("bounded_fairness_and_concurrent_ordinary_progress",
           bounded_fairness_and_concurrent_ordinary_progress)

    def response_loss_process_death_restart_and_stale_seed() -> None:
        loss_request, loss_case, _ = unresolved_offer("loss")
        r = h.start("receiver-response-loss", values["Rseed"], values["Rstate"],
                    {DROP_AFTER_ADMISSION: loss_request})
        lost = h.run("response-loss-send", send_command(
            values["Aseed"], values["bundles"]["loss"]),
            expected=4, timeout=15)
        h.check(lost is not None and lost["status"] == "UNRESOLVED" and
                (case_directory(values["Rstate"], loss_request) /
                 "acceptance.bin").is_file(),
                "lost NOS1 response remains unresolved after durable receiver acceptance")
        retained = (case_directory(values["Rstate"], loss_request) /
                    "acceptance.bin").read_bytes()
        r.shutdown()
        r = h.start("receiver-response-recovery", values["Rseed"], values["Rstate"])
        recovered = h.run("response-loss-retry", send_command(
            values["Aseed"], values["bundles"]["loss"]), timeout=15)
        h.check(recovered is not None and recovered["status"] == "ACCEPTED" and
                (loss_case / "acceptance.bin").read_bytes() == retained,
                "restart retry recovers only the exact retained acceptance")
        r.shutdown()

        crash_request, crash_case, _ = unresolved_offer("crash")
        r = h.start("receiver-process-death", values["Rseed"], values["Rstate"],
                    {PAUSE_AFTER_ACCEPTANCE: "5000"})
        sender = launch_command(h, send_command(
            values["Aseed"], values["bundles"]["crash"]))
        h.wait("receiver publishes acceptance before process death", lambda:
               PAUSE_AFTER_ACCEPTANCE in r.stderr_path.read_text(), 8)
        r_case = case_directory(values["Rstate"], crash_request)
        h.check((r_case / "acceptance.bin").is_file(),
                "acceptance bytes are durable at the process-death boundary")
        crash_acceptance = (r_case / "acceptance.bin").read_bytes()
        r.kill()
        rc, result, _ = finish_process(h, "crash-sender", sender, 15)
        h.check(rc == 4 and result["status"] == "UNRESOLVED",
                "receiver death cannot manufacture sender certainty")

        # The startup path deliberately names the stale accepted V19 seed. The
        # authenticated configuration journal must select the active V23 record.
        r = h.start("receiver-stale-seed-restart", values["Rseed"], values["Rstate"])
        status = h.status("stale-seed-active-status", values["Rstate"])
        h.check(status["runtime_configuration"]["generation"] == "r-v23-active",
                "stale startup seed cannot disable accepted V23 authority")
        recovered = h.run("crash-restart-retry", send_command(
            values["Aseed"], values["bundles"]["crash"]), timeout=15)
        h.check(recovered is not None and recovered["status"] == "ACCEPTED" and
                (crash_case / "acceptance.bin").read_bytes() == crash_acceptance and
                (r_case / "acceptance.bin").read_bytes() == crash_acceptance,
                "post-death recovery commits and replays the same acceptance bytes")
        r.shutdown()

    h.case("response_loss_process_death_restart_and_stale_seed",
           response_loss_process_death_restart_and_stale_seed)

    def retirement_revocation_inflight_and_expiry() -> None:
        retire_request, retire_case, _ = unresolved_offer("retire")
        new_request, new_case, _ = unresolved_offer("retired-new")
        retired_record = activation(
            rule=values["rule"], state="RETIRED", maximum_inflight=1,
            expiry_ms=values["authority_expiry"] - 1_000)
        r_retired = candidate(
            h, values["Ractive"], "r-v23-retired", "r-v23-retired",
            lambda text: with_receiver(text, retired_record))
        revoked_record = activation(
            rule=values["rule"], state="REVOKED", maximum_inflight=1,
            expiry_ms=values["authority_expiry"] - 1_000)
        r_revoked = candidate(
            h, r_retired, "r-v23-revoked", "r-v23-revoked",
            lambda text: with_receiver(text, revoked_record))

        r = h.start("receiver-inflight-retire", values["Rseed"], values["Rstate"],
                    {PAUSE_BEFORE_JOURNAL: "1200"})
        sender = launch_command(h, send_command(
            values["Aseed"], values["bundles"]["retire"]))
        h.wait("in-flight acceptance reaches journal boundary", lambda:
               PAUSE_BEFORE_JOURNAL in r.stderr_path.read_text(), 8)
        activation_process = launch_command(h, [
            "config-activate", "--control", str(values["Rstate"] / "control.sock"),
            "--candidate", str(r_retired), "--reason", "inflight-retirement",
            "--deadline-ms", "10000",
        ])
        time.sleep(0.25)
        h.check(activation_process.poll() is None,
                "live retirement waits for the in-flight durable V23 lease")
        rc, sent, err = finish_process(h, "retire-sender", sender, 20)
        h.check(rc == 0 and sent["status"] == "ACCEPTED",
                f"in-flight operation completes under its active lease: {err!r}")
        rc, activated, err = finish_process(
            h, "retire-activation", activation_process, 20)
        h.check(rc == 0 and activated.get("ok") is True,
                f"retirement publishes after the operation boundary: {err!r}")
        retained = (retire_case / "acceptance.bin").read_bytes()

        replay_session = RawCustodySession(h, values["r_port"], "retired-replay")
        replay = replay_session.exchange(
            retire_request, (retire_case / "offer.bin").read_bytes())
        denied = replay_session.exchange(
            new_request, (new_case / "offer.bin").read_bytes())
        replay_session.close()
        h.check(replay["kind"] == "acceptance" and replay["bytes"] == retained,
                "RETIRED replays only the exact retained acceptance")
        h.check(denied["kind"] == "error" and
                denied["code"] == "CUSTODY_RECEIVER_RETIRED",
                "RETIRED admits no new custody offer")

        activate(h, "activate-r-v23-revoked", values["Rstate"], r_revoked)
        revoked_session = RawCustodySession(h, values["r_port"], "revoked-replay")
        revoked = revoked_session.exchange(
            retire_request, (retire_case / "offer.bin").read_bytes())
        revoked_session.close()
        h.check(revoked["kind"] == "error" and
                revoked["code"] == "CUSTODY_RECEIVER_REVOKED",
                "REVOKED admits and replays nothing")

        rollback(h, "receiver-active-rollback-rejected", values["Rstate"],
                 "r-v23-active", expected=3,
                 code="CONFIG_CUSTODY_RECEIVER_STATE_ROLLBACK")
        downgrade = candidate(
            h, r_revoked, "r-v22-downgrade", "r-v22-downgrade",
            without_receiver_v22)
        activate(h, "receiver-v22-downgrade-rejected", values["Rstate"],
                 downgrade, expected=3,
                 code="CONFIG_CUSTODY_RECEIVER_DOWNGRADE")
        r.shutdown()

        r = h.start("receiver-revoked-stale-seed", values["Rseed"], values["Rstate"])
        status = h.status("revoked-stale-seed-status", values["Rstate"])
        h.check(status["runtime_configuration"]["generation"] == "r-v23-revoked",
                "restart reconstructs monotonic V23 revocation from journal")
        restarted = RawCustodySession(h, values["r_port"], "revoked-restart")
        rejected = restarted.exchange(
            retire_request, (retire_case / "offer.bin").read_bytes())
        restarted.close()
        h.check(rejected["kind"] == "error" and
                rejected["code"] == "CUSTODY_RECEIVER_REVOKED",
                "stale startup file cannot resurrect replay authority")
        r.shutdown()

        # An expired activation is accepted as retained policy but behaves as
        # retired for new offers. Use a fresh state so prior revocation history
        # cannot be confused with expiry behavior.
        expired_request, _, _ = unresolved_offer("expired")
        expired_state = h.runtime / "r-expired"
        expired_record = activation(
            rule=values["rule"], state="ACTIVE", maximum_inflight=1,
            expiry_ms=int(time.time() * 1000) - 1)
        lines: list[str] = []
        for line in values["Ractive"].read_text().splitlines():
            if line.startswith("state="):
                lines.append(f"state={expired_state}")
            elif line.startswith("runtime_generation=") or \
                    line.startswith("custody_receiver_hex="):
                continue
            else:
                lines.append(line)
        lines.append(receiver_line(expired_record).strip())
        lines.append("runtime_generation=r-v23-expired-bootstrap")
        expired_config = h.work / "r-v23-expired.conf"
        expired_config.write_text("\n".join(lines) + "\n")
        expired_config.chmod(0o600)
        checked = h.run("check-expired-v23", [
            "config-check", "--config", str(expired_config)])
        h.check(checked is not None and
                checked["custody_receiver_policy"]["activations"][0]["state"] == "ACTIVE",
                "expired timestamp does not erase retained V23 policy")
        expired_daemon = h.start(
            "receiver-expired", expired_config, expired_state)
        result = h.run("expired-new-offer", send_command(
            values["Aseed"], values["bundles"]["expired"]),
            expected=4, timeout=15)
        h.check(result is not None and result["request_id"] == expired_request and
                "CUSTODY_RECEIVER_RETIRED" in result["detail"],
                "expired V23 activation admits no new offer")
        expired_daemon.shutdown()

    h.case("retirement_revocation_inflight_restart_and_expiry",
           retirement_revocation_inflight_and_expiry)

    def negative_authority_and_no_automatic_second_hop() -> None:
        version = h.run("final-service-version", ["custody-service-v1-version"])
        h.check(version is not None and version["revision"] == "0613" and
                version["passive_daemon_custody_receiver"] ==
                    "V23_DEFAULT_OFF_EXACT_RULE_V1" and
                version["automatic_custody_sender"] is False and
                version["automatic_route_relay"] is False and
                version["open_relay"] is False and
                version["application_delivery_inferred"] is False,
                "service surface states the passive non-relay authority boundary")
        offline = h.run("final-r-inspect", [
            "inspect", "--state", str(values["Rstate"]), "--node", "R"])
        h.check(offline is not None and offline["outbox"]["count"] == 0,
                "accepted custody creates no ordinary outbound work")
        custody_root = values["Rstate"] / "custody-session-v1"
        rule_roots = sorted(
            path.relative_to(custody_root).as_posix()
            for path in custody_root.glob("*/*") if path.is_dir())
        h.check(rule_roots == [f"{RULE_ID}/{RULE_GENERATION}"],
                "daemon creates no implicit second-hop custody service")
        forbidden = [
            path for path in values["Rstate"].rglob("*")
            if path.is_file() and any(token in path.name.lower() for token in (
                "delivery-receipt", "application-success", "auto-forward",
                "discovery", "fallback-route"))
        ]
        h.check(not forbidden,
                "passive receiver creates no delivery, discovery, or forwarding sidecar")

    h.case("negative_authority_and_no_automatic_second_hop",
           negative_authority_and_no_automatic_second_hop)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not exist")
    h = Harness(args.binary, args.output)
    started = time.monotonic()
    code = 1
    try:
        suite(h)
        code = 0
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(
            f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
    finally:
        h.cleanup()
        report = {
            "format": "NATRAV_PASSIVE_DAEMON_CUSTODY_RECEIVER_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "assertions": h.assertions,
            "cases": h.cases,
            "commands": h.commands,
            "elapsed_seconds": time.monotonic() - started,
        }
        (h.output / "RESULT.json").write_text(
            json.dumps(report, indent=2, sort_keys=True) + "\n")
        summary = {
            "format": report["format"],
            "status": report["status"],
            "binary_sha256": report["binary_sha256"],
            "assertions": report["assertions"],
            "cases": report["cases"],
            "cases_passed": sum(case.get("status") == "PASS"
                                for case in report["cases"]),
            "cases_total": len(report["cases"]),
            "commands": len(report["commands"]),
            "elapsed_seconds": report["elapsed_seconds"],
            "failure": None if code == 0 else
                (h.output / "FAILURE.txt").read_text().strip(),
        }
        (h.output / "SUMMARY.json").write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n")
        print(json.dumps({
            "format": report["format"], "status": report["status"],
            "assertions": report["assertions"],
            "cases_passed": summary["cases_passed"],
            "cases_total": summary["cases_total"],
            "commands": summary["commands"],
        }, sort_keys=True))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
