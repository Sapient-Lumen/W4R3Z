#!/usr/bin/env python3
"""Actual revision-0568 rejection of kinds 46/47 and replay of their durable result."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import struct
import time
import traceback

from run_persistent import Harness, raw_control
from run_control_authorization import packet, text
from run_correlated_terminal_state_head import (
    correlated_terminal_shutdown,
    request_id,
    setup_keyed,
    terminal_args,
    verify_stopped,
)
from run_state_authentication import inspect


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--predecessor-binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    harness = Harness(args.binary, args.output)
    release = harness.binary
    predecessor = args.predecessor_binary.resolve(strict=True)
    started = time.time()
    code = 1
    try:
        def boundary() -> None:
            harness.binary = predecessor
            _, old_state, old_key, _, old_daemon = setup_keyed(harness, "actual-predecessor-correlated-terminal")
            for command in ("shutdown", "drain-shutdown"):
                argv = [
                    command, "--control", str(old_daemon.control),
                    "--correlation", "unsupported-terminal-correlation",
                    "--final-state-head", "yes",
                    "--deadline-ms", "3000",
                ]
                if command == "drain-shutdown":
                    argv += ["--reason", "predecessor rejection", "--drain-deadline-ms", "100"]
                rejected = harness.run("predecessor-cli-rejects-" + command, argv, expected=3)
                harness.check(rejected is not None and rejected.get("code") == "CONTROL_PROTOCOL_REJECTED", "revision 0568 CLI fails closed on combined terminal correlation")
                harness.check(old_daemon.process is not None and old_daemon.process.poll() is None, "predecessor CLI rejection cannot stop process")
            for kind, body in (
                (46, text("unsupported-terminal-correlation")),
                (47, struct.pack("!I", 100) + text("predecessor rejection") + text("unsupported-terminal-correlation")),
            ):
                ok, rejected = raw_control(old_daemon.control, packet(kind, body))
                harness.check(not ok and rejected.get("code") == "CONTROL_PROTOCOL_REJECTED" and "state_head" not in rejected, "revision 0568 server rejects unknown correlated terminal kind")
                harness.check(old_daemon.process is not None and old_daemon.process.poll() is None, "unknown wire kind cannot stop predecessor")
            legacy = harness.run(
                "predecessor-terminal-still-works",
                ["shutdown", "--control", str(old_daemon.control), "--final-state-head", "yes", "--deadline-ms", "12000"],
            )
            harness.check(legacy is not None and legacy["format"] == "NATRAV_OVERLAY_TERMINAL_STATE_HEAD_V1", "predecessor legacy terminal protocol remains functional")
            assert old_daemon.process
            old_daemon.process.wait(timeout=12)
            harness.check(old_daemon.process.returncode == 0, "predecessor legacy terminal stop exits")
            old_daemon._close_files()
            inspect(harness, "predecessor-legacy-offline", old_state, old_key)

            harness.binary = release
            token = "compat-0568-replay"
            expected = request_id(correlated_terminal_shutdown(token))
            _, state, key, _, daemon = setup_keyed(harness, "current-correlated-terminal")
            value = harness.run("current-correlated-terminal-stop", terminal_args(daemon.control, token))
            assert value is not None
            current_snapshot = verify_stopped(harness, "current-correlated-terminal", daemon, state, key, value, token, expected, drain=False)
            raw = (state / "state.journal").read_bytes()
            raw_hash = hashlib.sha256(raw).hexdigest()

            harness.binary = predecessor
            previous = inspect(harness, "predecessor-replays-current-correlated-terminal", state, key)
            harness.check(previous["storage"]["logical_state_digest"] == current_snapshot["storage"]["logical_state_digest"], "predecessor and current binary derive the same logical state")
            harness.check(previous["state_head"]["selector"] == value["state_head"]["selector"], "predecessor derives the same authenticated head")
            harness.check(hashlib.sha256((state / "state.journal").read_bytes()).hexdigest() == raw_hash, "predecessor replay leaves exact bytes unchanged")

        harness.case("actual_predecessor_wire_cli_and_durable_replay", boundary)
        code = 0
    except BaseException:
        (harness.output / "FAILURE.txt").write_text(traceback.format_exc())
    finally:
        harness.binary = release
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_CORRELATED_TERMINAL_COMPATIBILITY_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(release.read_bytes()).hexdigest(),
            "predecessor_sha256": hashlib.sha256(predecessor.read_bytes()).hexdigest(),
            "cases_passed": sum(item["status"] == "PASS" for item in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (
            ("SUMMARY.json", summary),
            ("CASES.json", harness.cases),
            ("COMMANDS.json", harness.commands),
        ):
            (harness.output / name).write_text(json.dumps(value, indent=2) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
