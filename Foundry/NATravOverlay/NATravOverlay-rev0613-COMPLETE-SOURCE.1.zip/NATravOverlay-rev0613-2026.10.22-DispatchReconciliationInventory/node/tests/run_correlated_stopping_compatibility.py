#!/usr/bin/env python3
"""Actual predecessor rejects correlated stop CLI/wire kinds without stopping."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

from run_persistent import Harness, free_port, raw_control
from run_local_administration import v8_config
from run_control_authorization import packet, text
from run_correlated_stopping import correlated_drain, correlated_shutdown, lifecycle_kinds
from run_response_loss_stopping import wait_stopped


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--previous-binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    harness = Harness(args.binary, args.output)
    previous = args.previous_binary.resolve(strict=True)
    started = time.time()
    code = 1
    try:
        state = harness.runtime / "predecessor-correlated"
        config = v8_config(
            harness,
            "predecessor-correlated",
            "A",
            state,
            free_port(),
            "predecessor-correlated-g1",
            [(os.geteuid(), ["ALL"])],
        )
        current = harness.binary
        harness.binary = previous
        daemon = harness.start("predecessor-correlated", config, state)
        harness.binary = current

        for label, payload in (
            ("immediate", correlated_shutdown("predecessor-immediate")),
            ("drain", correlated_drain(100, "predecessor drain", "predecessor-drain")),
        ):
            ok, result = raw_control(daemon.control, payload)
            harness.check(not ok and result.get("ok") is False, label + " new wire kind fails closed")
            harness.check(daemon.process is not None and daemon.process.poll() is None, label + " rejection cannot stop predecessor")
            status = harness.status("predecessor-running-" + label, state, logical_digest=False)
            harness.check(status["lifecycle"]["mode"] == "RUNNING", label + " preserves predecessor service mode")

        cli = subprocess.run(
            [
                str(previous), "shutdown", "--control", str(daemon.control),
                "--correlation", "predecessor-cli", "--deadline-ms", "2000",
            ],
            capture_output=True,
            text=True,
            timeout=5,
            env=os.environ.copy(),
        )
        harness.commands.append({
            "label": "predecessor-cli-rejection",
            "args": ["shutdown", "--correlation", "predecessor-cli"],
            "returncode": cli.returncode,
            "stdout": cli.stdout,
            "stderr": cli.stderr,
        })
        response = json.loads(cli.stdout.strip().splitlines()[-1])
        harness.check(cli.returncode == 3 and response.get("code") == "UNKNOWN_ARGUMENT", "predecessor CLI does not silently drop correlation")
        harness.check(daemon.process is not None and daemon.process.poll() is None, "CLI rejection leaves predecessor running")

        daemon.shutdown()
        before = (state / "state.journal").read_bytes()
        old_read = subprocess.run(
            [str(previous), "inspect", "--state", str(state), "--node", "A"],
            capture_output=True, text=True, timeout=5, env=os.environ.copy(),
        )
        harness.check(old_read.returncode == 0, "predecessor replays its stopped state")
        old_snapshot = json.loads(old_read.stdout.strip().splitlines()[-1])
        snapshot = harness.run("new-reader-of-predecessor-state", ["inspect", "--state", str(state), "--node", "A"])
        assert snapshot is not None
        harness.check(snapshot["storage"]["logical_state_digest"] == old_snapshot["storage"]["logical_state_digest"], "old and new readers agree on identical predecessor bytes")
        harness.check((state / "state.journal").read_bytes() == before, "new reader leaves predecessor bytes unchanged")
        harness.check(lifecycle_kinds(snapshot) == ["SHUTDOWN_REQUESTED"], "only ordinary cleanup created predecessor lifecycle stop")

        current_state = harness.runtime / "current-correlated-readable-by-predecessor"
        current_config = v8_config(
            harness,
            "current-correlated-readable-by-predecessor",
            "C",
            current_state,
            free_port(),
            "current-correlated-g1",
            [(os.geteuid(), ["ALL"])],
        )
        current_daemon = harness.start(
            "current-correlated-readable-by-predecessor", current_config, current_state)
        accepted = harness.run(
            "current-correlated-stop",
            ["shutdown", "--control", str(current_daemon.control),
             "--correlation", "readable-by-predecessor", "--deadline-ms", "2000"],
        )
        harness.check(accepted and accepted["format"] == "NATRAV_OVERLAY_CONTROL_CORRELATED_SHUTDOWN_V1", "current writer commits correlated stop")
        wait_stopped(harness, current_daemon, "current correlated compatibility stop")
        current_bytes = (current_state / "state.journal").read_bytes()
        current_read = harness.run(
            "current-reader-of-correlated-state",
            ["inspect", "--state", str(current_state), "--node", "C"],
        )
        predecessor_read = subprocess.run(
            [str(previous), "inspect", "--state", str(current_state), "--node", "C"],
            capture_output=True, text=True, timeout=5, env=os.environ.copy(),
        )
        harness.commands.append({
            "label": "predecessor-reader-of-correlated-state",
            "args": ["inspect", "--state", str(current_state), "--node", "C"],
            "returncode": predecessor_read.returncode,
            "stdout": predecessor_read.stdout,
            "stderr": predecessor_read.stderr,
        })
        harness.check(predecessor_read.returncode == 0, "predecessor reads new correlated durable history")
        predecessor_snapshot = json.loads(predecessor_read.stdout.strip().splitlines()[-1])
        assert current_read is not None
        harness.check(predecessor_snapshot["storage"]["logical_state_digest"] == current_read["storage"]["logical_state_digest"], "predecessor and current reader agree on exact correlated state")
        harness.check((current_state / "state.journal").read_bytes() == current_bytes, "predecessor leaves correlated state bytes unchanged")
        harness.check(lifecycle_kinds(predecessor_snapshot) == ["SHUTDOWN_REQUESTED"], "predecessor reconstructs correlated lifecycle consequence")
        code = 0
    except BaseException as error:
        import traceback
        (harness.output / "FAILURE.txt").write_text(traceback.format_exc())
        print(f"FAIL: {type(error).__name__}: {error}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_CORRELATED_STOPPING_COMPATIBILITY_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "previous_binary_sha256": hashlib.sha256(previous.read_bytes()).hexdigest(),
            "cases_passed": 1 if code == 0 else 0,
            "cases_total": 1,
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (
            ("SUMMARY.json", summary),
            ("COMMANDS.json", harness.commands),
        ):
            (harness.output / name).write_text(json.dumps(value, indent=2) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
