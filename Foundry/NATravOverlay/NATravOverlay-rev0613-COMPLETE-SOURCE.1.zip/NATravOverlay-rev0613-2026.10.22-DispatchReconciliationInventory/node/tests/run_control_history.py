#!/usr/bin/env python3
"""Read actual local decision/lifecycle accounts using independent wire and hash references.
All principals, state, corruption fixtures, and sockets belong to this test run.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, shutil, socket, struct, time
from pathlib import Path
from run_persistent import Harness, Daemon, operation, raw_control, receive_exact, free_port
from run_outbox_inspection import setup, submit
from run_live_configuration import candidate, activate
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_state_authentication import new_key, migrate, start as start_keyed, inspect
from run_delivery_selection import frame, text
from run_configuration_history import journal_reference, hash_domain, seed as config_seed, linked as config_link


def optional(n): return b'\0' if n is None else b'\1'+struct.pack('!Q',n)
def wire(section='decisions',ordinal=None,uid=None,request=None,event=None,offset=0,limit=16,budget=60000,through=None,prefix=None):
    return (b'NOC1\x1cNHA1'+bytes([1 if section=='decisions' else 2])+optional(ordinal)+optional(uid)+
            (b'\1'+bytes.fromhex(request) if request else b'\0')+optional(event)+struct.pack('!QII',offset,limit,budget)+optional(through)+
            (bytes.fromhex(prefix) if prefix else b''))

def history(h,label,a,*,section='decisions',ordinal=None,uid=None,request=None,event=None,offset=0,limit=16,budget=60000,through=None,prefix=None,actor=None,expected=0):
    args=['control-history','--control',str(a/'control.sock'),'--section',section,'--offset',str(offset),'--limit',str(limit),'--max-bytes',str(budget),'--deadline-ms','5000']
    for k,v in [('ordinal',ordinal),('uid',uid),('request-id',request),('event',event),('through',through),('prefix-digest',prefix)]:
        if v is not None:args += ['--'+k,str(v)]
    q=h.run(label,args,expected) if actor is None else run_as_uid(h,label,actor,actor,args,expected)
    if expected==0:
        h.check(q['format']=='NATRAV_OVERLAY_CONTROL_HISTORY_V1','versioned actual account API')
        h.check(q['returned']==len(q['rows']) and q['returned']<=limit,'exact whole-row count')
        h.check(len(json.dumps(q,separators=(',',':')).encode())<=budget,'complete annotated reply within budget')
        h.check(q['work']['rows_visited']<=limit+1,'bounded record visits')
        h.check(all(q['work'][k]==0 for k in ['canonical_bytes_read','payload_bytes_read','historical_configurations_parsed','state_snapshots','snapshot_logical_bytes']),'no application snapshot or canonical/payload read')
    return q

def all_rows(h,label,a,section='decisions',**kw):
    rows=[];first=None;offset=0;pages=0
    while True:
        q=history(h,label+'-'+str(pages),a,section=section,offset=offset,through=first['through'] if first else None,prefix=first['prefix_digest'] if first else None,**kw)
        first=first or q;rows+=q['rows'];pages+=1
        h.check(q['prefix_digest']==first['prefix_digest'],'fixed selected prefix')
        if not q['more']:return rows,first,pages
        h.check(q['next_offset']>offset,'page makes progress');offset=q['next_offset']
        if pages>2000:raise AssertionError('pagination loop')

def record_frames(raw):
    off=0
    while off<len(raw):
        assert raw[off:off+4]==b'NOJ1';n=struct.unpack_from('!I',raw,off+4)[0];body=raw[off+8:off+8+n]
        assert hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest()==raw[off+8+n:off+40+n]
        yield body[0],body[1:];off+=40+n
    assert off==len(raw)

def reference(raw,node='A'):
    configs,_=journal_reference(raw,node);rows={'decisions':[],'lifecycle':[]}
    prefixes={s:hash_domain('NATRAV_OVERLAY_CONTROL_HISTORY_SEED_V1',text(node)+bytes([i])) for i,s in enumerate(rows,1)}
    def txt(d,p):
        n=struct.unpack_from('!H',d,p)[0];return d[p+2:p+2+n].decode(),p+2+n
    kinds=['QUIESCED','RESUMED','DRAIN_STARTED','DRAIN_COMPLETED','DRAIN_DEADLINE','SHUTDOWN_REQUESTED']
    for kind,p in record_frames(raw):
        if kind not in (25,26):continue
        section='decisions' if kind==25 else 'lifecycle';row={};i=0
        if kind==26: row['kind']=kinds[p[0]-1];i+=1
        row['request_id']=p[i:i+32].hex();i+=32
        row['uid']=struct.unpack_from('!I',p,i)[0];i+=4
        if kind==25:row['gid']=struct.unpack_from('!I',p,i)[0];i+=4
        else:row['gid']=None
        row['pid']=struct.unpack_from('!I',p,i)[0];i+=4
        if kind==25:
            row['command'],i=txt(p,i);row['command_class'],i=txt(p,i)
        row['configuration_event'],row['unix_ms']=struct.unpack_from('!QQ',p,i);i+=16
        if kind==25:
            row['decision']={1:'AUTHORIZED',2:'DENIED'}[p[i]];i+=1
            row['error_code'],i=txt(p,i);row['effect_completed']=None
        else:
            row['deadline_ms'],row['pending_outbound'],row['pending_actions']=struct.unpack_from('!IQQ',p,i);i+=20
            reason,i=txt(p,i);row.update(reason_text=None,reason_bytes=len(reason.encode()),reason_digest=hash_domain('NATRAV_OVERLAY_LIFECYCLE_REASON_V1',reason.encode()).hex())
        assert i==len(p)
        cfg=configs[row['configuration_event']-1];row['configuration_prefix_digest']=cfg['prefix_digest']
        row['configuration_generation']=cfg['generation'];row['configuration_digest']=cfg['configuration_digest']
        item=hash_domain('NATRAV_OVERLAY_CONTROL_DECISION_ITEM_V1' if kind==25 else 'NATRAV_OVERLAY_LIFECYCLE_ITEM_V1',bytes.fromhex(cfg['prefix_digest'])+p)
        ordinal=len(rows[section])+1
        prefixes[section]=hash_domain('NATRAV_OVERLAY_CONTROL_HISTORY_LINK_V1',prefixes[section]+struct.pack('!Q',ordinal)+item)
        row.update(ordinal=ordinal,prefix_digest=prefixes[section].hex());rows[section].append(row)
    return rows

def compare(h,rows,refs):
    h.check(len(rows)==len(refs),'reference record count')
    for a,b in zip(rows,refs):h.check(all(a[k]==v for k,v in b.items()),'exact stored principal/account and independent prefix')

def cases(h,selected):
    def case(name,fn):
        if not selected or name in selected:h.case(name,fn)

    def actual():
        a,b,ac,bc,ad,bd=setup(h,'audit-actual',delegates=True);expose_control_for_uid(a)
        for i in range(10):submit(h,'audit-source-'+str(i),a,peer='C',payload='PRIVATE-PAYLOAD')
        denied=run_as_uid(h,'audit-denied-compact',65534,65534,['compact','--control',str(a/'control.sock')],3)
        # Authorization decision exists even though this operation cannot succeed.
        failed=h.run('authorized-but-failed',['cancel','--control',str(a/'control.sock'),'--operation',operation('missing'),'--reason','PRIVATE failed reason /secret/path'],3)
        h.check(failed is not None and not failed['ok'],'semantic failure after authorization')
        malformed=b'NOC1\xffPRIVATE-MALFORMED-PAYLOAD'
        ok,result=raw_control(a/'control.sock',malformed);h.check(not ok,'malformed current-principal request fails')
        reason='PRIVATE-LIFECYCLE '+str(h.work/'key-never-render')
        first=h.run('audit-quiesce',['quiesce','--control',str(a/'control.sock'),'--reason',reason])
        history(h,'quiesced-audit',a)
        h.run('audit-resume',['resume','--control',str(a/'control.sock'),'--reason','private resume'])
        # Exact same command bytes yields the same request identity, not one invocation.
        for i in range(2):h.run('audit-wake-'+str(i),['wake','--control',str(a/'control.sock'),'--peer','C'])
        raw=(a/'state.journal').read_bytes();ref=reference(raw)
        decisions,q,pages=all_rows(h,'actual-decisions',a,limit=3)
        lifecycle,lq,_=all_rows(h,'actual-lifecycle',a,'lifecycle',limit=1)
        compare(h,decisions,ref['decisions']);compare(h,lifecycle,ref['lifecycle'])
        d=history(h,'denial-exact-request',a,request=denied['request_id'])
        h.check(d['selected_total']==1 and d['rows'][0]['uid']==65534 and d['rows'][0]['decision']=='DENIED','actual denied actor distinct from current inspector')
        h.check(d['rows'][0]['pid']!=d['principal_pid'],'historical PID not replaced by inspection PID')
        f=history(h,'failed-command-account',a,request=failed['request_id'])
        h.check(any(x['decision']=='AUTHORIZED' and x['effect_completed'] is None for x in f['rows']),'authorization does not imply completed effect')
        w=[x for x in decisions if x['command']=='WAKE'][-1]
        h.check(history(h,'repeated-request-id',a,request=w['request_id'])['selected_total']==2,'request ID can select multiple invocations')
        pair=history(h,'matching-lifecycle-request',a,section='lifecycle',request=first['request_id'])
        h.check(pair['rows']==[lifecycle[0]] and lifecycle[0]['gid'] is None,'actual lifecycle request with missing historical GID explicit')
        h.check('PRIVATE' not in json.dumps(decisions+lifecycle) and str(h.work) not in json.dumps(decisions+lifecycle),'redaction does not expose request bytes or private reasons')
        h.check((a/'state.journal').read_bytes()==raw,'successful polls do not append successful audit')
        h.check(history(h,'exact-denial-ordinal',a,ordinal=d['rows'][0]['ordinal'])['rows']==d['rows'],'exact indexed lookup')
        h.check(history(h,'missing-ordinal',a,ordinal=999999)['rows']==[],'absent ordinal empty')
        (h.output/'ACTUAL-ACCOUNTS.json').write_text(json.dumps({'decisions':decisions,'lifecycle':lifecycle,'pages':pages,'denial':d['rows'],'failed_action_account':f['rows']},indent=2)+'\n')
        restore_owner_only_control(a);ad.shutdown()
    case('independent_actual_decisions_lifecycle_redaction_and_nonunique_request_lookup',actual)

    def validation():
        a,b,ac,bc,ad,bd=setup(h,'audit-wire');submit(h,'wire-source',a,peer='C')
        q=history(h,'wire-reference',a,limit=1)
        ok,x=raw_control(a/'control.sock',wire(limit=1));h.check(ok and x['rows']==q['rows'],'independent NHA1 encoder')
        for label,p in [('trailing',wire()+b'x'),('bad-magic',b'NOC1\x1cBAD!'+wire()[9:]),('bad-section',b'NOC1\x1cNHA1\x03'+wire()[10:]),('uid-overflow',wire(uid=2**32)),('zero-limit',wire(limit=0)),('false-flag',b'NOC1\x1cNHA1\x01\x02'+wire()[11:]),('two-filters',wire(uid=0,event=1)),('max-bytes',wire(budget=60001))]:
            ok,err=raw_control(a/'control.sock',p);h.check(not ok,'strict wire rejects '+label)
        h.check(history(h,'false-prefix',a,through=q['through'],prefix='11'*32,expected=3)['code']=='CONTROL_HISTORY_PREFIX_MISMATCH','prefix content equality required')
        h.check(history(h,'missing-prefix',a,through=1000000,prefix=q['prefix_digest'],expected=3)['code']=='CONTROL_HISTORY_PREFIX_UNAVAILABLE','absent prefix not invented')
        h.check(history(h,'offset-needs-prefix',a,offset=1,expected=3)['code']=='CONTROL_HISTORY_PREFIX_REQUIRED','offset requires selected boundary')
        root=history(h,'new-root',a)
        h.check(history(h,'past-offset',a,through=root['through'],prefix=root['prefix_digest'],offset=root['through']+1,expected=3)['code']=='CONTROL_HISTORY_OFFSET_INVALID','bounds reject excess offset')
        rows,_,pages=all_rows(h,'byte-pages',a,budget=3000,limit=64)
        h.check(len(rows)>1 and pages>1,'byte bound paginates complete rows')
        z=hash_domain('NATRAV_OVERLAY_CONTROL_HISTORY_SEED_V1',text('A')+b'\2').hex()
        empty=history(h,'explicit-empty-prefix',a,section='lifecycle',through=0,prefix=z)
        h.check(empty['rows']==[] and empty['work']['rows_visited']==0,'empty prefix is explicit and observational')
        ad.shutdown()
    case('independent_wire_strict_bounds_prefix_checks_and_byte_limited_pages',validation)

    def credentials():
        a,b,ac,bc,ad,bd=setup(h,'audit-credentials',delegates=True);expose_control_for_uid(a)
        history(h,'real-inspector',a,actor=65534)
        h.check(history(h,'submit-not-inspect',a,actor=65533,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','SUBMIT not administrative inspection')
        # Unknown UID rejection happens before frame decode. The generated ID is synthetic.
        h.check(run_as_uid(h,'unlisted-uid',65532,65532,['control-history','--control',str(a/'control.sock')],3)['code']=='LOCAL_CONTROL_UID_DENIED','unknown UID denied')
        q=history(h,'unlisted-audit',a,uid=65532)
        h.check(q['rows'][0]['uid']==65532 and q['rows'][0]['error_code']=='LOCAL_CONTROL_UID_DENIED','actual denied principal retained')
        s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);s.settimeout(6);s.connect(str(a/'control.sock'));data=wire();s.sendall(struct.pack('!I',len(data))+data[:-1])
        c=candidate(h,ac,'audit-revoked','audit-revoked-g2',lambda t:t.replace(f'local_control={os.geteuid()},ALL',f'local_control={os.geteuid()},CONFIGURATION,MAINTENANCE,SHUTDOWN,SUBMIT'))
        activate(h,'revoke-inspector',a,c);s.sendall(data[-1:]);s.shutdown(socket.SHUT_WR);n=struct.unpack('!I',receive_exact(s,4))[0];r=receive_exact(s,n);s.close()
        h.check(r[4]==1 and json.loads(r[5:])['code']=='LOCAL_CONTROL_CLASS_DENIED','partial request uses current authority')
        q=history(h,'delegated-view-of-denial',a,actor=65534,request=json.loads(r[5:])['request_id'])
        h.check(q['rows'][-1]['configuration_generation']=='audit-revoked-g2' and q['rows'][-1]['uid']==os.geteuid(),'denial attributed to revoking generation')
        c=candidate(h,ac,'audit-restored','audit-restored-g3');activate(h,'restore-inspector',a,c)
        submit(h,'drain-pending',a,peer='C')
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            f=pool.submit(h.run,'actual-drain',['drain-shutdown','--control',str(a/'control.sock'),'--reason','private drain','--drain-deadline-ms','1200'])
            h.wait('actual drain underway',lambda:h.status('draining-observation',a,logical_digest=False)['lifecycle']['draining'])
            during=history(h,'history-while-draining',a,section='lifecycle');h.check(during['rows'][-1]['kind']=='DRAIN_STARTED','read while actual drain in progress')
            done=f.result()
        ad.process.wait(timeout=5);ad._close_files();restore_owner_only_control(a)
        ad=h.start('audit-after-drain',ac,a)
        rows=history(h,'drain-request-history',a,section='lifecycle',request=done['request_id'])['rows']
        h.check([x['kind'] for x in rows]==['DRAIN_STARTED','DRAIN_DEADLINE'],'one request has two durable lifecycle outcomes')
        h.check(rows[0]['request_id']==rows[1]['request_id'] and rows[0]['uid']==os.geteuid(),'as-recorded lifecycle principal, not current inspector')
        (h.output/'PRINCIPALS.json').write_text(json.dumps({'revocation_denial':q['rows'],'drain_history':rows},indent=2)+'\n');ad.shutdown()
    case('real_uids_live_revocation_and_actual_drain_lifecycle_reconstruction',credentials)

    def concurrent_reads():
        a,b,ac,bc,ad,bd=setup(h,'audit-concurrent')
        for i in range(12):submit(h,'initial-audit-'+str(i),a,peer='C')
        rows,first,_=all_rows(h,'initial-prefix',a,limit=5)
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            fs=[pool.submit(submit,h,'new-audit-'+str(i),a,'C') for i in range(24)]
            c=candidate(h,ac,'audit-new-generation','audit-generation-g2');activate(h,'publish-with-readers',a,c)
            got=[];offset=0
            while True:
                q=history(h,'old-prefix-'+str(offset),a,through=first['through'],prefix=first['prefix_digest'],offset=offset,limit=3)
                got+=q['rows']
                if not q['more']:break
                offset=q['next_offset']
            for f in fs:f.result()
        h.check(got==rows,'old prefix stable during actual writes and activation')
        h.run('audit-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000']);ad.kill();ad=h.start('audit-after-kill',ac,a)
        q=history(h,'prefix-rebuilt',a,through=first['through'],prefix=first['prefix_digest'],limit=64)
        h.check(q['rows']==rows,'prefix same after checkpoint and hard restart')
        (h.output/'CONCURRENT.json').write_text(json.dumps({'before':first['through'],'after':q['retained_count_observed'],'prefix':first['prefix_digest']},indent=2)+'\n');ad.shutdown()
    case('concurrent_append_stable_pages_compaction_and_hard_restart',concurrent_reads)

    def maintenance():
        a,b,ac,bc,ad,bd=setup(h,'audit-maintenance')
        for i in range(3):submit(h,'maintenance-audit-'+str(i),a,peer='C')
        h.run('maintenance-quiesce',['quiesce','--control',str(a/'control.sock'),'--reason','PRIVATE '+str(h.work)])
        h.run('maintenance-resume',['resume','--control',str(a/'control.sock'),'--reason','private'])
        rows,first,_=all_rows(h,'pre-maintenance',a);life,lf,_=all_rows(h,'pre-maintenance-life',a,'lifecycle')
        ad.shutdown();key=new_key(h,h.work,'audit-state');migrate(h,'audit-migrate',a,key)
        ad=start_keyed(h,'audit-keyed',ac,a,key);h.run('keyed-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000']);ad.shutdown()
        h.run('audit-keyed-state',['state-auth-audit','--state',str(a),'--node','A','--state-auth-key',str(key)])
        before=inspect(h,'before-backup',a,key);crypt=h.work/'audit-backup.key';h.run('new-backup-key',['backup-key-init','--output',str(crypt),'--generation','audit-crypt'])
        ident=h.identity('A');archive=h.work/'audit.nob'
        h.run('audit-export',['backup-export','--state',str(a),'--node','A','--generation','a-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'audit-restored'
        h.run('audit-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        h.check(inspect(h,'after-backup',restored,key)['storage']['logical_state_digest']==before['storage']['logical_state_digest'],'no logical change from derived indexes at restore')
        keys=h.work/'moved-keys';keys.mkdir(mode=0o700);shutil.copyfile(ident.private_key,keys/'key.pem');(keys/'key.pem').chmod(0o600);shutil.copyfile(ident.certificate,keys/'cert.pem')
        moved=candidate(h,ac,'audit-relocated','audit-relocated-g2',lambda t:t.replace('state='+str(a),'state='+str(restored)).replace(str(ident.private_key),str(keys/'key.pem')).replace(str(ident.certificate),str(keys/'cert.pem')))
        h.run('audit-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','private old path '+str(a),'--state-auth-key',str(key)])
        ident.private_key.unlink();ident.certificate.unlink();ad=start_keyed(h,'audit-moved',moved,restored,key)
        h.check(history(h,'restored-decisions',restored,through=first['through'],prefix=first['prefix_digest'],limit=64)['rows']==rows,'exact historical decisions after old key removal')
        h.check(history(h,'restored-lifecycle',restored,section='lifecycle',through=lf['through'],prefix=lf['prefix_digest'],limit=64)['rows']==life,'exact lifecycle prefix after relocated restore')
        submit(h,'new-relocated-audit',restored,peer='C')
        q=history(h,'relocated-generation-records',restored,event=2)
        h.check(len(q['rows'])==1 and q['rows'][0]['configuration_generation']=='audit-relocated-g2','new records bind relocated generation')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'decision_count':len(rows),'lifecycle_count':len(life),'exact_restore_digest':before['storage']['logical_state_digest'],'new_accounts':q['rows'],'old_paths_removed':True},indent=2)+'\n')
        ad.shutdown();shutil.copyfile(keys/'key.pem',ident.private_key);ident.private_key.chmod(0o600);shutil.copyfile(keys/'cert.pem',ident.certificate)
    case('keyed_audit_compaction_encrypted_restore_relocation_and_obsolete_paths',maintenance)

    def large():
        a,b,ac,bc,ad,bd=setup(h,'audit-large');ad.shutdown()
        reqs=[bytes.fromhex(operation('synthetic-request-'+str(i))) for i in range(128)]
        stamp=int(time.time()*1000)
        with (a/'state.journal').open('ab') as f:
            for i in range(8192):
                p=reqs[i%128]+struct.pack('!III',1000+i%8,2000+i%8,4000+i%64)+text('WAKE')+text('MAINTENANCE')+struct.pack('!QQB',1,stamp+i,1)+text('')
                f.write(frame(25,p))
            for i in range(1024):
                p=bytes([1 if i%2==0 else 2])+reqs[i%128]+struct.pack('!IIQQIQQ',1000+i%8,4000+i%64,1,stamp+i,0,0,0)+text('synthetic private lifecycle '+str(i))
                f.write(frame(26,p))
        refs=reference((a/'state.journal').read_bytes());ad=Daemon(h,'audit-large-load',ac,a,readiness_timeout=20);h.daemons.append(ad);ad.start()
        rows,first,pages=all_rows(h,'large-decisions',a,limit=64);compare(h,rows,refs['decisions'])
        life,lf,lp=all_rows(h,'large-life',a,'lifecycle',limit=64);compare(h,life,refs['lifecycle'])
        q=history(h,'large-request-selection',a,request=reqs[0].hex(),limit=2)
        h.check(q['selected_total']==64 and q['work']['rows_visited']==2 and q['work']['ordinal_search_comparisons']<16,'indexed request lookup does not scan history')
        uid=history(h,'large-uid-selection',a,uid=1000,limit=2)
        h.check(uid['selected_total']==1024 and uid['work']['ordinal_search_comparisons']<16,'exact UID count via ordered index')
        h.check(history(h,'ordinal-filter-miss',a,ordinal=2,uid=9999)['selected_total']==0,'ordinal filter conjunctive')
        empty=history(h,'empty-event-filter',a,event=256)
        h.check(empty['work']['rows_visited']==0 and empty['selected_total']==0,'empty indexed filter no records read')
        h.run('audit-large-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000']);ad.shutdown();ad=h.start('audit-large-restart',ac,a)
        got=history(h,'large-prefix-rebuilt',a,through=first['through'],prefix=first['prefix_digest'],offset=len(rows)-1,limit=1)
        h.check(got['rows']==[rows[-1]],'large indexed prefix rebuilt from checkpoint')
        (h.output/'LARGE-HISTORY.json').write_text(json.dumps({'fixture':'synthetic valid local accounts, not actual 8192 clients/decisions','decisions':len(rows),'lifecycle':len(life),'synthetic_decisions':8192,'synthetic_lifecycle':1024,'preexisting_real_decisions':len(rows)-8192,'preexisting_real_lifecycle':len(life)-1024,'decision_pages':pages,'lifecycle_pages':lp,'request_selection_work':q['work'],'uid_selection_work':uid['work'],'empty_work':empty['work']},indent=2)+'\n');ad.shutdown()
    case('8192_decisions_1024_lifecycle_complete_enumeration_indexed_filters_and_rebuild',large)

    def altered():
        a,b,ac,bc,ad,bd=setup(h,'audit-alternate');submit(h,'alternate-source',a,peer='C')
        first=history(h,'original-prefix',a);ad.shutdown()
        # Change attribution while retaining the same accepted canonical settings.
        frames=list(record_frames((a/'state.journal').read_bytes()));found=False;out=[]
        for kind,p in frames:
            if kind==22 and not found:
                p=p.replace(text('LOCAL_STARTUP'),text('LOCAL_STARTUP_ALTERNATE'));found=True
            out.append(frame(kind,p))
        h.check(found,'changed initial config attribution not settings');(a/'state.journal').write_bytes(b''.join(out))
        ad=h.start('audit-alternative-valid',ac,a)
        h.check(history(h,'old-prefix-against-new-attribution',a,through=first['through'],prefix=first['prefix_digest'],expected=3)['code']=='CONTROL_HISTORY_PREFIX_MISMATCH','account prefix binds exact referred configuration provenance')
        ad.shutdown()
    case('referenced_configuration_attribution_changes_control_prefix',altered)

    def legacy():
        a=h.runtime/'audit-v6';cfg=h.config('audit-v6','A',a,free_port(),[],deadline_ms=2000)
        ad=h.start('audit-v6-owner',cfg,a)
        for i in range(2):
            h.run('legacy-quiesce-'+str(i),['quiesce','--control',str(a/'control.sock'),'--reason','legacy process-local event'])
            h.run('legacy-resume-'+str(i),['resume','--control',str(a/'control.sock'),'--reason','legacy process-local event'])
        raw=(a/'state.journal').read_bytes()
        for section in ('decisions','lifecycle'):
            q=history(h,'legacy-history-'+section,a,section=section)
            h.check(q['retained_count_observed']==0 and q['selected_total']==0 and q['rows']==[],'legacy ephemeral events are not invented durable history')
        h.check((a/'state.journal').read_bytes()==raw,'legacy history is observational')
        ad.shutdown()
    case('legacy_v6_process_local_accounts_remain_explicitly_absent',legacy)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);start=time.time();ok=False
    try:
        cases(h,set(a.case) if a.case else None)
        if not h.cases:raise ValueError('no selected cases')
        ok=True
    except BaseException as e:(h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();s={'format':'NATRAV_CONTROL_HISTORY_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,value in [('SUMMARY',s),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
        print(json.dumps(s),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
