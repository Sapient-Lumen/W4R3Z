#include "serial_packet_framing.hpp"
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace natrav_overlay::serial_packet;
int main() {
    std::size_t assertions = 0U;
    auto check = [&](const bool good) { ++assertions; if (!good) { throw std::runtime_error("framing assertion " + std::to_string(assertions)); } };
    const Settings s{.mtu=512U,.link=0x123456789abcdef0ULL,.epoch=23U,.frame_timeout_ms=100U};
    const std::string vector="123456789";
    check(crc32(std::span<const std::uint8_t>(reinterpret_cast<const std::uint8_t*>(vector.data()),vector.size()))==0xcbf43926U);
    check(maximum_wire_bytes(512U)==1070U);
    check(maximum_wire_bytes(256U)==558U);
    check(minimum_transmit_time_ms(512U,115200U,10U)==93U);
    check(minimum_transmit_time_ms(512U,1200U,10U)==8917U);
    check(minimum_transmit_time_ms(256U,1200U,10U)==4650U);
    bool invalid_budget=false;
    try { static_cast<void>(minimum_transmit_time_ms(512U,0U,10U)); }
    catch (const std::invalid_argument&) { invalid_budget=true; }
    check(invalid_budget);
    Bytes payload;
    for (unsigned i=0U;i<256U;++i) { payload.push_back(static_cast<std::uint8_t>(i)); }
    const auto wire=encode(s,payload);
    check(wire.front()==0x7eU && wire.back()==0x7eU);
    check(wire.size()<=2U*(payload.size()+kOverhead)+2U);
    for (std::size_t split=0U;split<=wire.size();++split) {
        Decoder d(s);std::size_t completed=0U;
        for (std::size_t i=0U;i<wire.size();++i) {
            auto p=d.consume(wire[i],i<split?1U:2U);
            if (p) { check(*p==payload); ++completed; }
            check(d.buffered_bytes()<=s.mtu+kOverhead);
        }
        check(completed==1U && d.counters().accepted==1U);
    }
    auto recover=[&](Bytes bad) {
        Decoder d(s);std::size_t completed=0U;
        for (auto b:bad) { check(!d.consume(b,1U).has_value()); }
        for (auto b:wire) { if (auto p=d.consume(b,2U)) { check(*p==payload);++completed; } }
        check(completed==1U);
        check(d.counters().rejected>0U || d.counters().noise_bytes>0U);
    };
    auto corrupt=wire;
    const Bytes marker{'A','B','C'};
    const auto position=std::search(corrupt.begin(),corrupt.end(),marker.begin(),marker.end());
    check(position!=corrupt.end());*position^=0x01U;recover(corrupt);
    auto truncated=wire;truncated.resize(truncated.size()/2U);truncated.push_back(0x7eU);recover(truncated);
    recover({0x7eU,0x7dU,0x7eU});
    recover({0x7eU,0x7dU,0x55U,0x7eU});
    recover({0x7eU,0x11U,0x7eU});
    recover(Bytes(10000U,0x55U));
    auto oversize=Bytes(1U,0x7eU);oversize.insert(oversize.end(),10000U,0x55U);recover(oversize);
    auto wrong=s;wrong.link++;recover(encode(wrong,payload));wrong=s;wrong.epoch++;recover(encode(wrong,payload));
    Decoder d(s);
    for (std::size_t i=0;i<wire.size()/2U;++i) { check(!d.consume(wire[i],1U)); }
    d.expire(101U);check(d.buffered_bytes()==0U && d.counters().expired==1U);
    for (std::size_t i=wire.size()/2U;i<wire.size();++i) { check(!d.consume(wire[i],102U)); }
    std::size_t n=0U;
    for (int twice=0;twice<2;++twice) { for (auto b:wire) { if (d.consume(b,103U)) { ++n; } } }
    check(n==2U); // Physical duplication is left to the finite packet layer.
    const Settings large{.mtu=4096U,.link=1U,.epoch=1U,.frame_timeout_ms=60000U};
    const Bytes maximum(4096U,0x7eU);Decoder big(large);n=0U;
    for (auto b:encode(large,maximum)) { if(auto p=big.consume(b,0U)){check(*p==maximum);++n;} }
    check(n==1U);
    bool caught=false;try{static_cast<void>(encode(s,{}));}catch(const std::invalid_argument&){caught=true;}check(caught);
    caught=false;try{static_cast<void>(encode(s,Bytes(513U)));}catch(const std::invalid_argument&){caught=true;}check(caught);
    std::cout<<"{\"status\":\"PASS\",\"cases\":8,\"assertions\":"<<assertions<<"}\n";
}
