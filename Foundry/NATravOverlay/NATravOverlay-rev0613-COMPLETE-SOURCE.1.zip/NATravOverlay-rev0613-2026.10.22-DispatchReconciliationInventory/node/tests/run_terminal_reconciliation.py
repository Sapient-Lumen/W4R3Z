#!/usr/bin/env python3
"""Exact terminal late-receipt reconciliation in disposable native-node state."""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
import time
from typing import Any
from run_persistent import Harness, operation, receive_exact, raw_control
from run_lease_succession import (setup, withdraw, expire, add_grant, succeed, received,
                                 recipient_successor, mapping_reference)
from run_subscription_leases import local, remote
from run_local_evidence import author
from run_live_configuration import candidate, activate
from run_local_administration import expose_control_for_uid, run_as_uid
from run_state_authentication import new_key, migrate, start as start_keyed, inspect, checksum_frame
from run_source_subscriptions import journal_frames
from run_automatic_source_delivery import automatic, wait_automatic


def text(s: str) -> bytes:
    b=s.encode();return struct.pack('!H',len(b))+b


def reconcile_args(state: Path, old: dict, reason: str='adopt exact durable late receipt') -> list[str]:
    return ['source-subscription-reconcile','--control',str(state/'control.sock'),
            '--grant',old['grant'],'--instance',old['instance'],'--expected-revision',str(old['revision']),
            '--state-digest',old['state_digest'],'--terminal-digest',old['terminal_digest'],
            '--source-operation',old['latest']['source_operation'],
            '--delivery-operation',old['latest']['operation_id'],
            '--receipt-digest',old['head_receipt']['digest'] if old['head_receipt'] else operation('missing-receipt'),
            '--reason',reason,'--deadline-ms','5000']


def wire(old: dict, reason: str) -> bytes:
    b=b'NOC1'+bytes([20])+b'NSR4'+bytes([9])+text(old['grant'])
    b+=bytes.fromhex(old['instance'])+struct.pack('!Q',old['revision'])
    for v in (old['state_digest'],old['terminal_digest'],old['latest']['source_operation'],
              old['latest']['operation_id'],old['head_receipt']['digest']):b+=bytes.fromhex(v)
    return b+text(reason)


def reconcile(h: Harness, label: str, a: Path, old: dict, expected: int=0) -> dict:
    result=h.run(label,reconcile_args(a,old),expected=expected);assert result is not None;return result


def late(h: Harness, name: str, *, lost: bool=False, policy: str='RETAIN', expiry: bool=False) -> tuple:
    a,c,pa,pc,ad,cd,current=setup(h,name,recipient=False,policy=policy,duration=1000 if expiry else 60000)
    original=operation(name+'-source');author(h,name+'-source',a,op=original,value='initial observation')
    issued=local(h,name+'-issue',a,'step',previous=current)
    terminal=expire(h,name,a,issued) if expiry else withdraw(h,name,a,pc,issued)
    cd=h.start(name+'-c-late',pc,c, {'NATRAV_OVERLAY_TEST_SESSION_DROP_AFTER_ADMISSION_OPERATION':issued['latest']['operation_id']} if lost else None)
    h.wait(name+' late durable receipt',lambda:local(h,name+'-receipt',a,'status')['delivery_status']=='ACKED')
    selected=local(h,name+'-selected',a,'status')
    h.check(selected['state_digest']==terminal['state_digest'] and selected['acknowledged']==0,
            'outbox receipt does not automatically advance terminal subscription')
    receipt=selected['head_receipt']
    payload=b'NOA1'+bytes([3])+bytes.fromhex(receipt['operation_id'])+text(receipt['recipient'])+text(receipt['recorder'])
    payload+=bytes([1 if receipt['disposition']=='COMMITTED' else 2])+struct.pack('!Q',receipt['sequence'])+bytes.fromhex(receipt['record_digest'])
    h.check(hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_DURABLE_RECEIPT_V1\0'+payload).hexdigest()==receipt['digest'],
            'independent canonical receipt commitment')
    if lost:h.check(receipt['disposition']=='DUPLICATE','lost initial reply recovered through real duplicate-safe peer admission')
    return a,c,pa,pc,ad,cd,selected,original


def invariant(h: Harness, before: dict, after: dict) -> None:
    h.check(after['revision']==before['revision']+1 and after['acknowledged']==before['acknowledged']+1 and
            not after['retained_unacknowledged'] and after['state']=='RETIRED','one terminal frontier advances, not its lifecycle')
    for field in ('termination','terminal_digest','issued','used_payload_bytes','lease_started_unix_ms',
                  'lease_expires_unix_ms','automatic_current','automatic_schedule_revision','grant_digest','remote_admission'):
        h.check(before[field]==after[field],field+' is preserved by reconciliation')
    x=after['reconciliation']
    h.check(x['preceding_state_digest']==before['state_digest'] and x['receipt_digest']==before['head_receipt']['digest'] and
            x['terminal_digest']==before['terminal_digest'] and x['uid']==os.geteuid() and x['pid']>0,
            'separate reconciliation commits exact prior state, receipt and actual manager')


def cases(h: Harness, selected: set[str]|None) -> None:
    def case(name: str, f: Any) -> None:
        if selected is None or name in selected:h.case(name,f)

    def continuity() -> None:
        a,c,pa,pc,ad,cd,old,original=late(h,'continuity',lost=True)
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda i:reconcile(h,f'concurrent-{i}',a,old),range(8)))
        h.check(sum(x['disposition']=='RECONCILED' for x in results)==1 and
                sum(x['disposition']=='ALREADY_RECONCILED' for x in results)==7,'one exact concurrent reconciliation winner')
        done=results[0];invariant(h,old,done)
        ad.shutdown();ad=h.start('continuity-restart',pa,a)
        h.check(reconcile(h,'restart-idempotent',a,old)['state_digest']==done['state_digest'],'idempotent retry survives restart')
        # Original authenticated withdrawal remains bound to the original request.
        repeated=remote(h,'withdraw-original-retry',pc,'withdraw',operation('continuity-withdraw'),instance=old['instance'],revision=old['revision']-1)
        h.check(repeated['disposition']=='ALREADY_WITHDRAWN','old remote withdrawal is not interpreted as a new receipt adoption')
        pa2=add_grant(h,pa,a,'continuity-g2');successor=succeed(h,'continuity-succeed',a,done)
        author(h,'continuity-correction',a,parent=original,value='corrected observation')
        issued=local(h,'continuity-g2-issue',a,'step',grant='g2',previous=successor)
        final=received(h,'continuity-g2',a,issued);env=recipient_successor(h,'continuity-envelope',c,final)
        h.check(env['mapped_corrects']==old['latest']['operation_id'] and final['acknowledged_source_position']==2,
                'successor correction uses the reconciled recipient parent, not a replacement original')
        denied=reconcile(h,'already-adopted',a,old,3)
        h.check(denied['code']=='SOURCE_RECONCILIATION_ADOPTED','adopted predecessor cannot be mutated even by old exact reconciliation retry')
        ad.shutdown();cd.shutdown();mapping_reference(h,inspect(h,'continuity-offline',a))
        (h.output/'CONTINUITY.json').write_text(json.dumps({'before':old,'reconciled':done,'successor':final,'envelope':env},indent=2)+'\n')
    case('lost_receipt_concurrent_adoption_and_successor_correction',continuity)

    def selectors() -> None:
        a,c,pa,pc,ad,cd,old,_=late(h,'selectors')
        base=reconcile_args(a,old)
        for flag in ('--instance','--state-digest','--terminal-digest','--source-operation','--delivery-operation','--receipt-digest'):
            bad=base.copy();bad[bad.index(flag)+1]=operation('wrong'+flag)
            h.run('wrong-'+flag[2:],bad,expected=3)
        bad=base.copy();bad[bad.index('--expected-revision')+1]=str(old['revision']+1)
        h.run('wrong-revision',bad,expected=3)
        h.check(local(h,'selectors-unmodified',a,'status')['state_digest']==old['state_digest'],'rejected selectors never change terminal state')
        grant_other=candidate(h,pa,'selectors-other','selectors-other-g',lambda tx:tx+'local_control=65534,SOURCE_DISCLOSE\n')
        activate(h,'selectors-other-activate',a,grant_other);expose_control_for_uid(a)
        response=run_as_uid(h,'selectors-other-uid',65534,65534,base,3)
        h.check(response['code']=='SOURCE_SUBSCRIPTION_NOT_FOUND','another real manager UID cannot select this owner instance')
        a.chmod(0o700);(a/'control.sock').chmod(0o600)
        raw=wire(old,'delayed receipt adoption')
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as sock:
            sock.settimeout(5);sock.connect(str(a/'control.sock'));sock.sendall(struct.pack('!I',len(raw))+raw[:-1])
            removed=candidate(h,grant_other,'selectors-removed','selectors-removed-g',lambda tx:'\n'.join(
                line for line in tx.splitlines() if not line.startswith('source_disclosure=g1,'))+'\n')
            activate(h,'selectors-remove-grant',a,removed)
            sock.sendall(raw[-1:]);sock.shutdown(socket.SHUT_WR)
            n=struct.unpack('!I',receive_exact(sock,4))[0];reply=receive_exact(sock,n)
        h.check(reply[:5]==b'NOR1\1' and json.loads(reply[5:])['code']=='SOURCE_DISCLOSURE_DENIED',
                'current policy is checked after the entire independent NSR4 request arrives')
        restored=candidate(h,grant_other,'selectors-restored','selectors-restored-g');activate(h,'selectors-restore',a,restored)
        ok,response=raw_control(a/'control.sock',wire(old,'independent receipt adoption'))
        h.check(ok and response['disposition']=='RECONCILED','independent strict NSR4 producer commits under current authority')
        ok,response=raw_control(a/'control.sock',wire(old,'independent receipt adoption')+b'x')
        h.check(not ok,'trailing request material is rejected')
        ad.shutdown();cd.shutdown()
    case('exact_selectors_real_uid_and_live_authority',selectors)

    def non_receipts() -> None:
        for policy in ('RETAIN','CANCEL'):
            name='no-receipt-'+policy.lower();a,c,pa,pc,ad,cd,current=setup(h,name,recipient=False,policy=policy)
            author(h,name+'-source',a,value='not a receipt');issued=local(h,name+'-issue',a,'step',previous=current)
            terminal=withdraw(h,name,a,pc,issued)
            result=reconcile(h,name+'-deny',a,terminal,3)
            h.check(result['code']=='SOURCE_RECONCILIATION_RECEIPT_REQUIRED','missing '+policy+' receipt cannot be invented')
            h.check(local(h,name+'-preserved',a,'status')['state_digest']==terminal['state_digest'],'failure does not advance or alter source')
            ad.shutdown()
        # A real authenticated recipient refusal is still not a receipt.
        a,c,pa,pc,ad,cd,current=setup(h,'rejected',recipient=False)
        pc.write_text('\n'.join(line for line in pc.read_text().splitlines() if not line.startswith('authorize=A,'))+'\n')
        cd=h.start('rejected-recipient',pc,c);author(h,'rejected-source',a,value='denied')
        issued=local(h,'rejected-issue',a,'step',previous=current)
        h.wait('recipient rejects source',lambda:local(h,'rejected-status',a,'status')['delivery_status']=='REJECTED')
        terminal=withdraw(h,'rejected',a,pc,issued)
        h.check(reconcile(h,'rejected-receipt-deny',a,terminal,3)['code']=='SOURCE_RECONCILIATION_RECEIPT_REQUIRED',
                'authenticated rejection never becomes acknowledgment')
        ad.shutdown();cd.shutdown()
    case('pending_cancelled_and_rejected_are_not_receipts',non_receipts)

    def natural_expiry() -> None:
        a,c,pa,pc,ad,cd,old,_=late(h,'expiry',expiry=True)
        done=reconcile(h,'expired-adopt',a,old);invariant(h,old,done)
        h.check(done['termination']['kind']=='EXPIRED','natural expiry remains the exact earlier account')
        ad.shutdown();ad=h.start('expiry-restart',pa,a)
        h.check(reconcile(h,'expiry-idempotent',a,old)['state_digest']==done['state_digest'],'expired reconciliation survives replay')
        ad.shutdown();cd.shutdown()
    case('natural_expiry_preserves_original_account',natural_expiry)

    def kills() -> None:
        for boundary in ('BEFORE','AFTER'):
            name='kill-'+boundary.lower();a,c,pa,pc,ad,cd,old,_=late(h,name)
            ad.shutdown();ad=h.start(name+'-hook',pa,a,{'NATRAV_OVERLAY_TEST_SOURCE_RECONCILE_'+boundary+'_COMMIT_MS':'10000'})
            with (h.logs/(name+'-client.txt')).open('w') as log:
                client=subprocess.Popen([str(h.binary),*reconcile_args(a,old)],stdout=log,stderr=subprocess.STDOUT)
                if boundary=='AFTER':h.wait(name+' committed marker',lambda:b'NSS6' in (a/'state.journal').read_bytes(),5)
                else:
                    time.sleep(.25);h.check(b'NSS6' not in (a/'state.journal').read_bytes(),'no reconciliation before commit')
                h.check(client.poll() is None,'client pending at selected commit boundary');ad.kill()
                try:client.wait(timeout=3)
                except subprocess.TimeoutExpired:client.kill();client.wait(timeout=3)
            ad=h.start(name+'-restart',pa,a);recovered=reconcile(h,name+'-retry',a,old)
            h.check(recovered['disposition']==('RECONCILED' if boundary=='BEFORE' else 'ALREADY_RECONCILED'),
                    'either old or complete reconciled state is authoritative')
            invariant(h,old,recovered);ad.shutdown();cd.shutdown()
    case('real_kills_around_atomic_reconciliation',kills)

    def corruption() -> None:
        a,c,pa,pc,ad,cd,old,_=late(h,'corruption');done=reconcile(h,'corruption-adopt',a,old)
        ad.shutdown();cd.shutdown();journal=a/'state.journal';frames=journal_frames(journal)
        for name,needle in [('receipt',old['head_receipt']['digest']),('prior',old['state_digest']),('terminal',old['terminal_digest'])]:
            out=[]
            for frame in frames:
                if b'NSS6' in frame:
                    b=bytearray(frame);pos=b.rfind(bytes.fromhex(needle),0,len(b)-32);h.check(pos>0,'locate '+name+' binding')
                    b[pos]^=1;frame=checksum_frame(bytes(b))
                out.append(frame)
            journal.write_bytes(b''.join(out));result=inspect(h,'forged-'+name,a,expected=3)
            h.check(result['code']=='JOURNAL_CORRUPT','recomputed checksum cannot bypass '+name+' binding')
        # Remove the actual durable receipt while retaining the complete reconciliation.
        target=bytes.fromhex(old['latest']['operation_id'])
        without=[f for f in frames if not (b'NOA1\3'+target in f and b'NSS6' not in f)]
        h.check(len(without)==len(frames)-1,'one durable receipt selected for removal')
        journal.write_bytes(b''.join(without));h.check(inspect(h,'removed-receipt',a,expected=3)['code']=='JOURNAL_CORRUPT',
            'semantic replay requires a durable receipt, not just its advertised digest')
        journal.write_bytes(b''.join(frames));mapping_reference(h,inspect(h,'valid-reconstruction',a))
        ad=h.start('corruption-compact',pa,a);h.run('corruption-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000']);ad.shutdown()
        compact=journal_frames(journal);b=bytearray(compact[0]);pos=b.rfind(bytes.fromhex(old['head_receipt']['digest']),0,len(b)-32)
        h.check(pos>0,'checkpoint retains receipt commitment');b[pos]^=1
        journal.write_bytes(checksum_frame(bytes(b))+b''.join(compact[1:]));h.check(inspect(h,'forged-checkpoint',a,expected=3)['code']=='JOURNAL_CORRUPT',
            'normal checkpoint reconstruction validates receipt and prior-state commitments')
        journal.write_bytes(b''.join(compact));h.check(inspect(h,'restored-checkpoint',a)['source_subscriptions'][0]['reconciliation']==done['reconciliation'],
            'valid checkpoint preserves reconciliation provenance')
    case('semantic_receipt_and_checkpoint_corruption',corruption)

    def automatic_history() -> None:
        a,c,pa,pc,ad,cd,current=setup(h,'automatic',recipient=False)
        author(h,'automatic-source',a,value='scheduled original')
        current=local(h,'automatic-initial',a,'status')
        enabled=automatic(h,'automatic-enable',a,'enable',previous=current,maximum=10,interval=10)
        issued=wait_automatic(h,'automatic-issued',a,lambda x:x['issued']==1)
        terminal=withdraw(h,'automatic',a,pc,issued)
        h.check(terminal['automatic_current']['steps']==1 and terminal['automatic_current']['state']=='RETIRED',
                'withdrawal retains the spent issue step and stops automation')
        cd=h.start('automatic-late-c',pc,c)
        h.wait('automatic late receipt',lambda:local(h,'automatic-wait',a,'status')['delivery_status']=='ACKED')
        selected=local(h,'automatic-selected',a,'status');done=reconcile(h,'automatic-reconcile',a,selected)
        invariant(h,selected,done)
        h.check(done['latest']['acknowledge_automatic_generation']==0 and done['automatic_current']['steps']==1,
                'manual reconciliation does not spend or restart the old automatic grant')
        ad.shutdown();ad=h.start('automatic-restart',pa,a)
        h.check(local(h,'automatic-reconstructed',a,'status')['state_digest']==done['state_digest'],
                'terminal schedule is reconstructed exactly after manual receipt adoption')
        # A revoked subscriber key remains in history, but cannot authorize a new reconciliation or retry.
        alt=h.identity('C-replacement')
        revoked=candidate(h,pa,'automatic-revoked','automatic-revoked-g',lambda tx:
            tx.replace('peer_key=C,c-g1,ACTIVE,','peer_key=C,c-g1,REVOKED,')+
            f'peer_key=C,c-g2,ACTIVE,{alt.spki_sha256}\n')
        activate(h,'automatic-revoke',a,revoked)
        h.check(reconcile(h,'revoked-key-retry',a,selected,3)['code']=='SOURCE_RECONCILIATION_KEY_POLICY',
                'current subscriber generation revocation also blocks idempotent reconciliation requests')
        ad.shutdown();cd.shutdown()
    case('terminal_automation_allowance_and_key_revocation',automatic_history)

    def successor_terminal() -> None:
        a,c,pa,pc,ad,cd,current=setup(h,'successor-terminal')
        original=operation('successor-terminal-original');author(h,'successor-terminal-original',a,op=original,value='first')
        issued=local(h,'successor-terminal-first',a,'step',previous=current)
        first=received(h,'successor-terminal-first',a,issued);terminal=withdraw(h,'successor-terminal',a,pc,first)
        pa2=add_grant(h,pa,a,'successor-terminal-g2',duration=1500)
        second=succeed(h,'successor-terminal-create',a,terminal)
        cd.kill();author(h,'successor-terminal-correction',a,parent=original,value='second')
        queued=local(h,'successor-terminal-issue',a,'step',grant='g2',previous=second)
        expired=expire(h,'successor-terminal-expire',a,queued)
        cd=h.start('successor-terminal-return',pc,c)
        h.wait('successor terminal late receipt',lambda:local(h,'successor-terminal-wait',a,'status',grant='g2')['delivery_status']=='ACKED')
        selected=local(h,'successor-terminal-selected',a,'status',grant='g2')
        done=reconcile(h,'successor-terminal-reconcile',a,selected);invariant(h,selected,done)
        h.check(done['inherited_acknowledged']==1 and done['acknowledged_source_position']==2 and
                done['succession']==second['succession'],'NSS6 preserves the optional ancestral succession reference')
        pa3=add_grant(h,pa2,a,'successor-terminal-g3',grant='g3',lease='lease-g3')
        third=succeed(h,'successor-terminal-adopt',a,done,grant='g3',lease='lease-g3')
        h.check(third['inherited_acknowledged']==2,'third lease inherits the explicitly reconciled cumulative frontier')
        h.run('successor-terminal-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000'])
        ad.shutdown();ad=h.start('successor-terminal-restart',pa3,a)
        h.check(local(h,'successor-terminal-retained',a,'status',grant='g2')['state_digest']==done['state_digest'],
                'non-topological checkpoint replay validates reconciled ancestry and later successor')
        ad.shutdown();cd.shutdown();mapping_reference(h,inspect(h,'successor-terminal-final',a))
    case('reconcile_successor_lease_and_reconstruct_deep_lineage',successor_terminal)

    def maintenance() -> None:
        a,c,pa,pc,ad,cd,old,original=late(h,'maintenance');ad.shutdown()
        keys=h.work/'maintenance-keys';keys.mkdir(mode=0o700);key=new_key(h,keys,'state-g1');migrate(h,'maintenance-migrate',a,key)
        ad=start_keyed(h,'maintenance-keyed',pa,a,key)
        done=reconcile(h,'maintenance-adopt',a,old)
        ad.shutdown();h.run('maintenance-audit',['state-auth-audit','--state',str(a),'--node','A','--state-auth-key',str(key)])
        ad=start_keyed(h,'maintenance-reopen',pa,a,key)
        h.run('maintenance-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000']);ad.shutdown()
        before=inspect(h,'maintenance-before',a,key)
        enc=keys/'archive.key';archive=h.work/'maintenance.nob';identity=h.identity('A')
        h.run('maintenance-encrypt-key',['backup-key-init','--output',str(enc),'--generation','archive-g1'])
        h.run('maintenance-export',['backup-export','--state',str(a),'--node','A','--generation','a-g1','--output',str(archive),
              '--state-auth-key',str(key),'--encrypt-key',str(enc),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'maintenance-restored'
        h.run('maintenance-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1',
              '--state-auth-key',str(key),'--decrypt-key',str(enc),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'maintenance-restored',restored,key)
        h.check(after['storage']['logical_state_digest']==before['storage']['logical_state_digest'] and
                after['source_subscriptions']==before['source_subscriptions'],'encrypted signed restore retains exact terminal and adopted receipt')
        moved=candidate(h,pa,'maintenance-moved','maintenance-moved-g',lambda tx:tx.replace('state='+str(a),'state='+str(restored)))
        h.run('maintenance-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','relocate reconciled state','--state-auth-key',str(key)])
        ad=start_keyed(h,'maintenance-resumed',moved,restored,key)
        h.check(reconcile(h,'maintenance-original-retry',restored,old)['state_digest']==done['state_digest'],'relocation preserves exact retry identity')
        newer=add_grant(h,moved,restored,'maintenance-g2');successor=succeed(h,'maintenance-successor',restored,done)
        author(h,'maintenance-correction',restored,parent=original,value='revised')
        issued=local(h,'maintenance-issue',restored,'step',grant='g2',previous=successor);final=received(h,'maintenance-delivery',restored,issued)
        env=recipient_successor(h,'maintenance-envelope',c,final)
        h.check(env['mapped_corrects']==old['latest']['operation_id'],'restored successor preserves actual acknowledged correction parent')
        ad.shutdown();cd.shutdown();mapping_reference(h,inspect(h,'maintenance-final',restored,key))
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'before_digest':before['storage']['logical_state_digest'],
            'restored_digest':after['storage']['logical_state_digest'],'reconciliation':done['reconciliation'],'successor':final},indent=2)+'\n')
    case('keyed_audit_compaction_encrypted_restore_relocation',maintenance)


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output already exists')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    try:cases(h,set(a.case) if a.case else None);ok=True
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_TERMINAL_RECONCILIATION_TESTS_V1','status':'PASS' if ok else 'FAIL',
            'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),
            'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),
            'elapsed_seconds':time.time()-started}
        for name,value in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:
            (h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
