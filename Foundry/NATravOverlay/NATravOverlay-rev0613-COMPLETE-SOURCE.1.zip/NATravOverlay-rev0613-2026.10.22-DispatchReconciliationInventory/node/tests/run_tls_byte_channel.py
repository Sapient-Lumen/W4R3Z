#!/usr/bin/env python3
"""Descriptor-free OpenSSL BIO over ByteChannel regression."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from typing import Any

from tls_test_support import IdentityFactory


EXPECTED_FEATURE = "OPENSSL_BYTE_CHANNEL_BIO_V1"


def run_command(
    command: list[str],
    *,
    stdout_path: Path,
    stderr_path: Path,
    timeout: float,
    environment: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        timeout=timeout,
        env=environment,
    )
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)
    return completed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    source_root = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    binary = args.binary.resolve(strict=True)
    if output.exists() or output == source_root or source_root in output.parents:
        parser.error("output must be new and outside the source tree")
    output.mkdir(parents=True)

    started = time.monotonic()
    assertions = 0
    commands: list[dict[str, Any]] = []
    cases: list[dict[str, Any]] = []

    def check(condition: bool, detail: str) -> None:
        nonlocal assertions
        assertions += 1
        if not condition:
            raise AssertionError(detail)

    def record_case(name: str, before: int, begin: float) -> None:
        cases.append(
            {
                "name": name,
                "status": "PASS",
                "assertions": assertions - before,
                "elapsed_seconds": time.monotonic() - begin,
            }
        )

    status = "FAIL"
    failure: str | None = None
    try:
        before = assertions
        begin = time.monotonic()
        version_run = run_command(
            [str(binary), "version"],
            stdout_path=output / "version.stdout.txt",
            stderr_path=output / "version.stderr.txt",
            timeout=10,
        )
        commands.append(
            {
                "label": "version",
                "returncode": version_run.returncode,
                "args": ["version"],
            }
        )
        check(version_run.returncode == 0, "version command succeeds")
        version_lines = [line for line in version_run.stdout.splitlines() if line.strip()]
        check(len(version_lines) == 1, "version emits one JSON line")
        version = json.loads(version_lines[0])
        check(version.get("version") == "0613", "revision is 0613")
        check(version.get("tls_byte_channel") == EXPECTED_FEATURE,
              "TLS ByteChannel feature marker is exact")
        check(version.get("transport_extraction") ==
              "TCP_ORDERED_BYTE_STREAM_BOUNDARY_V1",
              "predecessor transport marker is retained")
        record_case("revision metadata", before, begin)

        before = assertions
        begin = time.monotonic()
        tls_header = (source_root / "node/src/tls.hpp").read_text()
        tls_source = (source_root / "node/src/tls.cpp").read_text()
        bio_header = (source_root / "node/src/tls_bio.hpp").read_text()
        bio_source = (source_root / "node/src/tls_bio.cpp").read_text()
        transport_header = (source_root / "node/src/transport.hpp").read_text()
        transport_source = (source_root / "node/src/transport.cpp").read_text()
        peer_sources = "\n".join(
            (source_root / path).read_text()
            for path in ("node/src/node.cpp", "node/src/peer_session.cpp")
        )
        build_script = (source_root / "node/build.sh").read_text()
        all_peer_tls = "\n".join(
            (source_root / path).read_text()
            for path in (
                "node/src/tls.cpp",
                "node/src/tls_bio.cpp",
                "node/src/node.cpp",
                "node/src/peer_session.cpp",
                "node/src/transport.hpp",
                "node/src/transport.cpp",
            )
        )
        check("ByteChannel& channel" in tls_header,
              "TlsChannel accepts the generic byte channel")
        check("class TlsByteChannelBio" in bio_header,
              "owned BIO adapter has an explicit internal contract")
        check("SSL_set_bio" in tls_source,
              "TLS attaches the custom BIO to OpenSSL")
        check("src/tls_bio.cpp" in build_script,
              "product build includes the BIO implementation")
        check("native_tls_handle" not in all_peer_tls,
              "peer TLS has no native-handle seam")
        check("SSL_set_fd" not in all_peer_tls,
              "peer TLS does not bind OpenSSL to a descriptor")
        check("BIO_new_socket" not in all_peer_tls,
              "peer TLS has no hidden socket BIO fallback")
        check("wait_tls" not in tls_source,
              "TLS no longer polls a peer descriptor")
        check("std::exception_ptr failure" in bio_header,
              "callback state retains an exception without crossing C")
        check("noexcept" in bio_header and "catch (...)" in bio_source,
              "callbacks are nonthrowing and trap failures")
        check("thread_local" not in bio_source and
              "current_channel" not in bio_source,
              "adapter has no process-global current channel")
        check("TlsByteChannelBio channel_bio;" in tls_source and
              tls_source.index("TlsByteChannelBio channel_bio;") <
              tls_source.index("SSL* ssl{nullptr};"),
              "BIO callback state remains alive through SSL destruction")
        check("native_tls_handle" not in transport_header + transport_source,
              "transport no longer exposes a TLS descriptor")
        check("*stream" in peer_sources,
              "outbound peer paths pass the owned stream directly")
        record_case("source ownership and callback boundary", before, begin)

        probe = output / "tls-byte-channel-probe"
        compile_command = [
            "/usr/bin/g++",
            "-D_GNU_SOURCE",
            "-std=c++20",
            "-O1",
            "-g0",
            "-Wall",
            "-Wextra",
            "-Wpedantic",
            "-Wconversion",
            "-Wsign-conversion",
            "-Wshadow",
            "-Wformat=2",
            "-Werror",
            "-pthread",
            f"-I{source_root / 'foundation/include'}",
            f"-I{source_root / 'node/src'}",
            str(source_root / "node/tests/test_tls_byte_channel.cpp"),
            str(source_root / "node/src/tls.cpp"),
            str(source_root / "node/src/tls_bio.cpp"),
            str(source_root / "node/src/common.cpp"),
            str(source_root / "foundation/src/core.cpp"),
            "-lssl",
            "-lcrypto",
            "-lz",
            "-lzstd",
            "-ldl",
            "-o",
            str(probe),
        ]
        before = assertions
        begin = time.monotonic()
        compile_run = run_command(
            compile_command,
            stdout_path=output / "probe-build.stdout.txt",
            stderr_path=output / "probe-build.stderr.txt",
            timeout=180,
        )
        commands.append(
            {
                "label": "probe-build",
                "returncode": compile_run.returncode,
                "args": compile_command,
            }
        )
        check(compile_run.returncode == 0,
              "TLS ByteChannel probe compiles with production warnings")
        check(probe.is_file(), "TLS ByteChannel probe executable exists")
        record_case("probe build", before, begin)

        identities = IdentityFactory(output / "identities")
        client = identities.identity("BIO-CLIENT")
        server = identities.identity("BIO-SERVER")
        probe_command = [
            str(probe),
            str(client.certificate),
            str(client.private_key),
            client.spki_sha256,
            str(server.certificate),
            str(server.private_key),
            server.spki_sha256,
        ]
        before = assertions
        begin = time.monotonic()
        probe_run = run_command(
            probe_command,
            stdout_path=output / "probe.stdout.txt",
            stderr_path=output / "probe.stderr.txt",
            timeout=45,
            environment=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
        )
        commands.append(
            {
                "label": "probe",
                "returncode": probe_run.returncode,
                "args": [str(probe), "<ephemeral test identities>"],
            }
        )
        check(probe_run.returncode == 0, "TLS ByteChannel probe succeeds")
        probe_lines = [line for line in probe_run.stdout.splitlines() if line.strip()]
        check(len(probe_lines) == 1, "TLS ByteChannel probe emits one JSON line")
        probe_result = json.loads(probe_lines[0])
        check(probe_result.get("status") == "PASS", "TLS ByteChannel probe reports PASS")
        probe_cases = probe_result.get("cases")
        check(isinstance(probe_cases, list) and len(probe_cases) == 5,
              "TLS ByteChannel probe case count is exact")
        check(probe_result.get("assertions") == 31,
              "TLS ByteChannel probe assertion count is exact")
        check(sum(int(item["assertions"]) for item in probe_cases) == 31,
              "TLS ByteChannel probe per-case accounting is exact")
        assertions += int(probe_result["assertions"])
        cases.extend(
            {
                "name": f"TLS ByteChannel probe: {item['name']}",
                "status": "PASS",
                "assertions": int(item["assertions"]),
                "elapsed_seconds": 0.0,
            }
            for item in probe_cases
        )
        record_case("probe accounting", before + int(probe_result["assertions"]), begin)
        status = "PASS"
    except BaseException as error:  # preserve bounded evidence on any failure
        failure = f"{type(error).__name__}: {error}"
        cases.append(
            {
                "name": "suite failure",
                "status": "FAIL",
                "assertions": 0,
                "elapsed_seconds": 0.0,
                "detail": failure,
            }
        )

    summary = {
        "format": "NATRAV_TLS_BYTE_CHANNEL_SUITE_V1",
        "status": status,
        "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "cases_passed": sum(item["status"] == "PASS" for item in cases),
        "cases_total": len(cases),
        "assertions": assertions,
        "commands": len(commands),
        "elapsed_seconds": time.monotonic() - started,
        "feature": EXPECTED_FEATURE,
        "cases": cases,
        "command_records": commands,
    }
    if failure is not None:
        summary["failure"] = failure
    (output / "SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps({key: value for key, value in summary.items()
                      if key not in {"cases", "command_records"}}, sort_keys=True), flush=True)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
