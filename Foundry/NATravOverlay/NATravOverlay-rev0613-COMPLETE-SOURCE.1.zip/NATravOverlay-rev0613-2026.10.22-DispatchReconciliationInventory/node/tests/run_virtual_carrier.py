#!/usr/bin/env python3
"""Deterministic private virtual-carrier and real authenticated-stack regression."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from typing import Any

from tls_test_support import IdentityFactory


EXPECTED_FEATURE = "DETERMINISTIC_VIRTUAL_ORDERED_BYTE_STREAM_V1"


def run_command(
    command: list[str],
    *,
    stdout_path: Path,
    stderr_path: Path,
    timeout: float,
    environment: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        timeout=timeout,
        env=environment,
    )
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)
    return completed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    source_root = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    binary = args.binary.resolve(strict=True)
    if output.exists() or output == source_root or source_root in output.parents:
        parser.error("output must be new and outside the source tree")
    output.mkdir(parents=True)

    started = time.monotonic()
    assertions = 0
    commands: list[dict[str, Any]] = []
    cases: list[dict[str, Any]] = []

    def check(condition: bool, detail: str) -> None:
        nonlocal assertions
        assertions += 1
        if not condition:
            raise AssertionError(detail)

    def record_case(name: str, before: int, begin: float) -> None:
        cases.append(
            {
                "name": name,
                "status": "PASS",
                "assertions": assertions - before,
                "elapsed_seconds": time.monotonic() - begin,
            }
        )

    status = "FAIL"
    failure: str | None = None
    try:
        before = assertions
        begin = time.monotonic()
        version_run = run_command(
            [str(binary), "version"],
            stdout_path=output / "version.stdout.txt",
            stderr_path=output / "version.stderr.txt",
            timeout=10,
        )
        commands.append(
            {"label": "version", "returncode": version_run.returncode,
             "args": ["version"]}
        )
        check(version_run.returncode == 0, "version command succeeds")
        lines = [line for line in version_run.stdout.splitlines() if line.strip()]
        check(len(lines) == 1, "version emits one JSON line")
        version = json.loads(lines[0])
        check(version.get("version") == "0613", "revision is 0613")
        check(version.get("virtual_carrier") == EXPECTED_FEATURE,
              "virtual carrier feature marker is exact")
        check(version.get("tls_byte_channel") == "OPENSSL_BYTE_CHANNEL_BIO_V1",
              "descriptor-free TLS marker is retained")
        check(version.get("transport_extraction") ==
              "TCP_ORDERED_BYTE_STREAM_BOUNDARY_V1",
              "transport extraction marker is retained")
        record_case("revision metadata", before, begin)

        before = assertions
        begin = time.monotonic()
        header = (source_root / "node/src/virtual_transport.hpp").read_text()
        implementation = (source_root / "node/src/virtual_transport.cpp").read_text()
        transport_header = (source_root / "node/src/transport.hpp").read_text()
        transport_source = (source_root / "node/src/transport.cpp").read_text()
        session_header = (source_root / "node/src/peer_session.hpp").read_text()
        build_script = (source_root / "node/build.sh").read_text()
        config_sources = "\n".join(
            (source_root / path).read_text()
            for path in (
                "node/src/config.cpp",
                "node/src/runtime.cpp",
                "node/src/main.cpp",
            )
        )
        check("class VirtualLinkControl" in header and
              "make_virtual_link" in header,
              "private link has an explicit owned fixture contract")
        check("NVC" not in config_sources and
              "virtual-link-private" not in config_sources,
              "normal configuration contains no virtual locator or route token")
        parse_start = transport_source.index("TransportKind parse_transport_kind")
        parse_end = transport_source.index("std::string_view transport_kind_name")
        parse_body = transport_source[parse_start:parse_end]
        check('text == "tcp"' in parse_body and 'text == "serial"' in parse_body and
              'text == "udp"' in parse_body and 'text == "unix-dgram"' in parse_body and
              "virtual" not in parse_body,
              "configured transport parser exposes production carriers but not the private virtual link")
        check("virtual_link = 255U" in transport_header,
              "private transport kind is explicit and non-default")
        check("src/virtual_transport.cpp" in build_script,
              "the product build compiles the carrier implementation")
        check("open_connected" in session_header,
              "real reusable session accepts a fixture-owned connected stream")
        check("condition_variable" in implementation and
              "queue_capacity" in implementation,
              "link state uses finite queues and bounded synchronization")
        check("thread_local" not in implementation and
              "static Virtual" not in implementation,
              "link schedule, queues, clock steps, and faults are not process-global")
        check("encode_virtual_carrier_schedule" in implementation and
              "decode_virtual_carrier_schedule" in implementation and
              "encode_virtual_trace" in implementation,
              "schedule and replay evidence have canonical encoders")
        record_case("source authority and ownership boundary", before, begin)

        before = assertions
        begin = time.monotonic()
        probe = output / "virtual-carrier-probe"
        compile_command = [
            "/usr/bin/g++",
            "-D_GNU_SOURCE",
            "-std=c++20",
            "-O1",
            "-g0",
            "-Wall",
            "-Wextra",
            "-Wpedantic",
            "-Wconversion",
            "-Wsign-conversion",
            "-Wshadow",
            "-Wformat=2",
            "-Werror",
            "-pthread",
            f"-I{source_root / 'foundation/include'}",
            f"-I{source_root / 'node/src'}",
            str(source_root / "node/tests/test_virtual_carrier.cpp"),
            str(source_root / "node/src/virtual_transport.cpp"),
            str(source_root / "node/src/transport.cpp"),
            str(source_root / "node/src/serial_transport.cpp"),
            str(source_root / "node/src/udp_transport.cpp"),
            str(source_root / "node/src/unix_datagram_transport.cpp"),
            str(source_root / "node/src/finite_packet_link.cpp"),
            str(source_root / "node/src/packet_port.cpp"),
            str(source_root / "node/src/peer_session.cpp"),
            str(source_root / "node/src/tls.cpp"),
            str(source_root / "node/src/tls_bio.cpp"),
            str(source_root / "node/src/socket.cpp"),
            str(source_root / "node/src/protocol.cpp"),
            str(source_root / "node/src/common.cpp"),
            str(source_root / "foundation/src/core.cpp"),
            str(source_root / "foundation/src/natrav_peer_session.cpp"),
            str(source_root / "foundation/src/natrav_peer_stream.cpp"),
            str(source_root / "foundation/src/natrav_peer_message.cpp"),
            str(source_root / "foundation/src/natrav_peer_handshake.cpp"),
            "-lssl",
            "-lcrypto",
            "-lz",
            "-lzstd",
            "-ldl",
            "-o",
            str(probe),
        ]
        compile_run = run_command(
            compile_command,
            stdout_path=output / "probe-build.stdout.txt",
            stderr_path=output / "probe-build.stderr.txt",
            timeout=180,
        )
        commands.append(
            {"label": "probe-build", "returncode": compile_run.returncode,
             "args": compile_command}
        )
        check(compile_run.returncode == 0, "strict-warning probe compiles")
        check(probe.is_file() and os.access(probe, os.X_OK),
              "probe executable is materialized")
        record_case("probe build", before, begin)

        before = assertions
        begin = time.monotonic()
        identities = IdentityFactory(output / "identities")
        client = identities.identity("virtual-client")
        server = identities.identity("virtual-server")
        schedule_dir = output / "schedules"
        schedule_dir.mkdir()
        probe_command = [
            str(probe),
            str(client.certificate),
            str(client.private_key),
            client.spki_sha256,
            str(server.certificate),
            str(server.private_key),
            server.spki_sha256,
            str(schedule_dir),
        ]
        probe_run = run_command(
            probe_command,
            stdout_path=output / "probe.stdout.txt",
            stderr_path=output / "probe.stderr.txt",
            timeout=120,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append(
            {"label": "probe", "returncode": probe_run.returncode,
             "args": [str(probe), "<ephemeral test identities>",
                      str(schedule_dir)]}
        )
        check(probe_run.returncode == 0, "virtual carrier probe succeeds")
        probe_lines = [line for line in probe_run.stdout.splitlines() if line.strip()]
        check(len(probe_lines) == 1, "probe emits one JSON result")
        result = json.loads(probe_lines[0])
        check(result.get("format") == "NATRAV_VIRTUAL_CARRIER_PROBE_V1",
              "probe format is exact")
        check(result.get("status") == "PASS", "probe reports PASS")
        check(result.get("assertions", 0) >= 70,
              "probe retains the expected bounded assertion floor")
        probe_cases = result.get("cases")
        check(isinstance(probe_cases, list) and len(probe_cases) == 7,
              "probe covers seven carrier and authenticated-stack cases")
        for item in probe_cases:
            check(isinstance(item, dict) and item.get("assertions", 0) > 0,
                  "every probe case contributes explicit assertions")
            cases.append(
                {
                    "name": f"virtual carrier probe: {item['name']}",
                    "status": "PASS",
                    "assertions": int(item["assertions"]),
                    "elapsed_seconds": 0.0,
                }
            )
        assertions += int(result["assertions"])
        record_case("probe execution", before, begin)

        before = assertions
        begin = time.monotonic()
        schedules = result.get("schedules")
        check(isinstance(schedules, list) and len(schedules) >= 17,
              f"all generated schedules are enumerated (observed {len(schedules) if isinstance(schedules, list) else type(schedules).__name__})")
        names: set[str] = set()
        for item in schedules:
            check(isinstance(item, dict), "schedule account is an object")
            name = item.get("name")
            digest = item.get("sha256")
            size = item.get("bytes")
            check(isinstance(name, str) and name and name not in names,
                  "schedule names are unique and nonempty")
            names.add(name)
            path = schedule_dir / f"{name}.nvcs"
            check(path.is_file(), "canonical schedule bytes are materialized")
            payload = path.read_bytes()
            check(len(payload) == size, "recorded schedule size is exact")
            check(hashlib.sha256(payload).hexdigest() == digest,
                  "recorded schedule digest binds materialized bytes")
            check(payload.startswith(b"NVCS0001"),
                  "materialized schedule carries the canonical magic")
        first_trace = schedule_dir / "replay-first.nvtr"
        second_trace = schedule_dir / "replay-second.nvtr"
        check(first_trace.is_file() and second_trace.is_file(),
              "both exact-replay traces are retained")
        check(first_trace.read_bytes() == second_trace.read_bytes(),
              "retained replay traces are byte-identical")
        check(first_trace.stat().st_size < 1_000_000,
              "replay evidence remains finite and bounded")
        record_case("materialized schedule and replay evidence", before, begin)

        status = "PASS"
    except BaseException as error:  # preserve bounded evidence on any failure
        failure = f"{type(error).__name__}: {error}"
        cases.append(
            {
                "name": "suite failure",
                "status": "FAIL",
                "assertions": 0,
                "elapsed_seconds": 0.0,
                "detail": failure,
            }
        )

    summary = {
        "format": "NATRAV_VIRTUAL_CARRIER_SUITE_V1",
        "status": status,
        "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "cases_passed": sum(item["status"] == "PASS" for item in cases),
        "cases_total": len(cases),
        "assertions": assertions,
        "commands": len(commands),
        "elapsed_seconds": time.monotonic() - started,
        "feature": EXPECTED_FEATURE,
        "cases": cases,
        "command_records": commands,
    }
    if failure is not None:
        summary["failure"] = failure
    (output / "SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps({key: value for key, value in summary.items()
                      if key not in {"cases", "command_records"}}, sort_keys=True),
          flush=True)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
