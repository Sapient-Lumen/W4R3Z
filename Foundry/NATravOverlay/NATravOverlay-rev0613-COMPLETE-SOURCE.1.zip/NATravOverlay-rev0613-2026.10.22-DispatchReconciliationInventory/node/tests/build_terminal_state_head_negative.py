#!/usr/bin/env python3
"""Isolate a single omitted terminal INSPECT rule; never modify product sources."""
from __future__ import annotations
import argparse
import difflib
import json
from pathlib import Path
import shutil
import subprocess


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--prepare-only',action='store_true')
    a=p.parse_args();root=Path(__file__).resolve().parents[2];out=a.output.resolve()
    if out.exists() or out==root or root in out.parents:p.error('new output outside product required')
    tree=out/'source';tree.mkdir(parents=True)
    for part in ('node/src','foundation/src','foundation/include'):shutil.copytree(root/part,tree/part)
    shutil.copy2(root/'node/build.sh',tree/'node/build.sh')
    f=tree/'node/src/daemon.cpp';before=f.read_text()
    anchor='    return local_control_allows(config.local_control, uid, LocalControlClass::inspect);'
    assert before.count(anchor)==1
    after=before.replace(anchor,'    static_cast<void>(config); static_cast<void>(uid);\n    return true; // deliberately omitted terminal INSPECT requirement')
    f.write_text(after)
    (out/'OMIT-TERMINAL-INSPECT.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),
        fromfile='normal/daemon.cpp',tofile='negative/daemon.cpp')))
    if a.prepare_only:print(json.dumps({'status':'PREPARED_NOT_BUILT','source':str(tree)}));return 0
    with (out/'BUILD.log').open('w') as log:
        result=subprocess.run(['sh','node/build.sh','static'],cwd=tree,stdout=log,stderr=subprocess.STDOUT,timeout=600)
    return result.returncode
if __name__=='__main__':raise SystemExit(main())
