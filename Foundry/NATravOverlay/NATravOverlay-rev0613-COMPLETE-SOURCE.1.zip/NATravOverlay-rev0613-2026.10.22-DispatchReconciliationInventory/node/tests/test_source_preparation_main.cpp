#include "journal.hpp"
#include "source_validation_work.hpp"
#include <fstream>
#include <iostream>
#include <iterator>
#include <memory>
namespace natrav_overlay {
std::string source_preparation_boundary_probe(NodeState&);
std::string source_preparation_automatic_probe(NodeState&);
std::string source_eligibility_boundary_probe(NodeState&);
std::string parsed_source_progress_boundary_probe(NodeState&);
std::string parsed_source_progress_append_failure_probe(NodeState&);
std::string parsed_source_progress_post_append_failure_probe(NodeState&);
std::string source_outbound_admission_boundary_probe(NodeState&);
}
static std::string journal_digest(const std::filesystem::path& state) {
    std::ifstream input(state / "state.journal", std::ios::binary);
    if (!input) { throw std::runtime_error("fixture journal unavailable"); }
    const std::string bytes((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
    return datacube::hex_lower(datacube::sha256(datacube::text_octets(bytes)));
}
int main(int argc, char** argv) {
    using namespace natrav_overlay;
    if (argc != 3) { std::cerr << "usage: source-preparation-probe STATE boundary|eligibility|transaction|append-failure|post-append-failure|outbound|automatic|replay|terminal-seal\n"; return 2; }
    try {
        const std::string mode(argv[2]);
        if (mode != "boundary" && mode != "eligibility" && mode != "transaction" && mode != "append-failure" && mode != "post-append-failure" && mode != "outbound" && mode != "automatic" && mode != "replay" && mode != "terminal-seal") { return 2; }
        const auto before = journal_digest(argv[1]);
        std::unique_ptr<NodeState> state;
        SourceValidationWork construction;
        {
            SourceValidationWorkScope scope(construction);
            state = std::make_unique<NodeState>(argv[1], "A", 268435456U);
        }
        const auto initial = state->snapshot().logical_state_digest;
        std::string result = "{}";
        if (mode == "boundary") { result = source_preparation_boundary_probe(*state); }
        if (mode == "eligibility") { result = source_eligibility_boundary_probe(*state); }
        if (mode == "transaction") { result = parsed_source_progress_boundary_probe(*state); }
        if (mode == "append-failure") { result = parsed_source_progress_append_failure_probe(*state); }
        if (mode == "post-append-failure") { result = parsed_source_progress_post_append_failure_probe(*state); }
        if (mode == "outbound") { result = source_outbound_admission_boundary_probe(*state); }
        if (mode == "automatic") { result = source_preparation_automatic_probe(*state); }
        if (mode == "append-failure" || mode == "post-append-failure") {
            std::string head_code;
            try {
                static_cast<void>(state->live_state_head_json());
                throw std::runtime_error("poisoned writer returned a live authenticated head");
            } catch (const AppError& failure) { head_code = failure.code(); }
            if (head_code != "STATE_RESTART_REQUIRED") {
                throw std::runtime_error("live head did not reject poisoned writer");
            }
            std::string terminal_code;
            try {
                static_cast<void>(state->seal_terminal_state_head_json());
                throw std::runtime_error("poisoned writer returned a terminal authenticated head");
            } catch (const AppError& failure) { terminal_code = failure.code(); }
            if (terminal_code != "STATE_RESTART_REQUIRED") {
                throw std::runtime_error("terminal head did not reject poisoned writer");
            }
            result.pop_back();
            result += ",\"live_state_head_code\":" + json_string(head_code) +
                ",\"terminal_state_head_code\":" + json_string(terminal_code) + "}";
        }
        if (mode == "terminal-seal") {
            auto event = state->lifecycle_history().back();
            const auto terminal = state->seal_terminal_state_head_json();
            unsigned rejected = 0U;
            auto refuse = [&](auto action) {
                try { action(); throw std::runtime_error("mutation accepted after terminal sealing"); }
                catch (const AppError& error) {
                    if (error.code() != "STATE_TERMINAL") throw;
                    ++rejected;
                }
            };
            refuse([&] { state->record_lifecycle_event(event); });
            refuse([&] { static_cast<void>(state->compact()); });
            refuse([&] { static_cast<void>(state->authenticate_state({}, "no later auth")); });
            refuse([&] { static_cast<void>(state->seal_terminal_state_head_json()); });
            result = "{\"rejected_after_seal\":" + std::to_string(rejected) +
                ",\"head\":" + terminal + "}";
        }
        const auto after = journal_digest(argv[1]);
        const auto final = state->snapshot().logical_state_digest;
        if (mode != "automatic" && mode != "post-append-failure" && (before != after || initial != final)) {
            throw std::runtime_error("read-only preparation probe changed durable or logical state");
        }
        std::cout << "{\"format\":\"SOURCE_ELIGIBILITY_PROBE_V1\",\"status\":\"PASS\",\"mode\":" << json_string(mode)
                  << ",\"journal_before_sha256\":" << json_string(before)
                  << ",\"journal_after_sha256\":" << json_string(after)
                  << ",\"logical_state_digest\":" << json_string(datacube::hex_lower(final))
                  << ",\"construction_work\":" << source_validation_work_json(construction)
                  << ",\"result\":" << result << "}\n";
        return 0;
    } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
