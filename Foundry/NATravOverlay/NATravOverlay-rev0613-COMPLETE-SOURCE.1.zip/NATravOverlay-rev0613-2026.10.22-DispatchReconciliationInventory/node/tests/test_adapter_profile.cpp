#include "adapter_profile.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fcntl.h>
#include <fstream>
#include <functional>
#include <iostream>
#include <limits>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace {

using natrav_overlay::AdapterProfileError;
using natrav_overlay::AdapterSha256;
using natrav_overlay::OperatorPinnedAdapterProfile;
using natrav_overlay::VerifiedAdapterExecutable;

struct CaseRecord final {
    std::string name;
    std::size_t assertions{0U};
};

class Probe final {
public:
    template <typename Function>
    void run_case(std::string name, Function&& function) {
        const auto before = assertions_;
        function();
        cases_.push_back(CaseRecord{
            .name = std::move(name),
            .assertions = assertions_ - before,
        });
    }

    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_code(
        Function&& function,
        const std::string_view expected,
        const std::string_view detail) {
        ++assertions_;
        try {
            function();
        } catch (const AdapterProfileError& error) {
            if (error.code() == expected) {
                return;
            }
            throw std::runtime_error(
                std::string(detail) + ": expected " + std::string(expected) +
                ", observed " + error.code());
        }
        throw std::runtime_error(std::string(detail) + ": no error");
    }

    [[nodiscard]] std::size_t assertions() const noexcept { return assertions_; }
    [[nodiscard]] const std::vector<CaseRecord>& cases() const noexcept {
        return cases_;
    }

private:
    std::size_t assertions_{0U};
    std::vector<CaseRecord> cases_{};
};

class TempDirectory final {
public:
    TempDirectory() {
        std::array<char, 128U> pattern{};
        const std::string value = "/tmp/natrav-adapter-profile-XXXXXX";
        std::copy(value.begin(), value.end(), pattern.begin());
        char* created = ::mkdtemp(pattern.data());
        if (created == nullptr) {
            throw std::runtime_error("mkdtemp failed");
        }
        path_ = created;
        if (::chmod(path_.c_str(), S_IRWXU) != 0) {
            throw std::runtime_error("chmod temp directory failed");
        }
    }
    TempDirectory(const TempDirectory&) = delete;
    TempDirectory& operator=(const TempDirectory&) = delete;
    ~TempDirectory() { std::filesystem::remove_all(path_); }
    [[nodiscard]] const std::filesystem::path& path() const noexcept { return path_; }
private:
    std::filesystem::path path_{};
};

[[nodiscard]] std::vector<std::uint8_t> read_file(
    const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        throw std::runtime_error("open fixture failed");
    }
    return std::vector<std::uint8_t>(
        std::istreambuf_iterator<char>(input),
        std::istreambuf_iterator<char>());
}

void copy_executable(
    const std::filesystem::path& source,
    const std::filesystem::path& destination) {
    std::filesystem::copy_file(
        source, destination, std::filesystem::copy_options::overwrite_existing);
    if (::chmod(destination.c_str(), S_IRUSR | S_IWUSR | S_IXUSR) != 0) {
        throw std::runtime_error("chmod fixture failed");
    }
}

[[nodiscard]] OperatorPinnedAdapterProfile make_profile(
    const std::filesystem::path& executable,
    const AdapterSha256& executable_sha256) {
    OperatorPinnedAdapterProfile profile;
    profile.profile_id = "fixture-alpha";
    profile.generation = 1U;
    profile.executable = executable;
    profile.executable_sha256 = executable_sha256;
    profile.arguments = {"alpha", "two words", "percent%value"};
    profile.mtu = 1'200U;
    profile.capability_profile = 1U;
    profile.max_frame_bytes = 65'536U;
    profile.max_queued_bytes = 1'048'576U;
    profile.max_outstanding_requests = 1U;
    profile.max_evidence_events = 256U;
    profile.max_launch_attempts = 5U;
    profile.startup_timeout = std::chrono::milliseconds(2'000);
    profile.request_timeout = std::chrono::milliseconds(500);
    profile.shutdown_timeout = std::chrono::milliseconds(500);
    profile.initial_restart_backoff = std::chrono::milliseconds(10);
    profile.maximum_restart_backoff = std::chrono::milliseconds(50);
    return profile;
}

[[nodiscard]] std::string run_verified_image(
    const VerifiedAdapterExecutable& image,
    const OperatorPinnedAdapterProfile& profile) {
    std::array<int, 2U> sockets{-1, -1};
    if (::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0, sockets.data()) != 0) {
        throw std::runtime_error("socketpair failed");
    }
    const int image_descriptor = image.duplicate_for_exec(4);
    std::vector<std::string> argument_storage;
    argument_storage.reserve(profile.arguments.size() + 1U);
    argument_storage.push_back(profile.executable.string());
    argument_storage.insert(
        argument_storage.end(), profile.arguments.begin(), profile.arguments.end());
    std::vector<char*> arguments;
    arguments.reserve(argument_storage.size() + 1U);
    for (auto& argument : argument_storage) {
        arguments.push_back(argument.data());
    }
    arguments.push_back(nullptr);
    std::vector<std::string> environment_storage{
        "LANG=C",
        "LC_ALL=C",
        "NATRAV_ADAPTER_FD=3",
        "NATRAV_ADAPTER_PROTOCOL=NAPA0001",
        "PYTHONDONTWRITEBYTECODE=1",
    };
    std::vector<char*> environment;
    environment.reserve(environment_storage.size() + 1U);
    for (auto& item : environment_storage) {
        environment.push_back(item.data());
    }
    environment.push_back(nullptr);

    const pid_t child = ::fork();
    if (child < 0) {
        throw std::runtime_error("fork failed");
    }
    if (child == 0) {
        static_cast<void>(::close(sockets[0U]));
        if (sockets[1U] != 3) {
            if (::dup2(sockets[1U], 3) < 0) {
                _exit(120);
            }
            static_cast<void>(::close(sockets[1U]));
        }
        const int fd3_flags = ::fcntl(3, F_GETFD, 0);
        if (fd3_flags < 0 || ::fcntl(3, F_SETFD, fd3_flags & ~FD_CLOEXEC) != 0) {
            _exit(121);
        }
        int exec_descriptor = image_descriptor;
        if (exec_descriptor != 4) {
            if (::dup3(exec_descriptor, 4, O_CLOEXEC) < 0) {
                _exit(122);
            }
            static_cast<void>(::close(exec_descriptor));
            exec_descriptor = 4;
        }
        const int exec_flags = ::fcntl(exec_descriptor, F_GETFD, 0);
        if (exec_flags < 0 ||
            ::fcntl(exec_descriptor, F_SETFD, exec_flags | FD_CLOEXEC) != 0) {
            _exit(123);
        }
        const int null_descriptor = ::open("/dev/null", O_RDWR | O_CLOEXEC);
        if (null_descriptor < 0) {
            _exit(124);
        }
        for (int target = 0; target <= 2; ++target) {
            if (::dup2(null_descriptor, target) < 0) {
                _exit(125);
            }
        }
        if (null_descriptor > 4) {
            static_cast<void>(::close(null_descriptor));
        }
#if defined(SYS_close_range)
        if (::syscall(SYS_close_range, 5U, ~0U, 0U) != 0 &&
            errno != ENOSYS && errno != EINVAL) {
            _exit(126);
        }
#else
        for (int descriptor = 5; descriptor < 1'024; ++descriptor) {
            static_cast<void>(::close(descriptor));
        }
#endif
        static_cast<void>(natrav_overlay::execute_verified_adapter_image(
            exec_descriptor, arguments.data(), environment.data()));
        _exit(127);
    }

    static_cast<void>(::close(sockets[1U]));
    static_cast<void>(::close(image_descriptor));
    std::array<char, 65'536U> buffer{};
    const auto received = ::recv(sockets[0U], buffer.data(), buffer.size(), 0);
    const int receive_errno = errno;
    static_cast<void>(::close(sockets[0U]));
    int status = 0;
    pid_t waited = -1;
    do {
        waited = ::waitpid(child, &status, 0);
    } while (waited < 0 && errno == EINTR);
    if (received <= 0 || waited != child || !WIFEXITED(status) ||
        WEXITSTATUS(status) != 0) {
        throw std::runtime_error(
            "verified image child failed: recv=" + std::to_string(received) +
            " errno=" + std::to_string(receive_errno) +
            " status=" + std::to_string(status));
    }
    return std::string(buffer.data(), static_cast<std::size_t>(received));
}

[[nodiscard]] bool contains_line(
    const std::string_view text,
    const std::string_view line) {
    const std::string needle = std::string(line) + '\n';
    return text.find(needle) != std::string_view::npos;
}

}  // namespace

int main(int argc, char* argv[]) {
    Probe probe;
    try {
        if (argc != 3) {
            throw std::runtime_error("expected fixture A and fixture B paths");
        }
        const std::filesystem::path fixture_a = std::filesystem::absolute(argv[1]);
        const std::filesystem::path fixture_b = std::filesystem::absolute(argv[2]);
        const auto digest_a = natrav_overlay::adapter_sha256(read_file(fixture_a));
        const auto digest_b = natrav_overlay::adapter_sha256(read_file(fixture_b));
        TempDirectory temporary;
        const auto executable = temporary.path() / "adapter-fixture";
        copy_executable(fixture_a, executable);
        auto profile = make_profile(executable, digest_a);

        probe.run_case("canonical profile and locator", [&] {
            natrav_overlay::validate_operator_pinned_adapter_profile_transition(
                nullptr, profile);
            const auto text =
                natrav_overlay::operator_pinned_adapter_profile_text(profile);
            const auto parsed =
                natrav_overlay::parse_operator_pinned_adapter_profile(text);
            probe.check(parsed == profile, "profile canonical round trip");
            probe.check(
                natrav_overlay::operator_pinned_adapter_profile_text(parsed) == text,
                "profile re-encoding is byte exact");
            probe.check(
                natrav_overlay::adapter_sha256_hex(
                    natrav_overlay::operator_pinned_adapter_profile_sha256(profile))
                    .size() == 64U,
                "profile digest is canonical SHA-256 hex");
            const natrav_overlay::AdapterTransportLocator locator{
                .profile_id = profile.profile_id,
                .profile_generation = profile.generation,
                .link_id = 0x0102030405060708ULL,
                .epoch = 7U,
            };
            const auto locator_text =
                natrav_overlay::adapter_transport_locator_text(locator);
            probe.check(
                locator_text ==
                    "adapter-v1|profile=fixture-alpha|generation=1|link=0102030405060708|epoch=7",
                "adapter locator spelling is exact");
            probe.check(
                natrav_overlay::parse_adapter_transport_locator(locator_text) == locator,
                "adapter locator canonical round trip");
            const std::array<OperatorPinnedAdapterProfile, 1U> profiles{profile};
            probe.check(
                &natrav_overlay::resolve_adapter_profile(profiles, locator) ==
                    &profiles.front(),
                "locator resolves exact identifier and generation");
        });

        probe.run_case("profile negative controls", [&] {
            auto noncanonical =
                natrav_overlay::operator_pinned_adapter_profile_text(profile);
            const auto position = noncanonical.find("startup-timeout-ms=2000");
            if (position == std::string::npos) {
                throw std::runtime_error("canonical profile field not found");
            }
            noncanonical.replace(position, std::strlen("startup-timeout-ms=2000"),
                                 "startup-timeout-ms=02000");
            probe.expect_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::parse_operator_pinned_adapter_profile(
                            noncanonical));
                },
                "ADAPTER_PROFILE_NONCANONICAL",
                "leading-zero numeric profile field rejected");
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::parse_adapter_transport_locator(
                        "adapter-v1|profile=fixture-alpha|generation=1|link=010203040506070A|epoch=7"));
                },
                "ADAPTER_LOCATOR_NONCANONICAL",
                "uppercase locator hex rejected");
            auto invalid = profile;
            invalid.arguments.push_back(std::string(4'097U, 'x'));
            probe.expect_code(
                [&] {
                    natrav_overlay::validate_operator_pinned_adapter_profile(invalid);
                },
                "ADAPTER_ARGUMENTS_INVALID",
                "oversize argument rejected");
            const std::array<OperatorPinnedAdapterProfile, 2U> duplicates{
                profile, profile};
            const natrav_overlay::AdapterTransportLocator locator{
                .profile_id = profile.profile_id,
                .profile_generation = profile.generation,
                .link_id = 1U,
                .epoch = 1U,
            };
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::resolve_adapter_profile(
                        duplicates, locator));
                },
                "ADAPTER_PROFILE_AMBIGUOUS",
                "duplicate stable profile identifiers rejected");
        });

        probe.run_case("canonical record mutation controls", [&] {
            const auto canonical =
                natrav_overlay::operator_pinned_adapter_profile_text(profile);
            probe.expect_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::parse_operator_pinned_adapter_profile(
                            canonical.substr(0U, canonical.size() - 1U)));
                },
                "ADAPTER_PROFILE_INVALID",
                "missing terminal newline rejected");
            probe.expect_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::parse_operator_pinned_adapter_profile(
                            canonical + "unexpected=1\n"));
                },
                "ADAPTER_PROFILE_INVALID",
                "trailing profile field rejected");
            auto lowercase_escape = canonical;
            const auto escaped = lowercase_escape.find("two%20words");
            if (escaped == std::string::npos) {
                throw std::runtime_error("escaped argument not found");
            }
            lowercase_escape.replace(escaped, std::strlen("two%20words"),
                                     "two%2fwords");
            probe.expect_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::parse_operator_pinned_adapter_profile(
                            lowercase_escape));
                },
                "ADAPTER_PROFILE_NONCANONICAL",
                "lowercase percent escape rejected");
            auto uppercase_digest = canonical;
            const auto digest_position = uppercase_digest.find("sha256=");
            if (digest_position == std::string::npos) {
                throw std::runtime_error("digest field not found");
            }
            for (std::size_t index = digest_position + 7U;
                 index < digest_position + 71U; ++index) {
                if (uppercase_digest[index] >= 'a' && uppercase_digest[index] <= 'f') {
                    uppercase_digest[index] = static_cast<char>(
                        uppercase_digest[index] - 'a' + 'A');
                    break;
                }
            }
            probe.expect_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::parse_operator_pinned_adapter_profile(
                            uppercase_digest));
                },
                "ADAPTER_SHA256_NONCANONICAL",
                "uppercase SHA-256 rejected");
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::parse_adapter_transport_locator(
                        "adapter-v1|profile=fixture-alpha|generation=1|link=0000000000000000|epoch=7"));
                },
                "ADAPTER_LOCATOR_INVALID",
                "zero link identifier rejected");
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::parse_adapter_transport_locator(
                        "adapter-v1|profile=fixture-alpha|generation=1|link=0102030405060708|epoch=0"));
                },
                "ADAPTER_PROFILE_INVALID",
                "zero epoch rejected");
        });

        probe.run_case("authorized profile succession", [&] {
            auto proposed = profile;
            proposed.generation = 2U;
            proposed.previous_profile_sha256 =
                natrav_overlay::operator_pinned_adapter_profile_sha256(profile);
            proposed.arguments.push_back("generation-two");
            natrav_overlay::validate_operator_pinned_adapter_profile_transition(
                &profile, proposed);
            probe.check(true, "exact predecessor transition accepted");
            auto wrong_generation = proposed;
            wrong_generation.generation = 3U;
            probe.expect_code(
                [&] {
                    natrav_overlay::validate_operator_pinned_adapter_profile_transition(
                        &profile, wrong_generation);
                },
                "ADAPTER_PROFILE_TRANSITION_UNAUTHORIZED",
                "generation skip rejected");
            auto wrong_predecessor = proposed;
            wrong_predecessor.previous_profile_sha256.fill(0x5aU);
            probe.expect_code(
                [&] {
                    natrav_overlay::validate_operator_pinned_adapter_profile_transition(
                        &profile, wrong_predecessor);
                },
                "ADAPTER_PROFILE_TRANSITION_UNAUTHORIZED",
                "incorrect predecessor digest rejected");
            auto wrong_id = proposed;
            wrong_id.profile_id = "fixture-beta";
            probe.expect_code(
                [&] {
                    natrav_overlay::validate_operator_pinned_adapter_profile_transition(
                        &profile, wrong_id);
                },
                "ADAPTER_PROFILE_TRANSITION_UNAUTHORIZED",
                "stable identifier replacement rejected");
            const std::array<OperatorPinnedAdapterProfile, 2U> history{
                profile, proposed};
            const natrav_overlay::AdapterTransportLocator old_locator{
                .profile_id = profile.profile_id,
                .profile_generation = 1U,
                .link_id = 2U,
                .epoch = 1U,
            };
            auto new_locator = old_locator;
            new_locator.profile_generation = 2U;
            probe.check(
                &natrav_overlay::resolve_adapter_profile(history, old_locator) ==
                    &history[0U],
                "profile history resolves generation one exactly");
            probe.check(
                &natrav_overlay::resolve_adapter_profile(history, new_locator) ==
                    &history[1U],
                "profile history resolves generation two exactly");
            auto missing_locator = new_locator;
            missing_locator.profile_generation = 3U;
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::resolve_adapter_profile(
                        history, missing_locator));
                },
                "ADAPTER_PROFILE_NOT_FOUND",
                "unrecorded profile generation rejected");
        });

        probe.run_case("sealed exact image survives path replacement", [&] {
            auto image = natrav_overlay::open_verified_adapter_executable(profile);
            probe.check(image.sha256() == digest_a, "verified digest retained");
            probe.check(image.size() == read_file(fixture_a).size(),
                        "verified image size retained");
            probe.check(image.source_inode() != 0U,
                        "verified image source inode retained");
            probe.check(image.configured_path() == executable,
                        "verified image retains the authorized locator");
            const auto old_path = temporary.path() / "adapter-old";
            std::filesystem::rename(executable, old_path);
            copy_executable(fixture_b, executable);
            const auto report = run_verified_image(image, profile);
            probe.check(contains_line(report, "marker=A"),
                        "sealed image executes approved A bytes after replacement");
            probe.check(contains_line(report, "argc=4"),
                        "exact bounded argument vector reaches image");
            probe.check(contains_line(report, "argv=alpha") &&
                            contains_line(report, "argv=two words") &&
                            contains_line(report, "argv=percent%value"),
                        "exact profile arguments preserved");
            probe.check(contains_line(report, "env-count=5"),
                        "minimal environment has exact cardinality");
            probe.check(contains_line(report, "extra-fd-count=0"),
                        "sealed image descriptor closes across exec");
            probe.expect_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::open_verified_adapter_executable(profile));
                },
                "ADAPTER_EXECUTABLE_DIGEST_MISMATCH",
                "path replacement cannot satisfy old digest");
        });

        probe.run_case("authorized replacement executes new image", [&] {
            auto replacement = profile;
            replacement.generation = 2U;
            replacement.previous_profile_sha256 =
                natrav_overlay::operator_pinned_adapter_profile_sha256(profile);
            replacement.executable_sha256 = digest_b;
            replacement.arguments = {"replacement"};
            natrav_overlay::validate_operator_pinned_adapter_profile_transition(
                &profile, replacement);
            auto image =
                natrav_overlay::open_verified_adapter_executable(replacement);
            const auto report = run_verified_image(image, replacement);
            probe.check(contains_line(report, "marker=B"),
                        "authorized successor executes B bytes");
            probe.check(contains_line(report, "argc=2") &&
                            contains_line(report, "argv=replacement"),
                        "authorized successor argument vector is exact");
        });

        probe.run_case("executable path and mode negatives", [&] {
            const auto symlink_path = temporary.path() / "adapter-symlink";
            std::filesystem::create_symlink(executable, symlink_path);
            auto symlink_profile = profile;
            symlink_profile.executable = symlink_path;
            symlink_profile.executable_sha256 = digest_b;
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::open_verified_adapter_executable(
                        symlink_profile));
                },
                "ADAPTER_EXECUTABLE_SYMLINK",
                "final executable symlink rejected");

            const auto real_parent = temporary.path() / "real-parent";
            const auto alias_parent = temporary.path() / "alias-parent";
            std::filesystem::create_directory(real_parent);
            if (::chmod(real_parent.c_str(), S_IRWXU) != 0) {
                throw std::runtime_error("chmod real parent failed");
            }
            const auto nested = real_parent / "adapter";
            copy_executable(fixture_b, nested);
            std::filesystem::create_directory_symlink(real_parent, alias_parent);
            auto parent_symlink_profile = profile;
            parent_symlink_profile.executable = alias_parent / "adapter";
            parent_symlink_profile.executable_sha256 = digest_b;
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::open_verified_adapter_executable(
                        parent_symlink_profile));
                },
                "ADAPTER_EXECUTABLE_SYMLINK",
                "parent executable symlink rejected");

            const auto writable = temporary.path() / "adapter-writable";
            copy_executable(fixture_b, writable);
            if (::chmod(writable.c_str(), S_IRWXU | S_IWGRP) != 0) {
                throw std::runtime_error("chmod writable fixture failed");
            }
            auto writable_profile = profile;
            writable_profile.executable = writable;
            writable_profile.executable_sha256 = digest_b;
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::open_verified_adapter_executable(
                        writable_profile));
                },
                "ADAPTER_EXECUTABLE_UNSAFE",
                "group-writable executable rejected");

            const auto nonexecutable = temporary.path() / "adapter-no-exec";
            copy_executable(fixture_b, nonexecutable);
            if (::chmod(nonexecutable.c_str(), S_IRUSR | S_IWUSR) != 0) {
                throw std::runtime_error("chmod nonexecutable fixture failed");
            }
            auto nonexecutable_profile = profile;
            nonexecutable_profile.executable = nonexecutable;
            nonexecutable_profile.executable_sha256 = digest_b;
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::open_verified_adapter_executable(
                        nonexecutable_profile));
                },
                "ADAPTER_EXECUTABLE_UNSAFE",
                "nonexecutable image rejected");

            const auto setid = temporary.path() / "adapter-setid";
            copy_executable(fixture_b, setid);
            if (::chmod(setid.c_str(), S_IRWXU | S_ISUID) != 0) {
                throw std::runtime_error("chmod setid fixture failed");
            }
            auto setid_profile = profile;
            setid_profile.executable = setid;
            setid_profile.executable_sha256 = digest_b;
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::open_verified_adapter_executable(
                        setid_profile));
                },
                "ADAPTER_EXECUTABLE_UNSAFE",
                "set-id executable rejected");

            auto missing_profile = profile;
            missing_profile.executable = temporary.path() / "adapter-missing";
            missing_profile.executable_sha256 = digest_b;
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::open_verified_adapter_executable(
                        missing_profile));
                },
                "ADAPTER_EXECUTABLE_OPEN_FAILED",
                "missing executable rejected");

            const auto text_file = temporary.path() / "adapter-text";
            {
                std::ofstream output(text_file, std::ios::binary);
                output << "not an ELF adapter\n";
            }
            if (::chmod(text_file.c_str(), S_IRUSR | S_IWUSR | S_IXUSR) != 0) {
                throw std::runtime_error("chmod text fixture failed");
            }
            auto text_profile = profile;
            text_profile.executable = text_file;
            text_profile.executable_sha256 =
                natrav_overlay::adapter_sha256(read_file(text_file));
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::open_verified_adapter_executable(
                        text_profile));
                },
                "ADAPTER_EXECUTABLE_FORMAT_INVALID",
                "non-ELF adapter image rejected");
        });

        probe.run_case("bounded restart schedule", [&] {
            probe.check(
                natrav_overlay::adapter_restart_backoff(profile, 1U) ==
                    std::chrono::milliseconds(10),
                "first launch delay is initial bound");
            probe.check(
                natrav_overlay::adapter_restart_backoff(profile, 2U) ==
                    std::chrono::milliseconds(20),
                "second launch doubles backoff");
            probe.check(
                natrav_overlay::adapter_restart_backoff(profile, 3U) ==
                    std::chrono::milliseconds(40),
                "third launch doubles backoff");
            probe.check(
                natrav_overlay::adapter_restart_backoff(profile, 4U) ==
                    std::chrono::milliseconds(50) &&
                natrav_overlay::adapter_restart_backoff(profile, 5U) ==
                    std::chrono::milliseconds(50),
                "backoff remains capped");
            probe.expect_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::adapter_restart_backoff(profile, 6U));
                },
                "ADAPTER_RESTART_ATTEMPT_INVALID",
                "restart exhaustion rejected");
        });

        std::cout << "{\"format\":\"NATRAV_ADAPTER_PROFILE_PROBE_V1\","
                  << "\"status\":\"PASS\",\"cases\":" << probe.cases().size()
                  << ",\"assertions\":" << probe.assertions()
                  << ",\"case_records\":[";
        for (std::size_t index = 0U; index < probe.cases().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            std::cout << "{\"name\":\"" << probe.cases()[index].name
                      << "\",\"assertions\":"
                      << probe.cases()[index].assertions << '}';
        }
        std::cout << "]}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cout << "{\"format\":\"NATRAV_ADAPTER_PROFILE_PROBE_V1\","
                  << "\"status\":\"FAIL\",\"assertions\":"
                  << probe.assertions() << ",\"detail\":\"" << error.what()
                  << "\"}\n";
        return 1;
    }
}
