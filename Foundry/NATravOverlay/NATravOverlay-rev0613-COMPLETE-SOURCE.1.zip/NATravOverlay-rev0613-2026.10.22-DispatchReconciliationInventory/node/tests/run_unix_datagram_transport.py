#!/usr/bin/env python3
"""Owner-controlled Unix-domain datagram packet carrier regression."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from typing import Any

from run_multi_route import write_v13_config
from run_peer_sessions import outbox_entry, submit
from run_persistent import Harness, operation


EXPECTED_REVISION = "0613"
EXPECTED_FEATURE = "OWNER_CONTROLLED_UNIX_DATAGRAM_PACKET_CARRIER_V1"


def locator(local: Path, remote: Path, link: str, epoch: int, mtu: int = 512) -> str:
    return (
        f"unix-dgram-v1|local={local}|remote={remote}|mtu={mtu}|"
        f"link={link}|epoch={epoch}|profile=1"
    )


def run_external(
    h: Harness,
    label: str,
    command: list[str],
    *,
    timeout: float,
) -> subprocess.CompletedProcess[str]:
    started = time.monotonic()
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        timeout=timeout,
        env=dict(os.environ, TERM="dumb", PYTHONDONTWRITEBYTECODE="1"),
    )
    record = {
        "label": label,
        "args": command,
        "returncode": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
        "elapsed_seconds": time.monotonic() - started,
    }
    h.commands.append(record)
    index = len(h.commands)
    (h.logs / f"{index:03d}-{label}.stdout.txt").write_text(completed.stdout)
    (h.logs / f"{index:03d}-{label}.stderr.txt").write_text(completed.stderr)
    return completed


def run_suite(h: Harness) -> dict[str, Any]:
    source_root = Path(__file__).resolve().parents[2]
    evidence: dict[str, Any] = {}

    def revision_and_source_boundary() -> None:
        version = h.run("unix-dgram-version", ["version"])
        h.check(version is not None and version.get("version") == EXPECTED_REVISION,
                "revision marker is 0595")
        h.check(version is not None and version.get("unix_datagram_transport") ==
                EXPECTED_FEATURE,
                "Unix datagram carrier marker is exact")
        h.check(version is not None and version.get("packet_port") ==
                "OWNED_COMPLETE_DATAGRAM_PACKET_PORT_V1",
                "owned packet-port seam is retained")
        h.check(version is not None and version.get("packet_link_core") ==
                "FINITE_PACKET_LINK_SERVICE_V1",
                "finite packet service remains below the ordered stream")
        h.check(version is not None and version.get("tls_byte_channel") ==
                "OPENSSL_BYTE_CHANNEL_BIO_V1",
                "TLS remains above the carrier-neutral byte channel")

        transport_header = (source_root / "node/src/transport.hpp").read_text()
        transport_source = (source_root / "node/src/transport.cpp").read_text()
        carrier_header = (source_root / "node/src/unix_datagram_transport.hpp").read_text()
        carrier_source = (source_root / "node/src/unix_datagram_transport.cpp").read_text()
        config_source = (source_root / "node/src/config.cpp").read_text()
        tls_source = (source_root / "node/src/tls.cpp").read_text()
        node_source = (source_root / "node/src/node.cpp").read_text()
        build_script = (source_root / "node/build.sh").read_text()

        h.check("unix_datagram = 4U" in transport_header and
                "UnixDatagramTransportLocator" in transport_header,
                "Unix datagrams are one explicit typed production carrier")
        h.check("unix-dgram-v1|" in carrier_source and
                "UNIX_DATAGRAM_LOCATOR_NONCANONICAL" in carrier_source,
                "filesystem locators use one canonical versioned grammar")
        h.check("O_NOFOLLOW" in carrier_source and "::openat" in carrier_source and
                "AT_SYMLINK_NOFOLLOW" in carrier_source,
                "parent traversal and leaf observation refuse symlink following")
        h.check("::fstat" in carrier_source and "::lstat" in carrier_source and
                "same_object" in carrier_source,
                "descriptor and path identities are compared before use and cleanup")
        h.check("S_IRWXG | S_IRWXO" in carrier_source and "::geteuid()" in carrier_source,
                "parent and socket objects must remain owner controlled")
        h.check("SOCK_DGRAM" in carrier_source and "SO_PASSCRED" in carrier_source and
                "SCM_CREDENTIALS" in carrier_source,
                "the carrier owns complete Unix datagrams and verifies sender credentials")
        h.check("MSG_TRUNC" in carrier_source and "UNIX_DATAGRAM_TRUNCATED" in carrier_source,
                "oversize datagrams are rejected instead of silently truncated")
        h.check("cleanup_owned_path_noexcept" in carrier_source and
                "::unlinkat" in carrier_source and "UNIX_DATAGRAM_PATH_REPLACED" in carrier_source,
                "cleanup is inode checked and replacement is fail-closed")
        h.check("make_packet_port_ordered_byte_stream" in carrier_source and
                "FinitePacketStream" not in carrier_source,
                "the carrier enters the existing finite service only through OwnedPacketPort")
        h.check("CONFIG_UNIX_DATAGRAM_ROLE_CONFLICT" in config_source and
                "CONFIG_UNIX_DATAGRAM_SELF_ROUTE" in config_source,
                "configuration rejects conflicting local and self-route ownership")
        h.check('code.starts_with("UNIX_DATAGRAM_")' in tls_source and
                'error.code().starts_with("UNIX_DATAGRAM_")' in node_source,
                "carrier failures retain transport-error classification")
        h.check("src/unix_datagram_transport.cpp" in build_script,
                "the sole product executable links the Unix datagram implementation")
        h.check("abstract" not in carrier_header.lower() and
                "discovery" not in carrier_header.lower() and
                "identity" not in carrier_header.lower(),
                "the carrier declaration exposes no abstract namespace, discovery, or identity claim")
        parse_start = transport_source.index("TransportKind parse_transport_kind")
        parse_end = transport_source.index("std::string_view transport_kind_name")
        parse_body = transport_source[parse_start:parse_end]
        h.check('text == "unix-dgram"' in parse_body and
                "packet_link" not in parse_body and "virtual_link" not in parse_body,
                "configured registry exposes Unix datagrams but not private fixture kinds")

    h.case("revision metadata and source ownership boundary", revision_and_source_boundary)

    carrier_root = h.runtime / "unix-datagram-carrier"
    carrier_root.mkdir(mode=0o700)
    carrier_root.chmod(0o700)

    a_listen = carrier_root / "a-listen.sock"
    b_listen = carrier_root / "b-listen.sock"
    a_to_b = carrier_root / "a-to-b.sock"
    b_to_a = carrier_root / "b-to-a.sock"
    link_ab = "554e495844473031"
    link_ba = "554e495844473032"
    listen_a = locator(a_listen, b_to_a, link_ba, 8)
    listen_b = locator(b_listen, a_to_b, link_ab, 7)
    route_ab = locator(a_to_b, b_listen, link_ab, 7)
    route_ba = locator(b_to_a, a_listen, link_ba, 8)

    def configuration_boundary() -> None:
        a = h.identity("A")
        b = h.identity("B")

        def write_config(path: Path, listen: str, routes: list[tuple[str, str]]) -> None:
            lines = [
                "NATRAV_OVERLAY_CONFIG_V13",
                "runtime_generation=unix-dgram-config-v1",
                "node=A",
                f"state={h.runtime / ('config-' + path.stem)}",
                f"listen={listen}",
                "control=control.sock",
                f"identity_cert={a.certificate}",
                f"identity_key={a.private_key}",
                f"identity_pin={a.spki_sha256}",
                "identity_generation=a-g1",
                "deadline_ms=1000",
                "peer_workers=2",
                "peer_queue_capacity=16",
                "control_workers=1",
                "control_queue_capacity=16",
                "session_max_operations=8",
                "session_max_bytes=1048576",
                "session_max_lifetime_ms=10000",
                "session_idle_timeout_ms=3000",
                "outbox_global_max_records=32",
                "outbox_global_max_payload_bytes=1048576",
                "outbox_peer_max_records=16",
                "outbox_peer_max_payload_bytes=524288",
                f"local_control={os.geteuid()},ALL",
                "peer=B,50,200,10,30000",
                f"peer_key=B,b-g1,ACTIVE,{b.spki_sha256}",
                "authorize=B,*,EVIDENCE,unix-dgram/test",
            ]
            for index, (route_id, endpoint) in enumerate(routes):
                lines.append(f"peer_route=B,{route_id},{index},ENABLED,{endpoint}")
            path.write_text("\n".join(lines) + "\n")
            path.chmod(0o600)

        valid = h.work / "unix-dgram-valid.conf"
        write_config(valid, listen_a, [("unix", route_ab)])
        checked = h.run("unix-dgram-config-valid", ["config-check", "--config", str(valid)])
        h.check(checked is not None and checked.get("listen") == listen_a,
                "config-check preserves the exact canonical listener locator")
        assert checked is not None
        h.check(checked["peers"][0]["routes"][0]["endpoint"] == route_ab,
                "config-check preserves the exact canonical route locator")

        role = h.work / "unix-dgram-role.conf"
        role_route = locator(a_listen, b_listen, "554e495844473033", 9)
        write_config(role, listen_a, [("unix", role_route)])
        rejected = h.run("unix-dgram-config-role", ["config-check", "--config", str(role)], expected=3)
        h.check(rejected is not None and rejected.get("code") ==
                "CONFIG_UNIX_DATAGRAM_ROLE_CONFLICT",
                "one local path cannot be listener and outbound route")

        self_route = h.work / "unix-dgram-self.conf"
        self_endpoint = locator(carrier_root / "self-local.sock", a_listen,
                                "554e495844473034", 10)
        write_config(self_route, listen_a, [("unix", self_endpoint)])
        rejected = h.run("unix-dgram-config-self", ["config-check", "--config", str(self_route)], expected=3)
        h.check(rejected is not None and rejected.get("code") ==
                "CONFIG_UNIX_DATAGRAM_SELF_ROUTE",
                "outbound routes cannot target the local listener path")

        duplicate = h.work / "unix-dgram-duplicate.conf"
        shared = carrier_root / "duplicate-local.sock"
        write_config(
            duplicate,
            listen_a,
            [
                ("unix-a", locator(shared, b_listen, "554e495844473035", 11)),
                ("unix-b", locator(shared, carrier_root / "other.sock",
                                   "554e495844473036", 12)),
            ],
        )
        rejected = h.run("unix-dgram-config-duplicate", ["config-check", "--config", str(duplicate)], expected=3)
        h.check(rejected is not None and rejected.get("code") ==
                "CONFIG_PEER_ROUTE_ENDPOINT_AMBIGUOUS",
                "two routes cannot alias one local Unix datagram path")

    h.case("persistent configuration ownership boundary", configuration_boundary)

    def strict_probe() -> None:
        identities = h.identities
        client = identities.identity("unix-probe-client")
        server = identities.identity("unix-probe-server")
        probe = h.output / "unix-datagram-transport-probe"
        sources = [
            "node/tests/test_unix_datagram_transport.cpp",
            "node/src/unix_datagram_transport.cpp",
            "node/src/transport.cpp",
            "node/src/serial_transport.cpp",
            "node/src/udp_transport.cpp",
            "node/src/finite_packet_link.cpp",
            "node/src/packet_port.cpp",
            "node/src/peer_session.cpp",
            "node/src/tls.cpp",
            "node/src/tls_bio.cpp",
            "node/src/socket.cpp",
            "node/src/protocol.cpp",
            "node/src/common.cpp",
            "foundation/src/core.cpp",
            "foundation/src/natrav_peer_session.cpp",
            "foundation/src/natrav_peer_stream.cpp",
            "foundation/src/natrav_peer_message.cpp",
            "foundation/src/natrav_peer_handshake.cpp",
        ]
        command = [
            "/usr/bin/g++", "-D_GNU_SOURCE", "-std=c++20", "-O1", "-g0",
            "-Wall", "-Wextra", "-Wpedantic", "-Wconversion", "-Wsign-conversion",
            "-Wshadow", "-Wformat=2", "-Werror", "-pthread",
            f"-I{source_root / 'foundation/include'}",
            f"-I{source_root / 'node/src'}",
            *(str(source_root / item) for item in sources),
            "-lssl", "-lcrypto", "-lz", "-lzstd", "-ldl", "-o", str(probe),
        ]
        built = run_external(h, "unix-dgram-probe-build", command, timeout=300)
        h.check(built.returncode == 0,
                f"strict-warning probe compiles: {built.stderr[-2000:]}")
        h.check(probe.is_file() and os.access(probe, os.X_OK),
                "strict probe executable is materialized")
        run = run_external(
            h,
            "unix-dgram-probe",
            [
                str(probe),
                str(client.certificate), str(client.private_key), client.spki_sha256,
                str(server.certificate), str(server.private_key), server.spki_sha256,
            ],
            timeout=180,
        )
        h.check(run.returncode == 0,
                f"Unix datagram probe succeeds: {run.stderr[-2000:]}")
        lines = [line for line in run.stdout.splitlines() if line.strip()]
        h.check(len(lines) == 1, "probe emits one JSON line")
        result = json.loads(lines[0])
        h.check(result.get("format") == "NATRAV_UNIX_DATAGRAM_TRANSPORT_PROBE_V1",
                "probe format is exact")
        h.check(result.get("status") == "PASS", "probe reports PASS")
        h.check(result.get("assertions") == 30, "probe assertion account is exact")
        probe_cases = result.get("cases")
        h.check(isinstance(probe_cases, list) and len(probe_cases) == 7,
                "probe covers seven locator, ownership, datagram, stream, and TLS cases")
        assert isinstance(probe_cases, list)
        h.check(sum(int(item["assertions"]) for item in probe_cases) == 30,
                "probe per-case assertion account is exact")
        evidence["probe"] = result

    h.case("strict same-process carrier and authenticated-stack probe", strict_probe)

    def persistent_two_process_lifecycle() -> None:
        root = h.runtime / "unix-datagram-nodes"
        root.mkdir(mode=0o700)
        root.chmod(0o700)
        a_state = root / "a-state"
        b_state = root / "b-state"
        scope_ab = "unix-dgram/a-to-b"
        scope_ba = "unix-dgram/b-to-a"
        a_config = write_v13_config(
            h, "unix-dgram-a", "A", a_state, listen_a, "unix-dgram-a-v1",
            [("B", [("unix-ab", 0, "ENABLED", route_ab)], 50, 200, 30, 30_000)],
            authorizations=[("B", scope_ba)], deadline_ms=1200,
            session_operations=8, session_idle_ms=1200,
        )
        b_config = write_v13_config(
            h, "unix-dgram-b", "B", b_state, listen_b, "unix-dgram-b-v1",
            [("A", [("unix-ba", 0, "ENABLED", route_ba)], 50, 200, 30, 30_000)],
            authorizations=[("A", scope_ab)], deadline_ms=1200,
            session_operations=8, session_idle_ms=1200,
        )

        b = h.start("unix-dgram-b-1", b_config, b_state)
        a = h.start("unix-dgram-a-1", a_config, a_state)
        h.check(a_listen.is_socket() and b_listen.is_socket(),
                "both complete nodes own their explicit listener paths")

        op_ab = operation("unix-datagram-persistent-a-to-b")
        op_ba = operation("unix-datagram-persistent-b-to-a")
        submit(h, "unix-dgram-submit-ab", a.control, "A", "B", scope_ab,
               op_ab, "A-to-B over owner-controlled Unix datagrams " + "x" * 4096)
        submit(h, "unix-dgram-submit-ba", b.control, "B", "A", scope_ba,
               op_ba, "B-to-A over owner-controlled Unix datagrams " + "y" * 4096)

        def both_acked() -> bool:
            a_status = h.status("unix-dgram-wait-a", a_state, logical_digest=False)
            b_status = h.status("unix-dgram-wait-b", b_state, logical_digest=False)
            return (outbox_entry(a_status, op_ab)["status"] == "ACKED" and
                    outbox_entry(b_status, op_ba)["status"] == "ACKED")

        h.wait("both Unix datagram obligations receive bound receipts", both_acked, 20.0)
        a_status = h.status("unix-dgram-a-status", a_state, logical_digest=False)
        b_status = h.status("unix-dgram-b-status", b_state, logical_digest=False)
        h.check(a_status["inbound_records"] == 1 and b_status["inbound_records"] == 1,
                "each authenticated recipient admits the opposite operation exactly once")
        h.check(outbox_entry(a_status, op_ab)["status"] == "ACKED" and
                outbox_entry(b_status, op_ba)["status"] == "ACKED",
                "both senders retain exact terminal outbox receipts")

        a.shutdown()
        b.shutdown()
        h.check(all(not path.exists() for path in (a_listen, b_listen, a_to_b, b_to_a)),
                "orderly shutdown removes only the four socket objects owned by the nodes")

        b2 = h.start("unix-dgram-b-2", b_config, b_state)
        a2 = h.start("unix-dgram-a-2", a_config, a_state)
        restored_a = h.status("unix-dgram-restored-a", a_state, logical_digest=False)
        restored_b = h.status("unix-dgram-restored-b", b_state, logical_digest=False)
        h.check(outbox_entry(restored_a, op_ab)["status"] == "ACKED" and
                outbox_entry(restored_b, op_ba)["status"] == "ACKED",
                "restart reconstructs acknowledged obligations without changing carrier identity")

        op_restart = operation("unix-datagram-post-restart")
        submit(h, "unix-dgram-submit-restart", a2.control, "A", "B", scope_ab,
               op_restart, "post-restart Unix datagram delivery")

        def restart_acked() -> bool:
            status = h.status("unix-dgram-wait-restart", a_state, logical_digest=False)
            return outbox_entry(status, op_restart)["status"] == "ACKED"

        h.wait("reopened listener and scheduler deliver post-restart work",
               restart_acked, 20.0)
        h.check(h.status("unix-dgram-b-post-restart", b_state,
                         logical_digest=False)["inbound_records"] == 2,
                "post-restart operation is authenticated and admitted exactly once")
        a2.shutdown()
        b2.shutdown()
        h.check(all(not path.exists() for path in (a_listen, b_listen, a_to_b, b_to_a)),
                "restart shutdown again releases every exact owned socket path")

        evidence["operations"] = {
            "a_to_b": op_ab,
            "b_to_a": op_ba,
            "post_restart": op_restart,
        }
        evidence["locators"] = {
            "a_listener": listen_a,
            "b_listener": listen_b,
            "a_route": route_ab,
            "b_route": route_ba,
        }

    h.case("two complete persistent nodes delivery stop restart and cleanup",
           persistent_two_process_lifecycle)
    return evidence


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source_root = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    binary = args.binary.resolve(strict=True)
    if output.exists() or output == source_root or source_root in output.parents:
        parser.error("output must be new and outside the source tree")

    harness = Harness(binary, output)
    started = time.monotonic()
    status = "FAIL"
    failure: str | None = None
    evidence: dict[str, Any] = {}
    try:
        evidence = run_suite(harness)
        status = "PASS"
    except BaseException as exc:
        failure = f"{type(exc).__name__}: {exc}"
        (output / "FAILURE.txt").write_text(failure + "\n")
        print(f"FAIL: {failure}", file=os.sys.stderr, flush=True)
    finally:
        harness.cleanup()
        summary: dict[str, Any] = {
            "assertions": harness.assertions,
            "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
            "cases_passed": sum(item["status"] == "PASS" for item in harness.cases),
            "cases_total": len(harness.cases),
            "commands": len(harness.commands),
            "elapsed_seconds": time.monotonic() - started,
            "feature": EXPECTED_FEATURE,
            "format": "NATRAV_UNIX_DATAGRAM_TRANSPORT_SUITE_V1",
            "hardware_verified": False,
            "independent_host_verified": False,
            "status": status,
            "evidence": evidence,
        }
        if failure is not None:
            summary["failure"] = failure
        (output / "SUMMARY.json").write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n"
        )
        (output / "CASES.json").write_text(
            json.dumps(harness.cases, indent=2, sort_keys=True) + "\n"
        )
        (output / "COMMANDS.json").write_text(
            json.dumps(harness.commands, indent=2, sort_keys=True) + "\n"
        )
        print(json.dumps({key: value for key, value in summary.items()
                          if key != "evidence"}, sort_keys=True), flush=True)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
