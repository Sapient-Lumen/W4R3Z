#!/usr/bin/env python3
"""Finite automatic publication grants over durable projection channels."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from typing import Any

from run_persistent import Harness
from run_projection_publication import topology
from run_numeric_projection import create as numeric_create, produce, consume, call as numeric_call
from run_publication_channels import channel_create, channel_status, recipient_record
from run_live_configuration import candidate, activate, wait_state
from run_automatic_projections import enable as projection_enable
from run_state_authentication import new_key, migrate, start as start_keyed


def auto_status(h: Harness, label: str, state: Path,
                name: str = "channel", expected: int = 0) -> dict[str, Any]:
    result = h.run(label, [
        "publication-channel-auto-status", "--control", str(state / "control.sock"),
        "--channel", name, "--deadline-ms", "5000",
    ], expected=expected)
    assert result is not None
    return result


def auto_enable(h: Harness, label: str, state: Path, channel: dict[str, Any],
                *, name: str = "channel", generation: int | None = None,
                maximum: int = 100, interval: int = 20,
                reason: str = "finite automatic disclosure grant",
                expected: int = 0) -> dict[str, Any]:
    if generation is None:
        generation = int(channel.get("automatic_generation", 0))
    result = h.run(label, [
        "publication-channel-auto-enable", "--control", str(state / "control.sock"),
        "--channel", name, "--instance", channel["instance"],
        "--expected-channel-revision", str(channel["revision"]),
        "--expected-schedule-revision", str(channel.get("automatic_schedule_revision", 0)),
        "--expected-grant-generation", str(generation),
        "--max-automatic-publications", str(maximum),
        "--min-interval-ms", str(interval),
        "--reason", reason, "--deadline-ms", "5000",
    ], expected=expected)
    assert result is not None
    return result


def auto_pause(h: Harness, label: str, state: Path, channel: dict[str, Any],
               *, name: str = "channel", reason: str = "pause automatic disclosure",
               expected: int = 0) -> dict[str, Any]:
    result = h.run(label, [
        "publication-channel-auto-pause", "--control", str(state / "control.sock"),
        "--channel", name, "--instance", channel["instance"],
        "--expected-channel-revision", str(channel["revision"]),
        "--expected-schedule-revision", str(channel.get("automatic_schedule_revision", 0)),
        "--expected-grant-generation", str(channel.get("automatic_generation", 0)),
        "--reason", reason, "--deadline-ms", "5000",
    ], expected=expected)
    assert result is not None
    return result


def wait_publications(h: Harness, state: Path, count: int,
                      name: str = "channel") -> dict[str, Any]:
    box: dict[str, Any] = {}
    def ready() -> bool:
        result = channel_status(h, f"await-channel-{name}-{count}", state, name)
        box.clear(); box.update(result["channel"])
        return int(box["publication_count"]) == count
    h.wait(f"automatic channel {name} publication count {count}", ready, timeout=15)
    return box


def cases(h: Harness, selected: set[str] | None = None) -> None:
    def case(name: str, function: Any) -> None:
        if selected is None or name in selected:
            h.case(name, function)

    def strict_generations_and_history() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(h, "auto-channel-strict")
        assert cd is not None
        values: dict[str, bytes] = {}
        produce(h, "auto-channel-strict-source", a, values, ticks=12)
        numeric_create(h, "auto-channel-strict-projection", b, limit=8)
        projection, _ = consume(h, "auto-channel-strict-consume", b, values)
        created = channel_create(h, "auto-channel-strict-create", b, projection, maximum=4)
        wrong = auto_enable(h, "auto-channel-strict-wrong-revision", b,
                            created["channel"], generation=1, expected=3)
        h.check(wrong["code"] == "PUBLICATION_CHANNEL_SCHEDULE_CONFLICT",
                "automatic grants require exact observed schedule generation")
        auto_enable(h, "auto-channel-strict-first", b, created["channel"],
                    maximum=1, interval=10)
        head = wait_publications(h, b, 1)
        wait_state(h, b, head["head_operation"], "ACKED", "strict-first-acked")
        h.wait("first grant exhausted",
               lambda: auto_status(h, "await-strict-exhausted", b)["schedule"]["grant"]["state"] == "EXHAUSTED",
               timeout=10)
        for generation in range(1, 32):
            current = channel_status(h, f"strict-channel-{generation}", b)["channel"]
            auto_enable(h, f"strict-enable-{generation + 1}", b, current,
                        maximum=1, interval=60_000)
            current = channel_status(h, f"strict-enabled-{generation + 1}", b)["channel"]
            paused = auto_pause(h, f"strict-pause-{generation + 1}", b, current)
            h.check(paused["schedule"]["grant"]["state"] == "PAUSED",
                    "explicit pause closes one finite grant")
        full = channel_status(h, "strict-full-history", b)["channel"]
        h.check(full["automatic_generation"] == 32 and
                len(full["automatic_grants"]) == 32,
                "32 attributable automatic publication grants are retained")
        denied = auto_enable(h, "strict-grant-history-full", b, full,
                             maximum=1, expected=3)
        h.check(denied["code"] == "PUBLICATION_CHANNEL_SCHEDULE_HISTORY_LIMIT",
                "grant history exhaustion never overwrites earlier provenance")
        stopped = auto_pause(h, "strict-pause-still-safe", b, full)
        h.check(stopped["disposition"] == "ALREADY_STOPPED",
                "history exhaustion does not prevent a safe stop")
        h.run("strict-channel-compact", ["compact", "--control", str(bd.control)])
        bd.shutdown(); bd = h.start("strict-channel-restart", bc, b)
        replay = channel_status(h, "strict-channel-replayed", b)["channel"]
        h.check(replay["automatic_grants"] == full["automatic_grants"] and
                replay["automatic_schedule_revision"] == full["automatic_schedule_revision"],
                "complete finite-grant history reconstructs through compaction and restart")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("strict_schedule_generations_bounds_and_history", strict_generations_and_history)

    def changed_results_and_budget() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(h, "auto-channel-basic")
        assert cd is not None
        values: dict[str, bytes] = {}
        first = produce(h, "auto-channel-first", a, values, ticks=100)
        numeric_create(h, "auto-channel-projection", b, limit=8)
        projection, rows = consume(h, "auto-channel-consume-one", b, values)
        created = channel_create(h, "auto-channel-create", b, projection, maximum=4)
        enabled = auto_enable(h, "auto-channel-enable", b, created["channel"], maximum=2)
        h.check(enabled["disposition"] == "ENABLED", "explicit finite automatic grant")
        first_channel = wait_publications(h, b, 1)
        first_operation = first_channel["head_operation"]
        wait_state(h, b, first_operation, "ACKED", "auto-channel-first-acked")
        _, first_payload = recipient_record(h, "auto-channel-first-recipient", c, first_operation)
        h.check(first_payload["sequence"] == 1 and first_payload["corrects"] is None,
                "first automatic publication is an original")
        stable = (b / "state.journal").read_bytes()
        time.sleep(0.7)
        h.check((b / "state.journal").read_bytes() == stable,
                "caught-up automatic channel spends no budget and appends nothing")
        schedule = auto_status(h, "auto-channel-one-grant", b)["schedule"]
        h.check(schedule["grant"]["publications_completed"] == 1 and
                schedule["grant"]["state"] == "ENABLED",
                "one changed result consumes exactly one allowance")

        produce(h, "auto-channel-correction", a, values, ticks=125, corrects=first)
        projection, rows = consume(h, "auto-channel-consume-two", b, values, rows=rows)
        second_channel = wait_publications(h, b, 2)
        second_operation = second_channel["head_operation"]
        wait_state(h, b, second_operation, "ACKED", "auto-channel-second-acked")
        _, second_payload = recipient_record(h, "auto-channel-second-recipient", c, second_operation)
        h.check(second_payload["sequence"] == 2 and
                second_payload["corrects"] == first_operation,
                "changed result becomes one acknowledged correction")
        exhausted = auto_status(h, "auto-channel-exhausted", b)["schedule"]
        h.check(exhausted["grant"]["state"] == "EXHAUSTED" and
                exhausted["grant"]["publications_completed"] == 2,
                "finite publication allowance becomes durable exhaustion")
        produce(h, "auto-channel-after-budget", a, values, ticks=130,
                corrects=rows[-1]["operation_id"])
        consume(h, "auto-channel-consume-three", b, values, rows=rows)
        time.sleep(0.4)
        h.check(channel_status(h, "auto-channel-still-two", b)["channel"]["publication_count"] == 2,
                "exhausted grant cannot silently renew")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("changed_results_only_and_finite_budget", changed_results_and_budget)

    def pending_fairness_and_pause() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "auto-channel-fair", start_recipient=False)
        values: dict[str, bytes] = {}
        produce(h, "auto-channel-fair-source", a, values, ticks=50)
        numeric_create(h, "auto-channel-fair-projection", b, limit=8)
        projection, _ = consume(h, "auto-channel-fair-consume", b, values)
        one = channel_create(h, "auto-channel-fair-create-one", b, projection,
                             name="one", maximum=3)
        two = channel_create(h, "auto-channel-fair-create-two", b, projection,
                             name="two", maximum=3)
        auto_enable(h, "auto-channel-fair-enable-one", b, one["channel"], name="one",
                    maximum=3)
        auto_enable(h, "auto-channel-fair-enable-two", b, two["channel"], name="two",
                    maximum=3)
        first = wait_publications(h, b, 1, "one")
        second = wait_publications(h, b, 1, "two")
        h.check(first["latest_outbound_status"] == "PENDING" and
                second["latest_outbound_status"] == "PENDING",
                "one pending channel does not block another channel turn")
        paused = auto_pause(h, "auto-channel-fair-pause-one", b, first, name="one")
        h.check(paused["disposition"] == "PAUSED", "explicit pause stops future work")
        stable = auto_status(h, "auto-channel-fair-paused", b, "one")["schedule"]
        h.check(stable["grant"]["state"] == "PAUSED", "pause is durable and inspectable")
        cd = h.start("auto-channel-fair-c", cc, c)
        wait_state(h, b, first["head_operation"], "ACKED", "fair-one-acked")
        wait_state(h, b, second["head_operation"], "ACKED", "fair-two-acked")
        bd.shutdown(); bd = h.start("auto-channel-fair-restart", bc, b)
        h.check(auto_status(h, "auto-channel-fair-replay", b, "one")["schedule"] == stable,
                "paused grant reconstructs across restart")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("pending_channel_fairness_pause_and_restart", pending_fairness_and_pause)

    def recipient_rejection_blocks() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "auto-channel-reject", allow_output=False)
        assert cd is not None
        values: dict[str, bytes] = {}
        produce(h, "auto-channel-reject-source", a, values, ticks=77)
        numeric_create(h, "auto-channel-reject-projection", b, limit=8)
        projection, _ = consume(h, "auto-channel-reject-consume", b, values)
        created = channel_create(h, "auto-channel-reject-create", b, projection)
        auto_enable(h, "auto-channel-reject-enable", b, created["channel"], maximum=5)
        channel = wait_publications(h, b, 1)
        wait_state(h, b, channel["head_operation"], "REJECTED", "auto-channel-terminal-rejection")
        h.wait("automatic grant blocks on rejected predecessor",
               lambda: auto_status(h, "await-auto-rejected", b)["schedule"]["grant"]["state"] == "BLOCKED",
               timeout=12)
        blocked = auto_status(h, "auto-channel-rejected-account", b)["schedule"]
        h.check(blocked["grant"]["error"] == "PUBLICATION_CHANNEL_PREDECESSOR_REJECTED" and
                blocked["grant"]["publications_completed"] == 1,
                "recipient rejection blocks without spending another allowance")
        journal = (b / "state.journal").read_bytes(); time.sleep(0.6)
        h.check((b / "state.journal").read_bytes() == journal,
                "blocked channel does not retry or journal-loop")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("recipient_rejection_becomes_inspectable_block", recipient_rejection_blocks)

    def lifecycle_and_hard_kills() -> None:
        # Quiesce suspends both internal processing and automatic disclosure.
        a, b, c, ac, bc, cc, ad, bd, cd = topology(h, "auto-channel-life")
        assert cd is not None
        numeric_create(h, "auto-channel-life-projection", b, limit=8)
        projection = numeric_call(h, "auto-channel-life-empty", b, "status")
        created = channel_create(h, "auto-channel-life-create", b, projection)
        projection_enable(h, "auto-channel-life-process-enable", b, "numeric",
                          max_pages=10, min_interval_ms=10)
        auto_enable(h, "auto-channel-life-publish-enable", b, created["channel"], maximum=3)
        initial = wait_publications(h, b, 1)
        wait_state(h, b, initial["head_operation"], "ACKED", "life-initial-publication-acked")
        h.run("auto-channel-life-quiesce", ["quiesce", "--control", str(bd.control),
              "--reason", "suspend automatic publication"])
        values: dict[str, bytes] = {}
        produce(h, "auto-channel-life-source", a, values, ticks=88)
        time.sleep(0.4)
        h.check(channel_status(h, "auto-channel-life-one", b)["channel"]["publication_count"] == 1,
                "quiesce suspends new automatic disclosure")
        h.run("auto-channel-life-resume", ["resume", "--control", str(bd.control),
              "--reason", "resume bounded workers"])
        channel = wait_publications(h, b, 2)
        wait_state(h, b, channel["head_operation"], "ACKED", "life-publication-acked")
        cd.shutdown(); ad.shutdown(); bd.shutdown()

        for phase, expected_count in (("BEFORE", 0), ("AFTER", 1)):
            a, b, c, ac, bc, cc, ad, bd, cd = topology(
                h, "auto-channel-kill-" + phase.lower(), start_recipient=False)
            values = {}
            produce(h, "auto-channel-kill-source-" + phase.lower(), a, values, ticks=91)
            numeric_create(h, "auto-channel-kill-projection-" + phase.lower(), b, limit=8)
            projection, _ = consume(h, "auto-channel-kill-consume-" + phase.lower(), b, values)
            created = channel_create(h, "auto-channel-kill-create-" + phase.lower(), b, projection)
            bd.shutdown()
            bd = h.start("auto-channel-kill-daemon-" + phase.lower(), bc, b,
                         {f"NATRAV_OVERLAY_TEST_AUTOMATIC_PUBLICATION_{phase}_COMMIT_MS": "20000"})
            client = subprocess.Popen([
                str(h.binary), "publication-channel-auto-enable", "--control", str(b / "control.sock"),
                "--channel", "channel", "--instance", created["channel"]["instance"],
                "--expected-channel-revision", "1", "--expected-schedule-revision", "0",
                "--expected-grant-generation", "0", "--max-automatic-publications", "2",
                "--min-interval-ms", "10", "--reason", "kill boundary grant",
                "--deadline-ms", "5000"], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                h.wait("automatic publication kill marker " + phase,
                       lambda: f"AUTOMATIC_PUBLICATION_{phase}_COMMIT_MS" in bd.stderr_path.read_text(),
                       timeout=8)
                bd.kill(); client.communicate(timeout=5)
            finally:
                if client.poll() is None:
                    client.kill(); client.communicate()
            offline = h.run("auto-channel-kill-inspect-" + phase.lower(),
                            ["inspect", "--state", str(b), "--node", "B"])
            entries = offline.get("publication_channels", [])
            h.check(len(entries) == 1 and entries[0]["publication_count"] == expected_count,
                    "channel and outbox share the automatic publication commit boundary")
            bd = h.start("auto-channel-kill-restart-" + phase.lower(), bc, b)
            final = wait_publications(h, b, 1)
            h.check(final["publication_count"] == 1,
                    "restart completes at most one publication after crash boundary")
            ad.shutdown(); bd.shutdown()
    case("quiesce_resume_and_atomic_hard_kill_boundaries", lifecycle_and_hard_kills)

    def authenticated_restore_and_relocation() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(h, "auto-channel-maint")
        assert cd is not None
        values: dict[str, bytes] = {}
        first = produce(h, "auto-channel-maint-source", a, values, ticks=210)
        numeric_create(h, "auto-channel-maint-projection", b, limit=8)
        projection, rows = consume(h, "auto-channel-maint-consume", b, values)
        created = channel_create(h, "auto-channel-maint-create", b, projection, maximum=4)
        auto_enable(h, "auto-channel-maint-enable", b, created["channel"], maximum=4)
        first_channel = wait_publications(h, b, 1)
        first_operation = first_channel["head_operation"]
        wait_state(h, b, first_operation, "ACKED", "auto-channel-maint-first-acked")
        h.run("auto-channel-maint-quiesce", ["quiesce", "--control", str(bd.control),
              "--reason", "stable authenticated maintenance boundary"])
        bd.shutdown()

        keys = h.runtime / "auto-channel-maint-keys"
        keys.mkdir(mode=0o700)
        state_key = new_key(h, keys, "auto-channel-state-g1")
        migrate(h, "auto-channel-maint-migrate", b, state_key, "B")
        bd = start_keyed(h, "auto-channel-maint-keyed", bc, b, state_key)
        h.run("auto-channel-maint-resume", ["resume", "--control", str(bd.control),
              "--reason", "perform authenticated compaction"])
        h.run("auto-channel-maint-compact", ["compact", "--control", str(bd.control)])
        h.run("auto-channel-maint-quiesce-two", ["quiesce", "--control", str(bd.control),
              "--reason", "export stable encrypted state"])
        before_schedule = auto_status(h, "auto-channel-maint-schedule-before", b)["schedule"]
        bd.shutdown()
        audit = h.run("auto-channel-maint-audit", ["state-auth-audit", "--state", str(b),
                      "--node", "B", "--state-auth-key", str(state_key)])
        h.check(audit["status"] == "COMPLETE", "automatic publication records authenticate")

        identity = h.identity("B")
        backup_key = keys / "backup.key"
        archive = keys / "automatic-channel.nob"
        h.run("auto-channel-maint-backup-key", ["backup-key-init", "--output", str(backup_key),
              "--generation", "auto-channel-backup-g1"])
        h.run("auto-channel-maint-export", ["backup-export", "--state", str(b), "--node", "B",
              "--generation", "b-g1", "--output", str(archive),
              "--state-auth-key", str(state_key), "--encrypt-key", str(backup_key),
              "--sign-key", str(identity.private_key), "--sign-cert", str(identity.certificate)])
        restored = h.runtime / "auto-channel-maint-restored"
        h.run("auto-channel-maint-restore", ["backup-restore", "--input", str(archive),
              "--destination", str(restored), "--node", "B", "--generation", "b-g1",
              "--state-auth-key", str(state_key), "--decrypt-key", str(backup_key),
              "--trusted-cert", str(identity.certificate), "--require-signature", "yes",
              "--require-encryption", "yes"])
        restored_state = h.run("auto-channel-maint-restored-inspect", ["inspect", "--state",
              str(restored), "--node", "B", "--state-auth-key", str(state_key)])
        h.check(restored_state["storage"]["logical_state_digest"] == audit["logical_state_digest"],
                "encrypted restore preserves automatic channel state exactly")
        moved = candidate(h, bc, "auto-channel-maint-relocated", "auto-channel-relocated-g1",
                          lambda text: text.replace(f"state={b}", f"state={restored}"))
        h.run("auto-channel-maint-relocate", ["state-relocate", "--state", str(restored),
              "--node", "B", "--candidate", str(moved),
              "--reason", "relocate automatic publication channel", "--state-auth-key", str(state_key)])
        bd = start_keyed(h, "auto-channel-maint-relocated-start", moved, restored, state_key)
        restored_schedule = auto_status(h, "auto-channel-maint-schedule-restored", restored)["schedule"]
        h.check(restored_schedule["grant"]["publications_completed"] ==
                before_schedule["grant"]["publications_completed"] and
                restored_schedule["grant"]["state"] == "ENABLED",
                "finite grant reconstructs through compaction, restore, and relocation")
        h.run("auto-channel-maint-restored-resume", ["resume", "--control", str(bd.control),
              "--reason", "resume restored finite grant"])
        time.sleep(0.5)
        caught_up = channel_status(h, "auto-channel-maint-restored-caught-up", restored)["channel"]
        h.check(caught_up["publication_count"] == 1 and
                caught_up["automatic_observation"] == "CAUGHT_UP",
                "restore/configuration revision alone does not republish an unchanged canonical result")
        produce(h, "auto-channel-maint-correction", a, values, ticks=215, corrects=first)
        projection, rows = consume(h, "auto-channel-maint-consume-two", restored, values, rows=rows)
        second_channel = wait_publications(h, restored, 2)
        wait_state(h, restored, second_channel["head_operation"], "ACKED",
                   "auto-channel-maint-second-acked")
        h.check(second_channel["publications"][-1]["corrects"] == first_operation and
                second_channel["publications"][-1]["automatic"],
                "restored grant continues the acknowledged correction chain")
        bd.shutdown()
        h.check(h.run("auto-channel-maint-final-audit", ["state-auth-audit", "--state", str(restored),
                  "--node", "B", "--state-auth-key", str(state_key)])["status"] == "COMPLETE",
                "continued automatic publication remains authenticated")
        cd.shutdown(); ad.shutdown()
    case("authenticated_compaction_encrypted_restore_relocation_and_continuation",
         authenticated_restore_and_relocation)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--case", action="append")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not exist")
    harness = Harness(args.binary, args.output)
    started = time.time(); passed = False
    try:
        cases(harness, set(args.case) if args.case else None)
        passed = True
    except BaseException as error:
        (harness.output / "FAILURE.txt").write_text(
            f"{type(error).__name__}: {error}\n")
        print(f"FAIL: {type(error).__name__}: {error}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_AUTOMATIC_PUBLICATION_CHANNEL_TESTS_V1",
            "status": "PASS" if passed else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_total": len(harness.cases),
            "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (("SUMMARY", summary), ("CASES", harness.cases),
                            ("COMMANDS", harness.commands)):
            (harness.output / f"{name}.json").write_text(
                json.dumps(value, sort_keys=True, indent=2) + "\n")
        print(json.dumps(summary), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
