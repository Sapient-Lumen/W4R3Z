#!/usr/bin/env python3
"""Ordered, bounded-memory evidence pagination through the real native daemon.

Large fixtures are independently encoded legacy journal records, not claims of
network admission. Other cases use actual mutually authenticated C++ senders.
"""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import time
from typing import Any

from run_persistent import Harness, Daemon, free_port, operation, receive_exact
from run_scoped_reads import scoped_config, query, trio, send
from run_evidence_queries import wire_query, config as sender_config, query as legacy_query
from run_integration import encode_record, record_digest
from run_live_configuration import candidate, activate, wait_state
from run_peer_sessions import revise, submit

FIELDS=('sequence','operation_id','issuer','recipient','scope','record_digest','payload_size','corrects','superseded_by','authorization')

def fixture(h: Harness, name: str, originals: int, corrections: int = 0, hidden: int = 0,
            two_domains: bool = True) -> tuple[Path, list[dict[str, Any]]]:
    state=h.runtime/name;state.mkdir(mode=0o700)
    (state/'node.meta').write_text('NATRAV_OVERLAY_NODE_STATE_V2\nnode=B\nstorage_schema=2\n')
    (state/'node.meta').chmod(0o600);(state/'state.lock').touch(mode=0o600)
    records: list[dict[str, Any]]=[]
    def add(issuer: str, label: str, parent: dict[str,Any]|None=None) -> None:
        op=operation(name+'-'+label);payload=b'x';scope='query/series'
        body=encode_record(op,issuer,'B',scope,payload,parent['operation_id'] if parent else None)
        records.append({'operation_id':op,'issuer':issuer,'recipient':'B','scope':scope,
                        'record_digest':record_digest(body).hex(),'payload_size':1,
                        'corrects':parent['operation_id'] if parent else None,
                        'superseded_by':None,'authorization':None,'wire':body})
        if parent:parent['superseded_by']=op
    for i in range(originals):add('C' if two_domains and i%2 else 'A','original-'+str(i))
    visible=list(records)
    for i in range(corrections):
        # Long chains exercise removal and selection inside non-power-of-two trees.
        parent=visible[i] if i<len(visible) else records[-1]
        if parent['superseded_by'] is not None:parent=records[-1]
        add(parent['issuer'],'correction-'+str(i),parent)
    for i in range(hidden):add('H','hidden-'+str(i))
    with (state/'state.journal').open('wb') as f:
        for entry in records:
            body=b'\x01'+entry.pop('wire')
            f.write(b'NOJ1'+struct.pack('!I',len(body))+body+
                    hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest())
    (state/'state.journal').chmod(0o600)
    return state,records


def receiver(h: Harness,name: str,state: Path,*,two_domains: bool=True,
             env: dict[str,str]|None=None) -> tuple[Path,Daemon,int]:
    rules=[(os.geteuid(),'A','query/series','PAYLOAD')]
    if two_domains:rules.append((os.geteuid(),'C','query/series','METADATA'))
    port=free_port()
    cfg=scoped_config(h,name,'B',state,port,rules,inbound=['A','C'])
    # A declared large replay/root workload, not a relaxation of other suites'
    # normal control deadlines. Real cold/warm timings are retained below.
    cfg.write_text(cfg.read_text().replace('deadline_ms=2000','deadline_ms=20000'))
    daemon=Daemon(h,name,cfg,state,environment=env,readiness_timeout=30)
    h.daemons.append(daemon);daemon.start()
    return cfg,daemon,port


def raw_page(state: Path, **kw: Any) -> tuple[dict[str,Any],float,int]:
    body=wire_query(**kw)
    began=time.perf_counter()
    with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as sock:
        sock.settimeout(30);sock.connect(str(state/'control.sock'))
        sock.sendall(struct.pack('!I',len(body))+body);sock.shutdown(socket.SHUT_WR)
        n=struct.unpack('!I',receive_exact(sock,4))[0];response=receive_exact(sock,n)
    if response[:5]!=b'NOR1\x00':raise AssertionError('query failed: '+repr(response))
    return json.loads(response[5:]),time.perf_counter()-began,len(response)-5


def memory(daemon: Daemon) -> dict[str,int]:
    assert daemon.process
    result={}
    for line in Path(f'/proc/{daemon.process.pid}/status').read_text().splitlines():
        if line.split(':')[0] in ('VmRSS','VmHWM','Threads'):
            result[line.split(':')[0]]=int(line.split()[1])
    return result


def enumerate_exact(h: Harness,state: Path,expected: list[dict[str,Any]],history: bool) -> dict[str,Any]:
    rows=[e for e in expected if e['issuer'] in ('A','C') and (history or e['superseded_by'] is None)]
    cursor='';offset=0;first=None;root=None;latencies=[];hashed=0;visited=0;pages=0
    while True:
        page,elapsed,encoded_size=raw_page(state,history=history,limit=128,cursor=cursor)
        latencies.append(elapsed);pages+=1
        h.check(encoded_size<=60000,'actual bounded JSON bytes')
        h.check(page['selected_records']==len(rows),'exact large selection count')
        h.check(page['returned_records']==len(page['records']),'exact page record count')
        h.check(page['query_work']['maximum_batch_records']==128,'bounded metadata batch')
        h.check(page['query_work']['maximum_root_cache_entries']==32,'bounded root-cache contract')
        work=page['query_work'];hashed+=work['root_records_hashed'];visited+=work['index_records_visited']
        if first is None:
            first=page
            def txt(s: str) -> bytes:
                b=s.encode();return struct.pack('!H',len(b))+b
            seed=b'NATRAV_OVERLAY_EVIDENCE_SELECTION_V2'+txt('B')+bytes([history])+txt('')+txt('')+b'\0'+bytes.fromhex(page['read_policy_digest'])+b'\0'
            root=hashlib.sha256(seed).digest()
        else:
            h.check(work['root_cache_hit'] and work['root_records_hashed']==0,'settled continuation never rehashes population')
            h.check(work['index_records_visited']<=129,'seek visits only page plus one lookahead')
            h.check(page['selection_digest']==first['selection_digest'],'settled selection root stays exact')
        for row in page['records']:
            reference={'sequence':offset+1,**rows[offset]}
            h.check({f:row[f] for f in FIELDS}=={f:reference[f] for f in FIELDS},'independent complete ordered metadata reference')
            leaf=json.dumps({f:reference[f] for f in FIELDS},separators=(',',':')).encode()
            assert root is not None
            root=hashlib.sha256(root+struct.pack('!I',len(leaf))+leaf).digest();offset+=1
        cursor=page['next_cursor']
        if cursor is None:break
    assert first and root is not None
    h.check(offset==len(rows),'full enumeration has no gaps or duplicates')
    h.check(root.hex()==first['selection_digest'],'independent root matches all original/corrected metadata')
    return {'records':offset,'pages':pages,'root_records_hashed_total':hashed,
            'index_records_visited_total':visited,'first_page_seconds':latencies[0],
            'warm_page_seconds_median':sorted(latencies[1:])[len(latencies[1:])//2] if len(latencies)>1 else None,
            'warm_page_seconds_max':max(latencies[1:]) if len(latencies)>1 else None,
            'selection_digest':root.hex()}


def cases(h: Harness,selected: set[str]|None) -> None:
    def case(name: str,fn: Any) -> None:
        if selected is None or name in selected:h.case(name,fn)

    def large() -> None:
        state,records=fixture(h,'large',65560,20,257)
        cfg,daemon,_=receiver(h,'large',state)
        before=memory(daemon)
        hist=enumerate_exact(h,state,records,True)
        curr=enumerate_exact(h,state,records,False)
        h.check(hist['records']>65536 and curr['records']>65536,'both views exceed retired visible ceiling')
        h.check(hist['root_records_hashed_total']==hist['records'],'history root hashes each selected row only once')
        h.check(curr['root_records_hashed_total']==curr['records'],'current root hashes heads only once')
        after=memory(daemon)
        # Compact the actual large state, keep a cursor alive, then replay its
        # checkpoint. This is a real product operation, not a cache fixture.
        first,_,_=raw_page(state,history=True,limit=1)
        h.run('large-compact',['compact','--control',str(daemon.control),'--deadline-ms','30000'],timeout=40)
        continuation,_,_=raw_page(state,history=True,limit=1,cursor=first['next_cursor'])
        h.check(continuation['query_work']['root_cache_hit'],'same-process compaction preserves valid derivative root')
        h.check(continuation['records'][0]['operation_id']==records[1]['operation_id'],'cursor remains correct after compaction')
        daemon.shutdown()
        daemon=Daemon(h,'large-replayed',cfg,state,readiness_timeout=30);h.daemons.append(daemon);daemon.start()
        replay,elapsed,_=raw_page(state,history=False,limit=1)
        h.check(replay['selection_digest']==curr['selection_digest'],'checkpoint rebuild produces identical current root')
        h.check(not replay['query_work']['root_cache_hit'],'cache is process-local and rebuilt after replay')
        # Explicit V9 compatibility remains node-wide, with its original digest
        # and admission sequence semantics, but without the old scan ceiling.
        v9=candidate(h,cfg,'large-legacy-view','large-v9-g2',lambda s:'\n'.join(
            line.replace('CONFIG_V10','CONFIG_V9') for line in s.splitlines() if not line.startswith('evidence_read='))+'\n')
        activate(h,'large-explicit-v9',state,v9)
        v9page,_,_=raw_page(state,history=True,limit=1)
        h.check(v9page['format']=='NATRAV_OVERLAY_EVIDENCE_QUERY_V1' and v9page['selected_records']==len(records),
                'explicit node-wide V9 works above old ceiling, including deliberately granted hidden population')
        constrained=candidate(h,v9,'large-small-deadline','large-deadline-g3',lambda s:s.replace('deadline_ms=20000','deadline_ms=50'))
        activate(h,'large-configure-compute-deadline',state,constrained)
        timed=legacy_query(h,'large-cold-deadline',state,3,view='history',scope='query/series',limit=1)
        h.check(timed['code']=='EVIDENCE_QUERY_DEADLINE' and 'records' not in timed,
                'cold computation reserves time for a typed bounded failure, not partial output')
        timed_again=legacy_query(h,'large-cold-deadline-again',state,3,view='history',scope='query/series',limit=1)
        h.check(timed_again['code']=='EVIDENCE_QUERY_DEADLINE',
                'a timed-out partial root is not published as a successful cached selection')
        metrics={'fixture_kind':'INDEPENDENT_LEGACY_JOURNAL_NOT_NETWORK_LOAD','fixture_records':len(records),
                 'history':hist,'current':curr,'memory_before_queries':before,'memory_after_queries':after,
                 'replayed_current_cold_seconds':elapsed,'root_cache_fixed_entry_array_bytes':2816,
                 'memory_units':'Linux VmRSS/VmHWM KiB; Threads count; not allocator attribution'}
        (h.output/'LARGE-PAGINATION.json').write_text(json.dumps(metrics,indent=2)+'\n')
        daemon.kill()
    case('large_history_current_enumeration_and_checkpoint',large)

    def eviction() -> None:
        state,records=fixture(h,'eviction',1025,60,19)
        _,daemon,_=receiver(h,'eviction',state)
        page=query(h,'cache-prime',state,view='history',limit=1)
        root=page['selection_digest'];token=page['next_cursor']
        h.check(not page['query_work']['root_cache_hit'],'first query builds root')
        first=query(h,'cache-warm',state,view='history',limit=1)
        h.check(first['query_work']['root_cache_hit'] and first['query_work']['root_records_hashed']==0,'same selection reuses root')
        before=memory(daemon)
        for i in range(40):query(h,f'cache-evict-{i}',state,view='history',operation=records[i]['operation_id'])
        after=query(h,'cache-rebuild-token',state,view='history',limit=1,cursor=token)
        h.check(not after['query_work']['root_cache_hit'] and after['query_work']['root_records_hashed']==1085,'bounded LRU eviction causes exact rebuild')
        h.check(after['selection_digest']==root and after['records'][0]['operation_id']==records[1]['operation_id'],'evicted cache does not invalidate authentic content cursor')
        warm=query(h,'cache-rebuilt-warm',state,view='history',limit=1,cursor=after['next_cursor'])
        h.check(warm['query_work']['root_records_hashed']==0 and warm['query_work']['index_records_visited']<=2,'rebuilt cache seeks next ordinal directly')
        for i in range(40,296):
            result,_,_=raw_page(state,history=True,op=records[i]['operation_id'])
            h.check(result['selected_records']==1,'many distinct selections remain bounded and correct')
        (h.output/'CACHE-EVICTION.json').write_text(json.dumps({'distinct_exact_selections':296,'capacity':32,
            'before':before,'after':memory(daemon),'cursor_survives_eviction':True},indent=2)+'\n')
        daemon.shutdown()
    case('bounded_root_cache_eviction_rebuild_and_cursor',eviction)

    def invalidation() -> None:
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'invalidation')
        one=send(h,'invalidate-one',a,'A');send(h,'invalidate-two',a,'A')
        initial=query(h,'invalidation-prime',b,view='history',limit=1)
        query(h,'invalidation-warm',b,view='history',limit=1)
        send(h,'invalidate-hidden',c,'C')
        hidden=query(h,'invalidation-hidden-hit',b,view='history',limit=1,cursor=initial['next_cursor'])
        h.check(hidden['query_work']['root_cache_hit'] and hidden['selection_digest']==initial['selection_digest'],'hidden writes do not invalidate visible cached root')
        # Changes to metadata-only domains must not invalidate a payload root.
        payload=query(h,'payload-prime',b,view='history',payload='yes',limit=1)
        send(h,'invalidate-metadata',a,'A','query/other')
        payload2=query(h,'payload-not-metadata',b,view='history',payload='yes',limit=1,cursor=payload['next_cursor'])
        h.check(payload2['query_work']['root_cache_hit'],'metadata-only admissions do not affect payload root version')
        # Re-prime a history cursor after that visible metadata admission.
        hist=query(h,'before-correction-history',b,view='history',limit=1)
        current=query(h,'before-correction-current',b,limit=1)
        correction=operation('invalidation-correction')
        revise(h,'invalidate-correct',ad.control,'A','B','query/series',correction,one,'new')
        wait_state(h,a,correction,'ACKED','invalidate-correction-ack')
        h.check(query(h,'cached-correction-history-stale',b,3,view='history',limit=1,cursor=hist['next_cursor'])['code']=='EVIDENCE_CURSOR_STALE',
                'correction invalidates cached history metadata root')
        h.check(query(h,'cached-correction-current-stale',b,3,limit=1,cursor=current['next_cursor'])['code']=='EVIDENCE_CURSOR_STALE',
                'correction invalidates cached current membership root')
        fresh=query(h,'current-correction-rebuilt',b)
        h.check(one not in [r['operation_id'] for r in fresh['records']] and correction in [r['operation_id'] for r in fresh['records']],
                'current rank/select removes only corrected predecessor')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('authorized_cache_invalidation_and_hidden_isolation',invalidation)

    def cooperation() -> None:
        state,records=fixture(h,'cooperation',1025,two_domains=False)
        cfg,bd,port=receiver(h,'cooperation',state,two_domains=False,
            env={'NATRAV_OVERLAY_TEST_QUERY_AFTER_BATCH_MS':'1000'})
        a=h.runtime/'cooperative-a';c=h.runtime/'cooperative-c'
        ac=sender_config(h,'cooperative-a','A',a,free_port(),peers=[('B',port)])
        cc=sender_config(h,'cooperative-c','C',c,free_port(),peers=[('B',port)])
        ad=h.start('cooperative-a',ac,a);cd=h.start('cooperative-c',cc,c)
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            future=pool.submit(query,h,'changed-during-cold-root',state,3,view='history',limit=1)
            h.wait('cold query releases state mutex',lambda:'EVIDENCE_QUERY_TEST_BATCH_UNLOCKED' in bd.stderr_path.read_text())
            new=send(h,'cooperative-visible-write',a,'A')
            result=future.result()
        h.check(result['code']=='EVIDENCE_QUERY_CHANGED' and 'records' not in result,'concurrent visible write yields explicit no-partial-result invalidation')
        recovered=query(h,'cooperative-restart-query',state,view='history',limit=1)
        h.check(recovered['selected_records']==1026,'fresh query includes write committed while old root was unlocked')
        marker_count=bd.stderr_path.read_text().count('EVIDENCE_QUERY_TEST_BATCH_UNLOCKED')
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            future=pool.submit(query,h,'hidden-during-cold-root',state,limit=1)
            h.wait('new cold root is unlocked',lambda:bd.stderr_path.read_text().count('EVIDENCE_QUERY_TEST_BATCH_UNLOCKED')>marker_count)
            send(h,'cooperative-hidden-write',c,'C')
            stable=future.result()
        h.check(stable['selected_records']==1026 and stable['query_work']['root_records_hashed']==1026,'hidden writer does not abort or enter cold root')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('cooperative_cold_root_visible_hidden_concurrent_writers',cooperation)

    def chains() -> None:
        state,records=fixture(h,'chains',31,4067,200,two_domains=False)
        cfg,daemon,_=receiver(h,'chains',state,two_domains=False)
        result=enumerate_exact(h,state,records,False)
        h.check(result['records']==31,'long correction chains retain plural independent current heads')
        current=query(h,'chains-current-warm',state,limit=1)
        h.check(current['query_work']['root_records_hashed']==0 and current['query_work']['index_records_visited']<=2,'small current page does not walk superseded history')
        h.run('chains-compact',['compact','--control',str(daemon.control),'--deadline-ms','10000'])
        daemon.shutdown();daemon=h.start('chains-checkpoint-replay',cfg,state)
        h.check(query(h,'chains-reconstructed',state)['selection_digest']==result['selection_digest'],'current-head Fenwick tree reconstructs after checkpoint')
        daemon.shutdown()
    case('current_rank_select_over_long_correction_history',chains)


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--case',action='append');args=parser.parse_args()
    if args.output.exists():parser.error('output must not exist')
    h=Harness(args.binary,args.output);begin=time.time();success=False
    try:cases(h,set(args.case) if args.case else None);success=True
    except BaseException as exc:
        (h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n')
        print(f'FAIL: {type(exc).__name__}: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup()
        summary={'format':'NATRAV_OVERLAY_INDEXED_PAGINATION_TESTS_V1','status':'PASS' if success else 'FAIL',
                 'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),
                 'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),
                 'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-begin}
        for name,value in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:
            (h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if success else 1
if __name__=='__main__':raise SystemExit(main())
