#!/usr/bin/env python3
"""Opt-in C++ projection scheduling: durable grants, source checks and real peers."""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, struct, subprocess, time
from pathlib import Path
from run_persistent import Harness, free_port, raw_control
from run_projections import trio, config, create as create_summary, call as summary, read
from run_numeric_projection import create as create_numeric, produce, payload, verify, call as numeric
from run_consumers import wire
from run_local_administration import run_as_uid, expose_control_for_uid
from run_scoped_reads import UID, SECOND_UID
from run_live_configuration import candidate, activate
from run_state_authentication import new_key, migrate, start as start_keyed


def schedule(h,label,b,command='schedule-status',name='summary',expected=0,uid=None,**kw):
    args=['projection-'+command,'--control',str(b/'control.sock'),'--consumer',name,'--deadline-ms','4000']
    for k,v in kw.items():args+=['--'+k.replace('_','-'),str(v)]
    r=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    if expected==0:h.check(r['format']=='NATRAV_OVERLAY_PROJECTION_SCHEDULE_V1','versioned native schedule result')
    return r

def enable(h,label,b,name='summary',generation=0,**kw):
    return schedule(h,label,b,'enable',name,expected_generation=generation,reason='bounded explicit delegation',**kw)

def pause(h,label,b,name='summary',generation=1,**kw):
    return schedule(h,label,b,'pause',name,expected_generation=generation,reason='stop future automatic work',**kw)

def progress(h,label,b,name):
    return h.run(label,['projection-status','--control',str(b/'control.sock'),'--consumer',name,'--deadline-ms','4000'])

def wait_position(h,b,name,n):
    h.wait('automatic projection '+name+' to '+str(n),lambda:progress(h,'await-'+name,b,name)['consumer']['acknowledged_sequence']==n,timeout=12)

def wait_phase(h,b,name,phase):
    h.wait('schedule '+phase,lambda:schedule(h,'phase-'+phase,b,name=name)['schedule']['active']['state']==phase,timeout=12)

def cases(h,selected=None):
    def case(name,fn):
        if selected is None or name in selected:h.case(name,fn)
    def strict():
        b=h.runtime/'strict-auto';cfg=config(h,'strict-auto',b,free_port());d=h.start('strict-auto',cfg,b)
        create_summary(h,'strict-create',b)
        h.check(schedule(h,'default-off',b)['schedule'] is None,'no implicit scheduling on creation')
        h.check(enable(h,'wrong-generation',b,generation=1,expected=3)['code']=='PROJECTION_SCHEDULE_GENERATION_CONFLICT','exact owner-observed grant generation')
        for key,val in [('max_pages',0),('max_pages',10001),('min_interval_ms',9),('min_interval_ms',60001)]:
            enable(h,'invalid-'+key+str(val),b,expected=3,**{key:val})
        for pages,interval in [(0,10),(10001,10),(1,9),(1,60001)]:
            reason=b'finite native wire';tail=struct.pack('!QH',0,len(reason))+reason+struct.pack('!II',pages,interval)
            ok,error=raw_control(d.control,wire(10,'summary',tail).replace(b'NCR1',b'NCR3'));h.check(not ok,'independent wire budget validation')
        schedule(h,'status-unused-argument',b,max_pages=2,expected=3)
        s=enable(h,'first-enable',b,max_pages=1,min_interval_ms=20)['schedule']
        h.check(s['actor']=='KERNEL_AUTHENTICATED_OWNER' and s['owner_uid']==os.geteuid(),'actual explicit owner delegation')
        h.check(enable(h,'repeated-enable-no-renewal',b,generation=1,expected=3)['code']=='PROJECTION_SCHEDULE_ALREADY_ENABLED','cannot replenish an active grant')
        h.check(read(h,'manual-read-prohibited',b,expected=3)['code']=='PROJECTION_AUTOMATION_ENABLED','manual mutation cannot race automatic processing')
        before=(b/'state.journal').read_bytes();time.sleep(.65)
        for i in range(8):schedule(h,'empty-poll-'+str(i),b)
        h.check((b/'state.journal').read_bytes()==before,'caught-up automatic worker and status never append')
        pause(h,'first-pause',b)
        # Explicit new envelope; old request shapes and trailing fields rejected.
        body=wire(12,'summary').replace(b'NCR1',b'NCR3')
        ok,r=raw_control(d.control,body);h.check(ok and r['schedule']['active']['state']=='PAUSED','independent NCR3 request')
        for bad in [body+b'x',body[:-1],body.replace(b'NCR3',b'NCR1')]:
            ok,r=raw_control(d.control,bad);h.check(not ok,'strict schedule envelope')
        for generation in range(1,32):
            enable(h,'grant-'+str(generation+1),b,generation=generation,max_pages=1,min_interval_ms=10)
            pause(h,'stop-'+str(generation+1),b,generation=generation+1)
        h.check(enable(h,'grant-history-full',b,generation=32,expected=3)['code']=='PROJECTION_SCHEDULE_HISTORY_LIMIT','32 attributable grants, no silent overwrite')
        h.check(pause(h,'pause-still-safe',b,generation=32)['disposition']=='ALREADY_STOPPED','full history never blocks a safe stop')
        full=schedule(h,'full-history',b)['schedule'];h.check(len(full['grants'])==32,'all grants retained')
        h.run('full-grant-compact',['compact','--control',str(d.control)]);d.shutdown();d=h.start('full-grant-restart',cfg,b)
        h.check(schedule(h,'full-history-replay',b)['schedule']==full,'grants reconstruct through compact and restart')
        d.shutdown()
    case('strict_opt_in_generation_bounds_and_history',strict)

    def semantics():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'auto-semantics');v={}
        create_numeric(h,'numeric-auto-create',b,limit=1);create_summary(h,'metadata-auto-create',b,limit=2)
        enable(h,'numeric-auto-enable',b,'numeric',max_pages=100,min_interval_ms=10);enable(h,'metadata-auto-enable',b,max_pages=100,min_interval_ms=10)
        first=produce(h,'auto-first',a,v,ticks=125);produce(h,'auto-second',a,v,ticks=-25)
        bad=produce(h,'auto-invalid-correction',a,v,raw=b'bad',corrects=first)
        produce(h,'auto-repair',a,v,ticks=150,corrects=bad)
        produce(h,'auto-unit',a,v,raw=payload(1,'K'));produce(h,'auto-scale',a,v,raw=payload(1,scale=3))
        produce(h,'auto-hidden',c,v,ticks=999,issuer='C')
        wait_position(h,b,'numeric',6);wait_position(h,b,'summary',6)
        r=numeric(h,'automatic-numeric',b,'status');rows=h.run('source-reference',['evidence-query','--control',str(bd.control),'--view','history','--issuer','A','--scope','query/series','--payload','yes','--payload-length','46'])['records'];verify(h,r,rows,v)
        s=schedule(h,'automatic-grant-account',b,name='numeric')['schedule']
        h.check(s['active']['pages_completed']==6 and s['active']['through']==6,'finite pages consumed with result/progress')
        h.check(s['actor']=='DAEMON_PROJECTION_WORKER' and s['executor_pid']==bd.process.pid,'daemon execution honestly distinguished from grant PID')
        before=(b/'state.journal').read_bytes();time.sleep(.7);h.check((b/'state.journal').read_bytes()==before,'caught-up schedules create no journal traffic')
        pause(h,'pause-numeric',b,'numeric');produce(h,'arrives-while-paused',a,v,ticks=5)
        wait_position(h,b,'summary',7);time.sleep(.2);h.check(progress(h,'paused-numeric-result',b,'numeric')['consumer']['acknowledged_sequence']==6,'pause preserves cursor while another consumer progresses')
        enable(h,'reenable-exact',b,'numeric',generation=1,max_pages=1,min_interval_ms=10);wait_phase(h,b,'numeric','EXHAUSTED');wait_position(h,b,'numeric',7)
        h.check(numeric(h,'final-numeric',b,'status')['consumer']['projection']['result']['numeric']['sum_ticks']=='130','independent corrected result after resumed processing')
        (h.output/'AUTOMATIC-RESULT.json').write_text(json.dumps({'rows':rows,'inputs':{k:x.hex() for k,x in v.items()},'result':r,'schedule':s},indent=2)+'\n')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('native_numeric_and_metadata_processing',semantics)

    def blocked():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'auto-blocked');v={}
        produce(h,'over-budget-source',a,v,ticks=101)
        create_numeric(h,'blocked-create',b,max_abs_sum=100,limit=1);create_summary(h,'healthy-create',b,limit=1)
        issued=read(h,'manual-issued-before-enable',b,'numeric')['consumer']['pending_batch']
        enable(h,'blocked-enable',b,'numeric',max_pages=10,min_interval_ms=10)
        enable(h,'healthy-enable',b,max_pages=2,min_interval_ms=10)
        wait_phase(h,b,'numeric','BLOCKED');wait_position(h,b,'summary',1)
        s=schedule(h,'blocked-account',b,name='numeric')['schedule'];h.check(s['active']['error']=='PROJECTION_NUMERIC_SUM_LIMIT','typed permanent block without widening definition')
        n=numeric(h,'blocked-no-progress',b,'status')['consumer'];h.check(n['pending_batch']==issued and n['acknowledged_sequence']==0 and n['projection']['result']['numeric']['sum_ticks']=='0','blocking keeps existing pending page and result unchanged')
        stable=(b/'state.journal').read_bytes();time.sleep(.7);h.check((b/'state.journal').read_bytes()==stable,'blocked processor does not retry or journal-loop')
        produce(h,'healthy-second-source',a,v,ticks=1);wait_phase(h,b,'summary','EXHAUSTED')
        produce(h,'healthy-third-source',a,v,ticks=1);time.sleep(.2)
        h.check(progress(h,'page-budget-stops',b,'summary')['consumer']['acknowledged_sequence']==2,'page budget cannot auto-renew')
        enable(h,'healthy-next-grant',b,generation=1,max_pages=1,min_interval_ms=10);wait_position(h,b,'summary',3)
        bd.shutdown();bd=h.start('blocked-restart',bc,b)
        h.check(schedule(h,'blocked-reconstructed',b,name='numeric')['schedule']==s,'blocked account reconstructs without execution')
        # Existing issued page can be adopted, not replaced, by an automatic step.
        create_summary(h,'issued-create',b,'issued',limit=2);p=read(h,'issued-read',b,'issued')['consumer']['pending_batch']
        enable(h,'issued-enable',b,'issued',max_pages=1,min_interval_ms=10);wait_phase(h,b,'issued','EXHAUSTED')
        h.check(progress(h,'issued-completed',b,'issued')['consumer']['last_acknowledged_batch']==p,'preissued batch identity retained by automatic transaction')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('blocked_peer_fairness_finite_budget_and_pending_page',blocked)

    def principals():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'auto-principals',True);v={}
        expose_control_for_uid(b)
        create_summary(h,'principal-create',b,'delegated',uid=SECOND_UID,limit=1)
        create_summary(h,'nonadmin-create',b,'denied',uid=UID,limit=1)
        h.check(enable(h,'nonadmin-enable',b,'denied',uid=UID,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','PROJECTION alone cannot delegate scheduling')
        enable(h,'principal-enable',b,'delegated',uid=SECOND_UID,max_pages=20,min_interval_ms=10)
        produce(h,'delegated-one',a,v,ticks=3)
        h.wait('delegated progress',lambda:summary(h,'delegated-poll',b,'status','delegated',uid=SECOND_UID)['consumer']['acknowledged_sequence']==1)
        h.check(schedule(h,'wrong-owner',b,name='delegated',expected=3)['code']=='PROJECTION_NOT_FOUND','name and grant are exact UID namespace')
        changed=candidate(h,bc,'auto-revoked','auto-revoked-g2',lambda text:'\n'.join(line.replace(',PROJECTION','') if line.startswith(f'local_control={SECOND_UID},') else line for line in text.splitlines())+'\n')
        activate(h,'revoke-processing',b,changed)
        h.wait('revoked schedule blocked',lambda:schedule(h,'revoked-account',b,name='delegated',uid=SECOND_UID)['schedule']['active']['state']=='BLOCKED')
        account=schedule(h,'revoked-inspect-no-read-bypass',b,name='delegated',uid=SECOND_UID)['schedule']
        h.check(account['owner_uid']==SECOND_UID and account['executor_uid']==os.geteuid() and account['actor']=='DAEMON_PROJECTION_WORKER','scheduler attributes actual daemon distinct from grant owner')
        h.check(account['active']['error']=='LOCAL_CONTROL_CLASS_DENIED' and account['active']['through']==1,'revocation blocks before result mutation')
        produce(h,'after-revocation',a,v,ticks=4)
        restored=candidate(h,bc,'auto-grants-restored','auto-restored-g3',lambda x:x);activate(h,'restore-processing',b,restored)
        time.sleep(.25);h.check(summary(h,'restored-not-reenabled',b,'status','delegated',uid=SECOND_UID)['consumer']['acknowledged_sequence']==1,'restored grants do not silently restart blocked work')
        enable(h,'explicit-new-delegation',b,'delegated',uid=SECOND_UID,generation=1,max_pages=1,min_interval_ms=10)
        h.wait('explicit resumed result',lambda:summary(h,'delegated-final',b,'status','delegated',uid=SECOND_UID)['consumer']['acknowledged_sequence']==2)
        prior=summary(h,'before-domain-change',b,'status','delegated',uid=SECOND_UID)
        enable(h,'grant-before-domain-change',b,'delegated',uid=SECOND_UID,generation=2,max_pages=10,min_interval_ms=10)
        widened=candidate(h,restored,'auto-domain-change','auto-domain-g4',lambda text:text+f'evidence_read={SECOND_UID},A,query/other,METADATA\n')
        activate(h,'change-read-authority',b,widened)
        h.wait('authority digest block',lambda:schedule(h,'authority-block',b,name='delegated',uid=SECOND_UID)['schedule']['active']['state']=='BLOCKED')
        h.check(schedule(h,'authority-code',b,name='delegated',uid=SECOND_UID)['schedule']['active']['error']=='CONSUMER_POLICY_CHANGED','new domain never silently reinterprets saved ordinal')
        summary(h,'adopt-authority-rebuild',b,'rebuild','delegated',uid=SECOND_UID,expected_revision=prior['consumer']['revision'],reason='explicitly adopt new read authority')
        enable(h,'grant-new-epoch',b,'delegated',uid=SECOND_UID,generation=3,max_pages=2,min_interval_ms=10)
        h.wait('new epoch recomputation',lambda:summary(h,'new-epoch-result',b,'status','delegated',uid=SECOND_UID)['consumer']['acknowledged_sequence']==2)
        h.run('old-epoch-grants-compact',['compact','--control',str(bd.control)])
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('real_uid_grants_revocation_and_explicit_resume',principals)

    def lifecycle():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'auto-lifecycle');v={};create_summary(h,'life-create',b,limit=1)
        enable(h,'life-enable',b,max_pages=100,min_interval_ms=10)
        h.run('life-quiesce',['quiesce','--control',str(bd.control),'--reason','pause new automatic steps'])
        produce(h,'while-quiesced',a,v,ticks=1);time.sleep(.2)
        h.check(progress(h,'quiesced-no-step',b,'summary')['consumer']['acknowledged_sequence']==0,'quiesce suspends automatic result mutation')
        bd.shutdown();bd=h.start('quiesced-restart',bc,b);time.sleep(.2)
        h.check(progress(h,'quiesced-restart-no-step',b,'summary')['consumer']['acknowledged_sequence']==0,'quiescence reconstructed before worker starts')
        h.run('life-resume',['resume','--control',str(bd.control),'--reason','continue durable grants']);wait_position(h,b,'summary',1)
        h.run('life-drain',['drain-shutdown','--control',str(bd.control),'--reason','finite service shutdown','--drain-deadline-ms','1000'])
        bd.process.wait(timeout=8)
        bd=h.start('after-drain',bc,b);produce(h,'after-drain-source',a,v,ticks=2);wait_position(h,b,'summary',2)
        # Parallel pause callers cannot multiply grants or race a future step.
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            stopped=list(pool.map(lambda i:pause(h,'parallel-pause-'+str(i),b),range(8)))
        h.check(sum(x['disposition']=='PAUSED' for x in stopped)==1,'one pause transition, duplicate stops idempotent')
        produce(h,'after-pause-source',a,v,ticks=3);time.sleep(.2)
        h.check(progress(h,'stopped-progress',b,'summary')['consumer']['acknowledged_sequence']==2,'no step after pause response')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('quiesce_drain_restart_and_concurrent_pause',lifecycle)

    def kills():
        for phase,position in [('BEFORE',0),('AFTER',1)]:
            a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'auto-kill-'+phase);v={};produce(h,'kill-value-'+phase,a,v,ticks=77);create_numeric(h,'kill-create-'+phase,b,limit=1);bd.shutdown()
            bd=h.start('auto-kill-marker-'+phase,bc,b,{f'NATRAV_OVERLAY_TEST_AUTO_{phase}_COMMIT_MS':'20000'})
            enable(h,'kill-enable-'+phase,b,'numeric',max_pages=1,min_interval_ms=10)
            h.wait('actual automatic commit boundary',lambda:f'TEST_AUTO_{phase}_COMMIT_MS' in bd.stderr_path.read_text(),timeout=8)
            bd.kill()
            state=h.run('offline-kill-'+phase,['inspect','--state',str(b),'--node','B']);n=state['consumers'][0]
            h.check(n['acknowledged_sequence']==position and n['projection']['result']['numeric']['sum_ticks']==str(77*position),'result and checkpoint have one crash boundary')
            s=state['projection_schedules'][0];h.check(s['active']['pages_completed']==position,'work-budget consumption commits with effect')
            bd=h.start('auto-kill-restart-'+phase,bc,b);wait_position(h,b,'numeric',1);wait_phase(h,b,'numeric','EXHAUSTED')
            h.check(progress(h,'kill-final-'+phase,b,'numeric')['consumer']['projection']['result']['numeric']['sum_ticks']=='77','restart does not duplicate internal numeric effect')
            cd.shutdown();ad.shutdown();bd.shutdown()
    case('hard_kill_result_progress_and_budget_atomicity',kills)

    def maintenance():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'auto-maintenance');v={};first=produce(h,'maint-number',a,v,ticks=250);create_numeric(h,'maint-create',b,limit=1)
        enable(h,'maint-enable',b,'numeric',max_pages=100,min_interval_ms=10);wait_position(h,b,'numeric',1)
        h.run('maint-quiesce',['quiesce','--control',str(bd.control),'--reason','stable encrypted restore boundary']);bd.shutdown()
        keys=h.runtime/'auto-keys';keys.mkdir(mode=0o700);key=new_key(h,keys,'auto-state-g1');migrate(h,'auto-migrate',b,key,'B')
        bd=start_keyed(h,'auto-keyed',bc,b,key);h.run('auto-keyed-resume',['resume','--control',str(bd.control),'--reason','compact stable state']);h.run('auto-keyed-compact',['compact','--control',str(bd.control)]);h.run('auto-keyed-quiesce',['quiesce','--control',str(bd.control),'--reason','restore without processing']);bd.shutdown()
        before=h.run('auto-keyed-audit',['state-auth-audit','--state',str(b),'--node','B','--state-auth-key',str(key)])
        h.check(before['status']=='COMPLETE','separate keyed audit decoder accepts schedule transitions')
        identity=h.identity('B');crypt=keys/'backup.key';archive=keys/'auto.nob'
        h.run('auto-backup-key',['backup-key-init','--output',str(crypt),'--generation','auto-backup-g1'])
        h.run('auto-export',['backup-export','--state',str(b),'--node','B','--generation','b-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'auto-restored'
        h.run('auto-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','B','--generation','b-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=h.run('auto-restored-inspect',['inspect','--state',str(restored),'--node','B','--state-auth-key',str(key)])
        h.check(after['storage']['logical_state_digest']==before['logical_state_digest'],'schedule and result preserved exactly by encrypted restore')
        moved=candidate(h,bc,'auto-relocated','auto-relocated-g1',lambda s:s.replace(f'state={b}',f'state={restored}'))
        h.run('auto-relocate',['state-relocate','--state',str(restored),'--node','B','--candidate',str(moved),'--reason','explicit automatic projection relocation','--state-auth-key',str(key)])
        bd=start_keyed(h,'auto-relocated-start',moved,restored,key);produce(h,'restored-correction',a,v,ticks=-75,corrects=first);time.sleep(.1)
        h.check(progress(h,'restored-quiesced',restored,'numeric')['consumer']['acknowledged_sequence']==1,'restore retains quiesced lifecycle and enabled grant separately')
        h.run('auto-restored-resume',['resume','--control',str(bd.control),'--reason','resume adopted grant']);wait_position(h,restored,'numeric',2)
        result=progress(h,'restored-auto-result',restored,'numeric');h.check(result['consumer']['projection']['result']['numeric']['sum_ticks']=='-75','new correction processed automatically after restored continuation')
        pause(h,'maint-final-pause',restored,'numeric');h.run('auto-post-compact',['compact','--control',str(bd.control)]);bd.shutdown()
        h.check(h.run('auto-final-audit',['state-auth-audit','--state',str(restored),'--node','B','--state-auth-key',str(key)])['status']=='COMPLETE','appended automation records and checkpoints authenticate')
        (h.output/'RESTORED-AUTOMATION.json').write_text(json.dumps(result,indent=2)+'\n');cd.shutdown();ad.shutdown()
    case('keyed_compaction_signed_encrypted_restore_and_relocation',maintenance)

    def corruption():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'auto-corruption');v={};produce(h,'corrupt-auto-value',a,v,ticks=77);create_numeric(h,'corrupt-auto-create',b,limit=1)
        enable(h,'corrupt-auto-enable',b,'numeric',max_pages=1,min_interval_ms=10);wait_phase(h,b,'numeric','EXHAUSTED');bd.shutdown()
        journal=b/'state.journal';original=journal.read_bytes();frames=[];offset=0
        while offset<len(original):
            n=struct.unpack_from('!I',original,offset+4)[0];body=original[offset+8:offset+8+n];frames.append((offset,n,body));offset+=40+n
        events=[f for f in frames if f[2][0]==28];h.check(len(events)==2,'one explicit grant plus one atomic result/budget record, no implicit issue')
        at,n,body=events[0];journal.write_bytes(original[:at]+original[at+40+n:]);h.run('auto-deleted-grant',['inspect','--state',str(b),'--node','B'],expected=3)
        at,n,body=events[1];body=bytearray(body);start=body.rfind(b'NPR2');h.check(start>0,'numeric result inside atomic automatic transition');u=body[start+4]
        numeric_sum=start+4+1+u+1+8+8+32+72+4*8;struct.pack_into('!q',body,numeric_sum,78)
        journal.write_bytes(original[:at+8]+body+hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest()+original[at+40+n:])
        h.check(h.run('auto-forged-result',['inspect','--state',str(b),'--node','B'],expected=3)['code']=='JOURNAL_CORRUPT','automatic result rederived from source despite valid unkeyed checksum')
        journal.write_bytes(original);bd=h.start('auto-valid-restart',bc,b);wait_position(h,b,'numeric',1);bd.shutdown();cd.shutdown();ad.shutdown()
    case('automatic_transaction_semantic_corruption',corruption)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);begin=time.time();passed=False
    try:cases(h,set(a.case) if a.case else None);passed=True
    except BaseException as e:(h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {type(e).__name__}: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();s={'format':'NATRAV_OVERLAY_AUTOMATIC_PROJECTION_TESTS_V1','status':'PASS' if passed else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-begin}
        for name,value in [('SUMMARY',s),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
        print(json.dumps(s),flush=True)
    return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
