#!/usr/bin/env python3
"""Durable recipient reviews on owned C++ nodes. Tests record interpretations,
not proof of remote execution. Private fixtures/keys never leave local tests.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, shutil, socket, struct, subprocess, sys, time
from pathlib import Path
from run_persistent import Harness, operation, raw_control
from run_action_result_correlation import setup, completed, emit, encode_nac, effect
from run_action_results import submit_action, wait_action, wait_outbox, decode_nac1, evidence_query, RESULT_SCOPE
from run_result_discovery import discover
from run_live_configuration import candidate, activate
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_state_authentication import new_key, migrate, start as keyed_start, inspect
from run_conditional_action import journal_frames, frame


def selected(h,label,state,action):
    d=discover(h,label,state,action)
    return dict(request=action,provider='B',scope=RESULT_SCOPE,count=d['selection']['candidate_count'],
                root=d['selection']['candidate_root'],binding=d['selection']['request_binding'],configuration=d['configuration_digest'])


def args(state,s,reason='review exact observations'):
    return ['action-result-review','--control',str(state/'control.sock'),'--request',s['request'],
            '--provider',s['provider'],'--scope',s['scope'],'--candidate-count',str(s['count']),
            '--candidate-root',s['root'],'--request-binding',s['binding'],'--expected-configuration',s['configuration'],
            '--reason',reason,'--deadline-ms','5000']


def review(h,label,state,s,reason='review exact observations',expected=0,uid=None):
    a=args(state,s,reason)
    r=h.run(label,a,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,a,expected)
    if expected==0:
        h.check(r['format']=='NATRAV_OVERLAY_RESULT_REVIEW_V1' and not r['execution_verified_locally'] and r['freshness']=='NOT_ESTABLISHED','review never becomes local execution proof')
        h.check(r['consistent']+r['invalid']==r['candidate_count']==len(r['records']),'complete per-candidate conservation')
        h.check(len(json.dumps(r,separators=(',',':')).encode())<60000,'bounded full review response')
    return r


def status(h,label,state,r,expected=0,uid=None):
    a=['action-result-review-status','--control',str(state/'control.sock'),'--review',r['review_id'],'--deadline-ms','5000']
    return h.run(label,a,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,a,expected)


def wire(s,reason='review exact observations'):
    text=lambda v:struct.pack('!H',len(v.encode()))+v.encode()
    return b'NOC1\x21RRQ1'+bytes.fromhex(s['request'])+text(s['provider'])+text(s['scope'])+struct.pack('!Q',s['count'])+bytes.fromhex(s['root']+s['binding']+s['configuration'])+text(reason)


def save(h,name,value):
    (h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')


def cases(h,only):
    def case(name,fn):
        if only is None or name in only:h.case(name,fn)

    def basic():
        root,ap,bp,ac,bc,a,b=setup(h,'basic')
        action,result,payload=completed(h,'basic-result',root)
        s=selected(h,'select',root/'a',action)
        for field in ('root','binding','configuration'):
            wrong=dict(s);wrong[field]='ab'*32
            e=review(h,'bad-'+field,root/'a',wrong,expected=3)
            h.check(e['code'] in ('RESULT_REVIEW_SELECTION_CONFLICT','RESULT_REVIEW_REQUEST_CONFLICT','RESULT_REVIEW_CONFIGURATION_CONFLICT'),'exact selection required')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            rs=list(pool.map(lambda i:review(h,'concurrent-'+str(i),root/'a',s),range(8)))
        h.check(sum(r['disposition']=='REVIEWED' for r in rs)==1 and len({r['review_id'] for r in rs})==1,'one durable review and seven idempotent confirmations')
        r=rs[0];h.check(r['conclusion']=='UNIQUE_AUTHENTICATED_REPORT' and r['unique_operation_id']==result,'source-derived unique conclusion')
        independent=hashlib.sha256(b'NATRAV_OVERLAY_RESULT_REVIEW_ID_V1\0'+struct.pack('!I',os.geteuid())+wire(s)[5:]).hexdigest()
        h.check(independent==r['review_id'],'independent UID-bound exact review identity')
        ok,reply=raw_control(root/'a'/'control.sock',wire(s));h.check(ok and reply['disposition']=='ALREADY_REVIEWED','independent protocol retry')
        for p in [wire(s)+b'x',wire(s)[:-1],wire(s).replace(b'RRQ1',b'RRQ2')]:
            ok,e=raw_control(root/'a'/'control.sock',p);h.check(not ok and e['code']=='RESULT_REVIEW_INVALID','strict version EOF and length')
        before=h.status('before-read-polls',root/'a')['storage']['logical_state_digest']
        for i in range(4):status(h,'observational-'+str(i),root/'a',r)
        h.check(h.status('after-read-polls',root/'a')['storage']['logical_state_digest']==before,'successful status observational')
        altered=decode_nac1(payload);altered['terminal_unix_ms']+=1;altered['local_receipt_digest']=effect(altered);emit(h,ap,encode_nac(altered))
        old=status(h,'old-is-history',root/'a',r)
        h.check(old['comparison']['status']=='HISTORICAL' and old['conclusion']==r['conclusion'] and old['record_digest']==r['record_digest'],'later report does not rewrite review')
        h.check(review(h,'retry-after-new-evidence',root/'a',s)['review_id']==r['review_id'],'old exact command remains historical confirmation')
        second=review(h,'explicit-new-review',root/'a',selected(h,'new-select',root/'a',action))
        h.check(second['conclusion']=='CONFLICTING_REPORTS' and second['unique_operation_id'] is None,'new evidence requires separate review, no winner')
        a.shutdown();a=h.start('basic-restart',ac,root/'a');h.check(status(h,'restarted-old',root/'a',r)['record_digest']==r['record_digest'],'review survives restart')
        h.run('basic-compact',['compact','--control',str(root/'a'/'control.sock'),'--deadline-ms','5000']);a.shutdown();a=h.start('basic-after-compact',ac,root/'a')
        h.check(status(h,'compacted-old',root/'a',r)['record_digest']==r['record_digest'],'checkpoint recomputes old selected prefix')
        save(h,'BASIC',{'old':r,'historical':old,'new':second});b.shutdown();a.shutdown()
    case('exact_selection_concurrent_commit_historical_status_and_compaction',basic)

    def empty_and_rebound():
        root,ap,bp,ac,bc,a,b=setup(h,'empty-key')
        disabled=candidate(h,ac,'disabled','review-disabled-g2',lambda t:t.replace('peer_route=B,primary,0,ENABLED,','peer_route=B,primary,0,DISABLED,'))
        activate(h,'disable-request-route',root/'a',disabled)
        action=operation('empty-review-action');submit_action(h,'unsent-original',root/'a',action,5)
        empty=review(h,'empty-review',root/'a',selected(h,'empty-selection',root/'a',action))
        h.check(empty['conclusion']=='NO_CANDIDATES' and not empty['reviewed_receipt_present'],'complete empty review is not a missing receipt or execution')
        emit(h,ap,b'NAC1\x01'+bytes.fromhex(action)+b'invalid')
        invalid=review(h,'invalid-only-review',root/'a',selected(h,'invalid-only-selection',root/'a',action))
        h.check(invalid['conclusion']=='NO_CONSISTENT_REPORTS','invalid-only conclusion explicit')
        newpin=h.identity('B2').spki_sha256
        rebound=candidate(h,disabled,'new-generation','review-new-key-g3',lambda t:t.replace('peer_key=B,b-g1,ACTIVE,','peer_key=B,b-g1,RETIRED,')+f'peer_key=B,b-g2,ACTIVE,{newpin}\n')
        activate(h,'new-original-key-policy',root/'a',rebound)
        h.run('explicit-original-rebind',['rebind','--control',str(root/'a'/'control.sock'),'--operation',action,'--generation','b-g2','--reason','select replacement request key'])
        old=status(h,'old-key-review-historical',root/'a',invalid)
        h.check(not old['comparison']['request_binding_matches'] and old['reviewed_original']['provider_generation']=='b-g1','review retains original historical key rather than reinterpretation')
        h.run('rebound-history-compact',['compact','--control',str(root/'a'/'control.sock'),'--deadline-ms','5000']);a.shutdown();a=h.start('rebound-history-restart',rebound,root/'a')
        h.check(status(h,'rebound-review-reconstructed',root/'a',invalid)['record_digest']==invalid['record_digest'],'review reconstructs earlier key from retained delivery prefix')
        save(h,'EMPTY-AND-REBOUND',{'empty':empty,'invalid':invalid,'historical':old});b.shutdown();a.shutdown()
    case('empty_invalid_only_and_rebound_original_history',empty_and_rebound)

    def large():
        root,ap,bp,ac,bc,a,b=setup(h,'large')
        action,result,payload=completed(h,'large-result',root)
        for i in range(74):emit(h,ap,b'NAC1\x01'+bytes.fromhex(action)+struct.pack('!I',i)+b'invalid')
        r=review(h,'seventy-five-review',root/'a',selected(h,'large-select',root/'a',action))
        h.check(r['candidate_count']==75 and r['consistent']==1 and r['invalid']==74,'review recomputes beyond a discovery page')
        for i in range(74,127):emit(h,ap,b'NAC1\x01'+bytes.fromhex(action)+struct.pack('!I',i)+b'invalid')
        boundary=review(h,'exact-128-review',root/'a',selected(h,'exact-128-selection',root/'a',action))
        h.check(boundary['candidate_count']==128 and boundary['consistent']==1,'exact maximum complete review succeeds')
        emit(h,ap,b'NAC1\x01'+bytes.fromhex(action)+struct.pack('!I',128)+b'invalid')
        s=selected(h,'over-bound-select',root/'a',action)
        e=review(h,'over-bound-review',root/'a',s,expected=3)
        h.check(e['code'] in ('INVALID_INTEGER','INVALID_ARGUMENT','RESULT_REVIEW_INVALID'),'finite review cap, not partial uniqueness')
        save(h,'BOUNDED-REVIEW',{'accepted':r,'at_boundary':boundary,'too_large':e});b.shutdown();a.shutdown()
    case('bounded_complete_validation_beyond_one_discovery_page',large)

    def absent():
        action=operation('review-late-receipt')
        root,ap,bp,ac,bc,a,b=setup(h,'late',environment={'NATRAV_OVERLAY_TEST_SESSION_DROP_AFTER_ADMISSION_OPERATION':action})
        slow=candidate(h,ac,'slow','review-slow-g2',lambda t:t.replace('peer=B,50,250,50,120000','peer=B,10000,10000,50,120000'))
        activate(h,'slow-retry',root/'a',slow)
        submit_action(h,'late-submit',root/'a',action,9);ar=wait_action(h,'late-executed',root/'b',action,'EXECUTED');result=ar['action_result']['operation_id'];wait_outbox(h,'late-result',root/'b',result,'ACKED')
        raw=bytes.fromhex(evidence_query(h,'late-raw',root/'a',result)['payload_hex']);alternate=decode_nac1(raw);alternate['source_sequence']+=1;emit(h,ap,encode_nac(alternate))
        first=review(h,'absent-receipt-review',root/'a',selected(h,'late-select',root/'a',action))
        h.check(not first['reviewed_receipt_present'] and first['conclusion']=='CONFLICTING_REPORTS','no fabricated original receipt')
        b.shutdown();b=h.start('provider-returns',bc,root/'b');wait_outbox(h,'late-receipt-arrived',root/'a',action,'ACKED')
        old=status(h,'receipt-makes-history',root/'a',first)
        h.check(not old['comparison']['request_binding_matches'] and old['conclusion']=='CONFLICTING_REPORTS','actual receipt changes current facts, not recorded review')
        second=review(h,'with-receipt-review',root/'a',selected(h,'receipt-select',root/'a',action))
        h.check(second['reviewed_receipt_present'] and second['conclusion']=='UNIQUE_AUTHENTICATED_REPORT','new review uses actual receipt')
        h.run('late-compact',['compact','--control',str(root/'a'/'control.sock'),'--deadline-ms','5000']);a.shutdown();a=h.start('late-restart',slow,root/'a')
        h.check(status(h,'historical-receipt-replay',root/'a',first)['record_digest']==first['record_digest'],'checkpoint reconstructs earlier absence from mutation prefix')
        save(h,'LATE-RECEIPT',{'before':first,'historical':old,'after':second});b.shutdown();a.shutdown()
    case('late_original_receipt_preserves_historical_review_basis',absent)

    def authority():
        root,ap,bp,ac,bc,a,b=setup(h,'authority',delegates=True)
        action,result,payload=completed(h,'auth-result',root);s=selected(h,'auth-select',root/'a',action)
        expose_control_for_uid(root/'a')
        e=review(h,'reader-not-writer',root/'a',s,uid=65534,expected=3);h.check(e['code']=='LOCAL_CONTROL_CLASS_DENIED','read permission alone cannot persist review')
        grant=candidate(h,ac,'review-grant','review-grant-g2',lambda t:t.replace('local_control=65534,INSPECT,EVIDENCE_READ,EVIDENCE_PAYLOAD','local_control=65534,INSPECT,MAINTENANCE,EVIDENCE_READ,EVIDENCE_PAYLOAD'))
        activate(h,'grant-review',root/'a',grant);s=selected(h,'delegated-select',root/'a',action)
        r=review(h,'real-delegate',root/'a',s,uid=65534)
        h.check(r['uid']==65534 and r['pid']>0,'real historical principal retained')
        h.check(status(h,'other-owner',root/'a',r,expected=3)['code']=='RESULT_REVIEW_NOT_FOUND','another inspector cannot claim review ownership')
        script="""import socket,struct,sys,json
s=socket.socket(socket.AF_UNIX);s.settimeout(10);s.connect(sys.argv[1]);p=bytes.fromhex(sys.argv[2]);s.sendall(struct.pack('!I',len(p))+p[:2]);print('CONNECTED',flush=True);sys.stdin.readline();s.sendall(p[2:]);s.shutdown(socket.SHUT_WR)
def read(n):
 b=b''
 while len(b)<n:
  x=s.recv(n-len(b))
  if not x:raise RuntimeError('EOF')
  b+=x
 return b
r=read(struct.unpack('!I',read(4))[0]);print(json.dumps({'ok':r[4]==0,'body':json.loads(r[5:])}))
"""
        p=subprocess.Popen(['/usr/bin/setpriv','--reuid=65534','--regid=65534','--clear-groups',sys.executable,'-c',script,str(root/'a'/'control.sock'),wire(s,'new slow review').hex()],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            h.check(p.stdout.readline().strip()=='CONNECTED','kernel delegate partly transmitted')
            revoked=candidate(h,grant,'revoked','review-revoked-g3',lambda t:t.replace('local_control=65534,INSPECT,MAINTENANCE,EVIDENCE_READ,EVIDENCE_PAYLOAD','local_control=65534,INSPECT,EVIDENCE_READ,EVIDENCE_PAYLOAD'))
            activate(h,'revoke-review',root/'a',revoked);out,err=p.communicate('\n',timeout=10);response=json.loads(out.splitlines()[-1])
            h.check(p.returncode==0 and not response['ok'] and response['body']['code']=='LOCAL_CONTROL_CLASS_DENIED','new accepted grant governs commit')
        finally:
            if p.poll() is None:p.kill();p.wait()
        h.check(status(h,'still-readable',root/'a',r,uid=65534)['record_digest']==r['record_digest'],'read authority can remain after maintenance revocation')
        restore_owner_only_control(root/'a');save(h,'AUTHORITY',{'review':r,'revoked':response});b.shutdown();a.shutdown()
    case('real_uid_separate_write_authority_and_live_revocation',authority)

    def limits():
        root,ap,bp,ac,bc,a,b=setup(h,'limits')
        action,result,payload=completed(h,'limit-result',root);s=selected(h,'limits-select',root/'a',action)
        accepted=[review(h,'grant-'+str(i),root/'a',s,reason='independent review '+str(i)) for i in range(16)]
        h.check(review(h,'seventeenth',root/'a',s,reason='excess review',expected=3)['code']=='RESULT_REVIEW_LIMIT','per-UID history cap enforced')
        h.check(review(h,'retry-at-cap',root/'a',s,reason='independent review 0')['review_id']==accepted[0]['review_id'],'idempotency survives full history')
        h.run('limits-compact',['compact','--control',str(root/'a'/'control.sock'),'--deadline-ms','5000']);a.shutdown();a=h.start('limits-restart',ac,root/'a')
        h.check(status(h,'retained-sixteenth',root/'a',accepted[-1])['record_digest']==accepted[-1]['record_digest'],'full per-UID registry reconstructs')
        save(h,'LIMITS',{'accepted':len(accepted),'last':accepted[-1]});b.shutdown();a.shutdown()
    case('finite_per_principal_history_and_idempotency_at_capacity',limits)

    def corruption():
        root,ap,bp,ac,bc,a,b=setup(h,'corruption');action,result,payload=completed(h,'corrupt-result',root)
        emit(h,ap,b'NAC1\x01'+bytes.fromhex(action)+b'bad')
        r=review(h,'corruptible-review',root/'a',selected(h,'corrupt-select',root/'a',action));a.shutdown()
        journal=root/'a'/'state.journal';original=journal.read_bytes();frames=journal_frames(original)
        start,end,body=next(v for v in frames if v[2][0]==38)
        def encoded_rows(rows):
            out=b''
            for row in rows:
                rejection=(row['rejection_code'] or '').encode()
                out+=bytes.fromhex(row['operation_id']+row['record_digest'])+struct.pack('!H',len(rejection))+rejection
            return out
        recorded=encoded_rows(r['records'])
        forged=[dict(row) for row in r['records']]
        forged[0]['rejection_code'],forged[1]['rejection_code']=forged[1]['rejection_code'],forged[0]['rejection_code']
        replacement=encoded_rows(forged)
        h.check(len(recorded)==len(replacement) and body.count(recorded)==1,'exact retained classification replacement without size changes')
        changed=body.replace(recorded,replacement)
        journal.write_bytes(original[:start]+frame(changed)+original[end:])
        err=h.run('forged-classification',['inspect','--state',str(root/'a'),'--node','A'],expected=3)
        h.check(err['code']=='JOURNAL_CORRUPT','recomputed checksum cannot forge source-derived conclusion')
        journal.write_bytes(original);a=h.start('corruption-valid-again',ac,root/'a');h.run('corruption-compact',['compact','--control',str(root/'a'/'control.sock'),'--deadline-ms','5000']);a.shutdown()
        compact=journal.read_bytes();body=journal_frames(compact)[0][2];changed=bytearray(body.replace(recorded,replacement))
        logical=changed.index(b'NLS2');changed[logical-48:logical-16]=hashlib.sha256(b'NATRAV_OVERLAY_LOGICAL_STATE_V2\0'+bytes(changed[logical:])).digest();journal.write_bytes(frame(bytes(changed)))
        err=h.run('forged-checkpoint',['inspect','--state',str(root/'a'),'--node','A'],expected=3);h.check(err['code']=='JOURNAL_CORRUPT','checkpoint reconstructs classification from source')
        journal.write_bytes(compact);save(h,'CORRUPTION',{'review':r,'rejection':err});b.shutdown()
    case('source_derived_journal_and_checkpoint_classification',corruption)

    def crashes():
        for point in ('BEFORE_COMMIT','AFTER_COMMIT'):
            root,ap,bp,ac,bc,a,b=setup(h,'crash-'+point);action,result,payload=completed(h,'crash-result-'+point,root);s=selected(h,'crash-select-'+point,root/'a',action)
            a.shutdown();a=h.start('paused-'+point,ac,root/'a',environment={'NATRAV_OVERLAY_TEST_RESULT_REVIEW_'+point+'_MS':'2500'})
            p=subprocess.Popen([str(h.binary),*args(root/'a',s)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            try:
                h.wait('commit-boundary-'+point,lambda:('RESULT_REVIEW_'+point) in a.stderr_path.read_text(),timeout=6)
                a.kill();p.communicate(timeout=6)
            finally:
                if p.poll() is None:p.kill();p.wait()
            a=h.start('after-kill-'+point,ac,root/'a');r=review(h,'retry-kill-'+point,root/'a',s)
            h.check(r['disposition']==('REVIEWED' if point=='BEFORE_COMMIT' else 'ALREADY_REVIEWED'),'old or complete review across kill')
            b.shutdown();a.shutdown()
    case('real_kills_before_and_after_atomic_review_commit',crashes)

    def maintenance():
        root,ap,bp,ac,bc,a,b=setup(h,'maintenance');action,result,payload=completed(h,'maint-result',root,11)
        r=review(h,'maint-review',root/'a',selected(h,'maint-select',root/'a',action));a.shutdown()
        key=new_key(h,h.work,'review-state');migrate(h,'review-migrate',root/'a',key,node='A');a=keyed_start(h,'review-keyed',ac,root/'a',key)
        second=review(h,'keyed-appended-review',root/'a',selected(h,'keyed-select',root/'a',action),reason='second keyed review');a.shutdown()
        h.run('keyed-review-audit',['state-auth-audit','--state',str(root/'a'),'--node','A','--state-auth-key',str(key)])
        a=keyed_start(h,'keyed-compaction',ac,root/'a',key);h.run('review-compact',['compact','--control',str(root/'a'/'control.sock'),'--deadline-ms','5000']);a.shutdown()
        before=inspect(h,'review-pre-export',root/'a',key,node='A');crypt=h.work/'review-crypt.key'
        h.run('review-key',['backup-key-init','--output',str(crypt),'--generation','review-backup'])
        identity=h.identity('A');archive=h.work/'review.nob';h.run('review-export',['backup-export','--state',str(root/'a'),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--output',str(archive),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'review-restored';h.run('review-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'review-restored',restored,key,node='A');h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'restore preserves exact state including reviews')
        newidentity=h.runtime/'review-identity';newidentity.mkdir(mode=0o700);cert=newidentity/'cert.pem';secret=newidentity/'key.pem';shutil.copyfile(identity.certificate,cert);shutil.copyfile(identity.private_key,secret);secret.chmod(0o600)
        moved=candidate(h,ac,'review-relocated','review-relocated-g2',lambda t:t.replace('state='+str(root/'a'),'state='+str(restored)).replace(str(identity.certificate),str(cert)).replace(str(identity.private_key),str(secret)))
        h.run('review-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','review continuation','--state-auth-key',str(key)]);identity.certificate.unlink();identity.private_key.unlink()
        a=keyed_start(h,'relocated-review',moved,restored,key);rr=status(h,'review-history-without-old-keys',restored,r)
        h.check(rr['record_digest']==r['record_digest'] and rr['comparison']['candidate_set_matches'] and not rr['comparison']['configuration_matches'],'historical review survives relocation without reopening obsolete paths')
        new=operation('review-post-restore');submit_action(h,'new-request-after-review-restore',restored,new,2);ar=wait_action(h,'new-effect-after-restore',root/'b',new,'EXECUTED');wait_outbox(h,'new-result-after-restore',root/'b',ar['action_result']['operation_id'],'ACKED')
        latest=review(h,'new-review-after-restore',restored,selected(h,'new-selection-after-restore',restored,new));h.check(latest['conclusion']=='UNIQUE_AUTHENTICATED_REPORT','new real request/result still reviewable')
        save(h,'MAINTENANCE',{'before':r,'after':rr,'keyed':second,'continued':latest});b.shutdown();a.shutdown()
    case('authenticated_replay_encrypted_restore_relocation_and_new_results',maintenance)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');args_=p.parse_args()
    if args_.output.exists():p.error('output must not exist')
    h=Harness(args_.binary,args_.output);start=time.time();ok=False
    try:
        cases(h,set(args_.case) if args_.case else None)
        if not h.cases:raise ValueError('no selected cases')
        ok=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {e}',file=sys.stderr)
    finally:
        h.cleanup();s={'format':'NATRAV_RESULT_REVIEW_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,value in [('SUMMARY',s),('CASES',h.cases),('COMMANDS',h.commands)]:save(h,name,value)
        print(json.dumps(s),flush=True)
    return 0 if ok else 1

if __name__=='__main__':raise SystemExit(main())
