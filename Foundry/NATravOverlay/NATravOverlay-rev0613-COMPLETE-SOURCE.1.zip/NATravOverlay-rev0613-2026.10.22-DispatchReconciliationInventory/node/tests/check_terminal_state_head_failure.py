#!/usr/bin/env python3
"""Exercise finalizer refusal with an isolated injected runtime-failure build."""
import argparse,hashlib,json,time
from pathlib import Path
from run_persistent import Harness
from run_terminal_state_head import setup,args
from run_state_authentication import inspect,start
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
a=p.parse_args();h=Harness(a.binary,a.output);begin=time.time();code=1
try:
    def run():
        state,key,conf,d=setup(h,'failure-handoff')
        result=h.run('failed-runtime-final',args(d,100),expected=3)
        h.check(result and result['code']=='TERMINAL_HEAD_RUNTIME_FAILED' and 'state_head' not in result,'failed worker account cannot expose a healthy final head')
        assert d.process;d.process.wait(timeout=8);h.check(d.process.returncode==3,'failed terminal accounting is reflected in daemon exit');d._close_files()
        snapshot=inspect(h,'failed-final-offline',state,key)
        h.check(snapshot['lifecycle']['interrupted_drain'] is True,'no fabricated DRAIN_COMPLETED after failed runtime')
        restarted=start(h,'failure-restart',conf,state,key)
        h.check(h.status('failure-restart-status',state,logical_digest=False)['lifecycle']['mode']=='QUIESCED','independent restart preserves interrupted drain safety')
        restarted.shutdown()
    h.case('failed_runtime_refuses_terminal_head',run);code=0
except BaseException:
    import traceback
    (h.output/'FAILURE.txt').write_text(traceback.format_exc())
finally:
    h.cleanup()
    summary={'format':'TERMINAL_HEAD_FAILURE_PROPAGATION_V1','status':'PASS' if code==0 else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),
        'cases_passed':sum(c['status']=='PASS' for c in h.cases),'cases_total':len(h.cases),'assertions':h.assertions,'elapsed_seconds':time.time()-begin}
    for name,obj in (('SUMMARY.json',summary),('CASES.json',h.cases),('COMMANDS.json',h.commands)):(h.output/name).write_text(json.dumps(obj,indent=2)+'\n')
    print(json.dumps(summary))
raise SystemExit(code)
