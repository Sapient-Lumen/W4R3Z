#!/usr/bin/env python3
"""NSP1 framing, real NAPA/TTY I/O, and pinned same-binary complete-node lifecycle.
PTYs model byte-stream faults; this suite claims no electrical/hardware evidence.
"""
from __future__ import annotations
import argparse
import errno
import hashlib
import json
import os
from pathlib import Path
import pty
import select
import signal
import socket
import struct
import subprocess
import sys
import termios
import threading
import time
import tty
import zlib

from run_persistent import Harness, free_port, operation
from run_peer_sessions import submit, outbox_entry
from run_configured_adapter_transport import image_profile, ref, wait_entry, assert_receipt, peer
from run_runtime_adapter_configuration import endpoint, records, upgrade, write, digest
from run_live_configuration import candidate, activate
from run_unix_datagram_transport import run_external

HEADER=struct.Struct('>8sB3xQIII')
MAGIC=b'NAPA0001'

def arguments(path, quantum=127, timeout=5000, queue_bytes=65536, queue_frames=64, flow='none', baud=115200, mtu=512):
    return ['serial-packet-adapter','--serial',
        f'serial-v1|path={path}|baud={baud}|data=8|parity=none|stop=1|flow={flow}',
        '--mtu',str(mtu),'--link','0000000000000001','--epoch','1',
        '--queue-bytes',str(queue_bytes),'--queue-frames',str(queue_frames),
        '--frame-timeout-ms',str(timeout),'--io-quantum',str(quantum)]

def napa(kind,seq,payload=b'',deadline=500):
    prefix=HEADER.pack(MAGIC,kind,seq,deadline,0,len(payload))
    return prefix+struct.pack('>I',zlib.crc32(prefix+payload))+payload

def wire(payload, link=1, epoch=1):
    raw=b'NSP1'+struct.pack('>QIH',link,epoch,len(payload))+payload
    raw+=struct.pack('>I',zlib.crc32(raw));out=bytearray(b'~')
    for b in raw:
        if b<32 or b in (125,126,127):out.extend((125,b^32))
        else:out.append(b)
    return bytes(out)+b'~'

def worst_case_wire_bytes(mtu):
    return 2*(mtu+22)+2

def minimum_line_time_ms(mtu,baud,bits_per_character=10):
    return (worst_case_wire_bytes(mtu)*bits_per_character*1000+baud-1)//baud

class NativeAdapter:
    def __init__(self,binary,path,log,args=None,mtu=512):
        self.sock,child=socket.socketpair(socket.AF_UNIX,socket.SOCK_SEQPACKET)
        self.sock.settimeout(3);self.seq=0;self.log=log;self.err=log.open('wb');self.mtu=mtu
        fd=child.fileno()
        def setup():
            os.dup2(fd,3)
            if fd!=3:os.close(fd)
        self.p=subprocess.Popen([str(binary),*(args or arguments(path))],
            pass_fds=tuple(sorted({3,fd})),preexec_fn=setup,stdout=subprocess.DEVNULL,stderr=self.err,
            env=dict(os.environ,NATRAV_ADAPTER_FD='3',NATRAV_ADAPTER_PROTOCOL='NAPA0001'))
        child.close()
    def request(self,kind,payload=b''):
        self.seq+=1;self.sock.send(napa(kind,self.seq,payload));r=self.sock.recv(8192)
        if len(r)<36:raise AssertionError('adapter EOF: '+self.log.read_text(errors='replace'))
        magic,typ,seq,deadline,status,length=HEADER.unpack(r[:32])
        assert magic==MAGIC and typ==kind+1 and seq==self.seq and deadline==0 and length==len(r)-36
        assert zlib.crc32(r[:32]+r[36:])==struct.unpack('>I',r[32:36])[0]
        return status,r[36:]
    def hello(self):
        return self.request(1,struct.pack('>IIIII',1,self.mtu,65536,1048576,1))
    def received(self,timeout=3):
        end=time.monotonic()+timeout
        while time.monotonic()<end:
            status,payload=self.request(5)
            if status==0:return payload
            assert status==1 and not payload;time.sleep(.002)
        raise AssertionError('timed out waiting for serial packet')
    def close(self):
        try:
            if self.p.poll() is None:self.request(9)
        except (OSError,AssertionError):pass
        try:self.p.wait(timeout=2)
        except subprocess.TimeoutExpired:self.p.kill();self.p.wait()
        self.sock.close();self.err.close()
    def __enter__(self):return self
    def __exit__(self,*_):self.close()

def write_all(fd,data,quantum=17):
    end=time.monotonic()+4
    while data:
        if time.monotonic()>end:raise AssertionError('fixture write deadline')
        if select.select([],[fd],[],.1)[1]:
            try:n=os.write(fd,data[:quantum]);data=data[n:]
            except BlockingIOError:pass

def read_bytes(fd,n):
    out=bytearray();end=time.monotonic()+4
    while len(out)<n:
        if time.monotonic()>end:raise AssertionError('fixture read deadline')
        if select.select([fd],[],[],.1)[0]:out.extend(os.read(fd,n-len(out)))
    return bytes(out)

class PtyLink:
    """Fixture-only replaceable null-modem link with finite frame faults."""
    ACTIONS={3:'DROP',5:'CORRUPT',7:'DUPLICATE',9:'DELAY',11:'TRUNCATE',13:'NOISE',15:'REORDER'}
    def __init__(self,adversity=True):
        self.m=[];self.s=[];self.paths=[]
        for _ in range(2):
            m,s=self._new_pair();self.m.append(m);self.s.append(s);self.paths.append(os.ttyname(s))
        self.adversity=adversity;self.events=[];self.ordinals=[0,0];self.replacements=[]
        self.error=None;self.closed=False;self._start_worker()
    @staticmethod
    def _new_pair():
        m,s=pty.openpty();tty.setraw(s);os.set_blocking(m,False);return m,s
    def _start_worker(self):
        self.worker_stop=threading.Event()
        self.thread=threading.Thread(target=self.run,args=(self.worker_stop,),daemon=True)
        self.thread.start()
    def _stop_worker(self):
        self.worker_stop.set();self.thread.join(3)
        if self.thread.is_alive():raise AssertionError('fixture worker did not stop')
        if self.error:raise AssertionError(self.error)
    def replace_side(self,index):
        """Replace an actual PTY while leaving the opposite device open."""
        new_m,new_s=self._new_pair();new_path=os.ttyname(new_s);old_path=self.paths[index]
        try:self._stop_worker()
        except BaseException:
            os.close(new_m);os.close(new_s);raise
        old_m,old_s=self.m[index],self.s[index]
        self.m[index]=new_m;self.s[index]=new_s;self.paths[index]=new_path
        os.close(old_m);os.close(old_s)
        self.replacements.append({'side':index,'old_path':old_path,'new_path':new_path})
        self._start_worker();return new_path
    def run(self,stop):
        buffers=[bytearray(),bytearray()];queues=[bytearray(),bytearray()];delayed=[];held=[None,None]
        masters=list(self.m)
        try:
            while not stop.is_set():
                now=time.monotonic()
                for event in list(delayed):
                    when,d,data=event
                    if when<=now:queues[d].extend(data);delayed.remove(event)
                ready,writing,_=select.select(masters,[masters[i] for i in range(2) if queues[i]],[],.002)
                for fd in writing:
                    i=masters.index(fd)
                    try:n=os.write(fd,queues[i][:31]);del queues[i][:n]
                    except BlockingIOError:pass
                for fd in ready:
                    i=masters.index(fd);target=1-i
                    try:data=os.read(fd,4096)
                    except OSError as e:
                        if e.errno==errno.EIO:continue
                        raise
                    for b in data:
                        if b==126:
                            if buffers[i]:
                                packet=b'~'+bytes(buffers[i])+b'~';buffers[i].clear();self.ordinals[i]+=1
                                o=self.ordinals[i];action=self.ACTIONS.get(o,'PASS') if self.adversity else 'PASS'
                                if action!='PASS':self.events.append({'direction':i,'ordinal':o,'action':action})
                                if action=='DROP':continue
                                if action=='CORRUPT':packet=packet[:4]+bytes([packet[4]^1])+packet[5:]
                                elif action=='DUPLICATE':packet+=packet
                                elif action=='DELAY':delayed.append((now+.03,target,packet));continue
                                elif action=='TRUNCATE':packet=packet[:len(packet)//2]+b'~'
                                elif action=='NOISE':packet=b'garbage~\x7d\x55~'+packet
                                elif action=='REORDER':
                                    if held[i] is not None:raise AssertionError('more than one held reorder frame')
                                    held[i]=(target,packet);continue
                                queues[target].extend(packet)
                                if held[i] is not None:
                                    held_target,held_packet=held[i]
                                    if held_target!=target:raise AssertionError('reorder target changed')
                                    queues[target].extend(held_packet);held[i]=None
                        else:
                            buffers[i].append(b)
                            if len(buffers[i])>8240:raise AssertionError('fixture framing bound exceeded')
                if any(len(q)>262144 for q in queues) or len(delayed)>4:raise AssertionError('fixture queue bound exceeded')
        except BaseException as e:self.error=repr(e)
    def close(self):
        if self.closed:return
        self.closed=True
        try:self._stop_worker()
        finally:
            for fd in self.m+self.s:
                try:os.close(fd)
                except OSError:pass

def owned_children(daemon):
    # Some test kernels omit /proc/<pid>/task/<tid>/children. Match only the
    # exact owned daemon PPid and argv; no unrelated process may be signalled.
    pid=daemon.process.pid
    found=[]
    for directory in Path('/proc').iterdir():
        if not directory.name.isdigit():continue
        try:
            status=dict(line.split(':',1) for line in (directory/'status').read_text().splitlines() if ':' in line)
            if int(status.get('PPid','-1'))!=pid:continue
            args=(directory/'cmdline').read_bytes().split(b'\0')
        except (FileNotFoundError,ProcessLookupError,PermissionError):continue
        if b'serial-packet-adapter' in args:found.append((int(directory.name),args))
    return found


def suite(h,selected):
    root=Path(__file__).resolve().parents[2]
    def case(name,fn):
        if selected is None or selected==name:h.case(name,fn)
    def framing():
        probe=h.work/'framing-probe'
        flags=['-std=c++20','-O1','-Wall','-Wextra','-Wpedantic','-Wconversion','-Wsign-conversion','-Wshadow','-Wformat=2','-Werror']
        result=run_external(h,'compile-framing',['g++',*flags,'-I'+str(root/'node/src'),str(root/'node/tests/test_serial_packet_framing.cpp'),str(root/'node/src/serial_packet_framing.cpp'),'-o',str(probe)],timeout=60)
        h.check(result.returncode==0,result.stderr)
        result=run_external(h,'framing',[str(probe)],timeout=20)
        h.check(result.returncode==0,result.stderr)
        data=json.loads(result.stdout);h.assertions+=data['assertions']
        h.check(data['status']=='PASS','canonical vectors, splits, expiry and bounded recovery')
        version=h.run('version',['version'])
        h.check(version.get('serial_packet_adapter')=='FRAMED_SERIAL_PACKET_ADAPTER_V1','same product carries adapter role')
        h.check(version.get('serial_packet_timing')=='BOUNDED_LINE_RATE_FRAME_BUDGET_V1',
            'line-rate budget is an explicit product contract')
    case('canonical_framing_and_finite_decoder',framing)

    def direct():
        m,s=pty.openpty();path=os.ttyname(s);before=termios.tcgetattr(s);os.set_blocking(m,False)
        try:
            with NativeAdapter(h.binary,path,h.logs/'direct.stderr.txt',arguments(path,quantum=7,flow='software')) as adapter:
                adapter.seq=36 # supervisor counter may survive earlier failed launches
                status,caps=adapter.hello();h.check(status==0 and struct.unpack('>IIIII',caps)==(1,512,548,65536,1),'exact bounded NAPA capabilities')
                data=bytes(range(256));status,_=adapter.request(3,data);h.check(status==0,'local queue accepted datagram')
                expected=wire(data);h.check(read_bytes(m,len(expected))==expected,'exact canonical serial bytes with short writes and XON/XOFF escaping')
                write_all(m,expected,1);h.check(adapter.received()==data,'partial serial reads preserve all octets')
                bad=wire(b'wrong',link=2)+b'noise~\x7d\x55~'+wire(b'wrong',epoch=2)
                corrupted=bytearray(wire(b'bad'));corrupted[bytes(corrupted).index(b'bad')]^=1
                write_all(m,bad+corrupted+wire(b'good'),3)
                h.check(adapter.received()==b'good','noise, alias links, epochs, CRC and malformed escapes reject before next valid frame')
                write_all(m,wire(b'duplicate')*2,5)
                h.check(adapter.received()==b'duplicate' and adapter.received()==b'duplicate','packet duplicates deliberately left to finite service')
            h.check(termios.tcgetattr(s)==before,'orderly child release restores original termios')
            with NativeAdapter(h.binary,path,h.logs/'expiry.stderr.txt',arguments(path,timeout=100)) as adapter:
                adapter.hello();data=wire(b'expired');write_all(m,data[:8]);time.sleep(.15)
                write_all(m,data[8:]+wire(b'after-expiry'))
                h.check(adapter.received()==b'after-expiry','incomplete frame expires and resynchronizes')
            with NativeAdapter(h.binary,path,h.logs/'killed.stderr.txt') as killed:
                killed.hello();killed.p.kill();killed.p.wait()
            with NativeAdapter(h.binary,path,h.logs/'reopened.stderr.txt') as reopened:
                h.check(reopened.hello()[0]==0,'SIGKILL releases cooperative TTY lease without privileged ioctl cleanup')
            minimum=minimum_line_time_ms(256,1200)
            h.check(minimum==4650,'exact 1200-baud worst-case 256-byte line budget')
            rejected=h.run('low-baud-short-budget',
                arguments(path,baud=1200,mtu=256,timeout=minimum-1),expected=3)
            h.check(rejected.get('code')=='SERIAL_PACKET_TIMEOUT_TOO_SHORT',
                'impossible low-baud frame lifetime is rejected before TTY ownership')
            with NativeAdapter(h.binary,path,h.logs/'low-baud-exact.stderr.txt',
                    arguments(path,baud=1200,mtu=256,timeout=minimum),mtu=256) as low:
                status,caps=low.hello()
                h.check(status==0 and struct.unpack('>IIIII',caps)==(1,256,292,65536,1),
                    'exact minimum low-rate budget is admitted')
                payload=b'low-rate-budget';h.check(low.request(3,payload)[0]==0,'low-rate packet accepted')
                h.check(read_bytes(m,len(wire(payload)))==wire(payload),
                    'low-rate profile preserves canonical bytes; PTY does not claim physical baud timing')
            # Existing pathname / unsafe traversal negatives are actual child launches.
            symlink=h.work/'tty-link';symlink.symlink_to(path)
            for label,target,args in [('symlink',str(symlink),None),('dot',path.replace('/pts/','/pts/./'),None),('regular',str(h.work/'regular'),None),('seven',path,arguments(path))]:
                if label=='regular':Path(target).write_text('not a tty')
                aargs=args or arguments(target)
                if label=='seven':aargs=[arg.replace('|data=8|','|data=7|') for arg in aargs]
                with NativeAdapter(h.binary,target,h.logs/(label+'.stderr.txt'),aargs) as adapter:
                    rc=adapter.p.wait(timeout=3);h.check(rc!=0,'unsafe TTY selection rejected: '+label)
            with NativeAdapter(h.binary,path,h.logs/'owner.stderr.txt') as owner:
                owner.hello()
                with NativeAdapter(h.binary,path,h.logs/'duplicate.stderr.txt') as duplicate:
                    h.check(duplicate.p.wait(timeout=3)!=0,'second cooperative TTY lease rejected')
                # A syntactically valid but oversized local datagram is terminal.
                owner.sock.send(napa(3,owner.seq+1,b'x'*513))
                h.check(owner.p.wait(timeout=3)!=0,'truncated NAPA datagram cannot become serial packet')
        finally:os.close(m);os.close(s)
    case('napa_pty_framing_and_negative_controls',direct)

    def pressure():
        m,s=pty.openpty();path=os.ttyname(s);os.set_blocking(m,False)
        try:
            with NativeAdapter(h.binary,path,h.logs/'pressure.stderr.txt',arguments(path,quantum=1,timeout=100,queue_bytes=2048,queue_frames=1)) as a:
                a.hello();h.check(a.request(3,b'\x7e'*512)[0]==0,'one bounded serial frame accepted')
                h.check(a.request(3,b'x'*512)[0]==2,'queue pressure returns BUSY without partial admission')
                h.check(a.p.wait(timeout=3)!=0,'unfinished outbound frame expires instead of unbounded retry')
            with NativeAdapter(h.binary,path,h.logs/'receive-pressure.stderr.txt',
                    arguments(path,queue_bytes=2048,queue_frames=1)) as a:
                a.hello();first=b'first-receive';second=b'second-receive'
                write_all(m,wire(first)+wire(second),7);time.sleep(.08)
                h.check(a.received()==first,'first complete receive frame occupies the one-record queue')
                status,payload=a.request(5)
                h.check(status==1 and not payload,'overflowed receive frame is dropped whole, not partially admitted')
                write_all(m,wire(second),7)
                h.check(a.received()==second,'finite-service retransmission can refill the released queue')
            with NativeAdapter(h.binary,path,h.logs/'hangup.stderr.txt') as a:
                a.hello();os.close(m);m=-1
                h.check(a.p.wait(timeout=3)!=0,'PTY hangup retires adapter')
        finally:
            if m>=0:os.close(m)
            os.close(s)
    case('queue_pressure_expiry_and_device_hangup',pressure)

    def lifecycle():
        links=[PtyLink(),PtyLink()]
        # a-out <-> b-in; b-out <-> a-in. A also retains an ordinary TCP route
        # to C so physical-model replacement cannot stall unrelated carriers.
        paths={'a-out':links[0].paths[0],'b-in':links[0].paths[1],
               'b-out':links[1].paths[0],'a-in':links[1].paths[1]}
        astate,bstate,cstate=h.runtime/'serial-a',h.runtime/'serial-b',h.runtime/'serial-c'
        ps={};es={};a=b=c=None
        try:
            for name,path in paths.items():
                ps[name]=image_profile(name,h.binary,arguments(path))
                es[name]=endpoint(ps[name],identifier=name,role='listener' if name.endswith('in') else 'route')
            cport=free_port()
            ac=h.config('serial-a','A',astate,free_port(),
                [('B',free_port(),150,500,100,180000),('C',cport,150,500,100,180000)],deadline_ms=4000)
            bc=h.config('serial-b','B',bstate,free_port(),[('A',free_port(),150,500,100,180000)],deadline_ms=4000)
            cc=h.config('serial-c','C',cstate,cport,[],deadline_ms=4000,trusted=['A'])
            for node,cfg,remote in [('a',ac,'B'),('b',bc,'A')]:
                text=upgrade(cfg.read_text(),node+'-serial');lines=[]
                for line in text.splitlines():
                    if line.startswith('listen='):line='listen='+ref(node+'-in')
                    if line.startswith('peer_route='+remote+','):
                        line=','.join(line.split(',')[:4])+','+ref(node+'-out')
                    lines.append(line)
                write(cfg,'\n'.join(lines)+'\n'+records(
                    [ps[node+'-in'],ps[node+'-out']],[es[node+'-in'],es[node+'-out']])+\
                    'session_max_operations=32\nsession_idle_timeout_ms=2000\n')
                h.run('serial-config-'+node,['config-check','--config',str(cfg)])
            cc.write_text(cc.read_text()+'session_max_operations=32\nsession_idle_timeout_ms=2000\n')
            c=h.start('serial-c',cc,cstate);b=h.start('serial-b',bc,bstate);a=h.start('serial-a',ac,astate)
            first,reverse=operation('serial-first'),operation('serial-reverse')
            submit(h,'serial-first',a.control,'A','B','test/three',first,'NSP1-'+('x'*8000))
            s1=wait_entry(h,astate,first,timeout=55);assert_receipt(h,astate,first,'B')
            h.check(h.status('serial-admissions',bstate)['inbound_records']==1,
                'wire duplication and reordering do not duplicate durable admission')
            children=owned_children(a)
            matches=[pid for pid,args in children if any(
                arg.startswith(b'serial-v1|path='+paths['a-out'].encode()+b'|') for arg in args)]
            h.check(bool(matches),'owned pinned same-binary route adapter observed')
            old_open=peer(s1,'B')['session']['opened'];killed=matches[-1];os.kill(killed,signal.SIGKILL)
            second=operation('serial-after-death')
            submit(h,'serial-after-death',a.control,'A','B','test/three',second,'fresh authenticated session')
            s2=wait_entry(h,astate,second,timeout=45);assert_receipt(h,astate,second,'B')
            h.check(peer(s2,'B')['session']['opened']>old_open,'adapter death requires fresh TLS/HELLO')
            h.check(any(pid!=killed and any(
                arg.startswith(b'serial-v1|path='+paths['a-out'].encode()+b'|') for arg in args)
                for pid,args in owned_children(a)),'new supervised route child is present')
            submit(h,'serial-reverse',b.control,'B','A','test/three',reverse,'reverse-'+('y'*8000))
            wait_entry(h,bstate,reverse,timeout=55);assert_receipt(h,bstate,reverse,'A')
            required={'DROP','CORRUPT','DUPLICATE','DELAY','TRUNCATE','NOISE','REORDER'}
            h.check(all({e['action'] for e in link.events} >= required for link in links),
                'all declared byte-stream fault classes, including frame reordering, exercised')

            # Replace the actual route-side PTY. The opposite listener device
            # remains open. A new exact profile and endpoint generation is the
            # only authority by which the node may use the replacement path.
            old_path=paths['a-out'];new_path=links[0].replace_side(0);paths['a-out']=new_path
            h.check(new_path!=old_path and links[0].replacements[-1]['old_path']==old_path,
                'fixture replaced the actual PTY pathname rather than mutating an in-memory locator')
            listener_children=[pid for pid,args in owned_children(b) if any(
                arg.startswith(b'serial-v1|path='+paths['b-in'].encode()+b'|') for arg in args)]
            h.check(len(listener_children)<=1,'single-lease listener owns at most one live adapter child')
            # A completed inbound session may already have retired its listener
            # child under sanitizer scheduling. Kill it when still observable;
            # either way the replacement operation below must authenticate on
            # a newly constructed carrier.
            for pid in listener_children:os.kill(pid,signal.SIGKILL)

            # The unrelated TCP peer progresses while the serial carrier is
            # disconnected and before replacement policy is activated.
            mixed=operation('mixed-tcp-progress')
            submit(h,'mixed-tcp-progress',a.control,'A','C','test/three',mixed,
                'unrelated TCP route progresses during serial replacement')
            wait_entry(h,astate,mixed,timeout=20);assert_receipt(h,astate,mixed,'C')
            h.check(h.status('mixed-c-admissions',cstate)['inbound_records']==1,
                'mixed TCP carrier admitted exactly once while serial route was unavailable')

            p2=image_profile('a-out',h.binary,arguments(new_path),2,digest(ps['a-out']))
            e2=endpoint(p2,identifier='a-out',generation=2,previous=digest(es['a-out']))
            successor=candidate(h,ac,'serial-a-out-successor','serial-a-out-successor',
                lambda text:text.replace(ref('a-out'),ref('a-out',2))+records([p2],[e2]))
            activated=activate(h,'authorize-serial-pty-successor',astate,successor)
            h.check(activated.get('ok') is True,'owner authorized exact profile and endpoint succession')
            replacement=operation('serial-after-pty-replacement')
            submit(h,'serial-after-pty-replacement',a.control,'A','B','test/three',replacement,
                'new physical-model device and fresh authenticated session')
            sr=wait_entry(h,astate,replacement,timeout=55);assert_receipt(h,astate,replacement,'B')
            h.check(sr['runtime_configuration']['generation']=='serial-a-out-successor',
                'active immutable generation names exact replacement authority')
            h.check(peer(sr,'B')['session']['opened']>peer(s2,'B')['session']['opened'],
                'replacement device requires a fresh TLS/HELLO session')
            def replacement_child():
                return any(any(arg.startswith(b'serial-v1|path='+new_path.encode()+b'|') for arg in args)
                    for _,args in owned_children(a))
            h.wait('replacement route child',replacement_child,8)
            h.check(not any(any(arg.startswith(b'serial-v1|path='+old_path.encode()+b'|') for arg in args)
                for _,args in owned_children(a)),'retired path is not reused after exact succession')

            b.shutdown();pending=operation('serial-pending')
            submit(h,'serial-pending',a.control,'A','B','test/three',pending,'durable across serial outage')
            h.check(outbox_entry(h.status('serial-pending-before-stop',astate),pending)['status']=='PENDING',
                'absent physical-model peer leaves obligation pending')
            a.shutdown();a=h.start('serial-a-restart',ac,astate);b=h.start('serial-b-restart',bc,bstate)
            recovered=wait_entry(h,astate,pending,timeout=55);assert_receipt(h,astate,pending,'B')
            h.check(recovered['runtime_configuration']['generation']=='serial-a-out-successor',
                'stale startup seed cannot roll back authorized replacement device')
            h.check(h.status('serial-restarted-admissions',bstate)['inbound_records']==4,
                'four distinct A-to-B operations admitted exactly once across replacement and restart')
            a.shutdown();b.shutdown();c.shutdown()
            h.check(not owned_children(a) and not owned_children(b),'owned children retired after orderly stop')
        finally:
            for d in [a,b,c]:
                if d and d.process.poll() is None:d.shutdown()
            for link in links:link.close()
            evidence={'format':'NATRAV_SERIAL_MODEL_EVIDENCE_V1',
                'events':[l.events for l in links],
                'replacements':[l.replacements for l in links],
                'low_baud':{'baud':1200,'mtu':256,'minimum_frame_time_ms':minimum_line_time_ms(256,1200)}}
            (h.output/'PTY-ADVERSITY.json').write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
    case('two_pinned_nodes_over_adverse_ptys',lifecycle)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case');args=p.parse_args()
    if args.output.exists():p.error('output must not exist')
    h=Harness(args.binary,args.output);start=time.monotonic();rc=1
    try:
        suite(h,args.case)
        if not h.cases:raise ValueError('no case selected')
        rc=0
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {type(e).__name__}: {e}',file=sys.stderr)
    finally:
        h.cleanup()
        summary={'format':'NATRAV_SERIAL_PACKET_ADAPTER_TESTS_V1','status':'PASS' if rc==0 else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.monotonic()-start}
        for name,obj in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:
            (h.output/(name+'.json')).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary))
    return rc
if __name__=='__main__':raise SystemExit(main())
