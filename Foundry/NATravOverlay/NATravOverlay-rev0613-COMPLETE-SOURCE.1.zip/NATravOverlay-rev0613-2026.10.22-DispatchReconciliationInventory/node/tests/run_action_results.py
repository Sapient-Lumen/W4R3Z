#!/usr/bin/env python3
"""Durable counter-action result return through the ordinary authenticated outbox."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import struct
import time
from typing import Any, Callable

from run_persistent import Harness, free_port, operation

OWNER = ["INSPECT", "SUBMIT", "ACTION", "MAINTENANCE", "CONFIGURATION", "SHUTDOWN"]
RESULT_SCOPE = "results/counter"


def config(
    h: Harness,
    name: str,
    node: str,
    state: Path,
    port: int,
    peer: str,
    peer_port: int,
    *,
    receive_action: bool,
    allow_result: bool,
    read_results: bool = False,
    action_expiry_ms: int = 60_000,
) -> Path:
    local = h.identity(node)
    remote = h.identity(peer)
    classes = OWNER + (["EVIDENCE_READ", "EVIDENCE_PAYLOAD"] if read_results else [])
    lines = [
        "NATRAV_OVERLAY_CONFIG_V18",
        f"runtime_generation={name}-g1",
        f"node={node}",
        f"state={state}",
        f"listen=127.0.0.1:{port}",
        "control=control.sock",
        f"identity_cert={local.certificate}",
        f"identity_key={local.private_key}",
        f"identity_pin={local.spki_sha256}",
        f"identity_generation={node.lower()}-g1",
        "deadline_ms=1500",
        "peer_workers=4",
        "peer_queue_capacity=64",
        "control_workers=4",
        "control_queue_capacity=64",
        "outbox_global_max_records=256",
        "outbox_global_max_payload_bytes=16777216",
        "outbox_peer_max_records=128",
        "outbox_peer_max_payload_bytes=8388608",
        "action_counter_budget=1000",
        "action_max_increment=100",
        "action_max_defer_ms=30000",
        f"action_expiry_ms={action_expiry_ms}",
        f"local_control={os.geteuid()},{','.join(classes)}",
        f"peer={peer},50,250,50,120000",
        f"peer_route={peer},primary,0,ENABLED,127.0.0.1:{peer_port}",
        f"peer_key={peer},{peer.lower()}-g1,ACTIVE,{remote.spki_sha256}",
    ]
    if receive_action:
        lines.append(f"authorize={peer},{peer.lower()}-g1,ACTION,counter.add")
        if allow_result:
            lines.append(
                f"action_result={peer},{peer.lower()}-g1,counter.add,{RESULT_SCOPE}"
            )
    else:
        lines.append(f"authorize={peer},{peer.lower()}-g1,EVIDENCE,{RESULT_SCOPE}")
    if read_results:
        lines.append(f"evidence_read={os.geteuid()},{peer},{RESULT_SCOPE},PAYLOAD")
    path = h.work / f"{name}.conf"
    path.write_text("\n".join(lines) + "\n")
    path.chmod(0o600)
    return path


def action_query(h: Harness, label: str, state: Path, action_id: str) -> dict[str, Any]:
    value = h.run(label, [
        "action-query", "--control", str(state / "control.sock"),
        "--action", action_id, "--max-bytes", "60000", "--deadline-ms", "5000",
    ])
    assert value is not None
    h.check(value["format"] == "NATRAV_OVERLAY_ACTION_QUERY_V1", "versioned action query")
    h.check(len(value["records"]) == 1, "exact action query returns one row")
    return value["records"][0]


def outbox_query(h: Harness, label: str, state: Path, operation_id: str) -> dict[str, Any]:
    value = h.run(label, [
        "outbox-query", "--control", str(state / "control.sock"),
        "--operation", operation_id, "--history-limit", "16",
        "--max-bytes", "60000", "--deadline-ms", "5000",
    ])
    assert value is not None
    h.check(value["format"] == "NATRAV_OVERLAY_OUTBOX_QUERY_V1", "versioned outbox query")
    h.check(len(value["records"]) == 1, "exact outbox query returns one row")
    return value["records"][0]


def evidence_query(h: Harness, label: str, state: Path, operation_id: str) -> dict[str, Any]:
    value = h.run(label, [
        "evidence-query", "--control", str(state / "control.sock"),
        "--view", "history", "--operation", operation_id,
        "--payload", "yes", "--payload-length", "16384",
        "--max-bytes", "60000", "--deadline-ms", "5000",
    ])
    assert value is not None
    h.check(len(value["records"]) == 1, "result evidence is admitted once")
    return value["records"][0]


def decode_nac1(payload: bytes) -> dict[str, Any]:
    at = 0
    def take(size: int) -> bytes:
        nonlocal at
        if at + size > len(payload):
            raise AssertionError("truncated NAC1 payload")
        value = payload[at:at+size]
        at += size
        return value
    def u8() -> int: return take(1)[0]
    def u16() -> int: return struct.unpack("!H", take(2))[0]
    def u32() -> int: return struct.unpack("!I", take(4))[0]
    def u64() -> int: return struct.unpack("!Q", take(8))[0]
    def text16() -> str: return take(u16()).decode("ascii")
    def optional_u64() -> int | None: return u64() if u8() else None
    def optional_digest() -> str | None: return take(32).hex() if u8() else None

    if take(4) != b"NAC1":
        raise AssertionError("unknown action-result payload")
    result = {
        "outcome": u8(),
        "action_id": take(32).hex(),
        "source_record_digest": take(32).hex(),
        "source_sequence": u64(),
        "source_policy_digest": take(32).hex(),
        "source_rule_digest": take(32).hex(),
        "source_decided_unix_ms": u64(),
        "result_policy_digest": take(32).hex(),
        "result_rule_digest": take(32).hex(),
        "configuration_event": u64(),
        "scope": text16(),
        "peer_generation": text16(),
        "peer_spki_sha256": take(32).hex(),
        "amount": u64(),
        "admitted_unix_ms": u64(),
        "terminal_unix_ms": u64(),
        "attempts": u32(),
        "last_started_unix_ms": optional_u64(),
        "local_receipt_digest": optional_digest(),
        "counter_before": optional_u64(),
        "counter_after": optional_u64(),
        "reason_bytes": u16(),
        "reason_digest": take(32).hex(),
    }
    if at != len(payload):
        raise AssertionError("trailing NAC1 material")
    return result


def submit_action(h: Harness, label: str, state: Path, action_id: str,
                  amount: int, defer_ms: int = 0) -> dict[str, Any]:
    value = h.run(label, [
        "action-submit", "--control", str(state / "control.sock"),
        "--node", "A", "--peer", "B", "--operation", action_id,
        "--amount", str(amount), "--defer-ms", str(defer_ms),
        "--deadline-ms", "5000",
    ])
    assert value is not None
    return value


def wait_action(h: Harness, label: str, state: Path, action_id: str,
                expected: str, timeout: float = 12.0) -> dict[str, Any]:
    saved: dict[str, Any] = {}
    def done() -> bool:
        saved.clear()
        saved.update(action_query(h, label, state, action_id))
        return saved["status"] == expected
    h.wait(label + "-wait", done, timeout=timeout)
    return saved


def wait_outbox(h: Harness, label: str, state: Path, operation_id: str,
                expected: str, timeout: float = 12.0) -> dict[str, Any]:
    saved: dict[str, Any] = {}
    def done() -> bool:
        saved.clear()
        saved.update(outbox_query(h, label, state, operation_id))
        return saved["status"] == expected
    h.wait(label + "-wait", done, timeout=timeout)
    return saved


def run_cases(h: Harness, selected: set[str] | None = None) -> None:
    def case(name: str, function: Callable[[], None]) -> None:
        if selected is None or name in selected:
            h.case(name, function)

    def strict_v18_policy() -> None:
        root = h.runtime / "strict"
        root.mkdir()
        ap, bp = free_port(), free_port()
        a = config(h, "strict-a", "A", root / "a", ap, "B", bp,
                   receive_action=False, allow_result=False, read_results=True)
        b = config(h, "strict-b", "B", root / "b", bp, "A", ap,
                   receive_action=True, allow_result=True)
        checked = h.run("strict-v18-config", ["config-check", "--config", str(b)])
        assert checked is not None
        h.check(checked["format"] == "NATRAV_OVERLAY_CONFIG_V18", "V18 reported")
        h.check(len(checked["action_result_policy"]["rules"]) == 1,
                "one exact action-result rule retained")
        h.check(checked["action_result_policy"]["rules"][0]["scope"] == RESULT_SCOPE,
                "result scope reported")

        missing = config(h, "strict-b-missing", "B", root / "missing", bp,
                         "A", ap, receive_action=True, allow_result=False)
        ad = h.start("strict-a", a, root / "a")
        bd = h.start("strict-b-missing", missing, root / "missing")
        action_id = operation("strict-missing-result-rule")
        submit_action(h, "strict-submit", root / "a", action_id, 3)
        rejected = wait_outbox(h, "strict-rejected", root / "a", action_id, "REJECTED")
        h.check(rejected["active_rejection"]["error_code"] == "ACTION_RESULT_POLICY_REQUIRED",
                "V18 action without result disclosure policy is terminally rejected")
        bd.shutdown(); ad.shutdown()

    case("strict_v18_result_policy_and_missing_rule_rejection", strict_v18_policy)

    def execution_and_cancellation() -> None:
        root = h.runtime / "pipeline"
        root.mkdir()
        ap, bp = free_port(), free_port()
        a_conf = config(h, "pipeline-a", "A", root / "a", ap, "B", bp,
                        receive_action=False, allow_result=False, read_results=True)
        b_conf = config(h, "pipeline-b", "B", root / "b", bp, "A", ap,
                        receive_action=True, allow_result=True)
        a = h.start("pipeline-a", a_conf, root / "a")
        b = h.start("pipeline-b", b_conf, root / "b")

        executed_id = operation("action-result-executed")
        submit_action(h, "action-result-submit-executed", root / "a", executed_id, 7)
        executed = wait_action(h, "action-result-executed", root / "b", executed_id, "EXECUTED")
        result = executed["action_result"]
        h.check(result["configured"] is True and result["terminal_outcome"] == "EXECUTED",
                "executed action exposes durable result binding")
        result_operation = result["operation_id"]
        assert isinstance(result_operation, str)
        result_outbox = wait_outbox(h, "action-result-executed-outbox", root / "b",
                                    result_operation, "ACKED")
        h.check(result_outbox["association"]["kind"] == "ACTION_RESULT",
                "result outbox is associated with its source action")
        record = evidence_query(h, "action-result-executed-evidence", root / "a",
                                result_operation)
        decoded = decode_nac1(bytes.fromhex(record["payload_hex"]))
        h.check(record["issuer"] == "B" and record["recipient"] == "A" and
                record["scope"] == RESULT_SCOPE, "result is ordinary recipient-scoped evidence")
        h.check(decoded["outcome"] == 1 and decoded["action_id"] == executed_id,
                "NAC1 binds executed source action")
        h.check(decoded["amount"] == 7 and decoded["counter_before"] == 0 and
                decoded["counter_after"] == 7, "executed result carries exact local counter effect")
        h.check(decoded["local_receipt_digest"] == executed["result"]["receipt_digest"],
                "NAC1 carries the local effect receipt")
        h.check(decoded["reason_bytes"] == 0, "executed result carries no free-form reason")

        cancelled_id = operation("action-result-cancelled")
        submit_action(h, "action-result-submit-cancelled", root / "a", cancelled_id, 9, 20_000)
        wait_action(h, "action-result-cancelled-pending", root / "b", cancelled_id, "PENDING")
        cancel_reason = "private operator cancellation reason"
        cancelled_response = h.run("action-result-cancel", [
            "action-cancel", "--control", str(root / "b" / "control.sock"),
            "--action", cancelled_id, "--reason", cancel_reason,
            "--deadline-ms", "5000",
        ])
        assert cancelled_response is not None
        cancelled = wait_action(h, "action-result-cancelled", root / "b", cancelled_id, "CANCELLED")
        cancel_result_op = cancelled["action_result"]["operation_id"]
        assert isinstance(cancel_result_op, str)
        wait_outbox(h, "action-result-cancelled-outbox", root / "b", cancel_result_op, "ACKED")
        cancel_record = evidence_query(h, "action-result-cancelled-evidence", root / "a",
                                       cancel_result_op)
        cancel_payload = bytes.fromhex(cancel_record["payload_hex"])
        cancel_decoded = decode_nac1(cancel_payload)
        h.check(cancel_decoded["outcome"] == 2 and cancel_decoded["action_id"] == cancelled_id,
                "cancelled action returns a distinct terminal outcome")
        h.check(cancel_decoded["counter_before"] is None and cancel_decoded["counter_after"] is None,
                "cancelled result does not fabricate a local counter effect")
        h.check(cancel_decoded["reason_bytes"] == len(cancel_reason.encode()) and
                cancel_reason.encode() not in cancel_payload,
                "remote result commits to but does not disclose free-form reason text")

        # Compaction must reconstruct both the action-result sidecar and its
        # ordinary outbox association from canonical state.
        h.run("action-result-compact", ["compact", "--control", str(root / "b" / "control.sock"),
                                        "--deadline-ms", "10000"], timeout=20)
        b.shutdown()
        b = h.start("pipeline-b-restarted", b_conf, root / "b")
        restored = action_query(h, "action-result-restored-action", root / "b", executed_id)
        h.check(restored["action_result"]["operation_id"] == result_operation and
                restored["action_result"]["terminal_outcome"] == "EXECUTED",
                "checkpoint reconstructs terminal action-result binding")
        restored_outbox = outbox_query(h, "action-result-restored-outbox", root / "b",
                                       result_operation)
        h.check(restored_outbox["association"]["kind"] == "ACTION_RESULT" and
                restored_outbox["status"] == "ACKED",
                "checkpoint reconstructs result outbox association and receipt")
        (h.output / "PIPELINE.json").write_text(json.dumps({
            "executed": decoded,
            "cancelled": cancel_decoded,
            "executed_outbox": result_outbox,
            "cancelled_action": cancelled,
            "restored_action": restored,
        }, indent=2, sort_keys=True) + "\n")
        b.shutdown(); a.shutdown()

    case("atomic_executed_and_cancelled_results_survive_compaction", execution_and_cancellation)

    def result_outbox_quota_waits_without_worker_failure() -> None:
        root = h.runtime / "quota"
        root.mkdir()
        ap, bp, cp = free_port(), free_port(), free_port()
        a_conf = config(h, "quota-a", "A", root / "a", ap, "B", bp,
                        receive_action=False, allow_result=False, read_results=True)
        b_conf = config(h, "quota-b", "B", root / "b", bp, "A", ap,
                        receive_action=True, allow_result=True)
        c_identity = h.identity("C")
        text = b_conf.read_text()
        text = text.replace("outbox_global_max_records=256",
                            "outbox_global_max_records=1")
        text = text.replace("outbox_peer_max_records=128",
                            "outbox_peer_max_records=1")
        text += (
            f"peer=C,50,250,50,120000\n"
            f"peer_route=C,primary,0,DISABLED,127.0.0.1:{cp}\n"
            f"peer_key=C,c-g1,ACTIVE,{c_identity.spki_sha256}\n"
        )
        b_conf.write_text(text)
        b_conf.chmod(0o600)

        a = h.start("quota-a", a_conf, root / "a")
        b = h.start("quota-b", b_conf, root / "b")
        blocker = operation("action-result-quota-blocker")
        queued = h.run("action-result-quota-fill", [
            "submit", "--control", str(root / "b" / "control.sock"),
            "--node", "B", "--peer", "C", "--scope", "test/blocker",
            "--operation", blocker, "--payload-text", "x",
            "--deadline-ms", "5000",
        ])
        assert queued is not None
        h.check(queued["status"] == "PENDING",
                "disabled route retains the one-record blocker")

        action_id = operation("action-result-waits-for-outbox-capacity")
        submit_action(h, "action-result-quota-submit", root / "a", action_id, 13)
        time.sleep(0.6)
        pending = h.run("action-result-quota-unadmitted", [
            "action-query", "--control", str(root / "b" / "control.sock"),
            "--action", action_id, "--deadline-ms", "5000"])
        h.check(pending is not None and pending["records"] == [],
                "new V18 action reserves before admission; a full outbox cannot admit it")
        status = h.run("action-result-quota-daemon-alive", [
            "status", "--control", str(root / "b" / "control.sock"),
            "--deadline-ms", "5000",
        ])
        assert status is not None
        h.check(status["actions"]["pending"] == 0 and
                status["actions"]["counter_value"] == 0,
                "quota pressure neither kills the daemon nor applies the effect early")

        h.run("action-result-quota-release", [
            "cancel", "--control", str(root / "b" / "control.sock"),
            "--operation", blocker, "--reason", "release result capacity",
            "--deadline-ms", "5000",
        ])
        executed = wait_action(h, "action-result-quota-executed", root / "b",
                               action_id, "EXECUTED")
        h.check(executed["attempts"] == 1 and
                executed["result"]["counter_after"] == 13,
                "capacity release commits the original begun attempt exactly once")
        result_operation = executed["action_result"]["operation_id"]
        assert isinstance(result_operation, str)
        wait_outbox(h, "action-result-quota-result", root / "b",
                    result_operation, "ACKED")
        result_record = evidence_query(h, "action-result-quota-evidence", root / "a",
                                       result_operation)
        decoded = decode_nac1(bytes.fromhex(result_record["payload_hex"]))
        h.check(decoded["counter_before"] == 0 and decoded["counter_after"] == 13,
                "released result carries the one committed local effect")
        (h.output / "QUOTA.json").write_text(json.dumps({
            "pending": pending,
            "executed": executed,
            "result": decoded,
        }, indent=2, sort_keys=True) + "\n")
        b.shutdown(); a.shutdown()

    case("result_outbox_quota_waits_without_worker_failure",
         result_outbox_quota_waits_without_worker_failure)

    def expired_result_is_returned() -> None:
        root = h.runtime / "expiry"
        root.mkdir()
        ap, bp = free_port(), free_port()
        a_conf = config(h, "expiry-a", "A", root / "a", ap, "B", bp,
                        receive_action=False, allow_result=False, read_results=True)
        b_conf = config(h, "expiry-b", "B", root / "b", bp, "A", ap,
                        receive_action=True, allow_result=True,
                        action_expiry_ms=700)
        a = h.start("expiry-a", a_conf, root / "a")
        b = h.start("expiry-b", b_conf, root / "b", environment={
            "NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS": "1000",
        })
        blocker = operation("action-result-expiry-worker-blocker")
        submit_action(h, "action-result-expiry-blocker", root / "a", blocker, 1)
        def blocker_begun() -> bool:
            row = action_query(h, "action-result-expiry-blocker-begun", root / "b", blocker)
            return row["status"] == "PENDING" and row["attempts"] == 1
        h.wait("action-result-expiry-blocker-started", blocker_begun, timeout=5)

        expired_id = operation("action-result-expired")
        submit_action(h, "action-result-expiry-submit", root / "a", expired_id, 5)
        expired = wait_action(h, "action-result-expired", root / "b", expired_id,
                              "EXPIRED", timeout=8)
        h.check(expired["attempts"] == 0 and
                expired["action_result"]["terminal_outcome"] == "EXPIRED",
                "unbegun expired action returns an explicit terminal result")
        result_operation = expired["action_result"]["operation_id"]
        assert isinstance(result_operation, str)
        wait_outbox(h, "action-result-expired-outbox", root / "b",
                    result_operation, "ACKED")
        result_record = evidence_query(h, "action-result-expired-evidence", root / "a",
                                       result_operation)
        decoded = decode_nac1(bytes.fromhex(result_record["payload_hex"]))
        h.check(decoded["outcome"] == 3 and decoded["attempts"] == 0 and
                decoded["counter_before"] is None and
                decoded["counter_after"] is None,
                "expired NAC1 does not fabricate an attempted counter effect")
        h.check(decoded["reason_bytes"] == len("ACTION_DEADLINE_ELAPSED"),
                "expired NAC1 commits to the typed scheduler reason")
        blocker_done = wait_action(h, "action-result-expiry-blocker-done", root / "b",
                                   blocker, "EXECUTED", timeout=8)
        h.check(blocker_done["result"]["counter_after"] == 1,
                "begun predecessor retains its bounded execution semantics")
        (h.output / "EXPIRY.json").write_text(json.dumps({
            "expired": expired,
            "result": decoded,
            "blocker": blocker_done,
        }, indent=2, sort_keys=True) + "\n")
        b.shutdown(); a.shutdown()

    case("expired_result_is_returned", expired_result_is_returned)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not exist")
    h = Harness(args.binary, args.output)
    started = time.time()
    ok = False
    try:
        run_cases(h, set(args.case) if args.case else None)
        if not h.cases:
            raise ValueError("no selected cases")
        ok = True
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {exc}", file=os.sys.stderr)
    finally:
        h.cleanup()
        summary = {
            "format": "NATRAV_ACTION_RESULT_TESTS_V1",
            "status": "PASS" if ok else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "cases_total": len(h.cases),
            "cases_passed": sum(item["status"] == "PASS" for item in h.cases),
            "assertions": h.assertions,
            "commands": len(h.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (("SUMMARY", summary), ("CASES", h.cases), ("COMMANDS", h.commands)):
            (h.output / f"{name}.json").write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary), flush=True)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
