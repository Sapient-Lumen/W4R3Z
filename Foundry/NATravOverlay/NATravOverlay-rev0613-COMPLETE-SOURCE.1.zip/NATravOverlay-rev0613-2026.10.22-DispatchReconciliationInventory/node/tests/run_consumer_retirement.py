#!/usr/bin/env python3
"""Exact-owner terminal retirement: real C++ state, workers, UIDs and recovery."""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, struct, subprocess, time
from pathlib import Path
from run_persistent import Harness, free_port, raw_control
from run_projections import trio, config, create as create_projection, call as projection, read
from run_consumers import call as consumer, wire, PERMISSIONS
from run_numeric_projection import create as create_numeric, produce
from run_automatic_projections import enable, pause, wait_position, schedule
from run_local_administration import run_as_uid, expose_control_for_uid
from run_scoped_reads import UID, SECOND_UID
from run_live_configuration import candidate, activate
from run_state_authentication import new_key, migrate, start as start_keyed

REASON='explicitly retire obsolete application instance'

def call(h,label,b,name='summary',command='retirement-status',uid=None,expected=0,**kw):
    args=['consumer-'+command,'--control',str(b/'control.sock'),'--consumer',name,'--deadline-ms','4000']
    for k,v in kw.items():args+=['--'+k.replace('_','-'),str(v)]
    r=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    if expected==0:
        h.check(r['format']=='NATRAV_OVERLAY_CONSUMER_RETIREMENT_V1','explicit terminal-account format')
        h.check(r['consumer']['owner_uid']==(os.geteuid() if uid is None else uid),'actual kernel UID namespace')
    return r

def selection(account):
    c=account['consumer']
    return dict(instance=c['instance'],expected_revision=c['consumer_revision'],
                schedule_revision=c['schedule_revision'],pending='abandon' if c['pending_batch_id'] else 'require-empty',reason=REASON)

def retire(h,label,b,name='summary',uid=None,account=None,expected=0,**kw):
    a=account or call(h,label+'-observe',b,name,uid=uid)
    options=selection(a);options.update(kw)
    return call(h,label,b,name,'retire',uid,expected,**options)

def create(h,label,b,name,uid=None):
    return consumer(h,label,b,'create',name,uid=uid,issuer='A',scope='query/series',reason='bounded exact owner instance',limit=1)

def cases(h,selected=None):
    def case(name,fn):
        if selected is None or name in selected:h.case(name,fn)

    def strict():
        b=h.runtime/'strict-retire';cfg=config(h,'strict-retire',b,free_port());d=h.start('strict-retire',cfg,b)
        create(h,'create-first',b,'worker');a=call(h,'observe-first',b,'worker');opts=selection(a)
        h.check(retire(h,'wrong-instance',b,'worker',account=a,instance='12'*32,expected=3)['code']=='CONSUMER_RETIREMENT_CONFLICT','exact immutable instance required')
        h.check(retire(h,'wrong-revision',b,'worker',account=a,expected_revision=2,expected=3)['code']=='CONSUMER_RETIREMENT_CONFLICT','consumer revision required')
        h.check(retire(h,'wrong-schedule',b,'worker',account=a,schedule_revision=1,expected=3)['code']=='CONSUMER_RETIREMENT_CONFLICT','absent schedule revision is exactly zero')
        h.check(retire(h,'false-abandon',b,'worker',account=a,pending='abandon',expected=3)['code']=='CONSUMER_PENDING_DISPOSITION_REQUIRED','cannot invent abandoned page')
        reason=REASON.encode();tail=bytes.fromhex(opts['instance'])+struct.pack('!QQBH',opts['expected_revision'],0,0,len(reason))+reason
        body=wire(13,'worker',tail).replace(b'NCR1',b'NCR4')
        for bad in [body+b'x',body[:-1],body.replace(b'NCR4',b'NCR1'),wire(14,'worker')]:
            ok,err=raw_control(d.control,bad);h.check(not ok,'strict versioned retirement wire')
        for i in range(1,16):create(h,'fill-active-'+str(i),b,'worker'+str(i))
        h.check(consumer(h,'active-excess',b,'create','excess',expected=3,reason='capacity')['code']=='CONSUMER_LIMIT','active limit unchanged')
        ok,r=raw_control(d.control,body);h.check(ok and r['disposition']=='RETIRED','independent NCR4 retirement')
        h.check(r['owner_registry']['active']==15 and r['owner_registry']['retired']==1,'one active slot released, one tombstone charged')
        stable=(b/'state.journal').read_bytes()
        again=retire(h,'idempotent-retirement',b,'worker',account=a)
        h.check(again['disposition']=='ALREADY_RETIRED' and (b/'state.journal').read_bytes()==stable,'lost reply retry does not append or alter tombstone')
        create(h,'fresh-name-after-retire',b,'replacement')
        for cmd,kw in [('create',{'reason':'reuse forbidden'}),('read',{}),('ack',{'batch':'22'*32}),('reset',{'expected_revision':1,'start':'beginning','reason':'reset retired'})]:
            h.check(consumer(h,'retired-'+cmd,b,cmd,'worker',expected=3,**kw)['code']=='CONSUMER_RETIRED','legacy mutation never targets retired name')
        retired=consumer(h,'read-final-state',b,'status','worker')['consumer'];h.check(retired['lifecycle']=='RETIRED','authorized full final state remains inspectable')
        before=call(h,'before-checkpoint',b,'worker');h.run('retire-compact',['compact','--control',str(d.control)]);d.shutdown();d=h.start('retire-restart',cfg,b)
        after=call(h,'after-checkpoint',b,'worker');h.check(after['consumer']==before['consumer'] and after['owner_registry']==before['owner_registry'],'retirement and active capacity reconstruct exactly')
        d.shutdown()
    case('strict_selection_permanent_names_and_active_slot_reuse',strict)

    def pending():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'retire-pending');v={}
        produce(h,'pending-source',a,v,ticks=77);create_numeric(h,'pending-numeric',b,limit=1)
        issued=read(h,'pending-issued',b,'numeric')['consumer'];ob=call(h,'pending-observe',b,'numeric')
        h.check(retire(h,'pending-no-silent-loss',b,'numeric',account=ob,pending='require-empty',expected=3)['code']=='CONSUMER_PENDING_DISPOSITION_REQUIRED','issued page requires explicit abandonment')
        out=retire(h,'pending-explicit-abandon',b,'numeric',account=ob)
        final=h.run('pending-final',['projection-status','--control',str(bd.control),'--consumer','numeric'])['consumer']
        h.check(final['pending_batch']==issued['pending_batch'] and final['acknowledged_sequence']==0,'abandoned page retained, never acknowledged')
        h.check(final['projection']['result']==issued['projection']['result'] and final['projection']['definition_digest']==issued['projection']['definition_digest'],'unprocessed numeric result unchanged')
        h.check(out['consumer']['retirement']['pending_disposition']=='ABANDONED_UNACKNOWLEDGED','explicit loss disposition durable')
        for cmd,kw in [('process',{'batch':issued['pending_batch']['id']}),('rebuild',{'expected_revision':issued['revision'],'reason':'old request'}),('enable',{'expected_generation':0,'reason':'revive','max_pages':1})]:
            r=h.run('pending-old-'+cmd,['projection-'+cmd,'--control',str(bd.control),'--consumer','numeric']+sum((['--'+k.replace('_','-'),str(x)] for k,x in kw.items()),[]),expected=3)
            h.check(r['code']=='CONSUMER_RETIRED','stale projected command cannot revive retired instance')
        bd.shutdown();bd=h.start('pending-restart',bc,b)
        h.check(h.run('pending-replayed',['projection-status','--control',str(bd.control),'--consumer','numeric'])['consumer']==final,'pending abandonment and final result survive journal replay')
        (h.output/'PENDING-RETIREMENT.json').write_text(json.dumps({'issued':issued,'retired':final,'account':out},indent=2)+'\n')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('pending_page_abandonment_preserves_unacknowledged_result',pending)

    def workers():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'retire-workers');v={}
        create_numeric(h,'running-numeric',b,limit=1);create_projection(h,'unaffected-summary',b,limit=1)
        enable(h,'running-enable',b,'numeric',max_pages=100,min_interval_ms=10);enable(h,'unaffected-enable',b,max_pages=100,min_interval_ms=10)
        produce(h,'running-first',a,v,ticks=125);wait_position(h,b,'numeric',1);wait_position(h,b,'summary',1)
        observed=call(h,'before-owner-race',b,'numeric')
        # New work can win the same state mutex; stale observed revisions then
        # fail instead of silently choosing a new frontier.
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            job=pool.submit(produce,h,'running-race',a,v,ticks=5)
            args=['consumer-retire','--control',str(bd.control),'--consumer','numeric','--deadline-ms','4000']
            for k,x in selection(observed).items():args+=['--'+k.replace('_','-'),str(x)]
            raw=subprocess.run([str(h.binary),*args],capture_output=True,text=True,timeout=8);job.result()
        h.check(raw.returncode in (0,3),'retirement races into one bounded result')
        r=json.loads(raw.stdout)
        if raw.returncode==3:
            h.check(r['code']=='CONSUMER_RETIREMENT_CONFLICT','only exact-version conflict accepted in race')
            wait_position(h,b,'numeric',2);r=retire(h,'race-reobserve',b,'numeric')
        h.check(r['disposition']=='RETIRED','race ends with explicit committed retirement')
        final=h.run('stopped-numeric-result',['projection-status','--control',str(bd.control),'--consumer','numeric'])['consumer']
        s=schedule(h,'retired-grant',b,name='numeric')['schedule'];h.check(s['active']['state']=='RETIRED' and s['last_transition']=='RETIRE','enabled grant stops in retirement commit')
        produce(h,'after-retirement-source',a,v,ticks=10);wait_position(h,b,'summary',3);time.sleep(.2)
        h.check(h.run('numeric-frozen',['projection-status','--control',str(bd.control),'--consumer','numeric'])['consumer']==final,'no source processing beyond terminal boundary')
        # Exact duplicate terminal requests are idempotent, concurrent callers
        # cannot append multiple retirement events.
        obs=call(h,'unaffected-retire-observe',b)
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            outcomes=list(pool.map(lambda i:retire(h,'concurrent-retire-'+str(i),b,account=obs),range(8)))
        h.check(sum(x['disposition']=='RETIRED' for x in outcomes)==1,'one concurrent retiring winner')
        h.check(sum(x['disposition']=='ALREADY_RETIRED' for x in outcomes)==7,'other callers receive exact durable terminal receipt')
        saved=(b/'state.journal').read_bytes();time.sleep(.6)
        h.check((b/'state.journal').read_bytes()==saved,'retired work never loops journal writes')
        bd.shutdown();bd=h.start('retired-workers-restart',bc,b);time.sleep(.15)
        h.check(schedule(h,'stopped-grant-replayed',b,name='numeric')['schedule']==s,'stopped grant reconstructed')
        (h.output/'WORKER-RETIREMENT.json').write_text(json.dumps({'result':final,'schedule':s,'race_returncode':raw.returncode},indent=2)+'\n')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('automatic_processing_race_and_unaffected_progress',workers)

    def principals():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'retire-owners',True);expose_control_for_uid(b)
        create_projection(h,'no-admin-owned',b,'same',uid=UID);create_projection(h,'admin-owned',b,'same',uid=SECOND_UID)
        h.check(call(h,'no-admin-status',b,'same',uid=UID,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','retirement metadata requires admin class')
        h.check(call(h,'other-owner-not-found',b,'same',expected=3)['code']=='CONSUMER_NOT_FOUND','name does not grant cross-UID access')
        ob=call(h,'admin-observe',b,'same',uid=SECOND_UID)
        changed=candidate(h,bc,'retire-after-revoke','retire-revoke-g2',lambda text:'\n'.join(line.replace(',PROJECTION','') if line.startswith(f'local_control={SECOND_UID},') else line for line in text.splitlines())+'\n')
        activate(h,'remove-processing-permission',b,changed)
        h.check(projection(h,'revoked-full-result',b,'status','same',uid=SECOND_UID,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','admin stop never bypasses result permission')
        out=retire(h,'retire-revoked',b,'same',uid=SECOND_UID,account=ob)
        h.check(out['consumer']['owner_uid']==SECOND_UID and 'projection' not in out['consumer'],'administrative terminal account contains no result')
        wrong=call(h,'other-uid-cannot-see-retirement',b,'same',uid=UID,expected=3);h.check(wrong['code']=='LOCAL_CONTROL_CLASS_DENIED','no privilege expansion')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('real_uid_ownership_and_retirement_after_revocation',principals)

    def kills():
        for phase in ('BEFORE','AFTER'):
            b=h.runtime/('retire-kill-'+phase);cfg=config(h,'retire-kill-'+phase,b,free_port())
            d=h.start('retire-kill-'+phase,cfg,b,environment={f'NATRAV_OVERLAY_TEST_RETIREMENT_{phase}_COMMIT_MS':'10000'})
            create_projection(h,'kill-create-'+phase,b);enable(h,'kill-enable-'+phase,b,max_pages=2,min_interval_ms=10)
            ob=call(h,'kill-observe-'+phase,b);args=['consumer-retire','--control',str(d.control),'--consumer','summary','--deadline-ms','15000']
            for k,x in selection(ob).items():args+=['--'+k.replace('_','-'),str(x)]
            proc=subprocess.Popen([str(h.binary),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            h.wait('real retirement commit boundary '+phase,lambda:f'TEST_RETIREMENT_{phase}_COMMIT_MS' in d.stderr_path.read_text())
            d.kill();proc.communicate(timeout=5)
            state=h.run('kill-inspect-'+phase,['inspect','--state',str(b),'--node','B']);item=state['consumers'][0]
            h.check(item['lifecycle']==('ACTIVE' if phase=='BEFORE' else 'RETIRED'),'commit decides whole terminal transition')
            grant=state['projection_schedules'][0]['active']
            h.check(grant['state']==('ENABLED' if phase=='BEFORE' else 'RETIRED'),'automatic stop inseparable from lifecycle')
            d=h.start('kill-restart-'+phase,cfg,b)
            out=retire(h,'kill-retry-'+phase,b,account=ob)
            h.check(out['disposition']==('RETIRED' if phase=='BEFORE' else 'ALREADY_RETIRED'),'lost response retried without second transition')
            d.shutdown()
    case('sigkill_before_and_after_atomic_retirement',kills)

    def maintenance():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'retire-maint');v={}
        produce(h,'maint-value',a,v,ticks=250);create_numeric(h,'maint-numeric',b,limit=1)
        enable(h,'maint-auto-enable',b,'numeric',max_pages=10,min_interval_ms=10);wait_position(h,b,'numeric',1)
        bd.shutdown();keys=h.runtime/'retire-keys';keys.mkdir(mode=0o700);key=new_key(h,keys,'retire-state');migrate(h,'retire-migrate',b,key,'B');bd=start_keyed(h,'retire-keyed',bc,b,key)
        out=retire(h,'retire-keyed-source',b,'numeric');final=h.run('keyed-final-result',['projection-status','--control',str(b/'control.sock'),'--consumer','numeric'])['consumer']
        create(h,'new-consumer-after-keyed-retire',b,'new-reader');bd.shutdown()
        h.check(h.run('audit-real-retirement-record',['state-auth-audit','--state',str(b),'--node','B','--state-auth-key',str(key)])['status']=='COMPLETE','new atomic kind accepted by authentication semantic replay')
        bd=start_keyed(h,'retired-keyed-restart',bc,b,key);h.run('retired-keyed-compact',['compact','--control',str(bd.control)]);bd.shutdown()
        identity=h.identities.identity('B');crypt=keys/'retire-backup.key';archive=keys/'retired.enc'
        h.run('retire-backup-key',['backup-key-init','--output',str(crypt),'--generation','retire-encryption'])
        h.run('retire-backup',['backup-export','--state',str(b),'--node','B','--generation','b-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'retire-restored'
        h.run('retire-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','B','--generation','b-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        before=h.run('retire-before-relocation',['inspect','--state',str(b),'--node','B','--state-auth-key',str(key)])
        after=h.run('retire-restored-offline',['inspect','--state',str(restored),'--node','B','--state-auth-key',str(key)])
        h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'full logical state equal across signed encrypted restore')
        moved=candidate(h,bc,'retired-relocation','retired-moved-g1',lambda s:s.replace(f'state={b}',f'state={restored}'))
        h.run('retire-relocate',['state-relocate','--state',str(restored),'--node','B','--candidate',str(moved),'--reason','relocate retired history','--state-auth-key',str(key)])
        bd=start_keyed(h,'retired-moved-start',moved,restored,key)
        h.check(h.run('retired-restored-result',['projection-status','--control',str(bd.control),'--consumer','numeric'])['consumer']==final,'final result and tombstone unchanged through restoration')
        produce(h,'new-value-after-restore',a,v,ticks=10);new=consumer(h,'new-consumer-continued',restored,'read','new-reader')
        h.check(new['returned_records']==1,'unrelated new consumer remains useful after restore')
        h.check(call(h,'restored-name-reserved',restored,'numeric')['consumer']['state']=='RETIRED','restored name never reusable')
        h.check(h.run('numeric-still-frozen',['projection-status','--control',str(bd.control),'--consumer','numeric'])['consumer']==final,'new source does not change retired result')
        (h.output/'RESTORED-RETIREMENT.json').write_text(json.dumps({'retirement':out,'final':final,'restored_digest':after['storage']['logical_state_digest']},indent=2)+'\n')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('keyed_audit_compaction_encrypted_restore_relocation',maintenance)

    def corruption():
        b=h.runtime/'retire-corrupt';cfg=config(h,'retire-corrupt',b,free_port());d=h.start('retire-corrupt',cfg,b)
        create_projection(h,'corrupt-create',b);enable(h,'corrupt-enable',b,max_pages=2,min_interval_ms=10);retire(h,'corrupt-retire',b);d.shutdown()
        journal=b/'state.journal';original=journal.read_bytes();frames=[];offset=0
        while offset<len(original):
            n=struct.unpack_from('!I',original,offset+4)[0];frames.append((offset,n,original[offset+8:offset+8+n]));offset+=40+n
        rec=[f for f in frames if f[2][0]==29];h.check(len(rec)==1,'one dedicated atomic retirement record')
        at,n,body=rec[0];body=bytearray(body);start=body.index(b'NCS3');base_len=struct.unpack_from('!I',body,start+4)[0];meta=start+8+base_len
        def forged(label,data):
            journal.write_bytes(original[:at+8]+data+hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+data).digest()+original[at+40+n:])
            h.check(h.run(label,['inspect','--state',str(b),'--node','B'],expected=3)['code']=='JOURNAL_CORRUPT','semantically forged retirement rejected despite fresh checksum')
        changed=body.copy();struct.pack_into('!Q',changed,meta,999);forged('retire-forged-revision',changed)
        changed=body.copy();changed[meta+37]^=1;forged('retire-forged-final-digest',changed)
        changed=body.copy();index=changed.rfind(b'RETIRED');h.check(index>meta,'terminal schedule in same record');changed[index:index+7]=b'ENABLED';forged('retire-running-schedule',changed)
        # A valid retirement record cannot be appended twice or replayed after
        # removing its prerequisite grant.
        journal.write_bytes(original+original[at:at+n+40]);h.run('retire-duplicated-record',['inspect','--state',str(b),'--node','B'],expected=3)
        grant=[f for f in frames if f[2][0]==28][0];g,gn,_=grant
        journal.write_bytes(original[:g]+original[g+gn+40:]);h.run('retire-deleted-grant',['inspect','--state',str(b),'--node','B'],expected=3)
        journal.write_bytes(original);d=h.start('retire-valid-restart',cfg,b);h.run('retire-corrupt-compact',['compact','--control',str(d.control)]);d.shutdown()
        compact=journal.read_bytes();n=struct.unpack_from('!I',compact,4)[0];body=bytearray(compact[8:8+n]);i=body.index(b'NCS3');base_len=struct.unpack_from('!I',body,i+4)[0]
        body[i+8+base_len+37]^=1
        journal.write_bytes(compact[:8]+body+hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest()+compact[n+40:]);h.run('retire-forged-checkpoint',['inspect','--state',str(b),'--node','B'],expected=3)
        journal.write_bytes(compact)
    case('retirement_semantic_corruption_and_checkpoint',corruption)

    def capacity():
        b=h.runtime/'retire-capacity';cfg=config(h,'retire-capacity',b,free_port());uids=[os.geteuid(),65534,65533,65532,65531]
        cfg.write_text(cfg.read_text()+''.join(f'local_control={uid},EVIDENCE_READ,CONSUMER,CONSUMER_ADMIN\nevidence_read={uid},A,query/series,METADATA\n' for uid in uids[1:]))
        d=h.start('retire-capacity',cfg,b);expose_control_for_uid(b)
        for index,uid in enumerate(uids[:4]):
            u=None if uid==os.geteuid() else uid
            for i in range(64):
                create(h,f'archive-create-{index}-{i}',b,f'archived-{i}',uid=u)
                retire(h,f'archive-retire-{index}-{i}',b,f'archived-{i}',uid=u)
            create(h,f'live-after-archive-{index}',b,'still-active',uid=u)
            h.check(retire(h,f'archive-first-excess-{index}',b,'still-active',uid=u,expected=3)['code']=='CONSUMER_RETIREMENT_LIMIT','archive exhaustion refuses loss, keeps active instance')
            h.check(consumer(h,f'active-still-reads-{index}',b,'read','still-active',uid=u)['returned_records']==0,'archive limit does not disable existing consumers')
        # Fifth UID has no retired entries, isolating the global bound.
        create(h,'global-limit-create',b,'fifth-active',uid=uids[4])
        h.check(retire(h,'global-archive-excess',b,'fifth-active',uid=uids[4],expected=3)['code']=='CONSUMER_RETIREMENT_LIMIT','global 256 bound separate from per-owner 64')
        h.run('archive-capacity-compact',['compact','--control',str(d.control)]);d.shutdown();d=h.start('archive-capacity-restart',cfg,b);expose_control_for_uid(b)
        accounts=[call(h,'capacity-final-'+str(uid),b,'still-active',uid=None if uid==os.geteuid() else uid)['owner_registry'] for uid in uids[:4]]
        h.check(all(x['active']==1 and x['retired']==64 for x in accounts),'all 256 permanent tombstones reconstruct without consuming active quotas')
        (h.output/'RETIREMENT-CAPACITY.json').write_text(json.dumps({'retired':256,'active':5,'uids':uids,'accounts':accounts},indent=2)+'\n');d.shutdown()
    case('real_uid_archive_capacity_and_exhaustion',capacity)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);begin=time.time();passed=False
    try:cases(h,set(a.case) if a.case else None);passed=True
    except BaseException as e:(h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {type(e).__name__}: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();s={'format':'NATRAV_OVERLAY_CONSUMER_RETIREMENT_TESTS_V1','status':'PASS' if passed else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-begin}
        for name,value in [('SUMMARY',s),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
        print(json.dumps(s),flush=True)
    return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
