#!/usr/bin/env python3
"""Persistent C++ node integration, restart, scheduling, and control tests."""
from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import stat
import struct
import subprocess
import threading
import time
from typing import Any, Callable

from tls_test_support import IdentityFactory, TestIdentity


def operation(label: str) -> str:
    return hashlib.sha256(label.encode()).hexdigest()


_allocated_ports: set[int] = set()
_allocated_ports_lock = threading.Lock()


def free_port() -> int:
    """Return a process-unique loopback test port selected by the kernel.

    The socket must still be released before a daemon can bind it, so this does
    not claim to eliminate collisions with unrelated processes.  It does
    prevent one validation process from configuring two nodes with the same
    port after the kernel immediately recycles an ephemeral selection.
    """
    with _allocated_ports_lock:
        for _ in range(1024):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.bind(("127.0.0.1", 0))
                port = int(sock.getsockname()[1])
            if port not in _allocated_ports:
                _allocated_ports.add(port)
                return port
    raise RuntimeError("unable to allocate a distinct loopback test port")


def receive_exact(sock: socket.socket, size: int) -> bytes:
    chunks: list[bytes] = []
    remaining = size
    while remaining:
        chunk = sock.recv(remaining)
        if not chunk:
            raise AssertionError("unexpected EOF on control socket")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def raw_control(path: Path, payload: bytes) -> tuple[bool, dict[str, Any]]:
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
        sock.settimeout(3)
        sock.connect(str(path))
        sock.sendall(struct.pack(">I", len(payload)) + payload)
        sock.shutdown(socket.SHUT_WR)
        size = struct.unpack(">I", receive_exact(sock, 4))[0]
        response = receive_exact(sock, size)
    if len(response) < 6 or response[:4] != b"NOR1" or response[4] > 1:
        raise AssertionError(f"invalid control response: {response!r}")
    return response[4] == 0, json.loads(response[5:].decode())


class Harness:
    def __init__(self, binary: Path, output: Path):
        self.binary = binary.resolve()
        self.output = output.resolve()
        self.work = self.output / "work"
        self.logs = self.output / "logs"
        self.runtime = Path("/tmp") / f"natrav-overlay-0502-tests-{os.getpid()}"
        self.output.mkdir(parents=True)
        self.work.mkdir()
        self.logs.mkdir()
        if self.runtime.exists():
            shutil.rmtree(self.runtime)
        self.runtime.mkdir()
        self.identities = IdentityFactory(self.work / "identities")
        self.assertions = 0
        self.commands: list[dict[str, Any]] = []
        self.cases: list[dict[str, Any]] = []
        self.daemons: list[Daemon] = []

    def check(self, condition: bool, detail: str) -> None:
        self.assertions += 1
        if not condition:
            raise AssertionError(detail)

    def run(
        self,
        label: str,
        args: list[str],
        expected: int = 0,
        timeout: float = 10.0,
    ) -> dict[str, Any] | None:
        started = time.time()
        completed = subprocess.run(
            [str(self.binary), *args],
            text=True,
            capture_output=True,
            timeout=timeout,
            env=os.environ.copy(),
        )
        record = {
            "label": label,
            "args": args,
            "returncode": completed.returncode,
            "stdout": completed.stdout,
            "stderr": completed.stderr,
            "elapsed_seconds": time.time() - started,
        }
        self.commands.append(record)
        (self.logs / f"{len(self.commands):03d}-{label}.stdout.txt").write_text(completed.stdout)
        (self.logs / f"{len(self.commands):03d}-{label}.stderr.txt").write_text(completed.stderr)
        self.check(
            completed.returncode == expected,
            f"{label}: return {completed.returncode}, expected {expected}; "
            f"stdout={completed.stdout!r} stderr={completed.stderr!r}",
        )
        lines = [line for line in completed.stdout.splitlines() if line.strip()]
        if not lines:
            return None
        try:
            return json.loads(lines[-1])
        except json.JSONDecodeError as exc:
            raise AssertionError(f"{label}: invalid JSON: {lines[-1]!r}") from exc

    def case(self, name: str, function: Callable[[], None]) -> None:
        started = time.time()
        before = self.assertions
        try:
            function()
            status = "PASS"
        except BaseException:
            status = "FAIL"
            raise
        finally:
            self.cases.append(
                {
                    "name": name,
                    "status": status,
                    "assertions": self.assertions - before,
                    "elapsed_seconds": time.time() - started,
                }
            )

    def config(
        self,
        name: str,
        node: str,
        state: Path,
        port: int,
        peers: list[tuple[str, int, int, int, int, int]],
        deadline_ms: int = 300,
        trusted: list[str] | None = None,
    ) -> Path:
        path = self.work / f"{name}.conf"
        local_identity = self.identities.identity(node)
        lines = [
            "NATRAV_OVERLAY_CONFIG_V6",
            f"node={node}",
            f"state={state}",
            f"listen=127.0.0.1:{port}",
            "control=control.sock",
            f"identity_cert={local_identity.certificate}",
            f"identity_key={local_identity.private_key}",
            f"identity_pin={local_identity.spki_sha256}",
            f"identity_generation={node.lower()}-g1",
            f"deadline_ms={deadline_ms}",
            "peer_workers=4",
            "peer_queue_capacity=64",
            "control_workers=2",
            "control_queue_capacity=64",
        ]
        configured_keys: set[tuple[str, str]] = set()
        authorized_peers: set[str] = set()
        for peer, peer_port, initial, maximum, attempts, expiry in peers:
            peer_identity = self.identities.identity(peer)
            generation = f"{peer.lower()}-g1"
            lines.append(
                f"peer={peer},127.0.0.1:{peer_port},"
                f"{initial},{maximum},{attempts},{expiry}"
            )
            lines.append(
                f"peer_key={peer},{generation},ACTIVE,{peer_identity.spki_sha256}"
            )
            configured_keys.add((peer, peer_identity.spki_sha256))
            authorized_peers.add(peer)
        for peer in trusted or []:
            identity = self.identities.identity(peer)
            if (peer, identity.spki_sha256) not in configured_keys:
                lines.append(
                    f"peer_key={peer},{peer.lower()}-g1,ACTIVE,{identity.spki_sha256}"
                )
            authorized_peers.add(peer)
        for peer in sorted(authorized_peers):
            for scope in ("test/three", "test/interrupted", "test/expiry"):
                lines.append(f"authorize={peer},*,EVIDENCE,{scope}")
        path.write_text("\n".join(lines) + "\n")
        return path

    def identity(self, label: str) -> TestIdentity:
        return self.identities.identity(label)

    def start(
        self,
        name: str,
        config: Path,
        state: Path,
        environment: dict[str, str] | None = None,
    ) -> "Daemon":
        daemon = Daemon(self, name, config, state, environment)
        daemon.start()
        self.daemons.append(daemon)
        return daemon

    def status(self, name: str, state: Path, *, logical_digest: bool = True) -> dict[str, Any]:
        value = self.run(
            name,
            # Inherited fixtures compare live logical digests. Request the expensive
            # exact digest explicitly; narrow-status tests pass logical_digest=False.
            ["status", "--control", str(state / "control.sock"), "--deadline-ms", "2000",
             "--logical-digest", "yes" if logical_digest else "no"],
        )
        assert value is not None
        return value

    def wait(self, detail: str, function: Callable[[], bool], timeout: float = 8.0) -> None:
        deadline = time.monotonic() + timeout
        last_error: BaseException | None = None
        while time.monotonic() < deadline:
            try:
                if function():
                    return
            except BaseException as exc:
                last_error = exc
            time.sleep(0.05)
        if last_error is not None:
            raise AssertionError(f"{detail}: last error {last_error}") from last_error
        raise AssertionError(f"timeout: {detail}")

    def cleanup(self) -> None:
        for daemon in reversed(self.daemons):
            daemon.cleanup()
        if self.runtime.exists():
            shutil.rmtree(self.runtime)


class Daemon:
    def __init__(
        self,
        harness: Harness,
        name: str,
        config: Path,
        state: Path,
        environment: dict[str, str] | None = None,
        readiness_timeout: float = 5.0,
    ):
        self.harness = harness
        self.name = name
        self.config = config
        self.state = state
        self.stdout_path = harness.logs / f"daemon-{name}.stdout.txt"
        self.stderr_path = harness.logs / f"daemon-{name}.stderr.txt"
        self.process: subprocess.Popen[str] | None = None
        self.stdout_file = None
        self.stderr_file = None
        self.environment = environment or {}
        self.readiness_timeout = readiness_timeout

    @property
    def control(self) -> Path:
        return self.state / "control.sock"

    def start(self) -> None:
        self.stdout_file = self.stdout_path.open("a")
        self.stderr_file = self.stderr_path.open("a")
        environment = os.environ.copy()
        environment.update(self.environment)
        self.process = subprocess.Popen(
            [str(self.harness.binary), "run", "--config", str(self.config)],
            text=True,
            stdout=self.stdout_file,
            stderr=self.stderr_file,
            env=environment,
        )

        def ready() -> bool:
            if self.process is None:
                return False
            if self.process.poll() is not None:
                return False
            return self.control.is_socket() and "RUNTIME_READY" in self.stdout_path.read_text()

        try:
            self.harness.wait(f"daemon {self.name} ready", ready, self.readiness_timeout)
        except BaseException:
            self.cleanup()
            raise AssertionError(
                f"daemon {self.name} failed: stdout={self.stdout_path.read_text()!r} "
                f"stderr={self.stderr_path.read_text()!r}"
            )
        mode = stat.S_IMODE(self.control.stat().st_mode)
        self.harness.check(mode == 0o600, f"{self.name} control mode is 0600")

    def shutdown(self) -> None:
        if self.process is None or self.process.poll() is not None:
            return
        result = self.harness.run(
            f"shutdown-{self.name}",
            ["shutdown", "--control", str(self.control), "--deadline-ms", "2000"],
        )
        self.harness.check(result is not None and result.get("ok") is True, f"{self.name} shutdown accepted")
        self.process.wait(timeout=5)
        self.harness.check(self.process.returncode == 0, f"{self.name} graceful exit")
        self._close_files()
        self.harness.check(not self.control.exists(), f"{self.name} control path removed")

    def kill(self) -> None:
        if self.process is None or self.process.poll() is not None:
            return
        self.process.send_signal(signal.SIGKILL)
        self.process.wait(timeout=5)
        self.harness.check(self.process.returncode == -signal.SIGKILL, f"{self.name} killed")
        self._close_files()

    def cleanup(self) -> None:
        if self.process is not None and self.process.poll() is None:
            try:
                self.shutdown()
            except BaseException:
                self.process.kill()
                self.process.wait(timeout=5)
                self._close_files()

    def _close_files(self) -> None:
        if self.stdout_file is not None:
            self.stdout_file.close()
            self.stdout_file = None
        if self.stderr_file is not None:
            self.stderr_file.close()
            self.stderr_file = None


class Blackhole:
    def __init__(self, port: int):
        self.port = port
        self.accepted = threading.Event()
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.error: BaseException | None = None

    def start(self) -> None:
        self.thread.start()

    def _run(self) -> None:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
                listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                listener.bind(("127.0.0.1", self.port))
                listener.listen(8)
                listener.settimeout(5)
                connection, _ = listener.accept()
                with connection:
                    self.accepted.set()
                    self.stop.wait(5)
        except BaseException as exc:
            self.error = exc
            self.accepted.set()

    def close(self) -> None:
        self.stop.set()
        self.thread.join(timeout=5)
        if self.error is not None:
            raise self.error


def run_suite(h: Harness) -> None:
    def config_validation() -> None:
        a = h.identity("A")
        b = h.identity("B")
        identity_lines = (
            f"identity_cert={a.certificate}\n"
            f"identity_key={a.private_key}\n"
            f"identity_pin={a.spki_sha256}\n"
            "identity_generation=a-g1\n"
        )
        base = h.work / "bad-base.conf"
        base.write_text(
            "NATRAV_OVERLAY_CONFIG_V6\n"
            "node=A\nstate=bad-state\nlisten=127.0.0.1:44001\n"
            "control=control.sock\n" + identity_lines + "unknown=yes\n"
        )
        result = h.run("config-unknown", ["config-check", "--config", str(base)], expected=3)
        h.check(result is not None and result["code"] == "CONFIG_UNKNOWN_FIELD", "unknown config rejected")

        duplicate = h.work / "bad-duplicate.conf"
        duplicate.write_text(
            "NATRAV_OVERLAY_CONFIG_V6\n"
            "node=A\nstate=bad-state\nlisten=127.0.0.1:44001\n"
            "control=control.sock\n" + identity_lines +
            f"peer=B,127.0.0.1:44002,50,100,3,1000\n"
            f"peer=B,127.0.0.1:44003,50,100,3,1000\n"
        )
        result = h.run("config-duplicate-peer", ["config-check", "--config", str(duplicate)], expected=3)
        h.check(result is not None and result["code"] == "CONFIG_DUPLICATE_PEER", "duplicate peer rejected")

        unsafe = h.work / "bad-control.conf"
        unsafe.write_text(
            "NATRAV_OVERLAY_CONFIG_V6\n"
            "node=A\nstate=bad-state\nlisten=127.0.0.1:44001\n"
            "control=../escape.sock\n" + identity_lines
        )
        result = h.run("config-control-path", ["config-check", "--config", str(unsafe)], expected=3)
        h.check(result is not None and result["code"] == "CONFIG_CONTROL_INVALID", "unsafe control name rejected")

        hostname = h.work / "bad-hostname.conf"
        hostname.write_text(
            "NATRAV_OVERLAY_CONFIG_V6\n"
            "node=A\nstate=bad-state\nlisten=127.0.0.1:44001\n"
            "control=control.sock\n" + identity_lines +
            f"peer=B,localhost:44002,50,100,3,1000\n"
        )
        result = h.run("config-nonnumeric-peer", ["config-check", "--config", str(hostname)], expected=3)
        h.check(result is not None and result["code"] == "ENDPOINT_RESOLUTION_FAILED", "nonnumeric peer rejected")

        writable = h.work / "bad-permissions.conf"
        writable.write_text(
            "NATRAV_OVERLAY_CONFIG_V6\n"
            "node=A\nstate=bad-state\nlisten=127.0.0.1:44001\n"
            "control=control.sock\n" + identity_lines
        )
        writable.chmod(0o666)
        result = h.run("config-writable", ["config-check", "--config", str(writable)], expected=3)
        h.check(result is not None and result["code"] == "CONFIG_PERMISSIONS_INVALID", "writable config rejected")

    h.case("strict_versioned_configuration", config_validation)

    def control_lifecycle() -> None:
        root = h.runtime / "control"
        state = root / "state"
        state.mkdir(parents=True)
        control = state / "control.sock"
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as stale:
            stale.bind(str(control))
        h.check(control.is_socket(), "owned stale control socket created")

        config = h.config("control-node", "L", state, free_port(), [], 500)
        daemon = h.start("control-node", config, state)
        h.check(control.is_socket(), "stale socket replaced by live listener")

        ok, malformed = raw_control(control, b"BAD!\x02")
        h.check(not ok, "malformed control request rejected")
        h.check(malformed.get("code") == "CONTROL_PROTOCOL_REJECTED", "malformed control error typed")

        ok, trailing = raw_control(control, b"NOC1\x02\x00")
        h.check(not ok, "control trailing bytes rejected")
        h.check(trailing.get("code") == "trailing-material", "trailing-byte error typed")

        def status_client(index: int) -> tuple[int, str, str]:
            completed = subprocess.run(
                [
                    str(h.binary), "status", "--control", str(control),
                    "--deadline-ms", "2000",
                ],
                text=True, capture_output=True, timeout=5, env=os.environ.copy(),
            )
            return completed.returncode, completed.stdout, completed.stderr

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(status_client, range(16)))
        h.check(all(code == 0 for code, _, _ in results), "simultaneous local clients complete")
        parsed = [json.loads(stdout.splitlines()[-1]) for _, stdout, _ in results]
        h.check(all(value.get("ok") is True for value in parsed), "simultaneous local responses valid")
        h.check(all(not stderr for _, _, stderr in results), "simultaneous local clients have no diagnostics")

        assert daemon.process is not None
        daemon.process.send_signal(signal.SIGTERM)
        daemon.process.wait(timeout=5)
        h.check(daemon.process.returncode == 0, "SIGTERM produces graceful exit")
        daemon._close_files()
        h.check(not control.exists(), "SIGTERM removes control socket")
        h.check("RUNTIME_STOP" in daemon.stdout_path.read_text(), "SIGTERM emits stop account")

    h.case("control_socket_lifecycle_and_concurrency", control_lifecycle)

    def three_node_progress() -> None:
        root = h.runtime / "three"
        root.mkdir()
        a_state, b_state, c_state = root / "a", root / "b", root / "c"
        a_port, b_port, c_port = free_port(), free_port(), free_port()
        a_conf = h.config(
            "three-a", "A", a_state, a_port,
            [("B", b_port, 50, 200, 30, 15_000), ("C", c_port, 50, 200, 30, 15_000)],
            250,
        )
        b_conf = h.config("three-b", "B", b_state, b_port, [], 500, trusted=["A"])
        c_conf = h.config("three-c", "C", c_state, c_port, [], 500, trusted=["A"])
        slow_b = Blackhole(b_port)
        slow_b.start()
        c = h.start("three-c-1", c_conf, c_state)
        a = h.start("three-a-1", a_conf, a_state)

        busy = h.run(
            "three-state-busy",
            ["inspect", "--state", str(a_state), "--node", "A"],
            expected=3,
        )
        h.check(busy is not None and busy["code"] == "STATE_BUSY", "daemon owns state continuously")

        unknown = h.run(
            "three-unknown-peer",
            [
                "submit", "--control", str(a.control), "--node", "A", "--peer", "D",
                "--scope", "test/three", "--operation", operation("three-unknown"),
                "--payload-text", "unknown",
            ],
            expected=3,
        )
        h.check(unknown is not None and unknown["code"] == "PEER_NOT_CONFIGURED", "unknown peer rejected")

        op_b = operation("three-offline-b")
        op_c = operation("three-online-c")
        h.run(
            "three-submit-b",
            [
                "submit", "--control", str(a.control), "--node", "A", "--peer", "B",
                "--scope", "test/three", "--operation", op_b,
                "--payload-text", "queued for B",
            ],
        )
        h.run(
            "three-submit-c",
            [
                "submit", "--control", str(a.control), "--node", "A", "--peer", "C",
                "--scope", "test/three", "--operation", op_c,
                "--payload-text", "delivered to C",
            ],
        )
        h.check(slow_b.accepted.wait(5), "slow B accepted a connection")
        if slow_b.error is not None:
            raise slow_b.error

        observed: dict[str, Any] = {}

        def c_progressed() -> bool:
            status = h.status("three-wait-c", a_state)
            observed.clear(); observed.update(status)
            return status["outbox"]["acked"] == 1 and status["outbox"]["pending"] == 1

        h.wait("C progresses while B is absent", c_progressed)
        entries = {entry["recipient"]: entry for entry in observed["outbox"]["entries"]}
        h.check(
            entries["B"]["last_error_code"] in {
                "ATTEMPT_INTERRUPTED", "IO_TIMEOUT", "HANDSHAKE_EOF", "CONNECT_FAILED"
            },
            "B durable attempt state is visible",
        )
        h.check(entries["C"]["status"] == "ACKED", "C is acknowledged independently")
        h.check(slow_b.thread.is_alive(), "C progressed while B's connection remained slow")
        c_status = h.status("three-c-status", c_state)
        h.check(c_status["inbound_records"] == 1, "C durable admission")
        slow_b.close()

        b = h.start("three-b-1", b_conf, b_state)
        h.run("three-wake-b", ["wake", "--control", str(a.control), "--peer", "B"])

        def b_caught_up() -> bool:
            return h.status("three-wait-b", a_state)["outbox"]["acked"] == 2

        h.wait("B receives queued work", b_caught_up)
        h.check(h.status("three-b-status", b_state)["inbound_records"] == 1, "B admitted once")

        repeated = h.run(
            "three-repeat-b",
            [
                "submit", "--control", str(a.control), "--node", "A", "--peer", "B",
                "--scope", "test/three", "--operation", op_b,
                "--payload-text", "queued for B",
            ],
        )
        h.check(repeated is not None and repeated["queue_disposition"] == "ALREADY_ACKED", "repeat does not reschedule")
        time.sleep(0.25)
        h.check(h.status("three-b-still-once", b_state)["inbound_records"] == 1, "repeat did not duplicate admission")

        a.shutdown(); b.shutdown(); c.shutdown()
        offline_a = h.run("three-offline-a", ["inspect", "--state", str(a_state), "--node", "A"])
        assert offline_a is not None
        h.check(offline_a["outbox"]["acked"] == 2, "sender receipts survive shutdown")
        h.check(offline_a["outbox"]["pending"] == 0, "no obligation lost")

        b2 = h.start("three-b-2", b_conf, b_state)
        a2 = h.start("three-a-2", a_conf, a_state)
        restored = h.status("three-restored-a", a_state)
        h.check(restored["outbox"]["acked"] == 2, "acked state reconstructed")
        h.check(all(peer["attempts_this_run"] == 0 for peer in restored["peers"]), "restart did not resend acknowledged work")

        correction = operation("three-b-correction")
        h.run(
            "three-correction",
            [
                "revise", "--control", str(a2.control), "--node", "A", "--peer", "B",
                "--scope", "test/three", "--operation", correction,
                "--corrects", op_b, "--payload-text", "corrected for B",
            ],
        )

        def correction_delivered() -> bool:
            return h.status("three-wait-correction", b_state)["inbound_records"] == 2

        h.wait("correction delivered after restart", correction_delivered)
        a2.shutdown(); b2.shutdown()
        b_snapshot = h.run("three-b-offline", ["inspect", "--state", str(b_state), "--node", "B"])
        assert b_snapshot is not None
        h.check(b_snapshot["inbound"]["count"] == 2, "B history preserved")
        h.check(b_snapshot["inbound"]["current"][0]["current_operation_id"] == correction, "B current view follows correction")

    h.case("three_node_progress_reconnect_and_restart", three_node_progress)

    def interrupted_attempt() -> None:
        root = h.runtime / "interrupted"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        a_conf = h.config(
            "interrupted-a", "A", a_state, a_port,
            [("B", b_port, 700, 700, 5, 15_000)],
            3_000,
        )
        b_conf = h.config(
            "interrupted-b", "B", b_state, b_port, [], 500, trusted=["A"])
        blackhole = Blackhole(b_port)
        blackhole.start()
        a = h.start("interrupted-a-1", a_conf, a_state)
        op_id = operation("interrupted-operation")
        h.run(
            "interrupted-submit",
            [
                "submit", "--control", str(a.control), "--node", "A", "--peer", "B",
                "--scope", "test/interrupted", "--operation", op_id,
                "--payload-text", "survives process death",
            ],
        )
        h.check(blackhole.accepted.wait(5), "blackhole accepted attempt")
        if blackhole.error is not None:
            raise blackhole.error
        a.kill()
        blackhole.close()
        offline = h.run(
            "interrupted-offline",
            ["inspect", "--state", str(a_state), "--node", "A"],
        )
        assert offline is not None
        entry = offline["outbox"]["entries"][0]
        h.check(entry["status"] == "PENDING", "interrupted work remains pending")
        h.check(entry["delivery"]["attempts"] == 1, "begun attempt consumed durably")
        h.check(entry["delivery"]["last_error_code"] == "ATTEMPT_INTERRUPTED", "interrupted outcome reconstructed")

        b = h.start("interrupted-b", b_conf, b_state)
        a2 = h.start("interrupted-a-2", a_conf, a_state)
        h.run("interrupted-wake", ["wake", "--control", str(a2.control), "--peer", "B"])

        def recovered() -> bool:
            return h.status("interrupted-wait", a_state)["outbox"]["acked"] == 1

        h.wait("interrupted operation recovered", recovered, 8.0)
        h.check(h.status("interrupted-b-status", b_state)["inbound_records"] == 1, "recipient admitted recovered work once")
        a2.shutdown(); b.shutdown()

    h.case("kill_during_attempt_and_recover", interrupted_attempt)

    def expiry_budget() -> None:
        root = h.runtime / "expiry"
        root.mkdir()
        a_state = root / "a"
        a_port, absent_port = free_port(), free_port()
        a_conf = h.config(
            "expiry-a", "A", a_state, a_port,
            [("Z", absent_port, 50, 50, 2, 10_000)],
            100,
        )
        a = h.start("expiry-a-1", a_conf, a_state)
        op_id = operation("expiry-operation")
        h.run(
            "expiry-submit",
            [
                "submit", "--control", str(a.control), "--node", "A", "--peer", "Z",
                "--scope", "test/expiry", "--operation", op_id,
                "--payload-text", "bounded retries",
            ],
        )
        final: dict[str, Any] = {}

        def expired() -> bool:
            status = h.status("expiry-wait", a_state)
            final.clear(); final.update(status)
            return status["outbox"]["expired"] == 1

        h.wait("attempt budget expires operation", expired)
        entry = final["outbox"]["entries"][0]
        h.check(entry["attempts"] == 2, "attempt budget enforced")
        h.check(entry["expiry_reason"] == "ATTEMPT_LIMIT", "expiry reason visible")
        a.shutdown()

        a2 = h.start("expiry-a-2", a_conf, a_state)
        restored = h.status("expiry-restored", a_state)
        h.check(restored["outbox"]["expired"] == 1, "expiry reconstructed")
        h.check(restored["peers"][0]["attempts_this_run"] == 0, "expired operation not retried")
        time.sleep(0.2)
        h.check(h.status("expiry-stable", a_state)["peers"][0]["attempts_this_run"] == 0, "expiry remains quiescent")
        a2.shutdown()

        deadline_state = root / "deadline"
        deadline_port, second_absent = free_port(), free_port()
        deadline_conf = h.config(
            "expiry-deadline", "D", deadline_state, deadline_port,
            [("Y", second_absent, 100, 100, 100, 300)],
            100,
        )
        d = h.start("expiry-deadline", deadline_conf, deadline_state)
        deadline_operation = operation("deadline-expiry-operation")
        h.run(
            "deadline-expiry-submit",
            [
                "submit", "--control", str(d.control), "--node", "D", "--peer", "Y",
                "--scope", "test/expiry", "--operation", deadline_operation,
                "--payload-text", "expires by elapsed policy",
            ],
        )
        deadline_final: dict[str, Any] = {}

        def deadline_expired() -> bool:
            status = h.status("deadline-expiry-wait", deadline_state)
            deadline_final.clear(); deadline_final.update(status)
            return status["outbox"]["expired"] == 1

        h.wait("wall-clock expiry closes obligation", deadline_expired)
        deadline_entry = deadline_final["outbox"]["entries"][0]
        h.check(deadline_entry["expiry_reason"] == "DELIVERY_EXPIRED", "elapsed expiry reason visible")
        h.check(1 <= deadline_entry["attempts"] < 100, "elapsed expiry precedes attempt budget")
        d.shutdown()

    h.case("bounded_attempt_budget_and_expiry", expiry_budget)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, default=Path("node/bin/natrav-overlay"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output directory must not exist")
    harness = Harness(args.binary, args.output)
    started = time.time()
    status = "FAIL"
    return_code = 1
    try:
        run_suite(harness)
        status = "PASS"
        return_code = 0
    except BaseException as exc:
        (harness.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_PERSISTENT_TESTS_V1",
            "status": status,
            "binary": str(harness.binary),
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "started_unix": started,
            "elapsed_seconds": time.time() - started,
        }
        (harness.output / "SUMMARY.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
        (harness.output / "CASES.json").write_text(json.dumps(harness.cases, indent=2, sort_keys=True) + "\n")
        (harness.output / "COMMANDS.json").write_text(json.dumps(harness.commands, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary, sort_keys=True))
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
