#!/usr/bin/env python3
"""NRMB1 bundles, owner-pinned directories, and complete-node media lifecycle.

Local directories model explicitly selected removable media. This suite claims
no USB/SD hardware, filesystem power-loss, or independent-host evidence.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import struct
import subprocess
import sys
import threading
import time
import zlib

from run_persistent import Harness, free_port, operation
from run_peer_sessions import submit, outbox_entry
from run_configured_adapter_transport import image_profile, ref, wait_entry, assert_receipt, peer
from run_runtime_adapter_configuration import endpoint, records, upgrade, write, digest
from run_live_configuration import candidate, activate
from run_unix_datagram_transport import run_external

NAPA_HEADER = struct.Struct('>8sB3xQIII')
NAPA_MAGIC = b'NAPA0001'
BUNDLE_HEADER = struct.Struct('>8sIQIQQI')
BUNDLE_MAGIC = b'NRMB0001'
BUNDLE_OVERHEAD = 76


def directory(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=False)
    path.chmod(0o700)
    return path


def object_text(path: Path) -> str:
    status = path.stat(follow_symlinks=False)
    return f'{status.st_dev}:{status.st_ino}'


def arguments(side: dict[str, Path], *, mtu=512, lifetime=10000,
              queue_bytes=1048576, queue_files=128, poll=2,
              scan=128, entry_limit=512, quarantine_bytes=1048576,
              quarantine_files=128, duplicate_window=512):
    return [
        'removable-media-packet-adapter',
        '--inbound', str(side['in']), '--inbound-object', object_text(side['in']),
        '--outbound', str(side['out']), '--outbound-object', object_text(side['out']),
        '--quarantine', str(side['q']), '--quarantine-object', object_text(side['q']),
        '--mtu', str(mtu), '--link', '0000000000000001', '--epoch', '1',
        '--queue-bytes', str(queue_bytes), '--queue-files', str(queue_files),
        '--bundle-lifetime-ms', str(lifetime), '--poll-interval-ms', str(poll),
        '--scan-entries', str(scan), '--directory-entry-limit', str(entry_limit),
        '--quarantine-bytes', str(quarantine_bytes),
        '--quarantine-files', str(quarantine_files),
        '--duplicate-window', str(duplicate_window),
    ]


def napa(kind: int, sequence: int, payload=b'', deadline=500) -> bytes:
    prefix = NAPA_HEADER.pack(NAPA_MAGIC, kind, sequence, deadline, 0, len(payload))
    return prefix + struct.pack('>I', zlib.crc32(prefix + payload)) + payload


def bundle(payload: bytes, *, link=1, epoch=1, lifetime=10000, created=None):
    if created is None:
        created = int(time.time() * 1000)
    prefix = BUNDLE_HEADER.pack(
        BUNDLE_MAGIC, 0, link, epoch, created, created + lifetime, len(payload))
    digest = hashlib.sha256(prefix + payload).digest()
    data = prefix + payload + digest
    return digest.hex() + '.nrmb', data


def decode_bundle(data: bytes, name: str):
    assert len(data) >= BUNDLE_OVERHEAD
    magic, reserved, link, epoch, created, expires, length = BUNDLE_HEADER.unpack(
        data[:BUNDLE_HEADER.size])
    payload = data[BUNDLE_HEADER.size:-32]
    digest = data[-32:]
    assert magic == BUNDLE_MAGIC and reserved == 0 and length == len(payload)
    assert hashlib.sha256(data[:-32]).digest() == digest
    assert name == digest.hex() + '.nrmb'
    return {'link': link, 'epoch': epoch, 'created': created,
            'expires': expires, 'payload': payload, 'digest': digest.hex()}


def fsync_directory(path: Path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def atomic_file(directory_path: Path, name: str, data: bytes, *, part_prefix='.nrmb-part-'):
    temp = directory_path / f'{part_prefix}{os.getpid()}-{time.monotonic_ns()}'
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    target = directory_path / name
    if target.exists():
        temp.unlink()
        fsync_directory(directory_path)
        return False
    os.rename(temp, target)
    fsync_directory(directory_path)
    return True


class NativeAdapter:
    def __init__(self, binary: Path, side: dict[str, Path], log: Path,
                 args=None, mtu=512):
        self.sock, child = socket.socketpair(socket.AF_UNIX, socket.SOCK_SEQPACKET)
        self.sock.settimeout(4)
        self.sequence = 0
        self.log = log
        self.error = log.open('wb')
        self.mtu = mtu
        fd = child.fileno()
        def setup():
            os.dup2(fd, 3)
            if fd != 3:
                os.close(fd)
        self.process = subprocess.Popen(
            [str(binary), *(args or arguments(side))],
            pass_fds=tuple(sorted({3, fd})), preexec_fn=setup,
            stdout=subprocess.DEVNULL, stderr=self.error,
            env=dict(os.environ, NATRAV_ADAPTER_FD='3',
                     NATRAV_ADAPTER_PROTOCOL='NAPA0001'))
        child.close()

    def request(self, kind: int, payload=b''):
        self.sequence += 1
        self.sock.send(napa(kind, self.sequence, payload))
        response = self.sock.recv(131072)
        if len(response) < 36:
            raise AssertionError('adapter EOF: ' + self.log.read_text(errors='replace'))
        magic, response_type, sequence, deadline, status, length = NAPA_HEADER.unpack(
            response[:32])
        assert magic == NAPA_MAGIC and response_type == kind + 1
        assert sequence == self.sequence and deadline == 0 and length == len(response) - 36
        assert zlib.crc32(response[:32] + response[36:]) == struct.unpack('>I', response[32:36])[0]
        return status, response[36:]

    def hello(self):
        return self.request(1, struct.pack('>IIIII', 1, self.mtu, 65536, 1048576, 1))

    def received(self, timeout=5):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            status, payload = self.request(5)
            if status == 0:
                return payload
            assert status == 1 and not payload
            time.sleep(.005)
        raise AssertionError('timed out waiting for removable-media packet')

    def close(self):
        try:
            if self.process.poll() is None:
                self.request(9)
        except (OSError, AssertionError, socket.timeout):
            pass
        try:
            self.process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait()
        self.sock.close()
        self.error.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


class MediaLink:
    """Fixture-only bounded copier between two explicitly selected media sides."""
    ACTIONS = {3: 'INTERRUPT', 5: 'CORRUPT', 7: 'DUPLICATE',
               9: 'DELAY', 11: 'DROP'}

    def __init__(self, root: Path, adversity=True):
        self.root = directory(root)
        self.sides = [self._new_side('left'), self._new_side('right')]
        self.adversity = adversity
        self.ordinals = [0, 0]
        self.events = []
        self.replacements = []
        self.pending = []
        self.error = None
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _new_side(self, name: str):
        base = directory(self.root / name)
        return {'base': base, 'in': directory(base / 'in'),
                'out': directory(base / 'out'), 'q': directory(base / 'q')}

    def arm_adversity(self):
        with self.lock:
            if self.pending:
                raise AssertionError('cannot arm media adversity with pending copies')
            self.adversity = True
            self.ordinals = [0, 0]

    def replace_side(self, index: int):
        wait_for(lambda: not self.pending, timeout=5,
                 label='media fixture pending copies before replacement')
        with self.lock:
            old = self.sides[index]
            old_base = old['base']
            retired = old_base.with_name(old_base.name + f'-retired-{len(self.replacements)+1}')
            os.rename(old_base, retired)
            fresh = self._new_side(old_base.name + f'-replacement-{len(self.replacements)+1}')
            self.sides[index] = fresh
            self.replacements.append({
                'side': index,
                'old': {k: str(v) for k, v in old.items()},
                'retired': str(retired),
                'new': {k: str(v) for k, v in fresh.items()},
            })
            return fresh

    @staticmethod
    def _remove(path: Path):
        try:
            path.unlink()
            fsync_directory(path.parent)
        except FileNotFoundError:
            pass

    def _publish(self, target: Path, name: str, data: bytes):
        return atomic_file(target, name, data)

    def _defer(self, delay: float, target: Path, name: str, data: bytes,
               *, retry_if_present=False):
        now = time.monotonic()
        self.pending.append({
            'when': now + delay, 'deadline': now + 2.0,
            'target': target, 'name': name, 'data': data,
            'retry_if_present': retry_if_present,
        })

    def _action(self, direction: int, source: Path, target: Path, name: str, data: bytes):
        self.ordinals[direction] += 1
        ordinal = self.ordinals[direction]
        action = self.ACTIONS.get(ordinal, 'PASS') if self.adversity else 'PASS'
        if action != 'PASS':
            self.events.append({'direction': direction, 'ordinal': ordinal,
                                'action': action, 'bytes': len(data)})
        if action == 'INTERRUPT':
            part = target / f'.nrmb-part-{name}'
            fd = os.open(part, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'wb') as stream:
                stream.write(data[:max(1, len(data)//2)])
                stream.flush(); os.fsync(stream.fileno())
            fsync_directory(target)
        elif action == 'CORRUPT':
            corrupt = bytearray(data)
            corrupt[min(50, len(corrupt)-33)] ^= 1
            self._publish(target, name, bytes(corrupt))
        elif action == 'DUPLICATE':
            self._publish(target, name, data)
            self._defer(.08, target, name, data, retry_if_present=True)
        elif action == 'DELAY':
            self._defer(.12, target, name, data)
        elif action == 'DROP':
            pass
        else:
            self._publish(target, name, data)
        self._remove(source / name)

    def _run(self):
        try:
            while not self.stop_event.is_set():
                now = time.monotonic()
                with self.lock:
                    for item in list(self.pending):
                        if item['when'] <= now:
                            published = self._publish(
                                item['target'], item['name'], item['data'])
                            if (not published and item['retry_if_present'] and
                                    now < item['deadline']):
                                item['when'] = now + .02
                            else:
                                self.pending.remove(item)
                    for direction in (0, 1):
                        source = self.sides[direction]['out']
                        target = self.sides[1-direction]['in']
                        for path in sorted(source.glob('*.nrmb'))[:64]:
                            try:
                                data = path.read_bytes()
                            except FileNotFoundError:
                                continue
                            self._action(direction, source, target, path.name, data)
                    if len(self.pending) > 32:
                        raise AssertionError('media fixture pending queue exceeded')
                time.sleep(.002)
        except BaseException as error:
            self.error = repr(error)
            try:
                (self.root/'FIXTURE-ERROR.txt').write_text(self.error+'\n')
            except OSError:
                pass

    def quiescent(self):
        with self.lock:
            if self.pending:
                return False
            for side in self.sides:
                for directory_path in (side['in'], side['out']):
                    # Only complete bundles can enter the packet protocol.
                    # Interrupted fixture copies deliberately remain as inert
                    # .nrmb-part-* files until the adapter's bounded stale-file
                    # cleanup observes their expiry.  Waiting for that expiry
                    # here would turn a quiescence check into an artificial
                    # wall-clock delay and is unnecessary before process death.
                    if any(directory_path.glob('*.nrmb')):
                        return False
            return True

    def close(self):
        self.stop_event.set()
        self.thread.join(5)
        if self.thread.is_alive():
            raise AssertionError('media fixture worker did not stop')
        if self.error:
            raise AssertionError(self.error)


def owned_children(daemon):
    pid = daemon.process.pid
    found = []
    for directory_path in Path('/proc').iterdir():
        if not directory_path.name.isdigit():
            continue
        try:
            status = dict(line.split(':', 1) for line in
                          (directory_path/'status').read_text().splitlines() if ':' in line)
            if int(status.get('PPid', '-1')) != pid:
                continue
            args = (directory_path/'cmdline').read_bytes().split(b'\0')
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        if b'removable-media-packet-adapter' in args:
            found.append((int(directory_path.name), args))
    return found


def wait_for(predicate, timeout=5, label='condition'):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        value = predicate()
        if value:
            return value
        time.sleep(.01)
    raise AssertionError('timed out waiting for ' + label)


def _sanitized_binary(h):
    return 'sanitize' in h.binary.name


def _media_status(h, label, state):
    if not _sanitized_binary(h):
        return h.status(label, state, logical_digest=False)
    value = h.run(
        label,
        ['status', '--control', str(state/'control.sock'),
         '--deadline-ms', '20000', '--logical-digest', 'no'],
        timeout=30)
    assert value is not None
    return value


def _media_wait_entry(h, state, operation_id, timeout):
    if not _sanitized_binary(h):
        return wait_entry(h, state, operation_id, timeout=timeout)
    last = {}
    def ready():
        last.clear()
        last.update(_media_status(h, 'poll-'+operation_id[:8], state))
        return outbox_entry(last, operation_id)['status'] == 'ACKED'
    h.wait('configured adapter operation ACKED', ready, timeout)
    return last


def _media_assert_receipt(h, state, operation_id, recipient):
    if not _sanitized_binary(h):
        return assert_receipt(h, state, operation_id, recipient)
    entry_result = h.run(
        'bound-receipt-'+operation_id[:8],
        ['outbox-query', '--control', str(state/'control.sock'),
         '--operation', operation_id, '--limit', '1', '--max-bytes', '60000',
         '--history-limit', '4', '--deadline-ms', '20000'],
        timeout=30)
    h.check(entry_result is not None and
            entry_result.get('format') == 'NATRAV_OVERLAY_OUTBOX_QUERY_V1',
            'exact outbox query format under sanitizer')
    records_list = entry_result.get('records') if entry_result else None
    h.check(isinstance(records_list, list) and len(records_list) == 1,
            'exact outbox record exists under sanitizer')
    entry = records_list[0]
    receipt = entry['receipt']
    h.check(entry['status'] == 'ACKED' and receipt is not None and
            receipt['operation_id'] == operation_id and
            receipt['recorder'] == recipient and receipt['recipient'] == recipient and
            receipt['disposition'] in ('COMMITTED', 'DUPLICATE'),
            'exact authenticated operation and recipient binding under sanitizer')


def _media_profile(h, identifier, side, generation=1, previous='0'*64):
    value = image_profile(
        identifier, h.binary, arguments(side, lifetime=60000),
        generation, previous)
    if _sanitized_binary(h):
        value = value.replace('startup-timeout-ms=2000', 'startup-timeout-ms=10000')
        value = value.replace('request-timeout-ms=500', 'request-timeout-ms=5000')
        value = value.replace('shutdown-timeout-ms=500', 'shutdown-timeout-ms=5000')
    return value


def _media_shutdown(h, daemon):
    if not _sanitized_binary(h):
        daemon.shutdown()
        return
    if daemon.process is None or daemon.process.poll() is not None:
        return
    result = h.run(
        'shutdown-'+daemon.name,
        ['shutdown', '--control', str(daemon.control), '--deadline-ms', '20000'],
        timeout=30)
    h.check(result is not None and result.get('ok') is True,
            daemon.name+' shutdown accepted under sanitizer')
    daemon.process.wait(timeout=30)
    h.check(daemon.process.returncode == 0,
            daemon.name+' graceful sanitizer exit')
    daemon._close_files()
    h.check(not daemon.control.exists(),
            daemon.name+' sanitizer control path removed')


def suite(h, selected):
    root = Path(__file__).resolve().parents[2]
    def case(name, function):
        if selected is None or selected == name:
            h.case(name, function)

    def codec():
        probe = h.work/'removable-media-bundle-probe'
        flags = ['-D_GNU_SOURCE','-std=c++20','-O1','-Wall','-Wextra','-Wpedantic',
                 '-Wconversion','-Wsign-conversion','-Wshadow','-Wformat=2','-Werror']
        result = run_external(h, 'compile-bundle', ['/usr/bin/g++', *flags,
            '-I'+str(root/'foundation/include'), '-I'+str(root/'node/src'),
            str(root/'node/tests/test_removable_media_bundle.cpp'),
            str(root/'node/src/removable_media_bundle.cpp'),
            str(root/'foundation/src/core.cpp'), '-o', str(probe)], timeout=90)
        h.check(result.returncode == 0, result.stderr)
        result = run_external(h, 'bundle', [str(probe)], timeout=30)
        h.check(result.returncode == 0, result.stderr)
        data = json.loads(result.stdout); h.assertions += data['assertions']
        h.check(data['status'] == 'PASS', 'canonical finite bundle codec')
        version = h.run('version', ['version'])
        h.check(version['version'] == '0613', 'revision identity')
        h.check(version.get('removable_media_packet_adapter') ==
                'REMOVABLE_MEDIA_PACKET_ADAPTER_V1', 'adapter role marker')
        h.check(version.get('removable_media_bundle') ==
                'REMOVABLE_MEDIA_PACKET_BUNDLE_V1', 'bundle marker')
    case('canonical_bundle_codec', codec)

    def direct():
        base = directory(h.work/'direct-media')
        side = {'in': directory(base/'in'), 'out': directory(base/'out'),
                'q': directory(base/'q')}
        args = arguments(side, lifetime=1000, queue_files=8, poll=2)
        stale_name, stale_data = bundle(b'prior-adapter-incarnation', lifetime=1000)
        atomic_file(side['in'], stale_name, stale_data)
        with NativeAdapter(h.binary, side, h.logs/'direct.stderr.txt', args) as adapter:
            adapter.sequence = 41
            status, capabilities = adapter.hello()
            h.check(status == 0 and struct.unpack('>IIIII', capabilities) ==
                    (1, 512, 548, 1048576, 1), 'exact NAPA capabilities')
            h.check(not (side['in']/stale_name).exists() and
                    any(side['q'].glob('q-*.txt')) and adapter.request(5)[0] == 1,
                    'new adapter incarnation discards unauthenticated residual packets')
            payload = bytes(range(256))
            h.check(adapter.request(3, payload)[0] == 0,
                    'transmit accepted only after durable local publication')
            path = wait_for(lambda: next(iter(side['out'].glob('*.nrmb')), None),
                            label='outbound bundle')
            decoded = decode_bundle(path.read_bytes(), path.name)
            h.check(decoded['payload'] == payload and decoded['link'] == 1 and
                    decoded['epoch'] == 1, 'canonical content-addressed bundle')
            h.check((path.stat().st_mode & 0o777) == 0o600,
                    'published bundle is owner-only')
            atomic_file(side['in'], path.name, path.read_bytes())
            path.unlink(); fsync_directory(side['out'])
            h.check(adapter.received() == payload, 'copied bundle becomes one complete datagram')

            # Same exact bundle is suppressed within the bounded duplicate window.
            name, data = bundle(b'duplicate', lifetime=1000)
            atomic_file(side['in'], name, data)
            h.check(adapter.received() == b'duplicate', 'first content digest admitted')
            atomic_file(side['in'], name, data)
            wait_for(lambda: not (side['in']/name).exists(), label='duplicate suppression')
            h.check(adapter.request(5)[0] == 1, 'duplicate digest does not reappear')

            name, data = bundle(b'corrupt', lifetime=1000)
            corrupt = bytearray(data); corrupt[50] ^= 1
            before = len(list(side['q'].glob('q-*.txt')))
            atomic_file(side['in'], name, bytes(corrupt))
            wait_for(lambda: len(list(side['q'].glob('q-*.txt'))) > before,
                     label='corrupt quarantine evidence')
            h.check(adapter.request(5)[0] == 1,
                    'corrupted bundle never reaches packet queue')

            expired_name, expired = bundle(
                b'expired', lifetime=1000, created=int(time.time()*1000)-2000)
            before = len(list(side['q'].glob('q-*.txt')))
            atomic_file(side['in'], expired_name, expired)
            wait_for(lambda: len(list(side['q'].glob('q-*.txt'))) > before,
                     label='expired quarantine evidence')
            h.check(adapter.request(5)[0] == 1, 'expired bundle rejected')

            wrong_name, wrong = bundle(b'wrong-link', link=2, lifetime=1000)
            before = len(list(side['q'].glob('q-*.txt')))
            atomic_file(side['in'], wrong_name, wrong)
            wait_for(lambda: len(list(side['q'].glob('q-*.txt'))) > before,
                     label='wrong-link quarantine evidence')
            h.check(adapter.request(5)[0] == 1, 'wrong link rejected')

            part = side['in']/'.nrmb-part-interrupted'
            fd = os.open(part, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'wb') as stream:
                stream.write(b'incomplete'); stream.flush(); os.fsync(stream.fileno())
            old = time.time()-2; os.utime(part, (old, old)); fsync_directory(side['in'])
            before = len(list(side['q'].glob('q-*.txt')))
            wait_for(lambda: not part.exists(), timeout=4, label='stale interrupted copy cleanup')
            h.check(len(list(side['q'].glob('q-*.txt'))) > before,
                    'interrupted copy leaves bounded quarantine evidence')

        pressure = {'in': directory(base/'pressure-in'),
                    'out': directory(base/'pressure-out'),
                    'q': directory(base/'pressure-q')}
        with NativeAdapter(h.binary, pressure, h.logs/'pressure.stderr.txt',
                           arguments(pressure, queue_files=1, queue_bytes=1024,
                                     lifetime=5000, poll=2)) as adapter:
            adapter.hello()
            h.check(adapter.request(3, b'first')[0] == 0,
                    'one outbound bundle occupies finite file queue')
            h.check(adapter.request(3, b'second')[0] == 2,
                    'outbound file pressure returns BUSY without partial publication')
            first_file = next(pressure['out'].glob('*.nrmb'))
            first_file.unlink(); fsync_directory(pressure['out'])
            h.check(adapter.request(3, b'second')[0] == 0,
                    'released file slot admits later datagram')

            n1, d1 = bundle(b'in-one', lifetime=5000)
            time.sleep(.002)
            n2, d2 = bundle(b'in-two', lifetime=5000)
            atomic_file(pressure['in'], n1, d1); atomic_file(pressure['in'], n2, d2)
            first = adapter.received()
            second = adapter.received()
            h.check({first, second} == {b'in-one', b'in-two'},
                    'inbound queue pressure retains complete files for later admission')

        replaced = {'in': directory(base/'replace-in'),
                    'out': directory(base/'replace-out'),
                    'q': directory(base/'replace-q')}
        adapter = NativeAdapter(h.binary, replaced, h.logs/'replace.stderr.txt',
                                arguments(replaced, poll=2))
        try:
            adapter.hello()
            retired = base/'replace-in-retired'
            os.rename(replaced['in'], retired)
            replacement = directory(base/'replace-in')
            h.check(replacement.stat().st_ino != retired.stat().st_ino,
                    'fixture replaced exact directory object')
            h.check(adapter.process.wait(timeout=4) != 0,
                    'running adapter rejects directory replacement')
        finally:
            adapter.close()

        unsafe = base/'unsafe'; unsafe.mkdir(); unsafe.chmod(0o750)
        valid_out = directory(base/'unsafe-out'); valid_q = directory(base/'unsafe-q')
        unsafe_side = {'in': unsafe, 'out': valid_out, 'q': valid_q}
        with NativeAdapter(h.binary, unsafe_side, h.logs/'unsafe.stderr.txt',
                           arguments(unsafe_side)) as bad:
            h.check(bad.process.wait(timeout=3) != 0,
                    'group-accessible directory is rejected')

        symlink_target = directory(base/'symlink-target')
        symlink_path = base/'symlink-in'; symlink_path.symlink_to(symlink_target)
        symlink_side = {'in': symlink_path,
                        'out': directory(base/'symlink-out'),
                        'q': directory(base/'symlink-q')}
        symlink_args = arguments({**symlink_side, 'in': symlink_target})
        # Preserve the real target object ID while presenting a symlink path.
        symlink_args[symlink_args.index('--inbound')+1] = str(symlink_path)
        with NativeAdapter(h.binary, symlink_side, h.logs/'symlink.stderr.txt', symlink_args) as bad:
            h.check(bad.process.wait(timeout=3) != 0,
                    'symlink directory path is rejected without following it')
    case('direct_media_io_and_negative_controls', direct)

    def lifecycle():
        # All copy faults are deterministic on the A-to-B path.  The reverse
        # path remains clean so bidirectional application behavior is exercised
        # independently of the fault schedule rather than multiplying two
        # simultaneous handshake-fault state machines.
        links = [MediaLink(h.work/'media-link-0', adversity=False),
                 MediaLink(h.work/'media-link-1', adversity=False)]
        astate, bstate = h.runtime/'media-a', h.runtime/'media-b'
        a = b = None
        profiles = {}; endpoints = {}
        # link0: a-out side 0 <-> b-in side 1
        # link1: b-out side 0 <-> a-in side 1
        sides = {
            'a-out': links[0].sides[0], 'b-in': links[0].sides[1],
            'b-out': links[1].sides[0], 'a-in': links[1].sides[1],
        }
        try:
            for name, side in sides.items():
                profiles[name] = _media_profile(h, name, side)
                endpoints[name] = endpoint(
                    profiles[name], identifier=name,
                    role='listener' if name.endswith('in') else 'route')
            node_deadline = 20000 if _sanitized_binary(h) else 5000
            ac = h.config('media-a', 'A', astate, free_port(),
                          [('B', free_port(), 150, 500, 100, 180000)],
                          deadline_ms=node_deadline)
            bc = h.config('media-b', 'B', bstate, free_port(),
                          [('A', free_port(), 150, 500, 100, 180000)],
                          deadline_ms=node_deadline)
            for node, cfg, remote in [('a', ac, 'B'), ('b', bc, 'A')]:
                text = upgrade(cfg.read_text(), node+'-media'); lines = []
                for line in text.splitlines():
                    if line.startswith('listen='):
                        line = 'listen=' + ref(node+'-in')
                    if line.startswith('peer_route='+remote+','):
                        line = ','.join(line.split(',')[:4]) + ',' + ref(node+'-out')
                    lines.append(line)
                write(cfg, '\n'.join(lines)+'\n' + records(
                    [profiles[node+'-in'], profiles[node+'-out']],
                    [endpoints[node+'-in'], endpoints[node+'-out']]) +
                    'session_max_operations=32\nsession_idle_timeout_ms=2000\n')
                h.run('media-config-'+node, ['config-check', '--config', str(cfg)])
            b = h.start('media-b', bc, bstate)
            a = h.start('media-a', ac, astate)
            operation_timeout = 180 if _sanitized_binary(h) else 70
            first = operation('media-first')
            faulted = operation('media-faulted')
            reverse = operation('media-reverse')
            submit(h, 'media-first', a.control, 'A', 'B', 'test/three', first,
                   'removable media seed')
            first_status = _media_wait_entry(h, astate, first, operation_timeout)
            _media_assert_receipt(h, astate, first, 'B')
            wait_for(links[0].quiescent, timeout=8,
                     label='clean media path quiescent before fault schedule')
            links[0].arm_adversity()
            submit(h, 'media-faulted', a.control, 'A', 'B', 'test/three', faulted,
                   'removable media '+('x'*12000))
            faulted_status = _media_wait_entry(h, astate, faulted, operation_timeout)
            _media_assert_receipt(h, astate, faulted, 'B')
            required = {'INTERRUPT','CORRUPT','DUPLICATE','DELAY','DROP'}
            h.check({event['action'] for event in links[0].events} >= required,
                    'authenticated A-to-B operation survives every bounded media-copy fault')
            h.check(_media_status(h, 'media-b-admissions', bstate)['inbound_records'] == 2,
                    'faults and duplicates do not duplicate durable application admission')
            old_opened = peer(faulted_status, 'B')['session']['opened']
            # Kill the route adapter without draining the persistent carrier.
            # Complete or delayed packets from its old finite-stream epoch may
            # therefore arrive later; the replacement connector epoch and the
            # listener's one-time binding must keep those packets out of the
            # new TLS stream.
            route_children = wait_for(
                lambda: [(pid, args) for pid, args in owned_children(a)
                         if str(sides['a-out']['in']).encode() in args],
                timeout=5, label='owned pinned media route child')
            h.check(bool(route_children), 'owned pinned media route child observed')
            killed = route_children[-1][0]
            os.kill(killed, signal.SIGKILL)
            wait_for(lambda: all(pid != killed for pid, _ in owned_children(a)),
                     timeout=5, label='killed media route child reaped')
            after_death = operation('media-after-death')
            submit(h, 'media-after-death', a.control, 'A', 'B', 'test/three',
                   after_death, 'fresh carrier after media adapter death')
            death_status = _media_wait_entry(h, astate, after_death, operation_timeout)
            _media_assert_receipt(h, astate, after_death, 'B')
            h.check(peer(death_status, 'B')['session']['opened'] > old_opened,
                    'adapter death requires fresh TLS and HELLO')

            submit(h, 'media-reverse', b.control, 'B', 'A', 'test/three', reverse,
                   'reverse removable media '+('y'*8000))
            _media_wait_entry(h, bstate, reverse, operation_timeout)
            _media_assert_receipt(h, bstate, reverse, 'A')
            h.check(not links[1].events,
                    'clean reverse path isolates bidirectional application progress')
            h.check(sum(len(list(side['q'].glob('q-*.txt')))
                        for link in links for side in link.sides) > 0,
                    'invalid media bundles leave bounded quarantine evidence')

            old_side = sides['a-out']
            new_side = links[0].replace_side(0)
            sides['a-out'] = new_side
            profile2 = _media_profile(
                h, 'a-out', new_side, 2, digest(profiles['a-out']))
            endpoint2 = endpoint(profile2, identifier='a-out', generation=2,
                                 previous=digest(endpoints['a-out']))
            successor = candidate(
                h, ac, 'media-a-out-successor', 'media-a-out-successor',
                lambda text: text.replace(ref('a-out'), ref('a-out', 2)) +
                    records([profile2], [endpoint2]))
            activated = activate(h, 'authorize-media-successor', astate, successor)
            h.check(activated.get('ok') is True,
                    'owner authorizes exact replacement directory objects')
            replacement = operation('media-after-replacement')
            submit(h, 'media-after-replacement', a.control, 'A', 'B', 'test/three',
                   replacement, 'authorized replacement media')
            replacement_status = _media_wait_entry(h, astate, replacement, operation_timeout)
            _media_assert_receipt(h, astate, replacement, 'B')
            h.check(replacement_status['runtime_configuration']['generation'] ==
                    'media-a-out-successor', 'active generation records replacement authority')
            h.check(peer(replacement_status, 'B')['session']['opened'] >
                    peer(death_status, 'B')['session']['opened'],
                    'directory succession requires a fresh authenticated session')
            h.check(not old_side['in'].exists() and not old_side['out'].exists(),
                    'retired directory paths are not rediscovered')

            _media_shutdown(h, b); pending = operation('media-pending')
            submit(h, 'media-pending', a.control, 'A', 'B', 'test/three', pending,
                   'durable across carried-media outage')
            h.check(outbox_entry(_media_status(h, 'media-pending-before-stop', astate), pending)['status'] ==
                    'PENDING', 'absent recipient leaves obligation pending')
            _media_shutdown(h, a)
            a = h.start('media-a-restart', ac, astate)
            b = h.start('media-b-restart', bc, bstate)
            recovered = _media_wait_entry(h, astate, pending, operation_timeout)
            _media_assert_receipt(h, astate, pending, 'B')
            h.check(recovered['runtime_configuration']['generation'] ==
                    'media-a-out-successor',
                    'stale seed cannot roll back authorized media succession')
            h.check(_media_status(h, 'media-restarted-admissions', bstate)['inbound_records'] == 5,
                    'five distinct A-to-B operations admitted once across failures and restart')
            _media_shutdown(h, a); _media_shutdown(h, b)
            h.check(not owned_children(a) and not owned_children(b),
                    'owned media adapter processes retire after orderly stop')
        finally:
            for daemon in (a, b):
                if daemon and daemon.process.poll() is None:
                    daemon.shutdown()
            for link in links:
                link.close()
            evidence = {
                'format': 'NATRAV_REMOVABLE_MEDIA_MODEL_EVIDENCE_V1',
                'events': [link.events for link in links],
                'replacements': [link.replacements for link in links],
                'hardware_verified': False,
            }
            (h.output/'REMOVABLE-MEDIA-EVIDENCE.json').write_text(
                json.dumps(evidence, indent=2, sort_keys=True)+'\n')
    case('two_pinned_nodes_over_carried_files', lifecycle)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--case')
    args = parser.parse_args()
    if args.output.exists():
        parser.error('output must not exist')
    harness = Harness(args.binary, args.output)
    started = time.monotonic(); code = 1
    try:
        suite(harness, args.case)
        if not harness.cases:
            raise ValueError('no case selected')
        code = 0
    except BaseException as error:
        (harness.output/'FAILURE.txt').write_text(f'{type(error).__name__}: {error}\n')
        print(f'FAIL: {type(error).__name__}: {error}', file=sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            'format': 'NATRAV_REMOVABLE_MEDIA_PACKET_ADAPTER_TESTS_V1',
            'status': 'PASS' if code == 0 else 'FAIL',
            'binary_sha256': hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            'cases_total': len(harness.cases),
            'cases_passed': sum(case['status'] == 'PASS' for case in harness.cases),
            'assertions': harness.assertions,
            'commands': len(harness.commands),
            'elapsed_seconds': time.monotonic() - started,
        }
        for name, value in [('SUMMARY', summary), ('CASES', harness.cases),
                            ('COMMANDS', harness.commands)]:
            (harness.output/(name+'.json')).write_text(
                json.dumps(value, indent=2, sort_keys=True)+'\n')
        print(json.dumps(summary, sort_keys=True))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
