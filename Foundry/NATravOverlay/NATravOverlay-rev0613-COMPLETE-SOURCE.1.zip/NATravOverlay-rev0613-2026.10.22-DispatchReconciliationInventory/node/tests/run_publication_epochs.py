#!/usr/bin/env python3
"""Explicit publication-channel epochs after exact terminal predecessor outcomes."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import struct
import subprocess
import time
from typing import Any

from run_persistent import Harness, free_port
from run_projection_publication import (
    OUTPUT_SCOPE,
    source_config,
    publisher_config,
    recipient_config,
    topology,
)
from run_numeric_projection import create as numeric_create, produce, consume
from run_publication_channels import (
    Reader,
    channel_create,
    channel_publish,
    channel_status,
)
from run_automatic_publication_channels import auto_enable, auto_status, wait_publications
from run_live_configuration import candidate, activate, wait_state
from run_evidence_queries import query
from run_peer_sessions import outbox_entry
from run_state_authentication import new_key, migrate, start as start_keyed


def decode_npc2(payload: bytes) -> dict[str, Any]:
    r = Reader(payload)
    if r.take(4) != b"NPC2" or r.u8() != 1 or r.u8() != 1 or r.u16() != 0:
        raise AssertionError("invalid NPC2 header")
    result: dict[str, Any] = {
        "channel_instance": r.digest(),
        "sequence": r.u64(),
        "epoch": r.u64(),
        "maximum_publications": r.u32(),
    }
    predecessor = r.u8()
    if predecessor not in (0, 1):
        raise AssertionError("invalid NPC2 correction marker")
    result["corrects"] = r.digest() if predecessor else None
    terminal = r.u8()
    if terminal not in (0, 1):
        raise AssertionError("invalid NPC2 terminal marker")
    result["prior_epoch_terminal_operation"] = r.digest() if terminal else None
    result["prior_epoch_terminal_outcome"] = r.text()
    result["authority_digest"] = r.digest()
    result["channel_name"] = r.text()
    base_size = r.u32()
    result["npp1"] = r.take(base_size)
    if r.at != len(payload):
        raise AssertionError("NPC2 trailing bytes")
    return result


def recipient_epoch_record(h: Harness, label: str, state: Path,
                           operation_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    response = query(h, label, state, operation=operation_id, view="history",
                     payload="yes", payload_length=16384)
    h.check(len(response["records"]) == 1,
            "recipient admits one exact epoch publication")
    row = response["records"][0]
    payload = bytes.fromhex(row["payload_hex"])
    decoded = decode_npc2(payload)
    expected = hashlib.sha256(
        b"NATRAV_OVERLAY_PUBLICATION_CHANNEL_OPERATION_V1\0" + payload
    ).hexdigest()
    h.check(expected == operation_id == row["operation_id"],
            "independent NPC2 operation derivation matches recipient record")
    return row, decoded


def epoch_args(state: Path, channel: dict[str, Any], projection: dict[str, Any],
               *, outcome: str, reason: str, name: str = "channel",
               deadline_ms: int = 5000) -> list[str]:
    consumer = projection["consumer"]
    return [
        "publication-channel-new-epoch", "--control", str(state / "control.sock"),
        "--channel", name,
        "--instance", channel["instance"],
        "--expected-channel-revision", str(channel["revision"]),
        "--expected-epoch", str(channel["head_epoch"]),
        "--terminal-operation", channel["head_operation"],
        "--terminal-outcome", outcome.lower(),
        "--expected-projection-revision", str(consumer["revision"]),
        "--expected-position", str(consumer["acknowledged_sequence"]),
        "--result-digest", consumer["projection_result_digest"],
        "--reason", reason,
        "--deadline-ms", str(deadline_ms),
    ]


def new_epoch(h: Harness, label: str, state: Path, channel: dict[str, Any],
              projection: dict[str, Any], *, outcome: str, reason: str,
              name: str = "channel", expected: int = 0,
              deadline_ms: int = 5000) -> dict[str, Any]:
    result = h.run(label, epoch_args(state, channel, projection,
                                    outcome=outcome, reason=reason,
                                    name=name, deadline_ms=deadline_ms),
                   expected=expected, timeout=max(10.0, deadline_ms / 1000 + 3.0))
    assert result is not None
    if expected == 0:
        h.check(result["format"] == "NATRAV_OVERLAY_PUBLICATION_CHANNEL_EPOCH_V1",
                "versioned publication epoch receipt")
        if result["disposition"] == "QUEUED":
            h.check(result["corrects"] is None and result["payload_format"] == "NPC2",
                    "new epoch begins with an NPC2 original")
    return result


def cancel_head(h: Harness, label: str, state: Path, operation: str,
                reason: str = "close terminal publication line") -> None:
    h.run(label, [
        "cancel", "--control", str(state / "control.sock"),
        "--operation", operation, "--reason", reason,
        "--deadline-ms", "5000",
    ])


def cases(h: Harness, selected: set[str] | None = None) -> None:
    def case(name: str, function: Any) -> None:
        if selected is None or name in selected:
            h.case(name, function)

    def cancelled_epoch_and_correction() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "epoch-cancel", start_recipient=False)
        values: dict[str, bytes] = {}
        source = produce(h, "epoch-cancel-source-one", a, values, ticks=100)
        numeric_create(h, "epoch-cancel-projection", b, limit=16)
        projection, rows = consume(h, "epoch-cancel-consume-one", b, values)
        created = channel_create(h, "epoch-cancel-create", b, projection,
                                 maximum=8)
        first = channel_publish(h, "epoch-cancel-publish-one", b,
                                created["channel"], projection)
        wait_state(h, b, first["operation_id"], "PENDING", "epoch-cancel-pending")
        pending = channel_status(h, "epoch-cancel-pending-status", b)["channel"]
        refused = new_epoch(h, "epoch-cancel-pending-refused", b, pending,
                            projection, outcome="CANCELLED",
                            reason="cannot skip a pending predecessor", expected=3)
        h.check(refused["code"] == "PUBLICATION_CHANNEL_EPOCH_HEAD_NOT_TERMINAL",
                "pending head cannot start a replacement epoch")
        cancel_head(h, "epoch-cancel-head", b, first["operation_id"])
        cancelled = channel_status(h, "epoch-cancel-terminal", b)["channel"]
        wrong_args = epoch_args(
            b, cancelled, projection, outcome="CANCELLED",
            reason="wrong terminal selector must fail")
        wrong_args[wrong_args.index("--terminal-operation") + 1] = hashlib.sha256(
            b"not-the-channel-head").hexdigest()
        wrong = h.run("epoch-cancel-wrong-terminal", wrong_args, expected=3)
        assert wrong is not None
        h.check(wrong["code"] == "PUBLICATION_CHANNEL_EPOCH_HEAD_CONFLICT",
                "new epoch requires the exact terminal head operation")
        epoch = new_epoch(h, "epoch-cancel-new-epoch", b, cancelled, projection,
                          outcome="CANCELLED",
                          reason="replace explicitly cancelled publication line")
        h.check(epoch["epoch"] == 2 and
                epoch["terminal_operation"] == first["operation_id"],
                "epoch receipt binds terminal predecessor and monotonic epoch")

        cd = h.start("epoch-cancel-c", cc, c)
        wait_state(h, b, epoch["operation_id"], "ACKED", "epoch-cancel-epoch-acked")
        row, decoded = recipient_epoch_record(
            h, "epoch-cancel-recipient-original", c, epoch["operation_id"])
        h.check(row["corrects"] is None and decoded["corrects"] is None,
                "new epoch is an evidence original, not a correction of terminal work")
        h.check(decoded["epoch"] == 2 and
                decoded["prior_epoch_terminal_operation"] == first["operation_id"] and
                decoded["prior_epoch_terminal_outcome"] == "CANCELLED",
                "NPC2 retains exact terminal lineage without misusing corrects")
        acked = channel_status(h, "epoch-cancel-acked-status", b)["channel"]
        refused_acked = new_epoch(h, "epoch-cancel-acked-refused", b, acked,
                                  projection, outcome="CANCELLED",
                                  reason="cannot replace an acknowledged head", expected=3)
        h.check(refused_acked["code"] == "PUBLICATION_CHANNEL_EPOCH_HEAD_NOT_TERMINAL",
                "acknowledged head cannot start another epoch")

        produce(h, "epoch-cancel-source-two", a, values, ticks=125, corrects=source)
        second_projection, rows = consume(h, "epoch-cancel-consume-two", b,
                                          values, rows=rows)
        exact_retry = new_epoch(h, "epoch-cancel-exact-retry", b, cancelled,
                                projection, outcome="CANCELLED",
                                reason="replace explicitly cancelled publication line")
        h.check(exact_retry["disposition"] == "ALREADY_STARTED" and
                exact_retry["operation_id"] == epoch["operation_id"],
                "lost-response retry remains exact after projection advances")
        second = channel_publish(h, "epoch-cancel-publish-two", b, acked,
                                 second_projection)
        wait_state(h, b, second["operation_id"], "ACKED", "epoch-cancel-second-acked")
        second_row, second_decoded = recipient_epoch_record(
            h, "epoch-cancel-recipient-correction", c, second["operation_id"])
        h.check(second_decoded["epoch"] == 2 and
                second_decoded["corrects"] == epoch["operation_id"] and
                second_decoded["prior_epoch_terminal_operation"] is None and
                second_row["corrects"] == epoch["operation_id"],
                "later result corrects the acknowledged head inside epoch two")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("cancelled_epoch_original_and_correction", cancelled_epoch_and_correction)

    def rejected_and_expired() -> None:
        # Authenticated recipient rejection is an exact terminal predecessor.
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "epoch-reject", allow_output=False)
        assert cd is not None
        values: dict[str, bytes] = {}
        produce(h, "epoch-reject-source", a, values, ticks=30)
        numeric_create(h, "epoch-reject-projection", b)
        projection, _ = consume(h, "epoch-reject-consume", b, values)
        created = channel_create(h, "epoch-reject-create", b, projection,
                                 maximum=4)
        first = channel_publish(h, "epoch-reject-publish", b,
                                created["channel"], projection)
        wait_state(h, b, first["operation_id"], "REJECTED", "epoch-reject-terminal")
        rejected = channel_status(h, "epoch-reject-status", b)["channel"]
        second = new_epoch(h, "epoch-reject-new", b, rejected, projection,
                           outcome="REJECTED",
                           reason="start a separately attributable line after denial")
        wait_state(h, b, second["operation_id"], "REJECTED", "epoch-reject-second-terminal")
        h.check(query(h, "epoch-reject-not-admitted", c,
                      operation=second["operation_id"], view="history",
                      payload="no")["records"] == [],
                "new epoch does not bypass recipient authorization")
        status = channel_status(h, "epoch-reject-lineage", b)["channel"]
        h.check(status["publications"][-1]["prior_epoch_terminal_outcome"] == "REJECTED" and
                status["publications"][-1]["corrects"] is None,
                "rejected lineage is durable and the replacement remains an original")
        cd.shutdown(); ad.shutdown(); bd.shutdown()

        # A bounded delivery expiry can also terminate an epoch.
        a = h.runtime / "epoch-expire-a"
        b = h.runtime / "epoch-expire-b"
        c = h.runtime / "epoch-expire-c"
        ap, bp, cp = free_port(), free_port(), free_port()
        ac = source_config(h, "epoch-expire-a", a, ap, bp)
        bc = publisher_config(h, "epoch-expire-b", b, bp, cp)
        lines = []
        for line in bc.read_text().splitlines():
            if line.startswith("peer=C,"):
                fields = line.split(",")
                fields[-4:] = ["50", "50", "100", "350"]
                line = ",".join(fields)
            lines.append(line)
        bc.write_text("\n".join(lines) + "\n"); bc.chmod(0o600)
        cc = recipient_config(h, "epoch-expire-c", c, cp)
        bd = h.start("epoch-expire-b", bc, b)
        ad = h.start("epoch-expire-a", ac, a)
        values = {}
        produce(h, "epoch-expire-source", a, values, ticks=40)
        numeric_create(h, "epoch-expire-projection", b)
        projection, _ = consume(h, "epoch-expire-consume", b, values)
        created = channel_create(h, "epoch-expire-create", b, projection,
                                 maximum=4)
        first = channel_publish(h, "epoch-expire-publish", b,
                                created["channel"], projection)
        wait_state(h, b, first["operation_id"], "EXPIRED", "epoch-expire-terminal")
        expired = channel_status(h, "epoch-expire-status", b)["channel"]
        cd = h.start("epoch-expire-c", cc, c)
        second = new_epoch(h, "epoch-expire-new", b, expired, projection,
                           outcome="EXPIRED",
                           reason="start another line after bounded delivery expiry")
        wait_state(h, b, second["operation_id"], "ACKED", "epoch-expire-new-acked")
        row, decoded = recipient_epoch_record(
            h, "epoch-expire-recipient", c, second["operation_id"])
        h.check(row["corrects"] is None and decoded["epoch"] == 2 and
                decoded["prior_epoch_terminal_outcome"] == "EXPIRED",
                "expired predecessor yields one independently admitted epoch original")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("rejected_and_expired_epoch_lineage", rejected_and_expired)

    def automatic_grant_requires_reenable() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "epoch-auto", start_recipient=False)
        values: dict[str, bytes] = {}
        source = produce(h, "epoch-auto-source-one", a, values, ticks=50)
        numeric_create(h, "epoch-auto-projection", b)
        projection, rows = consume(h, "epoch-auto-consume-one", b, values)
        created = channel_create(h, "epoch-auto-create", b, projection,
                                 maximum=8)
        auto_enable(h, "epoch-auto-enable", b, created["channel"], maximum=8,
                    interval=10)
        first_channel = wait_publications(h, b, 1)
        first = first_channel["head_operation"]
        wait_state(h, b, first, "PENDING", "epoch-auto-pending")
        cancel_head(h, "epoch-auto-cancel", b, first)
        h.wait("automatic grant notices terminal predecessor", lambda:
               auto_status(h, "epoch-auto-await-block", b)["schedule"]["grant"]["state"] == "BLOCKED",
               timeout=10)
        terminal = channel_status(h, "epoch-auto-terminal", b)["channel"]
        second = new_epoch(h, "epoch-auto-new", b, terminal, projection,
                           outcome="CANCELLED",
                           reason="replace cancelled automatic publication line")
        schedule = auto_status(h, "epoch-auto-still-blocked", b)["schedule"]
        h.check(schedule["grant"]["state"] == "BLOCKED",
                "new epoch never silently re-enables the old automatic grant")
        cd = h.start("epoch-auto-c", cc, c)
        wait_state(h, b, second["operation_id"], "ACKED", "epoch-auto-new-acked")
        produce(h, "epoch-auto-source-two", a, values, ticks=55, corrects=source)
        projection, rows = consume(h, "epoch-auto-consume-two", b, values, rows=rows)
        time.sleep(0.4)
        h.check(channel_status(h, "epoch-auto-no-silent-publish", b)["channel"]["publication_count"] == 2,
                "blocked grant performs no remote disclosure after result changes")
        current = channel_status(h, "epoch-auto-current", b)["channel"]
        auto_enable(h, "epoch-auto-explicit-reenable", b, current, maximum=1,
                    interval=10, reason="explicit grant for replacement epoch")
        third = wait_publications(h, b, 3)
        wait_state(h, b, third["head_operation"], "ACKED", "epoch-auto-correction-acked")
        h.check(third["publications"][-1]["epoch"] == 2 and
                third["publications"][-1]["corrects"] == second["operation_id"] and
                third["publications"][-1]["automatic"],
                "explicit new grant publishes one correction inside replacement epoch")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("automatic_grant_stays_blocked_until_reenabled", automatic_grant_requires_reenable)

    def commit_kills() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "epoch-kills", start_recipient=False)
        values: dict[str, bytes] = {}
        produce(h, "epoch-kills-source", a, values, ticks=60)
        numeric_create(h, "epoch-kills-projection", b)
        projection, _ = consume(h, "epoch-kills-consume", b, values)
        selectors: list[tuple[str, dict[str, Any]]] = []
        for name in ("before", "after"):
            created = channel_create(h, f"epoch-kills-create-{name}", b,
                                     projection, name=name, maximum=4)["channel"]
            published = channel_publish(h, f"epoch-kills-publish-{name}", b,
                                        created, projection, name=name)
            wait_state(h, b, published["operation_id"], "PENDING",
                       f"epoch-kills-{name}-pending")
            cancel_head(h, f"epoch-kills-cancel-{name}", b,
                        published["operation_id"])
            selectors.append((name, channel_status(
                h, f"epoch-kills-selector-{name}", b, name=name)["channel"]))
        bd.shutdown()

        for phase, (name, selector), disposition in (
            ("BEFORE", selectors[0], "QUEUED"),
            ("AFTER", selectors[1], "ALREADY_STARTED"),
        ):
            marker = f"NATRAV_OVERLAY_TEST_PUBLICATION_EPOCH_{phase}_COMMIT_MS"
            bd = h.start(f"epoch-kills-{phase.lower()}", bc, b, {marker: "20000"})
            args = epoch_args(b, selector, projection, outcome="CANCELLED",
                              reason=f"replace {phase.lower()} killed epoch",
                              name=name, deadline_ms=15000)
            client = subprocess.Popen([str(h.binary), *args], text=True,
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                h.wait(f"epoch {phase.lower()} commit marker",
                       lambda: marker in bd.stderr_path.read_text(), timeout=7)
                bd.kill(); client.communicate(timeout=5)
            finally:
                if client.poll() is None:
                    client.kill(); client.communicate()
            bd = h.start(f"epoch-kills-restart-{phase.lower()}", bc, b)
            retried = new_epoch(h, f"epoch-kills-retry-{phase.lower()}", b,
                                selector, projection, outcome="CANCELLED",
                                reason=f"replace {phase.lower()} killed epoch",
                                name=name)
            h.check(retried["disposition"] == disposition,
                    f"{phase.lower()} commit boundary reconstructs exact epoch outcome")
            current = channel_status(h, f"epoch-kills-status-{phase.lower()}", b,
                                     name=name)["channel"]
            h.check(current["publication_count"] == 2 and current["current_epoch"] == 2,
                    "epoch retry never multiplies replacement revisions")
            bd.shutdown()
        ad.shutdown()
    case("hard_kill_before_and_after_atomic_epoch", commit_kills)

    def maintenance() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "epoch-maint", start_recipient=False)
        values: dict[str, bytes] = {}
        source = produce(h, "epoch-maint-source-one", a, values, ticks=70)
        numeric_create(h, "epoch-maint-projection", b)
        projection, rows = consume(h, "epoch-maint-consume-one", b, values)
        created = channel_create(h, "epoch-maint-create", b, projection,
                                 maximum=8)
        first = channel_publish(h, "epoch-maint-publish", b,
                                created["channel"], projection)
        wait_state(h, b, first["operation_id"], "PENDING", "epoch-maint-pending")
        cancel_head(h, "epoch-maint-cancel", b, first["operation_id"])
        terminal = channel_status(h, "epoch-maint-terminal", b)["channel"]
        second = new_epoch(h, "epoch-maint-new", b, terminal, projection,
                           outcome="CANCELLED",
                           reason="replacement line survives maintenance")
        wait_state(h, b, second["operation_id"], "PENDING", "epoch-maint-new-pending")
        bd.shutdown()

        keys = h.runtime / "epoch-maint-keys"; keys.mkdir(mode=0o700)
        state_key = new_key(h, keys, "epoch-state-g1")
        migrate(h, "epoch-maint-migrate", b, state_key, "B")
        bd = start_keyed(h, "epoch-maint-keyed", bc, b, state_key)
        h.run("epoch-maint-compact", ["compact", "--control", str(bd.control)])
        bd.shutdown()

        backup_key = keys / "backup.key"
        archive = keys / "epoch.nob"
        identity = h.identity("B")
        h.run("epoch-maint-backup-key", [
            "backup-key-init", "--output", str(backup_key),
            "--generation", "epoch-backup-g1",
        ])
        h.run("epoch-maint-export", [
            "backup-export", "--state", str(b), "--node", "B",
            "--generation", "b-g1", "--output", str(archive),
            "--state-auth-key", str(state_key), "--encrypt-key", str(backup_key),
            "--sign-key", str(identity.private_key),
            "--sign-cert", str(identity.certificate),
        ])
        restored = h.runtime / "epoch-maint-restored"
        h.run("epoch-maint-restore", [
            "backup-restore", "--input", str(archive),
            "--destination", str(restored), "--node", "B",
            "--generation", "b-g1", "--state-auth-key", str(state_key),
            "--decrypt-key", str(backup_key),
            "--trusted-cert", str(identity.certificate),
            "--require-signature", "yes", "--require-encryption", "yes",
        ])
        moved = candidate(h, bc, "epoch-maint-relocated", "epoch-maint-b-g2",
                          lambda text: text.replace(f"state={b}", f"state={restored}"))
        h.run("epoch-maint-relocate", [
            "state-relocate", "--state", str(restored), "--node", "B",
            "--candidate", str(moved),
            "--reason", "restore explicit publication epoch",
            "--state-auth-key", str(state_key),
        ])
        cd = h.start("epoch-maint-c", cc, c)
        bd = start_keyed(h, "epoch-maint-restored-b", moved, restored, state_key)
        wait_state(h, restored, second["operation_id"], "ACKED",
                   "epoch-maint-restored-acked")
        restored_channel = channel_status(h, "epoch-maint-restored-channel",
                                          restored)["channel"]
        h.check(restored_channel["current_epoch"] == 2 and
                restored_channel["publications"][-1]["prior_epoch_terminal_operation"] ==
                    first["operation_id"],
                "epoch lineage survives authenticated compaction, restore, and relocation")
        row, decoded = recipient_epoch_record(
            h, "epoch-maint-recipient-original", c, second["operation_id"])
        h.check(row["corrects"] is None and decoded["epoch"] == 2,
                "restored replacement epoch remains a recipient original")
        produce(h, "epoch-maint-source-two", a, values, ticks=75, corrects=source)
        projection, rows = consume(h, "epoch-maint-consume-two", restored,
                                   values, rows=rows)
        third = channel_publish(h, "epoch-maint-publish-two", restored,
                                restored_channel, projection)
        wait_state(h, restored, third["operation_id"], "ACKED",
                   "epoch-maint-correction-acked")
        row, decoded = recipient_epoch_record(
            h, "epoch-maint-recipient-correction", c, third["operation_id"])
        h.check(row["corrects"] == second["operation_id"] and
                decoded["epoch"] == 2,
                "restored channel continues its replacement correction chain")
        bd.shutdown()
        audit = h.run("epoch-maint-audit", [
            "state-auth-audit", "--state", str(restored), "--node", "B",
            "--state-auth-key", str(state_key),
        ])
        assert audit is not None
        h.check(audit["status"] == "COMPLETE",
                "continued epoch history remains authenticated")
        cd.shutdown(); ad.shutdown()
    case("authenticated_restore_relocation_and_epoch_continuation", maintenance)

    def epoch_capacity() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "epoch-capacity", start_recipient=False)
        values: dict[str, bytes] = {}
        produce(h, "epoch-capacity-source", a, values, ticks=1)
        numeric_create(h, "epoch-capacity-projection", b)
        projection, _ = consume(h, "epoch-capacity-consume", b, values)
        created = channel_create(h, "epoch-capacity-create", b, projection,
                                 maximum=64)
        published = channel_publish(h, "epoch-capacity-publish", b,
                                    created["channel"], projection)
        wait_state(h, b, published["operation_id"], "PENDING",
                   "epoch-capacity-first-pending")
        operation = published["operation_id"]
        for epoch in range(1, 32):
            cancel_head(h, f"epoch-capacity-cancel-{epoch}", b, operation,
                        reason=f"close epoch {epoch}")
            terminal = channel_status(h, f"epoch-capacity-status-{epoch}", b)["channel"]
            replacement = new_epoch(
                h, f"epoch-capacity-new-{epoch + 1}", b, terminal, projection,
                outcome="CANCELLED", reason=f"start epoch {epoch + 1}")
            operation = replacement["operation_id"]
        final = channel_status(h, "epoch-capacity-final", b)["channel"]
        h.check(final["current_epoch"] == 32 and final["publication_count"] == 32,
                "32 explicit epochs remain attributable")
        cancel_head(h, "epoch-capacity-cancel-final", b, operation,
                    reason="close final supported epoch")
        final = channel_status(h, "epoch-capacity-terminal-final", b)["channel"]
        denied = new_epoch(h, "epoch-capacity-overflow", b, final, projection,
                           outcome="CANCELLED", reason="unsupported epoch 33",
                           expected=3)
        h.check(denied["code"] == "PUBLICATION_CHANNEL_EPOCH_LIMIT",
                "epoch capacity fails closed without overwriting lineage")
        h.run("epoch-capacity-compact", ["compact", "--control", str(bd.control)])
        bd.shutdown(); bd = h.start("epoch-capacity-restart", bc, b)
        replayed = channel_status(h, "epoch-capacity-replayed", b)["channel"]
        h.check(replayed["current_epoch"] == 32 and
                replayed["publications"] == final["publications"],
                "complete epoch history reconstructs through compaction and restart")
        ad.shutdown(); bd.shutdown()
    case("bounded_epoch_history", epoch_capacity)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--case", action="append")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not exist")
    harness = Harness(args.binary, args.output)
    started = time.time(); passed = False
    try:
        cases(harness, set(args.case) if args.case else None)
        passed = True
    except BaseException as error:
        (harness.output / "FAILURE.txt").write_text(
            f"{type(error).__name__}: {error}\n")
        print(f"FAIL: {type(error).__name__}: {error}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_PUBLICATION_EPOCH_TESTS_V1",
            "status": "PASS" if passed else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_total": len(harness.cases),
            "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (("SUMMARY", summary), ("CASES", harness.cases),
                            ("COMMANDS", harness.commands)):
            (harness.output / f"{name}.json").write_text(
                json.dumps(value, sort_keys=True, indent=2) + "\n")
        print(json.dumps(summary), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
