#!/usr/bin/env python3
"""Provider-managed finite source subscriptions: real local peers, exact disclosure,
receipt-gated progress, independent source envelope parsing, and reconstruction.
These are local owned fixtures; there is no remote subscription request API yet.
"""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import struct
import subprocess
import time
from typing import Any

from run_persistent import Harness, free_port, operation, raw_control, receive_exact
from run_local_evidence import config as author_config, author, args as author_args
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_live_configuration import candidate, activate, wait_state
from run_evidence_queries import config as peer_config, query
from run_peer_sessions import submit
from run_integration import encode_record, record_digest
from run_state_authentication import new_key, migrate, start as start_keyed, inspect, checksum_frame

UID, OTHER = 65534, 65533
SCOPE = 'query/series'


def config(h: Harness, name: str, state: Path, *, ports: dict[str,int],
           rules: list[str]|None = None, delegates: bool = False, inbound: list[str]|None = None) -> Path:
    p = author_config(h, name, state, peers=list(ports.items()), delegates=delegates, inbound=inbound)
    text = p.read_text().replace('CONFIG_V14', 'CONFIG_V15')
    text = text.replace(',EVIDENCE_AUTHOR\n', ',EVIDENCE_AUTHOR,SOURCE_DISCLOSE\n', 1)
    if delegates:
        text = text.replace(f'local_control={UID},EVIDENCE_AUTHOR\n', f'local_control={UID},EVIDENCE_AUTHOR,SOURCE_DISCLOSE\n')
    for peer in inbound or []:
        text += f'authorize={peer},*,EVIDENCE,{SCOPE}\n'
    if rules is None:
        rules = [f'g1,{os.geteuid()},{os.geteuid()},C,c-g1,{SCOPE},8,10000']
    text += ''.join('source_disclosure='+r+'\n' for r in rules)
    p.write_text(text); p.chmod(0o600)
    return p


def command(h: Harness, label: str, state: Path, kind: str, *, grant: str='g1',
            previous: dict|None=None, expected: int=0, uid: int|None=None,
            reason: str='explicit finite source delivery', pending: str|None=None,
            instance: str|None=None, revision: int|None=None) -> dict:
    args = ['source-subscription-'+kind,'--control',str(state/'control.sock'),'--grant',grant,'--deadline-ms','5000']
    if kind in ('step','retire'):
        assert previous is not None or (instance is not None and revision is not None)
        args += ['--instance',instance or previous['instance'], '--expected-revision',str(revision if revision is not None else previous['revision'])]
    if kind in ('create','retire'): args += ['--reason',reason]
    if pending is not None: args += ['--pending',pending]
    result = h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    assert result is not None
    if expected == 0: h.check(result['format']=='NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_V1','explicit source subscription result')
    return result


def ack(h: Harness, label: str, state: Path, issued: dict, grant: str='g1') -> dict:
    # The generic status list intentionally truncates at 64 outbox entries.
    # Observe this subscription's exact head, not that global bounded listing.
    h.wait(label+'-receipt', lambda: command(h,label+'-receipt',state,'status',grant=grant)['delivery_status']=='ACKED')
    result = command(h,label,state,'step',grant=grant,previous=issued)
    h.check(result['disposition']=='ACK' and result['acknowledged']==issued['acknowledged']+1,'frontier advances behind durable receipt')
    return result


class Reader:
    def __init__(self,b:bytes): self.b=b; self.i=0
    def get(self,n:int)->bytes:
        assert n>=0 and self.i+n<=len(self.b)
        out=self.b[self.i:self.i+n];self.i+=n;return out
    def number(self,n:int)->int:return int.from_bytes(self.get(n),'big')
    def text(self)->str:return self.get(self.number(2)).decode('ascii')
    def digest(self)->str:return self.get(32).hex()
    def eof(self)->None: assert self.i==len(self.b)


def decode_envelope(b:bytes)->dict:
    r=Reader(b);assert r.get(4)==b'NSE1'
    x={'grant':r.text(),'instance':r.digest(),'grant_digest':r.digest(),'recipient':r.text(),
       'generation':r.text(),'spki':r.digest(),'ordinal':r.number(8),'author_uid':r.number(4),
       'authored_unix_ms':r.number(8),'source_digest':r.digest()}
    marker=r.number(1);assert marker in (0,1);x['mapped_corrects']=r.digest() if marker else None
    raw=r.get(r.number(4));r.eof();q=Reader(raw);assert q.get(4)==b'NOA1';kind=q.number(1);assert kind in (1,2)
    x['source_operation']=q.digest();x['issuer']=q.text();x['source_recipient']=q.text();x['scope']=q.text()
    x['source_corrects']=q.digest() if kind==2 else None
    x['payload_hex']=q.get(q.number(4)).hex();q.eof()
    assert record_digest(raw).hex()==x['source_digest']
    x['operation_id']=hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_DELIVERY_V1\0'+b).hexdigest()
    return x


def remote(h:Harness,label:str,state:Path,issued:dict)->dict:
    op=issued['latest']['operation_id']
    q=query(h,label,state,operation=op,view='history',payload='yes',payload_length=16384)
    h.check(len(q['records'])==1,'recipient admitted selected source once')
    record=q['records'][0];x=decode_envelope(bytes.fromhex(record['payload_hex']))
    h.check(x['operation_id']==op,'independent source envelope operation ID')
    h.check('local_authorship' not in record,'remote admission is not relabeled recipient authorship')
    fixture=h.work/(label+'.nse');fixture.write_bytes(bytes.fromhex(record['payload_hex']))
    native=h.run(label+'-native-decode',['source-envelope-inspect','--payload-file',str(fixture)])
    h.check(native['source_operation']==x['source_operation'] and native['source_payload_hex']==x['payload_hex'],
            'native decoder agrees with independent source decoder')
    h.check(native['verification']=='STRUCTURAL_ONLY' and native['operation_id']==op,'local file decoder makes no authentication claim')
    fixture.write_bytes(fixture.read_bytes()+b'x')
    h.run(label+'-trailing-decode',['source-envelope-inspect','--payload-file',str(fixture)],expected=4)
    return x


def journal_frames(path:Path)->list[bytes]:
    b=path.read_bytes();out=[];i=0
    while i<len(b):
        assert b[i:i+4]==b'NOJ1';size=struct.unpack('!I',b[i+4:i+8])[0];out.append(b[i:i+40+size]);i+=40+size
    assert i==len(b);return out


def add_legacy_claim(h:Harness,state:Path)->str:
    inspect(h,'initialize-unmarked',state,node='A')
    op=operation('unmarked-self-claim');body=b'\x01'+encode_record(op,'A','A',SCOPE,b'not explicitly authored')
    frame=b'NOJ1'+struct.pack('!I',len(body))+body+b'\0'*32
    with (state/'state.journal').open('ab') as f:f.write(checksum_frame(frame))
    return op


def run_cases(h:Harness,selected:set[str]|None=None)->None:
    def case(name,fn):
        if selected is None or name in selected:h.case(name,fn)

    def policy():
        s=h.runtime/'policy';port=free_port();p=config(h,'policy',s,ports={'C':port})
        first=h.run('policy-valid',['config-check','--config',str(p)])
        lines=p.read_text().splitlines();ordered=h.work/'ordered.conf';ordered.write_text(lines[0]+'\n'+'\n'.join(reversed(lines[1:]))+'\n');ordered.chmod(0o600)
        second=h.run('policy-ordered',['config-check','--config',str(ordered)])
        h.check(first['runtime_digest']==second['runtime_digest'],'canonical disclosure config independent of file order')
        g=first['source_disclosure_policy']['grants'][0];fields=g['definition'].split(',')
        def t(v):b=v.encode();return struct.pack('!H',len(b))+b
        independent=t(fields[0])+struct.pack('!II',int(fields[1]),int(fields[2]))+b''.join(t(v) for v in fields[3:6])+struct.pack('!IQ',int(fields[6]),int(fields[7]))
        h.check(g['digest']==hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_DISCLOSURE_GRANT_V1\0'+independent).hexdigest(),'independent grant digest')
        line=next(x for x in lines if x.startswith('source_disclosure='))
        for label,modify,code in [
            ('old-version',lambda x:x.replace('CONFIG_V15','CONFIG_V14'),'CONFIG_VERSION_REJECTED'),
            ('duplicate',lambda x:x+line+'\n','SOURCE_DISCLOSURE_DUPLICATE'),
            ('wildcard',lambda x:x.replace(',query/series,8,',',query/*,8,'),'SOURCE_DISCLOSURE_INVALID'),
            ('missing-class',lambda x:x.replace(',SOURCE_DISCLOSE',''),'SOURCE_DISCLOSURE_CLASS_REQUIRED'),
            ('unknown-key',lambda x:x.replace(',C,c-g1,',',C,c-missing,'),'SOURCE_DISCLOSURE_PEER_INVALID'),
            ('self',lambda x:x.replace(',C,c-g1,',',A,a-g1,'),'SOURCE_DISCLOSURE_PEER_INVALID')]:
            bad=candidate(h,p,label,label+'-g',modify)
            h.check(h.run(label,['config-check','--config',str(bad)],3)['code']==code,'strict '+label)
        d=h.start('policy',p,s)
        created=command(h,'policy-create',s,'create');again=command(h,'policy-repeat',s,'create')
        h.check(again['instance']==created['instance'] and again['revision']==1,'same grant cannot replenish by recreate')
        h.check(command(h,'unknown-grant',s,'create',grant='absent',expected=3)['code']=='SOURCE_DISCLOSURE_DENIED','grant required before source inspection')
        q=b'NOC1\x14NSR1\x03'+t('g1');ok,result=raw_control(d.control,q)
        h.check(ok and result['revision']==1,'independent source control encoding')
        for raw in (q+b'x',q[:-1],b'NOC1\x14NSR1\xff'+t('g1')):
            ok,_=raw_control(d.control,raw);h.check(not ok,'strict source request framing')
        changed=candidate(h,p,'grant-redefined','redefined',lambda x:x.replace(',8,10000',',9,10000'))
        activate(h,'immutable-grant-id',s,changed,3,'SOURCE_DISCLOSURE_GENERATION_CONFLICT')
        d.shutdown()
    case('strict_disclosure_policy_and_wire',policy)

    def sources():
        a,b,c=(h.runtime/x for x in ('sources-a','sources-b','sources-c'));ap,bp,cp=free_port(),free_port(),free_port()
        fake=add_legacy_claim(h,a)
        p=config(h,'sources-a',a,ports={'C':cp},delegates=True,inbound=['B'])
        # Give B an actual route to A's selected listener.
        ap=int(next(x for x in p.read_text().splitlines() if x.startswith('listen=')).rsplit(':',1)[1])
        bc=peer_config(h,'sources-b','B',b,bp,peers=[('A',ap)]);cc=peer_config(h,'sources-c','C',c,cp,inbound=['A'])
        ad=h.start('sources-a',p,a);bd=h.start('sources-b',bc,b);cd=h.start('sources-c',cc,c)
        foreign=operation('foreign-source');submit(h,'foreign-source',bd.control,'B','A',SCOPE,foreign,'third-party secret');wait_state(h,b,foreign,'ACKED','foreign-receipt')
        expose_control_for_uid(a);other=author(h,'other-uid-source',a,uid=UID,value='other local author');restore_owner_only_control(a)
        hidden=author(h,'wrong-scope-source',a,scope='query/other',value='not this scope')
        original=author(h,'source-original',a,value='hello')
        correction=author(h,'source-correction',a,parent=original['operation_id'],value='world!')
        sub=command(h,'sources-create',a,'create');first=command(h,'source-first',a,'step',previous=sub)
        same=command(h,'source-first-retry',a,'step',previous=sub)
        h.check(same['disposition']=='ALREADY_COMMITTED' and same['latest']==first['latest'],'lost issue reply replay stable')
        one=ack(h,'source-first-ack',a,first);decoded1=remote(h,'source-remote-first',c,first)
        h.check(decoded1['source_operation']==original['operation_id'] and bytes.fromhex(decoded1['payload_hex'])==b'hello','first eligible explicit local source only')
        h.check(decoded1['ordinal']==1 and decoded1['mapped_corrects'] is None,'no hidden source ordinal gaps')
        second=command(h,'source-second',a,'step',previous=one);two=ack(h,'source-second-ack',a,second);decoded2=remote(h,'source-remote-second',c,second)
        h.check(decoded2['source_operation']==correction['operation_id'] and decoded2['source_corrects']==original['operation_id'],'faithful original correction provenance')
        h.check(decoded2['mapped_corrects']==first['latest']['operation_id'],'recipient correction uses acknowledged delivery mapping')
        h.check(command(h,'source-tail',a,'step',previous=two)['disposition']=='CAUGHT_UP','only selected author/scope/local provenance eligible')
        snap=query(h,'remote-chain',c,issuer='A',scope=SCOPE,view='history')
        h.check(len(snap['records'])==2,'exactly two recipient admissions')
        for x in (fake,foreign,other['operation_id'],hidden['operation_id']):h.check(x not in json.dumps([decoded1,decoded2]),'ineligible operation not disclosed')
        before=(a/'state.journal').stat().st_size
        for i in range(12):command(h,f'empty-poll-{i}',a,'step',previous=two)
        h.check((a/'state.journal').stat().st_size==before,'caught-up stepping writes no journal events')
        ad.shutdown();bd.shutdown();cd.shutdown()
        (h.output/'SOURCE-DELIVERY.json').write_text(json.dumps({'first':decoded1,'correction':decoded2,'excluded_records':4,'recipient_admissions':2},indent=2)+'\n')
    case('explicit_source_filter_and_acknowledged_corrections',sources)

    def budgets():
        a,c,d=(h.runtime/x for x in ('budget-a','budget-c','budget-d'));cp,dp=free_port(),free_port()
        rules=[f'count,{os.geteuid()},{os.geteuid()},C,c-g1,{SCOPE},2,5',
               f'bytes,{os.geteuid()},{os.geteuid()},C,c-g1,{SCOPE},8,3',
               f'slow,{os.geteuid()},{os.geteuid()},D,d-g1,{SCOPE},8,10000']
        p=config(h,'budget',a,ports={'C':cp,'D':dp},rules=rules);cc=peer_config(h,'budget-c','C',c,cp,inbound=['A'])
        ad=h.start('budget-a',p,a);cd=h.start('budget-c',cc,c)
        original=author(h,'budget-original',a,value='abc');author(h,'budget-correction',a,parent=original['operation_id'],value='de');author(h,'budget-extra',a,value='f')
        slow=command(h,'slow-create',a,'create',grant='slow');queued=command(h,'slow-issue',a,'step',grant='slow',previous=slow)
        for i in range(3):
            pending=command(h,f'slow-still-pending-{i}',a,'step',grant='slow',previous=queued)
            h.check(pending['acknowledged']==0 and pending['issued']==1 and pending['disposition']=='PENDING','unavailable peer cannot advance source progress')
        s=command(h,'count-create',a,'create',grant='count')
        for i in range(2):s=ack(h,f'count-ack-{i}',a,command(h,f'count-issue-{i}',a,'step',grant='count',previous=s),grant='count')
        h.check(s['used_payload_bytes']==5 and s['acknowledged']==2,'exact finite record and raw payload limits')
        h.check(command(h,'count-stop',a,'step',grant='count',previous=s)['disposition']=='RECORD_BUDGET_EXHAUSTED','record budget immutable')
        b=command(h,'byte-create',a,'create',grant='bytes');b=ack(h,'bytes-ack',a,command(h,'bytes-issue',a,'step',grant='bytes',previous=b),grant='bytes')
        h.check(command(h,'byte-stop',a,'step',grant='bytes',previous=b)['disposition']=='BYTE_BUDGET_EXHAUSTED','no skip or truncation on byte exhaustion')
        cancelled=h.run('slow-cancel',['cancel','--control',str(ad.control),'--operation',queued['latest']['operation_id'],'--reason','terminal fixture'])
        h.check(cancelled['status']=='CANCELLED','ordinary cancellation remains effective')
        stopped=command(h,'slow-terminal',a,'step',grant='slow',previous=queued)
        h.check(stopped['disposition']=='BLOCKED_TERMINAL' and stopped['acknowledged']==0 and stopped['used_payload_bytes']==3,'cancelled source budget not refunded or acknowledged')
        h.check(command(h,'retire-needs-disposition',a,'retire',grant='slow',previous=stopped,expected=3)['code']=='SOURCE_SUBSCRIPTION_PENDING','explicit terminal disposition required')
        retired=command(h,'slow-retire',a,'retire',grant='slow',previous=stopped,pending='retain')
        h.check(retired['retained_unacknowledged'] and retired['state']=='RETIRED','terminal original obligation retained')
        h.check(command(h,'name-reserved',a,'create',grant='slow')['disposition']=='ALREADY_RETIRED','grant generation never replenished')
        ad.shutdown();cd.shutdown();ad=h.start('budget-restart',p,a)
        rebuilt=command(h,'retired-rebuilt',a,'status',grant='slow');h.check(rebuilt['acknowledged']==0 and rebuilt['used_payload_bytes']==3,'terminal budget survives restart')
        ad.shutdown()
    case('receipt_gating_finite_budgets_and_independent_peer_progress',budgets)

    def authority():
        a,c=(h.runtime/x for x in ('authority-a','authority-c'));cp=free_port()
        rules=[f'g1,{os.geteuid()},{os.geteuid()},C,c-g1,{SCOPE},8,10000',f'guest,{UID},{os.geteuid()},C,c-g1,{SCOPE},1,1000']
        p=config(h,'authority',a,ports={'C':cp},rules=rules,delegates=True);ad=h.start('authority',p,a)
        author(h,'authority-source',a,value='private until specifically granted')
        s=command(h,'authority-create',a,'create')
        expose_control_for_uid(a)
        guest=command(h,'guest-create',a,'create',grant='guest',uid=UID)
        h.check(guest['uid']==UID,'real kernel credential owns subscription')
        h.check(command(h,'guest-cannot-inspect-owner',a,'status',uid=UID,expected=3)['code']=='SOURCE_SUBSCRIPTION_NOT_FOUND','another UID has no subscription access')
        h.check(command(h,'author-not-discloser',a,'create',uid=OTHER,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','authorship alone cannot disclose')
        restore_owner_only_control(a)
        removed=candidate(h,p,'authority-removed','authority-removed-g1',lambda x:'\n'.join(l for l in x.splitlines() if not l.startswith('source_disclosure=g1,'))+'\n')
        wire=b'NOC1\x14NSR1\x02'+struct.pack('!H',2)+b'g1'+bytes.fromhex(s['instance'])+struct.pack('!Q',s['revision'])
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as sock:
            sock.settimeout(5);sock.connect(str(ad.control));sock.sendall(struct.pack('!I',len(wire))+wire[:-1])
            activate(h,'remove-grant',a,removed)
            sock.sendall(wire[-1:]);sock.shutdown(socket.SHUT_WR)
            size=int.from_bytes(receive_exact(sock,4),'big');reply=receive_exact(sock,size)
            h.check(reply[:5]==b'NOR1\x01' and json.loads(reply[5:])['code']=='SOURCE_DISCLOSURE_DENIED',
                    'slow connected request uses revoked grant, not pre-read configuration')
        h.check(command(h,'removed-grant-no-step',a,'step',previous=s,expected=3)['code']=='SOURCE_DISCLOSURE_DENIED','current explicit disclosure required before source enumeration')
        observed=command(h,'removed-grant-status',a,'status');h.check(not observed['policy_current'],'management status survives removed data grant')
        before=(a/'state.journal').stat().st_size
        command(h,'safe-status',a,'status');h.check((a/'state.journal').stat().st_size==before,'observational status does not write')
        retired=command(h,'removed-grant-retire',a,'retire',previous=s)
        h.check(retired['state']=='RETIRED','manager can stop after data authority removal')
        changed=candidate(h,removed,'reused-grant','reused-grant-g1',lambda x:x+f'source_disclosure=g1,{os.geteuid()},{os.geteuid()},C,c-g1,{SCOPE},9,10000\n')
        activate(h,'grant-history-immutable',a,changed,3,'SOURCE_DISCLOSURE_GENERATION_CONFLICT')
        ad.shutdown()
    case('kernel_owner_and_live_disclosure_revocation',authority)

    def safety():
        a,c=(h.runtime/x for x in ('safety-a','safety-c'));cp=free_port();p=config(h,'safety',a,ports={'C':cp})
        ad=h.start('safety',p,a);author(h,'safety-source',a,value='same source')
        s=command(h,'safety-create',a,'create')
        h.check(command(h,'wrong-instance',a,'step',previous=s,instance='ab'*32,expected=3)['code']=='SOURCE_SUBSCRIPTION_CONFLICT','exact source instance required')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            responses=list(pool.map(lambda i:command(h,f'concurrent-issue-{i}',a,'step',previous=s),range(8)))
        h.check(sum(r['disposition']=='ISSUE' for r in responses)==1,'one synchronized issuer')
        h.check(len({r['latest']['operation_id'] for r in responses})==1,'same operation across concurrent clients')
        issued=responses[0]
        # Add a new generation without redirecting a grant or its outstanding work.
        ident=h.identity('C-new')
        rotated=candidate(h,p,'rotated-recipient','rotated-recipient-g1',lambda x:x.replace('C,c-g1,ACTIVE','C,c-g1,RETIRED')+f'peer_key=C,c-g2,ACTIVE,{ident.spki_sha256}\n')
        activate(h,'rotate-subscriber-key',a,rotated)
        rebound=h.run('no-generic-rebind',['rebind','--control',str(ad.control),'--operation',issued['latest']['operation_id'],'--generation','c-g2','--reason','must not expand source grant'],expected=3)
        h.check(rebound['code']=='OUTBOUND_SOURCE_SUBSCRIPTION_BOUND','generic rebind cannot escape disclosure key binding')
        h.run('cancel-bound',['cancel','--control',str(ad.control),'--operation',issued['latest']['operation_id'],'--reason','stop obsolete key'])
        command(h,'safety-retire',a,'retire',previous=issued,pending='retain');ad.shutdown()
        # Whole-record envelope limit: no source truncation or spent allowance.
        x=h.runtime/'oversized';rules=[f'g1,{os.geteuid()},{os.geteuid()},C,c-g1,{SCOPE},8,120000']
        xp=config(h,'oversized',x,ports={'C':free_port()},rules=rules);xd=h.start('oversized',xp,x)
        payload=h.work/'large.bin';payload.write_bytes(bytes(range(256))*234+bytes(range(96)))
        h.check(len(payload.read_bytes())==60000,'maximum source fixture length')
        aargs=author_args(x,'oversized-source');i=aargs.index('--payload-text');aargs[i:i+2]=['--payload-file',str(payload)];h.run('oversized-source',aargs)
        xs=command(h,'oversized-create',x,'create');bad=command(h,'oversized-step',x,'step',previous=xs,expected=3)
        h.check(bad['code']=='SOURCE_SUBSCRIPTION_ENVELOPE_TOO_LARGE','whole-source envelope bound is explicit')
        xs=command(h,'oversized-status',x,'status');h.check(xs['issued']==0 and xs['used_payload_bytes']==0,'oversized source not skipped or charged');xd.shutdown()
    case('concurrent_issuance_key_binding_and_envelope_bound',safety)

    def maintenance():
        a,c=(h.runtime/x for x in ('maint-a','maint-c'));cp=free_port();p=config(h,'maint',a,ports={'C':cp})
        cc=peer_config(h,'maint-c','C',c,cp,inbound=['A']);ad=h.start('maint',p,a)
        original=author(h,'maint-original',a,value='saved');created=command(h,'maint-create',a,'create');issued=command(h,'maint-issue',a,'step',previous=created)
        ad.shutdown();key=new_key(h,h.work,'source-state-g1');migrate(h,'source-migrate',a,key)
        ad=start_keyed(h,'maint-keyed',p,a,key);command(h,'maint-keyed-pending',a,'step',previous=issued)
        h.run('source-compact',['compact','--control',str(ad.control)]);ad.shutdown()
        before=inspect(h,'source-before-backup',a,key);h.run('source-audit',['state-auth-audit','--state',str(a),'--node','A','--state-auth-key',str(key)])
        crypt=h.work/'source-backup.key';h.run('source-backup-key',['backup-key-init','--output',str(crypt),'--generation','source-backup-g1'])
        ident=h.identity('A');archive=h.work/'source.nob'
        h.run('source-export',['backup-export','--state',str(a),'--node','A','--generation','a-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'source-restored'
        h.run('source-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'source-restored-inspect',restored,key)
        h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'exact encrypted restore state before scheduling')
        h.check(before['source_subscriptions']==after['source_subscriptions'],'source mapping and quota survive checkpoint')
        moved=candidate(h,p,'source-moved','source-moved-g1',lambda x:x.replace('state='+str(a),'state='+str(restored)))
        h.run('source-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','operational source relocation','--state-auth-key',str(key)])
        cd=h.start('maint-recipient',cc,c);ad=start_keyed(h,'source-relocated',moved,restored,key)
        progressed=ack(h,'restored-receipt',restored,issued)
        corrected=author(h,'maint-correction',restored,parent=original['operation_id'],value='after relocation')
        nextissued=command(h,'restored-correction-issue',restored,'step',previous=progressed);complete=ack(h,'restored-correction-ack',restored,nextissued)
        decoded=remote(h,'restored-correction-data',c,nextissued)
        h.check(decoded['source_operation']==corrected['operation_id'] and decoded['mapped_corrects']==issued['latest']['operation_id'],'mapped ancestry survives relocated source')
        command(h,'retire-complete',restored,'retire',previous=complete)
        h.run('source-final-compact',['compact','--control',str(ad.control)]);ad.shutdown();cd.shutdown()
        final=inspect(h,'source-final',restored,key);h.check(final['source_subscriptions'][0]['acknowledged']==2,'retired receipt-gated frontier reconstructs')
        (h.output/'RESTORED-SUBSCRIPTION.json').write_text(json.dumps(final['source_subscriptions'][0],indent=2)+'\n')
    case('keyed_compaction_encrypted_restore_relocation_and_correction',maintenance)

    def route_quota_and_rejection():
        a,c=(h.runtime/x for x in ('route-a','route-c'));cp=free_port()
        rules=[f'g1,{os.geteuid()},{os.geteuid()},C,c-g1,{SCOPE},8,10000',
               f'g2,{os.geteuid()},{os.geteuid()},C,c-g1,{SCOPE},8,10000']
        p=config(h,'route',a,ports={'C':cp},rules=rules)
        p.write_text(p.read_text()+'outbox_global_max_records=1\noutbox_peer_max_records=1\n')
        ad=h.start('route-a',p,a);author(h,'route-source-one',a,value='first')
        s=command(h,'route-create-one',a,'create');t=command(h,'route-create-two',a,'create',grant='g2')
        one=command(h,'route-issue-one',a,'step',previous=s)
        quota=command(h,'route-quota-block',a,'step',grant='g2',previous=t,expected=3)
        h.check(quota['code']=='OUTBOX_GLOBAL_RECORD_LIMIT','ordinary outbox quota applies before subscription commit')
        t2=command(h,'route-quota-state',a,'status',grant='g2')
        h.check(t2['revision']==1 and t2['issued']==0 and t2['used_payload_bytes']==0,'quota failure does not spend disclosure budget')
        # Start a genuine peer that authenticates A but denies the evidence scope.
        cc=peer_config(h,'route-c','C',c,cp,inbound=['A'])
        cc.write_text('\n'.join(l for l in cc.read_text().splitlines() if l!='authorize=A,*,EVIDENCE,query/series')+'\n')
        cd=h.start('route-c',cc,c);wait_state(h,a,one['latest']['operation_id'],'REJECTED','recipient-denial')
        blocked=command(h,'source-denied-progress',a,'step',previous=one)
        h.check(blocked['disposition']=='BLOCKED_TERMINAL' and blocked['acknowledged']==0,'recipient denial cannot advance source frontier')
        cd.shutdown();recipient=inspect(h,'denied-recipient',c,node='C');h.check(recipient['inbound']['count']==0,'denial admits no source envelope')
        cc.write_text(cc.read_text()+'authorize=A,*,EVIDENCE,query/series\n')
        # V9 is journaled: explicitly activate a new accepted candidate, not edit a seed.
        original=cc.read_text();cc.write_text('\n'.join(l for l in original.splitlines() if l!='authorize=A,*,EVIDENCE,query/series')+'\n')
        cd=h.start('route-c-restart',cc,c)
        permitted=candidate(h,cc,'route-c-allowed','route-c-allowed-g1',lambda x:x+'authorize=A,*,EVIDENCE,query/series\n')
        activate(h,'allow-recipient',c,permitted)
        h.run('explicit-retry-source',['retry','--control',str(ad.control),'--operation',one['latest']['operation_id'],'--reason','recipient explicitly allowed scope'])
        progressed=ack(h,'rejection-retry-ack',a,one)
        author(h,'route-source-two',a,value='second')
        no_route=candidate(h,p,'route-removed','route-removed-g1',lambda x:'\n'.join(l for l in x.splitlines() if not l.startswith('peer=C,') and not l.startswith('peer_route=C,'))+'\n')
        activate(h,'remove-route-not-grant',a,no_route)
        h.check(command(h,'no-route-step',a,'step',previous=progressed,expected=3)['code']=='SOURCE_SUBSCRIPTION_ROUTE_UNAVAILABLE','route removal preserves exact grant and pending source frontier')
        restored=candidate(h,p,'route-restored','route-restored-g1');activate(h,'restore-route',a,restored)
        nextone=command(h,'next-source-after-route',a,'step',previous=progressed);ack(h,'next-source-route-ack',a,nextone)
        ad.shutdown();cd.shutdown()
    case('queue_quotas_recipient_denial_explicit_retry_and_route_changes',route_quota_and_rejection)

    def kills():
        for boundary in ('BEFORE','AFTER'):
            s=h.runtime/('kill-'+boundary.lower());p=config(h,'kill-'+boundary.lower(),s,ports={'C':free_port()})
            d=h.start('kill-seed-'+boundary,p,s);author(h,'kill-source-'+boundary,s,value='durable');opened=command(h,'kill-create-'+boundary,s,'create');d.shutdown()
            env={f'NATRAV_OVERLAY_TEST_SOURCE_SUBSCRIPTION_{boundary}_COMMIT_MS':'10000'}
            d=h.start('kill-running-'+boundary,p,s,env)
            raw=b'NOC1\x14NSR1\x02'+struct.pack('!H',2)+b'g1'+bytes.fromhex(opened['instance'])+struct.pack('!Q',opened['revision'])
            with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as sock:
                sock.connect(str(d.control))
                baseline=(s/'state.journal').stat().st_size
                sock.sendall(struct.pack('!I',len(raw))+raw)
                if boundary=='AFTER':h.wait('source commit physically appended',lambda:(s/'state.journal').stat().st_size>baseline,3)
                else:time.sleep(0.25)
                d.kill()
            snap=inspect(h,'kill-offline-'+boundary,s)
            h.check(snap['source_subscriptions'][0]['issued']==(1 if boundary=='AFTER' else 0),'source and obligation same kill boundary')
            h.check(snap['outbox']['count']==(1 if boundary=='AFTER' else 0),'no orphaned obligation')
            d=h.start('kill-restart-'+boundary,p,s);again=command(h,'kill-retry-'+boundary,s,'step',previous=opened)
            h.check(again['issued']==1 and again['used_payload_bytes']==7,'retry neither loses nor doubles grant use');d.shutdown()
    case('real_kills_around_atomic_source_issue',kills)

    def retained_capacity():
        # A retired name retains its finite grant and registry slot.
        state=h.runtime/'limit-owner';uid=os.geteuid()
        rules=[f'owner-{i},{uid},{uid},C,c-g1,{SCOPE},1,1' for i in range(17)]
        cfg=config(h,'limit-owner',state,ports={'C':free_port()},rules=rules)
        daemon=h.start('limit-owner',cfg,state)
        originals=[]
        for i in range(16):originals.append(command(h,f'owner-slot-{i}',state,'create',grant=f'owner-{i}'))
        h.check(command(h,'owner-limit',state,'create',grant='owner-16',expected=3)['code']=='SOURCE_SUBSCRIPTION_LIMIT','17th retained manager instance refused')
        command(h,'owner-retire-first',state,'retire',grant='owner-0',previous=originals[0])
        h.check(command(h,'owner-limit-after-retire',state,'create',grant='owner-16',expected=3)['code']=='SOURCE_SUBSCRIPTION_LIMIT','retirement cannot recycle finite registry grant')
        daemon.shutdown()
        # Four actual kernel UIDs, not UID claims in request bytes.
        state=h.runtime/'limit-global';owners=(uid,65534,65533,65532)
        rules=[f'slot-{who}-{i},{who},{uid},C,c-g1,{SCOPE},1,1' for who in owners for i in range(16)]
        cfg=config(h,'limit-global',state,ports={'C':free_port()},rules=rules)
        cfg.write_text(cfg.read_text()+''.join(f'local_control={who},SOURCE_DISCLOSE\n' for who in owners[1:]))
        daemon=h.start('limit-global',cfg,state);expose_control_for_uid(state)
        for who in owners:
            for i in range(16):
                command(h,f'global-slot-{who}-{i}',state,'create',grant=f'slot-{who}-{i}',uid=None if who==uid else who)
        restore_owner_only_control(state)
        line=next(x for x in cfg.read_text().splitlines() if x.startswith('source_disclosure='))
        excessive=candidate(h,cfg,'limit-65-current','limit-65-current',lambda x:x+f'source_disclosure=extra,{uid},{uid},C,c-g1,{SCOPE},1,1\n')
        h.check(h.run('too-many-current-grants',['config-check','--config',str(excessive)],3)['code']=='SOURCE_DISCLOSURE_LIMIT','65th current grant rejected')
        historical=candidate(h,cfg,'limit-65-history','limit-65-history',lambda x:x.replace(line+'\n',f'source_disclosure=extra,{uid},{uid},C,c-g1,{SCOPE},1,1\n'))
        activate(h,'limit-65-history-rejected',state,historical,3,'SOURCE_DISCLOSURE_HISTORY_LIMIT')
        h.run('limit-compact',['compact','--control',str(daemon.control)]);daemon.shutdown()
        snap=inspect(h,'limit-offline',state);h.check(len(snap['source_subscriptions'])==64,'all finite manager-owned instances survive checkpoint')
        daemon=h.start('limit-restart',cfg,state);h.check(command(h,'limit-restart-first',state,'status',grant=f'slot-{uid}-0')['revision']==1,'registry reconstructs without fictitious delivery')
        daemon.shutdown();(h.output/'REGISTRY-CAPACITY.json').write_text(json.dumps({'retained_global':64,'retained_per_uid':16,'actual_kernel_uids':list(owners),'network_source_admissions':0},indent=2)+'\n')
    case('retained_registry_limits_real_uids_and_no_grant_recycling',retained_capacity)

    def full_grant():
        a,c=(h.runtime/x for x in ('full-a','full-c'));cp=free_port();uid=os.geteuid()
        cfg=config(h,'full-a',a,ports={'C':cp},rules=[f'g1,{uid},{uid},C,c-g1,{SCOPE},128,128'])
        cc=peer_config(h,'full-c','C',c,cp,inbound=['A']);ad=h.start('full-a',cfg,a);cd=h.start('full-c',cc,c)
        source_ids=[]
        for i in range(128):source_ids.append(author(h,f'full-source-{i}',a,value='x')['operation_id'])
        previous=command(h,'full-create',a,'create')
        for i in range(128):
            issued=command(h,f'full-issue-{i}',a,'step',previous=previous)
            h.check(issued['latest']['source_operation']==source_ids[i] and issued['issued']==i+1,'exact consecutive eligible source index')
            previous=ack(h,f'full-ack-{i}',a,issued)
        h.check(previous['revision']==257 and previous['acknowledged']==128 and previous['used_payload_bytes']==128,'exact maximum finite grant')
        author(h,'full-129th-source',a,value='y')
        h.check(command(h,'full-exhausted',a,'step',previous=previous)['disposition']=='RECORD_BUDGET_EXHAUSTED','record129 remains unissued')
        command(h,'full-retire',a,'retire',previous=previous)
        h.run('full-compact',['compact','--control',str(ad.control)]);ad.shutdown();cd.shutdown()
        final=inspect(h,'full-offline',a);sub=final['source_subscriptions'][0]
        h.check(sub['revision']==258 and sub['state']=='RETIRED' and len(sub['deliveries'])==128,'largest state and final revision reconstruct')
        h.check(inspect(h,'full-recipient',c,node='C')['inbound']['count']==128,'recipient gets one record per distinct source')
        ad=h.start('full-restart',cfg,a);h.check(command(h,'full-restart-status',a,'status')['acknowledged']==128,'largest retained subscription opens through normal replay');ad.shutdown()
        (h.output/'FULL-GRANT.json').write_text(json.dumps({'records':128,'raw_payload_bytes':128,'final_revision':258,'recipient_records':128,'ordinary_tls_deliveries':True},indent=2)+'\n')
    case('maximum_finite_grant_delivery_and_checkpoint_reconstruction',full_grant)

    def corruption():
        a,c=(h.runtime/x for x in ('corrupt-a','corrupt-c'));cp=free_port();p=config(h,'corrupt',a,ports={'C':cp});cc=peer_config(h,'corrupt-c','C',c,cp,inbound=['A'])
        ad=h.start('corrupt-a',p,a);cd=h.start('corrupt-c',cc,c);author(h,'corrupt-source',a,value='bound source')
        created=command(h,'corrupt-create',a,'create');issued=command(h,'corrupt-issue',a,'step',previous=created);ack(h,'corrupt-ack',a,issued)
        ad.shutdown();cd.shutdown();frames=journal_frames(a/'state.journal')
        source_frames=[i for i,f in enumerate(frames) if f[8]==32];h.check(len(source_frames)==3,'create issue ack distinct native journal transitions')
        root=h.runtime/'missing-issuance';shutil.copytree(a,root)
        (root/'state.journal').write_bytes(b''.join(f for i,f in enumerate(frames) if i!=source_frames[1]))
        h.check(inspect(h,'missing-atomic-source-issue',root,expected=3)['code']=='JOURNAL_CORRUPT','missing issue cannot be concealed by receipt or ack')
        # Rewrite the compact ACK's exact predecessor commitment while
        # recomputing the outer checksum. The next state is derived rather than
        # supplied, so this replaces the older full-state ack-count forgery.
        tamper=bytearray(frames[source_frames[-1]]);r=Reader(bytes(tamper));r.get(8)
        assert r.get(1)==b'\x20' and r.get(4)==b'NST3' and r.number(1)==2
        r.text();r.get(32+8);off=r.i;original=r.get(32)
        h.check(any(original),'independently located nonzero predecessor commitment')
        tamper[off]^=1;altered=frames.copy();altered[source_frames[-1]]=checksum_frame(bytes(tamper))
        root=h.runtime/'forged-progress';shutil.copytree(a,root);(root/'state.journal').write_bytes(b''.join(altered))
        h.check(inspect(h,'forged-source-progress',root,expected=3)['code']=='JOURNAL_CORRUPT','checksum-correct compact predecessor forgery rejected')
    case('semantic_replay_and_detached_progress_rejection',corruption)


def main()->int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not already exist')
    h=Harness(a.binary,a.output);start=time.time();ok=False
    try:run_cases(h,set(a.case) if a.case else None);ok=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {type(e).__name__}: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
