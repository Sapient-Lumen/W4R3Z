#!/usr/bin/env python3
"""Conditional local outbox administration: real nodes, independent wire and durable replay."""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, shutil, signal, socket, struct, subprocess, time
from pathlib import Path
from run_persistent import Harness, operation, raw_control, receive_exact
from run_outbox_inspection import setup, submit, query, wait_outcome
from run_live_configuration import candidate, activate
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_state_authentication import new_key, migrate, start as start_keyed, inspect

text=lambda s: struct.pack('!H',len(s.encode()))+s.encode()
u32=lambda n:struct.pack('!I',n)
u64=lambda n:struct.pack('!Q',n)

def selection(h,label,state,op):
    q=query(h,label,state,op=op,history=0)
    return q['records'][0],q['configuration_digest']

def args(state,kind,row,config,reason='deliberate selected action',generation=''):
    a=[kind,'--control',str(state/'control.sock'),'--operation',row['operation_id'],
       '--expected-state',row['condition']['state_digest'],'--expected-configuration',config,
       '--reason',reason,'--deadline-ms','5000']
    if generation:a+=['--generation',generation]
    return a

def packet(kind,row,config,reason='deliberate selected action',generation=''):
    return b'NOC1\x18OCA1'+bytes([{'cancel':1,'retry':2,'rebind':3}[kind]])+bytes.fromhex(row['operation_id'])+bytes.fromhex(row['condition']['state_digest'])+bytes.fromhex(config)+text(generation)+text(reason)

def apply(h,label,state,kind,row,config,reason='deliberate selected action',generation='',expected=0,uid=None):
    a=args(state,kind,row,config,reason,generation)
    return h.run(label,a,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,a,expected)

def pending_metadata(row):
    """Independent OCM1 baseline encoding. No receipt, attempts or transitions."""
    d=row['delivery'];p=d['policy']
    assert row['receipt'] is None and d['attempts']==0 and row['history_total']==0
    b=b'OCM1'+bytes.fromhex(row['operation_id'])+bytes.fromhex(row['record_digest'])+u64(row['queue_sequence'])+b'\x00\x01'
    b+=u64(p['created_unix_ms'])+u64(p['expires_unix_ms'])+u32(p['maximum_attempts'])+u32(p['initial_backoff_ms'])+u32(p['maximum_backoff_ms'])
    b+=b'\x01'+bytes.fromhex(p['peer_spki_sha256'])+b'\x01'+text(p['peer_generation'])
    b+=u32(0)+b'\x00'+u64(d['next_attempt_unix_ms'])+text('')+text('')+b'\x00'+text('')+b'\x00'+text('')+u32(0)
    return b

def journal_frames(raw):
    result=[];i=0
    while i<len(raw):
        assert raw[i:i+4]==b'NOJ1'
        n=struct.unpack_from('!I',raw,i+4)[0];body=raw[i+8:i+8+n];tag=raw[i+8+n:i+40+n]
        assert hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest()==tag
        result.append((i,i+40+n,body));i+=40+n
    return result

def frame(body):return b'NOJ1'+u32(len(body))+body+hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest()

def cases(h,only):
    def case(name,fn):
        if not only or name in only:h.case(name,fn)

    def cancellation():
        a,b,ac,bc,ad,bd=setup(h,'conditional-basic')
        op=submit(h,'conditional-basic-op',a);row,cfg=selection(h,'selected-before',a,op)
        encoded=pending_metadata(row)
        material=b'NATRAV_OVERLAY_OUTBOX_SELECTION_V1\0'+u32(len(encoded))+encoded+bytes([row['condition']['restrictions']])+bytes.fromhex(row['condition']['previous_action_root'])
        h.check(hashlib.sha256(encoded).hexdigest()==row['condition']['metadata_digest'],'independent complete pending metadata encoding')
        h.check(hashlib.sha256(material).hexdigest()==row['condition']['state_digest'],'independent durable selected-state digest')
        wrong=json.loads(json.dumps(row));wrong['condition']['state_digest']='01'*32
        h.check(apply(h,'wrong-state',a,'cancel',wrong,cfg,expected=3)['code']=='OUTBOX_STATE_CONFLICT','mismatched state refused')
        h.check(apply(h,'wrong-config',a,'cancel',row,'02'*32,expected=3)['code']=='OUTBOX_CONFIGURATION_CONFLICT','mismatched config refused')
        ok,bad=raw_control(a/'control.sock',packet('cancel',row,cfg)+b'!')
        h.check(not ok,'strict EOF on independent request')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda _:raw_control(a/'control.sock',packet('cancel',row,cfg)),range(8)))
        h.check(all(ok for ok,_ in results),'all concurrent exact requests return valid outcomes')
        states=[v['status'] for _,v in results]
        h.check(states.count('APPLIED')==1 and states.count('ALREADY_APPLIED')==7,'one committing winner and seven immutable receipts')
        receipt=next(v['accepted_action'] for _,v in results if v['status']=='APPLIED')
        body=packet('cancel',row,cfg)[5:]
        h.check(hashlib.sha256(b'NATRAV_OVERLAY_OUTBOX_ADMIN_REQUEST_V1\0'+u32(os.geteuid())+body).hexdigest()==receipt['request_digest'],'independent owner-bound idempotency digest')
        after,_=selection(h,'selected-after',a,op)
        h.check(after['status']=='CANCELLED' and after['condition']['retained_actions']==1,'effect and receipt both committed')
        n=(a/'state.journal').stat().st_size
        apply(h,'exact-command-repeat',a,'cancel',row,cfg)
        h.check((a/'state.journal').stat().st_size==n,'exact successful repeat writes no event')
        h.run('basic-compact',['compact','--control',str(a/'control.sock')]);ad.shutdown();ad=h.start('basic-restart',ac,a)
        rebuilt,_=selection(h,'basic-rebuilt',a,op)
        h.check(rebuilt['condition']==after['condition'],'semantic selection and action provenance survive compaction/restart')
        h.check(apply(h,'after-restart-repeat',a,'cancel',row,cfg)['status']=='ALREADY_APPLIED','lost-response repeat survives restart')
        h.check(apply(h,'new-cancel-on-terminal',a,'cancel',rebuilt,cfg,reason='different decision',expected=3)['code']=='OUTBOUND_CANCELLED','fresh request cannot cancel again')
        (h.output/'CONCURRENCY.json').write_text(json.dumps({'applied':1,'idempotent':7,'receipt':receipt,'independent_state_digest':row['condition']['state_digest']},indent=2)+'\n')
        ad.shutdown()
    case('independent_encoding_exact_conflicts_concurrent_commit_and_restart',cancellation)

    def retry():
        a,b,ac,bc,ad,bd=setup(h,'conditional-retry',online=True)
        op=submit(h,'retry-denied',a,peer='B',scope='test/denied')
        wait_outcome(h,'retry-rejected',a,op,'REJECTED');old,cfg=selection(h,'retry-old',a,op)
        accepted=apply(h,'conditional-retry',a,'retry',old,cfg)
        h.check(accepted['status']=='APPLIED','rejected work explicitly reopened')
        wait_outcome(h,'new-rejection',a,op,'REJECTED')
        new,_=selection(h,'retry-new',a,op)
        h.check(new['condition']['state_digest']!=old['condition']['state_digest'],'new rejection is not ABA-equivalent')
        repeat=apply(h,'retry-old-receipt',a,'retry',old,cfg)
        h.check(repeat['status']=='ALREADY_APPLIED' and repeat['current_outcome']=='REJECTED','exact repeat reports old effect without replaying into newer rejection')
        h.check(apply(h,'changed-reason-stale',a,'retry',old,cfg,reason='new intent',expected=3)['code']=='OUTBOX_STATE_CONFLICT','different intent cannot reuse stale selection')
        # Legacy mutation remains available, but invalidates the optional semantic selection.
        h.run('legacy-retry',['retry','--control',str(a/'control.sock'),'--operation',op,'--reason','legacy compatibility'])
        wait_outcome(h,'legacy-reject',a,op,'REJECTED')
        h.check(apply(h,'legacy-invalidated',a,'cancel',new,cfg,expected=3)['code']=='OUTBOX_STATE_CONFLICT','legacy transition cannot silently preserve stale conditional state')
        ad.shutdown();bd.shutdown()
    case('new_rejection_aba_legacy_interoperation_and_durable_retry_receipt',retry)

    def rebinding():
        a,b,ac,bc,ad,bd=setup(h,'conditional-key')
        op=submit(h,'conditional-key-op',a);old,cfg=selection(h,'key-old',a,op)
        key=h.identity('C-next')
        nxt=candidate(h,ac,'key-next','key-next-g2',lambda t:t.replace('peer_key=C,c-g1,ACTIVE','peer_key=C,c-g1,RETIRED')+f'peer_key=C,c-g2,ACTIVE,{key.spki_sha256}\n')
        activate(h,'accept-key-change',a,nxt)
        h.check(apply(h,'old-config-rebind',a,'rebind',old,cfg,generation='c-g2',expected=3)['code']=='OUTBOX_CONFIGURATION_CONFLICT','target must belong to selected accepted configuration')
        selected,current=selection(h,'key-current-selection',a,op)
        changed=apply(h,'rebind-current',a,'rebind',selected,current,generation='c-g2')
        h.check(changed['status']=='APPLIED','conditional exact active rebind succeeds')
        after,_=selection(h,'key-after',a,op)
        h.check(after['delivery']['policy']['peer_generation']=='c-g2','durable target binding replaced')
        h.check(apply(h,'prior-binding-stale',a,'cancel',selected,current,expected=3)['code']=='OUTBOX_STATE_CONFLICT','rebind invalidates old state')
        h.run('rebind-compact',['compact','--control',str(a/'control.sock')]);ad.shutdown();ad=h.start('rebind-restart',ac,a)
        h.check(apply(h,'repeat-rebind',a,'rebind',selected,current,generation='c-g2')['status']=='ALREADY_APPLIED','rebind receipt reconstructed under journal-authoritative current config')
        ad.shutdown()
    case('target_key_and_configuration_selection_rebind_and_reconstruction',rebinding)

    def delivered():
        a,b,ac,bc,ad,bd=setup(h,'conditional-delivery')
        op=submit(h,'delivery-between',a,peer='B')
        enabled=candidate(h,ac,'enabled','enabled-g2',lambda t:t.replace('peer_route=B,primary,0,DISABLED','peer_route=B,primary,0,ENABLED'))
        activate(h,'enable-delivery',a,enabled);old,cfg=selection(h,'delivery-before-receipt',a,op)
        bd=h.start('conditional-recipient',bc,b);wait_outcome(h,'durable-receipt',a,op,'ACKED')
        h.check(apply(h,'cancel-after-receipt',a,'cancel',old,cfg,expected=3)['code']=='OUTBOX_STATE_CONFLICT','a real receipt defeats earlier cancellation selection')
        current,cfg=selection(h,'delivery-after-receipt',a,op)
        h.check(apply(h,'cancel-selected-receipt',a,'cancel',current,cfg,expected=3)['code']=='OUTBOUND_ALREADY_ACKED','fresh selector cannot override receipt finality')
        h.check(current['receipt']['operation_id']==op and current['reserved_records']==0,'received evidence remains acknowledged')
        ad.shutdown();bd.shutdown()
    case('actual_peer_receipt_between_inspection_and_cancel',delivered)

    def authority():
        a,b,ac,bc,ad,bd=setup(h,'conditional-authority',delegates=True)
        op=submit(h,'authority-op',a);old,cfg=selection(h,'authority-selection',a,op)
        expose_control_for_uid(a)
        h.check(apply(h,'inspect-cannot-mutate',a,'cancel',old,cfg,uid=65534,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','real INSPECT-only principal cannot administer')
        body=packet('cancel',old,cfg);sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);sock.settimeout(8);sock.connect(str(a/'control.sock'))
        sock.sendall(u32(len(body))+body[:-1])
        removed=candidate(h,ac,'remove-maintenance','remove-maintenance-g2',lambda t:t.replace(f'local_control={os.geteuid()},ALL',f'local_control={os.geteuid()},INSPECT,SUBMIT,CONFIGURATION,SHUTDOWN'))
        activate(h,'revoke-maintenance',a,removed);sock.sendall(body[-1:]);sock.shutdown(socket.SHUT_WR)
        n=struct.unpack('!I',receive_exact(sock,4))[0];response=receive_exact(sock,n);sock.close()
        h.check(response[4]==1 and json.loads(response[5:])['code']=='LOCAL_CONTROL_CLASS_DENIED','slow request governed by authority after read')
        h.check(selection(h,'authority-still-pending',a,op)[0]['status']=='PENDING','revocation does not mutate operation')
        restore_owner_only_control(a);ad.shutdown()
    case('real_uid_maintenance_boundary_and_live_revocation',authority)

    def maintenance():
        a,b,ac,bc,ad,bd=setup(h,'conditional-maintenance')
        op=submit(h,'maintenance-op',a);old,cfg=selection(h,'maintenance-selected',a,op)
        accepted=apply(h,'maintenance-commit',a,'cancel',old,cfg);ad.shutdown()
        key=new_key(h,h.work,'conditional-state');migrate(h,'conditional-migrate',a,key)
        ad=start_keyed(h,'conditional-keyed',ac,a,key)
        # Append a fresh kind-35 authenticated record, so audit tests the new decoder bound.
        op2=submit(h,'maintenance-second',a);row,cfg2=selection(h,'maintenance-second-select',a,op2);apply(h,'maintenance-second-cancel',a,'cancel',row,cfg2);ad.shutdown()
        audit=h.run('conditional-auth-audit',['state-auth-audit','--state',str(a),'--node','A','--state-auth-key',str(key)])
        ad=start_keyed(h,'conditional-compact-owner',ac,a,key);h.run('conditional-compact',['compact','--control',str(a/'control.sock')]);ad.shutdown()
        before=inspect(h,'conditional-backup-before',a,key)
        crypt=h.work/'conditional-backup.key';h.run('conditional-backup-key',['backup-key-init','--output',str(crypt),'--generation','conditional-archive'])
        ident=h.identity('A');archive=h.work/'conditional.nob'
        h.run('conditional-export',['backup-export','--state',str(a),'--node','A','--generation','a-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'conditional-restored';h.run('conditional-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'conditional-restored-state',restored,key);h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'conditional history included in logical backup identity')
        moved=candidate(h,ac,'conditional-moved','conditional-moved-g2',lambda t:t.replace('state='+str(a),'state='+str(restored)))
        h.run('conditional-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','explicit owned move','--state-auth-key',str(key)])
        ad=start_keyed(h,'conditional-restored-owner',moved,restored,key)
        repeat=apply(h,'old-command-after-relocation',restored,'cancel',old,cfg)
        h.check(repeat['status']=='ALREADY_APPLIED' and repeat['accepted_action']==accepted['accepted_action'],'historical exact receipt survives path relocation without repeating effect')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'logical_state_preserved':True,'historical_action':repeat['accepted_action'],'audit':audit},indent=2)+'\n');ad.shutdown()
    case('keyed_new_record_audit_compaction_encrypted_restore_and_relocation',maintenance)

    def kills():
        for phase in ('BEFORE','AFTER'):
            a,b,ac,bc,ad,bd=setup(h,'kill-'+phase.lower());op=submit(h,'kill-'+phase,a);old,cfg=selection(h,'kill-select-'+phase,a,op);ad.shutdown()
            ad=h.start('kill-hook-'+phase,ac,a,{f'NATRAV_OVERLAY_TEST_OUTBOX_CONDITION_{phase}_COMMIT_MS':'3000'})
            log=h.logs/f'kill-command-{phase}.txt'
            with log.open('w') as out:
                client=subprocess.Popen([str(h.binary),*args(a,'cancel',old,cfg)],stdout=out,stderr=subprocess.STDOUT)
                h.wait('conditional commit hook '+phase,lambda:f'OUTBOX_CONDITION_{phase}_COMMIT' in ad.stderr_path.read_text(),timeout=8)
                ad.kill();client.wait(timeout=8)
            ad=h.start('kill-recovered-'+phase,ac,a);restored,_=selection(h,'kill-recovered-state-'+phase,a,op)
            h.check(restored['status']==('PENDING' if phase=='BEFORE' else 'CANCELLED'),'crash boundary effect')
            repeated=apply(h,'kill-command-recovery-'+phase,a,'cancel',old,cfg)
            h.check(repeated['status']==('APPLIED' if phase=='BEFORE' else 'ALREADY_APPLIED'),'crash boundary receipt coupled to effect');ad.shutdown()
    case('real_sigkill_before_and_after_atomic_action_receipt',kills)

    def corruption():
        a,b,ac,bc,ad,bd=setup(h,'conditional-corrupt');op=submit(h,'corrupt-op',a);old,cfg=selection(h,'corrupt-before',a,op);apply(h,'corrupt-commit',a,'cancel',old,cfg);ad.shutdown()
        journal=a/'state.journal';original=journal.read_bytes();frames=journal_frames(original);idx=next(i for i,(_,_,b) in enumerate(frames) if b[0]==35)
        start,end,body=frames[idx];mut=bytearray(body);at=body.index(bytes.fromhex(old['condition']['state_digest']));mut[at]^=1
        journal.write_bytes(original[:start]+frame(mut)+original[end:])
        bad=h.run('forged-selected-state',['inspect','--state',str(a),'--node','A'],expected=3)
        h.check(bad['code'] in ('JOURNAL_CORRUPT','OUTBOX_CONDITION_INVALID'),'recomputed outer checksum cannot bypass selected-state semantics')
        journal.write_bytes(original);ad=h.start('corruption-restored',ac,a);h.run('corruption-compact',['compact','--control',str(a/'control.sock')]);ad.shutdown()
        # Corrupt retained command expectation inside canonical checkpoint. Both
        # its logical hash and outer checksum are recomputed independently.
        checkpoint=journal.read_bytes();body=bytearray(journal_frames(checkpoint)[0][2]);pos=body.index(bytes.fromhex(old['condition']['state_digest']));body[pos]^=1
        # Checkpoint layout is NCP3 marker/schema/generation/time + accounts +
        # logical digest + logical length + NLS2 bytes.
        loc=body.index(b'NLS2');logical=bytes(body[loc:]);body[loc-48:loc-16]=hashlib.sha256(b'NATRAV_OVERLAY_LOGICAL_STATE_V2\0'+logical).digest()
        journal.write_bytes(frame(body));bad=h.run('forged-checkpoint-condition',['inspect','--state',str(a),'--node','A'],expected=3)
        h.check(bad['code'] in ('JOURNAL_CORRUPT','OUTBOX_CONDITION_INVALID') and 'header is invalid' not in bad.get('message',''),'checkpoint rejects forged conditional history beyond recomputed logical header')
        journal.write_bytes(checkpoint)
    case('semantic_journal_and_checkpoint_corruption_after_checksum_recomputation',corruption)

    def lineage():
        from run_subscribed_source_views import setup as source_setup
        from run_source_subscriptions import command
        from run_local_evidence import author
        a,c,ac,cc,ad,cd,subscription=source_setup(h,'conditional-source')
        disabled=candidate(h,ac,'source-route-disabled','source-route-disabled-g2',lambda t:t.replace('peer_route=C,primary,0,ENABLED','peer_route=C,primary,0,DISABLED'))
        activate(h,'source-disable-route',a,disabled);cd.shutdown()
        author(h,'conditional-private-source',a,ticks=25)
        issued=command(h,'conditional-source-issue',a,'step',previous=subscription)
        op=issued['latest']['operation_id'];row,cfg=selection(h,'source-bound-selection',a,op)
        h.check(row['status']=='PENDING' and row['condition']['restrictions']&1,'source-grant binding is in semantic selector')
        h.check(apply(h,'source-key-rebind-refused',a,'rebind',row,cfg,generation='c-g1',expected=3)['code']=='OUTBOUND_SOURCE_SUBSCRIPTION_BOUND','condition never bypasses exact source grant')
        apply(h,'source-pending-cancel',a,'cancel',row,cfg)
        h.check(command(h,'source-retained-state',a,'status')['acknowledged']==0,'cancellation does not fabricate source acknowledgment');ad.shutdown()
        from run_projection_publication import topology
        from run_numeric_projection import produce,create,consume
        from run_publication_channels import channel_create,channel_publish,channel_status
        from run_publication_epochs import new_epoch
        a,b,c,ac,bc,cc,ad,bd,cd=topology(h,'conditional-epoch',allow_output=False)
        values={};produce(h,'conditional-epoch-input',a,values,ticks=77);create(h,'conditional-epoch-projection',b)
        projection,_=consume(h,'conditional-epoch-process',b,values)
        channel=channel_create(h,'conditional-channel-create',b,projection,maximum=4)['channel']
        first=channel_publish(h,'conditional-channel-head',b,channel,projection)
        wait_outcome(h,'conditional-head-rejected',b,first['operation_id'],'REJECTED')
        old,cfg=selection(h,'before-epoch-adoption',b,first['operation_id'])
        channel=channel_status(h,'conditional-channel-rejected',b)['channel']
        new_epoch(h,'conditional-epoch-adopt',b,channel,projection,outcome='REJECTED',reason='explicit discontinuity')
        h.check(apply(h,'stale-before-adoption',b,'retry',old,cfg,expected=3)['code']=='OUTBOX_STATE_CONFLICT','adoption changes selection even without old-outbox mutation')
        current,cfg=selection(h,'after-epoch-adoption',b,first['operation_id'])
        h.check(current['condition']['restrictions']&2,'adopted predecessor visible in selection')
        h.check(apply(h,'cannot-revive-adopted',b,'retry',current,cfg,expected=3)['code']=='OUTBOUND_ADOPTED_PREDECESSOR','fresh condition cannot revive an epoch terminal')
        ad.shutdown();bd.shutdown();cd.shutdown()
    case('source_grant_and_adopted_epoch_constraints_remain_authoritative',lineage)

    def bounds():
        a,b,ac,bc,ad,bd=setup(h,'conditional-bounds',online=True);op=submit(h,'bounds-denied',a,peer='B',scope='test/denied')
        for i in range(32):
            wait_outcome(h,'bounds-rejected-'+str(i),a,op,'REJECTED');row,cfg=selection(h,'bounds-selected-'+str(i),a,op)
            apply(h,'bounds-retry-'+str(i),a,'retry',row,cfg,reason='bounded retry '+str(i))
        wait_outcome(h,'bounds-final-rejection',a,op,'REJECTED');last,cfg=selection(h,'bounds-final-selection',a,op)
        h.check(last['condition']['retained_actions']==32,'exact per-operation retained history ceiling')
        h.check(apply(h,'bounds-first-excess',a,'retry',last,cfg,expected=3)['code']=='OUTBOX_ADMIN_HISTORY_LIMIT','first excess rejected without action')
        h.run('bounds-compact',['compact','--control',str(a/'control.sock')]);ad.shutdown();ad=h.start('bounds-restart',ac,a)
        last,cfg=selection(h,'bounds-rebuilt',a,op);h.check(last['condition']['retained_actions']==32,'history bound survives compaction restart')
        ad.shutdown();bd.shutdown()
    case('finite_conditional_receipt_registry_boundary',bounds)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    try:cases(h,set(a.case) if a.case else None);ok=True
    except BaseException as exc:(h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(f'FAIL: {type(exc).__name__}: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_CONDITIONAL_OUTBOX_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
