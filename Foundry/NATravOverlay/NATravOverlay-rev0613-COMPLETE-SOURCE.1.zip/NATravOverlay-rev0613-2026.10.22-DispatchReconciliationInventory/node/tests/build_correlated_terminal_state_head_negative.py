#!/usr/bin/env python3
"""Prepare a weakened build whose kind-46 request identity omits correlation."""
from __future__ import annotations

import argparse
import difflib
import json
from pathlib import Path
import shutil


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    out = args.output.resolve()
    if out.exists() or out == root or root in out.parents:
        parser.error("output must be a new path outside the product")
    tree = out / "source"
    tree.mkdir(parents=True)
    for part in ("node/src", "foundation/src", "foundation/include"):
        shutil.copytree(root / part, tree / part)
    shutil.copy2(root / "node/build.sh", tree / "node/build.sh")

    path = tree / "node/src/control.cpp"
    before = path.read_text()
    anchor = '''datacube::Digest32 control_request_id(const datacube::OctetView payload) {
    datacube::Octets material;
    datacube::append_text(material, "NATRAV_OVERLAY_CONTROL_REQUEST_ID_V1");
    datacube::append_u8(material, 0U);
    datacube::append_be64(material, static_cast<std::uint64_t>(payload.size()));
    datacube::append_octets(material, payload);
    return datacube::sha256(material);
}'''
    replacement = '''datacube::Digest32 control_request_id(const datacube::OctetView payload) {
    datacube::Octets material;
    datacube::append_text(material, "NATRAV_OVERLAY_CONTROL_REQUEST_ID_V1");
    datacube::append_u8(material, 0U);
    // DELIBERATE NEGATIVE CONTROL: omit the kind-46 correlation bytes.
    const auto identity_payload = payload.size() >= 5U &&
        payload[4] == static_cast<std::uint8_t>(ControlKind::shutdown_final_head_correlated) ?
        payload.first(5U) : payload;
    datacube::append_be64(material, static_cast<std::uint64_t>(identity_payload.size()));
    datacube::append_octets(material, identity_payload);
    return datacube::sha256(material);
}'''
    if before.count(anchor) != 1:
        raise SystemExit("release request-identity boundary not found exactly once")
    after = before.replace(anchor, replacement, 1)
    path.write_text(after)
    patch = out / "OMIT-CORRELATION-FROM-TERMINAL-REQUEST-ID.patch"
    patch.write_text("".join(difflib.unified_diff(
        before.splitlines(True), after.splitlines(True),
        fromfile="normal/control.cpp", tofile="negative/control.cpp",
    )))
    print(json.dumps({
        "format": "NATRAV_OVERLAY_CORRELATED_TERMINAL_NEGATIVE_PREPARATION_V1",
        "status": "PREPARED_NOT_BUILT",
        "source": str(tree),
        "patch": str(patch),
    }))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
