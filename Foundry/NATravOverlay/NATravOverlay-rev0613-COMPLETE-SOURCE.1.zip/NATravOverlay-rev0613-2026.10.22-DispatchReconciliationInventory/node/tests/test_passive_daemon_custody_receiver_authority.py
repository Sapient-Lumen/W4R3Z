#!/usr/bin/env python3
"""Static authority audit for the V23 passive ordinary-daemon receiver."""
from pathlib import Path

root = Path(__file__).resolve().parents[2]
source = root / "node/src"
policy_h = (source / "custody_receiver_policy.hpp").read_text()
policy_c = (source / "custody_receiver_policy.cpp").read_text()
config_h = (source / "config.hpp").read_text()
config_c = (source / "config.cpp").read_text()
runtime_c = (source / "runtime.cpp").read_text()
service_h = (source / "custody_session_service.hpp").read_text()
service_c = (source / "custody_session_service.cpp").read_text()
daemon_c = (source / "daemon.cpp").read_text()
main_c = (source / "main.cpp").read_text()
build = (root / "node/build.sh").read_text()
matrix = (root / "node/tests/run_matrix.py").read_text()
integration = (root / "node/tests/run_passive_daemon_custody_receiver.py").read_text()

passive_body = service_c.split(
    "CustodyTransferAcceptance PassiveCustodyReceiver::receive", 1)[1].split(
    "CustodyOwnerDispatcher::CustodyOwnerDispatcher", 1)[0]
daemon_handler = daemon_c.split(
    "const CustodySessionHandler custody_handler", 1)[1].split(
    "const auto outcome = handle_secure_peer_connection", 1)[0]

required = {
    "V23 feature name":
        "V23_PASSIVE_DAEMON_CUSTODY_RECEIVER_V1" in policy_h,
    "V23 configuration header":
        "NATRAV_OVERLAY_CONFIG_V23" in config_c,
    "canonical V23 record":
        "custody_receiver_hex" in config_c and
        "NATRAV_CUSTODY_RECEIVER_ACTIVATION_V1" in policy_c,
    "default-off retained policy":
        "CustodyReceiverPolicy custody_receivers" in config_h and
        "CUSTODY_RECEIVER_DISABLED" in passive_body,
    "exact V22 commitment":
        "session_rule_commitment" in policy_h and
        "custody_session_rule_commitment(*rule)" in policy_c,
    "finite activation bounds": all(token in policy_h for token in (
        "kCustodyReceiverActivationLimit",
        "kCustodyReceiverActivationPerIdLimit",
        "kCustodyReceiverMaximumInflightOffers")),
    "explicit lifecycle": all(token in policy_h for token in (
        "active = 1U", "retired = 2U", "revoked = 3U")),
    "monotonic lifecycle history":
        "require_custody_receiver_history_preserved" in policy_c and
        "CONFIG_CUSTODY_RECEIVER_STATE_ROLLBACK" in policy_c,
    "V23 downgrade rejection":
        runtime_c.count("CONFIG_CUSTODY_RECEIVER_DOWNGRADE") >= 2,
    "accepted history replay":
        runtime_c.count("require_custody_receiver_history_preserved") >= 2,
    "exact next-hop role":
        "CONFIG_CUSTODY_RECEIVER_LOCAL_ROLE" in config_c and
        "passive daemon receipt requires the exact V21 next-hop endpoint" in service_c,
    "V23 cannot outlive V22":
        "activation.activation_expires_unix_ms >" in config_c and
        "rule.authority_expires_unix_ms" in config_c,
    "ordinary worker reservation":
        "CONFIG_CUSTODY_RECEIVER_FAIRNESS" in config_c and
        "activation.maximum_inflight_offers >= config.peer_workers" in config_c,
    "single passive object":
        daemon_c.count("PassiveCustodyReceiver passive_custody_receiver") == 1,
    "existing daemon NOS1 dispatch":
        "handle_secure_peer_connection(" in daemon_c and
        "custody_handler" in daemon_c and
        "passive_custody_receiver.receive" in daemon_c,
    "per-operation live lease":
        "auto held = runtime.lease();" in daemon_handler and
        "*held->config" in daemon_handler,
    "drain-aware receipt":
        "SERVICE_DRAINING" in daemon_handler and
        "peer_admissions_accepted" in daemon_handler,
    "no passive route selector":
        "options.route_id" not in passive_body and
        "ServiceOperation::passive_receive" in passive_body,
    "no passive sender invocation":
        "run_custody_session_send" not in daemon_c,
    "no passive export invocation":
        "run_custody_session_export" not in daemon_c,
    "no added passive listener":
        "listen_transport" not in daemon_handler and
        "listen_tcp" not in daemon_handler and
        "listen_unix" not in daemon_handler,
    "no receiver-owned service thread":
        "std::thread" not in daemon_handler and
        "emplace_back" not in daemon_handler,
    "bounded concurrent admission":
        "compare_exchange_weak" in passive_body and
        "CUSTODY_RECEIVER_BUSY" in passive_body and
        "InflightGuard" in passive_body,
    "revocation rejects replay":
        "CUSTODY_RECEIVER_REVOKED" in passive_body and
        passive_body.index("CUSTODY_RECEIVER_REVOKED") <
            passive_body.index("acceptance.bin"),
    "retirement and expiry replay exact only":
        "activation_can_create" in passive_body and
        "regular_file_exists(directory / \"acceptance.bin\")" in passive_body and
        "CUSTODY_RECEIVER_RETIRED" in passive_body,
    "same durable receiver implementation":
        "return receive_offer(state_, authority, session, message);" in passive_body,
    "same V22 certificate checks":
        "require_tls_peer(authority, session);" in service_c and
        "CUSTODY_SESSION_PEER_CERTIFICATE_MISMATCH" in service_c and
        "CUSTODY_SESSION_LOCAL_CERTIFICATE_MISMATCH" in service_c,
    "same custody journal":
        "commit_acceptance(state, authority" in service_c and
        "NodeState& state_" in service_h,
    "negative authority markers": all(token in main_c for token in (
        r'\"passive_daemon_custody_receiver\":true',
        r'\"automatic_custody_sender\":false',
        r'\"automatic_route_relay\":false',
        r'\"open_relay\":false')),
    "service negative marker":
        r'\"automatic_custody_sender\":false' in service_c,
    "single binary build":
        "src/custody_receiver_policy.cpp" in build and
        "bin/natrav-overlay" in build,
    "registered integration suite":
        '"passive_daemon_custody_receiver"' in matrix,
    "required live and crash coverage": all(token in integration for token in (
        "default_off_and_live_activation_on_existing_session",
        "bounded_fairness_and_concurrent_ordinary_progress",
        "response_loss_process_death_restart_and_stale_seed",
        "retirement_revocation_inflight_restart_and_expiry")),
}

failed = [name for name, passed in required.items() if not passed]
if failed:
    raise SystemExit("FAIL: " + ", ".join(failed))
print(f"PASS: {len(required)} passive daemon custody authority checks")
