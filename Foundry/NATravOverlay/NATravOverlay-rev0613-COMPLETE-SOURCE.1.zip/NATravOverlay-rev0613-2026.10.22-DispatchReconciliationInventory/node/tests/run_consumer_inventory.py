#!/usr/bin/env python3
"""Owned current inventory: native C++ state, exact authority, and independent wire/digest checks."""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, shutil, struct, subprocess, sys, time
from pathlib import Path
from run_persistent import Harness, free_port, raw_control
from run_consumers import call as consumer
from run_projections import config, trio, create as summary_create, call as summary, read
from run_numeric_projection import create as numeric_create, produce
from run_automatic_projections import enable, wait_position
from run_consumer_retirement import retire
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_live_configuration import candidate, activate
from run_state_authentication import new_key, migrate, start as keyed_start, inspect

FORMAT='NATRAV_OVERLAY_CONSUMER_INVENTORY_V1'
def save(h,name,data): (h.output/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
def query(h,label,b,expected=0,uid=None,**kw):
    args=['consumer-inventory','--control',str(b/'control.sock'),'--deadline-ms','4000']
    for k,v in kw.items():args+=['--'+k.replace('_','-'),str(v)]
    r=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    if expected==0:
        h.check(r['format']==FORMAT and r['owner_uid']==(os.geteuid() if uid is None else uid),'native format and kernel owner')
        h.check(r['work']['snapshot_calls']==0 and r['work']['snapshot_payload_bytes']==0 and r['work']['logical_bytes_serialized']==0,'no whole-state snapshot or logical serialization')
        h.check(r['work']['evidence_records_visited']==0 and r['work']['consumer_histories_serialized']==0,'no source reads or full consumer/result-history serialization')
        h.check(r['returned']==len(r['records']) and r['next_offset']==r['offset']+r['returned'],'exact page boundaries')
        h.check(all(x['owner_uid']==r['owner_uid'] for x in r['records']),'no other owner rows')
    return r

def txt(s): b=s.encode();return struct.pack('!H',len(b))+b
def opt(s):return b'\x01'+bytes.fromhex(s) if s else b'\0'
def wire(*,kind='all',lifecycle='all',name='',issuer='',scope='',instance=None,offset=0,limit=16,max_bytes=32768,selection=None):
    return b'NOC1\x24CIN1'+b''.join(map(txt,[kind,lifecycle,name,issuer,scope]))+opt(instance)+struct.pack('!III',offset,limit,max_bytes)+opt(selection)
def root_for(response,rows,**kw):
    seed=b'NATRAV_OVERLAY_CONSUMER_INVENTORY_SELECTION_V1\0'+txt(response['node'])+struct.pack('!I',response['owner_uid'])
    seed+=bytes.fromhex(response['authorized_configuration_digest'])+bytes.fromhex(response['read_authority_digest'])
    seed+=b''.join(txt(kw.get(k,d)) for k,d in [('kind','all'),('lifecycle','all'),('name',''),('issuer',''),('scope','')])
    seed+=opt(kw.get('instance'))+struct.pack('!I',len(rows));root=hashlib.sha256(seed).digest()
    for r in rows:
        b=json.dumps(r,separators=(',',':'),ensure_ascii=True).encode()
        root=hashlib.sha256(b'NATRAV_OVERLAY_CONSUMER_INVENTORY_ROW_V1\0'+root+struct.pack('!I',len(b))+b).digest()
    return root.hex()
def check_row(h,row,c):
    for a,b in [('name','name'),('instance','instance'),('owner_uid','owner_uid'),('consumer_revision','revision'),('epoch','epoch'),
        ('acknowledged_sequence','acknowledged_sequence'),('acknowledgments','acknowledgments'),('issuer_filter','issuer_filter'),
        ('scope_filter','scope_filter'),('payload_included','payload_included'),('payload_length','payload_length'),('limit','limit'),('max_bytes','max_bytes'),('lifecycle','lifecycle')]:
        h.check(row[a]==c[b],'exact stored metadata '+a)
    h.check('result' not in json.dumps(row) or row['projection'] is not None,'no stray result fields')
    h.check('adoptions' not in row and 'projection_result_digest' not in row and 'reason' not in json.dumps(row),'no source/result histories or reason text')
    if row['projection']:
        h.check(row['projection']['definition_digest']==c['projection']['definition_digest'] and not row['projection']['result_included'],'immutable definition only')
    if c['pending_batch']:
        for key in ('id','from','through','configuration_event'):h.check(row['pending_batch'][key]==c['pending_batch'][key],'exact pending boundary '+key)

def cases(h,selected=None):
    def case(n,fn):
        if selected is None or n in selected:h.case(n,fn)
    def basic():
        b=h.runtime/'basic';cfg=config(h,'basic',b,free_port());d=h.start('basic',cfg,b)
        q=query(h,'empty',b);h.check(q['selected_total']==0 and q['selection_digest']==root_for(q,[]),'empty selection commitment')
        vals={}
        vals['zebra']=consumer(h,'zebra-create',b,'create','zebra',issuer='A',scope='query/series',reason='name-order source',limit=2)['consumer']
        vals['alpha']=summary_create(h,'alpha-create',b,'alpha',limit=2)['consumer']
        vals['number']=numeric_create(h,'numeric-create',b,'number',limit=2)['consumer']
        vals['retained']=consumer(h,'retained-create',b,'create','retained',issuer='A',scope='query/series',reason='terminal identity')['consumer']
        retire(h,'retained-retire',b,'retained');vals['retained']=consumer(h,'retained-exact',b,'status','retained')['consumer']
        allrows=query(h,'all',b);h.check([r['name'] for r in allrows['records']]==sorted(vals),'byte-lexicographic authorized name order')
        for r in allrows['records']:check_row(h,r,vals[r['name']])
        h.check(root_for(allrows,allrows['records'])==allrows['selection_digest'],'independent full selection digest')
        first=query(h,'first',b,limit=1);second=query(h,'second',b,offset=first['next_offset'],selection=first['selection_digest'],limit=32,max_bytes=60000)
        h.check(first['records']+second['records']==allrows['records'],'page budgets can change without changing selection')
        for kind,names in [('consumer',['retained','zebra']),('projection',['alpha','number']),('metadata',['alpha']),('numeric',['number'])]:
            f=query(h,'filter-'+kind,b,kind=kind);h.check([r['name'] for r in f['records']]==names,'exact kind filter')
            h.check(root_for(f,f['records'],kind=kind)==f['selection_digest'],'kind-bound root')
        h.check(query(h,'only-retired',b,lifecycle='retired')['selected_total']==1,'retired visible without revival')
        exact=query(h,'exact',b,name='number',instance=vals['number']['instance']);h.check(exact['selected_total']==1,'exact conjunctive name/instance')
        h.check(query(h,'wrong-instance',b,name='number',instance='21'*32)['selected_total']==0,'mismatch is empty')
        h.check(query(h,'empty-scope',b,scope='no/match')['selected_total']==0,'scope selector exact, not prefix')
        before=(b/'state.journal').read_bytes()
        for i in range(8):query(h,'observational-'+str(i),b,name='missing')
        h.check(before==(b/'state.journal').read_bytes(),'successful inventory does not append')
        ok,v=raw_control(d.control,wire());h.check(ok and v['records']==allrows['records'],'independent CIN1 wire')
        for bad in [wire()+b'x',wire()[:-1],wire().replace(b'CIN1',b'CIN2'),wire(kind='*'),wire(lifecycle='running'),wire(limit=0),wire(limit=33),wire(max_bytes=2047),wire(offset=1),wire(name='../x')]:
            ok,e=raw_control(d.control,bad);h.check(not ok,'strict encoding/limits '+repr(bad[-8:]))
        false=query(h,'false-selection',b,selection='12'*32,expected=3);h.check(false['code']=='CONSUMER_INVENTORY_SELECTION_MISMATCH','selected metadata bound')
        too_small=query(h,'small-first',b,name='number',max_bytes=2048,expected=3);h.check(too_small['code']=='CONSUMER_INVENTORY_PAGE_TOO_SMALL','no partial first row')
        bounded=query(h,'byte-bound',b,limit=32,max_bytes=4096);h.check(0<bounded['returned']<4,'whole nonfitting row retained for continuation')
        h.check(len(json.dumps(bounded,separators=(',',':')).encode())<=4096,'annotation inside byte limit')
        h.run('compact-basic',['compact','--control',str(d.control)]);d.shutdown();d=h.start('restart-basic',cfg,b)
        again=query(h,'restart-selection',b,selection=allrows['selection_digest']);h.check(again['records']==allrows['records'],'same metadata rebuilds same selection after compaction/restart')
        save(h,'BASIC',{'all':allrows,'byte_page':bounded,'restart':again});d.shutdown()
    case('strict_wire_exact_filters_summary_equality_and_paging',basic)

    def progress():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'progress');values={}
        consumer(h,'ordinary-create',b,'create','plain',issuer='A',scope='query/series',reason='manual cursor',limit=1)
        summary_create(h,'worker-create',b,'summary',limit=1)
        original=query(h,'before-arrival',b,limit=1)
        produce(h,'arriving',a,values,ticks=10)
        h.check(query(h,'arrival-no-implicit-progress',b,selection=original['selection_digest'])['selected_total']==2,'unprocessed incoming evidence alone changes no registry summary')
        issued=consumer(h,'issue',b,'read','plain')['consumer'];stale=query(h,'issue-stale',b,selection=original['selection_digest'],offset=1,expected=3)
        h.check(stale['code']=='CONSUMER_INVENTORY_SELECTION_MISMATCH','issued page invalidates selected metadata')
        selected_plain=query(h,'plain-selected',b,name='plain');check_row(h,selected_plain['records'][0],issued)
        enable(h,'worker-enable',b,'summary',max_pages=8,min_interval_ms=10);wait_position(h,b,'summary',1)
        h.check(query(h,'other-consumer-progress',b,name='plain',selection=selected_plain['selection_digest'])['records']==selected_plain['records'],'unselected processing does not invalidate exact-name page')
        worker=query(h,'worker-one',b,name='summary');h.check(worker['records'][0]['acknowledged_sequence']==1,'automatically processed frontier visible')
        produce(h,'second-arrival',a,values,ticks=5);wait_position(h,b,'summary',2)
        h.check(query(h,'worker-stale',b,name='summary',selection=worker['selection_digest'],expected=3)['code']=='CONSUMER_INVENTORY_SELECTION_MISMATCH','selected automatic progress invalidates')
        consumer(h,'ack-issued',b,'ack','plain',batch=issued['pending_batch']['id'])
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            rows=list(pool.map(lambda i:query(h,'parallel-read-'+str(i),b),range(8)))
        h.check(all(r['records']==rows[0]['records'] for r in rows),'concurrent pure reads same bounded metadata')
        before_retire=query(h,'before-retire',b);retire(h,'retire-worker',b,'summary')
        h.check(query(h,'retire-stale',b,selection=before_retire['selection_digest'],expected=3)['code']=='CONSUMER_INVENTORY_SELECTION_MISMATCH','retirement invalidates selection')
        term=query(h,'terminal-summary',b,kind='projection',lifecycle='retired');h.check(term['records'][0]['acknowledged_sequence']==2 and term['records'][0]['retirement'] is not None,'terminal metadata preserves final frontier')
        journal=(b/'state.journal').read_bytes();h.run('quiesce-query',['quiesce','--control',str(bd.control),'--reason','inventory quiescence'])
        stopped=(b/'state.journal').read_bytes();query(h,'quiesced-inventory',b);h.check(stopped==(b/'state.journal').read_bytes(),'quiesced read observational')
        h.run('resume-query',['resume','--control',str(bd.control),'--reason','resume'])
        save(h,'PROGRESS',{'issued':selected_plain,'worker':worker,'retired':term,'parallel_reads':len(rows),'journal_existed':bool(journal)})
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('mutable_progress_automatic_processing_retirement_and_observational_reads',progress)

    def ownership():
        b=h.runtime/'owners';cfg=config(h,'owners',b,free_port(),True);d=h.start('owners',cfg,b);expose_control_for_uid(b)
        consumer(h,'uid-one',b,'create','shared',uid=65534,issuer='A',scope='query/series',reason='first owner')
        one=query(h,'owned-one',b,uid=65534)
        consumer(h,'uid-two',b,'create','shared',uid=65533,issuer='A',scope='query/series',reason='another owner')
        two=query(h,'owned-two',b,uid=65533)
        still=query(h,'hidden-owner-unchanged',b,uid=65534,selection=one['selection_digest'])
        h.check(one['records']==still['records'] and one['selection_digest']==still['selection_digest'],'other UID has no count/ordinal/root effect')
        h.check(one['records'][0]['instance']!=two['records'][0]['instance'],'same names are not same instance across owners')
        for val in [two['records'][0]['instance'],'41'*32]:
            q=query(h,'hidden-exact-'+val[:5],b,uid=65534,instance=val)
            h.check(q['selected_total']==q['returned']==q['work']['authorized_summaries_hashed']==0,'hidden exact same absence fields as missing')
        h.check(query(h,'uid-selection-rejected',b,uid=65533,selection=one['selection_digest'],expected=3)['code']=='CONSUMER_INVENTORY_SELECTION_MISMATCH','digest is bound to actual owner')
        # Projection command authority removed without changing metadata read domains.
        meta=summary_create(h,'delegate-projection',b,'hidden-projection',uid=65534)
        removed=candidate(h,cfg,'projection-revoke','owners-g2',lambda t:t.replace('local_control=65534,EVIDENCE_READ,CONSUMER,PROJECTION','local_control=65534,EVIDENCE_READ,CONSUMER'))
        h.check(removed.read_text()!=cfg.read_text(),'candidate changes projection grant')
        activate(h,'projection-revoked',b,removed)
        shown=query(h,'metadata-only-consumer',b,uid=65534)
        h.check([x['name'] for x in shown['records']]==['shared'],'revoked projection class hides projection without exposing count')
        hidden=query(h,'hidden-projection-exact',b,uid=65534,name='hidden-projection');h.check(hidden['selected_total']==0,'exact name does not bypass class')
        # An authority-domain change cannot expose old progress; new registration uses current authority.
        changed=candidate(h,removed,'domain-change','owners-g3',lambda t:t.replace('evidence_read=65534,A,query/series,METADATA','evidence_read=65534,A,query/other,METADATA'))
        activate(h,'domain-changed',b,changed)
        h.check(query(h,'old-authority-hidden',b,uid=65534)['selected_total']==0,'old selection/progress not disclosed under changed domains')
        consumer(h,'new-domain',b,'create','fresh',uid=65534,issuer='A',scope='query/other',reason='new authorized selection')
        current=query(h,'new-domain-visible',b,uid=65534);h.check([r['name'] for r in current['records']]==['fresh'],'current authority inventory')
        script="""import socket,struct,sys,json
s=socket.socket(socket.AF_UNIX);s.settimeout(8);s.connect(sys.argv[1]);p=bytes.fromhex(sys.argv[2]);s.sendall(struct.pack('!I',len(p))+p[:2]);print('READY',flush=True);sys.stdin.readline();s.sendall(p[2:]);s.shutdown(socket.SHUT_WR)
def read(n):
 b=b''
 while len(b)<n:
  x=s.recv(n-len(b))
  if not x:raise RuntimeError('EOF')
  b+=x
 return b
r=read(struct.unpack('!I',read(4))[0]);print(json.dumps({'ok':r[4]==0,'body':json.loads(r[5:])}))
"""
        p=subprocess.Popen(['/usr/bin/setpriv','--reuid=65534','--regid=65534','--clear-groups',sys.executable,'-c',script,str(d.control),wire().hex()],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            h.check(p.stdout.readline().strip()=='READY','actual UID partial request')
            revoked=candidate(h,changed,'consumer-revoke','owners-g4',lambda t:t.replace('local_control=65534,EVIDENCE_READ,CONSUMER','local_control=65534,EVIDENCE_READ'))
            activate(h,'consumer-revoked',b,revoked);out,err=p.communicate('\n',timeout=10);denial=json.loads(out.splitlines()[-1])
            h.check(p.returncode==0 and not denial['ok'] and denial['body']['code']=='LOCAL_CONTROL_CLASS_DENIED','post-decode current authority rejects slow request')
        finally:
            if p.poll() is None:p.kill();p.wait()
        restore_owner_only_control(b);save(h,'PRINCIPALS',{'first':one,'other':two,'after_projection_revocation':shown,'after_domain_change':current,'slow_denial':denial});d.shutdown()
    case('actual_uid_isolation_class_and_domain_revocation',ownership)

    def capacity():
        b=h.runtime/'capacity';cfg=config(h,'capacity',b,free_port());d=h.start('capacity',cfg,b)
        # 64 retired names remain reserved; sixteen further active names remain usable.
        for i in range(64):
            name=f'retired-{i:02}';consumer(h,'make-'+name,b,'create',name,issuer='A',scope='query/series',reason='retained history');retire(h,'stop-'+name,b,name)
        for i in range(16):consumer(h,f'active-{i:02}',b,'create',f'active-{i:02}',issuer='A',scope='query/series',reason='active capacity')
        first=query(h,'capacity-first',b,limit=32,max_bytes=60000);rows=first['records'];pages=1;p=first
        while p['has_more']:
            p=query(h,'capacity-next-'+str(pages),b,offset=p['next_offset'],selection=first['selection_digest'],limit=32,max_bytes=60000);rows+=p['records'];pages+=1
        h.check(len(rows)==80 and len({r['instance'] for r in rows})==80 and [r['ordinal'] for r in rows]==list(range(1,81)),'full 80-owned-instance enumeration without gaps')
        h.check(root_for(first,rows)==first['selection_digest'],'independent max-owner commitment')
        active=query(h,'active-only',b,lifecycle='active');terminal=query(h,'retired-only',b,lifecycle='retired')
        h.check(active['selected_total']==16 and terminal['selected_total']==64,'counts scoped by lifecycle')
        state=(b/'state.journal').read_bytes()
        for i in range(8):query(h,'capacity-empty-'+str(i),b,name='absent')
        h.check(state==(b/'state.journal').read_bytes(),'large empty inventory remains observational')
        h.run('capacity-compact',['compact','--control',str(d.control),'--deadline-ms','4000']);d.shutdown();d=h.start('capacity-restart',cfg,b)
        after=query(h,'capacity-after-replay',b,offset=64,selection=first['selection_digest'],limit=32,max_bytes=60000)
        h.check(after['records']==rows[64:] and after['selected_total']==80,'reconstructed max-owned selection')
        save(h,'CAPACITY',{'owned_records':80,'active':16,'retired':64,'pages':pages,'first':first,'after_restart':after});d.shutdown()
    case('full_active_and_retired_owner_inventory_rebuild',capacity)

    def metadata_authority():
        b=h.runtime/'metadata';cfg=config(h,'metadata',b,free_port());d=h.start('metadata',cfg,b)
        consumer(h,'broad-create',b,'create','broad',reason='broad immutable selector')
        consumer(h,'payload-create',b,'create','payload',issuer='A',scope='query/series',payload='yes',payload_length=64,reason='payload selection')
        numeric_create(h,'numeric-hidden-later',b,'number')
        full=query(h,'metadata-full',b);h.check(full['selected_total']==3,'initial complete permission')
        # No payload permission may accidentally disclose numeric result identity/progress.
        downgraded=candidate(h,cfg,'metadata-downgrade','metadata-g2',lambda t:t.replace(',EVIDENCE_PAYLOAD','').replace('evidence_read='+str(os.geteuid())+',A,query/series,PAYLOAD','evidence_read='+str(os.geteuid())+',A,query/series,METADATA'))
        activate(h,'payload-removed',b,downgraded)
        hidden=query(h,'metadata-hidden-old',b);h.check(hidden['selected_total']==0,'whole adopted authority mismatch hidden, including broad counters')
        consumer(h,'metadata-fresh',b,'create','metadata-current',issuer='A',scope='query/series',reason='current policy')
        current=query(h,'metadata-current-only',b);h.check([r['name'] for r in current['records']]==['metadata-current'],'new metadata consumer visible')
        h.check(query(h,'numeric-exact-hidden',b,name='number',kind='numeric')['selected_total']==0,'numeric exact selector never bypasses payload authority')
        # Reset is an existing explicit operation, not a side effect of listing.
        old=consumer(h,'broad-status',b,'status','broad')['consumer']
        consumer(h,'broad-explicit-reset',b,'reset','broad',expected_revision=old['revision'],start='beginning',reason='adopt current domains')
        fresh=query(h,'broad-reset-visible',b);h.check([r['name'] for r in fresh['records']]==['broad','metadata-current'],'explicit reset restores visibility only under current authority')
        save(h,'AUTHORITY-MODE',{'before':full,'after_payload_revocation':hidden,'explicit_reset':fresh});d.shutdown()
    case('payload_read_separation_and_explicit_authority_adoption',metadata_authority)

    def drain():
        b=h.runtime/'drain';cfg=config(h,'drain',b,free_port());port=free_port()
        cfg.write_text(cfg.read_text()+f'peer=C,127.0.0.1:{port},200,2000,20,86400000\n')
        d=h.start('drain',cfg,b)
        consumer(h,'drain-consumer',b,'create','visible',issuer='A',scope='query/series',reason='observable during drain')
        h.run('drain-pending',['submit','--control',str(d.control),'--node','B','--peer','C','--scope','test/drain','--operation','13'*32,'--payload-text','pending while recipient is unavailable'])
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            stop=pool.submit(h.run,'drain-start',['drain-shutdown','--control',str(d.control),'--reason','genuine pending-work drain','--drain-deadline-ms','1500'])
            h.wait('actual nonempty drain',lambda:h.status('drain-health',b,logical_digest=False)['lifecycle']['draining'])
            q=query(h,'draining-inventory',b)
            h.check(q['selected_total']==1 and d.process.poll() is None,'read works during a genuine nonempty drain')
            done=stop.result()
        d.process.wait(timeout=5)
        save(h,'DRAIN',{'drain_response':done,'inventory':q});d.shutdown()
    case('observational_inventory_during_nonempty_service_drain',drain)

    def maintenance():
        b=h.runtime/'maintenance';cfg=config(h,'maintenance',b,free_port());d=h.start('maintenance',cfg,b)
        summary_create(h,'maint-summary',b,'summary');consumer(h,'maint-consumer',b,'create','plain',issuer='A',scope='query/series',reason='durable identity')
        retire(h,'maint-retire',b,'summary');first=query(h,'maint-first',b);d.shutdown()
        key=new_key(h,h.work,'inventory-state');migrate(h,'inventory-migrate',b,key,node='B');d=keyed_start(h,'maint-keyed',cfg,b,key)
        h.check(query(h,'migrate-selection',b,selection=first['selection_digest'])['records']==first['records'],'representation migration not metadata change')
        h.run('maint-compact',['compact','--control',str(d.control)]);d.shutdown()
        h.run('inventory-audit',['state-auth-audit','--state',str(b),'--node','B','--state-auth-key',str(key)])
        before=inspect(h,'inventory-before-export',b,key,node='B')
        crypt=h.work/'inventory-crypt.key';h.run('inventory-crypt',['backup-key-init','--output',str(crypt),'--generation','inventory-encryption'])
        identity=h.identity('B');archive=h.work/'inventory.nob';h.run('inventory-export',['backup-export','--state',str(b),'--node','B','--generation','b-g1','--state-auth-key',str(key),'--output',str(archive),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'restored-inventory';h.run('inventory-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','B','--generation','b-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'inventory-after-restore',restored,key,node='B');h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'exact restored logical state')
        new=h.runtime/'inventory-identity';new.mkdir(mode=0o700);cert=new/'cert.pem';secret=new/'key.pem';shutil.copyfile(identity.certificate,cert);shutil.copyfile(identity.private_key,secret);secret.chmod(0o600)
        moved=candidate(h,cfg,'inventory-moved','inventory-moved-g2',lambda t:t.replace('state='+str(b),'state='+str(restored)).replace(str(identity.certificate),str(cert)).replace(str(identity.private_key),str(secret)))
        h.run('inventory-relocate',['state-relocate','--state',str(restored),'--node','B','--candidate',str(moved),'--reason','explicit inventory owner-path move','--state-auth-key',str(key)])
        identity.certificate.unlink();identity.private_key.unlink();d=keyed_start(h,'inventory-moved',moved,restored,key)
        h.check(query(h,'old-selection-after-relocation',restored,selection=first['selection_digest'],expected=3)['code']=='CONSUMER_INVENTORY_SELECTION_MISMATCH','new accepted config requires fresh current selection')
        final=query(h,'fresh-after-relocation',restored);h.check(final['records']==first['records'],'immutable and progress metadata unchanged through restore/relocate')
        consumer(h,'new-after-relocation',restored,'create','later',issuer='A',scope='query/series',reason='continued native operation')
        h.check(query(h,'continued-inventory',restored)['selected_total']==3,'new retained work continues')
        save(h,'MAINTENANCE',{'before':first,'after':final,'logical_state_equal_at_restore':True,'old_identity_files_removed':True});d.shutdown()
    case('authenticated_compaction_encrypted_restore_relocation_and_continuation',maintenance)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);begin=time.time();ok=False
    try:
        cases(h,set(a.case) if a.case else None)
        if not h.cases:raise ValueError('no selected cases')
        ok=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {e}',file=sys.stderr)
    finally:
        h.cleanup();s={'format':'NATRAV_CONSUMER_INVENTORY_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-begin}
        for n,v in [('SUMMARY',s),('CASES',h.cases),('COMMANDS',h.commands)]:save(h,n,v)
        print(json.dumps(s),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
