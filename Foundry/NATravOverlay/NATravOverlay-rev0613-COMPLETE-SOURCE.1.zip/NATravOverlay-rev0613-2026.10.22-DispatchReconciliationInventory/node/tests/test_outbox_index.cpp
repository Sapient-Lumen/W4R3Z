#include "outbox_query.hpp"
#include <algorithm>
#include <iostream>
#include <random>
#include <set>
#include <stdexcept>
#include <vector>
using natrav_overlay::OutboxInspectionIndex;
int main() {
    std::uint64_t checks=0;
    auto check=[&](bool value){++checks;if(!value)throw std::runtime_error("outbox index differential mismatch");};
    OutboxInspectionIndex index;
    struct Record {std::string peer,state;};std::vector<Record> reference;
    const std::vector<std::string> outcomes={"PENDING","ACKED","REJECTED","CANCELLED","EXPIRED"};
    std::mt19937 random(530U);
    for(std::size_t i=0;i<5000U;++i){
        reference.push_back({"peer-"+std::to_string(i%13U),outcomes[i%outcomes.size()]});
        index.touch(i,reference.back().peer,reference.back().state);
    }
    for(std::size_t step=0;step<20000U;++step){
        const auto i=static_cast<std::size_t>(random()%reference.size());
        const auto unaffected=(i+1U)%reference.size();const auto previous=index.revision(i);const auto other=index.revision(unaffected);
        auto& item=reference[i];item.state=outcomes[static_cast<std::size_t>(random()%outcomes.size())];
        index.touch(i,item.peer,item.state);
        check(index.revision(i)>previous);check(index.revision(unaffected)==other);check(index.state(i)==item.state);
        if(step%25U!=0)continue;
        const std::string peer=step%50U==0?std::string{}:"peer-"+std::to_string(random()%13U);
        const std::string state=step%75U==0?std::string{}:outcomes[static_cast<std::size_t>(random()%outcomes.size())];
        std::set<std::size_t> expected;
        for(std::size_t n=0;n<reference.size();++n)if((peer.empty()||reference[n].peer==peer)&&(state.empty()||reference[n].state==state))expected.insert(n);
        const auto& actual=index.select(peer,state);check(actual.records==expected);check(actual.revision>0U);
        const std::size_t after=random()%reference.size();check(std::vector<std::size_t>(actual.records.upper_bound(after),actual.records.end())==std::vector<std::size_t>(expected.upper_bound(after),expected.end()));
    }
    check(index.select("missing","PENDING").records.empty());check(index.select("missing","PENDING").revision==0U);
    std::cout<<"{\"status\":\"PASS\",\"checks\":"<<checks<<",\"records\":5000,\"mutations\":20000}\n";
}
