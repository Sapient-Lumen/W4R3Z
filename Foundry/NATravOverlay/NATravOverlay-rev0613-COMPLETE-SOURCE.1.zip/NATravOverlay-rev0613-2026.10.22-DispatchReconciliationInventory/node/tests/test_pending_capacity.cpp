// Production index differential test. No kernel, network or synthetic peer claims.
#include "pending_capacity.hpp"
#include "common.hpp"
#include <array>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <map>
#include <new>
#include <random>
#include <string>
#include <vector>

namespace {
thread_local long allocation_failure = -1;
std::uint64_t checks=0U;
void check(bool value,const char* message) { ++checks; if(!value) throw std::runtime_error(message); }
}
// Deterministic allocation failure only during one explicitly selected update.
[[gnu::noinline]] void* operator new(std::size_t n) {
    if(allocation_failure == 0) throw std::bad_alloc();
    if(allocation_failure > 0) --allocation_failure;
    if(void* p=std::malloc(n == 0U ? 1U : n)) return p;
    throw std::bad_alloc();
}
[[gnu::noinline]] void operator delete(void* p) noexcept { std::free(p); }
[[gnu::noinline]] void operator delete(void* p,std::size_t) noexcept { std::free(p); }
[[gnu::noinline]] void* operator new[](std::size_t n) { return ::operator new(n); }
[[gnu::noinline]] void operator delete[](void* p) noexcept { ::operator delete(p); }
[[gnu::noinline]] void operator delete[](void* p,std::size_t) noexcept { ::operator delete(p); }

int main() {
    namespace no=natrav_overlay;
    try {
        constexpr std::size_t count=1024U;
        struct Ref { std::string peer; std::uint64_t bytes; bool pending; };
        std::vector<Ref> reference;
        for(std::size_t i=0;i<count;++i) reference.push_back({"peer-"+std::to_string(i%97U),i%9U==0U?0U:(i*47U)%60001U,false});
        no::PendingCapacityIndex actual;
        std::mt19937_64 random(0x0535C0FFEEU);
        std::uint64_t acquired=0U,released=0U,unchanged=0U;
        for(std::size_t turn=0;turn<50000U;++turn) {
            const auto i=static_cast<std::size_t>(random()%count);auto& ref=reference[i];
            const bool pending=(random()%3U)!=0U;
            const auto expected=ref.pending==pending?no::PendingCapacityChange::unchanged:
                pending?no::PendingCapacityChange::acquired:no::PendingCapacityChange::released;
            const auto change=actual.update(i,ref.peer,ref.bytes,pending);
            check(change==expected,"one exact charge/release or no-op");ref.pending=pending;
            if(change==no::PendingCapacityChange::acquired)++acquired;
            else if(change==no::PendingCapacityChange::released)++released;
            else ++unchanged;
            // Deliberately independent O(n) reference, including zero-byte records.
            no::QueueUsage oracle;std::map<std::string,no::PeerQueueUsage> peers;
            for(const auto& value:reference) if(value.pending) {
                ++oracle.pending_records;oracle.pending_payload_bytes+=value.bytes;
                auto& peer=peers[value.peer];peer.peer=value.peer;++peer.pending_records;peer.pending_payload_bytes+=value.bytes;
            }
            for(const auto& [name,value]:peers){static_cast<void>(name);oracle.peers.push_back(value);}
            check(actual.snapshot()==oracle,"derived totals equal independent full scan");
            check(actual.total()==no::PendingCapacityTotals{oracle.pending_records,oracle.pending_payload_bytes},"constant global read");
            const auto expected_peer=peers.find(ref.peer);
            check(actual.peer(ref.peer)==(expected_peer==peers.end()?no::PendingCapacityTotals{}:no::PendingCapacityTotals{expected_peer->second.pending_records,expected_peer->second.pending_payload_bytes}),"exact peer read");
            check(actual.entries()==oracle.pending_records && actual.peers()==oracle.peers.size(),"index retains pending entries and peers only");
        }
        for(std::size_t i=0;i<count;++i)static_cast<void>(actual.update(i,reference[i].peer,reference[i].bytes,false));
        check(actual.entries()==0U && actual.peers()==0U && actual.snapshot()==no::QueueUsage{},"settled history occupies no aggregate entries");
        no::PendingCapacityIndex boundary;
        const auto maximum=std::numeric_limits<std::uint64_t>::max();
        static_cast<void>(boundary.update(0U,"B",maximum,true));
        static_cast<void>(boundary.update(1U,"C",0U,true));
        const auto before=boundary.snapshot();
        bool overflow=false;try{static_cast<void>(boundary.update(2U,"D",1U,true));}
        catch(const no::AppError& e){overflow=e.code()=="OUTBOX_ACCOUNTING_OVERFLOW";}
        check(overflow && boundary.snapshot()==before && boundary.peers()==2U,"overflow is detected before new bucket or charge");
        bool changed=false;try{static_cast<void>(boundary.update(0U,"WRONG",maximum,false));}
        catch(const no::AppError& e){changed=e.code()=="OUTBOX_ACCOUNTING_CORRUPT";}
        check(changed && boundary.snapshot()==before,"recipient mismatch leaves counters intact");
        changed=false;try{static_cast<void>(boundary.update(0U,"B",maximum-1U,false));}
        catch(const no::AppError& e){changed=e.code()=="OUTBOX_ACCOUNTING_CORRUPT";}
        check(changed && boundary.snapshot()==before,"length mismatch cannot under-release");
        static_cast<void>(boundary.update(0U,"B",maximum,false));
        check(boundary.total()==no::PendingCapacityTotals{1U,0U},"zero payload consumes one count");
        static_cast<void>(boundary.update(1U,"C",0U,false));
        check(boundary.snapshot()==no::QueueUsage{},"exact maximum release leaves no residual bytes");
        std::size_t injected=0U;
        const std::string long_peer(60U,'P');
        for(long failure=0;failure<16;++failure) {
            no::PendingCapacityIndex tested;
            static_cast<void>(tested.update(7U,"B",42U,true));
            const auto prior=tested.snapshot();bool failed=false;
            allocation_failure=failure;
            try {static_cast<void>(tested.update(8U,long_peer,19U,true));}
            catch(const std::bad_alloc&){failed=true;}
            allocation_failure=-1;
            if(!failed){check(tested.total()==no::PendingCapacityTotals{2U,61U},"final injection boundary succeeds");break;}
            ++injected;
            check(tested.snapshot()==prior && tested.entries()==1U && tested.peers()==1U,"allocation failure leaves exact old aggregate");
            static_cast<void>(tested.update(8U,long_peer,19U,true));
            check(tested.total()==no::PendingCapacityTotals{2U,61U},"same update succeeds after fault removal");
        }
        check(injected>=3U,"allocation injection covered map and recipient storage");
        std::cout<<"{\"format\":\"NATRAV_PENDING_CAPACITY_DIFFERENTIAL_V1\",\"status\":\"PASS\",\"checks\":"<<checks
            <<",\"random_updates\":50000,\"positions\":1024,\"acquired\":"<<acquired<<",\"released\":"<<released
            <<",\"unchanged\":"<<unchanged<<",\"allocation_failures\":"<<injected<<"}\n";
        return 0;
    }catch(const std::exception& e){allocation_failure=-1;std::cerr<<e.what()<<'\n';return 1;}
}
