#!/usr/bin/env python3
"""Forced post-join INSPECT denial must stop without exposing a correlated terminal head."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time
import traceback

from run_persistent import Harness
from run_correlated_terminal_state_head import (
    correlated_terminal_shutdown,
    request_id,
    setup_keyed,
    terminal_args,
)
from run_state_authentication import inspect, start


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    harness = Harness(args.binary, args.output)
    started = time.time()
    code = 1
    try:
        def run() -> None:
            token = "forced-final-inspect-denial"
            expected_id = request_id(correlated_terminal_shutdown(token))
            _, state, key, config, daemon = setup_keyed(harness, "correlated-terminal-final-inspect-failure")
            result = harness.run(
                "correlated-terminal-final-inspect-failure",
                terminal_args(daemon.control, token),
                expected=3,
            )
            harness.check(result is not None and result.get("code") == "LOCAL_CONTROL_CLASS_DENIED", "post-join INSPECT denial fails closed")
            harness.check(result.get("request_id") == expected_id and "state_head" not in result and "correlation_token" not in result, "denial retains exact provenance without exposing head or token")
            assert daemon.process
            daemon.process.wait(timeout=8)
            harness.check(daemon.process.returncode == 3, "failed terminal head delivery is reflected in process exit")
            daemon._close_files()
            snapshot = inspect(harness, "correlated-terminal-final-inspect-offline", state, key)
            matching = [event for event in snapshot["lifecycle"]["events"] if event["request_id"] == expected_id]
            harness.check(len(matching) == 1 and matching[0]["kind"] == "SHUTDOWN_REQUESTED", "accepted stop remains durable despite final disclosure denial")
            restarted = start(harness, "correlated-terminal-final-inspect-restart", config, state, key)
            harness.check(harness.status("correlated-terminal-final-inspect-restart-status", state, logical_digest=False)["lifecycle"]["mode"] == "RUNNING", "restart reconstructs ordinary immediate-stop provenance")
            restarted.shutdown()

        harness.case("final_inspect_denial_refuses_head_without_revoking_stop", run)
        code = 0
    except BaseException:
        (harness.output / "FAILURE.txt").write_text(traceback.format_exc())
    finally:
        harness.cleanup()
        summary = {
            "format": "CORRELATED_TERMINAL_HEAD_FINAL_INSPECT_FAILURE_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(item["status"] == "PASS" for item in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (
            ("SUMMARY.json", summary),
            ("CASES.json", harness.cases),
            ("COMMANDS.json", harness.commands),
        ):
            (harness.output / name).write_text(json.dumps(value, indent=2) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
