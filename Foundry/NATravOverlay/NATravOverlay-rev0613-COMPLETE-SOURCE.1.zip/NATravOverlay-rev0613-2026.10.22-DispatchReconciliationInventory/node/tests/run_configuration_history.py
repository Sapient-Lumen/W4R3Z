#!/usr/bin/env python3
"""Bounded retained configuration history against owned C++ state and principals.
Independent NHC1 encoder and SHA-256 reference over actual journal bytes.
Large synthetic replay fixtures are not network/deployment-scale claims.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, shutil, socket, struct, time
from pathlib import Path
from run_persistent import Harness, Daemon, free_port, operation, raw_control, receive_exact
from run_live_configuration import candidate, activate, rollback
from run_outbox_inspection import setup, submit
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_state_authentication import new_key, migrate, start as start_keyed, inspect
from run_delivery_selection import frame, text


def hash_domain(name, data):return hashlib.sha256(name.encode()+b'\0'+data).digest()
def seed(node,section):return hash_domain('NATRAV_OVERLAY_CONFIGURATION_HISTORY_SEED_V1',text(node)+bytes([1 if section=='events' else 2]))
def linked(previous,ordinal,item):return hash_domain('NATRAV_OVERLAY_CONFIGURATION_HISTORY_LINK_V1',previous+struct.pack('!Q',ordinal)+item)
def optional(n):return b'\0' if n is None else b'\1'+struct.pack('!Q',n)
def wire(*,section='events',ordinal=None,event=None,offset=0,limit=16,budget=60000,through=None,prefix=None):
    return b'NOC1\x1bNHC1'+bytes([1 if section=='events' else 2])+optional(ordinal)+optional(event)+struct.pack('!QII',offset,limit,budget)+optional(through)+(bytes.fromhex(prefix) if prefix else b'')


def history(h,label,state,*,section='events',ordinal=None,event=None,offset=0,limit=16,budget=60000,through=None,prefix=None,uid=None,expected=0):
    args=['configuration-history','--control',str(state/'control.sock'),'--section',section,'--offset',str(offset),'--limit',str(limit),'--max-bytes',str(budget),'--deadline-ms','5000']
    for key,value in [('ordinal',ordinal),('event',event),('through',through),('prefix-digest',prefix)]:
        if value is not None:args+=['--'+key,str(value)]
    q=h.run(label,args,expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    if expected==0:
        h.check(q['format']=='NATRAV_OVERLAY_CONFIGURATION_HISTORY_V1','versioned history contract')
        h.check(q['returned']==len(q['rows']) and q['returned']<=limit,'whole bounded rows')
        h.check(len(json.dumps(q,separators=(',',':')).encode())<=budget,'complete annotated response bounded')
        h.check(q['work']['rows_visited']<=limit+1 and q['work']['prefix_reads']==1,'bounded visited metadata and prefix lookup')
        h.check(all(q['work'][k]==0 for k in ['canonical_bytes_read','payload_bytes_read','historical_configurations_parsed','state_snapshots','snapshot_logical_bytes']),'no canonical parse, payload or application snapshot')
    return q


def enumerate_history(h,label,state,**kw):
    rows=[];first=None;offset=0;page=0
    while True:
        q=history(h,label+'-'+str(page),state,offset=offset,through=first['through'] if first else None,prefix=first['prefix_digest'] if first else None,**kw)
        if first is None:first=q
        h.check(q['through']==first['through'] and q['prefix_digest']==first['prefix_digest'],'stable selected prefix')
        rows+=q['rows'];page+=1
        if not q['more']:break
        h.check(q['next_offset']>offset,'nonempty forward progress');offset=q['next_offset']
    h.check(len(rows)==first['selected_total'],'complete selected enumeration')
    return rows,first,page


def journal_reference(raw,node='A'):
    events=[];bindings=[];ep=seed(node,'events');bp=seed(node,'bindings');off=0
    def take_text(data,p):
        n=struct.unpack_from('!H',data,p)[0];return data[p+2:p+2+n].decode(),p+2+n
    while off<len(raw):
        assert raw[off:off+4]==b'NOJ1';n=struct.unpack_from('!I',raw,off+4)[0];body=raw[off+8:off+8+n]
        assert hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest()==raw[off+8+n:off+40+n]
        kind,payload=body[0],body[1:];off+=40+n
        if kind==22:
            p=0;k,p=take_text(payload,p);g,p=take_text(payload,p);digest=payload[p:p+32];p+=32
            n=struct.unpack_from('!I',payload,p)[0];p+=4;canonical=payload[p:p+n];p+=n
            stamp=struct.unpack_from('!Q',payload,p)[0];p+=8;actor,p=take_text(payload,p);reason,p=take_text(payload,p);code,p=take_text(payload,p);assert p==len(payload)
            item=hash_domain('NATRAV_OVERLAY_CONFIGURATION_EVENT_ITEM_V1',payload);ep=linked(ep,len(events)+1,item)
            events.append({'kind':k,'generation':g,'configuration_digest':digest.hex(),'canonical_bytes':n,'unix_ms':stamp,'actor':actor,'reason_bytes':len(reason.encode()),'reason_digest':hash_domain('NATRAV_OVERLAY_CONFIGURATION_REASON_V1',reason.encode()).hex(),'error_code':code,'item_digest':item.hex(),'prefix_digest':ep.hex()})
        elif kind==23:
            event=struct.unpack_from('!Q',payload)[0];inner=payload[8];data=payload[9:]
            op=data[5:37] if inner in (1,2,3) else None if inner==4 else data[:32]
            bound=struct.pack('!QB',event,inner)+hashlib.sha256(data).digest()+(b'\1'+op if op else b'\0')
            event_prefix=bytes.fromhex(events[event-1]['prefix_digest'])
            item=hash_domain('NATRAV_OVERLAY_CONFIGURATION_BINDING_ITEM_V1',event_prefix+bound);bp=linked(bp,len(bindings)+1,item)
            bindings.append({'configuration_event':event,'journal_kind':inner,'payload_digest':hashlib.sha256(data).hexdigest(),'operation_id':op.hex() if op else None,'item_digest':item.hex(),'prefix_digest':bp.hex(),'configuration_prefix_digest':event_prefix.hex()})
    assert off==len(raw)
    return events,bindings


def compare(h,rows,reference):
    h.check(len(rows)==len(reference),'independent reference count')
    for i,(row,ref) in enumerate(zip(rows,reference)):
        h.check(row['ordinal']==i+1 and all(row[k]==v for k,v in ref.items()),'independent canonical commitments and exact event fields')


def cases(h,selected):
    def case(name,fn):
        if not selected or name in selected:h.case(name,fn)

    def independent():
        a,b,ac,bc,ad,bd=setup(h,'history-reference')
        for i in range(18):submit(h,f'history-source-{i}',a,peer='C',payload='SENSITIVE-PAYLOAD-'+str(i))
        for i in range(9):
            c=candidate(h,ac,'history-candidate-'+str(i),'history-generation-'+str(i))
            activate(h,'history-activate-'+str(i),a,c)
            submit(h,'history-mutation-'+str(i),a,peer='C',payload='SECRET-CONTENT')
        forbidden=candidate(h,ac,'private-rejected-candidate','bad-owner',lambda t:t.replace('state='+str(a),'state=/private/DO-NOT-DISCLOSE'))
        activate(h,'reject-owner-boundary',a,forbidden,3,'CONFIG_OWNER_BOUNDARY_CHANGED')
        rollback(h,'history-rollback',a,'history-reference-g1')
        raw=(a/'state.journal').read_bytes();refs=journal_reference(raw)
        events,first,pages=enumerate_history(h,'events',a,limit=3)
        bindings,bfirst,bpages=enumerate_history(h,'bindings',a,section='bindings',limit=4)
        compare(h,events,refs[0]);compare(h,bindings,refs[1]);h.check(pages>1 and bpages>4,'complete history beyond status tails')
        h.check(events[-2]['kind']=='REJECTED' and not events[-2]['accepted'] and events[-2]['active_event_after']==10,'rejection preserves active predecessor')
        h.check(events[-1]['kind']=='ROLLBACK' and events[-1]['active_event_after']==12,'rollback is new accepted event, not overwritten history')
        for row in events:
            h.check(row['reason_text'] is None and row['canonical_contents'] is None and row['relocation_paths'] is None,'explicit opaque-field suppression')
        encoded=json.dumps(events)
        h.check(str(h.work) not in encoded and '/private/DO-NOT-DISCLOSE' not in encoded and 'SENSITIVE-PAYLOAD' not in json.dumps(bindings),'no candidate paths, canonical text or payloads in pages')
        exact=history(h,'exact-old-event',a,ordinal=2)
        h.check(exact['rows']==[events[1]],'exact event lookup beyond bounded status tail')
        byevent=history(h,'event-bindings',a,section='bindings',event=2)
        h.check(byevent['rows']==[x for x in bindings if x['configuration_event']==2],'exact accepted-event binding filter')
        h.check(history(h,'rejected-bindings',a,section='bindings',event=11)['rows']==[],'rejected event has no mutation bindings')
        h.check(history(h,'missing-event',a,ordinal=256)['rows']==[],'missing exact event empty')
        h.check(history(h,'exact-binding-with-wrong-event',a,section='bindings',ordinal=1,event=2)['rows']==[],'selectors conjunctive')
        after=(a/'state.journal').read_bytes();h.check(after==raw,'successful reads create no audit or journal event')
        (h.output/'REFERENCE.json').write_text(json.dumps({'events':events,'binding_count':len(bindings),'event_pages':pages,'binding_pages':bpages,'event_prefix':first['prefix_digest'],'binding_prefix':bfirst['prefix_digest']},indent=2)+'\n')
        ad.shutdown()
    case('independent_journal_commitments_events_bindings_redaction_and_exact_lookup',independent)

    def validation():
        a,b,ac,bc,ad,bd=setup(h,'history-validation');submit(h,'wire-op',a,peer='C')
        q=history(h,'wire-reference',a,limit=1)
        ok,r=raw_control(a/'control.sock',wire(limit=1));h.check(ok and r['rows']==q['rows'],'independent strict wire agrees with CLI')
        for label,payload in [('trailing',wire()+b'x'),('bad-magic',b'NOC1\x1bBAD!'+wire()[9:]),('bad-section',b'NOC1\x1bNHC1\x03'+wire()[10:]),('bad-flag',b'NOC1\x1bNHC1\x01\x02'+wire()[11:]),('zero-limit',wire(limit=0)),('excess-bytes',wire(budget=60001)),('filter-events',wire(event=1))]:
            ok,result=raw_control(a/'control.sock',payload);h.check(not ok,'strict decoding rejects '+label)
        bad=history(h,'false-prefix',a,through=q['through'],prefix='11'*32,expected=3)
        h.check(bad['code']=='CONFIGURATION_HISTORY_PREFIX_MISMATCH','exact prefix comparison required')
        bad=history(h,'future-prefix',a,through=q['through']+1,prefix=q['prefix_digest'],expected=3)
        h.check(bad['code']=='CONFIGURATION_HISTORY_PREFIX_UNAVAILABLE','cannot invent missing prefix')
        for kwargs,code in [({'offset':1},'CONFIGURATION_HISTORY_PREFIX_REQUIRED'),({'through':1},'CONFIGURATION_HISTORY_PREFIX_REQUIRED'),({'prefix':q['prefix_digest']},'CONFIGURATION_HISTORY_PREFIX_REQUIRED'),({'through':q['through'],'prefix':q['prefix_digest'],'offset':2},'CONFIGURATION_HISTORY_OFFSET_INVALID')]:
            h.check(history(h,'invalid-selection',a,expected=3,**kwargs)['code']==code,'specific bounds/selection error')
        small=history(h,'minimum-page',a,budget=2048)
        h.check(small['rows']==q['rows'],'small complete row fits honestly at minimum budget')
        more=candidate(h,ac,'two-events','wire-second-generation');activate(h,'wire-append-event',a,more)
        bounded=history(h,'byte-limited-page',a,limit=64,budget=2048)
        h.check(bounded['returned']==1 and bounded['more'] and bounded['next_offset']==1,'byte budget ends before nonfitting later row, no skip')
        empty=history(h,'end',a,through=q['through'],prefix=q['prefix_digest'],offset=q['selected_total'])
        h.check(empty['rows']==[] and empty['work']['rows_visited']==0,'end page visits no record')
        # Empty pre-V7 history is legitimate, not an invented bootstrap.
        ad.shutdown();legacy=h.runtime/'legacy';conf=h.config('legacy-history','L',legacy,free_port(),[],deadline_ms=2000);ld=h.start('legacy',conf,legacy)
        for section in ('events','bindings'):
            q0=history(h,'empty-'+section,legacy,section=section)
            h.check(q0['through']==0 and q0['prefix_digest']==seed('L',section).hex(),'independent empty seed and explicit no history')
            history(h,'selected-empty-'+section,legacy,section=section,through=0,prefix=q0['prefix_digest'])
        ld.shutdown()
    case('strict_independent_wire_prefix_mismatch_limits_and_legacy_empty_history',validation)

    def append_stable():
        a,b,ac,bc,ad,bd=setup(h,'history-concurrent')
        for i in range(12):submit(h,'pre-history-'+str(i),a,peer='C')
        rows,before,_=enumerate_history(h,'initial',a,section='bindings',limit=5)
        ev=history(h,'event-prefix-before',a)
        def writer(i):
            return submit(h,'concurrent-history-'+str(i),a,peer='C',payload='new')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            futures=[pool.submit(writer,i) for i in range(24)]
            new=candidate(h,ac,'concurrent-config','concurrent-config-g2');activate(h,'concurrent-activate',a,new)
            offset=0;got=[]
            while True:
                q=history(h,'fixed-old-page-'+str(offset),a,section='bindings',through=before['through'],prefix=before['prefix_digest'],offset=offset,limit=3)
                got+=q['rows']
                if not q['more']:break
                offset=q['next_offset']
            for f in futures:f.result()
        h.check(got==rows,'later mutations and config appends do not change chosen binding prefix')
        historical=history(h,'previous-events-survive-publication',a,through=ev['through'],prefix=ev['prefix_digest'])
        h.check(historical['rows']==ev['rows'] and historical['active_event_observed']>historical['prefix_active_event'],'current event and historical active event distinct')
        final=history(h,'later-bindings',a,section='bindings',limit=1)
        h.check(final['through']==before['through']+24,'all concurrent atomic admissions present once')
        h.run('history-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000'])
        q=history(h,'old-prefix-after-compact',a,section='bindings',through=before['through'],prefix=before['prefix_digest'],limit=64)
        h.check(q['rows']==rows,'compaction retains prefix')
        ad.kill();ad=h.start('history-after-kill',ac,a)
        q=history(h,'old-prefix-after-kill',a,section='bindings',through=before['through'],prefix=before['prefix_digest'],limit=64)
        h.check(q['rows']==rows,'reconstruction retains prefix while startup seed is older')
        (h.output/'CONCURRENT.json').write_text(json.dumps({'before_count':before['through'],'after_count':final['through'],'retained_prefix':before['prefix_digest'],'old_prefix_identical_after_compaction_restart':True},indent=2)+'\n');ad.shutdown()
    case('concurrent_append_stable_prefix_pages_compaction_and_hard_restart',append_stable)

    def credentials():
        a,b,ac,bc,ad,bd=setup(h,'history-authority',delegates=True);expose_control_for_uid(a)
        q=history(h,'real-reader',a,uid=65534)
        h.check(history(h,'submit-not-inspect',a,uid=65533,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','SUBMIT does not imply history inspection')
        # A prefix is public-to-current-inspectors context, not a UID capability.
        same=history(h,'same-public-prefix',a,through=q['through'],prefix=q['prefix_digest'])
        h.check(same['rows']==q['rows'],'currently authorized principals can compare same immutable prefix')
        sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);sock.settimeout(6);sock.connect(str(a/'control.sock'));data=wire();sock.sendall(struct.pack('!I',len(data))+data[:-1])
        c=candidate(h,ac,'history-revoked','history-revoked-g2',lambda t:t.replace(f'local_control={os.geteuid()},ALL',f'local_control={os.geteuid()},CONFIGURATION,MAINTENANCE,SHUTDOWN,SUBMIT'))
        activate(h,'revoke-inspection',a,c);sock.sendall(data[-1:]);sock.shutdown(socket.SHUT_WR);n=struct.unpack('!I',receive_exact(sock,4))[0];resp=receive_exact(sock,n);sock.close()
        h.check(resp[4]==1 and json.loads(resp[5:])['code']=='LOCAL_CONTROL_CLASS_DENIED','partial request uses current post-decode authority')
        history(h,'other-inspector-still-authorized',a,uid=65534)
        restore=candidate(h,ac,'history-owner-restored','history-owner-g3');activate(h,'restore-owner',a,restore)
        h.run('history-quiesce',['quiesce','--control',str(a/'control.sock'),'--reason','history during lifecycle']);history(h,'quiesced-history',a)
        h.run('history-resume',['resume','--control',str(a/'control.sock'),'--reason','resume fixture']);submit(h,'drain-kept',a,peer='C')
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            draining=pool.submit(h.run,'history-drain',['drain-shutdown','--control',str(a/'control.sock'),'--reason','bounded inspection','--drain-deadline-ms','1500'])
            h.wait('actual draining state',lambda:h.status('wait-draining',a,logical_digest=False)['lifecycle']['draining'])
            history(h,'draining-history',a)
            h.run('draining-inventory',['runtime-inventory','--control',str(a/'control.sock')])
            draining.result()
        restore_owner_only_control(a);ad.cleanup()
    case('real_kernel_uid_live_revocation_quiescence_and_draining_observation',credentials)

    def maintenance():
        a,b,ac,bc,ad,bd=setup(h,'history-maintenance')
        for i in range(4):submit(h,'maintenance-history-'+str(i),a,peer='C')
        ev,efirst,_=enumerate_history(h,'before-events',a,limit=3);bindings,bfirst,_=enumerate_history(h,'before-bindings',a,section='bindings',limit=2)
        ad.shutdown();key=new_key(h,h.work,'history-state');migrate(h,'history-migrate',a,key)
        ad=start_keyed(h,'history-keyed',ac,a,key);h.run('history-keyed-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000']);ad.shutdown()
        h.run('history-auth-audit',['state-auth-audit','--state',str(a),'--node','A','--state-auth-key',str(key)])
        before=inspect(h,'before-history-backup',a,key);crypt=h.work/'history.backup-key';h.run('history-backup-key',['backup-key-init','--output',str(crypt),'--generation','history-crypt'])
        ident=h.identity('A');archive=h.work/'history.nob'
        h.run('history-export',['backup-export','--state',str(a),'--node','A','--generation','a-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'history-restored'
        h.run('history-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'after-history-backup',restored,key);h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'derived history index changes no logical state through signed encrypted restore')
        keys=h.work/'relocated-identity';keys.mkdir(mode=0o700);shutil.copyfile(ident.private_key,keys/'key.pem');(keys/'key.pem').chmod(0o600);shutil.copyfile(ident.certificate,keys/'cert.pem')
        moved=candidate(h,ac,'history-relocated','history-relocated-g2',lambda t:t.replace('state='+str(a),'state='+str(restored)).replace(str(ident.private_key),str(keys/'key.pem')).replace(str(ident.certificate),str(keys/'cert.pem')))
        h.run('history-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','PRIVATE-REASON '+str(ident.private_key),'--state-auth-key',str(key)])
        ident.private_key.unlink();ident.certificate.unlink()
        ad=start_keyed(h,'history-relocated-daemon',moved,restored,key)
        q=history(h,'restored-old-events',restored,through=efirst['through'],prefix=efirst['prefix_digest'],limit=64)
        h.check(q['rows']==ev,'old event commitments survive obsolete key path removal')
        q=history(h,'restored-old-bindings',restored,section='bindings',through=bfirst['through'],prefix=bfirst['prefix_digest'],limit=64)
        h.check(q['rows']==bindings,'old binding prefix unchanged by representation and owner paths')
        current=history(h,'relocation-event',restored);row=current['rows'][-1]
        h.check(row['kind']=='RELOCATE' and row['relocation_paths'] is None and str(ident.private_key) not in json.dumps(current) and 'PRIVATE-REASON' not in json.dumps(current),'relocation lineage retained without obsolete path or reason-text disclosure')
        submit(h,'after-relocation-history',restored,peer='C')
        h.check(history(h,'new-binding-after-relocation',restored,section='bindings',limit=1)['through']==bfirst['through']+1,'new mutation under relocated event appends without changing prefix')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'events_before':efirst['through'],'bindings_before':bfirst['through'],'restored_prefix_identical':True,'old_key_paths_removed':True,'relocation':row},indent=2)+'\n');ad.shutdown()
        # The absence was exercised above. Restore the shared fixture identity
        # only after the relocated daemon stops, for unrelated later cases.
        shutil.copyfile(keys/'key.pem',ident.private_key);ident.private_key.chmod(0o600)
        shutil.copyfile(keys/'cert.pem',ident.certificate)
    case('keyed_compaction_signed_encrypted_restore_relocation_and_obsolete_path_redaction',maintenance)

    def large():
        a,b,ac,bc,ad,bd=setup(h,'history-large');ad.shutdown()
        # Synthetic semantically valid history: 256 events and 8192 recovery
        # bindings. No claim these represent real candidate/operator decisions.
        with (a/'state.journal').open('ab') as f:
            for i in range(255):
                p=text('REJECTED')+text('')+bytes(32)+struct.pack('!I',0)+struct.pack('!Q',int(time.time()*1000))+text('LOCAL_CONTROL')+text('opaque /private/history-'+str(i))+text('CONFIG_UNKNOWN_FIELD')
                f.write(frame(22,p))
            for i in range(8192):f.write(frame(23,struct.pack('!QBQQ',1,4,1,i)))
        refs=journal_reference((a/'state.journal').read_bytes())
        ad=Daemon(h,'history-large-loaded',ac,a,readiness_timeout=20);h.daemons.append(ad);ad.start()
        events,q,pages=enumerate_history(h,'large-events',a,limit=64);compare(h,events,refs[0]);h.check(len(events)==256,'maximum retained event count')
        allbindings,bq,bpages=enumerate_history(h,'large-bindings',a,section='bindings',limit=64);compare(h,allbindings,refs[1]);h.check(len(allbindings)==8192,'complete retained binding history above summaries')
        first=history(h,'large-filtered-page',a,section='bindings',event=1,limit=2)
        h.check(first['selected_total']==8192 and first['work']['rows_visited']==2 and first['work']['filter_comparisons']<40,'binary seek not full retained-history scan')
        exact=history(h,'large-last-binding',a,section='bindings',ordinal=8192)
        h.check(exact['rows']==[allbindings[-1]] and exact['work']['rows_visited']==1,'constant direct exact lookup')
        before=(a/'state.journal').read_bytes()
        for i in range(12):
            empty=history(h,'large-empty-'+str(i),a,section='bindings',event=256)
            h.check(empty['selected_total']==0 and empty['work']['rows_visited']==0,'empty rejected-event filter visits no row')
        h.check((a/'state.journal').read_bytes()==before,'large observational polling writes nothing')
        h.run('large-history-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000']);ad.shutdown();ad=h.start('history-large-restart',ac,a)
        end=history(h,'large-prefix-rebuilt',a,section='bindings',through=bq['through'],prefix=bq['prefix_digest'],offset=8191,limit=1)
        h.check(end['rows']==[allbindings[-1]],'replayed derivative root identical after checkpoint')
        (h.output/'LARGE-HISTORY.json').write_text(json.dumps({'origin':'synthetic semantically valid offline records; not genuine failures or network-scale activity','events':256,'bindings':8192,'event_pages':pages,'binding_pages':bpages,'two_row_work':first['work'],'exact_work':exact['work'],'bindings_prefix':bq['prefix_digest']},indent=2)+'\n');ad.shutdown()
    case('maximum_event_history_8192_bindings_bounded_work_and_checkpoint_rebuild',large)



    def alternate():
        a,b,ac,bc,ad,bd=setup(h,'history-alternate')
        submit(h,'alternate-binding',a,peer='C')
        old=history(h,'original-event-prefix',a)
        bound=history(h,'original-binding-prefix',a,section='bindings')
        ad.shutdown()
        raw=(a/'state.journal').read_bytes();changed=bytearray();offset=0;modified=False
        while offset<len(raw):
            n=struct.unpack_from('!I',raw,offset+4)[0];body=raw[offset+8:offset+8+n]
            if body[0]==22 and not modified:
                old_reason=b'initial explicit versioned configuration'
                h.check(old_reason in body,'controlled unkeyed fixture locates retained startup reason')
                body=body.replace(old_reason,b'altered explicit versioned configuration')
                modified=True
            changed+=frame(body[0],body[1:]);offset+=n+40
        h.check(modified,'one historic reason altered with ordinary checksum recomputed')
        (a/'state.journal').write_bytes(changed)
        ad=h.start('history-alternate-restart',ac,a)
        current=history(h,'different-valid-history',a)
        h.check(current['rows'][0]['configuration_digest']==old['rows'][0]['configuration_digest'] and current['prefix_digest']!=old['prefix_digest'],'same accepted settings and event ordinal do not mask changed historical attribution')
        denied=history(h,'changed-event-prefix',a,through=old['through'],prefix=old['prefix_digest'],expected=3)
        h.check(denied['code']=='CONFIGURATION_HISTORY_PREFIX_MISMATCH','saved event commitment rejects alternative valid unkeyed history')
        denied=history(h,'changed-binding-prefix',a,section='bindings',through=bound['through'],prefix=bound['prefix_digest'],expected=3)
        h.check(denied['code']=='CONFIGURATION_HISTORY_PREFIX_MISMATCH','binding commitment includes referred event ancestry, not just canonical config digest')
        ad.shutdown()
    case('same_configuration_alternative_history_changes_event_and_binding_commitments',alternate)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    try:
        cases(h,set(a.case) if a.case else None)
        if not h.cases:raise ValueError('no cases selected')
        ok=True
    except BaseException as e:(h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_CONFIGURATION_HISTORY_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
