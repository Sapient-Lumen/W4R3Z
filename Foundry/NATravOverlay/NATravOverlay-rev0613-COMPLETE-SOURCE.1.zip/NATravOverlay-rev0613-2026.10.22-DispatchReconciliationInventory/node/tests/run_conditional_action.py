#!/usr/bin/env python3
"""Exact conditional counter-action cancellation and durable administrative receipts."""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, signal, socket, struct, subprocess, time
from pathlib import Path
from run_persistent import Harness, operation, raw_control, receive_exact
from run_action_inspection import setup, incoming, query, wait_row
from run_authorization_actions import generation
from run_live_configuration import candidate, activate
from run_state_authentication import new_key, migrate, start as start_keyed, inspect
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control


def text16(value: str) -> bytes:
    raw=value.encode(); return struct.pack('!H',len(raw))+raw


def request_body(row: dict, configuration: str, reason: str) -> bytes:
    return (b'ACA1'+bytes.fromhex(row['action_id'])+
            bytes.fromhex(row['condition']['state_digest'])+
            bytes.fromhex(configuration)+text16(reason))


def packet(row: dict, configuration: str, reason: str) -> bytes:
    # NOC1 + ControlKind::action_conditional (30) + ACA1 request.
    return b'NOC1\x1e'+request_body(row,configuration,reason)


def selected(h: Harness, label: str, state: Path, action: str):
    value=query(h,label,state,action=action,limit=1)
    h.check(len(value['records'])==1,'exact selected action exists')
    row=value['records'][0]
    h.check(row['condition']['format']=='ACTION_SEMANTIC_SELECTION_V1','durable semantic selection returned')
    h.check(row['condition']['metadata_bytes']<=32768,'selection metadata bounded')
    return row,value['configuration_digest']


def cancel_args(state: Path,row: dict,configuration: str,reason: str):
    return ['action-cancel','--control',str(state/'control.sock'),'--action',row['action_id'],
            '--expected-state',row['condition']['state_digest'],
            '--expected-configuration',configuration,'--reason',reason,'--deadline-ms','5000']


def conditional(h: Harness,label: str,state: Path,row: dict,configuration: str,reason: str,
                expected: int=0):
    value=h.run(label,cancel_args(state,row,configuration,reason),expected=expected)
    assert value is not None
    return value


def journal_frames(raw: bytes):
    rows=[];at=0
    while at<len(raw):
        assert raw[at:at+4]==b'NOJ1'
        n=struct.unpack_from('!I',raw,at+4)[0]; body=raw[at+8:at+8+n]
        tag=raw[at+8+n:at+40+n]
        assert hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest()==tag
        rows.append((at,at+40+n,body));at+=40+n
    return rows


def frame(body: bytes) -> bytes:
    return b'NOJ1'+struct.pack('!I',len(body))+body+hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest()


def run_cases(h: Harness, selected_cases: set[str] | None):
    def case(name,fn):
        if not selected_cases or name in selected_cases:h.case(name,fn)

    def exact_and_concurrent():
        state,cfg,port,daemon=setup(h,'conditional-action-basic')
        action,_=incoming(h,'conditional-action-basic-source',port,amount=7,defer=600000)
        row,configuration=selected(h,'conditional-action-selected',state,action)
        reason='cancel exact inspected action without private /path leakage'
        wrong=json.loads(json.dumps(row));wrong['condition']['state_digest']='01'*32
        h.check(conditional(h,'conditional-action-wrong-state',state,wrong,configuration,reason,3)['code']=='ACTION_STATE_CONFLICT','wrong semantic state rejected')
        h.check(conditional(h,'conditional-action-wrong-config',state,row,'02'*32,reason,3)['code']=='ACTION_CONFIGURATION_CONFLICT','wrong accepted configuration rejected')
        ok,_=raw_control(state/'control.sock',packet(row,configuration,reason)+b'!')
        h.check(not ok,'independent request rejects trailing bytes')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda _:raw_control(state/'control.sock',packet(row,configuration,reason)),range(8)))
        h.check(all(ok for ok,_ in results),'all concurrent exact commands return structured results')
        statuses=[value['status'] for _,value in results]
        h.check(statuses.count('APPLIED')==1 and statuses.count('ALREADY_APPLIED')==7,'one cancellation commit and seven immutable receipt confirmations')
        accepted=next(value['accepted_action'] for _,value in results if value['status']=='APPLIED')
        material=b'NATRAV_OVERLAY_ACTION_ADMIN_REQUEST_V1\0'+struct.pack('!I',os.geteuid())+request_body(row,configuration,reason)
        h.check(hashlib.sha256(material).hexdigest()==accepted['request_digest'],'independent UID-bound request digest')
        h.check(reason not in json.dumps(accepted) and accepted['reason_bytes']==len(reason),'free-form reason omitted from receipt')
        after,_=selected(h,'conditional-action-after',state,action)
        h.check(after['status']=='CANCELLED' and after['condition']['retained_actions']==1,'action and administrative receipt committed together')
        h.check(after['condition']['latest_action']['request_digest']==accepted['request_digest'],'query exposes exact latest administrative receipt')
        size=(state/'state.journal').stat().st_size
        repeat=conditional(h,'conditional-action-exact-repeat',state,row,configuration,reason)
        h.check(repeat['status']=='ALREADY_APPLIED' and (state/'state.journal').stat().st_size==size,'exact retry writes no second event')
        h.run('conditional-action-compact',['compact','--control',str(state/'control.sock')]);daemon.shutdown();daemon=h.start('conditional-action-restart',cfg,state)
        rebuilt,_=selected(h,'conditional-action-rebuilt',state,action)
        h.check(rebuilt['condition']==after['condition'],'receipt and selected terminal state survive compaction/restart')
        h.check(conditional(h,'conditional-action-repeat-after-restart',state,row,configuration,reason)['status']=='ALREADY_APPLIED','lost response remains recoverable after restart')
        h.check(conditional(h,'conditional-action-new-intent-terminal',state,rebuilt,configuration,'different decision',3)['code']=='ACTION_CANCELLED','fresh commitment does not override terminal semantics')
        (h.output/'CONCURRENCY.json').write_text(json.dumps({'winner':1,'idempotent':7,'accepted_action':accepted,'after':after},indent=2)+'\n')
        daemon.shutdown()
    case('exact_conflicts_independent_wire_concurrent_receipt_and_restart',exact_and_concurrent)

    def races():
        # Completion between inspection and administration.
        state,cfg,port,daemon=setup(h,'conditional-action-complete',environment={'NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS':'700'})
        action,_=incoming(h,'conditional-action-completing',port,amount=5,defer=0)
        h.wait('conditional action begun',lambda:query(h,'conditional-action-begun',state,action=action)['records'][0]['attempts']==1)
        old,configuration=selected(h,'conditional-action-before-completion',state,action)
        wait_row(h,'conditional-action-completed',state,action,'EXECUTED')
        h.check(conditional(h,'conditional-action-completion-conflict',state,old,configuration,'too late',3)['code']=='ACTION_STATE_CONFLICT','completion after inspection is a typed state conflict')
        daemon.shutdown()

        # Legacy cancellation between inspection and conditional cancellation.
        state,cfg,port,daemon=setup(h,'conditional-action-legacy')
        action,_=incoming(h,'conditional-action-legacy-source',port,amount=3,defer=600000)
        old,configuration=selected(h,'conditional-action-before-legacy',state,action)
        h.run('conditional-action-legacy-cancel',['action-cancel','--control',str(state/'control.sock'),'--action',action,'--reason','legacy cancellation'])
        h.check(conditional(h,'conditional-action-legacy-conflict',state,old,configuration,'stale conditional',3)['code']=='ACTION_STATE_CONFLICT','legacy cancellation invalidates selected state')
        daemon.shutdown()

        # Accepted configuration changes while the action remains pending.
        state,cfg,port,daemon=setup(h,'conditional-action-config')
        action,_=incoming(h,'conditional-action-config-source',port,amount=4,defer=600000)
        old,configuration=selected(h,'conditional-action-before-config',state,action)
        nxt=candidate(h,cfg,'conditional-action-config-next','conditional-action-config-g2')
        activate(h,'conditional-action-activate',state,nxt)
        h.check(conditional(h,'conditional-action-config-conflict',state,old,configuration,'old generation',3)['code']=='ACTION_CONFIGURATION_CONFLICT','accepted configuration change is not silently reinterpreted')
        current,current_configuration=selected(h,'conditional-action-current-config',state,action)
        h.check(conditional(h,'conditional-action-current-cancel',state,current,current_configuration,'current generation')['status']=='APPLIED','fresh current selection succeeds')
        daemon.shutdown()

        # Expiry behind a begun action invalidates the earlier selection.
        state,cfg,port,daemon=setup(h,'conditional-action-expiry',environment={'NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS':'900'},expiry=250)
        blocker,_=incoming(h,'conditional-action-expiry-blocker',port,amount=1,defer=0)
        h.wait('conditional action blocker begun',lambda:query(h,'conditional-action-blocker',state,action=blocker)['records'][0]['attempts']==1)
        action,_=incoming(h,'conditional-action-expiring',port,amount=2,defer=100)
        old,configuration=selected(h,'conditional-action-before-expiry',state,action)
        wait_row(h,'conditional-action-expired',state,action,'EXPIRED')
        h.check(conditional(h,'conditional-action-expiry-conflict',state,old,configuration,'expired selection',3)['code']=='ACTION_STATE_CONFLICT','expiry after inspection is a typed state conflict')
        daemon.shutdown()
    case('completion_cancellation_configuration_and_expiry_conflicts',races)

    def authority():
        state,cfg,port,daemon=setup(h,'conditional-action-authority')
        delegated=candidate(h,cfg,'conditional-action-delegated','conditional-action-authority-g2',
            lambda text:text+f'local_control=65534,ACTION,INSPECT\n')
        activate(h,'conditional-action-delegate',state,delegated)
        expose_control_for_uid(state)
        action,_=incoming(h,'conditional-action-delegated-source',port,amount=4,defer=600000)
        row,configuration=selected(h,'conditional-action-delegated-select',state,action)
        accepted=run_as_uid(h,'conditional-action-delegated-cancel',65534,65534,
            cancel_args(state,row,configuration,'delegated exact action'),0)
        h.check(accepted['status']=='APPLIED' and accepted['accepted_action']['uid']==65534,
            'actual kernel UID is retained in the conditional action receipt')
        action2,_=incoming(h,'conditional-action-revocation-source',port,amount=5,defer=600000)
        row2,configuration2=selected(h,'conditional-action-revocation-select',state,action2)
        payload=packet(row2,configuration2,'revoked while reading')
        marker=Path(f'/tmp/natrav-action-marker-{os.getpid()}');go=Path(f'/tmp/natrav-action-go-{os.getpid()}')
        for path in (marker,go):
            try:path.unlink()
            except FileNotFoundError:pass
        script=r'''
import json,os,socket,struct,sys,time
path,payload_hex,marker,go=sys.argv[1:]
payload=bytes.fromhex(payload_hex)
s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);s.settimeout(8);s.connect(path)
s.sendall(struct.pack('!I',len(payload))+payload[:-1])
open(marker,'w').write('ready')
while not os.path.exists(go):time.sleep(.01)
s.sendall(payload[-1:]);s.shutdown(socket.SHUT_WR)
def recvn(n):
 out=b''
 while len(out)<n:
  part=s.recv(n-len(out))
  if not part:raise RuntimeError('EOF')
  out+=part
 return out
size=struct.unpack('!I',recvn(4))[0];raw=recvn(size);s.close()
print(json.dumps({'ok':raw[4]==0,'value':json.loads(raw[5:])}))
'''
        proc=subprocess.Popen(['/usr/bin/setpriv','--reuid=65534','--regid=65534','--clear-groups',
            'python3','-c',script,str(state/'control.sock'),payload.hex(),str(marker),str(go)],
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        h.wait('conditional action delegated partial request',marker.exists,timeout=8)
        revoked=candidate(h,delegated,'conditional-action-revoked','conditional-action-authority-g3',
            lambda text:text.replace('local_control=65534,ACTION,INSPECT\n',''))
        activate(h,'conditional-action-revoke',state,revoked);go.write_text('continue')
        stdout,stderr=proc.communicate(timeout=8);h.commands.append({'label':'conditional-action-partial-revocation','args':['setpriv','partial-control'],'returncode':proc.returncode,'stdout':stdout,'stderr':stderr})
        h.check(proc.returncode==0,'delegated partial client completed')
        result=json.loads(stdout);h.check(not result['ok'] and result['value']['code']=='LOCAL_CONTROL_CLASS_DENIED',
            'partial conditional request uses post-decode current authority')
        h.check(selected(h,'conditional-action-revoked-still-pending',state,action2)[0]['status']=='PENDING',
            'revoked request causes no action mutation')
        restore_owner_only_control(state);daemon.shutdown()
        for path in (marker,go):
            try:path.unlink()
            except FileNotFoundError:pass
    case('real_uid_receipt_and_post_decode_live_revocation',authority)

    def crash_boundaries():
        observations={}
        for phase in ('BEFORE','AFTER'):
            state,cfg,port,daemon=setup(h,'conditional-action-kill-'+phase.lower())
            action,_=incoming(h,'conditional-action-kill-source-'+phase,port,amount=6,defer=600000)
            row,configuration=selected(h,'conditional-action-kill-select-'+phase,state,action)
            daemon.shutdown();daemon=h.start('conditional-action-kill-hook-'+phase,cfg,state,{f'NATRAV_OVERLAY_TEST_ACTION_CONDITION_{phase}_COMMIT_MS':'3000'})
            command=cancel_args(state,row,configuration,'crash boundary '+phase)
            with (h.logs/f'conditional-action-kill-{phase}.txt').open('w') as out:
                client=subprocess.Popen([str(h.binary),*command],stdout=out,stderr=subprocess.STDOUT,text=True)
                h.wait('conditional action commit hook '+phase,lambda:f'ACTION_CONDITION_{phase}_COMMIT' in daemon.stderr_path.read_text(),timeout=8)
                daemon.kill();client.wait(timeout=8)
            daemon=h.start('conditional-action-kill-recovered-'+phase,cfg,state)
            restored,_=selected(h,'conditional-action-kill-state-'+phase,state,action)
            expected='PENDING' if phase=='BEFORE' else 'CANCELLED'
            h.check(restored['status']==expected,'crash boundary retains one authoritative side')
            repeated=conditional(h,'conditional-action-kill-retry-'+phase,state,row,configuration,'crash boundary '+phase)
            h.check(repeated['status']==('APPLIED' if phase=='BEFORE' else 'ALREADY_APPLIED'),'receipt and action effect share the commit boundary')
            observations[phase]={'restored':restored['status'],'retry':repeated['status']}
            daemon.shutdown()
        (h.output/'CRASH-BOUNDARIES.json').write_text(json.dumps(observations,indent=2)+'\n')
    case('real_sigkill_before_and_after_atomic_action_receipt',crash_boundaries)

    def maintenance():
        state,cfg,port,daemon=setup(h,'conditional-action-maintenance')
        action,_=incoming(h,'conditional-action-maintenance-source',port,amount=9,defer=600000)
        row,configuration=selected(h,'conditional-action-maintenance-select',state,action)
        accepted=conditional(h,'conditional-action-maintenance-cancel',state,row,configuration,'preserve receipt')
        daemon.shutdown()
        key=new_key(h,h.work,'conditional-action-state-g1');migrate(h,'conditional-action-migrate',state,key,node='B')
        daemon=start_keyed(h,'conditional-action-keyed',cfg,state,key)
        # Append a freshly authenticated kind-36 record after migration.
        action2,_=incoming(h,'conditional-action-second-source',port,amount=2,defer=600000)
        row2,configuration2=selected(h,'conditional-action-second-select',state,action2)
        conditional(h,'conditional-action-second-cancel',state,row2,configuration2,'authenticated receipt')
        daemon.shutdown()
        audit=h.run('conditional-action-audit',['state-auth-audit','--state',str(state),'--node','B','--state-auth-key',str(key)])
        daemon=start_keyed(h,'conditional-action-compact-owner',cfg,state,key);h.run('conditional-action-compact-keyed',['compact','--control',str(state/'control.sock')]);daemon.shutdown()
        before=inspect(h,'conditional-action-before-backup',state,key,node='B')
        crypt=h.work/'conditional-action-backup.key';h.run('conditional-action-backup-key',['backup-key-init','--output',str(crypt),'--generation','conditional-action-archive'])
        ident=h.identity('B');archive=h.work/'conditional-action.nob'
        h.run('conditional-action-export',['backup-export','--state',str(state),'--node','B','--generation',generation('B'),'--state-auth-key',str(key),'--output',str(archive),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'conditional-action-restored';h.run('conditional-action-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','B','--generation',generation('B'),'--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'conditional-action-restored-state',restored,key,node='B')
        h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'conditional action receipts survive encrypted restore exactly')
        moved=candidate(h,cfg,'conditional-action-moved','conditional-action-moved-g2',lambda t:t.replace('state='+str(state),'state='+str(restored)))
        h.run('conditional-action-relocate',['state-relocate','--state',str(restored),'--node','B','--candidate',str(moved),'--reason','move conditional action state','--state-auth-key',str(key)])
        daemon=start_keyed(h,'conditional-action-restored-owner',moved,restored,key)
        repeated=conditional(h,'conditional-action-old-command-after-relocation',restored,row,configuration,'preserve receipt')
        h.check(repeated['status']=='ALREADY_APPLIED' and repeated['accepted_action']==accepted['accepted_action'],'exact historical receipt survives path relocation without another effect')
        daemon.shutdown()
        offline=inspect(h,'conditional-action-offline-final',restored,key,node='B')
        h.check(len(offline['conditional_action_cancellations'])==2,'offline reconstruction exposes both attributable conditional cancellations')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'before_digest':before['storage']['logical_state_digest'],'after_digest':after['storage']['logical_state_digest'],'audit':audit,'receipts':offline['conditional_action_cancellations']},indent=2)+'\n')
    case('keyed_audit_compaction_encrypted_restore_relocation_and_exact_retry',maintenance)

    def corruption():
        state,cfg,port,daemon=setup(h,'conditional-action-corrupt')
        action,_=incoming(h,'conditional-action-corrupt-source',port,amount=4,defer=600000)
        row,configuration=selected(h,'conditional-action-corrupt-select',state,action)
        conditional(h,'conditional-action-corrupt-cancel',state,row,configuration,'semantic corruption target')
        daemon.shutdown();journal=state/'state.journal';original=journal.read_bytes();frames=journal_frames(original)
        index=next(i for i,(_,_,body) in enumerate(frames) if body[0]==36)
        start,end,body=frames[index];changed=bytearray(body);at=body.index(bytes.fromhex(row['condition']['state_digest']));changed[at]^=1
        journal.write_bytes(original[:start]+frame(bytes(changed))+original[end:])
        bad=h.run('conditional-action-forged-selected-state',['inspect','--state',str(state),'--node','B'],expected=3)
        h.check(bad['code'] in ('JOURNAL_CORRUPT','ACTION_CONDITION_INVALID'),'recomputed outer checksum cannot bypass selected action semantics')
        journal.write_bytes(original);daemon=h.start('conditional-action-corruption-restored',cfg,state);h.run('conditional-action-corruption-compact',['compact','--control',str(state/'control.sock')]);daemon.shutdown()
        checkpoint=journal.read_bytes();body=bytearray(journal_frames(checkpoint)[0][2]);at=body.index(bytes.fromhex(row['condition']['state_digest']));body[at]^=1
        logical=body.index(b'NLS2');body[logical-48:logical-16]=hashlib.sha256(b'NATRAV_OVERLAY_LOGICAL_STATE_V2\0'+bytes(body[logical:])).digest()
        journal.write_bytes(frame(bytes(body)))
        bad=h.run('conditional-action-forged-checkpoint',['inspect','--state',str(state),'--node','B'],expected=3)
        h.check(bad['code'] in ('JOURNAL_CORRUPT','ACTION_CONDITION_INVALID') and 'header is invalid' not in bad.get('message',''),'checkpoint replay rejects forged conditional action provenance')
        journal.write_bytes(checkpoint)
    case('semantic_journal_and_checkpoint_corruption_after_checksum_recomputation',corruption)


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    try:
        run_cases(h,set(a.case) if a.case else None)
        if not h.cases:raise ValueError('no selected cases')
        ok=True
    except BaseException as exc:
        (h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(f'FAIL: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_CONDITIONAL_ACTION_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(x['status']=='PASS' for x in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,value in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1

if __name__=='__main__':raise SystemExit(main())
