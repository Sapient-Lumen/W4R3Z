#!/usr/bin/env python3
"""Authenticated remote source-subscription requests over the native TLS/NOS1 peer path."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import ssl
import struct
import subprocess
import time
from typing import Any

from run_persistent import Harness, free_port, operation, receive_exact
from run_local_evidence import config as author_config, author
from run_source_subscriptions import command as local_subscription, ack, decode_envelope
from run_evidence_queries import config as peer_config
from run_live_configuration import candidate, activate
from run_state_authentication import new_key, migrate, start as start_keyed, inspect
from run_tls_security import client_context
from run_peer_sessions import (
    frame, receive_frame, decode_session, encode_session,
    SESSION_OPEN, SESSION_OPEN_ACK, SESSION_REQUEST, SESSION_RESPONSE,
)
from run_integration import hello

SCOPE = "query/series"


def provider_config(
    h: Harness,
    name: str,
    state: Path,
    provider_port: int,
    subscriber_port: int,
    *,
    extra_inbound: list[str] | None = None,
    alternate_c_generation: bool = False,
    maximum_records: int = 8,
    maximum_bytes: int = 10_000,
) -> Path:
    inbound = ["C", *(extra_inbound or [])]
    path = author_config(
        h, name, state, node="A", port=provider_port,
        peers=[("C", subscriber_port)], inbound=inbound,
    )
    text = path.read_text().replace("CONFIG_V14", "CONFIG_V15")
    text = text.replace(",EVIDENCE_AUTHOR\n", ",EVIDENCE_AUTHOR,SOURCE_DISCLOSE\n", 1)
    # C must be able to admit the ordinary NSE1 delivery envelope later.
    text += f"authorize=C,*,EVIDENCE,{SCOPE}\n"
    if alternate_c_generation:
        alternate = h.identity("C-alt")
        text += f"peer_key=C,c-g2,RETIRED,{alternate.spki_sha256}\n"
    uid = os.geteuid()
    text += (
        f"source_disclosure=g1,{uid},{uid},C,c-g1,{SCOPE},"
        f"{maximum_records},{maximum_bytes}\n"
    )
    path.write_text(text)
    path.chmod(0o600)
    return path


def subscriber_config(
    h: Harness,
    name: str,
    state: Path,
    node: str,
    listen_port: int,
    provider_port: int,
    *,
    identity_label: str | None = None,
    generation: str | None = None,
    failover_port: int | None = None,
) -> Path:
    path = author_config(
        h, name, state, node=node, port=listen_port,
        peers=[("A", provider_port)], inbound=["A"],
    )
    text = path.read_text()
    text += f"authorize=A,*,EVIDENCE,{SCOPE}\n"
    text += f"evidence_read={os.geteuid()},A,{SCOPE},PAYLOAD\n"
    if identity_label is not None:
        identity = h.identity(identity_label)
        lines = []
        for line in text.splitlines():
            if line.startswith("identity_cert="):
                line = f"identity_cert={identity.certificate}"
            elif line.startswith("identity_key="):
                line = f"identity_key={identity.private_key}"
            elif line.startswith("identity_pin="):
                line = f"identity_pin={identity.spki_sha256}"
            elif line.startswith("identity_generation="):
                line = f"identity_generation={generation or node.lower() + '-g1'}"
            lines.append(line)
        text = "\n".join(lines) + "\n"
    if failover_port is not None:
        lines = []
        for line in text.splitlines():
            if line.startswith("peer_route=A,primary,"):
                fields = line.split(",")
                lines.append(f"peer_route=A,preferred-dead,0,ENABLED,127.0.0.1:{failover_port}")
                lines.append(f"peer_route=A,secondary-live,10,ENABLED,{fields[-1]}")
            else:
                lines.append(line)
        text = "\n".join(lines) + "\n"
    path.write_text(text)
    path.chmod(0o600)
    return path


def request(
    h: Harness,
    label: str,
    config: Path,
    request_id: str,
    *,
    reason: str = "subscriber explicitly requests the accepted finite grant",
    expected: int = 0,
) -> dict[str, Any]:
    result = h.run(label, [
        "source-subscription-request", "--config", str(config),
        "--provider", "A", "--grant", "g1",
        "--request-id", request_id, "--reason", reason,
        "--deadline-ms", "5000",
    ], expected=expected)
    assert result is not None
    if expected == 0:
        h.check(result["format"] == "NATRAV_OVERLAY_REMOTE_SOURCE_SUBSCRIPTION_RESPONSE_V1",
                "remote request has explicit response format")
    return result


def status(h: Harness, label: str, config: Path, request_id: str, expected: int = 0) -> dict[str, Any]:
    result = h.run(label, [
        "source-subscription-remote-status", "--config", str(config),
        "--provider", "A", "--grant", "g1",
        "--request-id", request_id, "--deadline-ms", "5000",
    ], expected=expected)
    assert result is not None
    return result




def recipient_record(h: Harness, label: str, state: Path, issued: dict[str, Any]) -> dict[str, Any]:
    operation_id = issued["latest"]["operation_id"]
    result = h.run(label, ["evidence-query", "--control", str(state / "control.sock"),
        "--view", "history", "--operation", operation_id, "--payload", "yes",
        "--payload-length", "16384", "--deadline-ms", "5000"])
    assert result is not None
    h.check(result["format"] in ("NATRAV_OVERLAY_EVIDENCE_QUERY_V1",
                                  "NATRAV_OVERLAY_EVIDENCE_QUERY_V2") and
            len(result["records"]) == 1,
            "recipient query returns one admitted subscription envelope")
    record = result["records"][0]
    decoded = decode_envelope(bytes.fromhex(record["payload_hex"]))
    h.check(decoded["operation_id"] == operation_id,
            "independent envelope operation identity matches admission")
    h.check("local_authorship" not in record,
            "remote delivery is never relabeled local authorship")
    return decoded

def text16(value: str) -> bytes:
    raw = value.encode("ascii")
    return struct.pack("!H", len(raw)) + raw


def remote_wire(request_id: str, command: int, grant: str = "g1", reason: str = "wire request") -> bytes:
    return b"NOA1" + bytes([5]) + bytes.fromhex(request_id) + bytes([command]) + text16(grant) + text16(reason)


def decode_error(payload: bytes) -> dict[str, Any]:
    if len(payload) < 7 or payload[:4] != b"NOA1" or payload[4] != 4:
        raise AssertionError(f"expected NOA1 error, got {payload[:16]!r}")
    i = 5
    has = payload[i]; i += 1
    op = None
    if has:
        op = payload[i:i+32].hex(); i += 32
    n = struct.unpack("!H", payload[i:i+2])[0]; i += 2
    code = payload[i:i+n].decode("ascii"); i += n
    n = struct.unpack("!H", payload[i:i+2])[0]; i += 2
    detail = payload[i:i+n].decode("utf-8"); i += n
    if i != len(payload):
        raise AssertionError("trailing error bytes")
    return {"operation": op, "code": code, "detail": detail}


def decode_remote_response(payload: bytes) -> dict[str, Any]:
    if len(payload) < 5 or payload[:4] != b"NOA1" or payload[4] != 6:
        raise AssertionError("expected remote subscription response")
    i = 5
    def take(n: int) -> bytes:
        nonlocal i
        if i + n > len(payload): raise AssertionError("truncated remote response")
        value = payload[i:i+n]; i += n; return value
    def txt() -> str:
        return take(struct.unpack("!H", take(2))[0]).decode("ascii")
    value = {
        "request_id": take(32).hex(), "provider": txt(), "grant": txt(),
        "instance": take(32).hex(), "revision": int.from_bytes(take(8), "big"),
        "retired": bool(take(1)[0]), "disposition": txt(),
        "issued": int.from_bytes(take(4), "big"),
        "acknowledged": int.from_bytes(take(4), "big"),
        "used_payload_bytes": int.from_bytes(take(8), "big"),
        "maximum_records": int.from_bytes(take(4), "big"),
        "maximum_payload_bytes": int.from_bytes(take(8), "big"),
        "grant_digest": take(32).hex(), "subscriber_generation": txt(),
        "subscriber_spki": take(32).hex(), "accepted_request_id": take(32).hex(),
        "accepted_configuration_event": int.from_bytes(take(8), "big"),
        "accepted_unix_ms": int.from_bytes(take(8), "big"),
    }
    if i != len(payload): raise AssertionError("trailing remote response bytes")
    return value


class IndependentSession:
    def __init__(self, h: Harness, port: int, identity: str, claimed_node: str, label: str):
        self.h = h
        self.raw = socket.create_connection(("127.0.0.1", port), timeout=3)
        self.channel = client_context(h, identity).wrap_socket(self.raw, server_hostname=None)
        self.channel.settimeout(5)
        hello_request = operation(label + "-hello")
        self.channel.sendall(frame(hello(claimed_node, hello_request)))
        ack = json.loads(receive_frame(self.channel))
        h.check(ack["kind"] == "HELLO_ACK" and ack["request_id"] == hello_request,
                "independent client completed authenticated HELLO")
        self.session = bytes.fromhex(operation(label + "-session"))
        self.limits = (8, 1_048_576, 30_000, 2_000)
        self.channel.sendall(frame(encode_session(
            SESSION_OPEN, self.session, 0, b"\0" * 32, limits=self.limits)))
        opened = decode_session(receive_frame(self.channel))
        h.check(opened["kind"] == SESSION_OPEN_ACK and opened["session"] == self.session,
                "independent client opened NOS1")
        self.sequence = 1

    def exchange(self, operation_id: str, payload: bytes) -> bytes:
        self.channel.sendall(frame(encode_session(
            SESSION_REQUEST, self.session, self.sequence,
            bytes.fromhex(operation_id), payload)))
        response = decode_session(receive_frame(self.channel))
        if response["kind"] != SESSION_RESPONSE or response["sequence"] != self.sequence:
            raise AssertionError("invalid NOS1 response binding")
        if response["operation"].hex() != operation_id:
            raise AssertionError("response operation mismatch")
        self.sequence += 1
        return response["payload"]

    def close(self) -> None:
        try: self.channel.close()
        finally: self.raw.close()


def run_cases(h: Harness, selected: set[str] | None = None) -> None:
    def case(name: str, fn) -> None:
        if selected is None or name in selected:
            h.case(name, fn)

    def authorized() -> None:
        a, c = h.runtime / "authorized-a", h.runtime / "authorized-c"
        ap, cp = free_port(), free_port()
        pa = provider_config(h, "authorized-a", a, ap, cp)
        pc = subscriber_config(h, "authorized-c", c, "C", cp, ap)
        ad = h.start("authorized-a", pa, a)
        cd = h.start("authorized-c", pc, c)
        rid = operation("authorized-request")
        accepted = request(h, "authorized-request", pc, rid)
        h.check(accepted["disposition"] == "ACCEPTED" and accepted["revision"] == 1,
                "authenticated subscriber creates one bounded provider instance")
        again = request(h, "authorized-retry", pc, rid)
        h.check(again["disposition"] == "ALREADY_ACCEPTED" and again["instance"] == accepted["instance"],
                "exact retry is idempotent")
        changed = request(h, "authorized-new-id", pc, operation("authorized-request-2"))
        h.check(changed["disposition"] == "ALREADY_REQUESTED" and changed["accepted_request_id"] == rid,
                "changed request ID cannot replenish one immutable grant")
        conflict = request(h, "authorized-id-conflict", pc, rid, reason="different content", expected=3)
        h.check(conflict["code"] == "SOURCE_SUBSCRIPTION_REMOTE_REQUEST_CONFLICT",
                "one request identity cannot name different content")
        remote_status = status(h, "authorized-status", pc, operation("authorized-status"))
        h.check(remote_status["disposition"] == "STATUS" and remote_status["instance"] == accepted["instance"],
                "subscriber sees only bounded instance status")
        provider_status = local_subscription(h, "provider-status", a, "status")
        admission = provider_status["remote_admission"]
        h.check(admission["peer"] == "C" and admission["generation"] == "c-g1" and provider_status["pid"] == 0,
                "provider records actual remote actor without fabricated local PID")

        first = author(h, "remote-source-original", a, value="first source")
        issued = local_subscription(h, "remote-source-issue", a, "step", previous=provider_status)
        progressed = ack(h, "remote-source-ack", a, issued)
        decoded = recipient_record(h, "remote-source-record", c, issued)
        h.check(decoded["source_operation"] == first["operation_id"] and decoded["mapped_corrects"] is None,
                "provider manager uses remotely admitted state for ordinary delivery")
        correction = author(h, "remote-source-correction", a, parent=first["operation_id"], value="corrected source")
        corrected_issue = local_subscription(h, "remote-correction-issue", a, "step", previous=progressed)
        final = ack(h, "remote-correction-ack", a, corrected_issue)
        mapped = recipient_record(h, "remote-correction-record", c, corrected_issue)
        h.check(mapped["source_operation"] == correction["operation_id"] and
                mapped["mapped_corrects"] == issued["latest"]["operation_id"],
                "recipient correction ancestry uses acknowledged delivery mapping")
        observed = status(h, "remote-progress-status", pc, operation("remote-progress-status"))
        h.check(observed["revision"] == final["revision"] and observed["acknowledged"] == 2,
                "remote status reports bounded progress without source payloads")
        h.run("remote-request-compact", ["compact", "--control", str(ad.control)])
        ad.shutdown()
        ad = h.start("authorized-a-restart", pa, a)
        reconstructed = status(h, "remote-restart-status", pc, operation("remote-restart-status"))
        h.check(reconstructed["accepted_request_id"] == rid and reconstructed["acknowledged"] == 2,
                "remote actor and progress survive compaction and restart")
        ad.shutdown(); cd.shutdown()
        (h.output / "AUTHORIZED-PIPELINE.json").write_text(json.dumps({
            "request": accepted, "final_status": reconstructed,
            "source_operations": [first["operation_id"], correction["operation_id"]],
        }, indent=2, sort_keys=True) + "\n")
    case("authenticated_request_retry_status_and_delivery", authorized)

    def identity_and_privacy() -> None:
        a, c, b = (h.runtime / name for name in ("identity-a", "identity-c", "identity-b"))
        ap, cp, bp = free_port(), free_port(), free_port()
        pa = provider_config(h, "identity-a", a, ap, cp,
                             extra_inbound=["B"], alternate_c_generation=True)
        pc = subscriber_config(h, "identity-c", c, "C", cp, ap)
        pb = subscriber_config(h, "identity-b", b, "B", bp, ap)
        pc2 = subscriber_config(h, "identity-c-alt", h.runtime / "identity-c-alt", "C",
                                free_port(), ap, identity_label="C-alt", generation="c-g2")
        ad = h.start("identity-a", pa, a)
        denied = request(h, "wrong-subscriber", pb, operation("wrong-subscriber"), expected=3)
        h.check(denied["code"] == "SOURCE_SUBSCRIPTION_REMOTE_DENIED",
                "authenticated wrong node cannot inspect or create the grant")
        wrong_generation = request(h, "wrong-generation", pc2, operation("wrong-generation"), expected=3)
        h.check(wrong_generation["code"] == "SOURCE_SUBSCRIPTION_REMOTE_DENIED",
                "authenticated retired generation cannot claim active-generation grant")
        missing = status(h, "not-created-status", pc, operation("not-created-status"), expected=3)
        h.check(missing["code"] == "SOURCE_SUBSCRIPTION_REMOTE_NOT_FOUND",
                "exact subscriber learns only that its own grant has no instance")
        accepted = request(h, "identity-correct", pc, operation("identity-correct"))
        denied_status = status(h, "wrong-subscriber-status", pb, operation("wrong-subscriber-status"), expected=3)
        h.check(denied_status["code"] == "SOURCE_SUBSCRIPTION_REMOTE_DENIED",
                "another authenticated subscriber cannot read status")
        local_retry = local_subscription(h, "provider-create-after-remote", a, "create")
        h.check(local_retry["disposition"] == "ALREADY_REMOTE_REQUESTED" and
                local_retry["instance"] == accepted["instance"],
                "provider create does not replace or replenish remote admission")
        ad.shutdown()
    case("exact_subscriber_generation_and_status_privacy", identity_and_privacy)

    def wire_and_policy() -> None:
        a, c = h.runtime / "wire-a", h.runtime / "wire-c"
        ap, cp = free_port(), free_port()
        pa = provider_config(h, "wire-a", a, ap, cp)
        pc = subscriber_config(h, "wire-c", c, "C", cp, ap, failover_port=free_port())
        ad = h.start("wire-a", pa, a)
        accepted = request(h, "route-failover-request", pc, operation("route-failover-request"))
        h.check(accepted["disposition"] == "ACCEPTED",
                "subscriber request fails over from unavailable preferred route")
        ad.shutdown()

        # Fresh state for an independent wire and current-policy test.
        a2 = h.runtime / "wire-policy-a"; ap2, cp2 = free_port(), free_port()
        pa2 = provider_config(h, "wire-policy-a", a2, ap2, cp2)
        ad2 = h.start("wire-policy-a", pa2, a2)
        session = IndependentSession(h, ap2, "C", "C", "wire-policy")
        malformed_id = operation("malformed-command")
        malformed = session.exchange(malformed_id, remote_wire(malformed_id, 9))
        error = decode_error(malformed)
        h.check(error["operation"] == malformed_id and error["code"] == "SOURCE_SUBSCRIPTION_REMOTE_INVALID",
                "strict independent wire rejects unknown remote command")
        trailing_id = operation("trailing-request")
        trailing = decode_error(session.exchange(
            trailing_id, remote_wire(trailing_id, 1, reason="strict") + b"x"))
        h.check(trailing["code"] == "APPLICATION_SCHEMA_REJECTED",
                "strict independent wire rejects trailing material")
        valid_id = operation("independent-valid")
        decoded = decode_remote_response(session.exchange(
            valid_id, remote_wire(valid_id, 1, reason="independent bounded request")))
        h.check(decoded["request_id"] == valid_id and decoded["disposition"] == "ACCEPTED",
                "independent TLS/NOS1 implementation receives bound response")
        session.close(); ad2.shutdown()

        # A request already connected under the old policy is rechecked after live removal.
        a3 = h.runtime / "live-policy-a"; ap3, cp3 = free_port(), free_port()
        pa3 = provider_config(h, "live-policy-a", a3, ap3, cp3)
        pc3 = subscriber_config(h, "live-policy-c", h.runtime / "live-policy-c", "C", cp3, ap3)
        ad3 = h.start("live-policy-a", pa3, a3)
        connected = IndependentSession(h, ap3, "C", "C", "live-policy")
        removed = candidate(h, pa3, "live-policy-removed", "live-policy-removed-g1",
                            lambda text: "\n".join(line for line in text.splitlines()
                                if not line.startswith("source_disclosure=")) + "\n")
        activate(h, "remove-disclosure-grant", a3, removed)
        current_id = operation("policy-removed-open-session")
        retired = decode_error(connected.exchange(
            current_id, remote_wire(current_id, 1, reason="must use current policy")))
        h.check(retired["code"] == "SOURCE_SUBSCRIPTION_REMOTE_DENIED",
                "open session rechecks the current disclosure grant: " + repr(retired))
        connected.close()
        denied = request(h, "policy-removed-reconnect", pc3,
                         operation("policy-removed-reconnect"), expected=3)
        h.check(denied["code"] == "SOURCE_SUBSCRIPTION_REMOTE_DENIED",
                "reconnected request cannot recreate removed authority")
        ad3.shutdown()
    case("route_failover_independent_wire_and_live_policy_recheck", wire_and_policy)

    def kill_boundaries() -> None:
        observations = []
        for boundary in ("BEFORE", "AFTER"):
            a, c = h.runtime / f"kill-{boundary.lower()}-a", h.runtime / f"kill-{boundary.lower()}-c"
            ap, cp = free_port(), free_port()
            pa = provider_config(h, f"kill-{boundary.lower()}-a", a, ap, cp)
            pc = subscriber_config(h, f"kill-{boundary.lower()}-c", c, "C", cp, ap)
            environment = {f"NATRAV_OVERLAY_TEST_REMOTE_SOURCE_REQUEST_{boundary}_COMMIT_MS": "10000"}
            ad = h.start(f"kill-{boundary.lower()}-a", pa, a, environment)
            rid = operation(f"kill-{boundary.lower()}-request")
            args = [str(h.binary), "source-subscription-request", "--config", str(pc),
                    "--provider", "A", "--grant", "g1", "--request-id", rid,
                    "--reason", f"kill boundary {boundary.lower()}", "--deadline-ms", "15000"]
            baseline = (a / "state.journal").stat().st_size
            proc = subprocess.Popen(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    start_new_session=True)
            if boundary == "AFTER":
                h.wait("remote request physically appended", lambda: (a / "state.journal").stat().st_size > baseline, 5)
            else:
                time.sleep(0.5)
                h.check(proc.poll() is None, "remote request reached bounded pre-commit pause")
            ad.kill()
            try: stdout, stderr = proc.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill(); stdout, stderr = proc.communicate(timeout=2)
            h.commands.append({"label": f"kill-client-{boundary.lower()}", "args": args[1:],
                               "returncode": proc.returncode, "stdout": stdout, "stderr": stderr,
                               "elapsed_seconds": 0.0})
            offline = inspect(h, f"kill-offline-{boundary.lower()}", a)
            count = len(offline["source_subscriptions"])
            h.check(count == (1 if boundary == "AFTER" else 0),
                    "remote admission shares exact synchronized commit boundary")
            ad = h.start(f"kill-restart-{boundary.lower()}", pa, a)
            retry = request(h, f"kill-retry-{boundary.lower()}", pc, rid,
                            reason=f"kill boundary {boundary.lower()}")
            expected = "ALREADY_ACCEPTED" if boundary == "AFTER" else "ACCEPTED"
            h.check(retry["disposition"] == expected,
                    "exact retry reconstructs pre/post commit outcome")
            ad.shutdown()
            observations.append({"boundary": boundary, "offline_instances": count,
                                 "retry_disposition": retry["disposition"]})
        (h.output / "COMMIT-BOUNDARIES.json").write_text(
            json.dumps(observations, indent=2, sort_keys=True) + "\n")
    case("real_kills_around_remote_admission_commit", kill_boundaries)

    def maintenance() -> None:
        a, c = h.runtime / "maintenance-a", h.runtime / "maintenance-c"
        ap, cp = free_port(), free_port()
        pa = provider_config(h, "maintenance-a", a, ap, cp)
        pc = subscriber_config(h, "maintenance-c", c, "C", cp, ap)
        ad = h.start("maintenance-a", pa, a)
        rid = operation("maintenance-request")
        accepted = request(h, "maintenance-request", pc, rid)
        source = author(h, "maintenance-source", a, value="durable remote admission")
        issued = local_subscription(h, "maintenance-issue", a, "step", previous=accepted)
        ad.shutdown()
        key = new_key(h, h.work, "remote-request-state-g1")
        migrate(h, "remote-request-migrate", a, key)
        ad = start_keyed(h, "maintenance-keyed", pa, a, key)
        h.run("remote-request-compact", ["compact", "--control", str(ad.control)])
        ad.shutdown()
        before = inspect(h, "remote-request-before-backup", a, key)
        h.run("remote-request-audit", ["state-auth-audit", "--state", str(a),
              "--node", "A", "--state-auth-key", str(key)])
        encryption = h.work / "remote-request-backup.key"
        h.run("remote-request-backup-key", ["backup-key-init", "--output", str(encryption),
              "--generation", "remote-request-backup-g1"])
        identity = h.identity("A"); archive = h.work / "remote-request.nob"
        h.run("remote-request-export", ["backup-export", "--state", str(a), "--node", "A",
              "--generation", "a-g1", "--output", str(archive), "--state-auth-key", str(key),
              "--encrypt-key", str(encryption), "--sign-key", str(identity.private_key),
              "--sign-cert", str(identity.certificate)])
        restored = h.runtime / "maintenance-restored"
        h.run("remote-request-restore", ["backup-restore", "--input", str(archive),
              "--destination", str(restored), "--node", "A", "--generation", "a-g1",
              "--state-auth-key", str(key), "--decrypt-key", str(encryption),
              "--trusted-cert", str(identity.certificate), "--require-signature", "yes",
              "--require-encryption", "yes"])
        after = inspect(h, "remote-request-restored-inspect", restored, key)
        h.check(before["source_subscriptions"] == after["source_subscriptions"],
                "remote request provenance and pending mapping survive encrypted restore")
        moved = candidate(h, pa, "remote-request-moved", "remote-request-moved-g1",
                          lambda text: text.replace("state=" + str(a), "state=" + str(restored)))
        h.run("remote-request-relocate", ["state-relocate", "--state", str(restored),
              "--node", "A", "--candidate", str(moved), "--reason", "move remote request state",
              "--state-auth-key", str(key)])
        cd = h.start("maintenance-c", pc, c)
        ad = start_keyed(h, "maintenance-restored", moved, restored, key)
        progressed = ack(h, "maintenance-restored-ack", restored, issued)
        observed = status(h, "maintenance-remote-status", pc, operation("maintenance-remote-status"))
        h.check(observed["accepted_request_id"] == rid and observed["acknowledged"] == 1 and
                observed["revision"] == progressed["revision"],
                "subscriber status continues after authenticated restore and relocation")
        decoded = recipient_record(h, "maintenance-restored-record", c, issued)
        h.check(decoded["source_operation"] == source["operation_id"],
                "restored delivery retains exact source mapping")
        ad.shutdown(); cd.shutdown()
        (h.output / "RESTORED-REMOTE-REQUEST.json").write_text(
            json.dumps(observed, indent=2, sort_keys=True) + "\n")
    case("authenticated_compaction_encrypted_restore_and_relocation", maintenance)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append")
    args = parser.parse_args()
    if args.output.exists(): parser.error("output must not already exist")
    h = Harness(args.binary, args.output)
    started = time.time(); ok = False
    try:
        run_cases(h, set(args.case) if args.case else None); ok = True
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=os.sys.stderr)
    finally:
        h.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_SUBSCRIBER_REQUEST_TESTS_V1",
            "status": "PASS" if ok else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "cases_total": len(h.cases),
            "cases_passed": sum(c["status"] == "PASS" for c in h.cases),
            "assertions": h.assertions,
            "commands": len(h.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (("SUMMARY", summary), ("CASES", h.cases), ("COMMANDS", h.commands)):
            (h.output / (name + ".json")).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary), flush=True)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
