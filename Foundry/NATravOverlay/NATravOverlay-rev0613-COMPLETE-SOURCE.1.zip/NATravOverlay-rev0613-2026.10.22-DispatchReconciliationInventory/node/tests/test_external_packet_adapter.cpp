#include "external_packet_adapter.hpp"
#include "peer_session.hpp"
#include "protocol.hpp"
#include "socket.hpp"
#include "tls.hpp"

#include <algorithm>
#include <atomic>
#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <thread>
#include <utility>
#include <variant>
#include <vector>

namespace {

using natrav_overlay::AppError;
using natrav_overlay::Deadline;
using natrav_overlay::DeliveryReceipt;
using natrav_overlay::EvidenceRecord;
using natrav_overlay::ExternalPacketAdapterOptions;
using natrav_overlay::FramedReader;
using natrav_overlay::IoCounters;
using natrav_overlay::IoOptions;
using natrav_overlay::KeyGenerationState;
using natrav_overlay::OutboundPeerSession;
using natrav_overlay::PacketPortOrderedStreamOptions;
using natrav_overlay::PeerSessionFrame;
using natrav_overlay::PeerSessionFrameKind;
using natrav_overlay::PeerSessionLimits;
using natrav_overlay::ReceiptDisposition;
using natrav_overlay::SupervisedExternalPacketAdapterControl;
using natrav_overlay::TlsChannel;
using natrav_overlay::TlsContext;
using natrav_overlay::TlsIdentityFiles;
using natrav_overlay::TlsTrustedGeneration;
using natrav_overlay::TlsTrustedIdentity;

struct CaseRecord final {
    std::string name;
    std::size_t assertions{0U};
};

class Probe final {
public:
    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_code(
        Function&& function,
        const std::string_view code,
        const std::string_view detail) {
        bool observed = false;
        try {
            std::forward<Function>(function)();
        } catch (const AppError& error) {
            observed = error.code() == code;
        }
        check(observed, detail);
    }

    template <typename Function>
    void run_case(std::string name, Function&& function) {
        const auto before = assertions_;
        if (std::getenv("NATRAV_TEST_TRACE") != nullptr) {
            std::cerr << "BEGIN " << name << '\n';
        }
        std::forward<Function>(function)();
        if (std::getenv("NATRAV_TEST_TRACE") != nullptr) {
            std::cerr << "PASS " << name << '\n';
        }
        cases_.push_back(CaseRecord{
            .name = std::move(name),
            .assertions = assertions_ - before,
        });
    }

    [[nodiscard]] std::size_t assertions() const noexcept { return assertions_; }
    [[nodiscard]] const std::vector<CaseRecord>& cases() const noexcept {
        return cases_;
    }

private:
    std::size_t assertions_{0U};
    std::vector<CaseRecord> cases_{};
};

class TempRoot final {
public:
    TempRoot() {
        std::array<char, 48U> pattern{};
        const std::string prefix = "/tmp/natrav-external-adapter-XXXXXX";
        std::copy(prefix.begin(), prefix.end(), pattern.begin());
        char* created = ::mkdtemp(pattern.data());
        if (created == nullptr) {
            throw std::runtime_error("could not create adapter probe root");
        }
        path_ = created;
        if (::chmod(path_.c_str(), S_IRWXU) != 0) {
            throw std::runtime_error("could not secure adapter probe root");
        }
    }

    ~TempRoot() {
        if (std::getenv("NATRAV_KEEP_TEST_ROOT") == nullptr) {
            std::filesystem::remove_all(path_);
        } else {
            std::cerr << "PRESERVED " << path_ << '\n';
        }
    }
    TempRoot(const TempRoot&) = delete;
    TempRoot& operator=(const TempRoot&) = delete;

    [[nodiscard]] const std::filesystem::path& path() const noexcept {
        return path_;
    }

private:
    std::filesystem::path path_;
};

[[nodiscard]] Deadline test_deadline(
    const std::chrono::milliseconds duration = std::chrono::seconds(20)) {
    return std::chrono::steady_clock::now() + duration;
}

[[nodiscard]] TlsIdentityFiles identity(
    const char* certificate,
    const char* private_key,
    const char* pin) {
    return TlsIdentityFiles{
        .certificate = certificate,
        .private_key = private_key,
        .expected_spki_sha256 = natrav_overlay::parse_spki_sha256(pin),
    };
}

[[nodiscard]] datacube::Digest32 operation_id(const std::string_view label) {
    std::string input("NATRAV_EXTERNAL_PACKET_ADAPTER_TEST_OPERATION_V1");
    input.push_back('\0');
    input.append(label);
    return datacube::sha256(datacube::text_octets(input));
}

[[nodiscard]] EvidenceRecord record(
    const std::string_view label,
    const std::string_view payload) {
    return EvidenceRecord{
        .operation_id = operation_id(label),
        .issuer = "CLIENT",
        .recipient = "SERVER",
        .scope = "external-adapter/session",
        .corrects = std::nullopt,
        .payload = datacube::text_octets(payload),
    };
}

[[nodiscard]] std::string read_text(const std::filesystem::path& path) {
    std::ifstream input(path);
    if (!input) {
        throw std::runtime_error("could not read fixture evidence");
    }
    return std::string(
        std::istreambuf_iterator<char>(input),
        std::istreambuf_iterator<char>());
}

[[nodiscard]] ExternalPacketAdapterOptions adapter_options(
    const std::filesystem::path& executable,
    const std::filesystem::path& local,
    const std::filesystem::path& remote,
    const std::filesystem::path& evidence,
    const std::string_view schedule = {}) {
    ExternalPacketAdapterOptions options;
    options.executable = executable;
    options.arguments = {
        "--local", local.string(),
        "--remote", remote.string(),
        "--mtu", "512",
        "--schedule", std::string(schedule),
        "--evidence", evidence.string(),
    };
    options.requested_mtu = 512U;
    options.max_frame_bytes = 65'536U;
    options.max_queued_bytes = 1'048'576U;
    options.max_outstanding_requests = 1U;
    options.max_evidence_events = 256U;
    options.max_launch_attempts = 2U;
    options.startup_timeout = std::chrono::seconds(2);
    options.request_timeout = std::chrono::seconds(1);
    options.shutdown_timeout = std::chrono::seconds(1);
    options.initial_restart_backoff = std::chrono::milliseconds(20);
    options.maximum_restart_backoff = std::chrono::milliseconds(80);
    return options;
}

[[nodiscard]] PacketPortOrderedStreamOptions stream_options() {
    PacketPortOrderedStreamOptions options;
    options.limits.mtu = 512U;
    options.limits.max_message_bytes = 64U * 1024U;
    options.limits.max_reassembly_bytes = 256U * 1024U;
    options.limits.max_delivery_bytes = 256U * 1024U;
    options.limits.max_inflight_frames = 256U;
    options.limits.max_control_frames = 256U;
    options.limits.max_receive_packets_per_pump = 512U;
    // A supervised process boundary has higher scheduling latency than an
    // in-process packet fixture. Keep the profile finite while allowing a
    // 2.56-second retransmission window (4 ticks * 5 ms * 128 attempts).
    options.limits.retransmit_after_ticks = 4U;
    options.limits.retry_limit = 128U;
    options.limits.message_expiry_ticks = 8'192U;
    options.stream_id = 0x4558544144505431ULL;
    options.epoch = 19U;
    options.tick_interval = std::chrono::milliseconds(5);
    options.shutdown_budget = std::chrono::seconds(10);
    options.invalid_stream_code = "ADAPTER_STREAM_INVALID";
    options.logical_clock_invalid_code = "ADAPTER_CLOCK_INVALID";
    options.logical_clock_exhausted_code = "ADAPTER_CLOCK_EXHAUSTED";
    options.shutdown_operation = "external adapter packet-stream shutdown";
    return options;
}

struct StreamPair final {
    std::unique_ptr<natrav_overlay::OrderedByteStream> first;
    std::unique_ptr<natrav_overlay::OrderedByteStream> second;
    std::shared_ptr<SupervisedExternalPacketAdapterControl> first_control;
    std::shared_ptr<SupervisedExternalPacketAdapterControl> second_control;
    std::filesystem::path first_evidence;
    std::filesystem::path second_evidence;
};

[[nodiscard]] StreamPair make_stream_pair(
    const std::filesystem::path& executable,
    const std::filesystem::path& root,
    const std::string_view first_schedule = {},
    const std::string_view second_schedule = {}) {
    std::filesystem::create_directory(root);
    std::filesystem::permissions(
        root,
        std::filesystem::perms::owner_all,
        std::filesystem::perm_options::replace);
    const auto first_medium = root / "first-medium.sock";
    const auto second_medium = root / "second-medium.sock";
    const auto first_evidence = root / "first-evidence.json";
    const auto second_evidence = root / "second-evidence.json";
    auto first_adapter = natrav_overlay::make_supervised_external_packet_adapter(
        adapter_options(
            executable,
            first_medium,
            second_medium,
            first_evidence,
            first_schedule));
    auto second_adapter = natrav_overlay::make_supervised_external_packet_adapter(
        adapter_options(
            executable,
            second_medium,
            first_medium,
            second_evidence,
            second_schedule));
    auto first_control = first_adapter.control;
    auto second_control = second_adapter.control;
    auto first = natrav_overlay::make_packet_port_ordered_byte_stream(
        std::move(first_adapter.port), stream_options());
    auto second = natrav_overlay::make_packet_port_ordered_byte_stream(
        std::move(second_adapter.port), stream_options());
    return StreamPair{
        .first = std::move(first),
        .second = std::move(second),
        .first_control = std::move(first_control),
        .second_control = std::move(second_control),
        .first_evidence = first_evidence,
        .second_evidence = second_evidence,
    };
}

void write_all(
    natrav_overlay::OrderedByteStream& stream,
    const std::span<const std::uint8_t> bytes,
    const Deadline deadline,
    IoCounters& counters) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto progress = stream.write_some(
            datacube::OctetView(bytes.data() + offset, bytes.size() - offset),
            deadline,
            counters,
            "external adapter ordered write");
        if (progress == 0U || progress > bytes.size() - offset) {
            throw std::runtime_error("external adapter write made invalid progress");
        }
        offset += progress;
    }
}

[[nodiscard]] std::vector<std::uint8_t> read_exact(
    natrav_overlay::OrderedByteStream& stream,
    const std::size_t size,
    const Deadline deadline,
    IoCounters& counters) {
    std::vector<std::uint8_t> result(size);
    std::size_t offset = 0U;
    while (offset < result.size()) {
        const auto progress = stream.read_some(
            std::span<std::uint8_t>(result).subspan(offset),
            deadline,
            counters,
            "external adapter ordered read");
        if (progress == 0U || progress > result.size() - offset) {
            throw std::runtime_error("external adapter read ended early");
        }
        offset += progress;
    }
    return result;
}

struct SessionRun final {
    std::array<DeliveryReceipt, 2U> receipts;
    std::size_t server_operations{0U};
    bool clean_close{false};
};

[[nodiscard]] SessionRun run_reusable_session(
    StreamPair pair,
    const TlsIdentityFiles& client_identity,
    const TlsIdentityFiles& server_identity) {
    auto server_stream = std::move(pair.second);
    TlsContext client_context(client_identity);
    TlsContext server_context(server_identity);
    const std::vector<TlsTrustedIdentity> trusted_client{{
        .node_id = "CLIENT",
        .generations = {TlsTrustedGeneration{
            .generation = "client-g1",
            .spki_sha256 = client_identity.expected_spki_sha256,
            .state = KeyGenerationState::active,
        }},
    }};
    const IoOptions io{
        .timeout = std::chrono::seconds(20),
        .read_quantum = 257U,
        .write_quantum = 251U,
        .maximum_received_bytes = 1'048'576U,
    };
    const PeerSessionLimits limits{
        .maximum_operations = 4U,
        .maximum_bytes = 1'048'576U,
        .maximum_lifetime_ms = 30'000U,
        .idle_timeout_ms = 20'000U,
    };
    const std::array<EvidenceRecord, 2U> records{
        record("session-one", "alpha through the supervised external adapter"),
        record("session-two", std::string(4'000U, 'b')),
    };

    IoCounters server_tls;
    IoCounters server_io;
    std::size_t server_operations = 0U;
    bool server_clean_close = false;
    std::exception_ptr server_failure;
    std::thread server([&] {
        try {
            const auto deadline = test_deadline();
            auto channel = TlsChannel::accept(
                server_context, *server_stream, trusted_client,
                deadline, server_tls);
            FramedReader reader(io);
            const auto hello = natrav_overlay::perform_server_handshake(
                channel, "SERVER", reader, deadline, io);
            if (hello.remote_artifact_digest !=
                natrav_overlay::node_artifact_digest("CLIENT")) {
                throw std::runtime_error("server HELLO identity mismatch");
            }
            const auto open = natrav_overlay::decode_peer_session_frame(
                reader.read_frame(channel, deadline, server_io));
            if (open.kind != PeerSessionFrameKind::open ||
                !open.limits.has_value()) {
                throw std::runtime_error("server did not receive NOS1 OPEN");
            }
            const PeerSessionFrame acknowledgement{
                .kind = PeerSessionFrameKind::open_ack,
                .flags = 0U,
                .session_id = open.session_id,
                .sequence = 0U,
                .operation_id = {},
                .limits = *open.limits,
                .payload = {},
            };
            natrav_overlay::write_frame(
                channel,
                natrav_overlay::encode_peer_session_frame(acknowledgement),
                deadline,
                io,
                server_io);

            for (std::uint32_t sequence = 1U; sequence <= 2U; ++sequence) {
                const auto request = natrav_overlay::decode_peer_session_frame(
                    reader.read_frame(channel, deadline, server_io));
                if (request.kind != PeerSessionFrameKind::request ||
                    request.session_id != open.session_id ||
                    request.sequence != sequence) {
                    throw std::runtime_error("server request envelope mismatch");
                }
                const auto message = natrav_overlay::decode_application_message(
                    request.payload);
                const auto* evidence = std::get_if<EvidenceRecord>(&message);
                if (evidence == nullptr ||
                    evidence->operation_id != request.operation_id) {
                    throw std::runtime_error("server application binding mismatch");
                }
                ++server_operations;
                const DeliveryReceipt receipt{
                    .operation_id = evidence->operation_id,
                    .recipient = evidence->recipient,
                    .recorder = evidence->recipient,
                    .disposition = ReceiptDisposition::committed,
                    .sequence = sequence,
                    .record_digest = natrav_overlay::evidence_record_digest(*evidence),
                };
                const PeerSessionFrame response{
                    .kind = PeerSessionFrameKind::response,
                    .flags = 0U,
                    .session_id = open.session_id,
                    .sequence = sequence,
                    .operation_id = evidence->operation_id,
                    .limits = std::nullopt,
                    .payload = natrav_overlay::encode_application_message(receipt),
                };
                natrav_overlay::write_frame(
                    channel,
                    natrav_overlay::encode_peer_session_frame(response),
                    deadline,
                    io,
                    server_io);
            }

            const auto close = natrav_overlay::decode_peer_session_frame(
                reader.read_frame(channel, deadline, server_io));
            if (close.kind != PeerSessionFrameKind::close ||
                close.session_id != open.session_id || close.sequence != 3U) {
                throw std::runtime_error("server close envelope mismatch");
            }
            const PeerSessionFrame close_ack{
                .kind = PeerSessionFrameKind::close_ack,
                .flags = 0U,
                .session_id = open.session_id,
                .sequence = close.sequence,
                .operation_id = {},
                .limits = std::nullopt,
                .payload = {},
            };
            natrav_overlay::write_frame(
                channel,
                natrav_overlay::encode_peer_session_frame(close_ack),
                deadline,
                io,
                server_io);
            std::array<std::uint8_t, 1U> tls_eof{};
            if (channel.read_some(
                    tls_eof,
                    deadline,
                    server_tls,
                    "server waits for TLS close-notify") != 0U) {
                throw std::runtime_error("application bytes followed NOS1 close");
            }
            channel.close_notify(deadline, server_tls);
            server_clean_close = true;
        } catch (...) {
            server_failure = std::current_exception();
        }
    });

    std::array<DeliveryReceipt, 2U> receipts;
    bool client_clean_close = false;
    std::exception_ptr client_failure;
    try {
        auto session = OutboundPeerSession::open_connected(
            client_context,
            "CLIENT",
            "SERVER",
            "server-g1",
            KeyGenerationState::active,
            server_identity.expected_spki_sha256,
            std::move(pair.first),
            records[0U].operation_id,
            io,
            limits);
        receipts[0U] = session.exchange(records[0U], io);
        receipts[1U] = session.exchange(records[1U], io);
        client_clean_close = session.close_cleanly(io);
    } catch (...) {
        client_failure = std::current_exception();
    }
    server.join();
    server_stream.reset();
    if (client_failure) {
        std::rethrow_exception(client_failure);
    }
    if (server_failure) {
        std::rethrow_exception(server_failure);
    }
    if (!client_clean_close || !server_clean_close) {
        throw std::runtime_error("authenticated adapter session did not close cleanly");
    }
    return SessionRun{
        .receipts = receipts,
        .server_operations = server_operations,
        .clean_close = client_clean_close && server_clean_close,
    };
}

}  // namespace

int main(int argc, char* argv[]) {
    Probe probe;
    try {
        if (argc != 9) {
            throw std::runtime_error(
                "usage: probe FIXTURE CLIENT_CERT CLIENT_KEY CLIENT_PIN SERVER_CERT SERVER_KEY SERVER_PIN OUTPUT");
        }
        const std::filesystem::path fixture = argv[1];
        const auto client_identity = identity(argv[2], argv[3], argv[4]);
        const auto server_identity = identity(argv[5], argv[6], argv[7]);
        const std::filesystem::path output = argv[8];
        std::filesystem::create_directories(output);
        TempRoot temp;

        probe.run_case("marker and private carrier contract", [&] {
            probe.check(
                std::string_view(
                    natrav_overlay::kSupervisedExternalPacketAdapterMarker) ==
                    "SUPERVISED_EXTERNAL_PACKET_ADAPTER_V1",
                "external adapter marker is exact");
            probe.check(
                natrav_overlay::supervised_external_packet_adapter_revision_abi() == 1,
                "external adapter ABI anchor is one");
            ExternalPacketAdapterOptions invalid;
            invalid.executable = "relative-adapter";
            probe.expect_code(
                [&] {
                    auto adapter =
                        natrav_overlay::make_supervised_external_packet_adapter(
                            std::move(invalid));
                    static_cast<void>(adapter);
                },
                "ADAPTER_EXECUTABLE_INVALID",
                "relative adapter executables are rejected");
        });

        probe.run_case("bounded startup retry and inherited authority isolation", [&] {
            const auto root = temp.path() / "startup-retry";
            std::filesystem::create_directory(root);
            const auto local = root / "local.sock";
            const auto remote = root / "remote.sock";
            const auto evidence = root / "evidence.json";
            const auto crash_state = root / "crash-state";
            auto options = adapter_options(fixture, local, remote, evidence);
            options.arguments.push_back("--startup-crash-state");
            options.arguments.push_back(crash_state.string());
            auto adapter =
                natrav_overlay::make_supervised_external_packet_adapter(
                    std::move(options));
            const auto running = adapter.control->snapshot();
            probe.check(running.running, "adapter is ready after bounded restart");
            probe.check(running.launch_attempts == 2U && running.restarts == 1U,
                        "one startup crash consumes one bounded restart");
            probe.check(running.capabilities.profile == 1U &&
                            running.capabilities.mtu == 512U &&
                            running.capabilities.max_outstanding_requests == 1U,
                        "capability negotiation is finite and exact");
            adapter.port.reset();
            const auto final_snapshot = adapter.control->snapshot();
            probe.check(!final_snapshot.running,
                        "adapter destruction ends supervised process ownership");
            const auto text = read_text(evidence);
            probe.check(
                text.find("\"inherited_fds\": [0, 1, 2, 3]") != std::string::npos,
                "child inherits only redirected standard descriptors and descriptor 3");
            probe.check(
                text.find("NATRAV_ADAPTER_FD") != std::string::npos &&
                    text.find("NATRAV_ADAPTER_PROTOCOL") != std::string::npos &&
                    text.find("PRIVATE_KEY") == std::string::npos,
                "minimal environment carries protocol coordinates but no authority material");
            probe.check(text.find("\"shutdown\": true") != std::string::npos,
                        "graceful shutdown is explicitly acknowledged");
        });

        probe.run_case("fragmented ordered stream over two external processes", [&] {
            auto pair = make_stream_pair(fixture, temp.path() / "raw-pair");
            std::vector<std::uint8_t> forward(8'193U);
            for (std::size_t index = 0U; index < forward.size(); ++index) {
                forward[index] = static_cast<std::uint8_t>((index * 37U) & 0xffU);
            }
            const std::vector<std::uint8_t> reverse{
                'r', 'e', 'v', 'e', 'r', 's', 'e', '-', 'a', 'd', 'a', 'p', 't', 'e', 'r'};
            IoCounters first_counters;
            IoCounters second_counters;
            const auto deadline = test_deadline(std::chrono::seconds(20));
            std::vector<std::uint8_t> received_forward;
            std::atomic<bool> reverse_received{false};
            std::exception_ptr second_failure;
            std::thread second([&] {
                try {
                    received_forward = read_exact(
                        *pair.second, forward.size(), deadline, second_counters);
                    write_all(*pair.second, reverse, deadline, second_counters);

                    // write_some() accepts bytes into the finite packet stream; it
                    // does not promise that a process-backed packet port accepted
                    // every due datagram during the same call. Keep this endpoint
                    // pumping under short absolute deadlines until the peer
                    // confirms that the reverse bytes arrived.
                    std::array<std::uint8_t, 1U> unexpected{};
                    while (!reverse_received.load(std::memory_order_acquire)) {
                        const auto slice_deadline = std::min(
                            deadline,
                            std::chrono::steady_clock::now() +
                                std::chrono::milliseconds(25));
                        try {
                            const auto progress = pair.second->read_some(
                                unexpected,
                                slice_deadline,
                                second_counters,
                                "external adapter reverse-delivery pump");
                            if (progress != 0U) {
                                throw std::runtime_error(
                                    "unexpected application bytes while pumping reverse delivery");
                            }
                            throw std::runtime_error(
                                "unexpected ordered EOF while pumping reverse delivery");
                        } catch (const AppError& error) {
                            if (error.code() != "IO_TIMEOUT") {
                                throw;
                            }
                        }
                    }
                } catch (...) {
                    second_failure = std::current_exception();
                }
            });
            std::vector<std::uint8_t> received_reverse;
            std::exception_ptr first_failure;
            try {
                write_all(*pair.first, forward, deadline, first_counters);
                received_reverse = read_exact(
                    *pair.first, reverse.size(), deadline, first_counters);
                reverse_received.store(true, std::memory_order_release);
            } catch (...) {
                first_failure = std::current_exception();
                reverse_received.store(true, std::memory_order_release);
                pair.first.reset();
            }
            second.join();
            if (first_failure) {
                std::rethrow_exception(first_failure);
            }
            if (second_failure) {
                std::rethrow_exception(second_failure);
            }
            probe.check(received_forward == forward,
                        "fragmented forward application bytes are exact");
            probe.check(received_reverse == reverse,
                        "full-duplex reverse application bytes are exact");
            pair.first->shutdown_write();
            std::array<std::uint8_t, 1U> eof{};
            probe.check(pair.second->read_some(
                            eof,
                            deadline,
                            second_counters,
                            "adapter semantic EOF") == 0U,
                        "finite packet finish crosses the process boundary as ordered EOF");
            pair.first.reset();
            pair.second.reset();
            const auto first_snapshot = pair.first_control->snapshot();
            const auto second_snapshot = pair.second_control->snapshot();
            probe.check(first_snapshot.transmitted_packets != 0U &&
                            second_snapshot.received_packets != 0U &&
                            !first_snapshot.running && !second_snapshot.running,
                        "both supervisors account for traffic and release their children");
        });

        probe.run_case("adversarial authenticated stack and clean restart", [&] {
            auto first_pair = make_stream_pair(
                fixture,
                temp.path() / "tls-pair-one",
                "1=busy,2=drop,3=duplicate,4=corrupt,5=delay:2,6=reorder",
                "1=duplicate,2=delay:1");
            const auto first_evidence = first_pair.first_evidence;
            const auto first_run = run_reusable_session(
                std::move(first_pair), client_identity, server_identity);
            probe.check(first_run.clean_close && first_run.server_operations == 2U,
                        "real TLS, HELLO, NOS1, two operations, receipts, and close survive scheduled faults");
            probe.check(
                first_run.receipts[0U].operation_id == operation_id("session-one") &&
                    first_run.receipts[1U].operation_id == operation_id("session-two") &&
                    first_run.receipts[0U].disposition == ReceiptDisposition::committed &&
                    first_run.receipts[1U].disposition == ReceiptDisposition::committed,
                "authenticated receipts remain bound to both exact operations");
            const auto fault_evidence = read_text(first_evidence);
            probe.check(
                fault_evidence.find("\"action\": \"busy\"") != std::string::npos &&
                    fault_evidence.find("\"action\": \"drop\"") != std::string::npos &&
                    fault_evidence.find("\"action\": \"duplicate\"") != std::string::npos &&
                    fault_evidence.find("\"action\": \"corrupt\"") != std::string::npos &&
                    fault_evidence.find("\"action\": \"delay\"") != std::string::npos &&
                    fault_evidence.find("\"action\": \"reorder\"") != std::string::npos,
                "fixture evidence records all six deterministic adversities");

            auto second_pair = make_stream_pair(
                fixture, temp.path() / "tls-pair-two");
            const auto second_run = run_reusable_session(
                std::move(second_pair), client_identity, server_identity);
            probe.check(second_run.clean_close && second_run.server_operations == 2U,
                        "fresh supervised processes carry a second authenticated session after stop and restart");
        });

        probe.run_case("runtime death, exhaustion, and malformed output", [&] {
            const auto root = temp.path() / "runtime-faults";
            std::filesystem::create_directory(root);
            const natrav::packet_link::Bytes packet(64U, 0x5aU);

            auto crash = natrav_overlay::make_supervised_external_packet_adapter(
                adapter_options(
                    fixture,
                    root / "crash-local.sock",
                    root / "crash-remote.sock",
                    root / "crash.json",
                    "1=crash"));
            probe.expect_code(
                [&] { static_cast<void>(crash.port->send_packet(packet)); },
                "PEER_RESET",
                "runtime adapter death becomes a carrier reset rather than success");
            probe.check(crash.control->snapshot().child_exits == 1U,
                        "runtime child death is retained as bounded evidence");

            auto exhausted = natrav_overlay::make_supervised_external_packet_adapter(
                adapter_options(
                    fixture,
                    root / "exhaust-local.sock",
                    root / "exhaust-remote.sock",
                    root / "exhaust.json",
                    "1=exhaust"));
            probe.expect_code(
                [&] { static_cast<void>(exhausted.port->send_packet(packet)); },
                "ADAPTER_RESOURCE_EXHAUSTED",
                "adapter resource exhaustion is explicit and not guessed as delivery");

            auto malformed = natrav_overlay::make_supervised_external_packet_adapter(
                adapter_options(
                    fixture,
                    root / "malformed-local.sock",
                    root / "malformed-remote.sock",
                    root / "malformed.json",
                    "1=malformed"));
            probe.expect_code(
                [&] { static_cast<void>(malformed.port->send_packet(packet)); },
                "ADAPTER_PROTOCOL_INVALID",
                "malformed child output is rejected at the protocol boundary");
            probe.check(malformed.control->snapshot().protocol_failures == 1U,
                        "protocol violations are retained in bounded evidence");

            auto bad_hello_options = adapter_options(
                fixture,
                root / "hello-local.sock",
                root / "hello-remote.sock",
                root / "hello.json");
            bad_hello_options.arguments.push_back("--malformed-hello");
            bad_hello_options.max_launch_attempts = 1U;
            probe.expect_code(
                [&] {
                    auto bad = natrav_overlay::make_supervised_external_packet_adapter(
                        std::move(bad_hello_options));
                    static_cast<void>(bad);
                },
                "ADAPTER_START_FAILED",
                "malformed readiness output exhausts the bounded startup budget");
        });

        probe.run_case("finite evidence growth", [&] {
            const auto root = temp.path() / "evidence-bound";
            std::filesystem::create_directory(root);
            auto options = adapter_options(
                fixture,
                root / "local.sock",
                root / "remote.sock",
                root / "evidence.json");
            options.max_evidence_events = 16U;
            auto adapter = natrav_overlay::make_supervised_external_packet_adapter(
                std::move(options));
            const natrav::packet_link::Bytes packet(64U, 0x33U);
            for (std::size_t index = 0U; index < 20U; ++index) {
                static_cast<void>(adapter.port->send_packet(packet));
            }
            const auto snapshot = adapter.control->snapshot();
            probe.check(
                snapshot.transmitted_packets + snapshot.busy_responses == 20U,
                "every bounded transmit request has an explicit accepted-or-busy outcome");
            probe.check(snapshot.events.size() == 16U,
                        "evidence vector never exceeds its declared bound");
            probe.check(snapshot.dropped_evidence_events != 0U,
                        "overflow is counted instead of growing without limit");
        });

        const auto fixture_output = output / "fixture-evidence";
        for (const auto& entry : std::filesystem::recursive_directory_iterator(
                 temp.path(),
                 std::filesystem::directory_options::skip_permission_denied)) {
            if (!entry.is_regular_file() || entry.path().extension() != ".json") {
                continue;
            }
            const auto relative = std::filesystem::relative(entry.path(), temp.path());
            const auto destination = fixture_output / relative;
            std::filesystem::create_directories(destination.parent_path());
            std::filesystem::copy_file(
                entry.path(),
                destination,
                std::filesystem::copy_options::overwrite_existing);
        }

        std::ofstream summary(output / "probe-summary.json");
        summary << "{\"format\":\"NATRAV_EXTERNAL_PACKET_ADAPTER_PROBE_V1\","
                << "\"status\":\"PASS\",\"cases\":" << probe.cases().size()
                << ",\"assertions\":" << probe.assertions() << "}\n";
        summary.close();

        std::cout << "{\"format\":\"NATRAV_EXTERNAL_PACKET_ADAPTER_PROBE_V1\","
                  << "\"status\":\"PASS\",\"cases\":" << probe.cases().size()
                  << ",\"assertions\":" << probe.assertions()
                  << ",\"case_records\":[";
        for (std::size_t index = 0U; index < probe.cases().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            std::cout << "{\"name\":"
                      << natrav_overlay::json_string(probe.cases()[index].name)
                      << ",\"assertions\":" << probe.cases()[index].assertions
                      << '}';
        }
        std::cout << "]}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "external packet adapter probe failed: " << error.what() << '\n';
        return 1;
    }
}
