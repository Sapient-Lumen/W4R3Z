#!/usr/bin/env python3
"""Prepare isolated runtime-failure propagation probe; no injection in release code."""
import argparse,json,shutil
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];out=a.output.resolve()
if out.exists() or out==root or root in out.parents:p.error('new output outside product required')
tree=out/'source';tree.mkdir(parents=True)
for part in ('node/src','foundation/src','foundation/include'):shutil.copytree(root/part,tree/part)
shutil.copy2(root/'node/build.sh',tree/'node/build.sh')
p=tree/'node/src/daemon.cpp';s=p.read_text()
anchor='''    const auto terminal_delivery = terminal_handoff ?'''
assert s.count(anchor)==1
s=s.replace(anchor,'''    // Private test: model a runtime worker's fatal account at the joined boundary.
    if (terminal_handoff) scheduler_signal.record_failure();
'''+anchor);p.write_text(s)
print(json.dumps({'status':'PREPARED_NOT_BUILT','source':str(tree)}))
