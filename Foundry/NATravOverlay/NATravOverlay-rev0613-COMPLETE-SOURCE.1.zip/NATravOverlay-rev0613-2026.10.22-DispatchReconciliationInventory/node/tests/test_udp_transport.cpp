#include "peer_session.hpp"
#include "protocol.hpp"
#include "socket.hpp"
#include "tls.hpp"
#include "transport.hpp"
#include "udp_transport.hpp"

#include <algorithm>
#include <array>
#include <arpa/inet.h>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <iostream>
#include <memory>
#include <netinet/in.h>
#include <optional>
#include <poll.h>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/socket.h>
#include <thread>
#include <unistd.h>
#include <utility>
#include <variant>
#include <vector>

namespace {

using natrav_overlay::AppError;
using natrav_overlay::Deadline;
using natrav_overlay::DeliveryReceipt;
using natrav_overlay::EvidenceRecord;
using natrav_overlay::FramedReader;
using natrav_overlay::IoCounters;
using natrav_overlay::IoOptions;
using natrav_overlay::KeyGenerationState;
using natrav_overlay::OutboundPeerSession;
using natrav_overlay::PeerSessionFrame;
using natrav_overlay::PeerSessionFrameKind;
using natrav_overlay::PeerSessionLimits;
using natrav_overlay::ReceiptDisposition;
using natrav_overlay::TlsChannel;
using natrav_overlay::TlsContext;
using natrav_overlay::TlsIdentityFiles;
using natrav_overlay::TlsTrustedGeneration;
using natrav_overlay::TlsTrustedIdentity;
using natrav_overlay::TransportKind;
using natrav_overlay::TransportLocator;

struct CaseRecord final {
    std::string name;
    std::size_t assertions{0U};
};

class Probe final {
public:
    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_code(
        Function&& function,
        const std::string_view code,
        const std::string_view detail) {
        bool observed = false;
        try {
            std::forward<Function>(function)();
        } catch (const AppError& error) {
            observed = error.code() == code;
        }
        check(observed, detail);
    }

    template <typename Function>
    void run_case(std::string name, Function&& function) {
        const auto before = assertions_;
        std::forward<Function>(function)();
        cases_.push_back(CaseRecord{
            .name = std::move(name),
            .assertions = assertions_ - before,
        });
    }

    [[nodiscard]] std::size_t assertions() const noexcept { return assertions_; }
    [[nodiscard]] const std::vector<CaseRecord>& cases() const noexcept {
        return cases_;
    }

private:
    std::size_t assertions_{0U};
    std::vector<CaseRecord> cases_;
};

[[nodiscard]] Deadline test_deadline(
    const std::chrono::milliseconds duration = std::chrono::seconds(8)) {
    return std::chrono::steady_clock::now() + duration;
}

[[nodiscard]] TlsIdentityFiles identity(
    const char* certificate,
    const char* private_key,
    const char* pin) {
    return TlsIdentityFiles{
        .certificate = certificate,
        .private_key = private_key,
        .expected_spki_sha256 = natrav_overlay::parse_spki_sha256(pin),
    };
}

[[nodiscard]] datacube::Digest32 operation_id(const std::string_view label) {
    std::string input("NATRAV_UDP_PACKET_CARRIER_TEST_OPERATION_V1");
    input.push_back('\0');
    input.append(label);
    return datacube::sha256(datacube::text_octets(input));
}

[[nodiscard]] EvidenceRecord record(
    const std::string_view label,
    const std::string_view payload) {
    return EvidenceRecord{
        .operation_id = operation_id(label),
        .issuer = "CLIENT",
        .recipient = "SERVER",
        .scope = "udp/session",
        .corrects = std::nullopt,
        .payload = datacube::text_octets(payload),
    };
}

[[nodiscard]] std::uint16_t free_udp_port() {
    const int raw = ::socket(AF_INET, SOCK_DGRAM | SOCK_CLOEXEC, IPPROTO_UDP);
    if (raw < 0) {
        throw std::runtime_error("could not create UDP port probe");
    }
    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_port = 0;
    if (::inet_pton(AF_INET, "127.0.0.1", &address.sin_addr) != 1 ||
        ::bind(raw, reinterpret_cast<const sockaddr*>(&address), sizeof(address)) != 0) {
        ::close(raw);
        throw std::runtime_error("could not bind UDP port probe");
    }
    socklen_t length = static_cast<socklen_t>(sizeof(address));
    if (::getsockname(raw, reinterpret_cast<sockaddr*>(&address), &length) != 0) {
        ::close(raw);
        throw std::runtime_error("could not inspect UDP port probe");
    }
    const auto port = ntohs(address.sin_port);
    ::close(raw);
    if (port == 0U) {
        throw std::runtime_error("kernel returned zero UDP port");
    }
    return port;
}

[[nodiscard]] std::pair<std::uint16_t, std::uint16_t> port_pair() {
    const auto first = free_udp_port();
    std::uint16_t second = first;
    while (second == first) {
        second = free_udp_port();
    }
    return {first, second};
}

[[nodiscard]] std::string locator_text(
    const std::uint16_t local,
    const std::uint16_t remote,
    const std::uint16_t mtu = 512U,
    const std::string_view link = "5544505445535431",
    const std::uint32_t epoch = 7U) {
    return "udp-v1|local=127.0.0.1:" + std::to_string(local) +
        "|remote=127.0.0.1:" + std::to_string(remote) +
        "|mtu=" + std::to_string(mtu) +
        "|link=" + std::string(link) +
        "|epoch=" + std::to_string(epoch) +
        "|profile=1";
}

void write_all(
    natrav_overlay::OrderedByteStream& stream,
    const std::span<const std::uint8_t> bytes,
    const Deadline deadline,
    IoCounters& counters) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto progress = stream.write_some(
            datacube::OctetView(bytes.data() + offset, bytes.size() - offset),
            deadline,
            counters,
            "UDP ordered write");
        if (progress == 0U || progress > bytes.size() - offset) {
            throw std::runtime_error("UDP ordered write made invalid progress");
        }
        offset += progress;
    }
}

[[nodiscard]] std::vector<std::uint8_t> read_exact(
    natrav_overlay::OrderedByteStream& stream,
    const std::size_t size,
    const Deadline deadline,
    IoCounters& counters) {
    std::vector<std::uint8_t> result(size);
    std::size_t offset = 0U;
    while (offset < result.size()) {
        const auto progress = stream.read_some(
            std::span<std::uint8_t>(result).subspan(offset),
            deadline,
            counters,
            "UDP ordered read");
        if (progress == 0U || progress > result.size() - offset) {
            throw std::runtime_error("UDP ordered read ended early");
        }
        offset += progress;
    }
    return result;
}

[[nodiscard]] std::unique_ptr<natrav_overlay::OrderedByteStream> accept_with_deadline(
    natrav_overlay::TransportListener& listener,
    const Deadline deadline) {
    while (std::chrono::steady_clock::now() < deadline) {
        const int handle = listener.readiness_handle();
        if (handle < 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(5));
            continue;
        }
        pollfd item{.fd = handle, .events = POLLIN, .revents = 0};
        const int result = ::poll(&item, 1U, 20);
        if (result < 0 && errno == EINTR) {
            continue;
        }
        if (result < 0) {
            throw std::runtime_error("UDP listener poll failed");
        }
        if (result != 0 && (item.revents & POLLIN) != 0) {
            auto stream = listener.accept_ready();
            if (stream) {
                return stream;
            }
        }
    }
    throw std::runtime_error("UDP listener did not become ready");
}

void send_raw_datagram(
    const std::uint16_t source_port,
    const std::uint16_t target_port,
    const std::size_t bytes) {
    const int raw = ::socket(AF_INET, SOCK_DGRAM | SOCK_CLOEXEC, IPPROTO_UDP);
    if (raw < 0) {
        throw std::runtime_error("raw UDP socket creation failed");
    }
    sockaddr_in source{};
    source.sin_family = AF_INET;
    source.sin_port = htons(source_port);
    sockaddr_in target{};
    target.sin_family = AF_INET;
    target.sin_port = htons(target_port);
    if (::inet_pton(AF_INET, "127.0.0.1", &source.sin_addr) != 1 ||
        ::inet_pton(AF_INET, "127.0.0.1", &target.sin_addr) != 1 ||
        ::bind(raw, reinterpret_cast<const sockaddr*>(&source), sizeof(source)) != 0) {
        ::close(raw);
        throw std::runtime_error("raw UDP source bind failed");
    }
    std::vector<std::uint8_t> payload(bytes, 0x5aU);
    const ssize_t sent = ::sendto(
        raw,
        payload.data(),
        payload.size(),
        0,
        reinterpret_cast<const sockaddr*>(&target),
        static_cast<socklen_t>(sizeof(target)));
    ::close(raw);
    if (sent < 0 || static_cast<std::size_t>(sent) != payload.size()) {
        throw std::runtime_error("raw UDP datagram send failed");
    }
}

struct SessionRun final {
    std::array<DeliveryReceipt, 2U> receipts;
    std::size_t server_operations{0U};
    bool clean_close{false};
};

[[nodiscard]] SessionRun run_authenticated_session(
    const TransportLocator& client_locator,
    const TransportLocator& server_locator,
    const TlsIdentityFiles& client_identity,
    const TlsIdentityFiles& server_identity) {
    auto listener = natrav_overlay::listen_transport(server_locator, 4);
    TlsContext client_context(client_identity);
    TlsContext server_context(server_identity);
    const std::vector<TlsTrustedIdentity> trusted_client{{
        .node_id = "CLIENT",
        .generations = {TlsTrustedGeneration{
            .generation = "client-g1",
            .spki_sha256 = client_identity.expected_spki_sha256,
            .state = KeyGenerationState::active,
        }},
    }};
    const IoOptions io{
        .timeout = std::chrono::seconds(8),
        .read_quantum = 257U,
        .write_quantum = 251U,
        .maximum_received_bytes = 1'048'576U,
    };
    const PeerSessionLimits limits{
        .maximum_operations = 4U,
        .maximum_bytes = 1'048'576U,
        .maximum_lifetime_ms = 20'000U,
        .idle_timeout_ms = 8'000U,
    };
    const std::array<EvidenceRecord, 2U> records{
        record("session-one", "alpha over numeric UDP and finite packet reconstruction"),
        record("session-two", std::string(4'000U, 'b')),
    };

    std::size_t server_operations = 0U;
    bool server_clean_close = false;
    std::exception_ptr server_failure;
    std::thread server([&] {
        try {
            auto server_stream = accept_with_deadline(*listener, test_deadline());
            IoCounters server_tls;
            IoCounters server_io;
            const auto deadline = test_deadline();
            auto channel = TlsChannel::accept(
                server_context, *server_stream, trusted_client,
                deadline, server_tls);
            FramedReader reader(io);
            const auto hello = natrav_overlay::perform_server_handshake(
                channel, "SERVER", reader, deadline, io);
            if (hello.remote_artifact_digest !=
                natrav_overlay::node_artifact_digest("CLIENT")) {
                throw std::runtime_error("server HELLO identity mismatch");
            }
            const auto open = natrav_overlay::decode_peer_session_frame(
                reader.read_frame(channel, deadline, server_io));
            if (open.kind != PeerSessionFrameKind::open || !open.limits.has_value()) {
                throw std::runtime_error("server did not receive NOS1 OPEN");
            }
            const PeerSessionFrame acknowledgement{
                .kind = PeerSessionFrameKind::open_ack,
                .flags = 0U,
                .session_id = open.session_id,
                .sequence = 0U,
                .operation_id = {},
                .limits = *open.limits,
                .payload = {},
            };
            natrav_overlay::write_frame(
                channel,
                natrav_overlay::encode_peer_session_frame(acknowledgement),
                deadline,
                io,
                server_io);

            for (std::uint32_t sequence = 1U; sequence <= 2U; ++sequence) {
                const auto request = natrav_overlay::decode_peer_session_frame(
                    reader.read_frame(channel, deadline, server_io));
                if (request.kind != PeerSessionFrameKind::request ||
                    request.session_id != open.session_id ||
                    request.sequence != sequence) {
                    throw std::runtime_error("server request envelope mismatch");
                }
                const auto message = natrav_overlay::decode_application_message(
                    request.payload);
                const auto* evidence = std::get_if<EvidenceRecord>(&message);
                if (evidence == nullptr || evidence->operation_id != request.operation_id) {
                    throw std::runtime_error("server application binding mismatch");
                }
                ++server_operations;
                const DeliveryReceipt receipt{
                    .operation_id = evidence->operation_id,
                    .recipient = evidence->recipient,
                    .recorder = evidence->recipient,
                    .disposition = ReceiptDisposition::committed,
                    .sequence = sequence,
                    .record_digest = natrav_overlay::evidence_record_digest(*evidence),
                };
                const PeerSessionFrame response{
                    .kind = PeerSessionFrameKind::response,
                    .flags = 0U,
                    .session_id = open.session_id,
                    .sequence = sequence,
                    .operation_id = evidence->operation_id,
                    .limits = std::nullopt,
                    .payload = natrav_overlay::encode_application_message(receipt),
                };
                natrav_overlay::write_frame(
                    channel,
                    natrav_overlay::encode_peer_session_frame(response),
                    deadline,
                    io,
                    server_io);
            }

            const auto close = natrav_overlay::decode_peer_session_frame(
                reader.read_frame(channel, deadline, server_io));
            if (close.kind != PeerSessionFrameKind::close ||
                close.session_id != open.session_id || close.sequence != 3U) {
                throw std::runtime_error("server clean-close envelope mismatch");
            }
            const PeerSessionFrame close_ack{
                .kind = PeerSessionFrameKind::close_ack,
                .flags = 0U,
                .session_id = open.session_id,
                .sequence = close.sequence,
                .operation_id = {},
                .limits = std::nullopt,
                .payload = {},
            };
            natrav_overlay::write_frame(
                channel,
                natrav_overlay::encode_peer_session_frame(close_ack),
                deadline,
                io,
                server_io);
            std::array<std::uint8_t, 1U> eof{};
            if (channel.read_some(
                    eof, deadline, server_tls,
                    "server waits for UDP TLS close-notify") != 0U) {
                throw std::runtime_error("application bytes followed NOS1 close");
            }
            channel.close_notify(deadline, server_tls);
            server_clean_close = true;
        } catch (...) {
            server_failure = std::current_exception();
        }
    });

    std::array<DeliveryReceipt, 2U> receipts;
    bool client_clean_close = false;
    std::exception_ptr client_failure;
    try {
        IoCounters connect_counters;
        auto client_stream = natrav_overlay::connect_transport(
            client_locator, test_deadline(), connect_counters);
        auto session = OutboundPeerSession::open_connected(
            client_context,
            "CLIENT",
            "SERVER",
            "server-g1",
            KeyGenerationState::active,
            server_identity.expected_spki_sha256,
            std::move(client_stream),
            records[0U].operation_id,
            io,
            limits);
        receipts[0U] = session.exchange(records[0U], io);
        receipts[1U] = session.exchange(records[1U], io);
        client_clean_close = session.close_cleanly(io);
    } catch (...) {
        client_failure = std::current_exception();
    }
    server.join();
    if (client_failure) {
        std::rethrow_exception(client_failure);
    }
    if (server_failure) {
        std::rethrow_exception(server_failure);
    }
    if (!client_clean_close || !server_clean_close) {
        throw std::runtime_error("authenticated UDP session did not close cleanly");
    }
    return SessionRun{
        .receipts = receipts,
        .server_operations = server_operations,
        .clean_close = true,
    };
}

}  // namespace

int main(int argc, char* argv[]) {
    try {
        if (argc != 7) {
            throw std::runtime_error(
                "usage: test_udp_transport CLIENT_CERT CLIENT_KEY CLIENT_PIN SERVER_CERT SERVER_KEY SERVER_PIN");
        }
        const auto client_identity = identity(argv[1], argv[2], argv[3]);
        const auto server_identity = identity(argv[4], argv[5], argv[6]);
        Probe probe;

        probe.run_case("canonical numeric locator and authority boundary", [&] {
            const auto ports = port_pair();
            const auto text = locator_text(ports.first, ports.second, 1200U);
            const auto locator = natrav_overlay::parse_udp_transport_locator(text);
            probe.check(locator.kind == TransportKind::udp,
                "udp-v1 selects the configured UDP carrier");
            probe.check(natrav_overlay::transport_locator_text(locator) == text,
                "UDP locator round-trips canonically");
            probe.check(natrav_overlay::parse_configured_transport_locator(text, false).kind ==
                            TransportKind::udp,
                "configured locator parser recognizes udp-v1");
            probe.check(natrav_overlay::parse_transport_kind("udp") == TransportKind::udp,
                "transport kind parser exposes explicit UDP only");
            const auto capabilities = natrav_overlay::transport_capabilities(TransportKind::udp);
            probe.check(capabilities.reliable_stream && capabilities.ordered &&
                            capabilities.full_duplex && capabilities.can_dial &&
                            capabilities.can_listen && capabilities.can_shutdown_write,
                "finite packet service exposes bounded ordered-stream capabilities");
            const auto ipv6 = natrav_overlay::parse_udp_transport_locator(
                "udp-v1|local=[::1]:41001|remote=[::1]:41002|mtu=1200|"
                "link=5544505445535431|epoch=7|profile=1");
            probe.check(natrav_overlay::transport_locator_text(ipv6) ==
                    "udp-v1|local=[::1]:41001|remote=[::1]:41002|mtu=1200|"
                    "link=5544505445535431|epoch=7|profile=1",
                "canonical IPv6 spelling is stable");
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::parse_udp_transport_locator(
                        "udp-v1|local=127.0.0.1:41001|remote=127.0.0.1:41002|mtu=01200|"
                        "link=5544505445535431|epoch=7|profile=1"));
                },
                "UDP_LOCATOR_NONCANONICAL",
                "numeric leading zeros are rejected as noncanonical");
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::parse_udp_transport_locator(
                        "udp-v1|local=127.0.0.1:41001|remote=127.0.0.1:41002|mtu=1200|"
                        "link=554450544553543A|epoch=7|profile=1"));
                },
                "UDP_LOCATOR_INVALID",
                "link identifier is exact lowercase hexadecimal");
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::parse_udp_transport_locator(
                        "udp-v1|local=127.0.0.1:41001|remote=239.1.2.3:41002|mtu=1200|"
                        "link=5544505445535431|epoch=7|profile=1"));
                },
                "UDP_ENDPOINT_UNSUPPORTED",
                "multicast endpoints are outside the point-to-point carrier");
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::parse_udp_transport_locator(
                        "udp-v1|local=127.0.0.1:41001|remote=127.0.0.1:41001|mtu=1200|"
                        "link=5544505445535431|epoch=7|profile=1"));
                },
                "UDP_LOCATOR_INVALID",
                "self-identical local and remote endpoints are rejected");
        });

        probe.run_case("fragmented ordered bytes listener lease and semantic finish", [&] {
            const auto ports = port_pair();
            const auto client_locator = natrav_overlay::parse_udp_transport_locator(
                locator_text(ports.first, ports.second));
            const auto server_locator = natrav_overlay::parse_udp_transport_locator(
                locator_text(ports.second, ports.first));
            auto listener = natrav_overlay::listen_transport(server_locator, 4);
            IoCounters connect_counters;
            auto client = natrav_overlay::connect_transport(
                client_locator, test_deadline(), connect_counters);
            std::vector<std::uint8_t> payload(50'000U);
            for (std::size_t index = 0U; index < payload.size(); ++index) {
                payload[index] = static_cast<std::uint8_t>((index * 29U + 7U) & 0xffU);
            }
            IoCounters client_io;
            write_all(*client, payload, test_deadline(), client_io);
            auto server = accept_with_deadline(*listener, test_deadline());
            probe.check(server->transport_kind() == TransportKind::udp &&
                            listener->readiness_handle() == -1,
                "accepted UDP packet stream owns the one configured listener lease");
            IoCounters server_io;
            const auto received = read_exact(
                *server, payload.size(), test_deadline(), server_io);
            probe.check(received == payload,
                "finite fragmentation and reassembly preserve ordered application bytes");
            const std::vector<std::uint8_t> response(4'097U, 0xa5U);
            write_all(*server, response, test_deadline(), server_io);
            probe.check(read_exact(*client, response.size(), test_deadline(), client_io) == response,
                "the fixed UDP pair remains full duplex");
            client->shutdown_write();
            std::array<std::uint8_t, 1U> eof{};
            probe.check(server->read_some(
                    eof, test_deadline(), server_io, "UDP finish receive") == 0U,
                "finite packet FIN becomes ordered-stream EOF");
            server.reset();
            client.reset();
            std::this_thread::sleep_for(std::chrono::milliseconds(120));
            probe.check(listener->readiness_handle() >= 0,
                "listener reopens its exact fixed endpoint after lease destruction");
        });

        probe.run_case("connected filtering prevents source learning", [&] {
            const auto ports = port_pair();
            std::uint16_t attacker = free_udp_port();
            while (attacker == ports.first || attacker == ports.second) {
                attacker = free_udp_port();
            }
            const auto server_locator = natrav_overlay::parse_udp_transport_locator(
                locator_text(ports.second, ports.first));
            auto listener = natrav_overlay::listen_transport(server_locator, 4);
            send_raw_datagram(attacker, ports.second, 64U);
            pollfd foreign{.fd = listener->readiness_handle(), .events = POLLIN, .revents = 0};
            probe.check(::poll(&foreign, 1U, 100) == 0,
                "datagrams from an unconfigured source do not create a session");
            send_raw_datagram(ports.first, ports.second, 64U);
            auto accepted = accept_with_deadline(*listener, test_deadline());
            probe.check(accepted->transport_kind() == TransportKind::udp,
                "the explicitly configured source can activate the fixed listener");
        });

        probe.run_case("oversize datagrams are rejected rather than truncated", [&] {
            const auto ports = port_pair();
            const auto server_locator = natrav_overlay::parse_udp_transport_locator(
                locator_text(ports.second, ports.first, 256U));
            auto listener = natrav_overlay::listen_transport(server_locator, 4);
            send_raw_datagram(ports.first, ports.second, 400U);
            auto accepted = accept_with_deadline(*listener, test_deadline());
            IoCounters counters;
            std::array<std::uint8_t, 1U> byte{};
            probe.expect_code(
                [&] {
                    static_cast<void>(accepted->read_some(
                        byte, test_deadline(), counters, "UDP truncation probe"));
                },
                "UDP_DATAGRAM_TRUNCATED",
                "recvmsg MSG_TRUNC becomes an explicit carrier error");
        });

        probe.run_case("deadlines and local endpoint ownership remain explicit", [&] {
            const auto ports = port_pair();
            const auto first_locator = natrav_overlay::parse_udp_transport_locator(
                locator_text(ports.first, ports.second));
            IoCounters first_counters;
            auto first = natrav_overlay::connect_transport(
                first_locator, test_deadline(), first_counters);
            IoCounters duplicate_counters;
            probe.expect_code(
                [&] {
                    static_cast<void>(natrav_overlay::connect_transport(
                        first_locator, test_deadline(), duplicate_counters));
                },
                "CONNECT_FAILED",
                "one process cannot silently alias an owned UDP local endpoint");
            std::array<std::uint8_t, 1U> byte{};
            probe.expect_code(
                [&] {
                    static_cast<void>(first->read_some(
                        byte,
                        test_deadline(std::chrono::milliseconds(40)),
                        first_counters,
                        "UDP idle timeout"));
                },
                "IO_TIMEOUT",
                "idle UDP packet stream obeys the caller absolute deadline");
        });

        probe.run_case("real TLS HELLO NOS1 operations receipts and close", [&] {
            const auto ports = port_pair();
            const auto client_locator = natrav_overlay::parse_udp_transport_locator(
                locator_text(ports.first, ports.second, 1200U));
            const auto server_locator = natrav_overlay::parse_udp_transport_locator(
                locator_text(ports.second, ports.first, 1200U));
            const auto run = run_authenticated_session(
                client_locator, server_locator, client_identity, server_identity);
            probe.check(run.clean_close,
                "real authenticated UDP session closes with NOS1 and TLS close-notify");
            probe.check(run.server_operations == 2U,
                "one UDP-backed reusable session carries two operations");
            probe.check(
                run.receipts[0U].disposition == ReceiptDisposition::committed &&
                    run.receipts[1U].sequence == 2U,
                "receipts remain bound above the UDP and packet metadata");
        });

        std::cout << "{\"format\":\"NATRAV_UDP_TRANSPORT_PROBE_V1\","
                  << "\"status\":\"PASS\",\"cases\":[";
        for (std::size_t index = 0U; index < probe.cases().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            const auto& item = probe.cases()[index];
            std::cout << "{\"name\":" << natrav_overlay::json_string(item.name)
                      << ",\"assertions\":" << item.assertions << '}';
        }
        std::cout << "],\"assertions\":" << probe.assertions() << "}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
