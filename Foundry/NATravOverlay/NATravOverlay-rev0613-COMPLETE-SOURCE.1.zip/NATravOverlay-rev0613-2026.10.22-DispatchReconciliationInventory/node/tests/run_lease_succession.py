#!/usr/bin/env python3
"""Provider-controlled acknowledged lease succession; real C++ state and TLS peers."""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import struct
import subprocess
import time
from typing import Any
from run_persistent import Harness, free_port, operation, receive_exact
from run_subscription_leases import leased_provider_config, remote, local
from run_subscriber_requests import subscriber_config, recipient_record
from run_local_evidence import author
from run_live_configuration import candidate, activate
from run_state_authentication import new_key, migrate, start as start_keyed, inspect, checksum_frame
from run_local_administration import expose_control_for_uid, run_as_uid
from run_source_subscriptions import journal_frames, Reader
from run_integration import record_digest
from run_automatic_source_delivery import automatic, wait_automatic

SCOPE = 'query/series'

def add_grant(h: Harness, seed: Path, state: Path, name: str, *, grant: str='g2', lease: str='lease-g2',
              maximum: int=4, maximum_bytes: int=10000, duration: int=60000,
              scope: str=SCOPE, owner: int|None=None, author_uid: int|None=None,
              remove: str|None=None) -> Path:
    uid=os.geteuid() if owner is None else owner
    auid=os.geteuid() if author_uid is None else author_uid
    def change(text: str) -> str:
        if remove is not None:
            text='\n'.join(line for line in text.splitlines() if not line.startswith('source_disclosure='+remove+','))+'\n'
        return text+f'source_disclosure={grant},{uid},{auid},C,c-g1,{scope},{maximum},{maximum_bytes},{lease},{duration},RETAIN\n'
    nxt=candidate(h,seed,name,name+'-g',change)
    activate(h,name+'-activate',state,nxt)
    return nxt

def succeed_args(state: Path, old: dict[str, Any], *, grant: str='g2', lease: str='lease-g2',
                 reason: str='adopt exact acknowledged terminal frontier') -> list[str]:
    return ['source-subscription-succeed','--control',str(state/'control.sock'),'--grant',grant,
            '--successor-lease',lease,'--predecessor-grant',old['grant'],'--predecessor-lease',old['lease_generation'],
            '--instance',old['instance'],'--expected-revision',str(old['revision']),
            '--predecessor-state-digest',old['state_digest'],'--mapping-digest',old['acknowledged_mapping_digest'],
            '--expected-frontier',str(old['acknowledged_source_position']),'--reason',reason,'--deadline-ms','5000']

def succeed(h: Harness, label: str, state: Path, old: dict, *, expected: int=0, **kw: Any) -> dict:
    r=h.run(label,succeed_args(state,old,**kw),expected=expected)
    assert r is not None
    return r

def received(h: Harness, label: str, state: Path, issued: dict) -> dict:
    grant=issued['grant']
    h.wait(label+'-receipt',lambda: local(h,label+'-receipt',state,'status',grant=grant)['delivery_status']=='ACKED')
    r=local(h,label+'-ack',state,'step',grant=grant,previous=issued)
    h.check(r['acknowledged']==issued['acknowledged']+1,'subscription progress is behind an actual durable receipt')
    return r

def setup(h: Harness, name: str, *, policy: str='RETAIN', recipient: bool=True,
          duration: int=60000, maximum: int=8) -> tuple:
    a,c=h.runtime/(name+'-a'),h.runtime/(name+'-c')
    ap,cp=free_port(),free_port()
    pa=leased_provider_config(h,name+'-a',a,ap,cp,policy=policy,duration_ms=duration,maximum_records=maximum)
    pc=subscriber_config(h,name+'-c',c,'C',cp,ap)
    ad=h.start(name+'-a',pa,a)
    cd=h.start(name+'-c',pc,c) if recipient else None
    r=remote(h,name+'-request',pc,'request',operation(name+'-request'))
    return a,c,pa,pc,ad,cd,r

def withdraw(h: Harness, name: str, state: Path, pc: Path, old: dict) -> dict:
    remote(h,name+'-withdraw',pc,'withdraw',operation(name+'-withdraw'),instance=old['instance'],revision=old['revision'])
    return local(h,name+'-terminal',state,'status')

def expire(h: Harness, label: str, state: Path, current: dict) -> dict:
    remaining=current['lease_expires_unix_ms']/1000-time.time()
    if remaining>0: time.sleep(remaining+0.03)
    local(h,label+'-encounter',state,'step',grant=current['grant'],previous=current)
    result=local(h,label+'-terminal',state,'status',grant=current['grant'])
    h.check(result['termination']['kind']=='EXPIRED','expiry is a committed terminal transition')
    return result

def recipient_successor(h: Harness, label: str, state: Path, issued: dict) -> dict:
    op=issued['latest']['operation_id']
    q=h.run(label,['evidence-query','--control',str(state/'control.sock'),'--view','history',
                   '--operation',op,'--payload','yes','--payload-length','16384','--deadline-ms','5000'])
    h.check(len(q['records'])==1,'recipient stores one successor envelope')
    raw=bytes.fromhex(q['records'][0]['payload_hex']);r=Reader(raw)
    h.check(r.get(4)==b'NSE2','successor delivery uses an explicit lineage envelope')
    result={'grant':r.text(),'instance':r.digest(),'grant_digest':r.digest(),'recipient':r.text(),
            'generation':r.text(),'spki':r.digest(),'ordinal':r.number(8),'author_uid':r.number(4),
            'authored_unix_ms':r.number(8),'source_digest':r.digest()}
    marker=r.number(1);h.check(marker in (0,1),'parent boolean is strict')
    result['mapped_corrects']=r.digest() if marker else None
    source=r.get(r.number(4))
    result['predecessor_grant']=r.text();result['predecessor_lease']=r.text()
    result['predecessor_instance']=r.digest();result['predecessor_state_digest']=r.digest()
    result['mapping_digest']=r.digest();result['inherited_acknowledged']=r.number(8);r.eof()
    q=Reader(source);h.check(q.get(4)==b'NOA1','embedded source retains normal record framing')
    kind=q.number(1);h.check(kind in (1,2),'source is evidence or correction')
    result['source_operation']=q.digest();result['issuer']=q.text();result['source_recipient']=q.text();result['scope']=q.text()
    result['source_corrects']=q.digest() if kind==2 else None
    result['payload_hex']=q.get(q.number(4)).hex();q.eof()
    h.check(record_digest(source).hex()==result['source_digest'],'independent source commitment')
    h.check(hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_DELIVERY_V2\0'+raw).hexdigest()==op,
            'independent recipient operation commitment')
    fixture=h.work/(label+'.nse');fixture.write_bytes(raw)
    decoded=h.run(label+'-native',['source-envelope-inspect','--payload-file',str(fixture)])
    h.check(decoded['verification']=='STRUCTURAL_ONLY' and decoded['ordinal']==result['ordinal'] and
            decoded['source_payload_hex']==result['payload_hex'] and
            decoded['succession']['mapping_digest']==result['mapping_digest'],
            'native decoder agrees without asserting external proof')
    fixture.write_bytes(raw+b'x');h.run(label+'-trailing',['source-envelope-inspect','--payload-file',str(fixture)],expected=4)
    return result

def mapping_reference(h: Harness, snapshot: dict) -> None:
    by_grant={x['grant']:x for x in snapshot['source_subscriptions']}
    def text(s: str) -> bytes:
        b=s.encode();return struct.pack('!H',len(b))+b
    cache={}
    def compute(s: dict) -> bytes:
        if s['grant'] in cache:return cache[s['grant']]
        x=s['succession'];base=s['inherited_acknowledged']
        if x:
            root=compute(by_grant[x['predecessor_grant']])
            h.check(root.hex()==x['mapping_digest'],'successor inherits exact independently reconstructed mapping')
        else:
            raw=text(s['peer'])+text(s['generation'])+bytes.fromhex(s['peer_spki_sha256'])+struct.pack('!I',s['source_author_uid'])+text(s['scope'])
            root=hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_MAPPING_ROOT_V1\0'+raw).digest()
        for i,d in enumerate(s['deliveries'][:s['acknowledged']]):
            raw=root+struct.pack('!Q',base+i+1)
            raw+=bytes.fromhex(d['source_operation'])+bytes.fromhex(d['operation_id'])+bytes.fromhex(d['record_digest'])
            raw+=struct.pack('!IQQIQQIQQ',d['source_payload_bytes'],d['configuration_event'],d['queued_unix_ms'],d['pid'],
                             d['acknowledged_event'],d['acknowledged_unix_ms'],d['acknowledged_pid'],
                             d['issue_automatic_generation'],d['acknowledge_automatic_generation'])
            root=hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_MAPPING_LINK_V1\0'+raw).digest()
        h.check(root.hex()==s['acknowledged_mapping_digest'],'independent mapping root includes exact acknowledged provenance')
        cache[s['grant']]=root;return root
    for item in by_grant.values():compute(item)


def cases(h: Harness, selected: set[str]|None) -> None:
    def case(name: str, fn: Any) -> None:
        if selected is None or name in selected: h.case(name,fn)

    def chain() -> None:
        a,c,pa,pc,ad,cd,current=setup(h,'chain',maximum=2)
        orig=operation('chain-original'); other=operation('chain-other')
        author(h,'chain-original',a,op=orig,value='abc')
        author(h,'chain-other',a,op=other,value='12345')
        old_ops=[]
        for i in range(2):
            current=local(h,f'chain-issue-{i}',a,'step',previous=current)
            old_ops.append(current['latest']['operation_id'])
            current=received(h,f'chain-{i}',a,current)
        terminal=withdraw(h,'chain',a,pc,current)
        before=terminal['state_digest']
        pa2=add_grant(h,pa,a,'chain-g2',maximum=2,maximum_bytes=9,duration=15000)
        second=succeed(h,'chain-succeed',a,terminal)
        h.check(second['disposition']=='SUCCEEDED' and second['inherited_acknowledged']==2 and second['issued']==0 and
                second['used_payload_bytes']==0 and second['automatic_current'] is None,'new finite allowance and no borrowed automation')
        h.check(second['acknowledged_mapping_digest']==terminal['acknowledged_mapping_digest'],
                'adopting the acknowledged prefix preserves its commitment')
        correction=operation('chain-correction')
        author(h,'chain-correction',a,op=correction,parent=orig,value='1234567')
        second=local(h,'chain-new-issue',a,'step',grant='g2',previous=second)
        second=received(h,'chain-new',a,second)
        first_new=second['latest']['operation_id']
        env=recipient_successor(h,'chain-delivered',c,second)
        h.check(env['ordinal']==3 and env['source_corrects']==orig and env['mapped_corrects']==old_ops[0],
                'new lease maps a correction to the predecessor recipient operation')
        author(h,'chain-next-correction',a,parent=correction,value='xy')
        second=local(h,'chain-next-issue',a,'step',grant='g2',previous=second)
        second=received(h,'chain-next',a,second)
        h.check(second['acknowledged_source_position']==4 and second['used_payload_bytes']==9,
                'own finite accounting is separate from inherited position')
        again=succeed(h,'chain-original-retry',a,terminal)
        h.check(again['disposition']=='ALREADY_SUCCEEDED' and again['revision']==second['revision'] and
                again['used_payload_bytes']==9,'lost-response retry cannot reset or replenish a progressed successor')
        unchanged=local(h,'chain-old-still-terminal',a,'status')
        h.check(unchanged['state_digest']==before and unchanged['adopted_by']=='g2' and unchanged['used_payload_bytes']==8,
                'predecessor terminal state and spent budgets are immutable')
        r=remote(h,'chain-new-request-does-not-renew',pc,'request',operation('chain-g2-remote'),grant='g2',lease='lease-g2',expected=3)
        h.check(r['code']=='SOURCE_SUBSCRIPTION_PROVIDER_MANAGED','remote reconnect cannot replace provider-managed successor')
        exhausted=local(h,'chain-budget-bound',a,'step',grant='g2',previous=second)
        h.check(exhausted['disposition']=='RECORD_BUDGET_EXHAUSTED','successor grant has its own exact finite ceiling')
        term2=expire(h,'chain-g2',a,second)
        pa3=add_grant(h,pa2,a,'chain-g3',grant='g3',lease='lease-g3',maximum=1)
        third=succeed(h,'chain-third',a,term2,grant='g3',lease='lease-g3')
        author(h,'chain-third-source',a,parent=other,value='new')
        third=local(h,'chain-third-issue',a,'step',grant='g3',previous=third)
        third=received(h,'chain-third',a,third)
        env=recipient_successor(h,'chain-third-envelope',c,third)
        h.check(env['ordinal']==5 and env['mapped_corrects']==old_ops[1],
                'correction ancestry resolves through two retained predecessor leases')
        h.run('chain-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000'])
        ad.shutdown();ad=h.start('chain-restart',pa3,a)
        rebuilt=local(h,'chain-rebuilt',a,'status',grant='g3')
        h.check(rebuilt['state_digest']==third['state_digest'],'checkpoint and restart preserve exact successor state')
        (h.output/'CHAIN.json').write_text(json.dumps({'predecessor':terminal,'successor':second,'third':rebuilt},indent=2)+'\n')
        ad.shutdown();cd.shutdown()
        mapping_reference(h,inspect(h,'chain-offline',a))
    case('acknowledged_chain_and_correction_continuity',chain)

    def selectors() -> None:
        a,c,pa,pc,ad,cd,current=setup(h,'selectors')
        pa2=add_grant(h,pa,a,'selectors-g2')
        current=local(h,'selectors-current',a,'status')
        r=succeed(h,'selectors-active',a,current,expected=3)
        h.check(r['code']=='SOURCE_SUCCESSION_TERMINAL_REQUIRED','an active lease is not implicitly renewed')
        terminal=withdraw(h,'selectors',a,pc,current)
        base=succeed_args(a,terminal)
        for flag,value,code in [
            ('--instance',operation('wrong-instance'),'SOURCE_SUCCESSION_CONFLICT'),
            ('--expected-revision',str(terminal['revision']+1),'SOURCE_SUCCESSION_CONFLICT'),
            ('--predecessor-state-digest',operation('wrong-state'),'SOURCE_SUCCESSION_CONFLICT'),
            ('--mapping-digest',operation('wrong-mapping'),'SOURCE_SUCCESSION_CONFLICT'),
            ('--expected-frontier','1','SOURCE_SUCCESSION_CONFLICT'),
            ('--predecessor-lease','other-lease','SOURCE_SUCCESSION_CONFLICT'),
            ('--successor-lease','other-lease','SOURCE_SUCCESSION_LEASE_MISMATCH')]:
            args=list(base);args[args.index(flag)+1]=value
            result=h.run('selectors-'+flag[2:],args,expected=3)
            h.check(result['code']==code,'exact selector rejects '+flag)
        # A separately authorized domain is not the predecessor domain.
        pa3=add_grant(h,pa2,a,'selectors-wrong-domain',grant='wrong-domain',lease='lease-other-domain',scope='query/other')
        result=succeed(h,'selectors-domain',a,terminal,grant='wrong-domain',lease='lease-other-domain',expected=3)
        h.check(result['code']=='SOURCE_SUCCESSION_IDENTITY_MISMATCH','accepted new authority cannot reinterpret inherited domain')
        # Real kernel UID has SOURCE_DISCLOSE, but no ownership of the old grant.
        txt=f'local_control=65534,SOURCE_DISCLOSE\nsource_disclosure=other-owner,65534,{os.geteuid()},C,c-g1,{SCOPE},1,100,other-owner-lease,60000,RETAIN\n'
        alt=candidate(h,pa3,'selectors-owner-policy','selectors-owner-g',lambda text:text+txt)
        # candidate() sets runtime_generation on returned text; preserve its distinct generation.
        activate(h,'selectors-owner-activate',a,alt)
        expose_control_for_uid(a)
        other=run_as_uid(h,'selectors-real-uid',65534,65534,succeed_args(a,terminal,grant='other-owner',lease='other-owner-lease'),3)
        h.check(other['code']=='SOURCE_SUBSCRIPTION_NOT_FOUND','another granted real UID cannot adopt the manager predecessor')
        # Restore owner-only access after the disposable credential experiment.
        a.chmod(0o700);(a/'control.sock').chmod(0o600)
        good=succeed(h,'selectors-correct',a,terminal)
        fork=succeed(h,'selectors-fork',a,terminal,grant='wrong-domain',lease='lease-other-domain',expected=3)
        h.check(fork['code']=='SOURCE_SUCCESSION_IDENTITY_MISMATCH','domain check remains enforced after another adoption')
        nxt=add_grant(h,alt,a,'selectors-valid-fork',grant='fork',lease='lease-fork')
        fork=succeed(h,'selectors-exact-fork',a,terminal,grant='fork',lease='lease-fork',expected=3)
        h.check(fork['code']=='SOURCE_SUCCESSION_PREDECESSOR_ADOPTED','terminal predecessor cannot fork into two successors')
        stale=list(base);stale[stale.index('--reason')+1]='changed intent'
        h.run('selectors-changed-retry',stale,expected=3)
        h.check(local(h,'selectors-final',a,'status',grant='g2')['state_digest']==good['state_digest'],
                'invalid selectors do not change successful successor')
        ad.shutdown();cd.shutdown()
    case('exact_selectors_owner_and_no_fork',selectors)

    def pending() -> None:
        for policy in ('RETAIN','CANCEL'):
            label='pending-'+policy.lower()
            a,c,pa,pc,ad,cd,current=setup(h,label,policy=policy,recipient=False)
            author(h,label+'-source',a,value='not acknowledged')
            issued=local(h,label+'-issue',a,'step',previous=current)
            terminal=withdraw(h,label,a,pc,issued)
            newer=add_grant(h,pa,a,label+'-new')
            denied=succeed(h,label+'-deny',a,terminal,expected=3)
            h.check(denied['code']=='SOURCE_SUCCESSION_UNACKNOWLEDGED' and terminal['acknowledged']==0,
                    'terminal '+policy+' cannot implicitly discard or acknowledge its unresolved source')
            if policy=='RETAIN':
                cd=h.start(label+'-recipient',pc,c)
                h.wait(label+'-late-receipt',lambda: local(h,label+'-wait',a,'status')['delivery_status']=='ACKED')
                denied=succeed(h,label+'-late-ack',a,terminal,expected=3)
                h.check(denied['code']=='SOURCE_SUCCESSION_UNACKNOWLEDGED',
                        'late outbox receipt is not silently adopted as subscription progress')
                cd.shutdown()
            check=local(h,label+'-unchanged',a,'status')
            h.check(check['state_digest']==terminal['state_digest'] and check['adopted_by'] is None,
                    'rejected succession preserves terminal history')
            ad.shutdown()
    case('unacknowledged_predecessor_refused',pending)

    def racing() -> None:
        a,c,pa,pc,ad,cd,current=setup(h,'concurrent')
        terminal=withdraw(h,'concurrent',a,pc,current)
        newer=add_grant(h,pa,a,'concurrent-g2')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda i:succeed(h,f'concurrent-{i}',a,terminal),range(8)))
        h.check(sum(x['disposition']=='SUCCEEDED' for x in results)==1 and
                sum(x['disposition']=='ALREADY_SUCCEEDED' for x in results)==7,
                'eight racing exact requests have one durable creator')
        digests={x['state_digest'] for x in results};h.check(len(digests)==1,'all racing retries observe the same immutable admission')
        ad.shutdown();cd.shutdown()
    # Avoid shadowing the imported concurrent module in the callable.
    concurrent_case=racing
    case('concurrent_idempotent_succession',concurrent_case)


    def persistence() -> None:
        a,c,pa,pc,ad,cd,current=setup(h,'persist')
        orig=operation('persist-original');author(h,'persist-original',a,op=orig,value='original')
        issued=local(h,'persist-issue',a,'step',previous=current);acked=received(h,'persist',a,issued)
        terminal=withdraw(h,'persist',a,pc,acked)
        pa2=add_grant(h,pa,a,'persist-g2',maximum=2)
        successor=succeed(h,'persist-succeed',a,terminal)
        ad.shutdown()
        before=inspect(h,'persist-before',a);mapping_reference(h,before)
        keys=h.work/'persist-keys';keys.mkdir(mode=0o700);key=new_key(h,keys,'state-g1')
        migrate(h,'persist-migrate',a,key)
        h.run('persist-audit',['state-auth-audit','--state',str(a),'--node','A','--state-auth-key',str(key)])
        ad=start_keyed(h,'persist-keyed',pa2,a,key)
        h.run('persist-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000']);ad.shutdown()
        keyed=inspect(h,'persist-keyed-offline',a,key)
        h.check(keyed['source_subscriptions']==before['source_subscriptions'],'migration and compaction preserve exact linked state')
        enc=keys/'archive.key';archive=h.work/'persist.nob';identity=h.identity('A')
        h.run('persist-encryption',['backup-key-init','--output',str(enc),'--generation','backup-g1'])
        h.run('persist-export',['backup-export','--state',str(a),'--node','A','--generation','a-g1','--output',str(archive),
              '--state-auth-key',str(key),'--encrypt-key',str(enc),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'persist-restored'
        h.run('persist-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1',
              '--state-auth-key',str(key),'--decrypt-key',str(enc),'--trusted-cert',str(identity.certificate),
              '--require-signature','yes','--require-encryption','yes'])
        restored_state=inspect(h,'persist-restored-offline',restored,key)
        h.check(restored_state['storage']['logical_state_digest']==keyed['storage']['logical_state_digest'] and
                restored_state['source_subscriptions']==keyed['source_subscriptions'],
                'encrypted signed restore preserves adopted frontier and old budgets')
        moved=candidate(h,pa2,'persist-moved','persist-moved-g',lambda text:text.replace('state='+str(a),'state='+str(restored)))
        h.run('persist-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),
              '--reason','continue acknowledged successor on restored owned path','--state-auth-key',str(key)])
        ad=start_keyed(h,'persist-restored-live',moved,restored,key)
        same=succeed(h,'persist-retry',restored,terminal)
        h.check(same['disposition']=='ALREADY_SUCCEEDED' and same['instance']==successor['instance'],
                'relocation does not reinterpret lost-response retry or lease clock')
        enabled=automatic(h,'persist-enable',restored,'enable',grant='g2',previous=same,maximum=2,interval=10)
        author(h,'persist-correction',restored,parent=orig,value='replacement')
        done=wait_automatic(h,'persist-auto',restored,lambda x:x['acknowledged']==1,grant='g2')
        h.check(done['acknowledged_source_position']==2 and done['automatic_current']['steps']==2 and
                done['automatic_current']['state']=='EXHAUSTED','explicit new automation starts at inherited frontier and spends only new allowance')
        env=recipient_successor(h,'persist-envelope',c,done)
        h.check(env['mapped_corrects']==issued['latest']['operation_id'],'restored successor corrects original recipient admission')
        ad.shutdown();cd.shutdown()
        final=inspect(h,'persist-final',restored,key);mapping_reference(h,final)
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'successor':done,'envelope':env,
              'logical_digest_before_restore':keyed['storage']['logical_state_digest'],
              'logical_digest_after_restore':restored_state['storage']['logical_state_digest']},indent=2)+'\n')
    case('keyed_compaction_restore_and_automatic_continuation',persistence)

    def corruption() -> None:
        a,c,pa,pc,ad,cd,current=setup(h,'corrupt')
        author(h,'corrupt-source',a,value='source')
        current=local(h,'corrupt-issue',a,'step',previous=current);current=received(h,'corrupt',a,current)
        terminal=withdraw(h,'corrupt',a,pc,current);pa2=add_grant(h,pa,a,'corrupt-g2')
        successor=succeed(h,'corrupt-succeed',a,terminal)
        ad.shutdown();cd.shutdown()
        journal=a/'state.journal';frames=journal_frames(journal)
        h.check(sum(b'NSS5' in f for f in frames)==1,'one atomic successor journal state exists')
        for name,needle in [('mapping',terminal['acknowledged_mapping_digest']),('predecessor',terminal['state_digest'])]:
            out=[]
            for f in frames:
                if b'NSS5' in f:
                    b=bytearray(f);where=b.rfind(bytes.fromhex(needle),0,len(b)-32)
                    h.check(where>0,'find exact '+name+' commitment in successor state')
                    b[where]^=1;f=checksum_frame(bytes(b))
                out.append(f)
            journal.write_bytes(b''.join(out))
            rejected=inspect(h,'corrupt-'+name,a,expected=3)
            h.check(rejected['code']=='JOURNAL_CORRUPT','recomputed checksum cannot authenticate false '+name+' adoption')
        journal.write_bytes(b''.join(frames))
        recovered=inspect(h,'corrupt-restored-source',a);mapping_reference(h,recovered)
        ad=h.start('corrupt-compaction',pa2,a)
        h.run('corrupt-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000']);ad.shutdown()
        frames=journal_frames(journal)
        h.check(frames[0][8]==18 and sum(f[8]==18 for f in frames)==1,
                'compaction produces one checkpoint; shutdown may append control-account records')
        b=bytearray(frames[0]);where=b.rfind(bytes.fromhex(terminal['state_digest']),0,len(b)-32)
        h.check(where>0,'checkpoint retains exact predecessor commitment');b[where]^=1
        journal.write_bytes(checksum_frame(bytes(b))+b''.join(frames[1:]))
        rejected=inspect(h,'corrupt-checkpoint',a,expected=3)
        h.check(rejected['code']=='JOURNAL_CORRUPT','checkpoint decoding preserves predecessor-state binding')
        journal.write_bytes(b''.join(frames))
    case('semantic_journal_and_checkpoint_binding',corruption)

    def kills() -> None:
        for boundary in ('BEFORE','AFTER'):
            name='kill-'+boundary.lower();a,c,pa,pc,ad,cd,current=setup(h,name)
            terminal=withdraw(h,name,a,pc,current);pa2=add_grant(h,pa,a,name+'-g2')
            ad.shutdown()
            hook='NATRAV_OVERLAY_TEST_SOURCE_SUCCESSION_'+boundary+'_COMMIT_MS'
            ad=h.start(name+'-hook',pa2,a,{hook:'10000'})
            args=succeed_args(a,terminal)
            log=(h.logs/(name+'-client.txt')).open('w')
            client=subprocess.Popen([str(h.binary),*args],stdout=log,stderr=subprocess.STDOUT,text=True)
            if boundary=='AFTER':
                h.wait(name+' committed marker',lambda:b'NSS5' in (a/'state.journal').read_bytes(),5)
            else:
                time.sleep(.25)
                h.check(b'NSS5' not in (a/'state.journal').read_bytes(),'pre-commit publication is absent')
            h.check(client.poll() is None,'client is waiting at selected publication boundary')
            ad.kill()
            try:client.wait(timeout=3)
            except subprocess.TimeoutExpired:client.kill();client.wait(timeout=3)
            log.close()
            ad=h.start(name+'-restart',pa2,a)
            if boundary=='BEFORE':local(h,name+'-absent',a,'status',grant='g2',expected=3)
            recovered=succeed(h,name+'-recover',a,terminal)
            h.check(recovered['disposition']==('SUCCEEDED' if boundary=='BEFORE' else 'ALREADY_SUCCEEDED') and
                    recovered['revision']==1 and recovered['inherited_acknowledged']==0,
                    'restart reconstructs either no successor or the complete successor')
            h.check(local(h,name+'-old',a,'status')['state_digest']==terminal['state_digest'],
                    'publication kill does not edit predecessor terminal state')
            ad.shutdown();cd.shutdown()
    case('pre_and_post_commit_process_kills',kills)

    def capacity() -> None:
        a,c,pa,pc,ad,cd,current=setup(h,'capacity',duration=100)
        terminal=expire(h,'capacity-g1',a,local(h,'capacity-first',a,'status'))
        first=terminal
        for n in range(2,17):
            grant=f'g{n}';lease=f'lease-g{n}'
            pa=add_grant(h,pa,a,f'capacity-{n}',grant=grant,lease=lease,duration=100,maximum=1)
            created=succeed(h,f'capacity-succeed-{n}',a,terminal,grant=grant,lease=lease)
            terminal=expire(h,f'capacity-expire-{n}',a,created)
        pa=add_grant(h,pa,a,'capacity-17',grant='g17',lease='lease-g17')
        full=succeed(h,'capacity-full',a,terminal,grant='g17',lease='lease-g17',expected=3)
        h.check(full['code']=='SOURCE_SUBSCRIPTION_LIMIT','sixteen retained generations consume exact manager capacity')
        h.run('capacity-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000']);ad.shutdown()
        # Lexical grant ordering differs from lineage ordering (g10 precedes g2).
        ad=h.start('capacity-restart',pa,a)
        h.check(local(h,'capacity-last',a,'status',grant='g16')['state_digest']==terminal['state_digest'],
                'unordered checkpoint registry reconstructs the bounded complete lineage')
        h.check(local(h,'capacity-first-stable',a,'status')['state_digest']==first['state_digest'],
                'deep succession preserves original terminal account')
        ad.shutdown();cd.shutdown()
        state=inspect(h,'capacity-offline',a);mapping_reference(h,state)
        h.check(len(state['source_subscriptions'])==16,'no partial seventeenth successor')
        (h.output/'CAPACITY.json').write_text(json.dumps({'retained':16,'maximum_tested_depth':16,
              'excess_code':full['code'],'last_frontier':terminal['acknowledged_source_position']},indent=2)+'\n')
    case('bounded_retained_lineage_and_checkpoint_order',capacity)

    def revocation() -> None:
        a,c,pa,pc,ad,cd,current=setup(h,'revoke')
        terminal=withdraw(h,'revoke',a,pc,current);pa2=add_grant(h,pa,a,'revoke-g2')
        def text(value: str) -> bytes:
            raw=value.encode();return struct.pack('!H',len(raw))+raw
        reason='delayed candidate request'
        raw=b'NOC1'+bytes([20])+b'NSR3'+bytes([8])+text('g2')+bytes.fromhex(terminal['instance'])+struct.pack('!Q',terminal['revision'])
        raw+=text('g1')+text('lease-g1')+text('lease-g2')+bytes.fromhex(terminal['state_digest'])+bytes.fromhex(terminal['acknowledged_mapping_digest'])
        raw+=struct.pack('!Q',terminal['acknowledged_source_position'])+text(reason)
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as sock:
            sock.settimeout(5);sock.connect(str(a/'control.sock'));sock.sendall(struct.pack('!I',len(raw))+raw[:-1])
            revoked=candidate(h,pa2,'revoke-removed','revoke-removed-g',lambda tx:'\n'.join(
                line for line in tx.splitlines() if not line.startswith('source_disclosure=g2,'))+'\n')
            activate(h,'revoke-live',a,revoked)
            sock.sendall(raw[-1:]);sock.shutdown(socket.SHUT_WR)
            n=struct.unpack('!I',receive_exact(sock,4))[0];reply=receive_exact(sock,n)
        h.check(reply[:5]==b'NOR1\x01' and json.loads(reply[5:])['code']=='SOURCE_DISCLOSURE_DENIED',
                'slow connected request uses current policy rather than pre-read authority')
        restored=candidate(h,pa2,'revoke-restored','revoke-restored-g')
        activate(h,'revoke-restore',a,restored)
        r=succeed(h,'revoke-explicit-success',a,terminal)
        h.check(r['disposition']=='SUCCEEDED','restoring policy does not itself create successor')
        ad.shutdown();cd.shutdown()
    case('independent_wire_and_live_revocation',revocation)


    def ordinal_boundary() -> None:
        a,c,pa,pc,ad,cd,current=setup(h,'ordinal',maximum=128,duration=180000)
        parent=operation('ordinal-0');first_operation=None
        for i in range(128):
            author(h,f'ordinal-{i}',a,value='x')
            current=local(h,f'ordinal-issue-{i}',a,'step',previous=current)
            if i==0:first_operation=current['latest']['operation_id']
            current=received(h,f'ordinal-{i}',a,current)
        terminal=withdraw(h,'ordinal',a,pc,current)
        pa2=add_grant(h,pa,a,'ordinal-g2',maximum=1,maximum_bytes=1)
        successor=succeed(h,'ordinal-succeed',a,terminal)
        author(h,'ordinal-correction',a,parent=parent,value='y')
        successor=local(h,'ordinal-new-issue',a,'step',grant='g2',previous=successor)
        successor=received(h,'ordinal-new',a,successor)
        envelope=recipient_successor(h,'ordinal-129',c,successor)
        h.check(envelope['ordinal']==129 and envelope['inherited_acknowledged']==128 and
                envelope['mapped_corrects']==first_operation and successor['used_payload_bytes']==1,
                'NSE2 crosses the legacy ordinal ceiling without broadening the new lease budget')
        ad.shutdown();cd.shutdown()
        # Offline replay of the complete, uncompacted 128-issue transition
        # history performs full semantic reconstruction under sanitizers. Its
        # test process budget is separate from all live product I/O deadlines.
        replay_started=time.monotonic()
        snapshot=h.run('ordinal-offline',['inspect','--state',str(a),'--node','A'],timeout=60)
        assert snapshot is not None
        replay_seconds=time.monotonic()-replay_started
        mapping_reference(h,snapshot)
        (h.output/'ORDINAL-BOUNDARY.json').write_text(json.dumps({'predecessor_issued':128,
              'successor_issued':1,'successor_used_bytes':1,'offline_replay_budget_seconds':60,
              'offline_replay_seconds':replay_seconds,'envelope':envelope},indent=2)+'\n')
    case('full_predecessor_and_source_ordinal_129',ordinal_boundary)


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append')
    args=p.parse_args()
    if args.output.exists():p.error('output already exists')
    h=Harness(args.binary,args.output);t=time.time();ok=False
    try:cases(h,set(args.case) if args.case else None);ok=True
    finally:
        h.cleanup()
        summary={'format':'NATRAV_OVERLAY_LEASE_SUCCESSION_TESTS_V1','status':'PASS' if ok else 'FAIL',
            'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),
            'cases_passed':sum(x['status']=='PASS' for x in h.cases),'assertions':h.assertions,
            'commands':len(h.commands),'elapsed_seconds':time.time()-t}
        for n,v in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:
            (h.output/(n+'.json')).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
