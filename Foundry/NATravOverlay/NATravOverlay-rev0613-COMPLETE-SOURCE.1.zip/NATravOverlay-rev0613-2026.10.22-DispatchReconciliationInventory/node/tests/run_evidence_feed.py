#!/usr/bin/env python3
"""Bounded append-only authorized consumption using real C++ nodes and UIDs."""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import socket
import statistics
import struct
import time
from typing import Any

from run_persistent import Harness, free_port, operation, raw_control, receive_exact
from run_scoped_reads import trio, send, scoped_config, UID, SECOND_UID
from run_evidence_queries import config as legacy_config
from run_local_administration import run_as_uid, expose_control_for_uid
from run_live_configuration import candidate, activate, wait_state
from run_peer_sessions import revise, submit
from run_state_authentication import new_key, migrate, start as start_keyed
from run_indexed_pagination import fixture, receiver


def feed_args(state: Path, **options: Any) -> list[str]:
    args=['evidence-feed','--control',str(state/'control.sock'),'--deadline-ms','4000']
    for key,value in options.items():args += ['--'+key.replace('_','-'),str(value)]
    return args


def poll(h: Harness,label: str,state: Path,expected: int=0,*,uid: int|None=None,**options: Any) -> dict[str,Any]:
    args=feed_args(state,**options)
    result=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    assert result is not None
    if expected==0:
        h.check(result['format']=='NATRAV_OVERLAY_EVIDENCE_FEED_V1','feed response version')
        h.check(result['returned_records']==len(result['records']),'returned event count')
        h.check(result['sequence_semantics']=='AUTHORIZED_ADMISSION_ORDINAL','no global admission position')
        h.check(result['next_sequence']-result['after_sequence']==len(result['records']),'position advances only by returned rows')
        h.check(len(result['next_cursor'])==304,'finite process-local continuation')
        h.check(result['feed_work']['selection_records_hashed']==0,'no full-selection hashing')
        raw=next(c['stdout'] for c in reversed(h.commands) if c['label']==label)
        h.check(len(raw.strip().encode())<=int(options.get('max_bytes',60000)),'complete annotated byte limit')
        h.check(all('superseded_by' not in r for r in result['records']),'admission events are immutable')
    return result


def wire_feed(*,payload: bool=False,issuer: str='',scope: str='',limit: int=32,max_bytes: int=60000,
              length: int=0,start: bool=False,cursor: str='') -> bytes:
    def text(value: str) -> bytes:
        b=value.encode();return struct.pack('!H',len(b))+b
    return b'NOC1\x10NEF1'+bytes([payload])+text(issuer)+text(scope)+struct.pack('!III',limit,max_bytes,length)+bytes([start])+text(cursor)


def raw_poll(state: Path,**kw: Any) -> tuple[dict[str,Any],float,int]:
    before=time.perf_counter()
    ok,result=raw_control(state/'control.sock',wire_feed(**kw))
    if not ok:raise AssertionError('independent feed request failed: '+json.dumps(result))
    return result,time.perf_counter()-before,len(json.dumps(result))


def cases(h: Harness,selected: set[str]|None=None) -> None:
    def case(name: str,fn: Any) -> None:
        if selected is None or name in selected:h.case(name,fn)

    def strict() -> None:
        state=h.runtime/'strict';cfg=scoped_config(h,'strict','B',state,free_port(),[(os.geteuid(),'A','query/series','PAYLOAD')])
        d=h.start('strict',cfg,state)
        empty=poll(h,'strict-empty',state)
        h.check(empty['caught_up'] and empty['next_sequence']==0,'empty feed returns resumable zero-position token')
        wire=wire_feed();ok,response=raw_control(d.control,wire)
        h.check(ok and response['records']==[],'independent NEF1 encoding interoperates')
        def text(s: str)->bytes:
            b=s.encode();return struct.pack('!H',len(b))+b
        material=b'NEF1\x00'+text('')+text('')+struct.pack('!III',32,60000,0)+text('B')
        h.check(response['feed_digest']==hashlib.sha256(material).hexdigest(),'independent feed-spec digest')
        for label,body in [('zero-limit',wire_feed(limit=0)),('too-many',wire_feed(limit=129)),
                           ('small-body',wire_feed(max_bytes=4095)),('big-body',wire_feed(max_bytes=60001)),
                           ('no-payload-length',wire_feed(payload=True)),('long-payload',wire_feed(payload=True,length=16385)),
                           ('payload-without-authority-mode',wire_feed(length=1)),('start-with-token',wire_feed(start=True,cursor=empty['next_cursor'])),
                           ('short-cursor',wire_feed(cursor='00')),('unknown-magic',wire.replace(b'NEF1',b'NEF9')),
                           ('invalid-mode',wire[:9]+b'\x02'+wire[10:]),('short',wire[:-1]),('trailing',wire+b'x')]:
            ok,error=raw_control(d.control,body)
            h.check(not ok and 'records' not in error,'strict wire rejection '+label)
        tampered=empty['next_cursor'][:-1]+('0' if empty['next_cursor'][-1]!='0' else '1')
        h.check(poll(h,'feed-bad-mac',state,3,cursor=tampered)['code']=='EVIDENCE_FEED_CURSOR_INVALID','authenticate token before consumption')
        h.check(poll(h,'feed-changed-filter',state,3,cursor=empty['next_cursor'],issuer='C')['code']=='EVIDENCE_FEED_CONTEXT_MISMATCH','token selection bound')
        h.check(poll(h,'feed-changed-limit',state,3,cursor=empty['next_cursor'],limit=1)['code']=='EVIDENCE_FEED_CONTEXT_MISMATCH','token resource options bound')
        h.check(poll(h,'feed-uppercase',state,3,cursor=empty['next_cursor'].upper())['code']=='EVIDENCE_FEED_CURSOR_INVALID','canonical token encoding')
        d.shutdown()
        state2=h.runtime/'legacy';old=legacy_config(h,'legacy','B',state2,free_port());d=h.start('legacy',old,state2)
        h.check(poll(h,'legacy-does-not-adopt',state2,3)['code']=='EVIDENCE_FEED_SCOPED_POLICY_REQUIRED','no implicit new feed authority in V9')
        d.shutdown()
    case('strict_wire_and_continuation_binding',strict)

    def incremental() -> None:
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'incremental')
        p=poll(h,'incremental-zero',b,limit=1);initial=p['next_cursor']
        hidden=send(h,'incremental-hidden',c,'C')
        one=send(h,'incremental-one',a,'A',data='original')
        first=poll(h,'incremental-first',b,limit=1,cursor=initial)
        h.check([r['operation_id'] for r in first['records']]==[one] and first['next_sequence']==1,'first visible after hidden has position one')
        token=first['next_cursor'];two=send(h,'incremental-two',a,'A')
        correction=operation('incremental-correction')
        revise(h,'incremental-correction',ad.control,'A','B','query/series',correction,one,'changed')
        wait_state(h,a,correction,'ACKED','incremental-correction-ack')
        send(h,'incremental-hidden-later',c,'C')
        second=poll(h,'incremental-second',b,limit=1,cursor=token)
        third=poll(h,'incremental-third',b,limit=1,cursor=second['next_cursor'])
        h.check([r['operation_id'] for r in second['records']+third['records']]==[two,correction],'appends do not stale continuation')
        h.check(third['records'][0]['corrects']==one and third['records'][0]['event']=='CORRECTION_ADMITTED','correction is independently consumable event')
        again=poll(h,'incremental-replay',b,limit=1,cursor=initial)
        h.check(again['records']==first['records'],'earlier event bytes unchanged by later correction')
        h.check(hidden not in json.dumps(third),'hidden record absent')
        before=(b/'state.journal').read_bytes();next_token=third['next_cursor']
        for i in range(12):
            page=poll(h,'empty-poll-'+str(i),b,limit=1,cursor=next_token);next_token=page['next_cursor']
            h.check(page['records']==[] and page['feed_work']['index_records_visited']==0,'empty poll has zero record visits')
        h.check((b/'state.journal').read_bytes()==before,'successful and empty feeds do not mutate journal')
        h.run('feed-compact',['compact','--control',str(bd.control)])
        h.check(poll(h,'after-compact-token',b,limit=1,cursor=next_token)['caught_up'],'compaction preserves live token')
        tail=poll(h,'adopt-tail',b,start='now',limit=1)
        h.check(tail['records']==[] and tail['next_sequence']==3,'tail initialization adopts exact visible boundary')
        extra=send(h,'incremental-extra',a,'A','query/other','metadata only')
        nextpage=poll(h,'after-tail',b,limit=1,cursor=tail['next_cursor'])
        h.check([r['operation_id'] for r in nextpage['records']]==[extra],'tail token reads later metadata domain')
        payload=poll(h,'payload-domain-subset',b,payload='yes')
        h.check(len(payload['records'])==3 and extra not in json.dumps(payload),'payload feed omits metadata-only domain')
        h.check(poll(h,'hidden-filter-empty',b,issuer='C')['records']==[],'filters do not grant access')
        # Full-size arbitrary binary source; feed returns prefix and explicit continuation flag.
        raw=bytes(range(256))*234+bytes(range(96));path=h.work/'payload.bin';path.write_bytes(raw)
        op=operation('large-feed-payload')
        h.run('large-feed-submit',['submit','--control',str(ad.control),'--node','A','--peer','B','--scope','query/series','--operation',op,'--payload-file',str(path)])
        wait_state(h,a,op,'ACKED','large-feed-ack')
        bounded=poll(h,'payload-prefix',b,payload='yes',payload_length=16384)
        last=bounded['records'][-1]
        h.check(bytes.fromhex(last['payload_hex'])==raw[:16384] and last['payload_more'],'binary prefix bounded, not complete-payload claim')
        # Start at last small event with same tight byte options; failing row is never skipped.
        p=poll(h,'tight-first',b,payload='yes',payload_length=16384,max_bytes=4096,limit=1)
        for i in range(2):p=poll(h,'tight-step-'+str(i),b,payload='yes',payload_length=16384,max_bytes=4096,limit=1,cursor=p['next_cursor'])
        err=poll(h,'tight-large-row',b,3,payload='yes',payload_length=16384,max_bytes=4096,limit=1,cursor=p['next_cursor'])
        h.check(err['code']=='EVIDENCE_FEED_PAGE_TOO_SMALL','oversized row does not advance token')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('append_corrections_replay_bounds_and_observational_polling',incremental)

    def principals() -> None:
        if os.geteuid()!=0:raise RuntimeError('real UID laboratory case requires root')
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'principals',extra=True)
        one=send(h,'principals-a',a,'A');c1=send(h,'principals-c',c,'C');other=send(h,'principals-other',a,'A','query/other')
        expose_control_for_uid(b)
        delegated=poll(h,'real-uid-feed',b,uid=UID,limit=1)
        h.check(delegated['principal_uid']==UID and delegated['records'][0]['operation_id']==c1,'actual UID sees its own domain')
        body=poll(h,'real-uid-payload',b,uid=UID,payload='yes')
        h.check([r['operation_id'] for r in body['records']]==[other],'metadata-only domain not in payload feed')
        h.check(poll(h,'real-uid-class-denial',b,3,uid=SECOND_UID,payload='yes')['code']=='LOCAL_CONTROL_CLASS_DENIED','actual metadata-only UID cannot read payload')
        h.check(poll(h,'real-uid-token-transfer',b,3,limit=1,cursor=delegated['next_cursor'])['code']=='EVIDENCE_FEED_CONTEXT_MISMATCH','token cannot transfer to owner UID')
        owner=poll(h,'owner-before-revocation',b,limit=1)
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as slow:
            slow.settimeout(6);slow.connect(str(bd.control));wire=wire_feed();frame=struct.pack('!I',len(wire))+wire
            slow.sendall(frame[:3]);time.sleep(.05)
            narrowed=candidate(h,bc,'feed-narrow','principals-b-g2',lambda s:s.replace(f'evidence_read={os.geteuid()},A,query/series,PAYLOAD\n','').replace(f'evidence_read={os.geteuid()},A,query/other,METADATA',f'evidence_read={os.geteuid()},A,query/other,PAYLOAD'))
            activate(h,'feed-live-narrow',b,narrowed)
            slow.sendall(frame[3:]);slow.shutdown(socket.SHUT_WR)
            n=struct.unpack('!I',receive_exact(slow,4))[0];response=receive_exact(slow,n);result=json.loads(response[5:])
            h.check(response[4]==0 and [r['operation_id'] for r in result['records']]==[other],'slow connection reauthorizes after complete request')
        h.check(poll(h,'owner-old-policy-token',b,3,limit=1,cursor=owner['next_cursor'])['code']=='EVIDENCE_FEED_CONTEXT_MISMATCH','accepted policy change requires explicit reset')
        h.check(poll(h,'delegated-old-policy-token',b,3,uid=UID,limit=1,cursor=delegated['next_cursor'])['code']=='EVIDENCE_FEED_CONTEXT_MISMATCH','configuration binds even unaffected principal token')
        h.check(one not in json.dumps(poll(h,'narrowed-fresh',b)),'fresh feed does not recover revoked domain')
        (b/'control.sock').chmod(0o600);b.chmod(0o700)
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('real_uid_binding_and_live_reauthorization',principals)

    def concurrent_case() -> None:
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'concurrent')
        initial=poll(h,'concurrent-tail',b,start='now',limit=2);token=initial['next_cursor'];observed=[]
        def writer(issuer: str,i: int)->str:return send(h,f'feed-write-{issuer}-{i}',a if issuer=='A' else c,issuer,data=str(i))
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            writes=[pool.submit(writer,issuer,i) for i in range(8) for issuer in ['A','C']]
            for i in range(12):
                page=poll(h,f'concurrent-poll-{i}',b,limit=2,cursor=token);token=page['next_cursor'];observed+=page['records']
                if all(f.done() for f in writes) and page['caught_up']:break
                time.sleep(.01)
            ids=[f.result() for f in writes]
        for i in range(10):
            page=poll(h,f'settled-poll-{i}',b,limit=2,cursor=token);token=page['next_cursor'];observed+=page['records']
            if page['caught_up']:break
        h.check(len(observed)==8 and {r['operation_id'] for r in observed}==set(ids[::2]),'no missing or multiplied visible admissions during writers')
        h.check([r['sequence'] for r in observed]==list(range(1,9)),'no hidden admission gaps during concurrency')
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            readers=[pool.submit(poll,h,f'independent-reader-{i}',b,limit=2,cursor=initial['next_cursor']) for i in range(4)]
            pages=[p.result() for p in readers]
        h.check(all(p['records']==pages[0]['records'] for p in pages),'replayed token supports independent readers, not a consume-once server cursor')
        h.run('feed-quiesce',['quiesce','--control',str(bd.control),'--reason','feed observer'])
        journal=(b/'state.journal').read_bytes()
        poll(h,'quiesced-feed',b,limit=2,cursor=token)
        h.check((b/'state.journal').read_bytes()==journal,'quiesced feed remains observational')
        bd.shutdown();bd=h.start('feed-restart',bc,b)
        h.check(poll(h,'restart-token-reset',b,3,limit=2,cursor=token)['code']=='EVIDENCE_FEED_CURSOR_INVALID','restart explicitly invalidates prior tokens')
        fresh=poll(h,'restart-fresh',b)
        h.check({r['operation_id'] for r in fresh['records']}==set(ids[::2]),'explicit replay after restart retains operation identities')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('concurrent_consumers_and_restart_reset',concurrent_case)

    def maintenance() -> None:
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'maintenance')
        one=send(h,'maintenance-one',a,'A');send(h,'maintenance-hidden',c,'C')
        corrected=operation('maintenance-correction');revise(h,'maintenance-correction',ad.control,'A','B','query/series',corrected,one,'new')
        wait_state(h,a,corrected,'ACKED','maintenance-correction-ack')
        before=poll(h,'maintenance-before',b,payload='yes');bd.shutdown()
        keys=h.runtime/'feed-keys';keys.mkdir(mode=0o700);key=new_key(h,keys,'feed-state-g1');migrate(h,'feed-migrate',b,key,'B')
        bd=start_keyed(h,'feed-keyed',bc,b,key)
        page=poll(h,'keyed-page',b,limit=1,payload='yes')
        h.run('feed-keyed-compact',['compact','--control',str(bd.control)])
        h.check(poll(h,'keyed-next',b,limit=1,payload='yes',cursor=page['next_cursor'])['records'][0]['operation_id']==corrected,'same-process keyed compaction preserves feed continuation')
        bd.shutdown()
        crypt=keys/'backup.key';archive=keys/'backup.nob';identity=h.identity('B')
        h.run('feed-backup-key',['backup-key-init','--output',str(crypt),'--generation','feed-backup-g1'])
        h.run('feed-export',['backup-export','--state',str(b),'--node','B','--generation','b-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'feed-restored'
        h.run('feed-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','B','--generation','b-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        relocated=candidate(h,bc,'feed-relocated','feed-relocated-g1',lambda s:s.replace(f'state={b}',f'state={restored}'))
        h.run('feed-relocate',['state-relocate','--state',str(restored),'--node','B','--candidate',str(relocated),'--reason','verified feed restore','--state-auth-key',str(key)])
        bd=start_keyed(h,'feed-restored',relocated,restored,key)
        after=poll(h,'feed-restored-read',restored,payload='yes')
        h.check(after['records']==before['records'],'immutable feed history reconstructed through keyed encrypted restore and relocation')
        h.check(poll(h,'feed-restored-old-token',restored,3,payload='yes',cursor=before['next_cursor'])['code']=='EVIDENCE_FEED_CURSOR_INVALID','restored process cannot pretend token continuity')
        new=send(h,'feed-restored-new',a,'A')
        newpage=poll(h,'feed-restored-continued',restored,payload='yes',cursor=after['next_cursor'])
        h.check([r['operation_id'] for r in newpage['records']]==[new] and newpage['next_sequence']==3,'restored feed continues with new real peer delivery')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('keyed_encrypted_restore_relocation_continuation',maintenance)

    def large() -> None:
        state,allrows=fixture(h,'large-feed',65_540,17,hidden=3_001)
        cfg,d,port=receiver(h,'large-feed',state)
        expected=[r for r in allrows if r['issuer']!='H'];token='';observed=[];timings=[];visited=0;pages=0
        before=(state/'state.journal').read_bytes()
        while True:
            page,elapsed,_=raw_poll(state,limit=128,cursor=token);pages+=1;timings.append(elapsed)
            h.check(page['feed_work']['selection_records_hashed']==0,'large page never hashes history')
            h.check(page['feed_work']['index_records_visited']<=129,'bounded page record visits')
            h.check(page['after_sequence']==len(observed),'exact authorized continuation rank')
            for row in page['records']:
                original=expected[len(observed)]
                h.check(row['sequence']==len(observed)+1,'large feed ordinal')
                h.check(row['operation_id']==original['operation_id'] and row['corrects']==original['corrects'],'independent full ordered history reference')
                observed.append(row)
            visited+=page['feed_work']['index_records_visited'];token=page['next_cursor']
            if page['caught_up']:break
        h.check(len(observed)==65_557,'entire authorized history beyond retired query ceiling')
        empties=[]
        for _ in range(64):
            page,elapsed,_=raw_poll(state,limit=128,cursor=token);token=page['next_cursor'];empties.append(elapsed)
            h.check(page['records']==[] and page['feed_work']['index_records_visited']==0,'large-history empty poll does no record visits')
        h.check((state/'state.journal').read_bytes()==before,'large enumeration and polling are observational')
        ac=legacy_config(h,'large-writer','A',h.runtime/'large-writer',free_port(),[('B',port)]);ad=h.start('large-writer',ac,h.runtime/'large-writer')
        op=send(h,'large-feed-append',h.runtime/'large-writer','A')
        page,increment_time,_=raw_poll(state,limit=128,cursor=token)
        h.check([r['operation_id'] for r in page['records']]==[op] and page['feed_work']['index_records_visited']==1,'single increment visits one record, not historical population')
        (h.output/'LARGE-FEED.json').write_text(json.dumps({'fixture_records':len(allrows),'authorized_records':len(expected),'hidden_records':3001,
            'pages':pages,'selection_records_hashed':0,'index_records_visited':visited,'first_page_seconds':timings[0],
            'median_page_seconds':statistics.median(timings),'empty_polls':len(empties),'empty_record_visits':0,
            'median_empty_poll_seconds':statistics.median(empties),'single_increment_record_visits':1,'single_increment_seconds':increment_time,
            'synthetic_stored_fixture_not_network_scale':True},indent=2)+'\n')
        ad.shutdown();d.shutdown()
    case('large_ordered_feed_and_empty_poll_work',large)

    def expiry() -> None:
        state=h.runtime/'expiry';cfg=scoped_config(h,'expiry','B',state,free_port(),[(os.geteuid(),'A','query/series','PAYLOAD')])
        d=h.start('expiry',cfg,state)
        first=poll(h,'expiry-initial',state)
        began=time.monotonic();time.sleep(150.0)
        renewed=poll(h,'expiry-renewal',state,cursor=first['next_cursor'])
        time.sleep(max(0.0,300.5-(time.monotonic()-began)))
        h.check(poll(h,'expiry-old-token',state,3,cursor=first['next_cursor'])['code']=='EVIDENCE_FEED_CURSOR_EXPIRED','actual monotonic idle expiry')
        continued=poll(h,'expiry-renewed-token',state,cursor=renewed['next_cursor'])
        h.check(continued['caught_up'] and continued['next_sequence']==0,'successful empty polling renews continuation without inventing records')
        (h.output/'EXPIRY.json').write_text(json.dumps({'wall_seconds':time.monotonic()-began,'production_lifetime_ms':300000,
            'old_token_rejected':True,'renewed_token_accepted':True,'clock_bypass_used':False},indent=2)+'\n')
        d.shutdown()
    if selected and 'renewable_monotonic_expiry' in selected:
        case('renewable_monotonic_expiry',expiry)


def main()->int:
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--binary',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--case',action='append');args=parser.parse_args()
    if args.output.exists():parser.error('output must not exist')
    h=Harness(args.binary,args.output);begin=time.time();success=False
    try:cases(h,set(args.case) if args.case else None);success=True
    except BaseException as exc:
        (h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(f'FAIL: {type(exc).__name__}: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_EVIDENCE_FEED_TESTS_V1','status':'PASS' if success else 'FAIL',
            'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),
            'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-begin}
        for name,value in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:
            (h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if success else 1
if __name__=='__main__':raise SystemExit(main())
