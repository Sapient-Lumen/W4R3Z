#!/usr/bin/env python3
"""Native encrypted backups: independent wire encoding, tampering, and continuation.

Cryptography is test scaffolding only. It independently encodes NOBENC01, but
may share OpenSSL as a primitive backend; this is not independent cryptanalysis.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import struct
import subprocess
import time
from typing import Any

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from run_persistent import Harness, free_port, operation
from run_local_administration import v8_config, inspect
from run_authorization_actions import (
    submit_evidence, submit_action, outbox_entry, independent_record, action_payload,
)

MAGIC = b"NOBENC01"
KEY_DOMAIN = b"NATRAV_OVERLAY_BACKUP_KEY_ID_V1"
INFO = b"NATRAV_OVERLAY_BACKUP_AES256GCM_HKDF_V1"


def key_parts(path: Path) -> tuple[bytes, bytes, bytes]:
    raw = path.read_bytes()
    assert raw[:12] == b"NOBKEY01" + struct.pack("!I", 1)
    size = struct.unpack("!H", raw[12:14])[0]
    generation, secret = raw[14:14 + size], raw[14 + size:]
    assert 1 <= size <= 64 and len(secret) == 32
    key_id = hashlib.sha256(KEY_DOMAIN + struct.pack("!H", size) + generation + secret).digest()
    return generation, secret, key_id


def independent_open(raw: bytes, path: Path) -> bytes:
    generation, secret, key_id = key_parts(path)
    assert raw[:20] == MAGIC + struct.pack("!III", 1, 1, 0)
    size = struct.unpack("!H", raw[20:22])[0]
    assert raw[22:22 + size] == generation
    offset = 22 + size
    assert raw[offset:offset + 32] == key_id
    salt, nonce = raw[offset + 32:offset + 64], raw[offset + 64:offset + 76]
    count = struct.unpack("!Q", raw[offset + 76:offset + 84])[0]
    header = raw[:offset + 84]
    assert len(raw) == len(header) + count + 16
    derived = HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=INFO + header).derive(secret)
    return AESGCM(derived).decrypt(nonce, raw[len(header):], header)


def independent_seal(plaintext: bytes, path: Path) -> bytes:
    generation, secret, key_id = key_parts(path)
    salt, nonce = os.urandom(32), os.urandom(12)
    header = (MAGIC + struct.pack("!IIIH", 1, 1, 0, len(generation)) +
              generation + key_id + salt + nonce + struct.pack("!Q", len(plaintext)))
    derived = HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=INFO + header).derive(secret)
    return header + AESGCM(derived).encrypt(nonce, plaintext, header)


def new_key(h: Harness, root: Path, name: str) -> Path:
    path = root / (name + ".key")
    result = h.run("key-" + name, ["backup-key-init", "--output", str(path), "--generation", name])
    assert result is not None
    h.check(result["key_bits"] == 256 and result["purpose"] == "BACKUP_ENCRYPTION", "key purpose is explicit")
    h.check(stat.S_IMODE(path.stat().st_mode) == 0o600, "key mode exact 0600")
    _, secret, key_id = key_parts(path)
    h.check(result["key_id"] == key_id.hex(), "key identifier independently recomputes")
    h.check(secret.hex() not in json.dumps(result), "initializer does not print secret")
    return path


def export(h: Harness, name: str, state: Path, output: Path, key: Path | None,
           signed: bool = True, generation: str = "a-g1") -> dict[str, Any]:
    args = ["backup-export", "--state", str(state), "--node", "A", "--generation", generation,
            "--output", str(output)]
    if key:
        args += ["--encrypt-key", str(key)]
    if signed:
        identity = h.identity("A")
        args += ["--sign-key", str(identity.private_key), "--sign-cert", str(identity.certificate)]
    result = h.run(name, args, timeout=30)
    assert result is not None
    return result


def verify(h: Harness, label: str, archive: Path, key: Path | None, expected: int = 0,
           extra: list[str] | None = None) -> dict[str, Any]:
    args = ["backup-verify", "--input", str(archive)]
    if key:
        args += ["--decrypt-key", str(key)]
    result = h.run(label, args + (extra or []), expected=expected, timeout=30)
    assert result is not None
    return result


def empty_state(h: Harness, root: Path) -> Path:
    state = root / "state"
    inspect(h, "empty-state", state, "A")
    return state


def run_suite(h: Harness, selected: set[str] | None) -> None:
    def case(name: str, fn: Any) -> None:
        if selected is None or name in selected:
            h.case(name, fn)

    def key_safety_and_racing_publication() -> None:
        root = h.runtime / "key-safety"
        root.mkdir(mode=0o700)
        key = new_key(h, root, "g1")
        before = key.read_bytes()
        denied = h.run("no-key-overwrite", ["backup-key-init", "--output", str(key), "--generation", "g2"], expected=3)
        h.check(denied is not None and denied["code"] == "BACKUP_KEY_EXISTS", "existing key never overwritten")
        h.check(key.read_bytes() == before, "key bytes remain unchanged")
        link = root / "linked"
        link.symlink_to(root, target_is_directory=True)
        bad = h.run("key-parent-symlink", ["backup-key-init", "--output", str(link / "bad.key"), "--generation", "g1"], expected=3)
        h.check(bad is not None and bad["code"] == "BACKUP_KEY_PATH_INVALID", "symlink ancestry denied")
        target = root / "race.key"
        def contender(n: int) -> subprocess.CompletedProcess[str]:
            return subprocess.run([str(h.binary), "backup-key-init", "--output", str(target),
                                   "--generation", f"race-{n}"], text=True, capture_output=True, timeout=10)
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(contender, range(8)))
        h.check(sum(p.returncode == 0 for p in results) == 1, "one of eight concurrent initializers publishes")
        h.check(all(p.returncode in (0, 3) for p in results), "other initializers fail closed")
        for index, result in enumerate(results):
            h.commands.append({"label": f"key-race-{index}", "returncode": result.returncode,
                               "stdout": result.stdout, "stderr": result.stderr})
        h.check(not list(root.glob(".natrav-backup-key-*")), "normal race cleans staging files")
        state = empty_state(h, root)
        archive = root / "good.nob"
        export(h, "safety-export", state, archive, key)
        key.chmod(0o640)
        denied = verify(h, "group-readable-key", archive, key, 3)
        h.check(denied["code"] == "BACKUP_KEY_FILE_UNSAFE", "group-readable key rejected")
        key.chmod(0o600)
        hard = root / "hard.key"
        os.link(key, hard)
        denied = verify(h, "hardlinked-key", archive, key, 3)
        h.check(denied["code"] == "BACKUP_KEY_FILE_UNSAFE", "hardlinked key rejected")
        hard.unlink()
        badkey = root / "trailing.key"
        badkey.write_bytes(before + b"trailing")
        badkey.chmod(0o600)
        verify(h, "trailing-key", archive, badkey, 3)
        fifo = root / "fifo.key"
        os.mkfifo(fifo, 0o600)
        verify(h, "fifo-key-no-block", archive, fifo, 3)
        verify(h, "safety-final-good", archive, key)
    case("key_safety_and_racing_publication", key_safety_and_racing_publication)

    def independent_wire_and_no_plaintext_verification_files() -> None:
        root = h.runtime / "independent"
        root.mkdir(mode=0o700)
        key = new_key(h, root, "wire-g1")
        state = empty_state(h, root)
        plain, encrypted = root / "plain.nob", root / "encrypted.nob"
        old = export(h, "plain-export", state, plain, None)
        sealed = export(h, "wire-export", state, encrypted, key)
        decrypted = independent_open(encrypted.read_bytes(), key)
        h.check(decrypted[:8] == b"NOBACK01", "independent decoder opens native envelope")
        h.check(sealed["encrypted"] and sealed["encryption_authenticated"], "encryption claims explicit")
        h.check(sealed["state_authentication"] == "UNKEYED", "encryption is not falsely keyed journal authenticity")
        h.check(not old["encrypted"], "legacy plaintext never relabeled encrypted")
        independently_made = root / "python-sealed.nob"
        independently_made.write_bytes(independent_seal(plain.read_bytes(), key))
        independently_made.chmod(0o600)
        trusted = ["--trusted-cert", str(h.identity("A").certificate), "--require-signature", "yes"]
        native = verify(h, "native-opens-python-envelope", independently_made, key, extra=trusted)
        h.check(native["backup_id"] == old["backup_id"] and native["trusted_signer"], "native decoder verifies independently sealed signed inner backup")
        h.check(b"NOBACK01" not in encrypted.read_bytes(), "inner backup header not exposed")
        h.check(h.identity("A").certificate.read_bytes() not in encrypted.read_bytes(), "certificate is inside encryption")
        # Watch even transient /tmp creations, not just paths remaining afterward.
        libc = ctypes.CDLL(None, use_errno=True)
        descriptor = libc.inotify_init1(os.O_NONBLOCK | os.O_CLOEXEC)
        h.check(descriptor >= 0, "inotify available for temporary-file observation")
        try:
            h.check(libc.inotify_add_watch(descriptor, b"/tmp", 0x100 | 0x80) >= 0, "watch /tmp creation")
            verify(h, "verify-no-plaintext-files", encrypted, key, extra=trusted)
            try:
                events = os.read(descriptor, 65536)
            except BlockingIOError:
                events = b""
            h.check(b"natrav-overlay-backup-verify-" not in events, "verification creates no prior plaintext checkpoint workspace")
        finally:
            os.close(descriptor)
        # Valid encryption cannot make an invalid inner state valid.
        malformed = root / "authenticated-invalid-inner.nob"
        malformed.write_bytes(independent_seal(b"NOBACK01" + b"\0" * 100, key))
        malformed.chmod(0o600)
        verify(h, "authenticated-invalid-inner", malformed, key, 3)
        again = root / "again.nob"
        export(h, "independent-repeat", state, again, key)
        n = len(key_parts(key)[0])
        h.check(encrypted.read_bytes()[54+n:98+n] != again.read_bytes()[54+n:98+n], "repeat export changes random salt and nonce")
    case("independent_wire_and_no_plaintext_verification_files", independent_wire_and_no_plaintext_verification_files)

    def authenticated_but_invalid_checkpoint() -> None:
        root = h.runtime / "semantic-checkpoint"
        root.mkdir(mode=0o700)
        key = new_key(h, root, "semantic-g1")
        state = empty_state(h, root)
        plain = root / "unsigned-plain.nob"
        export(h, "semantic-plain", state, plain, None, signed=False)
        original = plain.read_bytes()
        position = 36
        for _ in range(2):
            length = struct.unpack("!H", original[position:position+2])[0]
            position += 2 + length
        checkpoint_hash_offset = position + 32
        identity_offset = position + 144
        checkpoint_offset = identity_offset + 32
        original_checkpoint = original[checkpoint_offset:]
        h.check(original_checkpoint[:4] == b"NOJ1" and original_checkpoint[8] == 18, "independent checkpoint frame location")

        def rebuild(checkpoint: bytes) -> bytes:
            prefix = bytearray(original[:checkpoint_offset])
            prefix[checkpoint_hash_offset:checkpoint_hash_offset+32] = hashlib.sha256(checkpoint).digest()
            prefix[position+64:position+72] = struct.pack("!Q", len(checkpoint))
            id_input = (b"NATRAV_OVERLAY_BACKUP_ID_V1\0" + prefix[8:12] + b"\0" +
                        prefix[16:identity_offset-4])
            prefix[identity_offset:identity_offset+32] = hashlib.sha256(id_input).digest()
            return bytes(prefix) + checkpoint

        # The envelope tag, inner backup ID, and every unkeyed checksum below are
        # valid. Only semantic checkpoint replay can reject these objects.
        wrong_kind = bytearray(original_checkpoint)
        wrong_kind[8] = 1
        wrong_kind[-32:] = hashlib.sha256(b"NATRAV_OVERLAY_JOURNAL_RECORD_V1\0" + wrong_kind[8:-32]).digest()
        logical_bad = bytearray(original_checkpoint)
        logical_bad[14:18] = struct.pack("!I", 99)  # NCP3 storage schema
        logical_bad[-32:] = hashlib.sha256(b"NATRAV_OVERLAY_JOURNAL_RECORD_V1\0" + logical_bad[8:-32]).digest()
        for label, checkpoint in [("non-checkpoint-kind", bytes(wrong_kind)),
                                  ("unknown-checkpoint-schema", bytes(logical_bad)),
                                  ("two-checkpoint-frames", original_checkpoint * 2),
                                  ("checkpoint-tail", original_checkpoint + b"NOJ")]:
            path = root / (label + ".nob")
            path.write_bytes(independent_seal(rebuild(checkpoint), key)); path.chmod(0o600)
            denied = verify(h, "semantic-" + label, path, key, 3)
            h.check(denied["code"] == "JOURNAL_CORRUPT", "authenticated backup still requires strict normal checkpoint semantics")
        verify(h, "unchanged-semantic-control", plain, None)
    case("authenticated_but_invalid_checkpoint", authenticated_but_invalid_checkpoint)

    def tamper_wrong_keys_and_no_downgrade() -> None:
        root = h.runtime / "tamper"
        root.mkdir(mode=0o700)
        key, wrong = new_key(h, root, "tamper-g1"), new_key(h, root, "tamper-g2")
        state = empty_state(h, root)
        archive = root / "valid.nob"
        export(h, "tamper-export", state, archive, key)
        original = archive.read_bytes()
        n = len(key_parts(key)[0])
        auth_offsets = {"tag": len(original)-1, "salt": 54+n, "nonce": 86+n, "ciphertext": 106+n}
        for name, offset in auth_offsets.items():
            damaged = bytearray(original)
            damaged[offset] ^= 1
            path = root / f"bad-{name}.nob"
            path.write_bytes(damaged)
            path.chmod(0o600)
            result = verify(h, f"tamper-{name}", path, key, 3)
            h.check(result["code"] == "BACKUP_AUTHENTICATION_FAILED", f"{name} alteration rejected at AEAD boundary")
            destination = root / f"restore-{name}"
            failure = h.run(f"restore-tampered-{name}", ["backup-restore", "--input", str(path),
                "--destination", str(destination), "--node", "A", "--generation", "a-g1",
                "--decrypt-key", str(key)], expected=3)
            h.check(failure is not None and not destination.exists(), "failed authentication publishes no restore state")
        for name, offset in {"version": 11, "suite": 15, "flags": 19,
                             "generation": 22, "key-id": 22+n, "length": 105+n}.items():
            damaged = bytearray(original)
            damaged[offset] ^= 1
            path = root / f"header-{name}.nob"
            path.write_bytes(damaged); path.chmod(0o600)
            verify(h, "header-" + name, path, key, 3)
        for count in (0, 7, 20, 106+n, len(original)-16, len(original)-1):
            path = root / f"short-{count}.nob"
            path.write_bytes(original[:count]); path.chmod(0o600)
            verify(h, f"truncated-{count}", path, key, 3)
        extra = root / "trailing.nob"
        extra.write_bytes(original + b"extra"); extra.chmod(0o600)
        verify(h, "trailing-envelope", extra, key, 3)
        missing = verify(h, "key-required", archive, None, 3)
        h.check(missing["code"] == "BACKUP_DECRYPTION_KEY_REQUIRED", "no automatic key search")
        wrong_result = verify(h, "wrong-exact-key", archive, wrong, 3)
        h.check(wrong_result["code"] == "BACKUP_ENCRYPTION_KEY_MISMATCH", "exact key identity required")
        plain = root / "plain.nob"
        export(h, "tamper-plain-export", state, plain, None)
        blocked = verify(h, "plaintext-supplied-key", plain, key, 3)
        h.check(blocked["code"] == "BACKUP_ENCRYPTION_REQUIRED", "supplying decrypt key forbids plaintext")
        verify(h, "plaintext-required-encryption", plain, None, 3, ["--require-encryption", "yes"])
        verify(h, "signed-wrong-trust", archive, key, 3, ["--trusted-cert", str(h.identity("B").certificate)])
        unsigned = root / "unsigned.nob"
        export(h, "unsigned-encrypted", state, unsigned, key, signed=False)
        verify(h, "encryption-not-signature", unsigned, key, 3, ["--require-signature", "yes"])
        accepted = verify(h, "unsigned-encrypted-valid", unsigned, key)
        h.check(accepted["encrypted"] and not accepted["signed"] and not accepted["trusted_signer"], "independent trust properties remain distinct")
        destination = root / "occupied"
        destination.mkdir(); (destination / "sentinel").write_text("keep")
        h.run("restore-never-overwrites", ["backup-restore", "--input", str(archive), "--destination", str(destination),
            "--node", "A", "--generation", "a-g1", "--decrypt-key", str(key)], expected=3)
        h.check((destination / "sentinel").read_text() == "keep", "existing destination untouched")
    case("tamper_wrong_keys_and_no_downgrade", tamper_wrong_keys_and_no_downgrade)

    def exact_archive_reencryption() -> None:
        root = h.runtime / "reencrypt"
        root.mkdir(mode=0o700)
        old, new = new_key(h, root, "old"), new_key(h, root, "new")
        state = empty_state(h, root)
        first, second = root / "first.nob", root / "second.nob"
        initial = export(h, "reencrypt-export", state, first, old)
        original_bytes = first.read_bytes()
        signing = ["--trusted-cert", str(h.identity("A").certificate), "--require-signature", "yes"]
        args = ["backup-reencrypt", "--input", str(first), "--output", str(second),
                "--decrypt-key", str(old), "--encrypt-key", str(new)] + signing
        result = h.run("reencrypt-native", args)
        assert result is not None
        h.check(result["backup_id"] == initial["backup_id"], "inner backup identity unchanged")
        h.check(result["previous_encryption_key_generation"] == "old" and result["encryption_key_generation"] == "new", "generation transition explicit")
        h.check(result["trusted_signer"], "original signing identity verified, no signing private key required")
        h.check(first.read_bytes() == original_bytes, "old archive not overwritten or revoked")
        h.check(independent_open(original_bytes, old) == independent_open(second.read_bytes(), new), "entire signed inner container identical")
        verify(h, "reencrypted-new-key", second, new, extra=signing)
        verify(h, "reencrypted-old-key-rejected", second, old, 3)
        verify(h, "old-archive-new-key-rejected", first, new, 3)
        h.run("reencrypt-output-exists", args, expected=3)
        same = root / "same.nob"
        h.run("reencrypt-same-generation", ["backup-reencrypt", "--input", str(first), "--output", str(same),
            "--decrypt-key", str(old), "--encrypt-key", str(old)], expected=3)
        h.check(not same.exists(), "same-generation re-encryption rejected before publication")
    case("exact_archive_reencryption", exact_archive_reencryption)

    def interrupted_drain_encrypted_restore_and_real_continuation() -> None:
        root = h.runtime / "continuation"
        root.mkdir(mode=0o700)
        key = new_key(h, root, "continuation-g1")
        a_state, b_state, c_state = root / "a", root / "b", root / "c"
        a_port, b_port, c_port = free_port(), free_port(), free_port()
        grant = [(os.geteuid(), ["ALL"])]
        ac = v8_config(h, "encrypted-a", "A", a_state, a_port, "a-initial", grant,
                       peers=[("C", c_port)], inbound=["B"], deadline_ms=250)
        ac.write_text(ac.read_text() + "authorize=B,*,ACTION,counter.add\n")
        bc = v8_config(h, "encrypted-b", "B", b_state, b_port, "b-initial", grant, peers=[("A", a_port)])
        cc = v8_config(h, "encrypted-c", "C", c_state, c_port, "c-initial", grant, inbound=["A"])
        a, b = h.start("encrypted-a", ac, a_state), h.start("encrypted-b", bc, b_state)
        action = operation("encrypted-completed-action")
        evidence = operation("encrypted-evidence")
        pending = operation("encrypted-pending")
        marker = "private-checkpoint-payload-0502-DO-NOT-EXPOSE"
        submit_evidence(h, "encrypted-evidence-submit", b.control, "B", "A", "admin/test", evidence, marker)
        submit_action(h, "encrypted-action-submit", b.control, "B", "A", action, 7)
        h.wait("counter effect complete", lambda: h.status("encrypted-action-status", a_state)["actions"]["counter_value"] == 7)
        h.wait("evidence acknowledged", lambda: outbox_entry(h.status("encrypted-b-status", b_state), evidence)["status"] == "ACKED")
        submit_evidence(h, "encrypted-pending-submit", a.control, "A", "C", "admin/test", pending, marker)
        h.run("encrypted-compact", ["compact", "--control", str(a.control), "--deadline-ms", "30000"], timeout=35)
        drain_args = ["drain-shutdown", "--control", str(a.control), "--reason", "encrypted recovery test",
                      "--drain-deadline-ms", "30000", "--deadline-ms", "35000"]
        client = subprocess.Popen([str(h.binary), *drain_args], text=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=os.environ.copy())
        try:
            h.wait("drain visible", lambda: h.status("encrypted-drain-status", a_state)["lifecycle"]["mode"] == "DRAINING")
            a.kill()
            stdout, stderr = client.communicate(timeout=8)
            h.commands.append({"label": "encrypted-interrupted-drain", "args": drain_args,
                "returncode": client.returncode, "stdout": stdout, "stderr": stderr})
            h.check(client.returncode != 0, "interrupted drain never reports clean completion")
        finally:
            if client.poll() is None:
                client.kill(); client.wait(timeout=5)
        before = inspect(h, "encrypted-before-backup", a_state, "A")
        archive = root / "recovery.nob"
        result = export(h, "encrypted-rich-export", a_state, archive, key)
        h.check(marker.encode() not in archive.read_bytes(), "payload concealed in exported bytes")
        h.check(str(a_state).encode() not in archive.read_bytes(), "sensitive owner paths encrypted")
        dest = root / "relocated"
        restore = h.run("encrypted-rich-restore", ["backup-restore", "--input", str(archive),
            "--destination", str(dest), "--node", "A", "--generation", "a-g1", "--decrypt-key", str(key),
            "--require-encryption", "yes", "--require-signature", "yes", "--trusted-cert", str(h.identity("A").certificate)], timeout=30)
        assert restore is not None
        after = inspect(h, "encrypted-restored-inspect", dest, "A")
        h.check(before["storage"]["logical_state_digest"] == after["storage"]["logical_state_digest"] == result["logical_state_digest"], "all logical state unchanged by encrypted restore")
        relocated = h.work / "encrypted-a-relocated.conf"
        relocated.write_text(ac.read_text().replace(f"state={a_state}", f"state={dest}").replace("runtime_generation=a-initial", "runtime_generation=a-relocated"))
        h.run("encrypted-state-relocate", ["state-relocate", "--state", str(dest), "--node", "A",
            "--candidate", str(relocated), "--reason", "promote authenticated decrypted backup"], timeout=30)
        moved = h.start("encrypted-a-restored", relocated, dest)
        recovered = h.status("encrypted-restored-status", dest)
        h.check(recovered["lifecycle"]["mode"] == "QUIESCED" and recovered["lifecycle"]["interrupted_drain"], "interrupted drain survives encrypted restore and relocation")
        h.check(recovered["actions"]["counter_value"] == 7, "counter effect reconstructed once")
        c = h.start("encrypted-c", cc, c_state)
        h.run("encrypted-resume", ["resume", "--control", str(moved.control), "--reason", "resume restored owned node"])
        h.wait("pending work reaches real node C", lambda: outbox_entry(h.status("encrypted-resumed-status", dest), pending)["status"] == "ACKED", timeout=15)
        reply = independent_record(h, a_port, "B", "B", "A", action, "actions/counter.add/v1", action_payload(7))
        h.check(reply["kind"] == "receipt" and reply["disposition"] == 2, "restored action replay returns duplicate receipt")
        h.check(h.status("encrypted-after-replay", dest)["actions"]["counter_value"] == 7, "replay does not repeat effect")
        fresh = operation("encrypted-new-work")
        submit_evidence(h, "encrypted-new-submit", moved.control, "A", "C", "admin/test", fresh, "after restore")
        h.wait("new work delivered", lambda: outbox_entry(h.status("encrypted-new-status", dest), fresh)["status"] == "ACKED")
        h.run("encrypted-recompact", ["compact", "--control", str(moved.control), "--deadline-ms", "30000"], timeout=35)
        moved.shutdown(); b.shutdown(); c.shutdown()
        c_snapshot = inspect(h, "encrypted-c-offline", c_state, "C")
        h.check(c_snapshot["inbound"]["count"] == 2, "recipient admits two distinct operations once")
        final = inspect(h, "encrypted-final-offline", dest, "A")
        second = root / "second.nob"
        export(h, "encrypted-second-export", dest, second, key)
        verified = verify(h, "encrypted-second-verify", second, key)
        h.check(verified["logical_state_digest"] == final["storage"]["logical_state_digest"], "continued state compacts and re-exports exactly")
    case("interrupted_drain_encrypted_restore_and_real_continuation", interrupted_drain_encrypted_restore_and_real_continuation)

    def publication_kill_boundaries() -> None:
        root = h.runtime / "publication"
        root.mkdir(mode=0o700)
        key = new_key(h, root, "publication-g1")
        state = empty_state(h, root)
        def kill_at(label: str, args: list[str], point: str, destination: Path,
                    present: bool, contains_secret: bool) -> None:
            err = h.logs / (label + ".stderr.txt")
            env = dict(os.environ, **{f"NATRAV_OVERLAY_TEST_{point}_MS": "10000"})
            with err.open("w") as stderr:
                child = subprocess.Popen([str(h.binary), *args], stdout=subprocess.DEVNULL, stderr=stderr, env=env)
                try:
                    h.wait(label + " reached publication boundary", lambda: ("BACKUP_TEST_PAUSE " + point) in err.read_text(), timeout=8)
                    h.check(destination.exists() == present, "destination publication boundary exact")
                    pattern = ".natrav-backup-key-*" if contains_secret else ".natrav-overlay-backup-*.tmp"
                    staged = list(root.glob(pattern))
                    for path in staged:
                        h.check(stat.S_IMODE(path.stat().st_mode) == 0o600, "staging mode exact owner-only")
                        if not contains_secret:
                            h.check(path.read_bytes().startswith(MAGIC), "archive staging contains ciphertext, not plaintext")
                    child.kill(); child.wait(timeout=5)
                    h.check(child.returncode == -signal.SIGKILL, "actual process hard kill")
                    h.commands.append({"label": label, "args": args, "returncode": child.returncode, "test_point": point})
                finally:
                    if child.poll() is None:
                        child.kill(); child.wait(timeout=5)
            for path in root.glob(".natrav-backup-key-*"):
                path.unlink()
            for path in root.glob(".natrav-overlay-backup-*.tmp"):
                path.unlink()
        for before in (True, False):
            stage = "BEFORE" if before else "AFTER"
            target = root / f"kill-key-{stage}.key"
            kill_at(f"kill-key-{stage}", ["backup-key-init", "--output", str(target), "--generation", f"kill-{stage}"],
                    f"KEY_{stage}_PUBLISH", target, not before, True)
            if before:
                h.run("retry-killed-key", ["backup-key-init", "--output", str(target), "--generation", "retry-key"])
            key_parts(target)
            output = root / f"kill-backup-{stage}.nob"
            args = ["backup-export", "--state", str(state), "--node", "A", "--generation", "a-g1", "--output", str(output), "--encrypt-key", str(key)]
            kill_at(f"kill-archive-{stage}", args, f"ARCHIVE_{stage}_PUBLISH", output, not before, False)
            if before:
                h.run("retry-killed-archive", args)
            verify(h, "published-archive-verifies-" + stage, output, key)
    case("publication_kill_boundaries", publication_kill_boundaries)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, default=Path("node/bin/natrav-overlay"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append", choices=[
        "key_safety_and_racing_publication", "independent_wire_and_no_plaintext_verification_files",
        "authenticated_but_invalid_checkpoint", "tamper_wrong_keys_and_no_downgrade", "exact_archive_reencryption",
        "interrupted_drain_encrypted_restore_and_real_continuation", "publication_kill_boundaries"])
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not already exist")
    h = Harness(args.binary, args.output)
    start, code = time.time(), 1
    try:
        run_suite(h, set(args.case) if args.case else None)
        code = 0
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=os.sys.stderr)
    finally:
        h.cleanup()
        summary = {"format": "NATRAV_OVERLAY_ENCRYPTED_BACKUP_TESTS_V1", "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(c["status"] == "PASS" for c in h.cases), "cases_total": len(h.cases),
            "assertions": h.assertions, "commands": len(h.commands), "elapsed_seconds": time.time()-start}
        for name, obj in [("SUMMARY.json", summary), ("CASES.json", h.cases), ("COMMANDS.json", h.commands)]:
            (h.output / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary, sort_keys=True))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
