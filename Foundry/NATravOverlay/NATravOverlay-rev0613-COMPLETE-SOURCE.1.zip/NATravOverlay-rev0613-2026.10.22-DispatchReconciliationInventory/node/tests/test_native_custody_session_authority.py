#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[2]
node = (root / "node/src/node.cpp").read_text()
protocol_h = (root / "node/src/protocol.hpp").read_text()
protocol_c = (root / "node/src/protocol.cpp").read_text()
policy_h = (root / "node/src/custody_session_policy.hpp").read_text()
policy_c = (root / "node/src/custody_session_policy.cpp").read_text()
config_c = (root / "node/src/config.cpp").read_text()
runtime_c = (root / "node/src/runtime.cpp").read_text()
service_c = (root / "node/src/custody_session_service.cpp").read_text()
service_h = (root / "node/src/custody_session_service.hpp").read_text()
main_c = (root / "node/src/main.cpp").read_text()
tls_c = (root / "node/src/tls.cpp").read_text()
export_body = service_c.split("run_custody_session_export", 1)[1].split(
    "int run_custody_session_server", 1)[0]
prepare_body = service_c.split(
    "PreparedSend prepare_send_bytes", 1)[1].split(
    "PreparedSend prepare_send(", 1)[0]
committed_attempt_body = service_c.split(
    "CustodySessionServiceResult perform_committed_attempt", 1)[1].split(
    "struct OwnerDispatchRecord", 1)[0]
dispatch_body = service_c.split(
    "CustodySessionServiceResult CustodyOwnerDispatcher::dispatch_once", 1)[1].split(
    "CustodySessionServiceResult run_custody_session_send", 1)[0]
standalone_send_body = service_c.split(
    "CustodySessionServiceResult run_custody_session_send", 1)[1].split(
    "CustodySessionServiceResult run_custody_session_status", 1)[0]

required = {
    "offer variant": "CustodyTransferOffer" in protocol_h,
    "acceptance variant": "CustodyTransferAcceptance" in protocol_h,
    "offer kind": "kCustodyTransferOfferKind = 9U" in protocol_c,
    "acceptance kind": "kCustodyTransferAcceptanceKind = 10U" in protocol_c,
    "bounded wire": "kMaximumCustodySessionWireBytes" in protocol_h,
    "typed unconfigured rejection": "CUSTODY_SESSION_NOT_CONFIGURED" in node,
    "V22 header": "NATRAV_OVERLAY_CONFIG_V22" in config_c,
    "V22 record": "custody_service_hex" in config_c,
    "downgrade rejection": "CONFIG_CUSTODY_SESSION_DOWNGRADE" in runtime_c,
    "history preservation": "require_custody_session_history_preserved" in runtime_c,
    "exact grant resolution": "resolve_custody_session_grant" in config_c,
    "explicit enabled route prerequisite": "PeerRouteState::enabled" in config_c,
    "shared rule does not commit route": all(
        forbidden not in policy_h and forbidden not in policy_c
        for forbidden in ("route_id", "carrier", "listen_host", "listen_port")
    ),
    "native sender opens reusable NOS1 session":
        "OutboundPeerSession::open" in service_c and
        ".exchange_message(" in service_c,
    "native receiver uses secure peer callback":
        "listen_transport(" in service_c and
        "handle_secure_peer_connection(" in service_c and
        "const CustodyTransferOffer& offer" in service_c,
    "no private socket or TLS stack": all(token not in service_c for token in (
        "::socket(", "::connect(", "::accept(", "SSL_CTX", "SSL_read",
        "SSL_write", "send_frame", "recv_frame")),
    "obsolete private implementation removed":
        "namespace natrav_custody_service_v1" not in main_c and
        "NATRAV_CUSTODY_SERVICE_POLICY_V1" not in main_c,
    "offer and attempt durable before carrier":
        'persist_exact(directory / "offer.bin"' in prepare_body and
        "OutboundPeerSession::open" not in prepare_body and
        'atomic_write_text(prepared.directory / "attempts"' in dispatch_body and
        dispatch_body.index('atomic_write_text(prepared.directory / "attempts"') <
            dispatch_body.index('perform_committed_attempt(') and
        'atomic_write_text(prepared.directory / "attempts"' in standalone_send_body and
        standalone_send_body.index('atomic_write_text(prepared.directory / "attempts"') <
            standalone_send_body.index('OutboundPeerSession::open') and
        "OutboundPeerSession::open" in committed_attempt_body,
    "acceptance durable before response":
        'persist_exact(directory / "acceptance.bin"' in service_c and
        'signed_acceptance = std::move(acceptance.wire)' in service_c and
        service_c.index('persist_exact(directory / "acceptance.bin"') <
            service_c.index('signed_acceptance = std::move(acceptance.wire)'),
    "request identity covers complete offer":
        "domain_message(kOfferRequestDomain, offer.wire)" in service_c,
    "offer-only crash metadata reconstruction":
        "case_envelope_sha256(" in service_c and
        "Reconstruct only from the complete, canonical signed offer" in service_c and
        "parse_offer(read_regular_file(" in service_c and
        "atomic_write_text(envelope_path" in service_c,
    "exact DER certificate evidence":
        "peer_certificate_sha256" in service_c and
        "tls_certificate_sha256" in tls_c,
    "single executable command surface": all(command in main_c for command in (
        "custody-service-v1-send", "custody-service-v1-serve",
        "custody-service-v1-status", "custody-service-v1-export",
        "custody-service-v1-version")),
    "owner retained export is current-custodian constrained":
        "run_custody_session_export" in service_c and
        "retained export requires the exact current nonterminal custodian" in service_c and
        "EXPORTED_RETAINED_CUSTODY_NOT_FORWARDED" in service_c and
        "publish_handoff_file(options.output, encoded)" in service_c,
    "retained export uses exact authenticated bytes":
        'directory / "offer.bin"' in export_body and
        'directory / "acceptance.bin"' in export_body and
        "validate_offer(authority, message, true)" in export_body and
        "validate_acceptance(authority" in export_body,
    "retained export does not repair or mutate custody journal":
        "import_bundle(" not in export_body and
        "commit_acceptance(" not in export_body and
        "require_case(state, envelope_sha256)" in export_body and
        "local_index + 1U < custody.envelope.route.size()" in export_body,
    "all durability cutpoint pauses are external-only": all(
        f'custody_session_test_pause("{phase}")' in service_c
        for phase in (
            "BEFORE_OFFER_PUBLICATION", "AFTER_OFFER_PUBLICATION",
            "BEFORE_ENVELOPE_INDEX_RECONSTRUCTION",
            "AFTER_ENVELOPE_INDEX_RECONSTRUCTION",
            "BEFORE_ATTEMPT_INCREMENT", "AFTER_ATTEMPT_INCREMENT",
            "BEFORE_RECEIVER_ACCEPTANCE_PUBLICATION",
            "AFTER_RECEIVER_ACCEPTANCE_PUBLICATION",
            "BEFORE_RECEIVER_JOURNAL_COMMIT",
            "AFTER_RECEIVER_JOURNAL_COMMIT",
            "BEFORE_SENDER_ACCEPTANCE_PUBLICATION",
            "AFTER_SENDER_ACCEPTANCE_PUBLICATION",
            "BEFORE_SENDER_JOURNAL_COMMIT",
            "AFTER_SENDER_JOURNAL_COMMIT",
        )) and "NATRAV_OVERLAY_TEST_CUSTODY_SESSION_" in service_c and
        "custody-session-crash" not in main_c and
        "custody-session-fault" not in main_c,
    "explicit configured but nonautomatic relay markers":
        r'\"configured_custody_relay\":true' in main_c and
        r'\"automatic_route_relay\":false' in main_c and
        r'\"open_relay\":false' in main_c,
    "service is built into ordinary binary":
        "NATIVE_DURABLE_CUSTODY_SESSION_SERVICE_V1" in service_h,
}

session_marker = "const auto* custody_offer ="
legacy_marker = "if (!looks_like_peer_session_frame(first_payload))"
if session_marker not in node or legacy_marker not in node:
    required["native NOS1-only dispatch"] = False
else:
    legacy_begin = node.index(legacy_marker)
    session_begin = node.index(session_marker)
    required["native NOS1-only dispatch"] = (
        session_begin > legacy_begin and
        "CustodyTransferOffer" not in node[legacy_begin:session_begin]
    )

failed = [name for name, passed in required.items() if not passed]
if failed:
    raise SystemExit("FAIL: " + ", ".join(failed))
print(f"PASS: {len(required)} native custody authority checks")
