#!/usr/bin/env python3
"""Detached-custody constrained authenticated-state opening validation."""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time
from typing import Any

from run_persistent import Harness, free_port, operation
from run_authenticated_recovery import setup, audit, incomplete_next, recover_args
from run_state_authentication import KeyedDaemon, inspect, new_key
from run_state_expectations import selector, append
from run_state_head_custody import parse_record, exact_args
from run_live_configuration import v7
from run_relocation import relocated_config, copy_identity
from run_backup_correlated_stop_audit import backup_key

CASES = (
    "strict_adapter_and_inspection",
    "stale_divergent_and_old_pair",
    "finite_replacement_race",
    "startup_compaction_and_explicit_advance",
    "startup_replacement_race",
    "rotation_and_recovery",
    "backup_restore_relocation_and_audit",
)


def nonzero_digest(byte: int) -> str:
    return (bytes([byte]) * 32).hex()


def create_anchor(h: Harness, label: str, directory: Path, head: str,
                  *, domain: str = "primary-operations", generation: int = 1,
                  filename: str = "A.head", node: str = "A") -> tuple[Path, dict[str, Any]]:
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    path = directory / filename
    value = h.run(label, ["state-head-custody-create", "--record", str(path),
        "--node", node, "--domain", domain, "--generation", str(generation),
        "--head", head])
    assert value
    record = parse_record(path.read_bytes())
    return path, record


def constraint_args(path: Path, record: dict[str, Any]) -> list[str]:
    return ["--expected-state-head-custody", str(path),
        "--expected-custody-domain", record["domain"],
        "--expected-custody-generation", str(record["generation"]),
        "--expected-custody-digest", record["record_digest"]]


def advance_anchor(h: Harness, label: str, path: Path, old: dict[str, Any],
                   new_head: str, new_generation: int) -> dict[str, Any]:
    value = h.run(label, ["state-head-custody-advance", *exact_args(path, old),
        "--new-generation", str(new_generation), "--new-head", new_head])
    assert value
    return parse_record(path.read_bytes())


def run_with_environment(h: Harness, label: str, args: list[str],
                         environment: dict[str, str], expected: int = 0,
                         timeout: int = 20) -> dict[str, Any] | None:
    started = time.time()
    completed = subprocess.run([str(h.binary), *args], capture_output=True,
        text=True, timeout=timeout, env=dict(os.environ, **environment))
    record = {"label": label, "args": args, "returncode": completed.returncode,
        "stdout": completed.stdout, "stderr": completed.stderr,
        "elapsed_seconds": time.time() - started,
        "environment": sorted(environment)}
    h.commands.append(record)
    (h.logs / f"{len(h.commands):03d}-{label}.stdout.txt").write_text(completed.stdout)
    (h.logs / f"{len(h.commands):03d}-{label}.stderr.txt").write_text(completed.stderr)
    h.check(completed.returncode == expected,
        f"{label}: return {completed.returncode}, expected {expected}; "
        f"stdout={completed.stdout!r} stderr={completed.stderr!r}")
    lines = [line for line in completed.stdout.splitlines() if line.strip()]
    return json.loads(lines[-1]) if lines else None


class CustodyDaemon(KeyedDaemon):
    def __init__(self, h: Harness, name: str, config: Path, state: Path,
                 key: Path, custody: list[str], environment: dict[str, str] | None = None):
        super().__init__(h, name, config, state, key, environment)
        self.custody = custody

    def start(self) -> None:
        self.stdout_file = self.stdout_path.open("w")
        self.stderr_file = self.stderr_path.open("w")
        self.process = subprocess.Popen([str(self.harness.binary), "run",
            "--config", str(self.config), "--state-auth-key", str(self.key),
            *self.custody], stdout=self.stdout_file, stderr=self.stderr_file,
            text=True, env=dict(os.environ, **self.environment))
        try:
            self.harness.wait("custody daemon " + self.name,
                lambda: bool(self.process and self.process.poll() is None and
                    self.control.is_socket() and
                    "RUNTIME_READY" in self.stdout_path.read_text()), 10)
        except BaseException:
            self.cleanup()
            raise AssertionError(self.stdout_path.read_text() + self.stderr_path.read_text())
        self.harness.check(stat.S_IMODE(self.control.stat().st_mode) == 0o600,
            "custody-constrained daemon control mode")


def start_custody_daemon(h: Harness, name: str, config: Path, state: Path,
                         key: Path, custody: list[str]) -> CustodyDaemon:
    daemon = CustodyDaemon(h, name, config, state, key, custody)
    h.daemons.append(daemon)
    daemon.start()
    return daemon


def run_suite(h: Harness, selected: set[str] | None) -> None:
    def case(name: str, fn: Any) -> None:
        if selected is None or name in selected:
            h.case(name, fn)

    def strict_adapter_and_inspection() -> None:
        root, state, key = setup(h, "custody-adapter")
        pin = selector((state / "state.journal").read_bytes(), key)
        record_path, record = create_anchor(h, "adapter-anchor-create",
            root / "anchors", pin, domain="operator.primary", generation=7)
        before = record_path.read_bytes()
        args = constraint_args(record_path, record)
        value = h.run("adapter-inspect", ["inspect", "--state", str(state),
            "--node", "A", "--state-auth-key", str(key), *args])
        assert value
        h.check(value["state_head"]["selector"] == pin and
            value["state_head"]["expectation"] == "MATCH",
            "custody selector reaches the existing exact NASH1 matcher")
        audited = audit(h, "adapter-audit", state, key, extra=args)
        h.check(audited["status"] == "COMPLETE" and
            audited["state_head"]["expectation"] == "MATCH",
            "complete offline audit accepts the exact detached condition")
        h.check(record_path.read_bytes() == before,
            "inspection and audit never advance detached custody")

        mixed = h.run("adapter-mixed-raw", ["inspect", "--state", str(state),
            "--node", "A", "--state-auth-key", str(key),
            "--expected-state-head", pin, *args], expected=3)
        h.check(mixed and mixed["code"] == "STATE_HEAD_EXPECTATION_INVALID",
            "raw and custody expectations are mutually exclusive")
        legacy = h.run("adapter-mixed-legacy", ["state-auth-audit", "--state", str(state),
            "--node", "A", "--state-auth-key", str(key), *args,
            "--expected-root", pin.split(":")[5], "--expected-records", "1"], expected=3)
        h.check(legacy and legacy["code"] == "STATE_HEAD_EXPECTATION_INVALID",
            "custody and legacy root/count alternatives are mutually exclusive")
        for index, key_name in enumerate(("--expected-state-head-custody",
                "--expected-custody-domain", "--expected-custody-generation",
                "--expected-custody-digest")):
            partial = []
            pairs = list(zip(args[::2], args[1::2]))
            for name, value_text in pairs:
                if name != key_name:
                    partial += [name, value_text]
            denied = h.run(f"adapter-partial-{index}", ["inspect", "--state", str(state),
                "--node", "A", "--state-auth-key", str(key), *partial], expected=3)
            h.check(denied and denied["code"] == "STATE_HEAD_CUSTODY_EXPECTATION_REQUIRED",
                "partial custody group never falls back to an unconditioned open")
        wrong_variants = [
            ("domain", ["--expected-state-head-custody", str(record_path),
                "--expected-custody-domain", "operator.secondary",
                "--expected-custody-generation", "7",
                "--expected-custody-digest", record["record_digest"]]),
            ("generation", ["--expected-state-head-custody", str(record_path),
                "--expected-custody-domain", record["domain"],
                "--expected-custody-generation", "6",
                "--expected-custody-digest", record["record_digest"]]),
            ("digest", ["--expected-state-head-custody", str(record_path),
                "--expected-custody-domain", record["domain"],
                "--expected-custody-generation", "7",
                "--expected-custody-digest", nonzero_digest(0x5A)]),
        ]
        for label, wrong in wrong_variants:
            denied = h.run("adapter-wrong-" + label, ["inspect", "--state", str(state),
                "--node", "A", "--state-auth-key", str(key), *wrong], expected=3)
            h.check(denied and denied["code"] == "STATE_HEAD_CUSTODY_EXPECTATION_MISMATCH",
                "each exact custodian account is enforced")
        no_key = h.run("adapter-no-state-key", ["inspect", "--state", str(state),
            "--node", "A", *args], expected=3)
        h.check(no_key and no_key["code"] == "STATE_AUTH_KEY_REQUIRED",
            "custody is never a state-authentication key")
        unsupported = h.run("adapter-unsupported-command", ["config-check", "--config", str(root / "none.conf"),
            *args], expected=3)
        h.check(unsupported and unsupported["code"] == "UNKNOWN_ARGUMENT",
            "custody adapter applies only to existing exact-head commands")
        noncanonical = h.run("adapter-generation-noncanonical", ["inspect", "--state", str(state),
            "--node", "A", "--state-auth-key", str(key),
            "--expected-state-head-custody", str(record_path),
            "--expected-custody-domain", record["domain"],
            "--expected-custody-generation", "07",
            "--expected-custody-digest", record["record_digest"]], expected=3)
        h.check(noncanonical and noncanonical["code"] == "STATE_HEAD_CUSTODY_GENERATION_INVALID",
            "custody generation is canonical decimal")

        record_path.chmod(0o640)
        unsafe = h.run("adapter-unsafe-mode", ["inspect", "--state", str(state),
            "--node", "A", "--state-auth-key", str(key), *args], expected=3)
        h.check(unsafe and unsafe["code"] == "STATE_HEAD_CUSTODY_FILE_PERMISSIONS_INVALID",
            "adapter retains exact owner-only custody mode")
        record_path.chmod(0o600)
        symlink = record_path.parent / "linked.head"
        symlink.symlink_to(record_path.name)
        linked_args = [*args]
        linked_args[1] = str(symlink)
        unsafe = h.run("adapter-final-symlink", ["inspect", "--state", str(state),
            "--node", "A", "--state-auth-key", str(key), *linked_args], expected=3)
        h.check(unsafe and unsafe["code"] in ("STATE_HEAD_CUSTODY_OPEN_FAILED",
            "STATE_HEAD_CUSTODY_FILE_INVALID"), "adapter never follows a final symlink")
        h.check(record_path.read_bytes() == before,
            "all parser and comparison failures preserve custody bytes")

    case("strict_adapter_and_inspection", strict_adapter_and_inspection)

    def stale_divergent_and_old_pair() -> None:
        root, state, key = setup(h, "custody-stale")
        old_state = root / "old-state"
        shutil.copytree(state, old_state)
        old_pin = selector((state / "state.journal").read_bytes(), key)
        record_path, record = create_anchor(h, "stale-anchor-create",
            root / "anchors", old_pin)
        args = constraint_args(record_path, record)
        append(h, state, key, "custody-stale-append")
        denied = h.run("stale-current-rejected", ["inspect", "--state", str(state),
            "--node", "A", "--state-auth-key", str(key), *args], expected=3)
        h.check(denied and denied["code"] == "STATE_HEAD_EXPECTATION_MISMATCH",
            "stale custody cannot open a later authenticated state")
        old = h.run("stale-old-pair", ["inspect", "--state", str(old_state),
            "--node", "A", "--state-auth-key", str(key), *args])
        assert old
        h.check(old["state_head"]["selector"] == old_pin,
            "authentic old state plus its authentic old custody remains an old pair")

        left = root / "left"; right = root / "right"
        shutil.copytree(old_state, left); shutil.copytree(old_state, right)
        append(h, left, key, "branch-left-01")
        append(h, right, key, "branch-rght-01")
        left_raw = (left / "state.journal").read_bytes()
        right_raw = (right / "state.journal").read_bytes()
        left_pin = selector(left_raw, key); right_pin = selector(right_raw, key)
        h.check(len(left_raw) == len(right_raw) and
            left_pin.split(":")[:5] == right_pin.split(":")[:5] and
            left_pin.split(":")[6:] == right_pin.split(":")[6:] and
            left_pin.split(":")[5] != right_pin.split(":")[5],
            "same-size branches differ only in authenticated root")
        branch_path, branch_record = create_anchor(h, "branch-anchor-create",
            root / "branch-anchor", left_pin)
        branch_args = constraint_args(branch_path, branch_record)
        h.run("branch-left-exact", ["inspect", "--state", str(left), "--node", "A",
            "--state-auth-key", str(key), *branch_args])
        rejected = h.run("branch-right-divergent", ["inspect", "--state", str(right),
            "--node", "A", "--state-auth-key", str(key), *branch_args], expected=3)
        h.check(rejected and rejected["code"] == "STATE_HEAD_EXPECTATION_MISMATCH",
            "custody detects an equal-size divergent authenticated branch")

    case("stale_divergent_and_old_pair", stale_divergent_and_old_pair)

    def finite_replacement_race() -> None:
        root, state, key = setup(h, "custody-race")
        pin = selector((state / "state.journal").read_bytes(), key)
        directory = root / "anchors"
        record_path, record = create_anchor(h, "race-anchor-create", directory, pin)
        replacement_path, _ = create_anchor(h, "race-replacement-create", directory,
            pin.replace(":" + pin.split(":")[-2] + ":" + pin.split(":")[-1],
                ":2:" + str(int(pin.split(":")[-1]) + 1)),
            generation=2, filename="replacement.head")
        state_before = (state / "state.journal").read_bytes()
        command = [str(h.binary), "inspect", "--state", str(state), "--node", "A",
            "--state-auth-key", str(key), *constraint_args(record_path, record)]
        started = time.time()
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, env=dict(os.environ,
                NATRAV_OVERLAY_TEST_CUSTODY_CONSTRAINT_PAUSE_FINAL_MS="800"))
        time.sleep(0.2)
        os.replace(replacement_path, record_path)
        stdout, stderr = process.communicate(timeout=10)
        h.commands.append({"label": "finite-replacement-race", "args": command[1:],
            "returncode": process.returncode, "stdout": stdout, "stderr": stderr,
            "elapsed_seconds": time.time() - started,
            "environment": ["NATRAV_OVERLAY_TEST_CUSTODY_CONSTRAINT_PAUSE_FINAL_MS"]})
        (h.logs / f"{len(h.commands):03d}-finite-replacement-race.stdout.txt").write_text(stdout)
        (h.logs / f"{len(h.commands):03d}-finite-replacement-race.stderr.txt").write_text(stderr)
        h.check(process.returncode == 3, "replacement before success suppresses the apparent success")
        value = json.loads([line for line in stdout.splitlines() if line.strip()][-1])
        h.check(value["code"] == "STATE_HEAD_CUSTODY_REPLACEMENT_RACE",
            "finite command has an explicit custody replacement failure")
        h.check((state / "state.journal").read_bytes() == state_before,
            "read-only race leaves authenticated state unchanged")

    case("finite_replacement_race", finite_replacement_race)

    def startup_compaction_and_explicit_advance() -> None:
        root, state, key = setup(h, "custody-start")
        conf = v7(h.config("custody-start", "A", state, free_port(), []),
            "custody-start-runtime-1")
        pin = selector((state / "state.journal").read_bytes(), key)
        record_path, record = create_anchor(h, "startup-anchor-create",
            root / "anchors", pin)
        daemon = start_custody_daemon(h, "custody-start", conf, state, key,
            constraint_args(record_path, record))
        parent_fd = os.open(record_path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            fcntl.flock(parent_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(parent_fd, fcntl.LOCK_UN)
        finally:
            os.close(parent_fd)
        h.check(True, "daemon releases custody parent lock after startup acceptance")
        before_anchor = record_path.read_bytes()
        compacted = h.run("custody-start-compact", ["compact", "--control", str(daemon.control),
            "--deadline-ms", "10000"])
        assert compacted
        daemon.shutdown()
        h.check(record_path.read_bytes() == before_anchor,
            "startup and compaction never auto-advance custody")
        final_pin = selector((state / "state.journal").read_bytes(), key)
        h.check(final_pin != pin, "startup configuration and compaction produce a distinct exact head")
        stale = h.run("custody-start-old-record", ["inspect", "--state", str(state),
            "--node", "A", "--state-auth-key", str(key),
            *constraint_args(record_path, record)], expected=3)
        h.check(stale and stale["code"] == "STATE_HEAD_EXPECTATION_MISMATCH",
            "old custody does not silently follow daemon mutation")
        current = advance_anchor(h, "custody-start-explicit-advance", record_path,
            record, final_pin, 2)
        reopened = h.run("custody-start-reopen", ["inspect", "--state", str(state),
            "--node", "A", "--state-auth-key", str(key),
            *constraint_args(record_path, current)])
        assert reopened
        h.check(reopened["state_head"]["selector"] == final_pin,
            "only explicit custody CAS admits the new state head")

    case("startup_compaction_and_explicit_advance", startup_compaction_and_explicit_advance)

    def startup_replacement_race() -> None:
        root, state, key = setup(h, "custody-start-race")
        pin = selector((state / "state.journal").read_bytes(), key)
        directory = root / "anchors"
        record_path, record = create_anchor(h, "startup-race-anchor", directory, pin)
        replacement_path, _ = create_anchor(h, "startup-race-replacement", directory,
            pin.replace(":" + pin.split(":")[-2] + ":" + pin.split(":")[-1],
                ":2:" + str(int(pin.split(":")[-1]) + 1)),
            generation=2, filename="replacement.head")
        command = [str(h.binary), "serve", "--state", str(state), "--node", "A",
            "--listen", f"127.0.0.1:{free_port()}", "--state-auth-key", str(key),
            *constraint_args(record_path, record), "--idle-timeout-ms", "1000"]
        started = time.time()
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, env=dict(os.environ,
                NATRAV_OVERLAY_TEST_CUSTODY_CONSTRAINT_PAUSE_STARTUP_MS="800"))
        time.sleep(0.2)
        os.replace(replacement_path, record_path)
        stdout, stderr = process.communicate(timeout=10)
        h.commands.append({"label": "startup-replacement-race", "args": command[1:],
            "returncode": process.returncode, "stdout": stdout, "stderr": stderr,
            "elapsed_seconds": time.time() - started,
            "environment": ["NATRAV_OVERLAY_TEST_CUSTODY_CONSTRAINT_PAUSE_STARTUP_MS"]})
        (h.logs / f"{len(h.commands):03d}-startup-replacement-race.stdout.txt").write_text(stdout)
        (h.logs / f"{len(h.commands):03d}-startup-replacement-race.stderr.txt").write_text(stderr)
        h.check(process.returncode == 3 and "SERVER_READY" not in stdout,
            "startup replacement fails before advertising readiness")
        value = json.loads([line for line in stdout.splitlines() if line.strip()][-1])
        h.check(value["code"] == "STATE_HEAD_CUSTODY_REPLACEMENT_RACE",
            "startup has an explicit custody replacement failure")

    case("startup_replacement_race", startup_replacement_race)

    def rotation_and_recovery() -> None:
        root, state, key = setup(h, "custody-rotate")
        pin = selector((state / "state.journal").read_bytes(), key)
        record_path, record = create_anchor(h, "rotate-anchor-create",
            root / "anchors", pin)
        next_key = new_key(h, root, "custody-rotate-g2")
        anchor_before_rotation = record_path.read_bytes()
        rotated = h.run("custody-rotate-exact", ["state-auth-rotate", "--state", str(state),
            "--node", "A", "--state-auth-key", str(key), "--new-key", str(next_key),
            "--reason", "explicit custody constrained rotation",
            *constraint_args(record_path, record)])
        assert rotated
        next_pin = selector((state / "state.journal").read_bytes(), next_key)
        h.check(next_pin != pin and record_path.read_bytes() == anchor_before_rotation,
            "rotation produces a distinct head without implicit custody mutation")
        stale = h.run("custody-rotate-stale-record", ["inspect", "--state", str(state),
            "--node", "A", "--state-auth-key", str(next_key),
            *constraint_args(record_path, record)], expected=3)
        h.check(stale and stale["code"] == "STATE_HEAD_EXPECTATION_MISMATCH",
            "rotation result is not silently accepted by old custody")
        current = advance_anchor(h, "custody-rotate-explicit-advance", record_path,
            record, next_pin, 2)
        inspected = h.run("custody-rotate-reopen", ["inspect", "--state", str(state),
            "--node", "A", "--state-auth-key", str(next_key),
            *constraint_args(record_path, current)])
        assert inspected

        recovery_root, recovery_state, recovery_key = setup(h, "custody-recovery", True)
        recovery_pin = selector((recovery_state / "state.journal").read_bytes(), recovery_key)
        recovery_path, recovery_record = create_anchor(h, "recovery-anchor-create",
            recovery_root / "anchors", recovery_pin)
        original = (recovery_state / "state.journal").read_bytes()
        recovery_anchor_before = recovery_path.read_bytes()
        partial = incomplete_next(original, recovery_key)
        (recovery_state / "state.journal").write_bytes(partial)
        report = audit(h, "custody-recovery-audit", recovery_state, recovery_key,
            expected=3, extra=constraint_args(recovery_path, recovery_record))
        h.check(report["status"] == "INCOMPLETE_TAIL" and report["recovery_eligible"],
            "custody can select the exact authenticated prefix without repairing it")
        recovered = h.run("custody-recovery-exact", [*recover_args(recovery_state,
            recovery_key, report, recovery_root / "preserved.bin"),
            *constraint_args(recovery_path, recovery_record)])
        assert recovered
        result_pin = selector((recovery_state / "state.journal").read_bytes(), recovery_key)
        h.check(result_pin != recovery_pin and recovery_path.read_bytes() == recovery_anchor_before,
            "recovery appends provenance but never advances detached custody")
        recovery_current = advance_anchor(h, "custody-recovery-explicit-advance",
            recovery_path, recovery_record, result_pin, 2)
        h.run("custody-recovery-reopen", ["inspect", "--state", str(recovery_state),
            "--node", "A", "--state-auth-key", str(recovery_key),
            *constraint_args(recovery_path, recovery_current)])

    case("rotation_and_recovery", rotation_and_recovery)

    def backup_restore_relocation_and_audit() -> None:
        root, state, key = setup(h, "custody-backup")
        conf = v7(h.config("custody-backup", "A", state, free_port(), []),
            "custody-backup-runtime-1")
        opening_pin = selector((state / "state.journal").read_bytes(), key)
        source_path, source_record = create_anchor(h, "backup-source-anchor",
            root / "anchors", opening_pin, domain="source-state")
        daemon = start_custody_daemon(h, "custody-backup", conf, state, key,
            constraint_args(source_path, source_record))
        daemon.shutdown()
        source_pin = selector((state / "state.journal").read_bytes(), key)
        source_record = advance_anchor(h, "backup-source-anchor-advance",
            source_path, source_record, source_pin, 2)
        source_anchor_before_maintenance = source_path.read_bytes()
        source_args = constraint_args(source_path, source_record)

        identity = h.identity("A")
        encryption = backup_key(h, root, "custody-backup", "enc-g1")
        archive = root / "snapshot.nob"
        exported = h.run("custody-backup-export", ["backup-export", "--state", str(state),
            "--node", "A", "--generation", "a-g1", "--output", str(archive),
            "--state-auth-key", str(key), "--sign-key", str(identity.private_key),
            "--sign-cert", str(identity.certificate), "--encrypt-key", str(encryption),
            *source_args], timeout=30)
        assert exported
        backup_pin = exported["state_head"]["selector"]
        backup_path, backup_record = create_anchor(h, "backup-checkpoint-anchor",
            root / "backup-anchor", backup_pin, domain="backup-checkpoint")
        backup_anchor_before_maintenance = backup_path.read_bytes()
        backup_args = constraint_args(backup_path, backup_record)
        verify_base = ["backup-verify", "--input", str(archive), "--node", "A",
            "--generation", "a-g1", "--state-auth-key", str(key),
            "--decrypt-key", str(encryption), "--require-encryption", "yes",
            "--trusted-cert", str(identity.certificate), "--require-signature", "yes"]
        verified = h.run("custody-backup-verify", [*verify_base, *backup_args], timeout=30)
        assert verified
        h.check(verified["state_head"]["selector"] == backup_pin and
            verified["state_head"]["expectation"] == "MATCH",
            "backup verification uses embedded checkpoint head from custody")
        not_found = h.run("custody-backup-stop-audit", ["backup-correlated-stop-audit",
            "--input", str(archive), "--node", "A", "--generation", "a-g1",
            "--state-auth-key", str(key), "--decrypt-key", str(encryption),
            "--trusted-cert", str(identity.certificate), "--request-id", operation("absent-stop"),
            *backup_args], timeout=30)
        assert not_found
        h.check(not_found["outcome"]["classification"] == "NOT_FOUND",
            "direct signed-encrypted backup audit consumes the exact custody condition")

        encryption2 = backup_key(h, root, "custody-backup-2", "enc-g2")
        reencrypted = root / "reencrypted.nob"
        reenc = h.run("custody-backup-reencrypt", ["backup-reencrypt",
            "--input", str(archive), "--output", str(reencrypted),
            "--decrypt-key", str(encryption), "--encrypt-key", str(encryption2),
            "--state-auth-key", str(key), "--node", "A", "--generation", "a-g1",
            "--trusted-cert", str(identity.certificate), "--require-signature", "yes",
            *backup_args], timeout=30)
        assert reenc
        h.check(reenc["state_head"]["selector"] == backup_pin,
            "re-encryption preserves the embedded authenticated head")
        h.run("custody-backup-reencrypted-verify", ["backup-verify", "--input", str(reencrypted),
            "--node", "A", "--generation", "a-g1", "--state-auth-key", str(key),
            "--decrypt-key", str(encryption2), "--require-encryption", "yes",
            "--trusted-cert", str(identity.certificate), "--require-signature", "yes",
            *backup_args], timeout=30)

        destination = root / "restored"
        restored = h.run("custody-backup-restore", ["backup-restore", "--input", str(archive),
            "--destination", str(destination), "--node", "A", "--generation", "a-g1",
            "--state-auth-key", str(key), "--decrypt-key", str(encryption),
            "--require-encryption", "yes", "--trusted-cert", str(identity.certificate),
            "--require-signature", "yes", *backup_args], timeout=30)
        assert restored
        restored_pin = selector((destination / "state.journal").read_bytes(), key)
        restored_path, restored_record = create_anchor(h, "restored-anchor-create",
            root / "restored-anchor", restored_pin, domain="restored-state")
        cert, tls_key = copy_identity(identity.certificate, identity.private_key,
            root / "relocated-identity")
        candidate = relocated_config(conf, destination, cert, tls_key,
            "custody-relocated-runtime-2", root / "relocated.conf")
        relocated = h.run("custody-state-relocate", ["state-relocate", "--state", str(destination),
            "--node", "A", "--candidate", str(candidate),
            "--reason", "explicit custody constrained relocation", "--state-auth-key", str(key),
            *constraint_args(restored_path, restored_record)], timeout=30)
        assert relocated
        relocated_pin = selector((destination / "state.journal").read_bytes(), key)
        h.check(relocated_pin != restored_pin,
            "relocation produces a distinct exact authenticated head")
        relocated_record = advance_anchor(h, "relocated-anchor-explicit-advance",
            restored_path, restored_record, relocated_pin, 2)
        h.run("relocated-custody-reopen", ["inspect", "--state", str(destination),
            "--node", "A", "--state-auth-key", str(key),
            *constraint_args(restored_path, relocated_record)])
        h.check(source_path.read_bytes() == source_anchor_before_maintenance and
            backup_path.read_bytes() == backup_anchor_before_maintenance,
            "maintenance never implicitly advances unrelated custody records")

    case("backup_restore_relocation_and_audit", backup_restore_relocation_and_audit)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append", choices=CASES)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    h = Harness(args.binary, args.output)
    begin = time.time(); code = 1
    try:
        run_suite(h, set(args.case) if args.case else None)
        code = 0
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
    finally:
        h.cleanup()
        summary = {"format": "NATRAV_OVERLAY_CUSTODY_STATE_OPENING_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(case["status"] == "PASS" for case in h.cases),
            "cases_total": len(h.cases), "assertions": h.assertions,
            "commands": len(h.commands), "elapsed_seconds": time.time() - begin}
        for name, value in (("SUMMARY.json", summary), ("CASES.json", h.cases),
                            ("COMMANDS.json", h.commands)):
            (h.output / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
