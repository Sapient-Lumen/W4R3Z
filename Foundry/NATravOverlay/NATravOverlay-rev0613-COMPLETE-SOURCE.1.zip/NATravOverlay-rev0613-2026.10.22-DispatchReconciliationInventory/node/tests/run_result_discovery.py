#!/usr/bin/env python3
"""Owned-process request-centric result discovery and continuation checks.
Dishonest-report fixtures use only locally generated test identities and loopback.
No report is treated as independent proof of remote execution.
"""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, socket, struct, subprocess, sys, time
from pathlib import Path
from run_persistent import Harness, operation, raw_control
from run_action_result_correlation import (setup, completed, emit, encode_nac, effect,
    result_id, query as exact_query)
from run_action_results import (submit_action, wait_action, wait_outbox, decode_nac1,
    evidence_query, RESULT_SCOPE)
from run_live_configuration import candidate, activate
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_state_authentication import new_key, migrate, start as keyed_start, inspect
from run_integration import encode_record, record_digest


def arguments(state, request, *, provider='B', scope=RESULT_SCOPE, limit=8, maximum=32768, cursor=''):
    args=['action-result-discover','--control',str(state/'control.sock'),'--request',request,
          '--provider',provider,'--scope',scope,'--limit',str(limit),'--max-bytes',str(maximum),'--deadline-ms','5000']
    if cursor:args+=['--cursor',cursor]
    return args


def discover(h,label,state,request,*,expected=0,uid=None,**kw):
    args=arguments(state,request,**kw)
    q=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    assert q is not None
    if expected==0:
        h.check(q['format']=='NATRAV_OVERLAY_ACTION_RESULT_DISCOVERY_V1','explicit discovery format')
        h.check(len(json.dumps(q,separators=(',',':')).encode())<=kw.get('maximum',32768),'complete annotated response bounded')
        h.check(q['work']['snapshot_calls']==q['work']['logical_bytes_serialized']==q['work']['prior_candidates_rehashed']==0,'no snapshots, logical encoding or old-candidate rehash')
        h.check(q['work']['candidate_records_visited']<=kw.get('limit',8),'at most configured validations, including any nonfitting candidate')
        h.check(q['returned']==len(q['records'])==q['scan']['after']-q['scan']['from'],'exact page accounting')
        h.check(q['scan']['consistent']+q['scan']['invalid']==q['scan']['examined'],'cumulative classification conservation')
        h.check(not q['execution_verified_locally'] and q['freshness']=='NOT_ESTABLISHED','no execution or freshness proof')
        if not q['complete']:
            h.check(q['status']=='INCOMPLETE' and q['unique_operation_id'] is None and q['next_cursor'],'incomplete scan cannot assert uniqueness')
        else:h.check(q['next_cursor'] is None,'complete scan has no continuation')
    return q


def wire(request, *, provider='B',scope=RESULT_SCOPE,limit=8,maximum=32768,cursor=''):
    text=lambda v:struct.pack('!H',len(v.encode()))+v.encode()
    return (b'NOC1\x20ARD1'+bytes.fromhex(request)+text(provider)+text(scope)+
            struct.pack('!II',limit,maximum)+text(cursor))


def enumerate_all(h,label,state,action,**kw):
    pages=[];cursor='';rows=[]
    for i in range(200):
        q=discover(h,f'{label}-{i}',state,action,cursor=cursor,**kw);pages.append(q);rows.extend(q['records'])
        if q['complete']:return pages,rows
        h.check(q['returned']>0,'nonterminal page always progresses');cursor=q['next_cursor']
    raise AssertionError('enumeration did not terminate')


def save(h,name,value):
    (h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')


def cases(h,only):
    def case(name,fn):
        if only is None or name in only:h.case(name,fn)

    def basic():
        root,ap,bp,ac,bc,a,b=setup(h,'basic')
        action=operation('not-yet-executed');submit_action(h,'pending-source',root/'a',action,7,30000)
        wait_action(h,'pending-source-admitted',root/'b',action,'PENDING')
        before=discover(h,'empty-domain',root/'a',action)
        h.check(before['status']=='NO_CANDIDATES' and before['work']['candidate_records_visited']==0 and before['work']['historical_configurations_parsed']==0,'empty indexed domain avoids parsing')
        h.check(discover(h,'missing-request',root/'a',operation('missing'),expected=3)['code']=='ACTION_RESULT_REQUEST_NOT_FOUND','no invented request')
        bad=[]
        for i in range(3):bad.append(emit(h,ap,b'NAC1\x01'+bytes.fromhex(action)+bytes([i])*40))
        pages,rows=enumerate_all(h,'invalid-only',root/'a',action,limit=2)
        h.check(pages[-1]['status']=='NO_CONSISTENT_REPORTS' and all(r['report'] is None for r in rows),'invalid-only domain explicitly complete without report')
        h.run('cancel-provider-action',['action-cancel','--control',str(root/'b'/'control.sock'),'--action',action,'--reason','bounded pending fixture'])
        row=wait_action(h,'cancelled-result',root/'b',action,'CANCELLED');result=row['action_result']['operation_id']
        wait_outbox(h,'cancelled-delivered',root/'b',result,'ACKED')
        pages,rows=enumerate_all(h,'unique-after-invalids',root/'a',action,limit=2)
        h.check(pages[-1]['status']=='UNIQUE_AUTHENTICATED_REPORT' and pages[-1]['unique_operation_id']==result,'unique only after final complete page')
        ok,ind=raw_control(root/'a'/'control.sock',wire(action,limit=2))
        h.check(ok and ind['records']==pages[0]['records'],'independent control encoding matches native client')
        for pkt in [wire(action)+b'x',wire(action)[:-1],wire(action).replace(b'ARD1',b'ARD2'),wire(action,limit=33),wire(action,maximum=60001)]:
            ok,err=raw_control(root/'a'/'control.sock',pkt)
            h.check(not ok and err['code'].startswith('ACTION_RESULT_DISCOVERY_'),'strict request version EOF and bounds')
        b.shutdown();a.shutdown();save(h,'BASIC',{'empty':before,'unique':pages[-1]})
    case('empty_invalid_unique_and_independent_protocol',basic)

    def many():
        root,ap,bp,ac,bc,a,b=setup(h,'many')
        action,result,payload=completed(h,'many-original',root)
        payloads=[(result,payload)]
        for i in range(73):
            p=b'NAC1\x01'+bytes.fromhex(action)+struct.pack('!I',i)+b'invalid payload'
            payloads.append((emit(h,ap,p),p))
        alternate=decode_nac1(payload);alternate['terminal_unix_ms']+=1;alternate['local_receipt_digest']=effect(alternate)
        p=encode_nac(alternate);payloads.append((emit(h,ap,p),p))
        h.check(exact_query(h,'old-exact-still-bounded',root/'a',result,action,expected=3)['code']=='ACTION_RESULT_SCAN_LIMIT','old exact query keeps declared total bound')
        pages,rows=enumerate_all(h,'many-pages',root/'a',action,limit=9)
        h.check(len(pages)==9 and len(rows)==75 and len({r['operation_id'] for r in rows})==75,'all 75 candidates enumerated once in nine pages')
        root_digest=bytes(32)
        for ordinal,((op,payload),row) in enumerate(zip(payloads,rows),1):
            rd=record_digest(encode_record(op,'B','A',RESULT_SCOPE,payload))
            h.check(row['operation_id']==op and row['record_digest']==rd.hex(),'row identity independently derived')
            root_digest=hashlib.sha256(b'NATRAV_OVERLAY_RESULT_CANDIDATE_CHAIN_V1\0'+root_digest+struct.pack('!Q',ordinal)+bytes.fromhex(op)+rd).digest()
            h.check(row['classification']==('CONSISTENT_AUTHENTICATED_REPORT' if ordinal in (1,75) else 'INVALID_REPORT'),'independent classification reference')
        for page in pages:h.check(page['selection']['candidate_root']==root_digest.hex(),'incremental candidate root independently recomputed')
        final=pages[-1]
        h.check(final['status']=='CONFLICTING_REPORTS' and final['scan']['consistent']==2 and final['scan']['invalid']==73 and final['unique_operation_id'] is None,'late conflict prevents false uniqueness')
        h.check(sum(p['work']['candidate_records_visited'] for p in pages)==75,'large pages do not revalidate old candidates')
        small,again=enumerate_all(h,'byte-pages',root/'a',action,limit=32,maximum=4096)
        h.check([r['operation_id'] for r in again]==[op for op,_ in payloads],'byte-limited rows are neither skipped nor split')
        state_before=h.status('read-only-before',root/'a')['storage']['logical_state_digest']
        for i in range(4):discover(h,'observational-'+str(i),root/'a',action,limit=1)
        h.check(h.status('read-only-after',root/'a')['storage']['logical_state_digest']==state_before,'successful discovery does not mutate logical state')
        save(h,'MANY-CANDIDATES',{'pages':len(pages),'byte_pages':len(small),'root':root_digest.hex(),'final':final})
        b.shutdown();a.shutdown()
    case('complete_75_candidate_scan_and_byte_limited_pagination',many)

    def continuation():
        root,ap,bp,ac,bc,a,b=setup(h,'continuation')
        action,result,payload=completed(h,'continuation-original',root)
        for i in range(3):emit(h,ap,b'NAC1\x01'+bytes.fromhex(action)+bytes([i])*48)
        first=discover(h,'first-page',root/'a',action,limit=1);token=first['next_cursor']
        mutated=token[:-1]+('0' if token[-1]!='0' else '1')
        h.check(discover(h,'bad-mac',root/'a',action,limit=1,cursor=mutated,expected=3)['code']=='ACTION_RESULT_DISCOVERY_CURSOR_INVALID','changed tag denied')
        h.check(discover(h,'changed-options',root/'a',action,limit=2,cursor=token,expected=3)['code']=='ACTION_RESULT_DISCOVERY_CONTEXT_MISMATCH','query options authenticated')
        h.run('compact-mid-page',['compact','--control',str(root/'a'/'control.sock'),'--deadline-ms','5000'])
        q=discover(h,'after-compaction',root/'a',action,limit=1,cursor=token)
        h.check(q['scan']['from']==1,'same-process compaction preserves continuation')
        other,_,_=completed(h,'unrelated-report',root)
        h.check(other!=action and discover(h,'unrelated-stable',root/'a',action,limit=1,cursor=token)['records']==q['records'],'unrelated report does not stale selected candidates')
        emit(h,ap,b'NAC1\x01'+bytes.fromhex(action)+b'new candidate')
        h.check(discover(h,'new-candidate-stale',root/'a',action,limit=1,cursor=token,expected=3)['code']=='ACTION_RESULT_DISCOVERY_STALE','changed candidates require restart')
        fresh=discover(h,'fresh-selection',root/'a',action,limit=1)
        changed=candidate(h,ac,'continuation-changed','continuation-g2')
        activate(h,'publish-new-config',root/'a',changed)
        h.check(discover(h,'configuration-context',root/'a',action,limit=1,cursor=fresh['next_cursor'],expected=3)['code']=='ACTION_RESULT_DISCOVERY_CONTEXT_MISMATCH','accepted configuration bound')
        fresh=discover(h,'before-restart',root/'a',action,limit=1)
        a.shutdown();a=h.start('continuation-restarted',ac,root/'a')
        h.check(discover(h,'restarted-token',root/'a',action,limit=1,cursor=fresh['next_cursor'],expected=3)['code']=='ACTION_RESULT_DISCOVERY_CURSOR_INVALID','process-local key invalidates restart')
        h.check(discover(h,'fresh-after-restart',root/'a',action,limit=1)['selection']==fresh['selection'],'candidate root reconstructs')
        b.shutdown();a.shutdown()
    case('cursor_authentication_context_compaction_and_new_candidates',continuation)

    def permissions():
        root,ap,bp,ac,bc,a,b=setup(h,'permissions',delegates=True)
        action,result,payload=completed(h,'permitted-report',root)
        emit(h,ap,b'NAC1\x01'+bytes.fromhex(action)+b'other')
        owner=discover(h,'owner-token',root/'a',action,limit=1)
        expose_control_for_uid(root/'a')
        discover(h,'actual-delegate',root/'a',action,uid=65534)
        for uid in (65533,65532):
            h.check(discover(h,'class-'+str(uid),root/'a',action,uid=uid,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','both administrative and payload authority required')
        h.check(discover(h,'cross-uid-cursor',root/'a',action,uid=65534,limit=1,cursor=owner['next_cursor'],expected=3)['code']=='ACTION_RESULT_DISCOVERY_CONTEXT_MISMATCH','owner token not usable as delegate capability')
        for request in (action,operation('hidden-missing')):
            h.check(discover(h,'hidden-'+request[:4],root/'a',request,uid=65534,scope='results/private',expected=3)['code']=='ACTION_RESULT_READ_DENIED','scope authority precedes request lookup')
        script="""import socket,struct,sys,json
s=socket.socket(socket.AF_UNIX);s.settimeout(10);s.connect(sys.argv[1]);p=bytes.fromhex(sys.argv[2]);s.sendall(struct.pack('!I',len(p))+p[:2]);print('CONNECTED',flush=True);sys.stdin.readline();s.sendall(p[2:]);s.shutdown(socket.SHUT_WR)
def read(n):
 b=b''
 while len(b)<n:
  x=s.recv(n-len(b))
  if not x:raise RuntimeError('EOF')
  b+=x
 return b
n=struct.unpack('!I',read(4))[0];r=read(n);print(json.dumps({'ok':r[4]==0,'body':json.loads(r[5:])}),flush=True)
"""
        proc=subprocess.Popen(['/usr/bin/setpriv','--reuid=65534','--regid=65534','--clear-groups',sys.executable,'-c',script,str(root/'a'/'control.sock'),wire(action).hex()],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            h.check(proc.stdout.readline().strip()=='CONNECTED','real UID request partly transmitted')
            changed=candidate(h,ac,'permission-revoked','permission-g2',lambda t:t.replace('local_control=65534,INSPECT,EVIDENCE_READ,EVIDENCE_PAYLOAD','local_control=65534,INSPECT,EVIDENCE_READ').replace(f'evidence_read=65534,B,{RESULT_SCOPE},PAYLOAD',f'evidence_read=65534,B,{RESULT_SCOPE},METADATA'))
            activate(h,'revoke-before-decoding-complete',root/'a',changed)
            stdout,stderr=proc.communicate('\n',timeout=12)
            r=json.loads(stdout.splitlines()[-1]);h.check(proc.returncode==0 and not r['ok'] and r['body']['code']=='LOCAL_CONTROL_CLASS_DENIED','completed request uses newly accepted permission')
            save(h,'PRINCIPALS',r)
        finally:
            if proc.poll() is None:proc.kill();proc.wait()
        restore_owner_only_control(root/'a');b.shutdown();a.shutdown()
    case('real_uid_domain_authority_and_partial_request_revocation',permissions)

    def receipt_change():
        action=operation('late-original-receipt')
        root,ap,bp,ac,bc,a,b=setup(h,'late',environment={'NATRAV_OVERLAY_TEST_SESSION_DROP_AFTER_ADMISSION_OPERATION':action})
        slow=candidate(h,ac,'late-retry','late-g2',lambda t:t.replace('peer=B,50,250,50,120000','peer=B,10000,10000,50,120000'))
        activate(h,'slow-original-retry',root/'a',slow)
        submit_action(h,'lost-receipt-source',root/'a',action,9)
        ar=wait_action(h,'executed-with-lost-reply',root/'b',action,'EXECUTED');result=ar['action_result']['operation_id']
        wait_outbox(h,'independent-result-received',root/'b',result,'ACKED')
        payload=bytes.fromhex(evidence_query(h,'late-raw',root/'a',result)['payload_hex']);r=decode_nac1(payload)
        wrong=dict(r);wrong['source_record_digest']='77'*32
        bad=emit(h,ap,encode_nac(wrong))
        alternate=dict(r);alternate['source_sequence']+=10
        alternative=emit(h,ap,encode_nac(alternate))
        pages,rows=enumerate_all(h,'before-receipt',root/'a',action,limit=1)
        first=pages[0]
        h.check(first['original_request']['source_admission_receipt'] is None and first['original_request']['delivery_state']=='PENDING','result is not a fabricated original receipt')
        h.check(rows[1]['operation_id']==bad and rows[1]['rejection_code']=='ACTION_RESULT_REQUEST_MISMATCH','no receipt still requires exact source digest')
        h.check(pages[-1]['status']=='CONFLICTING_REPORTS','without receipt two sequence claims can be self-consistent')
        b.shutdown();b=h.start('late-provider-returned',bc,root/'b')
        wait_outbox(h,'original-receipt-arrives',root/'a',action,'ACKED')
        h.check(discover(h,'late-receipt-stale',root/'a',action,limit=1,cursor=first['next_cursor'],expected=3)['code']=='ACTION_RESULT_DISCOVERY_STALE','new receipt alters validation facts')
        after,rows=enumerate_all(h,'after-receipt',root/'a',action,limit=1)
        h.check(after[-1]['status']=='UNIQUE_AUTHENTICATED_REPORT' and after[-1]['unique_operation_id']==result,'actual receipt excludes incompatible source sequence')
        h.check(rows[-1]['operation_id']==alternative and rows[-1]['rejection_code']=='ACTION_RESULT_SOURCE_RECEIPT_MISMATCH','sequence rejected against actual receipt')
        save(h,'RECEIPT-CHANGE',{'before':pages[-1],'after':after[-1]});b.shutdown();a.shutdown()
    case('late_receipt_stales_prior_scan_and_missing_receipt_never_weakens_binding',receipt_change)

    def timeline_and_keys():
        root,ap,bp,ac,bc,a,b=setup(h,'timeline')
        action,result,payload=completed(h,'timeline-source',root)
        r=decode_nac1(payload);r.update(outcome=2,last_started_unix_ms=r['terminal_unix_ms']+1,local_receipt_digest=None,counter_before=None,counter_after=None,reason_bytes=1,reason_digest=hashlib.sha256(b'x').hexdigest())
        bad=emit(h,ap,encode_nac(r))
        exact=exact_query(h,'impossible-terminal-timeline',root/'a',bad,action,expected=3)
        h.check(exact['code']=='ACTION_RESULT_REPORT_INVALID','nonexecuted start cannot follow termination')
        q=discover(h,'timeline-discovery',root/'a',action)
        h.check(q['records'][1]['rejection_code']=='ACTION_RESULT_REPORT_INVALID' and q['status']=='UNIQUE_AUTHENTICATED_REPORT','discovery shares corrected temporal validation')
        pin=h.identity('B2').spki_sha256
        changed=candidate(h,ac,'timeline-rotated','timeline-g2',lambda t:t.replace('peer_key=B,b-g1,ACTIVE,','peer_key=B,b-g1,REVOKED,').replace(f'authorize=B,b-g1,EVIDENCE,{RESULT_SCOPE}\n','')+f'peer_key=B,b-g2,ACTIVE,{pin}\nauthorize=B,b-g2,EVIDENCE,{RESULT_SCOPE}\n')
        activate(h,'rotate-executor',root/'a',changed)
        alt=decode_nac1(payload);alt['terminal_unix_ms']+=1;alt['local_receipt_digest']=effect(alt)
        wrong_key=emit(h,ap,encode_nac(alt),identity='B2')
        q=discover(h,'historical-versus-current-key',root/'a',action)
        h.check(q['original_request']['current_provider_key_state']=='REVOKED' and q['status']=='UNIQUE_AUTHENTICATED_REPORT','historical authentication not rewritten by revocation')
        h.check(q['records'][-1]['operation_id']==wrong_key and q['records'][-1]['rejection_code']=='ACTION_RESULT_PROVIDER_BINDING_MISMATCH','new key cannot answer old key-bound request')
        save(h,'TERMINAL-TIME',{'exact':exact,'discovery':q});b.shutdown();a.shutdown()
    case('shared_terminal_timeline_and_exact_historical_provider_key',timeline_and_keys)

    def maintenance():
        root,ap,bp,ac,bc,a,b=setup(h,'maintenance')
        action,result,payload=completed(h,'maintenance-source',root,11)
        emit(h,ap,b'NAC1\x01'+bytes.fromhex(action)+b'invalid retained')
        original=discover(h,'pre-maintenance',root/'a',action)
        prefix=discover(h,'pre-restart-cursor',root/'a',action,limit=1)
        a.shutdown();key=new_key(h,h.work,'discovery-state');migrate(h,'keyed-migration',root/'a',key,node='A')
        a=keyed_start(h,'discovery-keyed',ac,root/'a',key)
        h.check(discover(h,'keyed-fresh',root/'a',action)['records']==original['records'],'keyed reconstruction has same report decisions')
        h.check(discover(h,'old-process-token',root/'a',action,limit=1,cursor=prefix['next_cursor'],expected=3)['code']=='ACTION_RESULT_DISCOVERY_CURSOR_INVALID','key migration does not turn cursor into durable authority')
        h.run('keyed-compact',['compact','--control',str(root/'a'/'control.sock'),'--deadline-ms','5000']);a.shutdown()
        h.run('keyed-audit',['state-auth-audit','--state',str(root/'a'),'--node','A','--state-auth-key',str(key)])
        before=inspect(h,'before-backup',root/'a',key,node='A')
        crypt=h.work/'discovery-backup.key';h.run('encryption-key',['backup-key-init','--output',str(crypt),'--generation','discovery-archive'])
        identity=h.identity('A');archive=h.work/'discovery.nob'
        h.run('encrypted-export',['backup-export','--state',str(root/'a'),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--output',str(archive),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'discovery-restored'
        h.run('encrypted-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'after-restore',restored,key,node='A')
        h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'exact restored logical state')
        relocated_identity=h.runtime/'discovery-identity';relocated_identity.mkdir(mode=0o700)
        cert=relocated_identity/'cert.pem';secret=relocated_identity/'key.pem';shutil.copyfile(identity.certificate,cert);shutil.copyfile(identity.private_key,secret);secret.chmod(0o600)
        moved=candidate(h,ac,'moved','discovery-moved-g2',lambda t:t.replace('state='+str(root/'a'),'state='+str(restored)).replace(str(identity.certificate),str(cert)).replace(str(identity.private_key),str(secret)))
        h.run('relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','continue discovery','--state-auth-key',str(key)])
        identity.certificate.unlink();identity.private_key.unlink()
        a=keyed_start(h,'discovery-relocated',moved,restored,key)
        q=discover(h,'historical-after-relocation',restored,action)
        h.check(q['records']==original['records'] and q['selection']==original['selection'],'same source-derived classification without historical key paths')
        new=operation('new-post-restore-action');submit_action(h,'continued-action',restored,new,2)
        row=wait_action(h,'continued-effect',root/'b',new,'EXECUTED');wait_outbox(h,'continued-report',root/'b',row['action_result']['operation_id'],'ACKED')
        newer=discover(h,'continued-discovery',restored,new)
        h.check(newer['records'][0]['report']['counter_after']=='13','actual new action/result after restore')
        save(h,'MAINTENANCE',{'before':original,'after':q,'continued':newer});b.shutdown();a.shutdown()
    case('keyed_compaction_encrypted_restore_relocation_and_continuation',maintenance)

    def expiry():
        root,ap,bp,ac,bc,a,b=setup(h,'expiry')
        action,result,payload=completed(h,'expiry-source',root)
        emit(h,ap,b'NAC1\x01'+bytes.fromhex(action)+b'candidate')
        began=time.monotonic();page=discover(h,'expiry-first',root/'a',action,limit=1)
        time.sleep(max(0,300.3-(time.monotonic()-began)))
        err=discover(h,'expired-token',root/'a',action,limit=1,cursor=page['next_cursor'],expected=3)
        h.check(err['code']=='ACTION_RESULT_DISCOVERY_CURSOR_EXPIRED','fixed production monotonic lifetime')
        fresh=discover(h,'fresh-after-expiry',root/'a',action,limit=1)
        h.check(fresh['selection']==page['selection'],'expiry is not a candidate mutation')
        save(h,'EXPIRY',{'elapsed_seconds':time.monotonic()-began,'error':err,'same_selection':True});b.shutdown();a.shutdown()
    if only and 'production_monotonic_expiry' in only:case('production_monotonic_expiry',expiry)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');args=p.parse_args()
    if args.output.exists():p.error('output must not exist')
    h=Harness(args.binary,args.output);start=time.time();ok=False
    try:
        cases(h,set(args.case) if args.case else None)
        if not h.cases:raise ValueError('no selected cases')
        ok=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {e}',file=sys.stderr)
    finally:
        h.cleanup();s={'format':'NATRAV_RESULT_DISCOVERY_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,value in [('SUMMARY',s),('CASES',h.cases),('COMMANDS',h.commands)]:save(h,name,value)
        print(json.dumps(s),flush=True)
    return 0 if ok else 1

if __name__=='__main__':raise SystemExit(main())
