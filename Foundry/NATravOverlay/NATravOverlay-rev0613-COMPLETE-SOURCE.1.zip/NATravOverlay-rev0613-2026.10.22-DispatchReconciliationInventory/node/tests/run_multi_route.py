#!/usr/bin/env python3
"""Bounded V13 multi-route reachability, failover, live change and recovery tests."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import socket
import threading
import time
from typing import Any, Callable

from run_persistent import Harness, free_port as allocate_free_port, operation


# A released ephemeral port may be returned again immediately. Route fixtures
# intentionally assign several unavailable endpoints, and configuration rejects
# one endpoint assigned to multiple peers. Keep this process's requested port
# numbers distinct without reserving sockets across daemon startup.
_allocated_port_numbers: set[int] = set()
def free_port() -> int:
    while True:
        candidate = allocate_free_port()
        if candidate not in _allocated_port_numbers:
            _allocated_port_numbers.add(candidate)
            return candidate
from run_peer_sessions import submit, outbox_entry
from run_live_configuration import activate
from run_state_authentication import (
    inspect as keyed_inspect,
    migrate as migrate_state,
    new_key as new_state_key,
    start as start_keyed,
)

Route = tuple[str, int, str, str]
Peer = tuple[str, list[Route], int, int, int, int]


def write_v13_config(
    h: Harness,
    name: str,
    node: str,
    state: Path,
    listen: str,
    generation: str,
    peers: list[Peer],
    *,
    trusts: list[str] | None = None,
    authorizations: list[tuple[str, str]] | None = None,
    deadline_ms: int = 300,
    session_operations: int = 32,
    session_idle_ms: int = 2_000,
) -> Path:
    identity = h.identity(node)
    lines = [
        "NATRAV_OVERLAY_CONFIG_V13",
        f"runtime_generation={generation}",
        f"node={node}",
        f"state={state}",
        f"listen={listen}",
        "control=control.sock",
        f"identity_cert={identity.certificate}",
        f"identity_key={identity.private_key}",
        f"identity_pin={identity.spki_sha256}",
        f"identity_generation={node.lower()}-g1",
        f"deadline_ms={deadline_ms}",
        "peer_workers=4",
        "peer_queue_capacity=64",
        "control_workers=3",
        "control_queue_capacity=64",
        f"session_max_operations={session_operations}",
        "session_max_bytes=4194304",
        "session_max_lifetime_ms=30000",
        f"session_idle_timeout_ms={session_idle_ms}",
        "outbox_global_max_records=4096",
        "outbox_global_max_payload_bytes=67108864",
        "outbox_peer_max_records=1024",
        "outbox_peer_max_payload_bytes=16777216",
        f"local_control={os.geteuid()},ALL",
    ]
    configured: set[str] = set()
    for peer, routes, initial, maximum, attempts, expiry in peers:
        identity = h.identity(peer)
        lines.append(f"peer={peer},{initial},{maximum},{attempts},{expiry}")
        for route_id, priority, state_name, endpoint in routes:
            lines.append(
                f"peer_route={peer},{route_id},{priority},{state_name},{endpoint}"
            )
        lines.append(
            f"peer_key={peer},{peer.lower()}-g1,ACTIVE,{identity.spki_sha256}"
        )
        configured.add(peer)
    for peer in trusts or []:
        if peer in configured:
            continue
        identity = h.identity(peer)
        lines.append(
            f"peer_key={peer},{peer.lower()}-g1,ACTIVE,{identity.spki_sha256}"
        )
        configured.add(peer)
    for peer, scope in authorizations or []:
        lines.append(f"authorize={peer},*,EVIDENCE,{scope}")
    path = h.work / f"{name}.conf"
    path.write_text("\n".join(lines) + "\n")
    path.chmod(0o600)
    return path


def peer_status(status: dict[str, Any], node: str) -> dict[str, Any]:
    return next(item for item in status["peers"] if item["node"] == node)


def route_status(peer: dict[str, Any], route_id: str) -> dict[str, Any]:
    return next(item for item in peer["routes"] if item["id"] == route_id)


def wait_outbox(
    h: Harness,
    state: Path,
    operation_id: str,
    expected: str,
    label: str,
    timeout: float = 12.0,
) -> dict[str, Any]:
    observed: dict[str, Any] = {}

    def ready() -> bool:
        observed.clear()
        observed.update(h.status(label, state))
        return outbox_entry(observed, operation_id)["status"] == expected

    h.wait(label, ready, timeout)
    return observed


class TcpRelay:
    """Small TLS-transparent test relay; never part of the product runtime."""

    def __init__(self, listen_port: int, target_port: int):
        self.listen_port = listen_port
        self.target_port = target_port
        self.stop_event = threading.Event()
        self.ready = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.listener: socket.socket | None = None
        self.handlers: list[threading.Thread] = []
        self.connections = 0
        self.error: BaseException | None = None

    def start(self) -> None:
        self.thread.start()
        if not self.ready.wait(5):
            raise AssertionError("relay did not become ready")
        if self.error:
            raise self.error

    @staticmethod
    def _copy(source: socket.socket, destination: socket.socket) -> None:
        try:
            while True:
                data = source.recv(65_536)
                if not data:
                    try:
                        destination.shutdown(socket.SHUT_WR)
                    except OSError:
                        pass
                    return
                destination.sendall(data)
        except OSError:
            return

    def _handle(self, inbound: socket.socket) -> None:
        try:
            with inbound:
                with socket.create_connection(("127.0.0.1", self.target_port), timeout=3) as outbound:
                    first = threading.Thread(target=self._copy, args=(inbound, outbound), daemon=True)
                    second = threading.Thread(target=self._copy, args=(outbound, inbound), daemon=True)
                    first.start(); second.start()
                    first.join(timeout=10); second.join(timeout=10)
        except OSError:
            return

    def _run(self) -> None:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
                self.listener = listener
                listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                listener.bind(("127.0.0.1", self.listen_port))
                listener.listen(16)
                listener.setblocking(False)
                self.ready.set()
                while not self.stop_event.is_set():
                    readable, _, _ = select.select([listener], [], [], 0.1)
                    if not readable:
                        continue
                    inbound, _ = listener.accept()
                    self.connections += 1
                    handler = threading.Thread(target=self._handle, args=(inbound,), daemon=True)
                    self.handlers.append(handler)
                    handler.start()
        except BaseException as exc:
            self.error = exc
            self.ready.set()

    def close(self) -> None:
        self.stop_event.set()
        self.thread.join(timeout=5)
        for handler in self.handlers:
            handler.join(timeout=1)
        if self.error:
            raise self.error


def run_cases(h: Harness, selected: set[str] | None) -> None:
    def case(name: str, fn: Callable[[], None]) -> None:
        if selected is None or name in selected:
            h.case(name, fn)

    def strict_configuration_and_historical_provenance() -> None:
        state = h.runtime / "configuration-a"
        endpoints = [f"127.0.0.1:{free_port()}" for _ in range(9)]
        routes: list[Route] = [
            (f"r{index}", 80 - index, "ENABLED", endpoints[index])
            for index in range(8)
        ]
        good = write_v13_config(
            h, "routes-valid", "A", state, f"127.0.0.1:{free_port()}",
            "routes-v1", [("B", routes, 50, 200, 10, 10_000)],
        )
        checked = h.run("routes-config-valid", ["config-check", "--config", str(good)])
        assert checked is not None
        h.check(checked["format"] == "NATRAV_OVERLAY_CONFIG_V13", "V13 is explicit")
        observed = checked["peers"][0]["routes"]
        h.check(len(observed) == 8, "eight routes accepted")
        h.check(
            [(item["priority"], item["id"]) for item in observed] ==
            sorted((item["priority"], item["id"]) for item in observed),
            "canonical route order follows priority then stable ID",
        )

        too_many = write_v13_config(
            h, "routes-too-many", "A", h.runtime / "too-many",
            f"127.0.0.1:{free_port()}", "too-many-v1",
            [("B", routes + [("r8", 90, "ENABLED", endpoints[8])], 50, 200, 10, 10_000)],
        )
        denied = h.run("routes-too-many-check", ["config-check", "--config", str(too_many)], expected=3)
        h.check(denied is not None and denied["code"] == "CONFIG_TOO_MANY_PEER_ROUTES", "ninth route rejected")

        duplicate = write_v13_config(
            h, "routes-duplicate", "A", h.runtime / "duplicate",
            f"127.0.0.1:{free_port()}", "duplicate-v1",
            [("B", [("same", 0, "ENABLED", endpoints[0]),
                     ("same", 1, "ENABLED", endpoints[1])], 50, 200, 10, 10_000)],
        )
        denied = h.run("routes-duplicate-check", ["config-check", "--config", str(duplicate)], expected=3)
        h.check(denied is not None and denied["code"] == "CONFIG_DUPLICATE_PEER_ROUTE", "duplicate route ID rejected")

        ambiguous = write_v13_config(
            h, "routes-ambiguous", "A", h.runtime / "ambiguous",
            f"127.0.0.1:{free_port()}", "ambiguous-v1",
            [("B", [("one", 0, "ENABLED", endpoints[0]),
                     ("two", 1, "ENABLED", endpoints[0])], 50, 200, 10, 10_000)],
        )
        denied = h.run("routes-ambiguous-check", ["config-check", "--config", str(ambiguous)], expected=3)
        h.check(denied is not None and denied["code"] == "CONFIG_PEER_ROUTE_ENDPOINT_AMBIGUOUS", "one endpoint cannot name two routes")

        missing = write_v13_config(
            h, "routes-missing", "A", h.runtime / "missing",
            f"127.0.0.1:{free_port()}", "missing-v1",
            [("B", [], 50, 200, 10, 10_000)],
        )
        denied = h.run("routes-missing-check", ["config-check", "--config", str(missing)], expected=3)
        h.check(denied is not None and denied["code"] == "CONFIG_PEER_ROUTE_REQUIRED", "routed V13 peer needs an explicit route")

        unknown = good.read_text().replace(
            "peer_route=B,r7,73,ENABLED,", "peer_route=C,r7,73,ENABLED,")
        unknown_path = h.work / "routes-unknown.conf"
        unknown_path.write_text(unknown); unknown_path.chmod(0o600)
        denied = h.run("routes-unknown-check", ["config-check", "--config", str(unknown_path)], expected=3)
        h.check(denied is not None and denied["code"] == "CONFIG_PEER_ROUTE_PEER_UNKNOWN", "route cannot name an absent peer")

        # Durable configuration history keeps endpoint-to-peer provenance. A
        # later candidate may move B, but cannot silently reuse B's old address
        # as a route for C.
        old_port, moved_port = free_port(), free_port()
        live_state = h.runtime / "history-a"
        old = write_v13_config(
            h, "history-old", "A", live_state, f"127.0.0.1:{free_port()}",
            "history-v1", [("B", [("old", 0, "ENABLED", f"127.0.0.1:{old_port}")],
                                  50, 200, 10, 10_000)],
        )
        daemon = h.start("history-a", old, live_state)
        candidate = write_v13_config(
            h, "history-candidate", "A", live_state,
            next(line.split("=", 1)[1] for line in old.read_text().splitlines() if line.startswith("listen=")),
            "history-v2",
            [
                ("B", [("moved", 0, "ENABLED", f"127.0.0.1:{moved_port}")], 50, 200, 10, 10_000),
                ("C", [("reused", 0, "ENABLED", f"127.0.0.1:{old_port}")], 50, 200, 10, 10_000),
            ],
        )
        denied = activate(h, "historical-route-reassignment", live_state, candidate,
                          expected=3, code="CONFIG_HISTORICAL_ROUTE_CONFLICT")
        h.check(denied["code"] == "CONFIG_HISTORICAL_ROUTE_CONFLICT", "historical endpoint cannot switch peer identity")
        daemon.shutdown()

    case("strict_v13_configuration_and_route_provenance", strict_configuration_and_historical_provenance)

    def ipv4_failure_ipv6_success() -> None:
        root = h.runtime / "ipv6-failover"; root.mkdir()
        a_state, b_state = root / "a", root / "b"
        absent, b_port = free_port(), free_port()
        scope = "routes/ipv6"
        a_conf = write_v13_config(
            h, "ipv6-a", "A", a_state, f"127.0.0.1:{free_port()}", "ipv6-a1",
            [("B", [("preferred-v4", 0, "ENABLED", f"127.0.0.1:{absent}"),
                     ("secondary-v6", 10, "ENABLED", f"[::1]:{b_port}")],
              50, 200, 20, 20_000)],
        )
        b_conf = write_v13_config(
            h, "ipv6-b", "B", b_state, f"[::1]:{b_port}", "ipv6-b1", [],
            trusts=["A"], authorizations=[("A", scope)],
        )
        b = h.start("ipv6-b", b_conf, b_state)
        a = h.start("ipv6-a", a_conf, a_state)
        op = operation("v13-ipv4-fails-ipv6-succeeds")
        submit(h, "ipv6-submit", a.control, "A", "B", scope, op, "one application attempt")
        status = wait_outbox(h, a_state, op, "ACKED", "ipv6-wait")
        peer = peer_status(status, "B")
        h.check(outbox_entry(status, op)["attempts"] == 1, "route probe failure did not consume application attempt")
        h.check(peer["attempts_this_run"] == 1, "one application request issued")
        h.check(route_status(peer, "preferred-v4")["connection_attempts_this_run"] >= 1, "preferred route attempted")
        h.check(route_status(peer, "preferred-v4")["connection_successes_this_run"] == 0, "unavailable route not relabeled successful")
        h.check(route_status(peer, "secondary-v6")["connection_successes_this_run"] == 1, "IPv6 fallback authenticated")
        h.check(peer["selected_route"] == "secondary-v6", "selected route is observable")
        h.check(h.status("ipv6-b-status", b_state)["inbound_records"] == 1, "recipient admitted exactly once")
        a.shutdown(); b.shutdown()

    case("preferred_ipv4_unavailable_secondary_ipv6_succeeds", ipv4_failure_ipv6_success)

    def wrong_tls_identity_then_correct_peer() -> None:
        root = h.runtime / "identity-failover"; root.mkdir()
        a_state, b_state, c_state = root / "a", root / "b", root / "c"
        b_port, c_port = free_port(), free_port()
        scope = "routes/identity"
        b_conf = write_v13_config(
            h, "identity-b", "B", b_state, f"127.0.0.1:{b_port}", "identity-b1", [],
            trusts=["A"], authorizations=[("A", scope)],
        )
        c_conf = write_v13_config(
            h, "identity-c", "C", c_state, f"127.0.0.1:{c_port}", "identity-c1", [],
            trusts=["A"], authorizations=[("A", scope)],
        )
        a_conf = write_v13_config(
            h, "identity-a", "A", a_state, f"127.0.0.1:{free_port()}", "identity-a1",
            [("B", [("wrong-key", 0, "ENABLED", f"127.0.0.1:{c_port}"),
                     ("correct-key", 1, "ENABLED", f"127.0.0.1:{b_port}")],
              50, 200, 20, 20_000)],
        )
        b = h.start("identity-b", b_conf, b_state)
        c = h.start("identity-c", c_conf, c_state)
        a = h.start("identity-a", a_conf, a_state)
        op = operation("wrong-route-cannot-change-peer-identity")
        submit(h, "identity-submit", a.control, "A", "B", scope, op, "bind TLS to B")
        status = wait_outbox(h, a_state, op, "ACKED", "identity-wait")
        peer = peer_status(status, "B")
        wrong = route_status(peer, "wrong-key")
        good = route_status(peer, "correct-key")
        h.check(wrong["connection_attempts_this_run"] >= 1 and wrong["connection_successes_this_run"] == 0,
                "wrong certificate route cannot authenticate as B")
        h.check(wrong["last_failure_code"] is not None, "wrong-identity failure classified")
        h.check(good["connection_successes_this_run"] == 1, "correct identity route succeeds")
        h.check(outbox_entry(status, op)["attempts"] == 1, "TLS route mismatch did not spend an application attempt")
        h.check(h.status("identity-b-status", b_state)["inbound_records"] == 1, "B admitted once")
        h.check(h.status("identity-c-status", c_state)["inbound_records"] == 0, "wrong endpoint admitted nothing")
        a.shutdown(); b.shutdown(); c.shutdown()

    case("tls_identity_mismatch_fails_over_before_application_attempt", wrong_tls_identity_then_correct_peer)

    def unavailable_routes_do_not_block_other_peer_and_survive_restart() -> None:
        root = h.runtime / "unavailable"; root.mkdir()
        a_state, b_state, c_state = root / "a", root / "b", root / "c"
        b_primary, b_secondary, c_port = free_port(), free_port(), free_port()
        scope = "routes/progress"
        a_conf = write_v13_config(
            h, "unavailable-a", "A", a_state, f"127.0.0.1:{free_port()}", "unavailable-a1",
            [
                ("B", [("b-one", 0, "ENABLED", f"127.0.0.1:{b_primary}"),
                        ("b-two", 1, "ENABLED", f"127.0.0.1:{b_secondary}")],
                 50, 100, 20, 20_000),
                ("C", [("c-direct", 0, "ENABLED", f"127.0.0.1:{c_port}")],
                 50, 100, 20, 20_000),
            ],
        )
        b_conf = write_v13_config(
            h, "unavailable-b", "B", b_state, f"127.0.0.1:{b_secondary}", "unavailable-b1", [],
            trusts=["A"], authorizations=[("A", scope)],
        )
        c_conf = write_v13_config(
            h, "unavailable-c", "C", c_state, f"127.0.0.1:{c_port}", "unavailable-c1", [],
            trusts=["A"], authorizations=[("A", scope)],
        )
        c = h.start("unavailable-c", c_conf, c_state)
        a = h.start("unavailable-a", a_conf, a_state)
        op_b, op_c = operation("routes-unavailable-b"), operation("routes-available-c")
        submit(h, "unavailable-submit-b", a.control, "A", "B", scope, op_b, "pending B")
        submit(h, "unavailable-submit-c", a.control, "A", "C", scope, op_c, "progress C")
        status = wait_outbox(h, a_state, op_c, "ACKED", "unavailable-c-progress")
        b_entry = outbox_entry(status, op_b)
        b_peer = peer_status(status, "B")
        h.check(b_entry["status"] == "PENDING" and b_entry["attempts"] == 0,
                "all route-open failures preserve pending work and attempt budget")
        h.check(b_peer["attempts_this_run"] == 0, "no B application request was issued")
        h.check(sum(item["connection_attempts_this_run"] for item in b_peer["routes"]) >= 2,
                "both B routes receive bounded probes")
        h.check(h.status("unavailable-c-status", c_state)["inbound_records"] == 1,
                "other peer progresses independently")

        a.kill()
        a = h.start("unavailable-a-restart", a_conf, a_state)
        restored = h.status("unavailable-restored", a_state)
        h.check(outbox_entry(restored, op_b)["attempts"] == 0,
                "restart reconstructs unissued peer obligation exactly")
        h.check(peer_status(restored, "B")["attempts_this_run"] == 0,
                "run-scoped route observations do not fabricate durable attempts")
        b = h.start("unavailable-b", b_conf, b_state)
        h.run("unavailable-wake-b", ["wake", "--control", str(a.control), "--peer", "B"])
        final = wait_outbox(h, a_state, op_b, "ACKED", "unavailable-b-recovered")
        h.check(outbox_entry(final, op_b)["attempts"] == 1, "recovered secondary route issues once")
        h.check(h.status("unavailable-b-status", b_state)["inbound_records"] == 1, "recovered recipient admits once")
        a.shutdown(); b.shutdown(); c.shutdown()

    case("all_routes_unavailable_other_peer_progress_and_restart", unavailable_routes_do_not_block_other_peer_and_survive_restart)

    def preferred_route_recovery_and_duplicate_safe_failover() -> None:
        root = h.runtime / "recovery"; root.mkdir()
        a_state, b_state = root / "a", root / "b"
        b_port, relay_port = free_port(), free_port()
        scope = "routes/recovery"
        dropped = operation("route-response-loss")
        b_conf = write_v13_config(
            h, "recovery-b", "B", b_state, f"127.0.0.1:{b_port}", "recovery-b1", [],
            trusts=["A"], authorizations=[("A", scope)],
            session_operations=1,
        )
        a_conf = write_v13_config(
            h, "recovery-a", "A", a_state, f"127.0.0.1:{free_port()}", "recovery-a1",
            [("B", [("preferred-relay", 0, "ENABLED", f"127.0.0.1:{relay_port}"),
                     ("secondary-direct", 10, "ENABLED", f"127.0.0.1:{b_port}")],
              500, 500, 20, 30_000)],
            session_operations=1,
        )
        b = h.start(
            "recovery-b", b_conf, b_state,
            {"NATRAV_OVERLAY_TEST_SESSION_DROP_AFTER_ADMISSION_OPERATION": dropped},
        )
        a = h.start("recovery-a", a_conf, a_state)
        first = operation("route-secondary-first")
        submit(h, "recovery-first", a.control, "A", "B", scope, first, "secondary")
        first_status = wait_outbox(h, a_state, first, "ACKED", "recovery-first-wait")
        h.check(route_status(peer_status(first_status, "B"), "secondary-direct")["connection_successes_this_run"] >= 1,
                "secondary route used while preferred route unavailable")

        relay = TcpRelay(relay_port, b_port); relay.start()
        time.sleep(0.55)
        second = operation("route-preferred-recovered")
        submit(h, "recovery-second", a.control, "A", "B", scope, second, "preferred recovered")
        second_status = wait_outbox(h, a_state, second, "ACKED", "recovery-second-wait")
        h.check(route_status(peer_status(second_status, "B"), "preferred-relay")["connection_successes_this_run"] >= 1,
                "recovered preferred route deterministically regains selection")

        submit(h, "recovery-drop", a.control, "A", "B", scope, dropped, "admitted before response loss")
        h.wait("recipient exercised response-loss hook", lambda: "TEST_SESSION_DROP_AFTER_ADMISSION" in b.stderr_path.read_text(), 5)
        relay.close()
        final = wait_outbox(h, a_state, dropped, "ACKED", "recovery-drop-wait", 12)
        entry = outbox_entry(final, dropped)
        peer = peer_status(final, "B")
        h.check(entry["attempts"] == 2, "lost response uses one retry, not one attempt per route probe")
        h.check(route_status(peer, "secondary-direct")["connection_successes_this_run"] >= 2,
                "secondary route recovers after preferred session loss")
        recipient = h.status("recovery-b-status", b_state)
        h.check(recipient["inbound_records"] == 3, "three distinct operations admitted once")
        h.check(recipient["service"]["peer_duplicate"] >= 1, "recipient observed duplicate-safe replay")
        a.shutdown(); b.shutdown()

    case("preferred_route_recovery_and_duplicate_safe_failover", preferred_route_recovery_and_duplicate_safe_failover)

    def live_route_change_selectively_retires_sessions() -> None:
        root = h.runtime / "live-change"; root.mkdir()
        a_state, b_state, c_state = root / "a", root / "b", root / "c"
        b_port, relay_port, c_port = free_port(), free_port(), free_port()
        scope = "routes/live"
        relay = TcpRelay(relay_port, b_port); relay.start()
        a_listen = f"127.0.0.1:{free_port()}"
        a_conf = write_v13_config(
            h, "live-a", "A", a_state, a_listen, "live-a1",
            [
                ("B", [("b-primary", 0, "ENABLED", f"127.0.0.1:{b_port}"),
                        ("b-backup", 10, "ENABLED", f"127.0.0.1:{relay_port}")],
                 50, 100, 20, 30_000),
                ("C", [("c-primary", 0, "ENABLED", f"127.0.0.1:{c_port}")],
                 50, 100, 20, 30_000),
            ], session_idle_ms=10_000,
        )
        b_conf = write_v13_config(
            h, "live-b", "B", b_state, f"127.0.0.1:{b_port}", "live-b1", [],
            trusts=["A"], authorizations=[("A", scope)], session_idle_ms=10_000,
        )
        c_conf = write_v13_config(
            h, "live-c", "C", c_state, f"127.0.0.1:{c_port}", "live-c1", [],
            trusts=["A"], authorizations=[("A", scope)], session_idle_ms=10_000,
        )
        b = h.start("live-b", b_conf, b_state)
        c = h.start("live-c", c_conf, c_state)
        a = h.start("live-a", a_conf, a_state)
        warm_b, warm_c = operation("live-warm-b"), operation("live-warm-c")
        submit(h, "live-warm-b", a.control, "A", "B", scope, warm_b, "warm B")
        submit(h, "live-warm-c", a.control, "A", "C", scope, warm_c, "warm C")
        wait_outbox(h, a_state, warm_b, "ACKED", "live-warm-b-wait")
        before = wait_outbox(h, a_state, warm_c, "ACKED", "live-warm-c-wait")
        b_before, c_before = peer_status(before, "B"), peer_status(before, "C")
        h.check(b_before["selected_route"] == "b-primary", "B opened primary route")
        h.check(c_before["selected_route"] == "c-primary", "C opened its route")

        changed = write_v13_config(
            h, "live-a-changed", "A", a_state, a_listen, "live-a2",
            [
                ("B", [("b-backup", 0, "ENABLED", f"127.0.0.1:{relay_port}")],
                 50, 100, 20, 30_000),
                ("C", [("c-primary", 0, "ENABLED", f"127.0.0.1:{c_port}")],
                 50, 100, 20, 30_000),
            ], session_idle_ms=10_000,
        )
        activate(h, "live-route-activation", a_state, changed)
        after_b, after_c = operation("live-after-b"), operation("live-after-c")
        submit(h, "live-submit-b", a.control, "A", "B", scope, after_b, "through backup")
        submit(h, "live-submit-c", a.control, "A", "C", scope, after_c, "unchanged C")
        wait_outbox(h, a_state, after_b, "ACKED", "live-after-b-wait")
        final = wait_outbox(h, a_state, after_c, "ACKED", "live-after-c-wait")
        b_after, c_after = peer_status(final, "B"), peer_status(final, "C")
        h.check(b_after["configuration_drains"] == b_before["configuration_drains"] + 1,
                "changed B route contract retires B session")
        h.check(b_after["selected_route"] == "b-backup", "B selects remaining route")
        h.check(route_status(b_after, "b-backup")["connection_successes_this_run"] >= 1,
                "remaining route reaches same authenticated B identity")
        h.check(c_after["session"]["opened"] == c_before["session"]["opened"],
                "unaffected C session is reused")
        h.check(c_after["configuration_drains"] == c_before["configuration_drains"],
                "unaffected C contract is not drained")
        h.check(h.status("live-b-status", b_state)["inbound_records"] == 2, "B admits both operations once")
        h.check(h.status("live-c-status", c_state)["inbound_records"] == 2, "C admits both operations once")
        a.shutdown(); b.shutdown(); c.shutdown(); relay.close()

    case("live_route_removal_reprioritization_and_selective_session_drain", live_route_change_selectively_retires_sessions)

    def authenticated_compaction_encrypted_restore_and_relocation() -> None:
        root = h.runtime / "maintenance"; root.mkdir(mode=0o700)
        a_state, b_state = root / "a", root / "b"
        b_port, absent = free_port(), free_port()
        scope = "routes/maintenance"
        a_listen = f"127.0.0.1:{free_port()}"
        a_conf = write_v13_config(
            h, "maintenance-a", "A", a_state, a_listen, "maintenance-a1",
            [("B", [("preferred-absent", 0, "ENABLED", f"127.0.0.1:{absent}"),
                     ("secondary-live", 10, "ENABLED", f"127.0.0.1:{b_port}")],
              50, 200, 30, 60_000)],
            session_operations=1,
        )
        b_conf = write_v13_config(
            h, "maintenance-b", "B", b_state, f"127.0.0.1:{b_port}", "maintenance-b1", [],
            trusts=["A"], authorizations=[("A", scope)], session_operations=1,
        )
        b = h.start("maintenance-b", b_conf, b_state)
        a = h.start("maintenance-a", a_conf, a_state)
        first = operation("maintenance-first")
        submit(h, "maintenance-first", a.control, "A", "B", scope, first, "before backup")
        wait_outbox(h, a_state, first, "ACKED", "maintenance-first-wait")
        b.shutdown()
        pending = operation("maintenance-pending")
        submit(h, "maintenance-pending", a.control, "A", "B", scope, pending, "survive maintenance")
        h.wait("maintenance pending visible", lambda: outbox_entry(h.status("maintenance-pending-status", a_state), pending)["status"] == "PENDING")
        h.run("maintenance-compact", ["compact", "--control", str(a.control), "--deadline-ms", "10000"], timeout=20)
        a.shutdown()

        state_key = new_state_key(h, root, "route-state-g1")
        migrate_state(h, "maintenance-state-migrate", a_state, state_key)
        audit = h.run("maintenance-auth-audit", [
            "state-auth-audit", "--state", str(a_state), "--node", "A",
            "--state-auth-key", str(state_key),
        ])
        h.check(audit is not None and audit["status"] == "COMPLETE", "route state authenticates before backup")
        before = keyed_inspect(h, "maintenance-before-backup", a_state, state_key)

        backup_key = root / "route-backup.key"
        h.run("maintenance-backup-key", ["backup-key-init", "--output", str(backup_key), "--generation", "route-backup-g1"])
        archive = root / "route-state.nob"
        identity = h.identity("A")
        exported = h.run("maintenance-export", [
            "backup-export", "--state", str(a_state), "--node", "A", "--generation", "a-g1",
            "--output", str(archive), "--sign-key", str(identity.private_key),
            "--sign-cert", str(identity.certificate), "--encrypt-key", str(backup_key),
            "--state-auth-key", str(state_key),
        ], timeout=30)
        h.check(exported is not None and exported["encrypted"], "route state exported as signed encrypted backup")
        h.run("maintenance-verify", [
            "backup-verify", "--input", str(archive), "--decrypt-key", str(backup_key),
            "--trusted-cert", str(identity.certificate), "--require-signature", "yes",
            "--state-auth-key", str(state_key),
        ], timeout=30)
        restored = root / "restored"
        h.run("maintenance-restore", [
            "backup-restore", "--input", str(archive), "--destination", str(restored),
            "--node", "A", "--generation", "a-g1", "--decrypt-key", str(backup_key),
            "--trusted-cert", str(identity.certificate), "--require-signature", "yes",
            "--state-auth-key", str(state_key),
        ], timeout=30)
        after = keyed_inspect(h, "maintenance-restored-inspect", restored, state_key)
        h.check(before["storage"]["logical_state_digest"] == after["storage"]["logical_state_digest"],
                "multi-route obligations survive authenticated encrypted restore")

        relocated = write_v13_config(
            h, "maintenance-a-relocated", "A", restored, a_listen, "maintenance-a2",
            [("B", [("preferred-absent", 0, "ENABLED", f"127.0.0.1:{absent}"),
                     ("secondary-live", 10, "ENABLED", f"127.0.0.1:{b_port}")],
              50, 200, 30, 60_000)], session_operations=1,
        )
        h.run("maintenance-relocate", [
            "state-relocate", "--state", str(restored), "--node", "A",
            "--candidate", str(relocated), "--reason", "promote V13 restored state",
            "--state-auth-key", str(state_key),
        ], timeout=30)
        b = h.start("maintenance-b-restored", b_conf, b_state)
        a = start_keyed(h, "maintenance-a-restored", relocated, restored, state_key)
        final = wait_outbox(h, restored, pending, "ACKED", "maintenance-restored-delivery", 15)
        peer = peer_status(final, "B")
        h.check(len(peer["routes"]) == 2, "V13 route set reconstructs after relocation")
        h.check(route_status(peer, "secondary-live")["connection_successes_this_run"] >= 1,
                "restored pending obligation uses available secondary route")
        h.check(h.status("maintenance-b-final", b_state)["inbound_records"] == 2,
                "recipient retains pre-backup and restored deliveries once")
        a.shutdown(); b.shutdown()
        audit = h.run("maintenance-final-audit", [
            "state-auth-audit", "--state", str(restored), "--node", "A",
            "--state-auth-key", str(state_key),
        ])
        h.check(audit is not None and audit["status"] == "COMPLETE", "continued route state remains authenticated")

    case("authenticated_compaction_encrypted_restore_and_relocation", authenticated_compaction_encrypted_restore_and_relocation)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--case", action="append")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not exist")
    harness = Harness(args.binary, args.output)
    started = time.time(); passed = False
    try:
        run_cases(harness, set(args.case) if args.case else None)
        passed = True
    except BaseException as error:
        (harness.output / "FAILURE.txt").write_text(f"{type(error).__name__}: {error}\n")
        print(f"FAIL: {type(error).__name__}: {error}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_MULTI_ROUTE_TESTS_V1",
            "status": "PASS" if passed else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_total": len(harness.cases),
            "cases_passed": sum(item["status"] == "PASS" for item in harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (("SUMMARY", summary), ("CASES", harness.cases), ("COMMANDS", harness.commands)):
            (harness.output / f"{name}.json").write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
