#!/usr/bin/env python3
"""TLS 1.3 mutual-authentication, downgrade, tamper, and rotation tests."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import ssl
import subprocess
import time
from typing import Any

from run_integration import (
    decode_app,
    encode_record,
    frame,
    hello,
    recv_frame_bytes,
)
from run_persistent import Daemon, Harness, free_port, operation


def write_config(
    h: Harness,
    name: str,
    node: str,
    state: Path,
    port: int,
    identity_label: str,
    peers: list[tuple[str, int, str, int, int, int, int]],
    trusts: list[tuple[str, str]] | None = None,
    deadline_ms: int = 700,
) -> Path:
    identity = h.identity(identity_label)
    def generation(label: str) -> str:
        return "g-" + label.lower()

    lines = [
        "NATRAV_OVERLAY_CONFIG_V6",
        f"node={node}",
        f"state={state}",
        f"listen=127.0.0.1:{port}",
        "control=control.sock",
        f"identity_cert={identity.certificate}",
        f"identity_key={identity.private_key}",
        f"identity_pin={identity.spki_sha256}",
        f"identity_generation={generation(identity_label)}",
        f"deadline_ms={deadline_ms}",
        "peer_workers=4",
        "peer_queue_capacity=64",
        "control_workers=2",
        "control_queue_capacity=64",
    ]
    active: dict[str, tuple[str, str]] = {}
    configured: set[tuple[str, str]] = set()
    authorized_peers: set[str] = set()
    for peer, peer_port, peer_identity, initial, maximum, attempts, expiry in peers:
        pin = h.identity(peer_identity).spki_sha256
        key_generation = generation(peer_identity)
        lines.append(
            f"peer={peer},127.0.0.1:{peer_port},"
            f"{initial},{maximum},{attempts},{expiry}"
        )
        lines.append(
            f"peer_key={peer},{key_generation},ACTIVE,{pin}"
        )
        active[peer] = (key_generation, pin)
        configured.add((peer, pin))
        authorized_peers.add(peer)
    inbound_seen: set[str] = set()
    for peer, peer_identity in trusts or []:
        pin = h.identity(peer_identity).spki_sha256
        if (peer, pin) in configured:
            continue
        state_name = "RETIRED" if peer in active or peer in inbound_seen else "ACTIVE"
        lines.append(
            f"peer_key={peer},{generation(peer_identity)},{state_name},{pin}"
        )
        configured.add((peer, pin))
        inbound_seen.add(peer)
        authorized_peers.add(peer)
    for peer in sorted(authorized_peers):
        for scope in ("test/tls", "test/tls-independent", "test/rotation"):
            lines.append(f"authorize={peer},*,EVIDENCE,{scope}")
    path = h.work / f"{name}.conf"
    path.write_text("\n".join(lines) + "\n")
    path.chmod(0o644)
    return path


def client_context(h: Harness, identity_label: str) -> ssl.SSLContext:
    identity = h.identity(identity_label)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.maximum_version = ssl.TLSVersion.TLSv1_3
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    context.load_cert_chain(str(identity.certificate), str(identity.private_key))
    context.set_alpn_protocols(["natrav-overlay/1"])
    return context


def independent_delivery(
    h: Harness,
    port: int,
    identity_label: str,
    claimed_node: str,
    recipient: str,
    operation_id: str,
    payload: bytes,
) -> dict[str, Any]:
    context = client_context(h, identity_label)
    with socket.create_connection(("127.0.0.1", port), timeout=3) as raw:
        with context.wrap_socket(raw, server_hostname=None) as channel:
            h.check(channel.version() == "TLSv1.3", "independent client negotiated TLS 1.3")
            h.check(channel.selected_alpn_protocol() == "natrav-overlay/1", "ALPN is exact")
            cipher = channel.cipher()
            h.check(cipher is not None and cipher[1] == "TLSv1.3", "TLS 1.3 cipher reported")
            request = operation("independent-request-" + operation_id)
            channel.sendall(frame(hello(claimed_node, request)))
            _, ack = recv_frame_bytes(channel)
            decoded_ack = json.loads(ack)
            h.check(decoded_ack["kind"] == "HELLO_ACK", "independent client received HELLO_ACK")
            record = encode_record(
                operation_id, claimed_node, recipient, "test/tls-independent", payload)
            channel.sendall(frame(record))
            _, receipt = recv_frame_bytes(channel)
            decoded = decode_app(receipt)
            h.check(decoded["kind"] == "receipt", "independent client received receipt")
            return decoded


def wait_completed(h: Harness, state: Path, minimum: int) -> dict[str, Any]:
    latest: dict[str, Any] = {}

    def ready() -> bool:
        latest.clear()
        latest.update(h.status("tls-wait-completed", state))
        return latest["service"]["peer_completed"] >= minimum

    h.wait(f"{minimum} peer connections completed", ready, 6.0)
    return latest


def run_suite(h: Harness) -> None:
    def secure_delivery() -> None:
        root = h.runtime / "secure-delivery"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        a_conf = write_config(
            h, "secure-a", "A", a_state, a_port, "A",
            [("B", b_port, "B", 50, 200, 8, 15_000)],
            trusts=[("B", "B")],
        )
        b_conf = write_config(
            h, "secure-b", "B", b_state, b_port, "B", [],
            trusts=[("A", "A")],
        )
        b = h.start("secure-b", b_conf, b_state)
        a = h.start("secure-a", a_conf, a_state)
        first = operation("secure-cpp-delivery")
        h.run(
            "secure-submit",
            ["submit", "--control", str(a.control), "--node", "A", "--peer", "B",
             "--scope", "test/tls", "--operation", first, "--payload-text", "encrypted"],
        )
        h.wait(
            "C++ TLS delivery acknowledged",
            lambda: h.status("secure-wait", a_state)["outbox"]["acked"] == 1,
        )
        a_status = h.status("secure-a-status", a_state)
        b_status = h.status("secure-b-status", b_state)
        h.check(a_status["transport"] == "TLS1.3_MTLS_KEY_GENERATION_V1", "runtime reports protected transport")
        h.check(
            a_status["outbox"]["entries"][0]["peer_spki_sha256"] == h.identity("B").spki_sha256,
            "outbound obligation records B key pin",
        )
        h.check(b_status["service"]["peer_authenticated"] >= 1, "recipient counted authenticated peer")
        h.check(b_status["inbound_records"] == 1, "recipient committed C++ TLS delivery")

        second = operation("secure-independent-delivery")
        receipt = independent_delivery(h, b_port, "A", "A", "B", second, b"python-tls-client")
        h.check(receipt["operation"] == second, "independent receipt binds operation")
        h.check(receipt["recipient"] == "B", "independent receipt binds recipient")
        h.wait(
            "independent TLS delivery committed",
            lambda: h.status("secure-independent-status", b_state)["inbound_records"] == 2,
        )
        a.shutdown(); b.shutdown()
        snapshot = h.run("secure-a-offline", ["inspect", "--state", str(a_state), "--node", "A"])
        assert snapshot is not None
        h.check(
            snapshot["outbox"]["entries"][0]["delivery"]["peer_spki_sha256"] ==
            h.identity("B").spki_sha256,
            "durable journal reconstructs peer key pin",
        )

    h.case("tls13_mutual_delivery_and_independent_client", secure_delivery)

    def rejection_surface() -> None:
        root = h.runtime / "rejections"
        root.mkdir()
        b_state = root / "b"
        b_port = free_port()
        b_conf = write_config(
            h, "reject-b", "B", b_state, b_port, "B", [],
            trusts=[("A", "A")], deadline_ms=500,
        )
        b = h.start("reject-b", b_conf, b_state)

        # Plaintext framed HELLO cannot be interpreted as TLS.
        with socket.create_connection(("127.0.0.1", b_port), timeout=2) as plain:
            plain.sendall(frame(hello("A", operation("plaintext-request"))))
        wait_completed(h, b_state, 1)

        # A TLS 1.2-only client cannot negotiate a downgrade.
        a_identity = h.identity("A")
        downgraded = subprocess.run(
            ["openssl", "s_client", "-connect", f"127.0.0.1:{b_port}", "-tls1_2",
             "-alpn", "natrav-overlay/1", "-cert", str(a_identity.certificate),
             "-key", str(a_identity.private_key)],
            input="", text=True, capture_output=True, timeout=5,
        )
        h.check(downgraded.returncode != 0, "TLS 1.2 downgrade rejected")
        wait_completed(h, b_state, 2)

        # TLS 1.3 without a client certificate cannot enter the application protocol.
        no_certificate = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        no_certificate.minimum_version = ssl.TLSVersion.TLSv1_3
        no_certificate.maximum_version = ssl.TLSVersion.TLSv1_3
        no_certificate.check_hostname = False
        no_certificate.verify_mode = ssl.CERT_NONE
        no_certificate.set_alpn_protocols(["natrav-overlay/1"])
        try:
            with socket.create_connection(("127.0.0.1", b_port), timeout=2) as raw:
                with no_certificate.wrap_socket(raw, server_hostname=None) as channel:
                    channel.sendall(frame(hello("A", operation("missing-certificate"))))
                    channel.recv(1)
        except (ssl.SSLError, ConnectionError, OSError):
            pass
        wait_completed(h, b_state, 3)

        # A mutually authenticated client must also negotiate the exact protocol ALPN.
        wrong_alpn = client_context(h, "A")
        wrong_alpn.set_alpn_protocols(["not-natrav-overlay"])
        try:
            with socket.create_connection(("127.0.0.1", b_port), timeout=2) as raw:
                with wrong_alpn.wrap_socket(raw, server_hostname=None) as channel:
                    channel.sendall(frame(hello("A", operation("wrong-alpn"))))
                    channel.recv(1)
        except (ssl.SSLError, ConnectionError, OSError):
            pass
        wait_completed(h, b_state, 4)

        # A valid but unknown key completes cryptography and is rejected before HELLO.
        unknown_context = client_context(h, "UNKNOWN")
        try:
            with socket.create_connection(("127.0.0.1", b_port), timeout=2) as raw:
                with unknown_context.wrap_socket(raw, server_hostname=None) as channel:
                    channel.sendall(frame(hello("UNKNOWN", operation("unknown-key-request"))))
                    try:
                        channel.recv(1)
                    except (ssl.SSLError, ConnectionError, OSError):
                        pass
        except (ssl.SSLError, ConnectionError, OSError):
            pass
        wait_completed(h, b_state, 5)

        # The trusted A key cannot claim a different HELLO node identity.
        mismatch_context = client_context(h, "A")
        with socket.create_connection(("127.0.0.1", b_port), timeout=2) as raw:
            with mismatch_context.wrap_socket(raw, server_hostname=None) as channel:
                channel.sendall(frame(hello("X", operation("claimed-node-mismatch"))))
                _, ack = recv_frame_bytes(channel)
                h.check(json.loads(ack)["kind"] == "HELLO_ACK", "mismatch reached HELLO identity check")
        wait_completed(h, b_state, 6)

        # After a valid authenticated HELLO, inject bytes that are not a valid TLS record.
        altered_context = client_context(h, "A")
        raw = socket.create_connection(("127.0.0.1", b_port), timeout=2)
        channel = altered_context.wrap_socket(raw, server_hostname=None)
        channel.sendall(frame(hello("A", operation("altered-record-request"))))
        _, ack = recv_frame_bytes(channel)
        h.check(json.loads(ack)["kind"] == "HELLO_ACK", "altered test completed authenticated HELLO")
        detached = channel.detach()
        forged = socket.socket(fileno=detached)
        forged.sendall(b"\x17\x03\x03\x00\x10" + b"\x00" * 16)
        forged.close()
        wait_completed(h, b_state, 7)

        status = h.status("reject-final-status", b_state)
        h.check(status["inbound_records"] == 0, "rejected traffic admitted no evidence")
        h.check(status["service"]["peer_authenticated"] >= 2, "identity/tamper cases authenticated before rejection")
        h.check(status["service"]["peer_transport_errors"] >= 7, "transport rejections are accounted")
        b.shutdown()
        errors = b.stderr_path.read_text()
        for code in (
            "TLS_HANDSHAKE_FAILED", "TLS_PEER_UNTRUSTED",
            "TLS_NODE_ID_MISMATCH", "TLS_READ_FAILED",
        ):
            h.check(code in errors, f"server retained typed {code} diagnostic")

    h.case("plaintext_downgrade_unknown_identity_and_tamper_rejection", rejection_surface)

    def outbound_pin_rejection() -> None:
        root = h.runtime / "wrong-pin"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        a_conf = write_config(
            h, "wrong-pin-a", "A", a_state, a_port, "A",
            [("B", b_port, "WRONG-B", 300, 300, 5, 15_000)],
            trusts=[("B", "WRONG-B")], deadline_ms=500,
        )
        b_conf = write_config(
            h, "wrong-pin-b", "B", b_state, b_port, "B", [],
            trusts=[("A", "A")], deadline_ms=500,
        )
        b = h.start("wrong-pin-b", b_conf, b_state)
        a = h.start("wrong-pin-a", a_conf, a_state)
        op_id = operation("wrong-server-pin")
        h.run(
            "wrong-pin-submit",
            ["submit", "--control", str(a.control), "--node", "A", "--peer", "B",
             "--scope", "test/tls", "--operation", op_id, "--payload-text", "must not arrive"],
        )
        observed: dict[str, Any] = {}

        def rejected() -> bool:
            observed.clear(); observed.update(h.status("wrong-pin-wait", a_state))
            entry = observed["outbox"]["entries"][0]
            return entry["attempts"] >= 1 and entry["last_error_code"] == "TLS_PEER_PIN_MISMATCH"

        h.wait("wrong server key rejected", rejected)
        h.check(observed["outbox"]["acked"] == 0, "wrong pin produced no receipt")
        h.check(
            observed["outbox"]["entries"][0]["peer_spki_sha256"] == h.identity("WRONG-B").spki_sha256,
            "attempt used exact durable expected pin",
        )
        h.check(h.status("wrong-pin-b-status", b_state)["inbound_records"] == 0, "wrong-pin server admitted nothing")
        a.shutdown(); b.shutdown()

    h.case("outbound_exact_pin_rejection", outbound_pin_rejection)

    def identity_file_protection() -> None:
        root = h.runtime / "identity-files"
        root.mkdir()
        state = root / "state"
        port = free_port()
        valid = write_config(h, "identity-valid", "A", state, port, "A", [])
        checked = h.run("identity-valid-check", ["config-check", "--config", str(valid)])
        h.check(checked is not None and checked["transport"] == "TLS1.3_MTLS_KEY_GENERATION_V1", "valid identity loads")

        identity = h.identity("PERMISSIONS")
        identity.private_key.chmod(0o644)
        bad_mode = write_config(h, "identity-bad-mode", "P", state, port, "PERMISSIONS", [])
        result = h.run("identity-key-mode", ["config-check", "--config", str(bad_mode)], expected=3)
        h.check(result is not None and result["code"] == "TLS_KEY_PERMISSIONS_INVALID", "group-readable key rejected")
        identity.private_key.chmod(0o600)

        target = h.identity("SYMLINK")
        link = h.work / "identity-key-link.pem"
        link.symlink_to(target.private_key)
        symlink_config = write_config(h, "identity-symlink", "S", state, port, "SYMLINK", [])
        text = symlink_config.read_text().replace(
            f"identity_key={target.private_key}", f"identity_key={link}")
        symlink_config.write_text(text)
        result = h.run("identity-key-symlink", ["config-check", "--config", str(symlink_config)], expected=3)
        h.check(result is not None and result["code"] == "TLS_KEY_SYMLINK_REJECTED", "key symlink rejected")

        mismatch = write_config(h, "identity-pin-mismatch", "M", state, port, "M", [])
        wrong_pin = h.identity("OTHER").spki_sha256
        lines = mismatch.read_text().splitlines()
        lines = [f"identity_pin={wrong_pin}" if line.startswith("identity_pin=") else line for line in lines]
        mismatch.write_text("\n".join(lines) + "\n")
        result = h.run("identity-pin-mismatch", ["config-check", "--config", str(mismatch)], expected=3)
        h.check(result is not None and result["code"] == "TLS_IDENTITY_PIN_MISMATCH", "identity pin mismatch rejected")

    h.case("private_key_and_identity_configuration_protection", identity_file_protection)

    def rotation_binding() -> None:
        root = h.runtime / "rotation"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        old_pin = h.identity("B-OLD").spki_sha256
        new_pin = h.identity("B-NEW").spki_sha256
        stage1 = write_config(
            h, "rotation-a-old", "A", a_state, a_port, "A",
            [("B", b_port, "B-OLD", 2000, 2000, 10, 60_000)],
            trusts=[("B", "B-OLD")], deadline_ms=300,
        )
        a = h.start("rotation-a-old", stage1, a_state)
        old_operation = operation("rotation-old-obligation")
        h.run(
            "rotation-submit-old",
            ["submit", "--control", str(a.control), "--node", "A", "--peer", "B",
             "--scope", "test/rotation", "--operation", old_operation,
             "--payload-text", "bound to old key"],
        )
        old_status: dict[str, Any] = {}

        def first_attempt() -> bool:
            old_status.clear(); old_status.update(h.status("rotation-old-wait", a_state))
            return old_status["outbox"]["entries"][0]["attempts"] == 1

        h.wait("old-key obligation attempted once", first_attempt)
        h.check(old_status["outbox"]["entries"][0]["peer_spki_sha256"] == old_pin, "old key bound durably")
        a.shutdown()

        b_conf = write_config(
            h, "rotation-b-new", "B", b_state, b_port, "B-NEW", [],
            trusts=[("A", "A")], deadline_ms=500,
        )
        rotated = write_config(
            h, "rotation-a-new", "A", a_state, a_port, "A",
            [("B", b_port, "B-NEW", 50, 100, 5, 30_000)],
            trusts=[("B", "B-OLD"), ("B", "B-NEW")], deadline_ms=500,
        )
        b = h.start("rotation-b-new", b_conf, b_state)
        a2 = h.start("rotation-a-new", rotated, a_state)
        rotated_status: dict[str, Any] = {}

        def old_key_mismatch() -> bool:
            rotated_status.clear(); rotated_status.update(
                h.status("rotation-old-key-mismatch", a_state))
            old_entry = rotated_status["outbox"]["entries"][0]
            return (
                old_entry["attempts"] >= 2 and
                old_entry["status"] == "PENDING" and
                old_entry["last_error_code"] == "TLS_PEER_PIN_MISMATCH"
            )

        h.wait(
            "old-key obligation remains old-bound after exact-pin rejection",
            old_key_mismatch,
            8.0,
        )
        old_entry = rotated_status["outbox"]["entries"][0]
        h.check(old_entry["peer_spki_sha256"] == old_pin, "configuration rotation did not reinterpret old obligation")
        h.check(h.status("rotation-b-empty", b_state)["inbound_records"] == 0, "new B did not receive old-bound work")

        new_operation = operation("rotation-new-obligation")
        h.run(
            "rotation-submit-new",
            ["submit", "--control", str(a2.control), "--node", "A", "--peer", "B",
             "--scope", "test/rotation", "--operation", new_operation,
             "--payload-text", "bound to new key"],
        )
        h.wait(
            "new-key obligation delivered",
            lambda: h.status("rotation-new-wait", a_state)["outbox"]["acked"] == 1,
        )
        final = h.status("rotation-final", a_state)
        entries = {entry["operation_id"]: entry for entry in final["outbox"]["entries"]}
        h.check(entries[old_operation]["peer_spki_sha256"] == old_pin, "old binding retained")
        h.check(entries[old_operation]["status"] == "PENDING", "old-key work remains a distinct pending obligation")
        h.check(entries[new_operation]["peer_spki_sha256"] == new_pin, "new work binds active key")
        h.check(entries[new_operation]["status"] == "ACKED", "new-key work bypassed old-key backoff")
        h.check(h.status("rotation-b-received", b_state)["inbound_records"] == 1, "new B received only new-bound work")
        a2.shutdown(); b.shutdown()
        offline = h.run(
            "rotation-offline",
            ["inspect", "--state", str(a_state), "--node", "A"],
        )
        assert offline is not None
        offline_entries = {
            entry["operation_id"]: entry for entry in offline["outbox"]["entries"]
        }
        h.check(
            offline_entries[old_operation]["delivery"]["peer_spki_sha256"] == old_pin,
            "restart state preserves old-key obligation binding",
        )
        h.check(
            offline_entries[new_operation]["delivery"]["peer_spki_sha256"] == new_pin,
            "restart state preserves new-key receipt binding",
        )

    h.case("durable_peer_key_rotation_boundary", rotation_binding)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, default=Path("node/bin/natrav-overlay"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output directory must not exist")
    harness = Harness(args.binary, args.output)
    started = time.time()
    status = "FAIL"
    return_code = 1
    try:
        run_suite(harness)
        status = "PASS"
        return_code = 0
    except BaseException as exc:
        (harness.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_TLS_SECURITY_TESTS_V1",
            "status": status,
            "binary": str(harness.binary),
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "started_unix": started,
            "elapsed_seconds": time.time() - started,
        }
        (harness.output / "SUMMARY.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
        (harness.output / "CASES.json").write_text(json.dumps(harness.cases, indent=2, sort_keys=True) + "\n")
        (harness.output / "COMMANDS.json").write_text(json.dumps(harness.commands, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary, sort_keys=True))
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
