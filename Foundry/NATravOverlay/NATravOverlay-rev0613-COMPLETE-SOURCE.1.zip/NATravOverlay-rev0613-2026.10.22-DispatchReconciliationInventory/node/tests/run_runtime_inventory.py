#!/usr/bin/env python3
"""Native bounded runtime inventories against independently constructed configs.
Only owned local processes/sockets. Maximum-membership pins are synthetic: this
is not a test of 64 communicating or independently hosted nodes.
"""
from __future__ import annotations
import argparse, hashlib, json, os, socket, struct, subprocess, time
from pathlib import Path
from run_persistent import Harness, free_port, operation, raw_control, receive_exact
from run_live_configuration import candidate, activate, rollback
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_outbox_inspection import setup, submit, wait_outcome

SECTIONS=('peers','routes','keys','local-control','evidence-read','evidence-author','authorization','source-disclosure','source-views','source-bindings','configuration')

def inventory(h,label,state,*,section='peers',offset=0,selection=None,limit=16,budget=60000,peer=None,uid=None,id=None,principal=None,expected=0):
    args=['runtime-inventory','--control',str(state/'control.sock'),'--section',section,'--limit',str(limit),'--max-bytes',str(budget),'--offset',str(offset),'--deadline-ms','5000']
    for key,value in [('selection',selection),('peer',peer),('uid',uid),('id',id)]:
        if value is not None:args+=['--'+key,str(value)]
    q=h.run(label,args,expected) if principal is None else run_as_uid(h,label,principal,principal,args,expected)
    if expected==0:
        h.check(q['format']=='NATRAV_OVERLAY_RUNTIME_INVENTORY_V1','explicit format')
        h.check(q['returned']==len(q['rows']) and q['returned']<=limit,'whole bounded rows')
        h.check(len(json.dumps(q,separators=(',',':')).encode())<=budget,'annotated response within byte limit')
        h.check(q['work']['rows_serialized']<=limit+1 and q['work']['state_snapshots']==0 and q['work']['payload_bytes_copied']==0,'bounded selected-row work, no application copy')
        h.check(q['has_more']==(q['next_offset'] is not None),'explicit continuation')
        if q['has_more']:h.check(q['next_offset']==offset+q['returned'] and q['returned']>0,'no skip or stuck nonempty continuation')
    return q

def all_rows(h,label,state,section,**kw):
    rows=[]; offset=0; selection=None; pages=[]
    while True:
        q=inventory(h,label+'-'+str(offset),state,section=section,offset=offset,selection=selection,**kw)
        if selection is not None:h.check(q['selection_digest']==selection,'same selected configuration and membership')
        selection=q['selection_digest'];rows+=q['rows'];pages.append(q)
        if not q['has_more']:break
        offset=q['next_offset']
    h.check(len(rows)==q['total'],'complete selected inventory returned exactly')
    return rows,pages

def max_config(h,name):
    state=h.runtime/name;cfg=h.config(name,'A',state,free_port(),[],deadline_ms=5000)
    text=cfg.read_text().replace('CONFIG_V6','CONFIG_V17')
    root=os.geteuid();lines=[text.rstrip(),f'runtime_generation={name}-1',
        f'local_control={root},INSPECT,MAINTENANCE,CONFIGURATION,SHUTDOWN,EVIDENCE_READ,EVIDENCE_PAYLOAD,EVIDENCE_AUTHOR,SOURCE_DISCLOSE,SOURCE_IMPORT',
        f'evidence_read={root},P00,observations/0,PAYLOAD']
    for i in range(63):
        lines += [f'local_control={200000+i},INSPECT,EVIDENCE_READ',f'evidence_read={200000+i},P00,observations/{i},METADATA']
    nodes=[f'P{i:02}' for i in range(64)];routes=[];keys=[];auth=[]
    for i,n in enumerate(nodes):
        lines.append(f'peer={n},100,1000,20,86400000')
        for k,status in [(0,'ACTIVE'),(1,'REVOKED')]:
            pin=operation('inventory-'+n+'-g'+str(k));keys.append({'node':n,'id':f'g{k}','state':status,'spki_sha256':pin})
            lines.append(f'peer_key={n},g{k},{status},{pin}')
        for j in range(8):
            ep=f'127.0.0.1:{20000+i*8+j}';priority=7-j
            lines.append(f'peer_route={n},r{j},{priority},DISABLED,{ep}')
            routes.append({'peer':n,'id':f'r{j}','priority':priority,'state':'DISABLED','endpoint':ep})
        for j in range(4):
            lines.append(f'authorize={n},*,EVIDENCE,observations/{j}')
            auth.append((n,'*','EVIDENCE',f'observations/{j}'))
    for j in range(8):lines.append(f'evidence_author={root},owned/{j}')
    for j in range(2):
        lines += [f'source_disclosure=grant{j},{root},{root},P00,g0,owned/{j},10,1000,lease{j},60000,RETAIN',
            f'source_view=view{j},{root},P00,g0,{root},observations/{j},materialized/{j},20,1000',
            f'source_view_binding=view{j},grant{j},{operation("instance"+str(j))},{operation("grant"+str(j))},-']
    cfg.write_text('\n'.join(lines)+'\n');cfg.chmod(0o600)
    h.check(cfg.stat().st_size<=65536,'maximum-membership fixture obeys actual config byte bound')
    return state,cfg,{'peers':nodes,'routes':routes,'keys':keys,'authorization':auth}

def packet(section='peers',peer='',id='',uid=None,offset=0,limit=16,budget=60000,selection=None):
    def text(v):b=v.encode();return struct.pack('!H',len(b))+b
    return b'NOC1\x1aNRI1'+text(section)+text(peer)+text(id)+(b'\0' if uid is None else b'\1'+struct.pack('!I',uid))+struct.pack('!III',offset,limit,budget)+(b'\0' if selection is None else b'\1'+bytes.fromhex(selection))

def run_cases(h,only):
    def case(name,fn):
        if not only or name in only:h.case(name,fn)

    def maximum():
        state,cfg,ref=max_config(h,'inventory-max')
        # Config-check is an offline full inventory, not the runtime response.
        checked=h.run('max-config-check',['config-check','--config',str(cfg)])
        daemon=h.start('maximum-registry',cfg,state)
        before=(state/'state.journal').read_bytes()
        q=h.run('maximum-health',['status','--control',str(state/'control.sock'),'--deadline-ms','5000'])
        h.check(q['format']=='NATRAV_OVERLAY_RUNTIME_STATUS_V14' and q['lifecycle']['ready'],'ordinary health usable at maximum membership')
        h.check(q['peer_registry']['registered']==64 and q['peer_registry']['truncated'] and q['peers_total']==64 and q['peers_truncated'],'no omitted member mistaken for missing')
        h.check(q['peer_generations_total']==128 and q['local_control']['total']==64 and q['evidence_read_policy']['total']==64,'full totals remain exact despite previews')
        h.check(q['storage']['logical_state_digest'] is None and q['status_work']['logical_bytes_serialized']==0,'default status still never hashes full state')
        result={};measure={}
        for sec in SECTIONS:
            rows,pages=all_rows(h,'max-'+sec,state,sec,limit=7,budget=4096)
            result[sec]=rows;measure[sec]={'records':len(rows),'pages':len(pages),'maximum_reply_bytes':max(len(json.dumps(p,separators=(',',':')).encode()) for p in pages),'rows_serialized':sum(p['work']['rows_serialized'] for p in pages)}
            h.check(all(p['configuration_digest']==checked['runtime_digest'] for p in pages),'runtime config matches native parsed reference')
        h.check([r['node'] for r in result['peers']]==ref['peers'],'all 64 historical identity rows in exact order')
        h.check([{k:r[k] for k in ['peer','id','priority','state','endpoint']} for r in result['routes']]==ref['routes'],'512 configured routes, ordered by identity not priority/input order')
        h.check(result['keys']==ref['keys'],'all 128 exact key identities including revocation')
        def tx(v):
            b=v.encode();return struct.pack('!H',len(b))+b
        registry=hashlib.sha256(b'NATRAV_OVERLAY_RUNTIME_REGISTRY_V1\0'+struct.pack('!I',64)+b''.join(tx(n) for n in sorted(ref['peers']))).hexdigest()
        first=inventory(h,'independent-selection',state,section='peers',limit=1)
        context=b''.join(tx(v) for v in ['A',checked['runtime_digest'],registry,'peers','',''])+struct.pack('!I',os.geteuid())+b'\0'
        expected=hashlib.sha256(b'NATRAV_OVERLAY_RUNTIME_INVENTORY_SELECTION_V1\0'+context).hexdigest()
        h.check(first['registry_digest']==registry and first['selection_digest']==expected,'independently reconstruct both context commitments')
        expected_reads={(os.geteuid(),'P00','observations/0','PAYLOAD')} | {(200000+i,'P00',f'observations/{i}','METADATA') for i in range(63)}
        h.check({(x['uid'],x['issuer'],x['scope'],x['access']) for x in result['evidence-read']}==expected_reads,'every exact read domain and access class preserved')
        h.check({(x['uid'],x['scope']) for x in result['evidence-author']}=={(os.geteuid(),f'owned/{i}') for i in range(8)},'every exact author grant preserved')
        for j,row in enumerate(result['source-disclosure']):
            h.check(row['id']==f'grant{j}' and row['manager_uid']==os.geteuid() and row['author_uid']==os.geteuid() and row['subscriber']=='P00' and row['generation']=='g0' and row['scope']==f'owned/{j}' and row['maximum_records']==10 and row['maximum_payload_bytes']==1000 and row['lease_generation']==f'lease{j}' and row['lease_duration_ms']==60000 and row['pending_disposition']=='RETAIN','complete finite disclosure metadata')
        for row in result['source-views']:
            j=int(row['id'][-1]);h.check(row['provider']=='P00' and row['source_scope']==f'observations/{j}' and row['target_scope']==f'materialized/{j}' and row['maximum_records']==20 and row['maximum_payload_bytes']==1000,'exact source and target domain/retention metadata')
        for row in result['source-bindings']:
            j=int(row['view'][-1]);h.check(row['instance']==operation('instance'+str(j)) and row['grant_digest']==operation('grant'+str(j)) and row['lineage_digest'] is None,'exact subscription pins, no fabricated lineage')

        h.check(sorted((r['peer'],r['generation'],r['class'],r['resource']) for r in result['authorization'])==sorted(ref['authorization']),'all 256 independent authorization entries')
        h.check(len(result['local-control'])==64 and len(result['evidence-read'])==64 and len(result['source-bindings'])==2,'complete policy pages')
        h.check(all('private_key' not in json.dumps(r) and 'certificate' not in json.dumps(r) for rows in result.values() for r in rows),'no key/certificate paths or secret material in inventories')
        h.check((state/'state.journal').read_bytes()==before,'all successful inventory and health reads are journal-observational')
        (h.output/'MAXIMUM-INVENTORY.json').write_text(json.dumps({'fixture':'64 configured identities with synthetic pins, 512 disabled numeric routes; not network scale','config_bytes':cfg.stat().st_size,'status_bytes':len(json.dumps(q,separators=(',',':')).encode()),'health':q,'measurements':measure},indent=2)+'\n')
        daemon.shutdown()
    case('maximum_64_identities_512_routes_all_policy_pages_and_health',maximum)

    def maximum_keys():
        state,cfg,ref=max_config(h,'inventory-maxkeys')
        lines=[line for line in cfg.read_text().splitlines() if not line.startswith('authorize=') and (not line.startswith('peer_route=') or ',r0,' in line)]
        for node in ref['peers']:
            for generation in range(2,8):
                lines.append(f'peer_key={node},g{generation},REVOKED,{operation(node+"-extra-key-"+str(generation))}')
        cfg.write_text('\n'.join(lines)+'\n')
        h.check(cfg.stat().st_size<=65536,'maximum-key fixture also respects configuration byte budget')
        daemon=h.start('maximum-keys',cfg,state)
        health=h.run('keys-health',['status','--control',str(state/'control.sock'),'--deadline-ms','5000'])
        h.check(health['lifecycle']['ready'] and health['peer_generations_total']==512,'health usable with eight generations for every identity')
        rows,pages=all_rows(h,'all-512-keys',state,'keys',limit=32,budget=10000)
        h.check(len(rows)==512 and len({(r['node'],r['id']) for r in rows})==512,'exact 512-generation enumeration')
        h.check(sum(r['state']=='ACTIVE' for r in rows)==64 and sum(r['state']=='REVOKED' for r in rows)==448,'no revoked generations lost from pages')
        (h.output/'MAXIMUM-KEYS.json').write_text(json.dumps({'config_bytes':cfg.stat().st_size,'identities':64,'key_generations':512,'pages':len(pages),'status_bytes':len(json.dumps(health,separators=(',',':')).encode())},indent=2)+'\n')
        daemon.shutdown()
    case('maximum_eight_key_generations_per_identity',maximum_keys)

    def selectors():
        state,cfg,ref=max_config(h,'inventory-select');daemon=h.start('selection',cfg,state)
        q=inventory(h,'exact-route',state,section='routes',peer='P42',id='r7',budget=2048)
        h.check(q['total']==1 and q['rows'][0]['endpoint']=='127.0.0.1:'+str(20000+42*8+7),'exact conjunctive route lookup')
        missing=inventory(h,'missing-route',state,section='routes',peer='P42',id='not-a-route',budget=2048)
        h.check(missing['total']==0 and missing['work']['rows_serialized']==0,'missing exact selection visits no runtime row')
        uid=inventory(h,'uid-select',state,section='local-control',uid=200001)
        h.check(uid['total']==1 and uid['rows'][0]['uid']==200001,'exact numeric UID selection')
        peer_rows,peer_pages=all_rows(h,'peer-byte-cut',state,'peers',limit=64,budget=2048)
        h.check(len(peer_rows)==64 and len(peer_pages)>1,'byte budget actually ends pages, no silently skipped peer')
        rows,pages=all_rows(h,'small-budget',state,'keys',limit=64,budget=2048,peer='P00')
        h.check(len(rows)==2 and len(pages)>=1,'complete small byte-bound enumeration')
        ok,q=raw_control(state/'control.sock',packet('routes',peer='P00',limit=2,budget=2048));h.check(ok and q['returned']>0,'independent native request encoding')
        for name,data in [('trailing',packet()+b'x'),('cut',packet()[:-1]),('magic',packet().replace(b'NRI1',b'NRI2')),('no-selection',packet(offset=1)),('limit',packet(limit=65)),('bytes',packet(budget=2047)),('section',packet('unknown')),('filter',packet('keys',uid=0))]:
            ok,err=raw_control(state/'control.sock',data);h.check(not ok,'strict wire '+name)
        first=inventory(h,'context-first',state,section='routes',limit=2,peer='P00')
        e=inventory(h,'bad-selection',state,section='routes',peer='P00',offset=2,selection=operation('wrong'),expected=3)
        h.check(e['code']=='RUNTIME_INVENTORY_CONTEXT_MISMATCH','incorrect context not accepted')
        e=inventory(h,'filter-change',state,section='routes',peer='P01',offset=2,selection=first['selection_digest'],expected=3)
        h.check(e['code']=='RUNTIME_INVENTORY_CONTEXT_MISMATCH','filter context changes explicitly rejected')
        # Page size may change: positions are selection ordinals, not ephemeral server objects.
        last=inventory(h,'selection-resize',state,section='routes',peer='P00',offset=2,selection=first['selection_digest'],limit=64,budget=60000)
        h.check(last['returned']==6,'resized page does not skip records')
        e=inventory(h,'offset-range',state,section='routes',peer='P00',offset=9,selection=first['selection_digest'],expected=3)
        h.check(e['code']=='RUNTIME_INVENTORY_OFFSET_INVALID','beyond-end offset is not fabricated empty continuation')
        daemon.shutdown()
    case('independent_wire_exact_selectors_budgets_and_context_errors',selectors)

    def generation():
        a,b,ac,bc,ad,bd=setup(h,'inventory-generation')
        first=inventory(h,'before-change',a,section='routes',limit=1)
        changed=candidate(h,ac,'inventory-changed','inventory-g2',lambda t:t.replace(',primary,0,DISABLED,',',primary,5,DISABLED,'))
        activate(h,'change-contract',a,changed)
        denied=inventory(h,'changed-config',a,section='routes',offset=1,selection=first['selection_digest'],expected=3)
        h.check(denied['code']=='RUNTIME_INVENTORY_CONTEXT_MISMATCH','configuration change invalidates continuation')
        rollback(h,'restore-original',a,first['configuration_generation'])
        same=inventory(h,'same-canonical',a,section='routes',offset=1,selection=first['selection_digest'])
        h.check(same['selection_digest']==first['selection_digest'],'exact canonical rollback with same membership is same selection, not freshness claim')
        pin=h.identity('E').spki_sha256
        addition=candidate(h,ac,'inventory-added','inventory-g3',lambda t:t+f'peer_key=E,e-g1,ACTIVE,{pin}\n')
        activate(h,'new-historical-slot',a,addition);rollback(h,'rollback-route-only',a,first['configuration_generation'])
        denied=inventory(h,'history-changed',a,section='routes',offset=1,selection=first['selection_digest'],expected=3)
        h.check(denied['code']=='RUNTIME_INVENTORY_CONTEXT_MISMATCH','same config but new historical membership differs')
        q=inventory(h,'history-role',a,peer='E');h.check(q['rows'][0]['role']=='HISTORICAL','removed live key remains exactly inventoried')
        ad.shutdown()
    case('live_configuration_change_canonical_rollback_and_historical_membership',generation)

    def credentials():
        a,b,ac,bc,ad,bd=setup(h,'inventory-authority',delegates=True);expose_control_for_uid(a)
        q=inventory(h,'inspect-delegate',a,principal=65534,limit=1)
        no=inventory(h,'submit-not-inspect',a,principal=65533,expected=3)
        h.check(no['code']=='LOCAL_CONTROL_CLASS_DENIED','SUBMIT does not imply inventory authority')
        first=inventory(h,'owner-selection',a,limit=1)
        no=inventory(h,'another-principal-context',a,principal=65534,offset=1,selection=first['selection_digest'],expected=3)
        h.check(no['code']=='RUNTIME_INVENTORY_CONTEXT_MISMATCH','context binds actual kernel UID')
        wire=packet();sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);sock.settimeout(5);sock.connect(str(a/'control.sock'));sock.sendall(struct.pack('!I',len(wire))+wire[:-1])
        revoked=candidate(h,ac,'inventory-revoked','inventory-no-inspect',lambda t:t.replace(f'local_control={os.geteuid()},ALL',f'local_control={os.geteuid()},MAINTENANCE,CONFIGURATION,SHUTDOWN,SUBMIT'))
        activate(h,'revoke-inspection',a,revoked);sock.sendall(wire[-1:]);sock.shutdown(socket.SHUT_WR)
        n=struct.unpack('!I',receive_exact(sock,4))[0];data=receive_exact(sock,n);sock.close()
        h.check(data[4]==1 and json.loads(data[5:])['code']=='LOCAL_CONTROL_CLASS_DENIED','slow request uses current post-decode authority')
        inventory(h,'other-current-inspector',a,principal=65534)
        restore_owner_only_control(a);ad.shutdown()
    case('kernel_uids_current_inspect_and_partial_request_revocation',credentials)

    def telemetry():
        a,b,ac,bc,ad,bd=setup(h,'inventory-telemetry',online=True)
        q=inventory(h,'route-before',a,section='routes',peer='B',limit=1)
        op=submit(h,'real-inventory-delivery',a,peer='B',payload='measured native route');wait_outcome(h,'inventory-receipt',a,op,'ACKED')
        observed=inventory(h,'route-after',a,section='routes',peer='B',selection=q['selection_digest'])
        h.check(observed['selection_digest']==q['selection_digest'],'route telemetry does not alter selected membership')
        t=observed['rows'][0]['telemetry'];h.check(t is not None and t['connection_successes_this_run']>=1,'actual TCP TLS session reflected')
        b0=(a/'state.journal').read_bytes()
        for i in range(12):inventory(h,'empty-poll-'+str(i),a,section='keys',peer='unknown')
        h.check((a/'state.journal').read_bytes()==b0,'empty inventory polling has no durable writes')
        (h.output/'TELEMETRY.json').write_text(json.dumps({'before':q,'after':observed},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('actual_tls_delivery_separate_telemetry_and_observational_polling',telemetry)

    def maintenance():
        a,b,ac,bc,ad,bd=setup(h,'inventory-maintenance')
        before=inventory(h,'before-maintenance',a,section='keys',limit=1)
        h.run('compact-inventory',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000'])
        compacted=inventory(h,'after-compaction',a,section='keys',offset=1,selection=before['selection_digest'])
        ad.shutdown();ad=h.start('inventory-restarted',ac,a)
        restarted=inventory(h,'after-restart',a,section='keys',offset=1,selection=before['selection_digest'])
        h.check(restarted['selection_digest']==before['selection_digest'] and restarted['rows']==compacted['rows'],'configuration continuation survives nonmembership representation changes')
        h.check(restarted['process_instance']!=before['process_instance'],'run-scoped telemetry origin changes explicitly')
        quiet=(a/'state.journal').read_bytes()
        for i in range(8):h.run('health-poll-'+str(i),['status','--control',str(a/'control.sock')])
        h.check((a/'state.journal').read_bytes()==quiet,'bounded previews do not alter logical history')
        ad.shutdown()
    case('compaction_restart_stable_positions_and_run_telemetry_reset',maintenance)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);start=time.time();ok=False
    try:
        run_cases(h,set(a.case) if a.case else None)
        if not h.cases:raise ValueError('no cases selected')
        ok=True
    except BaseException as e:(h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_RUNTIME_INVENTORY_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
