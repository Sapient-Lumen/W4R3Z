#include "adapter_configuration.hpp"
#include "common.hpp"
#include <iostream>
#include <stdexcept>
#include <string>

using namespace natrav_overlay;
namespace {
std::size_t assertions = 0U;
void check(bool condition) {
    ++assertions;
    if (!condition) { throw std::runtime_error("assertion failed"); }
}
template <typename Function>
void rejects(Function function, const std::string& code) {
    ++assertions;
    try { function(); }
    catch (const AppError& error) {
        if (error.code() == code) { return; }
        throw std::runtime_error("expected " + code + ", observed " + error.code());
    }
    throw std::runtime_error("missing rejection " + code);
}
}
int main() {
    try {
        OperatorPinnedAdapterProfile p;
        p.profile_id = "radio"; p.generation = 1U;
        p.executable = "/not-present/adapter"; p.executable_sha256.fill(0x11U);
        auto p2 = p; p2.generation = 2U;
        p2.previous_profile_sha256 = operator_pinned_adapter_profile_sha256(p);
        p2.executable_sha256.fill(0x22U);
        ConfiguredAdapterEndpoint e;
        e.endpoint_id = "radio-out"; e.generation = 1U;
        e.locator = AdapterTransportLocator{.profile_id="radio", .profile_generation=1U, .link_id=1U, .epoch=1U};
        e.profile_sha256 = operator_pinned_adapter_profile_sha256(p);
        auto text = operator_pinned_adapter_profile_text(p);
        auto hex = adapter_configuration_record_hex(text);
        check(decode_adapter_configuration_record_hex(hex) == text);
        check(parse_runtime_adapter_profile(hex) == p);
        check(parse_runtime_adapter_endpoint(adapter_configuration_record_hex(configured_adapter_endpoint_text(e))) == e);
        RuntimeAdapterConfiguration c{.profiles={p2,p}, .endpoints={e}};
        normalize_runtime_adapter_configuration(c);
        check(c.profiles.front() == p && c.profiles.back() == p2);
        check(c.endpoints.front().profile_sha256 == operator_pinned_adapter_profile_sha256(p));
        check(runtime_adapter_configuration_json(c).find("/not-present/") == std::string::npos);
        check(runtime_adapter_configuration_json(c).find("\"configured_transport_enabled\":true") != std::string::npos);
        RuntimeAdapterConfiguration prior{.profiles={p},.endpoints={e}};
        require_runtime_adapter_history_preserved(prior,c);
        check(prior.profiles.size() == 1U);
        rejects([&] { require_runtime_adapter_history_preserved(c,prior); },"CONFIG_ADAPTER_HISTORY_REMOVED");
        auto drift = c; drift.profiles[0].arguments.push_back("replacement");
        rejects([&] { require_runtime_adapter_history_preserved(prior,drift); },"CONFIG_ADAPTER_GENERATION_CONFLICT");
        drift = c; drift.endpoints[0].locator.epoch = 2U;
        rejects([&] { require_runtime_adapter_history_preserved(prior,drift); },"CONFIG_ADAPTER_GENERATION_CONFLICT");
        drift = c; drift.endpoints.clear();
        rejects([&] { require_runtime_adapter_history_preserved(prior,drift); },"CONFIG_ADAPTER_HISTORY_REMOVED");
        drift = c; drift.profiles.push_back(p);
        rejects([&] { normalize_runtime_adapter_configuration(drift); },"CONFIG_ADAPTER_DUPLICATE_GENERATION");
        drift = c; drift.endpoints.push_back(e);
        rejects([&] { normalize_runtime_adapter_configuration(drift); },"CONFIG_ADAPTER_DUPLICATE_GENERATION");
        drift = c; drift.profiles.erase(drift.profiles.begin());
        rejects([&] { normalize_runtime_adapter_configuration(drift); },"ADAPTER_PROFILE_TRANSITION_UNAUTHORIZED");
        drift = c; drift.endpoints.front().profile_sha256.fill(0x33U);
        rejects([&] { normalize_runtime_adapter_configuration(drift); },"CONFIG_ADAPTER_PROFILE_DIGEST_MISMATCH");
        drift = c; drift.profiles.clear();
        rejects([&] { normalize_runtime_adapter_configuration(drift); },"ADAPTER_PROFILE_NOT_FOUND");
        drift = c; drift.endpoints.resize(65U,e);
        rejects([&] { normalize_runtime_adapter_configuration(drift); },"CONFIG_ADAPTER_CAPACITY");
        rejects([] { static_cast<void>(decode_adapter_configuration_record_hex("0")); },"CONFIG_ADAPTER_RECORD_INVALID");
        rejects([] { static_cast<void>(decode_adapter_configuration_record_hex("0A")); },"CONFIG_ADAPTER_RECORD_NONCANONICAL");
        rejects([] { static_cast<void>(decode_adapter_configuration_record_hex("00")); },"CONFIG_ADAPTER_RECORD_NONCANONICAL");
        rejects([] { static_cast<void>(decode_adapter_configuration_record_hex("ff")); },"CONFIG_ADAPTER_RECORD_NONCANONICAL");
        rejects([] { static_cast<void>(decode_adapter_configuration_record_hex(std::string(65'538U,'0'))); },"CONFIG_ADAPTER_RECORD_INVALID");
        for (unsigned int value=1U; value<128U; ++value) {
            const std::string record(1U,static_cast<char>(value));
            check(decode_adapter_configuration_record_hex(adapter_configuration_record_hex(record)) == record);
        }
        std::cout << "{\"status\":\"PASS\",\"assertions\":" << assertions << "}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n'; return 1;
    }
}
