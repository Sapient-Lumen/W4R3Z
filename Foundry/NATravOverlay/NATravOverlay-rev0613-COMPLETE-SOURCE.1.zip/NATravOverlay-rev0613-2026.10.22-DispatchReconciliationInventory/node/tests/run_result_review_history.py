#!/usr/bin/env python3
"""Owner-scoped, exact-domain review history on owned native C++ processes.
Independent wire/root checks. This is historical report evaluation, not proof
of remote execution, a retained live snapshot, or newest-state authority.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, shutil, socket, struct, subprocess, sys, time
from pathlib import Path
from run_persistent import Harness, operation, raw_control
from run_result_reviews import selected, review, status, wire as review_wire
from run_action_result_correlation import setup, completed, emit, decode_nac1, encode_nac, effect
from run_action_results import RESULT_SCOPE
from run_live_configuration import candidate, activate
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_state_authentication import new_key, migrate, start as keyed_start, inspect
from run_conditional_action import journal_frames, frame


def wire(action, provider='B', scope=RESULT_SCOPE, exact=None, offset=0, limit=8, maximum=32768, through=None, prefix=None):
    text=lambda s:struct.pack('!H',len(s.encode()))+s.encode()
    return (b'NOC1\x23RRH1'+bytes.fromhex(action)+text(provider)+text(scope)+
            (b'\0' if exact is None else b'\1'+bytes.fromhex(exact))+
            struct.pack('!QII',offset,limit,maximum)+(b'\0' if through is None else b'\1'+struct.pack('!Q',through)+bytes.fromhex(prefix)))


def history(h,label,state,action,*,uid=None,provider='B',scope=RESULT_SCOPE,exact=None,offset=0,limit=8,maximum=32768,through=None,prefix=None,expected=0):
    args=['action-result-review-history','--control',str(state/'control.sock'),'--request',action,
          '--provider',provider,'--scope',scope,'--limit',str(limit),'--max-bytes',str(maximum),'--offset',str(offset),'--deadline-ms','5000']
    if exact is not None:args+=['--review',exact]
    if through is not None:args+=['--through',str(through)]
    if prefix is not None:args+=['--prefix-digest',prefix]
    r=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    if expected==0:
        h.check(r['format']=='NATRAV_OVERLAY_RESULT_REVIEW_HISTORY_V1' and r['comparison_mode']=='STORED_ONLY_USE_REVIEW_STATUS','stored-only explicit history format')
        h.check(not r['execution_verified_locally'] and r['freshness']=='NOT_ESTABLISHED','listing not remote proof or freshness')
        h.check(r['returned']==len(r['records']) and r['next_offset']==r['offset']+r['returned'] and r['has_more']==(r['next_offset']<r['through']),'whole-row progress accounting')
        h.check(len(json.dumps(r,separators=(',',':')).encode())<=maximum,'complete annotated byte bound')
        h.check(r['work']['metadata_rows_visited']<=r['returned']+1,'bounded row visits including nonfitting lookahead')
        for field in ('candidate_validations','historical_configurations_parsed','review_record_bytes_serialized','snapshot_calls','snapshot_payload_bytes','logical_bytes_serialized'):
            h.check(r['work'][field]==0,'history avoids broad work '+field)
        h.check(all(x['ordinal']==offset+i+1 for i,x in enumerate(r['records'])),'owned-selection ordinals no global gaps')
    return r


def root_for(node,uid,action,records,provider='B',scope=RESULT_SCOPE,exact=None):
    text=lambda s:struct.pack('!H',len(s.encode()))+s.encode()
    material=text(node)+struct.pack('!I',uid)+bytes.fromhex(action)+text(provider)+text(scope)+(b'\0' if exact is None else b'\1'+bytes.fromhex(exact))
    root=hashlib.sha256(b'NATRAV_OVERLAY_RESULT_REVIEW_HISTORY_SEED_V1\0'+material).digest()
    for i,r in enumerate(records):
        root=hashlib.sha256(b'NATRAV_OVERLAY_RESULT_REVIEW_HISTORY_LINK_V1\0'+root+struct.pack('!Q',i+1)+bytes.fromhex(r['review_id']+r['record_digest'])).digest()
    return root.hex()


def compare(h,rows,reviews):
    h.check(len(rows)==len(reviews),'complete selected count')
    for row,r in zip(rows,reviews):
        for k in ('review_id','record_digest','request_operation_id','provider','scope','uid','gid','pid','unix_ms','configuration_event','configuration_digest','reason_bytes','reason_digest','candidate_count','candidate_root','request_binding','conclusion','consistent','invalid','unique_operation_id','reviewed_receipt_present'):
            h.check(row[k]==r[k],'immutable summary equals actual review '+k)
        h.check('records' not in row and 'comparison' not in row,'no per-candidate array or changing conclusion comparison')


def save(h,name,value):
    (h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')


def cases(h,only):
    def case(name,fn):
        if only is None or name in only:h.case(name,fn)

    def basic():
        root,ap,bp,ac,bc,a,b=setup(h,'history-basic');state=root/'a'
        action,result,payload=completed(h,'history-basic-result',root);s=selected(h,'select-basic',state,action)
        empty=history(h,'initial-empty',state,action)
        h.check(empty['through']==0 and empty['prefix_digest']==root_for('A',os.geteuid(),action,[]),'independent empty domain seed')
        # Send a genuine creation request then intentionally lose its response.
        raw=review_wire(s,'lost review response')
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as sock:
            sock.connect(str(state/'control.sock'));sock.sendall(struct.pack('!I',len(raw))+raw);sock.shutdown(socket.SHUT_WR)
        h.wait('discover-lost-response',lambda:history(h,'find-lost',state,action)['retained_selected_total']==1,timeout=5)
        first=history(h,'found-lost',state,action)
        rid=hashlib.sha256(b'NATRAV_OVERLAY_RESULT_REVIEW_ID_V1\0'+struct.pack('!I',os.geteuid())+raw[5:]).hexdigest()
        h.check(first['records'][0]['review_id']==rid,'recover review ID from original request after lost reply')
        originals=[status(h,'fetch-lost-review',state,{'review_id':rid})]
        for i in range(1,16):originals.append(review(h,'fill-owner-'+str(i),state,s,reason='private /identity/path reason '+str(i)))
        excess=review(h,'over-owner-cap',state,s,reason='seventeenth',expected=3)
        h.check(excess['code']=='RESULT_REVIEW_LIMIT','bounded owner registry is not reset by reading')
        rows=[];offset=0;prefix=None;through=None;pages=0
        while True:
            q=history(h,'page-'+str(pages),state,action,limit=4,offset=offset,through=through,prefix=prefix)
            through=q['through'];prefix=q['prefix_digest'];rows+=q['records'];pages+=1
            if not q['has_more']:break
            offset=q['next_offset']
        compare(h,rows,originals);h.check(prefix==root_for('A',os.geteuid(),action,originals),'independent full prefix over validated record digests')
        expected={hashlib.sha256(body[1:]).hexdigest() for _,_,body in journal_frames((state/'state.journal').read_bytes()) if body[0]==38}
        h.check(expected=={r['record_digest'] for r in rows},'record commitments equal actual encoded durable NRR1 bytes')
        h.check('private /identity/path' not in json.dumps(q),'private review reasons not disclosed')
        for r in originals[::5]:
            exact=history(h,'exact-'+r['review_id'][:6],state,action,exact=r['review_id']);compare(h,exact['records'],[r])
            h.check(exact['prefix_digest']==root_for('A',os.geteuid(),action,[r],exact=r['review_id']),'independent exact-ID selector prefix')
        unknown=history(h,'unknown-review',state,action,exact='ab'*32)
        h.check(unknown['through']==0 and not unknown['records'],'missing exact selection empty')
        small=history(h,'small-page',state,action,maximum=2048,expected=3)
        h.check(small['code']=='RESULT_REVIEW_HISTORY_PAGE_TOO_SMALL','first row must fit whole')
        bounded=history(h,'byte-page',state,action,limit=16,maximum=4096)
        h.check(0<bounded['returned']<16 and bounded['has_more'],'byte-limited page stops before nonfitting row')
        nextpage=history(h,'after-byte-page',state,action,offset=bounded['next_offset'],through=bounded['through'],prefix=bounded['prefix_digest'],limit=16)
        compare(h,bounded['records']+nextpage['records'],originals)
        # Required negative-control boundary.
        bad=history(h,'false-prefix',state,action,through=through,prefix='ab'*32,expected=3)
        h.check(bad['code']=='RESULT_REVIEW_HISTORY_PREFIX_MISMATCH','false retained prefix rejected')
        malformed=[wire(action)+b'x',wire(action)[:-1],wire(action).replace(b'RRH1',b'RRH2'),wire(action,offset=1),wire(action,limit=0),wire(action,maximum=60001)]
        for i,data in enumerate(malformed):
            ok,e=raw_control(state/'control.sock',data);h.check(not ok and e['code'].startswith('RESULT_REVIEW_HISTORY_'),'strict wire request '+str(i))
        ok,independent=raw_control(state/'control.sock',wire(action,limit=4));h.check(ok and independent['records']==rows[:4],'independent wire client')
        before=(state/'state.journal').read_bytes()
        for i in range(8):history(h,'poll-'+str(i),state,action,offset=16,through=16,prefix=prefix)
        h.check((state/'state.journal').read_bytes()==before,'empty and successful reads never append')
        h.run('full-history-compact',['compact','--control',str(state/'control.sock'),'--deadline-ms','5000']);a.shutdown();a=h.start('full-history-restart',ac,state)
        restored=history(h,'last-reconstructed',state,action,offset=15,through=16,prefix=prefix);compare(h,restored['records'],originals[-1:])
        save(h,'OWNER-CAPACITY',{'records':16,'pages':pages,'prefix':prefix,'byte_page':bounded,'reconstructed':restored});b.shutdown();a.shutdown()
    case('owner_capacity_lost_reply_exact_lookup_wire_and_byte_bounds',basic)

    def append_history():
        root,ap,bp,ac,bc,a,b=setup(h,'history-append');state=root/'a';action,result,payload=completed(h,'append-result',root)
        s=selected(h,'append-select',state,action)
        originals=[review(h,'prefix-'+str(i),state,s,reason='earlier '+str(i)) for i in range(3)]
        first=history(h,'stable-first',state,action,limit=1)
        # Actual late candidate turns all original conclusions historical without rewriting the rows.
        changed=decode_nac1(payload);changed['terminal_unix_ms']+=1;changed['local_receipt_digest']=effect(changed);emit(h,ap,encode_nac(changed))
        h.check(status(h,'now-historical',state,originals[0])['comparison']['status']=='HISTORICAL','actual candidate changes current comparison only')
        s2=selected(h,'later-select',state,action)
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
            jobs=[pool.submit(review,h,'append-'+str(i),state,s2,'later '+str(i)) for i in range(4)]
            page=history(h,'read-during-append',state,action,through=3,prefix=first['prefix_digest'],offset=1,limit=2)
            appended=[j.result() for j in jobs]
        compare(h,first['records']+page['records'],originals)
        current=history(h,'current-seven',state,action,limit=16)
        h.check(current['retained_selected_total']==7 and all(r['conclusion']=='CONFLICTING_REPORTS' for r in current['records'][3:]),'new reviews append new conclusions')
        h.check({r['review_id'] for r in current['records'][3:]}=={r['review_id'] for r in appended},'all concurrent appends visible once')
        # An unrelated original/review is outside the exact selection.
        action2,_,_=completed(h,'other-history-request',root);review(h,'other-domain-review',state,selected(h,'other-select',state,action2))
        again=history(h,'no-other-request-gap',state,action,through=3,prefix=first['prefix_digest'],limit=16)
        compare(h,again['records'],originals);h.check(again['retained_selected_total']==7,'other request not included in count')
        changed_config=candidate(h,ac,'history-new-cfg','history-new-cfg-g2',lambda t:t+'# irrelevant formatting only\n')
        activate(h,'history-activate',state,changed_config)
        q=history(h,'same-stored-prefix-new-config',state,action,through=3,prefix=first['prefix_digest'],limit=16)
        compare(h,q['records'],originals);h.check(q['authorized_configuration_digest']!=first['authorized_configuration_digest'],'current authorization separated from stored prefix')
        h.run('append-compact',['compact','--control',str(state/'control.sock'),'--deadline-ms','5000']);a.shutdown();a=h.start('append-restart',changed_config,state)
        compare(h,history(h,'old-prefix-after-restart',state,action,through=3,prefix=first['prefix_digest'])['records'],originals)
        save(h,'APPENDS',{'first':first,'during':page,'current':current,'after_configuration':q});b.shutdown();a.shutdown()
    case('stable_historical_prefix_concurrent_appends_and_current_facts',append_history)

    def principals():
        root,ap,bp,ac,bc,a,b=setup(h,'history-principals',delegates=True);state=root/'a'
        grant=candidate(h,ac,'history-delegate','history-delegates-g2',lambda t:t.replace('local_control=65534,INSPECT,EVIDENCE_READ,EVIDENCE_PAYLOAD','local_control=65534,INSPECT,MAINTENANCE,EVIDENCE_READ,EVIDENCE_PAYLOAD').replace('local_control=65533,INSPECT,EVIDENCE_READ','local_control=65533,INSPECT,MAINTENANCE,EVIDENCE_READ,EVIDENCE_PAYLOAD').replace(f'evidence_read=65533,B,{RESULT_SCOPE},METADATA',f'evidence_read=65533,B,{RESULT_SCOPE},PAYLOAD'))
        activate(h,'grant-two-reviewers',state,grant);action,result,payload=completed(h,'uid-history-result',root);s=selected(h,'uid-select',state,action)
        expose_control_for_uid(state)
        own1=review(h,'uid-first',state,s,uid=65534);first=history(h,'uid-first-page',state,action,uid=65534)
        hidden=review(h,'hidden-review',state,s,reason='hidden owner',uid=65533)
        same=history(h,'hidden-write-isolation',state,action,uid=65534)
        h.check(same['records']==first['records'] and same['prefix_digest']==first['prefix_digest'] and same['retained_selected_total']==1,'hidden owner append changes no rows counts or root')
        own2=review(h,'uid-second',state,s,reason='second visible',uid=65534)
        visible=history(h,'uid-two-visible',state,action,uid=65534);compare(h,visible['records'],[own1,own2])
        h.check([r['ordinal'] for r in visible['records']]==[1,2],'other UID introduces no ordinal gap')
        for label,rid in [('hidden-existing',hidden['review_id']),('nonexistent','ab'*32)]:
            q=history(h,label,state,action,exact=rid,uid=65534)
            h.check(q['through']==0 and q['retained_selected_total']==0 and not q['records'] and q['work']['metadata_rows_visited']==0,'hidden exact indistinguishable from missing in existence fields')
        denied=history(h,'cross-uid-prefix',state,action,uid=65533,through=first['through'],prefix=first['prefix_digest'],expected=3)
        h.check(denied['code']=='RESULT_REVIEW_HISTORY_PREFIX_MISMATCH','prefix bound to kernel owner')
        denied=history(h,'wrong-domain-with-no-record',state,action,uid=65534,scope='not/authorized',expected=3)
        h.check(denied['code']=='RESULT_REVIEW_PERMISSION_DENIED','domain check before lookup even empty')
        # Read-only authority remains sufficient, but losing payload authority forbids history.
        readonly=candidate(h,grant,'history-readonly','history-readonly-g3',lambda t:t.replace('local_control=65534,INSPECT,MAINTENANCE,EVIDENCE_READ,EVIDENCE_PAYLOAD','local_control=65534,INSPECT,EVIDENCE_READ,EVIDENCE_PAYLOAD'))
        activate(h,'remove-write-not-read',state,readonly);history(h,'reader-without-maintenance',state,action,uid=65534)
        script="""import socket,struct,sys,json
s=socket.socket(socket.AF_UNIX);s.settimeout(10);s.connect(sys.argv[1]);p=bytes.fromhex(sys.argv[2]);s.sendall(struct.pack('!I',len(p))+p[:2]);print('CONNECTED',flush=True);sys.stdin.readline();s.sendall(p[2:]);s.shutdown(socket.SHUT_WR)
def read(n):
 b=b''
 while len(b)<n:
  x=s.recv(n-len(b))
  if not x:raise RuntimeError('EOF')
  b+=x
 return b
r=read(struct.unpack('!I',read(4))[0]);print(json.dumps({'ok':r[4]==0,'body':json.loads(r[5:])}))
"""
        p=subprocess.Popen(['/usr/bin/setpriv','--reuid=65534','--regid=65534','--clear-groups',sys.executable,'-c',script,str(state/'control.sock'),wire(action).hex()],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            h.check(p.stdout.readline().strip()=='CONNECTED','real delegated partial request')
            revoked=candidate(h,readonly,'history-revoked','history-revoked-g4',lambda t:t.replace('local_control=65534,INSPECT,EVIDENCE_READ,EVIDENCE_PAYLOAD','local_control=65534,INSPECT,EVIDENCE_READ').replace(f'evidence_read=65534,B,{RESULT_SCOPE},PAYLOAD',f'evidence_read=65534,B,{RESULT_SCOPE},METADATA'))
            activate(h,'remove-payload-read',state,revoked);out,err=p.communicate('\n',timeout=10);denial=json.loads(out.splitlines()[-1])
            h.check(p.returncode==0 and not denial['ok'] and denial['body']['code']=='LOCAL_CONTROL_CLASS_DENIED','post-decode current payload class required')
        finally:
            if p.poll() is None:p.kill();p.wait()
        restore_owner_only_control(state);save(h,'PRINCIPALS',{'visible':visible,'hidden_append_same_prefix':same['prefix_digest']==first['prefix_digest'],'denial':denial});b.shutdown();a.shutdown()
    case('real_owner_isolation_domain_authority_and_live_revocation',principals)

    def alternative():
        root,ap,bp,ac,bc,a,b=setup(h,'history-alternate');state=root/'a';action,result,payload=completed(h,'alternative-result',root)
        review(h,'alternative-review',state,selected(h,'alternative-select',state,action));old=history(h,'old-authentic-prefix',state,action)
        a.shutdown();p=state/'state.journal';before=p.read_bytes();start,end,body=next(v for v in journal_frames(before) if v[2][0]==38)
        changed=bytearray(body);request_size=struct.unpack_from('!I',changed,5)[0];pid_position=1+4+4+request_size+32+8
        pid=struct.unpack_from('!I',changed,pid_position)[0];struct.pack_into('!I',changed,pid_position,pid+1)
        p.write_bytes(before[:start]+frame(bytes(changed))+before[end:]);a=h.start('valid-alternative-history',ac,state)
        now=history(h,'alternative-current',state,action)
        h.check(now['records'][0]['review_id']==old['records'][0]['review_id'] and now['records'][0]['conclusion']==old['records'][0]['conclusion'],'same request identity and conclusion in altered unkeyed attribution fixture')
        h.check(now['prefix_digest']!=old['prefix_digest'] and now['records'][0]['record_digest']!=old['records'][0]['record_digest'],'prefix commits actual complete stored actor record')
        bad=history(h,'old-prefix-against-different-attribution',state,action,through=old['through'],prefix=old['prefix_digest'],expected=3)
        h.check(bad['code']=='RESULT_REVIEW_HISTORY_PREFIX_MISMATCH','alternative valid unkeyed history cannot match supplied expected prefix')
        # This is not anti-rollback: the verifier with no separately saved expectation accepts valid history.
        save(h,'ALTERNATE-HISTORY',{'fixture':'altered unkeyed actor PID with checksum recomputed, not a claimed adversarial integrity guarantee','before':old,'after':now});b.shutdown();a.shutdown()
    case('full_record_prefix_detects_changed_valid_unkeyed_attribution',alternative)

    def lifecycle():
        root,ap,bp,ac,bc,a,b=setup(h,'history-lifecycle');state=root/'a';action,result,payload=completed(h,'life-result',root)
        r=review(h,'life-review',state,selected(h,'life-select',state,action));baseline=history(h,'life-history',state,action)
        h.run('history-quiesce',['quiesce','--control',str(state/'control.sock'),'--reason','review observation'])
        before=(state/'state.journal').read_bytes();q=history(h,'history-during-quiescence',state,action)
        h.check(q['records']==baseline['records'] and (state/'state.journal').read_bytes()==before,'quiesced read observational')
        h.run('history-resume',['resume','--control',str(state/'control.sock'),'--reason','resume after observation'])
        disabled=candidate(h,ac,'drain-route','history-drain-g2',lambda t:t.replace('peer_route=B,primary,0,ENABLED,','peer_route=B,primary,0,DISABLED,'))
        activate(h,'history-disable-for-drain',state,disabled)
        h.run('keep-drain-nonempty',['submit','--node','A','--control',str(state/'control.sock'),'--peer','B','--scope','results/counter','--operation',operation('history-drain-obligation'),'--payload-text','pending'])
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            draining=pool.submit(h.run,'history-drain',['drain-shutdown','--control',str(state/'control.sock'),'--drain-deadline-ms','1500','--reason','bounded observation test'])
            h.wait('actual history draining state',lambda:h.status('observe-draining',state,logical_digest=False)['lifecycle']['draining'])
            q=history(h,'history-during-drain',state,action,through=baseline['through'],prefix=baseline['prefix_digest'])
            h.check(q['records']==baseline['records'],'read authorized during actual nonempty drain')
            draining.result()
        a.process.wait(timeout=6);h.check(a.process.returncode==0,'drain exited cleanly');a._close_files();a=h.start('history-after-drain',disabled,state);compare(h,history(h,'restart-after-drain',state,action)['records'],[r]);b.shutdown();a.shutdown()
    case('observational_queries_during_quiescence_and_nonempty_drain',lifecycle)

    def maintenance():
        root,ap,bp,ac,bc,a,b=setup(h,'history-maintenance');state=root/'a';action,result,payload=completed(h,'maint-history-result',root,11)
        s=selected(h,'maint-select',state,action);r=review(h,'maint-first',state,s);first=history(h,'maint-prefix',state,action);a.shutdown()
        key=new_key(h,h.work,'review-history-state');migrate(h,'review-history-migrate',state,key,node='A');a=keyed_start(h,'history-keyed',ac,state,key)
        r2=review(h,'maint-keyed-second',state,selected(h,'keyed-select',state,action),reason='appended keyed review');a.shutdown()
        h.run('history-keyed-audit',['state-auth-audit','--state',str(state),'--node','A','--state-auth-key',str(key)])
        a=keyed_start(h,'history-keyed-compact',ac,state,key);h.run('history-compact',['compact','--control',str(state/'control.sock'),'--deadline-ms','5000']);a.shutdown()
        before=inspect(h,'history-pre-export',state,key,node='A');crypt=h.work/'history-crypt.key';h.run('history-key',['backup-key-init','--output',str(crypt),'--generation','history-backup'])
        identity=h.identity('A');archive=h.work/'history.nob'
        h.run('history-export',['backup-export','--state',str(state),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--output',str(archive),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'history-restored';h.run('history-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'history-restored',restored,key,node='A');h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'exact restored logical state including reviews')
        newidentity=h.runtime/'history-identity';newidentity.mkdir(mode=0o700);cert=newidentity/'cert.pem';secret=newidentity/'key.pem';shutil.copyfile(identity.certificate,cert);shutil.copyfile(identity.private_key,secret);secret.chmod(0o600)
        moved=candidate(h,ac,'history-relocated','history-relocated-g2',lambda t:t.replace('state='+str(state),'state='+str(restored)).replace(str(identity.certificate),str(cert)).replace(str(identity.private_key),str(secret)))
        h.run('history-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','history relocation','--state-auth-key',str(key)])
        identity.certificate.unlink();identity.private_key.unlink();a=keyed_start(h,'history-relocated-node',moved,restored,key)
        q=history(h,'history-with-obsolete-paths-gone',restored,action,through=first['through'],prefix=first['prefix_digest']);compare(h,q['records'],[r])
        current=history(h,'restored-both',restored,action);compare(h,current['records'],[r,r2])
        h.check(status(h,'review-historical-after-relocation',restored,r)['comparison']['status']=='HISTORICAL','listing historical account is not current conclusion')
        r3=review(h,'post-relocation-review',restored,selected(h,'post-relocation-select',restored,action),reason='explicit new decision')
        final=history(h,'post-relocation-append',restored,action);compare(h,final['records'],[r,r2,r3])
        h.check(final['prefix_digest']==root_for('A',os.geteuid(),action,[r,r2,r3]),'derived history root reconstructed and append-stable')
        save(h,'MAINTENANCE',{'before':first,'restored_old_prefix':q,'new_history':final,'old_identity_paths_removed':True,'logical_state_equal_at_restore':True});b.shutdown();a.shutdown()
    case('keyed_audit_compaction_encrypted_restore_relocation_and_later_append',maintenance)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    try:
        cases(h,set(a.case) if a.case else None)
        if not h.cases:raise ValueError('no selected cases')
        ok=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {e}',file=sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_RESULT_REVIEW_HISTORY_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:save(h,name,data)
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
