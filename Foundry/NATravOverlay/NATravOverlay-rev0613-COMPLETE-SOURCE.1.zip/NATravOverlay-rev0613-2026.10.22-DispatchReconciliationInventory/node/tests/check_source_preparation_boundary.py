#!/usr/bin/env python3
"""Exercise a separately built private-boundary probe on owned real-node fixtures."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from run_persistent import Harness
from run_source_selectors import pair, compact, dump
from run_source_subscriptions import journal_frames
from run_local_evidence import author
from run_automatic_source_delivery import automatic
from run_live_configuration import candidate, activate
from run_lease_succession import (setup as lease_setup, add_grant, succeed,
                                  received as lease_received, withdraw)
from run_subscription_leases import local as lease_local
from run_state_authentication import inspect


def run_cases(h: Harness, probe: Path, negative: bool, transaction_negative: bool,
              outbound_negative: bool = False, outgoing_slice_negative: bool = False,
              outbound_transfer_negative: bool = False) -> None:
    def invoke(label: str, state: Path, mode: str, expected: int = 0) -> dict:
        result = subprocess.run([str(probe), str(state), mode], capture_output=True,
                                text=True, timeout=30, env=os.environ.copy())
        h.commands.append({'label': label, 'binary': str(probe), 'mode': mode,
                           'returncode': result.returncode, 'stdout': result.stdout,
                           'stderr': result.stderr})
        h.check(result.returncode == expected,
                f'{label}: return {result.returncode}, expected {expected}: {result.stderr}')
        if expected:
            return {'returncode': result.returncode, 'stderr': result.stderr}
        return json.loads(result.stdout)

    if outbound_transfer_negative:
        def negative_outbound_transfer() -> None:
            a, c, pa, pc, ad, cd = pair(h, 'negative-outbound-transfer', 8)
            author(h, 'negative-outbound-transfer-source', a,
                   value='post-publication ownership transfer')
            compact(h, 'negative-outbound-transfer-create', a, 'create')
            ad.shutdown(); cd.shutdown()
            frozen = (a / 'state.journal').read_bytes()
            result = invoke('negative-outbound-transfer-probe', a, 'outbound', expected=1)
            h.check('source outbound boundary accepted: ownership-transfer-before-publication'
                    in result['stderr'],
                    'omitted durable-publication transfer boundary is detected')
            h.check((a / 'state.journal').read_bytes() == frozen,
                    'negative transfer probe publishes no mutation')
            dump(h, 'NEGATIVE-CONTROL', result)
        h.case('negative_outbound_transfer_boundary_detected', negative_outbound_transfer)
        return

    if outgoing_slice_negative:
        def negative_outgoing_slice() -> None:
            a, c, pa, pc, ad, cd = pair(h, 'negative-outgoing-slice', 8)
            author(h, 'negative-outgoing-slice-source', a,
                   value='strict decoder produced composite offset')
            compact(h, 'negative-outgoing-slice-create', a, 'create')
            ad.shutdown(); cd.shutdown()
            frozen = (a / 'state.journal').read_bytes()
            result = invoke('negative-outgoing-slice-probe', a, 'transaction', expected=1)
            h.check('parsed transaction boundary accepted: outgoing-offset-before-strict-field'
                    in result['stderr'],
                    'omitted strict outgoing end boundary is detected')
            h.check((a / 'state.journal').read_bytes() == frozen,
                    'negative outgoing-slice probe publishes no mutation')
            dump(h, 'NEGATIVE-CONTROL', result)
        h.case('negative_outgoing_slice_boundary_detected', negative_outgoing_slice)
        return

    if outbound_negative:
        def negative_outbound() -> None:
            a,c,pa,pc,ad,cd = pair(h, 'negative-outbound', 8)
            author(h, 'negative-outbound-source', a, value='exact nested immutable record')
            compact(h, 'negative-outbound-create', a, 'create')
            ad.shutdown();cd.shutdown()
            frozen=(a/'state.journal').read_bytes()
            result=invoke('negative-outbound-probe', a, 'outbound', expected=1)
            h.check('source outbound boundary accepted: composite-byte-snapshot' in result['stderr'],
                    'omitted nested bytes-to-owned-record binding is detected')
            h.check((a/'state.journal').read_bytes()==frozen, 'negative nested probe publishes no mutation')
            dump(h, 'NEGATIVE-CONTROL', result)
        h.case('negative_outbound_binding_detected', negative_outbound)
        return

    if transaction_negative:
        def negative_transaction() -> None:
            a, c, pa, pc, ad, cd = pair(h, 'negative-transaction', 8)
            author(h, 'negative-source', a, value='exact immutable bytes')
            compact(h, 'negative-create', a, 'create')
            ad.shutdown(); cd.shutdown()
            frozen = (a / 'state.journal').read_bytes()
            result = invoke('negative-transaction-probe', a, 'transaction', expected=1)
            h.check('parsed transaction boundary accepted: changed-byte-preflight' in result['stderr'],
                    'omitted byte-to-decoded binding is detected')
            h.check((a / 'state.journal').read_bytes() == frozen, 'negative control publishes no progress')
            dump(h, 'NEGATIVE-CONTROL', result)
        h.case('negative_transaction_binding_detected', negative_transaction)
        return

    if negative:
        def negative_eligibility() -> None:
            a, c, pa, pc, ad, cd = pair(h, 'negative-eligibility', 8)
            disabled = candidate(h, pa, 'negative-route-disabled',
                'negative-route-disabled-g1',
                lambda text: text.replace('peer_route=C,primary,0,ENABLED',
                                          'peer_route=C,primary,0,DISABLED'))
            activate(h, 'negative-route-disable', a, disabled)
            author(h, 'negative-original', a, value='negative original')
            author(h, 'negative-second', a, value='negative second')
            created = compact(h, 'negative-create', a, 'create')
            automatic(h, 'negative-enable', a, 'enable', previous=created,
                      maximum=2, interval=60000)
            ad.shutdown(); cd.shutdown()
            frozen = (a / 'state.journal').read_bytes()
            result = invoke('negative-eligibility-probe', a, 'eligibility', expected=1)
            h.check((a / 'state.journal').read_bytes() == frozen,
                    'negative eligibility probe changes no durable fixture bytes')
            h.check('eligibility boundary accepted: eligibility-source-record-digest'
                    in result['stderr'],
                    'narrowly weakened eligibility source binding is detected')
            dump(h, 'NEGATIVE-CONTROL', result)
        h.case('negative_control_detected', negative_eligibility)
        return

    def transaction_boundary() -> None:
        a, c, pa, pc, ad, cd = pair(h, 'transaction-boundary', 8)
        author(h, 'transaction-source', a, value='exact immutable transaction')
        created = compact(h, 'transaction-create', a, 'create')
        ad.shutdown(); cd.shutdown()
        frozen = (a / 'state.journal').read_bytes()
        result = invoke('transaction-probe', a, 'transaction')
        h.check((a / 'state.journal').read_bytes() == frozen, 'all transaction preparation probes publish nothing')
        observed = result['result']
        h.check(len(observed['rejected_boundaries']) >= 30, 'malformed, byte, state and replay boundaries reject')
        h.check(observed['checks'] == len(observed['rejected_boundaries']) + 4, 'exact native check account')
        offline = inspect(h, 'transaction-after-probe', a)['source_subscriptions'][0]
        h.check(offline['issued'] == 0 and offline['revision'] == created['revision'], 'failed preparations preserve canonical state')
        dump(h, 'TRANSACTION-BOUNDARIES', result)
    h.case('exact_byte_bound_transaction_preparation', transaction_boundary)

    def append_failure_poisoning() -> None:
        a, c, pa, pc, ad, cd = pair(h, 'append-failure', 8)
        author(h, 'append-failure-source', a, value='append failure immutable slice')
        created = compact(h, 'append-failure-create', a, 'create')
        ad.shutdown(); cd.shutdown()
        frozen = (a / 'state.journal').read_bytes()
        result = invoke('append-failure-probe', a, 'append-failure')
        observed = result['result']
        h.check(observed['terminal_state_head_code'] == 'STATE_RESTART_REQUIRED', 'terminal head rejects poisoned state')
        h.check(observed['live_state_head_code'] == 'STATE_RESTART_REQUIRED', 'head observation rejects failed append writer')
        h.check(observed['first_code'] == 'JOURNAL_WRITE_FAILED' and
                observed['retry_code'] == 'STATE_RESTART_REQUIRED' and
                observed['poisoned'],
                'durable append failure poisons the in-process writer and rejects retry')
        h.check((a / 'state.journal').read_bytes() == frozen,
                'closed-descriptor append failure publishes no journal prefix')
        offline = inspect(h, 'append-failure-after-restart', a)['source_subscriptions'][0]
        h.check(offline['issued'] == 0 and offline['revision'] == created['revision'],
                'restart reconstructs the unchanged predecessor after failed append')
        dump(h, 'APPEND-FAILURE', result)
    h.case('durable_append_failure_poisoning_and_restart', append_failure_poisoning)

    def post_append_failure_poisoning() -> None:
        a, c, pa, pc, ad, cd = pair(h, 'post-append-failure', 8)
        author(h, 'post-append-failure-source', a,
               value='durable publication precedes ownership transfer')
        created = compact(h, 'post-append-failure-create', a, 'create')
        ad.shutdown(); cd.shutdown()
        before = (a / 'state.journal').read_bytes()
        result = invoke('post-append-failure-probe', a, 'post-append-failure')
        observed = result['result']; work = observed['work']
        h.check(observed['terminal_state_head_code'] == 'STATE_RESTART_REQUIRED', 'terminal head rejects poisoned state')
        h.check(observed['live_state_head_code'] == 'STATE_RESTART_REQUIRED', 'head observation rejects partial post-publication writer')
        after = (a / 'state.journal').read_bytes()
        h.check(observed['first_code'] == 'PRIVATE_SOURCE_POST_TRANSFER_FAILURE' and
                observed['retry_code'] == 'STATE_RESTART_REQUIRED' and
                observed['poisoned'] and observed['partial_outbound_without_policy'],
                'a failure after the published ownership transfer poisons the writer')
        h.check(len(after) > len(before) and
                observed['journal_bytes_added'] == len(after) - len(before),
                'post-transfer fault retains the synchronized complete NST3 frame')
        h.check(work['outbound_store_ownership_transfers'] == 1 and
                work['outbound_store_publication_checks'] == 1 and
                work['outbound_store_payload_bytes_transferred'] > 0,
                'the injected failure occurs after exactly one publication-bound transfer')
        offline = inspect(h, 'post-append-failure-after-restart', a)['source_subscriptions'][0]
        h.check(offline['issued'] == 1 and offline['revision'] == created['revision'] + 1,
                'restart independently replays the durable complete source issue')
        dump(h, 'POST-APPEND-FAILURE', result)
    h.case('post_append_transfer_failure_poisoning_and_replay',
           post_append_failure_poisoning)

    def terminal_seal() -> None:
        a, c, pa, pc, ad, cd = pair(h, 'terminal-seal', 8)
        ad.shutdown(); cd.shutdown()
        frozen = (a / 'state.journal').read_bytes()
        result = invoke('terminal-seal-probe', a, 'terminal-seal')
        h.check(result['result']['rejected_after_seal'] == 4, 'append, compaction, authentication and repeated seal refuse')
        h.check((a / 'state.journal').read_bytes() == frozen, 'process-local terminal seal publishes no bytes')
        inspect(h, 'terminal-seal-replay', a)
        dump(h, 'TERMINAL-SEAL', result)
    h.case('terminal_seal_refuses_later_mutation', terminal_seal)

    def outbound_boundary() -> None:
        a,c,pa,pc,ad,cd = pair(h, 'outbound-boundary', 8)
        author(h, 'outbound-source', a, value='exact nested owned bytes')
        created=compact(h, 'outbound-create', a, 'create')
        ad.shutdown();cd.shutdown()
        frozen=(a/'state.journal').read_bytes()
        result=invoke('outbound-probe', a, 'outbound')
        h.check((a/'state.journal').read_bytes()==frozen, 'nested boundary probes publish no original mutation')
        observed=result['result']
        h.check(len(observed['rejected_boundaries']) >= 37, 'byte, origin, replay, transfer and actual admission boundaries reject')
        h.check(observed['checks'] == len(observed['rejected_boundaries']) + 14,
                'explicit native positive and negative check accounting')
        h.check(observed['live_work']['outbound_record_decodes']==0 and
                observed['replay_work']['outbound_record_decodes']==2 and
                observed['generic_work']['outbound_record_decodes']==2,
                'live reuse never extends to generic writers or independent replay')
        h.check(observed['parse_work']['source_composite_return_payload_bytes_copied']==0 and
                observed['parse_work']['source_composite_return_ownership_transfers']==1 and
                observed['parse_work']['source_composite_return_payload_bytes_transferred']>0,
                'strict parse transfers one owned payload with no return copy')
        after=inspect(h, 'outbound-after-probe', a)['source_subscriptions'][0]
        h.check(after['issued']==0 and after['revision']==created['revision'], 'all discarded preparations leave canonical source unchanged')
        dump(h, 'OUTBOUND-BOUNDARIES', result)
    h.case('exact_nested_outbound_record_binding', outbound_boundary)

    def boundary() -> None:
        a, c, pa, pc, ad, cd = pair(h, 'private-boundary', 8)
        original = author(h, 'private-original', a, value='private exact source')['operation_id']
        author(h, 'private-correction', a, parent=original, value='private exact correction')
        created = compact(h, 'private-create', a, 'create')
        ad.shutdown(); cd.shutdown()
        frozen = (a / 'state.journal').read_bytes()
        result = invoke('private-probe', a, 'boundary')
        h.check((a / 'state.journal').read_bytes() == frozen, 'private probe changes no durable fixture bytes')
        observed = result['result']
        h.check(len(observed['rejected_boundaries']) == 33, 'all 33 changed preparation/state/transaction boundaries reject')
        h.check(observed['checks'] == 37, 'native checks include valid reuse, independent replay and clean retry')
        h.check(result['journal_before_sha256'] == result['journal_after_sha256'], 'native preflight does not append')
        offline = inspect(h, 'private-after-probe', a)['source_subscriptions'][0]
        h.check(offline['issued'] == 0 and offline['revision'] == created['revision'], 'rejections retain original canonical predecessor')
        dump(h, 'BOUNDARIES', result)
    h.case('private_preparation_boundaries_and_replay', boundary)

    def eligibility_boundaries() -> None:
        a, c, pa, pc, ad, cd = pair(h, 'eligibility-boundary', 8)
        disabled = candidate(h, pa, 'eligibility-route-disabled',
            'eligibility-route-disabled-g1',
            lambda text: text.replace('peer_route=C,primary,0,ENABLED',
                                      'peer_route=C,primary,0,DISABLED'))
        activate(h, 'eligibility-route-disable', a, disabled)
        author(h, 'eligibility-original', a, value='eligibility original')
        author(h, 'eligibility-second', a, value='eligibility second')
        created = compact(h, 'eligibility-create', a, 'create')
        enabled = automatic(h, 'eligibility-enable', a, 'enable',
                            previous=created, maximum=2, interval=60000)
        h.check(enabled['issued'] == 0 and
                enabled['automatic_current']['steps'] == 0,
                'disabled route leaves the enabled source unissued')
        ad.shutdown(); cd.shutdown()
        frozen = (a / 'state.journal').read_bytes()
        result = invoke('eligibility-boundary-probe', a, 'eligibility')
        h.check((a / 'state.journal').read_bytes() == frozen,
                'eligibility boundary probe appends no durable bytes')
        observed = result['result']; work = observed['reuse_work']
        h.check(len(observed['rejected_boundaries']) == 31 and
                observed['checks'] == 33,
                'all 31 changed eligibility/state boundaries reject')
        h.check(work['source_records_reconstructed'] == 1 and
                work['automatic_eligibility_candidates'] == 1 and
                work['automatic_eligibility_source_reconstructions'] == 1 and
                work['automatic_eligibility_reuses'] == 1 and
                work['preparation_source_reconstructions'] == 0,
                'one classified envelope is consumed without reconstruction')
        dump(h, 'ELIGIBILITY-BOUNDARIES', result)
    h.case('automatic_eligibility_boundaries_and_read_only_scope',
           eligibility_boundaries)

    def automatic_receipt() -> None:
        a, c, pa, pc, ad, cd = pair(h, 'native-auto', 8)
        author(h, 'native-auto-source', a, value='actual automatically delivered source')
        compact(h, 'native-auto-create', a, 'create')
        ad.shutdown(); cd.shutdown()
        issued = invoke('native-auto-issue', a, 'automatic')
        h.check(issued['result']['transition'] == 'AUTO_ISSUE' and issued['result']['steps'] == 1,
                'native worker routine commits source and exactly one finite step')
        # No recipient is running until this daemon is ready. Pause only the
        # next automatic semantic commit; outbox transport still obtains a real receipt.
        ad = h.start('native-auto-await-receipt', pa, a,
                     {'NATRAV_OVERLAY_TEST_AUTOMATIC_SOURCE_BEFORE_COMMIT_MS': '5000'})
        cd = h.start('native-auto-recipient', pc, c)
        def receipt_committed() -> bool:
            return any((frame[8] == 3 or (frame[8] == 23 and frame[17] == 3))
                       for frame in journal_frames(a / 'state.journal'))
        h.wait('actual durable receipt before paused automatic acknowledgment', receipt_committed)
        ad.kill(); cd.shutdown()
        before = inspect(h, 'native-auto-before-ack', a)['source_subscriptions'][0]
        h.check(before['acknowledged'] == 0 and before['automatic_current']['steps'] == 1,
                'kill during precommit retains receipt without false automatic acknowledgment')
        acknowledged = invoke('native-auto-ack', a, 'automatic')
        after = acknowledged['result']
        h.check(after['transition'] == 'AUTO_ACK' and after['acknowledged'] == 1 and
                after['steps'] == 2 and after['grant_state'] == 'EXHAUSTED',
                'actual receipt advances exactly the remaining finite step')
        replayed = invoke('native-auto-replay', a, 'replay')
        work = replayed['construction_work']
        h.check(work['preparations_created'] == work['preflight_preparation_uses'] ==
                work['application_preparation_uses'] == 0, 'untrusted replay creates or consumes no command preparation')
        h.check(work['replay_source_reconstructions'] == 1,
                'sequential NST3 replay independently reconstructs its issued source')
        h.check(replayed['logical_state_digest'] == acknowledged['logical_state_digest'],
                'fresh independent replay equals live prepared automatic state on identical bytes')
        dump(h, 'AUTOMATIC-WORK', {'issue': issued, 'ack': acknowledged, 'replay': replayed})
    h.case('automatic_preparation_actual_receipt_kill_and_independent_replay', automatic_receipt)

    def successor_correction() -> None:
        a, c, pa, pc, ad, cd, current = lease_setup(
            h, 'eligibility-successor', maximum=1)
        original = author(h, 'eligibility-successor-original', a,
                          value='predecessor source')['operation_id']
        issued = lease_local(h, 'eligibility-predecessor-issue', a,
                             'step', previous=current)
        current = lease_received(h, 'eligibility-predecessor', a, issued)
        terminal = withdraw(h, 'eligibility-predecessor', a, pc, current)
        pa2 = add_grant(h, pa, a, 'eligibility-successor-g2', maximum=2,
                        maximum_bytes=10000)
        successor = succeed(h, 'eligibility-successor-create', a, terminal)
        author(h, 'eligibility-successor-correction', a, parent=original,
               value='successor correction')
        ad.shutdown()
        ad = h.start('eligibility-successor-paused', pa2, a,
                     {'NATRAV_OVERLAY_TEST_AUTOMATIC_SOURCE_BEFORE_COMMIT_MS': '5000'})
        automatic(h, 'eligibility-successor-enable', a, 'enable', grant='g2',
                  previous=successor, maximum=2, interval=60000)
        time.sleep(0.2)
        ad.kill(); cd.shutdown()
        result = invoke('eligibility-successor-issue', a, 'automatic')
        observed = result['result']; work = observed['work']
        h.check(observed['grant'] == 'g2' and
                observed['transition'] == 'AUTO_ISSUE',
                'private worker issues the active successor lease')
        h.check(work['source_records_reconstructed'] == 1 and
                work['automatic_eligibility_reuses'] == 1 and
                work['preparation_source_reconstructions'] == 0,
                'successor correction reuses its classified envelope once')
        h.check(work['mapping_index_lookups'] == 1 and
                work['mapping_index_hits'] == 1 and
                work['mapping_entries_visited'] == 0,
                'successor correction resolves retained ancestry once by index')
        replayed = invoke('eligibility-successor-replay', a, 'replay')
        h.check(replayed['logical_state_digest'] == result['logical_state_digest'],
                'independent replay equals the live successor issue')
        dump(h, 'SUCCESSOR-CORRECTION', {'issue': result, 'replay': replayed})
    h.case('automatic_successor_correction_single_construction',
           successor_correction)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--probe', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--negative-control', action='store_true')
    parser.add_argument('--transaction-negative-control', action='store_true')
    parser.add_argument('--outbound-negative-control', action='store_true')
    parser.add_argument('--outgoing-slice-negative-control', action='store_true')
    parser.add_argument('--outbound-transfer-negative-control', action='store_true')
    args = parser.parse_args()
    if args.output.exists():
        parser.error('output must not exist')
    h = Harness(args.binary, args.output)
    started = time.monotonic(); ok = False
    try:
        run_cases(h, args.probe.resolve(strict=True), args.negative_control,
                  args.transaction_negative_control, args.outbound_negative_control,
                  args.outgoing_slice_negative_control,
                  args.outbound_transfer_negative_control)
        ok = True
    except BaseException as error:
        (h.output / 'FAILURE.txt').write_text(f'{type(error).__name__}: {error}\n')
        print(f'FAIL: {type(error).__name__}: {error}', file=os.sys.stderr)
    finally:
        h.cleanup()
        summary = {'format': 'SOURCE_ELIGIBILITY_BOUNDARY_TESTS_V1', 'status': 'PASS' if ok else 'FAIL',
                   'negative_control': args.negative_control, 'transaction_negative_control': args.transaction_negative_control, 'outbound_negative_control': args.outbound_negative_control, 'outgoing_slice_negative_control': args.outgoing_slice_negative_control, 'outbound_transfer_negative_control': args.outbound_transfer_negative_control,
                   'binary_sha256': hashlib.sha256(h.binary.read_bytes()).hexdigest(),
                   'probe_sha256': hashlib.sha256(args.probe.read_bytes()).hexdigest(),
                   'cases_total': len(h.cases), 'cases_passed': sum(c['status'] == 'PASS' for c in h.cases),
                   'assertions': h.assertions, 'commands': len(h.commands),
                   'elapsed_seconds': time.monotonic() - started}
        for name, data in [('SUMMARY', summary), ('CASES', h.cases), ('COMMANDS', h.commands)]:
            dump(h, name, data)
        print(json.dumps(summary), flush=True)
    return 0 if ok else 1

if __name__ == '__main__':
    raise SystemExit(main())
