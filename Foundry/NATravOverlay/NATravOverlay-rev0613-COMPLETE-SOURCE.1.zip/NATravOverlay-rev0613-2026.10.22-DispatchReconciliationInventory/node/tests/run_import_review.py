#!/usr/bin/env python3
"""Owner-bound administrative import review and finite exact reconsideration.
All peers, identities, state and fault injection are owned local test fixtures.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, signal, socket, struct, subprocess, time
from pathlib import Path
from run_persistent import Harness,operation,raw_control,receive_exact
from run_subscribed_source_views import setup,emit,materialize,SCOPE,TARGET,fields
from run_import_automation import auto,until,allrows
from run_source_subscriptions import command,ack
from run_local_evidence import author
from run_local_administration import run_as_uid,expose_control_for_uid
from run_live_configuration import candidate,activate,wait_state
from run_state_authentication import new_key,migrate,start as start_keyed,inspect,checksum_frame


def review(h,label,c,*,view='temps',uid=None,expected=0,after=0,prefix=None,limit=16,maximum=32768):
    args=['source-view-decisions','--control',str(c/'control.sock'),'--view',view,'--after-revision',str(after),'--limit',str(limit),'--max-bytes',str(maximum),'--deadline-ms','5000']
    if prefix:args+=['--through-revision',str(prefix['through_revision']),'--history-digest',prefix['history_digest']]
    return h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)


def retry_args(c,page,decision,*,reason='explicit one-source reconsideration',view='temps'):
    return ['source-view-retry','--control',str(c/'control.sock'),'--view',view,
            '--expected-revision',str(page['current_revision']),'--decision-revision',str(decision['revision']),
            '--decision-digest',decision['decision_digest'],'--operation',decision['outer_operation'],
            '--view-digest',page['view_digest'],'--configuration-digest',page['configuration_digest'],
            '--reason',reason,'--deadline-ms','5000']


def retry(h,label,c,page,decision,*,reason='explicit one-source reconsideration',uid=None,view='temps',expected=0):
    args=retry_args(c,page,decision,reason=reason,view=view)
    return h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)


def denied_setup(h,name,*,delegates=False,view='temps',uid=None):
    a,c,ac,cc,ad,cd,s=setup(h,name,delegates=delegates)
    ac2=candidate(h,ac,name+'-g2-provider',name+'-g2-provider-g1',lambda t:t+f'source_disclosure=g2,{os.geteuid()},{os.geteuid()},C,c-g1,{SCOPE},128,1000000\n')
    activate(h,name+'-g2-provider-accept',a,ac2)
    sub=command(h,name+'-g2-create',a,'create',grant='g2')
    src=author(h,name+'-source',a,ticks=125)
    issue=command(h,name+'-g2-issue',a,'step',grant='g2',previous=sub);sub=ack(h,name+'-g2-ack',a,issue,grant='g2')
    if uid is not None:expose_control_for_uid(c)
    before=auto(h,name+'-initial',c,view=view,uid=uid)
    auto(h,name+'-enable',c,'enable',previous=before,view=view,uid=uid,imports=4,decisions=1)
    stopped=until(h,name+'-denied',c,lambda x:x['state']=='EXHAUSTED',view=view,uid=uid)
    page=review(h,name+'-review',c,view=view,uid=uid)
    selected=next(e for e in page['events'] if e['outer_operation']==issue['latest']['operation_id'])
    h.check(selected['outcome']=='SOURCE_VIEW_SUBSCRIPTION_DENIED','unapproved exact binding is a retained skipped decision')
    cc2=candidate(h,cc,name+'-binding',name+'-binding-g1',lambda t:t+f'source_view_binding={view},g2,{sub["instance"]},{sub["grant_digest"]},-\n')
    return a,c,ac2,cc,cc2,ad,cd,sub,src,selected,stopped


def frames(raw):
    result=[];at=0
    while at<len(raw):
        n=int.from_bytes(raw[at+4:at+8],'big');f=raw[at:at+n+40]
        if len(f)!=n+40:raise AssertionError('partial fixture frame')
        result.append(f);at+=n+40
    return result


def run_cases(h,selected):
    def case(name,fn):
        if selected is None or name in selected:h.case(name,fn)

    def pagination():
        a,c,ac,cc,ad,cd,s=setup(h,'review')
        for n in range(5):_,s,_=emit(h,'page-source-'+str(n),a,c,s,ticks=n)
        auto(h,'page-enable',c,'enable',previous=auto(h,'page-start',c),imports=5)
        until(h,'page-stopped',c,lambda x:x['state']=='EXHAUSTED')
        size=(c/'state.journal').stat().st_size
        first=review(h,'first-page',c,limit=2,maximum=4096);pages=[first];events=list(first['events']);p=first
        while p['more']:
            p=review(h,'next-page',c,prefix=first,after=p['next_after_revision'],limit=2,maximum=4096);pages.append(p);events+=p['events']
        h.check([e['revision'] for e in events]==list(range(1,7)),'bounded pages enumerate exact immutable event order')
        h.check(all(len(json.dumps(p,separators=(',',':')).encode())<=4096 for p in pages),'full annotated reply stays within requested byte bound')
        h.check('payload_hex' not in json.dumps(pages) and 'payload_text' not in json.dumps(pages),'SOURCE_IMPORT review carries no raw payload material')
        empty=review(h,'caught-up',c,after=first['through_revision'],prefix=first)
        h.check(empty['events']==[] and empty['decisions_visited']==0,'empty page visits no decisions')
        h.check((c/'state.journal').stat().st_size==size,'successful pages are observational')
        new=auto(h,'page-later-enable',c,'enable',previous=auto(h,'latest-schedule',c),imports=1)
        auto(h,'page-later-pause',c,'pause',previous=new)
        old=review(h,'prefix-survives-append',c,prefix=first,limit=32)
        h.check(old['events']==events and old['through_revision']==6 and old['current_revision']==8,'selected prefix remains stable across later events')
        bad=dict(first,history_digest=operation('wrong-history'))
        h.check(review(h,'wrong-prefix',c,prefix=bad,expected=3)['code']=='IMPORT_REVIEW_PREFIX_CONFLICT','wrong selected prefix fails')
        # Independent NIR2 encoding; request framing is the established control kind 22.
        text=lambda s:struct.pack('!H',len(s))+s.encode()
        wire=b'NOC1\x16NIR2\x04'+text('temps')+struct.pack('!QQ',0,6)+bytes.fromhex(first['history_digest'])+struct.pack('!II',32,60000)
        ok,independent=raw_control(c/'control.sock',wire)
        h.check(ok and independent['events']==events,'independent strict review wire matches native CLI')
        ok,_=raw_control(c/'control.sock',wire+b'x');h.check(not ok,'trailing review material rejected')
        # Compaction and restart preserve the same prefix commitments.
        h.run('page-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown();cd=h.start('page-restart',cc,c)
        h.check(review(h,'restored-page',c,prefix=first,limit=32)['events']==events,'review prefix survives checkpoint and restart')
        (h.output/'PAGINATION.json').write_text(json.dumps({'pages':pages,'old_prefix':old},indent=2)+'\n')
        cd.shutdown();ad.shutdown()
    case('bounded_observational_prefix_pages_wire_and_restart',pagination)

    def selective():
        a,c,ac,cc,cc2,ad,cd,sub,src,decision,stopped=denied_setup(h,'select')
        old=review(h,'old-policy-page',c)
        activate(h,'select-accept-pin',c,cc2)
        h.check(retry(h,'stale-config',c,old,decision,expected=3)['code']=='IMPORT_RETRY_CONFIGURATION_CONFLICT','new retry must select current accepted configuration')
        page=review(h,'current-policy-page',c)
        for field,code in [('decision_digest','IMPORT_RETRY_DECISION_CONFLICT'),('outer_operation','IMPORT_RETRY_OPERATION_CONFLICT')]:
            altered=dict(decision);altered[field]=operation('wrong-'+field)
            h.check(retry(h,'wrong-'+field,c,page,altered,expected=3)['code']==code,'exact selected '+field+' enforced')
        args=retry_args(c,page,decision)
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda i:h.run('concurrent-retry-'+str(i),args),range(8)))
        h.check(sum(r['status']=='RECONSIDERED' for r in results)==1 and sum(r['status']=='ALREADY_RECONSIDERED' for r in results)==7,'one commit and seven exact idempotent observations')
        state=auto(h,'after-reconsideration',c)
        h.check(state['next_position']==stopped['next_position'] and state['imports']==stopped['imports'] and state['decisions']==stopped['decisions'] and state['generation']==stopped['generation'] and state['state']==stopped['state'],'no scan rewind, automation refund, policy adoption or resume')
        rows=allrows(h,'retried-payload',c)
        h.check(len(rows)==1 and rows[0]['subscribed_source']['execution_actor']=='LOCAL_IMPORT_RETRY' and rows[0]['subscribed_source']['import_uid']==os.geteuid(),'manual retry provenance is actual local principal')
        h.check(state['manual_retries']==1,'one separate manual allowance consumed')
        stable=(c/'state.journal').stat().st_size
        h.run('exact-reply-retry',args);h.check((c/'state.journal').stat().st_size==stable,'lost-response retry writes no second successful event')
        current=review(h,'new-selection',c)
        dup=retry(h,'explicit-second-attempt',c,current,decision,reason='confirm already imported source')
        h.check(dup['decision']['outcome']=='DUPLICATE' and dup['schedule']['manual_retries']==2,'a distinct reconsideration is attributable and bounded, never another import')
        enabled=auto(h,'enable-for-boundary',c,'enable',previous=dup['schedule'],imports=2)
        page=review(h,'enabled-page',c)
        h.check(retry(h,'enabled-deny',c,page,decision,reason='must pause',expected=3)['code']=='IMPORT_RETRY_AUTOMATION_ENABLED','manual scheduling mutation cannot race enabled worker')
        auto(h,'pause-after-boundary',c,'pause',previous=enabled)
        cd.shutdown();original=(c/'state.journal').read_bytes();fs=frames(original)
        records=[f for f in fs if f[8]==34]
        # Independently verify the exact event commitments returned by review.
        for f in records:
            payload=f[9:-32]
            h.check(payload[:4] in (b'NIE1',b'NIE2'),'normal kind34 payload version')
        hashes=[hashlib.sha256(b'NATRAV_OVERLAY_IMPORT_EVENT_V1\0'+f[9:-32]).hexdigest() for f in records]
        expected=[e['decision_digest'] for e in review_after_restart(h,c,cc,'all-events')['events']]
        h.check(hashes==expected,'independent raw-journal hashes match review identities')
        (h.output/'SELECTIVE.json').write_text(json.dumps({'result':results[0],'schedule':state,'rows':rows},indent=2)+'\n')
        ad.shutdown()
    case('exact_reconsideration_current_policy_concurrency_and_provenance',selective)

    def limits():
        a,c,ac,cc,ad,cd,s=setup(h,'limits')
        op=operation('permanent-malformed')
        h.run('malformed-send',['submit','--control',str(a/'control.sock'),'--node','A','--peer','C','--scope',SCOPE,'--operation',op,'--payload-text','bad'])
        wait_state(h,a,op,'ACKED','bad-admitted')
        auto(h,'limits-enable',c,'enable',previous=auto(h,'limits-initial',c),imports=4,decisions=1)
        until(h,'limits-stop',c,lambda x:x['state']=='EXHAUSTED')
        page=review(h,'limits-review',c);decision=next(e for e in page['events'] if e['outer_operation']==op)
        outcome=decision['outcome']
        for i in range(64):
            result=retry(h,'bounded-manual-'+str(i),c,page,decision,reason='explicit inspection '+str(i))
            h.check(result['decision']['outcome']==outcome and result['schedule']['imports']==0 and result['schedule']['decisions']==1,'invalid bytes stay rejected without automatic budget change')
            page=dict(page,current_revision=result['schedule']['revision'])
        h.check(retry(h,'sixty-fifth-rejected',c,page,decision,reason='no implicit renewal',expected=3)['code']=='IMPORT_RETRY_LIMIT','64 retained manual attempts is exact hard bound')
        h.run('limits-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown();cd=h.start('limits-restart',cc,c)
        h.check(auto(h,'limit-preserved',c)['manual_retries']==64 and len(allrows(h,'invalid-never-imported',c))==0,'bound and denial history survive checkpoint')
        first=review(h,'large-page',c,limit=32,maximum=16384)
        h.check(len(json.dumps(first,separators=(',',':')).encode())<=16384 and 0<len(first['events'])<=32 and first['more'],'byte limit makes bounded progress through full manual history')
        (h.output/'LIMITS.json').write_text(json.dumps({'manual_retries':64,'page':first},indent=2)+'\n');cd.shutdown();ad.shutdown()
    case('finite_manual_budget_malformed_sources_and_page_bytes',limits)

    def dependencies():
        a,c,ac,cc,cc2,ad,cd,sub,src,parent_decision,stopped=denied_setup(h,'dependencies')
        activate(h,'dependency-pins',c,cc2)
        enabled=auto(h,'dependency-enable',c,'enable',previous=stopped,imports=8)
        child=author(h,'child',a,ticks=175,parent=src['operation_id'])
        issue=command(h,'child-issue',a,'step',grant='g2',previous=sub);sub=ack(h,'child-ack',a,issue,grant='g2')
        waiting=until(h,'deferred-child',c,lambda x:len(x['deferred'])==1)
        independent=author(h,'independent',a,ticks=25)
        issue2=command(h,'independent-issue',a,'step',grant='g2',previous=sub);sub=ack(h,'independent-ack',a,issue2,grant='g2')
        progressed=until(h,'independent-progress',c,lambda x:x['imports']==1)
        paused=auto(h,'pause-for-review',c,'pause',previous=progressed)
        p=review(h,'dependency-page',c);child_decision=next(e for e in p['events'] if e['outer_operation']==issue['latest']['operation_id'])
        still=retry(h,'missing-still-missing',c,p,child_decision)
        h.check(still['decision']['outcome']=='SOURCE_VIEW_PARENT_REQUIRED' and len(still['schedule']['deferred'])==1,'explicit missing-parent retry retains bounded dependency, not fake ancestry')
        p=review(h,'parent-now-select',c);parent_result=retry(h,'parent-approved',c,p,parent_decision)
        p=review(h,'child-now-select',c);done=retry(h,'child-now-ready',c,p,child_decision,reason='parent now materialized')
        h.check(done['decision']['outcome']=='IMPORTED' and not done['schedule']['deferred'] and done['schedule']['imports']==paused['imports'],'manual imports resolve dependency without spending automatic grant')
        rows=allrows(h,'all-dependent-rows',c)
        parent_row=next(r for r in rows if r['subscribed_source']['source_operation']==src['operation_id'])
        child_row=next(r for r in rows if r['subscribed_source']['source_operation']==child['operation_id'])
        h.check(len(rows)==3 and child_row['corrects']==parent_row['operation_id'],'independent source and exact correction ancestry preserved')
        h.run('dependency-review-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown();cd=h.start('dependency-review-replay',cc2,c)
        h.check(auto(h,'dependency-review-after',c)['history_digest']==done['schedule']['history_digest'],'replay evaluates missing parent at its historical prefix')
        cd.shutdown();ad.shutdown()
    case('deferred_retry_missing_parent_and_independent_progress',dependencies)

    def principals():
        a,c,ac,cc,cc2,ad,cd,sub,src,decision,stopped=denied_setup(h,'principals',delegates=True,view='delegated',uid=65534)
        h.check(review(h,'other-review-denied',c,view='delegated',uid=65533,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','metadata reader has no import review authority')
        h.check(review(h,'owner-is-not-manager',c,view='delegated',expected=3)['code']=='IMPORT_AUTO_POLICY_DENIED','daemon UID cannot impersonate delegated owner')
        activate(h,'principal-pin',c,cc2)
        p=review(h,'delegated-current',c,view='delegated',uid=65534)
        r=retry(h,'actual-uid-retry',c,p,decision,view='delegated',uid=65534)
        h.check(r['decision']['actor_uid']==65534 and r['schedule']['manual_retries']==1,'kernel delegated UID is recorded')
        # A native request encoder independent of the product, deliberately held
        # after connection acceptance and before complete request decoding.
        p=review(h,'slow-current',c,view='delegated',uid=65534)
        text=lambda v:struct.pack('!H',len(v))+v.encode()
        wire=b'NOC1\x16NIR2\x05'+text('delegated')+struct.pack('!Q',p['current_revision'])+text('slow request after policy change')+struct.pack('!Q',decision['revision'])+b''.join(bytes.fromhex(x) for x in [decision['decision_digest'],decision['outer_operation'],p['view_digest'],p['configuration_digest']])
        rendezvous=h.runtime/'uid-rendezvous';rendezvous.mkdir();rendezvous.chmod(0o777)
        script=h.work/'slow.py';sent=rendezvous/'slow.sent';go=rendezvous/'slow.go';out=rendezvous/'slow.result'
        script.write_text('import socket,struct,time,json,sys\ns=socket.socket(socket.AF_UNIX);s.settimeout(12);s.connect(sys.argv[1]);b=bytes.fromhex(sys.argv[2]);s.sendall(struct.pack("!I",len(b))+b[:1]);open(sys.argv[3],"w").close()\nwhile not __import__("os").path.exists(sys.argv[4]):time.sleep(.01)\ns.sendall(b[1:]);s.shutdown(socket.SHUT_WR)\ndef exact(n):\n b=b""\n while len(b)<n:b+=s.recv(n-len(b))\n return b\nr=exact(struct.unpack("!I",exact(4))[0]);open(sys.argv[5],"wb").write(r)\n')
        # Script/markers are disposable, intentionally accessible for this UID.
        h.work.chmod(0o755);script.chmod(0o644)
        proc=subprocess.Popen(['setpriv','--reuid=65534','--regid=65534','--clear-groups','python3',str(script),str(c/'control.sock'),wire.hex(),str(sent),str(go),str(out)],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        h.wait('slow frame started',lambda:sent.exists(),3)
        def remove(t):return '\n'.join(l for l in t.splitlines() if not l.startswith(('local_control=65534,','source_view=delegated,','source_view_binding=delegated,')))+'\n'
        revoked=candidate(h,cc2,'principal-revoked','principal-revoked-g1',remove);activate(h,'revoke-before-decode',c,revoked);go.touch()
        _,err=proc.communicate(timeout=15);h.check(proc.returncode==0,'different-UID slow client completed: '+err.decode())
        answer=json.loads(out.read_bytes()[5:]);h.check(answer['code']=='LOCAL_CONTROL_CLASS_DENIED','completed slow request uses current authority')
        cd.shutdown();ad.shutdown()
    case('real_uid_ownership_and_revocation_after_connection',principals)

    def kills_and_corruption():
        for point in ('BEFORE','AFTER'):
            a,c,ac,cc,cc2,ad,cd,sub,src,decision,stopped=denied_setup(h,'kill-'+point.lower())
            activate(h,'kill-accept-'+point,c,cc2);page=review(h,'kill-review-'+point,c);args=retry_args(c,page,decision)
            cd.shutdown();old=os.environ.get('NATRAV_OVERLAY_TEST_IMPORT_RETRY_'+point+'_COMMIT_MS');os.environ['NATRAV_OVERLAY_TEST_IMPORT_RETRY_'+point+'_COMMIT_MS']='3000'
            try:cd=h.start('kill-hook-'+point,cc2,c)
            finally:
                if old is None:os.environ.pop('NATRAV_OVERLAY_TEST_IMPORT_RETRY_'+point+'_COMMIT_MS',None)
                else:os.environ['NATRAV_OVERLAY_TEST_IMPORT_RETRY_'+point+'_COMMIT_MS']=old
            original=(c/'state.journal').read_bytes()
            client=subprocess.Popen([str(h.binary),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            if point=='AFTER':h.wait('manual retry committed',lambda:(c/'state.journal').stat().st_size>len(original),3)
            else:time.sleep(.6)
            cd.kill();client.communicate(timeout=8)
            cd=h.start('kill-restored-'+point,cc2,c)
            after=auto(h,'kill-state-'+point,c);h.check(after['manual_retries']==(1 if point=='AFTER' else 0),'crash preserves all-or-neither import and manual allowance')
            result=h.run('kill-safe-retry-'+point,args)
            h.check(result['status']==('ALREADY_RECONSIDERED' if point=='AFTER' else 'RECONSIDERED'),'lost reply safely reconstructs exact disposition')
            h.check(len(allrows(h,'kill-unique-'+point,c))==1,'only one imported source')
            cd.shutdown();raw=(c/'state.journal').read_bytes();fs=frames(raw);i=next(i for i,f in enumerate(fs) if f[8]==34 and f[9:13]==b'NIE2')
            forged=fs.copy();f=bytearray(forged[i]);position=f.index(bytes.fromhex(decision['decision_digest']));f[position]^=1;forged[i]=checksum_frame(bytes(f));(c/'state.journal').write_bytes(b''.join(forged))
            h.run('forged-selection-'+point,['inspect','--state',str(c),'--node','C'],expected=3)
            (c/'state.journal').write_bytes(raw);cd=h.start('valid-for-compact-'+point,cc2,c);h.run('retry-compact-'+point,['compact','--control',str(c/'control.sock')]);cd.shutdown()
            cp=(c/'state.journal').read_bytes();f=bytearray(cp);p=f.index(bytes.fromhex(decision['decision_digest']));f[p]^=1;(c/'state.journal').write_bytes(checksum_frame(bytes(f)))
            h.run('forged-checkpoint-'+point,['inspect','--state',str(c),'--node','C'],expected=3);(c/'state.journal').write_bytes(cp)
            ad.shutdown()
    case('atomic_kills_exact_retry_and_semantic_corruption',kills_and_corruption)

    def maintenance():
        a,c,ac,cc,cc2,ad,cd,sub,src,decision,stopped=denied_setup(h,'maintenance')
        activate(h,'maintenance-accept',c,cc2);p=review(h,'maintenance-page',c);r=retry(h,'maintenance-retry',c,p,decision);args=retry_args(c,p,decision)
        cd.shutdown();key=new_key(h,h.work,'review-state-g1');migrate(h,'review-migrate',c,key,node='C');cd=start_keyed(h,'review-keyed',cc2,c,key)
        h.run('review-keyed-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown();h.run('review-audit',['state-auth-audit','--state',str(c),'--node','C','--state-auth-key',str(key)])
        before=inspect(h,'before-review-backup',c,key,node='C');crypt=h.work/'review.key';h.run('review-key',['backup-key-init','--output',str(crypt),'--generation','review-backup'])
        ident=h.identity('C');archive=h.work/'review.nob';h.run('review-export',['backup-export','--state',str(c),'--node','C','--generation','c-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'review-restored';h.run('review-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','C','--generation','c-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'restored-review-state',restored,key,node='C');h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'encrypted restore preserves decision and effect logical state')
        moved=candidate(h,cc2,'review-moved','review-moved-g1',lambda t:t.replace('state='+str(c),'state='+str(restored)))
        h.run('review-relocate',['state-relocate','--state',str(restored),'--node','C','--candidate',str(moved),'--reason','owned relocation','--state-auth-key',str(key)])
        cd=start_keyed(h,'review-after-restore',moved,restored,key)
        replay_args=args.copy();replay_args[replay_args.index('--control')+1]=str(restored/'control.sock')
        h.check(h.run('review-old-idempotent',replay_args)['status']=='ALREADY_RECONSIDERED','same accepted retry survives relocation without re-import')
        h.check(review(h,'review-old-prefix',restored,prefix=p)['events']==p['events'],'selected old review prefix survives restore and relocation')
        child=author(h,'later-child',a,ticks=200,parent=src['operation_id']);issued=command(h,'later-child-issue',a,'step',grant='g2',previous=sub);ack(h,'later-child-ack',a,issued,grant='g2')
        auto(h,'explicit-new-automation',restored,'enable',previous=auto(h,'restored-old-grant',restored),imports=1)
        final=until(h,'later-child-imported',restored,lambda x:x['state']=='EXHAUSTED')
        h.check(final['manual_retries']==1 and len(allrows(h,'restored-new-correction',restored))==2,'manual history preserved while new explicit automation progresses')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'before':before['storage']['logical_state_digest'],'after':after['storage']['logical_state_digest'],'final':final},indent=2)+'\n')
        cd.shutdown();ad.shutdown()
    case('keyed_audit_encrypted_restore_relocation_and_continuation',maintenance)


def review_after_restart(h,c,config,label):
    daemon=h.start(label,config,c)
    result=review(h,label,c,limit=32);daemon.shutdown();return result

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);t=time.time();ok=False
    try:run_cases(h,set(a.case) if a.case else None);ok=True
    except BaseException as exc:(h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(f'FAIL: {type(exc).__name__}: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup();s={'format':'NATRAV_OVERLAY_IMPORT_REVIEW_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-t}
        for name,v in [('SUMMARY',s),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
        print(json.dumps(s),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
