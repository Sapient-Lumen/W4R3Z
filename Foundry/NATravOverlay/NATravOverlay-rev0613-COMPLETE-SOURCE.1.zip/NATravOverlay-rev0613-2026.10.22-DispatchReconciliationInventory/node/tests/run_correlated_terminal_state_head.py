#!/usr/bin/env python3
"""Correlated terminal authenticated-head handoff through strict NOC1 kinds 46/47."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import time
from typing import Any, Callable

from run_persistent import Harness, free_port, operation, raw_control
from run_control_authorization import Client, packet, text
from run_correlated_stopping import request_id, lifecycle_for, decisions_for
from run_response_loss_stopping import drop_after_complete_request, wait_stopped, verify_keyed_state
from run_local_administration import expose_control_for_uid, restore_owner_only_control, v8_config
from run_live_configuration import activate, candidate
from run_control_history import history, reference
from run_state_authentication import independent_open, inspect, new_key, migrate, start
from run_state_expectations import selector

DELEGATED_UID = 65534
CASES = (
    "strict_wire_and_legacy_terminal_unchanged",
    "keyed_immediate_exact_head_and_identity",
    "immediate_response_loss_exact_identity",
    "drain_deadline_preserves_obligation",
    "duplicate_tokens_are_not_idempotency",
    "current_policy_revocation",
    "compaction_replay_and_exact_lookup",
)


def correlated_terminal_shutdown(token: str) -> bytes:
    return packet(46, text(token))


def correlated_terminal_drain(deadline_ms: int, reason: str, token: str) -> bytes:
    return packet(47, struct.pack("!I", deadline_ms), text(reason), text(token))


def setup_keyed(
    h: Harness,
    name: str,
    *,
    peers: list[tuple[str, int]] | None = None,
    grants: list[tuple[int, list[str]]] | None = None,
    environment: dict[str, str] | None = None,
):
    root = h.runtime / name
    root.mkdir(mode=0o755)
    state = root / "state"
    inspect(h, name + "-initialize", state)
    key = new_key(h, root, name + "-state")
    migrate(h, name + "-migrate", state, key)
    config = v8_config(
        h,
        name,
        "A",
        state,
        free_port(),
        name + "-g1",
        grants or [(os.geteuid(), ["ALL"])],
        peers=peers,
        deadline_ms=3000,
    )
    daemon = start(h, name, config, state, key, environment)
    return root, state, key, config, daemon


def terminal_args(control: Path, token: str, drain_ms: int | None = None, reason: str = "correlated terminal stop") -> list[str]:
    args = [
        "shutdown" if drain_ms is None else "drain-shutdown",
        "--control", str(control),
        "--correlation", token,
        "--final-state-head", "yes",
        "--deadline-ms", "12000",
    ]
    if drain_ms is not None:
        args += ["--reason", reason, "--drain-deadline-ms", str(drain_ms)]
    return args


def check_correlated_shape(h: Harness, value: dict[str, Any], token: str, expected_id: str, drain: bool) -> None:
    h.check(value.get("ok") is True and value.get("format") == "NATRAV_OVERLAY_CORRELATED_TERMINAL_STATE_HEAD_V1", "explicit correlated terminal response format")
    h.check(value.get("correlation_token") == token, "response returns exact caller-selected token")
    h.check(value.get("correlation_semantics") == "PROVENANCE_ONLY_NOT_IDEMPOTENCY_OR_RECEIPT", "response labels token as provenance only")
    h.check(value.get("request_id") == expected_id, "response carries independently derived exact request identity")
    h.check(value.get("command_class") == "SHUTDOWN", "terminal correlation changes no authorization class")
    h.check(value["shutdown"]["required_head_class"] == "INSPECT", "head disclosure retains separate INSPECT requirement")
    h.check(value["shutdown"]["writers_joined"] is True and value["shutdown"]["final_lifecycle_accounting"] == "COMPLETE", "reply follows writer joins and final lifecycle accounting")
    h.check(value["shutdown"]["delivery_confirmation"] == "NOT_ESTABLISHED", "response write is not represented as client receipt")
    h.check(value["shutdown"]["requested"] == ("DRAIN" if drain else "IMMEDIATE"), "response identifies stop kind")
    h.check(value["terminal"]["state_sealed"] is True and value["terminal"]["scope"] == "THIS_PROCESS_STOP_ONLY", "same-process state is sealed without excluding a replacement owner")
    h.check(value["state_head"]["freshness"] == "NOT_ESTABLISHED" and value["state_head"]["expectation"] == "NOT_CHECKED_HERE", "terminal head is not promoted to an external freshness proof")
    h.check(value["state_head"]["automatic_update"] is False and value["automatic_update"] is False, "terminal correlation never updates an external expectation")
    h.check(len(json.dumps(value, separators=(",", ":")).encode()) <= 4096, "complete correlated terminal reply remains within fixed ceiling")
    expected_fields = {
        "format", "ok", "node", "mode", "journal_bytes", "state_head", "authentication",
        "opening_expectation", "observation", "automatic_update", "terminal", "shutdown",
        "request_id", "principal_uid", "principal_gid", "principal_pid", "command_class",
        "correlation_token", "correlation_semantics",
    }
    h.check(set(value) == expected_fields, "correlated reply adds only the two explicit provenance fields")


def verify_stopped(
    h: Harness,
    label: str,
    daemon,
    state: Path,
    key: Path,
    value: dict[str, Any],
    token: str,
    expected_id: str,
    *,
    drain: bool,
) -> dict[str, Any]:
    check_correlated_shape(h, value, token, expected_id, drain)
    wait_stopped(h, daemon, label)
    raw = (state / "state.journal").read_bytes()
    h.check(len(raw) == value["journal_bytes"], "returned physical byte account equals stopped journal")
    independent_open(raw, key)
    h.check(selector(raw, key) == value["state_head"]["selector"], "independent authenticated-byte calculation equals terminal selector")
    snapshot = inspect(h, label + "-offline", state, key)
    h.check(snapshot["state_head"]["selector"] == value["state_head"]["selector"], "complete semantic replay agrees with terminal selector")
    h.check((state / "state.journal").read_bytes() == raw, "offline verification changes no stopped bytes")
    h.check(token.encode() not in raw, "token text is not copied into durable state")
    return snapshot


def run_suite(h: Harness, selected: set[str] | None) -> None:
    def case(name: str, function: Callable[[], None]) -> None:
        if selected is None or name in selected:
            h.case(name, function)

    def strict_wire_and_legacy_terminal_unchanged() -> None:
        _, state, key, _, daemon = setup_keyed(h, "correlated-terminal-wire")
        malformed = [
            ("empty", correlated_terminal_shutdown("")),
            ("uppercase", correlated_terminal_shutdown("Upper")),
            ("leading-punctuation", correlated_terminal_shutdown(".leading")),
            ("trailing-punctuation", correlated_terminal_shutdown("trailing-")),
            ("slash", correlated_terminal_shutdown("bad/path")),
            ("non-ascii", packet(46, struct.pack("!H", 2), b"\xc3\xa9")),
            ("too-long", correlated_terminal_shutdown("a" * 65)),
            ("trailing-byte", correlated_terminal_shutdown("valid-token") + b"x"),
            ("truncated-immediate", correlated_terminal_shutdown("valid-token")[:-1]),
            ("missing-drain-token", packet(47, struct.pack("!I", 100), text("missing token"))),
            ("zero-deadline", packet(47, struct.pack("!I", 0), text("reason"), text("valid-token"))),
            ("empty-reason", packet(47, struct.pack("!I", 100), text(""), text("valid-token"))),
            ("truncated-drain-token", correlated_terminal_drain(100, "truncated", "valid-token")[:-1]),
        ]
        for label, payload in malformed:
            ok, result = raw_control(daemon.control, payload)
            h.check(not ok and result.get("ok") is False and "state_head" not in result, label + " fails before head exposure")
            h.check(daemon.process is not None and daemon.process.poll() is None, label + " cannot create stop intent")

        old_payload = packet(42)
        old = h.run(
            "legacy-terminal-kind-42",
            ["shutdown", "--control", str(daemon.control), "--final-state-head", "yes", "--deadline-ms", "12000"],
        )
        assert old is not None
        h.check(old["format"] == "NATRAV_OVERLAY_TERMINAL_STATE_HEAD_V1", "legacy terminal format remains unchanged")
        h.check("correlation_token" not in old and old["request_id"] == request_id(old_payload), "legacy kind and exact identity remain unchanged")
        wait_stopped(h, daemon, "legacy terminal stop")
        raw = (state / "state.journal").read_bytes()
        independent_open(raw, key)
        h.check(selector(raw, key) == old["state_head"]["selector"], "legacy terminal head still authenticates independently")

        maximum_token = "a" + "b" * 62 + "9"
        _, drain_state, drain_key, _, drain_daemon = setup_keyed(h, "correlated-terminal-max")
        reason = "maximum canonical correlated terminal drain"
        payload = correlated_terminal_drain(500, reason, maximum_token)
        value = h.run("maximum-correlated-terminal-drain", terminal_args(drain_daemon.control, maximum_token, 500, reason))
        assert value is not None
        verify_stopped(h, "maximum correlated terminal drain", drain_daemon, drain_state, drain_key, value, maximum_token, request_id(payload), drain=True)
        h.check(value["shutdown"]["drain_completed_at_wait_boundary"] is True, "empty correlated drain completes normally")

    case("strict_wire_and_legacy_terminal_unchanged", strict_wire_and_legacy_terminal_unchanged)

    def keyed_immediate_exact_head_and_identity() -> None:
        token = "ops-20261012-terminal-a01"
        payload = correlated_terminal_shutdown(token)
        expected = request_id(payload)
        _, state, key, _, daemon = setup_keyed(h, "correlated-terminal-immediate")
        value = h.run("correlated-terminal-immediate", terminal_args(daemon.control, token))
        assert value is not None
        snapshot = verify_stopped(h, "correlated terminal immediate", daemon, state, key, value, token, expected, drain=False)
        rows = lifecycle_for(snapshot, expected)
        decisions = decisions_for(snapshot, expected)
        h.check(len(rows) == 1 and rows[0]["kind"] == "SHUTDOWN_REQUESTED", "exact request identity reaches immediate lifecycle provenance")
        h.check(len(decisions) == 1 and decisions[0]["command"] == "SHUTDOWN_TERMINAL_CORRELATED", "authorization account names correlated terminal protocol")
        h.check(value["terminal"]["obligations_complete"] is True, "empty immediate fixture retains exact stopped obligation account")

    case("keyed_immediate_exact_head_and_identity", keyed_immediate_exact_head_and_identity)

    def immediate_response_loss_exact_identity() -> None:
        token = "ops-20261012-terminal-lost"
        payload = correlated_terminal_shutdown(token)
        expected = request_id(payload)
        _, state, key, config, daemon = setup_keyed(
            h,
            "correlated-terminal-lost",
            environment={
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_COMMAND": "SHUTDOWN_TERMINAL_CORRELATED",
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_PAUSE_MS": "350",
            },
        )
        drop_after_complete_request(daemon.control, payload)
        wait_stopped(h, daemon, "correlated terminal response loss")
        snapshot, raw = verify_keyed_state(h, "correlated-terminal-lost-offline", state, key)
        rows = lifecycle_for(snapshot, expected)
        decisions = decisions_for(snapshot, expected)
        h.check(len(rows) == 1 and rows[0]["kind"] == "SHUTDOWN_REQUESTED", "lost response cannot revoke accepted correlated terminal stop")
        h.check(len(decisions) == 1 and decisions[0]["command"] == "SHUTDOWN_TERMINAL_CORRELATED", "lost response preserves exact authorization provenance")
        h.check(token.encode() not in raw, "lost-response token remains digest-only durable provenance")
        _, plain_frames, _, _ = independent_open(raw, key)
        independently = reference(b"".join(plain_frames))["lifecycle"]
        h.check(any(row["request_id"] == expected and row["kind"] == "SHUTDOWN_REQUESTED" for row in independently), "independent raw decoder reconstructs exact lost-response identity")
        restarted = start(h, "correlated-terminal-lost-lookup", config, state, key)
        selected_rows = history(h, "correlated-terminal-lost-history", state, section="lifecycle", request=expected)
        h.check(selected_rows["selected_total"] == 1 and selected_rows["rows"][0]["request_id"] == expected, "bounded exact history finds intended lost-response attempt")
        restarted.shutdown()

    case("immediate_response_loss_exact_identity", immediate_response_loss_exact_identity)

    def drain_deadline_preserves_obligation() -> None:
        unavailable = free_port()
        token = "ops-20261012-terminal-deadline"
        reason = "correlated terminal deadline with pending delivery"
        payload = correlated_terminal_drain(150, reason, token)
        expected = request_id(payload)
        _, state, key, _, daemon = setup_keyed(h, "correlated-terminal-deadline", peers=[("B", unavailable)])
        h.run(
            "correlated-terminal-pending-submit",
            [
                "submit", "--control", str(daemon.control), "--node", "A", "--peer", "B",
                "--scope", "admin/test", "--operation", operation("correlated-terminal-pending"),
                "--payload-text", "retain exact obligation", "--deadline-ms", "2000",
            ],
        )
        value = h.run("correlated-terminal-deadline", terminal_args(daemon.control, token, 150, reason))
        assert value is not None
        snapshot = verify_stopped(h, "correlated terminal deadline", daemon, state, key, value, token, expected, drain=True)
        h.check(value["shutdown"]["drain_deadline_reached"] is True and value["shutdown"]["drain_completed_at_wait_boundary"] is False, "bounded drain reports its actual deadline outcome")
        h.check(value["terminal"]["pending_outbound"] == 1 and value["terminal"]["obligations_complete"] is False, "terminal correlation neither cancels nor conceals pending delivery")
        rows = lifecycle_for(snapshot, expected)
        h.check([row["kind"] for row in rows] == ["DRAIN_STARTED", "DRAIN_DEADLINE"], "same exact identity binds both drain lifecycle boundaries")
        h.check(rows[-1]["pending_outbound"] == 1 and snapshot["outbox"]["pending"] == 1, "replay preserves exact stopped obligation")

    case("drain_deadline_preserves_obligation", drain_deadline_preserves_obligation)

    def duplicate_tokens_are_not_idempotency() -> None:
        token = "attempt-x7c91"
        other = "attempt-z4f82"
        expected = request_id(correlated_terminal_shutdown(token))
        other_expected = request_id(correlated_terminal_shutdown(other))
        _, state, key, config, daemon = setup_keyed(h, "correlated-terminal-duplicates")
        for ordinal, selected_token in enumerate((token, token, other), 1):
            value = h.run(
                "correlated-terminal-duplicate-" + str(ordinal),
                terminal_args(daemon.control, selected_token),
            )
            assert value is not None
            selected_id = expected if selected_token == token else other_expected
            verify_stopped(h, "correlated terminal duplicate " + str(ordinal), daemon, state, key, value, selected_token, selected_id, drain=False)
            if ordinal < 3:
                daemon = start(h, "correlated-terminal-duplicates-" + str(ordinal + 1), config, state, key)
        h.check(expected != other_expected, "distinct token changes request identity")
        daemon = start(h, "correlated-terminal-duplicates-history", config, state, key)
        life = history(h, "correlated-terminal-duplicate-life", state, section="lifecycle", request=expected)
        decisions = history(h, "correlated-terminal-duplicate-decisions", state, request=expected)
        h.check(life["selected_total"] == 2 and all(row["kind"] == "SHUTDOWN_REQUESTED" for row in life["rows"]), "duplicate exact requests create two lifecycle rows")
        h.check(decisions["selected_total"] == 2 and all(row["command"] == "SHUTDOWN_TERMINAL_CORRELATED" for row in decisions["rows"]), "duplicate exact requests create two independently authorized decisions")
        distinct = history(h, "correlated-terminal-distinct-life", state, section="lifecycle", request=other_expected)
        h.check(distinct["selected_total"] == 1, "distinct token selects only its own attempt")
        daemon.shutdown()

    case("duplicate_tokens_are_not_idempotency", duplicate_tokens_are_not_idempotency)

    def current_policy_revocation() -> None:
        for index, payload in enumerate((
            correlated_terminal_shutdown("delegated-terminal-immediate"),
            correlated_terminal_drain(100, "delegated terminal drain", "delegated-terminal-drain"),
        )):
            _, state, key, config, daemon = setup_keyed(
                h,
                "correlated-terminal-revocation-" + str(index),
                grants=[(os.geteuid(), ["ALL"]), (DELEGATED_UID, ["SHUTDOWN", "INSPECT"])],
                environment={"NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER": "1"},
            )
            expose_control_for_uid(state)
            expected = request_id(payload)
            client = Client(h, daemon, "correlated-terminal-revoked-" + str(index), payload, uid=DELEGATED_UID, split=True)
            try:
                replacement = candidate(
                    h,
                    config,
                    "correlated-terminal-revoked-candidate-" + str(index),
                    "correlated-terminal-revoked-g2-" + str(index),
                    lambda raw: "\n".join(
                        f"local_control={DELEGATED_UID},SHUTDOWN" if line.startswith(f"local_control={DELEGATED_UID},") else line
                        for line in raw.splitlines()
                    ) + "\n",
                )
                activate(h, "correlated-terminal-revoke-" + str(index), state, replacement)
                denied = client.finish()
                h.check(denied.get("code") == "LOCAL_CONTROL_CLASS_DENIED" and denied.get("request_id") == expected and "state_head" not in denied, "current post-decode policy denies terminal head exposure")
                h.check(daemon.process is not None and daemon.process.poll() is None, "denied correlated terminal request cannot stop process")
                h.check(h.status("correlated-terminal-revoked-running-" + str(index), state, logical_digest=False)["lifecycle"]["mode"] == "RUNNING", "revocation leaves service running")
            finally:
                client.close()
                restore_owner_only_control(state)
            daemon.shutdown()
            verify_keyed_state(h, "correlated-terminal-revoked-offline-" + str(index), state, key)

    case("current_policy_revocation", current_policy_revocation)

    def compaction_replay_and_exact_lookup() -> None:
        token = "terminal.compact-window"
        expected = request_id(correlated_terminal_shutdown(token))
        _, state, key, config, daemon = setup_keyed(h, "correlated-terminal-compaction")
        value = h.run("correlated-terminal-before-compact", terminal_args(daemon.control, token))
        assert value is not None
        verify_stopped(h, "correlated terminal before compact", daemon, state, key, value, token, expected, drain=False)
        daemon = start(h, "correlated-terminal-compaction-online", config, state, key)
        before = history(h, "correlated-terminal-before-compact-lookup", state, section="lifecycle", request=expected)
        h.run("correlated-terminal-compact", ["compact", "--control", str(daemon.control), "--deadline-ms", "5000"])
        after = history(h, "correlated-terminal-after-compact-lookup", state, section="lifecycle", request=expected)
        h.check(after["rows"] == before["rows"] and after["selected_total"] == 1, "compaction preserves exact correlated terminal provenance")
        daemon.shutdown()
        snapshot, raw = verify_keyed_state(h, "correlated-terminal-compaction-offline", state, key)
        h.check(len(lifecycle_for(snapshot, expected)) == 1, "complete keyed replay retains correlated terminal request identity")
        _, plain_frames, root, _ = independent_open(raw, key)
        h.check(root.hex() == snapshot["storage"]["state_authentication"]["root"], "independent authentication reaches compacted head")
        h.check(b"".join(plain_frames).count(bytes.fromhex(expected)) >= 2, "canonical checkpoint retains decision and lifecycle identity")

    case("compaction_replay_and_exact_lookup", compaction_replay_and_exact_lookup)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append", choices=CASES)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    harness = Harness(args.binary, args.output)
    started = time.time()
    code = 1
    try:
        run_suite(harness, set(args.case) if args.case else None)
        code = 0
    except BaseException as error:
        import traceback
        (harness.output / "FAILURE.txt").write_text(traceback.format_exc())
        print(f"FAIL: {type(error).__name__}: {error}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_CORRELATED_TERMINAL_STATE_HEAD_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(item["status"] == "PASS" for item in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (
            ("SUMMARY.json", summary),
            ("CASES.json", harness.cases),
            ("COMMANDS.json", harness.commands),
        ):
            (harness.output / name).write_text(json.dumps(value, indent=2) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
