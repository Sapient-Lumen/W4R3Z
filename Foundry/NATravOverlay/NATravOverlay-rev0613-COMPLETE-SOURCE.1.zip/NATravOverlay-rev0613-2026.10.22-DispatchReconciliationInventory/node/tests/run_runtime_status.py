#!/usr/bin/env python3
"""Bounded live status beside independent retained histories and actual C++ peers.
Full-digest requests are explicit; metadata reads never pass null equality as a
logical-state check. All process effects and credentials are local test-owned.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, shutil, socket, struct, subprocess, time
from pathlib import Path
from run_persistent import Harness, Daemon, operation, free_port, raw_control, receive_exact
from run_delivery_selection import fixture, topology
from run_outbox_inspection import setup, submit, query, wait_outcome
from run_live_configuration import candidate, activate
from run_authorization_actions import write_config, independent_record, action_payload, generation
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_state_authentication import new_key, migrate, start as start_keyed, inspect


def status(h,label,state,*,full=False,uid=None):
    args=['status','--control',str(state/'control.sock'),'--logical-digest','yes' if full else 'no','--deadline-ms','5000']
    q=h.run(label,args) if uid is None else run_as_uid(h,label,uid,uid,args,0)
    h.check(q['format']=='NATRAV_OVERLAY_RUNTIME_STATUS_V14','explicit changed status schema')
    w=q['status_work'];h.check(w['snapshot_calls']==0 and w['snapshot_payload_bytes']==0,'no StateSnapshot in status')
    if full:
        h.check(isinstance(q['storage']['logical_state_digest'],str) and len(q['storage']['logical_state_digest'])==64,'explicit digest present, never null equality')
        h.check(w['logical_digest_computations']==1 and w['logical_bytes_serialized']>0,'full work explicitly counted')
    else:
        h.check(q['storage']['logical_state_digest'] is None and q['storage']['logical_state_digest_mode']=='NOT_REQUESTED','ordinary response never claims a full digest')
        h.check(w['logical_digest_computations']==0 and w['logical_bytes_serialized']==0,'no logical serialization on ordinary status')
    o=q['outbox'];h.check(sum(o[k] for k in ['pending','acked','rejected','cancelled','expired'])==o['count'],'outcome counts partition complete outbox')
    h.check(o['pending']==o['reservations']['pending_records'],'pending count and quota agree')
    a=q['actions'];h.check(sum(a[k] for k in ['pending','executed','cancelled','expired'])==a['count'],'action outcomes partition complete registry')
    h.check(w['outbox_metadata_records']<=65 and w['action_metadata_records']<=65 and w['transition_metadata_records']<=65*16,'bounded rows and transition windows')
    h.check(len(json.dumps(q,separators=(',',':')).encode())<=65000,'annotated response fits ordinary control cap')
    for peer in q['peers']:
        h.check(peer['pending']==peer['reserved_records'] and peer['unresolved']<=peer['pending'],'coherent per-peer counts')
    return q


def copy_quiet_state(h,label,state):
    # The scenario has no state-changing worker work. Validate that the exact
    # captured bytes stayed unchanged; do not pretend to back up an arbitrary live writer.
    before=(state/'state.journal').read_bytes();target=h.runtime/label;target.mkdir(mode=0o700)
    for name in ['node.meta','state.lock']:
        shutil.copyfile(state/name,target/name);(target/name).chmod(0o600)
    (target/'state.journal').write_bytes(before);(target/'state.journal').chmod(0o600)
    h.check(before==(state/'state.journal').read_bytes(),'fixture capture did not straddle mutation')
    return target


def cases(h,only):
    def case(name,fn):
        if not only or name in only:h.case(name,fn)

    def large():
        a,_,_=fixture(h,'status-large',unrelated=8192,settled=4096,ready_b=0)
        ac,bc,cc,ad,bd,cd,b,c=topology(h,'status-large',a,large=True,control_timeout_ms=30000)
        first=status(h,'large-default',a);size=(a/'state.journal').stat().st_size
        for i in range(12):
            q=status(h,'idle-'+str(i),a)
            h.check(q['inbound_records']==8192 and q['authorization']['admitted']==0,'legacy retained evidence not falsely counted as authorized')
            h.check(q['outbox']['count']==4096 and q['outbox']['acked']==4096,'all settled records counted beyond displayed window')
            h.check(q['status_work']==first['status_work'],'ordinary work independent of idle polling')
        full=status(h,'explicit-full',a,full=True)
        captured=copy_quiet_state(h,'status-captured',a)
        reference=h.run('independent-full-decoder',['inspect','--state',str(captured),'--node','A'],timeout=60)
        h.check(full['storage']['logical_state_digest']==reference['storage']['logical_state_digest'],'explicit status equals full normal decoder at captured exact state')
        h.check((a/'state.journal').stat().st_size==size,'all successful status reads are observational')
        # Explicit 30-second large-fixture maintenance budget; ordinary status
        # requests still use 5 seconds. No product default or inherited test changed.
        h.run('large-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','30000'],timeout=40)
        compacted=status(h,'large-compacted',a)
        h.check(compacted['outbox']['count']==4096 and compacted['storage']['maintenance_generation']==1,'compaction retains exact counts')
        ad.shutdown();ad=Daemon(h,'large-restart',ac,a,readiness_timeout=30);h.daemons.append(ad);ad.start();status(h,'large-reconstructed',a)
        (h.output/'LARGE-STATUS.json').write_text(json.dumps({'fixture':'8192 independent legacy inbound records (16 MiB) and 4096 settled outbound records; not network scale','ordinary':first,'full_work':full['status_work'],'full_digest':full['storage']['logical_state_digest'],'offline_digest':reference['storage']['logical_state_digest'],'idle_polls':12,'ordinary_request_deadline_ms':5000,'large_fixture_control_deadline_ms':30000,'large_compaction_request_deadline_ms':30000},indent=2)+'\n');ad.shutdown()
    case('large_state_zero_payload_snapshots_explicit_digest_and_reconstruction',large)

    def outcomes():
        a,b,ac,bc,ad,bd=setup(h,'status-outcomes',online=True)
        ack=submit(h,'status-acked',a,peer='B');wait_outcome(h,'status-real-receipt',a,ack,'ACKED')
        bad=submit(h,'status-rejected',a,peer='B',scope='test/denied');wait_outcome(h,'status-real-denial',a,bad,'REJECTED')
        pending=submit(h,'status-pending',a,peer='C',payload='')
        cancelled=submit(h,'status-cancelled',a,peer='C',payload='x'*19)
        h.run('status-cancel',['cancel','--control',str(a/'control.sock'),'--operation',cancelled,'--reason','reference outcomes'])
        expired=submit(h,'status-expired',a,peer='D');wait_outcome(h,'status-real-expiry',a,expired,'EXPIRED')
        first=status(h,'all-five-outcomes',a)
        h.check([first['outbox'][k] for k in ['count','pending','acked','rejected','cancelled','expired']]==[5,1,1,1,1,1],'independent five-outcome reference')
        h.check(first['outbox']['unresolved']==0 and first['outbox']['reservations']['pending_payload_bytes']==0,'disabled but configured valid binding remains resolved; zero-byte record reserves count')
        for i in range(10):
            h.run('status-retry-'+str(i),['retry','--control',str(a/'control.sock'),'--operation',bad,'--reason','bounded transition reference'])
            wait_outcome(h,'status-rejection-'+str(i),a,bad,'REJECTED')
        q=status(h,'bounded-history',a);row=next(x for x in q['outbox']['entries'] if x['operation_id']==bad)
        h.check(len(row['transitions'])==16 and row['transitions_truncated'] and row['rejection']['code']=='AUTHORIZATION_DENIED','tail window never alters active rejection')
        h.check([x['kind'] for x in row['transitions']]==['RETRIED','REJECTED']*8,'last sixteen of 21 transitions in order')
        removed=candidate(h,ac,'status-no-c-route','status-no-c-route-g2',lambda x:'\n'.join(line for line in x.splitlines() if not line.startswith(('peer=C,','peer_route=C,')))+'\n')
        activate(h,'remove-c-route',a,removed);q=status(h,'unresolved-no-route',a)
        h.check(q['outbox']['unresolved']==1,'removed route retains unresolved zero-byte obligation')
        restored=candidate(h,ac,'status-c-restored','status-c-restored-g3');activate(h,'restore-c-route',a,restored)
        h.check(status(h,'resolved-restored-route',a)['outbox']['unresolved']==0,'restoring route restores resolution without changing payload')
        ad.shutdown();ref=h.run('outcomes-offline',['inspect','--state',str(a),'--node','A'])
        h.check(ref['outbox']['count']==5 and ref['outbox']['pending']==1,'normal decoder agrees after restart boundary')
        (h.output/'OUTCOMES.json').write_text(json.dumps({'initial':first['outbox'],'history':row,'unresolved':q['outbox']['unresolved']},indent=2)+'\n');bd.shutdown()
    case('five_outcomes_bounded_transition_history_removed_routes_and_zero_bytes',outcomes)

    def actions():
        b=h.runtime/'status-actions';port=free_port()
        cfg=write_config(h,'status-action-cfg','B',b,port,'B',[],[('A',generation('A'),'ACTIVE','A')],[('A','*','ACTION','counter.add')],action_expiry_ms=300,maximum_defer_ms=1000,deadline_ms=2000)
        bd=h.start('status-action-daemon',cfg,b,{'NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS':'800'})
        one=operation('status-action-one');two=operation('status-action-two');three=operation('status-action-three');four=operation('status-action-four')
        independent_record(h,port,'A','A','B',one,'actions/counter.add/v1',action_payload(7))
        h.wait('actual counter completion',lambda:status(h,'action-progress',b)['actions']['executed']==1)
        independent_record(h,port,'A','A','B',two,'actions/counter.add/v1',action_payload(3,150))
        h.run('action-real-cancel',['action-cancel','--control',str(b/'control.sock'),'--action',two,'--reason','exact action count'])
        independent_record(h,port,'A','A','B',three,'actions/counter.add/v1',action_payload(1,0))
        h.wait('blocking action started',lambda:status(h,'blocking-action',b)['actions']['entries'][-1]['attempts']==1)
        independent_record(h,port,'A','A','B',four,'actions/counter.add/v1',action_payload(5,0))
        h.wait('actual action expiry',lambda:status(h,'action-expiry',b)['actions']['expired']==1)
        q=status(h,'all-action-outcomes',b)
        h.check(q['actions']['count']==4 and q['actions']['executed']==2 and q['actions']['cancelled']==1 and q['actions']['expired']==1 and q['actions']['pending']==0,'action counts match independent transition reference')
        h.check(q['actions']['counter_value']==8 and q['actions']['reserved_amount']==0 and q['authorization']['admitted']==4,'effects, reservations and authorized admissions exact')
        h.run('status-action-compact',['compact','--control',str(b/'control.sock'),'--deadline-ms','5000']);bd.shutdown()
        bd=h.start('status-action-restart',cfg,b);rebuilt=status(h,'action-reconstructed',b)
        h.check(all(q['actions'][k]==rebuilt['actions'][k] for k in ['count','pending','executed','cancelled','expired','counter_value','reserved_amount']),'action summary reconstructs from checkpoint')
        (h.output/'ACTIONS.json').write_text(json.dumps({'before':q['actions'],'after':rebuilt['actions']},indent=2)+'\n');bd.shutdown()
    case('actual_counter_execution_cancellation_expiry_and_authorized_admission_counts',actions)

    def concurrent_receipts():
        a,b,ac,bc,ad,bd=setup(h,'status-concurrent',online=True)
        before=status(h,'concurrent-start',a);observations=[]
        def writer(i):
            return h.run('status-write-'+str(i),['submit','--control',str(a/'control.sock'),'--node','A','--peer','B','--scope','test/three','--operation',operation('status-bulk-'+str(i)),'--payload-text','x'*i,'--deadline-ms','5000'])
        with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
            futures=[pool.submit(writer,i) for i in range(64)]
            for n in range(20):observations.append(status(h,'concurrent-observation-'+str(n),a))
            for f in futures:f.result()
        h.wait('all real receipts committed',lambda:status(h,'concurrent-finish',a)['outbox']['acked']==64,timeout=15)
        final=status(h,'concurrent-final',a)
        h.check(final['outbox']['pending']==0 and final['outbox']['count']==64 and final['outbox']['reservations']['pending_payload_bytes']==0,'64 actual exchanges finish and release exact reservations')
        h.check(all(o['outbox']['unresolved']==0 for o in observations),'valid route/key groups never become unresolved due to receipt updates')
        h.check(all(o['status_work']['logical_bytes_serialized']==0 for o in observations),'continuous mutation does not trigger hidden full hashing')
        (h.output/'CONCURRENT.json').write_text(json.dumps({'initial':before['outbox'],'observations':[{'pending':o['outbox']['pending'],'acked':o['outbox']['acked'],'bytes':o['outbox']['reservations']['pending_payload_bytes'],'work':o['status_work']} for o in observations],'final':final['outbox']},indent=2)+'\n');ad.shutdown();bd.shutdown()
    case('concurrent_real_receipts_preserve_coherent_counts_without_digest_work',concurrent_receipts)

    def authority_and_wire():
        a,b,ac,bc,ad,bd=setup(h,'status-authority',delegates=True);expose_control_for_uid(a)
        status(h,'inspect-uid',a,uid=65534)
        denied=run_as_uid(h,'status-wrong-class',65533,65533,['status','--control',str(a/'control.sock')],3)
        h.check(denied['code']=='LOCAL_CONTROL_CLASS_DENIED','SUBMIT alone does not inspect administrative metadata')
        for payload,full in [(b'NOC1\x02',False),(b'NOC1\x19',True)]:
            ok,q=raw_control(a/'control.sock',payload);h.check(ok and (q['storage']['logical_state_digest'] is not None)==full,'independent explicit digest request kind')
            ok,err=raw_control(a/'control.sock',payload+b'x');h.check(not ok,'strict EOF on both status forms')
        h.run('bad-digest-option',['status','--control',str(a/'control.sock'),'--logical-digest','sometimes'],expected=3)
        packet=b'NOC1\x02';sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);sock.settimeout(5);sock.connect(str(a/'control.sock'))
        sock.sendall(struct.pack('!I',len(packet))+packet[:-1])
        revoked=candidate(h,ac,'status-no-inspect','status-no-inspect-g2',lambda t:t.replace(f'local_control={os.geteuid()},ALL',f'local_control={os.geteuid()},SUBMIT,MAINTENANCE,CONFIGURATION,SHUTDOWN'))
        activate(h,'status-live-revoke',a,revoked);sock.sendall(packet[-1:]);sock.shutdown(socket.SHUT_WR)
        n=struct.unpack('!I',receive_exact(sock,4))[0];raw=receive_exact(sock,n);sock.close();h.check(raw[4]==1 and json.loads(raw[5:])['code']=='LOCAL_CONTROL_CLASS_DENIED','partial status observes current post-decode authority')
        status(h,'other-inspector-retained',a,uid=65534)
        restore_owner_only_control(a);ad.shutdown()
    case('real_uid_authority_explicit_wire_modes_strict_eof_and_live_revocation',authority_and_wire)

    def registry_race():
        old=os.environ.get('NATRAV_OVERLAY_TEST_STATUS_CAPTURE_PAUSE_MS');os.environ['NATRAV_OVERLAY_TEST_STATUS_CAPTURE_PAUSE_MS']='600'
        try:a,b,ac,bc,ad,bd=setup(h,'status-registry')
        finally:
            if old is None:os.environ.pop('NATRAV_OVERLAY_TEST_STATUS_CAPTURE_PAUSE_MS',None)
            else:os.environ['NATRAV_OVERLAY_TEST_STATUS_CAPTURE_PAUSE_MS']=old
        args=[str(h.binary),'status','--control',str(a/'control.sock'),'--deadline-ms','5000']
        request=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        h.wait('status captured stable peer pointees',lambda:'STATUS_REGISTRY_CAPTURED' in ad.stderr_path.read_text(),timeout=4)
        extra=h.identity('E');port=free_port()
        changed=candidate(h,ac,'status-add-peer','status-add-peer-g2',lambda t:t+f'peer=E,50,100,100,600000\npeer_route=E,primary,0,DISABLED,127.0.0.1:{port}\npeer_key=E,e-g1,ACTIVE,{extra.spki_sha256}\n')
        activate(h,'status-publish-during-observation',a,changed)
        stdout,stderr=request.communicate(timeout=5);h.commands.append({'label':'status-registry-overlap','returncode':request.returncode,'stdout':stdout,'stderr':stderr});q=json.loads(stdout)
        h.check(request.returncode==0 and q['peer_registry']['registered']==3,'bounded pointer snapshot retains original registry membership')
        h.check(not q['observation']['configuration_state_match'] and q['runtime_configuration']['generation']=='status-add-peer-g2','explicitly labels old authorized config versus newer state observation')
        later=status(h,'registry-current',a);h.check(later['peer_registry']['registered']==4 and later['observation']['configuration_state_match'],'subsequent request sees complete published registry')
        (h.output/'CONFIGURATION-RACE.json').write_text(json.dumps({'overlap':q['observation'],'overlap_state_configuration':q['runtime_configuration'],'registered_before':3,'registered_after':4},indent=2)+'\n');ad.shutdown()
    case('live_registry_publication_uses_stable_pointees_and_labels_observation_boundary',registry_race)

    def maintenance():
        a,b,ac,bc,ad,bd=setup(h,'status-maintenance')
        first=submit(h,'status-maintained-one',a,payload='x'*9);submit(h,'status-maintained-zero',a,payload='')
        q=status(h,'maintenance-before',a);h.check(q['outbox']['pending']==2,'two pending obligations');ad.shutdown()
        key=new_key(h,h.work,'status-state');migrate(h,'status-migrate',a,key)
        ad=start_keyed(h,'status-keyed',ac,a,key);narrow=status(h,'status-keyed-narrow',a);full=status(h,'status-keyed-full',a,full=True)
        h.check(narrow['storage']['state_authentication']['mode']=='HMAC_SHA256_CHAIN_V1','keyed state surfaced without hashing complete application')
        h.run('status-authenticated-compact',['compact','--control',str(a/'control.sock'),'--deadline-ms','5000']);ad.shutdown();before=inspect(h,'status-before-backup',a,key)
        ident=h.identity('A');crypt=h.work/'status-backup.key';archive=h.work/'status.nob'
        h.run('status-encryption-key',['backup-key-init','--output',str(crypt),'--generation','status-backup'])
        h.run('status-export',['backup-export','--state',str(a),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--output',str(archive),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'status-restored';h.run('status-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'status-after-restore',restored,key);h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'full offline digest equality, not null comparison')
        moved=candidate(h,ac,'status-relocated','status-relocated-g2',lambda t:t.replace('state='+str(a),'state='+str(restored)))
        h.run('status-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--state-auth-key',str(key),'--reason','bounded status reconstruction'])
        ad=start_keyed(h,'status-relocated-owner',moved,restored,key);final=status(h,'status-relocated-state',restored)
        h.check(final['outbox']['pending']==2 and final['outbox']['reservations']['pending_payload_bytes']==9,'exact quotas reconstruct with moved owner paths')
        h.run('status-relocated-cancel',['cancel','--control',str(restored/'control.sock'),'--operation',first,'--reason','check subsequent mutation'])
        final=status(h,'status-relocated-zero',restored);h.check(final['outbox']['pending']==1 and final['outbox']['reservations']['pending_payload_bytes']==0,'subsequent release is immediately visible')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'before_digest':before['storage']['logical_state_digest'],'restored_digest':after['storage']['logical_state_digest'],'explicit_work':full['status_work'],'after':final['outbox']},indent=2)+'\n');ad.shutdown()
    case('keyed_metadata_explicit_digest_encrypted_restore_relocation_and_later_release',maintenance)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);start=time.time();ok=False
    try:
        cases(h,set(a.case) if a.case else None)
        if not h.cases:raise ValueError('no cases selected')
        ok=True
    except BaseException as e:(h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_RUNTIME_STATUS_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
