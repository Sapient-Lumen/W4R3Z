#!/usr/bin/env python3
"""Injected joined-worker failure must refuse correlated terminal head exposure."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time
import traceback

from run_persistent import Harness
from run_correlated_terminal_state_head import (
    correlated_terminal_drain,
    request_id,
    setup_keyed,
    terminal_args,
)
from run_state_authentication import inspect, start


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    harness = Harness(args.binary, args.output)
    started = time.time()
    code = 1
    try:
        def run() -> None:
            token = "runtime-failure-at-finalizer"
            reason = "correlated terminal runtime failure"
            expected_id = request_id(correlated_terminal_drain(100, reason, token))
            _, state, key, config, daemon = setup_keyed(harness, "correlated-terminal-runtime-failure")
            result = harness.run(
                "correlated-terminal-runtime-failure",
                terminal_args(daemon.control, token, 100, reason),
                expected=3,
            )
            harness.check(result is not None and result.get("code") == "TERMINAL_HEAD_RUNTIME_FAILED", "joined runtime failure refuses correlated terminal head")
            harness.check(result.get("request_id") == expected_id and "state_head" not in result and "correlation_token" not in result, "failure preserves exact request identity without exposing head or token")
            assert daemon.process
            daemon.process.wait(timeout=8)
            harness.check(daemon.process.returncode == 3, "failed terminal accounting is reflected in daemon exit")
            daemon._close_files()
            snapshot = inspect(harness, "correlated-terminal-failure-offline", state, key)
            harness.check(snapshot["lifecycle"]["interrupted_drain"] is True, "runtime failure cannot fabricate final drain accounting")
            restarted = start(harness, "correlated-terminal-failure-restart", config, state, key)
            harness.check(harness.status("correlated-terminal-failure-restart-status", state, logical_digest=False)["lifecycle"]["mode"] == "QUIESCED", "restart preserves interrupted-drain safety")
            restarted.shutdown()

        harness.case("failed_runtime_refuses_correlated_terminal_head", run)
        code = 0
    except BaseException:
        (harness.output / "FAILURE.txt").write_text(traceback.format_exc())
    finally:
        harness.cleanup()
        summary = {
            "format": "CORRELATED_TERMINAL_HEAD_FAILURE_PROPAGATION_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(item["status"] == "PASS" for item in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (
            ("SUMMARY.json", summary),
            ("CASES.json", harness.cases),
            ("COMMANDS.json", harness.commands),
        ):
            (harness.output / name).write_text(json.dumps(value, indent=2) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
