#include "custody_bundle.hpp"

#include <cstdint>
#include <functional>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

using namespace natrav_overlay;

namespace {
using KeyPtr = std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)>;
std::size_t assertions = 0U;

void check(const bool condition, const char* detail) {
    ++assertions;
    if (!condition) { throw std::runtime_error(detail); }
}

void reject(const std::function<void()>& action, const std::string_view code = {}) {
    try { action(); }
    catch (const AppError& error) {
        check(code.empty() || error.code() == code, error.what());
        return;
    }
    catch (const std::exception& error) {
        check(code.empty(), error.what());
        return;
    }
    check(false, "expected rejection");
}

KeyPtr key(const std::uint8_t byte) {
    CustodySigningKey seed{};
    seed.fill(byte);
    auto* value = EVP_PKEY_new_raw_private_key(
        EVP_PKEY_ED25519, nullptr, seed.data(), seed.size());
    if (value == nullptr) { throw std::runtime_error("key creation failed"); }
    return KeyPtr(value, EVP_PKEY_free);
}

datacube::Digest32 digest(const std::uint8_t byte) {
    datacube::Digest32 result;
    result.octets.fill(byte);
    return result;
}

DurableCustodyEvent registration(
    const CustodyEnvelope& envelope,
    const datacube::Octets& capsule,
    const std::vector<CustodyGrantReference>& grants) {
    return DurableCustodyEvent{
        .kind = DurableCustodyEventKind::registered,
        .envelope_sha256 = custody_envelope_sha256(envelope),
        .configuration_event = 7U,
        .event_ms = 0U,
        .envelope = envelope.canonical,
        .capsule = capsule,
        .grants = grants,
        .record = {},
        .code = {},
        .detail = {},
        .imported_operation = std::nullopt,
    };
}

DurableCustodyEvent record_event(
    const CustodyEnvelope& envelope,
    const datacube::Octets& record) {
    return DurableCustodyEvent{
        .kind = DurableCustodyEventKind::record,
        .envelope_sha256 = custody_envelope_sha256(envelope),
        .configuration_event = 7U,
        .event_ms = 0U,
        .envelope = {},
        .capsule = {},
        .grants = {},
        .record = record,
        .code = {},
        .detail = {},
        .imported_operation = std::nullopt,
    };
}
} // namespace

int main() {
    try {
        auto a = key(1U);
        auto r = key(2U);
        auto b = key(3U);
        const std::vector<CustodyParty> route{
            make_custody_party("A", "a-g1", a.get()),
            make_custody_party("R", "r-g1", r.get()),
            make_custody_party("B", "b-g1", b.get()),
        };
        datacube::Octets capsule(4096U);
        for (std::size_t i = 0U; i < capsule.size(); ++i) {
            capsule[i] = static_cast<std::uint8_t>((i * 17U) & 0xffU);
        }
        const auto envelope = make_custody_envelope(
            route, capsule, 1000U, 50000U, a.get());
        const std::vector<CustodyGrantReference> grants{
            CustodyGrantReference{.id = "a-r", .generation = 1U,
                .commitment = digest(11U)},
            CustodyGrantReference{.id = "r-b", .generation = 1U,
                .commitment = digest(12U)},
        };

        const CustodyBundle original{
            .envelope = envelope,
            .capsule = capsule,
            .grants = grants,
            .records = {},
        };
        const auto encoded_bundle = encode_custody_bundle(original);
        const auto decoded_bundle = decode_custody_bundle(encoded_bundle);
        check(decoded_bundle.envelope.canonical == envelope.canonical,
            "bundle envelope roundtrip");
        check(decoded_bundle.capsule == capsule, "bundle capsule roundtrip");
        check(decoded_bundle.grants == grants, "bundle grants roundtrip");
        check(custody_bundle_envelope_sha256(decoded_bundle) ==
            custody_envelope_sha256(envelope), "bundle digest");
        for (std::size_t n = 0U; n < encoded_bundle.size(); ++n) {
            reject([&] { (void)decode_custody_bundle(
                datacube::OctetView(encoded_bundle.data(), n)); });
        }
        auto trailing_bundle = encoded_bundle;
        trailing_bundle.push_back(0U);
        reject([&] { (void)decode_custody_bundle(trailing_bundle); });

        DurableCustodyRegistry registry;
        const auto registered = registration(envelope, capsule, grants);
        const auto encoded_registered = encode_durable_custody_event(registered);
        check(decode_durable_custody_event(encoded_registered).grants == grants,
            "registration canonical roundtrip");
        check(registry.apply(registered) == DurableCustodyDisposition::applied,
            "registration applied");
        check(registry.apply(registered) == DurableCustodyDisposition::duplicate,
            "registration duplicate");
        check(registry.active_count() == 1U &&
            registry.retained_capsule_bytes() == capsule.size(),
            "bounded retained accounting");

        auto progress = initial_custody_progress(envelope);
        const auto transfer_one = make_custody_transfer(
            envelope, progress, 2000U, a.get());
        static_cast<void>(apply_custody_record(envelope, transfer_one, progress));
        check(registry.apply(record_event(envelope, transfer_one.canonical)) ==
            DurableCustodyDisposition::applied, "first transfer recorded");
        const DurableCustodyEvent uncertain{
            .kind = DurableCustodyEventKind::uncertainty,
            .envelope_sha256 = custody_envelope_sha256(envelope),
            .configuration_event = 7U,
            .event_ms = 2050U,
            .envelope = {}, .capsule = {}, .grants = {}, .record = {},
            .code = "RESPONSE_LOST", .detail = "acceptance outcome unknown",
            .imported_operation = std::nullopt,
        };
        check(registry.apply(uncertain) == DurableCustodyDisposition::applied,
            "uncertainty retained");
        check(registry.apply(uncertain) == DurableCustodyDisposition::duplicate,
            "uncertainty duplicate");
        const auto accept_one = make_custody_acceptance(
            envelope, progress, 2100U, r.get());
        static_cast<void>(apply_custody_record(envelope, accept_one, progress));
        check(registry.apply(record_event(envelope, accept_one.canonical)) ==
            DurableCustodyDisposition::applied, "first acceptance recorded");
        reject([&] {
            auto late = uncertain;
            late.event_ms = 2200U;
            static_cast<void>(registry.apply(late));
        }, "CUSTODY_STATE_UNCERTAINTY_INVALID");
        const auto transfer_two = make_custody_transfer(
            envelope, progress, 3000U, r.get());
        static_cast<void>(apply_custody_record(envelope, transfer_two, progress));
        check(registry.apply(record_event(envelope, transfer_two.canonical)) ==
            DurableCustodyDisposition::applied, "second transfer recorded");
        const auto accept_two = make_custody_acceptance(
            envelope, progress, 3100U, b.get());
        static_cast<void>(apply_custody_record(envelope, accept_two, progress));
        check(registry.apply(record_event(envelope, accept_two.canonical)) ==
            DurableCustodyDisposition::applied, "final acceptance recorded");
        const auto operation = digest(77U);
        const DurableCustodyEvent imported{
            .kind = DurableCustodyEventKind::imported,
            .envelope_sha256 = custody_envelope_sha256(envelope),
            .configuration_event = 7U,
            .event_ms = 3200U,
            .envelope = {}, .capsule = {}, .grants = {}, .record = {},
            .code = {}, .detail = {}, .imported_operation = operation,
        };
        check(registry.apply(imported) == DurableCustodyDisposition::applied,
            "final import retained");
        check(registry.active_count() == 0U, "terminal accounting");
        const auto* terminal = registry.find(custody_envelope_sha256(envelope));
        check(terminal != nullptr && terminal->imported_operation == operation &&
            terminal->records.size() == 4U &&
            terminal->uncertainties.size() == 1U,
            "terminal case reconstructed");
        check(registry.apply(record_event(envelope, transfer_one.canonical)) ==
            DurableCustodyDisposition::duplicate,
            "exact historical record remains idempotent after terminal state");

        DurableCustodyRegistry replay;
        for (const auto& event : registry.events()) {
            check(replay.apply_encoded(event) == DurableCustodyDisposition::applied,
                "event replay applied");
        }
        const auto* replayed = replay.find(custody_envelope_sha256(envelope));
        check(replayed != nullptr && replayed->imported_operation == operation &&
            replayed->records == terminal->records,
            "restart reconstruction exact");
        for (const auto& event : registry.events()) {
            check(replay.apply_encoded(event) == DurableCustodyDisposition::duplicate,
                "replayed duplicate bounded");
        }
        check(replay.status_json().find("\"state\":\"IMPORTED\"") !=
            std::string::npos, "status distinguishes final import");

        auto zero_config = registered;
        zero_config.configuration_event = 0U;
        reject([&] { (void)encode_durable_custody_event(zero_config); },
            "CUSTODY_STATE_EVENT_INVALID");
        auto mismatched = registered;
        mismatched.envelope_sha256 = digest(99U);
        reject([&] { static_cast<void>(DurableCustodyRegistry{}.apply(mismatched)); },
            "CUSTODY_STATE_CONFLICT");

        std::cout << "{\"status\":\"PASS\",\"case_groups\":7,\"assertions\":"
                  << assertions << "}\n";
        return 0;
    } catch (const AppError& error) {
        std::cerr << error.code() << ": " << error.what() << '\n';
        return 1;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
