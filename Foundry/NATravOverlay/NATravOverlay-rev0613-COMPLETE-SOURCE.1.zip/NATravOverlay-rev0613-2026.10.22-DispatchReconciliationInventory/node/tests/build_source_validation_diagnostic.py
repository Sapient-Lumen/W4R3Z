#!/usr/bin/env python3
"""Build an isolated source-validation oracle or replay probe. Never edits the product tree."""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, subprocess
from pathlib import Path

def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--mode',choices=('static','sanitize'),default='static')
    p.add_argument('--variant',choices=('full','reference','independent','independent-decoding','independent-outbound','owned-outgoing','copy-store','probe','full-probe'),required=True)
    p.add_argument('--prepare-only',action='store_true')
    a=p.parse_args();root=Path(__file__).resolve().parents[2];out=a.output.resolve()
    if out.exists() or out==root or root in out.parents:p.error('output must be new and outside this workspace')
    tree=out/'source';tree.mkdir(parents=True)
    for part in ('node/src','foundation/src','foundation/include'):shutil.copytree(root/part,tree/part)
    shutil.copy2(root/'node/build.sh',tree/'node/build.sh')
    definitions=''
    if a.variant in ('full','full-probe'):
        definitions='#define NATRAV_SOURCE_SUBSCRIPTION_FORCE_FULL\n#define NATRAV_SOURCE_SUBSCRIPTION_UNCACHED_CONFIG\n#define NATRAV_SOURCE_SUBSCRIPTION_LEGACY_PROGRESS\n'
    if a.variant=='reference':definitions='#define NATRAV_SOURCE_SUBSCRIPTION_REFERENCE_VALIDATE\n'
    if a.variant=='independent-decoding':definitions='#define NATRAV_SOURCE_PROGRESS_INDEPENDENT_DECODING\n'
    if a.variant=='independent-outbound':definitions='#define NATRAV_SOURCE_OUTBOUND_INDEPENDENT_DECODING\n'
    if a.variant=='independent':definitions='#define NATRAV_SOURCE_SUBSCRIPTION_INDEPENDENT_PREPARATION\n'
    if a.variant=='owned-outgoing':definitions='#define NATRAV_SOURCE_PROGRESS_OWNED_OUTGOING\n'
    if a.variant=='copy-store':definitions='#define NATRAV_SOURCE_OUTBOUND_COPY_STORE\n'
    source=tree/'node/src/source_subscription.cpp';source.write_text(definitions+source.read_text())
    if a.variant=='copy-store':
        journal=tree/'node/src/journal.cpp';journal.write_text(definitions+journal.read_text())
    if a.variant.endswith('probe'):
        shutil.copy2(root/'node/tests/source_replay_probe.cpp',tree/'node/src/main.cpp')
    if a.prepare_only:
        print(json.dumps({'status':'SOURCE_PREPARED_NOT_BUILT','source':str(tree)}));return 0
    with (out/'BUILD.log').open('w') as log:
        build=subprocess.run(['sh','node/build.sh',a.mode],cwd=tree,stdout=log,stderr=subprocess.STDOUT,timeout=600,env=dict(os.environ))
    binary=tree/'node/bin'/('natrav-overlay' if a.mode=='static' else 'natrav-overlay-sanitize')
    result={'format':'SOURCE_VALIDATION_DIAGNOSTIC_BUILD_V1','variant':a.variant,'mode':a.mode,'build_returncode':build.returncode,
            'status':'PASS' if build.returncode==0 else 'FAIL','binary':str(binary),
            'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest() if binary.exists() else None}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));return build.returncode
if __name__=='__main__':raise SystemExit(main())
