#!/usr/bin/env python3
"""V21 custody authority, durable evidence, restart, uncertainty and final import."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

from run_persistent import Harness, free_port, operation
from run_peer_sessions import submit, outbox_entry
from run_live_configuration import candidate, activate
from run_runtime_adapter_configuration import upgrade, write
from run_handoff_key_policy import record as handoff_record

ZERO = "0" * 64


def grant(*, identifier: str, origin: str, final: str,
          custodian: str, next_hop: str, state: str = "ACTIVE",
          generation: int = 1, predecessor: str = ZERO) -> str:
    return "\n".join([
        "NATRAV_CUSTODY_RELAY_GRANT_V1",
        f"id={identifier}",
        f"generation={generation}",
        f"predecessor_sha256={predecessor}",
        f"origin={origin}",
        f"origin_signing_generation={origin.lower()}-g1",
        f"final_recipient={final}",
        f"final_signing_generation={final.lower()}-g1",
        f"custodian={custodian}",
        f"custodian_signing_generation={custodian.lower()}-g1",
        f"next_hop={next_hop}",
        f"next_hop_signing_generation={next_hop.lower()}-g1",
        "maximum_envelope_lifetime_ms=600000",
        "maximum_hops=2",
        "maximum_active_envelopes=8",
        "maximum_capsule_bytes=68000",
        f"state={state}",
        "",
    ])




def grant_commitment_text(record: str) -> str:
    lines = record.splitlines()
    assert lines[0] == "NATRAV_CUSTODY_RELAY_GRANT_V1"
    assert lines[-1].startswith("state=")
    return "NATRAV_CUSTODY_RELAY_GRANT_COMMITMENT_V1\n" + \
        "\n".join(lines[1:-1]) + "\n"


def grant_commitment(record: str) -> str:
    return hashlib.sha256(grant_commitment_text(record).encode("ascii")).hexdigest()

def policy_lines(bindings: list[bytes], grants: list[str]) -> str:
    return "".join(
        f"handoff_key_hex={handoff_record(binding).encode('ascii').hex()}\n"
        for binding in bindings
    ) + "".join(
        f"custody_grant_hex={item.encode('ascii').hex()}\n" for item in grants
    )


def route(path: Path, bindings: list[bytes]) -> Path:
    path.write_text(
        "NATRAV_CUSTODY_ROUTE_V1\n" +
        "".join(f"binding_hex={binding.hex()}\n" for binding in bindings)
    )
    path.chmod(0o600)
    return path


def sha_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def suite(h: Harness, *, sanitize_probe: bool = False) -> None:
    root = Path(__file__).resolve().parents[2]
    h.work.chmod(0o700)
    state: dict[str, object] = {}

    def native() -> None:
        flags = [
            "-D_GNU_SOURCE", "-std=c++20", "-O1", "-g0", "-Wall",
            "-Wextra", "-Wpedantic", "-Wconversion", "-Wsign-conversion",
            "-Wshadow", "-Wformat=2", "-Werror", "-pthread",
        ]
        if sanitize_probe:
            flags += ["-O0", "-fsanitize=address,undefined",
                      "-fno-omit-frame-pointer", "-fno-pie", "-no-pie"]
        output = h.work / "custody-durable-probe"
        sources = [
            "node/tests/custody_durable_probe.cpp",
            "node/src/custody_bundle.cpp",
            "node/src/custody_state.cpp",
            "node/src/custody_envelope.cpp",
            "node/src/common.cpp",
            "node/src/protocol.cpp",
            "foundation/src/core.cpp",
            "foundation/src/natrav_peer_session.cpp",
            "foundation/src/natrav_peer_stream.cpp",
            "foundation/src/natrav_peer_message.cpp",
            "foundation/src/natrav_peer_handshake.cpp",
        ]
        command = ["g++", *flags, "-I" + str(root / "foundation/include"),
                   "-I" + str(root / "node/src"),
                   *[str(root / source) for source in sources],
                   "-lssl", "-lcrypto", "-lz", "-lzstd",
                   "-o", str(output)]
        (h.logs / "native-command.json").write_text(json.dumps(command, indent=2))
        result = subprocess.run(command, capture_output=True, text=True, timeout=240)
        (h.logs / "native-compile.stdout").write_text(result.stdout)
        (h.logs / "native-compile.stderr").write_text(result.stderr)
        h.check(result.returncode == 0, result.stderr)
        env = dict(os.environ)
        if sanitize_probe:
            env["ASAN_OPTIONS"] = "detect_leaks=1:halt_on_error=1"
            env["UBSAN_OPTIONS"] = "halt_on_error=1:print_stacktrace=1"
        result = subprocess.run([str(output)], capture_output=True, text=True,
                                timeout=90, env=env)
        (h.logs / "native.stdout").write_text(result.stdout)
        (h.logs / "native.stderr").write_text(result.stderr)
        h.check(result.returncode == 0, result.stderr)
        report = json.loads(result.stdout)
        h.check(report["status"] == "PASS", "durable custody native probe")
        h.assertions += report["assertions"]

    h.case("canonical_bundle_durable_registry_and_restart", native)

    def initialize() -> None:
        version = h.run("version", ["version"])
        h.check(version["version"] == "0613", "revision identity")
        h.check(version["custody_relay_policy"] ==
                "V21_DURABLE_CUSTODY_RELAY_POLICY_V1", "V21 authority marker")
        h.check(version["durable_custody_evidence"] ==
                "DURABLE_CUSTODY_EVIDENCE_V1", "durable evidence marker")
        h.check(version["configured_custody_relay"] is True,
                "explicit native custody service is present")
        h.check(version["automatic_route_relay"] is False and
                version["open_relay"] is False,
                "ordinary routes remain non-relaying and closed")

        nodes = ("A", "R", "B")
        for node in nodes:
            trusted = [peer for peer in nodes if peer != node]
            peers = []
            if node == "A":
                peers = [("B", free_port(), 100, 300, 20, 600000)]
            elif node == "B":
                peers = [("A", free_port(), 100, 300, 20, 600000)]
            seed = h.config(node.lower(), node, h.runtime / node.lower(),
                            free_port(), peers, trusted=trusted)
            write(seed, upgrade(seed.read_text(), f"{node.lower()}-v19", 19))
            daemon = h.start(f"init-{node}", seed, h.runtime / node.lower())
            if node == "A":
                op = operation("custody-authority-operation")
                submit(h, "queue-operation", daemon.control, "A", "B",
                       "test/three", op, "custody authority evidence")
                state["operation"] = op
            daemon.shutdown()
            key = h.work / f"{node.lower()}-handoff"
            result = h.run(f"key-{node}", [
                "handoff-key-init", "--config", str(seed),
                "--key-directory", str(key), "--generation", f"{node.lower()}-h1",
            ])
            binding = (key / "binding.nhkb").read_bytes()
            h.check(result["binding_sha256"] == hashlib.sha256(binding).hexdigest(),
                    "exact handoff binding commitment")
            state[f"{node}seed"] = seed
            state[f"{node}state"] = h.runtime / node.lower()
            state[f"{node}key"] = key
            state[f"{node}binding"] = binding

        grants = [
            grant(identifier="a-r", origin="A", final="B",
                  custodian="A", next_hop="R"),
            grant(identifier="r-b", origin="A", final="B",
                  custodian="R", next_hop="B"),
            grant(identifier="b-r", origin="B", final="A",
                  custodian="B", next_hop="R"),
            grant(identifier="r-a", origin="B", final="A",
                  custodian="R", next_hop="A"),
        ]
        bindings = [state[f"{node}binding"] for node in nodes]
        records = policy_lines(bindings, grants)
        state["grants"] = grants

        # Canonical V21 and succession negative controls are evaluated through
        # the real product parser before any durable activation.
        old_format = candidate(
            h, state["Aseed"], "custody-old-format", "custody-old-format",
            lambda text: text + policy_lines(bindings, grants),
        )
        h.check(h.run("custody-old-format", ["config-check", "--config",
                    str(old_format)], expected=3)["code"] ==
                "CONFIG_VERSION_REJECTED",
                "custody grants require V21")
        duplicate = candidate(
            h, state["Aseed"], "custody-duplicate", "custody-duplicate",
            lambda text: text.replace("CONFIG_V19", "CONFIG_V21") +
                policy_lines(bindings, grants + [grants[0]]),
        )
        h.check(h.run("custody-duplicate", ["config-check", "--config",
                    str(duplicate)], expected=3)["code"] ==
                "CONFIG_CUSTODY_GRANT_CONFLICT",
                "duplicate exact grant is rejected")
        successor = grant(
            identifier="a-r", origin="A", final="B", custodian="A",
            next_hop="R", generation=2,
            predecessor=grant_commitment(grants[0]))
        active_conflict = candidate(
            h, state["Aseed"], "custody-active-conflict",
            "custody-active-conflict",
            lambda text: text.replace("CONFIG_V19", "CONFIG_V21") +
                policy_lines(bindings, grants + [successor]),
        )
        h.check(h.run("custody-active-conflict", ["config-check", "--config",
                    str(active_conflict)], expected=3)["code"] ==
                "CONFIG_CUSTODY_GRANT_ACTIVE_CONFLICT",
                "successor requires explicit predecessor retirement or revocation")

        for node in nodes:
            seed = state[f"{node}seed"]
            cfg = candidate(
                h, seed, f"{node.lower()}-v21", f"{node.lower()}-v21",
                lambda text, records=records:
                    text.replace("CONFIG_V19", "CONFIG_V21") + records,
            )
            checked = h.run(f"check-{node}-v21", ["config-check", "--config", str(cfg)])
            h.check(len(checked["custody_relay_policy"]["grants"]) == 4,
                    "four exact transition grants")
            daemon = h.start(f"activate-{node}", seed, state[f"{node}state"])
            activate(h, f"activate-{node}-v21", state[f"{node}state"], cfg)
            daemon.shutdown()
            state[f"{node}v21"] = cfg

        state["route_ab"] = route(h.work / "route-a-r-b.txt",
            [state["Abinding"], state["Rbinding"], state["Bbinding"]])
        state["route_ba"] = route(h.work / "route-b-r-a.txt",
            [state["Bbinding"], state["Rbinding"], state["Abinding"]])
        state["route_direct"] = route(h.work / "route-a-b.txt",
            [state["Abinding"], state["Bbinding"]])

    h.case("v21_exact_authority_and_durable_activation", initialize)

    def handoff_export(origin: str, recipient: str, op: str,
                       kind: str, output: Path) -> dict:
        return h.run(f"export-{kind}-{origin}-{recipient}", [
            "handoff-export", "--config", str(state[f"{origin}seed"]),
            "--key-directory", str(state[f"{origin}key"]),
            "--recipient-binding", str(state[f"{recipient}key"] / "binding.nhkb"),
            "--recipient-binding-sha256",
            sha_file(state[f"{recipient}key"] / "binding.nhkb"),
            "--operation-id", op, "--kind", kind,
            "--expires-ms", str(int(time.time() * 1000) + 300000),
            "--output", str(output),
        ])

    def custody_create(node: str, route_path: Path, capsule: Path,
                       output: Path, *, expected: int = 0):
        now = int(time.time() * 1000)
        return h.run(f"custody-create-{node}-{output.stem}", [
            "custody-create", "--config", str(state[f"{node}seed"]),
            "--route", str(route_path), "--capsule", str(capsule),
            "--created-ms", str(now), "--expires-ms", str(now + 240000),
            "--output", str(output),
        ], expected=expected)

    def custody_step(node: str, command: str, input_path: Path,
                     output: Path, *, expected: int = 0):
        return h.run(f"{command}-{node}-{output.stem}", [
            command, "--config", str(state[f"{node}seed"]),
            "--input", str(input_path), "--output", str(output),
        ], expected=expected)

    def forward_operation() -> None:
        capsule = h.work / "operation.nhcp"
        exported = handoff_export("A", "B", state["operation"], "operation", capsule)
        h.check(exported["status"] == "EXPORTED_NOT_DELIVERED",
                "one-hop export remains distinct from delivery")
        created = h.work / "forward-created.nhcb"
        result = custody_create("A", state["route_ab"], capsule, created)
        h.check(result["status"] == "CREATED_CUSTODY_HELD",
                "origin retains initial custody")
        state["forward_digest"] = result["envelope_sha256"]
        offered = h.work / "forward-offered.nhcb"
        result = custody_step("A", "custody-offer", created, offered)
        h.check(result["status"] == "TRANSFER_OFFER_COMMITTED" and
                result["awaiting_acceptance"], "offer durably committed")
        uncertain = h.run("forward-uncertain", [
            "custody-uncertain", "--config", str(state["Aseed"]),
            "--envelope-sha256", state["forward_digest"],
            "--code", "RESPONSE_LOST", "--detail", "acceptance outcome unknown",
        ])
        h.check(uncertain["status"] == "UNCERTAINTY_RECORDED" and
                uncertain["uncertainties"] == 1, "uncertainty preserved")
        recovered = h.work / "forward-offered-recovered.nhcb"
        duplicate = custody_step("A", "custody-offer", created, recovered)
        h.check(duplicate["status"] == "TRANSFER_ALREADY_COMMITTED",
                "lost response recovered without second offer")
        accepted_r = h.work / "forward-r-accepted.nhcb"
        result = custody_step("R", "custody-accept", offered, accepted_r)
        h.check(result["status"] == "CUSTODY_ACCEPTED" and
                result["current_party_index"] == 1, "relay accepts exact custody")
        accepted_r_again = h.work / "forward-r-accepted-again.nhcb"
        duplicate = custody_step("R", "custody-accept", offered, accepted_r_again)
        h.check(duplicate["status"] == "ACCEPTANCE_ALREADY_COMMITTED",
                "relay acceptance is idempotent after restart-style reopen")
        offered_b = h.work / "forward-b-offered.nhcb"
        custody_step("R", "custody-offer", accepted_r, offered_b)
        accepted_b = h.work / "forward-b-accepted.nhcb"
        result = custody_step("B", "custody-accept", offered_b, accepted_b)
        h.check(result["final_custody_accepted"],
                "final custody acceptance is explicit")
        imported = h.run("forward-final-import", [
            "custody-final-import", "--config", str(state["Bseed"]),
            "--key-directory", str(state["Bkey"]),
            "--input", str(accepted_b),
        ])
        h.check(imported["status"] == "FINAL_CAPSULE_IMPORTED" and
                imported["imported_operation"] == state["operation"],
                "final recipient imports through existing admission path")
        duplicate = h.run("forward-final-import-duplicate", [
            "custody-final-import", "--config", str(state["Bseed"]),
            "--key-directory", str(state["Bkey"]),
            "--input", str(accepted_b),
        ])
        h.check(duplicate["status"] == "ALREADY_IMPORTED",
                "final import remains idempotent")
        status = h.run("relay-status-after-forward", [
            "custody-status", "--config", str(state["Rseed"]),
        ])
        h.check(status["case_count"] == 1 and status["event_count"] >= 3,
                "relay reconstructs retained custody state from stale seed")
        state["forward_final"] = accepted_b

    h.case("operation_custody_uncertainty_restart_and_final_import", forward_operation)

    def receipt_return() -> None:
        receipt = h.work / "receipt.nhcp"
        handoff_export("B", "A", state["operation"], "receipt", receipt)
        created = h.work / "return-created.nhcb"
        custody_create("B", state["route_ba"], receipt, created)
        offered_r = h.work / "return-r-offered.nhcb"
        custody_step("B", "custody-offer", created, offered_r)
        accepted_r = h.work / "return-r-accepted.nhcb"
        custody_step("R", "custody-accept", offered_r, accepted_r)
        offered_a = h.work / "return-a-offered.nhcb"
        custody_step("R", "custody-offer", accepted_r, offered_a)
        accepted_a = h.work / "return-a-accepted.nhcb"
        result = custody_step("A", "custody-accept", offered_a, accepted_a)
        h.check(result["final_custody_accepted"], "origin accepts return custody")
        imported = h.run("return-final-import", [
            "custody-final-import", "--config", str(state["Aseed"]),
            "--key-directory", str(state["Akey"]),
            "--input", str(accepted_a),
        ])
        h.check(imported["status"] == "FINAL_CAPSULE_IMPORTED" and
                imported["imported_operation"] == state["operation"],
                "return capsule reconciles exact operation")
        daemon = h.start("a-after-receipt", state["Aseed"], state["Astate"])
        entry = outbox_entry(h.status("a-acked", state["Astate"]), state["operation"])
        h.check(entry["status"] == "ACKED",
                "only exact authenticated receipt completes obligation")
        daemon.shutdown()

    h.case("reverse_custody_and_exact_receipt_completion", receipt_return)

    def negatives_and_current_policy() -> None:
        extra = operation("custody-direct-unauthorized")
        daemon = h.start("a-extra", state["Aseed"], state["Astate"])
        submit(h, "queue-extra", daemon.control, "A", "B", "test/three",
               extra, "must not bypass exact next hop")
        daemon.shutdown()
        capsule = h.work / "extra.nhcp"
        handoff_export("A", "B", extra, "operation", capsule)
        direct = h.work / "direct.nhcb"
        rejected = custody_create("A", state["route_direct"], capsule,
                                  direct, expected=3)
        h.check(rejected["code"] == "CUSTODY_GRANT_NOT_AUTHORIZED" and
                not direct.exists(), "ungranted next hop is rejected")

        retained_bindings = [state["Abinding"], state["Rbinding"],
                             state["Bbinding"]]
        removed_records = policy_lines(retained_bindings, list(state["grants"])[1:])
        removal = candidate(
            h, state["Av21"], "a-v21-history-removal",
            "a-v21-history-removal",
            lambda text, records=removed_records:
                "\n".join(line for line in text.splitlines()
                          if not line.startswith(("handoff_key_hex=",
                                                  "custody_grant_hex="))) +
                "\n" + records,
        )
        daemon = h.start("a-history-removal", state["Aseed"], state["Astate"])
        rejected_history = activate(
            h, "a-history-removal", state["Astate"], removal,
            expected=3, code="CONFIG_CUSTODY_GRANT_HISTORY_REMOVED")
        h.check(rejected_history["code"] ==
                "CONFIG_CUSTODY_GRANT_HISTORY_REMOVED",
                "accepted grant history cannot be erased")
        daemon.shutdown()

        revoked_grants = list(state["grants"])
        revoked_grants[0] = grant(identifier="a-r", origin="A", final="B",
                                  custodian="A", next_hop="R", state="REVOKED")
        records = policy_lines(
            [state["Abinding"], state["Rbinding"], state["Bbinding"]],
            revoked_grants,
        )
        successor = candidate(
            h, state["Av21"], "a-v21-revoked", "a-v21-revoked",
            lambda text, records=records:
                "\n".join(line for line in text.splitlines()
                          if not line.startswith(("handoff_key_hex=", "custody_grant_hex="))) +
                "\n" + records,
        )
        daemon = h.start("a-revoke", state["Aseed"], state["Astate"])
        activate(h, "a-revoke-grant", state["Astate"], successor)
        daemon.shutdown()
        rejected = custody_create("A", state["route_ab"], capsule,
                                  h.work / "revoked.nhcb", expected=3)
        h.check(rejected["code"] == "CUSTODY_GRANT_NOT_AUTHORIZED",
                "stale seed cannot undo accepted grant revocation")

        malformed = h.work / "malformed-route.txt"
        malformed.write_text("NATRAV_CUSTODY_ROUTE_V1\nbinding_hex=AA\n")
        malformed.chmod(0o600)
        rejected = custody_create("A", malformed, capsule,
                                  h.work / "malformed.nhcb", expected=3)
        h.check(rejected["code"] == "CUSTODY_ROUTE_REJECTED",
                "noncanonical route is rejected")

    h.case("unauthorized_next_hop_revocation_and_negative_controls",
           negatives_and_current_policy)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--sanitize-probe", action="store_true")
    args = parser.parse_args()
    source = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    if output.exists() or output == source or source in output.parents:
        parser.error("output must be new and outside source")
    h = Harness(args.binary, output)
    started = time.monotonic()
    status = "FAIL"
    failure = None
    try:
        suite(h, sanitize_probe=args.sanitize_probe)
        status = "PASS"
    except BaseException as error:
        failure = repr(error)
        (output / "failure.txt").write_text(failure + "\n")
        import traceback
        traceback.print_exc()
    finally:
        h.cleanup()
        result = {
            "format": "NATRAV_DURABLE_CUSTODY_AUTHORITY_TEST_V1",
            "status": status,
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(case["status"] == "PASS" for case in h.cases),
            "cases_total": len(h.cases),
            "assertions": h.assertions,
            "commands": len(h.commands),
            "sanitized_native_probe": args.sanitize_probe,
            "cases": h.cases,
            "elapsed_seconds": time.monotonic() - started,
            "failure": failure,
        }
        (output / "SUMMARY.json").write_text(
            json.dumps(result, indent=2, sort_keys=True) + "\n")
        print(json.dumps({key: value for key, value in result.items()
                          if key != "cases"}, sort_keys=True))
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
