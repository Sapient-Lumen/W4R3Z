#!/usr/bin/env python3
"""Build an isolated INSPECT-omission control; never modify the product tree."""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--prepare-only',action='store_true')
    a=p.parse_args();root=Path(__file__).resolve().parents[2];out=a.output.resolve()
    if out.exists() or out==root or root in out.parents:p.error('output must be new and outside product')
    tree=out/'source';tree.mkdir(parents=True)
    for part in ('node/src','foundation/src','foundation/include'):shutil.copytree(root/part,tree/part)
    shutil.copy2(root/'node/build.sh',tree/'node/build.sh')
    path=tree/'node/src/daemon.cpp';before=path.read_text()
    anchor='''        if (!local_control_allows(
                authorization_config->local_control,
                principal->uid,
                metadata.command_class) ||'''
    replacement='''        if ((!std::holds_alternative<ControlStateHead>(request) && !local_control_allows(
                authorization_config->local_control,
                principal->uid,
                metadata.command_class)) ||'''
    assert before.count(anchor)==1
    after=before.replace(anchor,replacement);path.write_text(after)
    (out/'OMIT-INSPECT.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),
        fromfile='normal/daemon.cpp',tofile='negative/daemon.cpp')))
    if a.prepare_only:print(json.dumps({'status':'PREPARED_NOT_BUILT','source':str(tree)}));return 0
    begin=time.monotonic()
    with (out/'BUILD.log').open('w') as log:
        run=subprocess.run(['sh','node/build.sh','static'],cwd=tree,stdout=log,stderr=subprocess.STDOUT,timeout=600)
    binary=tree/'node/bin/natrav-overlay'
    (out/'BUILD.json').write_text(json.dumps({'status':'PASS' if run.returncode==0 else 'FAIL','returncode':run.returncode,
        'elapsed_seconds':time.monotonic()-begin,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest() if binary.exists() else None},indent=2)+'\n')
    return run.returncode

if __name__=='__main__':raise SystemExit(main())
