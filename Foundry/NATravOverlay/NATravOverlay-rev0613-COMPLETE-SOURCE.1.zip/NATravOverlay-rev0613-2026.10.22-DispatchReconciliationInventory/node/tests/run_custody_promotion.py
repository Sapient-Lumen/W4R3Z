#!/usr/bin/env python3
"""Offline authenticated detached-custody promotion validation."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from typing import Any

from run_persistent import Harness
from run_authenticated_recovery import setup
from run_state_expectations import selector, append
from run_state_head_custody import parse_record, exact_args
from run_custody_state_opening import create_anchor, constraint_args
from run_backup_correlated_stop_audit import backup_key, export_backup
from run_state_authentication import new_key

CASES = (
    "state_append_promotion_and_reopen",
    "state_stale_divergent_and_noop",
    "backup_promotion_and_reopen",
    "backup_trust_failures",
    "backup_source_replacement_race",
    "prepublication_failure_and_duplicate",
    "custody_replacement_race",
    "strict_cli_and_no_mutation",
)


def promote_state_args(path: Path, record: dict[str, Any], generation: int,
                       state: Path, key: Path) -> list[str]:
    return ["state-head-custody-promote", *exact_args(path, record),
        "--new-generation", str(generation), "--state", str(state),
        "--state-auth-key", str(key)]


def promote_backup_args(path: Path, record: dict[str, Any], generation: int,
                        archive: Path, state_key: Path, decrypt_key: Path,
                        certificate: Path, backup_id: str | None = None) -> list[str]:
    args = ["state-head-custody-promote", *exact_args(path, record),
        "--new-generation", str(generation), "--input", str(archive),
        "--generation", "a-g1", "--state-auth-key", str(state_key),
        "--decrypt-key", str(decrypt_key), "--trusted-cert", str(certificate),
        "--require-signature", "yes", "--require-encryption", "yes"]
    if backup_id is not None:
        args += ["--expected-backup-id", backup_id]
    return args


def run_with_environment(h: Harness, label: str, args: list[str],
                         environment: dict[str, str], expected: int = 0,
                         timeout: int = 30) -> dict[str, Any] | None:
    started = time.time()
    completed = subprocess.run([str(h.binary), *args], capture_output=True,
        text=True, timeout=timeout, env=dict(os.environ, **environment))
    h.commands.append({"label": label, "args": args,
        "returncode": completed.returncode, "stdout": completed.stdout,
        "stderr": completed.stderr, "elapsed_seconds": time.time() - started,
        "environment": sorted(environment)})
    (h.logs / f"{len(h.commands):03d}-{label}.stdout.txt").write_text(completed.stdout)
    (h.logs / f"{len(h.commands):03d}-{label}.stderr.txt").write_text(completed.stderr)
    h.check(completed.returncode == expected,
        f"{label}: return {completed.returncode}, expected {expected}; "
        f"stdout={completed.stdout!r} stderr={completed.stderr!r}")
    lines = [line for line in completed.stdout.splitlines() if line.strip()]
    return json.loads(lines[-1]) if lines else None


def run_suite(h: Harness, selected: set[str] | None) -> None:
    def case(name: str, fn: Any) -> None:
        if selected is None or name in selected:
            h.case(name, fn)

    def state_append_promotion_and_reopen() -> None:
        root, state, key = setup(h, "promotion-state")
        old_head = selector((state / "state.journal").read_bytes(), key)
        record_path, record = create_anchor(h, "promotion-state-anchor",
            root / "anchors", old_head, generation=7)
        state_before = (state / "state.journal").read_bytes()
        append(h, state, key, "promotion-state-next")
        state_after = (state / "state.journal").read_bytes()
        current_head = selector(state_after, key)
        h.check(current_head != old_head and state_after.startswith(state_before),
            "fixture is an exact append-only authenticated extension")
        value = h.run("promotion-state-advance",
            promote_state_args(record_path, record, 8, state, key), timeout=30)
        assert value
        current = parse_record(record_path.read_bytes())
        h.check(value["format"] == "NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_V1",
            "promotion has an explicit response format")
        h.check(value["relationship"] == "VERIFIED_APPEND_ONLY_EXTENSION",
            "same-epoch source is proven through its exact authenticated prefix")
        h.check(value["derived_state_head"] == current_head and
            value["caller_supplied_new_selector"] is False,
            "replacement head is derived from the validated source")
        h.check(current["generation"] == 8 and current["selector"] == current_head,
            "atomic CAS publishes the exact derived head")
        h.check((state / "state.journal").read_bytes() == state_after,
            "promotion never mutates node state")
        reopened = h.run("promotion-state-reopen", ["inspect", "--state", str(state),
            "--node", "A", "--state-auth-key", str(key),
            *constraint_args(record_path, current)])
        assert reopened
        h.check(reopened["state_head"]["selector"] == current_head and
            reopened["state_head"]["expectation"] == "MATCH",
            "revision-0573 adapter reopens the promoted exact state")

        next_key = new_key(h, root, "promotion-state-g2")
        rotated = h.run("promotion-state-rotate", ["state-auth-rotate",
            "--state", str(state), "--node", "A", "--state-auth-key", str(key),
            "--new-key", str(next_key), "--reason",
            "custody promotion direct checkpoint successor"], timeout=30)
        assert rotated
        rotated_head = selector((state / "state.journal").read_bytes(), next_key)
        checkpoint = h.run("promotion-state-checkpoint-successor",
            promote_state_args(record_path, current, 9, state, next_key), timeout=30)
        assert checkpoint
        after_rotation = parse_record(record_path.read_bytes())
        h.check(checkpoint["relationship"] ==
            "VERIFIED_AUTHENTICATED_CHECKPOINT_SUCCESSOR",
            "state-directory rotation proves the exact old authenticated parent root")
        h.check(after_rotation["selector"] == rotated_head and
            after_rotation["generation"] == 9,
            "state checkpoint promotion publishes only the internally derived rotated head")
        h.run("promotion-state-rotated-reopen", ["inspect", "--state", str(state),
            "--node", "A", "--state-auth-key", str(next_key),
            *constraint_args(record_path, after_rotation)])

    case("state_append_promotion_and_reopen", state_append_promotion_and_reopen)

    def state_stale_divergent_and_noop() -> None:
        root, state, key = setup(h, "promotion-stale")
        stale = root / "stale-state"
        shutil.copytree(state, stale)
        initial = selector((state / "state.journal").read_bytes(), key)
        path, record = create_anchor(h, "promotion-stale-anchor",
            root / "anchors", initial)
        append(h, state, key, "promotion-stale-new")
        promoted = h.run("promotion-stale-first",
            promote_state_args(path, record, 2, state, key), timeout=30)
        assert promoted
        current = parse_record(path.read_bytes()); current_bytes = path.read_bytes()
        noop = h.run("promotion-noop", promote_state_args(path, current, 3, state, key),
            expected=3, timeout=30)
        h.check(noop and noop["code"] == "STATE_HEAD_CUSTODY_PROMOTION_NOOP",
            "exact current head is never advanced as a no-op")
        h.check(path.read_bytes() == current_bytes, "no-op preserves exact custody bytes")
        old = h.run("promotion-stale-input", promote_state_args(path, current, 3, stale, key),
            expected=3, timeout=30)
        h.check(old and old["code"] == "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_STALE",
            "authenticated input older than custody fails closed")
        h.check(path.read_bytes() == current_bytes, "stale input preserves custody")

        droot, base, dkey = setup(h, "promotion-divergent")
        branch = droot / "other-branch"; shutil.copytree(base, branch)
        append(h, base, dkey, "promotion-left-1")
        left_head = selector((base / "state.journal").read_bytes(), dkey)
        dpath, drecord = create_anchor(h, "promotion-divergent-anchor",
            droot / "anchors", left_head)
        append(h, branch, dkey, "promotion-rght-1")
        append(h, branch, dkey, "promotion-rght-2")
        before = dpath.read_bytes()
        divergent = h.run("promotion-divergent-input",
            promote_state_args(dpath, drecord, 2, branch, dkey), expected=3, timeout=30)
        h.check(divergent and divergent["code"] ==
            "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_DIVERGENT",
            "a longer same-epoch branch must contain the exact old prefix")
        h.check(dpath.read_bytes() == before, "divergent branch preserves custody")

    case("state_stale_divergent_and_noop", state_stale_divergent_and_noop)

    def backup_promotion_and_reopen() -> None:
        root, state, key = setup(h, "promotion-backup")
        old_head = selector((state / "state.journal").read_bytes(), key)
        path, record = create_anchor(h, "promotion-backup-anchor",
            root / "anchors", old_head, domain="backup-promotion", generation=4)
        encryption = backup_key(h, root, "promotion-backup", "enc-g1")
        archive, exported = export_backup(h, "promotion-backup", state, key, encryption)
        archive_before = archive.read_bytes(); state_before = (state / "state.journal").read_bytes()
        certificate = h.identity("A").certificate
        value = h.run("promotion-backup-advance",
            promote_backup_args(path, record, 5, archive, key, encryption,
                certificate, exported["backup_id"]), timeout=30)
        assert value
        current = parse_record(path.read_bytes())
        backup_head = exported["state_head"]["selector"]
        h.check(value["relationship"] ==
            "VERIFIED_AUTHENTICATED_CHECKPOINT_SUCCESSOR",
            "signed checkpoint proves the old authenticated parent root")
        h.check(current["selector"] == backup_head and
            value["derived_state_head"] == backup_head,
            "backup promotion publishes the exact embedded checkpoint head")
        h.check(archive.read_bytes() == archive_before and
            (state / "state.journal").read_bytes() == state_before,
            "backup promotion neither restores nor mutates source state")
        verified = h.run("promotion-backup-reopen", ["backup-verify",
            "--input", str(archive), "--node", "A", "--generation", "a-g1",
            "--trusted-cert", str(certificate), "--require-signature", "yes",
            "--decrypt-key", str(encryption), "--require-encryption", "yes",
            "--state-auth-key", str(key), *constraint_args(path, current)], timeout=30)
        assert verified
        h.check(verified["state_head"]["selector"] == backup_head and
            verified["state_head"]["expectation"] == "MATCH",
            "promoted custody directly constrains the encrypted backup checkpoint")

    case("backup_promotion_and_reopen", backup_promotion_and_reopen)

    def backup_trust_failures() -> None:
        root, state, key = setup(h, "promotion-backup-fail")
        old_head = selector((state / "state.journal").read_bytes(), key)
        path, record = create_anchor(h, "promotion-backup-fail-anchor",
            root / "anchors", old_head)
        encryption = backup_key(h, root, "promotion-backup-fail", "enc-g1")
        archive, exported = export_backup(h, "promotion-backup-fail", state, key, encryption)
        before = path.read_bytes(); archive_before = archive.read_bytes()
        wrong_encryption = backup_key(h, root, "promotion-backup-wrong", "enc-g2")
        wrong_state_key = new_key(h, root, "promotion-state-wrong")
        wrong_certificate = h.identity("B").certificate
        attempts = [
            ("decrypt", wrong_encryption, key, h.identity("A").certificate, None),
            ("state-key", encryption, wrong_state_key, h.identity("A").certificate, None),
            ("signer", encryption, key, wrong_certificate, None),
            ("backup-id", encryption, key, h.identity("A").certificate, "11" * 32),
        ]
        for label, decrypt, state_key, cert, expected_id in attempts:
            value = h.run("promotion-backup-wrong-" + label,
                promote_backup_args(path, record, 2, archive, state_key,
                    decrypt, cert, expected_id), expected=3, timeout=30)
            h.check(value is not None and value.get("ok") is False,
                "wrong backup trust input fails closed")
            h.check(path.read_bytes() == before and archive.read_bytes() == archive_before,
                "trust failure preserves custody and encrypted backup")
        h.check(exported["backup_id"] != "11" * 32, "wrong backup identity is independent")

    case("backup_trust_failures", backup_trust_failures)

    def backup_source_replacement_race() -> None:
        root, state, key = setup(h, "promotion-backup-race")
        old_head = selector((state / "state.journal").read_bytes(), key)
        path, record = create_anchor(h, "promotion-backup-race-anchor",
            root / "anchors", old_head)
        encryption = backup_key(h, root, "promotion-backup-race", "enc-g1")
        first, first_result = export_backup(h, "promotion-backup-race-first",
            state, key, encryption)
        second, second_result = export_backup(h, "promotion-backup-race-second",
            state, key, encryption)
        h.check(first_result["state_head"]["selector"] !=
            second_result["state_head"]["selector"],
            "two signed backup checkpoints are distinct direct successors")
        before = path.read_bytes()
        args = promote_backup_args(path, record, 2, first, key, encryption,
            h.identity("A").certificate)
        started = time.time()
        process = subprocess.Popen([str(h.binary), *args], stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, env=dict(os.environ,
                NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_PAUSE_BEFORE_BACKUP_VERIFY_MS="700"))
        time.sleep(0.2)
        os.replace(second, first)
        stdout, stderr = process.communicate(timeout=30)
        h.commands.append({"label": "promotion-backup-source-race", "args": args,
            "returncode": process.returncode, "stdout": stdout, "stderr": stderr,
            "elapsed_seconds": time.time() - started,
            "environment": ["NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_PAUSE_BEFORE_BACKUP_VERIFY_MS"]})
        (h.logs / f"{len(h.commands):03d}-promotion-backup-source-race.stdout.txt").write_text(stdout)
        (h.logs / f"{len(h.commands):03d}-promotion-backup-source-race.stderr.txt").write_text(stderr)
        h.check(process.returncode == 3, "backup pathname replacement is rejected")
        value = json.loads([line for line in stdout.splitlines() if line.strip()][-1])
        h.check(value["code"] == "BACKUP_SOURCE_CHANGED",
            "verification is bound to the exact retained encrypted-file snapshot")
        h.check(path.read_bytes() == before,
            "backup replacement race never advances custody")

    case("backup_source_replacement_race", backup_source_replacement_race)

    def prepublication_failure_and_duplicate() -> None:
        root, state, key = setup(h, "promotion-failure")
        old_head = selector((state / "state.journal").read_bytes(), key)
        path, record = create_anchor(h, "promotion-failure-anchor",
            root / "anchors", old_head)
        append(h, state, key, "promotion-failure-next")
        before = path.read_bytes()
        failed = run_with_environment(h, "promotion-injected-failure",
            promote_state_args(path, record, 2, state, key),
            {"NATRAV_OVERLAY_TEST_CUSTODY_FAIL_BEFORE_PUBLISH": "yes"}, expected=3)
        h.check(failed and failed["code"] ==
            "STATE_HEAD_CUSTODY_TEST_PREPUBLICATION_FAILURE",
            "injected failure occurs after complete validation but before exchange")
        h.check(path.read_bytes() == before, "prepublication failure preserves exact old custody")
        success = h.run("promotion-after-failure",
            promote_state_args(path, record, 2, state, key), timeout=30)
        assert success
        after = path.read_bytes()
        duplicate = h.run("promotion-duplicate-old-attempt",
            promote_state_args(path, record, 2, state, key), expected=3, timeout=30)
        h.check(duplicate and duplicate["code"] == "STATE_HEAD_CUSTODY_EXPECTATION_MISMATCH",
            "repeating an exact old attempt is not idempotent")
        h.check(path.read_bytes() == after, "duplicate attempt preserves the winner")

    case("prepublication_failure_and_duplicate", prepublication_failure_and_duplicate)

    def custody_replacement_race() -> None:
        root, state, key = setup(h, "promotion-race")
        old_head = selector((state / "state.journal").read_bytes(), key)
        directory = root / "anchors"
        path, record = create_anchor(h, "promotion-race-anchor", directory, old_head)
        append(h, state, key, "promotion-race-next")
        current_head = selector((state / "state.journal").read_bytes(), key)
        replacement, _ = create_anchor(h, "promotion-race-replacement", directory,
            current_head, generation=9, filename="replacement.head")
        winner = replacement.read_bytes()
        args = promote_state_args(path, record, 2, state, key)
        started = time.time()
        process = subprocess.Popen([str(h.binary), *args], stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, env=dict(os.environ,
                NATRAV_OVERLAY_TEST_CUSTODY_PAUSE_BEFORE_RECHECK_MS="700"))
        time.sleep(0.2); os.replace(replacement, path)
        stdout, stderr = process.communicate(timeout=20)
        h.commands.append({"label": "promotion-custody-race", "args": args,
            "returncode": process.returncode, "stdout": stdout, "stderr": stderr,
            "elapsed_seconds": time.time() - started,
            "environment": ["NATRAV_OVERLAY_TEST_CUSTODY_PAUSE_BEFORE_RECHECK_MS"]})
        (h.logs / f"{len(h.commands):03d}-promotion-custody-race.stdout.txt").write_text(stdout)
        (h.logs / f"{len(h.commands):03d}-promotion-custody-race.stderr.txt").write_text(stderr)
        h.check(process.returncode == 3, "concurrent custody replacement is rejected")
        value = json.loads([line for line in stdout.splitlines() if line.strip()][-1])
        h.check(value["code"] == "STATE_HEAD_CUSTODY_REPLACEMENT_RACE",
            "race has a precise failure code")
        h.check(path.read_bytes() == winner,
            "promotion never overwrites the independently replaced winner")

    case("custody_replacement_race", custody_replacement_race)

    def strict_cli_and_no_mutation() -> None:
        root, state, key = setup(h, "promotion-strict")
        old_head = selector((state / "state.journal").read_bytes(), key)
        path, record = create_anchor(h, "promotion-strict-anchor",
            root / "anchors", old_head)
        before_record = path.read_bytes(); before_state = (state / "state.journal").read_bytes()
        missing = h.run("promotion-missing-source", ["state-head-custody-promote",
            *exact_args(path, record), "--new-generation", "2",
            "--state-auth-key", str(key)], expected=3)
        h.check(missing and missing["code"] == "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_REQUIRED",
            "promotion requires exactly one explicit source")
        both = h.run("promotion-two-sources", [*promote_state_args(path, record, 2, state, key),
            "--input", str(root / "none.nob")], expected=3)
        h.check(both and both["code"] == "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_REQUIRED",
            "state and backup sources cannot be mixed")
        supplied = h.run("promotion-caller-new-head", [*promote_state_args(path, record, 2, state, key),
            "--new-head", old_head], expected=3)
        h.check(supplied and supplied["code"] == "UNKNOWN_ARGUMENT",
            "caller cannot supply a replacement selector")
        no_key_args = promote_state_args(path, record, 2, state, key)
        at = no_key_args.index("--state-auth-key")
        del no_key_args[at:at+2]
        no_key = h.run("promotion-no-state-key", no_key_args, expected=3)
        h.check(no_key and no_key["code"] == "STATE_AUTH_KEY_REQUIRED",
            "custody is never an authentication key")
        nonadvancing = h.run("promotion-generation-no-advance",
            promote_state_args(path, record, record["generation"], state, key), expected=3)
        h.check(nonadvancing and nonadvancing["code"] ==
            "STATE_HEAD_CUSTODY_GENERATION_INVALID",
            "promotion generation must strictly advance")
        h.check(path.read_bytes() == before_record and
            (state / "state.journal").read_bytes() == before_state,
            "strict parser and precondition failures mutate neither custody nor state")

    case("strict_cli_and_no_mutation", strict_cli_and_no_mutation)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append", choices=CASES)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    harness = Harness(args.binary, args.output)
    started = time.time(); code = 1
    try:
        run_suite(harness, set(args.case) if args.case else None)
        code = 0
    except BaseException as error:
        (harness.output / "FAILURE.txt").write_text(
            f"{type(error).__name__}: {error}\n")
        print(f"FAIL: {type(error).__name__}: {error}", file=sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_CUSTODY_PROMOTION_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (("SUMMARY.json", summary),
                ("CASES.json", harness.cases), ("COMMANDS.json", harness.commands)):
            (harness.output / name).write_text(
                json.dumps(value, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
