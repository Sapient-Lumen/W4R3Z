#!/usr/bin/env python3
"""Bounded administrative outbox queries against owned native daemons.
Independent OBQ1 encoding and response/reference checks; no third-party targets.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, signal, socket, struct, time
from pathlib import Path
from run_persistent import Harness, free_port, operation, raw_control, receive_exact
from run_multi_route import write_v13_config
from run_live_configuration import candidate, activate
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_state_authentication import new_key, migrate, start as start_keyed, inspect


def arguments(state, *, op=None, peer='', outcome='', limit=32, maximum=60000, history=4, cursor=None):
    args=['outbox-query','--control',str(state/'control.sock'),'--limit',str(limit),'--max-bytes',str(maximum),
          '--history-limit',str(history),'--deadline-ms','5000']
    if op:args+=['--operation',op]
    if peer:args+=['--peer',peer]
    if outcome:args+=['--state',outcome]
    if cursor:args+=['--cursor',cursor]
    return args


def query(h,label,state,uid=None,expected=0,**kw):
    args=arguments(state,**kw)
    q=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    if expected==0:
        h.check(q['format']=='NATRAV_OVERLAY_OUTBOX_QUERY_V1','explicit metadata-query format')
        h.check(q['returned']==len(q['records']) and q['returned']<=kw.get('limit',32),'exact returned-row account')
        h.check(q['work']['payload_bytes_read']==0,'no payload reads in inspection')
        h.check(q['work']['records_visited']<=kw.get('limit',32)+1,'bounded indexed page visits')
        h.check(len(json.dumps(q,separators=(',',':')).encode())<=kw.get('maximum',60000),'complete annotated response bounded')
        for row in q['records']:
            h.check('payload_hex' not in row and 'payload' not in row and 'last_error_detail' not in row.get('delivery',{}),'no payload or error detail copied')
    return q


def wire(*,op=None,peer='',outcome='',limit=32,maximum=60000,history=4,cursor=''):
    text=lambda s:struct.pack('!H',len(s))+s.encode()
    return b'NOC1\x17OBQ1'+text(peer)+text(outcome)+(b'\x01'+bytes.fromhex(op) if op else b'\x00')+struct.pack('!III',limit,maximum,history)+text(cursor)


def setup(h,name,*,online=False,delegates=False):
    a=h.runtime/(name+'-a');b=h.runtime/(name+'-b');bp=free_port();cp=free_port();dp=free_port()
    while len({bp,cp,dp})!=3:cp=free_port();dp=free_port()
    ac=write_v13_config(h,name+'-a','A',a,f'127.0.0.1:{free_port()}',name+'-g1',[
        ('B',[('primary',0,'ENABLED' if online else 'DISABLED',f'127.0.0.1:{bp}')],50,100,100,600000),
        ('C',[('primary',0,'DISABLED',f'127.0.0.1:{cp}')],50,100,100,600000),
        ('D',[('primary',0,'DISABLED',f'127.0.0.1:{dp}')],50,100,100,200)],deadline_ms=2000)
    if delegates:ac.write_text(ac.read_text()+'local_control=65534,INSPECT\nlocal_control=65533,SUBMIT\n')
    bc=write_v13_config(h,name+'-b','B',b,f'127.0.0.1:{bp}',name+'-b-g1',[],trusts=['A'],authorizations=[('A','test/three')],deadline_ms=2000)
    bd=h.start(name+'-b',bc,b) if online else None;ad=h.start(name+'-a',ac,a)
    return a,b,ac,bc,ad,bd


def submit(h,label,a,peer='C',scope='test/three',payload='bounded test metadata'):
    op=operation(label)
    h.run(label,['submit','--control',str(a/'control.sock'),'--node','A','--peer',peer,'--scope',scope,'--operation',op,'--payload-text',payload,'--deadline-ms','5000'])
    return op


def wait_outcome(h,label,a,op,expected):
    saved={}
    def done():
        q=query(h,label,a,op=op);saved.update(q['records'][0]);return saved['status']==expected
    h.wait(label,done,timeout=12);return saved


def enumerate_rows(h,label,a,**kw):
    rows=[];token=None;pages=0
    while True:
        q=query(h,label+'-'+str(pages),a,cursor=token,**kw);rows+=q['records'];pages+=1
        if not q['more']:break
        token=q['next_cursor'];h.check(bool(token),'nonempty continuation when more')
    return rows,pages


def stable(rows):
    return [{k:v for k,v in r.items() if k!='operation_revision'} for r in rows]


def run_cases(h,selected):
    def case(name,fn):
        if selected is None or name in selected:h.case(name,fn)

    def indexed():
        a,b,ac,bc,ad,bd=setup(h,'indexed',online=True)
        expected={}
        for i in range(150):
            peer='B' if i%2==0 else 'C';op=submit(h,f'indexed-{i}',a,peer=peer,payload=f'body-{i}')
            expected[op]=(i+1,peer,len(f'body-{i}'))
        h.wait('all B receipts',lambda:query(h,'b-total',a,peer='B',outcome='ACKED',limit=1)['selected_total']==75,timeout=20)
        summary=h.status('generic-truncated',a)
        h.check(0 < len(summary['outbox']['entries']) <= 64 and summary['outbox']['entries_returned'] == len(summary['outbox']['entries']) and summary['outbox']['entries_truncated'] and summary['outbox']['count'] == 150, 'generic status reports exact total and deliberate row/byte truncation')
        target=operation('indexed-149');row=query(h,'exact-beyond-summary',a,op=target)['records'][0]
        h.check(row['queue_sequence']==150 and row['status']=='PENDING' and row['delivery']['attempts']==0,'exact retained record beyond summary and route probes not application attempts')
        rows,pages=enumerate_rows(h,'whole-outbox',a,limit=7,history=0)
        h.check(len(rows)==150 and len({r['operation_id'] for r in rows})==150,'complete enumeration without duplication')
        for row in rows:
            n,peer,count=expected[row['operation_id']]
            h.check((row['queue_sequence'],row['recipient'],row['payload_bytes'])==(n,peer,count),'independent order, recipient and byte count')
            h.check(row['status']==('ACKED' if peer=='B' else 'PENDING'),'independent outcome reference')
        for peer,outcome in [('B','ACKED'),('C','PENDING')]:
            subset,_=enumerate_rows(h,'filtered-'+peer,a,peer=peer,outcome=outcome,limit=11)
            h.check(len(subset)==75 and all(r['recipient']==peer and r['status']==outcome for r in subset),'exact conjunctive indexes')
        # Deliberately denied scope and terminal transitions use actual native admission.
        rejected=submit(h,'typed-rejection',a,peer='B',scope='test/denied')
        r=wait_outcome(h,'rejected-ready',a,rejected,'REJECTED');h.check(r['active_rejection']['error_code']=='AUTHORIZATION_DENIED','typed authenticated rejection retained')
        cancelled=operation('indexed-149');h.run('cancel-one',['cancel','--control',str(a/'control.sock'),'--operation',cancelled,'--reason','selected cancellation'])
        h.check(query(h,'cancelled',a,op=cancelled)['records'][0]['reserved_records']==0,'cancellation releases reported reservation')
        expired=submit(h,'expire-one',a,peer='D');wait_outcome(h,'expired-ready',a,expired,'EXPIRED')
        for outcome in ('ACKED','PENDING','REJECTED','CANCELLED','EXPIRED'):
            q=query(h,'outcome-'+outcome,a,outcome=outcome,limit=64,history=0)
            h.check(q['selected_total']>0 and all(r['status']==outcome for r in q['records']),'indexed exact outcome '+outcome)
        h.check(query(h,'absent-operation',a,op='01'*32)['records']==[],'missing exact ID is empty')
        h.check(query(h,'conjunctive-miss',a,op=target,peer='B')['records']==[],'exact lookup respects filters')
        (h.output/'ENUMERATION.json').write_text(json.dumps({'records':150,'pages':pages,'exact_queue_sequence':150,'outcomes':5},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('exact_beyond_summary_complete_filtered_enumeration_and_all_outcomes',indexed)

    def cursors():
        a,b,ac,bc,ad,bd=setup(h,'cursors')
        ops=[submit(h,'cursor-'+str(i),a) for i in range(7)]
        p=query(h,'cursor-first',a,peer='C',limit=2);token=p['next_cursor']
        q=query(h,'cursor-second',a,peer='C',limit=2,cursor=token)
        h.check([r['operation_id'] for r in q['records']]==ops[2:4],'stable continuation seeks without scanning earlier records')
        submit(h,'unrelated-peer',a,peer='B')
        h.check(query(h,'other-peer-does-not-stale',a,peer='C',limit=2,cursor=token)['records']==q['records'],'unrelated peer mutation does not invalidate selected bucket')
        bad=token[:-1]+('0' if token[-1]!='0' else '1')
        h.check(query(h,'bad-mac',a,peer='C',limit=2,cursor=bad,expected=3)['code']=='OUTBOX_CURSOR_INVALID','tampered cursor rejected')
        for opts in [dict(peer='B',limit=2),dict(peer='C',limit=3),dict(peer='C',limit=2,history=0)]:
            h.check(query(h,'changed-options',a,cursor=token,expected=3,**opts)['code']=='OUTBOX_CURSOR_CONTEXT_MISMATCH','all query options bound')
        h.run('selected-change',['cancel','--control',str(a/'control.sock'),'--operation',ops[5],'--reason','selected outcome changes'])
        h.check(query(h,'selected-stale',a,peer='C',limit=2,cursor=token,expected=3)['code']=='OUTBOX_CURSOR_STALE','selected metadata mutation explicitly invalidates cursor')
        current=query(h,'pre-compact-page',a,peer='C',limit=2)
        h.run('cursor-compaction',['compact','--control',str(a/'control.sock')])
        query(h,'same-process-compact',a,peer='C',limit=2,cursor=current['next_cursor'])
        ad.shutdown();ad=h.start('cursor-restart',ac,a)
        h.check(query(h,'old-process-cursor',a,peer='C',limit=2,cursor=current['next_cursor'],expected=3)['code']=='OUTBOX_CURSOR_INVALID','restart never silently accepts old version counters')
        size=(a/'state.journal').stat().st_size
        for i in range(12):
            empty=query(h,'empty-poll-'+str(i),a,peer='MISSING')
            h.check(empty['work']['records_visited']==0 and empty['records']==[],'empty selection has zero record visits')
        h.check((a/'state.journal').stat().st_size==size,'successful and empty inspection append nothing')
        ad.shutdown()
    case('cursor_integrity_context_staleness_compaction_restart_and_empty_reads',cursors)

    def history():
        a,b,ac,bc,ad,bd=setup(h,'history',online=True)
        op=submit(h,'history-reject',a,peer='B',scope='test/denied')
        wait_outcome(h,'history-initial-reject',a,op,'REJECTED')
        for i in range(5):
            h.run('explicit-retry-'+str(i),['retry','--control',str(a/'control.sock'),'--operation',op,'--reason','explicit history test'])
            wait_outcome(h,'history-reject-'+str(i),a,op,'REJECTED')
        allrows,pages=enumerate_rows(h,'exact-history',a,op=op,history=2)
        records=[t for row in allrows for t in row['history']]
        h.check(len(records)==11 and [t['ordinal'] for t in records]==list(range(1,12)),'complete bounded transition enumeration')
        h.check([t['kind'] for t in records]==['REJECTED','RETRIED']*5+['REJECTED'],'independent rejection/retry order')
        h.check(all('reason' not in t and 'reason_sha256' in t for t in records),'freeform administrative reasons are not emitted')
        exact=query(h,'history-token',a,op=op,history=2)
        h.run('history-change',['retry','--control',str(a/'control.sock'),'--operation',op,'--reason','new history after page'])
        h.check(query(h,'history-stale',a,op=op,history=2,cursor=exact['next_cursor'],expected=3)['code']=='OUTBOX_CURSOR_STALE','exact history must not silently straddle a mutation')
        wait_outcome(h,'history-terminal',a,op,'REJECTED')
        # Small budgets reduce complete rows, never truncate metadata.
        q=query(h,'small-history',a,op=op,maximum=4096,history=0)
        h.check(q['records'][0]['history_more'] and not q['more'],'explicit omitted history with zero requested detail')
        err=query(h,'too-large-row',a,op=op,maximum=4096,history=16,expected=3)
        h.check(err['code']=='OUTBOX_QUERY_PAGE_TOO_SMALL','nonfitting first row is explicit')
        raw=wire(op=op,history=1)
        ok,decoded=raw_control(a/'control.sock',raw);h.check(ok and decoded['records'][0]['operation_id']==op,'independent OBQ1 request interoperates')
        for label,bad in [('tail',raw+b'x'),('short',raw[:-1]),('version',raw.replace(b'OBQ1',b'OBQ9')),('rows',wire(limit=65)),('history',wire(history=17)),('outcome',wire(outcome='LOST'))]:
            ok,_=raw_control(a/'control.sock',bad);h.check(not ok,'strict protocol '+label)
        (h.output/'HISTORY.json').write_text(json.dumps({'entries':len(records),'pages':pages,'transitions':records},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('bounded_exact_transition_history_strict_wire_and_mutation_detection',history)

    def authority():
        a,b,ac,bc,ad,bd=setup(h,'authority',delegates=True)
        for i in range(4):submit(h,'authority-'+str(i),a,payload='DO_NOT_EXPOSE_PAYLOAD_MARKER'*100)
        expose_control_for_uid(a)
        first=query(h,'delegated-inspect',a,uid=65534,limit=1)
        h.check('DO_NOT_EXPOSE_PAYLOAD_MARKER' not in json.dumps(first),'payload marker excluded from metadata')
        h.check(query(h,'wrong-class',a,uid=65533,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','SUBMIT does not imply administrative INSPECT')
        h.check(query(h,'cross-uid-cursor',a,limit=1,cursor=first['next_cursor'],expected=3)['code']=='OUTBOX_CURSOR_CONTEXT_MISMATCH','cursor bound to kernel principal')
        # Same owner connection opens under ALL, then loses INSPECT before EOF.
        packet=wire(limit=1);s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);s.settimeout(5);s.connect(str(a/'control.sock'))
        s.sendall(struct.pack('!I',len(packet))+packet[:-1])
        changed=candidate(h,ac,'authority-removed','authority-g2',lambda t:t.replace(f'local_control={os.geteuid()},ALL',f'local_control={os.geteuid()},SUBMIT,MAINTENANCE,CONFIGURATION,SHUTDOWN'))
        activate(h,'remove-inspect-live',a,changed);s.sendall(packet[-1:]);s.shutdown(socket.SHUT_WR)
        size=struct.unpack('!I',receive_exact(s,4))[0];response=receive_exact(s,size);s.close();error=json.loads(response[5:])
        h.check(response[4]==1 and error['code']=='LOCAL_CONTROL_CLASS_DENIED','connected request reauthorizes after live revocation')
        # Other exact INSPECT UID remains authorized under the active candidate.
        query(h,'still-delegated',a,uid=65534)
        restore=candidate(h,ac,'authority-restored','authority-g3');activate(h,'restore-owner-inspect',a,restore)
        h.check(query(h,'configuration-bound-token',a,uid=65534,limit=1,cursor=first['next_cursor'],expected=3)['code']=='OUTBOX_CURSOR_CONTEXT_MISMATCH','configuration digest bound in cursor')
        h.run('inspection-quiesce',['quiesce','--control',str(a/'control.sock'),'--reason','observational API test'])
        query(h,'quiesced-inspection',a);h.run('inspection-resume',['resume','--control',str(a/'control.sock'),'--reason','complete test'])
        restore_owner_only_control(a);ad.shutdown()
    case('real_uid_metadata_only_authority_live_revocation_and_quiescence',authority)

    def maintenance():
        a,b,ac,bc,ad,bd=setup(h,'maintenance')
        ops=[submit(h,'maintenance-'+str(i),a) for i in range(5)]
        h.run('maintenance-cancel',['cancel','--control',str(a/'control.sock'),'--operation',ops[1],'--reason','persistent terminal metadata'])
        old=query(h,'maintenance-before',a,limit=2);reference,_=enumerate_rows(h,'reference',a)
        h.run('maintenance-compact',['compact','--control',str(a/'control.sock')]);query(h,'compact-token-valid',a,limit=2,cursor=old['next_cursor'])
        ad.kill();ad=h.start('hard-restart',ac,a)
        h.check(stable(enumerate_rows(h,'after-kill',a)[0])==stable(reference),'index reconstructs exact metadata after hard restart')
        ad.shutdown();key=new_key(h,h.work,'outbox-state');migrate(h,'outbox-auth-migrate',a,key)
        ad=start_keyed(h,'outbox-keyed',ac,a,key);h.run('keyed-compact',['compact','--control',str(a/'control.sock')]);ad.shutdown()
        h.run('outbox-audit',['state-auth-audit','--state',str(a),'--node','A','--state-auth-key',str(key)])
        before=inspect(h,'before-backup',a,key);crypt=h.work/'outbox.key';h.run('outbox-encryption',['backup-key-init','--output',str(crypt),'--generation','outbox-archive'])
        ident=h.identity('A');archive=h.work/'outbox.nob';h.run('outbox-export',['backup-export','--state',str(a),'--node','A','--generation','a-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'outbox-restored';h.run('outbox-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'after-backup',restored,key);h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'restore preserves logical state')
        moved=candidate(h,ac,'outbox-moved','outbox-moved-g1',lambda t:t.replace('state='+str(a),'state='+str(restored)))
        h.run('outbox-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),'--reason','owned inspection restore','--state-auth-key',str(key)])
        ad=start_keyed(h,'outbox-restored-daemon',moved,restored,key)
        restoredrows,_=enumerate_rows(h,'restored-index',restored)
        h.check(stable(restoredrows)==stable(reference),'restored and relocated derived indexes match full metadata reference')
        h.check(query(h,'restored-old-token',restored,limit=2,cursor=old['next_cursor'],expected=3)['code']=='OUTBOX_CURSOR_INVALID','old process cursor not a durable checkpoint')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'records':len(reference),'logical_state_preserved':True,'metadata_reconstructed':True},indent=2)+'\n');ad.shutdown()
    case('hard_restart_compaction_authenticated_encrypted_restore_and_relocation',maintenance)

    def concurrent_delivery():
        import threading
        a,b,ac,bc,ad,bd=setup(h,'concurrent-delivery')
        operations=[submit(h,'concurrent-delivery-'+str(i),a,peer='B') for i in range(96)]
        enabled=candidate(h,ac,'delivery-enabled','delivery-enabled-g2',lambda t:t.replace('peer_route=B,primary,0,DISABLED','peer_route=B,primary,0,ENABLED'))
        activate(h,'enable-before-listener',a,enabled)
        initial=query(h,'before-receipts',a,peer='B',outcome='PENDING',limit=8)
        h.check(initial['selected_total']==96,'all pending before recipient starts')
        observations=[];failures=[];stop=threading.Event()
        def reader():
            while not stop.is_set():
                try:
                    ok,q=raw_control(a/'control.sock',wire(peer='B',outcome='ACKED',limit=8,history=0))
                    if not ok:raise AssertionError(q)
                    observations.append(q)
                except BaseException as error:failures.append(str(error));return
                time.sleep(.003)
        thread=threading.Thread(target=reader);thread.start()
        try:
            bd=h.start('concurrent-live-recipient',bc,b)
            h.wait('all concurrent receipts',lambda:query(h,'concurrent-ack-count',a,peer='B',outcome='ACKED',limit=1)['selected_total']==96,timeout=20)
        finally:
            stop.set();thread.join(timeout=5)
        h.check(not failures and observations,'concurrent queries complete alongside real receipts')
        for q in observations:
            h.check(q['returned']==min(8,q['selected_total']) and q['work']['records_visited']<=8,'coherent bounded membership count')
            h.check(all(r['status']=='ACKED' and r['receipt']['operation_id']==r['operation_id'] and r['reserved_records']==0 for r in q['records']),'receipt and outcome never straddle mutation')
        h.check(query(h,'receipt-invalidates-selection',a,peer='B',outcome='PENDING',limit=8,cursor=initial['next_cursor'],expected=3)['code']=='OUTBOX_CURSOR_STALE','actual receipt invalidates pending continuation')
        final,_=enumerate_rows(h,'concurrent-final',a,peer='B',outcome='ACKED',limit=9,history=0)
        h.check([r['operation_id'] for r in final]==operations,'final exact order after concurrent delivery')
        (h.output/'CONCURRENT.json').write_text(json.dumps({'observations':len(observations),'records':96,'minimum_ack_count':min(q['selected_total'] for q in observations),'maximum_ack_count':max(q['selected_total'] for q in observations)},indent=2)+'\n')
        ad.shutdown();bd.shutdown()
    case('real_concurrent_receipts_coherent_pages_and_pending_cursor_staleness',concurrent_delivery)

    def associations():
        from run_subscribed_source_views import setup as source_setup, emit
        a,c,ac,cc,ad,cd,s=source_setup(h,'associations-source')
        source,s,outer=emit(h,'association-source',a,c,s,ticks=50)
        row=query(h,'source-link',a,op=outer['operation_id'])['records'][0];link=row['association']
        h.check(link['kind']=='SOURCE_SUBSCRIPTION' and link['source_operation']==source['operation_id'] and link['grant']=='g1','source link derived from durable subscription not payload magic')
        h.run('source-association-compact',['compact','--control',str(a/'control.sock')]);ad.shutdown();ad=h.start('source-association-restart',ac,a)
        h.check(query(h,'source-link-rebuilt',a,op=outer['operation_id'])['records'][0]['association']==link,'source association reconstructed from checkpoint')
        ad.shutdown();cd.shutdown()
        from run_publication_channels import topology, channel_create, channel_publish
        from run_numeric_projection import produce, create, consume
        a,b,c,ac,bc,cc,ad,bd,cd=topology(h,'associations-channel')
        values={};produce(h,'channel-input',a,values,ticks=125);create(h,'channel-projection',b)
        projection,_=consume(h,'channel-process',b,values);channel=channel_create(h,'channel-create',b,projection)['channel']
        published=channel_publish(h,'channel-publish',b,channel,projection)
        # Canonical channel operation is exposed by the existing publication receipt.
        op=published['operation_id'];r=wait_outcome(h,'channel-outbox-ack',b,op,'ACKED');link=r['association']
        h.check(link['kind']=='PUBLICATION_CHANNEL' and link['instance']==channel['instance'] and link['sequence']==1 and link['epoch']==1,'channel/epoch association from durable state')
        h.run('channel-association-compact',['compact','--control',str(b/'control.sock')]);bd.shutdown();bd=h.start('channel-association-restart',bc,b)
        h.check(query(h,'channel-link-rebuilt',b,op=op)['records'][0]['association']==link,'channel association survives checkpoint')
        bd.shutdown();ad.shutdown();cd.shutdown()
    case('native_source_subscription_and_publication_channel_associations',associations)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    try:run_cases(h,set(a.case) if a.case else None);ok=True
    except BaseException as exc:(h.output/'FAILURE.txt').write_text(f'{type(exc).__name__}: {exc}\n');print(f'FAIL: {type(exc).__name__}: {exc}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_OUTBOX_INSPECTION_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:(h.output/(name+'.json')).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
