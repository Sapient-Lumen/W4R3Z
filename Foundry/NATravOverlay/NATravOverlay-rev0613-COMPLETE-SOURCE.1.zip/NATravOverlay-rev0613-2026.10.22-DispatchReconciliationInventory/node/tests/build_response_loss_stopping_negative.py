#!/usr/bin/env python3
"""Prepare a weakened build that revokes committed stop intent on reply failure."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parents[2]
out = args.output.resolve()
if out.exists() or out == root or root in out.parents:
    parser.error("output must be a new path outside the product")
source = out / "source"
source.mkdir(parents=True)
for part in ("node/src", "foundation/src", "foundation/include"):
    shutil.copytree(root / part, source / part)
shutil.copy2(root / "node/build.sh", source / "node/build.sh")
path = source / "node/src/daemon.cpp"
text = path.read_text()
anchor = """    } catch (const std::exception&) {
        ++stats.control_errors;
        // Reply delivery is not part of stop acceptance. Once the authorized
"""
replacement = """    } catch (const std::exception&) {
        ++stats.control_errors;
        stop_intent_committed = false; // DELIBERATE NEGATIVE CONTROL
        // Reply delivery is not part of stop acceptance. Once the authorized
"""
if text.count(anchor) != 1:
    raise SystemExit("release response-loss boundary not found exactly once")
path.write_text(text.replace(anchor, replacement, 1))
patch = out / "NEGATIVE.patch"
patch.write_text(
    "--- release/node/src/daemon.cpp\n"
    "+++ weakened/node/src/daemon.cpp\n"
    "@@ response-write failure\n"
    "+        stop_intent_committed = false; // DELIBERATE NEGATIVE CONTROL\n"
)
print(json.dumps({"format": "NATRAV_OVERLAY_RESPONSE_LOSS_NEGATIVE_PREPARATION_V1", "status": "PREPARED_NOT_BUILT", "source": str(source), "patch": str(patch)}))
