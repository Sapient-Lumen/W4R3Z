#!/usr/bin/env python3
"""Revision 0613 explicit owner dispatch through the ordinary daemon control path."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import stat
import subprocess
import sys
import time
from typing import Any

from run_persistent import Harness, free_port, operation
from run_peer_sessions import submit, outbox_entry
from run_live_configuration import candidate, activate, rollback
from run_local_administration import (
    expose_control_for_uid, restore_owner_only_control, run_as_uid,
    wait_process_exit,
)
from run_runtime_adapter_configuration import upgrade, write
from run_handoff_key_policy import record as handoff_record
from run_explicit_two_hop_custody import (
    AR_RULE, RB_RULE, RULE_GENERATION, cert_sha256, grant, service_rule,
    policy_lines, route_file, service_root, service_cases, send_command,
    launch_server, finish_server, terminate_server, sha_file,
)

ZERO = "0" * 64
RECEIVER_ID = "r-passive"
DISPATCH_ID = "r-owner-dispatch"
PAUSE_AFTER_RESERVATION = (
    "NATRAV_OVERLAY_TEST_CUSTODY_SESSION_AFTER_DISPATCH_RESERVATION_MS"
)
PAUSE_BEFORE_ACCEPTANCE = (
    "NATRAV_OVERLAY_TEST_CUSTODY_SESSION_BEFORE_RECEIVER_ACCEPTANCE_PUBLICATION_MS"
)
DROP_AFTER_ADMISSION = "NATRAV_OVERLAY_TEST_SESSION_DROP_AFTER_ADMISSION_OPERATION"


def immutable_commitment(record: str, domain: str) -> str:
    lines = record.splitlines()
    assert lines and lines[-1].startswith("state=")
    return hashlib.sha256((domain + "\n" + "\n".join(lines[1:-1]) + "\n").encode("ascii")).hexdigest()


def rule_commitment(record: str) -> str:
    return immutable_commitment(record, "NATRAV_CUSTODY_SESSION_RULE_COMMITMENT_V1")


def receiver_record(rule: str, expiry_ms: int, state: str = "ACTIVE") -> str:
    return "\n".join([
        "NATRAV_CUSTODY_RECEIVER_ACTIVATION_V1",
        f"id={RECEIVER_ID}",
        "generation=1",
        f"predecessor_sha256={ZERO}",
        f"session_rule_id={AR_RULE}",
        f"session_rule_generation={RULE_GENERATION}",
        f"session_rule_commitment_sha256={rule_commitment(rule)}",
        "maximum_inflight_offers=1",
        f"activation_expires_unix_ms={expiry_ms}",
        f"state={state}",
        "",
    ])


def receiver_commitment(record: str) -> str:
    return immutable_commitment(record, "NATRAV_CUSTODY_RECEIVER_ACTIVATION_COMMITMENT_V1")


def route_commitment(peer: str, route_id: str, locator: str, priority: int) -> str:
    text = "\n".join([
        "NATRAV_CUSTODY_DISPATCH_ROUTE_COMMITMENT_V1",
        f"peer_node={peer}",
        f"route_id={route_id}",
        f"locator={locator}",
        f"priority={priority}",
        "state=ENABLED",
        "",
    ])
    return hashlib.sha256(text.encode("ascii")).hexdigest()


def dispatch_record(receiver: str, outbound_rule: str, *, b_port: int,
                    expiry_ms: int, state: str = "ACTIVE",
                    route_digest: str | None = None,
                    maximum_concurrent: int = 1,
                    maximum_attempts: int = 4,
                    identifier: str = DISPATCH_ID,
                    generation: int = 1,
                    predecessor: str = ZERO) -> str:
    return "\n".join([
        "NATRAV_CUSTODY_DISPATCH_ACTIVATION_V1",
        f"id={identifier}",
        f"generation={generation}",
        f"predecessor_sha256={predecessor}",
        f"receiver_activation_id={RECEIVER_ID}",
        "receiver_activation_generation=1",
        f"receiver_activation_commitment_sha256={receiver_commitment(receiver)}",
        f"outbound_session_rule_id={RB_RULE}",
        f"outbound_session_rule_generation={RULE_GENERATION}",
        f"outbound_session_rule_commitment_sha256={rule_commitment(outbound_rule)}",
        "route_id=default",
        "route_commitment_sha256=" + (route_digest or route_commitment(
            "B", "default", f"127.0.0.1:{b_port}", 0)),
        f"maximum_concurrent_dispatches={maximum_concurrent}",
        f"maximum_dispatch_attempts={maximum_attempts}",
        f"activation_expires_unix_ms={expiry_ms}",
        f"state={state}",
        "",
    ])


def policy_line(key: str, record: str) -> str:
    return f"{key}={record.encode('ascii').hex()}\n"


def with_v24(text: str, receiver: str, dispatch: str) -> str:
    lines = [line for line in text.splitlines()
             if not line.startswith("custody_receiver_hex=") and
                not line.startswith("custody_dispatch_hex=")]
    lines[0] = "NATRAV_OVERLAY_CONFIG_V24"
    return "\n".join(lines) + "\n" + \
        policy_line("custody_receiver_hex", receiver) + \
        policy_line("custody_dispatch_hex", dispatch)


def replace_dispatch(text: str, dispatch: str) -> str:
    lines = [line for line in text.splitlines()
             if not line.startswith("custody_dispatch_hex=")]
    return "\n".join(lines) + "\n" + policy_line("custody_dispatch_hex", dispatch)


def append_dispatch(text: str, dispatch: str) -> str:
    return text.rstrip("\n") + "\n" + policy_line("custody_dispatch_hex", dispatch)


def without_dispatch_v23(text: str) -> str:
    lines = [line for line in text.splitlines()
             if not line.startswith("custody_dispatch_hex=")]
    lines[0] = "NATRAV_OVERLAY_CONFIG_V23"
    return "\n".join(lines) + "\n"


CONTROL_ANNOTATION_FIELDS = {
    "request_id", "principal_uid", "principal_gid", "principal_pid",
    "command_class",
}


def control_payload(value: dict[str, Any]) -> dict[str, Any]:
    """Remove per-connection audit annotation from a durable result replay."""
    return {key: item for key, item in value.items()
            if key not in CONTROL_ANNOTATION_FIELDS}


def dispatch_command(state: Path, receiver_request: str,
                     dispatch_request: str, reason: str,
                     activation: str = DISPATCH_ID,
                     activation_generation: int = 1) -> list[str]:
    return [
        "custody-dispatch", "--control", str(state / "control.sock"),
        "--activation", activation,
        "--activation-generation", str(activation_generation),
        "--receiver-request", receiver_request,
        "--dispatch-request", dispatch_request,
        "--reason", reason,
        "--deadline-ms", "10000",
    ]


def dispatch_status_command(state: Path, dispatch_request: str,
                            activation: str = DISPATCH_ID,
                            activation_generation: int = 1) -> list[str]:
    return [
        "custody-dispatch-status", "--control", str(state / "control.sock"),
        "--activation", activation,
        "--activation-generation", str(activation_generation),
        "--dispatch-request", dispatch_request,
        "--deadline-ms", "10000",
    ]


def dispatch_inventory_command(state: Path, *, cursor: str | None = None,
                               limit: int = 32, maximum_bytes: int = 32768,
                               activation: str = DISPATCH_ID,
                               activation_generation: int = 1) -> list[str]:
    command = [
        "custody-dispatch-inventory", "--control", str(state / "control.sock"),
        "--activation", activation,
        "--activation-generation", str(activation_generation),
        "--limit", str(limit), "--max-bytes", str(maximum_bytes),
        "--deadline-ms", "10000",
    ]
    if cursor is not None:
        command += ["--cursor", cursor]
    return command


def stable_state_snapshot(state: Path) -> dict[str, tuple[Any, ...]]:
    """Capture durable bytes/metadata while ignoring access times and sockets."""
    result: dict[str, tuple[Any, ...]] = {}
    if not state.exists():
        return result
    for path in sorted([state, *state.rglob("*")], key=lambda item: str(item)):
        status = path.lstat()
        relative = "." if path == state else str(path.relative_to(state))
        mode = stat.S_IMODE(status.st_mode)
        common: tuple[Any, ...] = (
            mode, status.st_uid, status.st_gid, status.st_nlink,
            status.st_size, status.st_mtime_ns,
        )
        if stat.S_ISREG(status.st_mode):
            result[relative] = ("file", *common,
                                hashlib.sha256(path.read_bytes()).hexdigest())
        elif stat.S_ISDIR(status.st_mode):
            result[relative] = ("directory", *common)
        elif stat.S_ISLNK(status.st_mode):
            result[relative] = ("symlink", *common, os.readlink(path))
        # The live control socket is process state, not durable state.
    return result


def launch_command(h: Harness, label: str, args: list[str]) -> subprocess.Popen[str]:
    stdout = h.logs / f"{label}.stdout.txt"
    stderr = h.logs / f"{label}.stderr.txt"
    out = stdout.open("w")
    err = stderr.open("w")
    process = subprocess.Popen([str(h.binary), *args], text=True,
                               stdout=out, stderr=err, start_new_session=True)
    setattr(process, "_natrav_stdout_file", out)
    setattr(process, "_natrav_stderr_file", err)
    setattr(process, "_natrav_stdout_path", stdout)
    setattr(process, "_natrav_stderr_path", stderr)
    setattr(process, "_natrav_started", time.time())
    setattr(process, "_natrav_args", args)
    return process


def finish_command(h: Harness, label: str, process: subprocess.Popen[str],
                   timeout: float = 20.0) -> tuple[int, dict[str, Any] | None]:
    process.wait(timeout=timeout)
    getattr(process, "_natrav_stdout_file").close()
    getattr(process, "_natrav_stderr_file").close()
    stdout = Path(getattr(process, "_natrav_stdout_path")).read_text()
    stderr = Path(getattr(process, "_natrav_stderr_path")).read_text()
    h.commands.append({
        "label": label, "args": getattr(process, "_natrav_args"),
        "returncode": process.returncode, "stdout": stdout, "stderr": stderr,
        "elapsed_seconds": time.time() - getattr(process, "_natrav_started"),
    })
    lines = [line for line in stdout.splitlines() if line.strip()]
    result = json.loads(lines[-1]) if lines else None
    assert process.returncode is not None
    return process.returncode, result


def suite(h: Harness) -> None:
    h.work.chmod(0o700)
    v: dict[str, Any] = {}

    def initialize_and_policy_validation() -> None:
        version = h.run("version", ["version"])
        h.check(version is not None and version["version"] == "0613",
                "revision 0613 identity")
        h.check(version["custody_dispatch_policy"] ==
                "V24_EXPLICIT_OWNER_CUSTODY_DISPATCH_V1" and
                version["explicit_owner_custody_dispatch"] is True and
                version["automatic_custody_sender"] is False and
                version["automatic_route_relay"] is False,
                "V24 is explicit and does not create an automatic sender")

        ports = {node: free_port() for node in ("A", "R", "B")}
        dead = {name: free_port() for name in ("AR", "RB", "AB")}
        states = {node: h.runtime / node.lower() for node in ("A", "R", "B")}
        configs = {
            "A": h.config("a-seed", "A", states["A"], ports["A"],
                          [("R", ports["R"], 50, 250, 16, 600_000),
                           ("B", dead["AB"], 50, 250, 16, 600_000)],
                          deadline_ms=5_000, trusted=["R", "B"]),
            "R": h.config("r-seed", "R", states["R"], ports["R"],
                          [("A", ports["A"], 50, 250, 16, 600_000),
                           ("B", ports["B"], 50, 250, 16, 600_000)],
                          deadline_ms=5_000, trusted=["A", "B"]),
            "B": h.config("b-seed", "B", states["B"], ports["B"],
                          [("R", ports["R"], 50, 250, 16, 600_000),
                           ("A", dead["AB"], 50, 250, 16, 600_000)],
                          deadline_ms=5_000, trusted=["A", "R"]),
        }
        for node, config in configs.items():
            write(config, upgrade(config.read_text(), f"{node.lower()}-v19", 19))
            daemon = h.start(f"initialize-{node}", config, states[node])
            daemon.shutdown()

        operations: dict[str, str] = {}
        a = h.start("queue-A", configs["A"], states["A"])
        for name in ("normal", "loss", "crash", "concurrent", "lifecycle"):
            op = operation(f"rev0613-owner-dispatch-{name}")
            operations[name] = op
            submit(h, f"queue-{name}", a.control, "A", "B", "test/three",
                   op, f"rev0613 owner dispatch {name}")
        a.shutdown()

        bindings: dict[str, bytes] = {}
        keys: dict[str, Path] = {}
        for node in ("A", "R", "B"):
            key = h.work / f"{node.lower()}-handoff"
            result = h.run(f"handoff-key-{node}", [
                "handoff-key-init", "--config", str(configs[node]),
                "--key-directory", str(key), "--generation", f"{node.lower()}-h1",
            ])
            binding = (key / "binding.nhkb").read_bytes()
            h.check(result is not None and result["binding_sha256"] ==
                    hashlib.sha256(binding).hexdigest(),
                    f"{node} exact handoff binding")
            bindings[node] = binding
            keys[node] = key

        grants = {
            "AR": grant(identifier="a-r", origin="A", final="B",
                        custodian="A", next_hop="R"),
            "RB": grant(identifier="r-b", origin="A", final="B",
                        custodian="R", next_hop="B"),
        }
        certs = {node: cert_sha256(h.identity(node).certificate)
                 for node in ("A", "R", "B")}
        authority_expiry = int(time.time() * 1000) + 900_000
        rules = {
            "AR": service_rule(identifier=AR_RULE, relay_grant=grants["AR"],
                               custodian_certificate=certs["A"],
                               next_hop_certificate=certs["R"],
                               maximum_attempts=4,
                               expiry_ms=authority_expiry),
            "RB": service_rule(identifier=RB_RULE, relay_grant=grants["RB"],
                               custodian_certificate=certs["R"],
                               next_hop_certificate=certs["B"],
                               maximum_attempts=4,
                               expiry_ms=authority_expiry),
        }
        all_bindings = [bindings[node] for node in ("A", "R", "B")]
        for node in ("A", "R", "B"):
            local_rules = ([rules["AR"]] if node == "A" else
                           [rules["RB"]] if node == "B" else
                           [rules["AR"], rules["RB"]])
            records = policy_lines(all_bindings, list(grants.values()), local_rules)

            def modify(text: str, *, node: str = node, records: str = records) -> str:
                extra = ""
                if node == "A":
                    extra = f"peer_route=R,dead,1,ENABLED,127.0.0.1:{dead['AR']}\n"
                elif node == "R":
                    extra = f"peer_route=B,dead,1,ENABLED,127.0.0.1:{dead['RB']}\n"
                return text.replace("CONFIG_V19", "CONFIG_V22") + extra + records

            v22 = candidate(h, configs[node], f"{node.lower()}-v22",
                            f"{node.lower()}-v22", modify)
            checked = h.run(f"check-{node}-v22", [
                "config-check", "--config", str(v22)])
            h.check(checked is not None and
                    checked["format"] == "NATRAV_OVERLAY_CONFIG_V22",
                    f"{node} V22 authority accepted")
            daemon = h.start(f"activate-{node}-v22", configs[node], states[node])
            activate(h, f"activate-{node}-v22", states[node], v22)
            daemon.shutdown()
            v[f"{node}v22"] = v22

        receiver_expiry = authority_expiry - 2_000
        dispatch_expiry = authority_expiry - 3_000
        receiver = receiver_record(rules["AR"], receiver_expiry)
        dispatch = dispatch_record(receiver, rules["RB"], b_port=ports["B"],
                                   expiry_ms=dispatch_expiry)
        r_v24 = candidate(h, v["Rv22"], "r-v24-active", "r-v24-active",
                          lambda text: with_v24(text, receiver, dispatch))
        checked = h.run("check-r-v24", ["config-check", "--config", str(r_v24)])
        h.check(checked is not None and
                checked["format"] == "NATRAV_OVERLAY_CONFIG_V24" and
                checked["custody_dispatch_policy"]["activations"][0]["state"] == "ACTIVE",
                "canonical V24 activation is inspectable")

        old_header = candidate(h, v["Rv22"], "v24-in-v23", "v24-in-v23",
            lambda text: text.replace("CONFIG_V22", "CONFIG_V23", 1) +
                policy_line("custody_receiver_hex", receiver) +
                policy_line("custody_dispatch_hex", dispatch))
        rejected = h.run("v24-in-v23", ["config-check", "--config", str(old_header)], expected=3)
        h.check(rejected is not None and rejected["code"] == "CONFIG_VERSION_REJECTED",
                "V24 activation cannot enter an older format")

        wrong_route = dispatch_record(receiver, rules["RB"], b_port=ports["B"],
                                      expiry_ms=dispatch_expiry,
                                      route_digest="11" * 32)
        wrong = candidate(h, v["Rv22"], "v24-wrong-route", "v24-wrong-route",
                          lambda text: with_v24(text, receiver, wrong_route))
        rejected = h.run("v24-wrong-route", ["config-check", "--config", str(wrong)], expected=3)
        h.check(rejected is not None and rejected["code"] == "CONFIG_CUSTODY_DISPATCH_ROUTE",
                "V24 commits the exact enabled route")

        unfair_dispatch = dispatch_record(receiver, rules["RB"], b_port=ports["B"],
                                           expiry_ms=dispatch_expiry,
                                           maximum_concurrent=2)
        unfair = candidate(h, v["Rv22"], "v24-unfair", "v24-unfair",
                           lambda text: with_v24(text, receiver, unfair_dispatch))
        rejected = h.run("v24-unfair", ["config-check", "--config", str(unfair)], expected=3)
        h.check(rejected is not None and rejected["code"] == "CONFIG_CUSTODY_DISPATCH_FAIRNESS",
                "V24 reserves an ordinary control worker")

        daemon = h.start("activate-r-v24", configs["R"], states["R"])
        activate(h, "activate-r-v24", states["R"], r_v24)
        daemon.shutdown()

        route = route_file(h.work / "a-r-b-route.txt", all_bindings)
        bundles: dict[str, Path] = {}
        for name, op in operations.items():
            capsule = h.work / f"{name}.nhcp"
            exported = h.run(f"handoff-export-{name}", [
                "handoff-export", "--config", str(configs["A"]),
                "--key-directory", str(keys["A"]),
                "--recipient-binding", str(keys["B"] / "binding.nhkb"),
                "--recipient-binding-sha256", sha_file(keys["B"] / "binding.nhkb"),
                "--operation-id", op, "--kind", "operation",
                "--expires-ms", str(int(time.time() * 1000) + 500_000),
                "--output", str(capsule),
            ])
            h.check(exported is not None and exported["status"] == "EXPORTED_NOT_DELIVERED",
                    f"{name} handoff export remains not delivered")
            bundle = h.work / f"{name}.nhcb"
            now = int(time.time() * 1000)
            created = h.run(f"custody-create-{name}", [
                "custody-create", "--config", str(configs["A"]),
                "--route", str(route), "--capsule", str(capsule),
                "--created-ms", str(now), "--expires-ms", str(now + 420_000),
                "--output", str(bundle),
            ])
            h.check(created is not None and created["status"] == "CREATED_CUSTODY_HELD",
                    f"{name} two-hop bundle created")
            bundles[name] = bundle

        v.update({"ports": ports, "dead": dead, "states": states,
                  "configs": configs, "operations": operations,
                  "bindings": bindings, "keys": keys, "grants": grants,
                  "rules": rules, "authority_expiry": authority_expiry,
                  "receiver_expiry": receiver_expiry,
                  "dispatch_expiry": dispatch_expiry,
                  "receiver": receiver, "dispatch": dispatch,
                  "r_v24": r_v24, "bundles": bundles})

    h.case("accepted_v24_policy_and_negative_controls", initialize_and_policy_validation)

    def start_r(label: str, environment: dict[str, str] | None = None):
        return h.start(label, v["configs"]["R"], v["states"]["R"], environment)

    def first_hop(harness_label: str, name: str) -> dict[str, Any]:
        result = h.run(harness_label, send_command(
            v["configs"]["A"], AR_RULE, v["bundles"][name]), timeout=20)
        h.check(result is not None and result["status"] == "ACCEPTED",
                f"{name} first hop accepted by passive daemon")
        return result

    def explicit_dispatch_and_duplicate_recovery() -> None:
        r = start_r("owner-dispatch-normal-r")
        b = launch_server(h, "owner-dispatch-normal-b", v["configs"]["B"], RB_RULE,
                          once="no")
        first = first_hop("owner-dispatch-normal-first", "normal")
        time.sleep(0.2)
        h.check(b.poll() is None and len(service_cases(v["states"]["R"], RB_RULE)) == 0,
                "first-hop acceptance creates no automatic second-hop case or connection")
        dispatch_request = operation("rev0613-owner-dispatch-normal-control")
        result = h.run("owner-dispatch-normal", dispatch_command(
            v["states"]["R"], first["request_id"], dispatch_request,
            "explicit normal owner dispatch"), timeout=20)
        h.check(result is not None and result["format"] == "NATRAV_OWNER_CUSTODY_DISPATCH_V1" and
                result["new_outbound_attempt_committed"] is True and
                result["custody_result"]["status"] == "ACCEPTED" and
                result["automatic_retry"] is False and
                result["automatic_route_relay"] is False,
                "one explicit control request commits one accepted NOS1 attempt")
        rc, out, err = terminate_server(b)
        h.check(rc == 0 and '"accepted_connections":1' in out,
                f"B observed exactly the explicit connection: {out!r} {err!r}")
        rb_cases = service_cases(v["states"]["R"], RB_RULE)
        h.check(len(rb_cases) == 1,
                "explicit dispatch creates one outbound custody case")
        retained_result_path = (rb_cases[0] / "dispatches" /
                                f"{dispatch_request}.result")
        retained_before = retained_result_path.read_bytes()
        duplicate = h.run("owner-dispatch-normal-duplicate", dispatch_command(
            v["states"]["R"], first["request_id"], dispatch_request,
            "explicit normal owner dispatch"), timeout=20)
        h.check(control_payload(duplicate) == control_payload(result) and
                duplicate["new_outbound_attempt_committed"] is True and
                retained_result_path.read_bytes() == retained_before,
                "duplicate request replays the byte-identical durable result without a second connection")
        # The retained result records whether the original request committed an
        # attempt; exact replay intentionally does not rewrite that evidence.
        h.check((rb_cases[0] / "attempts").read_text().strip() == "1" and
                (rb_cases[0] / "dispatches" / f"{dispatch_request}.record").is_file(),
                "duplicate control request leaves one attempt and one durable dispatch record")
        conflict = h.run("owner-dispatch-id-conflict", dispatch_command(
            v["states"]["R"], first["request_id"], dispatch_request,
            "different reason"), expected=3)
        h.check(conflict is not None and conflict["code"] == "CUSTODY_DISPATCH_ID_REUSE_CONFLICT",
                "dispatch request ID cannot be rebound to different bytes")
        r.shutdown()

    h.case("explicit_dispatch_duplicate_and_no_auto_forward",
           explicit_dispatch_and_duplicate_recovery)

    def response_loss_requires_fresh_owner_request() -> None:
        r = start_r("owner-dispatch-loss-r")
        first = first_hop("owner-dispatch-loss-first", "loss")
        request_one = operation("rev0613-owner-dispatch-loss-one")
        unavailable = h.run("owner-dispatch-loss-unavailable", dispatch_command(
            v["states"]["R"], first["request_id"], request_one,
            "first explicit attempt while B unavailable"), timeout=20)
        h.check(unavailable is not None and
                unavailable["custody_result"]["status"] == "UNRESOLVED" and
                unavailable["custody_result"]["attempts"] == 1 and
                unavailable["new_outbound_attempt_committed"] is True,
                "carrier failure remains unresolved after one committed owner attempt")
        outbound_request = unavailable["outbound_request_id"]

        request_two = operation("rev0613-owner-dispatch-loss-two")
        drop = launch_server(h, "owner-dispatch-loss-drop-b", v["configs"]["B"], RB_RULE,
                             {DROP_AFTER_ADMISSION: outbound_request})
        lost = h.run("owner-dispatch-loss-dropped", dispatch_command(
            v["states"]["R"], first["request_id"], request_two,
            "fresh explicit attempt with dropped response"), timeout=20)
        rc, out, err = finish_server(drop)
        h.check(rc == 3 and lost is not None and
                lost["custody_result"]["status"] == "UNRESOLVED" and
                lost["custody_result"]["attempts"] == 2 and
                lost["new_outbound_attempt_committed"] is True,
                f"lost peer response stays unresolved: {out!r} {err!r}")

        idle = launch_server(h, "owner-dispatch-loss-no-retry-b", v["configs"]["B"], RB_RULE,
                             once="no")
        same = h.run("owner-dispatch-loss-same-request", dispatch_command(
            v["states"]["R"], first["request_id"], request_two,
            "fresh explicit attempt with dropped response"), timeout=20)
        time.sleep(0.2)
        rc, out, err = terminate_server(idle)
        h.check(control_payload(same) == control_payload(lost) and
                rc == 0 and '"accepted_connections":0' in out,
                f"duplicate owner request cannot perform a hidden retry: {out!r} {err!r}")

        request_three = operation("rev0613-owner-dispatch-loss-three")
        replay = launch_server(h, "owner-dispatch-loss-replay-b", v["configs"]["B"], RB_RULE)
        recovered = h.run("owner-dispatch-loss-fresh-request", dispatch_command(
            v["states"]["R"], first["request_id"], request_three,
            "third fresh explicit owner attempt"), timeout=20)
        rc, out, err = finish_server(replay)
        h.check(rc == 0 and recovered is not None and
                recovered["custody_result"]["status"] == "ACCEPTED" and
                recovered["custody_result"]["attempts"] == 3 and
                recovered["outbound_request_id"] == outbound_request,
                f"only a fresh owner request performs the next attempt: {out!r} {err!r}")
        r.shutdown()

    h.case("response_loss_needs_fresh_owner_request",
           response_loss_requires_fresh_owner_request)

    def reservation_process_death_and_stale_seed() -> None:
        r = start_r("owner-dispatch-crash-r", {PAUSE_AFTER_RESERVATION: "30000"})
        first = first_hop("owner-dispatch-crash-first", "crash")
        dispatch_request = operation("rev0613-owner-dispatch-crash-control")
        args = dispatch_command(v["states"]["R"], first["request_id"],
                                dispatch_request, "reservation crash")
        client = launch_command(h, "owner-dispatch-crash-client", args)
        h.wait("daemon reaches durable dispatch reservation", lambda:
               PAUSE_AFTER_RESERVATION in r.stderr_path.read_text(), 10)
        r.kill()
        rc, _ = finish_command(h, "owner-dispatch-crash-client", client, 20)
        h.check(rc != 0, "control response loss cannot manufacture success")

        r = start_r("owner-dispatch-crash-restart")
        status = h.status("owner-dispatch-crash-stale-seed", v["states"]["R"])
        h.check(status["runtime_configuration"]["generation"] == "r-v24-active",
                "stale startup seed reconstructs accepted V24 authority")
        idle = launch_server(h, "owner-dispatch-crash-idle-b", v["configs"]["B"], RB_RULE,
                             once="no")
        recovered = h.run("owner-dispatch-crash-recover", args, timeout=20)
        time.sleep(0.2)
        rc, out, err = terminate_server(idle)
        h.check(recovered is not None and
                recovered["custody_result"]["status"] ==
                    "UNRESOLVED_OWNER_DISPATCH_RECOVERED" and
                recovered["new_outbound_attempt_committed"] is False and
                rc == 0 and '"accepted_connections":0' in out,
                f"restart recovers reservation without a network attempt: {out!r} {err!r}")
        rb_cases = service_cases(v["states"]["R"], RB_RULE)
        crash_case = next(path for path in rb_cases
                          if (path / "dispatches" / f"{dispatch_request}.record").exists())
        h.check((crash_case / "attempts").read_text().strip() == "1" and
                not (crash_case / "acceptance.bin").exists(),
                "reservation recovery preserves one finite unresolved attempt")
        r.shutdown()

    h.case("process_death_after_dispatch_reservation_and_stale_seed",
           reservation_process_death_and_stale_seed)

    def reconciliation_status_inventory_and_fail_closed() -> None:
        state = v["states"]["R"]
        r = start_r("dispatch-reconciliation-r")
        missing_id = operation("rev0613-dispatch-reconciliation-missing")

        durable_before = stable_state_snapshot(state)
        missing = h.run("dispatch-status-not-found", dispatch_status_command(
            state, missing_id))
        h.check(missing is not None and
                missing["format"] == "NATRAV_CUSTODY_DISPATCH_STATUS_V1" and
                missing["status"] == "NOT_FOUND" and
                missing["record"] is None and
                missing["repair_performed"] is False and
                missing["network_attempted"] is False and
                missing["filesystem_mutated"] is False and
                missing["application_delivery_inferred"] is False,
                "exact missing status is bounded read-only metadata")

        index_directory = service_root(state, RB_RULE) / "dispatch-index"
        indexed = sorted(path.name for path in index_directory.iterdir())
        h.check(len(indexed) >= 5 and len(indexed) == len(set(indexed)),
                "retained owner requests provide a finite canonical dispatch index")
        observed: list[str] = []
        cursor: str | None = None
        page_number = 0
        while True:
            page_number += 1
            h.check(page_number <= len(indexed) + 1,
                    "cursor pagination terminates within the retained index bound")
            page = h.run(f"dispatch-inventory-page-{page_number}",
                         dispatch_inventory_command(
                             state, cursor=cursor, limit=1,
                             maximum_bytes=4096))
            h.check(page is not None and
                    page["format"] == "NATRAV_CUSTODY_DISPATCH_INVENTORY_V1" and
                    page["returned"] == len(page["records"]) and
                    page["returned"] <= 1 and
                    page["repair_performed"] is False and
                    page["network_attempted"] is False and
                    page["filesystem_mutated"] is False and
                    page["application_delivery_inferred"] is False,
                    "each inventory page is finite and explicitly observational")
            for record in page["records"]:
                h.check(record["dispatch_request_id"] not in observed and
                        record["network_attempted"] is False and
                        record["filesystem_mutated"] is False and
                        record["remote_acceptance_replayed"] is False and
                        record["application_delivery_inferred"] is False and
                        "acceptance_bytes" not in record and
                        "acceptance_hex" not in record and
                        "custody_result" not in record,
                        "inventory exposes commitments and state, never acceptance or result bytes")
                observed.append(record["dispatch_request_id"])
            if not page["more"]:
                h.check(page["next_cursor"] ==
                        (observed[-1] if observed else None),
                        "terminal inventory page returns its exact last cursor")
                break
            h.check(page["next_cursor"] is not None and
                    page["next_cursor"] != cursor,
                    "nonterminal inventory page advances a canonical cursor")
            cursor = page["next_cursor"]
        h.check(observed == indexed,
                "lexicographic cursor inventory returns every exact dispatch identity once")

        for dispatch_id in observed:
            status = h.run(f"dispatch-status-{dispatch_id[:12]}",
                           dispatch_status_command(state, dispatch_id))
            h.check(status is not None and status["status"] == "RECORDED" and
                    status["record"]["dispatch_request_id"] == dispatch_id and
                    status["record"]["network_attempted"] is False and
                    status["record"]["filesystem_mutated"] is False and
                    status["record"]["remote_acceptance_replayed"] is False,
                    "exact status resolves one authenticated index-record-case chain")
        h.check(stable_state_snapshot(state) == durable_before,
                "status and complete inventory make no durable filesystem mutation")

        idle = launch_server(h, "dispatch-reconciliation-zero-network-b",
                             v["configs"]["B"], RB_RULE, once="no")
        network_before = stable_state_snapshot(state)
        h.run("dispatch-status-zero-network",
              dispatch_status_command(state, observed[0]))
        h.run("dispatch-inventory-zero-network",
              dispatch_inventory_command(state, limit=2,
                                         maximum_bytes=8192))
        h.check(stable_state_snapshot(state) == network_before,
                "observation remains byte-and-metadata stable with a reachable carrier")
        time.sleep(0.2)
        rc, out, err = terminate_server(idle)
        h.check(rc == 0 and '"accepted_connections":0' in out,
                f"status and inventory open no NOS1 connection: {out!r} {err!r}")

        r.shutdown()
        r = start_r("dispatch-reconciliation-restart-r")
        restarted = h.run("dispatch-status-after-restart",
                          dispatch_status_command(state, observed[0]))
        h.check(restarted is not None and restarted["status"] == "RECORDED" and
                restarted["record"]["dispatch_request_id"] == observed[0],
                "stale-seed restart reconstructs current V24 authority for observation")

        expose_control_for_uid(state)
        try:
            denied = run_as_uid(
                h, "dispatch-status-unauthorized", 65534, 65534,
                dispatch_status_command(state, observed[0]), expected=3)
            h.check(denied is not None and denied["code"] in {
                        "LOCAL_CONTROL_UID_DENIED", "LOCAL_CONTROL_CLASS_DENIED"},
                    "kernel-authenticated unlisted UID cannot reconcile custody state")
        finally:
            restore_owner_only_control(state)

        h.run("dispatch-reconciliation-quiesce", [
            "quiesce", "--control", str(state / "control.sock"),
            "--reason", "read-only reconciliation while quiesced",
            "--deadline-ms", "3000",
        ])
        quiesced_status = h.run(
            "dispatch-status-quiesced",
            dispatch_status_command(state, observed[0]))
        quiesced_inventory = h.run(
            "dispatch-inventory-quiesced",
            dispatch_inventory_command(state, limit=2, maximum_bytes=8192))
        h.check(quiesced_status is not None and
                quiesced_status["status"] == "RECORDED" and
                quiesced_inventory is not None and
                quiesced_inventory["returned"] == 2,
                "quiescence preserves bounded owner reconciliation")
        h.run("dispatch-reconciliation-resume", [
            "resume", "--control", str(state / "control.sock"),
            "--reason", "reconciliation verified",
            "--deadline-ms", "3000",
        ])

        # Every malformed or conflicting index entry fails the entire bounded
        # inventory, including corruption lexically beyond the requested page.
        index_paths = sorted(index_directory.iterdir())
        original = {path.name: path.read_bytes() for path in index_paths}
        selected = index_paths[0]
        selected.write_text(ZERO + "\n")
        malformed = h.run("dispatch-status-zero-index",
                          dispatch_status_command(state, selected.name),
                          expected=3)
        h.check(malformed is not None and
                malformed["code"] == "CUSTODY_DISPATCH_STATE_REJECTED",
                "zero outbound request in an exact index fails closed")
        selected.write_bytes(original[selected.name])

        conflicting_pair: tuple[Path, Path] | None = None
        for left in index_paths:
            for right in index_paths:
                if original[left.name] != original[right.name]:
                    conflicting_pair = (left, right)
                    break
            if conflicting_pair is not None:
                break
        h.check(conflicting_pair is not None,
                "fixture contains distinct V22 cases for conflict testing")
        assert conflicting_pair is not None
        left, right = conflicting_pair
        left.write_bytes(original[right.name])
        conflict = h.run("dispatch-status-conflicting-index",
                         dispatch_status_command(state, left.name), expected=3)
        h.check(conflict is not None and
                conflict["code"] == "CUSTODY_DISPATCH_STATE_REJECTED",
                "index-to-record-to-case conflict fails closed")
        left.write_bytes(original[left.name])

        symlink_id = operation("rev0613-dispatch-index-symlink")
        symlink_path = index_directory / symlink_id
        symlink_path.symlink_to(selected.name)
        try:
            rejected = h.run("dispatch-inventory-symlink",
                             dispatch_inventory_command(
                                 state, limit=1, maximum_bytes=4096),
                             expected=3)
            h.check(rejected is not None and
                    rejected["code"] == "CUSTODY_DISPATCH_STATE_REJECTED",
                    "inventory rejects a symlink entry before cursor paging")
        finally:
            symlink_path.unlink(missing_ok=True)
        restored_page = h.run("dispatch-inventory-restored",
                              dispatch_inventory_command(
                                  state, limit=1, maximum_bytes=4096))
        h.check(restored_page is not None and restored_page["returned"] == 1,
                "restored exact index remains observable after fail-closed checks")

        r.shutdown()
        r = start_r("dispatch-reconciliation-drain-r", {
            "NATRAV_OVERLAY_TEST_DRAIN_AFTER_START_MS": "3000",
        })
        drain = launch_command(h, "dispatch-reconciliation-drain-client", [
            "drain-shutdown", "--control", str(state / "control.sock"),
            "--reason", "bounded reconciliation drain test",
            "--drain-deadline-ms", "1000", "--deadline-ms", "8000",
        ])
        h.wait("daemon publishes DRAINING before reconciliation", lambda:
               h.status("dispatch-reconciliation-draining-status", state,
                        logical_digest=False)["lifecycle"]["mode"] == "DRAINING", 5)
        drain_before = stable_state_snapshot(state)
        draining_status = h.run(
            "dispatch-status-draining",
            dispatch_status_command(state, observed[0]))
        draining_inventory = h.run(
            "dispatch-inventory-draining",
            dispatch_inventory_command(state, limit=1, maximum_bytes=4096))
        h.check(draining_status is not None and
                draining_status["status"] == "RECORDED" and
                draining_inventory is not None and
                draining_inventory["returned"] == 1,
                "DRAINING accepts exact status and finite inventory as observations")
        h.check(stable_state_snapshot(state) == drain_before,
                "draining reconciliation makes no additional durable mutation")
        rc, drained = finish_command(
            h, "dispatch-reconciliation-drain-client", drain, 10)
        h.check(rc == 0 and drained is not None and
                drained["format"] == "NATRAV_OVERLAY_CONTROL_DRAIN_SHUTDOWN_V1",
                "bounded drain completes after observation")
        wait_process_exit(h, r, "dispatch reconciliation drain")

    h.case("read_only_status_inventory_authorization_restart_and_drain",
           reconciliation_status_inventory_and_fail_closed)

    def concurrent_application_progress_and_lifecycle() -> None:
        r = start_r("owner-dispatch-concurrent-r")
        first = first_hop("owner-dispatch-concurrent-first", "concurrent")
        b = launch_server(h, "owner-dispatch-concurrent-b", v["configs"]["B"], RB_RULE,
                          {PAUSE_BEFORE_ACCEPTANCE: "1200"})
        dispatch_request = operation("rev0613-owner-dispatch-concurrent-control")
        process = launch_command(h, "owner-dispatch-concurrent-client",
                                 dispatch_command(v["states"]["R"], first["request_id"],
                                                  dispatch_request,
                                                  "concurrent explicit dispatch"))
        assert b.stderr is not None
        observed = ""
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            ready, _, _ = select.select([b.stderr], [], [], 0.1)
            if ready:
                observed += b.stderr.readline()
                if PAUSE_BEFORE_ACCEPTANCE in observed:
                    break
        else:
            raise AssertionError("B did not reach the dispatch acceptance pause")

        a = h.start("owner-dispatch-concurrent-a", v["configs"]["A"], v["states"]["A"])
        ordinary = operation("rev0613-owner-dispatch-ordinary-progress")
        submit(h, "owner-dispatch-ordinary-submit", a.control, "A", "R",
               "test/three", ordinary, "ordinary traffic during custody dispatch")
        h.wait("ordinary application traffic progresses during dispatch", lambda:
               outbox_entry(h.status("owner-dispatch-ordinary-status",
                                     v["states"]["A"]), ordinary)["status"] == "ACKED", 8)
        a.shutdown()
        rc, result = finish_command(h, "owner-dispatch-concurrent-client", process, 20)
        remaining_out, remaining_err = b.communicate(timeout=10)
        complete_out = getattr(b, "_natrav_ready", "") + remaining_out
        Path(getattr(b, "_natrav_stdout_path")).write_text(complete_out)
        Path(getattr(b, "_natrav_stderr_path")).write_text(observed + remaining_err)
        h.check(rc == 0 and result is not None and
                result["custody_result"]["status"] == "ACCEPTED" and
                b.returncode == 0,
                "bounded explicit dispatch does not block ordinary peer progress")

        lifecycle_first = first_hop("owner-dispatch-lifecycle-first", "lifecycle")
        lifecycle_request = operation("rev0613-owner-dispatch-lifecycle-control")
        accept = launch_server(h, "owner-dispatch-lifecycle-b", v["configs"]["B"], RB_RULE)
        accepted = h.run("owner-dispatch-lifecycle-active", dispatch_command(
            v["states"]["R"], lifecycle_first["request_id"], lifecycle_request,
            "lifecycle accepted request"), timeout=20)
        finish_server(accept)
        h.check(accepted is not None and accepted["custody_result"]["status"] == "ACCEPTED",
                "active V24 dispatch accepted before retirement")
        active_status = h.run(
            "dispatch-status-active-lifecycle",
            dispatch_status_command(v["states"]["R"], lifecycle_request))
        h.check(active_status is not None and
                active_status["activation_state"] == "ACTIVE" and
                active_status["activation_expired"] is False and
                active_status["record"]["result_retained"] is True and
                active_status["record"]["acceptance_retained"] is True,
                "ACTIVE reconciliation reports exact durable result and acceptance commitments")

        retired_record = dispatch_record(v["receiver"], v["rules"]["RB"],
                                         b_port=v["ports"]["B"],
                                         expiry_ms=v["dispatch_expiry"], state="RETIRED")
        retired = candidate(h, v["r_v24"], "r-v24-retired", "r-v24-retired",
                            lambda text: replace_dispatch(text, retired_record))
        activate(h, "activate-r-v24-retired", v["states"]["R"], retired)
        replayed = h.run("owner-dispatch-retired-replay", dispatch_command(
            v["states"]["R"], lifecycle_first["request_id"], lifecycle_request,
            "lifecycle accepted request"), timeout=20)
        h.check(control_payload(replayed) == control_payload(accepted),
                "RETIRED returns only the exact retained owner-dispatch result")
        retired_status = h.run(
            "dispatch-status-retired-lifecycle",
            dispatch_status_command(v["states"]["R"], lifecycle_request))
        h.check(retired_status is not None and
                retired_status["activation_state"] == "RETIRED" and
                retired_status["record"]["result_retained"] is True and
                retired_status["record"]["acceptance_retained"] is True and
                retired_status["record"]["remote_acceptance_replayed"] is False,
                "RETIRED reconciliation observes commitments without replaying acceptance")
        denied = h.run("owner-dispatch-retired-new", dispatch_command(
            v["states"]["R"], lifecycle_first["request_id"],
            operation("rev0613-owner-dispatch-retired-new"),
            "retired new request"), expected=3)
        h.check(denied is not None and denied["code"] == "CUSTODY_DISPATCH_RETIRED",
                "RETIRED permits no new owner dispatch")

        revoked_record = dispatch_record(v["receiver"], v["rules"]["RB"],
                                         b_port=v["ports"]["B"],
                                         expiry_ms=v["dispatch_expiry"], state="REVOKED")
        revoked = candidate(h, retired, "r-v24-revoked", "r-v24-revoked",
                            lambda text: replace_dispatch(text, revoked_record))
        activate(h, "activate-r-v24-revoked", v["states"]["R"], revoked)
        denied = h.run("owner-dispatch-revoked-replay", dispatch_command(
            v["states"]["R"], lifecycle_first["request_id"], lifecycle_request,
            "lifecycle accepted request"), expected=3)
        h.check(denied is not None and denied["code"] == "CUSTODY_DISPATCH_REVOKED",
                "REVOKED permits neither attempt nor retained result replay")
        revoked_status = h.run(
            "dispatch-status-revoked-lifecycle",
            dispatch_status_command(v["states"]["R"], lifecycle_request))
        h.check(revoked_status is not None and
                revoked_status["activation_state"] == "REVOKED" and
                revoked_status["record"]["revoked_metadata_only"] is True and
                revoked_status["record"]["remote_acceptance_replayed"] is False and
                revoked_status["record"]["acceptance_retained"] is True and
                "acceptance_bytes" not in revoked_status["record"] and
                "custody_result" not in revoked_status["record"],
                "REVOKED exposes bounded metadata but never remote acceptance bytes or replay")
        revoked_inventory = h.run(
            "dispatch-inventory-revoked-lifecycle",
            dispatch_inventory_command(v["states"]["R"], limit=64,
                                       maximum_bytes=60000))
        h.check(revoked_inventory is not None and
                revoked_inventory["activation_state"] == "REVOKED" and
                all(row["revoked_metadata_only"] is True and
                    row["remote_acceptance_replayed"] is False
                    for row in revoked_inventory["records"]),
                "REVOKED inventory remains metadata-only for every retained request")
        rollback(h, "owner-dispatch-reactivation-rejected", v["states"]["R"],
                 "r-v24-active", expected=3,
                 code="CONFIG_CUSTODY_DISPATCH_STATE_ROLLBACK")
        downgrade = candidate(h, revoked, "r-v23-downgrade", "r-v23-downgrade",
                              without_dispatch_v23)
        activate(h, "owner-dispatch-v23-downgrade-rejected", v["states"]["R"],
                 downgrade, expected=3, code="CONFIG_CUSTODY_DISPATCH_DOWNGRADE")

        expired_id = "r-owner-dispatch-expired"
        expired_record = dispatch_record(
            v["receiver"], v["rules"]["RB"], b_port=v["ports"]["B"],
            expiry_ms=max(1, int(time.time() * 1000) - 1),
            identifier=expired_id)
        expired = candidate(
            h, revoked, "r-v24-expired-observer", "r-v24-expired-observer",
            lambda text: append_dispatch(text, expired_record))
        activate(h, "activate-r-v24-expired-observer", v["states"]["R"], expired)
        expired_status = h.run(
            "dispatch-status-expired-authority",
            dispatch_status_command(
                v["states"]["R"], operation("rev0613-expired-not-found"),
                activation=expired_id))
        h.check(expired_status is not None and
                expired_status["activation_state"] == "ACTIVE" and
                expired_status["activation_expired"] is True and
                expired_status["status"] == "NOT_FOUND" and
                expired_status["network_attempted"] is False and
                expired_status["filesystem_mutated"] is False,
                "expired V24 remains read-only observable without granting a new attempt")
        r.shutdown()

    h.case("concurrent_application_progress_and_monotonic_lifecycle",
           concurrent_application_progress_and_lifecycle)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not exist")
    h = Harness(args.binary, args.output)
    started = time.monotonic()
    code = 1
    try:
        suite(h)
        code = 0
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
    finally:
        h.cleanup()
        report = {
            "format": "NATRAV_OWNER_CUSTODY_DISPATCH_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "assertions": h.assertions, "cases": h.cases,
            "commands": h.commands,
            "elapsed_seconds": time.monotonic() - started,
        }
        (h.output / "RESULT.json").write_text(
            json.dumps(report, indent=2, sort_keys=True) + "\n")
        summary = {
            "format": report["format"], "status": report["status"],
            "binary_sha256": report["binary_sha256"],
            "assertions": report["assertions"], "cases": report["cases"],
            "cases_passed": sum(case.get("status") == "PASS" for case in report["cases"]),
            "cases_total": len(report["cases"]),
            "commands": len(report["commands"]),
            "elapsed_seconds": report["elapsed_seconds"],
            "failure": None if code == 0 else
                (h.output / "FAILURE.txt").read_text().strip(),
        }
        (h.output / "SUMMARY.json").write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n")
        print(json.dumps({
            "format": report["format"], "status": report["status"],
            "assertions": report["assertions"],
            "cases_passed": summary["cases_passed"],
            "cases_total": summary["cases_total"],
            "commands": summary["commands"],
        }, sort_keys=True))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
