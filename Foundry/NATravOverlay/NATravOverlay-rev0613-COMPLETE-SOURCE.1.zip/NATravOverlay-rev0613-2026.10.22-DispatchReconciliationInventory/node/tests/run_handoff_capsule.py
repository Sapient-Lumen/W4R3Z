#!/usr/bin/env python3
"""Owner-only offline operation/receipt capsules, current durable policy and crypto negatives.

Requires the existing native build dependencies plus Python cryptography for an
independent implementation of the published capsule encoding and key schedule.
All private identities and plaintext examples are fixture-only, outside source.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import struct
import subprocess
import sys
import time

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, x25519
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from run_persistent import Harness, free_port, operation
from run_peer_sessions import submit, revise, outbox_entry
from run_live_configuration import v7, candidate, activate
from run_maintenance import inspect

BIND_DOMAIN = b'NATravOverlay/handoff-binding/v1\0'
SIGN_DOMAIN = b'NATravOverlay/handoff-signature/v1\0'
KDF_INFO = b'NATravOverlay/handoff-key/v1\0'

def sha(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()

def private_file(path: Path, data: bytes):
    path.write_bytes(data)
    path.chmod(0o600)

def binding(data: bytes):
    assert data[:8] == b'NHKB0001'
    offset = 8
    names = []
    for _ in range(3):
        n, = struct.unpack_from('>H', data, offset)
        offset += 2
        names.append(data[offset:offset+n].decode('ascii'))
        offset += n
    ed, x = data[offset:offset+32], data[offset+32:offset+64]
    assert offset+128 == len(data)
    ed25519.Ed25519PublicKey.from_public_bytes(ed).verify(data[-64:], BIND_DOMAIN+data[:-64])
    return (*names, ed, x)

def independent_open(capsule: bytes, keydir: Path):
    assert capsule[:8] == b'NHCP0001' and capsule[9:12] == b'\0\0\0'
    offset = 104
    n, = struct.unpack_from('>H', capsule, offset)
    ob = capsule[offset+2:offset+2+n]
    offset += n+2
    n, = struct.unpack_from('>H', capsule, offset)
    rb = capsule[offset+2:offset+2+n]
    offset += n+2
    length, = struct.unpack_from('>I', capsule, offset)
    offset += 4
    origin = binding(ob)
    assert rb == (keydir/'binding.nhkb').read_bytes()
    binding(rb)
    ed25519.Ed25519PublicKey.from_public_bytes(origin[3]).verify(capsule[-64:], SIGN_DOMAIN+capsule[:-64])
    assert offset+length+16+64 == len(capsule)
    raw = (keydir/'private.nhks').read_bytes()
    assert raw[:8] == b'NHKS0001' and raw[40:] == sha(rb)
    shared = x25519.X25519PrivateKey.from_private_bytes(raw[8:40]).exchange(
        x25519.X25519PublicKey.from_public_bytes(capsule[60:92]))
    header = capsule[:offset]
    key = HKDF(algorithm=hashes.SHA256(), length=32, salt=sha(header), info=KDF_INFO).derive(shared)
    plaintext = AESGCM(key).decrypt(capsule[92:104], capsule[offset:-64], header)
    assert plaintext[:32] == sha(plaintext[32:])
    return plaintext[32:], ob, rb

def independent_seal(payload, origin, recipient, signing_key: Path, *, kind=1, created=None, expires=None):
    now = int(time.time()*1000)
    created = now if created is None else created
    expires = now+60000 if expires is None else expires
    binding(origin)
    peer = binding(recipient)
    ephemeral = x25519.X25519PrivateKey.generate()
    public = ephemeral.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    nonce = os.urandom(12)
    header = (b'NHCP0001'+bytes([kind, 0, 0, 0])+struct.pack('>QQ', created, expires)+os.urandom(32)+public+nonce+
              struct.pack('>H', len(origin))+origin+struct.pack('>H', len(recipient))+recipient+struct.pack('>I',len(payload)+32))
    secret = ephemeral.exchange(x25519.X25519PublicKey.from_public_bytes(peer[4]))
    key = HKDF(algorithm=hashes.SHA256(), length=32, salt=sha(header), info=KDF_INFO).derive(secret)
    encrypted = header+AESGCM(key).encrypt(nonce, sha(payload)+payload, header)
    signer = serialization.load_pem_private_key(signing_key.read_bytes(), password=None)
    return encrypted+signer.sign(SIGN_DOMAIN+encrypted)

def suite(h: Harness):
    root = Path(__file__).resolve().parents[2]
    h.work.chmod(0o700)
    state = {}
    def native():
        command = ['g++', '-D_GNU_SOURCE', '-std=c++20', '-O1', '-g0', '-Wall', '-Wextra', '-Wpedantic',
                   '-Wconversion', '-Wsign-conversion', '-Wshadow', '-Wformat=2', '-Werror', '-pthread',
                   '-I'+str(root/'foundation/include'), '-I'+str(root/'node/src')]
        sources = ['node/tests/handoff_capsule_probe.cpp','node/src/handoff_capsule.cpp','node/src/common.cpp',
                   'node/src/protocol.cpp','foundation/src/core.cpp','foundation/src/natrav_peer_session.cpp',
                   'foundation/src/natrav_peer_stream.cpp','foundation/src/natrav_peer_message.cpp','foundation/src/natrav_peer_handshake.cpp']
        command += [str(root/p) for p in sources]+['-lssl','-lcrypto','-lz','-lzstd','-o',str(h.work/'probe')]
        result = subprocess.run(command,capture_output=True,text=True,timeout=90)
        (h.logs/'probe-compile.stdout').write_text(result.stdout)
        (h.logs/'probe-compile.stderr').write_text(result.stderr)
        (h.logs/'probe-command.json').write_text(json.dumps(command,indent=2))
        h.check(result.returncode == 0, result.stderr)
        result = subprocess.run([str(h.work/'probe')],capture_output=True,text=True,timeout=30)
        (h.logs/'probe.stdout').write_text(result.stdout)
        (h.logs/'probe.stderr').write_text(result.stderr)
        h.check(result.returncode == 0, result.stderr)
        report = json.loads(result.stdout)
        h.check(report['status'] == 'PASS', 'native cryptographic negatives pass')
        h.assertions += report['assertions']
    h.case('native_codec_crypto_and_bounds', native)

    def init():
        version=h.run('version',['version'])
        h.check(version['version']=='0613' and version['handoff_capsule']=='ONE_HOP_AUTHENTICATED_CAPSULE_V1','current capsule capability')
        astate,bstate=h.runtime/'ha',h.runtime/'hb'
        ac=v7(h.config('ha','A',astate,free_port(),[('B',free_port(),100,300,100,600000)]),'ha-v1')
        bc=v7(h.config('hb','B',bstate,free_port(),[('A',free_port(),100,300,100,600000)]),'hb-v1')
        a=h.start('ha',ac,astate); b=h.start('hb',bc,bstate)
        op=operation('handoff-original'); correction=operation('handoff-correction'); denied=operation('handoff-denied')
        submit(h,'queue-original',a.control,'A','B','test/three',op,'offline capsule evidence')
        revise(h,'queue-correction',a.control,'A','B','test/three',correction,op,'offline corrected evidence')
        submit(h,'queue-denied',a.control,'A','B','test/forbidden',denied,'not authorized by recipient')
        ka,kb=h.work/'key-a',h.work/'key-b'
        result=h.run('live-state-lock',['handoff-key-init','--config',str(ac),'--key-directory',str(ka),'--generation','a-h1'],expected=3)
        h.check(not ka.exists() and result['code'].startswith('STATE_'),'live state ownership is exclusive')
        a.shutdown(); b.shutdown()
        for cfg,key,gen in [(ac,ka,'a-h1'),(bc,kb,'b-h1')]:
            r=h.run('key-'+gen,['handoff-key-init','--config',str(cfg),'--key-directory',str(key),'--generation',gen])
            h.check(r['binding_sha256']==sha((key/'binding.nhkb').read_bytes()).hex(),'key attestation commitment')
            h.check((key/'private.nhks').stat().st_mode&0o777==0o600,'private material owner-only')
        state.update(ac=ac,bc=bc,astate=astate,bstate=bstate,ka=ka,kb=kb,op=op,correction=correction,denied=denied)
    h.case('durable_state_and_dedicated_identity_bound_keys', init)

    def export_args(node,peer,op,path,kind='operation'):
        return ['handoff-export','--config',str(state[node+'c']),'--key-directory',str(state['k'+node]),
                '--recipient-binding',str(state['k'+peer]/'binding.nhkb'),'--recipient-binding-sha256',
                sha((state['k'+peer]/'binding.nhkb').read_bytes()).hex(),'--operation-id',op,'--kind',kind,
                '--expires-ms',str(int(time.time()*1000)+60000),'--output',str(path)]
    def import_args(node,path):
        return ['handoff-import','--config',str(state[node+'c']),'--key-directory',str(state['k'+node]),'--input',str(path)]
    def read(node,label):
        return inspect(h,label,state[node+'state'],node.upper())
    def kill_boundary(label,args,environment,boundary):
        so=h.logs/(label+'.out'); se=h.logs/(label+'.err')
        with so.open('w') as stdout,se.open('w') as stderr:
            p=subprocess.Popen([str(h.binary),*args],stdout=stdout,stderr=stderr,env=dict(os.environ,**environment))
            try:
                h.wait(label,lambda: boundary in se.read_text(),10)
                p.kill(); p.wait(timeout=10)
                h.check(p.returncode == -signal.SIGKILL,'deliberate process termination at recorded boundary')
            finally:
                if p.poll() is None: p.kill(); p.wait(timeout=10)

    def lifecycle():
        before=read('a','before-export')
        path=h.work/'operation.nhcp'
        exported=h.run('export-original',export_args('a','b',state['op'],path))
        h.check(exported['status']=='EXPORTED_NOT_DELIVERED','export is not delivery')
        after=read('a','after-export')
        h.check(before['outbox']==after['outbox'],'export does not change outbox or attempts')
        payload,ob,rb=independent_open(path.read_bytes(),state['kb'])
        h.check(b'offline capsule evidence' in payload and b'offline capsule evidence' not in path.read_bytes(),'independent KDF AEAD decryption')
        state.update(payload=payload,origin_binding=ob,recipient_binding=rb,opfile=path,
                     original_attempts=next(x['delivery']['attempts'] for x in before['outbox']['entries'] if x['operation_id']==state['op']))
        interrupted=h.work/'interrupted.nhcp'
        kill_boundary('publication-interrupted',export_args('a','b',state['op'],interrupted),
                      {'NATRAV_TEST_HANDOFF_BEFORE_PUBLISH_MS':'5000'},'NATRAV_TEST_HANDOFF_BEFORE_PUBLISH_MS')
        h.check(not interrupted.exists(),'incomplete publication has no destination')
        parts=list(h.work.glob('.nhc-part-*'));h.check(len(parts)==1,'one bounded unpublished temporary survives interruption')
        h.run('reject-staging-input',import_args('b',parts[0]),expected=3)
        h.run('retry-publication',export_args('a','b',state['op'],interrupted))
        old=path.read_bytes(); h.run('no-overwrite',export_args('a','b',state['op'],path),expected=3)
        h.check(path.read_bytes()==old,'no-replace preserves existing capsule')
        kill_boundary('admission-response-lost',import_args('b',path),
                      {'NATRAV_TEST_HANDOFF_AFTER_IMPORT_MS':'5000'},'NATRAV_TEST_HANDOFF_AFTER_IMPORT_MS')
        duplicate=h.run('recover-lost-admission',import_args('b',path))
        h.check(duplicate['status']=='DUPLICATE','journal survived lost response; no duplicate admission')
        second=h.work/'independent.nhcp'
        private_file(second,independent_seal(payload,ob,rb,h.identity('A').private_key))
        h.check(h.run('independent-seal-import',import_args('b',second))['status']=='DUPLICATE','independent encoder interoperability')
        receipt=h.work/'receipt.nhcp'
        h.run('export-receipt',export_args('b','a',state['op'],receipt,'receipt'))
        h.check(h.run('import-receipt',import_args('a',receipt))['status']=='ACKNOWLEDGED','existing exact receipt path completes')
        h.check(h.run('duplicate-receipt',import_args('a',receipt))['status']=='DUPLICATE_RECEIPT','same exact receipt is idempotent')
        h.run('terminal-not-exportable',export_args('a','b',state['op'],h.work/'terminal'),expected=3)
        revised=h.work/'correction.nhcp'
        h.run('export-correction',export_args('a','b',state['correction'],revised))
        h.check(h.run('import-correction',import_args('b',revised))['status']=='COMMITTED','ordinary correction history reused')
        # Reopen with stale seed configuration and checkpoint the actual persistent nodes.
        b=h.start('hb-restart',state['bc'],state['bstate'])
        h.check(h.status('hb-replayed',state['bstate'])['inbound_records']==2,'exactly original and correction after restart')
        h.run('checkpoint-b',['compact','--control',str(b.control),'--deadline-ms','2000'])
        b.shutdown()
        h.check(h.run('post-checkpoint-duplicate',import_args('b',path))['status']=='DUPLICATE','duplicate suppression survives checkpoint')
        a=h.start('ha-restart',state['ac'],state['astate'])
        entry=outbox_entry(h.status('ha-replayed',state['astate']),state['op'])
        h.check(entry['status']=='ACKED' and entry['attempts']==state['original_attempts'],'receipt survives restart without fabricated delivery attempts')
        a.shutdown()
    h.case('offline_operation_receipt_restart_and_interrupted_publication',lifecycle)

    def negatives():
        path=state['opfile']; original=path.read_bytes()
        for label,data in [('header',original[:28]+bytes([original[28]^1])+original[29:]),
                           ('ciphertext',original[:-90]+bytes([original[-90]^1])+original[-89:]),
                           ('signature',original[:-1]+bytes([original[-1]^1])),
                           ('truncated',original[:-1]),('trailing',original+b'\0'),('oversize',b'x'*68001)]:
            p=h.work/(label+'.nhcp');private_file(p,data)
            h.run('reject-'+label,import_args('b',p),expected=3)
        now=int(time.time()*1000)
        for name,created,expires in [('expired',now-2000,now-1000),('future',now+60000,now+120000)]:
            p=h.work/(name+'.nhcp'); private_file(p,independent_seal(state['payload'],state['origin_binding'],state['recipient_binding'],h.identity('A').private_key,created=created,expires=expires))
            h.run('reject-'+name,import_args('b',p),expected=3)
        # A correctly signed ciphertext for another exact local handoff key is not for this key.
        kb2=h.work/'key-b2'
        h.run('key-b2',['handoff-key-init','--config',str(state['bc']),'--key-directory',str(kb2),'--generation','b-h2'])
        other=h.work/'other-key.nhcp'
        private_file(other,independent_seal(state['payload'],state['origin_binding'],(kb2/'binding.nhkb').read_bytes(),h.identity('A').private_key))
        h.check(h.run('reject-other-key',import_args('b',other),expected=3)['code']=='HANDOFF_RECIPIENT_REJECTED','exact handoff-key selection')
        denied=h.work/'denied.nhcp'
        h.run('export-denied',export_args('a','b',state['denied'],denied))
        h.check(h.run('reject-unauthorized-operation',import_args('b',denied),expected=3)['code']=='AUTHORIZATION_DENIED','cryptographic validity is not scope authority')
        # Accepted policy, not a supplied stale seed, controls revocation and duplicate import.
        b=h.start('hb-revoke',state['bc'],state['bstate'])
        successor=candidate(h,state['bc'],'hb-revoked','hb-v2',lambda s:s.replace('peer_key=A,a-g1,ACTIVE','peer_key=A,a-g1,REVOKED'))
        # Existing peer rows require an active key. Remove the route, retaining the revoked identity.
        successor.write_text('\n'.join(x for x in successor.read_text().splitlines() if not x.startswith(('peer=A,', 'authorize=A,')))+'\n')
        activate(h,'revoke-origin',state['bstate'],successor)
        b.shutdown()
        h.check(h.run('stale-seed-cannot-unrevoke',import_args('b',path),expected=3)['code']=='HANDOFF_PEER_KEY_REJECTED','replayed active policy rejects revoked origin')
    h.case('cryptographic_and_current_authority_negative_controls',negatives)

    def filesystem():
        # These paths fail before application state admission, including after revocation.
        path=state['opfile'];link=h.work/'capsule-link';link.symlink_to(path)
        h.check(h.run('reject-input-symlink',import_args('a',link),expected=3)['code']=='HANDOFF_FILE_REJECTED','no-follow input')
        alias=h.work/'hard-alias';os.link(path,alias)
        h.check(h.run('reject-hard-alias',import_args('a',alias),expected=3)['code']=='HANDOFF_FILE_REJECTED','single-link input')
        alias.unlink()
        key=state['ka']/'private.nhks';saved=key.read_bytes()
        key.chmod(0o644)
        h.check(h.run('reject-key-permissions',import_args('a',path),expected=3)['code']=='HANDOFF_FILE_REJECTED','private key mode')
        key.chmod(0o600)
        private_file(key,saved[:8]+bytes([saved[8]^8])+saved[9:])
        h.check(h.run('reject-key-mutation',import_args('a',path),expected=3)['code']=='HANDOFF_FILE_REJECTED','key file binding')
        private_file(key,saved)
        before={p.name:p.read_bytes() for p in state['ka'].iterdir()}
        h.run('reject-key-overwrite',['handoff-key-init','--config',str(state['ac']),'--key-directory',str(state['ka']),'--generation','a-h2'],expected=3)
        h.check(before=={p.name:p.read_bytes() for p in state['ka'].iterdir()},'failed key publication preserves old material')
        h.check(not any(p.is_dir() for p in h.work.glob('.nhc-part-*')),'failed key publication cleaned only its own staging directory')
        quota=h.work/'quota';quota.mkdir(mode=0o700)
        for i in range(256): private_file(quota/str(i),b'x')
        h.check(h.run('output-quota',export_args('a','b',state['denied'],quota/'capsule'),expected=3)['code']=='HANDOFF_FILE_REJECTED','bounded output directory entries')
        h.check(not (quota/'capsule').exists(),'capacity rejection does not publish')
    h.case('filesystem_and_key_material_negative_controls',filesystem)

    def authenticated_state():
        key=h.work/'state-auth.key'
        h.run('state-key-init',['state-auth-key-init','--output',str(key),'--generation','handoff-mac1'])
        h.run('state-migrate',['state-auth-migrate','--state',str(state['astate']),'--node','A','--new-key',str(key),'--reason','handoff-keyed-test'])
        args=import_args('a',h.work/'receipt.nhcp')
        h.run('keyed-state-requires-key',args,expected=3)
        h.check(h.run('keyed-duplicate-receipt',args+['--state-auth-key',str(key)])['status']=='DUPLICATE_RECEIPT','handoff reuses authenticated state replay')
    h.case('authenticated_state_key_boundary',authenticated_state)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[2]
    out=args.output.resolve()
    if out.exists() or out==root or root in out.parents: parser.error('output must be new and outside source')
    h=Harness(args.binary,out);started=time.monotonic();status='FAIL';failure=None
    try: suite(h);status='PASS'
    except BaseException as error:
        failure=repr(error)
        (out/'failure.txt').write_text(failure+'\n')
        import traceback
        traceback.print_exc()
    finally:
        h.cleanup()
        result={'format':'NATRAV_HANDOFF_CAPSULE_TEST_V1','status':status,
                'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),
                'cases_passed':sum(c['status']=='PASS' for c in h.cases),'cases_total':len(h.cases),
                'assertions':h.assertions,'commands':len(h.commands),'cases':h.cases,
                'elapsed_seconds':time.monotonic()-started,'failure':failure}
        (out/'SUMMARY.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
        print(json.dumps({k:v for k,v in result.items() if k!='cases'}))
    return 0 if status=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
