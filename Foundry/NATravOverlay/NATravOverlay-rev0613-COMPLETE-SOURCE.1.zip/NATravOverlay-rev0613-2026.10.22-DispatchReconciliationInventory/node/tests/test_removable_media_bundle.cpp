#include "removable_media_bundle.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string_view>
#include <vector>

namespace {

class Probe final {
public:
    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_code(Function&& function, const std::string_view code,
                     const std::string_view detail) {
        bool observed = false;
        try {
            std::forward<Function>(function)();
        } catch (const natrav_overlay::removable_media::BundleError& error) {
            observed = error.code() == code;
        }
        check(observed, detail);
    }

    [[nodiscard]] std::size_t assertions() const noexcept { return assertions_; }

private:
    std::size_t assertions_{0U};
};

}  // namespace

int main() {
    using namespace natrav_overlay::removable_media;
    Probe probe;
    try {
        const Settings settings{
            .mtu = 512U,
            .link = 0x0102030405060708ULL,
            .epoch = 17U,
            .lifetime_ms = 10'000U,
        };
        const std::vector<std::uint8_t> payload{
            'r', 'e', 'm', 'o', 'v', 'a', 'b', 'l', 'e'};
        const std::uint64_t created = 1'700'000'000'000ULL;
        const auto encoded = encode(settings, payload, created);
        probe.check(encoded.size() == kBundleOverheadBytes + payload.size(),
                    "encoded size is canonical");
        const auto digest = datacube::sha256(
            std::span<const std::uint8_t>(encoded).first(
                encoded.size() - kBundleDigestBytes));
        const auto name = filename(digest);
        probe.check(name.size() == 69U && name.ends_with(".nrmb"),
                    "content-addressed filename is canonical");
        const auto parsed_name = parse_filename(name);
        probe.check(parsed_name.has_value() && *parsed_name == digest,
                    "filename digest round-trips");
        probe.check(!parse_filename("../not-a-bundle.nrmb").has_value(),
                    "noncanonical filename is rejected");

        const auto decoded = decode(settings, encoded, digest, created + 1U);
        probe.check(decoded.payload == payload && decoded.digest == digest,
                    "canonical payload and digest round-trip");
        probe.check(decoded.created_ms == created &&
                        decoded.expires_ms == created + settings.lifetime_ms,
                    "creation and expiry are exact");

        auto corrupt = encoded;
        corrupt[44U] ^= 1U;
        probe.expect_code(
            [&] { static_cast<void>(decode(settings, corrupt, digest, created + 1U)); },
            "REMOVABLE_MEDIA_BUNDLE_DIGEST_MISMATCH",
            "content corruption is detected");

        auto wrong_link = settings;
        wrong_link.link += 1U;
        probe.expect_code(
            [&] { static_cast<void>(decode(wrong_link, encoded, digest, created + 1U)); },
            "REMOVABLE_MEDIA_BUNDLE_WRONG_LINK",
            "wrong link is rejected");

        auto wrong_epoch = settings;
        wrong_epoch.epoch += 1U;
        probe.expect_code(
            [&] { static_cast<void>(decode(wrong_epoch, encoded, digest, created + 1U)); },
            "REMOVABLE_MEDIA_BUNDLE_WRONG_LINK",
            "wrong epoch is rejected");

        probe.expect_code(
            [&] {
                static_cast<void>(decode(
                    settings, encoded, digest,
                    created + settings.lifetime_ms + 1U));
            },
            "REMOVABLE_MEDIA_BUNDLE_EXPIRED",
            "expired bundle is rejected");

        auto too_future = encode(settings, payload,
                                 created + kMaximumClockSkewMs + 10U);
        const auto future_digest = datacube::sha256(
            std::span<const std::uint8_t>(too_future).first(
                too_future.size() - kBundleDigestBytes));
        probe.expect_code(
            [&] { static_cast<void>(decode(settings, too_future, future_digest, created)); },
            "REMOVABLE_MEDIA_BUNDLE_FUTURE",
            "far-future bundle is rejected");

        auto wrong_digest = digest;
        wrong_digest.octets[0U] ^= 1U;
        probe.expect_code(
            [&] { static_cast<void>(decode(settings, encoded, wrong_digest, created + 1U)); },
            "REMOVABLE_MEDIA_BUNDLE_DIGEST_MISMATCH",
            "filename digest mismatch is rejected");

        probe.expect_code(
            [&] { static_cast<void>(encode(settings, {}, created)); },
            "REMOVABLE_MEDIA_PAYLOAD_INVALID",
            "empty payload is rejected");

        std::vector<std::uint8_t> oversized(settings.mtu + 1U, 0U);
        probe.expect_code(
            [&] { static_cast<void>(encode(settings, oversized, created)); },
            "REMOVABLE_MEDIA_PAYLOAD_INVALID",
            "oversized payload is rejected");

        auto invalid = settings;
        invalid.epoch = 0U;
        probe.expect_code(
            [&] { invalid.validate(); },
            "REMOVABLE_MEDIA_SETTINGS_INVALID",
            "zero epoch is rejected");

        probe.check(std::string_view(kRemovableMediaPacketBundleMarker) ==
                        "REMOVABLE_MEDIA_PACKET_BUNDLE_V1",
                    "bundle marker is exact");
        probe.check(kBundleOverheadBytes == 76U && kBundleDigestBytes == 32U,
                    "bundle finite overhead is exact");

        std::cout << "{\"format\":\"NATRAV_REMOVABLE_MEDIA_BUNDLE_PROBE_V1\","
                  << "\"status\":\"PASS\",\"cases\":8,\"assertions\":"
                  << probe.assertions() << "}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cout << "{\"format\":\"NATRAV_REMOVABLE_MEDIA_BUNDLE_PROBE_V1\","
                  << "\"status\":\"FAIL\",\"assertions\":"
                  << probe.assertions() << ",\"detail\":\"" << error.what()
                  << "\"}\n";
        return 1;
    }
}
