#!/usr/bin/env python3
"""Optional actual rev0555/0556 reader checks; neither is a build dependency."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import time
from run_persistent import Harness
from run_source_selectors import compact, pair, received, typed
from run_local_evidence import author
from run_terminal_reconciliation import late, reconcile_args
from run_lease_succession import add_grant, succeed_args
from run_state_authentication import inspect


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--binary', type=Path, required=True)
    p.add_argument('--predecessor', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--predecessor-version', choices=('0555', '0556'), default='0555')
    a = p.parse_args()
    if a.output.exists(): p.error('output must not exist')
    old_binary = a.predecessor.resolve(strict=True)
    h = Harness(a.binary, a.output)
    start = time.time(); ok = False; observations = []

    def old_inspect(label, state, expected=0):
        current = h.binary
        try:
            h.binary = old_binary
            return inspect(h, label, state, expected=expected)
        finally:
            h.binary = current

    def ordinary():
        a, c, pa, pc, ad, cd = pair(h, 'compat-ordinary', 8)
        parent = author(h, 'compat-original', a, value='original')['operation_id']
        author(h, 'compat-correction', a, parent=parent, value='corrected')
        s = compact(h, 'compat-create', a, 'create')
        for i in range(2): s = received(h, 'compat-'+str(i), a, compact(h, 'compat-issue-'+str(i), a, 'step', previous=s))
        ad.shutdown(); cd.shutdown()
        before = (a/'state.journal').read_bytes()
        current = inspect(h, 'compat-current', a)
        old = old_inspect('compat-predecessor', a)
        h.check(old['storage']['logical_state_digest'] == current['storage']['logical_state_digest'],
                'actual predecessor reads compact-output legacy-intent history identically')
        h.check((a/'state.journal').read_bytes() == before, 'both inspectors leave exact journal unchanged')
        ad = h.start('compat-compact', pa, a)
        h.run('compat-compact', ['compact', '--control', str(ad.control), '--deadline-ms', '5000'])
        ad.shutdown()
        new_checkpoint = inspect(h, 'compat-current-checkpoint', a)
        old_checkpoint = old_inspect('compat-predecessor-checkpoint', a)
        h.check(old_checkpoint['storage']['logical_state_digest'] == new_checkpoint['storage']['logical_state_digest'],
                'actual predecessor reads canonical checkpoint identically')
        observations.append({'history':'NSR5 presentation with legacy mutation intent', 'predecessor':'accepted journal and checkpoint',
                             'uncompacted_logical_digest':current['storage']['logical_state_digest'],
                             'checkpoint_logical_digest':new_checkpoint['storage']['logical_state_digest']})

    def structural(label, successor):
        a, c, pa, pc, ad, cd, old, original = late(h, label)
        if successor:
            reconciled = h.run(label+'-legacy-reconcile', reconcile_args(a, old))
            selected = compact(h, label+'-predecessor-selector', a)
            add_grant(h, pa, a, label+'-g2')
            h.run(label+'-typed-successor', typed(succeed_args(a, reconciled), selected['state_selector']))
        else:
            selected = compact(h, label+'-terminal-selector', a)
            h.run(label+'-typed-reconcile', typed(reconcile_args(a, old), selected['state_selector']))
        ad.shutdown(); cd.shutdown()
        current = inspect(h, label+'-current', a)
        frozen = (a/'state.journal').read_bytes()
        if version['version'] == '0555':
            failure = old_inspect(label+'-old', a, expected=3)
            h.check(failure['code'] == 'JOURNAL_CORRUPT', 'actual rev0555 fails closed on structural request provenance')
            observations.append({'history':'NSR6 '+('succession' if successor else 'reconciliation'),
                                 'predecessor':'rejected', 'code':failure['code']})
        else:
            previous = old_inspect(label+'-old', a)
            h.check(previous['storage']['logical_state_digest'] == current['storage']['logical_state_digest'],
                    'actual rev0556 reads typed history produced by the prepared writer identically')
            h.check(frozen == (a/'state.journal').read_bytes(), 'both readers preserve exact typed journal bytes')
            # Use the currently accepted configuration, including any successor grant.
            active_path = h.work/(label+'-g2.conf') if successor else pa
            ad = h.start(label+'-checkpoint', active_path, a)
            h.run(label+'-compact', ['compact', '--control', str(ad.control), '--deadline-ms', '5000'])
            ad.shutdown()
            newer = inspect(h, label+'-checkpoint-new', a)
            older = old_inspect(label+'-checkpoint-old', a)
            h.check(newer['storage']['logical_state_digest'] == older['storage']['logical_state_digest'],
                    'actual rev0556 reads typed canonical checkpoints identically')
            observations.append({'history':'NSR6 '+('succession' if successor else 'reconciliation'),
                                 'predecessor':'accepted journal and checkpoint',
                                 'uncompacted_logical_digest':current['storage']['logical_state_digest'],
                                 'checkpoint_logical_digest':newer['storage']['logical_state_digest']})

    try:
        current = h.binary
        h.binary = old_binary
        try: version = h.run('predecessor-version', ['version'])
        finally: h.binary = current
        h.check(version['version']==a.predecessor_version, 'comparison uses the explicitly selected actual predecessor binary')
        h.case('compact_output_legacy_intent_older_reader_equal', ordinary)
        h.case('structural_reconciliation_predecessor_compatibility', lambda: structural('compat-reconcile', False))
        h.case('structural_succession_predecessor_compatibility', lambda: structural('compat-succeed', True))
        ok = True
    except BaseException as error:
        (h.output/'FAILURE.txt').write_text(f'{type(error).__name__}: {error}\n')
        print(f'FAIL: {type(error).__name__}: {error}', file=os.sys.stderr)
    finally:
        h.cleanup()
        summary = {'format':'NATRAV_SOURCE_SELECTOR_COMPATIBILITY_V1', 'status':'PASS' if ok else 'FAIL',
                   'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),
                   'predecessor_sha256':hashlib.sha256(old_binary.read_bytes()).hexdigest(),
                   'cases_total':len(h.cases), 'cases_passed':sum(x['status']=='PASS' for x in h.cases),
                   'assertions':h.assertions, 'commands':len(h.commands), 'elapsed_seconds':time.time()-start,
                   'observations':observations}
        for name, value in [('SUMMARY', summary), ('CASES', h.cases), ('COMMANDS', h.commands)]:
            (h.output/(name+'.json')).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
        print(json.dumps(summary), flush=True)
    return 0 if ok else 1

if __name__ == '__main__': raise SystemExit(main())
