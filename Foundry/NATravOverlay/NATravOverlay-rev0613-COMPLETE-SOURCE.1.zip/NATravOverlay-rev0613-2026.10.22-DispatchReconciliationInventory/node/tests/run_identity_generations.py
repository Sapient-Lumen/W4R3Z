#!/usr/bin/env python3
"""Native identity, peer-key generation, revocation, and obligation-transition tests."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import subprocess
import time
from typing import Any, Callable

from run_persistent import Harness, free_port, operation


def generation(label: str) -> str:
    return "g-" + label.lower()


def write_generation_config(
    h: Harness,
    name: str,
    node: str,
    state: Path,
    port: int,
    identity_label: str,
    routes: list[tuple[str, int, int, int, int, int]],
    keys: list[tuple[str, str, str, str]],
    deadline_ms: int = 500,
) -> Path:
    identity = h.identity(identity_label)
    lines = [
        "NATRAV_OVERLAY_CONFIG_V6",
        f"node={node}",
        f"state={state}",
        f"listen=127.0.0.1:{port}",
        "control=control.sock",
        f"identity_cert={identity.certificate}",
        f"identity_key={identity.private_key}",
        f"identity_pin={identity.spki_sha256}",
        f"identity_generation={generation(identity_label)}",
        f"deadline_ms={deadline_ms}",
        "peer_workers=4",
        "peer_queue_capacity=64",
        "control_workers=2",
        "control_queue_capacity=64",
    ]
    for peer, peer_port, initial, maximum, attempts, expiry in routes:
        lines.append(
            f"peer={peer},127.0.0.1:{peer_port},"
            f"{initial},{maximum},{attempts},{expiry}"
        )
    for peer, key_generation, state_name, identity in keys:
        lines.append(
            f"peer_key={peer},{key_generation},{state_name},"
            f"{h.identity(identity).spki_sha256}"
        )
    for peer in sorted({
        item[0] for item in keys if item[2] != "REVOKED"
    }):
        lines.append(
            f"authorize={peer},*,EVIDENCE,test/key-generations"
        )
    path = h.work / f"{name}.conf"
    path.write_text("\n".join(lines) + "\n")
    path.chmod(0o644)
    return path


def status_entries(status: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {
        entry["operation_id"]: entry
        for entry in status["outbox"]["entries"]
    }


def openssl_spki_pin(certificate: Path) -> str:
    public_key = subprocess.run(
        ["openssl", "x509", "-in", str(certificate), "-pubkey", "-noout"],
        check=True,
        capture_output=True,
    ).stdout
    der = subprocess.run(
        ["openssl", "pkey", "-pubin", "-outform", "DER"],
        input=public_key,
        check=True,
        capture_output=True,
    ).stdout
    return hashlib.sha256(der).hexdigest()


def submit(h: Harness, label: str, control: Path, issuer: str, peer: str, op: str) -> None:
    value = h.run(
        label,
        [
            "submit", "--control", str(control), "--node", issuer,
            "--peer", peer, "--scope", "test/key-generations",
            "--operation", op, "--payload-text", label,
            "--deadline-ms", "2000",
        ],
    )
    h.check(value is not None and value.get("ok") is True, f"{label} accepted")


def run_suite(h: Harness, selected: set[str] | None = None) -> None:
    cases: list[tuple[str, Callable[[], None]]] = []

    def native_identity_creation() -> None:
        root = h.runtime / "native-identity"
        parent = root / "private"
        parent.mkdir(parents=True, mode=0o700)
        parent.chmod(0o700)
        destination = parent / "node-a-g1"
        created = h.run(
            "identity-init",
            [
                "identity-init", "--directory", str(destination),
                "--node", "A", "--generation", "a-native-1",
                "--validity-days", "30",
            ],
        )
        assert created is not None
        h.check(created["generation"] == "a-native-1", "identity generation reported")
        h.check(created["private_key_exposed"] is False, "identity account marks key unexposed")
        h.check(destination.is_dir(), "identity directory published")
        h.check(stat.S_IMODE(destination.stat().st_mode) == 0o700, "identity directory mode is 0700")
        key = destination / "key.pem"
        cert = destination / "cert.pem"
        meta = destination / "identity.meta"
        h.check(stat.S_IMODE(key.stat().st_mode) == 0o600, "private key mode is 0600")
        h.check(stat.S_IMODE(cert.stat().st_mode) == 0o644, "certificate mode is 0644")
        h.check(stat.S_IMODE(meta.stat().st_mode) == 0o644, "metadata mode is 0644")
        h.check(openssl_spki_pin(cert) == created["spki_sha256"], "native identity pin matches SPKI")
        h.check("generation=a-native-1" in meta.read_text(), "identity metadata records generation")

        repeat = h.run(
            "identity-no-overwrite",
            [
                "identity-init", "--directory", str(destination),
                "--node", "A", "--generation", "a-native-1",
            ],
            expected=3,
        )
        h.check(repeat is not None and repeat["code"] == "IDENTITY_DESTINATION_EXISTS", "identity overwrite refused")

        unsafe = root / "unsafe"
        unsafe.mkdir(mode=0o777)
        unsafe.chmod(0o777)
        rejected = h.run(
            "identity-unsafe-parent",
            [
                "identity-init", "--directory", str(unsafe / "id"),
                "--node", "A", "--generation", "a-unsafe",
            ],
            expected=3,
        )
        h.check(
            rejected is not None and rejected["code"] == "IDENTITY_PARENT_PERMISSIONS_INVALID",
            "group-writable identity parent rejected",
        )

        real_parent = root / "real-parent"
        real_parent.mkdir(mode=0o700)
        link_parent = root / "linked-parent"
        link_parent.symlink_to(real_parent, target_is_directory=True)
        rejected = h.run(
            "identity-symlink-parent",
            [
                "identity-init", "--directory", str(link_parent / "id"),
                "--node", "A", "--generation", "a-link",
            ],
            expected=3,
        )
        h.check(
            rejected is not None and rejected["code"] == "IDENTITY_PARENT_SYMLINK_REJECTED",
            "identity parent symlink rejected",
        )

        config = h.work / "native-identity.conf"
        config.write_text(
            "NATRAV_OVERLAY_CONFIG_V6\n"
            "node=A\n"
            f"state={root / 'state'}\n"
            f"listen=127.0.0.1:{free_port()}\n"
            "control=control.sock\n"
            f"identity_cert={cert}\n"
            f"identity_key={key}\n"
            f"identity_pin={created['spki_sha256']}\n"
            "identity_generation=a-native-1\n"
        )
        checked = h.run("identity-config-check", ["config-check", "--config", str(config)])
        h.check(checked is not None and checked["identity"]["generation"] == "a-native-1", "created identity loads")

    cases.append(("native_identity_creation", native_identity_creation))

    def generation_configuration() -> None:
        root = h.runtime / "generation-config"
        root.mkdir()
        port = free_port()
        keys = [
            ("B", "b-old", "RETIRED", "B-OLD"),
            ("B", "b-current", "ACTIVE", "B-NEW"),
            ("B", "b-compromised", "REVOKED", "B-REVOKED"),
            ("C", "c-inbound", "ACTIVE", "C"),
        ]
        valid = write_generation_config(
            h, "generation-valid", "A", root / "state", free_port(), "A",
            [("B", port, 50, 200, 8, 10_000)], keys,
        )
        checked = h.run("generation-config-valid", ["config-check", "--config", str(valid)])
        assert checked is not None
        peer = checked["peers"][0]
        h.check(peer["active_generation"] == "b-current", "exact active generation selected")
        states = {item["id"]: item["state"] for item in peer["generations"]}
        h.check(states == {
            "b-compromised": "REVOKED",
            "b-current": "ACTIVE",
            "b-old": "RETIRED",
        }, "all routed peer generation states retained")
        all_generations = {
            (item["node"], item["id"]): item["state"]
            for item in checked["peer_generations"]
        }
        h.check(
            all_generations[("C", "c-inbound")] == "ACTIVE",
            "inbound-only trusted generation is visible",
        )

        duplicate_active = h.work / "generation-two-active.conf"
        text = valid.read_text().replace(
            "peer_key=B,b-old,RETIRED,",
            "peer_key=B,b-old,ACTIVE,",
        )
        duplicate_active.write_text(text)
        result = h.run("generation-two-active", ["config-check", "--config", str(duplicate_active)], expected=3)
        h.check(result is not None and result["code"] == "CONFIG_ACTIVE_GENERATION_INVALID", "two active generations rejected")

        duplicate_id = h.work / "generation-duplicate-id.conf"
        duplicate_id.write_text(valid.read_text() +
            f"peer_key=B,b-current,RETIRED,{h.identity('B-OLD').spki_sha256}\n")
        result = h.run("generation-duplicate-id", ["config-check", "--config", str(duplicate_id)], expected=3)
        h.check(result is not None and result["code"] == "CONFIG_DUPLICATE_PEER_GENERATION", "duplicate generation rejected")

        duplicate_pin = h.work / "generation-duplicate-pin.conf"
        duplicate_pin.write_text(valid.read_text() +
            f"peer_key=B,b-alias,RETIRED,{h.identity('B-OLD').spki_sha256}\n")
        result = h.run("generation-duplicate-pin", ["config-check", "--config", str(duplicate_pin)], expected=3)
        h.check(result is not None and result["code"] == "CONFIG_PEER_KEY_AMBIGUOUS", "one pin cannot name two generations")

        no_active = h.work / "generation-no-active.conf"
        no_active.write_text(valid.read_text().replace(
            "peer_key=B,b-current,ACTIVE,",
            "peer_key=B,b-current,RETIRED,",
        ))
        result = h.run("generation-no-active", ["config-check", "--config", str(no_active)], expected=3)
        h.check(result is not None and result["code"] == "CONFIG_ACTIVE_GENERATION_INVALID", "route without active generation rejected")

    cases.append(("generation_configuration", generation_configuration))

    def durable_rebind_cancel_restart() -> None:
        root = h.runtime / "transitions"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        old_op = operation("generation-old-rebind")
        cancel_op = operation("generation-old-cancel")
        new_op = operation("generation-new-active")

        stage1 = write_generation_config(
            h, "transitions-a-old", "A", a_state, a_port, "A",
            [("B", b_port, 1500, 1500, 20, 60_000)],
            [("B", "b-old", "ACTIVE", "B-OLD")],
            deadline_ms=250,
        )
        a1 = h.start("transitions-a-old", stage1, a_state)
        submit(h, "transition-submit-rebind", a1.control, "A", "B", old_op)
        submit(h, "transition-submit-cancel", a1.control, "A", "B", cancel_op)

        def both_attempted() -> bool:
            entries = status_entries(h.status("transition-old-wait", a_state))
            return entries[old_op]["attempts"] >= 1 and entries[cancel_op]["attempts"] >= 1

        h.wait("old-generation obligations attempted", both_attempted, 8.0)
        a1.shutdown()

        b_config = write_generation_config(
            h, "transitions-b-new", "B", b_state, b_port, "B-NEW", [],
            [("A", generation("A"), "ACTIVE", "A")],
            deadline_ms=500,
        )
        stage2 = write_generation_config(
            h, "transitions-a-new", "A", a_state, a_port, "A",
            [("B", b_port, 50, 200, 20, 60_000)],
            [
                ("B", "b-old", "RETIRED", "B-OLD"),
                ("B", "b-new", "ACTIVE", "B-NEW"),
                ("B", "b-revoked", "REVOKED", "B-REVOKED"),
            ],
            deadline_ms=500,
        )
        b = h.start("transitions-b-new", b_config, b_state)
        a2 = h.start("transitions-a-new", stage2, a_state)
        submit(h, "transition-submit-new", a2.control, "A", "B", new_op)
        h.wait(
            "new active generation delivers around old obligations",
            lambda: status_entries(h.status("transition-new-wait", a_state))[new_op]["status"] == "ACKED",
        )

        rebound = h.run(
            "transition-rebind",
            [
                "rebind", "--control", str(a2.control),
                "--operation", old_op, "--generation", "b-new",
                "--reason", "operator selected current recipient generation",
                "--deadline-ms", "2000",
            ],
        )
        h.check(rebound is not None and rebound["generation"] == "b-new", "rebind command selected active generation")
        cancelled = h.run(
            "transition-cancel",
            [
                "cancel", "--control", str(a2.control),
                "--operation", cancel_op,
                "--reason", "obsolete obligation intentionally withdrawn",
                "--deadline-ms", "2000",
            ],
        )
        h.check(cancelled is not None and cancelled["status"] == "CANCELLED", "cancel command made terminal state")

        h.wait(
            "rebound obligation acknowledged",
            lambda: status_entries(h.status("transition-rebound-wait", a_state))[old_op]["status"] == "ACKED",
        )
        final = h.status("transition-final", a_state)
        entries = status_entries(final)
        h.check(entries[new_op]["peer_generation"] == "b-new", "new work bound to active generation")
        h.check(entries[old_op]["peer_generation"] == "b-new", "old work now bound to selected generation")
        h.check(entries[old_op]["status"] == "ACKED", "rebound work delivered")
        h.check(entries[cancel_op]["status"] == "CANCELLED", "cancelled work remains terminal")
        h.check(entries[cancel_op]["cancellation_reason"] == "obsolete obligation intentionally withdrawn", "cancellation reason retained")
        h.check(entries[old_op]["transitions"][-1]["kind"] == "REBOUND", "rebind transition visible")
        h.check(entries[old_op]["transitions"][-1]["from_generation"] == "b-old", "rebind preserves old generation")
        h.check(entries[cancel_op]["transitions"][-1]["kind"] == "CANCELLED", "cancellation transition visible")
        h.check(final["outbox"]["acked"] == 2, "two obligations acknowledged")
        h.check(final["outbox"]["cancelled"] == 1, "one obligation cancelled")
        h.check(h.status("transition-b-final", b_state)["inbound_records"] == 2, "recipient admitted only delivered obligations")

        a2.shutdown()
        a3 = h.start("transitions-a-restart", stage2, a_state)
        restarted = h.status("transition-restart-status", a_state)
        restarted_entries = status_entries(restarted)
        h.check(restarted_entries[old_op]["status"] == "ACKED", "rebound receipt reconstructs after restart")
        h.check(restarted_entries[cancel_op]["status"] == "CANCELLED", "cancellation reconstructs after restart")
        h.check(restarted_entries[old_op]["transitions"][-1]["reason"] == "operator selected current recipient generation", "rebind reason reconstructs")
        a3.shutdown(); b.shutdown()

    cases.append(("durable_rebind_cancel_restart", durable_rebind_cancel_restart))

    def revoked_key_rejection() -> None:
        root = h.runtime / "revoked-inbound"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        a_config = write_generation_config(
            h, "revoked-a", "A", a_state, a_port, "A", [],
            [("B", "b-revoked", "REVOKED", "B-REVOKED")],
            deadline_ms=400,
        )
        b_config = write_generation_config(
            h, "revoked-b", "B", b_state, b_port, "B-REVOKED",
            [("A", a_port, 50, 100, 3, 5_000)],
            [("A", generation("A"), "ACTIVE", "A")],
            deadline_ms=400,
        )
        a = h.start("revoked-a", a_config, a_state)
        b = h.start("revoked-b", b_config, b_state)
        rejected_op = operation("revoked-key-inbound")
        submit(h, "revoked-submit", b.control, "B", "A", rejected_op)

        def rejected() -> bool:
            b_status = h.status("revoked-b-wait", b_state)
            entry = status_entries(b_status)[rejected_op]
            if entry["status"] == "ACKED":
                raise AssertionError("revoked generation was admitted")
            return entry["attempts"] >= 1 and "TLS_PEER_KEY_REVOKED" in a.stderr_path.read_text()

        h.wait("revoked key rejected by recipient", rejected, 8.0)
        a_status = h.status("revoked-a-status", a_state)
        b_status = h.status("revoked-b-status", b_state)
        h.check(a_status["inbound_records"] == 0, "revoked key admitted no evidence")
        h.check(a_status["service"]["peer_authenticated"] == 0, "revoked generation is rejected before authentication account")
        h.check(a_status["service"]["peer_rejected"] >= 1, "revoked connection counted rejected")
        visible = {
            (item["node"], item["id"]): item["state"]
            for item in a_status["peer_generations"]
        }
        h.check(visible[("B", "b-revoked")] == "REVOKED", "inbound-only revocation is visible in status")
        entry = status_entries(b_status)[rejected_op]
        h.check(entry["status"] == "PENDING", "revoked sender obligation remains pending")
        h.check(entry["peer_generation"] == generation("A"), "sender obligation retains recipient generation")
        b.shutdown(); a.shutdown()

    cases.append(("revoked_key_rejection", revoked_key_rejection))

    def transition_journal_recovery() -> None:
        root = h.runtime / "journal-transitions"
        root.mkdir()
        state = root / "state"
        a_port, b_port = free_port(), free_port()
        op_rebind = operation("journal-rebind")
        op_cancel = operation("journal-cancel")
        old = write_generation_config(
            h, "journal-old", "A", state, a_port, "A",
            [("B", b_port, 2000, 2000, 20, 60_000)],
            [("B", "b-old", "ACTIVE", "B-OLD")],
            deadline_ms=200,
        )
        daemon = h.start("journal-old", old, state)
        submit(h, "journal-submit-rebind", daemon.control, "A", "B", op_rebind)
        submit(h, "journal-submit-cancel", daemon.control, "A", "B", op_cancel)
        h.wait(
            "journal seed policies durable",
            lambda: len(h.status("journal-seed-wait", state)["outbox"]["entries"]) == 2,
        )
        daemon.shutdown()
        rotated = write_generation_config(
            h, "journal-rotated", "A", state, a_port, "A",
            [("B", b_port, 2000, 2000, 20, 60_000)],
            [
                ("B", "b-old", "RETIRED", "B-OLD"),
                ("B", "b-new", "ACTIVE", "B-NEW"),
            ],
            deadline_ms=200,
        )
        daemon2 = h.start("journal-rotated", rotated, state)
        h.run(
            "journal-rebind",
            [
                "rebind", "--control", str(daemon2.control),
                "--operation", op_rebind, "--generation", "b-new",
                "--reason", "journaled generation migration",
            ],
        )
        h.run(
            "journal-cancel",
            [
                "cancel", "--control", str(daemon2.control),
                "--operation", op_cancel,
                "--reason", "journaled terminal cancellation",
            ],
        )
        daemon2.shutdown()

        clean = root / "clean"
        shutil.copytree(state, clean)
        tail = root / "tail"
        shutil.copytree(state, tail)
        with (tail / "state.journal").open("ab") as stream:
            stream.write(b"NOJ1\x00\x00")
        recovered = h.run(
            "journal-transition-tail",
            ["inspect", "--state", str(tail), "--node", "A"],
        )
        assert recovered is not None
        recovered_entries = {
            entry["operation_id"]: entry for entry in recovered["outbox"]["entries"]
        }
        h.check(recovered["recoveries"][-1]["discarded_tail_bytes"] == 6, "transition journal tail recovered")
        h.check(recovered_entries[op_rebind]["delivery"]["transitions"][-1]["kind"] == "REBOUND", "rebind survives tail recovery")
        h.check(recovered_entries[op_cancel]["delivery"]["transitions"][-1]["kind"] == "CANCELLED", "cancel survives tail recovery")

        corrupt = root / "corrupt"
        shutil.copytree(clean, corrupt)
        journal = corrupt / "state.journal"
        data = bytearray(journal.read_bytes())
        offset = 0
        transition_checksums: list[int] = []
        while offset < len(data):
            h.check(data[offset:offset + 4] == b"NOJ1", "journal record magic")
            body_size = struct.unpack("!I", data[offset + 4:offset + 8])[0]
            kind = data[offset + 8]
            checksum = offset + 8 + body_size
            h.check(checksum + 32 <= len(data), "complete journal record parsed")
            if kind in (9, 10):
                transition_checksums.append(checksum)
            offset = checksum + 32
        h.check(len(transition_checksums) == 2, "both transition records located")
        data[transition_checksums[-1]] ^= 1
        journal.write_bytes(data)
        failed = h.run(
            "journal-transition-corrupt",
            ["inspect", "--state", str(corrupt), "--node", "A"],
            expected=3,
        )
        h.check(failed is not None and failed["code"] == "JOURNAL_CORRUPT", "transition checksum corruption fails closed")

    cases.append(("transition_journal_recovery", transition_journal_recovery))

    for name, function in cases:
        if selected is None or name in selected:
            h.case(name, function)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, default=Path("node/bin/natrav-overlay"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--case",
        action="append",
        choices=[
            "native_identity_creation",
            "generation_configuration",
            "durable_rebind_cancel_restart",
            "revoked_key_rejection",
            "transition_journal_recovery",
        ],
    )
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output directory must not exist")
    harness = Harness(args.binary, args.output)
    started = time.time()
    status = "FAIL"
    return_code = 1
    try:
        run_suite(harness, set(args.case) if args.case else None)
        status = "PASS"
        return_code = 0
    except BaseException as exc:
        (harness.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_IDENTITY_GENERATION_TESTS_V1",
            "status": status,
            "binary": str(harness.binary),
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "selected_cases": args.case or [],
            "started_unix": started,
            "elapsed_seconds": time.time() - started,
        }
        (harness.output / "SUMMARY.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
        (harness.output / "CASES.json").write_text(json.dumps(harness.cases, indent=2, sort_keys=True) + "\n")
        (harness.output / "COMMANDS.json").write_text(json.dumps(harness.commands, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary, sort_keys=True))
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
