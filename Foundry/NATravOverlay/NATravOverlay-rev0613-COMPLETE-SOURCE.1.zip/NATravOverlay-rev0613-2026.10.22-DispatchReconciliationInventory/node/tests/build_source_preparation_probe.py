#!/usr/bin/env python3
"""Build a private preparation-boundary probe in a new, isolated source tree."""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--mode', choices=('static', 'sanitize'), default='static')
    parser.add_argument('--negative-control', action='store_true')
    parser.add_argument('--transaction-negative-control', action='store_true')
    parser.add_argument('--outbound-negative-control', action='store_true')
    parser.add_argument('--outgoing-slice-negative-control', action='store_true')
    parser.add_argument('--outbound-transfer-negative-control', action='store_true')
    parser.add_argument('--prepare-only', action='store_true', help='create isolated source; compile separately with unchanged build flags')
    args = parser.parse_args()
    if sum((args.negative_control, args.transaction_negative_control,
            args.outbound_negative_control, args.outgoing_slice_negative_control,
            args.outbound_transfer_negative_control)) > 1:
        parser.error('select only one negative control')
    root = Path(__file__).resolve().parents[2]
    out = args.output.resolve()
    if out.exists() or out == root or root in out.parents:
        parser.error('output must be new and outside the product workspace')
    tree = out / 'source'
    tree.mkdir(parents=True)
    for part in ('node/src', 'foundation/src', 'foundation/include'):
        shutil.copytree(root / part, tree / part)
    shutil.copy2(root / 'node/build.sh', tree / 'node/build.sh')
    header = tree / 'node/src/journal.hpp'
    text = header.read_text()
    anchor = '    struct SourceProgressPreparation;'
    assert text.count(anchor) == 1
    text = text.replace(anchor, anchor + '\n    friend std::string source_preparation_boundary_probe(NodeState&);'
                        + '\n    friend std::string source_preparation_automatic_probe(NodeState&);'
                        + '\n    friend std::string source_eligibility_boundary_probe(NodeState&);'
                        + '\n    friend std::string parsed_source_progress_boundary_probe(NodeState&);'
                        + '\n    friend std::string parsed_source_progress_append_failure_probe(NodeState&);'
                        + '\n    friend std::string parsed_source_progress_post_append_failure_probe(NodeState&);'
                        + '\n    friend std::string source_outbound_admission_boundary_probe(NodeState&);')
    header.write_text(text)
    source = tree / 'node/src/source_subscription.cpp'
    original = source.read_text()
    changed = original
    if args.negative_control:
        guard = 'eligibility->source_record_digest == source.record_digest &&'
        assert changed.count(guard) == 1
        changed = changed.replace(guard, 'true && // deliberately omitted eligibility source digest boundary')
        (out / 'MUTATION.patch').write_text(''.join(difflib.unified_diff(
            original.splitlines(True), changed.splitlines(True),
            fromfile='normal/source_subscription.cpp', tofile='negative/source_subscription.cpp')))
    if args.transaction_negative_control:
        guard = '''bytes.size() == parsed.bytes.size() &&
        std::equal(bytes.begin(), bytes.end(), parsed.bytes.begin()) &&
        datacube::sha256(bytes) == parsed.bytes_digest'''
        assert changed.count(guard) == 1
        changed = changed.replace(guard, 'true /* deliberately omitted exact bytes-to-parse boundary */')
        (out / 'MUTATION.patch').write_text(''.join(difflib.unified_diff(
            original.splitlines(True), changed.splitlines(True),
            fromfile='normal/source_subscription.cpp', tofile='negative/source_subscription.cpp')))
    if args.outbound_negative_control:
        guard = """bytes.size() == expected.size() &&
        std::equal(bytes.begin(), bytes.end(), expected.begin())"""
        assert changed.count(guard) == 1
        changed = changed.replace(guard, '((void)expected, true) /* deliberately omitted nested byte-to-record binding */')
        (out / 'MUTATION.patch').write_text(''.join(difflib.unified_diff(
            original.splitlines(True), changed.splitlines(True),
            fromfile='normal/source_subscription.cpp', tofile='negative/source_subscription.cpp')))
    if args.outgoing_slice_negative_control:
        guard = """decoded.outgoing_size <= bytes.size() - decoded.outgoing_offset &&
        decoded.outgoing_offset + decoded.outgoing_size == bytes.size(),
        "source progress outgoing slice bounds invalid"""
        assert changed.count(guard) == 1
        changed = changed.replace(guard, """decoded.outgoing_size <= bytes.size() - decoded.outgoing_offset &&
        true /* deliberately omitted strict outgoing end boundary */,
        "source progress outgoing slice bounds invalid""")
        (out / 'MUTATION.patch').write_text(''.join(difflib.unified_diff(
            original.splitlines(True), changed.splitlines(True),
            fromfile='normal/source_subscription.cpp', tofile='negative/source_subscription.cpp')))
    if args.outbound_transfer_negative_control:
        guard = '''parsed.published_journal_bytes.has_value() &&
        *parsed.published_journal_bytes == journal_bytes_ &&
        !parsed.outbound_record_transferred'''
        assert changed.count(guard) == 1
        changed = changed.replace(guard,
            '''true /* deliberately omitted durable-publication transfer boundary */ &&
        !parsed.outbound_record_transferred''')
        (out / 'MUTATION.patch').write_text(''.join(difflib.unified_diff(
            original.splitlines(True), changed.splitlines(True),
            fromfile='normal/source_subscription.cpp', tofile='negative/source_subscription.cpp')))
    source.write_text(changed + '\n' + (root / 'node/tests/source_preparation_probe.inc').read_text()
                      + '\n' + (root / 'node/tests/parsed_source_progress_probe.inc').read_text()
                      + '\n' + (root / 'node/tests/source_outbound_admission_probe.inc').read_text())
    journal = tree / 'node/src/journal.cpp'
    journal_text = journal.read_text()
    journal_anchor = '    apply_outbound_record_locked(record_bytes, replaying, parsed);\n    apply_entry(EntryKind::outbound_policy, policy_bytes, replaying);'
    assert journal_text.count(journal_anchor) == 1
    journal_text = journal_text.replace(journal_anchor,
        '''    apply_outbound_record_locked(record_bytes, replaying, parsed);
    if (parsed && std::getenv("NATRAV_OVERLAY_TEST_PRIVATE_SOURCE_POST_TRANSFER_FAIL")) {
        app_fail("PRIVATE_SOURCE_POST_TRANSFER_FAILURE",
            "private probe failure after published source record transfer");
    }
    apply_entry(EntryKind::outbound_policy, policy_bytes, replaying);''')
    journal.write_text(journal_text)
    shutil.copy2(root / 'node/tests/test_source_preparation_main.cpp', tree / 'node/src/main.cpp')
    if args.prepare_only:
        print(json.dumps({'status': 'SOURCE_PREPARED_NOT_BUILT', 'source': str(tree)}))
        return 0
    started = time.monotonic()
    with (out / 'BUILD.log').open('w') as log:
        build = subprocess.run(['sh', 'node/build.sh', args.mode], cwd=tree,
                               stdout=log, stderr=subprocess.STDOUT, timeout=600,
                               env=dict(os.environ))
    binary = tree / 'node/bin' / ('natrav-overlay' if args.mode == 'static' else 'natrav-overlay-sanitize')
    result = {'format': 'SOURCE_ELIGIBILITY_PROBE_BUILD_V1', 'status': 'PASS' if build.returncode == 0 else 'FAIL',
              'mode': args.mode, 'negative_control': args.negative_control, 'transaction_negative_control': args.transaction_negative_control, 'outbound_negative_control': args.outbound_negative_control, 'outgoing_slice_negative_control': args.outgoing_slice_negative_control, 'outbound_transfer_negative_control': args.outbound_transfer_negative_control, 'returncode': build.returncode,
              'elapsed_seconds': time.monotonic() - started,
              'product_source_sha256': hashlib.sha256(original.encode()).hexdigest(),
              'test_source_sha256': hashlib.sha256((root / 'node/tests/source_preparation_probe.inc').read_bytes()).hexdigest(),
              'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest() if binary.exists() else None}
    (out / 'BUILD.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    return build.returncode

if __name__ == '__main__':
    raise SystemExit(main())
