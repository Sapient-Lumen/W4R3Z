#include "adapter_profile.hpp"
#include "common.hpp"
#include "external_packet_adapter.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace {

using natrav_overlay::AdapterSha256;
using natrav_overlay::AppError;
using natrav_overlay::ExternalPacketAdapterOptions;
using natrav_overlay::OperatorPinnedAdapterProfile;

struct CaseRecord final {
    std::string name;
    std::size_t assertions{0U};
};

class Probe final {
public:
    template <typename Function>
    void run_case(std::string name, Function&& function) {
        const auto before = assertions_;
        function();
        cases_.push_back(CaseRecord{
            .name = std::move(name),
            .assertions = assertions_ - before,
        });
    }

    void check(const bool condition, const std::string_view detail) {
        ++assertions_;
        if (!condition) {
            throw std::runtime_error(std::string(detail));
        }
    }

    template <typename Function>
    void expect_app_code(
        Function&& function,
        const std::string_view expected,
        const std::string_view detail) {
        ++assertions_;
        try {
            function();
        } catch (const AppError& error) {
            if (error.code() == expected) {
                return;
            }
            throw std::runtime_error(
                std::string(detail) + ": expected " + std::string(expected) +
                ", observed " + error.code());
        }
        throw std::runtime_error(std::string(detail) + ": no error");
    }

    [[nodiscard]] std::size_t assertions() const noexcept { return assertions_; }
    [[nodiscard]] const std::vector<CaseRecord>& cases() const noexcept {
        return cases_;
    }

private:
    std::size_t assertions_{0U};
    std::vector<CaseRecord> cases_{};
};

class TempDirectory final {
public:
    TempDirectory() {
        std::array<char, 128U> pattern{};
        const std::string value = "/tmp/natrav-adapter-integration-XXXXXX";
        std::copy(value.begin(), value.end(), pattern.begin());
        char* created = ::mkdtemp(pattern.data());
        if (created == nullptr) {
            throw std::runtime_error("mkdtemp failed");
        }
        path_ = created;
        if (::chmod(path_.c_str(), S_IRWXU) != 0) {
            throw std::runtime_error("chmod temp directory failed");
        }
    }
    TempDirectory(const TempDirectory&) = delete;
    TempDirectory& operator=(const TempDirectory&) = delete;
    ~TempDirectory() { std::filesystem::remove_all(path_); }
    [[nodiscard]] const std::filesystem::path& path() const noexcept { return path_; }
private:
    std::filesystem::path path_{};
};

[[nodiscard]] std::vector<std::uint8_t> read_bytes(
    const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        throw std::runtime_error("file open failed: " + path.string());
    }
    return std::vector<std::uint8_t>(
        std::istreambuf_iterator<char>(input),
        std::istreambuf_iterator<char>());
}

[[nodiscard]] std::string read_text(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        throw std::runtime_error("report open failed: " + path.string());
    }
    return std::string(
        std::istreambuf_iterator<char>(input),
        std::istreambuf_iterator<char>());
}

[[nodiscard]] bool contains_line(
    const std::string_view text,
    const std::string_view line) {
    return text.find(std::string(line) + '\n') != std::string_view::npos;
}

void copy_executable(
    const std::filesystem::path& source,
    const std::filesystem::path& destination) {
    std::filesystem::copy_file(
        source, destination, std::filesystem::copy_options::overwrite_existing);
    if (::chmod(destination.c_str(), S_IRUSR | S_IWUSR | S_IXUSR) != 0) {
        throw std::runtime_error("chmod copied executable failed");
    }
}

[[nodiscard]] OperatorPinnedAdapterProfile make_profile(
    const std::filesystem::path& executable,
    const AdapterSha256& digest,
    const std::filesystem::path& report) {
    OperatorPinnedAdapterProfile profile;
    profile.profile_id = "fixture-profile";
    profile.generation = 1U;
    profile.executable = executable;
    profile.executable_sha256 = digest;
    profile.arguments = {report.string()};
    profile.mtu = 1'200U;
    profile.capability_profile = 1U;
    profile.max_frame_bytes = 65'536U;
    profile.max_queued_bytes = 1'048'576U;
    profile.max_outstanding_requests = 1U;
    profile.max_evidence_events = 256U;
    profile.max_launch_attempts = 3U;
    profile.startup_timeout = std::chrono::milliseconds(2'000);
    profile.request_timeout = std::chrono::milliseconds(500);
    profile.shutdown_timeout = std::chrono::milliseconds(500);
    profile.initial_restart_backoff = std::chrono::milliseconds(5);
    profile.maximum_restart_backoff = std::chrono::milliseconds(20);
    return profile;
}

void exchange_one_packet(
    ExternalPacketAdapterOptions options,
    Probe& probe,
    const std::string_view expected_marker,
    const std::filesystem::path& report) {
    {
        auto adapter = natrav_overlay::make_supervised_external_packet_adapter(
            std::move(options));
        const natrav::packet_link::Bytes packet{
            0x01U, 0x02U, 0x03U, 0x7fU, 0xffU};
        probe.check(adapter.port->send_packet(packet),
                    "verified adapter accepts one bounded datagram");
        const auto received = adapter.port->receive_packet();
        probe.check(received.has_value() && *received == packet,
                    "verified adapter returns the exact datagram");
        const auto snapshot = adapter.control->snapshot();
        probe.check(snapshot.running && snapshot.launch_attempts == 1U,
                    "profile-backed adapter launch is recorded once");
        probe.check(snapshot.capabilities.mtu == 1'200U &&
                        snapshot.capabilities.profile == 1U,
                    "negotiated capabilities remain within profile bounds");
        probe.check(snapshot.pinned_profile_id == "fixture-profile" &&
                        snapshot.pinned_profile_generation != 0U &&
                        snapshot.pinned_profile_sha256 ==
                            options.pinned_profile_sha256 &&
                        snapshot.executable_sha256 ==
                            options.pinned_profile->executable_sha256,
                    "snapshot binds the operator profile and executable digests");
        const auto startup_report = read_text(report);
        probe.check(contains_line(startup_report,
                                  std::string("marker=") +
                                      std::string(expected_marker)),
                    "sealed image marker matches authorized bytes");
        probe.check(contains_line(startup_report, "environment-count=5") &&
                        contains_line(startup_report, "extra-fd-count=0") &&
                        contains_line(startup_report, "no-new-privs=1"),
                    "adapter receives only the bounded environment and descriptor set");
    }
    const auto shutdown_report = read_text(report);
    probe.check(contains_line(shutdown_report, "shutdown=1"),
                "adapter completes bounded protocol shutdown");
}

}  // namespace

int main(int argc, char* argv[]) {
    Probe probe;
    try {
        if (argc != 3) {
            throw std::runtime_error("expected adapter fixture A and B");
        }
        const auto fixture_a = std::filesystem::absolute(argv[1]);
        const auto fixture_b = std::filesystem::absolute(argv[2]);
        const auto digest_a = natrav_overlay::adapter_sha256(read_bytes(fixture_a));
        const auto digest_b = natrav_overlay::adapter_sha256(read_bytes(fixture_b));
        TempDirectory temporary;
        const auto executable = temporary.path() / "adapter";
        const auto report_a = temporary.path() / "report-a.txt";
        const auto report_b = temporary.path() / "report-b.txt";
        copy_executable(fixture_a, executable);
        auto profile = make_profile(executable, digest_a, report_a);

        ExternalPacketAdapterOptions prepared;
        probe.run_case("profile factory seals exact image", [&] {
            prepared =
                natrav_overlay::external_packet_adapter_options_from_profile(profile);
            probe.check(prepared.pinned_profile.has_value() &&
                            prepared.verified_executable != nullptr,
                        "profile factory retains durable record and sealed image");
            probe.check(prepared.pinned_profile.value() == profile,
                        "prepared options retain the exact canonical profile fields");
            probe.check(prepared.verified_executable->sha256() == digest_a,
                        "prepared options bind exact executable SHA-256");
        });

        probe.run_case("sealed launch survives path replacement", [&] {
            const auto old = temporary.path() / "adapter-old";
            std::filesystem::rename(executable, old);
            copy_executable(fixture_b, executable);
            exchange_one_packet(prepared, probe, "A", report_a);
        });

        probe.run_case("profile drift is rejected before fork", [&] {
            auto drifted = prepared;
            drifted.arguments.push_back("unauthorized");
            probe.expect_app_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::make_supervised_external_packet_adapter(
                            drifted));
                },
                "ADAPTER_PROFILE_DRIFT",
                "argument drift from pinned record rejected");
            auto metadata_drift = prepared;
            metadata_drift.pinned_profile->generation += 1U;
            probe.expect_app_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::make_supervised_external_packet_adapter(
                            metadata_drift));
                },
                "ADAPTER_PROFILE_DRIFT",
                "profile metadata mutation rejected by canonical digest");
            auto half_bound = prepared;
            half_bound.verified_executable.reset();
            probe.expect_app_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::make_supervised_external_packet_adapter(
                            half_bound));
                },
                "ADAPTER_PROFILE_INVALID",
                "profile without verified image rejected");
        });

        probe.run_case("stale digest cannot prepare replacement path", [&] {
            probe.expect_app_code(
                [&] {
                    static_cast<void>(
                        natrav_overlay::external_packet_adapter_options_from_profile(
                            profile));
                },
                "ADAPTER_EXECUTABLE_DIGEST_MISMATCH",
                "replacement path cannot satisfy predecessor digest");
        });

        ExternalPacketAdapterOptions successor_options;
        probe.run_case("authorized successor seals new image", [&] {
            auto successor = profile;
            successor.generation = 2U;
            successor.previous_profile_sha256 =
                natrav_overlay::operator_pinned_adapter_profile_sha256(profile);
            successor.executable_sha256 = digest_b;
            successor.arguments = {report_b.string()};
            natrav_overlay::validate_operator_pinned_adapter_profile_transition(
                &profile, successor);
            successor_options =
                natrav_overlay::external_packet_adapter_options_from_profile(
                    successor);
            probe.check(successor_options.pinned_profile->generation == 2U,
                        "authorized successor generation retained");
            exchange_one_packet(successor_options, probe, "B", report_b);
        });

        probe.run_case("prepared image survives locator disappearance", [&] {
            std::filesystem::remove(executable);
            exchange_one_packet(successor_options, probe, "B", report_b);
            probe.check(!std::filesystem::exists(executable),
                        "restart did not re-resolve the removed path");
        });

        std::cout << "{\"format\":\"NATRAV_ADAPTER_PROFILE_INTEGRATION_V1\","
                  << "\"status\":\"PASS\",\"cases\":" << probe.cases().size()
                  << ",\"assertions\":" << probe.assertions()
                  << ",\"case_records\":[";
        for (std::size_t index = 0U; index < probe.cases().size(); ++index) {
            if (index != 0U) {
                std::cout << ',';
            }
            std::cout << "{\"name\":\"" << probe.cases()[index].name
                      << "\",\"assertions\":"
                      << probe.cases()[index].assertions << '}';
        }
        std::cout << "]}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cout << "{\"format\":\"NATRAV_ADAPTER_PROFILE_INTEGRATION_V1\","
                  << "\"status\":\"FAIL\",\"assertions\":"
                  << probe.assertions() << ",\"detail\":\"" << error.what()
                  << "\"}\n";
        return 1;
    }
}
