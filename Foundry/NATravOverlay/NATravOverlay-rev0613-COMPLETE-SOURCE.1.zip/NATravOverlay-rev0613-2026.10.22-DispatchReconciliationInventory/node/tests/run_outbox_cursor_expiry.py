#!/usr/bin/env python3
"""Optional production-clock five-minute OBC1 expiry check, outside normal matrix."""
from __future__ import annotations
import argparse, hashlib, json, time
from pathlib import Path
from run_persistent import Harness
from run_outbox_inspection import setup, submit, query


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error('output must not exist')
    harness = Harness(args.binary, args.output)
    result = {'format': 'NATRAV_OVERLAY_OUTBOX_CURSOR_EXPIRY_V1',
              'binary_sha256': hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
              'clock': 'REAL_MONOTONIC', 'production_lifetime_ms': 300000,
              'status': 'FAIL'}
    try:
        state, _, _, _, daemon, _ = setup(harness, 'expiry')
        for i in range(3):
            submit(harness, f'expiry-{i}', state)
        first = query(harness, 'expiry-first', state, peer='C', limit=1)
        token = first['next_cursor']
        start = time.monotonic()
        query(harness, 'expiry-live', state, peer='C', limit=1, cursor=token)
        # No accelerated clock or production hook; sleep only in this optional test.
        remaining = 300.25 - (time.monotonic() - start)
        if remaining > 0:
            time.sleep(remaining)
        expired = query(harness, 'expiry-old', state, peer='C', limit=1,
                        cursor=token, expected=3)
        harness.check(expired['code'] == 'OUTBOX_CURSOR_EXPIRED',
                      'valid old cursor rejected at real production lifetime')
        fresh = query(harness, 'expiry-new', state, peer='C', limit=1)
        harness.check(fresh['selected_total'] == 3, 'unchanged evidence remains queryable')
        result.update(status='PASS', elapsed_seconds=time.monotonic()-start,
                      rejection_code=expired['code'], fresh_selected_total=3)
        daemon.shutdown()
    except BaseException as error:
        result['failure'] = f'{type(error).__name__}: {error}'
    finally:
        harness.cleanup()
        result['assertions'] = harness.assertions
        result['commands'] = len(harness.commands)
        (harness.output/'EXPIRY.json').write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps(result), flush=True)
    return 0 if result['status']=='PASS' else 1


if __name__=='__main__':
    raise SystemExit(main())
