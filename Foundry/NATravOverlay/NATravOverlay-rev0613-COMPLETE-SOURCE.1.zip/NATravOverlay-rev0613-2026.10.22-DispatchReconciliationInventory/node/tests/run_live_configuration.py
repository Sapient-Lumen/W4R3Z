#!/usr/bin/env python3
"""Owned-process live configuration, durable generation and publication tests."""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import time
from typing import Any, Callable

from run_persistent import Harness, free_port, operation
from run_peer_sessions import submit, outbox_entry
from run_maintenance import inspect


def v7(path: Path, generation: str) -> Path:
    path.write_text(path.read_text().replace("CONFIG_V6", "CONFIG_V7") +
                    f"runtime_generation={generation}\n")
    path.chmod(0o600)
    return path


def candidate(h: Harness, original: Path, name: str, generation: str,
              modify: Callable[[str], str] = lambda s: s) -> Path:
    text = original.read_text()
    lines = [line for line in text.splitlines() if not line.startswith("runtime_generation=")]
    path = h.work / f"{name}.conf"
    path.write_text(modify("\n".join(lines) + "\n") + f"runtime_generation={generation}\n")
    path.chmod(0o600)
    return path


def activate(h: Harness, label: str, state: Path, path: Path,
             expected: int = 0, code: str | None = None) -> dict[str, Any]:
    result = h.run(label, ["config-activate", "--control", str(state / "control.sock"),
                          "--candidate", str(path), "--reason", label,
                          "--deadline-ms", "10000"], expected=expected, timeout=15)
    assert result is not None
    if code: h.check(result.get("code") == code, f"{label}: expected {code}, got {result}")
    return result


def rollback(h: Harness, label: str, state: Path, generation: str,
             expected: int = 0, code: str | None = None) -> dict[str, Any]:
    result = h.run(label, ["config-rollback", "--control", str(state / "control.sock"),
                          "--generation", generation, "--reason", label,
                          "--deadline-ms", "10000"], expected=expected, timeout=15)
    assert result is not None
    if code: h.check(result.get("code") == code, f"{label}: {result}")
    return result


def wait_state(h: Harness, state: Path, op: str, target: str, label: str) -> dict[str, Any]:
    final: dict[str, Any] = {}
    def ready() -> bool:
        final.clear(); final.update(h.status(label, state))
        return outbox_entry(final, op)["status"] == target
    h.wait(label, ready, 12)
    return final


def peers(status: dict[str, Any]) -> dict[str, Any]:
    return {peer["node"]: peer for peer in status["peers"]}


def cases(h: Harness, only: str | None) -> None:
    def canonical_and_validation() -> None:
        state = h.runtime / "canonical"
        conf = v7(h.config("canonical", "A", state, free_port(), []), "a-base")
        base = h.run("canonical-check", ["config-check", "--config", str(conf)])
        assert base
        reorder = h.work / "reordered.conf"
        content = conf.read_text().splitlines()
        reorder.write_text(content[0] + "\n# comment\n" + "\n".join(reversed(content[1:])) + "\n")
        reordered = h.run("canonical-reordered", ["config-check", "--config", str(reorder)])
        h.check(reordered is not None and reordered["runtime_digest"] == base["runtime_digest"],
                "comments, input order and source path do not change canonical digest")
        missing = h.work / "missing.conf"
        missing.write_text("\n".join(line for line in content if not line.startswith("runtime_generation=")) + "\n")
        bad = h.run("missing-generation", ["config-check", "--config", str(missing)], expected=3)
        h.check(bad is not None and bad["code"] == "CONFIG_MISSING_FIELD", "V7 generation required")
        daemon = h.start("canonical", conf, state)
        original = h.status("canonical-state", state)["runtime_configuration"]
        bad_owner = candidate(h, conf, "owner-boundary", "a-owner",
            lambda t: t.replace(f"state={state}", f"state={h.runtime / 'wrong-state'}"))
        activate(h, "owner-boundary-rejected", state, bad_owner, 3, "CONFIG_OWNER_BOUNDARY_CHANGED")
        collision = candidate(h, conf, "generation-collision", "a-base",
            lambda t: t + "session_max_operations=7\n")
        activate(h, "immutable-generation-rejected", state, collision, 3, "CONFIG_GENERATION_CONFLICT")
        malformed = h.work / "malformed.conf"; malformed.write_text(conf.read_text() + "unknown=1\n")
        activate(h, "unknown-field-rejected", state, malformed, 3, "CONFIG_UNKNOWN_FIELD")
        symlink = h.work / "linked.conf"; symlink.symlink_to(conf)
        activate(h, "symlink-rejected", state, symlink, 3, "CONFIG_OPEN_FAILED")
        changed = h.status("canonical-after-rejections", state)["runtime_configuration"]
        h.check(changed["generation"] == original["generation"] and changed["digest"] == original["digest"],
                "rejected candidates leave active generation unchanged")
        h.check(changed["event_count"] == 5, "all four candidate failures journaled")
        daemon.shutdown()
        unseen = candidate(h, conf, "startup-unseen", "unaccepted")
        result = h.run("startup-unrecorded", ["run", "--config", str(unseen)], expected=3)
        h.check(result is not None and result["code"] == "CONFIG_STARTUP_NOT_RECORDED",
                "an unaccepted startup file cannot bypass durable activation")
        restored = h.start("canonical-accepted-restart", conf, state)
        h.check(h.status("canonical-restart-history", state)["runtime_configuration"]["generation"] == "a-base",
                "refused startup preserves prior generation")
        restored.shutdown()

    def selective_sessions_route_removal_and_rollback() -> None:
        a, b, c = (h.runtime / n for n in ("select-a", "select-b", "select-c"))
        bp, cp = free_port(), free_port()
        ac = v7(h.config("select-a", "A", a, free_port(),
                        [("B", bp, 50, 100, 100, 60000), ("C", cp, 50, 100, 100, 60000)]), "a-g1")
        # Keep idle sessions long enough to observe reuse independently of polling.
        ac.write_text(ac.read_text()+"session_idle_timeout_ms=10000\n")
        bc = v7(h.config("select-b", "B", b, bp, [], trusted=["A"]), "b-g1")
        cc = v7(h.config("select-c", "C", c, cp, [], trusted=["A"]), "c-g1")
        for cfg in (bc, cc): cfg.write_text(cfg.read_text()+"session_idle_timeout_ms=10000\n")
        bd=h.start("select-b",bc,b); cd=h.start("select-c",cc,c); ad=h.start("select-a",ac,a)
        for peer in ("B", "C"):
            op=operation("select-warm"+peer)
            submit(h,"select-warm"+peer,ad.control,"A",peer,"test/three",op,"warm")
            wait_state(h,a,op,"ACKED","select-warm-ack"+peer)
        before=peers(h.status("select-before",a))
        absent=free_port()
        g2=candidate(h,ac,"select-a2","a-g2",lambda t:t.replace(f"peer=B,127.0.0.1:{bp},",f"peer=B,127.0.0.1:{absent},"))
        activate(h,"select-activate",a,g2)
        opb=operation("select-pending-b")
        submit(h,"select-pending",ad.control,"A","B","test/three",opb,"owed-to-B")
        opc=operation("select-after-c")
        submit(h,"select-C-progress",ad.control,"A","C","test/three",opc,"unaffected")
        after=wait_state(h,a,opc,"ACKED","select-C-ack")
        h.check(peers(after)["C"]["session"]["opened"]==before["C"]["session"]["opened"], "unchanged C session not reopened")
        h.check(peers(after)["C"]["opened_configuration_event"]==1,"unchanged session retains opening generation")
        h.check(peers(after)["B"]["configuration_drains"]==1,"only B contract drained")
        g3=candidate(h,g2,"select-a3","a-g3",lambda t:"\n".join(x for x in t.splitlines() if not x.startswith("peer=B,"))+"\n")
        activate(h,"remove-B-route",a,g3)
        st=h.status("select-unresolved",a)
        h.check(st["outbox"]["unresolved"]==1 and outbox_entry(st,opb)["peer_generation"]=="b-g1", "removed route preserves exact unresolved generation")
        attempts=outbox_entry(st,opb)["attempts"]
        time.sleep(.25)
        h.check(outbox_entry(h.status("select-no-route-attempts",a),opb)["attempts"]==attempts,"removed route consumes no delivery attempts")
        ad.kill(); ad=h.start("select-a-restart",ac,a)
        h.check(h.status("select-reconstructed",a)["runtime_configuration"]["generation"]=="a-g3","stale seed cannot roll back durable active generation")
        activate(h,"old-file-needs-explicit-rollback",a,ac,3,"CONFIG_GENERATION_ALREADY_ACCEPTED")
        rollback(h,"explicit-route-rollback",a,"a-g1")
        final=wait_state(h,a,opb,"ACKED","select-B-recovered")
        h.check(final["runtime_configuration"]["events"][-1]["kind"]=="ROLLBACK","rollback attributable")
        h.check(h.status("select-B-records",b)["inbound_records"]==2,"B admits pending item once")
        ad.shutdown();bd.shutdown();cd.shutdown()
        saved=inspect(h,"select-offline",a,"A")["runtime_configuration"]
        bindings=[x for x in saved["bindings"] if x["operation_id"]==opb and x["journal_kind"] ==24]
        h.check(len(bindings)==1 and all(x["configuration_event"]==2 for x in bindings),"queue and policy retain original configuration, not rollback")

    def receiver_policy_activation() -> None:
        a,b,c=(h.runtime/n for n in ("policy-a","policy-b","policy-c"));bp=free_port()
        ac=h.config("policy-a","A",a,free_port(),[("B",bp,30,60,100,60000)])
        cc=h.config("policy-c","C",c,free_port(),[("B",bp,30,60,100,60000)])
        bc=v7(h.config("policy-b","B",b,bp,[],trusted=["A","C"]),"policy-1")
        for p in (ac,bc,cc):p.write_text(p.read_text()+"session_idle_timeout_ms=10000\n")
        bd=h.start("policy-b",bc,b);ad=h.start("policy-a",ac,a);cd=h.start("policy-c",cc,c)
        for who,sd,daemon in (("A",a,ad),("C",c,cd)):
            op=operation("policy-warm"+who)
            submit(h,"policy-warm"+who,daemon.control,who,"B","test/three",op,"allowed")
            wait_state(h,sd,op,"ACKED","policy-warm-ack"+who)
        c_before=peers(h.status("policy-c-before",c))["B"]["session"]["opened"]
        tight=candidate(h,bc,"policy-tight","policy-2",lambda t:t.replace("authorize=A,*,EVIDENCE,test/three\n",""))
        activate(h,"policy-tighten",b,tight)
        denied=operation("policy-denied")
        submit(h,"policy-denied",ad.control,"A","B","test/three",denied,"not authorized now")
        wait_state(h,a,denied,"REJECTED","policy-terminal-denial")
        c_new=operation("policy-c-new")
        submit(h,"policy-C-unaffected",cd.control,"C","B","test/three",c_new,"still allowed")
        c_status=wait_state(h,c,c_new,"ACKED","policy-C-ack")
        h.check(peers(c_status)["B"]["session"]["opened"]==c_before,"receiver change for A preserves C session")
        bst=h.status("policy-b-tight-status",b)
        h.check(bst["inbound_records"]==3 and bst["authorization"]["denied"]==1,"tightened policy denies before admission")
        loose=candidate(h,bc,"policy-loose","policy-3")
        activate(h,"policy-loosen",b,loose)
        h.run("policy-explicit-retry",["retry","--control",str(ad.control),"--operation",denied,"--reason","policy deliberately restored"])
        wait_state(h,a,denied,"ACKED","policy-retry-ack")
        ad.shutdown();cd.shutdown();bd.shutdown()
        offline=inspect(h,"policy-offline",b,"B")
        bound=offline["runtime_configuration"]["bindings"]
        h.check(any(x["operation_id"]==denied and x["journal_kind"]==12 and x["configuration_event"]==2 for x in bound),"denial binds tightened generation")
        h.check(any(x["operation_id"]==denied and x["journal_kind"]==11 and x["configuration_event"]==3 for x in bound),"later admission binds loosened generation")

    def limits_revocation_and_history() -> None:
        a=h.runtime/"limits-a";port=free_port()
        ac=v7(h.config("limits-a","A",a,free_port(),[("B",port,50,100,100,60000)]),"limits-1")
        ad=h.start("limits-a",ac,a)
        op=operation("limits-pending")
        submit(h,"limits-pending",ad.control,"A","B","test/three",op,"four")
        small=candidate(h,ac,"limits-small","limits-2",lambda t:t+"outbox_global_max_payload_bytes=3\noutbox_peer_max_payload_bytes=3\n")
        activate(h,"limits-reject-below-use",a,small,3,"CONFIG_OUTBOX_BELOW_USAGE")
        h.check(h.status("limits-original",a)["outbox"]["reservations"]["pending_payload_bytes"]==4,"failed quota change preserves reservation")
        new=h.identity("B-new")
        revoke=candidate(h,ac,"limits-revoke","limits-revoked",lambda t:t.replace("peer_key=B,b-g1,ACTIVE,","peer_key=B,b-g1,REVOKED,")+f"peer_key=B,b-g2,ACTIVE,{new.spki_sha256}\n")
        activate(h,"limits-revoke-key",a,revoke)
        st=h.status("limits-revoked-status",a)
        h.check(st["outbox"]["unresolved"]==1,"revoked pending obligation unresolved, not redirected")
        h.check(outbox_entry(st,op)["peer_generation"]=="b-g1","original bound generation survives rotation")
        rollback(h,"revocation-cannot-rollback",a,"limits-1",3,"CONFIG_REVOCATION_ROLLBACK")
        changed=candidate(h,revoke,"limits-redefined","limits-redefined",lambda t:t.replace(f"peer_key=B,b-g2,ACTIVE,{new.spki_sha256}",f"peer_key=B,b-g2,ACTIVE,{h.identity('B-third').spki_sha256}"))
        activate(h,"key-name-cannot-redefine",a,changed,3,"CONFIG_HISTORICAL_KEY_CONFLICT")
        ad.kill();ad=h.start("limits-restart",ac,a)
        h.check(h.status("limits-restored",a)["runtime_configuration"]["generation"]=="limits-revoked","restart cannot resurrect revoked generation")
        h.run("limits-cancel",["cancel","--control",str(ad.control),"--operation",op,"--reason","retire unresolved test obligation"])
        ad.shutdown()

    def compaction_backup_and_binding_validation() -> None:
        a,b=h.runtime/"maint-a",h.runtime/"maint-b";bp=free_port()
        ac=v7(h.config("maint-a","A",a,free_port(),[("B",bp,50,100,100,60000)]),"maint-1")
        bc=v7(h.config("maint-b","B",b,bp,[],trusted=["A"]),"maint-b1")
        bd=h.start("maint-b",bc,b);ad=h.start("maint-a",ac,a)
        first=operation("maint-first")
        submit(h,"maint-first",ad.control,"A","B","test/three",first,"before")
        wait_state(h,a,first,"ACKED","maint-first-ack")
        nextcfg=candidate(h,ac,"maint-next","maint-2",lambda t:t+"session_max_operations=5\n")
        activate(h,"maint-activate",a,nextcfg)
        second=operation("maint-second")
        submit(h,"maint-second",ad.control,"A","B","test/three",second,"after")
        wait_state(h,a,second,"ACKED","maint-second-ack")
        before=h.status("maint-before",a)
        h.run("maint-compact",["compact","--control",str(ad.control)])
        after=h.status("maint-after",a)
        h.check(before["storage"]["logical_state_digest"]==after["storage"]["logical_state_digest"],"live compaction preserves configuration history and mutation stamps")
        ad.shutdown();bd.shutdown()
        identity=h.identity("A"); backup=h.work/"live-config.nob"
        h.run("maint-export",["backup-export","--state",str(a),"--node","A","--generation","a-g1","--output",str(backup),"--sign-key",str(identity.private_key),"--sign-cert",str(identity.certificate)])
        h.run("maint-verify",["backup-verify","--input",str(backup),"--node","A","--generation","a-g1","--trusted-cert",str(identity.certificate),"--require-signature","yes"])
        original=h.runtime/"maint-original";a.rename(original)
        h.run("maint-restore",["backup-restore","--input",str(backup),"--destination",str(a),"--node","A","--generation","a-g1","--trusted-cert",str(identity.certificate),"--require-signature","yes"])
        restored=inspect(h,"maint-restored",a,"A")
        # Inspect retains the canonical logical digest under storage.
        h.check(restored["storage"]["logical_state_digest"]==before["storage"]["logical_state_digest"],"signed restore retains exact logical state")
        ad=h.start("maint-restored-daemon",ac,a)
        h.check(h.status("maint-restored-active",a)["runtime_configuration"]["generation"]=="maint-2","restored daemon resumes durable active generation")
        ad.shutdown()
        # Corrupt a generation reference while repairing the non-keyed checksum.
        # This must fail semantic validation, not merely checksum comparison.
        # Use a separate uncompacted mutation to exercise the envelope checker.
        isolated=h.runtime/"binding-source"
        ic=v7(h.config("binding-source","Z",isolated,free_port(),[("B",free_port(),50,100,100,60000)]),"binding-1")
        iz=h.start("binding-source",ic,isolated)
        submit(h,"binding-submit",iz.control,"Z","B","test/three",operation("binding-test"),"x")
        iz.shutdown()
        original_data=(isolated/"state.journal").read_bytes()
        data=bytearray(original_data);offset=0;changed=False
        while offset<len(data):
            length=struct.unpack("!I",data[offset+4:offset+8])[0]
            if data[offset+8]==23:
                data[offset+9:offset+17]=b"\0"*8
                body=bytes(data[offset+8:offset+8+length])
                data[offset+8+length:offset+8+length+32]=hashlib.sha256(b"NATRAV_OVERLAY_JOURNAL_RECORD_V1\0"+body).digest()
                changed=True;break
            offset+=8+length+32
        h.check(changed,"located real configuration-bound journal mutation")
        (isolated/"state.journal").write_bytes(data)
        failed=h.run("binding-reference-corrupt",["inspect","--state",str(isolated),"--node","Z"],expected=3)
        h.check(failed is not None and failed["code"]=="JOURNAL_CORRUPT","wrong generation reference fails semantic replay")
        body=original_data[offset+8:offset+8+length]
        unbound=body[9:]
        replacement=b"NOJ1"+struct.pack("!I",len(unbound))+unbound+hashlib.sha256(b"NATRAV_OVERLAY_JOURNAL_RECORD_V1\0"+unbound).digest()
        (isolated/"state.journal").write_bytes(original_data[:offset]+replacement+original_data[offset+8+length+32:])
        failed=h.run("binding-stripped",["inspect","--state",str(isolated),"--node","Z"],expected=3)
        h.check(failed is not None and failed["code"]=="JOURNAL_CORRUPT","stripped configuration stamp cannot become a legacy mutation")

    def publication_kill_boundaries() -> None:
        for stage in ("AFTER_VALIDATION","AFTER_COMMIT"):
            state=h.runtime/("kill-"+stage.lower())
            cfg=v7(h.config("kill-"+stage,"A",state,free_port(),[]),"kill-1")
            path=candidate(h,cfg,"kill-next-"+stage,"kill-2",lambda t:t+"session_max_operations=7\n")
            env={"NATRAV_OVERLAY_TEST_CONFIG_"+stage+"_MS":"10000"}
            daemon=h.start("kill-"+stage,cfg,state,env)
            command=[str(h.binary),"config-activate","--control",str(daemon.control),"--candidate",str(path),"--reason","publication boundary test","--deadline-ms","30000"]
            child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            try:
                marker="NATRAV_OVERLAY_TEST_CONFIG_"+stage+"_MS"
                h.wait("publication marker "+stage,lambda:marker in daemon.stderr_path.read_text(),5)
                daemon.kill();out,err=child.communicate(timeout=5)
                h.check(child.returncode!=0,"control caller observes unknown outcome after kill")
                h.commands.append({"label":"kill-boundary-"+stage,"args":command[1:],"returncode":child.returncode,"stdout":out,"stderr":err})
            finally:
                if child.poll() is None:child.kill();child.wait()
            restarted=h.start("restart-"+stage,cfg,state)
            account=h.status("boundary-reconstruction-"+stage,state)["runtime_configuration"]
            expected="kill-1" if stage=="AFTER_VALIDATION" else "kill-2"
            h.check(account["generation"]==expected,"journal publication determines active generation at "+stage)
            restarted.shutdown()


    def admitted_action_budget_continuity() -> None:
        a,b=h.runtime/"action-a",h.runtime/"action-b";bp=free_port()
        ac=h.config("action-a","A",a,free_port(),[("B",bp,50,100,100,60000)])
        bc=v7(h.config("action-b","B",b,bp,[],trusted=["A"]),"action-1")
        bc.write_text(bc.read_text()+"authorize=A,*,ACTION,counter.add\n")
        bd=h.start("action-b",bc,b);ad=h.start("action-a",ac,a)
        op=operation("live-budget-action")
        h.run("action-admit",["action-submit","--control",str(ad.control),"--node","A","--peer","B","--operation",op,"--amount","7","--defer-ms","5000"])
        wait_state(h,a,op,"ACKED","action-admission-receipt")
        h.check(h.status("action-reserved",b)["actions"]["reserved_amount"]==7,"deferred action has durable old-budget reservation")
        larger=candidate(h,bc,"action-larger","action-2",lambda t:t+"action_counter_budget=2000\n")
        activate(h,"old-budget-work-prevents-increase",b,larger,3,"CONFIG_ACTION_OBLIGATIONS_PRESENT")
        h.run("action-cancel-before-budget-change",["action-cancel","--control",str(bd.control),"--action",op,"--reason","resolve old-budget obligation before expansion"])
        activate(h,"budget-increase-after-resolution",b,larger)
        newop=operation("new-budget-action")
        h.run("new-budget-action",["action-submit","--control",str(ad.control),"--node","A","--peer","B","--operation",newop,"--amount","8"])
        wait_state(h,a,newop,"ACKED","new-budget-action-ack")
        h.wait("new-budget-counter-completed",lambda:h.status("new-budget-counter",b)["actions"]["counter_value"]==8)
        final=h.status("action-final",b)
        h.check(final["actions"]["cancelled"]==1 and final["actions"]["executed"]==1,"cancelled old-budget effect was not executed")
        ad.shutdown();bd.shutdown()
        saved=inspect(h,"action-bindings",b,"B")["runtime_configuration"]
        h.check(any(x["operation_id"]==newop and x["journal_kind"]==11 and x["configuration_event"]==3 for x in saved["bindings"]),"new action admission binds accepted budget generation, skipping rejected candidate")

    def concurrent_submissions_publication() -> None:
        a,b=h.runtime/"race-a",h.runtime/"race-b";bp=free_port()
        ac=v7(h.config("race-a","A",a,free_port(),[("B",bp,50,100,100,60000)]),"race-1")
        bc=v7(h.config("race-b","B",b,bp,[],trusted=["A"]),"race-b1")
        nextcfg=candidate(h,ac,"race-next","race-2",lambda t:t+"session_max_operations=7\n")
        bd=h.start("race-b",bc,b);ad=h.start("race-a",ac,a)
        pre=operation("race-before")
        submit(h,"race-before",ad.control,"A","B","test/three",pre,"before")
        def run_one(i: int) -> dict[str, Any]:
            args=["submit","--control",str(ad.control),"--node","A","--peer","B","--scope","test/three",
                  "--operation",operation("race-"+str(i)),"--payload-text",str(i),"--deadline-ms","5000"]
            result=subprocess.run([str(h.binary),*args],capture_output=True,text=True,timeout=8,env=os.environ.copy())
            return {"label":"concurrent-submit-"+str(i),"args":args,"returncode":result.returncode,"stdout":result.stdout,"stderr":result.stderr}
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            jobs=[pool.submit(run_one,i) for i in range(16)]
            activate(h,"concurrent-activation",a,nextcfg)
            results=[job.result() for job in jobs]
        h.commands.extend(results)
        for result in results:
            h.check(result["returncode"]==0 and json.loads(result["stdout"])["ok"],"concurrent submission remains usable")
        post=operation("race-after")
        submit(h,"race-after",ad.control,"A","B","test/three",post,"after")
        h.wait("all concurrent work acknowledged",lambda:h.status("race-drained",a)["outbox"]["acked"]==18,12)
        h.check(h.status("race-no-duplicates",b)["inbound_records"]==18,"all 18 operations admitted once across publication")
        ad.shutdown();bd.shutdown()
        history=inspect(h,"race-reconstruct",a,"A")["runtime_configuration"]
        for op in [pre,post]+[operation("race-"+str(i)) for i in range(16)]:
            stamps=[x["configuration_event"] for x in history["bindings"] if x["operation_id"]==op and x["journal_kind"] ==24]
            h.check(len(stamps)==1 and len(set(stamps))==1,"queue and policy cannot straddle configuration publication")
            if op==pre:h.check(stamps[0]==1,"pre-publication operation keeps original generation")
            if op==post:h.check(stamps[0]==2,"post-publication operation uses active generation")

    names = [
        ("canonical_and_validation", canonical_and_validation),
        ("selective_sessions_route_removal_and_rollback", selective_sessions_route_removal_and_rollback),
        ("receiver_policy_activation", receiver_policy_activation),
        ("limits_revocation_and_history", limits_revocation_and_history),
        ("compaction_backup_and_binding_validation", compaction_backup_and_binding_validation),
        ("publication_kill_boundaries", publication_kill_boundaries),
        ("admitted_action_budget_continuity", admitted_action_budget_continuity),
        ("concurrent_submissions_publication", concurrent_submissions_publication),
    ]
    for name, function in names:
        if only is None or only==name:h.case(name,function)
    if only and not any(name==only for name,_ in names):raise ValueError("unknown case")


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary",type=Path,default=Path("node/bin/natrav-overlay"))
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--case")
    args=parser.parse_args()
    if args.output.exists():parser.error("output must not exist")
    h=Harness(args.binary,args.output);started=time.time();code=1
    try:cases(h,args.case);code=0
    except BaseException as exc:
        (h.output/"FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}",file=sys.stderr)
    finally:
        h.cleanup()
        summary={"format":"NATRAV_OVERLAY_LIVE_CONFIGURATION_TESTS_V1","status":"PASS" if code==0 else "FAIL",
                 "binary_sha256":hashlib.sha256(h.binary.read_bytes()).hexdigest(),"cases_total":len(h.cases),
                 "cases_passed":sum(c["status"]=="PASS" for c in h.cases),"assertions":h.assertions,
                 "commands":len(h.commands),"started_unix":started,"elapsed_seconds":time.time()-started}
        for name,value in (("SUMMARY",summary),("CASES",h.cases),("COMMANDS",h.commands)):
            (h.output/(name+".json")).write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")
        print(json.dumps(summary,sort_keys=True))
    return code

if __name__=="__main__":raise SystemExit(main())
