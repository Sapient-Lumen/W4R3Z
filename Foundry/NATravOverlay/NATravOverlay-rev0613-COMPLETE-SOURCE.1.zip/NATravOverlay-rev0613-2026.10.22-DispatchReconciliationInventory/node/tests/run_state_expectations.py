#!/usr/bin/env python3
"""Exact external authenticated-head checks on owned local C++ fixtures.

Selectors are reconstructed from independently authenticated raw journal bytes,
not copied from the product's JSON. No network targets other than configured
loopback test peers are used. An old selector plus old state remains an explicit
limit: independent custody and selection of the expected value are external.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import time
from typing import Any

from run_persistent import Harness, free_port, operation
from run_state_authentication import (inspect, new_key, migrate, KeyedDaemon,
    independent_open, independent_seal)
from run_authenticated_recovery import setup, audit, incomplete_next, recover_args, file_accounts
from run_live_configuration import v7
from run_relocation import relocated_config, copy_identity

CASES = ("selector_and_parser", "equal_length_divergence", "rollback_and_append",
    "authentication_and_semantics", "startup_and_compaction", "rotation",
    "prefix_recovery", "encrypted_backup_and_relocation")


def selector(raw: bytes, key: Path) -> str:
    """Independent HMAC validation and big-endian header field extraction."""
    header, frames, root, _ = independent_open(raw, key)
    body = header[12:-32]
    assert int.from_bytes(body[:4], "big") in (1, 2)
    assert body[4:8] == (2).to_bytes(4, "big")
    at = 8
    def text() -> str:
        nonlocal at
        n = int.from_bytes(body[at:at+2], "big"); at += 2
        value = body[at:at+n].decode("ascii"); at += n
        return value
    node, generation = text(), text()
    key_id = body[at:at+32].hex(); epoch = body[at+32:at+64].hex()
    return ":".join(("NASH1", node, generation, key_id, epoch, root.hex(), str(len(frames)), str(len(raw))))


def selected(h: Harness, label: str, state: Path, key: Path, pin: str, expected: int = 0) -> dict[str, Any]:
    value = h.run(label, ["inspect", "--state", str(state), "--node", "A", "--state-auth-key", str(key),
        "--expected-state-head", pin], expected=expected)
    assert value
    return value


def changed(pin: str, field: int, value: str | None = None) -> str:
    fields = pin.split(":")
    fields[field] = value if value is not None else ("1" if fields[field][0] != "1" else "2") + fields[field][1:]
    return ":".join(fields)


def append(h: Harness, state: Path, key: Path, name: str, pin: str | None = None) -> None:
    # The command durably queues evidence before its connection attempt. Reserve
    # an owned non-listening socket, rather than addressing an arbitrary service.
    import socket
    with socket.socket() as reserved:
        reserved.bind(("127.0.0.1", 0))
        port = reserved.getsockname()[1]
        args = ["offer", "--state", str(state), "--node", "A", "--peer", "B", "--connect", f"127.0.0.1:{port}",
            "--scope", "test/three", "--operation", operation(name), "--payload-text", "payload", "--deadline-ms", "100",
            "--state-auth-key", str(key)]
        if pin is not None: args += ["--expected-state-head", pin]
        value = h.run("append-" + name, args, expected=3)
        h.check(value is not None and value.get("code") not in ("STATE_HEAD_EXPECTATION_MISMATCH", "STATE_AUTH_REQUIRED"),
            "matching input permits ordinary durable admission before unavailable route")


class ExpectedDaemon(KeyedDaemon):
    def __init__(self, h: Harness, name: str, config: Path, state: Path, key: Path, pin: str):
        super().__init__(h, name, config, state, key)
        self.pin = pin

    def start(self) -> None:
        self.stdout_file = self.stdout_path.open("w"); self.stderr_file = self.stderr_path.open("w")
        self.process = subprocess.Popen([str(self.harness.binary), "run", "--config", str(self.config),
            "--state-auth-key", str(self.key), "--expected-state-head", self.pin],
            stdout=self.stdout_file, stderr=self.stderr_file, text=True, env=dict(os.environ))
        try:
            self.harness.wait("expected daemon " + self.name, lambda: bool(self.process and self.process.poll() is None
                and self.control.is_socket() and "RUNTIME_READY" in self.stdout_path.read_text()), 8)
        except BaseException:
            self.cleanup()
            raise AssertionError(self.stdout_path.read_text() + self.stderr_path.read_text())
        self.harness.check(stat.S_IMODE(self.control.stat().st_mode) == 0o600, "expected startup preserves control custody")


def start_expected(h: Harness, name: str, conf: Path, state: Path, key: Path, pin: str) -> ExpectedDaemon:
    d = ExpectedDaemon(h, name, conf, state, key, pin); h.daemons.append(d); d.start(); return d


def run_suite(h: Harness, selected_cases: set[str] | None) -> None:
    def case(name: str, fn: Any) -> None:
        if selected_cases is None or name in selected_cases: h.case(name, fn)

    def selector_and_parser() -> None:
        root, state, key = setup(h, "selector")
        raw = (state / "state.journal").read_bytes(); pin = selector(raw, key)
        ordinary = inspect(h, "head-without-expectation", state, key)
        h.check(ordinary["state_head"]["selector"] == pin, "selector exactly matches independent authenticated byte decoder")
        h.check(ordinary["state_head"]["freshness"] == "NOT_ESTABLISHED", "an observed head is not its own freshness anchor")
        for i in range(2):
            value = selected(h, f"exact-{i}", state, key, pin)
            h.check(value["state_head"]["expectation"] == "MATCH" and
                value["state_head"]["freshness"] == "MATCHED_SUPPLIED_EXPECTATION", "exact explicit expectation is scoped and reported")
            h.check(value["state_head"]["automatic_update"] is False, "expectation is never automatically advanced")
        stale = state / "state.journal.compact.tmp"; stale.write_bytes(b"unpublished candidate"); stale.chmod(0o600)
        before = file_accounts(state)
        for field, value in ((1, "Other"), (2, "other-generation"), (3, None), (4, None), (5, None),
                             (6, "2"), (7, str(len(raw)+1))):
            bad = selected(h, f"field-{field}", state, key, changed(pin, field, value), 3)
            h.check(bad["code"] == "STATE_HEAD_EXPECTATION_MISMATCH", "each exact identity/head account is enforced")
            h.check(file_accounts(state) == before, "mismatch preserves source and stale candidate")
        invalid = ["", "NASH2" + pin[5:], pin + ":extra", pin.rsplit(":", 1)[0], " " + pin, pin + "\n", "x" * 513]
        invalid += [changed(pin, 1, "bad node"), changed(pin, 2, ".."), changed(pin, 3, "0"*64),
            changed(pin, 4, "G"*64), changed(pin, 5, "a"*63), changed(pin, 5, "A"*64)]
        for field in (6, 7):
            invalid += [changed(pin, field, v) for v in ("0", "01", "+1", "-1", "1 ", "", "1073741825", "18446744073709551616")]
        for i, malformed in enumerate(invalid):
            value = selected(h, f"invalid-{i}", state, key, malformed, 3)
            h.check(value["code"] == "STATE_HEAD_EXPECTATION_INVALID", "noncanonical selector rejected before state access")
        h.check(file_accounts(state) == before, "parser rejection preserves all existing source accounts")
        no_key = h.run("selector-without-key", ["inspect", "--state", str(state), "--node", "A", "--expected-state-head", pin], expected=3)
        h.check(no_key and no_key["code"] == "STATE_AUTH_KEY_REQUIRED", "selector is not a state authentication key")
        mixed = audit(h, "mixed-head-alternatives", state, key, 3,
            ["--expected-state-head", pin, "--expected-root", pin.split(":")[5], "--expected-records", "1"])
        h.check(mixed["code"] == "STATE_HEAD_EXPECTATION_INVALID", "legacy and typed alternatives cannot be combined")
        unkeyed = root / "unkeyed"; inspect(h, "unkeyed-create", unkeyed)
        unkeyed_raw = (unkeyed / "state.journal").read_bytes()
        value = selected(h, "unkeyed-no-upgrade", unkeyed, key, pin, 3)
        h.check(value["code"] in ("STATE_AUTH_REQUIRED", "STATE_AUTH_TRUNCATED"), "expectation never adopts unkeyed state")
        h.check((unkeyed / "state.journal").read_bytes() == unkeyed_raw, "no unkeyed mutation")
        selected(h, "missing-state", root / "missing", key, pin, 3)
        h.check(not (root / "missing").exists(), "expected startup never creates missing state")
    case("selector_and_parser", selector_and_parser)

    def equal_length_divergence() -> None:
        root, state, key = setup(h, "divergent")
        alternate = root / "alternate"; shutil.copytree(state, alternate)
        append(h, state, key, "diverge-left"); append(h, alternate, key, "diverge-rght")
        left = (state / "state.journal").read_bytes(); right = (alternate / "state.journal").read_bytes()
        left_pin, right_pin = selector(left, key), selector(right, key)
        l, r = left_pin.split(":"), right_pin.split(":")
        h.check(len(left) == len(right) and l[:5] == r[:5] and l[6:] == r[6:] and l[5] != r[5],
            "legitimate same-key same-epoch same-count same-length branches differ only in root")
        selected(h, "left-exact", state, key, left_pin)
        # Narrow negative control removes only expected.root comparison.
        try:
            value = selected(h, "equal-size-divergent-head", alternate, key, left_pin, 3)
        finally:
            after = (alternate / "state.journal").read_bytes()
            (h.output / "DIVERGENCE-BOUNDARY.json").write_text(json.dumps({
                "expected_root": l[5], "actual_root": r[5], "equal_nonroot_accounts": l[:5] == r[:5] and l[6:] == r[6:],
                "input_sha256": hashlib.sha256(right).hexdigest(), "after_sha256": hashlib.sha256(after).hexdigest(),
                "input_unchanged": after == right}, indent=2) + "\n")
            h.check(after == right, "divergent comparison leaves original bytes unchanged, including under the negative control")
        h.check(value["code"] == "STATE_HEAD_EXPECTATION_MISMATCH", "exact root rejects equal-sized divergent valid history")
        selected(h, "right-exact", alternate, key, right_pin)
    case("equal_length_divergence", equal_length_divergence)

    def rollback_and_append() -> None:
        root, state, key = setup(h, "rollback")
        journal = state / "state.journal"; old = journal.read_bytes(); old_pin = selector(old, key)
        append(h, state, key, "advance", old_pin)
        current = journal.read_bytes(); current_pin = selector(current, key)
        h.check(old_pin != current_pin, "ordinary accepted append advances head")
        h.check(selected(h, "newer-also-not-exact", state, key, old_pin, 3)["code"] == "STATE_HEAD_EXPECTATION_MISMATCH",
            "newer valid state is not an exact old expectation match")
        journal.write_bytes(old)
        h.check(inspect(h, "unanchored-rollback", state, key)["state_head"]["freshness"] == "NOT_ESTABLISHED", "absence preserves rollback compatibility")
        h.check(selected(h, "anchored-rollback", state, key, current_pin, 3)["code"] == "STATE_HEAD_EXPECTATION_MISMATCH", "protected later selector rejects old valid snapshot")
        h.check(journal.read_bytes() == old, "rejected rollback is not repaired or advanced")
        h.check(selected(h, "old-plus-old-limit", state, key, old_pin)["state_head"]["expectation"] == "MATCH", "old selector plus old state still matches: custody is external")
        journal.write_bytes(current); selected(h, "current-restored", state, key, current_pin)
    case("rollback_and_append", rollback_and_append)

    def authentication_and_semantics() -> None:
        root, state, key = setup(h, "semantics")
        append(h, state, key, "semantic-record")
        journal = state / "state.journal"; good = journal.read_bytes(); pin = selector(good, key)
        bad = good[:-1] + bytes([good[-1] ^ 1]); journal.write_bytes(bad)
        value = selected(h, "bad-mac-cannot-match", state, key, pin, 3)
        h.check(value["code"] == "STATE_AUTH_TAG_MISMATCH", "authentication remains before head equality")
        h.check(journal.read_bytes() == bad, "bad MAC never repairs input")
        invalid_audit = audit(h, "bad-mac-audit-preserves-cause", state, key, 3, ["--expected-state-head", pin])
        h.check(invalid_audit["status"] == "INVALID" and invalid_audit["code"] == "STATE_AUTH_TAG_MISMATCH",
            "an expectation never conceals the native authentication failure")
        header, frames, _, _ = independent_open(good, key)
        invalid = independent_seal(header, frames + [frames[-1]], key)
        invalid_pin = selector(invalid, key); journal.write_bytes(invalid)
        value = selected(h, "exact-pin-invalid-semantics", state, key, invalid_pin, 3)
        h.check(value["code"] == "JOURNAL_CORRUPT", "matching correctly authenticated head never bypasses duplicate-operation semantics")
        h.check(journal.read_bytes() == invalid, "semantic rejection does not mutate source")
        semantic_audit = audit(h, "semantic-audit-preserves-cause", state, key, 3, ["--expected-state-head", invalid_pin])
        h.check(semantic_audit["code"] == "JOURNAL_CORRUPT" and semantic_audit["state_head"] is None,
            "invalid semantic history supplies no validated head account")
        journal.write_bytes(good)
        wrong = new_key(h, root, "wrong-state-key")
        h.check(selected(h, "exact-pin-wrong-secret", state, wrong, pin, 3)["code"] == "STATE_AUTH_TAG_MISMATCH", "selector cannot replace secret verification")
    case("authentication_and_semantics", authentication_and_semantics)

    def startup_and_compaction() -> None:
        root, state, key = setup(h, "startup")
        pin = selector((state / "state.journal").read_bytes(), key)
        conf = h.config("expected-start", "A", state, free_port(), [])
        before = file_accounts(state)
        rejected = h.run("daemon-before-listening", ["run", "--config", str(conf), "--state-auth-key", str(key),
            "--expected-state-head", changed(pin, 5)], expected=3)
        h.check(rejected and rejected["code"] == "STATE_HEAD_EXPECTATION_MISMATCH", "startup rejects mismatched state")
        h.check(not (state / "control.sock").exists() and file_accounts(state) == before, "rejected startup creates no control socket or durable event")
        d = start_expected(h, "matched-start", conf, state, key, pin)
        h.run("expected-live-compact", ["compact", "--control", str(d.control)])
        d.shutdown()
        post = (state / "state.journal").read_bytes(); post_pin = selector(post, key)
        h.check(post_pin.split(":")[4] != pin.split(":")[4], "compaction creates distinct authenticated epoch")
        h.check(selected(h, "precompact-pin-stale", state, key, pin, 3)["code"] == "STATE_HEAD_EXPECTATION_MISMATCH", "compaction does not silently replace external expectation")
        selected(h, "postcompact-pin-exact", state, key, post_pin)
        again = start_expected(h, "compacted-start", conf, state, key, post_pin); again.shutdown()
    case("startup_and_compaction", startup_and_compaction)

    def rotation() -> None:
        root, state, key = setup(h, "rotation-expectation")
        journal = state / "state.journal"; before = journal.read_bytes(); pin = selector(before, key)
        next_key = new_key(h, root, "next-auth-generation")
        args = ["state-auth-rotate", "--state", str(state), "--node", "A", "--state-auth-key", str(key),
            "--new-key", str(next_key), "--reason", "explicit expected predecessor"]
        value = h.run("rotate-reject-wrong-head", args + ["--expected-state-head", changed(pin, 5)], expected=3)
        h.check(value and value["code"] == "STATE_HEAD_EXPECTATION_MISMATCH" and journal.read_bytes() == before, "rotation requires exact old input without mutation on mismatch")
        rotated = h.run("rotate-exact-head", args + ["--expected-state-head", pin]); assert rotated
        next_pin = selector(journal.read_bytes(), next_key)
        h.check(rotated["state_head"]["selector"] == next_pin and rotated["state_head"]["freshness"] == "NOT_ESTABLISHED", "new key head exported but not self-anchored")
        h.check(rotated["input_expectation"] == "MATCHED_AT_OPEN", "rotation reports only input check")
        h.check(selected(h, "new-key-old-expectation", state, next_key, pin, 3)["code"] == "STATE_HEAD_EXPECTATION_MISMATCH", "generation and key ID remain part of pin")
        after = journal.read_bytes(); journal.write_bytes(before)
        h.check(selected(h, "old-key-snapshot-vs-new-pin", state, key, next_pin, 3)["code"] == "STATE_HEAD_EXPECTATION_MISMATCH", "new-generation external selector rejects old key and snapshot pair")
        journal.write_bytes(after); selected(h, "new-key-exact", state, next_key, next_pin)
    case("rotation", rotation)

    def prefix_recovery() -> None:
        root, state, key = setup(h, "prefix-expected")
        journal = state / "state.journal"; original = journal.read_bytes(); pin = selector(original, key)
        torn = incomplete_next(original, key); journal.write_bytes(torn)
        selected(h, "no-automatic-prefix-adoption", state, key, pin, 3)
        report = audit(h, "prefix-exact-expectation", state, key, 3, ["--expected-state-head", pin])
        h.check(report["status"] == "INCOMPLETE_TAIL" and report["expected_head"] == "MATCH" and report["recovery_eligible"], "expectation matches only maximal semantically valid prefix")
        h.check(report["freshness"] == "NOT_ESTABLISHED" and report["state_head"]["freshness"] == "NOT_ESTABLISHED", "prefix match does not make incomplete source fresh")
        wrong = audit(h, "prefix-wrong-expectation", state, key, 3, ["--expected-state-head", changed(pin, 5)])
        h.check(not wrong["recovery_eligible"] and wrong["expected_head"] == "MISMATCH", "wrong expected prefix cannot be recovered")
        evidence = root / "source-evidence.bin"
        args = recover_args(state, key, report, evidence)
        denied = h.run("recover-wrong-expectation", args + ["--expected-state-head", changed(pin, 5)], expected=3)
        h.check(denied and denied["code"] == "STATE_HEAD_EXPECTATION_MISMATCH" and not evidence.exists() and journal.read_bytes() == torn, "mismatched recovery does not publish evidence or state")
        forged = list(args); forged[forged.index("--source-sha256")+1] = "11"*32
        denied = h.run("pin-not-recovery-authorization", forged + ["--expected-state-head", pin], expected=3)
        h.check(denied and denied["code"] == "STATE_AUTH_RECOVERY_SELECTION_MISMATCH" and not evidence.exists(), "matching pin never replaces explicit source and recovery selection")
        recovered = h.run("recover-exact-prefix", args + ["--expected-state-head", pin]); assert recovered
        new_pin = selector(journal.read_bytes(), key)
        h.check(evidence.read_bytes() == torn and stat.S_IMODE(evidence.stat().st_mode) == 0o600, "recovery preserves complete private source")
        h.check(recovered["state_head"]["selector"] == new_pin and new_pin != pin, "recovery produces explicit distinct resulting epoch")
        h.check(recovered["input_expectation"] == "MATCHED_VERIFIED_PREFIX" and recovered["state_head"]["freshness"] == "NOT_ESTABLISHED", "no automatic new-head freshness")
        h.check(selected(h, "old-prefix-pin-after-recovery", state, key, pin, 3)["code"] == "STATE_HEAD_EXPECTATION_MISMATCH", "recovered output requires a newly selected external anchor")
        selected(h, "recovered-exact", state, key, new_pin)
    case("prefix_recovery", prefix_recovery)

    def encrypted_backup_and_relocation() -> None:
        root, state, key = setup(h, "backup-expected")
        conf = v7(h.config("expected-backup", "A", state, free_port(), []), "backup-runtime-1")
        pin = selector((state / "state.journal").read_bytes(), key)
        d = start_expected(h, "backup-config", conf, state, key, pin); d.shutdown()
        pin = selector((state / "state.journal").read_bytes(), key)
        identity = h.identity("A")
        encryption = root / "backup-key"
        h.run("backup-key-create", ["backup-key-init", "--output", str(encryption), "--generation", "enc-g1"])
        archive = root / "snapshot.nob"
        base = ["backup-export", "--state", str(state), "--node", "A", "--generation", "a-g1", "--output", str(archive),
            "--state-auth-key", str(key), "--sign-key", str(identity.private_key), "--sign-cert", str(identity.certificate), "--encrypt-key", str(encryption)]
        value = h.run("export-wrong-expectation", base + ["--expected-state-head", changed(pin, 5)], expected=3)
        h.check(value and value["code"] == "STATE_HEAD_EXPECTATION_MISMATCH" and not archive.exists(), "export does not publish a mismatched source")
        exported = h.run("export-exact-source", base + ["--expected-state-head", pin]); assert exported
        backup_pin = exported["state_head"]["selector"]
        h.check(exported["input_expectation"] == "MATCHED" and backup_pin != pin and exported["state_head"]["freshness"] == "NOT_ESTABLISHED", "export checks input but reports new unanchored backup checkpoint")
        verify = ["backup-verify", "--input", str(archive), "--node", "A", "--generation", "a-g1", "--state-auth-key", str(key),
            "--decrypt-key", str(encryption), "--require-encryption", "yes", "--trusted-cert", str(identity.certificate), "--require-signature", "yes"]
        value = h.run("verify-wrong-representation", verify + ["--expected-state-head", pin], expected=3)
        h.check(value and value["code"] == "STATE_HEAD_EXPECTATION_MISMATCH", "source journal pin cannot substitute for embedded checkpoint pin")
        verified = h.run("verify-exact-backup", verify + ["--expected-state-head", backup_pin]); assert verified
        h.check(verified["state_head"]["expectation"] == "MATCH" and verified["trusted_signer"] and verified["encryption_authenticated"], "expected checkpoint still requires signature, decryption, authentication and semantics")
        enc2 = root / "backup-key-2"
        h.run("backup-key-create-2", ["backup-key-init", "--output", str(enc2), "--generation", "enc-g2"])
        reencrypted = root / "reencrypted.nob"
        reencrypt = ["backup-reencrypt", "--input", str(archive), "--output", str(reencrypted), "--decrypt-key", str(encryption),
            "--encrypt-key", str(enc2), "--state-auth-key", str(key), "--node", "A", "--generation", "a-g1", "--trusted-cert", str(identity.certificate), "--require-signature", "yes"]
        value = h.run("reencrypt-wrong-head", reencrypt + ["--expected-state-head", pin], expected=3)
        h.check(value and value["code"] == "STATE_HEAD_EXPECTATION_MISMATCH" and not reencrypted.exists(), "re-encryption fails before publication on mismatch")
        reenc = h.run("reencrypt-exact-head", reencrypt + ["--expected-state-head", backup_pin]); assert reenc
        h.check(reenc["state_head"]["selector"] == backup_pin and reenc["backup_id"] == exported["backup_id"], "outer encryption rotation leaves exact embedded head unchanged")
        destination = root / "restored"
        restore = ["backup-restore", "--input", str(archive), "--destination", str(destination), "--node", "A", "--generation", "a-g1",
            "--state-auth-key", str(key), "--decrypt-key", str(encryption), "--require-encryption", "yes", "--trusted-cert", str(identity.certificate), "--require-signature", "yes"]
        value = h.run("restore-wrong-head", restore + ["--expected-state-head", pin], expected=3)
        h.check(value and value["code"] == "STATE_HEAD_EXPECTATION_MISMATCH" and not destination.exists(), "restore rejects before destination staging")
        restored = h.run("restore-exact-backup", restore + ["--expected-state-head", backup_pin]); assert restored
        restored_pin = selector((destination / "state.journal").read_bytes(), key)
        h.check(restored["restored_state_head"]["selector"] == restored_pin and restored_pin != backup_pin, "restore provenance append creates distinct result head")
        h.check(restored["restored_state_head"]["freshness"] == "NOT_ESTABLISHED", "restored head is not automatically anchored")
        selected(h, "restored-exact-head", destination, key, restored_pin)
        cert, tlskey = copy_identity(identity.certificate, identity.private_key, root / "new-identity")
        candidate = relocated_config(conf, destination, cert, tlskey, "relocated-runtime-2", root / "relocated.conf")
        relocate = ["state-relocate", "--state", str(destination), "--node", "A", "--candidate", str(candidate), "--reason", "exact externally selected restored head", "--state-auth-key", str(key)]
        before = (destination / "state.journal").read_bytes()
        value = h.run("relocate-wrong-head", relocate + ["--expected-state-head", backup_pin], expected=3)
        h.check(value and value["code"] == "STATE_HEAD_EXPECTATION_MISMATCH" and (destination / "state.journal").read_bytes() == before, "relocation refuses a stale backup head without writing")
        relocated = h.run("relocate-exact-input", relocate + ["--expected-state-head", restored_pin]); assert relocated
        next_pin = selector((destination / "state.journal").read_bytes(), key)
        h.check(relocated["input_state_head"]["expectation"] == "MATCH" and relocated["result_state_head"]["selector"] == next_pin, "relocation separates input match from resulting head")
        h.check(relocated["result_state_head"]["freshness"] == "NOT_ESTABLISHED" and next_pin != restored_pin, "relocation cannot silently advance external expectation")
        selected(h, "relocated-exact-head", destination, key, next_pin)
        final = start_expected(h, "relocated-expected-start", candidate, destination, key, next_pin); final.shutdown()
        h.check(not list(root.glob(".natrav-overlay-restore-*")), "no leftover restore stage")
    case("encrypted_backup_and_relocation", encrypted_backup_and_relocation)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True); parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append", choices=CASES)
    args = parser.parse_args()
    if args.output.exists(): parser.error("output already exists")
    h = Harness(args.binary, args.output); begin = time.time(); code = 1
    try:
        run_suite(h, set(args.case) if args.case else None); code = 0
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=os.sys.stderr)
    finally:
        h.cleanup()
        summary = {"format": "NATRAV_OVERLAY_STATE_EXPECTATION_TESTS_V1", "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(), "cases_passed": sum(c["status"] == "PASS" for c in h.cases),
            "cases_total": len(h.cases), "assertions": h.assertions, "commands": len(h.commands), "elapsed_seconds": time.time()-begin}
        for name, obj in (("SUMMARY.json", summary), ("CASES.json", h.cases), ("COMMANDS.json", h.commands)):
            (h.output / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary))
    return code

if __name__ == "__main__": raise SystemExit(main())
