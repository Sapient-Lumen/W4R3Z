#!/usr/bin/env python3
"""Typed structural source selectors and receipt-derived ancestry, real owned peers."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import struct
import time
from run_persistent import Harness, free_port, operation, raw_control, receive_exact
from run_source_subscriptions import config, command, Reader, journal_frames, SCOPE
from run_evidence_queries import config as peer_config
from run_local_evidence import author
from run_lease_succession import (add_grant, succeed_args, expire, recipient_successor,
                                 mapping_reference)
from run_subscription_leases import local
from run_terminal_reconciliation import late, reconcile_args
from run_state_authentication import (inspect, new_key, migrate, start as start_keyed, checksum_frame)
from run_authenticated_recovery import audit, incomplete_next, recover_args
from run_live_configuration import candidate, activate
from run_automatic_source_delivery import automatic, wait_automatic
from run_local_administration import expose_control_for_uid, run_as_uid, restore_owner_only_control
from source_selector_reference import canonical_states, decode, h as reference_hash


def dump(h: Harness, name: str, value: object) -> None:
    (h.output/(name+'.json')).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')


def compact(h: Harness, label: str, state: Path, kind: str='status', *, grant: str='g1',
            previous: dict | None=None, expected: int=0) -> dict:
    args = ['source-subscription-'+kind, '--control', str(state/'control.sock'),
            '--grant', grant, '--response-format', 'compact', '--deadline-ms', '5000']
    if kind == 'step':
        assert previous
        args += ['--instance', previous['instance'], '--expected-revision', str(previous['revision'])]
    if kind == 'create': args += ['--reason', 'explicit structural response fixture']
    result = h.run(label, args, expected=expected); assert result is not None
    if not expected:
        h.check(result['format']=='NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_COMPACT_V1', 'explicit compact response format')
        h.check('state_digest' not in result and result['state_selector'].startswith('SPSC1:') and
                result['state_selector_kind']=='NATRAV_OVERLAY_SOURCE_PROGRESS_STATE_V1', 'legacy and structural digest types not interchanged')
        h.check(result['freshness']=='NOT_ESTABLISHED', 'selector does not establish freshness')
    return result


def received(h: Harness, label: str, state: Path, issued: dict) -> dict:
    h.wait(label+'-receipt', lambda: compact(h,label+'-receipt',state,grant=issued['grant'])['delivery_status']=='ACKED')
    done = compact(h,label+'-ack',state,'step',grant=issued['grant'],previous=issued)
    h.check(done['disposition']=='ACK' and done['acknowledged']==issued['acknowledged']+1, 'exact durable receipt gates compact acknowledgment')
    return done


def typed(args: list[str], selector: str, *, response: str='compact') -> list[str]:
    args = args.copy()
    old = '--predecessor-state-digest' if '--predecessor-state-digest' in args else '--state-digest'
    i = args.index(old); args[i] = '--predecessor-selector' if old.startswith('--predecessor') else '--state-selector'
    args[i+1] = selector
    return args + ['--response-format', response]


def compare(h: Harness, journal: bytes, states: list[dict]) -> list[dict]:
    canonical = canonical_states(journal); accounts = []
    for state in states:
        ref = canonical[state['grant']]
        h.check(ref['selector']==state['state_selector'], 'independent complete canonical reconstruction equals incremental selector')
        accounts.append({k:v for k,v in ref.items() if k not in ('raw','offset','delivery_offsets','pin_offset','generation_offset','request_offset')})
    return accounts


def pair(h: Harness, label: str, maximum: int=128) -> tuple:
    a,c=h.runtime/(label+'-a'),h.runtime/(label+'-c'); port=free_port(); uid=os.geteuid()
    pa=config(h,label+'-a',a,ports={'C':port},rules=[f'g1,{uid},{uid},C,c-g1,{SCOPE},{maximum},65536'])
    pc=peer_config(h,label+'-c','C',c,port,inbound=['A'])
    return a,c,pa,pc,h.start(label+'-a',pa,a),h.start(label+'-c',pc,c)


def run_cases(h: Harness, selected: set[str] | None, mode: str) -> None:
    def case(name, fn):
        if selected is None or name in selected: h.case(name, fn)

    def boundary():
        a,c,pa,pc,ad,cd=pair(h,'boundary')
        sources=[]
        for i in range(128):
            sources.append(author(h,f'boundary-author-{i}',a,value=f'{i:04d}:'+('x'*123),
                                  parent=sources[i-64] if i>=64 else None)['operation_id'])
        sub=compact(h,'boundary-create',a,'create'); rows=[]
        for i in range(128):
            issued=compact(h,f'boundary-issue-{i}',a,'step',previous=sub)
            issue_bytes=len(h.commands[-1]['stdout'].encode())-1
            done=received(h,f'boundary-{i}',a,issued)
            ack_bytes=len(h.commands[-1]['stdout'].encode())-1
            iw,aw=issued['validation_work'],done['validation_work']
            from source_outbound_work import check_outbound_work
            check_outbound_work(h, iw, aw, mode)
            if mode in ('delta','copy-return','owned-outgoing','copy-store','independent','independent-decoding','independent-outbound'):
                for work in (iw,aw):
                    h.check(work['state_encodes']==work['state_bytes_encoded']==0, 'compact ordinary response encodes no canonical state')
                    h.check(work['copied_delivery_entries']==work['compared_delivery_entries']==0, 'compact progress copies and compares no retained vector')
                    h.check(work['mapping_entries_visited']==work['mapping_index_full_rebuilds']==0, 'ordinary progress does not scan or rebuild retained ancestry')
                h.check(iw['mapping_index_hits']==((1 if mode in ('delta','copy-return','owned-outgoing','copy-store','independent-decoding','independent-outbound') else 3) if i>=64 else 0), 'exact correction parent is prepared once or independently reconstructed by control')
                if mode in ('delta','copy-return','owned-outgoing','copy-store','independent-decoding','independent-outbound'):
                    for work in (iw,aw):
                        h.check(work['configuration_parses']==1 and work['preparations_created']==1, 'one normally parsed active configuration per live progress command')
                        h.check(work['preflight_preparation_uses']==work['application_preparation_uses']==1, 'private preparation is reused only by originating preflight and application')
                        h.check(work['preflight_source_reconstructions']==work['application_source_reconstructions']==work['replay_source_reconstructions']==0, 'live command does not independently reconstruct an already prepared source')
                    for work in (iw,aw):
                        h.check(work['transaction_preparations_created']==(0 if mode=='independent-decoding' else 1) and
                                work['progress_transaction_decodes']==(2 if mode=='independent-decoding' else 1),
                                'one owned NST3 parse, or two independent parses in the decoder control')
                        h.check(work['preflight_transaction_uses']==work['application_transaction_uses']==(0 if mode=='independent-decoding' else 1) and
                                work['transaction_byte_binding_checks']==(0 if mode=='independent-decoding' else 3),
                                'both semantic passes and pre-append boundary use exactly bound bytes')
                        h.check(work['preflight_progress_decodes']==work['application_progress_decodes']==(1 if mode=='independent-decoding' else 0) and work['replay_progress_decodes']==0,
                                'live compact response neither reparses NST3 nor enters replay')
                        h.check((2 if mode=='independent-decoding' else 1)*work['progress_transaction_bytes_encoded']==work['progress_transaction_bytes_decoded'] and
                                work['transaction_binding_bytes_compared']==(0 if mode=='independent-decoding' else 3)*work['progress_transaction_bytes_encoded'],
                                'byte parsing and exact comparison are separate measured work')
                    h.check(iw['source_records_reconstructed']==iw['preparation_source_reconstructions']==1, 'selected source is reconstructed once')
                    h.check(iw['preparation_source_binding_checks']==2 and aw['source_records_reconstructed']==0, 'both issue checks rebind exact source; ACK constructs none')
                h.check(aw['mapping_digest_entries_hashed']==1 and iw['mapping_digest_entries_hashed']==0, 'ACK adds exactly one canonical acknowledged mapping link')
            h.check(done['state_selector']!=issued['state_selector']!=sub['state_selector'], 'issue and receipt acknowledgment change exact selector')
            rows.append({'ordinal':i+1,'issue':iw,'ack':aw,'issue_response_bytes':issue_bytes,'ack_response_bytes':ack_bytes})
            sub=done
        legacy=command(h,'boundary-legacy-status',a,'status')
        h.check(legacy['state_digest']!=sub['state_selector'][6:], 'canonical and structural digests retain distinct semantics')
        h.check(legacy['acknowledged_mapping_digest']==sub['acknowledged_mapping_digest'] and sub['used_payload_bytes']==16384, 'cached mapping and finite payload account remain exact')
        frozen=(a/'state.journal').read_bytes()
        poll=compact(h,'boundary-read-only',a)
        h.check(frozen==(a/'state.journal').read_bytes() and poll['state_selector']==sub['state_selector'], 'read-only selector request appends no progress')
        ad.shutdown();cd.shutdown()
        plain=inspect(h,'boundary-uncompacted',a); mapping_reference(h,plain)
        h.check(inspect(h,'boundary-recipient',c,node='C')['inbound']['count']==128, '128 actual recipient admissions')
        ad=h.start('boundary-restart',pa,a)
        h.check(compact(h,'boundary-after-replay',a)['state_selector']==sub['state_selector'], 'uncompacted replay reconstructs selector')
        h.run('boundary-compact',['compact','--control',str(ad.control),'--deadline-ms','5000'])
        refs=compare(h,(a/'state.journal').read_bytes(),[sub]); ad.shutdown()
        checkpoint=inspect(h,'boundary-checkpoint',a)
        h.check(checkpoint['source_subscriptions']==plain['source_subscriptions'], 'canonical source states and legacy state digests unchanged through compaction/restart')
        ad=h.start('boundary-checkpoint-restart',pa,a)
        h.check(compact(h,'boundary-checkpoint-selector',a)['state_selector']==sub['state_selector'], 'fully validated checkpoint recreates the selector')
        ad.shutdown()
        dump(h,'WORK-128',{'records':128,'payload_bytes':16384,'mode':mode,'first':rows[0],'last':rows[-1],'work':rows,
                           'legacy_status_work':legacy['validation_work'],'canonical_recomputation':refs,
                           'index_memory_note':'fixed C++ index and key/value payload only; excludes map tree nodes, allocator overhead and external string capacity'})
    case('128_sources_compact_responses_and_canonical_reconstruction',boundary)

    def preparation_scope():
        from run_source_subscriptions import remote as inspect_remote
        a,c,pa,pc,ad,cd=pair(h,'preparation-scope',8)
        sub=compact(h,'scope-create',a,'create')
        empty=compact(h,'scope-empty',a,'step',previous=sub)
        if mode in ('delta','copy-return','owned-outgoing','copy-store','independent-decoding','independent-outbound'):
            h.check(empty['disposition']=='CAUGHT_UP' and empty['validation_work']['preparations_created']==0,
                    'an empty command constructs no source preparation')
        original=author(h,'scope-original',a,value='first locked command')['operation_id']
        one=compact(h,'scope-issue-one',a,'step',previous=sub)
        retry=compact(h,'scope-retry-one',a,'step',previous=sub)
        h.check(retry['disposition']=='ALREADY_COMMITTED' and retry['state_selector']==one['state_selector'],
                'idempotent retry retains mutation identity without another source preparation')
        if mode in ('delta','copy-return','owned-outgoing','copy-store','independent-decoding','independent-outbound'):h.check(retry['validation_work']['preparations_created']==0,'no preparation survives into or is needed by an idempotent retry')
        done=received(h,'scope-one',a,one)
        def new_delivery_policy(text):
            lines=text.splitlines()
            for i,line in enumerate(lines):
                if line.startswith('peer=C,'):
                    fields=line.split(','); fields[-1]=str(int(fields[-1])+1000)
                    lines[i]=','.join(fields)
            return '\n'.join(lines)+'\n'
        changed=candidate(h,pa,'scope-new-configuration','scope-new-g',new_delivery_policy)
        # A new accepted event changes delivery policy but keeps the exact grant.
        activate(h,'scope-activate',a,changed)
        correction=author(h,'scope-correction',a,parent=original,value='source added after the first command')['operation_id']
        two=compact(h,'scope-issue-two',a,'step',previous=done)
        h.check(two['configuration_event']>one['configuration_event'] and two['latest']['source_operation']==correction and two['latest']['source_operation']!=one['latest']['source_operation'],
                'a subsequent command selects new local source, not an earlier prepared envelope')
        if mode in ('delta','copy-return','owned-outgoing','copy-store','independent-decoding','independent-outbound'):
            work=two['validation_work']
            h.check(work['preparations_created']==work['configuration_parses']==work['source_records_reconstructed']==1,
                    'new command obtains its own active configuration and exact correction preparation')
            h.check(work['mapping_index_hits']==1 and work['preparation_source_binding_checks']==2,
                    'one indexed correction preparation is bound twice under the changed accepted event')
        final=received(h,'scope-two',a,two)
        envelope=inspect_remote(h,'scope-recipient-correction',c,final)
        h.check(envelope['mapped_corrects']==one['latest']['operation_id'], 'new preparation keeps exact recipient-specific correction ancestry')
        h.run('scope-compact',['compact','--control',str(ad.control),'--deadline-ms','5000'])
        refs=compare(h,(a/'state.journal').read_bytes(),[final])
        ad.shutdown();ad=h.start('scope-restart',changed,a)
        h.check(compact(h,'scope-rebuilt',a)['state_selector']==final['state_selector'], 'checkpoint reconstructs the same selector without any saved preparation')
        ad.shutdown();cd.shutdown()
        dump(h,'PREPARATION-SCOPE',{'first_issue':one['validation_work'], 'next_issue':two['validation_work'], 'canonical':refs})
    case('command_preparation_expires_with_source_and_configuration',preparation_scope)

    def remote_canonical():
        from run_subscriber_requests import provider_config, subscriber_config, request as remote_request
        from run_subscription_leases import leased_provider_config, remote
        refs = []
        for leased in (False, True):
            label = 'remote-canonical-' + ('finite' if leased else 'plain')
            a, c = h.runtime/(label+'-a'), h.runtime/(label+'-c')
            ap, cp = free_port(), free_port()
            factory = leased_provider_config if leased else provider_config
            pa = factory(h, label+'-a', a, ap, cp)
            pc = subscriber_config(h, label+'-c', c, 'C', cp, ap)
            ad, cd = h.start(label+'-a', pa, a), h.start(label+'-c', pc, c)
            if leased:
                remote(h, label+'-request', pc, 'request', operation(label))
            else:
                remote_request(h, label+'-request', pc, operation(label))
            selected = compact(h, label+'-selected', a)
            h.check(selected['remote_admission'] is not None, 'remote admission remains committed in compact selector')
            original = author(h, label+'-original', a, value='remotely requested')['operation_id']
            author(h, label+'-correction', a, parent=original, value='remote correction')
            for i in range(2):
                selected = received(h, label+'-'+str(i), a,
                    compact(h, label+'-issue-'+str(i), a, 'step', previous=selected))
            h.run(label+'-compact', ['compact', '--control', str(ad.control), '--deadline-ms', '5000'])
            account = compare(h, (a/'state.journal').read_bytes(), [selected])[0]
            h.check(account['version'] == ('NSS4' if leased else 'NSS2'), 'independent canonical decoder covers original remote encoding')
            refs.append(account)
            ad.shutdown(); ad = h.start(label+'-restart', pa, a)
            h.check(compact(h, label+'-reconstructed', a)['state_selector'] == selected['state_selector'],
                    'remote-admission selector reconstructs through full checkpoint validation')
            ad.shutdown(); cd.shutdown()
        dump(h, 'REMOTE-CANONICAL', refs)
    case('historical_remote_admission_NSS2_and_NSS4_canonical_selectors', remote_canonical)

    def lineage():
        a,c,pa,pc,ad,cd,old,original=late(h,'typed-chain')
        selected=compact(h,'typed-terminal-selector',a)
        base=reconcile_args(a,old); args=typed(base,selected['state_selector'])
        for label,token in [('wrong-kind','SPSC2:'+selected['state_selector'][6:]),
                            ('canonical-as-structural','SPSC1:'+old['state_digest']),
                            ('zero','SPSC1:'+'0'*64)]:
            bad=args.copy();bad[bad.index('--state-selector')+1]=token
            h.run(label,bad,expected=3)
        bad=base.copy();bad[bad.index('--state-digest')+1]=selected['state_selector'][6:]
        h.run('structural-as-canonical',bad,expected=3)
        h.run('mixed-selectors',args+['--state-digest',old['state_digest']],expected=3)
        h.check(compact(h,'rejected-still-terminal',a)['state_selector']==selected['state_selector'], 'wrong selector types do not mutate terminal history')
        done=h.run('typed-reconcile',args)
        h.check(done['reconciliation']['preceding_state_digest']==old['state_digest'] and done['state_selector']!=selected['state_selector'], 'typed input preserves canonical stored predecessor digest')
        repeat=h.run('typed-reconcile-repeat',typed(base,selected['state_selector'],response='legacy'))
        h.check(repeat['disposition']=='ALREADY_RECONCILED', 'response preference is excluded from durable request identity')
        pa2=add_grant(h,pa,a,'typed-g2',duration=1000)
        g2_args=typed(succeed_args(a,repeat),done['state_selector'])
        g2=h.run('typed-successor',g2_args)
        h.check(g2['succession']['predecessor_state_digest']==repeat['state_digest'], 'succession retains canonical lineage commitment')
        child=author(h,'typed-child',a,parent=original,value='second lease correction')['operation_id']
        issued=compact(h,'typed-g2-issue',a,'step',grant='g2',previous=g2)
        final=received(h,'typed-g2',a,issued)
        env=recipient_successor(h,'typed-g2-envelope',c,final)
        h.check(env['mapped_corrects']==old['latest']['operation_id'], 'indexed successor maps to reconciled ancestor operation')
        terminal=expire(h,'typed-g2-expiry',a,final)
        g2_terminal=compact(h,'typed-g2-terminal-selector',a,grant='g2')
        pa3=add_grant(h,pa2,a,'typed-g3',grant='g3',lease='lease-g3')
        # A legacy selection follows a structural selection in the same chain.
        g3=h.run('legacy-third-successor',succeed_args(a,terminal,grant='g3',lease='lease-g3')+['--response-format','compact'])
        author(h,'typed-grandchild',a,parent=child,value='third lease correction')
        issued=compact(h,'typed-g3-issue',a,'step',grant='g3',previous=g3)
        last=received(h,'typed-g3',a,issued)
        env3=recipient_successor(h,'typed-g3-envelope',c,last)
        h.check(env3['mapped_corrects']==final['latest']['operation_id'] and last['acknowledged_source_position']==3, 'mixed selectors preserve exact multi-lease correction chain')
        if mode in ('delta','copy-return','owned-outgoing','copy-store','independent-decoding','independent-outbound'):h.check(issued['validation_work']['mapping_entries_visited']==0, 'cross-lease correction uses no retained-history scan')
        h.run('typed-chain-compact',['compact','--control',str(ad.control),'--deadline-ms','5000'])
        refs=compare(h,(a/'state.journal').read_bytes(),[done,g2_terminal,last])
        ad.shutdown();ad=h.start('typed-chain-restart',pa3,a)
        for s in (done,g2_terminal,last):h.check(compact(h,'typed-chain-state-'+s['grant'],a,grant=s['grant'])['state_selector']==s['state_selector'], 'deep canonical checkpoint reconstructs every selector')
        ad.shutdown();cd.shutdown();mapping_reference(h,inspect(h,'typed-chain-offline',a));dump(h,'LINEAGE',refs)
    case('typed_reconciliation_and_mixed_selector_multi_lease_chain',lineage)

    def rollback():
        a,c,pa,pc,ad,cd=pair(h,'rollback',8)
        parent=author(h,'rollback-parent',a,value='first')['operation_id']
        sub=compact(h,'rollback-create',a,'create')
        one=received(h,'rollback-one',a,compact(h,'rollback-one-issue',a,'step',previous=sub))
        frozen=(a/'state.journal').read_bytes()
        author(h,'rollback-child',a,parent=parent,value='second')
        two=received(h,'rollback-two',a,compact(h,'rollback-two-issue',a,'step',previous=one))
        current=(a/'state.journal').read_bytes(); ad.shutdown()
        (a/'state.journal').write_bytes(frozen);ad=h.start('rollback-old-prefix',pa,a)
        old=compact(h,'rollback-old-selector',a)
        h.check(old['state_selector']==one['state_selector'] and old['state_selector']!=two['state_selector'], 'valid old prefix restores old selector, not freshness')
        ad.shutdown();(a/'state.journal').write_bytes(current);ad=h.start('rollback-current-prefix',pa,a)
        h.check(compact(h,'rollback-restored-selector',a)['state_selector']==two['state_selector'], 'restored newer journal reconstructs exact selector')
        h.run('rollback-compact',['compact','--control',str(ad.control),'--deadline-ms','5000']);ad.shutdown();cd.shutdown()
        journal=(a/'state.journal').read_bytes(); refs=canonical_states(journal); ref=refs['g1'];compare(h,journal,[two])
        frames=journal_frames(a/'state.journal'); first=frames[0]
        h.check(ref['offset']<len(first), 'canonical subscription is inside owned checkpoint')
        mutations={'prior-source':ref['delivery_offsets'][0], 'prior-delivery':ref['delivery_offsets'][0]+32,
                   'prior-record':ref['delivery_offsets'][0]+64, 'recipient-spki':ref['pin_offset'],
                   'recipient-generation':ref['generation_offset']+2}
        observations=[]
        for label, offset in mutations.items():
            changed=bytearray(first);changed[ref['offset']+offset]^=1
            dest=h.runtime/('bad-'+label);shutil.copytree(a,dest)
            (dest/'state.journal').write_bytes(checksum_frame(bytes(changed))+b''.join(frames[1:]))
            failure=inspect(h,'reject-'+label,dest,expected=3)
            h.check(failure['code']=='JOURNAL_CORRUPT', 'canonical corruption rejected before derived index reconstruction')
            observations.append({'mutation':label,'code':failure['code']})
        dump(h,'ROLLBACK-CORRUPTION',observations)
    case('valid_rollback_and_independently_corrupted_canonical_ancestry',rollback)

    def automation():
        a,c,pa,pc,ad,cd=pair(h,'automatic',8)
        created=compact(h,'automatic-create',a,'create')
        sources=[]
        for i in range(3):sources.append(author(h,f'automatic-source-{i}',a,parent=sources[-1] if sources else None,value=str(i))['operation_id'])
        automatic(h,'automatic-enable',a,'enable',previous=created,maximum=6)
        done=wait_automatic(h,'automatic-exhausted',a,lambda s:s['acknowledged']==3 and s['automatic_current']['state']=='EXHAUSTED')
        selected=compact(h,'automatic-selector',a,'auto-status')
        h.check(selected['automatic_current']['steps']==6 and selected['acknowledged']==3, 'finite automatic issue/ack account unchanged')
        frozen=(a/'state.journal').read_bytes();compact(h,'automatic-observe',a,'auto-status')
        h.check((a/'state.journal').read_bytes()==frozen, 'compact automation status spends no allowance')
        h.run('automatic-compact',['compact','--control',str(ad.control),'--deadline-ms','5000'])
        refs=compare(h,(a/'state.journal').read_bytes(),[selected]);ad.shutdown()
        ad=h.start('automatic-restart',pa,a)
        h.check(compact(h,'automatic-after-restart',a)['state_selector']==selected['state_selector'], 'automatic grant history reconstructs selector')
        ad.shutdown();cd.shutdown();dump(h,'AUTOMATION',refs)
    case('automatic_progress_structural_commitment_and_finite_allowance',automation)

    def wire():
        a,c,pa,pc,ad,cd=pair(h,'wire',8);compact(h,'wire-create',a,'create')
        def text(s):b=s.encode();return struct.pack('!H',len(b))+b
        inner=b'NSR1'+bytes([3])+text('g1'); wrapper=b'NSR5'+struct.pack('!I',len(inner))+inner
        ok,response=raw_control(ad.control,b'NOC1'+bytes([20])+wrapper)
        h.check(ok and response['format']=='NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_COMPACT_V1' and 'state_digest' not in response, 'independent NSR5 producer selects compact format')
        before_selector=response['state_selector']
        for label,body in [('trailing',wrapper+b'x'),('nested',b'NSR5'+struct.pack('!I',len(wrapper))+wrapper),
                           ('unknown',b'NSR7'+inner[4:]),('structural-status',b'NSR6'+inner[4:]),
                           ('oversized',b'NSR5'+struct.pack('!I',2049)+b'x'*2049)]:
            ok,error=raw_control(ad.control,b'NOC1'+bytes([20])+body)
            h.check(not ok, 'strict selector wire rejects '+label)
        h.check(compact(h,'wire-after-rejections',a)['state_selector']==before_selector,
                'invalid wire requests do not change subscription state; denial audit records are permitted')
        ad.shutdown();cd.shutdown()
    case('independent_wire_versions_and_strict_selector_decoding',wire)

    def authority():
        a,c,pa,pc,ad,cd,old,_=late(h,'authority')
        selected=compact(h,'authority-selected',a)
        def text(value):
            b=value.encode();return struct.pack('!H',len(b))+b
        reason='independent typed receipt adoption'
        inner=b'NSR6'+bytes([9])+text(old['grant'])+bytes.fromhex(old['instance'])+struct.pack('!Q',old['revision'])
        for digest in (selected['state_selector'][6:],old['terminal_digest'],old['latest']['source_operation'],
                       old['latest']['operation_id'],old['head_receipt']['digest']):inner+=bytes.fromhex(digest)
        inner+=text(reason)
        payload=b'NOC1'+bytes([20])+b'NSR5'+struct.pack('!I',len(inner))+inner
        other=candidate(h,pa,'authority-other','authority-other-g',lambda tx:tx+'local_control=65534,SOURCE_DISCLOSE\n')
        activate(h,'authority-other-activate',a,other);expose_control_for_uid(a)
        denied=run_as_uid(h,'authority-other-uid',65534,65534,typed(reconcile_args(a,old),selected['state_selector']),3)
        h.check(denied['code']=='SOURCE_SUBSCRIPTION_NOT_FOUND', 'typed selector does not bypass actual manager UID')
        restore_owner_only_control(a)
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as sock:
            sock.settimeout(5);sock.connect(str(ad.control));sock.sendall(struct.pack('!I',len(payload))+payload[:-1])
            removed=candidate(h,other,'authority-removed','authority-removed-g',lambda tx:'\n'.join(
                line for line in tx.splitlines() if not line.startswith('source_disclosure=g1,'))+'\n')
            activate(h,'authority-remove',a,removed)
            sock.sendall(payload[-1:]);sock.shutdown(socket.SHUT_WR)
            count=struct.unpack('!I',receive_exact(sock,4))[0];reply=receive_exact(sock,count)
        h.check(reply[:5]==b'NOR1\1' and json.loads(reply[5:])['code']=='SOURCE_DISCLOSURE_DENIED',
                'typed cached selector never substitutes stale authority after request decoding')
        restored=candidate(h,other,'authority-restored','authority-restored-g');activate(h,'authority-restore',a,restored)
        ok,done=raw_control(ad.control,payload)
        h.check(ok and done['disposition']=='RECONCILED', 'independent NSR6 producer commits exact selected terminal receipt')
        expected=reference_hash('NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_REQUEST_V1',inner).hex()
        h.check(done['reconciliation']['request_digest']==expected, 'durable request digest commits exact structural-selector wire type, not translated legacy input')
        h.run('authority-compact',['compact','--control',str(ad.control),'--deadline-ms','5000'])
        compare(h,(a/'state.journal').read_bytes(),[done]);ad.shutdown();cd.shutdown()
        dump(h,'AUTHORITY',{'actual_request_digest':expected,'selector_kind':'NSR6','live_removal_rejected':True,'cross_uid_rejected':True})
    case('typed_wire_provenance_real_uid_and_live_authority',authority)

    def visibility():
        a=h.runtime/'visibility';uid=65534
        pa=config(h,'visibility',a,ports={'C':free_port()},delegates=True,
                  rules=[f'g1,{uid},{uid},C,c-g1,{SCOPE},2,20'])
        ad=h.start('visibility',pa,a);expose_control_for_uid(a)
        created=command(h,'visibility-create',a,'create',uid=uid)
        result=run_as_uid(h,'visibility-compact',uid,uid,['source-subscription-status','--control',str(ad.control),
                           '--grant','g1','--response-format','compact'],0)
        h.check(result['format']=='NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_COMPACT_V1' and 'validation_work' not in result,
                'compact response does not turn disclosure authority into inspection diagnostics')
        restore_owner_only_control(a);ad.shutdown()
    case('compact_work_diagnostics_require_current_inspection_authority',visibility)

    def maintenance():
        a,c,pa,pc,ad,cd,old,original=late(h,'maintenance')
        selected=compact(h,'maintenance-selected',a); ad.shutdown()
        keys=h.work/'keys';keys.mkdir(mode=0o700);key=new_key(h,keys,'state-g1');migrate(h,'maintenance-migrate',a,key)
        ad=start_keyed(h,'maintenance-keyed',pa,a,key)
        args=typed(reconcile_args(a,old),selected['state_selector'])
        done=h.run('maintenance-typed-reconcile',args)
        ad.shutdown()
        raw=(a/'state.journal').read_bytes();partial=incomplete_next(raw,key)
        (a/'state.journal').write_bytes(partial)
        report=audit(h,'maintenance-incomplete-audit',a,key,3)
        h.check(report['status']=='INCOMPLETE_TAIL' and report['verified_bytes']==len(raw), 'authenticated recovery selects exact complete prefix')
        custody=h.work/'preserved-source.bin'
        h.run('maintenance-prefix-recovery',recover_args(a,key,report,custody))
        h.check(custody.read_bytes()==partial, 'recovery preserves original partial journal bytes')
        ad=start_keyed(h,'maintenance-recovered',pa,a,key)
        h.check(compact(h,'maintenance-recovered-selector',a)['state_selector']==done['state_selector'], 'authenticated prefix recovery rebuilds same source selector')
        h.run('maintenance-compact',['compact','--control',str(ad.control),'--deadline-ms','5000'])
        compare(h,(a/'state.journal').read_bytes(),[done]);ad.shutdown()
        before=inspect(h,'maintenance-before',a,key)
        enc=keys/'archive.key';archive=h.work/'archive.nob';identity=h.identity('A')
        h.run('maintenance-encrypt-key',['backup-key-init','--output',str(enc),'--generation','archive-g1'])
        h.run('maintenance-export',['backup-export','--state',str(a),'--node','A','--generation','a-g1','--output',str(archive),
              '--state-auth-key',str(key),'--encrypt-key',str(enc),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'restored'
        h.run('maintenance-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','A','--generation','a-g1',
              '--state-auth-key',str(key),'--decrypt-key',str(enc),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'maintenance-restored',restored,key)
        h.check(after['storage']['logical_state_digest']==before['storage']['logical_state_digest'], 'signed encrypted restore retains canonical logical state')
        moved=candidate(h,pa,'maintenance-moved','maintenance-moved-g',lambda s:s.replace('state='+str(a),'state='+str(restored)))
        h.run('maintenance-relocate',['state-relocate','--state',str(restored),'--node','A','--candidate',str(moved),
              '--reason','relocate exact reconciled history','--state-auth-key',str(key)])
        ad=start_keyed(h,'maintenance-resumed',moved,restored,key)
        h.check(compact(h,'maintenance-relocated-selector',restored)['state_selector']==done['state_selector'], 'relocation does not reinterpret historical source selector')
        repeated=typed(reconcile_args(restored,old),selected['state_selector'],response='legacy')
        final_old=h.run('maintenance-retry',repeated)
        h.check(final_old['disposition']=='ALREADY_RECONCILED', 'typed request identity survives recovery restore and relocation')
        newer=add_grant(h,moved,restored,'maintenance-g2')
        successor=h.run('maintenance-successor',typed(succeed_args(restored,final_old),done['state_selector']))
        author(h,'maintenance-correction',restored,parent=original,value='restored correction')
        final=received(h,'maintenance-delivery',restored,compact(h,'maintenance-issue',restored,'step',grant='g2',previous=successor))
        env=recipient_successor(h,'maintenance-envelope',c,final)
        h.check(env['mapped_corrects']==old['latest']['operation_id'], 'restored index retains recipient-specific correction parent')
        h.run('maintenance-final-compact',['compact','--control',str(ad.control),'--deadline-ms','5000'])
        refs=compare(h,(restored/'state.journal').read_bytes(),[done,final]);ad.shutdown();cd.shutdown()
        mapping_reference(h,inspect(h,'maintenance-final',restored,key))
        dump(h,'MAINTENANCE',{'before_logical_digest':before['storage']['logical_state_digest'],
                            'restored_logical_digest':after['storage']['logical_state_digest'],'canonical':refs})
    case('typed_selectors_keyed_recovery_backup_restore_and_relocation',maintenance)


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--case',action='append');p.add_argument('--validation-mode',choices=('delta','copy-return','owned-outgoing','copy-store','reference','independent','independent-decoding','independent-outbound'),default='delta');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);started=time.time();ok=False
    try:run_cases(h,set(a.case) if a.case else None,a.validation_mode);ok=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {type(e).__name__}: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_SOURCE_SELECTOR_TESTS_V1','status':'PASS' if ok else 'FAIL',
            'binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),
            'cases_passed':sum(x['status']=='PASS' for x in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-started}
        for name,data in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]:dump(h,name,data)
        print(json.dumps(summary),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
