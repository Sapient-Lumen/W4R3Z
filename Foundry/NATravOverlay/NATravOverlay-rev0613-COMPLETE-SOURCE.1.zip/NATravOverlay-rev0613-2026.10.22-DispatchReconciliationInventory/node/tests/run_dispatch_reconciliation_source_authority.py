#!/usr/bin/env python3
"""Static authority audit for rev0613 read-only custody-dispatch observation."""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "node" / "src"
VALIDATION = ROOT / "validation" / "revision-0613"
VALIDATION.mkdir(parents=True, exist_ok=True)

checks: list[dict[str, object]] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append({"name": name, "passed": bool(condition), "detail": detail})


def function_body(text: str, signature_fragment: str) -> str:
    pos = text.find(signature_fragment)
    if pos < 0:
        return ""
    brace = text.find("{", pos)
    if brace < 0:
        return ""
    depth = 0
    in_string = False
    quote = ""
    escaped = False
    line_comment = False
    block_comment = False
    i = brace
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if line_comment:
            if ch == "\n":
                line_comment = False
        elif block_comment:
            if ch == "*" and nxt == "/":
                block_comment = False
                i += 1
        elif in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                in_string = False
        elif ch == "/" and nxt == "/":
            line_comment = True
            i += 1
        elif ch == "/" and nxt == "*":
            block_comment = True
            i += 1
        elif ch == "'" and i > 0 and i + 1 < len(text) and \
                text[i - 1].isalnum() and text[i + 1].isalnum():
            # C++ digit separator (for example 2'048U), not a character literal.
            pass
        elif ch in ('"', "'"):
            in_string = True
            quote = ch
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[brace : i + 1]
        i += 1
    return ""


header = (SRC / "custody_session_service.hpp").read_text()
service = (SRC / "custody_session_service.cpp").read_text()
control_h = (SRC / "control.hpp").read_text()
control_cpp = (SRC / "control.cpp").read_text()
daemon = (SRC / "daemon.cpp").read_text()
main = (SRC / "main.cpp").read_text()

status_body = function_body(service, "CustodyOwnerDispatcher::reconcile_status")
inventory_body = function_body(service, "CustodyOwnerDispatcher::reconcile_inventory")
authority_body = function_body(service, "resolve_dispatch_observation_authority")
observe_body = function_body(service, "observe_dispatch_exact")
row_body = function_body(service, "observed_dispatch_json")
observation_code = "\n".join(
    (status_body, inventory_body, authority_body, observe_body, row_body)
)

check("status request type exists", "CustodyOwnerDispatchStatusRequest" in header)
check("inventory request type exists", "CustodyOwnerDispatchInventoryRequest" in header)
check("status service method exists", bool(status_body))
check("inventory service method exists", bool(inventory_body))
check("status control kind 49 exists", re.search(r"custody_dispatch_status\s*=\s*49U?", control_h) is not None)
check("inventory control kind 50 exists", re.search(r"custody_dispatch_inventory\s*=\s*50U?", control_h) is not None)
check("status control request exists", "ControlCustodyDispatchStatus" in control_h)
check("inventory control request exists", "ControlCustodyDispatchInventory" in control_h)
check("status request is encoded and decoded", control_cpp.count("ControlCustodyDispatchStatus") >= 2)
check("inventory request is encoded and decoded", control_cpp.count("ControlCustodyDispatchInventory") >= 2)
check("status JSON schema is explicit", "NATRAV_CUSTODY_DISPATCH_STATUS_V1" in status_body)
check("inventory JSON schema is explicit", "NATRAV_CUSTODY_DISPATCH_INVENTORY_V1" in inventory_body)
check("status JSON bound exists", "kMaximumCustodyDispatchStatusJsonBytes" in header and "kMaximumCustodyDispatchStatusJsonBytes" in status_body)
check("inventory count bound exists", "kMaximumCustodyDispatchInventoryRecords" in header and "kMaximumCustodyDispatchInventoryRecords" in inventory_body)
check("inventory JSON bound exists", "kMaximumCustodyDispatchInventoryJsonBytes" in header and "kMaximumCustodyDispatchInventoryJsonBytes" in inventory_body)
check("status daemon handler exists", "ControlCustodyDispatchStatus" in daemon and "reconcile_status" in daemon)
check("inventory daemon handler exists", "ControlCustodyDispatchInventory" in daemon and "reconcile_inventory" in daemon)
check("status daemon command is distinct", '"CUSTODY_DISPATCH_STATUS"' in daemon)
check("inventory daemon command is distinct", '"CUSTODY_DISPATCH_INVENTORY"' in daemon)
check("status owner CLI exists", 'command == "custody-dispatch-status"' in main)
check("inventory owner CLI exists", 'command == "custody-dispatch-inventory"' in main)
check("candidate identity is revision 0613", re.search(r'\\"version\\":\\"0613\\"', main) is not None and re.search(r'\\"revision\\":\\"0613\\"', service) is not None)

check("current accepted V24 is required", "config.format_version >= 24U" in authority_body)
check("exact current activation is resolved", "find_custody_dispatch_activation" in authority_body)
check("exact V23 receiver is resolved", "resolve_custody_dispatch_receiver_activation" in authority_body)
check("exact outbound V22 rule is resolved", "resolve_custody_dispatch_outbound_rule" in authority_body)
check("exact outbound V21 grant is resolved", "resolve_custody_session_grant" in authority_body)
check("exact active route commitment is checked", "custody_dispatch_route_commitment" in authority_body)
check("read-only service root is used", "service_root_read_only" in authority_body)
check("repairing service root is not used", "service_root(" not in authority_body)

check("dispatch index is observed", "dispatch_index_path" in observe_body and '"dispatch-index"' in service)
check("index to V22 case is exact", "case_path" in observe_body and "outbound_request_id" in observe_body)
check("case to dispatch record is exact", '".record"' in observe_body and "parse_owner_dispatch_record" in observe_body)
check("record is bound to current V24 commitment", "activation_commitment" in observe_body)
check("retained offer is cryptographically validated", "validate_offer" in observe_body)
check("envelope metadata and reverse index are checked", "envelope_sha256" in observe_body and "envelope_index_path" in observe_body)
check("attempt reservation mismatch is bounded", "record.attempt - attempts == 1U" in observe_body and "maximum_dispatch_attempts" in observe_body)
check("result bytes are not returned", "result_sha256" in row_body and "custody_result" not in row_body)
check("acceptance bytes are not returned", "acceptance_sha256" in row_body and "acceptance_hex" not in row_body and "acceptance_bytes" not in row_body)
check("revocation is metadata-only", "revoked_metadata_only" in row_body and "remote_acceptance_replayed" in row_body)
check("lexical ordering is explicit", "std::sort" in inventory_body and "std::upper_bound" in inventory_body)
check("symlink rejection is explicit", "symlink" in observation_code.lower() and "symlink_status" in inventory_body)
check("finite inventory page is enforced", "kMaximumCustodyDispatchInventoryRecords" in inventory_body)
check("finite inventory bytes are enforced", "request.maximum_bytes" in inventory_body)
check("all index names are validated before paging", "before sorting" in inventory_body)

# Observation implementation and every helper it reaches remain disconnected
# from mutation, repair, carrier, forwarding, import, and delivery inference.
forbidden = {
    "network exchange": "exchange_message",
    "socket connect": "connect(",
    "socket send": "send(",
    "atomic file write": "atomic_write",
    "journal append": "append_",
    "repairing lookup": "find_dispatch_outbound_request",
    "mutable service root": "ensure_service_layout",
    "route discovery": "discover",
    "route fallback": "fallback",
    "forwarding": "forward",
    "final import": "import_bundle",
    "delivery inference": "delivered",
}
for label, token in forbidden.items():
    check(f"observation has no {label}", token not in observation_code, token)

check("status explicitly reports zero mutation", '"filesystem_mutated\\":false' in status_body)
check("inventory explicitly reports zero mutation", '"filesystem_mutated\\":false' in inventory_body)
check("status explicitly reports zero network", '"network_attempted\\":false' in status_body)
check("inventory explicitly reports zero network", '"network_attempted\\":false' in inventory_body)

passed = sum(1 for item in checks if item["passed"])
result = {
    "schema": "NATRAV_REV0613_DISPATCH_RECONCILIATION_SOURCE_AUTHORITY_V2",
    "passed": passed == len(checks),
    "checks_passed": passed,
    "checks_total": len(checks),
    "checks": checks,
}
(VALIDATION / "dispatch-reconciliation-source-authority.json").write_text(
    json.dumps(result, indent=2, sort_keys=True) + "\n"
)
print(json.dumps(result, sort_keys=True))
raise SystemExit(0 if result["passed"] else 1)
