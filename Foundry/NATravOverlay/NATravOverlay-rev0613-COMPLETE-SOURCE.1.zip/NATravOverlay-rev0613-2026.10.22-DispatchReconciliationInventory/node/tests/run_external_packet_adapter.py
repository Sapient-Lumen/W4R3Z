#!/usr/bin/env python3
"""Supervised external complete-datagram adapter boundary regression."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
from typing import Any

from tls_test_support import IdentityFactory


EXPECTED_FEATURE = "SUPERVISED_EXTERNAL_PACKET_ADAPTER_V1"
EXPECTED_REVISION = "0613"


def run_command(
    command: list[str],
    *,
    stdout_path: Path,
    stderr_path: Path,
    timeout: float,
    environment: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        timeout=timeout,
        env=environment,
    )
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)
    return completed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    source_root = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    binary = args.binary.resolve(strict=True)
    if output.exists() or output == source_root or source_root in output.parents:
        parser.error("output must be new and outside the source tree")
    output.mkdir(parents=True)

    started = time.monotonic()
    assertions = 0
    commands: list[dict[str, Any]] = []
    cases: list[dict[str, Any]] = []

    def check(condition: bool, detail: str) -> None:
        nonlocal assertions
        assertions += 1
        if not condition:
            raise AssertionError(detail)

    def record_case(name: str, before: int, begin: float) -> None:
        cases.append(
            {
                "name": name,
                "status": "PASS",
                "assertions": assertions - before,
                "elapsed_seconds": time.monotonic() - begin,
            }
        )

    status = "FAIL"
    failure: str | None = None
    try:
        before = assertions
        begin = time.monotonic()
        version_run = run_command(
            [str(binary), "version"],
            stdout_path=output / "version.stdout.txt",
            stderr_path=output / "version.stderr.txt",
            timeout=10,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append(
            {"label": "version", "returncode": version_run.returncode,
             "args": ["version"]}
        )
        check(version_run.returncode == 0, "version command succeeds")
        lines = [line for line in version_run.stdout.splitlines() if line.strip()]
        check(len(lines) == 1, "version emits one JSON line")
        version = json.loads(lines[0])
        check(version.get("version") == EXPECTED_REVISION,
              "revision marker is 0595")
        check(version.get("external_packet_adapter") == EXPECTED_FEATURE,
              "supervised external packet-adapter marker is exact")
        check(version.get("packet_port") ==
              "OWNED_COMPLETE_DATAGRAM_PACKET_PORT_V1",
              "owned packet-port boundary is retained")
        check(version.get("packet_link_stream") ==
              "PACKET_LINK_ORDERED_BYTE_STREAM_ADAPTER_V1",
              "finite packet ordered-stream boundary is retained")
        record_case("revision metadata", before, begin)

        before = assertions
        begin = time.monotonic()
        header = (source_root / "node/src/external_packet_adapter.hpp").read_text()
        implementation = (
            source_root / "node/src/external_packet_adapter.cpp"
        ).read_text()
        fixture_source = (
            source_root / "node/tests/fixture_external_packet_adapter.py"
        ).read_text()
        build_script = (source_root / "node/build.sh").read_text()
        main_source = (source_root / "node/src/main.cpp").read_text()
        transport_source = (source_root / "node/src/transport.cpp").read_text()
        configured_sources = "\n".join(
            (source_root / path).read_text()
            for path in (
                "node/src/config.cpp",
                "node/src/runtime.cpp",
                "node/src/daemon.cpp",
                "node/src/transport.cpp",
            )
        )
        check(EXPECTED_FEATURE in header and
              "ExternalPacketAdapterOptions" in header and
              "SupervisedExternalPacketAdapterControl" in header,
              "versioned adapter, bounded options, and evidence control are explicit")
        check("OwnedCompleteDatagramPacketPort" in header and
              "std::unique_ptr<OwnedCompleteDatagramPacketPort>" in header,
              "external process supplies only the existing complete-datagram seam")
        check("SOCK_SEQPACKET" in implementation and
              "socketpair" in implementation and
              "kAdapterDescriptor = 3" in implementation,
              "core creates one exact inherited full-duplex seqpacket endpoint")
        check("NAPA0001" in implementation and
              "kFrameHeaderBytes = 36U" in implementation and
              "FrameType::shutdown_request" in implementation,
              "local protocol is canonical, versioned, length-bound, and shutdown-aware")
        check("NATRAV_ADAPTER_FD=3" in implementation and
              "NATRAV_ADAPTER_PROTOCOL=NAPA0001" in implementation and
              "PYTHONDONTWRITEBYTECODE=1" in implementation,
              "adapter receives a minimal explicit environment")
        check("PR_SET_PDEATHSIG" in implementation and
              "PR_SET_NO_NEW_PRIVS" in implementation and
              "SYS_close_range" in implementation,
              "child lifetime, privilege escalation, and descriptor inheritance are bounded")
        check("max_launch_attempts" in implementation and
              "initial_restart_backoff" in implementation and
              "maximum_restart_backoff" in implementation,
              "startup supervision has finite retry and exponential-backoff bounds")
        check("dlopen" not in implementation and "dlsym" not in implementation,
              "node does not load adapter shared objects into its authority process")
        check("std::thread(" not in implementation,
              "supervisor owns no unbounded background thread")
        check("src/external_packet_adapter.cpp" in build_script,
              "normal product build compiles the supervised boundary")
        check(EXPECTED_FEATURE in main_source and
              "supervised_external_packet_adapter_revision_abi" in main_source,
              "release metadata and link anchor retain the adapter seam")
        parse_start = transport_source.index("TransportKind parse_transport_kind")
        parse_end = transport_source.index("std::string_view transport_kind_name")
        parse_body = transport_source[parse_start:parse_end]
        check('ADAPTER_AUTHORIZED_CONTEXT_REQUIRED' in transport_source and
              'make_configured_adapter_connector(config, route.locator)' in configured_sources and
              'external_packet_adapter_options_from_profile' not in parse_body,
              "unprepared calls fail; persistent routes require accepted exact policy")
        check("NATRAV_EXTERNAL_PACKET_ADAPTER_FIXTURE_V1" in fixture_source and
              "startup-crash-state" in fixture_source and
              '"drop", "duplicate", "corrupt", "delay", "reorder"' in fixture_source,
              "fixture covers deterministic packet adversity and process startup failure")
        record_case("private authority and supervision boundary", before, begin)

        before = assertions
        begin = time.monotonic()
        fixture = output / "fixture-external-packet-adapter"
        shutil.copy2(
            source_root / "node/tests/fixture_external_packet_adapter.py",
            fixture,
        )
        fixture.chmod(0o700)
        check(fixture.is_file() and os.access(fixture, os.X_OK),
              "exact fixture executable is materialized outside the source tree")

        probe = output / "external-packet-adapter-probe"
        compile_command = [
            "/usr/bin/g++",
            "-D_GNU_SOURCE",
            "-std=c++20",
            "-O1",
            "-g0",
            "-Wall",
            "-Wextra",
            "-Wpedantic",
            "-Wconversion",
            "-Wsign-conversion",
            "-Wshadow",
            "-Wformat=2",
            "-Werror",
            "-pthread",
            f"-I{source_root / 'foundation/include'}",
            f"-I{source_root / 'node/src'}",
            str(source_root / "node/tests/test_external_packet_adapter.cpp"),
            str(source_root / "node/src/external_packet_adapter.cpp"),
            str(source_root / "node/src/adapter_profile.cpp"),
            str(source_root / "node/src/packet_port.cpp"),
            str(source_root / "node/src/finite_packet_link.cpp"),
            str(source_root / "node/src/peer_session.cpp"),
            str(source_root / "node/src/tls.cpp"),
            str(source_root / "node/src/tls_bio.cpp"),
            str(source_root / "node/src/socket.cpp"),
            str(source_root / "node/src/protocol.cpp"),
            str(source_root / "node/src/common.cpp"),
            str(source_root / "node/src/transport.cpp"),
            str(source_root / "node/src/serial_transport.cpp"),
            str(source_root / "node/src/udp_transport.cpp"),
            str(source_root / "node/src/unix_datagram_transport.cpp"),
            str(source_root / "foundation/src/core.cpp"),
            str(source_root / "foundation/src/natrav_peer_session.cpp"),
            str(source_root / "foundation/src/natrav_peer_stream.cpp"),
            str(source_root / "foundation/src/natrav_peer_message.cpp"),
            str(source_root / "foundation/src/natrav_peer_handshake.cpp"),
            "-lssl",
            "-lcrypto",
            "-lz",
            "-lzstd",
            "-ldl",
            "-o",
            str(probe),
        ]
        compile_run = run_command(
            compile_command,
            stdout_path=output / "probe-build.stdout.txt",
            stderr_path=output / "probe-build.stderr.txt",
            timeout=600,
            environment=dict(os.environ, TERM="dumb"),
        )
        commands.append(
            {"label": "probe-build", "returncode": compile_run.returncode,
             "args": compile_command}
        )
        check(compile_run.returncode == 0,
              "strict-warning supervised-adapter probe compiles")
        check(probe.is_file() and os.access(probe, os.X_OK),
              "supervised-adapter probe executable is materialized")
        record_case("probe build", before, begin)

        before = assertions
        begin = time.monotonic()
        identities = IdentityFactory(output / "identities")
        client = identities.identity("external-adapter-client")
        server = identities.identity("external-adapter-server")
        evidence = output / "probe-evidence"
        evidence.mkdir()
        probe_command = [
            str(probe),
            str(fixture),
            str(client.certificate),
            str(client.private_key),
            client.spki_sha256,
            str(server.certificate),
            str(server.private_key),
            server.spki_sha256,
            str(evidence),
        ]
        probe_run = run_command(
            probe_command,
            stdout_path=output / "probe.stdout.txt",
            stderr_path=output / "probe.stderr.txt",
            timeout=360,
            environment=dict(
                os.environ,
                TERM="dumb",
                PYTHONDONTWRITEBYTECODE="1",
            ),
        )
        commands.append(
            {"label": "probe", "returncode": probe_run.returncode,
             "args": [str(probe), str(fixture),
                      "<ephemeral test identities>", str(evidence)]}
        )
        check(probe_run.returncode == 0,
              "supervised-adapter real-stack probe succeeds")
        probe_lines = [line for line in probe_run.stdout.splitlines() if line.strip()]
        check(len(probe_lines) == 1, "probe emits one JSON result")
        result = json.loads(probe_lines[0])
        check(result.get("format") ==
              "NATRAV_EXTERNAL_PACKET_ADAPTER_PROBE_V1",
              "probe format is exact")
        check(result.get("status") == "PASS", "probe reports PASS")
        check(result.get("cases") == 6,
              "probe executes all six process, packet, TLS, and negative cases")
        check(result.get("assertions", 0) >= 27,
              "probe retains the bounded behavioral assertion floor")
        records = result.get("case_records")
        check(isinstance(records, list) and len(records) == 6,
              "probe returns one account for every case")
        assert isinstance(records, list)
        for item in records:
            check(isinstance(item, dict) and int(item.get("assertions", 0)) > 0,
                  "every probe case contributes explicit assertions")
            cases.append(
                {
                    "name": f"external adapter probe: {item['name']}",
                    "status": "PASS",
                    "assertions": int(item["assertions"]),
                    "elapsed_seconds": 0.0,
                }
            )
        assertions += int(result["assertions"])
        record_case("probe execution", before, begin)

        before = assertions
        begin = time.monotonic()
        evidence_files = sorted(
            (evidence / "fixture-evidence").rglob("*.json")
        )
        check(len(evidence_files) >= 8,
              "fixture preserves bounded evidence across startup, data, TLS, and fault runs")
        documents = [json.loads(path.read_text()) for path in evidence_files]
        environments = [item.get("environment") for item in documents]
        allowed_environment = {
            "LANG": "C",
            "LC_ALL": "C",
            "NATRAV_ADAPTER_FD": "3",
            "NATRAV_ADAPTER_PROTOCOL": "NAPA0001",
            "PYTHONDONTWRITEBYTECODE": "1",
        }
        check(all(environment == allowed_environment for environment in environments),
              "every child receives only the exact minimal environment")
        check(all(item.get("inherited_fds") == [0, 1, 2, 3]
                  for item in documents),
              "every ready adapter inherits only standard descriptors and descriptor 3")
        actions = [
            action.get("action")
            for item in documents
            for action in item.get("actions", [])
            if isinstance(action, dict)
        ]
        for expected in ("busy", "drop", "duplicate", "corrupt", "delay", "reorder"):
            check(expected in actions,
                  f"fixture evidence retains deterministic {expected} adversity")
        check(any(item.get("runtime_crash") == 1 for item in documents),
              "runtime adapter death is retained in fixture evidence")
        check(any(item.get("malformed_hello") is True for item in documents),
              "malformed startup output is retained in fixture evidence")
        check(any(item.get("shutdown") is True for item in documents),
              "graceful adapter shutdown is retained in fixture evidence")
        record_case("descriptor isolation and bounded fixture evidence", before, begin)

        status = "PASS"
    except BaseException as error:
        failure = f"{type(error).__name__}: {error}"
        cases.append(
            {
                "name": "suite failure",
                "status": "FAIL",
                "assertions": 0,
                "elapsed_seconds": 0.0,
                "detail": failure,
            }
        )

    summary = {
        "format": "NATRAV_EXTERNAL_PACKET_ADAPTER_SUITE_V1",
        "status": status,
        "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "cases_passed": sum(item["status"] == "PASS" for item in cases),
        "cases_total": len(cases),
        "assertions": assertions,
        "commands": len(commands),
        "elapsed_seconds": time.monotonic() - started,
        "feature": EXPECTED_FEATURE,
        "cases": cases,
        "command_records": commands,
    }
    if failure is not None:
        summary["failure"] = failure
    (output / "SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(
        json.dumps(
            {key: value for key, value in summary.items()
             if key not in {"cases", "command_records"}},
            sort_keys=True,
        ),
        flush=True,
    )
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
