#!/usr/bin/env python3
"""Accepted legacy stops survive response loss; rejected or incomplete requests never stop."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import struct
import time
from typing import Any, Callable

from run_persistent import Harness, free_port, operation, raw_control
from run_local_administration import (
    expose_control_for_uid,
    restore_owner_only_control,
    run_as_uid,
    v8_config,
)
from run_state_authentication import independent_open, inspect, migrate, new_key, start
from run_control_authorization import Client, packet, text
from run_live_configuration import activate, candidate
from run_authorization_actions import (
    action_payload,
    generation,
    independent_record,
    write_config,
)

DELEGATED_UID = 65534
CASES = (
    "immediate_response_loss",
    "completed_drain_response_loss",
    "deadline_drain_preserves_outbound",
    "deadline_drain_preserves_action",
    "preacceptance_rejections",
    "post_decode_revocation",
    "competing_lifecycle_and_signal",
)


def setup_keyed(
    h: Harness,
    name: str,
    *,
    peers: list[tuple[str, int]] | None = None,
    grants: list[tuple[int, list[str]]] | None = None,
    environment: dict[str, str] | None = None,
    node: str = "A",
):
    root = h.runtime / name
    root.mkdir(mode=0o755)
    state = root / "state"
    inspect(h, name + "-initialize", state, node=node)
    key = new_key(h, root, name + "-state")
    migrate(h, name + "-migrate", state, key, node=node)
    config = v8_config(
        h,
        name,
        node,
        state,
        free_port(),
        name + "-g1",
        grants or [(os.geteuid(), ["ALL"])],
        peers=peers,
        deadline_ms=3000,
    )
    daemon = start(h, name, config, state, key, environment)
    return root, state, key, config, daemon


def drop_after_complete_request(control: Path, payload: bytes) -> None:
    """Deliver one complete frame, then force the server's reply write to fail."""
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as channel:
        channel.settimeout(3)
        channel.connect(str(control))
        channel.sendall(struct.pack("!I", len(payload)) + payload)
        channel.setsockopt(
            socket.SOL_SOCKET,
            socket.SO_LINGER,
            struct.pack("ii", 1, 0),
        )


def drop_partial_request(control: Path, declared: int, fragment: bytes) -> None:
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as channel:
        channel.settimeout(3)
        channel.connect(str(control))
        channel.sendall(struct.pack("!I", declared) + fragment)
        channel.setsockopt(
            socket.SOL_SOCKET,
            socket.SO_LINGER,
            struct.pack("ii", 1, 0),
        )


def wait_stopped(h: Harness, daemon, label: str, timeout: float = 12.0) -> None:
    assert daemon.process is not None
    daemon.process.wait(timeout=timeout)
    h.check(daemon.process.returncode == 0, label + " exits successfully")
    daemon._close_files()
    h.check(not daemon.control.exists(), label + " removes its control socket")


def verify_keyed_state(
    h: Harness,
    label: str,
    state: Path,
    key: Path,
    node: str = "A",
) -> tuple[dict[str, Any], bytes]:
    raw = (state / "state.journal").read_bytes()
    independent_open(raw, key)
    snapshot = inspect(h, label, state, key, node=node)
    h.check((state / "state.journal").read_bytes() == raw, label + " replay is observational")
    return snapshot, raw


def lifecycle_kinds(snapshot: dict[str, Any]) -> list[str]:
    return [event["kind"] for event in snapshot["lifecycle"]["events"]]


def run_suite(h: Harness, selected: set[str] | None) -> None:
    def case(name: str, function: Callable[[], None]) -> None:
        if selected is None or name in selected:
            h.case(name, function)

    def immediate_response_loss() -> None:
        _, state, key, config, daemon = setup_keyed(
            h,
            "lost-immediate",
            environment={
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_COMMAND": "SHUTDOWN",
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_PAUSE_MS": "350",
            },
        )
        drop_after_complete_request(daemon.control, packet(4))
        wait_stopped(h, daemon, "response-lost immediate shutdown")
        snapshot, raw = verify_keyed_state(h, "lost-immediate-offline", state, key)
        kinds = lifecycle_kinds(snapshot)
        h.check(kinds[-1] == "SHUTDOWN_REQUESTED", "accepted immediate stop remains durable")
        h.check(kinds.count("SHUTDOWN_REQUESTED") == 1, "one response-lost request records one stop")
        restarted = start(h, "lost-immediate-restart", config, state, key)
        h.check(
            h.status("lost-immediate-restarted", state, logical_digest=False)["lifecycle"]["mode"] == "RUNNING",
            "ordinary immediate-stop provenance does not create interrupted drain",
        )
        h.check((state / "state.journal").read_bytes() == raw, "restart changes no authenticated bytes")
        restarted.shutdown()

    case("immediate_response_loss", immediate_response_loss)

    def completed_drain_response_loss() -> None:
        _, state, key, config, daemon = setup_keyed(
            h,
            "lost-completed-drain",
            environment={
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_COMMAND": "DRAIN_SHUTDOWN",
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_PAUSE_MS": "350",
            },
        )
        drop_after_complete_request(
            daemon.control,
            packet(14, struct.pack("!I", 500), text("completed response-loss drain")),
        )
        wait_stopped(h, daemon, "response-lost completed drain")
        snapshot, _ = verify_keyed_state(h, "lost-completed-offline", state, key)
        kinds = lifecycle_kinds(snapshot)
        h.check(kinds[-2:] == ["DRAIN_STARTED", "DRAIN_COMPLETED"], "completed drain records both exact boundaries")
        h.check(snapshot["outbox"]["pending"] == 0 and snapshot["actions"]["pending"] == 0, "empty completed drain has no obligations")
        restarted = start(h, "lost-completed-restart", config, state, key)
        status = h.status("lost-completed-restarted", state, logical_digest=False)
        h.check(status["lifecycle"]["mode"] == "RUNNING" and status["lifecycle"]["interrupted_drain"] is False, "completed lost-response drain restarts normally")
        restarted.shutdown()

    case("completed_drain_response_loss", completed_drain_response_loss)

    def deadline_drain_preserves_outbound() -> None:
        unavailable = free_port()
        _, state, key, config, daemon = setup_keyed(
            h,
            "lost-outbound-deadline",
            peers=[("B", unavailable)],
            environment={
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_COMMAND": "DRAIN_SHUTDOWN",
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_PAUSE_MS": "200",
            },
        )
        op = operation("response-loss-pending-outbound")
        h.run(
            "lost-outbound-submit",
            [
                "submit", "--control", str(daemon.control), "--node", "A",
                "--peer", "B", "--scope", "admin/test", "--operation", op,
                "--payload-text", "preserve this obligation", "--deadline-ms", "2000",
            ],
        )
        h.check(h.status("lost-outbound-before", state)["outbox"]["pending"] == 1, "outbound is pending before drain")
        drop_after_complete_request(
            daemon.control,
            packet(14, struct.pack("!I", 150), text("deadline with pending outbound")),
        )
        wait_stopped(h, daemon, "response-lost deadline drain")
        snapshot, _ = verify_keyed_state(h, "lost-outbound-offline", state, key)
        kinds = lifecycle_kinds(snapshot)
        h.check(kinds[-2:] == ["DRAIN_STARTED", "DRAIN_DEADLINE"], "deadline drain records exact terminal kind")
        h.check(snapshot["outbox"]["pending"] == 1 and snapshot["outbox"]["acked"] == 0, "response loss neither cancels nor acknowledges outbound work")
        restarted = start(h, "lost-outbound-restart", config, state, key)
        status = h.status("lost-outbound-restarted", state)
        h.check(status["lifecycle"]["mode"] == "RUNNING" and status["outbox"]["pending"] == 1, "deadline stop restarts with exact obligation")
        restarted.shutdown()

    case("deadline_drain_preserves_outbound", deadline_drain_preserves_outbound)

    def deadline_drain_preserves_action() -> None:
        root = h.runtime / "lost-action-deadline"
        root.mkdir(mode=0o755)
        state = root / "state"
        inspect(h, "lost-action-initialize", state, node="B")
        key = new_key(h, root, "lost-action-state")
        migrate(h, "lost-action-migrate", state, key, node="B")
        port = free_port()
        config = write_config(
            h,
            "lost-action",
            "B",
            state,
            port,
            "B",
            [],
            [("A", generation("A"), "ACTIVE", "A")],
            [("A", "*", "ACTION", "counter.add")],
            counter_budget=1000,
            maximum_increment=100,
            maximum_defer_ms=600000,
            action_expiry_ms=86400000,
            deadline_ms=3000,
        )
        config.write_text(
            config.read_text().replace("CONFIG_V6", "CONFIG_V8")
            + "runtime_generation=lost-action-g1\n"
            + f"local_control={os.geteuid()},ALL\n"
        )
        daemon = start(
            h,
            "lost-action",
            config,
            state,
            key,
            {
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_COMMAND": "DRAIN_SHUTDOWN",
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_PAUSE_MS": "200",
            },
        )
        action_id = operation("response-loss-pending-action")
        receipt = independent_record(
            h,
            port,
            "A",
            "A",
            "B",
            action_id,
            "actions/counter.add/v1",
            action_payload(7, 600000),
        )
        h.check(receipt.get("kind") == "receipt", "actual TLS admission records the pending action")
        h.check(h.status("lost-action-before", state)["actions"]["pending"] == 1, "action is pending before drain")
        drop_after_complete_request(
            daemon.control,
            packet(14, struct.pack("!I", 150), text("deadline with pending action")),
        )
        wait_stopped(h, daemon, "response-lost action deadline")
        snapshot, _ = verify_keyed_state(h, "lost-action-offline", state, key, node="B")
        h.check(lifecycle_kinds(snapshot)[-2:] == ["DRAIN_STARTED", "DRAIN_DEADLINE"], "pending-action drain reaches its bounded deadline")
        h.check(snapshot["actions"]["pending"] == 1 and snapshot["actions"]["counter_value"] == 0, "response loss neither executes nor erases deferred action")
        restarted = start(h, "lost-action-restart", config, state, key)
        status = h.status("lost-action-restarted", state)
        h.check(status["actions"]["pending"] == 1 and status["actions"]["counter_value"] == 0, "restart reconstructs exact deferred action")
        restarted.shutdown()

    case("deadline_drain_preserves_action", deadline_drain_preserves_action)

    def preacceptance_rejections() -> None:
        state = h.runtime / "preacceptance"
        config = v8_config(
            h,
            "preacceptance",
            "A",
            state,
            free_port(),
            "preacceptance-g1",
            [(os.geteuid(), ["ALL"]), (DELEGATED_UID, ["INSPECT"])],
        )
        daemon = h.start("preacceptance", config, state, {
            "NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER": "1",
        })
        expose_control_for_uid(state)

        ok, malformed = raw_control(daemon.control, packet(4, b"x"))
        h.check(not ok and malformed.get("ok") is False and "state_head" not in malformed, "extra bytes cannot become stop intent")
        h.check(daemon.process is not None and daemon.process.poll() is None, "malformed complete request leaves process running")

        drop_partial_request(daemon.control, 5, b"NOC1")
        time.sleep(0.25)
        h.check(daemon.process is not None and daemon.process.poll() is None, "incomplete frame cannot become stop intent")
        h.check(h.status("preacceptance-after-partial", state, logical_digest=False)["lifecycle"]["mode"] == "RUNNING", "partial response loss leaves service running")

        denied = run_as_uid(
            h,
            "preacceptance-unauthorized",
            DELEGATED_UID,
            DELEGATED_UID,
            ["shutdown", "--control", str(daemon.control), "--deadline-ms", "2000"],
            3,
        )
        h.check(denied and denied.get("code") == "LOCAL_CONTROL_CLASS_DENIED", "fully decoded unauthorized stop is denied")
        h.check(daemon.process is not None and daemon.process.poll() is None, "unauthorized stop leaves process running")
        restore_owner_only_control(state)
        daemon.shutdown()
        snapshot = inspect(h, "preacceptance-offline", state)
        h.check(lifecycle_kinds(snapshot).count("SHUTDOWN_REQUESTED") == 1, "only final authorized cleanup records stop")

    case("preacceptance_rejections", preacceptance_rejections)

    def post_decode_revocation() -> None:
        state = h.runtime / "revoked-partial"
        config = v8_config(
            h,
            "revoked-partial",
            "A",
            state,
            free_port(),
            "revoked-g1",
            [(os.geteuid(), ["ALL"]), (DELEGATED_UID, ["SHUTDOWN"])],
        )
        daemon = h.start("revoked-partial", config, state, {
            "NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER": "1",
        })
        expose_control_for_uid(state)
        client = Client(h, daemon, "revoked-partial-client", packet(4), uid=DELEGATED_UID, split=True)
        try:
            replacement = candidate(
                h,
                config,
                "revoked-partial-candidate",
                "revoked-g2",
                lambda raw: "\n".join(
                    f"local_control={DELEGATED_UID},INSPECT" if line.startswith(f"local_control={DELEGATED_UID},") else line
                    for line in raw.splitlines()
                ) + "\n",
            )
            activate(h, "revoke-before-decode", state, replacement)
            denied = client.finish()
            h.check(denied.get("code") == "LOCAL_CONTROL_CLASS_DENIED", "current policy, not connection-time policy, governs stop")
            h.check(daemon.process is not None and daemon.process.poll() is None, "revoked partial request never becomes stop intent")
            h.check(h.status("revoked-partial-still-running", state, logical_digest=False)["lifecycle"]["mode"] == "RUNNING", "revocation leaves lifecycle unchanged")
        finally:
            client.close()
        restore_owner_only_control(state)
        daemon.shutdown()

    case("post_decode_revocation", post_decode_revocation)

    def competing_lifecycle_and_signal() -> None:
        unavailable = free_port()
        _, state, key, _, daemon = setup_keyed(
            h,
            "competing-drain",
            peers=[("B", unavailable)],
            environment={"NATRAV_OVERLAY_TEST_DRAIN_AFTER_START_MS": "450"},
        )
        h.run(
            "competing-submit",
            [
                "submit", "--control", str(daemon.control), "--node", "A", "--peer", "B",
                "--scope", "admin/test", "--operation", operation("competing-pending"),
                "--payload-text", "hold drain open",
            ],
        )
        drop_after_complete_request(
            daemon.control,
            packet(14, struct.pack("!I", 150), text("response-lost competing drain")),
        )
        h.wait(
            "competing drain publishes DRAINING",
            lambda: h.status("competing-draining", state, logical_digest=False)["lifecycle"]["mode"] == "DRAINING",
            4.0,
        )
        denied = h.run(
            "competing-quiesce-denied",
            ["quiesce", "--control", str(daemon.control), "--reason", "cannot replace drain"],
            expected=3,
        )
        h.check(denied and denied.get("code") == "SERVICE_DRAINING", "competing lifecycle command cannot cancel accepted drain")
        wait_stopped(h, daemon, "competing response-lost drain")
        snapshot, _ = verify_keyed_state(h, "competing-offline", state, key)
        h.check(lifecycle_kinds(snapshot)[-1] == "DRAIN_DEADLINE", "accepted drain remains terminal after competing denial")

        signal_state = h.runtime / "signal-stop"
        signal_config = v8_config(
            h,
            "signal-stop",
            "S",
            signal_state,
            free_port(),
            "signal-g1",
            [(os.geteuid(), ["ALL"])],
        )
        signaled = h.start("signal-stop", signal_config, signal_state)
        assert signaled.process is not None
        signaled.process.send_signal(signal.SIGTERM)
        signaled.process.wait(timeout=8)
        h.check(signaled.process.returncode == 0, "signal-driven stop remains successful")
        signaled._close_files()
        h.check(not signaled.control.exists(), "signal-driven stop removes control socket")
        signal_snapshot = inspect(h, "signal-stop-offline", signal_state, node="S")
        h.check("SHUTDOWN_REQUESTED" not in lifecycle_kinds(signal_snapshot), "signal stop does not fabricate a local shutdown request")

    case("competing_lifecycle_and_signal", competing_lifecycle_and_signal)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append", choices=CASES)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    harness = Harness(args.binary, args.output)
    started = time.time()
    code = 1
    try:
        run_suite(harness, set(args.case) if args.case else None)
        code = 0
    except BaseException as error:
        import traceback
        (harness.output / "FAILURE.txt").write_text(traceback.format_exc())
        print(f"FAIL: {type(error).__name__}: {error}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_RESPONSE_LOSS_STOPPING_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(item["status"] == "PASS" for item in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (
            ("SUMMARY.json", summary),
            ("CASES.json", harness.cases),
            ("COMMANDS.json", harness.commands),
        ):
            (harness.output / name).write_text(json.dumps(value, indent=2) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
