#!/usr/bin/env python3
"""Private finite custody-envelope model and negative controls."""
from __future__ import annotations
import argparse, hashlib, json, os, subprocess, time
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--sanitize-probe", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    if args.output.exists() or root in args.output.resolve().parents:
        parser.error("output must be new and outside source")
    args.output.mkdir(parents=True)
    logs = args.output / "logs"
    logs.mkdir()
    assertions = 0
    cases = []
    started = time.monotonic()
    failure = None

    def check(value: bool, detail: str) -> None:
        nonlocal assertions
        assertions += 1
        if not value:
            raise AssertionError(detail)

    def case(name: str, fn) -> None:
        begin = time.monotonic()
        try:
            fn()
            cases.append({"name": name, "status": "PASS",
                          "elapsed_seconds": time.monotonic() - begin})
        except BaseException as error:
            cases.append({"name": name, "status": "FAIL",
                          "elapsed_seconds": time.monotonic() - begin,
                          "failure": repr(error)})
            raise

    def version_case() -> None:
        result = subprocess.run([str(args.binary.resolve()), "version"],
                                capture_output=True, text=True, timeout=30)
        (logs / "version.stdout").write_text(result.stdout)
        (logs / "version.stderr").write_text(result.stderr)
        check(result.returncode == 0, result.stderr)
        version = json.loads(result.stdout)
        check(version.get("version") == "0613", "revision identity")
        check(version.get("custody_envelope_model") ==
              "PRIVATE_FINITE_CUSTODY_ENVELOPE_MODEL_V1", "feature marker")
        check(version.get("configured_custody_relay") is True,
              "explicit native durable custody service is available")
        check(version.get("automatic_route_relay") is False and
              version.get("open_relay") is False,
              "ordinary routes remain non-relaying and closed")
        check(version.get("custody_relay_policy") ==
              "V21_DURABLE_CUSTODY_RELAY_POLICY_V1", "authority marker")
        check(version.get("durable_custody_evidence") ==
              "DURABLE_CUSTODY_EVIDENCE_V1", "durable evidence marker")
        check(version.get("custody_bundle") ==
              "FINITE_CUSTODY_BUNDLE_V1", "bundle marker")

    def boundary_case() -> None:
        build = (root / "node/build.sh").read_text()
        check(build.count("src/custody_envelope.cpp") == 1,
              "production build owns the model")
        main = (root / "node/src/main.cpp").read_text()
        check("custody_envelope_model" in main and
              "configured_custody_relay" in main,
              "version evidence is explicit")
        consumers = []
        for path in (root / "node/src").glob("*.cpp"):
            if path.name == "custody_envelope.cpp":
                continue
            if '#include "custody_envelope.hpp"' in path.read_text():
                consumers.append(path.name)
        check(not consumers, "private model has runtime consumers: " + ",".join(consumers))
        for name in ("config.cpp", "transport.cpp", "adapter_transport.cpp",
                     "daemon.cpp", "runtime.cpp"):
            text = (root / "node/src" / name).read_text()
            check("NHCE0001" not in text and "NHCR0001" not in text,
                  f"{name} does not register custody relay")

    native_assertions = [0]
    def native_case() -> None:
        flags = ["-D_GNU_SOURCE", "-std=c++20", "-O1", "-g0", "-Wall",
                 "-Wextra", "-Wpedantic", "-Wconversion", "-Wsign-conversion",
                 "-Wshadow", "-Wformat=2", "-Werror", "-pthread"]
        if args.sanitize_probe:
            flags += ["-O0", "-fsanitize=address,undefined",
                      "-fno-omit-frame-pointer", "-fno-pie", "-no-pie"]
        output = args.output / "custody-envelope-probe"
        sources = ["node/tests/custody_envelope_probe.cpp",
                   "node/src/custody_envelope.cpp", "node/src/common.cpp",
                   "foundation/src/core.cpp"]
        command = ["g++", *flags, "-I" + str(root / "foundation/include"),
                   "-I" + str(root / "node/src"),
                   *[str(root / path) for path in sources],
                   "-lssl", "-lcrypto", "-lz", "-lzstd", "-o", str(output)]
        (logs / "compile-command.json").write_text(json.dumps(command, indent=2) + "\n")
        compiled = subprocess.run(command, capture_output=True, text=True, timeout=240)
        (logs / "compile.stdout").write_text(compiled.stdout)
        (logs / "compile.stderr").write_text(compiled.stderr)
        check(compiled.returncode == 0, compiled.stderr)
        environment = dict(os.environ)
        if args.sanitize_probe:
            environment["ASAN_OPTIONS"] = "detect_leaks=1:halt_on_error=1"
            environment["UBSAN_OPTIONS"] = "halt_on_error=1:print_stacktrace=1"
        executed = subprocess.run([str(output)], capture_output=True, text=True,
                                  timeout=120, env=environment)
        (logs / "probe.stdout").write_text(executed.stdout)
        (logs / "probe.stderr").write_text(executed.stderr)
        check(executed.returncode == 0, executed.stderr)
        report = json.loads(executed.stdout)
        check(report.get("status") == "PASS", "native model result")
        native_assertions[0] += int(report.get("assertions", 0))
        if args.sanitize_probe:
            check("AddressSanitizer" not in executed.stderr and
                  "runtime error:" not in executed.stderr and
                  "LeakSanitizer" not in executed.stderr,
                  "sanitizer diagnostic detected")

    status = "FAIL"
    try:
        case("release_marker_and_private_boundary", version_case)
        case("no_runtime_route_or_configuration_registration", boundary_case)
        case("canonical_signed_state_machine_and_negative_paths", native_case)
        status = "PASS"
    except BaseException as error:
        failure = repr(error)
        import traceback
        traceback.print_exc()
        (args.output / "FAILURE.txt").write_text(failure + "\n")
    summary = {
        "format": "NATRAV_PRIVATE_CUSTODY_ENVELOPE_TEST_V1",
        "status": status,
        "binary_sha256": hashlib.sha256(args.binary.read_bytes()).hexdigest(),
        "cases": cases,
        "cases_passed": sum(item["status"] == "PASS" for item in cases),
        "cases_total": len(cases),
        "assertions": assertions + native_assertions[0],
        "commands": 3,
        "elapsed_seconds": time.monotonic() - started,
        "failure": failure,
        "sanitized_native_probe": args.sanitize_probe,
    }
    (args.output / "SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: value for key, value in summary.items() if key != "cases"},
                     sort_keys=True))
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
