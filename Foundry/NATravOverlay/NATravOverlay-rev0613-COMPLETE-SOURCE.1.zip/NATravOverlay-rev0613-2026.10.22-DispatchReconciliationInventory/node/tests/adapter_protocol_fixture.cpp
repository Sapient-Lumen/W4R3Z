#include <algorithm>
#include <array>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <fcntl.h>
#include <fstream>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <unistd.h>
#include <vector>

#ifndef NATRAV_FIXTURE_MARKER
#define NATRAV_FIXTURE_MARKER "UNSET"
#endif

extern char** environ;

namespace {

using Bytes = std::vector<std::uint8_t>;

inline constexpr std::array<std::uint8_t, 8U> kMagic{
    'N', 'A', 'P', 'A', '0', '0', '0', '1'};
inline constexpr std::size_t kHeaderBytes = 36U;

enum class FrameType : std::uint8_t {
    hello_request = 1U,
    hello_response = 2U,
    transmit_request = 3U,
    transmit_response = 4U,
    receive_request = 5U,
    receive_response = 6U,
    ping_request = 7U,
    ping_response = 8U,
    shutdown_request = 9U,
    shutdown_response = 10U,
    fault = 11U,
};

enum class Status : std::uint32_t {
    ok = 0U,
    no_data = 1U,
    malformed = 3U,
};

struct Frame final {
    FrameType type{FrameType::fault};
    std::uint64_t sequence{0U};
    std::uint32_t deadline_ms{0U};
    Status status{Status::ok};
    Bytes payload{};
};

[[nodiscard]] std::uint32_t crc32(
    const std::span<const std::uint8_t> bytes) noexcept {
    std::uint32_t value = 0xffffffffU;
    for (const auto byte : bytes) {
        value ^= byte;
        for (std::size_t bit = 0U; bit < 8U; ++bit) {
            const std::uint32_t mask =
                static_cast<std::uint32_t>(0U - (value & 1U));
            value = (value >> 1U) ^ (0xedb88320U & mask);
        }
    }
    return ~value;
}

void append_be16(Bytes& out, const std::uint16_t value) {
    out.push_back(static_cast<std::uint8_t>((value >> 8U) & 0xffU));
    out.push_back(static_cast<std::uint8_t>(value & 0xffU));
}

void append_be32(Bytes& out, const std::uint32_t value) {
    for (int shift = 24; shift >= 0; shift -= 8) {
        out.push_back(static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(shift)) & 0xffU));
    }
}

void append_be64(Bytes& out, const std::uint64_t value) {
    for (int shift = 56; shift >= 0; shift -= 8) {
        out.push_back(static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(shift)) & 0xffU));
    }
}

[[nodiscard]] std::uint32_t read_be32(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) {
    if (offset > bytes.size() || bytes.size() - offset < 4U) {
        throw std::runtime_error("truncated u32");
    }
    std::uint32_t value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
        value = (value << 8U) | bytes[offset + index];
    }
    return value;
}

[[nodiscard]] std::uint64_t read_be64(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) {
    if (offset > bytes.size() || bytes.size() - offset < 8U) {
        throw std::runtime_error("truncated u64");
    }
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value = (value << 8U) | bytes[offset + index];
    }
    return value;
}

[[nodiscard]] Bytes encode(const Frame& frame) {
    Bytes output;
    output.reserve(kHeaderBytes + frame.payload.size());
    output.insert(output.end(), kMagic.begin(), kMagic.end());
    output.push_back(static_cast<std::uint8_t>(frame.type));
    output.push_back(0U);
    append_be16(output, 0U);
    append_be64(output, frame.sequence);
    append_be32(output, frame.deadline_ms);
    append_be32(output, static_cast<std::uint32_t>(frame.status));
    append_be32(output, static_cast<std::uint32_t>(frame.payload.size()));
    Bytes checksum_input(output);
    checksum_input.insert(
        checksum_input.end(), frame.payload.begin(), frame.payload.end());
    append_be32(output, crc32(checksum_input));
    output.insert(output.end(), frame.payload.begin(), frame.payload.end());
    return output;
}

[[nodiscard]] Frame decode(const std::span<const std::uint8_t> bytes) {
    if (bytes.size() < kHeaderBytes ||
        !std::equal(kMagic.begin(), kMagic.end(), bytes.begin()) ||
        bytes[9U] != 0U || bytes[10U] != 0U || bytes[11U] != 0U) {
        throw std::runtime_error("invalid frame prefix");
    }
    const auto payload_size = read_be32(bytes, 28U);
    if (payload_size != bytes.size() - kHeaderBytes) {
        throw std::runtime_error("invalid frame length");
    }
    Bytes checksum_input(bytes.begin(), bytes.begin() + 32);
    checksum_input.insert(
        checksum_input.end(), bytes.begin() + static_cast<std::ptrdiff_t>(kHeaderBytes),
        bytes.end());
    if (crc32(checksum_input) != read_be32(bytes, 32U)) {
        throw std::runtime_error("invalid frame checksum");
    }
    return Frame{
        .type = static_cast<FrameType>(bytes[8U]),
        .sequence = read_be64(bytes, 12U),
        .deadline_ms = read_be32(bytes, 20U),
        .status = static_cast<Status>(read_be32(bytes, 24U)),
        .payload = Bytes(
            bytes.begin() + static_cast<std::ptrdiff_t>(kHeaderBytes), bytes.end()),
    };
}

void send_frame(const int descriptor, const Frame& frame) {
    const auto bytes = encode(frame);
    ssize_t count = -1;
    do {
        count = ::send(descriptor, bytes.data(), bytes.size(), MSG_NOSIGNAL);
    } while (count < 0 && errno == EINTR);
    if (count < 0 || static_cast<std::size_t>(count) != bytes.size()) {
        throw std::runtime_error("frame send failed");
    }
}

[[nodiscard]] Frame receive_frame(const int descriptor) {
    Bytes bytes(1'048'576U);
    ssize_t count = -1;
    do {
        count = ::recv(descriptor, bytes.data(), bytes.size(), 0);
    } while (count < 0 && errno == EINTR);
    if (count <= 0) {
        throw std::runtime_error("frame receive failed");
    }
    bytes.resize(static_cast<std::size_t>(count));
    return decode(bytes);
}

[[nodiscard]] std::size_t environment_count() noexcept {
    std::size_t count = 0U;
    if (environ != nullptr) {
        while (environ[count] != nullptr) {
            ++count;
        }
    }
    return count;
}

[[nodiscard]] std::vector<int> open_extra_descriptors() {
    std::vector<int> descriptors;
    for (int descriptor = 4; descriptor < 64; ++descriptor) {
        if (::fcntl(descriptor, F_GETFD, 0) >= 0 || errno != EBADF) {
            descriptors.push_back(descriptor);
        }
    }
    return descriptors;
}

void write_report(
    const std::string& path,
    const int argc,
    char* argv[],
    const bool shutdown) {
    const auto environment_entries = environment_count();
    const auto extra_descriptors = open_extra_descriptors();
    const int no_new_privileges =
        ::prctl(PR_GET_NO_NEW_PRIVS, 0L, 0L, 0L, 0L);
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output) {
        throw std::runtime_error("report open failed");
    }
    output << "marker=" << NATRAV_FIXTURE_MARKER << '\n';
    output << "argc=" << argc << '\n';
    for (int index = 1; index < argc; ++index) {
        output << "argv=" << argv[index] << '\n';
    }
    output << "environment-count=" << environment_entries << '\n';
    output << "extra-fd-count=" << extra_descriptors.size() << '\n';
    output << "no-new-privs=" << no_new_privileges << '\n';
    output << "shutdown=" << (shutdown ? 1 : 0) << '\n';
}

}  // namespace

int main(int argc, char* argv[]) {
    try {
        if (argc != 2 || std::string_view(argv[1]).empty()) {
            return 70;
        }
        const char* adapter_fd = ::getenv("NATRAV_ADAPTER_FD");
        const char* protocol = ::getenv("NATRAV_ADAPTER_PROTOCOL");
        if (adapter_fd == nullptr || std::string_view(adapter_fd) != "3" ||
            protocol == nullptr || std::string_view(protocol) != "NAPA0001") {
            return 71;
        }
        write_report(argv[1], argc, argv, false);
        std::deque<Bytes> packets;
        std::size_t mtu = 512U;
        std::size_t frame_limit = 65'536U;
        while (true) {
            const auto request = receive_frame(3);
            switch (request.type) {
                case FrameType::hello_request: {
                    if (request.payload.size() != 20U) {
                        return 72;
                    }
                    const auto profile = read_be32(request.payload, 0U);
                    mtu = read_be32(request.payload, 4U);
                    frame_limit = read_be32(request.payload, 8U);
                    const auto queue = read_be32(request.payload, 12U);
                    const auto outstanding = read_be32(request.payload, 16U);
                    if (profile != 1U || mtu < 256U || outstanding != 1U ||
                        frame_limit < kHeaderBytes + mtu || queue < mtu) {
                        return 73;
                    }
                    Bytes payload;
                    append_be32(payload, profile);
                    append_be32(payload, static_cast<std::uint32_t>(mtu));
                    append_be32(payload, static_cast<std::uint32_t>(frame_limit));
                    append_be32(payload, queue);
                    append_be32(payload, outstanding);
                    send_frame(3, Frame{
                        .type = FrameType::hello_response,
                        .sequence = request.sequence,
                        .status = Status::ok,
                        .payload = std::move(payload),
                    });
                    break;
                }
                case FrameType::transmit_request:
                    if (request.payload.empty() || request.payload.size() > mtu) {
                        send_frame(3, Frame{
                            .type = FrameType::fault,
                            .sequence = request.sequence,
                            .status = Status::malformed,
                        });
                    } else {
                        packets.push_back(request.payload);
                        send_frame(3, Frame{
                            .type = FrameType::transmit_response,
                            .sequence = request.sequence,
                            .status = Status::ok,
                        });
                    }
                    break;
                case FrameType::receive_request:
                    if (packets.empty()) {
                        send_frame(3, Frame{
                            .type = FrameType::receive_response,
                            .sequence = request.sequence,
                            .status = Status::no_data,
                        });
                    } else {
                        auto payload = std::move(packets.front());
                        packets.pop_front();
                        send_frame(3, Frame{
                            .type = FrameType::receive_response,
                            .sequence = request.sequence,
                            .status = Status::ok,
                            .payload = std::move(payload),
                        });
                    }
                    break;
                case FrameType::ping_request:
                    send_frame(3, Frame{
                        .type = FrameType::ping_response,
                        .sequence = request.sequence,
                        .status = Status::ok,
                    });
                    break;
                case FrameType::shutdown_request:
                    send_frame(3, Frame{
                        .type = FrameType::shutdown_response,
                        .sequence = request.sequence,
                        .status = Status::ok,
                    });
                    write_report(argv[1], argc, argv, true);
                    return 0;
                default:
                    send_frame(3, Frame{
                        .type = FrameType::fault,
                        .sequence = request.sequence,
                        .status = Status::malformed,
                    });
                    break;
            }
        }
    } catch (...) {
        return 74;
    }
}
