#include "delivery_index.hpp"
#include <algorithm>
#include <iostream>
#include <limits>
#include <map>
#include <random>
#include <stdexcept>
#include <vector>
using namespace natrav_overlay;
int main() {
    std::uint64_t checks=0U, maximum_nodes=0U;
    auto check=[&](bool value){++checks;if(!value)throw std::runtime_error("delivery index differential mismatch");};
    DeadlineIndex times;
    std::map<std::size_t,std::uint64_t> reference;
    std::mt19937_64 rng(532U);
    for(std::size_t i=0;i<65537U;++i){times.put(i,10000U+i);reference[i]=10000U+i;}
    times.put(65536U,1U);reference[65536U]=1U;
    std::uint64_t visits=0U;
    check(times.first_due(1U,visits)==65536U);check(visits<=32U);check(times.valid());
    const auto delayed_seek_nodes=visits;
    for(std::size_t iteration=0;iteration<20000U;++iteration){
        const auto key=static_cast<std::size_t>(rng()%70000U);
        if(iteration%3U==0U){times.erase(key);reference.erase(key);}
        else {const auto time=rng()%90000U;times.put(key,time);reference[key]=time;}
        const auto now=rng()%90000U; // includes backwards movement
        std::optional<std::size_t> wanted;std::optional<std::uint64_t> earliest;
        for(const auto& [id,time]:reference){if(time<=now&&!wanted)wanted=id;if(!earliest||time<*earliest)earliest=time;}
        visits=0U;check(times.first_due(now,visits)==wanted);check(times.minimum()==earliest);
        check(times.size()==reference.size());check(visits<=40U);maximum_nodes=std::max(maximum_nodes,visits);
        if(iteration%100U==0U)check(times.valid());
    }
    DeadlineIndex edge;edge.put(4U,std::numeric_limits<std::uint64_t>::max());visits=0U;
    check(!edge.first_due(0U,visits));check(edge.first_due(std::numeric_limits<std::uint64_t>::max(),visits)==4U);
    edge.erase(4U);check(edge.size()==0U&&!edge.minimum()&&edge.valid());

    DeliveryIndex index;
    std::vector<std::optional<DeliveryIndexEntry>> records(4096U);
    const std::vector<DeliveryBinding> bindings={{"g1","pin1"},{"g2","pin2"},{"revoked","pin3"}};
    auto create=[&](std::size_t i){return DeliveryIndexEntry{
        "peer-"+std::to_string(i%8U),bindings[static_cast<std::size_t>(rng()%bindings.size())],
        rng()%7U!=0U,rng()%9U==0U,1U+rng()%50000U,rng()%50000U};};
    for(std::size_t i=0;i<records.size();++i){records[i]=create(i);index.touch(i,records[i]);}
    for(std::size_t iteration=0;iteration<12000U;++iteration){
        const auto i=static_cast<std::size_t>(rng()%records.size());
        if(iteration%4U==0U)records[i].reset();else records[i]=create(i);
        index.touch(i,records[i]);
        const auto peer="peer-"+std::to_string(rng()%8U);
        const bool routed=rng()%4U!=0U;
        const auto now=rng()%50001U;
        const std::vector<DeliveryBinding> allowed=iteration%2U==0U?std::vector<DeliveryBinding>{bindings[0]}:
            std::vector<DeliveryBinding>{bindings[0],bindings[1]};
        DeliveryIndexChoice want;std::optional<std::size_t> ready;std::uint64_t count=0U,pending=0U;
        auto wake=[&](std::uint64_t t){if(!want.next_wake||t<*want.next_wake)want.next_wake=t;};
        for(std::size_t n=0;n<records.size();++n){
            if(!records[n])continue;
            ++pending;
            const auto& r=*records[n];if(r.peer!=peer)continue;++count;
            if(r.has_policy)wake(r.expires);
            if(!want.index){
                if(r.has_policy&&now>=r.expires){want.index=n;want.kind=DeliveryChoiceKind::expired;}
                else if(routed&&!r.has_policy){want.index=n;want.kind=DeliveryChoiceKind::initialize_policy;}
                else if(routed&&r.attempts_exhausted){want.index=n;want.kind=DeliveryChoiceKind::attempts_exhausted;}
            }
        }
        if(!want.index&&routed){
            for(std::size_t n=0;n<records.size();++n){
                if(!records[n])continue;
                const auto& r=*records[n];
                if(r.peer!=peer||!r.has_policy||r.attempts_exhausted||std::find(allowed.begin(),allowed.end(),r.binding)==allowed.end())continue;
                wake(r.ready);if(r.ready<=now&&!ready)ready=n;
            }
            if(ready){want.index=ready;want.kind=DeliveryChoiceKind::ready;}
        }
        const auto got=index.select(peer,allowed,now,routed);
        check(got.index==want.index&&got.kind==want.kind&&got.next_wake==want.next_wake);
        check(index.pending(peer)==count);check(index.pending()==pending);
        if(iteration%50U==0U)check(index.valid());
    }
    check(index.select("absent",bindings,100U,true).kind==DeliveryChoiceKind::none);
    check(index.pending("absent")==0U);
    std::cout<<"{\"status\":\"PASS\",\"checks\":"<<checks<<",\"deadline_records\":65537,\"time_mutations\":20000,\"queue_records\":4096,\"queue_mutations\":12000,\"delayed_head_seek_nodes\":"<<delayed_seek_nodes<<",\"maximum_seek_nodes\":"<<maximum_nodes<<"}\n";
}
