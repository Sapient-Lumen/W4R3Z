#!/usr/bin/env python3
"""Read-only authenticated custody-promotion outcome audit validation."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from typing import Any

from run_persistent import Harness
from run_authenticated_recovery import setup
from run_state_expectations import selector, append
from run_state_head_custody import parse_record, exact_args
from run_custody_state_opening import create_anchor
from run_backup_correlated_stop_audit import backup_key, export_backup
from run_state_authentication import new_key
from run_custody_promotion import promote_state_args, promote_backup_args

CASES = (
    "state_not_applied_and_applied",
    "competing_exact_fields_different_domain",
    "source_noop_stale_and_divergent",
    "backup_not_applied_and_applied",
    "backup_trust_and_source_replacement",
    "custody_replacement_race",
    "strict_cli_duplicate_and_no_mutation",
)


def audit_state_args(path: Path, old: dict[str, Any], generation: int,
                     state: Path, key: Path) -> list[str]:
    return ["state-head-custody-promotion-audit", *exact_args(path, old),
        "--new-generation", str(generation), "--state", str(state),
        "--state-auth-key", str(key)]


def audit_backup_args(path: Path, old: dict[str, Any], generation: int,
                      archive: Path, state_key: Path, decrypt_key: Path,
                      certificate: Path, backup_id: str | None = None) -> list[str]:
    args = ["state-head-custody-promotion-audit", *exact_args(path, old),
        "--new-generation", str(generation), "--input", str(archive),
        "--generation", "a-g1", "--state-auth-key", str(state_key),
        "--decrypt-key", str(decrypt_key), "--trusted-cert", str(certificate),
        "--require-signature", "yes", "--require-encryption", "yes"]
    if backup_id is not None:
        args += ["--expected-backup-id", backup_id]
    return args


def run_with_environment(h: Harness, label: str, args: list[str],
                         environment: dict[str, str], expected: int = 0,
                         timeout: int = 30) -> dict[str, Any] | None:
    started = time.time()
    completed = subprocess.run([str(h.binary), *args], capture_output=True,
        text=True, timeout=timeout, env=dict(os.environ, **environment))
    h.commands.append({"label": label, "args": args,
        "returncode": completed.returncode, "stdout": completed.stdout,
        "stderr": completed.stderr, "elapsed_seconds": time.time() - started,
        "environment": sorted(environment)})
    (h.logs / f"{len(h.commands):03d}-{label}.stdout.txt").write_text(completed.stdout)
    (h.logs / f"{len(h.commands):03d}-{label}.stderr.txt").write_text(completed.stderr)
    h.check(completed.returncode == expected,
        f"{label}: return {completed.returncode}, expected {expected}; "
        f"stdout={completed.stdout!r} stderr={completed.stderr!r}")
    lines = [line for line in completed.stdout.splitlines() if line.strip()]
    return json.loads(lines[-1]) if lines else None


def check_common(h: Harness, value: dict[str, Any], old: dict[str, Any],
                 generation: int) -> None:
    h.check(value["format"] ==
        "NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_OUTCOME_AUDIT_V1" and
        value["ok"] is True, "audit has one explicit versioned format")
    h.check(value["operation"] ==
        "READ_ONLY_AUTHENTICATED_PROMOTION_OUTCOME_AUDIT",
        "operation is explicitly read-only")
    h.check(value["intent"]["old_record"]["record_digest"] == old["record_digest"] and
        value["intent"]["old_record"]["state_head"]["selector"] == old["selector"] and
        value["intent"]["intended_new_generation"] == generation,
        "complete intended old account and new generation remain visible")
    h.check(value["mutation"] == "NONE" and value["custody_advanced"] is False and
        value["promotion_retried"] is False and value["state_mutated"] is False and
        value["backup_restored"] is False and value["workers_started"] is False,
        "audit performs no promotion or source mutation")
    h.check(value["response_receipt"] == "NOT_ESTABLISHED" and
        value["freshness"] == "CUSTODIAN_EXPLICIT_SELECTION_NOT_GLOBAL_LATESTNESS",
        "audit is neither receipt proof nor a global freshness claim")
    h.check(value["evidence"]["source_rechecks"] == 2 and
        value["evidence"]["custody_rechecks"] == 1,
        "source and custody are rechecked before success")


def run_suite(h: Harness, selected: set[str] | None) -> None:
    def case(name: str, fn: Any) -> None:
        if selected is None or name in selected:
            h.case(name, fn)

    def state_not_applied_and_applied() -> None:
        root, state, key = setup(h, "promotion-audit-state")
        old_head = selector((state / "state.journal").read_bytes(), key)
        path, old = create_anchor(h, "promotion-audit-state-anchor",
            root / "anchors", old_head, domain="audit-state", generation=7)
        append(h, state, key, "promotion-audit-state-next")
        candidate_head = selector((state / "state.journal").read_bytes(), key)
        state_bytes = (state / "state.journal").read_bytes()
        old_bytes = path.read_bytes()

        pending = h.run("promotion-audit-state-not-applied",
            audit_state_args(path, old, 8, state, key), timeout=30)
        assert pending
        check_common(h, pending, old, 8)
        h.check(pending["classification"] == "NOT_APPLIED_EXACT_OLD_RECORD" and
            pending["source_eligibility"]["eligible"] is True and
            pending["source_eligibility"]["relationship"] ==
                "VERIFIED_APPEND_ONLY_EXTENSION",
            "valid source plus exact old record is classified as not applied")
        h.check(pending["intent"]["derived_state_head"] == candidate_head and
            pending["evidence"]["exact_old_record_present"] is True and
            pending["evidence"]["exact_intended_successor_present"] is False,
            "candidate is internally derived while exact old custody remains")
        h.check(path.read_bytes() == old_bytes and
            (state / "state.journal").read_bytes() == state_bytes,
            "not-applied audit changes neither custody nor state")

        promoted = h.run("promotion-audit-state-apply",
            promote_state_args(path, old, 8, state, key), timeout=30)
        assert promoted
        current = parse_record(path.read_bytes())
        applied_bytes = path.read_bytes()
        applied = h.run("promotion-audit-state-applied",
            audit_state_args(path, old, 8, state, key), timeout=30)
        assert applied
        check_common(h, applied, old, 8)
        h.check(applied["classification"] == "APPLIED_EXACT_DERIVED_SUCCESSOR" and
            applied["evidence"]["exact_old_record_present"] is False and
            applied["evidence"]["exact_intended_successor_present"] is True,
            "exact intended generation and derived head are classified as applied")
        h.check(applied["current_custody"]["record_digest"] ==
            current["record_digest"] and
            applied["intent"]["expected_successor_record"]["record_digest"] ==
            current["record_digest"],
            "current and deterministic expected successor accounts agree exactly")
        duplicate = h.run("promotion-audit-state-applied-again",
            audit_state_args(path, old, 8, state, key), timeout=30)
        assert duplicate
        h.check(duplicate["classification"] == "APPLIED_EXACT_DERIVED_SUCCESSOR" and
            duplicate["duplicate_attempt_semantics"] ==
                "OBSERVATIONAL_ONLY_NOT_IDEMPOTENCY_OR_RETRY",
            "repeated audit observes evidence without making promotion idempotent")
        h.check(path.read_bytes() == applied_bytes and
            (state / "state.journal").read_bytes() == state_bytes,
            "applied audits do not rewrite the winner or source")

    case("state_not_applied_and_applied", state_not_applied_and_applied)

    def competing_exact_fields_different_domain() -> None:
        root, state, key = setup(h, "promotion-audit-competing")
        old_head = selector((state / "state.journal").read_bytes(), key)
        directory = root / "anchors"
        path, old = create_anchor(h, "promotion-audit-competing-anchor",
            directory, old_head, domain="intended-domain", generation=5)
        append(h, state, key, "promotion-audit-competing-next")
        candidate_head = selector((state / "state.journal").read_bytes(), key)
        replacement, _ = create_anchor(h, "promotion-audit-competing-record",
            directory, candidate_head, domain="other-custodian", generation=6,
            filename="replacement.head")
        replacement_bytes = replacement.read_bytes()
        os.replace(replacement, path)
        value = h.run("promotion-audit-competing-outcome",
            audit_state_args(path, old, 6, state, key), timeout=30)
        assert value
        check_common(h, value, old, 6)
        h.check(value["classification"] == "CURRENT_CUSTODY_DIVERGED" and
            value["source_eligibility"]["eligible"] is True,
            "a valid candidate does not hide a competing custody winner")
        h.check(value["current_custody"]["custody_domain"] == "other-custodian" and
            value["current_custody"]["custody_generation"] == 6 and
            value["current_custody"]["state_head"]["selector"] == candidate_head,
            "all competing current-custody accounts remain visible")
        h.check(value["evidence"]["exact_intended_successor_present"] is False and
            path.read_bytes() == replacement_bytes,
            "same generation and head with a different domain is not the exact intended record")

    case("competing_exact_fields_different_domain",
         competing_exact_fields_different_domain)

    def source_noop_stale_and_divergent() -> None:
        nroot, nstate, nkey = setup(h, "promotion-audit-noop")
        nhead = selector((nstate / "state.journal").read_bytes(), nkey)
        npath, nold = create_anchor(h, "promotion-audit-noop-anchor",
            nroot / "anchors", nhead)
        noop = h.run("promotion-audit-source-noop",
            audit_state_args(npath, nold, 2, nstate, nkey), timeout=30)
        assert noop
        h.check(noop["classification"] == "SOURCE_STALE_OR_DIVERGENT" and
            noop["source_eligibility"]["relationship"] == "EXACT_CURRENT_HEAD_NOOP" and
            noop["source_eligibility"]["promotion_error_code"] ==
                "STATE_HEAD_CUSTODY_PROMOTION_NOOP",
            "exact source no-op is reported as ineligible evidence rather than retried")

        sroot, sstate, skey = setup(h, "promotion-audit-stale")
        stale = sroot / "stale-state"
        shutil.copytree(sstate, stale)
        append(h, sstate, skey, "promotion-audit-stale-next")
        shead = selector((sstate / "state.journal").read_bytes(), skey)
        spath, sold = create_anchor(h, "promotion-audit-stale-anchor",
            sroot / "anchors", shead)
        stale_value = h.run("promotion-audit-source-stale",
            audit_state_args(spath, sold, 2, stale, skey), timeout=30)
        assert stale_value
        h.check(stale_value["classification"] == "SOURCE_STALE_OR_DIVERGENT" and
            stale_value["source_eligibility"]["relationship"] ==
                "AUTHENTICATED_SOURCE_STALE" and
            stale_value["source_eligibility"]["promotion_error_code"] ==
                "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_STALE",
            "older authenticated source is visible as stale")

        droot, left, dkey = setup(h, "promotion-audit-divergent")
        right = droot / "right-branch"
        shutil.copytree(left, right)
        append(h, left, dkey, "promotion-audit-left")
        left_head = selector((left / "state.journal").read_bytes(), dkey)
        dpath, dold = create_anchor(h, "promotion-audit-divergent-anchor",
            droot / "anchors", left_head)
        append(h, right, dkey, "promotion-audit-right-1")
        append(h, right, dkey, "promotion-audit-right-2")
        before = dpath.read_bytes()
        divergent = h.run("promotion-audit-source-divergent",
            audit_state_args(dpath, dold, 2, right, dkey), timeout=30)
        assert divergent
        h.check(divergent["classification"] == "SOURCE_STALE_OR_DIVERGENT" and
            divergent["source_eligibility"]["relationship"] ==
                "AUTHENTICATED_SOURCE_DIVERGENT" and
            divergent["source_eligibility"]["promotion_error_code"] ==
                "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_DIVERGENT",
            "longer valid branch without the exact prefix is reported as divergent")
        h.check(dpath.read_bytes() == before,
            "ineligible-source audits preserve the exact current custody record")

    case("source_noop_stale_and_divergent", source_noop_stale_and_divergent)

    def backup_not_applied_and_applied() -> None:
        root, state, key = setup(h, "promotion-audit-backup")
        old_head = selector((state / "state.journal").read_bytes(), key)
        path, old = create_anchor(h, "promotion-audit-backup-anchor",
            root / "anchors", old_head, domain="backup-audit", generation=4)
        encryption = backup_key(h, root, "promotion-audit-backup", "enc-g1")
        archive, exported = export_backup(h, "promotion-audit-backup", state, key,
            encryption)
        archive_bytes = archive.read_bytes()
        state_bytes = (state / "state.journal").read_bytes()
        certificate = h.identity("A").certificate
        pending = h.run("promotion-audit-backup-not-applied",
            audit_backup_args(path, old, 5, archive, key, encryption,
                certificate, exported["backup_id"]), timeout=30)
        assert pending
        check_common(h, pending, old, 5)
        h.check(pending["classification"] == "NOT_APPLIED_EXACT_OLD_RECORD" and
            pending["source_eligibility"]["relationship"] ==
                "VERIFIED_AUTHENTICATED_CHECKPOINT_SUCCESSOR" and
            pending["source"]["kind"] == "SIGNED_ENCRYPTED_BACKUP",
            "direct signed encrypted checkpoint is audited before promotion")
        promoted = h.run("promotion-audit-backup-apply",
            promote_backup_args(path, old, 5, archive, key, encryption,
                certificate, exported["backup_id"]), timeout=30)
        assert promoted
        current = parse_record(path.read_bytes())
        applied = h.run("promotion-audit-backup-applied",
            audit_backup_args(path, old, 5, archive, key, encryption,
                certificate, exported["backup_id"]), timeout=30)
        assert applied
        h.check(applied["classification"] == "APPLIED_EXACT_DERIVED_SUCCESSOR" and
            applied["current_custody"]["record_digest"] == current["record_digest"],
            "exact backup-derived custody winner is identified after response loss")
        h.check(archive.read_bytes() == archive_bytes and
            (state / "state.journal").read_bytes() == state_bytes,
            "backup outcome auditing neither restores nor mutates source state")

    case("backup_not_applied_and_applied", backup_not_applied_and_applied)

    def backup_trust_and_source_replacement() -> None:
        root, state, key = setup(h, "promotion-audit-backup-fail")
        old_head = selector((state / "state.journal").read_bytes(), key)
        path, old = create_anchor(h, "promotion-audit-backup-fail-anchor",
            root / "anchors", old_head)
        encryption = backup_key(h, root, "promotion-audit-backup-fail", "enc-g1")
        archive, exported = export_backup(h, "promotion-audit-backup-fail", state,
            key, encryption)
        before = path.read_bytes(); archive_before = archive.read_bytes()
        wrong_encryption = backup_key(h, root, "promotion-audit-wrong", "enc-g2")
        wrong_state_key = new_key(h, root, "promotion-audit-wrong-state")
        wrong_certificate = h.identity("B").certificate
        attempts = [
            ("decrypt", wrong_encryption, key, h.identity("A").certificate, None),
            ("state-key", encryption, wrong_state_key, h.identity("A").certificate, None),
            ("signer", encryption, key, wrong_certificate, None),
            ("backup-id", encryption, key, h.identity("A").certificate, "11" * 32),
        ]
        for label, decrypt, state_key, cert, backup_id in attempts:
            value = h.run("promotion-audit-backup-wrong-" + label,
                audit_backup_args(path, old, 2, archive, state_key, decrypt,
                    cert, backup_id), expected=3, timeout=30)
            h.check(value is not None and value.get("ok") is False,
                "wrong backup trust input fails before classification")
            h.check(path.read_bytes() == before and archive.read_bytes() == archive_before,
                "trust failures preserve custody and backup bytes")
        h.check(exported["backup_id"] != "11" * 32,
            "wrong expected backup identity is independently false")

        second, second_exported = export_backup(h,
            "promotion-audit-backup-fail-second", state, key, encryption)
        h.check(second_exported["state_head"]["selector"] !=
            exported["state_head"]["selector"],
            "replacement fixture carries a distinct valid signed checkpoint")
        args = audit_backup_args(path, old, 2, archive, key, encryption,
            h.identity("A").certificate)
        started = time.time()
        process = subprocess.Popen([str(h.binary), *args], stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, env=dict(os.environ,
                NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_PAUSE_BEFORE_BACKUP_VERIFY_MS="700"))
        time.sleep(0.2)
        os.replace(second, archive)
        stdout, stderr = process.communicate(timeout=30)
        h.commands.append({"label": "promotion-audit-backup-source-race", "args": args,
            "returncode": process.returncode, "stdout": stdout, "stderr": stderr,
            "elapsed_seconds": time.time() - started,
            "environment": ["NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_PAUSE_BEFORE_BACKUP_VERIFY_MS"]})
        (h.logs / f"{len(h.commands):03d}-promotion-audit-backup-source-race.stdout.txt").write_text(stdout)
        (h.logs / f"{len(h.commands):03d}-promotion-audit-backup-source-race.stderr.txt").write_text(stderr)
        h.check(process.returncode == 3,
            "backup pathname replacement suppresses an apparent audit success")
        value = json.loads([line for line in stdout.splitlines() if line.strip()][-1])
        h.check(value["code"] == "BACKUP_SOURCE_CHANGED" and path.read_bytes() == before,
            "source replacement has a precise failure and cannot advance custody")

    case("backup_trust_and_source_replacement", backup_trust_and_source_replacement)

    def custody_replacement_race() -> None:
        root, state, key = setup(h, "promotion-audit-custody-race")
        old_head = selector((state / "state.journal").read_bytes(), key)
        directory = root / "anchors"
        path, old = create_anchor(h, "promotion-audit-custody-race-anchor",
            directory, old_head)
        append(h, state, key, "promotion-audit-custody-race-next")
        candidate_head = selector((state / "state.journal").read_bytes(), key)
        replacement, _ = create_anchor(h, "promotion-audit-custody-race-winner",
            directory, candidate_head, domain="race-winner", generation=9,
            filename="winner.head")
        winner = replacement.read_bytes()
        args = audit_state_args(path, old, 2, state, key)
        started = time.time()
        process = subprocess.Popen([str(h.binary), *args], stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, env=dict(os.environ,
                NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_AUDIT_PAUSE_FINAL_MS="700"))
        time.sleep(0.2)
        os.replace(replacement, path)
        stdout, stderr = process.communicate(timeout=30)
        h.commands.append({"label": "promotion-audit-custody-race", "args": args,
            "returncode": process.returncode, "stdout": stdout, "stderr": stderr,
            "elapsed_seconds": time.time() - started,
            "environment": ["NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_AUDIT_PAUSE_FINAL_MS"]})
        (h.logs / f"{len(h.commands):03d}-promotion-audit-custody-race.stdout.txt").write_text(stdout)
        (h.logs / f"{len(h.commands):03d}-promotion-audit-custody-race.stderr.txt").write_text(stderr)
        h.check(process.returncode == 3,
            "custody replacement before final response is rejected")
        value = json.loads([line for line in stdout.splitlines() if line.strip()][-1])
        h.check(value["code"] == "STATE_HEAD_CUSTODY_REPLACEMENT_RACE" and
            path.read_bytes() == winner,
            "audit never overwrites or repairs a competing custody record")

    case("custody_replacement_race", custody_replacement_race)

    def strict_cli_duplicate_and_no_mutation() -> None:
        root, state, key = setup(h, "promotion-audit-strict")
        old_head = selector((state / "state.journal").read_bytes(), key)
        path, old = create_anchor(h, "promotion-audit-strict-anchor",
            root / "anchors", old_head)
        append(h, state, key, "promotion-audit-strict-next")
        before_record = path.read_bytes(); before_state = (state / "state.journal").read_bytes()
        missing = h.run("promotion-audit-missing-source",
            ["state-head-custody-promotion-audit", *exact_args(path, old),
             "--new-generation", "2", "--state-auth-key", str(key)], expected=3)
        h.check(missing and missing["code"] ==
            "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_REQUIRED",
            "outcome audit requires exactly one explicit source")
        both = h.run("promotion-audit-two-sources",
            [*audit_state_args(path, old, 2, state, key),
             "--input", str(root / "missing.nob")], expected=3)
        h.check(both and both["code"] ==
            "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_REQUIRED",
            "state and backup sources cannot be mixed")
        supplied = h.run("promotion-audit-caller-new-head",
            [*audit_state_args(path, old, 2, state, key),
             "--new-head", old_head], expected=3)
        h.check(supplied and supplied["code"] == "UNKNOWN_ARGUMENT",
            "caller cannot supply the derived candidate head")
        nonadvancing = h.run("promotion-audit-generation-no-advance",
            audit_state_args(path, old, old["generation"], state, key), expected=3)
        h.check(nonadvancing and nonadvancing["code"] ==
            "STATE_HEAD_CUSTODY_GENERATION_INVALID",
            "intended new generation must strictly advance")
        wrong_old = dict(old); wrong_old["record_digest"] = "44" * 32
        inconsistent = h.run("promotion-audit-inconsistent-old-account",
            audit_state_args(path, wrong_old, 2, state, key), expected=3)
        h.check(inconsistent and inconsistent["code"] ==
            "STATE_HEAD_CUSTODY_EXPECTATION_INVALID",
            "intended old account must identify its canonical exact record")
        no_key = audit_state_args(path, old, 2, state, key)
        at = no_key.index("--state-auth-key"); del no_key[at:at+2]
        missing_key = h.run("promotion-audit-no-state-key", no_key, expected=3)
        h.check(missing_key and missing_key["code"] == "STATE_AUTH_KEY_REQUIRED",
            "custody never substitutes for the state authentication key")
        h.check(path.read_bytes() == before_record and
            (state / "state.journal").read_bytes() == before_state,
            "strict parser and input failures mutate neither custody nor state")

    case("strict_cli_duplicate_and_no_mutation",
         strict_cli_duplicate_and_no_mutation)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append", choices=CASES)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    harness = Harness(args.binary, args.output)
    started = time.time(); code = 1
    try:
        run_suite(harness, set(args.case) if args.case else None)
        code = 0
    except BaseException as error:
        (harness.output / "FAILURE.txt").write_text(
            f"{type(error).__name__}: {error}\n")
        print(f"FAIL: {type(error).__name__}: {error}", file=sys.stderr)
    finally:
        harness.cleanup()
        sizes = []
        for command in harness.commands:
            if command["returncode"] == 0:
                lines = [line for line in command["stdout"].splitlines() if line.strip()]
                if lines:
                    try:
                        value = json.loads(lines[-1])
                    except json.JSONDecodeError:
                        continue
                    if (value.get("format") ==
                            "NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_OUTCOME_AUDIT_V1"):
                        sizes.append(len(lines[-1].encode()))
        summary = {
            "format": "NATRAV_OVERLAY_CUSTODY_PROMOTION_OUTCOME_AUDIT_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "successful_audit_response_bytes_min": min(sizes) if sizes else None,
            "successful_audit_response_bytes_max": max(sizes) if sizes else None,
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (("SUMMARY.json", summary),
                ("CASES.json", harness.cases), ("COMMANDS.json", harness.commands)):
            (harness.output / name).write_text(
                json.dumps(value, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
