#!/usr/bin/env python3
"""Explicit POSIX serial/TTY carrier and PTY-backed authenticated-stack regression."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from typing import Any

from tls_test_support import IdentityFactory


EXPECTED_FEATURE = "POSIX_SERIAL_TTY_ORDERED_BYTE_STREAM_V1"


def run_command(
    command: list[str],
    *,
    stdout_path: Path,
    stderr_path: Path,
    timeout: float,
    environment: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        timeout=timeout,
        env=environment,
    )
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)
    return completed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    source_root = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    binary = args.binary.resolve(strict=True)
    if output.exists() or output == source_root or source_root in output.parents:
        parser.error("output must be new and outside the source tree")
    output.mkdir(parents=True)

    started = time.monotonic()
    assertions = 0
    commands: list[dict[str, Any]] = []
    cases: list[dict[str, Any]] = []

    def check(condition: bool, detail: str) -> None:
        nonlocal assertions
        assertions += 1
        if not condition:
            raise AssertionError(detail)

    def record_case(name: str, before: int, begin: float) -> None:
        cases.append(
            {
                "name": name,
                "status": "PASS",
                "assertions": assertions - before,
                "elapsed_seconds": time.monotonic() - begin,
            }
        )

    status = "FAIL"
    failure: str | None = None
    try:
        before = assertions
        begin = time.monotonic()
        version_run = run_command(
            [str(binary), "version"],
            stdout_path=output / "version.stdout.txt",
            stderr_path=output / "version.stderr.txt",
            timeout=10,
        )
        commands.append(
            {"label": "version", "returncode": version_run.returncode,
             "args": ["version"]}
        )
        check(version_run.returncode == 0, "version command succeeds")
        lines = [line for line in version_run.stdout.splitlines() if line.strip()]
        check(len(lines) == 1, "version emits one JSON line")
        version = json.loads(lines[0])
        check(version.get("version") == "0613", "revision is 0613")
        check(version.get("serial_transport") == EXPECTED_FEATURE,
              "serial transport feature marker is exact")
        check(version.get("virtual_carrier") ==
              "DETERMINISTIC_VIRTUAL_ORDERED_BYTE_STREAM_V1",
              "deterministic virtual carrier marker is retained")
        check(version.get("tls_byte_channel") == "OPENSSL_BYTE_CHANNEL_BIO_V1",
              "descriptor-free TLS marker is retained")
        check(version.get("transport_extraction") ==
              "TCP_ORDERED_BYTE_STREAM_BOUNDARY_V1",
              "TCP extraction marker is retained")
        record_case("revision metadata", before, begin)

        before = assertions
        begin = time.monotonic()
        header = (source_root / "node/src/transport.hpp").read_text()
        serial_header = (source_root / "node/src/serial_transport.hpp").read_text()
        serial_source = (source_root / "node/src/serial_transport.cpp").read_text()
        transport_source = (source_root / "node/src/transport.cpp").read_text()
        config_source = (source_root / "node/src/config.cpp").read_text()
        tls_source = (source_root / "node/src/tls.cpp").read_text()
        build_script = (source_root / "node/build.sh").read_text()
        check("serial = 2U" in header and "SerialTransportLocator" in header,
              "serial is an explicit typed production carrier")
        check("serial-v1|" in serial_source and
              "SERIAL_LOCATOR_NONCANONICAL" in serial_source,
              "serial locator has a versioned canonical grammar")
        check("O_NOFOLLOW" in serial_source and "S_ISCHR" in serial_source and
              "TIOCEXCL" in serial_source,
              "device acquisition rejects final symlinks and non-character devices and owns exclusivity")
        check("tcgetattr" in serial_source and "tcsetattr" in serial_source and
              "TIOCNXCL" in serial_source,
              "termios and exclusivity have explicit acquisition and cleanup")
        check("kMaximumSerialIoQuantum" in serial_source and
              "remaining_poll_ms" in serial_source,
              "serial progress and deadlines remain finite")
        check("TRANSPORT_HALF_CLOSE_UNSUPPORTED" in serial_source and
              "can_shutdown_write{true}" in header,
              "the generic capability exists and serial rejects false half-close claims")
        check("parse_configured_transport_locator" in config_source and
              "CONFIG_SERIAL_ROLE_CONFLICT" in config_source,
              "persistent configuration accepts typed serial locators and rejects one-device dual roles")
        check("/dev/tty" not in serial_source and "readdir(" not in serial_source and
              "glob(" not in serial_source,
              "production serial code contains no device scan or implicit attachment")
        check("identity" not in serial_header.lower() and
              "tls" not in serial_header.lower(),
              "carrier declarations do not derive peer identity or trust")
        check('code.starts_with("SERIAL_")' in tls_source,
              "TLS callback failures classify serial carrier I/O as transport failure")
        check("src/serial_transport.cpp" in build_script,
              "normal product build includes the serial implementation")
        parse_start = transport_source.index("TransportKind parse_transport_kind")
        parse_end = transport_source.index("std::string_view transport_kind_name")
        parse_body = transport_source[parse_start:parse_end]
        check('text == "tcp"' in parse_body and 'text == "serial"' in parse_body and
              'text == "udp"' in parse_body and 'text == "unix-dgram"' in parse_body and
              "virtual" not in parse_body,
              "configured parser exposes all production carriers but not the private virtual carrier")
        record_case("source authority and ownership boundary", before, begin)

        identities = IdentityFactory(output / "identities")
        client = identities.identity("serial-client")
        server = identities.identity("serial-server")

        def write_v13_config(
            path: Path,
            *,
            listen: str,
            routes: list[tuple[str, str, str]],
        ) -> None:
            lines = [
                "NATRAV_OVERLAY_CONFIG_V13",
                "runtime_generation=serial-test-v1",
                "node=CLIENT",
                f"state={output / ('state-' + path.stem)}",
                f"listen={listen}",
                "control=control.sock",
                f"identity_cert={client.certificate}",
                f"identity_key={client.private_key}",
                f"identity_pin={client.spki_sha256}",
                "identity_generation=client-g1",
                "deadline_ms=500",
                "peer_workers=2",
                "peer_queue_capacity=8",
                "control_workers=1",
                "control_queue_capacity=8",
                "session_max_operations=8",
                "session_max_bytes=1048576",
                "session_max_lifetime_ms=10000",
                "session_idle_timeout_ms=3000",
                "outbox_global_max_records=32",
                "outbox_global_max_payload_bytes=1048576",
                "outbox_peer_max_records=16",
                "outbox_peer_max_payload_bytes=524288",
                f"local_control={os.geteuid()},ALL",
                "peer=SERVER,10,100,3,10000",
                f"peer_key=SERVER,server-g1,ACTIVE,{server.spki_sha256}",
                "authorize=SERVER,*,EVIDENCE,serial/test",
            ]
            for route_id, priority, locator in routes:
                lines.append(
                    f"peer_route=SERVER,{route_id},{priority},ENABLED,{locator}"
                )
            path.write_text("\n".join(lines) + "\n")
            path.chmod(0o600)

        before = assertions
        begin = time.monotonic()
        serial_a = (
            "serial-v1|path=/dev/ttyS0|baud=115200|data=8|"
            "parity=none|stop=1|flow=none"
        )
        serial_a_other = (
            "serial-v1|path=/dev/ttyS0|baud=9600|data=7|"
            "parity=even|stop=2|flow=software"
        )
        valid_config = output / "serial-valid.conf"
        write_v13_config(
            valid_config, listen="127.0.0.1:0", routes=[("serial", "0", serial_a)]
        )
        valid_run = run_command(
            [str(binary), "config-check", "--config", str(valid_config)],
            stdout_path=output / "config-valid.stdout.txt",
            stderr_path=output / "config-valid.stderr.txt",
            timeout=15,
        )
        commands.append({"label": "config-valid", "returncode": valid_run.returncode,
                         "args": ["config-check", "--config", str(valid_config)]})
        check(valid_run.returncode == 0, "canonical serial route configuration is accepted")
        valid_json = json.loads(valid_run.stdout.strip())
        check(valid_json["peers"][0]["routes"][0]["endpoint"] == serial_a,
              "configuration JSON retains the exact canonical serial locator")

        role_config = output / "serial-role-conflict.conf"
        write_v13_config(
            role_config, listen=serial_a_other, routes=[("serial", "0", serial_a)]
        )
        role_run = run_command(
            [str(binary), "config-check", "--config", str(role_config)],
            stdout_path=output / "config-role-conflict.stdout.txt",
            stderr_path=output / "config-role-conflict.stderr.txt",
            timeout=15,
        )
        commands.append({"label": "config-role-conflict",
                         "returncode": role_run.returncode,
                         "args": ["config-check", "--config", str(role_config)]})
        role_json = json.loads(role_run.stdout.strip())
        check(role_run.returncode == 3 and
              role_json.get("code") == "CONFIG_SERIAL_ROLE_CONFLICT",
              "one device path cannot be both listener and outbound route even with different settings")

        duplicate_config = output / "serial-duplicate-device.conf"
        write_v13_config(
            duplicate_config, listen="127.0.0.1:0",
            routes=[("serial-a", "0", serial_a),
                    ("serial-b", "1", serial_a_other)],
        )
        duplicate_run = run_command(
            [str(binary), "config-check", "--config", str(duplicate_config)],
            stdout_path=output / "config-duplicate-device.stdout.txt",
            stderr_path=output / "config-duplicate-device.stderr.txt",
            timeout=15,
        )
        commands.append({"label": "config-duplicate-device",
                         "returncode": duplicate_run.returncode,
                         "args": ["config-check", "--config", str(duplicate_config)]})
        duplicate_json = json.loads(duplicate_run.stdout.strip())
        check(duplicate_run.returncode == 3 and
              duplicate_json.get("code") == "CONFIG_PEER_ROUTE_ENDPOINT_AMBIGUOUS",
              "one serial path cannot be assigned to multiple routes under different settings")
        record_case("persistent serial configuration boundary", before, begin)

        probe = output / "serial-transport-probe"
        compile_command = [
            "/usr/bin/g++",
            "-D_GNU_SOURCE",
            "-std=c++20",
            "-O1",
            "-g0",
            "-Wall",
            "-Wextra",
            "-Wpedantic",
            "-Wconversion",
            "-Wsign-conversion",
            "-Wshadow",
            "-Wformat=2",
            "-Werror",
            "-pthread",
            f"-I{source_root / 'foundation/include'}",
            f"-I{source_root / 'node/src'}",
            str(source_root / "node/tests/test_serial_transport.cpp"),
            str(source_root / "node/src/serial_transport.cpp"),
            str(source_root / "node/src/transport.cpp"),
            str(source_root / "node/src/udp_transport.cpp"),
            str(source_root / "node/src/unix_datagram_transport.cpp"),
            str(source_root / "node/src/finite_packet_link.cpp"),
            str(source_root / "node/src/packet_port.cpp"),
            str(source_root / "node/src/peer_session.cpp"),
            str(source_root / "node/src/tls.cpp"),
            str(source_root / "node/src/tls_bio.cpp"),
            str(source_root / "node/src/socket.cpp"),
            str(source_root / "node/src/protocol.cpp"),
            str(source_root / "node/src/common.cpp"),
            str(source_root / "foundation/src/core.cpp"),
            str(source_root / "foundation/src/natrav_peer_session.cpp"),
            str(source_root / "foundation/src/natrav_peer_stream.cpp"),
            str(source_root / "foundation/src/natrav_peer_message.cpp"),
            str(source_root / "foundation/src/natrav_peer_handshake.cpp"),
            "-lssl",
            "-lcrypto",
            "-lz",
            "-lzstd",
            "-ldl",
            "-o",
            str(probe),
        ]
        before = assertions
        begin = time.monotonic()
        compile_run = run_command(
            compile_command,
            stdout_path=output / "probe-build.stdout.txt",
            stderr_path=output / "probe-build.stderr.txt",
            timeout=240,
        )
        commands.append(
            {"label": "probe-build", "returncode": compile_run.returncode,
             "args": compile_command}
        )
        check(compile_run.returncode == 0, "strict-warning PTY probe compiles")
        check(probe.is_file() and os.access(probe, os.X_OK),
              "PTY probe executable is materialized")
        record_case("probe build", before, begin)

        before = assertions
        begin = time.monotonic()
        scratch = output / "scratch"
        probe_command = [
            str(probe),
            str(client.certificate),
            str(client.private_key),
            client.spki_sha256,
            str(server.certificate),
            str(server.private_key),
            server.spki_sha256,
            str(scratch),
        ]
        probe_run = run_command(
            probe_command,
            stdout_path=output / "probe.stdout.txt",
            stderr_path=output / "probe.stderr.txt",
            timeout=180,
            environment=dict(os.environ, TERM="xterm", PYTHONDONTWRITEBYTECODE="1"),
        )
        commands.append(
            {"label": "probe", "returncode": probe_run.returncode,
             "args": [str(probe), "<ephemeral test identities>", str(scratch)]}
        )
        check(probe_run.returncode == 0, "PTY-backed serial probe succeeds")
        probe_lines = [line for line in probe_run.stdout.splitlines() if line.strip()]
        check(len(probe_lines) == 1, "serial probe emits one JSON line")
        result = json.loads(probe_lines[0])
        check(result.get("format") == "NATRAV_SERIAL_TRANSPORT_PROBE_V1",
              "serial probe format is exact")
        check(result.get("status") == "PASS", "serial probe reports PASS")
        check(result.get("assertions") == 38,
              "serial probe exact assertion account is retained")
        probe_cases = result.get("cases")
        check(isinstance(probe_cases, list) and len(probe_cases) == 6,
              "serial probe covers six locator, device, PTY, and authenticated-stack cases")
        for item in probe_cases:
            check(isinstance(item, dict) and int(item.get("assertions", 0)) > 0,
                  "every serial probe case contributes assertions")
            cases.append(
                {
                    "name": f"serial transport probe: {item['name']}",
                    "status": "PASS",
                    "assertions": int(item["assertions"]),
                    "elapsed_seconds": 0.0,
                }
            )
        check(sum(int(item["assertions"]) for item in probe_cases) == 38,
              "serial probe per-case accounting is exact")
        assertions += int(result["assertions"])
        record_case("probe execution", before + int(result["assertions"]), begin)

        status = "PASS"
    except BaseException as error:  # preserve bounded evidence on any failure
        failure = f"{type(error).__name__}: {error}"
        cases.append(
            {
                "name": "suite failure",
                "status": "FAIL",
                "assertions": 0,
                "elapsed_seconds": 0.0,
                "detail": failure,
            }
        )

    summary = {
        "format": "NATRAV_SERIAL_TRANSPORT_SUITE_V1",
        "status": status,
        "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "cases_passed": sum(item["status"] == "PASS" for item in cases),
        "cases_total": len(cases),
        "assertions": assertions,
        "commands": len(commands),
        "elapsed_seconds": time.monotonic() - started,
        "feature": EXPECTED_FEATURE,
        "hardware_verified": False,
        "cases": cases,
        "command_records": commands,
    }
    if failure is not None:
        summary["failure"] = failure
    (output / "SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps({key: value for key, value in summary.items()
                      if key not in {"cases", "command_records"}}, sort_keys=True),
          flush=True)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
