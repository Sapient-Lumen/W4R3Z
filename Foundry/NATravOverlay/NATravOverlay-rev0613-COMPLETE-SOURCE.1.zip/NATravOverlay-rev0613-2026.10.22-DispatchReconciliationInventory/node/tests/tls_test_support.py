#!/usr/bin/env python3
"""Deterministic private-key and ephemeral certificate support for local tests.

The keys are derived from fixed, test-only labels. Certificates are generated in the
requested test workspace and are never product identities.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import os
from pathlib import Path
import subprocess


@dataclass(frozen=True)
class TestIdentity:
    label: str
    certificate: Path
    private_key: Path
    spki_sha256: str


class IdentityFactory:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._cache: dict[str, TestIdentity] = {}

    def identity(self, label: str) -> TestIdentity:
        if label in self._cache:
            return self._cache[label]
        if not label or any(ch not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._-" for ch in label):
            raise ValueError(f"unsafe identity label: {label!r}")
        directory = self.root / label
        directory.mkdir(mode=0o700)
        key_der = directory / "seed.pk8"
        key_pem = directory / "key.pem"
        certificate = directory / "cert.pem"
        seed = hashlib.sha256(
            b"NATRAV_OVERLAY_TEST_ONLY_ED25519_SEED_V1\0" + label.encode("ascii")
        ).digest()
        # RFC 8410 OneAsymmetricKey / PKCS#8 wrapper for a raw Ed25519 seed.
        key_der.write_bytes(bytes.fromhex("302e020100300506032b657004220420") + seed)
        key_der.chmod(0o600)
        self._run([
            "openssl", "pkey", "-inform", "DER", "-in", str(key_der),
            "-out", str(key_pem),
        ])
        key_pem.chmod(0o600)
        serial = int.from_bytes(hashlib.sha256(b"serial\0" + label.encode()).digest()[:16], "big") or 1
        self._run([
            "openssl", "req", "-new", "-x509", "-key", str(key_pem),
            "-out", str(certificate), "-days", "3650",
            "-set_serial", str(serial), "-subj", f"/CN=natrav-overlay-test-{label}",
        ])
        certificate.chmod(0o644)
        key_der.unlink()
        public_key = subprocess.run(
            ["openssl", "x509", "-in", str(certificate), "-pubkey", "-noout"],
            check=True,
            capture_output=True,
        ).stdout
        spki = subprocess.run(
            ["openssl", "pkey", "-pubin", "-outform", "DER"],
            input=public_key,
            check=True,
            capture_output=True,
        ).stdout
        pin = hashlib.sha256(spki).hexdigest()
        identity = TestIdentity(label, certificate, key_pem, pin)
        self._cache[label] = identity
        return identity

    @staticmethod
    def _run(args: list[str]) -> None:
        completed = subprocess.run(args, text=True, capture_output=True)
        if completed.returncode != 0:
            raise RuntimeError(
                f"identity command failed ({completed.returncode}): {args!r}\n"
                f"stdout={completed.stdout!r}\nstderr={completed.stderr!r}"
            )
