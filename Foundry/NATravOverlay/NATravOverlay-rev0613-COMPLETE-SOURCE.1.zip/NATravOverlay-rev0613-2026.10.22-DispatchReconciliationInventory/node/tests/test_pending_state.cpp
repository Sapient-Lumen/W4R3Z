// Link as main against the complete production NodeState. The expected statuses
// and amounts are held separately, not derived from the new aggregate itself.
#include "journal.hpp"
#include <barrier>
#include <array>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <map>
#include <memory>
#include <random>
#include <thread>
namespace no=natrav_overlay;
namespace {
std::uint64_t checks=0U;
void check(bool v,const char* m){++checks;if(!v)throw std::runtime_error(m);}
struct Directory {std::filesystem::path path;Directory(){char p[]="/tmp/natrav-capacity-native-XXXXXX";const auto q=::mkdtemp(p);if(!q)throw std::runtime_error("mkdtemp");path=q;}~Directory(){std::error_code e;std::filesystem::remove_all(path,e);}};
auto digest(std::string_view text){return datacube::sha256(datacube::text_octets(text));}
no::OutboundPolicy policy(std::uint64_t now){return {.created_unix_ms=now,.expires_unix_ms=now+10000000U,.maximum_attempts=1000U,.initial_backoff_ms=10U,.maximum_backoff_ms=1000U,.peer_spki_sha256=digest("g1"),.peer_generation="g1"};}
struct Ref {no::EvidenceRecord record;std::string status="PENDING";std::string generation="g1";};
no::QueueUsage reference(const std::vector<Ref>& values){
    no::QueueUsage r;std::map<std::string,no::PeerQueueUsage> peers;
    for(const auto& v:values)if(v.status=="PENDING") {++r.pending_records;r.pending_payload_bytes+=v.record.payload.size();auto& p=peers[v.record.recipient];p.peer=v.record.recipient;++p.pending_records;p.pending_payload_bytes+=v.record.payload.size();}
    for(const auto& [key,v]:peers){static_cast<void>(key);r.peers.push_back(v);}return r;
}
}
int main(){try {
    Directory root;constexpr std::uint64_t max_bytes=128U*1024U*1024U;
    auto state=std::make_unique<no::NodeState>(root.path/"state","A",max_bytes);
    std::vector<Ref> values;std::array<std::size_t,64U> active{};
    std::uint64_t now=1000U, mutations=0U;
    auto verify=[&](bool full=false){const auto expected=reference(values);check(state->pending_queue_usage()==expected,"actual state aggregate equals independent status model");
        if(full){const auto s=state->snapshot();check(s.queue_usage==expected && no::outbound_queue_usage(s.outbound)==expected,"snapshot and slow retained-state reference agree");for(std::size_t i=0;i<values.size();++i)check(no::outbound_status_name(s.outbound[i])==values[i].status,"independent durable outcome matches");}};
    auto add=[&](std::size_t seed){Ref v;v.record={.operation_id=digest("native-capacity-"+std::to_string(values.size())),.issuer="A",.recipient=std::string(1U,static_cast<char>('B'+seed%3U)),.scope="test/capacity",.corrects=std::nullopt,.payload=datacube::Octets(seed%11U==0U?0U:(seed*37U)%2048U,42U)};
        no::SubmissionWork work;{no::SubmissionWorkScope scope(work);if(seed%3U==0U){static_cast<void>(state->queue_outbound(v.record));state->ensure_outbound_policy(v.record.operation_id,policy(++now));}else static_cast<void>(state->queue_outbound(v.record,policy(++now)));}
        check(work.capacity_records_visited==0U && work.capacity_aggregate_reads==2U && work.capacity_acquires==1U,"queue/policy composite acquires once without scan");values.push_back(std::move(v));++mutations;return values.size()-1U;};
    for(std::size_t i=0;i<active.size();++i)active[i]=add(i);
    std::mt19937_64 random(0x0535BEEFU);
    for(std::size_t t=0;t<1200U;++t){const auto slot=static_cast<std::size_t>(random()%active.size());auto i=active[slot];
        if(values[i].status!="PENDING"&&values[i].status!="REJECTED"){active[slot]=add(t+64U);verify();continue;}
        auto& v=values[i];const auto op=v.record.operation_id;now+=3U;const auto action=random()%8U;
        if(v.status=="REJECTED"){
            if(action%3U==0U){state->cancel_outbound(op,now,"NATIVE_TEST","cancel rejected");v.status="CANCELLED";}
            else if(action%3U==1U){state->retry_outbound(op,now,"NATIVE_TEST","retry rejected");v.status="PENDING";}
            else {v.generation=v.generation=="g1"?"g2":"g1";state->rebind_outbound(op,v.generation,digest(v.generation),now,"NATIVE_TEST","reopen rejection");v.status="PENDING";}
        }else if(action==0U){no::DeliveryReceipt r{.operation_id=op,.recipient=v.record.recipient,.recorder=v.record.recipient,.disposition=no::ReceiptDisposition::committed,.sequence=i+1U,.record_digest=no::evidence_record_digest(v.record)};state->record_outbound_receipt(r);state->record_outbound_receipt(r);v.status="ACKED";
        }else if(action==1U){state->cancel_outbound(op,now,"NATIVE_TEST","cancel pending");state->cancel_outbound(op,now,"NATIVE_TEST","same cancellation");v.status="CANCELLED";
        }else if(action==2U){state->expire_outbound(op,now,"DELIVERY_EXPIRED");state->expire_outbound(op,now,"DELIVERY_EXPIRED");v.status="EXPIRED";
        }else if(action==3U){state->begin_outbound_attempt(op,now,now+1U);state->record_outbound_rejection(op,"AUTHORIZATION_DENIED","reference denial",now+1U,v.generation,digest(v.generation));v.status="REJECTED";
        }else if(action==4U){v.generation=v.generation=="g1"?"g2":"g1";state->rebind_outbound(op,v.generation,digest(v.generation),now,"NATIVE_TEST","pending rebind");
        }else if(action==5U){state->begin_outbound_attempt(op,now,now+1U);state->record_outbound_failure(op,"TEST_TRANSIENT","still reserves capacity",now+1U);
        }else{const auto r=state->queue_outbound(v.record,policy(now));check(r.disposition==no::QueueDisposition::already_pending,"duplicate remains pending");}
        ++mutations;verify(t%71U==0U);
        if(t==399U||t==799U){const auto before=state->snapshot().logical_state_digest;static_cast<void>(state->compact());check(state->snapshot().logical_state_digest==before,"compaction preserves logical state");state.reset();state=std::make_unique<no::NodeState>(root.path/"state","A",max_bytes);verify(true);}
    }
    verify(true);state.reset();state=std::make_unique<no::NodeState>(root.path/"state","A",max_bytes);verify(true);
    const auto saved=state->snapshot();
    no::SubmissionWork deliberately_slow;
    { no::SubmissionWorkScope scope(deliberately_slow);
      check(no::outbound_queue_usage(saved.outbound)==reference(values), "instrumented independent scan stays available for validation"); }
    check(deliberately_slow.capacity_records_visited==values.size(), "scan instrumentation observes every reference visit");
    // Real concurrent admission at an exact 8-record, 80-byte boundary.
    no::NodeState limited(root.path/"limited","A",max_bytes,no::QueueLimits{8U,80U,8U,80U});
    constexpr std::size_t clients=24U;std::barrier start(static_cast<std::ptrdiff_t>(clients));std::vector<std::thread> threads;std::array<int,clients> results{};
    for(std::size_t i=0;i<clients;++i)threads.emplace_back([&,i]{start.arrive_and_wait();try{no::EvidenceRecord r{.operation_id=digest("concurrent-"+std::to_string(i)),.issuer="A",.recipient="B",.scope="test/capacity",.corrects=std::nullopt,.payload=datacube::Octets(10U,7U)};static_cast<void>(limited.queue_outbound(r,policy(1000U)));results[i]=1;}catch(const no::AppError& e){results[i]=e.code()=="OUTBOX_GLOBAL_RECORD_LIMIT"?2:-1;}catch(...){results[i]=-1;}});
    for(auto& t:threads) { t.join(); }
    std::size_t accepted=0U;
    for(auto r:results){check(r==1||r==2,"bounded concurrent result");accepted+=r==1?1U:0U;}
    check(accepted==8U && limited.pending_queue_usage().pending_records==8U && limited.pending_queue_usage().pending_payload_bytes==80U,"one serialized exact capacity boundary");
    std::cout<<"{\"format\":\"NATRAV_PENDING_STATE_REFERENCE_V1\",\"status\":\"PASS\",\"checks\":"<<checks<<",\"semantic_actions\":"<<mutations<<",\"retained_operations\":"<<values.size()<<",\"concurrent_clients\":24,\"accepted_at_boundary\":8}\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
