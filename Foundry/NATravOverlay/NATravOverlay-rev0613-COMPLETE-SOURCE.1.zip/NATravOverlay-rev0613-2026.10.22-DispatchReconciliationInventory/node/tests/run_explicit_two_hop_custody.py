#!/usr/bin/env python3
"""Rev0610 deterministic durability cutpoints and explicit A-to-R-to-B custody composition."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import time
from typing import Any

from run_persistent import Harness, free_port, operation
from run_peer_sessions import submit
from run_live_configuration import candidate, activate
from run_runtime_adapter_configuration import upgrade, write
from run_handoff_key_policy import record as handoff_record

ZERO = "0" * 64
AR_RULE = "a-r-native"
RB_RULE = "r-b-native"
RULE_GENERATION = 1
DROP_AFTER_ADMISSION = "NATRAV_OVERLAY_TEST_SESSION_DROP_AFTER_ADMISSION_OPERATION"
PAUSE_PREFIX = "NATRAV_OVERLAY_TEST_CUSTODY_SESSION_"


def cert_sha256(path: Path) -> str:
    der = subprocess.check_output([
        "openssl", "x509", "-in", str(path), "-outform", "DER"
    ])
    return hashlib.sha256(der).hexdigest()


def sha_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree_digest(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix().encode("utf-8")
        payload = path.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(payload).to_bytes(8, "big"))
        digest.update(payload)
    return digest.hexdigest()


def grant(*, identifier: str, origin: str, final: str,
          custodian: str, next_hop: str, state: str = "ACTIVE",
          maximum_active: int = 32,
          maximum_lifetime_ms: int = 600_000) -> str:
    return "\n".join([
        "NATRAV_CUSTODY_RELAY_GRANT_V1",
        f"id={identifier}",
        "generation=1",
        f"predecessor_sha256={ZERO}",
        f"origin={origin}",
        f"origin_signing_generation={origin.lower()}-g1",
        f"final_recipient={final}",
        f"final_signing_generation={final.lower()}-g1",
        f"custodian={custodian}",
        f"custodian_signing_generation={custodian.lower()}-g1",
        f"next_hop={next_hop}",
        f"next_hop_signing_generation={next_hop.lower()}-g1",
        f"maximum_envelope_lifetime_ms={maximum_lifetime_ms}",
        "maximum_hops=2",
        f"maximum_active_envelopes={maximum_active}",
        "maximum_capsule_bytes=68000",
        f"state={state}",
        "",
    ])


def grant_commitment(record: str) -> str:
    lines = record.splitlines()
    assert lines[0] == "NATRAV_CUSTODY_RELAY_GRANT_V1"
    assert lines[-1].startswith("state=")
    text = "NATRAV_CUSTODY_RELAY_GRANT_COMMITMENT_V1\n" + \
        "\n".join(lines[1:-1]) + "\n"
    return hashlib.sha256(text.encode("ascii")).hexdigest()


def service_rule(*, identifier: str, relay_grant: str,
                 custodian_certificate: str, next_hop_certificate: str,
                 state: str = "ACTIVE", maximum_pending: int = 8,
                 maximum_bundle_bytes: int = 60_000,
                 maximum_attempts: int = 4,
                 maximum_window_ms: int = 180_000,
                 expiry_ms: int | None = None) -> str:
    if expiry_ms is None:
        expiry_ms = int(time.time() * 1000) + 600_000
    grant_id = next(line.split("=", 1)[1] for line in relay_grant.splitlines()
                    if line.startswith("id="))
    return "\n".join([
        "NATRAV_CUSTODY_SESSION_RULE_V1",
        f"id={identifier}",
        f"generation={RULE_GENERATION}",
        f"predecessor_sha256={ZERO}",
        f"grant_id={grant_id}",
        "grant_generation=1",
        f"grant_commitment_sha256={grant_commitment(relay_grant)}",
        f"custodian_certificate_sha256={custodian_certificate}",
        f"next_hop_certificate_sha256={next_hop_certificate}",
        f"maximum_pending_cases={maximum_pending}",
        f"maximum_bundle_bytes={maximum_bundle_bytes}",
        f"maximum_attempts={maximum_attempts}",
        f"maximum_transfer_window_ms={maximum_window_ms}",
        f"authority_expires_unix_ms={expiry_ms}",
        f"state={state}",
        "",
    ])


def policy_lines(bindings: list[bytes], grants: list[str], rules: list[str]) -> str:
    return "".join(
        f"handoff_key_hex={handoff_record(binding).encode('ascii').hex()}\n"
        for binding in bindings
    ) + "".join(
        f"custody_grant_hex={item.encode('ascii').hex()}\n" for item in grants
    ) + "".join(
        f"custody_service_hex={item.encode('ascii').hex()}\n" for item in rules
    )


def replace_rules(text: str, rules: list[str]) -> str:
    retained = [line for line in text.splitlines()
                if not line.startswith("custody_service_hex=")]
    return "\n".join(retained) + "\n" + "".join(
        f"custody_service_hex={rule.encode('ascii').hex()}\n" for rule in rules)


def route_file(path: Path, bindings: list[bytes]) -> Path:
    path.write_text(
        "NATRAV_CUSTODY_ROUTE_V1\n" +
        "".join(f"binding_hex={binding.hex()}\n" for binding in bindings)
    )
    path.chmod(0o600)
    return path


def service_root(state: Path, rule: str) -> Path:
    return state / "custody-session-v1" / rule / str(RULE_GENERATION)


def service_cases(state: Path, rule: str) -> list[Path]:
    root = service_root(state, rule) / "cases"
    if not root.exists():
        return []
    return sorted(path for path in root.iterdir() if path.is_dir())


def send_command(config: Path, rule: str, bundle: Path,
                 route_id: str = "default") -> list[str]:
    return [
        "custody-service-v1-send", "--config", str(config),
        "--rule", rule, "--rule-generation", str(RULE_GENERATION),
        "--route", route_id, "--bundle", str(bundle),
    ]


def export_command(config: Path, request_id: str, output: Path,
                   rule: str = AR_RULE) -> list[str]:
    return [
        "custody-service-v1-export", "--config", str(config),
        "--rule", rule, "--rule-generation", str(RULE_GENERATION),
        "--request", request_id, "--output", str(output),
    ]


def clone_config(base: Path, output: Path, state: Path, generation: str,
                 rules: list[str] | None = None) -> Path:
    state.mkdir(parents=True, mode=0o700)
    state.chmod(0o700)
    lines: list[str] = []
    for line in base.read_text().splitlines():
        if line.startswith("runtime_generation="):
            continue
        if line.startswith("state="):
            lines.append(f"state={state}")
        else:
            lines.append(line)
    text = "\n".join(lines) + "\n"
    if rules is not None:
        text = replace_rules(text, rules)
    output.write_text(text + f"runtime_generation={generation}\n")
    output.chmod(0o600)
    return output


def launch_server(h: Harness, label: str, config: Path, rule: str,
                  environment: dict[str, str] | None = None,
                  once: str = "yes") -> subprocess.Popen[str]:
    env = os.environ.copy()
    if environment:
        env.update(environment)
    stdout_path = h.logs / f"{label}.stdout.txt"
    stderr_path = h.logs / f"{label}.stderr.txt"
    process = subprocess.Popen(
        [str(h.binary), "custody-service-v1-serve", "--config", str(config),
         "--rule", rule, "--rule-generation", str(RULE_GENERATION),
         "--once", once],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env,
        start_new_session=True,
    )
    assert process.stdout is not None
    ready, _, _ = select.select([process.stdout], [], [], 8.0)
    if not ready:
        os.killpg(process.pid, signal.SIGKILL)
        out, err = process.communicate(timeout=5)
        stdout_path.write_text(out)
        stderr_path.write_text(err)
        raise AssertionError(f"{label}: receiver did not report ready: {out!r} {err!r}")
    first = process.stdout.readline()
    try:
        decoded = json.loads(first)
    except json.JSONDecodeError as exc:
        os.killpg(process.pid, signal.SIGKILL)
        out, err = process.communicate(timeout=5)
        raise AssertionError(f"{label}: invalid readiness {first!r} {out!r} {err!r}") from exc
    if decoded.get("format") != "NATRAV_NATIVE_CUSTODY_SESSION_READY_V1":
        os.killpg(process.pid, signal.SIGKILL)
        out, err = process.communicate(timeout=5)
        raise AssertionError(f"{label}: not ready {decoded!r} {out!r} {err!r}")
    setattr(process, "_natrav_ready", first)
    setattr(process, "_natrav_stdout_path", stdout_path)
    setattr(process, "_natrav_stderr_path", stderr_path)
    return process


def finish_server(process: subprocess.Popen[str], timeout: float = 12.0) -> tuple[int, str, str]:
    out, err = process.communicate(timeout=timeout)
    complete = getattr(process, "_natrav_ready", "") + out
    Path(getattr(process, "_natrav_stdout_path")).write_text(complete)
    Path(getattr(process, "_natrav_stderr_path")).write_text(err)
    assert process.returncode is not None
    return process.returncode, complete, err


def terminate_server(process: subprocess.Popen[str]) -> tuple[int, str, str]:
    if process.poll() is None:
        process.send_signal(signal.SIGTERM)
    return finish_server(process)


def record_process(h: Harness, label: str, args: list[str], process: subprocess.Popen[str],
                   stdout_path: Path, stderr_path: Path, started: float) -> None:
    h.commands.append({
        "label": label,
        "args": args,
        "returncode": process.returncode,
        "stdout": stdout_path.read_text() if stdout_path.exists() else "",
        "stderr": stderr_path.read_text() if stderr_path.exists() else "",
        "elapsed_seconds": time.time() - started,
    })


def kill_at_pause(h: Harness, label: str, args: list[str], phase: str,
                  timeout: float = 10.0) -> tuple[str, str]:
    env_name = f"{PAUSE_PREFIX}{phase}_MS"
    env = os.environ.copy()
    env[env_name] = "30000"
    stdout_path = h.logs / f"{label}.stdout.txt"
    stderr_path = h.logs / f"{label}.stderr.txt"
    started = time.time()
    with stdout_path.open("w") as stdout_file, stderr_path.open("w") as stderr_file:
        process = subprocess.Popen(
            [str(h.binary), *args], stdout=stdout_file, stderr=stderr_file,
            text=True, env=env, start_new_session=True,
        )
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if env_name in stderr_path.read_text(errors="replace"):
                break
            if process.poll() is not None:
                raise AssertionError(
                    f"{label}: exited before {phase}; rc={process.returncode}; "
                    f"stdout={stdout_path.read_text()!r}; stderr={stderr_path.read_text()!r}")
            time.sleep(0.02)
        else:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=5)
            raise AssertionError(f"{label}: did not reach deterministic pause {phase}")
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=5)
    record_process(h, label, args, process, stdout_path, stderr_path, started)
    h.check(process.returncode == -signal.SIGKILL,
            f"{label}: process died exactly at {phase}")
    return stdout_path.read_text(), stderr_path.read_text()


def paused_server_exchange(h: Harness, label: str, receiver_config: Path,
                           receiver_rule: str, sender_config: Path,
                           sender_rule: str, bundle: Path, phase: str) -> dict[str, Any]:
    env_name = f"{PAUSE_PREFIX}{phase}_MS"
    server = launch_server(h, label + "-server", receiver_config, receiver_rule,
                           {env_name: "30000"})
    sender_args = send_command(sender_config, sender_rule, bundle)
    sender_stdout = h.logs / f"{label}-sender.stdout.txt"
    sender_stderr = h.logs / f"{label}-sender.stderr.txt"
    started = time.time()
    with sender_stdout.open("w") as out_file, sender_stderr.open("w") as err_file:
        sender = subprocess.Popen(
            [str(h.binary), *sender_args], stdout=out_file, stderr=err_file,
            text=True, env=os.environ.copy(), start_new_session=True,
        )
        assert server.stderr is not None
        deadline = time.monotonic() + 10.0
        observed = ""
        while time.monotonic() < deadline:
            ready, _, _ = select.select([server.stderr], [], [], 0.1)
            if ready:
                line = server.stderr.readline()
                observed += line
                if env_name in observed:
                    break
            if server.poll() is not None:
                raise AssertionError(f"{label}: receiver exited before {phase}")
        else:
            os.killpg(server.pid, signal.SIGKILL)
            os.killpg(sender.pid, signal.SIGKILL)
            raise AssertionError(f"{label}: receiver did not reach {phase}")
        os.killpg(server.pid, signal.SIGKILL)
        server_out, server_err_tail = server.communicate(timeout=5)
        complete_server_out = getattr(server, "_natrav_ready", "") + server_out
        Path(getattr(server, "_natrav_stdout_path")).write_text(complete_server_out)
        Path(getattr(server, "_natrav_stderr_path")).write_text(observed + server_err_tail)
        sender.wait(timeout=15)
    record_process(h, label + "-sender", sender_args, sender,
                   sender_stdout, sender_stderr, started)
    h.check(server.returncode == -signal.SIGKILL,
            f"{label}: receiver killed exactly at {phase}")
    h.check(sender.returncode == 4,
            f"{label}: sender preserves uncertainty after receiver death")
    lines = [line for line in sender_stdout.read_text().splitlines() if line.strip()]
    h.check(bool(lines), f"{label}: sender emitted unresolved result")
    return json.loads(lines[-1])


def suite(h: Harness) -> None:
    h.work.chmod(0o700)
    v: dict[str, Any] = {}

    def initialize() -> None:
        version = h.run("version", ["version"])
        h.check(version is not None and version["version"] == "0613",
                "revision 0610 identity")
        h.check(version["custody_retained_export"] ==
                "EXPLICIT_CURRENT_CUSTODIAN_BUNDLE_EXPORT_V1",
                "explicit retained export capability")
        h.check(version["automatic_route_relay"] is False and
                version["open_relay"] is False,
                "multi-hop composition grants no automatic or open relay")

        ports = {node: free_port() for node in ("A", "R", "B")}
        dead_ports = {"AR": free_port(), "RB": free_port(), "AB": free_port()}
        states = {node: h.runtime / node.lower() for node in ("A", "R", "B")}
        configs = {
            "A": h.config("a-seed", "A", states["A"], ports["A"],
                          [("R", ports["R"], 50, 250, 16, 600_000),
                           ("B", dead_ports["AB"], 50, 250, 16, 600_000)],
                          trusted=["R", "B"]),
            "R": h.config("r-seed", "R", states["R"], ports["R"],
                          [("A", ports["A"], 50, 250, 16, 600_000),
                           ("B", ports["B"], 50, 250, 16, 600_000)],
                          trusted=["A", "B"]),
            "B": h.config("b-seed", "B", states["B"], ports["B"],
                          [("R", ports["R"], 50, 250, 16, 600_000),
                           ("A", dead_ports["AB"], 50, 250, 16, 600_000)],
                          trusted=["A", "R"]),
        }
        for node, config in configs.items():
            write(config, upgrade(config.read_text(), f"{node.lower()}-v19", 19))

        # Initialize durable state and queue independent operations for every bundle.
        for node in ("R", "B"):
            daemon = h.start(f"initialize-{node}", configs[node], states[node])
            daemon.shutdown()
        a = h.start("initialize-A", configs["A"], states["A"])
        operations: dict[str, str] = {}
        names = (
            "normal", "loss", "route", "capacity-one", "capacity-two",
            "lifecycle-one", "lifecycle-two", "certificate", "expiry",
            "cutpoint", "negative",
        )
        for name in names:
            op = operation(f"rev0610-explicit-two-hop-{name}")
            operations[name] = op
            submit(h, f"queue-{name}", a.control, "A", "B", "test/three",
                   op, f"rev0610 explicit two-hop custody {name}")
        a.shutdown()

        bindings: dict[str, bytes] = {}
        keys: dict[str, Path] = {}
        for node in ("A", "R", "B"):
            key = h.work / f"{node.lower()}-handoff"
            result = h.run(f"handoff-key-{node}", [
                "handoff-key-init", "--config", str(configs[node]),
                "--key-directory", str(key),
                "--generation", f"{node.lower()}-h1",
            ])
            binding = (key / "binding.nhkb").read_bytes()
            h.check(result is not None and result["binding_sha256"] ==
                    hashlib.sha256(binding).hexdigest(),
                    f"{node} exact handoff binding")
            bindings[node] = binding
            keys[node] = key

        grants = {
            "AR": grant(identifier="a-r", origin="A", final="B",
                        custodian="A", next_hop="R"),
            "RB": grant(identifier="r-b", origin="A", final="B",
                        custodian="R", next_hop="B"),
        }
        certs = {node: cert_sha256(h.identity(node).certificate)
                 for node in ("A", "R", "B")}
        authority_expiry = int(time.time() * 1000) + 600_000
        rules = {
            "AR": service_rule(
                identifier=AR_RULE, relay_grant=grants["AR"],
                custodian_certificate=certs["A"],
                next_hop_certificate=certs["R"],
                expiry_ms=authority_expiry),
            "RB": service_rule(
                identifier=RB_RULE, relay_grant=grants["RB"],
                custodian_certificate=certs["R"],
                next_hop_certificate=certs["B"],
                expiry_ms=authority_expiry),
        }
        all_bindings = [bindings[node] for node in ("A", "R", "B")]
        for node in ("A", "R", "B"):
            local_rules = ([rules["AR"]] if node == "A" else
                           [rules["RB"]] if node == "B" else
                           [rules["AR"], rules["RB"]])
            records = policy_lines(all_bindings, list(grants.values()), local_rules)

            def modify(text: str, *, node: str = node, records: str = records) -> str:
                extra = ""
                if node == "A":
                    extra = f"peer_route=R,dead,1,ENABLED,127.0.0.1:{dead_ports['AR']}\n"
                elif node == "R":
                    extra = f"peer_route=B,dead,1,ENABLED,127.0.0.1:{dead_ports['RB']}\n"
                return text.replace("CONFIG_V19", "CONFIG_V22") + extra + records

            v22 = candidate(h, configs[node], f"{node.lower()}-v22",
                            f"{node.lower()}-v22", modify)
            checked = h.run(f"check-{node}-v22", [
                "config-check", "--config", str(v22)])
            expected_rules = 2 if node == "R" else 1
            h.check(checked is not None and
                    checked["format"] == "NATRAV_OVERLAY_CONFIG_V22" and
                    len(checked["custody_session_policy"]["rules"]) == expected_rules,
                    f"{node} accepts only its exact endpoint V22 rules")
            daemon = h.start(f"activate-{node}-v22", configs[node], states[node])
            activate(h, f"activate-{node}-v22", states[node], v22)
            daemon.shutdown()
            v[f"{node}v22"] = v22

        route = route_file(h.work / "a-r-b-route.txt", all_bindings)
        bundles: dict[str, Path] = {}
        capsules: dict[str, Path] = {}
        for name, op in operations.items():
            capsule = h.work / f"{name}.nhcp"
            exported = h.run(f"handoff-export-{name}", [
                "handoff-export", "--config", str(configs["A"]),
                "--key-directory", str(keys["A"]),
                "--recipient-binding", str(keys["B"] / "binding.nhkb"),
                "--recipient-binding-sha256", sha_file(keys["B"] / "binding.nhkb"),
                "--operation-id", op, "--kind", "operation",
                "--expires-ms", str(int(time.time() * 1000) + 300_000),
                "--output", str(capsule),
            ])
            h.check(exported is not None and
                    exported["status"] == "EXPORTED_NOT_DELIVERED",
                    f"{name} capsule remains not delivered")
            bundle = h.work / f"{name}.nhcb"
            now = int(time.time() * 1000)
            created = h.run(f"custody-create-{name}", [
                "custody-create", "--config", str(configs["A"]),
                "--route", str(route), "--capsule", str(capsule),
                "--created-ms", str(now), "--expires-ms", str(now + 240_000),
                "--output", str(bundle),
            ])
            h.check(created is not None and
                    created["status"] == "CREATED_CUSTODY_HELD",
                    f"{name} canonical two-hop bundle created")
            bundles[name] = bundle
            capsules[name] = capsule

        v.update({
            "configs": configs, "states": states, "ports": ports,
            "dead_ports": dead_ports, "operations": operations,
            "bindings": bindings, "keys": keys, "grants": grants,
            "rules": rules, "certs": certs,
            "authority_expiry": authority_expiry,
            "route": route, "bundles": bundles, "capsules": capsules,
        })

    h.case("accepted_separate_two_transition_authority", initialize)

    def first_hop_and_explicit_second_hop() -> None:
        # Hold B's listener open before A->R. It must observe zero connections.
        b_idle = launch_server(h, "no-auto-forward-b", v["configs"]["B"], RB_RULE,
                               once="no")
        r = launch_server(h, "normal-first-hop-r", v["configs"]["R"], AR_RULE)
        first = h.run("normal-first-hop-send", send_command(
            v["configs"]["A"], AR_RULE, v["bundles"]["normal"]), timeout=15)
        rc, out, err = finish_server(r)
        h.check(rc == 0 and first is not None and
                first["status"] == "ACCEPTED" and first["attempts"] == 1,
                f"A to R exact transition accepted: {out!r} {err!r}")
        time.sleep(0.2)
        h.check(b_idle.poll() is None,
                "first acceptance schedules no R-to-B connection")
        h.check(len(service_cases(v["states"]["R"], RB_RULE)) == 0,
                "first acceptance creates no second-transition service case")
        rc, out, err = terminate_server(b_idle)
        h.check(rc == 0 and '"accepted_connections":0' in out,
                f"B observed no opportunistic forwarding: {out!r} {err!r}")

        exported_bundle = h.work / "normal-r-retained.nhcb"
        retained_state_before = tree_digest(v["states"]["R"])
        exported = h.run("normal-owner-export", export_command(
            v["configs"]["R"], first["request_id"], exported_bundle))
        retained_state_after = tree_digest(v["states"]["R"])
        h.check(exported is not None and
                exported["status"] == "EXPORTED_RETAINED_CUSTODY_NOT_FORWARDED" and
                exported["current_party_index"] == 1 and
                exported["automatic_route_relay"] is False and
                exported["application_delivery_inferred"] is False,
                "owner explicitly exports only authenticated retained R custody")
        h.check(retained_state_before == retained_state_after,
                "retained export is read-only over authenticated custody state")
        h.check(exported["envelope_sha256"] == first["envelope_sha256"] and
                exported["capsule_sha256"] == sha_file(v["capsules"]["normal"]),
                "owner export preserves exact envelope and capsule commitments")

        b = launch_server(h, "normal-second-hop-b", v["configs"]["B"], RB_RULE)
        second = h.run("normal-second-hop-send", send_command(
            v["configs"]["R"], RB_RULE, exported_bundle), timeout=15)
        rc, out, err = finish_server(b)
        h.check(rc == 0 and second is not None and
                second["status"] == "ACCEPTED" and second["attempts"] == 1,
                f"R to B requires its separate owner invocation: {out!r} {err!r}")
        h.check(second["request_id"] != first["request_id"],
                "each transition has a separate signed offer identity")
        h.check((service_root(v["states"]["R"], AR_RULE) / "cases" /
                 first["request_id"] / "acceptance.bin").is_file() and
                (service_root(v["states"]["R"], RB_RULE) / "cases" /
                 second["request_id"] / "acceptance.bin").is_file(),
                "R retains separate first-hop acceptance and second-hop acceptance")
        denied_output = h.work / "normal-r-no-longer-custodian.nhcb"
        denied = h.run("normal-export-after-onward-acceptance", export_command(
            v["configs"]["R"], first["request_id"], denied_output), expected=3)
        h.check(denied is not None and
                denied["code"] == "CUSTODY_SESSION_LOCAL_ROLE_REJECTED" and
                not denied_output.exists(),
                "retained export is denied after R ceases to be current custodian")
        final_output = h.work / "normal-b-final-recipient-cannot-export.nhcb"
        final_denied = h.run("normal-final-recipient-export-denied",
            export_command(v["configs"]["B"], second["request_id"],
                           final_output, RB_RULE), expected=3)
        h.check(final_denied is not None and
                final_denied["code"] == "CUSTODY_SESSION_LOCAL_ROLE_REJECTED" and
                not final_output.exists(),
                "retained export is denied to the terminal final recipient")
        v.update({"normal_first": first, "normal_second": second,
                  "normal_export": exported_bundle})

    h.case("explicit_owner_composition_never_auto_forwards", first_hop_and_explicit_second_hop)

    def sender_pre_network_cutpoints() -> None:
        phases = (
            "BEFORE_OFFER_PUBLICATION", "AFTER_OFFER_PUBLICATION",
            "BEFORE_ENVELOPE_INDEX_RECONSTRUCTION",
            "AFTER_ENVELOPE_INDEX_RECONSTRUCTION",
            "BEFORE_ATTEMPT_INCREMENT", "AFTER_ATTEMPT_INCREMENT",
        )
        for ordinal, phase in enumerate(phases, start=1):
            state = h.runtime / f"cut-sender-{ordinal}"
            config = clone_config(
                v["Av22"], h.work / f"cut-sender-{ordinal}.conf", state,
                f"cut-sender-{ordinal}")
            args = send_command(config, AR_RULE, v["bundles"]["cutpoint"], "dead")
            if "ENVELOPE_INDEX_RECONSTRUCTION" in phase:
                kill_at_pause(h, f"{phase.lower()}-prepare", args,
                              "AFTER_OFFER_PUBLICATION")
                cases = service_cases(state, AR_RULE)
                h.check(len(cases) == 1 and (cases[0] / "offer.bin").is_file(),
                        f"{phase}: complete signed offer is retained")
                kill_at_pause(h, phase.lower(), args, phase)
            else:
                kill_at_pause(h, phase.lower(), args, phase)

            cases = service_cases(state, AR_RULE)
            if phase == "BEFORE_OFFER_PUBLICATION":
                h.check(len(cases) == 0,
                        "death before offer publication leaves no partial case")
            else:
                h.check(len(cases) == 1 and (cases[0] / "offer.bin").is_file(),
                        f"{phase}: at most one complete offer case survives")
            if phase == "BEFORE_ENVELOPE_INDEX_RECONSTRUCTION":
                root = service_root(state, AR_RULE)
                h.check(not any((root / "envelope-index").iterdir()),
                        "death before reconstruction leaves reverse index absent")
            if phase == "AFTER_ENVELOPE_INDEX_RECONSTRUCTION":
                root = service_root(state, AR_RULE)
                h.check(any((root / "envelope-index").iterdir()),
                        "death after reconstruction retains reverse index")
            if phase == "BEFORE_ATTEMPT_INCREMENT":
                h.check((cases[0] / "attempts").read_text().strip() == "0",
                        "death before attempt publication consumes no attempt")
            if phase == "AFTER_ATTEMPT_INCREMENT":
                h.check((cases[0] / "attempts").read_text().strip() == "1",
                        "death after attempt publication retains one attempt")

            recovered = h.run(f"{phase.lower()}-recover", args,
                              expected=4, timeout=15)
            h.check(recovered is not None and
                    recovered["status"] == "UNRESOLVED",
                    f"{phase}: restart deterministically resumes same unresolved case")
            final_cases = service_cases(state, AR_RULE)
            h.check(len(final_cases) == 1 and
                    final_cases[0].name == recovered["request_id"],
                    f"{phase}: restart never mints a second request identity")
            expected_attempts = 2 if phase == "AFTER_ATTEMPT_INCREMENT" else 1
            h.check(recovered["attempts"] == expected_attempts,
                    f"{phase}: exact durable attempt count recovered")

    h.case("sender_offer_index_and_attempt_cutpoints", sender_pre_network_cutpoints)

    def receiver_acceptance_cutpoints() -> None:
        phases = (
            "BEFORE_RECEIVER_ACCEPTANCE_PUBLICATION",
            "AFTER_RECEIVER_ACCEPTANCE_PUBLICATION",
            "BEFORE_RECEIVER_JOURNAL_COMMIT",
            "AFTER_RECEIVER_JOURNAL_COMMIT",
        )
        for ordinal, phase in enumerate(phases, start=1):
            a_state = h.runtime / f"cut-rx-a-{ordinal}"
            r_state = h.runtime / f"cut-rx-r-{ordinal}"
            a_config = clone_config(v["Av22"], h.work / f"cut-rx-a-{ordinal}.conf",
                                    a_state, f"cut-rx-a-{ordinal}")
            r_config = clone_config(v["Rv22"], h.work / f"cut-rx-r-{ordinal}.conf",
                                    r_state, f"cut-rx-r-{ordinal}")
            first = paused_server_exchange(
                h, phase.lower(), r_config, AR_RULE, a_config, AR_RULE,
                v["bundles"]["cutpoint"], phase)
            h.check(first["status"] == "UNRESOLVED" and
                    first["acceptance_durable"] is False,
                    f"{phase}: sender never guesses acceptance after response loss")
            request = first["request_id"]
            receiver_case = service_root(r_state, AR_RULE) / "cases" / request
            offer_before = (receiver_case / "offer.bin").read_bytes()
            acceptance_before = ((receiver_case / "acceptance.bin").read_bytes()
                                 if (receiver_case / "acceptance.bin").is_file()
                                 else None)
            if phase == "BEFORE_RECEIVER_ACCEPTANCE_PUBLICATION":
                h.check(acceptance_before is None,
                        "receiver death before acceptance publication retains no acceptance")
            else:
                h.check(acceptance_before is not None,
                        f"{phase}: complete signed acceptance is durable")

            server = launch_server(h, phase.lower() + "-replay", r_config, AR_RULE)
            recovered = h.run(phase.lower() + "-sender-retry", send_command(
                a_config, AR_RULE, v["bundles"]["cutpoint"]), timeout=15)
            rc, out, err = finish_server(server)
            h.check(rc == 0 and recovered is not None and
                    recovered["status"] == "ACCEPTED" and
                    recovered["request_id"] == request,
                    f"{phase}: exact request recovers after restart: {out!r} {err!r}")
            h.check((receiver_case / "offer.bin").read_bytes() == offer_before,
                    f"{phase}: receiver reuses byte-identical offer")
            if acceptance_before is not None:
                h.check((receiver_case / "acceptance.bin").read_bytes() ==
                        acceptance_before,
                        f"{phase}: receiver replays byte-identical retained acceptance")
            sender_case = service_root(a_state, AR_RULE) / "cases" / request
            h.check((sender_case / "acceptance.bin").read_bytes() ==
                    (receiver_case / "acceptance.bin").read_bytes(),
                    f"{phase}: sender and receiver converge on one exact acceptance")

    h.case("receiver_acceptance_and_journal_cutpoints", receiver_acceptance_cutpoints)

    def sender_acceptance_cutpoints() -> None:
        phases = (
            "BEFORE_SENDER_ACCEPTANCE_PUBLICATION",
            "AFTER_SENDER_ACCEPTANCE_PUBLICATION",
            "BEFORE_SENDER_JOURNAL_COMMIT",
            "AFTER_SENDER_JOURNAL_COMMIT",
        )
        for ordinal, phase in enumerate(phases, start=1):
            a_state = h.runtime / f"cut-tx-a-{ordinal}"
            r_state = h.runtime / f"cut-tx-r-{ordinal}"
            a_config = clone_config(v["Av22"], h.work / f"cut-tx-a-{ordinal}.conf",
                                    a_state, f"cut-tx-a-{ordinal}")
            r_config = clone_config(v["Rv22"], h.work / f"cut-tx-r-{ordinal}.conf",
                                    r_state, f"cut-tx-r-{ordinal}")
            server = launch_server(h, phase.lower() + "-receiver", r_config, AR_RULE)
            args = send_command(a_config, AR_RULE, v["bundles"]["cutpoint"])
            kill_at_pause(h, phase.lower(), args, phase)
            rc, out, err = finish_server(server)
            h.check(rc in (0, 3) and '"operations":1' in out,
                    f"{phase}: receiver durably processed before sender death: {out!r} {err!r}")
            a_cases = service_cases(a_state, AR_RULE)
            r_cases = service_cases(r_state, AR_RULE)
            h.check(len(a_cases) == 1 and len(r_cases) == 1 and
                    a_cases[0].name == r_cases[0].name,
                    f"{phase}: one exact transition identity at both endpoints")
            request = a_cases[0].name
            remote_acceptance = (r_cases[0] / "acceptance.bin").read_bytes()
            local_path = a_cases[0] / "acceptance.bin"
            if phase == "BEFORE_SENDER_ACCEPTANCE_PUBLICATION":
                h.check(not local_path.exists(),
                        "death before sender publication retains remote-only acceptance")
                replay = launch_server(h, phase.lower() + "-replay", r_config, AR_RULE)
                recovered = h.run(phase.lower() + "-network-recovery", args, timeout=15)
                rc, out, err = finish_server(replay)
                h.check(rc == 0, f"{phase}: duplicate receiver replay completed: {out!r} {err!r}")
            else:
                h.check(local_path.read_bytes() == remote_acceptance,
                        f"{phase}: sender retains exact response before later work")
                recovered = h.run(phase.lower() + "-local-recovery", args, timeout=15)
            h.check(recovered is not None and recovered["status"] == "ACCEPTED" and
                    recovered["request_id"] == request,
                    f"{phase}: restart reaches durable acceptance")
            h.check(local_path.read_bytes() == remote_acceptance,
                    f"{phase}: restart cannot manufacture different acceptance bytes")

    h.case("sender_acceptance_and_journal_cutpoints", sender_acceptance_cutpoints)

    def first_hop_export(name: str) -> tuple[dict[str, Any], Path]:
        server = launch_server(h, f"{name}-first-hop-r", v["configs"]["R"], AR_RULE)
        first = h.run(f"{name}-first-hop-send", send_command(
            v["configs"]["A"], AR_RULE, v["bundles"][name]), timeout=15)
        rc, out, err = finish_server(server)
        h.check(rc == 0 and first is not None and first["status"] == "ACCEPTED",
                f"{name}: first transition accepted: {out!r} {err!r}")
        output = h.work / f"{name}-r-retained.nhcb"
        exported = h.run(f"{name}-owner-export", export_command(
            v["configs"]["R"], first["request_id"], output))
        h.check(exported is not None and
                exported["status"] == "EXPORTED_RETAINED_CUSTODY_NOT_FORWARDED",
                f"{name}: explicit owner export")
        return first, output

    def second_hop_response_loss_and_exact_replay() -> None:
        _, bundle = first_hop_export("loss")
        r_state = h.runtime / "rb-loss-r"
        b_state = h.runtime / "rb-loss-b"
        r_config = clone_config(v["Rv22"], h.work / "rb-loss-r.conf",
                                r_state, "rb-loss-r")
        b_config = clone_config(v["Bv22"], h.work / "rb-loss-b.conf",
                                b_state, "rb-loss-b")
        first = h.run("rb-loss-no-receiver", send_command(
            r_config, RB_RULE, bundle), expected=4, timeout=15)
        h.check(first is not None and first["status"] == "UNRESOLVED" and
                first["attempts"] == 1 and not first["acceptance_durable"],
                "second-hop carrier failure preserves uncertainty")
        request = first["request_id"]
        drop = launch_server(h, "rb-loss-drop-b", b_config, RB_RULE,
                             {DROP_AFTER_ADMISSION: request})
        second = h.run("rb-loss-response-dropped", send_command(
            r_config, RB_RULE, bundle), expected=4, timeout=15)
        rc, out, err = finish_server(drop)
        h.check(rc == 3 and "TEST_SESSION_DROP_AFTER_ADMISSION" in err and
                second is not None and second["status"] == "UNRESOLVED" and
                second["attempts"] == 2 and not second["acceptance_durable"],
                f"lost second-hop response remains unresolved: {out!r} {err!r}")
        b_case = service_root(b_state, RB_RULE) / "cases" / request
        retained = (b_case / "acceptance.bin").read_bytes()
        h.check(bool(retained), "B durably retained acceptance before response loss")

        replay = launch_server(h, "rb-loss-replay-b", b_config, RB_RULE)
        recovered = h.run("rb-loss-retry", send_command(
            r_config, RB_RULE, bundle), timeout=15)
        rc, out, err = finish_server(replay)
        h.check(rc == 0 and recovered is not None and
                recovered["status"] == "ACCEPTED" and
                recovered["attempts"] == 3 and
                recovered["request_id"] == request,
                f"restart replays exact second-hop acceptance: {out!r} {err!r}")
        r_case = service_root(r_state, RB_RULE) / "cases" / request
        h.check((b_case / "acceptance.bin").read_bytes() == retained and
                (r_case / "acceptance.bin").read_bytes() == retained,
                "response-loss recovery converges on byte-identical acceptance")
        local = h.run("rb-loss-local-recovery", send_command(
            r_config, RB_RULE, bundle))
        h.check(local is not None and local["status"] == "ACCEPTED" and
                local["attempts"] == 3,
                "retained local acceptance needs no further carrier use")

    h.case("second_hop_response_loss_restart_and_exact_replay",
           second_hop_response_loss_and_exact_replay)

    def second_hop_route_certificate_capacity_attempt_and_expiry() -> None:
        _, route_bundle = first_hop_export("route")
        route_r_state = h.runtime / "rb-route-r"
        route_b_state = h.runtime / "rb-route-b"
        route_r = clone_config(v["Rv22"], h.work / "rb-route-r.conf",
                               route_r_state, "rb-route-r")
        route_b = clone_config(v["Bv22"], h.work / "rb-route-b.conf",
                               route_b_state, "rb-route-b")
        available = launch_server(h, "rb-route-default-b", route_b, RB_RULE,
                                  once="no")
        unresolved = h.run("rb-explicit-dead-route", send_command(
            route_r, RB_RULE, route_bundle, "dead"), expected=4, timeout=15)
        h.check(unresolved is not None and unresolved["status"] == "UNRESOLVED" and
                unresolved["attempts"] == 1,
                "explicit dead second-hop route remains unresolved")
        time.sleep(0.15)
        h.check(available.poll() is None,
                "available default route is never automatic fallback")
        rc, out, err = terminate_server(available)
        h.check(rc == 0 and '"accepted_connections":0' in out,
                f"unselected B route observed no connection: {out!r} {err!r}")
        switched = h.run("rb-route-switch-rejected", send_command(
            route_r, RB_RULE, route_bundle, "default"), expected=3)
        h.check(switched is not None and
                switched["code"] == "CUSTODY_SESSION_ROUTE_CONFLICT",
                "retained second-hop offer cannot switch explicit route")

        _, cert_bundle = first_hop_export("certificate")
        wrong_rule = service_rule(
            identifier=RB_RULE, relay_grant=v["grants"]["RB"],
            custodian_certificate=v["certs"]["R"],
            next_hop_certificate="22" * 32,
            expiry_ms=v["authority_expiry"])
        cert_r_state = h.runtime / "rb-cert-r"
        cert_b_state = h.runtime / "rb-cert-b"
        cert_r = clone_config(
            v["Rv22"], h.work / "rb-cert-r.conf", cert_r_state, "rb-cert-r",
            [v["rules"]["AR"], wrong_rule])
        cert_b = clone_config(v["Bv22"], h.work / "rb-cert-b.conf",
                              cert_b_state, "rb-cert-b")
        receiver = launch_server(h, "rb-cert-b", cert_b, RB_RULE)
        mismatch = h.run("rb-cert-mismatch", send_command(
            cert_r, RB_RULE, cert_bundle), expected=4, timeout=15)
        rc, out, err = finish_server(receiver)
        h.check(mismatch is not None and mismatch["status"] == "UNRESOLVED" and
                "certificate" in mismatch.get("detail", "").lower(),
                "exact B certificate mismatch cannot become acceptance")
        h.check(rc == 3 and not service_cases(cert_b_state, RB_RULE),
                f"certificate mismatch transmits no custody application: {out!r} {err!r}")

        _, capacity_one = first_hop_export("capacity-one")
        _, capacity_two = first_hop_export("capacity-two")
        bounded_rule = service_rule(
            identifier=RB_RULE, relay_grant=v["grants"]["RB"],
            custodian_certificate=v["certs"]["R"],
            next_hop_certificate=v["certs"]["B"],
            maximum_pending=1, maximum_attempts=1,
            expiry_ms=v["authority_expiry"])
        bound_state = h.runtime / "rb-bounds-r"
        bounded = clone_config(
            v["Rv22"], h.work / "rb-bounds-r.conf", bound_state, "rb-bounds-r",
            [v["rules"]["AR"], bounded_rule])
        first = h.run("rb-bound-first", send_command(
            bounded, RB_RULE, capacity_one), expected=4, timeout=15)
        h.check(first is not None and first["status"] == "UNRESOLVED" and
                first["attempts"] == 1,
                "one second-hop attempt is durably consumed before I/O")
        exhausted = h.run("rb-bound-exhausted", send_command(
            bounded, RB_RULE, capacity_one), expected=4, timeout=15)
        h.check(exhausted is not None and
                exhausted["status"] == "UNRESOLVED_ATTEMPTS_EXHAUSTED" and
                exhausted["attempts"] == 1,
                "finite second-hop attempt bound survives restart")
        full = h.run("rb-bound-pending-limit", send_command(
            bounded, RB_RULE, capacity_two), expected=3)
        h.check(full is not None and
                full["code"] == "CUSTODY_SESSION_PENDING_LIMIT" and
                len(service_cases(bound_state, RB_RULE)) == 1,
                "finite second-hop pending-case bound is exact")

        _, expiry_bundle = first_hop_export("expiry")
        expired_rule = service_rule(
            identifier=RB_RULE, relay_grant=v["grants"]["RB"],
            custodian_certificate=v["certs"]["R"],
            next_hop_certificate=v["certs"]["B"],
            expiry_ms=int(time.time() * 1000) - 1)
        expired = clone_config(
            v["Rv22"], h.work / "rb-expired-r.conf",
            h.runtime / "rb-expired-r", "rb-expired-r",
            [v["rules"]["AR"], expired_rule])
        denied = h.run("rb-expired-authority", send_command(
            expired, RB_RULE, expiry_bundle), expected=3)
        h.check(denied is not None and
                denied["code"] == "CUSTODY_SESSION_AUTHORITY_EXPIRED",
                "expired second-hop V22 authority cannot originate an offer")

    h.case("second_hop_route_certificate_capacity_attempt_and_expiry",
           second_hop_route_certificate_capacity_attempt_and_expiry)

    def second_hop_retirement_revocation_and_stale_seed() -> None:
        _, one = first_hop_export("lifecycle-one")
        _, two = first_hop_export("lifecycle-two")
        _, new_after_retirement = first_hop_export("negative")

        # Produce a retained B acceptance whose response is lost before retirement.
        first = h.run("lifecycle-one-no-b", send_command(
            v["configs"]["R"], RB_RULE, one), expected=4, timeout=15)
        request_one = first["request_id"]
        drop = launch_server(h, "lifecycle-one-drop-b", v["configs"]["B"],
                             RB_RULE, {DROP_AFTER_ADMISSION: request_one})
        lost = h.run("lifecycle-one-drop", send_command(
            v["configs"]["R"], RB_RULE, one), expected=4, timeout=15)
        rc, out, err = finish_server(drop)
        h.check(rc == 3 and "TEST_SESSION_DROP_AFTER_ADMISSION" in err and
                lost is not None and lost["status"] == "UNRESOLVED" and
                lost["attempts"] == 2,
                f"pre-retirement response loss is unresolved: {out!r} {err!r}")
        b_case_one = service_root(v["states"]["B"], RB_RULE) / "cases" / request_one
        retained_acceptance = (b_case_one / "acceptance.bin").read_bytes()

        unresolved_two = h.run("lifecycle-two-no-b", send_command(
            v["configs"]["R"], RB_RULE, two), expected=4, timeout=15)
        h.check(unresolved_two is not None and
                unresolved_two["status"] == "UNRESOLVED" and
                unresolved_two["attempts"] == 1,
                "second retained offer is available for later revocation block")
        request_two = unresolved_two["request_id"]

        retired_rb = v["rules"]["RB"].replace("state=ACTIVE\n", "state=RETIRED\n")
        retired_configs: dict[str, Path] = {}
        for node, local_rules in (
                ("R", [v["rules"]["AR"], retired_rb]),
                ("B", [retired_rb])):
            config = candidate(
                h, v[f"{node}v22"], f"{node.lower()}-retired",
                f"{node.lower()}-retired",
                lambda text, local_rules=local_rules:
                    replace_rules(text, local_rules))
            checked = h.run(f"check-{node}-retired", [
                "config-check", "--config", str(config)])
            h.check(checked is not None and
                    any(rule["id"] == RB_RULE and rule["state"] == "RETIRED"
                        for rule in checked["custody_session_policy"]["rules"]),
                    f"{node} canonical R-to-B retirement")
            daemon = h.start(f"activate-{node}-retired-stale-seed",
                             v["configs"][node], v["states"][node])
            activate(h, f"activate-{node}-retired", v["states"][node], config)
            daemon.shutdown()
            retired_configs[node] = config

        replay = launch_server(h, "retired-rb-replay-b", v["configs"]["B"], RB_RULE)
        recovered = h.run("retired-rb-retry-r", send_command(
            v["configs"]["R"], RB_RULE, one), timeout=15)
        rc, out, err = finish_server(replay)
        h.check(rc == 0 and recovered is not None and
                recovered["status"] == "ACCEPTED" and
                recovered["attempts"] == 3,
                f"retired authority replays only retained exact fact: {out!r} {err!r}")
        r_case_one = service_root(v["states"]["R"], RB_RULE) / "cases" / request_one
        h.check((b_case_one / "acceptance.bin").read_bytes() == retained_acceptance and
                (r_case_one / "acceptance.bin").read_bytes() == retained_acceptance,
                "retirement recovery preserves byte-identical acceptance")
        retired_new = h.run("retired-rb-new-offer", send_command(
            v["configs"]["R"], RB_RULE, new_after_retirement), expected=3)
        h.check(retired_new is not None and
                retired_new["code"] == "CUSTODY_SESSION_RETIRED",
                "retired R-to-B authority cannot create a new offer")
        retired_status = h.run("retired-rb-stale-seed-status", [
            "custody-service-v1-status", "--config", str(v["configs"]["R"]),
            "--rule", RB_RULE, "--rule-generation", str(RULE_GENERATION)])
        h.check(retired_status is not None and
                retired_status["rule_state"] == "RETIRED",
                "stale seed reconstructs monotonic retirement")

        revoked_rb = v["rules"]["RB"].replace("state=ACTIVE\n", "state=REVOKED\n")
        for node, local_rules in (
                ("R", [v["rules"]["AR"], revoked_rb]),
                ("B", [revoked_rb])):
            config = candidate(
                h, retired_configs[node], f"{node.lower()}-revoked",
                f"{node.lower()}-revoked",
                lambda text, local_rules=local_rules:
                    replace_rules(text, local_rules))
            daemon = h.start(f"activate-{node}-revoked-stale-seed",
                             v["configs"][node], v["states"][node])
            activate(h, f"activate-{node}-revoked", v["states"][node], config)
            daemon.shutdown()

        serve = h.run("revoked-rb-serve", [
            "custody-service-v1-serve", "--config", str(v["configs"]["B"]),
            "--rule", RB_RULE, "--rule-generation", str(RULE_GENERATION),
            "--once", "yes"], expected=3)
        h.check(serve is not None and serve["code"] == "CUSTODY_SESSION_REVOKED",
                "revoked B endpoint cannot expose a custody listener")
        before_attempts = (service_root(v["states"]["R"], RB_RULE) /
                           "cases" / request_two / "attempts").read_text()
        blocked = h.run("revoked-rb-unresolved-retry", send_command(
            v["configs"]["R"], RB_RULE, two), expected=3)
        after_attempts = (service_root(v["states"]["R"], RB_RULE) /
                          "cases" / request_two / "attempts").read_text()
        h.check(blocked is not None and
                blocked["code"] == "CUSTODY_SESSION_REVOKED" and
                after_attempts == before_attempts,
                "revocation blocks unresolved retry without consuming an attempt")
        historical = h.run("revoked-rb-local-fact", send_command(
            v["configs"]["R"], RB_RULE, one))
        h.check(historical is not None and historical["status"] == "ACCEPTED",
                "revocation does not erase an already retained local acceptance")
        revoked_status = h.run("revoked-rb-stale-seed-status", [
            "custody-service-v1-status", "--config", str(v["configs"]["R"]),
            "--rule", RB_RULE, "--rule-generation", str(RULE_GENERATION)])
        h.check(revoked_status is not None and
                revoked_status["rule_state"] == "REVOKED",
                "stale seed cannot undo monotonic revocation")

    h.case("second_hop_retirement_revocation_and_stale_seed",
           second_hop_retirement_revocation_and_stale_seed)

    def no_application_delivery_or_receipt() -> None:
        b = h.run("final-b-inspect", [
            "inspect", "--state", str(v["states"]["B"]), "--node", "B"])
        h.check(b is not None and b["inbound"]["count"] == 0,
                "final custody acceptance does not import application evidence")
        forbidden: list[Path] = []
        for state in v["states"].values():
            root = state / "custody-session-v1"
            if root.exists():
                forbidden.extend(path for path in root.rglob("*")
                                 if "delivery" in path.name.lower() or
                                 "application-success" in path.name.lower())
        h.check(not forbidden,
                "neither transition creates a delivery receipt or application-success sidecar")
        version = h.run("service-version-final", ["custody-service-v1-version"])
        h.check(version is not None and
                version["revision"] == "0613" and
                version["retained_bundle_export"] ==
                    "EXPLICIT_CURRENT_CUSTODIAN_BUNDLE_EXPORT_V1" and
                version["automatic_route_relay"] is False and
                version["open_relay"] is False and
                version["application_delivery_inferred"] is False,
                "service surface preserves all negative authority markers")

    h.case("no_final_import_application_success_or_delivery_receipt",
           no_application_delivery_or_receipt)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not exist")
    h = Harness(args.binary, args.output)
    started = time.monotonic()
    code = 1
    try:
        suite(h)
        code = 0
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
    finally:
        h.cleanup()
        report = {
            "format": "NATRAV_EXPLICIT_TWO_HOP_CUSTODY_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "assertions": h.assertions,
            "cases": h.cases,
            "commands": h.commands,
            "elapsed_seconds": time.monotonic() - started,
        }
        (h.output / "RESULT.json").write_text(
            json.dumps(report, indent=2, sort_keys=True) + "\n")
        summary = {
            "format": report["format"],
            "status": report["status"],
            "binary_sha256": report["binary_sha256"],
            "assertions": report["assertions"],
            "cases": report["cases"],
            "cases_passed": sum(case.get("status") == "PASS"
                                for case in report["cases"]),
            "cases_total": len(report["cases"]),
            "commands": len(report["commands"]),
            "elapsed_seconds": report["elapsed_seconds"],
            "failure": None if code == 0 else
                (h.output / "FAILURE.txt").read_text().strip(),
        }
        (h.output / "SUMMARY.json").write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n")
        print(json.dumps({
            "format": report["format"], "status": report["status"],
            "assertions": report["assertions"],
            "cases_passed": summary["cases_passed"],
            "cases_total": summary["cases_total"],
            "commands": summary["commands"],
        }, sort_keys=True))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
