// Exact production parser/arithmetic with an independent bounded head-map interpreter.
#include "numeric.hpp"
#include <bit>
#include <iostream>
#include <limits>
#include <map>
#include <random>
#include <stdexcept>
namespace natrav_overlay {
[[noreturn]] void app_fail(std::string_view code, std::string_view detail) {
    throw std::runtime_error(std::string(code)+":"+std::string(detail));
}
}
namespace {
datacube::Octets independent(std::int64_t ticks,std::string_view unit="degC",std::uint8_t scale=2U){
    datacube::Octets out{'N','N','O','1',scale,static_cast<std::uint8_t>(unit.size())};
    for(const auto c:unit){out.push_back(static_cast<std::uint8_t>(c));}
    const auto raw=std::bit_cast<std::uint64_t>(ticks);
    for(int shift=56;shift>=0;shift-=8){out.push_back(static_cast<std::uint8_t>((raw>>shift)&255U));}
    return out;
}
}
int main(){
    using namespace natrav_overlay;
    std::uint64_t checks=0U;
    const auto check=[&](bool ok){++checks;if(!ok){throw std::runtime_error("numeric differential mismatch at "+std::to_string(checks));}};
    try{
        NumericDefinition d{"degC",2U,kNumericSumLimit};
        for(const std::int64_t v:std::array<std::int64_t,7>{-kNumericValueLimit,-123,-1,0,1,123,kNumericValueLimit}){
            const auto input=independent(static_cast<std::int64_t>(v));const auto got=decode_numeric_observation(input,d);
            check(got.outcome==NumericOutcome::accepted&&got.ticks==v);
            check(encode_numeric_observation(d,static_cast<std::int64_t>(v))==input);
            for(std::size_t n=0;n<input.size();++n){check(decode_numeric_observation(datacube::OctetView(input).first(n),d).outcome==NumericOutcome::malformed);}
            auto extra=input;extra.push_back(0U);check(decode_numeric_observation(extra,d).outcome==NumericOutcome::malformed);
        }
        for(const auto v:{std::numeric_limits<std::int64_t>::min(),std::numeric_limits<std::int64_t>::max(),-kNumericValueLimit-1,kNumericValueLimit+1}){
            check(decode_numeric_observation(independent(v),d).outcome==NumericOutcome::value_range);
        }
        const std::string longest="a"+std::string(31U,'z');NumericDefinition edge{longest,9U,kNumericSumLimit};
        check(decode_numeric_observation(independent(-5,longest,9U),edge).ticks==-5);
        check(decode_numeric_observation(independent(1,"degC",10U),d).outcome==NumericOutcome::malformed);
        check(decode_numeric_observation(independent(1,"DegC",2U),d).outcome==NumericOutcome::unit_mismatch);
        check(decode_numeric_observation(independent(1,"degC",3U),d).outcome==NumericOutcome::scale_mismatch);
        check(decode_numeric_observation(independent(1,"not a unit",2U),d).outcome==NumericOutcome::malformed);
        // Deliberately inconsistent candidates cannot overflow or partially update the caller.
        for(int which=0;which<4;++which){
            NumericTotals x;if(which==0){x.accepted=std::numeric_limits<std::uint64_t>::max();}
            if(which==1){x.sum_ticks=std::numeric_limits<std::int64_t>::max();}
            if(which==2){x.sum_ticks=std::numeric_limits<std::int64_t>::min();}
            if(which==3){x.sum_ticks=1;}
            const auto before=x;auto budget=d;if(which==3){budget.maximum_absolute_sum=1U;}
            bool failed=false;
            try{apply_numeric_observation(x,{NumericOutcome::accepted,which==2?-1:1},nullptr,budget);}catch(const std::runtime_error&){failed=true;}
            check(failed&&x==before);
        }
        NumericTotals totals;std::map<std::uint64_t,NumericObservation> heads;
        NumericTotals reference;std::mt19937_64 random(0x511U);
        for(std::uint64_t n=0U;n<100000U;++n){
            const auto kind=static_cast<unsigned>(random()%5U);
            const auto ticks=static_cast<std::int64_t>(random()%2000001U)-1000000;
            NumericObservation expected{static_cast<NumericOutcome>(kind),kind==0U?ticks:0};
            auto bytes=independent(ticks);
            if(kind==1U){bytes.push_back(0U);}else if(kind==2U){bytes=independent(ticks,"K");}
            else if(kind==3U){bytes=independent(ticks,"degC",3U);}else if(kind==4U){bytes=independent(kNumericValueLimit+1);}
            const auto actual=decode_numeric_observation(bytes,d);
            check(actual.outcome==expected.outcome&&actual.ticks==expected.ticks);
            NumericObservation previous;const NumericObservation* parent=nullptr;
            if(!heads.empty()&&random()%3U!=0U){
                auto it=heads.lower_bound(random()%(n+1U));if(it==heads.end()){it=heads.begin();}
                previous=it->second;parent=&previous;
                if(previous.outcome==NumericOutcome::accepted){--reference.valid_heads;reference.sum_ticks-=previous.ticks;}else{--reference.invalid_heads;}
                heads.erase(it);
            }
            if(expected.outcome==NumericOutcome::accepted){++reference.accepted;++reference.valid_heads;reference.sum_ticks+=ticks;}
            else{++reference.rejected;++reference.invalid_heads;++reference.errors.at(kind-1U);}
            heads.emplace(n,expected);apply_numeric_observation(totals,actual,parent,d);check(totals==reference);
            if(n%257U==0U){
                std::int64_t sum=0;std::uint64_t valid=0U,invalid=0U;
                for(const auto& [id,value]:heads){static_cast<void>(id);if(value.outcome==NumericOutcome::accepted){sum+=value.ticks;++valid;}else{++invalid;}}
                check(sum==totals.sum_ticks&&valid==totals.valid_heads&&invalid==totals.invalid_heads);
            }
        }
        NumericTotals maximum;
        for(std::uint64_t i=0;i<1000000U;++i){apply_numeric_observation(maximum,{NumericOutcome::accepted,kNumericValueLimit},nullptr,d);}
        check(maximum.sum_ticks==static_cast<std::int64_t>(kNumericSumLimit)&&maximum.accepted==1000000U);
        const auto before=maximum;bool exceeded=false;
        try{apply_numeric_observation(maximum,{NumericOutcome::accepted,1},nullptr,d);}catch(const std::runtime_error&){exceeded=true;}
        check(exceeded&&maximum==before);
        // Invalid correction replaces, rather than silently retaining, a valid head.
        NumericObservation parent{NumericOutcome::accepted,kNumericValueLimit};
        apply_numeric_observation(maximum,{NumericOutcome::malformed,0},&parent,d);
        check(maximum.sum_ticks==static_cast<std::int64_t>(kNumericSumLimit)-kNumericValueLimit&&maximum.invalid_heads==1U);
        // Bounded arbitrary byte strings must classify without reading past their end.
        for(std::size_t i=0;i<50000U;++i){
            datacube::Octets bytes(static_cast<std::size_t>(random()%101U));for(auto& b:bytes){b=static_cast<std::uint8_t>(random()&255U);}
            const auto got=decode_numeric_observation(bytes,d);check(got.outcome==NumericOutcome::malformed);
        }
        std::cout<<"{\"status\":\"PASS\",\"checks\":"<<checks<<",\"differential_admissions\":100000,\"budget_boundary_admissions\":1000000,\"random_payloads\":50000,\"heads\":"<<heads.size()<<"}\n";
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
