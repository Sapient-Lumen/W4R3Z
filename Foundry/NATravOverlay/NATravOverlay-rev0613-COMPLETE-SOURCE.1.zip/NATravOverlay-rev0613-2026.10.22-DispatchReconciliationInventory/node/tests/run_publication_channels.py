#!/usr/bin/env python3
"""Durable projection-publication channels and correction-chain continuity."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import time
from typing import Any

from run_persistent import Harness
from run_projection_publication import (
    OUTPUT_SCOPE,
    topology,
)
from run_numeric_projection import create as numeric_create, produce, consume
from run_live_configuration import candidate, activate, wait_state
from run_evidence_queries import query
from run_peer_sessions import outbox_entry
from run_state_authentication import new_key, migrate, start as start_keyed


class Reader:
    def __init__(self, data: bytes):
        self.data = data
        self.at = 0

    def take(self, count: int) -> bytes:
        if self.at + count > len(self.data):
            raise AssertionError("truncated NPC1")
        result = self.data[self.at:self.at + count]
        self.at += count
        return result

    def u8(self) -> int:
        return self.take(1)[0]

    def u16(self) -> int:
        return struct.unpack("!H", self.take(2))[0]

    def u32(self) -> int:
        return struct.unpack("!I", self.take(4))[0]

    def u64(self) -> int:
        return struct.unpack("!Q", self.take(8))[0]

    def digest(self) -> str:
        return self.take(32).hex()

    def text(self) -> str:
        return self.take(self.u16()).decode("utf-8")


def decode_npc1(payload: bytes) -> dict[str, Any]:
    r = Reader(payload)
    if r.take(4) != b"NPC1" or r.u8() != 1 or r.u8() != 1 or r.u16() != 0:
        raise AssertionError("invalid NPC1 header")
    result: dict[str, Any] = {
        "channel_instance": r.digest(),
        "sequence": r.u64(),
        "maximum_publications": r.u32(),
    }
    marker = r.u8()
    if marker not in (0, 1):
        raise AssertionError("invalid NPC1 predecessor marker")
    result["corrects"] = r.digest() if marker else None
    result["authority_digest"] = r.digest()
    result["channel_name"] = r.text()
    base_size = r.u32()
    result["npp1"] = r.take(base_size)
    if r.at != len(payload):
        raise AssertionError("NPC1 trailing bytes")
    return result


def channel_create(
    h: Harness,
    label: str,
    state: Path,
    projection: dict[str, Any],
    *,
    name: str = "channel",
    maximum: int = 128,
    reason: str = "create durable publication channel",
) -> dict[str, Any]:
    consumer = projection["consumer"]
    result = h.run(label, [
        "publication-channel-create", "--control", str(state / "control.sock"),
        "--channel", name,
        "--consumer", consumer["name"],
        "--projection-instance", consumer["instance"],
        "--peer", "C",
        "--scope", OUTPUT_SCOPE,
        "--max-publications", str(maximum),
        "--reason", reason,
        "--deadline-ms", "5000",
    ])
    assert result is not None
    h.check(result["format"] == "NATRAV_OVERLAY_PUBLICATION_CHANNEL_V1",
            "versioned channel creation receipt")
    h.check(result["channel"]["projection_instance"] == consumer["instance"],
            "channel binds immutable projection instance")
    h.check(result["channel"]["creation_reason"] == reason,
            "channel preserves creation reason")
    h.check(result["channel"]["created_configuration_event"] > 0,
            "channel preserves creation configuration provenance")
    return result


def channel_status(h: Harness, label: str, state: Path,
                   name: str = "channel", expected: int = 0) -> dict[str, Any]:
    result = h.run(label, [
        "publication-channel-status", "--control", str(state / "control.sock"),
        "--channel", name, "--deadline-ms", "5000",
    ], expected=expected)
    assert result is not None
    return result


def publish_args(state: Path, channel: dict[str, Any], projection: dict[str, Any],
                 *, name: str = "channel", deadline_ms: int = 5000) -> list[str]:
    consumer = projection["consumer"]
    return [
        "publication-channel-publish", "--control", str(state / "control.sock"),
        "--channel", name,
        "--instance", channel["instance"],
        "--expected-channel-revision", str(channel["revision"]),
        "--expected-projection-revision", str(consumer["revision"]),
        "--expected-position", str(consumer["acknowledged_sequence"]),
        "--result-digest", consumer["projection_result_digest"],
        "--deadline-ms", str(deadline_ms),
    ]


def channel_publish(h: Harness, label: str, state: Path,
                    channel: dict[str, Any], projection: dict[str, Any],
                    *, name: str = "channel", expected: int = 0,
                    deadline_ms: int = 5000) -> dict[str, Any]:
    result = h.run(label, publish_args(state, channel, projection, name=name,
                                      deadline_ms=deadline_ms), expected=expected,
                   timeout=max(10.0, deadline_ms / 1000 + 3.0))
    assert result is not None
    if expected == 0:
        h.check(result["format"] ==
                "NATRAV_OVERLAY_PUBLICATION_CHANNEL_PUBLICATION_V1",
                "versioned channel publication receipt")
        h.check(result["operation_id"] ==
                result["channel"]["publications"][-1]["operation_id"],
                "receipt and durable channel revision bind one operation")
    return result


def channel_retire(h: Harness, label: str, state: Path,
                   channel: dict[str, Any], *, name: str = "channel",
                   cancel: bool = False, reason: str = "retire publication channel",
                   expected: int = 0) -> dict[str, Any]:
    result = h.run(label, [
        "publication-channel-retire", "--control", str(state / "control.sock"),
        "--channel", name,
        "--instance", channel["instance"],
        "--expected-channel-revision", str(channel["revision"]),
        "--pending", "cancel" if cancel else "require-empty",
        "--reason", reason,
        "--deadline-ms", "5000",
    ], expected=expected)
    assert result is not None
    return result


def recipient_record(h: Harness, label: str, state: Path,
                     operation_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    response = query(h, label, state, operation=operation_id, view="history",
                     payload="yes", payload_length=16384)
    h.check(len(response["records"]) == 1,
            "recipient admits one exact channel publication")
    row = response["records"][0]
    payload = bytes.fromhex(row["payload_hex"])
    decoded = decode_npc1(payload)
    expected = hashlib.sha256(
        b"NATRAV_OVERLAY_PUBLICATION_CHANNEL_OPERATION_V1\0" + payload
    ).hexdigest()
    h.check(expected == operation_id == row["operation_id"],
            "independent NPC1 operation derivation matches recipient record")
    return row, decoded


def cases(h: Harness, selected: set[str] | None = None) -> None:
    def case(name: str, function: Any) -> None:
        if selected is None or name in selected:
            h.case(name, function)

    def correction_chain() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(h, "channel-chain")
        assert cd is not None
        values: dict[str, bytes] = {}
        source_first = produce(h, "channel-chain-source-one", a, values, ticks=100)
        numeric_create(h, "channel-chain-projection", b, limit=8)
        first_projection, rows = consume(h, "channel-chain-consume-one", b, values)
        created = channel_create(h, "channel-chain-create", b, first_projection,
                                 maximum=2)
        first_selector = created["channel"]
        first = channel_publish(h, "channel-chain-publish-one", b,
                                first_selector, first_projection)
        wait_state(h, b, first["operation_id"], "ACKED", "channel-chain-first-acked")
        first_row, first_payload = recipient_record(
            h, "channel-chain-recipient-one", c, first["operation_id"])
        h.check(first_payload["sequence"] == 1 and first_payload["corrects"] is None,
                "first channel result is an original")
        h.check(first_payload["channel_name"] == "channel" and
                first_payload["channel_instance"] == first_selector["instance"],
                "NPC1 binds channel name and immutable instance")
        h.check(first_payload["npp1"][:4] == b"NPP1",
                "NPC1 carries canonical projection result payload")
        h.check(first_row["corrects"] is None, "recipient original has no parent")

        produce(h, "channel-chain-source-two", a, values, ticks=125,
                corrects=source_first)
        second_projection, rows = consume(h, "channel-chain-consume-two", b,
                                          values, rows=rows)
        lost_reply_retry = channel_publish(
            h, "channel-chain-old-result-retry", b,
            first_selector, first_projection)
        h.check(lost_reply_retry["disposition"] == "ALREADY_PUBLISHED" and
                lost_reply_retry["operation_id"] == first["operation_id"],
                "lost-response retry remains idempotent after projection advances")

        current = channel_status(h, "channel-chain-status-one", b)["channel"]
        second = channel_publish(h, "channel-chain-publish-two", b,
                                 current, second_projection)
        wait_state(h, b, second["operation_id"], "ACKED", "channel-chain-second-acked")
        second_row, second_payload = recipient_record(
            h, "channel-chain-recipient-two", c, second["operation_id"])
        h.check(second_payload["sequence"] == 2 and
                second_payload["corrects"] == first["operation_id"],
                "second result is an attributable channel correction")
        h.check(second_row["corrects"] == first["operation_id"],
                "recipient correction ancestry matches channel predecessor")
        history = query(h, "channel-chain-history", c, scope=OUTPUT_SCOPE,
                        view="history", payload="no")
        current_view = query(h, "channel-chain-current", c, scope=OUTPUT_SCOPE,
                             view="current", payload="no")
        h.check([row["operation_id"] for row in history["records"]] ==
                [first["operation_id"], second["operation_id"]],
                "recipient history retains original and correction")
        h.check([row["operation_id"] for row in current_view["records"]] ==
                [second["operation_id"]],
                "recipient current view exposes only channel head")

        duplicate = channel_publish(h, "channel-chain-repeat-two", b,
                                    current, second_projection)
        h.check(duplicate["disposition"] == "ALREADY_PUBLISHED" and
                duplicate["operation_id"] == second["operation_id"],
                "exact retry does not multiply a channel correction")
        produce(h, "channel-chain-source-three", a, values, ticks=130,
                corrects=operation_from(rows[-1]))
        third_projection, rows = consume(h, "channel-chain-consume-three", b,
                                         values, rows=rows)
        exhausted = channel_publish(
            h, "channel-chain-budget-exhausted", b,
            channel_status(h, "channel-chain-status-two", b)["channel"],
            third_projection, expected=3)
        h.check(exhausted["code"] == "PUBLICATION_CHANNEL_BUDGET_EXHAUSTED",
                "finite channel publication budget is enforced")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("original_correction_idempotency_and_budget", correction_chain)

    def pending_and_retirement() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "channel-pending", start_recipient=False)
        values: dict[str, bytes] = {}
        first_source = produce(h, "channel-pending-source-one", a, values, ticks=10)
        numeric_create(h, "channel-pending-projection", b)
        first_projection, rows = consume(h, "channel-pending-consume-one", b, values)
        created = channel_create(h, "channel-pending-create", b, first_projection)
        first = channel_publish(h, "channel-pending-publish", b,
                                created["channel"], first_projection)
        wait_state(h, b, first["operation_id"], "PENDING", "channel-pending-visible")

        produce(h, "channel-pending-source-two", a, values, ticks=20,
                corrects=first_source)
        second_projection, rows = consume(h, "channel-pending-consume-two", b,
                                          values, rows=rows)
        status = channel_status(h, "channel-pending-status", b)["channel"]
        blocked = channel_publish(h, "channel-pending-blocked", b, status,
                                  second_projection, expected=3)
        h.check(blocked["code"] == "PUBLICATION_CHANNEL_PREDECESSOR_PENDING",
                "unacknowledged predecessor blocks correction-chain advancement")
        no_cancel = channel_retire(h, "channel-pending-retire-refused", b,
                                   status, expected=3)
        h.check(no_cancel["code"] == "PUBLICATION_CHANNEL_PENDING",
                "retirement requires explicit disposition of pending head")
        retired = channel_retire(h, "channel-pending-retire-cancel", b,
                                 status, cancel=True,
                                 reason="stop unresolved disclosure")
        h.check(retired["channel"]["retirement"]["cancelled_operation"] ==
                first["operation_id"],
                "retirement atomically identifies the cancelled channel head")
        final = h.status("channel-pending-outbox", b)
        h.check(outbox_entry(final, first["operation_id"])["status"] == "CANCELLED",
                "retirement and outbox cancellation commit together")
        h.run("channel-pending-compact", ["compact", "--control",
                                           str(b / "control.sock")])
        bd.shutdown(); bd = h.start("channel-pending-restart", bc, b)
        restored = channel_status(h, "channel-pending-restored", b)["channel"]
        h.check(restored["lifecycle"] == "RETIRED" and
                restored["latest_outbound_status"] == "CANCELLED",
                "retirement and cancellation survive compaction and restart")
        repeat = channel_retire(h, "channel-pending-retire-repeat", b,
                                status, cancel=True,
                                reason="stop unresolved disclosure")
        h.check(repeat["disposition"] == "ALREADY_RETIRED",
                "exact retirement retry is idempotent")
        reserved = h.run("channel-pending-name-reserved", [
            "publication-channel-create", "--control", str(b / "control.sock"),
            "--channel", "channel", "--consumer", "numeric",
            "--projection-instance", second_projection["consumer"]["instance"],
            "--peer", "C", "--scope", OUTPUT_SCOPE,
            "--reason", "cannot reuse retired channel",
        ], expected=3)
        assert reserved is not None
        h.check(reserved["code"] == "PUBLICATION_CHANNEL_RETIRED",
                "retired channel name cannot be recreated")
        ad.shutdown(); bd.shutdown()
    case("pending_predecessor_and_atomic_retirement", pending_and_retirement)

    def rejection_and_retry() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "channel-rejection", allow_output=False)
        assert cd is not None
        values: dict[str, bytes] = {}
        source = produce(h, "channel-rejection-source-one", a, values, ticks=30)
        numeric_create(h, "channel-rejection-projection", b)
        first_projection, rows = consume(h, "channel-rejection-consume-one", b, values)
        created = channel_create(h, "channel-rejection-create", b, first_projection)
        first = channel_publish(h, "channel-rejection-publish", b,
                                created["channel"], first_projection)
        wait_state(h, b, first["operation_id"], "REJECTED", "channel-rejection-terminal")
        h.check(query(h, "channel-rejection-not-admitted", c,
                      operation=first["operation_id"], view="history",
                      payload="no")["records"] == [],
                "recipient authorization denial creates no evidence admission")

        produce(h, "channel-rejection-source-two", a, values, ticks=35,
                corrects=source)
        second_projection, rows = consume(h, "channel-rejection-consume-two", b,
                                          values, rows=rows)
        current = channel_status(h, "channel-rejection-status", b)["channel"]
        blocked = channel_publish(h, "channel-rejection-blocked", b, current,
                                  second_projection, expected=3)
        h.check(blocked["code"] == "PUBLICATION_CHANNEL_PREDECESSOR_REJECTED",
                "terminally rejected predecessor cannot be skipped")

        allowed = candidate(
            h, cc, "channel-rejection-allow", "channel-rejection-c-g2",
            lambda text: text + f"authorize=B,*,EVIDENCE,{OUTPUT_SCOPE}\n")
        activate(h, "channel-rejection-policy-change", c, allowed)
        h.run("channel-rejection-explicit-retry", [
            "retry", "--control", str(b / "control.sock"),
            "--operation", first["operation_id"],
            "--reason", "recipient policy deliberately corrected",
        ])
        wait_state(h, b, first["operation_id"], "ACKED", "channel-rejection-retry-acked")
        second = channel_publish(h, "channel-rejection-publish-two", b,
                                 current, second_projection)
        wait_state(h, b, second["operation_id"], "ACKED", "channel-rejection-second-acked")
        row, decoded = recipient_record(h, "channel-rejection-recipient-two", c,
                                        second["operation_id"])
        h.check(row["corrects"] == first["operation_id"] and
                decoded["corrects"] == first["operation_id"],
                "explicitly repaired predecessor permits one correction")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("authenticated_rejection_requires_explicit_retry", rejection_and_retry)

    def commit_kills() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "channel-kills", start_recipient=False)
        values: dict[str, bytes] = {}
        produce(h, "channel-kills-source", a, values, ticks=44)
        numeric_create(h, "channel-kills-projection", b)
        projection, _ = consume(h, "channel-kills-consume", b, values)
        before = channel_create(h, "channel-kills-create-before", b, projection,
                                name="before")["channel"]
        after = channel_create(h, "channel-kills-create-after", b, projection,
                               name="after")["channel"]
        bd.shutdown()

        for phase, name, selector, disposition in (
            ("BEFORE", "before", before, "QUEUED"),
            ("AFTER", "after", after, "ALREADY_PUBLISHED"),
        ):
            env = {f"NATRAV_OVERLAY_TEST_PUBLICATION_CHANNEL_{phase}_COMMIT_MS": "20000"}
            bd = h.start(f"channel-kills-{phase.lower()}", bc, b, env)
            client = subprocess.Popen(
                [str(h.binary), *publish_args(b, selector, projection,
                                             name=name, deadline_ms=15000)],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                marker = f"NATRAV_OVERLAY_TEST_PUBLICATION_CHANNEL_{phase}_COMMIT_MS"
                h.wait(f"channel {phase.lower()} commit marker",
                       lambda: marker in bd.stderr_path.read_text(), timeout=7)
                bd.kill()
                client.communicate(timeout=5)
            finally:
                if client.poll() is None:
                    client.kill(); client.communicate()
            bd = h.start(f"channel-kills-restart-{phase.lower()}", bc, b)
            retried = channel_publish(h, f"channel-kills-retry-{phase.lower()}",
                                      b, selector, projection, name=name)
            h.check(retried["disposition"] == disposition,
                    f"{phase.lower()} commit boundary reconstructs exact channel outcome")
            current = channel_status(h, f"channel-kills-status-{phase.lower()}",
                                     b, name=name)["channel"]
            h.check(current["publication_count"] == 1,
                    "commit retry never multiplies channel revisions")
            channel_retire(h, f"channel-kills-retire-{phase.lower()}", b,
                           current, name=name, cancel=True,
                           reason=f"retire {phase.lower()} commit test")
            bd.shutdown()
        bd = h.start("channel-kills-final", bc, b)
        ad.shutdown(); bd.shutdown()
    case("hard_kill_before_and_after_atomic_publication", commit_kills)

    def maintenance() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "channel-maintenance", start_recipient=False)
        values: dict[str, bytes] = {}
        source = produce(h, "channel-maintenance-source-one", a, values, ticks=70)
        numeric_create(h, "channel-maintenance-projection", b)
        projection, rows = consume(h, "channel-maintenance-consume-one", b, values)
        created = channel_create(h, "channel-maintenance-create", b, projection)
        publication = channel_publish(h, "channel-maintenance-publish", b,
                                      created["channel"], projection)
        wait_state(h, b, publication["operation_id"], "PENDING",
                   "channel-maintenance-pending")
        bd.shutdown()

        keys = h.runtime / "channel-maintenance-keys"
        keys.mkdir(mode=0o700)
        state_key = new_key(h, keys, "channel-state-g1")
        migrate(h, "channel-maintenance-migrate", b, state_key, "B")
        bd = start_keyed(h, "channel-maintenance-keyed", bc, b, state_key)
        h.run("channel-maintenance-compact", ["compact", "--control", str(bd.control)])
        bd.shutdown()

        backup_key = keys / "backup.key"
        archive = keys / "channel.nob"
        identity = h.identity("B")
        h.run("channel-maintenance-backup-key", [
            "backup-key-init", "--output", str(backup_key),
            "--generation", "channel-backup-g1",
        ])
        h.run("channel-maintenance-export", [
            "backup-export", "--state", str(b), "--node", "B",
            "--generation", "b-g1", "--output", str(archive),
            "--state-auth-key", str(state_key), "--encrypt-key", str(backup_key),
            "--sign-key", str(identity.private_key),
            "--sign-cert", str(identity.certificate),
        ])
        restored = h.runtime / "channel-maintenance-restored"
        h.run("channel-maintenance-restore", [
            "backup-restore", "--input", str(archive),
            "--destination", str(restored), "--node", "B",
            "--generation", "b-g1", "--state-auth-key", str(state_key),
            "--decrypt-key", str(backup_key),
            "--trusted-cert", str(identity.certificate),
            "--require-signature", "yes", "--require-encryption", "yes",
        ])
        moved = candidate(
            h, bc, "channel-maintenance-relocated", "channel-maintenance-b-g2",
            lambda text: text.replace(f"state={b}", f"state={restored}"))
        h.run("channel-maintenance-relocate", [
            "state-relocate", "--state", str(restored), "--node", "B",
            "--candidate", str(moved),
            "--reason", "restore durable publication channel",
            "--state-auth-key", str(state_key),
        ])

        cd = h.start("channel-maintenance-c", cc, c)
        bd = start_keyed(h, "channel-maintenance-restored-b", moved,
                         restored, state_key)
        wait_state(h, restored, publication["operation_id"], "ACKED",
                   "channel-maintenance-restored-acked")
        restored_channel = channel_status(
            h, "channel-maintenance-restored-channel", restored)["channel"]
        h.check(restored_channel["head_operation"] == publication["operation_id"] and
                restored_channel["latest_outbound_status"] == "ACKED",
                "channel head and receipt survive authenticated restore and relocation")
        duplicate = channel_publish(h, "channel-maintenance-duplicate", restored,
                                    created["channel"], projection)
        h.check(duplicate["disposition"] == "ALREADY_PUBLISHED" and
                duplicate["operation_id"] == publication["operation_id"],
                "restored exact retry preserves original operation identity")

        produce(h, "channel-maintenance-source-two", a, values, ticks=75,
                corrects=source)
        second_projection, rows = consume(h, "channel-maintenance-consume-two",
                                          restored, values, rows=rows)
        second = channel_publish(h, "channel-maintenance-publish-two", restored,
                                 restored_channel, second_projection)
        wait_state(h, restored, second["operation_id"], "ACKED",
                   "channel-maintenance-second-acked")
        row, decoded = recipient_record(h, "channel-maintenance-recipient-two", c,
                                        second["operation_id"])
        h.check(row["corrects"] == publication["operation_id"] and
                decoded["corrects"] == publication["operation_id"],
                "restored channel continues the original correction chain")
        cd.shutdown(); ad.shutdown(); bd.shutdown()
    case("authenticated_compaction_encrypted_restore_and_continuation", maintenance)

    def capacity() -> None:
        a, b, c, ac, bc, cc, ad, bd, cd = topology(
            h, "channel-capacity", start_recipient=False)
        values: dict[str, bytes] = {}
        produce(h, "channel-capacity-source", a, values, ticks=1)
        numeric_create(h, "channel-capacity-projection", b)
        projection, _ = consume(h, "channel-capacity-consume", b, values)
        created: list[dict[str, Any]] = []
        for i in range(16):
            created.append(channel_create(
                h, f"channel-capacity-create-{i}", b, projection,
                name=f"channel-{i}")["channel"])
        denied = h.run("channel-capacity-active-limit", [
            "publication-channel-create", "--control", str(b / "control.sock"),
            "--channel", "channel-over", "--consumer", "numeric",
            "--projection-instance", projection["consumer"]["instance"],
            "--peer", "C", "--scope", OUTPUT_SCOPE,
            "--reason", "must exceed per owner active limit",
        ], expected=3)
        assert denied is not None
        h.check(denied["code"] == "PUBLICATION_CHANNEL_LIMIT",
                "per-owner active channel capacity is finite")
        channel_retire(h, "channel-capacity-retire", b, created[0],
                       name="channel-0", reason="release active slot")
        replacement = channel_create(h, "channel-capacity-replacement", b,
                                     projection, name="channel-new")
        h.check(replacement["channel"]["lifecycle"] == "ACTIVE",
                "retirement releases active channel capacity")
        reserved = h.run("channel-capacity-retired-name", [
            "publication-channel-create", "--control", str(b / "control.sock"),
            "--channel", "channel-0", "--consumer", "numeric",
            "--projection-instance", projection["consumer"]["instance"],
            "--peer", "C", "--scope", OUTPUT_SCOPE,
            "--reason", "cannot reuse retired identity",
        ], expected=3)
        assert reserved is not None
        h.check(reserved["code"] == "PUBLICATION_CHANNEL_RETIRED",
                "retired channel names remain reserved")
        ad.shutdown(); bd.shutdown()
    case("bounded_registry_and_nonreusable_names", capacity)


def operation_from(row: dict[str, Any]) -> str:
    return str(row["operation_id"])


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--case", action="append")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output must not exist")
    h = Harness(args.binary, args.output)
    began = time.time()
    passed = False
    try:
        cases(h, set(args.case) if args.case else None)
        passed = True
    except BaseException as exc:
        (h.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=os.sys.stderr)
    finally:
        h.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_PUBLICATION_CHANNEL_TESTS_V1",
            "status": "PASS" if passed else "FAIL",
            "binary_sha256": hashlib.sha256(h.binary.read_bytes()).hexdigest(),
            "cases_total": len(h.cases),
            "cases_passed": sum(item["status"] == "PASS" for item in h.cases),
            "assertions": h.assertions,
            "commands": len(h.commands),
            "elapsed_seconds": time.time() - began,
        }
        for name, value in (("SUMMARY", summary), ("CASES", h.cases),
                            ("COMMANDS", h.commands)):
            (h.output / f"{name}.json").write_text(
                json.dumps(value, sort_keys=True, indent=2) + "\n")
        print(json.dumps(summary), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
