#!/usr/bin/env python3
"""Storage migration, live compaction, crash boundary, and backup tests."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time
from typing import Any, Callable

from run_authorization_actions import (
    action_entry,
    action_payload,
    generation,
    independent_record,
    outbox_entry,
    submit_action,
    submit_evidence,
    write_config,
)
from run_persistent import Harness, free_port, operation


def compact(h: Harness, label: str, control: Path, expected: int = 0) -> dict[str, Any]:
    result = h.run(
        label,
        ["compact", "--control", str(control), "--deadline-ms", "30000"],
        expected=expected,
        timeout=35,
    )
    assert result is not None
    return result


def inspect(h: Harness, label: str, state: Path, node: str) -> dict[str, Any]:
    result = h.run(label, ["inspect", "--state", str(state), "--node", node])
    assert result is not None
    return result


def wait_outbox_acked(h: Harness, state: Path, operation_id: str, label: str) -> dict[str, Any]:
    observed: dict[str, Any] = {}

    def ready() -> bool:
        observed.clear()
        observed.update(h.status(label, state))
        return outbox_entry(observed, operation_id)["status"] == "ACKED"

    h.wait(f"{operation_id} acknowledged", ready, timeout=10)
    return observed


def run_suite(h: Harness, selected: set[str] | None = None) -> None:
    def run_case(name: str, function: Callable[[], None]) -> None:
        if selected is None or name in selected:
            h.case(name, function)

    def schema_migration_and_empty_compaction() -> None:
        root = h.runtime / "schema-migration"
        root.mkdir()
        state = root / "state"
        first = inspect(h, "migration-create-v2", state, "A")
        h.check(first["storage"]["schema_version"] == 2, "fresh state uses schema 2")
        (state / "node.meta").write_text("NATRAV_OVERLAY_NODE_STATE_V1\nA\n")
        (state / "node.meta").chmod(0o600)
        migrated = inspect(h, "migration-open-v1", state, "A")
        h.check(migrated["storage"]["schema_version"] == 2, "V1 state migrates to V2")
        migrations = migrated["storage"]["migrations"]
        h.check(len(migrations) == 1, "one migration account retained")
        h.check(
            migrations[0]["from_version"] == 1 and migrations[0]["to_version"] == 2,
            "migration direction is explicit",
        )
        h.check(
            (state / "node.meta").read_text() ==
            "NATRAV_OVERLAY_NODE_STATE_V2\nnode=A\nstorage_schema=2\n",
            "V2 metadata is published exactly",
        )

        config = h.config("migration-a", "A", state, free_port(), [], deadline_ms=5000)
        daemon = h.start("migration-a", config, state)
        before = h.status("migration-status-before", state)
        result = compact(h, "migration-compact", daemon.control)
        after = h.status("migration-status-after", state)
        h.check(result["generation"] == 1, "first maintenance generation published")
        h.check(
            before["storage"]["logical_state_digest"] ==
            after["storage"]["logical_state_digest"],
            "empty migration logical state survives compaction",
        )
        h.check(after["storage"]["migrations"] == 1, "live status retains migration count")
        daemon.shutdown()
        reopened = inspect(h, "migration-inspect-after", state, "A")
        h.check(
            reopened["storage"]["maintenance_generation"] == 1,
            "compaction generation reconstructs offline",
        )
        h.check(len(reopened["storage"]["migrations"]) == 1, "migration survives checkpoint")

    run_case("schema_migration_and_empty_compaction", schema_migration_and_empty_compaction)

    def rich_live_compaction_and_continuation() -> None:
        root = h.runtime / "rich-compaction"
        root.mkdir()
        a_state, b_state, c_state, d_state = (
            root / "a", root / "b", root / "c", root / "d"
        )
        a_port, b_port, c_port, d_port = (
            free_port(), free_port(), free_port(), free_port()
        )
        a_config = write_config(
            h, "maint-rich-a", "A", a_state, a_port, "A",
            [("D", d_port, "D")],
            [
                ("B", "b1", "ACTIVE", "B"),
                ("C", "c1", "ACTIVE", "C"),
                ("D", "d1", "ACTIVE", "D"),
            ],
            [
                ("B", "*", "EVIDENCE", "maintenance/evidence"),
                ("B", "*", "ACTION", "counter.add"),
            ],
            counter_budget=100,
            maximum_increment=20,
            maximum_defer_ms=5000,
            action_expiry_ms=1800,
            deadline_ms=180,
        )
        b_config = write_config(
            h, "maint-rich-b", "B", b_state, b_port, "B",
            [("A", a_port, "A")],
            [("A", "a1", "ACTIVE", "A")],
            [],
            deadline_ms=500,
        )
        c_config = write_config(
            h, "maint-rich-c", "C", c_state, c_port, "C",
            [("A", a_port, "A")],
            [("A", "a1", "ACTIVE", "A")],
            [],
            deadline_ms=500,
        )
        d_config = write_config(
            h, "maint-rich-d", "D", d_state, d_port, "D",
            [],
            [("A", "a1", "ACTIVE", "A")],
            [("A", "*", "EVIDENCE", "maintenance/offline")],
            deadline_ms=500,
        )
        a = h.start(
            "maint-rich-a", a_config, a_state,
            {"NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS": "2500"},
        )
        b = h.start("maint-rich-b", b_config, b_state)
        c = h.start("maint-rich-c", c_config, c_state)

        original = operation("maintenance-original")
        corrected = operation("maintenance-correction")
        submit_evidence(
            h, "maintenance-original-submit", b.control, "B", "A",
            "maintenance/evidence", original, "temperature=20",
        )
        wait_outbox_acked(h, b_state, original, "maintenance-original-wait")
        revised = h.run(
            "maintenance-correction-submit",
            [
                "revise", "--control", str(b.control), "--node", "B",
                "--peer", "A", "--scope", "maintenance/evidence",
                "--operation", corrected, "--corrects", original,
                "--payload-text", "temperature=21", "--deadline-ms", "2000",
            ],
        )
        h.check(revised is not None and revised["ok"] is True, "correction queued")
        wait_outbox_acked(h, b_state, corrected, "maintenance-correction-wait")

        denied = operation("maintenance-denied")
        submit_evidence(
            h, "maintenance-denied-submit", c.control, "C", "A",
            "maintenance/evidence", denied, "not-authorized",
        )
        denied_sender: dict[str, Any] = {}

        def denial_visible() -> bool:
            denied_sender.clear()
            denied_sender.update(h.status("maintenance-denied-wait", c_state))
            return outbox_entry(denied_sender, denied)["last_error_code"] == "AUTHORIZATION_DENIED"

        h.wait("typed denial returns", denial_visible)

        completed_action = operation("maintenance-action-completed")
        submit_action(
            h, "maintenance-action-completed-submit", b.control,
            "B", "A", completed_action, 5,
        )
        wait_outbox_acked(h, b_state, completed_action, "maintenance-action-completed-ack")
        h.wait(
            "first counter action durably begins",
            lambda: (
                h.status("maintenance-action-begun", a_state)["actions"]["count"] == 1
                and action_entry(
                    h.status("maintenance-action-begun-detail", a_state),
                    completed_action,
                )["attempts"] == 1
            ),
        )

        expired_action = operation("maintenance-action-expired")
        submit_action(
            h, "maintenance-action-expired-submit", b.control,
            "B", "A", expired_action, 9, 0,
        )
        wait_outbox_acked(h, b_state, expired_action, "maintenance-action-expired-ack")
        completed_status: dict[str, Any] = {}

        def action_completed_and_expired() -> bool:
            completed_status.clear()
            completed_status.update(
                h.status("maintenance-action-terminal-wait", a_state)
            )
            return (
                completed_status["actions"]["executed"] == 1
                and completed_status["actions"]["expired"] == 1
            )

        h.wait(
            "first action completes and queued action expires",
            action_completed_and_expired,
            timeout=8,
        )

        cancelled_action = operation("maintenance-action-cancelled")
        submit_action(
            h, "maintenance-action-cancelled-submit", b.control,
            "B", "A", cancelled_action, 7, 1200,
        )
        wait_outbox_acked(h, b_state, cancelled_action, "maintenance-action-cancelled-ack")
        h.wait(
            "cancelled action admitted",
            lambda: any(
                item["action_id"] == cancelled_action
                for item in h.status(
                    "maintenance-action-cancelled-visible", a_state
                )["actions"]["entries"]
            ),
        )
        cancelled = h.run(
            "maintenance-action-cancel",
            [
                "action-cancel", "--control", str(a.control),
                "--action", cancelled_action,
                "--reason", "maintenance cancellation",
                "--deadline-ms", "2000",
            ],
        )
        h.check(
            cancelled is not None and cancelled["status"] == "CANCELLED",
            "action cancelled before execution",
        )

        offline = operation("maintenance-offline-delivery")
        offline_submit = h.run(
            "maintenance-offline-submit",
            [
                "submit", "--control", str(a.control), "--node", "A",
                "--peer", "D", "--scope", "maintenance/offline",
                "--operation", offline, "--payload-text", "queued while absent",
                "--deadline-ms", "2000",
            ],
        )
        h.check(offline_submit is not None and offline_submit["ok"] is True, "offline work queued")
        h.wait(
            "offline retries accumulate",
            lambda: outbox_entry(
                h.status("maintenance-offline-retry-wait", a_state), offline
            )["attempts"] >= 3,
            timeout=8,
        )

        before = h.status("maintenance-rich-before", a_state)
        before_inode = (a_state / "state.journal").stat().st_ino
        result = compact(h, "maintenance-rich-compact", a.control)
        after = h.status("maintenance-rich-after", a_state)
        after_inode = (a_state / "state.journal").stat().st_ino
        h.check(before_inode != after_inode, "compaction atomically replaces journal inode")
        # Retrying D can append between separate control requests. Inspect the
        # exact published checkpoint prefix, not a later live snapshot whose
        # attempt account may legitimately have advanced. Appends cannot alter
        # this prefix and this scenario performs no second compaction.
        checkpoint_state = root / "published-checkpoint"
        checkpoint_state.mkdir(mode=0o700)
        shutil.copyfile(a_state / "node.meta", checkpoint_state / "node.meta")
        (checkpoint_state / "node.meta").chmod(0o600)
        with (a_state / "state.journal").open("rb") as journal:
            published = journal.read(result["after_bytes"])
        h.check(len(published) == result["after_bytes"], "complete published checkpoint read")
        (checkpoint_state / "state.journal").write_bytes(published)
        (checkpoint_state / "state.journal").chmod(0o600)
        checkpoint = inspect(h, "maintenance-rich-checkpoint", checkpoint_state, "A")
        h.check(
            checkpoint["storage"]["logical_state_digest"] == result["logical_state_digest"],
            "actual published checkpoint reconstructs the exact compaction digest",
        )
        h.check(checkpoint["inbound"]["count"] == before["inbound_records"],
                "checkpoint preserves all evidence and actions")
        h.check(checkpoint["authorization_denials"]["count"] == before["authorization"]["denied"],
                "checkpoint preserves the denial history")
        checkpoint_record = outbox_entry(checkpoint, offline)
        checkpoint_outbound = {**checkpoint_record, **checkpoint_record["delivery"]}
        before_outbound = outbox_entry(before, offline)
        after_outbound = outbox_entry(after, offline)
        h.check(before_outbound["attempts"] <= checkpoint_outbound["attempts"] <= after_outbound["attempts"],
                "live retries only advance the attempt account around compaction")
        for field in ("status", "peer_generation", "peer_spki_sha256", "expires_unix_ms"):
            h.check(before_outbound[field] == checkpoint_outbound[field] == after_outbound[field],
                    f"compaction preserves the pending obligation {field}")
        h.check(after["storage"]["maintenance_generation"] == 1, "rich compaction generation visible")
        h.check(result["after_bytes"] < result["before_bytes"], "operational noise is reclaimed")
        h.check(after["inbound_records"] == 5, "evidence, correction, and three actions retained")
        h.check(after["authorization"]["denied"] == 1, "denial account retained")
        h.check(after["actions"]["executed"] == 1, "completed action retained")
        h.check(after["actions"]["cancelled"] == 1, "cancelled action retained")
        h.check(after["actions"]["expired"] == 1, "expired action retained")
        h.check(after["actions"]["counter_value"] == 5, "counter value retained")

        d = h.start("maint-rich-d", d_config, d_state)
        h.run(
            "maintenance-offline-wake",
            ["wake", "--control", str(a.control), "--peer", "D", "--deadline-ms", "2000"],
        )
        final_live = wait_outbox_acked(h, a_state, offline, "maintenance-offline-acked")
        h.check(outbox_entry(final_live, offline)["status"] == "ACKED", "delivery continues after compaction")
        final_digest = final_live["storage"]["logical_state_digest"]

        c.shutdown(); b.shutdown(); d.shutdown(); a.shutdown()
        reopened = inspect(h, "maintenance-rich-reopened", a_state, "A")
        h.check(reopened["storage"]["logical_state_digest"] == final_digest, "post-compaction appends reconstruct")
        h.check(reopened["outbox"]["acked"] == 1, "post-compaction receipt reconstructs")
        h.check(reopened["actions"]["counter_value"] == 5, "no duplicate action effect after restart")
        current = reopened["inbound"]["current"]
        h.check(
            any(item["current_operation_id"] == corrected for item in current),
            "correction head reconstructs after checkpoint",
        )

    run_case("rich_live_compaction_and_continuation", rich_live_compaction_and_continuation)

    def publication_crash_boundaries() -> None:
        root = h.runtime / "publication-crash"
        root.mkdir()

        before_state = root / "before"
        before_config = h.config(
            "compact-kill-before", "A", before_state, free_port(), [],
            deadline_ms=20000,
        )
        before_daemon = h.start(
            "compact-kill-before", before_config, before_state,
            {"NATRAV_OVERLAY_TEST_COMPACT_BEFORE_PUBLISH_MS": "10000"},
        )
        initial = h.status("compact-kill-before-initial", before_state)
        client = subprocess.Popen(
            [
                str(h.binary), "compact", "--control", str(before_daemon.control),
                "--deadline-ms", "30000",
            ],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        h.wait(
            "candidate exists before publication",
            lambda: (before_state / "state.journal.compact.tmp").is_file(),
            timeout=8,
        )
        before_daemon.kill()
        client.communicate(timeout=5)
        h.check(
            (before_state / "state.journal.compact.tmp").exists(),
            "pre-publication kill leaves a recognizable sibling candidate",
        )
        before_restarted = h.start("compact-kill-before-restart", before_config, before_state)
        recovered = h.status("compact-kill-before-recovered", before_state)
        h.check(
            recovered["storage"]["maintenance_generation"] == 0,
            "old journal remains authoritative before publication",
        )
        h.check(
            recovered["storage"]["logical_state_digest"] ==
            initial["storage"]["logical_state_digest"],
            "pre-publication kill preserves logical state",
        )
        h.check(
            not (before_state / "state.journal.compact.tmp").exists(),
            "stale candidate is removed on restart",
        )
        before_restarted.shutdown()

        after_state = root / "after"
        after_config = h.config(
            "compact-kill-after", "Z", after_state, free_port(), [],
            deadline_ms=20000,
        )
        after_daemon = h.start(
            "compact-kill-after", after_config, after_state,
            {"NATRAV_OVERLAY_TEST_COMPACT_AFTER_PUBLISH_MS": "10000"},
        )
        old_inode = (after_state / "state.journal").stat().st_ino
        initial_after = h.status("compact-kill-after-initial", after_state)
        after_client = subprocess.Popen(
            [
                str(h.binary), "compact", "--control", str(after_daemon.control),
                "--deadline-ms", "30000",
            ],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        def published() -> bool:
            journal = after_state / "state.journal"
            return (
                journal.exists()
                and journal.stat().st_ino != old_inode
                and not (after_state / "state.journal.compact.tmp").exists()
            )

        h.wait("new journal published before kill", published, timeout=8)
        after_daemon.kill()
        after_client.communicate(timeout=5)
        after_restarted = h.start("compact-kill-after-restart", after_config, after_state)
        recovered_after = h.status("compact-kill-after-recovered", after_state)
        h.check(
            recovered_after["storage"]["maintenance_generation"] == 1,
            "new checkpoint remains authoritative after publication",
        )
        h.check(
            recovered_after["storage"]["logical_state_digest"] ==
            initial_after["storage"]["logical_state_digest"],
            "post-publication kill preserves logical state",
        )
        after_restarted.shutdown()

    run_case("publication_crash_boundaries", publication_crash_boundaries)

    def candidate_validation_rejects_corruption() -> None:
        root = h.runtime / "candidate-validation"
        root.mkdir()
        state = root / "state"
        config = h.config(
            "candidate-validation", "A", state, free_port(), [],
            deadline_ms=5000,
        )
        daemon = h.start(
            "candidate-validation", config, state,
            {"NATRAV_OVERLAY_TEST_CORRUPT_COMPACTION_CANDIDATE": "1"},
        )
        before = h.status("candidate-validation-before", state)
        rejected = compact(h, "candidate-validation-compact", daemon.control, expected=3)
        h.check(
            rejected["code"] in {"JOURNAL_CORRUPT", "COMPACTION_CANDIDATE_REJECTED"},
            "normal decoder rejects corrupted candidate",
        )
        after = h.status("candidate-validation-after", state)
        h.check(after["storage"]["maintenance_generation"] == 0, "bad candidate is not published")
        h.check(
            before["storage"]["logical_state_digest"] ==
            after["storage"]["logical_state_digest"],
            "candidate rejection preserves active state",
        )
        h.check(
            not (state / "state.journal.compact.tmp").exists(),
            "rejected candidate is removed",
        )
        daemon.shutdown()

    run_case("candidate_validation_rejects_corruption", candidate_validation_rejects_corruption)

    def signed_backup_restore_and_replay() -> None:
        root = h.runtime / "backup-restore"
        root.mkdir()
        a_state, b_state = root / "a", root / "b"
        a_port, b_port = free_port(), free_port()
        a_config = write_config(
            h, "backup-a", "A", a_state, a_port, "A", [],
            [("B", "b1", "ACTIVE", "B")],
            [
                ("B", "*", "EVIDENCE", "maintenance/backup"),
                ("B", "*", "ACTION", "counter.add"),
            ],
            counter_budget=100,
            maximum_increment=20,
            maximum_defer_ms=1000,
            action_expiry_ms=10000,
        )
        b_config = write_config(
            h, "backup-b", "B", b_state, b_port, "B",
            [("A", a_port, "A")],
            [("A", "a1", "ACTIVE", "A")],
            [],
        )
        a = h.start("backup-a", a_config, a_state)
        b = h.start("backup-b", b_config, b_state)
        evidence = operation("backup-evidence")
        action = operation("backup-action")
        submit_evidence(
            h, "backup-evidence-submit", b.control, "B", "A",
            "maintenance/backup", evidence, "preserve me",
        )
        wait_outbox_acked(h, b_state, evidence, "backup-evidence-wait")
        submit_action(
            h, "backup-action-submit", b.control, "B", "A", action, 11,
        )
        wait_outbox_acked(h, b_state, action, "backup-action-ack")
        h.wait(
            "backup action completes",
            lambda: h.status("backup-action-wait", a_state)["actions"]["executed"] == 1,
        )
        b.shutdown(); a.shutdown()
        before = inspect(h, "backup-before-inspect", a_state, "A")

        backup = root / "a-signed.nob"
        identity = h.identity("A")
        exported = h.run(
            "backup-export-signed",
            [
                "backup-export", "--state", str(a_state), "--node", "A",
                "--generation", generation("A"), "--output", str(backup),
                "--sign-key", str(identity.private_key),
                "--sign-cert", str(identity.certificate),
            ],
        )
        assert exported is not None
        h.check(exported["signed"] is True, "signed backup exported")
        verified = h.run(
            "backup-verify-signed",
            [
                "backup-verify", "--input", str(backup), "--node", "A",
                "--generation", generation("A"),
                "--trusted-cert", str(identity.certificate),
                "--require-signature", "yes",
            ],
        )
        assert verified is not None
        h.check(verified["signature_valid"] is True, "embedded signature verifies")
        h.check(verified["trusted_signer"] is True, "trusted certificate pins signer")
        h.check(
            verified["logical_state_digest"] == before["storage"]["logical_state_digest"],
            "backup manifest binds complete logical state",
        )

        restored_state = root / "restored"
        restored = h.run(
            "backup-restore-signed",
            [
                "backup-restore", "--input", str(backup),
                "--destination", str(restored_state), "--node", "A",
                "--generation", generation("A"),
                "--trusted-cert", str(identity.certificate),
                "--require-signature", "yes",
            ],
        )
        assert restored is not None
        after = inspect(h, "backup-after-inspect", restored_state, "A")
        h.check(
            before["storage"]["logical_state_digest"] ==
            after["storage"]["logical_state_digest"],
            "restored logical digest matches source",
        )
        for key in ("inbound", "outbox", "authorization_denials", "actions", "recoveries"):
            h.check(before[key] == after[key], f"restored {key} is logically exact")
        h.check(
            after["storage"]["restored_backup_id"] == exported["backup_id"],
            "restore provenance names exact backup",
        )
        h.check(
            after["storage"]["restored_backup_generation"] == generation("A"),
            "restore provenance names identity generation",
        )

        duplicate_destination = h.run(
            "backup-restore-no-overwrite",
            [
                "backup-restore", "--input", str(backup),
                "--destination", str(restored_state), "--node", "A",
                "--generation", generation("A"),
                "--trusted-cert", str(identity.certificate),
                "--require-signature", "yes",
            ],
            expected=3,
        )
        h.check(
            duplicate_destination is not None and
            duplicate_destination["code"] == "BACKUP_DESTINATION_EXISTS",
            "restore refuses overwrite",
        )
        duplicate_export = h.run(
            "backup-export-no-overwrite",
            [
                "backup-export", "--state", str(a_state), "--node", "A",
                "--generation", generation("A"), "--output", str(backup),
            ],
            expected=3,
        )
        h.check(
            duplicate_export is not None and
            duplicate_export["code"] == "BACKUP_DESTINATION_EXISTS",
            "export refuses overwrite",
        )

        wrong_identity = h.identity("WRONG")
        wrong_trust = h.run(
            "backup-wrong-trust",
            [
                "backup-verify", "--input", str(backup),
                "--trusted-cert", str(wrong_identity.certificate),
                "--require-signature", "yes",
            ],
            expected=3,
        )
        h.check(
            wrong_trust is not None and wrong_trust["code"] == "BACKUP_SIGNER_NOT_TRUSTED",
            "wrong trust anchor rejected",
        )

        corrupted = root / "corrupted.nob"
        corrupted.write_bytes(backup.read_bytes())
        damaged = bytearray(corrupted.read_bytes())
        damaged[len(damaged) // 2] ^= 0x40
        corrupted.write_bytes(damaged)
        corruption = h.run(
            "backup-corruption-rejected",
            ["backup-verify", "--input", str(corrupted), "--require-signature", "yes"],
            expected=3,
        )
        h.check(
            corruption is not None and corruption["code"] in {
                "BACKUP_CHECKPOINT_DIGEST_MISMATCH",
                "BACKUP_CERTIFICATE_INVALID",
                "BACKUP_SIGNATURE_INVALID",
                "BACKUP_ID_MISMATCH",
            },
            "altered backup is rejected",
        )

        unsigned = root / "a-unsigned.nob"
        h.run(
            "backup-export-unsigned",
            [
                "backup-export", "--state", str(a_state), "--node", "A",
                "--generation", generation("A"), "--output", str(unsigned),
            ],
        )
        signature_required = h.run(
            "backup-unsigned-signature-required",
            ["backup-verify", "--input", str(unsigned), "--require-signature", "yes"],
            expected=3,
        )
        h.check(
            signature_required is not None and
            signature_required["code"] == "BACKUP_SIGNATURE_REQUIRED",
            "required signature rejects unsigned backup",
        )

        restored_port = free_port()
        restored_config = write_config(
            h, "backup-restored-a", "A", restored_state, restored_port, "A", [],
            [("B", "b1", "ACTIVE", "B")],
            [
                ("B", "*", "EVIDENCE", "maintenance/backup"),
                ("B", "*", "ACTION", "counter.add"),
            ],
            counter_budget=100,
            maximum_increment=20,
            maximum_defer_ms=1000,
            action_expiry_ms=10000,
        )
        restored_daemon = h.start("backup-restored-a", restored_config, restored_state)
        replay = independent_record(
            h, restored_port, "B", "B", "A", action,
            "actions/counter.add/v1", action_payload(11),
        )
        h.check(replay["kind"] == "receipt" and replay["disposition"] == 2, "restored duplicate receives duplicate receipt")
        replay_status = h.status("backup-restored-replay-status", restored_state)
        h.check(replay_status["actions"]["count"] == 1, "restore replay does not multiply action")
        h.check(replay_status["actions"]["counter_value"] == 11, "restore replay does not repeat effect")
        restored_daemon.shutdown()

    run_case("signed_backup_restore_and_replay", signed_backup_restore_and_replay)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, default=Path("node/bin/natrav-overlay"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--case",
        action="append",
        choices=[
            "schema_migration_and_empty_compaction",
            "rich_live_compaction_and_continuation",
            "publication_crash_boundaries",
            "candidate_validation_rejects_corruption",
            "signed_backup_restore_and_replay",
        ],
    )
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output directory must not exist")
    harness = Harness(args.binary, args.output)
    started = time.time()
    status = "FAIL"
    return_code = 1
    try:
        run_suite(harness, set(args.case) if args.case else None)
        status = "PASS"
        return_code = 0
    except BaseException as exc:
        (harness.output / "FAILURE.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        print(f"FAIL: {type(exc).__name__}: {exc}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_MAINTENANCE_TESTS_V1",
            "status": status,
            "binary": str(harness.binary),
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(case["status"] == "PASS" for case in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "selected_cases": args.case or [],
            "started_unix": started,
            "elapsed_seconds": time.time() - started,
        }
        (harness.output / "SUMMARY.json").write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n"
        )
        (harness.output / "CASES.json").write_text(
            json.dumps(harness.cases, indent=2, sort_keys=True) + "\n"
        )
        (harness.output / "COMMANDS.json").write_text(
            json.dumps(harness.commands, indent=2, sort_keys=True) + "\n"
        )
        print(json.dumps(summary, sort_keys=True))
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
