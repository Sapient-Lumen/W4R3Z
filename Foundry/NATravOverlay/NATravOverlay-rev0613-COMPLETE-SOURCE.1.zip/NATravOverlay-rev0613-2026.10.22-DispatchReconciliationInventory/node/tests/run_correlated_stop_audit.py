#!/usr/bin/env python3
"""Offline authenticated correlated-stop handoff audit."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
from typing import Any, Callable

from run_persistent import Harness, free_port, operation
from run_control_authorization import Client
from run_correlated_terminal_state_head import (
    correlated_terminal_drain,
    correlated_terminal_shutdown,
    setup_keyed,
    terminal_args,
)
from run_correlated_stopping import request_id
from run_response_loss_stopping import drop_after_complete_request, wait_stopped
from run_local_administration import expose_control_for_uid, restore_owner_only_control
from run_state_authentication import independent_open, new_key, start
from run_state_expectations import selector

DELEGATED_UID = 65534
CASES = (
    "lost_response_explicit_and_exact_id",
    "deadline_pending_obligation_and_redaction",
    "duplicates_preserved_and_bounded",
    "denied_and_missing_request_ids",
    "exclusive_read_and_corruption_fail_closed",
    "compaction_preserves_offline_selection",
    "encrypted_restore_and_relocation_preserve_selection",
    "strict_cli_shapes",
)


def audit(
    h: Harness,
    label: str,
    state: Path,
    key: Path | None,
    selection: list[str],
    *,
    expected: int = 0,
    expected_head: str | None = None,
    max_matches: int = 64,
    max_bytes: int = 60000,
) -> dict[str, Any]:
    args = [
        "correlated-stop-audit",
        "--state", str(state),
        "--node", "A",
        "--max-matches", str(max_matches),
        "--max-bytes", str(max_bytes),
        *selection,
    ]
    if key is not None:
        args += ["--state-auth-key", str(key)]
    if expected_head is not None:
        args += ["--expected-state-head", expected_head]
    value = h.run(label, args, expected=expected, timeout=20)
    assert value is not None
    return value


def shape_immediate(token: str, final: bool = True) -> list[str]:
    return [
        "--correlation", token,
        "--stop", "immediate",
        "--final-state-head", "yes" if final else "no",
    ]


def shape_drain(token: str, deadline: int, reason: str, final: bool = True) -> list[str]:
    return [
        "--correlation", token,
        "--stop", "drain",
        "--final-state-head", "yes" if final else "no",
        "--drain-deadline-ms", str(deadline),
        "--reason", reason,
    ]


def mutated_selector(value: str) -> str:
    fields = value.split(":")
    assert len(fields) == 8
    fields[-1] = str(int(fields[-1]) + 1)
    return ":".join(fields)


def lifecycle_reason_digest(value: str) -> str:
    return hashlib.sha256(
        b"NATRAV_OVERLAY_LIFECYCLE_REASON_V1\0" + value.encode()
    ).hexdigest()


def check_common(h: Harness, value: dict[str, Any], expected_id: str) -> None:
    h.check(
        value.get("format") == "NATRAV_OVERLAY_OFFLINE_CORRELATED_STOP_AUDIT_V1"
        and value.get("ok") is True,
        "offline audit has explicit successful format",
    )
    h.check(value["selection"]["request_id"] == expected_id, "audit selects exact request identity")
    h.check(value["source"]["status"] == "COMPLETE_AUTHENTICATED_SEMANTIC_REPLAY", "audit reports complete authenticated replay")
    h.check(value["source"]["exclusive_existing_state_lock"] is True, "audit owns exact stopped state")
    h.check(value["source"]["writer_opened"] is False and value["source"]["workers_started"] is False, "audit opens no writer or worker")
    h.check(value["source"]["state_mutated"] is False and value["mutation"] == "NONE", "audit is observational")
    h.check(value["freshness"] == "NOT_ESTABLISHED" and value["automatic_expectation_update"] is False, "audit invents no freshness or anchor update")
    h.check(value["outcome"]["response_receipt"] == "NOT_ESTABLISHED", "history is not response receipt proof")
    h.check(value["outcome"]["idempotency"] == "NOT_ESTABLISHED", "request ID is not idempotency")
    h.check(value["redaction"] == "NO_PAYLOADS_SECRETS_REASON_TEXT_OR_IDENTITY_PATHS", "report declares narrow redaction")


def run_suite(h: Harness, selected: set[str] | None) -> None:
    def case(name: str, function: Callable[[], None]) -> None:
        if selected is None or name in selected:
            h.case(name, function)

    def lost_response_explicit_and_exact_id() -> None:
        token = "offline-audit-lost-01"
        payload = correlated_terminal_shutdown(token)
        expected_id = request_id(payload)
        _, state, key, _, daemon = setup_keyed(
            h,
            "offline-audit-lost",
            environment={
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_COMMAND": "SHUTDOWN_TERMINAL_CORRELATED",
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_PAUSE_MS": "300",
            },
        )
        drop_after_complete_request(daemon.control, payload)
        wait_stopped(h, daemon, "offline audit lost response")
        before = (state / "state.journal").read_bytes()
        independent_open(before, key)

        explicit = audit(h, "offline-audit-explicit", state, key, shape_immediate(token))
        check_common(h, explicit, expected_id)
        h.check(explicit["selection"]["method"] == "EXPLICIT_REQUEST_SHAPE", "explicit request shape is identified")
        h.check(explicit["selection"]["shape"]["correlation_token"] == token, "caller token is echoed only from selection input")
        h.check(explicit["outcome"]["classification"] == "ACCEPTED_IMMEDIATE", "lost terminal response has accepted immediate outcome")
        h.check(explicit["matches"]["decision_count"] == 1 and explicit["matches"]["lifecycle_count"] == 1, "one decision and lifecycle boundary are selected")
        h.check(explicit["matches"]["decisions"][0]["command"] == "SHUTDOWN_TERMINAL_CORRELATED", "authorization row identifies exact protocol")
        h.check(explicit["matches"]["lifecycle"][0]["kind"] == "SHUTDOWN_REQUESTED", "terminal boundary is preserved")
        h.check(explicit["matches"]["lifecycle"][0]["reason_text"] is None, "free-text lifecycle reason is redacted")
        h.check(explicit["state_head"]["selector"] == selector(before, key), "independent byte calculation agrees with audited head")

        exact = audit(
            h,
            "offline-audit-exact-id",
            state,
            key,
            ["--request-id", expected_id],
            expected_head=explicit["state_head"]["selector"],
        )
        check_common(h, exact, expected_id)
        h.check(exact["selection"]["method"] == "EXACT_REQUEST_ID" and exact["selection"]["shape"] is None, "exact-ID selection recovers no token text")
        h.check(exact["matches"] == explicit["matches"] and exact["outcome"] == explicit["outcome"], "shape and exact-ID paths select identical durable facts")
        h.check((state / "state.journal").read_bytes() == before, "both audits leave exact bytes unchanged")
        h.check(token.encode() not in before, "correlation token remains absent from durable state")

        mismatch = audit(
            h,
            "offline-audit-stale-expectation",
            state,
            key,
            ["--request-id", expected_id],
            expected=3,
            expected_head=mutated_selector(explicit["state_head"]["selector"]),
        )
        h.check(mismatch["code"] == "STATE_HEAD_EXPECTATION_MISMATCH", "separate exact expectation fails closed")
        h.check((state / "state.journal").read_bytes() == before, "expectation mismatch mutates nothing")

    case("lost_response_explicit_and_exact_id", lost_response_explicit_and_exact_id)

    def deadline_pending_obligation_and_redaction() -> None:
        token = "offline-audit.deadline-02"
        reason = "private maintenance reason must remain redacted"
        deadline = 150
        expected_id = request_id(correlated_terminal_drain(deadline, reason, token))
        unavailable = free_port()
        _, state, key, _, daemon = setup_keyed(
            h,
            "offline-audit-deadline",
            peers=[("B", unavailable)],
        )
        secret_payload = "retained private payload sentinel"
        h.run(
            "offline-audit-pending-submit",
            [
                "submit", "--control", str(daemon.control), "--node", "A",
                "--peer", "B", "--scope", "admin/test",
                "--operation", operation("offline-audit-pending"),
                "--payload-text", secret_payload, "--deadline-ms", "2000",
            ],
        )
        response = h.run(
            "offline-audit-deadline-stop",
            terminal_args(daemon.control, token, deadline, reason),
            timeout=20,
        )
        assert response is not None
        wait_stopped(h, daemon, "offline audit deadline")
        before = (state / "state.journal").read_bytes()

        value = audit(h, "offline-audit-deadline-report", state, key, shape_drain(token, deadline, reason))
        check_common(h, value, expected_id)
        h.check(value["outcome"]["classification"] == "ACCEPTED_DRAIN_DEADLINE", "deadline outcome is explicit")
        h.check([row["kind"] for row in value["matches"]["lifecycle"]] == ["DRAIN_STARTED", "DRAIN_DEADLINE"], "both drain boundaries are retained")
        h.check(all(row["deadline_ms"] == deadline for row in value["matches"]["lifecycle"]), "request deadline remains exact")
        h.check(all(row["reason_text"] is None for row in value["matches"]["lifecycle"]), "reason text is never disclosed")
        h.check(all(row["reason_bytes"] == len(reason) and row["reason_digest"] == lifecycle_reason_digest(reason) for row in value["matches"]["lifecycle"]), "redacted reason binding remains independently checkable")
        h.check(value["selection"]["shape"]["reason_text"] is None and value["selection"]["shape"]["reason_digest"] == lifecycle_reason_digest(reason), "caller shape is represented without reason text")
        h.check(value["retained_obligations"]["pending_outbound"] == 1 and value["retained_obligations"]["complete"] is False, "current replay preserves the pending delivery")
        rendered = json.dumps(value, separators=(",", ":"))
        h.check(secret_payload not in rendered and reason not in rendered, "payload and free-text reason do not enter report")
        h.check((state / "state.journal").read_bytes() == before, "deadline audit changes no bytes")

    case("deadline_pending_obligation_and_redaction", deadline_pending_obligation_and_redaction)

    def duplicates_preserved_and_bounded() -> None:
        token = "offline-audit-duplicate-03"
        expected_id = request_id(correlated_terminal_shutdown(token))
        _, state, key, config, daemon = setup_keyed(h, "offline-audit-duplicates")
        for ordinal in range(3):
            value = h.run(
                f"offline-audit-duplicate-stop-{ordinal + 1}",
                terminal_args(daemon.control, token),
                timeout=20,
            )
            assert value is not None
            wait_stopped(h, daemon, f"offline audit duplicate {ordinal + 1}")
            if ordinal != 2:
                daemon = start(h, f"offline-audit-duplicate-restart-{ordinal + 1}", config, state, key)
        before = (state / "state.journal").read_bytes()

        value = audit(h, "offline-audit-duplicates-report", state, key, ["--request-id", expected_id], max_matches=6)
        check_common(h, value, expected_id)
        h.check(value["matches"]["decision_count"] == 3 and value["matches"]["lifecycle_count"] == 3, "all duplicate decisions and lifecycle boundaries are preserved")
        h.check(value["outcome"]["authorized_decisions"] == 3 and value["outcome"]["shutdown_requested"] == 3, "duplicates remain independently accepted")
        h.check(value["outcome"]["classification"] == "ACCEPTED_IMMEDIATE", "duplicate immediate outcomes remain coherent without deduplication")
        h.check(len({row["ordinal"] for row in value["matches"]["decisions"]}) == 3, "decision ordinals remain distinct")

        limited = audit(h, "offline-audit-duplicates-match-limit", state, key, ["--request-id", expected_id], expected=3, max_matches=5)
        h.check(limited["code"] == "CORRELATED_STOP_AUDIT_MATCH_LIMIT", "bounded report fails rather than truncating duplicates")
        small = audit(h, "offline-audit-duplicates-byte-limit", state, key, ["--request-id", expected_id], expected=3, max_matches=6, max_bytes=4096)
        h.check(small["code"] == "CORRELATED_STOP_AUDIT_RESPONSE_TOO_LARGE", "byte ceiling fails before partial report emission")
        h.check((state / "state.journal").read_bytes() == before, "bounded failures mutate no state")

    case("duplicates_preserved_and_bounded", duplicates_preserved_and_bounded)

    def denied_and_missing_request_ids() -> None:
        token = "offline-audit-denied-04"
        payload = correlated_terminal_shutdown(token)
        expected_id = request_id(payload)
        _, state, key, _, daemon = setup_keyed(
            h,
            "offline-audit-denied",
            grants=[(os.geteuid(), ["ALL"]), (DELEGATED_UID, ["INSPECT"])],
            environment={"NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER": "1"},
        )
        expose_control_for_uid(state)
        client = Client(h, daemon, "offline-audit-denied-client", payload, uid=DELEGATED_UID, split=False)
        try:
            denied = client.finish()
            h.check(denied.get("code") == "LOCAL_CONTROL_CLASS_DENIED", "current SHUTDOWN authority remains mandatory")
            h.check(daemon.process is not None and daemon.process.poll() is None, "denied request cannot stop process")
        finally:
            client.close()
            restore_owner_only_control(state)
        h.run("offline-audit-denied-final-stop", terminal_args(daemon.control, "offline-audit-owner-stop"), timeout=20)
        wait_stopped(h, daemon, "offline audit denied source stop")

        value = audit(h, "offline-audit-denied-report", state, key, ["--request-id", expected_id])
        check_common(h, value, expected_id)
        h.check(value["outcome"]["classification"] == "DENIED", "denied attempt is distinguished from an accepted stop")
        h.check(value["matches"]["decision_count"] == 1 and value["matches"]["lifecycle_count"] == 0, "denial has no fabricated lifecycle effect")
        h.check(value["matches"]["decisions"][0]["uid"] == DELEGATED_UID and value["matches"]["decisions"][0]["decision"] == "DENIED", "actual connected UID and denial survive replay")

        missing_id = hashlib.sha256(b"offline-audit-missing-id").hexdigest()
        missing = audit(h, "offline-audit-missing-report", state, key, ["--request-id", missing_id])
        check_common(h, missing, missing_id)
        h.check(missing["outcome"]["classification"] == "NOT_FOUND" and missing["limits"]["matched_rows"] == 0, "missing request returns a bounded empty report")

    case("denied_and_missing_request_ids", denied_and_missing_request_ids)

    def exclusive_read_and_corruption_fail_closed() -> None:
        token = "offline-audit-source-05"
        expected_id = request_id(correlated_terminal_shutdown(token))
        root, state, key, _, daemon = setup_keyed(h, "offline-audit-source")
        busy = audit(h, "offline-audit-running-busy", state, key, ["--request-id", expected_id], expected=3)
        h.check(busy["code"] == "STATE_BUSY", "offline command never races a running writer")
        h.run("offline-audit-source-stop", terminal_args(daemon.control, token), timeout=20)
        wait_stopped(h, daemon, "offline audit source")
        good = (state / "state.journal").read_bytes()

        wrong = new_key(h, root, "offline-audit-wrong")
        wrong_result = audit(h, "offline-audit-wrong-key", state, wrong, ["--request-id", expected_id], expected=3)
        h.check(wrong_result["code"] == "STATE_AUTH_TAG_MISMATCH", "wrong key fails before report")
        h.check((state / "state.journal").read_bytes() == good, "wrong-key audit changes no bytes")

        changed = good[:-1] + bytes([good[-1] ^ 1])
        (state / "state.journal").write_bytes(changed)
        corrupt = audit(h, "offline-audit-corrupt-tag", state, key, ["--request-id", expected_id], expected=3)
        h.check(corrupt["code"] == "STATE_AUTH_TAG_MISMATCH", "authenticated corruption fails closed")
        h.check((state / "state.journal").read_bytes() == changed, "corruption is never repaired")

        (state / "state.journal").write_bytes(good[:-1])
        incomplete = audit(h, "offline-audit-incomplete-tail", state, key, ["--request-id", expected_id], expected=3)
        h.check(incomplete["code"] in {"STATE_AUTH_TRUNCATED", "STATE_AUTH_TAG_MISMATCH", "JOURNAL_CORRUPT"}, "incomplete tail is not silently repaired or prefix-adopted")
        h.check((state / "state.journal").read_bytes() == good[:-1], "incomplete source remains byte-exact")
        (state / "state.journal").write_bytes(good)

        missing_key = audit(h, "offline-audit-missing-key", state, None, ["--request-id", expected_id], expected=3)
        h.check(missing_key["code"] == "STATE_AUTH_KEY_REQUIRED", "explicit key remains mandatory")

    case("exclusive_read_and_corruption_fail_closed", exclusive_read_and_corruption_fail_closed)

    def compaction_preserves_offline_selection() -> None:
        token = "offline-audit.compaction-06"
        expected_id = request_id(correlated_terminal_shutdown(token))
        _, state, key, config, daemon = setup_keyed(h, "offline-audit-compaction")
        h.run("offline-audit-compaction-first-stop", terminal_args(daemon.control, token), timeout=20)
        wait_stopped(h, daemon, "offline audit before compaction")
        before = audit(h, "offline-audit-before-compact", state, key, ["--request-id", expected_id])

        daemon = start(h, "offline-audit-compaction-online", config, state, key)
        h.run("offline-audit-compact", ["compact", "--control", str(daemon.control), "--deadline-ms", "5000"], timeout=20)
        h.run("offline-audit-compaction-final-stop", terminal_args(daemon.control, "offline-audit-after-compact"), timeout=20)
        wait_stopped(h, daemon, "offline audit after compaction")
        raw = (state / "state.journal").read_bytes()
        independent_open(raw, key)
        after = audit(h, "offline-audit-after-compact", state, key, ["--request-id", expected_id])
        check_common(h, after, expected_id)
        h.check(
            after["matches"]["decisions"] == before["matches"]["decisions"]
            and after["matches"]["lifecycle"] == before["matches"]["lifecycle"]
            and after["matches"]["decision_count"] == before["matches"]["decision_count"]
            and after["matches"]["lifecycle_count"] == before["matches"]["lifecycle_count"],
            "canonical checkpoint preserves exact selected decision and lifecycle rows",
        )
        h.check(
            after["matches"]["retained_decision_count"] > before["matches"]["retained_decision_count"]
            and after["matches"]["retained_lifecycle_count"] > before["matches"]["retained_lifecycle_count"],
            "report distinguishes selected rows from later retained history",
        )
        h.check(after["state_head"]["selector"] != before["state_head"]["selector"], "audit reports the current representation head rather than the historical stop head")
        h.check(after["outcome"]["classification"] == "ACCEPTED_IMMEDIATE", "historical attempt remains classifiable after maintenance")
        h.check((state / "state.journal").read_bytes() == raw, "post-compaction audit is read-only")

    case("compaction_preserves_offline_selection", compaction_preserves_offline_selection)

    def encrypted_restore_and_relocation_preserve_selection() -> None:
        token = "offline-audit-backup-08"
        expected_id = request_id(correlated_terminal_shutdown(token))
        root, state, key, config, daemon = setup_keyed(h, "offline-audit-backup")
        response = h.run(
            "offline-audit-backup-stop",
            terminal_args(daemon.control, token),
            timeout=20,
        )
        assert response is not None
        wait_stopped(h, daemon, "offline audit backup source")
        source = audit(
            h,
            "offline-audit-backup-source",
            state,
            key,
            ["--request-id", expected_id],
        )
        check_common(h, source, expected_id)

        backup_key = root / "backup.key"
        initialized = h.run(
            "offline-audit-backup-key",
            ["backup-key-init", "--output", str(backup_key), "--generation", "audit-backup-g1"],
        )
        assert initialized is not None
        identity = h.identity("A")
        archive = h.work / "offline-audit-backup.nob"
        exported = h.run(
            "offline-audit-backup-export",
            [
                "backup-export", "--state", str(state), "--node", "A",
                "--generation", "a-g1", "--state-auth-key", str(key),
                "--output", str(archive), "--encrypt-key", str(backup_key),
                "--sign-key", str(identity.private_key),
                "--sign-cert", str(identity.certificate),
            ],
            timeout=30,
        )
        assert exported is not None
        archive_before = archive.read_bytes()
        restored = h.runtime / "offline-audit-backup-restored"
        restored_result = h.run(
            "offline-audit-backup-restore",
            [
                "backup-restore", "--input", str(archive),
                "--destination", str(restored), "--node", "A",
                "--generation", "a-g1", "--state-auth-key", str(key),
                "--decrypt-key", str(backup_key),
                "--trusted-cert", str(identity.certificate),
                "--require-signature", "yes", "--require-encryption", "yes",
            ],
            timeout=30,
        )
        assert restored_result is not None
        restored_audit = audit(
            h,
            "offline-audit-backup-restored-report",
            restored,
            key,
            ["--request-id", expected_id],
        )
        check_common(h, restored_audit, expected_id)
        h.check(
            restored_audit["matches"] == source["matches"],
            "encrypted restore preserves every selected durable row",
        )
        h.check(
            restored_audit["outcome"] == source["outcome"] and
            restored_audit["retained_obligations"] == source["retained_obligations"],
            "encrypted restore preserves stop outcome and obligations",
        )
        h.check(
            restored_audit["state_head"]["selector"] != source["state_head"]["selector"],
            "restore provenance creates a distinct exact representation head",
        )
        h.check(archive.read_bytes() == archive_before, "audit and restore leave encrypted backup bytes unchanged")

        relocated_config = h.work / "offline-audit-backup-relocated.conf"
        text = config.read_text().replace(f"state={state}", f"state={restored}")
        text = text.replace("runtime_generation=offline-audit-backup-g1", "runtime_generation=offline-audit-backup-relocated")
        relocated_config.write_text(text)
        relocated_config.chmod(0o600)
        relocated_result = h.run(
            "offline-audit-backup-relocate",
            [
                "state-relocate", "--state", str(restored), "--node", "A",
                "--state-auth-key", str(key), "--candidate", str(relocated_config),
                "--reason", "offline audit relocated representation",
            ],
            timeout=30,
        )
        assert relocated_result is not None
        relocated_audit = audit(
            h,
            "offline-audit-backup-relocated-report",
            restored,
            key,
            ["--request-id", expected_id],
        )
        check_common(h, relocated_audit, expected_id)
        h.check(
            relocated_audit["matches"] == source["matches"],
            "relocation preserves every selected durable row",
        )
        h.check(
            relocated_audit["outcome"] == source["outcome"] and
            relocated_audit["retained_obligations"] == source["retained_obligations"],
            "relocation preserves stop outcome and obligations",
        )
        h.check(
            relocated_audit["state_head"]["selector"] != restored_audit["state_head"]["selector"],
            "relocation creates another exact representation head",
        )

    case("encrypted_restore_and_relocation_preserve_selection", encrypted_restore_and_relocation_preserve_selection)

    def strict_cli_shapes() -> None:
        token = "offline-audit-cli-07"
        expected_id = request_id(correlated_terminal_shutdown(token))
        _, state, key, _, daemon = setup_keyed(h, "offline-audit-cli")
        h.run("offline-audit-cli-stop", terminal_args(daemon.control, token), timeout=20)
        wait_stopped(h, daemon, "offline audit CLI")
        base = ["correlated-stop-audit", "--state", str(state), "--node", "A", "--state-auth-key", str(key)]
        bad = [
            ("missing-selection", []),
            ("mixed-selection", ["--request-id", expected_id, *shape_immediate(token)]),
            ("shape-missing-final", ["--correlation", token, "--stop", "immediate"]),
            ("bad-stop", ["--correlation", token, "--stop", "other", "--final-state-head", "yes"]),
            ("immediate-drain-fields", [*shape_immediate(token), "--drain-deadline-ms", "10", "--reason", "bad"]),
            ("drain-missing-reason", ["--correlation", token, "--stop", "drain", "--final-state-head", "yes", "--drain-deadline-ms", "10"]),
            ("uppercase-token", shape_immediate("Uppercase")),
            ("zero-request-id", ["--request-id", "0" * 64]),
            ("small-json-limit", ["--request-id", expected_id, "--max-bytes", "4095"]),
            ("large-match-limit", ["--request-id", expected_id, "--max-matches", "65"]),
        ]
        for label, suffix in bad:
            value = h.run("offline-audit-cli-" + label, [*base, *suffix], expected=3)
            h.check(value is not None and value.get("ok") is False, label + " fails closed")
        valid = audit(h, "offline-audit-cli-valid", state, key, shape_immediate(token))
        h.check(valid["selection"]["request_id"] == expected_id, "strict rejection does not impair canonical shape")

    case("strict_cli_shapes", strict_cli_shapes)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append", choices=CASES)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    harness = Harness(args.binary, args.output)
    started = time.time()
    code = 1
    try:
        run_suite(harness, set(args.case) if args.case else None)
        code = 0
    except BaseException as error:
        import traceback
        (harness.output / "FAILURE.txt").write_text(traceback.format_exc())
        print(f"FAIL: {type(error).__name__}: {error}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_CORRELATED_STOP_AUDIT_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(item["status"] == "PASS" for item in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (
            ("SUMMARY.json", summary),
            ("CASES.json", harness.cases),
            ("COMMANDS.json", harness.commands),
        ):
            (harness.output / name).write_text(json.dumps(value, indent=2) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
