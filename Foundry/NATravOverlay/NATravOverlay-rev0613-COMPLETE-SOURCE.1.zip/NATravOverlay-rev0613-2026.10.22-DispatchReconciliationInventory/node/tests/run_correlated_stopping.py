#!/usr/bin/env python3
"""Strict correlated destructive stops bind caller tokens into durable request identity."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import struct
import time
from typing import Any, Callable

from run_persistent import Harness, free_port, operation, raw_control
from run_response_loss_stopping import (
    DELEGATED_UID,
    drop_after_complete_request,
    lifecycle_kinds,
    setup_keyed,
    verify_keyed_state,
    wait_stopped,
)
from run_local_administration import expose_control_for_uid, restore_owner_only_control, v8_config
from run_control_authorization import Client, packet, text
from run_live_configuration import activate, candidate
from run_control_history import history, reference
from run_state_authentication import independent_open, start

CASES = (
    "strict_wire_and_legacy_defaults",
    "immediate_response_loss_exact_identity",
    "completed_drain_response_loss_exact_identity",
    "deadline_drain_response_loss_preserves_obligation",
    "duplicate_tokens_are_not_idempotency",
    "current_policy_revocation",
    "compaction_replay_and_exact_lookup",
)


def request_id(payload: bytes) -> str:
    material = (
        b"NATRAV_OVERLAY_CONTROL_REQUEST_ID_V1\0"
        + struct.pack("!Q", len(payload))
        + payload
    )
    return hashlib.sha256(material).hexdigest()


def correlated_shutdown(token: str) -> bytes:
    return packet(44, text(token))


def correlated_drain(deadline_ms: int, reason: str, token: str) -> bytes:
    return packet(45, struct.pack("!I", deadline_ms), text(reason), text(token))


def lifecycle_for(snapshot: dict[str, Any], expected: str) -> list[dict[str, Any]]:
    return [event for event in snapshot["lifecycle"]["events"] if event["request_id"] == expected]


def decisions_for(snapshot: dict[str, Any], expected: str) -> list[dict[str, Any]]:
    return [event for event in snapshot["local_control"]["entries"] if event["request_id"] == expected]


def run_suite(h: Harness, selected: set[str] | None) -> None:
    def case(name: str, function: Callable[[], None]) -> None:
        if selected is None or name in selected:
            h.case(name, function)

    def strict_wire_and_legacy_defaults() -> None:
        state = h.runtime / "correlated-wire"
        config = v8_config(
            h, "correlated-wire", "A", state, free_port(), "correlated-wire-g1",
            [(os.geteuid(), ["ALL"])],
        )
        daemon = h.start("correlated-wire", config, state)
        invalid = [
            ("empty", correlated_shutdown("")),
            ("uppercase", correlated_shutdown("Upper")),
            ("leading-punctuation", correlated_shutdown(".leading")),
            ("trailing-punctuation", correlated_shutdown("trailing-")),
            ("slash", correlated_shutdown("bad/path")),
            ("non-ascii", packet(44, struct.pack("!H", 2), b"\xc3\xa9")),
            ("too-long", correlated_shutdown("a" * 65)),
            ("trailing-byte", correlated_shutdown("valid-token") + b"x"),
            ("truncated-immediate", correlated_shutdown("valid-token")[:-1]),
            ("missing-drain-token", packet(45, struct.pack("!I", 100), text("missing token"))),
            ("truncated-drain-token", correlated_drain(100, "truncated", "valid-token")[:-1]),
        ]
        for label, payload in invalid:
            ok, result = raw_control(daemon.control, payload)
            h.check(not ok and result.get("ok") is False and bool(result.get("code")), label + " fails strict decoding")
            h.check(daemon.process is not None and daemon.process.poll() is None, label + " cannot create stop intent")
        # Correlated terminal handoff is exercised by its dedicated suite.  The
        # ordinary correlated protocol in this suite remains kinds 44/45.
        h.check(h.status("wire-still-running", state, logical_digest=False)["lifecycle"]["mode"] == "RUNNING", "invalid opt-in requests leave service running")

        ordinary_payload = packet(4)
        response = h.run(
            "ordinary-default-shutdown",
            ["shutdown", "--control", str(daemon.control), "--deadline-ms", "2000"],
        )
        h.check(response and response["format"] == "NATRAV_OVERLAY_CONTROL_SHUTDOWN_V2", "legacy success JSON remains unchanged")
        h.check("correlation_token" not in response, "ordinary response gains no token field")
        ordinary_id = request_id(ordinary_payload)
        h.check(response["request_id"] == ordinary_id, "legacy request identity remains byte-derived")
        wait_stopped(h, daemon, "ordinary default shutdown")

        daemon = h.start("correlated-wire-repeat", config, state)
        repeated = h.run(
            "ordinary-repeated-shutdown",
            ["shutdown", "--control", str(daemon.control), "--deadline-ms", "2000"],
        )
        h.check(repeated and repeated["request_id"] == ordinary_id, "byte-identical ordinary attempts retain the same ambiguous identity")
        wait_stopped(h, daemon, "repeated ordinary default shutdown")
        daemon = h.start("correlated-wire-history", config, state)
        ordinary_rows = history(h, "ordinary-identical-history", state, section="lifecycle", request=ordinary_id)
        h.check(ordinary_rows["selected_total"] == 2 and [row["kind"] for row in ordinary_rows["rows"]] == ["SHUTDOWN_REQUESTED", "SHUTDOWN_REQUESTED"], "ordinary repeated attempts demonstrate the ambiguity correlation addresses")
        daemon.shutdown()

        drain_state = h.runtime / "correlated-wire-drain"
        drain_config = v8_config(
            h, "correlated-wire-drain", "D", drain_state, free_port(),
            "correlated-wire-drain-g1", [(os.geteuid(), ["ALL"])],
        )
        drain_daemon = h.start("correlated-wire-drain", drain_config, drain_state)
        maximum_token = "a" + "b" * 62 + "9"
        reason = "successful correlated drain"
        drain_payload = correlated_drain(500, reason, maximum_token)
        drain_response = h.run(
            "successful-correlated-drain",
            [
                "drain-shutdown", "--control", str(drain_daemon.control),
                "--reason", reason, "--drain-deadline-ms", "500",
                "--correlation", maximum_token, "--deadline-ms", "2000",
            ],
        )
        h.check(drain_response and drain_response["format"] == "NATRAV_OVERLAY_CONTROL_CORRELATED_DRAIN_SHUTDOWN_V1", "correlated drain success JSON is explicitly versioned")
        h.check(drain_response["completed"] is True and drain_response["correlation_token"] == maximum_token, "maximum canonical token survives exact successful response")
        h.check(drain_response["request_id"] == request_id(drain_payload), "correlated drain response carries independently derived identity")
        wait_stopped(h, drain_daemon, "successful correlated drain")

    case("strict_wire_and_legacy_defaults", strict_wire_and_legacy_defaults)

    def immediate_response_loss_exact_identity() -> None:
        token = "ops-20261012-immediate-01"
        payload = correlated_shutdown(token)
        expected = request_id(payload)
        _, state, key, config, daemon = setup_keyed(
            h,
            "correlated-lost-immediate",
            environment={
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_COMMAND": "SHUTDOWN_CORRELATED",
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_PAUSE_MS": "350",
            },
        )
        drop_after_complete_request(daemon.control, payload)
        wait_stopped(h, daemon, "correlated immediate response loss")
        snapshot, raw = verify_keyed_state(h, "correlated-immediate-offline", state, key)
        rows = lifecycle_for(snapshot, expected)
        decisions = decisions_for(snapshot, expected)
        h.check(len(rows) == 1 and rows[0]["kind"] == "SHUTDOWN_REQUESTED", "exact derived identity reaches lifecycle provenance")
        h.check(len(decisions) == 1 and decisions[0]["command"] == "SHUTDOWN_CORRELATED", "authorization account distinguishes opt-in command")
        h.check(token.encode() not in raw, "token is committed by digest rather than copied into durable history")
        _, plain_frames, _, _ = independent_open(raw, key)
        independently = reference(b"".join(plain_frames))["lifecycle"]
        h.check(any(row["request_id"] == expected and row["kind"] == "SHUTDOWN_REQUESTED" for row in independently), "independent raw-journal decoder reconstructs exact request identity")

        restarted = start(h, "correlated-immediate-lookup", config, state, key)
        selected = history(h, "correlated-immediate-exact-lookup", state, section="lifecycle", request=expected)
        h.check(selected["selected_total"] == 1 and selected["rows"][0]["request_id"] == expected, "bounded exact history lookup selects the lost-response attempt")
        restarted.shutdown()

    case("immediate_response_loss_exact_identity", immediate_response_loss_exact_identity)

    def completed_drain_response_loss_exact_identity() -> None:
        reason = "correlated completed drain"
        token = "ops-20261012-completed-01"
        payload = correlated_drain(500, reason, token)
        expected = request_id(payload)
        _, state, key, _, daemon = setup_keyed(
            h,
            "correlated-lost-completed",
            environment={
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_COMMAND": "DRAIN_SHUTDOWN_CORRELATED",
                "NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_PAUSE_MS": "350",
            },
        )
        drop_after_complete_request(daemon.control, payload)
        wait_stopped(h, daemon, "correlated completed drain response loss")
        snapshot, raw = verify_keyed_state(h, "correlated-completed-offline", state, key)
        rows = lifecycle_for(snapshot, expected)
        h.check([row["kind"] for row in rows] == ["DRAIN_STARTED", "DRAIN_COMPLETED"], "both drain boundaries carry one exact correlated request identity")
        h.check(all(row["deadline_ms"] == 500 for row in rows), "deadline remains part of exact request consequence")
        h.check(snapshot["outbox"]["pending"] == 0 and snapshot["actions"]["pending"] == 0, "completed correlated drain invents no obligation")
        h.check(token.encode() not in raw, "drain token is not disclosed as lifecycle reason text")

    case("completed_drain_response_loss_exact_identity", completed_drain_response_loss_exact_identity)

    def deadline_drain_response_loss_preserves_obligation() -> None:
        unavailable = free_port()
        reason = "correlated pending outbound deadline"
        token = "ops-20261012-deadline-01"
        payload = correlated_drain(150, reason, token)
        expected = request_id(payload)
        _, state, key, _, daemon = setup_keyed(
            h,
            "correlated-lost-deadline",
            peers=[("B", unavailable)],
            environment={"NATRAV_OVERLAY_TEST_DRAIN_AFTER_START_MS": "300"},
        )
        h.run(
            "correlated-deadline-submit",
            [
                "submit", "--control", str(daemon.control), "--node", "A", "--peer", "B",
                "--scope", "admin/test", "--operation", operation("correlated-pending-outbound"),
                "--payload-text", "preserve correlated obligation", "--deadline-ms", "2000",
            ],
        )
        drop_after_complete_request(daemon.control, payload)
        h.wait(
            "correlated drain publishes draining",
            lambda: h.status("correlated-draining", state, logical_digest=False)["lifecycle"]["mode"] == "DRAINING",
            4.0,
        )
        competing = h.run(
            "correlated-competing-quiesce",
            ["quiesce", "--control", str(daemon.control), "--reason", "cannot replace correlated drain"],
            expected=3,
        )
        h.check(competing and competing.get("code") == "SERVICE_DRAINING", "competing lifecycle request cannot cancel correlated stop")
        wait_stopped(h, daemon, "correlated deadline response loss")
        snapshot, _ = verify_keyed_state(h, "correlated-deadline-offline", state, key)
        rows = lifecycle_for(snapshot, expected)
        h.check([row["kind"] for row in rows] == ["DRAIN_STARTED", "DRAIN_DEADLINE"], "deadline result retains exact correlated identity")
        h.check(rows[-1]["pending_outbound"] == 1 and snapshot["outbox"]["pending"] == 1, "response loss and correlation preserve pending delivery")

    case("deadline_drain_response_loss_preserves_obligation", deadline_drain_response_loss_preserves_obligation)

    def duplicate_tokens_are_not_idempotency() -> None:
        token = "duplicate-attempt"
        other = "distinct-attempt"
        payload = correlated_shutdown(token)
        expected = request_id(payload)
        _, state, key, config, daemon = setup_keyed(h, "correlated-duplicates")

        first = h.run(
            "correlated-first-token",
            ["shutdown", "--control", str(daemon.control), "--correlation", token, "--deadline-ms", "2000"],
        )
        h.check(first and first["format"] == "NATRAV_OVERLAY_CONTROL_CORRELATED_SHUTDOWN_V1", "correlated response is explicitly versioned")
        h.check(first["correlation_token"] == token and first["request_id"] == expected, "response echoes exact token and derived identity")
        h.check(first["correlation_semantics"] == "PROVENANCE_ONLY_NOT_IDEMPOTENCY_OR_RECEIPT", "response labels narrow semantics")
        wait_stopped(h, daemon, "first duplicate-token stop")

        daemon = start(h, "correlated-duplicates-second", config, state, key)
        second = h.run(
            "correlated-second-token",
            ["shutdown", "--control", str(daemon.control), "--correlation", token, "--deadline-ms", "2000"],
        )
        h.check(second and second["request_id"] == expected, "same exact request bytes yield same request identity")
        wait_stopped(h, daemon, "second duplicate-token stop")

        daemon = start(h, "correlated-duplicates-third", config, state, key)
        third = h.run(
            "correlated-distinct-token",
            ["shutdown", "--control", str(daemon.control), "--correlation", other, "--deadline-ms", "2000"],
        )
        other_expected = request_id(correlated_shutdown(other))
        h.check(third and third["request_id"] == other_expected and other_expected != expected, "distinct token changes exact request identity")
        wait_stopped(h, daemon, "distinct-token stop")

        daemon = start(h, "correlated-duplicates-lookup", config, state, key)
        life = history(h, "correlated-duplicate-lifecycle", state, section="lifecycle", request=expected)
        decisions = history(h, "correlated-duplicate-decisions", state, request=expected)
        h.check(life["selected_total"] == 2 and [row["kind"] for row in life["rows"]] == ["SHUTDOWN_REQUESTED", "SHUTDOWN_REQUESTED"], "duplicate token does not suppress independently authorized lifecycle rows")
        h.check(decisions["selected_total"] == 2 and all(row["command"] == "SHUTDOWN_CORRELATED" for row in decisions["rows"]), "duplicate token does not suppress authorization decisions")
        daemon.shutdown()

    case("duplicate_tokens_are_not_idempotency", duplicate_tokens_are_not_idempotency)

    def current_policy_revocation() -> None:
        state = h.runtime / "correlated-revocation"
        config = v8_config(
            h,
            "correlated-revocation",
            "A",
            state,
            free_port(),
            "correlated-revocation-g1",
            [(os.geteuid(), ["ALL"]), (DELEGATED_UID, ["SHUTDOWN"])],
        )
        daemon = h.start(
            "correlated-revocation",
            config,
            state,
            {"NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER": "1"},
        )
        expose_control_for_uid(state)
        payload = correlated_shutdown("delegated-revoked")
        expected = request_id(payload)
        client = Client(h, daemon, "correlated-revoked-partial", payload, uid=DELEGATED_UID, split=True)
        try:
            replacement = candidate(
                h,
                config,
                "correlated-revoked-candidate",
                "correlated-revocation-g2",
                lambda raw: "\n".join(
                    f"local_control={DELEGATED_UID},INSPECT" if line.startswith(f"local_control={DELEGATED_UID},") else line
                    for line in raw.splitlines()
                ) + "\n",
            )
            activate(h, "correlated-revoke-before-decode", state, replacement)
            denied = client.finish()
            h.check(denied.get("code") == "LOCAL_CONTROL_CLASS_DENIED" and denied["request_id"] == expected, "post-decode current policy denies exact correlated request")
            h.check(daemon.process is not None and daemon.process.poll() is None, "denied token cannot become stop intent")
            status = h.status("correlated-revoked-running", state, logical_digest=False)
            h.check(status["lifecycle"]["mode"] == "RUNNING", "revocation leaves lifecycle running")
        finally:
            client.close()
        restore_owner_only_control(state)
        daemon.shutdown()

    case("current_policy_revocation", current_policy_revocation)

    def compaction_replay_and_exact_lookup() -> None:
        token = "compact.window_7"
        expected = request_id(correlated_shutdown(token))
        _, state, key, config, daemon = setup_keyed(h, "correlated-compaction")
        response = h.run(
            "correlated-before-compaction",
            ["shutdown", "--control", str(daemon.control), "--correlation", token, "--deadline-ms", "2000"],
        )
        h.check(response and response["request_id"] == expected, "pre-compaction response identity independently predicted")
        wait_stopped(h, daemon, "pre-compaction correlated stop")

        daemon = start(h, "correlated-compaction-online", config, state, key)
        before = history(h, "correlated-before-compact-lookup", state, section="lifecycle", request=expected)
        h.run("correlated-compact", ["compact", "--control", str(daemon.control), "--deadline-ms", "5000"])
        after = history(h, "correlated-after-compact-lookup", state, section="lifecycle", request=expected)
        h.check(after["rows"] == before["rows"] and after["selected_total"] == 1, "compaction reconstructs exact correlated lifecycle lookup")
        daemon.shutdown()
        snapshot, raw = verify_keyed_state(h, "correlated-compaction-offline", state, key)
        h.check(len(lifecycle_for(snapshot, expected)) == 1, "complete keyed replay retains correlated identity")
        _, plain_frames, root, _ = independent_open(raw, key)
        h.check(root.hex() == snapshot["storage"]["state_authentication"]["root"], "independent authentication reaches the replayed compacted head")
        h.check(b"".join(plain_frames).count(bytes.fromhex(expected)) >= 2, "compacted canonical bytes retain decision and lifecycle request identity")

    case("compaction_replay_and_exact_lookup", compaction_replay_and_exact_lookup)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append", choices=CASES)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    harness = Harness(args.binary, args.output)
    started = time.time()
    code = 1
    try:
        run_suite(harness, set(args.case) if args.case else None)
        code = 0
    except BaseException as error:
        import traceback
        (harness.output / "FAILURE.txt").write_text(traceback.format_exc())
        print(f"FAIL: {type(error).__name__}: {error}", file=os.sys.stderr)
    finally:
        harness.cleanup()
        summary = {
            "format": "NATRAV_OVERLAY_CORRELATED_STOPPING_TESTS_V1",
            "status": "PASS" if code == 0 else "FAIL",
            "binary_sha256": hashlib.sha256(harness.binary.read_bytes()).hexdigest(),
            "cases_passed": sum(item["status"] == "PASS" for item in harness.cases),
            "cases_total": len(harness.cases),
            "assertions": harness.assertions,
            "commands": len(harness.commands),
            "elapsed_seconds": time.time() - started,
        }
        for name, value in (
            ("SUMMARY.json", summary),
            ("CASES.json", harness.cases),
            ("COMMANDS.json", harness.commands),
        ):
            (harness.output / name).write_text(json.dumps(value, indent=2) + "\n")
        print(json.dumps(summary))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
