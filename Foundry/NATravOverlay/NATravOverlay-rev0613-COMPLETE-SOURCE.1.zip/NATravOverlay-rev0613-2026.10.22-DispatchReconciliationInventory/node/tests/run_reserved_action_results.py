#!/usr/bin/env python3
"""Future result capacity and conditional terminal conversion against real C++ nodes."""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, shutil, struct, subprocess, time
from pathlib import Path
from run_persistent import Harness, free_port, operation, raw_control
from run_action_results import config, submit_action, wait_action, action_query, wait_outbox, evidence_query, decode_nac1, RESULT_SCOPE
from run_conditional_action import selected, conditional, cancel_args, packet, journal_frames, frame
from run_live_configuration import candidate, activate
from run_state_authentication import new_key, migrate, start as start_keyed, inspect


def pair(h: Harness, name: str, *, records=4, payload=16384, disabled=True, environment=None):
    root=h.runtime/name; root.mkdir()
    ap,bp=free_port(),free_port()
    while bp==ap: bp=free_port()
    ac=config(h,name+'-a','A',root/'a',ap,'B',bp,receive_action=False,allow_result=False,read_results=True)
    bc=config(h,name+'-b','B',root/'b',bp,'A',ap,receive_action=True,allow_result=True)
    text=bc.read_text().replace('outbox_global_max_records=256',f'outbox_global_max_records={records}').replace('outbox_peer_max_records=128',f'outbox_peer_max_records={records}')
    text=text.replace('outbox_global_max_payload_bytes=16777216',f'outbox_global_max_payload_bytes={payload}').replace('outbox_peer_max_payload_bytes=8388608',f'outbox_peer_max_payload_bytes={payload}')
    text=text.replace('action_max_defer_ms=30000','action_max_defer_ms=600000').replace('action_expiry_ms=60000','action_expiry_ms=1200000')
    if disabled:text=text.replace('primary,0,ENABLED','primary,0,DISABLED')
    bc.write_text(text);bc.chmod(0o600)
    a=h.start(name+'-a',ac,root/'a');b=h.start(name+'-b',bc,root/'b',environment=environment)
    return root,ac,bc,a,b


def usage(h: Harness,label: str,state: Path):
    value=h.status(label,state,logical_digest=False)
    q=value['outbox']['reservations']
    h.check(q['committed_records']==q['pending_records']+q['future_result_records'],'combined record account')
    h.check(q['committed_payload_bytes']==q['pending_payload_bytes']+q['future_result_payload_bytes'],'combined payload account')
    return q


def ordinary(h,label,state,id,payload='',expected=0):
    return h.run(label,['submit','--control',str(state/'control.sock'),'--node','B','--peer','A','--scope','test/ordinary','--operation',id,'--payload-text',payload,'--deadline-ms','5000'],expected=expected)


def pending(h,label,state,id):return wait_action(h,label,state,id,'PENDING')


def run_cases(h: Harness, only: set[str]|None):
    def case(name,fn):
        if only is None or name in only:h.case(name,fn)

    def reservation_and_conversion():
        root,ac,bc,a,b=pair(h,'conversion',records=2)
        id=operation('reserved-conversion');submit_action(h,'source',root/'a',id,13,600000)
        r=pending(h,'reserved',root/'b',id); reserve=379+len(RESULT_SCOPE)+len('a-g1')
        h.check(r['action_result']['reserved_payload_bytes']==reserve and r['action_result']['capacity_state']=='RESERVED','exact independent NAC1 upper bound')
        q=usage(h,'one-future',root/'b');h.check(q['future_result_records']==1 and q['future_result_payload_bytes']==reserve and q['pending_records']==0,'reservation is not a fabricated outbox record')
        h.check(q['committed_records']==1,'one future commitment')
        submit_action(h,'source-duplicate',root/'a',id,13,600000)
        h.check(usage(h,'still-one',root/'b')['future_result_records']==1,'duplicate admission does not reserve twice')
        blocker=operation('ordinary-zero');ordinary(h,'zero-byte',root/'b',blocker)
        q=usage(h,'full',root/'b');h.check(q['committed_records']==2 and q['pending_payload_bytes']==0,'zero-byte ordinary work consumes a record beside future capacity')
        denied=ordinary(h,'no-third-record',root/'b',operation('excess'),expected=3)
        h.check(denied['code']=='OUTBOX_GLOBAL_RECORD_LIMIT','future capacity excludes unrelated admission')
        row,cfg=selected(h,'select-result-action',root/'b',id)
        wrong=json.loads(json.dumps(row));wrong['condition']['state_digest']='03'*32
        h.check(conditional(h,'wrong-reserved-state',root/'b',wrong,cfg,'conditional result',3)['code']=='ACTION_STATE_CONFLICT','selected binding and reservation cannot be substituted')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            replies=list(pool.map(lambda _:raw_control(root/'b'/'control.sock',packet(row,cfg,'conditional result')),range(8)))
        h.check(all(ok for ok,_ in replies),'concurrent conditional conversion replies')
        states=[v['status'] for _,v in replies]
        h.check(states.count('APPLIED')==1 and states.count('ALREADY_APPLIED')==7,'one compound commit and seven receipt confirmations')
        accepted=next(v for _,v in replies if v['status']=='APPLIED')
        result=accepted['observation']['action_result']['operation_id']
        actual=action_query(h,'after-cancel',root/'b',id)
        h.check(actual['status']=='CANCELLED' and actual['condition']['retained_actions']==1 and actual['action_result']['capacity_state']=='CONVERTED','conditional receipt, cancellation and conversion are visible together')
        q=usage(h,'converted',root/'b');h.check(q['future_result_records']==0 and q['pending_records']==2 and q['pending_payload_bytes']<reserve,'exact conversion releases only deterministic unused bytes')
        cancelled_bytes=q['pending_payload_bytes']
        b.shutdown();b=h.start('conversion-restart',bc,root/'b')
        again=conditional(h,'retry-after-restart',root/'b',row,cfg,'conditional result')
        h.check(again['status']=='ALREADY_APPLIED' and again['accepted_action']==accepted['accepted_action'],'compound administrative receipt survives restart')
        h.run('compact-compound',['compact','--control',str(root/'b'/'control.sock'),'--deadline-ms','5000'])
        b.shutdown();b=h.start('conversion-compacted',bc,root/'b')
        h.check(usage(h,'compacted-use',root/'b')['pending_payload_bytes']==cancelled_bytes,'checkpoint reconstructs exact combined account')
        # Unrelated cancellation cannot erase the result operation.
        h.run('cancel-zero',['cancel','--control',str(root/'b'/'control.sock'),'--operation',blocker,'--reason','release unrelated work'])
        enabled=candidate(h,bc,'conversion-enabled','conversion-g2',lambda t:t.replace('primary,0,DISABLED','primary,0,ENABLED'))
        activate(h,'enable-return',root/'b',enabled)
        wait_outbox(h,'result-received',root/'b',result,'ACKED')
        payload=bytes.fromhex(evidence_query(h,'recipient-result',root/'a',result)['payload_hex'])
        decoded=decode_nac1(payload)
        h.check(len(payload)==cancelled_bytes and decoded['outcome']==2 and decoded['counter_after'] is None,'recipient sees cancelled result, not a counter effect')
        h.check(usage(h,'receipt-release',root/'b')['committed_records']==0,'receipt releases ordinary result capacity without resurrecting future reservation')
        (h.output/'CONVERSION.json').write_text(json.dumps({'reservation_bytes':reserve,'cancelled_result_bytes':len(payload),'outcomes':states,'receipt':accepted,'decoded':decoded},indent=2)+'\n')
        b.shutdown();a.shutdown()
    case('reserved_conversion_and_conditional_concurrency',reservation_and_conversion)

    def byte_admission():
        bound=379+len(RESULT_SCOPE)+len('a-g1')
        root,ac,bc,a,b=pair(h,'bytes',records=4,payload=bound)
        blocker=operation('one-byte-blocker');ordinary(h,'one-byte-blocker',root/'b',blocker,'x')
        id=operation('capacity-before-admission');submit_action(h,'insufficient-byte-source',root/'a',id,7,600000)
        time.sleep(.4)
        observed=h.run('not-admitted',['action-query','--control',str(root/'b'/'control.sock'),'--action',id])
        h.check(observed['records']==[],'insufficient future bytes fail before action admission')
        h.check(usage(h,'no-reservation-on-failure',root/'b')['future_result_records']==0,'failed admission reserves nothing')
        h.run('free-one-byte',['cancel','--control',str(root/'b'/'control.sock'),'--operation',blocker,'--reason','admit within boundary'])
        r=pending(h,'exact-byte-admission',root/'b',id)
        h.check(r['attempts']==0,'counter action never began during refused admission')
        q=usage(h,'byte-full',root/'b');h.check(q['committed_payload_bytes']==bound,'exact byte boundary accepted')
        denied=ordinary(h,'byte-overflow',root/'b',operation('blocked-byte'),'x',3)
        h.check(denied['code']=='OUTBOX_GLOBAL_PAYLOAD_LIMIT','ordinary enqueue respects future payload capacity')
        ordinary(h,'zero-after-future',root/'b',operation('zero-after-future'))
        lower=candidate(h,bc,'below-future','below-future-g2',lambda t:t.replace(f'outbox_global_max_payload_bytes={bound}',f'outbox_global_max_payload_bytes={bound-1}').replace(f'outbox_peer_max_payload_bytes={bound}',f'outbox_peer_max_payload_bytes={bound-1}'))
        response=h.run('refuse-lower-limit',['config-activate','--control',str(root/'b'/'control.sock'),'--candidate',str(lower),'--reason','below reserved allowance','--deadline-ms','5000'],expected=3)
        h.check(response['code']=='CONFIG_OUTBOX_BELOW_USAGE','live quota reduction includes future results')
        before=usage(h,'before-plain-cancel',root/'b')
        h.run('plain-cancel-result',['action-cancel','--control',str(root/'b'/'control.sock'),'--action',id,'--reason','ordinary terminal conversion'])
        after=usage(h,'after-plain-cancel',root/'b')
        h.check(before['committed_records']==after['committed_records'] and after['future_result_records']==0,'ordinary cancellation converts reservation too')
        b.shutdown();a.shutdown()
    case('exact_byte_capacity_and_admission_refusal',byte_admission)

    def execution_full():
        root,ac,bc,a,b=pair(h,'execute',records=2)
        id=operation('full-queue-execution');submit_action(h,'delayed-execute',root/'a',id,19,800)
        pending(h,'execution-reserved',root/'b',id)
        ordinary(h,'fill-after-action',root/'b',operation('execute-blocker'),'q')
        h.check(usage(h,'execution-full',root/'b')['committed_records']==2,'ordinary queue fully committed after reserved admission')
        done=wait_action(h,'executed-with-full-queue',root/'b',id,'EXECUTED')
        q=usage(h,'execution-converted',root/'b')
        h.check(done['attempts']==1 and done['result']['counter_after']==19 and q['future_result_records']==0 and q['pending_records']==2,'reserved execution succeeds without releasing unrelated work or extra attempts')
        result=done['action_result']['operation_id'];out=wait_outbox(h,'executed-result-pending',root/'b',result,'PENDING')
        h.check(out['payload_bytes']==done['action_result']['reserved_payload_bytes'],'executed NAC1 exactly fills reserved upper bound')
        b.shutdown();a.shutdown()
    case('execution_with_all_queue_slots_committed',execution_full)

    def kills():
        for when in ('BEFORE_COMMIT','AFTER_COMMIT'):
            name='kill-'+when.lower();env={f'NATRAV_OVERLAY_TEST_ACTION_CONDITION_{when}_MS':'3000'}
            root,ac,bc,a,b=pair(h,name,records=1,environment=env)
            id=operation(name);submit_action(h,name+'-source',root/'a',id,5,600000)
            pending(h,name+'-pending',root/'b',id);row,cfg=selected(h,name+'-selected',root/'b',id)
            args=cancel_args(root/'b',row,cfg,'atomic reserved cancellation')
            proc=subprocess.Popen([str(h.binary),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            h.wait(name+'-boundary',lambda:when in b.stderr_path.read_text(),timeout=8)
            b.kill();stdout,stderr=proc.communicate(timeout=8)
            h.check(proc.returncode!=0,'killed response is not success')
            b=h.start(name+'-restarted',bc,root/'b')
            q=usage(h,name+'-use',root/'b');r=action_query(h,name+'-action',root/'b',id)
            before=when=='BEFORE_COMMIT'
            h.check(q['future_result_records']==int(before) and q['pending_records']==int(not before),'kill reconstructs old reservation or converted outbox atomically')
            h.check(r['status']==('PENDING' if before else 'CANCELLED'),'kill reconstructs matching terminal state')
            repeated=conditional(h,name+'-retry',root/'b',row,cfg,'atomic reserved cancellation')
            h.check(repeated['status']==('APPLIED' if before else 'ALREADY_APPLIED'),'lost reply cannot multiply terminal result')
            b.shutdown();a.shutdown()
    case('hard_kill_both_sides_of_conditional_conversion',kills)

    def maintenance():
        root,ac,bc,a,b=pair(h,'maintenance',records=3)
        first=operation('maintenance-cancel');second=operation('maintenance-pending')
        for name,id in [('first',first),('second',second)]:
            submit_action(h,name,root/'a',id,4,600000);pending(h,name+'-ready',root/'b',id)
        row,cfg=selected(h,'maintenance-selected',root/'b',first)
        accepted=conditional(h,'maintenance-cancel',root/'b',row,cfg,'preserve reserved result')
        b.shutdown();key=new_key(h,h.work,'reserved-state');migrate(h,'reserved-migrate',root/'b',key,node='B')
        b=start_keyed(h,'reserved-keyed',bc,root/'b',key)
        # New keyed AAT2 record plus one remaining future reservation.
        third=operation('maintenance-third');submit_action(h,'third',root/'a',third,3,600000);pending(h,'third-ready',root/'b',third)
        rr,cc=selected(h,'third-select',root/'b',third);conditional(h,'third-cancel',root/'b',rr,cc,'keyed conversion')
        h.run('reserved-compact',['compact','--control',str(root/'b'/'control.sock'),'--deadline-ms','5000'])
        b.shutdown();audit=h.run('reserved-audit',['state-auth-audit','--state',str(root/'b'),'--node','B','--state-auth-key',str(key)])
        before=inspect(h,'reserved-before-backup',root/'b',key,node='B')
        crypt=h.work/'reserved-archive.key';h.run('archive-key',['backup-key-init','--output',str(crypt),'--generation','reserved-archive'])
        ident=h.identity('B');archive=h.work/'reserved.nob'
        h.run('reserved-export',['backup-export','--state',str(root/'b'),'--node','B','--generation','b-g1','--state-auth-key',str(key),'--output',str(archive),'--encrypt-key',str(crypt),'--sign-key',str(ident.private_key),'--sign-cert',str(ident.certificate)])
        restored=h.runtime/'reserved-restored';h.run('reserved-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','B','--generation','b-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(ident.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'reserved-after-restore',restored,key,node='B')
        h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'restore preserves reservation and compound receipt logical state exactly')
        h.check(after['outbox']['reservations']['future_result_records']==1 and after['outbox']['pending']==2,'restored future and actual obligations remain distinct')
        moved=candidate(h,bc,'reserved-moved','reserved-moved-g2',lambda t:t.replace('state='+str(root/'b'),'state='+str(restored)))
        h.run('reserved-relocate',['state-relocate','--state',str(restored),'--node','B','--candidate',str(moved),'--reason','relocate reserved state','--state-auth-key',str(key)])
        b=start_keyed(h,'reserved-restored-daemon',moved,restored,key)
        again=conditional(h,'reserved-old-retry',restored,row,cfg,'preserve reserved result')
        h.check(again['status']=='ALREADY_APPLIED' and again['accepted_action']==accepted['accepted_action'],'original admin and result receipt survive relocation')
        h.run('remaining-conversion',['action-cancel','--control',str(restored/'control.sock'),'--action',second,'--reason','consume retained reservation'])
        q=usage(h,'restored-all-converted',restored);h.check(q['future_result_records']==0 and q['pending_records']==3,'all reserved slots convert under full restored quota')
        (h.output/'MAINTENANCE.json').write_text(json.dumps({'audit':audit,'before':before['storage']['logical_state_digest'],'after':after['storage']['logical_state_digest'],'restored':q,'duplicate':again},indent=2)+'\n')
        b.shutdown();a.shutdown()
    case('keyed_audit_compaction_backup_relocation_and_pending_conversion',maintenance)

    def corruption():
        root,ac,bc,a,b=pair(h,'corruption',records=2)
        id=operation('corrupt-reservation');submit_action(h,'corrupt-source',root/'a',id,7,600000);r=pending(h,'corrupt-pending',root/'b',id)
        row,cfg=selected(h,'corrupt-select',root/'b',id);conditional(h,'corrupt-cancel',root/'b',row,cfg,'reserved-checksum-target');b.shutdown()
        path=root/'b'/'state.journal';original=path.read_bytes();frames=journal_frames(original)
        start,end,body=next(x for x in frames if x[2][0]==36)
        h.check(body[1:5]==b'AAT2','compound cancellation uses strict new wrapper')
        n=struct.unpack_from('!I',body,5)[0];detached=b'\x24'+body[9:9+n]
        path.write_bytes(original[:start]+frame(detached)+original[end:])
        bad=inspect(h,'detached-result',root/'b',expected=3,node='B')
        h.check(bad['code']=='JOURNAL_CORRUPT','administration without its exact result is rejected after checksum recomputation')
        path.write_bytes(original)
        # Alter the explicit fixed-width capacity field in the admission.
        s,e,body=next(x for x in frames if x[2][0]==23 and b'\x0b'==x[2][9:10] and b'NOA1' in x[2])
        raw=bytearray(body);reserve=r['action_result']['reserved_payload_bytes'];offset=raw.index(struct.pack('!Q',reserve))
        raw[offset:offset+8]=struct.pack('!Q',reserve-1)
        path.write_bytes(original[:s]+frame(bytes(raw))+original[e:])
        bad=inspect(h,'forged-reservation',root/'b',expected=3,node='B')
        h.check(bad['code']=='JOURNAL_CORRUPT','undersized reservation is not accepted as a budget policy')
        path.write_bytes(original);b=h.start('corrupt-restored',bc,root/'b')
        h.run('corrupt-compact',['compact','--control',str(root/'b'/'control.sock'),'--deadline-ms','5000']);b.shutdown()
        checkpoint=path.read_bytes();body=bytearray(journal_frames(checkpoint)[0][2]);pos=body.index(b'NRA2');needle=struct.pack('!Q',reserve);off=body.index(needle,pos);body[off:off+8]=struct.pack('!Q',reserve-1)
        logical=body.index(b'NLS2');body[logical-48:logical-16]=hashlib.sha256(b'NATRAV_OVERLAY_LOGICAL_STATE_V2\0'+bytes(body[logical:])).digest()
        path.write_bytes(frame(bytes(body)));bad=inspect(h,'forged-checkpoint-reservation',root/'b',expected=3,node='B')
        h.check(bad['code']=='JOURNAL_CORRUPT','checkpoint rederives capacity rather than trusting serialized totals')
        path.write_bytes(checkpoint);a.shutdown()
    case('semantic_corruption_and_detached_result_rejection',corruption)

    def key_binding():
        root,ac,bc,a,b=pair(h,'key-binding',records=4)
        # Per-recipient limit remains independent of global capacity.
        other=h.identity('C');cp=free_port()
        limits=candidate(h,bc,'key-limits','key-limits-g2',lambda t:
            t.replace('outbox_peer_max_records=4','outbox_peer_max_records=1')+
            f'peer=C,50,250,50,120000\npeer_route=C,primary,0,DISABLED,127.0.0.1:{cp}\npeer_key=C,c-g1,ACTIVE,{other.spki_sha256}\n')
        activate(h,'peer-limit',root/'b',limits)
        id=operation('immutable-result-key');submit_action(h,'key-source',root/'a',id,2,600000);pending(h,'key-pending',root/'b',id)
        denied=ordinary(h,'peer-full-not-global',root/'b',operation('peer-too-full'),'x',3)
        h.check(denied['code']=='OUTBOX_PEER_RECORD_LIMIT','recipient reservation blocks only its peer bucket')
        h.run('other-peer-progress',['submit','--control',str(root/'b'/'control.sock'),'--node','B','--peer','C','--scope','test/other','--operation',operation('other-peer'),'--payload-text','x'])
        row,oldcfg=selected(h,'before-key-change',root/'b',id)
        new=h.identity('A2')
        rotated=candidate(h,limits,'key-rotated','key-rotated-g3',lambda t:t.replace('peer_key=A,a-g1,ACTIVE,','peer_key=A,a-g1,RETIRED,').replace('action_result=A,a-g1,','action_result=A,a-g2,')+f'peer_key=A,a-g2,ACTIVE,{new.spki_sha256}\n')
        activate(h,'rotate-result-recipient',root/'b',rotated)
        h.check(usage(h,'retained-key-capacity',root/'b')['future_result_records']==1,'key rotation does not erase future capacity')
        h.check(conditional(h,'stale-config-action',root/'b',row,oldcfg,'key change',3)['code']=='ACTION_CONFIGURATION_CONFLICT','accepted policy change conflicts with earlier selected cancellation')
        fresh,current=selected(h,'fresh-key-state',root/'b',id)
        h.check(fresh['action_result']['peer_generation']=='a-g1','original result generation remains immutable')
        accepted=conditional(h,'cancel-original-binding',root/'b',fresh,current,'key change')
        op=accepted['observation']['action_result']['operation_id']
        rejected=h.run('cannot-rebind-result',['rebind','--control',str(root/'b'/'control.sock'),'--operation',op,'--generation','a-g2','--reason','cannot reinterpret disclosure'],expected=3)
        h.check(rejected['code']=='OUTBOUND_ACTION_RESULT_BOUND','ordinary rebind cannot violate canonical result binding')
        selected_out=h.run('select-result-outbox',['outbox-query','--control',str(root/'b'/'control.sock'),'--operation',op])
        rr=selected_out['records'][0];h.check(rr['condition']['restrictions']&8,'new result selection binds immutable-recipient restriction')
        rejected=h.run('cannot-conditionally-rebind-result',['rebind','--control',str(root/'b'/'control.sock'),'--operation',op,'--generation','a-g2','--expected-state',rr['condition']['state_digest'],'--expected-configuration',selected_out['configuration_digest'],'--reason','cannot reinterpret disclosure'],expected=3)
        h.check(rejected['code']=='OUTBOUND_ACTION_RESULT_BOUND','conditional rebind also retains result authority')
        h.run('key-result-compact',['compact','--control',str(root/'b'/'control.sock'),'--deadline-ms','5000'])
        b.shutdown();b=h.start('key-result-restarted',rotated,root/'b')
        h.check(action_query(h,'key-result-preserved',root/'b',id)['action_result']['peer_generation']=='a-g1','checkpoint and restart preserve original key and valid journal')
        (h.output/'KEY-BINDING.json').write_text(json.dumps({'binding':fresh['action_result'],'outbox':rr,'refusal':rejected},indent=2)+'\n')
        b.shutdown();a.shutdown()
    case('peer_isolation_rotation_and_immutable_result_key',key_binding)

    def maximum_encoded_result():
        root,ac,bc,a,b=pair(h,'max-result',records=1,payload=571)
        # Restarting from an edited accepted seed is forbidden; create new local
        # identities and effective configurations before this fresh pair starts.
        b.shutdown();a.shutdown();shutil.rmtree(root/'a');shutil.rmtree(root/'b')
        scope='results/'+('x'*120);gen='a'+('g'*63)
        ac.write_text(ac.read_text().replace('identity_generation=a-g1',f'identity_generation={gen}').replace(RESULT_SCOPE,scope))
        bc.write_text(bc.read_text().replace('a-g1',gen).replace(RESULT_SCOPE,scope).replace('primary,0,DISABLED','primary,0,ENABLED'))
        a=h.start('max-result-a',ac,root/'a');b=h.start('max-result-b',bc,root/'b')
        id=operation('max-result');submit_action(h,'max-result-source',root/'a',id,100,500)
        r=pending(h,'max-result-pending',root/'b',id)
        h.check(r['action_result']['reserved_payload_bytes']==571,'maximum scope and generation reserve exact NAC1 maximum')
        done=wait_action(h,'max-result-executed',root/'b',id,'EXECUTED');op=done['action_result']['operation_id']
        wait_outbox(h,'max-result-ack',root/'b',op,'ACKED')
        raw=bytes.fromhex(evidence_query(h,'max-result-data',root/'a',op)['payload_hex']);decoded=decode_nac1(raw)
        h.check(len(raw)==571 and decoded['counter_after']==100,'independent largest canonical result exactly fits reserved bytes')
        b.shutdown();a.shutdown()
    case('maximum_scope_and_generation_payload_bound',maximum_encoded_result)

    def rejection_and_retry():
        root,ac,bc,a,b=pair(h,'reject-result',records=1,disabled=False)
        a.shutdown();shutil.rmtree(root/'a')
        allowed_line=f'authorize=B,b-g1,EVIDENCE,{RESULT_SCOPE}\n'
        ac.write_text(ac.read_text().replace(allowed_line,''));a=h.start('reject-result-a',ac,root/'a')
        id=operation('result-rejection');submit_action(h,'reject-source',root/'a',id,9,600000);pending(h,'reject-pending',root/'b',id)
        row,cfg=selected(h,'reject-select',root/'b',id);answer=conditional(h,'reject-cancel',root/'b',row,cfg,'return may be denied');op=answer['observation']['action_result']['operation_id']
        wait_outbox(h,'rejected-return',root/'b',op,'REJECTED')
        h.check(usage(h,'rejection-releases',root/'b')['committed_records']==0,'recipient rejection releases issued capacity, not action history')
        # Disable the route before creating the filler so its pending status
        # does not depend on whether recipient rejection wins a scheduling race.
        disabled=candidate(h,bc,'retry-disabled','retry-disabled-g2',lambda t:t.replace('primary,0,ENABLED','primary,0,DISABLED'))
        activate(h,'disable-while-full',root/'b',disabled)
        fill=operation('retry-fixed-blocker');ordinary(h,'pending-retry-blocker',root/'b',fill,'x')
        denied=h.run('result-retry-no-slot',['retry','--control',str(root/'b'/'control.sock'),'--operation',op,'--reason','explicit result retry'],expected=3)
        h.check(denied['code']=='OUTBOX_GLOBAL_RECORD_LIMIT','result retry must reacquire ordinary capacity')
        h.run('free-retry-slot',['cancel','--control',str(root/'b'/'control.sock'),'--operation',fill,'--reason','free retry capacity'])
        newa=candidate(h,ac,'allow-result','allow-result-g2',lambda t:t+allowed_line);activate(h,'allow-result-policy',root/'a',newa)
        h.run('result-retry',['retry','--control',str(root/'b'/'control.sock'),'--operation',op,'--reason','explicit result retry'])
        q=usage(h,'retried-reservations',root/'b');h.check(q['pending_records']==1 and q['future_result_records']==0,'result retry reacquires issued record only')
        enabled=candidate(h,disabled,'retry-enabled','retry-enabled-g3',lambda t:t.replace('primary,0,DISABLED','primary,0,ENABLED'));activate(h,'enable-retried-return',root/'b',enabled)
        wait_outbox(h,'retried-result-ack',root/'b',op,'ACKED')
        h.check(action_query(h,'cancel-still-terminal',root/'b',id)['status']=='CANCELLED','result delivery never changes terminal action outcome')
        b.shutdown();a.shutdown()
    case('recipient_rejection_and_exact_capacity_reacquisition',rejection_and_retry)

    def legacy_unreserved():
        root,ac,bc,a,b=pair(h,'legacy',records=1)
        id=operation('legacy-action');submit_action(h,'legacy-source',root/'a',id,4,600000);pending(h,'legacy-current',root/'b',id);b.shutdown()
        path=root/'b'/'state.journal';raw=path.read_bytes();items=journal_frames(raw);changed=[];converted=0
        for _,_,body in items:
            if body[0]==23 and body[9]==11:
                bdy=bytearray(body);pos=10+64
                def text_skip(pos):return pos+2+struct.unpack_from('!H',bdy,pos)[0]
                pos=text_skip(pos);pos=text_skip(pos);pos+=1;pos=text_skip(pos);pos+=32
                marker=bdy[pos];pos+=1+32*marker;pos+=9;pos=text_skip(pos)
                h.check(bdy[pos]==3,'new admission contains reserved marker')
                bdy[pos]=2;pos+=1+96
                pos=text_skip(pos);pos+=72;pos=text_skip(pos);pos+=52
                h.check(struct.unpack_from('!Q',bdy,pos)[0]==398,'independent legacy fixture locates exact reservation field')
                del bdy[pos:pos+8];body=bytes(bdy);converted+=1
            changed.append(frame(body))
        h.check(converted==1,'one independent historical marker-2 admission')
        path.write_bytes(b''.join(changed));legacy=inspect(h,'legacy-inspect',root/'b',node='B')
        h.check(legacy['outbox']['reservations']['future_result_records']==0,'legacy state is not retroactively charged')
        b=h.start('legacy-owner',bc,root/'b');r=action_query(h,'legacy-unreserved',root/'b',id)
        h.check(r['action_result']['capacity_state']=='LEGACY_UNRESERVED','legacy state labeled explicitly')
        blocker=operation('legacy-blocker');ordinary(h,'legacy-fill',root/'b',blocker,'x')
        row,cfg=selected(h,'legacy-select',root/'b',id)
        denied=conditional(h,'legacy-capacity-refusal',root/'b',row,cfg,'legacy compound',3)
        h.check(denied['code']=='OUTBOX_GLOBAL_RECORD_LIMIT','legacy conditional conversion has no invented capacity credit')
        h.run('legacy-free',['cancel','--control',str(root/'b'/'control.sock'),'--operation',blocker,'--reason','free legacy result slot'])
        accepted=conditional(h,'legacy-convert',root/'b',row,cfg,'legacy compound');h.check(accepted['status']=='APPLIED','legacy result can be conditionally cancelled when actual capacity fits')
        h.run('legacy-compact',['compact','--control',str(root/'b'/'control.sock'),'--deadline-ms','5000']);b.shutdown();b=h.start('legacy-checkpoint',bc,root/'b')
        h.check(conditional(h,'legacy-repeat',root/'b',row,cfg,'legacy compound')['status']=='ALREADY_APPLIED','NRA1 plus new conditional receipt reconstructs')
        b.shutdown();a.shutdown()
    case('independently_encoded_legacy_unreserved_compatibility',legacy_unreserved)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');args=p.parse_args()
    if args.output.exists():p.error('output must not exist')
    h=Harness(args.binary,args.output);started=time.monotonic();ok=False
    try:
        run_cases(h,set(args.case) if args.case else None)
        if not h.cases:raise ValueError('no cases selected')
        ok=True
    except BaseException as error:
        (h.output/'FAILURE.txt').write_text(f'{type(error).__name__}: {error}\n');print(f'FAIL: {error}',file=os.sys.stderr)
    finally:
        h.cleanup();result={'format':'RESERVED_ACTION_RESULTS_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.monotonic()-started}
        for name,value in [('SUMMARY',result),('CASES',h.cases),('COMMANDS',h.commands)]: (h.output/(name+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
        print(json.dumps(result),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
