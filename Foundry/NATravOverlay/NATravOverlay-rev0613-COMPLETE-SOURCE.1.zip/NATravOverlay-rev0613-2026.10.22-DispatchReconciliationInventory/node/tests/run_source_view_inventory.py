#!/usr/bin/env python3
"""Recipient view inventory through the real C++ owner, peers and kernel UIDs.
Synthetic policy pins in the capacity case are not communicating subscriptions.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, shutil, struct, subprocess, sys, time
from pathlib import Path
from run_persistent import Harness, operation, raw_control
from run_subscribed_source_views import setup, emit, materialize, SCOPE, TARGET
from run_import_automation import auto, until, allrows
from run_import_review import denied_setup, review, retry
from run_view_retirement import status as retire_status, retire
from run_source_subscriptions import command, ack
from run_local_evidence import author
from run_live_configuration import candidate, activate
from run_local_administration import run_as_uid, expose_control_for_uid, restore_owner_only_control
from run_scoped_reads import query as evidence_query
from run_state_authentication import new_key, migrate, start as start_keyed, inspect

FORMAT='NATRAV_OVERLAY_SOURCE_VIEW_INVENTORY_V1'

def save(h,name,obj): (h.output/(name+'.json')).write_text(json.dumps(obj,indent=2)+'\n')
def text(s):
    b=s.encode(); return struct.pack('!H',len(b))+b

def filters(kw):
    out=b''.join(text(kw.get(k,'all' if k in ('presence','lifecycle','schedule') else '')) for k in
        ('presence','lifecycle','schedule','view','provider','generation','source_scope','target_scope'))
    return out+(b'\0' if kw.get('author_uid') is None else b'\1'+struct.pack('!I',kw['author_uid']))

def wire(**kw):
    return b'NOC1\x27VIN1'+filters(kw)+struct.pack('!III',kw.get('offset',0),kw.get('limit',16),kw.get('max_bytes',32768))+(b'\1'+bytes.fromhex(kw['selection']) if kw.get('selection') else b'\0')

def root_for(response,rows,**kw):
    root=hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_VIEW_INVENTORY_SELECTION_V1\0'+text(response['node'])+struct.pack('!I',response['manager_uid'])+bytes.fromhex(response['authorized_configuration_digest'])+filters(kw)+struct.pack('!I',len(rows))).digest()
    for row in rows:
        b=json.dumps(row,separators=(',',':'),ensure_ascii=False).encode()
        root=hashlib.sha256(b'NATRAV_OVERLAY_SOURCE_VIEW_INVENTORY_ROW_V1\0'+root+struct.pack('!I',len(b))+b).digest()
    return root.hex()

def binding_root(entries):
    b=b'NATRAV_OVERLAY_VIEW_INVENTORY_BINDINGS_V1\0'+struct.pack('!I',len(entries))
    for grant,dig in sorted(entries):b+=text(grant)+bytes.fromhex(dig)
    return hashlib.sha256(b).hexdigest()

def query(h,label,c,uid=None,expected=0,**kw):
    args=['source-view-inventory','--control',str(c/'control.sock'),'--deadline-ms','5000']
    for k,v in kw.items():args+=['--'+k.replace('_','-'),str(v)]
    r=h.run(label,args,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,args,expected)
    if expected==0:
        h.check(r['format']==FORMAT and r['manager_uid']==(os.geteuid() if uid is None else uid),'native inventory under actual manager')
        h.check(len(json.dumps(r,separators=(',',':')).encode())<=kw.get('max_bytes',32768),'complete annotated byte budget')
        for field in ('source_records_read','payload_bytes_copied','histories_serialized','deferred_entries_serialized','historical_configurations_parsed','final_accounts_computed','snapshot_calls','snapshot_payload_bytes','logical_bytes_serialized'):
            h.check(r['work'][field]==0,'no broad work: '+field)
        h.check(not any(s in json.dumps(r) for s in ('payload_hex','payload_text','private_key','key.pem')),'no payload or private identity path in inventory')
    return r

def extra_view(s,name,uid=None,maximum=128):
    owner=os.geteuid() if uid is None else uid
    return (f'source_view={name},{owner},A,a-g1,{os.geteuid()},{SCOPE},subscribed/{name},{maximum},1000000\n'+
        f'source_view_binding={name},g1,{s["instance"]},{s["grant_digest"]},-\n')

def run_cases(h,selected):
    def case(name,fn):
        if selected is None or name in selected:h.case(name,fn)

    def basic():
        a,c,ac,cc,ad,cd,s=setup(h,'basic')
        cfg=candidate(h,cc,'basic-expanded','basic-expanded-g1',lambda t:t+extra_view(s,'alpha')+extra_view(s,'zulu'))
        activate(h,'basic-expand',c,cfg)
        retired=retire(h,'empty-retire',c,retire_status(h,'empty-select',c,view='alpha'))
        cfg2=candidate(h,cfg,'basic-removed','basic-removed-g1',lambda t:'\n'.join(l for l in t.splitlines() if not l.startswith(('source_view=alpha,','source_view_binding=alpha,')))+'\n')
        activate(h,'basic-remove',c,cfg2)
        first=query(h,'basic-whole',c,limit=16,max_bytes=60000);rows=first['records']
        h.check([x['view'] for x in rows]==['alpha','temps','zulu'],'history and current views in owned ID order')
        h.check(rows[0]['presence']=='HISTORICAL' and rows[0]['lifecycle']=='RETIRED' and rows[0]['current_binding_count']==0 and rows[0]['retained_binding_count']==1,'removed retired definition and pins preserved')
        h.check(rows[0]['retirement']['final_state_digest']==retired['retirement']['final_state_digest'],'retirement account reused without recomputation')
        h.check(rows[1]['schedule'] is None and rows[1]['retained_records']==0,'listing never creates a schedule')
        h.check(root_for(first,rows)==first['selection_digest'],'independent whole selection commitment')
        conf=h.run('basic-policy',['config-check','--config',str(cfg)])
        pins=[(x['binding'].split(',')[1],x['digest']) for x in conf['source_view_policy']['bindings'] if x['binding'].startswith('alpha,')]
        h.check(binding_root(pins)==rows[0]['retained_bindings_digest'],'independent exact binding commitment')
        page=query(h,'basic-first',c,limit=1);end=query(h,'basic-second',c,offset=1,selection=page['selection_digest'],limit=2,max_bytes=60000)
        h.check(page['records']+end['records']==rows,'page limits can change without changed selection')
        variants=[({'presence':'historical'},1),({'lifecycle':'retired'},1),({'schedule':'never-enabled'},2),({'schedule':'retired'},1),({'provider':'B'},0),({'author_uid':os.geteuid()},3),({'source_scope':SCOPE},3),({'target_scope':TARGET},1),({'generation':'a-g1'},3),({'view':'alpha','presence':'configured'},0)]
        for i,(kw,n) in enumerate(variants):
            got=query(h,'basic-filter-'+str(i),c,**kw);h.check(got['selected_total']==n and root_for(got,got['records'],**kw)==got['selection_digest'],'exact filter and independently hashed selection')
        h.check(query(h,'false-selection',c,selection='42'*32,expected=3)['code']=='SOURCE_VIEW_INVENTORY_SELECTION_MISMATCH','false selection rejected')
        h.check(query(h,'unbound-offset',c,offset=1,expected=3)['code']=='SOURCE_VIEW_INVENTORY_SELECTION_REQUIRED','unguarded continuation rejected')
        h.check(query(h,'small-first',c,max_bytes=2048,expected=3)['code']=='SOURCE_VIEW_INVENTORY_PAGE_TOO_SMALL','whole first row required')
        clipped=query(h,'byte-limited',c,max_bytes=4096);h.check(0<clipped['returned']<3 and clipped['has_more'],'nonfitting row not skipped')
        ok,ind=raw_control(c/'control.sock',wire(limit=2,max_bytes=60000));h.check(ok and ind['records']==rows[:2],'independent VIN1 control encoding')
        for raw in (wire()+b'x',wire()[:-1],wire().replace(b'VIN1',b'VIN2'),wire(schedule='invalid'),wire(selection='00'*32)):
            ok,e=raw_control(c/'control.sock',raw);h.check(not ok and e['code']=='SOURCE_VIEW_INVENTORY_INVALID','strict wire rejection')
        before=(c/'state.journal').read_bytes()
        for i in range(8):h.check(query(h,'empty-poll-'+str(i),c,view='absent')['records']==[],'empty exact view')
        h.check((c/'state.journal').read_bytes()==before,'successful empty inspection writes no event')
        bad=candidate(h,cfg2,'invalid-definition','invalid-definition-g1',lambda t:t.replace(','+TARGET+',128,1000000',','+TARGET+',129,1000000')+extra_view(s,'ghost'))
        h.run('bad-definition-rejected',['config-activate','--control',str(c/'control.sock'),'--candidate',str(bad),'--reason','must not index rejected policy'],expected=3)
        h.check(query(h,'no-ghost-policy',c,selection=first['selection_digest'])['records']==rows,'rejected candidate creates no registry member')
        save(h,'BASIC',{'whole':first,'byte_limited':clipped,'independent':ind});cd.shutdown();ad.shutdown()
    case('strict_wire_filters_rejected_config_historical_registry_and_page_bounds',basic)

    def progress():
        a,c,ac,cc,ad,cd,s=setup(h,'progress',records=3)
        initial=query(h,'progress-initial',c)
        one,s,r1=emit(h,'progress-one',a,c,s,ticks=100)
        raw=query(h,'raw-not-imported',c,selection=initial['selection_digest'])
        h.check(raw['records']==initial['records'],'raw admitted envelopes are not materialized usage')
        materialize(h,'progress-direct',c,r1)
        h.check(query(h,'direct-stale',c,selection=initial['selection_digest'],expected=3)['code']=='SOURCE_VIEW_INVENTORY_SELECTION_MISMATCH','direct import invalidates counts without scheduler revision')
        direct=query(h,'direct-metadata',c);h.check(direct['records'][0]['schedule'] is None and direct['records'][0]['retained_records']==1,'exact derived usage without schedule')
        auto(h,'progress-enable',c,'enable',previous=auto(h,'progress-auto-initial',c),imports=2,decisions=16)
        until(h,'duplicate-classified',c,lambda v:v['next_position']==1)
        two,s,r2=emit(h,'progress-two',a,c,s,ticks=25)
        until(h,'first-auto-import',c,lambda v:v['imports']==1)
        _,s,r3=emit(h,'progress-correction',a,c,s,ticks=150,parent=one['operation_id'])
        until(h,'exact-auto-allowance',c,lambda v:v['state']=='EXHAUSTED')
        done=query(h,'auto-exhausted',c);row=done['records'][0]
        h.check(row['retained_records']==3 and row['remaining_records']==0 and row['schedule']['imports']==2 and row['schedule']['decisions']==3,'direct and automated counters remain distinct')
        h.check(row['retained_payload_bytes']==sum(len(bytes.fromhex(x['payload_hex'])) for x in allrows(h,'projection-inputs',c)),'usage agrees with independently read stored payload sizes')
        from run_numeric_projection import call,consume
        inputs=allrows(h,'numeric-inputs',c)
        call(h,'inventory-projection-create',c,'create','sum',definition='NUMERIC_SUMMARY_V1',issuer='A',scope=TARGET,unit='degC',scale=2,reason='independent result')
        result,_=consume(h,'inventory-consume',c,{x['operation_id']:bytes.fromhex(x['payload_hex']) for x in inputs},name='sum')
        h.check(result['consumer']['projection']['result']['numeric']['sum_ticks']=='175','retained numeric correction result unchanged by listing')
        before=(c/'state.journal').read_bytes()
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: pages=list(pool.map(lambda i:query(h,'reader-'+str(i),c),range(8)))
        h.check(len({p['selection_digest'] for p in pages})==1 and (c/'state.journal').read_bytes()==before,'concurrent readers create no mutations')
        terminal=retire(h,'progress-retire',c,retire_status(h,'progress-final-select',c))
        retired=query(h,'progress-retired',c,lifecycle='retired')
        h.check(retired['records'][0]['retained_records']==3 and retired['records'][0]['retirement']['previous_schedule_state']=='EXHAUSTED','retirement preserves usage and last grant')
        _,s,r4=emit(h,'progress-after-retire',a,c,s,ticks=1)
        h.check(query(h,'retired-after-new-raw',c,lifecycle='retired',selection=retired['selection_digest'])['records']==retired['records'],'raw arrival cannot reopen retired view')
        save(h,'PROGRESS',{'initial':initial,'direct':direct,'automatic':done,'retired':retired,'numeric_sum':'175','terminal':terminal});cd.shutdown();ad.shutdown()
    case('raw_and_materialized_counts_manual_and_automatic_progress_and_retirement',progress)

    def dependencies():
        a,c,ac,cc,cc2,ad,cd,sub,src,parent_decision,stopped=denied_setup(h,'dependency')
        denied=query(h,'dependency-denied',c)
        h.check(denied['records'][0]['retained_records']==0 and denied['records'][0]['schedule']['latest_decision']['outcome']=='SOURCE_VIEW_SUBSCRIPTION_DENIED','typed invalid/denied source is not retained evidence')
        activate(h,'dependency-new-binding',c,cc2)
        auto(h,'dependency-enable',c,'enable',previous=stopped,imports=8)
        author(h,'dependency-child',a,ticks=175,parent=src['operation_id'])
        issued=command(h,'dependency-child-issue',a,'step',grant='g2',previous=sub);sub=ack(h,'dependency-child-receipt',a,issued,grant='g2')
        until(h,'child-deferred',c,lambda x:len(x['deferred'])==1)
        author(h,'dependency-independent',a,ticks=25)
        independent=command(h,'dependency-independent-issue',a,'step',grant='g2',previous=sub);sub=ack(h,'dependency-independent-receipt',a,independent,grant='g2')
        state=until(h,'independent-imported',c,lambda x:x['imports']==1)
        auto(h,'dependency-pause',c,'pause',previous=state)
        paused=query(h,'deferred-paused',c);r=paused['records'][0]
        h.check(r['retained_records']==1 and r['schedule']['deferred_count']==1 and r['current_binding_count']==2 and r['retained_binding_count']==2,'one missing dependency does not hide independent progress')
        before=(c/'state.journal').read_bytes();time.sleep(.15)
        h.check(query(h,'deferred-observed',c,selection=paused['selection_digest'])['records']==paused['records'] and before==(c/'state.journal').read_bytes(),'inspection does not retry deferred work')
        p=review(h,'dependency-review',c);retry(h,'retry-parent',c,p,parent_decision)
        p=review(h,'dependency-review-child',c);child=next(e for e in p['events'] if e['outer_operation']==issued['latest']['operation_id'])
        retry(h,'retry-child',c,p,child)
        done=query(h,'deferred-resolved',c);r=done['records'][0]
        h.check(r['retained_records']==3 and r['schedule']['deferred_count']==0 and r['schedule']['manual_retries']==2 and r['schedule']['imports']==1,'manual retry alters separate account without spending automatic allowance')
        h.check(query(h,'manual-retry-stale',c,selection=paused['selection_digest'],expected=3)['code']=='SOURCE_VIEW_INVENTORY_SELECTION_MISMATCH','manual retry invalidates selected metadata')
        save(h,'DEPENDENCIES',{'denied':denied,'deferred':paused,'resolved':done});cd.shutdown();ad.shutdown()
    case('denied_sources_deferred_corrections_and_explicit_retry_accounting',dependencies)

    def principals():
        a,c,ac,cc,ad,cd,s=setup(h,'principals',delegates=True)
        expanded=candidate(h,cc,'principals-more','principals-more-g1',lambda t:t+extra_view(s,'keep',65534)+extra_view(s,'other',65533))
        # OTHER originally has metadata read only; explicit import authority is required for its own view.
        expanded.write_text(expanded.read_text().replace('local_control=65533,EVIDENCE_READ','local_control=65533,EVIDENCE_READ,SOURCE_IMPORT'))
        activate(h,'principals-accept',c,expanded);expose_control_for_uid(c)
        own=query(h,'owner-root',c);u=query(h,'owner-u',c,uid=65534);v=query(h,'owner-v',c,uid=65533)
        h.check([x['view'] for x in own['records']]==['temps'] and [x['view'] for x in u['records']]==['delegated','keep'] and [x['view'] for x in v['records']]==['other'],'manager ranges isolate counts and names')
        h.check(query(h,'hidden-exact',c,uid=65534,view='temps')['records']==query(h,'missing-exact',c,uid=65534,view='nonexistent')['records']==[],'other owner indistinguishable from absent exact view')
        h.check(query(h,'cross-owner-selection',c,uid=65533,selection=u['selection_digest'],expected=3)['code']=='SOURCE_VIEW_INVENTORY_SELECTION_MISMATCH','prefix is principal scoped')
        author(h,'principal-source',a,ticks=11);issue=command(h,'principal-issue',a,'step',previous=s);s=ack(h,'principal-receipt',a,issue)
        materialize(h,'import-only-manager',c,issue['latest']['operation_id'],view='delegated',uid=65534)
        denied=run_as_uid(h,'import-is-not-read',65534,65534,['evidence-query','--control',str(c/'control.sock'),'--issuer','A','--scope','subscribed/delegated','--payload','yes'],3)
        h.check(denied['code']=='LOCAL_CONTROL_CLASS_DENIED','import manager does not acquire read class')
        h.check(query(h,'hidden-import-no-gap',c,selection=own['selection_digest'])['records']==own['records'],'other manager import does not change owned summary')
        def remove(t):
            return '\n'.join(l.replace('peer_key=A,a-g1,ACTIVE,','peer_key=A,a-g1,REVOKED,') for l in t.splitlines() if not l.startswith(('source_view=delegated,','source_view_binding=delegated,','peer=A,','peer_route=A,','authorize=A,')))+'\n'
        removed=candidate(h,expanded,'principals-removed','principals-removed-g1',remove);activate(h,'principals-remove-rule-and-revoke',c,removed)
        hist=query(h,'owner-historical',c,uid=65534,presence='historical');r=hist['records'][0]
        h.check(r['view']=='delegated' and r['retained_records']==1 and not r['policy_current'] and r['provider_generation_state']=='REVOKED' and r['provider_pin_matches'],'historical metadata does not restore import permission')
        h.check(materialize(h,'historical-import-denied',c,issue['latest']['operation_id'],view='delegated',uid=65534,expected=3)['code']=='SOURCE_VIEW_POLICY_DENIED','historical visibility is not eligibility')
        # Actual delegated slow client: class revocation after connection and before decoding.
        rendezvous=h.runtime/'principal-markers';rendezvous.mkdir();rendezvous.chmod(0o777)
        script=h.work/'slow_inventory.py';sent=rendezvous/'sent';go=rendezvous/'go';out=rendezvous/'result'
        script.write_text('import socket,struct,time,json,sys,os\ns=socket.socket(socket.AF_UNIX);s.settimeout(10);s.connect(sys.argv[1]);b=bytes.fromhex(sys.argv[2]);s.sendall(struct.pack("!I",len(b))+b[:1]);open(sys.argv[3],"w").close()\nwhile not os.path.exists(sys.argv[4]):time.sleep(.01)\ns.sendall(b[1:]);s.shutdown(socket.SHUT_WR)\ndef exact(n):\n b=b""\n while len(b)<n:\n  v=s.recv(n-len(b))\n  if not v:raise RuntimeError("unexpected EOF")\n  b+=v\n return b\nr=exact(struct.unpack("!I",exact(4))[0]);open(sys.argv[5],"wb").write(r)\n')
        h.work.chmod(0o755);script.chmod(0o644)
        proc=subprocess.Popen(['setpriv','--reuid=65534','--regid=65534','--clear-groups',sys.executable,str(script),str(c/'control.sock'),wire().hex(),str(sent),str(go),str(out)],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        try:
            h.wait('slow request accepted',lambda:sent.exists(),3)
            revoked=candidate(h,removed,'principals-revoked','principals-revoked-g1',lambda t:'\n'.join(l for l in t.splitlines() if not l.startswith(('local_control=65534,','source_view=keep,','source_view_binding=keep,')))+'\n')
            activate(h,'principals-class-revoked',c,revoked);go.touch();_,err=proc.communicate(timeout=12)
            h.check(proc.returncode==0,'kernel delegated client completed: '+err.decode());raw=out.read_bytes();reply=json.loads(raw[5:])
            h.check(raw[4]==1 and reply['code']=='LOCAL_CONTROL_CLASS_DENIED','post-decode authority used for partial request')
        finally:
            if proc.poll() is None:proc.kill();proc.wait()
        save(h,'PRINCIPALS',{'root':own,'first_manager':u,'second_manager':v,'historical':hist,'revoked_response':reply});cd.shutdown();ad.shutdown()
    case('actual_manager_uids_historical_visibility_key_revocation_and_live_class_change',principals)

    def capacity():
        a,c,ac,cc,ad,cd,s=setup(h,'capacity')
        names=['temps']+['v'+str(i).zfill(2) for i in range(1,32)]
        additions=''.join(extra_view(s,name) for name in names[1:])
        for name in names:
            for i in range(1,8):additions+=f'source_view_binding={name},pin{i},{operation(name+"-instance-"+str(i))},{operation(name+"-grant-"+str(i))},-\n'
        cfg=candidate(h,cc,'capacity-full','capacity-full-g1',lambda t:t+additions)
        h.check(cfg.stat().st_size<65536,'full registry fits unchanged configuration ceiling')
        activate(h,'capacity-accept',c,cfg)
        for name in names[:16]:retire(h,'capacity-retire-'+name,c,retire_status(h,'capacity-select-'+name,c,view=name))
        whole=[];pages=[];offset=0;sel=None
        while True:
            p=query(h,'capacity-page-'+str(offset),c,limit=7,max_bytes=60000,**({'offset':offset,'selection':sel} if sel else {}));pages.append(p);whole+=p['records'];sel=p['selection_digest']
            if not p['has_more']:break
            offset=p['next_offset']
        h.check(len(whole)==32 and len(pages)==5 and [x['ordinal'] for x in whole]==list(range(1,33)),'all 32 historical view definitions enumerated')
        h.check(sum(x['lifecycle']=='RETIRED' for x in whole)==16 and all(x['retained_binding_count']==x['current_binding_count']==8 for x in whole),'256 exact pins and active versus terminal views')
        h.check(root_for(pages[0],whole)==sel,'independent complete capacity root')
        bad=candidate(h,cfg,'capacity-over','capacity-over-g1',lambda t:t+extra_view(s,'excess'))
        h.check(h.run('capacity-excess-rejected',['config-check','--config',str(bad)],expected=3)['code']=='CONFIG_SOURCE_VIEW_LIMIT','existing 32-view maximum unchanged')
        before=(c/'state.journal').read_bytes()
        empty=query(h,'capacity-empty',c,view='none');h.check(empty['work']['page_rows_visited']==0 and before==(c/'state.journal').read_bytes(),'empty listing no record or history work')
        h.run('capacity-compact',['compact','--control',str(c/'control.sock'),'--deadline-ms','10000']);cd.shutdown();cd=h.start('capacity-restart',cfg,c)
        after=query(h,'capacity-after-replay',c,limit=7,max_bytes=60000,selection=sel)
        h.check(after['records']==pages[0]['records'],'same metadata and selection after reconstructed registry')
        save(h,'CAPACITY',{'views':32,'bindings':256,'retired':16,'pages':len(pages),'first':pages[0],'after_restart':after,'configuration_bytes':cfg.stat().st_size});cd.shutdown();ad.shutdown()
    case('maximum_32_view_256_pin_registry_complete_pagination_and_replay',capacity)

    def retired_dependency():
        a,c,ac,cc,cc2,ad,cd,sub,src,decision,stopped=denied_setup(h,'retained-dependency')
        activate(h,'retained-pins',c,cc2);auto(h,'retained-enable',c,'enable',previous=stopped,imports=8)
        author(h,'retained-child',a,ticks=20,parent=src['operation_id']);issue=command(h,'retained-issue',a,'step',grant='g2',previous=sub);ack(h,'retained-ack',a,issue,grant='g2')
        until(h,'retained-parent-wait',c,lambda x:len(x['deferred'])==1)
        before=query(h,'retained-before',c)
        terminal=retire(h,'retain-unprocessed',c,retire_status(h,'retained-final-select',c),deferred='retain')
        after=query(h,'retained-after',c);r=after['records'][0]
        h.check(r['schedule']['deferred_count']==1 and r['retained_records']==0 and r['retirement']['deferred_disposition']=='RETAIN_UNPROCESSED','terminal unresolved work not fabricated imports')
        h.check(r['retirement']['final_state_digest']==terminal['final_state_digest'],'recorded retirement commitment not recalculated')
        h.run('retained-compact',['compact','--control',str(c/'control.sock')]);cd.shutdown();cd=h.start('retained-restart',cc2,c)
        recovered=query(h,'retained-recovered',c,selection=after['selection_digest']);h.check(recovered['records']==after['records'],'deferred terminal summary reconstructs')
        save(h,'RETAINED-DEPENDENCY',{'before':before,'after':after,'recovered':recovered});cd.shutdown();ad.shutdown()
    case('retired_deferred_work_remains_unprocessed_and_observational',retired_dependency)

    def maintenance():
        a,c,ac,cc,ad,cd,s=setup(h,'maintenance')
        _,s,row=emit(h,'maintenance-source',a,c,s,ticks=125);materialize(h,'maintenance-import',c,row)
        first=query(h,'maintenance-first',c)
        h.run('maintenance-quiesce',['quiesce','--control',str(c/'control.sock'),'--reason','observational maintenance'])
        quiet=query(h,'maintenance-quiesced',c,selection=first['selection_digest']);h.check(quiet['records']==first['records'],'quiescence is not import mutation')
        h.run('maintenance-resume',['resume','--control',str(c/'control.sock'),'--reason','continue']);cd.shutdown()
        key=new_key(h,h.work,'view-inventory-g1');migrate(h,'inventory-migrate',c,key,node='C');cd=start_keyed(h,'inventory-keyed',cc,c,key)
        h.run('inventory-keyed-compact',['compact','--control',str(c/'control.sock')]);h.check(query(h,'inventory-keyed-query',c,selection=first['selection_digest'])['records']==first['records'],'same-state compaction preserves selected facts');cd.shutdown()
        h.run('inventory-keyed-audit',['state-auth-audit','--state',str(c),'--node','C','--state-auth-key',str(key)])
        before=inspect(h,'inventory-pre-backup',c,key,node='C');crypt=h.work/'view-inventory.key';h.run('inventory-key',['backup-key-init','--output',str(crypt),'--generation','inventory-encryption'])
        identity=h.identity('C');archive=h.work/'view-inventory.nob'
        h.run('inventory-export',['backup-export','--state',str(c),'--node','C','--generation','c-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        restored=h.runtime/'inventory-restored';h.run('inventory-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','C','--generation','c-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=inspect(h,'inventory-restored-state',restored,key,node='C');h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'exact restored logical state')
        new_identity=h.work/'moved-c-identity';new_identity.mkdir(mode=0o700)
        cert=new_identity/'cert.pem';secret=new_identity/'key.pem';shutil.copyfile(identity.certificate,cert);shutil.copyfile(identity.private_key,secret);cert.chmod(0o644);secret.chmod(0o600)
        moved=candidate(h,cc,'inventory-relocated','inventory-relocated-g1',lambda t:t.replace('state='+str(c),'state='+str(restored)).replace(str(identity.certificate),str(cert)).replace(str(identity.private_key),str(secret)))
        h.run('inventory-relocate',['state-relocate','--state',str(restored),'--node','C','--candidate',str(moved),'--reason','explicit owned paths','--state-auth-key',str(key)])
        identity.certificate.unlink();identity.private_key.unlink()
        cd=start_keyed(h,'inventory-relocated-start',moved,restored,key)
        relocated=query(h,'inventory-relocated-query',restored);h.check(relocated['records']==first['records'],'historical definition and metadata do not reopen obsolete keys')
        h.check(query(h,'inventory-relocated-stale',restored,selection=first['selection_digest'],expected=3)['code']=='SOURCE_VIEW_INVENTORY_SELECTION_MISMATCH','relocated accepted configuration needs reselect')
        _,s,later=emit(h,'inventory-continuation',a,restored,s,ticks=25);materialize(h,'inventory-next-import',restored,later)
        progressed=query(h,'inventory-after-new-import',restored);h.check(progressed['records'][0]['retained_records']==2,'new import continues after restored registry')
        ad.shutdown()
        h.run('inventory-drain-blocker',['submit','--control',str(restored/'control.sock'),'--node','C','--peer','A','--scope',SCOPE,'--operation',operation('inventory-drain'),'--payload-text','unavailable'])
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            drain=pool.submit(h.run,'inventory-drain',['drain-shutdown','--control',str(restored/'control.sock'),'--drain-deadline-ms','2500','--reason','nonempty lifecycle'])
            h.wait('real draining mode',lambda:h.status('inventory-drain-status',restored,logical_digest=False)['lifecycle']['draining'])
            dpage=query(h,'inventory-during-drain',restored);h.check(dpage['records']==progressed['records'],'inventory is observational during drain')
            h.check(drain.result(timeout=8)['deadline_reached'],'listing does not finish unavailable delivery')
        cd.process.wait(timeout=8)
        save(h,'MAINTENANCE',{'before':first,'quiesced':quiet,'relocated':relocated,'continued':progressed,'draining':dpage,'restored_digest':after['storage']['logical_state_digest']})
    case('keyed_compaction_signed_encrypted_restore_relocation_and_live_drain',maintenance)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);start=time.time();ok=False
    try:run_cases(h,set(a.case) if a.case else None);ok=True
    except BaseException as e:
        (h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {type(e).__name__}: {e}',file=sys.stderr)
    finally:
        h.cleanup();result={'format':'NATRAV_OVERLAY_SOURCE_VIEW_INVENTORY_TESTS_V1','status':'PASS' if ok else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(x['status']=='PASS' for x in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-start}
        for name,value in [('SUMMARY',result),('CASES',h.cases),('COMMANDS',h.commands)]:save(h,name,value)
        print(json.dumps(result),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
