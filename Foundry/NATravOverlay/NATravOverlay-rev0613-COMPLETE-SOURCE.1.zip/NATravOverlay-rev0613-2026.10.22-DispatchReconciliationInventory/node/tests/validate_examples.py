#!/usr/bin/env python3
"""Validate shipped configuration templates with disposable native identities.
This checks syntax/identity loading only. Synthetic view pins do not approve a
real subscription, and no daemon, listener, or external connection is started.
"""
from __future__ import annotations
import argparse, hashlib, json, os, subprocess, tempfile
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error('output must not exist')
    binary = args.binary.resolve(strict=True)
    examples = Path(__file__).resolve().parent.parent / 'examples'
    results = []
    with tempfile.TemporaryDirectory(prefix='natrav-examples-') as directory:
        root = Path(directory); root.chmod(0o700)
        (root / 'private').mkdir(mode=0o700)
        pins = {}
        for node in ('A', 'B', 'C', 'D'):
            generation = 'b1' if node == 'B' else node.lower()+'-g1'
            destination = root / 'private' / ('node-'+node.lower()+'-g1')
            command = [str(binary),'identity-init','--directory',str(destination),'--node',node,'--generation',generation]
            result = subprocess.run(command, capture_output=True, text=True, timeout=15)
            if result.returncode:
                raise RuntimeError('identity-init failed: '+result.stderr+result.stdout)
            identity = json.loads(result.stdout)
            pins[node.lower()*64] = identity['spki_sha256']
        for example in sorted(examples.glob('*.conf')):
            contents = example.read_text()
            for old, new in pins.items():
                contents = contents.replace(old, new)
            # Keep policy UID values exact; they are examples, not an implicit
            # permission grant to the user executing config-check.
            candidate = root / example.name
            candidate.write_text(contents); candidate.chmod(0o600)
            result = subprocess.run([str(binary),'config-check','--config',str(candidate)],capture_output=True,text=True,timeout=15)
            account = {'template':example.name,'template_sha256':hashlib.sha256(example.read_bytes()).hexdigest(),'returncode':result.returncode}
            if result.returncode:
                account['stdout'] = result.stdout; account['stderr'] = result.stderr
            else:
                check = json.loads(result.stdout)
                account['configuration_format'] = check.get('format')
                account['runtime_digest'] = check.get('runtime_digest')
            results.append(account)
    passed = all(r['returncode']==0 for r in results) and bool(results)
    account = {'format':'NATRAV_OVERLAY_EXAMPLE_VALIDATION_V1','status':'PASS' if passed else 'FAIL',
               'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
               'templates':results,'synthetic_subscription_pins':True,
               'scope':'native config-check with disposable identities; no network, admission, or real subscription consent'}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(account,indent=2)+'\n')
    print(json.dumps({'status':account['status'],'templates':len(results)}))
    return 0 if passed else 1

if __name__=='__main__':
    raise SystemExit(main())
