#!/usr/bin/env python3
"""Exact fixed-point projection: independent interpreter and real C++ peers."""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, os, re, socket, struct, subprocess, time
from pathlib import Path
from typing import Any
from run_persistent import Harness, free_port, operation, raw_control, receive_exact
from run_projections import trio, config, pargs, read
from run_consumers import call as consumer_call, wire
from run_evidence_feed import wire_feed
from run_local_administration import run_as_uid, expose_control_for_uid
from run_scoped_reads import UID, SECOND_UID, send
from run_live_configuration import candidate, activate, wait_state
from run_state_authentication import new_key, migrate, start as start_keyed

UNIT='degC'; SCALE=2
CODES=('MALFORMED','UNIT_MISMATCH','SCALE_MISMATCH','VALUE_RANGE')
def payload(ticks: int,unit: str=UNIT,scale: int=SCALE)->bytes:
    u=unit.encode('ascii');return b'NNO1'+bytes([scale,len(u)])+u+struct.pack('!q',ticks)
def classify(b: bytes,unit: str=UNIT,scale: int=SCALE)->tuple[str,int]:
    if len(b)<15 or b[:4]!=b'NNO1' or b[4]>9 or not 1<=b[5]<=32 or len(b)!=14+b[5]:return ('MALFORMED',0)
    u=b[6:6+b[5]]
    if not re.fullmatch(rb'[A-Za-z][A-Za-z0-9_./%\-]{0,31}',u):return ('MALFORMED',0)
    if u!=unit.encode():return ('UNIT_MISMATCH',0)
    if b[4]!=scale:return ('SCALE_MISMATCH',0)
    v=struct.unpack('!q',b[-8:])[0]
    if abs(v)>10**12:return ('VALUE_RANGE',0)
    return ('ACCEPTED',v)
def call(h:Harness,label:str,b:Path,cmd:str,name:str='numeric',expected:int=0,uid:int|None=None,**kw:Any)->dict:
    a=pargs(b,cmd,name,**kw);r=h.run(label,a,expected=expected) if uid is None else run_as_uid(h,label,uid,uid,a,expected)
    assert r is not None
    if expected==0:
        c=r['consumer'];h.check(c['projection']['definition']=='NUMERIC_SUMMARY_V1','exact numeric definition')
        h.check(c['owner_uid']==(os.geteuid() if uid is None else uid),'kernel ownership')
        h.check(c['acknowledged_sequence']==c['projection']['result']['admissions'],'numeric result and progress agree')
        h.check(c['payload_included'] and c['payload_length']==46,'payload authority required for full valid numeric schema')
    return r

def create(h:Harness,label:str,b:Path,name:str='numeric',**kw:Any)->dict:
    return call(h,label,b,'create',name,definition='NUMERIC_SUMMARY_V1',issuer='A',scope='query/series',unit=UNIT,scale=SCALE,reason='explicit exact numeric projection',**kw)
def produce(h:Harness,label:str,a:Path,values:dict[str,bytes],*,ticks:int|None=None,raw:bytes|None=None,corrects:str|None=None,unit:str=UNIT,scale:int=SCALE,issuer:str='A')->str:
    op=operation(label);args=['revise' if corrects else 'submit','--control',str(a/'control.sock'),'--node',issuer,'--peer','B','--scope','query/series','--operation',op]
    if corrects:args+=['--corrects',corrects]
    if raw is not None:
        p=h.runtime/(label+'.bin');p.write_bytes(raw);args+=['--payload-file',str(p)];encoded=raw
    else:
        assert ticks is not None
        args+=['--numeric-ticks',str(ticks),'--numeric-unit',unit,'--numeric-scale',str(scale)];encoded=payload(ticks,unit,scale)
    h.run(label,args);wait_state(h,a,op,'ACKED',label+'-ack');values[op]=encoded;return op

def verify(h:Harness,r:dict,rows:list[dict],values:dict[str,bytes])->None:
    p=r['consumer']['projection'];heads={};historical=0;originals=0;errors=dict.fromkeys(CODES,0);accepted=0;root=bytes.fromhex(p['definition_digest'])
    for i,row in enumerate(rows,1):
        op=row['operation_id'];b=values[op];h.check(row['payload_size']==len(b),'wire length matches independent input')
        h.check(row['payload_hex']==b[:46].hex(),'native numeric encoder/prefix matches independent bytes')
        old=row['corrects'];historical+=len(b)
        if old is not None:del heads[old]
        else:originals+=1
        code,value=classify(b);heads[op]=(code,value,len(b))
        if code=='ACCEPTED':accepted+=1
        else:errors[code]+=1
        root=hashlib.sha256(b'NATRAV_OVERLAY_PROJECTION_SOURCE_V1\0'+root+struct.pack('!Q',i)+bytes.fromhex(op)+bytes.fromhex(row['record_digest'])).digest()
    expected={'admissions':len(rows),'originals':originals,'corrections':len(rows)-originals,'current_heads':originals,
        'historical_payload_bytes':historical,'current_payload_bytes':sum(v[2] for v in heads.values()),'source_digest':root.hex(),
        'numeric':{'accepted_admissions':accepted,'rejected_admissions':len(rows)-accepted,'valid_heads':sum(v[0]=='ACCEPTED' for v in heads.values()),
            'invalid_heads':sum(v[0]!='ACCEPTED' for v in heads.values()),'sum_ticks':str(sum(v[1] for v in heads.values())), 'rejections':errors}}
    h.check(p['result']==expected,'independent numeric interpreter, corrected heads and source-chain match')
    h.check(p['last_numeric_outcomes']==[classify(values[op])[0] for op in p['last_source_operations']],'per-input outcomes attributable to exact last source IDs')
    c=r['consumer'];d=p['numeric_definition'];u=d['unit'].encode()
    feed=wire_feed(issuer=c['issuer_filter'],scope=c['scope_filter'],limit=c['limit'],max_bytes=60000,payload=True,length=46)[5:]
    digest=hashlib.sha256(b'NATRAV_OVERLAY_NUMERIC_SUMMARY_V1\0'+struct.pack('!I',c['owner_uid'])+bytes.fromhex(c['instance'])+
        struct.pack('!Q',p['maximum_admissions'])+feed+bytes([len(u)])+u+bytes([d['scale']])+struct.pack('!Q',int(d['maximum_absolute_sum_ticks']))).hexdigest()
    h.check(digest==p['definition_digest'],'independent schema/unit/scale/budget/selection/instance binding')

def consume(h:Harness,label:str,b:Path,values:dict[str,bytes],name:str='numeric',rows:list|None=None)->tuple[dict,list]:
    rows=[] if rows is None else rows
    i=0;r=call(h,label+'-before',b,'status',name)
    while True:
        p=read(h,f'{label}-page-{i}',b,name)
        if not p['records']:break
        rows+=p['records'];r=call(h,f'{label}-process-{i}',b,'process',name,batch=p['consumer']['pending_batch']['id']);verify(h,r,rows,values);i+=1
    return r,rows

def cases(h:Harness,selected:set[str]|None=None)->None:
    def case(name,fn):
        if selected is None or name in selected:h.case(name,fn)
    def strict():
        b=h.runtime/'strict';cfg=config(h,'strict-numeric',b,free_port());d=h.start('strict-numeric',cfg,b)
        r=create(h,'native-registration',b,limit=2);verify(h,r,[],{})
        h.check(create(h,'registration-retry',b,limit=2)['consumer']==r['consumer'],'registration retry idempotent')
        for label,opts in [('unknown-definition',dict(definition='RUN_CODE')),('bad-unit',dict(unit=' degree C')),('bad-scale',dict(scale=10)),('bad-budget',dict(max_abs_sum=0))]:
            kw=dict(definition='NUMERIC_SUMMARY_V1',issuer='A',scope='query/series',unit=UNIT,scale=SCALE,reason='strict');kw.update(opts)
            call(h,label,b,'create','bad',expected=3,**kw)
        h.check(call(h,'changed-unit',b,'create',definition='NUMERIC_SUMMARY_V1',issuer='A',scope='query/series',unit='K',scale=2,limit=2,reason='cannot edit',expected=3)['code']=='CONSUMER_EXISTS','definition immutable')
        reason=b'independent numeric request';feed=wire_feed(issuer='A',scope='query/series',payload=True,length=46)[5:]
        tail=struct.pack('!I',len(feed))+feed+struct.pack('!H',len(reason))+reason+struct.pack('!Q',100000)+bytes([4])+b'degC'+bytes([2])+struct.pack('!Q',10**18)
        body=wire(6,'independent',tail).replace(b'NCR1',b'NCR2')
        ok,response=raw_control(d.control,body);h.check(ok and response['consumer']['projection']['definition']=='NUMERIC_SUMMARY_V1','independent NCR2 registration')
        for bad in [body+b'x',body[:-1],body.replace(b'degC',b'bad\0'),wire(8,'numeric').replace(b'NCR1',b'NCR2')]:
            ok,error=raw_control(d.control,bad);h.check(not ok and 'consumer' not in error,'strict numeric envelope never downgrades')
        for v in ['1.25','nan','1e2','+1','01','-0',str(10**12+1),str(-(2**63))]:
            h.run('invalid-native-value-'+str(len(v))+v.replace('/','_'),['submit','--control',str(d.control),'--node','B','--peer','A','--scope','query/series','--operation',operation(v),'--numeric-ticks',v,'--numeric-unit',UNIT,'--numeric-scale','2'],expected=3)
        before=(b/'state.journal').read_bytes()
        for i in range(4):
            call(h,f'empty-status-{i}',b,'status');h.check(read(h,f'empty-page-{i}',b,'numeric')['returned_records']==0,'empty numeric consumer')
        h.check((b/'state.journal').read_bytes()==before,'successful numeric observations are nonmutating')
        d.shutdown()
    case('strict_native_schema_and_independent_request',strict)

    def semantics():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'numeric-semantics');v={}
        first=produce(h,'positive',a,v,ticks=125);second=produce(h,'negative',a,v,ticks=-25)
        bad=produce(h,'invalid-correction',a,v,raw=b'not a number',corrects=first)
        produce(h,'valid-after-invalid',a,v,ticks=150,corrects=bad)
        bad2=produce(h,'bad-original',a,v,raw=b'NaN');produce(h,'bad-after-bad',a,v,raw=payload(2,'K'),corrects=bad2)
        produce(h,'scale-mismatch',a,v,raw=payload(2,scale=3));produce(h,'positive-bound',a,v,ticks=10**12);produce(h,'negative-bound',a,v,ticks=-(10**12))
        produce(h,'zero',a,v,ticks=0)
        for i,raw in enumerate([payload(2)+b'\0',payload(2)[:-1],payload(2).replace(b'degC',b'deg\0'),payload(2,scale=10),payload(2).replace(b'NNO1',b'NNO2'),payload(2**63-1),payload(-2**63),payload(2,'DegC')]):
            produce(h,f'malformed-{i}',a,v,raw=raw)
        produce(h,'hidden-numeric',c,v,ticks=999,issuer='C');create(h,'numeric-create',b,limit=3)
        result,rows=consume(h,'semantics',b,v)
        h.check(len(rows)==18,'only exact visible domain consumed')
        h.check(result['consumer']['projection']['result']['numeric']['sum_ticks']=='125','independent heads after invalid replacement and repair')
        saved=result['consumer']['projection']['result'];revision=result['consumer']['revision']
        rebuilt=call(h,'numeric-rebuild',b,'rebuild',expected_revision=revision,reason='repeat interpretation')
        h.check(call(h,'rebuild-history',b,'status')['consumer']['projection']['retired_results']==[saved],'prior numeric result retained')
        result,again=consume(h,'recompute',b,v);h.check(result['consumer']['projection']['result']==saved and rows==again,'rebuild deterministic')
        h.run('numeric-compact',['compact','--control',str(bd.control)]);bd.shutdown();bd=h.start('numeric-restart',bc,b)
        verify(h,call(h,'numeric-replayed',b,'status'),rows,v)
        (h.output/'NUMERIC-RESULT.json').write_text(json.dumps({'rows':rows,'inputs':{k:x.hex() for k,x in v.items()},'projection':result['consumer']['projection']},indent=2)+'\n')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('independent_corrections_rejections_and_rebuild',semantics)

    def budget():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'numeric-budget');v={}
        produce(h,'at-budget',a,v,ticks=100);create(h,'budget-create',b,max_abs_sum=100,limit=1)
        p=read(h,'budget-page',b,'numeric');r=call(h,'budget-first',b,'process',batch=p['consumer']['pending_batch']['id'])
        produce(h,'over-budget',a,v,ticks=1);p=read(h,'budget-over-page',b,'numeric');before=call(h,'budget-before',b,'status')['consumer'];token=p['consumer']['pending_batch']['id']
        h.check(call(h,'over-budget-process',b,'process',batch=token,expected=3)['code']=='PROJECTION_NUMERIC_SUM_LIMIT','exact sum budget failure')
        h.check(call(h,'budget-state-unchanged',b,'status')['consumer']==before,'no partial result or progress commit')
        h.check(consumer_call(h,'no-generic-ack',b,'ack','numeric',batch=token,expected=3)['code']=='PROJECTION_ATOMIC_TRANSITION_REQUIRED','cannot skip overflowing input')
        h.check(call(h,'forged-numeric-ack',b,'process',batch='01'*32,expected=3)['code']=='CONSUMER_ACK_INVALID','exact page needed')
        create(h,'atomic-budget-create',b,'atomic',max_abs_sum=100,limit=2)
        p=read(h,'atomic-over-page',b,'atomic');h.check(p['returned_records']==2,'two input atomic page')
        call(h,'atomic-over-process',b,'process','atomic',batch=p['consumer']['pending_batch']['id'],expected=3)
        st=call(h,'atomic-unchanged',b,'status','atomic')['consumer'];h.check(st['acknowledged_sequence']==0 and st['projection']['result']['numeric']['sum_ticks']=='0','whole page rolls back, not first accepted prefix')
        bd.shutdown();bd=h.start('budget-restart',bc,b);h.check(call(h,'budget-persisted',b,'status')['consumer']==before,'limit failure persists only old state')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('exact_sum_budget_no_partial_effect',budget)

    def principals():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'numeric-principals',True);expose_control_for_uid(b);v={}
        produce(h,'principal-source',a,v,ticks=321)
        h.check(create(h,'metadata-not-number',b,uid=UID,expected=3)['code']=='LOCAL_CONTROL_CLASS_DENIED','metadata projection grant cannot interpret numeric payload')
        granted=candidate(h,bc,'payload-grant','numeric-payload-g2',lambda s:s.replace(f'local_control={UID},EVIDENCE_READ,CONSUMER,PROJECTION',f'local_control={UID},EVIDENCE_READ,EVIDENCE_PAYLOAD,CONSUMER,PROJECTION').replace(f'evidence_read={UID},A,query/series,METADATA',f'evidence_read={UID},A,query/series,PAYLOAD'))
        activate(h,'grant-payload',b,granted);create(h,'payload-number-create',b,uid=UID)
        p=read(h,'payload-number-read',b,'numeric',uid=UID);token=p['consumer']['pending_batch']['id']
        call(h,'cross-uid',b,'process',uid=SECOND_UID,batch=token,expected=3)
        sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
        # Slow owner request is used below after owner projection creation; UID checks remain covered by real setpriv clients.
        r=call(h,'payload-number-process',b,'process',uid=UID,batch=token)
        revoked=candidate(h,granted,'payload-revoke','numeric-payload-g3',lambda s:s.replace(f'local_control={UID},EVIDENCE_READ,EVIDENCE_PAYLOAD,CONSUMER,PROJECTION',f'local_control={UID},EVIDENCE_READ,CONSUMER,PROJECTION').replace(f'evidence_read={UID},A,query/series,PAYLOAD',f'evidence_read={UID},A,query/series,METADATA'))
        activate(h,'revoke-payload',b,revoked)
        err=call(h,'revoked-result',b,'status',uid=UID,expected=3);h.check(err['code'] in ['CONSUMER_POLICY_CHANGED','LOCAL_CONTROL_CLASS_DENIED'],'aggregate result is payload-derived and reauthorized')
        consumer_call(h,'generic-no-payload-bypass',b,'status','numeric',uid=UID,expected=3)
        create(h,'owner-number-create',b);p=read(h,'owner-number-read',b,'numeric');token=p['consumer']['pending_batch']['id']
        body=wire(7,'numeric',bytes.fromhex(token));sock.settimeout(4);sock.connect(str(bd.control));sock.sendall(struct.pack('!I',len(body))+body[:-1])
        owner_revoked=candidate(h,revoked,'owner-payload-revoke','numeric-payload-g4',lambda s:s.replace(',EVIDENCE_PAYLOAD','').replace(f'evidence_read={os.geteuid()},A,query/series,PAYLOAD',f'evidence_read={os.geteuid()},A,query/series,METADATA'))
        activate(h,'revoke-slow-owner',b,owner_revoked);sock.sendall(body[-1:]);sock.shutdown(socket.SHUT_WR)
        n=struct.unpack('!I',receive_exact(sock,4))[0];reply=receive_exact(sock,n);sock.close()
        h.check(reply[4]==1 and 'projection' not in json.loads(reply[5:]),'slow pre-opened process request uses active payload authority')
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('kernel_principals_payload_revocation_no_bypass',principals)

    def concurrency():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'numeric-concurrent');v={};produce(h,'parallel-numeric',a,v,ticks=-77);create(h,'parallel-create',b)
        p=read(h,'parallel-page',b,'numeric');token=p['consumer']['pending_batch']['id']
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:r=list(pool.map(lambda i:call(h,f'parallel-process-{i}',b,'process',batch=token),range(8)))
        h.check(sum(x['disposition']=='PROJECTED' for x in r)==1,'one numeric result/progress winner');verify(h,r[0],p['records'],v)
        produce(h,'lost-numeric',a,v,ticks=90);q=read(h,'lost-page',b,'numeric');token=q['consumer']['pending_batch']['id']
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as sock:
            sock.connect(str(bd.control));body=wire(7,'numeric',bytes.fromhex(token));sock.sendall(struct.pack('!I',len(body))+body)
        h.wait('lost response numeric commit',lambda:call(h,'lost-observe',b,'status')['consumer']['acknowledged_sequence']==2)
        same=call(h,'lost-repeat',b,'process',batch=token);h.check(same['disposition']=='ALREADY_ACKNOWLEDGED','lost reply retry no double numeric effect');verify(h,same,p['records']+q['records'],v)
        cd.shutdown();ad.shutdown();bd.shutdown()
    case('concurrent_processing_and_lost_reply',concurrency)

    def kills():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'numeric-kills');v={};produce(h,'kill-numeric',a,v,ticks=456);create(h,'kill-create',b)
        page=read(h,'kill-page',b,'numeric');token=page['consumer']['pending_batch']['id'];bd.shutdown()
        for phase,position in [('BEFORE',0),('AFTER',1)]:
            bd=h.start('numeric-kill-'+phase,bc,b,{f'NATRAV_OVERLAY_TEST_PROJECTION_{phase}_COMMIT_MS':'20000'})
            client=subprocess.Popen([str(h.binary),*pargs(b,'process','numeric',batch=token)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            try:
                h.wait('numeric commit marker '+phase,lambda:f'TEST_PROJECTION_{phase}_COMMIT_MS' in bd.stderr_path.read_text(),timeout=5)
                bd.kill();client.communicate(timeout=5)
            finally:
                if client.poll() is None:client.kill();client.communicate()
            bd=h.start('numeric-restart-'+phase,bc,b);r=call(h,'numeric-after-'+phase,b,'status');h.check(r['consumer']['acknowledged_sequence']==position,'numeric progress crash boundary')
            h.check(r['consumer']['projection']['result']['numeric']['sum_ticks']==str(456*position),'sum and position never separated')
            if phase=='AFTER':verify(h,r,page['records'],v);h.check(call(h,'killed-retry',b,'process',batch=token)['disposition']=='ALREADY_ACKNOWLEDGED','durable response loss idempotent')
            bd.shutdown()
        cd.shutdown();ad.shutdown()
    case('hard_kill_numeric_result_progress',kills)

    def maintenance():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'numeric-maintenance');v={};first=produce(h,'stored-valid',a,v,ticks=250);produce(h,'stored-invalid',a,v,raw=b'bad')
        create(h,'maintenance-create',b,limit=1);p=read(h,'maintenance-page',b,'numeric');call(h,'maintenance-process',b,'process',batch=p['consumer']['pending_batch']['id']);pending=read(h,'maintenance-pending',b,'numeric');bd.shutdown()
        keys=h.runtime/'numeric-keys';keys.mkdir(mode=0o700);key=new_key(h,keys,'numeric-state-g1');migrate(h,'numeric-migrate',b,key,'B')
        bd=start_keyed(h,'numeric-keyed',bc,b,key);h.run('numeric-keyed-compact',['compact','--control',str(bd.control)]);bd.shutdown()
        h.check(h.run('numeric-auth-audit',['state-auth-audit','--state',str(b),'--node','B','--state-auth-key',str(key)])['status']=='COMPLETE','authenticated decoder understands numeric results')
        crypt=keys/'backup.key';archive=keys/'numeric.nob';identity=h.identity('B')
        h.run('numeric-backup-key',['backup-key-init','--output',str(crypt),'--generation','numeric-backup-g1'])
        h.run('numeric-export',['backup-export','--state',str(b),'--node','B','--generation','b-g1','--output',str(archive),'--state-auth-key',str(key),'--encrypt-key',str(crypt),'--sign-key',str(identity.private_key),'--sign-cert',str(identity.certificate)])
        before=h.run('numeric-before-restore',['inspect','--state',str(b),'--node','B','--state-auth-key',str(key)]);restored=h.runtime/'numeric-restored'
        h.run('numeric-restore',['backup-restore','--input',str(archive),'--destination',str(restored),'--node','B','--generation','b-g1','--state-auth-key',str(key),'--decrypt-key',str(crypt),'--trusted-cert',str(identity.certificate),'--require-signature','yes','--require-encryption','yes'])
        after=h.run('numeric-restored-inspect',['inspect','--state',str(restored),'--node','B','--state-auth-key',str(key)])
        h.check(before['storage']['logical_state_digest']==after['storage']['logical_state_digest'],'numeric state exactly preserved by encrypted signed restore')
        moved=candidate(h,bc,'numeric-relocated','numeric-relocated-g1',lambda s:s.replace(f'state={b}',f'state={restored}'))
        h.run('numeric-relocate',['state-relocate','--state',str(restored),'--node','B','--candidate',str(moved),'--reason','explicit numeric relocation','--state-auth-key',str(key)])
        bd=start_keyed(h,'numeric-restored',moved,restored,key);replay=read(h,'numeric-restored-page',restored,'numeric')
        h.check(replay['records']==pending['records'] and replay['consumer']['pending_batch']==pending['consumer']['pending_batch'],'same outstanding numeric page after relocation')
        r=call(h,'numeric-restored-process',restored,'process',batch=pending['consumer']['pending_batch']['id']);rows=p['records']+pending['records'];verify(h,r,rows,v)
        produce(h,'post-restore-correction',a,v,ticks=-75,corrects=first);r,rows=consume(h,'after-restore',restored,v,rows=rows)
        h.check(r['consumer']['projection']['result']['numeric']['sum_ticks']=='-75','corrected sum after restored continuation')
        h.run('numeric-post-compact',['compact','--control',str(bd.control)]);bd.shutdown()
        h.check(h.run('numeric-post-audit',['state-auth-audit','--state',str(restored),'--node','B','--state-auth-key',str(key)])['status']=='COMPLETE','numeric post-continuation checkpoint verified')
        cd.shutdown();ad.shutdown()
    case('keyed_compaction_encrypted_restore_relocation',maintenance)

    def corruption():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'numeric-corruption');v={};produce(h,'corrupt-number',a,v,ticks=77);create(h,'corrupt-create',b)
        p=read(h,'corrupt-read',b,'numeric');call(h,'corrupt-project',b,'process',batch=p['consumer']['pending_batch']['id']);bd.shutdown();journal=b/'state.journal';original=journal.read_bytes()
        def numeric_sum_offset(body):
            start=body.rfind(b'NPR2');h.check(start>0,'independent numeric format found');unitlen=body[start+4]
            return start+4+1+unitlen+1+8+8+32+72+4*8
        frames=[];off=0
        while off<len(original):
            n=struct.unpack_from('!I',original,off+4)[0];body=original[off+8:off+8+n];frames.append((off,n,body));off+=40+n
        updates=[x for x in frames if x[2][0]==27];h.check(len(updates)==3,'one create/issue/project')
        at,n,body=updates[-1];body=bytearray(body);struct.pack_into('!q',body,numeric_sum_offset(body),78)
        checksum=hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest();journal.write_bytes(original[:at+8]+body+checksum+original[at+40+n:])
        h.check(h.run('numeric-forged-effect',['inspect','--state',str(b),'--node','B'],expected=3)['code']=='JOURNAL_CORRUPT','numeric value recomputed from payload despite valid checksum')
        journal.write_bytes(original);at,n,_=updates[1];journal.write_bytes(original[:at]+original[at+40+n:])
        h.check(h.run('numeric-missing-issue',['inspect','--state',str(b),'--node','B'],expected=3)['code']=='JOURNAL_CORRUPT','required issuance cannot be deleted')
        journal.write_bytes(original);bd=h.start('numeric-corruption-restored',bc,b);h.run('numeric-corrupt-compact',['compact','--control',str(bd.control)]);bd.shutdown()
        compact=journal.read_bytes();n=struct.unpack_from('!I',compact,4)[0];body=bytearray(compact[8:8+n]);h.check(body[:5]==b'\x12NCP3','checkpoint contract')
        cursor=1+4+1+4+8;flag=body[cursor];cursor+=1+(8 if flag else 0);cursor+=24;flag=body[cursor];cursor+=1+(32 if flag else 0);marker=body[cursor];cursor+=1
        if marker:size=struct.unpack_from('!H',body,cursor)[0];cursor+=2+size+8
        digest_offset=cursor;logical_start=cursor+32+8+8;h.check(body[logical_start:logical_start+4]==b'NLS2','logical state offset')
        struct.pack_into('!q',body,numeric_sum_offset(body),78);body[digest_offset:digest_offset+32]=hashlib.sha256(b'NATRAV_OVERLAY_LOGICAL_STATE_V2\0'+body[logical_start:]).digest()
        journal.write_bytes(compact[:8]+body+hashlib.sha256(b'NATRAV_OVERLAY_JOURNAL_RECORD_V1\0'+body).digest())
        h.check(h.run('numeric-forged-checkpoint',['inspect','--state',str(b),'--node','B'],expected=3)['code']=='JOURNAL_CORRUPT','checkpoint reconstructs exact numeric source values')
        journal.write_bytes(compact);cd.shutdown();ad.shutdown()
    case('semantic_numeric_journal_and_checkpoint_corruption',corruption)

    def bounded_pages():
        a,b,c,ac,bc,cc,ad,bd,cd=trio(h,'numeric-pages');v={}
        for i in range(140):
            label=f'numeric-page-source-{i}';args=['submit','--control',str(ad.control),'--node','A','--peer','B','--scope','query/series','--operation',operation(label),'--numeric-ticks',str(i-70),'--numeric-unit',UNIT,'--numeric-scale','2'];h.run(label,args);v[operation(label)]=payload(i-70)
            h.wait('numeric cumulative receipts',lambda:h.status('numeric-aggregate',a)['peers'][0]['acked']>=i+1)
        create(h,'pages-create',b,limit=128);r,rows=consume(h,'bounded-pages',b,v)
        h.check(len(rows)==140,'all real TLS numeric observations consumed')
        for i in range(31):r=call(h,f'numeric-epoch-{i}',b,'rebuild',expected_revision=r['consumer']['revision'],reason='R'*256)
        r,rows=consume(h,'after-epochs',b,v);st=call(h,'full-numeric-history',b,'status')
        h.check(len(st['consumer']['projection']['retired_results'])==31,'full bounded numeric history inspectable')
        h.check(call(h,'numeric-history-limit',b,'rebuild',expected_revision=st['consumer']['revision'],reason='full',expected=3)['code']=='CONSUMER_HISTORY_LIMIT','fixed adoption history')
        for command in h.commands:
            if command['returncode']==0 and command['args'][0] in ['projection-status','projection-process','consumer-read']:
                h.check(len(command['stdout'].strip().encode())<=60000,'complete numeric response remains within bound')
        (h.output/'BOUNDED-NUMERIC.json').write_text(json.dumps({'records':140,'epochs':32,'result':st['consumer']['projection']['result'],'status_bytes':len(json.dumps(st,separators=(',',':')))},indent=2)+'\n')
        h.run('numeric-epochs-compact',['compact','--control',str(bd.control)]);bd.shutdown();bd=h.start('numeric-epochs-restart',bc,b)
        verify(h,call(h,'numeric-epochs-restored',b,'status'),rows,v);cd.shutdown();ad.shutdown();bd.shutdown()
    case('annotated_pages_and_full_rebuild_history_bounds',bounded_pages)

def main()->int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--binary',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--case',action='append');a=p.parse_args()
    if a.output.exists():p.error('output must not exist')
    h=Harness(a.binary,a.output);begin=time.time();passed=False
    try:cases(h,set(a.case) if a.case else None);passed=True
    except BaseException as e:(h.output/'FAILURE.txt').write_text(f'{type(e).__name__}: {e}\n');print(f'FAIL: {type(e).__name__}: {e}',file=os.sys.stderr)
    finally:
        h.cleanup();summary={'format':'NATRAV_OVERLAY_NUMERIC_PROJECTION_TESTS_V1','status':'PASS' if passed else 'FAIL','binary_sha256':hashlib.sha256(h.binary.read_bytes()).hexdigest(),'cases_total':len(h.cases),'cases_passed':sum(c['status']=='PASS' for c in h.cases),'assertions':h.assertions,'commands':len(h.commands),'elapsed_seconds':time.time()-begin}
        for name,value in [('SUMMARY',summary),('CASES',h.cases),('COMMANDS',h.commands)]: (h.output/(name+'.json')).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
        print(json.dumps(summary),flush=True)
    return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
