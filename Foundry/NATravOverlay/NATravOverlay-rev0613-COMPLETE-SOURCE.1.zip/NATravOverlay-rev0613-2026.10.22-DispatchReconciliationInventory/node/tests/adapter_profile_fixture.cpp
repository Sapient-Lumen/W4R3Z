#include <algorithm>
#include <cerrno>
#include <cstddef>
#include <fcntl.h>
#include <string>
#include <string_view>
#include <sys/socket.h>
#include <unistd.h>
#include <vector>

#ifndef NATRAV_FIXTURE_MARKER
#define NATRAV_FIXTURE_MARKER "UNSET"
#endif

extern char** environ;

namespace {

void append_field(std::string& out, const std::string_view key, const std::string_view value) {
    out.append(key);
    out.push_back('=');
    out.append(value);
    out.push_back('\n');
}

}  // namespace

int main(int argc, char* argv[]) {
    std::string report;
    append_field(report, "marker", NATRAV_FIXTURE_MARKER);
    append_field(report, "argc", std::to_string(argc));
    for (int index = 0; index < argc; ++index) {
        append_field(report, "argv", argv[index] == nullptr ? "<null>" : argv[index]);
    }
    std::vector<std::string> environment;
    for (char** item = environ; item != nullptr && *item != nullptr; ++item) {
        environment.emplace_back(*item);
    }
    std::sort(environment.begin(), environment.end());
    append_field(report, "env-count", std::to_string(environment.size()));
    for (const auto& item : environment) {
        append_field(report, "env", item);
    }
    std::vector<int> extra_descriptors;
    for (int descriptor = 4; descriptor < 256; ++descriptor) {
        errno = 0;
        if (::fcntl(descriptor, F_GETFD, 0) >= 0 || errno != EBADF) {
            extra_descriptors.push_back(descriptor);
        }
    }
    append_field(report, "extra-fd-count", std::to_string(extra_descriptors.size()));
    for (const auto descriptor : extra_descriptors) {
        append_field(report, "extra-fd", std::to_string(descriptor));
    }
    const auto sent = ::send(3, report.data(), report.size(), MSG_NOSIGNAL);
    return sent == static_cast<ssize_t>(report.size()) ? 0 : 91;
}
