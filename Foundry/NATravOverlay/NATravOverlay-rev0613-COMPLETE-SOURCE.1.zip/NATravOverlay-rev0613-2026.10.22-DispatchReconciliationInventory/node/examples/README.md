# Configuration examples

The baseline templates illustrate `NATRAV_OVERLAY_CONFIG_V8`; scoped and consumer variants explicitly use V10 and V11, projections use V12, `node-a-multiroute.conf` demonstrates V13, and `node-a-local-source.conf` demonstrates V14 without any peer route. Replace paths, pins, ports, runtime/key generation IDs, authorization rules, limits, session bounds, and numeric local-administrator UIDs with values for nodes you control. Repeated-letter pins are placeholders and intentionally fail identity validation without matching certificate material.

Create identities with `identity-init`, copy each reported SPKI digest into the local `identity_pin` and the remote node's `peer_key`, then run `config-check`.

`local_control=UID,CLASS,...` is exact. `ALL` grants the six original administrative control classes to that UID. The examples use UID `1000` as a placeholder. The daemon still creates the state directory and socket as owner-only; delegated UIDs need separately deliberate filesystem or ACL access.

Session settings bound reusable post-TLS/HELLO `NOS1` sessions. Operations remain sequential; there is no in-session pipelining in this revision.

In V6–V12, `peer=` provides one outbound route and delivery policy. In V13–V18, `peer=` provides only delivery policy and one through eight `peer_route=` records provide stable numeric route candidates. `peer_key=` assigns exact generations. `ACTIVE` is selected for new work, `RETIRED` supports existing bound work and inbound staged continuity, and `REVOKED` is rejected. `authorize=` is exact inbound policy. The only current action resource is `counter.add`.

Global and per-peer pending-record/payload limits are checked before admission or explicit reopening. Pending work reserves one record plus its immutable payload bytes until receipt, terminal rejection, cancellation, or expiry.

Editing a startup file is not activation for an existing versioned state. Use live activation/rollback. For a verified restore at a different state path, use explicit offline `state-relocate`; relocation must preserve the exact accepted local-control and authoring policies. See [Configuration](../../docs/CONFIGURATION.md).


## Optional keyed state

The V8 examples remain valid without a storage-format change. Adopt an existing stopped node with `state-auth-migrate`, then add `--state-auth-key FILE` to its `run` launch. Do not put state-key bytes or path in a `local_control`, peer or authorization field. The key must be separately provisioned for offline backup/restore, inspection and relocation. Read [State authentication](../../docs/STATE-AUTHENTICATION.md) before treating a snapshot as fresh or assuming an incomplete authenticated append can be repaired automatically.

## Explicit read-enabled V9 adoption

The existing example files remain V8 compatibility templates. For evidence queries, deliberately change the header to `NATRAV_OVERLAY_CONFIG_V9`, choose a fresh runtime_generation, and replace the owner's ALL shorthand with the explicit eight-class list in [Evidence queries](../../docs/EVIDENCE-QUERIES.md). Keep exact numeric UID grants. Do not treat an issuer/scope query filter as an authorization restriction. Existing state adopts the candidate through config-activate, not an unrecorded startup-file edit.

## Scoped V10 delegation

`node-b-scoped.conf` is the explicit scoped successor template. UID 1000 is administrative only; UID 1001 receives one payload domain and UID 1002 receives that domain's metadata. Replace placeholder identities and UIDs with deliberately controlled values. Every read-capable V10 UID needs exact domains. V9 remains node-wide compatibility, not scoped security. Read [Scoped reads](../../docs/SCOPED-READS.md) before delegating.

## V11 durable consumers

`node-b-consumers.conf` adds CONSUMER for two exact scoped readers and CONSUMER_ADMIN only for the payload reader. Consumer names are UID-local. Creating/reading/acknowledging a consumer does not grant reset authority, and reset cannot act as another owner. No template widens filesystem reachability. Read [Durable consumers](../../docs/DURABLE-CONSUMERS.md). Native template checks substitute temporary generated identities; no generated credentials are retained. See the current package-verification record for results.

`node-b-projection.conf` adds explicit V12 PROJECTION authority for exact-domain metadata processing. UID 1001 may rebuild its own results; UID 1002 may process but not rebuild. The placeholder pins and local identity files must be provisioned for an actual deployment. No template enables its features merely through file presence; the complete configuration must be explicitly adopted.

Revision 0511 also uses node-b-projection.conf for NUMERIC_SUMMARY_V1. Only UID 1001 has the required payload classes/domain; UID 1002 remains metadata-only. Native submit/revise accepts --numeric-ticks, --numeric-unit and --numeric-scale. See [Numeric projections](../../docs/NUMERIC-PROJECTIONS.md). No additional identity or configuration version is required.

Revision 0512 uses the same V12 template for explicit automatic processing: UID 1001 can enable/pause an owned projection with CONSUMER_ADMIN and its exact reader grants. UID 1002 lacks administration and cannot enable a schedule merely because it can manually process metadata. No background work is enabled by the template itself. See [automatic controls](../../docs/AUTOMATIC-PROJECTIONS.md).

Revision 0513 uses those same explicit `CONSUMER_ADMIN` grants for exact-owner terminal retirement. No new configuration version or implicit authority is added. Retiring preserves the final result, gives an issued page an explicit unacknowledged disposition, releases an active slot into a bounded archive, and permanently reserves the name. See [retirement](../../docs/CONSUMER-RETIREMENT.md).

## V13 multi-route example

`node-a-multiroute.conf` separates B's delivery policy from two stable routes. The example uses loopback IPv4 and IPv6 placeholders so it remains numeric and self-contained; replace them with endpoints for peers you control. Every candidate must authenticate as the same configured B generation/SPKI. Route priority is explicit; file order is not policy. See [multi-route reachability](../../docs/MULTI-ROUTE.md).

## V14 local-source example

`node-a-local-source.conf` gives the explicit UID 1000 an exact `observations/temperature` authoring rule and separate payload-read/projection permissions. It needs no peer route. Use native `evidence-author` / `evidence-amend` to create local data; `submit` still means recipient-addressed outbound work. Replace the UID, identity files and public pin with values for the owned instance. Author permission does not imply disclosure or a remote subscription. See [local evidence sources](../../docs/LOCAL-EVIDENCE.md).

## V15 source-disclosure example

`node-a-source-subscription.conf` adds explicit SOURCE_DISCLOSE and one exact finite source grant. It distinguishes manager UID, source author UID, subscriber generation, scope and budgets. `node-c-source-subscriber.conf` shows the matching authenticated subscriber route and provider key. The subscriber may request only that already accepted grant. The provider manager may step it explicitly or enable a separate finite automatic-delivery grant; the subscriber cannot create that automation authority. Replace UIDs and pins with intentionally configured identities. The subscriber must independently authorize incoming A evidence in the scope. See [source subscriptions](../../docs/SOURCE-SUBSCRIPTIONS.md) and [subscriber requests](../../docs/SUBSCRIBER-REQUESTS.md).


## V16 subscription-lease example

`node-a-subscription-lease.conf` extends the V15 provider example with an immutable lease generation, a one-day finite duration, and `RETAIN` pending-delivery policy. `CANCEL` is the alternative exact policy. The matching subscriber may request/status the lease and may withdraw only its exact retained instance and revision. Neither policy recalls bytes or creates renewal authority. See [subscription leases](../../docs/SUBSCRIPTION-LEASES.md).

## Recipient view example

`node-c-source-view.conf` demonstrates explicit V17 import and separate target-domain read authority. Its repeated-digit identity and subscription values are placeholders, not credentials or trusted pins. Supply exact approved values before use. No peer grant or import is created by parsing the template.

## Recipient import automation (0527)

`node-c-source-view.conf` remains V17. Accepting that view does not schedule any
imports. Its exact SOURCE_IMPORT manager may separately use
`source-view-auto-enable`, `source-view-auto-pause`, and `source-view-auto-status`
with finite import/inspection allowances. See the [automatic-import contract](../../docs/AUTOMATIC-IMPORTS.md).
Read and payload authority remain separate, and remote providers cannot enable
the recipient worker. The example is a template, not an approved subscription.

## Import decision review and retry (0528)

Existing V17 view and SOURCE_IMPORT grants are sufficient; no new configuration template or implied read permission is required. See [bounded decision review](../../docs/IMPORT-DECISIONS.md) for exact prefix pagination, pause-before-retry, and current configuration selection.

## V18 durable action-result example

`node-b-action-results.conf` separates inbound `counter.add` permission from permission to return a terminal result. The exact `action_result=` rule binds A's active key generation, the action resource, and one evidence result scope. A must independently authorize B evidence in that result scope. Missing V18 result policy rejects a new action before admission; older V6–V17 configurations retain their local-only action behavior. Replace the placeholder UID, identity files, pin, route and generation with owned values. See [durable action results](../../docs/ACTION-RESULTS.md).

## Exact recipient-side result correlation (revision 0545)

Pair [node-a-action-correlation.conf](node-a-action-correlation.conf) with [node-b-action-results.conf](node-b-action-results.conf). A admits B's result scope and grants UID 1000 the distinct administrative inspection and exact payload-read permissions needed by `action-result-query`. Replace IDs, private paths, pins and the exact local UID deliberately. These examples are not credentials or automatic trust enrollment.

## Request-centric result discovery (revision 0546)

The same requester example also authorizes `action-result-discover`. Begin with the retained original request ID, provider and exact result scope; no result ID is needed. Every continuation rechecks current permissions and the complete selected candidate/request binding. See [result discovery](../../docs/RESULT-DISCOVERY.md). An incomplete scan is not a unique or verified effect.
