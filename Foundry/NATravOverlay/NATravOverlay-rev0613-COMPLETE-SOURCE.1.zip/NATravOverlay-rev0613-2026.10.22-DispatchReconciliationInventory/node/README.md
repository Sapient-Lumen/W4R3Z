# Native C++ node

```sh
JOBS=2 ./build.sh static
./bin/natrav-overlay version
```

The normal executable has no Python, shell, NATrav, relay, or external-service runtime dependency. It links OpenSSL for TLS, Ed25519 identity/signatures, AES-256-GCM/HKDF backup encryption, and HMAC-SHA-256 state authentication.

## Private finite custody-envelope model (0605)

The ordinary build compiles `custody_envelope.cpp` and reports
`PRIVATE_FINITE_CUSTODY_ENVELOPE_MODEL_V1`, but `configured_custody_relay` is
false. `NHCE0001` signs an explicit loop-free route around one unchanged
`NHCP0001` capsule digest. `NHCR0001` alternates exact signed transfer and
acceptance records with finite hop, expiry, sequence, duplicate and history
bounds. Final custody acceptance is not application delivery.

No configuration parser, connector, listener, daemon path or durable state
consumer includes this private model. Run its focused suite with:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -B tests/run_custody_envelope.py \
  --binary bin/natrav-overlay --output /tmp/natrav-0605-custody
```

See [the model contract](../docs/CUSTODY-ENVELOPE-MODEL.md). A later revision
must bind exact parties and next-hop permission to accepted configuration and
durable state before any ordinary node may relay.

## Persistent product path

```text
run
→ exclusive state ownership
→ transport listener + TLS peer sessions + Unix control socket
→ SO_PEERCRED exact-UID authorization
→ durable peer, outbox, action, consumer, projection and subscription schedulers
```

Configuration formats V6–V19 remain strict and backward readable. V20 adds immutable handoff-key commitments and explicit succession/retirement/revocation; see [the contract](../docs/HANDOFF-KEY-POLICY.md). V19 retains immutable operator-pinned adapter profiles and endpoint generations through the existing authenticated configuration journal. V13 adds bounded peer routes, V14 explicit local evidence authorship, V15 finite source disclosure, V16 immutable finite subscription leases, V17 recipient source views, and V18 exact action-result disclosure. Use `config-check` before startup; existing versioned state follows accepted journal configuration rather than unrecorded startup-file edits.

## Current strengthened serial packet model (0599)

The same `bin/natrav-overlay` executable also implements the supervised
`serial-packet-adapter` role. It is selected by an exact image-pinned V19 profile
and exact argument vector, not by a new route syntax or device discovery.
Configured routes/listeners still use
`adapter-endpoint-v1|id=<endpoint>|generation=<generation>`.

The core supplies descriptor 3, a Unix `SOCK_SEQPACKET` endpoint carrying
`NAPA0001`. The child opens one explicit TTY using canonical line parameters,
frames complete datagrams as bounded `NSP1`, and provides no peer identity,
authority or application receipts. TLS/HELLO/NOS1 stay in the parent stack.

Read [the serial packet contract](../docs/framed-serial-packet-adapter.md) for
all required profile arguments, framing, queue bounds and failure semantics.
Run the focal model against a **fresh output directory**, never production state:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -B tests/run_serial_packet_adapter.py \
  --binary bin/natrav-overlay --output /tmp/natrav-0599-serial-focal
```

The packet role uses a crash-released cooperative `flock` lease so a killed
child can be reconstructed. This is advisory: nonparticipating processes,
including the unchanged direct serial carrier, are not excluded by that lock.
Do not assign one physical TTY simultaneously to unrelated profiles/carriers.
Existing direct serial behavior, including its `TIOCEXCL` policy, is unchanged.
Revision 0599 additionally enforces an exact worst-case line serialization
lower bound, exercises whole-frame reordering, replaces an actual PTY under
exact profile/endpoint succession, and proves unrelated TCP progress during the
serial outage. Read
[the serial-model succession contract](../docs/SERIAL-MODEL-SUCCESSION.md).
PTY tests are not hardware tests. Current evidence is under
[revision 0599](../validation/revision-0599/STATUS.json).

## Historical carrier milestones through 0589

The following private-adapter restrictions describe their original milestones.
Revision 0596 made exact accepted V19 profiles executable as configured routes
and listeners; they are no longer private-only in the current product.

Revision 0577 concentrated TCP behind `TransportLocator`,
`TransportConnector`, `TransportListener`, and owned `OrderedByteStream`.
Revision 0578 moved peer TLS onto a private custom OpenSSL BIO over
`ByteChannel`, eliminating peer-layer descriptor recovery.

Revision 0579 added a private deterministic virtual stream. Revisions
0581–0583 added and verified the finite packet service and private packet
ordered-stream adapter. Revision 0580 added the explicit POSIX serial carrier,
revision 0584 added numeric point-to-point UDP, and revision 0586 extracted the
owned complete-datagram packet-port seam.

Revision 0588 adds the second configured packet carrier:

```text
unix-dgram-v1|local=/run/user/1000/natrav/a.sock|remote=/run/user/1000/natrav/b.sock|mtu=1200|link=554e495844473031|epoch=7|profile=1
```

The local and remote fields are canonical absolute filesystem paths. Parent
directories must be owned by the effective user and inaccessible to group and
other users. The carrier refuses pre-existing local occupants, traverses parent
components without following symlinks, binds an owner-only nonblocking Unix
datagram socket, filters exact source paths and credentials, rejects
truncation, detects path replacement, and cleans up only the exact socket object
it created and still observes.

`PacketPortOrderedByteStream` continues to own fragmentation, reassembly,
acknowledgment, retransmission, duplicate suppression, expiry, logical packet
time, semantic finish, and ordered reconstruction. The Unix carrier supplies
only bounded complete datagrams and lifecycle ownership. TLS identity, HELLO,
NOS1, application operations, durable receipts, and recovery remain above
filesystem coordinates.

Revision 0587 remains a failed wrapper attempt: it ran the build command from
the wrong directory, exited `127`, and produced no product or source archive.
Revision 0588 reconstructs from the verified revision-0586 source and retains
that failure as provenance.

Revision 0589 adds a private supervised process implementation of
`OwnedCompleteDatagramPacketPort`. The core creates a Unix `SOCK_SEQPACKET`
socketpair, gives the child only descriptor 3 and a minimal environment, and
uses canonical bounded `NAPA0001` request/response frames. The child is
protocol-untrusted and cannot supply peer identity, authorization, receipts,
custody, route policy, or relay permission. It is not registered as an ordinary
configured carrier in this revision.

The legacy one-shot `offer`, `flush`, and `serve` command-line paths remain TCP
only. Persistent configured nodes can select TCP, serial, UDP, or Unix-domain
datagrams through the same authenticated session stack.

```sh
python3 tests/run_external_packet_adapter.py \
  --binary bin/natrav-overlay \
  --output /tmp/natrav-external-adapter

python3 tests/run_unix_datagram_transport.py \
  --binary bin/natrav-overlay \
  --output /tmp/natrav-unix-datagram

python3 tests/run_packet_port.py \
  --binary bin/natrav-overlay \
  --output /tmp/natrav-packet-port

python3 tests/run_udp_adversary.py \
  --binary bin/natrav-overlay \
  --output /tmp/natrav-udp-adversary
```

See [the supervised external adapter contract](../docs/EXTERNAL-PACKET-ADAPTER.md),
[the Unix-domain datagram carrier contract](../docs/UNIX-DATAGRAM-PACKET-CARRIER.md),
[the owned packet-port contract](../docs/PACKET-PORT.md),
[the UDP adversary contract](../docs/UDP-DATAGRAM-ADVERSARY.md),
[the UDP carrier contract](../docs/UDP-PACKET-CARRIER.md),
[the serial carrier contract](../docs/SERIAL-TRANSPORT.md),
[the finite packet contract](../docs/PRIVATE_FINITE_PACKET_LINK.md),
[the TLS/ByteChannel contract](../docs/TLS-BYTE-CHANNEL.md), and
[the transport-extraction contract](../docs/TRANSPORT-EXTRACTION.md).

## Compact source progress

Revision 0555 journals ordinary manual/automatic issue and acknowledgment as strict `NST3` transactions. They bind the exact predecessor, active disclosure configuration, one source/outbox or durable receipt, and finite automatic allowance. Historical full-state `NST1`/`NST2` remains readable; complete checkpoints and complex transitions keep full validation. See [the compact progress contract](../docs/COMPACT-SOURCE-PROGRESS.md).

## Structural source selectors

Revision 0556 adds opt-in `--response-format compact` with an exact `SPSC1` selector, leaving default legacy `state_digest` unchanged. Succession and terminal reconciliation accept explicit structural alternatives; all current UID, policy, lease and receipt checks remain required. Ordinary corrections use an acknowledged canonical ancestry index while full validation retains independent reconstruction. See [the selector contract](../docs/STRUCTURAL-SOURCE-SELECTORS.md).

## Command-scoped source preparation

Revision 0557 shares one privately prepared envelope and accepted source configuration across candidate, preflight and live application within the same locked manual command. Revision 0558 lets the earlier automatic permanent-block classifier produce a private single-use envelope for that same preparation, so successful manual and automatic ISSUE each construct once. Exact source/policy/predecessor/outbox checks and both real-receipt checks remain; replay and full canonical boundaries accept neither object. See [the preparation contract](../docs/SOURCE-PREPARATION.md) and [automatic eligibility contract](../docs/AUTOMATIC-SOURCE-ELIGIBILITY.md).

## Exact-byte-bound source transaction preparation

Revision 0559 parses NST3 once inside the locked progress command and shares only the immutable decoder result. Exact bytes and origin are checked before append as well as at each semantic use. Both semantic checks, actual receipts, and the normal inner outbox decoder remain. Untrusted replay still parses independently. See [the transaction contract](../docs/PARSED-SOURCE-PROGRESS.md).

## Source outbound syntax and ownership

Revision 0560 reuses the exact nested evidence-record syntax in the same locked source command while retaining both inner validations, policy parsing and independent replay/generic-writer decoding. Revision 0561 makes the strict composite decoder return a private move-only owner, removing its local decoded-payload copy without adding a cache or semantic shortcut. See [nested source admission](../docs/SOURCE-OUTBOUND-ADMISSION.md) and [composite ownership](../docs/SOURCE-COMPOSITE-OWNERSHIP.md). Revision 0562 keeps the complete outgoing composite as a strict command-local slice inside the immutable NST3 owner, while generic replay remains fully owned. See [command-local composite slices](../docs/COMMAND-LOCAL-SOURCE-COMPOSITE-SLICES.md). Revision 0563 transfers the already-decoded evidence payload into canonical outbox state only after synchronized journal publication; replay and generic writers retain owned copies, and any post-publication application failure poisons the writer until restart. See [durable source-payload transfer](../docs/DURABLE-SOURCE-PAYLOAD-TRANSFER.md).

## Current source-subscription commands

Provider local control:

```text
source-subscription-create
source-subscription-step
source-subscription-status
source-subscription-retire
source-subscription-auto-enable
source-subscription-auto-pause
source-subscription-auto-status
source-subscription-succeed
source-subscription-reconcile
```

Subscriber peer control:

```text
source-subscription-request
source-subscription-remote-status
source-subscription-withdraw
```

V16 withdrawal requires the exact lease generation, instance, revision, authenticated subscriber identity, and bounded reason. See [subscription leases](../docs/SUBSCRIPTION-LEASES.md).

## Live authenticated head

`./bin/natrav-overlay state-head --control state-a/control.sock` returns a bounded current-head sample under current INSPECT authority. It is observational, not a disk re-audit or external anchor update. Opening expectations are explicitly separate from later samples, and unkeyed state returns no selector. Read [the live-head contract](../docs/LIVE-STATE-HEAD.md) before using a captured selector for a subsequent open.

## Durable state and recovery

Use `state-auth-key-init`, `state-auth-migrate`, and `state-auth-rotate` for authenticated state. Ordinary keyed startup fails closed. `state-auth-audit` reports a verified boundary; `state-auth-recover` explicitly adopts only an eligible incomplete tail while preserving the entire source.

`compact`, signed/encrypted backup commands, `backup-restore`, and `state-relocate` retain application obligations and configuration provenance. Authentication does not establish snapshot freshness.

## Evidence applications

The node includes exact local authorship, scoped query/feed APIs, durable consumers, metadata and fixed-point numeric projections, finite automatic internal processing, result publication, correction channels and epochs, and finite provider source disclosure. These remain separate authorization domains.

## Tests

Each `tests/run_*.py` launches the compiled binary as an independent process and writes machine-readable results. Python is test scaffolding only. Output directories must not already exist.

```sh
python3 tests/run_subscription_leases.py \
  --binary bin/natrav-overlay \
  --output /tmp/natrav-subscription-leases
```

Generate identities, keys, state, backups, and results outside the source tree.

## Terminal recipient views

`source-view-retirement-status` selects the exact retained account; `source-view-retire` stops future imports while preserving evidence and separately authorized reads. See [the retirement contract](../docs/VIEW-RETIREMENT.md).

## Exact action metadata and bounded scheduling

`action-query` retrieves admitted source, reservation, attempt summary and counter result under current INSPECT. It does not execute or cancel an action. See [the action-inspection contract](../docs/ACTION-INSPECTION.md).

The counter-action worker uses replay-derived readiness and expiry indexes and revalidates one narrow selection before begin, expiry and completion. It no longer copies a pending-action vector on every turn. See [the action-selection contract](../docs/ACTION-SELECTION.md).


## Durable counter-action results

V18 nodes require an exact `action_result=PEER,GENERATION,counter.add,SCOPE` rule for newly admitted counter actions. Terminal executed, cancelled and expired states commit with a canonical NAC1 evidence obligation in the ordinary outbox. The result uses the source issuer's exact accepted generation/SPKI and preserves the distinction between the local counter-effect receipt and the later remote delivery receipt. See [the action-result contract](../docs/ACTION-RESULTS.md).

## Exact received action-result correlation

`action-result-query --control PATH --operation RESULT_HEX64 --request ACTION_HEX64 --provider ID --scope SCOPE` requires current `INSPECT` plus metadata/payload access to the exact result domain. It verifies retained authenticated admission and request/key/digest bindings, separates claims from receipts, reports conflicts, and makes no state mutation on success. [Contract](../docs/ACTION-RESULT-CORRELATION.md).

`action-result-review` creates exact recipient decisions and `action-result-review-status` retrieves their complete owner-bound accounts; see [the contract](../docs/RESULT-REVIEWS.md). Revision 0549 adds `action-result-review-history --request HEX64 --provider ID --scope SCOPE` for bounded immutable summaries, optional exact review filtering, and owner-scoped retained-prefix pages. [History contract](../docs/REVIEW-HISTORY.md).

## Owner-scoped consumer inventory (0549)

`consumer-inventory` now locates current eligible consumer and projection identities with exact filters, bounded pages, and a selected-metadata commitment. Current kernel ownership and domain authority apply before visible counts. Old adopted authority must match current authority; otherwise the read inventory hides the record. No payload, projection result, automatic grant or full consumer history is returned. See the [inventory contract](../docs/CONSUMER-INVENTORY.md). Listings are observational. Existing finite registries and non-reusable retired names remain unchanged.



Revision 0564 adds optional `--expected-state-head NASH1:...` checks to keyed state-opening commands. The separately supplied token is checked only after authentication and semantic replay. It does not authorize recovery, advance itself, or turn an observed old head into a freshness oracle. See [external state expectations](../docs/EXTERNAL-STATE-EXPECTATIONS.md) for exact command and representation scopes.

## Correlated stopping and terminal heads (revisions 0568–0569)

Add `--correlation TOKEN` to `shutdown` or `drain-shutdown` to select strict NOC1 kinds 44/45. Combine it with `--final-state-head yes` to select kinds 46/47 and receive the deferred terminal authenticated-head response after writer joins and final lifecycle accounting. Tokens are canonical lowercase ASCII, 1–64 bytes, and are bound into the existing request ID. They are provenance labels only: duplicate requests are not suppressed, response delivery is not proved, and current authority remains mandatory. See [ordinary correlated stopping](../docs/CORRELATED-STOPPING.md) and [correlated terminal heads](../docs/CORRELATED-TERMINAL-STATE-HEAD.md).

## Offline correlated-stop audit (0570)

`correlated-stop-audit` completely authenticates and semantically replays an existing keyed stopped state without opening a writer or starting workers. Select by exact request ID or by the original correlated immediate/drain request shape. The bounded response includes the current `NASH1` head, every matching decision/lifecycle row, aggregate stop outcome, and current pending obligations. Duplicates are preserved; payloads and free-text reasons are omitted. See [the offline audit contract](../docs/OFFLINE-CORRELATED-STOP-AUDIT.md).

## Direct backup-contained stop audit (0571/0572 delivery)

`backup-correlated-stop-audit` verifies and decrypts a signed encrypted backup,
authenticates and semantically replays its embedded keyed checkpoint, and
returns the same bounded correlated-stop provenance report as the stopped-state
directory audit. It creates no restore destination and starts no writer or
worker. See [the backup audit contract](../docs/BACKUP-CORRELATED-STOP-AUDIT.md).

## Detached state-head custody (0572)

`state-head-custody-create`, `state-head-custody-read`, and
`state-head-custody-advance` manage one explicit owner-only canonical record
outside node state. Advancement is an exact old-account compare-and-swap with a
strictly greater custodian generation and atomic same-directory publication.
Nothing discovers or advances the record automatically. See
[the detached custody contract](../docs/DETACHED-STATE-HEAD-CUSTODY.md).

## Custody-constrained state opening (0573)

Commands that already accept an exact external authenticated head can instead
supply one explicit `NHCUST01` record together with its custody domain,
generation, and complete-file digest. The record is strictly verified and
rechecked; only its exact `NASH1` selector enters the existing complete state
matcher. Custody is never discovered or advanced automatically. See
[the custody-opening contract](../docs/CUSTODY-CONSTRAINED-STATE-OPENING.md).

## Offline authenticated custody promotion (0574)

`state-head-custody-promote` names one exact old detached custody record and
exactly one stopped keyed state directory or signed encrypted backup. It
completely authenticates and semantically replays that source, proves an exact
append-prefix or authenticated-checkpoint-parent relationship, derives the new
`NASH1` internally, and publishes it with the existing synchronized custody
compare-and-swap. It opens no node-state writer and cannot accept a caller-
supplied replacement selector. See
[the custody-promotion contract](../docs/CUSTODY-PROMOTION.md).


## Read-only custody-promotion outcome audit (0575)

`state-head-custody-promotion-audit` resolves a lost promotion response without
retrying the compare-and-swap. It completely authenticates and semantically
replays the explicitly named stopped state directory or signed encrypted
backup, derives the candidate `NASH1` internally, and compares the exact
canonical old and deterministic successor custody records with the current
named record. It reports not-applied, applied, competing-custody, or
stale/divergent-source evidence while mutating nothing. See
[the outcome-audit contract](../docs/CUSTODY-PROMOTION-OUTCOME-AUDIT.md).

## Detached custody-promotion intent (0576)

`state-head-custody-promotion-intent-create` completely validates one exact old
custody account and one stopped keyed state directory or signed encrypted
backup, proves the same promotion successor relationship, derives the candidate
`NASH1` internally, and publishes one canonical owner-private `NHCPI001` record
without replacement. `state-head-custody-promote` and
`state-head-custody-promotion-audit` accept the explicit intent as a complete
alternative to inline old-account fields. Every use re-authenticates the
explicit source and reproduces the exact bound source, relationship, selector,
intent bytes, and custody path. The intent grants no authority, freshness,
idempotency, automatic promotion, or response receipt. See
[the detached intent contract](../docs/CUSTODY-PROMOTION-INTENT.md).

## Removable-media packet adapter (revision 0600)

The normal executable also provides the supervised role:

```text
removable-media-packet-adapter
```

This role is not selected by scanning mounts or devices. An accepted V19
adapter profile pins the executable image, exact arguments, three
owner-controlled directories, link/epoch policy, MTU and finite resource
bounds. It exchanges complete datagrams with its supervisor over the existing
NAPA descriptor-3 protocol and uses canonical `NRMB0001` files on the selected
filesystem medium. See `../docs/REMOVABLE-MEDIA-PACKET-ADAPTER.md`.
