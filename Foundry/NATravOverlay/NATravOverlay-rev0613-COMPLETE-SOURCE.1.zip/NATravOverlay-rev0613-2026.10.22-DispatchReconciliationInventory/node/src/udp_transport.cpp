#include "udp_transport.hpp"

#include "packet_port.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <limits>
#include <memory>
#include <mutex>
#include <netinet/in.h>
#include <optional>
#include <poll.h>
#include <span>
#include <string>
#include <string_view>
#include <sys/socket.h>
#include <utility>
#include <vector>
#include <arpa/inet.h>

namespace natrav_overlay {

int udp_packet_carrier_revision_abi() noexcept { return 1; }

namespace {

inline constexpr std::string_view kUdpPrefix = "udp-v1|";
inline constexpr std::uint8_t kUdpProfile = 1U;
inline constexpr std::uint16_t kMinimumUdpMtu = 256U;
inline constexpr std::uint16_t kMaximumUdpMtu = 65'507U;
inline constexpr int kUdpSocketBufferBytes = 262'144;
inline constexpr std::chrono::milliseconds kUdpTickInterval{10};
inline constexpr std::chrono::milliseconds kListenerReopenDelay{100};
inline constexpr std::chrono::milliseconds kShutdownBudget{2'000};

struct ResolvedUdpEndpoint final {
    sockaddr_storage storage{};
    socklen_t length{0};
    int family{AF_UNSPEC};
    std::string canonical_host;
};

struct UdpListenerLease final {
    std::atomic<bool> active{false};
};

[[nodiscard]] std::vector<std::string_view> split_fields(
    const std::string_view text) {
    std::vector<std::string_view> fields;
    std::size_t begin = 0U;
    while (begin <= text.size()) {
        const auto separator = text.find('|', begin);
        if (separator == std::string_view::npos) {
            fields.push_back(text.substr(begin));
            break;
        }
        fields.push_back(text.substr(begin, separator - begin));
        begin = separator + 1U;
    }
    return fields;
}

[[nodiscard]] std::string_view field_value(
    const std::string_view field,
    const std::string_view name) {
    const std::string prefix = std::string(name) + "=";
    if (!field.starts_with(prefix) || field.size() == prefix.size()) {
        app_fail(
            "UDP_LOCATOR_INVALID",
            "expected nonempty field " + std::string(name));
    }
    return field.substr(prefix.size());
}

[[nodiscard]] ResolvedUdpEndpoint resolve_udp_endpoint(
    const UdpTransportEndpoint& endpoint,
    const std::string_view role) {
    if (endpoint.host.empty() || endpoint.service == 0U) {
        app_fail(
            "UDP_LOCATOR_INVALID",
            std::string(role) + " endpoint requires a numeric address and nonzero port");
    }

    ResolvedUdpEndpoint resolved;
    std::array<char, INET6_ADDRSTRLEN> text{};
    sockaddr_in ipv4{};
    ipv4.sin_family = AF_INET;
    ipv4.sin_port = htons(endpoint.service);
    if (::inet_pton(AF_INET, endpoint.host.c_str(), &ipv4.sin_addr) == 1) {
        const auto host_order = ntohl(ipv4.sin_addr.s_addr);
        const bool multicast = (host_order & 0xf0000000U) == 0xe0000000U;
        if (host_order == INADDR_ANY || host_order == INADDR_BROADCAST || multicast) {
            app_fail(
                "UDP_ENDPOINT_UNSUPPORTED",
                std::string(role) + " endpoint must be a concrete non-broadcast unicast address");
        }
        if (::inet_ntop(AF_INET, &ipv4.sin_addr, text.data(), text.size()) == nullptr) {
            app_fail("UDP_LOCATOR_INVALID", "failed to canonicalize IPv4 endpoint");
        }
        std::memcpy(&resolved.storage, &ipv4, sizeof(ipv4));
        resolved.length = static_cast<socklen_t>(sizeof(ipv4));
        resolved.family = AF_INET;
        resolved.canonical_host = text.data();
        return resolved;
    }

    sockaddr_in6 ipv6{};
    ipv6.sin6_family = AF_INET6;
    ipv6.sin6_port = htons(endpoint.service);
    if (::inet_pton(AF_INET6, endpoint.host.c_str(), &ipv6.sin6_addr) == 1) {
        if (IN6_IS_ADDR_UNSPECIFIED(&ipv6.sin6_addr) != 0 ||
            IN6_IS_ADDR_MULTICAST(&ipv6.sin6_addr) != 0 ||
            IN6_IS_ADDR_LINKLOCAL(&ipv6.sin6_addr) != 0) {
            app_fail(
                "UDP_ENDPOINT_UNSUPPORTED",
                std::string(role) +
                    " endpoint must be concrete unicast; scoped link-local addresses are not in udp-v1");
        }
        if (::inet_ntop(AF_INET6, &ipv6.sin6_addr, text.data(), text.size()) == nullptr) {
            app_fail("UDP_LOCATOR_INVALID", "failed to canonicalize IPv6 endpoint");
        }
        std::memcpy(&resolved.storage, &ipv6, sizeof(ipv6));
        resolved.length = static_cast<socklen_t>(sizeof(ipv6));
        resolved.family = AF_INET6;
        resolved.canonical_host = text.data();
        return resolved;
    }

    app_fail(
        "UDP_LOCATOR_INVALID",
        std::string(role) + " host must be a numeric IPv4 or IPv6 address");
}

[[nodiscard]] UdpTransportEndpoint parse_udp_endpoint(
    const std::string_view text,
    const std::string_view role) {
    std::string_view host;
    std::string_view service_text;
    if (!text.empty() && text.front() == '[') {
        const auto close = text.find(']');
        if (close == std::string_view::npos || close + 1U >= text.size() ||
            text[close + 1U] != ':') {
            app_fail("UDP_LOCATOR_INVALID", "invalid bracketed UDP endpoint");
        }
        host = text.substr(1U, close - 1U);
        service_text = text.substr(close + 2U);
    } else {
        const auto colon = text.rfind(':');
        if (colon == std::string_view::npos || colon == 0U ||
            colon + 1U >= text.size() || text.find(':') != colon) {
            app_fail(
                "UDP_LOCATOR_INVALID",
                "UDP endpoint must be IPv4:port or [IPv6]:port");
        }
        host = text.substr(0U, colon);
        service_text = text.substr(colon + 1U);
    }
    UdpTransportEndpoint endpoint{
        .host = std::string(host),
        .service = static_cast<std::uint16_t>(parse_u64(
            service_text,
            std::string(role) + " UDP port",
            1U,
            65'535U)),
    };
    static_cast<void>(resolve_udp_endpoint(endpoint, role));
    return endpoint;
}

[[nodiscard]] std::uint64_t parse_link_id(const std::string_view text) {
    if (text.size() != 16U) {
        app_fail("UDP_LOCATOR_INVALID", "link must be exactly 16 lowercase hexadecimal digits");
    }
    std::uint64_t value = 0U;
    for (const char digit : text) {
        std::uint8_t nibble = 0U;
        if (digit >= '0' && digit <= '9') {
            nibble = static_cast<std::uint8_t>(digit - '0');
        } else if (digit >= 'a' && digit <= 'f') {
            nibble = static_cast<std::uint8_t>(10 + digit - 'a');
        } else {
            app_fail(
                "UDP_LOCATOR_INVALID",
                "link must be exactly 16 lowercase hexadecimal digits");
        }
        value = (value << 4U) | static_cast<std::uint64_t>(nibble);
    }
    if (value == 0U) {
        app_fail("UDP_LOCATOR_INVALID", "link identifier must be nonzero");
    }
    return value;
}

[[nodiscard]] std::string link_id_text(const std::uint64_t value) {
    if (value == 0U) {
        app_fail("UDP_LOCATOR_INVALID", "link identifier must be nonzero");
    }
    static constexpr char kHex[] = "0123456789abcdef";
    std::string result(16U, '0');
    for (std::size_t index = 0U; index < result.size(); ++index) {
        const auto shift = static_cast<unsigned>((result.size() - 1U - index) * 4U);
        result[index] = kHex[(value >> shift) & 0x0fU];
    }
    return result;
}

[[nodiscard]] natrav::packet_link::Limits udp_profile_limits(
    const UdpTransportLocator& locator) {
    if (locator.profile != kUdpProfile) {
        app_fail("UDP_PROFILE_UNSUPPORTED", "udp-v1 supports only profile=1");
    }
    natrav::packet_link::Limits limits;
    limits.mtu = locator.mtu;
    limits.max_message_bytes = 256U * 1024U;
    limits.max_reassembly_bytes = 2U * 1024U * 1024U;
    limits.max_delivery_bytes = 2U * 1024U * 1024U;
    limits.max_inflight_frames = 512U;
    limits.max_control_frames = 512U;
    limits.max_receive_packets_per_pump = 512U;
    limits.retransmit_after_ticks = 5U;
    limits.retry_limit = 20U;
    limits.message_expiry_ticks = 2'000U;
    limits.validate();
    return limits;
}

[[nodiscard]] int poll_timeout_ms(const Deadline wake) {
    const auto now = std::chrono::steady_clock::now();
    if (now >= wake) {
        return 0;
    }
    const auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(
        wake - now);
    const auto count = std::max<std::chrono::milliseconds::rep>(
        remaining.count(), 1);
    return static_cast<int>(std::min<std::chrono::milliseconds::rep>(
        count, static_cast<std::chrono::milliseconds::rep>(INT_MAX)));
}

[[nodiscard]] bool udp_reset_errno(const int value) noexcept {
    return value == ECONNREFUSED || value == ECONNRESET ||
        value == EHOSTUNREACH || value == ENETUNREACH;
}

void make_udp_nonblocking(const int fd) {
    const int flags = ::fcntl(fd, F_GETFL, 0);
    if (flags < 0 || ::fcntl(fd, F_SETFL, flags | O_NONBLOCK) != 0) {
        app_fail(
            "UDP_SOCKET_CONFIG_FAILED",
            datacube::errno_detail("UDP O_NONBLOCK", errno));
    }
}

class UdpPacketPort final : public OwnedCompleteDatagramPacketPort {
public:
    UdpPacketPort(datacube::Fd fd, const std::size_t mtu) noexcept
        : fd_(std::move(fd)), mtu_(mtu) {}

    ~UdpPacketPort() override {
        if (lease_) {
            lease_->active.store(false, std::memory_order_release);
        }
    }

    [[nodiscard]] TransportKind transport_kind() const noexcept override {
        return TransportKind::udp;
    }

    [[nodiscard]] std::size_t mtu() const noexcept override { return mtu_; }

    [[nodiscard]] int readiness_handle() const noexcept { return fd_.get(); }

    void activate_listener_lease(std::shared_ptr<UdpListenerLease> lease) {
        if (!lease || lease_ || lease->active.exchange(true, std::memory_order_acq_rel)) {
            app_fail("UDP_LISTENER_LEASE_INVALID", "UDP listener lease is already active");
        }
        lease_ = std::move(lease);
    }

    [[nodiscard]] bool send_packet(
        const natrav::packet_link::Bytes& packet) override {
        if (fd_.get() < 0 || packet.empty() || packet.size() > mtu_) {
            app_fail("UDP_PACKET_INVALID", "outbound datagram violates the configured MTU");
        }
        while (true) {
            const ssize_t count = ::send(
                fd_.get(), packet.data(), packet.size(), MSG_NOSIGNAL);
            if (count >= 0) {
                if (static_cast<std::size_t>(count) != packet.size()) {
                    app_fail("UDP_SEND_FAILED", "datagram send was unexpectedly partial");
                }
                write_blocked_ = false;
                return true;
            }
            if (errno == EINTR) {
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                write_blocked_ = true;
                return false;
            }
            if (udp_reset_errno(errno)) {
                app_fail("PEER_RESET", datacube::errno_detail("UDP send", errno));
            }
            app_fail("UDP_SEND_FAILED", datacube::errno_detail("UDP send", errno));
        }
    }

    [[nodiscard]] std::optional<natrav::packet_link::Bytes> receive_packet() override {
        natrav::packet_link::Bytes packet(mtu_);
        iovec vector{
            .iov_base = packet.data(),
            .iov_len = packet.size(),
        };
        msghdr message{};
        message.msg_iov = &vector;
        message.msg_iovlen = 1U;
        while (true) {
            message.msg_flags = 0;
            const ssize_t count = ::recvmsg(fd_.get(), &message, MSG_DONTWAIT | MSG_TRUNC);
            if (count >= 0) {
                if ((message.msg_flags & MSG_TRUNC) != 0 ||
                    static_cast<std::size_t>(count) > mtu_) {
                    app_fail(
                        "UDP_DATAGRAM_TRUNCATED",
                        "received datagram exceeds the configured receive MTU");
                }
                packet.resize(static_cast<std::size_t>(count));
                return packet;
            }
            if (errno == EINTR) {
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                return std::nullopt;
            }
            if (udp_reset_errno(errno)) {
                app_fail("PEER_RESET", datacube::errno_detail("UDP receive", errno));
            }
            app_fail(
                "UDP_RECEIVE_FAILED",
                datacube::errno_detail("UDP receive", errno));
        }
    }

    void wait_for_progress(
        const Deadline wake_deadline,
        const Deadline operation_deadline,
        IoCounters& counters,
        const std::string_view operation) override {
        const auto now = std::chrono::steady_clock::now();
        if (now >= operation_deadline) {
            app_fail("IO_TIMEOUT", std::string(operation));
        }
        pollfd item{
            .fd = fd_.get(),
            .events = static_cast<short>(POLLIN | (write_blocked_ ? POLLOUT : 0)),
            .revents = 0,
        };
        ++counters.poll_calls;
        int result = 0;
        do {
            result = ::poll(&item, 1U, poll_timeout_ms(wake_deadline));
            if (result < 0 && errno == EINTR) {
                ++counters.interrupted;
            }
        } while (result < 0 && errno == EINTR);
        if (result < 0) {
            app_fail("UDP_POLL_FAILED", datacube::errno_detail(operation, errno));
        }
        if (result == 0) {
            ++counters.would_block;
            if (std::chrono::steady_clock::now() >= operation_deadline) {
                app_fail("IO_TIMEOUT", std::string(operation));
            }
            return;
        }
        if ((item.revents & POLLNVAL) != 0) {
            app_fail("UDP_SOCKET_INVALID", std::string(operation));
        }
        if ((item.revents & POLLOUT) != 0) {
            write_blocked_ = false;
        }
        if ((item.revents & (POLLERR | POLLHUP)) != 0 &&
            (item.revents & POLLIN) == 0) {
            throw_socket_error(operation);
        }
    }

    [[nodiscard]] bool receive_ready() const {
        pollfd item{.fd = fd_.get(), .events = POLLIN, .revents = 0};
        int result = 0;
        do {
            result = ::poll(&item, 1U, 0);
        } while (result < 0 && errno == EINTR);
        if (result < 0) {
            app_fail(
                "UDP_POLL_FAILED",
                datacube::errno_detail("UDP listener readiness", errno));
        }
        if (result == 0 || (item.revents & POLLIN) == 0) {
            return false;
        }
        if ((item.revents & POLLNVAL) != 0) {
            app_fail("UDP_SOCKET_INVALID", "UDP listener descriptor");
        }
        return true;
    }

private:
    void throw_socket_error(const std::string_view operation) const {
        int socket_error = 0;
        socklen_t length = static_cast<socklen_t>(sizeof(socket_error));
        if (::getsockopt(
                fd_.get(), SOL_SOCKET, SO_ERROR, &socket_error, &length) != 0) {
            app_fail(
                "UDP_SOCKET_ERROR",
                datacube::errno_detail(operation, errno));
        }
        if (socket_error == 0) {
            return;
        }
        if (udp_reset_errno(socket_error)) {
            app_fail("PEER_RESET", datacube::errno_detail(operation, socket_error));
        }
        app_fail("UDP_SOCKET_ERROR", datacube::errno_detail(operation, socket_error));
    }

    datacube::Fd fd_;
    std::size_t mtu_{0U};
    bool write_blocked_{false};
    std::shared_ptr<UdpListenerLease> lease_{};
};

[[nodiscard]] std::unique_ptr<UdpPacketPort> open_udp_packet_port(
    const UdpTransportLocator& locator,
    const std::string_view failure_code) {
    const auto local = resolve_udp_endpoint(locator.local, "local");
    const auto remote = resolve_udp_endpoint(locator.remote, "remote");
    if (local.family != remote.family) {
        app_fail("UDP_LOCATOR_INVALID", "local and remote endpoints must use one address family");
    }
    if (local.canonical_host == remote.canonical_host &&
        locator.local.service == locator.remote.service) {
        app_fail("UDP_LOCATOR_INVALID", "local and remote UDP endpoints must differ");
    }
    static_cast<void>(udp_profile_limits(locator));

    const int raw = ::socket(local.family, SOCK_DGRAM | SOCK_CLOEXEC, IPPROTO_UDP);
    if (raw < 0) {
        app_fail(failure_code, datacube::errno_detail("UDP socket", errno));
    }
    datacube::Fd fd(raw);
    if (local.family == AF_INET6) {
        const int enabled = 1;
        if (::setsockopt(
                fd.get(), IPPROTO_IPV6, IPV6_V6ONLY,
                &enabled, static_cast<socklen_t>(sizeof(enabled))) != 0) {
            app_fail(
                "UDP_SOCKET_CONFIG_FAILED",
                datacube::errno_detail("IPV6_V6ONLY", errno));
        }
    }
    const int disabled = 0;
    if (::setsockopt(
            fd.get(), SOL_SOCKET, SO_BROADCAST,
            &disabled, static_cast<socklen_t>(sizeof(disabled))) != 0 ||
        ::setsockopt(
            fd.get(), SOL_SOCKET, SO_RCVBUF,
            &kUdpSocketBufferBytes,
            static_cast<socklen_t>(sizeof(kUdpSocketBufferBytes))) != 0 ||
        ::setsockopt(
            fd.get(), SOL_SOCKET, SO_SNDBUF,
            &kUdpSocketBufferBytes,
            static_cast<socklen_t>(sizeof(kUdpSocketBufferBytes))) != 0) {
        app_fail(
            "UDP_SOCKET_CONFIG_FAILED",
            datacube::errno_detail("UDP socket buffers", errno));
    }
    if (::bind(
            fd.get(),
            reinterpret_cast<const sockaddr*>(&local.storage),
            local.length) != 0) {
        app_fail(
            failure_code,
            datacube::errno_detail("bind " + udp_transport_endpoint_text(locator.local), errno));
    }
    if (::connect(
            fd.get(),
            reinterpret_cast<const sockaddr*>(&remote.storage),
            remote.length) != 0) {
        app_fail(
            failure_code,
            datacube::errno_detail(
                "connect " + udp_transport_endpoint_text(locator.remote), errno));
    }
    make_udp_nonblocking(fd.get());
    return std::make_unique<UdpPacketPort>(std::move(fd), locator.mtu);
}

[[nodiscard]] PacketPortOrderedStreamOptions udp_packet_stream_options(
    const UdpTransportLocator& locator) {
    return PacketPortOrderedStreamOptions{
        .limits = udp_profile_limits(locator),
        .stream_id = locator.link_id,
        .epoch = locator.epoch,
        .tick_interval = kUdpTickInterval,
        .shutdown_budget = kShutdownBudget,
        .invalid_stream_code = "UDP_STREAM_INVALID",
        .logical_clock_invalid_code = "UDP_LOGICAL_CLOCK_INVALID",
        .logical_clock_exhausted_code = "UDP_LOGICAL_CLOCK_EXHAUSTED",
        .shutdown_operation = "UDP packet-link shutdown",
    };
}

class UdpTransportConnector final : public TransportConnector {
public:
    [[nodiscard]] std::unique_ptr<OrderedByteStream> connect(
        const TransportLocator& locator,
        const Deadline deadline,
        IoCounters& counters) const override {
        static_cast<void>(counters);
        if (std::chrono::steady_clock::now() >= deadline) {
            app_fail("IO_TIMEOUT", "UDP connect");
        }
        const auto& udp = udp_transport_locator(locator);
        auto port = open_udp_packet_port(udp, "CONNECT_FAILED");
        if (std::chrono::steady_clock::now() >= deadline) {
            app_fail("IO_TIMEOUT", "UDP connect");
        }
        return make_packet_port_ordered_byte_stream(
            std::move(port), udp_packet_stream_options(udp));
    }
};

class UdpTransportListener final : public TransportListener {
public:
    explicit UdpTransportListener(TransportLocator locator)
        : locator_(std::move(locator)),
          lease_(std::make_shared<UdpListenerLease>()),
          pending_(open_udp_packet_port(
              udp_transport_locator(locator_), "LISTEN_FAILED")) {}

    [[nodiscard]] TransportKind transport_kind() const noexcept override {
        return TransportKind::udp;
    }

    [[nodiscard]] int readiness_handle() const noexcept override {
        std::lock_guard<std::mutex> lock(mutex_);
        if (lease_->active.load(std::memory_order_acquire)) {
            return -1;
        }
        if (!pending_) {
            const auto now = std::chrono::steady_clock::now();
            if (now < reopen_after_) {
                return -1;
            }
            try {
                pending_ = open_udp_packet_port(
                    udp_transport_locator(locator_), "LISTEN_FAILED");
            } catch (...) {
                reopen_after_ = now + kListenerReopenDelay;
                return -1;
            }
        }
        return pending_->readiness_handle();
    }

    [[nodiscard]] TransportLocator bound_locator() const override {
        return locator_;
    }

    [[nodiscard]] std::unique_ptr<OrderedByteStream> accept_ready() override {
        std::lock_guard<std::mutex> lock(mutex_);
        if (lease_->active.load(std::memory_order_acquire)) {
            return nullptr;
        }
        if (!pending_) {
            pending_ = open_udp_packet_port(
                udp_transport_locator(locator_), "LISTEN_FAILED");
        }
        if (!pending_->receive_ready()) {
            return nullptr;
        }
        auto accepted = std::move(pending_);
        accepted->activate_listener_lease(lease_);
        const auto& udp = udp_transport_locator(locator_);
        return make_packet_port_ordered_byte_stream(
            std::move(accepted), udp_packet_stream_options(udp));
    }

private:
    TransportLocator locator_;
    std::shared_ptr<UdpListenerLease> lease_;
    mutable std::mutex mutex_;
    mutable std::unique_ptr<UdpPacketPort> pending_;
    mutable std::chrono::steady_clock::time_point reopen_after_{};
};

}  // namespace

std::string udp_transport_endpoint_text(const UdpTransportEndpoint& endpoint) {
    const auto resolved = resolve_udp_endpoint(endpoint, "UDP");
    const bool bracket = resolved.family == AF_INET6;
    return (bracket ? "[" + resolved.canonical_host + "]" : resolved.canonical_host) +
        ":" + std::to_string(endpoint.service);
}

std::string udp_transport_locator_text(const UdpTransportLocator& locator) {
    if (locator.mtu < kMinimumUdpMtu || locator.mtu > kMaximumUdpMtu) {
        app_fail("UDP_LOCATOR_INVALID", "UDP MTU must be in 256..65507");
    }
    if (locator.epoch == 0U) {
        app_fail("UDP_LOCATOR_INVALID", "UDP epoch must be nonzero");
    }
    if (locator.profile != kUdpProfile) {
        app_fail("UDP_PROFILE_UNSUPPORTED", "udp-v1 supports only profile=1");
    }
    const auto local = resolve_udp_endpoint(locator.local, "local");
    const auto remote = resolve_udp_endpoint(locator.remote, "remote");
    if (local.family != remote.family) {
        app_fail("UDP_LOCATOR_INVALID", "local and remote endpoints must use one address family");
    }
    if (local.canonical_host == remote.canonical_host &&
        locator.local.service == locator.remote.service) {
        app_fail("UDP_LOCATOR_INVALID", "local and remote UDP endpoints must differ");
    }
    static_cast<void>(udp_profile_limits(locator));
    return std::string(kUdpPrefix) +
        "local=" + udp_transport_endpoint_text(locator.local) +
        "|remote=" + udp_transport_endpoint_text(locator.remote) +
        "|mtu=" + std::to_string(locator.mtu) +
        "|link=" + link_id_text(locator.link_id) +
        "|epoch=" + std::to_string(locator.epoch) +
        "|profile=" + std::to_string(locator.profile);
}

TransportLocator parse_udp_transport_locator(const std::string_view text) {
    const auto fields = split_fields(text);
    if (fields.size() != 7U || fields[0U] != "udp-v1") {
        app_fail(
            "UDP_LOCATOR_INVALID",
            "UDP locator must use canonical udp-v1 fields");
    }
    TransportLocator locator{
        .kind = TransportKind::udp,
        .tcp = {},
        .serial = {},
        .udp = UdpTransportLocator{
            .local = parse_udp_endpoint(field_value(fields[1U], "local"), "local"),
            .remote = parse_udp_endpoint(field_value(fields[2U], "remote"), "remote"),
            .mtu = static_cast<std::uint16_t>(parse_u64(
                field_value(fields[3U], "mtu"),
                "UDP MTU",
                kMinimumUdpMtu,
                kMaximumUdpMtu)),
            .link_id = parse_link_id(field_value(fields[4U], "link")),
            .epoch = static_cast<std::uint32_t>(parse_u64(
                field_value(fields[5U], "epoch"),
                "UDP epoch",
                1U,
                std::numeric_limits<std::uint32_t>::max())),
            .profile = static_cast<std::uint8_t>(parse_u64(
                field_value(fields[6U], "profile"),
                "UDP profile",
                kUdpProfile,
                kUdpProfile)),
        },
        .unix_datagram = {},
    };
    if (udp_transport_locator_text(locator.udp) != text) {
        app_fail(
            "UDP_LOCATOR_NONCANONICAL",
            "UDP locator must use the exact canonical spelling");
    }
    return locator;
}

const TransportConnector& udp_transport_connector() {
    static const UdpTransportConnector connector;
    return connector;
}

std::unique_ptr<TransportListener> listen_udp_transport(
    const TransportLocator& locator,
    const int backlog) {
    if (backlog < 1 || backlog > 1024) {
        app_fail("INVALID_LISTEN_BACKLOG", "backlog outside 1..1024");
    }
    static_cast<void>(udp_transport_locator(locator));
    return std::make_unique<UdpTransportListener>(locator);
}

}  // namespace natrav_overlay
