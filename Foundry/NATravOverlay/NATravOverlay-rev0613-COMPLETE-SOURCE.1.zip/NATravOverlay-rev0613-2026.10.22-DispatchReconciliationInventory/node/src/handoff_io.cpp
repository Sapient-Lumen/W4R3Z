#include "handoff_io.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstring>
#include <cstdlib>
#include <chrono>
#include <thread>
#include <iostream>
#include <dirent.h>
#include <fcntl.h>
#include <linux/fs.h>
#include <openssl/crypto.h>
#include <openssl/pem.h>
#include <openssl/rand.h>
#include <set>
#include <sys/stat.h>
#include <sys/file.h>
#include <sys/syscall.h>
#include <unistd.h>

namespace natrav_overlay {
namespace {
using Bytes = datacube::Octets;
using View = datacube::OctetView;
void check(bool ok, std::string_view detail) {
    if (!ok) { app_fail("HANDOFF_FILE_REJECTED", detail); }
}
void sync(int fd) { check(::fsync(fd) == 0, "synchronization failed"); }
void require_canonical_path(const std::filesystem::path& p) {
    check(p.is_absolute() && p.string().size() <= 4'096U && p != p.root_path() &&
        p.lexically_normal().string() == p.string() && !p.filename().empty(), "canonical absolute path required");
    for (const auto& c : p.relative_path()) {
        const auto s = c.string();
        check(!s.empty() && s != "." && s != ".." && s.size() <= 255U &&
            std::all_of(s.begin(), s.end(), [](char ch) {
                const auto u = static_cast<unsigned char>(ch); return u >= 32U && u <= 126U;
            }), "invalid path component");
    }
}
datacube::Fd open_dir(const std::filesystem::path& p, bool private_parent) {
    require_canonical_path(p);
    datacube::Fd fd(::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC)); check(fd.get() >= 0, "root open failed");
    for (const auto& c : p.relative_path()) {
        datacube::Fd next(::openat(fd.get(), c.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW));
        check(next.get() >= 0, "directory traversal failed or symlink encountered"); fd = std::move(next);
    }
    struct stat st{}; check(::fstat(fd.get(), &st) == 0 && S_ISDIR(st.st_mode), "directory stat failed");
    if (private_parent) {
        check(st.st_uid == ::geteuid() && (st.st_mode & 0077U) == 0U, "directory must be owner-private");
    }
    return fd;
}
Bytes read_at(int dir, const char* name, std::size_t limit, bool secret) {
    datacube::Fd fd(::openat(dir, name, O_RDONLY | O_NONBLOCK | O_NOFOLLOW | O_CLOEXEC));
    check(fd.get() >= 0, "input open failed"); struct stat before{}, after{};
    check(::fstat(fd.get(), &before) == 0 && S_ISREG(before.st_mode) && before.st_nlink == 1 &&
        before.st_uid == ::geteuid() && (before.st_mode & (secret ? 0077U : 0022U)) == 0U &&
        before.st_size > 0 && static_cast<std::uint64_t>(before.st_size) <= limit,
        "input type, ownership, mode, link count or size rejected");
    Bytes b(static_cast<std::size_t>(before.st_size));
    std::size_t offset = 0U;
    while (offset < b.size()) {
        const auto n = ::read(fd.get(), b.data() + offset, b.size() - offset);
        if (n < 0 && errno == EINTR) { continue; }
        if (n <= 0) { if (secret) { OPENSSL_cleanse(b.data(), b.size()); } check(false, "incomplete input read"); }
        offset += static_cast<std::size_t>(n);
    }
    const bool same = ::fstat(fd.get(), &after) == 0 && before.st_dev == after.st_dev &&
        before.st_ino == after.st_ino && before.st_size == after.st_size && before.st_mode == after.st_mode &&
        before.st_uid == after.st_uid && after.st_nlink == 1 &&
        before.st_mtim.tv_sec == after.st_mtim.tv_sec && before.st_mtim.tv_nsec == after.st_mtim.tv_nsec &&
        before.st_ctim.tv_sec == after.st_ctim.tv_sec && before.st_ctim.tv_nsec == after.st_ctim.tv_nsec;
    if (!same && secret) { OPENSSL_cleanse(b.data(), b.size()); }
    check(same, "input changed during read"); return b;
}
void write_at(int dir, const char* name, View bytes) {
    datacube::Fd fd(::openat(dir, name, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600));
    check(fd.get() >= 0, "exclusive output create failed");
    check(::fchmod(fd.get(), 0600) == 0, "private output permissions failed");
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto n = ::write(fd.get(), bytes.data() + offset, bytes.size() - offset);
        if (n < 0 && errno == EINTR) { continue; }
        check(n > 0, "output write failed"); offset += static_cast<std::size_t>(n);
    }
    sync(fd.get());
}
void reserve_output_budget(int fd, std::size_t incoming) {
    // The exact chosen output directory is the only enumeration boundary. No
    // discovery, recursion, automatic cleanup, or unbounded persistent spool.
    check(::flock(fd, LOCK_EX | LOCK_NB) == 0, "output directory is already in use");
    const int copy = ::fcntl(fd, F_DUPFD_CLOEXEC, 3); check(copy >= 0, "directory duplication failed");
    DIR* entries = ::fdopendir(copy);
    if (entries == nullptr) { ::close(copy); check(false, "directory enumeration failed"); }
    std::size_t count = 0U; std::uint64_t bytes = incoming; bool ok = true;
    errno = 0;
    while (const auto* entry = ::readdir(entries)) {
        if (std::strcmp(entry->d_name, ".") == 0 || std::strcmp(entry->d_name, "..") == 0) { continue; }
        struct stat st{};
        if (++count >= 256U || ::fstatat(fd, entry->d_name, &st, AT_SYMLINK_NOFOLLOW) != 0) { ok = false; break; }
        if (S_ISREG(st.st_mode) && st.st_size > 0) {
            const auto n = static_cast<std::uint64_t>(st.st_size);
            if (n > 33'554'432U - bytes) { ok = false; break; }
            bytes += n;
        }
        errno = 0;
    }
    const int saved = errno; ::closedir(entries);
    check(ok && saved == 0, "output directory entry or byte budget exhausted");
}
std::string staging_name() {
    std::array<std::uint8_t, 16U> random{};
    check(RAND_bytes(random.data(), static_cast<int>(random.size())) == 1, "temporary name generation failed");
    return ".nhc-part-" + hex_bytes(random);
}
void rename_new(int dir, const char* from, const char* to) {
    // No fallback to overwrite-capable rename or a copy/delete pair.
    check(::syscall(SYS_renameat2, dir, from, dir, to, RENAME_NOREPLACE) == 0,
        "atomic no-replace publication failed; destination may already exist");
}
void layout(int dir) {
    const int duplicate = ::fcntl(dir, F_DUPFD_CLOEXEC, 3); check(duplicate >= 0, "directory duplication failed");
    DIR* entries = ::fdopendir(duplicate);
    if (entries == nullptr) { ::close(duplicate); check(false, "directory enumeration failed"); }
    std::set<std::string> names; std::size_t count = 0U;
    errno = 0;
    while (const auto* e = ::readdir(entries)) {
        const std::string name(e->d_name);
        if (name == "." || name == "..") { continue; }
        names.insert(name);
        if (++count > 2U) { ::closedir(entries); check(false, "unexpected key-directory contents"); }
        errno = 0;
    }
    const int saved = errno; ::closedir(entries);
    check(saved == 0 && names == std::set<std::string>{"binding.nhkb", "private.nhks"}, "incomplete key-directory layout");
}
} // namespace
void handoff_test_pause(const char* name) {
    const char* value = std::getenv(name);
    if (value == nullptr || *value == '\0') { return; }
    const auto delay = parse_u64(value, name, 0U, 5'000U);
    std::cerr << "{\"test_boundary\":" << json_string(name) << "}" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(delay));
}
HandoffLocalKey::~HandoffLocalKey() { OPENSSL_cleanse(secret.data(), secret.size()); }
void require_handoff_state_owner(const std::filesystem::path& directory) { (void)open_dir(directory, true); }
Bytes read_handoff_file(const std::filesystem::path& path, std::size_t limit, bool secret) {
    require_canonical_path(path); check(!path.filename().string().starts_with(".nhc-part-"), "staging inputs are not published handoffs"); auto parent = open_dir(path.parent_path(), false);
    return read_at(parent.get(), path.filename().c_str(), limit, secret);
}
HandoffSigner load_handoff_signer(const RuntimeConfig& config) {
    auto bytes = read_handoff_file(config.identity.private_key, 65'536U, true);
    std::unique_ptr<BIO, decltype(&BIO_free)> bio(BIO_new_mem_buf(bytes.data(), static_cast<int>(bytes.size())), BIO_free);
    EVP_PKEY* raw = bio ? PEM_read_bio_PrivateKey(bio.get(), nullptr, nullptr, nullptr) : nullptr;
    OPENSSL_cleanse(bytes.data(), bytes.size());
    HandoffSigner key(raw, EVP_PKEY_free);
    check(key != nullptr && EVP_PKEY_id(key.get()) == EVP_PKEY_ED25519, "Ed25519 signing key required");
    // TlsContext checks certificate/key correspondence as well; repeat the pin here.
    const int n = i2d_PUBKEY(key.get(), nullptr); check(n > 0 && n <= 1'024, "SPKI encoding failed");
    Bytes der(static_cast<std::size_t>(n)); auto* p = der.data();
    check(i2d_PUBKEY(key.get(), &p) == n && datacube::sha256(der) == config.identity.expected_spki_sha256,
        "private signing key differs from active configuration pin");
    return key;
}
std::unique_ptr<HandoffLocalKey> load_handoff_key(const std::filesystem::path& directory,
    const RuntimeConfig& config) {
    auto dir = open_dir(directory, true); layout(dir.get());
    auto result = std::make_unique<HandoffLocalKey>();
    result->binding = decode_handoff_binding(read_at(dir.get(), "binding.nhkb", kHandoffBindingLimit, true));
    require_handoff_binding(result->binding, config.local_node, config.local_identity_generation,
        config.identity.expected_spki_sha256);
    auto secret = read_at(dir.get(), "private.nhks", 72U, true);
    const auto expected = datacube::sha256(result->binding.canonical);
    const bool valid = secret.size() == 72U && std::memcmp(secret.data(), "NHKS0001", 8U) == 0 &&
        CRYPTO_memcmp(secret.data() + 40U, expected.octets.data(), 32U) == 0;
    if (valid) { std::copy_n(secret.data() + 8U, 32U, result->secret.begin()); }
    OPENSSL_cleanse(secret.data(), secret.size());
    check(valid && handoff_x25519_public(result->secret) == result->binding.encryption_public,
        "private material does not match the exact signed binding");
    return result;
}
HandoffBinding create_handoff_key(const std::filesystem::path& directory,
    const RuntimeConfig& config, std::string_view handoff_generation) {
    require_canonical_path(directory); auto parent = open_dir(directory.parent_path(), true);
    reserve_output_budget(parent.get(), 72U + kHandoffBindingLimit);
    auto signer = load_handoff_signer(config); HandoffLocalKey material;
    generate_handoff_secret(material.secret);
    material.binding = make_handoff_binding(config.local_node, config.local_identity_generation,
        handoff_generation, signer.get(), handoff_x25519_public(material.secret));
    auto tmp = staging_name(); check(::mkdirat(parent.get(), tmp.c_str(), 0700) == 0, "key staging directory creation failed");
    datacube::Fd staged(::openat(parent.get(), tmp.c_str(), O_DIRECTORY | O_RDONLY | O_NOFOLLOW | O_CLOEXEC));
    bool published = false;
    try {
        check(staged.get() >= 0, "key staging open failed");
        Bytes secret{'N','H','K','S','0','0','0','1'};
        secret.insert(secret.end(), material.secret.begin(), material.secret.end());
        const auto digest = datacube::sha256(material.binding.canonical);
        secret.insert(secret.end(), digest.octets.begin(), digest.octets.end());
        try { write_at(staged.get(), "private.nhks", secret); }
        catch (...) { OPENSSL_cleanse(secret.data(), secret.size()); throw; }
        OPENSSL_cleanse(secret.data(), secret.size());
        write_at(staged.get(), "binding.nhkb", material.binding.canonical);
        sync(staged.get()); rename_new(parent.get(), tmp.c_str(), directory.filename().c_str()); published = true; sync(parent.get());
    } catch (...) {
        // Only unpublished, locally-created fixed names are cleanup candidates.
        if (!published && staged.get() >= 0) { (void)::unlinkat(staged.get(), "private.nhks", 0); (void)::unlinkat(staged.get(), "binding.nhkb", 0); }
        if (!published) { (void)::unlinkat(parent.get(), tmp.c_str(), AT_REMOVEDIR); } throw;
    }
    return material.binding;
}
void publish_handoff_file(const std::filesystem::path& destination, View bytes) {
    require_canonical_path(destination); check(!bytes.empty() && bytes.size() <= kHandoffArtifactLimit, "output size bound");
    auto parent = open_dir(destination.parent_path(), true); reserve_output_budget(parent.get(), bytes.size());
    check(!destination.filename().string().starts_with(".nhc-part-"), "staging names are reserved");
    const auto tmp = staging_name();
    try { write_at(parent.get(), tmp.c_str(), bytes); handoff_test_pause("NATRAV_TEST_HANDOFF_BEFORE_PUBLISH_MS"); rename_new(parent.get(), tmp.c_str(), destination.filename().c_str()); sync(parent.get()); }
    catch (...) { (void)::unlinkat(parent.get(), tmp.c_str(), 0); throw; }
}
} // namespace natrav_overlay
