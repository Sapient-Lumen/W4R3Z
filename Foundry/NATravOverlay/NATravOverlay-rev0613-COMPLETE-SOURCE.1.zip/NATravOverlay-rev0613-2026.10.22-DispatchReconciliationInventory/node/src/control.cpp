#include "control.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <string>
#include <string_view>
#include <utility>

namespace natrav_overlay {
namespace {

inline constexpr std::array<std::uint8_t, 4> kRequestMagic{
    static_cast<std::uint8_t>('N'), static_cast<std::uint8_t>('O'),
    static_cast<std::uint8_t>('C'), static_cast<std::uint8_t>('1'),
};
inline constexpr std::array<std::uint8_t, 4> kResponseMagic{
    static_cast<std::uint8_t>('N'), static_cast<std::uint8_t>('O'),
    static_cast<std::uint8_t>('R'), static_cast<std::uint8_t>('1'),
};
inline constexpr std::size_t kMaximumControlJsonBytes = 65'000U;

void require_magic(
    datacube::Reader& reader,
    const std::array<std::uint8_t, 4>& expected,
    const std::string_view field) {
    const auto actual = reader.read_exact(expected.size(), field);
    if (!std::equal(expected.begin(), expected.end(), actual.begin())) {
        app_fail("CONTROL_PROTOCOL_REJECTED",
            std::string(field) + " magic mismatch");
    }
}

void append_text16(
    datacube::Octets& out,
    const std::string_view value,
    const std::size_t ceiling,
    const std::string_view field) {
    if (value.size() > ceiling || value.size() > 65'535U) {
        app_fail("CONTROL_PROTOCOL_REJECTED",
            std::string(field) + " exceeds its ceiling");
    }
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}

[[nodiscard]] std::string read_text16(
    datacube::Reader& reader,
    const std::size_t ceiling,
    const std::string_view field) {
    const auto size = reader.read_be16(field);
    if (static_cast<std::size_t>(size) > ceiling) {
        app_fail("CONTROL_PROTOCOL_REJECTED",
            std::string(field) + " exceeds its ceiling");
    }
    return datacube::octets_text(reader.read_exact(size, field), field, true);
}

void require_reason(const std::string_view reason) {
    if (reason.empty() || reason.size() > 256U ||
        !std::all_of(reason.begin(), reason.end(), [](const char raw) {
            const auto value = static_cast<unsigned char>(raw);
            return value == 9U || (value >= 32U && value <= 126U);
        })) {
        app_fail("CONTROL_PROTOCOL_REJECTED",
            "reason must be 1..256 printable ASCII bytes");
    }
}

void require_stop_correlation(const std::string_view token) {
    const auto body_character = [](const unsigned char value) noexcept {
        return (value >= static_cast<unsigned char>('a') &&
                value <= static_cast<unsigned char>('z')) ||
            (value >= static_cast<unsigned char>('0') &&
                value <= static_cast<unsigned char>('9')) ||
            value == static_cast<unsigned char>('.') ||
            value == static_cast<unsigned char>('_') ||
            value == static_cast<unsigned char>('-');
    };
    const auto edge_character = [](const unsigned char value) noexcept {
        return (value >= static_cast<unsigned char>('a') &&
                value <= static_cast<unsigned char>('z')) ||
            (value >= static_cast<unsigned char>('0') &&
                value <= static_cast<unsigned char>('9'));
    };
    if (token.empty() || token.size() > kMaximumStopCorrelationBytes ||
        !edge_character(static_cast<unsigned char>(token.front())) ||
        !edge_character(static_cast<unsigned char>(token.back())) ||
        !std::all_of(token.begin(), token.end(), [&](const char raw) {
            return body_character(static_cast<unsigned char>(raw));
        })) {
        app_fail("CONTROL_PROTOCOL_REJECTED",
            "stop correlation must be 1..64 lowercase token bytes");
    }
}

void append_operation_id(
    datacube::Octets& payload,
    const datacube::Digest32& operation_id) {
    if (digest_is_zero(operation_id)) {
        app_fail("CONTROL_PROTOCOL_REJECTED", "operation ID must be nonzero");
    }
    datacube::append_octets(payload, operation_id.octets);
}

[[nodiscard]] datacube::Digest32 read_operation_id(datacube::Reader& reader) {
    const auto bytes = reader.read_exact(32U, "operation ID");
    datacube::Digest32 operation_id {};
    std::copy(bytes.begin(), bytes.end(), operation_id.octets.begin());
    if (digest_is_zero(operation_id)) {
        app_fail("CONTROL_PROTOCOL_REJECTED", "operation ID must be nonzero");
    }
    return operation_id;
}

}  // namespace

datacube::Octets encode_control_request(const ControlRequest& request) {
    datacube::Octets payload;
    datacube::append_octets(payload, kRequestMagic);
    if (const auto* history = std::get_if<ControlHistoryRequest>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::control_history));
        datacube::append_octets(payload, encode_control_history(*history)); return payload;
    }
    if (const auto* history = std::get_if<ConfigurationHistoryRequest>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::configuration_history));
        datacube::append_octets(payload, encode_configuration_history(*history)); return payload;
    }
    if (const auto* inventory = std::get_if<RuntimeInventory>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::runtime_inventory));
        datacube::append_octets(payload, encode_runtime_inventory(*inventory)); return payload;
    }
    if (const auto* automation = std::get_if<ImportAutoRequest>(&request)) {
        datacube::append_u8(payload,static_cast<std::uint8_t>(ControlKind::import_auto));
        datacube::append_octets(payload,encode_import_auto_request(*automation));return payload;
    }
    if (const auto* view = std::get_if<SourceViewRequest>(&request)) {
        datacube::append_u8(payload,static_cast<std::uint8_t>(ControlKind::source_import));
        datacube::append_octets(payload,encode_source_view_request(*view));return payload;
    }
    if (const auto* subscription = std::get_if<SourceSubscriptionRequest>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::source_subscription));
        datacube::append_octets(payload, encode_source_subscription_request(*subscription));
        return payload;
    }
    if (const auto* channel = std::get_if<PublicationChannelRequest>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::publication_channel));
        datacube::append_octets(payload, encode_publication_channel_request(*channel));
        return payload;
    }
    if (const auto* consumer = std::get_if<ConsumerRequest>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::consumer));
        datacube::append_octets(payload, encode_consumer_request(*consumer));
        return payload;
    }
    if (const auto* feed = std::get_if<EvidenceFeed>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::evidence_feed));
        datacube::append_octets(payload, encode_evidence_feed(*feed));
        return payload;
    }
    if (const auto* review = std::get_if<ResultReviewRequest>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::result_review));
        datacube::append_octets(payload, encode_result_review(*review)); return payload;
    }
    if (const auto* review = std::get_if<ResultReviewStatus>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::result_review_status));
        datacube::append_octets(payload, encode_result_review_status(*review)); return payload;
    }
    if (const auto* bindings = std::get_if<ViewBindings>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::view_bindings));
        datacube::append_octets(payload, encode_view_bindings(*bindings)); return payload;
    }
    if (const auto* inventory = std::get_if<SourceViewInventory>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::source_view_inventory));
        datacube::append_octets(payload, encode_source_view_inventory(*inventory)); return payload;
    }
    if (const auto* inventory = std::get_if<SubscriptionInventory>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::subscription_inventory));
        datacube::append_octets(payload, encode_subscription_inventory(*inventory)); return payload;
    }
    if (const auto* inventory = std::get_if<PublicationInventory>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::publication_inventory));
        datacube::append_octets(payload, encode_publication_inventory(*inventory)); return payload;
    }
    if (const auto* inventory = std::get_if<ConsumerInventory>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::consumer_inventory));
        datacube::append_octets(payload, encode_consumer_inventory(*inventory)); return payload;
    }
    if (const auto* history = std::get_if<ResultReviewHistory>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::result_review_history));
        datacube::append_octets(payload, encode_result_review_history(*history)); return payload;
    }
    if (const auto* query = std::get_if<ActionResultDiscovery>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::action_result_discovery));
        datacube::append_octets(payload, encode_action_result_discovery(*query)); return payload;
    }
    if (const auto* query = std::get_if<ActionResultQuery>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::action_result_query));
        datacube::append_octets(payload, encode_action_result_query(*query)); return payload;
    }
    if (const auto* query = std::get_if<ActionQuery>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::action_query));
        datacube::append_octets(payload, encode_action_query(*query)); return payload;
    }
    if (const auto* query = std::get_if<OutboxQuery>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::outbox_query));
        datacube::append_octets(payload, encode_outbox_query(*query)); return payload;
    }
    if (const auto* query = std::get_if<EvidenceQuery>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::evidence_query));
        datacube::append_octets(payload, encode_evidence_query(*query));
        return payload;
    }
    if (const auto* config = std::get_if<ControlConfiguration>(&request)) {
        require_reason(config->reason);
        const bool rollback = !config->rollback_generation.empty();
        if (rollback == !config->candidate_path.empty()) {
            app_fail("CONTROL_PROTOCOL_REJECTED", "exactly one configuration selector is required");
        }
        if (rollback) { require_generation_id(config->rollback_generation, "rollback generation"); }
        datacube::append_u8(payload, static_cast<std::uint8_t>(rollback ?
            ControlKind::config_rollback : ControlKind::config_activate));
        append_text16(payload, rollback ? config->rollback_generation : config->candidate_path,
            rollback ? 64U : 4096U, "configuration selector");
        append_text16(payload, config->reason, 256U, "configuration reason");
        return payload;
    }
    if (const auto* author = std::get_if<ControlAuthor>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::author));
        datacube::append_octets(payload, encode_application_message(author->record));
        return payload;
    }
    if (const auto* submit = std::get_if<ControlSubmit>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::submit));
        const auto application = encode_application_message(submit->record);
        datacube::append_octets(payload, application);
        return payload;
    }
    if (std::holds_alternative<ControlStateHead>(request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::state_head));
        return payload;
    }
    if (const auto* snapshot = std::get_if<ControlSnapshot>(&request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(snapshot->logical_digest ?
            ControlKind::snapshot_with_digest : ControlKind::snapshot));
        return payload;
    }
    if (const auto* wake = std::get_if<ControlWake>(&request)) {
        require_node_id(wake->peer, "wake peer");
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::wake));
        append_text16(payload, wake->peer, 64U, "wake peer");
        return payload;
    }
    if (const auto* shutdown = std::get_if<ControlShutdown>(&request)) {
        if (shutdown->correlation.has_value()) {
            require_stop_correlation(*shutdown->correlation);
            datacube::append_u8(payload, static_cast<std::uint8_t>(
                shutdown->final_state_head ?
                    ControlKind::shutdown_final_head_correlated :
                    ControlKind::shutdown_correlated));
            append_text16(payload, *shutdown->correlation,
                kMaximumStopCorrelationBytes, "stop correlation");
        } else {
            datacube::append_u8(payload,
                static_cast<std::uint8_t>(shutdown->final_state_head ?
                    ControlKind::shutdown_final_head : ControlKind::shutdown));
        }
        return payload;
    }
    if (const auto* conditional = std::get_if<OutboxAdminRequest>(&request)) {
        datacube::append_u8(payload,static_cast<std::uint8_t>(ControlKind::outbox_conditional));
        datacube::append_octets(payload,encode_outbox_admin_request(*conditional));return payload;
    }
    if (const auto* rebind = std::get_if<ControlRebind>(&request)) {
        require_generation_id(rebind->generation, "target generation");
        require_reason(rebind->reason);
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::rebind));
        append_operation_id(payload, rebind->operation_id);
        append_text16(payload, rebind->generation, 64U, "target generation");
        append_text16(payload, rebind->reason, 256U, "reason");
        return payload;
    }
    if (const auto* cancel = std::get_if<ControlCancel>(&request)) {
        require_reason(cancel->reason);
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::cancel));
        append_operation_id(payload, cancel->operation_id);
        append_text16(payload, cancel->reason, 256U, "reason");
        return payload;
    }
    if (const auto* retry = std::get_if<ControlRetry>(&request)) {
        require_reason(retry->reason);
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::retry));
        append_operation_id(payload, retry->operation_id);
        append_text16(payload, retry->reason, 256U, "reason");
        return payload;
    }
    if (const auto* dispatch = std::get_if<ControlCustodyDispatch>(&request)) {
        require_generation_id(dispatch->activation_id, "custody dispatch activation ID");
        if (dispatch->activation_generation == 0U) {
            app_fail("CONTROL_PROTOCOL_REJECTED",
                "custody dispatch activation generation must be nonzero");
        }
        require_reason(dispatch->reason);
        datacube::append_u8(payload,
            static_cast<std::uint8_t>(ControlKind::custody_dispatch));
        append_text16(payload, dispatch->activation_id, 64U,
            "custody dispatch activation ID");
        datacube::append_be64(payload, dispatch->activation_generation);
        append_operation_id(payload, dispatch->receiver_request_digest);
        append_operation_id(payload, dispatch->dispatch_request_digest);
        append_text16(payload, dispatch->reason, 256U, "reason");
        return payload;
    }
    if (const auto* status =
            std::get_if<ControlCustodyDispatchStatus>(&request)) {
        require_generation_id(status->activation_id,
            "custody dispatch status activation ID");
        if (status->activation_generation == 0U) {
            app_fail("CONTROL_PROTOCOL_REJECTED",
                "custody dispatch status activation generation must be nonzero");
        }
        datacube::append_u8(payload,
            static_cast<std::uint8_t>(
                ControlKind::custody_dispatch_status));
        append_text16(payload, status->activation_id, 64U,
            "custody dispatch status activation ID");
        datacube::append_be64(payload, status->activation_generation);
        append_operation_id(payload, status->dispatch_request_digest);
        return payload;
    }
    if (const auto* inventory =
            std::get_if<ControlCustodyDispatchInventory>(&request)) {
        require_generation_id(inventory->activation_id,
            "custody dispatch inventory activation ID");
        if (inventory->activation_generation == 0U ||
            inventory->limit == 0U || inventory->limit > 64U ||
            inventory->maximum_bytes < 2'048U ||
            inventory->maximum_bytes > 60'000U) {
            app_fail("CONTROL_PROTOCOL_REJECTED",
                "custody dispatch inventory bounds are invalid");
        }
        datacube::append_u8(payload,
            static_cast<std::uint8_t>(
                ControlKind::custody_dispatch_inventory));
        append_text16(payload, inventory->activation_id, 64U,
            "custody dispatch inventory activation ID");
        datacube::append_be64(payload, inventory->activation_generation);
        datacube::append_u8(payload,
            inventory->cursor.has_value() ? 1U : 0U);
        if (inventory->cursor) {
            append_operation_id(payload, *inventory->cursor);
        }
        datacube::append_be32(payload, inventory->limit);
        datacube::append_be32(payload, inventory->maximum_bytes);
        return payload;
    }
    if (std::holds_alternative<ControlCompact>(request)) {
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::compact));
        return payload;
    }
    if (const auto* quiesce = std::get_if<ControlQuiesce>(&request)) {
        require_reason(quiesce->reason);
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::quiesce));
        append_text16(payload, quiesce->reason, 256U, "quiesce reason");
        return payload;
    }
    if (const auto* resume = std::get_if<ControlResume>(&request)) {
        require_reason(resume->reason);
        datacube::append_u8(payload, static_cast<std::uint8_t>(ControlKind::resume));
        append_text16(payload, resume->reason, 256U, "resume reason");
        return payload;
    }
    if (const auto* drain = std::get_if<ControlDrainShutdown>(&request)) {
        require_reason(drain->reason);
        if (drain->deadline_ms == 0U || drain->deadline_ms > 600'000U) {
            app_fail("CONTROL_PROTOCOL_REJECTED",
                "drain deadline must be 1..600000 milliseconds");
        }
        if (drain->correlation.has_value()) {
            require_stop_correlation(*drain->correlation);
            datacube::append_u8(payload, static_cast<std::uint8_t>(
                drain->final_state_head ?
                    ControlKind::drain_shutdown_final_head_correlated :
                    ControlKind::drain_shutdown_correlated));
        } else {
            datacube::append_u8(payload,
                static_cast<std::uint8_t>(drain->final_state_head ?
                    ControlKind::drain_shutdown_final_head : ControlKind::drain_shutdown));
        }
        datacube::append_be32(payload, drain->deadline_ms);
        append_text16(payload, drain->reason, 256U, "drain reason");
        if (drain->correlation.has_value()) {
            append_text16(payload, *drain->correlation,
                kMaximumStopCorrelationBytes, "stop correlation");
        }
        return payload;
    }
    if (const auto* conditional = std::get_if<ActionAdminRequest>(&request)) {
        datacube::append_u8(payload,
            static_cast<std::uint8_t>(ControlKind::action_conditional));
        datacube::append_octets(payload,
            encode_action_admin_request(*conditional));
        return payload;
    }
    const auto& cancel = std::get<ControlActionCancel>(request);
    require_reason(cancel.reason);
    datacube::append_u8(
        payload, static_cast<std::uint8_t>(ControlKind::action_cancel));
    append_operation_id(payload, cancel.action_id);
    append_text16(payload, cancel.reason, 256U, "reason");
    return payload;
}

ControlRequest decode_control_request(const datacube::OctetView payload) {
    datacube::Reader reader(payload, "control request");
    require_magic(reader, kRequestMagic, "control request");
    const auto kind = reader.read_u8("control kind");
    if (kind == static_cast<std::uint8_t>(ControlKind::view_bindings)) {
        return decode_view_bindings(reader.read_exact(reader.remaining(), "view bindings"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::source_view_inventory)) {
        return decode_source_view_inventory(reader.read_exact(reader.remaining(), "source view inventory"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::subscription_inventory)) {
        return decode_subscription_inventory(reader.read_exact(reader.remaining(), "subscription inventory"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::publication_inventory)) {
        return decode_publication_inventory(reader.read_exact(reader.remaining(), "publication inventory"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::consumer_inventory)) {
        return decode_consumer_inventory(reader.read_exact(reader.remaining(), "consumer inventory"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::control_history)) {
        return decode_control_history(reader.read_exact(reader.remaining(), "control history"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::configuration_history)) {
        return decode_configuration_history(reader.read_exact(reader.remaining(), "configuration history"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::runtime_inventory)) {
        return decode_runtime_inventory(reader.read_exact(reader.remaining(), "runtime inventory"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::import_auto)) {
        return decode_import_auto_request(reader.read_exact(reader.remaining(),"import automation request"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::source_import)) {
        return decode_source_view_request(reader.read_exact(reader.remaining(),"source view request"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::source_subscription)) {
        return decode_source_subscription_request(reader.read_exact(reader.remaining(), "source subscription"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::publication_channel)) {
        return decode_publication_channel_request(
            reader.read_exact(reader.remaining(), "publication channel request"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::author)) {
        const auto message = decode_application_message(reader.read_exact(reader.remaining(), "authored evidence"));
        const auto* record = std::get_if<EvidenceRecord>(&message);
        if (record == nullptr) { app_fail("CONTROL_PROTOCOL_REJECTED", "local author command requires evidence"); }
        return ControlAuthor{.record = *record};
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::consumer)) {
        return decode_consumer_request(reader.read_exact(reader.remaining(), "consumer request"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::evidence_feed)) {
        return decode_evidence_feed(reader.read_exact(static_cast<std::size_t>(reader.remaining()), "evidence feed"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::result_review)) {
        return decode_result_review(reader.read_exact(reader.remaining(), "result review"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::result_review_status)) {
        return decode_result_review_status(reader.read_exact(reader.remaining(), "result review status"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::result_review_history)) {
        return decode_result_review_history(reader.read_exact(reader.remaining(), "result review history"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::action_result_discovery)) {
        return decode_action_result_discovery(reader.read_exact(reader.remaining(), "action result discovery"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::action_result_query)) {
        return decode_action_result_query(reader.read_exact(reader.remaining(), "action result query"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::action_query)) {
        return decode_action_query(reader.read_exact(reader.remaining(), "action query"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::action_conditional)) {
        return decode_action_admin_request(
            reader.read_exact(reader.remaining(), "conditional action request"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::outbox_query)) {
        return decode_outbox_query(reader.read_exact(static_cast<std::size_t>(reader.remaining()), "outbox query"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::evidence_query)) {
        return decode_evidence_query(reader.read_exact(static_cast<std::size_t>(reader.remaining()), "evidence query"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::config_activate) ||
        kind == static_cast<std::uint8_t>(ControlKind::config_rollback)) {
        const bool rollback = kind == static_cast<std::uint8_t>(ControlKind::config_rollback);
        const auto selector = read_text16(reader, rollback ? 64U : 4096U, "configuration selector");
        const auto reason = read_text16(reader, 256U, "configuration reason");
        reader.require_eof("configuration request");
        require_reason(reason);
        if (selector.empty()) { app_fail("CONTROL_PROTOCOL_REJECTED", "empty configuration selector"); }
        if (rollback) { require_generation_id(selector, "rollback generation"); }
        return ControlConfiguration{
            .candidate_path = rollback ? std::string{} : selector,
            .rollback_generation = rollback ? selector : std::string{},
            .reason = reason,
        };
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::submit)) {
        const auto remaining = reader.read_exact(
            static_cast<std::uint64_t>(reader.remaining()), "submit application");
        const auto message = decode_application_message(remaining);
        const auto* record = std::get_if<EvidenceRecord>(&message);
        if (record == nullptr) {
            app_fail("CONTROL_PROTOCOL_REJECTED",
                "submit request must contain evidence or a correction");
        }
        return ControlSubmit{.record = *record};
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::state_head)) {
        reader.require_eof("state head request");
        return ControlStateHead{};
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::snapshot) ||
        kind == static_cast<std::uint8_t>(ControlKind::snapshot_with_digest)) {
        reader.require_eof("snapshot request");
        return ControlSnapshot{.logical_digest = kind == static_cast<std::uint8_t>(ControlKind::snapshot_with_digest)};
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::wake)) {
        auto peer = read_text16(reader, 64U, "wake peer");
        reader.require_eof("wake request");
        require_node_id(peer, "wake peer");
        return ControlWake{.peer = std::move(peer)};
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::shutdown) ||
        kind == static_cast<std::uint8_t>(ControlKind::shutdown_final_head)) {
        reader.require_eof("shutdown request");
        return ControlShutdown{
            .final_state_head =
                kind == static_cast<std::uint8_t>(ControlKind::shutdown_final_head),
            .correlation = std::nullopt,
        };
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::shutdown_correlated) ||
        kind == static_cast<std::uint8_t>(ControlKind::shutdown_final_head_correlated)) {
        auto correlation = read_text16(reader, kMaximumStopCorrelationBytes,
            "stop correlation");
        reader.require_eof("correlated shutdown request");
        require_stop_correlation(correlation);
        return ControlShutdown{
            .final_state_head = kind == static_cast<std::uint8_t>(
                ControlKind::shutdown_final_head_correlated),
            .correlation = std::move(correlation),
        };
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::outbox_conditional)) {
        return decode_outbox_admin_request(reader.read_exact(reader.remaining(),"conditional action"));
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::rebind)) {
        auto operation_id = read_operation_id(reader);
        auto generation = read_text16(reader, 64U, "target generation");
        auto reason = read_text16(reader, 256U, "reason");
        reader.require_eof("rebind request");
        require_generation_id(generation, "target generation");
        require_reason(reason);
        return ControlRebind{
            .operation_id = operation_id,
            .generation = std::move(generation),
            .reason = std::move(reason),
        };
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::cancel)) {
        auto operation_id = read_operation_id(reader);
        auto reason = read_text16(reader, 256U, "reason");
        reader.require_eof("cancel request");
        require_reason(reason);
        return ControlCancel{
            .operation_id = operation_id,
            .reason = std::move(reason),
        };
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::retry)) {
        auto operation_id = read_operation_id(reader);
        auto reason = read_text16(reader, 256U, "reason");
        reader.require_eof("retry request");
        require_reason(reason);
        return ControlRetry{
            .operation_id = operation_id,
            .reason = std::move(reason),
        };
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::custody_dispatch)) {
        auto activation_id = read_text16(reader, 64U,
            "custody dispatch activation ID");
        const auto activation_generation = reader.read_be64(
            "custody dispatch activation generation");
        auto receiver_request_digest = read_operation_id(reader);
        auto dispatch_request_digest = read_operation_id(reader);
        auto reason = read_text16(reader, 256U, "reason");
        reader.require_eof("custody dispatch request");
        require_generation_id(activation_id, "custody dispatch activation ID");
        if (activation_generation == 0U) {
            app_fail("CONTROL_PROTOCOL_REJECTED",
                "custody dispatch activation generation must be nonzero");
        }
        require_reason(reason);
        return ControlCustodyDispatch{
            .activation_id = std::move(activation_id),
            .activation_generation = activation_generation,
            .receiver_request_digest = receiver_request_digest,
            .dispatch_request_digest = dispatch_request_digest,
            .reason = std::move(reason),
        };
    }
    if (kind == static_cast<std::uint8_t>(
            ControlKind::custody_dispatch_status)) {
        auto activation_id = read_text16(reader, 64U,
            "custody dispatch status activation ID");
        const auto activation_generation = reader.read_be64(
            "custody dispatch status activation generation");
        auto dispatch_request_digest = read_operation_id(reader);
        reader.require_eof("custody dispatch status request");
        require_generation_id(activation_id,
            "custody dispatch status activation ID");
        if (activation_generation == 0U) {
            app_fail("CONTROL_PROTOCOL_REJECTED",
                "custody dispatch status activation generation must be nonzero");
        }
        return ControlCustodyDispatchStatus{
            .activation_id = std::move(activation_id),
            .activation_generation = activation_generation,
            .dispatch_request_digest = dispatch_request_digest,
        };
    }
    if (kind == static_cast<std::uint8_t>(
            ControlKind::custody_dispatch_inventory)) {
        auto activation_id = read_text16(reader, 64U,
            "custody dispatch inventory activation ID");
        const auto activation_generation = reader.read_be64(
            "custody dispatch inventory activation generation");
        const auto cursor_present = reader.read_u8(
            "custody dispatch inventory cursor presence");
        if (cursor_present > 1U) {
            app_fail("CONTROL_PROTOCOL_REJECTED",
                "custody dispatch inventory cursor presence is invalid");
        }
        std::optional<datacube::Digest32> cursor;
        if (cursor_present == 1U) {
            cursor = read_operation_id(reader);
        }
        const auto limit = reader.read_be32(
            "custody dispatch inventory limit");
        const auto maximum_bytes = reader.read_be32(
            "custody dispatch inventory byte bound");
        reader.require_eof("custody dispatch inventory request");
        require_generation_id(activation_id,
            "custody dispatch inventory activation ID");
        if (activation_generation == 0U || limit == 0U || limit > 64U ||
            maximum_bytes < 2'048U || maximum_bytes > 60'000U) {
            app_fail("CONTROL_PROTOCOL_REJECTED",
                "custody dispatch inventory bounds are invalid");
        }
        return ControlCustodyDispatchInventory{
            .activation_id = std::move(activation_id),
            .activation_generation = activation_generation,
            .cursor = cursor,
            .limit = limit,
            .maximum_bytes = maximum_bytes,
        };
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::action_cancel)) {
        auto action_id = read_operation_id(reader);
        auto reason = read_text16(reader, 256U, "reason");
        reader.require_eof("action cancel request");
        require_reason(reason);
        return ControlActionCancel{
            .action_id = action_id,
            .reason = std::move(reason),
        };
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::compact)) {
        reader.require_eof("compact request");
        return ControlCompact{};
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::quiesce)) {
        auto reason = read_text16(reader, 256U, "quiesce reason");
        reader.require_eof("quiesce request");
        require_reason(reason);
        return ControlQuiesce{.reason = std::move(reason)};
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::resume)) {
        auto reason = read_text16(reader, 256U, "resume reason");
        reader.require_eof("resume request");
        require_reason(reason);
        return ControlResume{.reason = std::move(reason)};
    }
    if (kind == static_cast<std::uint8_t>(ControlKind::drain_shutdown) ||
        kind == static_cast<std::uint8_t>(ControlKind::drain_shutdown_final_head) ||
        kind == static_cast<std::uint8_t>(ControlKind::drain_shutdown_correlated) ||
        kind == static_cast<std::uint8_t>(ControlKind::drain_shutdown_final_head_correlated)) {
        const auto deadline_ms = reader.read_be32("drain deadline");
        auto reason = read_text16(reader, 256U, "drain reason");
        std::optional<std::string> correlation;
        if (kind == static_cast<std::uint8_t>(ControlKind::drain_shutdown_correlated) ||
            kind == static_cast<std::uint8_t>(ControlKind::drain_shutdown_final_head_correlated)) {
            correlation = read_text16(reader, kMaximumStopCorrelationBytes,
                "stop correlation");
            require_stop_correlation(*correlation);
        }
        reader.require_eof("drain request");
        require_reason(reason);
        if (deadline_ms == 0U || deadline_ms > 600'000U) {
            app_fail("CONTROL_PROTOCOL_REJECTED",
                "drain deadline must be 1..600000 milliseconds");
        }
        return ControlDrainShutdown{
            .deadline_ms = deadline_ms,
            .reason = std::move(reason),
            .final_state_head =
                kind == static_cast<std::uint8_t>(ControlKind::drain_shutdown_final_head) ||
                kind == static_cast<std::uint8_t>(ControlKind::drain_shutdown_final_head_correlated),
            .correlation = std::move(correlation),
        };
    }
    app_fail("CONTROL_PROTOCOL_REJECTED", "unknown control request kind");
}

datacube::Octets encode_control_response(const ControlResponse& response) {
    if (response.json.empty() || response.json.size() > kMaximumControlJsonBytes) {
        app_fail("CONTROL_RESPONSE_INVALID", "response JSON is outside its envelope");
    }
    datacube::Octets payload;
    payload.reserve(kResponseMagic.size() + 1U + response.json.size());
    datacube::append_octets(payload, kResponseMagic);
    datacube::append_u8(payload, response.ok ? 0U : 1U);
    datacube::append_text(payload, response.json);
    return payload;
}

ControlResponse decode_control_response(const datacube::OctetView payload) {
    datacube::Reader reader(payload, "control response");
    require_magic(reader, kResponseMagic, "control response");
    const auto status = reader.read_u8("control status");
    if (status > 1U) {
        app_fail("CONTROL_PROTOCOL_REJECTED", "invalid control response status");
    }
    if (reader.remaining() == 0U || reader.remaining() > kMaximumControlJsonBytes) {
        app_fail("CONTROL_PROTOCOL_REJECTED", "invalid control response size");
    }
    const auto text = datacube::octets_text(
        reader.read_exact(static_cast<std::uint64_t>(reader.remaining()), "response JSON"),
        "response JSON", true);
    reader.require_eof("control response");
    return ControlResponse{.ok = status == 0U, .json = text};
}


datacube::Digest32 control_request_id(const datacube::OctetView payload) {
    datacube::Octets material;
    datacube::append_text(material, "NATRAV_OVERLAY_CONTROL_REQUEST_ID_V1");
    datacube::append_u8(material, 0U);
    datacube::append_be64(material, static_cast<std::uint64_t>(payload.size()));
    datacube::append_octets(material, payload);
    return datacube::sha256(material);
}

}  // namespace natrav_overlay
