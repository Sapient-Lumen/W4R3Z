#include "adapter_profile.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <charconv>
#include <climits>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <filesystem>
#include <grp.h>
#include <limits>
#include <memory>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <span>
#include <string>
#include <string_view>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace natrav_overlay {

int operator_pinned_adapter_profile_revision_abi() noexcept { return 1; }

AdapterProfileError::AdapterProfileError(std::string code, std::string detail)
    : std::runtime_error(code + ": " + detail), code_(std::move(code)) {}

const std::string& AdapterProfileError::code() const noexcept { return code_; }

namespace {

inline constexpr std::string_view kProfileMagic =
    "NATRAV_ADAPTER_PROFILE_V1";
inline constexpr std::string_view kLocatorPrefix = "adapter-v1|";
inline constexpr std::size_t kMaximumProfileBytes = 32'768U;
inline constexpr std::size_t kMaximumProfileIdBytes = 64U;
inline constexpr std::size_t kMaximumPathBytes = 4'096U;
inline constexpr std::size_t kMaximumArguments = 64U;
inline constexpr std::size_t kMaximumArgumentBytes = 4'096U;
inline constexpr std::size_t kMaximumTotalArgumentBytes = 16'384U;
inline constexpr std::size_t kMinimumMtu = 256U;
inline constexpr std::size_t kMaximumMtu = 65'507U;
inline constexpr std::size_t kFrameHeaderBytes = 36U;
inline constexpr std::size_t kAbsoluteMaximumFrameBytes = 1'048'576U;
inline constexpr std::size_t kAbsoluteMaximumQueuedBytes = 64U * 1'048'576U;
inline constexpr std::uint32_t kMaximumLaunchAttempts = 8U;
inline constexpr std::uint64_t kMaximumExecutableBytes = 128ULL * 1'048'576ULL;
inline constexpr std::size_t kCopyBufferBytes = 64U * 1'024U;

[[noreturn]] void fail(const std::string_view code, const std::string_view detail) {
    throw AdapterProfileError(std::string(code), std::string(detail));
}

[[nodiscard]] bool is_zero_digest(const AdapterSha256& digest) noexcept {
    return std::all_of(digest.begin(), digest.end(), [](const std::uint8_t value) {
        return value == 0U;
    });
}

[[nodiscard]] bool valid_profile_id(const std::string_view value) noexcept {
    if (value.empty() || value.size() > kMaximumProfileIdBytes ||
        value.front() < 'a' || value.front() > 'z' ||
        !((value.back() >= 'a' && value.back() <= 'z') ||
          (value.back() >= '0' && value.back() <= '9'))) {
        return false;
    }
    return std::all_of(value.begin(), value.end(), [](const char character) {
        return (character >= 'a' && character <= 'z') ||
            (character >= '0' && character <= '9') || character == '-';
    });
}

[[nodiscard]] bool canonical_absolute_path(const std::filesystem::path& path) {
    const auto text = path.string();
    if (text.empty() || text.size() > kMaximumPathBytes ||
        text.find('\0') != std::string::npos || !path.is_absolute() ||
        path == path.root_path() || path.lexically_normal() != path ||
        text.back() == '/') {
        return false;
    }
    for (const auto& component : path.relative_path()) {
        const auto part = component.string();
        if (part.empty() || part == "." || part == ".." ||
            part.find('\0') != std::string::npos) {
            return false;
        }
    }
    return true;
}

[[nodiscard]] bool duration_in_range(
    const std::chrono::milliseconds value,
    const std::chrono::milliseconds minimum,
    const std::chrono::milliseconds maximum) noexcept {
    return value >= minimum && value <= maximum;
}

[[nodiscard]] std::string canonical_decimal(const std::uint64_t value) {
    return std::to_string(value);
}

[[nodiscard]] std::uint64_t parse_u64(
    const std::string_view text,
    const std::string_view field,
    const bool allow_zero = false) {
    if (text.empty() || (text.size() > 1U && text.front() == '0')) {
        fail("ADAPTER_PROFILE_NONCANONICAL", std::string(field));
    }
    std::uint64_t value = 0U;
    const auto [end, error] = std::from_chars(
        text.data(), text.data() + text.size(), value, 10);
    if (error != std::errc{} || end != text.data() + text.size() ||
        (!allow_zero && value == 0U)) {
        fail("ADAPTER_PROFILE_INVALID", std::string(field));
    }
    return value;
}

[[nodiscard]] std::uint32_t parse_u32(
    const std::string_view text,
    const std::string_view field,
    const bool allow_zero = false) {
    const auto value = parse_u64(text, field, allow_zero);
    if (value > std::numeric_limits<std::uint32_t>::max()) {
        fail("ADAPTER_PROFILE_INVALID", std::string(field));
    }
    return static_cast<std::uint32_t>(value);
}

[[nodiscard]] std::size_t parse_size(
    const std::string_view text,
    const std::string_view field,
    const bool allow_zero = false) {
    const auto value = parse_u64(text, field, allow_zero);
    if (value > std::numeric_limits<std::size_t>::max()) {
        fail("ADAPTER_PROFILE_INVALID", std::string(field));
    }
    return static_cast<std::size_t>(value);
}

[[nodiscard]] bool unreserved(const unsigned char value) noexcept {
    return (value >= 'A' && value <= 'Z') || (value >= 'a' && value <= 'z') ||
        (value >= '0' && value <= '9') || value == '-' || value == '.' ||
        value == '_' || value == '~';
}

[[nodiscard]] char hex_digit(const std::uint8_t value) noexcept {
    return value < 10U ? static_cast<char>('0' + value) :
        static_cast<char>('A' + (value - 10U));
}

[[nodiscard]] std::string percent_encode(const std::string_view value) {
    std::string out;
    out.reserve(value.size());
    for (const char character : value) {
        const auto byte = static_cast<unsigned char>(character);
        if (unreserved(byte)) {
            out.push_back(static_cast<char>(byte));
        } else {
            out.push_back('%');
            out.push_back(hex_digit(static_cast<std::uint8_t>(byte >> 4U)));
            out.push_back(hex_digit(static_cast<std::uint8_t>(byte & 0x0fU)));
        }
    }
    return out;
}

[[nodiscard]] std::uint8_t uppercase_hex_value(const char value) {
    if (value >= '0' && value <= '9') {
        return static_cast<std::uint8_t>(value - '0');
    }
    if (value >= 'A' && value <= 'F') {
        return static_cast<std::uint8_t>(value - 'A' + 10);
    }
    fail("ADAPTER_PROFILE_NONCANONICAL", "percent escape");
}

[[nodiscard]] std::string percent_decode(const std::string_view value) {
    std::string out;
    out.reserve(value.size());
    for (std::size_t index = 0U; index < value.size();) {
        if (value[index] != '%') {
            const auto byte = static_cast<unsigned char>(value[index]);
            if (!unreserved(byte)) {
                fail("ADAPTER_PROFILE_NONCANONICAL", "unescaped profile byte");
            }
            out.push_back(value[index]);
            ++index;
            continue;
        }
        if (index + 2U >= value.size()) {
            fail("ADAPTER_PROFILE_INVALID", "truncated percent escape");
        }
        const auto byte = static_cast<std::uint8_t>(
            (uppercase_hex_value(value[index + 1U]) << 4U) |
            uppercase_hex_value(value[index + 2U]));
        if (byte == 0U || unreserved(byte)) {
            fail("ADAPTER_PROFILE_NONCANONICAL", "redundant percent escape");
        }
        out.push_back(static_cast<char>(byte));
        index += 3U;
    }
    if (percent_encode(out) != value) {
        fail("ADAPTER_PROFILE_NONCANONICAL", "percent encoding");
    }
    return out;
}

[[nodiscard]] std::vector<std::string_view> split_lines(
    const std::string_view text) {
    if (text.empty() || text.size() > kMaximumProfileBytes || text.back() != '\n') {
        fail("ADAPTER_PROFILE_INVALID", "profile record size or terminator");
    }
    std::vector<std::string_view> lines;
    std::size_t begin = 0U;
    while (begin < text.size()) {
        const auto end = text.find('\n', begin);
        if (end == std::string_view::npos) {
            fail("ADAPTER_PROFILE_INVALID", "profile line termination");
        }
        lines.push_back(text.substr(begin, end - begin));
        begin = end + 1U;
    }
    return lines;
}

[[nodiscard]] std::string_view field_value(
    const std::string_view line,
    const std::string_view field) {
    const std::string prefix = std::string(field) + '=';
    if (!line.starts_with(prefix)) {
        fail("ADAPTER_PROFILE_NONCANONICAL", std::string(field));
    }
    return line.substr(prefix.size());
}

[[nodiscard]] AdapterSha256 sha256_impl(
    const std::span<const std::uint8_t> bytes) {
    AdapterSha256 digest{};
    EVP_MD_CTX* raw = EVP_MD_CTX_new();
    if (raw == nullptr) {
        fail("ADAPTER_SHA256_FAILED", "EVP_MD_CTX_new");
    }
    const std::unique_ptr<EVP_MD_CTX, decltype(&EVP_MD_CTX_free)> context(
        raw, EVP_MD_CTX_free);
    unsigned int size = 0U;
    if (EVP_DigestInit_ex(context.get(), EVP_sha256(), nullptr) != 1 ||
        (!bytes.empty() &&
         EVP_DigestUpdate(context.get(), bytes.data(), bytes.size()) != 1) ||
        EVP_DigestFinal_ex(context.get(), digest.data(), &size) != 1 ||
        size != digest.size()) {
        fail("ADAPTER_SHA256_FAILED", "EVP digest operation");
    }
    return digest;
}

[[nodiscard]] bool effective_user_can_execute(const struct stat& status) {
    const uid_t user = ::geteuid();
    if (user == 0U) {
        return (status.st_mode & (S_IXUSR | S_IXGRP | S_IXOTH)) != 0;
    }
    if (status.st_uid == user) {
        return (status.st_mode & S_IXUSR) != 0;
    }
    const gid_t group = ::getegid();
    if (status.st_gid == group && (status.st_mode & S_IXGRP) != 0) {
        return true;
    }
    const int count = ::getgroups(0, nullptr);
    if (count < 0) {
        fail("ADAPTER_EXECUTABLE_STAT_FAILED", "getgroups");
    }
    std::vector<gid_t> groups(static_cast<std::size_t>(count));
    if (count != 0 && ::getgroups(count, groups.data()) != count) {
        fail("ADAPTER_EXECUTABLE_STAT_FAILED", "getgroups values");
    }
    return (status.st_mode & S_IXGRP) != 0 &&
        std::find(groups.begin(), groups.end(), status.st_gid) != groups.end();
}

class OwnedFd final {
public:
    explicit OwnedFd(const int descriptor = -1) noexcept : descriptor_(descriptor) {}
    OwnedFd(const OwnedFd&) = delete;
    OwnedFd& operator=(const OwnedFd&) = delete;
    OwnedFd(OwnedFd&& other) noexcept : descriptor_(std::exchange(other.descriptor_, -1)) {}
    OwnedFd& operator=(OwnedFd&& other) noexcept {
        if (this != &other) {
            reset();
            descriptor_ = std::exchange(other.descriptor_, -1);
        }
        return *this;
    }
    ~OwnedFd() { reset(); }
    [[nodiscard]] int get() const noexcept { return descriptor_; }
    [[nodiscard]] int release() noexcept { return std::exchange(descriptor_, -1); }
    void reset(const int next = -1) noexcept {
        if (descriptor_ >= 0) {
            static_cast<void>(::close(descriptor_));
        }
        descriptor_ = next;
    }
private:
    int descriptor_{-1};
};

[[nodiscard]] OwnedFd open_without_symlinks(const std::filesystem::path& path) {
    if (!canonical_absolute_path(path)) {
        fail("ADAPTER_EXECUTABLE_INVALID", "noncanonical absolute executable path");
    }
    OwnedFd directory(::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC));
    if (directory.get() < 0) {
        fail("ADAPTER_EXECUTABLE_OPEN_FAILED", "root directory");
    }
    std::vector<std::string> components;
    for (const auto& component : path.relative_path()) {
        components.push_back(component.string());
    }
    if (components.empty()) {
        fail("ADAPTER_EXECUTABLE_INVALID", "missing executable component");
    }
    for (std::size_t index = 0U; index + 1U < components.size(); ++index) {
        struct stat component_status {};
        if (::fstatat(directory.get(), components[index].c_str(),
                      &component_status, AT_SYMLINK_NOFOLLOW) == 0 &&
            S_ISLNK(component_status.st_mode)) {
            fail("ADAPTER_EXECUTABLE_SYMLINK", components[index]);
        }
        const int next = ::openat(
            directory.get(),
            components[index].c_str(),
            O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
        if (next < 0) {
            const auto code = errno == ELOOP ?
                "ADAPTER_EXECUTABLE_SYMLINK" : "ADAPTER_EXECUTABLE_OPEN_FAILED";
            fail(code, components[index]);
        }
        directory.reset(next);
    }
    struct stat final_status {};
    if (::fstatat(directory.get(), components.back().c_str(),
                  &final_status, AT_SYMLINK_NOFOLLOW) == 0 &&
        S_ISLNK(final_status.st_mode)) {
        fail("ADAPTER_EXECUTABLE_SYMLINK", components.back());
    }
    const int descriptor = ::openat(
        directory.get(),
        components.back().c_str(),
        O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (descriptor < 0) {
        const auto code = errno == ELOOP ?
            "ADAPTER_EXECUTABLE_SYMLINK" : "ADAPTER_EXECUTABLE_OPEN_FAILED";
        fail(code, components.back());
    }
    return OwnedFd(descriptor);
}

[[nodiscard]] OwnedFd create_sealed_memfd() {
#if defined(SYS_memfd_create)
    const int descriptor = static_cast<int>(::syscall(
        SYS_memfd_create,
        "natrav-adapter-image",
        static_cast<unsigned int>(MFD_CLOEXEC | MFD_ALLOW_SEALING)));
    if (descriptor < 0) {
        fail("ADAPTER_EXECUTABLE_SEAL_FAILED", "memfd_create");
    }
    return OwnedFd(descriptor);
#else
    fail("ADAPTER_EXECUTABLE_SEAL_UNSUPPORTED", "memfd_create unavailable");
#endif
}

void write_all_at(
    const int descriptor,
    const std::span<const std::uint8_t> bytes,
    const off_t offset) {
    std::size_t written = 0U;
    while (written < bytes.size()) {
        const auto result = ::pwrite(
            descriptor,
            bytes.data() + written,
            bytes.size() - written,
            offset + static_cast<off_t>(written));
        if (result < 0 && errno == EINTR) {
            continue;
        }
        if (result <= 0) {
            fail("ADAPTER_EXECUTABLE_SEAL_FAILED", "memfd write");
        }
        written += static_cast<std::size_t>(result);
    }
}

[[nodiscard]] std::string hex_u64_16(const std::uint64_t value) {
    std::string out(16U, '0');
    for (std::size_t index = 0U; index < out.size(); ++index) {
        const auto shift = static_cast<unsigned int>((out.size() - index - 1U) * 4U);
        const auto nibble = static_cast<std::uint8_t>((value >> shift) & 0x0fU);
        out[index] = nibble < 10U ? static_cast<char>('0' + nibble) :
            static_cast<char>('a' + (nibble - 10U));
    }
    return out;
}

[[nodiscard]] std::uint64_t parse_lower_hex_u64_16(
    const std::string_view text,
    const std::string_view field) {
    if (text.size() != 16U) {
        fail("ADAPTER_LOCATOR_INVALID", std::string(field));
    }
    std::uint64_t value = 0U;
    for (const char character : text) {
        std::uint8_t nibble = 0U;
        if (character >= '0' && character <= '9') {
            nibble = static_cast<std::uint8_t>(character - '0');
        } else if (character >= 'a' && character <= 'f') {
            nibble = static_cast<std::uint8_t>(character - 'a' + 10);
        } else {
            fail("ADAPTER_LOCATOR_NONCANONICAL", std::string(field));
        }
        value = (value << 4U) | nibble;
    }
    if (value == 0U) {
        fail("ADAPTER_LOCATOR_INVALID", std::string(field));
    }
    return value;
}

}  // namespace

std::string adapter_sha256_hex(const AdapterSha256& digest) {
    std::string out;
    out.reserve(digest.size() * 2U);
    constexpr char alphabet[] = "0123456789abcdef";
    for (const auto byte : digest) {
        out.push_back(alphabet[(byte >> 4U) & 0x0fU]);
        out.push_back(alphabet[byte & 0x0fU]);
    }
    return out;
}

AdapterSha256 parse_adapter_sha256(const std::string_view text) {
    if (text.size() != 64U) {
        fail("ADAPTER_SHA256_INVALID", "digest length");
    }
    AdapterSha256 digest{};
    for (std::size_t index = 0U; index < digest.size(); ++index) {
        std::uint8_t value = 0U;
        for (std::size_t nibble_index = 0U; nibble_index < 2U; ++nibble_index) {
            const char character = text[index * 2U + nibble_index];
            std::uint8_t nibble = 0U;
            if (character >= '0' && character <= '9') {
                nibble = static_cast<std::uint8_t>(character - '0');
            } else if (character >= 'a' && character <= 'f') {
                nibble = static_cast<std::uint8_t>(character - 'a' + 10);
            } else {
                fail("ADAPTER_SHA256_NONCANONICAL", "digest hex");
            }
            value = static_cast<std::uint8_t>((value << 4U) | nibble);
        }
        digest[index] = value;
    }
    return digest;
}

AdapterSha256 adapter_sha256(const std::span<const std::uint8_t> bytes) {
    return sha256_impl(bytes);
}

void validate_operator_pinned_adapter_profile(
    const OperatorPinnedAdapterProfile& profile) {
    if (!valid_profile_id(profile.profile_id)) {
        fail("ADAPTER_PROFILE_ID_INVALID", "stable profile identifier");
    }
    if (profile.generation == 0U) {
        fail("ADAPTER_PROFILE_GENERATION_INVALID", "generation is zero");
    }
    if (!canonical_absolute_path(profile.executable)) {
        fail("ADAPTER_EXECUTABLE_INVALID", "noncanonical absolute executable path");
    }
    if (profile.arguments.size() > kMaximumArguments) {
        fail("ADAPTER_ARGUMENTS_INVALID", "argument count");
    }
    std::size_t total_argument_bytes = profile.executable.string().size() + 1U;
    for (const auto& argument : profile.arguments) {
        if (argument.size() > kMaximumArgumentBytes ||
            argument.find('\0') != std::string::npos ||
            argument.size() >
                std::numeric_limits<std::size_t>::max() - total_argument_bytes - 1U) {
            fail("ADAPTER_ARGUMENTS_INVALID", "argument byte bound");
        }
        total_argument_bytes += argument.size() + 1U;
    }
    if (total_argument_bytes > kMaximumTotalArgumentBytes) {
        fail("ADAPTER_ARGUMENTS_INVALID", "total argument bytes");
    }
    if (profile.mtu < kMinimumMtu || profile.mtu > kMaximumMtu ||
        profile.capability_profile != 1U ||
        profile.max_frame_bytes < kFrameHeaderBytes + profile.mtu ||
        profile.max_frame_bytes > kAbsoluteMaximumFrameBytes ||
        profile.max_queued_bytes < profile.mtu ||
        profile.max_queued_bytes > kAbsoluteMaximumQueuedBytes ||
        profile.max_outstanding_requests != 1U ||
        profile.max_evidence_events < 16U ||
        profile.max_evidence_events > 4'096U ||
        profile.max_launch_attempts == 0U ||
        profile.max_launch_attempts > kMaximumLaunchAttempts ||
        !duration_in_range(profile.startup_timeout,
                           std::chrono::milliseconds(10),
                           std::chrono::seconds(60)) ||
        !duration_in_range(profile.request_timeout,
                           std::chrono::milliseconds(1),
                           std::chrono::seconds(30)) ||
        !duration_in_range(profile.shutdown_timeout,
                           std::chrono::milliseconds(1),
                           std::chrono::seconds(30)) ||
        !duration_in_range(profile.initial_restart_backoff,
                           std::chrono::milliseconds(1),
                           std::chrono::seconds(10)) ||
        !duration_in_range(profile.maximum_restart_backoff,
                           profile.initial_restart_backoff,
                           std::chrono::seconds(30))) {
        fail("ADAPTER_PROFILE_BOUNDS_INVALID", "finite adapter bounds");
    }
}

std::string operator_pinned_adapter_profile_text(
    const OperatorPinnedAdapterProfile& profile) {
    validate_operator_pinned_adapter_profile(profile);
    std::string out;
    out.reserve(1'024U);
    const auto append = [&](const std::string_view field, const std::string& value) {
        out.append(field);
        out.push_back('=');
        out.append(value);
        out.push_back('\n');
    };
    out.append(kProfileMagic);
    out.push_back('\n');
    append("id", profile.profile_id);
    append("generation", canonical_decimal(profile.generation));
    append("previous", adapter_sha256_hex(profile.previous_profile_sha256));
    append("executable", percent_encode(profile.executable.string()));
    append("sha256", adapter_sha256_hex(profile.executable_sha256));
    append("argument-count", canonical_decimal(profile.arguments.size()));
    for (const auto& argument : profile.arguments) {
        append("argument", percent_encode(argument));
    }
    append("mtu", canonical_decimal(profile.mtu));
    append("capability-profile", canonical_decimal(profile.capability_profile));
    append("max-frame-bytes", canonical_decimal(profile.max_frame_bytes));
    append("max-queued-bytes", canonical_decimal(profile.max_queued_bytes));
    append("max-outstanding-requests",
           canonical_decimal(profile.max_outstanding_requests));
    append("max-evidence-events", canonical_decimal(profile.max_evidence_events));
    append("max-launch-attempts", canonical_decimal(profile.max_launch_attempts));
    append("startup-timeout-ms",
           canonical_decimal(static_cast<std::uint64_t>(profile.startup_timeout.count())));
    append("request-timeout-ms",
           canonical_decimal(static_cast<std::uint64_t>(profile.request_timeout.count())));
    append("shutdown-timeout-ms",
           canonical_decimal(static_cast<std::uint64_t>(profile.shutdown_timeout.count())));
    append("initial-restart-backoff-ms",
           canonical_decimal(static_cast<std::uint64_t>(
               profile.initial_restart_backoff.count())));
    append("maximum-restart-backoff-ms",
           canonical_decimal(static_cast<std::uint64_t>(
               profile.maximum_restart_backoff.count())));
    if (out.size() > kMaximumProfileBytes) {
        fail("ADAPTER_PROFILE_INVALID", "canonical record exceeds bound");
    }
    return out;
}

OperatorPinnedAdapterProfile parse_operator_pinned_adapter_profile(
    const std::string_view text) {
    const auto lines = split_lines(text);
    if (lines.size() < 19U || lines.front() != kProfileMagic) {
        fail("ADAPTER_PROFILE_INVALID", "profile magic or field count");
    }
    std::size_t line = 1U;
    OperatorPinnedAdapterProfile profile;
    profile.profile_id = std::string(field_value(lines.at(line++), "id"));
    profile.generation = parse_u64(
        field_value(lines.at(line++), "generation"), "generation");
    profile.previous_profile_sha256 = parse_adapter_sha256(
        field_value(lines.at(line++), "previous"));
    profile.executable = percent_decode(
        field_value(lines.at(line++), "executable"));
    profile.executable_sha256 = parse_adapter_sha256(
        field_value(lines.at(line++), "sha256"));
    const auto argument_count = parse_size(
        field_value(lines.at(line++), "argument-count"),
        "argument-count", true);
    if (argument_count > kMaximumArguments ||
        line + argument_count + 12U != lines.size()) {
        fail("ADAPTER_PROFILE_INVALID", "argument count or total field count");
    }
    profile.arguments.reserve(argument_count);
    for (std::size_t index = 0U; index < argument_count; ++index) {
        profile.arguments.push_back(percent_decode(
            field_value(lines.at(line++), "argument")));
    }
    profile.mtu = parse_size(field_value(lines.at(line++), "mtu"), "mtu");
    profile.capability_profile = parse_u32(
        field_value(lines.at(line++), "capability-profile"),
        "capability-profile");
    profile.max_frame_bytes = parse_size(
        field_value(lines.at(line++), "max-frame-bytes"), "max-frame-bytes");
    profile.max_queued_bytes = parse_size(
        field_value(lines.at(line++), "max-queued-bytes"), "max-queued-bytes");
    profile.max_outstanding_requests = parse_u32(
        field_value(lines.at(line++), "max-outstanding-requests"),
        "max-outstanding-requests");
    profile.max_evidence_events = parse_size(
        field_value(lines.at(line++), "max-evidence-events"),
        "max-evidence-events");
    profile.max_launch_attempts = parse_u32(
        field_value(lines.at(line++), "max-launch-attempts"),
        "max-launch-attempts");
    profile.startup_timeout = std::chrono::milliseconds(parse_u64(
        field_value(lines.at(line++), "startup-timeout-ms"),
        "startup-timeout-ms"));
    profile.request_timeout = std::chrono::milliseconds(parse_u64(
        field_value(lines.at(line++), "request-timeout-ms"),
        "request-timeout-ms"));
    profile.shutdown_timeout = std::chrono::milliseconds(parse_u64(
        field_value(lines.at(line++), "shutdown-timeout-ms"),
        "shutdown-timeout-ms"));
    profile.initial_restart_backoff = std::chrono::milliseconds(parse_u64(
        field_value(lines.at(line++), "initial-restart-backoff-ms"),
        "initial-restart-backoff-ms"));
    profile.maximum_restart_backoff = std::chrono::milliseconds(parse_u64(
        field_value(lines.at(line++), "maximum-restart-backoff-ms"),
        "maximum-restart-backoff-ms"));
    if (line != lines.size()) {
        fail("ADAPTER_PROFILE_INVALID", "trailing profile fields");
    }
    validate_operator_pinned_adapter_profile(profile);
    if (operator_pinned_adapter_profile_text(profile) != text) {
        fail("ADAPTER_PROFILE_NONCANONICAL", "canonical re-encoding differs");
    }
    return profile;
}

AdapterSha256 operator_pinned_adapter_profile_sha256(
    const OperatorPinnedAdapterProfile& profile) {
    const auto text = operator_pinned_adapter_profile_text(profile);
    return adapter_sha256(std::span<const std::uint8_t>(
        reinterpret_cast<const std::uint8_t*>(text.data()), text.size()));
}

void validate_operator_pinned_adapter_profile_transition(
    const OperatorPinnedAdapterProfile* current,
    const OperatorPinnedAdapterProfile& proposed) {
    validate_operator_pinned_adapter_profile(proposed);
    if (current == nullptr) {
        if (proposed.generation != 1U ||
            !is_zero_digest(proposed.previous_profile_sha256)) {
            fail("ADAPTER_PROFILE_TRANSITION_UNAUTHORIZED",
                 "creation requires generation one and zero predecessor");
        }
        return;
    }
    validate_operator_pinned_adapter_profile(*current);
    if (current->profile_id != proposed.profile_id ||
        current->generation == std::numeric_limits<std::uint64_t>::max() ||
        proposed.generation != current->generation + 1U ||
        proposed.previous_profile_sha256 !=
            operator_pinned_adapter_profile_sha256(*current)) {
        fail("ADAPTER_PROFILE_TRANSITION_UNAUTHORIZED",
             "profile identifier, generation, or predecessor digest");
    }
}

std::string adapter_transport_locator_text(
    const AdapterTransportLocator& locator) {
    if (!valid_profile_id(locator.profile_id) ||
        locator.profile_generation == 0U || locator.link_id == 0U ||
        locator.epoch == 0U) {
        fail("ADAPTER_LOCATOR_INVALID", "adapter locator fields");
    }
    return std::string(kLocatorPrefix) + "profile=" + locator.profile_id +
        "|generation=" + canonical_decimal(locator.profile_generation) +
        "|link=" + hex_u64_16(locator.link_id) +
        "|epoch=" + canonical_decimal(locator.epoch);
}

AdapterTransportLocator parse_adapter_transport_locator(
    const std::string_view text) {
    if (!text.starts_with(kLocatorPrefix) || text.size() > 512U) {
        fail("ADAPTER_LOCATOR_INVALID", "locator prefix or size");
    }
    std::array<std::string_view, 4U> fields{};
    std::size_t begin = kLocatorPrefix.size();
    for (std::size_t index = 0U; index < fields.size(); ++index) {
        const auto end = text.find('|', begin);
        if ((index + 1U < fields.size() && end == std::string_view::npos) ||
            (index + 1U == fields.size() && end != std::string_view::npos)) {
            fail("ADAPTER_LOCATOR_INVALID", "locator field count");
        }
        const auto actual_end = end == std::string_view::npos ? text.size() : end;
        fields[index] = text.substr(begin, actual_end - begin);
        begin = actual_end + 1U;
    }
    AdapterTransportLocator locator;
    locator.profile_id = std::string(field_value(fields[0U], "profile"));
    locator.profile_generation = parse_u64(
        field_value(fields[1U], "generation"), "generation");
    locator.link_id = parse_lower_hex_u64_16(
        field_value(fields[2U], "link"), "link");
    locator.epoch = parse_u32(field_value(fields[3U], "epoch"), "epoch");
    if (adapter_transport_locator_text(locator) != text) {
        fail("ADAPTER_LOCATOR_NONCANONICAL", "canonical re-encoding differs");
    }
    return locator;
}

const OperatorPinnedAdapterProfile& resolve_adapter_profile(
    const std::span<const OperatorPinnedAdapterProfile> profiles,
    const AdapterTransportLocator& locator) {
    static_cast<void>(adapter_transport_locator_text(locator));
    const OperatorPinnedAdapterProfile* found = nullptr;
    for (const auto& profile : profiles) {
        validate_operator_pinned_adapter_profile(profile);
        if (profile.profile_id == locator.profile_id &&
            profile.generation == locator.profile_generation) {
            if (found != nullptr) {
                fail("ADAPTER_PROFILE_AMBIGUOUS", locator.profile_id);
            }
            found = &profile;
        }
    }
    if (found == nullptr) {
        fail("ADAPTER_PROFILE_NOT_FOUND", locator.profile_id);
    }
    return *found;
}

std::chrono::milliseconds adapter_restart_backoff(
    const OperatorPinnedAdapterProfile& profile,
    const std::uint32_t attempt) {
    validate_operator_pinned_adapter_profile(profile);
    if (attempt == 0U || attempt > profile.max_launch_attempts) {
        fail("ADAPTER_RESTART_ATTEMPT_INVALID", "attempt outside launch budget");
    }
    auto delay = profile.initial_restart_backoff;
    for (std::uint32_t current = 1U; current < attempt; ++current) {
        if (delay >= profile.maximum_restart_backoff) {
            return profile.maximum_restart_backoff;
        }
        const auto remaining = profile.maximum_restart_backoff - delay;
        delay += std::min(delay, remaining);
    }
    return delay;
}

VerifiedAdapterExecutable::VerifiedAdapterExecutable(
    const int descriptor,
    std::filesystem::path configured_path,
    const AdapterSha256 digest,
    const std::uint64_t source_device,
    const std::uint64_t source_inode,
    const std::uint64_t size) noexcept
    : descriptor_(descriptor),
      configured_path_(std::move(configured_path)),
      digest_(digest),
      source_device_(source_device),
      source_inode_(source_inode),
      size_(size) {}

VerifiedAdapterExecutable::VerifiedAdapterExecutable(
    VerifiedAdapterExecutable&& other) noexcept
    : descriptor_(std::exchange(other.descriptor_, -1)),
      configured_path_(std::move(other.configured_path_)),
      digest_(other.digest_),
      source_device_(other.source_device_),
      source_inode_(other.source_inode_),
      size_(other.size_) {}

VerifiedAdapterExecutable& VerifiedAdapterExecutable::operator=(
    VerifiedAdapterExecutable&& other) noexcept {
    if (this != &other) {
        if (descriptor_ >= 0) {
            static_cast<void>(::close(descriptor_));
        }
        descriptor_ = std::exchange(other.descriptor_, -1);
        configured_path_ = std::move(other.configured_path_);
        digest_ = other.digest_;
        source_device_ = other.source_device_;
        source_inode_ = other.source_inode_;
        size_ = other.size_;
    }
    return *this;
}

VerifiedAdapterExecutable::~VerifiedAdapterExecutable() {
    if (descriptor_ >= 0) {
        static_cast<void>(::close(descriptor_));
    }
}

const std::filesystem::path& VerifiedAdapterExecutable::configured_path() const noexcept {
    return configured_path_;
}

const AdapterSha256& VerifiedAdapterExecutable::sha256() const noexcept {
    return digest_;
}

std::uint64_t VerifiedAdapterExecutable::source_device() const noexcept {
    return source_device_;
}

std::uint64_t VerifiedAdapterExecutable::source_inode() const noexcept {
    return source_inode_;
}

std::uint64_t VerifiedAdapterExecutable::size() const noexcept { return size_; }

int VerifiedAdapterExecutable::duplicate_for_exec(
    const int minimum_descriptor) const {
    if (descriptor_ < 0 || minimum_descriptor < 0) {
        fail("ADAPTER_EXECUTABLE_INVALID", "sealed image descriptor");
    }
    const int duplicate = ::fcntl(descriptor_, F_DUPFD_CLOEXEC, minimum_descriptor);
    if (duplicate < 0) {
        fail("ADAPTER_EXECUTABLE_DUP_FAILED", "F_DUPFD_CLOEXEC");
    }
    return duplicate;
}

VerifiedAdapterExecutable open_verified_adapter_executable(
    const OperatorPinnedAdapterProfile& profile) {
    validate_operator_pinned_adapter_profile(profile);
    auto source = open_without_symlinks(profile.executable);
    struct stat status {};
    if (::fstat(source.get(), &status) != 0) {
        fail("ADAPTER_EXECUTABLE_STAT_FAILED", "fstat");
    }
    if (!S_ISREG(status.st_mode) || status.st_size <= 0 ||
        static_cast<std::uint64_t>(status.st_size) > kMaximumExecutableBytes ||
        (status.st_mode & (S_IWGRP | S_IWOTH | S_ISUID | S_ISGID)) != 0 ||
        (status.st_uid != ::geteuid() && status.st_uid != 0U) ||
        !effective_user_can_execute(status)) {
        fail("ADAPTER_EXECUTABLE_UNSAFE",
             "regular ownership, mode, size, or execute policy");
    }

    auto sealed = create_sealed_memfd();
    EVP_MD_CTX* raw = EVP_MD_CTX_new();
    if (raw == nullptr) {
        fail("ADAPTER_SHA256_FAILED", "EVP_MD_CTX_new");
    }
    const std::unique_ptr<EVP_MD_CTX, decltype(&EVP_MD_CTX_free)> context(
        raw, EVP_MD_CTX_free);
    if (EVP_DigestInit_ex(context.get(), EVP_sha256(), nullptr) != 1) {
        fail("ADAPTER_SHA256_FAILED", "EVP_DigestInit_ex");
    }
    std::array<std::uint8_t, kCopyBufferBytes> buffer{};
    std::uint64_t offset = 0U;
    std::array<std::uint8_t, 4U> magic{};
    std::size_t magic_bytes = 0U;
    while (offset < static_cast<std::uint64_t>(status.st_size)) {
        const auto remaining = static_cast<std::uint64_t>(status.st_size) - offset;
        const auto requested = static_cast<std::size_t>(
            std::min<std::uint64_t>(remaining, buffer.size()));
        ssize_t count = -1;
        do {
            count = ::pread(source.get(), buffer.data(), requested,
                            static_cast<off_t>(offset));
        } while (count < 0 && errno == EINTR);
        if (count <= 0 || static_cast<std::size_t>(count) > requested) {
            fail("ADAPTER_EXECUTABLE_READ_FAILED", "short or failed source read");
        }
        const auto amount = static_cast<std::size_t>(count);
        if (magic_bytes < magic.size()) {
            const auto copied = std::min(magic.size() - magic_bytes, amount);
            std::copy_n(buffer.begin(), copied, magic.begin() +
                static_cast<std::ptrdiff_t>(magic_bytes));
            magic_bytes += copied;
        }
        if (EVP_DigestUpdate(context.get(), buffer.data(), amount) != 1) {
            fail("ADAPTER_SHA256_FAILED", "EVP_DigestUpdate");
        }
        write_all_at(sealed.get(), std::span<const std::uint8_t>(buffer).first(amount),
                     static_cast<off_t>(offset));
        offset += amount;
    }
    if (offset != static_cast<std::uint64_t>(status.st_size)) {
        fail("ADAPTER_EXECUTABLE_READ_FAILED", "source size changed");
    }
    struct stat final_source_status {};
    struct stat sealed_status {};
    if (::fstat(source.get(), &final_source_status) != 0 ||
        ::fstat(sealed.get(), &sealed_status) != 0 ||
        final_source_status.st_dev != status.st_dev ||
        final_source_status.st_ino != status.st_ino ||
        final_source_status.st_size != status.st_size ||
        sealed_status.st_size != status.st_size) {
        fail("ADAPTER_EXECUTABLE_READ_FAILED",
             "source identity or sealed image size changed");
    }
    AdapterSha256 digest{};
    unsigned int digest_size = 0U;
    if (EVP_DigestFinal_ex(context.get(), digest.data(), &digest_size) != 1 ||
        digest_size != digest.size()) {
        fail("ADAPTER_SHA256_FAILED", "EVP_DigestFinal_ex");
    }
    if (CRYPTO_memcmp(
            digest.data(), profile.executable_sha256.data(), digest.size()) != 0) {
        fail("ADAPTER_EXECUTABLE_DIGEST_MISMATCH", profile.executable.string());
    }
    const std::array<std::uint8_t, 4U> elf_magic{0x7fU, 'E', 'L', 'F'};
    if (magic_bytes != magic.size() || magic != elf_magic) {
        fail("ADAPTER_EXECUTABLE_FORMAT_INVALID", "only pinned ELF images are accepted");
    }
    if (::fchmod(sealed.get(), S_IRUSR | S_IXUSR) != 0) {
        fail("ADAPTER_EXECUTABLE_SEAL_FAILED", "fchmod sealed image");
    }
    const int required_seals = F_SEAL_SEAL | F_SEAL_SHRINK | F_SEAL_GROW | F_SEAL_WRITE;
    if (::fcntl(sealed.get(), F_ADD_SEALS, required_seals) != 0) {
        fail("ADAPTER_EXECUTABLE_SEAL_FAILED", "F_ADD_SEALS");
    }
    const int actual_seals = ::fcntl(sealed.get(), F_GET_SEALS);
    if (actual_seals < 0 || (actual_seals & required_seals) != required_seals) {
        fail("ADAPTER_EXECUTABLE_SEAL_FAILED", "F_GET_SEALS");
    }
    return VerifiedAdapterExecutable(
        sealed.release(),
        profile.executable,
        digest,
        static_cast<std::uint64_t>(status.st_dev),
        static_cast<std::uint64_t>(status.st_ino),
        static_cast<std::uint64_t>(status.st_size));
}

int execute_verified_adapter_image(
    const int executable_descriptor,
    char* const arguments[],
    char* const environment[]) noexcept {
    if (executable_descriptor < 0 || arguments == nullptr ||
        arguments[0] == nullptr || environment == nullptr) {
        errno = EINVAL;
        return -1;
    }
#if defined(SYS_execveat)
    const int result = static_cast<int>(::syscall(
        SYS_execveat,
        executable_descriptor,
        "",
        arguments,
        environment,
        AT_EMPTY_PATH));
    if (result < 0 && errno == ENOSYS) {
        return ::fexecve(executable_descriptor, arguments, environment);
    }
    return result;
#else
    return ::fexecve(executable_descriptor, arguments, environment);
#endif
}

}  // namespace natrav_overlay
