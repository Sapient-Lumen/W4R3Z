#pragma once
#include "common.hpp"
#include <cstdint>
#include <string>
#include <vector>
#include <cstddef>

namespace natrav_overlay {
// An exact observational request. Neither selection nor reply is a capability,
// an action receipt, or an independent proof of remote execution.
struct ActionResultQuery final {
    datacube::Digest32 operation_id;
    datacube::Digest32 request_operation_id;
    std::string provider;
    std::string scope;
    std::uint32_t maximum_response_bytes{16'384U};
};
void validate_action_result_query(const ActionResultQuery& request);
[[nodiscard]] datacube::Octets encode_action_result_query(const ActionResultQuery& request);
[[nodiscard]] ActionResultQuery decode_action_result_query(datacube::OctetView bytes);
struct ActionResultDiscovery final {
    datacube::Digest32 request_operation_id;
    std::string provider;
    std::string scope;
    std::uint32_t limit{8U};
    std::uint32_t maximum_response_bytes{32'768U};
    std::string cursor;
};
void validate_action_result_discovery(const ActionResultDiscovery& request);
[[nodiscard]] datacube::Octets encode_action_result_discovery(const ActionResultDiscovery& request);
[[nodiscard]] ActionResultDiscovery decode_action_result_discovery(datacube::OctetView bytes);
// Derived metadata, never a claim that the candidate payload is valid. The root
// commits immutable outer identities in stored admission order; rebuilt on replay.
struct ReceivedActionResultCandidates final {
    std::vector<std::size_t> records;
    datacube::Digest32 root{};
};
} // namespace natrav_overlay
