#include "outbox_query.hpp"
#include "journal.hpp"
#include <algorithm>
#include <array>
#include <limits>
#include <memory>
#include <openssl/core_names.h>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/params.h>
#include <openssl/rand.h>

namespace natrav_overlay {
namespace {
using Digest=datacube::Digest32;
constexpr std::size_t kCursorBytes=128U;
constexpr std::uint64_t kLifetime=300'000U;
void require(bool value,std::string_view code,std::string_view message) {
    if(!value)app_fail(code,message);
}
std::string hex(const Digest& value) {return json_string(datacube::hex_lower(value));}
std::string maybe_hex(const std::optional<Digest>& value) {return value?hex(*value):"null";}
std::string time_json(const std::optional<std::uint64_t>& value) {return value?std::to_string(*value):"null";}
void text16(datacube::Octets& out,std::string_view value) {
    datacube::append_be16(out,static_cast<std::uint16_t>(value.size()));datacube::append_text(out,value);
}
std::string text16(datacube::Reader& reader,std::size_t maximum) {
    const auto size=reader.read_be16("text size");
    require(size<=maximum,"OUTBOX_QUERY_INVALID","text exceeds bound");
    return datacube::octets_text(reader.read_exact(size,"text"),"text",true);
}
Digest digest(datacube::Reader& reader) {
    Digest value{};const auto bytes=reader.read_exact(32U,"digest");std::copy(bytes.begin(),bytes.end(),value.octets.begin());return value;
}
std::uint64_t monotonic_ms() {
    const auto t=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
    require(t>=0,"OUTBOX_QUERY_CLOCK_FAILED","negative monotonic clock");return static_cast<std::uint64_t>(t);
}
void checked(int value) {require(value==1,"OUTBOX_QUERY_CRYPTO_FAILED","cursor cryptography failed");}
struct Secret final {
    std::array<unsigned char,32U> bytes{};
    Secret(){checked(RAND_priv_bytes(bytes.data(),static_cast<int>(bytes.size())));}
    ~Secret(){OPENSSL_cleanse(bytes.data(),bytes.size());}
    Secret(const Secret&)=delete;Secret& operator=(const Secret&)=delete;
};
Digest mac(datacube::OctetView bytes) {
    static const Secret secret;
    std::unique_ptr<EVP_MAC,decltype(&EVP_MAC_free)> algorithm(EVP_MAC_fetch(nullptr,"HMAC",nullptr),EVP_MAC_free);
    require(static_cast<bool>(algorithm),"OUTBOX_QUERY_CRYPTO_FAILED","HMAC unavailable");
    std::unique_ptr<EVP_MAC_CTX,decltype(&EVP_MAC_CTX_free)> ctx(EVP_MAC_CTX_new(algorithm.get()),EVP_MAC_CTX_free);
    require(static_cast<bool>(ctx),"OUTBOX_QUERY_CRYPTO_FAILED","HMAC context unavailable");
    char sha[]="SHA256";
    OSSL_PARAM parameters[]={OSSL_PARAM_construct_utf8_string(OSSL_MAC_PARAM_DIGEST,sha,0U),OSSL_PARAM_construct_end()};
    checked(EVP_MAC_init(ctx.get(),secret.bytes.data(),secret.bytes.size(),parameters));
    constexpr std::string_view domain="NATRAV_OVERLAY_OUTBOX_CURSOR_V1";
    checked(EVP_MAC_update(ctx.get(),reinterpret_cast<const unsigned char*>(domain.data()),domain.size()));
    checked(EVP_MAC_update(ctx.get(),bytes.data(),bytes.size()));
    Digest tag{};std::size_t length=0U;checked(EVP_MAC_final(ctx.get(),tag.octets.data(),&length,32U));
    require(length==32U,"OUTBOX_QUERY_CRYPTO_FAILED","HMAC size mismatch");return tag;
}
struct Position final {std::uint64_t version{0U};std::uint64_t after{0U};std::uint64_t expires{0U};};
std::string seal(const OutboxQueryContext& context,const Digest& specification,const Position& position) {
    datacube::Octets bytes;datacube::append_text(bytes,"OBC1");datacube::append_be32(bytes,context.uid);
    datacube::append_octets(bytes,context.configuration_digest.octets);datacube::append_octets(bytes,specification.octets);
    datacube::append_be64(bytes,position.version);datacube::append_be64(bytes,position.after);datacube::append_be64(bytes,position.expires);
    const auto tag=mac(bytes);datacube::append_octets(bytes,tag.octets);return hex_bytes(bytes);
}
Position open(const std::string& token,const OutboxQueryContext& context,const Digest& specification) {
    require(token.size()==kCursorBytes*2U,"OUTBOX_CURSOR_INVALID","invalid cursor size");
    auto nibble=[](char c)->std::uint8_t {
        if(c>='0'&&c<='9')return static_cast<std::uint8_t>(c-'0');
        if(c>='a'&&c<='f')return static_cast<std::uint8_t>(c-'a'+10);
        app_fail("OUTBOX_CURSOR_INVALID","cursor must be lowercase hexadecimal");
    };
    datacube::Octets bytes;bytes.reserve(kCursorBytes);
    for(std::size_t i=0U;i<token.size();i+=2U)bytes.push_back(static_cast<std::uint8_t>(nibble(token[i])*16U+nibble(token[i+1U])));
    const auto body=datacube::OctetView(bytes).first(kCursorBytes-32U);const auto tag=mac(body);
    require(CRYPTO_memcmp(tag.octets.data(),bytes.data()+body.size(),32U)==0,"OUTBOX_CURSOR_INVALID","authentication failed or issuing process restarted");
    datacube::Reader reader(body,"outbox cursor");
    require(datacube::octets_text(reader.read_exact(4U,"magic"),"magic",true)=="OBC1","OUTBOX_CURSOR_INVALID","unknown cursor version");
    const auto uid=reader.read_be32("UID");const auto config=digest(reader);const auto spec=digest(reader);
    Position result{reader.read_be64("revision"),reader.read_be64("position"),reader.read_be64("expiry")};reader.require_eof("cursor");
    require(uid==context.uid&&config==context.configuration_digest&&spec==specification,"OUTBOX_CURSOR_CONTEXT_MISMATCH","principal, node, query or configuration changed");
    require(monotonic_ms()<result.expires,"OUTBOX_CURSOR_EXPIRED","cursor expired; restart inspection");
    return result;
}
std::string transition_json(const OutboundTransition& t,std::size_t position) {
    const auto reason=datacube::sha256(datacube::text_octets(t.reason));
    std::string row="{\"ordinal\":"+std::to_string(position+1U)+",\"kind\":"+json_string(outbound_transition_kind_name(t.kind))+
        ",\"unix_ms\":"+std::to_string(t.unix_ms)+",\"actor\":"+json_string(t.actor)+
        ",\"reason_bytes\":"+std::to_string(t.reason.size())+",\"reason_sha256\":"+hex(reason)+
        ",\"from_generation\":"+json_string(t.from_generation)+",\"from_spki_sha256\":"+hex(t.from_spki_sha256);
    if(t.kind==OutboundTransitionKind::rejected){
        row+=",\"error_code\":"+json_string(t.actor)+",\"rejection_policy_digest\":"+maybe_hex(t.to_spki_sha256);
    }else{
        row+=",\"to_generation\":"+(t.to_generation?json_string(*t.to_generation):"null")+",\"to_spki_sha256\":"+maybe_hex(t.to_spki_sha256);
    }
    return row+"}";
}
std::string row_json(const StoredOutbound& entry,const std::string& outcome,std::uint64_t revision,
    std::size_t history_after,std::uint32_t history_limit,const std::string& association,std::size_t& history_visited) {
    const auto& r=entry.record;
    std::string row="{\"operation_id\":"+hex(r.operation_id)+",\"queue_sequence\":"+std::to_string(entry.queue_sequence)+
        ",\"operation_revision\":"+std::to_string(revision)+",\"issuer\":"+json_string(r.issuer)+",\"recipient\":"+json_string(r.recipient)+
        ",\"scope\":"+json_string(r.scope)+",\"corrects\":"+maybe_hex(r.corrects)+",\"record_digest\":"+hex(entry.record_digest)+
        ",\"payload_bytes\":"+std::to_string(r.payload.size())+",\"status\":"+json_string(outcome)+
        ",\"reserved_records\":"+(outcome=="PENDING"?"1":"0")+",\"reserved_payload_bytes\":"+std::to_string(outcome=="PENDING"?r.payload.size():0U);
    if(entry.receipt){const auto& receipt=*entry.receipt;
        row+=",\"receipt\":{\"recipient\":"+json_string(receipt.recipient)+",\"recorder\":"+json_string(receipt.recorder)+
            ",\"sequence\":"+std::to_string(receipt.sequence)+",\"disposition\":"+json_string(receipt.disposition==ReceiptDisposition::committed?"COMMITTED":"DUPLICATE")+
            ",\"operation_id\":"+hex(receipt.operation_id)+",\"record_digest\":"+hex(receipt.record_digest)+"}";
    }else row+=",\"receipt\":null";
    const std::size_t total=entry.delivery?entry.delivery->transitions.size():0U;
    require(history_after<=total,"OUTBOX_CURSOR_INVALID","history continuation is beyond retained history");
    if(entry.delivery){const auto& d=*entry.delivery;const auto& p=d.policy;
        row+=",\"delivery\":{\"attempts\":"+std::to_string(d.attempts)+",\"last_attempt_unix_ms\":"+time_json(d.last_attempt_unix_ms)+
            ",\"next_attempt_unix_ms\":"+std::to_string(d.next_attempt_unix_ms)+",\"last_error_code\":"+json_string(d.last_error_code)+
            ",\"expired_unix_ms\":"+time_json(d.expired_unix_ms)+",\"expiry_reason\":"+json_string(d.expiry_reason)+
            ",\"cancelled_unix_ms\":"+time_json(d.cancelled_unix_ms)+",\"policy\":{\"created_unix_ms\":"+std::to_string(p.created_unix_ms)+
            ",\"expires_unix_ms\":"+std::to_string(p.expires_unix_ms)+",\"maximum_attempts\":"+std::to_string(p.maximum_attempts)+
            ",\"initial_backoff_ms\":"+std::to_string(p.initial_backoff_ms)+",\"maximum_backoff_ms\":"+std::to_string(p.maximum_backoff_ms)+
            ",\"peer_generation\":"+(p.peer_generation?json_string(*p.peer_generation):"null")+",\"peer_spki_sha256\":"+maybe_hex(p.peer_spki_sha256)+"}}";
    }else row+=",\"delivery\":null";
    row+=",\"active_rejection\":";
    if(outcome=="REJECTED"&&entry.delivery&&!entry.delivery->transitions.empty()){
        ++history_visited;row+=transition_json(entry.delivery->transitions.back(),total-1U);
    }else row+="null";
    const auto end=history_after+std::min<std::size_t>(history_limit,total-history_after);
    row+=",\"history_total\":"+std::to_string(total)+",\"history_after\":"+std::to_string(history_after)+
        ",\"history_next_after\":"+std::to_string(end)+",\"history_more\":"+(end<total?"true":"false")+",\"history\":[";
    for(std::size_t i=history_after;i<end;++i){if(i!=history_after)row+=",";row+=transition_json(entry.delivery->transitions[i],i);++history_visited;}
    return row+"],\"association\":"+association+"}";
}
} // namespace

void OutboxInspectionIndex::touch(std::size_t index,const std::string& recipient,const std::string& outcome) {
    require(clock_!=std::numeric_limits<std::uint64_t>::max(),"OUTBOX_INDEX_EXHAUSTED","index version exhausted; restart owner");++clock_;
    require(index<=states_.size(),"JOURNAL_CORRUPT","outbox inspection index gap");
    if(index==states_.size()){states_.emplace_back();revisions_.push_back(0U);}
    const auto old=states_[index];
    if(!old.empty()&&old!=outcome){for(const auto& peer: {std::string{},recipient}){
        auto& b=buckets_[{peer,old}];b.records.erase(index);b.revision=clock_;
    }}
    for(const auto& peer: {std::string{},recipient})for(const auto& state: {std::string{},outcome}){
        auto& b=buckets_[{peer,state}];b.records.insert(index);b.revision=clock_;
    }
    states_[index]=outcome;revisions_[index]=clock_;
}
const OutboxInspectionIndex::Bucket& OutboxInspectionIndex::select(const std::string& recipient,const std::string& outcome) const {
    static const Bucket empty;const auto found=buckets_.find({recipient,outcome});return found==buckets_.end()?empty:found->second;
}
std::uint64_t OutboxInspectionIndex::revision(std::size_t index) const {return revisions_.at(index);}
const std::string& OutboxInspectionIndex::state(std::size_t index) const {return states_.at(index);}

void validate_outbox_query(const OutboxQuery& q) {
    require(q.recipient.empty()||valid_node_id(q.recipient),"OUTBOX_QUERY_INVALID","recipient must be an exact node ID");
    require(q.state.empty()||q.state=="PENDING"||q.state=="ACKED"||q.state=="REJECTED"||q.state=="CANCELLED"||q.state=="EXPIRED", "OUTBOX_QUERY_INVALID","unknown durable outcome");
    require(!q.operation_id||!digest_is_zero(*q.operation_id),"OUTBOX_QUERY_INVALID","operation must be nonzero");
    require(q.maximum_records>=1U&&q.maximum_records<=64U&&q.maximum_response_bytes>=4096U&&q.maximum_response_bytes<=60000U&&q.history_limit<=16U,
        "OUTBOX_QUERY_INVALID","limit 1..64, max-bytes 4096..60000, history-limit 0..16 required");
    require(q.cursor.empty()||q.cursor.size()==kCursorBytes*2U,"OUTBOX_CURSOR_INVALID","invalid cursor size");
}
datacube::Octets encode_outbox_query(const OutboxQuery& q) {
    validate_outbox_query(q);datacube::Octets bytes;datacube::append_text(bytes,"OBQ1");
    text16(bytes,q.recipient);text16(bytes,q.state);datacube::append_u8(bytes,q.operation_id?1U:0U);
    if(q.operation_id)datacube::append_octets(bytes,q.operation_id->octets);
    datacube::append_be32(bytes,q.maximum_records);datacube::append_be32(bytes,q.maximum_response_bytes);datacube::append_be32(bytes,q.history_limit);text16(bytes,q.cursor);return bytes;
}
OutboxQuery decode_outbox_query(datacube::OctetView bytes) {
    datacube::Reader reader(bytes,"outbox query");
    require(datacube::octets_text(reader.read_exact(4U,"magic"),"magic",true)=="OBQ1","OUTBOX_QUERY_INVALID","unknown query version");
    OutboxQuery q;q.recipient=text16(reader,64U);q.state=text16(reader,16U);const auto present=reader.read_u8("operation present");
    require(present<=1U,"OUTBOX_QUERY_INVALID","invalid operation marker");if(present)q.operation_id=digest(reader);
    q.maximum_records=reader.read_be32("rows");q.maximum_response_bytes=reader.read_be32("bytes");q.history_limit=reader.read_be32("history");
    q.cursor=text16(reader,kCursorBytes*2U);reader.require_eof("query");validate_outbox_query(q);return q;
}
void NodeState::index_outbound(std::size_t index) {
    const auto& entry = outbound_.at(index);
    const auto outcome = std::string(outbound_status_name(entry));
    const auto change = pending_capacity_.update(index, entry.record.recipient,
        static_cast<std::uint64_t>(entry.record.payload.size()), outcome == "PENDING");
    if (active_submission_work) {
        ++active_submission_work->capacity_entries_touched;
        if (change == PendingCapacityChange::acquired) ++active_submission_work->capacity_acquires;
        if (change == PendingCapacityChange::released) ++active_submission_work->capacity_releases;
    }
    outbox_inspection_index_.touch(index, entry.record.recipient, outcome);
    if (outcome != "PENDING") { delivery_index_.touch(index, std::nullopt); return; }
    DeliveryIndexEntry metadata;
    metadata.peer = entry.record.recipient;
    if (entry.delivery) {
        const auto& delivery = *entry.delivery;
        metadata.has_policy = true;
        metadata.binding = {delivery.policy.peer_generation.value_or(""),
            delivery.policy.peer_spki_sha256 ? operation_id_text(*delivery.policy.peer_spki_sha256) : ""};
        metadata.expires = delivery.policy.expires_unix_ms;
        metadata.ready = delivery.next_attempt_unix_ms;
        metadata.attempts_exhausted = delivery.attempts >= delivery.policy.maximum_attempts;
    }
    delivery_index_.touch(index, std::move(metadata));
}
void NodeState::index_outbound_associations(const PublicationChannel& channel) {
    for(const auto& p:channel.publications){const auto key=operation_id_text(p.operation_id);if(outbox_associations_.contains(key))continue;
        outbox_associations_.emplace(key,"{\"kind\":\"PUBLICATION_CHANNEL\",\"channel\":"+json_string(channel.name)+
            ",\"owner_uid\":"+std::to_string(channel.uid)+",\"instance\":"+hex(channel.instance)+",\"sequence\":"+std::to_string(p.sequence)+
            ",\"epoch\":"+std::to_string(p.epoch)+",\"projection_instance\":"+hex(channel.projection_instance)+
            ",\"result_digest\":"+hex(p.result_digest)+",\"source_commitment\":"+hex(p.source_commitment)+
            ",\"configuration_event\":"+std::to_string(p.configuration_event)+"}");
    }
}
void NodeState::index_outbound_associations(const SourceSubscription& subscription) {
    for(std::size_t i=0U;i<subscription.deliveries.size();++i){const auto& d=subscription.deliveries[i];const auto key=operation_id_text(d.operation);
        if(outbox_associations_.contains(key))continue;
        outbox_associations_.emplace(key,"{\"kind\":\"SOURCE_SUBSCRIPTION\",\"grant\":"+json_string(subscription.grant.id)+
            ",\"manager_uid\":"+std::to_string(subscription.grant.uid)+",\"author_uid\":"+std::to_string(subscription.grant.author_uid)+
            ",\"instance\":"+hex(subscription.instance)+",\"delivery_ordinal\":"+std::to_string(i+1U)+
            ",\"source_operation\":"+hex(d.source_operation)+",\"lease_generation\":"+json_string(subscription.grant.lease_generation)+
            ",\"lease_started_unix_ms\":"+std::to_string(subscription.lease_started_unix_ms)+",\"lease_expires_unix_ms\":"+std::to_string(subscription.lease_expires_unix_ms)+
            ",\"configuration_event\":"+std::to_string(d.configuration_event)+"}");
    }
}
std::string NodeState::query_outbox(const OutboxQuery& query,const OutboxQueryContext& context) const {
    validate_outbox_query(query);
    auto spec_query=query;spec_query.cursor.clear();auto bytes=encode_outbox_query(spec_query);text16(bytes,node_id_);const auto spec=datacube::sha256(bytes);
    std::optional<Position> old;if(!query.cursor.empty())old=open(query.cursor,context,spec);
    std::lock_guard lock(mutex_);
    require(!poisoned_,"STATE_POISONED","writer is poisoned; restart required");
    auto check_deadline=[&](){require(std::chrono::steady_clock::now()<context.deadline,"OUTBOX_QUERY_DEADLINE","inspection deadline elapsed; restart query");};
    check_deadline();
    const auto& selection=outbox_inspection_index_.select(query.recipient,query.state);
    std::optional<std::size_t> exact;
    if(query.operation_id){const auto f=outbound_index_.find(operation_id_text(*query.operation_id));
        if(f!=outbound_index_.end()&&(query.recipient.empty()||outbound_[f->second].record.recipient==query.recipient)&&
            (query.state.empty()||outbox_inspection_index_.state(f->second)==query.state))exact=f->second;
    }
    if(exact)require(outbox_inspection_index_.revision(*exact)<=std::numeric_limits<std::uint64_t>::max()/8U,"OUTBOX_INDEX_EXHAUSTED","restart inspection epoch");
    const auto version=query.operation_id?(exact?outbox_inspection_index_.revision(*exact)*8U+outbox_restrictions_locked(outbound_[*exact].record.operation_id):0U):selection.revision;
    require(!old||old->version==version,"OUTBOX_CURSOR_STALE","selected outbox metadata changed; restart inspection");
    const std::uint64_t total=query.operation_id?(exact?1U:0U):static_cast<std::uint64_t>(selection.records.size());
    Position position{version,old?old->after:0U,old?old->expires:monotonic_ms()+kLifetime};
    std::string prefix="{\"format\":\"NATRAV_OVERLAY_OUTBOX_QUERY_V1\",\"node\":"+json_string(node_id_)+
        ",\"configuration_digest\":"+hex(context.configuration_digest)+",\"query_digest\":"+hex(spec)+
        ",\"selection_revision\":"+std::to_string(version)+",\"selected_total\":"+std::to_string(total)+
        ",\"order\":\"QUEUE_SEQUENCE\",\"exact\":"+(query.operation_id?"true":"false")+
        ",\"maximum_bytes\":"+std::to_string(query.maximum_response_bytes)+",\"history_limit\":"+std::to_string(query.history_limit);
    std::vector<std::string> rows;std::size_t row_bytes=0U,visited=0U,histories=0U;bool more=false;
    // Covers footer, fixed-size cursor and actual bounded local-principal annotation.
    constexpr std::size_t reserve=1536U;
    auto add=[&](std::size_t index,std::size_t after)->bool {
        check_deadline();++visited;const auto& entry=outbound_[index];const auto link=outbox_associations_.find(operation_id_text(entry.record.operation_id));
        auto row=row_json(entry,outbox_inspection_index_.state(index),outbox_inspection_index_.revision(index),after,query.history_limit,
            link==outbox_associations_.end()?"null":link->second,histories);
        if(query.operation_id) { row.pop_back();row+=",\"condition\":"+outbox_condition_json_locked(entry)+"}"; }
        if(prefix.size()+row_bytes+row.size()+rows.size()+reserve>query.maximum_response_bytes){
            require(!rows.empty(),"OUTBOX_QUERY_PAGE_TOO_SMALL","first complete row cannot fit; raise max-bytes or lower history-limit");return false;
        }
        row_bytes+=row.size();rows.push_back(std::move(row));return true;
    };
    if(query.operation_id){
        if(exact){const auto& entry=outbound_[*exact];const auto count=entry.delivery?entry.delivery->transitions.size():0U;
            require(position.after<=count,"OUTBOX_CURSOR_INVALID","history position invalid");
            static_cast<void>(add(*exact,static_cast<std::size_t>(position.after)));
            position.after+=std::min<std::uint64_t>(query.history_limit,static_cast<std::uint64_t>(count)-position.after);
            more=query.history_limit!=0U&&position.after<count;
        }
    }else{
        require(position.after<=outbound_.size(),"OUTBOX_CURSOR_INVALID","queue continuation invalid");
        // Queue sequences are one-based; index upper_bound(after-1) is the next record.
        auto it=position.after==0U?selection.records.begin():selection.records.upper_bound(static_cast<std::size_t>(position.after-1U));
        while(it!=selection.records.end()&&rows.size()<query.maximum_records){
            const auto index=*it;if(!add(index,0U))break;position.after=outbound_[index].queue_sequence;++it;
        }
        more=it!=selection.records.end();
    }
    check_deadline();
    auto result=prefix+",\"returned\":"+std::to_string(rows.size())+",\"more\":"+(more?"true":"false")+
        ",\"next_cursor\":"+(more?json_string(seal(context,spec,position)):"null")+
        ",\"work\":{\"records_visited\":"+std::to_string(visited)+",\"transition_records_visited\":"+std::to_string(histories)+
        ",\"association_lookups\":"+std::to_string(visited)+",\"payload_bytes_read\":0},\"records\":[";
    for(std::size_t i=0U;i<rows.size();++i){if(i)result+=",";result+=rows[i];}
    result+="]}";
    require(result.size()+512U<=query.maximum_response_bytes,"OUTBOX_QUERY_RESPONSE_LIMIT","annotated response budget exceeded");return result;
}
} // namespace natrav_overlay
