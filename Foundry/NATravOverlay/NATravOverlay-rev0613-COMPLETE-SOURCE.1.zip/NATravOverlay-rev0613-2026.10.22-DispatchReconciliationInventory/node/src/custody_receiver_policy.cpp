#include "custody_receiver_policy.hpp"

#include "adapter_configuration.hpp"

#include <algorithm>
#include <limits>
#include <set>
#include <tuple>

namespace natrav_overlay {
namespace {

constexpr std::size_t kActivationTextLimit = 1'024U;

void require(const bool condition, const std::string_view code,
    const std::string_view detail) {
    if (!condition) { app_fail(code, detail); }
}

void validate_activation(const CustodyReceiverActivation& activation) {
    require(valid_generation_id(activation.id),
        "CONFIG_CUSTODY_RECEIVER_INVALID",
        "receiver activation id is invalid");
    require(activation.generation > 0U &&
            activation.generation <=
                kCustodyReceiverActivationPerIdLimit,
        "CONFIG_CUSTODY_RECEIVER_GENERATION",
        "receiver activation generation is outside the retained bound");
    require(activation.state == CustodyReceiverActivationState::active ||
            activation.state == CustodyReceiverActivationState::retired ||
            activation.state == CustodyReceiverActivationState::revoked,
        "CONFIG_CUSTODY_RECEIVER_STATE",
        "unknown receiver activation lifecycle state");
    require(valid_generation_id(activation.session_rule_id) &&
            activation.session_rule_generation > 0U &&
            activation.session_rule_generation <=
                kCustodySessionRulePerIdLimit &&
            !digest_is_zero(activation.session_rule_commitment),
        "CONFIG_CUSTODY_RECEIVER_RULE",
        "receiver activation requires one exact nonzero V22 rule reference");
    require(activation.maximum_inflight_offers > 0U &&
            activation.maximum_inflight_offers <=
                kCustodyReceiverMaximumInflightOffers,
        "CONFIG_CUSTODY_RECEIVER_LIMIT",
        "receiver in-flight bound is outside the finite envelope");
    require(activation.activation_expires_unix_ms > 0U,
        "CONFIG_CUSTODY_RECEIVER_LIMIT",
        "receiver activation expiry must be positive");
}

std::string field_value(const std::string& text, std::size_t& offset,
    const std::string_view prefix) {
    const auto end = text.find('\n', offset);
    require(end != std::string::npos,
        "CONFIG_CUSTODY_RECEIVER_NONCANONICAL",
        "complete canonical line required");
    const auto line = std::string_view(text).substr(offset, end - offset);
    require(line.starts_with(prefix),
        "CONFIG_CUSTODY_RECEIVER_NONCANONICAL",
        "canonical receiver-activation field order required");
    offset = end + 1U;
    return std::string(line.substr(prefix.size()));
}

CustodyReceiverActivationState parse_state(const std::string_view value) {
    if (value == "ACTIVE") {
        return CustodyReceiverActivationState::active;
    }
    if (value == "RETIRED") {
        return CustodyReceiverActivationState::retired;
    }
    if (value == "REVOKED") {
        return CustodyReceiverActivationState::revoked;
    }
    app_fail("CONFIG_CUSTODY_RECEIVER_STATE",
        "receiver lifecycle must be ACTIVE, RETIRED or REVOKED");
}

const CustodyReceiverActivation* find_exact(
    const CustodyReceiverPolicy& policy,
    const std::string_view id,
    const std::uint64_t generation) noexcept {
    const auto found = std::find_if(policy.begin(), policy.end(),
        [&](const CustodyReceiverActivation& activation) {
            return activation.id == id &&
                activation.generation == generation;
        });
    return found == policy.end() ? nullptr : &*found;
}

} // namespace

std::string_view custody_receiver_activation_state_name(
    const CustodyReceiverActivationState state) {
    switch (state) {
        case CustodyReceiverActivationState::active: return "ACTIVE";
        case CustodyReceiverActivationState::retired: return "RETIRED";
        case CustodyReceiverActivationState::revoked: return "REVOKED";
    }
    app_fail("CONFIG_CUSTODY_RECEIVER_STATE",
        "unknown receiver activation lifecycle state");
}

std::string custody_receiver_activation_commitment_text(
    const CustodyReceiverActivation& activation) {
    validate_activation(activation);
    return "NATRAV_CUSTODY_RECEIVER_ACTIVATION_COMMITMENT_V1\n"
        "id=" + activation.id +
        "\ngeneration=" + std::to_string(activation.generation) +
        "\npredecessor_sha256=" +
            operation_id_text(activation.predecessor) +
        "\nsession_rule_id=" + activation.session_rule_id +
        "\nsession_rule_generation=" +
            std::to_string(activation.session_rule_generation) +
        "\nsession_rule_commitment_sha256=" +
            operation_id_text(activation.session_rule_commitment) +
        "\nmaximum_inflight_offers=" +
            std::to_string(activation.maximum_inflight_offers) +
        "\nactivation_expires_unix_ms=" +
            std::to_string(activation.activation_expires_unix_ms) + "\n";
}

datacube::Digest32 custody_receiver_activation_commitment(
    const CustodyReceiverActivation& activation) {
    const auto text = custody_receiver_activation_commitment_text(activation);
    return datacube::sha256(datacube::OctetView(
        reinterpret_cast<const std::uint8_t*>(text.data()), text.size()));
}

std::string custody_receiver_activation_text(
    const CustodyReceiverActivation& activation) {
    const auto immutable =
        custody_receiver_activation_commitment_text(activation);
    return "NATRAV_CUSTODY_RECEIVER_ACTIVATION_V1\n" +
        immutable.substr(immutable.find('\n') + 1U) +
        "state=" + std::string(
            custody_receiver_activation_state_name(activation.state)) +
        "\n";
}

CustodyReceiverActivation parse_custody_receiver_activation(
    const std::string_view hex) {
    require(hex.size() <= 2U * kActivationTextLimit,
        "CONFIG_CUSTODY_RECEIVER_INVALID",
        "receiver activation byte bound");
    const auto raw = decode_adapter_configuration_record_hex(hex);
    require(raw.size() <= kActivationTextLimit &&
            std::all_of(raw.begin(), raw.end(), [](const char value) {
                const auto ch = static_cast<unsigned char>(value);
                return ch > 0U && ch < 128U;
            }),
        "CONFIG_CUSTODY_RECEIVER_NONCANONICAL",
        "canonical receiver activation requires ASCII without NUL");
    const std::string text(raw.begin(), raw.end());
    std::size_t offset = 0U;
    require(field_value(text, offset,
                "NATRAV_CUSTODY_RECEIVER_ACTIVATION_V1").empty(),
        "CONFIG_CUSTODY_RECEIVER_NONCANONICAL",
        "receiver activation header");
    CustodyReceiverActivation activation;
    activation.id = field_value(text, offset, "id=");
    activation.generation = parse_u64(
        field_value(text, offset, "generation="),
        "custody receiver generation", 1U,
        kCustodyReceiverActivationPerIdLimit);
    const auto predecessor = field_value(
        text, offset, "predecessor_sha256=");
    activation.predecessor = predecessor == std::string(64U, '0') ?
        datacube::Digest32{} : parse_operation_id(predecessor);
    activation.session_rule_id = field_value(
        text, offset, "session_rule_id=");
    activation.session_rule_generation = parse_u64(
        field_value(text, offset, "session_rule_generation="),
        "custody receiver V22 generation", 1U,
        kCustodySessionRulePerIdLimit);
    activation.session_rule_commitment = parse_operation_id(field_value(
        text, offset, "session_rule_commitment_sha256="));
    activation.maximum_inflight_offers =
        static_cast<std::uint32_t>(parse_u64(
            field_value(text, offset, "maximum_inflight_offers="),
            "custody receiver in-flight offers", 1U,
            kCustodyReceiverMaximumInflightOffers));
    activation.activation_expires_unix_ms = parse_u64(
        field_value(text, offset, "activation_expires_unix_ms="),
        "custody receiver activation expiry", 1U,
        std::numeric_limits<std::uint64_t>::max());
    activation.state = parse_state(field_value(text, offset, "state="));
    require(offset == text.size(),
        "CONFIG_CUSTODY_RECEIVER_NONCANONICAL",
        "trailing receiver-activation bytes are forbidden");
    validate_activation(activation);
    require(custody_receiver_activation_text(activation) == text,
        "CONFIG_CUSTODY_RECEIVER_NONCANONICAL",
        "receiver activation is not in canonical form");
    return activation;
}

void normalize_custody_receiver_policy(
    CustodyReceiverPolicy& activations) {
    require(activations.size() <= kCustodyReceiverActivationLimit,
        "CONFIG_CUSTODY_RECEIVER_CAPACITY",
        "retained receiver-activation count exceeded");
    std::sort(activations.begin(), activations.end(),
        [](const CustodyReceiverActivation& left,
           const CustodyReceiverActivation& right) {
            return std::tie(left.id, left.generation) <
                std::tie(right.id, right.generation);
        });
    std::set<std::pair<std::string, std::uint64_t>> identities;
    std::set<std::pair<std::string, std::uint64_t>> exact_rules;
    const CustodyReceiverActivation* previous = nullptr;
    std::size_t active_count = 0U;
    for (const auto& activation : activations) {
        validate_activation(activation);
        require(identities.emplace(
                activation.id, activation.generation).second,
            "CONFIG_CUSTODY_RECEIVER_CONFLICT",
            "duplicate receiver activation id and generation");
        require(exact_rules.emplace(activation.session_rule_id,
                activation.session_rule_generation).second,
            "CONFIG_CUSTODY_RECEIVER_CONFLICT",
            "one exact V22 rule cannot have several receiver activations");
        if (activation.state == CustodyReceiverActivationState::active) {
            ++active_count;
        }
        if (previous == nullptr || previous->id != activation.id) {
            require(activation.generation == 1U &&
                    digest_is_zero(activation.predecessor),
                "CONFIG_CUSTODY_RECEIVER_PREDECESSOR",
                "first receiver generation requires zero predecessor");
        } else {
            require(activation.generation == previous->generation + 1U &&
                    activation.predecessor ==
                        custody_receiver_activation_commitment(*previous),
                "CONFIG_CUSTODY_RECEIVER_PREDECESSOR",
                "exact consecutive immutable predecessor required");
            require(previous->state !=
                    CustodyReceiverActivationState::active,
                "CONFIG_CUSTODY_RECEIVER_ACTIVE_CONFLICT",
                "superseded receiver activation must first be retired or revoked");
        }
        previous = &activation;
    }
    require(active_count <= 1U,
        "CONFIG_CUSTODY_RECEIVER_ACTIVE_CONFLICT",
        "at most one daemon custody receiver activation may be active");
}

void require_custody_receiver_history_preserved(
    const CustodyReceiverPolicy& historical,
    const CustodyReceiverPolicy& candidate) {
    for (const auto& prior : historical) {
        const auto* next = find_exact(
            candidate, prior.id, prior.generation);
        require(next != nullptr,
            "CONFIG_CUSTODY_RECEIVER_HISTORY_REMOVED",
            "accepted receiver activation must remain present");
        require(custody_receiver_activation_commitment(*next) ==
                custody_receiver_activation_commitment(prior),
            "CONFIG_CUSTODY_RECEIVER_CONFLICT",
            "accepted receiver activation meaning cannot be redefined");
        require(static_cast<unsigned>(next->state) >=
                static_cast<unsigned>(prior.state),
            "CONFIG_CUSTODY_RECEIVER_STATE_ROLLBACK",
            "receiver retirement and revocation are monotonic");
    }
}

const CustodyReceiverActivation* find_custody_receiver_activation(
    const CustodyReceiverPolicy& policy,
    const std::string_view id,
    const std::uint64_t generation) noexcept {
    return find_exact(policy, id, generation);
}

const CustodyReceiverActivation*
find_custody_receiver_activation_for_rule(
    const CustodyReceiverPolicy& policy,
    const std::string_view session_rule_id,
    const std::uint64_t session_rule_generation) noexcept {
    const auto found = std::find_if(policy.begin(), policy.end(),
        [&](const CustodyReceiverActivation& activation) {
            return activation.session_rule_id == session_rule_id &&
                activation.session_rule_generation ==
                    session_rule_generation;
        });
    return found == policy.end() ? nullptr : &*found;
}

const CustodySessionRule& resolve_custody_receiver_session_rule(
    const CustodySessionPolicy& rules,
    const CustodyReceiverActivation& activation,
    const bool require_active) {
    validate_activation(activation);
    const auto* rule = find_custody_session_rule(
        rules, activation.session_rule_id,
        activation.session_rule_generation);
    require(rule != nullptr &&
            custody_session_rule_commitment(*rule) ==
                activation.session_rule_commitment,
        "CONFIG_CUSTODY_RECEIVER_RULE",
        "receiver activation names an absent or redefined V22 rule");
    if (rule->state == CustodySessionRuleState::revoked) {
        require(activation.state ==
                CustodyReceiverActivationState::revoked,
            "CONFIG_CUSTODY_RECEIVER_RULE_STATE",
            "a revoked V22 rule requires a revoked receiver activation");
    } else if (rule->state == CustodySessionRuleState::retired) {
        require(activation.state !=
                CustodyReceiverActivationState::active,
            "CONFIG_CUSTODY_RECEIVER_RULE_STATE",
            "an active receiver cannot retain a retired V22 rule");
    }
    require(!require_active ||
            (rule->state == CustodySessionRuleState::active &&
             activation.state ==
                CustodyReceiverActivationState::active),
        "CONFIG_CUSTODY_RECEIVER_RETIRED",
        "new daemon receipt requires active V22 and V23 authority");
    return *rule;
}

std::string custody_receiver_policy_json(
    const CustodyReceiverPolicy& policy) {
    std::string out =
        "{\"format\":\"V23_PASSIVE_DAEMON_CUSTODY_RECEIVER_V1\",\"activations\":[";
    bool first = true;
    for (const auto& activation : policy) {
        if (!first) { out += ','; }
        first = false;
        out += "{\"id\":" + json_string(activation.id) +
            ",\"generation\":" +
                std::to_string(activation.generation) +
            ",\"state\":" + json_string(
                custody_receiver_activation_state_name(activation.state)) +
            ",\"session_rule_id\":" +
                json_string(activation.session_rule_id) +
            ",\"session_rule_generation\":" +
                std::to_string(activation.session_rule_generation) +
            ",\"session_rule_commitment_sha256\":" +
                json_string(operation_id_text(
                    activation.session_rule_commitment)) +
            ",\"maximum_inflight_offers\":" +
                std::to_string(activation.maximum_inflight_offers) +
            ",\"activation_expires_unix_ms\":" +
                std::to_string(activation.activation_expires_unix_ms) +
            ",\"commitment_sha256\":" + json_string(
                operation_id_text(
                    custody_receiver_activation_commitment(activation))) +
            ",\"predecessor_sha256\":" +
                json_string(operation_id_text(activation.predecessor)) + "}";
    }
    return out + "]}";
}

} // namespace natrav_overlay
