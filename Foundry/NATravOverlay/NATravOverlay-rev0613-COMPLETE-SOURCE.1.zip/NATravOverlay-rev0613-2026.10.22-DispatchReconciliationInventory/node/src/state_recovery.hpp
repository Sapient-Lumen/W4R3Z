#pragma once
#include "journal.hpp"

namespace natrav_overlay {
struct StateAuditOptions final {
    std::filesystem::path directory;
    std::string node;
    std::uint64_t maximum_bytes{268'435'456U};
    std::optional<datacube::Digest32> expected_root;
    std::optional<std::uint64_t> expected_records;
};
struct StateAuditResult final { bool complete{false}; std::string json; };

struct CorrelatedStopRequestShape final {
    std::string operation;  // IMMEDIATE or DRAIN
    bool final_state_head{false};
    std::string correlation;
    std::uint64_t request_bytes{0U};
    std::string expected_command;
    std::optional<std::uint32_t> drain_deadline_ms;
    std::optional<std::string> drain_reason;
};

struct CorrelatedStopAuditOptions final {
    StateAuditOptions source;
    datacube::Digest32 request_id;
    std::optional<CorrelatedStopRequestShape> request_shape;
    std::uint32_t maximum_matches{64U};
    std::uint32_t maximum_json_bytes{60'000U};
};

struct StateRecoveryOptions final {
    StateAuditOptions source;
    datacube::Digest32 source_digest;
    datacube::Digest32 prefix_root;
    std::uint64_t prefix_records{0};
    std::uint64_t prefix_bytes{0};
    std::filesystem::path preserve_source;
    std::string reason;
};
[[nodiscard]] StateAuditResult audit_authenticated_state(const StateAuditOptions& options);
[[nodiscard]] std::string audit_correlated_stop(
    const CorrelatedStopAuditOptions& options);
[[nodiscard]] std::string render_correlated_stop_audit_report(
    const CorrelatedStopAuditOptions& options,
    const OfflineCorrelatedStopReplay& replay,
    std::string_view format,
    std::string_view source_json);
[[nodiscard]] std::string recover_authenticated_state(const StateRecoveryOptions& options);
} // namespace natrav_overlay
