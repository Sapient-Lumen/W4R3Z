#pragma once

#include "common.hpp"
#include "delivery_index.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>

namespace natrav_overlay {

enum class ActionSelectionKind : std::uint8_t {
    none = 0U,
    expired = 1U,
    ready = 2U,
};

struct ActionSelectionIndexEntry final {
    std::uint64_t not_before_unix_ms{0U};
    std::uint64_t expires_unix_ms{0U};
};

struct ActionSelectionIndexChoice final {
    ActionSelectionKind kind{ActionSelectionKind::none};
    std::optional<std::size_t> index;
    std::optional<std::uint64_t> next_wake_unix_ms;
    std::uint64_t tree_nodes_visited{0U};
};

// Derived entirely from validated action replay. Pending actions occupy both
// trees. Terminal transitions erase them, while begun-but-unfinished attempts
// remain ready for the existing restart-retry semantics.
class ActionSelectionIndex final {
public:
    void touch(
        std::size_t index,
        std::optional<ActionSelectionIndexEntry> entry);
    [[nodiscard]] ActionSelectionIndexChoice select(std::uint64_t now) const;
    [[nodiscard]] std::uint64_t revision(std::size_t index) const;
    [[nodiscard]] std::size_t pending() const noexcept;
    [[nodiscard]] bool valid() const;

private:
    std::uint64_t clock_{0U};
    DeadlineIndex readiness_;
    DeadlineIndex expiry_;
    std::map<std::size_t, ActionSelectionIndexEntry> entries_;
    std::map<std::size_t, std::uint64_t> revisions_;
};

// Narrow, payload-free scheduler selection. The version is process-local and
// used only to reject a stale in-memory choice before journal mutation.
struct ActionSelection final {
    ActionSelectionKind kind{ActionSelectionKind::none};
    datacube::Digest32 action_id{};
    datacube::Digest32 record_digest{};
    std::uint64_t queue_sequence{0U};
    std::uint64_t action_revision{0U};
    std::uint64_t admitted_unix_ms{0U};
    std::uint64_t not_before_unix_ms{0U};
    std::uint64_t expires_unix_ms{0U};
    std::uint64_t amount{0U};
    std::uint32_t attempts{0U};
    std::optional<std::uint64_t> next_wake_unix_ms;
    std::uint64_t tree_nodes_visited{0U};
    std::uint64_t metadata_records_read{0U};
};

}  // namespace natrav_overlay
