#pragma once

#include "common.hpp"
#include <array>
#include <memory>

namespace natrav_overlay {

// Separate-purpose secret, loaded once at the process entry point. Never copied
// into configuration, metadata, checkpoints, backups, status, or error strings.
struct StateAuthKey final {
    std::string generation;
    datacube::Digest32 id;
    std::array<std::uint8_t, 32> secret{};
    StateAuthKey() = default;
    ~StateAuthKey();
    StateAuthKey(const StateAuthKey&) = delete;
    StateAuthKey& operator=(const StateAuthKey&) = delete;
};
using StateAuthKeyPtr = std::shared_ptr<const StateAuthKey>;

struct StateAuthTransition final {
    std::string kind; // MIGRATE or ROTATE
    std::string generation;
    datacube::Digest32 key_id;
    std::uint64_t unix_ms{0};
    std::uint32_t uid{0};
    std::string reason;
    datacube::Digest32 source_root; // unkeyed file digest only for MIGRATE
};

struct StateAuthRecovery final {
    datacube::Digest32 source_digest;
    datacube::Digest32 discarded_digest;
    datacube::Digest32 prefix_digest;
    datacube::Digest32 selected_root;
    datacube::Digest32 selected_epoch;
    std::string generation;
    datacube::Digest32 key_id;
    std::uint64_t selected_records{0};
    std::uint64_t source_bytes{0};
    std::uint64_t prefix_bytes{0};
    std::uint64_t unix_ms{0};
    std::uint32_t uid{0};
    std::uint32_t pid{0};
    std::string reason;
};

struct StateAuthentication final {
    std::string generation;
    datacube::Digest32 key_id;
    datacube::Digest32 epoch;
    datacube::Digest32 parent_root;
    datacube::Digest32 checkpoint_logical_digest;
    std::string purpose; // MIGRATE, ROTATE, COMPACT, BACKUP, RECOVER
    std::vector<StateAuthTransition> history;
    std::vector<StateAuthRecovery> recoveries;
    datacube::Digest32 header_tag;
    datacube::Digest32 root;
    std::uint64_t records{0};
    std::uint64_t checkpoint_overhead{0};
};

// Explicit, non-secret external expectation. Never persisted or silently advanced.
// Equality applies to an authenticated, semantically replayed INPUT representation.
struct StateHeadExpectation final {
    std::string node;
    std::string generation;
    datacube::Digest32 key_id;
    datacube::Digest32 epoch;
    datacube::Digest32 root;
    std::uint64_t records{0U};
    std::uint64_t journal_bytes{0U};
};
[[nodiscard]] StateHeadExpectation parse_state_head_expectation(std::string_view selector);
void configure_process_state_head_expectation(std::string_view selector);
[[nodiscard]] const std::optional<StateHeadExpectation>& process_state_head_expectation();
[[nodiscard]] bool matches_state_head(const StateHeadExpectation& expected,
    std::string_view node, const StateAuthentication& authentication, std::uint64_t bytes);
[[nodiscard]] std::string state_head_selector(std::string_view node,
    const StateAuthentication& authentication, std::uint64_t bytes);
void enforce_expected_state_head(std::string_view node,
    const std::optional<StateAuthentication>& authentication, std::uint64_t bytes);
[[nodiscard]] std::string state_head_json(std::string_view node,
    const std::optional<StateAuthentication>& authentication, std::uint64_t bytes,
    bool compare_expectation = true);

struct AuthenticatedJournal final {
    datacube::Octets bytes;
    StateAuthentication authentication;
};
struct VerifiedJournal final {
    datacube::Octets plain_frames;
    StateAuthentication authentication;
};

// Scanner never applies application state and never skips an invalid record.
// Only a structurally plausible incomplete FINAL record receives INCOMPLETE_TAIL.
struct AuthenticatedScan final {
    VerifiedJournal verified;
    bool header_authenticated{false};
    std::uint64_t verified_bytes{0};
    std::string status{"INVALID"};
    std::string code;
};
[[nodiscard]] AuthenticatedScan scan_authenticated_journal(
    datacube::OctetView bytes, std::string_view node, const StateAuthKeyPtr& key,
    std::uint64_t maximum_bytes);
[[nodiscard]] StateAuthKeyPtr load_state_auth_key(const std::filesystem::path& path);
[[nodiscard]] std::string initialize_state_auth_key(
    const std::filesystem::path& output, std::string_view generation);
void configure_process_state_auth_key(const std::filesystem::path& path);
[[nodiscard]] StateAuthKeyPtr process_state_auth_key();
[[nodiscard]] bool is_authenticated_journal(datacube::OctetView bytes) noexcept;
[[nodiscard]] VerifiedJournal verify_authenticated_journal(
    datacube::OctetView bytes, std::string_view node, const StateAuthKeyPtr& key,
    std::uint64_t maximum_bytes);
[[nodiscard]] AuthenticatedJournal authenticate_checkpoint(
    datacube::OctetView plain_frame, std::string_view node,
    const StateAuthKeyPtr& key, const StateAuthentication* previous,
    const datacube::Digest32& logical_digest, std::string_view purpose,
    std::string_view reason = {}, const datacube::Digest32& unkeyed_source = {});
[[nodiscard]] datacube::Octets authenticate_next_frame(
    datacube::OctetView plain_frame, const StateAuthKeyPtr& key,
    StateAuthentication& next);
[[nodiscard]] std::string state_authentication_json(
    const std::optional<StateAuthentication>& value, bool bounded = false);
void state_auth_test_pause(std::string_view point);

} // namespace natrav_overlay
