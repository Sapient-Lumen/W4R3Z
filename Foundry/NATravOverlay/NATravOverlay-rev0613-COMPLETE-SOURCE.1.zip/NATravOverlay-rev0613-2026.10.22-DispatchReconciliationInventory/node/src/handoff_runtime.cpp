#include "handoff_runtime.hpp"
#include "handoff_io.hpp"
#include "runtime.hpp"

#include <chrono>
#include <unistd.h>

namespace natrav_overlay {
namespace {
void require(bool condition, std::string_view code, std::string_view detail) {
    if (!condition) { app_fail(code, detail); }
}
std::uint64_t now_ms() {
    const auto n = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    require(n > 0, "CLOCK_INVALID", "clock must be after the Unix epoch");
    return static_cast<std::uint64_t>(n);
}
const PeerKeyGeneration& active_key(const RuntimeConfig& config, const HandoffBinding& b) {
    const auto* key = find_peer_generation(config, b.node, b.signing_generation);
    require(key != nullptr && key->state == KeyGenerationState::active,
        "HANDOFF_PEER_KEY_REJECTED", "origin/recipient key generation is not currently active");
    require_handoff_binding(b, key->node_id, key->generation, key->spki_sha256);
    return *key;
}
void obligation_key(const StoredOutbound& stored, const HandoffBinding& recipient) {
    require(stored.delivery.has_value() && stored.delivery->policy.peer_generation.has_value() &&
        stored.delivery->policy.peer_spki_sha256.has_value() && stored.record.recipient == recipient.node &&
        *stored.delivery->policy.peer_generation == recipient.signing_generation &&
        *stored.delivery->policy.peer_spki_sha256 == handoff_signing_pin(recipient),
        "HANDOFF_OBLIGATION_KEY_REJECTED", "durable obligation names a different identity generation");
}
AdmissionResult admit(NodeState& state, const RuntimeConfig& config,
    const HandoffBinding& origin, const EvidenceRecord& record, std::uint64_t now) {
    require(record.issuer == origin.node, "AUTHENTICATED_ISSUER_MISMATCH", "capsule origin differs from operation issuer");
    const auto decision = evaluate_authorization(config.authorization, origin.node, origin.signing_generation, record);
    if (!decision.allowed) {
        state.record_authorization_denial(record, decision, now, decision.reason_code);
        app_fail("AUTHORIZATION_DENIED", "current policy does not authorize the imported operation");
    }
    // Same action-result requirements as the live peer admission boundary.
    std::optional<ActionResultBinding> result;
    const bool require_result = operation_class_for(record) == AuthorizedOperationClass::counter_action && config.format_version >= 18U;
    if (require_result) {
        const auto* rule = find_action_result_rule(config.action_results, origin.node, origin.signing_generation, "counter.add");
        const auto* routed = find_peer(config, origin.node);
        const auto& generation = active_key(config, origin);
        if (rule != nullptr && routed != nullptr && routed->active_generation == origin.signing_generation &&
            routed->active_spki_sha256 == generation.spki_sha256) {
            const auto canonical = canonical_runtime_config(config);
            result = ActionResultBinding{
                .result_scope = rule->result_scope, .policy_digest = config.action_results.digest,
                .rule_digest = rule->digest,
                .configuration_event = state.configuration_event_reference(config.runtime_generation,
                    runtime_configuration_digest(canonical), canonical),
                .peer_generation = origin.signing_generation, .peer_spki_sha256 = generation.spki_sha256,
                .maximum_attempts = routed->delivery.maximum_attempts,
                .initial_backoff_ms = routed->delivery.initial_backoff_ms,
                .maximum_backoff_ms = routed->delivery.maximum_backoff_ms,
                .delivery_expiry_ms = routed->delivery.expiry_ms,
            };
        }
    }
    // No synthetic TLS session, HELLO observation, success receipt, or alternate journal.
    return state.admit_inbound_authorized(record, node_artifact_digest(origin.node), decision, now, std::move(result), require_result);
}
std::string result_json(std::string_view status, const datacube::Digest32& id,
    const datacube::Digest32& operation, std::string_view kind) {
    return "{\"format\":\"NATRAV_HANDOFF_RESULT_V1\",\"status\":" + json_string(status) +
        ",\"capsule_id\":" + json_string(operation_id_text(id)) +
        ",\"operation_id\":" + json_string(operation_id_text(operation)) + ",\"kind\":" + json_string(kind) + "}";
}
} // namespace

std::string handoff_import_result_json(const HandoffImportResult& result) {
    return result_json(result.status, result.capsule_id,
        result.operation_id, result.kind);
}

StoredOutbound NodeState::outbound_record_for_handoff(const datacube::Digest32& operation) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = outbound_index_.find(operation_id_text(operation));
    require(found != outbound_index_.end(), "HANDOFF_OPERATION_NOT_FOUND", "operation not in existing outbox");
    return outbound_[found->second];
}
StoredInbound NodeState::inbound_record_for_handoff(const datacube::Digest32& operation) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = inbound_index_.find(operation_id_text(operation));
    require(found != inbound_index_.end(), "HANDOFF_OPERATION_NOT_FOUND", "operation not in existing inbox");
    return inbound_[found->second];
}
HandoffImportResult import_handoff_capsule(
    NodeState& state, const RuntimeConfig& config,
    const HandoffLocalKey& local, const datacube::OctetView encoded,
    const std::uint64_t now) {
    const auto untrusted = peek_handoff_origin(encoded);
    const auto& origin_key = active_key(config, untrusted);
    if (config.format_version >= 20U) {
        require_handoff_key_use(config.handoff_keys, local.binding, false);
        require_handoff_key_use(config.handoff_keys, untrusted, false);
    }
    const auto opened = open_handoff_capsule(encoded, local.binding,
        local.secret, origin_key.node_id, origin_key.generation,
        origin_key.spki_sha256, now);
    if (const auto* record = std::get_if<EvidenceRecord>(&opened.message)) {
        const auto admitted = admit(state, config, opened.origin, *record, now);
        handoff_test_pause("NATRAV_TEST_HANDOFF_AFTER_IMPORT_MS");
        return HandoffImportResult{
            .status = admitted.disposition == AdmissionDisposition::committed ?
                "COMMITTED" : "DUPLICATE",
            .capsule_id = opened.capsule_id,
            .operation_id = record->operation_id,
            .kind = "operation",
        };
    }
    const auto& receipt = std::get<DeliveryReceipt>(opened.message);
    const auto stored = state.outbound_record_for_handoff(receipt.operation_id);
    obligation_key(stored, opened.origin);
    require(stored.receipt.has_value() ||
            (outbound_is_pending(stored) &&
             now < stored.delivery->policy.expires_unix_ms),
        "HANDOFF_OPERATION_TERMINAL",
        "terminal obligation cannot accept a new receipt");
    state.record_outbound_receipt(receipt);
    return HandoffImportResult{
        .status = stored.receipt.has_value() ?
            "DUPLICATE_RECEIPT" : "ACKNOWLEDGED",
        .capsule_id = opened.capsule_id,
        .operation_id = receipt.operation_id,
        .kind = "receipt",
    };
}

std::string run_handoff_command(const HandoffCommand& options) {
    const auto seed = load_runtime_config(options.config);
    // The caller must already own an initialized private state directory. Never
    // scan for state or make a new application store from capsule metadata.
    require_handoff_state_owner(seed.state_directory);
    NodeState state(seed.state_directory, seed.local_node, seed.maximum_journal_bytes, seed.queue_limits);
    RuntimeConfiguration runtime(seed, state);
    const auto config = runtime.snapshot();
    require(!config->runtime_generation.empty(), "HANDOFF_VERSIONED_CONFIG_REQUIRED",
        "handoff requires a durably accepted V7-or-later configuration");
    require(local_control_allows(config->local_control, static_cast<std::uint32_t>(::geteuid()), LocalControlClass::maintenance),
        "LOCAL_CONTROL_DENIED", "offline handoff requires owner maintenance authority");
    if (options.command == "handoff-key-init") {
        const auto binding = create_handoff_key(options.key_directory, *config, options.generation);
        return "{\"format\":\"NATRAV_HANDOFF_KEY_V1\",\"node\":" + json_string(binding.node) +
            ",\"signing_generation\":" + json_string(binding.signing_generation) +
            ",\"handoff_generation\":" + json_string(binding.handoff_generation) +
            ",\"binding_sha256\":" + json_string(operation_id_text(datacube::sha256(binding.canonical))) + "}";
    }
    auto local = load_handoff_key(options.key_directory, *config);
    if (options.command == "handoff-export") {
        if (config->format_version >= 20U) { require_handoff_key_use(config->handoff_keys, local->binding, true); }
        const auto bytes = read_handoff_file(options.recipient_binding, kHandoffBindingLimit);
        require(datacube::sha256(bytes) == options.recipient_binding_digest,
            "HANDOFF_BINDING_COMMITMENT_REJECTED", "binding differs from the operator-selected commitment");
        const auto recipient = decode_handoff_binding(bytes); (void)active_key(*config, recipient);
        if (config->format_version >= 20U) { require_handoff_key_use(config->handoff_keys, recipient, true); }
        ApplicationMessage message;
        if (options.kind == "operation") {
            const auto stored = state.outbound_record_for_handoff(options.operation);
            obligation_key(stored, recipient);
            require(outbound_is_pending(stored) && now_ms() < stored.delivery->policy.expires_unix_ms &&
                stored.delivery->attempts < stored.delivery->policy.maximum_attempts,
                "HANDOFF_OPERATION_TERMINAL", "only an unexpired pending obligation can be exported");
            require(options.expires_ms <= stored.delivery->policy.expires_unix_ms,
                "HANDOFF_TIME_REJECTED", "capsule cannot extend the obligation lifetime");
            message = stored.record;
        } else {
            require(options.kind == "receipt", "HANDOFF_KIND_REJECTED", "only operation or receipt may be exported");
            const auto stored = state.inbound_record_for_handoff(options.operation);
            require(stored.record.issuer == recipient.node && stored.record.recipient == config->local_node &&
                stored.authorization.has_value() && stored.authorization->peer_generation == recipient.signing_generation &&
                !stored.local_authorship && !stored.subscribed_source,
                "HANDOFF_RECEIPT_REJECTED", "only a prior authenticated inbound admission can yield this receipt");
            // Stable receipt for the original journal commit, even following a
            // duplicate import. No fresh sequence or alternate receipt ledger.
            message = DeliveryReceipt{stored.record.operation_id, config->local_node, config->local_node,
                ReceiptDisposition::committed, stored.sequence, stored.record_digest};
        }
        auto signer = load_handoff_signer(*config);
        const auto encoded = seal_handoff_capsule(local->binding, signer.get(), recipient, message, now_ms(), options.expires_ms);
        publish_handoff_file(options.output, encoded);
        // Export changes neither the obligation's attempt counter nor its receipt.
        return result_json("EXPORTED_NOT_DELIVERED", datacube::sha256(encoded), options.operation, options.kind);
    }
    require(options.command == "handoff-import", "UNKNOWN_COMMAND",
        "unknown handoff operation");
    const auto encoded = read_handoff_file(
        options.input, kHandoffCapsuleLimit);
    return handoff_import_result_json(import_handoff_capsule(
        state, *config, *local, encoded, now_ms()));
}
} // namespace natrav_overlay
