#pragma once

#include "common.hpp"

#include <atomic>
#include <cstdint>
#include <filesystem>
#include <mutex>
#include <optional>
#include <set>
#include <string>

namespace natrav_overlay {

class NodeState;
struct RuntimeConfig;
struct TlsSessionInfo;
class TlsContext;
struct CustodyTransferOffer;
struct CustodyTransferAcceptance;
struct CustodySessionServiceResult;

inline constexpr std::string_view kNativeCustodySessionServiceFeature =
    "NATIVE_DURABLE_CUSTODY_SESSION_SERVICE_V1";


// One passive receiver object is embedded in the ordinary daemon. It owns no
// listener, route, sender, queue, retry loop, thread, or durable ledger. Each
// operation is evaluated against the caller's current accepted configuration.
class PassiveCustodyReceiver final {
public:
    explicit PassiveCustodyReceiver(NodeState& state) noexcept;
    [[nodiscard]] CustodyTransferAcceptance receive(
        const RuntimeConfig& config,
        const TlsSessionInfo& session,
        const CustodyTransferOffer& offer);
    [[nodiscard]] std::uint32_t in_flight() const noexcept;
private:
    NodeState& state_;
    std::atomic<std::uint32_t> in_flight_{0U};
};


struct CustodyOwnerDispatchRequest final {
    std::string activation_id;
    std::uint64_t activation_generation{0U};
    datacube::Digest32 receiver_request_id{};
    datacube::Digest32 dispatch_request_id{};
    std::string reason;
};

inline constexpr std::size_t kMaximumCustodyDispatchStatusJsonBytes =
    16'384U;
inline constexpr std::uint32_t kMaximumCustodyDispatchInventoryRecords = 64U;
inline constexpr std::uint32_t kMaximumCustodyDispatchInventoryJsonBytes =
    60'000U;

struct CustodyOwnerDispatchStatusRequest final {
    std::string activation_id;
    std::uint64_t activation_generation{0U};
    datacube::Digest32 dispatch_request_id{};
};

struct CustodyOwnerDispatchInventoryRequest final {
    std::string activation_id;
    std::uint64_t activation_generation{0U};
    std::optional<datacube::Digest32> cursor;
    std::uint32_t limit{32U};
    std::uint32_t maximum_bytes{32'768U};
};

// One synchronous owner-dispatch object is embedded in the ordinary daemon.
// It owns no listener, scheduler, timer, route search, fallback, or background
// worker. Every call is one authenticated owner request and may commit at most
// one new outbound attempt.
class CustodyOwnerDispatcher final {
public:
    CustodyOwnerDispatcher(NodeState& state, TlsContext& tls) noexcept;
    [[nodiscard]] CustodySessionServiceResult dispatch_once(
        const RuntimeConfig& config,
        const CustodyOwnerDispatchRequest& request);
    [[nodiscard]] std::string reconcile_status(
        const RuntimeConfig& config,
        const CustodyOwnerDispatchStatusRequest& request) const;
    [[nodiscard]] std::string reconcile_inventory(
        const RuntimeConfig& config,
        const CustodyOwnerDispatchInventoryRequest& request) const;
    [[nodiscard]] std::uint32_t in_flight() const noexcept;
private:
    NodeState& state_;
    TlsContext& tls_;
    std::atomic<std::uint32_t> in_flight_{0U};
    std::mutex active_mutex_;
    std::set<std::string> active_receiver_requests_;
};

struct CustodySessionServiceOptions final {
    std::filesystem::path config;
    std::string rule_id;
    std::uint64_t rule_generation{0U};
    std::string route_id;
    std::filesystem::path bundle;
    datacube::Digest32 request_id{};
    bool has_request_id{false};
    std::filesystem::path output;
    bool once{false};
};

struct CustodySessionServiceResult final {
    int status{0};
    std::string json;
};

[[nodiscard]] CustodySessionServiceResult run_custody_session_send(
    const CustodySessionServiceOptions& options);
[[nodiscard]] CustodySessionServiceResult run_custody_session_status(
    const CustodySessionServiceOptions& options);
[[nodiscard]] CustodySessionServiceResult run_custody_session_export(
    const CustodySessionServiceOptions& options);
int run_custody_session_server(
    const CustodySessionServiceOptions& options);
[[nodiscard]] std::string custody_session_service_version_json();

} // namespace natrav_overlay
