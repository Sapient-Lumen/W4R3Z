#include "consumer_inventory.hpp"
#include "journal.hpp"
#include "config.hpp"
#include "submission_work.hpp"

#include <algorithm>
#include <chrono>
#include <vector>

namespace natrav_overlay {
namespace {
using Digest = datacube::Digest32;
using Bytes = datacube::Octets;
constexpr std::size_t kOwnerBound = kConsumerUidLimit + kRetiredConsumerUidLimit;
constexpr std::size_t kPrincipalReserve = 384U;
void require(bool condition, std::string_view code, std::string_view detail) {
    if (!condition) app_fail(code, detail);
}
void text(Bytes& b, std::string_view s) {
    datacube::append_be16(b, static_cast<std::uint16_t>(s.size())); datacube::append_text(b,s);
}
std::string text(datacube::Reader& r, std::size_t maximum) {
    const auto n = r.read_be16("text length");
    require(n <= maximum,"CONSUMER_INVENTORY_INVALID","text exceeds bound");
    return datacube::octets_text(r.read_exact(n,"text"),"text",true);
}
void digest(Bytes& b, const Digest& d) { datacube::append_octets(b,d.octets); }
Digest digest(datacube::Reader& r) {
    Digest d{}; const auto b=r.read_exact(32U,"digest");
    std::copy(b.begin(),b.end(),d.octets.begin());return d;
}
void optional_digest(Bytes& b,const std::optional<Digest>& d) {
    datacube::append_u8(b,d?1U:0U);if(d)digest(b,*d);
}
std::optional<Digest> optional_digest(datacube::Reader& r) {
    const auto flag=r.read_u8("optional");
    require(flag<=1U,"CONSUMER_INVENTORY_INVALID","invalid optional marker");
    return flag?std::optional<Digest>{digest(r)}:std::nullopt;
}
bool valid_name(std::string_view s) {
    return !s.empty() && s.size()<=64U && std::all_of(s.begin(),s.end(),[](char c){
        return (c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'||c=='-'||c=='.';
    });
}
std::string hex(const Digest& d) { return json_string(datacube::hex_lower(d)); }
bool visible(const DurableConsumer& c,const RuntimeConfig& cfg,const EvidenceReadAccess& access) {
    // Old progress and pending boundaries may reflect domains no longer granted.
    // Conservatively expose only consumers whose complete adopted read authority
    // is still current, even when their registered filters are narrower.
    if(c.adoptions.empty() || c.adoptions.back().authority!=access.digest) return false;
    if(c.projection && (cfg.format_version<12U ||
        !local_control_allows(cfg.local_control,c.uid,LocalControlClass::projection))) return false;
    const bool payload=c.selection.include_payload || (c.projection && c.projection->numeric.has_value());
    if(!access.metadata_allowed || (payload&&!access.payload_allowed)) return false;
    return std::any_of(access.grants.begin(),access.grants.end(),[&](const auto& g){
        return (!payload||g.payload)&&(c.selection.issuer.empty()||c.selection.issuer==g.issuer)&&
            (c.selection.scope.empty()||c.selection.scope==g.scope);
    });
}
std::string_view kind(const DurableConsumer& c) {
    return !c.projection?"consumer":c.projection->numeric?"numeric":"metadata";
}
bool matches(const DurableConsumer& c,const ConsumerInventory& q) {
    return (q.kind=="all" || q.kind==kind(c) || (q.kind=="projection"&&c.projection)) &&
        (q.lifecycle=="all" || q.lifecycle==(c.retirement?"retired":"active")) &&
        (q.name.empty()||q.name==c.name) && (!q.instance||*q.instance==c.instance) &&
        (q.issuer.empty()||q.issuer==c.selection.issuer) && (q.scope.empty()||q.scope==c.selection.scope);
}
std::string batch_summary(const std::optional<ConsumerBatch>& b) {
    if(!b)return "null";
    return "{\"id\":"+hex(b->id)+",\"from\":"+std::to_string(b->from)+
        ",\"through\":"+std::to_string(b->through)+",\"configuration_event\":"+std::to_string(b->configuration_event)+"}";
}
std::string summary(const DurableConsumer& c,std::size_t ordinal) {
    // Do not call consumer_json/encode_consumer/projection_json: those copy or
    // hash complete source/result/adoption histories, irrelevant to inventory.
    std::string out="{\"ordinal\":"+std::to_string(ordinal)+",\"name\":"+json_string(c.name)+
        ",\"owner_uid\":"+std::to_string(c.uid)+",\"instance\":"+hex(c.instance)+
        ",\"kind\":"+json_string(kind(c))+",\"lifecycle\":"+json_string(c.retirement?"RETIRED":"ACTIVE")+
        ",\"consumer_revision\":"+std::to_string(c.revision)+
        ",\"lifecycle_revision\":"+std::to_string(c.retirement?c.retirement->revision:c.revision)+
        ",\"epoch\":"+std::to_string(c.adoptions.back().epoch)+
        ",\"acknowledged_sequence\":"+std::to_string(c.position)+
        ",\"acknowledgments\":"+std::to_string(c.acknowledgments)+
        ",\"authority_digest\":"+hex(c.adoptions.back().authority)+
        ",\"issuer_filter\":"+(c.selection.issuer.empty()?"null":json_string(c.selection.issuer))+
        ",\"scope_filter\":"+(c.selection.scope.empty()?"null":json_string(c.selection.scope))+
        ",\"payload_included\":"+(c.selection.include_payload?"true":"false")+
        ",\"limit\":"+std::to_string(c.selection.maximum_records)+
        ",\"max_bytes\":"+std::to_string(c.selection.maximum_response_bytes)+
        ",\"payload_length\":"+std::to_string(c.selection.payload_length)+
        ",\"pending_batch\":"+batch_summary(c.pending)+
        ",\"last_acknowledged_batch\":"+batch_summary(c.last_ack)+
        ",\"configuration_event\":"+std::to_string(c.configuration_event)+
        ",\"unix_ms\":"+std::to_string(c.unix_ms)+",\"pid\":"+std::to_string(c.pid)+
        ",\"last_transition\":"+json_string(c.transition)+",\"projection\":";
    if(c.projection){out+="{\"definition\":"+json_string(c.projection->numeric?"NUMERIC_SUMMARY_V1":"DOMAIN_SUMMARY_V1")+
        ",\"definition_digest\":"+hex(c.projection->definition_digest)+
        ",\"maximum_admissions\":"+std::to_string(c.projection->maximum_admissions)+",\"result_included\":false}";
    } else out+="null";
    out+=",\"retirement\":";
    if(c.retirement){const auto& r=*c.retirement;
        out+="{\"revision\":"+std::to_string(r.revision)+",\"configuration_event\":"+std::to_string(r.configuration_event)+
            ",\"unix_ms\":"+std::to_string(r.unix_ms)+",\"pid\":"+std::to_string(r.pid)+
            ",\"pending_disposition\":"+json_string(r.abandoned_pending?"ABANDONED_UNACKNOWLEDGED":"NONE")+"}";
    } else out+="null";
    return out+"}";
}
} // namespace

void validate_consumer_inventory(const ConsumerInventory& q) {
    require((q.kind=="all"||q.kind=="consumer"||q.kind=="projection"||q.kind=="metadata"||q.kind=="numeric") &&
        (q.lifecycle=="all"||q.lifecycle=="active"||q.lifecycle=="retired") &&
        (q.name.empty()||valid_name(q.name)) && (q.issuer.empty()||valid_node_id(q.issuer)) &&
        (q.scope.empty()||valid_scope(q.scope)) && (!q.instance||!digest_is_zero(*q.instance)) &&
        q.limit>=1U&&q.limit<=32U && q.maximum_bytes>=2048U&&q.maximum_bytes<=60000U && q.offset<=kOwnerBound &&
        (!q.selection||!digest_is_zero(*q.selection)),"CONSUMER_INVENTORY_INVALID","invalid exact filter or page bound");
    require(q.offset==0U||q.selection.has_value(),"CONSUMER_INVENTORY_SELECTION_REQUIRED","continuation requires selected inventory digest");
}
Bytes encode_consumer_inventory(const ConsumerInventory& q) {
    validate_consumer_inventory(q);Bytes b;datacube::append_text(b,"CIN1");
    text(b,q.kind);text(b,q.lifecycle);text(b,q.name);text(b,q.issuer);text(b,q.scope);optional_digest(b,q.instance);
    datacube::append_be32(b,q.offset);datacube::append_be32(b,q.limit);datacube::append_be32(b,q.maximum_bytes);
    optional_digest(b,q.selection);return b;
}
ConsumerInventory decode_consumer_inventory(datacube::OctetView b) {
    try{datacube::Reader r(b,"consumer inventory");
        require(datacube::octets_text(r.read_exact(4U,"magic"),"magic",true)=="CIN1","CONSUMER_INVENTORY_INVALID","unknown version");
        ConsumerInventory q;q.kind=text(r,16U);q.lifecycle=text(r,16U);q.name=text(r,64U);q.issuer=text(r,64U);q.scope=text(r,128U);
        q.instance=optional_digest(r);q.offset=r.read_be32("offset");q.limit=r.read_be32("limit");q.maximum_bytes=r.read_be32("max bytes");
        q.selection=optional_digest(r);r.require_eof("consumer inventory");validate_consumer_inventory(q);return q;
    }catch(const datacube::Failure&){app_fail("CONSUMER_INVENTORY_INVALID","malformed or truncated request");}
}
std::string NodeState::consumer_inventory(const ConsumerInventory& q,const RuntimeConfig& cfg,
    std::uint32_t uid,std::chrono::steady_clock::time_point deadline) const {
    validate_consumer_inventory(q);
    require(cfg.format_version>=11U,"CONSUMER_POLICY_VERSION_REQUIRED","inventory requires V11 or newer");
    const auto access=evidence_read_access(cfg.evidence_read,cfg.local_control,uid);
    require(local_control_allows(cfg.local_control,uid,LocalControlClass::consumer)&&access.scoped&&access.metadata_allowed,
        "LOCAL_CONTROL_CLASS_DENIED","consumer and scoped metadata-read authority required");
    const auto configuration=runtime_configuration_digest(canonical_runtime_config(cfg));
    std::lock_guard<std::mutex> lock(mutex_);
    require(!poisoned_,"STATE_UNAVAILABLE","writer requires restart");
    const auto check_time=[&](){require(std::chrono::steady_clock::now()<deadline,"CONSUMER_INVENTORY_DEADLINE","inventory exceeded deadline");};
    check_time();SubmissionWork work;SubmissionWorkScope measure(work);
    std::vector<std::string> selected;
    const auto prefix=std::to_string(uid)+":";
    const auto first=consumers_.lower_bound(q.name.empty()?prefix:consumer_key(uid,q.name));
    std::size_t owned=0U;
    for(auto it=first;it!=consumers_.end()&&it->first.starts_with(prefix);++it){
        if(!q.name.empty()&&it->first!=consumer_key(uid,q.name))break;
        check_time();const auto& c=it->second;
        require(++owned<=kOwnerBound&&c.uid==uid,"STATE_INDEX_CORRUPT","owned consumer registry bound");
        // Neither hidden existence, counters, nor serialized commitments escape.
        if(!visible(c,cfg,access)||!matches(c,q))continue;
        selected.push_back(summary(c,selected.size()+1U));
    }
    Bytes seed;datacube::append_text(seed,"NATRAV_OVERLAY_CONSUMER_INVENTORY_SELECTION_V1");datacube::append_u8(seed,0U);
    text(seed,node_id_);datacube::append_be32(seed,uid);digest(seed,configuration);digest(seed,access.digest);
    text(seed,q.kind);text(seed,q.lifecycle);text(seed,q.name);text(seed,q.issuer);text(seed,q.scope);optional_digest(seed,q.instance);
    datacube::append_be32(seed,static_cast<std::uint32_t>(selected.size()));
    auto root=datacube::sha256(seed);
    for(const auto& row:selected){Bytes link;datacube::append_text(link,"NATRAV_OVERLAY_CONSUMER_INVENTORY_ROW_V1");
        datacube::append_u8(link,0U);digest(link,root);datacube::append_be32(link,static_cast<std::uint32_t>(row.size()));datacube::append_text(link,row);root=datacube::sha256(link);}
    require(!q.selection||*q.selection==root,"CONSUMER_INVENTORY_SELECTION_MISMATCH","selected authorized metadata or context changed");
    require(q.offset<=selected.size(),"CONSUMER_INVENTORY_INVALID","offset exceeds selected inventory");
    std::size_t returned=0U,visited=0U;std::string rows;
    const auto render=[&](std::string_view content,std::size_t count){
        const auto next=q.offset+count;
        return std::string("{\"format\":\"NATRAV_OVERLAY_CONSUMER_INVENTORY_V1\",\"ok\":true,\"node\":")+json_string(node_id_)+
            ",\"owner_uid\":"+std::to_string(uid)+",\"authorized_configuration_digest\":"+hex(configuration)+
            ",\"read_authority_digest\":"+hex(access.digest)+",\"selected_total\":"+std::to_string(selected.size())+
            ",\"selection_digest\":"+hex(root)+",\"offset\":"+std::to_string(q.offset)+",\"returned\":"+std::to_string(count)+
            ",\"next_offset\":"+std::to_string(next)+",\"has_more\":"+(next<selected.size()?"true":"false")+
            ",\"sequence_semantics\":\"AUTHORIZED_OWNER_NAME_ORDER\",\"observation\":\"ONE_STATE_MUTEX_CURRENT_METADATA\""+
            ",\"visibility\":\"CURRENT_ADOPTED_AUTHORITY_ONLY\",\"projection_results_included\":false,\"schedule_details_included\":false"+
            ",\"freshness\":\"NOT_ESTABLISHED\",\"work\":{\"scope\":\"LOCKED_CONSUMER_INVENTORY\",\"authorized_summaries_hashed\":"+std::to_string(selected.size())+
            ",\"page_rows_visited\":"+std::to_string(visited)+",\"evidence_records_visited\":0,\"consumer_histories_serialized\":0"+
            ",\"snapshot_calls\":"+std::to_string(work.snapshot_calls)+",\"snapshot_payload_bytes\":"+std::to_string(work.snapshot_evidence_payload_bytes)+
            ",\"logical_bytes_serialized\":"+std::to_string(work.snapshot_logical_bytes)+"},\"records\":["+std::string(content)+"]}";
    };
    for(std::size_t n=q.offset;n<selected.size()&&returned<q.limit;++n){
        check_time();++visited;const auto trial=rows+(rows.empty()?"":",")+selected[n];
        if(render(trial,returned+1U).size()+kPrincipalReserve>q.maximum_bytes){
            require(returned!=0U,"CONSUMER_INVENTORY_PAGE_TOO_SMALL","first complete summary exceeds byte budget");break;}
        rows=trial;++returned;
    }
    auto out=render(rows,returned);require(out.size()+kPrincipalReserve<=q.maximum_bytes,"CONSUMER_INVENTORY_PAGE_TOO_SMALL","metadata exceeds byte budget");
    check_time();return out;
}
} // namespace natrav_overlay
