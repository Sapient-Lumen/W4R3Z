#include "evidence_query.hpp"
#include "journal.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <memory>
#include <queue>
#include <cstdlib>
#include <iostream>
#include <thread>
#include <openssl/core_names.h>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/params.h>
#include <openssl/rand.h>
#include <string_view>

namespace natrav_overlay {
namespace {
constexpr std::size_t kCursorBytes = 152U;
constexpr std::size_t kScopedCursorBytes = kCursorBytes + 32U;
constexpr std::size_t kRootBatchRecords = 128U;
constexpr std::size_t kEnvelopeReserve = 3'072U;
constexpr std::uint64_t kCursorLifetimeMs = 300'000U;

void checked(const int value) {
    if (value != 1) { app_fail("EVIDENCE_QUERY_CRYPTO_FAILED", "cursor cryptography failed"); }
}
std::uint64_t monotonic_ms() {
    const auto value = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
    if (value < 0) { app_fail("EVIDENCE_QUERY_CLOCK_FAILED", "negative monotonic clock"); }
    return static_cast<std::uint64_t>(value);
}
struct CursorSecret final {
    std::array<unsigned char, 32> bytes{};
    CursorSecret() { checked(RAND_priv_bytes(bytes.data(), static_cast<int>(bytes.size()))); }
    ~CursorSecret() { OPENSSL_cleanse(bytes.data(), bytes.size()); }
    CursorSecret(const CursorSecret&) = delete;
    CursorSecret& operator=(const CursorSecret&) = delete;
};
datacube::Digest32 cursor_mac(const datacube::OctetView bytes) {
    // Separate-purpose, process-local secret. Thread-safe initialization; no
    // cursor key is persisted, exported, or derived from the state/TLS key.
    static const CursorSecret secret;
    std::unique_ptr<EVP_MAC, decltype(&EVP_MAC_free)> algorithm(
        EVP_MAC_fetch(nullptr, "HMAC", nullptr), EVP_MAC_free);
    if (!algorithm) { app_fail("EVIDENCE_QUERY_CRYPTO_FAILED", "HMAC unavailable"); }
    std::unique_ptr<EVP_MAC_CTX, decltype(&EVP_MAC_CTX_free)> ctx(
        EVP_MAC_CTX_new(algorithm.get()), EVP_MAC_CTX_free);
    if (!ctx) { app_fail("EVIDENCE_QUERY_CRYPTO_FAILED", "HMAC context unavailable"); }
    char digest[] = "SHA256";
    OSSL_PARAM params[] = {
        OSSL_PARAM_construct_utf8_string(OSSL_MAC_PARAM_DIGEST, digest, 0U),
        OSSL_PARAM_construct_end()};
    checked(EVP_MAC_init(ctx.get(), secret.bytes.data(), secret.bytes.size(), params));
    constexpr std::string_view domain = "NATRAV_OVERLAY_EVIDENCE_CURSOR_V1";
    checked(EVP_MAC_update(ctx.get(), reinterpret_cast<const unsigned char*>(domain.data()), domain.size()));
    checked(EVP_MAC_update(ctx.get(), bytes.data(), bytes.size()));
    datacube::Digest32 tag{};
    std::size_t length = 0U;
    checked(EVP_MAC_final(ctx.get(), tag.octets.data(), &length, tag.octets.size()));
    if (length != tag.octets.size()) { app_fail("EVIDENCE_QUERY_CRYPTO_FAILED", "wrong HMAC length"); }
    return tag;
}
void text16(datacube::Octets& out, const std::string_view value) {
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}
std::string text16(datacube::Reader& reader, const std::size_t limit) {
    const auto size = reader.read_be16("query string length");
    if (size > limit) { app_fail("EVIDENCE_QUERY_INVALID", "query string exceeds its bound"); }
    return datacube::octets_text(reader.read_exact(size, "query string"), "query string", true);
}
datacube::Digest32 read_digest(datacube::Reader& reader) {
    datacube::Digest32 digest{};
    const auto bytes = reader.read_exact(digest.octets.size(), "query digest");
    std::copy(bytes.begin(), bytes.end(), digest.octets.begin());
    return digest;
}
datacube::Octets query_spec(const EvidenceQuery& query) {
    datacube::Octets bytes;
    datacube::append_text(bytes, "NEQ1");
    datacube::append_u8(bytes, query.history ? 1U : 0U);
    datacube::append_u8(bytes, query.include_payload ? 1U : 0U);
    text16(bytes, query.issuer);
    text16(bytes, query.scope);
    datacube::append_u8(bytes, query.operation_id ? 1U : 0U);
    if (query.operation_id) { datacube::append_octets(bytes, query.operation_id->octets); }
    datacube::append_be32(bytes, query.maximum_records);
    datacube::append_be32(bytes, query.maximum_response_bytes);
    datacube::append_be32(bytes, query.payload_offset);
    datacube::append_be32(bytes, query.payload_length);
    return bytes;
}
struct CursorPosition final {
    datacube::Digest32 root;
    std::uint64_t after{0U};
    std::uint64_t expires_ms{0U};
};
CursorPosition open_cursor(const EvidenceQuery& query, const EvidenceQueryContext& context,
    const datacube::Digest32& specification) {
    datacube::Octets bytes;
    bytes.reserve(kScopedCursorBytes);
    auto nibble = [](const char ch) -> std::uint8_t {
        if (ch >= '0' && ch <= '9') { return static_cast<std::uint8_t>(ch - '0'); }
        if (ch >= 'a' && ch <= 'f') { return static_cast<std::uint8_t>(ch - 'a' + 10); }
        app_fail("EVIDENCE_CURSOR_INVALID", "cursor must be canonical lowercase hexadecimal");
    };
    for (std::size_t index = 0U; index < query.cursor.size(); index += 2U) {
        bytes.push_back(static_cast<std::uint8_t>(nibble(query.cursor[index]) * 16U + nibble(query.cursor[index + 1U])));
    }
    const auto body_bytes = bytes.size() - 32U;
    const auto expected = cursor_mac(datacube::OctetView(bytes).first(body_bytes));
    if (CRYPTO_memcmp(expected.octets.data(), bytes.data() + body_bytes, 32U) != 0) {
        app_fail("EVIDENCE_CURSOR_INVALID", "cursor authentication failed or issuing process restarted");
    }
    datacube::Reader reader(datacube::OctetView(bytes).first(body_bytes), "evidence cursor");
    const auto magic = datacube::octets_text(reader.read_exact(4U, "cursor magic"), "cursor magic", true);
    const bool scoped = magic == "NEC2";
    if ((magic != "NEC1" && !scoped) ||
        bytes.size() != (scoped ? kScopedCursorBytes : kCursorBytes)) {
        app_fail("EVIDENCE_CURSOR_INVALID", "unknown cursor version");
    }
    const auto uid = reader.read_be32("cursor UID");
    const auto spec = read_digest(reader);
    const auto root = read_digest(reader);
    const auto config = read_digest(reader);
    const auto read_policy = scoped ? read_digest(reader) : datacube::Digest32{};
    const auto after = reader.read_be64("cursor position");
    const auto expires = reader.read_be64("cursor expiry");
    reader.require_eof("cursor");
    if (uid != context.uid || spec != specification || config != context.configuration_digest ||
        scoped != context.read_access.scoped || (scoped && read_policy != context.read_access.digest)) {
        app_fail("EVIDENCE_CURSOR_CONTEXT_MISMATCH", "cursor principal, query, read policy, or accepted configuration changed");
    }
    if (after == 0U) { app_fail("EVIDENCE_CURSOR_INVALID", "cursor position must be positive"); }
    if (monotonic_ms() >= expires) { app_fail("EVIDENCE_CURSOR_EXPIRED", "cursor lifetime elapsed; restart query"); }
    return CursorPosition{.root = root, .after = after, .expires_ms = expires};
}
std::string seal_cursor(const EvidenceQueryContext& context,
    const datacube::Digest32& specification, const CursorPosition& position) {
    datacube::Octets bytes;
    bytes.reserve(kScopedCursorBytes);
    datacube::append_text(bytes, context.read_access.scoped ? "NEC2" : "NEC1");
    datacube::append_be32(bytes, context.uid);
    datacube::append_octets(bytes, specification.octets);
    datacube::append_octets(bytes, position.root.octets);
    datacube::append_octets(bytes, context.configuration_digest.octets);
    if (context.read_access.scoped) { datacube::append_octets(bytes, context.read_access.digest.octets); }
    datacube::append_be64(bytes, position.after);
    datacube::append_be64(bytes, position.expires_ms);
    const auto tag = cursor_mac(bytes);
    datacube::append_octets(bytes, tag.octets);
    return hex_bytes(bytes);
}
bool matches(const StoredInbound& entry, const EvidenceQuery& query) {
    return (query.history || !entry.superseded_by) &&
        (query.issuer.empty() || entry.record.issuer == query.issuer) &&
        (query.scope.empty() || entry.record.scope == query.scope) &&
        (!query.operation_id || entry.record.operation_id == *query.operation_id);
}
std::string metadata(const StoredInbound& entry, const std::uint64_t position) {
    const auto& record = entry.record;
    std::string result = "{\"sequence\":" + std::to_string(position) +
        ",\"operation_id\":" + json_string(operation_id_text(record.operation_id)) +
        ",\"issuer\":" + json_string(record.issuer) +
        ",\"recipient\":" + json_string(record.recipient) +
        ",\"scope\":" + json_string(record.scope) +
        ",\"record_digest\":" + json_string(datacube::hex_lower(entry.record_digest)) +
        ",\"payload_size\":" + std::to_string(record.payload.size()) +
        ",\"corrects\":" + (record.corrects ? json_string(operation_id_text(*record.corrects)) : "null") +
        ",\"superseded_by\":" + (entry.superseded_by ? json_string(operation_id_text(*entry.superseded_by)) : "null") +
        ",\"authorization\":";
    if (entry.authorization) {
        const auto& auth = *entry.authorization;
        result += "{\"peer_node\":" + json_string(auth.peer_node) +
            ",\"peer_generation\":" + json_string(auth.peer_generation) +
            ",\"policy_digest\":" + json_string(datacube::hex_lower(auth.policy_digest)) +
            ",\"rule_digest\":" + (auth.rule_digest ? json_string(datacube::hex_lower(*auth.rule_digest)) : "null") +
            ",\"decided_unix_ms\":" + std::to_string(auth.decided_unix_ms) + "}";
    } else { result += "null"; }
    if (entry.local_authorship) { result += ",\"local_authorship\":" + local_authorship_json(*entry.local_authorship); }
    if (entry.subscribed_source) { result += ",\"subscribed_source\":" + subscribed_source_json(*entry.subscribed_source); }
    return result + "}";
}
} // namespace

void validate_evidence_query(const EvidenceQuery& query) {
    if ((!query.issuer.empty() && !valid_node_id(query.issuer)) ||
        (!query.scope.empty() && !valid_scope(query.scope)) ||
        (query.operation_id && digest_is_zero(*query.operation_id)) ||
        query.maximum_records == 0U || query.maximum_records > 128U ||
        query.maximum_response_bytes < 4'096U || query.maximum_response_bytes > 60'000U ||
        query.payload_offset > kMaximumEvidencePayloadBytes || query.payload_length > 16'384U ||
        (query.include_payload && query.payload_length == 0U) ||
        (!query.include_payload && (query.payload_offset != 0U || query.payload_length != 0U)) ||
        (query.payload_offset != 0U && !query.operation_id)) {
        app_fail("EVIDENCE_QUERY_INVALID", "query filter or resource bound is invalid");
    }
    if (!query.cursor.empty() && query.cursor.size() != kCursorBytes * 2U && query.cursor.size() != kScopedCursorBytes * 2U) {
        app_fail("EVIDENCE_CURSOR_INVALID", "cursor length is invalid");
    }
}
datacube::Octets encode_evidence_query(const EvidenceQuery& query) {
    validate_evidence_query(query);
    auto bytes = query_spec(query);
    text16(bytes, query.cursor);
    return bytes;
}
EvidenceQuery decode_evidence_query(const datacube::OctetView bytes) {
    datacube::Reader reader(bytes, "evidence query");
    if (datacube::octets_text(reader.read_exact(4U, "query magic"), "query magic", true) != "NEQ1") {
        app_fail("EVIDENCE_QUERY_INVALID", "unknown query version");
    }
    const auto history = reader.read_u8("query view");
    const auto payload = reader.read_u8("query payload mode");
    if (history > 1U || payload > 1U) { app_fail("EVIDENCE_QUERY_INVALID", "invalid query mode"); }
    EvidenceQuery query;
    query.history = history != 0U;
    query.include_payload = payload != 0U;
    query.issuer = text16(reader, 64U);
    query.scope = text16(reader, 128U);
    const auto has_operation = reader.read_u8("query operation selector");
    if (has_operation > 1U) { app_fail("EVIDENCE_QUERY_INVALID", "invalid operation selector"); }
    if (has_operation != 0U) { query.operation_id = read_digest(reader); }
    query.maximum_records = reader.read_be32("query record limit");
    query.maximum_response_bytes = reader.read_be32("query response limit");
    query.payload_offset = reader.read_be32("query payload offset");
    query.payload_length = reader.read_be32("query payload length");
    query.cursor = text16(reader, kScopedCursorBytes * 2U);
    reader.require_eof("evidence query");
    validate_evidence_query(query);
    return query;
}

std::string NodeState::query_evidence(const EvidenceQuery& query, const EvidenceQueryContext& context) const {
    validate_evidence_query(query);
    const auto spec = datacube::sha256(query_spec(query));
    std::optional<CursorPosition> cursor;
    if (!query.cursor.empty()) { cursor = open_cursor(query, context, spec); }
    // Each page is coherent, but a cold root is computed in bounded metadata
    // batches. Hashing full selections no longer monopolizes the state mutex.
    // No payloads, full selections, cursor tables or snapshots are cached.
    std::unique_lock<std::mutex> lock(mutex_);
    const bool scoped = context.read_access.scoped;
    if (!context.read_access.metadata_allowed ||
        (query.include_payload && !context.read_access.payload_allowed)) {
        app_fail("LOCAL_CONTROL_CLASS_DENIED", "read class is not authorized");
    }
    const auto ready = [&]() {
        if (poisoned_) { app_fail("STATE_UNAVAILABLE", "state writer requires restart"); }
        if (std::chrono::steady_clock::now() >= context.deadline) {
            app_fail("EVIDENCE_QUERY_DEADLINE", "query construction exceeded the control deadline");
        }
    };
    ready();
    const auto eligible = [&](const StoredInbound& entry) {
        return evidence_read_allows(context.read_access, entry.record.issuer,
            entry.record.scope, query.include_payload) && matches(entry, query);
    };
    const auto matching_grant = [&](const EvidenceReadGrant& grant) {
        return (!query.include_payload || grant.payload) &&
            (query.issuer.empty() || query.issuer == grant.issuer) &&
            (query.scope.empty() || query.scope == grant.scope);
    };
    const auto exact_index = [&]() -> std::optional<std::size_t> {
        const auto found = inbound_index_.find(operation_id_text(*query.operation_id));
        if (found != inbound_index_.end() && eligible(inbound_[found->second])) { return found->second; }
        return std::nullopt;
    };
    // Inbound history is append-only. A correction changes its predecessor's
    // metadata only in the same exact domain, and increases that domain's size.
    // Thus the sum of selected DOMAIN history sizes is a monotonic invalidation
    // version. Hidden admissions cannot perturb it. Exact queries instead use
    // only the selected operation or its single correction child's sequence.
    const auto selection_version = [&]() -> std::uint64_t {
        if (query.operation_id) {
            const auto index = exact_index();
            if (!index) { return 0U; }
            const auto& entry = inbound_[*index];
            return entry.superseded_by ?
                inbound_[inbound_index_.at(operation_id_text(*entry.superseded_by))].sequence : entry.sequence;
        }
        if (!scoped) { return static_cast<std::uint64_t>(inbound_.size()); }
        std::uint64_t version = 0U;
        for (const auto& grant : context.read_access.grants) {
            if (!matching_grant(grant)) { continue; }
            const auto found = inbound_domain_index_.find({grant.issuer, grant.scope});
            if (found != inbound_domain_index_.end()) {
                version += static_cast<std::uint64_t>(found->second.size(true));
            }
        }
        return version;
    };
    const auto version = selection_version();
    std::vector<const EvidenceOrderedIndex*> domains;
    if (!query.operation_id) {
        if (scoped) {
            domains.reserve(context.read_access.grants.size());
            for (const auto& grant : context.read_access.grants) {
                if (!matching_grant(grant)) { continue; }
                const auto found = inbound_domain_index_.find({grant.issuer, grant.scope});
                if (found != inbound_domain_index_.end()) { domains.push_back(&found->second); }
            }
        } else { domains.push_back(&inbound_order_index_); }
    }
    struct CandidateBatch final {
        std::vector<std::size_t> indices;
        std::size_t next{0U}; // exclusive global index; never serialized to a scoped reader
        bool exhausted{true};
    };
    std::uint64_t visited = 0U;
    const auto batch = [&](const std::size_t after, const std::size_t maximum) {
        CandidateBatch result{.indices = {}, .next = after, .exhausted = true};
        result.indices.reserve(maximum);
        if (query.operation_id) {
            const auto index = exact_index();
            if (index && *index >= after) {
                result.indices.push_back(*index); result.next = *index + 1U; ++visited;
            }
            return result;
        }
        struct Head final { std::size_t index; std::size_t domain; std::size_t ordinal; };
        const auto greater = [](const Head& a, const Head& b) { return a.index > b.index; };
        std::priority_queue<Head, std::vector<Head>, decltype(greater)> heads(greater);
        for (std::size_t i = 0U; i < domains.size(); ++i) {
            const auto ordinal = domains[i]->before(after, query.history);
            if (ordinal < domains[i]->size(query.history)) {
                heads.push(Head{.index = domains[i]->at(ordinal, query.history), .domain = i, .ordinal = ordinal});
            }
        }
        std::size_t steps = 0U;
        while (!heads.empty() && steps < maximum) {
            auto head = heads.top(); heads.pop();
            ++steps; ++visited; result.next = head.index + 1U;
            if (eligible(inbound_[head.index])) { result.indices.push_back(head.index); }
            ++head.ordinal;
            if (head.ordinal < domains[head.domain]->size(query.history)) {
                head.index = domains[head.domain]->at(head.ordinal, query.history); heads.push(head);
            }
        }
        result.exhausted = heads.empty();
        return result;
    };
    const auto unchanged = [&]() {
        ready();
        if (selection_version() != version) {
            app_fail("EVIDENCE_QUERY_CHANGED", "selected domain changed while building a page; restart query");
        }
    };
    datacube::Octets seed;
    datacube::append_text(seed, scoped ? "NATRAV_OVERLAY_EVIDENCE_SELECTION_V2" : "NATRAV_OVERLAY_EVIDENCE_SELECTION_V1");
    text16(seed, node_id_);
    datacube::append_u8(seed, query.history ? 1U : 0U);
    text16(seed, query.issuer); text16(seed, query.scope);
    datacube::append_u8(seed, query.operation_id ? 1U : 0U);
    if (query.operation_id) { datacube::append_octets(seed, query.operation_id->octets); }
    if (scoped) {
        datacube::append_octets(seed, context.read_access.digest.octets);
        datacube::append_u8(seed, query.include_payload ? 1U : 0U);
    }
    auto root = datacube::sha256(seed);
    datacube::Octets cache_material;
    datacube::append_text(cache_material, "NATRAV_OVERLAY_EVIDENCE_ROOT_CACHE_V1");
    datacube::append_octets(cache_material, root.octets);
    datacube::append_octets(cache_material, context.read_access.digest.octets);
    const auto cache_key = datacube::sha256(cache_material);
    std::uint64_t selected = 0U;
    std::uint64_t hashed = 0U;
    std::uint64_t root_batches = 0U;
    const auto cached = evidence_root_cache_.get(cache_key, version);
    if (cached) { root = cached->root; selected = cached->selected; }
    else {
        std::size_t offset = 0U;
        for (;;) {
            const auto chunk = batch(offset, kRootBatchRecords);
            std::vector<std::string> leaves;
            leaves.reserve(chunk.indices.size());
            for (const auto index : chunk.indices) {
                const auto& entry = inbound_[index];
                leaves.push_back(metadata(entry, scoped ? ++selected : entry.sequence));
                if (!scoped) { ++selected; }
            }
            ++root_batches;
            // For small selections keep the original single-lock behavior.
            // Between larger batches, payload writers and maintenance proceed.
            if (!chunk.exhausted) {
                lock.unlock();
                // Explicit, bounded local-laboratory scheduling seam. It never
                // changes authority, content, keys or validation decisions.
                if (root_batches == 1U) {
                    const char* pause = std::getenv("NATRAV_OVERLAY_TEST_QUERY_AFTER_BATCH_MS");
                    if (pause && *pause != '\0') {
                        const auto delay = parse_u64(pause, "query batch pause", 1U, 2000U);
                        std::cerr << "EVIDENCE_QUERY_TEST_BATCH_UNLOCKED\n" << std::flush;
                        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
                    }
                }
            }
            for (const auto& leaf : leaves) {
                datacube::Octets chain(root.octets.begin(), root.octets.end());
                datacube::append_be32(chain, static_cast<std::uint32_t>(leaf.size()));
                datacube::append_text(chain, leaf);
                root = datacube::sha256(chain); ++hashed;
            }
            if (!chunk.exhausted) { lock.lock(); }
            unchanged();
            if (chunk.exhausted) { break; }
            offset = chunk.next;
        }
        evidence_root_cache_.put(EvidenceRootCacheEntry{
            .key = cache_key, .version = version, .root = root, .selected = selected, .used = 0U});
    }
    if (cursor && cursor->root != root) {
        app_fail("EVIDENCE_CURSOR_STALE", "selected evidence changed; restart query from its first page");
    }
    const auto after = cursor ? cursor->after : 0U;
    std::size_t offset = 0U;
    if (cursor) {
        if (scoped) {
            if (after > selected) { app_fail("EVIDENCE_CURSOR_STALE", "cursor rank is outside the selection"); }
            if (query.operation_id) {
                const auto index = exact_index();
                if (!index || after != 1U) { app_fail("EVIDENCE_CURSOR_STALE", "exact cursor anchor absent"); }
                offset = *index + 1U;
            } else if (domains.size() == 1U) {
                offset = domains.front()->at(static_cast<std::size_t>(after - 1U), query.history) + 1U;
            } else {
                // Select the requested union rank without walking preceding
                // pages or putting a hidden global offset in the cursor.
                std::size_t low = 0U, high = inbound_.size();
                while (low < high) {
                    const auto middle = low + (high - low) / 2U;
                    std::uint64_t rank = 0U;
                    for (const auto* domain : domains) { rank += domain->before(middle + 1U, query.history); }
                    if (rank < after) { low = middle + 1U; } else { high = middle; }
                }
                offset = low + 1U;
            }
        } else {
            if (after > inbound_.size() || !eligible(inbound_[static_cast<std::size_t>(after - 1U)])) {
                app_fail("EVIDENCE_CURSOR_STALE", "cursor anchor is absent");
            }
            offset = static_cast<std::size_t>(after);
        }
    }
    std::uint64_t last = after;
    std::size_t count = 0U;
    bool more = false;
    bool stop = false;
    std::string rows;
    const auto row_budget = static_cast<std::size_t>(query.maximum_response_bytes) - kEnvelopeReserve;
    std::uint64_t ordinal = after;
    // A V10 page visits only granted domain entries, including at most one
    // bounded lookahead chunk. Legacy node-wide filtered queries may skip more.
    while (!stop && selected != 0U) {
        const auto chunk = batch(offset, std::min(kRootBatchRecords,
            static_cast<std::size_t>(query.maximum_records) - count + 1U));
        for (const auto index : chunk.indices) {
            const auto& entry = inbound_[index];
            const auto position = scoped ? ++ordinal : entry.sequence;
            if (count >= query.maximum_records) { more = true; stop = true; break; }
            auto row = metadata(entry, position);
            std::size_t payload_count = 0U;
            if (query.include_payload) {
                if (query.payload_offset > entry.record.payload.size()) {
                    app_fail("EVIDENCE_PAYLOAD_RANGE", "offset exceeds the selected payload length");
                }
                payload_count = std::min<std::size_t>(query.payload_length,
                    entry.record.payload.size() - query.payload_offset);
            }
            const auto estimated = row.size() + (query.include_payload ? payload_count * 2U + 160U : 0U) + 1U;
            if (estimated > row_budget - rows.size()) {
                if (count == 0U) { app_fail("EVIDENCE_QUERY_PAGE_TOO_SMALL", "increase max-bytes or reduce payload-length; no record was skipped"); }
                more = true; stop = true; break;
            }
            if (query.include_payload) {
                row.pop_back();
                row += ",\"payload_offset\":" + std::to_string(query.payload_offset) +
                    ",\"payload_returned_bytes\":" + std::to_string(payload_count) +
                    ",\"payload_more\":" + (query.payload_offset + payload_count < entry.record.payload.size() ? "true" : "false") +
                    ",\"payload_hex\":" + json_string(hex_bytes(datacube::OctetView(entry.record.payload).subspan(query.payload_offset, payload_count))) + "}";
            }
            if (count != 0U) { rows += ','; }
            rows += row; ++count; last = position;
        }
        if (stop || chunk.exhausted) { break; }
        offset = chunk.next;
        // Do not monopolize the mutex when legacy filters skip a large gap.
        lock.unlock(); lock.lock(); unchanged();
    }
    const auto expires = cursor ? cursor->expires_ms : monotonic_ms() + kCursorLifetimeMs;
    std::string next = "null";
    if (more) { next = json_string(seal_cursor(context, spec, CursorPosition{.root=root, .after=last, .expires_ms=expires})); }
    auto result = std::string("{\"format\":") +
        json_string(scoped ? "NATRAV_OVERLAY_EVIDENCE_QUERY_V2" : "NATRAV_OVERLAY_EVIDENCE_QUERY_V1") + ",\"ok\":true" +
        ",\"node\":" + json_string(node_id_) +
        ",\"view\":" + json_string(query.history ? "history" : "current") +
        ",\"issuer_filter\":" + (query.issuer.empty() ? "null" : json_string(query.issuer)) +
        ",\"scope_filter\":" + (query.scope.empty() ? "null" : json_string(query.scope)) +
        ",\"operation_filter\":" + (query.operation_id ? json_string(operation_id_text(*query.operation_id)) : "null") +
        ",\"selection_digest\":" + json_string(datacube::hex_lower(root)) +
        ",\"query_digest\":" + json_string(datacube::hex_lower(spec)) +
        ",\"configuration_generation\":" + json_string(context.configuration_generation) +
        ",\"configuration_digest\":" + json_string(datacube::hex_lower(context.configuration_digest)) +
        ",\"selected_records\":" + std::to_string(selected) +
        ",\"returned_records\":" + std::to_string(count) +
        ",\"payload_included\":" + (query.include_payload ? "true" : "false") +
        ",\"cursor_scope\":\"PROCESS_LOCAL_300_SECONDS\",\"next_cursor\":" + next +
        ",\"records\":[" + rows + "]}";
    if (scoped) {
        result.pop_back();
        result += ",\"read_policy_digest\":" + json_string(datacube::hex_lower(context.read_access.digest)) +
            ",\"read_authority\":\"EXACT_UID_ISSUER_SCOPE\",\"sequence_semantics\":\"AUTHORIZED_SELECTION_ORDINAL\"}";
    }
    result.pop_back();
    result += ",\"query_work\":{\"root_cache_hit\":" + std::string(cached ? "true" : "false") +
        ",\"root_records_hashed\":" + std::to_string(hashed) +
        ",\"index_records_visited\":" + std::to_string(visited) +
        ",\"root_batches\":" + std::to_string(root_batches) +
        ",\"maximum_batch_records\":" + std::to_string(kRootBatchRecords) +
        ",\"maximum_root_cache_entries\":" + std::to_string(EvidenceRootCache::capacity) + "}}";
    // Reserve for the existing kernel-principal response annotation as well.
    if (result.size() + 512U > query.maximum_response_bytes) {
        app_fail("EVIDENCE_QUERY_RESPONSE_LIMIT", "encoded query exceeded its response bound");
    }
    return result;
}
} // namespace natrav_overlay
