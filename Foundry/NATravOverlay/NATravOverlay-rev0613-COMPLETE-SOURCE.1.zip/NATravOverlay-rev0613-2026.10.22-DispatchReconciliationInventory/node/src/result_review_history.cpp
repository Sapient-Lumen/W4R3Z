#include "result_review.hpp"
#include "config.hpp"
#include "journal.hpp"
#include "submission_work.hpp"

#include <algorithm>
#include <chrono>

namespace natrav_overlay {
namespace {
using Digest = datacube::Digest32;
using Bytes = datacube::Octets;
using View = datacube::OctetView;
void require(bool test, std::string_view code, std::string_view detail) {
    if (!test) app_fail(code, detail);
}
void put_digest(Bytes& out, const Digest& d) { datacube::append_octets(out, d.octets); }
Digest get_digest(datacube::Reader& rd) {
    Digest d{}; const auto b = rd.read_exact(32U, "digest");
    std::copy(b.begin(), b.end(), d.octets.begin()); return d;
}
void put_text(Bytes& out, std::string_view value) {
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}
std::string get_text(datacube::Reader& rd, std::size_t maximum) {
    const auto n = rd.read_be16("text size");
    require(n > 0U && n <= maximum, "RESULT_REVIEW_HISTORY_INVALID", "invalid text bound");
    return datacube::octets_text(rd.read_exact(n, "text"), "text", true);
}
bool flag(datacube::Reader& rd) {
    const auto f = rd.read_u8("optional flag");
    require(f <= 1U, "RESULT_REVIEW_HISTORY_INVALID", "invalid optional flag"); return f != 0U;
}
Digest hash(std::string_view domain, View material) {
    Bytes b; datacube::append_text(b, domain); datacube::append_u8(b, 0U);
    datacube::append_octets(b, material); return datacube::sha256(b);
}
Digest seed(std::string_view node, std::uint32_t uid, const ResultReviewHistory& q) {
    Bytes b; put_text(b, node); datacube::append_be32(b, uid);
    put_digest(b, q.request_operation_id); put_text(b, q.provider); put_text(b, q.scope);
    datacube::append_u8(b, q.review_id ? 1U : 0U); if (q.review_id) put_digest(b, *q.review_id);
    return hash("NATRAV_OVERLAY_RESULT_REVIEW_HISTORY_SEED_V1", b);
}
Digest link(const Digest& previous, std::uint64_t ordinal, const Digest& id, const Digest& item) {
    Bytes b; put_digest(b, previous); datacube::append_be64(b, ordinal);
    put_digest(b, id); put_digest(b, item);
    return hash("NATRAV_OVERLAY_RESULT_REVIEW_HISTORY_LINK_V1", b);
}
std::string hex(const Digest& d) { return json_string(datacube::hex_lower(d)); }
std::string conclusion(const ResultReviewRecord& r, const ResultReviewHistoryEntry& i) {
    return r.candidates.empty() ? "NO_CANDIDATES" : i.consistent == 0U ? "NO_CONSISTENT_REPORTS" :
        i.consistent == 1U ? "UNIQUE_AUTHENTICATED_REPORT" : "CONFLICTING_REPORTS";
}
std::string row_json(const ResultReviewRecord& r, const ResultReviewHistoryEntry& i, std::size_t ordinal) {
    // Immutable summary only. Current candidate/key/configuration comparisons
    // remain a separate exact-status operation; no candidate rows are copied.
    return "{\"ordinal\":" + std::to_string(ordinal) + ",\"review_id\":" + hex(r.id) +
        ",\"record_digest\":" + hex(i.record_digest) + ",\"request_operation_id\":" + hex(r.request.request_operation_id) +
        ",\"provider\":" + json_string(r.request.provider) + ",\"scope\":" + json_string(r.request.scope) +
        ",\"uid\":" + std::to_string(r.uid) + ",\"gid\":" + std::to_string(r.gid) + ",\"pid\":" + std::to_string(r.pid) +
        ",\"unix_ms\":" + std::to_string(r.unix_ms) + ",\"configuration_event\":" + std::to_string(r.configuration_event) +
        ",\"configuration_digest\":" + hex(r.request.configuration) + ",\"reason_bytes\":" + std::to_string(r.request.reason.size()) +
        ",\"reason_digest\":" + hex(i.reason_digest) + ",\"candidate_count\":" + std::to_string(r.request.candidate_count) +
        ",\"candidate_root\":" + hex(r.request.candidate_root) + ",\"request_binding\":" + hex(r.request.request_binding) +
        ",\"reviewed_provider_generation\":" + json_string(r.original_generation) + ",\"reviewed_provider_spki\":" + hex(r.original_spki) +
        ",\"reviewed_receipt_present\":" + (r.original_receipt ? "true" : "false") +
        ",\"conclusion\":" + json_string(conclusion(r, i)) + ",\"consistent\":" + std::to_string(i.consistent) +
        ",\"invalid\":" + std::to_string(r.request.candidate_count - i.consistent) + ",\"unique_operation_id\":" +
        (i.unique_operation ? hex(*i.unique_operation) : "null") + "}";
}
} // namespace

void validate_result_review_history(const ResultReviewHistory& q) {
    require(!digest_is_zero(q.request_operation_id) && valid_node_id(q.provider) && valid_scope(q.scope) &&
        q.scope != kCounterAddActionScope && (!q.review_id || !digest_is_zero(*q.review_id)) &&
        q.limit >= 1U && q.limit <= kResultReviewUidLimit && q.maximum_bytes >= 2048U && q.maximum_bytes <= 60000U &&
        q.offset <= kResultReviewUidLimit && (!q.through || *q.through <= kResultReviewUidLimit) &&
        (!q.prefix || !digest_is_zero(*q.prefix)), "RESULT_REVIEW_HISTORY_INVALID", "invalid exact selector or page bound");
    require(q.through.has_value() == q.prefix.has_value() && (q.offset == 0U || q.through),
        "RESULT_REVIEW_HISTORY_PREFIX_REQUIRED", "continuation requires through and prefix digest");
}
Bytes encode_result_review_history(const ResultReviewHistory& q) {
    validate_result_review_history(q); Bytes b; datacube::append_text(b, "RRH1");
    put_digest(b, q.request_operation_id); put_text(b, q.provider); put_text(b, q.scope);
    datacube::append_u8(b, q.review_id ? 1U : 0U); if (q.review_id) put_digest(b, *q.review_id);
    datacube::append_be64(b, q.offset); datacube::append_be32(b, q.limit); datacube::append_be32(b, q.maximum_bytes);
    datacube::append_u8(b, q.through ? 1U : 0U);
    if (q.through) { datacube::append_be64(b, *q.through); put_digest(b, *q.prefix); }
    return b;
}
ResultReviewHistory decode_result_review_history(View bytes) {
    try {
        datacube::Reader rd(bytes, "result review history");
        require(datacube::octets_text(rd.read_exact(4U, "magic"), "magic", true) == "RRH1",
            "RESULT_REVIEW_HISTORY_INVALID", "unknown request version");
        ResultReviewHistory q;
        q.request_operation_id = get_digest(rd); q.provider = get_text(rd, 64U); q.scope = get_text(rd, 128U);
        if (flag(rd)) q.review_id = get_digest(rd);
        q.offset = rd.read_be64("offset"); q.limit = rd.read_be32("limit"); q.maximum_bytes = rd.read_be32("max bytes");
        if (flag(rd)) { q.through = rd.read_be64("through"); q.prefix = get_digest(rd); }
        rd.require_eof("review history"); validate_result_review_history(q); return q;
    } catch (const datacube::Failure&) { app_fail("RESULT_REVIEW_HISTORY_INVALID", "truncated or malformed request"); }
}

void NodeState::index_result_review_locked(View validated_record) {
    require(!result_reviews_.empty(), "JOURNAL_CORRUPT", "missing validated review");
    const auto& r = result_reviews_.back();
    const ReviewHistoryKey key{r.uid, r.request.provider, r.request.scope, datacube::hex_lower(r.request.request_operation_id)};
    auto& group = result_review_history_[key];
    require(group.size() < kResultReviewUidLimit, "JOURNAL_CORRUPT", "review history bound");
    ResultReviewHistory q;
    q.request_operation_id = r.request.request_operation_id; q.provider = r.request.provider; q.scope = r.request.scope;
    ResultReviewHistoryEntry item;
    item.record_index = result_reviews_.size() - 1U;
    item.record_digest = datacube::sha256(validated_record);
    item.reason_digest = datacube::sha256(datacube::text_octets(r.request.reason));
    for (const auto& c : r.candidates) {
        if (c.rejection.empty()) { ++item.consistent; item.unique_operation = c.operation; }
    }
    if (item.consistent != 1U) item.unique_operation.reset();
    item.prefix = link(group.empty() ? seed(node_id_, r.uid, q) : group.back().prefix,
        static_cast<std::uint64_t>(group.size() + 1U), r.id, item.record_digest);
    group.push_back(std::move(item));
}

std::string NodeState::result_review_history(const ResultReviewHistory& q, const RuntimeConfig& config,
    std::uint32_t uid, std::chrono::steady_clock::time_point deadline) const {
    validate_result_review_history(q);
    // Check domain authority before ANY registry lookup, including empty/exact
    // results. A prefix never grants authority and cannot expand this domain.
    const auto access = evidence_read_access(config.evidence_read, config.local_control, uid);
    require(config.format_version >= 8U && local_control_allows(config.local_control, uid, LocalControlClass::inspect) &&
        evidence_read_allows(access, q.provider, q.scope, true), "RESULT_REVIEW_PERMISSION_DENIED",
        "current inspection and exact payload-read authority required");
    const auto cfg = runtime_configuration_digest(canonical_runtime_config(config));
    const auto check_time = [&] {
        require(std::chrono::steady_clock::now() < deadline, "RESULT_REVIEW_HISTORY_DEADLINE", "page deadline elapsed");
    };
    check_time(); std::lock_guard<std::mutex> lock(mutex_); check_time();
    require(!poisoned_, "STATE_RESTART_REQUIRED", "restart failed writer");
    SubmissionWork work; SubmissionWorkScope measure(work);
    const ReviewHistoryKey key{uid, q.provider, q.scope, datacube::hex_lower(q.request_operation_id)};
    const auto found = result_review_history_.find(key);
    const auto* group = found == result_review_history_.end() ? nullptr : &found->second;
    std::size_t exact = 0U, comparisons = 0U;
    bool exact_found = false;
    if (q.review_id && group) {
        for (std::size_t n = 0U; n < group->size(); ++n) {
            ++comparisons;
            if (result_reviews_[(*group)[n].record_index].id == *q.review_id) { exact = n; exact_found = true; break; }
        }
    }
    const std::size_t available = q.review_id ? (exact_found ? 1U : 0U) : (group ? group->size() : 0U);
    const auto through = q.through.value_or(static_cast<std::uint64_t>(available));
    require(through <= available, "RESULT_REVIEW_HISTORY_PREFIX_UNAVAILABLE", "selected owned prefix is not retained");
    const auto empty = seed(node_id_, uid, q);
    Digest prefix = empty;
    if (through != 0U) {
        const auto& last = (*group)[q.review_id ? exact : static_cast<std::size_t>(through - 1U)];
        prefix = q.review_id ? link(empty, 1U, result_reviews_[last.record_index].id, last.record_digest) : last.prefix;
    }
    require(!q.prefix || *q.prefix == prefix, "RESULT_REVIEW_HISTORY_PREFIX_MISMATCH", "selected owned review history differs");
    require(q.offset <= through, "RESULT_REVIEW_HISTORY_INVALID", "offset exceeds selected prefix");
    std::size_t returned = 0U, visited = 0U; std::string rows;
    const auto render = [&](std::string_view content, std::size_t count) {
        const auto next = q.offset + static_cast<std::uint64_t>(count);
        return std::string("{\"format\":\"NATRAV_OVERLAY_RESULT_REVIEW_HISTORY_V1\",\"ok\":true") +
            ",\"node\":" + json_string(node_id_) + ",\"uid\":" + std::to_string(uid) +
            ",\"request_operation_id\":" + hex(q.request_operation_id) + ",\"provider\":" + json_string(q.provider) +
            ",\"scope\":" + json_string(q.scope) + ",\"review_filter\":" + (q.review_id ? hex(*q.review_id) : "null") +
            ",\"authorized_configuration_digest\":" + hex(cfg) + ",\"retained_selected_total\":" + std::to_string(available) +
            ",\"through\":" + std::to_string(through) + ",\"prefix_digest\":" + hex(prefix) +
            ",\"offset\":" + std::to_string(q.offset) + ",\"returned\":" + std::to_string(count) +
            ",\"next_offset\":" + std::to_string(next) + ",\"has_more\":" + (next < through ? "true" : "false") +
            ",\"sequence_semantics\":\"OWNED_EXACT_SELECTION_ORDINAL\",\"comparison_mode\":\"STORED_ONLY_USE_REVIEW_STATUS\"" +
            ",\"execution_verified_locally\":false,\"freshness\":\"NOT_ESTABLISHED\"" +
            ",\"work\":{\"scope\":\"LOCKED_REVIEW_HISTORY_PAGE\",\"metadata_rows_visited\":" + std::to_string(visited) +
            ",\"exact_filter_comparisons\":" + std::to_string(comparisons) +
            ",\"candidate_validations\":0,\"historical_configurations_parsed\":0,\"review_record_bytes_serialized\":0" +
            ",\"snapshot_calls\":" + std::to_string(work.snapshot_calls) +
            ",\"snapshot_payload_bytes\":" + std::to_string(work.snapshot_evidence_payload_bytes) +
            ",\"logical_bytes_serialized\":" + std::to_string(work.snapshot_logical_bytes) + "},\"records\":[" + std::string(content) + "]}";
    };
    for (auto n = q.offset; n < through && returned < q.limit; ++n) {
        check_time(); ++visited;
        const auto& item = (*group)[q.review_id ? exact : static_cast<std::size_t>(n)];
        const auto& r = result_reviews_[item.record_index];
        const auto row = row_json(r, item, static_cast<std::size_t>(n + 1U));
        const auto trial = rows + (rows.empty() ? "" : ",") + row;
        if (render(trial, returned + 1U).size() + 384U > q.maximum_bytes) {
            require(returned != 0U, "RESULT_REVIEW_HISTORY_PAGE_TOO_SMALL", "first complete summary exceeds byte limit");
            break;
        }
        rows = trial; ++returned;
    }
    auto out = render(rows, returned);
    require(out.size() + 384U <= q.maximum_bytes, "RESULT_REVIEW_HISTORY_PAGE_TOO_SMALL", "metadata exceeds byte limit");
    check_time(); return out;
}
} // namespace natrav_overlay
