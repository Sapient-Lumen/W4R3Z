#pragma once

#include "common.hpp"

namespace natrav_overlay {

struct CustodyCommand final {
    std::string command;
    std::filesystem::path config;
    std::filesystem::path route;
    std::filesystem::path capsule;
    std::filesystem::path input;
    std::filesystem::path output;
    std::filesystem::path key_directory;
    datacube::Digest32 envelope_sha256{};
    bool has_envelope_sha256{false};
    std::uint64_t created_ms{0U};
    std::uint64_t expires_ms{0U};
    std::string code;
    std::string detail;
};

[[nodiscard]] std::string run_custody_command(
    const CustodyCommand& options);

} // namespace natrav_overlay
