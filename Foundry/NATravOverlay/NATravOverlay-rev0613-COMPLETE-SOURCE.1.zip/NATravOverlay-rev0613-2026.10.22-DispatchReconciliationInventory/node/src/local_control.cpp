#include "local_control.hpp"

#include <algorithm>
#include <array>
#include <limits>
#include <set>
#include <string>
#include <utility>

namespace natrav_overlay {
namespace {

inline constexpr std::array<LocalControlClass, 14> kClasses{
    LocalControlClass::inspect,
    LocalControlClass::submit,
    LocalControlClass::action,
    LocalControlClass::maintenance,
    LocalControlClass::configuration,
    LocalControlClass::shutdown,
    LocalControlClass::evidence_read,
    LocalControlClass::evidence_payload,
    LocalControlClass::consumer,
    LocalControlClass::consumer_admin,
    LocalControlClass::projection,
    LocalControlClass::evidence_author,
    LocalControlClass::source_disclose,
    LocalControlClass::source_import,
};

[[nodiscard]] std::vector<std::string_view> split(const std::string_view value) {
    std::vector<std::string_view> parts;
    std::size_t begin = 0U;
    while (true) {
        const auto comma = value.find(',', begin);
        if (comma == std::string_view::npos) {
            parts.push_back(value.substr(begin));
            return parts;
        }
        parts.push_back(value.substr(begin, comma - begin));
        begin = comma + 1U;
    }
}

[[nodiscard]] std::uint32_t all_permissions() noexcept {
    std::uint32_t value = 0U;
    for (const auto command_class : kClasses) {
        // ALL is permanently the six legacy administrative classes. Evidence
        // access must always be explicitly granted, including in newer formats.
        if (command_class <= LocalControlClass::shutdown) {
            value |= local_control_permission(command_class);
        }
    }
    return value;
}

}  // namespace

std::uint32_t local_control_permission(
    const LocalControlClass command_class) noexcept {
    const auto bit = static_cast<std::uint8_t>(command_class) - 1U;
    return static_cast<std::uint32_t>(1U) << bit;
}

std::string_view local_control_class_name(
    const LocalControlClass command_class) noexcept {
    switch (command_class) {
        case LocalControlClass::inspect: return "INSPECT";
        case LocalControlClass::submit: return "SUBMIT";
        case LocalControlClass::action: return "ACTION";
        case LocalControlClass::maintenance: return "MAINTENANCE";
        case LocalControlClass::configuration: return "CONFIGURATION";
        case LocalControlClass::shutdown: return "SHUTDOWN";
        case LocalControlClass::evidence_read: return "EVIDENCE_READ";
        case LocalControlClass::evidence_payload: return "EVIDENCE_PAYLOAD";
        case LocalControlClass::consumer: return "CONSUMER";
        case LocalControlClass::consumer_admin: return "CONSUMER_ADMIN";
        case LocalControlClass::projection: return "PROJECTION";
        case LocalControlClass::evidence_author: return "EVIDENCE_AUTHOR";
        case LocalControlClass::source_disclose: return "SOURCE_DISCLOSE";
        case LocalControlClass::source_import: return "SOURCE_IMPORT";
    }
    return "UNKNOWN";
}

LocalControlClass parse_local_control_class(const std::string_view value) {
    for (const auto command_class : kClasses) {
        if (value == local_control_class_name(command_class)) {
            return command_class;
        }
    }
    app_fail("CONFIG_LOCAL_CONTROL_CLASS_INVALID",
        "local control class must be INSPECT, SUBMIT, ACTION, MAINTENANCE, CONFIGURATION, SHUTDOWN, EVIDENCE_READ, EVIDENCE_PAYLOAD, CONSUMER, CONSUMER_ADMIN, PROJECTION, or EVIDENCE_AUTHOR");
}

LocalControlGrant parse_local_control_grant(const std::string_view value) {
    const auto fields = split(value);
    if (fields.size() < 2U || fields.size() > 14U) {
        app_fail("CONFIG_LOCAL_CONTROL_INVALID",
            "local_control requires UID and one or more command classes");
    }
    const auto uid_value = parse_u64(
        fields.front(), "local control UID", 0U,
        static_cast<std::uint64_t>(std::numeric_limits<std::uint32_t>::max()));
    std::uint32_t permissions = 0U;
    bool all = false;
    for (std::size_t index = 1U; index < fields.size(); ++index) {
        if (fields[index].empty()) {
            app_fail("CONFIG_LOCAL_CONTROL_INVALID", "local control fields cannot be empty");
        }
        if (fields[index] == "ALL") {
            if (fields.size() != 2U) {
                app_fail("CONFIG_LOCAL_CONTROL_INVALID", "ALL must be the only local control class");
            }
            permissions = all_permissions();
            all = true;
            break;
        }
        const auto bit = local_control_permission(parse_local_control_class(fields[index]));
        if ((permissions & bit) != 0U) {
            app_fail("CONFIG_LOCAL_CONTROL_DUPLICATE_CLASS",
                std::string(fields[index]));
        }
        permissions |= bit;
    }
    if (!all && permissions == 0U) {
        app_fail("CONFIG_LOCAL_CONTROL_INVALID", "local control grant is empty");
    }
    return LocalControlGrant{
        .uid = static_cast<std::uint32_t>(uid_value),
        .permissions = permissions,
    };
}

LocalControlPolicy make_local_control_policy(
    std::vector<LocalControlGrant> grants,
    const bool legacy_owner_default) {
    if (grants.empty() || grants.size() > 64U) {
        app_fail("CONFIG_LOCAL_CONTROL_LIMIT",
            "local control policy requires 1..64 exact UID grants");
    }
    std::sort(grants.begin(), grants.end(), [](const auto& left, const auto& right) {
        return left.uid < right.uid;
    });
    for (std::size_t index = 0U; index < grants.size(); ++index) {
        if (grants[index].permissions == 0U ||
            (index != 0U && grants[index - 1U].uid == grants[index].uid)) {
            app_fail("CONFIG_LOCAL_CONTROL_DUPLICATE_UID",
                std::to_string(grants[index].uid));
        }
    }
    datacube::Octets canonical;
    datacube::append_text(canonical, "NATRAV_OVERLAY_LOCAL_CONTROL_POLICY_V1");
    datacube::append_u8(canonical, 0U);
    datacube::append_be32(canonical, static_cast<std::uint32_t>(grants.size()));
    for (const auto& grant : grants) {
        datacube::append_be32(canonical, grant.uid);
        datacube::append_be32(canonical, grant.permissions);
    }
    return LocalControlPolicy{
        .grants = std::move(grants),
        .digest = datacube::sha256(canonical),
        .legacy_owner_default = legacy_owner_default,
    };
}

LocalControlPolicy owner_local_control_policy(const std::uint32_t uid) {
    return make_local_control_policy(
        {LocalControlGrant{.uid = uid, .permissions = all_permissions()}}, true);
}

bool local_control_allows(
    const LocalControlPolicy& policy,
    const std::uint32_t uid,
    const LocalControlClass command_class) noexcept {
    const auto found = std::lower_bound(
        policy.grants.begin(), policy.grants.end(), uid,
        [](const LocalControlGrant& grant, const std::uint32_t candidate) {
            return grant.uid < candidate;
        });
    return found != policy.grants.end() && found->uid == uid &&
        (found->permissions & local_control_permission(command_class)) != 0U;
}

std::string local_control_grant_text(const LocalControlGrant& grant) {
    std::string out = std::to_string(grant.uid);
    const auto all = all_permissions();
    if (grant.permissions == all) {
        return out + ",ALL";
    }
    for (const auto command_class : kClasses) {
        if ((grant.permissions & local_control_permission(command_class)) != 0U) {
            out += ',';
            out += local_control_class_name(command_class);
        }
    }
    return out;
}

std::string local_control_policy_json(const LocalControlPolicy& policy) {
    std::string out = "{\"format\":\"NATRAV_OVERLAY_LOCAL_CONTROL_POLICY_V1\"";
    out += ",\"digest\":" + json_string(datacube::hex_lower(policy.digest));
    out += ",\"legacy_owner_default\":" +
        std::string(policy.legacy_owner_default ? "true" : "false");
    out += ",\"grants\":[";
    for (std::size_t index = 0U; index < policy.grants.size(); ++index) {
        if (index != 0U) { out += ','; }
        const auto& grant = policy.grants[index];
        out += "{\"uid\":" + std::to_string(grant.uid) + ",\"classes\":[";
        bool first = true;
        for (const auto command_class : kClasses) {
            if ((grant.permissions & local_control_permission(command_class)) == 0U) {
                continue;
            }
            if (!first) { out += ','; }
            first = false;
            out += json_string(local_control_class_name(command_class));
        }
        out += "]}";
    }
    return out + "]}";
}

}  // namespace natrav_overlay
