#pragma once
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
namespace natrav_overlay {
struct RuntimePeerCounts final {
    std::uint64_t pending{0}, acked{0}, rejected{0}, cancelled{0}, expired{0}, unresolved{0};
    std::uint64_t reserved_records{0}, reserved_payload_bytes{0};
    std::uint64_t future_result_records{0}, future_result_payload_bytes{0};
};
struct RuntimeStatusWork final {
    std::uint64_t outbox_metadata_records{0}, action_metadata_records{0}, transitions{0};
    std::uint64_t aggregate_reads{0}, binding_lookups{0}, rejection_tail_reads{0};
    std::uint64_t logical_bytes_serialized{0}, logical_digest_computations{0};
    std::uint64_t snapshot_calls{0}, snapshot_payload_bytes{0};
};
// One coherent state observation. Live runtime counters are sampled separately.
// No evidence objects, payloads, full registry values or canonical histories escape.
struct RuntimeStatusMetadata final {
    std::string fields;
    std::string actions;
    std::map<std::string, RuntimePeerCounts> peers;
    std::size_t lifecycle_events{0}, local_control_events{0};
    std::size_t projection_schedules{0}, publication_channels{0};
    bool configuration_state_match{false};
    std::string authorized_configuration_digest;
    RuntimeStatusWork work;
};
[[nodiscard]] std::string runtime_status_work_json(const RuntimeStatusWork& work);
} // namespace natrav_overlay
