#pragma once

#include "common.hpp"

#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

enum class LocalControlClass : std::uint8_t {
    inspect = 1U,
    submit = 2U,
    action = 3U,
    maintenance = 4U,
    configuration = 5U,
    shutdown = 6U,
    evidence_read = 7U,
    evidence_payload = 8U,
    consumer = 9U,
    consumer_admin = 10U,
    projection = 11U,
    evidence_author = 12U,
    source_disclose = 13U,
    source_import = 14U,
};

struct LocalControlGrant final {
    std::uint32_t uid{0U};
    std::uint32_t permissions{0U};

    bool operator==(const LocalControlGrant&) const = default;
};

struct LocalControlPolicy final {
    std::vector<LocalControlGrant> grants;
    datacube::Digest32 digest;
    bool legacy_owner_default{false};

    bool operator==(const LocalControlPolicy&) const = default;
};

[[nodiscard]] std::uint32_t local_control_permission(
    LocalControlClass command_class) noexcept;
[[nodiscard]] std::string_view local_control_class_name(
    LocalControlClass command_class) noexcept;
[[nodiscard]] LocalControlClass parse_local_control_class(std::string_view value);
[[nodiscard]] LocalControlGrant parse_local_control_grant(std::string_view value);
[[nodiscard]] LocalControlPolicy make_local_control_policy(
    std::vector<LocalControlGrant> grants,
    bool legacy_owner_default);
[[nodiscard]] LocalControlPolicy owner_local_control_policy(std::uint32_t uid);
[[nodiscard]] bool local_control_allows(
    const LocalControlPolicy& policy,
    std::uint32_t uid,
    LocalControlClass command_class) noexcept;
[[nodiscard]] std::string local_control_grant_text(const LocalControlGrant& grant);
[[nodiscard]] std::string local_control_policy_json(const LocalControlPolicy& policy);

}  // namespace natrav_overlay
