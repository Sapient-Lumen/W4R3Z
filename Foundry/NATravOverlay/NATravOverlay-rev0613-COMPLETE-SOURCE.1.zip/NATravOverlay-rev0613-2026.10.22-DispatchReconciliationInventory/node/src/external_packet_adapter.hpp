#pragma once

#include "adapter_profile.hpp"
#include "packet_port.hpp"

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <memory>
#include <optional>
#include <string>
#include <vector>

namespace natrav_overlay {

inline constexpr char kSupervisedExternalPacketAdapterMarker[] =
    "SUPERVISED_EXTERNAL_PACKET_ADAPTER_V1";
[[nodiscard]] int supervised_external_packet_adapter_revision_abi() noexcept;

struct ExternalPacketAdapterCapabilities final {
    std::uint32_t profile{0U};
    std::size_t mtu{0U};
    std::size_t max_frame_bytes{0U};
    std::size_t max_queued_bytes{0U};
    std::uint32_t max_outstanding_requests{0U};

    friend bool operator==(
        const ExternalPacketAdapterCapabilities&,
        const ExternalPacketAdapterCapabilities&) = default;
};

enum class ExternalPacketAdapterEventKind : std::uint8_t {
    launch_attempt = 1U,
    launch_ready = 2U,
    request_sent = 3U,
    response_received = 4U,
    child_exit = 5U,
    protocol_failure = 6U,
    graceful_shutdown = 7U,
    forced_termination = 8U,
};

struct ExternalPacketAdapterEvent final {
    ExternalPacketAdapterEventKind kind{
        ExternalPacketAdapterEventKind::launch_attempt};
    std::uint64_t sequence{0U};
    std::uint32_t frame_type{0U};
    std::uint32_t status{0U};
    std::uint32_t payload_bytes{0U};
    std::int64_t process_id{0};

    friend bool operator==(
        const ExternalPacketAdapterEvent&,
        const ExternalPacketAdapterEvent&) = default;
};

struct ExternalPacketAdapterSnapshot final {
    ExternalPacketAdapterCapabilities capabilities{};
    std::string pinned_profile_id{};
    std::uint64_t pinned_profile_generation{0U};
    AdapterSha256 pinned_profile_sha256{};
    AdapterSha256 executable_sha256{};
    bool running{false};
    std::int64_t process_id{0};
    std::size_t launch_attempts{0U};
    std::size_t restarts{0U};
    std::size_t requests_sent{0U};
    std::size_t responses_received{0U};
    std::size_t transmitted_packets{0U};
    std::size_t received_packets{0U};
    std::size_t busy_responses{0U};
    // Counted exactly once when the supervised protocol endpoint becomes
    // terminal. The matching event status is UINT32_MAX when EOF/HUP arrives
    // before waitpid can expose the child wait status.
    std::size_t child_exits{0U};
    std::size_t protocol_failures{0U};
    std::size_t dropped_evidence_events{0U};
    std::vector<ExternalPacketAdapterEvent> events{};
};

struct ExternalPacketAdapterOptions final {
    // When populated, these two fields prove that every launch and restart
    // consumes the exact operator-authorized profile and sealed executable
    // image. The empty state remains available only to the private revision-0589
    // fixture API; configured persistent routes must use the profile factory.
    std::optional<OperatorPinnedAdapterProfile> pinned_profile{};
    AdapterSha256 pinned_profile_sha256{};
    std::shared_ptr<const VerifiedAdapterExecutable> verified_executable{};
    // Caller may tighten, never extend, the bounded profile startup budget.
    Deadline launch_deadline{Deadline::max()};
    std::filesystem::path executable;
    std::vector<std::string> arguments{};
    std::size_t requested_mtu{512U};
    std::uint32_t profile{1U};
    std::size_t max_frame_bytes{65'536U};
    std::size_t max_queued_bytes{1'048'576U};
    std::uint32_t max_outstanding_requests{1U};
    std::size_t max_evidence_events{256U};
    std::uint32_t max_launch_attempts{3U};
    std::chrono::milliseconds startup_timeout{2'000};
    std::chrono::milliseconds request_timeout{500};
    std::chrono::milliseconds shutdown_timeout{500};
    std::chrono::milliseconds initial_restart_backoff{10};
    std::chrono::milliseconds maximum_restart_backoff{250};
};

struct SupervisedExternalPacketAdapter;

class SupervisedExternalPacketAdapterControl final {
public:
    struct State;

    SupervisedExternalPacketAdapterControl(
        const SupervisedExternalPacketAdapterControl&) = delete;
    SupervisedExternalPacketAdapterControl& operator=(
        const SupervisedExternalPacketAdapterControl&) = delete;
    ~SupervisedExternalPacketAdapterControl();

    [[nodiscard]] ExternalPacketAdapterSnapshot snapshot() const;

private:
    explicit SupervisedExternalPacketAdapterControl(
        std::shared_ptr<State> state) noexcept;
    std::shared_ptr<State> state_;

    friend struct SupervisedExternalPacketAdapter;
    friend SupervisedExternalPacketAdapter
    make_supervised_external_packet_adapter(ExternalPacketAdapterOptions options);
};

struct SupervisedExternalPacketAdapter final {
    std::unique_ptr<OwnedCompleteDatagramPacketPort> port;
    std::shared_ptr<SupervisedExternalPacketAdapterControl> control;
};

// Converts one validated durable profile into immutable launch options and
// seals the exact approved executable bytes. Callers should retain and reuse
// the returned options across bounded carrier restarts.
[[nodiscard]] ExternalPacketAdapterOptions
external_packet_adapter_options_from_profile(
    const OperatorPinnedAdapterProfile& profile);

// Launches one explicitly selected adapter process. The child receives only
// standard descriptors redirected to /dev/null plus the full-duplex
// SOCK_SEQPACKET protocol endpoint at descriptor 3. The adapter may exchange
// bounded datagrams and capabilities; all peer identity and authority remain
// above this boundary.
[[nodiscard]] SupervisedExternalPacketAdapter
make_supervised_external_packet_adapter(ExternalPacketAdapterOptions options);

}  // namespace natrav_overlay
