#include "config.hpp"
#include "udp_transport.hpp"
#include "unix_datagram_transport.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <cerrno>
#include <fcntl.h>
#include <map>
#include <set>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <unistd.h>
#include <utility>

namespace natrav_overlay {
namespace {

inline constexpr std::string_view kHeader = "NATRAV_OVERLAY_CONFIG_V6";
inline constexpr std::string_view kHeaderV7 = "NATRAV_OVERLAY_CONFIG_V7";
inline constexpr std::string_view kHeaderV8 = "NATRAV_OVERLAY_CONFIG_V8";
inline constexpr std::string_view kHeaderV9 = "NATRAV_OVERLAY_CONFIG_V9";
inline constexpr std::string_view kHeaderV11 = "NATRAV_OVERLAY_CONFIG_V11";
inline constexpr std::string_view kHeaderV12 = "NATRAV_OVERLAY_CONFIG_V12";
inline constexpr std::string_view kHeaderV13 = "NATRAV_OVERLAY_CONFIG_V13";
inline constexpr std::string_view kHeaderV14 = "NATRAV_OVERLAY_CONFIG_V14";
inline constexpr std::string_view kHeaderV15 = "NATRAV_OVERLAY_CONFIG_V15";
inline constexpr std::string_view kHeaderV16 = "NATRAV_OVERLAY_CONFIG_V16";
inline constexpr std::string_view kHeaderV17 = "NATRAV_OVERLAY_CONFIG_V17";
inline constexpr std::string_view kHeaderV18 = "NATRAV_OVERLAY_CONFIG_V18";
inline constexpr std::string_view kHeaderV19 = "NATRAV_OVERLAY_CONFIG_V19";
inline constexpr std::string_view kHeaderV20 = "NATRAV_OVERLAY_CONFIG_V20";
inline constexpr std::string_view kHeaderV21 = "NATRAV_OVERLAY_CONFIG_V21";
inline constexpr std::string_view kHeaderV22 = "NATRAV_OVERLAY_CONFIG_V22";
inline constexpr std::string_view kHeaderV23 = "NATRAV_OVERLAY_CONFIG_V23";
inline constexpr std::string_view kHeaderV24 = "NATRAV_OVERLAY_CONFIG_V24";
inline constexpr std::string_view kHeaderV10 = "NATRAV_OVERLAY_CONFIG_V10";
inline constexpr std::size_t kMaximumConfigBytes = 65'536U;
inline constexpr std::size_t kMaximumPeers = 64U;
inline constexpr std::size_t kMaximumGenerationsPerNode = 8U;
inline constexpr std::size_t kMaximumRoutesPerPeer = 8U;
inline constexpr std::size_t kMaximumAuthorizationRules = 512U;

struct ParsedPeer final {
    std::string node_id;
    std::vector<PeerRouteConfig> routes;
    DeliveryPolicy delivery;
};

struct ParsedRoute final {
    std::string node_id;
    PeerRouteConfig route;
};

[[nodiscard]] datacube::Octets read_configuration_file(
    const std::filesystem::path& path) {
    const int raw = ::open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (raw < 0) {
        app_fail("CONFIG_OPEN_FAILED",
            datacube::errno_detail(path.string(), errno));
    }
    datacube::Fd fd(raw);
    struct stat status {};
    if (::fstat(fd.get(), &status) != 0) {
        app_fail("CONFIG_STAT_FAILED",
            datacube::errno_detail(path.string(), errno));
    }
    if (!S_ISREG(status.st_mode)) {
        app_fail("CONFIG_NOT_REGULAR", path.string());
    }
    if (status.st_uid != ::geteuid()) {
        app_fail("CONFIG_OWNER_INVALID",
            "configuration must be owned by the effective user");
    }
    if ((status.st_mode & (S_IWGRP | S_IWOTH)) != 0) {
        app_fail("CONFIG_PERMISSIONS_INVALID",
            "configuration must not be group- or other-writable");
    }
    if (status.st_size < 0 ||
        static_cast<std::uint64_t>(status.st_size) >
            static_cast<std::uint64_t>(kMaximumConfigBytes)) {
        app_fail("CONFIG_TOO_LARGE", path.string());
    }
    return datacube::read_all_fd(
        fd.get(), static_cast<std::uint64_t>(kMaximumConfigBytes),
        path.string());
}

[[nodiscard]] std::string_view trim(const std::string_view value) noexcept {
    std::size_t begin = 0U;
    while (begin < value.size() &&
           std::isspace(static_cast<unsigned char>(value[begin])) != 0) {
        ++begin;
    }
    std::size_t end = value.size();
    while (end > begin &&
           std::isspace(static_cast<unsigned char>(value[end - 1U])) != 0) {
        --end;
    }
    return value.substr(begin, end - begin);
}

[[nodiscard]] std::vector<std::string_view> split(
    const std::string_view value,
    const char separator) {
    std::vector<std::string_view> parts;
    std::size_t begin = 0U;
    while (true) {
        const auto position = value.find(separator, begin);
        if (position == std::string_view::npos) {
            parts.push_back(trim(value.substr(begin)));
            break;
        }
        parts.push_back(trim(value.substr(begin, position - begin)));
        begin = position + 1U;
    }
    return parts;
}

[[nodiscard]] bool valid_control_name(const std::string_view value) noexcept {
    if (value.empty() || value.size() > 80U || value == "." || value == "..") {
        return false;
    }
    return std::all_of(value.begin(), value.end(), [](const char raw) {
        const auto ch = static_cast<unsigned char>(raw);
        return (ch >= static_cast<unsigned char>('A') &&
                ch <= static_cast<unsigned char>('Z')) ||
            (ch >= static_cast<unsigned char>('a') &&
             ch <= static_cast<unsigned char>('z')) ||
            (ch >= static_cast<unsigned char>('0') &&
             ch <= static_cast<unsigned char>('9')) ||
            ch == static_cast<unsigned char>('.') ||
            ch == static_cast<unsigned char>('_') ||
            ch == static_cast<unsigned char>('-');
    });
}

[[nodiscard]] std::string singleton(
    const std::map<std::string, std::string>& values,
    const std::string& key,
    std::string default_value) {
    const auto found = values.find(key);
    return found == values.end() ? std::move(default_value) : found->second;
}

[[nodiscard]] std::size_t size_option(
    const std::map<std::string, std::string>& values,
    const std::string& key,
    const std::string_view default_value,
    const std::uint64_t minimum,
    const std::uint64_t maximum) {
    return static_cast<std::size_t>(parse_u64(
        singleton(values, key, std::string(default_value)),
        key, minimum, maximum));
}

[[nodiscard]] bool valid_route_id(const std::string_view value) noexcept {
    if (value.empty() || value.size() > 32U || value == "." || value == "..") {
        return false;
    }
    return std::all_of(value.begin(), value.end(), [](const char raw) {
        const auto ch = static_cast<unsigned char>(raw);
        return (ch >= static_cast<unsigned char>('A') &&
                ch <= static_cast<unsigned char>('Z')) ||
            (ch >= static_cast<unsigned char>('a') &&
             ch <= static_cast<unsigned char>('z')) ||
            (ch >= static_cast<unsigned char>('0') &&
             ch <= static_cast<unsigned char>('9')) ||
            ch == static_cast<unsigned char>('.') ||
            ch == static_cast<unsigned char>('_') ||
            ch == static_cast<unsigned char>('-');
    });
}

[[nodiscard]] PeerRouteState parse_route_state(const std::string_view value) {
    if (value == "ENABLED") { return PeerRouteState::enabled; }
    if (value == "DISABLED") { return PeerRouteState::disabled; }
    app_fail("CONFIG_PEER_ROUTE_STATE_INVALID",
        "peer_route state must be ENABLED or DISABLED");
}

[[nodiscard]] ParsedPeer parse_peer(
    const std::string_view value,
    const std::uint32_t format_version) {
    const auto fields = split(value, ',');
    const std::size_t expected = format_version >= 13U ? 5U : 6U;
    if (fields.size() != expected) {
        app_fail("CONFIG_PEER_INVALID",
            format_version >= 13U ?
                "V13 peer requires ID,INITIAL_MS,MAX_MS,ATTEMPTS,EXPIRY_MS" :
                "peer requires ID,ENDPOINT,INITIAL_MS,MAX_MS,ATTEMPTS,EXPIRY_MS");
    }
    for (const auto field : fields) {
        if (field.empty()) {
            app_fail("CONFIG_PEER_INVALID", "peer fields cannot be empty");
        }
    }
    require_node_id(fields[0], "peer node ID");
    const std::size_t offset = format_version >= 13U ? 1U : 2U;
    const auto initial = parse_u64(
        fields[offset], "peer initial backoff", 10U, 600'000U);
    const auto maximum = parse_u64(
        fields[offset + 1U], "peer maximum backoff", initial, 3'600'000U);
    const auto attempts = parse_u64(
        fields[offset + 2U], "peer maximum attempts", 1U, 1'000U);
    const auto expiry = parse_u64(
        fields[offset + 3U], "peer expiry", 100U, 2'592'000'000U);
    ParsedPeer result{
        .node_id = std::string(fields[0]),
        .routes = {},
        .delivery = DeliveryPolicy{
            .initial_backoff_ms = static_cast<std::uint32_t>(initial),
            .maximum_backoff_ms = static_cast<std::uint32_t>(maximum),
            .maximum_attempts = static_cast<std::uint32_t>(attempts),
            .expiry_ms = expiry,
        },
    };
    if (format_version < 13U) {
        result.routes.push_back(PeerRouteConfig{
            .route_id = "primary",
            .locator = parse_tcp_transport_locator(fields[1], false),
            .priority = 0U,
            .state = PeerRouteState::enabled,
        });
    }
    return result;
}

[[nodiscard]] ParsedRoute parse_peer_route(const std::string_view value) {
    const auto fields = split(value, ',');
    if (fields.size() != 5U) {
        app_fail("CONFIG_PEER_ROUTE_INVALID",
            "peer_route requires PEER,ROUTE_ID,PRIORITY,STATE,ENDPOINT");
    }
    for (const auto field : fields) {
        if (field.empty()) {
            app_fail("CONFIG_PEER_ROUTE_INVALID",
                "peer_route fields cannot be empty");
        }
    }
    require_node_id(fields[0], "peer route node ID");
    if (!valid_route_id(fields[1])) {
        app_fail("CONFIG_PEER_ROUTE_ID_INVALID",
            "route ID must be 1..32 safe ASCII characters");
    }
    return ParsedRoute{
        .node_id = std::string(fields[0]),
        .route = PeerRouteConfig{
            .route_id = std::string(fields[1]),
            .locator = parse_configured_transport_locator(fields[4], false),
            .priority = static_cast<std::uint32_t>(parse_u64(
                fields[2], "peer route priority", 0U, 1'000'000U)),
            .state = parse_route_state(fields[3]),
        },
    };
}

[[nodiscard]] KeyGenerationState parse_generation_state(
    const std::string_view value) {
    if (value == "ACTIVE") { return KeyGenerationState::active; }
    if (value == "RETIRED") { return KeyGenerationState::retired; }
    if (value == "REVOKED") { return KeyGenerationState::revoked; }
    app_fail("CONFIG_KEY_STATE_INVALID",
        "peer_key state must be ACTIVE, RETIRED, or REVOKED");
}

[[nodiscard]] PeerKeyGeneration parse_peer_key(
    const std::string_view value) {
    const auto fields = split(value, ',');
    if (fields.size() != 4U) {
        app_fail("CONFIG_PEER_KEY_INVALID",
            "peer_key requires ID,GENERATION,STATE,SPKI_SHA256");
    }
    for (const auto field : fields) {
        if (field.empty()) {
            app_fail("CONFIG_PEER_KEY_INVALID",
                "peer_key fields cannot be empty");
        }
    }
    require_node_id(fields[0], "peer key node ID");
    require_generation_id(fields[1], "peer key generation");
    return PeerKeyGeneration{
        .node_id = std::string(fields[0]),
        .generation = std::string(fields[1]),
        .state = parse_generation_state(fields[2]),
        .spki_sha256 = parse_spki_sha256(fields[3]),
    };
}

[[nodiscard]] AuthorizationRule parse_authorization_rule(
    const std::string_view value) {
    const auto fields = split(value, ',');
    if (fields.size() != 4U) {
        app_fail("CONFIG_AUTHORIZATION_INVALID",
            "authorize requires PEER,GENERATION_OR_STAR,CLASS,RESOURCE");
    }
    for (const auto field : fields) {
        if (field.empty()) {
            app_fail("CONFIG_AUTHORIZATION_INVALID",
                "authorization fields cannot be empty");
        }
    }
    require_node_id(fields[0], "authorization peer");
    std::optional<std::string> generation;
    if (fields[1] != "*") {
        require_generation_id(fields[1], "authorization generation");
        generation = std::string(fields[1]);
    }
    AuthorizedOperationClass operation_class;
    if (fields[2] == "EVIDENCE") {
        operation_class = AuthorizedOperationClass::evidence;
        require_scope(fields[3]);
    } else if (fields[2] == "ACTION") {
        operation_class = AuthorizedOperationClass::counter_action;
        if (fields[3] != "counter.add") {
            app_fail("CONFIG_AUTHORIZATION_INVALID",
                "the only supported ACTION resource is counter.add");
        }
    } else {
        app_fail("CONFIG_AUTHORIZATION_INVALID",
            "authorization class must be EVIDENCE or ACTION");
    }
    return AuthorizationRule{
        .peer_node = std::string(fields[0]),
        .peer_generation = std::move(generation),
        .operation_class = operation_class,
        .resource = std::string(fields[3]),
        .digest = {},
    };
}

[[nodiscard]] ActionResultRule parse_action_result_rule(
    const std::string_view value) {
    const auto fields = split(value, ',');
    if (fields.size() != 4U) {
        app_fail("CONFIG_ACTION_RESULT_INVALID",
            "action_result requires PEER,GENERATION,RESOURCE,RESULT_SCOPE");
    }
    for (const auto field : fields) {
        if (field.empty()) {
            app_fail("CONFIG_ACTION_RESULT_INVALID",
                "action-result fields cannot be empty");
        }
    }
    require_node_id(fields[0], "action-result peer");
    require_generation_id(fields[1], "action-result generation");
    if (fields[2] != "counter.add") {
        app_fail("CONFIG_ACTION_RESULT_INVALID",
            "the only supported action-result resource is counter.add");
    }
    require_scope(fields[3]);
    return ActionResultRule{
        .peer_node = std::string(fields[0]),
        .peer_generation = std::string(fields[1]),
        .resource = std::string(fields[2]),
        .result_scope = std::string(fields[3]),
        .digest = {},
    };
}

[[nodiscard]] std::filesystem::path resolve_config_path(
    const std::filesystem::path& config_path,
    const std::string_view value,
    const std::string_view field) {
    std::filesystem::path result(value);
    if (result.empty()) {
        app_fail("CONFIG_PATH_INVALID", std::string(field) + " path is empty");
    }
    if (result.is_relative()) {
        result = config_path.parent_path() / result;
    }
    return std::filesystem::absolute(result).lexically_normal();
}

}  // namespace

RuntimeConfig load_runtime_config(const std::filesystem::path& path) {
    if (path.empty()) { app_fail("CONFIG_PATH_INVALID", "configuration path is empty"); }
    const auto bytes = read_configuration_file(path);
    return parse_runtime_config(std::string_view(
        reinterpret_cast<const char*>(bytes.data()), bytes.size()), path);
}

RuntimeConfig parse_runtime_config(
    const std::string_view text,
    const std::filesystem::path& path,
    const IdentityFileValidation identity_validation) {
    if (text.size() > kMaximumConfigBytes) {
        app_fail("CONFIG_TOO_LARGE", "configuration exceeds 65536 bytes");
    }
    std::uint32_t format_version = 0U;
    if (text.find('\0') != std::string::npos) {
        app_fail("CONFIG_INVALID", "configuration contains a NUL byte");
    }

    std::map<std::string, std::string> values;
    std::vector<std::string> peer_values;
    std::vector<std::string> peer_route_values;
    std::vector<std::string> peer_key_values;
    std::vector<std::string> authorization_values;
    std::vector<std::string> action_result_values;
    std::vector<std::string> adapter_profile_values, adapter_endpoint_values, handoff_key_values, custody_grant_values, custody_session_values, custody_receiver_values, custody_dispatch_values;
    std::vector<std::string> local_control_values;
    std::vector<std::string> evidence_read_values;
    std::vector<std::string> evidence_author_values;
    std::vector<std::string> source_disclosure_values;
    std::vector<std::string> source_view_values, source_view_binding_values;
    bool header_seen = false;
    std::size_t line_number = 0U;
    std::size_t begin = 0U;
    while (begin <= text.size()) {
        const auto end = text.find('\n', begin);
        std::string_view line = end == std::string::npos ?
            std::string_view(text).substr(begin) :
            std::string_view(text).substr(begin, end - begin);
        if (!line.empty() && line.back() == '\r') {
            line.remove_suffix(1U);
        }
        ++line_number;
        line = trim(line);
        if (!line.empty() && line.front() != '#') {
            if (!header_seen) {
                if (line == kHeader) { format_version = 6U; }
                else if (line == kHeaderV7) { format_version = 7U; }
                else if (line == kHeaderV8) { format_version = 8U; }
                else if (line == kHeaderV9) { format_version = 9U; }
                else if (line == kHeaderV10) { format_version = 10U; }
                else if (line == kHeaderV11) { format_version = 11U; }
                else if (line == kHeaderV12) { format_version = 12U; }
                else if (line == kHeaderV13) { format_version = 13U; }
                else if (line == kHeaderV14) { format_version = 14U; }
                else if (line == kHeaderV15) { format_version = 15U; }
                else if (line == kHeaderV16) { format_version = 16U; }
                else if (line == kHeaderV17) { format_version = 17U; }
                else if (line == kHeaderV18) { format_version = 18U; }
                else if (line == kHeaderV19) { format_version = 19U; }
                else if (line == kHeaderV20) { format_version = 20U; }
                else if (line == kHeaderV21) { format_version = 21U; }
                else if (line == kHeaderV22) { format_version = 22U; }
                else if (line == kHeaderV23) { format_version = 23U; }
                else if (line == kHeaderV24) { format_version = 24U; }
                else {
                    app_fail("CONFIG_VERSION_REJECTED",
                        "first content line must be NATRAV_OVERLAY_CONFIG_V6 through V24");
                }
                header_seen = true;
            } else {
                const auto equal = line.find('=');
                if (equal == std::string_view::npos || equal == 0U) {
                    app_fail("CONFIG_INVALID",
                        "line " + std::to_string(line_number) + " must be key=value");
                }
                const auto key_view = trim(line.substr(0U, equal));
                const auto value_view = trim(line.substr(equal + 1U));
                if (key_view.empty() || value_view.empty()) {
                    app_fail("CONFIG_INVALID",
                        "line " + std::to_string(line_number) +
                        " has an empty key or value");
                }
                const std::string key(key_view);
                const std::string value(value_view);
                static const std::set<std::string> allowed{
                    "node", "state", "listen", "control", "deadline_ms",
                    "read_quantum", "write_quantum", "receive_limit",
                    "max_journal_bytes", "peer_workers", "peer_queue_capacity",
                    "control_workers", "control_queue_capacity", "backlog", "peer",
                    "identity_cert", "identity_key", "identity_pin",
                    "identity_generation", "peer_key", "authorize",
                    "action_result", "adapter_profile_hex", "adapter_endpoint_hex", "handoff_key_hex", "custody_grant_hex", "custody_service_hex", "custody_receiver_hex", "custody_dispatch_hex",
                    "action_counter_budget", "action_max_increment",
                    "action_max_defer_ms", "action_expiry_ms",
                    "outbox_global_max_records",
                    "outbox_global_max_payload_bytes",
                    "outbox_peer_max_records",
                    "outbox_peer_max_payload_bytes",
                    "session_max_operations", "session_max_bytes",
                    "session_max_lifetime_ms", "session_idle_timeout_ms",
                    "runtime_generation", "local_control", "evidence_read", "evidence_author", "source_disclosure", "source_view", "source_view_binding",
                    "peer_route",
                };
                if (!allowed.contains(key)) {
                    app_fail("CONFIG_UNKNOWN_FIELD", key);
                }
                if (key == "peer") {
                    peer_values.push_back(value);
                } else if (key == "peer_route") {
                    peer_route_values.push_back(value);
                } else if (key == "peer_key") {
                    peer_key_values.push_back(value);
                } else if (key == "authorize") {
                    authorization_values.push_back(value);
                } else if (key == "action_result") {
                    action_result_values.push_back(value);
                } else if (key == "handoff_key_hex") {
                    handoff_key_values.push_back(value);
                } else if (key == "custody_grant_hex") {
                    custody_grant_values.push_back(value);
                } else if (key == "custody_service_hex") {
                    custody_session_values.push_back(value);
                } else if (key == "custody_receiver_hex") {
                    custody_receiver_values.push_back(value);
                } else if (key == "custody_dispatch_hex") {
                    custody_dispatch_values.push_back(value);
                } else if (key == "adapter_profile_hex") {
                    adapter_profile_values.push_back(value);
                } else if (key == "adapter_endpoint_hex") {
                    adapter_endpoint_values.push_back(value);
                } else if (key == "local_control") {
                    local_control_values.push_back(value);
                } else if (key == "source_view") {
                    source_view_values.push_back(value);
                } else if (key == "source_view_binding") {
                    source_view_binding_values.push_back(value);
                } else if (key == "source_disclosure") {
                    source_disclosure_values.push_back(value);
                } else if (key == "evidence_author") {
                    evidence_author_values.push_back(value);
                } else if (key == "evidence_read") {
                    evidence_read_values.push_back(value);
                } else if (!values.emplace(key, value).second) {
                    app_fail("CONFIG_DUPLICATE_FIELD", key);
                }
            }
        }
        if (end == std::string::npos) {
            break;
        }
        begin = end + 1U;
    }
    if (!header_seen) {
        app_fail("CONFIG_VERSION_REJECTED", "configuration header is absent");
    }
    for (const auto* required : {
             "node", "state", "listen", "control",
             "identity_cert", "identity_key", "identity_pin",
             "identity_generation"}) {
        if (!values.contains(required)) {
            app_fail("CONFIG_MISSING_FIELD", required);
        }
    }

    RuntimeConfig config;
    config.format_version = format_version;
    if (format_version < 19U && (!adapter_profile_values.empty() || !adapter_endpoint_values.empty())) {
        app_fail("CONFIG_VERSION_REJECTED", "adapter policy records require V19");
    }
    if (adapter_profile_values.size() > kMaximumRuntimeAdapterProfiles ||
        adapter_endpoint_values.size() > kMaximumRuntimeAdapterEndpoints) {
        app_fail("CONFIG_ADAPTER_CAPACITY", "retained adapter record count exceeded");
    }
    for (const auto& value : adapter_profile_values) {
        config.adapter_configuration.profiles.push_back(parse_runtime_adapter_profile(value));
    }
    for (const auto& value : adapter_endpoint_values) {
        config.adapter_configuration.endpoints.push_back(parse_runtime_adapter_endpoint(value));
    }
    normalize_runtime_adapter_configuration(config.adapter_configuration);
    if (format_version < 20U && !handoff_key_values.empty()) {
        app_fail("CONFIG_VERSION_REJECTED", "handoff key policy requires V20");
    }
    if (handoff_key_values.size() > kHandoffPolicyRecordLimit) {
        app_fail("CONFIG_HANDOFF_CAPACITY", "retained handoff key record bound");
    }
    for (const auto& value : handoff_key_values) { config.handoff_keys.push_back(parse_handoff_key_policy(value)); }
    normalize_handoff_key_policy(config.handoff_keys);
    if (format_version < 21U && !custody_grant_values.empty()) {
        app_fail("CONFIG_VERSION_REJECTED", "custody grant policy requires V21");
    }
    if (custody_grant_values.size() > kCustodyRelayGrantLimit) {
        app_fail("CONFIG_CUSTODY_GRANT_CAPACITY", "retained custody grant bound");
    }
    for (const auto& value : custody_grant_values) {
        config.custody_relay.push_back(parse_custody_relay_grant(value));
    }
    normalize_custody_relay_policy(config.custody_relay);
    if (format_version < 22U && !custody_session_values.empty()) {
        app_fail("CONFIG_VERSION_REJECTED",
            "native custody service policy requires V22");
    }
    if (custody_session_values.size() > kCustodySessionRuleLimit) {
        app_fail("CONFIG_CUSTODY_SESSION_CAPACITY",
            "retained service-rule count exceeded");
    }
    for (const auto& value : custody_session_values) {
        config.custody_sessions.push_back(parse_custody_session_rule(value));
    }
    normalize_custody_session_policy(config.custody_sessions);
    if (format_version < 23U && !custody_receiver_values.empty()) {
        app_fail("CONFIG_VERSION_REJECTED",
            "passive daemon custody receiver policy requires V23");
    }
    if (custody_receiver_values.size() > kCustodyReceiverActivationLimit) {
        app_fail("CONFIG_CUSTODY_RECEIVER_CAPACITY",
            "retained receiver-activation count exceeded");
    }
    for (const auto& value : custody_receiver_values) {
        config.custody_receivers.push_back(
            parse_custody_receiver_activation(value));
    }
    normalize_custody_receiver_policy(config.custody_receivers);
    if (format_version < 24U && !custody_dispatch_values.empty()) {
        app_fail("CONFIG_VERSION_REJECTED",
            "explicit owner custody dispatch policy requires V24");
    }
    if (custody_dispatch_values.size() > kCustodyDispatchActivationLimit) {
        app_fail("CONFIG_CUSTODY_DISPATCH_CAPACITY",
            "retained dispatch-activation count exceeded");
    }
    for (const auto& value : custody_dispatch_values) {
        config.custody_dispatch.push_back(
            parse_custody_dispatch_activation(value));
    }
    normalize_custody_dispatch_policy(config.custody_dispatch);
    if (format_version >= 7U) {
        if (!values.contains("runtime_generation")) {
            app_fail("CONFIG_MISSING_FIELD", "runtime_generation");
        }
        config.runtime_generation = values.at("runtime_generation");
        require_generation_id(config.runtime_generation, "runtime generation");
    } else if (values.contains("runtime_generation")) {
        app_fail("CONFIG_VERSION_REJECTED", "runtime_generation requires V7 or V8");
    }
    if (format_version < 13U && !peer_route_values.empty()) {
        app_fail("CONFIG_VERSION_REJECTED", "peer_route requires V13");
    }
    if (format_version < 18U && !action_result_values.empty()) {
        app_fail("CONFIG_VERSION_REJECTED", "action_result requires V18");
    }
    if (format_version < 8U && !local_control_values.empty()) {
        app_fail("CONFIG_VERSION_REJECTED", "local_control requires V8");
    }
    if (format_version >= 8U && local_control_values.empty()) {
        app_fail("CONFIG_MISSING_FIELD", "local_control");
    }
    config.source_path = std::filesystem::absolute(path).lexically_normal();
    config.local_node = values.at("node");
    require_node_id(config.local_node, "configured node ID");
    config.local_identity_generation = values.at("identity_generation");
    require_generation_id(
        config.local_identity_generation, "local identity generation");
    if (format_version >= 8U) {
        std::vector<LocalControlGrant> grants;
        grants.reserve(local_control_values.size());
        for (const auto& value : local_control_values) {
            auto grant = parse_local_control_grant(value);
            const auto reads = local_control_permission(LocalControlClass::evidence_read);
            const auto payloads = local_control_permission(LocalControlClass::evidence_payload);
            if (format_version < 9U && (grant.permissions & (reads | payloads)) != 0U) {
                app_fail("CONFIG_VERSION_REJECTED", "evidence permissions require V9");
            }
            if ((grant.permissions & payloads) != 0U && (grant.permissions & reads) == 0U) {
                app_fail("CONFIG_EVIDENCE_READ_REQUIRED", "EVIDENCE_PAYLOAD also requires EVIDENCE_READ");
            }
            const auto consumer = local_control_permission(LocalControlClass::consumer);
            const auto admin = local_control_permission(LocalControlClass::consumer_admin);
            const auto projection = local_control_permission(LocalControlClass::projection);
            if ((grant.permissions & projection) != 0U) {
                if (format_version < 12U) { app_fail("CONFIG_VERSION_REJECTED", "PROJECTION requires V12"); }
                if ((grant.permissions & consumer) == 0U || (grant.permissions & reads) == 0U) {
                    app_fail("CONFIG_PROJECTION_PREREQUISITE", "PROJECTION requires CONSUMER and EVIDENCE_READ");
                }
            }
            if ((grant.permissions & (consumer | admin)) != 0U) {
                if (format_version < 11U) {
                    app_fail("CONFIG_VERSION_REJECTED", "consumer permissions require V11");
                }
                if ((grant.permissions & reads) == 0U ||
                    ((grant.permissions & admin) != 0U && (grant.permissions & consumer) == 0U)) {
                    app_fail("CONFIG_CONSUMER_READ_REQUIRED", "CONSUMER requires EVIDENCE_READ; CONSUMER_ADMIN also requires CONSUMER");
                }
            }
            grants.push_back(grant);
        }
        config.local_control = make_local_control_policy(std::move(grants), false);
    } else {
        config.local_control = owner_local_control_policy(
            static_cast<std::uint32_t>(::geteuid()));
    }

    config.source_disclosure = make_source_disclosure_policy(
        source_disclosure_values, config.local_control, format_version);
    config.evidence_author = make_local_author_policy(
        evidence_author_values, config.local_control, format_version >= 14U);
    config.evidence_read = make_evidence_read_policy(
        evidence_read_values, config.local_control, format_version >= 10U);

    config.state_directory = resolve_config_path(
        config.source_path, values.at("state"), "state");
    config.identity = TlsIdentityFiles{
        .certificate = resolve_config_path(
            config.source_path, values.at("identity_cert"), "identity_cert"),
        .private_key = resolve_config_path(
            config.source_path, values.at("identity_key"), "identity_key"),
        .expected_spki_sha256 = parse_spki_sha256(values.at("identity_pin")),
    };
    if (identity_validation == IdentityFileValidation::required) {
        const TlsContext checked_identity(config.identity);
        if (checked_identity.identity_spki_sha256() !=
            config.identity.expected_spki_sha256) {
            app_fail("TLS_IDENTITY_PIN_MISMATCH",
                "loaded identity does not match configured pin");
        }
    }
    const std::string control_name = values.at("control");
    if (!valid_control_name(control_name)) {
        app_fail("CONFIG_CONTROL_INVALID",
            "control must be a safe filename of at most 80 characters");
    }
    config.control_socket = config.state_directory / control_name;
    config.listen_locator = parse_configured_transport_locator(values.at("listen"), true);

    config.io.timeout = parse_milliseconds(
        singleton(values, "deadline_ms", "3000"),
        "deadline_ms", 1U, 60'000U);
    config.io.read_quantum = size_option(
        values, "read_quantum", "4096", 1U, 65'536U);
    config.io.write_quantum = size_option(
        values, "write_quantum", "4096", 1U, 65'536U);
    config.io.maximum_received_bytes = size_option(
        values, "receive_limit", "131080", 4U, 1'048'576U);
    validate_io_options(config.io);
    config.sessions = PeerSessionLimits{
        .maximum_operations = static_cast<std::uint32_t>(parse_u64(
            singleton(values, "session_max_operations", "32"),
            "session_max_operations", 1U, 1'024U)),
        .maximum_bytes = parse_u64(
            singleton(values, "session_max_bytes", "4194304"),
            "session_max_bytes",
            2U * static_cast<std::uint64_t>(
                kPeerFramePrefixBytes + kPeerSessionHeaderBytes +
                kMaximumApplicationPayloadBytes),
            kMaximumPeerSessionBytes),
        .maximum_lifetime_ms = static_cast<std::uint32_t>(parse_u64(
            singleton(values, "session_max_lifetime_ms", "30000"),
            "session_max_lifetime_ms", 100U, 600'000U)),
        .idle_timeout_ms = static_cast<std::uint32_t>(parse_u64(
            singleton(values, "session_idle_timeout_ms", "2000"),
            "session_idle_timeout_ms", 10U, 60'000U)),
    };
    validate_peer_session_limits(config.sessions);
    config.maximum_journal_bytes = parse_u64(
        singleton(values, "max_journal_bytes", "67108864"),
        "max_journal_bytes", 1'024U, 1'073'741'824U);
    config.queue_limits = QueueLimits{
        .global_max_records = parse_u64(
            singleton(values, "outbox_global_max_records", "4096"),
            "outbox_global_max_records", 1U, 1'000'000U),
        .global_max_payload_bytes = parse_u64(
            singleton(values, "outbox_global_max_payload_bytes", "67108864"),
            "outbox_global_max_payload_bytes", 1U, 1'073'741'824U),
        .peer_max_records = parse_u64(
            singleton(values, "outbox_peer_max_records", "1024"),
            "outbox_peer_max_records", 1U, 1'000'000U),
        .peer_max_payload_bytes = parse_u64(
            singleton(values, "outbox_peer_max_payload_bytes", "16777216"),
            "outbox_peer_max_payload_bytes", 1U, 1'073'741'824U),
    };
    if (config.queue_limits.peer_max_records >
            config.queue_limits.global_max_records ||
        config.queue_limits.peer_max_payload_bytes >
            config.queue_limits.global_max_payload_bytes) {
        app_fail("CONFIG_OUTBOX_LIMIT_INVALID",
            "per-peer outbox limits must not exceed global limits");
    }
    config.peer_workers = size_option(
        values, "peer_workers", "4", 1U, 32U);
    config.peer_queue_capacity = size_option(
        values, "peer_queue_capacity", "64", 1U, 4'096U);
    config.control_workers = size_option(
        values, "control_workers", "2", 1U, 16U);
    config.control_queue_capacity = size_option(
        values, "control_queue_capacity", "64", 1U, 4'096U);
    config.backlog = static_cast<int>(parse_u64(
        singleton(values, "backlog", "64"),
        "backlog", 1U, 1'024U));

    if (peer_values.size() > kMaximumPeers) {
        app_fail("CONFIG_TOO_MANY_PEERS", "at most 64 peers are supported");
    }
    if (authorization_values.size() > kMaximumAuthorizationRules) {
        app_fail("CONFIG_TOO_MANY_AUTHORIZATION_RULES",
            "at most 512 authorization rules are supported");
    }
    std::map<std::string, ParsedPeer> routes;
    for (const auto& peer_text : peer_values) {
        auto peer = parse_peer(peer_text, format_version);
        if (peer.node_id == config.local_node) {
            app_fail("CONFIG_PEER_INVALID", "local node cannot be its own peer");
        }
        if (!routes.emplace(peer.node_id, std::move(peer)).second) {
            app_fail("CONFIG_DUPLICATE_PEER", peer_text);
        }
    }
    if (peer_route_values.size() > kMaximumPeers * kMaximumRoutesPerPeer) {
        app_fail("CONFIG_TOO_MANY_PEER_ROUTES",
            "at most eight routes per each of 64 peers are supported");
    }
    if (format_version >= 13U) {
        std::set<std::pair<std::string, std::string>> route_ids;
        std::map<std::string, std::string> endpoint_assignments;
        std::map<std::string, std::string> serial_device_assignments;
        std::map<std::string, std::string> udp_local_assignments;
        std::map<std::string, std::string> unix_datagram_local_assignments;
        const std::string listener_udp_local =
            config.listen_locator.kind == TransportKind::udp ?
                udp_transport_endpoint_text(
                    udp_transport_locator(config.listen_locator).local) :
                std::string{};
        const std::string listener_unix_datagram_local =
            config.listen_locator.kind == TransportKind::unix_datagram ?
                unix_datagram_transport_locator(config.listen_locator).local_path :
                std::string{};
        for (const auto& route_text : peer_route_values) {
            auto parsed = parse_peer_route(route_text);
            const auto peer_found = routes.find(parsed.node_id);
            if (peer_found == routes.end()) {
                app_fail("CONFIG_PEER_ROUTE_PEER_UNKNOWN", parsed.node_id);
            }
            if (!route_ids.emplace(parsed.node_id, parsed.route.route_id).second) {
                app_fail("CONFIG_DUPLICATE_PEER_ROUTE",
                    parsed.node_id + "/" + parsed.route.route_id);
            }
            const auto endpoint = transport_locator_text(parsed.route.locator);
            const auto assignment = parsed.node_id + "/" + parsed.route.route_id;
            if (parsed.route.locator.kind == TransportKind::serial) {
                const auto& route_serial =
                    serial_transport_locator(parsed.route.locator);
                if (config.listen_locator.kind == TransportKind::serial &&
                    route_serial.path ==
                        serial_transport_locator(config.listen_locator).path) {
                    app_fail(
                        "CONFIG_SERIAL_ROLE_CONFLICT",
                        "one serial device cannot be both the local listener and an outbound route");
                }
                const auto [serial_found, serial_inserted] =
                    serial_device_assignments.emplace(
                        route_serial.path, assignment);
                if (!serial_inserted) {
                    app_fail(
                        "CONFIG_PEER_ROUTE_ENDPOINT_AMBIGUOUS",
                        "one serial device path is assigned to more than one route: " +
                            serial_found->second + " and " + assignment);
                }
            }
            if (parsed.route.locator.kind == TransportKind::udp) {
                const auto& route_udp = udp_transport_locator(parsed.route.locator);
                const auto local = udp_transport_endpoint_text(route_udp.local);
                const auto remote = udp_transport_endpoint_text(route_udp.remote);
                if (!listener_udp_local.empty() && local == listener_udp_local) {
                    app_fail(
                        "CONFIG_UDP_ROLE_CONFLICT",
                        "one UDP local endpoint cannot be both the listener and an outbound route");
                }
                if (!listener_udp_local.empty() && remote == listener_udp_local) {
                    app_fail(
                        "CONFIG_UDP_SELF_ROUTE",
                        "an outbound UDP route cannot target the local listener endpoint");
                }
                const auto [udp_found, udp_inserted] =
                    udp_local_assignments.emplace(local, assignment);
                if (!udp_inserted) {
                    app_fail(
                        "CONFIG_PEER_ROUTE_ENDPOINT_AMBIGUOUS",
                        "one UDP local endpoint is assigned to more than one route: " +
                            udp_found->second + " and " + assignment);
                }
            }
            if (parsed.route.locator.kind == TransportKind::unix_datagram) {
                const auto& route_unix =
                    unix_datagram_transport_locator(parsed.route.locator);
                const auto& local = route_unix.local_path;
                const auto& remote = route_unix.remote_path;
                if (!listener_unix_datagram_local.empty() &&
                    local == listener_unix_datagram_local) {
                    app_fail(
                        "CONFIG_UNIX_DATAGRAM_ROLE_CONFLICT",
                        "one Unix datagram local path cannot be both the listener and an outbound route");
                }
                if (!listener_unix_datagram_local.empty() &&
                    remote == listener_unix_datagram_local) {
                    app_fail(
                        "CONFIG_UNIX_DATAGRAM_SELF_ROUTE",
                        "an outbound Unix datagram route cannot target the local listener path");
                }
                const auto [unix_found, unix_inserted] =
                    unix_datagram_local_assignments.emplace(local, assignment);
                if (!unix_inserted) {
                    app_fail(
                        "CONFIG_PEER_ROUTE_ENDPOINT_AMBIGUOUS",
                        "one Unix datagram local path is assigned to more than one route: " +
                            unix_found->second + " and " + assignment);
                }
            }
            const auto [found, inserted] = endpoint_assignments.emplace(
                endpoint, assignment);
            if (!inserted) {
                app_fail("CONFIG_PEER_ROUTE_ENDPOINT_AMBIGUOUS",
                    "one transport locator is assigned to more than one route: " +
                    found->second + " and " + assignment);
            }
            auto& peer_routes = peer_found->second.routes;
            if (peer_routes.size() >= kMaximumRoutesPerPeer) {
                app_fail("CONFIG_TOO_MANY_PEER_ROUTES",
                    "peer " + parsed.node_id + " has more than eight routes");
            }
            peer_routes.push_back(std::move(parsed.route));
        }
        for (auto& [node, peer] : routes) {
            if (peer.routes.empty()) {
                app_fail("CONFIG_PEER_ROUTE_REQUIRED",
                    "V13 routed peer " + node + " requires at least one peer_route");
            }
            std::sort(peer.routes.begin(), peer.routes.end(),
                [](const PeerRouteConfig& left, const PeerRouteConfig& right) {
                    if (left.priority != right.priority) {
                        return left.priority < right.priority;
                    }
                    return left.route_id < right.route_id;
                });
        }
    }

    std::map<std::string, std::size_t> generation_count;
    std::set<std::pair<std::string, std::string>> generation_ids;
    std::map<std::string, std::string> assignment_by_pin;
    for (const auto& key_text : peer_key_values) {
        auto key = parse_peer_key(key_text);
        if (key.node_id == config.local_node) {
            app_fail("CONFIG_PEER_KEY_INVALID",
                "local node cannot be configured as a remote peer identity");
        }
        if (key.spki_sha256 == config.identity.expected_spki_sha256) {
            app_fail("CONFIG_PEER_KEY_INVALID",
                "local identity key cannot identify a remote peer generation");
        }
        if (!generation_ids.emplace(key.node_id, key.generation).second) {
            app_fail("CONFIG_DUPLICATE_PEER_GENERATION",
                key.node_id + "/" + key.generation);
        }
        auto& count = generation_count[key.node_id];
        ++count;
        if (count > kMaximumGenerationsPerNode) {
            app_fail("CONFIG_TOO_MANY_PEER_GENERATIONS",
                "at most eight key generations are supported per peer");
        }
        const auto pin_text = spki_sha256_text(key.spki_sha256);
        const auto assignment = key.node_id + "/" + key.generation;
        const auto [found, inserted] = assignment_by_pin.emplace(pin_text, assignment);
        if (!inserted) {
            app_fail("CONFIG_PEER_KEY_AMBIGUOUS",
                "one SPKI pin is assigned to more than one generation: " +
                found->second + " and " + assignment);
        }
        config.peer_generations.push_back(std::move(key));
    }

    std::sort(config.peer_generations.begin(), config.peer_generations.end(),
        [](const PeerKeyGeneration& left, const PeerKeyGeneration& right) {
            if (left.node_id != right.node_id) {
                return left.node_id < right.node_id;
            }
            return left.generation < right.generation;
        });

    std::vector<AuthorizationRule> authorization_rules;
    authorization_rules.reserve(authorization_values.size());
    for (const auto& authorization_text : authorization_values) {
        auto rule = parse_authorization_rule(authorization_text);
        if (rule.peer_node == config.local_node) {
            app_fail("CONFIG_AUTHORIZATION_INVALID",
                "local node cannot be an inbound authorization subject");
        }
        bool peer_present = false;
        bool usable_generation = false;
        for (const auto& key : config.peer_generations) {
            if (key.node_id != rule.peer_node) { continue; }
            peer_present = true;
            if (rule.peer_generation.has_value() &&
                key.generation != *rule.peer_generation) {
                continue;
            }
            if (key.state != KeyGenerationState::revoked) {
                usable_generation = true;
            }
        }
        if (!peer_present) {
            app_fail("CONFIG_AUTHORIZATION_PEER_UNKNOWN", rule.peer_node);
        }
        if (rule.peer_generation.has_value()) {
            const auto* generation = find_peer_generation(
                config, rule.peer_node, *rule.peer_generation);
            if (generation == nullptr) {
                app_fail("CONFIG_AUTHORIZATION_GENERATION_UNKNOWN",
                    rule.peer_node + "/" + *rule.peer_generation);
            }
            if (generation->state == KeyGenerationState::revoked) {
                app_fail("CONFIG_AUTHORIZATION_GENERATION_REVOKED",
                    rule.peer_node + "/" + *rule.peer_generation);
            }
        } else if (!usable_generation) {
            app_fail("CONFIG_AUTHORIZATION_PEER_REVOKED", rule.peer_node);
        }
        authorization_rules.push_back(std::move(rule));
    }
    const ActionLimits action_limits{
        .counter_budget = parse_u64(
            singleton(values, "action_counter_budget", "1000"),
            "action_counter_budget", 1U, 1'000'000'000'000ULL),
        .maximum_increment = parse_u64(
            singleton(values, "action_max_increment", "100"),
            "action_max_increment", 1U, 1'000'000'000'000ULL),
        .maximum_defer_ms = parse_u64(
            singleton(values, "action_max_defer_ms", "60000"),
            "action_max_defer_ms", 0U, 2'592'000'000ULL),
        .expiry_ms = parse_u64(
            singleton(values, "action_expiry_ms", "86400000"),
            "action_expiry_ms", 100U, 2'592'000'000ULL),
    };
    config.authorization = make_authorization_policy(
        std::move(authorization_rules), action_limits);
    std::vector<ActionResultRule> action_result_rules;
    action_result_rules.reserve(action_result_values.size());
    for (const auto& value : action_result_values) {
        action_result_rules.push_back(parse_action_result_rule(value));
    }
    config.action_results = make_action_result_policy(
        std::move(action_result_rules));

    for (const auto& [node, route] : routes) {
        std::vector<const PeerKeyGeneration*> active;
        for (const auto& key : config.peer_generations) {
            if (key.node_id == node && key.state == KeyGenerationState::active) {
                active.push_back(&key);
            }
        }
        if (active.size() != 1U) {
            app_fail("CONFIG_ACTIVE_GENERATION_INVALID",
                "peer " + node + " must have exactly one ACTIVE key generation");
        }
        config.peers.push_back(PeerConfig{
            .node_id = node,
            .routes = route.routes,
            .active_generation = active.front()->generation,
            .active_spki_sha256 = active.front()->spki_sha256,
            .delivery = route.delivery,
        });
    }
    std::sort(config.peers.begin(), config.peers.end(),
        [](const PeerConfig& left, const PeerConfig& right) {
            return left.node_id < right.node_id;
        });

    for (const auto& rule : config.action_results.rules) {
        const auto* peer = find_peer(config, rule.peer_node);
        const auto* generation = find_peer_generation(
            config, rule.peer_node, rule.peer_generation);
        if (peer == nullptr || generation == nullptr ||
            generation->state != KeyGenerationState::active ||
            peer->active_generation != rule.peer_generation ||
            peer->active_spki_sha256 != generation->spki_sha256) {
            app_fail("ACTION_RESULT_ROUTE_INVALID",
                "action-result rules require the peer's exact active routed generation");
        }
    }

    config.source_views = make_source_view_policy(source_view_values, source_view_binding_values, config);
    for (const auto& grant : config.source_disclosure.grants) {
        if (grant.peer == config.local_node ||
            !find_peer_generation(config, grant.peer, grant.generation)) {
            app_fail("SOURCE_DISCLOSURE_PEER_INVALID", "disclosure grant requires a nonlocal peer with an exact configured key generation");
        }
    }
    for (const auto& key : config.peer_generations) {
        if (config.trusted_peers.empty() ||
            config.trusted_peers.back().node_id != key.node_id) {
            if (config.trusted_peers.size() >= kMaximumPeers) {
                app_fail("CONFIG_TOO_MANY_TRUSTED_PEERS",
                    "at most 64 trusted peer identities are supported");
            }
            config.trusted_peers.push_back(TlsTrustedIdentity{
                .node_id = key.node_id,
                .generations = {},
            });
        }
        config.trusted_peers.back().generations.push_back(TlsTrustedGeneration{
            .generation = key.generation,
            .spki_sha256 = key.spki_sha256,
            .state = key.state,
        });
    }
    // Public-only policy validation: never open private handoff material here.
    for (const auto& record : config.handoff_keys) {
        const auto& binding = record.binding;
        if (binding.node == config.local_node) {
            require_handoff_binding(binding, config.local_node, config.local_identity_generation, config.identity.expected_spki_sha256);
        } else {
            const auto* peer = find_peer_generation(config, binding.node, binding.signing_generation);
            if (peer == nullptr) { app_fail("CONFIG_HANDOFF_SIGNER_UNKNOWN", "retained handoff binding requires exact configured signing generation"); }
            require_handoff_binding(binding, peer->node_id, peer->generation, peer->spki_sha256);
        }
    }
    const auto require_custody_signer = [&](const std::string_view node,
            const std::string_view generation) {
        if (node == config.local_node) {
            if (generation != config.local_identity_generation) {
                app_fail("CONFIG_CUSTODY_GRANT_SIGNER_UNKNOWN",
                    "local custody party requires the exact local signing generation");
            }
            return;
        }
        if (find_peer_generation(config, node, generation) == nullptr) {
            app_fail("CONFIG_CUSTODY_GRANT_SIGNER_UNKNOWN",
                "custody grant party requires an exact retained peer signing generation");
        }
    };
    for (const auto& grant : config.custody_relay) {
        require_custody_signer(grant.origin, grant.origin_signing_generation);
        require_custody_signer(grant.final_recipient,
            grant.final_signing_generation);
        require_custody_signer(grant.custodian,
            grant.custodian_signing_generation);
        require_custody_signer(grant.next_hop,
            grant.next_hop_signing_generation);
    }
    for (const auto& rule : config.custody_sessions) {
        const auto& grant = resolve_custody_session_grant(
            config.custody_relay, rule, false);
        const bool local_is_custodian = config.local_node == grant.custodian;
        const bool local_is_next_hop = config.local_node == grant.next_hop;
        if (local_is_custodian == local_is_next_hop) {
            app_fail("CONFIG_CUSTODY_SESSION_ENDPOINT",
                "local node must be exactly one endpoint of each service rule");
        }
        const auto& local_generation = local_is_custodian ?
            grant.custodian_signing_generation :
            grant.next_hop_signing_generation;
        const auto& peer_node = local_is_custodian ?
            grant.next_hop : grant.custodian;
        const auto& peer_generation = local_is_custodian ?
            grant.next_hop_signing_generation :
            grant.custodian_signing_generation;
        if (config.local_identity_generation != local_generation) {
            app_fail("CONFIG_CUSTODY_SESSION_ENDPOINT",
                "local signing generation does not match the exact V21 endpoint");
        }
        const auto* retained = find_peer_generation(
            config, peer_node, peer_generation);
        if (retained == nullptr) {
            app_fail("CONFIG_CUSTODY_SESSION_ENDPOINT",
                "peer signing generation is not retained");
        }
        if (rule.maximum_pending_cases > grant.maximum_active_envelopes ||
            rule.maximum_transfer_window_ms >
                grant.maximum_envelope_lifetime_ms) {
            app_fail("CONFIG_CUSTODY_SESSION_LIMIT",
                "V22 service bounds exceed the referenced V21 grant");
        }
        if (rule.state == CustodySessionRuleState::active) {
            static_cast<void>(resolve_custody_session_grant(
                config.custody_relay, rule, true));
            const auto* routed = find_peer(config, peer_node);
            if (retained->state != KeyGenerationState::active ||
                routed == nullptr ||
                routed->active_generation != peer_generation ||
                routed->active_spki_sha256 != retained->spki_sha256 ||
                std::none_of(routed->routes.begin(), routed->routes.end(),
                    [](const PeerRouteConfig& route) {
                        return route.state == PeerRouteState::enabled;
                    })) {
                app_fail("CONFIG_CUSTODY_SESSION_ENDPOINT",
                    "active service requires the exact active peer generation and an enabled explicit route");
            }
        }
    }
    for (const auto& activation : config.custody_receivers) {
        const auto& rule = resolve_custody_receiver_session_rule(
            config.custody_sessions, activation, false);
        const auto& grant = resolve_custody_session_grant(
            config.custody_relay, rule, false);
        if (config.local_node != grant.next_hop ||
            config.local_identity_generation !=
                grant.next_hop_signing_generation) {
            app_fail("CONFIG_CUSTODY_RECEIVER_LOCAL_ROLE",
                "daemon receiver activation requires the exact local V21 next-hop endpoint");
        }
        if (activation.activation_expires_unix_ms >
                rule.authority_expires_unix_ms) {
            app_fail("CONFIG_CUSTODY_RECEIVER_LIMIT",
                "V23 activation expiry cannot exceed its exact V22 authority expiry");
        }
        if (activation.maximum_inflight_offers >= config.peer_workers) {
            app_fail("CONFIG_CUSTODY_RECEIVER_FAIRNESS",
                "daemon receiver must reserve at least one ordinary peer worker");
        }
        if (activation.state == CustodyReceiverActivationState::active) {
            static_cast<void>(resolve_custody_receiver_session_rule(
                config.custody_sessions, activation, true));
            static_cast<void>(resolve_custody_session_grant(
                config.custody_relay, rule, true));
        }
    }
    for (const auto& activation : config.custody_dispatch) {
        const auto& receiver = resolve_custody_dispatch_receiver_activation(
            config.custody_receivers, activation, false);
        const auto& receiver_rule = resolve_custody_receiver_session_rule(
            config.custody_sessions, receiver, false);
        const auto& receiver_grant = resolve_custody_session_grant(
            config.custody_relay, receiver_rule, false);
        const auto& outbound_rule = resolve_custody_dispatch_outbound_rule(
            config.custody_sessions, activation, false);
        const auto& outbound_grant = resolve_custody_session_grant(
            config.custody_relay, outbound_rule, false);
        if (config.local_node != receiver_grant.next_hop ||
            config.local_identity_generation !=
                receiver_grant.next_hop_signing_generation ||
            config.local_node != outbound_grant.custodian ||
            config.local_identity_generation !=
                outbound_grant.custodian_signing_generation) {
            app_fail("CONFIG_CUSTODY_DISPATCH_LOCAL_ROLE",
                "V24 requires the exact local V23 receiver and outbound V22 custodian roles");
        }
        if (activation.maximum_dispatch_attempts >
                outbound_rule.maximum_attempts ||
            activation.activation_expires_unix_ms >
                receiver.activation_expires_unix_ms ||
            activation.activation_expires_unix_ms >
                outbound_rule.authority_expires_unix_ms) {
            app_fail("CONFIG_CUSTODY_DISPATCH_LIMIT",
                "V24 bounds must fit inside the exact V23 and outbound V22 authorities");
        }
        if (activation.maximum_concurrent_dispatches >=
                config.control_workers) {
            app_fail("CONFIG_CUSTODY_DISPATCH_FAIRNESS",
                "owner dispatch must reserve at least one ordinary control worker");
        }
        if (activation.state == CustodyDispatchActivationState::active) {
            static_cast<void>(resolve_custody_dispatch_receiver_activation(
                config.custody_receivers, activation, true));
            static_cast<void>(resolve_custody_dispatch_outbound_rule(
                config.custody_sessions, activation, true));
            static_cast<void>(resolve_custody_session_grant(
                config.custody_relay, receiver_rule, true));
            static_cast<void>(resolve_custody_session_grant(
                config.custody_relay, outbound_rule, true));
            const auto* peer = find_peer(config, outbound_grant.next_hop);
            const auto* route = peer == nullptr ? nullptr :
                find_peer_route(*peer, activation.route_id);
            if (peer == nullptr || route == nullptr ||
                route->state != PeerRouteState::enabled ||
                custody_dispatch_route_commitment(
                    peer->node_id, route->route_id,
                    transport_locator_text(route->locator), route->priority) !=
                    activation.route_commitment) {
                app_fail("CONFIG_CUSTODY_DISPATCH_ROUTE",
                    "active V24 authority requires the exact enabled named route commitment");
            }
        }
    }
    std::set<std::string> adapter_assignments;
    const auto check_adapter = [&](const TransportLocator& locator, const AdapterEndpointRole role) {
        if (locator.kind != TransportKind::adapter) { return; }
        if (config.format_version < 19U) {
            app_fail("CONFIG_VERSION_REJECTED", "configured adapter execution requires V19");
        }
        static_cast<void>(resolve_runtime_adapter_endpoint(config.adapter_configuration, locator, role));
        // Different generations of the same endpoint must not own two carrier leases.
        if (!adapter_assignments.insert(locator.adapter.endpoint_id).second) {
            app_fail("CONFIG_ADAPTER_ENDPOINT_CONFLICT", "endpoint is assigned to more than one listener or route");
        }
    };
    check_adapter(config.listen_locator, AdapterEndpointRole::listener);
    for (const auto& peer : config.peers) {
        for (const auto& route : peer.routes) { check_adapter(route.locator, AdapterEndpointRole::route); }
    }
    return config;
}


std::string_view peer_route_state_name(const PeerRouteState state) noexcept {
    switch (state) {
        case PeerRouteState::enabled: return "ENABLED";
        case PeerRouteState::disabled: return "DISABLED";
    }
    return "UNKNOWN";
}

const PeerConfig* find_peer(
    const RuntimeConfig& config,
    const std::string_view node_id) noexcept {
    const auto found = std::lower_bound(
        config.peers.begin(), config.peers.end(), node_id,
        [](const PeerConfig& peer, const std::string_view id) {
            return peer.node_id < id;
        });
    if (found == config.peers.end() || found->node_id != node_id) {
        return nullptr;
    }
    return &*found;
}

const PeerRouteConfig* find_peer_route(
    const PeerConfig& peer,
    const std::string_view route_id) noexcept {
    const auto found = std::find_if(
        peer.routes.begin(), peer.routes.end(),
        [&](const PeerRouteConfig& route) { return route.route_id == route_id; });
    return found == peer.routes.end() ? nullptr : &*found;
}

const PeerKeyGeneration* find_peer_generation(
    const RuntimeConfig& config,
    const std::string_view node_id,
    const std::string_view generation) noexcept {
    const auto found = std::lower_bound(
        config.peer_generations.begin(), config.peer_generations.end(),
        std::pair(node_id, generation),
        [](const PeerKeyGeneration& key,
           const std::pair<std::string_view, std::string_view>& wanted) {
            return key.node_id < wanted.first ||
                (key.node_id == wanted.first && key.generation < wanted.second);
        });
    if (found == config.peer_generations.end() ||
        found->node_id != node_id || found->generation != generation) {
        return nullptr;
    }
    return &*found;
}

const PeerKeyGeneration* find_peer_generation_by_pin(
    const RuntimeConfig& config,
    const std::string_view node_id,
    const datacube::Digest32& pin) noexcept {
    const auto found = std::find_if(
        config.peer_generations.begin(), config.peer_generations.end(),
        [&](const PeerKeyGeneration& key) {
            return key.node_id == node_id && key.spki_sha256 == pin;
        });
    return found == config.peer_generations.end() ? nullptr : &*found;
}

std::string runtime_config_json(const RuntimeConfig& config) {
    std::string format_name;
    switch (config.format_version) {
        case 6U: format_name = "NATRAV_OVERLAY_CONFIG_V6"; break;
        case 7U: format_name = "NATRAV_OVERLAY_CONFIG_V7"; break;
        case 8U: format_name = "NATRAV_OVERLAY_CONFIG_V8"; break;
        case 9U: format_name = "NATRAV_OVERLAY_CONFIG_V9"; break;
        case 10U: format_name = "NATRAV_OVERLAY_CONFIG_V10"; break;
        case 11U: format_name = "NATRAV_OVERLAY_CONFIG_V11"; break;
        case 12U: format_name = "NATRAV_OVERLAY_CONFIG_V12"; break;
        case 13U: format_name = "NATRAV_OVERLAY_CONFIG_V13"; break;
        case 14U: format_name = "NATRAV_OVERLAY_CONFIG_V14"; break;
        case 15U: format_name = "NATRAV_OVERLAY_CONFIG_V15"; break;
        case 16U: format_name = "NATRAV_OVERLAY_CONFIG_V16"; break;
        case 17U: format_name = "NATRAV_OVERLAY_CONFIG_V17"; break;
        case 18U: format_name = "NATRAV_OVERLAY_CONFIG_V18"; break;
        case 19U: format_name = "NATRAV_OVERLAY_CONFIG_V19"; break;
        case 20U: format_name = "NATRAV_OVERLAY_CONFIG_V20"; break;
        case 21U: format_name = "NATRAV_OVERLAY_CONFIG_V21"; break;
        case 22U: format_name = "NATRAV_OVERLAY_CONFIG_V22"; break;
        case 23U: format_name = "NATRAV_OVERLAY_CONFIG_V23"; break;
        case 24U: format_name = "NATRAV_OVERLAY_CONFIG_V24"; break;
        default: app_fail("CONFIG_VERSION_REJECTED", "unsupported runtime configuration version");
    }
    std::string out = "{\"format\":" + json_string(format_name);
    out += ",\"format_version\":" + std::to_string(config.format_version);
    out += ",\"runtime_generation\":" +
        (config.runtime_generation.empty() ? std::string("null") :
            json_string(config.runtime_generation));
    out += ",\"runtime_digest\":" + json_string(datacube::hex_lower(
        runtime_configuration_digest(canonical_runtime_config(config))));
    out += ",\"source\":" + json_string(config.source_path.string());
    out += ",\"node\":" + json_string(config.local_node);
    out += ",\"state\":" + json_string(config.state_directory.string());
    out += ",\"listen\":" + json_string(transport_locator_text(config.listen_locator));
    out += ",\"control\":" + json_string(config.control_socket.string());
    out += ",\"transport\":\"TLS1.3_MTLS_KEY_GENERATION_V1\"";
    out += ",\"identity\":{\"certificate\":" +
        json_string(config.identity.certificate.string()) +
        ",\"generation\":" + json_string(config.local_identity_generation) +
        ",\"spki_sha256\":" +
        json_string(spki_sha256_text(config.identity.expected_spki_sha256)) +
        ",\"private_key_loaded\":true}";
    out += ",\"deadline_ms\":" + std::to_string(config.io.timeout.count());
    out += ",\"sessions\":{\"protocol\":\"NOS1\"" +
        std::string(",\"maximum_operations\":") +
        std::to_string(config.sessions.maximum_operations) +
        ",\"maximum_bytes\":" +
        std::to_string(config.sessions.maximum_bytes) +
        ",\"maximum_lifetime_ms\":" +
        std::to_string(config.sessions.maximum_lifetime_ms) +
        ",\"idle_timeout_ms\":" +
        std::to_string(config.sessions.idle_timeout_ms) + "}";
    out += ",\"peer_workers\":" + std::to_string(config.peer_workers);
    out += ",\"control_workers\":" + std::to_string(config.control_workers);
    out += ",\"outbox_limits\":{\"global_max_records\":" +
        std::to_string(config.queue_limits.global_max_records) +
        ",\"global_max_payload_bytes\":" +
        std::to_string(config.queue_limits.global_max_payload_bytes) +
        ",\"peer_max_records\":" +
        std::to_string(config.queue_limits.peer_max_records) +
        ",\"peer_max_payload_bytes\":" +
        std::to_string(config.queue_limits.peer_max_payload_bytes) + "}";
    out += ",\"peers\":[";
    for (std::size_t index = 0U; index < config.peers.size(); ++index) {
        if (index != 0U) { out += ','; }
        const auto& peer = config.peers[index];
        out += "{\"node\":" + json_string(peer.node_id) +
            ",\"active_generation\":" + json_string(peer.active_generation) +
            ",\"active_spki_sha256\":" +
            json_string(spki_sha256_text(peer.active_spki_sha256)) +
            ",\"initial_backoff_ms\":" +
            std::to_string(peer.delivery.initial_backoff_ms) +
            ",\"maximum_backoff_ms\":" +
            std::to_string(peer.delivery.maximum_backoff_ms) +
            ",\"maximum_attempts\":" +
            std::to_string(peer.delivery.maximum_attempts) +
            ",\"expiry_ms\":" + std::to_string(peer.delivery.expiry_ms) +
            ",\"routes\":[";
        for (std::size_t route_index = 0U; route_index < peer.routes.size(); ++route_index) {
            if (route_index != 0U) { out += ','; }
            const auto& route = peer.routes[route_index];
            out += "{\"id\":" + json_string(route.route_id) +
                ",\"endpoint\":" + json_string(transport_locator_text(route.locator)) +
                ",\"priority\":" + std::to_string(route.priority) +
                ",\"state\":" + json_string(peer_route_state_name(route.state)) + "}";
        }
        out += "],\"generations\":[";
        bool first = true;
        for (const auto& key : config.peer_generations) {
            if (key.node_id != peer.node_id) { continue; }
            if (!first) { out += ','; }
            first = false;
            out += "{\"id\":" + json_string(key.generation) +
                ",\"state\":" + json_string(key_generation_state_name(key.state)) +
                ",\"spki_sha256\":" +
                json_string(spki_sha256_text(key.spki_sha256)) + "}";
        }
        out += "]}";
    }
    out += "],\"peer_generations\":[";
    for (std::size_t index = 0U; index < config.peer_generations.size(); ++index) {
        if (index != 0U) { out += ','; }
        const auto& key = config.peer_generations[index];
        out += "{\"node\":" + json_string(key.node_id) +
            ",\"id\":" + json_string(key.generation) +
            ",\"state\":" + json_string(key_generation_state_name(key.state)) +
            ",\"spki_sha256\":" +
            json_string(spki_sha256_text(key.spki_sha256)) + "}";
    }
    out += "],\"authorization\":" +
        authorization_policy_json(config.authorization) +
        (config.format_version >= 18U ?
            ",\"action_result_policy\":" +
                action_result_policy_json(config.action_results) : "") +
        (config.format_version >= 19U ?
            ",\"adapter_configuration\":" + runtime_adapter_configuration_json(config.adapter_configuration) : "") +
        (config.format_version >= 20U ?
            ",\"handoff_key_policy\":" + handoff_key_policy_json(config.handoff_keys) : "") +
        (config.format_version >= 21U ?
            ",\"custody_relay_policy\":" + custody_relay_policy_json(config.custody_relay) : "") +
        (config.format_version >= 22U ?
            ",\"custody_session_policy\":" + custody_session_policy_json(config.custody_sessions) : "") +
        (config.format_version >= 23U ?
            ",\"custody_receiver_policy\":" + custody_receiver_policy_json(config.custody_receivers) : "") +
        (config.format_version >= 24U ?
            ",\"custody_dispatch_policy\":" + custody_dispatch_policy_json(config.custody_dispatch) : "") +
        ",\"local_control\":" + local_control_policy_json(config.local_control) +
        ",\"evidence_read_policy\":" + evidence_read_policy_json(config.evidence_read) +
        (config.format_version >= 14U ? ",\"evidence_author_policy\":" + local_author_policy_json(config.evidence_author) : "") +
        (config.format_version >= 15U ? ",\"source_disclosure_policy\":" + source_disclosure_policy_json(config.source_disclosure) : "") +
        (config.format_version >= 17U ? ",\"source_view_policy\":" + source_view_policy_json(config.source_views) : "") + "}";
    return out;
}

std::string canonical_runtime_config(const RuntimeConfig& config) {
    std::string text;
    if (config.format_version == 6U) { text = "NATRAV_OVERLAY_CONFIG_V6\n"; }
    else if (config.format_version == 7U) { text = "NATRAV_OVERLAY_CONFIG_V7\n"; }
    else if (config.format_version == 8U) { text = "NATRAV_OVERLAY_CONFIG_V8\n"; }
    else if (config.format_version == 9U) { text = "NATRAV_OVERLAY_CONFIG_V9\n"; }
    else if (config.format_version == 10U) { text = "NATRAV_OVERLAY_CONFIG_V10\n"; }
    else if (config.format_version == 11U) { text = "NATRAV_OVERLAY_CONFIG_V11\n"; }
    else if (config.format_version == 12U) { text = "NATRAV_OVERLAY_CONFIG_V12\n"; }
    else if (config.format_version == 13U) { text = "NATRAV_OVERLAY_CONFIG_V13\n"; }
    else if (config.format_version == 14U) { text = "NATRAV_OVERLAY_CONFIG_V14\n"; }
    else if (config.format_version == 15U) { text = "NATRAV_OVERLAY_CONFIG_V15\n"; }
    else if (config.format_version == 16U) { text = "NATRAV_OVERLAY_CONFIG_V16\n"; }
    else if (config.format_version == 17U) { text = "NATRAV_OVERLAY_CONFIG_V17\n"; }
    else if (config.format_version == 18U) { text = "NATRAV_OVERLAY_CONFIG_V18\n"; }
    else if (config.format_version == 19U) { text = "NATRAV_OVERLAY_CONFIG_V19\n"; }
    else if (config.format_version == 20U) { text = "NATRAV_OVERLAY_CONFIG_V20\n"; }
    else if (config.format_version == 21U) { text = "NATRAV_OVERLAY_CONFIG_V21\n"; }
    else if (config.format_version == 22U) { text = "NATRAV_OVERLAY_CONFIG_V22\n"; }
    else if (config.format_version == 23U) { text = "NATRAV_OVERLAY_CONFIG_V23\n"; }
    else if (config.format_version == 24U) { text = "NATRAV_OVERLAY_CONFIG_V24\n"; }
    else { app_fail("CONFIG_VERSION_REJECTED", "unsupported runtime configuration version"); }
    const auto put = [&](const std::string_view key, const std::string& value) {
        if (value.find_first_of("\r\n\0", 0U, 3U) != std::string::npos) {
            app_fail("CONFIG_CANONICAL_INVALID", "field contains a line separator");
        }
        text += std::string(key) + "=" + value + "\n";
    };
    const auto number = [&](const std::string_view key, const auto value) {
        put(key, std::to_string(value));
    };
    if (!config.runtime_generation.empty()) {
        put("runtime_generation", config.runtime_generation);
    }
    put("node", config.local_node);
    put("state", config.state_directory.string());
    put("listen", transport_locator_text(config.listen_locator));
    put("control", config.control_socket.filename().string());
    put("identity_cert", config.identity.certificate.string());
    put("identity_key", config.identity.private_key.string());
    put("identity_pin", spki_sha256_text(config.identity.expected_spki_sha256));
    put("identity_generation", config.local_identity_generation);
    number("deadline_ms", config.io.timeout.count());
    number("read_quantum", config.io.read_quantum);
    number("write_quantum", config.io.write_quantum);
    number("receive_limit", config.io.maximum_received_bytes);
    number("session_max_operations", config.sessions.maximum_operations);
    number("session_max_bytes", config.sessions.maximum_bytes);
    number("session_max_lifetime_ms", config.sessions.maximum_lifetime_ms);
    number("session_idle_timeout_ms", config.sessions.idle_timeout_ms);
    number("max_journal_bytes", config.maximum_journal_bytes);
    number("peer_workers", config.peer_workers);
    number("peer_queue_capacity", config.peer_queue_capacity);
    number("control_workers", config.control_workers);
    number("control_queue_capacity", config.control_queue_capacity);
    number("backlog", config.backlog);
    number("outbox_global_max_records", config.queue_limits.global_max_records);
    number("outbox_global_max_payload_bytes", config.queue_limits.global_max_payload_bytes);
    number("outbox_peer_max_records", config.queue_limits.peer_max_records);
    number("outbox_peer_max_payload_bytes", config.queue_limits.peer_max_payload_bytes);
    number("action_counter_budget", config.authorization.action_limits.counter_budget);
    number("action_max_increment", config.authorization.action_limits.maximum_increment);
    number("action_max_defer_ms", config.authorization.action_limits.maximum_defer_ms);
    number("action_expiry_ms", config.authorization.action_limits.expiry_ms);
    if (config.format_version >= 20U) {
        auto normalized = config.handoff_keys;
        normalize_handoff_key_policy(normalized);
        for (const auto& record : normalized) { put("handoff_key_hex", adapter_configuration_record_hex(handoff_key_policy_text(record))); }
    }
    if (config.format_version >= 21U) {
        auto normalized = config.custody_relay;
        normalize_custody_relay_policy(normalized);
        for (const auto& grant : normalized) {
            put("custody_grant_hex", adapter_configuration_record_hex(
                custody_relay_grant_text(grant)));
        }
    }
    if (config.format_version >= 22U) {
        auto normalized = config.custody_sessions;
        normalize_custody_session_policy(normalized);
        for (const auto& rule : normalized) {
            put("custody_service_hex", adapter_configuration_record_hex(
                custody_session_rule_text(rule)));
        }
    }
    if (config.format_version >= 23U) {
        auto normalized = config.custody_receivers;
        normalize_custody_receiver_policy(normalized);
        for (const auto& activation : normalized) {
            put("custody_receiver_hex", adapter_configuration_record_hex(
                custody_receiver_activation_text(activation)));
        }
    }
    if (config.format_version >= 24U) {
        auto normalized = config.custody_dispatch;
        normalize_custody_dispatch_policy(normalized);
        for (const auto& activation : normalized) {
            put("custody_dispatch_hex", adapter_configuration_record_hex(
                custody_dispatch_activation_text(activation)));
        }
    }
    if (config.format_version >= 19U) {
        auto normalized = config.adapter_configuration;
        normalize_runtime_adapter_configuration(normalized);
        for (const auto& profile : normalized.profiles) {
            put("adapter_profile_hex", adapter_configuration_record_hex(operator_pinned_adapter_profile_text(profile)));
        }
        for (const auto& endpoint : normalized.endpoints) {
            put("adapter_endpoint_hex", adapter_configuration_record_hex(configured_adapter_endpoint_text(endpoint)));
        }
    }
    if (config.format_version >= 8U) {
        for (const auto& grant : config.local_control.grants) {
            put("local_control", local_control_grant_text(grant));
        }
    }
    if (config.format_version >= 17U) {
        for (const auto& rule : config.source_views.rules) { text += "source_view=" + source_view_rule_text(rule) + "\n"; }
        for (const auto& binding : config.source_views.bindings) { text += "source_view_binding=" + source_view_binding_text(binding) + "\n"; }
    }
    if (config.format_version >= 15U) {
        for (const auto& grant : config.source_disclosure.grants) {
            text += "source_disclosure=" + source_disclosure_grant_text(grant) + "\n";
        }
    }
    if (config.format_version >= 14U) {
        for (const auto& grant : config.evidence_author.grants) {
            put("evidence_author", std::to_string(grant.uid) + "," + grant.scope);
        }
    }
    if (config.format_version >= 10U) {
        for (const auto& grant : config.evidence_read.grants) {
            put("evidence_read", evidence_read_grant_text(grant));
        }
    }
    for (const auto& peer : config.peers) {
        if (config.format_version >= 13U) {
            put("peer", peer.node_id + "," +
                std::to_string(peer.delivery.initial_backoff_ms) + "," +
                std::to_string(peer.delivery.maximum_backoff_ms) + "," +
                std::to_string(peer.delivery.maximum_attempts) + "," +
                std::to_string(peer.delivery.expiry_ms));
            for (const auto& route : peer.routes) {
                put("peer_route", peer.node_id + "," + route.route_id + "," +
                    std::to_string(route.priority) + "," +
                    std::string(peer_route_state_name(route.state)) + "," +
                    transport_locator_text(route.locator));
            }
        } else {
            if (peer.routes.size() != 1U) {
                app_fail("CONFIG_CANONICAL_INVALID",
                    "legacy configuration requires exactly one synthesized route");
            }
            put("peer", peer.node_id + "," + transport_locator_text(peer.routes.front().locator) + "," +
                std::to_string(peer.delivery.initial_backoff_ms) + "," +
                std::to_string(peer.delivery.maximum_backoff_ms) + "," +
                std::to_string(peer.delivery.maximum_attempts) + "," +
                std::to_string(peer.delivery.expiry_ms));
        }
    }
    for (const auto& key : config.peer_generations) {
        put("peer_key", key.node_id + "," + key.generation + "," +
            std::string(key_generation_state_name(key.state)) + "," +
            spki_sha256_text(key.spki_sha256));
    }
    for (const auto& rule : config.authorization.rules) {
        put("authorize", rule.peer_node + "," +
            rule.peer_generation.value_or("*") + "," +
            (rule.operation_class == AuthorizedOperationClass::evidence ?
                "EVIDENCE" : "ACTION") + "," + rule.resource);
    }
    if (config.format_version >= 18U) {
        for (const auto& rule : config.action_results.rules) {
            put("action_result", rule.peer_node + "," +
                rule.peer_generation + "," + rule.resource + "," +
                rule.result_scope);
        }
    }
    if (text.size() > kMaximumConfigBytes) {
        app_fail("CONFIG_TOO_LARGE", "normalized configuration exceeds envelope");
    }
    return text;
}

datacube::Digest32 runtime_configuration_digest(const std::string_view canonical) {
    datacube::Octets data;
    datacube::append_text(data, "NATRAV_OVERLAY_RUNTIME_CONFIGURATION_V1");
    datacube::append_u8(data, 0U);
    datacube::append_text(data, canonical);
    return datacube::sha256(data);
}

bool runtime_owner_boundary_equal(
    const RuntimeConfig& left,
    const RuntimeConfig& right) {
    return left.local_node == right.local_node &&
        left.state_directory == right.state_directory &&
        left.control_socket == right.control_socket &&
        left.local_identity_generation == right.local_identity_generation &&
        left.identity.certificate == right.identity.certificate &&
        left.identity.private_key == right.identity.private_key &&
        left.identity.expected_spki_sha256 ==
            right.identity.expected_spki_sha256 &&
        transport_locator_text(left.listen_locator) ==
            transport_locator_text(right.listen_locator) &&
        left.maximum_journal_bytes == right.maximum_journal_bytes &&
        left.peer_workers == right.peer_workers &&
        left.peer_queue_capacity == right.peer_queue_capacity &&
        left.control_workers == right.control_workers &&
        left.control_queue_capacity == right.control_queue_capacity &&
        left.backlog == right.backlog;
}

bool runtime_relocation_only_change(
    const RuntimeConfig& before,
    const RuntimeConfig& after) {
    RuntimeConfig normalized = after;
    normalized.runtime_generation = before.runtime_generation;
    normalized.source_path = before.source_path;
    normalized.state_directory = before.state_directory;
    normalized.control_socket = before.control_socket;
    normalized.identity.certificate = before.identity.certificate;
    normalized.identity.private_key = before.identity.private_key;
    return canonical_runtime_config(normalized) ==
        canonical_runtime_config(before);
}

std::string peer_runtime_contract(
    const RuntimeConfig& config, const std::string_view peer) {
    // Inbound TLS/application authorization is identity- and policy-bound, not
    // dependent on the local outbound addresses used to reach the same peer.
    RuntimeConfig selected = config;
    selected.format_version = config.format_version >= 13U ? 13U : 7U;
    selected.runtime_generation = "contract";
    selected.source_path.clear();
    selected.local_control = owner_local_control_policy(0U);
    selected.queue_limits = QueueLimits{};
    selected.peers.erase(std::remove_if(selected.peers.begin(), selected.peers.end(),
        [&](const PeerConfig& p) { return p.node_id != peer; }), selected.peers.end());
    for (auto& p : selected.peers) {
        p.delivery = DeliveryPolicy{};
        if (selected.format_version >= 13U) { p.routes.clear(); }
    }
    selected.peer_generations.erase(std::remove_if(
        selected.peer_generations.begin(), selected.peer_generations.end(),
        [&](const PeerKeyGeneration& key) { return key.node_id != peer; }),
        selected.peer_generations.end());
    auto& rules = selected.authorization.rules;
    rules.erase(std::remove_if(rules.begin(), rules.end(),
        [&](const AuthorizationRule& rule) { return rule.peer_node != peer; }),
        rules.end());
    return datacube::hex_lower(
        runtime_configuration_digest(canonical_runtime_config(selected)));
}

std::string peer_route_runtime_contract(
    const RuntimeConfig& config,
    const std::string_view peer,
    const std::string_view route_id) {
    RuntimeConfig selected = config;
    selected.format_version = config.format_version >= 13U ? 13U : 7U;
    selected.runtime_generation = "route-contract";
    selected.source_path.clear();
    selected.local_control = owner_local_control_policy(0U);
    selected.queue_limits = QueueLimits{};
    selected.peers.erase(std::remove_if(selected.peers.begin(), selected.peers.end(),
        [&](const PeerConfig& value) { return value.node_id != peer; }),
        selected.peers.end());
    if (selected.peers.size() != 1U) {
        app_fail("CONFIG_PEER_ROUTE_NOT_FOUND", "peer route contract names an absent peer");
    }
    auto& chosen_peer = selected.peers.front();
    chosen_peer.delivery = DeliveryPolicy{};
    if (selected.format_version >= 13U) {
        chosen_peer.routes.erase(std::remove_if(
            chosen_peer.routes.begin(), chosen_peer.routes.end(),
            [&](const PeerRouteConfig& route) { return route.route_id != route_id; }),
            chosen_peer.routes.end());
        if (chosen_peer.routes.size() != 1U) {
            app_fail("CONFIG_PEER_ROUTE_NOT_FOUND",
                "peer route contract names an absent route");
        }
    }
    selected.peer_generations.erase(std::remove_if(
        selected.peer_generations.begin(), selected.peer_generations.end(),
        [&](const PeerKeyGeneration& key) { return key.node_id != peer; }),
        selected.peer_generations.end());
    auto& rules = selected.authorization.rules;
    rules.erase(std::remove_if(rules.begin(), rules.end(),
        [&](const AuthorizationRule& rule) { return rule.peer_node != peer; }),
        rules.end());
    return datacube::hex_lower(
        runtime_configuration_digest(canonical_runtime_config(selected)));
}

}  // namespace natrav_overlay
