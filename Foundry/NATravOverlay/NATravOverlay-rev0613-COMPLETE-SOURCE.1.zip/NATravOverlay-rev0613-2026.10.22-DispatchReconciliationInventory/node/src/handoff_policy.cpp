#include "handoff_policy.hpp"
#include <algorithm>
#include <set>
#include <tuple>

namespace natrav_overlay {
namespace {
constexpr std::size_t kPolicyTextLimit = 1'500U;
void require(bool condition, std::string_view code, std::string_view detail) {
    if (!condition) { app_fail(code, detail); }
}
datacube::Octets decode_binding_hex(std::string_view text, std::size_t limit = kHandoffBindingLimit) {
    require(!text.empty() && text.size() <= 2U * limit && text.size() % 2U == 0U,
        "CONFIG_HANDOFF_RECORD_INVALID", "binding hexadecimal length");
    const auto nibble = [](char c) -> unsigned int {
        if (c >= '0' && c <= '9') { return static_cast<unsigned int>(c - '0'); }
        if (c >= 'a' && c <= 'f') { return static_cast<unsigned int>(c - 'a') + 10U; }
        app_fail("CONFIG_HANDOFF_RECORD_NONCANONICAL", "lowercase hexadecimal required");
    };
    datacube::Octets out;
    out.reserve(text.size() / 2U);
    for (std::size_t i = 0U; i < text.size(); i += 2U) {
        out.push_back(static_cast<std::uint8_t>(16U * nibble(text[i]) + nibble(text[i + 1U])));
    }
    return out;
}
const HandoffKeyPolicyRecord* find(const HandoffKeyPolicy& records, const HandoffBinding& binding) {
    const auto it = std::find_if(records.begin(), records.end(), [&](const auto& r) {
        return r.binding.node == binding.node && r.binding.handoff_generation == binding.handoff_generation;
    });
    return it == records.end() ? nullptr : &*it;
}
void validate_record(const HandoffKeyPolicyRecord& r) {
    require(r.sequence > 0U && r.sequence <= kHandoffPolicyPerNodeLimit,
        "CONFIG_HANDOFF_SEQUENCE", "sequence outside retained per-node bound");
    require(r.state == HandoffKeyState::active || r.state == HandoffKeyState::retired || r.state == HandoffKeyState::revoked,
        "CONFIG_HANDOFF_STATE", "unknown lifecycle state");
    // Re-decode and authenticate canonical bytes; derived in-memory fields must
    // agree as well. This is independent of filesystem/private key availability.
    require_handoff_binding(r.binding, r.binding.node, r.binding.signing_generation, handoff_signing_pin(r.binding));
}
} // namespace
std::string_view handoff_key_state_name(HandoffKeyState state) {
    switch (state) {
        case HandoffKeyState::active: return "ACTIVE";
        case HandoffKeyState::retired: return "RETIRED";
        case HandoffKeyState::revoked: return "REVOKED";
    }
    app_fail("CONFIG_HANDOFF_STATE", "unknown lifecycle state");
}
std::string handoff_key_commitment_text(const HandoffKeyPolicyRecord& r) {
    validate_record(r);
    return "NATRAV_HANDOFF_KEY_COMMITMENT_V1\nsequence=" + std::to_string(r.sequence) +
        "\npredecessor_sha256=" + operation_id_text(r.predecessor) +
        "\nbinding_hex=" + hex_bytes(r.binding.canonical) + "\n";
}
datacube::Digest32 handoff_key_commitment(const HandoffKeyPolicyRecord& r) {
    const auto text = handoff_key_commitment_text(r);
    return datacube::sha256(datacube::OctetView(reinterpret_cast<const std::uint8_t*>(text.data()), text.size()));
}
std::string handoff_key_policy_text(const HandoffKeyPolicyRecord& r) {
    const auto immutable = handoff_key_commitment_text(r);
    return "NATRAV_HANDOFF_KEY_POLICY_V1\n" + immutable.substr(immutable.find('\n') + 1U) +
        "state=" + std::string(handoff_key_state_name(r.state)) + "\n";
}
HandoffKeyPolicyRecord parse_handoff_key_policy(std::string_view hex) {
    require(hex.size() <= 2U * kPolicyTextLimit, "CONFIG_HANDOFF_RECORD_INVALID", "policy record byte bound");
    const auto raw = decode_binding_hex(hex, kPolicyTextLimit);
    require(std::all_of(raw.begin(), raw.end(), [](std::uint8_t c) { return c > 0U && c < 128U; }),
        "CONFIG_HANDOFF_RECORD_NONCANONICAL", "canonical policy text requires ASCII without NUL");
    const std::string text(raw.begin(), raw.end());
    std::size_t offset = 0U;
    const auto field = [&](std::string_view prefix) {
        const auto end = text.find('\n', offset);
        require(end != std::string::npos, "CONFIG_HANDOFF_RECORD_NONCANONICAL", "complete canonical line required");
        const auto line = std::string_view(text).substr(offset, end - offset);
        require(line.starts_with(prefix), "CONFIG_HANDOFF_RECORD_NONCANONICAL", "canonical field order required");
        offset = end + 1U;
        return line.substr(prefix.size());
    };
    require(field("NATRAV_HANDOFF_KEY_POLICY_V1").empty(), "CONFIG_HANDOFF_RECORD_NONCANONICAL", "policy header");
    HandoffKeyPolicyRecord r;
    r.sequence = parse_u64(field("sequence="), "handoff sequence", 1U, kHandoffPolicyPerNodeLimit);
    const auto predecessor = field("predecessor_sha256=");
    r.predecessor = predecessor == std::string(64U, '0') ? datacube::Digest32{} : parse_operation_id(predecessor);
    r.binding = decode_handoff_binding(decode_binding_hex(field("binding_hex=")));
    const auto state = field("state=");
    if (state == "ACTIVE") { r.state = HandoffKeyState::active; }
    else if (state == "RETIRED") { r.state = HandoffKeyState::retired; }
    else if (state == "REVOKED") { r.state = HandoffKeyState::revoked; }
    else { app_fail("CONFIG_HANDOFF_STATE", "expected ACTIVE, RETIRED or REVOKED"); }
    require(offset == text.size() && handoff_key_policy_text(r) == text,
        "CONFIG_HANDOFF_RECORD_NONCANONICAL", "noncanonical or trailing policy data");
    return r;
}
void normalize_handoff_key_policy(HandoffKeyPolicy& records) {
    require(records.size() <= kHandoffPolicyRecordLimit, "CONFIG_HANDOFF_CAPACITY", "retained policy record bound");
    std::sort(records.begin(), records.end(), [](const auto& a, const auto& b) {
        return std::tie(a.binding.node, a.sequence) < std::tie(b.binding.node, b.sequence);
    });
    std::set<std::pair<std::string, std::string>> names;
    std::set<HandoffKeyBytes> encryption_keys;
    const HandoffKeyPolicyRecord* previous = nullptr;
    for (const auto& r : records) {
        validate_record(r);
        require(names.emplace(r.binding.node, r.binding.handoff_generation).second,
            "CONFIG_HANDOFF_GENERATION_CONFLICT", "duplicate generation label");
        require(encryption_keys.insert(r.binding.encryption_public).second,
            "CONFIG_HANDOFF_KEY_REUSE", "X25519 key cannot be relabelled or reassigned");
        if (previous != nullptr && previous->binding.node != r.binding.node) { previous = nullptr; }
        if (previous == nullptr) {
            require(r.sequence == 1U && digest_is_zero(r.predecessor), "CONFIG_HANDOFF_PREDECESSOR", "first record requires sequence one and zero predecessor");
        } else {
            require(r.sequence == previous->sequence + 1U && r.predecessor == handoff_key_commitment(*previous),
                "CONFIG_HANDOFF_PREDECESSOR", "exact consecutive immutable predecessor required");
            require(previous->state != HandoffKeyState::active, "CONFIG_HANDOFF_ACTIVE_CONFLICT", "superseded key must be explicitly retired or revoked");
        }
        previous = &r;
    }
}
void require_handoff_key_history_preserved(const HandoffKeyPolicy& historical, const HandoffKeyPolicy& candidate) {
    for (const auto& prior : historical) {
        const auto* next = find(candidate, prior.binding);
        require(next != nullptr, "CONFIG_HANDOFF_HISTORY_REMOVED", "accepted key generation must remain present");
        require(handoff_key_commitment(*next) == handoff_key_commitment(prior),
            "CONFIG_HANDOFF_GENERATION_CONFLICT", "accepted binding or predecessor cannot be redefined");
        require(static_cast<unsigned>(next->state) >= static_cast<unsigned>(prior.state),
            "CONFIG_HANDOFF_STATE_ROLLBACK", "retirement and revocation are monotonic including rollback");
    }
}
void require_handoff_key_use(const HandoffKeyPolicy& records, const HandoffBinding& binding, bool exporting) {
    const auto* record = find(records, binding);
    require(record != nullptr && record->binding.canonical == binding.canonical,
        "HANDOFF_KEY_NOT_COMMITTED", "exact signed binding absent from accepted policy");
    require(record->state != HandoffKeyState::revoked, "HANDOFF_KEY_REVOKED", "accepted policy revokes this exact key");
    require(!exporting || record->state == HandoffKeyState::active,
        "HANDOFF_KEY_RETIRED", "retired keys cannot originate new capsule exports");
}
std::string handoff_key_policy_json(const HandoffKeyPolicy& records) {
    std::string out = "{\"format\":\"V20_DURABLE_HANDOFF_KEY_POLICY_V1\",\"records\":[";
    bool first = true;
    for (const auto& r : records) {
        if (!first) { out += ','; }
        first = false;
        out += "{\"node\":" + json_string(r.binding.node) + ",\"handoff_generation\":" + json_string(r.binding.handoff_generation) +
            ",\"signing_generation\":" + json_string(r.binding.signing_generation) + ",\"sequence\":" + std::to_string(r.sequence) +
            ",\"state\":" + json_string(handoff_key_state_name(r.state)) + ",\"binding_sha256\":" + json_string(operation_id_text(datacube::sha256(r.binding.canonical))) +
            ",\"commitment_sha256\":" + json_string(operation_id_text(handoff_key_commitment(r))) +
            ",\"predecessor_sha256\":" + json_string(operation_id_text(r.predecessor)) + "}";
    }
    return out + "]}";
}
} // namespace natrav_overlay
