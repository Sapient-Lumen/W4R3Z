#include "runtime_inventory.hpp"
#include "config.hpp"
#include <algorithm>
#include <array>
#include <limits>
#include <utility>

namespace natrav_overlay {
namespace {
constexpr std::array<std::string_view, 11> sections{
    "peers", "routes", "keys", "local-control", "evidence-read", "evidence-author",
    "authorization", "source-disclosure", "source-views", "source-bindings", "configuration"};
void text(datacube::Octets& out, std::string_view value) {
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}
std::string text(datacube::Reader& reader, std::size_t maximum) {
    const auto size = reader.read_be16("inventory text length");
    if (size > maximum) app_fail("RUNTIME_INVENTORY_INVALID", "text exceeds limit");
    return datacube::octets_text(reader.read_exact(size, "inventory text"), "inventory text", true);
}
std::string hash_text(std::string_view domain, const datacube::Octets& material) {
    datacube::Octets input; datacube::append_text(input, domain); datacube::append_u8(input, 0U);
    datacube::append_octets(input, material); return datacube::hex_lower(datacube::sha256(input));
}
std::string q(std::string_view value) { return json_string(value); }
std::string d(const datacube::Digest32& value) { return q(datacube::hex_lower(value)); }
struct Row final {
    std::string order, id, peer;
    std::optional<std::uint32_t> uid;
    std::function<std::string()> render;
};
} // namespace
void validate_runtime_inventory(const RuntimeInventory& r) {
    if (std::find(sections.begin(), sections.end(), r.section) == sections.end())
        app_fail("RUNTIME_INVENTORY_INVALID", "unknown section");
    if (r.limit < 1U || r.limit > 64U || r.maximum_bytes < 2048U || r.maximum_bytes > 60000U || r.offset > 1000000U)
        app_fail("RUNTIME_INVENTORY_INVALID", "limit, byte budget or offset outside bounds");
    if (!r.peer.empty()) require_node_id(r.peer, "inventory peer");
    if (r.id.size() > 256U || std::any_of(r.id.begin(), r.id.end(), [](unsigned char c) { return c < 32U || c > 126U; }))
        app_fail("RUNTIME_INVENTORY_INVALID", "id must be bounded printable ASCII");
    const bool peer_section = r.section == "peers" || r.section == "routes" || r.section == "keys" ||
        r.section == "authorization" || r.section == "evidence-read" || r.section == "source-disclosure" || r.section == "source-views";
    const bool uid_section = r.section == "local-control" || r.section == "evidence-read" ||
        r.section == "evidence-author" || r.section == "source-disclosure" || r.section == "source-views";
    if ((!r.peer.empty() && !peer_section) || (r.uid && !uid_section))
        app_fail("RUNTIME_INVENTORY_INVALID", "filter is not defined for this section");
    if (r.offset != 0U && !r.selection)
        app_fail("RUNTIME_INVENTORY_SELECTION_REQUIRED", "nonzero offset requires the selected context digest");
    if (r.selection && digest_is_zero(*r.selection))
        app_fail("RUNTIME_INVENTORY_INVALID", "selection digest is zero");
}
datacube::Octets encode_runtime_inventory(const RuntimeInventory& r) {
    validate_runtime_inventory(r);
    datacube::Octets out; datacube::append_text(out, "NRI1");
    text(out, r.section); text(out, r.peer); text(out, r.id);
    datacube::append_u8(out, r.uid ? 1U : 0U); if (r.uid) datacube::append_be32(out, *r.uid);
    datacube::append_be32(out, r.offset); datacube::append_be32(out, r.limit); datacube::append_be32(out, r.maximum_bytes);
    datacube::append_u8(out, r.selection ? 1U : 0U); if (r.selection) datacube::append_octets(out, r.selection->octets);
    return out;
}
RuntimeInventory decode_runtime_inventory(datacube::OctetView bytes) {
    datacube::Reader rd(bytes, "runtime inventory");
    if (datacube::octets_text(rd.read_exact(4U, "inventory magic"), "inventory magic", true) != "NRI1")
        app_fail("RUNTIME_INVENTORY_INVALID", "wrong magic");
    RuntimeInventory r; r.section = text(rd, 32U); r.peer = text(rd, 64U); r.id = text(rd, 256U);
    const auto has_uid = rd.read_u8("uid flag"); if (has_uid > 1U) app_fail("RUNTIME_INVENTORY_INVALID", "uid flag");
    if (has_uid) r.uid = rd.read_be32("uid");
    r.offset = rd.read_be32("offset"); r.limit = rd.read_be32("limit"); r.maximum_bytes = rd.read_be32("maximum bytes");
    const auto has_selection = rd.read_u8("selection flag"); if (has_selection > 1U) app_fail("RUNTIME_INVENTORY_INVALID", "selection flag");
    if (has_selection) { datacube::Digest32 digest{}; const auto v = rd.read_exact(32U, "selection"); std::copy(v.begin(), v.end(), digest.octets.begin()); r.selection = digest; }
    rd.require_eof("runtime inventory"); validate_runtime_inventory(r); return r;
}
std::string runtime_registry_digest(const std::vector<std::string>& registry) {
    auto names = registry; std::sort(names.begin(), names.end());
    datacube::Octets bytes; datacube::append_be32(bytes, static_cast<std::uint32_t>(names.size()));
    for (const auto& node : names) text(bytes, node);
    return hash_text("NATRAV_OVERLAY_RUNTIME_REGISTRY_V1", bytes);
}
std::string runtime_inventory_json(const RuntimeConfig& c, const std::vector<std::string>& registry,
    const RuntimeInventory& r, std::uint32_t principal_uid, std::string_view process_instance,
    const InventoryTelemetry& telemetry, std::chrono::steady_clock::time_point deadline) {
    validate_runtime_inventory(r);
    auto check_deadline = [&] { if (std::chrono::steady_clock::now() >= deadline)
        app_fail("RUNTIME_INVENTORY_DEADLINE", "inventory construction deadline reached"); };
    check_deadline();
    const auto config_digest = datacube::hex_lower(runtime_configuration_digest(canonical_runtime_config(c)));
    const auto registry_digest = runtime_registry_digest(registry);
    datacube::Octets context; text(context, c.local_node); text(context, config_digest); text(context, registry_digest);
    text(context, r.section); text(context, r.peer); text(context, r.id); datacube::append_be32(context, principal_uid);
    datacube::append_u8(context, r.uid ? 1U : 0U); if (r.uid) datacube::append_be32(context, *r.uid);
    const auto selection = hash_text("NATRAV_OVERLAY_RUNTIME_INVENTORY_SELECTION_V1", context);
    if (r.selection && datacube::hex_lower(*r.selection) != selection)
        app_fail("RUNTIME_INVENTORY_CONTEXT_MISMATCH", "configuration, membership, principal or filters changed");
    std::vector<Row> rows; std::size_t considered = 0U;
    auto add = [&](std::string id, std::string peer, std::optional<std::uint32_t> uid, std::function<std::string()> render) {
        ++considered;
        if ((!r.id.empty() && r.id != id) || (!r.peer.empty() && r.peer != peer) || (r.uid && r.uid != uid)) return;
        auto order = peer; order.push_back('\0'); order += id;
        rows.push_back(Row{std::move(order), std::move(id), std::move(peer), uid, std::move(render)});
    };
    if (r.section == "peers") for (const auto& node : registry) {
        const auto* p = find_peer(c, node);
        const bool key = std::any_of(c.peer_generations.begin(), c.peer_generations.end(), [&](const auto& k){ return k.node_id == node; });
        add(node, node, {}, [&, node, p, key] {
            std::string out = "{\"id\":" + q(node) + ",\"node\":" + q(node) + ",\"role\":" +
                q(p ? "ROUTED" : key ? "INBOUND_ONLY" : "HISTORICAL");
            if (p) {
                out += ",\"active_generation\":" + q(p->active_generation) + ",\"active_spki_sha256\":" + d(p->active_spki_sha256) +
                    ",\"routes\":" + std::to_string(p->routes.size()) + ",\"pending_max_records\":" + std::to_string(c.queue_limits.peer_max_records) + ",\"pending_max_payload_bytes\":" + std::to_string(c.queue_limits.peer_max_payload_bytes) + ",\"delivery\":{\"initial_backoff_ms\":" + std::to_string(p->delivery.initial_backoff_ms) +
                    ",\"maximum_backoff_ms\":" + std::to_string(p->delivery.maximum_backoff_ms) + ",\"maximum_attempts\":" + std::to_string(p->delivery.maximum_attempts) +
                    ",\"expiry_ms\":" + std::to_string(p->delivery.expiry_ms) + "}";
            }
            return out + ",\"telemetry\":" + telemetry(node, "") + "}";
        });
    }
    else if (r.section == "routes") for (const auto& p : c.peers) for (const auto& route : p.routes) {
        const auto* pp = &p; const auto* rt = &route;
        add(route.route_id, p.node_id, {}, [&, pp, rt] { return "{\"id\":" + q(rt->route_id) + ",\"peer\":" + q(pp->node_id) +
            ",\"endpoint\":" + q(transport_locator_text(rt->locator)) + ",\"priority\":" + std::to_string(rt->priority) +
            ",\"state\":" + q(peer_route_state_name(rt->state)) + ",\"telemetry\":" + telemetry(pp->node_id, rt->route_id) + "}"; });
    }
    else if (r.section == "keys") for (const auto& key : c.peer_generations) {
        const auto* k = &key; add(k->generation, k->node_id, {}, [k]{ return "{\"id\":" + q(k->generation) + ",\"node\":" + q(k->node_id) +
            ",\"state\":" + q(key_generation_state_name(k->state)) + ",\"spki_sha256\":" + d(k->spki_sha256) + "}"; });
    }
    else if (r.section == "local-control") for (const auto& grant : c.local_control.grants) {
        const auto* g = &grant; add(std::to_string(g->uid), "", g->uid, [g] {
            std::string row = "{\"id\":" + q(std::to_string(g->uid)) + ",\"uid\":" + std::to_string(g->uid) + ",\"classes\":[";
            bool first=true; for (std::uint8_t i=1U; i<=14U; ++i) { const auto cl=static_cast<LocalControlClass>(i);
                if ((g->permissions & local_control_permission(cl)) == 0U) continue;
                if (!first) { row += ','; } first=false; row += q(local_control_class_name(cl)); }
            return row + "]}";
        });
    }
    else if (r.section == "evidence-read") for (const auto& grant : c.evidence_read.grants) {
        const auto* g=&grant; const auto id=std::to_string(g->uid)+":"+g->issuer+":"+g->scope;
        add(id,g->issuer,g->uid,[g,id]{ return "{\"id\":"+q(id)+",\"uid\":"+std::to_string(g->uid)+",\"issuer\":"+q(g->issuer)+
            ",\"scope\":"+q(g->scope)+",\"access\":"+q(g->payload?"PAYLOAD":"METADATA")+"}"; });
    }
    else if (r.section == "evidence-author") for (const auto& grant : c.evidence_author.grants) {
        const auto* g=&grant; const auto id=std::to_string(g->uid)+":"+g->scope;
        add(id,"",g->uid,[g,id]{ return "{\"id\":"+q(id)+",\"uid\":"+std::to_string(g->uid)+",\"scope\":"+q(g->scope)+",\"digest\":"+d(g->digest)+"}"; });
    }
    else if (r.section == "authorization") for (const auto& rule : c.authorization.rules) {
        const auto* v=&rule; const auto id=datacube::hex_lower(v->digest);
        add(id,v->peer_node,{},[v,id]{return "{\"id\":"+q(id)+",\"peer\":"+q(v->peer_node)+",\"generation\":"+(v->peer_generation?q(*v->peer_generation):q("*"))+
            ",\"class\":"+q(authorized_operation_class_name(v->operation_class))+",\"resource\":"+q(v->resource)+"}";});
    }
    else if (r.section == "source-disclosure") for (const auto& grant : c.source_disclosure.grants) {
        const auto* g=&grant; add(g->id,g->peer,g->uid,[g]{return "{\"id\":"+q(g->id)+",\"manager_uid\":"+std::to_string(g->uid)+
            ",\"author_uid\":"+std::to_string(g->author_uid)+",\"subscriber\":"+q(g->peer)+",\"generation\":"+q(g->generation)+",\"scope\":"+q(g->scope)+
            ",\"maximum_records\":"+std::to_string(g->maximum_records)+",\"maximum_payload_bytes\":"+std::to_string(g->maximum_payload_bytes)+
            ",\"lease_generation\":"+q(g->lease_generation)+",\"lease_duration_ms\":"+std::to_string(g->lease_duration_ms)+
            ",\"pending_disposition\":"+q(source_pending_disposition_name(g->withdrawal_pending))+",\"digest\":"+d(g->digest)+"}";});
    }
    else if (r.section == "source-views") for (const auto& rule : c.source_views.rules) {
        const auto* v=&rule; add(v->id,v->provider,v->uid,[v]{return "{\"id\":"+q(v->id)+",\"manager_uid\":"+std::to_string(v->uid)+
            ",\"provider\":"+q(v->provider)+",\"generation\":"+q(v->generation)+",\"author_uid\":"+std::to_string(v->author_uid)+
            ",\"source_scope\":"+q(v->source_scope)+",\"target_scope\":"+q(v->target_scope)+",\"maximum_records\":"+std::to_string(v->maximum_records)+
            ",\"maximum_payload_bytes\":"+std::to_string(v->maximum_payload_bytes)+",\"digest\":"+d(v->digest)+"}";});
    }
    else if (r.section == "source-bindings") for (const auto& binding : c.source_views.bindings) {
        const auto* v=&binding; const auto id=datacube::hex_lower(v->digest);
        add(id,"",{},[v,id]{return "{\"id\":"+q(id)+",\"view\":"+q(v->view)+",\"grant\":"+q(v->grant)+",\"instance\":"+d(v->instance)+
            ",\"grant_digest\":"+d(v->grant_digest)+",\"lineage_digest\":"+(v->lineage_digest?d(*v->lineage_digest):"null")+"}";});
    }
    else if (r.section == "configuration") {
        add("service","",{},[&]{return "{\"id\":\"service\",\"configuration_version\":"+std::to_string(c.format_version)+
            ",\"identity_generation\":"+q(c.local_identity_generation)+",\"identity_spki_sha256\":"+d(c.identity.expected_spki_sha256)+
            ",\"listen\":"+q(transport_locator_text(c.listen_locator))+",\"maximum_journal_bytes\":"+std::to_string(c.maximum_journal_bytes)+
            ",\"peer_workers\":"+std::to_string(c.peer_workers)+",\"peer_queue_capacity\":"+std::to_string(c.peer_queue_capacity)+
            ",\"control_workers\":"+std::to_string(c.control_workers)+",\"control_queue_capacity\":"+std::to_string(c.control_queue_capacity)+
            ",\"backlog\":"+std::to_string(c.backlog)+"}";});
        add("sessions","",{},[&]{return "{\"id\":\"sessions\",\"maximum_operations\":"+std::to_string(c.sessions.maximum_operations)+
            ",\"maximum_bytes\":"+std::to_string(c.sessions.maximum_bytes)+",\"maximum_lifetime_ms\":"+std::to_string(c.sessions.maximum_lifetime_ms)+
            ",\"idle_timeout_ms\":"+std::to_string(c.sessions.idle_timeout_ms)+"}";});
        add("io","",{},[&]{return "{\"id\":\"io\",\"deadline_ms\":"+std::to_string(c.io.timeout.count())+
            ",\"read_quantum\":"+std::to_string(c.io.read_quantum)+",\"write_quantum\":"+std::to_string(c.io.write_quantum)+
            ",\"maximum_received_bytes\":"+std::to_string(c.io.maximum_received_bytes)+"}";});
        add("actions","",{},[&]{const auto& a=c.authorization.action_limits;return "{\"id\":\"actions\",\"counter_budget\":"+std::to_string(a.counter_budget)+
            ",\"maximum_increment\":"+std::to_string(a.maximum_increment)+",\"maximum_defer_ms\":"+std::to_string(a.maximum_defer_ms)+
            ",\"expiry_ms\":"+std::to_string(a.expiry_ms)+"}";});
        add("policy","",{},[&]{return "{\"id\":\"policy\",\"local_control_digest\":"+d(c.local_control.digest)+
            ",\"legacy_owner_default\":"+(c.local_control.legacy_owner_default?"true":"false")+",\"evidence_read_digest\":"+d(c.evidence_read.digest)+
            ",\"scoped_reads\":"+(c.evidence_read.scoped?"true":"false")+",\"authorization_digest\":"+d(c.authorization.digest)+
            ",\"authoring_digest\":"+d(c.evidence_author.digest)+"}";});
        add("outbox-limits","",{},[&]{return "{\"id\":\"outbox-limits\",\"global_max_records\":"+std::to_string(c.queue_limits.global_max_records)+
            ",\"global_max_payload_bytes\":"+std::to_string(c.queue_limits.global_max_payload_bytes)+",\"default_peer_max_records\":"+std::to_string(c.queue_limits.peer_max_records)+
            ",\"default_peer_max_payload_bytes\":"+std::to_string(c.queue_limits.peer_max_payload_bytes)+"}";});
    }
    std::sort(rows.begin(),rows.end(),[](const Row& a,const Row& b){return a.order<b.order;});
    if (r.offset > rows.size()) app_fail("RUNTIME_INVENTORY_OFFSET_INVALID", "offset is beyond the exact selected collection");
    std::string header="{\"format\":\"NATRAV_OVERLAY_RUNTIME_INVENTORY_V1\",\"ok\":true,\"node\":"+q(c.local_node)+
        ",\"section\":"+q(r.section)+",\"configuration_generation\":"+q(c.runtime_generation)+",\"configuration_digest\":"+q(config_digest)+
        ",\"registry_digest\":"+q(registry_digest)+",\"selection_digest\":"+q(selection)+",\"process_instance\":"+q(process_instance)+
        ",\"observation\":\"STABLE_CONFIGURATION_INDEPENDENT_RUN_TELEMETRY\",\"total\":"+std::to_string(rows.size())+
        ",\"offset\":"+std::to_string(r.offset)+",\"rows\":[";
    std::string data; std::size_t count=0U, serialized=0U;
    const auto finish=[&](std::size_t returned,std::size_t visits){const auto next=static_cast<std::size_t>(r.offset)+returned;
        return "],\"returned\":"+std::to_string(returned)+",\"has_more\":"+(next<rows.size()?"true":"false")+
            ",\"next_offset\":"+(next<rows.size()?std::to_string(next):"null")+
            ",\"work\":{\"references_considered\":"+std::to_string(considered)+",\"rows_serialized\":"+std::to_string(visits)+
            ",\"state_snapshots\":0,\"payload_bytes_copied\":0}}";};
    for (std::size_t i=r.offset;i<rows.size()&&count<r.limit;++i) {
        check_deadline(); const auto row=rows[i].render(); ++serialized;
        const auto extra=(count?1U:0U)+row.size();
        // 256 covers the maximum bounded kernel principal/request annotation.
        if(header.size()+data.size()+extra+finish(count+1U,serialized).size()+256U>r.maximum_bytes) {
            if(count==0U)app_fail("RUNTIME_INVENTORY_PAGE_TOO_SMALL","first complete row exceeds selected response budget");
            break;
        }
        if(count) { data+=','; } data+=row;++count;
    }
    check_deadline(); return header+data+finish(count,serialized);
}
} // namespace natrav_overlay
