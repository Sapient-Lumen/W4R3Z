#pragma once
#include "common.hpp"
#include <optional>
#include <string>

namespace natrav_overlay {
// Administrative current metadata only; selection is never mutation authority.
struct SubscriptionInventory final {
    std::string lifecycle{"all"}, lease{"all"}, schedule{"all"}, outcome{"all"};
    std::string grant, recipient, scope;
    std::optional<std::uint32_t> author_uid;
    std::optional<datacube::Digest32> instance;
    std::uint32_t offset{0U}, limit{16U}, maximum_bytes{32768U};
    std::optional<datacube::Digest32> selection;
};
void validate_subscription_inventory(const SubscriptionInventory&);
[[nodiscard]] datacube::Octets encode_subscription_inventory(const SubscriptionInventory&);
[[nodiscard]] SubscriptionInventory decode_subscription_inventory(datacube::OctetView);
} // namespace natrav_overlay
