#include "evidence_index.hpp"
#include <algorithm>
#include <bit>
#include <limits>

namespace natrav_overlay {
namespace {
std::size_t low_bit(const std::size_t value) noexcept { return value & (~value + 1U); }
}
std::size_t EvidenceOrderedIndex::prefix(std::size_t count) const noexcept {
    std::size_t result = 0U;
    while (count != 0U) { result += live_tree_[count - 1U]; count -= low_bit(count); }
    return result;
}
void EvidenceOrderedIndex::append(const std::size_t index, const std::optional<std::size_t> parent) {
    if (!history_.empty() && index <= history_.back()) {
        app_fail("EVIDENCE_INDEX_INVALID", "admission indices must increase");
    }
    std::optional<std::size_t> parent_position;
    if (parent) {
        const auto found = std::lower_bound(history_.begin(), history_.end(), *parent);
        if (found == history_.end() || *found != *parent) {
            app_fail("EVIDENCE_INDEX_INVALID", "correction parent missing from index");
        }
        parent_position = static_cast<std::size_t>(found - history_.begin());
        if (prefix(*parent_position + 1U) == prefix(*parent_position)) {
            app_fail("EVIDENCE_INDEX_INVALID", "correction parent is already superseded");
        }
    }
    const auto next = history_.size() + 1U;
    // A newly appended Fenwick cell covers earlier cells too, not just the new
    // leaf. Compute that interval BEFORE publishing the appended live bit.
    const auto value = 1U + prefix(next - 1U) - prefix(next - low_bit(next));
    history_.push_back(index);
    live_tree_.push_back(value);
    ++current_size_;
    if (parent_position) {
        for (auto cell = *parent_position + 1U; cell <= live_tree_.size(); cell += low_bit(cell)) {
            --live_tree_[cell - 1U];
        }
        --current_size_;
    }
}
std::size_t EvidenceOrderedIndex::size(const bool history) const noexcept {
    return history ? history_.size() : current_size_;
}
std::size_t EvidenceOrderedIndex::before(const std::size_t exclusive, const bool history) const {
    const auto position = static_cast<std::size_t>(
        std::lower_bound(history_.begin(), history_.end(), exclusive) - history_.begin());
    return history ? position : prefix(position);
}
std::size_t EvidenceOrderedIndex::at(const std::size_t ordinal, const bool history) const {
    if (ordinal >= size(history)) { app_fail("EVIDENCE_INDEX_INVALID", "index rank outside selection"); }
    if (history) { return history_[ordinal]; }
    auto rank = ordinal + 1U;
    std::size_t position = 0U;
    for (auto step = std::bit_floor(live_tree_.size()); step != 0U; step >>= 1U) {
        const auto next = position + step;
        if (next <= live_tree_.size() && live_tree_[next - 1U] < rank) {
            position = next;
            rank -= live_tree_[next - 1U];
        }
    }
    return history_[position];
}
std::size_t EvidenceOrderedIndex::allocated_bytes() const noexcept {
    return (history_.capacity() + live_tree_.capacity()) * sizeof(std::size_t);
}
std::uint64_t EvidenceRootCache::tick() noexcept {
    if (clock_ == std::numeric_limits<std::uint64_t>::max()) {
        // Losing LRU precision after wrap does not change cached state meaning.
        for (auto& entry : entries_) { entry.used = 0U; }
        clock_ = 0U;
    }
    return ++clock_;
}
std::optional<EvidenceRootCacheEntry> EvidenceRootCache::get(
    const datacube::Digest32& key, const std::uint64_t version) {
    for (auto& entry : entries_) {
        if (entry.key == key && entry.version == version) { entry.used = tick(); return entry; }
    }
    return std::nullopt;
}
void EvidenceRootCache::put(EvidenceRootCacheEntry value) {
    value.used = tick();
    for (auto& entry : entries_) { if (entry.key == value.key) { entry = value; return; } }
    if (entries_.size() < capacity) {
        if (entries_.capacity() == 0U) { entries_.reserve(capacity); }
        entries_.push_back(value);
    } else {
        *std::min_element(entries_.begin(), entries_.end(), [](const auto& a, const auto& b) {
            return a.used < b.used;
        }) = value;
    }
}
std::size_t EvidenceRootCache::allocated_bytes() const noexcept {
    return entries_.capacity() * sizeof(EvidenceRootCacheEntry);
}
} // namespace natrav_overlay
