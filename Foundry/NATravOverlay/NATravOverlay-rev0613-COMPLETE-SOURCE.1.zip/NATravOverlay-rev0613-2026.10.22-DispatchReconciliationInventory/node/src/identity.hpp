#pragma once

#include "tls.hpp"

#include <cstdint>
#include <filesystem>
#include <string>

namespace natrav_overlay {

struct IdentityCreateOptions final {
    std::filesystem::path directory;
    std::string node_id;
    std::string generation;
    std::uint32_t validity_days{3'650U};
};

struct IdentityCreateResult final {
    std::filesystem::path directory;
    std::filesystem::path certificate;
    std::filesystem::path private_key;
    std::filesystem::path metadata;
    std::string node_id;
    std::string generation;
    datacube::Digest32 spki_sha256;
    std::uint32_t validity_days{0U};
};

[[nodiscard]] IdentityCreateResult create_identity(
    const IdentityCreateOptions& options);
[[nodiscard]] std::string identity_create_result_json(
    const IdentityCreateResult& result);

}  // namespace natrav_overlay
