#include "custody_promotion.hpp"

#include "common.hpp"
#include "journal.hpp"
#include "state_auth.hpp"

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <fcntl.h>
#include <filesystem>
#include <memory>
#include <string>
#include <string_view>
#include <sys/file.h>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>
#include <utility>

namespace natrav_overlay {
namespace {

[[nodiscard]] datacube::Octets read_from_start(
    const int fd, const std::uint64_t maximum, const std::string_view operation) {
    if (::lseek(fd, 0, SEEK_SET) < 0) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_SOURCE_READ_FAILED",
            datacube::errno_detail(operation, errno));
    }
    return datacube::read_all_fd(fd, maximum, std::string(operation));
}

[[nodiscard]] bool exact_private_regular(const struct stat& value) noexcept {
    return S_ISREG(value.st_mode) && value.st_uid == ::geteuid() &&
        value.st_nlink == 1 && (value.st_mode & 07777U) == 0600U;
}

[[nodiscard]] bool same_file_identity(
    const struct stat& left, const struct stat& right) noexcept {
    return left.st_dev == right.st_dev && left.st_ino == right.st_ino &&
        left.st_uid == right.st_uid && left.st_mode == right.st_mode &&
        left.st_nlink == right.st_nlink && left.st_size == right.st_size &&
        left.st_mtim.tv_sec == right.st_mtim.tv_sec &&
        left.st_mtim.tv_nsec == right.st_mtim.tv_nsec &&
        left.st_ctim.tv_sec == right.st_ctim.tv_sec &&
        left.st_ctim.tv_nsec == right.st_ctim.tv_nsec;
}

[[nodiscard]] datacube::Fd open_directory_without_links(
    const std::filesystem::path& input) {
    if (input.empty()) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_SOURCE_UNSAFE",
            "state directory path is required");
    }
    for (const auto& component : input) {
        if (component == "..") {
            app_fail("STATE_HEAD_CUSTODY_PROMOTION_SOURCE_UNSAFE",
                "state directory dot-dot components are rejected");
        }
    }
    const auto absolute = std::filesystem::absolute(input).lexically_normal();
    datacube::Fd current(::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC));
    if (!current) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_SOURCE_UNSAFE",
            "cannot open root directory");
    }
    for (const auto& component_path : absolute.relative_path()) {
        const auto component = component_path.string();
        if (component.empty() || component == ".") { continue; }
        const int next = ::openat(current.get(), component.c_str(),
            O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
        if (next < 0) {
            app_fail("STATE_HEAD_CUSTODY_PROMOTION_SOURCE_UNSAFE",
                "state directory ancestry must exist without symbolic links");
        }
        current.reset(next);
    }
    struct stat status {};
    if (::fstat(current.get(), &status) != 0 || !S_ISDIR(status.st_mode) ||
        status.st_uid != ::geteuid() || (status.st_mode & 07777U) != 0700U) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_SOURCE_UNSAFE",
            "state directory must be owned by the effective user with exact mode 0700");
    }
    return current;
}

[[nodiscard]] datacube::Fd open_private_at(
    const int parent, const char* name, const std::string_view operation) {
    const int raw = ::openat(parent, name,
        O_RDONLY | O_NONBLOCK | O_NOFOLLOW | O_NOATIME | O_CLOEXEC);
    if (raw < 0) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_SOURCE_UNSAFE",
            datacube::errno_detail(operation, errno));
    }
    datacube::Fd fd(raw);
    struct stat status {};
    if (::fstat(fd.get(), &status) != 0 || !exact_private_regular(status)) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_SOURCE_UNSAFE",
            std::string(operation) + " must be an owned mode-0600 single-link regular file");
    }
    return fd;
}

void lock_exclusive(const int fd) {
    if (::flock(fd, LOCK_EX | LOCK_NB) != 0) {
        app_fail(errno == EWOULDBLOCK ? "STATE_BUSY" :
            "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_LOCK_FAILED",
            "exclusive existing-state ownership is required for custody promotion");
    }
}

struct LockedStatePromotionSource final {
    StateAuditOptions options;
    std::filesystem::path absolute;
    datacube::Fd directory;
    datacube::Fd lock;
    datacube::Fd journal;
    datacube::Octets bytes;
    struct stat journal_identity {};
    datacube::Digest32 source_digest;

    explicit LockedStatePromotionSource(StateAuditOptions value)
        : options(std::move(value)),
          absolute(std::filesystem::absolute(options.directory).lexically_normal()),
          directory(open_directory_without_links(options.directory)) {
        require_node_id(options.node, "custody promotion node");
        if (options.maximum_bytes < 1'024U ||
            options.maximum_bytes > 1'073'741'824U) {
            app_fail("INVALID_JOURNAL_LIMIT",
                "journal limit is outside 1024..1GiB");
        }
        if (!process_state_auth_key()) {
            app_fail("STATE_AUTH_KEY_REQUIRED",
                "state-directory custody promotion requires the exact state authentication key");
        }
        lock = open_private_at(directory.get(), "state.lock", "state lock");
        lock_exclusive(lock.get());
        const auto meta = open_private_at(directory.get(), "node.meta", "node metadata");
        const auto meta_bytes = read_from_start(meta.get(), 512U, "node metadata");
        const std::string expected = "NATRAV_OVERLAY_NODE_STATE_V2\nnode=" +
            options.node + "\nstorage_schema=2\n";
        if (meta_bytes != datacube::text_octets(expected)) {
            app_fail("STATE_AUTH_SCHEMA_REQUIRED",
                "schema-2 metadata for the exact promotion node is required");
        }
        journal = open_private_at(directory.get(), "state.journal", "state journal");
        lock_exclusive(journal.get());
        if (::fstat(journal.get(), &journal_identity) != 0 ||
            journal_identity.st_size <= 0 ||
            static_cast<std::uint64_t>(journal_identity.st_size) > options.maximum_bytes) {
            app_fail("STATE_AUTH_LIMIT",
                "promotion source journal is empty, invalid, or exceeds its explicit limit");
        }
        bytes = read_from_start(journal.get(), options.maximum_bytes,
            "custody promotion state journal");
        if (bytes.size() != static_cast<std::size_t>(journal_identity.st_size)) {
            app_fail("STATE_AUTH_SOURCE_CHANGED",
                "promotion source size changed during read");
        }
        source_digest = datacube::sha256(bytes);
    }

    void unchanged() const {
        struct stat named {};
        struct stat opened {};
        if (::fstatat(directory.get(), "state.journal", &named,
                AT_SYMLINK_NOFOLLOW) != 0 ||
            ::fstat(journal.get(), &opened) != 0 ||
            !same_file_identity(journal_identity, named) ||
            !same_file_identity(journal_identity, opened) ||
            !exact_private_regular(named) ||
            read_from_start(journal.get(), options.maximum_bytes,
                "custody promotion state recheck") != bytes) {
            app_fail("STATE_AUTH_SOURCE_CHANGED",
                "state source changed before custody publication");
        }
    }
};

struct BackupPromotionSource final {
    std::filesystem::path path;
    std::uint64_t ceiling{0U};
    datacube::Fd fd;
    struct stat identity {};
    datacube::Octets bytes;
    datacube::Digest32 digest;

    BackupPromotionSource(const std::filesystem::path& input,
        const std::uint64_t maximum_journal_bytes)
        : path(std::filesystem::absolute(input).lexically_normal()),
          ceiling(maximum_journal_bytes + 2U * 1'048'576U + 256U) {
        if (input.empty()) {
            app_fail("BACKUP_PATH_INVALID", "promotion backup input is required");
        }
        for (const auto& component : input) {
            if (component == "..") {
                app_fail("BACKUP_PATH_INVALID",
                    "promotion backup input must not contain dot-dot");
            }
        }
        const int raw = ::open(path.c_str(),
            O_RDONLY | O_NONBLOCK | O_NOFOLLOW | O_CLOEXEC);
        if (raw < 0) {
            app_fail("BACKUP_FILE_OPEN_FAILED",
                datacube::errno_detail(path.string(), errno));
        }
        fd.reset(raw);
        if (::flock(fd.get(), LOCK_SH | LOCK_NB) != 0) {
            app_fail(errno == EWOULDBLOCK ? "BACKUP_BUSY" :
                "BACKUP_FILE_LOCK_FAILED",
                "backup source lock is unavailable");
        }
        if (::fstat(fd.get(), &identity) != 0 || !S_ISREG(identity.st_mode) ||
            identity.st_uid != ::geteuid() || identity.st_size <= 0 ||
            static_cast<std::uint64_t>(identity.st_size) > ceiling) {
            app_fail("BACKUP_FILE_INVALID",
                "promotion backup must be a bounded regular file owned by the effective user");
        }
        bytes = read_from_start(fd.get(), ceiling, "custody promotion backup");
        if (bytes.size() != static_cast<std::size_t>(identity.st_size)) {
            app_fail("BACKUP_SOURCE_CHANGED",
                "backup size changed during promotion read");
        }
        digest = datacube::sha256(bytes);
    }

    void unchanged() const {
        struct stat named {};
        struct stat opened {};
        if (::lstat(path.c_str(), &named) != 0 ||
            ::fstat(fd.get(), &opened) != 0 ||
            !same_file_identity(identity, named) ||
            !same_file_identity(identity, opened) ||
            !S_ISREG(named.st_mode) || named.st_uid != ::geteuid() ||
            read_from_start(fd.get(), ceiling,
                "custody promotion backup recheck") != bytes) {
            app_fail("BACKUP_SOURCE_CHANGED",
                "backup source changed before custody publication");
        }
    }
};

struct SuccessorAssessment final {
    bool eligible{false};
    std::string relationship;
    std::string ineligibility_code;
    std::string detail;
};

[[nodiscard]] SuccessorAssessment eligible_successor(
    const std::string_view relationship) {
    return SuccessorAssessment{
        .eligible = true,
        .relationship = std::string(relationship),
        .ineligibility_code = {},
        .detail = {},
    };
}

[[nodiscard]] SuccessorAssessment ineligible_successor(
    const std::string_view relationship,
    const std::string_view code,
    const std::string_view detail) {
    return SuccessorAssessment{
        .eligible = false,
        .relationship = std::string(relationship),
        .ineligibility_code = std::string(code),
        .detail = std::string(detail),
    };
}

[[nodiscard]] SuccessorAssessment assess_successor(
    const StateHeadExpectation& previous,
    const std::string_view node,
    const StateAuthentication& current,
    const std::uint64_t current_bytes,
    const datacube::OctetView source_bytes,
    const std::uint64_t maximum_bytes,
    const StateAuthKeyPtr& key) {
    if (previous.node != node || current.records == 0U || current_bytes == 0U) {
        return ineligible_successor("AUTHENTICATED_SOURCE_MISMATCH",
            "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_MISMATCH",
            "promotion source node or authenticated head is invalid");
    }
    if (matches_state_head(previous, node, current, current_bytes)) {
        return ineligible_successor("EXACT_CURRENT_HEAD_NOOP",
            "STATE_HEAD_CUSTODY_PROMOTION_NOOP",
            "old custody already names the exact authenticated input head");
    }

    if (previous.generation == current.generation &&
        previous.key_id == current.key_id && previous.epoch == current.epoch) {
        if (current.records <= previous.records ||
            current_bytes <= previous.journal_bytes ||
            previous.journal_bytes > source_bytes.size()) {
            return ineligible_successor("AUTHENTICATED_SOURCE_STALE",
                "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_STALE",
                "authenticated source does not advance the old append-only head");
        }
#if defined(NATRAV_CUSTODY_PROMOTION_OMIT_PREFIX_RELATION)
        static_cast<void>(maximum_bytes);
        static_cast<void>(key);
#else
        try {
            const auto prefix = source_bytes.first(
                static_cast<std::size_t>(previous.journal_bytes));
            const auto verified = verify_authenticated_journal(
                prefix, node, key, maximum_bytes);
            static_cast<void>(NodeState::checkpoint_authenticated_prefix(
                prefix, std::string(node), maximum_bytes, key));
            if (!matches_state_head(previous, node,
                    verified.authentication, previous.journal_bytes)) {
                return ineligible_successor("AUTHENTICATED_SOURCE_DIVERGENT",
                    "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_DIVERGENT",
                    "same-epoch source does not contain the exact old authenticated prefix");
            }
        } catch (const AppError&) {
            return ineligible_successor("AUTHENTICATED_SOURCE_DIVERGENT",
                "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_DIVERGENT",
                "same-epoch source does not contain a valid exact old authenticated prefix");
        }
#endif
        return eligible_successor("VERIFIED_APPEND_ONLY_EXTENSION");
    }

    if (current.parent_root == previous.root) {
        if (current.purpose == "ROTATE") {
            const bool old_key_retained = std::any_of(
                current.history.begin(), current.history.end(),
                [&](const StateAuthTransition& transition) {
                    return transition.generation == previous.generation &&
                        transition.key_id == previous.key_id;
                });
            if (!old_key_retained || current.history.empty() ||
                current.history.back().kind != "ROTATE" ||
                current.history.back().source_root != previous.root) {
                return ineligible_successor("AUTHENTICATED_SOURCE_DIVERGENT",
                    "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_DIVERGENT",
                    "rotated source does not retain the exact old authenticated key lineage");
            }
        } else if (current.purpose == "COMPACT" ||
            current.purpose == "BACKUP" || current.purpose == "RECOVER") {
            if (current.generation != previous.generation ||
                current.key_id != previous.key_id) {
                return ineligible_successor("AUTHENTICATED_SOURCE_DIVERGENT",
                    "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_DIVERGENT",
                    "checkpoint successor unexpectedly changes the authentication key");
            }
        } else {
            return ineligible_successor("AUTHENTICATED_SOURCE_DIVERGENT",
                "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_DIVERGENT",
                "authenticated parent relation has an unsupported transition purpose");
        }
        return eligible_successor("VERIFIED_AUTHENTICATED_CHECKPOINT_SUCCESSOR");
    }

    return ineligible_successor("AUTHENTICATED_SOURCE_DIVERGENT",
        "STATE_HEAD_CUSTODY_PROMOTION_SOURCE_DIVERGENT",
        "authenticated input is neither an exact append extension nor a direct checkpoint successor");
}

void test_pause_before_backup_verification() {
    if (const char* raw = std::getenv(
            "NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_PAUSE_BEFORE_BACKUP_VERIFY_MS")) {
        const auto delay = parse_u64(raw, "backup promotion test pause", 1U, 10'000U);
        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    }
}

[[nodiscard]] std::string digest_json(const datacube::Digest32& value) {
    return json_string(datacube::hex_lower(value));
}

struct ValidatedPromotionSource final {
    StateAuthentication authentication;
    std::uint64_t journal_bytes{0U};
    SuccessorAssessment assessment;
    StateHeadCustodyPromotionSourceAccount account;
    std::string source_json;
    std::function<void()> recheck;
    std::shared_ptr<void> lifetime;
};

void require_eligible(const ValidatedPromotionSource& source) {
    if (!source.assessment.eligible) {
        app_fail(source.assessment.ineligibility_code, source.assessment.detail);
    }
}

[[nodiscard]] ValidatedPromotionSource validate_state_source(
    const StateAuditOptions& options, const StateHeadExpectation& previous) {
    auto effective = options;
    if (effective.node.empty()) { effective.node = previous.node; }
    auto source = std::make_shared<LockedStatePromotionSource>(effective);
    const auto scan = scan_authenticated_journal(source->bytes,
        effective.node, process_state_auth_key(), effective.maximum_bytes);
    if (!scan.header_authenticated || scan.status != "COMPLETE" ||
        scan.verified_bytes != source->bytes.size() ||
        scan.verified.authentication.records == 0U) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_SOURCE_INVALID",
            "custody promotion requires one complete authenticated journal");
    }
    const auto checkpoint = NodeState::checkpoint_authenticated_prefix(
        source->bytes, effective.node, effective.maximum_bytes,
        process_state_auth_key());
    const auto assessment = assess_successor(previous,
        effective.node, scan.verified.authentication, scan.verified_bytes,
        source->bytes, effective.maximum_bytes, process_state_auth_key());
    const auto selector = state_head_selector(effective.node,
        scan.verified.authentication, scan.verified_bytes);
    const std::string source_json =
        std::string("{\"kind\":\"STATE_DIRECTORY\",\"status\":") +
        json_string("COMPLETE_AUTHENTICATED_SEMANTIC_REPLAY") +
        ",\"path\":" + json_string(source->absolute.string()) +
        ",\"journal_bytes\":" + std::to_string(source->bytes.size()) +
        ",\"journal_sha256\":" + digest_json(source->source_digest) +
        ",\"logical_state_digest\":" +
        digest_json(checkpoint.logical_state_digest) +
        ",\"state_head\":" + json_string(selector) +
        ",\"exclusive_existing_state_lock\":true," +
        "\"writer_opened\":false,\"workers_started\":false," +
        "\"state_mutated\":false}";
    return ValidatedPromotionSource{
        .authentication = scan.verified.authentication,
        .journal_bytes = scan.verified_bytes,
        .assessment = assessment,
        .account = StateHeadCustodyPromotionSourceAccount{
            .kind = StateHeadCustodyPromotionSourceKind::state_directory,
            .canonical_path = source->absolute,
            .representation_bytes = static_cast<std::uint64_t>(source->bytes.size()),
            .representation_digest = source->source_digest,
            .authenticated_bytes = scan.verified_bytes,
            .authenticated_digest = source->source_digest,
            .logical_state_digest = checkpoint.logical_state_digest,
            .identity_generation = std::nullopt,
            .backup_id = std::nullopt,
            .signer_spki_sha256 = std::nullopt,
            .encryption_key_generation = std::nullopt,
            .encryption_key_id = std::nullopt,
        },
        .source_json = source_json,
        .recheck = [source] { source->unchanged(); },
        .lifetime = source,
    };
}

[[nodiscard]] ValidatedPromotionSource validate_backup_source(
    const BackupVerifyOptions& options, const StateHeadExpectation& previous) {
    if (!process_state_auth_key()) {
        app_fail("STATE_AUTH_KEY_REQUIRED",
            "backup custody promotion requires the embedded checkpoint authentication key");
    }
    auto source = std::make_shared<BackupPromotionSource>(
        options.input_file, options.maximum_journal_bytes);
    test_pause_before_backup_verification();
    const auto verified = verify_backup_exact_input(
        options, source->bytes.size(), source->digest);
    if (!verified.encrypted || !verified.encryption_authenticated ||
        !verified.signed_backup || !verified.signature_valid ||
        !verified.trusted_signer || !verified.signer_spki_sha256 ||
        !verified.encryption_key || !verified.state_authentication ||
        verified.checkpoint_bytes == 0U ||
        verified.file_bytes != source->bytes.size()) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_BACKUP_TRUST_REQUIRED",
            "backup custody promotion requires an exact signed encrypted authenticated checkpoint");
    }
    const auto assessment = assess_successor(previous,
        verified.node_id, *verified.state_authentication,
        verified.checkpoint_bytes, {}, options.maximum_journal_bytes,
        process_state_auth_key());
    const auto selector = state_head_selector(verified.node_id,
        *verified.state_authentication, verified.checkpoint_bytes);
    const std::string source_json =
        std::string("{\"kind\":\"SIGNED_ENCRYPTED_BACKUP\",\"status\":") +
        json_string("COMPLETE_SIGNED_ENCRYPTED_CHECKPOINT_AUTHENTICATED_SEMANTIC_REPLAY") +
        ",\"path\":" + json_string(source->path.string()) +
        ",\"file_bytes\":" + std::to_string(source->bytes.size()) +
        ",\"file_sha256\":" + digest_json(source->digest) +
        ",\"backup_id\":" + digest_json(verified.backup_id) +
        ",\"identity_generation\":" +
        json_string(verified.identity_generation) +
        ",\"checkpoint_bytes\":" +
        std::to_string(verified.checkpoint_bytes) +
        ",\"checkpoint_sha256\":" +
        digest_json(verified.checkpoint_digest) +
        ",\"state_head\":" + json_string(selector) +
        ",\"signed\":true,\"trusted_signer\":true," +
        "\"encrypted\":true,\"encryption_authenticated\":true," +
        "\"restore_performed\":false,\"writer_opened\":false," +
        "\"workers_started\":false,\"state_mutated\":false}";
    return ValidatedPromotionSource{
        .authentication = *verified.state_authentication,
        .journal_bytes = verified.checkpoint_bytes,
        .assessment = assessment,
        .account = StateHeadCustodyPromotionSourceAccount{
            .kind = StateHeadCustodyPromotionSourceKind::signed_encrypted_backup,
            .canonical_path = source->path,
            .representation_bytes = static_cast<std::uint64_t>(source->bytes.size()),
            .representation_digest = source->digest,
            .authenticated_bytes = verified.checkpoint_bytes,
            .authenticated_digest = verified.checkpoint_digest,
            .logical_state_digest = verified.logical_state_digest,
            .identity_generation = verified.identity_generation,
            .backup_id = verified.backup_id,
            .signer_spki_sha256 = *verified.signer_spki_sha256,
            .encryption_key_generation = verified.encryption_key->generation,
            .encryption_key_id = verified.encryption_key->id,
        },
        .source_json = source_json,
        .recheck = [source] { source->unchanged(); },
        .lifetime = source,
    };
}

[[nodiscard]] StateHeadCustodyPromotionCandidate promotion_candidate(
    ValidatedPromotionSource source) {
    require_eligible(source);
    return StateHeadCustodyPromotionCandidate{
        .authentication = std::move(source.authentication),
        .journal_bytes = source.journal_bytes,
        .relationship = std::move(source.assessment.relationship),
        .source_account = std::move(source.account),
        .source_json = std::move(source.source_json),
        .prepublication_recheck = std::move(source.recheck),
        .source_lifetime = std::move(source.lifetime),
    };
}

[[nodiscard]] StateHeadCustodyPromotionAuditCandidate audit_candidate(
    ValidatedPromotionSource source) {
    return StateHeadCustodyPromotionAuditCandidate{
        .authentication = std::move(source.authentication),
        .journal_bytes = source.journal_bytes,
        .eligible = source.assessment.eligible,
        .relationship = std::move(source.assessment.relationship),
        .ineligibility_code = std::move(source.assessment.ineligibility_code),
        .ineligibility_detail = std::move(source.assessment.detail),
        .source_account = std::move(source.account),
        .source_json = std::move(source.source_json),
        .final_recheck = std::move(source.recheck),
        .source_lifetime = std::move(source.lifetime),
    };
}

}  // namespace

std::string promote_state_head_custody_from_state(
    const StateDirectoryCustodyPromotionOptions& options) {
    return promote_state_head_custody_record(options.custody,
        [&](const StateHeadExpectation& previous) {
            return promotion_candidate(validate_state_source(
                options.source, previous));
        });
}

std::string promote_state_head_custody_from_backup(
    const BackupCustodyPromotionOptions& options) {
    return promote_state_head_custody_record(options.custody,
        [&](const StateHeadExpectation& previous) {
            return promotion_candidate(validate_backup_source(
                options.source, previous));
        });
}

std::string audit_state_head_custody_promotion_from_state(
    const StateDirectoryCustodyPromotionAuditOptions& options) {
    return audit_state_head_custody_promotion_outcome(options.custody,
        [&](const StateHeadExpectation& previous) {
            return audit_candidate(validate_state_source(
                options.source, previous));
        });
}

std::string audit_state_head_custody_promotion_from_backup(
    const BackupCustodyPromotionAuditOptions& options) {
    return audit_state_head_custody_promotion_outcome(options.custody,
        [&](const StateHeadExpectation& previous) {
            return audit_candidate(validate_backup_source(
                options.source, previous));
        });
}

std::string create_state_head_custody_promotion_intent_from_state(
    const StateDirectoryCustodyPromotionIntentCreateOptions& options) {
    return create_state_head_custody_promotion_intent(options.intent,
        [&](const StateHeadExpectation& previous) {
            return promotion_candidate(validate_state_source(
                options.source, previous));
        });
}

std::string create_state_head_custody_promotion_intent_from_backup(
    const BackupCustodyPromotionIntentCreateOptions& options) {
    return create_state_head_custody_promotion_intent(options.intent,
        [&](const StateHeadExpectation& previous) {
            return promotion_candidate(validate_backup_source(
                options.source, previous));
        });
}

std::string promote_state_head_custody_from_state_with_intent(
    const StateDirectoryCustodyPromotionIntentUseOptions& options) {
    return promote_state_head_custody_record_with_intent(options.intent,
        [&](const StateHeadExpectation& previous) {
            return promotion_candidate(validate_state_source(
                options.source, previous));
        });
}

std::string promote_state_head_custody_from_backup_with_intent(
    const BackupCustodyPromotionIntentUseOptions& options) {
    return promote_state_head_custody_record_with_intent(options.intent,
        [&](const StateHeadExpectation& previous) {
            return promotion_candidate(validate_backup_source(
                options.source, previous));
        });
}

std::string audit_state_head_custody_promotion_from_state_with_intent(
    const StateDirectoryCustodyPromotionIntentUseOptions& options) {
    return audit_state_head_custody_promotion_outcome_with_intent(options.intent,
        [&](const StateHeadExpectation& previous) {
            return audit_candidate(validate_state_source(
                options.source, previous));
        });
}

std::string audit_state_head_custody_promotion_from_backup_with_intent(
    const BackupCustodyPromotionIntentUseOptions& options) {
    return audit_state_head_custody_promotion_outcome_with_intent(options.intent,
        [&](const StateHeadExpectation& previous) {
            return audit_candidate(validate_backup_source(
                options.source, previous));
        });
}

}  // namespace natrav_overlay
