#include "custody_dispatch_policy.hpp"

#include "adapter_configuration.hpp"

#include <algorithm>
#include <limits>
#include <set>
#include <tuple>

namespace natrav_overlay {
namespace {

constexpr std::size_t kActivationTextLimit = 2'048U;

void require(const bool condition, const std::string_view code,
    const std::string_view detail) {
    if (!condition) { app_fail(code, detail); }
}

void validate_activation(const CustodyDispatchActivation& activation) {
    require(valid_generation_id(activation.id),
        "CONFIG_CUSTODY_DISPATCH_INVALID",
        "dispatch activation id is invalid");
    require(activation.generation > 0U &&
            activation.generation <= kCustodyDispatchActivationPerIdLimit,
        "CONFIG_CUSTODY_DISPATCH_GENERATION",
        "dispatch activation generation is outside the retained bound");
    require(activation.state == CustodyDispatchActivationState::active ||
            activation.state == CustodyDispatchActivationState::retired ||
            activation.state == CustodyDispatchActivationState::revoked,
        "CONFIG_CUSTODY_DISPATCH_STATE",
        "unknown dispatch activation lifecycle state");
    require(valid_generation_id(activation.receiver_activation_id) &&
            activation.receiver_activation_generation > 0U &&
            activation.receiver_activation_generation <=
                kCustodyReceiverActivationPerIdLimit &&
            !digest_is_zero(activation.receiver_activation_commitment),
        "CONFIG_CUSTODY_DISPATCH_RECEIVER",
        "dispatch activation requires one exact nonzero V23 receiver reference");
    require(valid_generation_id(activation.outbound_session_rule_id) &&
            activation.outbound_session_rule_generation > 0U &&
            activation.outbound_session_rule_generation <=
                kCustodySessionRulePerIdLimit &&
            !digest_is_zero(activation.outbound_session_rule_commitment),
        "CONFIG_CUSTODY_DISPATCH_RULE",
        "dispatch activation requires one exact nonzero outbound V22 rule reference");
    require(valid_generation_id(activation.route_id) &&
            !digest_is_zero(activation.route_commitment),
        "CONFIG_CUSTODY_DISPATCH_ROUTE",
        "dispatch activation requires one exact named route commitment");
    require(activation.maximum_concurrent_dispatches > 0U &&
            activation.maximum_concurrent_dispatches <=
                kCustodyDispatchMaximumConcurrent,
        "CONFIG_CUSTODY_DISPATCH_LIMIT",
        "dispatch concurrency bound is outside the finite envelope");
    require(activation.maximum_dispatch_attempts > 0U &&
            activation.maximum_dispatch_attempts <=
                kCustodyDispatchMaximumAttempts,
        "CONFIG_CUSTODY_DISPATCH_LIMIT",
        "dispatch attempt bound is outside the finite envelope");
    require(activation.activation_expires_unix_ms > 0U,
        "CONFIG_CUSTODY_DISPATCH_LIMIT",
        "dispatch activation expiry must be positive");
}

std::string field_value(const std::string& text, std::size_t& offset,
    const std::string_view prefix) {
    const auto end = text.find('\n', offset);
    require(end != std::string::npos,
        "CONFIG_CUSTODY_DISPATCH_NONCANONICAL",
        "complete canonical line required");
    const auto line = std::string_view(text).substr(offset, end - offset);
    require(line.starts_with(prefix),
        "CONFIG_CUSTODY_DISPATCH_NONCANONICAL",
        "canonical dispatch-activation field order required");
    offset = end + 1U;
    return std::string(line.substr(prefix.size()));
}

CustodyDispatchActivationState parse_state(const std::string_view value) {
    if (value == "ACTIVE") {
        return CustodyDispatchActivationState::active;
    }
    if (value == "RETIRED") {
        return CustodyDispatchActivationState::retired;
    }
    if (value == "REVOKED") {
        return CustodyDispatchActivationState::revoked;
    }
    app_fail("CONFIG_CUSTODY_DISPATCH_STATE",
        "dispatch lifecycle must be ACTIVE, RETIRED or REVOKED");
}

const CustodyDispatchActivation* find_exact(
    const CustodyDispatchPolicy& policy,
    const std::string_view id,
    const std::uint64_t generation) noexcept {
    const auto found = std::find_if(policy.begin(), policy.end(),
        [&](const CustodyDispatchActivation& activation) {
            return activation.id == id &&
                activation.generation == generation;
        });
    return found == policy.end() ? nullptr : &*found;
}

} // namespace

std::string_view custody_dispatch_activation_state_name(
    const CustodyDispatchActivationState state) {
    switch (state) {
        case CustodyDispatchActivationState::active: return "ACTIVE";
        case CustodyDispatchActivationState::retired: return "RETIRED";
        case CustodyDispatchActivationState::revoked: return "REVOKED";
    }
    app_fail("CONFIG_CUSTODY_DISPATCH_STATE",
        "unknown dispatch activation lifecycle state");
}

std::string custody_dispatch_route_commitment_text(
    const std::string_view peer_node,
    const std::string_view route_id,
    const std::string_view locator,
    const std::uint32_t priority) {
    require(valid_generation_id(peer_node) && valid_generation_id(route_id) &&
            !locator.empty() && locator.size() <= 1'024U,
        "CONFIG_CUSTODY_DISPATCH_ROUTE",
        "route commitment inputs are invalid");
    return "NATRAV_CUSTODY_DISPATCH_ROUTE_COMMITMENT_V1\npeer_node=" +
        std::string(peer_node) + "\nroute_id=" + std::string(route_id) +
        "\nlocator=" + std::string(locator) + "\npriority=" +
        std::to_string(priority) + "\nstate=ENABLED\n";
}

datacube::Digest32 custody_dispatch_route_commitment(
    const std::string_view peer_node,
    const std::string_view route_id,
    const std::string_view locator,
    const std::uint32_t priority) {
    const auto text = custody_dispatch_route_commitment_text(
        peer_node, route_id, locator, priority);
    return datacube::sha256(datacube::OctetView(
        reinterpret_cast<const std::uint8_t*>(text.data()), text.size()));
}

std::string custody_dispatch_activation_commitment_text(
    const CustodyDispatchActivation& activation) {
    validate_activation(activation);
    return "NATRAV_CUSTODY_DISPATCH_ACTIVATION_COMMITMENT_V1\n"
        "id=" + activation.id +
        "\ngeneration=" + std::to_string(activation.generation) +
        "\npredecessor_sha256=" + operation_id_text(activation.predecessor) +
        "\nreceiver_activation_id=" + activation.receiver_activation_id +
        "\nreceiver_activation_generation=" +
            std::to_string(activation.receiver_activation_generation) +
        "\nreceiver_activation_commitment_sha256=" +
            operation_id_text(activation.receiver_activation_commitment) +
        "\noutbound_session_rule_id=" +
            activation.outbound_session_rule_id +
        "\noutbound_session_rule_generation=" +
            std::to_string(activation.outbound_session_rule_generation) +
        "\noutbound_session_rule_commitment_sha256=" +
            operation_id_text(activation.outbound_session_rule_commitment) +
        "\nroute_id=" + activation.route_id +
        "\nroute_commitment_sha256=" +
            operation_id_text(activation.route_commitment) +
        "\nmaximum_concurrent_dispatches=" +
            std::to_string(activation.maximum_concurrent_dispatches) +
        "\nmaximum_dispatch_attempts=" +
            std::to_string(activation.maximum_dispatch_attempts) +
        "\nactivation_expires_unix_ms=" +
            std::to_string(activation.activation_expires_unix_ms) + "\n";
}

datacube::Digest32 custody_dispatch_activation_commitment(
    const CustodyDispatchActivation& activation) {
    const auto text = custody_dispatch_activation_commitment_text(activation);
    return datacube::sha256(datacube::OctetView(
        reinterpret_cast<const std::uint8_t*>(text.data()), text.size()));
}

std::string custody_dispatch_activation_text(
    const CustodyDispatchActivation& activation) {
    const auto immutable = custody_dispatch_activation_commitment_text(activation);
    return "NATRAV_CUSTODY_DISPATCH_ACTIVATION_V1\n" +
        immutable.substr(immutable.find('\n') + 1U) +
        "state=" + std::string(
            custody_dispatch_activation_state_name(activation.state)) + "\n";
}

CustodyDispatchActivation parse_custody_dispatch_activation(
    const std::string_view hex) {
    require(hex.size() <= 2U * kActivationTextLimit,
        "CONFIG_CUSTODY_DISPATCH_INVALID",
        "dispatch activation byte bound");
    const auto raw = decode_adapter_configuration_record_hex(hex);
    require(raw.size() <= kActivationTextLimit &&
            std::all_of(raw.begin(), raw.end(), [](const char value) {
                const auto ch = static_cast<unsigned char>(value);
                return ch > 0U && ch < 128U;
            }),
        "CONFIG_CUSTODY_DISPATCH_NONCANONICAL",
        "canonical dispatch activation requires ASCII without NUL");
    const std::string text(raw.begin(), raw.end());
    std::size_t offset = 0U;
    require(field_value(text, offset,
                "NATRAV_CUSTODY_DISPATCH_ACTIVATION_V1").empty(),
        "CONFIG_CUSTODY_DISPATCH_NONCANONICAL",
        "dispatch activation header");
    CustodyDispatchActivation activation;
    activation.id = field_value(text, offset, "id=");
    activation.generation = parse_u64(
        field_value(text, offset, "generation="),
        "custody dispatch generation", 1U,
        kCustodyDispatchActivationPerIdLimit);
    const auto predecessor = field_value(text, offset, "predecessor_sha256=");
    activation.predecessor = predecessor == std::string(64U, '0') ?
        datacube::Digest32{} : parse_operation_id(predecessor);
    activation.receiver_activation_id = field_value(
        text, offset, "receiver_activation_id=");
    activation.receiver_activation_generation = parse_u64(
        field_value(text, offset, "receiver_activation_generation="),
        "custody dispatch V23 generation", 1U,
        kCustodyReceiverActivationPerIdLimit);
    activation.receiver_activation_commitment = parse_operation_id(field_value(
        text, offset, "receiver_activation_commitment_sha256="));
    activation.outbound_session_rule_id = field_value(
        text, offset, "outbound_session_rule_id=");
    activation.outbound_session_rule_generation = parse_u64(
        field_value(text, offset, "outbound_session_rule_generation="),
        "custody dispatch V22 generation", 1U,
        kCustodySessionRulePerIdLimit);
    activation.outbound_session_rule_commitment = parse_operation_id(field_value(
        text, offset, "outbound_session_rule_commitment_sha256="));
    activation.route_id = field_value(text, offset, "route_id=");
    activation.route_commitment = parse_operation_id(field_value(
        text, offset, "route_commitment_sha256="));
    activation.maximum_concurrent_dispatches =
        static_cast<std::uint32_t>(parse_u64(
            field_value(text, offset, "maximum_concurrent_dispatches="),
            "custody dispatch concurrency", 1U,
            kCustodyDispatchMaximumConcurrent));
    activation.maximum_dispatch_attempts =
        static_cast<std::uint32_t>(parse_u64(
            field_value(text, offset, "maximum_dispatch_attempts="),
            "custody dispatch attempts", 1U,
            kCustodyDispatchMaximumAttempts));
    activation.activation_expires_unix_ms = parse_u64(
        field_value(text, offset, "activation_expires_unix_ms="),
        "custody dispatch activation expiry", 1U,
        std::numeric_limits<std::uint64_t>::max());
    activation.state = parse_state(field_value(text, offset, "state="));
    require(offset == text.size(),
        "CONFIG_CUSTODY_DISPATCH_NONCANONICAL",
        "trailing dispatch-activation bytes are forbidden");
    validate_activation(activation);
    require(custody_dispatch_activation_text(activation) == text,
        "CONFIG_CUSTODY_DISPATCH_NONCANONICAL",
        "dispatch activation is not in canonical form");
    return activation;
}

void normalize_custody_dispatch_policy(
    CustodyDispatchPolicy& activations) {
    require(activations.size() <= kCustodyDispatchActivationLimit,
        "CONFIG_CUSTODY_DISPATCH_CAPACITY",
        "retained dispatch-activation count exceeded");
    std::sort(activations.begin(), activations.end(),
        [](const CustodyDispatchActivation& left,
           const CustodyDispatchActivation& right) {
            return std::tie(left.id, left.generation) <
                std::tie(right.id, right.generation);
        });
    std::set<std::pair<std::string, std::uint64_t>> identities;
    const CustodyDispatchActivation* previous = nullptr;
    std::size_t active_count = 0U;
    for (const auto& activation : activations) {
        validate_activation(activation);
        require(identities.emplace(
                activation.id, activation.generation).second,
            "CONFIG_CUSTODY_DISPATCH_CONFLICT",
            "duplicate dispatch activation id and generation");
        if (activation.state == CustodyDispatchActivationState::active) {
            ++active_count;
        }
        if (previous == nullptr || previous->id != activation.id) {
            require(activation.generation == 1U &&
                    digest_is_zero(activation.predecessor),
                "CONFIG_CUSTODY_DISPATCH_PREDECESSOR",
                "first dispatch generation requires zero predecessor");
        } else {
            require(activation.generation == previous->generation + 1U &&
                    activation.predecessor ==
                        custody_dispatch_activation_commitment(*previous),
                "CONFIG_CUSTODY_DISPATCH_PREDECESSOR",
                "exact consecutive immutable predecessor required");
            require(previous->state != CustodyDispatchActivationState::active,
                "CONFIG_CUSTODY_DISPATCH_ACTIVE_CONFLICT",
                "superseded dispatch activation must first be retired or revoked");
        }
        previous = &activation;
    }
    require(active_count <= 1U,
        "CONFIG_CUSTODY_DISPATCH_ACTIVE_CONFLICT",
        "at most one owner custody dispatch activation may be active");
}

void require_custody_dispatch_history_preserved(
    const CustodyDispatchPolicy& historical,
    const CustodyDispatchPolicy& candidate) {
    for (const auto& prior : historical) {
        const auto* next = find_exact(candidate, prior.id, prior.generation);
        require(next != nullptr,
            "CONFIG_CUSTODY_DISPATCH_HISTORY_REMOVED",
            "accepted dispatch activation must remain present");
        require(custody_dispatch_activation_commitment(*next) ==
                custody_dispatch_activation_commitment(prior),
            "CONFIG_CUSTODY_DISPATCH_CONFLICT",
            "accepted dispatch activation meaning cannot be redefined");
        require(static_cast<unsigned>(next->state) >=
                static_cast<unsigned>(prior.state),
            "CONFIG_CUSTODY_DISPATCH_STATE_ROLLBACK",
            "dispatch retirement and revocation are monotonic");
    }
}

const CustodyDispatchActivation* find_custody_dispatch_activation(
    const CustodyDispatchPolicy& policy,
    const std::string_view id,
    const std::uint64_t generation) noexcept {
    return find_exact(policy, id, generation);
}

const CustodyReceiverActivation& resolve_custody_dispatch_receiver_activation(
    const CustodyReceiverPolicy& receivers,
    const CustodyDispatchActivation& activation,
    const bool require_active) {
    validate_activation(activation);
    const auto* receiver = find_custody_receiver_activation(
        receivers, activation.receiver_activation_id,
        activation.receiver_activation_generation);
    require(receiver != nullptr &&
            custody_receiver_activation_commitment(*receiver) ==
                activation.receiver_activation_commitment,
        "CONFIG_CUSTODY_DISPATCH_RECEIVER",
        "dispatch activation names an absent or redefined V23 receiver");
    if (receiver->state == CustodyReceiverActivationState::revoked) {
        require(activation.state == CustodyDispatchActivationState::revoked,
            "CONFIG_CUSTODY_DISPATCH_RECEIVER_STATE",
            "a revoked V23 receiver requires a revoked dispatch activation");
    } else if (receiver->state == CustodyReceiverActivationState::retired) {
        require(activation.state != CustodyDispatchActivationState::active,
            "CONFIG_CUSTODY_DISPATCH_RECEIVER_STATE",
            "an active dispatch cannot retain a retired V23 receiver");
    }
    require(!require_active ||
            (receiver->state == CustodyReceiverActivationState::active &&
             activation.state == CustodyDispatchActivationState::active),
        "CONFIG_CUSTODY_DISPATCH_RETIRED",
        "new owner dispatch requires active V23 and V24 authority");
    return *receiver;
}

const CustodySessionRule& resolve_custody_dispatch_outbound_rule(
    const CustodySessionPolicy& rules,
    const CustodyDispatchActivation& activation,
    const bool require_active) {
    validate_activation(activation);
    const auto* rule = find_custody_session_rule(
        rules, activation.outbound_session_rule_id,
        activation.outbound_session_rule_generation);
    require(rule != nullptr &&
            custody_session_rule_commitment(*rule) ==
                activation.outbound_session_rule_commitment,
        "CONFIG_CUSTODY_DISPATCH_RULE",
        "dispatch activation names an absent or redefined outbound V22 rule");
    if (rule->state == CustodySessionRuleState::revoked) {
        require(activation.state == CustodyDispatchActivationState::revoked,
            "CONFIG_CUSTODY_DISPATCH_RULE_STATE",
            "a revoked outbound V22 rule requires a revoked dispatch activation");
    } else if (rule->state == CustodySessionRuleState::retired) {
        require(activation.state != CustodyDispatchActivationState::active,
            "CONFIG_CUSTODY_DISPATCH_RULE_STATE",
            "an active dispatch cannot retain a retired outbound V22 rule");
    }
    require(!require_active ||
            (rule->state == CustodySessionRuleState::active &&
             activation.state == CustodyDispatchActivationState::active),
        "CONFIG_CUSTODY_DISPATCH_RETIRED",
        "new owner dispatch requires active V22 and V24 authority");
    return *rule;
}

std::string custody_dispatch_policy_json(
    const CustodyDispatchPolicy& policy) {
    std::string out =
        "{\"format\":\"V24_EXPLICIT_OWNER_CUSTODY_DISPATCH_V1\",\"activations\":[";
    bool first = true;
    for (const auto& activation : policy) {
        if (!first) { out += ','; }
        first = false;
        out += "{\"id\":" + json_string(activation.id) +
            ",\"generation\":" + std::to_string(activation.generation) +
            ",\"state\":" + json_string(
                custody_dispatch_activation_state_name(activation.state)) +
            ",\"receiver_activation_id\":" +
                json_string(activation.receiver_activation_id) +
            ",\"receiver_activation_generation\":" +
                std::to_string(activation.receiver_activation_generation) +
            ",\"receiver_activation_commitment_sha256\":" +
                json_string(operation_id_text(
                    activation.receiver_activation_commitment)) +
            ",\"outbound_session_rule_id\":" +
                json_string(activation.outbound_session_rule_id) +
            ",\"outbound_session_rule_generation\":" +
                std::to_string(activation.outbound_session_rule_generation) +
            ",\"outbound_session_rule_commitment_sha256\":" +
                json_string(operation_id_text(
                    activation.outbound_session_rule_commitment)) +
            ",\"route_id\":" + json_string(activation.route_id) +
            ",\"route_commitment_sha256\":" +
                json_string(operation_id_text(activation.route_commitment)) +
            ",\"maximum_concurrent_dispatches\":" +
                std::to_string(activation.maximum_concurrent_dispatches) +
            ",\"maximum_dispatch_attempts\":" +
                std::to_string(activation.maximum_dispatch_attempts) +
            ",\"activation_expires_unix_ms\":" +
                std::to_string(activation.activation_expires_unix_ms) +
            ",\"commitment_sha256\":" + json_string(
                operation_id_text(
                    custody_dispatch_activation_commitment(activation))) +
            ",\"predecessor_sha256\":" +
                json_string(operation_id_text(activation.predecessor)) + "}";
    }
    return out + "]}";
}

} // namespace natrav_overlay
