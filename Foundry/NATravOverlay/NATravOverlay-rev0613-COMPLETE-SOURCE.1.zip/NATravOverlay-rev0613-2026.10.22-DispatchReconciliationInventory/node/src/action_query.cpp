#include "action_query.hpp"
#include "journal.hpp"
#include <algorithm>
#include <array>
#include <limits>
#include <memory>
#include <openssl/core_names.h>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/params.h>
#include <openssl/rand.h>

namespace natrav_overlay {
namespace {
using Digest=datacube::Digest32;
constexpr std::size_t kCursorBytes=128U;
constexpr std::uint64_t kLifetime=300'000U;
void require(bool value,std::string_view code,std::string_view message) {
    if(!value)app_fail(code,message);
}
std::string hex(const Digest& value) {return json_string(datacube::hex_lower(value));}
std::string maybe_hex(const std::optional<Digest>& value) {return value?hex(*value):"null";}
std::string time_json(const std::optional<std::uint64_t>& value) {return value?std::to_string(*value):"null";}
std::string_view action_result_name(const ActionResultOutcome outcome) noexcept {
    switch(outcome){
        case ActionResultOutcome::executed:return "EXECUTED";
        case ActionResultOutcome::cancelled:return "CANCELLED";
        case ActionResultOutcome::expired:return "EXPIRED";
    }
    return "UNKNOWN";
}
void text16(datacube::Octets& out,std::string_view value) {
    datacube::append_be16(out,static_cast<std::uint16_t>(value.size()));datacube::append_text(out,value);
}
std::string text16(datacube::Reader& reader,std::size_t maximum) {
    const auto size=reader.read_be16("text size");
    require(size<=maximum,"ACTION_QUERY_INVALID","text exceeds bound");
    return datacube::octets_text(reader.read_exact(size,"text"),"text",true);
}
Digest digest(datacube::Reader& reader) {
    Digest value{};const auto bytes=reader.read_exact(32U,"digest");std::copy(bytes.begin(),bytes.end(),value.octets.begin());return value;
}
std::uint64_t monotonic_ms() {
    const auto t=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
    require(t>=0,"ACTION_QUERY_CLOCK_FAILED","negative monotonic clock");return static_cast<std::uint64_t>(t);
}
void checked(int value) {require(value==1,"ACTION_QUERY_CRYPTO_FAILED","cursor cryptography failed");}
struct Secret final {
    std::array<unsigned char,32U> bytes{};
    Secret(){checked(RAND_priv_bytes(bytes.data(),static_cast<int>(bytes.size())));}
    ~Secret(){OPENSSL_cleanse(bytes.data(),bytes.size());}
    Secret(const Secret&)=delete;Secret& operator=(const Secret&)=delete;
};
Digest mac(datacube::OctetView bytes) {
    static const Secret secret;
    std::unique_ptr<EVP_MAC,decltype(&EVP_MAC_free)> algorithm(EVP_MAC_fetch(nullptr,"HMAC",nullptr),EVP_MAC_free);
    require(static_cast<bool>(algorithm),"ACTION_QUERY_CRYPTO_FAILED","HMAC unavailable");
    std::unique_ptr<EVP_MAC_CTX,decltype(&EVP_MAC_CTX_free)> ctx(EVP_MAC_CTX_new(algorithm.get()),EVP_MAC_CTX_free);
    require(static_cast<bool>(ctx),"ACTION_QUERY_CRYPTO_FAILED","HMAC context unavailable");
    char sha[]="SHA256";
    OSSL_PARAM parameters[]={OSSL_PARAM_construct_utf8_string(OSSL_MAC_PARAM_DIGEST,sha,0U),OSSL_PARAM_construct_end()};
    checked(EVP_MAC_init(ctx.get(),secret.bytes.data(),secret.bytes.size(),parameters));
    constexpr std::string_view domain="NATRAV_OVERLAY_ACTION_CURSOR_V1";
    checked(EVP_MAC_update(ctx.get(),reinterpret_cast<const unsigned char*>(domain.data()),domain.size()));
    checked(EVP_MAC_update(ctx.get(),bytes.data(),bytes.size()));
    Digest tag{};std::size_t length=0U;checked(EVP_MAC_final(ctx.get(),tag.octets.data(),&length,32U));
    require(length==32U,"ACTION_QUERY_CRYPTO_FAILED","HMAC size mismatch");return tag;
}
struct Position final {std::uint64_t version{0U};std::uint64_t after{0U};std::uint64_t expires{0U};};
std::string seal(const ActionQueryContext& context,const Digest& specification,const Position& position) {
    datacube::Octets bytes;datacube::append_text(bytes,"ACQ1");datacube::append_be32(bytes,context.uid);
    datacube::append_octets(bytes,context.configuration_digest.octets);datacube::append_octets(bytes,specification.octets);
    datacube::append_be64(bytes,position.version);datacube::append_be64(bytes,position.after);datacube::append_be64(bytes,position.expires);
    const auto tag=mac(bytes);datacube::append_octets(bytes,tag.octets);return hex_bytes(bytes);
}
Position open(const std::string& token,const ActionQueryContext& context,const Digest& specification) {
    require(token.size()==kCursorBytes*2U,"ACTION_CURSOR_INVALID","invalid cursor size");
    auto nibble=[](char c)->std::uint8_t {
        if(c>='0'&&c<='9')return static_cast<std::uint8_t>(c-'0');
        if(c>='a'&&c<='f')return static_cast<std::uint8_t>(c-'a'+10);
        app_fail("ACTION_CURSOR_INVALID","cursor must be lowercase hexadecimal");
    };
    datacube::Octets bytes;bytes.reserve(kCursorBytes);
    for(std::size_t i=0U;i<token.size();i+=2U)bytes.push_back(static_cast<std::uint8_t>(nibble(token[i])*16U+nibble(token[i+1U])));
    const auto body=datacube::OctetView(bytes).first(kCursorBytes-32U);const auto tag=mac(body);
    require(CRYPTO_memcmp(tag.octets.data(),bytes.data()+body.size(),32U)==0,"ACTION_CURSOR_INVALID","authentication failed or issuing process restarted");
    datacube::Reader reader(body,"action cursor");
    require(datacube::octets_text(reader.read_exact(4U,"magic"),"magic",true)=="ACQ1","ACTION_CURSOR_INVALID","unknown cursor version");
    const auto uid=reader.read_be32("UID");const auto config=digest(reader);const auto spec=digest(reader);
    Position result{reader.read_be64("revision"),reader.read_be64("position"),reader.read_be64("expiry")};reader.require_eof("cursor");
    require(uid==context.uid&&config==context.configuration_digest&&spec==specification,"ACTION_CURSOR_CONTEXT_MISMATCH","principal, node, query or configuration changed");
    require(monotonic_ms()<result.expires,"ACTION_CURSOR_EXPIRED","cursor expired; restart inspection");
    return result;
}
// Commitments, not echoed free text that may contain private paths.
std::string reason_json(std::string_view reason) {
    if (reason.empty()) return "null";
    datacube::Octets bytes;
    datacube::append_text(bytes,"NATRAV_OVERLAY_ACTION_REASON_V1");
    datacube::append_u8(bytes,0U);datacube::append_text(bytes,reason);
    return "{\"bytes\":"+std::to_string(reason.size())+",\"digest\":"+hex(datacube::sha256(bytes))+"}";
}
std::string row_json(const StoredAction& a, const StoredInbound& source,
    std::uint64_t revision, const std::string& bindings,
    const std::string& condition, const std::string& action_result) {
    require(source.authorization.has_value() && source.record.operation_id==a.action_id &&
        source.record_digest==a.record_digest,"JOURNAL_CORRUPT","action source binding missing");
    const auto& auth=*source.authorization;
    const auto status=action_status_name(a);
    const auto phase=action_is_pending(a)?(a.last_started_unix_ms?"STARTED_UNRESOLVED":"ADMITTED"):status;
    std::string row="{\"action_id\":"+hex(a.action_id)+",\"queue_sequence\":"+std::to_string(a.queue_sequence)+
        ",\"action_revision\":"+std::to_string(revision)+",\"issuer\":"+json_string(a.issuer)+
        ",\"peer_generation\":"+json_string(a.peer_generation)+",\"kind\":\"counter.add\",\"status\":"+json_string(status)+
        ",\"execution_phase\":"+json_string(phase)+",\"amount\":"+std::to_string(a.amount)+
        ",\"reserved_amount\":"+std::to_string(action_is_pending(a)?a.amount:0U)+
        ",\"admitted_unix_ms\":"+std::to_string(a.admitted_unix_ms)+
        ",\"not_before_unix_ms\":"+std::to_string(a.not_before_unix_ms)+
        ",\"expires_unix_ms\":"+std::to_string(a.expires_unix_ms)+
        ",\"limits\":{\"counter_budget\":"+std::to_string(a.limits.counter_budget)+
        ",\"maximum_increment\":"+std::to_string(a.limits.maximum_increment)+
        ",\"maximum_defer_ms\":"+std::to_string(a.limits.maximum_defer_ms)+
        ",\"expiry_ms\":"+std::to_string(a.limits.expiry_ms)+"}"+
        ",\"attempts\":"+std::to_string(a.attempts)+",\"last_started_unix_ms\":"+time_json(a.last_started_unix_ms)+
        ",\"attempt_history\":\"COUNT_AND_LATEST_START_ONLY\",\"executor_identity\":null,\"executor_identity_basis\":\"NOT_RECORDED\""+
        ",\"last_error_code\":"+(a.last_error_code.empty()?"null":json_string(a.last_error_code))+
        ",\"completed_unix_ms\":"+time_json(a.completed_unix_ms)+",\"cancelled_unix_ms\":"+time_json(a.cancelled_unix_ms)+
        ",\"expired_unix_ms\":"+time_json(a.expired_unix_ms)+",\"cancellation_reason\":"+reason_json(a.cancellation_reason)+
        ",\"expiry_reason\":"+reason_json(a.expiry_reason)+",\"terminal_principal\":null,\"terminal_principal_basis\":\"NOT_RECORDED_IN_ACTION\""+
        ",\"effect_completed\":"+(a.completed_unix_ms?"true":"false")+",\"result\":";
    if(a.completed_unix_ms) row+="{\"kind\":\"LOCAL_COUNTER_COMMIT\",\"counter_before\":"+time_json(a.counter_before)+
        ",\"counter_after\":"+time_json(a.counter_after)+",\"receipt_digest\":"+maybe_hex(a.receipt_digest)+"}";
    else row+="null";
    row+=",\"source_admission\":{\"operation_id\":"+hex(source.record.operation_id)+",\"sequence\":"+std::to_string(source.sequence)+
        ",\"issuer\":"+json_string(source.record.issuer)+",\"recipient\":"+json_string(source.record.recipient)+
        ",\"scope\":"+json_string(source.record.scope)+",\"record_digest\":"+hex(source.record_digest)+
        ",\"payload_bytes\":"+std::to_string(source.record.payload.size())+
        ",\"authorization\":{\"decision\":"+json_string(authorization_decision_kind_name(auth.decision))+
        ",\"peer_node\":"+json_string(auth.peer_node)+",\"peer_generation\":"+json_string(auth.peer_generation)+
        ",\"operation_class\":"+json_string(authorized_operation_class_name(auth.operation_class))+
        ",\"resource\":"+json_string(auth.resource)+",\"policy_digest\":"+hex(auth.policy_digest)+
        ",\"rule_digest\":"+maybe_hex(auth.rule_digest)+",\"decided_unix_ms\":"+std::to_string(auth.decided_unix_ms)+
        ",\"reason_code\":"+json_string(auth.reason_code)+"}},\"mutation_bindings\":"+bindings+
        ",\"action_result\":"+action_result+
        ",\"condition\":"+condition+"}";
    return row;
}
} // namespace

void validate_action_query(const ActionQuery& q) {
    require(q.issuer.empty()||valid_node_id(q.issuer),"ACTION_QUERY_INVALID","issuer must be an exact node ID");
    require(q.state.empty()||q.state=="PENDING"||q.state=="EXECUTED"||q.state=="CANCELLED"||q.state=="EXPIRED",
        "ACTION_QUERY_INVALID","state must name a durable action outcome");
    require(!q.action_id||!digest_is_zero(*q.action_id),"ACTION_QUERY_INVALID","action ID must be nonzero");
    require(q.maximum_records>=1U&&q.maximum_records<=64U&&q.maximum_response_bytes>=2048U&&q.maximum_response_bytes<=60000U,
        "ACTION_QUERY_INVALID","limit 1..64 and max-bytes 2048..60000 required");
    require(q.cursor.empty()||q.cursor.size()==kCursorBytes*2U,"ACTION_CURSOR_INVALID","invalid cursor size");
}
datacube::Octets encode_action_query(const ActionQuery& q) {
    validate_action_query(q);datacube::Octets bytes;datacube::append_text(bytes,"AQY1");
    text16(bytes,q.issuer);text16(bytes,q.state);datacube::append_u8(bytes,q.action_id?1U:0U);
    if(q.action_id)datacube::append_octets(bytes,q.action_id->octets);
    datacube::append_be32(bytes,q.maximum_records);datacube::append_be32(bytes,q.maximum_response_bytes);text16(bytes,q.cursor);return bytes;
}
ActionQuery decode_action_query(datacube::OctetView bytes) {
    datacube::Reader reader(bytes,"action query");
    require(datacube::octets_text(reader.read_exact(4U,"magic"),"magic",true)=="AQY1","ACTION_QUERY_INVALID","unknown query version");
    ActionQuery q;q.issuer=text16(reader,64U);q.state=text16(reader,16U);const auto flag=reader.read_u8("action present");
    require(flag<=1U,"ACTION_QUERY_INVALID","invalid optional marker");if(flag)q.action_id=digest(reader);
    q.maximum_records=reader.read_be32("rows");q.maximum_response_bytes=reader.read_be32("bytes");q.cursor=text16(reader,kCursorBytes*2U);
    reader.require_eof("action query");validate_action_query(q);return q;
}

void NodeState::index_action_binding_locked(std::size_t index) {
    const auto& b=configuration_bindings_.at(index);
    if(!b.operation_id) return;
    const auto id=operation_id_text(*b.operation_id);
    if(!action_index_.contains(id)) return;
    std::size_t slot=0U;
    switch(b.journal_kind) {
        case 11U:slot=0U;break;
        case 13U:slot=1U;break;
        case 14U:slot=2U;break;
        case 15U:case 16U:slot=3U;break;
        case 37U:{
            const auto found=action_index_.find(id);
            if(found==action_index_.end())return;
            const auto& action=actions_.at(found->second);
            if(action.completed_unix_ms.has_value())slot=2U;
            else if(action.cancelled_unix_ms.has_value()||action.expired_unix_ms.has_value())slot=3U;
            else return;
            break;
        }
        default:return;
    }
    action_binding_index_[id][slot]=index;
}

std::string NodeState::query_actions(const ActionQuery& query,const ActionQueryContext& context) const {
    validate_action_query(query);
    auto q=query;q.cursor.clear();auto specification=encode_action_query(q);text16(specification,node_id_);
    const auto spec=datacube::sha256(specification);
    std::optional<Position> old;if(!query.cursor.empty())old=open(query.cursor,context,spec);
    const auto check_time=[&](){require(std::chrono::steady_clock::now()<context.deadline,"ACTION_QUERY_DEADLINE","action page deadline reached");};
    check_time();std::lock_guard lock(mutex_);check_time();
    require(!poisoned_,"STATE_POISONED","restart to reconstruct failed state");
    SubmissionWork work;SubmissionWorkScope work_scope(work);
    const auto& bucket=action_inspection_index_.select(query.issuer,query.state);
    std::optional<std::size_t> exact;
    if(query.action_id){const auto f=action_index_.find(operation_id_text(*query.action_id));
        if(f!=action_index_.end()&&(query.issuer.empty()||actions_[f->second].issuer==query.issuer)&&
            (query.state.empty()||action_inspection_index_.state(f->second)==query.state))exact=f->second;
    }
    const auto version=query.action_id?(exact?action_inspection_index_.revision(*exact):0U):bucket.revision;
    require(!old||old->version==version,"ACTION_CURSOR_STALE","selected action metadata changed; restart inspection");
    const std::uint64_t total=query.action_id?(exact?1U:0U):static_cast<std::uint64_t>(bucket.records.size());
    Position pos{version,old?old->after:0U,old?old->expires:monotonic_ms()+kLifetime};
    std::string prefix="{\"format\":\"NATRAV_OVERLAY_ACTION_QUERY_V1\",\"node\":"+json_string(node_id_)+
        ",\"configuration_digest\":"+hex(context.configuration_digest)+",\"query_digest\":"+hex(spec)+
        ",\"selection_revision\":"+std::to_string(version)+",\"selected_total\":"+std::to_string(total)+
        ",\"order\":\"ACTION_QUEUE_SEQUENCE\",\"exact\":"+(query.action_id?"true":"false")+
        ",\"maximum_bytes\":"+std::to_string(query.maximum_response_bytes)+
        ",\"observation\":\"ONE_STATE_MUTEX_OBSERVATION\",\"retained_attempt_history\":\"COUNT_AND_LATEST_START_ONLY\""+
        ",\"sink_observation\":{\"scope\":\"ALL_ACTIONS_AT_THIS_PAGE\",\"counter_value\":"+std::to_string(action_counter_value_)+
        ",\"reserved_amount\":"+std::to_string(action_reserved_amount_)+"}";
    std::vector<std::string> rows;std::size_t row_bytes=0U,visited=0U,source_visits=0U,binding_visits=0U;
    auto bindings=[&](const StoredAction& a){
        std::string result="{";const auto it=action_binding_index_.find(operation_id_text(a.action_id));
        const std::array<std::string_view,4U> names={"admission","latest_start","completion","terminal"};
        for(std::size_t i=0U;i<names.size();++i){if(i)result+=',';result+=json_string(names[i])+":";
            if(it==action_binding_index_.end()||!it->second[i]){result+="null";continue;}
            ++binding_visits;const auto ordinal=*it->second[i];const auto& b=configuration_bindings_.at(ordinal);
            const auto& event=configuration_events_.at(static_cast<std::size_t>(b.configuration_event-1U));
            result+="{\"binding_ordinal\":"+std::to_string(ordinal+1U)+",\"journal_kind\":"+std::to_string(b.journal_kind)+
                ",\"configuration_event\":"+std::to_string(b.configuration_event)+",\"configuration_generation\":"+json_string(event.generation)+
                ",\"configuration_digest\":"+hex(event.digest)+",\"inner_payload_digest\":"+hex(b.payload_digest)+"}";
        }
        return result+"}";
    };
    auto add=[&](std::size_t index){
        check_time();++visited;const auto& a=actions_.at(index);
        const auto source=inbound_index_.find(operation_id_text(a.action_id));
        require(source!=inbound_index_.end(),"JOURNAL_CORRUPT","action lacks admitted source");++source_visits;
        const auto condition = query.action_id ?
            action_condition_json_locked(index) : std::string("null");
        std::string action_result = "null";
        const auto result = action_results_.find(operation_id_text(a.action_id));
        if (result != action_results_.end()) {
            const auto& binding = result->second.binding;
            action_result = std::string("{\"configured\":true,\"result_scope\":") +
                json_string(binding.result_scope) +
                ",\"reserved_payload_bytes\":" + std::to_string(binding.reserved_payload_bytes) +
                ",\"capacity_state\":" + json_string(binding.reserved_payload_bytes == 0U ? "LEGACY_UNRESERVED" :
                    (result->second.outcome ? "CONVERTED" : "RESERVED")) +
                ",\"policy_digest\":" + hex(binding.policy_digest) +
                ",\"rule_digest\":" + hex(binding.rule_digest) +
                ",\"configuration_event\":" +
                std::to_string(binding.configuration_event) +
                ",\"peer_generation\":" +
                json_string(binding.peer_generation) +
                ",\"peer_spki_sha256\":" +
                hex(binding.peer_spki_sha256) +
                ",\"terminal_outcome\":" +
                (result->second.outcome.has_value() ?
                    json_string(action_result_name(*result->second.outcome)) :
                    std::string("null")) +
                ",\"operation_id\":" +
                (result->second.operation_id.has_value() ?
                    hex(*result->second.operation_id) : std::string("null")) +
                ",\"record_digest\":" +
                (result->second.record_digest.has_value() ?
                    hex(*result->second.record_digest) : std::string("null")) +
                "}";
        }
        auto row=row_json(a,inbound_.at(source->second),
            action_inspection_index_.revision(index),bindings(a),condition,
            action_result);
        constexpr std::size_t reserve=1536U;
        if(prefix.size()+row_bytes+row.size()+rows.size()+reserve>query.maximum_response_bytes){
            require(!rows.empty(),"ACTION_QUERY_PAGE_TOO_SMALL","first complete action row cannot fit; increase max-bytes");return false;
        }
        row_bytes+=row.size();rows.push_back(std::move(row));return true;
    };
    bool more=false;
    if(query.action_id){if(exact)static_cast<void>(add(*exact));}
    else {
        require(pos.after<=actions_.size(),"ACTION_CURSOR_INVALID","invalid queue position");
        auto it=pos.after==0U?bucket.records.begin():bucket.records.upper_bound(static_cast<std::size_t>(pos.after-1U));
        while(it!=bucket.records.end()&&rows.size()<query.maximum_records){const auto index=*it;
            if(!add(index))break;
            pos.after=actions_[index].queue_sequence;++it;
        }
        more=it!=bucket.records.end();
    }
    check_time();
    auto result=prefix+",\"returned\":"+std::to_string(rows.size())+",\"more\":"+(more?"true":"false")+
        ",\"next_cursor\":"+(more?json_string(seal(context,spec,pos)):"null")+
        ",\"work\":{\"action_records_visited\":"+std::to_string(visited)+",\"source_records_visited\":"+std::to_string(source_visits)+
        ",\"binding_records_visited\":"+std::to_string(binding_visits)+",\"payload_bytes_read\":0,\"historical_configurations_parsed\":0"+
        ",\"snapshot_calls\":"+std::to_string(work.snapshot_calls)+",\"logical_bytes_serialized\":"+std::to_string(work.snapshot_logical_bytes)+"},\"records\":[";
    for(std::size_t i=0U;i<rows.size();++i){if(i)result+=',';result+=rows[i];}result+="]}";
    require(result.size()+512U<=query.maximum_response_bytes,"ACTION_QUERY_RESPONSE_LIMIT","annotated response budget exceeded");return result;
}
} // namespace natrav_overlay
