#pragma once
#include "subscribed_source.hpp"
#include <map>
namespace natrav_overlay {
enum class ImportAutoCommand : std::uint8_t { enable=1U, pause=2U, status=3U, review=4U, reconsider=5U, retire=6U, retirement_status=7U };
struct ImportAutoRequest final {
    ImportAutoCommand command{ImportAutoCommand::status};
    std::string view;
    std::uint64_t revision{0U};
    std::uint32_t maximum_imports{32U}, maximum_decisions{128U}, interval_ms{100U};
    std::string reason;
    // Review uses an immutable authenticated-history prefix, not a permission token.
    std::uint64_t after_revision{0U}, through_revision{0U}, decision_revision{0U};
    std::uint32_t page_limit{16U}, maximum_bytes{32768U};
    datacube::Digest32 history_digest{}, decision_digest{}, outer_operation{}, view_digest{}, configuration_digest{};
    datacube::Digest32 final_state_digest{};
    std::string deferred_disposition; // REQUIRE_EMPTY or RETAIN_UNPROCESSED
};
// Only events are durable. Derived counters are recomputed by the same reducer
// during journal replay and full historical-prefix checkpoint validation.
struct ImportAutoEvent final {
    std::string view, action, reason, outcome;
    std::uint64_t revision{0U}, configuration_event{0U}, unix_ms{0U}, inbound_count{0U}, ordinal{0U};
    std::uint32_t uid{0U}, gid{0U}, pid{0U}, maximum_imports{0U}, maximum_decisions{0U}, interval_ms{0U};
    datacube::Digest32 previous_digest{};
    // Present only in NIE2 manual reconsideration. Older NIE1 bytes stay identical.
    std::uint64_t decision_revision{0U};
    datacube::Digest32 decision_digest{}, outer_operation{}, view_digest{}, configuration_digest{};
    // NIE3 retirement selects the complete retained pre-transition account.
    datacube::Digest32 final_state_digest{};
    std::string deferred_disposition;
};
struct ImportAutoState final {
    std::string view;
    std::uint32_t uid{0U};
    datacube::Digest32 rule_digest{}, authority_digest{}, head_digest{};
    std::uint64_t next_position{0U}, generation{0U}, imports{0U}, decisions{0U};
    std::uint32_t maximum_imports{0U}, maximum_decisions{0U}, interval_ms{0U};
    std::string state{"NEVER_ENABLED"}, error;
    std::uint64_t manual_retries{0U};
    // Derived solely from the terminal event and its original input prefix.
    std::string retired_from_state;
    std::uint64_t retired_records{0U}, retired_payload_bytes{0U};
    datacube::Digest32 retired_records_digest{};
    // Ordinal -> exact materialized predecessor. Never payload copies.
    std::map<std::uint64_t,datacube::Digest32> deferred;
    std::vector<ImportAutoEvent> history;
};
struct ViewFinalAccount final {
    datacube::Digest32 digest{}, records_digest{};
    std::uint64_t records{0U}, payload_bytes{0U};
};
struct ImportCandidate final {std::string view;std::uint64_t generation{0U};std::uint32_t interval_ms{0U};};
struct ImportAttempt final {
    std::string outcome;
    std::optional<datacube::Digest32> parent;
    std::optional<std::pair<EvidenceRecord,SubscribedSource>> imported;
};
struct ImportPlan final {ImportAutoState next;ImportAutoEvent event;ImportAttempt attempt;};
inline constexpr std::size_t kImportHistoryLimit=1024U;
// A terminal slot remains available even after all ordinary history is used.
inline constexpr std::size_t kImportRetainedHistoryLimit=kImportHistoryLimit+1U;
inline constexpr std::uint64_t kImportManualRetryLimit=64U;
[[nodiscard]] inline bool import_observational(ImportAutoCommand c) noexcept {
    return c==ImportAutoCommand::status || c==ImportAutoCommand::review || c==ImportAutoCommand::retirement_status;
}
[[nodiscard]] datacube::Octets encode_import_auto_request(const ImportAutoRequest& value);
[[nodiscard]] ImportAutoRequest decode_import_auto_request(datacube::OctetView bytes);
[[nodiscard]] datacube::Octets encode_import_auto_event(const ImportAutoEvent& value);
[[nodiscard]] ImportAutoEvent decode_import_auto_event(datacube::OctetView bytes);
[[nodiscard]] datacube::Octets encode_import_auto_history(const ImportAutoState& value);
[[nodiscard]] std::vector<ImportAutoEvent> decode_import_auto_history(datacube::OctetView bytes);
[[nodiscard]] std::string import_auto_json(const ImportAutoState& value, bool full_history=false);
} // namespace natrav_overlay
