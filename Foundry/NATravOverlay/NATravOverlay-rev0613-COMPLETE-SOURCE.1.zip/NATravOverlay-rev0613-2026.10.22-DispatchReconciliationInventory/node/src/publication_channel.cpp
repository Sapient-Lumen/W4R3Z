#include "publication_channel.hpp"

#include "config.hpp"
#include "consumer.hpp"
#include "journal.hpp"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <map>
#include <set>
#include <thread>

#include <openssl/rand.h>

namespace natrav_overlay {
namespace {

void append_text(datacube::Octets& out, const std::string_view value,
                 const std::size_t maximum, const std::string_view field) {
    if (value.size() > maximum || value.size() > 65'535U) {
        app_fail("PUBLICATION_CHANNEL_INVALID",
                 std::string(field) + " exceeds its bound");
    }
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}

std::string read_text(datacube::Reader& reader, const std::size_t maximum,
                      const std::string_view field) {
    const auto size = reader.read_be16(field);
    if (static_cast<std::size_t>(size) > maximum) {
        app_fail("PUBLICATION_CHANNEL_INVALID",
                 std::string(field) + " exceeds its bound");
    }
    return datacube::octets_text(reader.read_exact(size, field), field, true);
}

void append_digest(datacube::Octets& out, const datacube::Digest32& value) {
    datacube::append_octets(out, value.octets);
}

datacube::Digest32 read_digest(datacube::Reader& reader,
                               const std::string_view field) {
    datacube::Digest32 value{};
    const auto bytes = reader.read_exact(value.octets.size(), field);
    std::copy(bytes.begin(), bytes.end(), value.octets.begin());
    return value;
}

void append_optional_digest(datacube::Octets& out,
                            const std::optional<datacube::Digest32>& value) {
    datacube::append_u8(out, value ? 1U : 0U);
    if (value) { append_digest(out, *value); }
}

std::optional<datacube::Digest32> read_optional_digest(
    datacube::Reader& reader, const std::string_view field) {
    const auto marker = reader.read_u8(field);
    if (marker > 1U) {
        app_fail("PUBLICATION_CHANNEL_INVALID", "invalid optional digest marker");
    }
    return marker == 1U ? std::optional(read_digest(reader, field)) : std::nullopt;
}

void append_blob(datacube::Octets& out, const datacube::OctetView value,
                 const std::size_t maximum, const std::string_view field) {
    if (value.size() > maximum || value.size() > std::numeric_limits<std::uint32_t>::max()) {
        app_fail("PUBLICATION_CHANNEL_INVALID",
                 std::string(field) + " exceeds its bound");
    }
    datacube::append_be32(out, static_cast<std::uint32_t>(value.size()));
    datacube::append_octets(out, value);
}

datacube::OctetView read_blob(datacube::Reader& reader,
                              const std::size_t maximum,
                              const std::string_view field) {
    const auto size = reader.read_be32(field);
    if (static_cast<std::size_t>(size) > maximum) {
        app_fail("PUBLICATION_CHANNEL_INVALID",
                 std::string(field) + " exceeds its bound");
    }
    return reader.read_exact(size, field);
}

bool valid_name(const std::string_view value) {
    return !value.empty() && value.size() <= 64U && value != "." && value != ".." &&
        std::all_of(value.begin(), value.end(), [](const char c) {
            return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '.';
        });
}

bool valid_reason(const std::string_view value) {
    return !value.empty() && value.size() <= 256U &&
        std::all_of(value.begin(), value.end(), [](const char c) {
            const auto byte = static_cast<unsigned char>(c);
            return byte == 9U || (byte >= 32U && byte <= 126U);
        });
}

bool valid_terminal_outcome(const std::string_view value) {
    return value == "REJECTED" || value == "CANCELLED" || value == "EXPIRED";
}

std::uint64_t now_ms() {
    return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count());
}

datacube::Digest32 random_digest() {
    datacube::Digest32 value{};
    if (RAND_priv_bytes(value.octets.data(), static_cast<int>(value.octets.size())) != 1 ||
        digest_is_zero(value)) {
        app_fail("PUBLICATION_CHANNEL_RANDOM_FAILED", "cannot generate channel instance");
    }
    return value;
}

void pause_test(const char* variable) {
    if (const auto* value = std::getenv(variable); value != nullptr && *value != '\0') {
        std::fprintf(stderr, "PUBLICATION_CHANNEL_TEST_BOUNDARY %s\n", variable);
        std::fflush(stderr);
        std::this_thread::sleep_for(std::chrono::milliseconds(
            parse_u64(value, variable, 1U, 60'000U)));
    }
}

void require_projection_access(const DurableConsumer& value,
                               const EvidenceQueryContext& context) {
    const auto& access = context.read_access;
    if (!access.scoped || !access.metadata_allowed ||
        (value.selection.include_payload && !access.payload_allowed)) {
        app_fail("LOCAL_CONTROL_CLASS_DENIED",
                 "current scoped result-read authority is required");
    }
    if (std::none_of(access.grants.begin(), access.grants.end(),
            [&](const EvidenceReadGrant& grant) {
                return (!value.selection.include_payload || grant.payload) &&
                    grant.issuer == value.selection.issuer &&
                    grant.scope == value.selection.scope;
            })) {
        app_fail("CONSUMER_DOMAIN_DENIED",
                 "no current exact read domain covers the projection result");
    }
}

std::string channel_status_for(const StoredOutbound& outbound) {
    return std::string(outbound_status_name(outbound));
}

void append_policy(datacube::Octets& out, const datacube::Digest32& operation,
                   const OutboundPolicy& policy) {
    append_digest(out, operation);
    datacube::append_be64(out, policy.created_unix_ms);
    datacube::append_be64(out, policy.expires_unix_ms);
    datacube::append_be32(out, policy.maximum_attempts);
    datacube::append_be32(out, policy.initial_backoff_ms);
    datacube::append_be32(out, policy.maximum_backoff_ms);
    if (!policy.peer_generation || !policy.peer_spki_sha256) {
        app_fail("PUBLICATION_CHANNEL_POLICY_INVALID",
                 "channel publication requires one exact recipient generation");
    }
    append_digest(out, *policy.peer_spki_sha256);
    append_text(out, *policy.peer_generation, 64U, "recipient generation");
}

OutboundPolicy read_policy(datacube::Reader& reader,
                           const datacube::Digest32& operation) {
    if (read_digest(reader, "policy operation") != operation) {
        app_fail("JOURNAL_CORRUPT", "channel policy operation mismatch");
    }
    OutboundPolicy policy{
        .created_unix_ms = reader.read_be64("policy created"),
        .expires_unix_ms = reader.read_be64("policy expires"),
        .maximum_attempts = reader.read_be32("policy attempts"),
        .initial_backoff_ms = reader.read_be32("policy initial backoff"),
        .maximum_backoff_ms = reader.read_be32("policy maximum backoff"),
        .peer_spki_sha256 = read_digest(reader, "policy recipient SPKI"),
        .peer_generation = read_text(reader, 64U, "policy recipient generation"),
    };
    return policy;
}

datacube::Octets outbound_composite(const EvidenceRecord& record,
                                     const OutboundPolicy& policy) {
    const auto encoded = encode_application_message(record);
    datacube::Octets result;
    append_digest(result, record.operation_id);
    datacube::append_be32(result, static_cast<std::uint32_t>(encoded.size()));
    datacube::append_octets(result, encoded);
    append_policy(result, record.operation_id, policy);
    return result;
}

std::pair<EvidenceRecord, OutboundPolicy> decode_outbound_composite(
    const datacube::OctetView bytes) {
    datacube::Reader reader(bytes, "publication channel outbound");
    const auto operation = read_digest(reader, "operation");
    const auto size = reader.read_be32("application size");
    const auto message = decode_application_message(
        reader.read_exact(size, "application"));
    const auto* record = std::get_if<EvidenceRecord>(&message);
    if (record == nullptr || record->operation_id != operation) {
        app_fail("JOURNAL_CORRUPT", "channel transaction contains invalid evidence");
    }
    auto policy = read_policy(reader, operation);
    reader.require_eof("publication channel outbound");
    return {*record, std::move(policy)};
}

datacube::Octets cancellation_payload(const datacube::Digest32& operation,
                                       const std::uint64_t at,
                                       const std::string_view reason,
                                       const OutboundPolicy& policy) {
    if (!policy.peer_generation || !policy.peer_spki_sha256) {
        app_fail("PUBLICATION_CHANNEL_POLICY_INVALID",
                 "pending publication lacks exact key binding");
    }
    datacube::Octets out;
    append_digest(out, operation);
    datacube::append_be64(out, at);
    append_text(out, "LOCAL_PUBLICATION_CHANNEL", 64U, "cancellation actor");
    append_text(out, reason, 256U, "cancellation reason");
    append_text(out, *policy.peer_generation, 64U, "cancelled generation");
    append_digest(out, *policy.peer_spki_sha256);
    return out;
}

struct DecodedCancellation final {
    datacube::Digest32 operation;
    std::uint64_t unix_ms = 0U;
    std::string actor;
    std::string reason;
    std::string generation;
    datacube::Digest32 spki_sha256;
};

DecodedCancellation decode_cancellation_payload(const datacube::OctetView bytes) {
    datacube::Reader reader(bytes, "publication channel cancellation");
    DecodedCancellation value{
        .operation = read_digest(reader, "cancelled operation"),
        .unix_ms = reader.read_be64("cancellation time"),
        .actor = read_text(reader, 64U, "cancellation actor"),
        .reason = read_text(reader, 256U, "cancellation reason"),
        .generation = read_text(reader, 64U, "cancelled generation"),
        .spki_sha256 = read_digest(reader, "cancelled peer SPKI"),
    };
    reader.require_eof("publication channel cancellation");
    return value;
}

struct DecodedTransaction final {
    PublicationChannel channel;
    std::optional<datacube::Octets> outbound;
    std::optional<datacube::Octets> cancellation;
};

datacube::Octets encode_transaction(const PublicationChannel& channel,
                                     const std::optional<datacube::Octets>& outbound,
                                     const std::optional<datacube::Octets>& cancellation) {
    datacube::Octets out;
    datacube::append_text(out, "NCT1");
    const auto encoded = encode_publication_channel(channel);
    append_blob(out, encoded, kPublicationChannelEncodedLimit, "channel state");
    datacube::append_u8(out, outbound ? 1U : 0U);
    if (outbound) { append_blob(out, *outbound, 200'000U, "channel outbound"); }
    datacube::append_u8(out, cancellation ? 1U : 0U);
    if (cancellation) { append_blob(out, *cancellation, 1'024U, "channel cancellation"); }
    return out;
}

DecodedTransaction decode_transaction(const datacube::OctetView bytes) {
    datacube::Reader reader(bytes, "publication channel transaction");
    if (datacube::octets_text(reader.read_exact(4U, "transaction magic"),
            "transaction magic", true) != "NCT1") {
        app_fail("JOURNAL_CORRUPT", "publication channel transaction magic mismatch");
    }
    DecodedTransaction value{
        .channel = decode_publication_channel(
            read_blob(reader, kPublicationChannelEncodedLimit, "channel state")),
        .outbound = std::nullopt,
        .cancellation = std::nullopt,
    };
    const auto outbound_marker = reader.read_u8("outbound marker");
    if (outbound_marker > 1U) { app_fail("JOURNAL_CORRUPT", "invalid outbound marker"); }
    if (outbound_marker == 1U) {
        const auto blob = read_blob(reader, 200'000U, "channel outbound");
        value.outbound = datacube::Octets(blob.begin(), blob.end());
    }
    const auto cancel_marker = reader.read_u8("cancellation marker");
    if (cancel_marker > 1U) { app_fail("JOURNAL_CORRUPT", "invalid cancellation marker"); }
    if (cancel_marker == 1U) {
        const auto blob = read_blob(reader, 1'024U, "channel cancellation");
        value.cancellation = datacube::Octets(blob.begin(), blob.end());
    }
    reader.require_eof("publication channel transaction");
    return value;
}

datacube::Digest32 channel_authority_digest(
    const PublicationChannel& channel, const DurableConsumer& projection,
    const EvidenceQueryContext& context, const OutboundPolicy& policy,
    const std::uint64_t sequence, const std::uint64_t epoch,
    const std::optional<datacube::Digest32>& corrects,
    const std::optional<datacube::Digest32>& terminal_operation,
    const std::string_view terminal_outcome) {
    datacube::Octets material;
    const bool epoch_aware = epoch != 1U || terminal_operation ||
        !terminal_outcome.empty();
    datacube::append_text(material, epoch_aware ?
        "NATRAV_OVERLAY_PUBLICATION_CHANNEL_AUTHORITY_V2" :
        "NATRAV_OVERLAY_PUBLICATION_CHANNEL_AUTHORITY_V1");
    datacube::append_u8(material, 0U);
    datacube::append_be32(material, channel.uid);
    append_digest(material, channel.instance);
    datacube::append_be64(material, sequence);
    append_optional_digest(material, corrects);
    if (epoch_aware) {
        datacube::append_be64(material, epoch);
        append_optional_digest(material, terminal_operation);
        append_text(material, terminal_outcome, 16U, "terminal outcome");
    }
    append_digest(material, context.read_access.digest);
    append_digest(material, projection_publication_authority(
        projection, channel.recipient, *policy.peer_generation,
        *policy.peer_spki_sha256, channel.scope, context));
    return datacube::sha256(material);
}

datacube::Octets channel_payload(
    const PublicationChannel& channel, const DurableConsumer& projection,
    const EvidenceQueryContext& context, const OutboundPolicy& policy,
    const std::uint64_t sequence, const std::uint64_t epoch,
    const std::optional<datacube::Digest32>& corrects,
    const std::optional<datacube::Digest32>& terminal_operation,
    const std::string_view terminal_outcome,
    const datacube::Digest32& authority) {
    const auto base = projection_publication_payload(
        projection, channel.recipient, *policy.peer_generation,
        *policy.peer_spki_sha256, channel.scope, context);
    datacube::Octets out;
    const bool epoch_aware = epoch != 1U || terminal_operation ||
        !terminal_outcome.empty();
    datacube::append_text(out, epoch_aware ? "NPC2" : "NPC1");
    datacube::append_u8(out, 1U);
    datacube::append_u8(out,
        static_cast<std::uint8_t>(PublicationChannelKeyPolicy::active_at_publish));
    datacube::append_be16(out, 0U);
    append_digest(out, channel.instance);
    datacube::append_be64(out, sequence);
    if (epoch_aware) { datacube::append_be64(out, epoch); }
    datacube::append_be32(out, channel.maximum_publications);
    append_optional_digest(out, corrects);
    if (epoch_aware) {
        append_optional_digest(out, terminal_operation);
        append_text(out, terminal_outcome, 16U, "terminal outcome");
    }
    append_digest(out, authority);
    append_text(out, channel.name, 64U, "channel name");
    append_blob(out, base, kMaximumEvidencePayloadBytes, "NPP1 payload");
    if (out.size() > kMaximumEvidencePayloadBytes) {
        app_fail("PUBLICATION_CHANNEL_PAYLOAD_LIMIT",
                 "channel result exceeds the evidence payload bound");
    }
    return out;
}

datacube::Digest32 channel_operation(const datacube::OctetView payload) {
    datacube::Octets material;
    datacube::append_text(material,
        "NATRAV_OVERLAY_PUBLICATION_CHANNEL_OPERATION_V1");
    datacube::append_u8(material, 0U);
    datacube::append_octets(material, payload);
    return datacube::sha256(material);
}

void validate_channel_record_payload(
    const EvidenceRecord& record, const PublicationChannel& channel,
    const PublicationChannelRevision& publication,
    const DurableConsumer& projection, const std::string_view local_node) {
    const auto invalid = []() {
        app_fail("JOURNAL_CORRUPT", "publication channel payload binding is invalid");
    };
    if (record.issuer != local_node || record.recipient != channel.recipient ||
        record.scope != channel.scope || record.corrects != publication.corrects ||
        record.operation_id != publication.operation_id ||
        evidence_record_digest(record) != publication.record_digest ||
        channel_operation(record.payload) != publication.operation_id) {
        invalid();
    }
    datacube::Reader wrapper(record.payload, "NPC channel publication");
    const auto wrapper_magic = datacube::octets_text(
        wrapper.read_exact(4U, "NPC magic"), "NPC magic", true);
    if (wrapper_magic != "NPC1" && wrapper_magic != "NPC2") { invalid(); }
    const bool epoch_payload = wrapper_magic == "NPC2";
    if (wrapper.read_u8("NPC version") != 1U ||
        wrapper.read_u8("NPC key policy") !=
            static_cast<std::uint8_t>(PublicationChannelKeyPolicy::active_at_publish) ||
        wrapper.read_be16("NPC reserved") != 0U ||
        read_digest(wrapper, "NPC channel instance") != channel.instance ||
        wrapper.read_be64("NPC sequence") != publication.sequence) {
        invalid();
    }
    if (epoch_payload) {
        if (wrapper.read_be64("NPC epoch") != publication.epoch) { invalid(); }
    } else if (publication.epoch != 1U || publication.prior_epoch_terminal_operation ||
               !publication.prior_epoch_terminal_outcome.empty()) {
        invalid();
    }
    if (wrapper.read_be32("NPC maximum publications") != channel.maximum_publications ||
        read_optional_digest(wrapper, "NPC predecessor") != publication.corrects) {
        invalid();
    }
    if (epoch_payload &&
        (read_optional_digest(wrapper, "NPC terminal predecessor") !=
             publication.prior_epoch_terminal_operation ||
         read_text(wrapper, 16U, "NPC terminal outcome") !=
             publication.prior_epoch_terminal_outcome)) {
        invalid();
    }
    if (read_digest(wrapper, "NPC authority") != publication.authority_digest ||
        read_text(wrapper, 64U, "NPC channel name") != channel.name) {
        invalid();
    }
    const auto base = read_blob(wrapper, kMaximumEvidencePayloadBytes, "NPP1 payload");
    wrapper.require_eof("NPC channel publication");

    datacube::Reader result(base, "NPP1 channel result");
    if (datacube::octets_text(result.read_exact(4U, "NPP1 magic"),
            "NPP1 magic", true) != "NPP1") {
        invalid();
    }
    const auto definition_kind = result.read_u8("NPP1 definition");
    const auto lifecycle_kind = result.read_u8("NPP1 lifecycle");
    if ((definition_kind != 1U && definition_kind != 2U) ||
        (lifecycle_kind != 1U && lifecycle_kind != 2U) ||
        result.read_be16("NPP1 reserved") != 0U ||
        result.read_be32("NPP1 owner") != channel.uid ||
        read_digest(result, "NPP1 projection instance") != channel.projection_instance ||
        result.read_be64("NPP1 revision") != publication.projection_revision) {
        invalid();
    }
    static_cast<void>(result.read_be64("NPP1 epoch"));
    if (result.read_be64("NPP1 position") != publication.processed_position) {
        invalid();
    }
    static_cast<void>(result.read_be64("NPP1 acknowledgments"));
    if (read_digest(result, "NPP1 definition digest") !=
            channel.projection_definition_digest ||
        read_digest(result, "NPP1 result digest") != publication.result_digest ||
        read_digest(result, "NPP1 source commitment") != publication.source_commitment ||
        digest_is_zero(read_digest(result, "NPP1 read authority")) ||
        digest_is_zero(read_digest(result, "NPP1 publication authority")) ||
        read_text(result, 64U, "NPP1 consumer") != channel.projection_name ||
        read_text(result, 64U, "NPP1 source issuer") != projection.selection.issuer ||
        read_text(result, 128U, "NPP1 source scope") != projection.selection.scope ||
        read_text(result, 64U, "NPP1 recipient") != channel.recipient ||
        read_text(result, 64U, "NPP1 recipient generation") !=
            publication.recipient_generation ||
        read_digest(result, "NPP1 recipient SPKI") !=
            publication.recipient_spki_sha256 ||
        read_text(result, 128U, "NPP1 output scope") != channel.scope ||
        result.read_be64("NPP1 maximum admissions") !=
            projection.projection->maximum_admissions) {
        invalid();
    }
    for (std::size_t i = 0U; i < 5U; ++i) {
        static_cast<void>(result.read_be64("NPP1 summary counter"));
    }
    if (read_digest(result, "NPP1 totals source commitment") !=
        publication.source_commitment) {
        invalid();
    }
    if (definition_kind == 2U) {
        if (!projection.projection->numeric) { invalid(); }
        for (std::size_t i = 0U; i < 9U; ++i) {
            static_cast<void>(result.read_be64("NPP1 numeric counter"));
        }
        const auto numeric_size = result.read_be32("NPP1 numeric definition size");
        const auto numeric = result.read_exact(numeric_size, "NPP1 numeric definition");
        if (datacube::Octets(numeric.begin(), numeric.end()) !=
            encode_numeric_definition(*projection.projection->numeric)) {
            invalid();
        }
    } else if (projection.projection->numeric) {
        invalid();
    }
    if (lifecycle_kind == 2U) {
        static_cast<void>(result.read_be64("NPP1 retirement revision"));
        static_cast<void>(result.read_be64("NPP1 retirement time"));
        static_cast<void>(read_digest(result, "NPP1 final consumer digest"));
        static_cast<void>(read_digest(result, "NPP1 final schedule digest"));
    }
    result.require_eof("NPP1 channel result");
}

std::string latest_status(const PublicationChannel& channel,
                          const std::map<std::string, std::size_t>& index,
                          const std::vector<StoredOutbound>& outbound) {
    if (channel.publications.empty()) { return "NONE"; }
    const auto found = index.find(datacube::hex_lower(
        channel.publications.back().operation_id));
    if (found == index.end()) { return "MISSING"; }
    return channel_status_for(outbound.at(found->second));
}

std::string terminal_channel_outcome(const StoredOutbound& outbound) {
    if (outbound.receipt) { return {}; }
    if (active_outbound_rejection(outbound)) { return "REJECTED"; }
    if (outbound.delivery && outbound.delivery->cancelled_unix_ms) {
        return "CANCELLED";
    }
    if (outbound.delivery && outbound.delivery->expired_unix_ms) {
        return "EXPIRED";
    }
    return {};
}

std::uint64_t publication_channel_epoch(const PublicationChannel& channel) {
    return channel.publications.empty() ? 1U : channel.publications.back().epoch;
}

void finish_automatic_grant(PublicationChannelAutomaticGrant& grant,
                            const PublicationChannel& channel,
                            const std::string_view state,
                            const std::string_view error) {
    grant.state = std::string(state);
    grant.error = std::string(error);
    grant.ended_configuration_event = channel.configuration_event;
    grant.ended_unix_ms = channel.unix_ms;
    grant.ended_uid = channel.actor_uid;
    grant.ended_pid = channel.pid;
}

bool automatic_grant_enabled(const PublicationChannel& channel) {
    return !channel.automatic_grants.empty() &&
        channel.automatic_grants.back().state == "ENABLED";
}

}  // namespace

std::string publication_channel_key(const std::uint32_t uid,
                                    const std::string_view name) {
    return std::to_string(uid) + ":" + std::string(name);
}

void validate_publication_channel_request(const PublicationChannelRequest& request) {
    if (!valid_name(request.name)) {
        app_fail("PUBLICATION_CHANNEL_NAME_INVALID",
                 "channel name requires 1..64 ASCII name characters");
    }
    if (request.command < PublicationChannelCommand::create ||
        request.command > PublicationChannelCommand::new_epoch) {
        app_fail("PUBLICATION_CHANNEL_INVALID", "unknown channel command");
    }
    if (request.command == PublicationChannelCommand::create) {
        if (!valid_name(request.projection_name) || !request.projection_instance ||
            digest_is_zero(*request.projection_instance) || request.recipient.empty() ||
            request.scope.empty() || !valid_reason(request.reason) ||
            request.maximum_publications == 0U ||
            request.maximum_publications > kPublicationChannelMaximumRevisions) {
            app_fail("PUBLICATION_CHANNEL_CREATE_INVALID",
                     "create requires projection, instance, target, finite budget, and reason");
        }
        require_node_id(request.recipient, "channel recipient");
        require_scope(request.scope);
        if (request.scope == kCounterAddActionScope) {
            app_fail("PUBLICATION_CHANNEL_SCOPE_REJECTED",
                     "projection results cannot be action requests");
        }
    } else if (request.command == PublicationChannelCommand::publish) {
        if (!request.channel_instance || digest_is_zero(*request.channel_instance) ||
            request.expected_channel_revision == 0U ||
            request.expected_projection_revision == 0U ||
            !request.expected_result_digest ||
            digest_is_zero(*request.expected_result_digest)) {
            app_fail("PUBLICATION_CHANNEL_SELECTION_REQUIRED",
                     "publish requires exact channel and projection selectors");
        }
    } else if (request.command == PublicationChannelCommand::retire) {
        if (!request.channel_instance || digest_is_zero(*request.channel_instance) ||
            request.expected_channel_revision == 0U || !valid_reason(request.reason)) {
            app_fail("PUBLICATION_CHANNEL_RETIRE_INVALID",
                     "retirement requires exact instance, revision, and reason");
        }
    } else if (request.command == PublicationChannelCommand::automatic_enable ||
               request.command == PublicationChannelCommand::automatic_pause) {
        if (!request.channel_instance || digest_is_zero(*request.channel_instance) ||
            request.expected_channel_revision == 0U || !valid_reason(request.reason)) {
            app_fail("PUBLICATION_CHANNEL_SCHEDULE_INVALID",
                     "automatic scheduling requires exact channel selectors and a reason");
        }
        if (request.command == PublicationChannelCommand::automatic_enable &&
            (request.automatic_maximum_publications == 0U ||
             request.automatic_maximum_publications > 10'000U ||
             request.automatic_minimum_interval_ms < 10U ||
             request.automatic_minimum_interval_ms > 60'000U)) {
            app_fail("PUBLICATION_CHANNEL_SCHEDULE_INVALID",
                     "automatic grant bounds are 1..10000 publications and 10..60000 milliseconds");
        }
    } else if (request.command == PublicationChannelCommand::new_epoch) {
        if (!request.channel_instance || digest_is_zero(*request.channel_instance) ||
            request.expected_channel_revision == 0U || request.expected_epoch == 0U ||
            !request.terminal_operation || digest_is_zero(*request.terminal_operation) ||
            !valid_terminal_outcome(request.terminal_outcome) ||
            request.expected_projection_revision == 0U ||
            !request.expected_result_digest ||
            digest_is_zero(*request.expected_result_digest) ||
            !valid_reason(request.reason)) {
            app_fail("PUBLICATION_CHANNEL_EPOCH_INVALID",
                     "new epoch requires exact terminal head, result selectors, and reason");
        }
    }
}

datacube::Octets encode_publication_channel_request(
    const PublicationChannelRequest& request) {
    validate_publication_channel_request(request);
    datacube::Octets out;
    datacube::append_text(out, "PCR3");
    datacube::append_u8(out, static_cast<std::uint8_t>(request.command));
    append_text(out, request.name, 64U, "channel name");
    if (request.command == PublicationChannelCommand::create) {
        append_text(out, request.projection_name, 64U, "projection name");
        append_digest(out, *request.projection_instance);
        append_text(out, request.recipient, 64U, "recipient");
        append_text(out, request.scope, 128U, "scope");
        datacube::append_be32(out, request.maximum_publications);
        append_text(out, request.reason, 256U, "reason");
    } else if (request.command == PublicationChannelCommand::publish) {
        append_digest(out, *request.channel_instance);
        datacube::append_be64(out, request.expected_channel_revision);
        datacube::append_be64(out, request.expected_projection_revision);
        datacube::append_be64(out, request.expected_position);
        append_digest(out, *request.expected_result_digest);
    } else if (request.command == PublicationChannelCommand::retire) {
        append_digest(out, *request.channel_instance);
        datacube::append_be64(out, request.expected_channel_revision);
        datacube::append_u8(out, request.cancel_pending ? 1U : 0U);
        append_text(out, request.reason, 256U, "reason");
    } else if (request.command == PublicationChannelCommand::automatic_enable ||
               request.command == PublicationChannelCommand::automatic_pause) {
        append_digest(out, *request.channel_instance);
        datacube::append_be64(out, request.expected_channel_revision);
        datacube::append_be64(out, request.expected_schedule_revision);
        datacube::append_be64(out, request.expected_grant_generation);
        append_text(out, request.reason, 256U, "reason");
        if (request.command == PublicationChannelCommand::automatic_enable) {
            datacube::append_be32(out, request.automatic_maximum_publications);
            datacube::append_be32(out, request.automatic_minimum_interval_ms);
        }
    } else if (request.command == PublicationChannelCommand::new_epoch) {
        append_digest(out, *request.channel_instance);
        datacube::append_be64(out, request.expected_channel_revision);
        datacube::append_be64(out, request.expected_epoch);
        append_digest(out, *request.terminal_operation);
        append_text(out, request.terminal_outcome, 16U, "terminal outcome");
        datacube::append_be64(out, request.expected_projection_revision);
        datacube::append_be64(out, request.expected_position);
        append_digest(out, *request.expected_result_digest);
        append_text(out, request.reason, 256U, "reason");
    }
    return out;
}

PublicationChannelRequest decode_publication_channel_request(
    const datacube::OctetView bytes) {
    datacube::Reader reader(bytes, "publication channel request");
    const auto magic = datacube::octets_text(reader.read_exact(4U, "request magic"),
        "request magic", true);
    if (magic != "PCR1" && magic != "PCR2" && magic != "PCR3") {
        app_fail("PUBLICATION_CHANNEL_INVALID", "request magic mismatch");
    }
    PublicationChannelRequest request;
    const auto command = reader.read_u8("channel command");
    const auto maximum_command = magic == "PCR1" ?
        static_cast<std::uint8_t>(PublicationChannelCommand::retire) :
        magic == "PCR2" ?
            static_cast<std::uint8_t>(PublicationChannelCommand::automatic_status) :
            static_cast<std::uint8_t>(PublicationChannelCommand::new_epoch);
    if (command < static_cast<std::uint8_t>(PublicationChannelCommand::create) ||
        command > maximum_command) {
        app_fail("PUBLICATION_CHANNEL_INVALID", "unknown channel command");
    }
    request.command = static_cast<PublicationChannelCommand>(command);
    request.name = read_text(reader, 64U, "channel name");
    if (request.command == PublicationChannelCommand::create) {
        request.projection_name = read_text(reader, 64U, "projection name");
        request.projection_instance = read_digest(reader, "projection instance");
        request.recipient = read_text(reader, 64U, "recipient");
        request.scope = read_text(reader, 128U, "scope");
        request.maximum_publications = reader.read_be32("maximum publications");
        request.reason = read_text(reader, 256U, "reason");
    } else if (request.command == PublicationChannelCommand::publish) {
        request.channel_instance = read_digest(reader, "channel instance");
        request.expected_channel_revision = reader.read_be64("channel revision");
        request.expected_projection_revision = reader.read_be64("projection revision");
        request.expected_position = reader.read_be64("processed position");
        request.expected_result_digest = read_digest(reader, "result digest");
    } else if (request.command == PublicationChannelCommand::retire) {
        request.channel_instance = read_digest(reader, "channel instance");
        request.expected_channel_revision = reader.read_be64("channel revision");
        const auto marker = reader.read_u8("pending disposition");
        if (marker > 1U) {
            app_fail("PUBLICATION_CHANNEL_INVALID", "invalid pending disposition");
        }
        request.cancel_pending = marker == 1U;
        request.reason = read_text(reader, 256U, "reason");
    } else if (request.command == PublicationChannelCommand::automatic_enable ||
               request.command == PublicationChannelCommand::automatic_pause) {
        request.channel_instance = read_digest(reader, "channel instance");
        request.expected_channel_revision = reader.read_be64("channel revision");
        request.expected_schedule_revision = reader.read_be64("schedule revision");
        request.expected_grant_generation = reader.read_be64("grant generation");
        request.reason = read_text(reader, 256U, "reason");
        if (request.command == PublicationChannelCommand::automatic_enable) {
            request.automatic_maximum_publications =
                reader.read_be32("automatic publication budget");
            request.automatic_minimum_interval_ms =
                reader.read_be32("automatic minimum interval");
        }
    } else if (request.command == PublicationChannelCommand::new_epoch) {
        request.channel_instance = read_digest(reader, "channel instance");
        request.expected_channel_revision = reader.read_be64("channel revision");
        request.expected_epoch = reader.read_be64("channel epoch");
        request.terminal_operation = read_digest(reader, "terminal operation");
        request.terminal_outcome = read_text(reader, 16U, "terminal outcome");
        request.expected_projection_revision = reader.read_be64("projection revision");
        request.expected_position = reader.read_be64("processed position");
        request.expected_result_digest = read_digest(reader, "result digest");
        request.reason = read_text(reader, 256U, "reason");
    }
    reader.require_eof("publication channel request");
    validate_publication_channel_request(request);
    return request;
}

datacube::Octets encode_publication_channel(const PublicationChannel& value) {
    datacube::Octets out;
    datacube::append_text(out, "NCH3");
    append_text(out, value.name, 64U, "channel name");
    datacube::append_be32(out, value.uid);
    append_digest(out, value.instance);
    append_text(out, value.projection_name, 64U, "projection name");
    append_digest(out, value.projection_instance);
    append_digest(out, value.projection_definition_digest);
    append_text(out, value.recipient, 64U, "recipient");
    append_text(out, value.scope, 128U, "scope");
    datacube::append_u8(out, static_cast<std::uint8_t>(value.key_policy));
    datacube::append_be32(out, value.maximum_publications);
    append_text(out, value.creation_reason, 256U, "creation reason");
    datacube::append_be64(out, value.created_configuration_event);
    datacube::append_be64(out, value.created_unix_ms);
    datacube::append_be32(out, value.created_pid);
    datacube::append_be64(out, value.revision);
    datacube::append_be32(out, static_cast<std::uint32_t>(value.publications.size()));
    for (const auto& publication : value.publications) {
        datacube::append_be64(out, publication.sequence);
        datacube::append_be64(out, publication.projection_revision);
        datacube::append_be64(out, publication.processed_position);
        append_digest(out, publication.result_digest);
        append_digest(out, publication.source_commitment);
        append_digest(out, publication.operation_id);
        append_digest(out, publication.record_digest);
        append_optional_digest(out, publication.corrects);
        datacube::append_be64(out, publication.epoch);
        append_optional_digest(out, publication.prior_epoch_terminal_operation);
        append_text(out, publication.prior_epoch_terminal_outcome, 16U,
                    "prior epoch terminal outcome");
        append_text(out, publication.epoch_reason, 256U, "epoch reason");
        datacube::append_be32(out, publication.epoch_actor_uid);
        append_text(out, publication.recipient_generation, 64U,
                    "recipient generation");
        append_digest(out, publication.recipient_spki_sha256);
        append_digest(out, publication.authority_digest);
        datacube::append_u8(out, publication.automatic ? 1U : 0U);
        datacube::append_be64(out, publication.automatic_grant_generation);
        datacube::append_be64(out, publication.configuration_event);
        datacube::append_be64(out, publication.unix_ms);
        datacube::append_be32(out, publication.pid);
    }
    datacube::append_be64(out, value.automatic_schedule_revision);
    datacube::append_be32(out,
        static_cast<std::uint32_t>(value.automatic_grants.size()));
    for (const auto& grant : value.automatic_grants) {
        datacube::append_be64(out, grant.generation);
        datacube::append_be64(out, grant.observed_channel_revision);
        datacube::append_be64(out, grant.configuration_event);
        datacube::append_be64(out, grant.unix_ms);
        datacube::append_be32(out, grant.pid);
        datacube::append_be32(out, grant.maximum_publications);
        datacube::append_be32(out, grant.minimum_interval_ms);
        append_digest(out, grant.authority_digest);
        append_text(out, grant.reason, 256U, "automatic grant reason");
        datacube::append_be64(out, grant.start_sequence);
        datacube::append_be64(out, grant.publications);
        append_text(out, grant.state, 16U, "automatic grant state");
        append_text(out, grant.error, 128U, "automatic grant error");
        datacube::append_be64(out, grant.ended_configuration_event);
        datacube::append_be64(out, grant.ended_unix_ms);
        datacube::append_be32(out, grant.ended_uid);
        datacube::append_be32(out, grant.ended_pid);
    }
    datacube::append_u8(out, value.retirement ? 1U : 0U);
    if (value.retirement) {
        datacube::append_be64(out, value.retirement->revision);
        datacube::append_be64(out, value.retirement->configuration_event);
        datacube::append_be64(out, value.retirement->unix_ms);
        datacube::append_be32(out, value.retirement->pid);
        datacube::append_u8(out, value.retirement->cancelled_pending ? 1U : 0U);
        append_optional_digest(out, value.retirement->cancelled_operation);
        append_text(out, value.retirement->reason, 256U, "retirement reason");
    }
    append_text(out, value.transition, 16U, "transition");
    datacube::append_be64(out, value.configuration_event);
    datacube::append_be64(out, value.unix_ms);
    datacube::append_be32(out, value.actor_uid);
    datacube::append_be32(out, value.pid);
    if (out.size() > kPublicationChannelEncodedLimit) {
        app_fail("PUBLICATION_CHANNEL_SIZE_LIMIT", "channel state exceeds its bound");
    }
    return out;
}

PublicationChannel decode_publication_channel(const datacube::OctetView bytes) {
    datacube::Reader reader(bytes, "publication channel state");
    const auto magic = datacube::octets_text(reader.read_exact(4U, "channel magic"),
        "channel magic", true);
    if (magic != "NCH1" && magic != "NCH2" && magic != "NCH3") {
        app_fail("PUBLICATION_CHANNEL_INVALID", "channel state magic mismatch");
    }
    const bool v2 = magic == "NCH2" || magic == "NCH3";
    const bool v3 = magic == "NCH3";
    PublicationChannel value;
    value.name = read_text(reader, 64U, "channel name");
    value.uid = reader.read_be32("owner UID");
    value.instance = read_digest(reader, "channel instance");
    value.projection_name = read_text(reader, 64U, "projection name");
    value.projection_instance = read_digest(reader, "projection instance");
    value.projection_definition_digest = read_digest(reader, "projection definition");
    value.recipient = read_text(reader, 64U, "recipient");
    value.scope = read_text(reader, 128U, "scope");
    const auto policy = reader.read_u8("key policy");
    if (policy != static_cast<std::uint8_t>(PublicationChannelKeyPolicy::active_at_publish)) {
        app_fail("PUBLICATION_CHANNEL_INVALID", "unknown channel key policy");
    }
    value.key_policy = static_cast<PublicationChannelKeyPolicy>(policy);
    value.maximum_publications = reader.read_be32("maximum publications");
    value.creation_reason = read_text(reader, 256U, "creation reason");
    value.created_configuration_event = reader.read_be64("creation configuration");
    value.created_unix_ms = reader.read_be64("creation time");
    value.created_pid = reader.read_be32("creation PID");
    value.revision = reader.read_be64("channel revision");
    const auto count = reader.read_be32("publication count");
    if (count > kPublicationChannelMaximumRevisions) {
        app_fail("PUBLICATION_CHANNEL_INVALID", "publication count exceeds its bound");
    }
    value.publications.reserve(count);
    for (std::uint32_t i = 0U; i < count; ++i) {
        PublicationChannelRevision publication{};
        publication.sequence = reader.read_be64("publication sequence");
        publication.projection_revision = reader.read_be64("projection revision");
        publication.processed_position = reader.read_be64("processed position");
        publication.result_digest = read_digest(reader, "result digest");
        publication.source_commitment = read_digest(reader, "source commitment");
        publication.operation_id = read_digest(reader, "operation ID");
        publication.record_digest = read_digest(reader, "record digest");
        publication.corrects = read_optional_digest(reader, "correction parent");
        if (v3) {
            publication.epoch = reader.read_be64("publication epoch");
            publication.prior_epoch_terminal_operation =
                read_optional_digest(reader, "prior epoch terminal operation");
            publication.prior_epoch_terminal_outcome =
                read_text(reader, 16U, "prior epoch terminal outcome");
            publication.epoch_reason = read_text(reader, 256U, "epoch reason");
            publication.epoch_actor_uid = reader.read_be32("epoch actor UID");
        }
        publication.recipient_generation =
            read_text(reader, 64U, "recipient generation");
        publication.recipient_spki_sha256 = read_digest(reader, "recipient SPKI");
        publication.authority_digest = read_digest(reader, "authority digest");
        if (v2) {
            const auto automatic = reader.read_u8("automatic publication marker");
            if (automatic > 1U) {
                app_fail("PUBLICATION_CHANNEL_INVALID",
                         "invalid automatic publication marker");
            }
            publication.automatic = automatic == 1U;
            publication.automatic_grant_generation =
                reader.read_be64("automatic grant generation");
        }
        publication.configuration_event = reader.read_be64("configuration event");
        publication.unix_ms = reader.read_be64("publication time");
        publication.pid = reader.read_be32("publication PID");
        value.publications.push_back(std::move(publication));
    }
    if (v2) {
        value.automatic_schedule_revision =
            reader.read_be64("automatic schedule revision");
        const auto grants = reader.read_be32("automatic grant count");
        if (grants > kPublicationChannelAutomaticGrantLimit) {
            app_fail("PUBLICATION_CHANNEL_INVALID",
                     "automatic grant count exceeds its bound");
        }
        value.automatic_grants.reserve(grants);
        for (std::uint32_t i = 0U; i < grants; ++i) {
            value.automatic_grants.push_back(PublicationChannelAutomaticGrant{
                .generation = reader.read_be64("automatic grant generation"),
                .observed_channel_revision =
                    reader.read_be64("automatic observed channel revision"),
                .configuration_event =
                    reader.read_be64("automatic grant configuration"),
                .unix_ms = reader.read_be64("automatic grant time"),
                .pid = reader.read_be32("automatic grant PID"),
                .maximum_publications =
                    reader.read_be32("automatic publication budget"),
                .minimum_interval_ms =
                    reader.read_be32("automatic minimum interval"),
                .authority_digest = read_digest(reader, "automatic authority"),
                .reason = read_text(reader, 256U, "automatic grant reason"),
                .start_sequence = reader.read_be64("automatic start sequence"),
                .publications = reader.read_be64("automatic publications"),
                .state = read_text(reader, 16U, "automatic grant state"),
                .error = read_text(reader, 128U, "automatic grant error"),
                .ended_configuration_event =
                    reader.read_be64("automatic ended configuration"),
                .ended_unix_ms = reader.read_be64("automatic ended time"),
                .ended_uid = reader.read_be32("automatic ended UID"),
                .ended_pid = reader.read_be32("automatic ended PID"),
            });
        }
    }
    const auto retired = reader.read_u8("retirement marker");
    if (retired > 1U) {
        app_fail("PUBLICATION_CHANNEL_INVALID", "invalid retirement marker");
    }
    if (retired == 1U) {
        const auto retirement_revision = reader.read_be64("retirement revision");
        const auto retirement_configuration = reader.read_be64("retirement configuration");
        const auto retirement_time = reader.read_be64("retirement time");
        const auto retirement_pid = reader.read_be32("retirement PID");
        const auto cancelled_marker = reader.read_u8("retirement cancellation");
        if (cancelled_marker > 1U) {
            app_fail("PUBLICATION_CHANNEL_INVALID",
                     "invalid retirement cancellation marker");
        }
        PublicationChannelRetirement retirement{
            .revision = retirement_revision,
            .configuration_event = retirement_configuration,
            .unix_ms = retirement_time,
            .pid = retirement_pid,
            .cancelled_pending = cancelled_marker == 1U,
            .cancelled_operation = read_optional_digest(reader, "cancelled operation"),
            .reason = read_text(reader, 256U, "retirement reason"),
        };
        value.retirement = std::move(retirement);
    }
    value.transition = read_text(reader, 16U, "transition");
    value.configuration_event = reader.read_be64("transition configuration");
    value.unix_ms = reader.read_be64("transition time");
    value.actor_uid = v2 ? reader.read_be32("transition actor UID") : value.uid;
    value.pid = reader.read_be32("transition PID");
    reader.require_eof("publication channel state");
    return value;
}

std::string publication_channel_json(const PublicationChannel& value,
                                     const bool include_history,
                                     const std::string_view outbound_status,
                                     const std::string_view automatic_observation) {
    const auto grant_json = [](const PublicationChannelAutomaticGrant& grant) {
        return "{\"generation\":" + std::to_string(grant.generation) +
            ",\"observed_channel_revision\":" +
                std::to_string(grant.observed_channel_revision) +
            ",\"state\":" + json_string(grant.state) +
            ",\"reason\":" + json_string(grant.reason) +
            ",\"error\":" + json_string(grant.error) +
            ",\"maximum_publications\":" +
                std::to_string(grant.maximum_publications) +
            ",\"minimum_interval_ms\":" +
                std::to_string(grant.minimum_interval_ms) +
            ",\"publications_completed\":" +
                std::to_string(grant.publications) +
            ",\"start_sequence\":" + std::to_string(grant.start_sequence) +
            ",\"authority_digest\":" +
                json_string(datacube::hex_lower(grant.authority_digest)) +
            ",\"configuration_event\":" +
                std::to_string(grant.configuration_event) +
            ",\"grant_unix_ms\":" + std::to_string(grant.unix_ms) +
            ",\"grant_pid\":" + std::to_string(grant.pid) +
            ",\"ended_configuration_event\":" +
                std::to_string(grant.ended_configuration_event) +
            ",\"ended_unix_ms\":" + std::to_string(grant.ended_unix_ms) +
            ",\"ended_uid\":" + std::to_string(grant.ended_uid) +
            ",\"ended_pid\":" + std::to_string(grant.ended_pid) + "}";
    };
    std::string out =
        "{\"name\":" + json_string(value.name) +
        ",\"owner_uid\":" + std::to_string(value.uid) +
        ",\"instance\":" + json_string(datacube::hex_lower(value.instance)) +
        ",\"projection_consumer\":" + json_string(value.projection_name) +
        ",\"projection_instance\":" +
            json_string(datacube::hex_lower(value.projection_instance)) +
        ",\"projection_definition_digest\":" +
            json_string(datacube::hex_lower(value.projection_definition_digest)) +
        ",\"recipient\":" + json_string(value.recipient) +
        ",\"scope\":" + json_string(value.scope) +
        ",\"key_policy\":\"ACTIVE_AT_PUBLISH\"" +
        ",\"maximum_publications\":" + std::to_string(value.maximum_publications) +
        ",\"creation_reason\":" + json_string(value.creation_reason) +
        ",\"created_configuration_event\":" +
            std::to_string(value.created_configuration_event) +
        ",\"created_unix_ms\":" + std::to_string(value.created_unix_ms) +
        ",\"created_pid\":" + std::to_string(value.created_pid) +
        ",\"actor_uid\":" + std::to_string(value.actor_uid) +
        ",\"revision\":" + std::to_string(value.revision) +
        ",\"current_epoch\":" + std::to_string(publication_channel_epoch(value)) +
        ",\"publication_count\":" + std::to_string(value.publications.size()) +
        ",\"lifecycle\":" + json_string(value.retirement ? "RETIRED" : "ACTIVE") +
        ",\"latest_outbound_status\":" +
            json_string(outbound_status.empty() ? "NONE" : outbound_status) +
        ",\"automatic_schedule_revision\":" +
            std::to_string(value.automatic_schedule_revision) +
        ",\"automatic_generation\":" +
            std::to_string(value.automatic_grants.size()) +
        ",\"automatic_observation\":" +
            json_string(automatic_observation.empty() ? "UNOBSERVED" : automatic_observation) +
        ",\"automatic_grant\":" +
            (value.automatic_grants.empty() ? std::string("null") :
                grant_json(value.automatic_grants.back()));
    if (!value.publications.empty()) {
        const auto& latest = value.publications.back();
        out += ",\"head_operation\":" + json_string(datacube::hex_lower(latest.operation_id)) +
            ",\"head_epoch\":" + std::to_string(latest.epoch) +
            ",\"head_result_digest\":" + json_string(datacube::hex_lower(latest.result_digest)) +
            ",\"head_processed_position\":" + std::to_string(latest.processed_position) +
            ",\"head_recipient_generation\":" + json_string(latest.recipient_generation) +
            ",\"head_automatic\":" + std::string(latest.automatic ? "true" : "false") +
            ",\"head_automatic_generation\":" +
                std::to_string(latest.automatic_grant_generation);
    } else {
        out += ",\"head_operation\":null,\"head_result_digest\":null";
    }
    if (include_history) {
        out += ",\"publications\":[";
        for (std::size_t i = 0U; i < value.publications.size(); ++i) {
            if (i != 0U) { out += ','; }
            const auto& item = value.publications[i];
            out += "{\"sequence\":" + std::to_string(item.sequence) +
                ",\"epoch\":" + std::to_string(item.epoch) +
                ",\"projection_revision\":" + std::to_string(item.projection_revision) +
                ",\"processed_position\":" + std::to_string(item.processed_position) +
                ",\"result_digest\":" + json_string(datacube::hex_lower(item.result_digest)) +
                ",\"source_commitment\":" + json_string(datacube::hex_lower(item.source_commitment)) +
                ",\"operation_id\":" + json_string(datacube::hex_lower(item.operation_id)) +
                ",\"record_digest\":" + json_string(datacube::hex_lower(item.record_digest)) +
                ",\"corrects\":" + (item.corrects ?
                    json_string(datacube::hex_lower(*item.corrects)) : "null") +
                ",\"recipient_generation\":" + json_string(item.recipient_generation) +
                ",\"recipient_spki_sha256\":" +
                    json_string(datacube::hex_lower(item.recipient_spki_sha256)) +
                ",\"authority_digest\":" + json_string(datacube::hex_lower(item.authority_digest)) +
                ",\"prior_epoch_terminal_operation\":" +
                    (item.prior_epoch_terminal_operation ?
                        json_string(datacube::hex_lower(*item.prior_epoch_terminal_operation)) :
                        "null") +
                ",\"prior_epoch_terminal_outcome\":" +
                    (item.prior_epoch_terminal_outcome.empty() ? "null" :
                        json_string(item.prior_epoch_terminal_outcome)) +
                ",\"epoch_reason\":" +
                    (item.epoch_reason.empty() ? "null" : json_string(item.epoch_reason)) +
                ",\"epoch_actor_uid\":" + std::to_string(item.epoch_actor_uid) +
                ",\"automatic\":" + std::string(item.automatic ? "true" : "false") +
                ",\"automatic_generation\":" +
                    std::to_string(item.automatic_grant_generation) +
                ",\"configuration_event\":" + std::to_string(item.configuration_event) +
                ",\"unix_ms\":" + std::to_string(item.unix_ms) +
                ",\"pid\":" + std::to_string(item.pid) + "}";
        }
        out += "]";
        out += ",\"automatic_grants\":[";
        for (std::size_t i = 0U; i < value.automatic_grants.size(); ++i) {
            if (i != 0U) { out += ','; }
            out += grant_json(value.automatic_grants[i]);
        }
        out += "]";
    }
    if (value.retirement) {
        out += ",\"retirement\":{\"revision\":" +
            std::to_string(value.retirement->revision) +
            ",\"cancelled_pending\":" +
            std::string(value.retirement->cancelled_pending ? "true" : "false") +
            ",\"cancelled_operation\":" +
            (value.retirement->cancelled_operation ?
                json_string(datacube::hex_lower(*value.retirement->cancelled_operation)) : "null") +
            ",\"reason\":" + json_string(value.retirement->reason) +
            ",\"configuration_event\":" +
                std::to_string(value.retirement->configuration_event) +
            ",\"unix_ms\":" + std::to_string(value.retirement->unix_ms) +
            ",\"pid\":" + std::to_string(value.retirement->pid) + "}";
    } else {
        out += ",\"retirement\":null";
    }
    return out + "}";
}

namespace {

std::string publication_channel_schedule_json(
    const PublicationChannel& value, const std::string_view observation) {
    std::string out =
        "{\"name\":" + json_string(value.name) +
        ",\"owner_uid\":" + std::to_string(value.uid) +
        ",\"instance\":" + json_string(datacube::hex_lower(value.instance)) +
        ",\"channel_revision\":" + std::to_string(value.revision) +
        ",\"schedule_revision\":" +
            std::to_string(value.automatic_schedule_revision) +
        ",\"grant_generation\":" +
            std::to_string(value.automatic_grants.size()) +
        ",\"lifecycle\":" +
            json_string(value.retirement ? "RETIRED" : "ACTIVE") +
        ",\"observation\":" + json_string(observation);
    if (value.automatic_grants.empty()) {
        out += ",\"grant\":null";
    } else {
        const auto& grant = value.automatic_grants.back();
        out += ",\"grant\":{\"generation\":" +
            std::to_string(grant.generation) +
            ",\"observed_channel_revision\":" +
                std::to_string(grant.observed_channel_revision) +
            ",\"state\":" + json_string(grant.state) +
            ",\"reason\":" + json_string(grant.reason) +
            ",\"error\":" + json_string(grant.error) +
            ",\"maximum_publications\":" +
                std::to_string(grant.maximum_publications) +
            ",\"minimum_interval_ms\":" +
                std::to_string(grant.minimum_interval_ms) +
            ",\"publications_completed\":" +
                std::to_string(grant.publications) +
            ",\"configuration_event\":" +
                std::to_string(grant.configuration_event) +
            ",\"grant_unix_ms\":" + std::to_string(grant.unix_ms) +
            ",\"ended_configuration_event\":" +
                std::to_string(grant.ended_configuration_event) +
            ",\"ended_unix_ms\":" + std::to_string(grant.ended_unix_ms) +
            ",\"ended_uid\":" + std::to_string(grant.ended_uid) +
            ",\"ended_pid\":" + std::to_string(grant.ended_pid) + "}";
    }
    return out + "}";
}

}  // namespace

void NodeState::validate_publication_channel_locked(
    const PublicationChannel& value,
    const std::optional<EvidenceRecord>& pending_record) const {
    const auto invalid = []() {
        app_fail("JOURNAL_CORRUPT", "invalid publication channel state");
    };
    const auto valid_transition = value.transition == "CREATE" ||
        value.transition == "PUBLISH" || value.transition == "RETIRE" ||
        value.transition == "AUTO_ENABLE" || value.transition == "AUTO_PAUSE" ||
        value.transition == "AUTO_BLOCK" || value.transition == "AUTO_PUBLISH" ||
        value.transition == "NEW_EPOCH";
    if (!valid_name(value.name) || !valid_name(value.projection_name) ||
        digest_is_zero(value.instance) || digest_is_zero(value.projection_instance) ||
        digest_is_zero(value.projection_definition_digest) ||
        value.maximum_publications == 0U ||
        value.maximum_publications > kPublicationChannelMaximumRevisions ||
        !valid_reason(value.creation_reason) ||
        value.created_configuration_event == 0U ||
        value.created_configuration_event > configuration_events_.size() ||
        value.created_unix_ms == 0U || value.created_pid == 0U ||
        value.publications.size() > value.maximum_publications ||
        value.automatic_grants.size() > kPublicationChannelAutomaticGrantLimit ||
        value.key_policy != PublicationChannelKeyPolicy::active_at_publish ||
        value.configuration_event == 0U ||
        value.configuration_event > configuration_events_.size() ||
        value.created_configuration_event > value.configuration_event ||
        value.unix_ms == 0U || value.pid == 0U || !valid_transition) {
        invalid();
    }
    require_node_id(value.recipient, "channel recipient");
    require_scope(value.scope);
    const auto projection = consumers_.find(consumer_key(value.uid, value.projection_name));
    if (projection == consumers_.end() || !projection->second.projection ||
        projection->second.instance != value.projection_instance ||
        projection->second.projection->definition_digest !=
            value.projection_definition_digest) {
        invalid();
    }
    const auto expected_revision = 1U + static_cast<std::uint64_t>(value.publications.size()) +
        (value.retirement ? 1U : 0U);
    if (value.revision != expected_revision) { invalid(); }

    std::vector<std::uint64_t> automatic_counts(value.automatic_grants.size(), 0U);
    std::optional<datacube::Digest32> previous;
    std::uint64_t previous_projection_revision = 0U;
    std::uint64_t previous_epoch = 1U;
    std::uint64_t previous_configuration_event = value.created_configuration_event;
    for (std::size_t i = 0U; i < value.publications.size(); ++i) {
        const auto& item = value.publications[i];
        const bool first = i == 0U;
        const bool same_epoch = first ? item.epoch == 1U : item.epoch == previous_epoch;
        const bool starts_epoch = !first && item.epoch == previous_epoch + 1U;
        const bool lineage_empty = !item.prior_epoch_terminal_operation &&
            item.prior_epoch_terminal_outcome.empty() && item.epoch_reason.empty() &&
            item.epoch_actor_uid == 0U;
        const bool lineage_valid = starts_epoch &&
            item.prior_epoch_terminal_operation == previous &&
            valid_terminal_outcome(item.prior_epoch_terminal_outcome) &&
            valid_reason(item.epoch_reason) && item.epoch_actor_uid == value.uid;
        const bool correction_valid = first ? !item.corrects :
            (same_epoch ? item.corrects == previous : starts_epoch && !item.corrects);
        const bool projection_order_valid = first ||
            (same_epoch ? item.projection_revision > previous_projection_revision :
                starts_epoch && item.projection_revision >= previous_projection_revision);
        if (item.sequence != i + 1U || item.projection_revision == 0U ||
            item.epoch == 0U || item.epoch > kPublicationChannelMaximumEpochs ||
            digest_is_zero(item.result_digest) || digest_is_zero(item.source_commitment) ||
            digest_is_zero(item.operation_id) || digest_is_zero(item.record_digest) ||
            !valid_generation_id(item.recipient_generation) ||
            digest_is_zero(item.recipient_spki_sha256) ||
            digest_is_zero(item.authority_digest) || item.configuration_event == 0U ||
            item.configuration_event > configuration_events_.size() ||
            item.configuration_event < previous_configuration_event ||
            item.configuration_event > value.configuration_event ||
            !projection_order_valid || item.unix_ms == 0U || item.pid == 0U ||
            !correction_valid || (!starts_epoch && !lineage_empty) ||
            (starts_epoch && !lineage_valid) || (starts_epoch && item.automatic) ||
            (item.automatic != (item.automatic_grant_generation != 0U))) {
            invalid();
        }
        if (item.automatic) {
            if (item.automatic_grant_generation > value.automatic_grants.size()) {
                invalid();
            }
            ++automatic_counts[static_cast<std::size_t>(
                item.automatic_grant_generation - 1U)];
        }
        const auto key = datacube::hex_lower(item.operation_id);
        const auto found = outbound_index_.find(key);
        const EvidenceRecord* record = nullptr;
        if (found != outbound_index_.end()) {
            record = &outbound_[found->second].record;
        } else if (pending_record && pending_record->operation_id == item.operation_id) {
            record = &*pending_record;
        }
        if (record == nullptr) { invalid(); }
        validate_channel_record_payload(*record, value, item,
            projection->second, node_id_);
        previous = item.operation_id;
        previous_projection_revision = item.projection_revision;
        previous_epoch = item.epoch;
        previous_configuration_event = item.configuration_event;
    }

    std::uint64_t expected_schedule_revision =
        static_cast<std::uint64_t>(value.automatic_grants.size());
    for (std::size_t i = 0U; i < value.automatic_grants.size(); ++i) {
        const auto& grant = value.automatic_grants[i];
        if (grant.generation != i + 1U || grant.observed_channel_revision == 0U ||
            grant.observed_channel_revision > value.revision ||
            grant.configuration_event == 0U ||
            grant.configuration_event > configuration_events_.size() ||
            grant.configuration_event > value.configuration_event ||
            grant.unix_ms == 0U || grant.pid == 0U ||
            grant.maximum_publications == 0U || grant.maximum_publications > 10'000U ||
            grant.minimum_interval_ms < 10U || grant.minimum_interval_ms > 60'000U ||
            digest_is_zero(grant.authority_digest) || !valid_reason(grant.reason) ||
            grant.start_sequence > value.publications.size() ||
            grant.publications != automatic_counts[i] ||
            grant.publications > grant.maximum_publications) {
            invalid();
        }
        const auto& event = configuration_events_[grant.configuration_event - 1U];
        if (event.kind == "REJECTED") { invalid(); }
        const auto cfg = parse_runtime_config(event.canonical,
            "/publication-channel-automatic-history",
            IdentityFileValidation::deferred);
        const auto access = evidence_read_access(
            cfg.evidence_read, cfg.local_control, value.uid);
        const bool adopted = std::any_of(projection->second.adoptions.begin(),
            projection->second.adoptions.end(), [&](const auto& adoption) {
                return adoption.authority == grant.authority_digest &&
                    adoption.configuration_event <= grant.configuration_event;
            });
        if (cfg.format_version < 12U ||
            !local_control_allows(cfg.local_control, value.uid,
                LocalControlClass::projection) ||
            !local_control_allows(cfg.local_control, value.uid,
                LocalControlClass::consumer) ||
            !local_control_allows(cfg.local_control, value.uid,
                LocalControlClass::submit) ||
            !evidence_read_allows(access, projection->second.selection.issuer,
                projection->second.selection.scope,
                projection->second.selection.include_payload) ||
            access.digest != grant.authority_digest || !adopted) {
            invalid();
        }
        if (grant.state == "ENABLED") {
            if (i + 1U != value.automatic_grants.size() || value.retirement ||
                grant.publications == grant.maximum_publications || !grant.error.empty() ||
                grant.ended_configuration_event != 0U || grant.ended_unix_ms != 0U ||
                grant.ended_uid != 0U || grant.ended_pid != 0U) {
                invalid();
            }
        } else if (grant.state == "EXHAUSTED") {
            if (grant.publications != grant.maximum_publications ||
                grant.error != "PUBLICATION_AUTOMATIC_BUDGET_EXHAUSTED" ||
                grant.ended_configuration_event == 0U || grant.ended_unix_ms == 0U ||
                grant.ended_pid == 0U) {
                invalid();
            }
        } else if (grant.state == "PAUSED" || grant.state == "BLOCKED") {
            if (!valid_reason(grant.error) || grant.ended_configuration_event == 0U ||
                grant.ended_unix_ms == 0U || grant.ended_pid == 0U ||
                (grant.state == "PAUSED" && grant.ended_uid != value.uid)) {
                invalid();
            }
            ++expected_schedule_revision;
        } else {
            invalid();
        }
        if (grant.state == "EXHAUSTED") {
            // Exhaustion is part of the final successful publication transition.
        }
        expected_schedule_revision += grant.publications;
    }
    if (value.automatic_schedule_revision != expected_schedule_revision) {
        invalid();
    }

    if (value.transition == "CREATE") {
        if (value.revision != 1U || !value.publications.empty() || value.retirement ||
            value.created_configuration_event != value.configuration_event ||
            value.created_unix_ms != value.unix_ms || value.created_pid != value.pid ||
            value.automatic_schedule_revision != 0U ||
            !value.automatic_grants.empty()) {
            invalid();
        }
    } else if (value.transition == "PUBLISH" ||
               value.transition == "AUTO_PUBLISH" ||
               value.transition == "NEW_EPOCH") {
        if (value.publications.empty() || value.retirement) { invalid(); }
        const auto& latest = value.publications.back();
        if (latest.configuration_event != value.configuration_event ||
            latest.unix_ms != value.unix_ms || latest.pid != value.pid ||
            latest.automatic != (value.transition == "AUTO_PUBLISH")) {
            invalid();
        }
        if (value.transition == "NEW_EPOCH" &&
            (!latest.prior_epoch_terminal_operation ||
             !valid_terminal_outcome(latest.prior_epoch_terminal_outcome) ||
             !valid_reason(latest.epoch_reason) ||
             latest.epoch_actor_uid != value.actor_uid ||
             latest.epoch_actor_uid != value.uid || latest.corrects ||
             latest.epoch <= 1U)) {
            invalid();
        }
        if (value.transition != "NEW_EPOCH" &&
            latest.prior_epoch_terminal_operation) {
            invalid();
        }
        if (latest.automatic &&
            (value.automatic_grants.empty() ||
             latest.automatic_grant_generation !=
                value.automatic_grants.back().generation)) {
            invalid();
        }
    } else if (value.transition == "AUTO_ENABLE") {
        if (value.automatic_grants.empty()) { invalid(); }
        const auto& grant = value.automatic_grants.back();
        if (grant.state != "ENABLED" || grant.configuration_event != value.configuration_event ||
            grant.unix_ms != value.unix_ms || grant.pid != value.pid) {
            invalid();
        }
    } else if (value.transition == "AUTO_PAUSE" ||
               value.transition == "AUTO_BLOCK") {
        if (value.automatic_grants.empty()) { invalid(); }
        const auto& grant = value.automatic_grants.back();
        const auto expected_state = value.transition == "AUTO_PAUSE" ? "PAUSED" : "BLOCKED";
        if (grant.state != expected_state ||
            grant.ended_configuration_event != value.configuration_event ||
            grant.ended_unix_ms != value.unix_ms || grant.ended_pid != value.pid) {
            invalid();
        }
    }
    if (value.retirement) {
        const auto& retirement = *value.retirement;
        if (value.transition != "RETIRE" || retirement.revision != value.revision ||
            retirement.configuration_event != value.configuration_event ||
            retirement.unix_ms != value.unix_ms || retirement.pid != value.pid ||
            !valid_reason(retirement.reason) ||
            (retirement.cancelled_pending != retirement.cancelled_operation.has_value()) ||
            (retirement.cancelled_operation && (value.publications.empty() ||
                *retirement.cancelled_operation != value.publications.back().operation_id))) {
            invalid();
        }
        if (!value.automatic_grants.empty() &&
            value.automatic_grants.back().state == "BLOCKED" &&
            value.automatic_grants.back().error == "PUBLICATION_CHANNEL_RETIRED" &&
            value.automatic_grants.back().ended_configuration_event !=
                value.configuration_event) {
            invalid();
        }
    } else if (value.transition == "RETIRE") {
        invalid();
    }
}

void NodeState::validate_publication_channel_registry_locked() const {
    std::size_t active = 0U;
    std::size_t retired = 0U;
    std::map<std::uint32_t, std::size_t> active_by_uid;
    std::map<std::uint32_t, std::size_t> retired_by_uid;
    std::set<std::string> instances;
    for (const auto& [key, value] : publication_channels_) {
        if (key != publication_channel_key(value.uid, value.name) ||
            !instances.emplace(datacube::hex_lower(value.instance)).second) {
            app_fail("JOURNAL_CORRUPT", "publication channel registry identity conflict");
        }
        validate_publication_channel_locked(value);
        if (value.retirement) {
            ++retired; ++retired_by_uid[value.uid];
        } else {
            ++active; ++active_by_uid[value.uid];
        }
    }
    if (active > kPublicationChannelLimit || retired > kRetiredPublicationChannelLimit) {
        app_fail("PUBLICATION_CHANNEL_LIMIT", "publication channel registry exhausted");
    }
    for (const auto& [uid, count] : active_by_uid) {
        static_cast<void>(uid);
        if (count > kPublicationChannelUidLimit) {
            app_fail("PUBLICATION_CHANNEL_LIMIT", "per-UID active channel limit exceeded");
        }
    }
    for (const auto& [uid, count] : retired_by_uid) {
        static_cast<void>(uid);
        if (count > kRetiredPublicationChannelUidLimit) {
            app_fail("PUBLICATION_CHANNEL_LIMIT", "per-UID retired channel limit exceeded");
        }
    }
}

void NodeState::apply_publication_channel(const datacube::OctetView bytes,
                                          const bool replaying,
                                          const bool validate_only) {
    auto transaction = decode_transaction(bytes);
    auto& next = transaction.channel;
    if (next.configuration_event != active_configuration_event(configuration_events_)) {
        app_fail("JOURNAL_CORRUPT", "publication channel must bind the active configuration");
    }
    const auto key = publication_channel_key(next.uid, next.name);
    const auto found = publication_channels_.find(key);
    std::optional<EvidenceRecord> record;
    std::optional<OutboundPolicy> policy;
    if (transaction.outbound) {
        auto decoded = decode_outbound_composite(*transaction.outbound);
        record = std::move(decoded.first);
        policy = std::move(decoded.second);
    }
    const auto compare_expected = [&](const PublicationChannel& expected,
                                      const std::string_view detail) {
        if (encode_publication_channel(expected) != encode_publication_channel(next)) {
            app_fail("JOURNAL_CORRUPT", std::string(detail));
        }
    };
    if (next.transition == "CREATE") {
        if (found != publication_channels_.end() || transaction.outbound ||
            transaction.cancellation || next.revision != 1U ||
            !next.publications.empty() || next.retirement ||
            next.automatic_schedule_revision != 0U ||
            !next.automatic_grants.empty() || next.actor_uid != next.uid) {
            app_fail("JOURNAL_CORRUPT", "invalid publication channel creation");
        }
    } else if (next.transition == "PUBLISH" ||
               next.transition == "AUTO_PUBLISH") {
        const bool automatic = next.transition == "AUTO_PUBLISH";
        if (found == publication_channels_.end() || found->second.retirement ||
            !record || !policy || transaction.cancellation ||
            next.revision != found->second.revision + 1U ||
            next.publications.size() != found->second.publications.size() + 1U) {
            app_fail("JOURNAL_CORRUPT", "invalid publication channel publication");
        }
        auto expected = found->second;
        expected.revision = next.revision;
        expected.publications.push_back(next.publications.back());
        expected.transition = next.transition;
        expected.configuration_event = next.configuration_event;
        expected.unix_ms = next.unix_ms;
        expected.actor_uid = next.actor_uid;
        expected.pid = next.pid;
        if (automatic) {
            if (!automatic_grant_enabled(found->second) ||
                next.automatic_schedule_revision !=
                    found->second.automatic_schedule_revision + 1U ||
                next.automatic_grants.size() != found->second.automatic_grants.size()) {
                app_fail("JOURNAL_CORRUPT", "automatic publication lacks one enabled grant");
            }
            expected.automatic_schedule_revision = next.automatic_schedule_revision;
            auto& grant = expected.automatic_grants.back();
            if (grant.publications == std::numeric_limits<std::uint64_t>::max()) {
                app_fail("JOURNAL_CORRUPT", "automatic publication counter exhausted");
            }
            ++grant.publications;
            if (grant.publications == grant.maximum_publications) {
                finish_automatic_grant(grant, expected, "EXHAUSTED",
                    "PUBLICATION_AUTOMATIC_BUDGET_EXHAUSTED");
            }
        } else {
            if (next.automatic_schedule_revision !=
                    found->second.automatic_schedule_revision ||
                next.automatic_grants != found->second.automatic_grants ||
                next.actor_uid != next.uid) {
                app_fail("JOURNAL_CORRUPT", "manual publication altered automatic scheduling");
            }
        }
        compare_expected(expected, "publication channel prior state mismatch");
        const auto& publication = next.publications.back();
        if (publication.automatic != automatic ||
            (automatic && (next.automatic_grants.empty() ||
                publication.automatic_grant_generation !=
                    next.automatic_grants.back().generation)) ||
            (!automatic && publication.automatic_grant_generation != 0U) ||
            record->operation_id != publication.operation_id ||
            evidence_record_digest(*record) != publication.record_digest ||
            !policy->peer_generation || !policy->peer_spki_sha256 ||
            *policy->peer_generation != publication.recipient_generation ||
            *policy->peer_spki_sha256 != publication.recipient_spki_sha256) {
            app_fail("JOURNAL_CORRUPT", "publication channel outbound binding mismatch");
        }
        if (!found->second.publications.empty()) {
            const auto prior = outbound_index_.find(datacube::hex_lower(
                found->second.publications.back().operation_id));
            if (prior == outbound_index_.end() || !outbound_[prior->second].receipt) {
                app_fail("JOURNAL_CORRUPT",
                         "channel advanced without an acknowledged predecessor");
            }
        }
        validate_new_outbound_locked(*record, *policy);
    } else if (next.transition == "NEW_EPOCH") {
        if (found == publication_channels_.end() || found->second.retirement ||
            found->second.publications.empty() || !record || !policy ||
            transaction.cancellation || next.revision != found->second.revision + 1U ||
            next.publications.size() != found->second.publications.size() + 1U ||
            next.actor_uid != next.uid) {
            app_fail("JOURNAL_CORRUPT", "invalid publication channel epoch transition");
        }
        const auto& prior_publication = found->second.publications.back();
        const auto prior_found = outbound_index_.find(
            datacube::hex_lower(prior_publication.operation_id));
        if (prior_found == outbound_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "epoch predecessor is absent from the outbox");
        }
        const auto terminal = terminal_channel_outcome(outbound_[prior_found->second]);
        const auto& publication = next.publications.back();
        if (terminal.empty() || publication.epoch != prior_publication.epoch + 1U ||
            publication.corrects ||
            publication.prior_epoch_terminal_operation != prior_publication.operation_id ||
            publication.prior_epoch_terminal_outcome != terminal ||
            publication.epoch_actor_uid != next.uid ||
            publication.epoch_reason.empty() || publication.automatic ||
            publication.automatic_grant_generation != 0U ||
            record->operation_id != publication.operation_id ||
            evidence_record_digest(*record) != publication.record_digest ||
            !policy->peer_generation || !policy->peer_spki_sha256 ||
            *policy->peer_generation != publication.recipient_generation ||
            *policy->peer_spki_sha256 != publication.recipient_spki_sha256) {
            app_fail("JOURNAL_CORRUPT", "publication epoch lineage is invalid");
        }
        auto expected = found->second;
        expected.revision = next.revision;
        expected.publications.push_back(publication);
        expected.transition = "NEW_EPOCH";
        expected.configuration_event = next.configuration_event;
        expected.unix_ms = next.unix_ms;
        expected.actor_uid = next.actor_uid;
        expected.pid = next.pid;
        if (automatic_grant_enabled(found->second)) {
            expected.automatic_schedule_revision =
                found->second.automatic_schedule_revision + 1U;
            finish_automatic_grant(expected.automatic_grants.back(), expected,
                "BLOCKED", "PUBLICATION_CHANNEL_NEW_EPOCH_REQUIRES_NEW_GRANT");
        }
        compare_expected(expected, "publication epoch prior state mismatch");
        validate_new_outbound_locked(*record, *policy);
    } else if (next.transition == "AUTO_ENABLE") {
        if (found == publication_channels_.end() || found->second.retirement ||
            transaction.outbound || transaction.cancellation ||
            next.revision != found->second.revision ||
            next.publications != found->second.publications ||
            next.automatic_schedule_revision !=
                found->second.automatic_schedule_revision + 1U ||
            next.automatic_grants.size() != found->second.automatic_grants.size() + 1U ||
            automatic_grant_enabled(found->second) || next.actor_uid != next.uid) {
            app_fail("JOURNAL_CORRUPT", "invalid automatic publication enable");
        }
        auto expected = found->second;
        expected.automatic_schedule_revision = next.automatic_schedule_revision;
        expected.automatic_grants.push_back(next.automatic_grants.back());
        expected.transition = "AUTO_ENABLE";
        expected.configuration_event = next.configuration_event;
        expected.unix_ms = next.unix_ms;
        expected.actor_uid = next.actor_uid;
        expected.pid = next.pid;
        compare_expected(expected, "automatic publication enable prior state mismatch");
        const auto& grant = next.automatic_grants.back();
        if (grant.generation != next.automatic_grants.size() ||
            grant.observed_channel_revision != found->second.revision ||
            grant.configuration_event != next.configuration_event ||
            grant.unix_ms != next.unix_ms || grant.pid != next.pid ||
            grant.start_sequence != found->second.publications.size() ||
            grant.publications != 0U || grant.state != "ENABLED" ||
            !grant.error.empty() || grant.ended_configuration_event != 0U ||
            grant.ended_unix_ms != 0U || grant.ended_uid != 0U ||
            grant.ended_pid != 0U) {
            app_fail("JOURNAL_CORRUPT", "automatic publication grant is invalid");
        }
    } else if (next.transition == "AUTO_PAUSE" ||
               next.transition == "AUTO_BLOCK") {
        const bool pause = next.transition == "AUTO_PAUSE";
        if (found == publication_channels_.end() || found->second.retirement ||
            transaction.outbound || transaction.cancellation ||
            !automatic_grant_enabled(found->second) ||
            next.revision != found->second.revision ||
            next.publications != found->second.publications ||
            next.automatic_schedule_revision !=
                found->second.automatic_schedule_revision + 1U ||
            next.automatic_grants.size() != found->second.automatic_grants.size() ||
            (pause && next.actor_uid != next.uid)) {
            app_fail("JOURNAL_CORRUPT", "invalid automatic publication stop");
        }
        if (!pause) {
            const auto block_config = parse_runtime_config(
                configuration_events_.at(next.configuration_event - 1U).canonical,
                "/publication-channel-automatic-block",
                IdentityFileValidation::deferred);
            const auto expected_error =
                automatic_publication_block_error_locked(found->second, block_config);
            if (expected_error.empty() ||
                expected_error != next.automatic_grants.back().error) {
                app_fail("JOURNAL_CORRUPT",
                         "automatic publication block reason is not source-derived");
            }
        }
        auto expected = found->second;
        expected.automatic_schedule_revision = next.automatic_schedule_revision;
        expected.transition = next.transition;
        expected.configuration_event = next.configuration_event;
        expected.unix_ms = next.unix_ms;
        expected.actor_uid = next.actor_uid;
        expected.pid = next.pid;
        finish_automatic_grant(expected.automatic_grants.back(), expected,
            pause ? "PAUSED" : "BLOCKED",
            next.automatic_grants.back().error);
        compare_expected(expected, "automatic publication stop prior state mismatch");
    } else if (next.transition == "RETIRE") {
        if (found == publication_channels_.end() || found->second.retirement ||
            transaction.outbound || next.revision != found->second.revision + 1U ||
            !next.retirement || next.actor_uid != next.uid) {
            app_fail("JOURNAL_CORRUPT", "invalid publication channel retirement");
        }
        auto expected = found->second;
        expected.revision = next.revision;
        expected.retirement = next.retirement;
        expected.transition = "RETIRE";
        expected.configuration_event = next.configuration_event;
        expected.unix_ms = next.unix_ms;
        expected.actor_uid = next.actor_uid;
        expected.pid = next.pid;
        if (automatic_grant_enabled(found->second)) {
            expected.automatic_schedule_revision =
                found->second.automatic_schedule_revision + 1U;
            finish_automatic_grant(expected.automatic_grants.back(), expected,
                "BLOCKED", "PUBLICATION_CHANNEL_RETIRED");
        }
        compare_expected(expected, "publication channel retirement prior state mismatch");
        if (transaction.cancellation.has_value() !=
            next.retirement->cancelled_pending) {
            app_fail("JOURNAL_CORRUPT",
                     "retirement cancellation marker does not match its transition");
        }
        if (transaction.cancellation) {
            if (!next.retirement->cancelled_operation || next.publications.empty()) {
                app_fail("JOURNAL_CORRUPT", "retirement cancellation lacks publication");
            }
            const auto outbound_found = outbound_index_.find(datacube::hex_lower(
                *next.retirement->cancelled_operation));
            if (outbound_found == outbound_index_.end() ||
                !outbound_is_pending(outbound_[outbound_found->second]) ||
                !outbound_[outbound_found->second].delivery ||
                !outbound_[outbound_found->second].delivery->policy.peer_generation ||
                !outbound_[outbound_found->second].delivery->policy.peer_spki_sha256) {
                app_fail("JOURNAL_CORRUPT", "retirement cancellation is not pending");
            }
            const auto cancellation = decode_cancellation_payload(*transaction.cancellation);
            const auto& outbound = outbound_[outbound_found->second];
            if (cancellation.operation != *next.retirement->cancelled_operation ||
                cancellation.actor != "LOCAL_PUBLICATION_CHANNEL" ||
                cancellation.reason != next.retirement->reason ||
                cancellation.generation !=
                    *outbound.delivery->policy.peer_generation ||
                cancellation.spki_sha256 !=
                    *outbound.delivery->policy.peer_spki_sha256 ||
                cancellation.unix_ms == 0U) {
                app_fail("JOURNAL_CORRUPT",
                         "retirement cancellation does not bind the channel head");
            }
        } else if (!next.publications.empty()) {
            const auto outbound_found = outbound_index_.find(datacube::hex_lower(
                next.publications.back().operation_id));
            if (outbound_found == outbound_index_.end() ||
                outbound_is_pending(outbound_[outbound_found->second])) {
                app_fail("JOURNAL_CORRUPT",
                         "unresolved publication was retired without cancellation");
            }
        }
    } else {
        app_fail("JOURNAL_CORRUPT", "unknown publication channel transition");
    }
    validate_publication_channel_locked(next, record);
    if (validate_only) { return; }
    const bool previous_binding = applying_runtime_bound_mutation_;
    applying_runtime_bound_mutation_ = true;
    try {
        if (transaction.outbound) {
            apply_entry(EntryKind::outbound_queued_with_policy,
                        *transaction.outbound, replaying);
        }
        if (transaction.cancellation) {
            apply_entry(EntryKind::outbound_cancelled,
                        *transaction.cancellation, replaying);
        }
        applying_runtime_bound_mutation_ = previous_binding;
    } catch (...) {
        applying_runtime_bound_mutation_ = previous_binding;
        throw;
    }
    index_outbound_associations(next);
    publication_channels_[key] = std::move(next);
    validate_publication_channel_registry_locked();
}

std::string NodeState::publication_channel_recipient(
    const std::uint32_t uid, const std::string_view name) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = publication_channels_.find(publication_channel_key(uid, name));
    if (found == publication_channels_.end()) {
        app_fail("PUBLICATION_CHANNEL_NOT_FOUND",
                 "no channel with this name is owned by the connected UID");
    }
    return found->second.recipient;
}

std::string NodeState::automatic_publication_block_error_locked(
    const PublicationChannel& channel, const RuntimeConfig& config) const {
    if (config.format_version < 12U ||
        !local_control_allows(config.local_control, channel.uid,
                              LocalControlClass::projection) ||
        !local_control_allows(config.local_control, channel.uid,
                              LocalControlClass::consumer) ||
        !local_control_allows(config.local_control, channel.uid,
                              LocalControlClass::submit)) {
        return "LOCAL_CONTROL_CLASS_DENIED";
    }
    const auto projection_it = consumers_.find(
        consumer_key(channel.uid, channel.projection_name));
    if (projection_it == consumers_.end() || !projection_it->second.projection) {
        return "PROJECTION_NOT_FOUND";
    }
    const auto& projection = projection_it->second;
    if (projection.instance != channel.projection_instance ||
        projection.projection->definition_digest !=
            channel.projection_definition_digest) {
        return "PUBLICATION_CHANNEL_PROJECTION_CONFLICT";
    }
    const auto access = evidence_read_access(
        config.evidence_read, config.local_control, channel.uid);
    if (!access.scoped || !access.metadata_allowed ||
        (projection.selection.include_payload && !access.payload_allowed)) {
        return "LOCAL_CONTROL_CLASS_DENIED";
    }
    if (!evidence_read_allows(access, projection.selection.issuer,
            projection.selection.scope, projection.selection.include_payload)) {
        return "CONSUMER_DOMAIN_DENIED";
    }
    if (channel.automatic_grants.empty() ||
        channel.automatic_grants.back().state != "ENABLED") {
        return "PUBLICATION_CHANNEL_SCHEDULE_NOT_ENABLED";
    }
    const auto& grant = channel.automatic_grants.back();
    if (grant.authority_digest != access.digest || projection.adoptions.empty() ||
        projection.adoptions.back().authority != access.digest) {
        return "PUBLICATION_AUTOMATIC_AUTHORITY_CHANGED";
    }
    if (!channel.publications.empty()) {
        const auto& head = channel.publications.back();
        const auto outbound_found = outbound_index_.find(
            datacube::hex_lower(head.operation_id));
        if (outbound_found == outbound_index_.end()) {
            return "PUBLICATION_CHANNEL_HEAD_MISSING";
        }
        const auto& outbound = outbound_[outbound_found->second];
        if (!outbound.receipt) {
            if (active_outbound_rejection(outbound)) {
                return "PUBLICATION_CHANNEL_PREDECESSOR_REJECTED";
            }
            if (outbound.delivery && outbound.delivery->cancelled_unix_ms) {
                return "PUBLICATION_CHANNEL_PREDECESSOR_CANCELLED";
            }
            if (outbound.delivery && outbound.delivery->expired_unix_ms) {
                return "PUBLICATION_CHANNEL_PREDECESSOR_EXPIRED";
            }
        }
    }
    if (channel.publications.size() >= channel.maximum_publications) {
        return "PUBLICATION_CHANNEL_BUDGET_EXHAUSTED";
    }
    return {};
}

std::vector<PublicationChannelCandidate>
NodeState::automatic_publication_channel_candidates() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<PublicationChannelCandidate> result;
    result.reserve(publication_channels_.size());
    for (const auto& [key, channel] : publication_channels_) {
        if (!channel.retirement && automatic_grant_enabled(channel)) {
            result.push_back(PublicationChannelCandidate{
                .key = key,
                .recipient = channel.recipient,
                .generation = channel.automatic_grants.size(),
                .minimum_interval_ms =
                    channel.automatic_grants.back().minimum_interval_ms,
            });
        }
    }
    return result;
}

bool NodeState::automatic_publication_channel_step(
    const std::string_view key_view,
    const RuntimeConfig& config,
    const std::uint64_t configuration_event,
    const std::uint32_t executor_uid,
    const std::uint32_t executor_pid,
    const std::optional<OutboundPolicy>& policy) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (poisoned_) {
        app_fail("STATE_RESTART_REQUIRED",
                 "automatic publication writer requires restart");
    }
    if (configuration_event == 0U ||
        configuration_event != active_configuration_event(configuration_events_)) {
        app_fail("PUBLICATION_CHANNEL_CONFIGURATION_MISMATCH",
                 "automatic publication must retain the active configuration");
    }
    const auto found = publication_channels_.find(std::string(key_view));
    if (found == publication_channels_.end() || found->second.retirement ||
        !automatic_grant_enabled(found->second)) {
        return false;
    }
    const auto& channel = found->second;
    const auto projection_it = consumers_.find(
        consumer_key(channel.uid, channel.projection_name));

    const auto block = [&](const std::string_view error) {
        auto next = channel;
        ++next.automatic_schedule_revision;
        next.transition = "AUTO_BLOCK";
        next.configuration_event = configuration_event;
        next.unix_ms = now_ms();
        next.actor_uid = executor_uid;
        next.pid = executor_pid;
        finish_automatic_grant(next.automatic_grants.back(), next,
                               "BLOCKED", error);
        append_entry(EntryKind::publication_channel,
            encode_transaction(next, std::nullopt, std::nullopt));
        return true;
    };

    if (config.format_version < 12U ||
        !local_control_allows(config.local_control, channel.uid,
                              LocalControlClass::projection) ||
        !local_control_allows(config.local_control, channel.uid,
                              LocalControlClass::consumer) ||
        !local_control_allows(config.local_control, channel.uid,
                              LocalControlClass::submit)) {
        return block("LOCAL_CONTROL_CLASS_DENIED");
    }
    if (projection_it == consumers_.end() || !projection_it->second.projection) {
        return block("PROJECTION_NOT_FOUND");
    }
    const auto& projection = projection_it->second;
    if (projection.instance != channel.projection_instance ||
        projection.projection->definition_digest !=
            channel.projection_definition_digest) {
        return block("PUBLICATION_CHANNEL_PROJECTION_CONFLICT");
    }
    const auto access = evidence_read_access(
        config.evidence_read, config.local_control, channel.uid);
    const EvidenceQueryContext context{
        .uid = channel.uid,
        .configuration_generation = config.runtime_generation,
        .configuration_digest = runtime_configuration_digest(
            canonical_runtime_config(config)),
        .read_access = access,
        .deadline = std::chrono::steady_clock::now() +
            std::chrono::milliseconds(5'000),
    };
    try {
        require_projection_access(projection, context);
    } catch (const AppError& error) {
        return block(error.code());
    }
    const auto& grant = channel.automatic_grants.back();
    if (grant.authority_digest != access.digest || projection.adoptions.empty() ||
        projection.adoptions.back().authority != access.digest) {
        return block("PUBLICATION_AUTOMATIC_AUTHORITY_CHANGED");
    }

    std::optional<datacube::Digest32> corrects;
    if (!channel.publications.empty()) {
        const auto& previous = channel.publications.back();
        const auto outbound_found = outbound_index_.find(
            datacube::hex_lower(previous.operation_id));
        if (outbound_found == outbound_index_.end()) {
            return block("PUBLICATION_CHANNEL_HEAD_MISSING");
        }
        const auto& outbound = outbound_[outbound_found->second];
        if (!outbound.receipt) {
            if (active_outbound_rejection(outbound)) {
                return block("PUBLICATION_CHANNEL_PREDECESSOR_REJECTED");
            }
            if (outbound.delivery && outbound.delivery->cancelled_unix_ms) {
                return block("PUBLICATION_CHANNEL_PREDECESSOR_CANCELLED");
            }
            if (outbound.delivery && outbound.delivery->expired_unix_ms) {
                return block("PUBLICATION_CHANNEL_PREDECESSOR_EXPIRED");
            }
            return false;
        }
        corrects = previous.operation_id;
        if (previous.result_digest == projection_result_digest(projection)) {
            return false;
        }
    }
    if (channel.publications.size() >= channel.maximum_publications) {
        return block("PUBLICATION_CHANNEL_BUDGET_EXHAUSTED");
    }
    if (!policy || !policy->peer_generation || !policy->peer_spki_sha256) {
        return false;
    }

    const auto sequence = static_cast<std::uint64_t>(
        channel.publications.size()) + 1U;
    const auto epoch = publication_channel_epoch(channel);
    const auto result_digest = projection_result_digest(projection);
    const auto authority = channel_authority_digest(
        channel, projection, context, *policy, sequence, epoch, corrects,
        std::nullopt, {});
    const auto payload = channel_payload(
        channel, projection, context, *policy, sequence, epoch, corrects,
        std::nullopt, {}, authority);
    const auto operation = channel_operation(payload);
    EvidenceRecord record{
        .operation_id = operation,
        .issuer = node_id_,
        .recipient = channel.recipient,
        .scope = channel.scope,
        .corrects = corrects,
        .payload = payload,
    };
    validate_evidence_record(record);
    try {
        validate_new_outbound_locked(record, *policy);
    } catch (const AppError& error) {
        if (error.code() == "OUTBOX_GLOBAL_RECORD_LIMIT" ||
            error.code() == "OUTBOX_GLOBAL_PAYLOAD_LIMIT" ||
            error.code() == "OUTBOX_PEER_RECORD_LIMIT" ||
            error.code() == "OUTBOX_PEER_PAYLOAD_LIMIT" ||
            error.code() == "STATE_CAPACITY_EXCEEDED") {
            return false;
        }
        throw;
    }

    auto next = channel;
    ++next.revision;
    ++next.automatic_schedule_revision;
    next.transition = "AUTO_PUBLISH";
    next.configuration_event = configuration_event;
    next.unix_ms = now_ms();
    next.actor_uid = executor_uid;
    next.pid = executor_pid;
    next.publications.push_back(PublicationChannelRevision{
        .sequence = sequence,
        .epoch = epoch,
        .projection_revision = projection.revision,
        .processed_position = projection.position,
        .result_digest = result_digest,
        .source_commitment = projection.projection->totals.source_digest,
        .operation_id = operation,
        .record_digest = evidence_record_digest(record),
        .corrects = corrects,
        .recipient_generation = *policy->peer_generation,
        .recipient_spki_sha256 = *policy->peer_spki_sha256,
        .authority_digest = authority,
        .prior_epoch_terminal_operation = std::nullopt,
        .prior_epoch_terminal_outcome = {},
        .epoch_reason = {},
        .epoch_actor_uid = 0U,
        .automatic = true,
        .automatic_grant_generation = grant.generation,
        .configuration_event = configuration_event,
        .unix_ms = next.unix_ms,
        .pid = executor_pid,
    });
    auto& next_grant = next.automatic_grants.back();
    ++next_grant.publications;
    if (next_grant.publications == next_grant.maximum_publications) {
        finish_automatic_grant(next_grant, next, "EXHAUSTED",
            "PUBLICATION_AUTOMATIC_BUDGET_EXHAUSTED");
    }
    const auto transaction = encode_transaction(
        next, outbound_composite(record, *policy), std::nullopt);
    pause_test("NATRAV_OVERLAY_TEST_AUTOMATIC_PUBLICATION_BEFORE_COMMIT_MS");
    append_entry(EntryKind::publication_channel, transaction);
    pause_test("NATRAV_OVERLAY_TEST_AUTOMATIC_PUBLICATION_AFTER_COMMIT_MS");
    return true;
}

std::string NodeState::publication_channel_command(
    const PublicationChannelRequest& request,
    const EvidenceQueryContext& context,
    const std::uint32_t pid,
    const std::uint64_t configuration_event,
    const std::optional<OutboundPolicy>& policy) {
    validate_publication_channel_request(request);
    std::unique_lock<std::mutex> lock(mutex_);
    if (poisoned_) { app_fail("STATE_UNAVAILABLE", "state writer requires restart"); }
    if (std::chrono::steady_clock::now() >= context.deadline) {
        app_fail("PUBLICATION_CHANNEL_DEADLINE", "channel request exceeded its deadline");
    }
    if (configuration_event == 0U ||
        configuration_event != active_configuration_event(configuration_events_)) {
        app_fail("PUBLICATION_CHANNEL_CONFIGURATION_MISMATCH",
                 "channel request requires one accepted active configuration");
    }
    const auto config = parse_runtime_config(
        configuration_events_.at(configuration_event - 1U).canonical,
        "/publication-channel-authority", IdentityFileValidation::deferred);
    if (config.format_version < 12U ||
        !local_control_allows(config.local_control, context.uid,
                              LocalControlClass::projection) ||
        !local_control_allows(config.local_control, context.uid,
                              LocalControlClass::consumer)) {
        app_fail("LOCAL_CONTROL_CLASS_DENIED",
                 "publication channels require explicit V12 PROJECTION and CONSUMER authority");
    }
    const auto key = publication_channel_key(context.uid, request.name);
    auto found = publication_channels_.find(key);
    const auto require_submit = [&]() {
        if (!local_control_allows(config.local_control, context.uid,
                                  LocalControlClass::submit)) {
            app_fail("LOCAL_CONTROL_CLASS_DENIED",
                     "publication channel mutation requires explicit SUBMIT authority");
        }
    };
    if (request.command == PublicationChannelCommand::create) {
        require_submit();
        if (!policy || !policy->peer_generation || !policy->peer_spki_sha256) {
            app_fail("PUBLICATION_CHANNEL_POLICY_INVALID", "configured recipient route is required");
        }
        const auto projection = consumers_.find(
            consumer_key(context.uid, request.projection_name));
        if (projection == consumers_.end() || !projection->second.projection) {
            app_fail("PROJECTION_NOT_FOUND", "channel projection does not exist");
        }
        const auto& value = projection->second;
        require_projection_access(value, context);
        if (value.instance != *request.projection_instance) {
            app_fail("PUBLICATION_CHANNEL_PROJECTION_CONFLICT",
                     "channel must bind the exact projection instance");
        }
        if (found != publication_channels_.end()) {
            const auto& existing = found->second;
            if (existing.retirement) {
                app_fail("PUBLICATION_CHANNEL_RETIRED",
                         "retired channel names are permanently reserved");
            }
            if (existing.projection_name == request.projection_name &&
                existing.projection_instance == *request.projection_instance &&
                existing.recipient == request.recipient &&
                existing.scope == request.scope &&
                existing.maximum_publications == request.maximum_publications &&
                existing.creation_reason == request.reason) {
                return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_CHANNEL_V1\",\"ok\":true,\"disposition\":\"ALREADY_EXISTS\",\"channel\":") +
                    publication_channel_json(existing, true,
                        latest_status(existing, outbound_index_, outbound_)) + "}";
            }
            app_fail("PUBLICATION_CHANNEL_NAME_CONFLICT",
                     "channel name is already bound to another definition");
        }
        const auto active = std::count_if(publication_channels_.begin(),
            publication_channels_.end(), [](const auto& item) {
                return !item.second.retirement;
            });
        const auto owner = std::count_if(publication_channels_.begin(),
            publication_channels_.end(), [&](const auto& item) {
                return !item.second.retirement && item.second.uid == context.uid;
            });
        if (active >= static_cast<std::ptrdiff_t>(kPublicationChannelLimit) ||
            owner >= static_cast<std::ptrdiff_t>(kPublicationChannelUidLimit)) {
            app_fail("PUBLICATION_CHANNEL_LIMIT", "active channel capacity exhausted");
        }
        PublicationChannel next{
            .name = request.name,
            .uid = context.uid,
            .instance = random_digest(),
            .projection_name = request.projection_name,
            .projection_instance = value.instance,
            .projection_definition_digest = value.projection->definition_digest,
            .recipient = request.recipient,
            .scope = request.scope,
            .key_policy = PublicationChannelKeyPolicy::active_at_publish,
            .maximum_publications = request.maximum_publications,
            .creation_reason = request.reason,
            .created_configuration_event = configuration_event,
            .created_unix_ms = now_ms(),
            .created_pid = pid,
            .revision = 1U,
            .publications = {},
            .automatic_schedule_revision = 0U,
            .automatic_grants = {},
            .retirement = std::nullopt,
            .transition = "CREATE",
            .configuration_event = configuration_event,
            .unix_ms = 0U,
            .actor_uid = context.uid,
            .pid = pid,
        };
        next.unix_ms = next.created_unix_ms;
        const auto transaction = encode_transaction(next, std::nullopt, std::nullopt);
        append_entry(EntryKind::publication_channel, transaction);
        return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_CHANNEL_V1\",\"ok\":true,\"disposition\":\"CREATED\",\"reason\":") +
            json_string(request.reason) + ",\"channel\":" +
            publication_channel_json(publication_channels_.at(key), true, "NONE") + "}";
    }
    if (found == publication_channels_.end()) {
        app_fail("PUBLICATION_CHANNEL_NOT_FOUND", "no channel with this name is owned by the connected UID");
    }
    auto& channel = found->second;
    const auto automatic_observation = [&]() -> std::string {
        if (channel.retirement) { return "RETIRED"; }
        if (channel.automatic_grants.empty()) { return "DISABLED"; }
        const auto& grant = channel.automatic_grants.back();
        if (grant.state != "ENABLED") { return grant.state; }
        const auto projection = consumers_.find(
            consumer_key(channel.uid, channel.projection_name));
        if (projection == consumers_.end() || !projection->second.projection) {
            return "PROJECTION_NOT_FOUND";
        }
        if (projection->second.instance != channel.projection_instance ||
            projection->second.projection->definition_digest !=
                channel.projection_definition_digest) {
            return "PUBLICATION_CHANNEL_PROJECTION_CONFLICT";
        }
        if (!local_control_allows(config.local_control, channel.uid,
                                  LocalControlClass::projection) ||
            !local_control_allows(config.local_control, channel.uid,
                                  LocalControlClass::consumer) ||
            !local_control_allows(config.local_control, channel.uid,
                                  LocalControlClass::submit)) {
            return "LOCAL_CONTROL_CLASS_DENIED";
        }
        try {
            require_projection_access(projection->second, context);
        } catch (const AppError& error) {
            return error.code();
        }
        if (grant.authority_digest != context.read_access.digest ||
            projection->second.adoptions.empty() ||
            projection->second.adoptions.back().authority !=
                context.read_access.digest) {
            return "PUBLICATION_AUTOMATIC_AUTHORITY_CHANGED";
        }
        if (!channel.publications.empty()) {
            const auto& head = channel.publications.back();
            const auto outbound_found = outbound_index_.find(
                datacube::hex_lower(head.operation_id));
            if (outbound_found == outbound_index_.end()) {
                return "PUBLICATION_CHANNEL_HEAD_MISSING";
            }
            const auto& outbound = outbound_[outbound_found->second];
            if (!outbound.receipt) {
                if (active_outbound_rejection(outbound)) {
                    return "PREDECESSOR_REJECTED";
                }
                if (outbound.delivery && outbound.delivery->cancelled_unix_ms) {
                    return "PREDECESSOR_CANCELLED";
                }
                if (outbound.delivery && outbound.delivery->expired_unix_ms) {
                    return "PREDECESSOR_EXPIRED";
                }
                return "PREDECESSOR_PENDING";
            }
            if (head.result_digest == projection_result_digest(projection->second)) {
                return "CAUGHT_UP";
            }
        }
        if (channel.publications.size() >= channel.maximum_publications) {
            return "PUBLICATION_CHANNEL_BUDGET_EXHAUSTED";
        }
        if (!policy || !policy->peer_generation || !policy->peer_spki_sha256) {
            return "ROUTE_UNAVAILABLE";
        }
        return "ELIGIBLE";
    };
    if (request.command == PublicationChannelCommand::status) {
        const auto projection = consumers_.find(
            consumer_key(context.uid, channel.projection_name));
        if (projection == consumers_.end() || !projection->second.projection) {
            app_fail("PROJECTION_NOT_FOUND", "channel projection is missing");
        }
        require_projection_access(projection->second, context);
        return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_CHANNEL_V1\",\"ok\":true,\"channel\":") +
            publication_channel_json(channel, true,
                latest_status(channel, outbound_index_, outbound_),
                automatic_observation()) + "}";
    }
    if (request.command == PublicationChannelCommand::automatic_status) {
        return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_CHANNEL_SCHEDULE_V1\",\"ok\":true,\"schedule\":") +
            publication_channel_schedule_json(channel, automatic_observation()) + "}";
    }
    if (request.command == PublicationChannelCommand::automatic_enable ||
        request.command == PublicationChannelCommand::automatic_pause) {
        require_submit();
        if (channel.instance != *request.channel_instance) {
            app_fail("PUBLICATION_CHANNEL_INSTANCE_CONFLICT",
                     "automatic scheduling selected another channel instance");
        }
        if (channel.retirement) {
            app_fail("PUBLICATION_CHANNEL_RETIRED",
                     "retired channel cannot be scheduled");
        }
        if (request.command == PublicationChannelCommand::automatic_enable &&
            automatic_grant_enabled(channel)) {
            const auto& grant = channel.automatic_grants.back();
            if (request.expected_channel_revision == channel.revision &&
                request.expected_schedule_revision <
                    std::numeric_limits<std::uint64_t>::max() &&
                request.expected_schedule_revision + 1U ==
                    channel.automatic_schedule_revision &&
                request.expected_grant_generation <
                    std::numeric_limits<std::uint64_t>::max() &&
                request.expected_grant_generation + 1U ==
                    channel.automatic_grants.size() &&
                grant.observed_channel_revision == channel.revision &&
                grant.maximum_publications == request.automatic_maximum_publications &&
                grant.minimum_interval_ms == request.automatic_minimum_interval_ms &&
                grant.reason == request.reason) {
                return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_CHANNEL_SCHEDULE_V1\",\"ok\":true,\"disposition\":\"ALREADY_ENABLED\",\"schedule\":") +
                    publication_channel_schedule_json(channel,
                        automatic_observation()) + "}";
            }
            app_fail("PUBLICATION_CHANNEL_SCHEDULE_ALREADY_ENABLED",
                     "pause before granting another finite publication run");
        }
        if (request.command == PublicationChannelCommand::automatic_pause &&
            !automatic_grant_enabled(channel)) {
            return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_CHANNEL_SCHEDULE_V1\",\"ok\":true,\"disposition\":\"ALREADY_STOPPED\",\"schedule\":") +
                publication_channel_schedule_json(channel, automatic_observation()) + "}";
        }
        if (channel.revision != request.expected_channel_revision ||
            channel.automatic_schedule_revision !=
                request.expected_schedule_revision ||
            channel.automatic_grants.size() !=
                request.expected_grant_generation) {
            app_fail("PUBLICATION_CHANNEL_SCHEDULE_CONFLICT",
                     "automatic schedule changed before the requested transition");
        }
        auto next = channel;
        ++next.automatic_schedule_revision;
        next.configuration_event = configuration_event;
        next.unix_ms = now_ms();
        next.actor_uid = context.uid;
        next.pid = pid;
        std::string disposition;
        if (request.command == PublicationChannelCommand::automatic_enable) {
            if (channel.automatic_grants.size() >=
                    kPublicationChannelAutomaticGrantLimit) {
                app_fail("PUBLICATION_CHANNEL_SCHEDULE_HISTORY_LIMIT",
                         "32 finite publication grants are retained");
            }
            if (!policy || !policy->peer_generation ||
                !policy->peer_spki_sha256) {
                app_fail("PUBLICATION_CHANNEL_POLICY_INVALID",
                         "configured recipient route is required to enable publication");
            }
            const auto projection = consumers_.find(
                consumer_key(context.uid, channel.projection_name));
            if (projection == consumers_.end() ||
                !projection->second.projection) {
                app_fail("PROJECTION_NOT_FOUND",
                         "channel projection is missing");
            }
            require_projection_access(projection->second, context);
            if (projection->second.instance != channel.projection_instance ||
                projection->second.projection->definition_digest !=
                    channel.projection_definition_digest) {
                app_fail("PUBLICATION_CHANNEL_PROJECTION_CONFLICT",
                         "channel projection identity changed");
            }
            next.transition = "AUTO_ENABLE";
            next.automatic_grants.push_back(PublicationChannelAutomaticGrant{
                .generation = channel.automatic_grants.size() + 1U,
                .observed_channel_revision = channel.revision,
                .configuration_event = configuration_event,
                .unix_ms = next.unix_ms,
                .pid = pid,
                .maximum_publications =
                    request.automatic_maximum_publications,
                .minimum_interval_ms =
                    request.automatic_minimum_interval_ms,
                .authority_digest = context.read_access.digest,
                .reason = request.reason,
                .start_sequence = channel.publications.size(),
                .publications = 0U,
                .state = "ENABLED",
                .error = {},
                .ended_configuration_event = 0U,
                .ended_unix_ms = 0U,
                .ended_uid = 0U,
                .ended_pid = 0U,
            });
            disposition = "ENABLED";
        } else {
            next.transition = "AUTO_PAUSE";
            finish_automatic_grant(next.automatic_grants.back(), next,
                "PAUSED", request.reason);
            disposition = "PAUSED";
        }
        append_entry(EntryKind::publication_channel,
            encode_transaction(next, std::nullopt, std::nullopt));
        const auto& committed = publication_channels_.at(key);
        return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_CHANNEL_SCHEDULE_V1\",\"ok\":true,\"disposition\":") +
            json_string(disposition) + ",\"schedule\":" +
            publication_channel_schedule_json(committed,
                automatic_observation()) + "}";
    }
    if (request.command == PublicationChannelCommand::new_epoch) {
        require_submit();
        if (channel.retirement) {
            app_fail("PUBLICATION_CHANNEL_RETIRED",
                     "retired channel cannot start another epoch");
        }
        if (channel.instance != *request.channel_instance) {
            app_fail("PUBLICATION_CHANNEL_INSTANCE_CONFLICT",
                     "epoch transition selected another channel instance");
        }
        const auto projection_it = consumers_.find(
            consumer_key(context.uid, channel.projection_name));
        if (projection_it == consumers_.end() || !projection_it->second.projection) {
            app_fail("PROJECTION_NOT_FOUND", "channel projection is missing");
        }
        const auto& projection = projection_it->second;
        require_projection_access(projection, context);
        if (projection.instance != channel.projection_instance ||
            projection.projection->definition_digest !=
                channel.projection_definition_digest) {
            app_fail("PUBLICATION_CHANNEL_PROJECTION_CONFLICT",
                     "channel projection identity changed");
        }
        if (!channel.publications.empty()) {
            const auto& latest = channel.publications.back();
            const bool preceding_revision = request.expected_channel_revision <
                std::numeric_limits<std::uint64_t>::max() &&
                request.expected_channel_revision + 1U == channel.revision;
            if (preceding_revision && latest.epoch == request.expected_epoch + 1U &&
                latest.prior_epoch_terminal_operation == request.terminal_operation &&
                latest.prior_epoch_terminal_outcome == request.terminal_outcome &&
                latest.epoch_reason == request.reason &&
                latest.projection_revision == request.expected_projection_revision &&
                latest.processed_position == request.expected_position &&
                latest.result_digest == *request.expected_result_digest) {
                const auto outbound_found = outbound_index_.find(
                    datacube::hex_lower(latest.operation_id));
                if (outbound_found == outbound_index_.end()) {
                    app_fail("STATE_INVARIANT", "new epoch head is absent");
                }
                return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_CHANNEL_EPOCH_V1\",\"ok\":true,\"disposition\":\"ALREADY_STARTED\",\"operation_id\":") +
                    json_string(datacube::hex_lower(latest.operation_id)) +
                    ",\"status\":" +
                    json_string(outbound_status_name(outbound_[outbound_found->second])) +
                    ",\"channel\":" + publication_channel_json(channel, true,
                        outbound_status_name(outbound_[outbound_found->second])) + "}";
            }
        }
        if (projection.revision != request.expected_projection_revision ||
            projection.position != request.expected_position ||
            projection_result_digest(projection) != *request.expected_result_digest) {
            app_fail("PUBLICATION_CHANNEL_RESULT_CONFLICT",
                     "projection result changed before epoch transition");
        }
        if (channel.revision != request.expected_channel_revision) {
            app_fail("PUBLICATION_CHANNEL_REVISION_CONFLICT",
                     "channel changed before epoch transition");
        }
        if (channel.publications.empty()) {
            app_fail("PUBLICATION_CHANNEL_EPOCH_NO_PREDECESSOR",
                     "the initial epoch has no terminal predecessor");
        }
        const auto& previous = channel.publications.back();
        if (previous.epoch != request.expected_epoch ||
            previous.operation_id != *request.terminal_operation) {
            app_fail("PUBLICATION_CHANNEL_EPOCH_HEAD_CONFLICT",
                     "terminal head or epoch changed before transition");
        }
        const auto outbound_found = outbound_index_.find(
            datacube::hex_lower(previous.operation_id));
        if (outbound_found == outbound_index_.end()) {
            app_fail("STATE_INVARIANT", "terminal channel head is absent");
        }
        const auto observed_outcome = terminal_channel_outcome(
            outbound_[outbound_found->second]);
        if (observed_outcome.empty()) {
            app_fail("PUBLICATION_CHANNEL_EPOCH_HEAD_NOT_TERMINAL",
                     "pending or acknowledged head cannot start another epoch");
        }
        if (observed_outcome != request.terminal_outcome) {
            app_fail("PUBLICATION_CHANNEL_EPOCH_OUTCOME_CONFLICT",
                     "terminal head outcome changed before transition");
        }
        if (channel.publications.size() >= channel.maximum_publications) {
            app_fail("PUBLICATION_CHANNEL_BUDGET_EXHAUSTED",
                     "publication budget exhausted");
        }
        if (request.expected_epoch >= kPublicationChannelMaximumEpochs) {
            app_fail("PUBLICATION_CHANNEL_EPOCH_LIMIT",
                     "publication channel epoch capacity exhausted");
        }
        if (!policy || !policy->peer_generation || !policy->peer_spki_sha256) {
            app_fail("PUBLICATION_CHANNEL_POLICY_INVALID",
                     "active recipient route is required for a new epoch");
        }
        const auto sequence = static_cast<std::uint64_t>(
            channel.publications.size()) + 1U;
        const auto epoch = request.expected_epoch + 1U;
        const auto authority = channel_authority_digest(
            channel, projection, context, *policy, sequence, epoch, std::nullopt,
            request.terminal_operation, request.terminal_outcome);
        const auto payload = channel_payload(
            channel, projection, context, *policy, sequence, epoch, std::nullopt,
            request.terminal_operation, request.terminal_outcome, authority);
        const auto operation = channel_operation(payload);
        EvidenceRecord record{
            .operation_id = operation,
            .issuer = node_id_,
            .recipient = channel.recipient,
            .scope = channel.scope,
            .corrects = std::nullopt,
            .payload = payload,
        };
        validate_evidence_record(record);
        validate_new_outbound_locked(record, *policy);
        auto next = channel;
        ++next.revision;
        next.transition = "NEW_EPOCH";
        next.configuration_event = configuration_event;
        next.unix_ms = now_ms();
        next.actor_uid = context.uid;
        next.pid = pid;
        if (automatic_grant_enabled(channel)) {
            ++next.automatic_schedule_revision;
            finish_automatic_grant(next.automatic_grants.back(), next, "BLOCKED",
                "PUBLICATION_CHANNEL_NEW_EPOCH_REQUIRES_NEW_GRANT");
        }
        next.publications.push_back(PublicationChannelRevision{
            .sequence = sequence,
            .epoch = epoch,
            .projection_revision = projection.revision,
            .processed_position = projection.position,
            .result_digest = *request.expected_result_digest,
            .source_commitment = projection.projection->totals.source_digest,
            .operation_id = operation,
            .record_digest = evidence_record_digest(record),
            .corrects = std::nullopt,
            .recipient_generation = *policy->peer_generation,
            .recipient_spki_sha256 = *policy->peer_spki_sha256,
            .authority_digest = authority,
            .prior_epoch_terminal_operation = request.terminal_operation,
            .prior_epoch_terminal_outcome = request.terminal_outcome,
            .epoch_reason = request.reason,
            .epoch_actor_uid = context.uid,
            .configuration_event = configuration_event,
            .unix_ms = next.unix_ms,
            .pid = pid,
        });
        const auto transaction = encode_transaction(
            next, outbound_composite(record, *policy), std::nullopt);
        pause_test("NATRAV_OVERLAY_TEST_PUBLICATION_EPOCH_BEFORE_COMMIT_MS");
        append_entry(EntryKind::publication_channel, transaction);
        pause_test("NATRAV_OVERLAY_TEST_PUBLICATION_EPOCH_AFTER_COMMIT_MS");
        const auto& committed = publication_channels_.at(key);
        return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_CHANNEL_EPOCH_V1\",\"ok\":true,\"disposition\":\"QUEUED\",\"epoch\":") +
            std::to_string(epoch) + ",\"operation_id\":" +
            json_string(datacube::hex_lower(operation)) +
            ",\"terminal_operation\":" +
            json_string(datacube::hex_lower(*request.terminal_operation)) +
            ",\"terminal_outcome\":" + json_string(request.terminal_outcome) +
            ",\"corrects\":null,\"payload_format\":\"NPC2\",\"channel\":" +
            publication_channel_json(committed, true, "PENDING") + "}";
    }
    if (request.command == PublicationChannelCommand::retire) {
        require_submit();
        if (channel.instance != *request.channel_instance) {
            app_fail("PUBLICATION_CHANNEL_INSTANCE_CONFLICT", "retirement selected another channel instance");
        }
        if (channel.retirement) {
            if (request.expected_channel_revision <
                    std::numeric_limits<std::uint64_t>::max() &&
                request.expected_channel_revision + 1U == channel.revision &&
                channel.retirement->reason == request.reason &&
                channel.retirement->cancelled_pending == request.cancel_pending) {
                return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_CHANNEL_V1\",\"ok\":true,\"disposition\":\"ALREADY_RETIRED\",\"channel\":") +
                    publication_channel_json(channel, true,
                        latest_status(channel, outbound_index_, outbound_)) + "}";
            }
            app_fail("PUBLICATION_CHANNEL_RETIRED", "channel is already retired");
        }
        if (channel.revision != request.expected_channel_revision) {
            app_fail("PUBLICATION_CHANNEL_REVISION_CONFLICT", "channel changed before retirement");
        }
        const auto retired = std::count_if(publication_channels_.begin(),
            publication_channels_.end(), [](const auto& item) {
                return item.second.retirement.has_value();
            });
        const auto owner_retired = std::count_if(publication_channels_.begin(),
            publication_channels_.end(), [&](const auto& item) {
                return item.second.retirement && item.second.uid == context.uid;
            });
        if (retired >= static_cast<std::ptrdiff_t>(kRetiredPublicationChannelLimit) ||
            owner_retired >= static_cast<std::ptrdiff_t>(kRetiredPublicationChannelUidLimit)) {
            app_fail("PUBLICATION_CHANNEL_RETIREMENT_LIMIT", "retired channel capacity exhausted");
        }
        std::optional<datacube::Octets> cancellation;
        std::optional<datacube::Digest32> cancelled;
        if (!channel.publications.empty()) {
            const auto operation = channel.publications.back().operation_id;
            const auto outbound_found = outbound_index_.find(datacube::hex_lower(operation));
            if (outbound_found == outbound_index_.end()) {
                app_fail("STATE_INVARIANT", "channel head is absent from the outbox");
            }
            const auto& current = outbound_[outbound_found->second];
            if (outbound_is_pending(current)) {
                if (!request.cancel_pending) {
                    app_fail("PUBLICATION_CHANNEL_PENDING",
                             "retirement requires an explicit pending cancellation");
                }
                if (!current.delivery) {
                    app_fail("OUTBOUND_POLICY_MISSING", "channel head lacks delivery policy");
                }
                cancellation = cancellation_payload(operation, now_ms(),
                    request.reason, current.delivery->policy);
                cancelled = operation;
            } else if (request.cancel_pending) {
                app_fail("PUBLICATION_CHANNEL_NO_PENDING",
                         "there is no pending publication to cancel");
            }
        } else if (request.cancel_pending) {
            app_fail("PUBLICATION_CHANNEL_NO_PENDING",
                     "there is no publication to cancel");
        }
        auto next = channel;
        ++next.revision;
        next.transition = "RETIRE";
        next.configuration_event = configuration_event;
        next.unix_ms = now_ms();
        next.actor_uid = context.uid;
        next.pid = pid;
        if (automatic_grant_enabled(channel)) {
            ++next.automatic_schedule_revision;
            finish_automatic_grant(next.automatic_grants.back(), next,
                "BLOCKED", "PUBLICATION_CHANNEL_RETIRED");
        }
        next.retirement = PublicationChannelRetirement{
            .revision = next.revision,
            .configuration_event = configuration_event,
            .unix_ms = next.unix_ms,
            .pid = pid,
            .cancelled_pending = cancelled.has_value(),
            .cancelled_operation = cancelled,
            .reason = request.reason,
        };
        const auto transaction = encode_transaction(next, std::nullopt, cancellation);
        append_entry(EntryKind::publication_channel, transaction);
        return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_CHANNEL_V1\",\"ok\":true,\"disposition\":\"RETIRED\",\"channel\":") +
            publication_channel_json(publication_channels_.at(key), true,
                latest_status(publication_channels_.at(key), outbound_index_, outbound_)) + "}";
    }
    require_submit();
    if (!policy || !policy->peer_generation || !policy->peer_spki_sha256) {
        app_fail("PUBLICATION_CHANNEL_POLICY_INVALID", "active recipient route is required");
    }
    if (channel.retirement) {
        app_fail("PUBLICATION_CHANNEL_RETIRED", "retired channel cannot publish");
    }
    if (channel.instance != *request.channel_instance) {
        app_fail("PUBLICATION_CHANNEL_INSTANCE_CONFLICT", "publication selected another channel instance");
    }
    const auto projection_it = consumers_.find(
        consumer_key(context.uid, channel.projection_name));
    if (projection_it == consumers_.end() || !projection_it->second.projection) {
        app_fail("PROJECTION_NOT_FOUND", "channel projection is missing");
    }
    const auto& projection = projection_it->second;
    require_projection_access(projection, context);
    if (projection.instance != channel.projection_instance ||
        projection.projection->definition_digest != channel.projection_definition_digest) {
        app_fail("PUBLICATION_CHANNEL_PROJECTION_CONFLICT",
                 "channel projection identity changed");
    }
    if (!channel.publications.empty()) {
        const auto& latest = channel.publications.back();
        const bool preceding_revision = request.expected_channel_revision <
            std::numeric_limits<std::uint64_t>::max() &&
            request.expected_channel_revision + 1U == channel.revision;
        if (latest.projection_revision == request.expected_projection_revision &&
            latest.processed_position == request.expected_position &&
            latest.result_digest == *request.expected_result_digest &&
            (request.expected_channel_revision == channel.revision ||
             preceding_revision)) {
            const auto outbound_found = outbound_index_.find(
                datacube::hex_lower(latest.operation_id));
            if (outbound_found == outbound_index_.end()) {
                app_fail("STATE_INVARIANT", "published channel head is absent");
            }
            return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_CHANNEL_PUBLICATION_V1\",\"ok\":true,\"disposition\":\"ALREADY_PUBLISHED\",\"operation_id\":") +
                json_string(datacube::hex_lower(latest.operation_id)) +
                ",\"status\":" + json_string(outbound_status_name(outbound_[outbound_found->second])) +
                ",\"channel\":" + publication_channel_json(channel, true,
                    outbound_status_name(outbound_[outbound_found->second])) + "}";
        }
    }
    if (projection.revision != request.expected_projection_revision ||
        projection.position != request.expected_position ||
        projection_result_digest(projection) != *request.expected_result_digest) {
        app_fail("PUBLICATION_CHANNEL_RESULT_CONFLICT",
                 "projection result changed before channel publication");
    }
    if (channel.revision != request.expected_channel_revision) {
        app_fail("PUBLICATION_CHANNEL_REVISION_CONFLICT", "channel changed before publication");
    }
    if (channel.publications.size() >= channel.maximum_publications) {
        app_fail("PUBLICATION_CHANNEL_BUDGET_EXHAUSTED", "publication budget exhausted");
    }
    std::optional<datacube::Digest32> corrects;
    if (!channel.publications.empty()) {
        const auto& previous = channel.publications.back();
        const auto outbound_found = outbound_index_.find(datacube::hex_lower(previous.operation_id));
        if (outbound_found == outbound_index_.end()) {
            app_fail("STATE_INVARIANT", "channel predecessor is absent");
        }
        const auto& outbound = outbound_[outbound_found->second];
        if (!outbound.receipt) {
            if (active_outbound_rejection(outbound)) {
                app_fail("PUBLICATION_CHANNEL_PREDECESSOR_REJECTED",
                         "retry or retire the rejected predecessor before advancing");
            }
            if (outbound.delivery && outbound.delivery->cancelled_unix_ms) {
                app_fail("PUBLICATION_CHANNEL_PREDECESSOR_CANCELLED",
                         "cancelled predecessor cannot be corrected");
            }
            if (outbound.delivery && outbound.delivery->expired_unix_ms) {
                app_fail("PUBLICATION_CHANNEL_PREDECESSOR_EXPIRED",
                         "expired predecessor cannot be corrected");
            }
            app_fail("PUBLICATION_CHANNEL_PREDECESSOR_PENDING",
                     "wait for the durable predecessor receipt before advancing");
        }
        corrects = previous.operation_id;
    }
    const auto sequence = static_cast<std::uint64_t>(channel.publications.size()) + 1U;
    const auto epoch = publication_channel_epoch(channel);
    const auto authority = channel_authority_digest(
        channel, projection, context, *policy, sequence, epoch, corrects,
        std::nullopt, {});
    const auto payload = channel_payload(
        channel, projection, context, *policy, sequence, epoch, corrects,
        std::nullopt, {}, authority);
    const auto operation = channel_operation(payload);
    EvidenceRecord record{
        .operation_id = operation,
        .issuer = node_id_,
        .recipient = channel.recipient,
        .scope = channel.scope,
        .corrects = corrects,
        .payload = payload,
    };
    validate_evidence_record(record);
    validate_new_outbound_locked(record, *policy);
    auto next = channel;
    ++next.revision;
    next.transition = "PUBLISH";
    next.configuration_event = configuration_event;
    next.unix_ms = now_ms();
    next.actor_uid = context.uid;
    next.pid = pid;
    next.publications.push_back(PublicationChannelRevision{
        .sequence = sequence,
        .epoch = epoch,
        .projection_revision = projection.revision,
        .processed_position = projection.position,
        .result_digest = *request.expected_result_digest,
        .source_commitment = projection.projection->totals.source_digest,
        .operation_id = operation,
        .record_digest = evidence_record_digest(record),
        .corrects = corrects,
        .recipient_generation = *policy->peer_generation,
        .recipient_spki_sha256 = *policy->peer_spki_sha256,
        .authority_digest = authority,
        .prior_epoch_terminal_operation = std::nullopt,
        .prior_epoch_terminal_outcome = {},
        .epoch_reason = {},
        .epoch_actor_uid = 0U,
        .configuration_event = configuration_event,
        .unix_ms = next.unix_ms,
        .pid = pid,
    });
    const auto transaction = encode_transaction(
        next, outbound_composite(record, *policy), std::nullopt);
    pause_test("NATRAV_OVERLAY_TEST_PUBLICATION_CHANNEL_BEFORE_COMMIT_MS");
    append_entry(EntryKind::publication_channel, transaction);
    pause_test("NATRAV_OVERLAY_TEST_PUBLICATION_CHANNEL_AFTER_COMMIT_MS");
    const auto& committed = publication_channels_.at(key);
    return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_CHANNEL_PUBLICATION_V1\",\"ok\":true,\"disposition\":\"QUEUED\",\"operation_id\":") +
        json_string(datacube::hex_lower(operation)) +
        ",\"record_digest\":" + json_string(datacube::hex_lower(evidence_record_digest(record))) +
        ",\"payload_format\":" + json_string(epoch == 1U ? "NPC1" : "NPC2") +
        ",\"result_digest\":" +
        json_string(datacube::hex_lower(*request.expected_result_digest)) +
        ",\"corrects\":" + (corrects ? json_string(datacube::hex_lower(*corrects)) : "null") +
        ",\"channel\":" + publication_channel_json(committed, true, "PENDING") + "}";
}

}  // namespace natrav_overlay
