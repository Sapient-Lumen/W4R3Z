#include "delivery_index.hpp"

#include <algorithm>
#include <limits>
#include <stdexcept>

namespace natrav_overlay {
struct DeadlineIndex::Node final {
    std::size_t key;
    std::uint64_t time;
    std::uint64_t minimum;
    std::size_t count{1U};
    int height{1};
    std::unique_ptr<Node> left, right;
    Node(std::size_t k, std::uint64_t t) : key(k), time(t), minimum(t) {}
    static int h(const std::unique_ptr<Node>& n) { return n ? n->height : 0; }
    static std::size_t size(const std::unique_ptr<Node>& n) { return n ? n->count : 0U; }
    static void refresh(Node& n) {
        n.height = 1 + std::max(h(n.left), h(n.right));
        n.count = 1U + size(n.left) + size(n.right);
        n.minimum = n.time;
        if (n.left) n.minimum = std::min(n.minimum, n.left->minimum);
        if (n.right) n.minimum = std::min(n.minimum, n.right->minimum);
    }
    static void rotate_left(std::unique_ptr<Node>& root) {
        auto next = std::move(root->right);
        root->right = std::move(next->left);
        refresh(*root);
        next->left = std::move(root);
        refresh(*next);
        root = std::move(next);
    }
    static void rotate_right(std::unique_ptr<Node>& root) {
        auto next = std::move(root->left);
        root->left = std::move(next->right);
        refresh(*root);
        next->right = std::move(root);
        refresh(*next);
        root = std::move(next);
    }
    static void balance(std::unique_ptr<Node>& n) {
        if (!n) return;
        refresh(*n);
        const auto diff = h(n->left) - h(n->right);
        if (diff > 1) {
            if (h(n->left->left) < h(n->left->right)) rotate_left(n->left);
            rotate_right(n);
        } else if (diff < -1) {
            if (h(n->right->right) < h(n->right->left)) rotate_right(n->right);
            rotate_left(n);
        }
    }
    static void put(std::unique_ptr<Node>& n, std::size_t k, std::uint64_t t) {
        if (!n) { n = std::make_unique<Node>(k, t); return; }
        if (k < n->key) put(n->left, k, t);
        else if (k > n->key) put(n->right, k, t);
        else n->time = t;
        balance(n);
    }
    static void erase(std::unique_ptr<Node>& n, std::size_t k) {
        if (!n) return;
        if (k < n->key) erase(n->left, k);
        else if (k > n->key) erase(n->right, k);
        else if (!n->left) { auto next = std::move(n->right); n = std::move(next); }
        else if (!n->right) { auto next = std::move(n->left); n = std::move(next); }
        else {
            const Node* next = n->right.get();
            while (next->left) next = next->left.get();
            n->key = next->key; n->time = next->time;
            erase(n->right, n->key);
        }
        balance(n);
    }
    static bool valid(const std::unique_ptr<Node>& n,
        std::optional<std::size_t> low, std::optional<std::size_t> high) {
        if (!n) return true;
        if ((low && n->key <= *low) || (high && n->key >= *high)) return false;
        const auto diff = h(n->left) - h(n->right);
        auto minimum = n->time;
        if (n->left) minimum = std::min(minimum, n->left->minimum);
        if (n->right) minimum = std::min(minimum, n->right->minimum);
        return diff >= -1 && diff <= 1 && n->height == 1 + std::max(h(n->left), h(n->right)) &&
            n->count == 1U + size(n->left) + size(n->right) && n->minimum == minimum &&
            valid(n->left, low, n->key) && valid(n->right, n->key, high);
    }
};
DeadlineIndex::DeadlineIndex() = default;
DeadlineIndex::~DeadlineIndex() = default;
DeadlineIndex::DeadlineIndex(DeadlineIndex&&) noexcept = default;
DeadlineIndex& DeadlineIndex::operator=(DeadlineIndex&&) noexcept = default;
void DeadlineIndex::put(std::size_t key, std::uint64_t time) { Node::put(root_, key, time); }
void DeadlineIndex::erase(std::size_t key) { Node::erase(root_, key); }
std::optional<std::size_t> DeadlineIndex::first_due(std::uint64_t now, std::uint64_t& visited) const {
    const Node* n = root_.get();
    while (n) {
        ++visited;
        if (n->minimum > now) return std::nullopt;
        if (n->left && n->left->minimum <= now) { n = n->left.get(); continue; }
        if (n->time <= now) return n->key;
        n = n->right.get();
    }
    return std::nullopt;
}
std::optional<std::uint64_t> DeadlineIndex::minimum() const noexcept {
    return root_ ? std::optional(root_->minimum) : std::nullopt;
}
std::size_t DeadlineIndex::size() const noexcept { return Node::size(root_); }
bool DeadlineIndex::valid() const { return Node::valid(root_, std::nullopt, std::nullopt); }

void DeliveryIndex::touch(std::size_t index, std::optional<DeliveryIndexEntry> entry) {
    const auto old = entries_.find(index);
    if (old != entries_.end()) {
        auto& peer = peers_.at(old->second.peer);
        peer.expiry.erase(index); peer.policy_missing.erase(index); peer.exhausted.erase(index);
        const auto ready = peer.readiness.find(old->second.binding);
        if (ready != peer.readiness.end()) {
            ready->second.erase(index);
            if (ready->second.size() == 0U) peer.readiness.erase(ready);
        }
        if (old->second.has_policy) {
            auto it = peer.bindings.find(old->second.binding);
            if (--it->second == 0U) peer.bindings.erase(it);
        }
        --peer.count;
        if (peer.count == 0U) peers_.erase(old->second.peer);
        entries_.erase(old);
    }
    if (!entry) return;
    auto& peer = peers_[entry->peer]; ++peer.count;
    if (!entry->has_policy) peer.policy_missing.insert(index);
    else {
        ++peer.bindings[entry->binding];
        peer.expiry.put(index, entry->expires);
        if (entry->attempts_exhausted) peer.exhausted.insert(index);
        else peer.readiness[entry->binding].put(index, entry->ready);
    }
    entries_.emplace(index, std::move(*entry));
}
DeliveryIndexChoice DeliveryIndex::select(const std::string& id,
    const std::vector<DeliveryBinding>& permitted, std::uint64_t now, bool routed) const {
    DeliveryIndexChoice choice;
    const auto found = peers_.find(id); if (found == peers_.end()) return choice;
    const auto& peer = found->second;
    const auto choose = [&](std::optional<std::size_t> index, DeliveryChoiceKind kind) {
        if (index && (!choice.index || *index < *choice.index)) { choice.index = index; choice.kind = kind; }
    };
    const auto wake = [&](std::optional<std::uint64_t> time) {
        if (time && (!choice.next_wake || *time < *choice.next_wake)) choice.next_wake = time;
    };
    choose(peer.expiry.first_due(now, choice.tree_nodes_visited), DeliveryChoiceKind::expired);
    wake(peer.expiry.minimum());
    if (routed) {
        if (!peer.policy_missing.empty()) choose(*peer.policy_missing.begin(), DeliveryChoiceKind::initialize_policy);
        if (!peer.exhausted.empty()) choose(*peer.exhausted.begin(), DeliveryChoiceKind::attempts_exhausted);
    }
    // At most one maintenance candidate is returned in a turn, even when a
    // route was removed. No linear expiry sweep can monopolize state ownership.
    if (choice.index || !routed) return choice;
    for (const auto& binding : permitted) {
        ++choice.key_buckets_checked;
        const auto ready = peer.readiness.find(binding);
        if (ready == peer.readiness.end()) continue;
        choose(ready->second.first_due(now, choice.tree_nodes_visited), DeliveryChoiceKind::ready);
        wake(ready->second.minimum());
    }
    return choice;
}
std::size_t DeliveryIndex::pending(const std::string& peer) const {
    const auto found = peers_.find(peer); return found == peers_.end() ? 0U : found->second.count;
}
std::size_t DeliveryIndex::pending() const noexcept { return entries_.size(); }
std::size_t DeliveryIndex::bound_pending(const std::string& id, const DeliveryBinding& binding) const {
    const auto peer = peers_.find(id); if (peer == peers_.end()) return 0U;
    const auto found = peer->second.bindings.find(binding);
    return found == peer->second.bindings.end() ? 0U : found->second;
}
bool DeliveryIndex::valid() const {
    std::size_t total = 0U;
    for (const auto& [id, peer] : peers_) {
        static_cast<void>(id); total += peer.count;
        if (!peer.expiry.valid() || peer.expiry.size() + peer.policy_missing.size() != peer.count) return false;
        std::size_t ready_count = 0U;
        for (const auto& [binding, ready] : peer.readiness) { static_cast<void>(binding); if (!ready.valid()) return false; ready_count += ready.size(); }
        if (ready_count + peer.exhausted.size() != peer.expiry.size()) return false;
        std::map<DeliveryBinding, std::size_t> reference;
        for (const auto& [index, entry] : entries_) {
            static_cast<void>(index);
            if (entry.peer == id && entry.has_policy) ++reference[entry.binding];
        }
        if (peer.bindings != reference) return false;
    }
    return total == entries_.size();
}
} // namespace natrav_overlay
