#pragma once
#include "common.hpp"
#include "numeric.hpp"
#include <optional>
#include <vector>
namespace natrav_overlay {
struct ProjectionTotals final {
    std::uint64_t admissions{0U}, originals{0U}, corrections{0U};
    std::uint64_t historical_payload_bytes{0U}, current_payload_bytes{0U};
    datacube::Digest32 source_digest{};
    NumericTotals numeric;
    bool operator==(const ProjectionTotals&) const = default;
};
struct EvidenceProjection final {
    std::uint64_t maximum_admissions{100000U};
    std::optional<NumericDefinition> numeric;
    datacube::Digest32 definition_digest{};
    ProjectionTotals totals;
    // One bounded account per prior consumer epoch; no arbitrary result or payload storage.
    std::vector<ProjectionTotals> retired_results;
    std::vector<datacube::Digest32> last_sources;
    std::vector<NumericOutcome> last_outcomes;
    bool operator==(const EvidenceProjection&) const = default;
};
[[nodiscard]] datacube::Octets encode_projection(const EvidenceProjection& value);
[[nodiscard]] EvidenceProjection decode_projection(datacube::OctetView bytes);
[[nodiscard]] std::string projection_json(const EvidenceProjection& value, bool history);
} // namespace natrav_overlay
