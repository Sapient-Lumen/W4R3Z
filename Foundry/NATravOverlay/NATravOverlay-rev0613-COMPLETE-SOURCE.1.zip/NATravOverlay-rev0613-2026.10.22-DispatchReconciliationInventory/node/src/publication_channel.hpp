#pragma once

#include "evidence_query.hpp"
#include "protocol.hpp"

#include <cstdint>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

enum class PublicationChannelCommand : std::uint8_t {
    create = 1U,
    publish = 2U,
    status = 3U,
    retire = 4U,
    automatic_enable = 5U,
    automatic_pause = 6U,
    automatic_status = 7U,
    new_epoch = 8U,
};

enum class PublicationChannelKeyPolicy : std::uint8_t {
    active_at_publish = 1U,
};

struct PublicationChannelRequest final {
    PublicationChannelCommand command{PublicationChannelCommand::status};
    std::string name;
    std::string projection_name;
    std::optional<datacube::Digest32> projection_instance;
    std::optional<datacube::Digest32> channel_instance;
    std::uint64_t expected_channel_revision{0U};
    std::uint64_t expected_projection_revision{0U};
    std::uint64_t expected_position{0U};
    std::optional<datacube::Digest32> expected_result_digest;
    std::string recipient;
    std::string scope;
    std::uint32_t maximum_publications{128U};
    bool cancel_pending{false};
    std::uint64_t expected_schedule_revision{0U};
    std::uint64_t expected_grant_generation{0U};
    std::uint32_t automatic_maximum_publications{100U};
    std::uint32_t automatic_minimum_interval_ms{100U};
    std::uint64_t expected_epoch{0U};
    std::optional<datacube::Digest32> terminal_operation;
    std::string terminal_outcome;
    std::string reason;
};

struct PublicationChannelRevision final {
    std::uint64_t sequence{0U};
    std::uint64_t epoch{1U};
    std::uint64_t projection_revision{0U};
    std::uint64_t processed_position{0U};
    datacube::Digest32 result_digest{};
    datacube::Digest32 source_commitment{};
    datacube::Digest32 operation_id{};
    datacube::Digest32 record_digest{};
    std::optional<datacube::Digest32> corrects;
    std::string recipient_generation;
    datacube::Digest32 recipient_spki_sha256{};
    datacube::Digest32 authority_digest{};
    std::optional<datacube::Digest32> prior_epoch_terminal_operation;
    std::string prior_epoch_terminal_outcome;
    std::string epoch_reason;
    std::uint32_t epoch_actor_uid{0U};
    bool automatic{false};
    std::uint64_t automatic_grant_generation{0U};
    std::uint64_t configuration_event{0U};
    std::uint64_t unix_ms{0U};
    std::uint32_t pid{0U};

    bool operator==(const PublicationChannelRevision&) const = default;
};

struct PublicationChannelAutomaticGrant final {
    std::uint64_t generation{0U};
    std::uint64_t observed_channel_revision{0U};
    std::uint64_t configuration_event{0U};
    std::uint64_t unix_ms{0U};
    std::uint32_t pid{0U};
    std::uint32_t maximum_publications{0U};
    std::uint32_t minimum_interval_ms{0U};
    datacube::Digest32 authority_digest{};
    std::string reason;
    std::uint64_t start_sequence{0U};
    std::uint64_t publications{0U};
    std::string state{"ENABLED"};
    std::string error;
    std::uint64_t ended_configuration_event{0U};
    std::uint64_t ended_unix_ms{0U};
    std::uint32_t ended_uid{0U};
    std::uint32_t ended_pid{0U};

    bool operator==(const PublicationChannelAutomaticGrant&) const = default;
};

struct PublicationChannelRetirement final {
    std::uint64_t revision{0U};
    std::uint64_t configuration_event{0U};
    std::uint64_t unix_ms{0U};
    std::uint32_t pid{0U};
    bool cancelled_pending{false};
    std::optional<datacube::Digest32> cancelled_operation;
    std::string reason;

    bool operator==(const PublicationChannelRetirement&) const = default;
};

struct PublicationChannel final {
    std::string name;
    std::uint32_t uid{0U};
    datacube::Digest32 instance{};
    std::string projection_name;
    datacube::Digest32 projection_instance{};
    datacube::Digest32 projection_definition_digest{};
    std::string recipient;
    std::string scope;
    PublicationChannelKeyPolicy key_policy{PublicationChannelKeyPolicy::active_at_publish};
    std::uint32_t maximum_publications{128U};
    std::string creation_reason;
    std::uint64_t created_configuration_event{0U};
    std::uint64_t created_unix_ms{0U};
    std::uint32_t created_pid{0U};
    std::uint64_t revision{0U};
    std::vector<PublicationChannelRevision> publications;
    std::uint64_t automatic_schedule_revision{0U};
    std::vector<PublicationChannelAutomaticGrant> automatic_grants;
    std::optional<PublicationChannelRetirement> retirement;
    std::string transition;
    std::uint64_t configuration_event{0U};
    std::uint64_t unix_ms{0U};
    std::uint32_t actor_uid{0U};
    std::uint32_t pid{0U};

    bool operator==(const PublicationChannel&) const = default;
};

struct PublicationChannelCandidate final {
    std::string key;
    std::string recipient;
    std::uint64_t generation{0U};
    std::uint32_t minimum_interval_ms{0U};
};

inline constexpr std::size_t kPublicationChannelLimit = 128U;
inline constexpr std::size_t kPublicationChannelUidLimit = 16U;
inline constexpr std::size_t kRetiredPublicationChannelLimit = 256U;
inline constexpr std::size_t kRetiredPublicationChannelUidLimit = 64U;
inline constexpr std::size_t kStoredPublicationChannelLimit =
    kPublicationChannelLimit + kRetiredPublicationChannelLimit;
inline constexpr std::uint32_t kPublicationChannelMaximumRevisions = 128U;
inline constexpr std::uint64_t kPublicationChannelMaximumEpochs = 32U;
inline constexpr std::size_t kPublicationChannelAutomaticGrantLimit = 32U;
inline constexpr std::size_t kPublicationChannelEncodedLimit = 131'072U;

void validate_publication_channel_request(const PublicationChannelRequest& request);
[[nodiscard]] datacube::Octets encode_publication_channel_request(
    const PublicationChannelRequest& request);
[[nodiscard]] PublicationChannelRequest decode_publication_channel_request(
    datacube::OctetView bytes);
[[nodiscard]] datacube::Octets encode_publication_channel(
    const PublicationChannel& value);
[[nodiscard]] PublicationChannel decode_publication_channel(
    datacube::OctetView bytes);
[[nodiscard]] std::string publication_channel_key(
    std::uint32_t uid, std::string_view name);
[[nodiscard]] std::string publication_channel_json(
    const PublicationChannel& value, bool include_history,
    std::string_view latest_outbound_status = {},
    std::string_view automatic_observation = {});

}  // namespace natrav_overlay
