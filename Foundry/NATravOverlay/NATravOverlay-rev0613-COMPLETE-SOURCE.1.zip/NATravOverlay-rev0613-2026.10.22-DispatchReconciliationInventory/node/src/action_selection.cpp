#include "action_selection.hpp"

#include <algorithm>
#include <stdexcept>

namespace natrav_overlay {

void ActionSelectionIndex::touch(
    const std::size_t index,
    std::optional<ActionSelectionIndexEntry> entry) {
    readiness_.erase(index);
    expiry_.erase(index);
    entries_.erase(index);

    ++clock_;
    if (clock_ == 0U) {
        throw std::overflow_error("action selection revision overflow");
    }
    revisions_[index] = clock_;

    if (!entry.has_value()) {
        return;
    }
    readiness_.put(index, entry->not_before_unix_ms);
    expiry_.put(index, entry->expires_unix_ms);
    entries_.emplace(index, *entry);
}

ActionSelectionIndexChoice ActionSelectionIndex::select(
    const std::uint64_t now) const {
    ActionSelectionIndexChoice result;
    const auto expired = expiry_.first_due(now, result.tree_nodes_visited);
    const auto ready = readiness_.first_due(now, result.tree_nodes_visited);

    if (expired.has_value() &&
        (!ready.has_value() || *expired <= *ready)) {
        result.kind = ActionSelectionKind::expired;
        result.index = expired;
    } else if (ready.has_value()) {
        result.kind = ActionSelectionKind::ready;
        result.index = ready;
    }

    const auto expiry_wake = expiry_.minimum();
    const auto readiness_wake = readiness_.minimum();
    if (expiry_wake.has_value() && readiness_wake.has_value()) {
        result.next_wake_unix_ms = std::min(*expiry_wake, *readiness_wake);
    } else if (expiry_wake.has_value()) {
        result.next_wake_unix_ms = expiry_wake;
    } else {
        result.next_wake_unix_ms = readiness_wake;
    }
    return result;
}

std::uint64_t ActionSelectionIndex::revision(const std::size_t index) const {
    const auto found = revisions_.find(index);
    if (found == revisions_.end()) {
        return 0U;
    }
    return found->second;
}

std::size_t ActionSelectionIndex::pending() const noexcept {
    return entries_.size();
}

bool ActionSelectionIndex::valid() const {
    if (!readiness_.valid() || !expiry_.valid() ||
        readiness_.size() != entries_.size() ||
        expiry_.size() != entries_.size()) {
        return false;
    }
    for (const auto& [index, entry] : entries_) {
        const auto revision_found = revisions_.find(index);
        if (revision_found == revisions_.end() || revision_found->second == 0U) {
            return false;
        }
    }
    return true;
}

}  // namespace natrav_overlay
