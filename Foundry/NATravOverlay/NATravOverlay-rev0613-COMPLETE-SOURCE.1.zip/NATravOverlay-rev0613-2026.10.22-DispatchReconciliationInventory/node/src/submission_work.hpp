#pragma once

#include <cstdint>
#include <string>

namespace natrav_overlay {
// Per-calling-thread observations of enqueue and reply construction. No durable
// counters, global snapshots, payload inspection or inter-thread deltas. Other
// threads and work before this scope (decode/authorization/audit) are excluded.
struct SubmissionWork final {
    std::uint64_t digest_payload_bytes{0U};
    std::uint64_t encoded_application_bytes{0U};
    std::uint64_t enqueue_journal_payload_bytes{0U};
    std::uint64_t queue_metadata_records{0U};
    std::uint64_t observation_metadata_records{0U};
    std::uint64_t receipt_text_bytes_copied{0U};
    std::uint64_t observation_text_bytes_copied{0U};
    // Reference full-scan visits remain instrumented; admission now reads totals.
    std::uint64_t capacity_records_visited{0U};
    std::uint64_t capacity_aggregate_reads{0U};
    std::uint64_t capacity_entries_touched{0U};
    std::uint64_t capacity_acquires{0U};
    std::uint64_t capacity_releases{0U};
    std::uint64_t snapshot_calls{0U};
    std::uint64_t snapshot_evidence_payload_bytes{0U};
    std::uint64_t snapshot_logical_bytes{0U};
};
inline thread_local SubmissionWork* active_submission_work = nullptr;

class SubmissionWorkScope final {
public:
    explicit SubmissionWorkScope(SubmissionWork& value) noexcept
        : previous_(active_submission_work) { active_submission_work = &value; }
    ~SubmissionWorkScope() { active_submission_work = previous_; }
    SubmissionWorkScope(const SubmissionWorkScope&) = delete;
    SubmissionWorkScope& operator=(const SubmissionWorkScope&) = delete;
private:
    SubmissionWork* previous_;
};

[[nodiscard]] inline std::string submission_work_json(const SubmissionWork& w) {
    return std::string("{\"scope\":\"ENQUEUE_AND_REPLY_METADATA\"") +
        ",\"digest_payload_bytes\":" + std::to_string(w.digest_payload_bytes) +
        ",\"encoded_application_bytes\":" + std::to_string(w.encoded_application_bytes) +
        ",\"enqueue_journal_payload_bytes\":" + std::to_string(w.enqueue_journal_payload_bytes) +
        ",\"queue_metadata_records\":" + std::to_string(w.queue_metadata_records) +
        ",\"observation_metadata_records\":" + std::to_string(w.observation_metadata_records) +
        ",\"receipt_text_bytes_copied\":" + std::to_string(w.receipt_text_bytes_copied) +
        ",\"observation_text_bytes_copied\":" + std::to_string(w.observation_text_bytes_copied) +
        ",\"capacity_records_visited\":" + std::to_string(w.capacity_records_visited) +
        ",\"capacity_aggregate_reads\":" + std::to_string(w.capacity_aggregate_reads) +
        ",\"capacity_entries_touched\":" + std::to_string(w.capacity_entries_touched) +
        ",\"capacity_acquires\":" + std::to_string(w.capacity_acquires) +
        ",\"capacity_releases\":" + std::to_string(w.capacity_releases) +
        ",\"snapshot_calls\":" + std::to_string(w.snapshot_calls) +
        ",\"snapshot_evidence_payload_bytes\":" + std::to_string(w.snapshot_evidence_payload_bytes) +
        ",\"snapshot_logical_bytes\":" + std::to_string(w.snapshot_logical_bytes) + "}";
}
} // namespace natrav_overlay
