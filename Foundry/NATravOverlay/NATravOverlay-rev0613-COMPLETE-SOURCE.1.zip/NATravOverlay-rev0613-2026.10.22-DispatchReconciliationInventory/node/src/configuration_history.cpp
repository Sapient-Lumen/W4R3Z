#include "configuration_history.hpp"
#include "journal.hpp"
#include <algorithm>
#include <utility>

namespace natrav_overlay {
namespace {
using Digest = datacube::Digest32;
Digest hash(std::string_view domain, datacube::OctetView material) {
    datacube::Octets bytes;
    datacube::append_text(bytes, domain); datacube::append_u8(bytes, 0U);
    datacube::append_octets(bytes, material); return datacube::sha256(bytes);
}
Digest seed(std::string_view node, std::string_view section) {
    datacube::Octets bytes;
    datacube::append_be16(bytes, static_cast<std::uint16_t>(node.size()));
    datacube::append_text(bytes, node);
    datacube::append_u8(bytes, section == "events" ? 1U : 2U);
    return hash("NATRAV_OVERLAY_CONFIGURATION_HISTORY_SEED_V1", bytes);
}
Digest link(const Digest& previous, std::uint64_t ordinal, const Digest& item) {
    datacube::Octets bytes; datacube::append_octets(bytes, previous.octets);
    datacube::append_be64(bytes, ordinal); datacube::append_octets(bytes, item.octets);
    return hash("NATRAV_OVERLAY_CONFIGURATION_HISTORY_LINK_V1", bytes);
}
Digest binding_digest(const RuntimeMutationBinding& b, const Digest& event_prefix) {
    datacube::Octets bytes; datacube::append_octets(bytes, event_prefix.octets);
    datacube::append_be64(bytes, b.configuration_event); datacube::append_u8(bytes, b.journal_kind);
    datacube::append_octets(bytes, b.payload_digest.octets);
    datacube::append_u8(bytes, b.operation_id ? 1U : 0U);
    if (b.operation_id) datacube::append_octets(bytes, b.operation_id->octets);
    return hash("NATRAV_OVERLAY_CONFIGURATION_BINDING_ITEM_V1", bytes);
}
std::string digest_json(const Digest& d) { return json_string(datacube::hex_lower(d)); }
void append_optional(datacube::Octets& bytes, const std::optional<std::uint64_t>& n) {
    datacube::append_u8(bytes, n ? 1U : 0U); if (n) datacube::append_be64(bytes, *n);
}
std::optional<std::uint64_t> read_optional(datacube::Reader& reader) {
    const auto flag = reader.read_u8("history optional flag");
    if (flag > 1U) app_fail("CONFIGURATION_HISTORY_INVALID", "invalid optional flag");
    if (flag) return reader.read_be64("history ordinal");
    return {};
}
} // namespace

void validate_configuration_history(const ConfigurationHistoryRequest& r) {
    if (r.section != "events" && r.section != "bindings")
        app_fail("CONFIGURATION_HISTORY_INVALID", "section must be events or bindings");
    if (r.limit < 1U || r.limit > 64U || r.maximum_bytes < 2048U || r.maximum_bytes > 60000U ||
        r.offset > 1'000'000U || (r.ordinal && (*r.ordinal == 0U || *r.ordinal > 1'000'000U)) ||
        (r.configuration_event && (*r.configuration_event == 0U || *r.configuration_event > 1'000'000U)))
        app_fail("CONFIGURATION_HISTORY_INVALID", "ordinal, offset, row or byte bound is invalid");
    if ((r.configuration_event && r.section != "bindings") || (r.ordinal && r.offset != 0U))
        app_fail("CONFIGURATION_HISTORY_INVALID", "unsupported selector combination");
    if (r.through.has_value() != r.prefix.has_value() || (r.offset != 0U && !r.through))
        app_fail("CONFIGURATION_HISTORY_PREFIX_REQUIRED", "continuation requires both through and prefix digest");
    if ((r.through && *r.through > (r.section == "events" ? 256U : 1'000'000U)) ||
        (r.prefix && digest_is_zero(*r.prefix)))
        app_fail("CONFIGURATION_HISTORY_INVALID", "invalid selected prefix");
}
datacube::Octets encode_configuration_history(const ConfigurationHistoryRequest& r) {
    validate_configuration_history(r);
    datacube::Octets bytes; datacube::append_text(bytes, "NHC1");
    datacube::append_u8(bytes, r.section == "events" ? 1U : 2U);
    append_optional(bytes, r.ordinal); append_optional(bytes, r.configuration_event);
    datacube::append_be64(bytes, r.offset); datacube::append_be32(bytes, r.limit);
    datacube::append_be32(bytes, r.maximum_bytes); append_optional(bytes, r.through);
    if (r.prefix) datacube::append_octets(bytes, r.prefix->octets);
    return bytes;
}
ConfigurationHistoryRequest decode_configuration_history(datacube::OctetView bytes) {
    datacube::Reader rd(bytes, "configuration history request");
    if (datacube::octets_text(rd.read_exact(4U, "magic"), "magic", true) != "NHC1")
        app_fail("CONFIGURATION_HISTORY_INVALID", "wrong request magic");
    const auto section = rd.read_u8("section");
    if (section != 1U && section != 2U) app_fail("CONFIGURATION_HISTORY_INVALID", "invalid section");
    ConfigurationHistoryRequest r; r.section = section == 1U ? "events" : "bindings";
    r.ordinal = read_optional(rd); r.configuration_event = read_optional(rd);
    r.offset = rd.read_be64("offset"); r.limit = rd.read_be32("limit");
    r.maximum_bytes = rd.read_be32("maximum bytes"); r.through = read_optional(rd);
    if (r.through) {
        Digest d{}; const auto raw = rd.read_exact(32U, "prefix");
        std::copy(raw.begin(), raw.end(), d.octets.begin()); r.prefix = d;
    }
    rd.require_eof("configuration history request"); validate_configuration_history(r); return r;
}

// These derivatives are updated ONLY after semantic acceptance, at all four
// append/checkpoint load sites. They never serialize into application state.
void NodeState::index_configuration_event_locked(datacube::OctetView payload) {
    const auto ordinal = configuration_events_.size();
    if (ordinal != configuration_history_index_.size() + 1U)
        app_fail("JOURNAL_CORRUPT", "configuration history derivative mismatch");
    const auto item = hash("NATRAV_OVERLAY_CONFIGURATION_EVENT_ITEM_V1", payload);
    const auto previous = configuration_history_index_.empty() ? seed(node_id_, "events") :
        configuration_history_index_.back().prefix;
    const auto old_active = configuration_history_index_.empty() ? 0U :
        configuration_history_index_.back().active_event;
    configuration_history_index_.push_back(ConfigurationHistoryCommitment{
        .item = item, .prefix = link(previous, static_cast<std::uint64_t>(ordinal), item),
        .active_event = configuration_events_.back().kind == "REJECTED" ? old_active :
            static_cast<std::uint64_t>(ordinal)});
}
void NodeState::index_configuration_binding_locked() {
    const auto ordinal = configuration_bindings_.size();
    if (ordinal != configuration_binding_prefixes_.size() + 1U)
        app_fail("JOURNAL_CORRUPT", "binding history derivative mismatch");
    const auto& b = configuration_bindings_.back();
    const auto item = binding_digest(b, configuration_history_index_.at(
        static_cast<std::size_t>(b.configuration_event - 1U)).prefix);
    const auto previous = configuration_binding_prefixes_.empty() ? seed(node_id_, "bindings") :
        configuration_binding_prefixes_.back();
    configuration_binding_prefixes_.push_back(link(previous, static_cast<std::uint64_t>(ordinal), item));
    index_action_binding_locked(ordinal - 1U);
    if (b.journal_kind == 3U && b.operation_id) {
        // A duplicate identical receipt does not change its first retained time.
        result_receipt_binding_.try_emplace(datacube::hex_lower(*b.operation_id), ordinal);
    }
    if (b.journal_kind == static_cast<std::uint8_t>(EntryKind::inbound_authorized) && b.operation_id) {
        const auto key = datacube::hex_lower(*b.operation_id);
        const auto [position, inserted] = inbound_authorization_configuration_.emplace(key, b.configuration_event);
        if (!inserted && position->second != b.configuration_event)
            app_fail("JOURNAL_CORRUPT", "inbound admission configuration is ambiguous");
    }
}

std::string NodeState::configuration_history_page(const ConfigurationHistoryRequest& r,
    const Digest& authorized_configuration, std::chrono::steady_clock::time_point deadline) const {
    validate_configuration_history(r);
    const auto check_time = [&] {
        if (std::chrono::steady_clock::now() >= deadline)
            app_fail("CONFIGURATION_HISTORY_DEADLINE", "history page construction deadline reached");
    };
    check_time();
    std::lock_guard<std::mutex> lock(mutex_); check_time();
    if (poisoned_) app_fail("STATE_RESTART_REQUIRED", "restart to reconstruct failed writer");
    SubmissionWork work; SubmissionWorkScope scope(work);
    const bool events = r.section == "events";
    const auto available = events ? configuration_events_.size() : configuration_bindings_.size();
    const auto through = r.through.value_or(static_cast<std::uint64_t>(available));
    if (through > available)
        app_fail("CONFIGURATION_HISTORY_PREFIX_UNAVAILABLE", "selected retained prefix is not present");
    const auto end = static_cast<std::size_t>(through);
    const auto prefix = end == 0U ? seed(node_id_, r.section) : events ?
        configuration_history_index_.at(end - 1U).prefix : configuration_binding_prefixes_.at(end - 1U);
    if (r.prefix && *r.prefix != prefix)
        app_fail("CONFIGURATION_HISTORY_PREFIX_MISMATCH", "selected immutable history differs");

    std::size_t first = 0U, last = end, comparisons = 0U, visited = 0U;
    if (r.ordinal) {
        if (*r.ordinal <= through) { first = static_cast<std::size_t>(*r.ordinal - 1U); last = first + 1U; }
        else { first = last = end; }
    }
    if (r.configuration_event) {
        // Bindings are semantically validated in monotonically increasing
        // accepted-event order; even a large filtered history needs only seeks.
        const auto begin_it = configuration_bindings_.begin() + static_cast<std::ptrdiff_t>(first);
        const auto end_it = configuration_bindings_.begin() + static_cast<std::ptrdiff_t>(last);
        const auto lo = std::lower_bound(begin_it, end_it, *r.configuration_event,
            [&](const RuntimeMutationBinding& b, std::uint64_t event) { ++comparisons; return b.configuration_event < event; });
        const auto hi = std::upper_bound(lo, end_it, *r.configuration_event,
            [&](std::uint64_t event, const RuntimeMutationBinding& b) { ++comparisons; return event < b.configuration_event; });
        first = static_cast<std::size_t>(lo - configuration_bindings_.begin());
        last = static_cast<std::size_t>(hi - configuration_bindings_.begin());
    }
    const auto selected = last - first;
    if (r.offset > selected)
        app_fail("CONFIGURATION_HISTORY_OFFSET_INVALID", "offset exceeds exact selected total");
    const auto start = first + static_cast<std::size_t>(r.offset);
    const auto number = std::min<std::size_t>(r.limit, last - start);
    const auto active = configuration_history_index_.empty() ? 0U : configuration_history_index_.back().active_event;
    const auto prefix_active = events ? (end == 0U ? 0U : configuration_history_index_[end - 1U].active_event) : 0U;
    const auto header = std::string("{\"format\":\"NATRAV_OVERLAY_CONFIGURATION_HISTORY_V1\",\"node\":") + json_string(node_id_) +
        ",\"section\":" + json_string(r.section) + ",\"authorized_configuration_digest\":" + digest_json(authorized_configuration) +
        ",\"retained_count_observed\":" + std::to_string(available) +
        ",\"active_event_observed\":" + std::to_string(active) +
        ",\"prefix_active_event\":" + (events ? std::to_string(prefix_active) : "null") +
        ",\"through\":" + std::to_string(through) + ",\"prefix_digest\":" + digest_json(prefix) +
        ",\"selected_total\":" + std::to_string(selected) + ",\"offset\":" + std::to_string(r.offset) +
        ",\"bindings_coverage\":\"RUNTIME_BOUND_MUTATIONS_ONLY_NOT_ALL_JOURNAL_EVENTS\"" +
        ",\"observation\":\"ONE_STATE_MUTEX_OBSERVATION\"" +
        ",\"redaction\":\"CANONICAL_CONTENTS_REASON_TEXT_AND_RELOCATION_PATHS_OMITTED\",\"rows\":[";
    const auto finish = [&](std::size_t returned) {
        const auto next = r.offset + returned;
        return std::string("],\"returned\":") + std::to_string(returned) +
            ",\"next_offset\":" + std::to_string(next) + ",\"more\":" + (next < selected ? "true" : "false") +
            ",\"work\":{\"scope\":\"LOCKED_HISTORY_PAGE\",\"rows_visited\":" + std::to_string(visited) +
            ",\"filter_comparisons\":" + std::to_string(comparisons) +
            ",\"prefix_reads\":1,\"historical_configurations_parsed\":0,\"canonical_bytes_read\":0,\"payload_bytes_read\":0," +
            "\"state_snapshots\":" + std::to_string(work.snapshot_calls) +
            ",\"snapshot_logical_bytes\":" + std::to_string(work.snapshot_logical_bytes) + "}}";
    };
    std::string rows; std::size_t returned = 0U;
    for (std::size_t index = start; index < start + number; ++index) {
        check_time(); ++visited;
        std::string row = "{\"ordinal\":" + std::to_string(index + 1U);
        if (events) {
            const auto& e = configuration_events_[index]; const auto& c = configuration_history_index_[index];
            const auto reason_digest = hash("NATRAV_OVERLAY_CONFIGURATION_REASON_V1", datacube::OctetView(reinterpret_cast<const std::uint8_t*>(e.reason.data()), e.reason.size()));
            const auto previous_active = index == 0U ? 0U : configuration_history_index_[index - 1U].active_event;
            row += ",\"kind\":" + json_string(e.kind) + ",\"accepted\":" + (e.kind != "REJECTED" ? "true" : "false") +
                ",\"generation\":" + json_string(e.generation) + ",\"configuration_digest\":" + digest_json(e.digest) +
                ",\"canonical_bytes\":" + std::to_string(e.canonical.size()) + ",\"canonical_contents\":null" +
                ",\"unix_ms\":" + std::to_string(e.unix_ms) + ",\"actor\":" + json_string(e.actor) +
                ",\"actor_semantics\":\"AS_RECORDED_NO_PRINCIPAL_INFERENCE\"" +
                ",\"reason_text\":null,\"reason_bytes\":" + std::to_string(e.reason.size()) +
                ",\"reason_digest\":" + digest_json(reason_digest) + ",\"error_code\":" + json_string(e.error_code) +
                ",\"previous_accepted_event\":" + std::to_string(previous_active) +
                ",\"active_event_after\":" + std::to_string(c.active_event) +
                ",\"relocation_paths\":null,\"item_digest\":" + digest_json(c.item) + ",\"prefix_digest\":" + digest_json(c.prefix);
        } else {
            const auto& b = configuration_bindings_[index];
            const auto event_index = static_cast<std::size_t>(b.configuration_event - 1U);
            const auto& e = configuration_events_[event_index]; const auto& c = configuration_history_index_[event_index];
            row += ",\"configuration_event\":" + std::to_string(b.configuration_event) +
                ",\"configuration_generation\":" + json_string(e.generation) +
                ",\"configuration_digest\":" + digest_json(e.digest) +
                ",\"configuration_item_digest\":" + digest_json(c.item) +
                ",\"configuration_prefix_digest\":" + digest_json(c.prefix) +
                ",\"journal_kind\":" + std::to_string(b.journal_kind) +
                ",\"payload_digest\":" + digest_json(b.payload_digest) +
                ",\"operation_id\":" + (b.operation_id ? digest_json(*b.operation_id) : "null") +
                ",\"item_digest\":" + digest_json(binding_digest(b, c.prefix)) +
                ",\"prefix_digest\":" + digest_json(configuration_binding_prefixes_[index]);
        }
        row += '}';
        if (header.size() + rows.size() + (returned ? 1U : 0U) + row.size() + finish(returned + 1U).size() + 256U > r.maximum_bytes) {
            if (returned == 0U) app_fail("CONFIGURATION_HISTORY_PAGE_TOO_SMALL", "first whole row exceeds byte budget");
            break;
        }
        if (returned) rows += ',';
        rows += row; ++returned;
    }
    check_time(); return header + rows + finish(returned);
}
} // namespace natrav_overlay
