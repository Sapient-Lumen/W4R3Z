#pragma once

#include "journal.hpp"
#include "socket.hpp"
#include "tls.hpp"
#include "transport.hpp"

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <vector>

namespace natrav_overlay {
struct RuntimeConfig;

struct SendOptions final {
    std::filesystem::path state_directory;
    std::string local_node;
    std::string expected_peer;
    TransportLocator locator;
    EvidenceRecord record;
    IoOptions io;
    std::uint64_t maximum_journal_bytes{67'108'864U};
};

struct SendResult final {
    QueueDisposition queue_disposition{QueueDisposition::queued};
    bool network_used{false};
    bool secure_transport{false};
    DeliveryReceipt receipt;
    datacube::NATravPeerClientExchangeObservation handshake;
    std::optional<TlsSessionInfo> tls_session;
    IoCounters connect_counters;
    IoCounters tls_counters;
    IoCounters handshake_counters;
    IoCounters application_counters;
};

[[nodiscard]] SendResult send_evidence(const SendOptions& options);

[[nodiscard]] SendResult deliver_outbound_record(
    NodeState& state,
    std::string_view local_node,
    std::string_view expected_peer,
    const TransportLocator& locator,
    const EvidenceRecord& record,
    const IoOptions& io,
    QueueDisposition queue_disposition);

[[nodiscard]] SendResult deliver_outbound_record_secure(
    NodeState& state,
    TlsContext& tls,
    std::string_view local_node,
    std::string_view expected_peer,
    std::string_view expected_peer_generation,
    KeyGenerationState expected_peer_key_state,
    const datacube::Digest32& expected_peer_spki_sha256,
    const TransportLocator& locator,
    const EvidenceRecord& record,
    const IoOptions& io,
    QueueDisposition queue_disposition);

enum class PeerConnectionEvent : std::uint8_t {
    authenticated,
    legacy_connection,
    session_connection,
    operation,
    committed,
    duplicate,
    authorization_denied,
    action_queued,
    session_clean_close,
    session_retired,
};

using PeerConnectionObserver = std::function<void(PeerConnectionEvent)>;

struct PeerConnectionOutcome final {
    bool committed{false};
    bool duplicate{false};
    bool rejected{false};
    bool transport_error{false};
    bool authenticated{false};
    bool authorization_denied{false};
    bool action_queued{false};
    bool session_protocol{false};
    bool session_clean_close{false};
    bool session_retired{false};
    std::size_t operations{0U};
    std::size_t committed_operations{0U};
    std::size_t duplicate_operations{0U};
    std::size_t rejected_operations{0U};
    std::size_t authorization_denials{0U};
    std::size_t actions_queued{0U};
    std::optional<TlsSessionInfo> tls_session;
    IoCounters tls_counters;
    IoCounters counters;
};

[[nodiscard]] PeerConnectionOutcome handle_peer_connection(
    OrderedByteStream& stream,
    NodeState& state,
    std::string_view local_node,
    const IoOptions& io);

struct PeerAdmissionLease final {
    std::shared_ptr<void> guard;
    const AuthorizationPolicy* authorization{nullptr};
    const RuntimeConfig* config{nullptr};
};
using PeerAdmissionGuard = std::function<PeerAdmissionLease(const TlsSessionInfo&)>;
using CustodySessionHandler = std::function<CustodyTransferAcceptance(
    const TlsSessionInfo&, const CustodyTransferOffer&)>;

[[nodiscard]] PeerConnectionOutcome handle_secure_peer_connection(
    OrderedByteStream& stream,
    NodeState& state,
    TlsContext& tls,
    const std::vector<TlsTrustedIdentity>& trusted_peers,
    const AuthorizationPolicy& authorization,
    std::string_view local_node,
    const IoOptions& io,
    const PeerSessionLimits& session_limits,
    PeerConnectionObserver observer = {},
    PeerAdmissionGuard admission_guard = {},
    CustodySessionHandler custody_handler = {});

struct FlushOptions final {
    std::filesystem::path state_directory;
    std::string local_node;
    std::string expected_peer;
    TransportLocator locator;
    IoOptions io;
    std::uint64_t maximum_journal_bytes{67'108'864U};
    std::size_t maximum_records{1'000U};
};

struct FlushResult final {
    std::string peer;
    std::size_t pending_before{0U};
    std::size_t attempted{0U};
    std::size_t acknowledged{0U};
    std::size_t committed{0U};
    std::size_t duplicate{0U};
    std::size_t pending_after{0U};
    std::vector<datacube::Digest32> acknowledged_operations;
    IoCounters connect_counters;
    IoCounters handshake_counters;
    IoCounters application_counters;
};

[[nodiscard]] FlushResult flush_outbox(const FlushOptions& options);

struct ServerOptions final {
    std::filesystem::path state_directory;
    std::string local_node;
    TransportLocator listen_locator;
    IoOptions io;
    std::uint64_t maximum_journal_bytes{67'108'864U};
    std::size_t workers{4U};
    std::size_t queue_capacity{64U};
    std::size_t maximum_connections{0U};
    std::chrono::milliseconds idle_timeout{0};
    int backlog{64};
};

int run_server(const ServerOptions& options);

[[nodiscard]] std::string state_snapshot_json(const StateSnapshot& snapshot);
[[nodiscard]] std::string send_result_json(const SendResult& result);
[[nodiscard]] std::string flush_result_json(const FlushResult& result);
[[nodiscard]] std::string error_json(
    std::string_view code,
    std::string_view detail);

}  // namespace natrav_overlay
