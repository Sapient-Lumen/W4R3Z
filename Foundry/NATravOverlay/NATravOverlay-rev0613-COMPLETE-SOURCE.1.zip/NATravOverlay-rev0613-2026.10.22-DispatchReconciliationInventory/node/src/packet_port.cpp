#include "packet_port.hpp"

#include <algorithm>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <limits>
#include <memory>
#include <span>
#include <string>
#include <string_view>
#include <utility>

namespace natrav_overlay {

int owned_complete_datagram_packet_port_revision_abi() noexcept { return 1; }

namespace {

[[nodiscard]] std::size_t maximum_write_bytes(
    const natrav::packet_link::Limits& limits) noexcept {
    const auto payload = limits.max_payload_bytes();
    if (payload == 0U || limits.max_inflight_frames == 0U) {
        return 0U;
    }
    const auto bounded_frames = std::min(
        limits.max_inflight_frames,
        std::numeric_limits<std::size_t>::max() / payload);
    return std::min(limits.max_message_bytes, payload * bounded_frames);
}

[[nodiscard]] bool valid_error_code(const std::string_view code) noexcept {
    if (code.empty() || code.size() > 64U) {
        return false;
    }
    return std::all_of(code.begin(), code.end(), [](const char value) {
        return (value >= 'A' && value <= 'Z') ||
            (value >= '0' && value <= '9') || value == '_';
    });
}

class PacketPortOrderedByteStream final : public OrderedByteStream {
public:
    PacketPortOrderedByteStream(
        std::unique_ptr<OwnedCompleteDatagramPacketPort> port,
        PacketPortOrderedStreamOptions options)
        : port_(std::move(port)),
          options_(std::move(options)),
          maximum_write_chunk_(maximum_write_bytes(options_.limits)),
          next_tick_(std::chrono::steady_clock::now() + options_.tick_interval) {
        validate_options();
        stream_ = std::make_unique<natrav::packet_link::FinitePacketStream>(
            *port_, options_.stream_id, options_.epoch, options_.limits);
    }

    [[nodiscard]] TransportKind transport_kind() const noexcept override {
        return port_->transport_kind();
    }

    [[nodiscard]] std::size_t read_some(
        const std::span<std::uint8_t> buffer,
        const Deadline deadline,
        IoCounters& counters,
        const std::string_view operation) override {
        if (!stream_ || buffer.empty()) {
            app_fail("SOCKET_INVALID", std::string(operation));
        }
        if (options_.propagate_operation_deadline) { port_->set_operation_deadline(deadline); }
        while (true) {
            if (std::chrono::steady_clock::now() >= deadline) { app_fail("IO_TIMEOUT", std::string(operation)); }
            pump();
            const auto progress = stream_->read_some(buffer);
            if (progress != 0U) {
                ++counters.read_calls;
                return progress;
            }
            if (stream_->read_eof()) {
                ++counters.read_calls;
                return 0U;
            }
            wait_for_progress(deadline, counters, operation);
        }
    }

    [[nodiscard]] std::size_t write_some(
        const datacube::OctetView bytes,
        const Deadline deadline,
        IoCounters& counters,
        const std::string_view operation) override {
        if (!stream_ || bytes.empty() || write_shutdown_) {
            app_fail(
                write_shutdown_ ? "SOCKET_WRITE_CLOSED" : "SOCKET_INVALID",
                std::string(operation));
        }
        const auto amount = std::min(bytes.size(), maximum_write_chunk_);
        if (options_.propagate_operation_deadline) { port_->set_operation_deadline(deadline); }
        while (true) {
            if (std::chrono::steady_clock::now() >= deadline) { app_fail("IO_TIMEOUT", std::string(operation)); }
            pump();
            if (stream_->queue_message(bytes.first(amount), logical_tick_)) {
                ++counters.write_calls;
                pump();
                return amount;
            }
            wait_for_progress(deadline, counters, operation);
        }
    }

    void shutdown_write() override {
        if (!stream_ || write_shutdown_) {
            return;
        }
        const auto deadline =
            std::chrono::steady_clock::now() + options_.shutdown_budget;
        IoCounters counters;
        if (options_.propagate_operation_deadline) { port_->set_operation_deadline(deadline); }
        while (true) {
            pump();
            if (stream_->queue_finish(logical_tick_)) {
                write_shutdown_ = true;
                pump();
                return;
            }
            wait_for_progress(
                deadline, counters, options_.shutdown_operation);
        }
    }

private:
    void validate_options() const {
        const auto error_code = valid_error_code(options_.invalid_stream_code) ?
            std::string_view(options_.invalid_stream_code) :
            std::string_view("PACKET_PORT_STREAM_INVALID");
        try {
            options_.limits.validate();
        } catch (const std::exception&) {
            app_fail(error_code, "invalid finite packet profile for owned port");
        }
        if (!port_ || maximum_write_chunk_ == 0U ||
            options_.stream_id == 0U ||
            (options_.epoch == 0U && !options_.bind_epoch_from_first_packet) ||
            (options_.epoch != 0U && options_.bind_epoch_from_first_packet) ||
            port_->mtu() != options_.limits.mtu ||
            options_.tick_interval < std::chrono::milliseconds(1) ||
            options_.tick_interval > std::chrono::seconds(1) ||
            options_.shutdown_budget < options_.tick_interval ||
            options_.shutdown_budget > std::chrono::minutes(5) ||
            !valid_error_code(options_.invalid_stream_code) ||
            !valid_error_code(options_.logical_clock_invalid_code) ||
            !valid_error_code(options_.logical_clock_exhausted_code) ||
            options_.shutdown_operation.empty()) {
            app_fail(
                error_code,
                "invalid owned complete-datagram packet-stream options");
        }
    }

    void advance_clock() {
        const auto now = std::chrono::steady_clock::now();
        if (now < next_tick_) {
            return;
        }
        const auto elapsed_intervals = (now - next_tick_) / options_.tick_interval;
        const auto signed_steps = elapsed_intervals + 1;
        if (signed_steps <= 0) {
            app_fail(
                options_.logical_clock_invalid_code,
                "packet-link logical clock step is invalid");
        }
        const auto steps = static_cast<std::uint64_t>(signed_steps);
        if (steps > std::numeric_limits<std::uint64_t>::max() - logical_tick_) {
            app_fail(
                options_.logical_clock_exhausted_code,
                "packet-link logical clock exhausted");
        }
        logical_tick_ += steps;
        next_tick_ += options_.tick_interval * signed_steps;
    }

    void pump() {
        advance_clock();
        stream_->pump(logical_tick_);
        if (stream_->failed()) {
            app_fail("PEER_RESET", stream_->failure_reason());
        }
    }

    void wait_for_progress(
        const Deadline deadline,
        IoCounters& counters,
        const std::string_view operation) {
        const auto now = std::chrono::steady_clock::now();
        if (now >= deadline) {
            app_fail("IO_TIMEOUT", std::string(operation));
        }
        port_->wait_for_progress(
            std::min(deadline, next_tick_), deadline, counters, operation);
    }

    std::unique_ptr<OwnedCompleteDatagramPacketPort> port_;
    PacketPortOrderedStreamOptions options_;
    std::size_t maximum_write_chunk_{0U};
    std::unique_ptr<natrav::packet_link::FinitePacketStream> stream_;
    std::uint64_t logical_tick_{1U};
    std::chrono::steady_clock::time_point next_tick_{};
    bool write_shutdown_{false};
};

}  // namespace

std::unique_ptr<OrderedByteStream> make_packet_port_ordered_byte_stream(
    std::unique_ptr<OwnedCompleteDatagramPacketPort> port,
    PacketPortOrderedStreamOptions options) {
    return std::make_unique<PacketPortOrderedByteStream>(
        std::move(port), std::move(options));
}

}  // namespace natrav_overlay
