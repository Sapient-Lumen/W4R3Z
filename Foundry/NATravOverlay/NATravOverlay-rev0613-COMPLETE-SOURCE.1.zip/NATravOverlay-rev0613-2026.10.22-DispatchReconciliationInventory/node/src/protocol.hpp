#pragma once

#include "common.hpp"

#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <variant>

namespace natrav_overlay {

inline constexpr std::size_t kMaximumEvidencePayloadBytes = 60'000U;
inline constexpr std::size_t kMaximumApplicationPayloadBytes = 65'536U;
inline constexpr std::string_view kCounterAddActionScope =
    "actions/counter.add/v1";

inline constexpr std::size_t kPeerSessionHeaderBytes = 100U;
inline constexpr std::size_t kPeerFramePrefixBytes = 4U;
inline constexpr std::uint64_t kMaximumPeerSessionBytes = 67'108'864U;
inline constexpr std::uint16_t kPeerSessionRetireAfterResponse = 1U;

struct PeerSessionLimits final {
    std::uint32_t maximum_operations{32U};
    std::uint64_t maximum_bytes{4'194'304U};
    std::uint32_t maximum_lifetime_ms{30'000U};
    std::uint32_t idle_timeout_ms{2'000U};

    bool operator==(const PeerSessionLimits&) const = default;
};

enum class PeerSessionFrameKind : std::uint8_t {
    open = 1U,
    open_ack = 2U,
    request = 3U,
    response = 4U,
    close = 5U,
    close_ack = 6U,
};

struct PeerSessionFrame final {
    PeerSessionFrameKind kind{PeerSessionFrameKind::open};
    std::uint16_t flags{0U};
    datacube::Digest32 session_id;
    std::uint32_t sequence{0U};
    datacube::Digest32 operation_id;
    std::optional<PeerSessionLimits> limits;
    datacube::Octets payload;

    bool operator==(const PeerSessionFrame&) const = default;
};

void validate_peer_session_limits(const PeerSessionLimits& limits);
[[nodiscard]] bool looks_like_peer_session_frame(
    datacube::OctetView payload) noexcept;
[[nodiscard]] datacube::Octets encode_peer_session_frame(
    const PeerSessionFrame& frame);
[[nodiscard]] PeerSessionFrame decode_peer_session_frame(
    datacube::OctetView payload);
[[nodiscard]] std::string_view peer_session_frame_kind_name(
    PeerSessionFrameKind kind) noexcept;

struct CounterAddRequest final {
    std::uint64_t amount{0U};
    std::uint32_t defer_ms{0U};

    bool operator==(const CounterAddRequest&) const = default;
};

struct EvidenceRecord final {
    datacube::Digest32 operation_id;
    std::string issuer;
    std::string recipient;
    std::string scope;
    std::optional<datacube::Digest32> corrects;
    datacube::Octets payload;

    bool operator==(const EvidenceRecord&) const = default;
};

enum class ReceiptDisposition : std::uint8_t {
    committed = 1U,
    duplicate = 2U,
};

struct DeliveryReceipt final {
    datacube::Digest32 operation_id;
    std::string recipient;
    std::string recorder;
    ReceiptDisposition disposition{ReceiptDisposition::committed};
    std::uint64_t sequence{0U};
    datacube::Digest32 record_digest;

    bool operator==(const DeliveryReceipt&) const = default;
};

struct ProtocolError final {
    std::optional<datacube::Digest32> operation_id;
    std::string code;
    std::string detail;

    bool operator==(const ProtocolError&) const = default;
};

enum class RemoteSourceSubscriptionCommand : std::uint8_t {
    request = 1U,
    status = 2U,
    withdraw = 3U,
};

// An authenticated peer may request only a disclosure grant that the provider
// has already accepted.  The request ID is also the NOS1 operation ID; it is a
// retry/correlation identity, never a source of authority or budget.
struct RemoteSourceSubscriptionRequest final {
    datacube::Digest32 request_id;
    RemoteSourceSubscriptionCommand command{
        RemoteSourceSubscriptionCommand::request};
    std::string grant;
    // V16 leased requests bind the immutable provider lease generation.
    // Withdrawal additionally binds the exact retained instance/revision.
    std::string lease_generation;
    std::optional<datacube::Digest32> instance;
    std::uint64_t expected_revision{0U};
    std::string reason;

    bool operator==(const RemoteSourceSubscriptionRequest&) const = default;
};

struct RemoteSourceSubscriptionResponse final {
    datacube::Digest32 request_id;
    std::string provider;
    std::string grant;
    datacube::Digest32 instance;
    std::uint64_t revision{0U};
    bool retired{false};
    std::string disposition;
    std::uint32_t issued{0U};
    std::uint32_t acknowledged{0U};
    std::uint64_t used_payload_bytes{0U};
    std::uint32_t maximum_records{0U};
    std::uint64_t maximum_payload_bytes{0U};
    datacube::Digest32 grant_digest;
    std::string subscriber_generation;
    datacube::Digest32 subscriber_spki;
    datacube::Digest32 accepted_request_id;
    std::uint64_t accepted_configuration_event{0U};
    std::uint64_t accepted_unix_ms{0U};
    std::string lease_generation;
    std::uint64_t lease_expires_unix_ms{0U};
    std::string withdrawal_policy;
    std::string terminal_kind;
    std::string terminal_pending_disposition;
    std::optional<datacube::Digest32> terminal_cancelled_operation;
    std::string terminal_reason;

    bool operator==(const RemoteSourceSubscriptionResponse&) const = default;
};

// V22 custody transport messages are admitted only inside an authenticated
// reusable NOS1 session.  The opaque bytes retain the separately signed,
// durable offer/acceptance formats; the outer request ID is also the NOS1
// operation ID so transport correlation cannot invent custody state.
// The V22 rule bounds the embedded canonical custody bundle at 60,000 bytes.
// Leave a finite envelope for exact authority, route, configuration, and
// detached-signature bindings while remaining below the 65,536-byte native
// application payload ceiling.
inline constexpr std::size_t kMaximumCustodySessionWireBytes = 64'000U;

struct CustodyTransferOffer final {
    datacube::Digest32 request_id;
    datacube::Octets signed_offer;

    bool operator==(const CustodyTransferOffer&) const = default;
};

struct CustodyTransferAcceptance final {
    datacube::Digest32 request_id;
    datacube::Octets signed_acceptance;

    bool operator==(const CustodyTransferAcceptance&) const = default;
};

using ApplicationMessage = std::variant<EvidenceRecord, DeliveryReceipt,
    ProtocolError, RemoteSourceSubscriptionRequest,
    RemoteSourceSubscriptionResponse, CustodyTransferOffer,
    CustodyTransferAcceptance>;

void validate_evidence_record(const EvidenceRecord& record);
void validate_delivery_receipt(const DeliveryReceipt& receipt);
void validate_protocol_error(const ProtocolError& error);
void validate_remote_source_subscription_request(
    const RemoteSourceSubscriptionRequest& request);
void validate_remote_source_subscription_response(
    const RemoteSourceSubscriptionResponse& response);
void validate_custody_transfer_offer(const CustodyTransferOffer& offer);
void validate_custody_transfer_acceptance(
    const CustodyTransferAcceptance& acceptance);

[[nodiscard]] datacube::Octets encode_application_message(
    const ApplicationMessage& message);
[[nodiscard]] ApplicationMessage decode_application_message(
    datacube::OctetView payload);
[[nodiscard]] std::optional<datacube::Digest32>
application_message_operation_id(const ApplicationMessage& message) noexcept;
[[nodiscard]] datacube::Digest32 evidence_record_digest(
    const EvidenceRecord& record);
[[nodiscard]] std::string_view receipt_disposition_name(
    ReceiptDisposition disposition) noexcept;
[[nodiscard]] datacube::Octets encode_counter_add_request(
    const CounterAddRequest& request);
[[nodiscard]] CounterAddRequest decode_counter_add_request(
    datacube::OctetView payload);
[[nodiscard]] bool is_counter_add_record(
    const EvidenceRecord& record) noexcept;

}  // namespace natrav_overlay
