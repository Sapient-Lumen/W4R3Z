#include "numeric.hpp"
#include <algorithm>
#include <bit>
#include <limits>

namespace natrav_overlay {
bool valid_numeric_unit(const std::string_view unit) noexcept {
    const auto alpha=[](char c){return (c>='A'&&c<='Z')||(c>='a'&&c<='z');};
    return !unit.empty() && unit.size()<=32U && alpha(unit.front()) &&
        std::all_of(unit.begin(),unit.end(),[&](char c){return alpha(c)||(c>='0'&&c<='9')||c=='_'||c=='.'||c=='/'||c=='%'||c=='-';});
}
void validate_numeric_definition(const NumericDefinition& d) {
    if(!valid_numeric_unit(d.unit)||d.scale>9U||d.maximum_absolute_sum==0U||d.maximum_absolute_sum>kNumericSumLimit) {
        app_fail("PROJECTION_NUMERIC_DEFINITION_INVALID", "unit must be 1..32 exact ASCII token characters, scale 0..9 and sum budget 1..10^18");
    }
}
std::string_view numeric_outcome_name(const NumericOutcome outcome) {
    switch(outcome){
    case NumericOutcome::accepted:return "ACCEPTED";
    case NumericOutcome::malformed:return "MALFORMED";
    case NumericOutcome::unit_mismatch:return "UNIT_MISMATCH";
    case NumericOutcome::scale_mismatch:return "SCALE_MISMATCH";
    case NumericOutcome::value_range:return "VALUE_RANGE";
    }
    app_fail("JOURNAL_CORRUPT","unknown numeric outcome");
}
NumericObservation decode_numeric_observation(const datacube::OctetView b,const NumericDefinition& d) noexcept {
    if(b.size()<15U||b[0]!='N'||b[1]!='N'||b[2]!='O'||b[3]!='1'||b[4]>9U||b[5]==0U||b[5]>32U||b.size()!=14U+b[5]){return {};}
    const auto n=static_cast<std::size_t>(b[5]);
    const std::string_view unit(reinterpret_cast<const char*>(b.data()+6U),n);
    if(!valid_numeric_unit(unit)){return {};}
    std::uint64_t bits=0U;
    for(std::size_t i=6U+n;i<b.size();++i){bits=(bits<<8U)|b[i];}
    const auto ticks=std::bit_cast<std::int64_t>(bits);
    if(unit!=d.unit){return {NumericOutcome::unit_mismatch,0};}
    if(b[4]!=d.scale){return {NumericOutcome::scale_mismatch,0};}
    if(ticks < -kNumericValueLimit || ticks > kNumericValueLimit){return {NumericOutcome::value_range,0};}
    return {NumericOutcome::accepted,ticks};
}
datacube::Octets encode_numeric_observation(const NumericDefinition& d,const std::int64_t ticks) {
    validate_numeric_definition(d);
    if(ticks < -kNumericValueLimit || ticks > kNumericValueLimit){app_fail("NUMERIC_VALUE_RANGE","numeric ticks must be within +/-10^12");}
    datacube::Octets out;datacube::append_text(out,"NNO1");datacube::append_u8(out,d.scale);
    datacube::append_u8(out,static_cast<std::uint8_t>(d.unit.size()));datacube::append_text(out,d.unit);
    datacube::append_be64(out,std::bit_cast<std::uint64_t>(ticks));return out;
}
namespace {
void increment(std::uint64_t& v){if(v==std::numeric_limits<std::uint64_t>::max()){app_fail("PROJECTION_ARITHMETIC_LIMIT","numeric counter overflow");}++v;}
void decrement(std::uint64_t& v){if(v==0U){app_fail("JOURNAL_CORRUPT","numeric correction predecessor missing from result");}--v;}
std::int64_t add(const std::int64_t a,const std::int64_t b){
    if((b>0&&a>std::numeric_limits<std::int64_t>::max()-b)||(b<0&&a<std::numeric_limits<std::int64_t>::min()-b)){
        app_fail("PROJECTION_ARITHMETIC_LIMIT","numeric signed sum overflow");
    }return a+b;
}
}
void apply_numeric_observation(NumericTotals& totals,const NumericObservation& source,
    const NumericObservation* parent,const NumericDefinition& d) {
    // Strong exception guarantee even for direct native callers.
    auto next=totals;
    const auto valid=[](const NumericObservation& v){
        if(v.outcome>NumericOutcome::value_range || (v.outcome==NumericOutcome::accepted &&
            (v.ticks < -kNumericValueLimit || v.ticks > kNumericValueLimit))){app_fail("JOURNAL_CORRUPT","invalid decoded numeric observation");}
    };
    valid(source);
    if(parent){valid(*parent);if(parent->outcome==NumericOutcome::accepted){decrement(next.valid_heads);next.sum_ticks=add(next.sum_ticks,-parent->ticks);}
        else{decrement(next.invalid_heads);}}
    if(source.outcome==NumericOutcome::accepted){increment(next.accepted);increment(next.valid_heads);next.sum_ticks=add(next.sum_ticks,source.ticks);}
    else{increment(next.rejected);increment(next.invalid_heads);increment(next.errors.at(static_cast<std::size_t>(source.outcome)-1U));}
    const auto bound=static_cast<std::int64_t>(d.maximum_absolute_sum);
    if(next.sum_ticks > bound || next.sum_ticks < -bound){app_fail("PROJECTION_NUMERIC_SUM_LIMIT","exact per-admission sum budget exceeded; entire issued page remains outstanding");}
    totals=next;
}
datacube::Octets encode_numeric_definition(const NumericDefinition& d){
    validate_numeric_definition(d);datacube::Octets out;datacube::append_u8(out,static_cast<std::uint8_t>(d.unit.size()));
    datacube::append_text(out,d.unit);datacube::append_u8(out,d.scale);datacube::append_be64(out,d.maximum_absolute_sum);return out;
}
NumericDefinition decode_numeric_definition(datacube::Reader& r){
    NumericDefinition d;const auto n=r.read_u8("numeric unit length");
    if(n>32U){app_fail("PROJECTION_NUMERIC_DEFINITION_INVALID","unit length exceeds bound");}
    d.unit=datacube::octets_text(r.read_exact(n,"numeric unit"),"numeric unit",true);
    d.scale=r.read_u8("numeric scale");d.maximum_absolute_sum=r.read_be64("numeric sum budget");validate_numeric_definition(d);return d;
}
} // namespace natrav_overlay
