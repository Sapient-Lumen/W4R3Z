#include "custody_session_service.hpp"

#include "config.hpp"
#include "custody_authority.hpp"
#include "custody_bundle.hpp"
#include "custody_session_policy.hpp"
#include "handoff_io.hpp"
#include "handoff_policy.hpp"
#include "local_control.hpp"
#include "node.hpp"
#include "peer_session.hpp"
#include "runtime.hpp"
#include "tls.hpp"
#include "transport.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <csignal>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fcntl.h>
#include <limits>
#include <iostream>
#include <memory>
#include <optional>
#include <poll.h>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <sys/types.h>
#include <thread>
#include <unistd.h>
#include <utility>
#include <vector>

#include <openssl/crypto.h>
#include <openssl/evp.h>

namespace natrav_overlay {
namespace {

using Bytes = datacube::Octets;
using View = datacube::OctetView;
using SigningKey = CustodySigningKey;
using KeyPtr = std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)>;
using MdPtr = std::unique_ptr<EVP_MD_CTX, decltype(&EVP_MD_CTX_free)>;

inline constexpr std::string_view kOfferMagic = "NHCSO001";
inline constexpr std::string_view kAcceptanceMagic = "NHCSA001";
inline constexpr std::string_view kOfferSignatureDomain =
    "NATravOverlay/native-custody-session-offer/v1";
inline constexpr std::string_view kOfferRequestDomain =
    "NATravOverlay/native-custody-session-request/v1";
inline constexpr std::string_view kAcceptanceSignatureDomain =
    "NATravOverlay/native-custody-session-acceptance/v1";
inline constexpr std::size_t kDetachedSignatureBytes = 64U;
inline constexpr std::size_t kStateTextLimit = 4'096U;
inline constexpr std::size_t kCaseScanLimit =
    static_cast<std::size_t>(kCustodySessionMaximumPendingCases);

volatile sig_atomic_t service_stop_requested = 0;
std::atomic<std::uint64_t> staging_counter{0U};

void service_stop_handler(int) { service_stop_requested = 1; }

void require(const bool condition, const std::string_view code,
    const std::string_view detail) {
    if (!condition) { app_fail(code, detail); }
}

std::uint64_t now_ms() {
    const auto value = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    require(value >= 0, "CUSTODY_SESSION_TIME_INVALID",
        "system clock precedes the Unix epoch");
    return static_cast<std::uint64_t>(value);
}

void custody_session_test_pause(const std::string_view phase) {
    const std::string name =
        "NATRAV_OVERLAY_TEST_CUSTODY_SESSION_" + std::string(phase) + "_MS";
    const char* raw = std::getenv(name.c_str());
    if (raw == nullptr || *raw == '\0') { return; }
    const auto delay = parse_u64(raw, name, 1U, 60'000U);
    std::cerr << name << '\n' << std::flush;
    std::this_thread::sleep_for(std::chrono::milliseconds(delay));
}

View digest_view(const datacube::Digest32& digest) {
    return View(digest.octets.data(), digest.octets.size());
}

bool equal_digest(const datacube::Digest32& left,
    const datacube::Digest32& right) noexcept {
    return CRYPTO_memcmp(left.octets.data(), right.octets.data(),
        left.octets.size()) == 0;
}

std::string bounded_detail(const std::string_view detail) {
    std::string result;
    result.reserve(std::min<std::size_t>(detail.size(), 1'024U));
    for (const char raw : detail) {
        if (result.size() == 1'024U) { break; }
        const auto value = static_cast<unsigned char>(raw);
        result.push_back(value >= 32U && value <= 126U ? raw : ' ');
    }
    if (result.empty()) { result = "custody session outcome unresolved"; }
    return result;
}

class Writer final {
public:
    Bytes bytes;

    void raw(const View value) {
        bytes.insert(bytes.end(), value.begin(), value.end());
    }
    void text(const std::string_view value) {
        raw(View(reinterpret_cast<const std::uint8_t*>(value.data()),
            value.size()));
    }
    void u8(const std::uint8_t value) { datacube::append_u8(bytes, value); }
    void u16(const std::uint16_t value) {
        datacube::append_be16(bytes, value);
    }
    void u32(const std::uint32_t value) {
        datacube::append_be32(bytes, value);
    }
    void u64(const std::uint64_t value) {
        datacube::append_be64(bytes, value);
    }
    void digest(const datacube::Digest32& value) { raw(digest_view(value)); }
    void identifier(const std::string_view value) {
        require(!value.empty() && value.size() <= 64U,
            "CUSTODY_SESSION_ENCODING_REJECTED",
            "identifier length is outside the finite wire bound");
        u8(static_cast<std::uint8_t>(value.size()));
        text(value);
    }
    void octets32(const View value) {
        require(value.size() <=
                static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max()),
            "CUSTODY_SESSION_ENCODING_REJECTED",
            "octet field cannot be encoded");
        u32(static_cast<std::uint32_t>(value.size()));
        raw(value);
    }
};

class Reader final {
public:
    explicit Reader(const View source) : bytes_(source) {}

    View take(const std::size_t count) {
        require(count <= bytes_.size() - offset_,
            "CUSTODY_SESSION_ENCODING_REJECTED", "truncated field");
        const auto result = bytes_.subspan(offset_, count);
        offset_ += count;
        return result;
    }
    std::uint64_t number(const std::size_t count) {
        std::uint64_t result = 0U;
        for (const auto byte : take(count)) {
            result = (result << 8U) | byte;
        }
        return result;
    }
    std::uint8_t u8() { return static_cast<std::uint8_t>(number(1U)); }
    std::uint16_t u16() { return static_cast<std::uint16_t>(number(2U)); }
    std::uint32_t u32() { return static_cast<std::uint32_t>(number(4U)); }
    std::uint64_t u64() { return number(8U); }
    datacube::Digest32 digest() {
        datacube::Digest32 result{};
        const auto value = take(result.octets.size());
        std::copy(value.begin(), value.end(), result.octets.begin());
        return result;
    }
    std::string identifier() {
        const auto count = u8();
        require(count > 0U && count <= 64U,
            "CUSTODY_SESSION_ENCODING_REJECTED",
            "identifier length is outside the finite wire bound");
        const auto value = take(count);
        const std::string result(
            reinterpret_cast<const char*>(value.data()), value.size());
        require(std::all_of(result.begin(), result.end(), [](const char raw) {
                const auto ch = static_cast<unsigned char>(raw);
                return ch >= 33U && ch <= 126U;
            }),
            "CUSTODY_SESSION_ENCODING_REJECTED",
            "identifier contains a non-canonical byte");
        return result;
    }
    Bytes octets32(const std::size_t maximum) {
        const auto count = static_cast<std::size_t>(u32());
        require(count <= maximum,
            "CUSTODY_SESSION_ENCODING_REJECTED",
            "octet field exceeds its finite bound");
        const auto value = take(count);
        return Bytes(value.begin(), value.end());
    }
    void magic(const std::string_view expected) {
        const auto value = take(expected.size());
        require(std::equal(value.begin(), value.end(), expected.begin()),
            "CUSTODY_SESSION_ENCODING_REJECTED", "unknown wire format");
    }
    std::size_t offset() const noexcept { return offset_; }
    void end() const {
        require(offset_ == bytes_.size(),
            "CUSTODY_SESSION_ENCODING_REJECTED", "trailing wire bytes");
    }

private:
    View bytes_;
    std::size_t offset_{0U};
};

Bytes domain_message(const std::string_view domain, const View message) {
    Writer writer;
    writer.text(domain);
    writer.u8(0U);
    writer.raw(message);
    return std::move(writer.bytes);
}

SigningKey raw_public_key(EVP_PKEY* key) {
    require(key != nullptr && EVP_PKEY_id(key) == EVP_PKEY_ED25519,
        "CUSTODY_SESSION_SIGNING_KEY_REJECTED",
        "custody session signing requires Ed25519");
    SigningKey result{};
    std::size_t count = result.size();
    require(EVP_PKEY_get_raw_public_key(key, result.data(), &count) == 1 &&
            count == result.size(),
        "CUSTODY_SESSION_CRYPTO_FAILED",
        "unable to extract the Ed25519 public key");
    return result;
}

KeyPtr public_key(const SigningKey& raw) {
    require(std::any_of(raw.begin(), raw.end(), [](const std::uint8_t value) {
            return value != 0U;
        }),
        "CUSTODY_SESSION_SIGNING_KEY_REJECTED", "zero public key");
    EVP_PKEY* value = EVP_PKEY_new_raw_public_key(
        EVP_PKEY_ED25519, nullptr, raw.data(), raw.size());
    require(value != nullptr, "CUSTODY_SESSION_CRYPTO_FAILED",
        "unable to construct the Ed25519 public key");
    return KeyPtr(value, EVP_PKEY_free);
}

Bytes sign_detached(EVP_PKEY* key, const SigningKey& expected_public,
    const std::string_view domain, const View message) {
    require(raw_public_key(key) == expected_public,
        "CUSTODY_SESSION_SIGNING_KEY_REJECTED",
        "private signing key differs from the exact route party");
    const auto input = domain_message(domain, message);
    MdPtr context(EVP_MD_CTX_new(), EVP_MD_CTX_free);
    require(context != nullptr &&
            EVP_DigestSignInit(
                context.get(), nullptr, nullptr, nullptr, key) == 1,
        "CUSTODY_SESSION_CRYPTO_FAILED",
        "unable to initialize Ed25519 signing");
    Bytes signature(kDetachedSignatureBytes);
    std::size_t count = signature.size();
    require(EVP_DigestSign(context.get(), signature.data(), &count,
                input.data(), input.size()) == 1 &&
            count == signature.size(),
        "CUSTODY_SESSION_CRYPTO_FAILED", "unable to sign custody wire");
    return signature;
}

void verify_detached(const SigningKey& raw,
    const std::string_view domain, const View message,
    const View signature) {
    require(signature.size() == kDetachedSignatureBytes,
        "CUSTODY_SESSION_SIGNATURE_REJECTED", "signature size is invalid");
    auto key = public_key(raw);
    const auto input = domain_message(domain, message);
    MdPtr context(EVP_MD_CTX_new(), EVP_MD_CTX_free);
    require(context != nullptr &&
            EVP_DigestVerifyInit(
                context.get(), nullptr, nullptr, nullptr, key.get()) == 1,
        "CUSTODY_SESSION_CRYPTO_FAILED",
        "unable to initialize Ed25519 verification");
    require(EVP_DigestVerify(context.get(), signature.data(), signature.size(),
                input.data(), input.size()) == 1,
        "CUSTODY_SESSION_SIGNATURE_REJECTED",
        "custody session signature did not verify");
}

struct SignedOffer final {
    datacube::Digest32 request_id;
    std::string rule_id;
    std::uint64_t rule_generation{0U};
    datacube::Digest32 rule_commitment;
    CustodyGrantReference grant;
    datacube::Digest32 sender_configuration_sha256;
    std::string route_id;
    datacube::Digest32 custodian_certificate_sha256;
    datacube::Digest32 next_hop_certificate_sha256;
    std::uint64_t created_ms{0U};
    std::uint64_t expires_ms{0U};
    Bytes bundle;
    Bytes unsigned_bytes;
    Bytes signature;
    Bytes wire;
};

struct SignedAcceptance final {
    datacube::Digest32 request_id;
    datacube::Digest32 offer_sha256;
    std::string rule_id;
    std::uint64_t rule_generation{0U};
    datacube::Digest32 rule_commitment;
    CustodyGrantReference grant;
    datacube::Digest32 receiver_configuration_sha256;
    datacube::Digest32 custodian_certificate_sha256;
    datacube::Digest32 next_hop_certificate_sha256;
    std::uint64_t accepted_ms{0U};
    Bytes record;
    Bytes unsigned_bytes;
    Bytes signature;
    Bytes wire;
};

Writer offer_unsigned(const SignedOffer& offer) {
    Writer writer;
    writer.text(kOfferMagic);
    writer.u16(0U);
    writer.identifier(offer.rule_id);
    writer.u64(offer.rule_generation);
    writer.digest(offer.rule_commitment);
    writer.identifier(offer.grant.id);
    writer.u64(offer.grant.generation);
    writer.digest(offer.grant.commitment);
    writer.digest(offer.sender_configuration_sha256);
    writer.identifier(offer.route_id);
    writer.digest(offer.custodian_certificate_sha256);
    writer.digest(offer.next_hop_certificate_sha256);
    writer.u64(offer.created_ms);
    writer.u64(offer.expires_ms);
    writer.octets32(offer.bundle);
    return writer;
}

SignedOffer build_offer(const CustodySessionRule& rule,
    const datacube::Digest32& configuration_sha256,
    const std::string_view route_id, const std::uint64_t created_ms,
    const std::uint64_t expires_ms, Bytes bundle,
    const CustodyParty& signing_party, EVP_PKEY* signer) {
    SignedOffer offer;
    offer.rule_id = rule.id;
    offer.rule_generation = rule.generation;
    offer.rule_commitment = custody_session_rule_commitment(rule);
    offer.grant = rule.grant;
    offer.sender_configuration_sha256 = configuration_sha256;
    offer.route_id = std::string(route_id);
    offer.custodian_certificate_sha256 =
        rule.custodian_certificate_sha256;
    offer.next_hop_certificate_sha256 = rule.next_hop_certificate_sha256;
    offer.created_ms = created_ms;
    offer.expires_ms = expires_ms;
    offer.bundle = std::move(bundle);
    auto unsigned_wire = offer_unsigned(offer);
    offer.unsigned_bytes = unsigned_wire.bytes;
    offer.signature = sign_detached(signer, signing_party.signing_public,
        kOfferSignatureDomain, offer.unsigned_bytes);
    unsigned_wire.raw(offer.signature);
    offer.wire = std::move(unsigned_wire.bytes);
    require(offer.wire.size() <= kMaximumCustodySessionWireBytes,
        "CUSTODY_SESSION_OFFER_LIMIT",
        "signed custody offer exceeds the native application bound");
    const auto request_input = domain_message(kOfferRequestDomain, offer.wire);
    offer.request_id = datacube::sha256(request_input);
    require(!digest_is_zero(offer.request_id),
        "CUSTODY_SESSION_REQUEST_INVALID", "request digest is zero");
    return offer;
}

SignedOffer parse_offer(const View wire) {
    require(!wire.empty() && wire.size() <= kMaximumCustodySessionWireBytes,
        "CUSTODY_SESSION_OFFER_LIMIT",
        "signed custody offer is outside the native application bound");
    Reader reader(wire);
    reader.magic(kOfferMagic);
    require(reader.u16() == 0U,
        "CUSTODY_SESSION_ENCODING_REJECTED", "unsupported offer flags");
    SignedOffer offer;
    offer.rule_id = reader.identifier();
    offer.rule_generation = reader.u64();
    offer.rule_commitment = reader.digest();
    offer.grant.id = reader.identifier();
    offer.grant.generation = reader.u64();
    offer.grant.commitment = reader.digest();
    offer.sender_configuration_sha256 = reader.digest();
    offer.route_id = reader.identifier();
    offer.custodian_certificate_sha256 = reader.digest();
    offer.next_hop_certificate_sha256 = reader.digest();
    offer.created_ms = reader.u64();
    offer.expires_ms = reader.u64();
    offer.bundle = reader.octets32(kCustodySessionMaximumBundleBytes);
    const auto signature_offset = reader.offset();
    const auto signature = reader.take(kDetachedSignatureBytes);
    reader.end();
    offer.unsigned_bytes.assign(wire.begin(), wire.begin() +
        static_cast<std::ptrdiff_t>(signature_offset));
    offer.signature.assign(signature.begin(), signature.end());
    offer.wire.assign(wire.begin(), wire.end());
    const auto canonical = offer_unsigned(offer).bytes;
    require(canonical == offer.unsigned_bytes,
        "CUSTODY_SESSION_ENCODING_REJECTED",
        "signed custody offer is not canonical");
    const auto request_input = domain_message(kOfferRequestDomain, offer.wire);
    offer.request_id = datacube::sha256(request_input);
    return offer;
}

Writer acceptance_unsigned(const SignedAcceptance& acceptance) {
    Writer writer;
    writer.text(kAcceptanceMagic);
    writer.u16(0U);
    writer.digest(acceptance.request_id);
    writer.digest(acceptance.offer_sha256);
    writer.identifier(acceptance.rule_id);
    writer.u64(acceptance.rule_generation);
    writer.digest(acceptance.rule_commitment);
    writer.identifier(acceptance.grant.id);
    writer.u64(acceptance.grant.generation);
    writer.digest(acceptance.grant.commitment);
    writer.digest(acceptance.receiver_configuration_sha256);
    writer.digest(acceptance.custodian_certificate_sha256);
    writer.digest(acceptance.next_hop_certificate_sha256);
    writer.u64(acceptance.accepted_ms);
    writer.octets32(acceptance.record);
    return writer;
}

SignedAcceptance build_acceptance(const SignedOffer& offer,
    const CustodySessionRule& rule,
    const datacube::Digest32& configuration_sha256,
    const CustodyRecord& record, const CustodyParty& signing_party,
    EVP_PKEY* signer) {
    SignedAcceptance acceptance;
    acceptance.request_id = offer.request_id;
    acceptance.offer_sha256 = datacube::sha256(offer.wire);
    acceptance.rule_id = rule.id;
    acceptance.rule_generation = rule.generation;
    acceptance.rule_commitment = custody_session_rule_commitment(rule);
    acceptance.grant = rule.grant;
    acceptance.receiver_configuration_sha256 = configuration_sha256;
    acceptance.custodian_certificate_sha256 =
        rule.custodian_certificate_sha256;
    acceptance.next_hop_certificate_sha256 =
        rule.next_hop_certificate_sha256;
    acceptance.accepted_ms = record.event_ms;
    acceptance.record = record.canonical;
    auto unsigned_wire = acceptance_unsigned(acceptance);
    acceptance.unsigned_bytes = unsigned_wire.bytes;
    acceptance.signature = sign_detached(signer,
        signing_party.signing_public, kAcceptanceSignatureDomain,
        acceptance.unsigned_bytes);
    unsigned_wire.raw(acceptance.signature);
    acceptance.wire = std::move(unsigned_wire.bytes);
    require(acceptance.wire.size() <= kMaximumCustodySessionWireBytes,
        "CUSTODY_SESSION_ACCEPTANCE_LIMIT",
        "signed custody acceptance exceeds the native application bound");
    return acceptance;
}

SignedAcceptance parse_acceptance(const View wire) {
    require(!wire.empty() && wire.size() <= kMaximumCustodySessionWireBytes,
        "CUSTODY_SESSION_ACCEPTANCE_LIMIT",
        "signed custody acceptance is outside the native application bound");
    Reader reader(wire);
    reader.magic(kAcceptanceMagic);
    require(reader.u16() == 0U,
        "CUSTODY_SESSION_ENCODING_REJECTED",
        "unsupported acceptance flags");
    SignedAcceptance acceptance;
    acceptance.request_id = reader.digest();
    acceptance.offer_sha256 = reader.digest();
    acceptance.rule_id = reader.identifier();
    acceptance.rule_generation = reader.u64();
    acceptance.rule_commitment = reader.digest();
    acceptance.grant.id = reader.identifier();
    acceptance.grant.generation = reader.u64();
    acceptance.grant.commitment = reader.digest();
    acceptance.receiver_configuration_sha256 = reader.digest();
    acceptance.custodian_certificate_sha256 = reader.digest();
    acceptance.next_hop_certificate_sha256 = reader.digest();
    acceptance.accepted_ms = reader.u64();
    acceptance.record = reader.octets32(kCustodyRecordLimit);
    const auto signature_offset = reader.offset();
    const auto signature = reader.take(kDetachedSignatureBytes);
    reader.end();
    acceptance.unsigned_bytes.assign(wire.begin(), wire.begin() +
        static_cast<std::ptrdiff_t>(signature_offset));
    acceptance.signature.assign(signature.begin(), signature.end());
    acceptance.wire.assign(wire.begin(), wire.end());
    require(acceptance_unsigned(acceptance).bytes ==
            acceptance.unsigned_bytes,
        "CUSTODY_SESSION_ENCODING_REJECTED",
        "signed custody acceptance is not canonical");
    return acceptance;
}

void ensure_private_directory(const std::filesystem::path& directory) {
    struct stat status {};
    if (::lstat(directory.c_str(), &status) != 0) {
        require(errno == ENOENT, "CUSTODY_SESSION_STATE_REJECTED",
            datacube::errno_detail("custody service directory", errno));
        require(::mkdir(directory.c_str(), 0700) == 0,
            "CUSTODY_SESSION_STATE_REJECTED",
            datacube::errno_detail("custody service mkdir", errno));
        require(::lstat(directory.c_str(), &status) == 0,
            "CUSTODY_SESSION_STATE_REJECTED",
            datacube::errno_detail("custody service directory stat", errno));
    }
    require(S_ISDIR(status.st_mode) && status.st_uid == ::geteuid() &&
            (status.st_mode & 0077U) == 0U,
        "CUSTODY_SESSION_STATE_REJECTED",
        "custody service directories must be owner-private real directories");
}

void ensure_service_layout(const std::filesystem::path& root) {
    ensure_private_directory(root.parent_path());
    ensure_private_directory(root);
    ensure_private_directory(root / "cases");
    ensure_private_directory(root / "envelope-index");
    ensure_private_directory(root / "dispatch-index");
}

void write_all(const int descriptor, const View bytes) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const ssize_t count = ::write(descriptor, bytes.data() + offset,
            bytes.size() - offset);
        if (count < 0 && errno == EINTR) { continue; }
        require(count > 0, "CUSTODY_SESSION_STATE_WRITE_FAILED",
            datacube::errno_detail("custody service state write", errno));
        offset += static_cast<std::size_t>(count);
    }
}

void sync_directory(const std::filesystem::path& directory) {
    const int raw = ::open(directory.c_str(),
        O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    require(raw >= 0, "CUSTODY_SESSION_STATE_SYNC_FAILED",
        datacube::errno_detail("custody service directory open", errno));
    datacube::Fd descriptor(raw);
    require(::fsync(descriptor.get()) == 0,
        "CUSTODY_SESSION_STATE_SYNC_FAILED",
        datacube::errno_detail("custody service directory sync", errno));
}

void atomic_write(const std::filesystem::path& destination,
    const View bytes) {
    ensure_private_directory(destination.parent_path());
    const auto serial = staging_counter.fetch_add(1U);
    const auto temporary = destination.parent_path() /
        (".custody-session-part-" + std::to_string(::getpid()) + "-" +
            std::to_string(serial));
    const int raw = ::open(temporary.c_str(),
        O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0600);
    require(raw >= 0, "CUSTODY_SESSION_STATE_WRITE_FAILED",
        datacube::errno_detail("custody service staging create", errno));
    datacube::Fd descriptor(raw);
    try {
        write_all(descriptor.get(), bytes);
        require(::fsync(descriptor.get()) == 0,
            "CUSTODY_SESSION_STATE_SYNC_FAILED",
            datacube::errno_detail("custody service state sync", errno));
        descriptor = datacube::Fd{};
        require(::rename(temporary.c_str(), destination.c_str()) == 0,
            "CUSTODY_SESSION_STATE_WRITE_FAILED",
            datacube::errno_detail("custody service atomic rename", errno));
        sync_directory(destination.parent_path());
    } catch (...) {
        static_cast<void>(::unlink(temporary.c_str()));
        throw;
    }
}

void atomic_write_text(const std::filesystem::path& destination,
    const std::string_view text) {
    atomic_write(destination, View(
        reinterpret_cast<const std::uint8_t*>(text.data()), text.size()));
}

Bytes read_regular_file(const std::filesystem::path& path,
    const std::size_t maximum, const bool allow_empty = false) {
    const int raw = ::open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    require(raw >= 0, "CUSTODY_SESSION_STATE_READ_FAILED",
        datacube::errno_detail("custody service state open", errno));
    datacube::Fd descriptor(raw);
    struct stat status {};
    require(::fstat(descriptor.get(), &status) == 0 &&
            S_ISREG(status.st_mode) && status.st_uid == ::geteuid() &&
            status.st_nlink == 1 && (status.st_mode & 0077U) == 0U &&
            status.st_size >= 0 &&
            static_cast<std::uint64_t>(status.st_size) <= maximum &&
            (allow_empty || status.st_size > 0),
        "CUSTODY_SESSION_STATE_READ_FAILED",
        "custody service state file type, ownership, mode, or size rejected");
    Bytes result(static_cast<std::size_t>(status.st_size));
    std::size_t offset = 0U;
    while (offset < result.size()) {
        const ssize_t count = ::read(descriptor.get(), result.data() + offset,
            result.size() - offset);
        if (count < 0 && errno == EINTR) { continue; }
        require(count > 0, "CUSTODY_SESSION_STATE_READ_FAILED",
            "custody service state read was incomplete");
        offset += static_cast<std::size_t>(count);
    }
    return result;
}

std::string read_text(const std::filesystem::path& path,
    const std::size_t maximum = kStateTextLimit) {
    const auto bytes = read_regular_file(path, maximum);
    std::string result(bytes.begin(), bytes.end());
    while (!result.empty() &&
        (result.back() == '\n' || result.back() == '\r')) {
        result.pop_back();
    }
    require(!result.empty(), "CUSTODY_SESSION_STATE_READ_FAILED",
        "custody service text state is empty");
    return result;
}

bool regular_file_exists(const std::filesystem::path& path) {
    struct stat status {};
    if (::lstat(path.c_str(), &status) != 0) {
        if (errno == ENOENT) { return false; }
        app_fail("CUSTODY_SESSION_STATE_READ_FAILED",
            datacube::errno_detail("custody service state stat", errno));
    }
    require(S_ISREG(status.st_mode) && status.st_uid == ::geteuid() &&
            status.st_nlink == 1 && (status.st_mode & 0077U) == 0U,
        "CUSTODY_SESSION_STATE_READ_FAILED",
        "custody service state path is not an owner-controlled regular file");
    return true;
}

void persist_exact(const std::filesystem::path& path, const View bytes,
    const std::size_t maximum, const std::string_view conflict_detail) {
    if (regular_file_exists(path)) {
        require(read_regular_file(path, maximum) == Bytes(bytes.begin(), bytes.end()),
            "CUSTODY_SESSION_REPLAY_CONFLICT", conflict_detail);
        return;
    }
    atomic_write(path, bytes);
}

std::uint64_t read_counter(const std::filesystem::path& path) {
    if (!regular_file_exists(path)) { return 0U; }
    const auto text = read_text(path, 64U);
    return parse_u64(text, "custody service attempt counter", 0U,
        kCustodySessionMaximumAttempts);
}

bool canonical_retained_operation_id_text(const std::string_view text) {
    return text.size() == 64U &&
        std::all_of(text.begin(), text.end(), [](const char value) {
            return (value >= '0' && value <= '9') ||
                (value >= 'a' && value <= 'f');
        }) &&
        std::any_of(text.begin(), text.end(), [](const char value) {
            return value != '0';
        });
}

datacube::Digest32 parse_retained_operation_id(
    const std::string_view text, const std::string_view detail) {
    require(canonical_retained_operation_id_text(text),
        "CUSTODY_DISPATCH_STATE_REJECTED", detail);
    return parse_operation_id(std::string(text));
}

std::filesystem::path service_root(const RuntimeConfig& config,
    const CustodySessionRule& rule) {
    const auto base = config.state_directory / "custody-session-v1";
    ensure_private_directory(base);
    const auto id = base / rule.id;
    ensure_private_directory(id);
    const auto root = id / std::to_string(rule.generation);
    ensure_service_layout(root);
    return root;
}

std::filesystem::path case_path(const std::filesystem::path& root,
    const datacube::Digest32& request_id) {
    return root / "cases" / operation_id_text(request_id);
}

std::filesystem::path envelope_index_path(
    const std::filesystem::path& root,
    const datacube::Digest32& envelope_sha256) {
    return root / "envelope-index" / operation_id_text(envelope_sha256);
}

std::optional<datacube::Digest32> indexed_request(
    const std::filesystem::path& root,
    const datacube::Digest32& envelope_sha256) {
    const auto path = envelope_index_path(root, envelope_sha256);
    if (!regular_file_exists(path)) { return std::nullopt; }
    return parse_operation_id(read_text(path, 128U));
}

std::optional<datacube::Digest32> case_envelope_sha256(
    const std::filesystem::path& directory, const bool repair_metadata) {
    const auto envelope_path = directory / "envelope_sha256";
    if (regular_file_exists(envelope_path)) {
        return parse_operation_id(read_text(envelope_path, 128U));
    }

    // offer.bin is the first durable case artifact. A crash may occur after
    // that fsync and before the derived envelope metadata or reverse index is
    // installed. Reconstruct only from the complete, canonical signed offer;
    // never mint a second request identity for the same custody envelope.
    const auto offer_path = directory / "offer.bin";
    if (!regular_file_exists(offer_path)) { return std::nullopt; }
    const auto request_id = parse_operation_id(
        directory.filename().string());
    const auto offer = parse_offer(read_regular_file(
        offer_path, kMaximumCustodySessionWireBytes));
    require(equal_digest(offer.request_id, request_id),
        "CUSTODY_SESSION_REPLAY_CONFLICT",
        "custody service case directory differs from its signed offer");
    const auto bundle = decode_custody_bundle(offer.bundle);
    const auto envelope_sha256 = custody_bundle_envelope_sha256(bundle);
    if (repair_metadata) {
        atomic_write_text(envelope_path,
            operation_id_text(envelope_sha256) + "\n");
    }
    return envelope_sha256;
}

std::optional<datacube::Digest32> scan_request_for_envelope(
    const std::filesystem::path& root,
    const datacube::Digest32& envelope_sha256,
    const bool repair_metadata) {
    std::size_t examined = 0U;
    const auto cases = root / "cases";
    for (const auto& entry : std::filesystem::directory_iterator(cases)) {
        require(++examined <= kCaseScanLimit,
            "CUSTODY_SESSION_STATE_CAPACITY",
            "custody service case scan exceeds the finite bound");
        if (!entry.is_directory()) { continue; }
        const auto candidate = case_envelope_sha256(
            entry.path(), repair_metadata);
        if (candidate && equal_digest(*candidate, envelope_sha256)) {
            return parse_operation_id(entry.path().filename().string());
        }
    }
    return std::nullopt;
}

std::optional<datacube::Digest32> request_for_envelope(
    const std::filesystem::path& root,
    const datacube::Digest32& envelope_sha256, const bool repair_index) {
    auto result = indexed_request(root, envelope_sha256);
    const bool reconstructing = !result.has_value() && repair_index;
    if (!result) {
        if (reconstructing) {
            custody_session_test_pause("BEFORE_ENVELOPE_INDEX_RECONSTRUCTION");
        }
        result = scan_request_for_envelope(
            root, envelope_sha256, repair_index);
    }
    if (result && repair_index &&
        !regular_file_exists(envelope_index_path(root, envelope_sha256))) {
        atomic_write_text(envelope_index_path(root, envelope_sha256),
            operation_id_text(*result) + "\n");
    }
    if (reconstructing && result) {
        custody_session_test_pause("AFTER_ENVELOPE_INDEX_RECONSTRUCTION");
    }
    return result;
}

std::size_t unresolved_case_count(const std::filesystem::path& root) {
    std::size_t count = 0U;
    std::size_t examined = 0U;
    for (const auto& entry :
            std::filesystem::directory_iterator(root / "cases")) {
        require(++examined <= kCaseScanLimit,
            "CUSTODY_SESSION_STATE_CAPACITY",
            "custody service case scan exceeds the finite bound");
        if (!entry.is_directory()) { continue; }
        if (!regular_file_exists(entry.path() / "acceptance.bin")) { ++count; }
    }
    return count;
}

} // namespace

namespace {

bool same_party(const CustodyParty& party,
    const HandoffBinding& binding) {
    return party.node == binding.node &&
        party.signing_generation == binding.signing_generation &&
        party.signing_public == binding.signing_public;
}

void require_capsule_route_binding(const RuntimeConfig& config,
    const CustodyEnvelope& envelope, const View capsule,
    const bool require_active_handoff_keys) {
    require_custody_capsule(envelope, capsule);
    const auto origin = peek_handoff_origin(capsule);
    const auto recipient = peek_handoff_recipient(capsule);
    require(same_party(envelope.route.front(), origin) &&
            same_party(envelope.route.back(), recipient),
        "CUSTODY_CAPSULE_ROUTE_MISMATCH",
        "capsule endpoints differ from the exact custody route");
    if (config.format_version >= 20U) {
        require_handoff_key_use(
            config.handoff_keys, origin, require_active_handoff_keys);
        require_handoff_key_use(
            config.handoff_keys, recipient, require_active_handoff_keys);
    }
}

bool local_route_party(const RuntimeConfig& config,
    const CustodyEnvelope& envelope) {
    return std::any_of(envelope.route.begin(), envelope.route.end(),
        [&](const CustodyParty& party) {
            return party.node == config.local_node &&
                party.signing_generation ==
                    config.local_identity_generation;
        });
}

std::size_t active_use_count(const StateSnapshot& snapshot,
    const CustodyGrantReference& reference) {
    return static_cast<std::size_t>(std::count_if(
        snapshot.custody_cases.begin(), snapshot.custody_cases.end(),
        [&](const DurableCustodyCase& custody) {
            return !custody.expired_ms && !custody.imported_ms &&
                std::find(custody.grants.begin(), custody.grants.end(),
                    reference) != custody.grants.end();
        }));
}

void require_registration_capacity(NodeState& state,
    const RuntimeConfig& config, const CustodyBundle& bundle) {
    const auto snapshot = state.snapshot();
    for (std::size_t hop = 0U; hop < bundle.grants.size(); ++hop) {
        const auto& reference = bundle.grants[hop];
        const auto& grant = resolve_custody_grant_reference(
            config, reference, bundle.envelope, hop, false);
        require(active_use_count(snapshot, reference) <
                grant.maximum_active_envelopes,
            "CUSTODY_GRANT_ACTIVE_LIMIT",
            "custody grant active-envelope quota reached");
    }
}

DurableCustodyCase require_case(NodeState& state,
    const datacube::Digest32& envelope_sha256) {
    const auto custody = state.custody_case(envelope_sha256);
    require(custody.has_value(), "CUSTODY_STATE_UNKNOWN",
        "custody envelope is not retained in durable state");
    return *custody;
}

std::uint64_t configuration_event(NodeState& state,
    const RuntimeConfig& config) {
    require(config.format_version >= 22U &&
            !config.runtime_generation.empty(),
        "CUSTODY_SESSION_POLICY_REQUIRED",
        "native custody service requires accepted V22 configuration");
    const auto canonical = canonical_runtime_config(config);
    return state.configuration_event_reference(config.runtime_generation,
        runtime_configuration_digest(canonical), canonical);
}

DurableCustodyCase import_bundle(NodeState& state,
    const RuntimeConfig& config, const CustodyBundle& bundle,
    const std::uint64_t config_event) {
    require(local_route_party(config, bundle.envelope),
        "CUSTODY_LOCAL_ROLE_REJECTED",
        "local node is not a named party in this custody route");
    require_capsule_route_binding(
        config, bundle.envelope, bundle.capsule, false);
    require_custody_registration_authority(
        config, bundle.envelope, bundle.grants, false);
    const auto envelope_sha256 = custody_bundle_envelope_sha256(bundle);
    const auto existing = state.custody_case(envelope_sha256);
    if (existing.has_value()) {
        require(existing->envelope.canonical == bundle.envelope.canonical &&
                existing->capsule == bundle.capsule &&
                existing->grants == bundle.grants,
            "CUSTODY_STATE_CONFLICT",
            "durable custody case differs from the received bundle");
    } else {
        require_registration_capacity(state, config, bundle);
        static_cast<void>(state.commit_custody_event(DurableCustodyEvent{
            .kind = DurableCustodyEventKind::registered,
            .envelope_sha256 = envelope_sha256,
            .configuration_event = config_event,
            .event_ms = 0U,
            .envelope = bundle.envelope.canonical,
            .capsule = bundle.capsule,
            .grants = bundle.grants,
            .record = {},
            .code = {},
            .detail = {},
            .imported_operation = std::nullopt,
        }));
    }
    for (const auto& encoded : bundle.records) {
        const auto record = decode_custody_record(bundle.envelope, encoded);
        require(record.hop_index < bundle.grants.size(),
            "CUSTODY_GRANT_REFERENCE_REJECTED",
            "custody record hop lacks an exact grant");
        static_cast<void>(resolve_custody_grant_reference(config,
            bundle.grants[record.hop_index], bundle.envelope,
            record.hop_index, false));
        static_cast<void>(state.commit_custody_event(DurableCustodyEvent{
            .kind = DurableCustodyEventKind::record,
            .envelope_sha256 = envelope_sha256,
            .configuration_event = config_event,
            .event_ms = 0U,
            .envelope = {},
            .capsule = {},
            .grants = {},
            .record = encoded,
            .code = {},
            .detail = {},
            .imported_operation = std::nullopt,
        }));
    }
    return require_case(state, envelope_sha256);
}

CustodyBundle bundle_from_case(const DurableCustodyCase& custody) {
    return CustodyBundle{
        .envelope = custody.envelope,
        .capsule = custody.capsule,
        .grants = custody.grants,
        .records = custody.records,
    };
}

std::size_t route_index(const CustodyEnvelope& envelope,
    const std::string_view node, const std::string_view generation) {
    const auto found = std::find_if(envelope.route.begin(),
        envelope.route.end(), [&](const CustodyParty& party) {
            return party.node == node &&
                party.signing_generation == generation;
        });
    require(found != envelope.route.end(), "CUSTODY_LOCAL_ROLE_REJECTED",
        "exact custody route party is absent");
    return static_cast<std::size_t>(
        std::distance(envelope.route.begin(), found));
}

bool last_record_is(const DurableCustodyCase& custody,
    const CustodyRecordKind kind, const std::size_t actor_index) {
    if (custody.records.empty()) { return false; }
    const auto record = decode_custody_record(
        custody.envelope, custody.records.back());
    return record.kind == kind &&
        record.actor_index == actor_index;
}

struct ServiceAuthority final {
    const RuntimeConfig* config{nullptr};
    const CustodySessionRule* rule{nullptr};
    const CustodyRelayGrant* grant{nullptr};
    const PeerKeyGeneration* peer_generation{nullptr};
    const PeerConfig* peer{nullptr};
    const PeerRouteConfig* route{nullptr};
    bool local_is_custodian{false};
    datacube::Digest32 configuration_sha256;
    datacube::Digest32 local_certificate_sha256;
    std::uint64_t configuration_event{0U};
    std::filesystem::path state_root;
};

enum class ServiceOperation : std::uint8_t {
    send = 1U,
    receive = 2U,
    inspect = 3U,
    export_retained = 4U,
    passive_receive = 5U,
    dispatch_source = 6U,
    owner_dispatch = 7U,
    owner_dispatch_recovery = 8U,
};

ServiceAuthority resolve_authority(NodeState& state,
    const RuntimeConfig& config,
    const CustodySessionServiceOptions& options,
    const ServiceOperation operation) {
    require(config.format_version >= 22U,
        "CUSTODY_SESSION_POLICY_REQUIRED",
        "native custody service requires V22 configuration");
    if (operation != ServiceOperation::passive_receive &&
        operation != ServiceOperation::dispatch_source &&
        operation != ServiceOperation::owner_dispatch &&
        operation != ServiceOperation::owner_dispatch_recovery) {
        require(local_control_allows(config.local_control,
                static_cast<std::uint32_t>(::geteuid()),
                LocalControlClass::maintenance),
            "LOCAL_CONTROL_DENIED",
            "explicit custody service commands require owner maintenance authority");
    }
    require(valid_generation_id(options.rule_id) &&
            options.rule_generation > 0U,
        "CUSTODY_SESSION_RULE_REQUIRED",
        "exact V22 service rule id and generation are required");
    const auto* rule = find_custody_session_rule(config.custody_sessions,
        options.rule_id, options.rule_generation);
    require(rule != nullptr, "CUSTODY_SESSION_RULE_UNKNOWN",
        "exact V22 service rule is absent from accepted configuration");
    const auto& grant = resolve_custody_session_grant(
        config.custody_relay, *rule, false);
    const bool local_is_custodian = config.local_node == grant.custodian &&
        config.local_identity_generation ==
            grant.custodian_signing_generation;
    const bool local_is_next_hop = config.local_node == grant.next_hop &&
        config.local_identity_generation ==
            grant.next_hop_signing_generation;
    require(local_is_custodian != local_is_next_hop,
        "CUSTODY_SESSION_LOCAL_ROLE_REJECTED",
        "local identity is not exactly one endpoint of the V22 transition");
    if (operation == ServiceOperation::send ||
        operation == ServiceOperation::owner_dispatch ||
        operation == ServiceOperation::owner_dispatch_recovery) {
        require(local_is_custodian,
            "CUSTODY_SESSION_LOCAL_ROLE_REJECTED",
            (operation == ServiceOperation::owner_dispatch ||
             operation == ServiceOperation::owner_dispatch_recovery) ?
                "owner dispatch requires the exact V21 custodian endpoint" :
                "send requires the exact V21 custodian endpoint");
    } else if (operation == ServiceOperation::receive ||
               operation == ServiceOperation::passive_receive) {
        require(local_is_next_hop,
            "CUSTODY_SESSION_LOCAL_ROLE_REJECTED",
            operation == ServiceOperation::passive_receive ?
                "passive daemon receipt requires the exact V21 next-hop endpoint" :
                "serve requires the exact V21 next-hop endpoint");
    } else if (operation == ServiceOperation::export_retained ||
               operation == ServiceOperation::dispatch_source) {
        require(local_is_next_hop,
            "CUSTODY_SESSION_LOCAL_ROLE_REJECTED",
            operation == ServiceOperation::dispatch_source ?
                "owner dispatch source requires the exact V21 next-hop endpoint" :
                "retained export requires the exact V21 next-hop endpoint");
    }

    const auto peer_node = local_is_custodian ?
        grant.next_hop : grant.custodian;
    const auto peer_generation_id = local_is_custodian ?
        grant.next_hop_signing_generation :
        grant.custodian_signing_generation;
    const auto* peer_generation = find_peer_generation(
        config, peer_node, peer_generation_id);
    require(peer_generation != nullptr,
        "CUSTODY_SESSION_PEER_REJECTED",
        "exact peer generation is absent from accepted configuration");
    require(peer_generation->state != KeyGenerationState::revoked,
        "CUSTODY_SESSION_PEER_REVOKED",
        "exact peer generation is revoked");
    const auto* peer = find_peer(config, peer_node);
    require(peer != nullptr, "CUSTODY_SESSION_PEER_REJECTED",
        "exact custody peer has no configured peer entry");

    const PeerRouteConfig* route = nullptr;
    if (operation == ServiceOperation::send ||
        operation == ServiceOperation::owner_dispatch) {
        require(valid_generation_id(options.route_id),
            "CUSTODY_SESSION_ROUTE_REQUIRED",
            "send requires one explicitly named configured route");
        route = find_peer_route(*peer, options.route_id);
        require(route != nullptr && route->state == PeerRouteState::enabled,
            "CUSTODY_SESSION_ROUTE_REJECTED",
            "explicit custody route is absent or disabled");
    } else {
        require(options.route_id.empty(),
            "CUSTODY_SESSION_ROUTE_REJECTED",
            (operation == ServiceOperation::receive ||
             operation == ServiceOperation::passive_receive) ?
                "receiver authority comes from the configured listener, not a route selector" :
                (operation == ServiceOperation::export_retained ||
                 operation == ServiceOperation::dispatch_source) ?
                    "retained source inspection does not select, discover, or fail over a route" :
                    operation == ServiceOperation::owner_dispatch_recovery ?
                        "retained dispatch recovery does not select, discover, or fail over a route" :
                        "status does not select, discover, or fail over a route");
    }

    const auto local_certificate_sha256 =
        tls_certificate_sha256(config.identity.certificate);
    const auto& expected_local_certificate = local_is_custodian ?
        rule->custodian_certificate_sha256 :
        rule->next_hop_certificate_sha256;
    require(equal_digest(local_certificate_sha256,
            expected_local_certificate),
        "CUSTODY_SESSION_LOCAL_CERTIFICATE_MISMATCH",
        "local certificate differs from the exact V22 commitment");
    const auto canonical = canonical_runtime_config(config);
    const auto configuration_sha256 =
        runtime_configuration_digest(canonical);
    require(!digest_is_zero(configuration_sha256),
        "CUSTODY_SESSION_CONFIGURATION_REJECTED",
        "accepted configuration digest is zero");

    ServiceAuthority authority{
        .config = &config,
        .rule = rule,
        .grant = &grant,
        .peer_generation = peer_generation,
        .peer = peer,
        .route = route,
        .local_is_custodian = local_is_custodian,
        .configuration_sha256 = configuration_sha256,
        .local_certificate_sha256 = local_certificate_sha256,
        .configuration_event = configuration_event(state, config),
        .state_root = service_root(config, *rule),
    };
    return authority;
}

void require_new_authority(const ServiceAuthority& authority) {
    require(authority.rule->state == CustodySessionRuleState::active,
        "CUSTODY_SESSION_RETIRED",
        "new custody offers require active V22 authority");
    static_cast<void>(resolve_custody_session_grant(
        authority.config->custody_relay, *authority.rule, true));
    require(now_ms() <= authority.rule->authority_expires_unix_ms,
        "CUSTODY_SESSION_AUTHORITY_EXPIRED",
        "V22 service authority has expired");
    require(authority.peer_generation->state == KeyGenerationState::active,
        "CUSTODY_SESSION_PEER_RETIRED",
        "new custody offers require the exact active peer generation");
}

void require_tls_peer(const ServiceAuthority& authority,
    const TlsSessionInfo& session) {
    const auto expected_node = authority.local_is_custodian ?
        authority.grant->next_hop : authority.grant->custodian;
    const auto expected_generation = authority.local_is_custodian ?
        authority.grant->next_hop_signing_generation :
        authority.grant->custodian_signing_generation;
    const auto& expected_certificate = authority.local_is_custodian ?
        authority.rule->next_hop_certificate_sha256 :
        authority.rule->custodian_certificate_sha256;
    require(session.peer_node == expected_node &&
            session.peer_generation == expected_generation,
        "CUSTODY_SESSION_AUTHENTICATED_PEER_MISMATCH",
        "authenticated TLS peer differs from the exact V21 endpoint");
    require(equal_digest(session.peer_certificate_sha256,
            expected_certificate),
        "CUSTODY_SESSION_PEER_CERTIFICATE_MISMATCH",
        "authenticated peer certificate differs from the exact V22 commitment");
}

struct ValidatedOffer final {
    SignedOffer offer;
    CustodyBundle bundle;
    CustodyProgress progress;
    std::size_t hop{0U};
};

ValidatedOffer validate_offer(const ServiceAuthority& authority,
    const CustodyTransferOffer& message,
    const bool permit_expired_duplicate) {
    auto offer = parse_offer(message.signed_offer);
    require(equal_digest(offer.request_id, message.request_id),
        "CUSTODY_SESSION_REQUEST_BINDING_REJECTED",
        "NOS1 operation id differs from the signed offer bytes");
    require(offer.rule_id == authority.rule->id &&
            offer.rule_generation == authority.rule->generation &&
            equal_digest(offer.rule_commitment,
                custody_session_rule_commitment(*authority.rule)),
        "CUSTODY_SESSION_RULE_MISMATCH",
        "signed offer differs from the exact accepted V22 rule");
    require(offer.grant == authority.rule->grant,
        "CUSTODY_SESSION_GRANT_MISMATCH",
        "signed offer differs from the exact accepted V21 grant reference");
    require(equal_digest(offer.custodian_certificate_sha256,
                authority.rule->custodian_certificate_sha256) &&
            equal_digest(offer.next_hop_certificate_sha256,
                authority.rule->next_hop_certificate_sha256),
        "CUSTODY_SESSION_CERTIFICATE_MISMATCH",
        "signed offer differs from the V22 certificate commitments");
    require(!digest_is_zero(offer.sender_configuration_sha256),
        "CUSTODY_SESSION_CONFIGURATION_REJECTED",
        "signed offer lacks a sender configuration commitment");
    require(valid_generation_id(offer.route_id),
        "CUSTODY_SESSION_ROUTE_REJECTED",
        "signed offer lacks an explicit canonical sender route");
    require(offer.bundle.size() <= authority.rule->maximum_bundle_bytes,
        "CUSTODY_SESSION_BUNDLE_LIMIT",
        "canonical custody bundle exceeds the V22 byte bound");
    require(offer.created_ms > 0U && offer.expires_ms > offer.created_ms &&
            offer.expires_ms - offer.created_ms <=
                authority.rule->maximum_transfer_window_ms &&
            offer.expires_ms <= authority.rule->authority_expires_unix_ms,
        "CUSTODY_SESSION_TIME_REJECTED",
        "signed offer exceeds the exact V22 transfer window");
    if (!permit_expired_duplicate) {
        require(now_ms() <= offer.expires_ms,
            "CUSTODY_SESSION_OFFER_EXPIRED",
            "custody offer expired before acceptance");
    }

    auto bundle = decode_custody_bundle(offer.bundle);
    require(bundle.grants.size() + 1U == bundle.envelope.route.size(),
        "CUSTODY_SESSION_GRANT_MISMATCH",
        "canonical custody bundle grant count is inconsistent");
    require(offer.expires_ms <= bundle.envelope.expires_ms,
        "CUSTODY_SESSION_TIME_REJECTED",
        "service offer outlives its custody envelope");
    auto progress = reconstruct_custody_progress(
        bundle.envelope, bundle.records);
    const auto hop = static_cast<std::size_t>(progress.current_party_index);
    require(progress.awaiting_acceptance &&
            hop + 1U < bundle.envelope.route.size() &&
            hop < bundle.grants.size(),
        "CUSTODY_SESSION_TRANSFER_REQUIRED",
        "bundle does not contain one unresolved signed transfer offer");
    require(bundle.grants[hop] == authority.rule->grant,
        "CUSTODY_SESSION_GRANT_MISMATCH",
        "unresolved custody hop differs from the exact V22 grant");
    static_cast<void>(resolve_custody_grant_reference(*authority.config,
        bundle.grants[hop], bundle.envelope, hop, false));
    const auto& custodian = bundle.envelope.route[hop];
    const auto& next_hop = bundle.envelope.route[hop + 1U];
    require(custodian.node == authority.grant->custodian &&
            custodian.signing_generation ==
                authority.grant->custodian_signing_generation &&
            next_hop.node == authority.grant->next_hop &&
            next_hop.signing_generation ==
                authority.grant->next_hop_signing_generation,
        "CUSTODY_SESSION_GRANT_MISMATCH",
        "signed bundle route differs from the exact V21 transition");
    const auto transfer = decode_custody_record(
        bundle.envelope, bundle.records.back());
    require(transfer.kind == CustodyRecordKind::transfer &&
            transfer.hop_index == hop && transfer.actor_index == hop &&
            transfer.event_ms == offer.created_ms,
        "CUSTODY_SESSION_TRANSFER_REQUIRED",
        "signed service offer does not bind its exact custody transfer record");
    verify_detached(custodian.signing_public, kOfferSignatureDomain,
        offer.unsigned_bytes, offer.signature);
    return ValidatedOffer{
        .offer = std::move(offer),
        .bundle = std::move(bundle),
        .progress = std::move(progress),
        .hop = hop,
    };
}

SignedAcceptance validate_acceptance(const ServiceAuthority& authority,
    const SignedOffer& offer, const CustodyBundle& bundle,
    const View wire) {
    auto acceptance = parse_acceptance(wire);
    require(equal_digest(acceptance.request_id, offer.request_id) &&
            equal_digest(acceptance.offer_sha256,
                datacube::sha256(offer.wire)),
        "CUSTODY_SESSION_ACCEPTANCE_BINDING_REJECTED",
        "acceptance does not bind the exact retained offer");
    require(acceptance.rule_id == authority.rule->id &&
            acceptance.rule_generation == authority.rule->generation &&
            equal_digest(acceptance.rule_commitment,
                custody_session_rule_commitment(*authority.rule)) &&
            acceptance.grant == authority.rule->grant,
        "CUSTODY_SESSION_ACCEPTANCE_BINDING_REJECTED",
        "acceptance differs from the exact V22/V21 authority");
    require(equal_digest(acceptance.custodian_certificate_sha256,
                authority.rule->custodian_certificate_sha256) &&
            equal_digest(acceptance.next_hop_certificate_sha256,
                authority.rule->next_hop_certificate_sha256) &&
            !digest_is_zero(acceptance.receiver_configuration_sha256),
        "CUSTODY_SESSION_ACCEPTANCE_BINDING_REJECTED",
        "acceptance lacks exact endpoint or configuration commitments");
    auto progress = reconstruct_custody_progress(
        bundle.envelope, bundle.records);
    const auto hop = static_cast<std::size_t>(progress.current_party_index);
    require(progress.awaiting_acceptance &&
            hop + 1U < bundle.envelope.route.size(),
        "CUSTODY_SESSION_ACCEPTANCE_REJECTED",
        "retained offer no longer awaits one exact acceptance");
    const auto record = decode_custody_record(
        bundle.envelope, acceptance.record);
    require(record.kind == CustodyRecordKind::acceptance &&
            record.hop_index == hop &&
            record.actor_index == hop + 1U &&
            record.counterparty_index == hop &&
            record.event_ms == acceptance.accepted_ms,
        "CUSTODY_SESSION_ACCEPTANCE_REJECTED",
        "acceptance record does not match the exact pending hop");
    static_cast<void>(apply_custody_record(
        bundle.envelope, record, progress));
    verify_detached(bundle.envelope.route[hop + 1U].signing_public,
        kAcceptanceSignatureDomain, acceptance.unsigned_bytes,
        acceptance.signature);
    return acceptance;
}

void commit_acceptance(NodeState& state,
    const ServiceAuthority& authority, const CustodyBundle& bundle,
    const SignedAcceptance& acceptance) {
    const auto envelope_sha256 = custody_bundle_envelope_sha256(bundle);
    static_cast<void>(state.commit_custody_event(DurableCustodyEvent{
        .kind = DurableCustodyEventKind::record,
        .envelope_sha256 = envelope_sha256,
        .configuration_event = authority.configuration_event,
        .event_ms = 0U,
        .envelope = {},
        .capsule = {},
        .grants = {},
        .record = acceptance.record,
        .code = {},
        .detail = {},
        .imported_operation = std::nullopt,
    }));
}

void record_uncertainty(NodeState& state,
    const ServiceAuthority& authority,
    const datacube::Digest32& envelope_sha256,
    const std::string_view detail) {
    const auto custody = state.custody_case(envelope_sha256);
    if (!custody || !custody->progress.awaiting_acceptance ||
        custody->uncertainties.size() >= kDurableCustodyUncertaintyLimit) {
        return;
    }
    static_cast<void>(state.commit_custody_event(DurableCustodyEvent{
        .kind = DurableCustodyEventKind::uncertainty,
        .envelope_sha256 = envelope_sha256,
        .configuration_event = authority.configuration_event,
        .event_ms = now_ms(),
        .envelope = {},
        .capsule = {},
        .grants = {},
        .record = {},
        .code = "CUSTODY_SESSION_UNRESOLVED",
        .detail = bounded_detail(detail),
        .imported_operation = std::nullopt,
    }));
}

std::string result_json(const std::string_view status,
    const SignedOffer& offer, const datacube::Digest32& envelope_sha256,
    const std::uint64_t attempts, const bool acceptance_durable,
    const std::string_view detail = {}) {
    std::string result =
        "{\"format\":\"NATRAV_NATIVE_CUSTODY_SESSION_RESULT_V1\"";
    result += ",\"status\":" + json_string(status);
    result += ",\"request_id\":" +
        json_string(operation_id_text(offer.request_id));
    result += ",\"envelope_sha256\":" +
        json_string(operation_id_text(envelope_sha256));
    result += ",\"attempts\":" + std::to_string(attempts);
    result += ",\"acceptance_durable\":" +
        std::string(acceptance_durable ? "true" : "false");
    result += ",\"automatic_route_relay\":false";
    result += ",\"application_delivery_inferred\":false";
    if (!detail.empty()) {
        result += ",\"detail\":" + json_string(bounded_detail(detail));
    }
    result += "}";
    return result;
}

} // namespace

namespace {

struct PreparedSend final {
    SignedOffer offer;
    CustodyBundle bundle;
    datacube::Digest32 envelope_sha256;
    std::filesystem::path directory;
};

std::uint64_t bounded_expiry(const std::uint64_t created,
    const std::uint64_t window, const std::uint64_t authority_expiry,
    const std::uint64_t envelope_expiry) {
    const auto window_expiry = window >
            std::numeric_limits<std::uint64_t>::max() - created ?
        std::numeric_limits<std::uint64_t>::max() : created + window;
    return std::min({window_expiry, authority_expiry, envelope_expiry});
}

PreparedSend prepare_send_bytes(NodeState& state,
    const ServiceAuthority& authority,
    const View input,
    const std::string_view route_id) {
    require(!input.empty() &&
            input.size() <= authority.rule->maximum_bundle_bytes,
        "CUSTODY_SESSION_BUNDLE_REQUIRED",
        "send requires one explicit bounded canonical custody bundle");
    const auto input_bundle = decode_custody_bundle(input);
    const auto envelope_sha256 =
        custody_bundle_envelope_sha256(input_bundle);

    const auto existing_request = request_for_envelope(
        authority.state_root, envelope_sha256, true);
    if (existing_request.has_value()) {
        const auto directory = case_path(
            authority.state_root, *existing_request);
        const auto wire = read_regular_file(directory / "offer.bin",
            kMaximumCustodySessionWireBytes);
        const CustodyTransferOffer message{
            .request_id = *existing_request,
            .signed_offer = wire,
        };
        auto validated = validate_offer(authority, message, true);
        require(validated.offer.route_id == route_id,
            "CUSTODY_SESSION_ROUTE_CONFLICT",
            "retained custody offer is bound to a different explicit route");
        require(custody_bundle_envelope_sha256(validated.bundle) ==
                envelope_sha256,
            "CUSTODY_SESSION_REPLAY_CONFLICT",
            "retained custody offer differs from the requested envelope");
        static_cast<void>(import_bundle(state, *authority.config,
            validated.bundle, authority.configuration_event));
        return PreparedSend{
            .offer = std::move(validated.offer),
            .bundle = std::move(validated.bundle),
            .envelope_sha256 = envelope_sha256,
            .directory = directory,
        };
    }

    require_new_authority(authority);
    require(unresolved_case_count(authority.state_root) <
            authority.rule->maximum_pending_cases,
        "CUSTODY_SESSION_PENDING_LIMIT",
        "finite sender pending-case capacity is exhausted");
    auto custody = import_bundle(state, *authority.config, input_bundle,
        authority.configuration_event);
    const auto local_index = route_index(custody.envelope,
        authority.config->local_node,
        authority.config->local_identity_generation);
    require(local_index == custody.progress.current_party_index &&
            local_index + 1U < custody.envelope.route.size() &&
            local_index < custody.grants.size() &&
            custody.grants[local_index] == authority.rule->grant,
        "CUSTODY_SESSION_LOCAL_ROLE_REJECTED",
        "local node is not the exact current custodian for this V22 transition");
    require(!custody.expired_ms && !custody.imported_ms &&
            now_ms() <= custody.envelope.expires_ms,
        "CUSTODY_SESSION_STATE_TERMINAL",
        "terminal or expired custody case cannot originate an offer");
    require_custody_party_authorized(*authority.config,
        custody.envelope.route[local_index], true);
    require_custody_party_authorized(*authority.config,
        custody.envelope.route[local_index + 1U], true);
    static_cast<void>(resolve_custody_grant_reference(*authority.config,
        custody.grants[local_index], custody.envelope, local_index, true));

    if (!custody.progress.awaiting_acceptance) {
        auto signer = load_handoff_signer(*authority.config);
        const auto transfer = make_custody_transfer(custody.envelope,
            custody.progress, now_ms(), signer.get());
        static_cast<void>(state.commit_custody_event(DurableCustodyEvent{
            .kind = DurableCustodyEventKind::record,
            .envelope_sha256 = custody.envelope_sha256,
            .configuration_event = authority.configuration_event,
            .event_ms = 0U,
            .envelope = {},
            .capsule = {},
            .grants = {},
            .record = transfer.canonical,
            .code = {},
            .detail = {},
            .imported_operation = std::nullopt,
        }));
        custody = require_case(state, envelope_sha256);
    } else {
        require(last_record_is(custody, CustodyRecordKind::transfer,
                local_index),
            "CUSTODY_SESSION_TRANSFER_CONFLICT",
            "a different custody transfer is already unresolved");
    }

    auto bundle = bundle_from_case(custody);
    const auto encoded_bundle = encode_custody_bundle(bundle);
    require(encoded_bundle.size() <= authority.rule->maximum_bundle_bytes,
        "CUSTODY_SESSION_BUNDLE_LIMIT",
        "bundle with durable transfer exceeds the V22 byte bound");
    const auto transfer = decode_custody_record(
        custody.envelope, custody.records.back());
    const auto expires = bounded_expiry(transfer.event_ms,
        authority.rule->maximum_transfer_window_ms,
        authority.rule->authority_expires_unix_ms,
        custody.envelope.expires_ms);
    require(expires > transfer.event_ms,
        "CUSTODY_SESSION_AUTHORITY_EXPIRED",
        "no positive V22 transfer window remains");
    auto signer = load_handoff_signer(*authority.config);
    auto offer = build_offer(*authority.rule,
        authority.configuration_sha256, route_id,
        transfer.event_ms, expires, encoded_bundle,
        custody.envelope.route[local_index], signer.get());
    const auto directory = case_path(authority.state_root, offer.request_id);
    custody_session_test_pause("BEFORE_OFFER_PUBLICATION");
    ensure_private_directory(directory);
    persist_exact(directory / "offer.bin", offer.wire,
        kMaximumCustodySessionWireBytes,
        "request identifier collision carries different offer bytes");
    custody_session_test_pause("AFTER_OFFER_PUBLICATION");
    atomic_write_text(directory / "envelope_sha256",
        operation_id_text(envelope_sha256) + "\n");
    atomic_write_text(directory / "attempts", "0\n");
    atomic_write_text(directory / "state",
        "OFFER_COMMITTED_AWAITING_ACCEPTANCE\n");
    atomic_write_text(envelope_index_path(
        authority.state_root, envelope_sha256),
        operation_id_text(offer.request_id) + "\n");
    return PreparedSend{
        .offer = std::move(offer),
        .bundle = std::move(bundle),
        .envelope_sha256 = envelope_sha256,
        .directory = directory,
    };
}

PreparedSend prepare_send(NodeState& state,
    const ServiceAuthority& authority,
    const CustodySessionServiceOptions& options) {
    require(!options.bundle.empty(), "CUSTODY_SESSION_BUNDLE_REQUIRED",
        "send requires one explicit canonical custody bundle");
    const auto input = read_handoff_file(options.bundle,
        authority.rule->maximum_bundle_bytes);
    return prepare_send_bytes(state, authority, input, options.route_id);
}

PreparedSend prepared_from_request(NodeState& state,
    const ServiceAuthority& authority,
    const datacube::Digest32& request_id,
    const std::string_view route_id) {
    const auto directory = case_path(authority.state_root, request_id);
    const auto wire = read_regular_file(directory / "offer.bin",
        kMaximumCustodySessionWireBytes);
    const CustodyTransferOffer message{
        .request_id = request_id,
        .signed_offer = wire,
    };
    auto validated = validate_offer(authority, message, true);
    require(validated.offer.route_id == route_id,
        "CUSTODY_SESSION_ROUTE_CONFLICT",
        "retained custody offer is bound to a different explicit route");
    const auto envelope_sha256 =
        custody_bundle_envelope_sha256(validated.bundle);
    static_cast<void>(import_bundle(state, *authority.config,
        validated.bundle, authority.configuration_event));
    return PreparedSend{
        .offer = std::move(validated.offer),
        .bundle = std::move(validated.bundle),
        .envelope_sha256 = envelope_sha256,
        .directory = directory,
    };
}

CustodySessionServiceResult accepted_from_retained(
    NodeState& state, const ServiceAuthority& authority,
    const PreparedSend& prepared) {
    const auto acceptance_wire = read_regular_file(
        prepared.directory / "acceptance.bin",
        kMaximumCustodySessionWireBytes);
    const auto acceptance = validate_acceptance(authority,
        prepared.offer, prepared.bundle, acceptance_wire);
    commit_acceptance(state, authority, prepared.bundle, acceptance);
    atomic_write_text(prepared.directory / "state", "ACCEPTED\n");
    const auto attempts = read_counter(prepared.directory / "attempts");
    return CustodySessionServiceResult{
        .status = 0,
        .json = result_json("ACCEPTED", prepared.offer,
            prepared.envelope_sha256, attempts, true,
            "byte-identical retained acceptance reconstructed"),
    };
}

CustodyTransferAcceptance receive_offer(NodeState& state,
    const ServiceAuthority& authority, const TlsSessionInfo& session,
    const CustodyTransferOffer& message) {
    require_tls_peer(authority, session);
    const auto directory = case_path(authority.state_root,
        message.request_id);
    const bool retained_offer = regular_file_exists(directory / "offer.bin");
    if (retained_offer) {
        persist_exact(directory / "offer.bin", message.signed_offer,
            kMaximumCustodySessionWireBytes,
            "duplicate request id carries different offer bytes");
    }
    auto validated = validate_offer(
        authority, message, retained_offer);
    const auto envelope_sha256 =
        custody_bundle_envelope_sha256(validated.bundle);
    const auto envelope_request = request_for_envelope(
        authority.state_root, envelope_sha256, true);
    require(!envelope_request.has_value() ||
            equal_digest(*envelope_request, message.request_id),
        "CUSTODY_SESSION_ENVELOPE_REPLAY_CONFLICT",
        "one custody envelope is already bound to a different request id");

    if (regular_file_exists(directory / "acceptance.bin")) {
        require(authority.rule->state != CustodySessionRuleState::revoked &&
                authority.grant->state != CustodyRelayGrantState::revoked,
            "CUSTODY_SESSION_REVOKED",
            "revoked authority does not return retained acceptance bytes");
        const auto wire = read_regular_file(directory / "acceptance.bin",
            kMaximumCustodySessionWireBytes);
        const auto acceptance = validate_acceptance(authority,
            validated.offer, validated.bundle, wire);
        static_cast<void>(import_bundle(state, *authority.config,
            validated.bundle, authority.configuration_event));
        commit_acceptance(state, authority, validated.bundle, acceptance);
        atomic_write_text(directory / "state", "ACCEPTED\n");
        return CustodyTransferAcceptance{
            .request_id = message.request_id,
            .signed_acceptance = wire,
        };
    }

    require_new_authority(authority);
    require(now_ms() <= validated.offer.expires_ms,
        "CUSTODY_SESSION_OFFER_EXPIRED",
        "custody offer expired before receiver acceptance");
    if (!retained_offer) {
        require(unresolved_case_count(authority.state_root) <
                authority.rule->maximum_pending_cases,
            "CUSTODY_SESSION_PENDING_LIMIT",
            "finite receiver pending-case capacity is exhausted");
        ensure_private_directory(directory);
        persist_exact(directory / "offer.bin", message.signed_offer,
            kMaximumCustodySessionWireBytes,
            "request identifier collision carries different offer bytes");
        atomic_write_text(directory / "envelope_sha256",
            operation_id_text(envelope_sha256) + "\n");
        atomic_write_text(directory / "state",
            "OFFER_DURABLE_BEFORE_ACCEPTANCE\n");
        atomic_write_text(envelope_index_path(
            authority.state_root, envelope_sha256),
            operation_id_text(message.request_id) + "\n");
    }

    auto custody = import_bundle(state, *authority.config,
        validated.bundle, authority.configuration_event);
    const auto local_index = route_index(custody.envelope,
        authority.config->local_node,
        authority.config->local_identity_generation);
    const auto hop = static_cast<std::size_t>(
        custody.progress.current_party_index);
    require(custody.progress.awaiting_acceptance &&
            local_index == hop + 1U &&
            hop < custody.grants.size() &&
            custody.grants[hop] == authority.rule->grant,
        "CUSTODY_SESSION_LOCAL_ROLE_REJECTED",
        "receiver is not the exact next hop for the unresolved transfer");
    require_custody_party_authorized(*authority.config,
        custody.envelope.route[local_index], true);
    static_cast<void>(resolve_custody_grant_reference(*authority.config,
        custody.grants[hop], custody.envelope, hop, true));

    auto signer = load_handoff_signer(*authority.config);
    const auto record = make_custody_acceptance(custody.envelope,
        custody.progress, now_ms(), signer.get());
    auto acceptance = build_acceptance(validated.offer,
        *authority.rule, authority.configuration_sha256, record,
        custody.envelope.route[local_index], signer.get());

    // Crash boundary: the byte-identical signed acceptance is durable before
    // any native session response. A retry repairs/replays the journal record.
    custody_session_test_pause("BEFORE_RECEIVER_ACCEPTANCE_PUBLICATION");
    persist_exact(directory / "acceptance.bin", acceptance.wire,
        kMaximumCustodySessionWireBytes,
        "durable acceptance differs from the reconstructed acceptance");
    custody_session_test_pause("AFTER_RECEIVER_ACCEPTANCE_PUBLICATION");
    atomic_write_text(directory / "state",
        "ACCEPTANCE_DURABLE_BEFORE_REPLY\n");
    custody_session_test_pause("BEFORE_RECEIVER_JOURNAL_COMMIT");
    commit_acceptance(state, authority, validated.bundle, acceptance);
    custody_session_test_pause("AFTER_RECEIVER_JOURNAL_COMMIT");
    atomic_write_text(directory / "state", "ACCEPTED\n");
    return CustodyTransferAcceptance{
        .request_id = message.request_id,
        .signed_acceptance = std::move(acceptance.wire),
    };
}

CustodyBundle retained_dispatch_source(NodeState& state,
    const ServiceAuthority& authority,
    const datacube::Digest32& request_id) {
    require(authority.rule->state != CustodySessionRuleState::revoked &&
            authority.grant->state != CustodyRelayGrantState::revoked,
        "CUSTODY_SESSION_REVOKED",
        "revoked source authority cannot support owner dispatch");
    const auto directory = case_path(authority.state_root, request_id);
    const auto offer_wire = read_regular_file(directory / "offer.bin",
        kMaximumCustodySessionWireBytes);
    const CustodyTransferOffer message{
        .request_id = request_id,
        .signed_offer = offer_wire,
    };
    auto validated = validate_offer(authority, message, true);
    const auto acceptance_wire = read_regular_file(
        directory / "acceptance.bin", kMaximumCustodySessionWireBytes);
    const auto acceptance = validate_acceptance(authority,
        validated.offer, validated.bundle, acceptance_wire);

    const auto envelope_sha256 =
        custody_bundle_envelope_sha256(validated.bundle);
    const auto custody = require_case(state, envelope_sha256);
    const auto local_index = route_index(custody.envelope,
        authority.config->local_node,
        authority.config->local_identity_generation);
    const bool retained_at_local_custodian =
        !custody.progress.awaiting_acceptance &&
        custody.progress.current_party_index == local_index &&
        last_record_is(custody, CustodyRecordKind::acceptance,
            local_index);
    // A prior explicit dispatch may already have durably appended the one
    // local transfer record while its acceptance remains unresolved.  A fresh
    // owner request is allowed to spend one further V22 attempt against that
    // same retained offer; it must not require or manufacture a second
    // first-hop acceptance.
    const bool retained_unresolved_local_transfer =
        custody.progress.awaiting_acceptance &&
        custody.progress.current_party_index == local_index &&
        last_record_is(custody, CustodyRecordKind::transfer,
            local_index);
    require(!custody.expired_ms && !custody.imported_ms &&
            now_ms() <= custody.envelope.expires_ms &&
            local_index > 0U &&
            local_index + 1U < custody.envelope.route.size() &&
            (retained_at_local_custodian ||
                retained_unresolved_local_transfer),
        "CUSTODY_SESSION_LOCAL_ROLE_REJECTED",
        "owner dispatch requires the exact current nonterminal custodian");
    const auto accepted_record_index = validated.bundle.records.size();
    const auto expected_records = accepted_record_index +
        (retained_unresolved_local_transfer ? 2U : 1U);
    require(custody.envelope.canonical ==
                validated.bundle.envelope.canonical &&
            custody.capsule == validated.bundle.capsule &&
            custody.grants == validated.bundle.grants &&
            custody.records.size() == expected_records &&
            std::equal(validated.bundle.records.begin(),
                validated.bundle.records.end(), custody.records.begin()) &&
            custody.records[accepted_record_index] == acceptance.record,
        "CUSTODY_SESSION_REPLAY_CONFLICT",
        "authenticated source case differs from its exact offer and acceptance");
    return bundle_from_case(custody);
}

CustodySessionServiceResult perform_committed_attempt(
    NodeState& state, TlsContext& tls,
    const ServiceAuthority& authority,
    const PreparedSend& prepared,
    const std::uint64_t attempts) {
    require(authority.route != nullptr,
        "CUSTODY_SESSION_ROUTE_REQUIRED",
        "a newly committed dispatch attempt requires its exact route");
    try {
        auto session = OutboundPeerSession::open(tls,
            authority.config->local_node, authority.grant->next_hop,
            authority.grant->next_hop_signing_generation,
            authority.peer_generation->state,
            authority.peer_generation->spki_sha256,
            authority.route->locator, prepared.offer.request_id,
            authority.config->io, authority.config->sessions);
        require_tls_peer(authority, session.tls_session());
        const ApplicationMessage request = CustodyTransferOffer{
            .request_id = prepared.offer.request_id,
            .signed_offer = prepared.offer.wire,
        };
        const auto response = session.exchange_message(
            prepared.offer.request_id, request, authority.config->io);
        if (const auto* error = std::get_if<ProtocolError>(&response)) {
            app_fail(error->code, error->detail);
        }
        const auto* accepted =
            std::get_if<CustodyTransferAcceptance>(&response);
        require(accepted != nullptr &&
                equal_digest(accepted->request_id,
                    prepared.offer.request_id),
            "CUSTODY_SESSION_RESPONSE_REJECTED",
            "native session did not return the exact custody acceptance");
        const auto acceptance = validate_acceptance(authority,
            prepared.offer, prepared.bundle,
            accepted->signed_acceptance);
        custody_session_test_pause("BEFORE_SENDER_ACCEPTANCE_PUBLICATION");
        persist_exact(prepared.directory / "acceptance.bin",
            acceptance.wire, kMaximumCustodySessionWireBytes,
            "received acceptance differs from durable acceptance");
        custody_session_test_pause("AFTER_SENDER_ACCEPTANCE_PUBLICATION");
        atomic_write_text(prepared.directory / "state",
            "ACCEPTANCE_DURABLE_BEFORE_LOCAL_COMMIT\n");
        custody_session_test_pause("BEFORE_SENDER_JOURNAL_COMMIT");
        commit_acceptance(state, authority, prepared.bundle, acceptance);
        custody_session_test_pause("AFTER_SENDER_JOURNAL_COMMIT");
        atomic_write_text(prepared.directory / "state", "ACCEPTED\n");
        atomic_write_text(prepared.directory / "last_error", "NONE\n");
        static_cast<void>(session.close_cleanly(authority.config->io));
        return CustodySessionServiceResult{
            .status = 0,
            .json = result_json("ACCEPTED", prepared.offer,
                prepared.envelope_sha256, attempts, true),
        };
    } catch (const std::exception& error) {
        const auto detail = bounded_detail(error.what());
        atomic_write_text(prepared.directory / "last_error", detail + "\n");
        atomic_write_text(prepared.directory / "state",
            "UNRESOLVED_AFTER_ATTEMPT\n");
        record_uncertainty(state, authority,
            prepared.envelope_sha256, detail);
        return CustodySessionServiceResult{
            .status = 4,
            .json = result_json("UNRESOLVED", prepared.offer,
                prepared.envelope_sha256, attempts, false, detail),
        };
    }
}

struct OwnerDispatchRecord final {
    datacube::Digest32 dispatch_request_id;
    datacube::Digest32 request_commitment;
    std::string activation_id;
    std::uint64_t activation_generation{0U};
    datacube::Digest32 activation_commitment;
    datacube::Digest32 receiver_request_id;
    datacube::Digest32 outbound_request_id;
    std::uint64_t attempt{0U};
};

std::string owner_dispatch_request_text(
    const CustodyOwnerDispatchRequest& request) {
    require(valid_generation_id(request.activation_id) &&
            request.activation_generation > 0U &&
            !digest_is_zero(request.receiver_request_id) &&
            !digest_is_zero(request.dispatch_request_id) &&
            !request.reason.empty() && request.reason.size() <= 256U &&
            std::all_of(request.reason.begin(), request.reason.end(),
                [](const char raw) {
                    const auto value = static_cast<unsigned char>(raw);
                    return value == 9U || (value >= 32U && value <= 126U);
                }),
        "CUSTODY_DISPATCH_REQUEST_REJECTED",
        "owner dispatch request fields are outside their canonical bounds");
    return "NATRAV_CUSTODY_OWNER_DISPATCH_REQUEST_V1\nactivation_id=" +
        request.activation_id + "\nactivation_generation=" +
        std::to_string(request.activation_generation) +
        "\nreceiver_request_id=" +
        operation_id_text(request.receiver_request_id) +
        "\ndispatch_request_id=" +
        operation_id_text(request.dispatch_request_id) +
        "\nreason=" + request.reason + "\n";
}

datacube::Digest32 owner_dispatch_request_commitment(
    const CustodyOwnerDispatchRequest& request) {
    const auto text = owner_dispatch_request_text(request);
    return datacube::sha256(View(
        reinterpret_cast<const std::uint8_t*>(text.data()), text.size()));
}

std::string owner_dispatch_record_text(const OwnerDispatchRecord& record) {
    return "NATRAV_CUSTODY_OWNER_DISPATCH_RECORD_V1\n"
        "dispatch_request_id=" + operation_id_text(record.dispatch_request_id) +
        "\nrequest_commitment_sha256=" +
            operation_id_text(record.request_commitment) +
        "\nactivation_id=" + record.activation_id +
        "\nactivation_generation=" +
            std::to_string(record.activation_generation) +
        "\nactivation_commitment_sha256=" +
            operation_id_text(record.activation_commitment) +
        "\nreceiver_request_id=" +
            operation_id_text(record.receiver_request_id) +
        "\noutbound_request_id=" +
            operation_id_text(record.outbound_request_id) +
        "\nattempt=" + std::to_string(record.attempt) + "\n";
}

OwnerDispatchRecord parse_owner_dispatch_record(const Bytes& bytes) {
    require(bytes.size() <= kStateTextLimit,
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "owner dispatch record exceeds its finite bound");
    const std::string text(bytes.begin(), bytes.end());
    std::size_t offset = 0U;
    const auto field = [&](const std::string_view prefix) {
        const auto end = text.find('\n', offset);
        require(end != std::string::npos,
            "CUSTODY_DISPATCH_STATE_REJECTED",
            "owner dispatch record is truncated");
        const auto line = std::string_view(text).substr(offset, end - offset);
        require(line.starts_with(prefix),
            "CUSTODY_DISPATCH_STATE_REJECTED",
            "owner dispatch record field order is not canonical");
        offset = end + 1U;
        return std::string(line.substr(prefix.size()));
    };
    require(field("NATRAV_CUSTODY_OWNER_DISPATCH_RECORD_V1").empty(),
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "owner dispatch record header is invalid");
    OwnerDispatchRecord record;
    record.dispatch_request_id = parse_operation_id(
        field("dispatch_request_id="));
    record.request_commitment = parse_operation_id(
        field("request_commitment_sha256="));
    record.activation_id = field("activation_id=");
    record.activation_generation = parse_u64(
        field("activation_generation="), "dispatch activation generation",
        1U, kCustodyDispatchActivationPerIdLimit);
    record.activation_commitment = parse_operation_id(
        field("activation_commitment_sha256="));
    record.receiver_request_id = parse_operation_id(
        field("receiver_request_id="));
    record.outbound_request_id = parse_operation_id(
        field("outbound_request_id="));
    record.attempt = parse_u64(field("attempt="),
        "owner dispatch attempt", 0U, kCustodySessionMaximumAttempts);
    require(offset == text.size() && valid_generation_id(record.activation_id) &&
            owner_dispatch_record_text(record) == text,
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "owner dispatch record is not canonical");
    return record;
}

std::filesystem::path dispatch_directory(
    const PreparedSend& prepared) {
    const auto directory = prepared.directory / "dispatches";
    ensure_private_directory(directory);
    return directory;
}

std::filesystem::path dispatch_record_path(
    const PreparedSend& prepared,
    const datacube::Digest32& dispatch_request_id) {
    return dispatch_directory(prepared) /
        (operation_id_text(dispatch_request_id) + ".record");
}

std::filesystem::path dispatch_result_path(
    const PreparedSend& prepared,
    const datacube::Digest32& dispatch_request_id) {
    return dispatch_directory(prepared) /
        (operation_id_text(dispatch_request_id) + ".result");
}

std::filesystem::path dispatch_index_path(
    const std::filesystem::path& root,
    const datacube::Digest32& dispatch_request_id) {
    return root / "dispatch-index" / operation_id_text(dispatch_request_id);
}

// Read-only owner reconciliation deliberately has its own path validation.
// service_root(), dispatch_directory(), prepared_from_request(), and the legacy
// find_dispatch_outbound_request() helper may create or repair derived state;
// none of them is authority for an observation request.
bool private_directory_exists_read_only(
    const std::filesystem::path& directory) {
    struct stat status {};
    if (::lstat(directory.c_str(), &status) != 0) {
        if (errno == ENOENT) { return false; }
        app_fail("CUSTODY_DISPATCH_STATE_REJECTED",
            datacube::errno_detail("custody dispatch directory stat", errno));
    }
    require(S_ISDIR(status.st_mode) && status.st_uid == ::geteuid() &&
            (status.st_mode & 0077U) == 0U,
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "custody dispatch observation rejects symlink, foreign, or non-private directories");
    return true;
}

std::optional<std::filesystem::path> service_root_read_only(
    const RuntimeConfig& config, const CustodySessionRule& rule) {
    const auto base = config.state_directory / "custody-session-v1";
    if (!private_directory_exists_read_only(base)) { return std::nullopt; }
    const auto id = base / rule.id;
    if (!private_directory_exists_read_only(id)) { return std::nullopt; }
    const auto root = id / std::to_string(rule.generation);
    if (!private_directory_exists_read_only(root)) { return std::nullopt; }
    require(private_directory_exists_read_only(root / "cases") &&
            private_directory_exists_read_only(root / "envelope-index") &&
            private_directory_exists_read_only(root / "dispatch-index"),
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "existing custody service root lacks its complete owner-private layout");
    return root;
}

struct DispatchObservationAuthority final {
    const RuntimeConfig* config{nullptr};
    const CustodyDispatchActivation* activation{nullptr};
    const CustodyReceiverActivation* receiver{nullptr};
    const CustodySessionRule* outbound_rule{nullptr};
    const CustodyRelayGrant* outbound_grant{nullptr};
    const PeerKeyGeneration* peer_generation{nullptr};
    const PeerConfig* peer{nullptr};
    const PeerRouteConfig* route{nullptr};
    datacube::Digest32 activation_commitment;
    datacube::Digest32 configuration_sha256;
    datacube::Digest32 local_certificate_sha256;
    bool activation_expired{false};
    std::optional<std::filesystem::path> state_root;
};

DispatchObservationAuthority resolve_dispatch_observation_authority(
    const RuntimeConfig& config, const std::string_view activation_id,
    const std::uint64_t activation_generation) {
    require(config.format_version >= 24U,
        "CUSTODY_DISPATCH_POLICY_VERSION_REQUIRED",
        "owner dispatch reconciliation requires the current accepted V24 configuration");
    require(valid_generation_id(activation_id) && activation_generation > 0U,
        "CUSTODY_DISPATCH_REQUEST_REJECTED",
        "exact V24 activation id and generation are required");
    const auto* activation = find_custody_dispatch_activation(
        config.custody_dispatch, activation_id, activation_generation);
    require(activation != nullptr,
        "CUSTODY_DISPATCH_ACTIVATION_UNKNOWN",
        "exact V24 owner-dispatch activation is absent from the current accepted configuration");
    const auto& receiver = resolve_custody_dispatch_receiver_activation(
        config.custody_receivers, *activation, false);
    const auto& outbound_rule = resolve_custody_dispatch_outbound_rule(
        config.custody_sessions, *activation, false);
    const auto& outbound_grant = resolve_custody_session_grant(
        config.custody_relay, outbound_rule, false);
    require(config.local_node == outbound_grant.custodian &&
            config.local_identity_generation ==
                outbound_grant.custodian_signing_generation,
        "CUSTODY_DISPATCH_LOCAL_ROLE_REJECTED",
        "dispatch reconciliation requires the exact local V21 custodian endpoint");

    const auto* peer_generation = find_peer_generation(config,
        outbound_grant.next_hop,
        outbound_grant.next_hop_signing_generation);
    require(peer_generation != nullptr,
        "CUSTODY_DISPATCH_PEER_REJECTED",
        "exact outbound V21 peer generation is absent from accepted configuration");
    const auto* peer = find_peer(config, outbound_grant.next_hop);
    require(peer != nullptr,
        "CUSTODY_DISPATCH_PEER_REJECTED",
        "exact outbound V21 peer is absent from accepted configuration");
    const auto* route = find_peer_route(*peer, activation->route_id);
    if (activation->state == CustodyDispatchActivationState::active) {
        require(route != nullptr && route->state == PeerRouteState::enabled &&
                equal_digest(custody_dispatch_route_commitment(
                        peer->node_id, route->route_id,
                        transport_locator_text(route->locator), route->priority),
                    activation->route_commitment),
            "CUSTODY_DISPATCH_ROUTE_REJECTED",
            "active V24 reconciliation requires its exact enabled route commitment");
    } else if (route != nullptr) {
        require(equal_digest(custody_dispatch_route_commitment(
                    peer->node_id, route->route_id,
                    transport_locator_text(route->locator), route->priority),
                activation->route_commitment),
            "CUSTODY_DISPATCH_ROUTE_REJECTED",
            "retained V24 route id was redefined in accepted configuration");
    }

    const auto local_certificate_sha256 =
        tls_certificate_sha256(config.identity.certificate);
    require(equal_digest(local_certificate_sha256,
            outbound_rule.custodian_certificate_sha256),
        "CUSTODY_SESSION_LOCAL_CERTIFICATE_MISMATCH",
        "local certificate differs from the exact outbound V22 commitment");
    const auto canonical = canonical_runtime_config(config);
    const auto configuration_sha256 = runtime_configuration_digest(canonical);
    require(!digest_is_zero(configuration_sha256),
        "CUSTODY_SESSION_CONFIGURATION_REJECTED",
        "accepted configuration digest is zero");

    return DispatchObservationAuthority{
        .config = &config,
        .activation = activation,
        .receiver = &receiver,
        .outbound_rule = &outbound_rule,
        .outbound_grant = &outbound_grant,
        .peer_generation = peer_generation,
        .peer = peer,
        .route = route,
        .activation_commitment =
            custody_dispatch_activation_commitment(*activation),
        .configuration_sha256 = configuration_sha256,
        .local_certificate_sha256 = local_certificate_sha256,
        .activation_expired = now_ms() >
            activation->activation_expires_unix_ms,
        .state_root = service_root_read_only(config, outbound_rule),
    };
}

struct ObservedDispatch final {
    OwnerDispatchRecord record;
    SignedOffer offer;
    datacube::Digest32 envelope_sha256;
    std::uint64_t attempts_observed{0U};
    std::string case_state;
    bool result_retained{false};
    std::optional<std::uint64_t> result_status;
    datacube::Digest32 result_sha256;
    bool acceptance_retained{false};
    datacube::Digest32 acceptance_sha256;
};

std::optional<ObservedDispatch> observe_dispatch_exact(
    const DispatchObservationAuthority& authority,
    const datacube::Digest32& dispatch_request_id) {
    require(!digest_is_zero(dispatch_request_id),
        "CUSTODY_DISPATCH_REQUEST_REJECTED",
        "dispatch reconciliation request id must be nonzero");
    if (!authority.state_root) { return std::nullopt; }
    const auto& root = *authority.state_root;
    const auto index = dispatch_index_path(root, dispatch_request_id);
    if (!regular_file_exists(index)) { return std::nullopt; }
    const auto outbound_request_id = parse_retained_operation_id(
        read_text(index, 128U),
        "dispatch index contains a non-canonical outbound request id");

    const auto case_directory = case_path(root, outbound_request_id);
    require(private_directory_exists_read_only(case_directory),
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "dispatch index names a missing or invalid V22 case directory");
    const auto dispatches = case_directory / "dispatches";
    require(private_directory_exists_read_only(dispatches),
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "dispatch index names a V22 case without its dispatch directory");
    const auto record_path = dispatches /
        (operation_id_text(dispatch_request_id) + ".record");
    require(regular_file_exists(record_path),
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "dispatch index names a V22 case without its exact dispatch record");
    const auto record = parse_owner_dispatch_record(
        read_regular_file(record_path, kStateTextLimit));
    require(equal_digest(record.dispatch_request_id, dispatch_request_id) &&
            record.activation_id == authority.activation->id &&
            record.activation_generation == authority.activation->generation &&
            equal_digest(record.activation_commitment,
                authority.activation_commitment) &&
            equal_digest(record.outbound_request_id, outbound_request_id),
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "dispatch index, record, and current V24 authority do not form one exact chain");

    const auto offer_path = case_directory / "offer.bin";
    const auto offer_wire = read_regular_file(
        offer_path, kMaximumCustodySessionWireBytes);
    const CustodyTransferOffer message{
        .request_id = outbound_request_id,
        .signed_offer = offer_wire,
    };
    ServiceAuthority service_authority{
        .config = authority.config,
        .rule = authority.outbound_rule,
        .grant = authority.outbound_grant,
        .peer_generation = authority.peer_generation,
        .peer = authority.peer,
        .route = authority.route,
        .local_is_custodian = true,
        .configuration_sha256 = authority.configuration_sha256,
        .local_certificate_sha256 = authority.local_certificate_sha256,
        .configuration_event = 0U,
        .state_root = root,
    };
    auto validated = validate_offer(service_authority, message, true);
    require(validated.offer.route_id == authority.activation->route_id,
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "retained V22 offer route differs from the exact V24 activation");
    const auto envelope_sha256 =
        custody_bundle_envelope_sha256(validated.bundle);
    const auto envelope_file = case_directory / "envelope_sha256";
    require(regular_file_exists(envelope_file) &&
            equal_digest(parse_retained_operation_id(
                    read_text(envelope_file, 128U),
                    "V22 case envelope metadata is non-canonical"),
                envelope_sha256),
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "V22 case envelope metadata differs from the retained signed offer");
    const auto envelope_index = envelope_index_path(root, envelope_sha256);
    require(regular_file_exists(envelope_index) &&
            equal_digest(parse_retained_operation_id(
                    read_text(envelope_index, 128U),
                    "V22 envelope index is non-canonical"),
                outbound_request_id),
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "V22 envelope index differs from the exact retained outbound request");

    const auto attempts = read_counter(case_directory / "attempts");
    require(record.attempt > 0U &&
            record.attempt <= authority.activation->maximum_dispatch_attempts &&
            (attempts >= record.attempt || record.attempt - attempts == 1U),
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "dispatch record and V22 attempt counter are inconsistent");
    const auto case_state = read_text(case_directory / "state", 256U);
    require(std::all_of(case_state.begin(), case_state.end(), [](const char raw) {
            const auto value = static_cast<unsigned char>(raw);
            return value >= 32U && value <= 126U;
        }),
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "V22 case state contains non-canonical bytes");

    const auto result_path = dispatches /
        (operation_id_text(dispatch_request_id) + ".result");
    const auto result_status_path = result_path.string() + ".status";
    const bool result_retained = regular_file_exists(result_path);
    const bool result_status_retained = regular_file_exists(result_status_path);
    require(result_retained || !result_status_retained,
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "dispatch status exists without its exact retained result");
    std::optional<std::uint64_t> result_status;
    datacube::Digest32 result_sha256{};
    if (result_retained) {
        const auto result_bytes = read_regular_file(
            result_path, kMaximumCustodyDispatchStatusJsonBytes);
        result_sha256 = datacube::sha256(result_bytes);
        if (result_status_retained) {
            result_status = parse_u64(read_text(result_status_path, 32U),
                "owner dispatch result status", 0U, 255U);
        }
    }

    const auto acceptance_path = case_directory / "acceptance.bin";
    const bool acceptance_retained = regular_file_exists(acceptance_path);
    datacube::Digest32 acceptance_sha256{};
    if (acceptance_retained) {
        const auto acceptance_bytes = read_regular_file(
            acceptance_path, kMaximumCustodySessionWireBytes);
        acceptance_sha256 = datacube::sha256(acceptance_bytes);
    }
    return ObservedDispatch{
        .record = record,
        .offer = std::move(validated.offer),
        .envelope_sha256 = envelope_sha256,
        .attempts_observed = attempts,
        .case_state = case_state,
        .result_retained = result_retained,
        .result_status = result_status,
        .result_sha256 = result_sha256,
        .acceptance_retained = acceptance_retained,
        .acceptance_sha256 = acceptance_sha256,
    };
}

std::string observed_dispatch_json(
    const DispatchObservationAuthority& authority,
    const ObservedDispatch& observed) {
    const bool revoked = authority.activation->state ==
        CustodyDispatchActivationState::revoked;
    std::string result = "{\"dispatch_request_id\":" +
        json_string(operation_id_text(observed.record.dispatch_request_id)) +
        ",\"request_commitment_sha256\":" +
        json_string(operation_id_text(observed.record.request_commitment)) +
        ",\"receiver_request_id\":" +
        json_string(operation_id_text(observed.record.receiver_request_id)) +
        ",\"outbound_request_id\":" +
        json_string(operation_id_text(observed.record.outbound_request_id)) +
        ",\"attempt_reserved\":" + std::to_string(observed.record.attempt) +
        ",\"attempts_observed\":" +
            std::to_string(observed.attempts_observed) +
        ",\"attempt_increment_pending\":" +
            std::string(observed.attempts_observed < observed.record.attempt ?
                "true" : "false") +
        ",\"case_state\":" + json_string(observed.case_state) +
        ",\"outbound_rule_id\":" +
            json_string(observed.offer.rule_id) +
        ",\"outbound_rule_generation\":" +
            std::to_string(observed.offer.rule_generation) +
        ",\"outbound_rule_commitment_sha256\":" +
            json_string(operation_id_text(observed.offer.rule_commitment)) +
        ",\"route_id\":" + json_string(observed.offer.route_id) +
        ",\"sender_configuration_sha256\":" +
            json_string(operation_id_text(
                observed.offer.sender_configuration_sha256)) +
        ",\"offer_sha256\":" +
            json_string(operation_id_text(
                datacube::sha256(observed.offer.wire))) +
        ",\"envelope_sha256\":" +
            json_string(operation_id_text(observed.envelope_sha256)) +
        ",\"result_retained\":" +
            std::string(observed.result_retained ? "true" : "false") +
        ",\"result_status\":" +
            (observed.result_status ?
                std::to_string(*observed.result_status) : "null") +
        ",\"result_sha256\":" +
            (observed.result_retained ?
                json_string(operation_id_text(observed.result_sha256)) :
                "null") +
        ",\"acceptance_retained\":" +
            std::string(observed.acceptance_retained ? "true" : "false") +
        ",\"acceptance_sha256\":" +
            (observed.acceptance_retained ?
                json_string(operation_id_text(observed.acceptance_sha256)) :
                "null") +
        ",\"revoked_metadata_only\":" +
            std::string(revoked ? "true" : "false") +
        ",\"remote_acceptance_replayed\":false"
        ",\"network_attempted\":false"
        ",\"filesystem_mutated\":false"
        ",\"application_delivery_inferred\":false}";
    return result;
}

std::optional<datacube::Digest32> find_dispatch_outbound_request(
    const std::filesystem::path& root,
    const datacube::Digest32& dispatch_request_id) {
    const auto index = dispatch_index_path(root, dispatch_request_id);
    if (regular_file_exists(index)) {
        return parse_operation_id(read_text(index, 128U));
    }
    std::size_t examined = 0U;
    for (const auto& entry : std::filesystem::directory_iterator(
            root / "cases")) {
        require(++examined <= kCaseScanLimit,
            "CUSTODY_SESSION_STATE_CAPACITY",
            "custody case scan exceeds the finite bound");
        if (!entry.is_directory()) { continue; }
        const auto candidate = entry.path() / "dispatches" /
            (operation_id_text(dispatch_request_id) + ".record");
        if (!regular_file_exists(candidate)) { continue; }
        const auto outbound_request = parse_operation_id(
            entry.path().filename().string());
        atomic_write_text(index,
            operation_id_text(outbound_request) + "\n");
        return outbound_request;
    }
    return std::nullopt;
}

std::size_t dispatch_record_count(const PreparedSend& prepared,
    const std::size_t limit) {
    std::size_t count = 0U;
    for (const auto& entry : std::filesystem::directory_iterator(
            dispatch_directory(prepared))) {
        if (entry.path().extension() != ".record") { continue; }
        require(++count <= limit,
            "CUSTODY_DISPATCH_ATTEMPTS_EXHAUSTED",
            "finite owner-dispatch request bound is exhausted");
    }
    return count;
}

std::string owner_dispatch_result_json(
    const CustodyDispatchActivation& activation,
    const CustodyOwnerDispatchRequest& request,
    const PreparedSend& prepared,
    const OwnerDispatchRecord& record,
    const CustodySessionServiceResult& custody_result,
    const bool newly_committed_attempt) {
    return "{\"format\":\"NATRAV_OWNER_CUSTODY_DISPATCH_V1\""
        ",\"activation_id\":" + json_string(activation.id) +
        ",\"activation_generation\":" +
            std::to_string(activation.generation) +
        ",\"activation_commitment_sha256\":" +
            json_string(operation_id_text(
                custody_dispatch_activation_commitment(activation))) +
        ",\"dispatch_request_id\":" +
            json_string(operation_id_text(request.dispatch_request_id)) +
        ",\"receiver_request_id\":" +
            json_string(operation_id_text(request.receiver_request_id)) +
        ",\"outbound_request_id\":" +
            json_string(operation_id_text(prepared.offer.request_id)) +
        ",\"attempt_number\":" + std::to_string(record.attempt) +
        ",\"new_outbound_attempt_committed\":" +
            std::string(newly_committed_attempt ? "true" : "false") +
        ",\"custody_result\":" + custody_result.json +
        ",\"automatic_retry\":false"
        ",\"automatic_route_relay\":false"
        ",\"application_delivery_inferred\":false}";
}

int poll_listener(const int descriptor) {
    while (service_stop_requested == 0) {
        pollfd item{
            .fd = descriptor,
            .events = POLLIN,
            .revents = 0,
        };
        const int result = ::poll(&item, 1U, 100);
        if (result < 0) {
            if (errno == EINTR) { continue; }
            app_fail("CUSTODY_SESSION_LISTENER_FAILED",
                datacube::errno_detail("custody service listener poll", errno));
        }
        if (result > 0 && (item.revents & POLLIN) != 0) { return 1; }
        if (result > 0 &&
            (item.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0) {
            app_fail("CUSTODY_SESSION_LISTENER_FAILED",
                "custody service listener became unavailable");
        }
    }
    return 0;
}

std::string aggregate_status(const ServiceAuthority& authority) {
    std::size_t cases = 0U;
    std::size_t accepted = 0U;
    std::size_t unresolved = 0U;
    for (const auto& entry : std::filesystem::directory_iterator(
            authority.state_root / "cases")) {
        require(++cases <= kCaseScanLimit,
            "CUSTODY_SESSION_STATE_CAPACITY",
            "custody service case count exceeds the finite bound");
        if (!entry.is_directory()) { continue; }
        if (regular_file_exists(entry.path() / "acceptance.bin")) {
            ++accepted;
        } else {
            ++unresolved;
        }
    }
    return "{\"format\":\"NATRAV_NATIVE_CUSTODY_SESSION_STATUS_V1\""
        ",\"rule_id\":" + json_string(authority.rule->id) +
        ",\"rule_generation\":" +
            std::to_string(authority.rule->generation) +
        ",\"rule_state\":" +
            json_string(custody_session_rule_state_name(
                authority.rule->state)) +
        ",\"cases\":" + std::to_string(accepted + unresolved) +
        ",\"accepted\":" + std::to_string(accepted) +
        ",\"unresolved\":" + std::to_string(unresolved) +
        ",\"transport\":\"NOS1_BOUNDED_REUSE_V1\""
        ",\"automatic_route_relay\":false}";
}

} // namespace

PassiveCustodyReceiver::PassiveCustodyReceiver(
    NodeState& state) noexcept : state_(state) {}

std::uint32_t PassiveCustodyReceiver::in_flight() const noexcept {
    return in_flight_.load();
}

CustodyTransferAcceptance PassiveCustodyReceiver::receive(
    const RuntimeConfig& config,
    const TlsSessionInfo& session,
    const CustodyTransferOffer& message) {
    require(config.format_version >= 23U,
        "CUSTODY_RECEIVER_DISABLED",
        "ordinary daemon custody receipt is default-off without V23");
    const auto parsed = parse_offer(message.signed_offer);
    require(equal_digest(parsed.request_id, message.request_id),
        "CUSTODY_SESSION_REQUEST_BINDING_REJECTED",
        "NOS1 operation id differs from the signed offer bytes");
    const auto* activation = find_custody_receiver_activation_for_rule(
        config.custody_receivers, parsed.rule_id,
        parsed.rule_generation);
    require(activation != nullptr,
        "CUSTODY_RECEIVER_DISABLED",
        "no accepted V23 activation names this exact V22 rule");
    static_cast<void>(resolve_custody_receiver_session_rule(
        config.custody_sessions, *activation, false));
    require(activation->state !=
            CustodyReceiverActivationState::revoked,
        "CUSTODY_RECEIVER_REVOKED",
        "revoked V23 receiver authority admits and replays nothing");

    std::uint32_t observed = in_flight_.load();
    while (true) {
        require(observed < activation->maximum_inflight_offers,
            "CUSTODY_RECEIVER_BUSY",
            "finite daemon custody receiver concurrency is exhausted");
        if (in_flight_.compare_exchange_weak(
                observed, observed + 1U)) {
            break;
        }
    }
    struct InflightGuard final {
        std::atomic<std::uint32_t>& value;
        ~InflightGuard() { static_cast<void>(value.fetch_sub(1U)); }
    } guard{in_flight_};

    CustodySessionServiceOptions options;
    options.rule_id = activation->session_rule_id;
    options.rule_generation = activation->session_rule_generation;
    const auto authority = resolve_authority(
        state_, config, options, ServiceOperation::passive_receive);
    const bool activation_can_create =
        activation->state == CustodyReceiverActivationState::active &&
        now_ms() <= activation->activation_expires_unix_ms;
    if (!activation_can_create) {
        const auto directory = case_path(
            authority.state_root, message.request_id);
        require(regular_file_exists(directory / "acceptance.bin"),
            "CUSTODY_RECEIVER_RETIRED",
            "retired or expired V23 authority may replay only an exact retained acceptance");
    }
    return receive_offer(state_, authority, session, message);
}

CustodyOwnerDispatcher::CustodyOwnerDispatcher(
    NodeState& state, TlsContext& tls) noexcept : state_(state), tls_(tls) {}

std::uint32_t CustodyOwnerDispatcher::in_flight() const noexcept {
    return in_flight_.load();
}

CustodySessionServiceResult CustodyOwnerDispatcher::dispatch_once(
    const RuntimeConfig& config,
    const CustodyOwnerDispatchRequest& request) {
    require(config.format_version >= 24U,
        "CUSTODY_DISPATCH_DISABLED",
        "ordinary-daemon owner dispatch is default-off without V24");
    const auto request_commitment =
        owner_dispatch_request_commitment(request);
    const auto* activation = find_custody_dispatch_activation(
        config.custody_dispatch, request.activation_id,
        request.activation_generation);
    require(activation != nullptr,
        "CUSTODY_DISPATCH_ACTIVATION_UNKNOWN",
        "exact V24 owner-dispatch activation is absent");
    const auto& receiver = resolve_custody_dispatch_receiver_activation(
        config.custody_receivers, *activation, false);
    const auto& outbound_rule = resolve_custody_dispatch_outbound_rule(
        config.custody_sessions, *activation, false);
    require(activation->state != CustodyDispatchActivationState::revoked,
        "CUSTODY_DISPATCH_REVOKED",
        "revoked V24 authority permits neither attempts nor result replay");

    const auto prior = in_flight_.fetch_add(1U);
    if (prior >= activation->maximum_concurrent_dispatches) {
        static_cast<void>(in_flight_.fetch_sub(1U));
        app_fail("CUSTODY_DISPATCH_CONCURRENCY_LIMIT",
            "finite owner-dispatch concurrency is exhausted");
    }
    const auto active_key = activation->id + "/" +
        std::to_string(activation->generation) + "/" +
        operation_id_text(request.receiver_request_id);
    bool inserted = false;
    {
        std::lock_guard<std::mutex> lock(active_mutex_);
        inserted = active_receiver_requests_.insert(active_key).second;
    }
    if (!inserted) {
        static_cast<void>(in_flight_.fetch_sub(1U));
        app_fail("CUSTODY_DISPATCH_CASE_BUSY",
            "one owner dispatch for this retained receiver case is already active");
    }
    struct DispatchGuard final {
        std::atomic<std::uint32_t>& in_flight;
        std::mutex& mutex;
        std::set<std::string>& active;
        const std::string& key;
        ~DispatchGuard() {
            {
                std::lock_guard<std::mutex> lock(mutex);
                active.erase(key);
            }
            static_cast<void>(in_flight.fetch_sub(1U));
        }
    } guard{in_flight_, active_mutex_, active_receiver_requests_, active_key};

    const auto root = service_root(config, outbound_rule);
    const auto activation_commitment =
        custody_dispatch_activation_commitment(*activation);

    const auto read_result = [&](const PreparedSend& prepared) ->
            std::optional<CustodySessionServiceResult> {
        const auto path = dispatch_result_path(
            prepared, request.dispatch_request_id);
        if (!regular_file_exists(path)) { return std::nullopt; }
        const auto json = read_text(path, 16'384U);
        int status = json.find("\"status\":\"ACCEPTED\"") !=
                std::string::npos ? 0 : 4;
        const auto status_path = path.string() + ".status";
        if (regular_file_exists(status_path)) {
            status = static_cast<int>(parse_u64(read_text(status_path, 32U),
                "owner dispatch result status", 0U, 255U));
        }
        return CustodySessionServiceResult{
            .status = status,
            .json = json,
        };
    };
    const auto save_result = [&](const PreparedSend& prepared,
            const CustodySessionServiceResult& result) {
        const auto path = dispatch_result_path(
            prepared, request.dispatch_request_id);
        persist_exact(path, View(
            reinterpret_cast<const std::uint8_t*>(result.json.data()),
            result.json.size()), 16'384U,
            "owner dispatch result differs from its retained exact bytes");
        atomic_write_text(path.string() + ".status",
            std::to_string(result.status) + "\n");
    };
    const auto validate_record = [&](const OwnerDispatchRecord& record,
            const PreparedSend& prepared) {
        require(equal_digest(record.dispatch_request_id,
                    request.dispatch_request_id) &&
                equal_digest(record.request_commitment,
                    request_commitment) &&
                record.activation_id == activation->id &&
                record.activation_generation == activation->generation &&
                equal_digest(record.activation_commitment,
                    activation_commitment) &&
                equal_digest(record.receiver_request_id,
                    request.receiver_request_id) &&
                equal_digest(record.outbound_request_id,
                    prepared.offer.request_id),
            "CUSTODY_DISPATCH_ID_REUSE_CONFLICT",
            "dispatch request id was previously bound to different authority or bytes");
    };
    const auto recover_record = [&](const ServiceAuthority& authority,
            const PreparedSend& prepared) -> CustodySessionServiceResult {
        const auto record_path = dispatch_record_path(
            prepared, request.dispatch_request_id);
        require(regular_file_exists(record_path),
            "CUSTODY_DISPATCH_STATE_REJECTED",
            "dispatch index names a case without its durable request record");
        const auto record = parse_owner_dispatch_record(read_regular_file(
            record_path, kStateTextLimit));
        validate_record(record, prepared);
        if (const auto retained = read_result(prepared)) { return *retained; }
        const auto attempts = read_counter(prepared.directory / "attempts");
        if (attempts < record.attempt) {
            atomic_write_text(prepared.directory / "attempts",
                std::to_string(record.attempt) + "\n");
            atomic_write_text(prepared.directory / "state",
                "UNRESOLVED_AFTER_DISPATCH_RESERVATION\n");
        }
        CustodySessionServiceResult custody_result;
        if (regular_file_exists(prepared.directory / "acceptance.bin")) {
            custody_result = accepted_from_retained(
                state_, authority, prepared);
        } else {
            record_uncertainty(state_, authority,
                prepared.envelope_sha256,
                "owner dispatch was durably committed; no second attempt is permitted for this request id");
            custody_result = CustodySessionServiceResult{
                .status = 4,
                .json = result_json(
                    "UNRESOLVED_OWNER_DISPATCH_RECOVERED",
                    prepared.offer, prepared.envelope_sha256,
                    std::max(attempts, record.attempt), false,
                    "durable dispatch reservation recovered without a second network attempt"),
            };
        }
        CustodySessionServiceResult result{
            .status = custody_result.status,
            .json = owner_dispatch_result_json(*activation, request,
                prepared, record, custody_result, false),
        };
        save_result(prepared, result);
        return result;
    };

    if (const auto outbound_request = find_dispatch_outbound_request(
            root, request.dispatch_request_id)) {
        CustodySessionServiceOptions recovery_options;
        recovery_options.rule_id = outbound_rule.id;
        recovery_options.rule_generation = outbound_rule.generation;
        const auto authority = resolve_authority(state_, config,
            recovery_options, ServiceOperation::owner_dispatch_recovery);
        const auto prepared = prepared_from_request(state_, authority,
            *outbound_request, activation->route_id);
        return recover_record(authority, prepared);
    }

    require(activation->state == CustodyDispatchActivationState::active &&
            now_ms() <= activation->activation_expires_unix_ms,
        "CUSTODY_DISPATCH_RETIRED",
        "retired or expired V24 authority may recover only an exact retained dispatch request");
    static_cast<void>(resolve_custody_dispatch_receiver_activation(
        config.custody_receivers, *activation, true));
    static_cast<void>(resolve_custody_dispatch_outbound_rule(
        config.custody_sessions, *activation, true));
    const auto& receiver_rule = resolve_custody_receiver_session_rule(
        config.custody_sessions, receiver, true);
    static_cast<void>(resolve_custody_session_grant(
        config.custody_relay, receiver_rule, true));
    const auto& outbound_grant = resolve_custody_session_grant(
        config.custody_relay, outbound_rule, true);
    require(now_ms() <= receiver.activation_expires_unix_ms,
        "CUSTODY_DISPATCH_RECEIVER_EXPIRED",
        "exact V23 receiver authority has expired");
    const auto* peer = find_peer(config, outbound_grant.next_hop);
    const auto* route = peer == nullptr ? nullptr :
        find_peer_route(*peer, activation->route_id);
    require(peer != nullptr && route != nullptr &&
            route->state == PeerRouteState::enabled &&
            equal_digest(custody_dispatch_route_commitment(
                    peer->node_id, route->route_id,
                    transport_locator_text(route->locator), route->priority),
                activation->route_commitment),
        "CUSTODY_DISPATCH_ROUTE_REJECTED",
        "current route differs from the exact active V24 commitment");

    CustodySessionServiceOptions source_options;
    source_options.rule_id = receiver_rule.id;
    source_options.rule_generation = receiver_rule.generation;
    source_options.request_id = request.receiver_request_id;
    source_options.has_request_id = true;
    const auto source_authority = resolve_authority(state_, config,
        source_options, ServiceOperation::dispatch_source);
    const auto source_bundle = retained_dispatch_source(
        state_, source_authority, request.receiver_request_id);
    const auto encoded_source = encode_custody_bundle(source_bundle);

    CustodySessionServiceOptions outbound_options;
    outbound_options.rule_id = outbound_rule.id;
    outbound_options.rule_generation = outbound_rule.generation;
    outbound_options.route_id = activation->route_id;
    const auto outbound_authority = resolve_authority(state_, config,
        outbound_options, ServiceOperation::owner_dispatch);
    auto prepared = prepare_send_bytes(state_, outbound_authority,
        encoded_source, activation->route_id);

    const auto record_path = dispatch_record_path(
        prepared, request.dispatch_request_id);
    if (regular_file_exists(record_path)) {
        atomic_write_text(dispatch_index_path(
            root, request.dispatch_request_id),
            operation_id_text(prepared.offer.request_id) + "\n");
        return recover_record(outbound_authority, prepared);
    }
    require(dispatch_record_count(prepared,
            activation->maximum_dispatch_attempts) <
            activation->maximum_dispatch_attempts,
        "CUSTODY_DISPATCH_ATTEMPTS_EXHAUSTED",
        "finite owner-dispatch request bound is exhausted");

    auto attempts = read_counter(prepared.directory / "attempts");
    const bool already_accepted =
        regular_file_exists(prepared.directory / "acceptance.bin");
    if (!already_accepted) {
        require(now_ms() <= prepared.offer.expires_ms,
            "CUSTODY_DISPATCH_OFFER_EXPIRED",
            "retained outbound custody offer has expired");
        require(attempts < outbound_rule.maximum_attempts &&
                attempts < activation->maximum_dispatch_attempts,
            "CUSTODY_DISPATCH_ATTEMPTS_EXHAUSTED",
            "finite V22 or V24 attempt bound is exhausted");
    }
    const OwnerDispatchRecord record{
        .dispatch_request_id = request.dispatch_request_id,
        .request_commitment = request_commitment,
        .activation_id = activation->id,
        .activation_generation = activation->generation,
        .activation_commitment = activation_commitment,
        .receiver_request_id = request.receiver_request_id,
        .outbound_request_id = prepared.offer.request_id,
        .attempt = already_accepted ? 0U : attempts + 1U,
    };
    const auto record_text = owner_dispatch_record_text(record);
    custody_session_test_pause("BEFORE_DISPATCH_RESERVATION");
    persist_exact(record_path, View(
        reinterpret_cast<const std::uint8_t*>(record_text.data()),
        record_text.size()), kStateTextLimit,
        "dispatch request id carries different retained bytes");
    atomic_write_text(dispatch_index_path(
        root, request.dispatch_request_id),
        operation_id_text(prepared.offer.request_id) + "\n");
    custody_session_test_pause("AFTER_DISPATCH_RESERVATION");

    CustodySessionServiceResult custody_result;
    bool newly_committed_attempt = false;
    if (already_accepted) {
        custody_result = accepted_from_retained(
            state_, outbound_authority, prepared);
    } else {
        attempts = record.attempt;
        custody_session_test_pause("BEFORE_ATTEMPT_INCREMENT");
        atomic_write_text(prepared.directory / "attempts",
            std::to_string(attempts) + "\n");
        custody_session_test_pause("AFTER_ATTEMPT_INCREMENT");
        atomic_write_text(prepared.directory / "state",
            "ATTEMPT_COMMITTED_AWAITING_ACCEPTANCE\n");
        newly_committed_attempt = true;
        custody_result = perform_committed_attempt(state_, tls_,
            outbound_authority, prepared, attempts);
    }
    CustodySessionServiceResult result{
        .status = custody_result.status,
        .json = owner_dispatch_result_json(*activation, request,
            prepared, record, custody_result, newly_committed_attempt),
    };
    save_result(prepared, result);
    return result;
}

std::string CustodyOwnerDispatcher::reconcile_status(
    const RuntimeConfig& config,
    const CustodyOwnerDispatchStatusRequest& request) const {
    const auto authority = resolve_dispatch_observation_authority(
        config, request.activation_id, request.activation_generation);
    const auto observed = observe_dispatch_exact(
        authority, request.dispatch_request_id);
    std::string result =
        "{\"format\":\"NATRAV_CUSTODY_DISPATCH_STATUS_V1\""
        ",\"activation_id\":" + json_string(authority.activation->id) +
        ",\"activation_generation\":" +
            std::to_string(authority.activation->generation) +
        ",\"activation_state\":" + json_string(
            custody_dispatch_activation_state_name(
                authority.activation->state)) +
        ",\"activation_expired\":" +
            std::string(authority.activation_expired ? "true" : "false") +
        ",\"activation_commitment_sha256\":" + json_string(
            operation_id_text(authority.activation_commitment)) +
        ",\"current_configuration_sha256\":" + json_string(
            operation_id_text(authority.configuration_sha256)) +
        ",\"dispatch_request_id\":" +
            json_string(operation_id_text(request.dispatch_request_id)) +
        ",\"status\":" +
            json_string(observed ? "RECORDED" : "NOT_FOUND") +
        ",\"record\":" +
            (observed ? observed_dispatch_json(authority, *observed) : "null") +
        ",\"repair_performed\":false"
        ",\"network_attempted\":false"
        ",\"filesystem_mutated\":false"
        ",\"application_delivery_inferred\":false}";
    require(result.size() <= kMaximumCustodyDispatchStatusJsonBytes,
        "CUSTODY_DISPATCH_STATUS_BYTE_LIMIT",
        "custody dispatch status JSON exceeds its finite byte bound");
    return result;
}

std::string CustodyOwnerDispatcher::reconcile_inventory(
    const RuntimeConfig& config,
    const CustodyOwnerDispatchInventoryRequest& request) const {
    require(request.limit > 0U &&
            request.limit <= kMaximumCustodyDispatchInventoryRecords &&
            request.maximum_bytes >= 2'048U &&
            request.maximum_bytes <=
                kMaximumCustodyDispatchInventoryJsonBytes &&
            (!request.cursor || !digest_is_zero(*request.cursor)),
        "CUSTODY_DISPATCH_INVENTORY_BOUNDS",
        "custody dispatch inventory bounds or cursor are invalid");
    const auto authority = resolve_dispatch_observation_authority(
        config, request.activation_id, request.activation_generation);

    std::vector<std::string> names;
    if (authority.state_root) {
        const auto directory = *authority.state_root / "dispatch-index";
        require(private_directory_exists_read_only(directory),
            "CUSTODY_DISPATCH_STATE_REJECTED",
            "dispatch inventory directory is absent from an existing V22 root");
        std::size_t examined = 0U;
        for (const auto& entry : std::filesystem::directory_iterator(directory)) {
            require(++examined <= kCaseScanLimit,
                "CUSTODY_DISPATCH_INVENTORY_CAPACITY",
                "dispatch inventory exceeds its finite scan bound");
            const auto status = entry.symlink_status();
            require(status.type() == std::filesystem::file_type::regular,
                "CUSTODY_DISPATCH_STATE_REJECTED",
                "dispatch inventory rejects symlink and non-regular index entries");
            const auto name = entry.path().filename().string();
            const auto digest = parse_retained_operation_id(name,
                "dispatch inventory contains a non-canonical request id");
            require(operation_id_text(digest) == name,
                "CUSTODY_DISPATCH_STATE_REJECTED",
                "dispatch inventory contains a non-canonical request id");
            // Validate the complete exact index -> record -> V22 case chain
            // before sorting. This fails closed even for conflicting entries
            // beyond the requested page; cursor position cannot hide corruption.
            const auto observed = observe_dispatch_exact(authority, digest);
            require(observed.has_value(),
                "CUSTODY_DISPATCH_STATE_REJECTED",
                "dispatch inventory index vanished during bounded validation");
            names.push_back(name);
        }
    }
    std::sort(names.begin(), names.end());
    require(std::adjacent_find(names.begin(), names.end()) == names.end(),
        "CUSTODY_DISPATCH_STATE_REJECTED",
        "dispatch inventory contains duplicate canonical index names");

    const std::string cursor_text = request.cursor ?
        operation_id_text(*request.cursor) : std::string{};
    auto current = cursor_text.empty() ? names.begin() :
        std::upper_bound(names.begin(), names.end(), cursor_text);
    std::vector<std::string> records;
    records.reserve(request.limit);
    std::string last_cursor;
    bool more = false;
    while (current != names.end()) {
        if (records.size() >= request.limit) {
            more = true;
            break;
        }
        const auto dispatch_id = parse_operation_id(*current);
        const auto observed = observe_dispatch_exact(authority, dispatch_id);
        require(observed.has_value(),
            "CUSTODY_DISPATCH_STATE_REJECTED",
            "dispatch inventory index vanished during its bounded read");
        const auto row = observed_dispatch_json(authority, *observed);
        std::size_t rows_bytes = 0U;
        for (const auto& retained : records) {
            rows_bytes += retained.size() + 1U;
        }
        const std::size_t conservative_overhead = 1'024U;
        if (rows_bytes + row.size() + conservative_overhead >
                request.maximum_bytes) {
            require(!records.empty(),
                "CUSTODY_DISPATCH_INVENTORY_BYTE_LIMIT",
                "one custody dispatch inventory row exceeds the requested page byte bound");
            more = true;
            break;
        }
        records.push_back(row);
        last_cursor = *current;
        ++current;
    }
    if (current != names.end()) { more = true; }

    std::string result =
        "{\"format\":\"NATRAV_CUSTODY_DISPATCH_INVENTORY_V1\""
        ",\"activation_id\":" + json_string(authority.activation->id) +
        ",\"activation_generation\":" +
            std::to_string(authority.activation->generation) +
        ",\"activation_state\":" + json_string(
            custody_dispatch_activation_state_name(
                authority.activation->state)) +
        ",\"activation_expired\":" +
            std::string(authority.activation_expired ? "true" : "false") +
        ",\"activation_commitment_sha256\":" + json_string(
            operation_id_text(authority.activation_commitment)) +
        ",\"current_configuration_sha256\":" + json_string(
            operation_id_text(authority.configuration_sha256)) +
        ",\"cursor\":" +
            (request.cursor ? json_string(cursor_text) : "null") +
        ",\"limit\":" + std::to_string(request.limit) +
        ",\"maximum_bytes\":" + std::to_string(request.maximum_bytes) +
        ",\"records\":[";
    for (std::size_t index = 0U; index < records.size(); ++index) {
        if (index != 0U) { result += ','; }
        result += records[index];
    }
    result += "],\"returned\":" + std::to_string(records.size()) +
        ",\"more\":" + std::string(more ? "true" : "false") +
        ",\"next_cursor\":" +
            (last_cursor.empty() ? "null" : json_string(last_cursor)) +
        ",\"repair_performed\":false"
        ",\"network_attempted\":false"
        ",\"filesystem_mutated\":false"
        ",\"application_delivery_inferred\":false}";
    require(result.size() <= request.maximum_bytes &&
            result.size() <= kMaximumCustodyDispatchInventoryJsonBytes,
        "CUSTODY_DISPATCH_INVENTORY_BYTE_LIMIT",
        "custody dispatch inventory JSON exceeds its finite byte bound");
    return result;
}

CustodySessionServiceResult run_custody_session_send(
    const CustodySessionServiceOptions& options) {
    const auto seed = load_runtime_config(options.config);
    require_handoff_state_owner(seed.state_directory);
    NodeState state(seed.state_directory, seed.local_node,
        seed.maximum_journal_bytes, seed.queue_limits);
    RuntimeConfiguration runtime(seed, state);
    const auto config = runtime.snapshot();
    const auto authority = resolve_authority(state, *config, options, ServiceOperation::send);
    auto prepared = prepare_send(state, authority, options);

    if (regular_file_exists(prepared.directory / "acceptance.bin")) {
        return accepted_from_retained(state, authority, prepared);
    }
    if (authority.rule->state == CustodySessionRuleState::revoked ||
        authority.grant->state == CustodyRelayGrantState::revoked) {
        app_fail("CUSTODY_SESSION_REVOKED",
            "revoked authority cannot retry an unresolved custody offer");
    }
    if (now_ms() > prepared.offer.expires_ms) {
        record_uncertainty(state, authority, prepared.envelope_sha256,
            "retained custody offer expired without acceptance");
        return CustodySessionServiceResult{
            .status = 4,
            .json = result_json("UNRESOLVED_EXPIRED", prepared.offer,
                prepared.envelope_sha256,
                read_counter(prepared.directory / "attempts"), false,
                "retained custody offer expired without acceptance"),
        };
    }

    auto attempts = read_counter(prepared.directory / "attempts");
    if (attempts >= authority.rule->maximum_attempts) {
        record_uncertainty(state, authority, prepared.envelope_sha256,
            "finite custody-service attempt bound is exhausted");
        return CustodySessionServiceResult{
            .status = 4,
            .json = result_json("UNRESOLVED_ATTEMPTS_EXHAUSTED",
                prepared.offer, prepared.envelope_sha256, attempts, false,
                "finite custody-service attempt bound is exhausted"),
        };
    }
    ++attempts;
    custody_session_test_pause("BEFORE_ATTEMPT_INCREMENT");
    atomic_write_text(prepared.directory / "attempts",
        std::to_string(attempts) + "\n");
    custody_session_test_pause("AFTER_ATTEMPT_INCREMENT");
    atomic_write_text(prepared.directory / "state",
        "ATTEMPT_COMMITTED_AWAITING_ACCEPTANCE\n");

    try {
        TlsContext tls(config->identity);
        auto session = OutboundPeerSession::open(tls,
            config->local_node, authority.grant->next_hop,
            authority.grant->next_hop_signing_generation,
            authority.peer_generation->state,
            authority.peer_generation->spki_sha256,
            authority.route->locator, prepared.offer.request_id,
            config->io, config->sessions);
        require_tls_peer(authority, session.tls_session());
        const ApplicationMessage request = CustodyTransferOffer{
            .request_id = prepared.offer.request_id,
            .signed_offer = prepared.offer.wire,
        };
        const auto response = session.exchange_message(
            prepared.offer.request_id, request, config->io);
        if (const auto* error = std::get_if<ProtocolError>(&response)) {
            app_fail(error->code, error->detail);
        }
        const auto* accepted =
            std::get_if<CustodyTransferAcceptance>(&response);
        require(accepted != nullptr &&
                equal_digest(accepted->request_id,
                    prepared.offer.request_id),
            "CUSTODY_SESSION_RESPONSE_REJECTED",
            "native session did not return the exact custody acceptance");
        const auto acceptance = validate_acceptance(authority,
            prepared.offer, prepared.bundle,
            accepted->signed_acceptance);
        // Sender recovery mirrors the receiver boundary: retain exact response
        // bytes before applying the durable custody record.
        custody_session_test_pause("BEFORE_SENDER_ACCEPTANCE_PUBLICATION");
        persist_exact(prepared.directory / "acceptance.bin",
            acceptance.wire, kMaximumCustodySessionWireBytes,
            "received acceptance differs from durable acceptance");
        custody_session_test_pause("AFTER_SENDER_ACCEPTANCE_PUBLICATION");
        atomic_write_text(prepared.directory / "state",
            "ACCEPTANCE_DURABLE_BEFORE_LOCAL_COMMIT\n");
        custody_session_test_pause("BEFORE_SENDER_JOURNAL_COMMIT");
        commit_acceptance(state, authority, prepared.bundle, acceptance);
        custody_session_test_pause("AFTER_SENDER_JOURNAL_COMMIT");
        atomic_write_text(prepared.directory / "state", "ACCEPTED\n");
        atomic_write_text(prepared.directory / "last_error", "NONE\n");
        // The acceptance and its local journal effect are already durable;
        // clean NOS1 closure is best-effort and cannot downgrade custody.
        static_cast<void>(session.close_cleanly(config->io));
        return CustodySessionServiceResult{
            .status = 0,
            .json = result_json("ACCEPTED", prepared.offer,
                prepared.envelope_sha256, attempts, true),
        };
    } catch (const std::exception& error) {
        const auto detail = bounded_detail(error.what());
        atomic_write_text(prepared.directory / "last_error", detail + "\n");
        atomic_write_text(prepared.directory / "state",
            "UNRESOLVED_AFTER_ATTEMPT\n");
        record_uncertainty(state, authority,
            prepared.envelope_sha256, detail);
        return CustodySessionServiceResult{
            .status = 4,
            .json = result_json("UNRESOLVED", prepared.offer,
                prepared.envelope_sha256, attempts, false, detail),
        };
    }
}

CustodySessionServiceResult run_custody_session_status(
    const CustodySessionServiceOptions& options) {
    const auto seed = load_runtime_config(options.config);
    require_handoff_state_owner(seed.state_directory);
    NodeState state(seed.state_directory, seed.local_node,
        seed.maximum_journal_bytes, seed.queue_limits);
    RuntimeConfiguration runtime(seed, state);
    const auto config = runtime.snapshot();
    const auto authority = resolve_authority(state, *config, options,
        ServiceOperation::inspect);
    if (options.bundle.empty()) {
        return CustodySessionServiceResult{
            .status = 0,
            .json = aggregate_status(authority),
        };
    }
    const auto encoded = read_handoff_file(options.bundle,
        authority.rule->maximum_bundle_bytes);
    const auto bundle = decode_custody_bundle(encoded);
    const auto envelope_sha256 = custody_bundle_envelope_sha256(bundle);
    const auto request = request_for_envelope(
        authority.state_root, envelope_sha256, false);
    if (!request) {
        return CustodySessionServiceResult{
            .status = 0,
            .json = "{\"format\":\"NATRAV_NATIVE_CUSTODY_SESSION_STATUS_V1\""
                ",\"status\":\"NOT_REGISTERED\",\"envelope_sha256\":" +
                json_string(operation_id_text(envelope_sha256)) + "}",
        };
    }
    const auto directory = case_path(authority.state_root, *request);
    const auto wire = read_regular_file(directory / "offer.bin",
        kMaximumCustodySessionWireBytes);
    const auto offer = parse_offer(wire);
    const auto attempts = read_counter(directory / "attempts");
    const auto accepted = regular_file_exists(directory / "acceptance.bin");
    const auto state_text = read_text(directory / "state");
    return CustodySessionServiceResult{
        .status = 0,
        .json = result_json(state_text, offer, envelope_sha256,
            attempts, accepted),
    };
}

CustodySessionServiceResult run_custody_session_export(
    const CustodySessionServiceOptions& options) {
    require(options.has_request_id,
        "CUSTODY_SESSION_REQUEST_REQUIRED",
        "retained export requires one exact request identifier");
    require(!options.output.empty(),
        "CUSTODY_SESSION_OUTPUT_REQUIRED",
        "retained export requires one new output file");
    const auto seed = load_runtime_config(options.config);
    require_handoff_state_owner(seed.state_directory);
    NodeState state(seed.state_directory, seed.local_node,
        seed.maximum_journal_bytes, seed.queue_limits);
    RuntimeConfiguration runtime(seed, state);
    const auto config = runtime.snapshot();
    const auto authority = resolve_authority(state, *config, options,
        ServiceOperation::export_retained);
    require(authority.rule->state != CustodySessionRuleState::revoked &&
            authority.grant->state != CustodyRelayGrantState::revoked,
        "CUSTODY_SESSION_REVOKED",
        "revoked authority cannot export retained acceptance for onward use");

    const auto directory = case_path(
        authority.state_root, options.request_id);
    const auto offer_wire = read_regular_file(directory / "offer.bin",
        kMaximumCustodySessionWireBytes);
    const CustodyTransferOffer message{
        .request_id = options.request_id,
        .signed_offer = offer_wire,
    };
    auto validated = validate_offer(authority, message, true);
    const auto acceptance_wire = read_regular_file(
        directory / "acceptance.bin", kMaximumCustodySessionWireBytes);
    const auto acceptance = validate_acceptance(authority,
        validated.offer, validated.bundle, acceptance_wire);

    const auto envelope_sha256 =
        custody_bundle_envelope_sha256(validated.bundle);
    const auto custody = require_case(state, envelope_sha256);
    const auto local_index = route_index(custody.envelope,
        authority.config->local_node,
        authority.config->local_identity_generation);
    require(!custody.expired_ms && !custody.imported_ms &&
            now_ms() <= custody.envelope.expires_ms &&
            !custody.progress.awaiting_acceptance &&
            custody.progress.current_party_index == local_index &&
            local_index > 0U &&
            local_index + 1U < custody.envelope.route.size() &&
            last_record_is(custody, CustodyRecordKind::acceptance,
                local_index),
        "CUSTODY_SESSION_LOCAL_ROLE_REJECTED",
        "retained export requires the exact current nonterminal custodian");
    require(custody.envelope.canonical ==
                validated.bundle.envelope.canonical &&
            custody.capsule == validated.bundle.capsule &&
            custody.grants == validated.bundle.grants &&
            custody.records.size() == validated.bundle.records.size() + 1U &&
            std::equal(validated.bundle.records.begin(),
                validated.bundle.records.end(), custody.records.begin()) &&
            custody.records.back() == acceptance.record,
        "CUSTODY_SESSION_REPLAY_CONFLICT",
        "authenticated retained case differs from its exact offer and acceptance");

    const auto exported = bundle_from_case(custody);
    const auto encoded = encode_custody_bundle(exported);
    require(encoded.size() <= authority.rule->maximum_bundle_bytes,
        "CUSTODY_SESSION_BUNDLE_LIMIT",
        "retained accepted bundle exceeds the exact V22 byte bound");
    publish_handoff_file(options.output, encoded);
    return CustodySessionServiceResult{
        .status = 0,
        .json =
            "{\"format\":\"NATRAV_NATIVE_CUSTODY_SESSION_EXPORT_V1\""
            ",\"status\":\"EXPORTED_RETAINED_CUSTODY_NOT_FORWARDED\""
            ",\"request_id\":" +
                json_string(operation_id_text(options.request_id)) +
            ",\"envelope_sha256\":" +
                json_string(operation_id_text(envelope_sha256)) +
            ",\"capsule_sha256\":" +
                json_string(operation_id_text(custody.envelope.capsule_sha256)) +
            ",\"current_party_index\":" +
                std::to_string(custody.progress.current_party_index) +
            ",\"records\":" + std::to_string(custody.records.size()) +
            ",\"automatic_route_relay\":false"
            ",\"application_delivery_inferred\":false}",
    };
}

int run_custody_session_server(
    const CustodySessionServiceOptions& options) {
    const auto seed = load_runtime_config(options.config);
    require_handoff_state_owner(seed.state_directory);
    NodeState state(seed.state_directory, seed.local_node,
        seed.maximum_journal_bytes, seed.queue_limits);
    RuntimeConfiguration runtime(seed, state);
    const auto config = runtime.snapshot();
    const auto authority = resolve_authority(state, *config, options, ServiceOperation::receive);
    require(authority.rule->state != CustodySessionRuleState::revoked &&
            authority.grant->state != CustodyRelayGrantState::revoked,
        "CUSTODY_SESSION_REVOKED",
        "revoked custody service authority cannot run a receiver");

    struct sigaction action {};
    action.sa_handler = service_stop_handler;
    ::sigemptyset(&action.sa_mask);
    action.sa_flags = 0;
    require(::sigaction(SIGTERM, &action, nullptr) == 0 &&
            ::sigaction(SIGINT, &action, nullptr) == 0,
        "SIGNAL_SETUP_FAILED", "unable to install custody service signals");
    service_stop_requested = 0;

    TlsContext tls(config->identity);
    auto listener = listen_transport(config->listen_locator, config->backlog);
    std::cout << "{\"format\":\"NATRAV_NATIVE_CUSTODY_SESSION_READY_V1\""
              << ",\"node\":" << json_string(config->local_node)
              << ",\"listen\":"
              << json_string(transport_locator_text(listener->bound_locator()))
              << ",\"rule_id\":" << json_string(authority.rule->id)
              << ",\"rule_generation\":"
              << authority.rule->generation
              << ",\"transport\":\"NOS1_BOUNDED_REUSE_V1\"}"
              << std::endl;

    std::size_t accepted_connections = 0U;
    std::size_t rejected_connections = 0U;
    while (service_stop_requested == 0) {
        if (poll_listener(listener->readiness_handle()) == 0) { break; }
        while (true) {
            auto connection = listener->accept_ready();
            if (!connection) { break; }
            ++accepted_connections;
            const auto outcome = handle_secure_peer_connection(
                *connection, state, tls, config->trusted_peers,
                config->authorization, config->local_node, config->io,
                config->sessions, {}, {},
                [&](const TlsSessionInfo& session,
                    const CustodyTransferOffer& offer) {
                    return receive_offer(state, authority, session, offer);
                });
            if (outcome.rejected || outcome.transport_error) {
                ++rejected_connections;
            }
            std::cout << "{\"format\":\"NATRAV_NATIVE_CUSTODY_SESSION_CONNECTION_V1\""
                      << ",\"authenticated\":"
                      << (outcome.authenticated ? "true" : "false")
                      << ",\"session_protocol\":"
                      << (outcome.session_protocol ? "true" : "false")
                      << ",\"operations\":" << outcome.operations
                      << ",\"rejected\":"
                      << (outcome.rejected ? "true" : "false")
                      << ",\"transport_error\":"
                      << (outcome.transport_error ? "true" : "false")
                      << "}" << std::endl;
            if (options.once) { service_stop_requested = 1; break; }
        }
    }
    std::cout << "{\"format\":\"NATRAV_NATIVE_CUSTODY_SESSION_STOP_V1\""
              << ",\"accepted_connections\":" << accepted_connections
              << ",\"rejected_connections\":" << rejected_connections
              << "}" << std::endl;
    return rejected_connections == 0U ? 0 : 3;
}

std::string custody_session_service_version_json() {
    return "{\"format\":\"NATRAV_NATIVE_CUSTODY_SESSION_VERSION_V1\""
        ",\"revision\":\"0613\""
        ",\"service\":\"NATIVE_DURABLE_CUSTODY_SESSION_SERVICE_V1\""
        ",\"transport\":\"NOS1_BOUNDED_REUSE_V1\""
        ",\"retained_bundle_export\":\"EXPLICIT_CURRENT_CUSTODIAN_BUNDLE_EXPORT_V1\""
        ",\"configured_custody_relay\":true"
        ",\"passive_daemon_custody_receiver\":\"V23_DEFAULT_OFF_EXACT_RULE_V1\""
        ",\"explicit_owner_custody_dispatch\":\"V24_SYNCHRONOUS_ONE_ATTEMPT_V1\""
        ",\"automatic_custody_sender\":false"
        ",\"automatic_route_relay\":false"
        ",\"open_relay\":false"
        ",\"application_delivery_inferred\":false}";
}

} // namespace natrav_overlay
