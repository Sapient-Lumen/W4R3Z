#pragma once
#include "handoff_capsule.hpp"
#include "config.hpp"
#include <memory>

namespace natrav_overlay {
inline constexpr std::size_t kHandoffArtifactLimit = 72'000U;
using HandoffSigner = std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)>;
struct HandoffLocalKey final {
    HandoffBinding binding;
    HandoffKeyBytes secret{};
    HandoffLocalKey() = default;
    ~HandoffLocalKey();
    HandoffLocalKey(const HandoffLocalKey&) = delete;
    HandoffLocalKey& operator=(const HandoffLocalKey&) = delete;
};
[[nodiscard]] HandoffSigner load_handoff_signer(const RuntimeConfig& config);
[[nodiscard]] std::unique_ptr<HandoffLocalKey> load_handoff_key(
    const std::filesystem::path& directory, const RuntimeConfig& config);
[[nodiscard]] HandoffBinding create_handoff_key(const std::filesystem::path& directory,
    const RuntimeConfig& config, std::string_view handoff_generation);
[[nodiscard]] datacube::Octets read_handoff_file(const std::filesystem::path& path,
    std::size_t limit, bool secret = false);
void publish_handoff_file(const std::filesystem::path& destination, datacube::OctetView bytes);
void handoff_test_pause(const char* name);
// Owner-only offline operations, not delegated daemon control commands.
void require_handoff_state_owner(const std::filesystem::path& directory);
} // namespace natrav_overlay
