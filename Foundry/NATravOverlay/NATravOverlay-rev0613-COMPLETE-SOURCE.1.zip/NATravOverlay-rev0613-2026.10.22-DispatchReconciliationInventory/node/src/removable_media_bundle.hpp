#pragma once

#include "datacube/core.hpp"

#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>

namespace natrav_overlay::removable_media {

inline constexpr char kRemovableMediaPacketBundleMarker[] =
    "REMOVABLE_MEDIA_PACKET_BUNDLE_V1";
inline constexpr std::size_t kBundleDigestBytes = 32U;
inline constexpr std::size_t kBundleOverheadBytes = 76U;
inline constexpr std::uint64_t kMaximumClockSkewMs = 300'000U;

class BundleError final : public std::runtime_error {
public:
    BundleError(std::string code, std::string detail);
    [[nodiscard]] const std::string& code() const noexcept;

private:
    std::string code_;
};

struct Settings final {
    std::size_t mtu{512U};
    std::uint64_t link{0U};
    std::uint32_t epoch{0U};
    std::uint64_t lifetime_ms{10'000U};

    void validate() const;
    friend bool operator==(const Settings&, const Settings&) = default;
};

struct DecodedBundle final {
    datacube::Octets payload{};
    datacube::Digest32 digest{};
    std::uint64_t created_ms{0U};
    std::uint64_t expires_ms{0U};
};

[[nodiscard]] datacube::Octets encode(
    const Settings& settings,
    std::span<const std::uint8_t> payload,
    std::uint64_t created_ms);

[[nodiscard]] DecodedBundle decode(
    const Settings& settings,
    std::span<const std::uint8_t> bytes,
    const datacube::Digest32& filename_digest,
    std::uint64_t now_ms);

[[nodiscard]] std::string filename(const datacube::Digest32& digest);
[[nodiscard]] std::optional<datacube::Digest32> parse_filename(
    std::string_view name) noexcept;

}  // namespace natrav_overlay::removable_media
