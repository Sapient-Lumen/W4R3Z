#pragma once

#include "consumer.hpp"
#include <vector>

namespace natrav_overlay {
// A finite durable delegation. Completed and stopped grants remain attributable;
// the worker never fabricates socket credentials for a disconnected owner.
struct ProjectionGrant final {
    std::uint64_t epoch{0U}, configuration_event{0U}, unix_ms{0U};
    std::uint32_t pid{0U}, maximum_pages{0U}, minimum_interval_ms{0U};
    datacube::Digest32 authority{};
    std::string reason;
    std::uint64_t start_position{0U}, position{0U}, pages{0U};
    std::string state{"ENABLED"}, error;
    std::uint64_t ended_event{0U}, ended_unix_ms{0U};
    std::uint32_t ended_pid{0U}, ended_uid{0U};
    bool operator==(const ProjectionGrant&) const = default;
};
struct ProjectionSchedule final {
    std::string name;
    std::uint32_t uid{0U};
    datacube::Digest32 instance{};
    std::uint64_t revision{0U}, configuration_event{0U}, unix_ms{0U};
    std::uint32_t executor_uid{0U}, pid{0U};
    std::string transition;
    std::vector<ProjectionGrant> grants;
    bool operator==(const ProjectionSchedule&) const = default;
};
struct ProjectionCandidate final {
    std::string key;
    std::uint64_t generation{0U};
    std::uint32_t minimum_interval_ms{0U};
};
inline constexpr std::size_t kProjectionGrantLimit=32U;
[[nodiscard]] datacube::Octets encode_projection_schedule(const ProjectionSchedule& value);
[[nodiscard]] ProjectionSchedule decode_projection_schedule(datacube::OctetView bytes);
[[nodiscard]] std::string projection_schedule_json(const ProjectionSchedule& value,bool history);
} // namespace natrav_overlay
