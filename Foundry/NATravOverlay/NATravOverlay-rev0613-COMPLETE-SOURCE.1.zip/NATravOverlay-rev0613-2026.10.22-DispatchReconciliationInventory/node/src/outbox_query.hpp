#pragma once
#include "common.hpp"
#include <chrono>
#include <cstdint>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace natrav_overlay {
// All filters are exact and conjunctive. INSPECT is node-wide administrative
// metadata authority; this API never grants access to payload bytes.
struct OutboxQuery final {
    std::optional<datacube::Digest32> operation_id;
    std::string recipient;
    std::string state;
    std::uint32_t maximum_records{32U};
    std::uint32_t maximum_response_bytes{60'000U};
    std::uint32_t history_limit{4U};
    std::string cursor;
};
struct OutboxQueryContext final {
    std::uint32_t uid{0U};
    datacube::Digest32 configuration_digest{};
    std::chrono::steady_clock::time_point deadline{std::chrono::steady_clock::time_point::max()};
};
void validate_outbox_query(const OutboxQuery& query);
[[nodiscard]] datacube::Octets encode_outbox_query(const OutboxQuery& query);
[[nodiscard]] OutboxQuery decode_outbox_query(datacube::OctetView bytes);

// Reconstructed indexes, not a separately trusted store. Every semantic outbox
// mutation touches the old/new selection and exact-operation revision. Revisions
// are run-local and must never be used as durable or external freshness anchors.
class OutboxInspectionIndex final {
public:
    struct Bucket final {
        std::set<std::size_t> records;
        std::uint64_t revision{0U};
    };
    void touch(std::size_t index, const std::string& recipient, const std::string& state);
    [[nodiscard]] const Bucket& select(const std::string& recipient, const std::string& state) const;
    [[nodiscard]] std::uint64_t revision(std::size_t index) const;
    [[nodiscard]] const std::string& state(std::size_t index) const;
private:
    std::uint64_t clock_{0U};
    std::map<std::pair<std::string,std::string>,Bucket> buckets_;
    std::vector<std::string> states_;
    std::vector<std::uint64_t> revisions_;
};
} // namespace natrav_overlay
