#pragma once

#include "config.hpp"
#include "custody_state.hpp"

namespace natrav_overlay {

[[nodiscard]] datacube::Digest32 custody_party_configured_pin(
    const RuntimeConfig& config, const CustodyParty& party,
    bool require_active);
void require_custody_party_authorized(
    const RuntimeConfig& config, const CustodyParty& party,
    bool require_active);
[[nodiscard]] const CustodyRelayGrant& resolve_custody_grant_reference(
    const RuntimeConfig& config, const CustodyGrantReference& reference,
    const CustodyEnvelope& envelope, std::size_t hop_index,
    bool require_active);
void require_custody_registration_authority(
    const RuntimeConfig& config, const CustodyEnvelope& envelope,
    std::span<const CustodyGrantReference> grants,
    bool require_active);

} // namespace natrav_overlay
