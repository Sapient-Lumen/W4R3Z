#pragma once
#include "evidence_feed.hpp"
#include "projection.hpp"
#include <optional>
#include <vector>
namespace natrav_overlay {
enum class ConsumerCommand : std::uint8_t { create=1U, read=2U, acknowledge=3U, status=4U, reset=5U, projection_create=6U, projection_process=7U, projection_status=8U, projection_rebuild=9U, projection_enable=10U, projection_pause=11U, projection_schedule_status=12U, retire=13U, retirement_status=14U, projection_publish=15U };
inline bool schedule_command(ConsumerCommand c) { return c>=ConsumerCommand::projection_enable && c<=ConsumerCommand::projection_schedule_status; }
inline bool retirement_command(ConsumerCommand c) { return c==ConsumerCommand::retire || c==ConsumerCommand::retirement_status; }
inline bool publication_command(ConsumerCommand c) { return c==ConsumerCommand::projection_publish; }
inline bool consumer_create(ConsumerCommand c) { return c==ConsumerCommand::create || c==ConsumerCommand::projection_create; }
inline bool consumer_status(ConsumerCommand c) { return c==ConsumerCommand::status || c==ConsumerCommand::projection_status || c==ConsumerCommand::projection_schedule_status || c==ConsumerCommand::retirement_status; }
inline bool consumer_reset(ConsumerCommand c) { return c==ConsumerCommand::reset || c==ConsumerCommand::projection_rebuild; }
inline bool consumer_ack(ConsumerCommand c) { return c==ConsumerCommand::acknowledge || c==ConsumerCommand::projection_process; }
inline bool projection_command(ConsumerCommand c) { return (c>=ConsumerCommand::projection_create && c<=ConsumerCommand::projection_schedule_status) || publication_command(c); }
struct ConsumerRequest final {
    ConsumerCommand command{ConsumerCommand::status};
    std::string name;
    EvidenceFeed selection;
    std::optional<datacube::Digest32> batch_id;
    std::uint64_t expected_revision{0U};
    std::optional<datacube::Digest32> expected_instance;
    std::optional<datacube::Digest32> expected_result_digest;
    std::uint64_t expected_position{0U};
    std::string publication_recipient;
    std::string publication_scope;
    std::uint64_t expected_schedule_revision{0U};
    bool abandon_pending{false};
    std::string reason;
    std::uint64_t maximum_admissions{100000U};
    std::optional<NumericDefinition> numeric;
    std::uint32_t automatic_maximum_pages{100U}, automatic_minimum_interval_ms{100U};
};
struct ConsumerBatch final {
    datacube::Digest32 id{};
    std::uint64_t from{0U}, through{0U};
    datacube::Digest32 rows_digest{};
    std::uint64_t configuration_event{0U}, unix_ms{0U};
    std::uint32_t pid{0U};
    bool operator==(const ConsumerBatch&) const = default;
};
struct ConsumerAdoption final {
    std::uint64_t epoch{0U}, from{0U}, to{0U};
    bool from_now{false};
    std::uint64_t configuration_event{0U}, unix_ms{0U};
    std::uint32_t pid{0U};
    datacube::Digest32 authority{};
    std::optional<datacube::Digest32> abandoned_batch;
    std::string reason;
    bool operator==(const ConsumerAdoption&) const = default;
};
// Terminal, permanent name reservation. The base consumer is frozen exactly;
// the new lifecycle revision is separate from the last computation revision.
struct ConsumerRetirement final {
    std::uint64_t revision{0U}, configuration_event{0U}, unix_ms{0U};
    std::uint32_t pid{0U}; // owner UID is the containing consumer's kernel namespace
    std::uint64_t previous_schedule_revision{0U};
    bool abandoned_pending{false};
    datacube::Digest32 final_consumer_digest{}, final_schedule_digest{};
    std::string reason;
};
struct DurableConsumer final {
    std::string name;
    std::uint32_t uid{0U};
    datacube::Digest32 instance{};
    EvidenceFeed selection; // immutable filters, mode and finite page bounds
    std::uint64_t revision{0U}, position{0U}, acknowledgments{0U};
    std::optional<ConsumerBatch> pending, last_ack;
    std::vector<ConsumerAdoption> adoptions; // creation plus at most 31 resets
    std::optional<EvidenceProjection> projection;
    std::optional<ConsumerRetirement> retirement;
    std::string transition;
    std::uint64_t configuration_event{0U}, unix_ms{0U};
    std::uint32_t pid{0U};
};
inline constexpr std::size_t kConsumerLimit=128U, kConsumerUidLimit=16U, kConsumerAdoptionLimit=32U;
inline constexpr std::size_t kRetiredConsumerLimit=256U, kRetiredConsumerUidLimit=64U;
inline constexpr std::size_t kStoredConsumerLimit=kConsumerLimit+kRetiredConsumerLimit;
inline constexpr std::size_t kConsumerEncodedLimit=65536U;
[[nodiscard]] std::string consumer_retirement_json(const ConsumerRetirement& value);
void validate_consumer_request(const ConsumerRequest& request);
[[nodiscard]] datacube::Octets encode_consumer_request(const ConsumerRequest& request);
[[nodiscard]] ConsumerRequest decode_consumer_request(datacube::OctetView bytes);
[[nodiscard]] datacube::Octets encode_consumer(const DurableConsumer& value);
[[nodiscard]] DurableConsumer decode_consumer(datacube::OctetView bytes);
[[nodiscard]] std::string consumer_key(std::uint32_t uid, std::string_view name);
[[nodiscard]] datacube::Digest32 projection_result_digest(const DurableConsumer& value);
[[nodiscard]] datacube::Digest32 projection_publication_authority(
    const DurableConsumer& value, std::string_view recipient,
    std::string_view recipient_generation,
    const datacube::Digest32& recipient_spki_sha256, std::string_view scope,
    const EvidenceQueryContext& context);
[[nodiscard]] datacube::Octets projection_publication_payload(
    const DurableConsumer& value, std::string_view recipient,
    std::string_view recipient_generation,
    const datacube::Digest32& recipient_spki_sha256, std::string_view scope,
    const EvidenceQueryContext& context);
[[nodiscard]] datacube::Digest32 projection_publication_operation(
    datacube::OctetView payload);
[[nodiscard]] std::string consumer_json(const DurableConsumer& value, bool include_history);
} // namespace natrav_overlay
