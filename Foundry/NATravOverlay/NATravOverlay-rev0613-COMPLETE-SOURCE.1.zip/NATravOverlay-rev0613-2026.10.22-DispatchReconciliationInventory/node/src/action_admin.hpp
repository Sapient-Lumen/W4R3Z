#pragma once
#include "common.hpp"
#include <cstddef>
#include <cstdint>
#include <string>

namespace natrav_overlay {

struct ActionAdminRequest final {
    datacube::Digest32 action{};
    datacube::Digest32 expected_state{};
    datacube::Digest32 expected_configuration{};
    std::string reason;
};

struct ActionAdminRecord final {
    ActionAdminRequest request;
    std::uint32_t uid{0U};
    std::uint32_t gid{0U};
    std::uint32_t pid{0U};
    std::uint64_t unix_ms{0U};
    std::uint64_t configuration_event{0U};
    datacube::Digest32 request_digest{};
    datacube::Digest32 prior_admin_root{};
    datacube::Digest32 resulting_metadata_digest{};
    datacube::Octets before_metadata;
};

inline constexpr std::size_t kActionAdminLimit = 1024U;
inline constexpr std::size_t kActionAdminPerActionLimit = 1U;
inline constexpr std::size_t kActionAdminMetadataLimit = 32'768U;

void validate_action_admin_request(const ActionAdminRequest& request);
[[nodiscard]] datacube::Octets encode_action_admin_request(
    const ActionAdminRequest& request);
[[nodiscard]] ActionAdminRequest decode_action_admin_request(
    datacube::OctetView bytes);
[[nodiscard]] datacube::Digest32 action_admin_request_digest(
    const ActionAdminRequest& request,
    std::uint32_t uid);
[[nodiscard]] datacube::Digest32 action_selected_digest(
    datacube::OctetView metadata,
    const datacube::Digest32& previous_admin_root);
[[nodiscard]] datacube::Octets encode_action_admin_record(
    const ActionAdminRecord& record);
[[nodiscard]] ActionAdminRecord decode_action_admin_record(
    datacube::OctetView bytes);
[[nodiscard]] std::string action_admin_record_json(
    const ActionAdminRecord& record);

}  // namespace natrav_overlay
