#pragma once

#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {
struct PeerQueueUsage final {
    std::string peer;
    std::uint64_t pending_records{0U};
    std::uint64_t pending_payload_bytes{0U};
    std::uint64_t future_result_records{0U};
    std::uint64_t future_result_payload_bytes{0U};
    bool operator==(const PeerQueueUsage&) const = default;
};
struct QueueUsage final {
    std::uint64_t pending_records{0U};
    std::uint64_t pending_payload_bytes{0U};
    std::vector<PeerQueueUsage> peers;
    std::uint64_t future_result_records{0U};
    std::uint64_t future_result_payload_bytes{0U};
    bool operator==(const QueueUsage&) const = default;
};
struct PendingCapacityTotals final {
    std::uint64_t records{0U};
    std::uint64_t payload_bytes{0U};
    bool operator==(const PendingCapacityTotals&) const = default;
};
enum class PendingCapacityChange { unchanged, acquired, released };

// A derivative of accepted outbox state, never serialized or independently
// authoritative. Queue positions, recipients and payload sizes are immutable.
// Only pending entries consume index memory. Repeated notifications of the same
// state are idempotent; metadata-only changes do not recharge reservations.
// NodeState owns synchronization. Checked arithmetic and allocation failures
// leave this index unchanged; a failed journal apply poisons the owning writer.
class PendingCapacityIndex final {
public:
    [[nodiscard]] PendingCapacityChange update(std::size_t index,
        std::string_view recipient, std::uint64_t payload_bytes, bool pending);
    [[nodiscard]] PendingCapacityTotals total() const noexcept { return total_; }
    [[nodiscard]] PendingCapacityTotals peer(std::string_view recipient) const;
    [[nodiscard]] QueueUsage snapshot() const;
    [[nodiscard]] bool matches(std::size_t index, std::string_view recipient,
        std::uint64_t bytes) const;
    [[nodiscard]] std::size_t entries() const noexcept { return entries_.size(); }
    [[nodiscard]] std::size_t peers() const noexcept { return peers_.size(); }
private:
    struct Entry final {
        std::string recipient;
        std::uint64_t payload_bytes{0U};
    };
    std::map<std::size_t, Entry> entries_;
    std::map<std::string, PendingCapacityTotals, std::less<>> peers_;
    PendingCapacityTotals total_;
};
} // namespace natrav_overlay
