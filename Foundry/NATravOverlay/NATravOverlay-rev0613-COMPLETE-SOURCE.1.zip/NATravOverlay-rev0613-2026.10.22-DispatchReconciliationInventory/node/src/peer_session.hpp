#pragma once

#include "socket.hpp"
#include "tls.hpp"
#include "transport.hpp"

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string_view>

namespace natrav_overlay {

struct PeerSessionOpenCounters final {
    IoCounters connect;
    IoCounters tls;
    IoCounters handshake;
    IoCounters session;
};

class OutboundPeerSession final {
public:
    ~OutboundPeerSession();
    OutboundPeerSession(const OutboundPeerSession&) = delete;
    OutboundPeerSession& operator=(const OutboundPeerSession&) = delete;
    OutboundPeerSession(OutboundPeerSession&&) noexcept;
    OutboundPeerSession& operator=(OutboundPeerSession&&) noexcept;

    [[nodiscard]] static OutboundPeerSession open(
        TlsContext& tls,
        std::string_view local_node,
        std::string_view expected_peer,
        std::string_view expected_peer_generation,
        KeyGenerationState expected_peer_key_state,
        const datacube::Digest32& expected_peer_spki_sha256,
        const TransportLocator& locator,
        const EvidenceRecord& first_record,
        const IoOptions& io,
        const PeerSessionLimits& requested_limits);
    [[nodiscard]] static OutboundPeerSession open(
        TlsContext& tls,
        std::string_view local_node,
        std::string_view expected_peer,
        std::string_view expected_peer_generation,
        KeyGenerationState expected_peer_key_state,
        const datacube::Digest32& expected_peer_spki_sha256,
        const TransportLocator& locator,
        const datacube::Digest32& first_operation_id,
        const IoOptions& io,
        const PeerSessionLimits& requested_limits,
        const TransportConnector* authorized_connector = nullptr);

    // Internal carrier fixture seam: consumes an already connected owned
    // stream while preserving the exact TLS, HELLO, NOS1, and application
    // implementation. It is not reachable from route configuration.
    [[nodiscard]] static OutboundPeerSession open_connected(
        TlsContext& tls,
        std::string_view local_node,
        std::string_view expected_peer,
        std::string_view expected_peer_generation,
        KeyGenerationState expected_peer_key_state,
        const datacube::Digest32& expected_peer_spki_sha256,
        std::unique_ptr<OrderedByteStream> stream,
        const datacube::Digest32& first_operation_id,
        const IoOptions& io,
        const PeerSessionLimits& requested_limits);

    [[nodiscard]] bool reusable() const noexcept;
    [[nodiscard]] std::chrono::milliseconds retirement_delay() const noexcept;
    [[nodiscard]] bool usable_for(
        std::string_view expected_peer_generation,
        const datacube::Digest32& expected_peer_spki_sha256,
        const EvidenceRecord& record) const;

    [[nodiscard]] bool usable_for_encoded_size(std::string_view expected_peer_generation,
        const datacube::Digest32& expected_peer_spki_sha256, std::size_t application_bytes) const;

    [[nodiscard]] DeliveryReceipt exchange(
        const EvidenceRecord& record,
        const IoOptions& io);
    [[nodiscard]] ApplicationMessage exchange_message(
        const datacube::Digest32& operation_id,
        const ApplicationMessage& message,
        const IoOptions& io);

    [[nodiscard]] bool close_cleanly(const IoOptions& io) noexcept;
    [[nodiscard]] bool peer_requested_retirement() const noexcept;
    [[nodiscard]] std::uint64_t operations() const noexcept;
    [[nodiscard]] std::uint64_t session_bytes() const noexcept;
    [[nodiscard]] const TlsSessionInfo& tls_session() const noexcept;
    [[nodiscard]] const PeerSessionLimits& negotiated_limits() const noexcept;
    [[nodiscard]] const PeerSessionOpenCounters& open_counters() const noexcept;
    [[nodiscard]] const IoCounters& application_counters() const noexcept;

private:
    struct State;
    [[nodiscard]] static OutboundPeerSession open_connected_impl(
        TlsContext& tls,
        std::string_view local_node,
        std::string_view expected_peer,
        std::string_view expected_peer_generation,
        KeyGenerationState expected_peer_key_state,
        const datacube::Digest32& expected_peer_spki_sha256,
        std::unique_ptr<OrderedByteStream> stream,
        const datacube::Digest32& first_operation_id,
        const IoOptions& io,
        const PeerSessionLimits& requested_limits,
        Deadline deadline,
        PeerSessionOpenCounters counters);
    explicit OutboundPeerSession(std::unique_ptr<State> state) noexcept;
    std::unique_ptr<State> state_;
};

}  // namespace natrav_overlay
