#pragma once

#include "authorization.hpp"
#include "adapter_configuration.hpp"
#include "handoff_policy.hpp"
#include "custody_policy.hpp"
#include "custody_session_policy.hpp"
#include "custody_receiver_policy.hpp"
#include "custody_dispatch_policy.hpp"
#include "local_author.hpp"
#include "subscribed_source.hpp"
#include "source_subscription.hpp"
#include "journal.hpp"
#include "local_control.hpp"
#include "read_policy.hpp"
#include "tls.hpp"
#include "transport.hpp"

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

struct DeliveryPolicy final {
    std::uint32_t initial_backoff_ms{100U};
    std::uint32_t maximum_backoff_ms{5'000U};
    std::uint32_t maximum_attempts{20U};
    std::uint64_t expiry_ms{86'400'000U};
};

struct PeerKeyGeneration final {
    std::string node_id;
    std::string generation;
    KeyGenerationState state{KeyGenerationState::retired};
    datacube::Digest32 spki_sha256;
};

enum class PeerRouteState : std::uint8_t {
    enabled = 1U,
    disabled = 2U,
};

struct PeerRouteConfig final {
    std::string route_id;
    TransportLocator locator;
    std::uint32_t priority{0U};
    PeerRouteState state{PeerRouteState::enabled};
};

struct PeerConfig final {
    std::string node_id;
    std::vector<PeerRouteConfig> routes;
    std::string active_generation;
    datacube::Digest32 active_spki_sha256;
    DeliveryPolicy delivery;
};

struct RuntimeConfig final {
    std::uint32_t format_version{6U};
    // Empty for the explicit V6 startup-only compatibility mode.
    std::string runtime_generation;
    std::filesystem::path source_path;
    std::filesystem::path state_directory;
    std::filesystem::path control_socket;
    std::string local_node;
    std::string local_identity_generation;
    TlsIdentityFiles identity;
    TransportLocator listen_locator;
    IoOptions io;
    PeerSessionLimits sessions;
    std::uint64_t maximum_journal_bytes{67'108'864U};
    QueueLimits queue_limits;
    std::size_t peer_workers{4U};
    std::size_t peer_queue_capacity{64U};
    std::size_t control_workers{2U};
    std::size_t control_queue_capacity{64U};
    int backlog{64};
    std::vector<PeerConfig> peers;
    std::vector<PeerKeyGeneration> peer_generations;
    std::vector<TlsTrustedIdentity> trusted_peers;
    AuthorizationPolicy authorization;
    ActionResultPolicy action_results;
    LocalControlPolicy local_control;
    EvidenceReadPolicy evidence_read;
    LocalAuthorPolicy evidence_author;
    SourceDisclosurePolicy source_disclosure;
    SourceViewPolicy source_views;
    RuntimeAdapterConfiguration adapter_configuration;
    HandoffKeyPolicy handoff_keys;
    CustodyRelayPolicy custody_relay;
    CustodySessionPolicy custody_sessions;
    CustodyReceiverPolicy custody_receivers;
    CustodyDispatchPolicy custody_dispatch;
};

enum class IdentityFileValidation {
    required,
    deferred,
};

[[nodiscard]] RuntimeConfig load_runtime_config(
    const std::filesystem::path& path);
[[nodiscard]] RuntimeConfig parse_runtime_config(
    std::string_view text,
    const std::filesystem::path& origin,
    IdentityFileValidation identity_validation =
        IdentityFileValidation::required);
[[nodiscard]] std::string canonical_runtime_config(const RuntimeConfig& config);
[[nodiscard]] datacube::Digest32 runtime_configuration_digest(
    std::string_view canonical);
[[nodiscard]] bool runtime_owner_boundary_equal(
    const RuntimeConfig& left,
    const RuntimeConfig& right);
[[nodiscard]] bool runtime_relocation_only_change(
    const RuntimeConfig& before,
    const RuntimeConfig& after);
[[nodiscard]] std::string peer_runtime_contract(
    const RuntimeConfig& config, std::string_view peer);
[[nodiscard]] std::string peer_route_runtime_contract(
    const RuntimeConfig& config, std::string_view peer, std::string_view route_id);
[[nodiscard]] std::string_view peer_route_state_name(
    PeerRouteState state) noexcept;
[[nodiscard]] const PeerConfig* find_peer(
    const RuntimeConfig& config,
    std::string_view node_id) noexcept;
[[nodiscard]] const PeerRouteConfig* find_peer_route(
    const PeerConfig& peer,
    std::string_view route_id) noexcept;
[[nodiscard]] const PeerKeyGeneration* find_peer_generation(
    const RuntimeConfig& config,
    std::string_view node_id,
    std::string_view generation) noexcept;
[[nodiscard]] const PeerKeyGeneration* find_peer_generation_by_pin(
    const RuntimeConfig& config,
    std::string_view node_id,
    const datacube::Digest32& pin) noexcept;
[[nodiscard]] std::string runtime_config_json(const RuntimeConfig& config);

}  // namespace natrav_overlay
