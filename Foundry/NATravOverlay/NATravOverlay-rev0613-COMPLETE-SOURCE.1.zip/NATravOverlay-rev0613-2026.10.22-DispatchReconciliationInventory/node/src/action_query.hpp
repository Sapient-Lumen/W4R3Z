#pragma once
#include "common.hpp"
#include <chrono>
#include <cstdint>
#include <optional>
#include <string>
namespace natrav_overlay {
// INSPECT is node-wide administrative metadata authority, not payload access.
struct ActionQuery final {
    std::optional<datacube::Digest32> action_id;
    std::string issuer;
    std::string state;
    std::uint32_t maximum_records{16U};
    std::uint32_t maximum_response_bytes{60'000U};
    std::string cursor;
};
struct ActionQueryContext final {
    std::uint32_t uid{0U};
    datacube::Digest32 configuration_digest{};
    std::chrono::steady_clock::time_point deadline{std::chrono::steady_clock::time_point::max()};
};
void validate_action_query(const ActionQuery& query);
[[nodiscard]] datacube::Octets encode_action_query(const ActionQuery& query);
[[nodiscard]] ActionQuery decode_action_query(datacube::OctetView bytes);
} // namespace natrav_overlay
