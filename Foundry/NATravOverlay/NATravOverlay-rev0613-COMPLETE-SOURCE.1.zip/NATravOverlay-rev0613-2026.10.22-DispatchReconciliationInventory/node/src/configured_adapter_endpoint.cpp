#include "configured_adapter_endpoint.hpp"

#include <cstdint>
#include <string_view>
#include <utility>

namespace natrav_overlay {

int configured_external_adapter_endpoint_revision_abi() noexcept { return 1; }

PreparedConfiguredAdapterEndpoint prepare_configured_external_adapter_endpoint(
    const DurableAdapterProfileCatalog& catalog,
    const std::string_view endpoint_id,
    const std::uint64_t endpoint_generation) {
    const auto resolved = catalog.resolve_endpoint(endpoint_id, endpoint_generation);
    auto options = external_packet_adapter_options_from_profile(resolved.profile);
    if (!options.pinned_profile.has_value() ||
        options.pinned_profile.value() != resolved.profile ||
        options.pinned_profile_sha256 != resolved.profile_sha256 ||
        options.verified_executable == nullptr ||
        options.verified_executable->sha256() !=
            resolved.profile.executable_sha256) {
        throw AdapterCatalogError(
            "ADAPTER_CATALOG_PREPARATION_DRIFT",
            "configured endpoint did not produce exact profile-backed options");
    }
    return PreparedConfiguredAdapterEndpoint{
        .endpoint = resolved.endpoint,
        .endpoint_sha256 = resolved.endpoint_sha256,
        .profile_sha256 = resolved.profile_sha256,
        .options = std::move(options),
    };
}

}  // namespace natrav_overlay
