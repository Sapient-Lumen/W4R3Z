#pragma once
#include "common.hpp"
#include <cstdint>
#include <string>

namespace natrav_overlay {
enum class OutboxAdminKind : std::uint8_t { cancel=1U, retry=2U, rebind=3U };
struct OutboxAdminRequest final {
    OutboxAdminKind kind{OutboxAdminKind::cancel};
    datacube::Digest32 operation{};
    datacube::Digest32 expected_state{};
    datacube::Digest32 expected_configuration{};
    std::string generation;
    std::string reason;
};
struct OutboxAdminRecord final {
    OutboxAdminRequest request;
    std::uint32_t uid{0U}, gid{0U}, pid{0U};
    std::uint64_t unix_ms{0U}, configuration_event{0U};
    datacube::Digest32 request_digest{}, prior_admin_root{}, resulting_metadata_digest{};
    std::uint8_t restrictions{0U};
    datacube::Octets before_metadata;
};
inline constexpr std::size_t kOutboxAdminLimit=1024U;
inline constexpr std::size_t kOutboxAdminPerOperationLimit=32U;
inline constexpr std::size_t kOutboxAdminMetadataLimit=32768U;
void validate_outbox_admin_request(const OutboxAdminRequest&);
[[nodiscard]] datacube::Octets encode_outbox_admin_request(const OutboxAdminRequest&);
[[nodiscard]] OutboxAdminRequest decode_outbox_admin_request(datacube::OctetView);
[[nodiscard]] datacube::Digest32 outbox_admin_request_digest(const OutboxAdminRequest&,std::uint32_t uid);
[[nodiscard]] datacube::Octets encode_outbox_admin_record(const OutboxAdminRecord&);
[[nodiscard]] OutboxAdminRecord decode_outbox_admin_record(datacube::OctetView);
[[nodiscard]] datacube::Digest32 outbox_selected_digest(datacube::OctetView metadata,
    std::uint8_t restrictions,const datacube::Digest32& previous_admin);
[[nodiscard]] std::string_view outbox_admin_kind_name(OutboxAdminKind);
[[nodiscard]] std::string outbox_admin_record_json(const OutboxAdminRecord&);
} // namespace natrav_overlay
