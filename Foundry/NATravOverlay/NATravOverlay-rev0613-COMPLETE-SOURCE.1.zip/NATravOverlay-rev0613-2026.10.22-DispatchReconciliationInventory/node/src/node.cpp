#include "node.hpp"
#include "config.hpp"
#include "state_head_custody.hpp"

#include "datacube/natrav_peer_stream.hpp"

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <condition_variable>
#include <csignal>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <deque>
#include <iostream>
#include <map>
#include <mutex>
#include <optional>
#include <poll.h>
#include <string>
#include <string_view>
#include <thread>
#include <unistd.h>
#include <utility>
#include <vector>

namespace natrav_overlay {
namespace {

volatile sig_atomic_t stop_requested = 0;

void stop_handler(int) { stop_requested = 1; }

std::atomic<bool> test_session_drop_consumed{false};

[[nodiscard]] bool test_drop_after_admission(
    const datacube::Digest32& operation_id) {
    const char* configured = std::getenv(
        "NATRAV_OVERLAY_TEST_SESSION_DROP_AFTER_ADMISSION_OPERATION");
    if (configured == nullptr || *configured == '\0' ||
        operation_id_text(operation_id) != configured) {
        return false;
    }
    bool expected = false;
    return test_session_drop_consumed.compare_exchange_strong(expected, true);
}

[[nodiscard]] std::string request_id_for(const EvidenceRecord& record) {
    datacube::Octets bytes;
    constexpr std::string_view domain = "NATRAV_OVERLAY_SOCKET_REQUEST_V1";
    const auto operation = operation_id_text(record.operation_id);
    const auto monotonic = datacube::monotonic_nanoseconds();
    bytes.reserve(domain.size() + 1U + operation.size() + 16U);
    datacube::append_text(bytes, domain);
    datacube::append_u8(bytes, 0U);
    datacube::append_text(bytes, operation);
    datacube::append_be64(bytes, monotonic);
    datacube::append_be64(bytes, static_cast<std::uint64_t>(::getpid()));
    return datacube::hex_lower(datacube::sha256(bytes));
}

[[nodiscard]] std::string safe_protocol_detail(std::string_view value) {
    std::string result;
    result.reserve(std::min<std::size_t>(value.size(), 512U));
    for (const char raw : value) {
        if (result.size() == 512U) {
            break;
        }
        const auto ch = static_cast<unsigned char>(raw);
        result.push_back(ch == 9U || (ch >= 32U && ch <= 126U) ? raw : '?');
    }
    return result;
}

[[nodiscard]] std::uint64_t unix_milliseconds_now() {
    const auto now = std::chrono::system_clock::now().time_since_epoch();
    const auto value =
        std::chrono::duration_cast<std::chrono::milliseconds>(now).count();
    if (value <= 0) {
        app_fail("CLOCK_INVALID", "system clock is not after the Unix epoch");
    }
    return static_cast<std::uint64_t>(value);
}

void add_counters(IoCounters& target, const IoCounters& source) {
    target.poll_calls += source.poll_calls;
    target.read_calls += source.read_calls;
    target.write_calls += source.write_calls;
    target.read_bytes += source.read_bytes;
    target.write_bytes += source.write_bytes;
    target.short_reads += source.short_reads;
    target.short_writes += source.short_writes;
    target.interrupted += source.interrupted;
    target.would_block += source.would_block;
    target.frames_read += source.frames_read;
}

[[nodiscard]] PeerConnectionOutcome handle_connection_impl(
    OrderedByteStream& stream,
    NodeState& state,
    const std::string_view local_node,
    const IoOptions& io) {
    PeerConnectionOutcome outcome;
    const auto deadline = deadline_after(io.timeout);
    FramedReader reader(io);
    bool handshake_complete = false;
    std::optional<datacube::Digest32> operation_id;
    try {
        const auto handshake = perform_server_handshake(
            stream, local_node, reader, deadline, io);
        handshake_complete = true;
        add_counters(outcome.counters, handshake.counters);
        const auto payload = reader.read_frame(stream, deadline, outcome.counters);
        const auto message = decode_application_message(payload);
        const auto* record = std::get_if<EvidenceRecord>(&message);
        if (record == nullptr) {
            app_fail("APPLICATION_KIND_REJECTED",
                "server accepts only evidence and correction requests");
        }
        operation_id = record->operation_id;
        if (reader.queued_frames() != 0U) {
            app_fail("EXTRA_APPLICATION_FRAMES",
                "one operation is admitted per connection");
        }
        const auto admission = state.admit_inbound(
            *record, handshake.remote_artifact_digest);
        const auto response = encode_application_message(admission.receipt);
        write_frame(
            stream, response, deadline, io, outcome.counters);
        try { stream.shutdown_write(); } catch (...) {}
        outcome.committed =
            admission.disposition == AdmissionDisposition::committed;
        outcome.duplicate =
            admission.disposition == AdmissionDisposition::duplicate;
        return outcome;
    } catch (const AppError& error) {
        outcome.rejected = true;
        if (error.code() == "IO_TIMEOUT" ||
            error.code().starts_with("SOCKET_") ||
            error.code() == "PEER_CLOSED" ||
            error.code() == "PEER_RESET" ||
            error.code() == "INCOMPLETE_FRAME_EOF" ||
            error.code() == "CONNECT_FAILED") {
            outcome.transport_error = true;
        }
        if (handshake_complete) {
            try {
                ProtocolError response{
                    .operation_id = operation_id,
                    .code = valid_error_code(error.code()) ?
                        error.code() : "APPLICATION_REJECTED",
                    .detail = safe_protocol_detail(error.what()),
                };
                const auto payload = encode_application_message(response);
                write_frame(
                    stream, payload, deadline, io, outcome.counters);
                try { stream.shutdown_write(); } catch (...) {}
            } catch (...) {
                // The original connection failure remains the recorded outcome.
            }
        }
        std::cerr << error_json(error.code(), error.what()) << '\n';
        return outcome;
    } catch (const std::exception& error) {
        outcome.rejected = true;
        outcome.transport_error = true;
        std::cerr << error_json("CONNECTION_EXCEPTION", error.what()) << '\n';
        return outcome;
    }
}

class ConnectionQueue final {
public:
    explicit ConnectionQueue(const std::size_t capacity) : capacity_(capacity) {}

    [[nodiscard]] bool push(std::unique_ptr<OrderedByteStream> connection) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (closing_ || queue_.size() >= capacity_) {
            return false;
        }
        queue_.push_back(std::move(connection));
        condition_.notify_one();
        return true;
    }

    [[nodiscard]] std::optional<std::unique_ptr<OrderedByteStream>> pop() {
        std::unique_lock<std::mutex> lock(mutex_);
        condition_.wait(lock, [this] { return closing_ || !queue_.empty(); });
        if (queue_.empty()) {
            return std::nullopt;
        }
        auto result = std::move(queue_.front());
        queue_.pop_front();
        return result;
    }

    void close() {
        std::lock_guard<std::mutex> lock(mutex_);
        closing_ = true;
        condition_.notify_all();
    }

private:
    std::size_t capacity_{0U};
    std::deque<std::unique_ptr<OrderedByteStream>> queue_;
    bool closing_{false};
    std::mutex mutex_;
    std::condition_variable condition_;
};

struct AtomicServerStats final {
    std::atomic<std::size_t> accepted{0U};
    std::atomic<std::size_t> queued{0U};
    std::atomic<std::size_t> busy_rejected{0U};
    std::atomic<std::size_t> completed{0U};
    std::atomic<std::size_t> committed{0U};
    std::atomic<std::size_t> duplicate{0U};
    std::atomic<std::size_t> rejected{0U};
    std::atomic<std::size_t> transport_errors{0U};
    std::atomic<std::size_t> read_bytes{0U};
    std::atomic<std::size_t> write_bytes{0U};
};

[[nodiscard]] std::string optional_digest_json(
    const std::optional<datacube::Digest32>& value) {
    return value.has_value() ? json_string(operation_id_text(*value)) : "null";
}

[[nodiscard]] std::string record_json(
    const EvidenceRecord& record,
    const datacube::Digest32& record_digest,
    const std::uint64_t sequence,
    const std::optional<datacube::Digest32>& superseded_by,
    const std::optional<AuthorizationAccount>& authorization) {
    const auto payload_digest = datacube::sha256(record.payload);
    std::string out = std::string("{") +
        "\"sequence\":" + std::to_string(sequence) +
        ",\"operation_id\":" + json_string(operation_id_text(record.operation_id)) +
        ",\"issuer\":" + json_string(record.issuer) +
        ",\"recipient\":" + json_string(record.recipient) +
        ",\"scope\":" + json_string(record.scope) +
        ",\"corrects\":" + optional_digest_json(record.corrects) +
        ",\"superseded_by\":" + optional_digest_json(superseded_by) +
        ",\"payload_bytes\":" + std::to_string(record.payload.size()) +
        ",\"payload_sha256\":" + json_string(datacube::hex_lower(payload_digest)) +
        ",\"payload_hex\":" + json_string(hex_bytes(record.payload)) +
        ",\"record_digest\":" + json_string(datacube::hex_lower(record_digest)) +
        ",\"authorization\":";
    if (authorization.has_value()) {
        out += "{\"decision\":" +
            json_string(authorization_decision_kind_name(authorization->decision)) +
            ",\"peer\":" + json_string(authorization->peer_node) +
            ",\"generation\":" +
            json_string(authorization->peer_generation) +
            ",\"operation_class\":" +
            json_string(authorized_operation_class_name(
                authorization->operation_class)) +
            ",\"resource\":" + json_string(authorization->resource) +
            ",\"policy_digest\":" +
            json_string(datacube::hex_lower(authorization->policy_digest)) +
            ",\"rule_digest\":" +
            (authorization->rule_digest.has_value() ?
                json_string(datacube::hex_lower(*authorization->rule_digest)) :
                std::string("null")) +
            ",\"decided_unix_ms\":" +
            std::to_string(authorization->decided_unix_ms) +
            ",\"reason_code\":" +
            json_string(authorization->reason_code) + "}";
    } else {
        out += "null";
    }
    out += "}";
    return out;
}

[[nodiscard]] std::string counters_json(const IoCounters& value) {
    return std::string("{") +
        "\"poll_calls\":" + std::to_string(value.poll_calls) +
        ",\"read_calls\":" + std::to_string(value.read_calls) +
        ",\"write_calls\":" + std::to_string(value.write_calls) +
        ",\"read_bytes\":" + std::to_string(value.read_bytes) +
        ",\"write_bytes\":" + std::to_string(value.write_bytes) +
        ",\"short_reads\":" + std::to_string(value.short_reads) +
        ",\"short_writes\":" + std::to_string(value.short_writes) +
        ",\"interrupted\":" + std::to_string(value.interrupted) +
        ",\"would_block\":" + std::to_string(value.would_block) +
        ",\"frames_read\":" + std::to_string(value.frames_read) +
        "}";
}

void validate_receipt_binding(
    const DeliveryReceipt& receipt,
    const EvidenceRecord& record) {
    if (receipt.operation_id != record.operation_id ||
        receipt.recipient != record.recipient ||
        receipt.recorder != record.recipient ||
        receipt.record_digest != evidence_record_digest(record)) {
        app_fail("RECEIPT_BINDING_REJECTED",
            "remote receipt does not bind the sent record");
    }
}

[[nodiscard]] Deadline earlier_deadline(
    const Deadline left,
    const Deadline right) noexcept {
    return left < right ? left : right;
}

[[nodiscard]] std::chrono::milliseconds session_milliseconds(
    const std::uint32_t value) {
    return std::chrono::milliseconds(
        static_cast<std::chrono::milliseconds::rep>(value));
}

[[nodiscard]] PeerSessionLimits negotiate_session_limits(
    const PeerSessionLimits& requested,
    const PeerSessionLimits& available) {
    validate_peer_session_limits(requested);
    validate_peer_session_limits(available);
    PeerSessionLimits selected{
        .maximum_operations = std::min(
            requested.maximum_operations, available.maximum_operations),
        .maximum_bytes = std::min(
            requested.maximum_bytes, available.maximum_bytes),
        .maximum_lifetime_ms = std::min(
            requested.maximum_lifetime_ms, available.maximum_lifetime_ms),
        .idle_timeout_ms = std::min(
            requested.idle_timeout_ms, available.idle_timeout_ms),
    };
    selected.idle_timeout_ms = std::min(
        selected.idle_timeout_ms, selected.maximum_lifetime_ms);
    validate_peer_session_limits(selected);
    return selected;
}

void observe_peer_event(
    const PeerConnectionObserver& observer,
    const PeerConnectionEvent event) {
    if (observer) {
        observer(event);
    }
}

[[nodiscard]] DeliveryReceipt admit_authenticated_record(
    NodeState& state,
    const AuthorizationPolicy& authorization,
    const TlsSessionInfo& peer,
    const datacube::Digest32& remote_artifact_digest,
    const EvidenceRecord& record,
    PeerConnectionOutcome& outcome,
    const PeerConnectionObserver& observer,
    const PeerAdmissionGuard& admission_guard) {
    const auto lease = admission_guard ? admission_guard(peer) : PeerAdmissionLease{};
    const auto& current_authorization = lease.authorization ? *lease.authorization : authorization;
    if (record.issuer != peer.peer_node) {
        app_fail("AUTHENTICATED_ISSUER_MISMATCH",
            "application issuer does not match the authenticated peer key");
    }
    const auto decision = evaluate_authorization(
        current_authorization,
        peer.peer_node,
        peer.peer_generation,
        record);
    const auto decided_unix_ms = unix_milliseconds_now();
    if (!decision.allowed) {
        state.record_authorization_denial(
            record, decision, decided_unix_ms, decision.reason_code);
        outcome.authorization_denied = true;
        ++outcome.authorization_denials;
        observe_peer_event(observer, PeerConnectionEvent::authorization_denied);
        app_fail("AUTHORIZATION_DENIED",
            "authenticated peer is not authorized for this operation resource");
    }
    std::optional<ActionResultBinding> action_result;
    const bool require_action_result =
        operation_class_for(record) == AuthorizedOperationClass::counter_action &&
        lease.config != nullptr && lease.config->format_version >= 18U;
    if (require_action_result) {
        const auto& config = *lease.config;
        const auto* rule = find_action_result_rule(
            config.action_results, peer.peer_node, peer.peer_generation,
            "counter.add");
        const auto* routed = find_peer(config, peer.peer_node);
        const auto* generation = find_peer_generation(
            config, peer.peer_node, peer.peer_generation);
        if (rule != nullptr && routed != nullptr && generation != nullptr &&
            generation->state == KeyGenerationState::active &&
            routed->active_generation == peer.peer_generation &&
            routed->active_spki_sha256 == generation->spki_sha256) {
            const auto canonical = canonical_runtime_config(config);
            action_result = ActionResultBinding{
                .result_scope = rule->result_scope,
                .policy_digest = config.action_results.digest,
                .rule_digest = rule->digest,
                .configuration_event = state.configuration_event_reference(
                    config.runtime_generation,
                    runtime_configuration_digest(canonical), canonical),
                .peer_generation = peer.peer_generation,
                .peer_spki_sha256 = generation->spki_sha256,
                .maximum_attempts = routed->delivery.maximum_attempts,
                .initial_backoff_ms = routed->delivery.initial_backoff_ms,
                .maximum_backoff_ms = routed->delivery.maximum_backoff_ms,
                .delivery_expiry_ms = routed->delivery.expiry_ms,
            };
        }
    }
    const auto admission = state.admit_inbound_authorized(
        record, remote_artifact_digest, decision, decided_unix_ms,
        std::move(action_result), require_action_result);
    if (admission.disposition == AdmissionDisposition::committed) {
        outcome.committed = true;
        ++outcome.committed_operations;
        observe_peer_event(observer, PeerConnectionEvent::committed);
    } else {
        outcome.duplicate = true;
        ++outcome.duplicate_operations;
        observe_peer_event(observer, PeerConnectionEvent::duplicate);
    }
    if (admission.action_queued) {
        outcome.action_queued = true;
        ++outcome.actions_queued;
        observe_peer_event(observer, PeerConnectionEvent::action_queued);
    }
    return admission.receipt;
}

[[nodiscard]] RemoteSourceSubscriptionResponse
admit_remote_source_subscription_request(
    NodeState& state,
    const TlsSessionInfo& peer,
    const RemoteSourceSubscriptionRequest& request,
    const PeerAdmissionGuard& admission_guard) {
    if (!admission_guard) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_DENIED",
            "remote subscription requests require a live configuration lease");
    }
    const auto lease = admission_guard(peer);
    if (lease.config == nullptr) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_DENIED",
            "remote subscription request lacks the active provider policy");
    }
    const auto& config = *lease.config;
    if (config.runtime_generation.empty()) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_DENIED",
            "remote subscription requests require accepted versioned configuration");
    }
    const auto canonical = canonical_runtime_config(config);
    const auto event = state.configuration_event_reference(
        config.runtime_generation,
        runtime_configuration_digest(canonical),
        canonical);
    return state.source_subscription_remote_command(
        request, config, peer, event, unix_milliseconds_now());
}

[[nodiscard]] ProtocolError operation_error(
    const datacube::Digest32& operation_id,
    const AppError& error) {
    return ProtocolError{
        .operation_id = operation_id,
        .code = valid_error_code(error.code()) ?
            error.code() : "APPLICATION_REJECTED",
        .detail = safe_protocol_detail(error.what()),
    };
}

[[nodiscard]] PeerConnectionOutcome handle_secure_connection_impl(
    OrderedByteStream& stream,
    NodeState& state,
    TlsContext& tls,
    const std::vector<TlsTrustedIdentity>& trusted_peers,
    const AuthorizationPolicy& authorization,
    const std::string_view local_node,
    const IoOptions& io,
    const PeerSessionLimits& session_limits,
    const PeerConnectionObserver& observer,
    const PeerAdmissionGuard& admission_guard,
    const CustodySessionHandler& custody_handler) {
    PeerConnectionOutcome outcome;
    validate_peer_session_limits(session_limits);
    const auto connection_deadline = deadline_after(io.timeout);
    IoOptions session_io = io;
    const auto expanded_receive = session_limits.maximum_bytes +
        static_cast<std::uint64_t>(io.maximum_received_bytes);
    if (expanded_receive >
        static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
        app_fail("SESSION_LIMIT_INVALID", "receiver byte bound exceeds size_t");
    }
    session_io.maximum_received_bytes =
        static_cast<std::size_t>(expanded_receive);
    FramedReader reader(session_io);
    bool legacy_application_protocol_ready = false;
    bool session_application_protocol_ready = false;
    std::optional<datacube::Digest32> operation_id;
    std::optional<TlsChannel> channel;
    try {
        channel.emplace(TlsChannel::accept(
            tls, stream, trusted_peers, connection_deadline,
            outcome.tls_counters));
        outcome.authenticated = true;
        outcome.tls_session = channel->session();
        observe_peer_event(observer, PeerConnectionEvent::authenticated);

        const auto handshake = perform_server_handshake(
            *channel, local_node, reader, connection_deadline, session_io);
        add_counters(outcome.counters, handshake.counters);
        if (handshake.remote_artifact_digest !=
            node_artifact_digest(channel->session().peer_node)) {
            app_fail("TLS_NODE_ID_MISMATCH",
                "authenticated peer key does not match the HELLO node identity");
        }

        const auto first_payload = reader.read_frame(
            *channel, connection_deadline, outcome.counters);
        if (!looks_like_peer_session_frame(first_payload)) {
            legacy_application_protocol_ready = true;
            observe_peer_event(observer, PeerConnectionEvent::legacy_connection);
            const auto message = decode_application_message(first_payload);
            const auto* record = std::get_if<EvidenceRecord>(&message);
            const auto* subscription =
                std::get_if<RemoteSourceSubscriptionRequest>(&message);
            if (record == nullptr && subscription == nullptr) {
                app_fail("APPLICATION_KIND_REJECTED",
                    "server accepts evidence, corrections, or bounded remote subscription requests");
            }
            operation_id = record ? record->operation_id : subscription->request_id;
            if (reader.queued_frames() != 0U) {
                app_fail("EXTRA_APPLICATION_FRAMES",
                    "legacy mode admits one operation per connection");
            }
            ++outcome.operations;
            ApplicationMessage application_response;
            if (record != nullptr) {
                application_response = admit_authenticated_record(
                    state,
                    authorization,
                    channel->session(),
                    handshake.remote_artifact_digest,
                    *record,
                    outcome,
                    observer, admission_guard);
            } else {
                application_response = admit_remote_source_subscription_request(
                    state, channel->session(), *subscription, admission_guard);
            }
            const auto response = encode_application_message(application_response);
            write_frame(
                *channel, response, connection_deadline, session_io,
                outcome.counters);
            channel->close_notify(connection_deadline, outcome.tls_counters);
            return outcome;
        }

        outcome.session_protocol = true;
        const auto open = decode_peer_session_frame(first_payload);
        if (open.kind != PeerSessionFrameKind::open ||
            !open.limits.has_value()) {
            app_fail("SESSION_OPEN_REJECTED",
                "the first NOS1 frame must be OPEN");
        }
        const auto negotiated = negotiate_session_limits(
            *open.limits, session_limits);
        PeerSessionFrame open_ack{
            .kind = PeerSessionFrameKind::open_ack,
            .flags = 0U,
            .session_id = open.session_id,
            .sequence = 0U,
            .operation_id = {},
            .limits = negotiated,
            .payload = {},
        };
        const auto encoded_open_ack = encode_peer_session_frame(open_ack);
        write_frame(
            *channel,
            encoded_open_ack,
            connection_deadline,
            session_io,
            outcome.counters);
        session_application_protocol_ready = true;
        observe_peer_event(observer, PeerConnectionEvent::session_connection);
        std::uint64_t session_bytes =
            static_cast<std::uint64_t>(kPeerFramePrefixBytes + first_payload.size()) +
            static_cast<std::uint64_t>(kPeerFramePrefixBytes + encoded_open_ack.size());
        if (session_bytes > negotiated.maximum_bytes) {
            app_fail("SESSION_BYTE_LIMIT", "session open exceeds byte bound");
        }
        std::uint32_t expected_sequence = 1U;
        const auto opened = std::chrono::steady_clock::now();
        auto last_activity = opened;

        while (outcome.operations < negotiated.maximum_operations) {
            auto deadline = earlier_deadline(
                opened + session_milliseconds(negotiated.maximum_lifetime_ms),
                last_activity + session_milliseconds(negotiated.idle_timeout_ms));
            const auto frame_payload = reader.read_frame(
                *channel, deadline, outcome.counters);
            const auto framed_request_bytes = static_cast<std::uint64_t>(
                kPeerFramePrefixBytes + frame_payload.size());
            if (framed_request_bytes >
                negotiated.maximum_bytes - session_bytes) {
                app_fail("SESSION_BYTE_LIMIT",
                    "peer exceeded the negotiated session byte bound");
            }
            session_bytes += framed_request_bytes;
            const auto frame = decode_peer_session_frame(frame_payload);
            if (frame.session_id != open.session_id ||
                frame.sequence != expected_sequence) {
                app_fail("SESSION_REQUEST_BINDING_REJECTED",
                    "session frame does not bind the current session sequence");
            }
            if (frame.kind == PeerSessionFrameKind::close) {
                PeerSessionFrame close_ack{
                    .kind = PeerSessionFrameKind::close_ack,
                    .flags = 0U,
                    .session_id = open.session_id,
                    .sequence = expected_sequence,
                    .operation_id = {},
                    .limits = std::nullopt,
                    .payload = {},
                };
                const auto encoded = encode_peer_session_frame(close_ack);
                const auto framed_close_ack_bytes = static_cast<std::uint64_t>(
                    kPeerFramePrefixBytes + encoded.size());
                if (framed_close_ack_bytes > negotiated.maximum_bytes - session_bytes) {
                    app_fail("SESSION_BYTE_LIMIT",
                        "session close acknowledgement exceeds byte bound");
                }
                session_bytes += framed_close_ack_bytes;
                write_frame(
                    *channel, encoded, deadline, session_io, outcome.counters);
                outcome.session_clean_close = true;
                observe_peer_event(observer, PeerConnectionEvent::session_clean_close);
                channel->close_notify(deadline, outcome.tls_counters);
                return outcome;
            }
            if (frame.kind != PeerSessionFrameKind::request) {
                app_fail("SESSION_KIND_REJECTED",
                    "server expected a session request or close frame");
            }
            operation_id = frame.operation_id;
            ++outcome.operations;
            observe_peer_event(observer, PeerConnectionEvent::operation);

            ApplicationMessage application_response;
            bool configuration_retire = false;
            try {
                const auto message = decode_application_message(frame.payload);
                const auto* record = std::get_if<EvidenceRecord>(&message);
                const auto* subscription =
                    std::get_if<RemoteSourceSubscriptionRequest>(&message);
                const auto* custody_offer =
                    std::get_if<CustodyTransferOffer>(&message);
                if (record == nullptr && subscription == nullptr &&
                    custody_offer == nullptr) {
                    app_fail("APPLICATION_KIND_REJECTED",
                        "session server accepts evidence, corrections, bounded remote subscription requests, or explicit custody offers");
                }
                if (custody_offer != nullptr && !custody_handler) {
                    app_fail("CUSTODY_SESSION_NOT_CONFIGURED",
                        "this authenticated session has no custody-service authority");
                }
                const auto message_operation = application_message_operation_id(message);
                if (!message_operation.has_value() ||
                    *message_operation != frame.operation_id) {
                    app_fail("SESSION_REQUEST_BINDING_REJECTED",
                        "application operation does not match the session envelope");
                }
                if (record != nullptr) {
                    application_response = admit_authenticated_record(
                        state,
                        authorization,
                        channel->session(),
                        handshake.remote_artifact_digest,
                        *record,
                        outcome,
                        observer, admission_guard);
                } else if (subscription != nullptr) {
                    application_response = admit_remote_source_subscription_request(
                        state, channel->session(), *subscription,
                        admission_guard);
                } else {
                    application_response = custody_handler(
                        channel->session(), *custody_offer);
                }
            } catch (const AppError& error) {
                if (error.code() == "SESSION_REQUEST_BINDING_REJECTED") {
                    throw;
                }
                configuration_retire = error.code() == "CONFIG_SESSION_RETIRED";
                outcome.rejected = true;
                ++outcome.rejected_operations;
                application_response = operation_error(frame.operation_id, error);
            }

            if (test_drop_after_admission(frame.operation_id)) {
                app_fail("TEST_SESSION_DROP_AFTER_ADMISSION",
                    "test hook closed a session after durable admission and before response");
            }
            auto encoded_application = encode_application_message(
                application_response);
            const auto operation_count_after = outcome.operations;
            const auto projected_response_bytes = static_cast<std::uint64_t>(
                kPeerFramePrefixBytes + kPeerSessionHeaderBytes +
                encoded_application.size());
            const auto close_reserve = static_cast<std::uint64_t>(
                2U * (kPeerFramePrefixBytes + kPeerSessionHeaderBytes));
            const bool lifetime_reached =
                std::chrono::steady_clock::now() >=
                opened + session_milliseconds(negotiated.maximum_lifetime_ms);
            const bool retire_after = configuration_retire ||
                operation_count_after >= negotiated.maximum_operations ||
                lifetime_reached ||
                projected_response_bytes > negotiated.maximum_bytes - session_bytes ||
                close_reserve > negotiated.maximum_bytes - session_bytes -
                    std::min(projected_response_bytes,
                        negotiated.maximum_bytes - session_bytes);
            PeerSessionFrame response{
                .kind = PeerSessionFrameKind::response,
                .flags = static_cast<std::uint16_t>(
                    retire_after ? kPeerSessionRetireAfterResponse : 0U),
                .session_id = open.session_id,
                .sequence = expected_sequence,
                .operation_id = frame.operation_id,
                .limits = std::nullopt,
                .payload = std::move(encoded_application),
            };
            const auto encoded_response = encode_peer_session_frame(response);
            const auto framed_response_bytes = static_cast<std::uint64_t>(
                kPeerFramePrefixBytes + encoded_response.size());
            if (framed_response_bytes >
                negotiated.maximum_bytes - session_bytes) {
                app_fail("SESSION_BYTE_LIMIT",
                    "operation response exceeds negotiated session byte bound");
            }
            session_bytes += framed_response_bytes;
            write_frame(
                *channel,
                encoded_response,
                deadline,
                session_io,
                outcome.counters);
            ++expected_sequence;
            last_activity = std::chrono::steady_clock::now();
            if (retire_after) {
                outcome.session_retired = true;
                observe_peer_event(observer, PeerConnectionEvent::session_retired);
                channel->close_notify(deadline, outcome.tls_counters);
                return outcome;
            }
        }

        outcome.session_retired = true;
        observe_peer_event(observer, PeerConnectionEvent::session_retired);
        channel->close_notify(connection_deadline, outcome.tls_counters);
        return outcome;
    } catch (const AppError& error) {
        outcome.rejected = true;
        if (error.code() == "IO_TIMEOUT" ||
            error.code().starts_with("SOCKET_") ||
            error.code().starts_with("SERIAL_") ||
            error.code().starts_with("UDP_") ||
            error.code().starts_with("UNIX_DATAGRAM_") ||
            error.code().starts_with("TLS_") ||
            error.code() == "PEER_CLOSED" ||
            error.code() == "PEER_RESET" ||
            error.code() == "INCOMPLETE_FRAME_EOF" ||
            error.code() == "CONNECT_FAILED") {
            outcome.transport_error = true;
        }
        if (legacy_application_protocol_ready && channel.has_value()) {
            try {
                ProtocolError response{
                    .operation_id = operation_id,
                    .code = valid_error_code(error.code()) ?
                        error.code() : "APPLICATION_REJECTED",
                    .detail = safe_protocol_detail(error.what()),
                };
                const auto payload = encode_application_message(response);
                write_frame(
                    *channel,
                    payload,
                    connection_deadline,
                    session_io,
                    outcome.counters);
                channel->close_notify(connection_deadline, outcome.tls_counters);
            } catch (...) {
                // The original authenticated connection failure remains primary.
            }
        } else if (session_application_protocol_ready && channel.has_value()) {
            channel->close_notify(connection_deadline, outcome.tls_counters);
        }
        std::cerr << error_json(error.code(), error.what()) << '\n';
        return outcome;
    } catch (const std::exception& error) {
        outcome.rejected = true;
        outcome.transport_error = true;
        std::cerr << error_json("TLS_CONNECTION_EXCEPTION", error.what()) << '\n';
        return outcome;
    }
}

[[nodiscard]] SendResult deliver_outbound_record_impl(
    NodeState& state,
    const std::string_view local_node,
    const std::string_view expected_peer,
    const TransportLocator& locator,
    const EvidenceRecord& record,
    const IoOptions& io,
    const QueueDisposition queue_disposition) {
    SendResult result;
    result.queue_disposition = queue_disposition;
    result.network_used = true;
    const auto deadline = deadline_after(io.timeout);
    auto stream = connect_transport(locator, deadline, result.connect_counters);
    const auto handshake = perform_client_handshake(
        *stream,
        local_node,
        expected_peer,
        request_id_for(record),
        deadline,
        io);
    result.handshake = handshake.observation;
    result.handshake_counters = handshake.counters;

    const auto payload = encode_application_message(record);
    write_frame(
        *stream, payload, deadline, io,
        result.application_counters);
    stream->shutdown_write();
    FramedReader reader(io);
    const auto response_payload = reader.read_frame(
        *stream, deadline, result.application_counters);
    const auto response = decode_application_message(response_payload);
    if (const auto* error = std::get_if<ProtocolError>(&response)) {
        app_fail(error->code, error->detail);
    }
    const auto* receipt = std::get_if<DeliveryReceipt>(&response);
    if (receipt == nullptr) {
        app_fail("APPLICATION_KIND_REJECTED", "expected delivery receipt");
    }
    validate_receipt_binding(*receipt, record);
    state.record_outbound_receipt(*receipt);
    result.receipt = *receipt;
    return result;
}

[[nodiscard]] SendResult deliver_outbound_record_secure_impl(
    NodeState& state,
    TlsContext& tls,
    const std::string_view local_node,
    const std::string_view expected_peer,
    const std::string_view expected_peer_generation,
    const KeyGenerationState expected_peer_key_state,
    const datacube::Digest32& expected_peer_spki_sha256,
    const TransportLocator& locator,
    const EvidenceRecord& record,
    const IoOptions& io,
    const QueueDisposition queue_disposition) {
    SendResult result;
    result.queue_disposition = queue_disposition;
    result.network_used = true;
    result.secure_transport = true;
    const auto deadline = deadline_after(io.timeout);
    auto stream = connect_transport(locator, deadline, result.connect_counters);
    auto channel = TlsChannel::connect(
        tls,
        *stream,
        expected_peer,
        expected_peer_generation,
        expected_peer_key_state,
        expected_peer_spki_sha256,
        deadline,
        result.tls_counters);
    result.tls_session = channel.session();

    const auto handshake = perform_client_handshake(
        channel,
        local_node,
        expected_peer,
        request_id_for(record),
        deadline,
        io);
    result.handshake = handshake.observation;
    result.handshake_counters = handshake.counters;

    const auto payload = encode_application_message(record);
    write_frame(
        channel, payload, deadline, io,
        result.application_counters);
    FramedReader reader(io);
    const auto response_payload = reader.read_frame(
        channel, deadline, result.application_counters);
    const auto response = decode_application_message(response_payload);
    if (const auto* error = std::get_if<ProtocolError>(&response)) {
        if (!error->operation_id.has_value() ||
            *error->operation_id != record.operation_id) {
            app_fail("REMOTE_ERROR_BINDING_REJECTED",
                "authenticated peer error does not bind the exact outbound operation");
        }
        throw AuthenticatedPeerError(
            error->code,
            error->detail,
            authenticated_peer_error_is_terminal(error->code));
    }
    const auto* receipt = std::get_if<DeliveryReceipt>(&response);
    if (receipt == nullptr) {
        app_fail("APPLICATION_KIND_REJECTED", "expected delivery receipt");
    }
    validate_receipt_binding(*receipt, record);
    state.record_outbound_receipt(*receipt);
    result.receipt = *receipt;
    channel.close_notify(deadline, result.tls_counters);
    return result;
}

}  // namespace

PeerConnectionOutcome handle_peer_connection(
    OrderedByteStream& stream,
    NodeState& state,
    const std::string_view local_node,
    const IoOptions& io) {
    validate_io_options(io);
    require_node_id(local_node, "local node");
    return handle_connection_impl(stream, state, local_node, io);
}

PeerConnectionOutcome handle_secure_peer_connection(
    OrderedByteStream& stream,
    NodeState& state,
    TlsContext& tls,
    const std::vector<TlsTrustedIdentity>& trusted_peers,
    const AuthorizationPolicy& authorization,
    const std::string_view local_node,
    const IoOptions& io,
    const PeerSessionLimits& session_limits,
    PeerConnectionObserver observer,
    PeerAdmissionGuard admission_guard,
    CustodySessionHandler custody_handler) {
    validate_io_options(io);
    validate_peer_session_limits(session_limits);
    require_node_id(local_node, "local node");
    return handle_secure_connection_impl(
        stream, state, tls, trusted_peers, authorization, local_node, io,
        session_limits, observer, admission_guard, custody_handler);
}

SendResult deliver_outbound_record(
    NodeState& state,
    const std::string_view local_node,
    const std::string_view expected_peer,
    const TransportLocator& locator,
    const EvidenceRecord& record,
    const IoOptions& io,
    const QueueDisposition queue_disposition) {
    validate_io_options(io);
    require_node_id(local_node, "local node");
    require_node_id(expected_peer, "expected peer");
    validate_evidence_record(record);
    return deliver_outbound_record_impl(
        state, local_node, expected_peer, locator, record, io,
        queue_disposition);
}

SendResult deliver_outbound_record_secure(
    NodeState& state,
    TlsContext& tls,
    const std::string_view local_node,
    const std::string_view expected_peer,
    const std::string_view expected_peer_generation,
    const KeyGenerationState expected_peer_key_state,
    const datacube::Digest32& expected_peer_spki_sha256,
    const TransportLocator& locator,
    const EvidenceRecord& record,
    const IoOptions& io,
    const QueueDisposition queue_disposition) {
    validate_io_options(io);
    require_node_id(local_node, "local node");
    require_node_id(expected_peer, "expected peer");
    require_generation_id(expected_peer_generation, "expected peer generation");
    validate_evidence_record(record);
    if (spki_sha256_is_zero(expected_peer_spki_sha256) ||
        expected_peer_key_state == KeyGenerationState::revoked) {
        app_fail("TLS_PIN_INVALID", "outbound peer key is all-zero or revoked");
    }
    return deliver_outbound_record_secure_impl(
        state,
        tls,
        local_node,
        expected_peer,
        expected_peer_generation,
        expected_peer_key_state,
        expected_peer_spki_sha256,
        locator,
        record,
        io,
        queue_disposition);
}

SendResult send_evidence(const SendOptions& options) {
    validate_io_options(options.io);
    require_node_id(options.local_node, "local node");
    require_node_id(options.expected_peer, "expected peer");
    validate_evidence_record(options.record);
    if (options.record.issuer != options.local_node) {
        app_fail("OUTBOUND_ISSUER_MISMATCH",
            "record issuer must match local node");
    }
    NodeState state(
        options.state_directory,
        options.local_node,
        options.maximum_journal_bytes);
    const auto queued = state.queue_outbound(options.record);
    if (queued.disposition == QueueDisposition::already_acked) {
        SendResult result;
        result.queue_disposition = queued.disposition;
        result.network_used = false;
        result.receipt = *queued.receipt;
        return result;
    }
    if (queued.disposition == QueueDisposition::already_rejected) {
        app_fail("OUTBOUND_REJECTED",
            "operation has a durable authenticated peer rejection; use retry or rebind through the persistent control plane");
    }
    return deliver_outbound_record(
        state,
        options.local_node,
        options.expected_peer,
        options.locator,
        options.record,
        options.io,
        queued.disposition);
}

FlushResult flush_outbox(const FlushOptions& options) {
    validate_io_options(options.io);
    require_node_id(options.local_node, "local node");
    require_node_id(options.expected_peer, "expected peer");
    if (options.maximum_records < 1U || options.maximum_records > 100'000U) {
        app_fail("INVALID_FLUSH_LIMIT",
            "maximum records must be between 1 and 100000");
    }
    NodeState state(
        options.state_directory,
        options.local_node,
        options.maximum_journal_bytes);
    const auto before = state.snapshot();
    std::vector<EvidenceRecord> pending;
    pending.reserve(std::min(before.outbound.size(), options.maximum_records));
    FlushResult result;
    result.peer = options.expected_peer;
    for (const auto& entry : before.outbound) {
        if (outbound_is_pending(entry) &&
            entry.record.recipient == options.expected_peer) {
            ++result.pending_before;
            if (pending.size() < options.maximum_records) {
                pending.push_back(entry.record);
            }
        }
    }
    for (const auto& record : pending) {
        ++result.attempted;
        const auto delivered = deliver_outbound_record(
            state,
            options.local_node,
            options.expected_peer,
            options.locator,
            record,
            options.io,
            QueueDisposition::already_pending);
        ++result.acknowledged;
        if (delivered.receipt.disposition == ReceiptDisposition::committed) {
            ++result.committed;
        } else {
            ++result.duplicate;
        }
        result.acknowledged_operations.push_back(record.operation_id);
        add_counters(result.connect_counters, delivered.connect_counters);
        add_counters(result.handshake_counters, delivered.handshake_counters);
        add_counters(result.application_counters, delivered.application_counters);
    }
    const auto after = state.snapshot();
    for (const auto& entry : after.outbound) {
        if (outbound_is_pending(entry) &&
            entry.record.recipient == options.expected_peer) {
            ++result.pending_after;
        }
    }
    return result;
}

int run_server(const ServerOptions& options) {
    validate_io_options(options.io);
    require_node_id(options.local_node, "local node");
    if (options.workers < 1U || options.workers > 32U ||
        options.queue_capacity < 1U || options.queue_capacity > 4096U ||
        options.maximum_connections > 1'000'000U ||
        options.idle_timeout.count() < 0 ||
        options.idle_timeout.count() > 3'600'000) {
        app_fail("INVALID_SERVER_OPTIONS", "bounded server options violated");
    }
    NodeState state(
        options.state_directory,
        options.local_node,
        options.maximum_journal_bytes);
    auto listener = listen_transport(options.listen_locator, options.backlog);
    const auto bound_locator = listener->bound_locator();
    const auto port = tcp_transport_locator(bound_locator).service;

    struct sigaction action {};
    action.sa_handler = stop_handler;
    ::sigemptyset(&action.sa_mask);
    action.sa_flags = 0;
    if (::sigaction(SIGTERM, &action, nullptr) != 0 ||
        ::sigaction(SIGINT, &action, nullptr) != 0) {
        app_fail("SIGNAL_SETUP_FAILED", datacube::errno_detail("sigaction", errno));
    }
    stop_requested = 0;
    recheck_process_state_head_custody_constraint(
        StateHeadCustodyRecheckPoint::startup_acceptance);
    release_process_state_head_custody_constraint();
    ConnectionQueue queue(options.queue_capacity);
    AtomicServerStats stats;
    std::vector<std::thread> workers;
    workers.reserve(options.workers);
    for (std::size_t index = 0U; index < options.workers; ++index) {
        workers.emplace_back([&queue, &state, &options, &stats] {
            while (true) {
                auto connection = queue.pop();
                if (!connection.has_value()) {
                    return;
                }
                const auto outcome = handle_peer_connection(
                    **connection, state, options.local_node, options.io);
                ++stats.completed;
                if (outcome.committed) { ++stats.committed; }
                if (outcome.duplicate) { ++stats.duplicate; }
                if (outcome.rejected) { ++stats.rejected; }
                if (outcome.transport_error) { ++stats.transport_errors; }
                stats.read_bytes += outcome.counters.read_bytes;
                stats.write_bytes += outcome.counters.write_bytes;
            }
        });
    }

    std::cout << "{\"format\":\"NATRAV_OVERLAY_SERVER_READY_V1\""
              << ",\"node\":" << json_string(options.local_node)
              << ",\"host\":" << json_string(tcp_transport_locator(options.listen_locator).host)
              << ",\"port\":" << port
              << ",\"workers\":" << options.workers
              << ",\"pid\":" << ::getpid() << "}" << std::endl;

    auto last_accept = std::chrono::steady_clock::now();
    while (stop_requested == 0) {
        if (options.maximum_connections != 0U &&
            stats.accepted.load() >= options.maximum_connections) {
            break;
        }
        int timeout = 100;
        if (options.idle_timeout.count() > 0) {
            const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now() - last_accept);
            if (elapsed >= options.idle_timeout) {
                break;
            }
            const auto remaining = options.idle_timeout - elapsed;
            timeout = static_cast<int>(std::min<std::chrono::milliseconds::rep>(
                remaining.count(), 100));
            timeout = std::max(timeout, 1);
        }
        pollfd item{.fd = listener->readiness_handle(), .events = POLLIN, .revents = 0};
        const int polled = ::poll(&item, 1U, timeout);
        if (polled < 0) {
            if (errno == EINTR) {
                continue;
            }
            queue.close();
            for (auto& worker : workers) { worker.join(); }
            app_fail("LISTENER_POLL_FAILED",
                datacube::errno_detail("listener poll", errno));
        }
        if (polled == 0 || (item.revents & POLLIN) == 0) {
            continue;
        }
        while (true) {
            auto connection = listener->accept_ready();
            if (!connection) {
                break;
            }
            ++stats.accepted;
            last_accept = std::chrono::steady_clock::now();
            if (queue.push(std::move(connection))) {
                ++stats.queued;
            } else {
                ++stats.busy_rejected;
            }
            if (options.maximum_connections != 0U &&
                stats.accepted.load() >= options.maximum_connections) {
                break;
            }
        }
    }
    queue.close();
    for (auto& worker : workers) {
        worker.join();
    }
    const auto snapshot = state.snapshot();
    std::cout << "{\"format\":\"NATRAV_OVERLAY_SERVER_STOP_V1\""
              << ",\"node\":" << json_string(options.local_node)
              << ",\"port\":" << port
              << ",\"accepted\":" << stats.accepted.load()
              << ",\"queued\":" << stats.queued.load()
              << ",\"busy_rejected\":" << stats.busy_rejected.load()
              << ",\"completed\":" << stats.completed.load()
              << ",\"committed\":" << stats.committed.load()
              << ",\"duplicate\":" << stats.duplicate.load()
              << ",\"rejected\":" << stats.rejected.load()
              << ",\"transport_errors\":" << stats.transport_errors.load()
              << ",\"read_bytes\":" << stats.read_bytes.load()
              << ",\"write_bytes\":" << stats.write_bytes.load()
              << ",\"journal_bytes\":" << snapshot.journal_bytes
              << ",\"inbound_records\":" << snapshot.inbound.size()
              << "}" << std::endl;
    return 0;
}

std::string state_snapshot_json(const StateSnapshot& snapshot) {
    std::map<std::string, std::size_t> index;
    std::map<std::string, std::string> child;
    for (std::size_t i = 0U; i < snapshot.inbound.size(); ++i) {
        index.emplace(operation_id_text(snapshot.inbound[i].record.operation_id), i);
        if (snapshot.inbound[i].record.corrects.has_value()) {
            child.emplace(
                operation_id_text(*snapshot.inbound[i].record.corrects),
                operation_id_text(snapshot.inbound[i].record.operation_id));
        }
    }
    std::size_t pending = 0U;
    std::size_t acked = 0U;
    std::size_t expired = 0U;
    std::size_t cancelled = 0U;
    std::size_t rejected = 0U;
    for (const auto& entry : snapshot.outbound) {
        if (entry.receipt.has_value()) {
            ++acked;
        } else if (entry.delivery.has_value() &&
                   entry.delivery->cancelled_unix_ms.has_value()) {
            ++cancelled;
        } else if (entry.delivery.has_value() &&
                   entry.delivery->expired_unix_ms.has_value()) {
            ++expired;
        } else if (outbound_status_name(entry) == "REJECTED") {
            ++rejected;
        } else {
            ++pending;
        }
    }

    std::string out = "{\"format\":\"NATRAV_OVERLAY_STATE_V7\"";
    out += ",\"node\":" + json_string(snapshot.node_id);
    out += ",\"state_directory\":" + json_string(snapshot.state_directory.string());
    out += ",\"journal_bytes\":" + std::to_string(snapshot.journal_bytes);
    out += ",\"state_head\":" + state_head_json(snapshot.node_id, snapshot.authentication, snapshot.journal_bytes);
    out += ",\"storage\":{\"schema_version\":" +
        std::to_string(snapshot.storage_schema_version) +
        ",\"maintenance_generation\":" +
        std::to_string(snapshot.maintenance_generation) +
        ",\"state_authentication\":" + state_authentication_json(snapshot.authentication) +
        ",\"logical_state_digest\":" +
        json_string(datacube::hex_lower(snapshot.logical_state_digest)) +
        ",\"last_compaction_unix_ms\":" +
        (snapshot.last_compaction_unix_ms.has_value() ?
            std::to_string(*snapshot.last_compaction_unix_ms) :
            std::string("null")) +
        ",\"last_compaction_before_bytes\":" +
        std::to_string(snapshot.last_compaction_before_bytes) +
        ",\"last_compaction_after_bytes\":" +
        std::to_string(snapshot.last_compaction_after_bytes) +
        ",\"last_compaction_retained_records\":" +
        std::to_string(snapshot.last_compaction_retained_records) +
        ",\"restored_backup_id\":" +
        (snapshot.restored_backup_id.has_value() ?
            json_string(datacube::hex_lower(*snapshot.restored_backup_id)) :
            std::string("null")) +
        ",\"restored_backup_generation\":" +
        (snapshot.restored_backup_generation.empty() ?
            std::string("null") :
            json_string(snapshot.restored_backup_generation)) +
        ",\"restored_backup_unix_ms\":" +
        (snapshot.restored_backup_unix_ms.has_value() ?
            std::to_string(*snapshot.restored_backup_unix_ms) :
            std::string("null")) +
        ",\"migrations\":[";
    for (std::size_t i = 0U; i < snapshot.migrations.size(); ++i) {
        if (i != 0U) { out += ','; }
        const auto& migration = snapshot.migrations[i];
        out += "{\"from_version\":" +
            std::to_string(migration.from_version) +
            ",\"to_version\":" +
            std::to_string(migration.to_version) +
            ",\"migrated_unix_ms\":" +
            std::to_string(migration.migrated_unix_ms) + "}";
    }
    out += "]}";
    out += ",\"recoveries\":[";
    for (std::size_t i = 0U; i < snapshot.recoveries.size(); ++i) {
        if (i != 0U) { out += ','; }
        out += "{\"discarded_tail_bytes\":" +
            std::to_string(snapshot.recoveries[i].discarded_tail_bytes) +
            ",\"valid_prefix_bytes\":" +
            std::to_string(snapshot.recoveries[i].valid_prefix_bytes) + "}";
    }
    out += "]";
    out += ",\"inbound\":{\"count\":" +
        std::to_string(snapshot.inbound.size()) + ",\"history\":[";
    for (std::size_t i = 0U; i < snapshot.inbound.size(); ++i) {
        if (i != 0U) { out += ','; }
        const auto& entry = snapshot.inbound[i];
        out += record_json(
            entry.record, entry.record_digest, entry.sequence,
            entry.superseded_by, entry.authorization);
        if (entry.subscribed_source) { out.pop_back(); out += ",\"subscribed_source\":" + subscribed_source_json(*entry.subscribed_source) + "}"; }
        if (entry.local_authorship) {
            out.pop_back();
            out += ",\"local_authorship\":" + local_authorship_json(*entry.local_authorship) + "}";
        }
    }
    out += "],\"current\":[";
    bool first_current = true;
    for (const auto& entry : snapshot.inbound) {
        if (entry.record.corrects.has_value()) {
            continue;
        }
        const std::string root = operation_id_text(entry.record.operation_id);
        std::string current = root;
        while (child.contains(current)) {
            current = child.at(current);
        }
        const auto current_index = index.at(current);
        if (!first_current) { out += ','; }
        first_current = false;
        out += "{\"root_operation_id\":" + json_string(root) +
            ",\"current_operation_id\":" + json_string(current) +
            ",\"current_sequence\":" +
            std::to_string(snapshot.inbound[current_index].sequence) + "}";
    }
    out += "]}";
    out += ",\"outbox\":{\"count\":" +
        std::to_string(snapshot.outbound.size()) +
        ",\"pending\":" + std::to_string(pending) +
        ",\"acked\":" + std::to_string(acked) +
        ",\"rejected\":" + std::to_string(rejected) +
        ",\"expired\":" + std::to_string(expired) +
        ",\"cancelled\":" + std::to_string(cancelled) +
        ",\"reservations\":{\"pending_records\":" +
        std::to_string(snapshot.queue_usage.pending_records) +
        ",\"pending_payload_bytes\":" +
        std::to_string(snapshot.queue_usage.pending_payload_bytes) +
        ",\"future_result_records\":" + std::to_string(snapshot.queue_usage.future_result_records) +
        ",\"future_result_payload_bytes\":" + std::to_string(snapshot.queue_usage.future_result_payload_bytes) +
        ",\"committed_records\":" + std::to_string(snapshot.queue_usage.pending_records + snapshot.queue_usage.future_result_records) +
        ",\"committed_payload_bytes\":" + std::to_string(snapshot.queue_usage.pending_payload_bytes + snapshot.queue_usage.future_result_payload_bytes) +
        ",\"global_max_records\":" +
        std::to_string(snapshot.queue_limits.global_max_records) +
        ",\"global_max_payload_bytes\":" +
        std::to_string(snapshot.queue_limits.global_max_payload_bytes) +
        ",\"peer_max_records\":" +
        std::to_string(snapshot.queue_limits.peer_max_records) +
        ",\"peer_max_payload_bytes\":" +
        std::to_string(snapshot.queue_limits.peer_max_payload_bytes) +
        ",\"peers\":[";
    for (std::size_t i = 0U; i < snapshot.queue_usage.peers.size(); ++i) {
        if (i != 0U) { out += ','; }
        const auto& usage = snapshot.queue_usage.peers[i];
        out += "{\"peer\":" + json_string(usage.peer) +
            ",\"pending_records\":" +
            std::to_string(usage.pending_records) +
            ",\"pending_payload_bytes\":" +
            std::to_string(usage.pending_payload_bytes) +
            ",\"future_result_records\":" + std::to_string(usage.future_result_records) +
            ",\"future_result_payload_bytes\":" + std::to_string(usage.future_result_payload_bytes) + "}";
    }
    out += "]},\"entries\":[";
    for (std::size_t i = 0U; i < snapshot.outbound.size(); ++i) {
        if (i != 0U) { out += ','; }
        const auto& entry = snapshot.outbound[i];
        out += "{\"queue_sequence\":" + std::to_string(entry.queue_sequence) +
            ",\"operation_id\":" +
            json_string(operation_id_text(entry.record.operation_id)) +
            ",\"recipient\":" + json_string(entry.record.recipient) +
            ",\"scope\":" + json_string(entry.record.scope) +
            ",\"record_digest\":" +
            json_string(datacube::hex_lower(entry.record_digest)) +
            ",\"status\":" + json_string(outbound_status_name(entry)) +
            ",\"delivery\":";
        if (entry.delivery.has_value()) {
            const auto& delivery = *entry.delivery;
            out += "{\"created_unix_ms\":" +
                std::to_string(delivery.policy.created_unix_ms) +
                ",\"expires_unix_ms\":" +
                std::to_string(delivery.policy.expires_unix_ms) +
                ",\"maximum_attempts\":" +
                std::to_string(delivery.policy.maximum_attempts) +
                ",\"initial_backoff_ms\":" +
                std::to_string(delivery.policy.initial_backoff_ms) +
                ",\"maximum_backoff_ms\":" +
                std::to_string(delivery.policy.maximum_backoff_ms) +
                ",\"peer_generation\":" +
                (delivery.policy.peer_generation.has_value() ?
                    json_string(*delivery.policy.peer_generation) :
                    std::string("null")) +
                ",\"peer_spki_sha256\":" +
                (delivery.policy.peer_spki_sha256.has_value() ?
                    json_string(spki_sha256_text(
                        *delivery.policy.peer_spki_sha256)) :
                    std::string("null")) +
                ",\"attempts\":" + std::to_string(delivery.attempts) +
                ",\"last_attempt_unix_ms\":" +
                (delivery.last_attempt_unix_ms.has_value() ?
                    std::to_string(*delivery.last_attempt_unix_ms) :
                    std::string("null")) +
                ",\"next_attempt_unix_ms\":" +
                std::to_string(delivery.next_attempt_unix_ms) +
                ",\"last_error_code\":" +
                (delivery.last_error_code.empty() ?
                    std::string("null") : json_string(delivery.last_error_code)) +
                ",\"last_error_detail\":" +
                (delivery.last_error_detail.empty() ?
                    std::string("null") : json_string(delivery.last_error_detail)) +
                ",\"expired_unix_ms\":" +
                (delivery.expired_unix_ms.has_value() ?
                    std::to_string(*delivery.expired_unix_ms) :
                    std::string("null")) +
                ",\"expiry_reason\":" +
                (delivery.expiry_reason.empty() ?
                    std::string("null") : json_string(delivery.expiry_reason)) +
                ",\"cancelled_unix_ms\":" +
                (delivery.cancelled_unix_ms.has_value() ?
                    std::to_string(*delivery.cancelled_unix_ms) :
                    std::string("null")) +
                ",\"cancellation_reason\":" +
                (delivery.cancellation_reason.empty() ?
                    std::string("null") : json_string(delivery.cancellation_reason));
            const auto rejection = active_outbound_rejection(entry);
            out += ",\"rejection\":" +
                (rejection.has_value() ?
                    std::string("{\"rejected_unix_ms\":") +
                        std::to_string(rejection->rejected_unix_ms) +
                        ",\"code\":" + json_string(rejection->code) +
                        ",\"detail\":" + json_string(rejection->detail) +
                        ",\"detail_digest\":" +
                        json_string(datacube::hex_lower(rejection->detail_digest)) +
                        ",\"peer_generation\":" +
                        json_string(rejection->peer_generation) +
                        ",\"peer_spki_sha256\":" +
                        json_string(spki_sha256_text(rejection->peer_spki_sha256)) +
                        ",\"policy_digest\":" +
                        json_string(datacube::hex_lower(rejection->policy_digest)) + "}" :
                    std::string("null")) +
                ",\"transitions\":[";
            for (std::size_t t = 0U; t < delivery.transitions.size(); ++t) {
                if (t != 0U) { out += ','; }
                const auto& transition = delivery.transitions[t];
                out += "{\"kind\":" +
                    json_string(outbound_transition_kind_name(transition.kind)) +
                    ",\"unix_ms\":" + std::to_string(transition.unix_ms) +
                    ",\"actor\":" + json_string(transition.actor) +
                    ",\"reason\":" + json_string(transition.reason) +
                    ",\"from_generation\":" +
                    json_string(transition.from_generation) +
                    ",\"from_spki_sha256\":" +
                    json_string(spki_sha256_text(transition.from_spki_sha256));
                if (transition.kind == OutboundTransitionKind::rejected) {
                    out += ",\"to_generation\":null,\"to_spki_sha256\":null";
                    out += ",\"policy_digest\":" +
                        (transition.to_spki_sha256.has_value() ?
                            json_string(datacube::hex_lower(*transition.to_spki_sha256)) :
                            std::string("null"));
                } else {
                    out += ",\"to_generation\":" +
                        (transition.to_generation.has_value() ?
                            json_string(*transition.to_generation) :
                            std::string("null")) +
                        ",\"to_spki_sha256\":" +
                        (transition.to_spki_sha256.has_value() ?
                            json_string(spki_sha256_text(*transition.to_spki_sha256)) :
                            std::string("null")) +
                        ",\"policy_digest\":null";
                }
                out += "}";
            }
            out += "]}";
        } else {
            out += "null";
        }
        out += ",\"receipt\":";
        if (entry.receipt.has_value()) {
            out += "{\"disposition\":" +
                json_string(receipt_disposition_name(entry.receipt->disposition)) +
                ",\"sequence\":" + std::to_string(entry.receipt->sequence) +
                ",\"recorder\":" + json_string(entry.receipt->recorder) + "}";
        } else {
            out += "null";
        }
        out += "}";
    }
    out += "]}";
    out += ",\"authorization_denials\":{";
    out += "\"count\":" +
        std::to_string(snapshot.authorization_denials.size()) +
        ",\"entries\":[";
    for (std::size_t i = 0U; i < snapshot.authorization_denials.size(); ++i) {
        if (i != 0U) { out += ','; }
        const auto& denial = snapshot.authorization_denials[i];
        const auto& account = denial.authorization;
        out += "{\"operation_id\":" +
            json_string(operation_id_text(account.operation_id)) +
            ",\"record_digest\":" +
            json_string(datacube::hex_lower(account.record_digest)) +
            ",\"issuer\":" + json_string(denial.issuer) +
            ",\"recipient\":" + json_string(denial.recipient) +
            ",\"scope\":" + json_string(denial.scope) +
            ",\"peer\":" + json_string(account.peer_node) +
            ",\"generation\":" + json_string(account.peer_generation) +
            ",\"operation_class\":" +
            json_string(authorized_operation_class_name(
                account.operation_class)) +
            ",\"resource\":" + json_string(account.resource) +
            ",\"policy_digest\":" +
            json_string(datacube::hex_lower(account.policy_digest)) +
            ",\"rule_digest\":" +
            (account.rule_digest.has_value() ?
                json_string(datacube::hex_lower(*account.rule_digest)) :
                std::string("null")) +
            ",\"decided_unix_ms\":" +
            std::to_string(account.decided_unix_ms) +
            ",\"reason_code\":" + json_string(account.reason_code) + "}";
    }
    out += "]}";

    std::size_t action_pending = 0U;
    std::size_t action_executed = 0U;
    std::size_t action_cancelled = 0U;
    std::size_t action_expired = 0U;
    for (const auto& action : snapshot.actions) {
        if (action.completed_unix_ms.has_value()) { ++action_executed; }
        else if (action.cancelled_unix_ms.has_value()) { ++action_cancelled; }
        else if (action.expired_unix_ms.has_value()) { ++action_expired; }
        else { ++action_pending; }
    }
    out += ",\"actions\":{\"sink\":\"DURABLE_COUNTER_V1\"";
    out += ",\"counter_value\":" +
        std::to_string(snapshot.action_counter_value) +
        ",\"reserved_amount\":" +
        std::to_string(snapshot.action_reserved_amount) +
        ",\"count\":" + std::to_string(snapshot.actions.size()) +
        ",\"pending\":" + std::to_string(action_pending) +
        ",\"executed\":" + std::to_string(action_executed) +
        ",\"cancelled\":" + std::to_string(action_cancelled) +
        ",\"expired\":" + std::to_string(action_expired) +
        ",\"entries\":[";
    for (std::size_t i = 0U; i < snapshot.actions.size(); ++i) {
        if (i != 0U) { out += ','; }
        const auto& action = snapshot.actions[i];
        out += "{\"queue_sequence\":" + std::to_string(action.queue_sequence) +
            ",\"action_id\":" + json_string(operation_id_text(action.action_id)) +
            ",\"record_digest\":" +
            json_string(datacube::hex_lower(action.record_digest)) +
            ",\"issuer\":" + json_string(action.issuer) +
            ",\"peer_generation\":" + json_string(action.peer_generation) +
            ",\"status\":" + json_string(action_status_name(action)) +
            ",\"amount\":" + std::to_string(action.amount) +
            ",\"admitted_unix_ms\":" +
            std::to_string(action.admitted_unix_ms) +
            ",\"not_before_unix_ms\":" +
            std::to_string(action.not_before_unix_ms) +
            ",\"expires_unix_ms\":" +
            std::to_string(action.expires_unix_ms) +
            ",\"counter_budget\":" +
            std::to_string(action.limits.counter_budget) +
            ",\"maximum_increment\":" +
            std::to_string(action.limits.maximum_increment) +
            ",\"attempts\":" + std::to_string(action.attempts) +
            ",\"last_started_unix_ms\":" +
            (action.last_started_unix_ms.has_value() ?
                std::to_string(*action.last_started_unix_ms) :
                std::string("null")) +
            ",\"completed_unix_ms\":" +
            (action.completed_unix_ms.has_value() ?
                std::to_string(*action.completed_unix_ms) :
                std::string("null")) +
            ",\"cancelled_unix_ms\":" +
            (action.cancelled_unix_ms.has_value() ?
                std::to_string(*action.cancelled_unix_ms) :
                std::string("null")) +
            ",\"expired_unix_ms\":" +
            (action.expired_unix_ms.has_value() ?
                std::to_string(*action.expired_unix_ms) :
                std::string("null")) +
            ",\"counter_before\":" +
            (action.counter_before.has_value() ?
                std::to_string(*action.counter_before) : std::string("null")) +
            ",\"counter_after\":" +
            (action.counter_after.has_value() ?
                std::to_string(*action.counter_after) : std::string("null")) +
            ",\"receipt_digest\":" +
            (action.receipt_digest.has_value() ?
                json_string(datacube::hex_lower(*action.receipt_digest)) :
                std::string("null")) +
            ",\"policy_digest\":" +
            json_string(datacube::hex_lower(action.policy_digest)) +
            ",\"rule_digest\":" +
            json_string(datacube::hex_lower(action.rule_digest)) +
            ",\"last_error_code\":" +
            (action.last_error_code.empty() ? std::string("null") :
                json_string(action.last_error_code)) +
            ",\"cancellation_reason\":" +
            (action.cancellation_reason.empty() ? std::string("null") :
                json_string(action.cancellation_reason)) +
            ",\"expiry_reason\":" +
            (action.expiry_reason.empty() ? std::string("null") :
                json_string(action.expiry_reason)) + "}";
    }
    out += "]}}";
    out.pop_back();

    out += ",\"local_control\":{\"count\":" +
        std::to_string(snapshot.local_control_events.size()) +
        ",\"entries\":[";
    for (std::size_t event_index = 0U;
         event_index < snapshot.local_control_events.size(); ++event_index) {
        if (event_index != 0U) { out += ','; }
        const auto& event = snapshot.local_control_events[event_index];
        out += "{\"ordinal\":" + std::to_string(event_index + 1U) +
            ",\"request_id\":" +
            json_string(datacube::hex_lower(event.request_id)) +
            ",\"uid\":" + std::to_string(event.uid) +
            ",\"gid\":" + std::to_string(event.gid) +
            ",\"pid\":" + std::to_string(event.pid) +
            ",\"command\":" + json_string(event.command) +
            ",\"command_class\":" + json_string(event.command_class) +
            ",\"configuration_event\":" +
            std::to_string(event.configuration_event) +
            ",\"unix_ms\":" + std::to_string(event.unix_ms) +
            ",\"decision\":" +
            json_string(local_control_decision_kind_name(event.decision)) +
            ",\"error_code\":" +
            (event.error_code.empty() ? std::string("null") :
                json_string(event.error_code)) + "}";
    }
    out += "]}";

    std::string lifecycle_mode = "RUNNING";
    bool interrupted_drain = false;
    for (const auto& event : snapshot.lifecycle_events) {
        switch (event.kind) {
            case LifecycleTransitionKind::quiesced:
                lifecycle_mode = "QUIESCED";
                interrupted_drain = false;
                break;
            case LifecycleTransitionKind::resumed:
                lifecycle_mode = "RUNNING";
                interrupted_drain = false;
                break;
            case LifecycleTransitionKind::drain_started:
                lifecycle_mode = "QUIESCED";
                interrupted_drain = true;
                break;
            case LifecycleTransitionKind::drain_completed:
            case LifecycleTransitionKind::drain_deadline:
                lifecycle_mode = "RUNNING";
                interrupted_drain = false;
                break;
            case LifecycleTransitionKind::shutdown_requested:
                // Shutdown provenance does not change the durable mode.
                break;
        }
    }
    out += ",\"lifecycle\":{\"reconstructed_mode\":" +
        json_string(lifecycle_mode) +
        ",\"interrupted_drain\":" +
        std::string(interrupted_drain ? "true" : "false") +
        ",\"count\":" + std::to_string(snapshot.lifecycle_events.size()) +
        ",\"events\":[";
    for (std::size_t event_index = 0U;
         event_index < snapshot.lifecycle_events.size(); ++event_index) {
        if (event_index != 0U) { out += ','; }
        const auto& event = snapshot.lifecycle_events[event_index];
        out += "{\"ordinal\":" + std::to_string(event_index + 1U) +
            ",\"kind\":" +
            json_string(lifecycle_transition_kind_name(event.kind)) +
            ",\"request_id\":" +
            json_string(datacube::hex_lower(event.request_id)) +
            ",\"uid\":" + std::to_string(event.uid) +
            ",\"pid\":" + std::to_string(event.pid) +
            ",\"configuration_event\":" +
            std::to_string(event.configuration_event) +
            ",\"unix_ms\":" + std::to_string(event.unix_ms) +
            ",\"deadline_ms\":" + std::to_string(event.deadline_ms) +
            ",\"pending_outbound\":" +
            std::to_string(event.pending_outbound) +
            ",\"pending_actions\":" +
            std::to_string(event.pending_actions) +
            ",\"reason\":" + json_string(event.reason) + "}";
    }
    out += "]}";
    out += ",\"consumers\":[";
    for (std::size_t i = 0U; i < snapshot.consumers.size(); ++i) {
        if (i != 0U) { out += ','; }
        out += consumer_json(snapshot.consumers[i], true);
    }
    out += "]";
    out += ",\"projection_schedules\":[";
    for(std::size_t i=0;i<snapshot.projection_schedules.size();++i){if(i){out+=',';}out+=projection_schedule_json(snapshot.projection_schedules[i],true);}
    out += "]";
    out += ",\"publication_channels\":[";
    for (std::size_t i = 0U; i < snapshot.publication_channels.size(); ++i) {
        if (i != 0U) { out += ','; }
        out += publication_channel_json(snapshot.publication_channels[i], true);
    }
    out += "]";
    out += ",\"import_automation\":[";
    for(std::size_t i=0U;i<snapshot.import_schedules.size();++i){if(i)out+=",";out+=import_auto_json(snapshot.import_schedules[i],true);}
    out += "]";
    out += ",\"source_subscriptions\":[";
    for (std::size_t i = 0U; i < snapshot.source_subscriptions.size(); ++i) {
        if (i != 0U) { out += ','; }
        out += source_subscription_json(snapshot.source_subscriptions[i], true);
    }
    out += "]";
    if(!snapshot.outbox_admin_accounts.empty()) {
        out+=",\"conditional_outbox_actions\":[";
        for(std::size_t i=0U;i<snapshot.outbox_admin_accounts.size();++i){if(i)out+=",";out+=snapshot.outbox_admin_accounts[i];}out+="]";
    }
    if(!snapshot.action_admin_accounts.empty()) {
        out+=",\"conditional_action_cancellations\":[";
        for(std::size_t i=0U;i<snapshot.action_admin_accounts.size();++i){if(i)out+=",";out+=snapshot.action_admin_accounts[i];}out+="]";
    }
    out += ",\"runtime_configuration\":" + configuration_history_json(snapshot, false) + "}";
    return out;
}

std::string send_result_json(const SendResult& result) {
    const auto status = result.handshake.status.has_value() ?
        datacube::natrav_peer_client_exchange_status_name(*result.handshake.status) :
        std::string_view("SKIPPED");
    const auto classification = result.handshake.classification.value_or("SKIPPED");
    return std::string("{\"format\":\"NATRAV_OVERLAY_SEND_V1\",\"ok\":true") +
        ",\"queue_disposition\":" +
        json_string(queue_disposition_name(result.queue_disposition)) +
        ",\"network_used\":" + (result.network_used ? "true" : "false") +
        ",\"secure_transport\":" +
        (result.secure_transport ? "true" : "false") +
        ",\"tls\":" +
        (result.tls_session.has_value() ?
            tls_session_json(*result.tls_session) : std::string("null")) +
        ",\"operation_id\":" +
        json_string(operation_id_text(result.receipt.operation_id)) +
        ",\"receipt_disposition\":" +
        json_string(receipt_disposition_name(result.receipt.disposition)) +
        ",\"receipt_sequence\":" + std::to_string(result.receipt.sequence) +
        ",\"record_digest\":" +
        json_string(datacube::hex_lower(result.receipt.record_digest)) +
        ",\"handshake_status\":" + json_string(status) +
        ",\"handshake_classification\":" + json_string(classification) +
        ",\"connect_io\":" + counters_json(result.connect_counters) +
        ",\"tls_io\":" + counters_json(result.tls_counters) +
        ",\"handshake_io\":" + counters_json(result.handshake_counters) +
        ",\"application_io\":" + counters_json(result.application_counters) +
        "}";
}

std::string flush_result_json(const FlushResult& result) {
    std::string operations = "[";
    for (std::size_t index = 0U;
         index < result.acknowledged_operations.size(); ++index) {
        if (index != 0U) { operations += ','; }
        operations += json_string(
            operation_id_text(result.acknowledged_operations[index]));
    }
    operations += ']';
    return std::string("{\"format\":\"NATRAV_OVERLAY_FLUSH_V1\",\"ok\":true") +
        ",\"peer\":" + json_string(result.peer) +
        ",\"pending_before\":" + std::to_string(result.pending_before) +
        ",\"attempted\":" + std::to_string(result.attempted) +
        ",\"acknowledged\":" + std::to_string(result.acknowledged) +
        ",\"committed\":" + std::to_string(result.committed) +
        ",\"duplicate\":" + std::to_string(result.duplicate) +
        ",\"pending_after\":" + std::to_string(result.pending_after) +
        ",\"acknowledged_operations\":" + operations +
        ",\"connect_io\":" + counters_json(result.connect_counters) +
        ",\"handshake_io\":" + counters_json(result.handshake_counters) +
        ",\"application_io\":" + counters_json(result.application_counters) +
        "}";
}

std::string error_json(
    const std::string_view code,
    const std::string_view detail) {
    return std::string("{\"format\":\"NATRAV_OVERLAY_ERROR_V1\",\"ok\":false") +
        ",\"code\":" + json_string(code) +
        ",\"detail\":" + json_string(detail) + "}";
}

}  // namespace natrav_overlay
