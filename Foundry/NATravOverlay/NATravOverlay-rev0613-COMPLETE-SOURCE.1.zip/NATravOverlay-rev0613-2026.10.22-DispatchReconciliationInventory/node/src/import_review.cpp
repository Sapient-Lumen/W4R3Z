#include "journal.hpp"
#include "config.hpp"
#include <algorithm>

namespace natrav_overlay {
namespace {
using Digest=datacube::Digest32;
Digest event_digest(const ImportAutoEvent& event) {
    datacube::Octets bytes;
    datacube::append_text(bytes,"NATRAV_OVERLAY_IMPORT_EVENT_V1");
    datacube::append_u8(bytes,0U);
    datacube::append_octets(bytes,encode_import_auto_event(event));
    return datacube::sha256(bytes);
}
std::string hex(const Digest& d) {return json_string(datacube::hex_lower(d));}
bool candidate_event(const ImportAutoEvent& e) {
    return e.action=="SCAN" || e.action=="RETRY" || e.action=="MANUAL_RETRY";
}
void require(bool value,std::string_view code,std::string_view reason) {
    if(!value)app_fail(code,reason);
}
} // namespace

// Resolve through the exact event's accepted configuration and its immutable
// inbound prefix. Never accept an operation supplied by the requester instead.
Digest NodeState::import_event_operation_locked(const ImportAutoEvent& e) const {
    require(candidate_event(e)&&e.configuration_event>0U&&e.configuration_event<=configuration_events_.size(),
        "JOURNAL_CORRUPT","candidate event and accepted configuration required");
    const auto& ce=configuration_events_[static_cast<std::size_t>(e.configuration_event-1U)];
    const auto config=parse_runtime_config(ce.canonical,"/import-review-history",IdentityFileValidation::deferred);
    const auto rule=std::find_if(config.source_views.rules.begin(),config.source_views.rules.end(),[&](const auto& r){return r.id==e.view;});
    require(rule!=config.source_views.rules.end(),"JOURNAL_CORRUPT","candidate view missing");
    const auto domain=inbound_domain_index_.find({rule->provider,rule->source_scope});
    require(domain!=inbound_domain_index_.end()&&e.inbound_count<=inbound_.size()&&
        e.ordinal<domain->second.before(static_cast<std::size_t>(e.inbound_count),true),
        "JOURNAL_CORRUPT","candidate ordinal beyond original inbound prefix");
    return inbound_[domain->second.at(static_cast<std::size_t>(e.ordinal),true)].record.operation_id;
}

std::string NodeState::import_decision_json_locked(const ImportAutoEvent& e) const {
    const bool candidate=candidate_event(e);
    auto result="{\"revision\":"+std::to_string(e.revision+1U)+",\"decision_digest\":"+hex(event_digest(e))+
        ",\"action\":"+json_string(e.action)+",\"outcome\":"+json_string(e.outcome)+
        ",\"configuration_event\":"+std::to_string(e.configuration_event)+",\"configuration_digest\":"+hex(configuration_events_[static_cast<std::size_t>(e.configuration_event-1U)].digest)+",\"unix_ms\":"+std::to_string(e.unix_ms)+
        ",\"actor_uid\":"+std::to_string(e.uid)+",\"actor_gid\":"+std::to_string(e.gid)+",\"actor_pid\":"+std::to_string(e.pid)+
        ",\"reason\":"+json_string(e.reason)+",\"outer_operation\":"+(candidate?hex(import_event_operation_locked(e)):"null")+
        ",\"source_domain_ordinal\":"+(candidate?std::to_string(e.ordinal):"null")+
        ",\"selected_decision_revision\":"+(e.action=="MANUAL_RETRY"?std::to_string(e.decision_revision):"null")+
        ",\"selected_decision_digest\":"+(e.action=="MANUAL_RETRY"?hex(e.decision_digest):"null");
    if(e.action=="RETIRE")result+=",\"selected_final_state_digest\":"+hex(e.final_state_digest)+
        ",\"selected_view_digest\":"+hex(e.view_digest)+",\"deferred_disposition\":"+json_string(e.deferred_disposition);
    return result+"}";
}

std::string NodeState::review_import_decisions_locked(const ImportAutoRequest& request,
    const ImportAutoState& state,const RuntimeConfig& config,const std::uint64_t configuration_event) const {
    static_cast<void>(config);
    const auto count=static_cast<std::uint64_t>(state.history.size());
    const auto through=request.through_revision==0U?count:request.through_revision;
    require(through<=count&&request.after_revision<=through&&request.page_limit>=1U&&request.page_limit<=32U&&
        request.maximum_bytes>=2048U&&request.maximum_bytes<=60000U,"IMPORT_REVIEW_INVALID","bounded page and retained prefix required");
    const Digest root=through==0U?Digest{}:event_digest(state.history[static_cast<std::size_t>(through-1U)]);
    require(request.through_revision==0U||request.history_digest==root,"IMPORT_REVIEW_PREFIX_CONFLICT","selected history prefix differs");
    require(configuration_event>0U&&configuration_event<=configuration_events_.size(),"JOURNAL_CORRUPT","review configuration required");
    std::vector<std::string> rows;
    std::size_t row_bytes=0U;
    std::uint64_t next=request.after_revision;
    std::size_t visited=0U;
    const auto prefix="{\"format\":\"NATRAV_OVERLAY_IMPORT_DECISIONS_V1\",\"view\":"+json_string(state.view)+
        ",\"owner_uid\":"+std::to_string(state.uid)+",\"view_digest\":"+hex(state.rule_digest)+
        ",\"configuration_digest\":"+hex(configuration_events_[static_cast<std::size_t>(configuration_event-1U)].digest)+
        ",\"current_revision\":"+std::to_string(count)+",\"through_revision\":"+std::to_string(through)+
        ",\"history_digest\":"+hex(root)+",\"after_revision\":"+std::to_string(request.after_revision)+
        ",\"maximum_bytes\":"+std::to_string(request.maximum_bytes);
    // Reserve the complete footer and the existing local-principal annotation.
    // No payload or complete history copy is constructed to size the page.
    constexpr std::size_t reserve=1024U;
    while(next<through&&rows.size()<request.page_limit){
        ++visited;
        auto row=import_decision_json_locked(state.history[static_cast<std::size_t>(next)]);
        if(prefix.size()+row_bytes+row.size()+rows.size()+reserve>request.maximum_bytes){
            require(!rows.empty(),"IMPORT_REVIEW_PAGE_TOO_SMALL","first complete administrative decision cannot fit");break;
        }
        row_bytes+=row.size();rows.push_back(std::move(row));++next;
    }
    auto result=prefix+",\"next_after_revision\":"+std::to_string(next)+",\"more\":"+(next<through?"true":"false")+
        ",\"decisions_visited\":"+std::to_string(visited)+",\"events\":[";
    for(std::size_t i=0U;i<rows.size();++i){if(i)result+=",";result+=rows[i];}
    return result+"]}";
}
} // namespace natrav_overlay
