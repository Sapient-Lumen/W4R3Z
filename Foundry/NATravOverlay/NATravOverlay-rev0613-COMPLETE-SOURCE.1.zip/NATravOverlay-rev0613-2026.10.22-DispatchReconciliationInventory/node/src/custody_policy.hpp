#pragma once

#include "custody_envelope.hpp"

#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

inline constexpr std::string_view kCustodyRelayPolicyFeature =
    "V21_DURABLE_CUSTODY_RELAY_POLICY_V1";
inline constexpr std::size_t kCustodyRelayGrantLimit = 128U;
inline constexpr std::size_t kCustodyRelayGrantPerIdLimit = 16U;
inline constexpr std::uint32_t kCustodyRelayMaximumActiveLimit = 256U;
inline constexpr std::uint64_t kCustodyRelayMaximumBytesLimit = kHandoffCapsuleLimit;

enum class CustodyRelayGrantState : std::uint8_t {
    active = 1U,
    retired = 2U,
    revoked = 3U,
};

struct CustodyRelayGrant final {
    std::string id;
    std::uint64_t generation{1U};
    datacube::Digest32 predecessor;
    CustodyRelayGrantState state{CustodyRelayGrantState::active};
    std::string origin;
    std::string origin_signing_generation;
    std::string final_recipient;
    std::string final_signing_generation;
    std::string custodian;
    std::string custodian_signing_generation;
    std::string next_hop;
    std::string next_hop_signing_generation;
    std::uint64_t maximum_envelope_lifetime_ms{0U};
    std::uint8_t maximum_hops{0U};
    std::uint32_t maximum_active_envelopes{0U};
    std::uint64_t maximum_capsule_bytes{0U};
};

using CustodyRelayPolicy = std::vector<CustodyRelayGrant>;

struct CustodyGrantReference final {
    std::string id;
    std::uint64_t generation{0U};
    datacube::Digest32 commitment;

    bool operator==(const CustodyGrantReference&) const = default;
};

[[nodiscard]] std::string_view custody_relay_grant_state_name(
    CustodyRelayGrantState state);
[[nodiscard]] std::string custody_relay_grant_commitment_text(
    const CustodyRelayGrant& grant);
[[nodiscard]] datacube::Digest32 custody_relay_grant_commitment(
    const CustodyRelayGrant& grant);
[[nodiscard]] std::string custody_relay_grant_text(
    const CustodyRelayGrant& grant);
[[nodiscard]] CustodyRelayGrant parse_custody_relay_grant(
    std::string_view hex);
void normalize_custody_relay_policy(CustodyRelayPolicy& grants);
void require_custody_relay_history_preserved(
    const CustodyRelayPolicy& historical,
    const CustodyRelayPolicy& candidate);
[[nodiscard]] const CustodyRelayGrant* find_custody_relay_grant(
    const CustodyRelayPolicy& policy,
    std::string_view id,
    std::uint64_t generation) noexcept;
[[nodiscard]] const CustodyRelayGrant* find_matching_custody_relay_grant(
    const CustodyRelayPolicy& policy,
    const CustodyEnvelope& envelope,
    std::size_t hop_index,
    bool require_active);
void require_custody_relay_grant_use(
    const CustodyRelayGrant& grant,
    const CustodyEnvelope& envelope,
    std::size_t hop_index,
    bool require_active);
[[nodiscard]] CustodyGrantReference custody_grant_reference(
    const CustodyRelayGrant& grant);
[[nodiscard]] std::string custody_relay_policy_json(
    const CustodyRelayPolicy& grants);

} // namespace natrav_overlay
