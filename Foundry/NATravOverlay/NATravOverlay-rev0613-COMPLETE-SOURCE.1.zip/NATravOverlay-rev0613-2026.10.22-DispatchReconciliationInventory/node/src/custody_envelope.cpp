#include "custody_envelope.hpp"

#include <algorithm>
#include <limits>
#include <memory>
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <utility>

namespace natrav_overlay {
namespace {

using Bytes = datacube::Octets;
using View = datacube::OctetView;
template<class T, void (*Destroy)(T*)>
using Ptr = std::unique_ptr<T, decltype(Destroy)>;
using Key = Ptr<EVP_PKEY, EVP_PKEY_free>;
using Context = Ptr<EVP_MD_CTX, EVP_MD_CTX_free>;

constexpr std::string_view envelope_magic = "NHCE0001";
constexpr std::string_view record_magic = "NHCR0001";
constexpr std::string_view envelope_signature_domain =
    "NATravOverlay/custody-envelope/v1";
constexpr std::string_view record_signature_domain =
    "NATravOverlay/custody-record/v1";
constexpr std::size_t signature_bytes = 64U;
constexpr std::size_t maximum_records =
    2U * (kCustodyRoutePartyLimit - 1U);

void require(bool condition, std::string_view code, std::string_view detail) {
    if (!condition) {
        app_fail(code, detail);
    }
}

void crypto(bool condition) {
    require(condition, "CUSTODY_CRYPTO_FAILED", "cryptographic operation failed");
}

bool nonzero(View value) {
    return std::any_of(value.begin(), value.end(),
        [](std::uint8_t byte) { return byte != 0U; });
}

View digest_view(const datacube::Digest32& digest) {
    return View(digest.octets.data(), digest.octets.size());
}

View key_view(const CustodySigningKey& key) {
    return View(key.data(), key.size());
}

struct Writer final {
    Bytes bytes;

    void raw(View value) {
        bytes.insert(bytes.end(), value.begin(), value.end());
    }
    void text(std::string_view value) {
        raw(View(reinterpret_cast<const std::uint8_t*>(value.data()), value.size()));
    }
    void u8(std::uint8_t value) { datacube::append_u8(bytes, value); }
    void u16(std::uint16_t value) { datacube::append_be16(bytes, value); }
    void u32(std::uint32_t value) { datacube::append_be32(bytes, value); }
    void u64(std::uint64_t value) { datacube::append_be64(bytes, value); }
    void digest(const datacube::Digest32& value) { raw(digest_view(value)); }
    void key(const CustodySigningKey& value) { raw(key_view(value)); }
    void identifier(std::string_view value) {
        require(!value.empty() && value.size() <= 64U,
            "CUSTODY_ENCODING_REJECTED", "identifier length is outside bounds");
        u8(static_cast<std::uint8_t>(value.size()));
        text(value);
    }
};

struct Reader final {
    View bytes;
    std::size_t offset{0U};

    View take(std::size_t count) {
        require(count <= bytes.size() - offset,
            "CUSTODY_ENCODING_REJECTED", "truncated field");
        const auto result = bytes.subspan(offset, count);
        offset += count;
        return result;
    }
    std::uint64_t number(std::size_t count) {
        std::uint64_t result = 0U;
        for (const auto byte : take(count)) {
            result = (result << 8U) | byte;
        }
        return result;
    }
    std::uint8_t u8() { return static_cast<std::uint8_t>(number(1U)); }
    std::uint16_t u16() { return static_cast<std::uint16_t>(number(2U)); }
    std::uint32_t u32() { return static_cast<std::uint32_t>(number(4U)); }
    std::uint64_t u64() { return number(8U); }
    std::string identifier() {
        const auto count = u8();
        require(count > 0U && count <= 64U,
            "CUSTODY_ENCODING_REJECTED", "identifier length is outside bounds");
        const auto value = take(count);
        return std::string(reinterpret_cast<const char*>(value.data()), value.size());
    }
    datacube::Digest32 digest() {
        datacube::Digest32 result;
        const auto value = take(result.octets.size());
        std::copy(value.begin(), value.end(), result.octets.begin());
        return result;
    }
    CustodySigningKey key() {
        CustodySigningKey result{};
        const auto value = take(result.size());
        std::copy(value.begin(), value.end(), result.begin());
        return result;
    }
    void magic(std::string_view expected) {
        const auto value = take(expected.size());
        require(std::equal(value.begin(), value.end(), expected.begin()),
            "CUSTODY_ENCODING_REJECTED", "unknown format");
    }
    void end() const {
        require(offset == bytes.size(),
            "CUSTODY_ENCODING_REJECTED", "trailing bytes");
    }
};

Bytes domain_bytes(std::string_view domain, View message) {
    Writer writer;
    writer.text(domain);
    writer.u8(0U);
    writer.raw(message);
    return std::move(writer.bytes);
}

CustodySigningKey public_bytes(EVP_PKEY* key) {
    require(key != nullptr && EVP_PKEY_id(key) == EVP_PKEY_ED25519,
        "CUSTODY_SIGNING_KEY_REJECTED", "Ed25519 signing key required");
    CustodySigningKey result{};
    std::size_t count = result.size();
    crypto(EVP_PKEY_get_raw_public_key(key, result.data(), &count) == 1 &&
        count == result.size());
    return result;
}

Key public_key(const CustodySigningKey& bytes) {
    require(nonzero(key_view(bytes)),
        "CUSTODY_PARTY_REJECTED", "zero signing key is forbidden");
    EVP_PKEY* raw = EVP_PKEY_new_raw_public_key(
        EVP_PKEY_ED25519, nullptr, bytes.data(), bytes.size());
    crypto(raw != nullptr);
    return Key(raw, EVP_PKEY_free);
}

Bytes sign(EVP_PKEY* private_key, const CustodySigningKey& expected_public,
    std::string_view domain, View message) {
    require(public_bytes(private_key) == expected_public,
        "CUSTODY_SIGNING_KEY_REJECTED", "signing key does not match route party");
    const auto input = domain_bytes(domain, message);
    Context context(EVP_MD_CTX_new(), EVP_MD_CTX_free);
    crypto(context != nullptr &&
        EVP_DigestSignInit(context.get(), nullptr, nullptr, nullptr, private_key) == 1);
    Bytes signature(signature_bytes);
    std::size_t count = signature.size();
    crypto(EVP_DigestSign(context.get(), signature.data(), &count,
        input.data(), input.size()) == 1 && count == signature.size());
    return signature;
}

void verify(const CustodySigningKey& signing_public,
    std::string_view domain, View message, View signature) {
    auto key = public_key(signing_public);
    const auto input = domain_bytes(domain, message);
    Context context(EVP_MD_CTX_new(), EVP_MD_CTX_free);
    crypto(context != nullptr &&
        EVP_DigestVerifyInit(context.get(), nullptr, nullptr, nullptr, key.get()) == 1);
    require(signature.size() == signature_bytes &&
        EVP_DigestVerify(context.get(), signature.data(), signature.size(),
            input.data(), input.size()) == 1,
        "CUSTODY_SIGNATURE_REJECTED", "signature did not verify");
}

void validate_party(const CustodyParty& party) {
    require_node_id(party.node, "custody party node");
    require_generation_id(party.signing_generation,
        "custody party signing generation");
    require(party.node.size() <= 64U && party.signing_generation.size() <= 64U,
        "CUSTODY_PARTY_REJECTED", "party identifier exceeds encoding bound");
    (void)public_key(party.signing_public);
}

void write_party(Writer& writer, const CustodyParty& party) {
    validate_party(party);
    writer.identifier(party.node);
    writer.identifier(party.signing_generation);
    writer.key(party.signing_public);
}

CustodyParty read_party(Reader& reader) {
    CustodyParty party;
    party.node = reader.identifier();
    party.signing_generation = reader.identifier();
    party.signing_public = reader.key();
    validate_party(party);
    return party;
}

void validate_route(std::span<const CustodyParty> route) {
    require(route.size() >= 2U && route.size() <= kCustodyRoutePartyLimit,
        "CUSTODY_ROUTE_REJECTED", "route party count is outside bounds");
    for (std::size_t index = 0U; index < route.size(); ++index) {
        validate_party(route[index]);
        for (std::size_t previous = 0U; previous < index; ++previous) {
            require(route[index].node != route[previous].node,
                "CUSTODY_ROUTE_LOOP", "route repeats a node");
            require(route[index].signing_public != route[previous].signing_public,
                "CUSTODY_ROUTE_KEY_REUSE", "route reuses a signing key");
        }
    }
}

void validate_envelope_fields(const CustodyEnvelope& envelope) {
    validate_route(envelope.route);
    require(envelope.hop_limit == envelope.route.size() - 1U,
        "CUSTODY_HOP_BOUND_REJECTED", "hop bound must exactly match explicit route");
    require(envelope.created_ms != 0U && envelope.expires_ms > envelope.created_ms &&
        envelope.expires_ms - envelope.created_ms <= kCustodyEnvelopeLifetimeLimitMs,
        "CUSTODY_TIME_REJECTED", "invalid envelope lifetime");
    require(envelope.capsule_bytes > 0U &&
        envelope.capsule_bytes <= kHandoffCapsuleLimit,
        "CUSTODY_CAPSULE_REJECTED", "opaque capsule size is outside bounds");
    require(!digest_is_zero(envelope.capsule_sha256),
        "CUSTODY_CAPSULE_REJECTED", "opaque capsule digest is zero");
}

Writer envelope_unsigned(const CustodyEnvelope& envelope) {
    validate_envelope_fields(envelope);
    Writer writer;
    writer.text(envelope_magic);
    writer.u16(0U);
    writer.u64(envelope.created_ms);
    writer.u64(envelope.expires_ms);
    writer.u8(envelope.hop_limit);
    writer.u32(envelope.capsule_bytes);
    writer.digest(envelope.capsule_sha256);
    writer.u8(static_cast<std::uint8_t>(envelope.route.size()));
    for (const auto& party : envelope.route) {
        write_party(writer, party);
    }
    require(writer.bytes.size() + signature_bytes <= kCustodyEnvelopeLimit,
        "CUSTODY_ENCODING_REJECTED", "envelope exceeds bound");
    return writer;
}

Writer record_unsigned(const CustodyRecord& record) {
    Writer writer;
    writer.text(record_magic);
    writer.u16(0U);
    writer.u8(static_cast<std::uint8_t>(record.kind));
    writer.u16(record.sequence);
    writer.u8(record.hop_index);
    writer.u8(record.actor_index);
    writer.u8(record.counterparty_index);
    writer.u64(record.event_ms);
    writer.digest(record.envelope_sha256);
    writer.digest(record.previous_record_sha256);
    writer.digest(record.capsule_sha256);
    require(writer.bytes.size() + signature_bytes <= kCustodyRecordLimit,
        "CUSTODY_ENCODING_REJECTED", "record exceeds bound");
    return writer;
}

bool same_envelope_fields(const CustodyEnvelope& left,
    const CustodyEnvelope& right) {
    return left.created_ms == right.created_ms &&
        left.expires_ms == right.expires_ms &&
        left.hop_limit == right.hop_limit &&
        left.capsule_bytes == right.capsule_bytes &&
        left.capsule_sha256 == right.capsule_sha256 &&
        left.route == right.route;
}

bool same_record_fields(const CustodyRecord& left,
    const CustodyRecord& right) {
    return left.kind == right.kind &&
        left.sequence == right.sequence &&
        left.hop_index == right.hop_index &&
        left.actor_index == right.actor_index &&
        left.counterparty_index == right.counterparty_index &&
        left.event_ms == right.event_ms &&
        left.envelope_sha256 == right.envelope_sha256 &&
        left.previous_record_sha256 == right.previous_record_sha256 &&
        left.capsule_sha256 == right.capsule_sha256;
}

void validate_record_shape(const CustodyEnvelope& envelope,
    const CustodyRecord& record) {
    const auto route_size = envelope.route.size();
    require(record.kind == CustodyRecordKind::transfer ||
        record.kind == CustodyRecordKind::acceptance,
        "CUSTODY_RECORD_REJECTED", "unknown custody record kind");
    require(record.hop_index < envelope.hop_limit,
        "CUSTODY_RECORD_REJECTED", "hop index exceeds bound");
    require(record.actor_index < route_size && record.counterparty_index < route_size,
        "CUSTODY_RECORD_REJECTED", "party index exceeds route");
    const auto hop = static_cast<std::uint16_t>(record.hop_index);
    const auto expected_sequence = static_cast<std::uint16_t>(
        (2U * hop) + (record.kind == CustodyRecordKind::transfer ? 1U : 2U));
    require(record.sequence == expected_sequence,
        "CUSTODY_RECORD_REJECTED", "record sequence is not canonical for hop");
    if (record.kind == CustodyRecordKind::transfer) {
        require(record.actor_index == record.hop_index &&
            record.counterparty_index == record.hop_index + 1U,
            "CUSTODY_NEXT_HOP_REJECTED", "transfer does not name the explicit next hop");
    } else {
        require(record.actor_index == record.hop_index + 1U &&
            record.counterparty_index == record.hop_index,
            "CUSTODY_NEXT_HOP_REJECTED", "acceptance does not name the explicit transferor");
    }
    require(record.event_ms >= envelope.created_ms &&
        record.event_ms < envelope.expires_ms,
        "CUSTODY_TIME_REJECTED", "record time is outside envelope lifetime");
    require(record.envelope_sha256 == datacube::sha256(envelope.canonical),
        "CUSTODY_ENVELOPE_MISMATCH", "record names a different envelope");
    require(record.capsule_sha256 == envelope.capsule_sha256,
        "CUSTODY_CAPSULE_REJECTED", "record names a different capsule");
    if (record.sequence == 1U) {
        require(digest_is_zero(record.previous_record_sha256),
            "CUSTODY_CHAIN_REJECTED", "first record must use the zero predecessor");
    } else {
        require(!digest_is_zero(record.previous_record_sha256),
            "CUSTODY_CHAIN_REJECTED", "later record requires a predecessor");
    }
}

void validate_progress(const CustodyEnvelope& envelope,
    const CustodyProgress& progress) {
    const auto count = progress.accepted_record_sha256.size();
    require(count <= static_cast<std::size_t>(2U * envelope.hop_limit),
        "CUSTODY_STATE_REJECTED", "record history exceeds envelope hop bound");
    require(progress.next_sequence == count + 1U,
        "CUSTODY_STATE_REJECTED", "next sequence differs from record history");
    require(progress.current_party_index == count / 2U,
        "CUSTODY_STATE_REJECTED", "current custodian differs from record history");
    require(progress.awaiting_acceptance == ((count % 2U) != 0U),
        "CUSTODY_STATE_REJECTED", "pending acceptance differs from record history");
    require(progress.current_party_index <= envelope.hop_limit,
        "CUSTODY_STATE_REJECTED", "current custodian exceeds route");
    if (count == 0U) {
        require(digest_is_zero(progress.last_record_sha256) &&
            progress.last_event_ms == envelope.created_ms,
            "CUSTODY_STATE_REJECTED", "initial state is not canonical");
    } else {
        require(!digest_is_zero(progress.last_record_sha256) &&
            progress.last_record_sha256 == progress.accepted_record_sha256.back(),
            "CUSTODY_STATE_REJECTED", "last record digest differs from history");
        require(progress.last_event_ms >= envelope.created_ms &&
            progress.last_event_ms < envelope.expires_ms,
            "CUSTODY_STATE_REJECTED", "last event time is outside envelope lifetime");
    }
    for (std::size_t index = 0U; index < count; ++index) {
        require(!digest_is_zero(progress.accepted_record_sha256[index]),
            "CUSTODY_STATE_REJECTED", "record history contains the zero digest");
        const auto before = progress.accepted_record_sha256.begin() +
            static_cast<std::ptrdiff_t>(index);
        require(std::find(progress.accepted_record_sha256.begin(), before,
            progress.accepted_record_sha256[index]) == before,
            "CUSTODY_STATE_REJECTED", "record history contains a duplicate digest");
    }
}

void require_live_time(const CustodyEnvelope& envelope,
    const CustodyProgress& progress, std::uint64_t event_ms) {
    require(event_ms >= envelope.created_ms && event_ms < envelope.expires_ms,
        "CUSTODY_TIME_REJECTED", "event is outside envelope lifetime");
    require(event_ms >= progress.last_event_ms,
        "CUSTODY_TIME_REJECTED", "event time moved backward");
}

CustodyRecord make_record(const CustodyEnvelope& envelope,
    const CustodyProgress& progress, CustodyRecordKind kind,
    std::uint64_t event_ms, EVP_PKEY* private_key) {
    validate_envelope_fields(envelope);
    (void)custody_envelope_sha256(envelope);
    validate_progress(envelope, progress);
    require_live_time(envelope, progress, event_ms);
    require(progress.current_party_index + 1U < envelope.route.size(),
        "CUSTODY_FINAL_STATE", "final recipient already holds custody");
    if (kind == CustodyRecordKind::transfer) {
        require(!progress.awaiting_acceptance,
            "CUSTODY_STATE_REJECTED", "a transfer is already awaiting acceptance");
    } else {
        require(progress.awaiting_acceptance,
            "CUSTODY_STATE_REJECTED", "no transfer is awaiting acceptance");
    }

    CustodyRecord record;
    record.kind = kind;
    record.hop_index = progress.current_party_index;
    record.sequence = progress.next_sequence;
    if (kind == CustodyRecordKind::transfer) {
        record.actor_index = progress.current_party_index;
        record.counterparty_index = static_cast<std::uint8_t>(
            progress.current_party_index + 1U);
    } else {
        record.actor_index = static_cast<std::uint8_t>(
            progress.current_party_index + 1U);
        record.counterparty_index = progress.current_party_index;
    }
    record.event_ms = event_ms;
    record.envelope_sha256 = custody_envelope_sha256(envelope);
    record.previous_record_sha256 = progress.last_record_sha256;
    record.capsule_sha256 = envelope.capsule_sha256;
    validate_record_shape(envelope, record);

    auto unsigned_bytes = record_unsigned(record);
    const auto signature = sign(private_key,
        envelope.route[record.actor_index].signing_public,
        record_signature_domain, unsigned_bytes.bytes);
    unsigned_bytes.raw(signature);
    record.canonical = std::move(unsigned_bytes.bytes);
    return record;
}

} // namespace

bool CustodyProgress::final_custody_accepted(
    const CustodyEnvelope& envelope) const noexcept {
    return !envelope.route.empty() && !awaiting_acceptance &&
        static_cast<std::size_t>(current_party_index) + 1U == envelope.route.size();
}

datacube::Digest32 custody_party_signing_pin(const CustodyParty& party) {
    validate_party(party);
    const auto key = public_key(party.signing_public);
    const int count = ::i2d_PUBKEY(key.get(), nullptr);
    require(count > 0 && count <= 1'024,
        "CUSTODY_CRYPTO_FAILED", "public key encoding is outside bounds");
    Bytes encoded(static_cast<std::size_t>(count));
    auto* output = encoded.data();
    crypto(::i2d_PUBKEY(key.get(), &output) == count);
    return datacube::sha256(encoded);
}

CustodyParty make_custody_party(std::string_view node,
    std::string_view signing_generation, EVP_PKEY* signing_private) {
    CustodyParty party;
    party.node = std::string(node);
    party.signing_generation = std::string(signing_generation);
    party.signing_public = public_bytes(signing_private);
    validate_party(party);
    return party;
}

CustodyEnvelope make_custody_envelope(std::span<const CustodyParty> route,
    datacube::OctetView opaque_capsule, std::uint64_t created_ms,
    std::uint64_t expires_ms, EVP_PKEY* origin_signing_private) {
    validate_route(route);
    require(!opaque_capsule.empty() && opaque_capsule.size() <= kHandoffCapsuleLimit,
        "CUSTODY_CAPSULE_REJECTED", "opaque capsule size is outside bounds");
    require(opaque_capsule.size() <= std::numeric_limits<std::uint32_t>::max(),
        "CUSTODY_CAPSULE_REJECTED", "opaque capsule size cannot be encoded");

    CustodyEnvelope envelope;
    envelope.created_ms = created_ms;
    envelope.expires_ms = expires_ms;
    envelope.hop_limit = static_cast<std::uint8_t>(route.size() - 1U);
    envelope.capsule_bytes = static_cast<std::uint32_t>(opaque_capsule.size());
    envelope.capsule_sha256 = datacube::sha256(opaque_capsule);
    envelope.route.assign(route.begin(), route.end());
    validate_envelope_fields(envelope);

    auto unsigned_bytes = envelope_unsigned(envelope);
    const auto signature = sign(origin_signing_private,
        envelope.route.front().signing_public,
        envelope_signature_domain, unsigned_bytes.bytes);
    unsigned_bytes.raw(signature);
    envelope.canonical = std::move(unsigned_bytes.bytes);
    return envelope;
}

CustodyEnvelope decode_custody_envelope(datacube::OctetView bytes) {
    require(!bytes.empty() && bytes.size() <= kCustodyEnvelopeLimit,
        "CUSTODY_ENCODING_REJECTED", "envelope size is outside bounds");
    Reader reader{bytes};
    reader.magic(envelope_magic);
    require(reader.u16() == 0U,
        "CUSTODY_ENCODING_REJECTED", "unsupported envelope flags");
    CustodyEnvelope envelope;
    envelope.created_ms = reader.u64();
    envelope.expires_ms = reader.u64();
    envelope.hop_limit = reader.u8();
    envelope.capsule_bytes = reader.u32();
    envelope.capsule_sha256 = reader.digest();
    const auto route_count = reader.u8();
    require(route_count >= 2U && route_count <= kCustodyRoutePartyLimit,
        "CUSTODY_ROUTE_REJECTED", "route party count is outside bounds");
    envelope.route.reserve(route_count);
    for (std::uint8_t index = 0U; index < route_count; ++index) {
        envelope.route.push_back(read_party(reader));
    }
    const auto signature_offset = reader.offset;
    const auto signature = reader.take(signature_bytes);
    reader.end();
    validate_envelope_fields(envelope);
    verify(envelope.route.front().signing_public,
        envelope_signature_domain, bytes.first(signature_offset), signature);
    envelope.canonical.assign(bytes.begin(), bytes.end());
    const auto expected_unsigned = envelope_unsigned(envelope).bytes;
    require(expected_unsigned.size() == signature_offset &&
        std::equal(expected_unsigned.begin(), expected_unsigned.end(), bytes.begin()),
        "CUSTODY_ENCODING_REJECTED", "envelope is not canonical");
    return envelope;
}

datacube::Digest32 custody_envelope_sha256(const CustodyEnvelope& envelope) {
    require(!envelope.canonical.empty(),
        "CUSTODY_ENCODING_REJECTED", "envelope canonical bytes are absent");
    const auto decoded = decode_custody_envelope(envelope.canonical);
    require(same_envelope_fields(envelope, decoded),
        "CUSTODY_ENCODING_REJECTED", "envelope fields differ from signed bytes");
    return datacube::sha256(envelope.canonical);
}

void require_custody_capsule(const CustodyEnvelope& envelope,
    datacube::OctetView opaque_capsule) {
    (void)custody_envelope_sha256(envelope);
    require(opaque_capsule.size() == envelope.capsule_bytes &&
        datacube::sha256(opaque_capsule) == envelope.capsule_sha256,
        "CUSTODY_CAPSULE_REJECTED", "opaque capsule bytes do not match envelope");
}

CustodyProgress initial_custody_progress(const CustodyEnvelope& envelope) {
    validate_envelope_fields(envelope);
    (void)custody_envelope_sha256(envelope);
    CustodyProgress progress;
    progress.last_event_ms = envelope.created_ms;
    progress.accepted_record_sha256.reserve(
        static_cast<std::size_t>(2U * envelope.hop_limit));
    return progress;
}

CustodyRecord make_custody_transfer(const CustodyEnvelope& envelope,
    const CustodyProgress& progress, std::uint64_t event_ms,
    EVP_PKEY* current_custodian_private) {
    return make_record(envelope, progress, CustodyRecordKind::transfer,
        event_ms, current_custodian_private);
}

CustodyRecord make_custody_acceptance(const CustodyEnvelope& envelope,
    const CustodyProgress& progress, std::uint64_t event_ms,
    EVP_PKEY* accepting_custodian_private) {
    return make_record(envelope, progress, CustodyRecordKind::acceptance,
        event_ms, accepting_custodian_private);
}

CustodyRecord decode_custody_record(const CustodyEnvelope& envelope,
    datacube::OctetView bytes) {
    require(!bytes.empty() && bytes.size() <= kCustodyRecordLimit,
        "CUSTODY_ENCODING_REJECTED", "record size is outside bounds");
    (void)custody_envelope_sha256(envelope);
    Reader reader{bytes};
    reader.magic(record_magic);
    require(reader.u16() == 0U,
        "CUSTODY_ENCODING_REJECTED", "unsupported record flags");
    CustodyRecord record;
    record.kind = static_cast<CustodyRecordKind>(reader.u8());
    record.sequence = reader.u16();
    record.hop_index = reader.u8();
    record.actor_index = reader.u8();
    record.counterparty_index = reader.u8();
    record.event_ms = reader.u64();
    record.envelope_sha256 = reader.digest();
    record.previous_record_sha256 = reader.digest();
    record.capsule_sha256 = reader.digest();
    const auto signature_offset = reader.offset;
    const auto signature = reader.take(signature_bytes);
    reader.end();
    validate_record_shape(envelope, record);
    verify(envelope.route[record.actor_index].signing_public,
        record_signature_domain, bytes.first(signature_offset), signature);
    record.canonical.assign(bytes.begin(), bytes.end());
    const auto expected_unsigned = record_unsigned(record).bytes;
    require(expected_unsigned.size() == signature_offset &&
        std::equal(expected_unsigned.begin(), expected_unsigned.end(), bytes.begin()),
        "CUSTODY_ENCODING_REJECTED", "record is not canonical");
    return record;
}

datacube::Digest32 custody_record_sha256(const CustodyRecord& record) {
    require(!record.canonical.empty(),
        "CUSTODY_ENCODING_REJECTED", "record canonical bytes are absent");
    return datacube::sha256(record.canonical);
}

CustodyApplyResult apply_custody_record(const CustodyEnvelope& envelope,
    const CustodyRecord& record, CustodyProgress& progress) {
    validate_envelope_fields(envelope);
    (void)custody_envelope_sha256(envelope);
    validate_progress(envelope, progress);
    const auto decoded = decode_custody_record(envelope, record.canonical);
    require(same_record_fields(record, decoded),
        "CUSTODY_ENCODING_REJECTED", "record fields differ from signed bytes");
    const auto digest = custody_record_sha256(decoded);
    if (std::find(progress.accepted_record_sha256.begin(),
            progress.accepted_record_sha256.end(), digest) !=
        progress.accepted_record_sha256.end()) {
        return CustodyApplyResult::duplicate;
    }
    require(progress.accepted_record_sha256.size() < maximum_records,
        "CUSTODY_CAPACITY_EXHAUSTED", "custody record history is full");
    require(!progress.final_custody_accepted(envelope),
        "CUSTODY_FINAL_STATE", "final recipient already holds custody");
    require(decoded.sequence == progress.next_sequence,
        "CUSTODY_SEQUENCE_REJECTED", "record is not the next sequence");
    require(decoded.previous_record_sha256 == progress.last_record_sha256,
        "CUSTODY_CHAIN_REJECTED", "record predecessor does not match");
    require(decoded.event_ms >= progress.last_event_ms,
        "CUSTODY_TIME_REJECTED", "record time moved backward");
    require(decoded.hop_index == progress.current_party_index,
        "CUSTODY_NEXT_HOP_REJECTED", "record is not for the current route hop");
    if (progress.awaiting_acceptance) {
        require(decoded.kind == CustodyRecordKind::acceptance,
            "CUSTODY_STATE_REJECTED", "transfer requires exact acceptance");
        ++progress.current_party_index;
        progress.awaiting_acceptance = false;
    } else {
        require(decoded.kind == CustodyRecordKind::transfer,
            "CUSTODY_STATE_REJECTED", "custodian must transfer before acceptance");
        progress.awaiting_acceptance = true;
    }
    progress.last_record_sha256 = digest;
    progress.last_event_ms = decoded.event_ms;
    ++progress.next_sequence;
    progress.accepted_record_sha256.push_back(digest);
    return CustodyApplyResult::applied;
}

CustodyProgress reconstruct_custody_progress(const CustodyEnvelope& envelope,
    std::span<const datacube::Octets> records) {
    require(records.size() <= maximum_records * 2U,
        "CUSTODY_CAPACITY_EXHAUSTED", "custody evidence list exceeds replay bound");
    auto progress = initial_custody_progress(envelope);
    for (const auto& bytes : records) {
        const auto record = decode_custody_record(envelope, bytes);
        (void)apply_custody_record(envelope, record, progress);
    }
    return progress;
}

} // namespace natrav_overlay
