#pragma once
#include "common.hpp"
#include <optional>
#include <string>

namespace natrav_overlay {
// Current authorized metadata. A selection digest is not mutation authority.
struct PublicationInventory final {
    std::string lifecycle{"all"}, schedule{"all"}, outcome{"all"};
    std::string name, projection, recipient, scope;
    std::optional<datacube::Digest32> instance;
    std::uint32_t offset{0U}, limit{16U}, maximum_bytes{32768U};
    std::optional<datacube::Digest32> selection;
};
void validate_publication_inventory(const PublicationInventory&);
[[nodiscard]] datacube::Octets encode_publication_inventory(const PublicationInventory&);
[[nodiscard]] PublicationInventory decode_publication_inventory(datacube::OctetView);
} // namespace natrav_overlay
