#pragma once

#include "protocol.hpp"

#include <cstdint>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

enum class AuthorizedOperationClass : std::uint8_t {
    evidence = 1U,
    counter_action = 2U,
};

struct ActionLimits final {
    std::uint64_t counter_budget{1'000U};
    std::uint64_t maximum_increment{100U};
    std::uint64_t maximum_defer_ms{60'000U};
    std::uint64_t expiry_ms{86'400'000U};

    bool operator==(const ActionLimits&) const = default;
};

struct AuthorizationRule final {
    std::string peer_node;
    std::optional<std::string> peer_generation;
    AuthorizedOperationClass operation_class{AuthorizedOperationClass::evidence};
    std::string resource;
    datacube::Digest32 digest;
};

struct AuthorizationPolicy final {
    std::vector<AuthorizationRule> rules;
    ActionLimits action_limits;
    datacube::Digest32 digest;
};

// Separate outbound-disclosure authority for terminal counter-action results.
// An inbound ACTION authorization never implies permission to disclose the
// resulting local counter state back to that peer.
struct ActionResultRule final {
    std::string peer_node;
    std::string peer_generation;
    std::string resource;
    std::string result_scope;
    datacube::Digest32 digest;
};

struct ActionResultPolicy final {
    std::vector<ActionResultRule> rules;
    datacube::Digest32 digest;
};

struct AuthorizationDecision final {
    bool allowed{false};
    std::string peer_node;
    std::string peer_generation;
    AuthorizedOperationClass operation_class{AuthorizedOperationClass::evidence};
    std::string resource;
    datacube::Digest32 policy_digest;
    std::optional<datacube::Digest32> rule_digest;
    ActionLimits action_limits;
    std::string reason_code;
};

[[nodiscard]] AuthorizationPolicy make_authorization_policy(
    std::vector<AuthorizationRule> rules,
    const ActionLimits& action_limits);
[[nodiscard]] AuthorizationDecision evaluate_authorization(
    const AuthorizationPolicy& policy,
    std::string_view peer_node,
    std::string_view peer_generation,
    const EvidenceRecord& record);
[[nodiscard]] AuthorizedOperationClass operation_class_for(
    const EvidenceRecord& record) noexcept;
[[nodiscard]] std::string authorization_resource_for(
    const EvidenceRecord& record);
[[nodiscard]] std::string_view authorized_operation_class_name(
    AuthorizedOperationClass value) noexcept;
[[nodiscard]] std::string authorization_policy_json(
    const AuthorizationPolicy& policy);
[[nodiscard]] ActionResultPolicy make_action_result_policy(
    std::vector<ActionResultRule> rules);
[[nodiscard]] const ActionResultRule* find_action_result_rule(
    const ActionResultPolicy& policy,
    std::string_view peer_node,
    std::string_view peer_generation,
    std::string_view resource) noexcept;
[[nodiscard]] std::string action_result_policy_json(
    const ActionResultPolicy& policy);

}  // namespace natrav_overlay
