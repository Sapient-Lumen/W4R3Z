#include "custody_session_policy.hpp"

#include "adapter_configuration.hpp"

#include <algorithm>
#include <limits>
#include <set>
#include <tuple>

namespace natrav_overlay {
namespace {

constexpr std::size_t kRuleTextLimit = 2'048U;

void require(const bool condition, const std::string_view code,
    const std::string_view detail) {
    if (!condition) { app_fail(code, detail); }
}

void validate_rule(const CustodySessionRule& rule) {
    require(valid_generation_id(rule.id),
        "CONFIG_CUSTODY_SESSION_INVALID", "service rule id is invalid");
    require(rule.generation > 0U &&
            rule.generation <= kCustodySessionRulePerIdLimit,
        "CONFIG_CUSTODY_SESSION_GENERATION",
        "service rule generation is outside the retained bound");
    require(rule.state == CustodySessionRuleState::active ||
            rule.state == CustodySessionRuleState::retired ||
            rule.state == CustodySessionRuleState::revoked,
        "CONFIG_CUSTODY_SESSION_STATE", "unknown service lifecycle state");
    require(valid_generation_id(rule.grant.id) && rule.grant.generation > 0U &&
            !digest_is_zero(rule.grant.commitment),
        "CONFIG_CUSTODY_SESSION_GRANT",
        "service rule requires one exact nonzero V21 grant reference");
    require(!digest_is_zero(rule.custodian_certificate_sha256) &&
            !digest_is_zero(rule.next_hop_certificate_sha256) &&
            rule.custodian_certificate_sha256 !=
                rule.next_hop_certificate_sha256,
        "CONFIG_CUSTODY_SESSION_CERTIFICATE",
        "service endpoints require distinct exact certificate commitments");
    require(rule.maximum_pending_cases > 0U &&
            rule.maximum_pending_cases <=
                kCustodySessionMaximumPendingCases,
        "CONFIG_CUSTODY_SESSION_LIMIT",
        "pending-case bound is outside the finite service envelope");
    require(rule.maximum_bundle_bytes >= 8U &&
            rule.maximum_bundle_bytes <=
                kCustodySessionMaximumBundleBytes,
        "CONFIG_CUSTODY_SESSION_LIMIT",
        "bundle-byte bound is outside the native application envelope");
    require(rule.maximum_attempts > 0U &&
            rule.maximum_attempts <= kCustodySessionMaximumAttempts,
        "CONFIG_CUSTODY_SESSION_LIMIT",
        "attempt bound is outside the finite service envelope");
    require(rule.maximum_transfer_window_ms > 0U &&
            rule.maximum_transfer_window_ms <=
                kCustodySessionMaximumTransferWindowMs,
        "CONFIG_CUSTODY_SESSION_LIMIT",
        "transfer window is outside the finite seven-day envelope");
    require(rule.authority_expires_unix_ms > 0U,
        "CONFIG_CUSTODY_SESSION_LIMIT",
        "service authority expiry must be positive");
}

std::string field_value(
    const std::string& text,
    std::size_t& offset,
    const std::string_view prefix) {
    const auto end = text.find('\n', offset);
    require(end != std::string::npos,
        "CONFIG_CUSTODY_SESSION_NONCANONICAL",
        "complete canonical line required");
    const auto line = std::string_view(text).substr(offset, end - offset);
    require(line.starts_with(prefix),
        "CONFIG_CUSTODY_SESSION_NONCANONICAL",
        "canonical service-rule field order required");
    offset = end + 1U;
    return std::string(line.substr(prefix.size()));
}

const CustodySessionRule* find_exact(
    const CustodySessionPolicy& policy,
    const std::string_view id,
    const std::uint64_t generation) noexcept {
    const auto found = std::find_if(policy.begin(), policy.end(),
        [&](const CustodySessionRule& rule) {
            return rule.id == id && rule.generation == generation;
        });
    return found == policy.end() ? nullptr : &*found;
}

CustodySessionRuleState parse_state(const std::string_view value) {
    if (value == "ACTIVE") { return CustodySessionRuleState::active; }
    if (value == "RETIRED") { return CustodySessionRuleState::retired; }
    if (value == "REVOKED") { return CustodySessionRuleState::revoked; }
    app_fail("CONFIG_CUSTODY_SESSION_STATE",
        "service lifecycle must be ACTIVE, RETIRED or REVOKED");
}

} // namespace

std::string_view custody_session_rule_state_name(
    const CustodySessionRuleState state) {
    switch (state) {
        case CustodySessionRuleState::active: return "ACTIVE";
        case CustodySessionRuleState::retired: return "RETIRED";
        case CustodySessionRuleState::revoked: return "REVOKED";
    }
    app_fail("CONFIG_CUSTODY_SESSION_STATE",
        "unknown service lifecycle state");
}

std::string custody_session_rule_commitment_text(
    const CustodySessionRule& rule) {
    validate_rule(rule);
    return "NATRAV_CUSTODY_SESSION_RULE_COMMITMENT_V1\n"
        "id=" + rule.id +
        "\ngeneration=" + std::to_string(rule.generation) +
        "\npredecessor_sha256=" + operation_id_text(rule.predecessor) +
        "\ngrant_id=" + rule.grant.id +
        "\ngrant_generation=" + std::to_string(rule.grant.generation) +
        "\ngrant_commitment_sha256=" +
            operation_id_text(rule.grant.commitment) +
        "\ncustodian_certificate_sha256=" +
            operation_id_text(rule.custodian_certificate_sha256) +
        "\nnext_hop_certificate_sha256=" +
            operation_id_text(rule.next_hop_certificate_sha256) +
        "\nmaximum_pending_cases=" +
            std::to_string(rule.maximum_pending_cases) +
        "\nmaximum_bundle_bytes=" +
            std::to_string(rule.maximum_bundle_bytes) +
        "\nmaximum_attempts=" +
            std::to_string(rule.maximum_attempts) +
        "\nmaximum_transfer_window_ms=" +
            std::to_string(rule.maximum_transfer_window_ms) +
        "\nauthority_expires_unix_ms=" +
            std::to_string(rule.authority_expires_unix_ms) + "\n";
}

datacube::Digest32 custody_session_rule_commitment(
    const CustodySessionRule& rule) {
    const auto text = custody_session_rule_commitment_text(rule);
    return datacube::sha256(datacube::OctetView(
        reinterpret_cast<const std::uint8_t*>(text.data()), text.size()));
}

std::string custody_session_rule_text(const CustodySessionRule& rule) {
    const auto immutable = custody_session_rule_commitment_text(rule);
    return "NATRAV_CUSTODY_SESSION_RULE_V1\n" +
        immutable.substr(immutable.find('\n') + 1U) +
        "state=" + std::string(custody_session_rule_state_name(rule.state)) +
        "\n";
}

CustodySessionRule parse_custody_session_rule(const std::string_view hex) {
    require(hex.size() <= 2U * kRuleTextLimit,
        "CONFIG_CUSTODY_SESSION_INVALID", "service record byte bound");
    const auto raw = decode_adapter_configuration_record_hex(hex);
    require(raw.size() <= kRuleTextLimit &&
            std::all_of(raw.begin(), raw.end(), [](const char value) {
                const auto ch = static_cast<unsigned char>(value);
                return ch > 0U && ch < 128U;
            }),
        "CONFIG_CUSTODY_SESSION_NONCANONICAL",
        "canonical service text requires ASCII without NUL");
    const std::string text(raw.begin(), raw.end());
    std::size_t offset = 0U;
    require(field_value(text, offset,
                "NATRAV_CUSTODY_SESSION_RULE_V1").empty(),
        "CONFIG_CUSTODY_SESSION_NONCANONICAL", "service header");
    CustodySessionRule rule;
    rule.id = field_value(text, offset, "id=");
    rule.generation = parse_u64(
        field_value(text, offset, "generation="),
        "custody service generation", 1U,
        kCustodySessionRulePerIdLimit);
    const auto predecessor = field_value(
        text, offset, "predecessor_sha256=");
    rule.predecessor = predecessor == std::string(64U, '0') ?
        datacube::Digest32{} : parse_operation_id(predecessor);
    rule.grant.id = field_value(text, offset, "grant_id=");
    rule.grant.generation = parse_u64(
        field_value(text, offset, "grant_generation="),
        "custody service grant generation", 1U,
        kCustodyRelayGrantPerIdLimit);
    rule.grant.commitment = parse_operation_id(field_value(
        text, offset, "grant_commitment_sha256="));
    rule.custodian_certificate_sha256 = parse_operation_id(field_value(
        text, offset, "custodian_certificate_sha256="));
    rule.next_hop_certificate_sha256 = parse_operation_id(field_value(
        text, offset, "next_hop_certificate_sha256="));
    rule.maximum_pending_cases = static_cast<std::uint32_t>(parse_u64(
        field_value(text, offset, "maximum_pending_cases="),
        "custody service pending cases", 1U,
        kCustodySessionMaximumPendingCases));
    rule.maximum_bundle_bytes = static_cast<std::uint32_t>(parse_u64(
        field_value(text, offset, "maximum_bundle_bytes="),
        "custody service bundle bytes", 8U,
        kCustodySessionMaximumBundleBytes));
    rule.maximum_attempts = static_cast<std::uint32_t>(parse_u64(
        field_value(text, offset, "maximum_attempts="),
        "custody service attempts", 1U,
        kCustodySessionMaximumAttempts));
    rule.maximum_transfer_window_ms = parse_u64(
        field_value(text, offset, "maximum_transfer_window_ms="),
        "custody service transfer window", 1U,
        kCustodySessionMaximumTransferWindowMs);
    rule.authority_expires_unix_ms = parse_u64(
        field_value(text, offset, "authority_expires_unix_ms="),
        "custody service authority expiry", 1U,
        std::numeric_limits<std::uint64_t>::max());
    rule.state = parse_state(field_value(text, offset, "state="));
    require(offset == text.size(),
        "CONFIG_CUSTODY_SESSION_NONCANONICAL",
        "trailing service-rule bytes are forbidden");
    validate_rule(rule);
    require(custody_session_rule_text(rule) == text,
        "CONFIG_CUSTODY_SESSION_NONCANONICAL",
        "service rule is not in canonical form");
    return rule;
}

void normalize_custody_session_policy(CustodySessionPolicy& rules) {
    require(rules.size() <= kCustodySessionRuleLimit,
        "CONFIG_CUSTODY_SESSION_CAPACITY",
        "retained service-rule count exceeded");
    std::sort(rules.begin(), rules.end(),
        [](const CustodySessionRule& left,
           const CustodySessionRule& right) {
            return std::tie(left.id, left.generation) <
                std::tie(right.id, right.generation);
        });
    std::set<std::pair<std::string, std::uint64_t>> identities;
    std::set<std::tuple<std::string, std::uint64_t,
        std::string, std::string>> exact_transitions;
    const CustodySessionRule* previous = nullptr;
    for (const auto& rule : rules) {
        validate_rule(rule);
        require(identities.emplace(rule.id, rule.generation).second,
            "CONFIG_CUSTODY_SESSION_CONFLICT",
            "duplicate service id and generation");
        require(exact_transitions.emplace(
                rule.grant.id, rule.grant.generation,
                operation_id_text(rule.custodian_certificate_sha256),
                operation_id_text(rule.next_hop_certificate_sha256)).second,
            "CONFIG_CUSTODY_SESSION_CONFLICT",
            "one exact custody transition cannot have several service rules");
        if (previous == nullptr || previous->id != rule.id) {
            require(rule.generation == 1U && digest_is_zero(rule.predecessor),
                "CONFIG_CUSTODY_SESSION_PREDECESSOR",
                "first service generation requires zero predecessor");
        } else {
            require(rule.generation == previous->generation + 1U &&
                    rule.predecessor ==
                        custody_session_rule_commitment(*previous),
                "CONFIG_CUSTODY_SESSION_PREDECESSOR",
                "exact consecutive immutable predecessor required");
            require(previous->state != CustodySessionRuleState::active,
                "CONFIG_CUSTODY_SESSION_ACTIVE_CONFLICT",
                "superseded service rule must first be retired or revoked");
        }
        previous = &rule;
    }
}

void require_custody_session_history_preserved(
    const CustodySessionPolicy& historical,
    const CustodySessionPolicy& candidate) {
    for (const auto& prior : historical) {
        const auto* next = find_exact(candidate, prior.id, prior.generation);
        require(next != nullptr,
            "CONFIG_CUSTODY_SESSION_HISTORY_REMOVED",
            "accepted custody service generation must remain present");
        require(custody_session_rule_commitment(*next) ==
                    custody_session_rule_commitment(prior),
            "CONFIG_CUSTODY_SESSION_CONFLICT",
            "accepted custody service meaning cannot be redefined");
        require(static_cast<unsigned>(next->state) >=
                    static_cast<unsigned>(prior.state),
            "CONFIG_CUSTODY_SESSION_STATE_ROLLBACK",
            "service retirement and revocation are monotonic");
    }
}

const CustodySessionRule* find_custody_session_rule(
    const CustodySessionPolicy& policy,
    const std::string_view id,
    const std::uint64_t generation) noexcept {
    return find_exact(policy, id, generation);
}

const CustodyRelayGrant& resolve_custody_session_grant(
    const CustodyRelayPolicy& grants,
    const CustodySessionRule& rule,
    const bool require_active) {
    validate_rule(rule);
    const auto* grant = find_custody_relay_grant(
        grants, rule.grant.id, rule.grant.generation);
    require(grant != nullptr &&
            custody_relay_grant_commitment(*grant) == rule.grant.commitment,
        "CONFIG_CUSTODY_SESSION_GRANT",
        "service rule names an absent or redefined V21 grant");
    if (grant->state == CustodyRelayGrantState::revoked) {
        require(rule.state == CustodySessionRuleState::revoked,
            "CONFIG_CUSTODY_SESSION_GRANT_STATE",
            "a revoked grant requires a revoked service rule");
    } else if (grant->state == CustodyRelayGrantState::retired) {
        require(rule.state != CustodySessionRuleState::active,
            "CONFIG_CUSTODY_SESSION_GRANT_STATE",
            "an active service rule cannot retain a retired grant");
    }
    require(!require_active ||
            (grant->state == CustodyRelayGrantState::active &&
             rule.state == CustodySessionRuleState::active),
        "CONFIG_CUSTODY_SESSION_RETIRED",
        "new custody offers require active V21 and V22 authority");
    return *grant;
}

std::string custody_session_policy_json(
    const CustodySessionPolicy& rules) {
    std::string out =
        "{\"format\":\"V22_NATIVE_CUSTODY_SESSION_POLICY_V1\",\"rules\":[";
    bool first = true;
    for (const auto& rule : rules) {
        if (!first) { out += ','; }
        first = false;
        out += "{\"id\":" + json_string(rule.id) +
            ",\"generation\":" + std::to_string(rule.generation) +
            ",\"state\":" +
                json_string(custody_session_rule_state_name(rule.state)) +
            ",\"grant_id\":" + json_string(rule.grant.id) +
            ",\"grant_generation\":" +
                std::to_string(rule.grant.generation) +
            ",\"grant_commitment_sha256\":" +
                json_string(operation_id_text(rule.grant.commitment)) +
            ",\"custodian_certificate_sha256\":" +
                json_string(operation_id_text(
                    rule.custodian_certificate_sha256)) +
            ",\"next_hop_certificate_sha256\":" +
                json_string(operation_id_text(
                    rule.next_hop_certificate_sha256)) +
            ",\"maximum_pending_cases\":" +
                std::to_string(rule.maximum_pending_cases) +
            ",\"maximum_bundle_bytes\":" +
                std::to_string(rule.maximum_bundle_bytes) +
            ",\"maximum_attempts\":" +
                std::to_string(rule.maximum_attempts) +
            ",\"maximum_transfer_window_ms\":" +
                std::to_string(rule.maximum_transfer_window_ms) +
            ",\"authority_expires_unix_ms\":" +
                std::to_string(rule.authority_expires_unix_ms) +
            ",\"commitment_sha256\":" +
                json_string(operation_id_text(
                    custody_session_rule_commitment(rule))) +
            ",\"predecessor_sha256\":" +
                json_string(operation_id_text(rule.predecessor)) + "}";
    }
    return out + "]}";
}

} // namespace natrav_overlay
