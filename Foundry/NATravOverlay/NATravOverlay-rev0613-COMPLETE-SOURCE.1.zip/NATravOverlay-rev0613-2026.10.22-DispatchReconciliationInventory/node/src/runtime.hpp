#pragma once

#include "config.hpp"
#include <memory>
#include <functional>
#include <shared_mutex>
#include <mutex>
#include <string>
#include <vector>

namespace natrav_overlay {

inline constexpr std::size_t maximum_peer_registry_size = 64U;

// Prepared schedulers are parked until the accepted configuration and registry
// are published under the generation gate. Destruction cancels/joins unpublished
// workers. Publication is allocation-free and cannot throw after journal commit.
class PreparedPeerRegistryChange {
public:
    virtual ~PreparedPeerRegistryChange() = default;
    virtual void publish() noexcept = 0;
};
using PeerRegistryPreparer = std::function<std::unique_ptr<PreparedPeerRegistryChange>(
    const std::vector<std::string>&)>;

// Invoked while the caller owns the generation gate. Preparation rejects a
// revoked waiter before reading its candidate. Commit authorizes against the
// exact predecessor configuration with exclusive publication access; failure
// attributes a rejected attempt without implying a successful activation.
enum class ConfigurationAdmissionPhase { prepare, commit, failure };
using ConfigurationAdmission = std::function<void(
    const RuntimeConfig&, ConfigurationAdmissionPhase, std::string_view)>;

// Readers hold a generation stable through a bounded decision/commit boundary.
// The TLS context is immutable: reload never mutates SSL_CTX in use by sessions.
class RuntimeConfiguration final {
public:
    RuntimeConfiguration(const RuntimeConfig& seed, NodeState& state);
    struct Lease final {
        std::shared_lock<std::shared_timed_mutex> lock;
        std::shared_ptr<const RuntimeConfig> config;
    };
    [[nodiscard]] std::shared_ptr<Lease> lease() const;
    [[nodiscard]] std::shared_ptr<const RuntimeConfig> snapshot() const;
    [[nodiscard]] std::vector<std::string> scheduler_nodes() const;
    [[nodiscard]] std::string activate(
        NodeState& state, std::string_view candidate_path,
        std::string_view rollback_generation, std::string_view reason,
        const PeerRegistryPreparer& prepare_registry,
        const ConfigurationAdmission& admit);
private:
    mutable std::shared_timed_mutex gate_;
    std::mutex activation_mutex_;
    std::shared_ptr<const RuntimeConfig> active_;
    std::vector<std::string> scheduler_nodes_;
};

}  // namespace natrav_overlay
