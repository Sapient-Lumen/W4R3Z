#pragma once
#include "adapter_profile_catalog.hpp"
#include "transport.hpp"
#include <cstddef>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {
inline constexpr char kRuntimeAdapterConfigurationMarker[] =
    "V19_DURABLE_ADAPTER_CONFIGURATION_V1";
inline constexpr std::size_t kMaximumRuntimeAdapterProfiles = 64U;
inline constexpr std::size_t kMaximumRuntimeAdapterEndpoints = 64U;
// This retained policy is authorized and persisted by the existing NodeState
// configuration admission/journal, not a second catalog file or active carrier.
struct RuntimeAdapterConfiguration final {
    std::vector<OperatorPinnedAdapterProfile> profiles;
    std::vector<ConfiguredAdapterEndpoint> endpoints;
};
[[nodiscard]] std::string adapter_configuration_record_hex(std::string_view record);
[[nodiscard]] std::string decode_adapter_configuration_record_hex(std::string_view hex);
[[nodiscard]] OperatorPinnedAdapterProfile parse_runtime_adapter_profile(std::string_view hex);
[[nodiscard]] ConfiguredAdapterEndpoint parse_runtime_adapter_endpoint(std::string_view hex);
void normalize_runtime_adapter_configuration(RuntimeAdapterConfiguration& configuration);
void require_runtime_adapter_history_preserved(
    const RuntimeAdapterConfiguration& historical,
    const RuntimeAdapterConfiguration& candidate);
[[nodiscard]] ResolvedConfiguredAdapterEndpoint resolve_runtime_adapter_endpoint(
    const RuntimeAdapterConfiguration& configuration,
    const TransportLocator& locator, AdapterEndpointRole role);
[[nodiscard]] std::string runtime_adapter_configuration_json(
    const RuntimeAdapterConfiguration& configuration);
}  // namespace natrav_overlay
