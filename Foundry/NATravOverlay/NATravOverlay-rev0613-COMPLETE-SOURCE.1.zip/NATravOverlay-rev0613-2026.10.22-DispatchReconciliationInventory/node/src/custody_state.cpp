#include "custody_state.hpp"

#include <algorithm>
#include <limits>
#include <set>

namespace natrav_overlay {
namespace {

constexpr std::string_view kMagic = "NCUE0001";
constexpr std::size_t kCodeLimit = 64U;
constexpr std::size_t kDetailLimit = 256U;

void require(const bool condition, const std::string_view code,
    const std::string_view detail) {
    if (!condition) { app_fail(code, detail); }
}

void append_digest(datacube::Octets& out, const datacube::Digest32& value) {
    datacube::append_octets(out,
        datacube::OctetView(value.octets.data(), value.octets.size()));
}

void append_text8(datacube::Octets& out, const std::string_view value,
    const std::size_t maximum, const std::string_view field) {
    require(!value.empty() && value.size() <= maximum && value.size() <= 255U,
        "CUSTODY_STATE_ENCODING", std::string(field) + " length");
    require(std::all_of(value.begin(), value.end(), [](const char c) {
        const auto byte = static_cast<unsigned char>(c);
        return byte >= 0x20U && byte <= 0x7eU;
    }), "CUSTODY_STATE_ENCODING", std::string(field) + " ASCII");
    datacube::append_u8(out, static_cast<std::uint8_t>(value.size()));
    datacube::append_text(out, value);
}

void append_text16(datacube::Octets& out, const std::string_view value,
    const std::size_t maximum, const std::string_view field) {
    require(!value.empty() && value.size() <= maximum && value.size() <= 65535U,
        "CUSTODY_STATE_ENCODING", std::string(field) + " length");
    require(std::all_of(value.begin(), value.end(), [](const char c) {
        const auto byte = static_cast<unsigned char>(c);
        return byte >= 0x20U && byte <= 0x7eU;
    }), "CUSTODY_STATE_ENCODING", std::string(field) + " ASCII");
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}

std::string read_text8(datacube::Reader& reader, const std::size_t maximum,
    const std::string_view field) {
    const auto count = reader.read_u8(std::string(field) + " length");
    require(count > 0U && count <= maximum, "CUSTODY_STATE_ENCODING",
        std::string(field) + " length");
    return datacube::octets_text(reader.read_exact(count, field), field, true);
}

std::string read_text16(datacube::Reader& reader, const std::size_t maximum,
    const std::string_view field) {
    const auto count = reader.read_be16(std::string(field) + " length");
    require(count > 0U && count <= maximum, "CUSTODY_STATE_ENCODING",
        std::string(field) + " length");
    return datacube::octets_text(reader.read_exact(count, field), field, true);
}

datacube::Digest32 read_digest(datacube::Reader& reader,
    const std::string_view field) {
    datacube::Digest32 result;
    const auto bytes = reader.read_exact(result.octets.size(), field);
    std::copy(bytes.begin(), bytes.end(), result.octets.begin());
    return result;
}

std::string digest_key(const datacube::Digest32& digest) {
    return operation_id_text(digest);
}

void require_reference(const CustodyGrantReference& reference) {
    require(valid_generation_id(reference.id) && reference.generation > 0U &&
            !digest_is_zero(reference.commitment),
        "CUSTODY_STATE_GRANT_INVALID", "invalid custody grant reference");
}

void require_common(const DurableCustodyEvent& event) {
    require(!digest_is_zero(event.envelope_sha256),
        "CUSTODY_STATE_EVENT_INVALID", "zero envelope digest");
    require(event.configuration_event > 0U,
        "CUSTODY_STATE_EVENT_INVALID", "zero configuration event");
    switch (event.kind) {
        case DurableCustodyEventKind::registered:
            require(event.event_ms == 0U &&
                    !event.envelope.empty() && !event.capsule.empty() &&
                    event.record.empty() && event.code.empty() &&
                    event.detail.empty() && !event.imported_operation,
                "CUSTODY_STATE_EVENT_INVALID", "invalid registration shape");
            break;
        case DurableCustodyEventKind::record:
            require(event.event_ms == 0U &&
                    event.envelope.empty() && event.capsule.empty() &&
                    event.grants.empty() && !event.record.empty() &&
                    event.code.empty() && event.detail.empty() &&
                    !event.imported_operation,
                "CUSTODY_STATE_EVENT_INVALID", "invalid custody-record shape");
            break;
        case DurableCustodyEventKind::uncertainty:
            require(event.event_ms > 0U &&
                    event.envelope.empty() && event.capsule.empty() &&
                    event.grants.empty() && event.record.empty() &&
                    !event.code.empty() && !event.detail.empty() &&
                    !event.imported_operation,
                "CUSTODY_STATE_EVENT_INVALID", "invalid uncertainty shape");
            break;
        case DurableCustodyEventKind::expired:
            require(event.event_ms > 0U &&
                    event.envelope.empty() && event.capsule.empty() &&
                    event.grants.empty() && event.record.empty() &&
                    event.code.empty() && event.detail.empty() &&
                    !event.imported_operation,
                "CUSTODY_STATE_EVENT_INVALID", "invalid expiry shape");
            break;
        case DurableCustodyEventKind::imported:
            require(event.event_ms > 0U &&
                    event.envelope.empty() && event.capsule.empty() &&
                    event.grants.empty() && event.record.empty() &&
                    event.code.empty() && event.detail.empty() &&
                    event.imported_operation.has_value() &&
                    !digest_is_zero(*event.imported_operation),
                "CUSTODY_STATE_EVENT_INVALID", "invalid import shape");
            break;
        default:
            app_fail("CUSTODY_STATE_EVENT_INVALID", "unknown custody event kind");
    }
}

} // namespace

std::string_view durable_custody_event_kind_name(
    const DurableCustodyEventKind kind) {
    switch (kind) {
        case DurableCustodyEventKind::registered: return "REGISTERED";
        case DurableCustodyEventKind::record: return "RECORD";
        case DurableCustodyEventKind::uncertainty: return "UNCERTAINTY";
        case DurableCustodyEventKind::expired: return "EXPIRED";
        case DurableCustodyEventKind::imported: return "IMPORTED";
    }
    app_fail("CUSTODY_STATE_EVENT_INVALID", "unknown custody event kind");
}

datacube::Octets encode_durable_custody_event(
    const DurableCustodyEvent& event) {
    require_common(event);
    datacube::Octets out;
    datacube::append_text(out, kMagic);
    datacube::append_u8(out, static_cast<std::uint8_t>(event.kind));
    append_digest(out, event.envelope_sha256);
    datacube::append_be64(out, event.configuration_event);
    if (event.kind == DurableCustodyEventKind::registered) {
        require(event.envelope.size() <= kCustodyEnvelopeLimit &&
                event.capsule.size() <= kHandoffCapsuleLimit &&
                event.grants.size() + 1U <= kCustodyRoutePartyLimit,
            "CUSTODY_STATE_EVENT_INVALID", "registration bounds");
        datacube::append_be32(out,
            static_cast<std::uint32_t>(event.envelope.size()));
        datacube::append_octets(out, event.envelope);
        datacube::append_be32(out,
            static_cast<std::uint32_t>(event.capsule.size()));
        datacube::append_octets(out, event.capsule);
        datacube::append_u8(out,
            static_cast<std::uint8_t>(event.grants.size()));
        for (const auto& reference : event.grants) {
            require_reference(reference);
            append_text8(out, reference.id, 64U, "grant id");
            datacube::append_be64(out, reference.generation);
            append_digest(out, reference.commitment);
        }
    } else if (event.kind == DurableCustodyEventKind::record) {
        require(event.record.size() <= kCustodyRecordLimit,
            "CUSTODY_STATE_EVENT_INVALID", "custody record bound");
        datacube::append_be16(out,
            static_cast<std::uint16_t>(event.record.size()));
        datacube::append_octets(out, event.record);
    } else if (event.kind == DurableCustodyEventKind::uncertainty) {
        datacube::append_be64(out, event.event_ms);
        append_text8(out, event.code, kCodeLimit, "uncertainty code");
        append_text16(out, event.detail, kDetailLimit, "uncertainty detail");
    } else if (event.kind == DurableCustodyEventKind::expired) {
        datacube::append_be64(out, event.event_ms);
    } else {
        datacube::append_be64(out, event.event_ms);
        append_digest(out, *event.imported_operation);
    }
    require(out.size() <= kDurableCustodyEventEncodedLimit,
        "CUSTODY_STATE_EVENT_INVALID", "custody event encoded bound");
    return out;
}

DurableCustodyEvent decode_durable_custody_event(
    const datacube::OctetView bytes) {
    require(!bytes.empty() && bytes.size() <= kDurableCustodyEventEncodedLimit,
        "CUSTODY_STATE_EVENT_INVALID", "custody event byte bound");
    datacube::Reader reader(bytes, "durable custody event");
    require(datacube::octets_text(reader.read_exact(kMagic.size(), "magic"),
                "custody event magic", true) == kMagic,
        "CUSTODY_STATE_EVENT_INVALID", "custody event magic");
    DurableCustodyEvent event;
    const auto raw_kind = reader.read_u8("custody event kind");
    require(raw_kind >= static_cast<std::uint8_t>(
                DurableCustodyEventKind::registered) &&
            raw_kind <= static_cast<std::uint8_t>(
                DurableCustodyEventKind::imported),
        "CUSTODY_STATE_EVENT_INVALID", "custody event kind");
    event.kind = static_cast<DurableCustodyEventKind>(raw_kind);
    event.envelope_sha256 = read_digest(reader, "envelope digest");
    event.configuration_event = reader.read_be64("configuration event");
    if (event.kind == DurableCustodyEventKind::registered) {
        const auto envelope_size = reader.read_be32("envelope size");
        require(envelope_size > 0U && envelope_size <= kCustodyEnvelopeLimit,
            "CUSTODY_STATE_EVENT_INVALID", "envelope size");
        const auto envelope = reader.read_exact(envelope_size, "envelope");
        event.envelope.assign(envelope.begin(), envelope.end());
        const auto capsule_size = reader.read_be32("capsule size");
        require(capsule_size > 0U && capsule_size <= kHandoffCapsuleLimit,
            "CUSTODY_STATE_EVENT_INVALID", "capsule size");
        const auto capsule = reader.read_exact(capsule_size, "capsule");
        event.capsule.assign(capsule.begin(), capsule.end());
        const auto count = reader.read_u8("grant count");
        require(count > 0U && count < kCustodyRoutePartyLimit,
            "CUSTODY_STATE_EVENT_INVALID", "grant count");
        event.grants.reserve(count);
        for (std::size_t index = 0U; index < count; ++index) {
            event.grants.push_back(CustodyGrantReference{
                .id = read_text8(reader, 64U, "grant id"),
                .generation = reader.read_be64("grant generation"),
                .commitment = read_digest(reader, "grant commitment"),
            });
        }
    } else if (event.kind == DurableCustodyEventKind::record) {
        const auto size = reader.read_be16("custody record size");
        require(size > 0U && size <= kCustodyRecordLimit,
            "CUSTODY_STATE_EVENT_INVALID", "custody record size");
        const auto record = reader.read_exact(size, "custody record");
        event.record.assign(record.begin(), record.end());
    } else if (event.kind == DurableCustodyEventKind::uncertainty) {
        event.event_ms = reader.read_be64("uncertainty time");
        event.code = read_text8(reader, kCodeLimit, "uncertainty code");
        event.detail = read_text16(reader, kDetailLimit, "uncertainty detail");
    } else if (event.kind == DurableCustodyEventKind::expired) {
        event.event_ms = reader.read_be64("expiry time");
    } else {
        event.event_ms = reader.read_be64("import time");
        event.imported_operation = read_digest(reader, "imported operation");
    }
    reader.require_eof("durable custody event");
    require(encode_durable_custody_event(event) ==
            datacube::Octets(bytes.begin(), bytes.end()),
        "CUSTODY_STATE_EVENT_INVALID", "noncanonical custody event");
    return event;
}

datacube::Digest32 durable_custody_event_envelope(
    const datacube::OctetView bytes) {
    return decode_durable_custody_event(bytes).envelope_sha256;
}

DurableCustodyDisposition DurableCustodyRegistry::apply_encoded(
    const datacube::OctetView bytes) {
    return apply(decode_durable_custody_event(bytes));
}

DurableCustodyDisposition DurableCustodyRegistry::apply(
    const DurableCustodyEvent& event) {
    const auto encoded = encode_durable_custody_event(event);
    const auto event_digest = digest_key(datacube::sha256(encoded));
    if (event_digests_.contains(event_digest)) {
        return DurableCustodyDisposition::duplicate;
    }
    require(events_.size() < kDurableCustodyEventLimit,
        "CUSTODY_STATE_CAPACITY", "durable custody event limit reached");
    const auto key = digest_key(event.envelope_sha256);
    if (event.kind == DurableCustodyEventKind::registered) {
        const auto envelope = decode_custody_envelope(event.envelope);
        require(custody_envelope_sha256(envelope) == event.envelope_sha256,
            "CUSTODY_STATE_CONFLICT", "envelope digest mismatch");
        require_custody_capsule(envelope, event.capsule);
        require(event.grants.size() + 1U == envelope.route.size(),
            "CUSTODY_STATE_GRANT_INVALID",
            "one exact grant reference is required per custody hop");
        std::set<std::pair<std::string, std::uint64_t>> grants;
        for (const auto& reference : event.grants) {
            require_reference(reference);
            require(grants.emplace(reference.id, reference.generation).second,
                "CUSTODY_STATE_GRANT_INVALID",
                "duplicate grant reference in one custody case");
        }
        const auto found = cases_.find(key);
        if (found != cases_.end()) {
            const auto& existing = found->second;
            if (existing.envelope.canonical == envelope.canonical &&
                existing.capsule == event.capsule &&
                existing.configuration_event == event.configuration_event &&
                existing.grants == event.grants) {
                return DurableCustodyDisposition::duplicate;
            }
            app_fail("CUSTODY_STATE_CONFLICT",
                "envelope digest is already bound to different custody state");
        }
        require(cases_.size() < kDurableCustodyCaseLimit,
            "CUSTODY_STATE_CAPACITY", "durable custody case limit reached");
        require(retained_capsule_bytes_ <=
                kCustodyRelayMaximumBytesLimit * kDurableCustodyCaseLimit -
                    event.capsule.size(),
            "CUSTODY_STATE_CAPACITY", "durable custody capsule-byte bound");
        DurableCustodyCase value{
            .envelope_sha256 = event.envelope_sha256,
            .envelope = envelope,
            .capsule = event.capsule,
            .configuration_event = event.configuration_event,
            .grants = event.grants,
            .records = {},
            .progress = initial_custody_progress(envelope),
            .uncertainties = {},
            .expired_ms = std::nullopt,
            .imported_ms = std::nullopt,
            .imported_operation = std::nullopt,
        };
        retained_capsule_bytes_ += event.capsule.size();
        cases_.emplace(key, std::move(value));
    } else {
        const auto found = cases_.find(key);
        require(found != cases_.end(), "CUSTODY_STATE_UNKNOWN",
            "custody event references an unknown envelope");
        auto& value = found->second;
        if (event.kind == DurableCustodyEventKind::record) {
            require(!value.expired_ms && !value.imported_ms,
                "CUSTODY_STATE_TERMINAL",
                "custody records cannot follow terminal state");
            const auto record = decode_custody_record(
                value.envelope, event.record);
            auto progress = value.progress;
            const auto disposition = apply_custody_record(
                value.envelope, record, progress);
            if (disposition == CustodyApplyResult::duplicate) {
                return DurableCustodyDisposition::duplicate;
            }
            value.progress = std::move(progress);
            value.records.push_back(event.record);
        } else if (event.kind == DurableCustodyEventKind::uncertainty) {
            require(!value.expired_ms && !value.imported_ms &&
                    value.progress.awaiting_acceptance &&
                    event.event_ms >= value.progress.last_event_ms &&
                    event.event_ms <= value.envelope.expires_ms,
                "CUSTODY_STATE_UNCERTAINTY_INVALID",
                "uncertainty requires one unresolved transfer offer");
            require(value.uncertainties.size() <
                    kDurableCustodyUncertaintyLimit,
                "CUSTODY_STATE_CAPACITY", "uncertainty evidence limit reached");
            value.uncertainties.push_back(CustodyUncertainty{
                .event_ms = event.event_ms,
                .code = event.code,
                .detail = event.detail,
            });
        } else if (event.kind == DurableCustodyEventKind::expired) {
            require(!value.expired_ms && !value.imported_ms &&
                    event.event_ms >= value.envelope.expires_ms,
                "CUSTODY_STATE_EXPIRY_INVALID",
                "expiry requires an unimported expired envelope");
            value.expired_ms = event.event_ms;
        } else {
            require(!value.expired_ms && !value.imported_ms &&
                    value.progress.final_custody_accepted(value.envelope) &&
                    event.event_ms >= value.progress.last_event_ms &&
                    event.event_ms <= value.envelope.expires_ms,
                "CUSTODY_STATE_IMPORT_INVALID",
                "import requires final custody before envelope expiry");
            value.imported_ms = event.event_ms;
            value.imported_operation = event.imported_operation;
        }
    }
    events_.push_back(encoded);
    event_digests_.emplace(event_digest, true);
    return DurableCustodyDisposition::applied;
}

const DurableCustodyCase* DurableCustodyRegistry::find(
    const datacube::Digest32& envelope) const noexcept {
    const auto found = cases_.find(digest_key(envelope));
    return found == cases_.end() ? nullptr : &found->second;
}

std::vector<DurableCustodyCase> DurableCustodyRegistry::cases() const {
    std::vector<DurableCustodyCase> result;
    result.reserve(cases_.size());
    for (const auto& [key, value] : cases_) {
        static_cast<void>(key);
        result.push_back(value);
    }
    return result;
}

const std::vector<datacube::Octets>& DurableCustodyRegistry::events() const noexcept {
    return events_;
}

std::size_t DurableCustodyRegistry::active_count() const noexcept {
    return static_cast<std::size_t>(std::count_if(cases_.begin(), cases_.end(),
        [](const auto& item) {
            return !item.second.expired_ms && !item.second.imported_ms;
        }));
}

std::uint64_t DurableCustodyRegistry::retained_capsule_bytes() const noexcept {
    return retained_capsule_bytes_;
}

std::string DurableCustodyRegistry::status_json() const {
    std::string out = "{\"format\":\"DURABLE_CUSTODY_EVIDENCE_V1\"";
    out += ",\"case_count\":" + std::to_string(cases_.size());
    out += ",\"active_count\":" + std::to_string(active_count());
    out += ",\"event_count\":" + std::to_string(events_.size());
    out += ",\"retained_capsule_bytes\":" +
        std::to_string(retained_capsule_bytes_) + ",\"cases\":[";
    bool first = true;
    for (const auto& [key, value] : cases_) {
        if (!first) { out += ','; }
        first = false;
        std::string state = value.imported_ms ? "IMPORTED" :
            value.expired_ms ? "EXPIRED" :
            value.progress.final_custody_accepted(value.envelope) ?
                "FINAL_CUSTODY_ACCEPTED" :
            value.progress.awaiting_acceptance ? "TRANSFER_UNCERTAIN" :
                "CUSTODY_HELD";
        out += "{\"envelope_sha256\":" + json_string(key) +
            ",\"state\":" + json_string(state) +
            ",\"current_party_index\":" +
                std::to_string(value.progress.current_party_index) +
            ",\"awaiting_acceptance\":" +
                (value.progress.awaiting_acceptance ? "true" : "false") +
            ",\"records\":" + std::to_string(value.records.size()) +
            ",\"uncertainties\":" +
                std::to_string(value.uncertainties.size()) +
            ",\"configuration_event\":" +
                std::to_string(value.configuration_event) +
            ",\"expires_ms\":" +
                std::to_string(value.envelope.expires_ms) + "}";
    }
    return out + "]}";
}

} // namespace natrav_overlay
