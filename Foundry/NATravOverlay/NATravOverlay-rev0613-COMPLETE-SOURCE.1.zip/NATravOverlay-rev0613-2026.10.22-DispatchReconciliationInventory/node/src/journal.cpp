#include "journal.hpp"
#include "config.hpp"
#include "custody_authority.hpp"
#include "runtime.hpp"
#include "source_validation_work.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <filesystem>
#include <limits>
#include <openssl/crypto.h>
#include <string>
#include <string_view>
#include <thread>
#include <sys/file.h>
#include <sys/stat.h>
#include <unistd.h>
#include <utility>

namespace natrav_overlay {
namespace {

inline constexpr std::array<std::uint8_t, 4> kJournalMagic{
    static_cast<std::uint8_t>('N'),
    static_cast<std::uint8_t>('O'),
    static_cast<std::uint8_t>('J'),
    static_cast<std::uint8_t>('1'),
};
inline constexpr std::string_view kJournalChecksumDomain =
    "NATRAV_OVERLAY_JOURNAL_RECORD_V1";
inline constexpr std::string_view kMetadataPrefixV1 =
    "NATRAV_OVERLAY_NODE_STATE_V1\n";
inline constexpr std::string_view kMetadataPrefixV2 =
    "NATRAV_OVERLAY_NODE_STATE_V2\n";
inline constexpr std::uint32_t kMaximumJournalBodyBytes = 1'073'741'000U;
inline constexpr std::array<std::uint8_t, 4> kCheckpointMagicV2{
    static_cast<std::uint8_t>('N'),
    static_cast<std::uint8_t>('C'),
    static_cast<std::uint8_t>('P'),
    static_cast<std::uint8_t>('2'),
};
inline constexpr std::array<std::uint8_t, 4> kCheckpointMagicV3{
    static_cast<std::uint8_t>('N'),
    static_cast<std::uint8_t>('C'),
    static_cast<std::uint8_t>('P'),
    static_cast<std::uint8_t>('3'),
};
inline constexpr std::array<std::uint8_t, 4> kLogicalStateMagic{
    static_cast<std::uint8_t>('N'),
    static_cast<std::uint8_t>('L'),
    static_cast<std::uint8_t>('S'),
    static_cast<std::uint8_t>('2'),
};
inline constexpr std::string_view kLogicalStateDigestDomain =
    "NATRAV_OVERLAY_LOGICAL_STATE_V2";
inline constexpr std::string_view kCompactionCandidateName =
    "state.journal.compact.tmp";
inline constexpr std::string_view kActionReceiptDomain =
    "NATRAV_OVERLAY_COUNTER_ACTION_RECEIPT_V1";
inline constexpr std::string_view kOutboundPolicyDigestDomain =
    "NATRAV_OVERLAY_OUTBOUND_POLICY_V1";
inline constexpr std::string_view kOutboundRejectionDetailDigestDomain =
    "NATRAV_OVERLAY_OUTBOUND_REJECTION_DETAIL_V1";

[[nodiscard]] std::uint32_t decode_u32(const datacube::OctetView bytes) {
    return (static_cast<std::uint32_t>(bytes[0]) << 24U) |
        (static_cast<std::uint32_t>(bytes[1]) << 16U) |
        (static_cast<std::uint32_t>(bytes[2]) << 8U) |
        static_cast<std::uint32_t>(bytes[3]);
}

[[nodiscard]] std::uint64_t decode_u64(const datacube::OctetView bytes) {
    std::uint64_t value = 0U;
    for (const auto byte : bytes) {
        value = (value << 8U) | static_cast<std::uint64_t>(byte);
    }
    return value;
}

[[nodiscard]] std::uint64_t saturating_add_u64(
    const std::uint64_t left,
    const std::uint64_t right) noexcept {
    return right > std::numeric_limits<std::uint64_t>::max() - left ?
        std::numeric_limits<std::uint64_t>::max() : left + right;
}

[[nodiscard]] std::uint64_t unix_milliseconds_now() {
    const auto value = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    if (value <= 0) {
        app_fail("CLOCK_INVALID", "system clock is not after the Unix epoch");
    }
    return static_cast<std::uint64_t>(value);
}

[[nodiscard]] datacube::Digest32 checksum(const datacube::OctetView body) {
    datacube::Octets bytes;
    bytes.reserve(kJournalChecksumDomain.size() + 1U + body.size());
    datacube::append_text(bytes, kJournalChecksumDomain);
    datacube::append_u8(bytes, 0U);
    datacube::append_octets(bytes, body);
    return datacube::sha256(bytes);
}

[[nodiscard]] bool equal_digest_bytes(
    const datacube::Digest32& expected,
    const datacube::OctetView actual) noexcept {
    return actual.size() == expected.octets.size() &&
        std::equal(expected.octets.begin(), expected.octets.end(), actual.begin());
}

void write_all(const int fd, const datacube::OctetView bytes) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto remaining = bytes.size() - offset;
        const auto requested = std::min(
            remaining,
            static_cast<std::size_t>(std::numeric_limits<ssize_t>::max()));
        const ssize_t count = ::write(fd, bytes.data() + offset, requested);
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            app_fail("JOURNAL_WRITE_FAILED",
                datacube::errno_detail("state.journal", errno));
        }
        if (count == 0) {
            app_fail("JOURNAL_WRITE_FAILED", "write made no progress");
        }
        offset += static_cast<std::size_t>(count);
    }
}

[[nodiscard]] datacube::Octets recovery_payload(
    const std::uint64_t discarded,
    const std::uint64_t valid_prefix) {
    datacube::Octets payload;
    payload.reserve(16U);
    datacube::append_be64(payload, discarded);
    datacube::append_be64(payload, valid_prefix);
    return payload;
}

[[nodiscard]] std::string metadata_text_v1(const std::string_view node_id) {
    return std::string(kMetadataPrefixV1) + std::string(node_id) + "\n";
}

[[nodiscard]] std::string metadata_text_v2(const std::string_view node_id) {
    return std::string(kMetadataPrefixV2) + "node=" + std::string(node_id) +
        "\nstorage_schema=" + std::to_string(kCurrentStorageSchemaVersion) + "\n";
}

[[nodiscard]] std::string op_key(const datacube::Digest32& value) {
    return datacube::hex_lower(value);
}

void append_digest(
    datacube::Octets& out,
    const datacube::Digest32& value) {
    datacube::append_octets(out, value.octets);
}

void append_text16(
    datacube::Octets& out,
    const std::string_view value,
    const std::size_t ceiling,
    const std::string_view field) {
    if (value.size() > ceiling || value.size() > 65'535U) {
        app_fail("JOURNAL_RECORD_INVALID",
            std::string(field) + " exceeds its journal ceiling");
    }
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}

[[nodiscard]] datacube::Digest32 read_digest(
    datacube::Reader& reader,
    const std::string_view field) {
    datacube::Digest32 value;
    const auto bytes = reader.read_exact(value.octets.size(), field);
    std::copy(bytes.begin(), bytes.end(), value.octets.begin());
    return value;
}

[[nodiscard]] std::string read_text16(
    datacube::Reader& reader,
    const std::size_t ceiling,
    const std::string_view field) {
    const auto size = reader.read_be16(field);
    if (static_cast<std::size_t>(size) > ceiling) {
        app_fail("JOURNAL_CORRUPT",
            std::string(field) + " exceeds its ceiling");
    }
    return datacube::octets_text(reader.read_exact(size, field), field, true);
}

[[nodiscard]] datacube::Octets outbound_policy_payload(
    const datacube::Digest32& operation_id,
    const OutboundPolicy& policy) {
    datacube::Octets payload;
    payload.reserve(92U);
    append_digest(payload, operation_id);
    datacube::append_be64(payload, policy.created_unix_ms);
    datacube::append_be64(payload, policy.expires_unix_ms);
    datacube::append_be32(payload, policy.maximum_attempts);
    datacube::append_be32(payload, policy.initial_backoff_ms);
    datacube::append_be32(payload, policy.maximum_backoff_ms);
    if (policy.peer_spki_sha256.has_value()) {
        append_digest(payload, *policy.peer_spki_sha256);
        if (policy.peer_generation.has_value()) {
            append_text16(payload, *policy.peer_generation, 64U,
                "peer key generation");
        }
    }
    return payload;
}

[[nodiscard]] datacube::Octets outbound_attempt_payload(
    const datacube::Digest32& operation_id,
    const std::uint32_t attempt,
    const std::uint64_t attempted_unix_ms,
    const std::uint64_t next_attempt_unix_ms) {
    datacube::Octets payload;
    payload.reserve(52U);
    append_digest(payload, operation_id);
    datacube::append_be32(payload, attempt);
    datacube::append_be64(payload, attempted_unix_ms);
    datacube::append_be64(payload, next_attempt_unix_ms);
    return payload;
}

[[nodiscard]] datacube::Octets outbound_failure_payload(
    const datacube::Digest32& operation_id,
    const std::uint32_t attempt,
    const std::uint64_t next_attempt_unix_ms,
    const std::string_view code,
    const std::string_view detail) {
    datacube::Octets payload;
    payload.reserve(48U + code.size() + detail.size());
    append_digest(payload, operation_id);
    datacube::append_be32(payload, attempt);
    datacube::append_be64(payload, next_attempt_unix_ms);
    append_text16(payload, code, 64U, "failure code");
    append_text16(payload, detail, 512U, "failure detail");
    return payload;
}

[[nodiscard]] datacube::Octets outbound_expired_payload(
    const datacube::Digest32& operation_id,
    const std::uint64_t expired_unix_ms,
    const std::string_view reason) {
    datacube::Octets payload;
    payload.reserve(42U + reason.size());
    append_digest(payload, operation_id);
    datacube::append_be64(payload, expired_unix_ms);
    append_text16(payload, reason, 64U, "expiry reason");
    return payload;
}

[[nodiscard]] datacube::Octets outbound_rebound_payload(
    const datacube::Digest32& operation_id,
    const std::uint64_t rebound_unix_ms,
    const std::string_view actor,
    const std::string_view reason,
    const std::string_view from_generation,
    const datacube::Digest32& from_pin,
    const std::string_view to_generation,
    const datacube::Digest32& to_pin) {
    datacube::Octets payload;
    payload.reserve(144U + actor.size() + reason.size() +
        from_generation.size() + to_generation.size());
    append_digest(payload, operation_id);
    datacube::append_be64(payload, rebound_unix_ms);
    append_text16(payload, actor, 64U, "transition actor");
    append_text16(payload, reason, 256U, "transition reason");
    append_text16(payload, from_generation, 64U, "old generation");
    append_digest(payload, from_pin);
    append_text16(payload, to_generation, 64U, "new generation");
    append_digest(payload, to_pin);
    return payload;
}

[[nodiscard]] datacube::Octets outbound_cancelled_payload(
    const datacube::Digest32& operation_id,
    const std::uint64_t cancelled_unix_ms,
    const std::string_view actor,
    const std::string_view reason,
    const std::string_view generation,
    const datacube::Digest32& pin) {
    datacube::Octets payload;
    payload.reserve(80U + actor.size() + reason.size() + generation.size());
    append_digest(payload, operation_id);
    datacube::append_be64(payload, cancelled_unix_ms);
    append_text16(payload, actor, 64U, "transition actor");
    append_text16(payload, reason, 256U, "transition reason");
    append_text16(payload, generation, 64U, "cancelled generation");
    append_digest(payload, pin);
    return payload;
}

[[nodiscard]] datacube::Octets outbound_rejected_payload(
    const datacube::Digest32& operation_id,
    const std::uint32_t attempt,
    const std::uint64_t rejected_unix_ms,
    const std::string_view code,
    const std::string_view detail,
    const std::string_view generation,
    const datacube::Digest32& pin,
    const datacube::Digest32& policy_digest) {
    datacube::Octets payload;
    payload.reserve(144U + code.size() + detail.size() + generation.size());
    append_digest(payload, operation_id);
    datacube::append_be32(payload, attempt);
    datacube::append_be64(payload, rejected_unix_ms);
    append_text16(payload, code, 64U, "rejection code");
    append_text16(payload, detail, 256U, "rejection detail");
    append_text16(payload, generation, 64U, "rejection generation");
    append_digest(payload, pin);
    append_digest(payload, policy_digest);
    return payload;
}

[[nodiscard]] datacube::Octets outbound_retried_payload(
    const datacube::Digest32& operation_id,
    const std::uint64_t retried_unix_ms,
    const std::string_view actor,
    const std::string_view reason,
    const std::string_view generation,
    const datacube::Digest32& pin) {
    datacube::Octets payload;
    payload.reserve(80U + actor.size() + reason.size() + generation.size());
    append_digest(payload, operation_id);
    datacube::append_be64(payload, retried_unix_ms);
    append_text16(payload, actor, 64U, "transition actor");
    append_text16(payload, reason, 256U, "transition reason");
    append_text16(payload, generation, 64U, "retried generation");
    append_digest(payload, pin);
    return payload;
}

void append_authorization_account(
    datacube::Octets& out,
    const AuthorizationAccount& account) {
    append_digest(out, account.operation_id);
    append_digest(out, account.record_digest);
    append_text16(out, account.peer_node, 64U, "authorization peer");
    append_text16(
        out, account.peer_generation, 64U, "authorization generation");
    datacube::append_u8(
        out, static_cast<std::uint8_t>(account.operation_class));
    append_text16(out, account.resource, 128U, "authorization resource");
    append_digest(out, account.policy_digest);
    datacube::append_u8(out, account.rule_digest.has_value() ? 1U : 0U);
    if (account.rule_digest.has_value()) {
        append_digest(out, *account.rule_digest);
    }
    datacube::append_be64(out, account.decided_unix_ms);
    datacube::append_u8(out, static_cast<std::uint8_t>(account.decision));
    append_text16(out, account.reason_code, 64U, "authorization reason");
}

[[nodiscard]] AuthorizationAccount read_authorization_account(
    datacube::Reader& reader) {
    AuthorizationAccount account{
        .operation_id = read_digest(reader, "authorization operation ID"),
        .record_digest = read_digest(reader, "authorization record digest"),
        .peer_node = read_text16(reader, 64U, "authorization peer"),
        .peer_generation = read_text16(
            reader, 64U, "authorization generation"),
        .operation_class = static_cast<AuthorizedOperationClass>(
            reader.read_u8("authorization operation class")),
        .resource = read_text16(reader, 128U, "authorization resource"),
        .policy_digest = read_digest(reader, "authorization policy digest"),
        .rule_digest = std::nullopt,
        .decided_unix_ms = 0U,
        .decision = AuthorizationDecisionKind::admitted,
        .reason_code = {},
    };
    const auto has_rule = reader.read_u8("authorization rule marker");
    if (has_rule > 1U) {
        app_fail("JOURNAL_CORRUPT", "invalid authorization rule marker");
    }
    if (has_rule == 1U) {
        account.rule_digest = read_digest(reader, "authorization rule digest");
    }
    account.decided_unix_ms = reader.read_be64("authorization decision time");
    account.decision = static_cast<AuthorizationDecisionKind>(
        reader.read_u8("authorization decision"));
    account.reason_code = read_text16(
        reader, 64U, "authorization reason");
    return account;
}

void validate_initial_outbound_policy(const OutboundPolicy& policy) {
    if (policy.created_unix_ms == 0U ||
        policy.expires_unix_ms <= policy.created_unix_ms ||
        policy.maximum_attempts < 1U || policy.maximum_attempts > 1'000U ||
        policy.initial_backoff_ms < 10U ||
        policy.initial_backoff_ms > 600'000U ||
        policy.maximum_backoff_ms < policy.initial_backoff_ms ||
        policy.maximum_backoff_ms > 3'600'000U ||
        !policy.peer_spki_sha256.has_value() ||
        digest_is_zero(*policy.peer_spki_sha256) ||
        !policy.peer_generation.has_value() ||
        !valid_generation_id(*policy.peer_generation)) {
        app_fail("INVALID_OUTBOUND_POLICY", "bounded delivery policy violated");
    }
}

[[nodiscard]] bool valid_authorization_account(
    const AuthorizationAccount& account) {
    if (digest_is_zero(account.operation_id) ||
        digest_is_zero(account.record_digest) ||
        digest_is_zero(account.policy_digest) ||
        account.decided_unix_ms == 0U ||
        !valid_error_code(account.reason_code) ||
        !valid_node_id(account.peer_node) ||
        !valid_generation_id(account.peer_generation)) {
        return false;
    }
    if (account.operation_class == AuthorizedOperationClass::evidence) {
        return valid_scope(account.resource);
    }
    return account.operation_class == AuthorizedOperationClass::counter_action &&
        account.resource == "counter.add";
}

[[nodiscard]] AuthorizationAccount authorization_account_for(
    const EvidenceRecord& record,
    const AuthorizationDecision& decision,
    const std::uint64_t decided_unix_ms,
    const AuthorizationDecisionKind kind,
    const std::string_view reason_code) {
    return AuthorizationAccount{
        .operation_id = record.operation_id,
        .record_digest = evidence_record_digest(record),
        .peer_node = decision.peer_node,
        .peer_generation = decision.peer_generation,
        .operation_class = decision.operation_class,
        .resource = decision.resource,
        .policy_digest = decision.policy_digest,
        .rule_digest = decision.rule_digest,
        .decided_unix_ms = decided_unix_ms,
        .decision = kind,
        .reason_code = std::string(reason_code),
    };
}

[[nodiscard]] std::string authorization_denial_key(
    const AuthorizationAccount& account) {
    return op_key(account.operation_id) + ":" + account.peer_node + ":" +
        account.peer_generation + ":" + datacube::hex_lower(account.policy_digest);
}

[[nodiscard]] datacube::Octets authorization_denial_payload(
    const EvidenceRecord& record,
    const AuthorizationAccount& account) {
    datacube::Octets payload;
    payload.reserve(320U);
    append_authorization_account(payload, account);
    append_text16(payload, record.issuer, 64U, "denied issuer");
    append_text16(payload, record.recipient, 64U, "denied recipient");
    append_text16(payload, record.scope, 128U, "denied scope");
    return payload;
}

void append_action_result_binding(
    datacube::Octets& out,
    const ActionResultBinding& binding) {
    append_text16(out, binding.result_scope, 128U, "action-result scope");
    append_digest(out, binding.policy_digest);
    append_digest(out, binding.rule_digest);
    datacube::append_be64(out, binding.configuration_event);
    append_text16(out, binding.peer_generation, 64U,
        "action-result peer generation");
    append_digest(out, binding.peer_spki_sha256);
    datacube::append_be32(out, binding.maximum_attempts);
    datacube::append_be32(out, binding.initial_backoff_ms);
    datacube::append_be32(out, binding.maximum_backoff_ms);
    datacube::append_be64(out, binding.delivery_expiry_ms);
}

[[nodiscard]] ActionResultBinding read_action_result_binding(
    datacube::Reader& reader) {
    return ActionResultBinding{
        .result_scope = read_text16(reader, 128U, "action-result scope"),
        .policy_digest = read_digest(reader, "action-result policy digest"),
        .rule_digest = read_digest(reader, "action-result rule digest"),
        .configuration_event = reader.read_be64(
            "action-result configuration event"),
        .peer_generation = read_text16(
            reader, 64U, "action-result peer generation"),
        .peer_spki_sha256 = read_digest(
            reader, "action-result peer SPKI"),
        .maximum_attempts = reader.read_be32(
            "action-result maximum attempts"),
        .initial_backoff_ms = reader.read_be32(
            "action-result initial backoff"),
        .maximum_backoff_ms = reader.read_be32(
            "action-result maximum backoff"),
        .delivery_expiry_ms = reader.read_be64(
            "action-result delivery expiry"),
    };
}

// NAC1's largest representation is EXECUTED: latest start, effect receipt,
// and both counter values are present. All numbers/digests have fixed widths;
// reason text is represented only by a fixed digest and a two-byte length.
[[nodiscard]] std::uint64_t action_result_reservation_bytes(
    const ActionResultBinding& binding) {
    return 379U + static_cast<std::uint64_t>(binding.result_scope.size()) +
        static_cast<std::uint64_t>(binding.peer_generation.size());
}

[[nodiscard]] bool valid_action_result_binding(
    const ActionResultBinding& binding) {
    return (binding.reserved_payload_bytes == 0U ||
        binding.reserved_payload_bytes == action_result_reservation_bytes(binding)) &&
        valid_scope(binding.result_scope) &&
        binding.result_scope != kCounterAddActionScope &&
        !digest_is_zero(binding.policy_digest) &&
        !digest_is_zero(binding.rule_digest) &&
        binding.configuration_event != 0U &&
        valid_generation_id(binding.peer_generation) &&
        !digest_is_zero(binding.peer_spki_sha256) &&
        binding.maximum_attempts >= 1U &&
        binding.maximum_attempts <= 1'000U &&
        binding.initial_backoff_ms >= 10U &&
        binding.initial_backoff_ms <= 600'000U &&
        binding.maximum_backoff_ms >= binding.initial_backoff_ms &&
        binding.maximum_backoff_ms <= 3'600'000U &&
        binding.delivery_expiry_ms >= 100U &&
        binding.delivery_expiry_ms <= 2'592'000'000U;
}

[[nodiscard]] datacube::Octets authorized_inbound_payload(
    const EvidenceRecord& record,
    const AuthorizationAccount& account,
    const std::optional<StoredAction>& action,
    const std::optional<ActionResultBinding>& action_result) {
    const auto encoded = encode_application_message(record);
    datacube::Octets payload;
    payload.reserve(384U + encoded.size());
    append_authorization_account(payload, account);
    datacube::append_u8(payload,
        action.has_value() ? (action_result.has_value() ?
            (action_result->reserved_payload_bytes != 0U ? 3U : 2U) : 1U) : 0U);
    if (action.has_value()) {
        datacube::append_be64(payload, action->amount);
        datacube::append_be64(payload, action->admitted_unix_ms);
        datacube::append_be64(payload, action->not_before_unix_ms);
        datacube::append_be64(payload, action->expires_unix_ms);
        datacube::append_be64(payload, action->limits.counter_budget);
        datacube::append_be64(payload, action->limits.maximum_increment);
        datacube::append_be64(payload, action->limits.maximum_defer_ms);
        datacube::append_be64(payload, action->limits.expiry_ms);
        append_digest(payload, action->rule_digest);
        if (action_result.has_value()) {
            append_action_result_binding(payload, *action_result);
            if (action_result->reserved_payload_bytes != 0U) {
                datacube::append_be64(payload, action_result->reserved_payload_bytes);
            }
        }
    }
    datacube::append_be32(payload, static_cast<std::uint32_t>(encoded.size()));
    datacube::append_octets(payload, encoded);
    return payload;
}

[[nodiscard]] datacube::Digest32 action_receipt_digest(
    const datacube::Digest32& action_id,
    const std::uint32_t attempt,
    const std::uint64_t completed_unix_ms,
    const std::uint64_t before,
    const std::uint64_t after) {
    datacube::Octets bytes;
    bytes.reserve(kActionReceiptDomain.size() + 1U + 60U);
    datacube::append_text(bytes, kActionReceiptDomain);
    datacube::append_u8(bytes, 0U);
    append_digest(bytes, action_id);
    datacube::append_be32(bytes, attempt);
    datacube::append_be64(bytes, completed_unix_ms);
    datacube::append_be64(bytes, before);
    datacube::append_be64(bytes, after);
    return datacube::sha256(bytes);
}

[[nodiscard]] datacube::Octets action_started_payload(
    const datacube::Digest32& action_id,
    const std::uint32_t attempt,
    const std::uint64_t started_unix_ms) {
    datacube::Octets payload;
    payload.reserve(44U);
    append_digest(payload, action_id);
    datacube::append_be32(payload, attempt);
    datacube::append_be64(payload, started_unix_ms);
    return payload;
}

[[nodiscard]] datacube::Octets action_completed_payload(
    const datacube::Digest32& action_id,
    const std::uint32_t attempt,
    const std::uint64_t completed_unix_ms,
    const std::uint64_t before,
    const std::uint64_t after,
    const datacube::Digest32& receipt_digest) {
    datacube::Octets payload;
    payload.reserve(92U);
    append_digest(payload, action_id);
    datacube::append_be32(payload, attempt);
    datacube::append_be64(payload, completed_unix_ms);
    datacube::append_be64(payload, before);
    datacube::append_be64(payload, after);
    append_digest(payload, receipt_digest);
    return payload;
}

[[nodiscard]] datacube::Octets action_terminal_payload(
    const datacube::Digest32& action_id,
    const std::uint64_t unix_ms,
    const std::string_view reason) {
    datacube::Octets payload;
    payload.reserve(42U + reason.size());
    append_digest(payload, action_id);
    datacube::append_be64(payload, unix_ms);
    append_text16(payload, reason, 256U, "action terminal reason");
    return payload;
}

[[nodiscard]] std::string_view action_result_outcome_name(
    const ActionResultOutcome outcome) noexcept {
    switch (outcome) {
        case ActionResultOutcome::executed: return "EXECUTED";
        case ActionResultOutcome::cancelled: return "CANCELLED";
        case ActionResultOutcome::expired: return "EXPIRED";
    }
    return "UNKNOWN";
}

[[nodiscard]] datacube::Digest32 action_terminal_reason_digest(
    const StoredAction& action,
    const ActionResultOutcome outcome) {
    const std::string_view reason = outcome == ActionResultOutcome::cancelled ?
        std::string_view(action.cancellation_reason) :
        outcome == ActionResultOutcome::expired ?
            std::string_view(action.expiry_reason) : std::string_view{};
    if (reason.empty()) { return datacube::Digest32{}; }
    datacube::Octets material;
    datacube::append_text(material,
        "NATRAV_OVERLAY_ACTION_RESULT_REASON_V1");
    datacube::append_u8(material, 0U);
    append_digest(material, action.action_id);
    datacube::append_u8(material, static_cast<std::uint8_t>(outcome));
    datacube::append_text(material, reason);
    return datacube::sha256(material);
}

[[nodiscard]] std::uint64_t action_terminal_time(
    const StoredAction& action,
    const ActionResultOutcome outcome) {
    const auto value = outcome == ActionResultOutcome::executed ?
        action.completed_unix_ms : outcome == ActionResultOutcome::cancelled ?
            action.cancelled_unix_ms : action.expired_unix_ms;
    if (!value.has_value()) {
        app_fail("ACTION_RESULT_INVALID",
            "terminal action state is missing its outcome time");
    }
    return *value;
}

[[nodiscard]] datacube::Octets canonical_action_result_payload(
    const StoredAction& action,
    const StoredInbound& source,
    const ActionResultBinding& binding,
    const ActionResultOutcome outcome) {
    if (!source.authorization.has_value() ||
        source.record.operation_id != action.action_id ||
        source.record_digest != action.record_digest ||
        source.authorization->decision != AuthorizationDecisionKind::admitted ||
        source.authorization->operation_class !=
            AuthorizedOperationClass::counter_action ||
        !source.authorization->rule_digest.has_value() ||
        !valid_action_result_binding(binding)) {
        app_fail("ACTION_RESULT_INVALID",
            "action result lacks its admitted source and policy binding");
    }
    datacube::Octets out;
    datacube::append_text(out, "NAC1");
    datacube::append_u8(out, static_cast<std::uint8_t>(outcome));
    append_digest(out, action.action_id);
    append_digest(out, action.record_digest);
    datacube::append_be64(out, source.sequence);
    append_digest(out, source.authorization->policy_digest);
    append_digest(out, *source.authorization->rule_digest);
    datacube::append_be64(out, source.authorization->decided_unix_ms);
    append_digest(out, binding.policy_digest);
    append_digest(out, binding.rule_digest);
    datacube::append_be64(out, binding.configuration_event);
    append_text16(out, binding.result_scope, 128U, "action-result scope");
    append_text16(out, binding.peer_generation, 64U,
        "action-result peer generation");
    append_digest(out, binding.peer_spki_sha256);
    datacube::append_be64(out, action.amount);
    datacube::append_be64(out, action.admitted_unix_ms);
    datacube::append_be64(out, action_terminal_time(action, outcome));
    datacube::append_be32(out, action.attempts);
    datacube::append_u8(out, action.last_started_unix_ms.has_value() ? 1U : 0U);
    if (action.last_started_unix_ms.has_value()) {
        datacube::append_be64(out, *action.last_started_unix_ms);
    }
    datacube::append_u8(out, action.receipt_digest.has_value() ? 1U : 0U);
    if (action.receipt_digest.has_value()) {
        append_digest(out, *action.receipt_digest);
    }
    datacube::append_u8(out, action.counter_before.has_value() ? 1U : 0U);
    if (action.counter_before.has_value()) {
        datacube::append_be64(out, *action.counter_before);
    }
    datacube::append_u8(out, action.counter_after.has_value() ? 1U : 0U);
    if (action.counter_after.has_value()) {
        datacube::append_be64(out, *action.counter_after);
    }
    const std::string_view reason = outcome == ActionResultOutcome::cancelled ?
        std::string_view(action.cancellation_reason) :
        outcome == ActionResultOutcome::expired ?
            std::string_view(action.expiry_reason) : std::string_view{};
    datacube::append_be16(out, static_cast<std::uint16_t>(reason.size()));
    append_digest(out, action_terminal_reason_digest(action, outcome));
    return out;
}

[[nodiscard]] EvidenceRecord action_result_record(
    const std::string_view local_node,
    const StoredAction& action,
    const StoredInbound& source,
    const ActionResultBinding& binding,
    const ActionResultOutcome outcome) {
    auto payload = canonical_action_result_payload(
        action, source, binding, outcome);
    datacube::Octets identity;
    datacube::append_text(identity,
        "NATRAV_OVERLAY_ACTION_RESULT_OPERATION_V1");
    datacube::append_u8(identity, 0U);
    datacube::append_octets(identity, payload);
    return EvidenceRecord{
        .operation_id = datacube::sha256(identity),
        .issuer = std::string(local_node),
        .recipient = action.issuer,
        .scope = binding.result_scope,
        .corrects = std::nullopt,
        .payload = std::move(payload),
    };
}

[[nodiscard]] OutboundPolicy action_result_outbound_policy(
    const ActionResultBinding& binding,
    const std::uint64_t terminal_unix_ms) {
    if (binding.delivery_expiry_ms >
        std::numeric_limits<std::uint64_t>::max() - terminal_unix_ms) {
        app_fail("ACTION_RESULT_INVALID", "result delivery expiry overflow");
    }
    return OutboundPolicy{
        .created_unix_ms = terminal_unix_ms,
        .expires_unix_ms = terminal_unix_ms + binding.delivery_expiry_ms,
        .maximum_attempts = binding.maximum_attempts,
        .initial_backoff_ms = binding.initial_backoff_ms,
        .maximum_backoff_ms = binding.maximum_backoff_ms,
        .peer_spki_sha256 = binding.peer_spki_sha256,
        .peer_generation = binding.peer_generation,
    };
}

[[nodiscard]] datacube::Octets action_result_transaction_payload(
    const ActionResultOutcome outcome,
    const datacube::OctetView terminal_payload,
    const EvidenceRecord& record,
    const OutboundPolicy& policy) {
    const auto encoded = encode_application_message(record);
    datacube::Octets out;
    datacube::append_text(out, "NAT1");
    datacube::append_u8(out, static_cast<std::uint8_t>(outcome));
    datacube::append_be32(out, static_cast<std::uint32_t>(terminal_payload.size()));
    datacube::append_octets(out, terminal_payload);
    append_digest(out, record.operation_id);
    datacube::append_be32(out, static_cast<std::uint32_t>(encoded.size()));
    datacube::append_octets(out, encoded);
    datacube::append_octets(out,
        outbound_policy_payload(record.operation_id, policy));
    return out;
}

[[nodiscard]] bool valid_transition_text(
    const std::string_view value,
    const std::size_t ceiling) noexcept {
    return !value.empty() && value.size() <= ceiling &&
        std::all_of(value.begin(), value.end(), [](const char raw) {
            const auto ch = static_cast<unsigned char>(raw);
            return ch == 9U || (ch >= 32U && ch <= 126U);
        });
}

[[nodiscard]] bool valid_optional_text(
    const std::string_view value,
    const std::size_t ceiling) noexcept {
    return value.size() <= ceiling &&
        std::all_of(value.begin(), value.end(), [](const char raw) {
            const auto ch = static_cast<unsigned char>(raw);
            return ch == 9U || (ch >= 32U && ch <= 126U);
        });
}

void append_count32(
    datacube::Octets& out,
    const std::size_t value,
    const std::string_view field) {
    if (value > static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max())) {
        app_fail("CHECKPOINT_TOO_LARGE", std::string(field));
    }
    datacube::append_be32(out, static_cast<std::uint32_t>(value));
}

[[nodiscard]] std::size_t read_count32(
    datacube::Reader& reader,
    const std::size_t ceiling,
    const std::string_view field) {
    const auto value = reader.read_be32(field);
    if (static_cast<std::size_t>(value) > ceiling) {
        app_fail("JOURNAL_CORRUPT", std::string(field) + " exceeds its ceiling");
    }
    return static_cast<std::size_t>(value);
}

void append_optional_u64(
    datacube::Octets& out,
    const std::optional<std::uint64_t>& value) {
    datacube::append_u8(out, value.has_value() ? 1U : 0U);
    if (value.has_value()) {
        datacube::append_be64(out, *value);
    }
}

[[nodiscard]] std::optional<std::uint64_t> read_optional_u64(
    datacube::Reader& reader,
    const std::string_view field) {
    const auto marker = reader.read_u8(field);
    if (marker > 1U) {
        app_fail("JOURNAL_CORRUPT", std::string(field) + " marker is invalid");
    }
    if (marker == 0U) {
        return std::nullopt;
    }
    return reader.read_be64(field);
}

void append_optional_digest(
    datacube::Octets& out,
    const std::optional<datacube::Digest32>& value) {
    datacube::append_u8(out, value.has_value() ? 1U : 0U);
    if (value.has_value()) {
        append_digest(out, *value);
    }
}

[[nodiscard]] std::optional<datacube::Digest32> read_optional_digest(
    datacube::Reader& reader,
    const std::string_view field) {
    const auto marker = reader.read_u8(field);
    if (marker > 1U) {
        app_fail("JOURNAL_CORRUPT", std::string(field) + " marker is invalid");
    }
    if (marker == 0U) {
        return std::nullopt;
    }
    return read_digest(reader, field);
}

void append_application(
    datacube::Octets& out,
    const ApplicationMessage& message,
    const std::string_view field) {
    const auto encoded = encode_application_message(message);
    if (encoded.size() > kMaximumApplicationPayloadBytes) {
        app_fail("CHECKPOINT_TOO_LARGE", std::string(field));
    }
    datacube::append_be32(out, static_cast<std::uint32_t>(encoded.size()));
    datacube::append_octets(out, encoded);
}

[[nodiscard]] ApplicationMessage read_application(
    datacube::Reader& reader,
    const std::string_view field) {
    const auto size = reader.read_be32(field);
    if (size == 0U || size > kMaximumApplicationPayloadBytes) {
        app_fail("JOURNAL_CORRUPT", std::string(field) + " size is invalid");
    }
    return decode_application_message(reader.read_exact(size, field));
}

void append_outbound_policy_state(
    datacube::Octets& out,
    const OutboundPolicy& policy) {
    datacube::append_be64(out, policy.created_unix_ms);
    datacube::append_be64(out, policy.expires_unix_ms);
    datacube::append_be32(out, policy.maximum_attempts);
    datacube::append_be32(out, policy.initial_backoff_ms);
    datacube::append_be32(out, policy.maximum_backoff_ms);
    append_optional_digest(out, policy.peer_spki_sha256);
    datacube::append_u8(out, policy.peer_generation.has_value() ? 1U : 0U);
    if (policy.peer_generation.has_value()) {
        append_text16(out, *policy.peer_generation, 64U, "checkpoint peer generation");
    }
}

[[nodiscard]] OutboundPolicy read_outbound_policy_state(
    datacube::Reader& reader) {
    OutboundPolicy policy{
        .created_unix_ms = reader.read_be64("checkpoint policy created"),
        .expires_unix_ms = reader.read_be64("checkpoint policy expires"),
        .maximum_attempts = reader.read_be32("checkpoint policy attempts"),
        .initial_backoff_ms = reader.read_be32("checkpoint policy initial backoff"),
        .maximum_backoff_ms = reader.read_be32("checkpoint policy maximum backoff"),
        .peer_spki_sha256 = read_optional_digest(reader, "checkpoint policy pin"),
        .peer_generation = std::nullopt,
    };
    const auto generation_marker = reader.read_u8("checkpoint generation marker");
    if (generation_marker > 1U) {
        app_fail("JOURNAL_CORRUPT", "checkpoint generation marker is invalid");
    }
    if (generation_marker == 1U) {
        policy.peer_generation = read_text16(
            reader, 64U, "checkpoint peer generation");
    }
    return policy;
}

void append_outbound_transition_state(
    datacube::Octets& out,
    const OutboundTransition& transition) {
    datacube::append_u8(out, static_cast<std::uint8_t>(transition.kind));
    datacube::append_be64(out, transition.unix_ms);
    append_text16(out, transition.actor, 64U, "checkpoint transition actor");
    append_text16(out, transition.reason, 256U, "checkpoint transition reason");
    append_text16(out, transition.from_generation, 64U,
        "checkpoint transition generation");
    append_digest(out, transition.from_spki_sha256);
    datacube::append_u8(out, transition.to_generation.has_value() ? 1U : 0U);
    if (transition.to_generation.has_value()) {
        append_text16(out, *transition.to_generation, 64U,
            "checkpoint transition target generation");
    }
    append_optional_digest(out, transition.to_spki_sha256);
}

[[nodiscard]] OutboundTransition read_outbound_transition_state(
    datacube::Reader& reader) {
    OutboundTransition transition{
        .kind = static_cast<OutboundTransitionKind>(
            reader.read_u8("checkpoint transition kind")),
        .unix_ms = reader.read_be64("checkpoint transition time"),
        .actor = read_text16(reader, 64U, "checkpoint transition actor"),
        .reason = read_text16(reader, 256U, "checkpoint transition reason"),
        .from_generation = read_text16(
            reader, 64U, "checkpoint transition source generation"),
        .from_spki_sha256 = read_digest(
            reader, "checkpoint transition source pin"),
        .to_generation = std::nullopt,
        .to_spki_sha256 = std::nullopt,
    };
    const auto marker = reader.read_u8("checkpoint transition target marker");
    if (marker > 1U) {
        app_fail("JOURNAL_CORRUPT", "checkpoint transition target marker is invalid");
    }
    if (marker == 1U) {
        transition.to_generation = read_text16(
            reader, 64U, "checkpoint transition target generation");
    }
    transition.to_spki_sha256 = read_optional_digest(
        reader, "checkpoint transition target pin");
    return transition;
}

void append_outbound_delivery_state(
    datacube::Octets& out,
    const OutboundDeliveryState& delivery) {
    append_outbound_policy_state(out, delivery.policy);
    datacube::append_be32(out, delivery.attempts);
    append_optional_u64(out, delivery.last_attempt_unix_ms);
    datacube::append_be64(out, delivery.next_attempt_unix_ms);
    append_text16(out, delivery.last_error_code, 64U,
        "checkpoint outbound error code");
    append_text16(out, delivery.last_error_detail, 512U,
        "checkpoint outbound error detail");
    append_optional_u64(out, delivery.expired_unix_ms);
    append_text16(out, delivery.expiry_reason, 64U,
        "checkpoint outbound expiry reason");
    append_optional_u64(out, delivery.cancelled_unix_ms);
    append_text16(out, delivery.cancellation_reason, 256U,
        "checkpoint outbound cancellation reason");
    append_count32(out, delivery.transitions.size(),
        "checkpoint outbound transition count");
    for (const auto& transition : delivery.transitions) {
        append_outbound_transition_state(out, transition);
    }
}

[[nodiscard]] OutboundDeliveryState read_outbound_delivery_state(
    datacube::Reader& reader, const std::size_t maximum_transitions = 1'000'000U) {
    OutboundDeliveryState delivery{
        .policy = read_outbound_policy_state(reader),
        .attempts = reader.read_be32("checkpoint outbound attempts"),
        .last_attempt_unix_ms = read_optional_u64(
            reader, "checkpoint outbound last attempt"),
        .next_attempt_unix_ms = reader.read_be64(
            "checkpoint outbound next attempt"),
        .last_error_code = read_text16(
            reader, 64U, "checkpoint outbound error code"),
        .last_error_detail = read_text16(
            reader, 512U, "checkpoint outbound error detail"),
        .expired_unix_ms = read_optional_u64(
            reader, "checkpoint outbound expired"),
        .expiry_reason = read_text16(
            reader, 64U, "checkpoint outbound expiry reason"),
        .cancelled_unix_ms = read_optional_u64(
            reader, "checkpoint outbound cancelled"),
        .cancellation_reason = read_text16(
            reader, 256U, "checkpoint outbound cancellation reason"),
        .transitions = {},
    };
    const auto count = read_count32(
        reader, maximum_transitions, "checkpoint outbound transition count");
    delivery.transitions.reserve(count);
    for (std::size_t index = 0U; index < count; ++index) {
        delivery.transitions.push_back(read_outbound_transition_state(reader));
    }
    return delivery;
}

void append_action_state(
    datacube::Octets& out,
    const StoredAction& action) {
    append_digest(out, action.action_id);
    append_digest(out, action.record_digest);
    append_text16(out, action.issuer, 64U, "checkpoint action issuer");
    append_text16(out, action.peer_generation, 64U,
        "checkpoint action generation");
    datacube::append_be64(out, action.queue_sequence);
    datacube::append_be64(out, action.amount);
    datacube::append_be64(out, action.admitted_unix_ms);
    datacube::append_be64(out, action.not_before_unix_ms);
    datacube::append_be64(out, action.expires_unix_ms);
    datacube::append_be64(out, action.limits.counter_budget);
    datacube::append_be64(out, action.limits.maximum_increment);
    datacube::append_be64(out, action.limits.maximum_defer_ms);
    datacube::append_be64(out, action.limits.expiry_ms);
    append_digest(out, action.policy_digest);
    append_digest(out, action.rule_digest);
    datacube::append_be32(out, action.attempts);
    append_optional_u64(out, action.last_started_unix_ms);
    append_optional_u64(out, action.completed_unix_ms);
    append_optional_u64(out, action.cancelled_unix_ms);
    append_optional_u64(out, action.expired_unix_ms);
    append_optional_u64(out, action.counter_before);
    append_optional_u64(out, action.counter_after);
    append_optional_digest(out, action.receipt_digest);
    append_text16(out, action.cancellation_reason, 256U,
        "checkpoint action cancellation reason");
    append_text16(out, action.expiry_reason, 256U,
        "checkpoint action expiry reason");
    append_text16(out, action.last_error_code, 64U,
        "checkpoint action error code");
}

[[nodiscard]] StoredAction read_action_state(datacube::Reader& reader) {
    return StoredAction{
        .action_id = read_digest(reader, "checkpoint action ID"),
        .record_digest = read_digest(reader, "checkpoint action record digest"),
        .issuer = read_text16(reader, 64U, "checkpoint action issuer"),
        .peer_generation = read_text16(
            reader, 64U, "checkpoint action generation"),
        .queue_sequence = reader.read_be64("checkpoint action queue sequence"),
        .amount = reader.read_be64("checkpoint action amount"),
        .admitted_unix_ms = reader.read_be64("checkpoint action admitted"),
        .not_before_unix_ms = reader.read_be64("checkpoint action not-before"),
        .expires_unix_ms = reader.read_be64("checkpoint action expires"),
        .limits = ActionLimits{
            .counter_budget = reader.read_be64("checkpoint action budget"),
            .maximum_increment = reader.read_be64(
                "checkpoint action maximum increment"),
            .maximum_defer_ms = reader.read_be64(
                "checkpoint action maximum defer"),
            .expiry_ms = reader.read_be64("checkpoint action expiry interval"),
        },
        .policy_digest = read_digest(reader, "checkpoint action policy digest"),
        .rule_digest = read_digest(reader, "checkpoint action rule digest"),
        .attempts = reader.read_be32("checkpoint action attempts"),
        .last_started_unix_ms = read_optional_u64(
            reader, "checkpoint action last started"),
        .completed_unix_ms = read_optional_u64(
            reader, "checkpoint action completed"),
        .cancelled_unix_ms = read_optional_u64(
            reader, "checkpoint action cancelled"),
        .expired_unix_ms = read_optional_u64(
            reader, "checkpoint action expired"),
        .counter_before = read_optional_u64(
            reader, "checkpoint action counter before"),
        .counter_after = read_optional_u64(
            reader, "checkpoint action counter after"),
        .receipt_digest = read_optional_digest(
            reader, "checkpoint action receipt"),
        .cancellation_reason = read_text16(
            reader, 256U, "checkpoint action cancellation reason"),
        .expiry_reason = read_text16(
            reader, 256U, "checkpoint action expiry reason"),
        .last_error_code = read_text16(
            reader, 64U, "checkpoint action error code"),
    };
}

[[nodiscard]] datacube::Digest32 logical_state_digest_for(
    const datacube::OctetView logical) {
    datacube::Octets material;
    material.reserve(kLogicalStateDigestDomain.size() + 1U + logical.size());
    datacube::append_text(material, kLogicalStateDigestDomain);
    datacube::append_u8(material, 0U);
    datacube::append_octets(material, logical);
    return datacube::sha256(material);
}

[[nodiscard]] datacube::Octets frame_for(
    const std::uint8_t kind,
    const datacube::OctetView payload) {
    if (payload.size() + 1U > static_cast<std::size_t>(kMaximumJournalBodyBytes)) {
        app_fail("JOURNAL_RECORD_TOO_LARGE", "journal record exceeds envelope");
    }
    datacube::Octets body;
    body.reserve(payload.size() + 1U);
    datacube::append_u8(body, kind);
    datacube::append_octets(body, payload);
    const auto body_checksum = checksum(body);
    datacube::Octets frame;
    frame.reserve(8U + body.size() + body_checksum.octets.size());
    datacube::append_octets(frame, kJournalMagic);
    datacube::append_be32(frame, static_cast<std::uint32_t>(body.size()));
    datacube::append_octets(frame, body);
    datacube::append_octets(frame, body_checksum.octets);
    return frame;
}

void maybe_test_pause(const char* name) {
    const char* raw = std::getenv(name);
    if (raw == nullptr || *raw == '\0') {
        return;
    }
    const auto delay = parse_u64(raw, name, 1U, 60'000U);
    std::this_thread::sleep_for(std::chrono::milliseconds(delay));
}

[[nodiscard]] ProtocolError wrap_decode_error(const AppError& error) {
    return ProtocolError{
        .operation_id = std::nullopt,
        .code = "JOURNAL_CORRUPT",
        .detail = error.what(),
    };
}

[[nodiscard]] datacube::Octets runtime_event_payload(
    const RuntimeConfigurationEvent& event) {
    datacube::Octets out;
    append_text16(out, event.kind, 16U, "configuration event kind");
    append_text16(out, event.generation, 64U, "configuration generation");
    append_digest(out, event.digest);
    if (event.canonical.size() > 65'536U) {
        app_fail("CONFIG_TOO_LARGE", "durable configuration exceeds envelope");
    }
    datacube::append_be32(out, static_cast<std::uint32_t>(event.canonical.size()));
    datacube::append_text(out, event.canonical);
    datacube::append_be64(out, event.unix_ms);
    append_text16(out, event.actor, 64U, "configuration actor");
    append_text16(out, event.reason, 256U, "configuration reason");
    append_text16(out, event.error_code, 64U, "configuration error");
    return out;
}

[[nodiscard]] RuntimeConfigurationEvent read_runtime_event(datacube::Reader& reader) {
    RuntimeConfigurationEvent event;
    event.kind = read_text16(reader, 16U, "configuration event kind");
    event.generation = read_text16(reader, 64U, "configuration generation");
    event.digest = read_digest(reader, "configuration digest");
    const auto length = reader.read_be32("configuration length");
    if (length > 65'536U) { app_fail("JOURNAL_CORRUPT", "configuration length"); }
    const auto data = reader.read_exact(length, "canonical configuration");
    event.canonical.assign(reinterpret_cast<const char*>(data.data()), data.size());
    event.unix_ms = reader.read_be64("configuration time");
    event.actor = read_text16(reader, 64U, "configuration actor");
    event.reason = read_text16(reader, 256U, "configuration reason");
    event.error_code = read_text16(reader, 64U, "configuration error");
    return event;
}

[[nodiscard]] bool printable_token(
    const std::string_view value,
    const std::size_t maximum) noexcept {
    return !value.empty() && value.size() <= maximum &&
        std::all_of(value.begin(), value.end(), [](const char raw) {
            const auto ch = static_cast<unsigned char>(raw);
            return ch >= 32U && ch <= 126U;
        });
}

void validate_configuration_event_reference(
    const std::uint64_t ordinal,
    const std::vector<RuntimeConfigurationEvent>& history,
    const std::string_view field) {
    if (ordinal == 0U || ordinal > history.size() ||
        history[static_cast<std::size_t>(ordinal - 1U)].kind == "REJECTED") {
        app_fail("JOURNAL_CORRUPT", std::string(field) + " is not an accepted configuration event");
    }
}

void validate_custody_event_authority(
    const DurableCustodyRegistry& registry,
    const std::vector<RuntimeConfigurationEvent>& history,
    const DurableCustodyEvent& event) {
    validate_configuration_event_reference(
        event.configuration_event, history, "custody configuration event");
    const auto& accepted = history.at(static_cast<std::size_t>(
        event.configuration_event - 1U));
    const auto config = parse_runtime_config(accepted.canonical,
        "/custody-history", IdentityFileValidation::deferred);
    if (config.format_version < 21U) {
        app_fail("JOURNAL_CORRUPT",
            "durable custody event references pre-V21 configuration");
    }
    if (event.kind == DurableCustodyEventKind::registered) {
        const auto envelope = decode_custody_envelope(event.envelope);
        require_custody_registration_authority(
            config, envelope, event.grants, false);
        return;
    }
    const auto* custody = registry.find(event.envelope_sha256);
    if (custody == nullptr) {
        app_fail("JOURNAL_CORRUPT",
            "custody authority event references unknown envelope");
    }
    if (event.kind == DurableCustodyEventKind::record) {
        const auto record = decode_custody_record(
            custody->envelope, event.record);
        if (record.hop_index >= custody->grants.size()) {
            app_fail("JOURNAL_CORRUPT",
                "custody record hop lacks an exact grant reference");
        }
        static_cast<void>(resolve_custody_grant_reference(
            config, custody->grants[record.hop_index], custody->envelope,
            record.hop_index, false));
        return;
    }
    if (event.kind == DurableCustodyEventKind::uncertainty) {
        if (!custody->progress.awaiting_acceptance ||
            custody->progress.current_party_index >= custody->grants.size()) {
            app_fail("JOURNAL_CORRUPT",
                "custody uncertainty lacks an unresolved authorized hop");
        }
        static_cast<void>(resolve_custody_grant_reference(
            config, custody->grants[custody->progress.current_party_index],
            custody->envelope, custody->progress.current_party_index, false));
        return;
    }
    if (event.kind == DurableCustodyEventKind::imported) {
        if (custody->grants.empty()) {
            app_fail("JOURNAL_CORRUPT",
                "final custody import lacks an exact grant reference");
        }
        const auto hop = custody->grants.size() - 1U;
        static_cast<void>(resolve_custody_grant_reference(
            config, custody->grants[hop], custody->envelope, hop, false));
        return;
    }
    // Expiry is a terminal observation over already-admitted evidence.  Its
    // accepted configuration reference still proves that it was made under a
    // retained V21 authority view, but a later grant revocation does not erase
    // the historical case or prevent bounded expiry accounting.
}

[[nodiscard]] datacube::Octets local_control_event_payload(
    const LocalControlEvent& event) {
    datacube::Octets out;
    append_digest(out, event.request_id);
    datacube::append_be32(out, event.uid);
    datacube::append_be32(out, event.gid);
    datacube::append_be32(out, event.pid);
    append_text16(out, event.command, 64U, "local control command");
    append_text16(out, event.command_class, 32U, "local control class");
    datacube::append_be64(out, event.configuration_event);
    datacube::append_be64(out, event.unix_ms);
    datacube::append_u8(out, static_cast<std::uint8_t>(event.decision));
    append_text16(out, event.error_code, 64U, "local control error");
    return out;
}

[[nodiscard]] LocalControlEvent read_local_control_event(datacube::Reader& reader) {
    return LocalControlEvent{
        .request_id = read_digest(reader, "local control request ID"),
        .uid = reader.read_be32("local control UID"),
        .gid = reader.read_be32("local control GID"),
        .pid = reader.read_be32("local control PID"),
        .command = read_text16(reader, 64U, "local control command"),
        .command_class = read_text16(reader, 32U, "local control class"),
        .configuration_event = reader.read_be64("local control configuration event"),
        .unix_ms = reader.read_be64("local control time"),
        .decision = static_cast<LocalControlDecisionKind>(reader.read_u8("local control decision")),
        .error_code = read_text16(reader, 64U, "local control error"),
    };
}

void validate_local_control_event(
    const LocalControlEvent& event,
    const std::vector<RuntimeConfigurationEvent>& history) {
    if (digest_is_zero(event.request_id) || event.pid == 0U || event.unix_ms == 0U ||
        !printable_token(event.command, 64U) ||
        !printable_token(event.command_class, 32U)) {
        app_fail("JOURNAL_CORRUPT", "invalid local control account");
    }
    validate_configuration_event_reference(
        event.configuration_event, history, "local control configuration event");
    if (event.decision == LocalControlDecisionKind::authorized) {
        if (!event.error_code.empty()) {
            app_fail("JOURNAL_CORRUPT", "authorized local control account has an error");
        }
    } else if (event.decision == LocalControlDecisionKind::denied) {
        if (!valid_error_code(event.error_code)) {
            app_fail("JOURNAL_CORRUPT", "denied local control account lacks a valid error");
        }
    } else {
        app_fail("JOURNAL_CORRUPT", "unknown local control decision");
    }
}

[[nodiscard]] datacube::Octets lifecycle_event_payload(
    const LifecycleEvent& event) {
    datacube::Octets out;
    datacube::append_u8(out, static_cast<std::uint8_t>(event.kind));
    append_digest(out, event.request_id);
    datacube::append_be32(out, event.uid);
    datacube::append_be32(out, event.pid);
    datacube::append_be64(out, event.configuration_event);
    datacube::append_be64(out, event.unix_ms);
    datacube::append_be32(out, event.deadline_ms);
    datacube::append_be64(out, event.pending_outbound);
    datacube::append_be64(out, event.pending_actions);
    append_text16(out, event.reason, 256U, "lifecycle reason");
    return out;
}

[[nodiscard]] LifecycleEvent read_lifecycle_event(datacube::Reader& reader) {
    return LifecycleEvent{
        .kind = static_cast<LifecycleTransitionKind>(reader.read_u8("lifecycle kind")),
        .request_id = read_digest(reader, "lifecycle request ID"),
        .uid = reader.read_be32("lifecycle UID"),
        .pid = reader.read_be32("lifecycle PID"),
        .configuration_event = reader.read_be64("lifecycle configuration event"),
        .unix_ms = reader.read_be64("lifecycle time"),
        .deadline_ms = reader.read_be32("lifecycle deadline"),
        .pending_outbound = reader.read_be64("lifecycle pending outbound"),
        .pending_actions = reader.read_be64("lifecycle pending actions"),
        .reason = read_text16(reader, 256U, "lifecycle reason"),
    };
}

void validate_lifecycle_event(
    const LifecycleEvent& event,
    const std::vector<RuntimeConfigurationEvent>& history) {
    if (digest_is_zero(event.request_id) || event.pid == 0U || event.unix_ms == 0U ||
        !printable_token(event.reason, 256U)) {
        app_fail("JOURNAL_CORRUPT", "invalid lifecycle account");
    }
    validate_configuration_event_reference(
        event.configuration_event, history, "lifecycle configuration event");
    switch (event.kind) {
        case LifecycleTransitionKind::quiesced:
        case LifecycleTransitionKind::resumed:
        case LifecycleTransitionKind::shutdown_requested:
            if (event.deadline_ms != 0U) {
                app_fail("JOURNAL_CORRUPT", "non-drain lifecycle event has a deadline");
            }
            break;
        case LifecycleTransitionKind::drain_started:
        case LifecycleTransitionKind::drain_completed:
        case LifecycleTransitionKind::drain_deadline:
            if (event.deadline_ms == 0U || event.deadline_ms > 600'000U) {
                app_fail("JOURNAL_CORRUPT", "drain lifecycle deadline is invalid");
            }
            break;
        default:
            app_fail("JOURNAL_CORRUPT", "unknown lifecycle transition");
    }
}

void validate_runtime_event(
    const RuntimeConfigurationEvent& event,
    const std::vector<RuntimeConfigurationEvent>& history,
    const std::string_view node) {
    if (history.size() >= 256U || event.unix_ms == 0U ||
        event.actor.empty() || event.reason.empty()) {
        app_fail("CONFIG_HISTORY_LIMIT", "invalid or full configuration history (256 events)");
    }
    if (event.kind == "REJECTED") {
        if (!valid_error_code(event.error_code) || !event.canonical.empty()) {
            app_fail("JOURNAL_CORRUPT", "invalid rejected configuration account");
        }
        return;
    }
    if (event.kind != "BOOTSTRAP" && event.kind != "ACTIVATE" &&
        event.kind != "ROLLBACK" && event.kind != "RELOCATE") {
        app_fail("JOURNAL_CORRUPT", "unknown configuration event kind");
    }
    if (!event.error_code.empty() || !valid_generation_id(event.generation) ||
        runtime_configuration_digest(event.canonical) != event.digest) {
        app_fail("JOURNAL_CORRUPT", "configuration digest or identity mismatch");
    }
    const auto config = parse_runtime_config(
        event.canonical,
        "/durable-configuration",
        IdentityFileValidation::deferred);
    if (config.local_node != node || config.runtime_generation != event.generation ||
        canonical_runtime_config(config) != event.canonical) {
        app_fail("JOURNAL_CORRUPT", "configuration is not canonical for this node");
    }
    bool known = false;
    for (const auto& previous : history) {
        if (previous.kind == "REJECTED" || previous.generation != event.generation) { continue; }
        known = true;
        if (previous.digest != event.digest || previous.canonical != event.canonical) {
            app_fail("CONFIG_GENERATION_CONFLICT", "generation cannot be redefined");
        }
    }
    const bool has_active = active_configuration_event(history) != 0U;
    if ((event.kind == "BOOTSTRAP") == has_active ||
        (event.kind == "ROLLBACK" && !known)) {
        app_fail("CONFIG_TRANSITION_INVALID", "invalid activation or rollback predecessor");
    }
    if (!config.source_disclosure.grants.empty()) {
        std::map<std::string, datacube::Digest32> accepted;
        for (const auto& previous : history) {
            if (previous.kind == "REJECTED" || previous.canonical.find("source_disclosure=") == std::string::npos) { continue; }
            const auto old = parse_runtime_config(previous.canonical, "/disclosure-history", IdentityFileValidation::deferred);
            for (const auto& grant : old.source_disclosure.grants) { accepted.emplace(grant.id, grant.digest); }
        }
        for (const auto& grant : config.source_disclosure.grants) {
            const auto [it, added] = accepted.emplace(grant.id, grant.digest);
            if (!added && it->second != grant.digest) { app_fail("SOURCE_DISCLOSURE_GENERATION_CONFLICT", "accepted grant ID cannot be redefined"); }
        }
        if (accepted.size() > kSourceSubscriptionLimit) { app_fail("SOURCE_DISCLOSURE_HISTORY_LIMIT", "at most 64 historical disclosure generations"); }
    }
    if (!config.source_views.rules.empty()) {
        std::map<std::string, datacube::Digest32> rules;
        std::map<std::pair<std::string,std::string>, datacube::Digest32> bindings;
        std::map<std::pair<std::string,std::string>, std::string> targets;
        auto collect = [&](const RuntimeConfig& c) {
            for (const auto& r : c.source_views.rules) {
                const auto [it, fresh] = rules.emplace(r.id,r.digest);
                if (!fresh && it->second != r.digest) { app_fail("SOURCE_VIEW_POLICY_CONFLICT", "historical view ID cannot change meaning or budgets"); }
                const auto [domain, added] = targets.emplace(std::make_pair(r.provider,r.target_scope),r.id);
                if (!added && domain->second != r.id) { app_fail("SOURCE_VIEW_POLICY_CONFLICT", "historical materialized domain remains reserved"); }
            }
            for (const auto& b : c.source_views.bindings) {
                const auto [it, fresh] = bindings.emplace(std::make_pair(b.view,b.grant),b.digest);
                if (!fresh && it->second != b.digest) { app_fail("SOURCE_VIEW_POLICY_CONFLICT", "historical grant binding cannot change"); }
            }
        };
        for (const auto& old : history) {
            if (old.kind != "REJECTED" && old.canonical.find("source_view=") != std::string::npos) {
                collect(parse_runtime_config(old.canonical,"/source-view-history",IdentityFileValidation::deferred));
            }
        }
        collect(config);
        if (rules.size()>32U || bindings.size()>256U) { app_fail("SOURCE_VIEW_HISTORY_LIMIT", "historical view registry is full"); }
    }
    if (event.kind == "RELOCATE") {
        if (!has_active || known) {
            app_fail("CONFIG_TRANSITION_INVALID",
                "relocation requires an active predecessor and a fresh generation");
        }
        const auto active = active_configuration_event(history);
        const auto before = parse_runtime_config(
            history[active - 1U].canonical,
            "/durable-relocation-predecessor",
            IdentityFileValidation::deferred);
        const bool changed = before.state_directory != config.state_directory ||
            before.control_socket != config.control_socket ||
            before.identity.certificate != config.identity.certificate ||
            before.identity.private_key != config.identity.private_key;
        if (!changed || !runtime_relocation_only_change(before, config)) {
            app_fail("CONFIG_TRANSITION_INVALID",
                "relocation may change only runtime generation and owner paths");
        }
    } else if (has_active && event.kind != "BOOTSTRAP") {
        const auto active = active_configuration_event(history);
        const auto before = parse_runtime_config(
            history[active - 1U].canonical,
            "/durable-configuration-predecessor",
            IdentityFileValidation::deferred);
        if (!runtime_owner_boundary_equal(before, config)) {
            app_fail("CONFIG_TRANSITION_INVALID",
                "ordinary activation cannot change the owner boundary");
        }
    }
}

[[nodiscard]] std::optional<datacube::Digest32> runtime_mutation_operation(
    const std::uint8_t kind, const datacube::OctetView payload) {
    if (kind == 1U || kind == 2U || kind == 3U) {
        const auto message = decode_application_message(payload);
        if (const auto* record = std::get_if<EvidenceRecord>(&message)) { return record->operation_id; }
        if (const auto* receipt = std::get_if<DeliveryReceipt>(&message)) { return receipt->operation_id; }
    } else if ((kind >= 5U && kind <= 10U) || (kind >= 11U && kind <= 16U) ||
               kind == 20U || kind == 21U || kind == 24U) {
        if (payload.size() < 32U) { app_fail("JOURNAL_CORRUPT", "bound operation truncated"); }
        datacube::Digest32 digest;
        std::copy_n(payload.begin(), 32U, digest.octets.begin());
        return digest;
    } else if (kind == 39U) {
        return durable_custody_event_envelope(payload);
    } else if (kind == 37U) {
        datacube::Reader reader(payload, "bound action-result transaction");
        if (datacube::octets_text(reader.read_exact(4U, "action-result magic"),
                "action-result magic", true) != "NAT1") {
            app_fail("JOURNAL_CORRUPT", "invalid bound action-result transaction");
        }
        static_cast<void>(reader.read_u8("action-result outcome"));
        const auto terminal_size = reader.read_be32("action terminal size");
        const auto terminal = reader.read_exact(terminal_size, "action terminal");
        if (terminal.size() < 32U) {
            app_fail("JOURNAL_CORRUPT", "action-result terminal is truncated");
        }
        datacube::Digest32 digest;
        std::copy_n(terminal.begin(), 32U, digest.octets.begin());
        return digest;
    }
    return std::nullopt;
}

void append_runtime_binding(datacube::Octets& out, const RuntimeMutationBinding& binding) {
    datacube::append_be64(out, binding.configuration_event);
    datacube::append_u8(out, binding.journal_kind);
    append_digest(out, binding.payload_digest);
    append_optional_digest(out, binding.operation_id);
}

[[nodiscard]] RuntimeMutationBinding read_runtime_binding(datacube::Reader& reader) {
    return RuntimeMutationBinding{
        .configuration_event = reader.read_be64("bound configuration event"),
        .journal_kind = reader.read_u8("bound journal kind"),
        .payload_digest = read_digest(reader, "bound payload digest"),
        .operation_id = read_optional_digest(reader, "bound operation"),
    };
}

}  // namespace

datacube::Digest32 outbound_policy_digest(const OutboundPolicy& policy) {
    datacube::Octets bytes;
    bytes.reserve(kOutboundPolicyDigestDomain.size() + 1U + 128U);
    datacube::append_text(bytes, kOutboundPolicyDigestDomain);
    datacube::append_u8(bytes, 0U);
    datacube::append_be64(bytes, policy.created_unix_ms);
    datacube::append_be64(bytes, policy.expires_unix_ms);
    datacube::append_be32(bytes, policy.maximum_attempts);
    datacube::append_be32(bytes, policy.initial_backoff_ms);
    datacube::append_be32(bytes, policy.maximum_backoff_ms);
    datacube::append_u8(bytes, policy.peer_generation.has_value() ? 1U : 0U);
    if (policy.peer_generation.has_value()) {
        append_text16(bytes, *policy.peer_generation, 64U,
            "outbound policy generation");
    }
    datacube::append_u8(bytes, policy.peer_spki_sha256.has_value() ? 1U : 0U);
    if (policy.peer_spki_sha256.has_value()) {
        append_digest(bytes, *policy.peer_spki_sha256);
    }
    return datacube::sha256(bytes);
}

std::optional<OutboundRejection> active_outbound_rejection(
    const StoredOutbound& entry) {
    if (!entry.delivery.has_value()) {
        return std::nullopt;
    }
    std::optional<OutboundRejection> active;
    for (const auto& transition : entry.delivery->transitions) {
        if (transition.kind == OutboundTransitionKind::rejected) {
            if (!transition.to_spki_sha256.has_value()) {
                return std::nullopt;
            }
            datacube::Octets detail_material;
            detail_material.reserve(
                kOutboundRejectionDetailDigestDomain.size() + 1U +
                transition.reason.size());
            datacube::append_text(
                detail_material, kOutboundRejectionDetailDigestDomain);
            datacube::append_u8(detail_material, 0U);
            datacube::append_text(detail_material, transition.reason);
            active = OutboundRejection{
                .rejected_unix_ms = transition.unix_ms,
                .code = transition.actor,
                .detail = transition.reason,
                .detail_digest = datacube::sha256(detail_material),
                .peer_generation = transition.from_generation,
                .peer_spki_sha256 = transition.from_spki_sha256,
                .policy_digest = *transition.to_spki_sha256,
            };
        } else if (transition.kind == OutboundTransitionKind::retried ||
                   transition.kind == OutboundTransitionKind::rebound ||
                   transition.kind == OutboundTransitionKind::cancelled) {
            active.reset();
        }
    }
    return active;
}

// Deliberately slow independent reference; not used by production admission.
QueueUsage outbound_queue_usage(
    const std::vector<StoredOutbound>& outbound) {
    QueueUsage usage;
    std::map<std::string, PeerQueueUsage> by_peer;
    for (const auto& entry : outbound) {
        if (active_submission_work) ++active_submission_work->capacity_records_visited;
        if (!outbound_is_pending(entry)) {
            continue;
        }
        if (usage.pending_records == std::numeric_limits<std::uint64_t>::max() ||
            entry.record.payload.size() >
                std::numeric_limits<std::uint64_t>::max() -
                    usage.pending_payload_bytes) {
            app_fail("OUTBOX_ACCOUNTING_OVERFLOW",
                "durable outbox usage exceeds the accounting range");
        }
        ++usage.pending_records;
        usage.pending_payload_bytes +=
            static_cast<std::uint64_t>(entry.record.payload.size());
        auto& peer = by_peer[entry.record.recipient];
        peer.peer = entry.record.recipient;
        if (peer.pending_records == std::numeric_limits<std::uint64_t>::max() ||
            entry.record.payload.size() >
                std::numeric_limits<std::uint64_t>::max() -
                    peer.pending_payload_bytes) {
            app_fail("OUTBOX_ACCOUNTING_OVERFLOW",
                "per-peer outbox usage exceeds the accounting range");
        }
        ++peer.pending_records;
        peer.pending_payload_bytes +=
            static_cast<std::uint64_t>(entry.record.payload.size());
    }
    usage.peers.reserve(by_peer.size());
    for (auto& [peer, value] : by_peer) {
        static_cast<void>(peer);
        usage.peers.push_back(std::move(value));
    }
    return usage;
}

namespace {

void require_outbox_capacity(
    const QueueLimits& limits,
    const PendingCapacityIndex& capacity,
    const std::string_view peer,
    const std::uint64_t payload_bytes,
    const PendingCapacityIndex& future,
    const std::uint64_t converting_bytes = 0U) {
    auto global = capacity.total();
    auto local = capacity.peer(peer);
    const auto reserved_global = future.entries() == 0U ? PendingCapacityTotals{} : future.total();
    const auto reserved_peer = reserved_global.records == 0U ? PendingCapacityTotals{} : future.peer(peer);
    if (converting_bytes != 0U && (reserved_global.records == 0U ||
        reserved_peer.records == 0U || reserved_global.payload_bytes < converting_bytes ||
        reserved_peer.payload_bytes < converting_bytes || payload_bytes > converting_bytes)) {
        app_fail("ACTION_RESULT_RESERVATION_INVALID", "missing or insufficient conversion reservation");
    }
    const auto add = [&](PendingCapacityTotals& value, PendingCapacityTotals reserved) {
        if (converting_bytes != 0U) { --reserved.records; reserved.payload_bytes -= converting_bytes; }
        if (reserved.records > std::numeric_limits<std::uint64_t>::max() - value.records ||
            reserved.payload_bytes > std::numeric_limits<std::uint64_t>::max() - value.payload_bytes) {
            app_fail("OUTBOX_ACCOUNTING_OVERFLOW", "combined obligation capacity overflow");
        }
        value.records += reserved.records;
        value.payload_bytes += reserved.payload_bytes;
    };
    add(global, reserved_global);
    add(local, reserved_peer);
    if (active_submission_work) {
        active_submission_work->capacity_aggregate_reads += reserved_global.records == 0U ? 2U : 4U;
    }
    if (global.records >= limits.global_max_records) {
        app_fail("OUTBOX_GLOBAL_RECORD_LIMIT",
            "global pending-record limit is exhausted");
    }
    if (local.records >= limits.peer_max_records) {
        app_fail("OUTBOX_PEER_RECORD_LIMIT",
            "pending-record limit is exhausted for peer " + std::string(peer));
    }
    if (payload_bytes > limits.global_max_payload_bytes ||
        global.payload_bytes >
            limits.global_max_payload_bytes - payload_bytes) {
        app_fail("OUTBOX_GLOBAL_PAYLOAD_LIMIT",
            "global pending-payload-byte limit is exhausted");
    }
    if (payload_bytes > limits.peer_max_payload_bytes ||
        local.payload_bytes > limits.peer_max_payload_bytes - payload_bytes) {
        app_fail("OUTBOX_PEER_PAYLOAD_LIMIT",
            "pending-payload-byte limit is exhausted for peer " +
                std::string(peer));
    }
}

[[nodiscard]] std::string bounded_rejection_detail(
    const std::string_view detail) {
    std::string safe;
    safe.reserve(std::min<std::size_t>(detail.size(), 256U));
    for (const char raw : detail) {
        if (safe.size() == 256U) { break; }
        const auto ch = static_cast<unsigned char>(raw);
        safe.push_back(ch == 9U || (ch >= 32U && ch <= 126U) ? raw : '?');
    }
    if (safe.empty()) {
        safe = "authenticated peer rejected the operation";
    }
    return safe;
}

}  // namespace

NodeState::NodeState(
    std::filesystem::path state_directory,
    std::string node_id,
    const std::uint64_t maximum_journal_bytes,
    const QueueLimits queue_limits, const bool migration_source)
    : auth_key_(process_state_auth_key()), strict_source_(migration_source), state_directory_(std::move(state_directory)),
      node_id_(std::move(node_id)),
      maximum_journal_bytes_(maximum_journal_bytes),
      queue_limits_(queue_limits) {
    require_node_id(node_id_, "node ID");
    if (state_directory_.empty()) {
        app_fail("INVALID_STATE_DIRECTORY", "state directory is empty");
    }
    if (maximum_journal_bytes_ < 1'024U ||
        maximum_journal_bytes_ > 1'073'741'824U) {
        app_fail("INVALID_JOURNAL_LIMIT",
            "journal limit must be between 1024 bytes and 1 GiB");
    }
    if (queue_limits_.global_max_records == 0U ||
        queue_limits_.global_max_records > 1'000'000U ||
        queue_limits_.peer_max_records == 0U ||
        queue_limits_.peer_max_records > queue_limits_.global_max_records ||
        queue_limits_.global_max_payload_bytes == 0U ||
        queue_limits_.global_max_payload_bytes > 1'073'741'824U ||
        queue_limits_.peer_max_payload_bytes == 0U ||
        queue_limits_.peer_max_payload_bytes >
            queue_limits_.global_max_payload_bytes) {
        app_fail("INVALID_OUTBOX_LIMITS",
            "outbox limits must be positive, bounded, and per-peer limits must not exceed global limits");
    }
    initialize_directory();
    open_and_lock_state();
    // An expectation mismatch must not clean a rollbackable candidate first.
    if (!process_state_head_expectation()) { cleanup_stale_compaction_candidate(); }
    initialize_metadata();
    if ((strict_source_ || auth_key_) && metadata_schema_version_ != kCurrentStorageSchemaVersion) {
        app_fail("STATE_AUTH_SCHEMA_REQUIRED", "authenticated state and migration sources require storage schema 2 metadata");
    }
    open_and_lock_journal();
    load_journal();
    // Complete authentication AND ordinary semantic replay precede comparison.
    enforce_expected_state_head(node_id_, authentication_, journal_bytes_);
    opening_state_head_expectation_ = process_state_head_expectation();
    if (process_state_head_expectation()) { cleanup_stale_compaction_candidate(); }
    migrate_storage_schema_if_needed();
}

NodeState::NodeState(
    MemoryReplayTag, std::string node_id,
    const std::uint64_t maximum_journal_bytes)
    : node_id_(std::move(node_id)),
      maximum_journal_bytes_(maximum_journal_bytes),
      metadata_schema_version_(kCurrentStorageSchemaVersion),
      storage_schema_version_(kCurrentStorageSchemaVersion) {
    require_node_id(node_id_, "checkpoint node ID");
    if (maximum_journal_bytes_ < 1'024U ||
        maximum_journal_bytes_ > 1'073'741'824U) {
        app_fail("INVALID_JOURNAL_LIMIT", "checkpoint replay limit is invalid");
    }
}

StateSnapshot NodeState::validate_checkpoint_image(
    datacube::OctetView frame, std::string node_id,
    const std::uint64_t maximum_journal_bytes, StateAuthKeyPtr key) {
    NodeState replay(MemoryReplayTag{}, std::move(node_id), maximum_journal_bytes);
    const auto physical_bytes = frame.size();
    std::optional<VerifiedJournal> verified;
    if (is_authenticated_journal(frame) || key) {
        verified = verify_authenticated_journal(frame, replay.node_id_, key, maximum_journal_bytes);
        if (verified->authentication.records != 1U) {
            app_fail("JOURNAL_CORRUPT", "backup requires exactly one authenticated checkpoint");
        }
        replay.authentication_ = verified->authentication;
        replay.authenticated_checkpoint_overhead_ = verified->authentication.checkpoint_overhead;
        frame = verified->plain_frames;
    }
    if (frame.size() < 41U || frame.size() > maximum_journal_bytes ||
        !std::equal(kJournalMagic.begin(), kJournalMagic.end(), frame.begin())) {
        app_fail("JOURNAL_CORRUPT", "checkpoint frame size or magic is invalid");
    }
    const auto length = decode_u32(frame.subspan(4U, 4U));
    if (length < 1U || length > kMaximumJournalBodyBytes ||
        static_cast<std::uint64_t>(length) + 40U != frame.size()) {
        app_fail("JOURNAL_CORRUPT", "checkpoint requires exactly one complete frame");
    }
    const auto body = frame.subspan(8U, length);
    if (body[0] != static_cast<std::uint8_t>(EntryKind::checkpoint) ||
        !equal_digest_bytes(checksum(body), frame.last(32U))) {
        app_fail("JOURNAL_CORRUPT", "checkpoint kind or checksum is invalid");
    }
    replay.load_checkpoint(body.subspan(1U));
    replay.journal_bytes_ = physical_bytes;
    const auto snapshot = replay.snapshot();
    if (verified && snapshot.logical_state_digest != verified->authentication.checkpoint_logical_digest) {
        app_fail("STATE_AUTH_CHECKPOINT_MISMATCH", "authenticated checkpoint logical binding failed");
    }
    return snapshot;
}

std::unique_ptr<NodeState> NodeState::replay_authenticated_prefix_state(
    datacube::OctetView source, std::string node_id,
    const std::uint64_t maximum_journal_bytes, StateAuthKeyPtr key) {
    auto verified = verify_authenticated_journal(
        source, node_id, key, maximum_journal_bytes);
    auto replay = std::unique_ptr<NodeState>(new NodeState(
        MemoryReplayTag{}, std::move(node_id), maximum_journal_bytes));
    replay->authentication_ = verified.authentication;
    replay->authenticated_checkpoint_overhead_ =
        verified.authentication.checkpoint_overhead;
    const datacube::OctetView bytes = verified.plain_frames;
    std::size_t offset = 0U;
    try {
        while (offset < bytes.size()) {
            if (bytes.size() - offset < 41U ||
                !std::equal(kJournalMagic.begin(), kJournalMagic.end(),
                    bytes.begin() + static_cast<std::ptrdiff_t>(offset))) {
                app_fail("JOURNAL_CORRUPT",
                    "authenticated prefix frame is invalid");
            }
            const auto length = decode_u32(bytes.subspan(offset + 4U, 4U));
            const auto total = static_cast<std::uint64_t>(length) + 40U;
            if (length < 1U || length > kMaximumJournalBodyBytes ||
                total > bytes.size() - offset) {
                app_fail("JOURNAL_CORRUPT",
                    "authenticated prefix frame length is invalid");
            }
            const auto body = bytes.subspan(offset + 8U, length);
            if (!equal_digest_bytes(checksum(body),
                    bytes.subspan(offset + 8U + length, 32U)) ||
                body[0] < static_cast<std::uint8_t>(EntryKind::inbound) ||
                body[0] > static_cast<std::uint8_t>(EntryKind::result_review)) {
                app_fail("JOURNAL_CORRUPT",
                    "authenticated prefix checksum or kind is invalid");
            }
            replay->apply_entry(
                static_cast<EntryKind>(body[0]), body.subspan(1U), true);
            if (offset == 0U &&
                replay->snapshot_locked().logical_state_digest !=
                    verified.authentication.checkpoint_logical_digest) {
                app_fail("STATE_AUTH_CHECKPOINT_MISMATCH",
                    "prefix checkpoint logical binding failed");
            }
            offset += static_cast<std::size_t>(total);
        }
    } catch (const datacube::Failure&) {
        app_fail("JOURNAL_CORRUPT",
            "authenticated prefix has malformed application state");
    }
    replay->journal_bytes_ = source.size();
    return replay;
}

CheckpointImage NodeState::checkpoint_authenticated_prefix(
    datacube::OctetView source, std::string node_id,
    const std::uint64_t maximum_journal_bytes, StateAuthKeyPtr key) {
    auto replay = replay_authenticated_prefix_state(
        source, std::move(node_id), maximum_journal_bytes, std::move(key));
    return replay->checkpoint_image_locked(
        unix_milliseconds_now(), replay->maintenance_generation_, source.size(), false);
}

OfflineCorrelatedStopReplay NodeState::replay_correlated_stop_audit(
    datacube::OctetView source, std::string node_id,
    const std::uint64_t maximum_journal_bytes, StateAuthKeyPtr key,
    const datacube::Digest32& request_id,
    const std::uint32_t maximum_matches) {
    if (digest_is_zero(request_id) || maximum_matches == 0U ||
        maximum_matches > 64U) {
        app_fail("CORRELATED_STOP_AUDIT_SELECTION_INVALID",
            "request ID and maximum match count are invalid");
    }
    auto replay = replay_authenticated_prefix_state(
        source, std::move(node_id), maximum_journal_bytes, std::move(key));
    if (!replay->authentication_ || replay->authentication_->records == 0U) {
        app_fail("STATE_AUTH_REQUIRED",
            "offline correlated-stop audit requires keyed state");
    }
    if (replay->local_control_events_.size() !=
            replay->control_history_index_.prefixes.size() ||
        replay->lifecycle_events_.size() !=
            replay->lifecycle_history_index_.prefixes.size()) {
        app_fail("JOURNAL_CORRUPT",
            "offline control-history derivative is inconsistent");
    }

    OfflineCorrelatedStopReplay result;
    result.authentication = *replay->authentication_;
    result.journal_bytes = replay->journal_bytes_;
    result.retained_decisions = replay->local_control_events_.size();
    result.retained_lifecycle_events = replay->lifecycle_events_.size();
    result.pending.pending_outbound =
        static_cast<std::uint64_t>(replay->delivery_index_.pending());
    result.pending.pending_actions =
        static_cast<std::uint64_t>(replay->action_selection_index_.pending());

    const auto configuration = [&](const std::uint64_t event) {
        if (event == 0U || event > replay->configuration_events_.size() ||
            event > replay->configuration_history_index_.size()) {
            app_fail("JOURNAL_CORRUPT",
                "offline audit row references an unavailable configuration");
        }
        const auto index = static_cast<std::size_t>(event - 1U);
        const auto& value = replay->configuration_events_.at(index);
        return OfflineConfigurationReference{
            .event = event,
            .generation = value.generation,
            .digest = value.digest,
            .prefix = replay->configuration_history_index_.at(index).prefix,
        };
    };

    const auto decision_it = replay->control_history_index_.by_request.find(
        request_id.octets);
    const auto lifecycle_it = replay->lifecycle_history_index_.by_request.find(
        request_id.octets);
    const std::size_t decision_count = decision_it ==
        replay->control_history_index_.by_request.end() ? 0U :
        decision_it->second.size();
    const std::size_t lifecycle_count = lifecycle_it ==
        replay->lifecycle_history_index_.by_request.end() ? 0U :
        lifecycle_it->second.size();
    if (decision_count + lifecycle_count > maximum_matches) {
        app_fail("CORRELATED_STOP_AUDIT_MATCH_LIMIT",
            "matching durable rows exceed the explicit bounded report limit");
    }

    if (decision_it != replay->control_history_index_.by_request.end()) {
        result.decisions.reserve(decision_it->second.size());
        for (const auto ordinal : decision_it->second) {
            if (ordinal == 0U || ordinal > replay->local_control_events_.size()) {
                app_fail("JOURNAL_CORRUPT",
                    "offline decision index contains an invalid ordinal");
            }
            const auto index = static_cast<std::size_t>(ordinal - 1U);
            const auto& value = replay->local_control_events_.at(index);
            if (value.request_id != request_id) {
                app_fail("JOURNAL_CORRUPT",
                    "offline decision index request binding differs");
            }
            result.decisions.push_back(OfflineControlDecisionMatch{
                .ordinal = ordinal,
                .configuration = configuration(value.configuration_event),
                .history_prefix =
                    replay->control_history_index_.prefixes.at(index),
                .request_id = value.request_id,
                .uid = value.uid,
                .gid = value.gid,
                .pid = value.pid,
                .unix_ms = value.unix_ms,
                .command = value.command,
                .command_class = value.command_class,
                .decision = value.decision,
                .error_code = value.error_code,
            });
        }
    }

    const auto reason_digest = [](const std::string_view reason) {
        datacube::Octets material;
        datacube::append_text(material,
            "NATRAV_OVERLAY_LIFECYCLE_REASON_V1");
        datacube::append_u8(material, 0U);
        datacube::append_text(material, reason);
        return datacube::sha256(material);
    };
    if (lifecycle_it != replay->lifecycle_history_index_.by_request.end()) {
        result.lifecycle.reserve(lifecycle_it->second.size());
        for (const auto ordinal : lifecycle_it->second) {
            if (ordinal == 0U || ordinal > replay->lifecycle_events_.size()) {
                app_fail("JOURNAL_CORRUPT",
                    "offline lifecycle index contains an invalid ordinal");
            }
            const auto index = static_cast<std::size_t>(ordinal - 1U);
            const auto& value = replay->lifecycle_events_.at(index);
            if (value.request_id != request_id) {
                app_fail("JOURNAL_CORRUPT",
                    "offline lifecycle index request binding differs");
            }
            result.lifecycle.push_back(OfflineLifecycleMatch{
                .ordinal = ordinal,
                .configuration = configuration(value.configuration_event),
                .history_prefix =
                    replay->lifecycle_history_index_.prefixes.at(index),
                .request_id = value.request_id,
                .uid = value.uid,
                .pid = value.pid,
                .unix_ms = value.unix_ms,
                .kind = value.kind,
                .deadline_ms = value.deadline_ms,
                .pending_outbound = value.pending_outbound,
                .pending_actions = value.pending_actions,
                .reason_bytes = value.reason.size(),
                .reason_digest = reason_digest(value.reason),
            });
        }
    }
    return result;
}

void NodeState::index_inbound(const std::size_t index) {
    index_received_action_result_locked(index);
    if (inbound_[index].authorization) ++authorized_inbound_count_;
    if (inbound_[index].subscribed_source) {
        const auto& a=*inbound_[index].subscribed_source;
        auto& use=source_view_usage_[a.view];++use.first;use.second+=inbound_[index].record.payload.size();
        if (!source_view_ordinals_.emplace(a.view,datacube::hex_lower(a.subscription_instance),a.ordinal).second) {
            app_fail("JOURNAL_CORRUPT","duplicate materialized source ordinal");
        }
    }
    const auto& record = inbound_[index].record;
    const auto parent = record.corrects ?
        std::optional<std::size_t>(inbound_index_.at(op_key(*record.corrects))) : std::nullopt;
    inbound_domain_index_[{record.issuer, record.scope}].append(index, parent);
    inbound_order_index_.append(index, parent);
    if (inbound_[index].local_authorship) {
        authored_source_index_[{inbound_[index].local_authorship->uid, record.scope}].push_back(index);
    }
}

void NodeState::index_action(const std::size_t index) {
    const auto& action = actions_.at(index);
    action_inspection_index_.touch(index, action.issuer, std::string(action_status_name(action)));
    action_selection_index_.touch(index, action_is_pending(action) ?
        std::optional<ActionSelectionIndexEntry>(ActionSelectionIndexEntry{
            .not_before_unix_ms = action.not_before_unix_ms,
            .expires_unix_ms = action.expires_unix_ms,
        }) : std::nullopt);
    const std::size_t next = action.completed_unix_ms ? 1U : action.cancelled_unix_ms ? 2U : action.expired_unix_ms ? 3U : 0U;
    if (index == indexed_action_outcomes_.size()) {
        indexed_action_outcomes_.push_back(next); ++action_outcomes_[next];
    } else {
        auto& before = indexed_action_outcomes_.at(index);
        if (before != next) { --action_outcomes_[before]; ++action_outcomes_[next]; before = next; }
    }
}

void NodeState::initialize_directory() {
    if (auth_key_ || strict_source_) {
        // Keyed operation never creates a missing source or traverses a symlink.
        for (const auto& part : state_directory_) {
            if (part == "..") { app_fail("STATE_AUTH_SOURCE_UNSAFE", "dot-dot state path rejected"); }
        }
        const auto absolute = std::filesystem::absolute(state_directory_).lexically_normal();
        datacube::Fd checked(::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC));
        if (!checked) { app_fail("STATE_AUTH_SOURCE_UNSAFE", "cannot open root"); }
        for (const auto& part : absolute.relative_path()) {
            const int raw = ::openat(checked.get(), part.c_str(), O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
            if (raw < 0) { app_fail("STATE_AUTH_SOURCE_UNSAFE", "state ancestry must exist without symlinks"); }
            checked.reset(raw);
        }
        struct stat st {};
        if (::fstat(checked.get(), &st) != 0 || st.st_uid != ::geteuid() || (st.st_mode & 07777U) != 0700U) {
            app_fail("STATE_AUTH_SOURCE_UNSAFE", "state directory must be effective-user owned and mode 0700");
        }
        for (const auto* name : {"node.meta", "state.journal"}) {
            if (::fstatat(checked.get(), name, &st, AT_SYMLINK_NOFOLLOW) != 0 || !S_ISREG(st.st_mode) ||
                st.st_uid != ::geteuid() || st.st_nlink != 1 || (st.st_mode & 07777U) != 0600U) {
                app_fail("STATE_AUTH_SOURCE_UNSAFE", "state metadata and journal must be private single-link regular files");
            }
        }
        directory_fd_ = std::move(checked);
        return;
    }
    std::error_code error;
    const bool existed = std::filesystem::exists(state_directory_, error);
    if (error) {
        app_fail("STATE_DIRECTORY_FAILED", error.message());
    }
    if (!existed && !std::filesystem::create_directories(state_directory_, error)) {
        if (error) {
            app_fail("STATE_DIRECTORY_FAILED", error.message());
        }
    }
    if (::chmod(state_directory_.c_str(), S_IRWXU) != 0 && errno != EPERM) {
        app_fail("STATE_DIRECTORY_FAILED",
            datacube::errno_detail(state_directory_.string(), errno));
    }
    const int raw = ::open(
        state_directory_.c_str(),
        O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (raw < 0) {
        app_fail("STATE_DIRECTORY_FAILED",
            datacube::errno_detail(state_directory_.string(), errno));
    }
    directory_fd_.reset(raw);
}

void NodeState::open_and_lock_state() {
    const int raw = ::openat(
        directory_fd_.get(),
        "state.lock",
        O_RDWR | O_CREAT | O_CLOEXEC | O_NOFOLLOW,
        S_IRUSR | S_IWUSR);
    if (raw < 0) {
        app_fail("STATE_LOCK_OPEN_FAILED",
            datacube::errno_detail("state.lock", errno));
    }
    state_lock_fd_.reset(raw);
    struct stat status {};
    if (::fstat(state_lock_fd_.get(), &status) != 0 ||
        !S_ISREG(status.st_mode)) {
        app_fail("STATE_LOCK_INVALID", "state.lock must be a regular file");
    }
    if ((auth_key_ || strict_source_) && (status.st_uid != ::geteuid() || status.st_nlink != 1 ||
        (status.st_mode & 07777U) != 0600U)) {
        app_fail("STATE_AUTH_SOURCE_UNSAFE", "state lock must be private, single-link, and effective-user owned");
    }
    if (::fchmod(state_lock_fd_.get(), S_IRUSR | S_IWUSR) != 0) {
        app_fail("STATE_LOCK_MODE_FAILED",
            datacube::errno_detail("state.lock", errno));
    }
    if (::flock(state_lock_fd_.get(), LOCK_EX | LOCK_NB) != 0) {
        if (errno == EWOULDBLOCK) {
            app_fail("STATE_BUSY", "another process owns this state directory");
        }
        app_fail("STATE_LOCK_FAILED",
            datacube::errno_detail("state.lock", errno));
    }
}

void NodeState::cleanup_stale_compaction_candidate() {
    struct stat status {};
    if (::fstatat(
            directory_fd_.get(),
            std::string(kCompactionCandidateName).c_str(),
            &status,
            AT_SYMLINK_NOFOLLOW) != 0) {
        if (errno == ENOENT) {
            return;
        }
        app_fail("COMPACTION_CANDIDATE_STAT_FAILED",
            datacube::errno_detail(kCompactionCandidateName, errno));
    }
    if (!S_ISREG(status.st_mode)) {
        app_fail("COMPACTION_CANDIDATE_INVALID",
            "stale compaction candidate is not a regular file");
    }
    if (::unlinkat(
            directory_fd_.get(),
            std::string(kCompactionCandidateName).c_str(),
            0) != 0) {
        app_fail("COMPACTION_CANDIDATE_CLEANUP_FAILED",
            datacube::errno_detail(kCompactionCandidateName, errno));
    }
    if (::fsync(directory_fd_.get()) != 0) {
        app_fail("STATE_DIRECTORY_SYNC_FAILED",
            datacube::errno_detail(state_directory_.string(), errno));
    }
}

void NodeState::initialize_metadata() {
    int raw = ::openat(
        directory_fd_.get(),
        "node.meta",
        O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (raw < 0 && errno == ENOENT) {
        const auto expected = metadata_text_v2(node_id_);
        raw = ::openat(
            directory_fd_.get(),
            "node.meta",
            O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW,
            S_IRUSR | S_IWUSR);
        if (raw >= 0) {
            datacube::Fd created(raw);
            write_all(created.get(), datacube::text_octets(expected));
            if (::fsync(created.get()) != 0) {
                app_fail("STATE_METADATA_SYNC_FAILED",
                    datacube::errno_detail("node.meta", errno));
            }
            if (::fsync(directory_fd_.get()) != 0) {
                app_fail("STATE_DIRECTORY_SYNC_FAILED",
                    datacube::errno_detail(state_directory_.string(), errno));
            }
            metadata_schema_version_ = kCurrentStorageSchemaVersion;
            storage_schema_version_ = kCurrentStorageSchemaVersion;
            return;
        }
        if (errno == EEXIST) {
            raw = ::openat(
                directory_fd_.get(),
                "node.meta",
                O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
        }
    }
    if (raw < 0) {
        app_fail("STATE_METADATA_OPEN_FAILED",
            datacube::errno_detail("node.meta", errno));
    }
    datacube::Fd existing(raw);
    const auto bytes = datacube::read_all_fd(existing.get(), 512U, "node.meta");
    const std::string actual(
        reinterpret_cast<const char*>(bytes.data()), bytes.size());
    if (actual == metadata_text_v1(node_id_)) {
        metadata_schema_version_ = 1U;
        storage_schema_version_ = 1U;
        return;
    }
    if (actual == metadata_text_v2(node_id_)) {
        metadata_schema_version_ = kCurrentStorageSchemaVersion;
        storage_schema_version_ = kCurrentStorageSchemaVersion;
        return;
    }
    if (actual.starts_with(kMetadataPrefixV1) ||
        actual.starts_with(kMetadataPrefixV2)) {
        app_fail("STATE_NODE_MISMATCH",
            "state directory belongs to a different node ID");
    }
    app_fail("STATE_METADATA_CORRUPT", "node.meta has an unknown schema");
}

void NodeState::publish_metadata_v2() {
    static constexpr std::string_view temporary = "node.meta.migrate.tmp";
    static_cast<void>(::unlinkat(
        directory_fd_.get(), std::string(temporary).c_str(), 0));
    const int raw = ::openat(
        directory_fd_.get(),
        std::string(temporary).c_str(),
        O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW,
        S_IRUSR | S_IWUSR);
    if (raw < 0) {
        app_fail("STATE_METADATA_MIGRATION_FAILED",
            datacube::errno_detail(temporary, errno));
    }
    datacube::Fd candidate(raw);
    write_all(candidate.get(), datacube::text_octets(metadata_text_v2(node_id_)));
    if (::fsync(candidate.get()) != 0) {
        app_fail("STATE_METADATA_SYNC_FAILED",
            datacube::errno_detail(temporary, errno));
    }
    if (::renameat(
            directory_fd_.get(), std::string(temporary).c_str(),
            directory_fd_.get(), "node.meta") != 0) {
        app_fail("STATE_METADATA_MIGRATION_FAILED",
            datacube::errno_detail("rename node.meta", errno));
    }
    if (::fsync(directory_fd_.get()) != 0) {
        app_fail("STATE_DIRECTORY_SYNC_FAILED",
            datacube::errno_detail(state_directory_.string(), errno));
    }
    metadata_schema_version_ = kCurrentStorageSchemaVersion;
}

void NodeState::migrate_storage_schema_if_needed() {
    if (metadata_schema_version_ == kCurrentStorageSchemaVersion &&
        storage_schema_version_ == kCurrentStorageSchemaVersion) {
        return;
    }
    if (metadata_schema_version_ != 1U ||
        (storage_schema_version_ != 1U &&
         storage_schema_version_ != kCurrentStorageSchemaVersion)) {
        app_fail("STORAGE_SCHEMA_MISMATCH",
            "state metadata and journal schema versions disagree");
    }
    if (storage_schema_version_ == 1U) {
        datacube::Octets payload;
        datacube::append_be32(payload, 1U);
        datacube::append_be32(payload, kCurrentStorageSchemaVersion);
        datacube::append_be64(payload, unix_milliseconds_now());
        append_entry(EntryKind::schema_migrated, payload);
    }
    publish_metadata_v2();
}

void NodeState::open_and_lock_journal() {
    const int raw = ::openat(
        directory_fd_.get(),
        "state.journal",
        O_RDWR | O_APPEND | O_CREAT | O_CLOEXEC | O_NOFOLLOW,
        S_IRUSR | S_IWUSR);
    if (raw < 0) {
        app_fail("JOURNAL_OPEN_FAILED",
            datacube::errno_detail("state.journal", errno));
    }
    journal_fd_.reset(raw);
    if (::flock(journal_fd_.get(), LOCK_EX | LOCK_NB) != 0) {
        if (errno == EWOULDBLOCK) {
            app_fail("STATE_BUSY", "another process owns this state directory");
        }
        app_fail("JOURNAL_LOCK_FAILED",
            datacube::errno_detail("state.journal", errno));
    }
    struct stat status {};
    if (::fstat(journal_fd_.get(), &status) != 0) {
        app_fail("JOURNAL_STAT_FAILED",
            datacube::errno_detail("state.journal", errno));
    }
    if (!S_ISREG(status.st_mode) || status.st_size < 0) {
        app_fail("JOURNAL_NOT_REGULAR", "state.journal");
    }
    if ((auth_key_ || strict_source_) && (status.st_uid != ::geteuid() || status.st_nlink != 1 ||
        (status.st_mode & 07777U) != 0600U)) {
        app_fail("STATE_AUTH_SOURCE_UNSAFE", "journal descriptor must remain private and single-link");
    }
    journal_bytes_ = static_cast<std::uint64_t>(status.st_size);
    if (journal_bytes_ > maximum_journal_bytes_) {
        app_fail("STATE_CAPACITY_EXCEEDED",
            "existing journal exceeds configured maximum");
    }
}

void NodeState::load_journal() {
    const auto raw_bytes = datacube::read_all_fd(
        journal_fd_.get(), maximum_journal_bytes_, "state.journal");
    datacube::OctetView bytes = raw_bytes;
    std::optional<VerifiedJournal> verified;
    if (is_authenticated_journal(bytes) || auth_key_) {
        verified = verify_authenticated_journal(bytes, node_id_, auth_key_, maximum_journal_bytes_);
        authentication_ = verified->authentication;
        authenticated_checkpoint_overhead_ = authentication_->checkpoint_overhead;
        bytes = verified->plain_frames;
    }
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const std::size_t remaining = bytes.size() - offset;
        if (remaining < 8U) {
            break;
        }
        const datacube::OctetView header(bytes.data() + offset, 8U);
        if (!std::equal(
                kJournalMagic.begin(), kJournalMagic.end(), header.begin())) {
            app_fail("JOURNAL_CORRUPT",
                "record magic mismatch at offset " + std::to_string(offset));
        }
        const auto body_length = decode_u32(header.subspan(4U, 4U));
        if (body_length < 1U || body_length > kMaximumJournalBodyBytes) {
            app_fail("JOURNAL_CORRUPT",
                "record length invalid at offset " + std::to_string(offset));
        }
        const std::size_t total = 8U + static_cast<std::size_t>(body_length) + 32U;
        if (remaining < total) {
            break;
        }
        const datacube::OctetView body(
            bytes.data() + offset + 8U,
            static_cast<std::size_t>(body_length));
        const datacube::OctetView actual_checksum(
            bytes.data() + offset + 8U + static_cast<std::size_t>(body_length),
            32U);
        const auto expected_checksum = checksum(body);
        if (!equal_digest_bytes(expected_checksum, actual_checksum)) {
            app_fail("JOURNAL_CORRUPT",
                "record checksum mismatch at offset " + std::to_string(offset));
        }
        const auto kind_value = body[0];
        if (kind_value < static_cast<std::uint8_t>(EntryKind::inbound) ||
            kind_value > static_cast<std::uint8_t>(EntryKind::result_review)) {
            app_fail("JOURNAL_CORRUPT",
                "unknown record kind at offset " + std::to_string(offset));
        }
        try {
            apply_entry(
                static_cast<EntryKind>(kind_value),
                body.subspan(1U),
                true);
            if (offset == 0U && verified &&
                snapshot_locked().logical_state_digest != authentication_->checkpoint_logical_digest) {
                app_fail("STATE_AUTH_CHECKPOINT_MISMATCH", "authenticated checkpoint logical binding failed");
            }
        } catch (const AppError& error) {
            const auto wrapped = wrap_decode_error(error);
            app_fail(wrapped.code,
                wrapped.detail + " at offset " + std::to_string(offset));
        } catch (const datacube::Failure& error) {
            app_fail("JOURNAL_CORRUPT",
                std::string(error.what()) + " at offset " + std::to_string(offset));
        }
        offset += total;
    }
    if (offset != bytes.size()) {
        if (verified || strict_source_) {
            app_fail("STATE_AUTH_TRUNCATED", "incomplete source or authenticated frame; nothing was truncated");
        }
        const auto discarded = static_cast<std::uint64_t>(bytes.size() - offset);
        if (::ftruncate(journal_fd_.get(), static_cast<off_t>(offset)) != 0) {
            app_fail("JOURNAL_RECOVERY_FAILED",
                datacube::errno_detail("ftruncate state.journal", errno));
        }
        if (::fdatasync(journal_fd_.get()) != 0) {
            app_fail("JOURNAL_RECOVERY_FAILED",
                datacube::errno_detail("fdatasync state.journal", errno));
        }
        journal_bytes_ = static_cast<std::uint64_t>(offset);
        append_recovery(discarded, static_cast<std::uint64_t>(offset));
    }
}


void NodeState::apply_action_result(
    const datacube::OctetView payload,
    const bool replaying) {
    datacube::Reader reader(payload, "action-result transaction");
    if (datacube::octets_text(reader.read_exact(4U, "action-result magic"),
            "action-result magic", true) != "NAT1") {
        app_fail("JOURNAL_CORRUPT", "unknown action-result transaction");
    }
    const auto raw_outcome = reader.read_u8("action-result outcome");
    if (raw_outcome < static_cast<std::uint8_t>(ActionResultOutcome::executed) ||
        raw_outcome > static_cast<std::uint8_t>(ActionResultOutcome::expired)) {
        app_fail("JOURNAL_CORRUPT", "invalid action-result outcome");
    }
    const auto outcome = static_cast<ActionResultOutcome>(raw_outcome);
    const auto terminal_size = reader.read_be32("action terminal size");
    if (terminal_size < 32U || terminal_size > 1'024U) {
        app_fail("JOURNAL_CORRUPT", "invalid action terminal size");
    }
    const auto terminal = reader.read_exact(terminal_size, "action terminal");
    const auto composite = reader.read_exact(reader.remaining(),
        "action-result outbox composite");
    reader.require_eof("action-result transaction");

    datacube::Reader terminal_reader(terminal, "action-result terminal");
    const auto action_id = read_digest(terminal_reader, "action ID");
    const auto found = action_index_.find(op_key(action_id));
    if (found == action_index_.end()) {
        app_fail("JOURNAL_CORRUPT", "action result has no admitted action");
    }
    const auto result_found = action_results_.find(op_key(action_id));
    if (result_found == action_results_.end() ||
        result_found->second.outcome.has_value() ||
        result_found->second.operation_id.has_value() ||
        result_found->second.record_digest.has_value()) {
        app_fail("JOURNAL_CORRUPT", "action result binding is absent or terminal");
    }
    const auto source_found = inbound_index_.find(op_key(action_id));
    if (source_found == inbound_index_.end()) {
        app_fail("JOURNAL_CORRUPT", "action result source is absent");
    }
    const auto& current = actions_.at(found->second);
    if (!action_is_pending(current)) {
        app_fail("JOURNAL_CORRUPT", "action result follows a terminal action");
    }
    StoredAction terminal_action = current;
    EntryKind terminal_kind = EntryKind::action_completed;
    if (outcome == ActionResultOutcome::executed) {
        const auto attempt = terminal_reader.read_be32("action attempt");
        const auto completed = terminal_reader.read_be64("action completion time");
        const auto before = terminal_reader.read_be64("counter before");
        const auto after = terminal_reader.read_be64("counter after");
        const auto receipt = read_digest(terminal_reader, "action receipt");
        terminal_reader.require_eof("action completion");
        if (!current.last_started_unix_ms.has_value() || attempt == 0U ||
            attempt != current.attempts || completed == 0U ||
            completed < *current.last_started_unix_ms ||
            before != action_counter_value_ ||
            current.amount > std::numeric_limits<std::uint64_t>::max() - before ||
            after != before + current.amount ||
            after > current.limits.counter_budget ||
            action_reserved_amount_ < current.amount ||
            receipt != action_receipt_digest(
                action_id, attempt, completed, before, after)) {
            app_fail("JOURNAL_CORRUPT", "invalid action-result completion");
        }
        terminal_action.completed_unix_ms = completed;
        terminal_action.counter_before = before;
        terminal_action.counter_after = after;
        terminal_action.receipt_digest = receipt;
        terminal_action.last_error_code.clear();
    } else {
        const auto at = terminal_reader.read_be64("action terminal time");
        const auto reason = read_text16(
            terminal_reader, 256U, "action terminal reason");
        terminal_reader.require_eof("action terminal");
        if (at == 0U || !valid_transition_text(reason, 256U) ||
            action_reserved_amount_ < current.amount) {
            app_fail("JOURNAL_CORRUPT", "invalid action-result terminal state");
        }
        if (outcome == ActionResultOutcome::cancelled) {
            terminal_kind = EntryKind::action_cancelled;
            terminal_action.cancelled_unix_ms = at;
            terminal_action.cancellation_reason = reason;
            terminal_action.last_error_code = applying_action_administration_ ?
                "ACTION_CANCELLED_CONDITIONAL" : "ACTION_CANCELLED";
        } else {
            terminal_kind = EntryKind::action_expired;
            terminal_action.expired_unix_ms = at;
            terminal_action.expiry_reason = reason;
            terminal_action.last_error_code = "ACTION_EXPIRED";
        }
    }

    const auto& result_state = result_found->second;
    const auto& source = inbound_.at(source_found->second);
    const auto expected_record = action_result_record(
        node_id_, terminal_action, source, result_state.binding, outcome);
    const auto expected_policy = action_result_outbound_policy(
        result_state.binding, action_terminal_time(terminal_action, outcome));
    validate_new_outbound_locked(expected_record, expected_policy, found->second);
    const auto expected = action_result_transaction_payload(
        outcome, terminal, expected_record, expected_policy);
    if (expected.size() != payload.size() ||
        !std::equal(expected.begin(), expected.end(), payload.begin())) {
        app_fail("JOURNAL_CORRUPT", "action-result transaction binding mismatch");
    }

    applying_action_result_ = true;
    try {
        apply_entry(terminal_kind, terminal, replaying);
        index_action_result_reservation_locked(found->second);
        apply_entry(EntryKind::outbound_queued_with_policy, composite, replaying);
        applying_action_result_ = false;
    } catch (...) {
        applying_action_result_ = false;
        throw;
    }
    auto& stored_result = action_results_.at(op_key(action_id));
    stored_result.outcome = outcome;
    stored_result.operation_id = expected_record.operation_id;
    stored_result.record_digest = evidence_record_digest(expected_record);
    action_result_operations_.emplace(op_key(expected_record.operation_id),
        stored_result.binding.reserved_payload_bytes != 0U);
    outbox_associations_[op_key(expected_record.operation_id)] =
        std::string("{\"kind\":\"ACTION_RESULT\",\"action_id\":") +
        json_string(op_key(action_id)) +
        ",\"outcome\":" +
        json_string(action_result_outcome_name(outcome)) +
        ",\"result_scope\":" +
        json_string(result_state.binding.result_scope) +
        ",\"configuration_event\":" +
        std::to_string(result_state.binding.configuration_event) +
        ",\"local_result_receipt\":" +
        (terminal_action.receipt_digest.has_value() ?
            json_string(datacube::hex_lower(*terminal_action.receipt_digest)) :
            std::string("null")) + "}";
}

// The generic and source-specific paths share every admission predicate and
// mutation. Only a same-command parsed source can select the record reuse path.
void NodeState::apply_outbound_admission_locked(const datacube::OctetView payload,
    const bool replaying, const ParsedSourceProgress* parsed) {
    if (parsed && (replaying || !applying_runtime_bound_mutation_)) {
        app_fail("JOURNAL_CORRUPT", "source outbound preparation outside live bound admission");
    }
    if (active_source_validation_work) { ++active_source_validation_work->outbound_composite_frames; }
    datacube::Reader reader(payload, "atomic outbound admission");
    const auto operation = read_digest(reader, "operation");
    const auto length = reader.read_be32("record length");
    const auto record_bytes = reader.read_exact(length, "record");
    const auto policy_bytes = reader.read_exact(reader.remaining(), "policy");
    std::optional<ApplicationMessage> independent;
    const EvidenceRecord* record = nullptr;
    if (parsed) {
        record = &source_outbound_record_locked(payload, *parsed,
            SourceOutboundPart::composite, replaying);
        validate_evidence_record(*record);
    } else {
        if (active_source_validation_work) {
            ++active_source_validation_work->outbound_record_decodes;
            active_source_validation_work->outbound_record_bytes_decoded += record_bytes.size();
        }
        independent.emplace(decode_application_message(record_bytes));
        record = std::get_if<EvidenceRecord>(&*independent);
        if (record && active_source_validation_work) {
            active_source_validation_work->outbound_record_payload_bytes_decoded += record->payload.size();
        }
    }
    if (record && active_source_validation_work) {
        ++active_source_validation_work->outbound_record_validations;
    }
    if (record == nullptr || record->operation_id != operation ||
        policy_bytes.size() < 32U ||
        !std::equal(operation.octets.begin(), operation.octets.end(), policy_bytes.begin())) {
        app_fail("JOURNAL_CORRUPT", "atomic operation/policy binding mismatch");
    }
    apply_outbound_record_locked(record_bytes, replaying, parsed);
    apply_entry(EntryKind::outbound_policy, policy_bytes, replaying);
    return;
}

void NodeState::apply_outbound_record_locked(const datacube::OctetView payload,
    const bool replaying, const ParsedSourceProgress* parsed) {
    if (parsed && (replaying || !applying_runtime_bound_mutation_)) {
        app_fail("JOURNAL_CORRUPT", "source outbound preparation outside live bound record");
    }
    std::optional<ApplicationMessage> independent;
    std::optional<EvidenceRecord> transferred;
    const EvidenceRecord* record = nullptr;
    if (parsed) {
#ifdef NATRAV_SOURCE_OUTBOUND_COPY_STORE
        record = &source_outbound_record_locked(payload, *parsed,
            SourceOutboundPart::record, replaying);
#else
        transferred.emplace(take_source_outbound_record_locked(
            payload, *parsed, replaying));
        record = &*transferred;
#endif
        validate_evidence_record(*record);
    } else {
        if (active_source_validation_work) {
            ++active_source_validation_work->outbound_record_decodes;
            active_source_validation_work->outbound_record_bytes_decoded += payload.size();
        }
        independent.emplace(decode_application_message(payload));
        record = std::get_if<EvidenceRecord>(&*independent);
        if (record && active_source_validation_work) {
            active_source_validation_work->outbound_record_payload_bytes_decoded += record->payload.size();
        }
    }
    if (record && active_source_validation_work) {
        ++active_source_validation_work->outbound_record_validations;
    }
    if (record == nullptr) {
        app_fail("JOURNAL_CORRUPT", "outbound entry is not evidence");
    }
    if (record->issuer != node_id_) {
        app_fail("JOURNAL_CORRUPT", "outbound issuer does not match node");
    }
    const auto key = op_key(record->operation_id);
    if (outbound_index_.contains(key)) {
        app_fail("JOURNAL_CORRUPT", "duplicate outbound queue entry");
    }
    const auto index = outbound_.size();
    if (active_source_validation_work && !transferred.has_value()) {
        active_source_validation_work->outbound_store_payload_bytes_copied += record->payload.size();
    }
    if (active_source_validation_work) {
        ++active_source_validation_work->outbound_store_digest_calls;
        active_source_validation_work->outbound_store_digest_payload_bytes += record->payload.size();
    }
    const auto record_digest = evidence_record_digest(*record);
    EvidenceRecord stored_record = transferred.has_value() ?
        std::move(*transferred) : *record;
    outbound_.push_back(StoredOutbound{
        .record = std::move(stored_record),
        .record_digest = record_digest,
        .queue_sequence = static_cast<std::uint64_t>(outbound_.size()) + 1U,
        .receipt = std::nullopt,
        .delivery = std::nullopt,
    });
    outbound_index_.emplace(key, index);
    index_outbound(index);
    return;
}

void NodeState::apply_entry(
    const EntryKind kind,
    const datacube::OctetView payload,
    const bool replaying,
    const SourceProgressPreparation* prepared,
    const ParsedSourceProgress* parsed) {
    if ((prepared || parsed) && (replaying || kind != EntryKind::source_subscription)) {
        app_fail("JOURNAL_CORRUPT", "source preparation outside live source progress");
    }
    if (kind == EntryKind::custody_event) {
        const auto event = decode_durable_custody_event(payload);
        validate_custody_event_authority(
            custody_registry_, configuration_events_, event);
        static_cast<void>(custody_registry_.apply(event));
        return;
    }
    if (kind == EntryKind::result_review) { apply_result_review(payload); return; }
    if (kind == EntryKind::action_result) {
        apply_action_result(payload, replaying);
        return;
    }
    if (kind == EntryKind::outbox_administration) { apply_outbox_administration(payload); return; }
    if (kind == EntryKind::action_administration) { apply_action_administration(payload); return; }
    if (kind == EntryKind::consumer_update) { apply_consumer_update(payload); return; }
    if (kind == EntryKind::projection_schedule) { apply_projection_schedule_update(payload); return; }
    if (kind == EntryKind::consumer_retirement) { apply_consumer_retirement(payload); return; }
    if (kind == EntryKind::source_subscription) { apply_source_subscription(payload, replaying, false, prepared, parsed); return; }
    if (kind == EntryKind::publication_channel) { apply_publication_channel(payload, replaying); return; }
    if (kind == EntryKind::runtime_configuration) {
        datacube::Reader reader(payload, "runtime configuration");
        const auto event = read_runtime_event(reader);
        reader.require_eof("runtime configuration");
        validate_runtime_event(event, configuration_events_, node_id_);
        if (event.kind != "REJECTED") {
            reserve_source_view_domains_locked(parse_runtime_config(event.canonical,"/source-view-reservation",IdentityFileValidation::deferred));
        }
        configuration_events_.push_back(event);
        index_configuration_event_locked(runtime_event_payload(event));
        if (event.kind != "REJECTED") {
            queue_limits_ = parse_runtime_config(
                event.canonical,
                "/durable-configuration",
                IdentityFileValidation::deferred).queue_limits;
        }
        return;
    }
    if (kind == EntryKind::local_control_event) {
        datacube::Reader reader(payload, "local control event");
        const auto event = read_local_control_event(reader);
        reader.require_eof("local control event");
        validate_local_control_event(event, configuration_events_);
        if (local_control_events_.size() >= 1'000'000U) {
            app_fail("LOCAL_CONTROL_HISTORY_LIMIT", "local control history limit reached");
        }
        local_control_events_.push_back(event);
        index_control_history_locked(true, local_control_event_payload(event));
        return;
    }
    if (kind == EntryKind::lifecycle_event) {
        datacube::Reader reader(payload, "lifecycle event");
        const auto event = read_lifecycle_event(reader);
        reader.require_eof("lifecycle event");
        validate_lifecycle_event(event, configuration_events_);
        if (lifecycle_events_.size() >= 1'000'000U) {
            app_fail("LIFECYCLE_HISTORY_LIMIT", "lifecycle history limit reached");
        }
        lifecycle_events_.push_back(event);
        index_control_history_locked(false, lifecycle_event_payload(event));
        return;
    }
    if (kind == EntryKind::runtime_bound_mutation) {
        datacube::Reader reader(payload, "runtime-bound mutation");
        const auto configuration_event = reader.read_be64("configuration event");
        const auto inner = reader.read_u8("inner kind");
        if (configuration_event == 0U ||
            configuration_event != active_configuration_event(configuration_events_) ||
            inner < 1U || (inner > 21U && inner != 24U && inner != 37U && inner != 39U) ||
            inner == 17U || inner == 18U || inner == 19U) {
            app_fail("JOURNAL_CORRUPT", "runtime mutation generation mismatch");
        }
        const auto bytes = reader.read_exact(reader.remaining(), "inner payload");
        if (inner == static_cast<std::uint8_t>(EntryKind::custody_event) &&
            decode_durable_custody_event(bytes).configuration_event !=
                configuration_event) {
            app_fail("JOURNAL_CORRUPT",
                "custody event configuration binding mismatch");
        }
        RuntimeMutationBinding binding{
            .configuration_event = configuration_event,
            .journal_kind = inner,
            .payload_digest = datacube::sha256(bytes),
            .operation_id = runtime_mutation_operation(inner, bytes),
        };
        applying_runtime_bound_mutation_ = true;
        try {
            apply_entry(static_cast<EntryKind>(inner), bytes, replaying);
            applying_runtime_bound_mutation_ = false;
        } catch (...) {
            applying_runtime_bound_mutation_ = false;
            throw;
        }
        configuration_bindings_.push_back(binding);
        index_configuration_binding_locked();
        return;
    }
    if (active_configuration_event(configuration_events_) != 0U &&
        !applying_runtime_bound_mutation_ && kind != EntryKind::schema_migrated &&
        kind != EntryKind::checkpoint && kind != EntryKind::backup_restored &&
        kind != EntryKind::local_control_event && kind != EntryKind::lifecycle_event && kind != EntryKind::consumer_update && kind != EntryKind::projection_schedule && kind != EntryKind::consumer_retirement && kind != EntryKind::publication_channel && kind != EntryKind::local_authored && kind != EntryKind::source_subscription && kind != EntryKind::subscribed_source && kind != EntryKind::import_schedule && kind != EntryKind::outbox_administration && kind != EntryKind::action_administration && kind != EntryKind::result_review) {
        app_fail("JOURNAL_CORRUPT", "unbound mutation after runtime configuration activation");
    }
    if (kind == EntryKind::outbound_queued_with_policy) {
        apply_outbound_admission_locked(payload, replaying);
        return;
    }
    if (kind == EntryKind::schema_migrated) {
        datacube::Reader reader(payload, "journal schema migration");
        const auto from = reader.read_be32("source schema");
        const auto to = reader.read_be32("target schema");
        const auto at = reader.read_be64("migration time");
        reader.require_eof("schema migration");
        if (from != 1U || to != kCurrentStorageSchemaVersion || at == 0U ||
            !migrations_.empty()) {
            app_fail("JOURNAL_CORRUPT", "invalid storage schema migration");
        }
        migrations_.push_back(StorageMigration{
            .from_version = from,
            .to_version = to,
            .migrated_unix_ms = at,
        });
        storage_schema_version_ = to;
        return;
    }
    if (kind == EntryKind::checkpoint) {
        load_checkpoint(payload);
        return;
    }
    if (kind == EntryKind::backup_restored) {
        datacube::Reader reader(payload, "journal backup restore");
        const auto backup_id = read_digest(reader, "backup ID");
        const auto generation = read_text16(
            reader, 64U, "backup identity generation");
        const auto restored = reader.read_be64("backup restore time");
        reader.require_eof("backup restore");
        if (digest_is_zero(backup_id) || !valid_generation_id(generation) ||
            restored == 0U) {
            app_fail("JOURNAL_CORRUPT", "invalid backup restore account");
        }
        restored_backup_id_ = backup_id;
        restored_backup_generation_ = generation;
        restored_backup_unix_ms_ = restored;
        return;
    }
    const auto commit_inbound = [this](
        const EvidenceRecord& record,
        std::optional<AuthorizationAccount> authorization,
        std::shared_ptr<const LocalAuthorship> local = {},
        std::shared_ptr<const SubscribedSource> imported = {}) {
        const auto key = op_key(record.operation_id);
        if (inbound_index_.contains(key)) {
            app_fail("JOURNAL_CORRUPT", "duplicate inbound operation entry");
        }
        if (record.recipient != node_id_) {
            app_fail("JOURNAL_CORRUPT", "inbound recipient does not match node");
        }
        if (!imported && source_view_domains_.contains({record.issuer,record.scope})) {
            app_fail("JOURNAL_CORRUPT", "ordinary admission entered a reserved subscribed-source domain");
        }
        if (authorization.has_value()) {
            if (!valid_authorization_account(*authorization) ||
                authorization->decision != AuthorizationDecisionKind::admitted ||
                authorization->operation_id != record.operation_id ||
                authorization->record_digest != evidence_record_digest(record) ||
                authorization->peer_node != record.issuer ||
                authorization->operation_class != operation_class_for(record) ||
                authorization->resource != authorization_resource_for(record) ||
                !authorization->rule_digest.has_value()) {
                app_fail("JOURNAL_CORRUPT", "invalid authorized inbound account");
            }
        }
        if (record.corrects.has_value()) {
            const auto parent_key = op_key(*record.corrects);
            const auto parent_it = inbound_index_.find(parent_key);
            if (parent_it == inbound_index_.end()) {
                app_fail("JOURNAL_CORRUPT", "correction parent is absent");
            }
            if (correction_child_.contains(parent_key)) {
                app_fail("JOURNAL_CORRUPT", "correction parent has multiple children");
            }
            const auto& parent_entry = inbound_[parent_it->second];
            if (parent_entry.subscribed_source && !imported) { app_fail("JOURNAL_CORRUPT", "ordinary correction cannot modify imported source"); }
            if (parent_entry.local_authorship && !local) {
                app_fail("JOURNAL_CORRUPT", "network evidence cannot correct locally authored evidence");
            }
            const auto& parent = parent_entry.record;
            if (parent.issuer != record.issuer ||
                parent.recipient != record.recipient ||
                parent.scope != record.scope) {
                app_fail("JOURNAL_CORRUPT", "correction ancestry metadata mismatch");
            }
        }
        StoredInbound stored{
            .record = record,
            .record_digest = evidence_record_digest(record),
            .sequence = static_cast<std::uint64_t>(inbound_.size()) + 1U,
            .superseded_by = std::nullopt,
            .authorization = std::move(authorization),
            .local_authorship = std::move(local),
            .subscribed_source = std::move(imported),
        };
        const auto index = inbound_.size();
        inbound_.push_back(std::move(stored));
        inbound_index_.emplace(key, index);
        index_inbound(index);
        if (record.corrects.has_value()) {
            const auto parent_key = op_key(*record.corrects);
            correction_child_.emplace(parent_key, key);
            inbound_[inbound_index_.at(parent_key)].superseded_by =
                record.operation_id;
        }
    };

    if (kind == EntryKind::import_schedule) { apply_import_auto_event(payload); return; }
    if (kind == EntryKind::subscribed_source) {
        datacube::Reader reader(payload,"subscribed source admission");
        const auto account=decode_subscribed_source(reader);
        if(account.executor_uid&&!applying_import_auto_){app_fail("JOURNAL_CORRUPT","automatic admission without schedule transition");}
        const auto message=decode_application_message(reader.read_exact(reader.remaining(),"materialized record"));
        const auto* record=std::get_if<EvidenceRecord>(&message);
        if (!record) { app_fail("JOURNAL_CORRUPT","source import must be evidence"); }
        validate_subscribed_source_locked(*record,account,true);
        commit_inbound(*record,std::nullopt,{},std::make_shared<const SubscribedSource>(account));
        return;
    }
    if (kind == EntryKind::local_authored) {
        datacube::Reader reader(payload, "locally authored admission");
        const auto account = decode_local_authorship(reader);
        const auto message = decode_application_message(reader.read_exact(reader.remaining(), "local source record"));
        const auto* record = std::get_if<EvidenceRecord>(&message);
        if (record == nullptr) { app_fail("JOURNAL_CORRUPT", "local authored entry is not evidence"); }
        validate_local_authorship_locked(*record, account, true);
        commit_inbound(*record, std::nullopt, std::make_shared<const LocalAuthorship>(account));
        return;
    }
    if (kind == EntryKind::inbound) {
        const auto message = decode_application_message(payload);
        const auto* record = std::get_if<EvidenceRecord>(&message);
        if (record == nullptr) {
            app_fail("JOURNAL_CORRUPT", "inbound entry is not evidence");
        }
        commit_inbound(*record, std::nullopt);
        return;
    }
    if (kind == EntryKind::outbound_queued) {
        apply_outbound_record_locked(payload, replaying);
        return;
    }
    if (kind == EntryKind::outbound_receipt) {
        const auto message = decode_application_message(payload);
        const auto* receipt = std::get_if<DeliveryReceipt>(&message);
        if (receipt == nullptr) {
            app_fail("JOURNAL_CORRUPT", "receipt entry has wrong message kind");
        }
        const auto key = op_key(receipt->operation_id);
        const auto found = outbound_index_.find(key);
        if (found == outbound_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "receipt has no queued operation");
        }
        auto& outbound = outbound_[found->second];
        if (outbound.receipt.has_value()) {
            app_fail("JOURNAL_CORRUPT", "duplicate durable receipt entry");
        }
        if (outbound.delivery.has_value() &&
            (outbound.delivery->expired_unix_ms.has_value() ||
             outbound.delivery->cancelled_unix_ms.has_value() ||
             active_outbound_rejection(outbound).has_value())) {
            app_fail("JOURNAL_CORRUPT",
                "terminal operation has a later receipt");
        }
        if (receipt->recipient != outbound.record.recipient ||
            receipt->recorder != outbound.record.recipient ||
            receipt->record_digest != outbound.record_digest) {
            app_fail("JOURNAL_CORRUPT", "receipt does not bind queued record");
        }
        outbound.receipt = *receipt;
        if (outbound.delivery.has_value()) {
            outbound.delivery->last_error_code.clear();
            outbound.delivery->last_error_detail.clear();
        }
        index_outbound(found->second);
        return;
    }
    if (kind == EntryKind::recovery) {
        if (payload.size() != 16U) {
            app_fail("JOURNAL_CORRUPT", "recovery entry size mismatch");
        }
        const auto discarded = decode_u64(payload.first(8U));
        const auto prefix = decode_u64(payload.subspan(8U, 8U));
        if (discarded == 0U && replaying) {
            app_fail("JOURNAL_CORRUPT", "zero-byte recovery entry");
        }
        recoveries_.push_back(JournalRecovery{
            .discarded_tail_bytes = discarded,
            .valid_prefix_bytes = prefix,
        });
        return;
    }
    if (kind == EntryKind::outbound_policy) {
        if (active_source_validation_work) {
            ++active_source_validation_work->outbound_policy_decodes;
            active_source_validation_work->outbound_policy_bytes_decoded += payload.size();
        }
        datacube::Reader reader(payload, "journal outbound policy");
        const auto operation_id = read_digest(reader, "operation ID");
        OutboundPolicy policy{
            .created_unix_ms = reader.read_be64("created time"),
            .expires_unix_ms = reader.read_be64("expiry time"),
            .maximum_attempts = reader.read_be32("maximum attempts"),
            .initial_backoff_ms = reader.read_be32("initial backoff"),
            .maximum_backoff_ms = reader.read_be32("maximum backoff"),
            .peer_spki_sha256 = std::nullopt,
            .peer_generation = std::nullopt,
        };
        if (reader.remaining() >= 32U) {
            policy.peer_spki_sha256 = read_digest(reader, "peer SPKI SHA-256");
            if (reader.remaining() != 0U) {
                policy.peer_generation = read_text16(
                    reader, 64U, "peer key generation");
            }
        } else if (reader.remaining() != 0U) {
            app_fail("JOURNAL_CORRUPT", "outbound policy key binding size mismatch");
        }
        reader.require_eof("outbound policy");
        const auto found = outbound_index_.find(op_key(operation_id));
        if (found == outbound_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "outbound policy has no queued operation");
        }
        auto& outbound = outbound_[found->second];
        if (outbound.delivery.has_value()) {
            app_fail("JOURNAL_CORRUPT", "duplicate outbound policy entry");
        }
        if (outbound.receipt.has_value() ||
            policy.created_unix_ms == 0U ||
            policy.expires_unix_ms <= policy.created_unix_ms ||
            policy.maximum_attempts == 0U ||
            policy.initial_backoff_ms == 0U ||
            policy.maximum_backoff_ms < policy.initial_backoff_ms ||
            (policy.peer_spki_sha256.has_value() &&
             digest_is_zero(*policy.peer_spki_sha256)) ||
            (policy.peer_generation.has_value() &&
             !valid_generation_id(*policy.peer_generation)) ||
            (policy.peer_spki_sha256.has_value() !=
             policy.peer_generation.has_value()) ||
            (!replaying && (!policy.peer_spki_sha256.has_value() ||
                            !policy.peer_generation.has_value()))) {
            app_fail("JOURNAL_CORRUPT", "invalid outbound policy");
        }
        outbound.delivery = OutboundDeliveryState{
            .policy = policy,
            .attempts = 0U,
            .last_attempt_unix_ms = std::nullopt,
            .next_attempt_unix_ms = policy.created_unix_ms,
            .last_error_code = {},
            .last_error_detail = {},
            .expired_unix_ms = std::nullopt,
            .expiry_reason = {},
            .cancelled_unix_ms = std::nullopt,
            .cancellation_reason = {},
            .transitions = {},
        };
        index_outbound(found->second);
        return;
    }
    if (kind == EntryKind::outbound_attempt) {
        datacube::Reader reader(payload, "journal outbound attempt");
        const auto operation_id = read_digest(reader, "operation ID");
        const auto attempt = reader.read_be32("attempt number");
        const auto attempted = reader.read_be64("attempted time");
        const auto next = reader.read_be64("next attempt time");
        reader.require_eof("outbound attempt");
        const auto found = outbound_index_.find(op_key(operation_id));
        if (found == outbound_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "outbound attempt has no queued operation");
        }
        auto& outbound = outbound_[found->second];
        if (!outbound.delivery.has_value() || outbound.receipt.has_value() ||
            outbound.delivery->expired_unix_ms.has_value() ||
            outbound.delivery->cancelled_unix_ms.has_value() ||
            active_outbound_rejection(outbound).has_value() ||
            attempt != outbound.delivery->attempts + 1U ||
            attempt > outbound.delivery->policy.maximum_attempts ||
            attempted == 0U || next < attempted) {
            app_fail("JOURNAL_CORRUPT", "invalid outbound attempt transition");
        }
        outbound.delivery->attempts = attempt;
        outbound.delivery->last_attempt_unix_ms = attempted;
        outbound.delivery->next_attempt_unix_ms = next;
        outbound.delivery->last_error_code = "ATTEMPT_INTERRUPTED";
        outbound.delivery->last_error_detail =
            "attempt began but no durable outcome was recorded";
        index_outbound(found->second);
        return;
    }
    if (kind == EntryKind::outbound_failure) {
        datacube::Reader reader(payload, "journal outbound failure");
        const auto operation_id = read_digest(reader, "operation ID");
        const auto attempt = reader.read_be32("attempt number");
        const auto next = reader.read_be64("next attempt time");
        const auto code = read_text16(reader, 64U, "failure code");
        const auto detail = read_text16(reader, 512U, "failure detail");
        reader.require_eof("outbound failure");
        const auto found = outbound_index_.find(op_key(operation_id));
        if (found == outbound_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "outbound failure has no queued operation");
        }
        auto& outbound = outbound_[found->second];
        if (!outbound.delivery.has_value() || outbound.receipt.has_value() ||
            outbound.delivery->expired_unix_ms.has_value() ||
            outbound.delivery->cancelled_unix_ms.has_value() ||
            active_outbound_rejection(outbound).has_value() ||
            attempt == 0U || attempt != outbound.delivery->attempts ||
            next != outbound.delivery->next_attempt_unix_ms ||
            !valid_error_code(code)) {
            app_fail("JOURNAL_CORRUPT", "invalid outbound failure transition");
        }
        outbound.delivery->last_error_code = code;
        outbound.delivery->last_error_detail = detail;
        index_outbound(found->second);
        return;
    }
    if (kind == EntryKind::outbound_expired) {
        datacube::Reader reader(payload, "journal outbound expiry");
        const auto operation_id = read_digest(reader, "operation ID");
        const auto expired = reader.read_be64("expired time");
        const auto reason = read_text16(reader, 64U, "expiry reason");
        reader.require_eof("outbound expiry");
        const auto found = outbound_index_.find(op_key(operation_id));
        if (found == outbound_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "outbound expiry has no queued operation");
        }
        auto& outbound = outbound_[found->second];
        if (!outbound.delivery.has_value() || outbound.receipt.has_value() ||
            outbound.delivery->expired_unix_ms.has_value() ||
            outbound.delivery->cancelled_unix_ms.has_value() ||
            active_outbound_rejection(outbound).has_value() ||
            expired == 0U || !valid_error_code(reason)) {
            app_fail("JOURNAL_CORRUPT", "invalid outbound expiry transition");
        }
        outbound.delivery->expired_unix_ms = expired;
        outbound.delivery->expiry_reason = reason;
        outbound.delivery->last_error_code = reason;
        outbound.delivery->last_error_detail = "delivery obligation expired";
        index_outbound(found->second);
        return;
    }
    if (kind == EntryKind::outbound_rebound) {
        datacube::Reader reader(payload, "journal outbound rebind");
        const auto operation_id = read_digest(reader, "operation ID");
        if (action_result_operations_.contains(op_key(operation_id))) {
            app_fail("JOURNAL_CORRUPT", "action result cannot outlive its exact recipient-key binding");
        }
        for (const auto& [id, subscription] : source_subscriptions_) {
            static_cast<void>(id);
            if (std::any_of(subscription.deliveries.begin(), subscription.deliveries.end(),
                [&](const auto& d) { return d.operation == operation_id; })) {
                app_fail("JOURNAL_CORRUPT", "source disclosure cannot be rebound beyond its exact grant");
            }
        }
        const auto at = reader.read_be64("rebind time");
        const auto actor = read_text16(reader, 64U, "transition actor");
        if(actor.starts_with("CONDITIONAL_UID_")&&!applying_conditional_action_)app_fail("JOURNAL_CORRUPT","conditional transition lost its atomic account");
        const auto reason = read_text16(reader, 256U, "transition reason");
        const auto from_generation = read_text16(reader, 64U, "old generation");
        const auto from_pin = read_digest(reader, "old peer SPKI SHA-256");
        const auto to_generation = read_text16(reader, 64U, "new generation");
        const auto to_pin = read_digest(reader, "new peer SPKI SHA-256");
        reader.require_eof("outbound rebind");
        const auto found = outbound_index_.find(op_key(operation_id));
        if (found == outbound_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "outbound rebind has no queued operation");
        }
        auto& outbound = outbound_[found->second];
        if (!outbound.delivery.has_value() || outbound.receipt.has_value() ||
            outbound.delivery->expired_unix_ms.has_value() ||
            outbound.delivery->cancelled_unix_ms.has_value() || at == 0U ||
            !valid_transition_text(actor, 64U) ||
            !valid_transition_text(reason, 256U) ||
            !valid_generation_id(from_generation) ||
            !valid_generation_id(to_generation) ||
            digest_is_zero(from_pin) || digest_is_zero(to_pin) ||
            !outbound.delivery->policy.peer_generation.has_value() ||
            !outbound.delivery->policy.peer_spki_sha256.has_value() ||
            *outbound.delivery->policy.peer_generation != from_generation ||
            *outbound.delivery->policy.peer_spki_sha256 != from_pin ||
            (from_generation == to_generation && from_pin == to_pin)) {
            app_fail("JOURNAL_CORRUPT", "invalid outbound rebind transition");
        }
        const bool reopens_rejection =
            active_outbound_rejection(outbound).has_value();
        outbound.delivery->policy.peer_generation = to_generation;
        outbound.delivery->policy.peer_spki_sha256 = to_pin;
        outbound.delivery->next_attempt_unix_ms = at;
        if (reopens_rejection) {
            outbound.delivery->attempts = 0U;
            outbound.delivery->last_attempt_unix_ms.reset();
            outbound.delivery->last_error_code.clear();
            outbound.delivery->last_error_detail.clear();
        } else {
            outbound.delivery->last_error_code = "OBLIGATION_REBOUND";
            outbound.delivery->last_error_detail = reason;
        }
        outbound.delivery->transitions.push_back(OutboundTransition{
            .kind = OutboundTransitionKind::rebound,
            .unix_ms = at,
            .actor = actor,
            .reason = reason,
            .from_generation = from_generation,
            .from_spki_sha256 = from_pin,
            .to_generation = to_generation,
            .to_spki_sha256 = to_pin,
        });
        index_outbound(found->second);
        return;
    }
    if (kind == EntryKind::outbound_cancelled) {
        datacube::Reader reader(payload, "journal outbound cancellation");
        const auto operation_id = read_digest(reader, "operation ID");
        const auto at = reader.read_be64("cancellation time");
        const auto actor = read_text16(reader, 64U, "transition actor");
        if(actor.starts_with("CONDITIONAL_UID_")&&!applying_conditional_action_)app_fail("JOURNAL_CORRUPT","conditional transition lost its atomic account");
        const auto reason = read_text16(reader, 256U, "transition reason");
        const auto generation = read_text16(reader, 64U, "cancelled generation");
        const auto pin = read_digest(reader, "cancelled peer SPKI SHA-256");
        reader.require_eof("outbound cancellation");
        const auto found = outbound_index_.find(op_key(operation_id));
        if (found == outbound_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "outbound cancellation has no queued operation");
        }
        auto& outbound = outbound_[found->second];
        if (!outbound.delivery.has_value() || outbound.receipt.has_value() ||
            outbound.delivery->expired_unix_ms.has_value() ||
            outbound.delivery->cancelled_unix_ms.has_value() || at == 0U ||
            !valid_transition_text(actor, 64U) ||
            !valid_transition_text(reason, 256U) ||
            !valid_generation_id(generation) || digest_is_zero(pin) ||
            !outbound.delivery->policy.peer_generation.has_value() ||
            !outbound.delivery->policy.peer_spki_sha256.has_value() ||
            *outbound.delivery->policy.peer_generation != generation ||
            *outbound.delivery->policy.peer_spki_sha256 != pin) {
            app_fail("JOURNAL_CORRUPT", "invalid outbound cancellation transition");
        }
        outbound.delivery->cancelled_unix_ms = at;
        outbound.delivery->cancellation_reason = reason;
        outbound.delivery->last_error_code = "OBLIGATION_CANCELLED";
        outbound.delivery->last_error_detail = reason;
        outbound.delivery->transitions.push_back(OutboundTransition{
            .kind = OutboundTransitionKind::cancelled,
            .unix_ms = at,
            .actor = actor,
            .reason = reason,
            .from_generation = generation,
            .from_spki_sha256 = pin,
            .to_generation = std::nullopt,
            .to_spki_sha256 = std::nullopt,
        });
        index_outbound(found->second);
        return;
    }
    if (kind == EntryKind::outbound_rejected) {
        datacube::Reader reader(payload, "journal outbound rejection");
        const auto operation_id = read_digest(reader, "operation ID");
        const auto attempt = reader.read_be32("attempt number");
        const auto at = reader.read_be64("rejection time");
        const auto code = read_text16(reader, 64U, "rejection code");
        const auto detail = read_text16(reader, 256U, "rejection detail");
        const auto generation = read_text16(reader, 64U, "rejection generation");
        const auto pin = read_digest(reader, "rejection peer SPKI SHA-256");
        const auto policy_digest = read_digest(reader, "rejection policy digest");
        reader.require_eof("outbound rejection");
        const auto found = outbound_index_.find(op_key(operation_id));
        if (found == outbound_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "outbound rejection has no queued operation");
        }
        auto& outbound = outbound_[found->second];
        if (!outbound.delivery.has_value() || outbound.receipt.has_value() ||
            outbound.delivery->expired_unix_ms.has_value() ||
            outbound.delivery->cancelled_unix_ms.has_value() ||
            active_outbound_rejection(outbound).has_value() ||
            attempt == 0U || attempt != outbound.delivery->attempts ||
            !outbound.delivery->last_attempt_unix_ms.has_value() ||
            at < *outbound.delivery->last_attempt_unix_ms ||
            !authenticated_peer_error_is_terminal(code) ||
            !valid_transition_text(detail, 256U) ||
            !valid_generation_id(generation) || digest_is_zero(pin) ||
            digest_is_zero(policy_digest) ||
            !outbound.delivery->policy.peer_generation.has_value() ||
            !outbound.delivery->policy.peer_spki_sha256.has_value() ||
            *outbound.delivery->policy.peer_generation != generation ||
            *outbound.delivery->policy.peer_spki_sha256 != pin ||
            outbound_policy_digest(outbound.delivery->policy) != policy_digest ||
            outbound.delivery->last_error_code != "ATTEMPT_INTERRUPTED") {
            app_fail("JOURNAL_CORRUPT", "invalid outbound rejection transition");
        }
        outbound.delivery->last_error_code = code;
        outbound.delivery->last_error_detail = detail;
        outbound.delivery->transitions.push_back(OutboundTransition{
            .kind = OutboundTransitionKind::rejected,
            .unix_ms = at,
            .actor = code,
            .reason = detail,
            .from_generation = generation,
            .from_spki_sha256 = pin,
            .to_generation = std::nullopt,
            .to_spki_sha256 = policy_digest,
        });
        index_outbound(found->second);
        return;
    }
    if (kind == EntryKind::outbound_retried) {
        datacube::Reader reader(payload, "journal outbound retry");
        const auto operation_id = read_digest(reader, "operation ID");
        const auto at = reader.read_be64("retry time");
        const auto actor = read_text16(reader, 64U, "transition actor");
        if(actor.starts_with("CONDITIONAL_UID_")&&!applying_conditional_action_)app_fail("JOURNAL_CORRUPT","conditional transition lost its atomic account");
        const auto reason = read_text16(reader, 256U, "transition reason");
        const auto generation = read_text16(reader, 64U, "retried generation");
        const auto pin = read_digest(reader, "retried peer SPKI SHA-256");
        reader.require_eof("outbound retry");
        const auto found = outbound_index_.find(op_key(operation_id));
        if (found == outbound_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "outbound retry has no queued operation");
        }
        auto& outbound = outbound_[found->second];
        const auto rejection = active_outbound_rejection(outbound);
        if (!outbound.delivery.has_value() || outbound.receipt.has_value() ||
            outbound.delivery->expired_unix_ms.has_value() ||
            outbound.delivery->cancelled_unix_ms.has_value() ||
            !rejection.has_value() || at == 0U ||
            !valid_transition_text(actor, 64U) ||
            !valid_transition_text(reason, 256U) ||
            !valid_generation_id(generation) || digest_is_zero(pin) ||
            !outbound.delivery->policy.peer_generation.has_value() ||
            !outbound.delivery->policy.peer_spki_sha256.has_value() ||
            *outbound.delivery->policy.peer_generation != generation ||
            *outbound.delivery->policy.peer_spki_sha256 != pin ||
            rejection->peer_generation != generation ||
            rejection->peer_spki_sha256 != pin) {
            app_fail("JOURNAL_CORRUPT", "invalid outbound retry transition");
        }
        outbound.delivery->attempts = 0U;
        outbound.delivery->last_attempt_unix_ms.reset();
        outbound.delivery->next_attempt_unix_ms = at;
        outbound.delivery->last_error_code.clear();
        outbound.delivery->last_error_detail.clear();
        outbound.delivery->transitions.push_back(OutboundTransition{
            .kind = OutboundTransitionKind::retried,
            .unix_ms = at,
            .actor = actor,
            .reason = reason,
            .from_generation = generation,
            .from_spki_sha256 = pin,
            .to_generation = generation,
            .to_spki_sha256 = pin,
        });
        index_outbound(found->second);
        return;
    }
    if (kind == EntryKind::inbound_authorized) {
        datacube::Reader reader(payload, "journal authorized inbound");
        auto account = read_authorization_account(reader);
        const auto action_marker = reader.read_u8("authorized action marker");
        if (action_marker > 3U) {
            app_fail("JOURNAL_CORRUPT", "invalid authorized action marker");
        }
        std::optional<StoredAction> action;
        std::optional<ActionResultBinding> action_result;
        if (action_marker >= 1U) {
            const auto amount = reader.read_be64("action amount");
            const auto admitted = reader.read_be64("action admitted time");
            const auto not_before = reader.read_be64("action not-before time");
            const auto expires = reader.read_be64("action expiry time");
            ActionLimits limits{
                .counter_budget = reader.read_be64("action counter budget"),
                .maximum_increment = reader.read_be64("action maximum increment"),
                .maximum_defer_ms = reader.read_be64("action maximum defer"),
                .expiry_ms = reader.read_be64("action expiry interval"),
            };
            const auto rule_digest = read_digest(reader, "action rule digest");
            action = StoredAction{
                .action_id = account.operation_id,
                .record_digest = account.record_digest,
                .issuer = account.peer_node,
                .peer_generation = account.peer_generation,
                .queue_sequence = static_cast<std::uint64_t>(actions_.size()) + 1U,
                .amount = amount,
                .admitted_unix_ms = admitted,
                .not_before_unix_ms = not_before,
                .expires_unix_ms = expires,
                .limits = limits,
                .policy_digest = account.policy_digest,
                .rule_digest = rule_digest,
                .attempts = 0U,
                .last_started_unix_ms = std::nullopt,
                .completed_unix_ms = std::nullopt,
                .cancelled_unix_ms = std::nullopt,
                .expired_unix_ms = std::nullopt,
                .counter_before = std::nullopt,
                .counter_after = std::nullopt,
                .receipt_digest = std::nullopt,
                .cancellation_reason = {},
                .expiry_reason = {},
                .last_error_code = {},
            };
            if (action_marker >= 2U) {
                action_result = read_action_result_binding(reader);
                if (action_marker == 3U) {
                    action_result->reserved_payload_bytes = reader.read_be64("future result payload capacity");
                    if (action_result->reserved_payload_bytes == 0U) {
                        app_fail("JOURNAL_CORRUPT", "empty future result reservation");
                    }
                }
            }
        }
        const auto encoded_size = reader.read_be32("authorized application size");
        const auto encoded = reader.read_exact(
            encoded_size, "authorized application message");
        reader.require_eof("authorized inbound");
        const auto message = decode_application_message(encoded);
        const auto* record = std::get_if<EvidenceRecord>(&message);
        if (record == nullptr || account.operation_id != record->operation_id ||
            account.record_digest != evidence_record_digest(*record)) {
            app_fail("JOURNAL_CORRUPT", "authorized inbound record binding mismatch");
        }
        if (action.has_value()) {
            const auto request = decode_counter_add_request(record->payload);
            if (!is_counter_add_record(*record) || record->corrects.has_value() ||
                account.operation_class != AuthorizedOperationClass::counter_action ||
                account.resource != "counter.add" ||
                !account.rule_digest.has_value() ||
                action->rule_digest != *account.rule_digest ||
                action->amount != request.amount ||
                action->admitted_unix_ms != account.decided_unix_ms ||
                action->amount == 0U ||
                action->amount > action->limits.maximum_increment ||
                request.defer_ms > action->limits.maximum_defer_ms ||
                action->not_before_unix_ms < action->admitted_unix_ms ||
                action->expires_unix_ms <= action->admitted_unix_ms ||
                action->limits.expiry_ms == 0U ||
                action->expires_unix_ms - action->admitted_unix_ms !=
                    action->limits.expiry_ms ||
                action->not_before_unix_ms - action->admitted_unix_ms !=
                    request.defer_ms ||
                action_index_.contains(op_key(action->action_id)) ||
                action->limits.maximum_increment > action->limits.counter_budget ||
                action_counter_value_ > action->limits.counter_budget ||
                action_reserved_amount_ >
                    action->limits.counter_budget - action_counter_value_ ||
                action->amount > action->limits.counter_budget -
                    action_counter_value_ - action_reserved_amount_) {
                app_fail("JOURNAL_CORRUPT", "invalid authorized action admission");
            }
            if (action_result.has_value() &&
                (!valid_action_result_binding(*action_result) ||
                 action_result->peer_generation != account.peer_generation ||
                 action_result->configuration_event > configuration_events_.size() ||
                 configuration_events_[static_cast<std::size_t>(
                     action_result->configuration_event - 1U)].kind == "REJECTED" ||
                 action_results_.contains(op_key(action->action_id)))) {
                app_fail("JOURNAL_CORRUPT", "invalid action-result admission binding");
            }
        } else if (account.operation_class != AuthorizedOperationClass::evidence ||
                   is_counter_add_record(*record)) {
            app_fail("JOURNAL_CORRUPT", "authorized evidence/action marker mismatch");
        }
        if (action_result.has_value()) {
            validate_action_result_binding_locked(*action, *action_result);
            if (action_result->reserved_payload_bytes != 0U) {
                require_outbox_capacity(queue_limits_, pending_capacity_, record->issuer,
                    action_result->reserved_payload_bytes, future_result_capacity_);
            }
        }
        commit_inbound(*record, account);
        if (action.has_value()) {
            const auto index = actions_.size();
            action_reserved_amount_ += action->amount;
            actions_.push_back(std::move(*action));
            action_index_.emplace(op_key(record->operation_id), index);
            index_action(index);
            if (action_result.has_value()) {
                action_results_.emplace(op_key(record->operation_id),
                    ActionResultState{
                        .binding = std::move(*action_result),
                        .outcome = std::nullopt,
                        .operation_id = std::nullopt,
                        .record_digest = std::nullopt,
                    });
                index_action_result_reservation_locked(index);
            }
        }
        return;
    }
    if (kind == EntryKind::authorization_denied) {
        datacube::Reader reader(payload, "journal authorization denial");
        auto account = read_authorization_account(reader);
        AuthorizationDenial denial{
            .authorization = account,
            .issuer = read_text16(reader, 64U, "denied issuer"),
            .recipient = read_text16(reader, 64U, "denied recipient"),
            .scope = read_text16(reader, 128U, "denied scope"),
        };
        reader.require_eof("authorization denial");
        const auto key = authorization_denial_key(account);
        if (!valid_authorization_account(account) ||
            account.decision != AuthorizationDecisionKind::denied ||
            account.peer_node != denial.issuer ||
            denial.recipient != node_id_ || !valid_scope(denial.scope) ||
            authorization_denial_index_.contains(key)) {
            app_fail("JOURNAL_CORRUPT", "invalid authorization denial account");
        }
        const auto index = authorization_denials_.size();
        authorization_denials_.push_back(std::move(denial));
        authorization_denial_index_.emplace(key, index);
        return;
    }
    if (kind == EntryKind::action_started) {
        datacube::Reader reader(payload, "journal action start");
        const auto action_id = read_digest(reader, "action ID");
        const auto attempt = reader.read_be32("action attempt");
        const auto started = reader.read_be64("action start time");
        reader.require_eof("action start");
        const auto found = action_index_.find(op_key(action_id));
        if (found == action_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "action start has no admitted action");
        }
        auto& action = actions_[found->second];
        if (!action_is_pending(action) || attempt != action.attempts + 1U ||
            started == 0U || started < action.admitted_unix_ms) {
            app_fail("JOURNAL_CORRUPT", "invalid action start transition");
        }
        action.attempts = attempt;
        action.last_started_unix_ms = started;
        action.last_error_code = "ACTION_ATTEMPT_INTERRUPTED";
        index_action(found->second);
        return;
    }
    if (kind == EntryKind::action_completed) {
        datacube::Reader reader(payload, "journal action completion");
        const auto action_id = read_digest(reader, "action ID");
        const auto attempt = reader.read_be32("action attempt");
        const auto completed = reader.read_be64("action completion time");
        const auto before = reader.read_be64("counter before");
        const auto after = reader.read_be64("counter after");
        const auto receipt = read_digest(reader, "action receipt digest");
        reader.require_eof("action completion");
        const auto found = action_index_.find(op_key(action_id));
        if (found == action_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "action completion has no admitted action");
        }
        auto& action = actions_[found->second];
        if (action_results_.contains(op_key(action_id)) &&
            !applying_action_result_) {
            app_fail("JOURNAL_CORRUPT",
                "result-bound action completion lost its atomic result");
        }
        if (!action_is_pending(action) || !action.last_started_unix_ms.has_value() ||
            attempt == 0U || attempt != action.attempts || completed == 0U ||
            completed < *action.last_started_unix_ms ||
            before != action_counter_value_ ||
            action.amount > std::numeric_limits<std::uint64_t>::max() - before ||
            after != before + action.amount ||
            after > action.limits.counter_budget ||
            action_reserved_amount_ < action.amount ||
            receipt != action_receipt_digest(
                action_id, attempt, completed, before, after)) {
            app_fail("JOURNAL_CORRUPT", "invalid action completion transition");
        }
        action_counter_value_ = after;
        action_reserved_amount_ -= action.amount;
        action.completed_unix_ms = completed;
        action.counter_before = before;
        action.counter_after = after;
        action.receipt_digest = receipt;
        action.last_error_code.clear();
        index_action(found->second);
        return;
    }
    if (kind == EntryKind::action_cancelled || kind == EntryKind::action_expired) {
        datacube::Reader reader(payload,
            kind == EntryKind::action_cancelled ?
                "journal action cancellation" : "journal action expiry");
        const auto action_id = read_digest(reader, "action ID");
        const auto at = reader.read_be64("action terminal time");
        const auto reason = read_text16(reader, 256U, "action terminal reason");
        reader.require_eof("action terminal transition");
        const auto found = action_index_.find(op_key(action_id));
        if (found == action_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "terminal action has no admitted action");
        }
        auto& action = actions_[found->second];
        if (action_results_.contains(op_key(action_id)) &&
            !applying_action_result_) {
            app_fail("JOURNAL_CORRUPT",
                "result-bound action terminal transition lost its atomic result");
        }
        if (!action_is_pending(action) || at == 0U ||
            !valid_transition_text(reason, 256U) ||
            action_reserved_amount_ < action.amount) {
            app_fail("JOURNAL_CORRUPT", "invalid terminal action transition");
        }
        action_reserved_amount_ -= action.amount;
        if (kind == EntryKind::action_cancelled) {
            action.cancelled_unix_ms = at;
            action.cancellation_reason = reason;
            action.last_error_code = applying_action_administration_ ?
                "ACTION_CANCELLED_CONDITIONAL" : "ACTION_CANCELLED";
        } else {
            action.expired_unix_ms = at;
            action.expiry_reason = reason;
            action.last_error_code = "ACTION_EXPIRED";
        }
        index_action(found->second);
        return;
    }
    app_fail("JOURNAL_CORRUPT", "unknown journal entry kind");
}

std::uint64_t NodeState::configuration_event_reference(
    const std::string_view generation, const datacube::Digest32& digest,
    const std::string_view canonical) const {
    std::lock_guard<std::mutex> lock(mutex_);
    for (std::size_t index = configuration_events_.size(); index > 0U; --index) {
        const auto& event = configuration_events_[index - 1U];
        if (event.kind != "REJECTED" && event.generation == generation &&
            event.digest == digest && event.canonical == canonical) {
            return static_cast<std::uint64_t>(index);
        }
    }
    app_fail("CONFIG_PROVENANCE_MISSING", "active local policy has no accepted configuration event");
}

datacube::Octets NodeState::canonical_logical_state_locked() const {
    datacube::Octets out;
    datacube::append_octets(out, kLogicalStateMagic);
    datacube::append_be32(out, storage_schema_version_);
    append_text16(out, node_id_, 64U, "checkpoint node ID");

    append_count32(out, migrations_.size(), "checkpoint migration count");
    for (const auto& migration : migrations_) {
        datacube::append_be32(out, migration.from_version);
        datacube::append_be32(out, migration.to_version);
        datacube::append_be64(out, migration.migrated_unix_ms);
    }

    append_count32(out, inbound_.size(), "checkpoint inbound count");
    for (const auto& entry : inbound_) {
        append_application(out, ApplicationMessage(entry.record),
            "checkpoint inbound application");
        datacube::append_u8(out, entry.subscribed_source ? 3U : (entry.local_authorship ? 2U : (entry.authorization ? 1U : 0U)));
        if (entry.authorization) { append_authorization_account(out, *entry.authorization); }
        if (entry.local_authorship) { datacube::append_octets(out, encode_local_authorship(*entry.local_authorship)); }
        if (entry.subscribed_source) { datacube::append_octets(out, encode_subscribed_source(*entry.subscribed_source)); }
    }

    append_count32(out, outbound_.size(), "checkpoint outbound count");
    for (const auto& entry : outbound_) {
        append_application(out, ApplicationMessage(entry.record),
            "checkpoint outbound application");
        datacube::append_u8(out, entry.receipt.has_value() ? 1U : 0U);
        if (entry.receipt.has_value()) {
            append_application(out, ApplicationMessage(*entry.receipt),
                "checkpoint outbound receipt");
        }
        datacube::append_u8(out, entry.delivery.has_value() ? 1U : 0U);
        if (entry.delivery.has_value()) {
            append_outbound_delivery_state(out, *entry.delivery);
        }
    }

    append_count32(out, authorization_denials_.size(),
        "checkpoint authorization denial count");
    for (const auto& denial : authorization_denials_) {
        append_authorization_account(out, denial.authorization);
        append_text16(out, denial.issuer, 64U, "checkpoint denied issuer");
        append_text16(out, denial.recipient, 64U,
            "checkpoint denied recipient");
        append_text16(out, denial.scope, 128U, "checkpoint denied scope");
    }

    append_count32(out, actions_.size(), "checkpoint action count");
    for (const auto& action : actions_) {
        append_action_state(out, action);
    }
    datacube::append_be64(out, action_counter_value_);
    datacube::append_be64(out, action_reserved_amount_);

    append_count32(out, recoveries_.size(), "checkpoint recovery count");
    for (const auto& recovery : recoveries_) {
        datacube::append_be64(out, recovery.discarded_tail_bytes);
        datacube::append_be64(out, recovery.valid_prefix_bytes);
    }
    if (!configuration_events_.empty()) {
        datacube::append_text(out, "NRC1");
        append_count32(out, configuration_events_.size(), "configuration count");
        for (const auto& event : configuration_events_) {
            datacube::append_octets(out, runtime_event_payload(event));
        }
        append_count32(out, configuration_bindings_.size(), "configuration binding count");
        for (const auto& binding : configuration_bindings_) { append_runtime_binding(out, binding); }
    }
    if (!local_control_events_.empty() || !lifecycle_events_.empty() || !consumers_.empty() || !source_subscriptions_.empty()) {
        datacube::append_text(out, "NLC1");
        append_count32(out, local_control_events_.size(), "local control event count");
        for (const auto& event : local_control_events_) {
            datacube::append_octets(out, local_control_event_payload(event));
        }
        append_count32(out, lifecycle_events_.size(), "lifecycle event count");
        for (const auto& event : lifecycle_events_) {
            datacube::append_octets(out, lifecycle_event_payload(event));
        }
    }
    if (!consumers_.empty()) {
        datacube::append_text(out, std::any_of(consumers_.begin(),consumers_.end(),[](const auto& p){return p.second.retirement.has_value();})?"NDC2":"NDC1");
        append_count32(out, consumers_.size(), "consumer count");
        for (const auto& [name, value] : consumers_) {
            static_cast<void>(name);
            const auto encoded = encode_consumer(value);
            datacube::append_be32(out, static_cast<std::uint32_t>(encoded.size()));
            datacube::append_octets(out, encoded);
        }
    }
    if (!projection_schedules_.empty()) {
        datacube::append_text(out,"NAS1");append_count32(out,projection_schedules_.size(),"schedule count");
        for(const auto& [key,value]:projection_schedules_){static_cast<void>(key);const auto bytes=encode_projection_schedule(value);
            datacube::append_be32(out,static_cast<std::uint32_t>(bytes.size()));datacube::append_octets(out,bytes);}
    }
    if (!publication_channels_.empty()) {
        datacube::append_text(out, "NPH1");
        append_count32(out, publication_channels_.size(), "publication channel count");
        for (const auto& [key, value] : publication_channels_) {
            static_cast<void>(key);
            const auto encoded = encode_publication_channel(value);
            datacube::append_be32(out, static_cast<std::uint32_t>(encoded.size()));
            datacube::append_octets(out, encoded);
        }
    }
    if (!source_subscriptions_.empty()) {
        datacube::append_text(out, "NSB1");
        append_count32(out, source_subscriptions_.size(), "source subscription count");
        for (const auto& [id, value] : source_subscriptions_) {
            static_cast<void>(id); const auto encoded = encode_source_subscription(value);
            datacube::append_be32(out, static_cast<std::uint32_t>(encoded.size()));
            datacube::append_octets(out, encoded);
        }
    }
    if(!import_schedules_.empty()) {
        datacube::append_text(out,"NIS1");append_count32(out,import_schedules_.size(),"import schedules");
        for(const auto& [id,value]:import_schedules_){static_cast<void>(id);const auto b=encode_import_auto_history(value);datacube::append_be32(out,static_cast<std::uint32_t>(b.size()));datacube::append_octets(out,b);}
    }
    if(!outbox_administration_.empty()) {
        datacube::append_text(out,"NOA2");append_count32(out,outbox_administration_.size(),"conditional receipts");
        for(const auto& record:outbox_administration_){const auto bytes=encode_outbox_admin_record(record);datacube::append_be32(out,static_cast<std::uint32_t>(bytes.size()));datacube::append_octets(out,bytes);}
    }
    if(!action_administration_.empty()) {
        datacube::append_text(out,"NAA1");append_count32(out,action_administration_.size(),"conditional action receipts");
        for(const auto& record:action_administration_){const auto bytes=encode_action_admin_record(record);datacube::append_be32(out,static_cast<std::uint32_t>(bytes.size()));datacube::append_octets(out,bytes);}
    }
    if (!action_results_.empty()) {
        const bool reserved = std::any_of(action_results_.begin(), action_results_.end(),
            [](const auto& pair) { return pair.second.binding.reserved_payload_bytes != 0U; });
        datacube::append_text(out, reserved ? "NRA2" : "NRA1");
        append_count32(out, action_results_.size(), "action-result bindings");
        for (const auto& [key, result] : action_results_) {
            const auto action = action_index_.find(key);
            if (action == action_index_.end()) {
                app_fail("JOURNAL_CORRUPT", "action-result binding lacks action");
            }
            append_digest(out, actions_.at(action->second).action_id);
            append_action_result_binding(out, result.binding);
            if (reserved) { datacube::append_be64(out, result.binding.reserved_payload_bytes); }
            datacube::append_u8(out, result.outcome.has_value() ? 1U : 0U);
            if (result.outcome.has_value()) {
                datacube::append_u8(out,
                    static_cast<std::uint8_t>(*result.outcome));
                if (!result.operation_id.has_value() ||
                    !result.record_digest.has_value()) {
                    app_fail("JOURNAL_CORRUPT",
                        "terminal action result lacks outbox binding");
                }
                append_digest(out, *result.operation_id);
                append_digest(out, *result.record_digest);
            }
        }
    }

    if (!result_reviews_.empty()) {
        datacube::append_text(out, "NRV1");
        append_count32(out, result_reviews_.size(), "result reviews");
        for (const auto& review : result_reviews_) {
            const auto bytes = encode_result_review_record(review);
            datacube::append_be32(out, static_cast<std::uint32_t>(bytes.size()));
            datacube::append_octets(out, bytes);
        }
    }
    if (!custody_registry_.events().empty()) {
        datacube::append_text(out, "NCU1");
        append_count32(out, custody_registry_.events().size(),
            "durable custody events");
        for (const auto& event : custody_registry_.events()) {
            datacube::append_be32(out,
                static_cast<std::uint32_t>(event.size()));
            datacube::append_octets(out, event);
        }
    }
    return out;
}

void NodeState::validate_action_result_binding_locked(const StoredAction& action,
    const ActionResultBinding& binding) const {
    if (!valid_action_result_binding(binding) || binding.configuration_event > configuration_events_.size()) {
        app_fail("JOURNAL_CORRUPT", "invalid result-capacity policy binding");
    }
    const auto& event = configuration_events_.at(static_cast<std::size_t>(binding.configuration_event - 1U));
    if (event.kind == "REJECTED") app_fail("JOURNAL_CORRUPT", "result binding uses rejected configuration");
    const auto historical = parse_runtime_config(event.canonical, "/action-result-binding", IdentityFileValidation::deferred);
    const auto* rule = find_action_result_rule(historical.action_results, action.issuer, action.peer_generation, "counter.add");
    const auto* peer = find_peer(historical, action.issuer);
    if (historical.format_version < 18U || !rule || !peer ||
        historical.action_results.digest != binding.policy_digest || rule->digest != binding.rule_digest ||
        rule->result_scope != binding.result_scope || action.peer_generation != binding.peer_generation ||
        peer->active_generation != binding.peer_generation || peer->active_spki_sha256 != binding.peer_spki_sha256 ||
        peer->delivery.maximum_attempts != binding.maximum_attempts ||
        peer->delivery.initial_backoff_ms != binding.initial_backoff_ms ||
        peer->delivery.maximum_backoff_ms != binding.maximum_backoff_ms ||
        peer->delivery.expiry_ms != binding.delivery_expiry_ms) {
        app_fail("JOURNAL_CORRUPT", "result binding differs from accepted admission policy");
    }
}

void NodeState::index_action_result_reservation_locked(const std::size_t index) {
    const auto& action = actions_.at(index);
    const auto result = action_results_.find(op_key(action.action_id));
    if (result == action_results_.end() || result->second.binding.reserved_payload_bytes == 0U) return;
    const auto bytes = result->second.binding.reserved_payload_bytes;
    if (bytes != action_result_reservation_bytes(result->second.binding)) {
        app_fail("JOURNAL_CORRUPT", "noncanonical result reservation size");
    }
    static_cast<void>(future_result_capacity_.update(index, action.issuer, bytes, action_is_pending(action)));
}

QueueUsage NodeState::queue_usage_locked() const {
    auto usage = pending_capacity_.snapshot();
    const auto future = future_result_capacity_.snapshot();
    usage.future_result_records = future.pending_records;
    usage.future_result_payload_bytes = future.pending_payload_bytes;
    for (const auto& item : future.peers) {
        auto found = std::lower_bound(usage.peers.begin(), usage.peers.end(), item.peer,
            [](const auto& entry, const auto& peer) { return entry.peer < peer; });
        if (found == usage.peers.end() || found->peer != item.peer) {
            found = usage.peers.insert(found, PeerQueueUsage{.peer = item.peer});
        }
        found->future_result_records = item.pending_records;
        found->future_result_payload_bytes = item.pending_payload_bytes;
    }
    return usage;
}

QueueUsage NodeState::pending_queue_usage() const {
    std::lock_guard<std::mutex> lock(mutex_);
    if (poisoned_) app_fail("STATE_RESTART_REQUIRED", "writer is poisoned; restart required");
    return queue_usage_locked();
}

StateSnapshot NodeState::snapshot_locked() const {
    const auto logical = canonical_logical_state_locked();
    if (active_submission_work) {
        ++active_submission_work->snapshot_calls;
        active_submission_work->snapshot_logical_bytes += logical.size();
        for (const auto& entry : inbound_) active_submission_work->snapshot_evidence_payload_bytes += entry.record.payload.size();
        for (const auto& entry : outbound_) active_submission_work->snapshot_evidence_payload_bytes += entry.record.payload.size();
    }
    return StateSnapshot{
        .authentication = authentication_,
        .node_id = node_id_,
        .state_directory = state_directory_,
        .storage_schema_version = storage_schema_version_,
        .journal_bytes = journal_bytes_,
        .maintenance_generation = maintenance_generation_,
        .last_compaction_unix_ms = last_compaction_unix_ms_,
        .last_compaction_before_bytes = last_compaction_before_bytes_,
        .last_compaction_after_bytes = last_compaction_after_bytes_,
        .last_compaction_retained_records = last_compaction_retained_records_,
        .logical_state_digest = logical_state_digest_for(logical),
        .restored_backup_id = restored_backup_id_,
        .restored_backup_generation = restored_backup_generation_,
        .restored_backup_unix_ms = restored_backup_unix_ms_,
        .inbound = inbound_,
        .outbound = outbound_,
        .queue_limits = queue_limits_,
        .queue_usage = queue_usage_locked(),
        .authorization_denials = authorization_denials_,
        .actions = actions_,
        .action_counter_value = action_counter_value_,
        .action_reserved_amount = action_reserved_amount_,
        .recoveries = recoveries_,
        .migrations = migrations_,
        .configuration_events = configuration_events_,
        .configuration_bindings = configuration_bindings_,
        .local_control_events = local_control_events_,
        .lifecycle_events = lifecycle_events_,
        .consumers = [&]() { std::vector<DurableConsumer> values;
            for (const auto& [name, value] : consumers_) { static_cast<void>(name); values.push_back(value); }
            return values; }(),
        .projection_schedules = [&]() {std::vector<ProjectionSchedule> values;
            for(const auto& [key,value]:projection_schedules_){static_cast<void>(key);values.push_back(value);}return values;}(),
        .import_schedules = [&]() {std::vector<ImportAutoState> values;for(const auto& [id,value]:import_schedules_){static_cast<void>(id);values.push_back(value);}return values;}(),
        .source_subscriptions = [&]() { std::vector<SourceSubscription> values;
            for (const auto& [id, value] : source_subscriptions_) { static_cast<void>(id); values.push_back(value); }
            return values; }(),
        .outbox_admin_accounts = [&]() {std::vector<std::string> values;for(const auto& a:outbox_administration_)values.push_back(outbox_admin_record_json(a));return values;}(),
        .action_admin_accounts = [&]() {std::vector<std::string> values;for(const auto& a:action_administration_)values.push_back(action_admin_record_json(a));return values;}(),
        .publication_channels = [&]() { std::vector<PublicationChannel> values;
            for (const auto& [key, value] : publication_channels_) {
                static_cast<void>(key); values.push_back(value);
            }
            return values; }(),
        .custody_cases = custody_registry_.cases(),
    };
}


namespace {
// Accepted transition kinds either set rejection or clear it. The last
// validated transition completely determines the active rejection; historical
// detail hashes are not recomputed merely to render bounded runtime metadata.
std::optional<OutboundRejection> runtime_final_rejection(
    const StoredOutbound& entry) {
    if (!entry.delivery.has_value() || entry.delivery->transitions.empty()) {
        return std::nullopt;
    }
    std::optional<OutboundRejection> active;
    {
        const auto& transition = entry.delivery->transitions.back();
        if (transition.kind == OutboundTransitionKind::rejected) {
            if (!transition.to_spki_sha256.has_value()) {
                return std::nullopt;
            }
            datacube::Octets detail_material;
            detail_material.reserve(
                kOutboundRejectionDetailDigestDomain.size() + 1U +
                transition.reason.size());
            datacube::append_text(
                detail_material, kOutboundRejectionDetailDigestDomain);
            datacube::append_u8(detail_material, 0U);
            datacube::append_text(detail_material, transition.reason);
            active = OutboundRejection{
                .rejected_unix_ms = transition.unix_ms,
                .code = transition.actor,
                .detail = transition.reason,
                .detail_digest = datacube::sha256(detail_material),
                .peer_generation = transition.from_generation,
                .peer_spki_sha256 = transition.from_spki_sha256,
                .policy_digest = *transition.to_spki_sha256,
            };
        } else if (transition.kind == OutboundTransitionKind::retried ||
                   transition.kind == OutboundTransitionKind::rebound ||
                   transition.kind == OutboundTransitionKind::cancelled) {
            active.reset();
        }
    }
    return active;
}

const PeerKeyGeneration* runtime_bound_generation(const RuntimeConfig& config, const StoredOutbound& entry) {
    if (!entry.delivery || !entry.delivery->policy.peer_generation || !entry.delivery->policy.peer_spki_sha256) return nullptr;
    const auto* key = find_peer_generation(config, entry.record.recipient, *entry.delivery->policy.peer_generation);
    return key && key->spki_sha256 == *entry.delivery->policy.peer_spki_sha256 ? key : nullptr;
}
}
std::string NodeState::live_state_head_json() const {
    // Appends, semantic application, and compaction hold this same mutex.
    // Refuse a partially applied/failed writer, even if it has a durable root.
    std::lock_guard<std::mutex> lock(mutex_);
    if (poisoned_) app_fail("STATE_RESTART_REQUIRED", "writer is poisoned; restart required");
    return state_head_observation_json_locked(false);
}

std::string NodeState::seal_terminal_state_head_json() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (poisoned_) app_fail("STATE_RESTART_REQUIRED", "writer is poisoned; restart required");
    if (terminal_sealed_) app_fail("STATE_TERMINAL", "terminal state has already been sealed");
    auto result = state_head_observation_json_locked(true);
    terminal_sealed_ = true;
    return result;
}

std::string NodeState::state_head_observation_json_locked(const bool terminal) const {
    std::string out = "{\"format\":" + json_string(terminal ?
        "NATRAV_OVERLAY_TERMINAL_STATE_HEAD_V1" : "NATRAV_OVERLAY_LIVE_STATE_HEAD_V1") +
        ",\"ok\":true,\"node\":" + json_string(node_id_) +
        ",\"mode\":" + json_string(authentication_ ? "HMAC_SHA256_CHAIN_V1" : "UNKEYED") +
        ",\"journal_bytes\":" + std::to_string(journal_bytes_) +
        ",\"state_head\":" + state_head_json(node_id_, authentication_, journal_bytes_, false) +
        ",\"authentication\":";
    if (authentication_) {
        const auto& a = *authentication_;
        out += "{\"generation\":" + json_string(a.generation) +
            ",\"key_id\":" + json_string(datacube::hex_lower(a.key_id)) +
            ",\"epoch\":" + json_string(datacube::hex_lower(a.epoch)) +
            ",\"root\":" + json_string(datacube::hex_lower(a.root)) +
            ",\"records\":" + std::to_string(a.records) + "}";
    } else { out += "null"; }
    out += ",\"opening_expectation\":{\"result\":" + json_string(
        opening_state_head_expectation_ ? "MATCHED_AT_OPEN" : "NOT_SUPPLIED") +
        ",\"scope\":\"PROCESS_OPEN_INPUT_ONLY\",\"matches_observation\":";
    if (opening_state_head_expectation_) {
        out += authentication_ && matches_state_head(*opening_state_head_expectation_,
            node_id_, *authentication_, journal_bytes_) ? "true" : "false";
    } else { out += "null"; }
    out += "},\"observation\":{\"consistency\":\"ONE_STATE_LOCK\","
        "\"validation\":\"REPLAY_AND_LIVE_APPLICATION\",\"disk_reaudit\":false,"
        "\"may_advance_after_sample\":" + std::string(terminal ? "false" : "true") +
        ",\"freshness\":\"NOT_ESTABLISHED\"}";
    if (terminal) {
        const auto outbound = delivery_index_.pending();
        const auto actions = action_selection_index_.pending();
        out += ",\"terminal\":{\"scope\":\"THIS_PROCESS_STOP_ONLY\",\"state_sealed\":true,"
            "\"pending_outbound\":" + std::to_string(outbound) +
            ",\"pending_actions\":" + std::to_string(actions) +
            ",\"obligations_complete\":" + std::string(outbound == 0U && actions == 0U ? "true" : "false") +
            ",\"backlog_scope\":\"OUTBOUND_AND_ACTIONS_ONLY\",\"replacement_writer_excluded\":false}";
    }
    return out + ",\"automatic_update\":false}";
}

RuntimeStatusMetadata NodeState::runtime_status_metadata(const RuntimeConfig& config,
    const std::vector<std::string>& registered_peers, const bool include_logical_digest, const bool minimal_details) const {
    std::lock_guard<std::mutex> lock(mutex_);
    if (poisoned_) app_fail("STATE_RESTART_REQUIRED", "writer is poisoned; restart required");
    RuntimeStatusMetadata result;
    SubmissionWork snapshot_work;
    SubmissionWorkScope measured(snapshot_work);
    result.lifecycle_events = lifecycle_events_.size();
    result.local_control_events = local_control_events_.size();
    result.projection_schedules = projection_schedules_.size();
    result.publication_channels = publication_channels_.size();
    result.authorized_configuration_digest = datacube::hex_lower(runtime_configuration_digest(canonical_runtime_config(config)));
    const auto active = active_configuration_event(configuration_events_);
    result.configuration_state_match = active == 0U ? config.runtime_generation.empty() :
        configuration_events_[active - 1U].digest == runtime_configuration_digest(canonical_runtime_config(config));
    auto counts = [&](const std::string& peer) {
        RuntimePeerCounts c;
        auto count = [&](const char* status) { ++result.work.aggregate_reads;
            return static_cast<std::uint64_t>(outbox_inspection_index_.select(peer, status).records.size()); };
        c.pending = count("PENDING"); c.acked = count("ACKED"); c.rejected = count("REJECTED");
        c.cancelled = count("CANCELLED"); c.expired = count("EXPIRED");
        if (!peer.empty()) {
            const auto capacity = pending_capacity_.peer(peer); ++result.work.aggregate_reads;
            c.reserved_records = capacity.records; c.reserved_payload_bytes = capacity.payload_bytes;
            const auto future = future_result_capacity_.peer(peer); ++result.work.aggregate_reads;
            c.future_result_records = future.records; c.future_result_payload_bytes = future.payload_bytes;
            c.unresolved = c.pending;
            if (find_peer(config, peer)) {
                for (const auto& key : config.peer_generations) {
                    if (key.node_id != peer || key.state == KeyGenerationState::revoked) continue;
                    ++result.work.binding_lookups;
                    c.unresolved -= delivery_index_.bound_pending(peer, {key.generation, spki_sha256_text(key.spki_sha256)});
                }
            }
        }
        return c;
    };
    const auto global = counts("");
    const auto global_capacity = pending_capacity_.total(); ++result.work.aggregate_reads;
    const auto future_capacity = future_result_capacity_.total(); ++result.work.aggregate_reads;
    std::uint64_t resolved = 0U;
    for (const auto& peer : registered_peers) result.peers.emplace(peer, counts(peer));
    for (const auto& peer : config.peers) {
        if (!result.peers.contains(peer.node_id)) result.peers.emplace(peer.node_id, counts(peer.node_id));
        const auto& c = result.peers.at(peer.node_id); resolved += c.pending - c.unresolved;
    }
    const auto pending = global.pending, acknowledged = global.acked, rejected = global.rejected;
    const auto cancelled = global.cancelled, expired = global.expired, unresolved = pending - resolved;
    const auto authorized_admissions = authorized_inbound_count_;
    const auto action_pending = action_outcomes_[0], action_executed = action_outcomes_[1];
    const auto action_cancelled = action_outcomes_[2], action_expired = action_outcomes_[3];
    std::optional<datacube::Digest32> logical_digest;
    if (include_logical_digest) {
        const auto logical = canonical_logical_state_locked();
        result.work.logical_bytes_serialized = logical.size();
        ++result.work.logical_digest_computations;
        logical_digest = logical_state_digest_for(logical);
    }
    std::string out;
    if (!minimal_details) out += ",\"runtime_configuration\":" + configuration_history_json(configuration_events_, configuration_bindings_, true);
    else {
        out += ",\"runtime_configuration\":{\"active_event\":"+std::to_string(active)+
            ",\"generation\":"+(active?json_string(configuration_events_[active-1U].generation):"null")+
            ",\"digest\":"+(active?json_string(datacube::hex_lower(configuration_events_[active-1U].digest)):"null")+
            ",\"event_count\":"+std::to_string(configuration_events_.size())+",\"events\":[],\"events_truncated\":"+(configuration_events_.empty()?"false":"true")+
            ",\"binding_count\":"+std::to_string(configuration_bindings_.size())+",\"bindings\":[],\"bindings_truncated\":"+(configuration_bindings_.empty()?"false":"true")+"}";
    }
    out += ",\"journal_bytes\":" + std::to_string(journal_bytes_);
    out += ",\"storage\":{\"schema_version\":" +
        std::to_string(storage_schema_version_) +
        ",\"maintenance_generation\":" +
        std::to_string(maintenance_generation_) +
        ",\"state_authentication\":" + state_authentication_json(authentication_, true) +
        ",\"logical_state_digest\":" +
        (logical_digest ? json_string(datacube::hex_lower(*logical_digest)) : std::string("null")) +
        ",\"logical_state_digest_mode\":" + json_string(include_logical_digest ? "COMPUTED_AT_STATE_OBSERVATION" : "NOT_REQUESTED") +
        ",\"last_compaction_unix_ms\":" +
        (last_compaction_unix_ms_.has_value() ?
            std::to_string(*last_compaction_unix_ms_) :
            std::string("null")) +
        ",\"last_compaction_before_bytes\":" +
        std::to_string(last_compaction_before_bytes_) +
        ",\"last_compaction_after_bytes\":" +
        std::to_string(last_compaction_after_bytes_) +
        ",\"last_compaction_retained_records\":" +
        std::to_string(last_compaction_retained_records_) +
        ",\"restored_backup_id\":" +
        (restored_backup_id_.has_value() ?
            json_string(datacube::hex_lower(*restored_backup_id_)) :
            std::string("null")) +
        ",\"restored_backup_generation\":" +
        (restored_backup_generation_.empty() ?
            std::string("null") :
            json_string(restored_backup_generation_)) +
        ",\"restored_backup_unix_ms\":" +
        (restored_backup_unix_ms_.has_value() ?
            std::to_string(*restored_backup_unix_ms_) :
            std::string("null")) +
        ",\"migrations\":" + std::to_string(migrations_.size()) + "}";
    out += ",\"inbound_records\":" + std::to_string(inbound_.size());
    out += ",\"authorization\":{\"policy_digest\":" +
        json_string(datacube::hex_lower(config.authorization.digest)) +
        ",\"rules\":" + std::to_string(config.authorization.rules.size()) +
        ",\"admitted\":" + std::to_string(authorized_admissions) +
        ",\"denied\":" +
        std::to_string(authorization_denials_.size()) + "}";
    out += ",\"outbox\":{\"count\":" + std::to_string(outbound_.size()) +
        ",\"pending\":" + std::to_string(pending) +
        ",\"unresolved\":" + std::to_string(unresolved) +
        ",\"acked\":" + std::to_string(acknowledged) +
        ",\"rejected\":" + std::to_string(rejected) +
        ",\"expired\":" + std::to_string(expired) +
        ",\"cancelled\":" + std::to_string(cancelled) +
        ",\"reservations\":{\"pending_records\":" +
        std::to_string(global_capacity.records) +
        ",\"pending_payload_bytes\":" +
        std::to_string(global_capacity.payload_bytes) +
        ",\"future_result_records\":" + std::to_string(future_capacity.records) +
        ",\"future_result_payload_bytes\":" + std::to_string(future_capacity.payload_bytes) +
        ",\"committed_records\":" + std::to_string(global_capacity.records + future_capacity.records) +
        ",\"committed_payload_bytes\":" + std::to_string(global_capacity.payload_bytes + future_capacity.payload_bytes) +
        ",\"global_max_records\":" +
        std::to_string(queue_limits_.global_max_records) +
        ",\"global_max_payload_bytes\":" +
        std::to_string(queue_limits_.global_max_payload_bytes) +
        ",\"peer_max_records\":" +
        std::to_string(queue_limits_.peer_max_records) +
        ",\"peer_max_payload_bytes\":" +
        std::to_string(queue_limits_.peer_max_payload_bytes) + "}" +
        ",\"entries\":[";
    constexpr std::size_t entry_limit = 64U;
    constexpr std::size_t transition_limit = 16U;
    const auto shown = minimal_details ? 0U : std::min(outbound_.size(), entry_limit);
    std::size_t returned = 0U;
    const auto entries_begin = out.size();
    for (std::size_t index = 0U; index < shown; ++index) {
        const auto row_begin = out.size();
        ++result.work.outbox_metadata_records;
        if (index != 0U) { out += ','; }
        const auto& entry = outbound_[index];
        out += "{\"queue_sequence\":" + std::to_string(entry.queue_sequence) +
            ",\"operation_id\":" +
            json_string(operation_id_text(entry.record.operation_id)) +
            ",\"recipient\":" + json_string(entry.record.recipient) +
            ",\"status\":" + json_string(outbound_status_name(entry));
        if (entry.delivery.has_value()) {
            const auto& delivery = *entry.delivery;
            const auto* generation = runtime_bound_generation(config, entry);
            const auto rejection = runtime_final_rejection(entry);
            if (!delivery.transitions.empty()) ++result.work.rejection_tail_reads;
            out += ",\"attempts\":" + std::to_string(delivery.attempts) +
                ",\"maximum_attempts\":" +
                std::to_string(delivery.policy.maximum_attempts) +
                ",\"next_attempt_unix_ms\":" +
                std::to_string(delivery.next_attempt_unix_ms) +
                ",\"expires_unix_ms\":" +
                std::to_string(delivery.policy.expires_unix_ms) +
                ",\"peer_generation\":" +
                (delivery.policy.peer_generation.has_value() ?
                    json_string(*delivery.policy.peer_generation) : std::string("null")) +
                ",\"peer_generation_state\":" +
                (generation != nullptr ?
                    json_string(key_generation_state_name(generation->state)) :
                    std::string("null")) +
                ",\"peer_spki_sha256\":" +
                (delivery.policy.peer_spki_sha256.has_value() ?
                    json_string(spki_sha256_text(
                        *delivery.policy.peer_spki_sha256)) :
                    std::string("null")) +
                ",\"last_error_code\":" +
                (delivery.last_error_code.empty() ?
                    std::string("null") : json_string(delivery.last_error_code)) +
                ",\"expiry_reason\":" +
                (delivery.expiry_reason.empty() ?
                    std::string("null") : json_string(delivery.expiry_reason)) +
                ",\"cancelled_unix_ms\":" +
                (delivery.cancelled_unix_ms.has_value() ?
                    std::to_string(*delivery.cancelled_unix_ms) : std::string("null")) +
                ",\"cancellation_reason\":" +
                (delivery.cancellation_reason.empty() ?
                    std::string("null") : json_string(delivery.cancellation_reason)) +
                ",\"rejection\":" +
                (rejection.has_value() ?
                    std::string("{\"rejected_unix_ms\":") +
                        std::to_string(rejection->rejected_unix_ms) +
                        ",\"code\":" + json_string(rejection->code) +
                        ",\"detail\":" + json_string(rejection->detail) +
                        ",\"detail_digest\":" +
                        json_string(datacube::hex_lower(rejection->detail_digest)) +
                        ",\"peer_generation\":" +
                        json_string(rejection->peer_generation) +
                        ",\"peer_spki_sha256\":" +
                        json_string(spki_sha256_text(
                            rejection->peer_spki_sha256)) +
                        ",\"policy_digest\":" +
                        json_string(datacube::hex_lower(
                            rejection->policy_digest)) + "}" :
                    std::string("null")) +
                ",\"transitions\":[";
            const auto transition_start = delivery.transitions.size() > transition_limit ?
                delivery.transitions.size() - transition_limit : 0U;
            for (std::size_t item = transition_start;
                 item < delivery.transitions.size(); ++item) {
                if (item != transition_start) { out += ','; }
                ++result.work.transitions;
                const auto& transition = delivery.transitions[item];
                out += "{\"kind\":" +
                    json_string(outbound_transition_kind_name(transition.kind)) +
                    ",\"unix_ms\":" + std::to_string(transition.unix_ms) +
                    ",\"actor\":" + json_string(transition.actor) +
                    ",\"reason\":" + json_string(transition.reason) +
                    ",\"from_generation\":" +
                    json_string(transition.from_generation) +
                    ",\"from_spki_sha256\":" +
                    json_string(spki_sha256_text(transition.from_spki_sha256));
                if (transition.kind == OutboundTransitionKind::rejected) {
                    out += ",\"to_generation\":null,\"to_spki_sha256\":null";
                    out += ",\"policy_digest\":" +
                        (transition.to_spki_sha256.has_value() ?
                            json_string(datacube::hex_lower(
                                *transition.to_spki_sha256)) :
                            std::string("null"));
                } else {
                    out += ",\"to_generation\":" +
                        (transition.to_generation.has_value() ?
                            json_string(*transition.to_generation) :
                            std::string("null")) +
                        ",\"to_spki_sha256\":" +
                        (transition.to_spki_sha256.has_value() ?
                            json_string(spki_sha256_text(
                                *transition.to_spki_sha256)) :
                            std::string("null")) +
                        ",\"policy_digest\":null";
                }
                out += "}";
            }
            out += "],\"transitions_truncated\":" +
                std::string(delivery.transitions.size() > transition_limit ?
                    "true" : "false");
        } else {
            out += ",\"attempts\":0,\"maximum_attempts\":null"
                ",\"next_attempt_unix_ms\":null,\"expires_unix_ms\":null"
                ",\"peer_generation\":null,\"peer_generation_state\":null"
                ",\"peer_spki_sha256\":null,\"last_error_code\":null"
                ",\"expiry_reason\":null,\"cancelled_unix_ms\":null"
                ",\"cancellation_reason\":null,\"rejection\":null"
                ",\"transitions\":[]"
                ",\"transitions_truncated\":false";
        }
        out += "}";
        if (out.size() - entries_begin > 24'576U) { out.resize(row_begin); break; }
        ++returned;
    }
    out += "],\"entries_returned\":" + std::to_string(returned);
    out += ",\"entries_truncated\":" +
        std::string(outbound_.size() > returned ? "true" : "false") + "}";


    result.fields = std::move(out);
    out = "{\"sink\":\"DURABLE_COUNTER_V1\"";
    out += ",\"counter_value\":" +
        std::to_string(action_counter_value_);
    out += ",\"reserved_amount\":" +
        std::to_string(action_reserved_amount_);
    out += ",\"count\":" + std::to_string(actions_.size()) +
        ",\"pending\":" + std::to_string(action_pending) +
        ",\"executed\":" + std::to_string(action_executed) +
        ",\"cancelled\":" + std::to_string(action_cancelled) +
        ",\"expired\":" + std::to_string(action_expired) +
        ",\"entries\":[";
    std::size_t actions_returned = 0U;
    const auto action_entries_begin = out.size();
    const auto action_shown = minimal_details ? 0U : std::min(actions_.size(), entry_limit);
    for (std::size_t index = 0U; index < action_shown; ++index) {
        const auto row_begin = out.size();
        ++result.work.action_metadata_records;
        if (index != 0U) { out += ','; }
        const auto& action = actions_[index];
        out += "{\"queue_sequence\":" + std::to_string(action.queue_sequence) +
            ",\"action_id\":" + json_string(operation_id_text(action.action_id)) +
            ",\"issuer\":" + json_string(action.issuer) +
            ",\"peer_generation\":" + json_string(action.peer_generation) +
            ",\"status\":" + json_string(action_status_name(action)) +
            ",\"amount\":" + std::to_string(action.amount) +
            ",\"attempts\":" + std::to_string(action.attempts) +
            ",\"admitted_unix_ms\":" +
            std::to_string(action.admitted_unix_ms) +
            ",\"not_before_unix_ms\":" +
            std::to_string(action.not_before_unix_ms) +
            ",\"expires_unix_ms\":" +
            std::to_string(action.expires_unix_ms) +
            ",\"policy_digest\":" +
            json_string(datacube::hex_lower(action.policy_digest)) +
            ",\"rule_digest\":" +
            json_string(datacube::hex_lower(action.rule_digest)) +
            ",\"last_error_code\":" +
            (action.last_error_code.empty() ? std::string("null") :
                json_string(action.last_error_code)) +
            ",\"completed_unix_ms\":" +
            (action.completed_unix_ms.has_value() ?
                std::to_string(*action.completed_unix_ms) : std::string("null")) +
            ",\"cancelled_unix_ms\":" +
            (action.cancelled_unix_ms.has_value() ?
                std::to_string(*action.cancelled_unix_ms) : std::string("null")) +
            ",\"expired_unix_ms\":" +
            (action.expired_unix_ms.has_value() ?
                std::to_string(*action.expired_unix_ms) : std::string("null")) +
            ",\"counter_before\":" +
            (action.counter_before.has_value() ?
                std::to_string(*action.counter_before) : std::string("null")) +
            ",\"counter_after\":" +
            (action.counter_after.has_value() ?
                std::to_string(*action.counter_after) : std::string("null")) +
            ",\"receipt_digest\":" +
            (action.receipt_digest.has_value() ?
                json_string(datacube::hex_lower(*action.receipt_digest)) :
                std::string("null")) + "}";
        if (out.size() - action_entries_begin > 8'192U) { out.resize(row_begin); break; }
        ++actions_returned;
    }
    out += "],\"entries_returned\":" + std::to_string(actions_returned);
    out += ",\"entries_truncated\":" +
        std::string(actions_.size() > actions_returned ? "true" : "false") + "}";


    result.actions = std::move(out);
    result.work.snapshot_calls = snapshot_work.snapshot_calls;
    result.work.snapshot_payload_bytes = snapshot_work.snapshot_evidence_payload_bytes;
    return result;
}

CheckpointImage NodeState::checkpoint_image_locked(
    const std::uint64_t created_unix_ms,
    const std::uint64_t generation,
    const std::uint64_t before_bytes, const bool protect) const {
    if (created_unix_ms == 0U || generation < maintenance_generation_) {
        app_fail("CHECKPOINT_INVALID", "checkpoint generation or time is invalid");
    }
    const auto logical = canonical_logical_state_locked();
    const auto digest = logical_state_digest_for(logical);
    const auto retained = static_cast<std::uint64_t>(inbound_.size()) +
        static_cast<std::uint64_t>(outbound_.size()) +
        static_cast<std::uint64_t>(authorization_denials_.size()) +
        static_cast<std::uint64_t>(actions_.size()) +
        static_cast<std::uint64_t>(recoveries_.size()) +
        static_cast<std::uint64_t>(migrations_.size()) +
        static_cast<std::uint64_t>(configuration_events_.size()) +
        static_cast<std::uint64_t>(configuration_bindings_.size()) +
        static_cast<std::uint64_t>(local_control_events_.size()) +
        static_cast<std::uint64_t>(lifecycle_events_.size()) +
        static_cast<std::uint64_t>(consumers_.size()) +
        static_cast<std::uint64_t>(projection_schedules_.size()) +
        static_cast<std::uint64_t>(publication_channels_.size()) +
        static_cast<std::uint64_t>(source_subscriptions_.size()) + static_cast<std::uint64_t>(import_schedules_.size()) + static_cast<std::uint64_t>(outbox_administration_.size()) + static_cast<std::uint64_t>(action_administration_.size()) + static_cast<std::uint64_t>(action_results_.size()) + static_cast<std::uint64_t>(result_reviews_.size()) +
        static_cast<std::uint64_t>(custody_registry_.events().size());
    const bool records_compaction = generation > maintenance_generation_;
    const auto compaction_time = records_compaction ?
        std::optional<std::uint64_t>(created_unix_ms) : last_compaction_unix_ms_;
    const auto compaction_before = records_compaction ?
        before_bytes : last_compaction_before_bytes_;
    const auto compaction_retained = records_compaction ?
        retained : last_compaction_retained_records_;

    const auto make_payload = [&](const std::uint64_t compaction_after) {
        datacube::Octets payload;
        datacube::append_octets(payload, kCheckpointMagicV3);
        datacube::append_u8(payload, records_compaction ? 1U : 0U);
        datacube::append_be32(payload, kCurrentStorageSchemaVersion);
        datacube::append_be64(payload, generation);
        append_optional_u64(payload, compaction_time);
        datacube::append_be64(payload, compaction_before);
        datacube::append_be64(payload, compaction_after);
        datacube::append_be64(payload, compaction_retained);
        append_optional_digest(payload, restored_backup_id_);
        datacube::append_u8(
            payload, restored_backup_id_.has_value() ? 1U : 0U);
        if (restored_backup_id_.has_value()) {
            append_text16(payload, restored_backup_generation_, 64U,
                "checkpoint restored backup generation");
            if (!restored_backup_unix_ms_.has_value()) {
                app_fail("CHECKPOINT_INVALID",
                    "restored backup identity is missing its time");
            }
            datacube::append_be64(payload, *restored_backup_unix_ms_);
        }
        append_digest(payload, digest);
        datacube::append_be64(payload, retained);
        datacube::append_be64(
            payload, static_cast<std::uint64_t>(logical.size()));
        datacube::append_octets(payload, logical);
        return payload;
    };

    auto payload = make_payload(records_compaction ? 0U :
        last_compaction_after_bytes_);
    auto frame = frame_for(
        static_cast<std::uint8_t>(EntryKind::checkpoint), payload);
    std::optional<StateAuthentication> image_authentication;
    if (protect && authentication_) {
        auto wrapped = authenticate_checkpoint(frame, node_id_, auth_key_, &*authentication_,
            digest, records_compaction ? "COMPACT" : "BACKUP");
        if (records_compaction) {
            payload = make_payload(static_cast<std::uint64_t>(wrapped.bytes.size()));
            frame = frame_for(static_cast<std::uint8_t>(EntryKind::checkpoint), payload);
            wrapped = authenticate_checkpoint(frame, node_id_, auth_key_, &*authentication_, digest, "COMPACT");
        }
        frame = std::move(wrapped.bytes);
        image_authentication = std::move(wrapped.authentication);
    } else if (records_compaction) {
        payload = make_payload(static_cast<std::uint64_t>(frame.size()));
        frame = frame_for(static_cast<std::uint8_t>(EntryKind::checkpoint), payload);
    }
    if (frame.size() > maximum_journal_bytes_) {
        app_fail("STATE_CAPACITY_EXCEEDED",
            "canonical checkpoint exceeds the configured journal limit");
    }
    return CheckpointImage{
        .authentication = std::move(image_authentication),
        .journal_bytes = std::move(frame),
        .storage_schema_version = kCurrentStorageSchemaVersion,
        .maintenance_generation = generation,
        .retained_records = retained,
        .logical_state_digest = digest,
    };
}

void NodeState::load_checkpoint(const datacube::OctetView payload) {
    if (!inbound_.empty() || !outbound_.empty() ||
        !authorization_denials_.empty() || !actions_.empty() ||
        !recoveries_.empty() || !migrations_.empty() ||
        !configuration_events_.empty() || !configuration_bindings_.empty() ||
        !local_control_events_.empty() || !lifecycle_events_.empty() ||
        !consumers_.empty() || !projection_schedules_.empty() ||
        !publication_channels_.empty() || !source_subscriptions_.empty() ||
        !source_subscription_commitments_.empty() || !import_schedules_.empty() ||
        !outbox_administration_.empty() || !action_administration_.empty() ||
        !action_results_.empty() || !custody_registry_.events().empty() ||
        maintenance_generation_ != 0U || restored_backup_id_.has_value()) {
        app_fail("JOURNAL_CORRUPT", "checkpoint must be the first journal record");
    }
    datacube::Reader reader(payload, "journal checkpoint");
    const auto magic = reader.read_exact(kCheckpointMagicV2.size(), "checkpoint magic");
    const bool checkpoint_v2 = std::equal(
        kCheckpointMagicV2.begin(), kCheckpointMagicV2.end(), magic.begin());
    const bool checkpoint_v3 = std::equal(
        kCheckpointMagicV3.begin(), kCheckpointMagicV3.end(), magic.begin());
    if (!checkpoint_v2 && !checkpoint_v3) {
        app_fail("JOURNAL_CORRUPT", "checkpoint magic mismatch");
    }
    bool publication_account_current = true;
    if (checkpoint_v3) {
        const auto marker = reader.read_u8("checkpoint publication-account marker");
        if (marker > 1U) {
            app_fail("JOURNAL_CORRUPT",
                "checkpoint publication-account marker is invalid");
        }
        publication_account_current = marker == 1U;
    }
    const auto schema = reader.read_be32("checkpoint schema");
    const auto generation = reader.read_be64("checkpoint generation");
    const auto compacted = read_optional_u64(reader, "checkpoint compaction time");
    const auto before_bytes = reader.read_be64("checkpoint previous bytes");
    const auto after_bytes = reader.read_be64("checkpoint compacted bytes");
    const auto compaction_retained = reader.read_be64(
        "checkpoint compaction retained records");
    const auto backup_id = read_optional_digest(reader, "checkpoint backup ID");
    const auto backup_marker = reader.read_u8("checkpoint backup marker");
    if (backup_marker > 1U ||
        (backup_marker == 1U) != backup_id.has_value()) {
        app_fail("JOURNAL_CORRUPT", "checkpoint backup marker mismatch");
    }
    std::string backup_generation;
    std::optional<std::uint64_t> backup_time;
    if (backup_marker == 1U) {
        backup_generation = read_text16(
            reader, 64U, "checkpoint backup generation");
        backup_time = reader.read_be64("checkpoint backup restore time");
    }
    const auto expected_digest = read_digest(reader, "checkpoint logical digest");
    const auto expected_retained = reader.read_be64(
        "checkpoint retained record count");
    const auto logical_size = reader.read_be64("checkpoint logical state size");
    if (logical_size > static_cast<std::uint64_t>(reader.remaining())) {
        app_fail("JOURNAL_CORRUPT", "checkpoint logical state is truncated");
    }
    const auto logical = reader.read_exact(logical_size, "checkpoint logical state");
    reader.require_eof("checkpoint");
    if (schema != kCurrentStorageSchemaVersion || generation > 1'000'000'000ULL ||
        (compacted.has_value() && *compacted == 0U) ||
        (!compacted.has_value() &&
         (before_bytes != 0U || after_bytes != 0U || compaction_retained != 0U)) ||
        (publication_account_current && !compacted.has_value()) ||
        (backup_id.has_value() &&
         (!valid_generation_id(backup_generation) || !backup_time.has_value() ||
          *backup_time == 0U)) ||
        expected_digest != logical_state_digest_for(logical)) {
        app_fail("JOURNAL_CORRUPT", "checkpoint header is invalid");
    }

    datacube::Reader state_reader(logical, "checkpoint logical state");
    const auto logical_magic = state_reader.read_exact(
        kLogicalStateMagic.size(), "logical state magic");
    if (!std::equal(
            kLogicalStateMagic.begin(), kLogicalStateMagic.end(),
            logical_magic.begin())) {
        app_fail("JOURNAL_CORRUPT", "logical state magic mismatch");
    }
    const auto logical_schema = state_reader.read_be32("logical state schema");
    const auto logical_node = read_text16(
        state_reader, 64U, "logical state node ID");
    if (logical_schema != schema || logical_node != node_id_) {
        app_fail("JOURNAL_CORRUPT", "logical state identity mismatch");
    }

    std::vector<StorageMigration> decoded_migrations;
    const auto migration_count = read_count32(
        state_reader, 16U, "logical migration count");
    decoded_migrations.reserve(migration_count);
    for (std::size_t index = 0U; index < migration_count; ++index) {
        decoded_migrations.push_back(StorageMigration{
            .from_version = state_reader.read_be32("migration source"),
            .to_version = state_reader.read_be32("migration target"),
            .migrated_unix_ms = state_reader.read_be64("migration time"),
        });
    }
    if (decoded_migrations.size() > 1U ||
        (!decoded_migrations.empty() &&
         (decoded_migrations.front().from_version != 1U ||
          decoded_migrations.front().to_version != kCurrentStorageSchemaVersion ||
          decoded_migrations.front().migrated_unix_ms == 0U))) {
        app_fail("JOURNAL_CORRUPT", "checkpoint migration history is invalid");
    }

    struct DecodedInbound final {
        EvidenceRecord record;
        std::optional<AuthorizationAccount> authorization;
        std::shared_ptr<const LocalAuthorship> local_authorship;
        std::shared_ptr<const SubscribedSource> subscribed_source;
    };
    std::vector<DecodedInbound> decoded_inbound;
    const auto inbound_count = read_count32(
        state_reader, 1'000'000U, "logical inbound count");
    decoded_inbound.reserve(inbound_count);
    for (std::size_t index = 0U; index < inbound_count; ++index) {
        const auto message = read_application(state_reader, "logical inbound");
        const auto* record = std::get_if<EvidenceRecord>(&message);
        if (record == nullptr) {
            app_fail("JOURNAL_CORRUPT", "checkpoint inbound is not evidence");
        }
        const auto marker = state_reader.read_u8("logical inbound authorization marker");
        if (marker > 3U) {
            app_fail("JOURNAL_CORRUPT", "invalid inbound authorization marker");
        }
        std::optional<AuthorizationAccount> authorization;
        if (marker == 1U) {
            authorization = read_authorization_account(state_reader);
        }
        std::shared_ptr<const LocalAuthorship> local;
        if (marker == 2U) { local = std::make_shared<const LocalAuthorship>(decode_local_authorship(state_reader)); }
        std::shared_ptr<const SubscribedSource> imported;
        if (marker == 3U) { imported = std::make_shared<const SubscribedSource>(decode_subscribed_source(state_reader)); }
        decoded_inbound.push_back(DecodedInbound{
            .record = *record,
            .authorization = std::move(authorization),
            .local_authorship = std::move(local),
            .subscribed_source = std::move(imported),
        });
    }

    std::vector<StoredOutbound> decoded_outbound;
    const auto outbound_count = read_count32(
        state_reader, 1'000'000U, "logical outbound count");
    decoded_outbound.reserve(outbound_count);
    for (std::size_t index = 0U; index < outbound_count; ++index) {
        const auto message = read_application(state_reader, "logical outbound");
        const auto* record = std::get_if<EvidenceRecord>(&message);
        if (record == nullptr) {
            app_fail("JOURNAL_CORRUPT", "checkpoint outbound is not evidence");
        }
        std::optional<DeliveryReceipt> receipt;
        const auto receipt_marker = state_reader.read_u8(
            "logical outbound receipt marker");
        if (receipt_marker > 1U) {
            app_fail("JOURNAL_CORRUPT", "invalid outbound receipt marker");
        }
        if (receipt_marker == 1U) {
            const auto receipt_message = read_application(
                state_reader, "logical outbound receipt");
            const auto* value = std::get_if<DeliveryReceipt>(&receipt_message);
            if (value == nullptr) {
                app_fail("JOURNAL_CORRUPT", "checkpoint receipt has wrong kind");
            }
            receipt = *value;
        }
        std::optional<OutboundDeliveryState> delivery;
        const auto delivery_marker = state_reader.read_u8(
            "logical outbound delivery marker");
        if (delivery_marker > 1U) {
            app_fail("JOURNAL_CORRUPT", "invalid outbound delivery marker");
        }
        if (delivery_marker == 1U) {
            delivery = read_outbound_delivery_state(state_reader);
        }
        decoded_outbound.push_back(StoredOutbound{
            .record = *record,
            .record_digest = evidence_record_digest(*record),
            .queue_sequence = static_cast<std::uint64_t>(index) + 1U,
            .receipt = std::move(receipt),
            .delivery = std::move(delivery),
        });
    }

    std::vector<AuthorizationDenial> decoded_denials;
    const auto denial_count = read_count32(
        state_reader, 1'000'000U, "logical denial count");
    decoded_denials.reserve(denial_count);
    for (std::size_t index = 0U; index < denial_count; ++index) {
        decoded_denials.push_back(AuthorizationDenial{
            .authorization = read_authorization_account(state_reader),
            .issuer = read_text16(state_reader, 64U, "logical denied issuer"),
            .recipient = read_text16(
                state_reader, 64U, "logical denied recipient"),
            .scope = read_text16(state_reader, 128U, "logical denied scope"),
        });
    }

    std::vector<StoredAction> decoded_actions;
    const auto action_count = read_count32(
        state_reader, 1'000'000U, "logical action count");
    decoded_actions.reserve(action_count);
    for (std::size_t index = 0U; index < action_count; ++index) {
        decoded_actions.push_back(read_action_state(state_reader));
    }
    const auto decoded_counter = state_reader.read_be64("logical action counter");
    const auto decoded_reserved = state_reader.read_be64("logical action reserved");

    std::vector<JournalRecovery> decoded_recoveries;
    const auto recovery_count = read_count32(
        state_reader, 1'000'000U, "logical recovery count");
    decoded_recoveries.reserve(recovery_count);
    for (std::size_t index = 0U; index < recovery_count; ++index) {
        const auto discarded = state_reader.read_be64("recovery discarded bytes");
        const auto prefix = state_reader.read_be64("recovery valid prefix");
        if (discarded == 0U) {
            app_fail("JOURNAL_CORRUPT", "checkpoint recovery discards zero bytes");
        }
        decoded_recoveries.push_back(JournalRecovery{
            .discarded_tail_bytes = discarded,
            .valid_prefix_bytes = prefix,
        });
    }
    if (state_reader.remaining() != 0U) {
        const auto marker = state_reader.read_exact(4U, "configuration extension");
        if (datacube::octets_text(marker, "configuration extension", true) != "NRC1") {
            app_fail("JOURNAL_CORRUPT", "unknown logical state extension");
        }
        const auto count = read_count32(state_reader, 256U, "configuration count");
        if (count == 0U) { app_fail("JOURNAL_CORRUPT", "empty configuration extension"); }
        for (std::size_t i = 0U; i < count; ++i) {
            const auto event = read_runtime_event(state_reader);
            validate_runtime_event(event, configuration_events_, node_id_);
            if (event.kind != "REJECTED") { reserve_source_view_domains_locked(parse_runtime_config(event.canonical,"/source-view-checkpoint",IdentityFileValidation::deferred)); }
            configuration_events_.push_back(event);
        index_configuration_event_locked(runtime_event_payload(event));
        }
        const auto bindings = read_count32(state_reader, 1'000'000U, "binding count");
        std::uint64_t previous = 0U;
        for (std::size_t i = 0U; i < bindings; ++i) {
            const auto binding = read_runtime_binding(state_reader);
            if (binding.configuration_event == 0U ||
                binding.configuration_event > configuration_events_.size() ||
                binding.configuration_event < previous ||
                configuration_events_[binding.configuration_event - 1U].kind == "REJECTED" ||
                binding.journal_kind < 1U || (binding.journal_kind > 21U && binding.journal_kind != 24U && binding.journal_kind != 37U && binding.journal_kind != 39U) ||
                binding.journal_kind == 17U || binding.journal_kind == 18U ||
                binding.journal_kind == 19U || digest_is_zero(binding.payload_digest)) {
                app_fail("JOURNAL_CORRUPT", "invalid runtime mutation binding");
            }
            previous = binding.configuration_event;
            configuration_bindings_.push_back(binding);
        index_configuration_binding_locked();
        }
        const auto active = active_configuration_event(configuration_events_);
        if (active != 0U) {
            queue_limits_ = parse_runtime_config(
                configuration_events_[active - 1U].canonical,
                "/durable-configuration",
                IdentityFileValidation::deferred).queue_limits;
        }
        if (state_reader.remaining() != 0U) {
            const auto local_marker = state_reader.read_exact(4U, "local control extension");
            if (datacube::octets_text(local_marker, "local control extension", true) != "NLC1") {
                app_fail("JOURNAL_CORRUPT", "unknown logical state extension after configuration");
            }
            const auto local_count = read_count32(
                state_reader, 1'000'000U, "local control event count");
            local_control_events_.reserve(local_count);
            for (std::size_t i = 0U; i < local_count; ++i) {
                const auto event = read_local_control_event(state_reader);
                validate_local_control_event(event, configuration_events_);
                local_control_events_.push_back(event);
                index_control_history_locked(true, local_control_event_payload(event));
            }
            const auto lifecycle_count = read_count32(
                state_reader, 1'000'000U, "lifecycle event count");
            lifecycle_events_.reserve(lifecycle_count);
            for (std::size_t i = 0U; i < lifecycle_count; ++i) {
                const auto event = read_lifecycle_event(state_reader);
                validate_lifecycle_event(event, configuration_events_);
                lifecycle_events_.push_back(event);
                index_control_history_locked(false, lifecycle_event_payload(event));
            }
        }
    }
    std::vector<std::vector<ImportAutoEvent>> decoded_import_histories;
    std::vector<std::pair<datacube::Digest32, ActionResultState>>
        decoded_action_results;
    std::vector<datacube::Octets> decoded_result_reviews;
    unsigned extension_rank = 0U;
    while (state_reader.remaining() != 0U) {
        const auto marker = datacube::octets_text(state_reader.read_exact(4U, "derived extension"), "derived extension", true);
        const unsigned rank = (marker == "NDC1" || marker == "NDC2") ? 1U : marker == "NAS1" ? 2U :
            marker == "NPH1" ? 3U : marker == "NSB1" ? 4U : marker == "NIS1" ? 5U : marker == "NOA2" ? 6U : marker == "NAA1" ? 7U : (marker == "NRA1" || marker == "NRA2") ? 8U : marker == "NRV1" ? 9U : marker == "NCU1" ? 10U : 0U;
        if (rank == 0U || rank <= extension_rank) { app_fail("JOURNAL_CORRUPT", "unknown, duplicate or unordered derived extension"); }
        extension_rank = rank;
        if (rank == 1U) {
            const auto count = read_count32(state_reader, marker == "NDC1" ? kConsumerLimit : kStoredConsumerLimit, "consumer count");
            if (count == 0U) { app_fail("JOURNAL_CORRUPT", "empty consumer extension"); }
            for (std::size_t i = 0U; i < count; ++i) {
                const auto size = state_reader.read_be32("consumer bytes");
                if (size > kConsumerEncodedLimit) { app_fail("JOURNAL_CORRUPT", "oversized consumer state"); }
                auto value = decode_consumer(state_reader.read_exact(size, "consumer state"));
                const auto key = consumer_key(value.uid, value.name);
                if ((marker == "NDC1" && value.retirement) || consumers_.contains(key)) { app_fail("JOURNAL_CORRUPT", "duplicate consumer"); }
                consumers_.emplace(key, std::move(value));
            }
        } else if (rank == 2U) {
            const auto count = read_count32(state_reader, kStoredConsumerLimit, "schedule count");
            if (count == 0U) { app_fail("JOURNAL_CORRUPT", "empty schedule extension"); }
            for (std::size_t i = 0U; i < count; ++i) {
                const auto size = state_reader.read_be32("schedule size");
                if (size > 32'000U) { app_fail("JOURNAL_CORRUPT", "schedule size bound"); }
                auto value = decode_projection_schedule(state_reader.read_exact(size, "schedule"));
                const auto key = consumer_key(value.uid, value.name);
                if (projection_schedules_.contains(key)) { app_fail("JOURNAL_CORRUPT", "duplicate schedule"); }
                projection_schedules_.emplace(key, std::move(value));
            }
        } else if (rank == 3U) {
            const auto count = read_count32(state_reader, kStoredPublicationChannelLimit, "publication channel count");
            if (count == 0U) { app_fail("JOURNAL_CORRUPT", "empty publication channel extension"); }
            for (std::size_t i = 0U; i < count; ++i) {
                const auto size = state_reader.read_be32("publication channel size");
                if (size > kPublicationChannelEncodedLimit) { app_fail("JOURNAL_CORRUPT", "publication channel size bound"); }
                auto value = decode_publication_channel(state_reader.read_exact(size, "publication channel"));
                const auto key = publication_channel_key(value.uid, value.name);
                if (publication_channels_.contains(key)) { app_fail("JOURNAL_CORRUPT", "duplicate publication channel"); }
                publication_channels_.emplace(key, std::move(value));
            }
        } else if(rank==6U) {
            const auto count=read_count32(state_reader,kOutboxAdminLimit,"conditional receipts");
            if(count==0U)app_fail("JOURNAL_CORRUPT","empty conditional extension");
            for(std::size_t i=0U;i<count;++i){const auto size=state_reader.read_be32("conditional receipt size");if(size>kOutboxAdminMetadataLimit+1024U)app_fail("JOURNAL_CORRUPT","conditional receipt bound");outbox_administration_.push_back(decode_outbox_admin_record(state_reader.read_exact(size,"conditional receipt")));}
        } else if(rank==7U) {
            const auto count=read_count32(state_reader,kActionAdminLimit,"conditional action receipts");
            if(count==0U)app_fail("JOURNAL_CORRUPT","empty conditional action extension");
            for(std::size_t i=0U;i<count;++i){const auto size=state_reader.read_be32("conditional action receipt size");if(size>kActionAdminMetadataLimit+1024U)app_fail("JOURNAL_CORRUPT","conditional action receipt bound");action_administration_.push_back(decode_action_admin_record(state_reader.read_exact(size,"conditional action receipt")));}
        } else if (rank == 9U) {
            const auto count = read_count32(state_reader, kResultReviewLimit, "result review count");
            if (count == 0U) app_fail("JOURNAL_CORRUPT", "empty result review extension");
            for (std::size_t i=0U; i<count; ++i) {
                const auto size = state_reader.read_be32("review size");
                if (size > kResultReviewEncodedLimit) app_fail("JOURNAL_CORRUPT", "review size limit");
                const auto bytes = state_reader.read_exact(size, "result review");
                decoded_result_reviews.emplace_back(bytes.begin(), bytes.end());
            }
        } else if(rank==8U) {
            const auto count = read_count32(
                state_reader, 1'000'000U, "action-result binding count");
            if (count == 0U) {
                app_fail("JOURNAL_CORRUPT", "empty action-result extension");
            }
            decoded_action_results.reserve(count);
            for (std::size_t i = 0U; i < count; ++i) {
                const auto action_id = read_digest(
                    state_reader, "action-result action ID");
                ActionResultState result{
                    .binding = read_action_result_binding(state_reader),
                    .outcome = std::nullopt,
                    .operation_id = std::nullopt,
                    .record_digest = std::nullopt,
                };
                if (marker == "NRA2") {
                    result.binding.reserved_payload_bytes = state_reader.read_be64("result reserved payload bytes");
                }
                const auto marker_value = state_reader.read_u8(
                    "action-result terminal marker");
                if (marker_value > 1U) {
                    app_fail("JOURNAL_CORRUPT",
                        "invalid action-result terminal marker");
                }
                if (marker_value == 1U) {
                    const auto raw = state_reader.read_u8(
                        "action-result terminal outcome");
                    if (raw < static_cast<std::uint8_t>(
                            ActionResultOutcome::executed) ||
                        raw > static_cast<std::uint8_t>(
                            ActionResultOutcome::expired)) {
                        app_fail("JOURNAL_CORRUPT",
                            "invalid action-result checkpoint outcome");
                    }
                    result.outcome = static_cast<ActionResultOutcome>(raw);
                    result.operation_id = read_digest(
                        state_reader, "action-result operation ID");
                    result.record_digest = read_digest(
                        state_reader, "action-result record digest");
                }
                decoded_action_results.emplace_back(action_id, std::move(result));
            }
        } else if(rank==5U) {
            const auto count=read_count32(state_reader,32U,"import schedules");
            if(count==0U)app_fail("JOURNAL_CORRUPT","empty import schedule extension");
            for(std::size_t i=0U;i<count;++i){const auto size=state_reader.read_be32("import history size");if(size>1'048'576U)app_fail("JOURNAL_CORRUPT","import history bound");decoded_import_histories.push_back(decode_import_auto_history(state_reader.read_exact(size,"import history")));}
        } else if (rank == 10U) {
            const auto count = read_count32(state_reader,
                kDurableCustodyEventLimit, "durable custody event count");
            if (count == 0U) {
                app_fail("JOURNAL_CORRUPT", "empty durable custody extension");
            }
            for (std::size_t index = 0U; index < count; ++index) {
                const auto size = state_reader.read_be32(
                    "durable custody event size");
                if (size == 0U || size > kDurableCustodyEventEncodedLimit) {
                    app_fail("JOURNAL_CORRUPT",
                        "durable custody event size bound");
                }
                const auto bytes = state_reader.read_exact(
                    size, "durable custody event");
                const auto event = decode_durable_custody_event(bytes);
                validate_custody_event_authority(
                    custody_registry_, configuration_events_, event);
                if (custody_registry_.apply(event) ==
                        DurableCustodyDisposition::duplicate) {
                    app_fail("JOURNAL_CORRUPT",
                        "duplicate durable custody event in checkpoint");
                }
            }
        } else {
            const auto count = read_count32(state_reader, kSourceSubscriptionLimit, "source subscription count");
            if (count == 0U) { app_fail("JOURNAL_CORRUPT", "empty source subscription extension"); }
            for (std::size_t i = 0U; i < count; ++i) {
                const auto size = state_reader.read_be32("source subscription size");
                if (size > kSourceSubscriptionEncodedLimit) { app_fail("JOURNAL_CORRUPT", "source subscription size bound"); }
                auto value = decode_source_subscription(state_reader.read_exact(size, "source subscription"));
                const auto id = value.grant.id;
                if (source_subscriptions_.contains(id)) { app_fail("JOURNAL_CORRUPT", "duplicate source subscription"); }
                source_subscriptions_.emplace(id, std::move(value));
            }
        }
    }
    state_reader.require_eof("logical state");

    storage_schema_version_ = logical_schema;
    migrations_ = std::move(decoded_migrations);

    for (std::size_t index = 0U; index < decoded_inbound.size(); ++index) {
        const auto& decoded = decoded_inbound[index];
        validate_evidence_record(decoded.record);
        const auto key = op_key(decoded.record.operation_id);
        if (inbound_index_.contains(key) || decoded.record.recipient != node_id_) {
            app_fail("JOURNAL_CORRUPT", "checkpoint inbound identity is invalid");
        }
        if (decoded.authorization.has_value()) {
            const auto& account = *decoded.authorization;
            if (!valid_authorization_account(account) ||
                account.decision != AuthorizationDecisionKind::admitted ||
                account.operation_id != decoded.record.operation_id ||
                account.record_digest != evidence_record_digest(decoded.record) ||
                account.peer_node != decoded.record.issuer ||
                account.operation_class != operation_class_for(decoded.record) ||
                account.resource != authorization_resource_for(decoded.record) ||
                !account.rule_digest.has_value()) {
                app_fail("JOURNAL_CORRUPT", "checkpoint authorization is invalid");
            }
        }
        if (decoded.subscribed_source) {
            validate_subscribed_source_locked(decoded.record,*decoded.subscribed_source,false);
        } else if (source_view_domains_.contains({decoded.record.issuer,decoded.record.scope})) {
            app_fail("JOURNAL_CORRUPT","ordinary checkpoint record entered materialized domain");
        }
        if (decoded.local_authorship) {
            validate_local_authorship_locked(decoded.record, *decoded.local_authorship, false);
        }
        if (decoded.record.corrects.has_value()) {
            const auto parent_key = op_key(*decoded.record.corrects);
            const auto parent = inbound_index_.find(parent_key);
            if (parent == inbound_index_.end() ||
                correction_child_.contains(parent_key)) {
                app_fail("JOURNAL_CORRUPT", "checkpoint correction ancestry is invalid");
            }
            if (inbound_[parent->second].local_authorship && !decoded.local_authorship) {
                app_fail("JOURNAL_CORRUPT", "nonlocal checkpoint correction crosses authorship boundary");
            }
            const auto& parent_record = inbound_[parent->second].record;
            if (parent_record.issuer != decoded.record.issuer ||
                parent_record.recipient != decoded.record.recipient ||
                parent_record.scope != decoded.record.scope) {
                app_fail("JOURNAL_CORRUPT", "checkpoint correction metadata differs");
            }
        }
        StoredInbound stored{
            .record = decoded.record,
            .record_digest = evidence_record_digest(decoded.record),
            .sequence = static_cast<std::uint64_t>(index) + 1U,
            .superseded_by = std::nullopt,
            .authorization = decoded.authorization,
            .local_authorship = decoded.local_authorship,
            .subscribed_source = decoded.subscribed_source,
        };
        inbound_index_.emplace(key, inbound_.size());
        inbound_.push_back(std::move(stored));
        index_inbound(inbound_.size() - 1U);
        if (decoded.record.corrects.has_value()) {
            const auto parent_key = op_key(*decoded.record.corrects);
            correction_child_.emplace(parent_key, key);
            inbound_[inbound_index_.at(parent_key)].superseded_by =
                decoded.record.operation_id;
        }
    }

    for (std::size_t index = 0U; index < decoded_outbound.size(); ++index) {
        auto& entry = decoded_outbound[index];
        validate_evidence_record(entry.record);
        if (entry.record.issuer != node_id_ ||
            entry.queue_sequence != static_cast<std::uint64_t>(index) + 1U ||
            entry.record_digest != evidence_record_digest(entry.record) ||
            outbound_index_.contains(op_key(entry.record.operation_id))) {
            app_fail("JOURNAL_CORRUPT", "checkpoint outbound identity is invalid");
        }
        if (entry.receipt.has_value()) {
            validate_delivery_receipt(*entry.receipt);
            if (entry.receipt->operation_id != entry.record.operation_id ||
                entry.receipt->recipient != entry.record.recipient ||
                entry.receipt->recorder != entry.record.recipient ||
                entry.receipt->record_digest != entry.record_digest ||
                entry.receipt->sequence == 0U) {
                app_fail("JOURNAL_CORRUPT", "checkpoint receipt binding is invalid");
            }
        }
        if (entry.delivery.has_value()) {
            const auto& delivery = *entry.delivery;
            const auto& policy = delivery.policy;
            if (policy.created_unix_ms == 0U ||
                policy.expires_unix_ms <= policy.created_unix_ms ||
                policy.maximum_attempts == 0U ||
                policy.initial_backoff_ms == 0U ||
                policy.maximum_backoff_ms < policy.initial_backoff_ms ||
                policy.peer_spki_sha256.has_value() !=
                    policy.peer_generation.has_value() ||
                (policy.peer_spki_sha256.has_value() &&
                 digest_is_zero(*policy.peer_spki_sha256)) ||
                (policy.peer_generation.has_value() &&
                 !valid_generation_id(*policy.peer_generation)) ||
                delivery.attempts > policy.maximum_attempts ||
                (delivery.attempts == 0U) !=
                    !delivery.last_attempt_unix_ms.has_value() ||
                (delivery.last_attempt_unix_ms.has_value() &&
                 *delivery.last_attempt_unix_ms < policy.created_unix_ms) ||
                delivery.next_attempt_unix_ms < policy.created_unix_ms ||
                !valid_optional_text(delivery.last_error_detail, 512U) ||
                (!delivery.last_error_code.empty() &&
                 !valid_error_code(delivery.last_error_code)) ||
                (delivery.expired_unix_ms.has_value() &&
                 delivery.cancelled_unix_ms.has_value())) {
                app_fail("JOURNAL_CORRUPT", "checkpoint delivery state is invalid");
            }
            if (entry.receipt.has_value() &&
                (delivery.expired_unix_ms.has_value() ||
                 delivery.cancelled_unix_ms.has_value() ||
                 !delivery.last_error_code.empty() ||
                 !delivery.last_error_detail.empty())) {
                app_fail("JOURNAL_CORRUPT", "checkpoint receipt has terminal failure state");
            }
            if (delivery.expired_unix_ms.has_value() &&
                (!valid_error_code(delivery.expiry_reason) ||
                 delivery.last_error_code != delivery.expiry_reason)) {
                app_fail("JOURNAL_CORRUPT", "checkpoint expiry state is invalid");
            }
            if (!delivery.expired_unix_ms.has_value() &&
                !delivery.expiry_reason.empty()) {
                app_fail("JOURNAL_CORRUPT", "checkpoint has an orphan expiry reason");
            }
            if (delivery.cancelled_unix_ms.has_value() &&
                (!valid_transition_text(delivery.cancellation_reason, 256U) ||
                 delivery.last_error_code != "OBLIGATION_CANCELLED")) {
                app_fail("JOURNAL_CORRUPT", "checkpoint cancellation state is invalid");
            }
            if (!delivery.cancelled_unix_ms.has_value() &&
                !delivery.cancellation_reason.empty()) {
                app_fail("JOURNAL_CORRUPT", "checkpoint has an orphan cancellation reason");
            }
            std::optional<std::string> chain_generation;
            std::optional<datacube::Digest32> chain_pin;
            bool saw_cancel = false;
            bool active_rejection = false;
            std::string active_rejection_code;
            std::string active_rejection_detail;
            for (std::size_t transition_index = 0U;
                 transition_index < delivery.transitions.size();
                 ++transition_index) {
                const auto& transition = delivery.transitions[transition_index];
                if ((transition.kind != OutboundTransitionKind::rebound &&
                     transition.kind != OutboundTransitionKind::cancelled &&
                     transition.kind != OutboundTransitionKind::rejected &&
                     transition.kind != OutboundTransitionKind::retried) ||
                    transition.unix_ms == 0U ||
                    !valid_transition_text(transition.actor, 64U) ||
                    !valid_transition_text(transition.reason, 256U) ||
                    !valid_generation_id(transition.from_generation) ||
                    digest_is_zero(transition.from_spki_sha256)) {
                    app_fail("JOURNAL_CORRUPT", "checkpoint transition is invalid");
                }
                if (!chain_generation.has_value()) {
                    chain_generation = transition.from_generation;
                    chain_pin = transition.from_spki_sha256;
                }
                if (*chain_generation != transition.from_generation ||
                    *chain_pin != transition.from_spki_sha256 || saw_cancel) {
                    app_fail("JOURNAL_CORRUPT", "checkpoint transition chain is invalid");
                }
                if (transition.kind == OutboundTransitionKind::rebound) {
                    if (!transition.to_generation.has_value() ||
                        !transition.to_spki_sha256.has_value() ||
                        !valid_generation_id(*transition.to_generation) ||
                        digest_is_zero(*transition.to_spki_sha256) ||
                        (*transition.to_generation == transition.from_generation &&
                         *transition.to_spki_sha256 == transition.from_spki_sha256)) {
                        app_fail("JOURNAL_CORRUPT", "checkpoint rebind is invalid");
                    }
                    active_rejection = false;
                    active_rejection_code.clear();
                    active_rejection_detail.clear();
                    chain_generation = *transition.to_generation;
                    chain_pin = *transition.to_spki_sha256;
                } else if (transition.kind == OutboundTransitionKind::cancelled) {
                    if (transition.to_generation.has_value() ||
                        transition.to_spki_sha256.has_value() ||
                        transition_index + 1U != delivery.transitions.size()) {
                        app_fail("JOURNAL_CORRUPT", "checkpoint cancel transition is invalid");
                    }
                    active_rejection = false;
                    saw_cancel = true;
                } else if (transition.kind == OutboundTransitionKind::rejected) {
                    if (active_rejection ||
                        !authenticated_peer_error_is_terminal(transition.actor) ||
                        transition.to_generation.has_value() ||
                        !transition.to_spki_sha256.has_value() ||
                        digest_is_zero(*transition.to_spki_sha256)) {
                        app_fail("JOURNAL_CORRUPT", "checkpoint rejection is invalid");
                    }
                    auto rejected_policy = policy;
                    rejected_policy.peer_generation = transition.from_generation;
                    rejected_policy.peer_spki_sha256 = transition.from_spki_sha256;
                    if (outbound_policy_digest(rejected_policy) !=
                        *transition.to_spki_sha256) {
                        app_fail("JOURNAL_CORRUPT",
                            "checkpoint rejection policy digest is invalid");
                    }
                    active_rejection = true;
                    active_rejection_code = transition.actor;
                    active_rejection_detail = transition.reason;
                } else {
                    if (!active_rejection ||
                        !transition.to_generation.has_value() ||
                        !transition.to_spki_sha256.has_value() ||
                        *transition.to_generation != transition.from_generation ||
                        *transition.to_spki_sha256 != transition.from_spki_sha256) {
                        app_fail("JOURNAL_CORRUPT", "checkpoint retry is invalid");
                    }
                    active_rejection = false;
                    active_rejection_code.clear();
                    active_rejection_detail.clear();
                }
            }
            if (!delivery.transitions.empty()) {
                if (!policy.peer_generation.has_value() ||
                    !policy.peer_spki_sha256.has_value() ||
                    *policy.peer_generation != *chain_generation ||
                    *policy.peer_spki_sha256 != *chain_pin ||
                    saw_cancel != delivery.cancelled_unix_ms.has_value()) {
                    app_fail("JOURNAL_CORRUPT", "checkpoint transition endpoint is invalid");
                }
            } else if (delivery.cancelled_unix_ms.has_value()) {
                app_fail("JOURNAL_CORRUPT", "checkpoint cancellation lacks a transition");
            }
            if (active_rejection &&
                (entry.receipt.has_value() ||
                 delivery.expired_unix_ms.has_value() ||
                 delivery.cancelled_unix_ms.has_value() ||
                 delivery.last_error_code != active_rejection_code ||
                 delivery.last_error_detail != active_rejection_detail)) {
                app_fail("JOURNAL_CORRUPT", "checkpoint rejection state is invalid");
            }
        }
        outbound_index_.emplace(
            op_key(entry.record.operation_id), outbound_.size());
        outbound_.push_back(std::move(entry));
        index_outbound(outbound_.size()-1U);
    }

    for (auto& denial : decoded_denials) {
        const auto key = authorization_denial_key(denial.authorization);
        if (!valid_authorization_account(denial.authorization) ||
            denial.authorization.decision != AuthorizationDecisionKind::denied ||
            denial.authorization.peer_node != denial.issuer ||
            denial.recipient != node_id_ || !valid_scope(denial.scope) ||
            authorization_denial_index_.contains(key)) {
            app_fail("JOURNAL_CORRUPT", "checkpoint denial account is invalid");
        }
        authorization_denial_index_.emplace(key, authorization_denials_.size());
        authorization_denials_.push_back(std::move(denial));
    }

    struct CompletedCounterStep final {
        std::uint64_t before{0U};
        std::uint64_t after{0U};
    };
    std::vector<CompletedCounterStep> completed_actions;
    std::uint64_t calculated_reserved = 0U;
    for (std::size_t index = 0U; index < decoded_actions.size(); ++index) {
        auto& action = decoded_actions[index];
        const auto found = inbound_index_.find(op_key(action.action_id));
        if (found == inbound_index_.end()) {
            app_fail("JOURNAL_CORRUPT", "checkpoint action has no inbound record");
        }
        const auto& inbound = inbound_[found->second];
        const auto request = decode_counter_add_request(inbound.record.payload);
        const auto terminal_count =
            static_cast<unsigned int>(action.completed_unix_ms.has_value()) +
            static_cast<unsigned int>(action.cancelled_unix_ms.has_value()) +
            static_cast<unsigned int>(action.expired_unix_ms.has_value());
        if (action.queue_sequence != static_cast<std::uint64_t>(index) + 1U ||
            action.action_id != inbound.record.operation_id ||
            action.record_digest != inbound.record_digest ||
            !inbound.authorization.has_value() ||
            inbound.authorization->decision != AuthorizationDecisionKind::admitted ||
            inbound.authorization->operation_class !=
                AuthorizedOperationClass::counter_action ||
            inbound.authorization->resource != "counter.add" ||
            !inbound.authorization->rule_digest.has_value() ||
            action.issuer != inbound.record.issuer ||
            action.peer_generation != inbound.authorization->peer_generation ||
            action.policy_digest != inbound.authorization->policy_digest ||
            action.rule_digest != *inbound.authorization->rule_digest ||
            !is_counter_add_record(inbound.record) ||
            inbound.record.corrects.has_value() || action.amount == 0U ||
            action.amount != request.amount ||
            action.admitted_unix_ms != inbound.authorization->decided_unix_ms ||
            action.not_before_unix_ms < action.admitted_unix_ms ||
            action.expires_unix_ms <= action.admitted_unix_ms ||
            action.limits.expiry_ms == 0U ||
            action.expires_unix_ms - action.admitted_unix_ms !=
                action.limits.expiry_ms ||
            action.not_before_unix_ms - action.admitted_unix_ms !=
                request.defer_ms ||
            request.defer_ms > action.limits.maximum_defer_ms ||
            action.amount > action.limits.maximum_increment ||
            action.limits.maximum_increment > action.limits.counter_budget ||
            terminal_count > 1U ||
            (action.attempts == 0U) != !action.last_started_unix_ms.has_value() ||
            (action.last_started_unix_ms.has_value() &&
             *action.last_started_unix_ms < action.admitted_unix_ms) ||
            (!action.last_error_code.empty() &&
             !valid_error_code(action.last_error_code)) ||
            !valid_optional_text(action.cancellation_reason, 256U) ||
            !valid_optional_text(action.expiry_reason, 256U) ||
            action_index_.contains(op_key(action.action_id))) {
            app_fail("JOURNAL_CORRUPT", "checkpoint action state is invalid");
        }
        if (action.completed_unix_ms.has_value()) {
            if (action.attempts == 0U || !action.last_started_unix_ms.has_value() ||
                *action.completed_unix_ms < *action.last_started_unix_ms ||
                !action.counter_before.has_value() ||
                !action.counter_after.has_value() ||
                !action.receipt_digest.has_value() ||
                action.amount > std::numeric_limits<std::uint64_t>::max() -
                    *action.counter_before ||
                *action.counter_after != *action.counter_before + action.amount ||
                *action.counter_after > action.limits.counter_budget ||
                *action.receipt_digest != action_receipt_digest(
                    action.action_id, action.attempts,
                    *action.completed_unix_ms,
                    *action.counter_before, *action.counter_after) ||
                !action.cancellation_reason.empty() ||
                !action.expiry_reason.empty() ||
                !action.last_error_code.empty()) {
                app_fail("JOURNAL_CORRUPT", "checkpoint completed action is invalid");
            }
            completed_actions.push_back(CompletedCounterStep{
                .before = *action.counter_before,
                .after = *action.counter_after,
            });
        } else {
            if (action.counter_before.has_value() || action.counter_after.has_value() ||
                action.receipt_digest.has_value()) {
                app_fail("JOURNAL_CORRUPT", "checkpoint incomplete action has a result");
            }
            if (action.cancelled_unix_ms.has_value()) {
                if (!valid_transition_text(action.cancellation_reason, 256U) ||
                    !action.expiry_reason.empty() ||
                    (action.last_error_code != "ACTION_CANCELLED" &&
                     action.last_error_code != "ACTION_CANCELLED_CONDITIONAL")) {
                    app_fail("JOURNAL_CORRUPT", "checkpoint cancelled action is invalid");
                }
            } else if (action.expired_unix_ms.has_value()) {
                if (!valid_transition_text(action.expiry_reason, 256U) ||
                    !action.cancellation_reason.empty() ||
                    action.last_error_code != "ACTION_EXPIRED") {
                    app_fail("JOURNAL_CORRUPT", "checkpoint expired action is invalid");
                }
            } else {
                if (!action.cancellation_reason.empty() ||
                    !action.expiry_reason.empty() ||
                    action.amount > std::numeric_limits<std::uint64_t>::max() -
                        calculated_reserved) {
                    app_fail("JOURNAL_CORRUPT", "checkpoint pending action is invalid");
                }
                calculated_reserved += action.amount;
            }
        }
        action_index_.emplace(op_key(action.action_id), actions_.size());
        actions_.push_back(std::move(action));
        index_action(actions_.size() - 1U);
    }
    // Checkpoint bindings precede action reconstruction. Link once after all
    // validated actions exist; ordinary pages never scan the binding history.
    for (std::size_t i = 0U; i < configuration_bindings_.size(); ++i) index_action_binding_locked(i);
    std::sort(completed_actions.begin(), completed_actions.end(),
        [](const CompletedCounterStep& left,
           const CompletedCounterStep& right) {
            return left.before < right.before;
        });
    std::uint64_t calculated_counter = 0U;
    for (const auto& action : completed_actions) {
        if (action.before != calculated_counter) {
            app_fail("JOURNAL_CORRUPT", "checkpoint counter history has a gap");
        }
        calculated_counter = action.after;
    }
    if (calculated_counter != decoded_counter ||
        calculated_reserved != decoded_reserved) {
        app_fail("JOURNAL_CORRUPT", "checkpoint counter totals are inconsistent");
    }
    action_counter_value_ = decoded_counter;
    action_reserved_amount_ = decoded_reserved;

    // Reconstruct action-result disclosure bindings only after actions, their
    // admitted sources, and the complete outbox are available. The checkpoint
    // extension is derived state: every terminal result must independently
    // recompute to the exact ordinary outbox record and delivery policy.
    for (auto& [action_id, result] : decoded_action_results) {
        const auto key = op_key(action_id);
        if (action_results_.contains(key) ||
            !valid_action_result_binding(result.binding)) {
            app_fail("JOURNAL_CORRUPT",
                "duplicate or invalid checkpoint action-result binding");
        }
        const auto action_found = action_index_.find(key);
        const auto source_found = inbound_index_.find(key);
        if (action_found == action_index_.end() ||
            source_found == inbound_index_.end() ||
            result.binding.configuration_event > configuration_events_.size()) {
            app_fail("JOURNAL_CORRUPT",
                "checkpoint action-result source or configuration is absent");
        }
        const auto& action = actions_.at(action_found->second);
        const auto& source = inbound_.at(source_found->second);
        const auto& event = configuration_events_.at(static_cast<std::size_t>(
            result.binding.configuration_event - 1U));
        if (event.kind == "REJECTED" || action.issuer != source.record.issuer ||
            action.peer_generation != result.binding.peer_generation ||
            !source.authorization.has_value() ||
            source.authorization->decision != AuthorizationDecisionKind::admitted ||
            source.authorization->operation_class !=
                AuthorizedOperationClass::counter_action) {
            app_fail("JOURNAL_CORRUPT",
                "checkpoint action-result admission binding is invalid");
        }
        const auto historical = parse_runtime_config(event.canonical,
            "/action-result-checkpoint", IdentityFileValidation::deferred);
        const auto* rule = find_action_result_rule(historical.action_results,
            action.issuer, action.peer_generation, "counter.add");
        const auto* peer = find_peer(historical, action.issuer);
        const auto* result_generation = find_peer_generation(historical, action.issuer,
            action.peer_generation);
        if (historical.format_version < 18U) {
            app_fail("JOURNAL_CORRUPT", "checkpoint action-result requires historical V18 policy");
        }
        if (rule == nullptr) {
            app_fail("JOURNAL_CORRUPT", "checkpoint action-result rule is absent");
        }
        if (peer == nullptr || result_generation == nullptr ||
            result_generation->state != KeyGenerationState::active) {
            app_fail("JOURNAL_CORRUPT", "checkpoint action-result routed peer generation is absent");
        }
        if (historical.action_results.digest != result.binding.policy_digest) {
            app_fail("JOURNAL_CORRUPT", "checkpoint action-result policy digest differs");
        }
        if (rule->digest != result.binding.rule_digest ||
            rule->result_scope != result.binding.result_scope) {
            app_fail("JOURNAL_CORRUPT", "checkpoint action-result rule commitment differs");
        }
        if (peer->active_generation != result.binding.peer_generation ||
            peer->active_spki_sha256 != result.binding.peer_spki_sha256) {
            app_fail("JOURNAL_CORRUPT", "checkpoint action-result key binding differs");
        }
        if (peer->delivery.maximum_attempts != result.binding.maximum_attempts ||
            peer->delivery.initial_backoff_ms != result.binding.initial_backoff_ms ||
            peer->delivery.maximum_backoff_ms != result.binding.maximum_backoff_ms ||
            peer->delivery.expiry_ms != result.binding.delivery_expiry_ms) {
            app_fail("JOURNAL_CORRUPT", "checkpoint action-result delivery policy differs");
        }

        if (!result.outcome.has_value()) {
            if (!action_is_pending(action) || result.operation_id.has_value() ||
                result.record_digest.has_value()) {
                app_fail("JOURNAL_CORRUPT",
                    "pending checkpoint action-result state is invalid");
            }
            action_results_.emplace(key, std::move(result));
            index_action_result_reservation_locked(action_found->second);
            continue;
        }
        if (!result.operation_id.has_value() ||
            !result.record_digest.has_value()) {
            app_fail("JOURNAL_CORRUPT",
                "terminal checkpoint action-result identity is absent");
        }
        const auto outcome = *result.outcome;
        const bool matching_terminal =
            (outcome == ActionResultOutcome::executed &&
                action.completed_unix_ms.has_value()) ||
            (outcome == ActionResultOutcome::cancelled &&
                action.cancelled_unix_ms.has_value()) ||
            (outcome == ActionResultOutcome::expired &&
                action.expired_unix_ms.has_value());
        if (!matching_terminal) {
            app_fail("JOURNAL_CORRUPT",
                "checkpoint action-result terminal state is inconsistent");
        }
        const auto expected_record = action_result_record(
            node_id_, action, source, result.binding, outcome);
        const auto expected_policy = action_result_outbound_policy(
            result.binding, action_terminal_time(action, outcome));
        if (expected_record.operation_id != *result.operation_id ||
            evidence_record_digest(expected_record) != *result.record_digest) {
            app_fail("JOURNAL_CORRUPT",
                "checkpoint action-result record commitment is invalid");
        }
        const auto outbound_found = outbound_index_.find(
            op_key(expected_record.operation_id));
        if (outbound_found == outbound_index_.end()) {
            app_fail("JOURNAL_CORRUPT",
                "checkpoint action-result outbox record is absent");
        }
        const auto& outbound = outbound_.at(outbound_found->second);
        if (outbound.record != expected_record ||
            outbound.record_digest != *result.record_digest ||
            !outbound.delivery.has_value() ||
            outbound.delivery->policy != expected_policy) {
            app_fail("JOURNAL_CORRUPT",
                "checkpoint action-result outbox binding is invalid");
        }
        outbox_associations_[op_key(expected_record.operation_id)] =
            std::string("{\"kind\":\"ACTION_RESULT\",\"action_id\":") +
            json_string(key) + ",\"outcome\":" +
            json_string(action_result_outcome_name(outcome)) +
            ",\"result_scope\":" +
            json_string(result.binding.result_scope) +
            ",\"configuration_event\":" +
            std::to_string(result.binding.configuration_event) +
            ",\"local_result_receipt\":" +
            (action.receipt_digest.has_value() ?
                json_string(datacube::hex_lower(*action.receipt_digest)) :
                std::string("null")) + "}";
        action_result_operations_.emplace(op_key(expected_record.operation_id),
            result.binding.reserved_payload_bytes != 0U);
        action_results_.emplace(key, std::move(result));
    }

    recoveries_ = std::move(decoded_recoveries);
    for (const auto& [name, value] : consumers_) {
        static_cast<void>(name); validate_consumer_locked(value); validate_projection_locked(value, true); validate_consumer_retirement_locked(value);
        if(value.transition=="AUTO_PROJECT" && !projection_schedules_.contains(consumer_key(value.uid,value.name))){
            app_fail("JOURNAL_CORRUPT","automatic checkpoint result is missing its scheduling grant");
        }
    }
    validate_consumer_registry_locked();
    for(const auto& [key,value]:projection_schedules_){static_cast<void>(key);validate_projection_schedule_locked(value);}
    validate_publication_channel_registry_locked();
    validate_source_subscription_registry_locked();
    validate_source_subscriptions_locked();
    rebuild_source_subscription_commitments_locked();

    for(const auto& events:decoded_import_histories){
        if(import_schedules_.contains(events.front().view))app_fail("JOURNAL_CORRUPT","duplicate import schedule");
        for(const auto& e:events)apply_import_auto_event(encode_import_auto_event(e),true);
    }
    validate_retired_import_prefixes_locked();
    for(const auto& [key, value]:publication_channels_) { static_cast<void>(key); index_outbound_associations(value); }
    for(const auto& [key, value]:source_subscriptions_) { static_cast<void>(key); index_outbound_associations(value); }
    for(const auto& item:inbound_){
        if(item.subscribed_source && item.subscribed_source->executor_uid){
            const auto& a=*item.subscribed_source;const auto schedule=import_schedules_.find(a.view);
            if(schedule==import_schedules_.end()||a.automation_revision==0U||a.automation_revision>schedule->second.history.size())app_fail("JOURNAL_CORRUPT","automatic import missing history");
            const auto& event=schedule->second.history[static_cast<std::size_t>(a.automation_revision-1U)];
            if(event.outcome!="IMPORTED"||event.inbound_count+1U!=item.sequence)app_fail("JOURNAL_CORRUPT","automatic effect missing exact event");
        }
    }

    validate_outbox_administration_checkpoint();
    validate_action_administration_checkpoint();
    for (const auto& bytes : decoded_result_reviews) apply_result_review(bytes, true);
    const auto retained = static_cast<std::uint64_t>(inbound_.size()) +
        static_cast<std::uint64_t>(outbound_.size()) +
        static_cast<std::uint64_t>(authorization_denials_.size()) +
        static_cast<std::uint64_t>(actions_.size()) +
        static_cast<std::uint64_t>(recoveries_.size()) +
        static_cast<std::uint64_t>(migrations_.size()) +
        static_cast<std::uint64_t>(configuration_events_.size()) +
        static_cast<std::uint64_t>(configuration_bindings_.size()) +
        static_cast<std::uint64_t>(local_control_events_.size()) +
        static_cast<std::uint64_t>(lifecycle_events_.size()) +
        static_cast<std::uint64_t>(consumers_.size()) +
        static_cast<std::uint64_t>(projection_schedules_.size()) +
        static_cast<std::uint64_t>(publication_channels_.size()) +
        static_cast<std::uint64_t>(source_subscriptions_.size()) + static_cast<std::uint64_t>(import_schedules_.size()) + static_cast<std::uint64_t>(outbox_administration_.size()) + static_cast<std::uint64_t>(action_administration_.size()) + static_cast<std::uint64_t>(action_results_.size()) + static_cast<std::uint64_t>(result_reviews_.size()) +
        static_cast<std::uint64_t>(custody_registry_.events().size());
    if (retained != expected_retained ||
        canonical_logical_state_locked() != datacube::Octets(
            logical.begin(), logical.end())) {
        app_fail("JOURNAL_CORRUPT", "checkpoint logical state is not canonical");
    }

    maintenance_generation_ = generation;
    last_compaction_unix_ms_ = compacted;
    last_compaction_before_bytes_ = before_bytes;
    last_compaction_after_bytes_ = after_bytes;
    last_compaction_retained_records_ = compaction_retained;
    restored_backup_id_ = backup_id;
    restored_backup_generation_ = std::move(backup_generation);
    restored_backup_unix_ms_ = backup_time;

    if (compacted.has_value() && publication_account_current) {
        const auto encoded = frame_for(
            static_cast<std::uint8_t>(EntryKind::checkpoint), payload);
        if (after_bytes != encoded.size() + authenticated_checkpoint_overhead_ || compaction_retained != retained) {
            app_fail("JOURNAL_CORRUPT", "checkpoint publication account is invalid");
        }
    }
}


void NodeState::append_entry(
    EntryKind kind,
    datacube::OctetView payload,
    const SourceProgressPreparation* prepared,
    const ParsedSourceProgress* parsed) {
    if ((prepared || parsed) && kind != EntryKind::source_subscription) {
        app_fail("JOURNAL_CORRUPT", "source preparation on unrelated journal append");
    }
    // Reject changed bytes or a changed command origin before constructing or
    // writing a frame. This is not a substitute for either semantic pass.
    if (parsed) { validate_parsed_source_progress_locked(payload, *parsed, true); }
    datacube::Octets bound;
    const auto active = active_configuration_event(configuration_events_);
    if (active != 0U && kind != EntryKind::runtime_configuration &&
        kind != EntryKind::checkpoint && kind != EntryKind::schema_migrated &&
        kind != EntryKind::backup_restored && kind != EntryKind::local_control_event &&
        kind != EntryKind::lifecycle_event && kind != EntryKind::consumer_update && kind != EntryKind::projection_schedule && kind != EntryKind::consumer_retirement && kind != EntryKind::publication_channel && kind != EntryKind::local_authored && kind != EntryKind::source_subscription && kind != EntryKind::subscribed_source && kind != EntryKind::import_schedule && kind != EntryKind::outbox_administration && kind != EntryKind::action_administration && kind != EntryKind::result_review) {
        if (configuration_bindings_.size() >= 1'000'000U) {
            app_fail("CONFIG_BINDING_LIMIT", "configuration provenance limit reached");
        }
        datacube::append_be64(bound, static_cast<std::uint64_t>(active));
        datacube::append_u8(bound, static_cast<std::uint8_t>(kind));
        datacube::append_octets(bound, payload);
        payload = bound;
        kind = EntryKind::runtime_bound_mutation;
    }
    if (terminal_sealed_) app_fail("STATE_TERMINAL", "no append after terminal head sampling");
    if (poisoned_) {
        app_fail("STATE_RESTART_REQUIRED",
            "a previous journal mutation failed; restart to reconstruct durable state");
    }
    if (payload.size() + 1U >
        static_cast<std::size_t>(kMaximumJournalBodyBytes)) {
        app_fail("JOURNAL_RECORD_TOO_LARGE", "journal record exceeds envelope");
    }
    datacube::Octets body;
    body.reserve(payload.size() + 1U);
    datacube::append_u8(body, static_cast<std::uint8_t>(kind));
    datacube::append_octets(body, payload);
    const auto body_checksum = checksum(body);

    datacube::Octets frame;
    frame.reserve(8U + body.size() + body_checksum.octets.size());
    datacube::append_octets(frame, kJournalMagic);
    datacube::append_be32(frame, static_cast<std::uint32_t>(body.size()));
    datacube::append_octets(frame, body);
    datacube::append_octets(frame, body_checksum.octets);

    auto next_authentication = authentication_;
    if (next_authentication) {
        frame = authenticate_next_frame(frame, auth_key_, *next_authentication);
    }
    if (static_cast<std::uint64_t>(frame.size()) >
        maximum_journal_bytes_ - journal_bytes_) {
        app_fail("STATE_CAPACITY_EXCEEDED",
            "journal capacity would be exceeded");
    }
    try {
        // Fault injection only when explicitly enabled in a disposable test.
        // The prefix is actually written and synchronized before the process is killed.
        if (authentication_ && std::getenv("NATRAV_OVERLAY_TEST_STATE_AUTH_PARTIAL_APPEND_MS")) {
            const auto cut = std::min<std::size_t>(60U, frame.size() - 1U);
            write_all(journal_fd_.get(), datacube::OctetView(frame).first(cut));
            if (::fdatasync(journal_fd_.get()) != 0) { app_fail("JOURNAL_SYNC_FAILED", "test partial append sync failed"); }
            state_auth_test_pause("PARTIAL_APPEND");
            write_all(journal_fd_.get(), datacube::OctetView(frame).subspan(cut));
        } else {
            write_all(journal_fd_.get(), frame);
        }
        if (::fdatasync(journal_fd_.get()) != 0) {
            app_fail("JOURNAL_SYNC_FAILED",
                datacube::errno_detail("state.journal", errno));
        }
        journal_bytes_ += static_cast<std::uint64_t>(frame.size());
        authentication_ = std::move(next_authentication);
        if (parsed) { mark_parsed_source_progress_published_locked(*parsed); }
        apply_entry(kind, payload, false, prepared, parsed);
        if (parsed) { validate_parsed_source_progress_applied_locked(*parsed); }
    } catch (...) {
        poisoned_ = true;
        throw;
    }
}

void NodeState::append_recovery(
    const std::uint64_t discarded,
    const std::uint64_t valid_prefix) {
    const auto payload = recovery_payload(discarded, valid_prefix);
    append_entry(EntryKind::recovery, payload);
}

void NodeState::validate_new_outbound_locked(
    const EvidenceRecord& record, const OutboundPolicy& policy,
    const std::optional<std::size_t> converting_action) const {
    validate_initial_outbound_policy(policy);
    validate_evidence_record(record);
    if (record.issuer != node_id_) {
        app_fail("OUTBOUND_ISSUER_MISMATCH",
            "record issuer must match the local node ID");
    }
    const auto key = op_key(record.operation_id);
    if (outbound_index_.contains(key)) {
        app_fail("OUTBOUND_OPERATION_CONFLICT",
            "operation ID is already queued");
    }
    std::uint64_t credit = 0U;
    if (converting_action.has_value()) {
        const auto& action = actions_.at(*converting_action);
        const auto result = action_results_.find(op_key(action.action_id));
        if (result == action_results_.end() || result->second.outcome ||
            !action_is_pending(action) || action.issuer != record.recipient) {
            app_fail("ACTION_RESULT_RESERVATION_INVALID", "invalid result conversion source");
        }
        credit = result->second.binding.reserved_payload_bytes;
        if (credit != 0U && (!future_result_capacity_.matches(*converting_action,
                action.issuer, credit) || credit != action_result_reservation_bytes(result->second.binding))) {
            app_fail("ACTION_RESULT_RESERVATION_INVALID", "exact reserved contribution is absent");
        }
    }
    require_outbox_capacity(
        queue_limits_, pending_capacity_, record.recipient,
        static_cast<std::uint64_t>(record.payload.size()), future_result_capacity_, credit);
}

QueueResult NodeState::queue_outbound_locked(
    const EvidenceRecord& record,
    const std::optional<OutboundPolicy>& initial_policy) {
    if (initial_policy.has_value()) { validate_initial_outbound_policy(*initial_policy); }
    validate_evidence_record(record);
    if (record.issuer != node_id_) {
        app_fail("OUTBOUND_ISSUER_MISMATCH",
            "record issuer must match the local node ID");
    }
    const auto digest = evidence_record_digest(record);
    if (active_submission_work) {
        active_submission_work->digest_payload_bytes += record.payload.size();
    }
    const auto result_for = [&](const std::size_t index, const QueueDisposition disposition) {
        const auto& stored = outbound_.at(index);
        if (active_submission_work) {
            ++active_submission_work->queue_metadata_records;
            if (stored.receipt) active_submission_work->receipt_text_bytes_copied +=
                stored.receipt->recipient.size() + stored.receipt->recorder.size();
        }
        return QueueResult{
            .disposition = disposition,
            .operation_id = stored.record.operation_id,
            .record_digest = stored.record_digest,
            .status = outbound_status_name(stored),
            .has_delivery_policy = stored.delivery.has_value(),
            .receipt = stored.receipt,
        };
    };
    const auto key = op_key(record.operation_id);
    const auto found = outbound_index_.find(key);
    if (found != outbound_index_.end()) {
        const auto index = found->second;
        const auto& existing = outbound_[index];
        if (existing.record_digest != digest) {
            app_fail("OUTBOUND_OPERATION_CONFLICT",
                "operation ID is already queued with different content");
        }
        if (existing.delivery && existing.delivery->expired_unix_ms) {
            app_fail("OUTBOUND_EXPIRED",
                "operation has an expired durable delivery obligation");
        }
        if (existing.delivery && existing.delivery->cancelled_unix_ms) {
            app_fail("OUTBOUND_CANCELLED",
                "operation has a cancelled durable delivery obligation");
        }
        // Older, unbound queued operations acquire their first policy under the
        // same owner lock. A concurrent duplicate/scheduler cannot choose a
        // different timestamp between the observation and initialization. Never
        // overwrite any existing policy, rejection, key binding or receipt.
        if (initial_policy && !existing.delivery && !existing.receipt) {
            const auto policy_bytes = outbound_policy_payload(record.operation_id, *initial_policy);
            if (active_submission_work) active_submission_work->enqueue_journal_payload_bytes += policy_bytes.size();
            append_entry(EntryKind::outbound_policy, policy_bytes);
        }
        // No references survive append_entry: replay owns the stored objects.
        const auto status = outbound_status_name(outbound_.at(index));
        return result_for(index, status == "REJECTED" ? QueueDisposition::already_rejected :
            status == "ACKED" ? QueueDisposition::already_acked : QueueDisposition::already_pending);
    }
    require_outbox_capacity(
        queue_limits_, pending_capacity_, record.recipient,
        static_cast<std::uint64_t>(record.payload.size()), future_result_capacity_);
    const auto payload = encode_application_message(record);
    if (active_submission_work) active_submission_work->encoded_application_bytes += payload.size();
    if (initial_policy.has_value()) {
        // Operation and first policy retain the existing single durable commit.
        datacube::Octets composite;
        append_digest(composite, record.operation_id);
        datacube::append_be32(composite, static_cast<std::uint32_t>(payload.size()));
        datacube::append_octets(composite, payload);
        datacube::append_octets(composite,
            outbound_policy_payload(record.operation_id, *initial_policy));
        if (active_submission_work) active_submission_work->enqueue_journal_payload_bytes += composite.size();
        append_entry(EntryKind::outbound_queued_with_policy, composite);
    } else {
        if (active_submission_work) active_submission_work->enqueue_journal_payload_bytes += payload.size();
        append_entry(EntryKind::outbound_queued, payload);
    }
    return result_for(outbound_index_.at(key), QueueDisposition::queued);
}

QueueResult NodeState::queue_outbound(
    const EvidenceRecord& record,
    const std::optional<OutboundPolicy>& initial_policy) {
    std::lock_guard<std::mutex> lock(mutex_);
    return queue_outbound_locked(record, initial_policy);
}

SubmissionObservation NodeState::observe_submission(
    const datacube::Digest32& operation_id,
    const datacube::Digest32& expected_record_digest) const {
    std::lock_guard<std::mutex> lock(mutex_);
    if (poisoned_) app_fail("STATE_POISONED", "writer is poisoned; restart required");
    const auto found = outbound_index_.find(op_key(operation_id));
    if (found == outbound_index_.end()) {
        app_fail("OUTBOUND_NOT_FOUND", "submitted operation is not present in the outbox");
    }
    const auto& entry = outbound_.at(found->second);
    if (entry.record.operation_id != operation_id || entry.record_digest != expected_record_digest) {
        app_fail("SUBMISSION_OBSERVATION_CONFLICT", "reply must observe the exact enqueued record");
    }
    SubmissionObservation result{
        .operation_id = entry.record.operation_id,
        .record_digest = entry.record_digest,
        .recipient = entry.record.recipient,
        .operation_class = operation_class_for(entry.record),
        .resource = authorization_resource_for(entry.record),
        .status = outbound_status_name(entry),
    };
    if (active_submission_work) {
        ++active_submission_work->observation_metadata_records;
        active_submission_work->observation_text_bytes_copied += result.recipient.size() + result.resource.size();
    }
    return result;
}

void NodeState::ensure_outbound_policy(
    const datacube::Digest32& operation_id,
    const OutboundPolicy& policy) {
    validate_initial_outbound_policy(policy);
    const auto key = op_key(operation_id);
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = outbound_index_.find(key);
    if (found == outbound_index_.end()) {
        app_fail("OUTBOUND_NOT_FOUND", "operation is not in the local outbox");
    }
    auto& existing = outbound_[found->second];
    if (existing.receipt.has_value()) {
        return;
    }
    if (existing.delivery.has_value()) {
        if (existing.delivery->policy != policy) {
            app_fail("OUTBOUND_POLICY_CONFLICT",
                "operation already has a different durable delivery policy");
        }
        return;
    }
    const auto payload = outbound_policy_payload(operation_id, policy);
    append_entry(EntryKind::outbound_policy, payload);
}

DeliverySelection NodeState::select_delivery(const RuntimeConfig& config,
    const std::string& recipient, const std::uint64_t now) const {
    const bool routed = find_peer(config, recipient) != nullptr;
    std::vector<DeliveryBinding> permitted;
    // At most eight configured generations per peer. Missing/revoked historical
    // bindings are not selectable; their expiry remains independently indexed.
    const auto first = std::lower_bound(config.peer_generations.begin(), config.peer_generations.end(), recipient,
        [](const PeerKeyGeneration& key, const std::string& id) { return key.node_id < id; });
    for (auto it = first; it != config.peer_generations.end() && it->node_id == recipient; ++it) {
        if (it->state != KeyGenerationState::revoked)
            permitted.emplace_back(it->generation, operation_id_text(it->spki_sha256));
    }
    std::lock_guard lock(mutex_);
    if (poisoned_) app_fail("STATE_POISONED", "writer is poisoned; restart required");
    const auto choice = delivery_index_.select(recipient, permitted, now, routed);
    DeliverySelection result;
    result.kind = choice.kind; result.next_wake = choice.next_wake;
    result.tree_nodes_visited = choice.tree_nodes_visited;
    result.key_buckets_checked = choice.key_buckets_checked;
    if (!choice.index) return result;
    result.index = *choice.index;
    const auto& entry = outbound_.at(result.index);
    result.metadata_records_read = 1U;
    result.operation_id = entry.record.operation_id; result.record_digest = entry.record_digest;
    result.recipient = entry.record.recipient;
    result.version = outbox_inspection_index_.revision(result.index);
    result.configuration_event = static_cast<std::uint64_t>(active_configuration_event(configuration_events_));
    // Exact NOA1 encoded record length; no payload access/copy/encoding needed.
    result.encoded_bytes = 4U + 1U + 32U + 6U + entry.record.issuer.size() +
        entry.record.recipient.size() + entry.record.scope.size() +
        (entry.record.corrects ? 32U : 0U) + 4U + entry.record.payload.size();
    if (entry.delivery) {
        result.policy = entry.delivery->policy; result.attempts = entry.delivery->attempts;
        result.next_attempt = entry.delivery->next_attempt_unix_ms;
    }
    return result;
}

bool NodeState::delivery_selection_matches_locked(const DeliverySelection& selected) const {
    if (poisoned_) app_fail("STATE_POISONED", "writer is poisoned; restart required");
    if (selected.index >= outbound_.size()) return false;
    const auto& entry = outbound_[selected.index];
    return outbox_inspection_index_.revision(selected.index) == selected.version &&
        outbox_inspection_index_.state(selected.index) == "PENDING" &&
        entry.record.operation_id == selected.operation_id && entry.record_digest == selected.record_digest &&
        entry.record.recipient == selected.recipient;
}

bool NodeState::maintain_selected_delivery(const DeliverySelection& selected,
    const std::uint64_t now, const std::optional<OutboundPolicy>& initial_policy) {
    std::lock_guard lock(mutex_);
    if (!delivery_selection_matches_locked(selected)) return false;
    const auto& entry = outbound_[selected.index];
    if (selected.kind == DeliveryChoiceKind::initialize_policy) {
        if (entry.delivery || !initial_policy) return false;
        validate_initial_outbound_policy(*initial_policy);
        const auto payload = outbound_policy_payload(selected.operation_id, *initial_policy);
        append_entry(EntryKind::outbound_policy, payload); return true;
    }
    if (!entry.delivery) return false;
    const auto& delivery = *entry.delivery;
    std::string_view reason;
    if (now >= delivery.policy.expires_unix_ms) reason = "DELIVERY_EXPIRED";
    else if (selected.kind == DeliveryChoiceKind::attempts_exhausted &&
             delivery.attempts >= delivery.policy.maximum_attempts) reason = "ATTEMPT_LIMIT";
    else return false;
    const auto payload = outbound_expired_payload(selected.operation_id, now, reason);
    append_entry(EntryKind::outbound_expired, payload); return true;
}

bool NodeState::selected_delivery_is_current(const DeliverySelection& selected, const std::uint64_t now) const {
    std::lock_guard lock(mutex_);
    if (!delivery_selection_matches_locked(selected)) return false;
    const auto& entry = outbound_[selected.index];
    return entry.delivery && selected.policy && entry.delivery->policy == *selected.policy &&
        entry.delivery->attempts == selected.attempts && now >= entry.delivery->next_attempt_unix_ms &&
        now < entry.delivery->policy.expires_unix_ms &&
        entry.delivery->attempts < entry.delivery->policy.maximum_attempts;
}

bool NodeState::begin_selected_delivery(DeliverySelection& selected,
    const std::uint64_t now, const std::uint64_t next_attempt) {
    std::lock_guard lock(mutex_);
    if (!delivery_selection_matches_locked(selected)) return false;
    const auto& entry = outbound_[selected.index];
    if (!entry.delivery || !selected.policy || entry.delivery->policy != *selected.policy ||
        entry.delivery->attempts != selected.attempts || now < entry.delivery->next_attempt_unix_ms ||
        now >= entry.delivery->policy.expires_unix_ms ||
        entry.delivery->attempts >= entry.delivery->policy.maximum_attempts) return false;
    begin_outbound_attempt_locked(selected.operation_id, now, next_attempt);
    selected.version = outbox_inspection_index_.revision(selected.index);
    ++selected.attempts; selected.next_attempt = next_attempt;
    return true;
}

std::optional<EvidenceRecord> NodeState::copy_selected_delivery(const DeliverySelection& selected) const {
    std::lock_guard lock(mutex_);
    if (!delivery_selection_matches_locked(selected)) return std::nullopt;
    const auto& entry = outbound_[selected.index];
    if (!entry.delivery || !selected.policy || entry.delivery->policy != *selected.policy ||
        entry.delivery->attempts != selected.attempts ||
        entry.delivery->next_attempt_unix_ms != selected.next_attempt ||
        entry.delivery->last_error_code != "ATTEMPT_INTERRUPTED") return std::nullopt;
    // The only scheduler payload copy. The peer-transition lock remains held
    // across this check and the bounded application exchange.
    return entry.record;
}

void NodeState::begin_outbound_attempt(
    const datacube::Digest32& operation_id,
    const std::uint64_t attempted_unix_ms,
    const std::uint64_t next_attempt_unix_ms) {
    std::lock_guard<std::mutex> lock(mutex_);
    begin_outbound_attempt_locked(operation_id, attempted_unix_ms, next_attempt_unix_ms);
}

void NodeState::begin_outbound_attempt_locked(
    const datacube::Digest32& operation_id,
    const std::uint64_t attempted_unix_ms,
    const std::uint64_t next_attempt_unix_ms) {
    const auto key = op_key(operation_id);
    const auto found = outbound_index_.find(key);
    if (found == outbound_index_.end()) {
        app_fail("OUTBOUND_NOT_FOUND", "attempt operation is not queued");
    }
    auto& existing = outbound_[found->second];
    if (!existing.delivery.has_value()) {
        app_fail("OUTBOUND_POLICY_MISSING", "delivery policy is absent");
    }
    if (existing.receipt.has_value()) {
        app_fail("OUTBOUND_ALREADY_ACKED", "operation already has a receipt");
    }
    if (existing.delivery->expired_unix_ms.has_value()) {
        app_fail("OUTBOUND_EXPIRED", "operation is already expired");
    }
    if (existing.delivery->cancelled_unix_ms.has_value()) {
        app_fail("OUTBOUND_CANCELLED", "operation is already cancelled");
    }
    if (active_outbound_rejection(existing).has_value()) {
        app_fail("OUTBOUND_REJECTED",
            "operation has a terminal authenticated peer rejection");
    }
    if (existing.delivery->attempts >=
        existing.delivery->policy.maximum_attempts) {
        app_fail("OUTBOUND_ATTEMPT_LIMIT", "attempt budget is exhausted");
    }
    if (attempted_unix_ms == 0U || next_attempt_unix_ms < attempted_unix_ms) {
        app_fail("INVALID_OUTBOUND_ATTEMPT", "attempt timestamps are invalid");
    }
    const auto attempt = existing.delivery->attempts + 1U;
    const auto payload = outbound_attempt_payload(
        operation_id, attempt, attempted_unix_ms, next_attempt_unix_ms);
    append_entry(EntryKind::outbound_attempt, payload);
}

void NodeState::record_outbound_failure(
    const datacube::Digest32& operation_id,
    const std::string_view code,
    const std::string_view detail,
    const std::uint64_t next_attempt_unix_ms) {
    if (!valid_error_code(code)) {
        app_fail("INVALID_OUTBOUND_FAILURE", "failure code is invalid");
    }
    std::string safe_detail;
    safe_detail.reserve(std::min<std::size_t>(detail.size(), 512U));
    for (const char raw : detail) {
        if (safe_detail.size() == 512U) { break; }
        const auto ch = static_cast<unsigned char>(raw);
        safe_detail.push_back(ch == 9U || (ch >= 32U && ch <= 126U) ? raw : '?');
    }
    const auto key = op_key(operation_id);
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = outbound_index_.find(key);
    if (found == outbound_index_.end()) {
        app_fail("OUTBOUND_NOT_FOUND", "failure operation is not queued");
    }
    auto& existing = outbound_[found->second];
    if (!existing.delivery.has_value() || existing.delivery->attempts == 0U) {
        app_fail("OUTBOUND_ATTEMPT_MISSING", "failure has no begun attempt");
    }
    if (existing.receipt.has_value() ||
        existing.delivery->expired_unix_ms.has_value() ||
        existing.delivery->cancelled_unix_ms.has_value() ||
        active_outbound_rejection(existing).has_value()) {
        app_fail("OUTBOUND_NOT_PENDING", "failure operation is not pending");
    }
    if (existing.delivery->next_attempt_unix_ms != next_attempt_unix_ms) {
        app_fail("OUTBOUND_FAILURE_CONFLICT",
            "failure next-attempt time does not match the begun attempt");
    }
    const auto payload = outbound_failure_payload(
        operation_id,
        existing.delivery->attempts,
        next_attempt_unix_ms,
        code,
        safe_detail);
    append_entry(EntryKind::outbound_failure, payload);
}

void NodeState::record_outbound_rejection(
    const datacube::Digest32& operation_id,
    const std::string_view code,
    const std::string_view detail,
    const std::uint64_t rejected_unix_ms,
    const std::string_view authenticated_generation,
    const datacube::Digest32& authenticated_spki_sha256) {
    if (!authenticated_peer_error_is_terminal(code) ||
        rejected_unix_ms == 0U ||
        !valid_generation_id(authenticated_generation) ||
        digest_is_zero(authenticated_spki_sha256)) {
        app_fail("INVALID_OUTBOUND_REJECTION",
            "rejection must be an exact terminal authenticated peer decision");
    }
    const auto safe_detail = bounded_rejection_detail(detail);
    const auto key = op_key(operation_id);
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = outbound_index_.find(key);
    if (found == outbound_index_.end()) {
        app_fail("OUTBOUND_NOT_FOUND", "rejection operation is not queued");
    }
    auto& existing = outbound_[found->second];
    if (!existing.delivery.has_value() || existing.delivery->attempts == 0U ||
        !existing.delivery->last_attempt_unix_ms.has_value()) {
        app_fail("OUTBOUND_ATTEMPT_MISSING",
            "rejection has no synchronized begun attempt");
    }
    if (existing.receipt.has_value() ||
        existing.delivery->expired_unix_ms.has_value() ||
        existing.delivery->cancelled_unix_ms.has_value()) {
        app_fail("OUTBOUND_NOT_PENDING", "rejection operation is not pending");
    }
    if (active_outbound_rejection(existing).has_value()) {
        app_fail("OUTBOUND_ALREADY_REJECTED",
            "operation already has a durable terminal rejection");
    }
    const auto& generation = existing.delivery->policy.peer_generation;
    const auto& pin = existing.delivery->policy.peer_spki_sha256;
    if (!generation.has_value() || !pin.has_value() ||
        *generation != authenticated_generation ||
        *pin != authenticated_spki_sha256) {
        app_fail("OUTBOUND_REJECTION_BINDING_MISMATCH",
            "authenticated rejection does not match the durable peer generation");
    }
    if (rejected_unix_ms < *existing.delivery->last_attempt_unix_ms ||
        existing.delivery->last_error_code != "ATTEMPT_INTERRUPTED") {
        app_fail("OUTBOUND_REJECTION_CONFLICT",
            "rejection does not resolve the current begun attempt");
    }
    const auto policy_digest = outbound_policy_digest(existing.delivery->policy);
    const auto payload = outbound_rejected_payload(
        operation_id,
        existing.delivery->attempts,
        rejected_unix_ms,
        code,
        safe_detail,
        authenticated_generation,
        authenticated_spki_sha256,
        policy_digest);
    append_entry(EntryKind::outbound_rejected, payload);
}

void NodeState::retry_outbound(
    const datacube::Digest32& operation_id,
    const std::uint64_t retried_unix_ms,
    const std::string_view actor,
    const std::string_view reason) {
    if (retried_unix_ms == 0U ||
        !valid_transition_text(actor, 64U) ||
        !valid_transition_text(reason, 256U)) {
        app_fail("INVALID_OUTBOUND_RETRY",
            "retry requires a time, actor, and printable reason");
    }
    const auto key = op_key(operation_id);
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = outbound_index_.find(key);
    if (found == outbound_index_.end()) {
        app_fail("OUTBOUND_NOT_FOUND", "retry operation is not queued");
    }
    auto& existing = outbound_[found->second];
    if (!existing.delivery.has_value()) {
        app_fail("OUTBOUND_POLICY_MISSING", "retry policy is absent");
    }
    if (existing.receipt.has_value() ||
        existing.delivery->expired_unix_ms.has_value() ||
        existing.delivery->cancelled_unix_ms.has_value()) {
        app_fail("OUTBOUND_NOT_RETRYABLE",
            "only a rejected nonterminally-resolved obligation can be retried");
    }
    const auto rejection = active_outbound_rejection(existing);
    if (!rejection.has_value()) {
        app_fail("OUTBOUND_NOT_REJECTED",
            "operation has no active terminal peer rejection");
    }
    require_outbox_capacity(
        queue_limits_, pending_capacity_, existing.record.recipient,
        static_cast<std::uint64_t>(existing.record.payload.size()), future_result_capacity_);
    const auto& generation = existing.delivery->policy.peer_generation;
    const auto& pin = existing.delivery->policy.peer_spki_sha256;
    if (!generation.has_value() || !pin.has_value()) {
        app_fail("OUTBOUND_KEY_BINDING_REQUIRED",
            "operation predates generation-bound delivery");
    }
    const auto payload = outbound_retried_payload(
        operation_id, retried_unix_ms, actor, reason, *generation, *pin);
    append_entry(EntryKind::outbound_retried, payload);
}

void NodeState::expire_outbound(
    const datacube::Digest32& operation_id,
    const std::uint64_t expired_unix_ms,
    const std::string_view reason) {
    if (expired_unix_ms == 0U || !valid_error_code(reason)) {
        app_fail("INVALID_OUTBOUND_EXPIRY", "expiry record is invalid");
    }
    const auto key = op_key(operation_id);
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = outbound_index_.find(key);
    if (found == outbound_index_.end()) {
        app_fail("OUTBOUND_NOT_FOUND", "expiry operation is not queued");
    }
    auto& existing = outbound_[found->second];
    if (!existing.delivery.has_value()) {
        app_fail("OUTBOUND_POLICY_MISSING", "expiry policy is absent");
    }
    if (existing.receipt.has_value()) {
        app_fail("OUTBOUND_ALREADY_ACKED", "acked operation cannot expire");
    }
    if (existing.delivery->cancelled_unix_ms.has_value()) {
        app_fail("OUTBOUND_CANCELLED", "cancelled operation cannot expire");
    }
    if (active_outbound_rejection(existing).has_value()) {
        app_fail("OUTBOUND_REJECTED", "rejected operation cannot expire");
    }
    if (existing.delivery->expired_unix_ms.has_value()) {
        return;
    }
    const auto payload = outbound_expired_payload(
        operation_id, expired_unix_ms, reason);
    append_entry(EntryKind::outbound_expired, payload);
}

void NodeState::rebind_outbound(
    const datacube::Digest32& operation_id,
    const std::string_view new_generation,
    const datacube::Digest32& new_spki_sha256,
    const std::uint64_t rebound_unix_ms,
    const std::string_view actor,
    const std::string_view reason) {
    require_generation_id(new_generation, "new peer key generation");
    if (digest_is_zero(new_spki_sha256) || rebound_unix_ms == 0U ||
        !valid_transition_text(actor, 64U) ||
        !valid_transition_text(reason, 256U)) {
        app_fail("INVALID_OUTBOUND_REBIND",
            "rebind requires a nonzero key, time, actor, and printable reason");
    }
    const auto key = op_key(operation_id);
    std::lock_guard<std::mutex> lock(mutex_);
    if (action_result_operations_.contains(key)) {
        app_fail("OUTBOUND_ACTION_RESULT_BOUND", "result disclosure remains bound to its admitted recipient generation");
    }
    for (const auto& [id, subscription] : source_subscriptions_) {
        static_cast<void>(id);
        if (std::any_of(subscription.deliveries.begin(), subscription.deliveries.end(),
            [&](const auto& d) { return d.operation == operation_id; })) {
            app_fail("OUTBOUND_SOURCE_SUBSCRIPTION_BOUND", "source disclosure cannot be rebound beyond its grant generation");
        }
    }
    const auto found = outbound_index_.find(key);
    if (found == outbound_index_.end()) {
        app_fail("OUTBOUND_NOT_FOUND", "rebind operation is not queued");
    }
    auto& existing = outbound_[found->second];
    if (!existing.delivery.has_value()) {
        app_fail("OUTBOUND_POLICY_MISSING", "rebind policy is absent");
    }
    if (existing.receipt.has_value()) {
        app_fail("OUTBOUND_ALREADY_ACKED", "acked operation cannot be rebound");
    }
    if (existing.delivery->expired_unix_ms.has_value()) {
        app_fail("OUTBOUND_EXPIRED", "expired operation cannot be rebound");
    }
    if (existing.delivery->cancelled_unix_ms.has_value()) {
        app_fail("OUTBOUND_CANCELLED", "cancelled operation cannot be rebound");
    }
    const auto& old_generation = existing.delivery->policy.peer_generation;
    const auto& old_pin = existing.delivery->policy.peer_spki_sha256;
    if (!old_generation.has_value() || !old_pin.has_value()) {
        app_fail("OUTBOUND_KEY_BINDING_REQUIRED",
            "operation predates generation-bound delivery");
    }
    if (*old_generation == new_generation && *old_pin == new_spki_sha256) {
        app_fail("OUTBOUND_BINDING_UNCHANGED",
            "new generation is identical to the current durable binding");
    }
    if (active_outbound_rejection(existing).has_value()) {
        require_outbox_capacity(
            queue_limits_, pending_capacity_,
            existing.record.recipient,
            static_cast<std::uint64_t>(existing.record.payload.size()), future_result_capacity_);
    }
    const auto payload = outbound_rebound_payload(
        operation_id, rebound_unix_ms, actor, reason,
        *old_generation, *old_pin, new_generation, new_spki_sha256);
    append_entry(EntryKind::outbound_rebound, payload);
}

void NodeState::cancel_outbound(
    const datacube::Digest32& operation_id,
    const std::uint64_t cancelled_unix_ms,
    const std::string_view actor,
    const std::string_view reason) {
    if (cancelled_unix_ms == 0U ||
        !valid_transition_text(actor, 64U) ||
        !valid_transition_text(reason, 256U)) {
        app_fail("INVALID_OUTBOUND_CANCELLATION",
            "cancellation requires a time, actor, and printable reason");
    }
    const auto key = op_key(operation_id);
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = outbound_index_.find(key);
    if (found == outbound_index_.end()) {
        app_fail("OUTBOUND_NOT_FOUND", "cancellation operation is not queued");
    }
    auto& existing = outbound_[found->second];
    if (!existing.delivery.has_value()) {
        app_fail("OUTBOUND_POLICY_MISSING", "cancellation policy is absent");
    }
    if (existing.receipt.has_value()) {
        app_fail("OUTBOUND_ALREADY_ACKED", "acked operation cannot be cancelled");
    }
    if (existing.delivery->expired_unix_ms.has_value()) {
        app_fail("OUTBOUND_EXPIRED", "expired operation cannot be cancelled");
    }
    if (existing.delivery->cancelled_unix_ms.has_value()) {
        return;
    }
    const auto& generation = existing.delivery->policy.peer_generation;
    const auto& pin = existing.delivery->policy.peer_spki_sha256;
    if (!generation.has_value() || !pin.has_value()) {
        app_fail("OUTBOUND_KEY_BINDING_REQUIRED",
            "operation predates generation-bound delivery");
    }
    const auto payload = outbound_cancelled_payload(
        operation_id, cancelled_unix_ms, actor, reason, *generation, *pin);
    append_entry(EntryKind::outbound_cancelled, payload);
}

void NodeState::record_outbound_receipt(const DeliveryReceipt& receipt) {
    validate_delivery_receipt(receipt);
    const auto key = op_key(receipt.operation_id);
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = outbound_index_.find(key);
    if (found == outbound_index_.end()) {
        app_fail("UNEXPECTED_RECEIPT", "operation is not in the local outbox");
    }
    const auto& existing = outbound_[found->second];
    if (receipt.recipient != existing.record.recipient ||
        receipt.recorder != existing.record.recipient ||
        receipt.record_digest != existing.record_digest) {
        app_fail("RECEIPT_BINDING_REJECTED",
            "receipt does not bind the queued operation");
    }
    if (existing.receipt.has_value()) {
        if (*existing.receipt != receipt) {
            app_fail("RECEIPT_CONFLICT",
                "operation already has a different durable receipt");
        }
        return;
    }
    if (existing.delivery.has_value() &&
        existing.delivery->expired_unix_ms.has_value()) {
        app_fail("RECEIPT_AFTER_EXPIRY",
            "expired operation cannot accept a later receipt");
    }
    if (existing.delivery.has_value() &&
        existing.delivery->cancelled_unix_ms.has_value()) {
        app_fail("RECEIPT_AFTER_CANCELLATION",
            "cancelled operation cannot accept a later receipt");
    }
    if (active_outbound_rejection(existing).has_value()) {
        app_fail("RECEIPT_AFTER_REJECTION",
            "rejected operation must be explicitly retried or rebound first");
    }
    const auto payload = encode_application_message(receipt);
    append_entry(EntryKind::outbound_receipt, payload);
}

AdmissionResult NodeState::admit_inbound(
    const EvidenceRecord& record,
    const datacube::Digest32& remote_artifact_digest) {
    validate_evidence_record(record);
    if (is_counter_add_record(record)) {
        app_fail("ACTION_REQUIRES_AUTHENTICATED_POLICY",
            "the reserved action scope is accepted only by the authorized persistent path");
    }
    if (record.recipient != node_id_) {
        app_fail("WRONG_RECIPIENT",
            "record is scoped to " + record.recipient +
            ", not local node " + node_id_);
    }
    if (node_artifact_digest(record.issuer) != remote_artifact_digest) {
        app_fail("ISSUER_HANDSHAKE_MISMATCH",
            "record issuer does not match the connected peer's HELLO artifact");
    }
    const auto digest = evidence_record_digest(record);
    const auto key = op_key(record.operation_id);
    std::lock_guard<std::mutex> lock(mutex_);
    if (source_view_domains_.contains({record.issuer,record.scope})) {
        app_fail("SOURCE_VIEW_DOMAIN_RESERVED","ordinary peer data cannot enter a materialized source domain");
    }
    const auto found = inbound_index_.find(key);
    if (found != inbound_index_.end()) {
        const auto& existing = inbound_[found->second];
        if (existing.local_authorship) {
            app_fail("LOCAL_AUTHOR_NETWORK_REJECTED", "local source records are not peer admissions");
        }
        if (existing.record_digest != digest) {
            app_fail("INBOUND_OPERATION_CONFLICT",
                "operation ID already names different committed content");
        }
        return AdmissionResult{
            .disposition = AdmissionDisposition::duplicate,
            .receipt = DeliveryReceipt{
                .operation_id = record.operation_id,
                .recipient = node_id_,
                .recorder = node_id_,
                .disposition = ReceiptDisposition::duplicate,
                .sequence = existing.sequence,
                .record_digest = existing.record_digest,
            },
            .action_queued = false,
        };
    }
    if (record.corrects.has_value()) {
        const auto parent_key = op_key(*record.corrects);
        const auto parent_it = inbound_index_.find(parent_key);
        if (parent_it == inbound_index_.end()) {
            app_fail("CORRECTION_PARENT_NOT_FOUND",
                "correction parent is not committed at this recipient");
        }
        if (correction_child_.contains(parent_key)) {
            app_fail("CORRECTION_BRANCH_REJECTED",
                "the named parent already has a correction child");
        }
        if (inbound_[parent_it->second].local_authorship) {
            app_fail("LOCAL_AUTHOR_NETWORK_REJECTED", "only local authorship may correct a local source");
        }
        const auto& parent = inbound_[parent_it->second].record;
        if (parent.issuer != record.issuer ||
            parent.recipient != record.recipient ||
            parent.scope != record.scope) {
            app_fail("CORRECTION_ANCESTRY_MISMATCH",
                "correction issuer, recipient, and scope must match its parent");
        }
    }
    const auto payload = encode_application_message(record);
    append_entry(EntryKind::inbound, payload);
    const auto& stored = inbound_.back();
    return AdmissionResult{
        .disposition = AdmissionDisposition::committed,
        .receipt = DeliveryReceipt{
            .operation_id = record.operation_id,
            .recipient = node_id_,
            .recorder = node_id_,
            .disposition = ReceiptDisposition::committed,
            .sequence = stored.sequence,
            .record_digest = stored.record_digest,
        },
        .action_queued = false,
    };
}

void NodeState::record_authorization_denial(
    const EvidenceRecord& record,
    const AuthorizationDecision& decision,
    const std::uint64_t decided_unix_ms,
    const std::string_view reason_code) {
    validate_evidence_record(record);
    if (record.recipient != node_id_ || decision.peer_node != record.issuer ||
        decision.operation_class != operation_class_for(record) ||
        decision.resource != authorization_resource_for(record) ||
        decided_unix_ms == 0U || !valid_error_code(reason_code) ||
        digest_is_zero(decision.policy_digest)) {
        app_fail("AUTHORIZATION_ACCOUNT_INVALID",
            "denial account does not bind the authenticated operation");
    }
    const auto account = authorization_account_for(
        record, decision, decided_unix_ms,
        AuthorizationDecisionKind::denied, reason_code);
    const auto key = authorization_denial_key(account);
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = authorization_denial_index_.find(key);
    if (found != authorization_denial_index_.end()) {
        const auto& existing = authorization_denials_[found->second];
        if (existing.authorization.record_digest != account.record_digest ||
            existing.authorization.reason_code != account.reason_code ||
            existing.authorization.rule_digest != account.rule_digest ||
            existing.issuer != record.issuer ||
            existing.recipient != record.recipient ||
            existing.scope != record.scope) {
            app_fail("AUTHORIZATION_DENIAL_CONFLICT",
                "the denial key already names a different decision account");
        }
        return;
    }
    const auto payload = authorization_denial_payload(record, account);
    append_entry(EntryKind::authorization_denied, payload);
}

AdmissionResult NodeState::admit_inbound_authorized(
    const EvidenceRecord& record,
    const datacube::Digest32& remote_artifact_digest,
    const AuthorizationDecision& decision,
    const std::uint64_t decided_unix_ms,
    std::optional<ActionResultBinding> action_result,
    const bool require_action_result) {
    validate_evidence_record(record);
    if (record.recipient != node_id_) {
        app_fail("WRONG_RECIPIENT",
            "record is scoped to " + record.recipient +
            ", not local node " + node_id_);
    }
    if (node_artifact_digest(record.issuer) != remote_artifact_digest) {
        app_fail("ISSUER_HANDSHAKE_MISMATCH",
            "record issuer does not match the connected peer's HELLO artifact");
    }
    if (!decision.allowed || !decision.rule_digest.has_value() ||
        decision.peer_node != record.issuer ||
        decision.operation_class != operation_class_for(record) ||
        decision.resource != authorization_resource_for(record) ||
        decided_unix_ms == 0U || digest_is_zero(decision.policy_digest)) {
        app_fail("AUTHORIZATION_ACCOUNT_INVALID",
            "admission decision does not bind the authenticated operation");
    }

    const auto digest = evidence_record_digest(record);
    const auto key = op_key(record.operation_id);
    std::lock_guard<std::mutex> lock(mutex_);
    if (source_view_domains_.contains({record.issuer,record.scope})) {
        app_fail("SOURCE_VIEW_DOMAIN_RESERVED","ordinary peer data cannot enter a materialized source domain");
    }
    const auto found = inbound_index_.find(key);
    if (found != inbound_index_.end()) {
        const auto& existing = inbound_[found->second];
        if (existing.local_authorship) {
            app_fail("LOCAL_AUTHOR_NETWORK_REJECTED", "local source records are not peer admissions");
        }
        if (existing.record_digest != digest) {
            app_fail("INBOUND_OPERATION_CONFLICT",
                "operation ID already names different committed content");
        }
        return AdmissionResult{
            .disposition = AdmissionDisposition::duplicate,
            .receipt = DeliveryReceipt{
                .operation_id = record.operation_id,
                .recipient = node_id_,
                .recorder = node_id_,
                .disposition = ReceiptDisposition::duplicate,
                .sequence = existing.sequence,
                .record_digest = existing.record_digest,
            },
            .action_queued = false,
        };
    }
    if (record.corrects.has_value()) {
        if (is_counter_add_record(record)) {
            app_fail("ACTION_CORRECTION_REJECTED",
                "counter actions are immutable commands and cannot be corrections");
        }
        const auto parent_key = op_key(*record.corrects);
        const auto parent_it = inbound_index_.find(parent_key);
        if (parent_it == inbound_index_.end()) {
            app_fail("CORRECTION_PARENT_NOT_FOUND",
                "correction parent is not committed at this recipient");
        }
        if (correction_child_.contains(parent_key)) {
            app_fail("CORRECTION_BRANCH_REJECTED",
                "the named parent already has a correction child");
        }
        if (inbound_[parent_it->second].local_authorship) {
            app_fail("LOCAL_AUTHOR_NETWORK_REJECTED", "only local authorship may correct a local source");
        }
        const auto& parent = inbound_[parent_it->second].record;
        if (parent.issuer != record.issuer ||
            parent.recipient != record.recipient ||
            parent.scope != record.scope) {
            app_fail("CORRECTION_ANCESTRY_MISMATCH",
                "correction issuer, recipient, and scope must match its parent");
        }
    }

    const auto account = authorization_account_for(
        record, decision, decided_unix_ms,
        AuthorizationDecisionKind::admitted, "AUTHORIZED");
    std::optional<StoredAction> action;
    if (is_counter_add_record(record)) {
        if (require_action_result && !action_result.has_value()) {
            app_fail("ACTION_RESULT_POLICY_REQUIRED",
                "new V18 counter actions require an exact result disclosure rule");
        }
        if (action_result.has_value()) {
            if (!valid_action_result_binding(*action_result) ||
                action_result->peer_generation != decision.peer_generation ||
                action_result->configuration_event > configuration_events_.size() ||
                configuration_events_[
                    static_cast<std::size_t>(action_result->configuration_event - 1U)].kind ==
                    "REJECTED") {
                app_fail("ACTION_RESULT_POLICY_INVALID",
                    "action-result binding is not a valid accepted policy");
            }
        }
        const auto request = decode_counter_add_request(record.payload);
        std::string denial_code;
        if (request.amount > decision.action_limits.maximum_increment) {
            denial_code = "ACTION_INCREMENT_LIMIT";
        } else if (request.defer_ms > decision.action_limits.maximum_defer_ms ||
                   request.defer_ms >= decision.action_limits.expiry_ms) {
            denial_code = "ACTION_DEFER_LIMIT";
        } else if (action_counter_value_ > decision.action_limits.counter_budget ||
                   action_reserved_amount_ > decision.action_limits.counter_budget -
                       action_counter_value_ ||
                   request.amount > decision.action_limits.counter_budget -
                       action_counter_value_ - action_reserved_amount_) {
            denial_code = "ACTION_BUDGET_EXHAUSTED";
        }
        if (!denial_code.empty()) {
            const auto denied_account = authorization_account_for(
                record, decision, decided_unix_ms,
                AuthorizationDecisionKind::denied, denial_code);
            const auto denial_key = authorization_denial_key(denied_account);
            if (!authorization_denial_index_.contains(denial_key)) {
                const auto payload = authorization_denial_payload(
                    record, denied_account);
                append_entry(EntryKind::authorization_denied, payload);
            }
            app_fail(denial_code,
                "authorized counter action exceeds its durable execution limits");
        }
        const auto not_before = saturating_add_u64(
            decided_unix_ms, request.defer_ms);
        const auto expires = saturating_add_u64(
            decided_unix_ms, decision.action_limits.expiry_ms);
        action = StoredAction{
            .action_id = record.operation_id,
            .record_digest = digest,
            .issuer = record.issuer,
            .peer_generation = decision.peer_generation,
            .queue_sequence = static_cast<std::uint64_t>(actions_.size()) + 1U,
            .amount = request.amount,
            .admitted_unix_ms = decided_unix_ms,
            .not_before_unix_ms = not_before,
            .expires_unix_ms = expires,
            .limits = decision.action_limits,
            .policy_digest = decision.policy_digest,
            .rule_digest = *decision.rule_digest,
            .attempts = 0U,
            .last_started_unix_ms = std::nullopt,
            .completed_unix_ms = std::nullopt,
            .cancelled_unix_ms = std::nullopt,
            .expired_unix_ms = std::nullopt,
            .counter_before = std::nullopt,
            .counter_after = std::nullopt,
            .receipt_digest = std::nullopt,
            .cancellation_reason = {},
            .expiry_reason = {},
            .last_error_code = {},
        };
    }
    if (action_result && require_action_result) {
        action_result->reserved_payload_bytes = action_result_reservation_bytes(*action_result);
        validate_action_result_binding_locked(*action, *action_result);
        require_outbox_capacity(queue_limits_, pending_capacity_, record.issuer,
            action_result->reserved_payload_bytes, future_result_capacity_);
    }
    const auto payload = authorized_inbound_payload(
        record, account, action, action_result);
    append_entry(EntryKind::inbound_authorized, payload);
    const auto& stored = inbound_.back();
    return AdmissionResult{
        .disposition = AdmissionDisposition::committed,
        .receipt = DeliveryReceipt{
            .operation_id = record.operation_id,
            .recipient = node_id_,
            .recorder = node_id_,
            .disposition = ReceiptDisposition::committed,
            .sequence = stored.sequence,
            .record_digest = stored.record_digest,
        },
        .action_queued = action.has_value(),
    };
}

void NodeState::begin_action(
    const datacube::Digest32& action_id,
    const std::uint64_t started_unix_ms) {
    if (started_unix_ms == 0U) {
        app_fail("INVALID_ACTION_START", "action start time must be nonzero");
    }
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = action_index_.find(op_key(action_id));
    if (found == action_index_.end()) {
        app_fail("ACTION_NOT_FOUND", "action is not present in the durable queue");
    }
    const auto& action = actions_[found->second];
    if (!action_is_pending(action)) {
        app_fail("ACTION_NOT_PENDING", "action is already terminal");
    }
    const auto next_attempt = action.attempts + 1U;
    if (next_attempt == 0U) {
        app_fail("ACTION_ATTEMPT_LIMIT", "action attempt counter overflow");
    }
    const auto payload = action_started_payload(
        action_id, next_attempt, started_unix_ms);
    append_entry(EntryKind::action_started, payload);
}

void NodeState::complete_counter_action(
    const datacube::Digest32& action_id,
    const std::uint64_t completed_unix_ms) {
    if (completed_unix_ms == 0U) {
        app_fail("INVALID_ACTION_COMPLETION",
            "action completion time must be nonzero");
    }
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = action_index_.find(op_key(action_id));
    if (found == action_index_.end()) {
        app_fail("ACTION_NOT_FOUND", "action is not present in the durable queue");
    }
    const auto& action = actions_[found->second];
    if (!action_is_pending(action) || !action.last_started_unix_ms.has_value()) {
        app_fail("ACTION_NOT_STARTED", "action has no current durable start");
    }
    if (action.amount > std::numeric_limits<std::uint64_t>::max() -
            action_counter_value_) {
        app_fail("ACTION_COUNTER_OVERFLOW", "counter addition would overflow");
    }
    const auto before = action_counter_value_;
    const auto after = before + action.amount;
    if (after > action.limits.counter_budget) {
        app_fail("ACTION_BUDGET_EXHAUSTED",
            "counter action would exceed its admitted budget");
    }
    const auto receipt = action_receipt_digest(
        action_id, action.attempts, completed_unix_ms, before, after);
    const auto payload = action_completed_payload(
        action_id, action.attempts, completed_unix_ms, before, after, receipt);
    const auto result = action_results_.find(op_key(action_id));
    if (result == action_results_.end()) {
        append_entry(EntryKind::action_completed, payload);
        return;
    }
    auto terminal = action;
    terminal.completed_unix_ms = completed_unix_ms;
    terminal.counter_before = before;
    terminal.counter_after = after;
    terminal.receipt_digest = receipt;
    terminal.last_error_code.clear();
    const auto source = inbound_index_.find(op_key(action_id));
    if (source == inbound_index_.end()) {
        app_fail("JOURNAL_CORRUPT", "result-bound action source is absent");
    }
    const auto record = action_result_record(
        node_id_, terminal, inbound_.at(source->second),
        result->second.binding, ActionResultOutcome::executed);
    const auto policy = action_result_outbound_policy(
        result->second.binding, completed_unix_ms);
    validate_new_outbound_locked(record, policy, found->second);
    append_entry(EntryKind::action_result,
        action_result_transaction_payload(
            ActionResultOutcome::executed, payload, record, policy));
}

void NodeState::cancel_action(
    const datacube::Digest32& action_id,
    const std::uint64_t cancelled_unix_ms,
    const std::string_view reason) {
    if (cancelled_unix_ms == 0U || !valid_transition_text(reason, 256U)) {
        app_fail("INVALID_ACTION_CANCELLATION",
            "action cancellation requires a time and printable reason");
    }
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = action_index_.find(op_key(action_id));
    if (found == action_index_.end()) {
        app_fail("ACTION_NOT_FOUND", "action is not present in the durable queue");
    }
    const auto& action = actions_[found->second];
    if (action.completed_unix_ms.has_value()) {
        app_fail("ACTION_ALREADY_COMPLETED", "completed action cannot be cancelled");
    }
    if (action.expired_unix_ms.has_value()) {
        app_fail("ACTION_ALREADY_EXPIRED", "expired action cannot be cancelled");
    }
    if (action.cancelled_unix_ms.has_value()) {
        return;
    }
    const auto payload = action_terminal_payload(
        action_id, cancelled_unix_ms, reason);
    const auto result = action_results_.find(op_key(action_id));
    if (result == action_results_.end()) {
        append_entry(EntryKind::action_cancelled, payload);
        return;
    }
    auto terminal = action;
    terminal.cancelled_unix_ms = cancelled_unix_ms;
    terminal.cancellation_reason = std::string(reason);
    terminal.last_error_code = "ACTION_CANCELLED";
    const auto source = inbound_index_.find(op_key(action_id));
    if (source == inbound_index_.end()) {
        app_fail("JOURNAL_CORRUPT", "result-bound action source is absent");
    }
    const auto record = action_result_record(
        node_id_, terminal, inbound_.at(source->second),
        result->second.binding, ActionResultOutcome::cancelled);
    const auto policy = action_result_outbound_policy(
        result->second.binding, cancelled_unix_ms);
    validate_new_outbound_locked(record, policy, found->second);
    append_entry(EntryKind::action_result,
        action_result_transaction_payload(
            ActionResultOutcome::cancelled, payload, record, policy));
}

void NodeState::expire_action(
    const datacube::Digest32& action_id,
    const std::uint64_t expired_unix_ms,
    const std::string_view reason) {
    if (expired_unix_ms == 0U || !valid_transition_text(reason, 256U)) {
        app_fail("INVALID_ACTION_EXPIRY",
            "action expiry requires a time and printable reason");
    }
    std::lock_guard<std::mutex> lock(mutex_);
    const auto found = action_index_.find(op_key(action_id));
    if (found == action_index_.end()) {
        app_fail("ACTION_NOT_FOUND", "action is not present in the durable queue");
    }
    const auto& action = actions_[found->second];
    if (action.completed_unix_ms.has_value()) {
        app_fail("ACTION_ALREADY_COMPLETED", "completed action cannot expire");
    }
    if (action.cancelled_unix_ms.has_value()) {
        app_fail("ACTION_CANCELLED", "cancelled action cannot expire");
    }
    if (action.expired_unix_ms.has_value()) {
        return;
    }
    const auto payload = action_terminal_payload(action_id, expired_unix_ms, reason);
    const auto result = action_results_.find(op_key(action_id));
    if (result == action_results_.end()) {
        append_entry(EntryKind::action_expired, payload);
        return;
    }
    auto terminal = action;
    terminal.expired_unix_ms = expired_unix_ms;
    terminal.expiry_reason = std::string(reason);
    terminal.last_error_code = "ACTION_EXPIRED";
    const auto source = inbound_index_.find(op_key(action_id));
    if (source == inbound_index_.end()) {
        app_fail("JOURNAL_CORRUPT", "result-bound action source is absent");
    }
    const auto record = action_result_record(
        node_id_, terminal, inbound_.at(source->second),
        result->second.binding, ActionResultOutcome::expired);
    const auto policy = action_result_outbound_policy(
        result->second.binding, expired_unix_ms);
    validate_new_outbound_locked(record, policy, found->second);
    append_entry(EntryKind::action_result,
        action_result_transaction_payload(
            ActionResultOutcome::expired, payload, record, policy));
}


bool NodeState::action_selection_matches_locked(
    const ActionSelection& selection) const {
    if (selection.kind == ActionSelectionKind::none ||
        selection.queue_sequence == 0U ||
        selection.queue_sequence > actions_.size()) {
        return false;
    }
    const auto found = action_index_.find(op_key(selection.action_id));
    if (found == action_index_.end()) {
        return false;
    }
    const auto index = found->second;
    if (index + 1U != selection.queue_sequence ||
        action_selection_index_.revision(index) != selection.action_revision) {
        return false;
    }
    const auto& action = actions_[index];
    return action_is_pending(action) &&
        action.record_digest == selection.record_digest &&
        action.queue_sequence == selection.queue_sequence &&
        action.admitted_unix_ms == selection.admitted_unix_ms &&
        action.not_before_unix_ms == selection.not_before_unix_ms &&
        action.expires_unix_ms == selection.expires_unix_ms &&
        action.amount == selection.amount &&
        action.attempts == selection.attempts;
}

ActionSelection NodeState::select_action(const std::uint64_t now) const {
    std::lock_guard<std::mutex> lock(mutex_);
    ActionSelection selection;
    const auto choice = action_selection_index_.select(now);
    selection.kind = choice.kind;
    selection.next_wake_unix_ms = choice.next_wake_unix_ms;
    selection.tree_nodes_visited = choice.tree_nodes_visited;
    if (!choice.index.has_value()) {
        return selection;
    }
    if (*choice.index >= actions_.size()) {
        app_fail("STATE_INDEX_CORRUPT", "action selection index points outside retained actions");
    }
    const auto& action = actions_[*choice.index];
    if (!action_is_pending(action) ||
        action.queue_sequence != static_cast<std::uint64_t>(*choice.index) + 1U) {
        app_fail("STATE_INDEX_CORRUPT", "action selection index points to a nonpending action");
    }
    selection.action_id = action.action_id;
    selection.record_digest = action.record_digest;
    selection.queue_sequence = action.queue_sequence;
    selection.action_revision = action_selection_index_.revision(*choice.index);
    selection.admitted_unix_ms = action.admitted_unix_ms;
    selection.not_before_unix_ms = action.not_before_unix_ms;
    selection.expires_unix_ms = action.expires_unix_ms;
    selection.amount = action.amount;
    selection.attempts = action.attempts;
    selection.metadata_records_read = 1U;
    return selection;
}

bool NodeState::expire_selected_action(
    const ActionSelection& selection,
    const std::uint64_t expired_unix_ms,
    const std::string_view reason) {
    if (expired_unix_ms == 0U || !valid_transition_text(reason, 256U)) {
        app_fail("INVALID_ACTION_EXPIRY",
            "action expiry requires a time and printable reason");
    }
    std::lock_guard<std::mutex> lock(mutex_);
    if (selection.kind != ActionSelectionKind::expired ||
        !action_selection_matches_locked(selection) ||
        expired_unix_ms < selection.expires_unix_ms) {
        return false;
    }
    const auto payload = action_terminal_payload(
        selection.action_id, expired_unix_ms, reason);
    const auto result = action_results_.find(op_key(selection.action_id));
    if (result == action_results_.end()) {
        append_entry(EntryKind::action_expired, payload);
        return true;
    }
    const auto index = static_cast<std::size_t>(selection.queue_sequence - 1U);
    auto terminal = actions_.at(index);
    terminal.expired_unix_ms = expired_unix_ms;
    terminal.expiry_reason = std::string(reason);
    terminal.last_error_code = "ACTION_EXPIRED";
    const auto source = inbound_index_.find(op_key(selection.action_id));
    if (source == inbound_index_.end()) {
        app_fail("JOURNAL_CORRUPT", "result-bound action source is absent");
    }
    const auto record = action_result_record(
        node_id_, terminal, inbound_.at(source->second),
        result->second.binding, ActionResultOutcome::expired);
    const auto policy = action_result_outbound_policy(
        result->second.binding, expired_unix_ms);
    validate_new_outbound_locked(record, policy, index);
    append_entry(EntryKind::action_result,
        action_result_transaction_payload(
            ActionResultOutcome::expired, payload, record, policy));
    return true;
}

bool NodeState::begin_selected_action(
    ActionSelection& selection,
    const std::uint64_t started_unix_ms) {
    if (started_unix_ms == 0U) {
        app_fail("INVALID_ACTION_START", "action start time must be nonzero");
    }
    std::lock_guard<std::mutex> lock(mutex_);
    if (selection.kind != ActionSelectionKind::ready ||
        !action_selection_matches_locked(selection) ||
        started_unix_ms < selection.not_before_unix_ms ||
        started_unix_ms >= selection.expires_unix_ms) {
        return false;
    }
    if (selection.attempts == std::numeric_limits<std::uint32_t>::max()) {
        app_fail("ACTION_ATTEMPT_LIMIT", "action attempt counter overflow");
    }
    const auto next_attempt = selection.attempts + 1U;
    const auto payload = action_started_payload(
        selection.action_id, next_attempt, started_unix_ms);
    append_entry(EntryKind::action_started, payload);
    const auto index = static_cast<std::size_t>(selection.queue_sequence - 1U);
    selection.action_revision = action_selection_index_.revision(index);
    selection.attempts = next_attempt;
    return true;
}

bool NodeState::complete_selected_counter_action(
    const ActionSelection& selection,
    const std::uint64_t completed_unix_ms) {
    if (completed_unix_ms == 0U) {
        app_fail("INVALID_ACTION_COMPLETION",
            "action completion time must be nonzero");
    }
    std::lock_guard<std::mutex> lock(mutex_);
    if (!action_selection_matches_locked(selection)) {
        return false;
    }
    const auto index = static_cast<std::size_t>(selection.queue_sequence - 1U);
    const auto& action = actions_[index];
    if (!action.last_started_unix_ms.has_value() ||
        action.attempts != selection.attempts ||
        completed_unix_ms < *action.last_started_unix_ms) {
        return false;
    }
    if (action.amount > std::numeric_limits<std::uint64_t>::max() -
            action_counter_value_) {
        app_fail("ACTION_COUNTER_OVERFLOW", "counter addition would overflow");
    }
    const auto before = action_counter_value_;
    const auto after = before + action.amount;
    if (after > action.limits.counter_budget) {
        app_fail("ACTION_BUDGET_EXHAUSTED",
            "counter action would exceed its admitted budget");
    }
    const auto receipt = action_receipt_digest(
        action.action_id, action.attempts, completed_unix_ms, before, after);
    const auto payload = action_completed_payload(
        action.action_id, action.attempts, completed_unix_ms,
        before, after, receipt);
    const auto result = action_results_.find(op_key(action.action_id));
    if (result == action_results_.end()) {
        append_entry(EntryKind::action_completed, payload);
        return true;
    }
    auto terminal = action;
    terminal.completed_unix_ms = completed_unix_ms;
    terminal.counter_before = before;
    terminal.counter_after = after;
    terminal.receipt_digest = receipt;
    terminal.last_error_code.clear();
    const auto source = inbound_index_.find(op_key(action.action_id));
    if (source == inbound_index_.end()) {
        app_fail("JOURNAL_CORRUPT", "result-bound action source is absent");
    }
    const auto record = action_result_record(
        node_id_, terminal, inbound_.at(source->second),
        result->second.binding, ActionResultOutcome::executed);
    const auto policy = action_result_outbound_policy(
        result->second.binding, completed_unix_ms);
    validate_new_outbound_locked(record, policy, index);
    append_entry(EntryKind::action_result,
        action_result_transaction_payload(
            ActionResultOutcome::executed, payload, record, policy));
    return true;
}

void NodeState::validate_compaction_candidate(
    const datacube::Digest32& expected_digest) const {
    const int candidate_raw = ::openat(
        directory_fd_.get(),
        std::string(kCompactionCandidateName).c_str(),
        O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (candidate_raw < 0) {
        app_fail("COMPACTION_CANDIDATE_REJECTED",
            datacube::errno_detail(kCompactionCandidateName, errno));
    }
    datacube::Fd candidate_fd(candidate_raw);
    struct stat candidate_status {};
    if (::fstat(candidate_fd.get(), &candidate_status) != 0 ||
        !S_ISREG(candidate_status.st_mode) || candidate_status.st_size <= 0 ||
        static_cast<std::uint64_t>(candidate_status.st_size) >
            maximum_journal_bytes_) {
        app_fail("COMPACTION_CANDIDATE_REJECTED",
            "candidate is not a bounded regular journal file");
    }
    const auto frame = datacube::read_all_fd(
        candidate_fd.get(), maximum_journal_bytes_,
        std::string(kCompactionCandidateName));
    if (frame.size() != static_cast<std::size_t>(candidate_status.st_size)) {
        app_fail("COMPACTION_CANDIDATE_REJECTED",
            "candidate size changed during validation");
    }

    const auto observed = validate_checkpoint_image(frame, node_id_, maximum_journal_bytes_, auth_key_);
    if (observed.logical_state_digest != expected_digest || observed.journal_bytes != frame.size()) {
        app_fail("COMPACTION_CANDIDATE_REJECTED", "normal decoder reconstructed a different logical state");
    }
}

CompactionResult NodeState::compact() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (terminal_sealed_) app_fail("STATE_TERMINAL", "no compaction after terminal head sampling");
    if (poisoned_) {
        app_fail("STATE_RESTART_REQUIRED",
            "a previous journal mutation failed; restart before compaction");
    }
    if (storage_schema_version_ != kCurrentStorageSchemaVersion ||
        metadata_schema_version_ != kCurrentStorageSchemaVersion) {
        app_fail("STORAGE_SCHEMA_MISMATCH",
            "state must be migrated before compaction");
    }
    if (maintenance_generation_ == std::numeric_limits<std::uint64_t>::max()) {
        app_fail("COMPACTION_GENERATION_EXHAUSTED",
            "maintenance generation cannot advance");
    }
    const auto before = journal_bytes_;
    const auto compacted_at = unix_milliseconds_now();
    const auto generation = maintenance_generation_ + 1U;
    const auto image = checkpoint_image_locked(
        compacted_at, generation, before);

    bool published = false;
    static_cast<void>(::unlinkat(
        directory_fd_.get(), std::string(kCompactionCandidateName).c_str(), 0));
    try {
        const int raw = ::openat(
            directory_fd_.get(),
            std::string(kCompactionCandidateName).c_str(),
            O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW,
            S_IRUSR | S_IWUSR);
        if (raw < 0) {
            app_fail("COMPACTION_CANDIDATE_CREATE_FAILED",
                datacube::errno_detail(kCompactionCandidateName, errno));
        }
        datacube::Fd candidate(raw);
        write_all(candidate.get(), image.journal_bytes);
        if (::fdatasync(candidate.get()) != 0) {
            app_fail("COMPACTION_CANDIDATE_SYNC_FAILED",
                datacube::errno_detail(kCompactionCandidateName, errno));
        }
        const char* const corrupt = std::getenv(
            "NATRAV_OVERLAY_TEST_CORRUPT_COMPACTION_CANDIDATE");
        if (corrupt != nullptr && std::string_view(corrupt) == "1") {
            if (image.journal_bytes.empty()) {
                app_fail("COMPACTION_TEST_HOOK_FAILED",
                    "candidate unexpectedly has no bytes");
            }
            std::uint8_t value = 0U;
            const auto offset = static_cast<off_t>(
                image.journal_bytes.size() - 1U);
            if (::pread(candidate.get(), &value, 1U, offset) != 1) {
                app_fail("COMPACTION_TEST_HOOK_FAILED",
                    datacube::errno_detail("pread candidate", errno));
            }
            value ^= 0x5aU;
            if (::pwrite(candidate.get(), &value, 1U, offset) != 1 ||
                ::fdatasync(candidate.get()) != 0) {
                app_fail("COMPACTION_TEST_HOOK_FAILED",
                    datacube::errno_detail("corrupt candidate", errno));
            }
        }
        validate_compaction_candidate(image.logical_state_digest);
        maybe_test_pause("NATRAV_OVERLAY_TEST_COMPACT_BEFORE_PUBLISH_MS");
        if (::renameat(
                directory_fd_.get(),
                std::string(kCompactionCandidateName).c_str(),
                directory_fd_.get(), "state.journal") != 0) {
            app_fail("COMPACTION_PUBLISH_FAILED",
                datacube::errno_detail("rename state.journal", errno));
        }
        published = true;
        if (::fsync(directory_fd_.get()) != 0) {
            app_fail("COMPACTION_DIRECTORY_SYNC_FAILED",
                datacube::errno_detail(state_directory_.string(), errno));
        }
        maybe_test_pause("NATRAV_OVERLAY_TEST_COMPACT_AFTER_PUBLISH_MS");
        candidate.reset();
        journal_fd_.reset();
        open_and_lock_journal();
        if (journal_bytes_ != image.journal_bytes.size()) {
            app_fail("COMPACTION_PUBLISH_FAILED",
                "published checkpoint size changed while reopening");
        }
        authentication_ = image.authentication;
        authenticated_checkpoint_overhead_ = authentication_ ? authentication_->checkpoint_overhead : 0U;
        maintenance_generation_ = generation;
        last_compaction_unix_ms_ = compacted_at;
        last_compaction_before_bytes_ = before;
        last_compaction_after_bytes_ = journal_bytes_;
        last_compaction_retained_records_ = image.retained_records;
        return CompactionResult{
            .generation = generation,
            .compacted_unix_ms = compacted_at,
            .before_bytes = before,
            .after_bytes = journal_bytes_,
            .retained_records = image.retained_records,
            .logical_state_digest = image.logical_state_digest,
        };
    } catch (...) {
        if (!published) {
            static_cast<void>(::unlinkat(
                directory_fd_.get(),
                std::string(kCompactionCandidateName).c_str(), 0));
        } else {
            poisoned_ = true;
        }
        throw;
    }
}

std::string NodeState::authenticate_state(StateAuthKeyPtr new_key, const std::string_view reason) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (terminal_sealed_) app_fail("STATE_TERMINAL", "no authentication change after terminal head sampling");
    if (poisoned_) { app_fail("STATE_RESTART_REQUIRED", "cannot authenticate a poisoned writer"); }
    if (!new_key) { app_fail("STATE_AUTH_KEY_REQUIRED", "new authentication key required"); }
    if (auth_key_ && CRYPTO_memcmp(auth_key_->secret.data(), new_key->secret.data(), new_key->secret.size()) == 0) {
        app_fail("STATE_AUTH_ROTATION_REUSES_KEY", "rotation requires genuinely new secret material");
    }
    if (!authentication_ && !strict_source_) {
        app_fail("STATE_AUTH_MIGRATION_REQUIRED", "unkeyed state requires explicit strict offline migration");
    }
    const auto plain = checkpoint_image_locked(unix_milliseconds_now(), maintenance_generation_, journal_bytes_, false);
    datacube::Digest32 source_root;
    if (!authentication_) {
        if (::lseek(journal_fd_.get(), 0, SEEK_SET) < 0) { app_fail("JOURNAL_READ_FAILED", "cannot seek migration source"); }
        const auto bytes = datacube::read_all_fd(journal_fd_.get(), maximum_journal_bytes_, "migration source");
        source_root = datacube::sha256(bytes);
    }
    const auto purpose = authentication_ ? "ROTATE" : "MIGRATE";
    auto image = authenticate_checkpoint(plain.journal_bytes, node_id_, new_key,
        authentication_ ? &*authentication_ : nullptr, plain.logical_state_digest, purpose, reason, source_root);
    if (image.bytes.size() > maximum_journal_bytes_) {
        app_fail("STATE_CAPACITY_EXCEEDED", "authenticated checkpoint exceeds the journal limit");
    }
    bool published = false;
    try {
        datacube::Fd candidate(::openat(directory_fd_.get(), std::string(kCompactionCandidateName).c_str(),
            O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0600));
        if (!candidate || ::fchmod(candidate.get(), 0600) != 0) {
            app_fail("STATE_AUTH_CANDIDATE_FAILED", "cannot create authentication candidate");
        }
        write_all(candidate.get(), image.bytes);
        if (::fdatasync(candidate.get()) != 0 || ::lseek(candidate.get(), 0, SEEK_SET) < 0) {
            app_fail("STATE_AUTH_CANDIDATE_FAILED", "cannot sync or read authentication candidate");
        }
        const char* corrupt = std::getenv("NATRAV_OVERLAY_TEST_STATE_AUTH_CORRUPT_CANDIDATE");
        if (corrupt && std::string_view(corrupt) == "1") {
            std::uint8_t value = static_cast<std::uint8_t>(image.bytes.back() ^ 1U);
            if (::pwrite(candidate.get(), &value, 1U, static_cast<off_t>(image.bytes.size() - 1U)) != 1 ||
                ::fdatasync(candidate.get()) != 0) {
                app_fail("STATE_AUTH_TEST_HOOK_FAILED", "cannot alter test candidate");
            }
        }
        const auto actual = datacube::read_all_fd(candidate.get(), maximum_journal_bytes_, "authentication candidate");
        const auto checked = validate_checkpoint_image(actual, node_id_, maximum_journal_bytes_, new_key);
        if (checked.logical_state_digest != plain.logical_state_digest || !checked.authentication ||
            checked.authentication->root != image.authentication.root) {
            app_fail("STATE_AUTH_CANDIDATE_REJECTED", "candidate changed logical state or root");
        }
        state_auth_test_pause("BEFORE_PUBLISH");
        if (::renameat(directory_fd_.get(), std::string(kCompactionCandidateName).c_str(),
                       directory_fd_.get(), "state.journal") != 0) {
            app_fail("STATE_AUTH_PUBLISH_FAILED", "atomic authentication publication failed");
        }
        published = true;
        if (::fsync(directory_fd_.get()) != 0) {
            app_fail("STATE_AUTH_SYNC_FAILED", "published state requires inspection after directory sync failure");
        }
        state_auth_test_pause("AFTER_PUBLISH");
        journal_fd_.reset();
        open_and_lock_journal();
        auth_key_ = std::move(new_key);
        authentication_ = std::move(image.authentication);
        authenticated_checkpoint_overhead_ = authentication_->checkpoint_overhead;
        return "{\"format\":\"NATRAV_OVERLAY_STATE_AUTH_TRANSITION_V1\",\"ok\":true,\"transition\":" +
            json_string(purpose) + ",\"logical_state_digest\":" + json_string(datacube::hex_lower(plain.logical_state_digest)) +
            ",\"state_authentication\":" + state_authentication_json(authentication_) +
            ",\"state_head\":" + state_head_json(node_id_, authentication_, journal_bytes_, false) +
            ",\"input_expectation\":" + json_string(process_state_head_expectation() ? "MATCHED_AT_OPEN" : "NOT_SUPPLIED") + "}";
    } catch (...) {
        if (!published) { static_cast<void>(::unlinkat(directory_fd_.get(), std::string(kCompactionCandidateName).c_str(), 0)); }
        else { poisoned_ = true; }
        throw;
    }
}

CheckpointImage NodeState::checkpoint_image(
    const std::uint64_t created_unix_ms) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return checkpoint_image_locked(
        created_unix_ms, maintenance_generation_, journal_bytes_);
}

void NodeState::record_backup_restore(
    const datacube::Digest32& backup_id,
    const std::string_view generation,
    const std::uint64_t restored_unix_ms) {
    if (digest_is_zero(backup_id) || !valid_generation_id(generation) ||
        restored_unix_ms == 0U) {
        app_fail("BACKUP_RESTORE_ACCOUNT_INVALID",
            "backup restore account is incomplete");
    }
    std::lock_guard<std::mutex> lock(mutex_);
    datacube::Octets payload;
    append_digest(payload, backup_id);
    append_text16(payload, generation, 64U, "backup identity generation");
    datacube::append_be64(payload, restored_unix_ms);
    append_entry(EntryKind::backup_restored, payload);
}

bool NodeState::has_pending_outbound_for(const std::string_view recipient) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return delivery_index_.pending(std::string(recipient)) != 0U;
}

PendingWorkCounts NodeState::pending_work_counts() const {
    std::lock_guard<std::mutex> lock(mutex_);
    PendingWorkCounts counts;
    counts.pending_outbound = static_cast<std::uint64_t>(delivery_index_.pending());
    counts.pending_actions = static_cast<std::uint64_t>(
        action_selection_index_.pending());
    return counts;
}

std::vector<StoredAction> NodeState::pending_actions() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<StoredAction> result;
    for (const auto& item : actions_) {
        if (action_is_pending(item)) { result.push_back(item); }
    }
    return result;
}

std::vector<LifecycleEvent> NodeState::lifecycle_history() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return lifecycle_events_;
}

DurableCustodyDisposition NodeState::commit_custody_event(
    const DurableCustodyEvent& event) {
    std::lock_guard<std::mutex> lock(mutex_);
    // Authority and exact configuration provenance must be established before
    // the append is made durable.  A semantic rejection must never become a
    // synchronized frame followed by a poisoned in-memory state.
    validate_custody_event_authority(
        custody_registry_, configuration_events_, event);
    auto trial = custody_registry_;
    const auto disposition = trial.apply(event);
    if (disposition == DurableCustodyDisposition::duplicate) {
        return disposition;
    }
    const auto bytes = encode_durable_custody_event(event);
    append_entry(EntryKind::custody_event, bytes);
    return disposition;
}

std::optional<DurableCustodyCase> NodeState::custody_case(
    const datacube::Digest32& envelope) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto* found = custody_registry_.find(envelope);
    return found == nullptr ? std::nullopt :
        std::optional<DurableCustodyCase>(*found);
}

std::string NodeState::custody_status_json() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return custody_registry_.status_json();
}

StateSnapshot NodeState::snapshot() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return snapshot_locked();
}

const std::string& NodeState::node_id() const noexcept { return node_id_; }

const std::filesystem::path& NodeState::state_directory() const noexcept {
    return state_directory_;
}

std::string_view queue_disposition_name(
    const QueueDisposition disposition) noexcept {
    switch (disposition) {
        case QueueDisposition::queued: return "QUEUED";
        case QueueDisposition::already_pending: return "ALREADY_PENDING";
        case QueueDisposition::already_acked: return "ALREADY_ACKED";
        case QueueDisposition::already_rejected: return "ALREADY_REJECTED";
    }
    return "UNKNOWN";
}

std::string_view admission_disposition_name(
    const AdmissionDisposition disposition) noexcept {
    switch (disposition) {
        case AdmissionDisposition::committed: return "COMMITTED";
        case AdmissionDisposition::duplicate: return "DUPLICATE";
    }
    return "UNKNOWN";
}

std::string_view outbound_transition_kind_name(
    const OutboundTransitionKind kind) noexcept {
    switch (kind) {
        case OutboundTransitionKind::rebound: return "REBOUND";
        case OutboundTransitionKind::cancelled: return "CANCELLED";
        case OutboundTransitionKind::rejected: return "REJECTED";
        case OutboundTransitionKind::retried: return "RETRIED";
    }
    return "UNKNOWN";
}

bool outbound_is_pending(const StoredOutbound& entry) noexcept {
    bool rejected = false;
    if (entry.delivery.has_value()) {
        for (const auto& transition : entry.delivery->transitions) {
            if (transition.kind == OutboundTransitionKind::rejected) {
                rejected = true;
            } else if (transition.kind == OutboundTransitionKind::retried ||
                       transition.kind == OutboundTransitionKind::rebound ||
                       transition.kind == OutboundTransitionKind::cancelled) {
                rejected = false;
            }
        }
    }
    return !entry.receipt.has_value() &&
        !rejected &&
        (!entry.delivery.has_value() ||
         (!entry.delivery->expired_unix_ms.has_value() &&
          !entry.delivery->cancelled_unix_ms.has_value()));
}

std::string_view outbound_status_name(const StoredOutbound& entry) noexcept {
    if (entry.receipt) return "ACKED";
    if (entry.delivery) {
        if (entry.delivery->cancelled_unix_ms) return "CANCELLED";
        if (entry.delivery->expired_unix_ms) return "EXPIRED";
        // Every accepted transition either sets rejection or clears it:
        // REJECTED sets; RETRIED, REBOUND and CANCELLED clear. Receipt and
        // terminal markers above preserve the existing precedence.
        if (!entry.delivery->transitions.empty() &&
            entry.delivery->transitions.back().kind == OutboundTransitionKind::rejected) {
            return "REJECTED";
        }
    }
    return "PENDING";
}

std::string_view authorization_decision_kind_name(
    const AuthorizationDecisionKind kind) noexcept {
    switch (kind) {
        case AuthorizationDecisionKind::admitted: return "ADMITTED";
        case AuthorizationDecisionKind::denied: return "DENIED";
    }
    return "UNKNOWN";
}

std::string_view local_control_decision_kind_name(
    const LocalControlDecisionKind kind) noexcept {
    switch (kind) {
        case LocalControlDecisionKind::authorized: return "AUTHORIZED";
        case LocalControlDecisionKind::denied: return "DENIED";
    }
    return "UNKNOWN";
}

std::string_view lifecycle_transition_kind_name(
    const LifecycleTransitionKind kind) noexcept {
    switch (kind) {
        case LifecycleTransitionKind::quiesced: return "QUIESCED";
        case LifecycleTransitionKind::resumed: return "RESUMED";
        case LifecycleTransitionKind::drain_started: return "DRAIN_STARTED";
        case LifecycleTransitionKind::drain_completed: return "DRAIN_COMPLETED";
        case LifecycleTransitionKind::drain_deadline: return "DRAIN_DEADLINE";
        case LifecycleTransitionKind::shutdown_requested: return "SHUTDOWN_REQUESTED";
    }
    return "UNKNOWN";
}

bool action_is_pending(const StoredAction& action) noexcept {
    return !action.completed_unix_ms.has_value() &&
        !action.cancelled_unix_ms.has_value() &&
        !action.expired_unix_ms.has_value();
}

std::string_view action_status_name(const StoredAction& action) noexcept {
    if (action.completed_unix_ms.has_value()) {
        return "EXECUTED";
    }
    if (action.cancelled_unix_ms.has_value()) {
        return "CANCELLED";
    }
    if (action.expired_unix_ms.has_value()) {
        return "EXPIRED";
    }
    if (action.last_started_unix_ms.has_value()) {
        return "PENDING";
    }
    return "PENDING";
}

std::size_t active_configuration_event(
    const std::vector<RuntimeConfigurationEvent>& events) noexcept {
    for (std::size_t i = events.size(); i > 0U; --i) {
        if (events[i - 1U].kind != "REJECTED") { return i; }
    }
    return 0U;
}

void NodeState::record_runtime_configuration(const RuntimeConfigurationEvent& event) {
    std::lock_guard<std::mutex> lock(mutex_);
    validate_runtime_event(event, configuration_events_, node_id_);
    if (event.kind != "REJECTED") { reserve_source_view_domains_locked(parse_runtime_config(event.canonical,"/source-view-candidate",IdentityFileValidation::deferred),false); }
    const auto payload = runtime_event_payload(event);
    append_entry(EntryKind::runtime_configuration, payload);
}

void NodeState::record_local_control_event(const LocalControlEvent& event) {
    std::lock_guard<std::mutex> lock(mutex_);
    validate_local_control_event(event, configuration_events_);
    append_entry(EntryKind::local_control_event, local_control_event_payload(event));
}

void NodeState::record_lifecycle_event(const LifecycleEvent& event) {
    std::lock_guard<std::mutex> lock(mutex_);
    validate_lifecycle_event(event, configuration_events_);
    append_entry(EntryKind::lifecycle_event, lifecycle_event_payload(event));
}

std::string configuration_history_json(const StateSnapshot& snapshot, const bool bounded) {
    return configuration_history_json(snapshot.configuration_events, snapshot.configuration_bindings, bounded);
}

std::string configuration_history_json(const std::vector<RuntimeConfigurationEvent>& events,
    const std::vector<RuntimeMutationBinding>& bindings, const bool bounded) {
    const auto active = active_configuration_event(events);
    std::string out = "{\"active_event\":" + std::to_string(active);
    if (active != 0U) {
        const auto& event = events[active - 1U];
        out += ",\"generation\":" + json_string(event.generation) +
            ",\"digest\":" + json_string(datacube::hex_lower(event.digest));
    } else { out += ",\"generation\":null,\"digest\":null"; }
    out += ",\"event_count\":" + std::to_string(events.size());
    out += ",\"events\":[";
    const std::size_t start = bounded && events.size() > 8U ?
        events.size() - 8U : 0U;
    for (std::size_t i = start; i < events.size(); ++i) {
        if (i != start) { out += ','; }
        const auto& e = events[i];
        out += "{\"event\":" + std::to_string(i + 1U) +
            ",\"kind\":" + json_string(e.kind) + ",\"generation\":" + json_string(e.generation) +
            ",\"digest\":" + json_string(datacube::hex_lower(e.digest)) +
            ",\"unix_ms\":" + std::to_string(e.unix_ms) + ",\"actor\":" + json_string(e.actor) +
            ",\"reason\":" + json_string(e.reason) + ",\"error_code\":" + json_string(e.error_code);
        if (e.kind == "RELOCATE") {
            std::size_t previous = i;
            while (previous > 0U &&
                   events[previous - 1U].kind == "REJECTED") {
                --previous;
            }
            if (previous == 0U) {
                app_fail("JOURNAL_CORRUPT", "relocation has no accepted predecessor");
            }
            const auto before = parse_runtime_config(
                events[previous - 1U].canonical,
                "/durable-relocation-json-before",
                IdentityFileValidation::deferred);
            const auto after = parse_runtime_config(
                e.canonical,
                "/durable-relocation-json-after",
                IdentityFileValidation::deferred);
            out += ",\"relocation\":{\"old_state\":" +
                json_string(before.state_directory.string()) +
                ",\"new_state\":" + json_string(after.state_directory.string()) +
                ",\"old_control\":" + json_string(before.control_socket.string()) +
                ",\"new_control\":" + json_string(after.control_socket.string()) +
                ",\"old_certificate\":" +
                    json_string(before.identity.certificate.string()) +
                ",\"new_certificate\":" +
                    json_string(after.identity.certificate.string()) +
                ",\"old_private_key\":" + (bounded ? std::string("null") :
                    json_string(before.identity.private_key.string())) +
                ",\"new_private_key\":" + (bounded ? std::string("null") :
                    json_string(after.identity.private_key.string())) + "}";
        }
        out += "}";
    }
    out += "],\"events_truncated\":" + std::string(start != 0U ? "true" : "false");
    out += ",\"binding_count\":" + std::to_string(bindings.size());
    out += ",\"bindings\":[";
    const std::size_t first = bounded && bindings.size() > 16U ?
        bindings.size() - 16U : 0U;
    for (std::size_t i = first; i < bindings.size(); ++i) {
        if (i != first) { out += ','; }
        const auto& b = bindings[i];
        out += "{\"ordinal\":" + std::to_string(i + 1U) +
            ",\"configuration_event\":" + std::to_string(b.configuration_event) +
            ",\"journal_kind\":" + std::to_string(b.journal_kind) +
            ",\"payload_digest\":" + json_string(datacube::hex_lower(b.payload_digest)) +
            ",\"operation_id\":" + (b.operation_id.has_value() ?
                json_string(operation_id_text(*b.operation_id)) : std::string("null")) + "}";
    }
    return out + "],\"bindings_truncated\":" + std::string(first != 0U ? "true" : "false") + "}";
}

namespace {
// A payload-free record-local snapshot. Immutable record bytes are committed by
// record_digest; all mutable delivery fields retain their existing strict codec.
datacube::Octets outbox_admin_metadata(const StoredOutbound& e) {
    datacube::Octets b;datacube::append_text(b,"OCM1");
    append_digest(b,e.record.operation_id);append_digest(b,e.record_digest);
    datacube::append_be64(b,e.queue_sequence);
    datacube::append_u8(b,e.receipt?1U:0U);if(e.receipt)append_application(b,*e.receipt,"condition receipt");
    datacube::append_u8(b,e.delivery?1U:0U);if(e.delivery)append_outbound_delivery_state(b,*e.delivery);
    return b;
}
StoredOutbound read_outbox_admin_metadata(datacube::OctetView bytes,const StoredOutbound& identity) {
    datacube::Reader r(bytes,"conditional prior metadata");
    if(datacube::octets_text(r.read_exact(4U,"magic"),"magic",true)!="OCM1")app_fail("JOURNAL_CORRUPT","conditional metadata version");
    StoredOutbound e;e.record.operation_id=read_digest(r,"operation");e.record_digest=read_digest(r,"record digest");e.queue_sequence=r.read_be64("queue sequence");
    e.record.issuer=identity.record.issuer;e.record.recipient=identity.record.recipient;
    if(e.record.operation_id!=identity.record.operation_id||e.record_digest!=identity.record_digest||e.queue_sequence!=identity.queue_sequence)
        app_fail("JOURNAL_CORRUPT","conditional immutable identity mismatch");
    const auto receipt=r.read_u8("receipt");if(receipt>1U)app_fail("JOURNAL_CORRUPT","receipt marker");
    if(receipt){const auto a=read_application(r,"condition receipt");if(!std::holds_alternative<DeliveryReceipt>(a))app_fail("JOURNAL_CORRUPT","condition receipt type");e.receipt=std::get<DeliveryReceipt>(a);}
    const auto delivery=r.read_u8("delivery");if(delivery>1U)app_fail("JOURNAL_CORRUPT","delivery marker");
    if(delivery)e.delivery=read_outbound_delivery_state(r,256U);
    r.require_eof("conditional metadata");
    if(outbox_admin_metadata(e)!=datacube::Octets(bytes.begin(),bytes.end()))app_fail("JOURNAL_CORRUPT","noncanonical conditional metadata");
    return e;
}
void conditional_pause(const char* phase) {
    const std::string key=std::string("NATRAV_OVERLAY_TEST_OUTBOX_CONDITION_")+phase+"_MS";
    if(const char* v=std::getenv(key.c_str())) {
        const auto delay=parse_u64(v,key,1U,10000U);
        const std::string marker=std::string("OUTBOX_CONDITION_")+phase+"\n";
        static_cast<void>(::write(STDERR_FILENO,marker.data(),marker.size()));
        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    }
}
std::string conditional_actor(std::uint32_t uid){return "CONDITIONAL_UID_"+std::to_string(uid);}
std::uint8_t conditional_inner_kind(OutboxAdminKind kind){return kind==OutboxAdminKind::cancel?10U:kind==OutboxAdminKind::retry?21U:9U;}
}

std::string NodeState::outbound_recipient(const datacube::Digest32& operation) const {
    std::lock_guard lock(mutex_);const auto it=outbound_index_.find(op_key(operation));
    if(it==outbound_index_.end())app_fail("OUTBOUND_NOT_FOUND","operation is not queued");
    return outbound_[it->second].record.recipient;
}
std::uint8_t NodeState::outbox_restrictions_locked(const datacube::Digest32& operation) const {
    const auto result = action_result_operations_.find(op_key(operation));
    // Preserve pre-reservation conditional receipt commitments for legacy state.
    std::uint8_t value = result != action_result_operations_.end() && result->second ? 8U : 0U;
    for(const auto& [id,s]:source_subscriptions_){
        const bool contains=std::any_of(s.deliveries.begin(),s.deliveries.end(),[&](const auto& d){return d.operation==operation;});
        if(!contains)continue;
        value=static_cast<std::uint8_t>(value|1U);
        for(const auto& [other,t]:source_subscriptions_){static_cast<void>(other);if(t.succession&&t.succession->predecessor_grant==id)value=static_cast<std::uint8_t>(value|4U);}
    }
    for(const auto& [id,c]:publication_channels_){static_cast<void>(id);for(const auto& p:c.publications)if(p.prior_epoch_terminal_operation&&*p.prior_epoch_terminal_operation==operation)value=static_cast<std::uint8_t>(value|2U);}
    return value;
}
datacube::Digest32 NodeState::outbox_admin_root_locked(const datacube::Digest32& operation) const {
    const auto f=outbox_admin_by_operation_.find(op_key(operation));
    return f==outbox_admin_by_operation_.end()||f->second.empty()?datacube::Digest32{}:
        datacube::sha256(encode_outbox_admin_record(outbox_administration_[f->second.back()]));
}
std::string NodeState::outbox_condition_json_locked(const StoredOutbound& e) const {
    if(e.delivery && e.delivery->transitions.size()>256U) return "{\"available\":false,\"code\":\"OUTBOX_ADMIN_HISTORY_LIMIT\"}";
    const auto metadata=outbox_admin_metadata(e);
    if(metadata.size()>kOutboxAdminMetadataLimit) return "{\"available\":false,\"code\":\"OUTBOX_ADMIN_HISTORY_LIMIT\"}";
    const auto restrictions=outbox_restrictions_locked(e.record.operation_id);
    const auto root=outbox_admin_root_locked(e.record.operation_id);const auto digest=outbox_selected_digest(metadata,restrictions,root);
    const auto f=outbox_admin_by_operation_.find(op_key(e.record.operation_id));
    return "{\"format\":\"OUTBOX_SEMANTIC_SELECTION_V1\",\"state_digest\":"+json_string(datacube::hex_lower(digest))+
        ",\"metadata_digest\":"+json_string(datacube::hex_lower(datacube::sha256(metadata)))+",\"metadata_bytes\":"+std::to_string(metadata.size())+
        ",\"restrictions\":"+std::to_string(restrictions)+",\"previous_action_root\":"+json_string(datacube::hex_lower(root))+
        ",\"retained_actions\":"+std::to_string(f==outbox_admin_by_operation_.end()?0U:f->second.size())+
        ",\"latest_action\":"+(f==outbox_admin_by_operation_.end()||f->second.empty()?"null":outbox_admin_record_json(outbox_administration_[f->second.back()]))+"}";
}

datacube::Octets NodeState::conditional_inner_locked(const OutboxAdminRecord& a,const StoredOutbound& e,const RuntimeConfig& config) const {
    const auto& q=a.request;
    if(!e.delivery)app_fail("OUTBOUND_POLICY_MISSING","conditional action requires delivery policy");
    const auto& d=*e.delivery;const auto& p=d.policy;
    if(e.receipt)app_fail("OUTBOUND_ALREADY_ACKED","receipt is terminal for administration");
    if(d.cancelled_unix_ms)app_fail("OUTBOUND_CANCELLED","operation is cancelled");
    if(d.expired_unix_ms)app_fail("OUTBOUND_EXPIRED","operation is expired");
    if(!p.peer_generation||!p.peer_spki_sha256)app_fail("OUTBOUND_KEY_BINDING_REQUIRED","exact durable generation required");
    if((a.restrictions&6U)!=0U&&q.kind!=OutboxAdminKind::cancel)app_fail("OUTBOUND_ADOPTED_PREDECESSOR","an adopted predecessor cannot be reopened");
    const auto actor=conditional_actor(a.uid);
    if(q.kind==OutboxAdminKind::cancel)return outbound_cancelled_payload(q.operation,a.unix_ms,actor,q.reason,*p.peer_generation,*p.peer_spki_sha256);
    if(q.kind==OutboxAdminKind::retry){
        if(!active_outbound_rejection(e))app_fail("OUTBOUND_NOT_REJECTED","retry requires an active rejection");
        const auto* gen=find_peer_generation(config,e.record.recipient,*p.peer_generation);
        if(!gen||gen->spki_sha256!=*p.peer_spki_sha256||gen->state==KeyGenerationState::revoked)app_fail("OUTBOUND_KEY_POLICY_INVALID","retry requires a retained nonrevoked exact binding");
        return outbound_retried_payload(q.operation,a.unix_ms,actor,q.reason,*p.peer_generation,*p.peer_spki_sha256);
    }
    if (action_result_operations_.contains(op_key(q.operation))) {
        app_fail("OUTBOUND_ACTION_RESULT_BOUND", "result disclosure cannot be rebound beyond its admission");
    }
    if((a.restrictions&1U)!=0U)app_fail("OUTBOUND_SOURCE_SUBSCRIPTION_BOUND","source disclosure cannot be rebound beyond its grant");
    const auto* gen=find_peer_generation(config,e.record.recipient,q.generation);
    if(!gen)app_fail("OUTBOUND_GENERATION_NOT_CONFIGURED","target generation unavailable");
    if(gen->state!=KeyGenerationState::active)app_fail("OUTBOUND_REBIND_TARGET_NOT_ACTIVE","target must be ACTIVE");
    if(gen->generation==*p.peer_generation&&gen->spki_sha256==*p.peer_spki_sha256)app_fail("OUTBOUND_BINDING_UNCHANGED","target is the existing binding");
    return outbound_rebound_payload(q.operation,a.unix_ms,actor,q.reason,*p.peer_generation,*p.peer_spki_sha256,gen->generation,gen->spki_sha256);
}

std::string NodeState::conditional_outbox_command(const OutboxAdminRequest& request,const RuntimeConfig& config,
    std::uint32_t uid,std::uint32_t gid,std::uint32_t pid,std::uint64_t event) {
    validate_outbox_admin_request(request);std::lock_guard lock(mutex_);
    if(poisoned_)app_fail("STATE_POISONED","restart the writer");
    if(config.format_version<8U||event==0U)app_fail("OUTBOX_CONDITION_POLICY_VERSION","conditional administration requires durable V8+ local policy");
    if(!local_control_allows(config.local_control,uid,LocalControlClass::maintenance))app_fail("LOCAL_CONTROL_CLASS_DENIED","MAINTENANCE is required");
    const auto key=op_key(request.operation);const auto f=outbound_index_.find(key);
    if(f==outbound_index_.end())app_fail("OUTBOUND_NOT_FOUND","operation is not queued");
    const auto id=outbox_admin_request_digest(request,uid);const auto prior=outbox_admin_by_request_.find(op_key(id));
    auto response=[&](const OutboxAdminRecord& accepted,bool duplicate){return
        "{\"format\":\"NATRAV_OVERLAY_CONDITIONAL_OUTBOX_V1\",\"status\":"+json_string(duplicate?"ALREADY_APPLIED":"APPLIED")+
        ",\"operation_id\":"+json_string(key)+",\"accepted_action\":"+outbox_admin_record_json(accepted)+
        ",\"current_outcome\":"+json_string(outbound_status_name(outbound_[f->second]))+",\"condition\":"+outbox_condition_json_locked(outbound_[f->second])+"}";};
    // An exact prior command confirms an immutable effect; it never applies again.
    // Current credentials still apply, but relocation need not recreate old paths.
    if(prior!=outbox_admin_by_request_.end())return response(outbox_administration_[prior->second],true);
    const auto canonical=canonical_runtime_config(config);const auto cfg=runtime_configuration_digest(canonical);
    if(request.expected_configuration!=cfg||event!=active_configuration_event(configuration_events_))app_fail("OUTBOX_CONFIGURATION_CONFLICT","accepted configuration changed since selection");
    const auto& before=outbound_[f->second];
    if(before.delivery && before.delivery->transitions.size()>256U)app_fail("OUTBOX_ADMIN_HISTORY_LIMIT","conditional metadata transition bound reached");
    const auto bytes=outbox_admin_metadata(before);
    const auto restrictions=outbox_restrictions_locked(request.operation);const auto root=outbox_admin_root_locked(request.operation);
    if(request.expected_state!=outbox_selected_digest(bytes,restrictions,root))app_fail("OUTBOX_STATE_CONFLICT","durable operation changed since selection");
    const auto count=outbox_admin_by_operation_.find(key);
    if(bytes.size()>kOutboxAdminMetadataLimit||outbox_administration_.size()>=kOutboxAdminLimit||
        (count!=outbox_admin_by_operation_.end()&&count->second.size()>=kOutboxAdminPerOperationLimit))app_fail("OUTBOX_ADMIN_HISTORY_LIMIT","conditional receipt or metadata bound reached");
    OutboxAdminRecord a{.request=request,.uid=uid,.gid=gid,.pid=pid,.unix_ms=unix_milliseconds_now(),.configuration_event=event,
        .request_digest=id,.prior_admin_root=root,.resulting_metadata_digest={},.restrictions=restrictions,.before_metadata=bytes};
    const auto inner=conditional_inner_locked(a,before,config);
    if(request.kind!=OutboxAdminKind::cancel&&active_outbound_rejection(before))
        require_outbox_capacity(queue_limits_,pending_capacity_,before.record.recipient,static_cast<std::uint64_t>(before.record.payload.size()),future_result_capacity_);
    // Use the existing semantic transition decoder, with only this operation in
    // memory. No whole-state snapshot and no source payload copy is needed.
    NodeState scratch(MemoryReplayTag{},node_id_,maximum_journal_bytes_);
    scratch.outbound_.push_back(read_outbox_admin_metadata(bytes,before));scratch.outbound_index_.emplace(key,0U);
    scratch.index_outbound(0U);
    scratch.applying_conditional_action_=true;
    scratch.apply_entry(static_cast<EntryKind>(conditional_inner_kind(request.kind)),inner,true);
    a.resulting_metadata_digest=datacube::sha256(outbox_admin_metadata(scratch.outbound_.front()));
    const auto payload=encode_outbox_admin_record(a);apply_outbox_administration(payload,true);
    conditional_pause("BEFORE_COMMIT");append_entry(EntryKind::outbox_administration,payload);conditional_pause("AFTER_COMMIT");
    return response(outbox_administration_.back(),false);
}

void NodeState::apply_outbox_administration(datacube::OctetView payload,bool validate_only) {
    const auto a=decode_outbox_admin_record(payload);const auto key=op_key(a.request.operation);const auto f=outbound_index_.find(key);
    auto check=[](bool v,std::string_view m){if(!v)app_fail("JOURNAL_CORRUPT",m);};
    check(f!=outbound_index_.end(),"conditional operation missing");
    check(a.configuration_event==active_configuration_event(configuration_events_),"conditional configuration is not active");
    const auto& configuration=configuration_events_.at(static_cast<std::size_t>(a.configuration_event-1U));
    const auto config=parse_runtime_config(configuration.canonical,"/conditional-history",IdentityFileValidation::deferred);
    check(config.format_version>=8U&&configuration.digest==a.request.expected_configuration&&local_control_allows(config.local_control,a.uid,LocalControlClass::maintenance),"conditional historical authority mismatch");
    const auto& before=outbound_[f->second];
    check(a.before_metadata==outbox_admin_metadata(before)&&a.restrictions==outbox_restrictions_locked(a.request.operation)&&a.prior_admin_root==outbox_admin_root_locked(a.request.operation),"conditional prior state mismatch");
    check(a.request.expected_state==outbox_selected_digest(a.before_metadata,a.restrictions,a.prior_admin_root),"conditional selected digest mismatch");
    check(!outbox_admin_by_request_.contains(op_key(a.request_digest)),"duplicate conditional event");
    const auto existing=outbox_admin_by_operation_.find(key);
    check(outbox_administration_.size()<kOutboxAdminLimit&&(existing==outbox_admin_by_operation_.end()||existing->second.size()<kOutboxAdminPerOperationLimit),"conditional history bound");
    const auto inner=conditional_inner_locked(a,before,config);
    NodeState scratch(MemoryReplayTag{},node_id_,maximum_journal_bytes_);scratch.outbound_.push_back(read_outbox_admin_metadata(a.before_metadata,before));scratch.outbound_index_.emplace(key,0U);
    scratch.index_outbound(0U);
    scratch.applying_conditional_action_=true;
    scratch.apply_entry(static_cast<EntryKind>(conditional_inner_kind(a.request.kind)),inner,true);
    check(a.resulting_metadata_digest==datacube::sha256(outbox_admin_metadata(scratch.outbound_.front())),"conditional result mismatch");
    if(validate_only)return;
    applying_runtime_bound_mutation_=true;applying_conditional_action_=true;
    try {apply_entry(static_cast<EntryKind>(conditional_inner_kind(a.request.kind)),inner,true);applying_runtime_bound_mutation_=false;applying_conditional_action_=false;}
    catch(...){applying_runtime_bound_mutation_=false;applying_conditional_action_=false;throw;}
    const auto index=outbox_administration_.size();outbox_administration_.push_back(a);
    outbox_admin_by_operation_[key].push_back(index);outbox_admin_by_request_.emplace(op_key(a.request_digest),index);
}

void NodeState::validate_outbox_administration_checkpoint() {
    auto check=[](bool v,std::string_view m){if(!v)app_fail("JOURNAL_CORRUPT",m);};
    outbox_admin_by_request_.clear();outbox_admin_by_operation_.clear();
    std::set<std::pair<std::string,std::size_t>> covered;
    for(std::size_t i=0U;i<outbox_administration_.size();++i){
        const auto& a=outbox_administration_[i];const auto key=op_key(a.request.operation);const auto f=outbound_index_.find(key);
        check(f!=outbound_index_.end()&&a.configuration_event>0U&&a.configuration_event<=configuration_events_.size(),"checkpoint conditional reference missing");
        const auto& cfg=configuration_events_[static_cast<std::size_t>(a.configuration_event-1U)];
        check(cfg.kind!="REJECTED"&&cfg.digest==a.request.expected_configuration,"checkpoint conditional configuration mismatch");
        const auto config=parse_runtime_config(cfg.canonical,"/conditional-checkpoint",IdentityFileValidation::deferred);
        check(config.format_version>=8U&&local_control_allows(config.local_control,a.uid,LocalControlClass::maintenance),"checkpoint conditional authority mismatch");
        check(a.prior_admin_root==outbox_admin_root_locked(a.request.operation)&&a.request.expected_state==outbox_selected_digest(a.before_metadata,a.restrictions,a.prior_admin_root),"checkpoint conditional chain mismatch");
        const auto& current=outbound_[f->second];auto before=read_outbox_admin_metadata(a.before_metadata,current);
        check(before.delivery&&current.delivery,"checkpoint conditional delivery missing");
        auto normalized=before.delivery->policy;normalized.peer_generation=current.delivery->policy.peer_generation;normalized.peer_spki_sha256=current.delivery->policy.peer_spki_sha256;
        check(normalized==current.delivery->policy,"checkpoint conditional immutable policy mismatch");
        const auto inner=conditional_inner_locked(a,before,config);
        NodeState scratch(MemoryReplayTag{},node_id_,maximum_journal_bytes_);scratch.outbound_index_.emplace(key,0U);scratch.outbound_.push_back(std::move(before));
        scratch.index_outbound(0U);
    scratch.applying_conditional_action_=true;
    scratch.apply_entry(static_cast<EntryKind>(conditional_inner_kind(a.request.kind)),inner,true);const auto& after=scratch.outbound_.front();
        check(datacube::sha256(outbox_admin_metadata(after))==a.resulting_metadata_digest,"checkpoint conditional result mismatch");
        const auto& transitions=after.delivery->transitions;check(!transitions.empty()&&transitions.size()<=current.delivery->transitions.size(),"checkpoint conditional transition missing");
        for(std::size_t j=0U;j<transitions.size();++j){datacube::Octets l,r;append_outbound_transition_state(l,transitions[j]);append_outbound_transition_state(r,current.delivery->transitions[j]);check(l==r,"checkpoint conditional transition prefix mismatch");}
        check(covered.emplace(key,transitions.size()-1U).second,"checkpoint duplicate conditional transition");
        check(outbox_admin_by_request_.emplace(op_key(a.request_digest),i).second,"checkpoint duplicate conditional request");
        auto& entries=outbox_admin_by_operation_[key];check(entries.size()<kOutboxAdminPerOperationLimit,"checkpoint conditional receipt bound");entries.push_back(i);
    }
    for(const auto& entry:outbound_)if(entry.delivery)for(std::size_t i=0U;i<entry.delivery->transitions.size();++i)
        if(entry.delivery->transitions[i].actor.starts_with("CONDITIONAL_UID_"))check(covered.contains({op_key(entry.record.operation_id),i}),"checkpoint conditional transition lost its receipt");
}


namespace {
struct ActionBindingCommitment final {
    std::uint64_t ordinal{0U};
    std::uint8_t journal_kind{0U};
    std::uint64_t configuration_event{0U};
    datacube::Digest32 payload_digest{};
    friend bool operator==(const ActionBindingCommitment&,
        const ActionBindingCommitment&) = default;
};
struct ActionAdminMetadata final {
    StoredAction action;
    std::uint64_t source_sequence{0U};
    datacube::Digest32 source_record_digest{};
    datacube::Digest32 source_authorization_digest{};
    std::array<std::optional<ActionBindingCommitment>,4U> bindings{};
    std::optional<ActionResultState> result;
};

datacube::Digest32 action_authorization_digest(
    const AuthorizationAccount& authorization) {
    datacube::Octets bytes;
    datacube::append_text(bytes,
        "NATRAV_OVERLAY_ACTION_SOURCE_AUTHORIZATION_V1");
    datacube::append_u8(bytes, 0U);
    append_authorization_account(bytes, authorization);
    return datacube::sha256(bytes);
}

datacube::Octets encode_action_admin_metadata(
    const ActionAdminMetadata& metadata) {
    datacube::Octets bytes;
    datacube::append_text(bytes, metadata.result ? "ACM2" : "ACM1");
    append_action_state(bytes, metadata.action);
    datacube::append_be64(bytes, metadata.source_sequence);
    append_digest(bytes, metadata.source_record_digest);
    append_digest(bytes, metadata.source_authorization_digest);
    for (const auto& binding : metadata.bindings) {
        datacube::append_u8(bytes, binding.has_value() ? 1U : 0U);
        if (!binding) { continue; }
        datacube::append_be64(bytes, binding->ordinal);
        datacube::append_u8(bytes, binding->journal_kind);
        datacube::append_be64(bytes, binding->configuration_event);
        append_digest(bytes, binding->payload_digest);
    }
    if (metadata.result) {
        const auto& result = *metadata.result;
        append_action_result_binding(bytes, result.binding);
        datacube::append_be64(bytes, result.binding.reserved_payload_bytes);
        datacube::append_u8(bytes, result.outcome ? static_cast<std::uint8_t>(*result.outcome) : 0U);
        if (result.outcome) {
            if (!result.operation_id || !result.record_digest) app_fail("JOURNAL_CORRUPT", "incomplete result commitment");
            append_digest(bytes, *result.operation_id);
            append_digest(bytes, *result.record_digest);
        }
    }
    return bytes;
}

ActionAdminMetadata decode_action_admin_metadata(
    const datacube::OctetView bytes) {
    datacube::Reader reader(bytes, "conditional action metadata");
    const auto magic = datacube::octets_text(reader.read_exact(4U, "magic"), "magic", true);
    if (magic != "ACM1" && magic != "ACM2") {
        app_fail("JOURNAL_CORRUPT", "conditional action metadata version");
    }
    ActionAdminMetadata metadata;
    metadata.action = read_action_state(reader);
    metadata.source_sequence = reader.read_be64("source sequence");
    metadata.source_record_digest = read_digest(reader, "source record digest");
    metadata.source_authorization_digest = read_digest(
        reader, "source authorization digest");
    for (auto& binding : metadata.bindings) {
        const auto present = reader.read_u8("binding marker");
        if (present > 1U) {
            app_fail("JOURNAL_CORRUPT", "conditional action binding marker");
        }
        if (present == 0U) { continue; }
        binding = ActionBindingCommitment{
            .ordinal = reader.read_be64("binding ordinal"),
            .journal_kind = reader.read_u8("binding kind"),
            .configuration_event = reader.read_be64("binding configuration"),
            .payload_digest = read_digest(reader, "binding payload digest"),
        };
    }
    if (magic == "ACM2") {
        ActionResultState result{.binding = read_action_result_binding(reader),
            .outcome = std::nullopt, .operation_id = std::nullopt, .record_digest = std::nullopt};
        result.binding.reserved_payload_bytes = reader.read_be64("reserved result payload");
        if (!valid_action_result_binding(result.binding)) app_fail("JOURNAL_CORRUPT", "invalid selected result binding");
        const auto outcome = reader.read_u8("selected result outcome");
        if (outcome > 3U) app_fail("JOURNAL_CORRUPT", "invalid selected result outcome");
        if (outcome != 0U) {
            result.outcome = static_cast<ActionResultOutcome>(outcome);
            result.operation_id = read_digest(reader, "result operation");
            result.record_digest = read_digest(reader, "result digest");
        }
        metadata.result = std::move(result);
    }
    reader.require_eof("conditional action metadata");
    if (encode_action_admin_metadata(metadata) !=
        datacube::Octets(bytes.begin(), bytes.end())) {
        app_fail("JOURNAL_CORRUPT", "noncanonical conditional action metadata");
    }
    return metadata;
}

datacube::Octets action_state_bytes(const StoredAction& action) {
    datacube::Octets bytes;
    append_action_state(bytes, action);
    return bytes;
}

bool same_action_contract(const StoredAction& left,
    const StoredAction& right) {
    return left.action_id == right.action_id &&
        left.record_digest == right.record_digest &&
        left.issuer == right.issuer &&
        left.peer_generation == right.peer_generation &&
        left.queue_sequence == right.queue_sequence &&
        left.amount == right.amount &&
        left.admitted_unix_ms == right.admitted_unix_ms &&
        left.not_before_unix_ms == right.not_before_unix_ms &&
        left.expires_unix_ms == right.expires_unix_ms &&
        left.limits.counter_budget == right.limits.counter_budget &&
        left.limits.maximum_increment == right.limits.maximum_increment &&
        left.limits.maximum_defer_ms == right.limits.maximum_defer_ms &&
        left.limits.expiry_ms == right.limits.expiry_ms &&
        left.policy_digest == right.policy_digest &&
        left.rule_digest == right.rule_digest;
}

void action_condition_pause(const char* phase) {
    const std::string key = std::string(
        "NATRAV_OVERLAY_TEST_ACTION_CONDITION_") + phase + "_MS";
    if (const char* raw = std::getenv(key.c_str())) {
        const auto delay = parse_u64(raw, key, 1U, 10'000U);
        const std::string line = std::string("ACTION_CONDITION_") + phase + "\n";
        static_cast<void>(::write(STDERR_FILENO, line.data(), line.size()));
        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    }
}
}  // namespace


datacube::Octets NodeState::action_admin_metadata_locked(
    const std::size_t action_index) const {
    const auto& action = actions_.at(action_index);
    const auto source_it = inbound_index_.find(op_key(action.action_id));
    if (source_it == inbound_index_.end()) {
        app_fail("JOURNAL_CORRUPT", "conditional action source missing");
    }
    const auto& source = inbound_.at(source_it->second);
    if (!source.authorization || source.record.operation_id != action.action_id ||
        source.record_digest != action.record_digest) {
        app_fail("JOURNAL_CORRUPT", "conditional action source binding invalid");
    }
    ActionAdminMetadata metadata{
        .action = action,
        .source_sequence = source.sequence,
        .source_record_digest = source.record_digest,
        .source_authorization_digest = action_authorization_digest(
            *source.authorization),
        .bindings = {},
        .result = std::nullopt,
    };
    const auto selected_result = action_results_.find(op_key(action.action_id));
    if (selected_result != action_results_.end()) metadata.result = selected_result->second;
    const auto binding_it = action_binding_index_.find(op_key(action.action_id));
    if (binding_it != action_binding_index_.end()) {
        for (std::size_t slot = 0U; slot < metadata.bindings.size(); ++slot) {
            if (!binding_it->second[slot]) { continue; }
            const auto ordinal = *binding_it->second[slot];
            const auto& binding = configuration_bindings_.at(ordinal);
            metadata.bindings[slot] = ActionBindingCommitment{
                .ordinal = static_cast<std::uint64_t>(ordinal) + 1U,
                .journal_kind = binding.journal_kind,
                .configuration_event = binding.configuration_event,
                .payload_digest = binding.payload_digest,
            };
        }
    }
    return encode_action_admin_metadata(metadata);
}

datacube::Digest32 NodeState::action_admin_root_locked(
    const datacube::Digest32& action_id) const {
    const auto found = action_admin_by_action_.find(op_key(action_id));
    if (found == action_admin_by_action_.end() || found->second.empty()) {
        return datacube::Digest32{};
    }
    return datacube::sha256(encode_action_admin_record(
        action_administration_.at(found->second.back())));
}

std::string NodeState::action_condition_json_locked(
    const std::size_t action_index) const {
    const auto& action = actions_.at(action_index);
    const auto metadata = action_admin_metadata_locked(action_index);
    if (metadata.size() > kActionAdminMetadataLimit) {
        return "{\"available\":false,\"code\":\"ACTION_ADMIN_HISTORY_LIMIT\"}";
    }
    const auto root = action_admin_root_locked(action.action_id);
    const auto selected = action_selected_digest(metadata, root);
    const auto found = action_admin_by_action_.find(op_key(action.action_id));
    const auto count = found == action_admin_by_action_.end() ? 0U :
        found->second.size();
    return std::string("{\"format\":\"ACTION_SEMANTIC_SELECTION_V1\"") +
        ",\"state_digest\":" +
        json_string(datacube::hex_lower(selected)) +
        ",\"metadata_digest\":" +
        json_string(datacube::hex_lower(datacube::sha256(metadata))) +
        ",\"metadata_bytes\":" + std::to_string(metadata.size()) +
        ",\"previous_action_root\":" +
        json_string(datacube::hex_lower(root)) +
        ",\"retained_actions\":" + std::to_string(count) +
        ",\"latest_action\":" +
        (count == 0U ? std::string("null") :
            action_admin_record_json(action_administration_.at(
                found->second.back()))) + "}";
}

std::string NodeState::action_result_status_locked(const datacube::Digest32& action) const {
    const auto found = action_results_.find(op_key(action));
    if (found == action_results_.end()) return "null";
    const auto& result = found->second;
    return std::string("{\"reserved_payload_bytes\":") + std::to_string(result.binding.reserved_payload_bytes) +
        ",\"capacity_state\":" + json_string(result.binding.reserved_payload_bytes == 0U ? "LEGACY_UNRESERVED" :
            (result.outcome ? "CONVERTED" : "RESERVED")) +
        ",\"operation_id\":" + (result.operation_id ? json_string(op_key(*result.operation_id)) : std::string("null")) +
        ",\"record_digest\":" + (result.record_digest ? json_string(op_key(*result.record_digest)) : std::string("null")) + "}";
}

std::string NodeState::action_cancel_observation_json(
    const datacube::Digest32& action_id) const {
    std::lock_guard lock(mutex_);
    const auto found = action_index_.find(op_key(action_id));
    if (found == action_index_.end()) {
        app_fail("ACTION_NOT_FOUND", "action is not present in the durable queue");
    }
    const auto& action = actions_.at(found->second);
    return std::string("{\"action_id\":") +
        json_string(operation_id_text(action.action_id)) +
        ",\"status\":" + json_string(action_status_name(action)) +
        ",\"attempts\":" + std::to_string(action.attempts) +
        ",\"completed_unix_ms\":" +
        (action.completed_unix_ms ? std::to_string(*action.completed_unix_ms) :
            std::string("null")) +
        ",\"cancelled_unix_ms\":" +
        (action.cancelled_unix_ms ? std::to_string(*action.cancelled_unix_ms) :
            std::string("null")) +
        ",\"expired_unix_ms\":" +
        (action.expired_unix_ms ? std::to_string(*action.expired_unix_ms) :
            std::string("null")) +
        ",\"reserved_amount\":" +
        std::to_string(action_is_pending(action) ? action.amount : 0U) +
        ",\"action_result\":" + action_result_status_locked(action_id) +
        ",\"condition\":" + action_condition_json_locked(found->second) + "}";
}

datacube::Octets NodeState::conditional_action_result_locked(
    const StoredAction& terminal, ActionResultState& result) const {
    const auto source = inbound_index_.find(op_key(terminal.action_id));
    if (source == inbound_index_.end() || result.outcome || !terminal.cancelled_unix_ms) {
        app_fail("JOURNAL_CORRUPT", "invalid conditional result source");
    }
    const auto record = action_result_record(node_id_, terminal, inbound_.at(source->second),
        result.binding, ActionResultOutcome::cancelled);
    const auto policy = action_result_outbound_policy(result.binding, *terminal.cancelled_unix_ms);
    auto payload = action_result_transaction_payload(ActionResultOutcome::cancelled,
        action_terminal_payload(terminal.action_id, *terminal.cancelled_unix_ms,
            terminal.cancellation_reason), record, policy);
    result.outcome = ActionResultOutcome::cancelled;
    result.operation_id = record.operation_id;
    result.record_digest = evidence_record_digest(record);
    return payload;
}

namespace {
// AAT2 binds the ordinary AAT1 administrative receipt and its exact NAT1 result
// conversion. Neither component is independently appended to the journal.
datacube::Octets action_admin_composite(const ActionAdminRecord& record,
    const datacube::OctetView result) {
    const auto admin = encode_action_admin_record(record);
    if (result.empty()) return admin;
    datacube::Octets bytes;
    datacube::append_text(bytes, "AAT2");
    datacube::append_be32(bytes, static_cast<std::uint32_t>(admin.size()));
    datacube::append_octets(bytes, admin);
    datacube::append_be32(bytes, static_cast<std::uint32_t>(result.size()));
    datacube::append_octets(bytes, result);
    return bytes;
}
}

std::string NodeState::conditional_action_cancel(
    const ActionAdminRequest& request,
    const RuntimeConfig& config,
    const std::uint32_t uid,
    const std::uint32_t gid,
    const std::uint32_t pid,
    const std::uint64_t configuration_event,
    bool* const applied) {
    validate_action_admin_request(request);
    std::lock_guard lock(mutex_);
    if (applied) { *applied = false; }
    if (poisoned_) { app_fail("STATE_POISONED", "restart the writer"); }
    if (config.format_version < 8U || configuration_event == 0U) {
        app_fail("ACTION_CONDITION_POLICY_VERSION",
            "conditional action administration requires durable V8+ local policy");
    }
    if (!local_control_allows(config.local_control, uid,
            LocalControlClass::action)) {
        app_fail("LOCAL_CONTROL_CLASS_DENIED", "ACTION is required");
    }
    const auto key = op_key(request.action);
    const auto found = action_index_.find(key);
    if (found == action_index_.end()) {
        app_fail("ACTION_NOT_FOUND", "action is not present in the durable queue");
    }
    const auto request_digest = action_admin_request_digest(request, uid);
    const auto prior_request = action_admin_by_request_.find(
        op_key(request_digest));
    const auto response = [&](const ActionAdminRecord& accepted,
                              const bool duplicate) {
        return std::string("{\"format\":\"NATRAV_OVERLAY_CONDITIONAL_ACTION_V1\",\"status\":") +
            json_string(duplicate ? "ALREADY_APPLIED" : "APPLIED") +
            ",\"action_id\":" + json_string(key) +
            ",\"accepted_action\":" + action_admin_record_json(accepted) +
            ",\"observation\":{\"action_id\":" + json_string(key) +
            ",\"status\":" + json_string(action_status_name(
                actions_.at(found->second))) +
            ",\"attempts\":" + std::to_string(actions_.at(found->second).attempts) +
            ",\"reserved_amount\":" +
                std::to_string(action_is_pending(actions_.at(found->second)) ?
                    actions_.at(found->second).amount : 0U) +
            ",\"action_result\":" + action_result_status_locked(request.action) +
            ",\"condition\":" + action_condition_json_locked(found->second) +
            "}}";
    };
    // Exact repeats confirm the already-committed decision under current
    // authority. They do not apply cancellation again after configuration or
    // state has moved on.
    if (prior_request != action_admin_by_request_.end()) {
        return response(action_administration_.at(prior_request->second), true);
    }
    const auto canonical = canonical_runtime_config(config);
    const auto current_configuration = runtime_configuration_digest(canonical);
    if (request.expected_configuration != current_configuration ||
        configuration_event != active_configuration_event(configuration_events_)) {
        app_fail("ACTION_CONFIGURATION_CONFLICT",
            "accepted configuration changed since action selection");
    }
    const auto& before = actions_.at(found->second);
    const auto metadata = action_admin_metadata_locked(found->second);
    const auto root = action_admin_root_locked(request.action);
    if (request.expected_state != action_selected_digest(metadata, root)) {
        app_fail("ACTION_STATE_CONFLICT",
            "durable action changed since selection");
    }
    if (before.completed_unix_ms) {
        app_fail("ACTION_ALREADY_COMPLETED", "completed action cannot be cancelled");
    }
    if (before.expired_unix_ms) {
        app_fail("ACTION_ALREADY_EXPIRED", "expired action cannot be cancelled");
    }
    if (before.cancelled_unix_ms) {
        app_fail("ACTION_CANCELLED", "cancelled action cannot be cancelled again");
    }
    const auto existing = action_admin_by_action_.find(key);
    if (metadata.size() > kActionAdminMetadataLimit ||
        action_administration_.size() >= kActionAdminLimit ||
        (existing != action_admin_by_action_.end() &&
         existing->second.size() >= kActionAdminPerActionLimit)) {
        app_fail("ACTION_ADMIN_HISTORY_LIMIT",
            "conditional action receipt or metadata bound reached");
    }
    ActionAdminRecord record{
        .request = request,
        .uid = uid,
        .gid = gid,
        .pid = pid,
        .unix_ms = unix_milliseconds_now(),
        .configuration_event = configuration_event,
        .request_digest = request_digest,
        .prior_admin_root = root,
        .resulting_metadata_digest = {},
        .before_metadata = metadata,
    };
    const auto decoded = decode_action_admin_metadata(metadata);
    NodeState scratch(MemoryReplayTag{}, node_id_, maximum_journal_bytes_);
    scratch.actions_.push_back(decoded.action);
    scratch.action_index_.emplace(key, 0U);
    scratch.action_reserved_amount_ = decoded.action.amount;
    scratch.index_action(0U);
    scratch.applying_action_administration_ = true;
    scratch.apply_entry(EntryKind::action_cancelled,
        action_terminal_payload(request.action, record.unix_ms, request.reason),
        true);
    auto after = decoded;
    after.action = scratch.actions_.front();
    datacube::Octets result_payload;
    if (after.result) result_payload = conditional_action_result_locked(after.action, *after.result);
    record.resulting_metadata_digest = datacube::sha256(
        encode_action_admin_metadata(after));
    const auto payload = action_admin_composite(record, result_payload);
    apply_action_administration(payload, true);
    action_condition_pause("BEFORE_COMMIT");
    append_entry(EntryKind::action_administration, payload);
    action_condition_pause("AFTER_COMMIT");
    if (applied) { *applied = true; }
    return response(action_administration_.back(), false);
}

void NodeState::apply_action_administration(
    const datacube::OctetView payload,
    const bool validate_only) {
    datacube::OctetView admin_payload = payload;
    datacube::OctetView result_payload;
    if (payload.size() >= 4U && datacube::octets_text(payload.first(4U), "admin magic", true) == "AAT2") {
        datacube::Reader reader(payload, "conditional result cancellation");
        static_cast<void>(reader.read_exact(4U, "magic"));
        const auto admin_size = reader.read_be32("administrative record size");
        if (admin_size > kActionAdminMetadataLimit + 1024U) app_fail("JOURNAL_CORRUPT", "conditional result admin bound");
        admin_payload = reader.read_exact(admin_size, "administrative record");
        const auto result_size = reader.read_be32("result conversion size");
        if (result_size == 0U || result_size > 4096U) app_fail("JOURNAL_CORRUPT", "conditional result conversion bound");
        result_payload = reader.read_exact(result_size, "result conversion");
        reader.require_eof("conditional result cancellation");
    }
    const auto record = decode_action_admin_record(admin_payload);
    const auto key = op_key(record.request.action);
    const auto found = action_index_.find(key);
    const auto check = [](const bool value, const std::string_view message) {
        if (!value) { app_fail("JOURNAL_CORRUPT", message); }
    };
    check(found != action_index_.end(), "conditional action missing");
    check(record.configuration_event ==
            active_configuration_event(configuration_events_),
        "conditional action configuration is not active");
    const auto& configuration = configuration_events_.at(
        static_cast<std::size_t>(record.configuration_event - 1U));
    const auto config = parse_runtime_config(configuration.canonical,
        "/conditional-action-history", IdentityFileValidation::deferred);
    check(config.format_version >= 8U &&
            configuration.digest == record.request.expected_configuration &&
            local_control_allows(config.local_control, record.uid,
                LocalControlClass::action),
        "conditional action historical authority mismatch");
    const auto metadata = action_admin_metadata_locked(found->second);
    check(record.before_metadata == metadata &&
            record.prior_admin_root ==
                action_admin_root_locked(record.request.action),
        "conditional action prior state mismatch");
    check(record.request.expected_state == action_selected_digest(
            record.before_metadata, record.prior_admin_root),
        "conditional action selected digest mismatch");
    check(!action_admin_by_request_.contains(op_key(record.request_digest)),
        "duplicate conditional action event");
    const auto existing = action_admin_by_action_.find(key);
    check(action_administration_.size() < kActionAdminLimit &&
            (existing == action_admin_by_action_.end() ||
             existing->second.size() < kActionAdminPerActionLimit),
        "conditional action history bound");
    const auto decoded = decode_action_admin_metadata(record.before_metadata);
    check(same_action_contract(decoded.action, actions_.at(found->second)),
        "conditional action immutable contract mismatch");
    NodeState scratch(MemoryReplayTag{}, node_id_, maximum_journal_bytes_);
    scratch.actions_.push_back(decoded.action);
    scratch.action_index_.emplace(key, 0U);
    scratch.action_reserved_amount_ = decoded.action.amount;
    scratch.index_action(0U);
    scratch.applying_action_administration_ = true;
    scratch.apply_entry(EntryKind::action_cancelled,
        action_terminal_payload(record.request.action, record.unix_ms,
            record.request.reason), true);
    auto after = decoded;
    after.action = scratch.actions_.front();
    datacube::Octets expected_result;
    if (after.result) expected_result = conditional_action_result_locked(after.action, *after.result);
    check(expected_result.size() == result_payload.size() &&
        std::equal(expected_result.begin(), expected_result.end(), result_payload.begin()),
        "conditional cancellation detached from its exact action result");
    check(record.resulting_metadata_digest == datacube::sha256(
            encode_action_admin_metadata(after)),
        "conditional action result mismatch");
    if (after.result) {
        const auto source = inbound_index_.find(key);
        const auto result_record = action_result_record(node_id_, after.action,
            inbound_.at(source->second), after.result->binding, ActionResultOutcome::cancelled);
        const auto result_policy = action_result_outbound_policy(after.result->binding, record.unix_ms);
        validate_new_outbound_locked(result_record, result_policy, found->second);
    }
    if (validate_only) { return; }
    applying_runtime_bound_mutation_ = true;
    applying_action_administration_ = true;
    try {
        if (!result_payload.empty()) {
            apply_entry(EntryKind::action_result, result_payload, true);
        } else {
            apply_entry(EntryKind::action_cancelled,
                action_terminal_payload(record.request.action, record.unix_ms,
                    record.request.reason), true);
        }
        applying_runtime_bound_mutation_ = false;
        applying_action_administration_ = false;
    } catch (...) {
        applying_runtime_bound_mutation_ = false;
        applying_action_administration_ = false;
        throw;
    }
    const auto index = action_administration_.size();
    action_administration_.push_back(record);
    action_admin_by_action_[key].push_back(index);
    action_admin_by_request_.emplace(op_key(record.request_digest), index);
}

void NodeState::validate_action_administration_checkpoint() {
    const auto check = [](const bool value, const std::string_view message) {
        if (!value) { app_fail("JOURNAL_CORRUPT", message); }
    };
    action_admin_by_request_.clear();
    action_admin_by_action_.clear();
    std::set<std::string> covered;
    for (std::size_t index = 0U; index < action_administration_.size(); ++index) {
        const auto& record = action_administration_.at(index);
        const auto key = op_key(record.request.action);
        const auto found = action_index_.find(key);
        check(found != action_index_.end() && record.configuration_event > 0U &&
                record.configuration_event <= configuration_events_.size(),
            "checkpoint conditional action reference missing");
        const auto& configuration = configuration_events_.at(
            static_cast<std::size_t>(record.configuration_event - 1U));
        check(configuration.kind != "REJECTED" &&
                configuration.digest == record.request.expected_configuration,
            "checkpoint conditional action configuration mismatch");
        const auto config = parse_runtime_config(configuration.canonical,
            "/conditional-action-checkpoint", IdentityFileValidation::deferred);
        check(config.format_version >= 8U &&
                local_control_allows(config.local_control, record.uid,
                    LocalControlClass::action),
            "checkpoint conditional action authority mismatch");
        check(record.prior_admin_root ==
                action_admin_root_locked(record.request.action) &&
                record.request.expected_state == action_selected_digest(
                    record.before_metadata, record.prior_admin_root),
            "checkpoint conditional action chain mismatch");
        const auto before = decode_action_admin_metadata(record.before_metadata);
        const auto& current = actions_.at(found->second);
        check(same_action_contract(before.action, current),
            "checkpoint conditional action contract mismatch");
        const auto source = inbound_index_.find(key);
        check(source != inbound_index_.end(),
            "checkpoint conditional action source missing");
        const auto& inbound = inbound_.at(source->second);
        check(inbound.authorization.has_value() &&
                before.source_sequence == inbound.sequence &&
                before.source_record_digest == inbound.record_digest &&
                before.source_authorization_digest ==
                    action_authorization_digest(*inbound.authorization),
            "checkpoint conditional action source mismatch");
        // Bindings present before cancellation must still name the exact same
        // historical records. Conditional cancellation itself is attributed by
        // this receipt rather than a fabricated runtime-bound mutation entry.
        const auto current_metadata = decode_action_admin_metadata(
            action_admin_metadata_locked(found->second));
        check(before.bindings == current_metadata.bindings,
            "checkpoint conditional action binding mismatch");
        NodeState scratch(MemoryReplayTag{}, node_id_, maximum_journal_bytes_);
        scratch.actions_.push_back(before.action);
        scratch.action_index_.emplace(key, 0U);
        scratch.action_reserved_amount_ = before.action.amount;
        scratch.index_action(0U);
        scratch.applying_action_administration_ = true;
        scratch.apply_entry(EntryKind::action_cancelled,
            action_terminal_payload(record.request.action, record.unix_ms,
                record.request.reason), true);
        auto after = before;
        after.action = scratch.actions_.front();
        if (after.result) static_cast<void>(conditional_action_result_locked(after.action, *after.result));
        check(after.result == current_metadata.result,
            "checkpoint conditional result or reservation mismatch");
        check(record.resulting_metadata_digest == datacube::sha256(
                encode_action_admin_metadata(after)),
            "checkpoint conditional action result mismatch");
        check(action_state_bytes(after.action) == action_state_bytes(current),
            "checkpoint conditional action terminal state mismatch");
        check(current.last_error_code == "ACTION_CANCELLED_CONDITIONAL",
            "checkpoint conditional action marker missing");
        check(action_admin_by_request_.emplace(
                op_key(record.request_digest), index).second,
            "checkpoint duplicate conditional action request");
        auto& entries = action_admin_by_action_[key];
        check(entries.size() < kActionAdminPerActionLimit,
            "checkpoint conditional action receipt bound");
        entries.push_back(index);
        check(covered.emplace(key).second,
            "checkpoint duplicate conditional action cancellation");
    }
    for (const auto& action : actions_) {
        if (action.last_error_code == "ACTION_CANCELLED_CONDITIONAL") {
            check(covered.contains(op_key(action.action_id)),
                "checkpoint conditional cancellation lost its receipt");
        }
    }
}

}  // namespace natrav_overlay
