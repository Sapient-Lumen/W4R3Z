#pragma once

#include "authorization.hpp"
#include "local_author.hpp"
#include "subscribed_source.hpp"
#include "import_scheduler.hpp"
#include <set>
#include <tuple>
#include "evidence_query.hpp"
#include "outbox_query.hpp"
#include "action_query.hpp"
#include "action_selection.hpp"
#include "action_admin.hpp"
#include "delivery_index.hpp"
#include "pending_capacity.hpp"
#include "outbox_admin.hpp"
#include "submission_work.hpp"
#include "runtime_status.hpp"
#include "configuration_history.hpp"
#include "control_history.hpp"
#include <array>
#include "evidence_feed.hpp"
#include "consumer.hpp"
#include "consumer_inventory.hpp"
#include "publication_inventory.hpp"
#include "subscription_inventory.hpp"
#include "source_view_inventory.hpp"
#include "view_bindings.hpp"
#include "projection_scheduler.hpp"
#include "publication_channel.hpp"
#include "action_result_query.hpp"
#include "result_review.hpp"
#include "source_subscription.hpp"
#include "evidence_index.hpp"
#include "state_auth.hpp"
#include "custody_state.hpp"

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {
struct RuntimeConfig;
struct TlsSessionInfo;

inline constexpr std::uint32_t kCurrentStorageSchemaVersion = 2U;

enum class AuthorizationDecisionKind : std::uint8_t {
    admitted = 1U,
    denied = 2U,
};

struct AuthorizationAccount final {
    datacube::Digest32 operation_id;
    datacube::Digest32 record_digest;
    std::string peer_node;
    std::string peer_generation;
    AuthorizedOperationClass operation_class{AuthorizedOperationClass::evidence};
    std::string resource;
    datacube::Digest32 policy_digest;
    std::optional<datacube::Digest32> rule_digest;
    std::uint64_t decided_unix_ms{0U};
    AuthorizationDecisionKind decision{AuthorizationDecisionKind::admitted};
    std::string reason_code;
};

struct AuthorizationDenial final {
    AuthorizationAccount authorization;
    std::string issuer;
    std::string recipient;
    std::string scope;
};

struct StoredInbound final {
    EvidenceRecord record;
    datacube::Digest32 record_digest;
    std::uint64_t sequence{0U};
    std::optional<datacube::Digest32> superseded_by;
    std::optional<AuthorizationAccount> authorization;
    // Immutable, sparse provenance; do not inline a 160-byte account in every remote record.
    std::shared_ptr<const LocalAuthorship> local_authorship{};
    std::shared_ptr<const SubscribedSource> subscribed_source{};
};

struct OutboundPolicy final {
    std::uint64_t created_unix_ms{0U};
    std::uint64_t expires_unix_ms{0U};
    std::uint32_t maximum_attempts{0U};
    std::uint32_t initial_backoff_ms{0U};
    std::uint32_t maximum_backoff_ms{0U};
    std::optional<datacube::Digest32> peer_spki_sha256;
    std::optional<std::string> peer_generation;

    bool operator==(const OutboundPolicy&) const = default;
};

struct QueueLimits final {
    std::uint64_t global_max_records{4'096U};
    std::uint64_t global_max_payload_bytes{67'108'864U};
    std::uint64_t peer_max_records{1'024U};
    std::uint64_t peer_max_payload_bytes{16'777'216U};

    bool operator==(const QueueLimits&) const = default;
};

enum class OutboundTransitionKind : std::uint8_t {
    rebound = 1U,
    cancelled = 2U,
    rejected = 3U,
    retried = 4U,
};

struct OutboundTransition final {
    OutboundTransitionKind kind{OutboundTransitionKind::rebound};
    std::uint64_t unix_ms{0U};
    std::string actor;
    std::string reason;
    std::string from_generation;
    datacube::Digest32 from_spki_sha256;
    std::optional<std::string> to_generation;
    std::optional<datacube::Digest32> to_spki_sha256;
};

struct OutboundDeliveryState final {
    OutboundPolicy policy;
    std::uint32_t attempts{0U};
    std::optional<std::uint64_t> last_attempt_unix_ms;
    std::uint64_t next_attempt_unix_ms{0U};
    std::string last_error_code;
    std::string last_error_detail;
    std::optional<std::uint64_t> expired_unix_ms;
    std::string expiry_reason;
    std::optional<std::uint64_t> cancelled_unix_ms;
    std::string cancellation_reason;
    std::vector<OutboundTransition> transitions;
};

struct OutboundRejection final {
    std::uint64_t rejected_unix_ms{0U};
    std::string code;
    std::string detail;
    datacube::Digest32 detail_digest;
    std::string peer_generation;
    datacube::Digest32 peer_spki_sha256;
    datacube::Digest32 policy_digest;
};

struct StoredOutbound final {
    EvidenceRecord record;
    datacube::Digest32 record_digest;
    std::uint64_t queue_sequence{0U};
    std::optional<DeliveryReceipt> receipt;
    std::optional<OutboundDeliveryState> delivery;
};

// Ephemeral in-process selection, never a wire token or durable authority.
// It contains no payload, error text, receipt, or transition-history vector.
struct DeliverySelection final {
    DeliveryChoiceKind kind{DeliveryChoiceKind::none};
    std::optional<std::uint64_t> next_wake;
    std::size_t index{0U};
    datacube::Digest32 operation_id{};
    datacube::Digest32 record_digest{};
    std::string recipient;
    std::uint64_t version{0U};
    std::uint64_t configuration_event{0U};
    std::optional<OutboundPolicy> policy;
    std::uint32_t attempts{0U};
    std::uint64_t next_attempt{0U};
    std::size_t encoded_bytes{0U};
    std::uint64_t tree_nodes_visited{0U};
    std::uint64_t key_buckets_checked{0U};
    std::uint64_t metadata_records_read{0U};
};

struct StoredAction final {
    datacube::Digest32 action_id;
    datacube::Digest32 record_digest;
    std::string issuer;
    std::string peer_generation;
    std::uint64_t queue_sequence{0U};
    std::uint64_t amount{0U};
    std::uint64_t admitted_unix_ms{0U};
    std::uint64_t not_before_unix_ms{0U};
    std::uint64_t expires_unix_ms{0U};
    ActionLimits limits;
    datacube::Digest32 policy_digest;
    datacube::Digest32 rule_digest;
    std::uint32_t attempts{0U};
    std::optional<std::uint64_t> last_started_unix_ms;
    std::optional<std::uint64_t> completed_unix_ms;
    std::optional<std::uint64_t> cancelled_unix_ms;
    std::optional<std::uint64_t> expired_unix_ms;
    std::optional<std::uint64_t> counter_before;
    std::optional<std::uint64_t> counter_after;
    std::optional<datacube::Digest32> receipt_digest;
    std::string cancellation_reason;
    std::string expiry_reason;
    std::string last_error_code;
};

struct ActionResultBinding final {
    std::string result_scope;
    datacube::Digest32 policy_digest;
    datacube::Digest32 rule_digest;
    std::uint64_t configuration_event{0U};
    std::string peer_generation;
    datacube::Digest32 peer_spki_sha256;
    std::uint32_t maximum_attempts{0U};
    std::uint32_t initial_backoff_ms{0U};
    std::uint32_t maximum_backoff_ms{0U};
    std::uint64_t delivery_expiry_ms{0U};
    // Zero identifies legacy V18 bindings: never retroactively reserve capacity.
    std::uint64_t reserved_payload_bytes{0U};

    bool operator==(const ActionResultBinding&) const = default;
};

enum class ActionResultOutcome : std::uint8_t {
    executed = 1U,
    cancelled = 2U,
    expired = 3U,
};

struct ActionResultState final {
    ActionResultBinding binding;
    std::optional<ActionResultOutcome> outcome;
    std::optional<datacube::Digest32> operation_id;
    std::optional<datacube::Digest32> record_digest;
    bool operator==(const ActionResultState&) const = default;
};

struct JournalRecovery final {
    std::uint64_t discarded_tail_bytes{0U};
    std::uint64_t valid_prefix_bytes{0U};
};

struct StorageMigration final {
    std::uint32_t from_version{0U};
    std::uint32_t to_version{0U};
    std::uint64_t migrated_unix_ms{0U};
};

struct CompactionResult final {
    std::uint64_t generation{0U};
    std::uint64_t compacted_unix_ms{0U};
    std::uint64_t before_bytes{0U};
    std::uint64_t after_bytes{0U};
    std::uint64_t retained_records{0U};
    datacube::Digest32 logical_state_digest;
};

struct CheckpointImage final {
    std::optional<StateAuthentication> authentication;
    datacube::Octets journal_bytes;
    std::uint32_t storage_schema_version{0U};
    std::uint64_t maintenance_generation{0U};
    std::uint64_t retained_records{0U};
    datacube::Digest32 logical_state_digest;
};

// Runtime configuration provenance is independent of representation maintenance.
// Configurations contain paths to identity files, never private-key material.
struct RuntimeConfigurationEvent final {
    std::string kind;  // BOOTSTRAP, ACTIVATE, ROLLBACK, RELOCATE, or REJECTED
    std::string generation;
    datacube::Digest32 digest;
    std::string canonical;
    std::uint64_t unix_ms{0U};
    std::string actor;
    std::string reason;
    std::string error_code;
};

struct RuntimeMutationBinding final {
    std::uint64_t configuration_event{0U};  // one-based accepted event ordinal
    std::uint8_t journal_kind{0U};
    datacube::Digest32 payload_digest;
    std::optional<datacube::Digest32> operation_id;
};


enum class LocalControlDecisionKind : std::uint8_t {
    authorized = 1U,
    denied = 2U,
};

struct LocalControlEvent final {
    datacube::Digest32 request_id;
    std::uint32_t uid{0U};
    std::uint32_t gid{0U};
    std::uint32_t pid{0U};
    std::string command;
    std::string command_class;
    std::uint64_t configuration_event{0U};
    std::uint64_t unix_ms{0U};
    LocalControlDecisionKind decision{LocalControlDecisionKind::denied};
    std::string error_code;
};

enum class LifecycleTransitionKind : std::uint8_t {
    quiesced = 1U,
    resumed = 2U,
    drain_started = 3U,
    drain_completed = 4U,
    drain_deadline = 5U,
    shutdown_requested = 6U,
};

struct LifecycleEvent final {
    LifecycleTransitionKind kind{LifecycleTransitionKind::quiesced};
    datacube::Digest32 request_id;
    std::uint32_t uid{0U};
    std::uint32_t pid{0U};
    std::uint64_t configuration_event{0U};
    std::uint64_t unix_ms{0U};
    std::uint32_t deadline_ms{0U};
    std::uint64_t pending_outbound{0U};
    std::uint64_t pending_actions{0U};
    std::string reason;
};

struct StateSnapshot final {
    std::optional<StateAuthentication> authentication;
    std::string node_id;
    std::filesystem::path state_directory;
    std::uint32_t storage_schema_version{0U};
    std::uint64_t journal_bytes{0U};
    std::uint64_t maintenance_generation{0U};
    std::optional<std::uint64_t> last_compaction_unix_ms;
    std::uint64_t last_compaction_before_bytes{0U};
    std::uint64_t last_compaction_after_bytes{0U};
    std::uint64_t last_compaction_retained_records{0U};
    datacube::Digest32 logical_state_digest;
    std::optional<datacube::Digest32> restored_backup_id;
    std::string restored_backup_generation;
    std::optional<std::uint64_t> restored_backup_unix_ms;
    std::vector<StoredInbound> inbound;
    std::vector<StoredOutbound> outbound;
    QueueLimits queue_limits;
    QueueUsage queue_usage;
    std::vector<AuthorizationDenial> authorization_denials;
    std::vector<StoredAction> actions;
    std::uint64_t action_counter_value{0U};
    std::uint64_t action_reserved_amount{0U};
    std::vector<JournalRecovery> recoveries;
    std::vector<StorageMigration> migrations;
    std::vector<RuntimeConfigurationEvent> configuration_events;
    std::vector<RuntimeMutationBinding> configuration_bindings;
    std::vector<LocalControlEvent> local_control_events;
    std::vector<LifecycleEvent> lifecycle_events;
    std::vector<DurableConsumer> consumers;
    std::vector<ProjectionSchedule> projection_schedules;
    std::vector<ImportAutoState> import_schedules;
    std::vector<SourceSubscription> source_subscriptions;
    std::vector<std::string> outbox_admin_accounts;
    std::vector<std::string> action_admin_accounts;
    std::vector<PublicationChannel> publication_channels;
    std::vector<DurableCustodyCase> custody_cases;
};

enum class QueueDisposition {
    queued,
    already_pending,
    already_acked,
    already_rejected,
};

// Bounded enqueue result: never owns an EvidenceRecord or a transition vector.
// status points only at the static strings returned by outbound_status_name.
// The optional bounded receipt serves the offline one-shot compatibility path.
struct QueueResult final {
    QueueDisposition disposition{QueueDisposition::queued};
    datacube::Digest32 operation_id{};
    datacube::Digest32 record_digest{};
    std::string_view status;
    bool has_delivery_policy{false};
    std::optional<DeliveryReceipt> receipt;
};

// Later coherent observation for a submission reply. No references to mutable
// store objects escape the mutex, and no payload/history/policy is copied.
struct SubmissionObservation final {
    datacube::Digest32 operation_id{};
    datacube::Digest32 record_digest{};
    std::string recipient;
    AuthorizedOperationClass operation_class{AuthorizedOperationClass::evidence};
    std::string resource;
    std::string_view status;
};

enum class AdmissionDisposition {
    committed,
    duplicate,
};

struct AdmissionResult final {
    AdmissionDisposition disposition{AdmissionDisposition::committed};
    DeliveryReceipt receipt;
    bool action_queued{false};
};

struct PendingWorkCounts final {
    std::uint64_t pending_outbound{0U};
    std::uint64_t pending_actions{0U};
};

// Narrow, payload-free records returned by strict in-memory replay for the
// offline correlated-stop audit. These values are observations of completely
// authenticated and semantically replayed state; they are never accepted as
// durable authority or mutation inputs.
struct OfflineConfigurationReference final {
    std::uint64_t event{0U};
    std::string generation;
    datacube::Digest32 digest;
    datacube::Digest32 prefix;
};

struct OfflineControlDecisionMatch final {
    std::uint64_t ordinal{0U};
    OfflineConfigurationReference configuration;
    datacube::Digest32 history_prefix;
    datacube::Digest32 request_id;
    std::uint32_t uid{0U};
    std::uint32_t gid{0U};
    std::uint32_t pid{0U};
    std::uint64_t unix_ms{0U};
    std::string command;
    std::string command_class;
    LocalControlDecisionKind decision{LocalControlDecisionKind::denied};
    std::string error_code;
};

struct OfflineLifecycleMatch final {
    std::uint64_t ordinal{0U};
    OfflineConfigurationReference configuration;
    datacube::Digest32 history_prefix;
    datacube::Digest32 request_id;
    std::uint32_t uid{0U};
    std::uint32_t pid{0U};
    std::uint64_t unix_ms{0U};
    LifecycleTransitionKind kind{LifecycleTransitionKind::quiesced};
    std::uint32_t deadline_ms{0U};
    std::uint64_t pending_outbound{0U};
    std::uint64_t pending_actions{0U};
    std::uint64_t reason_bytes{0U};
    datacube::Digest32 reason_digest;
};

struct OfflineCorrelatedStopReplay final {
    StateAuthentication authentication;
    std::uint64_t journal_bytes{0U};
    std::uint64_t retained_decisions{0U};
    std::uint64_t retained_lifecycle_events{0U};
    PendingWorkCounts pending;
    std::vector<OfflineControlDecisionMatch> decisions;
    std::vector<OfflineLifecycleMatch> lifecycle;
};

class NodeState final {
public:
    NodeState(
        std::filesystem::path state_directory,
        std::string node_id,
        std::uint64_t maximum_journal_bytes,
        QueueLimits queue_limits = {}, bool migration_source = false);
    ~NodeState() = default;

    // Strict, read-only replay of exactly one checkpoint frame. No filesystem
    // objects or recoverable-tail semantics are used for imported snapshots.
    [[nodiscard]] static StateSnapshot validate_checkpoint_image(
        datacube::OctetView frame, std::string node_id,
        std::uint64_t maximum_journal_bytes,
        StateAuthKeyPtr key = process_state_auth_key());

    // Reconstruct a complete, authenticated prefix in memory; return a plain
    // canonical checkpoint only after every MAC and application invariant passes.
    [[nodiscard]] static CheckpointImage checkpoint_authenticated_prefix(
        datacube::OctetView bytes, std::string node_id,
        std::uint64_t maximum_journal_bytes, StateAuthKeyPtr key);

    // Completely authenticate and semantically replay one exact journal in
    // memory, then select bounded request provenance without copying evidence
    // payloads or exposing free-text lifecycle reasons.
    [[nodiscard]] static OfflineCorrelatedStopReplay
        replay_correlated_stop_audit(
            datacube::OctetView bytes, std::string node_id,
            std::uint64_t maximum_journal_bytes, StateAuthKeyPtr key,
            const datacube::Digest32& request_id,
            std::uint32_t maximum_matches);

    NodeState(const NodeState&) = delete;
    NodeState& operator=(const NodeState&) = delete;
    NodeState(NodeState&&) = delete;
    NodeState& operator=(NodeState&&) = delete;

    [[nodiscard]] std::string view_bindings(const ViewBindings& request,
        const RuntimeConfig& config, std::uint32_t uid,
        std::chrono::steady_clock::time_point deadline) const;
    [[nodiscard]] std::string source_view_inventory(const SourceViewInventory& request,
        const RuntimeConfig& config, std::uint32_t uid,
        std::chrono::steady_clock::time_point deadline) const;
    [[nodiscard]] std::string subscription_inventory(const SubscriptionInventory& request,
        const RuntimeConfig& config, std::uint32_t uid,
        std::chrono::steady_clock::time_point deadline) const;
    [[nodiscard]] std::string publication_inventory(const PublicationInventory& request,
        const RuntimeConfig& config, std::uint32_t uid,
        std::chrono::steady_clock::time_point deadline) const;
    [[nodiscard]] std::string consumer_inventory(const ConsumerInventory& request,
        const RuntimeConfig& config, std::uint32_t uid,
        std::chrono::steady_clock::time_point deadline) const;
    [[nodiscard]] std::string commit_result_review(const ResultReviewRequest& request,
        const RuntimeConfig& config, std::uint32_t uid, std::uint32_t gid, std::uint32_t pid,
        std::chrono::steady_clock::time_point deadline);
    [[nodiscard]] std::string result_review_status(const ResultReviewStatus& request,
        const RuntimeConfig& config, std::uint32_t uid) const;
    [[nodiscard]] std::string result_review_history(const ResultReviewHistory& request,
        const RuntimeConfig& config, std::uint32_t uid,
        std::chrono::steady_clock::time_point deadline) const;
    [[nodiscard]] std::string discover_action_results(const ActionResultDiscovery& request,
        const RuntimeConfig& config, std::uint32_t uid,
        std::chrono::steady_clock::time_point deadline) const;
    [[nodiscard]] std::string correlate_action_result(const ActionResultQuery& request,
        const RuntimeConfig& config, std::uint32_t uid,
        std::chrono::steady_clock::time_point deadline) const;
    [[nodiscard]] std::string outbound_recipient(const datacube::Digest32& operation) const;
    [[nodiscard]] std::string conditional_outbox_command(const OutboxAdminRequest& request,
        const RuntimeConfig& config, std::uint32_t uid, std::uint32_t gid, std::uint32_t pid,
        std::uint64_t configuration_event);
    [[nodiscard]] std::string query_outbox(const OutboxQuery& query, const OutboxQueryContext& context) const;
    [[nodiscard]] QueueResult queue_outbound(
        const EvidenceRecord& record,
        const std::optional<OutboundPolicy>& initial_policy = std::nullopt);
    [[nodiscard]] SubmissionObservation observe_submission(
        const datacube::Digest32& operation_id,
        const datacube::Digest32& expected_record_digest) const;
    void ensure_outbound_policy(
        const datacube::Digest32& operation_id,
        const OutboundPolicy& policy);
    [[nodiscard]] DeliverySelection select_delivery(
        const RuntimeConfig& config, const std::string& recipient, std::uint64_t now) const;
    [[nodiscard]] bool maintain_selected_delivery(const DeliverySelection& selection,
        std::uint64_t now, const std::optional<OutboundPolicy>& initial_policy = std::nullopt);
    // Callers retain the existing configuration lease and peer-transition lock.
    [[nodiscard]] bool selected_delivery_is_current(const DeliverySelection& selection, std::uint64_t now) const;
    [[nodiscard]] bool begin_selected_delivery(DeliverySelection& selection,
        std::uint64_t now, std::uint64_t next_attempt);
    [[nodiscard]] std::optional<EvidenceRecord> copy_selected_delivery(
        const DeliverySelection& selection) const;
    void begin_outbound_attempt(
        const datacube::Digest32& operation_id,
        std::uint64_t attempted_unix_ms,
        std::uint64_t next_attempt_unix_ms);
    void record_outbound_failure(
        const datacube::Digest32& operation_id,
        std::string_view code,
        std::string_view detail,
        std::uint64_t next_attempt_unix_ms);
    void record_outbound_rejection(
        const datacube::Digest32& operation_id,
        std::string_view code,
        std::string_view detail,
        std::uint64_t rejected_unix_ms,
        std::string_view authenticated_generation,
        const datacube::Digest32& authenticated_spki_sha256);
    void retry_outbound(
        const datacube::Digest32& operation_id,
        std::uint64_t retried_unix_ms,
        std::string_view actor,
        std::string_view reason);
    void expire_outbound(
        const datacube::Digest32& operation_id,
        std::uint64_t expired_unix_ms,
        std::string_view reason);
    void rebind_outbound(
        const datacube::Digest32& operation_id,
        std::string_view new_generation,
        const datacube::Digest32& new_spki_sha256,
        std::uint64_t rebound_unix_ms,
        std::string_view actor,
        std::string_view reason);
    void cancel_outbound(
        const datacube::Digest32& operation_id,
        std::uint64_t cancelled_unix_ms,
        std::string_view actor,
        std::string_view reason);
    // One-record copies under the existing state mutex for owner-only offline handoff.
    [[nodiscard]] StoredOutbound outbound_record_for_handoff(const datacube::Digest32& operation) const;
    [[nodiscard]] StoredInbound inbound_record_for_handoff(const datacube::Digest32& operation) const;
    void record_outbound_receipt(const DeliveryReceipt& receipt);
    [[nodiscard]] AdmissionResult admit_inbound(
        const EvidenceRecord& record,
        const datacube::Digest32& remote_artifact_digest);
    [[nodiscard]] AdmissionResult admit_inbound_authorized(
        const EvidenceRecord& record,
        const datacube::Digest32& remote_artifact_digest,
        const AuthorizationDecision& decision,
        std::uint64_t decided_unix_ms,
        std::optional<ActionResultBinding> action_result = std::nullopt,
        bool require_action_result = false);
    void record_authorization_denial(
        const EvidenceRecord& record,
        const AuthorizationDecision& decision,
        std::uint64_t decided_unix_ms,
        std::string_view reason_code);
    void begin_action(
        const datacube::Digest32& action_id,
        std::uint64_t started_unix_ms);
    void complete_counter_action(
        const datacube::Digest32& action_id,
        std::uint64_t completed_unix_ms);
    void cancel_action(
        const datacube::Digest32& action_id,
        std::uint64_t cancelled_unix_ms,
        std::string_view reason);
    [[nodiscard]] std::string conditional_action_cancel(
        const ActionAdminRequest& request,
        const RuntimeConfig& config,
        std::uint32_t uid,
        std::uint32_t gid,
        std::uint32_t pid,
        std::uint64_t configuration_event,
        bool* applied = nullptr);
    [[nodiscard]] std::string action_cancel_observation_json(
        const datacube::Digest32& action_id) const;
    void expire_action(
        const datacube::Digest32& action_id,
        std::uint64_t expired_unix_ms,
        std::string_view reason);
    [[nodiscard]] ActionSelection select_action(std::uint64_t now) const;
    [[nodiscard]] bool expire_selected_action(
        const ActionSelection& selection,
        std::uint64_t expired_unix_ms,
        std::string_view reason);
    [[nodiscard]] bool begin_selected_action(
        ActionSelection& selection,
        std::uint64_t started_unix_ms);
    [[nodiscard]] bool complete_selected_counter_action(
        const ActionSelection& selection,
        std::uint64_t completed_unix_ms);
    [[nodiscard]] std::string configuration_history_page(const ConfigurationHistoryRequest& request,
        const datacube::Digest32& authorized_configuration,
        std::chrono::steady_clock::time_point deadline) const;
    void record_runtime_configuration(const RuntimeConfigurationEvent& event);
    [[nodiscard]] std::string control_history_page(const ControlHistoryRequest& request,
        const datacube::Digest32& authorized_configuration,
        std::chrono::steady_clock::time_point deadline) const;
    void record_local_control_event(const LocalControlEvent& event);
    void record_lifecycle_event(const LifecycleEvent& event);
    [[nodiscard]] StateSnapshot snapshot() const;
    // Caller retains the current INSPECT-authorized runtime lease through this
    // bounded observation. No disk reread, history walk, or payload snapshot.
    [[nodiscard]] std::string live_state_head_json() const;
    // Coordinator only, after ALL writer joins and final lifecycle append.
    // Seals this process-local writer before exposing a single terminal sample.
    [[nodiscard]] std::string seal_terminal_state_head_json();
    [[nodiscard]] std::string query_actions(const ActionQuery&, const ActionQueryContext&) const;
    [[nodiscard]] RuntimeStatusMetadata runtime_status_metadata(const RuntimeConfig& config,
        const std::vector<std::string>& registered_peers, bool logical_digest, bool minimal_details = false) const;
    [[nodiscard]] QueueUsage pending_queue_usage() const;
    // Narrow lifecycle/action views: never copy/hash the inbound evidence store.
    [[nodiscard]] PendingWorkCounts pending_work_counts() const;
    [[nodiscard]] std::vector<StoredAction> pending_actions() const;
    [[nodiscard]] std::vector<LifecycleEvent> lifecycle_history() const;
    [[nodiscard]] std::uint64_t configuration_event_reference(
        std::string_view generation, const datacube::Digest32& digest,
        std::string_view canonical) const;
    // Select and encode under the state mutex: no whole-state/payload snapshot.
    // Cursors are process-local continuation tokens, not authority or durable state.
    [[nodiscard]] std::string query_evidence(
        const EvidenceQuery& query, const EvidenceQueryContext& context) const;
    [[nodiscard]] std::string poll_evidence(
        const EvidenceFeed& feed, const EvidenceQueryContext& context) const;
    [[nodiscard]] std::string consumer_command(const ConsumerRequest& request,
        const EvidenceQueryContext& context, std::uint32_t pid,
        std::uint64_t configuration_event);
    [[nodiscard]] std::string publish_projection_result(
        const ConsumerRequest& request,
        const EvidenceQueryContext& context,
        std::uint32_t pid,
        std::uint64_t configuration_event,
        const OutboundPolicy& policy);
    [[nodiscard]] std::string import_auto_command(const ImportAutoRequest& request,
        const RuntimeConfig& config, std::uint32_t uid, std::uint32_t gid, std::uint32_t pid,
        std::uint64_t event, std::uint64_t unix_ms);
    [[nodiscard]] std::vector<ImportCandidate> automatic_import_candidates() const;
    [[nodiscard]] bool automatic_import_step(std::string_view view, const RuntimeConfig& config,
        std::uint64_t event, std::uint32_t uid, std::uint32_t gid, std::uint32_t pid);
    [[nodiscard]] std::string import_subscribed_source(const SourceViewRequest& request,
        const RuntimeConfig& config, std::uint32_t uid, std::uint32_t gid, std::uint32_t pid,
        std::uint64_t configuration_event, std::uint64_t unix_ms);
    [[nodiscard]] std::string source_subscription_command(const SourceSubscriptionRequest& request,
        const RuntimeConfig& config, std::uint32_t uid, std::uint32_t pid,
        std::uint64_t configuration_event, std::uint64_t unix_ms);
    [[nodiscard]] RemoteSourceSubscriptionResponse
        source_subscription_remote_command(
            const RemoteSourceSubscriptionRequest& request,
            const RuntimeConfig& config,
            const TlsSessionInfo& peer,
            std::uint64_t configuration_event,
            std::uint64_t unix_ms);
    [[nodiscard]] std::vector<SourceSubscriptionCandidate>
        automatic_source_subscription_candidates() const;
    [[nodiscard]] bool automatic_source_subscription_step(
        std::string_view grant,
        const RuntimeConfig& config,
        std::uint64_t configuration_event,
        std::uint32_t executor_uid,
        std::uint32_t executor_pid);
    [[nodiscard]] std::string publication_channel_recipient(
        std::uint32_t uid, std::string_view name) const;
    [[nodiscard]] std::string publication_channel_command(
        const PublicationChannelRequest& request,
        const EvidenceQueryContext& context,
        std::uint32_t pid,
        std::uint64_t configuration_event,
        const std::optional<OutboundPolicy>& policy = std::nullopt);
    [[nodiscard]] std::vector<PublicationChannelCandidate>
        automatic_publication_channel_candidates() const;
    [[nodiscard]] bool automatic_publication_channel_step(
        std::string_view key,
        const RuntimeConfig& config,
        std::uint64_t configuration_event,
        std::uint32_t executor_uid,
        std::uint32_t executor_pid,
        const std::optional<OutboundPolicy>& policy = std::nullopt);
    [[nodiscard]] std::vector<ProjectionCandidate> automatic_projection_candidates() const;
    [[nodiscard]] bool automatic_projection_step(std::string_view key, const RuntimeConfig& config,
        std::uint64_t configuration_event, std::uint32_t executor_uid, std::uint32_t executor_pid);
    // Read-only readiness probe: no payload/history copies or logical hashing.
    [[nodiscard]] bool has_pending_outbound_for(std::string_view recipient) const;
    [[nodiscard]] std::string author_evidence(const EvidenceRecord& record,
        const RuntimeConfig& config, std::uint32_t uid, std::uint32_t gid, std::uint32_t pid,
        std::uint64_t configuration_event, std::uint64_t unix_ms);
    [[nodiscard]] DurableCustodyDisposition commit_custody_event(
        const DurableCustodyEvent& event);
    [[nodiscard]] std::optional<DurableCustodyCase> custody_case(
        const datacube::Digest32& envelope) const;
    [[nodiscard]] std::string custody_status_json() const;
    [[nodiscard]] CompactionResult compact();
    [[nodiscard]] std::string authenticate_state(
        StateAuthKeyPtr new_key, std::string_view reason);
    [[nodiscard]] CheckpointImage checkpoint_image(
        std::uint64_t created_unix_ms) const;
    void record_backup_restore(
        const datacube::Digest32& backup_id,
        std::string_view generation,
        std::uint64_t restored_unix_ms);
    [[nodiscard]] const std::string& node_id() const noexcept;
    [[nodiscard]] const std::filesystem::path& state_directory() const noexcept;

private:
    [[nodiscard]] std::string state_head_observation_json_locked(bool terminal) const;
    struct MemoryReplayTag final {};
    NodeState(MemoryReplayTag, std::string node_id,
        std::uint64_t maximum_journal_bytes);
    [[nodiscard]] static std::unique_ptr<NodeState>
        replay_authenticated_prefix_state(
            datacube::OctetView bytes, std::string node_id,
            std::uint64_t maximum_journal_bytes, StateAuthKeyPtr key);
    enum class EntryKind : std::uint8_t {
        inbound = 1U,
        outbound_queued = 2U,
        outbound_receipt = 3U,
        recovery = 4U,
        outbound_policy = 5U,
        outbound_attempt = 6U,
        outbound_failure = 7U,
        outbound_expired = 8U,
        outbound_rebound = 9U,
        outbound_cancelled = 10U,
        inbound_authorized = 11U,
        authorization_denied = 12U,
        action_started = 13U,
        action_completed = 14U,
        action_cancelled = 15U,
        action_expired = 16U,
        schema_migrated = 17U,
        checkpoint = 18U,
        backup_restored = 19U,
        outbound_rejected = 20U,
        outbound_retried = 21U,
        runtime_configuration = 22U,
        runtime_bound_mutation = 23U,
        outbound_queued_with_policy = 24U,
        local_control_event = 25U,
        lifecycle_event = 26U,
        consumer_update = 27U,
        projection_schedule = 28U,
        consumer_retirement = 29U,
        publication_channel = 30U,
        local_authored = 31U,
        source_subscription = 32U,
        subscribed_source = 33U,
        import_schedule = 34U,
        outbox_administration = 35U,
        action_administration = 36U,
        action_result = 37U,
        result_review = 38U,
        custody_event = 39U,
    };

    [[nodiscard]] std::uint64_t evidence_feed_total_locked(const EvidenceFeed& feed,
        const EvidenceQueryContext& context) const;
    [[nodiscard]] EvidenceFeedSlice evidence_feed_slice_locked(const EvidenceFeed& feed,
        const EvidenceQueryContext& context, std::uint64_t after, std::uint64_t through) const;
    [[nodiscard]] EvidenceFeedSlice consumer_slice_locked(const DurableConsumer& consumer,
        const EvidenceQueryContext& context, std::uint64_t after, std::uint64_t through) const;
    [[nodiscard]] QueueResult queue_outbound_locked(
        const EvidenceRecord& record,
        const std::optional<OutboundPolicy>& initial_policy);
    void validate_new_outbound_locked(
        const EvidenceRecord& record, const OutboundPolicy& policy,
        std::optional<std::size_t> converting_action = std::nullopt) const;
    void validate_consumer_locked(const DurableConsumer& value) const;
    [[nodiscard]] EvidenceProjection initial_projection_locked(const DurableConsumer& value,
        std::uint64_t maximum_admissions,
        const std::optional<NumericDefinition>& numeric = std::nullopt) const;
    [[nodiscard]] EvidenceProjection advance_projection_locked(const DurableConsumer& value,
        const ConsumerBatch& batch) const;
    void validate_projection_locked(const DurableConsumer& value, bool full_replay) const;
    mutable std::uint64_t projection_records_visited_{0U};
    void apply_consumer_update(datacube::OctetView bytes, bool automatic=false, bool validate_only=false);
    std::map<std::string,ProjectionSchedule> projection_schedules_;
    void validate_projection_schedule_locked(const ProjectionSchedule& value) const;
    void apply_projection_schedule_update(datacube::OctetView bytes, bool validate_only=false);
    void commit_projection_schedule_locked(const ProjectionSchedule& value, const std::optional<DurableConsumer>& consumer);
    [[nodiscard]] std::string projection_schedule_command_locked(const ConsumerRequest& request,
        const EvidenceQueryContext& context, std::uint32_t pid, std::uint64_t event);
    void commit_consumer_locked(const DurableConsumer& value);
    void validate_consumer_retirement_locked(const DurableConsumer& value) const;
    void validate_consumer_registry_locked() const;
    void apply_consumer_retirement(datacube::OctetView bytes, bool validate_only=false);
    [[nodiscard]] std::string consumer_retirement_command_locked(const ConsumerRequest& request,
        const EvidenceQueryContext& context, std::uint32_t pid, std::uint64_t configuration_event);
    std::map<std::string, DurableConsumer> consumers_;
    mutable std::uint64_t consumer_validation_records_{0U}; // observational work, never durable authority
    void apply_publication_channel(datacube::OctetView bytes, bool replaying=false,
        bool validate_only=false);
    void validate_publication_channel_locked(const PublicationChannel& value,
        const std::optional<EvidenceRecord>& pending_record = std::nullopt) const;
    [[nodiscard]] std::string automatic_publication_block_error_locked(
        const PublicationChannel& value, const RuntimeConfig& config) const;
    void validate_publication_channel_registry_locked() const;
    std::map<std::string, PublicationChannel> publication_channels_;
    std::map<std::string, SourceSubscription> source_subscriptions_;
    std::map<std::string, SourceSubscriptionCommitment> source_subscription_commitments_;
    std::map<std::string, SourceSubscriptionIndex> source_subscription_indexes_;
    [[nodiscard]] SourceSubscriptionIndex build_source_subscription_index_locked(
        const SourceSubscription& value) const;
    void acknowledge_source_subscription_index_locked(const SourceSubscription& value);
    std::map<std::pair<std::uint32_t, std::string>, std::vector<std::size_t>> authored_source_index_;
    // Private, stack-owned preparation. Never stored in NodeState or decoded from
    // durable/client bytes; only the locked originating command can pass it on.
    struct AutomaticSourceEligibility;
    struct SourceProgressPreparation;
    struct ParsedSourceProgress;
    enum class SourceOutboundPart : std::uint8_t { composite, record };
    void validate_parsed_source_progress_origin_locked(
        const ParsedSourceProgress& parsed, bool before_append) const;
    [[nodiscard]] const EvidenceRecord& source_outbound_record_locked(
        datacube::OctetView bytes, const ParsedSourceProgress& parsed,
        SourceOutboundPart part, bool replaying) const;
    [[nodiscard]] EvidenceRecord take_source_outbound_record_locked(
        datacube::OctetView bytes, const ParsedSourceProgress& parsed,
        bool replaying) const;
    void mark_parsed_source_progress_published_locked(
        const ParsedSourceProgress& parsed) const;
    void validate_parsed_source_progress_applied_locked(
        const ParsedSourceProgress& parsed) const;
    void apply_outbound_admission_locked(datacube::OctetView payload, bool replaying,
        const ParsedSourceProgress* parsed = nullptr);
    void apply_outbound_record_locked(datacube::OctetView payload, bool replaying,
        const ParsedSourceProgress* parsed = nullptr);
    void validate_parsed_source_progress_locked(datacube::OctetView bytes,
        const ParsedSourceProgress& parsed, bool before_append) const;
    void commit_source_progress_locked(datacube::Octets bytes,
        const SourceProgressPreparation* prepared, bool automatic);
    [[nodiscard]] SourceProgressPreparation prepare_source_progress_locked(
        const SourceSubscription& old, std::uint64_t event, std::uint64_t at,
        bool issue, AutomaticSourceEligibility* eligibility = nullptr) const;
    void apply_source_subscription(datacube::OctetView bytes, bool replaying,
        bool validate_only = false, const SourceProgressPreparation* prepared = nullptr,
        const ParsedSourceProgress* parsed = nullptr);
    void apply_source_subscription_progress(datacube::OctetView bytes, bool replaying,
        bool validate_only = false, const SourceProgressPreparation* prepared = nullptr,
        const ParsedSourceProgress* parsed = nullptr);
    void validate_source_subscriptions_locked() const;
    void rebuild_source_subscription_commitments_locked();
    void validate_source_subscription_progress_locked(const SourceSubscription& old,
        const SourceSubscription& next, const std::optional<EvidenceRecord>& candidate,
        const RuntimeConfig& latest) const;
    void validate_source_subscription_locked(const SourceSubscription& value,
        const std::optional<EvidenceRecord>& candidate = std::nullopt) const;
    void validate_source_subscription_registry_locked() const;
    void validate_source_succession_locked(const SourceSubscription& value) const;
    [[nodiscard]] std::string automatic_source_subscription_block_error_locked(
        const SourceSubscription& value, const RuntimeConfig& config,
        std::uint64_t configuration_event = 0U,
        AutomaticSourceEligibility* eligibility = nullptr) const;
    [[nodiscard]] EvidenceRecord source_subscription_record_locked(const SourceSubscription& value,
        std::size_t position, bool indexed = false) const;
    void validate_local_authorship_locked(const EvidenceRecord& record,
        const LocalAuthorship& account, bool active_policy) const;
    void reserve_source_view_domains_locked(const RuntimeConfig& config, bool commit = true);
    [[nodiscard]] std::pair<EvidenceRecord, SubscribedSource> derive_subscribed_source_locked(
        const SubscribedSource& selected, bool current_policy, std::uint64_t input_limit = UINT64_MAX) const;
    void validate_subscribed_source_locked(const EvidenceRecord& record,
        const SubscribedSource& account, bool current_policy) const;
    [[nodiscard]] ImportAttempt prepare_import_locked(const SubscribedSource& selected, std::uint64_t input_limit) const;
    [[nodiscard]] ImportPlan plan_import_event_locked(const ImportAutoState& before,
        ImportAutoEvent event, bool checkpoint) const;
    void apply_import_auto_event(datacube::OctetView bytes, bool checkpoint = false);
    void commit_import_auto_event(const ImportAutoEvent& event);
    [[nodiscard]] datacube::Digest32 import_event_operation_locked(const ImportAutoEvent& event) const;
    [[nodiscard]] std::string import_decision_json_locked(const ImportAutoEvent& event) const;
    [[nodiscard]] std::string review_import_decisions_locked(const ImportAutoRequest& request,
        const ImportAutoState& state, const RuntimeConfig& config, std::uint64_t configuration_event) const;
    [[nodiscard]] SourceViewRule retained_source_view_rule_locked(std::string_view view, std::uint64_t configuration_event) const;
    [[nodiscard]] ViewFinalAccount view_final_account_locked(const ImportAutoState& before,
        const SourceViewRule& rule, std::uint64_t inbound_count) const;
    [[nodiscard]] std::string view_retirement_command_locked(const ImportAutoRequest& request,
        const RuntimeConfig& config, std::uint32_t uid, std::uint32_t gid, std::uint32_t pid,
        std::uint64_t configuration_event, std::uint64_t unix_ms);
    void require_source_view_active_locked(std::string_view view) const;
    void validate_retired_import_prefixes_locked() const;
    bool applying_import_auto_{false};
    std::map<std::string,ImportAutoState> import_schedules_;
    void index_source_view_configuration_locked(const RuntimeConfig& config);
    std::map<std::pair<std::uint32_t,std::string>, RetainedSourceView> retained_source_views_;
    std::set<std::pair<std::string, std::string>> source_view_domains_;
    std::map<std::string, std::pair<std::uint64_t, std::uint64_t>> source_view_usage_;
    std::set<std::tuple<std::string, std::string, std::uint64_t>> source_view_ordinals_;
    // Untrusted format candidates, never authentication. Only an exact query
    // under read authority invokes the strict decoder and historical checks.
    std::map<std::tuple<std::string, std::string, std::string>, ReceivedActionResultCandidates> received_action_result_candidates_;
    std::map<std::string, std::uint64_t> inbound_authorization_configuration_;
    void index_received_action_result_locked(std::size_t index);
    std::vector<ResultReviewRecord> result_reviews_;
    DurableCustodyRegistry custody_registry_;
    std::map<std::string,std::size_t> result_review_index_;
    // Derived only after full source/semantic validation. Each group is one
    // owner's exact request/provider/scope: no hidden global offsets or counts.
    using ReviewHistoryKey = std::tuple<std::uint32_t, std::string, std::string, std::string>;
    std::map<ReviewHistoryKey, std::vector<ResultReviewHistoryEntry>> result_review_history_;
    void index_result_review_locked(datacube::OctetView validated_record);
    std::map<std::string,std::size_t> result_receipt_binding_;
    void apply_result_review(datacube::OctetView payload, bool checkpoint = false);
    [[nodiscard]] StoredOutbound review_original_locked(const ResultReviewRecord& review) const;
    [[nodiscard]] std::vector<ResultReviewCandidate> evaluate_result_review_locked(
        const ResultReviewRecord& review, const StoredOutbound& original,
        std::chrono::steady_clock::time_point deadline) const;
    [[nodiscard]] std::string result_review_json_locked(const ResultReviewRecord& review,
        const RuntimeConfig& config, std::string_view disposition) const;
    void index_inbound(std::size_t index);
    void index_action(std::size_t index);
    void index_outbound(std::size_t index);
    [[nodiscard]] std::uint8_t outbox_restrictions_locked(const datacube::Digest32& operation) const;
    [[nodiscard]] datacube::Digest32 outbox_admin_root_locked(const datacube::Digest32& operation) const;
    [[nodiscard]] std::string outbox_condition_json_locked(const StoredOutbound& entry) const;
    [[nodiscard]] datacube::Octets conditional_inner_locked(const OutboxAdminRecord& record,
        const StoredOutbound& before, const RuntimeConfig& config) const;
    void apply_outbox_administration(datacube::OctetView payload, bool validate_only=false);
    void validate_outbox_administration_checkpoint();
    std::vector<OutboxAdminRecord> outbox_administration_;
    std::map<std::string,std::vector<std::size_t>> outbox_admin_by_operation_;
    std::map<std::string,std::size_t> outbox_admin_by_request_;
    [[nodiscard]] datacube::Octets action_admin_metadata_locked(
        std::size_t action_index) const;
    [[nodiscard]] datacube::Digest32 action_admin_root_locked(
        const datacube::Digest32& action_id) const;
    [[nodiscard]] std::string action_condition_json_locked(
        std::size_t action_index) const;
    void apply_action_administration(datacube::OctetView payload,
        bool validate_only = false);
    void validate_action_administration_checkpoint();
    std::vector<ActionAdminRecord> action_administration_;
    std::map<std::string,std::vector<std::size_t>> action_admin_by_action_;
    std::map<std::string,std::size_t> action_admin_by_request_;
    void apply_action_result(datacube::OctetView payload, bool replaying);
    std::map<std::string, ActionResultState> action_results_;
    PendingCapacityIndex future_result_capacity_;
    // Result-operation identity -> whether its original admission reserved capacity.
    std::map<std::string, bool> action_result_operations_;
    [[nodiscard]] QueueUsage queue_usage_locked() const;
    [[nodiscard]] std::string action_result_status_locked(const datacube::Digest32& action) const;
    void index_action_result_reservation_locked(std::size_t action_index);
    void validate_action_result_binding_locked(const StoredAction& action,
        const ActionResultBinding& binding) const;
    [[nodiscard]] datacube::Octets conditional_action_result_locked(
        const StoredAction& terminal, ActionResultState& result) const;
    void index_outbound_associations(const PublicationChannel& channel);
    void index_outbound_associations(const SourceSubscription& subscription);
    void initialize_directory();
    void open_and_lock_state();
    void initialize_metadata();
    void migrate_storage_schema_if_needed();
    void publish_metadata_v2();
    void cleanup_stale_compaction_candidate();
    void open_and_lock_journal();
    void load_journal();
    void apply_entry(EntryKind kind, datacube::OctetView payload, bool replaying,
        const SourceProgressPreparation* prepared = nullptr,
        const ParsedSourceProgress* parsed = nullptr);
    void append_entry(EntryKind kind, datacube::OctetView payload,
        const SourceProgressPreparation* prepared = nullptr,
        const ParsedSourceProgress* parsed = nullptr);
    void append_recovery(std::uint64_t discarded, std::uint64_t valid_prefix);
    void load_checkpoint(datacube::OctetView payload);
    [[nodiscard]] bool delivery_selection_matches_locked(const DeliverySelection& selection) const;
    [[nodiscard]] bool action_selection_matches_locked(
        const ActionSelection& selection) const;
    void begin_outbound_attempt_locked(const datacube::Digest32& operation,
        std::uint64_t now, std::uint64_t next_attempt);
    [[nodiscard]] StateSnapshot snapshot_locked() const;
    [[nodiscard]] datacube::Octets canonical_logical_state_locked() const;
    [[nodiscard]] CheckpointImage checkpoint_image_locked(
        std::uint64_t created_unix_ms,
        std::uint64_t generation,
        std::uint64_t before_bytes, bool protect = true) const;
    void validate_compaction_candidate(
        const datacube::Digest32& expected_digest) const;

    StateAuthKeyPtr auth_key_;
    std::optional<StateAuthentication> authentication_;
    // Set only after a real disk open has authenticated, replayed and matched.
    // Memory reconstruction never inherits this process-opening observation.
    std::optional<StateHeadExpectation> opening_state_head_expectation_;
    std::uint64_t authenticated_checkpoint_overhead_{0U};
    bool strict_source_{false};
    std::filesystem::path state_directory_;
    std::string node_id_;
    std::uint64_t maximum_journal_bytes_{0U};
    QueueLimits queue_limits_;
    datacube::Fd directory_fd_;
    datacube::Fd state_lock_fd_;
    datacube::Fd journal_fd_;
    std::uint64_t journal_bytes_{0U};
    bool poisoned_{false};
    bool terminal_sealed_{false}; // process-local; never encoded or replayed
    bool applying_runtime_bound_mutation_{false};
    bool applying_conditional_action_{false};
    bool applying_action_administration_{false};
    bool applying_action_result_{false};
    std::uint32_t metadata_schema_version_{0U};
    std::uint32_t storage_schema_version_{0U};
    std::uint64_t maintenance_generation_{0U};
    std::optional<std::uint64_t> last_compaction_unix_ms_;
    std::uint64_t last_compaction_before_bytes_{0U};
    std::uint64_t last_compaction_after_bytes_{0U};
    std::uint64_t last_compaction_retained_records_{0U};
    std::optional<datacube::Digest32> restored_backup_id_;
    std::string restored_backup_generation_;
    std::optional<std::uint64_t> restored_backup_unix_ms_;

    std::vector<StoredInbound> inbound_;
    std::vector<StoredOutbound> outbound_;
    std::vector<AuthorizationDenial> authorization_denials_;
    std::vector<StoredAction> actions_;
    std::uint64_t authorized_inbound_count_{0U};
    std::array<std::uint64_t, 4> action_outcomes_{};
    std::vector<std::size_t> indexed_action_outcomes_;
    std::uint64_t action_counter_value_{0U};
    std::uint64_t action_reserved_amount_{0U};
    std::vector<JournalRecovery> recoveries_;
    std::vector<StorageMigration> migrations_;
    std::vector<RuntimeConfigurationEvent> configuration_events_;
    std::vector<RuntimeMutationBinding> configuration_bindings_;
    // Append-only derived prefix commitments. No canonical copies or application
    // payloads; rebuilt by normal replay. One 32-byte prefix per binding.
    std::vector<ConfigurationHistoryCommitment> configuration_history_index_;
    std::vector<datacube::Digest32> configuration_binding_prefixes_;
    void index_configuration_event_locked(datacube::OctetView serialized_event);
    void index_configuration_binding_locked();
    void index_control_history_locked(bool decisions, datacube::OctetView payload);
    ControlHistoryIndex control_history_index_;
    ControlHistoryIndex lifecycle_history_index_;
    std::vector<LocalControlEvent> local_control_events_;
    std::vector<LifecycleEvent> lifecycle_events_;
    std::map<std::string, std::size_t> inbound_index_;
    // Reconstructed derivative index; no new durable schema or hidden counts.
    std::map<std::pair<std::string, std::string>, EvidenceOrderedIndex> inbound_domain_index_;
    EvidenceOrderedIndex inbound_order_index_;
    mutable EvidenceRootCache evidence_root_cache_;
    std::map<std::string, std::size_t> outbound_index_;
    OutboxInspectionIndex outbox_inspection_index_;
    // Same ordered scalar buckets, keyed by action issuer/outcome, no payloads.
    OutboxInspectionIndex action_inspection_index_;
    // Pending-only readiness/expiry trees, rebuilt by ordinary replay.
    ActionSelectionIndex action_selection_index_;
    std::map<std::string, std::array<std::optional<std::size_t>,4U>> action_binding_index_;
    void index_action_binding_locked(std::size_t index);
    DeliveryIndex delivery_index_;
    PendingCapacityIndex pending_capacity_;
    std::map<std::string,std::string> outbox_associations_; // Immutable issuance metadata, never payloads.
    std::map<std::string, std::size_t> action_index_;
    std::map<std::string, std::size_t> authorization_denial_index_;
    std::map<std::string, std::string> correction_child_;
    mutable std::mutex mutex_;
};

[[nodiscard]] std::string configuration_history_json(
    const std::vector<RuntimeConfigurationEvent>& events,
    const std::vector<RuntimeMutationBinding>& bindings, bool bounded);
[[nodiscard]] std::size_t active_configuration_event(
    const std::vector<RuntimeConfigurationEvent>& events) noexcept;
[[nodiscard]] std::string configuration_history_json(
    const StateSnapshot& snapshot, bool bounded);
[[nodiscard]] std::string_view queue_disposition_name(
    QueueDisposition disposition) noexcept;
[[nodiscard]] std::string_view admission_disposition_name(
    AdmissionDisposition disposition) noexcept;
[[nodiscard]] std::string_view outbound_transition_kind_name(
    OutboundTransitionKind kind) noexcept;
[[nodiscard]] datacube::Digest32 outbound_policy_digest(
    const OutboundPolicy& policy);
[[nodiscard]] std::optional<OutboundRejection> active_outbound_rejection(
    const StoredOutbound& entry);
[[nodiscard]] QueueUsage outbound_queue_usage(
    const std::vector<StoredOutbound>& outbound);
[[nodiscard]] bool outbound_is_pending(const StoredOutbound& entry) noexcept;
[[nodiscard]] std::string_view outbound_status_name(
    const StoredOutbound& entry) noexcept;
[[nodiscard]] std::string_view authorization_decision_kind_name(
    AuthorizationDecisionKind kind) noexcept;
[[nodiscard]] std::string_view local_control_decision_kind_name(
    LocalControlDecisionKind kind) noexcept;
[[nodiscard]] std::string_view lifecycle_transition_kind_name(
    LifecycleTransitionKind kind) noexcept;
[[nodiscard]] bool action_is_pending(const StoredAction& action) noexcept;
[[nodiscard]] std::string_view action_status_name(
    const StoredAction& action) noexcept;

}  // namespace natrav_overlay
