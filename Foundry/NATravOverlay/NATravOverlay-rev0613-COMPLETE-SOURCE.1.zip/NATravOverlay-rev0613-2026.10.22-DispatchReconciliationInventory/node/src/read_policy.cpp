#include "read_policy.hpp"
#include <algorithm>
#include <array>
#include <limits>
#include <tuple>

namespace natrav_overlay {
namespace {
void text(datacube::Octets& out, const std::string_view value) {
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}
void encode_grant(datacube::Octets& out, const EvidenceReadGrant& grant) {
    datacube::append_be32(out, grant.uid);
    text(out, grant.issuer); text(out, grant.scope);
    datacube::append_u8(out, grant.payload ? 1U : 0U);
}
EvidenceReadGrant parse(const std::string& value) {
    std::array<std::string_view, 4> fields{};
    std::size_t begin = 0U;
    for (std::size_t i = 0U; i < fields.size(); ++i) {
        const auto end = value.find(',', begin);
        if ((i < 3U && end == std::string::npos) || (i == 3U && end != std::string::npos)) {
            app_fail("CONFIG_EVIDENCE_READ_INVALID", "evidence_read requires UID,ISSUER,SCOPE,METADATA or PAYLOAD");
        }
        fields[i] = std::string_view(value).substr(begin, end == std::string::npos ? end : end - begin);
        begin = end == std::string::npos ? value.size() : end + 1U;
    }
    if (!valid_node_id(fields[1]) || !valid_scope(fields[2]) ||
        fields[1].find_first_of("*?") != std::string_view::npos ||
        fields[2].find_first_of("*?") != std::string_view::npos ||
        (fields[3] != "METADATA" && fields[3] != "PAYLOAD")) {
        app_fail("CONFIG_EVIDENCE_READ_INVALID", "read domains and access modes must be exact and bounded");
    }
    return EvidenceReadGrant{
        .uid = static_cast<std::uint32_t>(parse_u64(fields[0], "evidence read UID", 0U,
            std::numeric_limits<std::uint32_t>::max())),
        .issuer = std::string(fields[1]), .scope = std::string(fields[2]),
        .payload = fields[3] == "PAYLOAD"};
}
} // namespace

EvidenceReadPolicy make_evidence_read_policy(const std::vector<std::string>& values,
    const LocalControlPolicy& local, const bool scoped) {
    if (!scoped && !values.empty()) {
        app_fail("CONFIG_VERSION_REJECTED", "evidence_read domains require V10");
    }
    if (values.size() > 256U) {
        app_fail("CONFIG_EVIDENCE_READ_LIMIT", "at most 256 exact read domains are supported");
    }
    EvidenceReadPolicy policy{.scoped = scoped, .grants = {}, .digest = {}};
    for (const auto& value : values) {
        auto grant = parse(value);
        if (!local_control_allows(local, grant.uid, LocalControlClass::evidence_read) ||
            (grant.payload && !local_control_allows(local, grant.uid, LocalControlClass::evidence_payload))) {
            app_fail("CONFIG_EVIDENCE_READ_CLASS_REQUIRED", "domain grant requires corresponding local command classes");
        }
        policy.grants.push_back(std::move(grant));
    }
    std::sort(policy.grants.begin(), policy.grants.end(), [](const auto& a, const auto& b) {
        return std::tie(a.uid, a.issuer, a.scope) < std::tie(b.uid, b.issuer, b.scope);
    });
    for (std::size_t i = 1U; i < policy.grants.size(); ++i) {
        const auto& a = policy.grants[i - 1U]; const auto& b = policy.grants[i];
        if (std::tie(a.uid, a.issuer, a.scope) == std::tie(b.uid, b.issuer, b.scope)) {
            app_fail("CONFIG_EVIDENCE_READ_DUPLICATE", "one access mode per exact UID/issuer/scope; PAYLOAD includes METADATA");
        }
    }
    if (scoped) {
        for (const auto& local_grant : local.grants) {
            const bool read = local_control_allows(local, local_grant.uid, LocalControlClass::evidence_read);
            const bool payload = local_control_allows(local, local_grant.uid, LocalControlClass::evidence_payload);
            bool has_read = false; bool has_payload = false;
            for (const auto& grant : policy.grants) {
                if (grant.uid == local_grant.uid) { has_read = true; has_payload = has_payload || grant.payload; }
            }
            if ((read && !has_read) || (payload && !has_payload)) {
                app_fail("CONFIG_EVIDENCE_READ_DOMAIN_REQUIRED", "V10 read classes require explicit domains of the corresponding access mode");
            }
        }
    }
    datacube::Octets bytes;
    datacube::append_text(bytes, "NATRAV_OVERLAY_EVIDENCE_READ_POLICY_V1");
    datacube::append_u8(bytes, scoped ? 1U : 0U);
    datacube::append_be32(bytes, static_cast<std::uint32_t>(policy.grants.size()));
    for (const auto& grant : policy.grants) { encode_grant(bytes, grant); }
    policy.digest = datacube::sha256(bytes);
    return policy;
}

EvidenceReadAccess evidence_read_access(const EvidenceReadPolicy& policy,
    const LocalControlPolicy& local, const std::uint32_t uid) {
    EvidenceReadAccess access{.scoped = policy.scoped,
        .metadata_allowed = local_control_allows(local, uid, LocalControlClass::evidence_read),
        .payload_allowed = local_control_allows(local, uid, LocalControlClass::evidence_payload),
        .grants = {}, .digest = {}};
    for (const auto& grant : policy.grants) { if (grant.uid == uid) { access.grants.push_back(grant); } }
    datacube::Octets bytes;
    datacube::append_text(bytes, "NATRAV_OVERLAY_EVIDENCE_READ_ACCESS_V1");
    datacube::append_be32(bytes, uid);
    datacube::append_u8(bytes, access.scoped ? 1U : 0U);
    datacube::append_u8(bytes, access.metadata_allowed ? 1U : 0U);
    datacube::append_u8(bytes, access.payload_allowed ? 1U : 0U);
    datacube::append_be32(bytes, static_cast<std::uint32_t>(access.grants.size()));
    for (const auto& grant : access.grants) { encode_grant(bytes, grant); }
    access.digest = datacube::sha256(bytes);
    return access;
}

bool evidence_read_allows(const EvidenceReadAccess& access, const std::string_view issuer,
    const std::string_view scope, const bool payload) noexcept {
    if (!access.metadata_allowed || (payload && !access.payload_allowed)) { return false; }
    if (!access.scoped) { return true; }
    return std::any_of(access.grants.begin(), access.grants.end(), [&](const auto& grant) {
        return grant.issuer == issuer && grant.scope == scope && (!payload || grant.payload);
    });
}
std::string evidence_read_grant_text(const EvidenceReadGrant& grant) {
    return std::to_string(grant.uid) + "," + grant.issuer + "," + grant.scope +
        (grant.payload ? ",PAYLOAD" : ",METADATA");
}
std::string evidence_read_policy_json(const EvidenceReadPolicy& policy) {
    std::string out = "{\"format\":\"NATRAV_OVERLAY_EVIDENCE_READ_POLICY_V1\",\"mode\":" +
        json_string(policy.scoped ? "EXACT_DOMAINS" : "LEGACY_NODE_WIDE") +
        ",\"digest\":" + json_string(datacube::hex_lower(policy.digest)) + ",\"grants\":[";
    bool first = true;
    for (const auto& grant : policy.grants) {
        if (!first) { out += ','; } first = false;
        out += "{\"uid\":" + std::to_string(grant.uid) + ",\"issuer\":" + json_string(grant.issuer) +
            ",\"scope\":" + json_string(grant.scope) + ",\"access\":" + json_string(grant.payload ? "PAYLOAD" : "METADATA") + "}";
    }
    return out + "]}";
}
} // namespace natrav_overlay
