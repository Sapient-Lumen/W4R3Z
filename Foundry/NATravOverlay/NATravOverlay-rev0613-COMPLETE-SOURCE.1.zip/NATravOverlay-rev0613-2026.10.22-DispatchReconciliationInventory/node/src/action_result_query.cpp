#include "action_result_query.hpp"
#include "config.hpp"
#include "journal.hpp"
#include "submission_work.hpp"

#include <algorithm>
#include <iostream>
#include <thread>
#include <cstdlib>
#include <limits>
#include <map>
#include <array>
#include <memory>
#include <openssl/core_names.h>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/params.h>
#include <openssl/rand.h>

namespace natrav_overlay {
namespace {
using Digest = datacube::Digest32;
using Bytes = datacube::Octets;
using View = datacube::OctetView;
constexpr std::size_t kMaximumReportBytes = 571U;
constexpr std::size_t kMaximumCandidates = 32U;
void require(bool value, std::string_view code, std::string_view detail) {
    if (!value) app_fail(code, detail);
}
void text(Bytes& out, std::string_view value) {
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}
std::string text(datacube::Reader& reader, std::size_t maximum) {
    const auto size = reader.read_be16("text size");
    require(size > 0U && size <= maximum, "ACTION_RESULT_FORMAT_INVALID", "text bound violated");
    return datacube::octets_text(reader.read_exact(size,"text"),"text",true);
}
Digest digest(datacube::Reader& reader) {
    Digest value{};
    const auto bytes = reader.read_exact(32U,"digest");
    std::copy(bytes.begin(), bytes.end(), value.octets.begin());
    return value;
}
std::optional<std::uint64_t> optional_u64(datacube::Reader& reader) {
    const auto marker=reader.read_u8("optional number");
    require(marker<=1U,"ACTION_RESULT_FORMAT_INVALID","invalid optional marker");
    if (marker==0U) return std::nullopt;
    return reader.read_be64("optional number");
}
std::optional<Digest> optional_digest(datacube::Reader& reader) {
    const auto marker=reader.read_u8("optional digest");
    require(marker<=1U,"ACTION_RESULT_FORMAT_INVALID","invalid optional marker");
    if (marker==0U) return std::nullopt;
    return digest(reader);
}
Digest domain_hash(std::string_view domain, View bytes) {
    Bytes material;
    datacube::append_text(material,domain); datacube::append_u8(material,0U);
    datacube::append_octets(material,bytes); return datacube::sha256(material);
}
std::string hex(const Digest& value) { return json_string(datacube::hex_lower(value)); }
std::string nullable_hex(const std::optional<Digest>& value) { return value?hex(*value):"null"; }
std::string number(const std::optional<std::uint64_t>& value) { return value?std::to_string(*value):"null"; }
// Counters are decimal strings: downstream JSON clients need not round uint64.
std::string exact_number(const std::optional<std::uint64_t>& value) { return value?json_string(std::to_string(*value)):"null"; }

struct Report final {
    std::uint8_t outcome{0U};
    Digest action{}, record{};
    std::uint64_t source_sequence{0U};
    Digest source_policy{}, source_rule{};
    std::uint64_t source_decided{0U};
    Digest result_policy{}, result_rule{};
    std::uint64_t provider_configuration_event{0U};
    std::string scope, recipient_generation;
    Digest recipient_pin{};
    std::uint64_t amount{0U}, admitted{0U}, terminal{0U};
    std::uint32_t attempts{0U};
    std::optional<std::uint64_t> started;
    std::optional<Digest> effect_receipt;
    std::optional<std::uint64_t> before, after;
    std::uint16_t reason_bytes{0U};
    Digest reason{};
};
std::string_view outcome_name(std::uint8_t value) {
    if(value==1U)return "EXECUTED";
    if(value==2U)return "CANCELLED";
    return "EXPIRED";
}
Report decode_report(View bytes) {
    require(bytes.size()<=kMaximumReportBytes,"ACTION_RESULT_FORMAT_INVALID","NAC1 exceeds maximum format size");
    try {
        datacube::Reader reader(bytes,"action-result report");
        require(datacube::octets_text(reader.read_exact(4U,"magic"),"magic",true)=="NAC1",
            "ACTION_RESULT_FORMAT_INVALID","unknown result format");
        Report r;
        r.outcome=reader.read_u8("outcome"); r.action=digest(reader); r.record=digest(reader);
        r.source_sequence=reader.read_be64("source sequence"); r.source_policy=digest(reader); r.source_rule=digest(reader);
        r.source_decided=reader.read_be64("source decision time");r.result_policy=digest(reader);r.result_rule=digest(reader);
        r.provider_configuration_event=reader.read_be64("provider configuration event");
        r.scope=text(reader,128U);r.recipient_generation=text(reader,64U);r.recipient_pin=digest(reader);
        r.amount=reader.read_be64("amount");r.admitted=reader.read_be64("admission time");r.terminal=reader.read_be64("terminal time");
        r.attempts=reader.read_be32("attempts");r.started=optional_u64(reader);r.effect_receipt=optional_digest(reader);
        r.before=optional_u64(reader);r.after=optional_u64(reader);r.reason_bytes=reader.read_be16("reason bytes");r.reason=digest(reader);
        reader.require_eof("NAC1 report");
        require(r.outcome>=1U&&r.outcome<=3U && !digest_is_zero(r.action)&&!digest_is_zero(r.record)&&
            r.source_sequence>0U&&!digest_is_zero(r.source_policy)&&!digest_is_zero(r.source_rule)&&
            !digest_is_zero(r.result_policy)&&!digest_is_zero(r.result_rule)&&r.provider_configuration_event>0U&&
            valid_scope(r.scope)&&r.scope!=kCounterAddActionScope&&valid_generation_id(r.recipient_generation)&&
            !digest_is_zero(r.recipient_pin)&&r.amount>0U&&r.admitted>0U&&r.source_decided==r.admitted&&r.terminal>=r.admitted&&
            (r.attempts==0U)==!r.started.has_value()&&(!r.started||(*r.started>=r.admitted&&*r.started<=r.terminal)),
            "ACTION_RESULT_REPORT_INVALID","inconsistent result identity, outcome or temporal account");
        if(r.outcome==1U) {
            require(r.attempts>0U&&r.started&&*r.started<=r.terminal&&r.effect_receipt&&r.before&&r.after&&
                r.amount<=std::numeric_limits<std::uint64_t>::max()-*r.before&&*r.after==*r.before+r.amount&&
                r.reason_bytes==0U&&digest_is_zero(r.reason),
                "ACTION_RESULT_REPORT_INVALID","inconsistent executed counter account");
            Bytes material;datacube::append_octets(material,r.action.octets);datacube::append_be32(material,r.attempts);
            datacube::append_be64(material,r.terminal);datacube::append_be64(material,*r.before);datacube::append_be64(material,*r.after);
            require(*r.effect_receipt==domain_hash("NATRAV_OVERLAY_COUNTER_ACTION_RECEIPT_V1",material),
                "ACTION_RESULT_EFFECT_RECEIPT_MISMATCH","reported local-effect commitment is inconsistent");
        } else {
            require(!r.effect_receipt&&!r.before&&!r.after&&r.reason_bytes>0U&&r.reason_bytes<=256U&&!digest_is_zero(r.reason),
                "ACTION_RESULT_REPORT_INVALID","nonexecuted report cannot carry an effect; bounded reason commitment required");
        }
        return r;
    } catch (const datacube::Failure&) {
        app_fail("ACTION_RESULT_FORMAT_INVALID","truncated or malformed NAC1 report");
    }
}
struct Work final {
    std::uint64_t candidates{0U}, bytes{0U}, configurations{0U}, configuration_bytes{0U}, bindings{0U};
};

struct Match final {Report report;std::uint64_t event;Digest provider_pin;};
// Shared by exact correlation and paginated discovery. All references remain
// protected by the caller's state lock; no mutable state reference escapes.
class ReportValidator final {
public:
    const ActionResultQuery& q;
    const StoredOutbound& request;
    const std::string& node_id_;
    const std::vector<StoredInbound>& inbound_;
    const std::vector<RuntimeConfigurationEvent>& configuration_events_;
    const std::map<std::string,std::uint64_t>& inbound_authorization_configuration_;
    std::chrono::steady_clock::time_point deadline;
    Work& work;
    std::map<std::uint64_t,RuntimeConfig> historical;
    std::size_t history_limit{32U};
    ReportValidator(const ActionResultQuery& query, const StoredOutbound& original,
        const std::string& node, const std::vector<StoredInbound>& inbound,
        const std::vector<RuntimeConfigurationEvent>& events,
        const std::map<std::string,std::uint64_t>& bindings,
        std::chrono::steady_clock::time_point until, Work& counts)
        : q(query),request(original),node_id_(node),inbound_(inbound),
          configuration_events_(events),inbound_authorization_configuration_(bindings),
          deadline(until),work(counts) {}
    void check_time() const {
        require(std::chrono::steady_clock::now()<deadline,
            "ACTION_RESULT_QUERY_DEADLINE","bounded correlation deadline reached");
    }
    const RuntimeConfig& admission_config(std::uint64_t ordinal) {
        check_time();require(ordinal>0U&&ordinal<=configuration_events_.size(),"ACTION_RESULT_ADMISSION_INVALID","missing historical configuration");
        if(auto it=historical.find(ordinal);it!=historical.end())return it->second;
        const auto& event=configuration_events_[static_cast<std::size_t>(ordinal-1U)];
        require(event.kind!="REJECTED","ACTION_RESULT_ADMISSION_INVALID","rejected admission configuration");
        require(historical.size()<history_limit,"RESULT_REVIEW_VALIDATION_LIMIT","at most 32 historical configurations per validation");
        ++work.configurations;work.configuration_bytes+=event.canonical.size();
        auto parsed=parse_runtime_config(event.canonical,"/action-result-historical-admission",IdentityFileValidation::deferred);
        return historical.emplace(ordinal,std::move(parsed)).first->second;
    }
    Match match(std::size_t index) {
        const auto& policy=request.delivery->policy;
        const auto source=decode_counter_add_request(request.record.payload);
        check_time();++work.candidates;const auto& outer=inbound_.at(index);const auto& r=outer.record;
        require(outer.authorization&&!outer.local_authorship&&!outer.subscribed_source&&!r.corrects&&
            r.issuer==q.provider&&r.recipient==node_id_&&r.scope==q.scope,
            "ACTION_RESULT_ADMISSION_INVALID","independent authenticated provider evidence original required");
        const auto& account=*outer.authorization;
        require(account.decision==AuthorizationDecisionKind::admitted&&account.operation_class==AuthorizedOperationClass::evidence&&
            account.peer_node==q.provider&&account.operation_id==r.operation_id&&account.record_digest==outer.record_digest&&
            account.resource==q.scope&&account.rule_digest,
            "ACTION_RESULT_ADMISSION_INVALID","outer authorization account does not bind the selected provider and scope");
        ++work.bindings;const auto binding=inbound_authorization_configuration_.find(datacube::hex_lower(r.operation_id));
        require(binding!=inbound_authorization_configuration_.end(),"ACTION_RESULT_ADMISSION_INVALID","retained authenticated admission configuration required");
        const auto& admitted=admission_config(binding->second);
        const auto decision=evaluate_authorization(admitted.authorization,q.provider,account.peer_generation,r);
        const auto* key=find_peer_generation(admitted,q.provider,account.peer_generation);
        require(decision.allowed&&decision.policy_digest==account.policy_digest&&decision.rule_digest==account.rule_digest&&
            key&&key->state!=KeyGenerationState::revoked,"ACTION_RESULT_ADMISSION_INVALID","historical peer policy and key do not validate the admission");
        require(account.peer_generation==*policy.peer_generation&&key->spki_sha256==*policy.peer_spki_sha256,
            "ACTION_RESULT_PROVIDER_BINDING_MISMATCH","reporting provider key differs from original request delivery binding");
        require(r.payload.size()<=kMaximumReportBytes,"ACTION_RESULT_FORMAT_INVALID","NAC1 exceeds maximum format size");
        work.bytes+=r.payload.size();auto report=decode_report(r.payload);
        require(domain_hash("NATRAV_OVERLAY_ACTION_RESULT_OPERATION_V1",r.payload)==r.operation_id,
            "ACTION_RESULT_OPERATION_MISMATCH","outer operation does not commit the complete NAC1 payload");
        require(report.scope==q.scope&&report.recipient_generation==admitted.local_identity_generation&&
            report.recipient_pin==admitted.identity.expected_spki_sha256,
            "ACTION_RESULT_RECIPIENT_BINDING_MISMATCH","embedded recipient generation, key or result scope differs");
        require(report.action==q.request_operation_id&&report.record==request.record_digest&&report.amount==source.amount,
            "ACTION_RESULT_REQUEST_MISMATCH","report does not bind the exact original request and amount");
        // No foreign wall clock is compared to local receipt time. Only ordering
        // within the provider's own claimed timeline is checked.
        if(report.started) {
            require(source.defer_ms<=std::numeric_limits<std::uint64_t>::max()-report.admitted&&
                *report.started>=report.admitted+source.defer_ms,
                "ACTION_RESULT_REPORT_INVALID","reported start precedes requested defer interval");
        }
        if(request.receipt) {
            const auto& receipt=*request.receipt;
            require(receipt.operation_id==report.action&&receipt.recipient==q.provider&&receipt.recorder==q.provider&&
                receipt.record_digest==report.record&&receipt.sequence==report.source_sequence,
                "ACTION_RESULT_SOURCE_RECEIPT_MISMATCH","reported admission differs from retained source-delivery receipt");
        }
        return Match{std::move(report),binding->second,key->spki_sha256};
    }
};
} // namespace

void validate_action_result_query(const ActionResultQuery& q) {
    require(!digest_is_zero(q.operation_id)&&!digest_is_zero(q.request_operation_id)&&valid_node_id(q.provider)&&
        valid_scope(q.scope)&&q.scope!=kCounterAddActionScope&&q.maximum_response_bytes>=2048U&&q.maximum_response_bytes<=16384U,
        "ACTION_RESULT_QUERY_INVALID","exact result, request, provider, non-action scope and bounded response required");
}
Bytes encode_action_result_query(const ActionResultQuery& q) {
    validate_action_result_query(q);Bytes out;datacube::append_text(out,"ARQ1");
    datacube::append_octets(out,q.operation_id.octets);datacube::append_octets(out,q.request_operation_id.octets);
    text(out,q.provider);text(out,q.scope);datacube::append_be32(out,q.maximum_response_bytes);return out;
}
ActionResultQuery decode_action_result_query(View bytes) {
    try {
        datacube::Reader reader(bytes,"action result query");
        require(datacube::octets_text(reader.read_exact(4U,"magic"),"magic",true)=="ARQ1",
            "ACTION_RESULT_QUERY_INVALID","unknown request version");
        ActionResultQuery q{.operation_id=digest(reader),.request_operation_id=digest(reader),
            .provider=text(reader,64U),.scope=text(reader,128U),.maximum_response_bytes=reader.read_be32("response size")};
        reader.require_eof("action result query");validate_action_result_query(q);return q;
    } catch(const datacube::Failure&) {app_fail("ACTION_RESULT_QUERY_INVALID","malformed exact result query");}
}

void NodeState::index_received_action_result_locked(const std::size_t index) {
    const auto& value=inbound_.at(index);const auto& r=value.record;
    if(!value.authorization||value.local_authorship||value.subscribed_source||r.payload.size()<37U||
        !std::equal(r.payload.begin(),r.payload.begin()+4,"NAC1"))return;
    Digest claimed_action{};std::copy_n(r.payload.begin()+5,32U,claimed_action.octets.begin());
    auto& candidates=received_action_result_candidates_[{r.issuer,r.scope,datacube::hex_lower(claimed_action)}];
    Bytes material;datacube::append_octets(material,candidates.root.octets);
    datacube::append_be64(material,static_cast<std::uint64_t>(candidates.records.size()+1U));
    datacube::append_octets(material,r.operation_id.octets);datacube::append_octets(material,value.record_digest.octets);
    const auto next=domain_hash("NATRAV_OVERLAY_RESULT_CANDIDATE_CHAIN_V1",material);
    candidates.records.push_back(index);candidates.root=next;
}

std::string NodeState::correlate_action_result(const ActionResultQuery& q,const RuntimeConfig& config,
    const std::uint32_t uid,const std::chrono::steady_clock::time_point deadline) const {
    validate_action_result_query(q);
    const auto access=evidence_read_access(config.evidence_read,config.local_control,uid);
    require(local_control_allows(config.local_control,uid,LocalControlClass::inspect)&&
        evidence_read_allows(access,q.provider,q.scope,true),"ACTION_RESULT_READ_DENIED",
        "current INSPECT and exact-domain payload-read authority required");
    const auto check_time=[&]{require(std::chrono::steady_clock::now()<deadline,
        "ACTION_RESULT_QUERY_DEADLINE","bounded correlation deadline reached");};
    check_time();std::lock_guard<std::mutex> lock(mutex_);check_time();
    if(poisoned_)app_fail("STATE_RESTART_REQUIRED","restart to reconstruct failed writer");
    SubmissionWork observed;SubmissionWorkScope instrumentation(observed);Work work;
    const auto config_digest=runtime_configuration_digest(canonical_runtime_config(config));
    std::string base="{\"format\":\"NATRAV_OVERLAY_ACTION_RESULT_QUERY_V1\",\"ok\":true,\"configuration_digest\":"+hex(config_digest)+
        ",\"operation_id\":"+hex(q.operation_id)+",\"request_operation_id\":"+hex(q.request_operation_id)+
        ",\"provider\":"+json_string(q.provider)+",\"scope\":"+json_string(q.scope);
    const auto finish=[&](std::string out) {
        check_time();out+=",\"work\":{\"scope\":\"EXACT_LOCKED_CORRELATION\",\"candidate_records_visited\":"+std::to_string(work.candidates)+
            ",\"report_payload_bytes_parsed\":"+std::to_string(work.bytes)+",\"historical_configurations_parsed\":"+std::to_string(work.configurations)+
            ",\"historical_configuration_bytes\":"+std::to_string(work.configuration_bytes)+",\"admission_binding_lookups\":"+std::to_string(work.bindings)+
            ",\"snapshot_calls\":"+std::to_string(observed.snapshot_calls)+",\"logical_bytes_serialized\":"+std::to_string(observed.snapshot_logical_bytes)+"}}";
        // The control dispatcher enforces the limit again after actual principal
        // annotation. This conservative allowance prevents creating oversize rows.
        require(out.size()+384U<=q.maximum_response_bytes,"ACTION_RESULT_RESPONSE_LIMIT","complete correlation does not fit response limit");
        return out;
    };
    const auto selected=inbound_index_.find(datacube::hex_lower(q.operation_id));
    if(selected==inbound_index_.end()||inbound_[selected->second].record.issuer!=q.provider||
        inbound_[selected->second].record.scope!=q.scope||inbound_[selected->second].record.recipient!=node_id_)
        return finish(base+",\"status\":\"NOT_FOUND\",\"correlated\":false,\"report\":null");
    const auto original=outbound_index_.find(datacube::hex_lower(q.request_operation_id));
    require(original!=outbound_index_.end(),"ACTION_RESULT_REQUEST_NOT_FOUND","exact original request is not retained");
    const auto& request=outbound_[original->second];
    require(request.record.issuer==node_id_&&request.record.recipient==q.provider&&is_counter_add_record(request.record)&&
        !request.record.corrects&&request.delivery&&request.delivery->policy.peer_generation&&request.delivery->policy.peer_spki_sha256,
        "ACTION_RESULT_REQUEST_MISMATCH","original must be a generation-bound local counter request to the selected provider");
    const auto& policy=request.delivery->policy;
    ReportValidator validator(q,request,node_id_,inbound_,configuration_events_,
        inbound_authorization_configuration_,deadline,work);
    const auto match=[&](std::size_t index){return validator.match(index);};
    const auto found=match(selected->second);
    const auto candidates=received_action_result_candidates_.find({q.provider,q.scope,datacube::hex_lower(q.request_operation_id)});
    require(candidates!=received_action_result_candidates_.end(),"STATE_INDEX_CORRUPT","result candidate index missing");
    require(candidates->second.records.size()<=kMaximumCandidates,"ACTION_RESULT_SCAN_LIMIT","too many retained candidates in this exact provider/scope/request domain");
    std::vector<Digest> matches{q.operation_id};std::uint64_t invalid=0U;
    for(const auto index:candidates->second.records) {
        if(index==selected->second)continue;
        try {static_cast<void>(match(index));matches.push_back(inbound_[index].record.operation_id);}
        catch(const AppError& e) {
            if(e.code()=="ACTION_RESULT_QUERY_DEADLINE"||!e.code().starts_with("ACTION_RESULT_"))throw;
            ++invalid;
        }
    }
    if(matches.size()>1U) {
        std::string ids="[";
        for(std::size_t i=0U;i<matches.size();++i){if(i)ids+=',';ids+=hex(matches[i]);}
        ids+=']';return finish(base+",\"status\":\"CONFLICTING_REPORTS\",\"correlated\":false,\"report\":null,\"conflicting_operations\":"+ids);
    }
    const auto& r=found.report;const auto& outer=inbound_[selected->second];const auto& authorization=*outer.authorization;
    const auto* current=find_peer_generation(config,q.provider,*policy.peer_generation);
    const std::string trust=!current?"NOT_CONFIGURED":current->state==KeyGenerationState::revoked?"REVOKED":
        current->state==KeyGenerationState::retired?"RETIRED":"ACTIVE";
    std::string receipt="null";
    if(request.receipt) {
        const auto& delivered=*request.receipt;
        receipt="{\"operation_id\":"+hex(delivered.operation_id)+",\"recipient\":"+json_string(delivered.recipient)+
            ",\"recorder\":"+json_string(delivered.recorder)+",\"sequence\":"+std::to_string(delivered.sequence)+
            ",\"record_digest\":"+hex(delivered.record_digest)+",\"disposition\":"+json_string(receipt_disposition_name(delivered.disposition))+"}";
    }
    return finish(base+",\"status\":\"CORRELATED\",\"correlated\":true,\"verification\":\"AUTHENTICATED_PROVIDER_REPORT\""
        ",\"execution_verified_locally\":false,\"freshness\":\"NOT_ESTABLISHED\",\"uniqueness\":\"EXACT_RETAINED_PROVIDER_SCOPE_REQUEST\""
        ",\"invalid_other_candidates\":"+std::to_string(invalid)+
        ",\"original_request\":{\"operation_id\":"+hex(request.record.operation_id)+",\"record_digest\":"+hex(request.record_digest)+
        ",\"queue_sequence\":"+std::to_string(request.queue_sequence)+",\"delivery_state\":"+json_string(outbound_status_name(request))+
        ",\"provider_generation\":"+json_string(*policy.peer_generation)+",\"provider_spki_sha256\":"+hex(*policy.peer_spki_sha256)+
        ",\"current_provider_key_state\":"+json_string(trust)+",\"source_admission_receipt\":"+receipt+"}"+
        ",\"result_admission\":{\"operation_id\":"+hex(q.operation_id)+",\"record_digest\":"+hex(outer.record_digest)+
        ",\"sequence\":"+std::to_string(outer.sequence)+",\"configuration_event\":"+std::to_string(found.event)+
        ",\"configuration_digest\":"+hex(configuration_events_[static_cast<std::size_t>(found.event-1U)].digest)+
        ",\"provider_generation\":"+json_string(authorization.peer_generation)+",\"provider_spki_sha256\":"+hex(found.provider_pin)+
        ",\"authorization_policy_digest\":"+hex(authorization.policy_digest)+",\"authorization_rule_digest\":"+nullable_hex(authorization.rule_digest)+
        ",\"decided_unix_ms\":"+std::to_string(authorization.decided_unix_ms)+",\"meaning\":\"LOCAL_AUTHENTICATED_EVIDENCE_ADMISSION\"}"+
        ",\"report\":{\"outcome\":"+json_string(outcome_name(r.outcome))+",\"amount_ticks\":"+json_string(std::to_string(r.amount))+
        ",\"source_admission_sequence\":"+std::to_string(r.source_sequence)+",\"source_authorization_policy_digest\":"+hex(r.source_policy)+
        ",\"source_authorization_rule_digest\":"+hex(r.source_rule)+",\"source_decided_unix_ms\":"+std::to_string(r.source_decided)+
        ",\"result_policy_digest\":"+hex(r.result_policy)+",\"result_rule_digest\":"+hex(r.result_rule)+
        ",\"provider_configuration_event\":"+std::to_string(r.provider_configuration_event)+
        ",\"policy_verification\":\"PROVIDER_CLAIMS_NOT_INDEPENDENTLY_AVAILABLE\",\"recipient_generation\":"+json_string(r.recipient_generation)+
        ",\"recipient_spki_sha256\":"+hex(r.recipient_pin)+",\"admitted_unix_ms\":"+std::to_string(r.admitted)+
        ",\"terminal_unix_ms\":"+std::to_string(r.terminal)+",\"attempts\":"+std::to_string(r.attempts)+
        ",\"last_started_unix_ms\":"+number(r.started)+",\"local_effect_receipt_digest\":"+nullable_hex(r.effect_receipt)+
        ",\"effect_commitment_check\":"+json_string(r.effect_receipt?"SELF_CONSISTENT_NOT_INDEPENDENT_PROOF":"NOT_PRESENT")+
        ",\"counter_before\":"+exact_number(r.before)+",\"counter_after\":"+exact_number(r.after)+
        ",\"reason_bytes\":"+std::to_string(r.reason_bytes)+",\"reason_digest\":"+hex(r.reason)+
        ",\"provider_administrative_receipt\":null,\"administrative_receipt_status\":\"NOT_CARRIED_BY_NAC1\"}");
}

namespace {
constexpr std::size_t kDiscoveryCursorBytes=240U;
constexpr std::uint64_t kDiscoveryLifetimeMs=300'000U;
std::uint64_t discovery_time() {
    const auto now=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
    require(now>=0,"ACTION_RESULT_DISCOVERY_CLOCK_FAILED","negative monotonic clock");
    return static_cast<std::uint64_t>(now);
}
void crypto_checked(int ok) {require(ok==1,"ACTION_RESULT_DISCOVERY_CRYPTO_FAILED","cursor cryptography failed");}
struct DiscoverySecret final {
    std::array<unsigned char,32U> bytes{};
    DiscoverySecret(){crypto_checked(RAND_priv_bytes(bytes.data(),static_cast<int>(bytes.size())));}
    ~DiscoverySecret(){OPENSSL_cleanse(bytes.data(),bytes.size());}
    DiscoverySecret(const DiscoverySecret&)=delete;
    DiscoverySecret& operator=(const DiscoverySecret&)=delete;
};
Digest discovery_mac(View bytes) {
    static const DiscoverySecret key;
    std::unique_ptr<EVP_MAC,decltype(&EVP_MAC_free)> algorithm(EVP_MAC_fetch(nullptr,"HMAC",nullptr),EVP_MAC_free);
    require(static_cast<bool>(algorithm),"ACTION_RESULT_DISCOVERY_CRYPTO_FAILED","HMAC unavailable");
    std::unique_ptr<EVP_MAC_CTX,decltype(&EVP_MAC_CTX_free)> context(EVP_MAC_CTX_new(algorithm.get()),EVP_MAC_CTX_free);
    require(static_cast<bool>(context),"ACTION_RESULT_DISCOVERY_CRYPTO_FAILED","HMAC context unavailable");
    char sha[]="SHA256";
    OSSL_PARAM parameters[]={OSSL_PARAM_construct_utf8_string(OSSL_MAC_PARAM_DIGEST,sha,0U),OSSL_PARAM_construct_end()};
    crypto_checked(EVP_MAC_init(context.get(),key.bytes.data(),key.bytes.size(),parameters));
    constexpr std::string_view domain="NATRAV_OVERLAY_RESULT_DISCOVERY_CURSOR_V1";
    crypto_checked(EVP_MAC_update(context.get(),reinterpret_cast<const unsigned char*>(domain.data()),domain.size()));
    crypto_checked(EVP_MAC_update(context.get(),bytes.data(),bytes.size()));
    Digest result{};std::size_t size=0U;
    crypto_checked(EVP_MAC_final(context.get(),result.octets.data(),&size,32U));
    require(size==32U,"ACTION_RESULT_DISCOVERY_CRYPTO_FAILED","HMAC length mismatch");return result;
}
struct DiscoveryPosition final {
    std::uint64_t count{0U},next{0U},consistent{0U},invalid{0U};
    Digest first{};
    std::uint64_t expires{0U};
};
std::string seal_discovery(std::uint32_t uid,const Digest& config,const Digest& specification,
    const Digest& original,const Digest& candidates,const DiscoveryPosition& p) {
    Bytes body;datacube::append_text(body,"ADC1");datacube::append_be32(body,uid);
    for(const auto* d:{&config,&specification,&original,&candidates})datacube::append_octets(body,d->octets);
    for(const auto value:{p.count,p.next,p.consistent,p.invalid})datacube::append_be64(body,value);
    datacube::append_octets(body,p.first.octets);datacube::append_be64(body,p.expires);
    const auto tag=discovery_mac(body);datacube::append_octets(body,tag.octets);
    require(body.size()==kDiscoveryCursorBytes,"STATE_INDEX_CORRUPT","discovery cursor encoding length");
    return hex_bytes(body);
}
DiscoveryPosition open_discovery(const std::string& token,std::uint32_t uid,const Digest& config,
    const Digest& specification,const Digest& original,const Digest& candidates,std::uint64_t count) {
    require(token.size()==2U*kDiscoveryCursorBytes,"ACTION_RESULT_DISCOVERY_CURSOR_INVALID","invalid cursor size");
    const auto nibble=[](char c)->std::uint8_t {
        if(c>='0'&&c<='9')return static_cast<std::uint8_t>(c-'0');
        if(c>='a'&&c<='f')return static_cast<std::uint8_t>(c-'a'+10);
        app_fail("ACTION_RESULT_DISCOVERY_CURSOR_INVALID","cursor must be lowercase hexadecimal");
    };
    Bytes bytes;bytes.reserve(kDiscoveryCursorBytes);
    for(std::size_t i=0U;i<token.size();i+=2U)bytes.push_back(static_cast<std::uint8_t>(nibble(token[i])*16U+nibble(token[i+1U])));
    const auto body=View(bytes).first(kDiscoveryCursorBytes-32U);const auto tag=discovery_mac(body);
    require(CRYPTO_memcmp(tag.octets.data(),bytes.data()+body.size(),32U)==0,
        "ACTION_RESULT_DISCOVERY_CURSOR_INVALID","authentication failed or issuing process restarted");
    datacube::Reader reader(body,"discovery cursor");
    require(datacube::octets_text(reader.read_exact(4U,"magic"),"magic",true)=="ADC1",
        "ACTION_RESULT_DISCOVERY_CURSOR_INVALID","unknown cursor version");
    const auto stored_uid=reader.read_be32("uid");const auto cfg=digest(reader);const auto spec=digest(reader);
    const auto req=digest(reader);const auto root=digest(reader);
    DiscoveryPosition p; p.count=reader.read_be64("count");p.next=reader.read_be64("next");
    p.consistent=reader.read_be64("consistent");p.invalid=reader.read_be64("invalid");
    p.first=digest(reader);p.expires=reader.read_be64("expiry");reader.require_eof("discovery cursor");
    require(stored_uid==uid&&cfg==config&&spec==specification,
        "ACTION_RESULT_DISCOVERY_CONTEXT_MISMATCH","principal, configuration, node or query options changed");
    require(discovery_time()<p.expires,"ACTION_RESULT_DISCOVERY_CURSOR_EXPIRED","cursor expired; restart discovery");
    require(req==original&&root==candidates&&p.count==count,
        "ACTION_RESULT_DISCOVERY_STALE","request receipt/key binding or selected candidate set changed");
    require(p.next<p.count&&p.consistent<=p.next&&p.invalid==p.next-p.consistent&&
        (p.consistent==0U)==digest_is_zero(p.first),"ACTION_RESULT_DISCOVERY_CURSOR_INVALID","invalid authenticated scan state");
    return p;
}
Digest original_binding(const StoredOutbound& original) {
    // Only facts used by validation, not process-local attempts, pagination
    // counters, free-form errors, unrelated records or physical journal bytes.
    Bytes material;datacube::append_octets(material,original.record.operation_id.octets);
    datacube::append_octets(material,original.record_digest.octets);
    text(material,original.record.issuer);text(material,original.record.recipient);
    const auto& policy=original.delivery->policy;
    text(material,*policy.peer_generation);datacube::append_octets(material,policy.peer_spki_sha256->octets);
    datacube::append_u8(material,original.receipt?1U:0U);
    if(original.receipt) {
        const auto& r=*original.receipt;
        datacube::append_octets(material,r.operation_id.octets);text(material,r.recipient);text(material,r.recorder);
        datacube::append_be64(material,r.sequence);datacube::append_octets(material,r.record_digest.octets);
        text(material,receipt_disposition_name(r.disposition));
    }
    return domain_hash("NATRAV_OVERLAY_RESULT_DISCOVERY_REQUEST_BINDING_V1",material);
}
std::string original_summary(const StoredOutbound& original,const RuntimeConfig& config,std::string_view provider) {
    const auto& policy=original.delivery->policy;
    const auto* current=find_peer_generation(config,provider,*policy.peer_generation);
    const auto trust=!current?"NOT_CONFIGURED":current->state==KeyGenerationState::revoked?"REVOKED":
        current->state==KeyGenerationState::retired?"RETIRED":"ACTIVE";
    std::string receipt="null";
    if(original.receipt) {
        const auto& r=*original.receipt;
        receipt="{\"sequence\":"+std::to_string(r.sequence)+",\"operation_id\":"+hex(r.operation_id)+
            ",\"record_digest\":"+hex(r.record_digest)+",\"recipient\":"+json_string(r.recipient)+
            ",\"recorder\":"+json_string(r.recorder)+",\"disposition\":"+json_string(receipt_disposition_name(r.disposition))+"}";
    }
    return "{\"operation_id\":"+hex(original.record.operation_id)+",\"record_digest\":"+hex(original.record_digest)+
        ",\"provider_generation\":"+json_string(*policy.peer_generation)+",\"provider_spki_sha256\":"+hex(*policy.peer_spki_sha256)+
        ",\"current_provider_key_state\":"+json_string(trust)+",\"delivery_state\":"+json_string(outbound_status_name(original))+
        ",\"source_admission_receipt\":"+receipt+"}";
}
std::string discovered_report(const Match& matched,const StoredInbound& outer) {
    const auto& r=matched.report;
    return "{\"outcome\":"+json_string(outcome_name(r.outcome))+",\"amount_ticks\":"+json_string(std::to_string(r.amount))+
        ",\"source_admission_sequence\":"+std::to_string(r.source_sequence)+
        ",\"admitted_unix_ms\":"+std::to_string(r.admitted)+",\"terminal_unix_ms\":"+std::to_string(r.terminal)+
        ",\"attempts\":"+std::to_string(r.attempts)+",\"last_started_unix_ms\":"+number(r.started)+
        ",\"local_effect_receipt_digest\":"+nullable_hex(r.effect_receipt)+
        ",\"effect_commitment_check\":"+json_string(r.effect_receipt?"SELF_CONSISTENT_NOT_INDEPENDENT_PROOF":"NOT_PRESENT")+
        ",\"counter_before\":"+exact_number(r.before)+",\"counter_after\":"+exact_number(r.after)+
        ",\"reason_bytes\":"+std::to_string(r.reason_bytes)+",\"reason_digest\":"+hex(r.reason)+
        ",\"provider_generation\":"+json_string(outer.authorization->peer_generation)+
        ",\"provider_spki_sha256\":"+hex(matched.provider_pin)+",\"local_admission_configuration_event\":"+std::to_string(matched.event)+
        ",\"provider_claimed_configuration_event\":"+std::to_string(r.provider_configuration_event)+
        ",\"provider_policy_verification\":\"CLAIM_NOT_INDEPENDENTLY_AVAILABLE\",\"provider_administrative_receipt\":null}";
}
} // namespace

void validate_action_result_discovery(const ActionResultDiscovery& q) {
    require(!digest_is_zero(q.request_operation_id)&&valid_node_id(q.provider)&&valid_scope(q.scope)&&
        q.scope!=kCounterAddActionScope&&q.limit>=1U&&q.limit<=32U&&q.maximum_response_bytes>=4096U&&
        q.maximum_response_bytes<=60000U&&(q.cursor.empty()||q.cursor.size()==2U*kDiscoveryCursorBytes),
        "ACTION_RESULT_DISCOVERY_INVALID","exact original request/provider/result scope and bounded page required");
    require(std::all_of(q.cursor.begin(),q.cursor.end(),[](char c){return(c>='0'&&c<='9')||(c>='a'&&c<='f');}),
        "ACTION_RESULT_DISCOVERY_CURSOR_INVALID","cursor must be lowercase hexadecimal");
}
Bytes encode_action_result_discovery(const ActionResultDiscovery& q) {
    validate_action_result_discovery(q);Bytes bytes;datacube::append_text(bytes,"ARD1");
    datacube::append_octets(bytes,q.request_operation_id.octets);text(bytes,q.provider);text(bytes,q.scope);
    datacube::append_be32(bytes,q.limit);datacube::append_be32(bytes,q.maximum_response_bytes);text(bytes,q.cursor);return bytes;
}
ActionResultDiscovery decode_action_result_discovery(View bytes) {
    try {
        datacube::Reader reader(bytes,"action result discovery");
        require(datacube::octets_text(reader.read_exact(4U,"magic"),"magic",true)=="ARD1",
            "ACTION_RESULT_DISCOVERY_INVALID","unknown discovery format");
        ActionResultDiscovery q{.request_operation_id=digest(reader),.provider=text(reader,64U),.scope=text(reader,128U),
            .limit=reader.read_be32("limit"),.maximum_response_bytes=reader.read_be32("response limit"),.cursor={}};
        const auto n=reader.read_be16("cursor length");
        require(n<=2U*kDiscoveryCursorBytes,"ACTION_RESULT_DISCOVERY_INVALID","oversized cursor");
        q.cursor=datacube::octets_text(reader.read_exact(n,"cursor"),"cursor",true);
        reader.require_eof("discovery request");validate_action_result_discovery(q);return q;
    } catch(const datacube::Failure&) {app_fail("ACTION_RESULT_DISCOVERY_INVALID","malformed discovery request");}
}
std::string NodeState::discover_action_results(const ActionResultDiscovery& q,const RuntimeConfig& config,
    std::uint32_t uid,std::chrono::steady_clock::time_point deadline) const {
    validate_action_result_discovery(q);
    const auto access=evidence_read_access(config.evidence_read,config.local_control,uid);
    require(local_control_allows(config.local_control,uid,LocalControlClass::inspect)&&
        evidence_read_allows(access,q.provider,q.scope,true),"ACTION_RESULT_READ_DENIED",
        "current INSPECT and exact-domain payload-read authority required");
    const auto check_time=[&]{require(std::chrono::steady_clock::now()<deadline,
        "ACTION_RESULT_DISCOVERY_DEADLINE","bounded discovery deadline reached");};
    check_time();std::lock_guard<std::mutex> lock(mutex_);check_time();
    require(!poisoned_,"STATE_RESTART_REQUIRED","restart to reconstruct failed writer");
    SubmissionWork observed;SubmissionWorkScope instrumentation(observed);Work work;
    const auto found_request=outbound_index_.find(datacube::hex_lower(q.request_operation_id));
    require(found_request!=outbound_index_.end(),"ACTION_RESULT_REQUEST_NOT_FOUND","original request not retained");
    const auto& request=outbound_[found_request->second];
    require(request.record.issuer==node_id_&&request.record.recipient==q.provider&&is_counter_add_record(request.record)&&
        !request.record.corrects&&request.delivery&&request.delivery->policy.peer_generation&&request.delivery->policy.peer_spki_sha256,
        "ACTION_RESULT_REQUEST_MISMATCH","generation-bound local counter request to expected provider required");
    // Validate the original even for an empty candidate collection.
    static_cast<void>(decode_counter_add_request(request.record.payload));
    const auto candidate_it=received_action_result_candidates_.find({q.provider,q.scope,datacube::hex_lower(q.request_operation_id)});
    const auto* selected=candidate_it==received_action_result_candidates_.end()?nullptr:&candidate_it->second;
    const auto count=selected?static_cast<std::uint64_t>(selected->records.size()):0U;
    const Digest root=selected?selected->root:Digest{};
    const auto config_digest=runtime_configuration_digest(canonical_runtime_config(config));
    ActionResultDiscovery specification_query=q;specification_query.cursor.clear();
    auto encoded=encode_action_result_discovery(specification_query);text(encoded,node_id_);
    const auto specification=domain_hash("NATRAV_OVERLAY_RESULT_DISCOVERY_SPEC_V1",encoded);
    const auto request_digest=original_binding(request);
    DiscoveryPosition position;
    if(q.cursor.empty()) {
        const auto now=discovery_time();
        require(now<=std::numeric_limits<std::uint64_t>::max()-kDiscoveryLifetimeMs,
            "ACTION_RESULT_DISCOVERY_CLOCK_FAILED","monotonic deadline overflow");
        position.count=count;position.expires=now+kDiscoveryLifetimeMs;
    } else position=open_discovery(q.cursor,uid,config_digest,specification,request_digest,root,count);
    const auto begin=position.next;
    ActionResultQuery domain{.operation_id=q.request_operation_id,.request_operation_id=q.request_operation_id,
        .provider=q.provider,.scope=q.scope,.maximum_response_bytes=16'384U};
    ReportValidator validator(domain,request,node_id_,inbound_,configuration_events_,inbound_authorization_configuration_,deadline,work);
    const std::string base="{\"format\":\"NATRAV_OVERLAY_ACTION_RESULT_DISCOVERY_V1\",\"ok\":true,\"node\":"+json_string(node_id_)+
        ",\"request_operation_id\":"+hex(q.request_operation_id)+",\"provider\":"+json_string(q.provider)+",\"scope\":"+json_string(q.scope)+
        ",\"configuration_digest\":"+hex(config_digest)+",\"original_request\":"+original_summary(request,config,q.provider)+
        ",\"verification\":\"AUTHENTICATED_PROVIDER_REPORTS_ONLY\",\"execution_verified_locally\":false,\"freshness\":\"NOT_ESTABLISHED\""+
        ",\"coverage\":\"RETAINED_PEER_AUTHORIZED_NAC1_PREFIX_EXACT_PROVIDER_SCOPE_REQUEST\""+
        ",\"selection\":{\"candidate_count\":"+std::to_string(count)+",\"candidate_root\":"+hex(root)+
        ",\"request_binding\":"+hex(request_digest)+"}";
    const auto render=[&](const DiscoveryPosition& p,const std::string& rows) {
        const bool complete=p.next==p.count;
        const auto status=!complete?"INCOMPLETE":p.count==0U?"NO_CANDIDATES":p.consistent==0U?"NO_CONSISTENT_REPORTS":
            p.consistent==1U?"UNIQUE_AUTHENTICATED_REPORT":"CONFLICTING_REPORTS";
        return base+",\"status\":"+json_string(status)+",\"complete\":"+(complete?"true":"false")+
            ",\"unique_operation_id\":"+(complete&&p.consistent==1U?hex(p.first):"null")+
            ",\"scan\":{\"from\":"+std::to_string(begin)+",\"after\":"+std::to_string(p.next)+
            ",\"examined\":"+std::to_string(p.next)+",\"consistent\":"+std::to_string(p.consistent)+",\"invalid\":"+std::to_string(p.invalid)+"}"+
            ",\"returned\":"+std::to_string(p.next-begin)+",\"records\":["+rows+"]"+
            ",\"next_cursor\":"+(complete?"null":json_string(seal_discovery(uid,config_digest,specification,request_digest,root,p)))+
            ",\"cursor_lifetime_ms\":300000,\"work\":{\"scope\":\"LOCKED_DISCOVERY_PAGE_INCLUDING_NONFITTING_CANDIDATE\""+
            ",\"candidate_records_visited\":"+std::to_string(work.candidates)+",\"report_payload_bytes_parsed\":"+std::to_string(work.bytes)+
            ",\"historical_configurations_parsed\":"+std::to_string(work.configurations)+
            ",\"historical_configuration_bytes\":"+std::to_string(work.configuration_bytes)+
            ",\"admission_binding_lookups\":"+std::to_string(work.bindings)+
            ",\"prior_candidates_rehashed\":0,\"snapshot_calls\":"+std::to_string(observed.snapshot_calls)+
            ",\"logical_bytes_serialized\":"+std::to_string(observed.snapshot_logical_bytes)+"}}";
    };
    std::string rows;
    while(position.next<count&&position.next-begin<q.limit) {
        check_time();const auto index=selected->records[static_cast<std::size_t>(position.next)];
        const auto& outer=inbound_.at(index);
        std::optional<Match> good;std::string rejection;
        try {good=validator.match(index);}
        catch(const AppError& error) {
            if(error.code()=="ACTION_RESULT_QUERY_DEADLINE")app_fail("ACTION_RESULT_DISCOVERY_DEADLINE","report validation deadline");
            if(!error.code().starts_with("ACTION_RESULT_"))throw;
            rejection=error.code();
        }
        auto next=position;++next.next;
        if(good){if(next.consistent==0U)next.first=outer.record.operation_id;++next.consistent;}else ++next.invalid;
        const std::string row="{\"operation_id\":"+hex(outer.record.operation_id)+",\"record_digest\":"+hex(outer.record_digest)+
            ",\"admission_sequence\":"+std::to_string(outer.sequence)+
            ",\"classification\":"+json_string(good?"CONSISTENT_AUTHENTICATED_REPORT":"INVALID_REPORT")+
            ",\"rejection_code\":"+(good?"null":json_string(rejection))+
            ",\"report\":"+(good?discovered_report(*good,outer):"null")+"}";
        const std::string next_rows=rows+(rows.empty()?"":",")+row;
        // Include the complete trailer, cumulative token and measured work plus
        // a conservative principal allowance. Dispatcher checks actual bytes too.
        if(render(next,next_rows).size()+384U>q.maximum_response_bytes) {
            require(position.next>begin,"ACTION_RESULT_DISCOVERY_PAGE_TOO_SMALL","first complete row does not fit");break;
        }
        rows=next_rows;position=next;
    }
    check_time();auto response=render(position,rows);
    require(response.size()+384U<=q.maximum_response_bytes,"ACTION_RESULT_DISCOVERY_PAGE_TOO_SMALL","complete metadata page does not fit");
    return response;
}
} // namespace natrav_overlay

namespace natrav_overlay {
namespace {
void put_digest(Bytes& out, const Digest& d) { datacube::append_octets(out,d.octets); }
void put_blob(Bytes& out, View bytes) {
    datacube::append_be32(out,static_cast<std::uint32_t>(bytes.size()));datacube::append_octets(out,bytes);
}
View blob(datacube::Reader& r, std::size_t bound) {
    const auto n=r.read_be32("bounded object size");
    require(n<=bound,"RESULT_REVIEW_INVALID","object exceeds limit");return r.read_exact(n,"bounded object");
}
void review_authority(const RuntimeConfig& config, std::uint32_t uid,
    std::string_view provider, std::string_view scope, bool write) {
    const auto access=evidence_read_access(config.evidence_read,config.local_control,uid);
    require(config.format_version>=8U&&local_control_allows(config.local_control,uid,LocalControlClass::inspect)&&
        evidence_read_allows(access,provider,scope,true)&&
        (!write||local_control_allows(config.local_control,uid,LocalControlClass::maintenance)),
        "RESULT_REVIEW_PERMISSION_DENIED","current durable inspection/payload authority and maintenance for commit required");
}
std::string review_conclusion(const std::vector<ResultReviewCandidate>& rows) {
    const auto good=std::count_if(rows.begin(),rows.end(),[](const auto& r){return r.rejection.empty();});
    return rows.empty()?"NO_CANDIDATES":good==0?"NO_CONSISTENT_REPORTS":
        good==1?"UNIQUE_AUTHENTICATED_REPORT":"CONFLICTING_REPORTS";
}
void review_pause(std::string_view point) {
    const std::string name="NATRAV_OVERLAY_TEST_RESULT_REVIEW_"+std::string(point)+"_MS";
    if(const auto* value=std::getenv(name.c_str())) {
        const auto ms=parse_u64(value,"review test pause",0U,5000U);
        std::cerr<<"RESULT_REVIEW_"<<point<<std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(ms));
    }
}
} // namespace

void validate_result_review(const ResultReviewRequest& r) {
    require(!digest_is_zero(r.request_operation_id)&&valid_node_id(r.provider)&&valid_scope(r.scope)&&
        r.scope!=kCounterAddActionScope&&r.candidate_count<=kResultReviewCandidateLimit&&
        (r.candidate_count==0U)==digest_is_zero(r.candidate_root)&&!digest_is_zero(r.request_binding)&&
        !digest_is_zero(r.configuration)&&!r.reason.empty()&&r.reason.size()<=256U&&
        std::all_of(r.reason.begin(),r.reason.end(),[](unsigned char c){return c>=32U&&c<=126U;}),
        "RESULT_REVIEW_INVALID","exact selection and 1..256 printable-byte reason required; at most 128 candidates");
}
Bytes encode_result_review(const ResultReviewRequest& r) {
    validate_result_review(r);Bytes out;datacube::append_text(out,"RRQ1");put_digest(out,r.request_operation_id);
    text(out,r.provider);text(out,r.scope);datacube::append_be64(out,r.candidate_count);
    put_digest(out,r.candidate_root);put_digest(out,r.request_binding);put_digest(out,r.configuration);text(out,r.reason);return out;
}
ResultReviewRequest decode_result_review(View bytes) {
    try {
        datacube::Reader r(bytes,"result review request");
        require(datacube::octets_text(r.read_exact(4U,"magic"),"magic",true)=="RRQ1","RESULT_REVIEW_INVALID","unknown review version");
        ResultReviewRequest q{.request_operation_id=digest(r),.provider=text(r,64U),.scope=text(r,128U),
            .candidate_count=r.read_be64("candidate count"),.candidate_root=digest(r),.request_binding=digest(r),
            .configuration=digest(r),.reason=text(r,256U)};
        r.require_eof("review request");validate_result_review(q);return q;
    }catch(const datacube::Failure&){app_fail("RESULT_REVIEW_INVALID","malformed review request");}
}
Bytes encode_result_review_status(const ResultReviewStatus& r) {
    require(!digest_is_zero(r.review_id),"RESULT_REVIEW_INVALID","nonzero review ID required");
    Bytes out;datacube::append_text(out,"RRS1");put_digest(out,r.review_id);return out;
}
ResultReviewStatus decode_result_review_status(View bytes) {
    try {
        datacube::Reader r(bytes,"review status");
        require(datacube::octets_text(r.read_exact(4U,"magic"),"magic",true)=="RRS1","RESULT_REVIEW_INVALID","unknown status version");
        ResultReviewStatus q{digest(r)};r.require_eof("review status");static_cast<void>(encode_result_review_status(q));return q;
    }catch(const datacube::Failure&){app_fail("RESULT_REVIEW_INVALID","malformed review status");}
}
Digest result_review_id(const ResultReviewRequest& r,std::uint32_t uid) {
    Bytes material;datacube::append_be32(material,uid);datacube::append_octets(material,encode_result_review(r));
    return domain_hash("NATRAV_OVERLAY_RESULT_REVIEW_ID_V1",material);
}
Bytes encode_result_review_record(const ResultReviewRecord& r) {
    require(r.candidates.size()==r.request.candidate_count&&r.id==result_review_id(r.request,r.uid)&&
        r.pid>0U&&r.unix_ms>0U&&r.configuration_event>0U&&valid_generation_id(r.original_generation)&&!digest_is_zero(r.original_spki),
        "RESULT_REVIEW_INVALID","invalid review record metadata");
    Bytes out;datacube::append_text(out,"NRR1");put_blob(out,encode_result_review(r.request));put_digest(out,r.id);
    datacube::append_be32(out,r.uid);datacube::append_be32(out,r.gid);datacube::append_be32(out,r.pid);
    datacube::append_be64(out,r.unix_ms);datacube::append_be64(out,r.configuration_event);
    datacube::append_be64(out,r.inbound_through);datacube::append_be64(out,r.mutation_through);put_digest(out,r.mutation_prefix);
    datacube::append_be64(out,r.original_transition_count);text(out,r.original_generation);put_digest(out,r.original_spki);
    datacube::append_u8(out,r.original_receipt?1U:0U);
    if(r.original_receipt)put_blob(out,encode_application_message(ApplicationMessage(*r.original_receipt)));
    datacube::append_be32(out,static_cast<std::uint32_t>(r.candidates.size()));
    for(const auto& c:r.candidates){put_digest(out,c.operation);put_digest(out,c.record_digest);text(out,c.rejection);}
    require(out.size()<=kResultReviewEncodedLimit,"RESULT_REVIEW_LIMIT","encoded review exceeds bound");return out;
}
ResultReviewRecord decode_result_review_record(View bytes) {
    require(bytes.size()<=kResultReviewEncodedLimit,"RESULT_REVIEW_INVALID","review size limit");
    try {
        datacube::Reader rd(bytes,"result review record");
        require(datacube::octets_text(rd.read_exact(4U,"magic"),"magic",true)=="NRR1","RESULT_REVIEW_INVALID","unknown record version");
        ResultReviewRecord r;r.request=decode_result_review(blob(rd,1024U));r.id=digest(rd);
        r.uid=rd.read_be32("uid");r.gid=rd.read_be32("gid");r.pid=rd.read_be32("pid");
        r.unix_ms=rd.read_be64("time");r.configuration_event=rd.read_be64("configuration");
        r.inbound_through=rd.read_be64("inbound prefix");r.mutation_through=rd.read_be64("mutation prefix");r.mutation_prefix=digest(rd);
        r.original_transition_count=rd.read_be64("transition prefix");r.original_generation=text(rd,64U);r.original_spki=digest(rd);
        const auto marker=rd.read_u8("receipt marker");require(marker<=1U,"RESULT_REVIEW_INVALID","receipt marker");
        if(marker){const auto m=decode_application_message(blob(rd,1024U));const auto* receipt=std::get_if<DeliveryReceipt>(&m);
            require(receipt!=nullptr,"RESULT_REVIEW_INVALID","wrong receipt kind");r.original_receipt=*receipt;}
        const auto n=rd.read_be32("classifications");require(n==r.request.candidate_count&&n<=kResultReviewCandidateLimit,"RESULT_REVIEW_INVALID","classification bound");
        for(std::uint32_t i=0U;i<n;++i){ResultReviewCandidate c;c.operation=digest(rd);c.record_digest=digest(rd);
            const auto len=rd.read_be16("rejection code length");require(len<=96U,"RESULT_REVIEW_INVALID","rejection bound");
            c.rejection=datacube::octets_text(rd.read_exact(len,"rejection"),"rejection",true);r.candidates.push_back(std::move(c));}
        rd.require_eof("result review record");require(encode_result_review_record(r)==Bytes(bytes.begin(),bytes.end()),"RESULT_REVIEW_INVALID","noncanonical review");return r;
    }catch(const datacube::Failure&){app_fail("RESULT_REVIEW_INVALID","truncated review record");}
}

StoredOutbound NodeState::review_original_locked(const ResultReviewRecord& review) const {
    const auto& q=review.request;const auto found=outbound_index_.find(datacube::hex_lower(q.request_operation_id));
    require(found!=outbound_index_.end(),"RESULT_REVIEW_SOURCE_MISSING","original request missing");
    const auto& current=outbound_[found->second];
    require(current.record.issuer==node_id_&&current.record.recipient==q.provider&&is_counter_add_record(current.record)&&
        !current.record.corrects&&current.delivery&&current.delivery->policy.peer_generation&&current.delivery->policy.peer_spki_sha256,
        "RESULT_REVIEW_SOURCE_INVALID","original generation-bound local counter request required");
    static_cast<void>(decode_counter_add_request(current.record.payload));
    const auto& transitions=current.delivery->transitions;
    require(review.original_transition_count<=transitions.size(),"RESULT_REVIEW_SOURCE_INVALID","missing request transition prefix");
    const auto generation=review.original_transition_count<transitions.size()?
        transitions[static_cast<std::size_t>(review.original_transition_count)].from_generation:*current.delivery->policy.peer_generation;
    const auto pin=review.original_transition_count<transitions.size()?
        transitions[static_cast<std::size_t>(review.original_transition_count)].from_spki_sha256:*current.delivery->policy.peer_spki_sha256;
    require(generation==review.original_generation&&pin==review.original_spki,"RESULT_REVIEW_SOURCE_INVALID","historical request key binding mismatch");
    // A later receipt must not retroactively change a no-receipt review. The
    // ordinary runtime mutation prefix proves whether that receipt was present.
    const auto rb=result_receipt_binding_.find(datacube::hex_lower(q.request_operation_id));
    if(current.receipt){require(rb!=result_receipt_binding_.end(),"RESULT_REVIEW_SOURCE_INVALID","original receipt lacks retained runtime provenance");
        const auto& binding=configuration_bindings_.at(rb->second-1U);
        require(binding.payload_digest==datacube::sha256(encode_application_message(ApplicationMessage(*current.receipt))),
            "RESULT_REVIEW_SOURCE_INVALID","receipt and retained mutation differ");
        const bool existed=rb->second<=review.mutation_through;
        require(existed==review.original_receipt.has_value()&&(!existed||*current.receipt==*review.original_receipt),
            "RESULT_REVIEW_SOURCE_INVALID","reviewed receipt does not match historical mutation prefix");
    }else require(!review.original_receipt,"RESULT_REVIEW_SOURCE_INVALID","review invents an original receipt");
    StoredOutbound result{.record=current.record,.record_digest=current.record_digest,.queue_sequence=current.queue_sequence,
        .receipt=review.original_receipt,.delivery=OutboundDeliveryState{}};
    result.delivery->policy=current.delivery->policy;
    result.delivery->policy.peer_generation=review.original_generation;result.delivery->policy.peer_spki_sha256=review.original_spki;
    require(original_binding(result)==q.request_binding,"RESULT_REVIEW_SOURCE_INVALID","review request-binding digest mismatch");return result;
}
std::vector<ResultReviewCandidate> NodeState::evaluate_result_review_locked(const ResultReviewRecord& review,
    const StoredOutbound& original,std::chrono::steady_clock::time_point deadline) const {
    require(review.inbound_through<=inbound_.size(),"RESULT_REVIEW_SOURCE_MISSING","review evidence prefix not retained");
    const auto& q=review.request;const auto group=received_action_result_candidates_.find({q.provider,q.scope,datacube::hex_lower(q.request_operation_id)});
    const auto* candidates=group==received_action_result_candidates_.end()?nullptr:&group->second;
    std::size_t count=0U;
    if(candidates)count=static_cast<std::size_t>(std::lower_bound(candidates->records.begin(),candidates->records.end(),review.inbound_through)-candidates->records.begin());
    require(count==q.candidate_count&&count<=kResultReviewCandidateLimit,"RESULT_REVIEW_SELECTION_CONFLICT","candidate count differs at selected evidence prefix");
    ActionResultQuery domain{.operation_id=q.request_operation_id,.request_operation_id=q.request_operation_id,
        .provider=q.provider,.scope=q.scope,.maximum_response_bytes=16384U};
    Work work;ReportValidator validator(domain,original,node_id_,inbound_,configuration_events_,inbound_authorization_configuration_,deadline,work);
    validator.history_limit=32U;
    Digest root{};std::vector<ResultReviewCandidate> rows;rows.reserve(count);
    for(std::size_t i=0U;i<count;++i){
        const auto index=candidates->records[i];const auto& outer=inbound_[index];
        const auto binding=inbound_authorization_configuration_.find(datacube::hex_lower(outer.record.operation_id));
        require(binding!=inbound_authorization_configuration_.end()&&binding->second<=review.configuration_event,
            "RESULT_REVIEW_SOURCE_INVALID","candidate admission after review configuration");
        Bytes b;put_digest(b,root);datacube::append_be64(b,static_cast<std::uint64_t>(i+1U));put_digest(b,outer.record.operation_id);put_digest(b,outer.record_digest);
        root=domain_hash("NATRAV_OVERLAY_RESULT_CANDIDATE_CHAIN_V1",b);
        ResultReviewCandidate row{.operation=outer.record.operation_id,.record_digest=outer.record_digest,.rejection={}};
        try{static_cast<void>(validator.match(index));}
        catch(const AppError& e){if(e.code()=="ACTION_RESULT_QUERY_DEADLINE")app_fail("RESULT_REVIEW_DEADLINE","bounded validation deadline");
            if(!e.code().starts_with("ACTION_RESULT_")) throw;
            row.rejection=e.code();}
        rows.push_back(std::move(row));
    }
    require(root==q.candidate_root,"RESULT_REVIEW_SELECTION_CONFLICT","candidate root differs");return rows;
}
void NodeState::apply_result_review(View bytes,bool checkpoint) {
    try {
        const auto r=decode_result_review_record(bytes);
        require(r.configuration_event<=configuration_events_.size(),"RESULT_REVIEW_SOURCE_INVALID","missing accepted configuration");
        const auto& event=configuration_events_[static_cast<std::size_t>(r.configuration_event-1U)];
        require(event.kind!="REJECTED"&&event.digest==r.request.configuration,"RESULT_REVIEW_SOURCE_INVALID","invalid configuration binding");
        const auto config=parse_runtime_config(event.canonical,"/historical-result-review",IdentityFileValidation::deferred);
        review_authority(config,r.uid,r.request.provider,r.request.scope,true);
        require(r.mutation_through<=configuration_binding_prefixes_.size()&&
            r.mutation_prefix==(r.mutation_through?configuration_binding_prefixes_[static_cast<std::size_t>(r.mutation_through-1U)]:Digest{}),
            "RESULT_REVIEW_SOURCE_INVALID","retained mutation prefix mismatch");
        if(!checkpoint) {
            require(r.inbound_through==inbound_.size()&&r.mutation_through==configuration_bindings_.size()&&
                r.configuration_event==active_configuration_event(configuration_events_),"RESULT_REVIEW_SOURCE_INVALID","review observation is not current at commit");
            const auto it=outbound_index_.find(datacube::hex_lower(r.request.request_operation_id));
            require(it!=outbound_index_.end()&&outbound_[it->second].delivery&&
                outbound_[it->second].delivery->transitions.size()==r.original_transition_count,
                "RESULT_REVIEW_SOURCE_INVALID","original transition prefix is stale");
        }
        const auto original=review_original_locked(r);
        const auto expected=evaluate_result_review_locked(r,original,std::chrono::steady_clock::time_point::max());
        require(expected==r.candidates,"RESULT_REVIEW_CONCLUSION_MISMATCH","source-derived review classification differs");
        require(result_reviews_.size()<kResultReviewLimit&&
            std::count_if(result_reviews_.begin(),result_reviews_.end(),[&](const auto& v){return v.uid==r.uid;})<static_cast<std::ptrdiff_t>(kResultReviewUidLimit)&&
            !result_review_index_.contains(datacube::hex_lower(r.id)),"RESULT_REVIEW_LIMIT","review registry bound or duplicate");
        result_review_index_.emplace(datacube::hex_lower(r.id),result_reviews_.size());result_reviews_.push_back(r);
        index_result_review_locked(bytes);
    }catch(const AppError& e){app_fail("JOURNAL_CORRUPT",std::string("invalid result review: ")+e.code());}
}
std::string NodeState::result_review_json_locked(const ResultReviewRecord& r,const RuntimeConfig& config,std::string_view disposition) const {
    const auto current_config=runtime_configuration_digest(canonical_runtime_config(config));
    const auto group=received_action_result_candidates_.find({r.request.provider,r.request.scope,datacube::hex_lower(r.request.request_operation_id)});
    const auto count=group==received_action_result_candidates_.end()?0U:group->second.records.size();
    const auto root=group==received_action_result_candidates_.end()?Digest{}:group->second.root;
    const bool same_candidates=count==r.request.candidate_count&&root==r.request.candidate_root;
    const auto it=outbound_index_.find(datacube::hex_lower(r.request.request_operation_id));
    const bool same_request=it!=outbound_index_.end()&&outbound_[it->second].delivery&&
        original_binding(outbound_[it->second])==r.request.request_binding;
    const auto good=std::count_if(r.candidates.begin(),r.candidates.end(),[](const auto& v){return v.rejection.empty();});
    Digest unique{};if(good==1)unique=std::find_if(r.candidates.begin(),r.candidates.end(),[](const auto& v){return v.rejection.empty();})->operation;
    std::string rows;
    for(const auto& c:r.candidates){if(!rows.empty())rows+=',';rows+="{\"operation_id\":"+hex(c.operation)+",\"record_digest\":"+hex(c.record_digest)+
        ",\"classification\":"+json_string(c.rejection.empty()?"CONSISTENT_AUTHENTICATED_REPORT":"INVALID_REPORT")+
        ",\"rejection_code\":"+(c.rejection.empty()?"null":json_string(c.rejection))+"}";}
    std::string receipt="null";
    if (r.original_receipt) {
        const auto& value=*r.original_receipt;
        receipt="{\"operation_id\":"+hex(value.operation_id)+",\"record_digest\":"+hex(value.record_digest)+
            ",\"sequence\":"+std::to_string(value.sequence)+",\"recipient\":"+json_string(value.recipient)+
            ",\"recorder\":"+json_string(value.recorder)+",\"disposition\":"+json_string(receipt_disposition_name(value.disposition))+"}";
    }
    const std::string original="{\"provider_generation\":"+json_string(r.original_generation)+
        ",\"provider_spki_sha256\":"+hex(r.original_spki)+",\"source_admission_receipt\":"+receipt+"}";
    const auto yes=[](bool b){return b?"true":"false";};
    std::string out="{\"format\":\"NATRAV_OVERLAY_RESULT_REVIEW_V1\",\"ok\":true,\"disposition\":"+json_string(disposition)+
        ",\"review_id\":"+hex(r.id)+",\"record_digest\":"+hex(datacube::sha256(encode_result_review_record(r)))+
        ",\"request_operation_id\":"+hex(r.request.request_operation_id)+",\"provider\":"+json_string(r.request.provider)+",\"scope\":"+json_string(r.request.scope)+
        ",\"uid\":"+std::to_string(r.uid)+",\"gid\":"+std::to_string(r.gid)+",\"pid\":"+std::to_string(r.pid)+",\"unix_ms\":"+std::to_string(r.unix_ms)+
        ",\"configuration_event\":"+std::to_string(r.configuration_event)+",\"configuration_digest\":"+hex(r.request.configuration)+
        ",\"reason_bytes\":"+std::to_string(r.request.reason.size())+",\"reason_digest\":"+hex(datacube::sha256(datacube::text_octets(r.request.reason)))+
        ",\"candidate_count\":"+std::to_string(r.request.candidate_count)+",\"candidate_root\":"+hex(r.request.candidate_root)+
        ",\"request_binding\":"+hex(r.request.request_binding)+",\"reviewed_original\":"+original+",\"reviewed_receipt_present\":"+yes(r.original_receipt.has_value())+
        ",\"conclusion\":"+json_string(review_conclusion(r.candidates))+",\"consistent\":"+std::to_string(good)+
        ",\"invalid\":"+std::to_string(r.candidates.size()-static_cast<std::size_t>(good))+",\"unique_operation_id\":"+(good==1?hex(unique):"null")+
        ",\"comparison\":{\"candidate_set_matches\":"+yes(same_candidates)+",\"request_binding_matches\":"+yes(same_request)+
        ",\"configuration_matches\":"+yes(current_config==r.request.configuration)+",\"status\":"+
        json_string(same_candidates&&same_request&&current_config==r.request.configuration?"CURRENT_SELECTION":"HISTORICAL")+"}"+
        ",\"execution_verified_locally\":false,\"freshness\":\"NOT_ESTABLISHED\",\"coverage\":\"EXACT_PROVIDER_SCOPE_REQUEST_NAC1_CANDIDATES\""+
        ",\"records\":["+rows+"]}";
    require(out.size()+384U<=60000U,"RESULT_REVIEW_RESPONSE_LIMIT","bounded review response");return out;
}
std::string NodeState::commit_result_review(const ResultReviewRequest& q,const RuntimeConfig& config,
    std::uint32_t uid,std::uint32_t gid,std::uint32_t pid,std::chrono::steady_clock::time_point deadline) {
    validate_result_review(q);review_authority(config,uid,q.provider,q.scope,true);
    std::lock_guard<std::mutex> lock(mutex_);require(!poisoned_,"STATE_RESTART_REQUIRED","restart failed writer");
    const auto id=result_review_id(q,uid);const auto old=result_review_index_.find(datacube::hex_lower(id));
    if(old!=result_review_index_.end())return result_review_json_locked(result_reviews_[old->second],config,"ALREADY_REVIEWED");
    require(result_reviews_.size()<kResultReviewLimit&&std::count_if(result_reviews_.begin(),result_reviews_.end(),
        [&](const auto& r){return r.uid==uid;})<static_cast<std::ptrdiff_t>(kResultReviewUidLimit),"RESULT_REVIEW_LIMIT","finite retained review registry full");
    const auto cfg=runtime_configuration_digest(canonical_runtime_config(config));
    require(cfg==q.configuration,"RESULT_REVIEW_CONFIGURATION_CONFLICT","accepted configuration changed");
    const auto original=outbound_index_.find(datacube::hex_lower(q.request_operation_id));
    require(original!=outbound_index_.end(),"ACTION_RESULT_REQUEST_NOT_FOUND","original request missing");
    const auto& source=outbound_[original->second];
    require(source.delivery&&source.delivery->policy.peer_generation&&source.delivery->policy.peer_spki_sha256&&
        original_binding(source)==q.request_binding,"RESULT_REVIEW_REQUEST_CONFLICT","original request receipt or key binding changed");
    ResultReviewRecord r{.request=q,.id=id,.uid=uid,.gid=gid,.pid=pid,.unix_ms=static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count()),
        .configuration_event=static_cast<std::uint64_t>(active_configuration_event(configuration_events_)),
        .inbound_through=static_cast<std::uint64_t>(inbound_.size()),.mutation_through=static_cast<std::uint64_t>(configuration_bindings_.size()),
        .mutation_prefix=configuration_binding_prefixes_.empty()?Digest{}:configuration_binding_prefixes_.back(),
        .original_transition_count=static_cast<std::uint64_t>(source.delivery->transitions.size()),
        .original_generation=*source.delivery->policy.peer_generation,.original_spki=*source.delivery->policy.peer_spki_sha256,
        .original_receipt=source.receipt,.candidates={}};
    const auto original_at_review=review_original_locked(r);
    r.candidates=evaluate_result_review_locked(r,original_at_review,deadline);
    require(std::chrono::steady_clock::now()<deadline,"RESULT_REVIEW_DEADLINE","validation budget elapsed");
    const auto payload=encode_result_review_record(r);
    review_pause("BEFORE_COMMIT");append_entry(EntryKind::result_review,payload);review_pause("AFTER_COMMIT");
    return result_review_json_locked(result_reviews_.back(),config,"REVIEWED");
}
std::string NodeState::result_review_status(const ResultReviewStatus& q,const RuntimeConfig& config,std::uint32_t uid) const {
    std::lock_guard<std::mutex> lock(mutex_);require(!poisoned_,"STATE_RESTART_REQUIRED","restart failed writer");
    const auto found=result_review_index_.find(datacube::hex_lower(q.review_id));
    require(found!=result_review_index_.end()&&result_reviews_[found->second].uid==uid,"RESULT_REVIEW_NOT_FOUND","no review owned by this principal");
    const auto& r=result_reviews_[found->second];review_authority(config,uid,r.request.provider,r.request.scope,false);
    return result_review_json_locked(r,config,"RETAINED");
}
} // namespace natrav_overlay
