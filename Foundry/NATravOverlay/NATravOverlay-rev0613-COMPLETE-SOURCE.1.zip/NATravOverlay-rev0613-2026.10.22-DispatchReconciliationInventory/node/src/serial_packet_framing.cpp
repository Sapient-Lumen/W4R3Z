#include "serial_packet_framing.hpp"

#include <algorithm>
#include <limits>
#include <stdexcept>

namespace natrav_overlay::serial_packet {
namespace {
void increment(std::uint64_t& value) noexcept {
    if (value != std::numeric_limits<std::uint64_t>::max()) { ++value; }
}
bool escaped(const std::uint8_t byte) noexcept {
    return byte < 0x20U || byte == 0x7dU || byte == 0x7eU || byte == 0x7fU;
}
void append(Bytes& bytes, const std::uint64_t value, const unsigned count) {
    for (unsigned i = count; i > 0U; --i) {
        bytes.push_back(static_cast<std::uint8_t>(value >> ((i - 1U) * 8U)));
    }
}
std::uint64_t read(const Bytes& bytes, const std::size_t offset, const std::size_t count) {
    std::uint64_t result = 0U;
    for (std::size_t i = 0U; i < count; ++i) { result = (result << 8U) | bytes[offset + i]; }
    return result;
}
}  // namespace

void Settings::validate() const {
    if (mtu < 256U || mtu > kMaximumMtu || link == 0U || epoch == 0U ||
        frame_timeout_ms < 100U || frame_timeout_ms > 60000U) {
        throw std::invalid_argument("NSP1 settings outside finite bounds");
    }
}

std::uint32_t crc32(const std::span<const std::uint8_t> bytes) noexcept {
    std::uint32_t value = 0xffffffffU;
    for (const auto byte : bytes) {
        value ^= byte;
        for (unsigned bit = 0U; bit < 8U; ++bit) {
            const std::uint32_t mask = 0U - (value & 1U);
            value = (value >> 1U) ^ (0xedb88320U & mask);
        }
    }
    return ~value;
}

std::size_t maximum_wire_bytes(const std::size_t packet_bytes) {
    if (packet_bytes == 0U || packet_bytes > kMaximumMtu) {
        throw std::invalid_argument("NSP1 packet size outside finite bounds");
    }
    return 2U * (packet_bytes + kOverhead) + 2U;
}

std::uint64_t minimum_transmit_time_ms(
    const std::size_t packet_bytes,
    const std::uint32_t baud,
    const std::uint8_t bits_per_character) {
    if (baud == 0U || bits_per_character < 8U || bits_per_character > 16U) {
        throw std::invalid_argument("serial line-rate parameters outside finite bounds");
    }
    const auto bytes = static_cast<std::uint64_t>(maximum_wire_bytes(packet_bytes));
    const auto bits = bytes * static_cast<std::uint64_t>(bits_per_character);
    const auto numerator = bits * 1000U;
    return (numerator + static_cast<std::uint64_t>(baud) - 1U) /
        static_cast<std::uint64_t>(baud);
}

Bytes encode(const Settings& settings, const std::span<const std::uint8_t> packet) {
    settings.validate();
    if (packet.empty() || packet.size() > settings.mtu) {
        throw std::invalid_argument("NSP1 datagram outside MTU");
    }
    Bytes raw{'N', 'S', 'P', '1'};
    raw.reserve(packet.size() + kOverhead);
    append(raw, settings.link, 8U);
    append(raw, settings.epoch, 4U);
    append(raw, packet.size(), 2U);
    raw.insert(raw.end(), packet.begin(), packet.end());
    append(raw, crc32(raw), 4U);
    Bytes wire;
    wire.reserve(maximum_wire_bytes(packet.size()));
    wire.push_back(0x7eU);
    for (const auto byte : raw) {
        if (escaped(byte)) {
            wire.push_back(0x7dU);
            wire.push_back(static_cast<std::uint8_t>(byte ^ 0x20U));
        } else { wire.push_back(byte); }
    }
    wire.push_back(0x7eU);
    return wire;
}

Decoder::Decoder(Settings settings) : settings_(settings) {
    settings_.validate();
    raw_.reserve(settings_.mtu + kOverhead);
}
void Decoder::reject() noexcept {
    increment(counters_.rejected);
    raw_.clear();
    active_ = false;
    escaping_ = false;
    started_ = false;
}
void Decoder::expire(const std::uint64_t now_ms) noexcept {
    // Unsigned subtraction is avoided until monotonicity has been checked.
    if (started_ && (now_ms < started_ms_ || now_ms - started_ms_ >= settings_.frame_timeout_ms)) {
        increment(counters_.expired);
        reject();
    }
}
std::optional<Bytes> Decoder::finish() {
    static constexpr std::uint8_t magic[]{'N', 'S', 'P', '1'};
    if (escaping_ || raw_.size() <= kOverhead ||
        !std::equal(std::begin(magic), std::end(magic), raw_.begin()) ||
        read(raw_, 4U, 8U) != settings_.link || read(raw_, 12U, 4U) != settings_.epoch ||
        read(raw_, 16U, 2U) != raw_.size() - kOverhead ||
        crc32(std::span<const std::uint8_t>(raw_).first(raw_.size() - 4U)) !=
            read(raw_, raw_.size() - 4U, 4U)) {
        reject();
        return std::nullopt;
    }
    increment(counters_.accepted);
    return Bytes(raw_.begin() + 18, raw_.end() - 4);
}
std::optional<Bytes> Decoder::consume(const std::uint8_t byte, const std::uint64_t now_ms) {
    expire(now_ms);
    if (byte == 0x7eU) {
        std::optional<Bytes> result;
        if (active_ && (!raw_.empty() || escaping_)) { result = finish(); }
        raw_.clear();
        active_ = true;
        escaping_ = false;
        started_ = false;
        return result;
    }
    if (!active_) { increment(counters_.noise_bytes); return std::nullopt; }
    if (!started_) { started_ = true; started_ms_ = now_ms; }
    std::uint8_t decoded = byte;
    if (escaping_) {
        decoded = static_cast<std::uint8_t>(byte ^ 0x20U);
        if (!escaped(decoded)) { reject(); return std::nullopt; }
        escaping_ = false;
    } else if (byte == 0x7dU) {
        escaping_ = true;
        return std::nullopt;
    } else if (escaped(byte)) {
        reject();
        return std::nullopt;
    }
    if (raw_.size() == settings_.mtu + kOverhead) {
        reject();
        return std::nullopt;
    }
    raw_.push_back(decoded);
    return std::nullopt;
}
}  // namespace natrav_overlay::serial_packet
