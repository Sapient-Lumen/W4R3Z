#include "runtime_status.hpp"
namespace natrav_overlay {
std::string runtime_status_work_json(const RuntimeStatusWork& w) {
    return std::string("{\"scope\":\"LOCKED_STATE_STATUS_SELECTION\"") +
        ",\"outbox_metadata_records\":" + std::to_string(w.outbox_metadata_records) +
        ",\"action_metadata_records\":" + std::to_string(w.action_metadata_records) +
        ",\"transition_metadata_records\":" + std::to_string(w.transitions) +
        ",\"rejection_tail_reads\":" + std::to_string(w.rejection_tail_reads) +
        ",\"aggregate_reads\":" + std::to_string(w.aggregate_reads) +
        ",\"binding_lookups\":" + std::to_string(w.binding_lookups) +
        ",\"logical_bytes_serialized\":" + std::to_string(w.logical_bytes_serialized) +
        ",\"logical_digest_computations\":" + std::to_string(w.logical_digest_computations) +
        ",\"snapshot_calls\":" + std::to_string(w.snapshot_calls) +
        ",\"snapshot_payload_bytes\":" + std::to_string(w.snapshot_payload_bytes) + "}";
}
}
