#include "authorization.hpp"

#include <algorithm>
#include <string>
#include <tuple>
#include <utility>

namespace natrav_overlay {
namespace {

[[nodiscard]] std::string generation_text(
    const std::optional<std::string>& generation) {
    return generation.has_value() ? *generation : "*";
}

[[nodiscard]] std::string canonical_rule(const AuthorizationRule& rule) {
    return std::string("NATRAV_OVERLAY_AUTHORIZATION_RULE_V1\n") +
        "peer=" + rule.peer_node + "\n" +
        "generation=" + generation_text(rule.peer_generation) + "\n" +
        "class=" + std::string(authorized_operation_class_name(
            rule.operation_class)) + "\n" +
        "resource=" + rule.resource + "\n";
}

[[nodiscard]] datacube::Digest32 rule_digest(const AuthorizationRule& rule) {
    return datacube::sha256(datacube::text_octets(canonical_rule(rule)));
}

void validate_action_limits(const ActionLimits& limits) {
    if (limits.counter_budget < 1U ||
        limits.counter_budget > 1'000'000'000'000ULL ||
        limits.maximum_increment < 1U ||
        limits.maximum_increment > limits.counter_budget ||
        limits.maximum_defer_ms > 2'592'000'000ULL ||
        limits.expiry_ms < 100U ||
        limits.expiry_ms > 2'592'000'000ULL) {
        app_fail("AUTHORIZATION_POLICY_INVALID",
            "counter action limits are outside the supported envelope");
    }
}

void validate_rule(const AuthorizationRule& rule) {
    require_node_id(rule.peer_node, "authorization peer");
    if (rule.peer_generation.has_value()) {
        require_generation_id(*rule.peer_generation,
            "authorization peer generation");
    }
    if (rule.operation_class == AuthorizedOperationClass::evidence) {
        require_scope(rule.resource);
        if (rule.resource == kCounterAddActionScope) {
            app_fail("AUTHORIZATION_POLICY_INVALID",
                "the reserved counter action scope must use ACTION/counter.add");
        }
        return;
    }
    if (rule.operation_class == AuthorizedOperationClass::counter_action &&
        rule.resource == "counter.add") {
        return;
    }
    app_fail("AUTHORIZATION_POLICY_INVALID",
        "unsupported authorization operation class or resource");
}

[[nodiscard]] auto rule_key(const AuthorizationRule& rule) {
    return std::tuple(
        rule.peer_node,
        generation_text(rule.peer_generation),
        static_cast<std::uint8_t>(rule.operation_class),
        rule.resource);
}

[[nodiscard]] std::string canonical_action_result_rule(
    const ActionResultRule& rule) {
    return std::string("NATRAV_OVERLAY_ACTION_RESULT_RULE_V1\n") +
        "peer=" + rule.peer_node + "\n" +
        "generation=" + rule.peer_generation + "\n" +
        "resource=" + rule.resource + "\n" +
        "scope=" + rule.result_scope + "\n";
}

[[nodiscard]] auto action_result_key(const ActionResultRule& rule) {
    return std::tuple(
        rule.peer_node, rule.peer_generation, rule.resource,
        rule.result_scope);
}

}  // namespace

AuthorizationPolicy make_authorization_policy(
    std::vector<AuthorizationRule> rules,
    const ActionLimits& action_limits) {
    validate_action_limits(action_limits);
    if (rules.size() > 512U) {
        app_fail("AUTHORIZATION_POLICY_INVALID",
            "at most 512 authorization rules are supported");
    }
    for (auto& rule : rules) {
        validate_rule(rule);
        rule.digest = rule_digest(rule);
    }
    std::sort(rules.begin(), rules.end(), [](const auto& left, const auto& right) {
        return rule_key(left) < rule_key(right);
    });
    for (std::size_t index = 1U; index < rules.size(); ++index) {
        if (rule_key(rules[index - 1U]) == rule_key(rules[index])) {
            app_fail("AUTHORIZATION_RULE_DUPLICATE",
                "duplicate authorization rule for " + rules[index].peer_node);
        }
    }
    for (std::size_t left = 0U; left < rules.size(); ++left) {
        for (std::size_t right = left + 1U; right < rules.size(); ++right) {
            const auto& a = rules[left];
            const auto& b = rules[right];
            if (a.peer_node != b.peer_node ||
                a.operation_class != b.operation_class ||
                a.resource != b.resource) {
                continue;
            }
            if (a.peer_generation.has_value() != b.peer_generation.has_value()) {
                app_fail("AUTHORIZATION_RULE_AMBIGUOUS",
                    "peer-wide and generation-specific rules overlap for " +
                    a.peer_node + "/" + a.resource);
            }
        }
    }

    std::string canonical = "NATRAV_OVERLAY_AUTHORIZATION_POLICY_V1\n";
    canonical += "counter_budget=" +
        std::to_string(action_limits.counter_budget) + "\n";
    canonical += "maximum_increment=" +
        std::to_string(action_limits.maximum_increment) + "\n";
    canonical += "maximum_defer_ms=" +
        std::to_string(action_limits.maximum_defer_ms) + "\n";
    canonical += "expiry_ms=" + std::to_string(action_limits.expiry_ms) + "\n";
    for (const auto& rule : rules) {
        canonical += canonical_rule(rule);
    }
    return AuthorizationPolicy{
        .rules = std::move(rules),
        .action_limits = action_limits,
        .digest = datacube::sha256(datacube::text_octets(canonical)),
    };
}

AuthorizedOperationClass operation_class_for(
    const EvidenceRecord& record) noexcept {
    return record.scope == kCounterAddActionScope ?
        AuthorizedOperationClass::counter_action :
        AuthorizedOperationClass::evidence;
}

std::string authorization_resource_for(const EvidenceRecord& record) {
    return operation_class_for(record) == AuthorizedOperationClass::counter_action ?
        std::string("counter.add") : record.scope;
}

AuthorizationDecision evaluate_authorization(
    const AuthorizationPolicy& policy,
    const std::string_view peer_node,
    const std::string_view peer_generation,
    const EvidenceRecord& record) {
    require_node_id(peer_node, "authenticated peer");
    require_generation_id(peer_generation, "authenticated peer generation");
    const auto operation_class = operation_class_for(record);
    const auto resource = authorization_resource_for(record);
    const AuthorizationRule* matched = nullptr;
    for (const auto& rule : policy.rules) {
        if (rule.peer_node != peer_node ||
            rule.operation_class != operation_class ||
            rule.resource != resource ||
            (rule.peer_generation.has_value() &&
             *rule.peer_generation != peer_generation)) {
            continue;
        }
        if (matched != nullptr) {
            app_fail("AUTHORIZATION_POLICY_AMBIGUOUS",
                "more than one rule matched an authenticated operation");
        }
        matched = &rule;
    }
    return AuthorizationDecision{
        .allowed = matched != nullptr,
        .peer_node = std::string(peer_node),
        .peer_generation = std::string(peer_generation),
        .operation_class = operation_class,
        .resource = resource,
        .policy_digest = policy.digest,
        .rule_digest = matched == nullptr ?
            std::optional<datacube::Digest32>{} : matched->digest,
        .action_limits = policy.action_limits,
        .reason_code = matched == nullptr ?
            std::string("AUTHORIZATION_DENIED") : std::string("AUTHORIZED"),
    };
}

std::string_view authorized_operation_class_name(
    const AuthorizedOperationClass value) noexcept {
    switch (value) {
        case AuthorizedOperationClass::evidence: return "EVIDENCE";
        case AuthorizedOperationClass::counter_action: return "ACTION";
    }
    return "UNKNOWN";
}

std::string authorization_policy_json(const AuthorizationPolicy& policy) {
    std::string out = "{\"format\":\"NATRAV_OVERLAY_AUTHORIZATION_POLICY_V1\"";
    out += ",\"digest\":" + json_string(datacube::hex_lower(policy.digest));
    out += ",\"action_limits\":{\"counter_budget\":" +
        std::to_string(policy.action_limits.counter_budget) +
        ",\"maximum_increment\":" +
        std::to_string(policy.action_limits.maximum_increment) +
        ",\"maximum_defer_ms\":" +
        std::to_string(policy.action_limits.maximum_defer_ms) +
        ",\"expiry_ms\":" +
        std::to_string(policy.action_limits.expiry_ms) + "}";
    out += ",\"rules\":[";
    for (std::size_t index = 0U; index < policy.rules.size(); ++index) {
        if (index != 0U) { out += ','; }
        const auto& rule = policy.rules[index];
        out += "{\"peer\":" + json_string(rule.peer_node) +
            ",\"generation\":" +
            (rule.peer_generation.has_value() ?
                json_string(*rule.peer_generation) : std::string("null")) +
            ",\"class\":" +
            json_string(authorized_operation_class_name(rule.operation_class)) +
            ",\"resource\":" + json_string(rule.resource) +
            ",\"digest\":" +
            json_string(datacube::hex_lower(rule.digest)) + "}";
    }
    out += "]}";
    return out;
}

ActionResultPolicy make_action_result_policy(
    std::vector<ActionResultRule> rules) {
    if (rules.size() > 256U) {
        app_fail("ACTION_RESULT_POLICY_INVALID",
            "at most 256 action-result disclosure rules are supported");
    }
    for (auto& rule : rules) {
        require_node_id(rule.peer_node, "action-result peer");
        require_generation_id(rule.peer_generation,
            "action-result peer generation");
        if (rule.resource != "counter.add") {
            app_fail("ACTION_RESULT_POLICY_INVALID",
                "the only supported action-result resource is counter.add");
        }
        require_scope(rule.result_scope);
        if (rule.result_scope == kCounterAddActionScope) {
            app_fail("ACTION_RESULT_POLICY_INVALID",
                "an action result must use an evidence scope");
        }
        rule.digest = datacube::sha256(datacube::text_octets(
            canonical_action_result_rule(rule)));
    }
    std::sort(rules.begin(), rules.end(), [](const auto& left, const auto& right) {
        return action_result_key(left) < action_result_key(right);
    });
    for (std::size_t index = 1U; index < rules.size(); ++index) {
        const auto& before = rules[index - 1U];
        const auto& after = rules[index];
        if (before.peer_node == after.peer_node &&
            before.peer_generation == after.peer_generation &&
            before.resource == after.resource) {
            app_fail("ACTION_RESULT_RULE_DUPLICATE",
                "one peer generation may have only one result scope per resource");
        }
    }
    std::string canonical = "NATRAV_OVERLAY_ACTION_RESULT_POLICY_V1\n";
    for (const auto& rule : rules) {
        canonical += canonical_action_result_rule(rule);
    }
    return ActionResultPolicy{
        .rules = std::move(rules),
        .digest = datacube::sha256(datacube::text_octets(canonical)),
    };
}

const ActionResultRule* find_action_result_rule(
    const ActionResultPolicy& policy,
    const std::string_view peer_node,
    const std::string_view peer_generation,
    const std::string_view resource) noexcept {
    for (const auto& rule : policy.rules) {
        if (rule.peer_node == peer_node &&
            rule.peer_generation == peer_generation &&
            rule.resource == resource) {
            return &rule;
        }
    }
    return nullptr;
}

std::string action_result_policy_json(const ActionResultPolicy& policy) {
    std::string out = "{\"format\":\"NATRAV_OVERLAY_ACTION_RESULT_POLICY_V1\"";
    out += ",\"digest\":" + json_string(datacube::hex_lower(policy.digest));
    out += ",\"rules\":[";
    for (std::size_t index = 0U; index < policy.rules.size(); ++index) {
        if (index != 0U) { out += ','; }
        const auto& rule = policy.rules[index];
        out += "{\"peer\":" + json_string(rule.peer_node) +
            ",\"generation\":" + json_string(rule.peer_generation) +
            ",\"resource\":" + json_string(rule.resource) +
            ",\"scope\":" + json_string(rule.result_scope) +
            ",\"digest\":" +
            json_string(datacube::hex_lower(rule.digest)) + "}";
    }
    out += "]}";
    return out;
}

}  // namespace natrav_overlay
