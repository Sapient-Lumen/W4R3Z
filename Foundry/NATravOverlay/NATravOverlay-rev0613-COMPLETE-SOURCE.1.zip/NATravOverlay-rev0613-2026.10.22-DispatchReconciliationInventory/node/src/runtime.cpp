#include "runtime.hpp"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <set>
#include <thread>

namespace natrav_overlay {
namespace {
std::uint64_t now_ms() {
    const auto value = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    if (value <= 0) { app_fail("CLOCK_INVALID", "invalid configuration activation time"); }
    return static_cast<std::uint64_t>(value);
}
std::chrono::milliseconds boundary_delay(const char* name) {
    const char* value = std::getenv(name);
    return std::chrono::milliseconds(value && *value ? parse_u64(value, name, 0U, 60'000U) : 0U);
}
void pause_prepared_boundary(const char* name, const std::chrono::milliseconds delay) {
    if (delay.count() != 0) {
        // Literal hook names contain no quoting/control characters. Avoid any
        // allocation or parsing between durable commit and memory publication.
        std::cerr << "{\"test_boundary\":\"" << name << "\"}" << std::endl;
        std::this_thread::sleep_for(delay);
    }
}
void pause_boundary(const char* name) { pause_prepared_boundary(name, boundary_delay(name)); }
void require_owner_boundary(const RuntimeConfig& before, const RuntimeConfig& after) {
    if (!runtime_owner_boundary_equal(before, after)) {
        const bool owner_changed = before.local_node != after.local_node ||
            before.state_directory != after.state_directory ||
            before.control_socket != after.control_socket ||
            before.local_identity_generation != after.local_identity_generation ||
            before.identity.certificate != after.identity.certificate ||
            before.identity.private_key != after.identity.private_key ||
            before.identity.expected_spki_sha256 !=
                after.identity.expected_spki_sha256;
        if (owner_changed) {
            app_fail("CONFIG_OWNER_BOUNDARY_CHANGED",
                "node, state, control and local identity are immutable while running");
        }
        app_fail("CONFIG_SERVICE_LAYOUT_CHANGED",
            "listener, journal ceiling and worker layout are fixed for this versioned state");
    }
}
void require_capacity(const RuntimeConfig& config, const StateSnapshot& state) {
    const auto& used = state.queue_usage;
    const auto& limit = config.queue_limits;
    if (used.pending_records + used.future_result_records > limit.global_max_records ||
        used.pending_payload_bytes + used.future_result_payload_bytes > limit.global_max_payload_bytes) {
        app_fail("CONFIG_OUTBOX_BELOW_USAGE", "candidate global quota is below durable pending usage");
    }
    for (const auto& peer : used.peers) {
        if (peer.pending_records + peer.future_result_records > limit.peer_max_records ||
            peer.pending_payload_bytes + peer.future_result_payload_bytes > limit.peer_max_payload_bytes) {
            app_fail("CONFIG_OUTBOX_BELOW_USAGE", "candidate peer quota is below durable pending usage");
        }
    }
    const auto budget = config.authorization.action_limits.counter_budget;
    for (const auto& action : state.actions) {
        if (action_is_pending(action) && budget > action.limits.counter_budget) {
            app_fail("CONFIG_ACTION_OBLIGATIONS_PRESENT",
                "complete or cancel old-budget actions before increasing the absolute counter budget");
        }
    }
    if (state.action_counter_value > budget ||
        state.action_reserved_amount > budget - state.action_counter_value) {
        app_fail("CONFIG_ACTION_BELOW_USAGE", "candidate action budget is below committed and reserved effects");
    }
}
void require_historical_keys(const RuntimeConfig& candidate, const StateSnapshot& state) {
    for (const auto& event : state.configuration_events) {
        if (event.kind == "REJECTED") { continue; }
        const auto old = parse_runtime_config(
            event.canonical,
            "/durable-configuration",
            IdentityFileValidation::deferred);
        require_runtime_adapter_history_preserved(old.adapter_configuration, candidate.adapter_configuration);
        if (old.format_version >= 20U && candidate.format_version < 20U) {
            app_fail("CONFIG_HANDOFF_DOWNGRADE", "accepted V20 policy cannot be bypassed by version downgrade");
        }
        require_handoff_key_history_preserved(old.handoff_keys, candidate.handoff_keys);
        if (old.format_version >= 21U && candidate.format_version < 21U) {
            app_fail("CONFIG_CUSTODY_DOWNGRADE",
                "accepted V21 custody policy cannot be bypassed by version downgrade");
        }
        require_custody_relay_history_preserved(
            old.custody_relay, candidate.custody_relay);
        if (old.format_version >= 22U && candidate.format_version < 22U) {
            app_fail("CONFIG_CUSTODY_SESSION_DOWNGRADE",
                "accepted V22 custody service policy cannot be bypassed by version downgrade");
        }
        require_custody_session_history_preserved(
            old.custody_sessions, candidate.custody_sessions);
        if (old.format_version >= 23U && candidate.format_version < 23U) {
            app_fail("CONFIG_CUSTODY_RECEIVER_DOWNGRADE",
                "accepted V23 daemon receiver policy cannot be bypassed by version downgrade");
        }
        require_custody_receiver_history_preserved(
            old.custody_receivers, candidate.custody_receivers);
        if (old.format_version >= 24U && candidate.format_version < 24U) {
            app_fail("CONFIG_CUSTODY_DISPATCH_DOWNGRADE",
                "accepted V24 owner dispatch policy cannot be bypassed by version downgrade");
        }
        require_custody_dispatch_history_preserved(
            old.custody_dispatch, candidate.custody_dispatch);
        for (const auto& old_peer : old.peers) {
            for (const auto& old_route : old_peer.routes) {
                const auto old_endpoint = transport_locator_text(old_route.locator);
                for (const auto& replacement_peer : candidate.peers) {
                    if (replacement_peer.node_id == old_peer.node_id) { continue; }
                    for (const auto& replacement_route : replacement_peer.routes) {
                        if (transport_locator_text(replacement_route.locator) == old_endpoint) {
                            app_fail("CONFIG_HISTORICAL_ROUTE_CONFLICT",
                                "a transport locator cannot be reassigned to a different peer identity");
                        }
                    }
                }
            }
        }
        for (const auto& key : old.peer_generations) {
            for (const auto& replacement : candidate.peer_generations) {
                if ((key.node_id == replacement.node_id && key.generation == replacement.generation &&
                     key.spki_sha256 != replacement.spki_sha256) ||
                    (key.spki_sha256 == replacement.spki_sha256 &&
                     (key.node_id != replacement.node_id || key.generation != replacement.generation))) {
                    app_fail("CONFIG_HISTORICAL_KEY_CONFLICT", "previous key-to-node/generation meaning cannot be reassigned");
                }
                // Revocation is a monotonic security fact, including rollback.
                if (key.node_id == replacement.node_id && key.generation == replacement.generation &&
                    key.state == KeyGenerationState::revoked && replacement.state != KeyGenerationState::revoked) {
                    app_fail("CONFIG_REVOCATION_ROLLBACK", "rollback cannot resurrect a revoked generation");
                }
            }
        }
    }
    for (const auto& entry : state.outbound) {
        if (!outbound_is_pending(entry)) { continue; }
        if (!entry.delivery.has_value()) {
            app_fail("OUTBOUND_GENERATION_BINDING_REQUIRED", "unbound historical operation requires an explicit migration before live mode");
        }
        const auto& policy = entry.delivery->policy;
        if (!policy.peer_generation.has_value() || !policy.peer_spki_sha256.has_value()) {
            app_fail("OUTBOUND_GENERATION_BINDING_REQUIRED", "unbound historical obligation cannot enter live mode");
        }
        const auto* key = find_peer_generation(candidate, entry.record.recipient, *policy.peer_generation);
        if (key && key->spki_sha256 != *policy.peer_spki_sha256) {
            app_fail("CONFIG_HISTORICAL_KEY_CONFLICT", "candidate changes a durable obligation key binding");
        }
    }
}
}

RuntimeConfiguration::RuntimeConfiguration(const RuntimeConfig& seed, NodeState& state) {
    auto stored = state.snapshot();
    const auto active = active_configuration_event(stored.configuration_events);
    RuntimeConfig selected = seed;
    if (active != 0U) {
        const auto canonical = canonical_runtime_config(seed);
        bool known = false;
        for (const auto& event : stored.configuration_events) {
            known = known || (event.kind != "REJECTED" && event.canonical == canonical);
        }
        if (!known) {
            app_fail("CONFIG_STARTUP_NOT_RECORDED", "startup config must name an accepted generation; active journal generation is authoritative");
        }
        selected = parse_runtime_config(
            stored.configuration_events[active - 1U].canonical,
            seed.source_path,
            IdentityFileValidation::deferred);
        require_owner_boundary(seed, selected);
    }
    TlsContext validated_identity(selected.identity);
    if (active == 0U && !selected.runtime_generation.empty()) {
        require_capacity(selected, stored);
        require_historical_keys(selected, stored);
        std::set<std::string> bootstrap_nodes;
        for (const auto& key : selected.peer_generations) { bootstrap_nodes.insert(key.node_id); }
        for (const auto& peer : selected.peers) { bootstrap_nodes.insert(peer.node_id); }
        if (bootstrap_nodes.size() > maximum_peer_registry_size) {
            app_fail("CONFIG_PEER_REGISTRY_LIMIT", "at most 64 historical peer slots are supported");
        }
        const auto canonical = canonical_runtime_config(selected);
        state.record_runtime_configuration(RuntimeConfigurationEvent{
            .kind = "BOOTSTRAP", .generation = selected.runtime_generation,
            .digest = runtime_configuration_digest(canonical), .canonical = canonical,
            .unix_ms = now_ms(), .actor = "LOCAL_STARTUP", .reason = "initial explicit versioned configuration",
            .error_code = {},
        });
        stored = state.snapshot();
    }
    std::set<std::string> nodes;
    for (const auto& key : selected.peer_generations) { nodes.insert(key.node_id); }
    for (const auto& peer : selected.peers) { nodes.insert(peer.node_id); }
    for (const auto& event : stored.configuration_events) {
        if (event.kind == "REJECTED") { continue; }
        const auto config = parse_runtime_config(
            event.canonical,
            seed.source_path,
            IdentityFileValidation::deferred);
        require_runtime_adapter_history_preserved(config.adapter_configuration, selected.adapter_configuration);
        if (config.format_version >= 20U && selected.format_version < 20U) {
            app_fail("CONFIG_HANDOFF_DOWNGRADE", "accepted V20 policy cannot be bypassed during replay");
        }
        require_handoff_key_history_preserved(config.handoff_keys, selected.handoff_keys);
        if (config.format_version >= 21U && selected.format_version < 21U) {
            app_fail("CONFIG_CUSTODY_DOWNGRADE",
                "accepted V21 custody policy cannot be bypassed during replay");
        }
        require_custody_relay_history_preserved(
            config.custody_relay, selected.custody_relay);
        if (config.format_version >= 22U && selected.format_version < 22U) {
            app_fail("CONFIG_CUSTODY_SESSION_DOWNGRADE",
                "accepted V22 custody service policy cannot be bypassed during replay");
        }
        require_custody_session_history_preserved(
            config.custody_sessions, selected.custody_sessions);
        if (config.format_version >= 23U && selected.format_version < 23U) {
            app_fail("CONFIG_CUSTODY_RECEIVER_DOWNGRADE",
                "accepted V23 daemon receiver policy cannot be bypassed during replay");
        }
        require_custody_receiver_history_preserved(
            config.custody_receivers, selected.custody_receivers);
        if (config.format_version >= 24U && selected.format_version < 24U) {
            app_fail("CONFIG_CUSTODY_DISPATCH_DOWNGRADE",
                "accepted V24 owner dispatch policy cannot be bypassed during replay");
        }
        require_custody_dispatch_history_preserved(
            config.custody_dispatch, selected.custody_dispatch);
        for (const auto& key : config.peer_generations) { nodes.insert(key.node_id); }
        for (const auto& peer : config.peers) { nodes.insert(peer.node_id); }
    }
    if (nodes.size() > maximum_peer_registry_size) { app_fail("CONFIG_PEER_REGISTRY_LIMIT", "at most 64 historical peer slots are supported"); }
    scheduler_nodes_.assign(nodes.begin(), nodes.end());
    active_ = std::make_shared<const RuntimeConfig>(std::move(selected));
}

std::shared_ptr<RuntimeConfiguration::Lease> RuntimeConfiguration::lease() const {
    auto result = std::make_shared<Lease>();
    result->lock = std::shared_lock<std::shared_timed_mutex>(gate_);
    result->config = active_;
    return result;
}
std::shared_ptr<const RuntimeConfig> RuntimeConfiguration::snapshot() const {
    std::shared_lock<std::shared_timed_mutex> lock(gate_);
    return active_;
}
std::vector<std::string> RuntimeConfiguration::scheduler_nodes() const {
    std::shared_lock<std::shared_timed_mutex> lock(gate_);
    return scheduler_nodes_;
}

std::string RuntimeConfiguration::activate(
    NodeState& state, const std::string_view candidate_path,
    const std::string_view rollback_generation, const std::string_view reason,
    const PeerRegistryPreparer& prepare_registry,
    const ConfigurationAdmission& admit) {
    std::lock_guard<std::mutex> activation(activation_mutex_);
    RuntimeConfigurationEvent event{
        .kind = rollback_generation.empty() ? "ACTIVATE" : "ROLLBACK",
        .generation = {}, .digest = {}, .canonical = {}, .unix_ms = now_ms(),
        .actor = "LOCAL_CONTROL", .reason = std::string(reason), .error_code = {},
    };
    bool committed = false;
    bool preparation_authorized = false;
    try {
        {
            std::shared_lock<std::shared_timed_mutex> gate(gate_);
            admit(*active_, ConfigurationAdmissionPhase::prepare, {});
            preparation_authorized = true;
        }
        if (snapshot()->runtime_generation.empty()) {
            app_fail("CONFIG_LIVE_MODE_REQUIRED", "start with an explicit versioned runtime_generation before using live activation");
        }
        RuntimeConfig candidate;
        if (rollback_generation.empty()) {
            candidate = load_runtime_config(std::filesystem::path(candidate_path));
        } else {
            const auto saved = state.snapshot();
            const auto found = std::find_if(saved.configuration_events.begin(), saved.configuration_events.end(),
                [&](const RuntimeConfigurationEvent& item) {
                    return item.kind != "REJECTED" && item.generation == rollback_generation;
                });
            if (found == saved.configuration_events.end()) {
                app_fail("CONFIG_ROLLBACK_NOT_FOUND", "generation was not previously accepted");
            }
            candidate = parse_runtime_config(
                found->canonical,
                "/durable-rollback",
                IdentityFileValidation::deferred);
        }
        if (candidate.runtime_generation.empty()) { app_fail("CONFIG_LIVE_MODE_REQUIRED", "candidate must use a versioned runtime_generation"); }
        event.generation = candidate.runtime_generation;
        event.canonical = canonical_runtime_config(candidate);
        event.digest = runtime_configuration_digest(event.canonical);
        // Validate actual identity files afresh without modifying the SSL_CTX used
        // by other threads. Local key identity cannot change in this slice.
        TlsContext candidate_identity(candidate.identity);
        auto prepared = std::make_shared<const RuntimeConfig>(std::move(candidate));
        // Activation is serialized. Build the historical union and prepare new
        // service resources outside the publication gate, so existing readers
        // and unaffected peers continue while thread creation is in progress.
        const auto previous_nodes = scheduler_nodes();
        std::set<std::string> union_nodes(previous_nodes.begin(), previous_nodes.end());
        for (const auto& key : prepared->peer_generations) { union_nodes.insert(key.node_id); }
        for (const auto& peer : prepared->peers) { union_nodes.insert(peer.node_id); }
        if (union_nodes.size() > maximum_peer_registry_size) {
            app_fail("CONFIG_PEER_REGISTRY_LIMIT", "at most 64 historical peer slots are supported");
        }
        std::vector<std::string> next_nodes(union_nodes.begin(), union_nodes.end());
        std::vector<std::string> additions;
        for (const auto& node : next_nodes) {
            if (!std::binary_search(previous_nodes.begin(), previous_nodes.end(), node)) {
                additions.push_back(node);
            }
        }
        const auto preliminary = snapshot();
        require_owner_boundary(*preliminary, *prepared);
        auto prepared_registry = prepare_registry(additions);
        pause_boundary("NATRAV_OVERLAY_TEST_REGISTRY_AFTER_PREPARE_MS");
        pause_boundary("NATRAV_OVERLAY_TEST_CONFIG_AFTER_VALIDATION_MS");
        std::unique_lock<std::shared_timed_mutex> publication(gate_, std::defer_lock);
        if (!publication.try_lock_for(std::chrono::seconds(5))) {
            app_fail("CONFIG_ACTIVATION_BUSY", "bounded operations did not drain before publication deadline; nothing activated");
        }
        // The serialized preparation can wait behind another activation.
        // Never let authority captured before that wait authorize publication.
        // Lifecycle changes during preparation must also be observed here.
        admit(*active_, ConfigurationAdmissionPhase::prepare, {});
        require_owner_boundary(*active_, *prepared);
        const auto saved = state.snapshot();
        require_capacity(*prepared, saved);
        require_historical_keys(*prepared, saved);
        for (const auto& old : saved.configuration_events) {
            if (old.kind != "REJECTED" && old.generation == event.generation && old.digest != event.digest) {
                app_fail("CONFIG_GENERATION_CONFLICT", "accepted generation ID cannot be redefined");
            }
        }
        const auto current = active_configuration_event(saved.configuration_events);
        if (current != 0U && saved.configuration_events[current - 1U].digest == event.digest) {
            app_fail("CONFIG_ALREADY_ACTIVE", "configuration is already active");
        }
        if (event.kind == "ACTIVATE") {
            for (const auto& old : saved.configuration_events) {
                if (old.kind != "REJECTED" && old.generation == event.generation) {
                    app_fail("CONFIG_GENERATION_ALREADY_ACCEPTED", "use explicit config-rollback for a historical generation");
                }
            }
        }
        const std::string response = "{\"format\":\"NATRAV_OVERLAY_CONFIG_ACTIVATION_V1\",\"ok\":true,\"kind\":" +
            json_string(event.kind) + ",\"generation\":" + json_string(event.generation) +
            ",\"digest\":" + json_string(datacube::hex_lower(event.digest)) + "}";
        const auto after_durable_delay = boundary_delay("NATRAV_OVERLAY_TEST_REGISTRY_AFTER_DURABLE_MS");
        const auto after_commit_delay = boundary_delay("NATRAV_OVERLAY_TEST_CONFIG_AFTER_COMMIT_MS");
        // All fallible resource preparation is complete before this boundary.
        // Parked schedulers cannot run until publish(), and their first lease
        // cannot pass the exclusive gate until config and registry agree.
        pause_boundary("NATRAV_OVERLAY_TEST_REGISTRY_BEFORE_COMMIT_MS");
        admit(*active_, ConfigurationAdmissionPhase::commit, {});
        event.unix_ms = now_ms();
        state.record_runtime_configuration(event);
        committed = true;  // Never relabel a durable acceptance as a rejection.
        pause_prepared_boundary("NATRAV_OVERLAY_TEST_REGISTRY_AFTER_DURABLE_MS", after_durable_delay);
        active_.swap(prepared);
        scheduler_nodes_.swap(next_nodes);
        prepared_registry->publish();
        pause_prepared_boundary("NATRAV_OVERLAY_TEST_CONFIG_AFTER_COMMIT_MS", after_commit_delay);
        return response;
    } catch (const AppError& error) {
        if (committed) { throw; }  // Never relabel a committed activation as rejection.
        // Rejection cannot replace the active generation. Never retain candidate
        // private paths or untrusted file text in the bounded rejection account.
        event.kind = "REJECTED";
        event.canonical.clear();
        event.error_code = error.code();
        // Keep failed-attempt attribution and any rejection event in one
        // accepted generation. Unauthorized waiters never create a candidate
        // configuration event. The callback must not recursively take gate_.
        std::shared_lock<std::shared_timed_mutex> gate(gate_);
        admit(*active_, ConfigurationAdmissionPhase::failure, error.code());
        if (preparation_authorized && !active_->runtime_generation.empty()) {
            state.record_runtime_configuration(event);
        }
        throw;
    }
}
}  // namespace natrav_overlay
