#pragma once
#include "handoff_capsule.hpp"
#include <vector>

namespace natrav_overlay {
inline constexpr std::string_view kHandoffPolicyFeature = "V20_DURABLE_HANDOFF_KEY_POLICY_V1";
inline constexpr std::size_t kHandoffPolicyRecordLimit = 128U;
inline constexpr std::size_t kHandoffPolicyPerNodeLimit = 16U;
enum class HandoffKeyState : std::uint8_t { active = 1U, retired = 2U, revoked = 3U };
struct HandoffKeyPolicyRecord final {
    std::uint64_t sequence{1U};
    datacube::Digest32 predecessor{};
    HandoffBinding binding;
    HandoffKeyState state{HandoffKeyState::active};
};
using HandoffKeyPolicy = std::vector<HandoffKeyPolicyRecord>;
[[nodiscard]] std::string_view handoff_key_state_name(HandoffKeyState state);
// Commitment excludes mutable lifecycle state. The enclosing configuration
// digest authenticates state. Retirement never invalidates a successor's link.
[[nodiscard]] std::string handoff_key_commitment_text(const HandoffKeyPolicyRecord& record);
[[nodiscard]] datacube::Digest32 handoff_key_commitment(const HandoffKeyPolicyRecord& record);
[[nodiscard]] std::string handoff_key_policy_text(const HandoffKeyPolicyRecord& record);
[[nodiscard]] HandoffKeyPolicyRecord parse_handoff_key_policy(std::string_view hex);
void normalize_handoff_key_policy(HandoffKeyPolicy& records);
void require_handoff_key_history_preserved(const HandoffKeyPolicy& historical, const HandoffKeyPolicy& candidate);
// Export needs ACTIVE at both ends. Import permits RETIRED for delayed recovery,
// but never REVOKED; signing-key and application authorization remain additional.
void require_handoff_key_use(const HandoffKeyPolicy& records, const HandoffBinding& binding, bool exporting);
[[nodiscard]] std::string handoff_key_policy_json(const HandoffKeyPolicy& records);
} // namespace natrav_overlay
