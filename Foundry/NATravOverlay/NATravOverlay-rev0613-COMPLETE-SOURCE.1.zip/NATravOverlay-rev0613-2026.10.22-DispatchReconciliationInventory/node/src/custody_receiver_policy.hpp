#pragma once

#include "custody_session_policy.hpp"

#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

inline constexpr std::string_view kCustodyReceiverActivationFeature =
    "V23_PASSIVE_DAEMON_CUSTODY_RECEIVER_V1";
inline constexpr std::size_t kCustodyReceiverActivationLimit = 128U;
inline constexpr std::size_t kCustodyReceiverActivationPerIdLimit = 16U;
inline constexpr std::uint32_t kCustodyReceiverMaximumInflightOffers = 64U;

enum class CustodyReceiverActivationState : std::uint8_t {
    active = 1U,
    retired = 2U,
    revoked = 3U,
};

// A default-off daemon receiver activation. The record grants no sender,
// route-selection, export, retry, discovery, forwarding, or delivery authority.
// It binds one exact retained V22 rule and a finite in-memory concurrency limit.
struct CustodyReceiverActivation final {
    std::string id;
    std::uint64_t generation{1U};
    datacube::Digest32 predecessor;
    CustodyReceiverActivationState state{
        CustodyReceiverActivationState::active};
    std::string session_rule_id;
    std::uint64_t session_rule_generation{1U};
    datacube::Digest32 session_rule_commitment;
    std::uint32_t maximum_inflight_offers{1U};
    std::uint64_t activation_expires_unix_ms{0U};
};

using CustodyReceiverPolicy = std::vector<CustodyReceiverActivation>;

[[nodiscard]] std::string_view custody_receiver_activation_state_name(
    CustodyReceiverActivationState state);
[[nodiscard]] std::string custody_receiver_activation_commitment_text(
    const CustodyReceiverActivation& activation);
[[nodiscard]] datacube::Digest32 custody_receiver_activation_commitment(
    const CustodyReceiverActivation& activation);
[[nodiscard]] std::string custody_receiver_activation_text(
    const CustodyReceiverActivation& activation);
[[nodiscard]] CustodyReceiverActivation parse_custody_receiver_activation(
    std::string_view hex);
void normalize_custody_receiver_policy(CustodyReceiverPolicy& activations);
void require_custody_receiver_history_preserved(
    const CustodyReceiverPolicy& historical,
    const CustodyReceiverPolicy& candidate);
[[nodiscard]] const CustodyReceiverActivation*
find_custody_receiver_activation(
    const CustodyReceiverPolicy& policy,
    std::string_view id,
    std::uint64_t generation) noexcept;
[[nodiscard]] const CustodyReceiverActivation*
find_custody_receiver_activation_for_rule(
    const CustodyReceiverPolicy& policy,
    std::string_view session_rule_id,
    std::uint64_t session_rule_generation) noexcept;
[[nodiscard]] const CustodySessionRule&
resolve_custody_receiver_session_rule(
    const CustodySessionPolicy& rules,
    const CustodyReceiverActivation& activation,
    bool require_active);
[[nodiscard]] std::string custody_receiver_policy_json(
    const CustodyReceiverPolicy& policy);

} // namespace natrav_overlay
