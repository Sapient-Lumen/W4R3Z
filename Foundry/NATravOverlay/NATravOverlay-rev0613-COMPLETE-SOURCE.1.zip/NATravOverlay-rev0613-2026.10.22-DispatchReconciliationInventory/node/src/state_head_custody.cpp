#include "state_head_custody.hpp"

#include "common.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <fcntl.h>
#include <filesystem>
#include <linux/fs.h>
#include <memory>
#include <openssl/rand.h>
#include <string>
#include <string_view>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <thread>
#include <unistd.h>
#include <utility>
#include <vector>

namespace natrav_overlay {
namespace {

inline constexpr std::array<std::uint8_t, 8U> kMagic{
    static_cast<std::uint8_t>('N'), static_cast<std::uint8_t>('H'),
    static_cast<std::uint8_t>('C'), static_cast<std::uint8_t>('U'),
    static_cast<std::uint8_t>('S'), static_cast<std::uint8_t>('T'),
    static_cast<std::uint8_t>('0'), static_cast<std::uint8_t>('1'),
};
inline constexpr std::uint32_t kVersion = 1U;
inline constexpr std::uint64_t kMaximumRecordBytes = 1'024U;
inline constexpr std::size_t kMaximumDomainBytes = 64U;
inline constexpr std::size_t kMaximumFilenameBytes = 128U;
inline constexpr std::string_view kDigestDomain =
    "NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_RECORD_V1";
inline constexpr std::array<std::uint8_t, 8U> kIntentMagic{
    static_cast<std::uint8_t>('N'), static_cast<std::uint8_t>('H'),
    static_cast<std::uint8_t>('C'), static_cast<std::uint8_t>('P'),
    static_cast<std::uint8_t>('I'), static_cast<std::uint8_t>('0'),
    static_cast<std::uint8_t>('0'), static_cast<std::uint8_t>('1'),
};
inline constexpr std::uint32_t kIntentVersion = 1U;
inline constexpr std::uint64_t kMaximumIntentBytes = 16'384U;
inline constexpr std::size_t kMaximumIntentPathBytes = 4'096U;
inline constexpr std::size_t kMaximumRelationshipBytes = 64U;
inline constexpr std::string_view kIntentDigestDomain =
    "NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_INTENT_V1";

struct CustodyRecord final {
    std::string node;
    std::string domain;
    std::uint64_t generation{0U};
    std::string selector;
    StateHeadExpectation head;
    datacube::Digest32 content_digest;
};

struct FileSnapshot final {
    datacube::Octets bytes;
    struct stat status {};
    datacube::Digest32 digest;
};

struct CustodyPath final {
    std::filesystem::path absolute;
    std::string filename;
    datacube::Fd parent;
};

struct IntentPath final {
    std::filesystem::path absolute;
    std::string filename;
    datacube::Fd parent;
};

struct CustodyPromotionIntentRecord final {
    std::filesystem::path custody_path;
    datacube::Octets old_record_bytes;
    datacube::Digest32 old_record_digest;
    CustodyRecord old_record;
    std::uint64_t intended_new_generation{0U};
    StateHeadCustodyPromotionSourceAccount source;
    std::string relationship;
    std::string derived_selector;
    datacube::Digest32 content_digest;
};

struct ProcessCustodyConstraint final {
    CustodyPath path;
    FileSnapshot snapshot;
    CustodyRecord record;
};

std::unique_ptr<ProcessCustodyConstraint> configured_constraint;

[[nodiscard]] bool canonical_domain(const std::string_view value) noexcept {
    if (value.empty() || value.size() > kMaximumDomainBytes) { return false; }
    const auto alnum = [](const char ch) {
        return (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9');
    };
    if (!alnum(value.front()) || !alnum(value.back())) { return false; }
    return std::all_of(value.begin(), value.end(), [&](const char ch) {
        return alnum(ch) || ch == '.' || ch == '_' || ch == '-';
    });
}

void require_domain(const std::string_view value) {
    if (!canonical_domain(value)) {
        app_fail("STATE_HEAD_CUSTODY_DOMAIN_INVALID",
            "custody domain must be 1..64 canonical lowercase ASCII bytes");
    }
}

void reject_dot_dot(const std::filesystem::path& path) {
    if (path.empty()) {
        app_fail("STATE_HEAD_CUSTODY_PATH_INVALID", "explicit custody record path is required");
    }
    for (const auto& component : path) {
        if (component == "..") {
            app_fail("STATE_HEAD_CUSTODY_PATH_INVALID", "dot-dot path components are rejected");
        }
    }
}

[[nodiscard]] bool safe_filename(const std::string_view name) noexcept {
    if (name.empty() || name.size() > kMaximumFilenameBytes || name == "." || name == "..") {
        return false;
    }
    return std::all_of(name.begin(), name.end(), [](const char ch) {
        return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') ||
            (ch >= '0' && ch <= '9') || ch == '.' || ch == '_' || ch == '-';
    });
}

[[nodiscard]] CustodyPath open_custody_path(const std::filesystem::path& input) {
    reject_dot_dot(input);
    const auto absolute = std::filesystem::absolute(input).lexically_normal();
    const auto filename = absolute.filename().string();
    if (!safe_filename(filename)) {
        app_fail("STATE_HEAD_CUSTODY_PATH_INVALID", "custody filename must be bounded safe ASCII");
    }
    auto parent_path = absolute.parent_path();
    if (parent_path.empty()) { parent_path = "/"; }

    datacube::Fd current(::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW));
    if (!current) {
        app_fail("STATE_HEAD_CUSTODY_PARENT_OPEN_FAILED", datacube::errno_detail("/", errno));
    }
    for (const auto& component_path : parent_path.relative_path()) {
        const auto component = component_path.string();
        if (component.empty() || component == ".") { continue; }
        const int next = ::openat(current.get(), component.c_str(),
            O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
        if (next < 0) {
            app_fail("STATE_HEAD_CUSTODY_PARENT_OPEN_FAILED",
                datacube::errno_detail(parent_path.string(), errno));
        }
        current.reset(next);
    }
    struct stat status {};
    if (::fstat(current.get(), &status) != 0 || !S_ISDIR(status.st_mode)) {
        app_fail("STATE_HEAD_CUSTODY_PARENT_INVALID", "custody parent is not a directory");
    }
    if (status.st_uid != ::geteuid() || (status.st_mode & (S_IWGRP | S_IWOTH)) != 0) {
        app_fail("STATE_HEAD_CUSTODY_PARENT_PERMISSIONS_INVALID",
            "custody parent must be owned by the effective user and not writable by group or other");
    }
    return CustodyPath{absolute, filename, std::move(current)};
}

[[nodiscard]] IntentPath open_intent_path(const std::filesystem::path& input) {
    if (input.empty()) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_PATH_INVALID",
            "explicit custody-promotion intent path is required");
    }
    for (const auto& component : input) {
        if (component == "..") {
            app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_PATH_INVALID",
                "custody-promotion intent dot-dot path components are rejected");
        }
    }
    const auto absolute = std::filesystem::absolute(input).lexically_normal();
    const auto filename = absolute.filename().string();
    if (!safe_filename(filename)) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_PATH_INVALID",
            "custody-promotion intent filename must be bounded safe ASCII");
    }
    auto parent_path = absolute.parent_path();
    if (parent_path.empty()) { parent_path = "/"; }

    datacube::Fd current(::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW));
    if (!current) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_PARENT_OPEN_FAILED",
            datacube::errno_detail("/", errno));
    }
    for (const auto& component_path : parent_path.relative_path()) {
        const auto component = component_path.string();
        if (component.empty() || component == ".") { continue; }
        const int next = ::openat(current.get(), component.c_str(),
            O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
        if (next < 0) {
            app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_PARENT_OPEN_FAILED",
                datacube::errno_detail(parent_path.string(), errno));
        }
        current.reset(next);
    }
    struct stat status {};
    if (::fstat(current.get(), &status) != 0 || !S_ISDIR(status.st_mode)) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_PARENT_INVALID",
            "custody-promotion intent parent is not a directory");
    }
    if (status.st_uid != ::geteuid() || (status.st_mode & (S_IWGRP | S_IWOTH)) != 0) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_PARENT_PERMISSIONS_INVALID",
            "intent parent must be owned by the effective user and not writable by group or other");
    }
    return IntentPath{absolute, filename, std::move(current)};
}

void lock_parent(const int fd, const int operation) {
    if (::flock(fd, operation | LOCK_NB) != 0) {
        app_fail(errno == EWOULDBLOCK ? "STATE_HEAD_CUSTODY_BUSY" :
            "STATE_HEAD_CUSTODY_LOCK_FAILED", "custody parent lock is unavailable");
    }
}

void lock_intent_parent(const int fd, const int operation) {
    if (::flock(fd, operation | LOCK_NB) != 0) {
        app_fail(errno == EWOULDBLOCK ?
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_BUSY" :
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_LOCK_FAILED",
            "custody-promotion intent parent lock is unavailable");
    }
}

[[nodiscard]] bool same_directory(const int left, const int right) {
    struct stat left_status {};
    struct stat right_status {};
    if (::fstat(left, &left_status) != 0 || ::fstat(right, &right_status) != 0) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_PARENT_INVALID",
            "cannot compare custody and intent parent identities");
    }
    return left_status.st_dev == right_status.st_dev &&
        left_status.st_ino == right_status.st_ino;
}

[[nodiscard]] bool same_identity(const struct stat& left, const struct stat& right) noexcept {
    return left.st_dev == right.st_dev && left.st_ino == right.st_ino &&
        left.st_uid == right.st_uid && left.st_mode == right.st_mode &&
        left.st_nlink == right.st_nlink && left.st_size == right.st_size &&
        left.st_mtim.tv_sec == right.st_mtim.tv_sec &&
        left.st_mtim.tv_nsec == right.st_mtim.tv_nsec &&
        left.st_ctim.tv_sec == right.st_ctim.tv_sec &&
        left.st_ctim.tv_nsec == right.st_ctim.tv_nsec;
}

[[nodiscard]] bool same_inode_account(
    const struct stat& left, const struct stat& right) noexcept {
    return left.st_dev == right.st_dev && left.st_ino == right.st_ino &&
        left.st_uid == right.st_uid && left.st_mode == right.st_mode &&
        left.st_nlink == right.st_nlink && left.st_size == right.st_size;
}

[[nodiscard]] FileSnapshot read_snapshot_at(
    const int parent, const std::string& name, const std::string_view operation) {
    const int raw = ::openat(parent, name.c_str(),
        O_RDONLY | O_NONBLOCK | O_CLOEXEC | O_NOFOLLOW);
    if (raw < 0) {
        app_fail(errno == ENOENT ? "STATE_HEAD_CUSTODY_NOT_FOUND" :
            "STATE_HEAD_CUSTODY_OPEN_FAILED", datacube::errno_detail(name, errno));
    }
    datacube::Fd fd(raw);
    struct stat before {};
    if (::fstat(fd.get(), &before) != 0) {
        app_fail("STATE_HEAD_CUSTODY_STAT_FAILED", datacube::errno_detail(name, errno));
    }
    if (!S_ISREG(before.st_mode) || before.st_size <= 0 ||
        static_cast<std::uint64_t>(before.st_size) > kMaximumRecordBytes) {
        app_fail("STATE_HEAD_CUSTODY_FILE_INVALID", "custody record must be a bounded regular file");
    }
    if (before.st_uid != ::geteuid() || (before.st_mode & 07777U) != 0600U || before.st_nlink != 1) {
        app_fail("STATE_HEAD_CUSTODY_FILE_PERMISSIONS_INVALID",
            "custody record must be owner-only, singly linked, and owned by the effective user");
    }
    auto bytes = datacube::read_all_fd(fd.get(), kMaximumRecordBytes, std::string(operation));
    struct stat after {};
    if (::fstat(fd.get(), &after) != 0 || !same_identity(before, after) ||
        bytes.size() != static_cast<std::size_t>(before.st_size)) {
        app_fail("STATE_HEAD_CUSTODY_REPLACEMENT_RACE", "custody record changed while being read");
    }
    return FileSnapshot{std::move(bytes), before, datacube::Digest32{}};
}

[[nodiscard]] FileSnapshot read_intent_snapshot_at(
    const int parent, const std::string& name, const std::string_view operation) {
    const int raw = ::openat(parent, name.c_str(),
        O_RDONLY | O_NONBLOCK | O_CLOEXEC | O_NOFOLLOW);
    if (raw < 0) {
        app_fail(errno == ENOENT ?
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_NOT_FOUND" :
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_OPEN_FAILED",
            datacube::errno_detail(name, errno));
    }
    datacube::Fd fd(raw);
    struct stat before {};
    if (::fstat(fd.get(), &before) != 0) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_STAT_FAILED",
            datacube::errno_detail(name, errno));
    }
    if (!S_ISREG(before.st_mode) || before.st_size <= 0 ||
        static_cast<std::uint64_t>(before.st_size) > kMaximumIntentBytes) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_FILE_INVALID",
            "custody-promotion intent must be a bounded regular file");
    }
    if (before.st_uid != ::geteuid() || (before.st_mode & 07777U) != 0600U ||
        before.st_nlink != 1) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_FILE_PERMISSIONS_INVALID",
            "custody-promotion intent must be owner-only, singly linked, and owned by the effective user");
    }
    auto bytes = datacube::read_all_fd(fd.get(), kMaximumIntentBytes,
        std::string(operation));
    struct stat after {};
    if (::fstat(fd.get(), &after) != 0 || !same_identity(before, after) ||
        bytes.size() != static_cast<std::size_t>(before.st_size)) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_REPLACEMENT_RACE",
            "custody-promotion intent changed while being read");
    }
    return FileSnapshot{std::move(bytes), before, datacube::Digest32{}};
}

[[nodiscard]] FileSnapshot finalize_snapshot(FileSnapshot snapshot) {
    snapshot.digest = datacube::sha256(snapshot.bytes);
    if (digest_is_zero(snapshot.digest)) {
        app_fail("STATE_HEAD_CUSTODY_FILE_INVALID", "custody record digest is reserved");
    }
    return snapshot;
}

[[nodiscard]] FileSnapshot finalize_intent_snapshot(FileSnapshot snapshot) {
    snapshot.digest = datacube::sha256(snapshot.bytes);
    if (digest_is_zero(snapshot.digest)) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_FILE_INVALID",
            "custody-promotion intent digest is reserved");
    }
    return snapshot;
}

void append_text16(datacube::Octets& out, const std::string_view value) {
    if (value.empty() || value.size() > 65'535U) {
        app_fail("STATE_HEAD_CUSTODY_RECORD_INVALID", "custody text field is outside its envelope");
    }
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}

[[nodiscard]] std::string read_text16(
    datacube::Reader& reader, const std::size_t maximum, const std::string_view field) {
    const auto size = reader.read_be16(field);
    if (size == 0U || static_cast<std::size_t>(size) > maximum) {
        app_fail("STATE_HEAD_CUSTODY_RECORD_INVALID", "custody text field is outside its envelope");
    }
    const auto bytes = reader.read_exact(size, field);
    return std::string(reinterpret_cast<const char*>(bytes.data()), bytes.size());
}

[[nodiscard]] datacube::Digest32 content_digest(const datacube::OctetView body) {
    datacube::Octets material;
    material.reserve(kDigestDomain.size() + 1U + body.size());
    datacube::append_text(material, kDigestDomain);
    datacube::append_u8(material, 0U);
    datacube::append_octets(material, body);
    return datacube::sha256(material);
}

void append_optional_text16(datacube::Octets& out,
    const std::optional<std::string>& value) {
    if (!value) {
        datacube::append_be16(out, 0U);
        return;
    }
    if (value->empty() || value->size() > 65'535U) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "optional intent text is outside its canonical envelope");
    }
    datacube::append_be16(out, static_cast<std::uint16_t>(value->size()));
    datacube::append_text(out, *value);
}

[[nodiscard]] std::optional<std::string> read_optional_text16(
    datacube::Reader& reader, const std::size_t maximum,
    const std::string_view field) {
    const auto size = reader.read_be16(field);
    if (size == 0U) { return std::nullopt; }
    if (static_cast<std::size_t>(size) > maximum) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "optional intent text exceeds its canonical envelope");
    }
    const auto bytes = reader.read_exact(size, field);
    return std::string(reinterpret_cast<const char*>(bytes.data()), bytes.size());
}

void append_digest(datacube::Octets& out, const datacube::Digest32& value) {
    datacube::append_octets(out, value.octets);
}

[[nodiscard]] datacube::Digest32 read_digest(
    datacube::Reader& reader, const std::string_view field) {
    const auto bytes = reader.read_exact(32U, field);
    datacube::Digest32 value;
    std::copy(bytes.begin(), bytes.end(), value.octets.begin());
    return value;
}

void append_optional_digest(datacube::Octets& out,
    const std::optional<datacube::Digest32>& value) {
    append_digest(out, value.value_or(datacube::Digest32{}));
}

[[nodiscard]] std::optional<datacube::Digest32> read_optional_digest(
    datacube::Reader& reader, const std::string_view field) {
    auto value = read_digest(reader, field);
    if (digest_is_zero(value)) { return std::nullopt; }
    return value;
}

[[nodiscard]] datacube::Digest32 intent_content_digest(
    const datacube::OctetView body) {
    datacube::Octets material;
    material.reserve(kIntentDigestDomain.size() + 1U + body.size());
    datacube::append_text(material, kIntentDigestDomain);
    datacube::append_u8(material, 0U);
    datacube::append_octets(material, body);
    return datacube::sha256(material);
}

[[nodiscard]] std::string source_kind_text(
    const StateHeadCustodyPromotionSourceKind kind) {
    switch (kind) {
        case StateHeadCustodyPromotionSourceKind::state_directory:
            return "STATE_DIRECTORY";
        case StateHeadCustodyPromotionSourceKind::signed_encrypted_backup:
            return "SIGNED_ENCRYPTED_BACKUP";
    }
    app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
        "unknown custody-promotion source kind");
}

void require_canonical_intent_path(const std::filesystem::path& value,
    const std::string_view field) {
    const auto text = value.string();
    if (text.empty() || text.size() > kMaximumIntentPathBytes ||
        !value.is_absolute() || value.lexically_normal() != value) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            std::string(field) + " must be an absolute canonical bounded path");
    }
}

void validate_source_account(
    const StateHeadCustodyPromotionSourceAccount& source) {
    require_canonical_intent_path(source.canonical_path, "intent source path");
    if (source.representation_bytes == 0U || source.authenticated_bytes == 0U ||
        digest_is_zero(source.representation_digest) ||
        digest_is_zero(source.authenticated_digest) ||
        digest_is_zero(source.logical_state_digest)) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "intent source account is incomplete");
    }
    switch (source.kind) {
        case StateHeadCustodyPromotionSourceKind::state_directory:
            if (source.identity_generation || source.backup_id ||
                source.signer_spki_sha256 || source.encryption_key_generation ||
                source.encryption_key_id) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
                    "state-directory intent source contains backup-only identity fields");
            }
            if (source.authenticated_bytes != source.representation_bytes ||
                source.authenticated_digest != source.representation_digest) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
                    "state-directory intent must bind the exact authenticated journal representation");
            }
            break;
        case StateHeadCustodyPromotionSourceKind::signed_encrypted_backup:
            if (!source.identity_generation || source.identity_generation->empty() ||
                source.identity_generation->size() > 128U || !source.backup_id ||
                !source.signer_spki_sha256 || !source.encryption_key_generation ||
                source.encryption_key_generation->empty() ||
                source.encryption_key_generation->size() > 128U ||
                !source.encryption_key_id || digest_is_zero(*source.backup_id) ||
                digest_is_zero(*source.signer_spki_sha256) ||
                digest_is_zero(*source.encryption_key_id)) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
                    "signed encrypted backup intent source lacks exact trust identities");
            }
            break;
        default:
            app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
                "unknown custody-promotion source kind");
    }
}

[[nodiscard]] bool same_source_account(
    const StateHeadCustodyPromotionSourceAccount& left,
    const StateHeadCustodyPromotionSourceAccount& right) noexcept {
    return left.kind == right.kind && left.canonical_path == right.canonical_path &&
        left.representation_bytes == right.representation_bytes &&
        left.representation_digest == right.representation_digest &&
        left.authenticated_bytes == right.authenticated_bytes &&
        left.authenticated_digest == right.authenticated_digest &&
        left.logical_state_digest == right.logical_state_digest &&
        left.identity_generation == right.identity_generation &&
        left.backup_id == right.backup_id &&
        left.signer_spki_sha256 == right.signer_spki_sha256 &&
        left.encryption_key_generation == right.encryption_key_generation &&
        left.encryption_key_id == right.encryption_key_id;
}

[[nodiscard]] std::string source_account_json(
    const StateHeadCustodyPromotionSourceAccount& source) {
    validate_source_account(source);
    return std::string("{\"kind\":") + json_string(source_kind_text(source.kind)) +
        ",\"canonical_path\":" + json_string(source.canonical_path.string()) +
        ",\"representation_bytes\":" + std::to_string(source.representation_bytes) +
        ",\"representation_sha256\":" +
        json_string(datacube::hex_lower(source.representation_digest)) +
        ",\"authenticated_bytes\":" + std::to_string(source.authenticated_bytes) +
        ",\"authenticated_sha256\":" +
        json_string(datacube::hex_lower(source.authenticated_digest)) +
        ",\"logical_state_digest\":" +
        json_string(datacube::hex_lower(source.logical_state_digest)) +
        ",\"identity_generation\":" +
        (source.identity_generation ? json_string(*source.identity_generation) :
            std::string("null")) +
        ",\"backup_id\":" +
        (source.backup_id ? json_string(datacube::hex_lower(*source.backup_id)) :
            std::string("null")) +
        ",\"signer_spki_sha256\":" +
        (source.signer_spki_sha256 ?
            json_string(datacube::hex_lower(*source.signer_spki_sha256)) :
            std::string("null")) +
        ",\"encryption_key_generation\":" +
        (source.encryption_key_generation ?
            json_string(*source.encryption_key_generation) : std::string("null")) +
        ",\"encryption_key_id\":" +
        (source.encryption_key_id ?
            json_string(datacube::hex_lower(*source.encryption_key_id)) :
            std::string("null")) + "}";
}

[[nodiscard]] datacube::Octets encode_record(
    const std::string_view node, const std::string_view domain,
    const std::uint64_t generation, const std::string_view selector) {
    require_node_id(node, "custody node");
    require_domain(domain);
    if (generation == 0U) {
        app_fail("STATE_HEAD_CUSTODY_GENERATION_INVALID", "custody generation must be positive");
    }
    const auto head = parse_state_head_expectation(selector);
    if (head.node != node) {
        app_fail("STATE_HEAD_CUSTODY_HEAD_MISMATCH", "custody node and NASH1 node differ");
    }
    datacube::Octets out;
    out.reserve(128U + selector.size());
    datacube::append_octets(out, kMagic);
    datacube::append_be32(out, kVersion);
    append_text16(out, node);
    append_text16(out, domain);
    datacube::append_be64(out, generation);
    append_text16(out, selector);
    const auto digest = content_digest(out);
    datacube::append_octets(out, digest.octets);
    if (out.size() > kMaximumRecordBytes) {
        app_fail("STATE_HEAD_CUSTODY_RECORD_INVALID", "custody record exceeds its fixed size ceiling");
    }
    return out;
}

[[nodiscard]] CustodyRecord decode_record(const datacube::OctetView bytes) {
    if (bytes.empty() || bytes.size() > kMaximumRecordBytes) {
        app_fail("STATE_HEAD_CUSTODY_RECORD_INVALID", "custody record is empty or oversized");
    }
    datacube::Reader reader(bytes, "detached state-head custody record");
    const auto magic = reader.read_exact(kMagic.size(), "custody magic");
    if (!std::equal(kMagic.begin(), kMagic.end(), magic.begin())) {
        app_fail("STATE_HEAD_CUSTODY_RECORD_INVALID", "custody record magic mismatch");
    }
    if (reader.read_be32("custody version") != kVersion) {
        app_fail("STATE_HEAD_CUSTODY_RECORD_INVALID", "unknown custody record version");
    }
    auto node = read_text16(reader, 64U, "custody node");
    auto domain = read_text16(reader, kMaximumDomainBytes, "custody domain");
    const auto generation = reader.read_be64("custody generation");
    auto selector = read_text16(reader, 512U, "custody state head");
    const auto digest_bytes = reader.read_exact(32U, "custody content digest");
    reader.require_eof("custody record");
    datacube::Digest32 stored;
    std::copy(digest_bytes.begin(), digest_bytes.end(), stored.octets.begin());

    require_node_id(node, "custody node");
    require_domain(domain);
    if (generation == 0U) {
        app_fail("STATE_HEAD_CUSTODY_GENERATION_INVALID", "custody generation must be positive");
    }
    auto head = parse_state_head_expectation(selector);
    if (head.node != node) {
        app_fail("STATE_HEAD_CUSTODY_HEAD_MISMATCH", "custody node and NASH1 node differ");
    }
    const auto expected = encode_record(node, domain, generation, selector);
    if (expected.size() != bytes.size() || !std::equal(expected.begin(), expected.end(), bytes.begin())) {
        app_fail("STATE_HEAD_CUSTODY_RECORD_INVALID", "custody record is malformed or noncanonical");
    }
    const auto calculated = content_digest(bytes.first(bytes.size() - stored.octets.size()));
    if (calculated != stored) {
        app_fail("STATE_HEAD_CUSTODY_RECORD_INVALID", "custody content digest mismatch");
    }
    return CustodyRecord{std::move(node), std::move(domain), generation,
        std::move(selector), std::move(head), stored};
}

[[nodiscard]] bool valid_successor_relationship(
    const std::string_view relationship) noexcept {
    return relationship == "VERIFIED_APPEND_ONLY_EXTENSION" ||
        relationship == "VERIFIED_AUTHENTICATED_CHECKPOINT_SUCCESSOR";
}

[[nodiscard]] datacube::Octets encode_intent_record(
    const std::filesystem::path& custody_path,
    const datacube::OctetView old_record_bytes,
    const datacube::Digest32& old_record_digest,
    const std::uint64_t intended_new_generation,
    const StateHeadCustodyPromotionSourceAccount& source,
    const std::string_view relationship,
    const std::string_view derived_selector) {
    require_canonical_intent_path(custody_path, "intent custody path");
    if (old_record_bytes.empty() || old_record_bytes.size() > kMaximumRecordBytes ||
        old_record_bytes.size() > 65'535U ||
        datacube::sha256(old_record_bytes) != old_record_digest ||
        digest_is_zero(old_record_digest)) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "intent old custody representation is incomplete or inconsistent");
    }
    const auto old_record = decode_record(old_record_bytes);
    if (intended_new_generation <= old_record.generation) {
        app_fail("STATE_HEAD_CUSTODY_GENERATION_INVALID",
            "intent generation must be strictly greater than the exact old generation");
    }
    validate_source_account(source);
    if (!valid_successor_relationship(relationship)) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "intent successor relationship is not a verified supported relation");
    }
    const auto derived = parse_state_head_expectation(derived_selector);
    if (derived.node != old_record.node || derived_selector == old_record.selector ||
        derived.journal_bytes != source.authenticated_bytes) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "intent derived head is inconsistent with its old custody or source account");
    }

    datacube::Octets out;
    out.reserve(512U + custody_path.string().size() + old_record_bytes.size() +
        source.canonical_path.string().size() + derived_selector.size());
    datacube::append_octets(out, kIntentMagic);
    datacube::append_be32(out, kIntentVersion);
    append_text16(out, custody_path.string());
    datacube::append_be16(out,
        static_cast<std::uint16_t>(old_record_bytes.size()));
    datacube::append_octets(out, old_record_bytes);
    append_digest(out, old_record_digest);
    datacube::append_be64(out, intended_new_generation);
    datacube::append_u8(out, static_cast<std::uint8_t>(source.kind));
    append_text16(out, source.canonical_path.string());
    datacube::append_be64(out, source.representation_bytes);
    append_digest(out, source.representation_digest);
    datacube::append_be64(out, source.authenticated_bytes);
    append_digest(out, source.authenticated_digest);
    append_digest(out, source.logical_state_digest);
    append_optional_text16(out, source.identity_generation);
    append_optional_digest(out, source.backup_id);
    append_optional_digest(out, source.signer_spki_sha256);
    append_optional_text16(out, source.encryption_key_generation);
    append_optional_digest(out, source.encryption_key_id);
    append_text16(out, relationship);
    append_text16(out, derived_selector);
    const auto commitment = intent_content_digest(out);
    append_digest(out, commitment);
    if (out.size() > kMaximumIntentBytes) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "custody-promotion intent exceeds its fixed size ceiling");
    }
    return out;
}

[[nodiscard]] CustodyPromotionIntentRecord decode_intent_record(
    const datacube::OctetView bytes) {
    if (bytes.empty() || bytes.size() > kMaximumIntentBytes) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "custody-promotion intent is empty or oversized");
    }
    datacube::Reader reader(bytes, "detached custody-promotion intent");
    const auto magic = reader.read_exact(kIntentMagic.size(), "intent magic");
    if (!std::equal(kIntentMagic.begin(), kIntentMagic.end(), magic.begin())) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "custody-promotion intent magic mismatch");
    }
    if (reader.read_be32("intent version") != kIntentVersion) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "unknown custody-promotion intent version");
    }
    const auto custody_path_text = read_text16(reader, kMaximumIntentPathBytes,
        "intent custody path");
    std::filesystem::path custody_path(custody_path_text);
    const auto old_size = reader.read_be16("intent old custody bytes");
    if (old_size == 0U || static_cast<std::uint64_t>(old_size) > kMaximumRecordBytes) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "intent old custody record size is outside its envelope");
    }
    const auto old_view = reader.read_exact(old_size, "intent old custody record");
    datacube::Octets old_bytes(old_view.begin(), old_view.end());
    const auto old_digest = read_digest(reader, "intent old custody digest");
    const auto new_generation = reader.read_be64("intent new generation");
    const auto raw_kind = reader.read_u8("intent source kind");
    StateHeadCustodyPromotionSourceAccount source;
    if (raw_kind == static_cast<std::uint8_t>(
            StateHeadCustodyPromotionSourceKind::state_directory)) {
        source.kind = StateHeadCustodyPromotionSourceKind::state_directory;
    } else if (raw_kind == static_cast<std::uint8_t>(
            StateHeadCustodyPromotionSourceKind::signed_encrypted_backup)) {
        source.kind = StateHeadCustodyPromotionSourceKind::signed_encrypted_backup;
    } else {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "unknown custody-promotion intent source kind");
    }
    source.canonical_path = std::filesystem::path(read_text16(reader,
        kMaximumIntentPathBytes, "intent source path"));
    source.representation_bytes = reader.read_be64("intent representation bytes");
    source.representation_digest = read_digest(reader,
        "intent representation digest");
    source.authenticated_bytes = reader.read_be64("intent authenticated bytes");
    source.authenticated_digest = read_digest(reader,
        "intent authenticated digest");
    source.logical_state_digest = read_digest(reader,
        "intent logical state digest");
    source.identity_generation = read_optional_text16(reader, 128U,
        "intent identity generation");
    source.backup_id = read_optional_digest(reader, "intent backup id");
    source.signer_spki_sha256 = read_optional_digest(reader,
        "intent signer identity");
    source.encryption_key_generation = read_optional_text16(reader, 128U,
        "intent encryption generation");
    source.encryption_key_id = read_optional_digest(reader,
        "intent encryption key identity");
    auto relationship = read_text16(reader, kMaximumRelationshipBytes,
        "intent successor relationship");
    auto derived_selector = read_text16(reader, 512U,
        "intent derived state head");
    const auto stored_commitment = read_digest(reader, "intent content digest");
    reader.require_eof("custody-promotion intent");

    const auto old_record = decode_record(old_bytes);
    const auto expected = encode_intent_record(custody_path, old_bytes, old_digest,
        new_generation, source, relationship, derived_selector);
    if (expected.size() != bytes.size() ||
        !std::equal(expected.begin(), expected.end(), bytes.begin())) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "custody-promotion intent is malformed or noncanonical");
    }
    const auto calculated_commitment = intent_content_digest(
        bytes.first(bytes.size() - stored_commitment.octets.size()));
    if (calculated_commitment != stored_commitment) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "custody-promotion intent content digest mismatch");
    }
    return CustodyPromotionIntentRecord{
        .custody_path = std::move(custody_path),
        .old_record_bytes = std::move(old_bytes),
        .old_record_digest = old_digest,
        .old_record = old_record,
        .intended_new_generation = new_generation,
        .source = std::move(source),
        .relationship = std::move(relationship),
        .derived_selector = std::move(derived_selector),
        .content_digest = stored_commitment,
    };
}

void enforce_expectation(const StateHeadCustodyExpectation& expected,
    const CustodyRecord& record, const datacube::Digest32& digest,
    const bool require_complete) {
    if (expected.node) { require_node_id(*expected.node, "expected custody node"); }
    if (expected.domain) { require_domain(*expected.domain); }
    if (expected.generation && *expected.generation == 0U) {
        app_fail("STATE_HEAD_CUSTODY_GENERATION_INVALID", "expected custody generation must be positive");
    }
    if (expected.state_head) {
        const auto parsed = parse_state_head_expectation(*expected.state_head);
        if (expected.node && parsed.node != *expected.node) {
            app_fail("STATE_HEAD_CUSTODY_EXPECTATION_INVALID",
                "expected custody node and expected NASH1 node differ");
        }
    }
    if (require_complete && (!expected.node || !expected.domain ||
        !expected.generation || !expected.state_head || !expected.record_digest)) {
        app_fail("STATE_HEAD_CUSTODY_EXPECTATION_REQUIRED",
            "compare-and-swap requires exact old node, domain, generation, head, and record digest");
    }
#if defined(NATRAV_CUSTODY_OMIT_RECORD_DIGEST_EXPECTATION)
    static_cast<void>(digest);
    const bool digest_mismatch = false;
#else
    const bool digest_mismatch =
        expected.record_digest && *expected.record_digest != digest;
#endif
    if ((expected.node && *expected.node != record.node) ||
        (expected.domain && *expected.domain != record.domain) ||
        (expected.generation && *expected.generation != record.generation) ||
        (expected.state_head && *expected.state_head != record.selector) ||
        digest_mismatch) {
        app_fail("STATE_HEAD_CUSTODY_EXPECTATION_MISMATCH",
            "detached custody record differs from the explicitly supplied exact old account");
    }
}

[[nodiscard]] std::string record_account_json(
    const CustodyRecord& record,
    const datacube::OctetView bytes,
    const datacube::Digest32& digest) {
    return std::string("{\"format\":\"NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_RECORD_V1\"") +
        ",\"node\":" + json_string(record.node) +
        ",\"custody_domain\":" + json_string(record.domain) +
        ",\"custody_generation\":" + std::to_string(record.generation) +
        ",\"state_head\":{\"selector\":" + json_string(record.selector) +
        ",\"node\":" + json_string(record.head.node) +
        ",\"authentication_generation\":" + json_string(record.head.generation) +
        ",\"key_id\":" + json_string(datacube::hex_lower(record.head.key_id)) +
        ",\"epoch\":" + json_string(datacube::hex_lower(record.head.epoch)) +
        ",\"root\":" + json_string(datacube::hex_lower(record.head.root)) +
        ",\"records\":" + std::to_string(record.head.records) +
        ",\"journal_bytes\":" + std::to_string(record.head.journal_bytes) + "}" +
        ",\"content_digest\":" + json_string(datacube::hex_lower(record.content_digest)) +
        ",\"record_digest\":" + json_string(datacube::hex_lower(digest)) +
        ",\"record_bytes\":" + std::to_string(bytes.size()) +
        ",\"freshness\":\"CUSTODIAN_EXPLICIT_UPDATE_DISCIPLINE_ONLY\"," +
        "\"automatic_update\":false}";
}

[[nodiscard]] std::string record_json(
    const CustodyRecord& record, const FileSnapshot& file) {
    const auto mode = static_cast<unsigned>(file.status.st_mode & 07777U);
    return std::string("{\"format\":\"NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_RECORD_V1\"") +
        ",\"node\":" + json_string(record.node) +
        ",\"custody_domain\":" + json_string(record.domain) +
        ",\"custody_generation\":" + std::to_string(record.generation) +
        ",\"state_head\":{\"selector\":" + json_string(record.selector) +
        ",\"node\":" + json_string(record.head.node) +
        ",\"authentication_generation\":" + json_string(record.head.generation) +
        ",\"key_id\":" + json_string(datacube::hex_lower(record.head.key_id)) +
        ",\"epoch\":" + json_string(datacube::hex_lower(record.head.epoch)) +
        ",\"root\":" + json_string(datacube::hex_lower(record.head.root)) +
        ",\"records\":" + std::to_string(record.head.records) +
        ",\"journal_bytes\":" + std::to_string(record.head.journal_bytes) + "}" +
        ",\"content_digest\":" + json_string(datacube::hex_lower(record.content_digest)) +
        ",\"record_digest\":" + json_string(datacube::hex_lower(file.digest)) +
        ",\"record_bytes\":" + std::to_string(file.bytes.size()) +
        ",\"file_identity\":{\"device\":" +
        std::to_string(static_cast<std::uintmax_t>(file.status.st_dev)) +
        ",\"inode\":" + std::to_string(static_cast<std::uintmax_t>(file.status.st_ino)) +
        ",\"uid\":" + std::to_string(static_cast<std::uintmax_t>(file.status.st_uid)) +
        ",\"mode\":" + json_string(mode == 0600U ? "0600" : "INVALID") +
        ",\"links\":" + std::to_string(static_cast<std::uintmax_t>(file.status.st_nlink)) + "}" +
        ",\"freshness\":\"CUSTODIAN_EXPLICIT_UPDATE_DISCIPLINE_ONLY\",\"automatic_update\":false}";
}

[[nodiscard]] std::string intent_account_json(
    const CustodyPromotionIntentRecord& intent,
    const FileSnapshot& file) {
    const auto mode = static_cast<unsigned>(file.status.st_mode & 07777U);
    return std::string("{\"format\":\"NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_INTENT_V1\"") +
        ",\"custody_path\":" + json_string(intent.custody_path.string()) +
        ",\"old_record\":" + record_account_json(intent.old_record,
            intent.old_record_bytes, intent.old_record_digest) +
        ",\"intended_new_generation\":" +
        std::to_string(intent.intended_new_generation) +
        ",\"source_account\":" + source_account_json(intent.source) +
        ",\"relationship\":" + json_string(intent.relationship) +
        ",\"derived_state_head\":" + json_string(intent.derived_selector) +
        ",\"content_commitment\":" +
        json_string(datacube::hex_lower(intent.content_digest)) +
        ",\"file_digest\":" + json_string(datacube::hex_lower(file.digest)) +
        ",\"file_bytes\":" + std::to_string(file.bytes.size()) +
        ",\"file_identity\":{\"device\":" +
        std::to_string(static_cast<std::uintmax_t>(file.status.st_dev)) +
        ",\"inode\":" + std::to_string(static_cast<std::uintmax_t>(file.status.st_ino)) +
        ",\"uid\":" + std::to_string(static_cast<std::uintmax_t>(file.status.st_uid)) +
        ",\"mode\":" + json_string(mode == 0600U ? "0600" : "INVALID") +
        ",\"links\":" + std::to_string(static_cast<std::uintmax_t>(file.status.st_nlink)) + "}" +
        ",\"authority\":\"NONE_REVALIDATION_REQUIRED\"," +
        "\"automatic_discovery\":false,\"automatic_promotion\":false," +
        "\"response_receipt\":false,\"global_latestness\":false}";
}

[[nodiscard]] std::string random_stage_name(const std::string_view filename) {
    std::array<std::uint8_t, 12U> random{};
    if (RAND_bytes(random.data(), static_cast<int>(random.size())) != 1) {
        app_fail("STATE_HEAD_CUSTODY_RANDOM_FAILED", "cannot generate custody staging name");
    }
    return "." + std::string(filename) + ".custody-" + hex_bytes(random) + ".tmp";
}

void write_all(const int fd, const datacube::OctetView bytes) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto count = ::write(fd, bytes.data() + offset, bytes.size() - offset);
        if (count < 0 && errno == EINTR) { continue; }
        if (count <= 0) {
            app_fail("STATE_HEAD_CUSTODY_WRITE_FAILED", "custody staging write made no progress");
        }
        offset += static_cast<std::size_t>(count);
    }
}

struct Stage final {
    int parent{-1};
    std::string name;
    datacube::Fd fd;
    bool exchanged{false};
    Stage(const int parent_fd, std::string stage_name, const datacube::OctetView bytes)
        : parent(parent_fd), name(std::move(stage_name)) {
        const int raw = ::openat(parent, name.c_str(),
            O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0600);
        if (raw < 0) {
            app_fail("STATE_HEAD_CUSTODY_STAGE_CREATE_FAILED", datacube::errno_detail(name, errno));
        }
        fd.reset(raw);
        try {
            if (::fchmod(fd.get(), 0600) != 0) {
                app_fail("STATE_HEAD_CUSTODY_STAGE_MODE_FAILED", datacube::errno_detail(name, errno));
            }
            write_all(fd.get(), bytes);
            if (::fsync(fd.get()) != 0) {
                app_fail("STATE_HEAD_CUSTODY_STAGE_SYNC_FAILED", datacube::errno_detail(name, errno));
            }
            if (::lseek(fd.get(), 0, SEEK_SET) < 0) {
                app_fail("STATE_HEAD_CUSTODY_STAGE_VERIFY_FAILED", datacube::errno_detail(name, errno));
            }
            const auto actual = datacube::read_all_fd(fd.get(), kMaximumRecordBytes, name);
            if (actual.size() != bytes.size() || !std::equal(actual.begin(), actual.end(), bytes.begin())) {
                app_fail("STATE_HEAD_CUSTODY_STAGE_VERIFY_FAILED", "custody staging bytes differ from candidate");
            }
        } catch (...) {
            static_cast<void>(::unlinkat(parent, name.c_str(), 0));
            throw;
        }
    }
    ~Stage() {
        if (!name.empty() && !exchanged) {
            static_cast<void>(::unlinkat(parent, name.c_str(), 0));
        }
    }
};

[[nodiscard]] std::string random_intent_stage_name(
    const std::string_view filename) {
    std::array<std::uint8_t, 12U> random{};
    if (RAND_bytes(random.data(), static_cast<int>(random.size())) != 1) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_RANDOM_FAILED",
            "cannot generate custody-promotion intent staging name");
    }
    return "." + std::string(filename) + ".promotion-intent-" +
        hex_bytes(random) + ".tmp";
}

void write_all_intent(const int fd, const datacube::OctetView bytes) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto count = ::write(fd, bytes.data() + offset,
            bytes.size() - offset);
        if (count < 0 && errno == EINTR) { continue; }
        if (count <= 0) {
            app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_WRITE_FAILED",
                "custody-promotion intent staging write made no progress");
        }
        offset += static_cast<std::size_t>(count);
    }
}

struct IntentStage final {
    int parent{-1};
    std::string name;
    datacube::Fd fd;
    explicit IntentStage(const int parent_fd, std::string stage_name,
        const datacube::OctetView bytes)
        : parent(parent_fd), name(std::move(stage_name)) {
        const int raw = ::openat(parent, name.c_str(),
            O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0600);
        if (raw < 0) {
            app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_STAGE_CREATE_FAILED",
                datacube::errno_detail(name, errno));
        }
        fd.reset(raw);
        try {
            if (::fchmod(fd.get(), 0600) != 0) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_STAGE_MODE_FAILED",
                    datacube::errno_detail(name, errno));
            }
            write_all_intent(fd.get(), bytes);
            if (::fsync(fd.get()) != 0) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_STAGE_SYNC_FAILED",
                    datacube::errno_detail(name, errno));
            }
            if (::lseek(fd.get(), 0, SEEK_SET) < 0) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_STAGE_VERIFY_FAILED",
                    datacube::errno_detail(name, errno));
            }
            const auto actual = datacube::read_all_fd(fd.get(),
                kMaximumIntentBytes, name);
            if (actual.size() != bytes.size() ||
                !std::equal(actual.begin(), actual.end(), bytes.begin())) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_STAGE_VERIFY_FAILED",
                    "custody-promotion intent staging bytes differ from candidate");
            }
        } catch (...) {
            static_cast<void>(::unlinkat(parent, name.c_str(), 0));
            throw;
        }
    }
    ~IntentStage() {
        if (!name.empty()) {
            static_cast<void>(::unlinkat(parent, name.c_str(), 0));
        }
    }
};

void sync_parent(const int parent, const std::string_view code) {
    if (::fsync(parent) != 0) {
        app_fail(code, "custody parent directory synchronization failed");
    }
}

void test_pause_before_recheck() {
    if (const char* raw = std::getenv("NATRAV_OVERLAY_TEST_CUSTODY_PAUSE_BEFORE_RECHECK_MS")) {
        const auto delay = parse_u64(raw, "custody test pause", 1U, 10'000U);
        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    }
}

void maybe_fail_before_publish() {
    if (const char* raw = std::getenv("NATRAV_OVERLAY_TEST_CUSTODY_FAIL_BEFORE_PUBLISH")) {
        if (std::string_view(raw) == "yes") {
            app_fail("STATE_HEAD_CUSTODY_TEST_PREPUBLICATION_FAILURE",
                "injected custody failure before atomic publication");
        }
    }
}

void test_pause_after_create_publication() {
    if (const char* raw = std::getenv(
            "NATRAV_OVERLAY_TEST_CUSTODY_PAUSE_AFTER_CREATE_PUBLISH_MS")) {
        const auto delay = parse_u64(raw, "custody create publication test pause", 1U, 10'000U);
        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    }
}

void test_pause_constraint_recheck(const StateHeadCustodyRecheckPoint point) {
    const char* variable = nullptr;
    std::string_view field;
    switch (point) {
        case StateHeadCustodyRecheckPoint::authenticated_input:
            variable = "NATRAV_OVERLAY_TEST_CUSTODY_CONSTRAINT_PAUSE_INPUT_MS";
            field = "custody input recheck pause";
            break;
        case StateHeadCustodyRecheckPoint::successful_command:
            variable = "NATRAV_OVERLAY_TEST_CUSTODY_CONSTRAINT_PAUSE_FINAL_MS";
            field = "custody final recheck pause";
            break;
        case StateHeadCustodyRecheckPoint::startup_acceptance:
            variable = "NATRAV_OVERLAY_TEST_CUSTODY_CONSTRAINT_PAUSE_STARTUP_MS";
            field = "custody startup recheck pause";
            break;
    }
    if (const char* raw = std::getenv(variable)) {
        const auto delay = parse_u64(raw, field, 1U, 10'000U);
        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    }
}

void test_pause_promotion_audit_final_recheck() {
    if (const char* raw = std::getenv(
            "NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_AUDIT_PAUSE_FINAL_MS")) {
        const auto delay = parse_u64(raw,
            "custody promotion audit final recheck pause", 1U, 10'000U);
        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    }
}

void test_pause_intent_creation_final_recheck() {
    if (const char* raw = std::getenv(
            "NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_INTENT_PAUSE_CREATE_MS")) {
        const auto delay = parse_u64(raw,
            "custody promotion intent creation pause", 1U, 10'000U);
        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    }
}

void test_pause_intent_consumption_final_recheck() {
    if (const char* raw = std::getenv(
            "NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_INTENT_PAUSE_CONSUME_MS")) {
        const auto delay = parse_u64(raw,
            "custody promotion intent consumption pause", 1U, 10'000U);
        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    }
}

[[nodiscard]] FileSnapshot recheck_exact(
    const CustodyPath& path, const FileSnapshot& original) {
    auto current = finalize_snapshot(read_snapshot_at(
        path.parent.get(), path.filename, "custody exact recheck"));
    if (!same_identity(original.status, current.status) ||
        current.digest != original.digest || current.bytes != original.bytes) {
        app_fail("STATE_HEAD_CUSTODY_REPLACEMENT_RACE",
            "custody record path no longer identifies the exact old file");
    }
    return current;
}

[[nodiscard]] FileSnapshot recheck_intent_exact(
    const IntentPath& path, const FileSnapshot& original) {
    auto current = finalize_intent_snapshot(read_intent_snapshot_at(
        path.parent.get(), path.filename,
        "custody-promotion intent exact recheck"));
    if (!same_identity(original.status, current.status) ||
        current.digest != original.digest || current.bytes != original.bytes) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_REPLACEMENT_RACE",
            "custody-promotion intent path no longer identifies the exact input file");
    }
    return current;
}

[[nodiscard]] std::string response_prefix(
    const std::string_view operation, const CustodyPath& path) {
    return std::string("{\"format\":\"NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_V1\",\"ok\":true") +
        ",\"operation\":" + json_string(operation) +
        ",\"path\":" + json_string(path.absolute.string());
}

struct PublishedRecord final {
    FileSnapshot snapshot;
    CustodyRecord record;
};

[[nodiscard]] PublishedRecord publish_replacement(
    const CustodyPath& path,
    const FileSnapshot& original,
    const CustodyRecord& previous,
    const std::uint64_t new_generation,
    const std::string_view new_selector,
    const std::function<void()>& prepublication_recheck) {
    const auto replacement_bytes = encode_record(previous.node, previous.domain,
        new_generation, new_selector);
    Stage stage(path.parent.get(), random_stage_name(path.filename), replacement_bytes);

    test_pause_before_recheck();
    static_cast<void>(recheck_exact(path, original));
    if (prepublication_recheck) { prepublication_recheck(); }
    maybe_fail_before_publish();
    if (::syscall(SYS_renameat2, path.parent.get(), stage.name.c_str(),
            path.parent.get(), path.filename.c_str(), RENAME_EXCHANGE) != 0) {
        app_fail("STATE_HEAD_CUSTODY_PUBLISH_FAILED",
            "atomic custody exchange failed");
    }
    stage.exchanged = true;

    auto displaced = finalize_snapshot(read_snapshot_at(
        path.parent.get(), stage.name, "displaced custody record"));
    if (!same_inode_account(displaced.status, original.status) ||
        displaced.digest != original.digest || displaced.bytes != original.bytes) {
        const auto restored = ::syscall(SYS_renameat2, path.parent.get(),
            stage.name.c_str(), path.parent.get(), path.filename.c_str(),
            RENAME_EXCHANGE);
        if (restored == 0) {
            stage.exchanged = false;
            sync_parent(path.parent.get(),
                "STATE_HEAD_CUSTODY_DIRECTORY_SYNC_FAILED_AFTER_RACE_RESTORE");
        }
        app_fail(restored == 0 ? "STATE_HEAD_CUSTODY_REPLACEMENT_RACE" :
            "STATE_HEAD_CUSTODY_RACE_RESTORE_FAILED",
            restored == 0 ?
                "unexpected custody record reached the atomic exchange boundary" :
                "custody publication raced and the atomic restoration failed");
    }
    sync_parent(path.parent.get(),
        "STATE_HEAD_CUSTODY_DIRECTORY_SYNC_FAILED_AFTER_PUBLICATION");
    if (::unlinkat(path.parent.get(), stage.name.c_str(), 0) != 0) {
        app_fail("STATE_HEAD_CUSTODY_OLD_RECORD_REMOVE_FAILED",
            "new custody record is published but old staging link could not be removed");
    }
    stage.name.clear();
    sync_parent(path.parent.get(),
        "STATE_HEAD_CUSTODY_DIRECTORY_SYNC_FAILED_AFTER_CLEANUP");

    auto result_snapshot = finalize_snapshot(read_snapshot_at(
        path.parent.get(), path.filename, "advanced custody record"));
    auto result = decode_record(result_snapshot.bytes);
    if (result.node != previous.node || result.domain != previous.domain ||
        result.generation != new_generation || result.selector != new_selector) {
        app_fail("STATE_HEAD_CUSTODY_POSTCONDITION_FAILED",
            "published custody record does not match the exact candidate");
    }
    return PublishedRecord{
        .snapshot = std::move(result_snapshot),
        .record = std::move(result),
    };
}

struct CanonicalCustodyAccount final {
    datacube::Octets bytes;
    datacube::Digest32 digest;
    CustodyRecord record;
};

[[nodiscard]] CanonicalCustodyAccount canonical_complete_expectation(
    const StateHeadCustodyExpectation& expected) {
    if (!expected.node || !expected.domain || !expected.generation ||
        !expected.state_head || !expected.record_digest) {
        app_fail("STATE_HEAD_CUSTODY_EXPECTATION_REQUIRED",
            "promotion outcome audit requires exact old node, domain, generation, head, and record digest");
    }
    const auto bytes = encode_record(*expected.node, *expected.domain,
        *expected.generation, *expected.state_head);
    const auto digest = datacube::sha256(bytes);
    if (digest_is_zero(digest) || digest != *expected.record_digest) {
        app_fail("STATE_HEAD_CUSTODY_EXPECTATION_INVALID",
            "intended old custody account is not the canonical record named by its digest");
    }
    return CanonicalCustodyAccount{
        .bytes = bytes,
        .digest = digest,
        .record = decode_record(bytes),
    };
}

void validate_promotion_candidate(
    const StateHeadCustodyPromotionCandidate& candidate) {
    if (candidate.journal_bytes == 0U || candidate.authentication.records == 0U ||
        !valid_successor_relationship(candidate.relationship) ||
        candidate.source_json.empty() || !candidate.prepublication_recheck ||
        !candidate.source_lifetime) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INVALID",
            "authenticated promotion candidate is incomplete");
    }
    validate_source_account(candidate.source_account);
    if (candidate.source_account.authenticated_bytes != candidate.journal_bytes) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INVALID",
            "promotion candidate source account does not bind its authenticated byte count");
    }
}

void validate_promotion_audit_candidate(
    const StateHeadCustodyPromotionAuditCandidate& candidate) {
    if (candidate.journal_bytes == 0U || candidate.authentication.records == 0U ||
        candidate.relationship.empty() || candidate.source_json.empty() ||
        !candidate.final_recheck || !candidate.source_lifetime ||
        (candidate.eligible && (!candidate.ineligibility_code.empty() ||
            !candidate.ineligibility_detail.empty())) ||
        (!candidate.eligible && (candidate.ineligibility_code.empty() ||
            candidate.ineligibility_detail.empty()))) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_AUDIT_INVALID",
            "authenticated promotion-audit candidate is incomplete or inconsistent");
    }
    validate_source_account(candidate.source_account);
    if (candidate.source_account.authenticated_bytes != candidate.journal_bytes ||
        (candidate.eligible && !valid_successor_relationship(candidate.relationship))) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_AUDIT_INVALID",
            "promotion-audit candidate source account is inconsistent");
    }
}

void enforce_intent_source_match(
    const CustodyPromotionIntentRecord& intent,
    const StateHeadCustodyPromotionSourceAccount& source,
    const std::string_view relationship,
    const std::string_view derived_selector) {
    if (!same_source_account(intent.source, source) ||
        intent.relationship != relationship ||
        intent.derived_selector != derived_selector) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_SOURCE_MISMATCH",
            "revalidated source does not reproduce the exact detached promotion intent");
    }
}

void enforce_intent_custody_path(const IntentPath& intent_path,
    const CustodyPath& custody_path, const CustodyPromotionIntentRecord& intent) {
    if (intent_path.absolute == custody_path.absolute) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_PATH_INVALID",
            "custody record and custody-promotion intent must be distinct paths");
    }
    if (intent.custody_path != custody_path.absolute) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_CUSTODY_MISMATCH",
            "detached promotion intent is bound to a different explicit custody path");
    }
}

}  // namespace

void configure_process_state_head_custody_constraint(
    const StateHeadCustodyConstraintOptions& options) {
    if (configured_constraint || process_state_head_expectation()) {
        app_fail("STATE_HEAD_EXPECTATION_INVALID",
            "raw and detached-custody state expectations cannot be mixed or configured twice");
    }
    if (!process_state_auth_key()) {
        app_fail("STATE_AUTH_KEY_REQUIRED",
            "a custody-constrained state head requires an explicit state authentication key");
    }
    if (options.expected_generation == 0U) {
        app_fail("STATE_HEAD_CUSTODY_GENERATION_INVALID",
            "expected custody generation must be positive");
    }
    require_domain(options.expected_domain);
    if (digest_is_zero(options.expected_record_digest)) {
        app_fail("STATE_HEAD_CUSTODY_EXPECTATION_INVALID",
            "expected custody record digest is reserved");
    }

    auto path = open_custody_path(options.record_file);
    lock_parent(path.parent.get(), LOCK_SH);
    auto snapshot = finalize_snapshot(read_snapshot_at(
        path.parent.get(), path.filename, "state-opening custody record"));
    auto record = decode_record(snapshot.bytes);
    StateHeadCustodyExpectation expected;
    expected.domain = options.expected_domain;
    expected.generation = options.expected_generation;
    expected.record_digest = options.expected_record_digest;
    enforce_expectation(expected, record, snapshot.digest, false);

    auto constraint = std::make_unique<ProcessCustodyConstraint>(
        ProcessCustodyConstraint{
            .path = std::move(path),
            .snapshot = std::move(snapshot),
            .record = std::move(record),
        });
    configure_process_state_head_expectation(constraint->record.selector);
    configured_constraint = std::move(constraint);
}

void recheck_process_state_head_custody_constraint(
    const StateHeadCustodyRecheckPoint point) {
    if (!configured_constraint) { return; }
#if defined(NATRAV_CUSTODY_CONSTRAINT_OMIT_FINAL_RECHECK)
    if (point == StateHeadCustodyRecheckPoint::successful_command) { return; }
#endif
    test_pause_constraint_recheck(point);
    static_cast<void>(recheck_exact(
        configured_constraint->path, configured_constraint->snapshot));
}

void release_process_state_head_custody_constraint() noexcept {
    configured_constraint.reset();
}

bool process_state_head_custody_constraint_active() noexcept {
    return static_cast<bool>(configured_constraint);
}

std::string create_state_head_custody_record(
    const StateHeadCustodyCreateOptions& options) {
    auto path = open_custody_path(options.record_file);
    lock_parent(path.parent.get(), LOCK_EX);
    const auto bytes = encode_record(options.node, options.domain,
        options.generation, options.state_head);
    Stage stage(path.parent.get(), random_stage_name(path.filename), bytes);
    if (::syscall(SYS_renameat2, path.parent.get(), stage.name.c_str(),
            path.parent.get(), path.filename.c_str(), RENAME_NOREPLACE) != 0) {
        app_fail(errno == EEXIST ? "STATE_HEAD_CUSTODY_DESTINATION_EXISTS" :
            "STATE_HEAD_CUSTODY_PUBLISH_FAILED", "custody creation never overwrites an existing path");
    }
    stage.name.clear();
    sync_parent(path.parent.get(), "STATE_HEAD_CUSTODY_DIRECTORY_SYNC_FAILED");
    test_pause_after_create_publication();
    auto snapshot = finalize_snapshot(read_snapshot_at(
        path.parent.get(), path.filename, "created custody record"));
    if (snapshot.bytes != bytes) {
        app_fail("STATE_HEAD_CUSTODY_POSTCONDITION_FAILED",
            "published custody path no longer contains the exact created record");
    }
    const auto record = decode_record(snapshot.bytes);
    return response_prefix("CREATE", path) +
        ",\"previous\":null,\"result\":" + record_json(record, snapshot) +
        ",\"publication\":\"ATOMIC_NO_REPLACE\",\"state_opened\":false," +
        "\"workers_started\":false,\"automatic_update\":false}";
}

std::string read_state_head_custody_record(
    const StateHeadCustodyReadOptions& options) {
    auto path = open_custody_path(options.record_file);
    lock_parent(path.parent.get(), LOCK_SH);
    auto snapshot = finalize_snapshot(read_snapshot_at(
        path.parent.get(), path.filename, "custody record"));
    const auto record = decode_record(snapshot.bytes);
    enforce_expectation(options.expected, record, snapshot.digest, false);
    static_cast<void>(recheck_exact(path, snapshot));
    return response_prefix("READ_VERIFY", path) +
        ",\"record\":" + record_json(record, snapshot) +
        ",\"state_opened\":false,\"workers_started\":false," +
        "\"mutation\":\"NONE\",\"automatic_update\":false}";
}

std::string advance_state_head_custody_record(
    const StateHeadCustodyAdvanceOptions& options) {
    auto path = open_custody_path(options.record_file);
    lock_parent(path.parent.get(), LOCK_EX);
    auto original = finalize_snapshot(read_snapshot_at(
        path.parent.get(), path.filename, "custody compare-and-swap source"));
    const auto previous = decode_record(original.bytes);
    enforce_expectation(options.expected, previous, original.digest, true);
    if (options.new_generation <= previous.generation) {
        app_fail("STATE_HEAD_CUSTODY_GENERATION_INVALID",
            "new custody generation must be strictly greater than the exact old generation");
    }
    const auto published = publish_replacement(path, original, previous,
        options.new_generation, options.new_state_head, {});
    return response_prefix("COMPARE_AND_SWAP_ADVANCE", path) +
        ",\"previous\":" + record_json(previous, original) +
        ",\"result\":" + record_json(published.record, published.snapshot) +
        ",\"publication\":\"SAME_DIRECTORY_SYNCED_ATOMIC_EXCHANGE\"," +
        "\"old_identity_rechecked_immediately_before_publication\":true," +
        "\"state_opened\":false,\"workers_started\":false," +
        "\"automatic_update\":false}";
}

std::string promote_state_head_custody_record(
    const StateHeadCustodyPromotionOptions& options,
    const StateHeadCustodyPromotionValidator& validator) {
    if (!validator) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INVALID",
            "custody promotion requires one authenticated source validator");
    }
    auto path = open_custody_path(options.record_file);
    lock_parent(path.parent.get(), LOCK_EX);
    auto original = finalize_snapshot(read_snapshot_at(
        path.parent.get(), path.filename, "custody promotion source"));
    const auto previous = decode_record(original.bytes);
    enforce_expectation(options.expected, previous, original.digest, true);
    if (options.new_generation <= previous.generation) {
        app_fail("STATE_HEAD_CUSTODY_GENERATION_INVALID",
            "promotion generation must be strictly greater than the exact old generation");
    }

    auto candidate = validator(previous.head);
    validate_promotion_candidate(candidate);
    const auto selector = state_head_selector(previous.node,
        candidate.authentication, candidate.journal_bytes);
    if (selector == previous.selector) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_NOOP",
            "old custody already names the exact authenticated input head");
    }

    const auto published = publish_replacement(path, original, previous,
        options.new_generation, selector, candidate.prepublication_recheck);
    return std::string("{\"format\":\"NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_V1\",\"ok\":true") +
        ",\"operation\":\"AUTHENTICATED_INPUT_PROMOTION\"" +
        ",\"path\":" + json_string(path.absolute.string()) +
        ",\"relationship\":" + json_string(candidate.relationship) +
        ",\"source\":" + candidate.source_json +
        ",\"previous\":" + record_json(previous, original) +
        ",\"result\":" + record_json(published.record, published.snapshot) +
        ",\"derived_state_head\":" + json_string(selector) +
        ",\"caller_supplied_new_selector\":false," +
        "\"publication\":\"SAME_DIRECTORY_SYNCED_ATOMIC_EXCHANGE\"," +
        "\"old_identity_rechecked_immediately_before_publication\":true," +
        "\"input_rechecked_immediately_before_publication\":true," +
        "\"node_state_mutated\":false,\"backup_restored\":false," +
        "\"workers_started\":false,\"automatic_update\":false," +
        "\"freshness\":\"CUSTODIAN_EXPLICIT_UPDATE_DISCIPLINE_ONLY\"}";
}

std::string audit_state_head_custody_promotion_outcome(
    const StateHeadCustodyPromotionAuditOptions& options,
    const StateHeadCustodyPromotionAuditValidator& validator) {
    if (!validator) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_AUDIT_INVALID",
            "promotion outcome audit requires one authenticated source validator");
    }
    const auto intended_old = canonical_complete_expectation(options.intended_old);
    if (options.intended_new_generation <= intended_old.record.generation) {
        app_fail("STATE_HEAD_CUSTODY_GENERATION_INVALID",
            "audited promotion generation must be strictly greater than the intended old generation");
    }

    auto path = open_custody_path(options.record_file);
    lock_parent(path.parent.get(), LOCK_SH);
    auto current_snapshot = finalize_snapshot(read_snapshot_at(
        path.parent.get(), path.filename, "current custody promotion outcome"));
    const auto current_record = decode_record(current_snapshot.bytes);

    auto candidate = validator(intended_old.record.head);
    validate_promotion_audit_candidate(candidate);

    const auto derived_selector = state_head_selector(intended_old.record.node,
        candidate.authentication, candidate.journal_bytes);
    const auto intended_result_bytes = encode_record(intended_old.record.node,
        intended_old.record.domain, options.intended_new_generation,
        derived_selector);
    const auto intended_result_digest = datacube::sha256(intended_result_bytes);
    const auto intended_result_record = decode_record(intended_result_bytes);

    test_pause_promotion_audit_final_recheck();
    candidate.final_recheck();
    current_snapshot = recheck_exact(path, current_snapshot);
    candidate.final_recheck();

    const bool exact_old_present = current_snapshot.bytes == intended_old.bytes;
#if defined(NATRAV_CUSTODY_PROMOTION_AUDIT_OMIT_EXACT_RESULT_RECORD)
    const bool exact_result_present =
        current_record.node == intended_result_record.node &&
        current_record.generation == intended_result_record.generation &&
        current_record.selector == intended_result_record.selector;
#else
    const bool exact_result_present = current_snapshot.bytes == intended_result_bytes;
#endif
    const std::string classification = !candidate.eligible ?
        "SOURCE_STALE_OR_DIVERGENT" :
        (exact_old_present ? "NOT_APPLIED_EXACT_OLD_RECORD" :
            (exact_result_present ? "APPLIED_EXACT_DERIVED_SUCCESSOR" :
                "CURRENT_CUSTODY_DIVERGED"));

    return std::string("{\"format\":\"NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_OUTCOME_AUDIT_V1\",\"ok\":true") +
        ",\"operation\":\"READ_ONLY_AUTHENTICATED_PROMOTION_OUTCOME_AUDIT\"" +
        ",\"classification\":" + json_string(classification) +
        ",\"path\":" + json_string(path.absolute.string()) +
        ",\"source_eligibility\":{\"eligible\":" +
        std::string(candidate.eligible ? "true" : "false") +
        ",\"relationship\":" + json_string(candidate.relationship) +
        ",\"promotion_error_code\":" +
        (candidate.eligible ? std::string("null") :
            json_string(candidate.ineligibility_code)) +
        ",\"detail\":" +
        (candidate.eligible ? std::string("null") :
            json_string(candidate.ineligibility_detail)) + "}" +
        ",\"source\":" + candidate.source_json +
        ",\"intent\":{\"old_record\":" +
        record_account_json(intended_old.record, intended_old.bytes,
            intended_old.digest) +
        ",\"intended_new_generation\":" +
        std::to_string(options.intended_new_generation) +
        ",\"derived_state_head\":" + json_string(derived_selector) +
        ",\"expected_successor_record\":" +
        record_account_json(intended_result_record, intended_result_bytes,
            intended_result_digest) + "}" +
        ",\"current_custody\":" +
        record_json(current_record, current_snapshot) +
        ",\"evidence\":{\"exact_old_record_present\":" +
        std::string(exact_old_present ? "true" : "false") +
        ",\"exact_intended_successor_present\":" +
        std::string(exact_result_present ? "true" : "false") +
        ",\"source_rechecks\":2,\"custody_rechecks\":1}" +
        ",\"mutation\":\"NONE\",\"custody_advanced\":false," +
        "\"promotion_retried\":false,\"state_mutated\":false," +
        "\"backup_restored\":false,\"workers_started\":false," +
        "\"response_receipt\":\"NOT_ESTABLISHED\"," +
        "\"duplicate_attempt_semantics\":\"OBSERVATIONAL_ONLY_NOT_IDEMPOTENCY_OR_RETRY\"," +
        "\"freshness\":\"CUSTODIAN_EXPLICIT_SELECTION_NOT_GLOBAL_LATESTNESS\"}";
}

std::string create_state_head_custody_promotion_intent(
    const StateHeadCustodyPromotionIntentCreateOptions& options,
    const StateHeadCustodyPromotionValidator& validator) {
    if (!validator) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "custody-promotion intent creation requires one authenticated source validator");
    }
    auto intent_path = open_intent_path(options.intent_file);
    auto custody_path = open_custody_path(options.record_file);
    if (intent_path.absolute == custody_path.absolute) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_PATH_INVALID",
            "custody record and custody-promotion intent must be distinct paths");
    }
    lock_intent_parent(intent_path.parent.get(), LOCK_EX);
    const bool common_parent = same_directory(
        intent_path.parent.get(), custody_path.parent.get());
    if (!common_parent) { lock_parent(custody_path.parent.get(), LOCK_SH); }

    auto old_snapshot = finalize_snapshot(read_snapshot_at(
        custody_path.parent.get(), custody_path.filename,
        "custody-promotion intent old custody record"));
    const auto old_record = decode_record(old_snapshot.bytes);
    enforce_expectation(options.expected, old_record, old_snapshot.digest, true);
    if (options.new_generation <= old_record.generation) {
        app_fail("STATE_HEAD_CUSTODY_GENERATION_INVALID",
            "intent generation must be strictly greater than the exact old generation");
    }

    auto candidate = validator(old_record.head);
    validate_promotion_candidate(candidate);
    const auto selector = state_head_selector(old_record.node,
        candidate.authentication, candidate.journal_bytes);
    if (selector == old_record.selector) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_NOOP",
            "old custody already names the exact authenticated input head");
    }
    const auto bytes = encode_intent_record(custody_path.absolute,
        old_snapshot.bytes, old_snapshot.digest, options.new_generation,
        candidate.source_account, candidate.relationship, selector);
    IntentStage stage(intent_path.parent.get(),
        random_intent_stage_name(intent_path.filename), bytes);

    test_pause_intent_creation_final_recheck();
    static_cast<void>(recheck_exact(custody_path, old_snapshot));
    candidate.prepublication_recheck();
    if (::syscall(SYS_renameat2, intent_path.parent.get(), stage.name.c_str(),
            intent_path.parent.get(), intent_path.filename.c_str(),
            RENAME_NOREPLACE) != 0) {
        app_fail(errno == EEXIST ?
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_DESTINATION_EXISTS" :
            "STATE_HEAD_CUSTODY_PROMOTION_INTENT_PUBLISH_FAILED",
            "custody-promotion intent creation never overwrites an existing path");
    }
    stage.name.clear();
    sync_parent(intent_path.parent.get(),
        "STATE_HEAD_CUSTODY_PROMOTION_INTENT_DIRECTORY_SYNC_FAILED");

    auto intent_snapshot = finalize_intent_snapshot(read_intent_snapshot_at(
        intent_path.parent.get(), intent_path.filename,
        "created custody-promotion intent"));
    if (intent_snapshot.bytes != bytes) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_POSTCONDITION_FAILED",
            "published intent path no longer contains the exact created record");
    }
    const auto intent = decode_intent_record(intent_snapshot.bytes);
    candidate.prepublication_recheck();
    static_cast<void>(recheck_exact(custody_path, old_snapshot));
    static_cast<void>(recheck_intent_exact(intent_path, intent_snapshot));

    const auto successor_bytes = encode_record(old_record.node, old_record.domain,
        options.new_generation, selector);
    const auto successor_digest = datacube::sha256(successor_bytes);
    const auto successor = decode_record(successor_bytes);
    return std::string("{\"format\":\"NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_INTENT_CREATION_V1\",\"ok\":true") +
        ",\"operation\":\"CREATE_AUTHENTICATED_PROMOTION_INTENT\"" +
        ",\"path\":" + json_string(intent_path.absolute.string()) +
        ",\"source\":" + candidate.source_json +
        ",\"intent\":" + intent_account_json(intent, intent_snapshot) +
        ",\"expected_successor_record\":" +
        record_account_json(successor, successor_bytes, successor_digest) +
        ",\"publication\":\"ATOMIC_NO_REPLACE\"," +
        "\"custody_mutated\":false,\"state_mutated\":false," +
        "\"backup_restored\":false,\"workers_started\":false," +
        "\"source_rechecks\":2,\"custody_rechecks\":2," +
        "\"intent_rechecks\":1,\"automatic_promotion\":false," +
        "\"authority\":\"NONE_REVALIDATION_REQUIRED\"}";
}

std::string promote_state_head_custody_record_with_intent(
    const StateHeadCustodyPromotionIntentUseOptions& options,
    const StateHeadCustodyPromotionValidator& validator) {
    if (!validator) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_INVALID",
            "intent promotion requires one authenticated source validator");
    }
    auto intent_path = open_intent_path(options.intent_file);
    auto custody_path = open_custody_path(options.record_file);
    if (intent_path.absolute == custody_path.absolute) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_PATH_INVALID",
            "custody record and custody-promotion intent must be distinct paths");
    }
    lock_intent_parent(intent_path.parent.get(), LOCK_EX);
    const bool common_parent = same_directory(
        intent_path.parent.get(), custody_path.parent.get());
    if (!common_parent) { lock_parent(custody_path.parent.get(), LOCK_EX); }

    auto intent_snapshot = finalize_intent_snapshot(read_intent_snapshot_at(
        intent_path.parent.get(), intent_path.filename,
        "custody-promotion intent"));
    const auto intent = decode_intent_record(intent_snapshot.bytes);
    enforce_intent_custody_path(intent_path, custody_path, intent);
    auto original = finalize_snapshot(read_snapshot_at(
        custody_path.parent.get(), custody_path.filename,
        "intent-bound custody promotion source"));
    const auto previous = decode_record(original.bytes);
    if (original.bytes != intent.old_record_bytes ||
        original.digest != intent.old_record_digest) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_CUSTODY_MISMATCH",
            "current custody is not the exact old record bound by the detached intent");
    }

    auto candidate = validator(intent.old_record.head);
    validate_promotion_candidate(candidate);
    const auto selector = state_head_selector(intent.old_record.node,
        candidate.authentication, candidate.journal_bytes);
    enforce_intent_source_match(intent, candidate.source_account,
        candidate.relationship, selector);

    const std::function<void()> recheck = [&] {
        candidate.prepublication_recheck();
        static_cast<void>(recheck_intent_exact(intent_path, intent_snapshot));
    };
    test_pause_intent_consumption_final_recheck();
    const auto published = publish_replacement(custody_path, original, previous,
        intent.intended_new_generation, selector, recheck);
    candidate.prepublication_recheck();
    static_cast<void>(recheck_intent_exact(intent_path, intent_snapshot));

    return std::string("{\"format\":\"NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_V1\",\"ok\":true") +
        ",\"operation\":\"AUTHENTICATED_INPUT_PROMOTION\"" +
        ",\"input_mode\":\"DETACHED_INTENT\"" +
        ",\"path\":" + json_string(custody_path.absolute.string()) +
        ",\"relationship\":" + json_string(candidate.relationship) +
        ",\"source\":" + candidate.source_json +
        ",\"promotion_intent\":" + intent_account_json(intent, intent_snapshot) +
        ",\"previous\":" + record_json(previous, original) +
        ",\"result\":" + record_json(published.record, published.snapshot) +
        ",\"derived_state_head\":" + json_string(selector) +
        ",\"caller_supplied_new_selector\":false," +
        "\"publication\":\"SAME_DIRECTORY_SYNCED_ATOMIC_EXCHANGE\"," +
        "\"old_identity_rechecked_immediately_before_publication\":true," +
        "\"input_rechecked_immediately_before_publication\":true," +
        "\"intent_rechecked_immediately_before_publication\":true," +
        "\"intent_authority\":\"NONE_REVALIDATED_INPUT_ONLY\"," +
        "\"node_state_mutated\":false,\"backup_restored\":false," +
        "\"workers_started\":false,\"automatic_update\":false," +
        "\"freshness\":\"CUSTODIAN_EXPLICIT_UPDATE_DISCIPLINE_ONLY\"}";
}

std::string audit_state_head_custody_promotion_outcome_with_intent(
    const StateHeadCustodyPromotionIntentUseOptions& options,
    const StateHeadCustodyPromotionAuditValidator& validator) {
    if (!validator) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_AUDIT_INVALID",
            "intent outcome audit requires one authenticated source validator");
    }
    auto intent_path = open_intent_path(options.intent_file);
    auto custody_path = open_custody_path(options.record_file);
    if (intent_path.absolute == custody_path.absolute) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_PATH_INVALID",
            "custody record and custody-promotion intent must be distinct paths");
    }
    lock_intent_parent(intent_path.parent.get(), LOCK_EX);
    const bool common_parent = same_directory(
        intent_path.parent.get(), custody_path.parent.get());
    if (!common_parent) { lock_parent(custody_path.parent.get(), LOCK_SH); }

    auto intent_snapshot = finalize_intent_snapshot(read_intent_snapshot_at(
        intent_path.parent.get(), intent_path.filename,
        "custody-promotion intent outcome audit"));
    const auto intent = decode_intent_record(intent_snapshot.bytes);
    enforce_intent_custody_path(intent_path, custody_path, intent);
    auto current_snapshot = finalize_snapshot(read_snapshot_at(
        custody_path.parent.get(), custody_path.filename,
        "current intent-bound custody promotion outcome"));
    const auto current_record = decode_record(current_snapshot.bytes);

    auto candidate = validator(intent.old_record.head);
    validate_promotion_audit_candidate(candidate);
    if (!candidate.eligible) {
        app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_SOURCE_MISMATCH",
            "revalidated source no longer proves the successor relationship bound by the intent");
    }
    const auto derived_selector = state_head_selector(intent.old_record.node,
        candidate.authentication, candidate.journal_bytes);
    enforce_intent_source_match(intent, candidate.source_account,
        candidate.relationship, derived_selector);
    const auto intended_result_bytes = encode_record(intent.old_record.node,
        intent.old_record.domain, intent.intended_new_generation,
        derived_selector);
    const auto intended_result_digest = datacube::sha256(intended_result_bytes);
    const auto intended_result_record = decode_record(intended_result_bytes);

    test_pause_intent_consumption_final_recheck();
    candidate.final_recheck();
    static_cast<void>(recheck_intent_exact(intent_path, intent_snapshot));
    current_snapshot = recheck_exact(custody_path, current_snapshot);
    candidate.final_recheck();
    static_cast<void>(recheck_intent_exact(intent_path, intent_snapshot));

    const bool exact_old_present =
        current_snapshot.bytes == intent.old_record_bytes;
    const bool exact_result_present =
        current_snapshot.bytes == intended_result_bytes;
    const std::string classification = exact_old_present ?
        "NOT_APPLIED_EXACT_OLD_RECORD" :
        (exact_result_present ? "APPLIED_EXACT_DERIVED_SUCCESSOR" :
            "CURRENT_CUSTODY_DIVERGED");

    return std::string("{\"format\":\"NATRAV_OVERLAY_DETACHED_STATE_HEAD_CUSTODY_PROMOTION_OUTCOME_AUDIT_V1\",\"ok\":true") +
        ",\"operation\":\"READ_ONLY_AUTHENTICATED_PROMOTION_OUTCOME_AUDIT\"" +
        ",\"input_mode\":\"DETACHED_INTENT\"" +
        ",\"classification\":" + json_string(classification) +
        ",\"path\":" + json_string(custody_path.absolute.string()) +
        ",\"source_eligibility\":{\"eligible\":true,\"relationship\":" +
        json_string(candidate.relationship) +
        ",\"promotion_error_code\":null,\"detail\":null}" +
        ",\"source\":" + candidate.source_json +
        ",\"promotion_intent\":" + intent_account_json(intent, intent_snapshot) +
        ",\"expected_successor_record\":" +
        record_account_json(intended_result_record, intended_result_bytes,
            intended_result_digest) +
        ",\"current_custody\":" +
        record_json(current_record, current_snapshot) +
        ",\"evidence\":{\"exact_old_record_present\":" +
        std::string(exact_old_present ? "true" : "false") +
        ",\"exact_intended_successor_present\":" +
        std::string(exact_result_present ? "true" : "false") +
        ",\"source_rechecks\":2,\"custody_rechecks\":1," +
        "\"intent_rechecks\":2}" +
        ",\"mutation\":\"NONE\",\"custody_advanced\":false," +
        "\"promotion_retried\":false,\"state_mutated\":false," +
        "\"backup_restored\":false,\"workers_started\":false," +
        "\"response_receipt\":\"NOT_ESTABLISHED\"," +
        "\"duplicate_attempt_semantics\":\"OBSERVATIONAL_ONLY_NOT_IDEMPOTENCY_OR_RETRY\"," +
        "\"intent_authority\":\"NONE_REVALIDATED_INPUT_ONLY\"," +
        "\"freshness\":\"CUSTODIAN_EXPLICIT_SELECTION_NOT_GLOBAL_LATESTNESS\"}";
}

}  // namespace natrav_overlay
