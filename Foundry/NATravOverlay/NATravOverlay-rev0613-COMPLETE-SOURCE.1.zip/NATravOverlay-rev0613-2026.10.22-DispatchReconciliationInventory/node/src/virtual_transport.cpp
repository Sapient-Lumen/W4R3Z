#include "virtual_transport.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <limits>
#include <map>
#include <mutex>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <tuple>
#include <utility>
#include <vector>

namespace natrav_overlay {
namespace {

constexpr std::array<std::uint8_t, 8U> kScheduleMagic{
    'N', 'V', 'C', 'S', '0', '0', '0', '1'};
constexpr std::array<std::uint8_t, 8U> kTraceMagic{
    'N', 'V', 'T', 'R', '0', '0', '0', '1'};
constexpr std::uint16_t kScheduleVersion = 1U;
constexpr std::uint16_t kFlagHalfDuplex = 1U;
constexpr std::uint16_t kFlagInitialGrant = 2U;
constexpr std::uint16_t kFlagInitialGrantSecond = 4U;
constexpr std::uint16_t kKnownScheduleFlags =
    kFlagHalfDuplex | kFlagInitialGrant | kFlagInitialGrantSecond;
constexpr std::uint32_t kMaximumOperationIndex = 1'000'000U;
constexpr std::uint32_t kNoEventIndex = std::numeric_limits<std::uint32_t>::max();

[[nodiscard]] std::size_t endpoint_offset(const VirtualEndpoint endpoint) {
    switch (endpoint) {
        case VirtualEndpoint::first:
            return 0U;
        case VirtualEndpoint::second:
            return 1U;
    }
    app_fail("VIRTUAL_SCHEDULE_INVALID", "unknown virtual endpoint");
}

[[nodiscard]] VirtualEndpoint opposite_endpoint(
    const VirtualEndpoint endpoint) noexcept {
    return endpoint == VirtualEndpoint::first ?
        VirtualEndpoint::second : VirtualEndpoint::first;
}

[[nodiscard]] std::size_t operation_offset(const VirtualOperation operation) {
    switch (operation) {
        case VirtualOperation::read:
            return 0U;
        case VirtualOperation::write:
            return 1U;
        case VirtualOperation::shutdown_write:
            return 2U;
    }
    app_fail("VIRTUAL_SCHEDULE_INVALID", "unknown virtual operation");
}

[[nodiscard]] auto event_key_tuple(const VirtualScheduleEvent& event) noexcept {
    return std::tuple(
        static_cast<std::uint8_t>(event.endpoint),
        static_cast<std::uint8_t>(event.operation),
        event.operation_index);
}

[[nodiscard]] std::uint64_t event_key(
    const VirtualEndpoint endpoint,
    const VirtualOperation operation,
    const std::uint32_t operation_index) noexcept {
    return (static_cast<std::uint64_t>(static_cast<std::uint8_t>(endpoint)) << 56U) |
        (static_cast<std::uint64_t>(static_cast<std::uint8_t>(operation)) << 48U) |
        static_cast<std::uint64_t>(operation_index);
}

[[nodiscard]] bool fault_allowed(
    const VirtualOperation operation,
    const VirtualFault fault) noexcept {
    switch (operation) {
        case VirtualOperation::read:
            return fault == VirtualFault::none ||
                fault == VirtualFault::timeout ||
                fault == VirtualFault::reset ||
                fault == VirtualFault::disconnect;
        case VirtualOperation::write:
            return true;
        case VirtualOperation::shutdown_write:
            return fault == VirtualFault::none ||
                fault == VirtualFault::reset ||
                fault == VirtualFault::disconnect;
    }
    return false;
}

void validate_event(const VirtualScheduleEvent& event,
                    const VirtualCarrierSchedule& schedule) {
    static_cast<void>(endpoint_offset(event.endpoint));
    static_cast<void>(operation_offset(event.operation));
    switch (event.fault) {
        case VirtualFault::none:
        case VirtualFault::timeout:
        case VirtualFault::reset:
        case VirtualFault::disconnect:
        case VirtualFault::drop:
        case VirtualFault::duplicate:
        case VirtualFault::corrupt:
        case VirtualFault::reorder:
            break;
        default:
            app_fail("VIRTUAL_SCHEDULE_INVALID", "unknown virtual fault");
    }
    if (event.operation_index == 0U ||
        event.operation_index > kMaximumOperationIndex) {
        app_fail(
            "VIRTUAL_SCHEDULE_INVALID",
            "operation index is outside 1..1000000");
    }
    if (event.delay_steps > kMaximumVirtualDelaySteps) {
        app_fail(
            "VIRTUAL_SCHEDULE_INVALID",
            "delay steps exceed the finite virtual bound");
    }
    if (event.maximum_bytes > kMaximumVirtualChunkBytes) {
        app_fail(
            "VIRTUAL_SCHEDULE_INVALID",
            "event byte ceiling exceeds 65536");
    }
    if (!fault_allowed(event.operation, event.fault)) {
        app_fail(
            "VIRTUAL_SCHEDULE_INVALID",
            "fault is not valid for the selected operation");
    }
    if (event.operation == VirtualOperation::shutdown_write &&
        (event.delay_steps != 0U || event.maximum_bytes != 0U)) {
        app_fail(
            "VIRTUAL_SCHEDULE_INVALID",
            "shutdown events cannot carry delay or byte ceilings");
    }
    switch (event.fault) {
        case VirtualFault::duplicate:
            if (event.parameter < 1U || event.parameter > 3U) {
                app_fail(
                    "VIRTUAL_SCHEDULE_INVALID",
                    "duplicate parameter must request 1..3 extra copies");
            }
            if (schedule.queue_capacity <= event.parameter) {
                app_fail(
                    "VIRTUAL_SCHEDULE_INVALID",
                    "queue cannot hold one byte and every duplicate copy");
            }
            break;
        case VirtualFault::corrupt:
            if (event.parameter >= kMaximumVirtualChunkBytes) {
                app_fail(
                    "VIRTUAL_SCHEDULE_INVALID",
                    "corruption offset exceeds the finite chunk bound");
            }
            break;
        case VirtualFault::reorder:
            if (event.parameter != 0U || schedule.queue_capacity < 2U) {
                app_fail(
                    "VIRTUAL_SCHEDULE_INVALID",
                    "reordering requires parameter zero and queue capacity at least two");
            }
            break;
        case VirtualFault::none:
        case VirtualFault::timeout:
        case VirtualFault::reset:
        case VirtualFault::disconnect:
        case VirtualFault::drop:
            if (event.parameter != 0U) {
                app_fail(
                    "VIRTUAL_SCHEDULE_INVALID",
                    "the selected fault requires parameter zero");
            }
            break;
    }
}

[[nodiscard]] VirtualCarrierSchedule canonical_schedule(
    VirtualCarrierSchedule schedule) {
    if (schedule.queue_capacity == 0U ||
        schedule.queue_capacity > kMaximumVirtualQueueBytes) {
        app_fail(
            "VIRTUAL_SCHEDULE_INVALID",
            "queue capacity is outside 1..1048576");
    }
    if (schedule.default_read_chunk == 0U ||
        schedule.default_read_chunk > kMaximumVirtualChunkBytes ||
        schedule.default_write_chunk == 0U ||
        schedule.default_write_chunk > kMaximumVirtualChunkBytes ||
        schedule.mtu == 0U || schedule.mtu > kMaximumVirtualChunkBytes ||
        schedule.mtu > schedule.queue_capacity) {
        app_fail(
            "VIRTUAL_SCHEDULE_INVALID",
            "chunk and MTU bounds must be positive, finite, and the MTU must fit the queue");
    }
    if (!schedule.half_duplex && schedule.initial_grant.has_value()) {
        app_fail(
            "VIRTUAL_SCHEDULE_INVALID",
            "an initial grant requires half-duplex mode");
    }
    if (schedule.initial_grant.has_value()) {
        static_cast<void>(endpoint_offset(*schedule.initial_grant));
    }
    if (schedule.events.size() > kMaximumVirtualScheduleEvents) {
        app_fail(
            "VIRTUAL_SCHEDULE_INVALID",
            "schedule exceeds 4096 finite events");
    }
    for (const auto& event : schedule.events) {
        validate_event(event, schedule);
    }
    std::sort(
        schedule.events.begin(), schedule.events.end(),
        [](const VirtualScheduleEvent& left,
           const VirtualScheduleEvent& right) noexcept {
            return event_key_tuple(left) < event_key_tuple(right);
        });
    for (std::size_t index = 1U; index < schedule.events.size(); ++index) {
        if (event_key_tuple(schedule.events[index - 1U]) ==
            event_key_tuple(schedule.events[index])) {
            app_fail(
                "VIRTUAL_SCHEDULE_INVALID",
                "schedule contains duplicate endpoint/operation/index events");
        }
    }
    return schedule;
}

void append_magic(
    datacube::Octets& output,
    const std::array<std::uint8_t, 8U>& magic) {
    datacube::append_octets(output, magic);
}

void add_counter(
    std::size_t& value,
    const std::uint32_t increment,
    const std::string_view field) {
    if (increment > std::numeric_limits<std::size_t>::max() - value) {
        app_fail("VIRTUAL_COUNTER_OVERFLOW", std::string(field));
    }
    value += static_cast<std::size_t>(increment);
}

[[nodiscard]] std::uint8_t corruption_mask(
    const std::uint64_t seed,
    const std::uint32_t operation_index) noexcept {
    const auto mixed = seed ^
        (static_cast<std::uint64_t>(operation_index) * 0x9e3779b97f4a7c15ULL);
    const auto value = static_cast<std::uint8_t>(mixed & 0xffU);
    return value == 0U ? static_cast<std::uint8_t>(1U) : value;
}

}  // namespace

struct VirtualLinkControl::State final {
    struct Direction final {
        std::deque<std::uint8_t> queue;
        std::deque<std::size_t> segments;
        datacube::Octets held;
        bool write_closed{false};
    };

    explicit State(VirtualCarrierSchedule schedule_value)
        : schedule(std::move(schedule_value)),
          canonical_bytes(encode_virtual_carrier_schedule(schedule)),
          digest(datacube::sha256(canonical_bytes)),
          grant(schedule.initial_grant) {
        for (std::size_t index = 0U; index < schedule.events.size(); ++index) {
            const auto& event = schedule.events[index];
            event_indices.emplace(
                event_key(event.endpoint, event.operation, event.operation_index),
                static_cast<std::uint32_t>(index));
        }
    }

    mutable std::mutex mutex;
    std::condition_variable condition;
    VirtualCarrierSchedule schedule;
    datacube::Octets canonical_bytes;
    datacube::Digest32 digest;
    std::array<Direction, 2U> directions;
    std::array<bool, 2U> alive{true, true};
    std::array<std::array<std::uint32_t, 3U>, 2U> operation_counts{};
    bool reset{false};
    std::optional<VirtualEndpoint> grant;
    std::map<std::uint64_t, std::uint32_t> event_indices;
    std::vector<VirtualTraceRecord> trace;
};

namespace {

[[nodiscard]] const VirtualScheduleEvent* scheduled_event(
    const VirtualLinkControl::State& state,
    const VirtualEndpoint endpoint,
    const VirtualOperation operation,
    const std::uint32_t operation_index,
    std::optional<std::uint32_t>& event_index_value) {
    const auto found = state.event_indices.find(
        event_key(endpoint, operation, operation_index));
    if (found == state.event_indices.end()) {
        event_index_value.reset();
        return nullptr;
    }
    event_index_value = found->second;
    return &state.schedule.events.at(found->second);
}

void record_trace_locked(
    VirtualLinkControl::State& state,
    const VirtualEndpoint endpoint,
    const VirtualOperation operation,
    const std::uint32_t operation_index,
    const std::optional<std::uint32_t> event_index_value,
    const std::uint32_t delay_steps,
    const std::size_t requested_bytes,
    const std::size_t result_bytes,
    const VirtualTraceOutcome outcome) {
    state.trace.push_back(VirtualTraceRecord{
        .endpoint = endpoint,
        .operation = operation,
        .operation_index = operation_index,
        .event_index = event_index_value,
        .delay_steps = delay_steps,
        .requested_bytes = requested_bytes,
        .result_bytes = result_bytes,
        .outcome = outcome,
    });
}

void apply_delay(
    const VirtualScheduleEvent* event,
    IoCounters& counters) {
    if (event == nullptr || event->delay_steps == 0U) {
        return;
    }
    add_counter(counters.poll_calls, event->delay_steps, "virtual poll calls");
    add_counter(counters.would_block, event->delay_steps, "virtual would-block calls");
}

void disconnect_locked(
    VirtualLinkControl::State& state,
    const VirtualEndpoint endpoint) {
    const auto own = endpoint_offset(endpoint);
    const auto peer = endpoint_offset(opposite_endpoint(endpoint));
    state.alive[own] = false;
    state.directions[own].write_closed = true;
    state.directions[own].held.clear();
    state.directions[peer].write_closed = true;
    state.directions[peer].queue.clear();
    state.directions[peer].segments.clear();
    state.directions[peer].held.clear();
    if (state.grant.has_value()) {
        const auto granted = endpoint_offset(*state.grant);
        if (granted == own || state.directions[granted].queue.empty()) {
            state.grant.reset();
        }
    }
    state.condition.notify_all();
}

void reset_locked(VirtualLinkControl::State& state) {
    state.reset = true;
    state.condition.notify_all();
}

[[nodiscard]] bool can_take_half_duplex_grant(
    const VirtualLinkControl::State& state,
    const VirtualEndpoint endpoint) {
    if (!state.schedule.half_duplex) {
        return true;
    }
    if (state.grant.has_value()) {
        return *state.grant == endpoint;
    }
    const auto peer = endpoint_offset(opposite_endpoint(endpoint));
    return state.directions[peer].queue.empty() &&
        state.directions[peer].held.empty();
}

void release_grant_if_idle(
    VirtualLinkControl::State& state,
    const VirtualEndpoint source) {
    if (!state.schedule.half_duplex || !state.grant.has_value() ||
        *state.grant != source) {
        return;
    }
    const auto direction = endpoint_offset(source);
    if (state.directions[direction].queue.empty() &&
        state.directions[direction].held.empty()) {
        state.grant.reset();
        state.condition.notify_all();
    }
}

[[nodiscard]] std::size_t event_byte_limit(
    const VirtualScheduleEvent* event,
    const std::uint32_t fallback) noexcept {
    if (event != nullptr && event->maximum_bytes != 0U) {
        return static_cast<std::size_t>(event->maximum_bytes);
    }
    return static_cast<std::size_t>(fallback);
}

class VirtualOrderedByteStream final : public OrderedByteStream {
public:
    VirtualOrderedByteStream(
        std::shared_ptr<VirtualLinkControl::State> state,
        const VirtualEndpoint endpoint) noexcept
        : state_(std::move(state)), endpoint_(endpoint) {}

    ~VirtualOrderedByteStream() override {
        if (!state_) {
            return;
        }
        std::lock_guard<std::mutex> lock(state_->mutex);
        const auto own = endpoint_offset(endpoint_);
        if (state_->alive[own]) {
            disconnect_locked(*state_, endpoint_);
        }
    }

    [[nodiscard]] TransportKind transport_kind() const noexcept override {
        return TransportKind::virtual_link;
    }

    [[nodiscard]] std::size_t read_some(
        const std::span<std::uint8_t> buffer,
        const Deadline deadline,
        IoCounters& counters,
        const std::string_view operation_label) override {
        if (!state_ || buffer.empty()) {
            app_fail("SOCKET_INVALID", std::string(operation_label));
        }
        std::unique_lock<std::mutex> lock(state_->mutex);
        const auto own = endpoint_offset(endpoint_);
        if (!state_->alive[own]) {
            app_fail("SOCKET_INVALID", std::string(operation_label));
        }
        auto& count = state_->operation_counts[own][operation_offset(
            VirtualOperation::read)];
        if (count == kMaximumOperationIndex) {
            app_fail("VIRTUAL_OPERATION_LIMIT", "virtual read operation limit reached");
        }
        ++count;
        const auto operation_index_value = count;
        std::optional<std::uint32_t> event_index_value;
        const auto* event = scheduled_event(
            *state_, endpoint_, VirtualOperation::read,
            operation_index_value, event_index_value);
        apply_delay(event, counters);
        const auto delay = event == nullptr ? 0U : event->delay_steps;
        const auto fault = event == nullptr ? VirtualFault::none : event->fault;
        if (fault == VirtualFault::timeout) {
            record_trace_locked(
                *state_, endpoint_, VirtualOperation::read,
                operation_index_value, event_index_value, delay,
                buffer.size(), 0U, VirtualTraceOutcome::timeout);
            lock.unlock();
            app_fail("IO_TIMEOUT", std::string(operation_label));
        }
        if (fault == VirtualFault::reset) {
            reset_locked(*state_);
            record_trace_locked(
                *state_, endpoint_, VirtualOperation::read,
                operation_index_value, event_index_value, delay,
                buffer.size(), 0U, VirtualTraceOutcome::reset);
            lock.unlock();
            app_fail("PEER_RESET", std::string(operation_label));
        }
        if (fault == VirtualFault::disconnect) {
            disconnect_locked(*state_, opposite_endpoint(endpoint_));
        }

        const auto incoming_source = opposite_endpoint(endpoint_);
        const auto incoming_index = endpoint_offset(incoming_source);
        auto& incoming = state_->directions[incoming_index];
        while (incoming.queue.empty() && !incoming.write_closed &&
               state_->alive[incoming_index] && !state_->reset) {
            if (state_->condition.wait_until(lock, deadline) ==
                std::cv_status::timeout) {
                ++counters.poll_calls;
                record_trace_locked(
                    *state_, endpoint_, VirtualOperation::read,
                    operation_index_value, event_index_value, delay,
                    buffer.size(), 0U, VirtualTraceOutcome::timeout);
                lock.unlock();
                app_fail("IO_TIMEOUT", std::string(operation_label));
            }
        }
        if (state_->reset) {
            record_trace_locked(
                *state_, endpoint_, VirtualOperation::read,
                operation_index_value, event_index_value, delay,
                buffer.size(), 0U, VirtualTraceOutcome::reset);
            lock.unlock();
            app_fail("PEER_RESET", std::string(operation_label));
        }
        ++counters.read_calls;
        if (incoming.queue.empty()) {
            record_trace_locked(
                *state_, endpoint_, VirtualOperation::read,
                operation_index_value, event_index_value, delay,
                buffer.size(), 0U, VirtualTraceOutcome::eof);
            release_grant_if_idle(*state_, incoming_source);
            return 0U;
        }
        if (incoming.segments.empty()) {
            app_fail(
                "VIRTUAL_LINK_STATE_INVALID",
                "queued virtual bytes have no segment boundary");
        }
        const auto limit = event_byte_limit(
            event, state_->schedule.default_read_chunk);
        const auto progress = std::min({
            buffer.size(), limit, incoming.queue.size(),
            incoming.segments.front()});
        if (progress == 0U) {
            app_fail(
                "VIRTUAL_LINK_STATE_INVALID",
                "virtual read selected zero progress");
        }
        for (std::size_t index = 0U; index < progress; ++index) {
            buffer[index] = incoming.queue.front();
            incoming.queue.pop_front();
        }
        incoming.segments.front() -= progress;
        if (incoming.segments.front() == 0U) {
            incoming.segments.pop_front();
        }
        if (incoming.queue.empty() && !incoming.segments.empty()) {
            app_fail(
                "VIRTUAL_LINK_STATE_INVALID",
                "empty virtual queue retains segment metadata");
        }
        record_trace_locked(
            *state_, endpoint_, VirtualOperation::read,
            operation_index_value, event_index_value, delay,
            buffer.size(), progress, VirtualTraceOutcome::progress);
        release_grant_if_idle(*state_, incoming_source);
        state_->condition.notify_all();
        return progress;
    }

    [[nodiscard]] std::size_t write_some(
        const datacube::OctetView bytes,
        const Deadline deadline,
        IoCounters& counters,
        const std::string_view operation_label) override {
        if (!state_ || bytes.empty()) {
            app_fail("SOCKET_INVALID", std::string(operation_label));
        }
        std::unique_lock<std::mutex> lock(state_->mutex);
        const auto own = endpoint_offset(endpoint_);
        const auto peer = endpoint_offset(opposite_endpoint(endpoint_));
        if (!state_->alive[own]) {
            app_fail("SOCKET_INVALID", std::string(operation_label));
        }
        auto& count = state_->operation_counts[own][operation_offset(
            VirtualOperation::write)];
        if (count == kMaximumOperationIndex) {
            app_fail("VIRTUAL_OPERATION_LIMIT", "virtual write operation limit reached");
        }
        ++count;
        const auto operation_index_value = count;
        std::optional<std::uint32_t> event_index_value;
        const auto* event = scheduled_event(
            *state_, endpoint_, VirtualOperation::write,
            operation_index_value, event_index_value);
        apply_delay(event, counters);
        const auto delay = event == nullptr ? 0U : event->delay_steps;
        const auto fault = event == nullptr ? VirtualFault::none : event->fault;
        if (fault == VirtualFault::timeout) {
            record_trace_locked(
                *state_, endpoint_, VirtualOperation::write,
                operation_index_value, event_index_value, delay,
                bytes.size(), 0U, VirtualTraceOutcome::timeout);
            lock.unlock();
            app_fail("IO_TIMEOUT", std::string(operation_label));
        }
        if (fault == VirtualFault::reset) {
            reset_locked(*state_);
            record_trace_locked(
                *state_, endpoint_, VirtualOperation::write,
                operation_index_value, event_index_value, delay,
                bytes.size(), 0U, VirtualTraceOutcome::reset);
            lock.unlock();
            app_fail("SOCKET_WRITE_CLOSED", std::string(operation_label));
        }
        if (fault == VirtualFault::disconnect) {
            disconnect_locked(*state_, endpoint_);
            record_trace_locked(
                *state_, endpoint_, VirtualOperation::write,
                operation_index_value, event_index_value, delay,
                bytes.size(), 0U, VirtualTraceOutcome::write_closed);
            lock.unlock();
            app_fail("SOCKET_WRITE_CLOSED", std::string(operation_label));
        }

        auto& outgoing = state_->directions[own];
        const auto duplicate_copies = fault == VirtualFault::duplicate ?
            static_cast<std::size_t>(event->parameter) + 1U : 1U;
        const auto ceiling = std::min({
            bytes.size(),
            event_byte_limit(event, state_->schedule.default_write_chunk),
            static_cast<std::size_t>(state_->schedule.mtu)});

        auto available_progress = [&]() -> std::size_t {
            if (fault == VirtualFault::drop) {
                return ceiling;
            }
            const auto used = outgoing.queue.size();
            const auto capacity = static_cast<std::size_t>(
                state_->schedule.queue_capacity);
            if (fault == VirtualFault::reorder) {
                if (!outgoing.held.empty()) {
                    app_fail(
                        "VIRTUAL_REORDER_PENDING",
                        "a direction cannot hold two reordered segments");
                }
                if (used + 1U >= capacity) {
                    return 0U;
                }
                return std::min(ceiling, capacity - used - 1U);
            }
            if (used >= capacity || outgoing.held.size() >= capacity - used) {
                return 0U;
            }
            const auto free_after_held = capacity - used - outgoing.held.size();
            return std::min(ceiling, free_after_held / duplicate_copies);
        };

        while (!state_->reset && state_->alive[own] && state_->alive[peer] &&
               !outgoing.write_closed &&
               (!can_take_half_duplex_grant(*state_, endpoint_) ||
                available_progress() == 0U)) {
            if (state_->condition.wait_until(lock, deadline) ==
                std::cv_status::timeout) {
                ++counters.poll_calls;
                record_trace_locked(
                    *state_, endpoint_, VirtualOperation::write,
                    operation_index_value, event_index_value, delay,
                    bytes.size(), 0U, VirtualTraceOutcome::timeout);
                lock.unlock();
                app_fail("IO_TIMEOUT", std::string(operation_label));
            }
        }
        if (state_->reset) {
            record_trace_locked(
                *state_, endpoint_, VirtualOperation::write,
                operation_index_value, event_index_value, delay,
                bytes.size(), 0U, VirtualTraceOutcome::reset);
            lock.unlock();
            app_fail("SOCKET_WRITE_CLOSED", std::string(operation_label));
        }
        if (!state_->alive[peer] || outgoing.write_closed) {
            record_trace_locked(
                *state_, endpoint_, VirtualOperation::write,
                operation_index_value, event_index_value, delay,
                bytes.size(), 0U, VirtualTraceOutcome::write_closed);
            lock.unlock();
            app_fail("SOCKET_WRITE_CLOSED", std::string(operation_label));
        }
        if (state_->schedule.half_duplex && !state_->grant.has_value()) {
            state_->grant = endpoint_;
        }
        const auto progress = available_progress();
        if (progress == 0U) {
            record_trace_locked(
                *state_, endpoint_, VirtualOperation::write,
                operation_index_value, event_index_value, delay,
                bytes.size(), 0U, VirtualTraceOutcome::write_closed);
            lock.unlock();
            app_fail("SOCKET_WRITE_CLOSED", "virtual write made no progress");
        }
        ++counters.write_calls;
        datacube::Octets segment(
            bytes.begin(), bytes.begin() + static_cast<std::ptrdiff_t>(progress));
        if (fault == VirtualFault::corrupt) {
            const auto offset = static_cast<std::size_t>(event->parameter) %
                segment.size();
            segment[offset] ^= corruption_mask(
                state_->schedule.seed, operation_index_value);
        }
        if (fault == VirtualFault::drop) {
            release_grant_if_idle(*state_, endpoint_);
        } else if (fault == VirtualFault::reorder) {
            outgoing.held = std::move(segment);
        } else {
            for (std::size_t copy = 0U; copy < duplicate_copies; ++copy) {
                outgoing.queue.insert(
                    outgoing.queue.end(), segment.begin(), segment.end());
            }
            outgoing.segments.push_back(segment.size() * duplicate_copies);
            if (!outgoing.held.empty()) {
                outgoing.queue.insert(
                    outgoing.queue.end(),
                    outgoing.held.begin(), outgoing.held.end());
                outgoing.segments.push_back(outgoing.held.size());
                outgoing.held.clear();
            }
        }
        record_trace_locked(
            *state_, endpoint_, VirtualOperation::write,
            operation_index_value, event_index_value, delay,
            bytes.size(), progress, VirtualTraceOutcome::progress);
        state_->condition.notify_all();
        return progress;
    }

    void shutdown_write() override {
        if (!state_) {
            return;
        }
        std::lock_guard<std::mutex> lock(state_->mutex);
        const auto own = endpoint_offset(endpoint_);
        if (!state_->alive[own]) {
            return;
        }
        auto& count = state_->operation_counts[own][operation_offset(
            VirtualOperation::shutdown_write)];
        if (count == kMaximumOperationIndex) {
            app_fail(
                "VIRTUAL_OPERATION_LIMIT",
                "virtual shutdown operation limit reached");
        }
        ++count;
        const auto operation_index_value = count;
        std::optional<std::uint32_t> event_index_value;
        const auto* event = scheduled_event(
            *state_, endpoint_, VirtualOperation::shutdown_write,
            operation_index_value, event_index_value);
        const auto fault = event == nullptr ? VirtualFault::none : event->fault;
        if (fault == VirtualFault::reset) {
            reset_locked(*state_);
            record_trace_locked(
                *state_, endpoint_, VirtualOperation::shutdown_write,
                operation_index_value, event_index_value, 0U,
                0U, 0U, VirtualTraceOutcome::reset);
            return;
        }
        if (fault == VirtualFault::disconnect) {
            disconnect_locked(*state_, endpoint_);
            record_trace_locked(
                *state_, endpoint_, VirtualOperation::shutdown_write,
                operation_index_value, event_index_value, 0U,
                0U, 0U, VirtualTraceOutcome::disconnected);
            return;
        }
        auto& outgoing = state_->directions[own];
        if (!outgoing.held.empty()) {
            outgoing.queue.insert(
                outgoing.queue.end(),
                outgoing.held.begin(), outgoing.held.end());
            outgoing.segments.push_back(outgoing.held.size());
            outgoing.held.clear();
        }
        outgoing.write_closed = true;
        record_trace_locked(
            *state_, endpoint_, VirtualOperation::shutdown_write,
            operation_index_value, event_index_value, 0U,
            0U, 0U, VirtualTraceOutcome::progress);
        release_grant_if_idle(*state_, endpoint_);
        state_->condition.notify_all();
    }

private:
    std::shared_ptr<VirtualLinkControl::State> state_;
    VirtualEndpoint endpoint_{VirtualEndpoint::first};
};

}  // namespace

VirtualLinkControl::VirtualLinkControl(std::shared_ptr<State> state) noexcept
    : state_(std::move(state)) {}
VirtualLinkControl::~VirtualLinkControl() = default;

const datacube::Octets& VirtualLinkControl::canonical_schedule() const noexcept {
    return state_->canonical_bytes;
}

const datacube::Digest32& VirtualLinkControl::schedule_digest() const noexcept {
    return state_->digest;
}

VirtualLinkSnapshot VirtualLinkControl::snapshot() const {
    std::lock_guard<std::mutex> lock(state_->mutex);
    auto trace = state_->trace;
    std::sort(
        trace.begin(), trace.end(),
        [](const VirtualTraceRecord& left,
           const VirtualTraceRecord& right) noexcept {
            return std::tuple(
                static_cast<std::uint8_t>(left.endpoint),
                static_cast<std::uint8_t>(left.operation),
                left.operation_index) <
                std::tuple(
                    static_cast<std::uint8_t>(right.endpoint),
                    static_cast<std::uint8_t>(right.operation),
                    right.operation_index);
        });
    return VirtualLinkSnapshot{
        .schedule_digest = state_->digest,
        .seed = state_->schedule.seed,
        .first_to_second_queued = state_->directions[0U].queue.size(),
        .second_to_first_queued = state_->directions[1U].queue.size(),
        .first_alive = state_->alive[0U],
        .second_alive = state_->alive[1U],
        .reset = state_->reset,
        .trace = std::move(trace),
    };
}

void VirtualLinkControl::reset_link() {
    std::lock_guard<std::mutex> lock(state_->mutex);
    reset_locked(*state_);
}

void VirtualLinkControl::disconnect_endpoint(const VirtualEndpoint endpoint) {
    std::lock_guard<std::mutex> lock(state_->mutex);
    disconnect_locked(*state_, endpoint);
}

std::string_view virtual_endpoint_name(const VirtualEndpoint endpoint) noexcept {
    switch (endpoint) {
        case VirtualEndpoint::first:
            return "first";
        case VirtualEndpoint::second:
            return "second";
    }
    return "unknown";
}

std::string_view virtual_operation_name(const VirtualOperation operation) noexcept {
    switch (operation) {
        case VirtualOperation::read:
            return "read";
        case VirtualOperation::write:
            return "write";
        case VirtualOperation::shutdown_write:
            return "shutdown-write";
    }
    return "unknown";
}

std::string_view virtual_fault_name(const VirtualFault fault) noexcept {
    switch (fault) {
        case VirtualFault::none:
            return "none";
        case VirtualFault::timeout:
            return "timeout";
        case VirtualFault::reset:
            return "reset";
        case VirtualFault::disconnect:
            return "disconnect";
        case VirtualFault::drop:
            return "drop";
        case VirtualFault::duplicate:
            return "duplicate";
        case VirtualFault::corrupt:
            return "corrupt";
        case VirtualFault::reorder:
            return "reorder";
    }
    return "unknown";
}

std::string_view virtual_trace_outcome_name(
    const VirtualTraceOutcome outcome) noexcept {
    switch (outcome) {
        case VirtualTraceOutcome::progress:
            return "progress";
        case VirtualTraceOutcome::eof:
            return "eof";
        case VirtualTraceOutcome::timeout:
            return "timeout";
        case VirtualTraceOutcome::reset:
            return "reset";
        case VirtualTraceOutcome::disconnected:
            return "disconnected";
        case VirtualTraceOutcome::write_closed:
            return "write-closed";
    }
    return "unknown";
}

datacube::Octets encode_virtual_carrier_schedule(
    const VirtualCarrierSchedule& input) {
    const auto schedule = canonical_schedule(input);
    datacube::Octets output;
    output.reserve(40U + schedule.events.size() * 24U);
    append_magic(output, kScheduleMagic);
    datacube::append_be16(output, kScheduleVersion);
    std::uint16_t flags = schedule.half_duplex ? kFlagHalfDuplex : 0U;
    if (schedule.initial_grant.has_value()) {
        flags = static_cast<std::uint16_t>(flags | kFlagInitialGrant);
        if (*schedule.initial_grant == VirtualEndpoint::second) {
            flags = static_cast<std::uint16_t>(
                flags | kFlagInitialGrantSecond);
        }
    }
    datacube::append_be16(output, flags);
    datacube::append_be64(output, schedule.seed);
    datacube::append_be32(output, schedule.queue_capacity);
    datacube::append_be32(output, schedule.default_read_chunk);
    datacube::append_be32(output, schedule.default_write_chunk);
    datacube::append_be32(output, schedule.mtu);
    datacube::append_be32(
        output, static_cast<std::uint32_t>(schedule.events.size()));
    for (const auto& event : schedule.events) {
        datacube::append_u8(
            output, static_cast<std::uint8_t>(event.endpoint));
        datacube::append_u8(
            output, static_cast<std::uint8_t>(event.operation));
        datacube::append_u8(
            output, static_cast<std::uint8_t>(event.fault));
        datacube::append_u8(output, 0U);
        datacube::append_be32(output, event.operation_index);
        datacube::append_be32(output, event.delay_steps);
        datacube::append_be32(output, event.maximum_bytes);
        datacube::append_be32(output, event.parameter);
        datacube::append_be32(output, 0U);
    }
    return output;
}

VirtualCarrierSchedule decode_virtual_carrier_schedule(
    const datacube::OctetView bytes) {
    try {
        datacube::Reader reader(bytes, "virtual carrier schedule");
        const auto magic = reader.read_exact(kScheduleMagic.size(), "magic");
        if (!std::equal(magic.begin(), magic.end(), kScheduleMagic.begin())) {
            app_fail("VIRTUAL_SCHEDULE_MALFORMED", "schedule magic is invalid");
        }
        if (reader.read_be16("version") != kScheduleVersion) {
            app_fail("VIRTUAL_SCHEDULE_MALFORMED", "schedule version is unsupported");
        }
        const auto flags = reader.read_be16("flags");
        if ((flags & static_cast<std::uint16_t>(~kKnownScheduleFlags)) != 0U ||
            ((flags & kFlagInitialGrantSecond) != 0U &&
             (flags & kFlagInitialGrant) == 0U)) {
            app_fail("VIRTUAL_SCHEDULE_MALFORMED", "schedule flags are invalid");
        }
        VirtualCarrierSchedule schedule;
        schedule.half_duplex = (flags & kFlagHalfDuplex) != 0U;
        if ((flags & kFlagInitialGrant) != 0U) {
            schedule.initial_grant = (flags & kFlagInitialGrantSecond) != 0U ?
                VirtualEndpoint::second : VirtualEndpoint::first;
        }
        schedule.seed = reader.read_be64("seed");
        schedule.queue_capacity = reader.read_be32("queue capacity");
        schedule.default_read_chunk = reader.read_be32("read chunk");
        schedule.default_write_chunk = reader.read_be32("write chunk");
        schedule.mtu = reader.read_be32("MTU");
        const auto event_count = reader.read_be32("event count");
        if (event_count > kMaximumVirtualScheduleEvents) {
            app_fail("VIRTUAL_SCHEDULE_MALFORMED", "event count exceeds 4096");
        }
        schedule.events.reserve(event_count);
        for (std::uint32_t index = 0U; index < event_count; ++index) {
            const auto endpoint_raw = reader.read_u8("event endpoint");
            const auto operation_raw = reader.read_u8("event operation");
            const auto fault_raw = reader.read_u8("event fault");
            if (reader.read_u8("event reserved byte") != 0U) {
                app_fail(
                    "VIRTUAL_SCHEDULE_MALFORMED",
                    "event reserved byte is nonzero");
            }
            VirtualScheduleEvent event{
                .endpoint = static_cast<VirtualEndpoint>(endpoint_raw),
                .operation = static_cast<VirtualOperation>(operation_raw),
                .fault = static_cast<VirtualFault>(fault_raw),
                .operation_index = reader.read_be32("operation index"),
                .delay_steps = reader.read_be32("delay steps"),
                .maximum_bytes = reader.read_be32("maximum bytes"),
                .parameter = reader.read_be32("fault parameter"),
            };
            if (reader.read_be32("event reserved word") != 0U) {
                app_fail(
                    "VIRTUAL_SCHEDULE_MALFORMED",
                    "event reserved word is nonzero");
            }
            schedule.events.push_back(event);
        }
        reader.require_eof("schedule trailing bytes");
        const auto canonical = canonical_schedule(schedule);
        if (canonical.events != schedule.events) {
            app_fail(
                "VIRTUAL_SCHEDULE_MALFORMED",
                "schedule events are not in canonical order");
        }
        const auto reencoded = encode_virtual_carrier_schedule(canonical);
        if (!std::equal(bytes.begin(), bytes.end(), reencoded.begin(), reencoded.end()) ||
            bytes.size() != reencoded.size()) {
            app_fail(
                "VIRTUAL_SCHEDULE_MALFORMED",
                "schedule representation is not canonical");
        }
        return canonical;
    } catch (const datacube::Failure& error) {
        app_fail("VIRTUAL_SCHEDULE_MALFORMED", error.what());
    }
}

datacube::Digest32 virtual_carrier_schedule_digest(
    const VirtualCarrierSchedule& schedule) {
    return datacube::sha256(encode_virtual_carrier_schedule(schedule));
}

datacube::Octets encode_virtual_trace(
    const std::vector<VirtualTraceRecord>& input) {
    auto trace = input;
    std::sort(
        trace.begin(), trace.end(),
        [](const VirtualTraceRecord& left,
           const VirtualTraceRecord& right) noexcept {
            return std::tuple(
                static_cast<std::uint8_t>(left.endpoint),
                static_cast<std::uint8_t>(left.operation),
                left.operation_index) <
                std::tuple(
                    static_cast<std::uint8_t>(right.endpoint),
                    static_cast<std::uint8_t>(right.operation),
                    right.operation_index);
        });
    if (trace.size() > static_cast<std::size_t>(
            std::numeric_limits<std::uint32_t>::max())) {
        app_fail("VIRTUAL_TRACE_INVALID", "trace record count exceeds uint32");
    }
    datacube::Octets output;
    output.reserve(12U + trace.size() * 36U);
    append_magic(output, kTraceMagic);
    datacube::append_be32(
        output, static_cast<std::uint32_t>(trace.size()));
    for (const auto& record : trace) {
        static_cast<void>(endpoint_offset(record.endpoint));
        static_cast<void>(operation_offset(record.operation));
        datacube::append_u8(
            output, static_cast<std::uint8_t>(record.endpoint));
        datacube::append_u8(
            output, static_cast<std::uint8_t>(record.operation));
        datacube::append_u8(
            output, static_cast<std::uint8_t>(record.outcome));
        datacube::append_u8(output, 0U);
        datacube::append_be32(output, record.operation_index);
        datacube::append_be32(
            output, record.event_index.value_or(kNoEventIndex));
        datacube::append_be32(output, record.delay_steps);
        datacube::append_be64(
            output, static_cast<std::uint64_t>(record.requested_bytes));
        datacube::append_be64(
            output, static_cast<std::uint64_t>(record.result_bytes));
    }
    return output;
}

VirtualLinkPair make_virtual_link(const VirtualCarrierSchedule& input) {
    const auto schedule = canonical_schedule(input);
    auto state = std::make_shared<VirtualLinkControl::State>(schedule);
    auto control = std::shared_ptr<VirtualLinkControl>(
        new VirtualLinkControl(state));
    return VirtualLinkPair{
        .first = std::make_unique<VirtualOrderedByteStream>(
            state, VirtualEndpoint::first),
        .second = std::make_unique<VirtualOrderedByteStream>(
            std::move(state), VirtualEndpoint::second),
        .control = std::move(control),
    };
}

}  // namespace natrav_overlay
