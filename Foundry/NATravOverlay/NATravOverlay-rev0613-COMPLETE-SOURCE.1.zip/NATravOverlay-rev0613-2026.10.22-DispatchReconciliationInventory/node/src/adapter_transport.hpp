#pragma once
#include "config.hpp"
#include "transport.hpp"
#include <memory>
namespace natrav_overlay {
inline constexpr char kConfiguredAdapterTransportMarker[] = "V19_EXACT_CONFIGURED_ADAPTER_TRANSPORT_V1";
// Factories consume an accepted immutable configuration; outbound callers
// hold the runtime generation lease. Parsing and unprepared calls cannot exec.
[[nodiscard]] std::unique_ptr<TransportConnector> make_configured_adapter_connector(
    const RuntimeConfig& accepted, const TransportLocator& locator);
[[nodiscard]] std::unique_ptr<TransportListener> listen_configured_adapter_transport(
    const RuntimeConfig& accepted, const TransportLocator& locator);
}  // namespace natrav_overlay
