#pragma once

#include "custody_policy.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

inline constexpr std::string_view kDurableCustodyEvidenceFeature =
    "DURABLE_CUSTODY_EVIDENCE_V1";
inline constexpr std::size_t kDurableCustodyCaseLimit = 256U;
inline constexpr std::size_t kDurableCustodyEventLimit = 4'096U;
inline constexpr std::size_t kDurableCustodyUncertaintyLimit = 32U;
inline constexpr std::size_t kDurableCustodyEventEncodedLimit = 72'000U;

struct CustodyUncertainty final {
    std::uint64_t event_ms{0U};
    std::string code;
    std::string detail;

    bool operator==(const CustodyUncertainty&) const = default;
};

enum class DurableCustodyEventKind : std::uint8_t {
    registered = 1U,
    record = 2U,
    uncertainty = 3U,
    expired = 4U,
    imported = 5U,
};

struct DurableCustodyEvent final {
    DurableCustodyEventKind kind{DurableCustodyEventKind::registered};
    datacube::Digest32 envelope_sha256;
    std::uint64_t configuration_event{0U};
    std::uint64_t event_ms{0U};
    datacube::Octets envelope;
    datacube::Octets capsule;
    std::vector<CustodyGrantReference> grants;
    datacube::Octets record;
    std::string code;
    std::string detail;
    std::optional<datacube::Digest32> imported_operation;
};

struct DurableCustodyCase final {
    datacube::Digest32 envelope_sha256;
    CustodyEnvelope envelope;
    datacube::Octets capsule;
    std::uint64_t configuration_event{0U};
    std::vector<CustodyGrantReference> grants;
    std::vector<datacube::Octets> records;
    CustodyProgress progress;
    std::vector<CustodyUncertainty> uncertainties;
    std::optional<std::uint64_t> expired_ms;
    std::optional<std::uint64_t> imported_ms;
    std::optional<datacube::Digest32> imported_operation;
};

enum class DurableCustodyDisposition : std::uint8_t {
    applied = 1U,
    duplicate = 2U,
};

[[nodiscard]] datacube::Octets encode_durable_custody_event(
    const DurableCustodyEvent& event);
[[nodiscard]] DurableCustodyEvent decode_durable_custody_event(
    datacube::OctetView bytes);
[[nodiscard]] datacube::Digest32 durable_custody_event_envelope(
    datacube::OctetView bytes);
[[nodiscard]] std::string_view durable_custody_event_kind_name(
    DurableCustodyEventKind kind);

class DurableCustodyRegistry final {
public:
    [[nodiscard]] DurableCustodyDisposition apply(
        const DurableCustodyEvent& event);
    [[nodiscard]] DurableCustodyDisposition apply_encoded(
        datacube::OctetView bytes);
    [[nodiscard]] const DurableCustodyCase* find(
        const datacube::Digest32& envelope) const noexcept;
    [[nodiscard]] std::vector<DurableCustodyCase> cases() const;
    [[nodiscard]] const std::vector<datacube::Octets>& events() const noexcept;
    [[nodiscard]] std::string status_json() const;
    [[nodiscard]] std::size_t active_count() const noexcept;
    [[nodiscard]] std::uint64_t retained_capsule_bytes() const noexcept;

private:
    std::map<std::string, DurableCustodyCase> cases_;
    std::vector<datacube::Octets> events_;
    std::map<std::string, bool> event_digests_;
    std::uint64_t retained_capsule_bytes_{0U};
};

} // namespace natrav_overlay
