#include "unix_datagram_transport.hpp"

#include "packet_port.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <limits>
#include <memory>
#include <mutex>
#include <optional>
#include <poll.h>
#include <span>
#include <string>
#include <string_view>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/un.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace natrav_overlay {

int unix_datagram_packet_carrier_revision_abi() noexcept { return 1; }

namespace {

inline constexpr std::string_view kUnixDatagramPrefix = "unix-dgram-v1|";
inline constexpr std::uint8_t kUnixDatagramProfile = 1U;
inline constexpr std::uint16_t kMinimumUnixDatagramMtu = 256U;
inline constexpr std::uint16_t kMaximumUnixDatagramMtu = 65'507U;
inline constexpr int kUnixDatagramSocketBufferBytes = 262'144;
inline constexpr std::chrono::milliseconds kUnixDatagramTickInterval{10};
inline constexpr std::chrono::milliseconds kListenerReopenDelay{100};
inline constexpr std::chrono::milliseconds kShutdownBudget{2'000};
inline constexpr std::size_t kMaximumUnixPathBytes =
    sizeof(sockaddr_un{}.sun_path) - 1U;

struct PathObservation final {
    dev_t device{0};
    ino_t inode{0};
    uid_t owner{0};
    mode_t mode{0};
};

struct SecureParent final {
    datacube::Fd fd;
    std::string absolute_path;
    std::string leaf;
    PathObservation observation;
};

struct WatchedPath final {
    SecureParent parent;
    std::string absolute_path;
    PathObservation observation;
};

struct UnixAddress final {
    sockaddr_un address{};
    socklen_t length{0};
};

struct UnixDatagramListenerLease final {
    std::atomic<bool> active{false};
};

[[nodiscard]] bool same_object(
    const PathObservation& left,
    const PathObservation& right) noexcept {
    return left.device == right.device && left.inode == right.inode;
}

[[nodiscard]] PathObservation observation_from_stat(
    const struct stat& status) noexcept {
    return PathObservation{
        .device = status.st_dev,
        .inode = status.st_ino,
        .owner = status.st_uid,
        .mode = status.st_mode,
    };
}

[[nodiscard]] std::vector<std::string_view> split_fields(
    const std::string_view text) {
    std::vector<std::string_view> fields;
    std::size_t begin = 0U;
    while (begin <= text.size()) {
        const auto separator = text.find('|', begin);
        if (separator == std::string_view::npos) {
            fields.push_back(text.substr(begin));
            break;
        }
        fields.push_back(text.substr(begin, separator - begin));
        begin = separator + 1U;
    }
    return fields;
}

[[nodiscard]] std::string_view field_value(
    const std::string_view field,
    const std::string_view name) {
    const std::string prefix = std::string(name) + "=";
    if (!field.starts_with(prefix) || field.size() == prefix.size()) {
        app_fail(
            "UNIX_DATAGRAM_LOCATOR_INVALID",
            "expected nonempty field " + std::string(name));
    }
    return field.substr(prefix.size());
}

[[nodiscard]] bool unreserved_path_byte(const unsigned char value) noexcept {
    return (value >= static_cast<unsigned char>('A') &&
            value <= static_cast<unsigned char>('Z')) ||
        (value >= static_cast<unsigned char>('a') &&
         value <= static_cast<unsigned char>('z')) ||
        (value >= static_cast<unsigned char>('0') &&
         value <= static_cast<unsigned char>('9')) ||
        value == static_cast<unsigned char>('/') ||
        value == static_cast<unsigned char>('.') ||
        value == static_cast<unsigned char>('_') ||
        value == static_cast<unsigned char>('-') ||
        value == static_cast<unsigned char>('~');
}

[[nodiscard]] std::string encode_path(const std::string_view path) {
    static constexpr char kHex[] = "0123456789ABCDEF";
    std::string encoded;
    encoded.reserve(path.size());
    for (const char raw : path) {
        const auto value = static_cast<unsigned char>(raw);
        if (unreserved_path_byte(value)) {
            encoded.push_back(static_cast<char>(value));
        } else {
            encoded.push_back('%');
            encoded.push_back(kHex[(value >> 4U) & 0x0fU]);
            encoded.push_back(kHex[value & 0x0fU]);
        }
    }
    return encoded;
}

[[nodiscard]] std::optional<unsigned char> hex_value(
    const char value) noexcept {
    if (value >= '0' && value <= '9') {
        return static_cast<unsigned char>(value - '0');
    }
    if (value >= 'A' && value <= 'F') {
        return static_cast<unsigned char>(10 + value - 'A');
    }
    if (value >= 'a' && value <= 'f') {
        return static_cast<unsigned char>(10 + value - 'a');
    }
    return std::nullopt;
}

void validate_path_syntax(const std::string_view path) {
    const bool has_control = std::any_of(
        path.begin(), path.end(), [](const char raw) {
            const auto value = static_cast<unsigned char>(raw);
            return value < 0x20U || value == 0x7fU;
        });
    if (path.size() < 2U || path.size() > kMaximumUnixPathBytes ||
        path.front() != '/' || path.back() == '/' || has_control) {
        app_fail(
            "UNIX_DATAGRAM_LOCATOR_INVALID",
            "Unix datagram paths must be absolute canonical paths within sun_path");
    }
    std::size_t begin = 1U;
    while (begin < path.size()) {
        const auto end = path.find('/', begin);
        const auto component = path.substr(
            begin,
            end == std::string_view::npos ? path.size() - begin : end - begin);
        if (component.empty() || component == "." || component == "..") {
            app_fail(
                "UNIX_DATAGRAM_LOCATOR_INVALID",
                "Unix datagram paths must not contain empty, dot, or dot-dot components");
        }
        if (end == std::string_view::npos) {
            break;
        }
        begin = end + 1U;
    }
}

[[nodiscard]] std::string decode_path(const std::string_view encoded) {
    std::string path;
    path.reserve(encoded.size());
    for (std::size_t offset = 0U; offset < encoded.size();) {
        if (encoded[offset] != '%') {
            path.push_back(encoded[offset]);
            ++offset;
            continue;
        }
        if (offset + 2U >= encoded.size()) {
            app_fail("UNIX_DATAGRAM_LOCATOR_INVALID", "truncated path escape");
        }
        const auto high = hex_value(encoded[offset + 1U]);
        const auto low = hex_value(encoded[offset + 2U]);
        if (!high.has_value() || !low.has_value()) {
            app_fail("UNIX_DATAGRAM_LOCATOR_INVALID", "invalid path escape");
        }
        const auto value = static_cast<unsigned char>(
            static_cast<unsigned>(*high) * 16U + static_cast<unsigned>(*low));
        if (value < 0x20U || value == 0x7fU) {
            app_fail(
                "UNIX_DATAGRAM_LOCATOR_INVALID",
                "Unix datagram path contains a control byte");
        }
        path.push_back(static_cast<char>(value));
        offset += 3U;
    }
    validate_path_syntax(path);
    return path;
}

[[nodiscard]] std::uint64_t parse_link_id(const std::string_view text) {
    if (text.size() != 16U) {
        app_fail(
            "UNIX_DATAGRAM_LOCATOR_INVALID",
            "link must be exactly 16 lowercase hexadecimal digits");
    }
    std::uint64_t value = 0U;
    for (const char digit : text) {
        std::uint8_t nibble = 0U;
        if (digit >= '0' && digit <= '9') {
            nibble = static_cast<std::uint8_t>(digit - '0');
        } else if (digit >= 'a' && digit <= 'f') {
            nibble = static_cast<std::uint8_t>(10 + digit - 'a');
        } else {
            app_fail(
                "UNIX_DATAGRAM_LOCATOR_INVALID",
                "link must be exactly 16 lowercase hexadecimal digits");
        }
        value = (value << 4U) | static_cast<std::uint64_t>(nibble);
    }
    if (value == 0U) {
        app_fail(
            "UNIX_DATAGRAM_LOCATOR_INVALID",
            "link identifier must be nonzero");
    }
    return value;
}

[[nodiscard]] std::string link_id_text(const std::uint64_t value) {
    if (value == 0U) {
        app_fail(
            "UNIX_DATAGRAM_LOCATOR_INVALID",
            "link identifier must be nonzero");
    }
    static constexpr char kHex[] = "0123456789abcdef";
    std::string result(16U, '0');
    for (std::size_t index = 0U; index < result.size(); ++index) {
        const auto shift = static_cast<unsigned>((result.size() - 1U - index) * 4U);
        result[index] = kHex[(value >> shift) & 0x0fU];
    }
    return result;
}

[[nodiscard]] UnixAddress unix_address(const std::string_view path) {
    validate_path_syntax(path);
    UnixAddress result;
    result.address.sun_family = AF_UNIX;
    std::memcpy(result.address.sun_path, path.data(), path.size());
    result.address.sun_path[path.size()] = '\0';
    result.length = static_cast<socklen_t>(
        offsetof(sockaddr_un, sun_path) + path.size() + 1U);
    return result;
}

[[nodiscard]] SecureParent open_secure_parent(
    const std::string_view path,
    const std::string_view role) {
    validate_path_syntax(path);
    const auto slash = path.rfind('/');
    const std::string parent_path = slash == 0U ? "/" : std::string(path.substr(0U, slash));
    const std::string leaf(path.substr(slash + 1U));

    const int root_raw = ::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (root_raw < 0) {
        app_fail(
            "UNIX_DATAGRAM_PARENT_INVALID",
            datacube::errno_detail(std::string(role) + " root", errno));
    }
    datacube::Fd current(root_raw);
    std::size_t begin = 1U;
    while (begin < parent_path.size()) {
        const auto end = parent_path.find('/', begin);
        const auto component = parent_path.substr(
            begin,
            end == std::string::npos ? parent_path.size() - begin : end - begin);
        const int next_raw = ::openat(
            current.get(),
            component.c_str(),
            O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
        if (next_raw < 0) {
            app_fail(
                "UNIX_DATAGRAM_PARENT_INVALID",
                datacube::errno_detail(
                    std::string(role) + " parent component " + component,
                    errno));
        }
        current.reset(next_raw);
        if (end == std::string::npos) {
            break;
        }
        begin = end + 1U;
    }

    struct stat descriptor_status {};
    struct stat path_status {};
    if (::fstat(current.get(), &descriptor_status) != 0 ||
        ::lstat(parent_path.c_str(), &path_status) != 0) {
        app_fail(
            "UNIX_DATAGRAM_PARENT_INVALID",
            datacube::errno_detail(std::string(role) + " parent", errno));
    }
    const auto descriptor_observation = observation_from_stat(descriptor_status);
    const auto path_observation = observation_from_stat(path_status);
    if (!S_ISDIR(descriptor_status.st_mode) ||
        !S_ISDIR(path_status.st_mode) ||
        !same_object(descriptor_observation, path_observation) ||
        descriptor_status.st_uid != ::geteuid() ||
        (descriptor_status.st_mode & (S_IRWXG | S_IRWXO)) != 0 ||
        (descriptor_status.st_mode & (S_IWUSR | S_IXUSR)) !=
            (S_IWUSR | S_IXUSR)) {
        app_fail(
            "UNIX_DATAGRAM_PARENT_UNSAFE",
            std::string(role) +
                " parent must be a stable owner-controlled directory without group or other access");
    }
    return SecureParent{
        .fd = std::move(current),
        .absolute_path = parent_path,
        .leaf = leaf,
        .observation = descriptor_observation,
    };
}

[[nodiscard]] std::optional<PathObservation> observe_leaf(
    const SecureParent& parent) {
    struct stat status {};
    if (::fstatat(
            parent.fd.get(),
            parent.leaf.c_str(),
            &status,
            AT_SYMLINK_NOFOLLOW) == 0) {
        return observation_from_stat(status);
    }
    if (errno == ENOENT) {
        return std::nullopt;
    }
    app_fail(
        "UNIX_DATAGRAM_PATH_STAT_FAILED",
        datacube::errno_detail(parent.absolute_path + "/" + parent.leaf, errno));
}

[[nodiscard]] PathObservation observe_exact_path(
    const SecureParent& parent,
    const std::string_view absolute_path,
    const std::string_view role) {
    const auto relative = observe_leaf(parent);
    struct stat absolute_status {};
    if (!relative.has_value() ||
        ::lstat(std::string(absolute_path).c_str(), &absolute_status) != 0) {
        app_fail(
            "UNIX_DATAGRAM_PATH_REPLACED",
            std::string(role) + " socket path is absent or replaced");
    }
    const auto absolute = observation_from_stat(absolute_status);
    if (!same_object(*relative, absolute)) {
        app_fail(
            "UNIX_DATAGRAM_PATH_REPLACED",
            std::string(role) + " socket path no longer names the observed object");
    }
    return absolute;
}

void require_socket_path(
    const PathObservation& observation,
    const std::string_view role) {
    if (!S_ISSOCK(observation.mode)) {
        app_fail(
            "UNIX_DATAGRAM_PATH_NOT_SOCKET",
            std::string(role) + " path is not a Unix socket");
    }
    if (observation.owner != ::geteuid() ||
        (observation.mode & (S_IRWXG | S_IRWXO)) != 0 ||
        (observation.mode & S_IWUSR) == 0) {
        app_fail(
            "UNIX_DATAGRAM_PATH_UNSAFE",
            std::string(role) +
                " socket must be owner-controlled and inaccessible to group and other users");
    }
}

[[nodiscard]] WatchedPath watch_remote_path(
    const std::string& path) {
    auto parent = open_secure_parent(path, "remote");
    const auto observation = observe_exact_path(parent, path, "remote");
    require_socket_path(observation, "remote");
    return WatchedPath{
        .parent = std::move(parent),
        .absolute_path = path,
        .observation = observation,
    };
}

void verify_watched_path(
    const WatchedPath& watched,
    const std::string_view role) {
    struct stat parent_status {};
    struct stat parent_path_status {};
    if (::fstat(watched.parent.fd.get(), &parent_status) != 0 ||
        ::lstat(watched.parent.absolute_path.c_str(), &parent_path_status) != 0) {
        app_fail(
            "UNIX_DATAGRAM_PATH_REPLACED",
            std::string(role) + " parent is absent or replaced");
    }
    if (!same_object(
            observation_from_stat(parent_status),
            observation_from_stat(parent_path_status)) ||
        !same_object(
            observe_exact_path(
                watched.parent, watched.absolute_path, role),
            watched.observation)) {
        app_fail(
            "UNIX_DATAGRAM_PATH_REPLACED",
            std::string(role) + " path identity changed");
    }
}

void cleanup_owned_path_noexcept(WatchedPath& local) noexcept {
    try {
        struct stat parent_status {};
        struct stat parent_path_status {};
        struct stat relative_status {};
        struct stat absolute_status {};
        if (::fstat(local.parent.fd.get(), &parent_status) != 0 ||
            ::lstat(local.parent.absolute_path.c_str(), &parent_path_status) != 0 ||
            !same_object(
                observation_from_stat(parent_status),
                observation_from_stat(parent_path_status)) ||
            ::fstatat(
                local.parent.fd.get(),
                local.parent.leaf.c_str(),
                &relative_status,
                AT_SYMLINK_NOFOLLOW) != 0 ||
            ::lstat(local.absolute_path.c_str(), &absolute_status) != 0) {
            return;
        }
        const auto relative = observation_from_stat(relative_status);
        const auto absolute = observation_from_stat(absolute_status);
        if (same_object(relative, local.observation) &&
            same_object(absolute, local.observation) &&
            S_ISSOCK(relative.mode)) {
            static_cast<void>(::unlinkat(
                local.parent.fd.get(), local.parent.leaf.c_str(), 0));
        }
    } catch (...) {
    }
}

[[nodiscard]] WatchedPath bind_owned_path(
    const int fd,
    const std::string& path,
    const std::string_view failure_code) {
    auto parent = open_secure_parent(path, "local");
    const auto existing = observe_leaf(parent);
    if (existing.has_value()) {
        app_fail(
            S_ISLNK(existing->mode) ?
                "UNIX_DATAGRAM_PATH_SYMLINK" :
                "UNIX_DATAGRAM_PATH_OCCUPIED",
            "local Unix datagram path already exists; stale paths require explicit operator removal");
    }
    const auto address = unix_address(path);
    if (::bind(
            fd,
            reinterpret_cast<const sockaddr*>(&address.address),
            address.length) != 0) {
        app_fail(failure_code, datacube::errno_detail("bind " + path, errno));
    }
    if (::fchmodat(
            parent.fd.get(),
            parent.leaf.c_str(),
            S_IRUSR | S_IWUSR,
            0) != 0) {
        const int saved = errno;
        static_cast<void>(::unlinkat(parent.fd.get(), parent.leaf.c_str(), 0));
        app_fail(
            "UNIX_DATAGRAM_PERMISSION_FAILED",
            datacube::errno_detail(path, saved));
    }
    const auto observation = observe_exact_path(parent, path, "local");
    require_socket_path(observation, "local");
    return WatchedPath{
        .parent = std::move(parent),
        .absolute_path = path,
        .observation = observation,
    };
}

[[nodiscard]] natrav::packet_link::Limits unix_datagram_profile_limits(
    const UnixDatagramTransportLocator& locator) {
    if (locator.profile != kUnixDatagramProfile) {
        app_fail(
            "UNIX_DATAGRAM_PROFILE_UNSUPPORTED",
            "unix-dgram-v1 supports only profile=1");
    }
    natrav::packet_link::Limits limits;
    limits.mtu = locator.mtu;
    limits.max_message_bytes = 256U * 1024U;
    limits.max_reassembly_bytes = 2U * 1024U * 1024U;
    limits.max_delivery_bytes = 2U * 1024U * 1024U;
    limits.max_inflight_frames = 512U;
    limits.max_control_frames = 512U;
    limits.max_receive_packets_per_pump = 512U;
    limits.retransmit_after_ticks = 5U;
    limits.retry_limit = 20U;
    limits.message_expiry_ticks = 2'000U;
    limits.validate();
    return limits;
}

[[nodiscard]] int poll_timeout_ms(const Deadline wake) {
    const auto now = std::chrono::steady_clock::now();
    if (now >= wake) {
        return 0;
    }
    const auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(
        wake - now);
    const auto count = std::max<std::chrono::milliseconds::rep>(
        remaining.count(), 1);
    return static_cast<int>(std::min<std::chrono::milliseconds::rep>(
        count, static_cast<std::chrono::milliseconds::rep>(INT_MAX)));
}

[[nodiscard]] bool reset_errno(const int value) noexcept {
    return value == ECONNREFUSED || value == ECONNRESET || value == EPIPE ||
        value == ENOENT || value == ENOTCONN;
}

void make_nonblocking(const int fd) {
    const int flags = ::fcntl(fd, F_GETFL, 0);
    if (flags < 0 || ::fcntl(fd, F_SETFL, flags | O_NONBLOCK) != 0) {
        app_fail(
            "UNIX_DATAGRAM_SOCKET_CONFIG_FAILED",
            datacube::errno_detail("Unix datagram O_NONBLOCK", errno));
    }
}

[[nodiscard]] std::optional<std::string> source_path_from_message(
    const msghdr& message) {
    if (message.msg_name == nullptr ||
        message.msg_namelen <= offsetof(sockaddr_un, sun_path)) {
        return std::nullopt;
    }
    const auto* source = static_cast<const sockaddr_un*>(message.msg_name);
    if (source->sun_family != AF_UNIX || source->sun_path[0] == '\0') {
        return std::nullopt;
    }
    std::size_t bytes = static_cast<std::size_t>(message.msg_namelen) -
        offsetof(sockaddr_un, sun_path);
    bytes = std::min(bytes, sizeof(source->sun_path));
    const auto* terminator = static_cast<const char*>(
        std::memchr(source->sun_path, '\0', bytes));
    if (terminator != nullptr) {
        bytes = static_cast<std::size_t>(terminator - source->sun_path);
    }
    if (bytes == 0U) {
        return std::nullopt;
    }
    return std::string(source->sun_path, bytes);
}

[[nodiscard]] std::optional<uid_t> credential_uid(const msghdr& message) {
    for (auto* header = CMSG_FIRSTHDR(const_cast<msghdr*>(&message));
         header != nullptr;
         header = CMSG_NXTHDR(const_cast<msghdr*>(&message), header)) {
        if (header->cmsg_level == SOL_SOCKET &&
            header->cmsg_type == SCM_CREDENTIALS &&
            header->cmsg_len >= CMSG_LEN(sizeof(ucred))) {
            ucred credentials{};
            std::memcpy(&credentials, CMSG_DATA(header), sizeof(credentials));
            return credentials.uid;
        }
    }
    return std::nullopt;
}

class UnixDatagramPacketPort final : public OwnedCompleteDatagramPacketPort {
public:
    UnixDatagramPacketPort(
        datacube::Fd fd,
        const std::size_t mtu,
        WatchedPath local,
        std::string remote_path) noexcept
        : fd_(std::move(fd)),
          mtu_(mtu),
          local_(std::move(local)),
          remote_path_(std::move(remote_path)) {}

    ~UnixDatagramPacketPort() override {
        fd_.reset();
        cleanup_owned_path_noexcept(local_);
        if (lease_) {
            lease_->active.store(false, std::memory_order_release);
        }
    }

    [[nodiscard]] TransportKind transport_kind() const noexcept override {
        return TransportKind::unix_datagram;
    }

    [[nodiscard]] std::size_t mtu() const noexcept override { return mtu_; }

    [[nodiscard]] int readiness_handle() const noexcept { return fd_.get(); }

    void activate_listener_lease(
        std::shared_ptr<UnixDatagramListenerLease> lease) {
        if (!lease || lease_ ||
            lease->active.exchange(true, std::memory_order_acq_rel)) {
            app_fail(
                "UNIX_DATAGRAM_LISTENER_LEASE_INVALID",
                "Unix datagram listener lease is already active");
        }
        lease_ = std::move(lease);
    }

    void connect_expected_remote(const std::string_view failure_code) {
        if (connected_) {
            return;
        }
        auto remote = watch_remote_path(remote_path_);
        if (same_object(local_.observation, remote.observation)) {
            app_fail(
                "UNIX_DATAGRAM_PATH_ALIAS",
                "local and remote paths resolve to the same socket object");
        }
        const auto address = unix_address(remote_path_);
        if (::connect(
                fd_.get(),
                reinterpret_cast<const sockaddr*>(&address.address),
                address.length) != 0) {
            app_fail(
                failure_code,
                datacube::errno_detail("connect " + remote_path_, errno));
        }
        remote_ = std::move(remote);
        connected_ = true;
    }

    [[nodiscard]] bool receive_ready_and_connect() {
        verify_watched_path(local_, "local");
        if (connected_) {
            return receive_ready();
        }
        sockaddr_un source{};
        std::array<std::uint8_t, 1U> payload{};
        std::array<std::byte, CMSG_SPACE(sizeof(ucred))> control{};
        iovec vector{.iov_base = payload.data(), .iov_len = payload.size()};
        msghdr message{};
        message.msg_name = &source;
        message.msg_namelen = static_cast<socklen_t>(sizeof(source));
        message.msg_iov = &vector;
        message.msg_iovlen = 1U;
        message.msg_control = control.data();
        message.msg_controllen = control.size();
        const ssize_t count = ::recvmsg(
            fd_.get(), &message, MSG_DONTWAIT | MSG_PEEK | MSG_TRUNC);
        if (count < 0) {
            if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK) {
                return false;
            }
            app_fail(
                "UNIX_DATAGRAM_RECEIVE_FAILED",
                datacube::errno_detail("Unix datagram listener peek", errno));
        }
        const auto source_path = source_path_from_message(message);
        const auto uid = credential_uid(message);
        if (!source_path.has_value() || *source_path != remote_path_ ||
            !uid.has_value() || *uid != ::geteuid()) {
            std::array<std::uint8_t, 1U> discard{};
            static_cast<void>(::recv(
                fd_.get(), discard.data(), discard.size(),
                MSG_DONTWAIT | MSG_TRUNC));
            return false;
        }
        connect_expected_remote("LISTEN_FAILED");
        return true;
    }

    [[nodiscard]] bool send_packet(
        const natrav::packet_link::Bytes& packet) override {
        require_connected("Unix datagram send");
        verify_paths();
        if (packet.empty() || packet.size() > mtu_) {
            app_fail(
                "UNIX_DATAGRAM_PACKET_INVALID",
                "outbound datagram violates the configured MTU");
        }
        while (true) {
            const ssize_t count = ::send(
                fd_.get(), packet.data(), packet.size(), MSG_NOSIGNAL);
            if (count >= 0) {
                if (static_cast<std::size_t>(count) != packet.size()) {
                    app_fail(
                        "UNIX_DATAGRAM_SEND_FAILED",
                        "datagram send was unexpectedly partial");
                }
                write_blocked_ = false;
                return true;
            }
            if (errno == EINTR) {
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                write_blocked_ = true;
                return false;
            }
            if (reset_errno(errno)) {
                app_fail(
                    "PEER_RESET",
                    datacube::errno_detail("Unix datagram send", errno));
            }
            app_fail(
                "UNIX_DATAGRAM_SEND_FAILED",
                datacube::errno_detail("Unix datagram send", errno));
        }
    }

    [[nodiscard]] std::optional<natrav::packet_link::Bytes>
    receive_packet() override {
        require_connected("Unix datagram receive");
        verify_paths();
        natrav::packet_link::Bytes packet(mtu_);
        std::array<std::byte, CMSG_SPACE(sizeof(ucred))> control{};
        iovec vector{.iov_base = packet.data(), .iov_len = packet.size()};
        msghdr message{};
        message.msg_iov = &vector;
        message.msg_iovlen = 1U;
        message.msg_control = control.data();
        message.msg_controllen = control.size();
        while (true) {
            message.msg_flags = 0;
            message.msg_controllen = control.size();
            const ssize_t count = ::recvmsg(
                fd_.get(), &message, MSG_DONTWAIT | MSG_TRUNC);
            if (count >= 0) {
                if ((message.msg_flags & MSG_TRUNC) != 0 ||
                    static_cast<std::size_t>(count) > mtu_) {
                    app_fail(
                        "UNIX_DATAGRAM_TRUNCATED",
                        "received datagram exceeds the configured receive MTU");
                }
                const auto uid = credential_uid(message);
                if (!uid.has_value() || *uid != ::geteuid()) {
                    app_fail(
                        "UNIX_DATAGRAM_SOURCE_UNAUTHORIZED",
                        "received datagram does not carry the expected owner credential");
                }
                packet.resize(static_cast<std::size_t>(count));
                return packet;
            }
            if (errno == EINTR) {
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                return std::nullopt;
            }
            if (reset_errno(errno)) {
                app_fail(
                    "PEER_RESET",
                    datacube::errno_detail("Unix datagram receive", errno));
            }
            app_fail(
                "UNIX_DATAGRAM_RECEIVE_FAILED",
                datacube::errno_detail("Unix datagram receive", errno));
        }
    }

    void wait_for_progress(
        const Deadline wake_deadline,
        const Deadline operation_deadline,
        IoCounters& counters,
        const std::string_view operation) override {
        require_connected(operation);
        verify_paths();
        const auto now = std::chrono::steady_clock::now();
        if (now >= operation_deadline) {
            app_fail("IO_TIMEOUT", std::string(operation));
        }
        pollfd item{
            .fd = fd_.get(),
            .events = static_cast<short>(POLLIN | (write_blocked_ ? POLLOUT : 0)),
            .revents = 0,
        };
        ++counters.poll_calls;
        int result = 0;
        do {
            result = ::poll(&item, 1U, poll_timeout_ms(wake_deadline));
            if (result < 0 && errno == EINTR) {
                ++counters.interrupted;
            }
        } while (result < 0 && errno == EINTR);
        if (result < 0) {
            app_fail(
                "UNIX_DATAGRAM_POLL_FAILED",
                datacube::errno_detail(operation, errno));
        }
        if (result == 0) {
            ++counters.would_block;
            if (std::chrono::steady_clock::now() >= operation_deadline) {
                app_fail("IO_TIMEOUT", std::string(operation));
            }
            return;
        }
        if ((item.revents & POLLNVAL) != 0) {
            app_fail("UNIX_DATAGRAM_SOCKET_INVALID", std::string(operation));
        }
        if ((item.revents & POLLOUT) != 0) {
            write_blocked_ = false;
        }
        if ((item.revents & (POLLERR | POLLHUP)) != 0 &&
            (item.revents & POLLIN) == 0) {
            throw_socket_error(operation);
        }
    }

private:
    [[nodiscard]] bool receive_ready() const {
        pollfd item{.fd = fd_.get(), .events = POLLIN, .revents = 0};
        int result = 0;
        do {
            result = ::poll(&item, 1U, 0);
        } while (result < 0 && errno == EINTR);
        if (result < 0) {
            app_fail(
                "UNIX_DATAGRAM_POLL_FAILED",
                datacube::errno_detail("Unix datagram listener readiness", errno));
        }
        if (result == 0 || (item.revents & POLLIN) == 0) {
            return false;
        }
        if ((item.revents & POLLNVAL) != 0) {
            app_fail(
                "UNIX_DATAGRAM_SOCKET_INVALID",
                "Unix datagram listener descriptor");
        }
        return true;
    }

    void require_connected(const std::string_view operation) const {
        if (fd_.get() < 0 || !connected_ || !remote_.has_value()) {
            app_fail("UNIX_DATAGRAM_SOCKET_INVALID", std::string(operation));
        }
    }

    void verify_paths() const {
        verify_watched_path(local_, "local");
        if (!remote_.has_value()) {
            app_fail(
                "UNIX_DATAGRAM_SOCKET_INVALID",
                "Unix datagram remote path is not connected");
        }
        verify_watched_path(*remote_, "remote");
    }

    void throw_socket_error(const std::string_view operation) const {
        int socket_error = 0;
        socklen_t length = static_cast<socklen_t>(sizeof(socket_error));
        if (::getsockopt(
                fd_.get(), SOL_SOCKET, SO_ERROR, &socket_error, &length) != 0) {
            app_fail(
                "UNIX_DATAGRAM_SOCKET_ERROR",
                datacube::errno_detail(operation, errno));
        }
        if (socket_error == 0) {
            return;
        }
        if (reset_errno(socket_error)) {
            app_fail(
                "PEER_RESET",
                datacube::errno_detail(operation, socket_error));
        }
        app_fail(
            "UNIX_DATAGRAM_SOCKET_ERROR",
            datacube::errno_detail(operation, socket_error));
    }

    datacube::Fd fd_;
    std::size_t mtu_{0U};
    WatchedPath local_;
    std::string remote_path_;
    std::optional<WatchedPath> remote_;
    bool connected_{false};
    bool write_blocked_{false};
    std::shared_ptr<UnixDatagramListenerLease> lease_{};
};

[[nodiscard]] std::unique_ptr<UnixDatagramPacketPort>
open_unix_datagram_packet_port(
    const UnixDatagramTransportLocator& locator,
    const std::string_view failure_code,
    const bool connect_remote) {
    static_cast<void>(unix_datagram_profile_limits(locator));
    if (locator.local_path == locator.remote_path) {
        app_fail(
            "UNIX_DATAGRAM_PATH_ALIAS",
            "local and remote Unix datagram paths must differ");
    }
    const int raw = ::socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
    if (raw < 0) {
        app_fail(
            failure_code,
            datacube::errno_detail("Unix datagram socket", errno));
    }
    datacube::Fd fd(raw);
    const int enabled = 1;
    if (::setsockopt(
            fd.get(), SOL_SOCKET, SO_PASSCRED,
            &enabled, static_cast<socklen_t>(sizeof(enabled))) != 0 ||
        ::setsockopt(
            fd.get(), SOL_SOCKET, SO_RCVBUF,
            &kUnixDatagramSocketBufferBytes,
            static_cast<socklen_t>(sizeof(kUnixDatagramSocketBufferBytes))) != 0 ||
        ::setsockopt(
            fd.get(), SOL_SOCKET, SO_SNDBUF,
            &kUnixDatagramSocketBufferBytes,
            static_cast<socklen_t>(sizeof(kUnixDatagramSocketBufferBytes))) != 0) {
        app_fail(
            "UNIX_DATAGRAM_SOCKET_CONFIG_FAILED",
            datacube::errno_detail("Unix datagram socket options", errno));
    }
    make_nonblocking(fd.get());
    auto local = bind_owned_path(fd.get(), locator.local_path, failure_code);
    auto port = std::make_unique<UnixDatagramPacketPort>(
        std::move(fd), locator.mtu, std::move(local), locator.remote_path);
    if (connect_remote) {
        port->connect_expected_remote(failure_code);
    }
    return port;
}

[[nodiscard]] PacketPortOrderedStreamOptions unix_datagram_stream_options(
    const UnixDatagramTransportLocator& locator) {
    return PacketPortOrderedStreamOptions{
        .limits = unix_datagram_profile_limits(locator),
        .stream_id = locator.link_id,
        .epoch = locator.epoch,
        .tick_interval = kUnixDatagramTickInterval,
        .shutdown_budget = kShutdownBudget,
        .invalid_stream_code = "UNIX_DATAGRAM_STREAM_INVALID",
        .logical_clock_invalid_code = "UNIX_DATAGRAM_LOGICAL_CLOCK_INVALID",
        .logical_clock_exhausted_code = "UNIX_DATAGRAM_LOGICAL_CLOCK_EXHAUSTED",
        .shutdown_operation = "Unix datagram packet-link shutdown",
    };
}

class UnixDatagramTransportConnector final : public TransportConnector {
public:
    [[nodiscard]] std::unique_ptr<OrderedByteStream> connect(
        const TransportLocator& locator,
        const Deadline deadline,
        IoCounters& counters) const override {
        static_cast<void>(counters);
        if (std::chrono::steady_clock::now() >= deadline) {
            app_fail("IO_TIMEOUT", "Unix datagram connect");
        }
        const auto& unix_datagram = unix_datagram_transport_locator(locator);
        auto port = open_unix_datagram_packet_port(
            unix_datagram, "CONNECT_FAILED", true);
        if (std::chrono::steady_clock::now() >= deadline) {
            app_fail("IO_TIMEOUT", "Unix datagram connect");
        }
        return make_packet_port_ordered_byte_stream(
            std::move(port), unix_datagram_stream_options(unix_datagram));
    }
};

class UnixDatagramTransportListener final : public TransportListener {
public:
    explicit UnixDatagramTransportListener(TransportLocator locator)
        : locator_(std::move(locator)),
          lease_(std::make_shared<UnixDatagramListenerLease>()),
          pending_(open_unix_datagram_packet_port(
              unix_datagram_transport_locator(locator_),
              "LISTEN_FAILED",
              false)) {}

    [[nodiscard]] TransportKind transport_kind() const noexcept override {
        return TransportKind::unix_datagram;
    }

    [[nodiscard]] int readiness_handle() const noexcept override {
        std::lock_guard<std::mutex> lock(mutex_);
        if (lease_->active.load(std::memory_order_acquire)) {
            return -1;
        }
        if (!pending_) {
            const auto now = std::chrono::steady_clock::now();
            if (now < reopen_after_) {
                return -1;
            }
            try {
                pending_ = open_unix_datagram_packet_port(
                    unix_datagram_transport_locator(locator_),
                    "LISTEN_FAILED",
                    false);
            } catch (...) {
                reopen_after_ = now + kListenerReopenDelay;
                return -1;
            }
        }
        return pending_->readiness_handle();
    }

    [[nodiscard]] TransportLocator bound_locator() const override {
        return locator_;
    }

    [[nodiscard]] std::unique_ptr<OrderedByteStream> accept_ready() override {
        std::lock_guard<std::mutex> lock(mutex_);
        if (lease_->active.load(std::memory_order_acquire)) {
            return nullptr;
        }
        if (!pending_) {
            pending_ = open_unix_datagram_packet_port(
                unix_datagram_transport_locator(locator_),
                "LISTEN_FAILED",
                false);
        }
        if (!pending_->receive_ready_and_connect()) {
            return nullptr;
        }
        auto accepted = std::move(pending_);
        accepted->activate_listener_lease(lease_);
        const auto& unix_datagram = unix_datagram_transport_locator(locator_);
        return make_packet_port_ordered_byte_stream(
            std::move(accepted), unix_datagram_stream_options(unix_datagram));
    }

private:
    TransportLocator locator_;
    std::shared_ptr<UnixDatagramListenerLease> lease_;
    mutable std::mutex mutex_;
    mutable std::unique_ptr<UnixDatagramPacketPort> pending_;
    mutable std::chrono::steady_clock::time_point reopen_after_{};
};

}  // namespace

std::string unix_datagram_transport_locator_text(
    const UnixDatagramTransportLocator& locator) {
    validate_path_syntax(locator.local_path);
    validate_path_syntax(locator.remote_path);
    if (locator.local_path == locator.remote_path) {
        app_fail(
            "UNIX_DATAGRAM_PATH_ALIAS",
            "local and remote Unix datagram paths must differ");
    }
    if (locator.mtu < kMinimumUnixDatagramMtu ||
        locator.mtu > kMaximumUnixDatagramMtu) {
        app_fail(
            "UNIX_DATAGRAM_LOCATOR_INVALID",
            "Unix datagram MTU must be in 256..65507");
    }
    if (locator.epoch == 0U) {
        app_fail(
            "UNIX_DATAGRAM_LOCATOR_INVALID",
            "Unix datagram epoch must be nonzero");
    }
    static_cast<void>(unix_datagram_profile_limits(locator));
    return std::string(kUnixDatagramPrefix) +
        "local=" + encode_path(locator.local_path) +
        "|remote=" + encode_path(locator.remote_path) +
        "|mtu=" + std::to_string(locator.mtu) +
        "|link=" + link_id_text(locator.link_id) +
        "|epoch=" + std::to_string(locator.epoch) +
        "|profile=" + std::to_string(locator.profile);
}

TransportLocator parse_unix_datagram_transport_locator(
    const std::string_view text) {
    const auto fields = split_fields(text);
    if (fields.size() != 7U || fields[0U] != "unix-dgram-v1") {
        app_fail(
            "UNIX_DATAGRAM_LOCATOR_INVALID",
            "Unix datagram locator must use canonical unix-dgram-v1 fields");
    }
    TransportLocator locator{
        .kind = TransportKind::unix_datagram,
        .tcp = {},
        .serial = {},
        .udp = {},
        .unix_datagram = UnixDatagramTransportLocator{
            .local_path = decode_path(field_value(fields[1U], "local")),
            .remote_path = decode_path(field_value(fields[2U], "remote")),
            .mtu = static_cast<std::uint16_t>(parse_u64(
                field_value(fields[3U], "mtu"),
                "Unix datagram MTU",
                kMinimumUnixDatagramMtu,
                kMaximumUnixDatagramMtu)),
            .link_id = parse_link_id(field_value(fields[4U], "link")),
            .epoch = static_cast<std::uint32_t>(parse_u64(
                field_value(fields[5U], "epoch"),
                "Unix datagram epoch",
                1U,
                std::numeric_limits<std::uint32_t>::max())),
            .profile = static_cast<std::uint8_t>(parse_u64(
                field_value(fields[6U], "profile"),
                "Unix datagram profile",
                kUnixDatagramProfile,
                kUnixDatagramProfile)),
        },
    };
    if (unix_datagram_transport_locator_text(locator.unix_datagram) != text) {
        app_fail(
            "UNIX_DATAGRAM_LOCATOR_NONCANONICAL",
            "Unix datagram locator must use the exact canonical spelling");
    }
    return locator;
}

const TransportConnector& unix_datagram_transport_connector() {
    static const UnixDatagramTransportConnector connector;
    return connector;
}

std::unique_ptr<TransportListener> listen_unix_datagram_transport(
    const TransportLocator& locator,
    const int backlog) {
    if (backlog < 1 || backlog > 1024) {
        app_fail("INVALID_LISTEN_BACKLOG", "backlog outside 1..1024");
    }
    static_cast<void>(unix_datagram_transport_locator(locator));
    return std::make_unique<UnixDatagramTransportListener>(locator);
}

}  // namespace natrav_overlay
