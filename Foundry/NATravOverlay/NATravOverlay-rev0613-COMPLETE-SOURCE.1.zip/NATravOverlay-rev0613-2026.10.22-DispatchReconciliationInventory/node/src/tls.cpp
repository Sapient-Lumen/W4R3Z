#include "tls.hpp"
#include "tls_bio.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <limits>
#include <optional>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <unistd.h>
#include <utility>
#include <vector>

#include <openssl/crypto.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>

namespace natrav_overlay {
namespace {

inline constexpr std::string_view kAlpn = "natrav-overlay/1";
inline constexpr std::size_t kMaximumCertificateBytes = 2U * 1024U * 1024U;
inline constexpr std::size_t kMaximumPrivateKeyBytes = 1024U * 1024U;

class SecretBytes final {
public:
    explicit SecretBytes(datacube::Octets bytes) : bytes_(std::move(bytes)) {}
    ~SecretBytes() {
        if (!bytes_.empty()) {
            OPENSSL_cleanse(bytes_.data(), bytes_.size());
        }
    }
    SecretBytes(const SecretBytes&) = delete;
    SecretBytes& operator=(const SecretBytes&) = delete;
    [[nodiscard]] datacube::OctetView view() const noexcept { return bytes_; }
private:
    datacube::Octets bytes_;
};

struct BioDeleter final {
    void operator()(BIO* value) const noexcept { BIO_free(value); }
};
struct X509Deleter final {
    void operator()(X509* value) const noexcept { X509_free(value); }
};
struct PkeyDeleter final {
    void operator()(EVP_PKEY* value) const noexcept { EVP_PKEY_free(value); }
};

using BioPtr = std::unique_ptr<BIO, BioDeleter>;
using X509Ptr = std::unique_ptr<X509, X509Deleter>;
using PkeyPtr = std::unique_ptr<EVP_PKEY, PkeyDeleter>;

[[nodiscard]] std::string openssl_reason() {
    const unsigned long value = ERR_get_error();
    if (value == 0UL) {
        return "TLS protocol failure";
    }
    const char* reason = ERR_reason_error_string(value);
    while (ERR_get_error() != 0UL) {
    }
    return reason == nullptr ? "TLS protocol failure" : std::string(reason);
}

[[nodiscard]] datacube::Octets read_identity_file(
    const std::filesystem::path& path,
    const bool private_key) {
    if (path.empty()) {
        app_fail(private_key ? "TLS_KEY_PATH_INVALID" : "TLS_CERT_PATH_INVALID",
            "identity file path is empty");
    }
    const int raw = ::open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (raw < 0) {
        if (errno == ELOOP) {
            app_fail(private_key ? "TLS_KEY_SYMLINK_REJECTED" :
                    "TLS_CERT_SYMLINK_REJECTED",
                "identity file final component must not be a symlink");
        }
        app_fail(private_key ? "TLS_KEY_OPEN_FAILED" : "TLS_CERT_OPEN_FAILED",
            datacube::errno_detail(private_key ? "private key file" :
                "certificate file", errno));
    }
    datacube::Fd fd(raw);
    struct stat status {};
    if (::fstat(fd.get(), &status) != 0) {
        app_fail(private_key ? "TLS_KEY_STAT_FAILED" : "TLS_CERT_STAT_FAILED",
            datacube::errno_detail(private_key ? "private key file" :
                "certificate file", errno));
    }
    if (!S_ISREG(status.st_mode)) {
        app_fail(private_key ? "TLS_KEY_NOT_REGULAR" : "TLS_CERT_NOT_REGULAR",
            "identity file must be regular");
    }
    if (status.st_uid != ::geteuid()) {
        app_fail(private_key ? "TLS_KEY_OWNER_INVALID" : "TLS_CERT_OWNER_INVALID",
            "identity file must be owned by the effective user");
    }
    if (private_key) {
        const mode_t unsafe = S_IRWXG | S_IRWXO | S_IXUSR |
            S_ISUID | S_ISGID | S_ISVTX;
        if ((status.st_mode & unsafe) != 0 ||
            (status.st_mode & S_IRUSR) == 0) {
            app_fail("TLS_KEY_PERMISSIONS_INVALID",
                "private key must be owner-readable and inaccessible to group and other users");
        }
    } else if ((status.st_mode & (S_IWGRP | S_IWOTH | S_ISUID | S_ISGID)) != 0) {
        app_fail("TLS_CERT_PERMISSIONS_INVALID",
            "certificate must not be group- or other-writable or carry special mode bits");
    }
    const auto ceiling = private_key ? kMaximumPrivateKeyBytes : kMaximumCertificateBytes;
    if (status.st_size <= 0 ||
        static_cast<std::uint64_t>(status.st_size) >
            static_cast<std::uint64_t>(ceiling)) {
        app_fail(private_key ? "TLS_KEY_SIZE_INVALID" : "TLS_CERT_SIZE_INVALID",
            "identity file size is outside the accepted envelope");
    }
    return datacube::read_all_fd(
        fd.get(), static_cast<std::uint64_t>(ceiling),
        private_key ? "private key file" : "certificate file");
}

[[nodiscard]] BioPtr memory_bio(const datacube::OctetView bytes) {
    if (bytes.empty() || bytes.size() > static_cast<std::size_t>(INT_MAX)) {
        app_fail("TLS_IDENTITY_PARSE_FAILED", "identity material size is invalid");
    }
    BIO* raw = BIO_new_mem_buf(
        bytes.data(), static_cast<int>(bytes.size()));
    if (raw == nullptr) {
        app_fail("TLS_IDENTITY_PARSE_FAILED", "OpenSSL memory BIO allocation failed");
    }
    return BioPtr(raw);
}

[[nodiscard]] datacube::Digest32 certificate_spki_sha256(X509* certificate) {
    PkeyPtr key(X509_get_pubkey(certificate));
    if (!key) {
        app_fail("TLS_CERT_PUBLIC_KEY_MISSING", "certificate has no public key");
    }
    const int length = i2d_PUBKEY(key.get(), nullptr);
    if (length <= 0) {
        app_fail("TLS_CERT_PUBLIC_KEY_INVALID", openssl_reason());
    }
    datacube::Octets der(static_cast<std::size_t>(length));
    unsigned char* cursor = der.data();
    if (i2d_PUBKEY(key.get(), &cursor) != length) {
        app_fail("TLS_CERT_PUBLIC_KEY_INVALID", openssl_reason());
    }
    return datacube::sha256(der);
}

[[nodiscard]] datacube::Digest32 certificate_der_sha256(X509* certificate) {
    if (certificate == nullptr) {
        app_fail("TLS_CERT_PARSE_FAILED", "certificate is absent");
    }
    const int length = i2d_X509(certificate, nullptr);
    if (length <= 0) {
        app_fail("TLS_CERT_PARSE_FAILED", openssl_reason());
    }
    datacube::Octets der(static_cast<std::size_t>(length));
    unsigned char* cursor = der.data();
    if (i2d_X509(certificate, &cursor) != length) {
        app_fail("TLS_CERT_PARSE_FAILED", openssl_reason());
    }
    return datacube::sha256(der);
}

[[nodiscard]] bool equal_pin(
    const datacube::Digest32& left,
    const datacube::Digest32& right) noexcept {
    return CRYPTO_memcmp(
        left.octets.data(), right.octets.data(), left.octets.size()) == 0;
}

[[nodiscard]] int permissive_verify_callback(int, X509_STORE_CTX*) noexcept {
    // Trust is decided immediately after the authenticated handshake by an exact
    // configured SPKI pin. OpenSSL still verifies proof of private-key possession.
    return 1;
}

[[nodiscard]] int alpn_select_callback(
    SSL*,
    const unsigned char** out,
    unsigned char* out_length,
    const unsigned char* input,
    const unsigned int input_length,
    void*) noexcept {
    // The selected pointer must remain valid after this callback returns.
    // Point into OpenSSL's client-offered protocol vector rather than a local
    // server preference buffer.
    unsigned int offset = 0U;
    while (offset < input_length) {
        const unsigned int length = input[offset];
        ++offset;
        if (length == 0U || length > input_length - offset) {
            return SSL_TLSEXT_ERR_ALERT_FATAL;
        }
        if (length == kAlpn.size() &&
            std::equal(
                kAlpn.begin(), kAlpn.end(),
                reinterpret_cast<const char*>(input + offset))) {
            *out = input + offset;
            *out_length = static_cast<unsigned char>(length);
            return SSL_TLSEXT_ERR_OK;
        }
        offset += length;
    }
    return SSL_TLSEXT_ERR_ALERT_FATAL;
}

void configure_ssl(
    SSL* ssl,
    TlsByteChannelBio& channel_bio,
    const bool server) {
    BIO* bio = channel_bio.release();
    if (bio == nullptr) {
        app_fail("TLS_SETUP_FAILED", "TLS ByteChannel BIO is unavailable");
    }
    SSL_set_bio(ssl, bio, bio);
    static_cast<void>(SSL_set_mode(
        ssl, SSL_MODE_ENABLE_PARTIAL_WRITE |
            SSL_MODE_ACCEPT_MOVING_WRITE_BUFFER |
            SSL_MODE_RELEASE_BUFFERS));
    SSL_set_verify(
        ssl,
        server ? SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT :
            SSL_VERIFY_PEER,
        permissive_verify_callback);
    if (server) {
        SSL_set_accept_state(ssl);
    } else {
        std::array<unsigned char, 1U + kAlpn.size()> protocols{};
        protocols[0] = static_cast<unsigned char>(kAlpn.size());
        std::copy(kAlpn.begin(), kAlpn.end(), protocols.begin() + 1);
        if (SSL_set_alpn_protos(
                ssl, protocols.data(),
                static_cast<unsigned int>(protocols.size())) != 0) {
            app_fail("TLS_SETUP_FAILED", "failed to configure ALPN");
        }
        SSL_set_connect_state(ssl);
    }
}

template <typename Call>
[[nodiscard]] int invoke_ssl(
    TlsByteChannelBio& channel_bio,
    const Deadline deadline,
    IoCounters& counters,
    const std::string_view operation,
    Call&& call) {
    channel_bio.begin_operation(deadline, counters, operation);
    try {
        const int result = std::forward<Call>(call)();
        channel_bio.complete_operation();
        return result;
    } catch (...) {
        channel_bio.cancel_operation();
        throw;
    }
}

[[nodiscard]] bool callback_transport_failure(
    const std::string_view code) noexcept {
    return code == "PEER_RESET" ||
        code == "SOCKET_READ_FAILED" ||
        code == "SOCKET_WRITE_FAILED" ||
        code == "SOCKET_WRITE_CLOSED" ||
        code.starts_with("SERIAL_") ||
        code.starts_with("UDP_") ||
        code.starts_with("UNIX_DATAGRAM_");
}

[[nodiscard]] bool unexpected_tls_eof() noexcept {
#ifdef SSL_R_UNEXPECTED_EOF_WHILE_READING
    const unsigned long value = ERR_peek_error();
    return value != 0UL && ERR_GET_LIB(value) == ERR_LIB_SSL &&
        ERR_GET_REASON(value) == SSL_R_UNEXPECTED_EOF_WHILE_READING;
#else
    return false;
#endif
}

void require_deadline_remaining(
    const Deadline deadline,
    const std::string_view operation) {
    if (std::chrono::steady_clock::now() >= deadline) {
        app_fail("IO_TIMEOUT", std::string(operation));
    }
}

void run_handshake(
    SSL* ssl,
    TlsByteChannelBio& channel_bio,
    const bool server,
    const Deadline deadline,
    IoCounters& counters) {
    while (true) {
        require_deadline_remaining(deadline, "TLS handshake");
        ERR_clear_error();
        errno = 0;
        int result = 0;
        try {
            result = invoke_ssl(
                channel_bio,
                deadline,
                counters,
                server ? "TLS handshake accept" : "TLS handshake connect",
                [ssl, server] {
                    return server ? SSL_accept(ssl) : SSL_connect(ssl);
                });
        } catch (const AppError& error) {
            if (callback_transport_failure(error.code())) {
                app_fail("TLS_HANDSHAKE_FAILED", error.what());
            }
            throw;
        }
        if (result == 1) {
            break;
        }
        const int error = SSL_get_error(ssl, result);
        if (error == SSL_ERROR_WANT_READ) {
            ++counters.would_block;
            continue;
        }
        if (error == SSL_ERROR_WANT_WRITE) {
            ++counters.would_block;
            continue;
        }
        app_fail("TLS_HANDSHAKE_FAILED", openssl_reason());
    }

    if (SSL_version(ssl) != TLS1_3_VERSION) {
        app_fail("TLS_VERSION_REJECTED", "peer did not negotiate TLS 1.3");
    }
    const unsigned char* selected = nullptr;
    unsigned int selected_length = 0U;
    SSL_get0_alpn_selected(ssl, &selected, &selected_length);
    if (selected_length != kAlpn.size() || selected == nullptr ||
        !std::equal(kAlpn.begin(), kAlpn.end(), selected)) {
        app_fail("TLS_ALPN_REJECTED", "peer did not negotiate natrav-overlay/1");
    }
}

[[nodiscard]] X509Ptr peer_certificate(SSL* ssl) {
    X509Ptr certificate(SSL_get1_peer_certificate(ssl));
    if (!certificate) {
        app_fail("TLS_PEER_CERTIFICATE_MISSING", "peer did not present a certificate");
    }
    const int before = X509_cmp_current_time(X509_get0_notBefore(certificate.get()));
    const int after = X509_cmp_current_time(X509_get0_notAfter(certificate.get()));
    if (before >= 0 || after <= 0) {
        app_fail("TLS_PEER_CERTIFICATE_TIME_INVALID",
            "peer certificate is not currently valid");
    }
    return certificate;
}

[[nodiscard]] TlsSessionInfo session_info(
    SSL* ssl,
    std::string peer_node,
    std::string peer_generation,
    const KeyGenerationState peer_key_state,
    const datacube::Digest32& pin,
    const datacube::Digest32& certificate_sha256) {
    const char* protocol = SSL_get_version(ssl);
    const char* cipher = SSL_get_cipher_name(ssl);
    return TlsSessionInfo{
        .peer_node = std::move(peer_node),
        .peer_generation = std::move(peer_generation),
        .peer_key_state = peer_key_state,
        .peer_spki_sha256 = pin,
        .peer_certificate_sha256 = certificate_sha256,
        .protocol = protocol == nullptr ? "UNKNOWN" : std::string(protocol),
        .cipher = cipher == nullptr ? "UNKNOWN" : std::string(cipher),
    };
}

struct TrustedGenerationMatch final {
    std::string node_id;
    std::string generation;
    KeyGenerationState state{KeyGenerationState::retired};
};

[[nodiscard]] TrustedGenerationMatch trusted_generation_for_pin(
    const std::vector<TlsTrustedIdentity>& trusted_peers,
    const datacube::Digest32& pin) {
    std::optional<TrustedGenerationMatch> found;
    for (const auto& identity : trusted_peers) {
        for (const auto& candidate : identity.generations) {
            if (!equal_pin(candidate.spki_sha256, pin)) {
                continue;
            }
            if (found.has_value()) {
                app_fail("TLS_TRUST_AMBIGUOUS",
                    "one public key pin is assigned to more than one generation");
            }
            found = TrustedGenerationMatch{
                .node_id = identity.node_id,
                .generation = candidate.generation,
                .state = candidate.state,
            };
        }
    }
    if (!found.has_value()) {
        app_fail("TLS_PEER_UNTRUSTED",
            "peer public key is not assigned to a configured generation");
    }
    if (found->state == KeyGenerationState::revoked) {
        app_fail("TLS_PEER_KEY_REVOKED",
            "peer public key generation is explicitly revoked: " +
            found->node_id + "/" + found->generation);
    }
    return *found;
}

}  // namespace

struct TlsContext::State final {
    SSL_CTX* context{nullptr};
    datacube::Digest32 identity_pin;

    ~State() { SSL_CTX_free(context); }
};

struct TlsChannel::State final {
    explicit State(ByteChannel& channel) : channel_bio(channel) {}

    TlsByteChannelBio channel_bio;
    SSL* ssl{nullptr};
    TlsSessionInfo session;

    // SSL_free releases the owned BIO while channel_bio and its callback state
    // are still alive. The caller-owned backing ByteChannel outlives State.
    ~State() { SSL_free(ssl); }
};

datacube::Digest32 parse_spki_sha256(const std::string_view value) {
    if (value.size() != 64U ||
        !std::all_of(value.begin(), value.end(), [](const char ch) {
            return (ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f');
        })) {
        app_fail("TLS_PIN_INVALID",
            "SPKI SHA-256 pin must be exactly 64 lowercase hexadecimal characters");
    }
    const auto result = datacube::parse_hex_digest32(value, "SPKI SHA-256 pin");
    if (spki_sha256_is_zero(result)) {
        app_fail("TLS_PIN_INVALID", "all-zero SPKI SHA-256 pin is reserved");
    }
    return result;
}

std::string spki_sha256_text(const datacube::Digest32& value) {
    return datacube::hex_lower(value);
}

bool spki_sha256_is_zero(const datacube::Digest32& value) noexcept {
    return std::all_of(value.octets.begin(), value.octets.end(),
        [](const std::uint8_t byte) { return byte == 0U; });
}

datacube::Digest32 tls_certificate_sha256(
    const std::filesystem::path& certificate_file) {
    ERR_clear_error();
    const auto certificate_bytes = read_identity_file(certificate_file, false);
    auto certificate_bio = memory_bio(certificate_bytes);
    X509Ptr certificate(PEM_read_bio_X509(
        certificate_bio.get(), nullptr, nullptr, nullptr));
    if (!certificate) {
        app_fail("TLS_CERT_PARSE_FAILED", openssl_reason());
    }
    return certificate_der_sha256(certificate.get());
}

std::string_view key_generation_state_name(
    const KeyGenerationState state) noexcept {
    switch (state) {
        case KeyGenerationState::active: return "ACTIVE";
        case KeyGenerationState::retired: return "RETIRED";
        case KeyGenerationState::revoked: return "REVOKED";
    }
    return "UNKNOWN";
}

TlsContext::TlsContext(const TlsIdentityFiles& identity)
    : state_(std::make_unique<State>()) {
    ERR_clear_error();
    const auto certificate_bytes = read_identity_file(identity.certificate, false);
    SecretBytes key_bytes(read_identity_file(identity.private_key, true));

    auto certificate_bio = memory_bio(certificate_bytes);
    X509Ptr certificate(PEM_read_bio_X509(
        certificate_bio.get(), nullptr, nullptr, nullptr));
    if (!certificate) {
        app_fail("TLS_CERT_PARSE_FAILED", openssl_reason());
    }
    auto key_bio = memory_bio(key_bytes.view());
    PkeyPtr key(PEM_read_bio_PrivateKey(
        key_bio.get(), nullptr, nullptr, nullptr));
    if (!key) {
        app_fail("TLS_KEY_PARSE_FAILED", openssl_reason());
    }
    if (X509_check_private_key(certificate.get(), key.get()) != 1) {
        app_fail("TLS_IDENTITY_KEY_MISMATCH",
            "certificate and private key do not form one identity");
    }
    const auto actual_pin = certificate_spki_sha256(certificate.get());
    if (!equal_pin(actual_pin, identity.expected_spki_sha256)) {
        app_fail("TLS_IDENTITY_PIN_MISMATCH",
            "configured identity pin does not match the certificate public key");
    }

    SSL_CTX* context = SSL_CTX_new(TLS_method());
    if (context == nullptr) {
        app_fail("TLS_CONTEXT_FAILED", openssl_reason());
    }
    state_->context = context;
    if (SSL_CTX_set_min_proto_version(context, TLS1_3_VERSION) != 1 ||
        SSL_CTX_set_max_proto_version(context, TLS1_3_VERSION) != 1) {
        app_fail("TLS_CONTEXT_FAILED", openssl_reason());
    }
    static_cast<void>(SSL_CTX_set_options(
        context, SSL_OP_NO_COMPRESSION | SSL_OP_NO_RENEGOTIATION |
            SSL_OP_NO_TICKET));
    static_cast<void>(SSL_CTX_set_mode(context, SSL_MODE_RELEASE_BUFFERS));
    static_cast<void>(SSL_CTX_set_session_cache_mode(context, SSL_SESS_CACHE_OFF));
    if (SSL_CTX_set_num_tickets(context, 0U) != 1) {
        app_fail("TLS_CONTEXT_FAILED", openssl_reason());
    }
    if (SSL_CTX_set_max_early_data(context, 0U) != 1) {
        app_fail("TLS_CONTEXT_FAILED", openssl_reason());
    }
    SSL_CTX_set_alpn_select_cb(context, alpn_select_callback, nullptr);
    if (SSL_CTX_use_certificate(context, certificate.get()) != 1 ||
        SSL_CTX_use_PrivateKey(context, key.get()) != 1 ||
        SSL_CTX_check_private_key(context) != 1) {
        app_fail("TLS_IDENTITY_LOAD_FAILED", openssl_reason());
    }
    state_->identity_pin = actual_pin;
}

TlsContext::~TlsContext() = default;
TlsContext::TlsContext(TlsContext&&) noexcept = default;
TlsContext& TlsContext::operator=(TlsContext&&) noexcept = default;

const datacube::Digest32& TlsContext::identity_spki_sha256() const noexcept {
    return state_->identity_pin;
}

TlsChannel::TlsChannel(std::unique_ptr<State> state) noexcept
    : state_(std::move(state)) {}
TlsChannel::~TlsChannel() = default;
TlsChannel::TlsChannel(TlsChannel&&) noexcept = default;
TlsChannel& TlsChannel::operator=(TlsChannel&&) noexcept = default;

TlsChannel TlsChannel::connect(
    TlsContext& context,
    ByteChannel& channel,
    const std::string_view expected_peer_node,
    const std::string_view expected_peer_generation,
    const KeyGenerationState expected_peer_key_state,
    const datacube::Digest32& expected_peer_spki_sha256,
    const Deadline deadline,
    IoCounters& counters) {
    require_node_id(expected_peer_node, "expected TLS peer node");
    require_generation_id(expected_peer_generation, "expected TLS peer generation");
    if (spki_sha256_is_zero(expected_peer_spki_sha256) ||
        expected_peer_key_state == KeyGenerationState::revoked) {
        app_fail("TLS_SETUP_FAILED", "invalid or revoked client TLS parameters");
    }
    auto state = std::make_unique<State>(channel);
    state->ssl = SSL_new(context.state_->context);
    if (state->ssl == nullptr) {
        app_fail("TLS_SETUP_FAILED", openssl_reason());
    }
    configure_ssl(state->ssl, state->channel_bio, false);
    run_handshake(
        state->ssl, state->channel_bio, false, deadline, counters);
    auto certificate = peer_certificate(state->ssl);
    const auto actual_pin = certificate_spki_sha256(certificate.get());
    const auto actual_certificate_sha256 =
        certificate_der_sha256(certificate.get());
    if (!equal_pin(actual_pin, expected_peer_spki_sha256)) {
        app_fail("TLS_PEER_PIN_MISMATCH",
            "peer certificate public key does not match the durable configured pin");
    }
    state->session = session_info(
        state->ssl,
        std::string(expected_peer_node),
        std::string(expected_peer_generation),
        expected_peer_key_state,
        actual_pin,
        actual_certificate_sha256);
    return TlsChannel(std::move(state));
}

TlsChannel TlsChannel::accept(
    TlsContext& context,
    ByteChannel& channel,
    const std::vector<TlsTrustedIdentity>& trusted_peers,
    const Deadline deadline,
    IoCounters& counters) {
    if (trusted_peers.empty()) {
        app_fail("TLS_SETUP_FAILED", "server TLS trust store is empty");
    }
    auto state = std::make_unique<State>(channel);
    state->ssl = SSL_new(context.state_->context);
    if (state->ssl == nullptr) {
        app_fail("TLS_SETUP_FAILED", openssl_reason());
    }
    configure_ssl(state->ssl, state->channel_bio, true);
    run_handshake(
        state->ssl, state->channel_bio, true, deadline, counters);
    auto certificate = peer_certificate(state->ssl);
    const auto actual_pin = certificate_spki_sha256(certificate.get());
    const auto actual_certificate_sha256 =
        certificate_der_sha256(certificate.get());
    const auto peer = trusted_generation_for_pin(trusted_peers, actual_pin);
    state->session = session_info(
        state->ssl, peer.node_id, peer.generation, peer.state, actual_pin,
        actual_certificate_sha256);
    return TlsChannel(std::move(state));
}

const TlsSessionInfo& TlsChannel::session() const noexcept {
    return state_->session;
}

std::size_t TlsChannel::read_some(
    const std::span<std::uint8_t> buffer,
    const Deadline deadline,
    IoCounters& counters,
    const std::string_view operation) {
    if (!state_ || state_->ssl == nullptr || buffer.empty()) {
        app_fail("TLS_READ_FAILED", "invalid TLS read state");
    }
    while (true) {
        require_deadline_remaining(deadline, operation);
        ERR_clear_error();
        errno = 0;
        std::size_t count = 0U;
        ++counters.read_calls;
        int result = 0;
        try {
            result = invoke_ssl(
                state_->channel_bio,
                deadline,
                counters,
                operation,
                [this, buffer, &count] {
                    return SSL_read_ex(
                        state_->ssl, buffer.data(), buffer.size(), &count);
                });
        } catch (const AppError& error) {
            if (callback_transport_failure(error.code())) {
                app_fail("TLS_READ_FAILED", error.what());
            }
            throw;
        }
        if (result == 1) {
            if (count == 0U || count > buffer.size()) {
                app_fail("TLS_READ_FAILED", "TLS read made invalid progress");
            }
            return count;
        }
        const int error = SSL_get_error(state_->ssl, result);
        if (error == SSL_ERROR_WANT_READ) {
            ++counters.would_block;
            continue;
        }
        if (error == SSL_ERROR_WANT_WRITE) {
            ++counters.would_block;
            continue;
        }
        if (error == SSL_ERROR_ZERO_RETURN) {
            return 0U;
        }
        if ((error == SSL_ERROR_SYSCALL && ERR_peek_error() == 0UL) ||
            (error == SSL_ERROR_SSL && unexpected_tls_eof())) {
            app_fail("TLS_TRUNCATED_EOF", "peer closed without TLS close-notify");
        }
        app_fail("TLS_READ_FAILED", openssl_reason());
    }
}

std::size_t TlsChannel::write_some(
    const datacube::OctetView bytes,
    const Deadline deadline,
    IoCounters& counters,
    const std::string_view operation) {
    if (!state_ || state_->ssl == nullptr || bytes.empty()) {
        app_fail("TLS_WRITE_FAILED", "invalid TLS write state");
    }
    while (true) {
        require_deadline_remaining(deadline, operation);
        ERR_clear_error();
        errno = 0;
        std::size_t count = 0U;
        ++counters.write_calls;
        int result = 0;
        try {
            result = invoke_ssl(
                state_->channel_bio,
                deadline,
                counters,
                operation,
                [this, bytes, &count] {
                    return SSL_write_ex(
                        state_->ssl, bytes.data(), bytes.size(), &count);
                });
        } catch (const AppError& error) {
            if (callback_transport_failure(error.code())) {
                app_fail("TLS_WRITE_FAILED", error.what());
            }
            throw;
        }
        if (result == 1) {
            if (count == 0U || count > bytes.size()) {
                app_fail("TLS_WRITE_FAILED", "TLS write made invalid progress");
            }
            return count;
        }
        const int error = SSL_get_error(state_->ssl, result);
        if (error == SSL_ERROR_WANT_READ) {
            ++counters.would_block;
            continue;
        }
        if (error == SSL_ERROR_WANT_WRITE) {
            ++counters.would_block;
            continue;
        }
        if (error == SSL_ERROR_ZERO_RETURN) {
            app_fail("TLS_WRITE_CLOSED", "peer sent TLS close-notify");
        }
        app_fail("TLS_WRITE_FAILED", openssl_reason());
    }
}

void TlsChannel::close_notify(
    const Deadline deadline,
    IoCounters& counters) noexcept {
    if (!state_ || state_->ssl == nullptr) {
        return;
    }
    try {
        while (true) {
            require_deadline_remaining(deadline, "TLS close-notify");
            ERR_clear_error();
            errno = 0;
            const int result = invoke_ssl(
                state_->channel_bio,
                deadline,
                counters,
                "TLS close-notify",
                [this] { return SSL_shutdown(state_->ssl); });
            if (result >= 0) {
                return;
            }
            const int error = SSL_get_error(state_->ssl, result);
            if (error == SSL_ERROR_WANT_READ) {
                ++counters.would_block;
                continue;
            }
            if (error == SSL_ERROR_WANT_WRITE) {
                ++counters.would_block;
                continue;
            }
            return;
        }
    } catch (...) {
        return;
    }
}

std::string tls_session_json(const TlsSessionInfo& session) {
    return std::string("{") +
        "\"peer_node\":" + json_string(session.peer_node) +
        ",\"peer_generation\":" + json_string(session.peer_generation) +
        ",\"peer_key_state\":" +
        json_string(key_generation_state_name(session.peer_key_state)) +
        ",\"peer_spki_sha256\":" +
        json_string(spki_sha256_text(session.peer_spki_sha256)) +
        ",\"peer_certificate_sha256\":" +
        json_string(spki_sha256_text(session.peer_certificate_sha256)) +
        ",\"protocol\":" + json_string(session.protocol) +
        ",\"cipher\":" + json_string(session.cipher) + "}";
}

}  // namespace natrav_overlay
