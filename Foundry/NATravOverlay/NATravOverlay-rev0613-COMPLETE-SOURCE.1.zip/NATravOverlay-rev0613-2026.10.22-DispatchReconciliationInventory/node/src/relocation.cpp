#include "relocation.hpp"

#include "config.hpp"
#include "tls.hpp"

#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>

namespace natrav_overlay {
namespace {

[[nodiscard]] std::uint64_t unix_milliseconds_now() {
    const auto value = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    if (value <= 0) {
        app_fail("CLOCK_INVALID", "system clock is before the Unix epoch");
    }
    return static_cast<std::uint64_t>(value);
}

void pause_boundary(const char* name) {
    const char* raw = std::getenv(name);
    if (raw == nullptr || *raw == '\0') { return; }
    const auto delay = parse_u64(raw, name, 1U, 60'000U);
    std::cerr << "{\"test_boundary\":\"" << name << "\"}" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(delay));
}

[[nodiscard]] std::filesystem::path absolute_normal(
    const std::filesystem::path& path,
    const std::string_view field) {
    if (path.empty()) {
        app_fail("RELOCATION_PATH_INVALID", std::string(field) + " is empty");
    }
    for (const auto& component : path) {
        if (component == "..") {
            app_fail("RELOCATION_PATH_INVALID",
                std::string(field) + " must not contain dot-dot");
        }
    }
    return std::filesystem::absolute(path).lexically_normal();
}

void validate_existing_chain(
    const std::filesystem::path& absolute,
    const bool final_must_be_directory,
    const std::string_view field) {
    if (!absolute.is_absolute()) {
        app_fail("RELOCATION_PATH_INVALID",
            std::string(field) + " must be absolute");
    }
    std::filesystem::path current = absolute.root_path();
    for (const auto& component : absolute.relative_path()) {
        current /= component;
        struct stat status {};
        if (::lstat(current.c_str(), &status) != 0) {
            app_fail("RELOCATION_PATH_INVALID",
                datacube::errno_detail(current.string(), errno));
        }
        if (S_ISLNK(status.st_mode)) {
            app_fail("RELOCATION_PATH_SYMLINK_REJECTED",
                std::string(field) + " contains a symbolic link: " +
                current.string());
        }
        if (current != absolute && !S_ISDIR(status.st_mode)) {
            app_fail("RELOCATION_PATH_INVALID",
                std::string(field) + " parent component is not a directory: " +
                current.string());
        }
        if (current == absolute) {
            const bool kind_ok = final_must_be_directory ?
                S_ISDIR(status.st_mode) : S_ISREG(status.st_mode);
            if (!kind_ok) {
                app_fail("RELOCATION_PATH_INVALID",
                    std::string(field) + (final_must_be_directory ?
                        " must be a directory" : " must be a regular file"));
            }
        }
    }
}

void validate_owned_directory(
    const std::filesystem::path& absolute,
    const bool require_private,
    const std::string_view field) {
    validate_existing_chain(absolute, true, field);
    struct stat status {};
    if (::lstat(absolute.c_str(), &status) != 0) {
        app_fail("RELOCATION_PATH_INVALID",
            datacube::errno_detail(absolute.string(), errno));
    }
    if (status.st_uid != ::geteuid()) {
        app_fail("RELOCATION_PATH_OWNER_INVALID",
            std::string(field) + " must be owned by the effective user");
    }
    const mode_t unsafe = require_private ?
        (S_IRWXG | S_IRWXO) : (S_IWGRP | S_IWOTH);
    if ((status.st_mode & unsafe) != 0) {
        app_fail("RELOCATION_PATH_PERMISSIONS_INVALID",
            std::string(field) + (require_private ?
                " must be inaccessible to group and other users" :
                " must not be group- or other-writable"));
    }
}

void validate_identity_path(
    const std::filesystem::path& file,
    const std::string_view field) {
    const auto absolute = absolute_normal(file, field);
    validate_existing_chain(absolute, false, field);
    validate_owned_directory(absolute.parent_path(), false,
        std::string(field) + " parent");
}

void require_control_absent(const std::filesystem::path& path) {
    struct stat status {};
    if (::lstat(path.c_str(), &status) == 0) {
        app_fail("RELOCATION_CONTROL_EXISTS",
            "candidate control path already exists; overwrite is forbidden");
    }
    if (errno != ENOENT) {
        app_fail("RELOCATION_CONTROL_INVALID",
            datacube::errno_detail(path.string(), errno));
    }
}

[[nodiscard]] bool accepted_generation_exists(
    const StateSnapshot& snapshot,
    const std::string_view generation) {
    for (const auto& event : snapshot.configuration_events) {
        if (event.kind != "REJECTED" && event.generation == generation) {
            return true;
        }
    }
    return false;
}

}  // namespace

StateRelocationResult relocate_state(const StateRelocationOptions& options) {
    require_node_id(options.node_id, "relocation node ID");
    if (options.reason.empty() || options.reason.size() > 256U) {
        app_fail("RELOCATION_REASON_INVALID",
            "relocation reason must contain 1 to 256 bytes");
    }
    const auto state_path = absolute_normal(
        options.state_directory, "state directory");
    validate_owned_directory(state_path, true, "state directory");
    const auto candidate_path = absolute_normal(
        options.candidate_config, "candidate configuration");
    validate_existing_chain(candidate_path, false, "candidate configuration");
    validate_owned_directory(candidate_path.parent_path(), false,
        "candidate configuration parent");

    const auto candidate = load_runtime_config(candidate_path);
    if (candidate.runtime_generation.empty()) {
        app_fail("RELOCATION_LIVE_MODE_REQUIRED",
            "relocation requires a versioned candidate with runtime_generation");
    }
    if (candidate.local_node != options.node_id) {
        app_fail("RELOCATION_NODE_MISMATCH",
            "candidate node does not match the state owner");
    }
    if (candidate.state_directory != state_path) {
        app_fail("RELOCATION_STATE_PATH_MISMATCH",
            "candidate state path must equal the owned restored directory");
    }
    if (candidate.control_socket.parent_path() != state_path) {
        app_fail("RELOCATION_CONTROL_PATH_INVALID",
            "candidate control socket must be inside the restored state directory");
    }
    validate_identity_path(candidate.identity.certificate, "identity certificate");
    validate_identity_path(candidate.identity.private_key, "identity private key");
    const TlsContext identity(candidate.identity);

    NodeState state(
        state_path,
        options.node_id,
        options.maximum_journal_bytes);
    require_control_absent(candidate.control_socket);
    const auto before_snapshot = state.snapshot();
    const auto active = active_configuration_event(
        before_snapshot.configuration_events);
    if (active == 0U) {
        app_fail("RELOCATION_CONFIGURATION_REQUIRED",
            "state has no accepted versioned configuration history");
    }
    const auto& active_event = before_snapshot.configuration_events[active - 1U];
    const auto before = parse_runtime_config(
        active_event.canonical,
        "/durable-relocation-predecessor",
        IdentityFileValidation::deferred);
    if (before.runtime_generation.empty()) {
        app_fail("RELOCATION_LIVE_MODE_REQUIRED",
            "startup-only V6 state cannot be relocated by this command");
    }
    if (before.local_node != candidate.local_node ||
        before.local_identity_generation != candidate.local_identity_generation ||
        before.identity.expected_spki_sha256 !=
            candidate.identity.expected_spki_sha256 ||
        identity.identity_spki_sha256() !=
            before.identity.expected_spki_sha256) {
        app_fail("RELOCATION_IDENTITY_CHANGED",
            "relocation must preserve node, identity generation, and actual SPKI identity");
    }
    if (before.state_directory == candidate.state_directory) {
        app_fail("RELOCATION_STATE_UNCHANGED",
            "relocation requires a different recorded state directory");
    }
    if (!runtime_relocation_only_change(before, candidate)) {
        app_fail("RELOCATION_SCOPE_CHANGED",
            "offline relocation may change only runtime generation and owner paths");
    }
    if (accepted_generation_exists(
            before_snapshot, candidate.runtime_generation)) {
        app_fail("RELOCATION_GENERATION_EXISTS",
            "relocation requires a fresh runtime generation");
    }

    const auto canonical = canonical_runtime_config(candidate);
    const auto relocated_at = unix_milliseconds_now();
    const RuntimeConfigurationEvent event{
        .kind = "RELOCATE",
        .generation = candidate.runtime_generation,
        .digest = runtime_configuration_digest(canonical),
        .canonical = canonical,
        .unix_ms = relocated_at,
        .actor = "LOCAL_OFFLINE_RELOCATION",
        .reason = options.reason,
        .error_code = {},
    };
    pause_boundary("NATRAV_OVERLAY_TEST_RELOCATION_BEFORE_COMMIT_MS");
    state.record_runtime_configuration(event);
    pause_boundary("NATRAV_OVERLAY_TEST_RELOCATION_AFTER_COMMIT_MS");
    const auto after_snapshot = state.snapshot();

    return StateRelocationResult{
        .state_directory = state_path,
        .from_generation = active_event.generation,
        .from_digest = active_event.digest,
        .to_generation = event.generation,
        .to_digest = event.digest,
        .old_state_directory = before.state_directory,
        .new_state_directory = candidate.state_directory,
        .old_control_socket = before.control_socket,
        .new_control_socket = candidate.control_socket,
        .old_certificate = before.identity.certificate,
        .new_certificate = candidate.identity.certificate,
        .old_private_key = before.identity.private_key,
        .new_private_key = candidate.identity.private_key,
        .identity_spki_sha256 = candidate.identity.expected_spki_sha256,
        .relocated_unix_ms = relocated_at,
        .configuration_event = after_snapshot.configuration_events.size(),
        .logical_state_before = before_snapshot.logical_state_digest,
        .logical_state_after = after_snapshot.logical_state_digest,
        .input_state_head = state_head_json(options.node_id, before_snapshot.authentication, before_snapshot.journal_bytes),
        .result_state_head = state_head_json(options.node_id, after_snapshot.authentication, after_snapshot.journal_bytes, false),
    };
}

std::string state_relocation_result_json(
    const StateRelocationResult& result) {
    return std::string("{\"format\":\"NATRAV_OVERLAY_STATE_RELOCATION_V1\",\"ok\":true") +
        ",\"state\":" + json_string(result.state_directory.string()) +
        ",\"input_state_head\":" + result.input_state_head +
        ",\"result_state_head\":" + result.result_state_head +
        ",\"configuration_event\":" +
            std::to_string(result.configuration_event) +
        ",\"relocated_unix_ms\":" +
            std::to_string(result.relocated_unix_ms) +
        ",\"from_generation\":" + json_string(result.from_generation) +
        ",\"from_digest\":" +
            json_string(datacube::hex_lower(result.from_digest)) +
        ",\"to_generation\":" + json_string(result.to_generation) +
        ",\"to_digest\":" +
            json_string(datacube::hex_lower(result.to_digest)) +
        ",\"identity_spki_sha256\":" +
            json_string(datacube::hex_lower(result.identity_spki_sha256)) +
        ",\"logical_state_before\":" +
            json_string(datacube::hex_lower(result.logical_state_before)) +
        ",\"logical_state_after\":" +
            json_string(datacube::hex_lower(result.logical_state_after)) +
        ",\"paths\":{\"old_state\":" +
            json_string(result.old_state_directory.string()) +
        ",\"new_state\":" +
            json_string(result.new_state_directory.string()) +
        ",\"old_control\":" +
            json_string(result.old_control_socket.string()) +
        ",\"new_control\":" +
            json_string(result.new_control_socket.string()) +
        ",\"old_certificate\":" +
            json_string(result.old_certificate.string()) +
        ",\"new_certificate\":" +
            json_string(result.new_certificate.string()) +
        ",\"old_private_key\":" +
            json_string(result.old_private_key.string()) +
        ",\"new_private_key\":" +
            json_string(result.new_private_key.string()) + "}}";
}

}  // namespace natrav_overlay
