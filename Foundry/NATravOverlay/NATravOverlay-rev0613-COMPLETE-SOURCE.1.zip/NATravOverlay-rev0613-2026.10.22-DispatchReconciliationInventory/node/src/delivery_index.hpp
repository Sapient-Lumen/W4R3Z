#pragma once

#include <cstddef>
#include <cstdint>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace natrav_overlay {
// AVL ordered by stable queue position, augmented with minimum time. Finds the
// earliest QUEUED eligible item without walking earlier delayed entries. No
// promotion sweep or assumption that the wall clock only moves forward.
class DeadlineIndex final {
public:
    DeadlineIndex();
    ~DeadlineIndex();
    DeadlineIndex(DeadlineIndex&&) noexcept;
    DeadlineIndex& operator=(DeadlineIndex&&) noexcept;
    DeadlineIndex(const DeadlineIndex&) = delete;
    DeadlineIndex& operator=(const DeadlineIndex&) = delete;
    void put(std::size_t key, std::uint64_t time);
    void erase(std::size_t key);
    [[nodiscard]] std::optional<std::size_t> first_due(
        std::uint64_t now, std::uint64_t& nodes_visited) const;
    [[nodiscard]] std::optional<std::uint64_t> minimum() const noexcept;
    [[nodiscard]] std::size_t size() const noexcept;
    // Structural differential-test surface; never called by the scheduler.
    [[nodiscard]] bool valid() const;
private:
    struct Node;
    std::unique_ptr<Node> root_;
};

using DeliveryBinding = std::pair<std::string, std::string>; // generation, SPKI hex
struct DeliveryIndexEntry final {
    std::string peer;
    DeliveryBinding binding;
    bool has_policy{false};
    bool attempts_exhausted{false};
    std::uint64_t expires{0U};
    std::uint64_t ready{0U};
};
enum class DeliveryChoiceKind { none, initialize_policy, expired, attempts_exhausted, ready };
struct DeliveryIndexChoice final {
    DeliveryChoiceKind kind{DeliveryChoiceKind::none};
    std::optional<std::size_t> index;
    std::optional<std::uint64_t> next_wake;
    std::uint64_t tree_nodes_visited{0U};
    std::uint64_t key_buckets_checked{0U};
};
// Derived from ordinary outbox replay. Only pending records occupy these trees;
// receipt/cancel/reject/expire erase them, and retry/rebind insert/update them.
class DeliveryIndex final {
public:
    void touch(std::size_t index, std::optional<DeliveryIndexEntry> entry);
    [[nodiscard]] DeliveryIndexChoice select(const std::string& peer,
        const std::vector<DeliveryBinding>& permitted, std::uint64_t now, bool routed) const;
    [[nodiscard]] std::size_t pending(const std::string& peer) const;
    [[nodiscard]] std::size_t pending() const noexcept;
    [[nodiscard]] std::size_t bound_pending(const std::string& peer, const DeliveryBinding& binding) const;
    [[nodiscard]] bool valid() const;
private:
    struct Peer final {
        DeadlineIndex expiry;
        std::set<std::size_t> policy_missing;
        std::set<std::size_t> exhausted;
        std::map<DeliveryBinding, DeadlineIndex> readiness;
        std::map<DeliveryBinding, std::size_t> bindings;
        std::size_t count{0U};
    };
    std::map<std::string, Peer> peers_;
    std::map<std::size_t, DeliveryIndexEntry> entries_;
};
} // namespace natrav_overlay
