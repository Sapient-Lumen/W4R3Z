#include "custody_runtime.hpp"

#include "custody_authority.hpp"
#include "custody_bundle.hpp"
#include "handoff_io.hpp"
#include "handoff_runtime.hpp"
#include "runtime.hpp"

#include <algorithm>
#include <chrono>
#include <set>
#include <span>
#include <unistd.h>

namespace natrav_overlay {
namespace {

constexpr std::string_view kRouteHeader = "NATRAV_CUSTODY_ROUTE_V1";
constexpr std::size_t kRouteFileLimit =
    64U + kCustodyRoutePartyLimit * (2U * kHandoffBindingLimit + 32U);

void require(const bool condition, const std::string_view code,
    const std::string_view detail) {
    if (!condition) { app_fail(code, detail); }
}

std::uint64_t now_ms() {
    const auto value = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    require(value > 0, "CLOCK_INVALID", "clock must be after the Unix epoch");
    return static_cast<std::uint64_t>(value);
}

std::uint8_t nibble(const char value) {
    if (value >= '0' && value <= '9') {
        return static_cast<std::uint8_t>(value - '0');
    }
    if (value >= 'a' && value <= 'f') {
        return static_cast<std::uint8_t>(value - 'a' + 10);
    }
    app_fail("CUSTODY_ROUTE_REJECTED",
        "route bindings require lowercase hexadecimal");
}

datacube::Octets decode_hex(const std::string_view value) {
    require(!value.empty() && value.size() % 2U == 0U &&
            value.size() <= 2U * kHandoffBindingLimit,
        "CUSTODY_ROUTE_REJECTED", "route binding hexadecimal length");
    datacube::Octets result;
    result.reserve(value.size() / 2U);
    for (std::size_t offset = 0U; offset < value.size(); offset += 2U) {
        result.push_back(static_cast<std::uint8_t>(
            static_cast<unsigned int>(nibble(value[offset])) * 16U +
            nibble(value[offset + 1U])));
    }
    return result;
}

std::vector<HandoffBinding> read_route_bindings(
    const std::filesystem::path& path) {
    const auto bytes = read_handoff_file(path, kRouteFileLimit);
    const std::string text(reinterpret_cast<const char*>(bytes.data()),
        bytes.size());
    require(!text.empty() && text.back() == '\n',
        "CUSTODY_ROUTE_REJECTED", "route file requires final newline");
    std::vector<HandoffBinding> result;
    std::size_t offset = 0U;
    const auto first = text.find('\n');
    require(first != std::string::npos &&
            std::string_view(text).substr(0U, first) == kRouteHeader,
        "CUSTODY_ROUTE_REJECTED", "route file header");
    offset = first + 1U;
    std::string canonical = std::string(kRouteHeader) + "\n";
    while (offset < text.size()) {
        const auto end = text.find('\n', offset);
        require(end != std::string::npos,
            "CUSTODY_ROUTE_REJECTED", "route line termination");
        const auto line = std::string_view(text).substr(offset, end - offset);
        constexpr std::string_view prefix = "binding_hex=";
        require(line.starts_with(prefix) && line.size() > prefix.size(),
            "CUSTODY_ROUTE_REJECTED", "route binding field");
        const auto binding_bytes = decode_hex(line.substr(prefix.size()));
        auto binding = decode_handoff_binding(binding_bytes);
        canonical += std::string(prefix) + hex_bytes(binding.canonical) + "\n";
        result.push_back(std::move(binding));
        offset = end + 1U;
    }
    require(result.size() >= 2U &&
            result.size() <= kCustodyRoutePartyLimit,
        "CUSTODY_ROUTE_REJECTED", "route party count");
    require(canonical == text, "CUSTODY_ROUTE_REJECTED",
        "route file is not canonical");
    return result;
}

CustodyParty party_from_binding(const HandoffBinding& binding) {
    CustodyParty party;
    party.node = binding.node;
    party.signing_generation = binding.signing_generation;
    party.signing_public = binding.signing_public;
    static_cast<void>(custody_party_signing_pin(party));
    return party;
}

bool same_party(const CustodyParty& party, const HandoffBinding& binding) {
    return party.node == binding.node &&
        party.signing_generation == binding.signing_generation &&
        party.signing_public == binding.signing_public;
}

void require_capsule_route_binding(const RuntimeConfig& config,
    const CustodyEnvelope& envelope, const datacube::OctetView capsule,
    const bool require_active_handoff_keys) {
    require_custody_capsule(envelope, capsule);
    const auto origin = peek_handoff_origin(capsule);
    const auto recipient = peek_handoff_recipient(capsule);
    require(same_party(envelope.route.front(), origin) &&
            same_party(envelope.route.back(), recipient),
        "CUSTODY_CAPSULE_ROUTE_MISMATCH",
        "capsule origin and recipient differ from custody route endpoints");
    if (config.format_version >= 20U) {
        require_handoff_key_use(
            config.handoff_keys, origin, require_active_handoff_keys);
        require_handoff_key_use(
            config.handoff_keys, recipient, require_active_handoff_keys);
    }
}

std::uint64_t current_configuration_event(
    NodeState& state, const RuntimeConfig& config) {
    require(config.format_version >= 21U &&
            !config.runtime_generation.empty(),
        "CUSTODY_POLICY_REQUIRED",
        "durable custody requires accepted V21 configuration");
    const auto canonical = canonical_runtime_config(config);
    return state.configuration_event_reference(config.runtime_generation,
        runtime_configuration_digest(canonical), canonical);
}

bool local_route_party(const RuntimeConfig& config,
    const CustodyEnvelope& envelope) {
    return std::any_of(envelope.route.begin(), envelope.route.end(),
        [&](const CustodyParty& party) {
            return party.node == config.local_node &&
                party.signing_generation == config.local_identity_generation;
        });
}

void require_local_party(const RuntimeConfig& config,
    const CustodyParty& party, const std::string_view detail) {
    require(party.node == config.local_node &&
            party.signing_generation == config.local_identity_generation,
        "CUSTODY_LOCAL_ROLE_REJECTED", detail);
    require_custody_party_authorized(config, party, false);
}

CustodyBundle bundle_from_case(const DurableCustodyCase& custody) {
    return CustodyBundle{
        .envelope = custody.envelope,
        .capsule = custody.capsule,
        .grants = custody.grants,
        .records = custody.records,
    };
}

std::size_t active_use_count(const StateSnapshot& snapshot,
    const CustodyGrantReference& reference) {
    return static_cast<std::size_t>(std::count_if(
        snapshot.custody_cases.begin(), snapshot.custody_cases.end(),
        [&](const DurableCustodyCase& custody) {
            return !custody.expired_ms && !custody.imported_ms &&
                std::find(custody.grants.begin(), custody.grants.end(),
                    reference) != custody.grants.end();
        }));
}

void require_registration_capacity(NodeState& state,
    const RuntimeConfig& config, const CustodyBundle& bundle) {
    const auto snapshot = state.snapshot();
    for (std::size_t hop = 0U; hop < bundle.grants.size(); ++hop) {
        const auto& reference = bundle.grants[hop];
        const auto& grant = resolve_custody_grant_reference(
            config, reference, bundle.envelope, hop, false);
        require(active_use_count(snapshot, reference) <
                grant.maximum_active_envelopes,
            "CUSTODY_GRANT_ACTIVE_LIMIT",
            "custody grant active-envelope quota reached");
    }
}

DurableCustodyCase require_case(NodeState& state,
    const datacube::Digest32& envelope) {
    const auto custody = state.custody_case(envelope);
    require(custody.has_value(), "CUSTODY_STATE_UNKNOWN",
        "custody envelope is not retained in durable state");
    return *custody;
}

DurableCustodyCase import_bundle(NodeState& state,
    const RuntimeConfig& config, const CustodyBundle& bundle,
    const std::uint64_t configuration_event) {
    require(local_route_party(config, bundle.envelope),
        "CUSTODY_LOCAL_ROLE_REJECTED",
        "local node is not a named party in this custody route");
    require_capsule_route_binding(config, bundle.envelope,
        bundle.capsule, false);
    require_custody_registration_authority(
        config, bundle.envelope, bundle.grants, false);
    const auto envelope_digest = custody_bundle_envelope_sha256(bundle);
    const auto existing = state.custody_case(envelope_digest);
    if (existing.has_value()) {
        require(existing->envelope.canonical == bundle.envelope.canonical &&
                existing->capsule == bundle.capsule &&
                existing->grants == bundle.grants,
            "CUSTODY_STATE_CONFLICT",
            "durable custody case differs from imported bundle");
    } else {
        require_registration_capacity(state, config, bundle);
        static_cast<void>(state.commit_custody_event(DurableCustodyEvent{
            .kind = DurableCustodyEventKind::registered,
            .envelope_sha256 = envelope_digest,
            .configuration_event = configuration_event,
            .event_ms = 0U,
            .envelope = bundle.envelope.canonical,
            .capsule = bundle.capsule,
            .grants = bundle.grants,
            .record = {},
            .code = {},
            .detail = {},
            .imported_operation = std::nullopt,
        }));
    }
    for (const auto& encoded : bundle.records) {
        const auto record = decode_custody_record(bundle.envelope, encoded);
        require(record.hop_index < bundle.grants.size(),
            "CUSTODY_GRANT_REFERENCE_REJECTED",
            "custody record hop lacks an exact grant");
        static_cast<void>(resolve_custody_grant_reference(config,
            bundle.grants[record.hop_index], bundle.envelope,
            record.hop_index, false));
        static_cast<void>(state.commit_custody_event(DurableCustodyEvent{
            .kind = DurableCustodyEventKind::record,
            .envelope_sha256 = envelope_digest,
            .configuration_event = configuration_event,
            .event_ms = 0U,
            .envelope = {},
            .capsule = {},
            .grants = {},
            .record = encoded,
            .code = {},
            .detail = {},
            .imported_operation = std::nullopt,
        }));
    }
    return require_case(state, envelope_digest);
}

std::string custody_result_json(const std::string_view status,
    const DurableCustodyCase& custody, const std::string_view detail = {}) {
    std::string out =
        "{\"format\":\"NATRAV_CUSTODY_COMMAND_RESULT_V1\",\"status\":" +
        json_string(status) +
        ",\"envelope_sha256\":" +
        json_string(operation_id_text(custody.envelope_sha256)) +
        ",\"current_party_index\":" +
        std::to_string(custody.progress.current_party_index) +
        ",\"awaiting_acceptance\":" +
        (custody.progress.awaiting_acceptance ? "true" : "false") +
        ",\"final_custody_accepted\":" +
        (custody.progress.final_custody_accepted(custody.envelope) ?
            "true" : "false") +
        ",\"records\":" + std::to_string(custody.records.size()) +
        ",\"uncertainties\":" +
        std::to_string(custody.uncertainties.size());
    if (!detail.empty()) { out += ",\"detail\":" + json_string(detail); }
    if (custody.imported_operation) {
        out += ",\"imported_operation\":" +
            json_string(operation_id_text(*custody.imported_operation));
    }
    return out + "}";
}

void publish_case(const std::filesystem::path& output,
    const DurableCustodyCase& custody) {
    publish_handoff_file(output, encode_custody_bundle(
        bundle_from_case(custody)));
}

bool last_record_is(const DurableCustodyCase& custody,
    const CustodyRecordKind kind, const std::size_t actor_index) {
    if (custody.records.empty()) { return false; }
    const auto record = decode_custody_record(
        custody.envelope, custody.records.back());
    return record.kind == kind && record.actor_index == actor_index;
}

} // namespace

std::string run_custody_command(const CustodyCommand& options) {
    const auto seed = load_runtime_config(options.config);
    require_handoff_state_owner(seed.state_directory);
    NodeState state(seed.state_directory, seed.local_node,
        seed.maximum_journal_bytes, seed.queue_limits);
    RuntimeConfiguration runtime(seed, state);
    const auto config = runtime.snapshot();
    require(config->format_version >= 21U,
        "CUSTODY_POLICY_REQUIRED",
        "custody commands require accepted V21 configuration");
    require(local_control_allows(config->local_control,
            static_cast<std::uint32_t>(::geteuid()),
            LocalControlClass::maintenance),
        "LOCAL_CONTROL_DENIED",
        "offline custody commands require owner maintenance authority");
    const auto configuration_event = current_configuration_event(state, *config);

    if (options.command == "custody-status") {
        return state.custody_status_json();
    }

    if (options.command == "custody-create") {
        const auto bindings = read_route_bindings(options.route);
        std::vector<CustodyParty> route;
        route.reserve(bindings.size());
        for (const auto& binding : bindings) {
            route.push_back(party_from_binding(binding));
            require_custody_party_authorized(*config, route.back(), true);
        }
        require_local_party(*config, route.front(),
            "only the named origin may create a custody envelope");
        const auto capsule = read_handoff_file(
            options.capsule, kHandoffCapsuleLimit);
        const auto capsule_origin = peek_handoff_origin(capsule);
        const auto capsule_recipient = peek_handoff_recipient(capsule);
        require(same_party(route.front(), capsule_origin) &&
                same_party(route.back(), capsule_recipient),
            "CUSTODY_CAPSULE_ROUTE_MISMATCH",
            "capsule endpoints differ from the custody route");
        if (config->format_version >= 20U) {
            require_handoff_key_use(config->handoff_keys,
                capsule_origin, true);
            require_handoff_key_use(config->handoff_keys,
                capsule_recipient, true);
        }
        auto signer = load_handoff_signer(*config);
        const auto envelope = make_custody_envelope(route, capsule,
            options.created_ms, options.expires_ms, signer.get());
        require(options.created_ms <= now_ms(), "CUSTODY_TIME_REJECTED",
            "custody envelope creation time is in the future");
        std::vector<CustodyGrantReference> grants;
        grants.reserve(route.size() - 1U);
        for (std::size_t hop = 0U; hop + 1U < route.size(); ++hop) {
            const auto* grant = find_matching_custody_relay_grant(
                config->custody_relay, envelope, hop, true);
            grants.push_back(custody_grant_reference(*grant));
        }
        CustodyBundle bundle{
            .envelope = envelope,
            .capsule = capsule,
            .grants = grants,
            .records = {},
        };
        auto custody = import_bundle(
            state, *config, bundle, configuration_event);
        publish_case(options.output, custody);
        return custody_result_json("CREATED_CUSTODY_HELD", custody);
    }

    if (options.command == "custody-offer" ||
        options.command == "custody-accept" ||
        options.command == "custody-final-import") {
        const auto encoded = read_handoff_file(
            options.input, kCustodyBundleLimit);
        const auto bundle = decode_custody_bundle(encoded);
        auto custody = import_bundle(
            state, *config, bundle, configuration_event);
        const auto local_index = static_cast<std::size_t>(
            std::distance(custody.envelope.route.begin(),
                std::find_if(custody.envelope.route.begin(),
                    custody.envelope.route.end(), [&](const CustodyParty& party) {
                        return party.node == config->local_node &&
                            party.signing_generation ==
                                config->local_identity_generation;
                    })));
        require(local_index < custody.envelope.route.size(),
            "CUSTODY_LOCAL_ROLE_REJECTED",
            "local node is not an exact route party");

        if (options.command == "custody-offer") {
            require(!custody.expired_ms && !custody.imported_ms,
                "CUSTODY_STATE_TERMINAL",
                "terminal custody case cannot offer transfer");
            if (custody.progress.awaiting_acceptance) {
                require(local_index == custody.progress.current_party_index &&
                        last_record_is(custody,
                            CustodyRecordKind::transfer, local_index),
                    "CUSTODY_TRANSFER_ALREADY_PENDING",
                    "another transfer offer is already unresolved");
                publish_case(options.output, custody);
                return custody_result_json(
                    "TRANSFER_ALREADY_COMMITTED", custody);
            }
            require(local_index == custody.progress.current_party_index &&
                    local_index + 1U < custody.envelope.route.size(),
                "CUSTODY_LOCAL_ROLE_REJECTED",
                "only the current non-final custodian may offer transfer");
            require_custody_party_authorized(*config,
                custody.envelope.route[local_index], true);
            require_custody_party_authorized(*config,
                custody.envelope.route[local_index + 1U], true);
            static_cast<void>(resolve_custody_grant_reference(*config,
                custody.grants[local_index], custody.envelope,
                local_index, true));
            auto signer = load_handoff_signer(*config);
            const auto record = make_custody_transfer(custody.envelope,
                custody.progress, now_ms(), signer.get());
            static_cast<void>(state.commit_custody_event(DurableCustodyEvent{
                .kind = DurableCustodyEventKind::record,
                .envelope_sha256 = custody.envelope_sha256,
                .configuration_event = configuration_event,
                .event_ms = 0U,
                .envelope = {}, .capsule = {}, .grants = {},
                .record = record.canonical, .code = {}, .detail = {},
                .imported_operation = std::nullopt,
            }));
            custody = require_case(state, custody.envelope_sha256);
            publish_case(options.output, custody);
            return custody_result_json("TRANSFER_OFFER_COMMITTED", custody);
        }

        if (options.command == "custody-accept") {
            require(!custody.expired_ms && !custody.imported_ms,
                "CUSTODY_STATE_TERMINAL",
                "terminal custody case cannot accept transfer");
            if (!custody.progress.awaiting_acceptance) {
                require(local_index == custody.progress.current_party_index &&
                        local_index > 0U &&
                        last_record_is(custody,
                            CustodyRecordKind::acceptance, local_index),
                    "CUSTODY_ACCEPTANCE_NOT_PENDING",
                    "no transfer offer awaits this local party");
                publish_case(options.output, custody);
                return custody_result_json(
                    "ACCEPTANCE_ALREADY_COMMITTED", custody);
            }
            const auto hop = static_cast<std::size_t>(
                custody.progress.current_party_index);
            require(local_index == hop + 1U,
                "CUSTODY_LOCAL_ROLE_REJECTED",
                "only the exact next route party may accept custody");
            require_custody_party_authorized(*config,
                custody.envelope.route[local_index], false);
            static_cast<void>(resolve_custody_grant_reference(*config,
                custody.grants[hop], custody.envelope, hop, false));
            auto signer = load_handoff_signer(*config);
            const auto record = make_custody_acceptance(custody.envelope,
                custody.progress, now_ms(), signer.get());
            static_cast<void>(state.commit_custody_event(DurableCustodyEvent{
                .kind = DurableCustodyEventKind::record,
                .envelope_sha256 = custody.envelope_sha256,
                .configuration_event = configuration_event,
                .event_ms = 0U,
                .envelope = {}, .capsule = {}, .grants = {},
                .record = record.canonical, .code = {}, .detail = {},
                .imported_operation = std::nullopt,
            }));
            custody = require_case(state, custody.envelope_sha256);
            publish_case(options.output, custody);
            return custody_result_json("CUSTODY_ACCEPTED", custody);
        }

        require(local_index + 1U == custody.envelope.route.size(),
            "CUSTODY_LOCAL_ROLE_REJECTED",
            "only the final named recipient may import the capsule");
        require(custody.progress.final_custody_accepted(custody.envelope),
            "CUSTODY_FINAL_ACCEPTANCE_REQUIRED",
            "final recipient has not accepted custody");
        require(!custody.expired_ms && now_ms() <= custody.envelope.expires_ms,
            "CUSTODY_STATE_EXPIRED",
            "expired custody case cannot import its capsule");
        if (custody.imported_operation) {
            return custody_result_json("ALREADY_IMPORTED", custody);
        }
        auto local_key = load_handoff_key(options.key_directory, *config);
        const auto imported = import_handoff_capsule(state, *config,
            *local_key, custody.capsule, now_ms());
        static_cast<void>(state.commit_custody_event(DurableCustodyEvent{
            .kind = DurableCustodyEventKind::imported,
            .envelope_sha256 = custody.envelope_sha256,
            .configuration_event = configuration_event,
            .event_ms = now_ms(),
            .envelope = {}, .capsule = {}, .grants = {}, .record = {},
            .code = {}, .detail = {},
            .imported_operation = imported.operation_id,
        }));
        custody = require_case(state, custody.envelope_sha256);
        return custody_result_json("FINAL_CAPSULE_IMPORTED", custody,
            handoff_import_result_json(imported));
    }

    require(options.has_envelope_sha256,
        "CUSTODY_ENVELOPE_REQUIRED", "exact envelope digest required");
    auto custody = require_case(state, options.envelope_sha256);
    const auto local_index = static_cast<std::size_t>(
        std::distance(custody.envelope.route.begin(),
            std::find_if(custody.envelope.route.begin(),
                custody.envelope.route.end(), [&](const CustodyParty& party) {
                    return party.node == config->local_node &&
                        party.signing_generation ==
                            config->local_identity_generation;
                })));
    require(local_index == custody.progress.current_party_index,
        "CUSTODY_LOCAL_ROLE_REJECTED",
        "only the current custodian may record this transition");

    if (options.command == "custody-uncertain") {
        require(custody.progress.awaiting_acceptance &&
                local_index < custody.grants.size(),
            "CUSTODY_UNCERTAINTY_REJECTED",
            "uncertainty requires an unresolved transfer offer");
        static_cast<void>(resolve_custody_grant_reference(*config,
            custody.grants[local_index], custody.envelope,
            local_index, false));
        static_cast<void>(state.commit_custody_event(DurableCustodyEvent{
            .kind = DurableCustodyEventKind::uncertainty,
            .envelope_sha256 = custody.envelope_sha256,
            .configuration_event = configuration_event,
            .event_ms = now_ms(),
            .envelope = {}, .capsule = {}, .grants = {}, .record = {},
            .code = options.code, .detail = options.detail,
            .imported_operation = std::nullopt,
        }));
        custody = require_case(state, custody.envelope_sha256);
        return custody_result_json("UNCERTAINTY_RECORDED", custody);
    }

    require(options.command == "custody-expire", "UNKNOWN_COMMAND",
        "unknown custody operation");
    if (!custody.expired_ms) {
        static_cast<void>(state.commit_custody_event(DurableCustodyEvent{
            .kind = DurableCustodyEventKind::expired,
            .envelope_sha256 = custody.envelope_sha256,
            .configuration_event = configuration_event,
            .event_ms = now_ms(),
            .envelope = {}, .capsule = {}, .grants = {}, .record = {},
            .code = {}, .detail = {},
            .imported_operation = std::nullopt,
        }));
        custody = require_case(state, custody.envelope_sha256);
    }
    return custody_result_json("EXPIRED", custody);
}

} // namespace natrav_overlay
