#include "adapter_profile_catalog.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <charconv>
#include <climits>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <filesystem>
#include <limits>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace natrav_overlay {

int durable_adapter_profile_catalog_revision_abi() noexcept { return 1; }

AdapterCatalogError::AdapterCatalogError(std::string code, std::string detail)
    : std::runtime_error(code + ": " + detail), code_(std::move(code)) {}

const std::string& AdapterCatalogError::code() const noexcept { return code_; }

namespace {

inline constexpr std::string_view kEndpointMagic =
    "NATRAV_ADAPTER_ENDPOINT_V1";
inline constexpr std::string_view kEventMagic =
    "NATRAV_ADAPTER_CATALOG_EVENT_V1";
inline constexpr std::array<std::uint8_t, 8U> kCatalogMagic{
    'N', 'A', 'P', 'C', 'A', 'T', '0', '1'};
inline constexpr std::array<std::uint8_t, 8U> kRecordMagic{
    'N', 'A', 'P', 'R', 'E', 'C', '0', '1'};
inline constexpr std::array<std::uint8_t, 8U> kTrailerMagic{
    'N', 'A', 'P', 'E', 'N', 'D', '0', '1'};
inline constexpr std::size_t kCatalogHeaderBytes = 16U;
inline constexpr std::size_t kRecordHeaderBytes = 88U;
inline constexpr std::size_t kRecordDigestBytes = 32U;
inline constexpr std::size_t kRecordTrailerBytes = 8U;
inline constexpr std::size_t kRecordFixedBytes =
    kRecordHeaderBytes + kRecordDigestBytes + kRecordTrailerBytes;
inline constexpr std::size_t kMaximumEventPayloadBytes = 262'144U;
inline constexpr std::size_t kMaximumEndpointIdBytes = 64U;
inline constexpr std::size_t kMaximumRejectionCodeBytes = 64U;

[[noreturn]] void fail(
    const std::string_view code,
    const std::string_view detail) {
    throw AdapterCatalogError(std::string(code), std::string(detail));
}

[[nodiscard]] bool is_zero_digest(const AdapterSha256& digest) noexcept {
    return std::all_of(digest.begin(), digest.end(), [](const std::uint8_t byte) {
        return byte == 0U;
    });
}

[[nodiscard]] bool valid_identifier(const std::string_view value) noexcept {
    if (value.empty() || value.size() > kMaximumEndpointIdBytes ||
        value.front() < 'a' || value.front() > 'z' ||
        !((value.back() >= 'a' && value.back() <= 'z') ||
          (value.back() >= '0' && value.back() <= '9'))) {
        return false;
    }
    return std::all_of(value.begin(), value.end(), [](const char character) {
        return (character >= 'a' && character <= 'z') ||
            (character >= '0' && character <= '9') || character == '-';
    });
}

[[nodiscard]] bool valid_rejection_code(const std::string_view value) noexcept {
    return !value.empty() && value.size() <= kMaximumRejectionCodeBytes &&
        std::all_of(value.begin(), value.end(), [](const char character) {
            return (character >= 'A' && character <= 'Z') ||
                (character >= '0' && character <= '9') || character == '_';
        });
}

[[nodiscard]] std::uint64_t parse_u64(
    const std::string_view text,
    const std::string_view field,
    const bool allow_zero = false) {
    if (text.empty() || (text.size() > 1U && text.front() == '0')) {
        fail("ADAPTER_CATALOG_NONCANONICAL", field);
    }
    std::uint64_t value = 0U;
    const auto [end, error] = std::from_chars(
        text.data(), text.data() + text.size(), value, 10);
    if (error != std::errc{} || end != text.data() + text.size() ||
        (!allow_zero && value == 0U)) {
        fail("ADAPTER_CATALOG_INVALID_NUMBER", field);
    }
    return value;
}

[[nodiscard]] std::size_t checked_size(
    const std::uint64_t value,
    const std::string_view field) {
    if (value > std::numeric_limits<std::size_t>::max()) {
        fail("ADAPTER_CATALOG_INVALID_NUMBER", field);
    }
    return static_cast<std::size_t>(value);
}

[[nodiscard]] std::vector<std::string_view> split_canonical_lines(
    const std::string_view text,
    const std::string_view context) {
    if (text.empty() || text.back() != '\n' || text.find('\r') != std::string_view::npos) {
        fail("ADAPTER_CATALOG_NONCANONICAL", context);
    }
    std::vector<std::string_view> lines;
    std::size_t offset = 0U;
    while (offset < text.size()) {
        const auto end = text.find('\n', offset);
        if (end == std::string_view::npos) {
            fail("ADAPTER_CATALOG_NONCANONICAL", context);
        }
        lines.push_back(text.substr(offset, end - offset));
        offset = end + 1U;
    }
    return lines;
}

[[nodiscard]] std::string_view field_value(
    const std::string_view line,
    const std::string_view prefix,
    const std::string_view context) {
    if (!line.starts_with(prefix)) {
        fail("ADAPTER_CATALOG_NONCANONICAL", context);
    }
    return line.substr(prefix.size());
}

[[nodiscard]] std::string bytes_hex(
    const std::span<const std::uint8_t> bytes) {
    static constexpr std::array<char, 16U> digits{
        '0', '1', '2', '3', '4', '5', '6', '7',
        '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
    std::string output;
    output.reserve(bytes.size() * 2U);
    for (const auto byte : bytes) {
        output.push_back(digits[(byte >> 4U) & 0x0fU]);
        output.push_back(digits[byte & 0x0fU]);
    }
    return output;
}

[[nodiscard]] std::vector<std::uint8_t> parse_bytes_hex(
    const std::string_view text,
    const std::string_view field) {
    if ((text.size() % 2U) != 0U) {
        fail("ADAPTER_CATALOG_NONCANONICAL", field);
    }
    const auto nibble = [&](const char character) -> std::uint8_t {
        if (character >= '0' && character <= '9') {
            return static_cast<std::uint8_t>(character - '0');
        }
        if (character >= 'a' && character <= 'f') {
            return static_cast<std::uint8_t>(10 + character - 'a');
        }
        fail("ADAPTER_CATALOG_NONCANONICAL", field);
    };
    std::vector<std::uint8_t> output;
    output.reserve(text.size() / 2U);
    for (std::size_t offset = 0U; offset < text.size(); offset += 2U) {
        output.push_back(static_cast<std::uint8_t>(
            (nibble(text[offset]) << 4U) | nibble(text[offset + 1U])));
    }
    return output;
}

[[nodiscard]] std::string endpoint_role_text(const AdapterEndpointRole role) {
    switch (role) {
        case AdapterEndpointRole::route:
            return "route";
        case AdapterEndpointRole::listener:
            return "listener";
    }
    fail("ADAPTER_ENDPOINT_INVALID_ROLE", "unknown endpoint role");
}

[[nodiscard]] AdapterEndpointRole parse_endpoint_role(
    const std::string_view text) {
    if (text == "route") {
        return AdapterEndpointRole::route;
    }
    if (text == "listener") {
        return AdapterEndpointRole::listener;
    }
    fail("ADAPTER_ENDPOINT_INVALID_ROLE", text);
}

[[nodiscard]] std::string canonical_endpoint_text(
    const ConfiguredAdapterEndpoint& endpoint) {
    std::string output;
    output.reserve(512U);
    output.append(kEndpointMagic);
    output.push_back('\n');
    output.append("id=");
    output.append(endpoint.endpoint_id);
    output.push_back('\n');
    output.append("generation=");
    output.append(std::to_string(endpoint.generation));
    output.push_back('\n');
    output.append("previous=");
    output.append(adapter_sha256_hex(endpoint.previous_endpoint_sha256));
    output.push_back('\n');
    output.append("role=");
    output.append(endpoint_role_text(endpoint.role));
    output.push_back('\n');
    output.append("locator=");
    output.append(adapter_transport_locator_text(endpoint.locator));
    output.push_back('\n');
    output.append("profile-sha256=");
    output.append(adapter_sha256_hex(endpoint.profile_sha256));
    output.push_back('\n');
    return output;
}

void validate_limits(const AdapterCatalogLimits& limits) {
    if (limits.maximum_file_bytes < 4'096U ||
        limits.maximum_file_bytes > 256U * 1'048'576U ||
        limits.maximum_records == 0U || limits.maximum_records > 65'536U ||
        limits.maximum_profiles == 0U ||
        limits.maximum_profiles > limits.maximum_records ||
        limits.maximum_endpoints == 0U ||
        limits.maximum_endpoints > limits.maximum_records ||
        limits.maximum_rejections == 0U ||
        limits.maximum_rejections > limits.maximum_records ||
        limits.maximum_authority_evidence_bytes == 0U ||
        limits.maximum_authority_evidence_bytes > 65'536U) {
        fail("ADAPTER_CATALOG_INVALID_LIMITS", "catalog limits are outside bounds");
    }
}

[[nodiscard]] bool canonical_absolute_file_path(
    const std::filesystem::path& path) {
    const auto text = path.string();
    if (text.empty() || text.find('\0') != std::string::npos ||
        !path.is_absolute() || path == path.root_path() ||
        path.lexically_normal() != path || text.back() == '/') {
        return false;
    }
    for (const auto& component : path.relative_path()) {
        const auto part = component.string();
        if (part.empty() || part == "." || part == ".." ||
            part.find('\0') != std::string::npos) {
            return false;
        }
    }
    return true;
}

class UniqueFd final {
public:
    explicit UniqueFd(const int descriptor = -1) noexcept : descriptor_(descriptor) {}
    UniqueFd(const UniqueFd&) = delete;
    UniqueFd& operator=(const UniqueFd&) = delete;
    UniqueFd(UniqueFd&& other) noexcept
        : descriptor_(std::exchange(other.descriptor_, -1)) {}
    UniqueFd& operator=(UniqueFd&& other) noexcept {
        if (this != &other) {
            reset();
            descriptor_ = std::exchange(other.descriptor_, -1);
        }
        return *this;
    }
    ~UniqueFd() { reset(); }
    [[nodiscard]] int get() const noexcept { return descriptor_; }
    void reset(const int descriptor = -1) noexcept {
        if (descriptor_ >= 0) {
            static_cast<void>(::close(descriptor_));
        }
        descriptor_ = descriptor;
    }
private:
    int descriptor_{-1};
};

struct LockedCatalogFile final {
    UniqueFd parent{};
    UniqueFd file{};
    std::string filename{};
    dev_t device{0};
    ino_t inode{0};
    bool created{false};
};

[[nodiscard]] std::string errno_detail(
    const std::string_view operation,
    const int error) {
    return std::string(operation) + ": " + std::strerror(error);
}

void require_same_path_object(const LockedCatalogFile& catalog) {
    struct stat path_status {};
    if (::fstatat(
            catalog.parent.get(),
            catalog.filename.c_str(),
            &path_status,
            AT_SYMLINK_NOFOLLOW) != 0) {
        fail("ADAPTER_CATALOG_PATH_REPLACED",
             errno_detail("fstatat catalog path", errno));
    }
    if (!S_ISREG(path_status.st_mode) || path_status.st_dev != catalog.device ||
        path_status.st_ino != catalog.inode) {
        fail("ADAPTER_CATALOG_PATH_REPLACED", "catalog path no longer names opened file");
    }
}

[[nodiscard]] LockedCatalogFile open_locked_catalog(
    const std::filesystem::path& path,
    const AdapterCatalogLimits& limits) {
    if (!canonical_absolute_file_path(path)) {
        fail("ADAPTER_CATALOG_INVALID_PATH", path.string());
    }
    UniqueFd current(::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC));
    if (current.get() < 0) {
        fail("ADAPTER_CATALOG_OPEN_FAILED", errno_detail("open root", errno));
    }
    const auto parent_path = path.parent_path();
    for (const auto& component : parent_path.relative_path()) {
        const auto part = component.string();
        const int descriptor = ::openat(
            current.get(),
            part.c_str(),
            O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
        if (descriptor < 0) {
            fail("ADAPTER_CATALOG_OPEN_FAILED",
                 errno_detail("open catalog parent component", errno));
        }
        current.reset(descriptor);
    }
    struct stat parent_status {};
    if (::fstat(current.get(), &parent_status) != 0) {
        fail("ADAPTER_CATALOG_OPEN_FAILED", errno_detail("fstat parent", errno));
    }
    if (!S_ISDIR(parent_status.st_mode) || parent_status.st_uid != ::geteuid() ||
        (parent_status.st_mode & static_cast<mode_t>(0077)) != 0) {
        fail("ADAPTER_CATALOG_UNSAFE_PARENT",
             "final parent must be owner-controlled and inaccessible to group/other");
    }

    const auto filename = path.filename().string();
    bool created = false;
    int descriptor = ::openat(
        current.get(),
        filename.c_str(),
        O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW,
        S_IRUSR | S_IWUSR);
    if (descriptor >= 0) {
        created = true;
    } else if (errno == EEXIST) {
        descriptor = ::openat(
            current.get(),
            filename.c_str(),
            O_RDWR | O_CLOEXEC | O_NOFOLLOW);
    }
    if (descriptor < 0) {
        fail("ADAPTER_CATALOG_OPEN_FAILED", errno_detail("open catalog", errno));
    }
    UniqueFd file(descriptor);
    if (::flock(file.get(), LOCK_EX) != 0) {
        fail("ADAPTER_CATALOG_LOCK_FAILED", errno_detail("flock catalog", errno));
    }
    struct stat file_status {};
    if (::fstat(file.get(), &file_status) != 0) {
        fail("ADAPTER_CATALOG_OPEN_FAILED", errno_detail("fstat catalog", errno));
    }
    if (!S_ISREG(file_status.st_mode) || file_status.st_uid != ::geteuid() ||
        (file_status.st_mode & static_cast<mode_t>(0077 | S_ISUID | S_ISGID)) != 0 ||
        file_status.st_nlink != 1) {
        fail("ADAPTER_CATALOG_UNSAFE_FILE",
             "catalog must be one owner-private regular file without aliases");
    }
    if (file_status.st_size < 0 ||
        static_cast<std::uint64_t>(file_status.st_size) > limits.maximum_file_bytes) {
        fail("ADAPTER_CATALOG_LIMIT_EXHAUSTED", "catalog file size");
    }
    LockedCatalogFile result{
        .parent = std::move(current),
        .file = std::move(file),
        .filename = filename,
        .device = file_status.st_dev,
        .inode = file_status.st_ino,
        .created = created,
    };
    require_same_path_object(result);
    if (created && ::fsync(result.parent.get()) != 0) {
        fail("ADAPTER_CATALOG_SYNC_FAILED", errno_detail("fsync parent", errno));
    }
    return result;
}

void write_all(const int descriptor, const std::span<const std::uint8_t> bytes) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto count = ::write(
            descriptor,
            bytes.data() + offset,
            bytes.size() - offset);
        if (count > 0) {
            offset += static_cast<std::size_t>(count);
            continue;
        }
        if (count < 0 && errno == EINTR) {
            continue;
        }
        fail("ADAPTER_CATALOG_WRITE_FAILED", errno_detail("write catalog", errno));
    }
}

[[nodiscard]] std::vector<std::uint8_t> read_all(
    const int descriptor,
    const std::size_t maximum_bytes) {
    struct stat status {};
    if (::fstat(descriptor, &status) != 0) {
        fail("ADAPTER_CATALOG_READ_FAILED", errno_detail("fstat catalog", errno));
    }
    if (status.st_size < 0 ||
        static_cast<std::uint64_t>(status.st_size) > maximum_bytes) {
        fail("ADAPTER_CATALOG_LIMIT_EXHAUSTED", "catalog file size");
    }
    const auto size = static_cast<std::size_t>(status.st_size);
    std::vector<std::uint8_t> bytes(size);
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto count = ::pread(
            descriptor,
            bytes.data() + offset,
            bytes.size() - offset,
            static_cast<off_t>(offset));
        if (count > 0) {
            offset += static_cast<std::size_t>(count);
            continue;
        }
        if (count < 0 && errno == EINTR) {
            continue;
        }
        if (count == 0) {
            fail("ADAPTER_CATALOG_READ_FAILED", "unexpected EOF");
        }
        fail("ADAPTER_CATALOG_READ_FAILED", errno_detail("pread catalog", errno));
    }
    return bytes;
}

void append_be32(std::vector<std::uint8_t>& bytes, const std::uint32_t value) {
    for (int shift = 24; shift >= 0; shift -= 8) {
        bytes.push_back(static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(shift)) & 0xffU));
    }
}

void append_be64(std::vector<std::uint8_t>& bytes, const std::uint64_t value) {
    for (int shift = 56; shift >= 0; shift -= 8) {
        bytes.push_back(static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(shift)) & 0xffU));
    }
}

[[nodiscard]] std::uint32_t read_be32(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) {
    if (offset > bytes.size() || bytes.size() - offset < 4U) {
        fail("ADAPTER_CATALOG_CORRUPT", "truncated u32");
    }
    std::uint32_t value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
        value = (value << 8U) | bytes[offset + index];
    }
    return value;
}

[[nodiscard]] std::uint64_t read_be64(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) {
    if (offset > bytes.size() || bytes.size() - offset < 8U) {
        fail("ADAPTER_CATALOG_CORRUPT", "truncated u64");
    }
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value = (value << 8U) | bytes[offset + index];
    }
    return value;
}

[[nodiscard]] AdapterSha256 read_digest(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) {
    if (offset > bytes.size() || bytes.size() - offset < 32U) {
        fail("ADAPTER_CATALOG_CORRUPT", "truncated digest");
    }
    AdapterSha256 digest{};
    std::copy_n(bytes.begin() + static_cast<std::ptrdiff_t>(offset), 32U, digest.begin());
    return digest;
}

void append_digest(
    std::vector<std::uint8_t>& bytes,
    const AdapterSha256& digest) {
    bytes.insert(bytes.end(), digest.begin(), digest.end());
}

[[nodiscard]] std::vector<std::uint8_t> catalog_header() {
    std::vector<std::uint8_t> bytes;
    bytes.insert(bytes.end(), kCatalogMagic.begin(), kCatalogMagic.end());
    append_be32(bytes, 1U);
    append_be32(bytes, 0U);
    return bytes;
}

void ensure_initialized(LockedCatalogFile& catalog) {
    struct stat status {};
    if (::fstat(catalog.file.get(), &status) != 0) {
        fail("ADAPTER_CATALOG_OPEN_FAILED", errno_detail("fstat catalog", errno));
    }
    if (status.st_size != 0) {
        return;
    }
    const auto header = catalog_header();
    if (::lseek(catalog.file.get(), 0, SEEK_SET) < 0) {
        fail("ADAPTER_CATALOG_WRITE_FAILED", errno_detail("seek catalog", errno));
    }
    write_all(catalog.file.get(), header);
    if (::fsync(catalog.file.get()) != 0) {
        fail("ADAPTER_CATALOG_SYNC_FAILED", errno_detail("fsync catalog", errno));
    }
    require_same_path_object(catalog);
}

enum class EventKind {
    profile_accepted,
    endpoint_accepted,
    rejected,
    recovery,
};

struct ParsedEvent final {
    EventKind kind{EventKind::profile_accepted};
    AdapterSha256 authority{};
    std::vector<std::uint8_t> object{};
    AdapterCatalogOperation operation{AdapterCatalogOperation::profile_create};
    AdapterSha256 object_sha256{};
    std::string rejection_code{};
    std::size_t discarded_bytes{0U};
    AdapterSha256 discarded_sha256{};
};

[[nodiscard]] AdapterCatalogOperation parse_operation(
    const std::string_view text) {
    if (text == "profile-create") {
        return AdapterCatalogOperation::profile_create;
    }
    if (text == "profile-replace") {
        return AdapterCatalogOperation::profile_replace;
    }
    if (text == "endpoint-create") {
        return AdapterCatalogOperation::endpoint_create;
    }
    if (text == "endpoint-replace") {
        return AdapterCatalogOperation::endpoint_replace;
    }
    fail("ADAPTER_CATALOG_CORRUPT", "unknown operation");
}

[[nodiscard]] std::string accepted_event_text(
    const EventKind kind,
    const AdapterSha256& authority,
    const std::span<const std::uint8_t> object) {
    std::string output;
    output.reserve(256U + object.size() * 2U);
    output.append(kEventMagic);
    output.push_back('\n');
    output.append("kind=");
    output.append(kind == EventKind::profile_accepted
                      ? "profile-accepted"
                      : "endpoint-accepted");
    output.push_back('\n');
    output.append("authority=");
    output.append(adapter_sha256_hex(authority));
    output.push_back('\n');
    output.append("object=");
    output.append(bytes_hex(object));
    output.push_back('\n');
    return output;
}

[[nodiscard]] std::string rejection_event_text(
    const AdapterCatalogOperation operation,
    const AdapterSha256& authority,
    const AdapterSha256& object,
    const std::string_view code) {
    std::string output;
    output.reserve(384U);
    output.append(kEventMagic);
    output.push_back('\n');
    output.append("kind=rejected\noperation=");
    output.append(adapter_catalog_operation_text(operation));
    output.push_back('\n');
    output.append("authority=");
    output.append(adapter_sha256_hex(authority));
    output.push_back('\n');
    output.append("object-sha256=");
    output.append(adapter_sha256_hex(object));
    output.push_back('\n');
    output.append("code=");
    output.append(code);
    output.push_back('\n');
    return output;
}

[[nodiscard]] std::string recovery_event_text(
    const std::size_t discarded_bytes,
    const AdapterSha256& discarded_sha256) {
    std::string output;
    output.reserve(256U);
    output.append(kEventMagic);
    output.append("\nkind=recovery\ndiscarded-bytes=");
    output.append(std::to_string(discarded_bytes));
    output.append("\ndiscarded-sha256=");
    output.append(adapter_sha256_hex(discarded_sha256));
    output.push_back('\n');
    return output;
}

[[nodiscard]] ParsedEvent parse_event(const std::span<const std::uint8_t> bytes) {
    const std::string text(bytes.begin(), bytes.end());
    const auto lines = split_canonical_lines(text, "catalog event");
    if (lines.size() < 2U || lines[0U] != kEventMagic) {
        fail("ADAPTER_CATALOG_CORRUPT", "event magic");
    }
    const auto kind = field_value(lines[1U], "kind=", "event kind");
    ParsedEvent event;
    if (kind == "profile-accepted" || kind == "endpoint-accepted") {
        if (lines.size() != 4U) {
            fail("ADAPTER_CATALOG_CORRUPT", "accepted event fields");
        }
        event.kind = kind == "profile-accepted"
            ? EventKind::profile_accepted
            : EventKind::endpoint_accepted;
        event.authority = parse_adapter_sha256(
            field_value(lines[2U], "authority=", "event authority"));
        event.object = parse_bytes_hex(
            field_value(lines[3U], "object=", "event object"),
            "event object");
        if (accepted_event_text(event.kind, event.authority, event.object) != text) {
            fail("ADAPTER_CATALOG_CORRUPT", "noncanonical accepted event");
        }
        return event;
    }
    if (kind == "rejected") {
        if (lines.size() != 6U) {
            fail("ADAPTER_CATALOG_CORRUPT", "rejection event fields");
        }
        event.kind = EventKind::rejected;
        event.operation = parse_operation(
            field_value(lines[2U], "operation=", "rejection operation"));
        event.authority = parse_adapter_sha256(
            field_value(lines[3U], "authority=", "rejection authority"));
        event.object_sha256 = parse_adapter_sha256(
            field_value(lines[4U], "object-sha256=", "rejection object"));
        event.rejection_code = std::string(
            field_value(lines[5U], "code=", "rejection code"));
        if (!valid_rejection_code(event.rejection_code) ||
            rejection_event_text(
                event.operation,
                event.authority,
                event.object_sha256,
                event.rejection_code) != text) {
            fail("ADAPTER_CATALOG_CORRUPT", "noncanonical rejection event");
        }
        return event;
    }
    if (kind == "recovery") {
        if (lines.size() != 4U) {
            fail("ADAPTER_CATALOG_CORRUPT", "recovery event fields");
        }
        event.kind = EventKind::recovery;
        event.discarded_bytes = checked_size(
            parse_u64(
                field_value(lines[2U], "discarded-bytes=", "discarded bytes"),
                "discarded bytes"),
            "discarded bytes");
        event.discarded_sha256 = parse_adapter_sha256(
            field_value(lines[3U], "discarded-sha256=", "discarded digest"));
        if (recovery_event_text(
                event.discarded_bytes,
                event.discarded_sha256) != text) {
            fail("ADAPTER_CATALOG_CORRUPT", "noncanonical recovery event");
        }
        return event;
    }
    fail("ADAPTER_CATALOG_CORRUPT", "unknown event kind");
}

[[nodiscard]] const AuthorizedAdapterProfileRecord* exact_profile(
    const AdapterProfileCatalogSnapshot& snapshot,
    const std::string_view profile_id,
    const std::uint64_t generation) {
    const AuthorizedAdapterProfileRecord* result = nullptr;
    for (const auto& record : snapshot.profiles) {
        if (record.profile.profile_id == profile_id &&
            record.profile.generation == generation) {
            if (result != nullptr) {
                fail("ADAPTER_CATALOG_DUPLICATE_PROFILE", profile_id);
            }
            result = &record;
        }
    }
    return result;
}

[[nodiscard]] const AuthorizedAdapterProfileRecord* current_profile(
    const AdapterProfileCatalogSnapshot& snapshot,
    const std::string_view profile_id) {
    const AuthorizedAdapterProfileRecord* result = nullptr;
    for (const auto& record : snapshot.profiles) {
        if (record.profile.profile_id != profile_id) {
            continue;
        }
        if (result == nullptr ||
            record.profile.generation > result->profile.generation) {
            result = &record;
        } else if (record.profile.generation == result->profile.generation) {
            fail("ADAPTER_CATALOG_DUPLICATE_PROFILE", profile_id);
        }
    }
    return result;
}

[[nodiscard]] const AuthorizedAdapterEndpointRecord* exact_endpoint(
    const AdapterProfileCatalogSnapshot& snapshot,
    const std::string_view endpoint_id,
    const std::uint64_t generation) {
    const AuthorizedAdapterEndpointRecord* result = nullptr;
    for (const auto& record : snapshot.endpoints) {
        if (record.endpoint.endpoint_id == endpoint_id &&
            record.endpoint.generation == generation) {
            if (result != nullptr) {
                fail("ADAPTER_CATALOG_DUPLICATE_ENDPOINT", endpoint_id);
            }
            result = &record;
        }
    }
    return result;
}

[[nodiscard]] const AuthorizedAdapterEndpointRecord* current_endpoint(
    const AdapterProfileCatalogSnapshot& snapshot,
    const std::string_view endpoint_id) {
    const AuthorizedAdapterEndpointRecord* result = nullptr;
    for (const auto& record : snapshot.endpoints) {
        if (record.endpoint.endpoint_id != endpoint_id) {
            continue;
        }
        if (result == nullptr ||
            record.endpoint.generation > result->endpoint.generation) {
            result = &record;
        } else if (record.endpoint.generation == result->endpoint.generation) {
            fail("ADAPTER_CATALOG_DUPLICATE_ENDPOINT", endpoint_id);
        }
    }
    return result;
}

void replay_event(
    AdapterProfileCatalogSnapshot& snapshot,
    const ParsedEvent& event,
    const std::uint64_t sequence,
    const AdapterSha256& record_digest,
    const AdapterCatalogLimits& limits) {
    if (event.kind == EventKind::profile_accepted) {
        if (snapshot.profiles.size() >= limits.maximum_profiles) {
            fail("ADAPTER_CATALOG_CORRUPT", "profile limit exceeded in journal");
        }
        const std::string text(event.object.begin(), event.object.end());
        const auto profile = parse_operator_pinned_adapter_profile(text);
        const auto* current = current_profile(snapshot, profile.profile_id);
        validate_operator_pinned_adapter_profile_transition(
            current == nullptr ? nullptr : &current->profile,
            profile);
        if (exact_profile(snapshot, profile.profile_id, profile.generation) != nullptr) {
            fail("ADAPTER_CATALOG_DUPLICATE_PROFILE", profile.profile_id);
        }
        snapshot.profiles.push_back(AuthorizedAdapterProfileRecord{
            .profile = profile,
            .authority_evidence_sha256 = event.authority,
            .sequence = sequence,
            .catalog_record_sha256 = record_digest,
        });
        return;
    }
    if (event.kind == EventKind::endpoint_accepted) {
        if (snapshot.endpoints.size() >= limits.maximum_endpoints) {
            fail("ADAPTER_CATALOG_CORRUPT", "endpoint limit exceeded in journal");
        }
        const std::string text(event.object.begin(), event.object.end());
        const auto endpoint = parse_configured_adapter_endpoint(text);
        const auto* current = current_endpoint(snapshot, endpoint.endpoint_id);
        validate_configured_adapter_endpoint_transition(
            current == nullptr ? nullptr : &current->endpoint,
            endpoint);
        if (exact_endpoint(snapshot, endpoint.endpoint_id, endpoint.generation) != nullptr) {
            fail("ADAPTER_CATALOG_DUPLICATE_ENDPOINT", endpoint.endpoint_id);
        }
        const auto* profile = exact_profile(
            snapshot,
            endpoint.locator.profile_id,
            endpoint.locator.profile_generation);
        if (profile == nullptr) {
            fail("ADAPTER_CATALOG_MISSING_PROFILE", endpoint.locator.profile_id);
        }
        const auto profile_digest =
            operator_pinned_adapter_profile_sha256(profile->profile);
        if (profile_digest != endpoint.profile_sha256) {
            fail("ADAPTER_CATALOG_STALE_PROFILE", endpoint.endpoint_id);
        }
        snapshot.endpoints.push_back(AuthorizedAdapterEndpointRecord{
            .endpoint = endpoint,
            .authority_evidence_sha256 = event.authority,
            .sequence = sequence,
            .catalog_record_sha256 = record_digest,
        });
        return;
    }
    if (event.kind == EventKind::rejected) {
        if (snapshot.rejections.size() >= limits.maximum_rejections) {
            fail("ADAPTER_CATALOG_CORRUPT", "rejection limit exceeded in journal");
        }
        snapshot.rejections.push_back(AdapterCatalogRejection{
            .operation = event.operation,
            .object_sha256 = event.object_sha256,
            .authority_evidence_sha256 = event.authority,
            .code = event.rejection_code,
            .sequence = sequence,
            .catalog_record_sha256 = record_digest,
        });
        return;
    }
    snapshot.recoveries.push_back(AdapterCatalogRecovery{
        .discarded_bytes = event.discarded_bytes,
        .discarded_sha256 = event.discarded_sha256,
        .sequence = sequence,
        .catalog_record_sha256 = record_digest,
    });
}

struct ReplayResult final {
    AdapterProfileCatalogSnapshot snapshot{};
    std::size_t valid_bytes{kCatalogHeaderBytes};
    std::vector<std::uint8_t> incomplete_tail{};
};

[[nodiscard]] ReplayResult replay_catalog(
    const std::span<const std::uint8_t> bytes,
    const AdapterCatalogLimits& limits) {
    if (bytes.size() < kCatalogHeaderBytes) {
        fail("ADAPTER_CATALOG_CORRUPT", "truncated catalog header");
    }
    if (!std::equal(kCatalogMagic.begin(), kCatalogMagic.end(), bytes.begin()) ||
        read_be32(bytes, 8U) != 1U || read_be32(bytes, 12U) != 0U) {
        fail("ADAPTER_CATALOG_CORRUPT", "catalog header");
    }
    ReplayResult result;
    std::size_t offset = kCatalogHeaderBytes;
    std::size_t records = 0U;
    while (offset < bytes.size()) {
        const auto remaining = bytes.size() - offset;
        if (remaining < kRecordHeaderBytes) {
            result.incomplete_tail.assign(
                bytes.begin() + static_cast<std::ptrdiff_t>(offset), bytes.end());
            result.valid_bytes = offset;
            return result;
        }
        if (!std::equal(
                kRecordMagic.begin(),
                kRecordMagic.end(),
                bytes.begin() + static_cast<std::ptrdiff_t>(offset))) {
            fail("ADAPTER_CATALOG_CORRUPT", "record magic");
        }
        const auto payload_size = static_cast<std::size_t>(read_be32(bytes, offset + 8U));
        if (payload_size == 0U || payload_size > kMaximumEventPayloadBytes ||
            read_be32(bytes, offset + 12U) != 0U) {
            fail("ADAPTER_CATALOG_CORRUPT", "record length or reserved field");
        }
        if (payload_size > std::numeric_limits<std::size_t>::max() - kRecordFixedBytes) {
            fail("ADAPTER_CATALOG_CORRUPT", "record size overflow");
        }
        const auto total = kRecordFixedBytes + payload_size;
        if (remaining < total) {
            result.incomplete_tail.assign(
                bytes.begin() + static_cast<std::ptrdiff_t>(offset), bytes.end());
            result.valid_bytes = offset;
            return result;
        }
        ++records;
        if (records > limits.maximum_records) {
            fail("ADAPTER_CATALOG_CORRUPT", "record limit exceeded");
        }
        const auto sequence = read_be64(bytes, offset + 16U);
        if (sequence != result.snapshot.last_sequence + 1U) {
            fail("ADAPTER_CATALOG_CORRUPT", "record sequence");
        }
        const auto previous = read_digest(bytes, offset + 24U);
        if (previous != result.snapshot.last_record_sha256) {
            fail("ADAPTER_CATALOG_CORRUPT", "record chain");
        }
        const auto expected_payload_digest = read_digest(bytes, offset + 56U);
        const auto payload_offset = offset + kRecordHeaderBytes;
        const auto payload = bytes.subspan(payload_offset, payload_size);
        if (adapter_sha256(payload) != expected_payload_digest) {
            fail("ADAPTER_CATALOG_CORRUPT", "payload digest");
        }
        const auto record_digest_offset = payload_offset + payload_size;
        const auto expected_record_digest =
            read_digest(bytes, record_digest_offset);
        const auto computed_record_digest = adapter_sha256(
            bytes.subspan(offset, kRecordHeaderBytes + payload_size));
        if (expected_record_digest != computed_record_digest) {
            fail("ADAPTER_CATALOG_CORRUPT", "record digest");
        }
        const auto trailer_offset = record_digest_offset + kRecordDigestBytes;
        if (!std::equal(
                kTrailerMagic.begin(),
                kTrailerMagic.end(),
                bytes.begin() + static_cast<std::ptrdiff_t>(trailer_offset))) {
            fail("ADAPTER_CATALOG_CORRUPT", "record trailer");
        }
        replay_event(
            result.snapshot,
            parse_event(payload),
            sequence,
            computed_record_digest,
            limits);
        result.snapshot.last_sequence = sequence;
        result.snapshot.last_record_sha256 = computed_record_digest;
        offset += total;
        result.valid_bytes = offset;
    }
    return result;
}

[[nodiscard]] std::vector<std::uint8_t> make_record(
    const AdapterProfileCatalogSnapshot& snapshot,
    const std::span<const std::uint8_t> payload) {
    if (payload.empty() || payload.size() > kMaximumEventPayloadBytes ||
        payload.size() > std::numeric_limits<std::uint32_t>::max()) {
        fail("ADAPTER_CATALOG_LIMIT_EXHAUSTED", "event payload");
    }
    if (snapshot.last_sequence == std::numeric_limits<std::uint64_t>::max()) {
        fail("ADAPTER_CATALOG_LIMIT_EXHAUSTED", "sequence");
    }
    std::vector<std::uint8_t> frame;
    frame.reserve(kRecordFixedBytes + payload.size());
    frame.insert(frame.end(), kRecordMagic.begin(), kRecordMagic.end());
    append_be32(frame, static_cast<std::uint32_t>(payload.size()));
    append_be32(frame, 0U);
    append_be64(frame, snapshot.last_sequence + 1U);
    append_digest(frame, snapshot.last_record_sha256);
    append_digest(frame, adapter_sha256(payload));
    frame.insert(frame.end(), payload.begin(), payload.end());
    append_digest(frame, adapter_sha256(frame));
    frame.insert(frame.end(), kTrailerMagic.begin(), kTrailerMagic.end());
    return frame;
}

void append_record(
    LockedCatalogFile& catalog,
    const AdapterProfileCatalogSnapshot& snapshot,
    const AdapterCatalogLimits& limits,
    const std::span<const std::uint8_t> payload) {
    const auto total_records = snapshot.profiles.size() + snapshot.endpoints.size() +
        snapshot.rejections.size() + snapshot.recoveries.size();
    if (total_records >= limits.maximum_records) {
        fail("ADAPTER_CATALOG_LIMIT_EXHAUSTED", "record count");
    }
    const auto frame = make_record(snapshot, payload);
    struct stat status {};
    if (::fstat(catalog.file.get(), &status) != 0 || status.st_size < 0) {
        fail("ADAPTER_CATALOG_WRITE_FAILED", errno_detail("fstat before append", errno));
    }
    const auto size = static_cast<std::uint64_t>(status.st_size);
    if (size > limits.maximum_file_bytes ||
        frame.size() > limits.maximum_file_bytes - static_cast<std::size_t>(size)) {
        fail("ADAPTER_CATALOG_LIMIT_EXHAUSTED", "file bytes");
    }
    require_same_path_object(catalog);
    if (::lseek(catalog.file.get(), 0, SEEK_END) < 0) {
        fail("ADAPTER_CATALOG_WRITE_FAILED", errno_detail("seek append", errno));
    }
    write_all(catalog.file.get(), frame);
    if (::fsync(catalog.file.get()) != 0) {
        fail("ADAPTER_CATALOG_SYNC_FAILED", errno_detail("fsync append", errno));
    }
    require_same_path_object(catalog);
}

[[nodiscard]] AdapterProfileCatalogSnapshot load_snapshot(
    LockedCatalogFile& catalog,
    const AdapterCatalogLimits& limits,
    const bool recover_tail) {
    ensure_initialized(catalog);
    auto bytes = read_all(catalog.file.get(), limits.maximum_file_bytes);
    auto replay = replay_catalog(bytes, limits);
    if (replay.incomplete_tail.empty()) {
        return replay.snapshot;
    }
    if (!recover_tail) {
        fail("ADAPTER_CATALOG_INCOMPLETE_TAIL",
             std::to_string(replay.incomplete_tail.size()) + " bytes");
    }
    const auto total_records = replay.snapshot.profiles.size() +
        replay.snapshot.endpoints.size() + replay.snapshot.rejections.size() +
        replay.snapshot.recoveries.size();
    if (total_records >= limits.maximum_records) {
        fail("ADAPTER_CATALOG_EVIDENCE_EXHAUSTED",
             "cannot repair incomplete tail without a recovery record");
    }
    const auto tail_digest = adapter_sha256(replay.incomplete_tail);
    const auto event = recovery_event_text(replay.incomplete_tail.size(), tail_digest);
    const std::vector<std::uint8_t> payload(event.begin(), event.end());
    const auto recovery_frame = make_record(replay.snapshot, payload);
    if (replay.valid_bytes > limits.maximum_file_bytes ||
        recovery_frame.size() > limits.maximum_file_bytes - replay.valid_bytes) {
        fail("ADAPTER_CATALOG_LIMIT_EXHAUSTED", "recovery evidence");
    }
    require_same_path_object(catalog);
    if (::ftruncate(catalog.file.get(), static_cast<off_t>(replay.valid_bytes)) != 0) {
        fail("ADAPTER_CATALOG_WRITE_FAILED", errno_detail("truncate tail", errno));
    }
    if (::fsync(catalog.file.get()) != 0) {
        fail("ADAPTER_CATALOG_SYNC_FAILED", errno_detail("fsync truncate", errno));
    }
    append_record(catalog, replay.snapshot, limits, payload);
    bytes = read_all(catalog.file.get(), limits.maximum_file_bytes);
    replay = replay_catalog(bytes, limits);
    if (!replay.incomplete_tail.empty()) {
        fail("ADAPTER_CATALOG_CORRUPT", "recovery produced incomplete tail");
    }
    return replay.snapshot;
}

[[nodiscard]] AdapterSha256 authority_digest(
    const std::span<const std::uint8_t> evidence,
    const AdapterCatalogLimits& limits) {
    if (evidence.empty() || evidence.size() > limits.maximum_authority_evidence_bytes) {
        fail("ADAPTER_CATALOG_INVALID_AUTHORITY_EVIDENCE", "authority evidence size");
    }
    return adapter_sha256(evidence);
}

[[nodiscard]] AdapterCatalogAuthorityDecision verify_authority(
    const AdapterCatalogAuthorityVerifier& verifier,
    const AdapterCatalogOperation operation,
    const std::span<const std::uint8_t> object,
    const std::span<const std::uint8_t> evidence) {
    if (!verifier) {
        fail("ADAPTER_CATALOG_INVALID_AUTHORITY_VERIFIER", "empty verifier");
    }
    AdapterCatalogAuthorityDecision decision;
    try {
        decision = verifier(operation, object, evidence);
    } catch (const std::exception&) {
        return AdapterCatalogAuthorityDecision{
            .authorized = false,
            .rejection_code = "AUTHORITY_VERIFIER_FAILED",
        };
    }
    if (decision.authorized) {
        if (!decision.rejection_code.empty()) {
            fail("ADAPTER_CATALOG_INVALID_AUTHORITY_VERIFIER",
                 "authorized decision carried a rejection code");
        }
        return decision;
    }
    if (!valid_rejection_code(decision.rejection_code)) {
        decision.rejection_code = "AUTHORITY_REJECTED";
    }
    return decision;
}

[[nodiscard]] AdapterProfileCatalogSnapshot append_rejection(
    LockedCatalogFile& catalog,
    const AdapterProfileCatalogSnapshot& snapshot,
    const AdapterCatalogLimits& limits,
    const AdapterCatalogOperation operation,
    const AdapterSha256& authority,
    const AdapterSha256& object,
    const std::string_view code) {
    if (snapshot.rejections.size() >= limits.maximum_rejections) {
        fail("ADAPTER_CATALOG_EVIDENCE_EXHAUSTED", "rejection evidence bound");
    }
    const auto canonical_code = valid_rejection_code(code)
        ? std::string(code)
        : std::string("STRUCTURAL_REJECTION");
    const auto event = rejection_event_text(
        operation, authority, object, canonical_code);
    const std::vector<std::uint8_t> payload(event.begin(), event.end());
    append_record(catalog, snapshot, limits, payload);
    return load_snapshot(catalog, limits, false);
}

[[noreturn]] void reject_and_fail(
    LockedCatalogFile& catalog,
    const AdapterProfileCatalogSnapshot& snapshot,
    const AdapterCatalogLimits& limits,
    const AdapterCatalogOperation operation,
    const AdapterSha256& authority,
    const AdapterSha256& object,
    const std::string_view evidence_code,
    const std::string_view error_code,
    const std::string_view detail) {
    static_cast<void>(append_rejection(
        catalog,
        snapshot,
        limits,
        operation,
        authority,
        object,
        evidence_code));
    fail(error_code, detail);
}

}  // namespace

void validate_configured_adapter_endpoint(
    const ConfiguredAdapterEndpoint& endpoint) {
    if (!valid_identifier(endpoint.endpoint_id)) {
        fail("ADAPTER_ENDPOINT_INVALID_ID", endpoint.endpoint_id);
    }
    if (endpoint.generation == 0U) {
        fail("ADAPTER_ENDPOINT_INVALID_GENERATION", "generation must be nonzero");
    }
    static_cast<void>(endpoint_role_text(endpoint.role));
    const auto canonical_locator = adapter_transport_locator_text(endpoint.locator);
    if (parse_adapter_transport_locator(canonical_locator) != endpoint.locator) {
        fail("ADAPTER_ENDPOINT_INVALID_LOCATOR", "locator did not round trip");
    }
    if (is_zero_digest(endpoint.profile_sha256)) {
        fail("ADAPTER_ENDPOINT_INVALID_PROFILE_DIGEST", "zero profile digest");
    }
}

std::string configured_adapter_endpoint_text(
    const ConfiguredAdapterEndpoint& endpoint) {
    validate_configured_adapter_endpoint(endpoint);
    return canonical_endpoint_text(endpoint);
}

ConfiguredAdapterEndpoint parse_configured_adapter_endpoint(
    const std::string_view text) {
    const auto lines = split_canonical_lines(text, "adapter endpoint");
    if (lines.size() != 7U || lines[0U] != kEndpointMagic) {
        fail("ADAPTER_ENDPOINT_NONCANONICAL", "endpoint fields");
    }
    ConfiguredAdapterEndpoint endpoint;
    endpoint.endpoint_id = std::string(
        field_value(lines[1U], "id=", "endpoint id"));
    endpoint.generation = parse_u64(
        field_value(lines[2U], "generation=", "endpoint generation"),
        "endpoint generation");
    endpoint.previous_endpoint_sha256 = parse_adapter_sha256(
        field_value(lines[3U], "previous=", "endpoint predecessor"));
    endpoint.role = parse_endpoint_role(
        field_value(lines[4U], "role=", "endpoint role"));
    endpoint.locator = parse_adapter_transport_locator(
        field_value(lines[5U], "locator=", "endpoint locator"));
    endpoint.profile_sha256 = parse_adapter_sha256(
        field_value(lines[6U], "profile-sha256=", "endpoint profile digest"));
    validate_configured_adapter_endpoint(endpoint);
    if (canonical_endpoint_text(endpoint) != text) {
        fail("ADAPTER_ENDPOINT_NONCANONICAL", "endpoint re-encoding mismatch");
    }
    return endpoint;
}

AdapterSha256 configured_adapter_endpoint_sha256(
    const ConfiguredAdapterEndpoint& endpoint) {
    const auto text = configured_adapter_endpoint_text(endpoint);
    return adapter_sha256(std::span<const std::uint8_t>(
        reinterpret_cast<const std::uint8_t*>(text.data()), text.size()));
}

void validate_configured_adapter_endpoint_transition(
    const ConfiguredAdapterEndpoint* current,
    const ConfiguredAdapterEndpoint& proposed) {
    validate_configured_adapter_endpoint(proposed);
    if (current == nullptr) {
        if (proposed.generation != 1U ||
            !is_zero_digest(proposed.previous_endpoint_sha256)) {
            fail("ADAPTER_ENDPOINT_INVALID_CREATION",
                 "creation requires generation one and zero predecessor");
        }
        return;
    }
    validate_configured_adapter_endpoint(*current);
    if (proposed.endpoint_id != current->endpoint_id ||
        proposed.role != current->role ||
        current->generation == std::numeric_limits<std::uint64_t>::max() ||
        proposed.generation != current->generation + 1U ||
        proposed.previous_endpoint_sha256 !=
            configured_adapter_endpoint_sha256(*current)) {
        fail("ADAPTER_ENDPOINT_INVALID_TRANSITION",
             "replacement must preserve id and role, increment once, and bind predecessor");
    }
}

std::string_view adapter_catalog_operation_text(
    const AdapterCatalogOperation operation) noexcept {
    switch (operation) {
        case AdapterCatalogOperation::profile_create:
            return "profile-create";
        case AdapterCatalogOperation::profile_replace:
            return "profile-replace";
        case AdapterCatalogOperation::endpoint_create:
            return "endpoint-create";
        case AdapterCatalogOperation::endpoint_replace:
            return "endpoint-replace";
    }
    return "unknown";
}

DurableAdapterProfileCatalog::DurableAdapterProfileCatalog(
    std::filesystem::path path,
    AdapterCatalogLimits limits)
    : path_(std::move(path)), limits_(limits) {
    validate_limits(limits_);
    if (!canonical_absolute_file_path(path_)) {
        fail("ADAPTER_CATALOG_INVALID_PATH", path_.string());
    }
}

const std::filesystem::path& DurableAdapterProfileCatalog::path() const noexcept {
    return path_;
}

const AdapterCatalogLimits& DurableAdapterProfileCatalog::limits() const noexcept {
    return limits_;
}

AdapterProfileCatalogSnapshot DurableAdapterProfileCatalog::snapshot() const {
    auto catalog = open_locked_catalog(path_, limits_);
    return load_snapshot(catalog, limits_, true);
}

AdapterProfileCatalogSnapshot DurableAdapterProfileCatalog::snapshot_strict() const {
    auto catalog = open_locked_catalog(path_, limits_);
    return load_snapshot(catalog, limits_, false);
}

AuthorizedAdapterProfileRecord DurableAdapterProfileCatalog::commit_profile(
    const OperatorPinnedAdapterProfile& profile,
    const std::span<const std::uint8_t> opaque_authority_evidence,
    const AdapterCatalogAuthorityVerifier& verifier) const {
    const auto canonical = operator_pinned_adapter_profile_text(profile);
    const std::vector<std::uint8_t> object(canonical.begin(), canonical.end());
    const auto object_digest = adapter_sha256(object);
    const auto authority = authority_digest(opaque_authority_evidence, limits_);
    auto catalog = open_locked_catalog(path_, limits_);
    auto state = load_snapshot(catalog, limits_, true);
    const auto* current = current_profile(state, profile.profile_id);
    const auto operation = current == nullptr
        ? AdapterCatalogOperation::profile_create
        : AdapterCatalogOperation::profile_replace;
    const auto decision = verify_authority(
        verifier, operation, object, opaque_authority_evidence);
    if (!decision.authorized) {
        reject_and_fail(
            catalog,
            state,
            limits_,
            operation,
            authority,
            object_digest,
            decision.rejection_code,
            "ADAPTER_CATALOG_UNAUTHORIZED",
            decision.rejection_code);
    }
    try {
        validate_operator_pinned_adapter_profile_transition(
            current == nullptr ? nullptr : &current->profile,
            profile);
    } catch (const AdapterProfileError& error) {
        reject_and_fail(
            catalog,
            state,
            limits_,
            operation,
            authority,
            object_digest,
            error.code(),
            "ADAPTER_CATALOG_PROFILE_REJECTED",
            error.what());
    }
    if (state.profiles.size() >= limits_.maximum_profiles) {
        reject_and_fail(
            catalog,
            state,
            limits_,
            operation,
            authority,
            object_digest,
            "PROFILE_LIMIT_EXHAUSTED",
            "ADAPTER_CATALOG_LIMIT_EXHAUSTED",
            "profile count");
    }
    const auto event = accepted_event_text(
        EventKind::profile_accepted, authority, object);
    const std::vector<std::uint8_t> payload(event.begin(), event.end());
    append_record(catalog, state, limits_, payload);
    state = load_snapshot(catalog, limits_, false);
    const auto* accepted = exact_profile(
        state, profile.profile_id, profile.generation);
    if (accepted == nullptr) {
        fail("ADAPTER_CATALOG_CORRUPT", "accepted profile missing after append");
    }
    return *accepted;
}

AuthorizedAdapterEndpointRecord DurableAdapterProfileCatalog::commit_endpoint(
    const ConfiguredAdapterEndpoint& endpoint,
    const std::span<const std::uint8_t> opaque_authority_evidence,
    const AdapterCatalogAuthorityVerifier& verifier) const {
    const auto canonical = configured_adapter_endpoint_text(endpoint);
    const std::vector<std::uint8_t> object(canonical.begin(), canonical.end());
    const auto object_digest = adapter_sha256(object);
    const auto authority = authority_digest(opaque_authority_evidence, limits_);
    auto catalog = open_locked_catalog(path_, limits_);
    auto state = load_snapshot(catalog, limits_, true);
    const auto* current = current_endpoint(state, endpoint.endpoint_id);
    const auto operation = current == nullptr
        ? AdapterCatalogOperation::endpoint_create
        : AdapterCatalogOperation::endpoint_replace;
    const auto decision = verify_authority(
        verifier, operation, object, opaque_authority_evidence);
    if (!decision.authorized) {
        reject_and_fail(
            catalog,
            state,
            limits_,
            operation,
            authority,
            object_digest,
            decision.rejection_code,
            "ADAPTER_CATALOG_UNAUTHORIZED",
            decision.rejection_code);
    }
    try {
        validate_configured_adapter_endpoint_transition(
            current == nullptr ? nullptr : &current->endpoint,
            endpoint);
    } catch (const AdapterCatalogError& error) {
        reject_and_fail(
            catalog,
            state,
            limits_,
            operation,
            authority,
            object_digest,
            error.code(),
            "ADAPTER_CATALOG_ENDPOINT_REJECTED",
            error.what());
    }
    const auto* profile = exact_profile(
        state,
        endpoint.locator.profile_id,
        endpoint.locator.profile_generation);
    if (profile == nullptr) {
        reject_and_fail(
            catalog,
            state,
            limits_,
            operation,
            authority,
            object_digest,
            "PROFILE_MISSING",
            "ADAPTER_CATALOG_MISSING_PROFILE",
            endpoint.locator.profile_id);
    }
    const auto expected_profile_digest =
        operator_pinned_adapter_profile_sha256(profile->profile);
    if (expected_profile_digest != endpoint.profile_sha256) {
        reject_and_fail(
            catalog,
            state,
            limits_,
            operation,
            authority,
            object_digest,
            "PROFILE_DIGEST_STALE",
            "ADAPTER_CATALOG_STALE_PROFILE",
            endpoint.endpoint_id);
    }
    if (state.endpoints.size() >= limits_.maximum_endpoints) {
        reject_and_fail(
            catalog,
            state,
            limits_,
            operation,
            authority,
            object_digest,
            "ENDPOINT_LIMIT_EXHAUSTED",
            "ADAPTER_CATALOG_LIMIT_EXHAUSTED",
            "endpoint count");
    }
    const auto event = accepted_event_text(
        EventKind::endpoint_accepted, authority, object);
    const std::vector<std::uint8_t> payload(event.begin(), event.end());
    append_record(catalog, state, limits_, payload);
    state = load_snapshot(catalog, limits_, false);
    const auto* accepted = exact_endpoint(
        state, endpoint.endpoint_id, endpoint.generation);
    if (accepted == nullptr) {
        fail("ADAPTER_CATALOG_CORRUPT", "accepted endpoint missing after append");
    }
    return *accepted;
}

ResolvedConfiguredAdapterEndpoint DurableAdapterProfileCatalog::resolve_endpoint(
    const std::string_view endpoint_id,
    const std::uint64_t endpoint_generation) const {
    return resolve_configured_adapter_endpoint(
        snapshot(), endpoint_id, endpoint_generation);
}

ResolvedConfiguredAdapterEndpoint resolve_configured_adapter_endpoint(
    const AdapterProfileCatalogSnapshot& snapshot,
    const std::string_view endpoint_id,
    const std::uint64_t endpoint_generation) {
    if (!valid_identifier(endpoint_id) || endpoint_generation == 0U) {
        fail("ADAPTER_CATALOG_INVALID_ENDPOINT_REFERENCE", endpoint_id);
    }
    const auto* endpoint = exact_endpoint(
        snapshot, endpoint_id, endpoint_generation);
    if (endpoint == nullptr) {
        fail("ADAPTER_CATALOG_MISSING_ENDPOINT", endpoint_id);
    }
    const auto* profile = exact_profile(
        snapshot,
        endpoint->endpoint.locator.profile_id,
        endpoint->endpoint.locator.profile_generation);
    if (profile == nullptr) {
        fail("ADAPTER_CATALOG_MISSING_PROFILE",
             endpoint->endpoint.locator.profile_id);
    }
    const auto profile_digest =
        operator_pinned_adapter_profile_sha256(profile->profile);
    if (profile_digest != endpoint->endpoint.profile_sha256) {
        fail("ADAPTER_CATALOG_STALE_PROFILE", endpoint_id);
    }
    return ResolvedConfiguredAdapterEndpoint{
        .endpoint = endpoint->endpoint,
        .profile = profile->profile,
        .profile_sha256 = profile_digest,
        .endpoint_sha256 = configured_adapter_endpoint_sha256(endpoint->endpoint),
    };
}

}  // namespace natrav_overlay
