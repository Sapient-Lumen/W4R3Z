#include "backup_crypto.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <thread>
#include <fcntl.h>
#include <limits>
#include <linux/fs.h>
#include <memory>
#include <openssl/core_names.h>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/kdf.h>
#include <openssl/params.h>
#include <openssl/rand.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

namespace natrav_overlay {
namespace {

constexpr std::string_view kKeyMagic = "NOBKEY01";
constexpr std::string_view kEnvelopeMagic = "NOBENC01";
constexpr std::string_view kKeyIdDomain = "NATRAV_OVERLAY_BACKUP_KEY_ID_V1";
constexpr std::string_view kHkdfInfo = "NATRAV_OVERLAY_BACKUP_AES256GCM_HKDF_V1";
constexpr std::size_t kTagBytes = 16U;
constexpr std::size_t kSaltBytes = 32U;
constexpr std::size_t kNonceBytes = 12U;
constexpr std::size_t kFixedHeaderBytes = 106U; // plus generation (1..64)
constexpr std::uint64_t kMaximumPlaintext = 1'073'741'824ULL + 2U * 1'048'576U;

struct Secret final {
    std::array<std::uint8_t, 32> bytes{};
    ~Secret() { OPENSSL_cleanse(bytes.data(), bytes.size()); }
    Secret() = default;
    Secret(const Secret&) = delete;
    Secret& operator=(const Secret&) = delete;
};
struct Key final {
    BackupKeyIdentity identity;
    Secret secret;
};
struct CipherDeleter final {
    void operator()(EVP_CIPHER_CTX* p) const noexcept { EVP_CIPHER_CTX_free(p); }
};
struct CipherAlgorithmDeleter final {
    void operator()(EVP_CIPHER* p) const noexcept { EVP_CIPHER_free(p); }
};
struct KdfDeleter final {
    void operator()(EVP_KDF* p) const noexcept { EVP_KDF_free(p); }
};
struct KdfCtxDeleter final {
    void operator()(EVP_KDF_CTX* p) const noexcept { EVP_KDF_CTX_free(p); }
};
using CipherAlgorithmPtr = std::unique_ptr<EVP_CIPHER, CipherAlgorithmDeleter>;
using CipherPtr = std::unique_ptr<EVP_CIPHER_CTX, CipherDeleter>;
using KdfPtr = std::unique_ptr<EVP_KDF, KdfDeleter>;
using KdfCtxPtr = std::unique_ptr<EVP_KDF_CTX, KdfCtxDeleter>;

void crypto_check(const int result) {
    if (result != 1) {
        app_fail("BACKUP_CRYPTO_FAILED", "OpenSSL backup cryptographic operation failed");
    }
}

// Descriptor-relative traversal makes a checked parent immune to subsequent
// symbolic-link substitution. Ancestor write access by another privileged/local
// owner is not a host-compromise boundary; the final parent must be ours.
struct KeyLocation final {
    datacube::Fd parent;
    std::string name;
};
KeyLocation key_location(const std::filesystem::path& path) {
    if (path.empty()) { app_fail("BACKUP_KEY_PATH_INVALID", "key path is empty"); }
    for (const auto& part : path) {
        if (part == "..") {
            app_fail("BACKUP_KEY_PATH_INVALID", "dot-dot is forbidden in key paths");
        }
    }
    const auto absolute = std::filesystem::absolute(path).lexically_normal();
    const auto name = absolute.filename().string();
    if (name.empty() || name == "." || name == ".." || name.size() > 160U) {
        app_fail("BACKUP_KEY_PATH_INVALID", "invalid key filename");
    }
    for (const char raw : name) {
        const auto ch = static_cast<unsigned char>(raw);
        if (!((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') ||
              (ch >= '0' && ch <= '9') || ch == '-' || ch == '_' || ch == '.')) {
            app_fail("BACKUP_KEY_PATH_INVALID", "key filename must use safe ASCII");
        }
    }
    datacube::Fd parent(::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC));
    if (!parent) { app_fail("BACKUP_KEY_PATH_INVALID", "cannot open root directory"); }
    for (const auto& part : absolute.parent_path().relative_path()) {
        const int raw = ::openat(parent.get(), part.c_str(),
            O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
        if (raw < 0) {
            app_fail("BACKUP_KEY_PATH_INVALID", "key parent must be a real directory without symlinks");
        }
        parent.reset(raw);
    }
    struct stat status{};
    if (::fstat(parent.get(), &status) != 0 || status.st_uid != ::geteuid() ||
        (status.st_mode & (S_IWGRP | S_IWOTH)) != 0) {
        app_fail("BACKUP_KEY_PARENT_UNSAFE", "key parent must be effective-user owned and not writable by others");
    }
    return {.parent = std::move(parent), .name = name};
}

void text16(datacube::Octets& bytes, std::string_view text) {
    datacube::append_be16(bytes, static_cast<std::uint16_t>(text.size()));
    datacube::append_text(bytes, text);
}
std::string read_generation(datacube::Reader& reader) {
    const auto count = reader.read_be16("encryption key generation size");
    if (count == 0U || count > 64U) {
        app_fail("BACKUP_ENCRYPTION_FORMAT_INVALID", "generation size is invalid");
    }
    const auto generation = datacube::octets_text(
        reader.read_exact(count, "encryption key generation"), "generation", true);
    require_generation_id(generation, "backup encryption key generation");
    return generation;
}

datacube::Digest32 key_id(std::string_view generation, datacube::OctetView secret) {
    datacube::Octets input;
    BackupWipeGuard wipe(input);
    datacube::append_text(input, kKeyIdDomain);
    text16(input, generation);
    datacube::append_octets(input, secret);
    return datacube::sha256(input);
}

std::unique_ptr<Key> load_key(const std::filesystem::path& path) {
    auto location = key_location(path);
    const int raw = ::openat(location.parent.get(), location.name.c_str(),
        O_RDONLY | O_NONBLOCK | O_CLOEXEC | O_NOFOLLOW);
    if (raw < 0) { app_fail("BACKUP_KEY_OPEN_FAILED", "cannot open backup encryption key"); }
    datacube::Fd fd(raw);
    struct stat status{};
    if (::fstat(fd.get(), &status) != 0 || !S_ISREG(status.st_mode) ||
        status.st_uid != ::geteuid() || (status.st_mode & 07777U) != 0600U ||
        status.st_nlink != 1 || status.st_size < 47 || status.st_size > 110) {
        app_fail("BACKUP_KEY_FILE_UNSAFE", "key must be single-link, effective-user-owned, exact mode 0600, and bounded");
    }
    auto bytes = datacube::read_all_fd(fd.get(), 110U, "backup encryption key");
    BackupWipeGuard wipe(bytes);
    if (bytes.size() != static_cast<std::size_t>(status.st_size)) {
        app_fail("BACKUP_KEY_FILE_UNSAFE", "key size changed while reading");
    }
    try {
    datacube::Reader reader(bytes, "backup encryption key");
    if (datacube::octets_text(reader.read_exact(8U, "key magic"), "magic", true) != kKeyMagic ||
        reader.read_be32("key version") != 1U) {
        app_fail("BACKUP_KEY_FORMAT_INVALID", "unsupported encryption key format");
    }
    auto key = std::make_unique<Key>();
    key->identity.generation = read_generation(reader);
    const auto raw_key = reader.read_exact(32U, "key material");
    std::copy(raw_key.begin(), raw_key.end(), key->secret.bytes.begin());
    reader.require_eof("backup encryption key");
    key->identity.id = key_id(key->identity.generation, key->secret.bytes);
    return key;
    } catch (const datacube::Failure&) {
        app_fail("BACKUP_KEY_FORMAT_INVALID", "malformed or trailing encryption key material");
    }
}

void derive_key(const Key& key, datacube::OctetView salt,
                datacube::OctetView header, Secret& derived) {
    KdfPtr algorithm(EVP_KDF_fetch(nullptr, "HKDF", nullptr));
    if (!algorithm) { app_fail("BACKUP_CRYPTO_FAILED", "HKDF unavailable"); }
    KdfCtxPtr context(EVP_KDF_CTX_new(algorithm.get()));
    if (!context) { app_fail("BACKUP_CRYPTO_FAILED", "HKDF context allocation failed"); }
    datacube::Octets info;
    datacube::append_text(info, kHkdfInfo);
    datacube::append_octets(info, header);
    char digest[] = "SHA256";
    char mode[] = "EXTRACT_AND_EXPAND";
    OSSL_PARAM parameters[] = {
        OSSL_PARAM_construct_utf8_string(OSSL_KDF_PARAM_DIGEST, digest, 0U),
        OSSL_PARAM_construct_utf8_string(OSSL_KDF_PARAM_MODE, mode, 0U),
        OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_KEY,
            const_cast<std::uint8_t*>(key.secret.bytes.data()), key.secret.bytes.size()),
        OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_SALT,
            const_cast<std::uint8_t*>(salt.data()), salt.size()),
        OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_INFO, info.data(), info.size()),
        OSSL_PARAM_construct_end(),
    };
    crypto_check(EVP_KDF_derive(context.get(), derived.bytes.data(), derived.bytes.size(), parameters));
}

void write_key(const KeyLocation& location, datacube::OctetView bytes) {
    std::array<std::uint8_t, 16> random{};
    crypto_check(RAND_bytes(random.data(), static_cast<int>(random.size())));
    const std::string stage = ".natrav-backup-key-" + hex_bytes(random) + ".tmp";
    bool published = false;
    try {
        datacube::Fd fd(::openat(location.parent.get(), stage.c_str(),
            O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600));
        if (!fd || ::fchmod(fd.get(), 0600) != 0) {
            app_fail("BACKUP_KEY_WRITE_FAILED", "cannot create owner-only key staging file");
        }
        std::size_t offset = 0U;
        while (offset < bytes.size()) {
            const auto n = ::write(fd.get(), bytes.data() + offset, bytes.size() - offset);
            if (n < 0 && errno == EINTR) { continue; }
            if (n <= 0) { app_fail("BACKUP_KEY_WRITE_FAILED", "key write failed"); }
            offset += static_cast<std::size_t>(n);
        }
        if (::fsync(fd.get()) != 0) { app_fail("BACKUP_KEY_WRITE_FAILED", "key sync failed"); }
        backup_publication_test_pause("KEY_BEFORE_PUBLISH");
        if (::syscall(SYS_renameat2, location.parent.get(), stage.c_str(),
                location.parent.get(), location.name.c_str(), RENAME_NOREPLACE) != 0) {
            app_fail(errno == EEXIST ? "BACKUP_KEY_EXISTS" : "BACKUP_KEY_WRITE_FAILED",
                "key publication failed; no overwrite is permitted");
        }
        published = true;
        if (::fsync(location.parent.get()) != 0) {
            app_fail("BACKUP_KEY_SYNC_FAILED", "key published but parent sync failed; inspect destination");
        }
        backup_publication_test_pause("KEY_AFTER_PUBLISH");
    } catch (...) {
        if (!published) { static_cast<void>(::unlinkat(location.parent.get(), stage.c_str(), 0)); }
        throw;
    }
}

}  // namespace

void backup_publication_test_pause(const std::string_view point) {
    const auto name = std::string("NATRAV_OVERLAY_TEST_") + std::string(point) + "_MS";
    const char* raw = std::getenv(name.c_str());
    if (raw == nullptr) { return; }
    const auto duration = parse_milliseconds(raw, name, 1U, 10'000U);
    const auto marker = std::string("BACKUP_TEST_PAUSE ") + std::string(point) + "\n";
    static_cast<void>(std::fwrite(marker.data(), 1U, marker.size(), stderr));
    static_cast<void>(std::fflush(stderr));
    std::this_thread::sleep_for(duration);
}

BackupWipeGuard::~BackupWipeGuard() {
    if (!bytes_.empty()) { OPENSSL_cleanse(bytes_.data(), bytes_.size()); }
}

BackupKeyIdentity initialize_backup_key(
    const std::filesystem::path& destination, const std::string_view generation) {
    require_generation_id(generation, "backup encryption generation");
    auto location = key_location(destination);
    Key key;
    key.identity.generation = generation;
    crypto_check(RAND_priv_bytes(key.secret.bytes.data(), static_cast<int>(key.secret.bytes.size())));
    key.identity.id = key_id(generation, key.secret.bytes);
    datacube::Octets bytes;
    BackupWipeGuard wipe(bytes);
    datacube::append_text(bytes, kKeyMagic);
    datacube::append_be32(bytes, 1U);
    text16(bytes, generation);
    datacube::append_octets(bytes, key.secret.bytes);
    write_key(location, bytes);
    return key.identity;
}

BackupKeyIdentity check_backup_key(const std::filesystem::path& path) {
    return load_key(path)->identity;
}

std::string backup_key_json(const BackupKeyIdentity& key) {
    return "{\"format\":\"NATRAV_OVERLAY_BACKUP_KEY_V1\",\"ok\":true,\"generation\":" +
        json_string(key.generation) + ",\"key_id\":" + json_string(datacube::hex_lower(key.id)) +
        ",\"key_bits\":256,\"purpose\":\"BACKUP_ENCRYPTION\"}";
}

bool is_encrypted_backup(const datacube::OctetView bytes) noexcept {
    return bytes.size() >= kEnvelopeMagic.size() &&
        std::equal(kEnvelopeMagic.begin(), kEnvelopeMagic.end(), bytes.begin());
}

BackupCryptResult encrypt_backup_bytes(
    const datacube::OctetView plaintext, const std::filesystem::path& key_path) {
    if (plaintext.empty() || plaintext.size() > kMaximumPlaintext) {
        app_fail("BACKUP_ENCRYPTION_LIMIT", "plaintext backup exceeds encryption bounds");
    }
    const auto key = load_key(key_path);
    std::array<std::uint8_t, kSaltBytes> salt{};
    std::array<std::uint8_t, kNonceBytes> nonce{};
    crypto_check(RAND_bytes(salt.data(), static_cast<int>(salt.size())));
    crypto_check(RAND_bytes(nonce.data(), static_cast<int>(nonce.size())));
    datacube::Octets header;
    datacube::append_text(header, kEnvelopeMagic);
    datacube::append_be32(header, 1U); // envelope version
    datacube::append_be32(header, 1U); // AES-256-GCM + HKDF-SHA-256 suite
    datacube::append_be32(header, 0U); // flags (must be zero)
    text16(header, key->identity.generation);
    datacube::append_octets(header, key->identity.id.octets);
    datacube::append_octets(header, salt);
    datacube::append_octets(header, nonce);
    datacube::append_be64(header, plaintext.size());
    if (header.size() != kFixedHeaderBytes + key->identity.generation.size()) {
        app_fail("BACKUP_CRYPTO_FAILED", "encryption header construction failed");
    }
    Secret derived;
    derive_key(*key, salt, header, derived);
    CipherPtr cipher(EVP_CIPHER_CTX_new());
    if (!cipher) { app_fail("BACKUP_CRYPTO_FAILED", "cipher context allocation failed"); }
    CipherAlgorithmPtr algorithm(EVP_CIPHER_fetch(nullptr, "AES-256-GCM", nullptr));
    if (!algorithm) { app_fail("BACKUP_CRYPTO_FAILED", "AES-256-GCM unavailable"); }
    crypto_check(EVP_EncryptInit_ex2(cipher.get(), algorithm.get(), derived.bytes.data(), nonce.data(), nullptr));
    if (EVP_CIPHER_CTX_get_iv_length(cipher.get()) != static_cast<int>(nonce.size())) {
        app_fail("BACKUP_CRYPTO_FAILED", "unexpected GCM nonce length");
    }
    int count = 0;
    crypto_check(EVP_EncryptUpdate(cipher.get(), nullptr, &count,
        header.data(), static_cast<int>(header.size())));
    datacube::Octets output = header;
    output.resize(header.size() + plaintext.size() + kTagBytes);
    crypto_check(EVP_EncryptUpdate(cipher.get(), output.data() + header.size(), &count,
        plaintext.data(), static_cast<int>(plaintext.size())));
    if (count < 0 || static_cast<std::size_t>(count) != plaintext.size()) {
        app_fail("BACKUP_CRYPTO_FAILED", "unexpected GCM ciphertext length");
    }
    int tail = 0;
    crypto_check(EVP_EncryptFinal_ex(cipher.get(), output.data() + header.size() + plaintext.size(), &tail));
    if (tail != 0) { app_fail("BACKUP_CRYPTO_FAILED", "unexpected GCM tail"); }
    OSSL_PARAM tag_parameters[] = {
        OSSL_PARAM_construct_octet_string(OSSL_CIPHER_PARAM_AEAD_TAG,
            output.data() + header.size() + plaintext.size(), kTagBytes),
        OSSL_PARAM_construct_end(),
    };
    crypto_check(EVP_CIPHER_CTX_get_params(cipher.get(), tag_parameters));
    return {.bytes = std::move(output), .key = key->identity};
}

BackupCryptResult decrypt_backup_bytes(
    const datacube::OctetView envelope, const std::filesystem::path& key_path,
    const std::uint64_t maximum_plaintext_bytes) {
    if (!is_encrypted_backup(envelope) || envelope.size() < kFixedHeaderBytes + 1U + kTagBytes ||
        maximum_plaintext_bytes > kMaximumPlaintext) {
        app_fail("BACKUP_ENCRYPTION_FORMAT_INVALID", "invalid encrypted backup envelope");
    }
    datacube::Reader reader(envelope, "encrypted backup envelope");
    static_cast<void>(reader.read_exact(8U, "encrypted magic"));
    if (reader.read_be32("encrypted version") != 1U ||
        reader.read_be32("cipher suite") != 1U || reader.read_be32("flags") != 0U) {
        app_fail("BACKUP_ENCRYPTION_FORMAT_INVALID", "unsupported encrypted version, suite, or flags");
    }
    const auto generation = read_generation(reader);
    const auto expected_id = reader.read_exact(32U, "key ID");
    const auto salt = reader.read_exact(kSaltBytes, "salt");
    const auto nonce = reader.read_exact(kNonceBytes, "nonce");
    const auto count = reader.read_be64("encrypted byte count");
    if (count == 0U || count > maximum_plaintext_bytes ||
        count > static_cast<std::uint64_t>(std::numeric_limits<int>::max()) ||
        count + kTagBytes != reader.remaining()) {
        app_fail("BACKUP_ENCRYPTION_FORMAT_INVALID", "encrypted length mismatch or limit exceeded");
    }
    const auto header = envelope.first(envelope.size() - reader.remaining());
    const auto ciphertext = reader.read_exact(count, "ciphertext");
    const auto tag = reader.read_exact(kTagBytes, "authentication tag");
    reader.require_eof("encrypted backup");
    const auto key = load_key(key_path);
    if (generation != key->identity.generation ||
        CRYPTO_memcmp(expected_id.data(), key->identity.id.octets.data(), 32U) != 0) {
        app_fail("BACKUP_ENCRYPTION_KEY_MISMATCH", "backup requires a different exact encryption key generation");
    }
    Secret derived;
    derive_key(*key, salt, header, derived);
    CipherPtr cipher(EVP_CIPHER_CTX_new());
    if (!cipher) { app_fail("BACKUP_CRYPTO_FAILED", "cipher context allocation failed"); }
    CipherAlgorithmPtr algorithm(EVP_CIPHER_fetch(nullptr, "AES-256-GCM", nullptr));
    if (!algorithm) { app_fail("BACKUP_CRYPTO_FAILED", "AES-256-GCM unavailable"); }
    crypto_check(EVP_DecryptInit_ex2(cipher.get(), algorithm.get(), derived.bytes.data(), nonce.data(), nullptr));
    if (EVP_CIPHER_CTX_get_iv_length(cipher.get()) != static_cast<int>(nonce.size())) {
        app_fail("BACKUP_CRYPTO_FAILED", "unexpected GCM nonce length");
    }
    int written = 0;
    crypto_check(EVP_DecryptUpdate(cipher.get(), nullptr, &written,
        header.data(), static_cast<int>(header.size())));
    datacube::Octets plaintext(ciphertext.size() + kTagBytes);
    BackupWipeGuard wipe(plaintext);
    crypto_check(EVP_DecryptUpdate(cipher.get(), plaintext.data(), &written,
        ciphertext.data(), static_cast<int>(ciphertext.size())));
    if (written < 0 || static_cast<std::size_t>(written) != ciphertext.size()) {
        app_fail("BACKUP_CRYPTO_FAILED", "unexpected GCM plaintext length");
    }
    OSSL_PARAM tag_parameters[] = {
        OSSL_PARAM_construct_octet_string(OSSL_CIPHER_PARAM_AEAD_TAG,
            const_cast<std::uint8_t*>(tag.data()), tag.size()),
        OSSL_PARAM_construct_end(),
    };
    crypto_check(EVP_CIPHER_CTX_set_params(cipher.get(), tag_parameters));
    int tail = 0;
    const int authenticated = EVP_DecryptFinal_ex(cipher.get(), plaintext.data() + written, &tail);
    // Do not parse, publish, or return any plaintext before this check.
    if (authenticated != 1) {
        app_fail("BACKUP_AUTHENTICATION_FAILED", "encrypted backup authentication failed");
    }
    if (tail != 0) { app_fail("BACKUP_CRYPTO_FAILED", "unexpected authenticated tail"); }
    plaintext.resize(ciphertext.size());
    BackupCryptResult result{.bytes = {}, .key = key->identity};
    result.bytes.swap(plaintext);
    return result;
}

}  // namespace natrav_overlay
