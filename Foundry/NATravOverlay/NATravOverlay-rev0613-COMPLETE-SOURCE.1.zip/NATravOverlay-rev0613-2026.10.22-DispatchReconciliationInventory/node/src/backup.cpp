#include "backup.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <filesystem>
#include <limits>
#include <linux/fs.h>
#include <memory>
#include <openssl/bio.h>
#include <openssl/crypto.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rand.h>
#include <openssl/x509.h>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <thread>
#include <unistd.h>
#include <utility>

namespace natrav_overlay {
namespace {

inline constexpr std::array<std::uint8_t, 8> kBackupMagic{
    static_cast<std::uint8_t>('N'), static_cast<std::uint8_t>('O'),
    static_cast<std::uint8_t>('B'), static_cast<std::uint8_t>('A'),
    static_cast<std::uint8_t>('C'), static_cast<std::uint8_t>('K'),
    static_cast<std::uint8_t>('0'), static_cast<std::uint8_t>('1'),
};
inline constexpr std::uint32_t kBackupVersion = 1U;
inline constexpr std::uint32_t kSignedFlag = 1U;
inline constexpr std::uint64_t kMaximumCertificateBytes = 1'048'576U;
inline constexpr std::uint64_t kMaximumSignatureBytes = 4'096U;
inline constexpr std::string_view kBackupIdDomain =
    "NATRAV_OVERLAY_BACKUP_ID_V1";
inline constexpr std::string_view kMetadataPrefix =
    "NATRAV_OVERLAY_NODE_STATE_V2\nnode=";

void test_pause_exact_backup_verification() {
    if (const char* raw = std::getenv(
            "NATRAV_OVERLAY_TEST_CUSTODY_PROMOTION_PAUSE_AFTER_BACKUP_VERIFY_MS")) {
        const auto delay = parse_u64(raw, "backup exact-input test pause", 1U, 10'000U);
        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    }
}

struct PkeyDeleter final {
    void operator()(EVP_PKEY* value) const noexcept { EVP_PKEY_free(value); }
};
struct X509Deleter final {
    void operator()(X509* value) const noexcept { X509_free(value); }
};
struct BioDeleter final {
    void operator()(BIO* value) const noexcept { BIO_free(value); }
};
struct MdContextDeleter final {
    void operator()(EVP_MD_CTX* value) const noexcept { EVP_MD_CTX_free(value); }
};
using PkeyPtr = std::unique_ptr<EVP_PKEY, PkeyDeleter>;
using X509Ptr = std::unique_ptr<X509, X509Deleter>;
using BioPtr = std::unique_ptr<BIO, BioDeleter>;
using MdContextPtr = std::unique_ptr<EVP_MD_CTX, MdContextDeleter>;

struct ParsedBackup final {
    BackupResult result;
    datacube::Digest32 outer_file_digest;
    datacube::Octets checkpoint;
    datacube::Octets certificate_der;
    datacube::Octets signature;
    ~ParsedBackup() {
        if (!checkpoint.empty()) { OPENSSL_cleanse(checkpoint.data(), checkpoint.size()); }
    }
};

[[nodiscard]] std::uint64_t unix_milliseconds_now() {
    const auto now = std::chrono::system_clock::now().time_since_epoch();
    const auto value = std::chrono::duration_cast<std::chrono::milliseconds>(now).count();
    if (value <= 0) {
        app_fail("CLOCK_INVALID", "system clock is before the Unix epoch");
    }
    return static_cast<std::uint64_t>(value);
}

[[nodiscard]] std::string openssl_reason() {
    const unsigned long value = ERR_get_error();
    if (value == 0UL) { return "OpenSSL operation failed"; }
    const char* reason = ERR_reason_error_string(value);
    while (ERR_get_error() != 0UL) {}
    return reason == nullptr ? "OpenSSL operation failed" : std::string(reason);
}

[[nodiscard]] bool safe_path_name(const std::string_view value) noexcept {
    if (value.empty() || value.size() > 160U || value == "." || value == "..") {
        return false;
    }
    return std::all_of(value.begin(), value.end(), [](const char raw) {
        const auto ch = static_cast<unsigned char>(raw);
        return (ch >= static_cast<unsigned char>('A') &&
                ch <= static_cast<unsigned char>('Z')) ||
            (ch >= static_cast<unsigned char>('a') &&
             ch <= static_cast<unsigned char>('z')) ||
            (ch >= static_cast<unsigned char>('0') &&
             ch <= static_cast<unsigned char>('9')) ||
            ch == static_cast<unsigned char>('.') ||
            ch == static_cast<unsigned char>('_') ||
            ch == static_cast<unsigned char>('-');
    });
}

void reject_dot_dot(const std::filesystem::path& path, const std::string_view field) {
    if (path.empty()) {
        app_fail("BACKUP_PATH_INVALID", std::string(field) + " is empty");
    }
    for (const auto& component : path) {
        if (component == "..") {
            app_fail("BACKUP_PATH_INVALID",
                std::string(field) + " must not contain dot-dot");
        }
    }
}

void validate_secure_parent(const std::filesystem::path& absolute_parent) {
    std::filesystem::path current = absolute_parent.root_path();
    for (const auto& component : absolute_parent.relative_path()) {
        current /= component;
        struct stat status {};
        if (::lstat(current.c_str(), &status) != 0) {
            app_fail("BACKUP_PARENT_INVALID",
                datacube::errno_detail(current.string(), errno));
        }
        if (S_ISLNK(status.st_mode)) {
            app_fail("BACKUP_PARENT_SYMLINK_REJECTED",
                "backup parent path contains a symbolic link: " +
                current.string());
        }
        if (!S_ISDIR(status.st_mode)) {
            app_fail("BACKUP_PARENT_INVALID",
                "backup parent component is not a directory: " +
                current.string());
        }
    }
    struct stat status {};
    if (::lstat(absolute_parent.c_str(), &status) != 0) {
        app_fail("BACKUP_PARENT_INVALID",
            datacube::errno_detail(absolute_parent.string(), errno));
    }
    if (status.st_uid != ::geteuid()) {
        app_fail("BACKUP_PARENT_OWNER_INVALID",
            "final backup parent directory must be owned by the effective user");
    }
    if ((status.st_mode & (S_IWGRP | S_IWOTH)) != 0) {
        app_fail("BACKUP_PARENT_PERMISSIONS_INVALID",
            "final backup parent directory must not be group- or other-writable");
    }
}

struct Destination final {
    std::filesystem::path absolute;
    std::filesystem::path parent;
    std::string name;
};

[[nodiscard]] Destination validate_destination(
    const std::filesystem::path& path,
    const std::string_view field) {
    reject_dot_dot(path, field);
    const auto absolute = std::filesystem::absolute(path).lexically_normal();
    const auto parent = absolute.parent_path();
    const auto name = absolute.filename().string();
    if (parent.empty() || !safe_path_name(name)) {
        app_fail("BACKUP_PATH_INVALID",
            std::string(field) + " final name must use safe ASCII characters");
    }
    validate_secure_parent(parent);
    struct stat existing {};
    if (::lstat(absolute.c_str(), &existing) == 0) {
        app_fail("BACKUP_DESTINATION_EXISTS",
            std::string(field) + " already exists; overwrite is forbidden");
    }
    if (errno != ENOENT) {
        app_fail("BACKUP_DESTINATION_INVALID",
            datacube::errno_detail(absolute.string(), errno));
    }
    return Destination{.absolute = absolute, .parent = parent, .name = name};
}

void write_all(
    const int fd,
    const datacube::OctetView bytes,
    const std::string_view operation) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const ssize_t count = ::write(
            fd, bytes.data() + offset, bytes.size() - offset);
        if (count < 0) {
            if (errno == EINTR) { continue; }
            app_fail("BACKUP_WRITE_FAILED",
                datacube::errno_detail(operation, errno));
        }
        if (count == 0) {
            app_fail("BACKUP_WRITE_FAILED",
                std::string(operation) + " made no progress");
        }
        offset += static_cast<std::size_t>(count);
    }
}

[[nodiscard]] datacube::Octets read_regular_file(
    const std::filesystem::path& path,
    const std::uint64_t ceiling,
    const bool require_private_mode,
    const std::string_view field) {
    reject_dot_dot(path, field);
    const int raw = ::open(path.c_str(), O_RDONLY | O_NONBLOCK | O_CLOEXEC | O_NOFOLLOW);
    if (raw < 0) {
        app_fail("BACKUP_FILE_OPEN_FAILED",
            datacube::errno_detail(path.string(), errno));
    }
    datacube::Fd fd(raw);
    struct stat status {};
    if (::fstat(fd.get(), &status) != 0) {
        app_fail("BACKUP_FILE_STAT_FAILED",
            datacube::errno_detail(path.string(), errno));
    }
    if (!S_ISREG(status.st_mode) || status.st_size < 0) {
        app_fail("BACKUP_FILE_INVALID",
            std::string(field) + " must be a regular file");
    }
    if (status.st_uid != ::geteuid()) {
        app_fail("BACKUP_FILE_OWNER_INVALID",
            std::string(field) + " must be owned by the effective user");
    }
    if (require_private_mode &&
        (status.st_mode & (S_IRWXG | S_IRWXO)) != 0) {
        app_fail("BACKUP_PRIVATE_KEY_PERMISSIONS_INVALID",
            "signing private key must be inaccessible to group and other users");
    }
    if (static_cast<std::uint64_t>(status.st_size) > ceiling) {
        app_fail("BACKUP_FILE_TOO_LARGE",
            std::string(field) + " exceeds its size ceiling");
    }
    return datacube::read_all_fd(fd.get(), ceiling, path.string());
}

void append_text16(
    datacube::Octets& out,
    const std::string_view value,
    const std::size_t ceiling,
    const std::string_view field) {
    if (value.empty() || value.size() > ceiling || value.size() > 65'535U) {
        app_fail("BACKUP_FORMAT_INVALID",
            std::string(field) + " is outside its size envelope");
    }
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}

[[nodiscard]] std::string read_text16(
    datacube::Reader& reader,
    const std::size_t ceiling,
    const std::string_view field) {
    const auto size = reader.read_be16(field);
    if (size == 0U || static_cast<std::size_t>(size) > ceiling) {
        app_fail("BACKUP_FORMAT_INVALID",
            std::string(field) + " is outside its size envelope");
    }
    return datacube::octets_text(reader.read_exact(size, field), field, true);
}

void append_digest(datacube::Octets& out, const datacube::Digest32& digest) {
    datacube::append_octets(out, digest.octets);
}

[[nodiscard]] datacube::Digest32 read_digest(
    datacube::Reader& reader,
    const std::string_view field) {
    const auto value = reader.read_exact(32U, field);
    datacube::Digest32 digest {};
    std::copy(value.begin(), value.end(), digest.octets.begin());
    return digest;
}

[[nodiscard]] datacube::Digest32 pkey_spki_sha256(EVP_PKEY* key) {
    const int length = i2d_PUBKEY(key, nullptr);
    if (length <= 0) {
        app_fail("BACKUP_PUBLIC_KEY_FAILED", openssl_reason());
    }
    datacube::Octets der(static_cast<std::size_t>(length));
    unsigned char* cursor = der.data();
    if (i2d_PUBKEY(key, &cursor) != length) {
        app_fail("BACKUP_PUBLIC_KEY_FAILED", openssl_reason());
    }
    return datacube::sha256(der);
}

[[nodiscard]] datacube::Octets certificate_der(X509* certificate) {
    const int length = i2d_X509(certificate, nullptr);
    if (length <= 0) {
        app_fail("BACKUP_CERTIFICATE_FAILED", openssl_reason());
    }
    datacube::Octets der(static_cast<std::size_t>(length));
    unsigned char* cursor = der.data();
    if (i2d_X509(certificate, &cursor) != length) {
        app_fail("BACKUP_CERTIFICATE_FAILED", openssl_reason());
    }
    return der;
}

[[nodiscard]] PkeyPtr load_private_key(
    const std::filesystem::path& path) {
    auto bytes = read_regular_file(
        path, 1'048'576U, true, "signing private key");
    if (bytes.size() > static_cast<std::size_t>(std::numeric_limits<int>::max())) {
        app_fail("BACKUP_PRIVATE_KEY_INVALID", "private key is too large");
    }
    BioPtr bio(BIO_new_mem_buf(
        bytes.data(), static_cast<int>(bytes.size())));
    if (!bio) {
        OPENSSL_cleanse(bytes.data(), bytes.size());
        app_fail("BACKUP_PRIVATE_KEY_INVALID", openssl_reason());
    }
    EVP_PKEY* raw = PEM_read_bio_PrivateKey(
        bio.get(), nullptr, nullptr, nullptr);
    OPENSSL_cleanse(bytes.data(), bytes.size());
    if (raw == nullptr) {
        app_fail("BACKUP_PRIVATE_KEY_INVALID", openssl_reason());
    }
    PkeyPtr key(raw);
    if (EVP_PKEY_base_id(key.get()) != EVP_PKEY_ED25519) {
        app_fail("BACKUP_PRIVATE_KEY_INVALID",
            "backup signing key must be Ed25519");
    }
    return key;
}

[[nodiscard]] X509Ptr load_pem_certificate(
    const std::filesystem::path& path) {
    const auto bytes = read_regular_file(
        path, kMaximumCertificateBytes, false, "certificate");
    if (bytes.size() > static_cast<std::size_t>(std::numeric_limits<int>::max())) {
        app_fail("BACKUP_CERTIFICATE_INVALID", "certificate is too large");
    }
    BioPtr bio(BIO_new_mem_buf(
        bytes.data(), static_cast<int>(bytes.size())));
    if (!bio) {
        app_fail("BACKUP_CERTIFICATE_INVALID", openssl_reason());
    }
    X509* raw = PEM_read_bio_X509(bio.get(), nullptr, nullptr, nullptr);
    if (raw == nullptr) {
        app_fail("BACKUP_CERTIFICATE_INVALID", openssl_reason());
    }
    return X509Ptr(raw);
}

[[nodiscard]] X509Ptr decode_der_certificate(
    const datacube::OctetView der) {
    if (der.empty() ||
        der.size() > static_cast<std::size_t>(std::numeric_limits<long>::max())) {
        app_fail("BACKUP_CERTIFICATE_INVALID",
            "embedded certificate size is invalid");
    }
    const unsigned char* cursor = der.data();
    const unsigned char* const end = der.data() + der.size();
    X509* raw = d2i_X509(
        nullptr, &cursor, static_cast<long>(der.size()));
    if (raw == nullptr || cursor != end) {
        if (raw != nullptr) { X509_free(raw); }
        app_fail("BACKUP_CERTIFICATE_INVALID",
            "embedded certificate DER is malformed");
    }
    return X509Ptr(raw);
}

[[nodiscard]] PkeyPtr certificate_public_key(X509* certificate) {
    EVP_PKEY* raw = X509_get_pubkey(certificate);
    if (raw == nullptr) {
        app_fail("BACKUP_CERTIFICATE_INVALID", openssl_reason());
    }
    PkeyPtr key(raw);
    if (EVP_PKEY_base_id(key.get()) != EVP_PKEY_ED25519) {
        app_fail("BACKUP_CERTIFICATE_INVALID",
            "backup signing certificate must contain an Ed25519 key");
    }
    return key;
}

[[nodiscard]] datacube::Octets sign_backup_id(
    EVP_PKEY* key,
    const datacube::Digest32& backup_id) {
    MdContextPtr context(EVP_MD_CTX_new());
    if (!context ||
        EVP_DigestSignInit(context.get(), nullptr, nullptr, nullptr, key) != 1) {
        app_fail("BACKUP_SIGNATURE_FAILED", openssl_reason());
    }
    std::size_t size = 0U;
    if (EVP_DigestSign(
            context.get(), nullptr, &size,
            backup_id.octets.data(), backup_id.octets.size()) != 1 ||
        size == 0U || size > kMaximumSignatureBytes) {
        app_fail("BACKUP_SIGNATURE_FAILED", openssl_reason());
    }
    datacube::Octets signature(size);
    if (EVP_DigestSign(
            context.get(), signature.data(), &size,
            backup_id.octets.data(), backup_id.octets.size()) != 1) {
        app_fail("BACKUP_SIGNATURE_FAILED", openssl_reason());
    }
    signature.resize(size);
    return signature;
}

void verify_backup_signature(
    EVP_PKEY* key,
    const datacube::Digest32& backup_id,
    const datacube::OctetView signature) {
    MdContextPtr context(EVP_MD_CTX_new());
    if (!context ||
        EVP_DigestVerifyInit(context.get(), nullptr, nullptr, nullptr, key) != 1) {
        app_fail("BACKUP_SIGNATURE_INVALID", openssl_reason());
    }
    const int result = EVP_DigestVerify(
        context.get(), signature.data(), signature.size(),
        backup_id.octets.data(), backup_id.octets.size());
    if (result != 1) {
        app_fail("BACKUP_SIGNATURE_INVALID",
            result == 0 ? "backup signature does not verify" : openssl_reason());
    }
}

[[nodiscard]] datacube::Octets backup_id_input(
    const BackupResult& result,
    const datacube::Digest32& certificate_digest,
    const std::uint32_t certificate_size) {
    datacube::Octets out;
    datacube::append_text(out, kBackupIdDomain);
    datacube::append_u8(out, 0U);
    datacube::append_be32(out, kBackupVersion);
    datacube::append_u8(out, result.signed_backup ? 1U : 0U);
    datacube::append_be64(out, result.created_unix_ms);
    datacube::append_be32(out, result.storage_schema_version);
    datacube::append_be64(out, result.maintenance_generation);
    append_text16(out, result.node_id, 64U, "backup node ID");
    append_text16(out, result.identity_generation, 64U,
        "backup identity generation");
    append_digest(out, result.logical_state_digest);
    append_digest(out, result.checkpoint_digest);
    datacube::append_be64(out, result.checkpoint_bytes);
    if (result.signer_spki_sha256.has_value()) {
        append_digest(out, *result.signer_spki_sha256);
    } else {
        append_digest(out, datacube::Digest32{});
    }
    append_digest(out, certificate_digest);
    datacube::append_be32(out, certificate_size);
    return out;
}

[[nodiscard]] datacube::Octets encode_backup(
    BackupResult& result,
    const datacube::OctetView checkpoint,
    const datacube::OctetView certificate,
    const datacube::OctetView signature) {
    if (checkpoint.size() != result.checkpoint_bytes ||
        certificate.size() > kMaximumCertificateBytes ||
        signature.size() > kMaximumSignatureBytes ||
        certificate.size() > std::numeric_limits<std::uint32_t>::max() ||
        signature.size() > std::numeric_limits<std::uint32_t>::max()) {
        app_fail("BACKUP_FORMAT_INVALID", "backup component size is invalid");
    }
    const auto certificate_digest = certificate.empty() ?
        datacube::Digest32{} : datacube::sha256(certificate);
    result.backup_id = datacube::sha256(backup_id_input(
        result, certificate_digest,
        static_cast<std::uint32_t>(certificate.size())));

    datacube::Octets out;
    datacube::append_octets(out, kBackupMagic);
    datacube::append_be32(out, kBackupVersion);
    datacube::append_be32(out, result.signed_backup ? kSignedFlag : 0U);
    datacube::append_be64(out, result.created_unix_ms);
    datacube::append_be32(out, result.storage_schema_version);
    datacube::append_be64(out, result.maintenance_generation);
    append_text16(out, result.node_id, 64U, "backup node ID");
    append_text16(out, result.identity_generation, 64U,
        "backup identity generation");
    append_digest(out, result.logical_state_digest);
    append_digest(out, result.checkpoint_digest);
    datacube::append_be64(out, result.checkpoint_bytes);
    if (result.signer_spki_sha256.has_value()) {
        append_digest(out, *result.signer_spki_sha256);
    } else {
        append_digest(out, datacube::Digest32{});
    }
    append_digest(out, certificate_digest);
    datacube::append_be32(out, static_cast<std::uint32_t>(certificate.size()));
    datacube::append_be32(out, static_cast<std::uint32_t>(signature.size()));
    append_digest(out, result.backup_id);
    datacube::append_octets(out, checkpoint);
    datacube::append_octets(out, certificate);
    datacube::append_octets(out, signature);
    result.file_bytes = out.size();
    return out;
}

[[nodiscard]] std::string random_suffix() {
    std::array<unsigned char, 8> bytes {};
    if (RAND_bytes(bytes.data(), static_cast<int>(bytes.size())) != 1) {
        app_fail("BACKUP_RANDOM_FAILED", openssl_reason());
    }
    static constexpr char hex[] = "0123456789abcdef";
    std::string out;
    out.reserve(bytes.size() * 2U);
    for (const auto value : bytes) {
        out.push_back(hex[(value >> 4U) & 0x0fU]);
        out.push_back(hex[value & 0x0fU]);
    }
    return out;
}

void publish_file_no_replace(
    const Destination& destination,
    const datacube::OctetView bytes) {
    const int parent_raw = ::open(
        destination.parent.c_str(),
        O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (parent_raw < 0) {
        app_fail("BACKUP_PARENT_OPEN_FAILED",
            datacube::errno_detail(destination.parent.string(), errno));
    }
    datacube::Fd parent_fd(parent_raw);
    const std::string stage = ".natrav-overlay-backup-" +
        std::to_string(::getpid()) + "-" + random_suffix() + ".tmp";
    bool published = false;
    try {
        const int raw = ::openat(
            parent_fd.get(), stage.c_str(),
            O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW,
            S_IRUSR | S_IWUSR);
        if (raw < 0) {
            app_fail("BACKUP_STAGE_CREATE_FAILED",
                datacube::errno_detail(stage, errno));
        }
        datacube::Fd fd(raw);
        if (::fchmod(fd.get(), S_IRUSR | S_IWUSR) != 0) {
            app_fail("BACKUP_STAGE_MODE_FAILED", "cannot enforce mode 0600");
        }
        write_all(fd.get(), bytes, "backup staging file");
        if (::fsync(fd.get()) != 0) {
            app_fail("BACKUP_STAGE_SYNC_FAILED",
                datacube::errno_detail(stage, errno));
        }
        fd.reset();
        backup_publication_test_pause("ARCHIVE_BEFORE_PUBLISH");
        const long renamed = ::syscall(
            SYS_renameat2,
            parent_fd.get(), stage.c_str(),
            parent_fd.get(), destination.name.c_str(),
            RENAME_NOREPLACE);
        if (renamed != 0) {
            if (errno == EEXIST) {
                app_fail("BACKUP_DESTINATION_EXISTS",
                    "backup output appeared during publication");
            }
            app_fail("BACKUP_PUBLISH_FAILED",
                datacube::errno_detail(destination.absolute.string(), errno));
        }
        published = true;
        if (::fsync(parent_fd.get()) != 0) {
            app_fail("BACKUP_PARENT_SYNC_FAILED",
                datacube::errno_detail(destination.parent.string(), errno));
        }
        backup_publication_test_pause("ARCHIVE_AFTER_PUBLISH");
    } catch (...) {
        if (!published) {
            static_cast<void>(::unlinkat(parent_fd.get(), stage.c_str(), 0));
        }
        throw;
    }
}

void create_state_file(
    const std::filesystem::path& directory,
    const char* name,
    const datacube::OctetView bytes) {
    const auto path = directory / name;
    const int raw = ::open(
        path.c_str(), O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW,
        S_IRUSR | S_IWUSR);
    if (raw < 0) {
        app_fail("BACKUP_VALIDATION_SETUP_FAILED",
            datacube::errno_detail(path.string(), errno));
    }
    datacube::Fd fd(raw);
    write_all(fd.get(), bytes, path.string());
    if (::fsync(fd.get()) != 0) {
        app_fail("BACKUP_VALIDATION_SETUP_FAILED",
            datacube::errno_detail(path.string(), errno));
    }
}

[[nodiscard]] ParsedBackup parse_and_verify(
    const BackupVerifyOptions& options) {
    if (options.maximum_journal_bytes < 1'024U ||
        options.maximum_journal_bytes > 1'073'741'824U) {
        app_fail("BACKUP_LIMIT_INVALID", "maximum journal bytes is invalid");
    }
    if (options.expected_node_id.has_value()) {
        require_node_id(*options.expected_node_id, "expected backup node ID");
    }
    if (options.expected_identity_generation.has_value()) {
        require_generation_id(
            *options.expected_identity_generation,
            "expected backup identity generation");
    }
    const std::uint64_t overhead = 2U * 1'048'576U;
    if (options.maximum_journal_bytes >
        std::numeric_limits<std::uint64_t>::max() - overhead) {
        app_fail("BACKUP_LIMIT_INVALID", "backup ceiling overflow");
    }
    auto bytes = read_regular_file(
        options.input_file,
        options.maximum_journal_bytes + overhead + 256U,
        false,
        "backup input");
    BackupWipeGuard wipe(bytes);
    const auto outer_file_bytes = bytes.size();
    const auto outer_file_digest = datacube::sha256(bytes);
    std::optional<BackupKeyIdentity> encryption_key;
    if (is_encrypted_backup(bytes)) {
        if (!options.decryption_key.has_value()) {
            app_fail("BACKUP_DECRYPTION_KEY_REQUIRED", "encrypted backup requires an exact key file");
        }
        auto opened = decrypt_backup_bytes(bytes, *options.decryption_key,
            options.maximum_journal_bytes + overhead);
        encryption_key = std::move(opened.key);
        bytes = std::move(opened.bytes);
    } else if (options.require_encryption || options.decryption_key.has_value()) {
        app_fail("BACKUP_ENCRYPTION_REQUIRED", "plaintext input is not accepted when encryption is required or a decryption key is supplied");
    }
    datacube::Reader reader(bytes, options.input_file.string());
    const auto magic = reader.read_exact(kBackupMagic.size(), "backup magic");
    if (!std::equal(kBackupMagic.begin(), kBackupMagic.end(), magic.begin())) {
        app_fail("BACKUP_FORMAT_INVALID", "backup magic mismatch");
    }
    const auto version = reader.read_be32("backup version");
    const auto flags = reader.read_be32("backup flags");
    if (version != kBackupVersion || (flags & ~kSignedFlag) != 0U) {
        app_fail("BACKUP_FORMAT_INVALID", "backup version or flags are unsupported");
    }
    BackupResult result;
    result.path = std::filesystem::absolute(options.input_file).lexically_normal();
    result.signed_backup = (flags & kSignedFlag) != 0U;
    result.created_unix_ms = reader.read_be64("created Unix milliseconds");
    result.storage_schema_version = reader.read_be32("storage schema");
    result.maintenance_generation = reader.read_be64("maintenance generation");
    result.node_id = read_text16(reader, 64U, "backup node ID");
    result.identity_generation = read_text16(
        reader, 64U, "backup identity generation");
    result.logical_state_digest = read_digest(reader, "logical state digest");
    result.checkpoint_digest = read_digest(reader, "checkpoint digest");
    result.checkpoint_bytes = reader.read_be64("checkpoint size");
    const auto signer_spki = read_digest(reader, "signer SPKI digest");
    const auto certificate_digest = read_digest(reader, "certificate digest");
    const auto certificate_size = reader.read_be32("certificate size");
    const auto signature_size = reader.read_be32("signature size");
    result.backup_id = read_digest(reader, "backup ID");
    if (result.created_unix_ms == 0U ||
        result.storage_schema_version != kCurrentStorageSchemaVersion ||
        !valid_node_id(result.node_id) ||
        !valid_generation_id(result.identity_generation) ||
        digest_is_zero(result.logical_state_digest) ||
        digest_is_zero(result.checkpoint_digest) ||
        digest_is_zero(result.backup_id) ||
        result.checkpoint_bytes == 0U ||
        result.checkpoint_bytes > options.maximum_journal_bytes ||
        certificate_size > kMaximumCertificateBytes ||
        signature_size > kMaximumSignatureBytes) {
        app_fail("BACKUP_FORMAT_INVALID", "backup manifest is invalid");
    }
    const auto checkpoint_view = reader.read_exact(
        result.checkpoint_bytes, "checkpoint journal");
    const auto certificate_view = reader.read_exact(
        certificate_size, "embedded certificate");
    const auto signature_view = reader.read_exact(
        signature_size, "backup signature");
    reader.require_eof("backup file");
    result.file_bytes = outer_file_bytes;
    result.inner_file_bytes = bytes.size();
    result.encrypted = encryption_key.has_value();
    result.encryption_authenticated = encryption_key.has_value();
    result.encryption_key = std::move(encryption_key);

    if (datacube::sha256(checkpoint_view) != result.checkpoint_digest) {
        app_fail("BACKUP_CHECKPOINT_DIGEST_MISMATCH",
            "checkpoint content digest does not match the manifest");
    }
    const bool manifest_signed = !digest_is_zero(signer_spki) ||
        !digest_is_zero(certificate_digest) || certificate_size != 0U ||
        signature_size != 0U;
    if (manifest_signed != result.signed_backup) {
        app_fail("BACKUP_FORMAT_INVALID",
            "signed flag and signature material disagree");
    }
    if (result.signed_backup) {
        if (digest_is_zero(signer_spki) || digest_is_zero(certificate_digest) ||
            certificate_size == 0U || signature_size == 0U ||
            datacube::sha256(certificate_view) != certificate_digest) {
            app_fail("BACKUP_FORMAT_INVALID",
                "signed backup identity material is incomplete");
        }
        result.signer_spki_sha256 = signer_spki;
    } else if (options.require_signature) {
        app_fail("BACKUP_SIGNATURE_REQUIRED",
            "backup is unsigned but a signature was required");
    }
    const auto calculated_id = datacube::sha256(backup_id_input(
        result, certificate_digest, certificate_size));
    if (calculated_id != result.backup_id) {
        app_fail("BACKUP_ID_MISMATCH",
            "backup manifest identity does not verify");
    }
    if (options.expected_backup_id &&
        *options.expected_backup_id != result.backup_id) {
        app_fail("BACKUP_ID_EXPECTATION_MISMATCH",
            "verified signed backup identity differs from the explicitly supplied expectation");
    }
    if (options.expected_node_id.has_value() &&
        *options.expected_node_id != result.node_id) {
        app_fail("BACKUP_NODE_MISMATCH",
            "backup node does not match the expected node");
    }
    if (options.expected_identity_generation.has_value() &&
        *options.expected_identity_generation != result.identity_generation) {
        app_fail("BACKUP_GENERATION_MISMATCH",
            "backup identity generation does not match the expected generation");
    }

    datacube::Octets certificate(
        certificate_view.begin(), certificate_view.end());
    datacube::Octets signature(signature_view.begin(), signature_view.end());
    if (result.signed_backup) {
        auto embedded = decode_der_certificate(certificate);
        auto embedded_key = certificate_public_key(embedded.get());
        if (pkey_spki_sha256(embedded_key.get()) != signer_spki) {
            app_fail("BACKUP_SIGNER_MISMATCH",
                "embedded certificate does not match signer SPKI digest");
        }
        verify_backup_signature(
            embedded_key.get(), result.backup_id, signature);
        result.signature_valid = true;
        if (options.trusted_certificate.has_value()) {
            auto trusted = load_pem_certificate(*options.trusted_certificate);
            auto trusted_key = certificate_public_key(trusted.get());
            if (pkey_spki_sha256(trusted_key.get()) != signer_spki) {
                app_fail("BACKUP_SIGNER_NOT_TRUSTED",
                    "backup signer does not match the trusted certificate");
            }
            result.trusted_signer = true;
        }
    } else if (options.trusted_certificate.has_value()) {
        app_fail("BACKUP_SIGNATURE_REQUIRED",
            "a trusted certificate was supplied for an unsigned backup");
    }

    const auto checkpoint_snapshot = NodeState::validate_checkpoint_image(
        checkpoint_view, result.node_id, options.maximum_journal_bytes);
    if (checkpoint_snapshot.storage_schema_version !=
            result.storage_schema_version ||
        checkpoint_snapshot.maintenance_generation !=
            result.maintenance_generation ||
        checkpoint_snapshot.logical_state_digest !=
            result.logical_state_digest ||
        checkpoint_snapshot.journal_bytes != result.checkpoint_bytes) {
        app_fail("BACKUP_CHECKPOINT_STATE_MISMATCH",
            "normal state decoder disagrees with the backup manifest");
    }

    result.state_authentication = checkpoint_snapshot.authentication;
    // Do not stage a restore or re-encryption until the exact verified embedded
    // checkpoint matches. Internal candidate validation never inherits this gate.
    enforce_expected_state_head(result.node_id, result.state_authentication, result.checkpoint_bytes);

    return ParsedBackup{
        .result = std::move(result),
        .outer_file_digest = outer_file_digest,
        .checkpoint = datacube::Octets(
            checkpoint_view.begin(), checkpoint_view.end()),
        .certificate_der = std::move(certificate),
        .signature = std::move(signature),
    };
}

class RestoreStageGuard final {
public:
    RestoreStageGuard(int parent_fd, std::string name)
        : parent_fd_(parent_fd), name_(std::move(name)) {}
    ~RestoreStageGuard() {
        if (published_) { return; }
        static_cast<void>(::unlinkat(
            parent_fd_, (name_ + "/state.lock").c_str(), 0));
        static_cast<void>(::unlinkat(
            parent_fd_, (name_ + "/state.journal").c_str(), 0));
        static_cast<void>(::unlinkat(
            parent_fd_, (name_ + "/node.meta").c_str(), 0));
        static_cast<void>(::unlinkat(parent_fd_, name_.c_str(), AT_REMOVEDIR));
    }
    void published() noexcept { published_ = true; }
private:
    int parent_fd_{-1};
    std::string name_;
    bool published_{false};
};

}  // namespace

BackupResult export_backup(const BackupExportOptions& options) {
    require_node_id(options.node_id, "backup node ID");
    require_generation_id(
        options.identity_generation, "backup identity generation");
    const bool has_key = options.signing_private_key.has_value();
    const bool has_certificate = options.signing_certificate.has_value();
    if (has_key != has_certificate) {
        app_fail("BACKUP_SIGNING_ARGUMENTS_INVALID",
            "signing private key and certificate must be supplied together");
    }
    const auto destination = validate_destination(
        options.output_file, "backup output");
    if (options.encryption_key.has_value()) {
        static_cast<void>(check_backup_key(*options.encryption_key));
    }
    NodeState state(
        options.state_directory, options.node_id,
        options.maximum_journal_bytes);
    const auto created = unix_milliseconds_now();
    auto image = state.checkpoint_image(created);
    BackupWipeGuard wipe_image(image.journal_bytes);
    BackupResult result{
        .path = destination.absolute,
        .node_id = options.node_id,
        .identity_generation = options.identity_generation,
        .storage_schema_version = image.storage_schema_version,
        .created_unix_ms = created,
        .maintenance_generation = image.maintenance_generation,
        .checkpoint_bytes = image.journal_bytes.size(),
        .file_bytes = 0U,
        .logical_state_digest = image.logical_state_digest,
        .checkpoint_digest = datacube::sha256(image.journal_bytes),
        .backup_id = {},
        .signed_backup = has_key,
        .signature_valid = has_key,
        .trusted_signer = false,
        .signer_spki_sha256 = std::nullopt,
        .encrypted = false,
        .encryption_authenticated = false,
        .inner_file_bytes = 0U,
        .encryption_key = std::nullopt,
        .previous_encryption_key = std::nullopt,
        .state_authentication = image.authentication,
    };

    datacube::Octets certificate;
    datacube::Octets signature;
    PkeyPtr private_key;
    if (has_key) {
        private_key = load_private_key(*options.signing_private_key);
        auto cert = load_pem_certificate(*options.signing_certificate);
        auto public_key = certificate_public_key(cert.get());
        if (EVP_PKEY_eq(private_key.get(), public_key.get()) != 1) {
            app_fail("BACKUP_SIGNING_IDENTITY_MISMATCH",
                "signing private key and certificate do not match");
        }
        result.signer_spki_sha256 = pkey_spki_sha256(public_key.get());
        certificate = certificate_der(cert.get());
        const auto cert_digest = datacube::sha256(certificate);
        result.backup_id = datacube::sha256(backup_id_input(
            result, cert_digest,
            static_cast<std::uint32_t>(certificate.size())));
        signature = sign_backup_id(private_key.get(), result.backup_id);
    }
    auto encoded = encode_backup(
        result, image.journal_bytes, certificate, signature);
    BackupWipeGuard wipe_encoded(encoded);
    result.inner_file_bytes = encoded.size();
    if (options.encryption_key.has_value()) {
        auto sealed = encrypt_backup_bytes(encoded, *options.encryption_key);
        // Validate the exact bytes to be published, not only a round-trip of
        // a different buffer. No plaintext ever goes into an export staging file.
        auto verified = decrypt_backup_bytes(sealed.bytes, *options.encryption_key,
            options.maximum_journal_bytes + 2U * 1'048'576U);
        BackupWipeGuard wipe_verified(verified.bytes);
        if (verified.bytes != encoded) {
            app_fail("BACKUP_ENCRYPTION_ROUNDTRIP_FAILED", "candidate encrypted backup differs from source");
        }
        result.encrypted = true;
        result.encryption_authenticated = true;
        result.encryption_key = sealed.key;
        result.file_bytes = sealed.bytes.size();
        publish_file_no_replace(destination, sealed.bytes);
    } else {
        publish_file_no_replace(destination, encoded);
    }
    return result;
}

BackupResult reencrypt_backup(const BackupReencryptOptions& options) {
    auto verification = options.verification;
    verification.require_encryption = true;
    const auto parsed = parse_and_verify(verification);
    const auto next_key = check_backup_key(options.encryption_key);
    if (!parsed.result.encryption_key.has_value() ||
        next_key.generation == parsed.result.encryption_key->generation ||
        next_key.id == parsed.result.encryption_key->id) {
        app_fail("BACKUP_REENCRYPT_GENERATION_REQUIRED", "re-encryption requires a different key and generation");
    }
    const auto destination = validate_destination(options.output_file, "re-encrypted backup output");
    auto result = parsed.result;
    const auto original_id = result.backup_id;
    auto encoded = encode_backup(result, parsed.checkpoint, parsed.certificate_der, parsed.signature);
    BackupWipeGuard wipe(encoded);
    if (result.backup_id != original_id) {
        app_fail("BACKUP_REENCRYPT_ID_MISMATCH", "re-encryption must preserve the signed inner backup identity");
    }
    auto sealed = encrypt_backup_bytes(encoded, options.encryption_key);
    auto verified = decrypt_backup_bytes(sealed.bytes, options.encryption_key,
        options.verification.maximum_journal_bytes + 2U * 1'048'576U);
    BackupWipeGuard wipe_verified(verified.bytes);
    if (verified.bytes != encoded) {
        app_fail("BACKUP_ENCRYPTION_ROUNDTRIP_FAILED", "re-encrypted candidate differs from source");
    }
    result.previous_encryption_key = result.encryption_key;
    result.encryption_key = sealed.key;
    result.path = destination.absolute;
    result.inner_file_bytes = encoded.size();
    result.file_bytes = sealed.bytes.size();
    publish_file_no_replace(destination, sealed.bytes);
    return result;
}

BackupResult verify_backup(const BackupVerifyOptions& options) {
    return parse_and_verify(options).result;
}

BackupResult verify_backup_exact_input(
    const BackupVerifyOptions& options,
    const std::uint64_t expected_file_bytes,
    const datacube::Digest32& expected_file_digest) {
    auto parsed = parse_and_verify(options);
    test_pause_exact_backup_verification();
    if (parsed.result.file_bytes != expected_file_bytes ||
        parsed.outer_file_digest != expected_file_digest) {
        app_fail("BACKUP_SOURCE_CHANGED",
            "verified backup differs from the exact retained promotion input");
    }
    return std::move(parsed.result);
}

std::string audit_backup_correlated_stop(
    const BackupCorrelatedStopAuditOptions& options) {
    if (!process_state_auth_key()) {
        app_fail("STATE_AUTH_KEY_REQUIRED",
            "backup correlated-stop audit requires the embedded checkpoint authentication key");
    }
    auto parsed = parse_and_verify(options.verification);
    if (!parsed.result.encrypted || !parsed.result.encryption_authenticated ||
        !parsed.result.signed_backup || !parsed.result.signature_valid ||
        !parsed.result.trusted_signer) {
        app_fail("BACKUP_CORRELATED_STOP_AUDIT_TRUST_REQUIRED",
            "direct backup audit requires authenticated encryption and an explicitly trusted signature");
    }
    if (parsed.result.node_id != options.audit.source.node ||
        parsed.result.checkpoint_bytes != parsed.checkpoint.size()) {
        app_fail("BACKUP_CORRELATED_STOP_AUDIT_SOURCE_MISMATCH",
            "verified backup and correlated-stop audit source accounts disagree");
    }
    const auto replay = NodeState::replay_correlated_stop_audit(
        parsed.checkpoint, parsed.result.node_id,
        options.verification.maximum_journal_bytes,
        process_state_auth_key(), options.audit.request_id,
        options.audit.maximum_matches);
    enforce_expected_state_head(parsed.result.node_id, replay.authentication,
        replay.journal_bytes);

    const std::string source_json =
        "{\"status\":\"COMPLETE_SIGNED_ENCRYPTED_BACKUP_AUTHENTICATED_SEMANTIC_REPLAY\"," +
        std::string("\"path\":") + json_string(parsed.result.path.string()) +
        ",\"file_bytes\":" + std::to_string(parsed.result.file_bytes) +
        ",\"file_sha256\":" + json_string(datacube::hex_lower(parsed.outer_file_digest)) +
        ",\"backup_id\":" + json_string(datacube::hex_lower(parsed.result.backup_id)) +
        ",\"identity_generation\":" + json_string(parsed.result.identity_generation) +
        ",\"signed\":true,\"signature_valid\":true,\"trusted_signer\":true," +
        std::string("\"encrypted\":true,\"encryption_authenticated\":true,") +
        "\"checkpoint_bytes\":" + std::to_string(parsed.checkpoint.size()) +
        ",\"checkpoint_sha256\":" + json_string(datacube::hex_lower(parsed.result.checkpoint_digest)) +
        ",\"restore_performed\":false,\"writer_opened\":false," +
        std::string("\"workers_started\":false,\"state_mutated\":false}");
    auto report = render_correlated_stop_audit_report(options.audit, replay,
        "NATRAV_OVERLAY_BACKUP_CORRELATED_STOP_AUDIT_V1", source_json);

    const std::uint64_t overhead = 2U * 1'048'576U;
    const auto current = read_regular_file(options.verification.input_file,
        options.verification.maximum_journal_bytes + overhead + 256U,
        false, "backup audit input recheck");
    if (current.size() != parsed.result.file_bytes ||
        datacube::sha256(current) != parsed.outer_file_digest) {
        app_fail("BACKUP_CORRELATED_STOP_AUDIT_SOURCE_CHANGED",
            "backup bytes changed while the authenticated audit report was constructed");
    }
    return report;
}

BackupRestoreResult restore_backup(const BackupRestoreOptions& options) {
    require_node_id(options.expected_node_id, "restore node ID");
    require_generation_id(
        options.expected_identity_generation,
        "restore identity generation");
    const auto parsed = parse_and_verify(BackupVerifyOptions{
        .input_file = options.input_file,
        .expected_node_id = options.expected_node_id,
        .expected_identity_generation = options.expected_identity_generation,
        .trusted_certificate = options.trusted_certificate,
        .require_signature = options.require_signature,
        .maximum_journal_bytes = options.maximum_journal_bytes,
        .decryption_key = options.decryption_key,
        .require_encryption = options.require_encryption,
        .expected_backup_id = std::nullopt,
    });
    const auto destination = validate_destination(
        options.destination_directory, "restore destination");
    const int parent_raw = ::open(
        destination.parent.c_str(),
        O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (parent_raw < 0) {
        app_fail("BACKUP_PARENT_OPEN_FAILED",
            datacube::errno_detail(destination.parent.string(), errno));
    }
    datacube::Fd parent_fd(parent_raw);
    const std::string stage = ".natrav-overlay-restore-" +
        std::to_string(::getpid()) + "-" + random_suffix();
    if (::mkdirat(parent_fd.get(), stage.c_str(), S_IRWXU) != 0) {
        app_fail("BACKUP_RESTORE_STAGE_CREATE_FAILED",
            datacube::errno_detail(stage, errno));
    }
    RestoreStageGuard stage_guard(parent_fd.get(), stage);
    const auto stage_path = destination.parent / stage;
    const int stage_raw = ::openat(
        parent_fd.get(), stage.c_str(),
        O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (stage_raw < 0) {
        app_fail("BACKUP_RESTORE_STAGE_OPEN_FAILED",
            datacube::errno_detail(stage, errno));
    }
    datacube::Fd stage_fd(stage_raw);
    if (::fchmod(stage_fd.get(), S_IRWXU) != 0) {
        app_fail("BACKUP_RESTORE_STAGE_MODE_FAILED",
            datacube::errno_detail(stage, errno));
    }
    const std::string metadata = std::string(kMetadataPrefix) +
        parsed.result.node_id + "\nstorage_schema=2\n";
    create_state_file(
        stage_path, "node.meta", datacube::text_octets(metadata));
    create_state_file(stage_path, "state.journal", parsed.checkpoint);
    if (::fsync(stage_fd.get()) != 0) {
        app_fail("BACKUP_RESTORE_STAGE_SYNC_FAILED",
            datacube::errno_detail(stage, errno));
    }

    const auto restored_at = unix_milliseconds_now();
    StateSnapshot restored;
    {
        NodeState state(
            stage_path, parsed.result.node_id,
            options.maximum_journal_bytes);
        const auto before = state.snapshot();
        if (before.logical_state_digest != parsed.result.logical_state_digest) {
            app_fail("BACKUP_RESTORE_STATE_MISMATCH",
                "restored checkpoint logical digest differs from backup");
        }
        state.record_backup_restore(
            parsed.result.backup_id,
            parsed.result.identity_generation,
            restored_at);
        restored = state.snapshot();
        if (restored.logical_state_digest != parsed.result.logical_state_digest ||
            !restored.restored_backup_id.has_value() ||
            *restored.restored_backup_id != parsed.result.backup_id ||
            restored.restored_backup_generation !=
                parsed.result.identity_generation ||
            !restored.restored_backup_unix_ms.has_value() ||
            *restored.restored_backup_unix_ms != restored_at) {
            app_fail("BACKUP_RESTORE_STATE_MISMATCH",
                "restore provenance account did not reconstruct correctly");
        }
    }
    if (::fsync(stage_fd.get()) != 0) {
        app_fail("BACKUP_RESTORE_STAGE_SYNC_FAILED",
            datacube::errno_detail(stage, errno));
    }
    stage_fd.reset();
    const long renamed = ::syscall(
        SYS_renameat2,
        parent_fd.get(), stage.c_str(),
        parent_fd.get(), destination.name.c_str(),
        RENAME_NOREPLACE);
    if (renamed != 0) {
        if (errno == EEXIST) {
            app_fail("BACKUP_DESTINATION_EXISTS",
                "restore destination appeared during publication");
        }
        app_fail("BACKUP_RESTORE_PUBLISH_FAILED",
            datacube::errno_detail(destination.absolute.string(), errno));
    }
    stage_guard.published();
    if (::fsync(parent_fd.get()) != 0) {
        app_fail("BACKUP_PARENT_SYNC_FAILED",
            datacube::errno_detail(destination.parent.string(), errno));
    }
    return BackupRestoreResult{
        .backup = parsed.result,
        .destination_directory = destination.absolute,
        .restored_unix_ms = restored_at,
        .restored_journal_bytes = restored.journal_bytes,
        .restored_authentication = restored.authentication,
    };
}

std::string backup_result_json(
    const BackupResult& result,
    const std::string_view operation) {
    return std::string("{\"format\":\"NATRAV_OVERLAY_BACKUP_V1\",\"ok\":true") +
        ",\"operation\":" + json_string(operation) +
        ",\"path\":" + json_string(result.path.string()) +
        ",\"node\":" + json_string(result.node_id) +
        ",\"identity_generation\":" +
        json_string(result.identity_generation) +
        ",\"storage_schema_version\":" +
        std::to_string(result.storage_schema_version) +
        ",\"created_unix_ms\":" + std::to_string(result.created_unix_ms) +
        ",\"maintenance_generation\":" +
        std::to_string(result.maintenance_generation) +
        ",\"checkpoint_bytes\":" + std::to_string(result.checkpoint_bytes) +
        ",\"file_bytes\":" + std::to_string(result.file_bytes) +
        ",\"logical_state_digest\":" +
        json_string(datacube::hex_lower(result.logical_state_digest)) +
        ",\"checkpoint_digest\":" +
        json_string(datacube::hex_lower(result.checkpoint_digest)) +
        ",\"backup_id\":" +
        json_string(datacube::hex_lower(result.backup_id)) +
        ",\"encrypted\":" + std::string(result.encrypted ? "true" : "false") +
        ",\"encryption_authenticated\":" + std::string(result.encryption_authenticated ? "true" : "false") +
        ",\"encryption_suite\":" + (result.encrypted ?
            json_string("AES-256-GCM/HKDF-SHA-256") : std::string("null")) +
        ",\"encryption_key_generation\":" + (result.encryption_key.has_value() ?
            json_string(result.encryption_key->generation) : std::string("null")) +
        ",\"encryption_key_id\":" + (result.encryption_key.has_value() ?
            json_string(datacube::hex_lower(result.encryption_key->id)) : std::string("null")) +
        ",\"previous_encryption_key_generation\":" + (result.previous_encryption_key.has_value() ?
            json_string(result.previous_encryption_key->generation) : std::string("null")) +
        ",\"inner_file_bytes\":" + std::to_string(result.inner_file_bytes) +
        ",\"state_authentication\":" + json_string(result.state_authentication ? "HMAC_SHA256_CHAIN_V1" : "UNKEYED") +
        ",\"state_authentication_account\":" + state_authentication_json(result.state_authentication) +
        ",\"state_head\":" + state_head_json(result.node_id, result.state_authentication,
            result.checkpoint_bytes, operation != "export") +
        ",\"expectation_scope\":" + json_string(operation == "export" ? "SOURCE_STATE_AT_OPEN" : "EMBEDDED_CHECKPOINT") +
        ",\"input_expectation\":" + json_string(process_state_head_expectation() ? "MATCHED" : "NOT_SUPPLIED") +
        ",\"signed\":" + std::string(result.signed_backup ? "true" : "false") +
        ",\"signature_valid\":" +
        std::string(result.signature_valid ? "true" : "false") +
        ",\"trusted_signer\":" +
        std::string(result.trusted_signer ? "true" : "false") +
        ",\"signer_spki_sha256\":" +
        (result.signer_spki_sha256.has_value() ?
            json_string(datacube::hex_lower(*result.signer_spki_sha256)) :
            std::string("null")) + "}";
}

std::string backup_restore_result_json(
    const BackupRestoreResult& result) {
    std::string out = backup_result_json(result.backup, "restore");
    if (out.empty() || out.back() != '}') {
        app_fail("BACKUP_JSON_FAILED", "backup JSON construction failed");
    }
    out.pop_back();
    out += ",\"destination\":" +
        json_string(result.destination_directory.string()) +
        ",\"restored_unix_ms\":" +
        std::to_string(result.restored_unix_ms) +
        ",\"restored_journal_bytes\":" +
        std::to_string(result.restored_journal_bytes) +
        ",\"restored_state_head\":" + state_head_json(result.backup.node_id,
            result.restored_authentication, result.restored_journal_bytes, false) + "}";
    return out;
}

}  // namespace natrav_overlay
