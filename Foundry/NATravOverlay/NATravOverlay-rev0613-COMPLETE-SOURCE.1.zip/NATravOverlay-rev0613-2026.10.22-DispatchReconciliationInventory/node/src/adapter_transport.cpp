#include "adapter_transport.hpp"
#include "external_packet_adapter.hpp"
#include "packet_port.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <memory>
#include <openssl/rand.h>
#include <span>
#include <string>
#include <sys/timerfd.h>
#include <unistd.h>
#include <utility>

namespace natrav_overlay {
namespace {
using Clock = std::chrono::steady_clock;
ResolvedConfiguredAdapterEndpoint resolve(const RuntimeConfig& config,
    const TransportLocator& locator, const AdapterEndpointRole role) {
    if (config.format_version < 19U) {
        app_fail("ADAPTER_AUTHORIZED_CONTEXT_REQUIRED", "accepted V19 configuration required");
    }
    return resolve_runtime_adapter_endpoint(config.adapter_configuration, locator, role);
}
std::uint32_t fresh_packet_epoch() {
    for (unsigned attempt = 0U; attempt < 8U; ++attempt) {
        std::array<unsigned char, 4U> bytes{};
        if (RAND_bytes(bytes.data(), static_cast<int>(bytes.size())) != 1) {
            app_fail("ADAPTER_PACKET_EPOCH_FAILED", "cryptographic random generation failed");
        }
        const auto value =
            (static_cast<std::uint32_t>(bytes[0U]) << 24U) |
            (static_cast<std::uint32_t>(bytes[1U]) << 16U) |
            (static_cast<std::uint32_t>(bytes[2U]) << 8U) |
            static_cast<std::uint32_t>(bytes[3U]);
        if (value != 0U) {
            return value;
        }
    }
    app_fail("ADAPTER_PACKET_EPOCH_FAILED", "could not select a nonzero packet epoch");
}

PacketPortOrderedStreamOptions stream_options(
    const ResolvedConfiguredAdapterEndpoint& binding,
    const bool listener) {
    PacketPortOrderedStreamOptions result;
    result.limits.mtu = binding.profile.mtu;
    result.limits.max_message_bytes = 65'536U;
    result.limits.max_reassembly_bytes = 262'144U;
    result.limits.max_delivery_bytes = 262'144U;
    result.limits.max_inflight_frames = 16U;
    result.limits.max_control_frames = 64U;
    result.limits.max_receive_packets_per_pump = 16U;
    // Process scheduling is not a physical-link time guarantee. The absolute
    // byte-operation deadline takes precedence over this finite retry profile.
    result.limits.retransmit_after_ticks = 50U;
    result.limits.retry_limit = 8U;
    result.limits.message_expiry_ticks = 3'000U;
    result.stream_id = binding.endpoint.locator.link_id;
    result.epoch = listener ? 0U : fresh_packet_epoch();
    result.bind_epoch_from_first_packet = listener;
    result.tick_interval = std::chrono::milliseconds(10);
    result.shutdown_budget = std::chrono::milliseconds(2'000);
    result.propagate_operation_deadline = true;
    result.limits.validate();
    return result;
}
struct ListenerLease final { std::atomic<bool> active{false}; };
// No hashing, fork or handshake on the accept/control thread. First byte I/O
// in a peer worker constructs the carrier under that operation's deadline.
class ConfiguredAdapterStream final : public OrderedByteStream {
public:
    ConfiguredAdapterStream(ResolvedConfiguredAdapterEndpoint binding,
        const bool listener,
        std::shared_ptr<ListenerLease> lease = {})
        : binding_(std::move(binding)), listener_(listener), lease_(std::move(lease)) {}
    ~ConfiguredAdapterStream() override {
        stream_.reset(); // retire the child/image before releasing the lease
        if (lease_) { lease_->active.store(false); }
    }
    TransportKind transport_kind() const noexcept override { return TransportKind::adapter; }
    std::size_t read_some(const std::span<std::uint8_t> bytes, const Deadline deadline,
        IoCounters& counters, const std::string_view operation) override {
        ensure(deadline);
        try { return stream_->read_some(bytes, deadline, counters, operation); }
        catch (...) { failed_ = true; throw; }
    }
    std::size_t write_some(const datacube::OctetView bytes, const Deadline deadline,
        IoCounters& counters, const std::string_view operation) override {
        ensure(deadline);
        try { return stream_->write_some(bytes, deadline, counters, operation); }
        catch (...) { failed_ = true; throw; }
    }
    void shutdown_write() override {
        if (stream_ && !failed_) { stream_->shutdown_write(); }
    }
    void ensure(const Deadline deadline) {
        if (failed_) { app_fail("PEER_RESET", "failed adapter carrier cannot be resurrected"); }
        if (Clock::now() >= deadline) { app_fail("IO_TIMEOUT", "configured adapter operation"); }
        if (stream_) { return; }
        try {
            // Each NEW carrier reopens/hashes/seals the pinned image. A path
            // change cannot cause image reuse across separately opened sessions.
            auto options = external_packet_adapter_options_from_profile(binding_.profile);
            if (options.pinned_profile_sha256 != binding_.profile_sha256 ||
                !options.verified_executable ||
                options.verified_executable->sha256() != binding_.profile.executable_sha256) {
                app_fail("ADAPTER_PROFILE_DRIFT", "accepted profile preparation changed");
            }
            options.launch_deadline = deadline;
            if (Clock::now() >= deadline) { app_fail("IO_TIMEOUT", "adapter image preparation"); }
            auto adapter = make_supervised_external_packet_adapter(std::move(options));
            stream_ = make_packet_port_ordered_byte_stream(std::move(adapter.port), stream_options(binding_, listener_));
        } catch (const AdapterProfileError& error) {
            failed_ = true;
            app_fail(error.code(), "configured adapter image preparation rejected");
        } catch (...) { failed_ = true; throw; }
    }
private:
    ResolvedConfiguredAdapterEndpoint binding_;
    bool listener_{false};
    std::shared_ptr<ListenerLease> lease_;
    std::unique_ptr<OrderedByteStream> stream_;
    bool failed_{false};
};
class ConfiguredAdapterConnector final : public TransportConnector {
public:
    ConfiguredAdapterConnector(TransportLocator locator, ResolvedConfiguredAdapterEndpoint binding)
        : locator_(std::move(locator)), binding_(std::move(binding)) {}
    std::unique_ptr<OrderedByteStream> connect(const TransportLocator& locator,
        const Deadline deadline, IoCounters& counters) const override {
        static_cast<void>(counters);
        if (transport_locator_text(locator) != transport_locator_text(locator_)) {
            app_fail("ADAPTER_PROFILE_DRIFT", "connector used with a different endpoint reference");
        }
        auto stream = std::make_unique<ConfiguredAdapterStream>(binding_, false);
        stream->ensure(deadline);
        return stream;
    }
private:
    TransportLocator locator_;
    ResolvedConfiguredAdapterEndpoint binding_;
};
class ConfiguredAdapterListener final : public TransportListener {
public:
    ConfiguredAdapterListener(TransportLocator locator, ResolvedConfiguredAdapterEndpoint binding)
        : locator_(std::move(locator)), binding_(std::move(binding)),
          lease_(std::make_shared<ListenerLease>()),
          timer_(::timerfd_create(CLOCK_MONOTONIC, TFD_NONBLOCK | TFD_CLOEXEC)) {
        if (timer_.get() < 0) { app_fail("LISTEN_FAILED", "adapter timer creation failed"); }
        // Single lease, at most two admissions per second. No busy-spinning
        // accept/relaunch loop on a missing, crashing or uncooperative image.
        const itimerspec spec{.it_interval = {.tv_sec = 0, .tv_nsec = 500'000'000},
                              .it_value = {.tv_sec = 0, .tv_nsec = 1}};
        if (::timerfd_settime(timer_.get(), 0, &spec, nullptr) != 0) {
            app_fail("LISTEN_FAILED", "adapter admission timer failed");
        }
    }
    TransportKind transport_kind() const noexcept override { return TransportKind::adapter; }
    int readiness_handle() const noexcept override { return timer_.get(); }
    TransportLocator bound_locator() const override { return locator_; }
    std::unique_ptr<OrderedByteStream> accept_ready() override {
        std::uint64_t expirations = 0U;
        const auto count = ::read(timer_.get(), &expirations, sizeof(expirations));
        if (count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)) { return {}; }
        if (count != static_cast<ssize_t>(sizeof(expirations))) {
            app_fail("ACCEPT_FAILED", "adapter admission timer read failed");
        }
        if (lease_->active.load()) { return {}; }
        auto stream = std::make_unique<ConfiguredAdapterStream>(binding_, true, lease_);
        lease_->active.store(true);
        return stream;
    }
private:
    TransportLocator locator_;
    ResolvedConfiguredAdapterEndpoint binding_;
    std::shared_ptr<ListenerLease> lease_;
    datacube::Fd timer_;
};
}  // namespace
std::unique_ptr<TransportConnector> make_configured_adapter_connector(
    const RuntimeConfig& accepted, const TransportLocator& locator) {
    return std::make_unique<ConfiguredAdapterConnector>(locator,
        resolve(accepted, locator, AdapterEndpointRole::route));
}
std::unique_ptr<TransportListener> listen_configured_adapter_transport(
    const RuntimeConfig& accepted, const TransportLocator& locator) {
    return std::make_unique<ConfiguredAdapterListener>(locator,
        resolve(accepted, locator, AdapterEndpointRole::listener));
}
}  // namespace natrav_overlay
