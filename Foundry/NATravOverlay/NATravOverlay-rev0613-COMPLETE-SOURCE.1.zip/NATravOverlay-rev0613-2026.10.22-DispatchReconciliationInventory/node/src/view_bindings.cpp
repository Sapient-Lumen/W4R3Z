#include "view_bindings.hpp"
#include "journal.hpp"
#include "config.hpp"
#include "submission_work.hpp"

#include <algorithm>
#include <vector>

namespace natrav_overlay {
namespace {
using Digest = datacube::Digest32;
using Bytes = datacube::Octets;
constexpr std::size_t kPrincipalReserve = 384U;
void require(bool condition, std::string_view code, std::string_view detail) {
    if (!condition) app_fail(code, detail);
}
void text(Bytes& b, std::string_view value) {
    datacube::append_be16(b, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(b, value);
}
std::string text(datacube::Reader& reader, std::size_t maximum) {
    const auto size = reader.read_be16("text length");
    require(size <= maximum, "VIEW_BINDINGS_INVALID", "selector text exceeds bound");
    return datacube::octets_text(reader.read_exact(size, "text"), "text", true);
}
void put_digest(Bytes& b, const Digest& value) { datacube::append_octets(b, value.octets); }
Digest get_digest(datacube::Reader& reader) {
    Digest value{};
    const auto b = reader.read_exact(value.octets.size(), "digest");
    std::copy(b.begin(), b.end(), value.octets.begin());
    return value;
}
void optional_digest(Bytes& b, const std::optional<Digest>& value) {
    datacube::append_u8(b, value ? 1U : 0U);
    if (value) put_digest(b, *value);
}
std::optional<Digest> optional_digest(datacube::Reader& reader) {
    const auto flag = reader.read_u8("optional digest");
    require(flag <= 1U, "VIEW_BINDINGS_INVALID", "invalid optional marker");
    return flag ? std::optional<Digest>(get_digest(reader)) : std::nullopt;
}
void filters(Bytes& b, const ViewBindings& q) {
    text(b, q.view); text(b, q.presence); text(b, q.grant); text(b, q.envelope);
    optional_digest(b, q.instance); optional_digest(b, q.grant_digest);
    optional_digest(b, q.binding_digest); optional_digest(b, q.lineage_digest);
}
std::string hex(const Digest& value) { return json_string(datacube::hex_lower(value)); }
std::string boolean(bool value) { return value ? "true" : "false"; }
bool valid_optional(const std::optional<Digest>& value) { return !value || !digest_is_zero(*value); }
} // namespace

void validate_view_bindings(const ViewBindings& q) {
    require(valid_generation_id(q.view) && (q.grant.empty() || valid_generation_id(q.grant)) &&
        (q.presence == "all" || q.presence == "configured" || q.presence == "historical") &&
        (q.envelope == "all" || q.envelope == "nse1" || q.envelope == "nse2") &&
        valid_optional(q.instance) && valid_optional(q.grant_digest) && valid_optional(q.binding_digest) &&
        valid_optional(q.lineage_digest) && valid_optional(q.selection) &&
        !(q.envelope == "nse1" && q.lineage_digest) && q.offset <= 256U &&
        q.limit >= 1U && q.limit <= 32U && q.maximum_bytes >= 2048U && q.maximum_bytes <= 60000U,
        "VIEW_BINDINGS_INVALID", "invalid exact selector or page limit");
    require(q.offset == 0U || q.selection, "VIEW_BINDINGS_SELECTION_REQUIRED", "continuation requires exact selection");
}
Bytes encode_view_bindings(const ViewBindings& q) {
    validate_view_bindings(q);
    Bytes b; datacube::append_text(b, "VBI1"); filters(b, q);
    datacube::append_be32(b, q.offset); datacube::append_be32(b, q.limit);
    datacube::append_be32(b, q.maximum_bytes); optional_digest(b, q.selection);
    return b;
}
ViewBindings decode_view_bindings(datacube::OctetView b) {
    try {
        datacube::Reader reader(b, "view bindings");
        require(datacube::octets_text(reader.read_exact(4U, "magic"), "magic", true) == "VBI1",
            "VIEW_BINDINGS_INVALID", "unknown format");
        ViewBindings q; q.view = text(reader, 64U); q.presence = text(reader, 16U);
        q.grant = text(reader, 64U); q.envelope = text(reader, 8U);
        q.instance = optional_digest(reader); q.grant_digest = optional_digest(reader);
        q.binding_digest = optional_digest(reader); q.lineage_digest = optional_digest(reader);
        q.offset = reader.read_be32("offset"); q.limit = reader.read_be32("limit");
        q.maximum_bytes = reader.read_be32("byte limit"); q.selection = optional_digest(reader);
        reader.require_eof("view bindings"); validate_view_bindings(q); return q;
    } catch (const datacube::Failure&) {
        app_fail("VIEW_BINDINGS_INVALID", "malformed or truncated view binding request");
    }
}

std::string NodeState::view_bindings(const ViewBindings& q, const RuntimeConfig& cfg,
    std::uint32_t uid, std::chrono::steady_clock::time_point deadline) const {
    validate_view_bindings(q);
    require(cfg.format_version >= 17U, "SOURCE_VIEW_POLICY_VERSION_REQUIRED", "binding inspection requires V17 or newer");
    require(local_control_allows(cfg.local_control, uid, LocalControlClass::source_import),
        "LOCAL_CONTROL_CLASS_DENIED", "current explicit SOURCE_IMPORT required");
    const auto configuration = runtime_configuration_digest(canonical_runtime_config(cfg));
    std::lock_guard<std::mutex> lock(mutex_);
    require(!poisoned_, "STATE_UNAVAILABLE", "writer requires restart");
    const auto check_time = [&]() {
        require(std::chrono::steady_clock::now() < deadline, "VIEW_BINDINGS_DEADLINE", "binding inspection deadline exceeded");
    };
    check_time(); SubmissionWork work; SubmissionWorkScope measured(work);
    const auto retained = retained_source_views_.find({uid, q.view});
    std::string view_account = "null";
    std::vector<std::string> selected;
    std::size_t retained_total = 0U, configured_total = 0U, bindings_examined = 0U;
    if (retained != retained_source_views_.end()) {
        const auto& entry = retained->second;
        const auto& rule = entry.rule;
        require(rule.uid == uid && rule.id == q.view && entry.bindings.size() <= 256U &&
            entry.binding_first_events.size() == entry.bindings.size(), "STATE_INDEX_CORRUPT", "invalid retained binding registry");
        const auto active = std::find_if(cfg.source_views.rules.begin(), cfg.source_views.rules.end(),
            [&](const auto& item) { return item.id == q.view; });
        require(active == cfg.source_views.rules.end() || (active->uid == uid && active->digest == rule.digest),
            "STATE_INDEX_CORRUPT", "active view differs from retained identity");
        const auto* key = find_peer_generation(cfg, rule.provider, rule.generation);
        const auto schedule = import_schedules_.find(q.view);
        const bool retired = schedule != import_schedules_.end() && schedule->second.state == "RETIRED";
        const auto event_json = [&](std::uint64_t ordinal) {
            require(ordinal > 0U && ordinal <= configuration_events_.size(), "STATE_INDEX_CORRUPT", "missing binding configuration event");
            const auto& event = configuration_events_[static_cast<std::size_t>(ordinal - 1U)];
            require(event.kind != "REJECTED", "STATE_INDEX_CORRUPT", "pin attributed to rejected configuration");
            return "{\"ordinal\":" + std::to_string(ordinal) + ",\"generation\":" + json_string(event.generation) +
                ",\"digest\":" + hex(event.digest) + "}";
        };
        // Current membership uses validated canonical policy, never historical
        // configuration reparsing or live provider/subscription inference.
        std::map<std::string, const SourceViewBinding*> current;
        for (const auto& binding : cfg.source_views.bindings) {
            if (binding.view != q.view) continue;
            const auto old = entry.bindings.find(binding.grant);
            require(old != entry.bindings.end() && old->second.digest == binding.digest,
                "STATE_INDEX_CORRUPT", "active binding not retained");
            current.emplace(binding.grant, &binding);
        }
        retained_total = entry.bindings.size(); configured_total = current.size();
        view_account = "{\"id\":" + json_string(rule.id) + ",\"manager_uid\":" + std::to_string(uid) +
            ",\"view_digest\":" + hex(rule.digest) + ",\"presence\":" +
            json_string(active == cfg.source_views.rules.end() ? "HISTORICAL" : "CONFIGURED") +
            ",\"lifecycle\":" + json_string(retired ? "RETIRED" : "ACTIVE") +
            ",\"provider\":" + json_string(rule.provider) + ",\"provider_generation\":" + json_string(rule.generation) +
            ",\"provider_spki_sha256\":" + hex(entry.provider_spki) + ",\"provider_generation_state\":" +
            (key ? json_string(key_generation_state_name(key->state)) : "null") +
            ",\"provider_pin_matches\":" + boolean(key && key->spki_sha256 == entry.provider_spki) +
            ",\"source_author_uid_claim\":" + std::to_string(rule.author_uid) +
            ",\"source_scope\":" + json_string(rule.source_scope) + ",\"target_scope\":" + json_string(rule.target_scope) +
            ",\"first_accepted_configuration\":" + event_json(entry.first_configuration_event) +
            ",\"target_reserved\":true}";
        for (const auto& [grant, binding] : entry.bindings) {
            check_time(); ++bindings_examined;
            const bool present = current.contains(grant);
            if ((!q.grant.empty() && q.grant != grant) ||
                (q.presence != "all" && q.presence != (present ? "configured" : "historical")) ||
                (q.envelope != "all" && q.envelope != (binding.lineage_digest ? "nse2" : "nse1")) ||
                (q.instance && *q.instance != binding.instance) ||
                (q.grant_digest && *q.grant_digest != binding.grant_digest) ||
                (q.binding_digest && *q.binding_digest != binding.digest) ||
                (q.lineage_digest && q.lineage_digest != binding.lineage_digest)) continue;
            const auto first = entry.binding_first_events.find(grant);
            require(first != entry.binding_first_events.end(), "STATE_INDEX_CORRUPT", "missing first binding provenance");
            selected.push_back("{\"ordinal\":" + std::to_string(selected.size() + 1U) + ",\"view\":" + json_string(q.view) +
                ",\"grant\":" + json_string(grant) + ",\"subscription_instance\":" + hex(binding.instance) +
                ",\"grant_digest\":" + hex(binding.grant_digest) + ",\"lineage_digest\":" +
                (binding.lineage_digest ? hex(*binding.lineage_digest) : "null") +
                ",\"binding_digest\":" + hex(binding.digest) + ",\"envelope\":" + json_string(binding.lineage_digest ? "NSE2" : "NSE1") +
                ",\"presence\":" + json_string(present ? "CONFIGURED" : "HISTORICAL") +
                ",\"first_accepted_configuration\":" + event_json(first->second) + "}");
        }
    }
    Bytes b; datacube::append_text(b, "NATRAV_OVERLAY_VIEW_BINDINGS_SELECTION_V1"); datacube::append_u8(b, 0U);
    text(b, node_id_); datacube::append_be32(b, uid); put_digest(b, configuration); filters(b, q);
    datacube::append_be32(b, static_cast<std::uint32_t>(view_account.size())); datacube::append_text(b, view_account);
    datacube::append_be32(b, static_cast<std::uint32_t>(selected.size())); auto root = datacube::sha256(b);
    for (const auto& row : selected) {
        check_time(); Bytes link; datacube::append_text(link, "NATRAV_OVERLAY_VIEW_BINDINGS_ROW_V1"); datacube::append_u8(link, 0U);
        put_digest(link, root); datacube::append_be32(link, static_cast<std::uint32_t>(row.size())); datacube::append_text(link, row);
        root = datacube::sha256(link);
    }
    require(!q.selection || *q.selection == root, "VIEW_BINDINGS_SELECTION_MISMATCH", "selected bindings, lifecycle, or context changed");
    require(q.offset <= selected.size(), "VIEW_BINDINGS_INVALID", "offset exceeds selected bindings");
    std::size_t visited = 0U, returned = 0U; std::string rows;
    const auto render = [&](std::string_view content, std::size_t count) {
        const auto next = q.offset + count;
        return std::string("{\"format\":\"NATRAV_OVERLAY_VIEW_BINDINGS_V1\",\"ok\":true,\"node\":") + json_string(node_id_) +
            ",\"manager_uid\":" + std::to_string(uid) + ",\"authorized_configuration_digest\":" + hex(configuration) +
            ",\"requested_view\":" + json_string(q.view) + ",\"view\":" + view_account +
            ",\"retained_binding_count\":" + std::to_string(retained_total) + ",\"configured_binding_count\":" + std::to_string(configured_total) +
            ",\"selected_total\":" + std::to_string(selected.size()) + ",\"selection_digest\":" + hex(root) +
            ",\"offset\":" + std::to_string(q.offset) + ",\"returned\":" + std::to_string(count) +
            ",\"next_offset\":" + std::to_string(next) + ",\"has_more\":" + boolean(next < selected.size()) +
            ",\"sequence_semantics\":\"OWNED_VIEW_FILTERED_GRANT_ORDER\",\"observation\":\"ONE_STATE_MUTEX_CURRENT_BINDINGS\"" +
            ",\"verification\":\"RECIPIENT_ACCEPTED_PINS_NOT_PROVIDER_LEASE_PROOF\",\"freshness\":\"NOT_ESTABLISHED\"" +
            ",\"payloads_included\":false,\"reason_text_included\":false,\"import_decisions_included\":false" +
            ",\"work\":{\"scope\":\"LOCKED_VIEW_BINDINGS\",\"owned_bindings_examined\":" + std::to_string(bindings_examined) +
            ",\"selected_rows_hashed\":" + std::to_string(selected.size()) + ",\"page_rows_visited\":" + std::to_string(visited) +
            ",\"source_records_read\":0,\"payload_bytes_copied\":0,\"histories_serialized\":0,\"historical_configurations_parsed\":0" +
            ",\"snapshot_calls\":" + std::to_string(work.snapshot_calls) +
            ",\"logical_bytes_serialized\":" + std::to_string(work.snapshot_logical_bytes) + "},\"records\":[" + std::string(content) + "]}";
    };
    for (std::size_t i = q.offset; i < selected.size() && returned < q.limit; ++i) {
        check_time(); ++visited;
        const auto candidate = rows + (returned ? "," : "") + selected[i];
        if (render(candidate, returned + 1U).size() + kPrincipalReserve > q.maximum_bytes) {
            require(returned != 0U, "VIEW_BINDINGS_PAGE_TOO_SMALL", "first complete row exceeds byte budget"); break;
        }
        rows = candidate; ++returned;
    }
    auto out = render(rows, returned);
    require(out.size() + kPrincipalReserve <= q.maximum_bytes, "VIEW_BINDINGS_PAGE_TOO_SMALL", "metadata exceeds byte budget");
    check_time(); return out;
}
} // namespace natrav_overlay
