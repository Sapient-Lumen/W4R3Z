#pragma once

#include "custody_state.hpp"

#include <string_view>

namespace natrav_overlay {

inline constexpr std::string_view kCustodyBundleFeature =
    "FINITE_CUSTODY_BUNDLE_V1";
inline constexpr std::size_t kCustodyBundleLimit = 72'000U;

struct CustodyBundle final {
    CustodyEnvelope envelope;
    datacube::Octets capsule;
    std::vector<CustodyGrantReference> grants;
    std::vector<datacube::Octets> records;
};

[[nodiscard]] datacube::Octets encode_custody_bundle(
    const CustodyBundle& bundle);
[[nodiscard]] CustodyBundle decode_custody_bundle(
    datacube::OctetView bytes);
[[nodiscard]] datacube::Digest32 custody_bundle_envelope_sha256(
    const CustodyBundle& bundle);

} // namespace natrav_overlay
