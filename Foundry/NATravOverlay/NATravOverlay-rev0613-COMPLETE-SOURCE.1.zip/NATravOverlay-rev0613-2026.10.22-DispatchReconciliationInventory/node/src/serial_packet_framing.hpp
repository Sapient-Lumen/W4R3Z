#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <vector>

namespace natrav_overlay::serial_packet {

inline constexpr char kMarker[] = "FRAMED_SERIAL_PACKET_ADAPTER_V1";
inline constexpr std::size_t kMaximumMtu = 4096U;
inline constexpr std::size_t kOverhead = 22U;
inline constexpr std::size_t kPumpBytes = 4096U;
using Bytes = std::vector<std::uint8_t>;

// NSP1 is carrier framing, not identity, authentication or delivery evidence.
struct Settings final {
    std::size_t mtu{512U};
    std::uint64_t link{1U};
    std::uint32_t epoch{1U};
    std::uint64_t frame_timeout_ms{5000U};
    void validate() const;
};

[[nodiscard]] std::uint32_t crc32(std::span<const std::uint8_t> bytes) noexcept;
// Exact upper bound for one canonical escaped NSP1 frame, including both
// delimiters. This is a line-capacity bound, not a delivery guarantee.
[[nodiscard]] std::size_t maximum_wire_bytes(std::size_t packet_bytes);
// Minimum whole-millisecond serialization budget for the worst-case escaped
// frame at an explicitly configured line rate. Flow-control stalls and driver
// latency remain outside this lower bound.
[[nodiscard]] std::uint64_t minimum_transmit_time_ms(
    std::size_t packet_bytes, std::uint32_t baud, std::uint8_t bits_per_character);
[[nodiscard]] Bytes encode(const Settings& settings, std::span<const std::uint8_t> packet);

struct DecodeCounters final {
    std::uint64_t accepted{0U};
    std::uint64_t rejected{0U};
    std::uint64_t expired{0U};
    std::uint64_t noise_bytes{0U};
};

// At most MTU+22 unescaped bytes; no search/backtracking or unbounded garbage
// retention. One consume() step performs constant work except at an end flag,
// where checksum work is bounded by the declared MTU.
class Decoder final {
public:
    explicit Decoder(Settings settings);
    [[nodiscard]] std::optional<Bytes> consume(std::uint8_t byte, std::uint64_t now_ms);
    void expire(std::uint64_t now_ms) noexcept;
    [[nodiscard]] const DecodeCounters& counters() const noexcept { return counters_; }
    [[nodiscard]] std::size_t buffered_bytes() const noexcept { return raw_.size(); }
private:
    void reject() noexcept;
    [[nodiscard]] std::optional<Bytes> finish();
    Settings settings_;
    Bytes raw_{};
    DecodeCounters counters_{};
    bool active_{false};
    bool escaping_{false};
    bool started_{false};
    std::uint64_t started_ms_{0U};
};

}  // namespace natrav_overlay::serial_packet
