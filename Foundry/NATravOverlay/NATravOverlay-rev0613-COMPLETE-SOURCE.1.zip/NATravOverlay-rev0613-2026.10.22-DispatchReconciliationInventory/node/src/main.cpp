#include "backup.hpp"
#include "serial_packet_adapter.hpp"
#include "removable_media_packet_adapter.hpp"
#include "state_auth.hpp"
#include "state_recovery.hpp"
#include "state_head_custody.hpp"
#include "custody_promotion.hpp"
#include "daemon.hpp"
#include "identity.hpp"
#include "handoff_runtime.hpp"
#include "custody_runtime.hpp"
#include "custody_session_service.hpp"
#include "node.hpp"
#include "relocation.hpp"

#include <algorithm>
#include <array>
#include <csignal>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <iostream>
#include <map>
#include <limits>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <utility>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/sha.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>

#include <arpa/inet.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/file.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cctype>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>



namespace natrav_overlay {
namespace {

class Arguments final {
public:
    Arguments(const int argc, char* argv[], const int begin) {
        for (int index = begin; index < argc; index += 2) {
            const std::string key = argv[index];
            if (!key.starts_with("--")) {
                app_fail("INVALID_ARGUMENT", "expected --option, got " + key);
            }
            if (index + 1 >= argc) {
                app_fail("INVALID_ARGUMENT", "missing value for " + key);
            }
            const std::string value = argv[index + 1];
            if (!values_.emplace(key, value).second) {
                app_fail("INVALID_ARGUMENT", "duplicate option " + key);
            }
        }
    }

    [[nodiscard]] const std::string& require(const std::string& key) const {
        const auto found = values_.find(key);
        if (found == values_.end()) {
            app_fail("MISSING_ARGUMENT", key);
        }
        return found->second;
    }

    [[nodiscard]] std::string get(
        const std::string& key,
        std::string default_value) const {
        const auto found = values_.find(key);
        return found == values_.end() ? std::move(default_value) : found->second;
    }

    [[nodiscard]] bool contains(const std::string& key) const {
        return values_.contains(key);
    }

    void erase(const std::string& key) { values_.erase(key); }

    void require_only(const std::set<std::string>& allowed) const {
        for (const auto& [key, value] : values_) {
            static_cast<void>(value);
            if (!allowed.contains(key)) {
                app_fail("UNKNOWN_ARGUMENT", key);
            }
        }
    }

private:
    std::map<std::string, std::string> values_;
};

[[nodiscard]] IoOptions io_options(const Arguments& args) {
    IoOptions options;
    options.timeout = parse_milliseconds(
        args.get("--deadline-ms", "3000"),
        "deadline-ms", 1U, 60'000U);
    options.read_quantum = static_cast<std::size_t>(parse_u64(
        args.get("--read-quantum", "4096"),
        "read-quantum", 1U, 65'536U));
    options.write_quantum = static_cast<std::size_t>(parse_u64(
        args.get("--write-quantum", "4096"),
        "write-quantum", 1U, 65'536U));
    options.maximum_received_bytes = static_cast<std::size_t>(parse_u64(
        args.get("--receive-limit", "131080"),
        "receive-limit", 4U, 1'048'576U));
    validate_io_options(options);
    return options;
}

[[nodiscard]] std::uint64_t journal_limit(const Arguments& args) {
    return parse_u64(
        args.get("--max-journal-bytes", "67108864"),
        "max-journal-bytes", 1'024U, 1'073'741'824U);
}

[[nodiscard]] bool yes_no_option(
    const Arguments& args,
    const std::string& key,
    const bool default_value) {
    const auto value = args.get(key, default_value ? "yes" : "no");
    if (value == "yes") { return true; }
    if (value == "no") { return false; }
    app_fail("INVALID_ARGUMENT", key + " must be yes or no");
}

[[nodiscard]] CorrelatedStopAuditOptions correlated_stop_audit_options(
    const Arguments& args, StateAuditOptions source) {
    const bool has_request_id = args.contains("--request-id");
    const bool has_correlation = args.contains("--correlation");
    if (has_request_id == has_correlation) {
        app_fail("CORRELATED_STOP_AUDIT_SELECTION_INVALID",
            "provide exactly one of --request-id or an explicit correlated request shape");
    }
    CorrelatedStopAuditOptions options{
        .source = std::move(source),
        .request_id = {},
        .request_shape = std::nullopt,
        .maximum_matches = static_cast<std::uint32_t>(parse_u64(
            args.get("--max-matches", "64"), "maximum matches", 1U, 64U)),
        .maximum_json_bytes = static_cast<std::uint32_t>(parse_u64(
            args.get("--max-bytes", "60000"), "maximum bytes", 4'096U, 60'000U)),
    };
    if (has_request_id) {
        if (args.contains("--stop") || args.contains("--final-state-head") ||
            args.contains("--drain-deadline-ms") || args.contains("--reason")) {
            app_fail("CORRELATED_STOP_AUDIT_SELECTION_INVALID",
                "exact request ID cannot be mixed with request-shape fields");
        }
        options.request_id = parse_operation_id(args.require("--request-id"));
        return options;
    }
    if (!args.contains("--stop") || !args.contains("--final-state-head")) {
        app_fail("CORRELATED_STOP_AUDIT_SELECTION_INVALID",
            "explicit shape requires --stop and --final-state-head");
    }
    const auto stop = args.require("--stop");
    const bool final_state_head = yes_no_option(
        args, "--final-state-head", false);
    ControlRequest request;
    CorrelatedStopRequestShape shape{
        .operation = stop == "immediate" ? "IMMEDIATE" :
            stop == "drain" ? "DRAIN" : "",
        .final_state_head = final_state_head,
        .correlation = args.require("--correlation"),
        .request_bytes = 0U,
        .expected_command = {},
        .drain_deadline_ms = std::nullopt,
        .drain_reason = std::nullopt,
    };
    if (stop == "immediate") {
        if (args.contains("--drain-deadline-ms") || args.contains("--reason")) {
            app_fail("CORRELATED_STOP_AUDIT_SELECTION_INVALID",
                "immediate shape cannot contain drain fields");
        }
        request = ControlShutdown{
            .final_state_head = final_state_head,
            .correlation = shape.correlation,
        };
        shape.expected_command = final_state_head ?
            "SHUTDOWN_TERMINAL_CORRELATED" : "SHUTDOWN_CORRELATED";
    } else if (stop == "drain") {
        if (!args.contains("--drain-deadline-ms") || !args.contains("--reason")) {
            app_fail("CORRELATED_STOP_AUDIT_SELECTION_INVALID",
                "drain shape requires deadline and reason");
        }
        const auto drain_deadline = static_cast<std::uint32_t>(parse_u64(
            args.require("--drain-deadline-ms"), "drain-deadline-ms",
            1U, 600'000U));
        const auto reason = args.require("--reason");
        request = ControlDrainShutdown{
            .deadline_ms = drain_deadline,
            .reason = reason,
            .final_state_head = final_state_head,
            .correlation = shape.correlation,
        };
        shape.drain_deadline_ms = drain_deadline;
        shape.drain_reason = reason;
        shape.expected_command = final_state_head ?
            "DRAIN_SHUTDOWN_TERMINAL_CORRELATED" :
            "DRAIN_SHUTDOWN_CORRELATED";
    } else {
        app_fail("CORRELATED_STOP_AUDIT_SELECTION_INVALID",
            "--stop must be immediate or drain");
    }
    const auto encoded = encode_control_request(request);
    options.request_id = control_request_id(encoded);
    shape.request_bytes = encoded.size();
    options.request_shape = std::move(shape);
    return options;
}

[[nodiscard]] datacube::Octets payload(const Arguments& args) {
    const bool has_text = args.contains("--payload-text");
    const bool has_file = args.contains("--payload-file");
    const bool has_numeric=args.contains("--numeric-ticks")||args.contains("--numeric-unit")||args.contains("--numeric-scale");
    if (static_cast<unsigned>(has_text)+static_cast<unsigned>(has_file)+static_cast<unsigned>(has_numeric)!=1U) {
        app_fail("INVALID_ARGUMENT",
            "provide exactly one of --payload-text, --payload-file, or --numeric-ticks/--numeric-unit/--numeric-scale");
    }
    if(has_numeric){
        const auto input=args.require("--numeric-ticks");std::int64_t ticks=0;
        const auto parsed=std::from_chars(input.data(),input.data()+input.size(),ticks);
        if(parsed.ec!=std::errc{}||parsed.ptr!=input.data()+input.size()||std::to_string(ticks)!=input){app_fail("NUMERIC_VALUE_RANGE","ticks must be a canonical signed decimal integer");}
        NumericDefinition definition;definition.unit=args.require("--numeric-unit");
        definition.scale=static_cast<std::uint8_t>(parse_u64(args.require("--numeric-scale"),"numeric scale",0U,9U));
        return encode_numeric_observation(definition,ticks);
    }
    if (has_text) {
        auto bytes = datacube::text_octets(args.require("--payload-text"));
        if (bytes.size() > kMaximumEvidencePayloadBytes) {
            app_fail("PAYLOAD_TOO_LARGE", "payload text exceeds 60000 bytes");
        }
        return bytes;
    }
    return read_payload_file(
        std::filesystem::path(args.require("--payload-file")),
        kMaximumEvidencePayloadBytes);
}

[[nodiscard]] SendOptions send_options(
    const Arguments& args,
    const bool correction) {
    args.require_only({
        "--state", "--node", "--peer", "--connect", "--recipient",
        "--scope", "--operation", "--corrects", "--payload-text",
        "--payload-file", "--numeric-ticks", "--numeric-unit", "--numeric-scale", "--deadline-ms", "--read-quantum",
        "--write-quantum", "--receive-limit", "--max-journal-bytes",
    });
    const std::string local = args.require("--node");
    const std::string peer = args.require("--peer");
    const std::string recipient = args.get("--recipient", peer);
    EvidenceRecord record{
        .operation_id = parse_operation_id(args.require("--operation")),
        .issuer = local,
        .recipient = recipient,
        .scope = args.require("--scope"),
        .corrects = std::nullopt,
        .payload = payload(args),
    };
    if (correction) {
        record.corrects = parse_operation_id(args.require("--corrects"));
    } else if (args.contains("--corrects")) {
        app_fail("INVALID_ARGUMENT", "--corrects is valid only for correct");
    }
    validate_evidence_record(record);
    return SendOptions{
        .state_directory = std::filesystem::path(args.require("--state")),
        .local_node = local,
        .expected_peer = peer,
        .locator = parse_tcp_transport_locator(args.require("--connect"), false),
        .record = std::move(record),
        .io = io_options(args),
        .maximum_journal_bytes = journal_limit(args),
    };
}

[[nodiscard]] EvidenceRecord control_record(
    const Arguments& args,
    const bool correction) {
    args.require_only({
        "--control", "--node", "--peer", "--scope", "--operation",
        "--corrects", "--payload-text", "--payload-file", "--numeric-ticks", "--numeric-unit", "--numeric-scale", "--deadline-ms",
        "--read-quantum", "--write-quantum", "--receive-limit",
    });
    EvidenceRecord record{
        .operation_id = parse_operation_id(args.require("--operation")),
        .issuer = args.require("--node"),
        .recipient = args.require("--peer"),
        .scope = args.require("--scope"),
        .corrects = std::nullopt,
        .payload = payload(args),
    };
    if (correction) {
        record.corrects = parse_operation_id(args.require("--corrects"));
    } else if (args.contains("--corrects")) {
        app_fail("INVALID_ARGUMENT", "--corrects is valid only for revise");
    }
    validate_evidence_record(record);
    return record;
}

[[nodiscard]] EvidenceRecord action_control_record(const Arguments& args) {
    args.require_only({
        "--control", "--node", "--peer", "--operation", "--amount",
        "--defer-ms", "--deadline-ms", "--read-quantum",
        "--write-quantum", "--receive-limit",
    });
    const CounterAddRequest request{
        .amount = parse_u64(
            args.require("--amount"), "amount", 1U, 1'000'000'000'000ULL),
        .defer_ms = static_cast<std::uint32_t>(parse_u64(
            args.get("--defer-ms", "0"), "defer-ms", 0U, 2'592'000'000ULL)),
    };
    EvidenceRecord record{
        .operation_id = parse_operation_id(args.require("--operation")),
        .issuer = args.require("--node"),
        .recipient = args.require("--peer"),
        .scope = std::string(kCounterAddActionScope),
        .corrects = std::nullopt,
        .payload = encode_counter_add_request(request),
    };
    validate_evidence_record(record);
    return record;
}

[[nodiscard]] int print_control_response(const ControlResponse& response) {
    std::cout << response.json << '\n';
    return response.ok ? 0 : 3;
}

[[nodiscard]] int print_state_conditioned_response(
    std::string response, const int status = 0) {
    recheck_process_state_head_custody_constraint(
        StateHeadCustodyRecheckPoint::successful_command);
    std::cout << response << '\n';
    return status;
}

[[nodiscard]] FlushOptions flush_options(const Arguments& args) {
    args.require_only({
        "--state", "--node", "--peer", "--connect",
        "--deadline-ms", "--read-quantum", "--write-quantum",
        "--receive-limit", "--max-journal-bytes", "--max-records",
    });
    return FlushOptions{
        .state_directory = std::filesystem::path(args.require("--state")),
        .local_node = args.require("--node"),
        .expected_peer = args.require("--peer"),
        .locator = parse_tcp_transport_locator(args.require("--connect"), false),
        .io = io_options(args),
        .maximum_journal_bytes = journal_limit(args),
        .maximum_records = static_cast<std::size_t>(parse_u64(
            args.get("--max-records", "1000"),
            "max-records", 1U, 100'000U)),
    };
}

void usage(std::ostream& out) {
    out <<
        "NATravOverlay native C++ node\n"
        "\n"
        "Commands:\n"
        "  source-view-retirement-status --control PATH --view ID\n"
        "  source-view-retire --control PATH --view ID --expected-revision N\n"
        "      --view-digest HEX64 --configuration-digest HEX64 --final-state-digest HEX64\n"
        "      --deferred require-empty|retain --reason TEXT\n"
        "  source-view-decisions --control PATH --view ID\n"
        "     [--after-revision N] [--through-revision N --history-digest HEX64]\n"
        "     [--limit 1..32] [--max-bytes 2048..60000] [socket limits]\n"
        "  source-view-retry --control PATH --view ID --expected-revision N\n"
        "     --decision-revision N --decision-digest HEX64 --operation HEX64\n"
        "     --view-digest HEX64 --configuration-digest HEX64 --reason TEXT\n"
        "     [socket limits]\n"
        "  serial-packet-adapter --serial LOCATOR --mtu N --link HEX16 --epoch N\n"
        "      --queue-bytes N --queue-frames N --frame-timeout-ms N --io-quantum N\n"
        "      (supervised NAPA0001 descriptor 3 only; no node authority)\n"
        "  removable-media-packet-adapter --inbound DIR --inbound-object DEV:INO\n"
        "      --outbound DIR --outbound-object DEV:INO --quarantine DIR\n"
        "      --quarantine-object DEV:INO --mtu N --link HEX16 --epoch N\n"
        "      --queue-bytes N --queue-files N --bundle-lifetime-ms N\n"
        "      --poll-interval-ms N --scan-entries N --directory-entry-limit N\n"
        "      --quarantine-bytes N --quarantine-files N --duplicate-window N\n"
        "      (supervised NAPA0001 descriptor 3 only; no node authority)\n"
        "  run --config FILE\n"
        "  config-check --config FILE\n"
        "  config-activate --control PATH --candidate FILE --reason TEXT [socket limits]\n"
        "  config-rollback --control PATH --generation ID --reason TEXT [socket limits]\n"
        "  identity-init --directory DIR --node ID --generation ID\n"
        "                [--validity-days N]\n"
        "  backup-key-init --output FILE --generation ID\n"
        "  backup-reencrypt --input FILE --output FILE --decrypt-key OLD --encrypt-key NEW\n"
        "                   [--node ID --generation ID --trusted-cert FILE --require-signature yes|no]\n"
        "  backup-export --state DIR --node ID --generation ID --output FILE\n"
        "                [--sign-key FILE --sign-cert FILE] [--encrypt-key FILE] [--max-journal-bytes N]\n"
        "  backup-verify --input FILE [--node ID] [--generation ID]\n"
        "                [--trusted-cert FILE] [--require-signature yes|no]\n"
        "  backup-restore --input FILE --destination DIR --node ID --generation ID\n"
        "                 [--trusted-cert FILE] [--require-signature yes|no]\n"
        "  Backup verify/restore: [--decrypt-key FILE] [--require-encryption yes|no]\n"
        "  state-relocate --state DIR --node ID --candidate FILE --reason TEXT\n"
        "                 [--max-journal-bytes N]\n"
        "  submit --control PATH --node ID --peer ID --scope S --operation HEX64\n"
        "         (--payload-text T | --payload-file F) [socket limits]\n"
        "     Numeric payload alternative: --numeric-ticks INTEGER --numeric-unit UNIT --numeric-scale 0..9\n"
        "  revise (submit options) --corrects HEX64\n"
        "  evidence-author --control PATH --node ID --scope S --operation HEX64\n"
        "    --payload-text TEXT | --payload-file FILE | --numeric-ticks N --numeric-unit U --numeric-scale N\n"
        "  evidence-amend (evidence-author options) --corrects HEX64\n"
        "  action-submit --control PATH --node ID --peer ID --operation HEX64\n"
        "                --amount N [--defer-ms N] [socket limits]\n"
        "  action-cancel --control PATH --action HEX64 --reason TEXT [--expected-state HEX64 --expected-configuration HEX64]\n"
        "                [socket limits]\n"
        "  projection-enable --control PATH --consumer NAME --expected-generation N\n"
        "    --reason TEXT [--max-pages N] [--min-interval-ms N]\n"
        "  projection-pause --control PATH --consumer NAME --expected-generation N --reason TEXT\n"
        "  projection-schedule-status --control PATH --consumer NAME\n"
        "  projection-create --control PATH --consumer NAME --issuer ID --scope S\n"
        "     --reason TEXT [--limit 1..128] [--max-admissions 1..1000000] [socket limits]\n"
        "     [--definition NUMERIC_SUMMARY_V1 --unit UNIT --scale 0..9 --max-abs-sum N]\n"
        "  projection-process --control PATH --consumer NAME --batch HEX64 [socket limits]\n"
        "  projection-status --control PATH --consumer NAME [socket limits]\n"
        "  projection-rebuild --control PATH --consumer NAME --expected-revision N\n"
        "     --reason TEXT [socket limits]\n"
        "  publication-channel-create --control PATH --channel NAME --consumer NAME\n"
        "     --projection-instance HEX64 --peer ID --scope S --reason TEXT\n"
        "     [--max-publications 1..128] [socket limits]\n"
        "  publication-channel-publish --control PATH --channel NAME --instance HEX64\n"
        "     --expected-channel-revision N --expected-projection-revision N\n"
        "     --expected-position N --result-digest HEX64 [socket limits]\n"
        "  publication-channel-status --control PATH --channel NAME [socket limits]\n"
        "  publication-channel-auto-enable --control PATH --channel NAME --instance HEX64\n"
        "     --expected-channel-revision N --expected-schedule-revision N\n"
        "     --expected-grant-generation N --reason TEXT\n"
        "     [--max-automatic-publications 1..10000] [--min-interval-ms 10..60000]\n"
        "     [socket limits]\n"
        "  publication-channel-auto-pause --control PATH --channel NAME --instance HEX64\n"
        "     --expected-channel-revision N --expected-schedule-revision N\n"
        "     --expected-grant-generation N --reason TEXT [socket limits]\n"
        "  publication-channel-auto-status --control PATH --channel NAME [socket limits]\n"
        "  publication-channel-new-epoch --control PATH --channel NAME --instance HEX64\n"
        "     --expected-channel-revision N --expected-epoch N --terminal-operation HEX64\n"
        "     --terminal-outcome rejected|cancelled|expired\n"
        "     --expected-projection-revision N --expected-position N --result-digest HEX64\n"
        "     --reason TEXT [socket limits]\n"
        "  publication-channel-retire --control PATH --channel NAME --instance HEX64\n"
        "     --expected-channel-revision N --pending require-empty|cancel --reason TEXT\n"
        "  projection-publish --control PATH --consumer NAME --instance HEX64\n"
        "     --expected-revision N --expected-position N --result-digest HEX64\n"
        "     --peer ID --scope S [socket limits]\n"
        "  consumer-retire --control PATH --consumer NAME --instance HEX64\n"
        "    --expected-revision N --schedule-revision N --pending require-empty|abandon --reason TEXT\n"
        "  consumer-retirement-status --control PATH --consumer NAME\n"
        "  consumer-create --control PATH --consumer NAME --reason TEXT\n"
        "                  [--start beginning|now] [--issuer ID] [--scope S]\n"
        "                  [--limit N] [--max-bytes N] [--payload yes|no] [--payload-length N]\n"
        "  consumer-read --control PATH --consumer NAME\n"
        "  consumer-ack --control PATH --consumer NAME --batch HEX64\n"
        "  consumer-status --control PATH --consumer NAME\n"
        "  consumer-reset --control PATH --consumer NAME --expected-revision N\n"
        "                 --start beginning|now --reason TEXT\n"
        "  evidence-feed --control PATH [--start beginning|now] [--issuer ID] [--scope S]\n"
        "     [--limit 1..128] [--max-bytes 4096..60000] [--payload yes|no]\n"
        "     [--payload-length 1..16384] [--cursor TOKEN] [socket limits]\n"
        "  source-view-bindings --control PATH --view ID [--presence all|configured|historical]\n"
        "    [--grant ID] [--instance HEX64] [--grant-digest HEX64] [--binding-digest HEX64]\n"
        "    [--lineage-digest HEX64] [--envelope all|nse1|nse2] [--offset N --selection HEX64]\n"
        "    [--limit 1..32] [--max-bytes 2048..60000]\n"
        "  source-view-inventory --control PATH [--presence all|configured|historical]\n"
        "    [--lifecycle all|active|retired] [--schedule all|never-enabled|enabled|paused|blocked|exhausted|retired]\n"
        "    [--view ID] [--provider ID] [--generation ID] [--author-uid UID] [--source-scope SCOPE] [--target-scope SCOPE]\n"
        "    [--offset N --selection HEX64] [--limit 1..16] [--max-bytes 2048..60000]\n"
        "  source-subscription-inventory --control PATH [--lifecycle all|active|retired]\n"
        "    [--lease all|unleased|open|withdrawn|expired] [--schedule STATE] [--outcome STATE]\n"
        "    [--grant ID] [--instance HEX64] [--peer ID] [--scope SCOPE] [--author-uid UID]\n"
        "    [--offset N --selection HEX64] [--limit 1..16] [--max-bytes 2048..60000]\n"
        "  publication-channel-inventory --control PATH [--lifecycle all|active|retired]\n"
        "    [--schedule all|none|enabled|paused|blocked|exhausted] [--outcome all|none|pending|acked|rejected|cancelled|expired]\n"
        "    [--name NAME] [--instance HEX64] [--projection NAME] [--peer NODE] [--scope SCOPE]\n"
        "    [--offset N --selection HEX64] [--limit 1..32] [--max-bytes 2048..60000]\n"
        "  consumer-inventory --control PATH [--kind all|consumer|projection|metadata|numeric]\n"
        "    [--lifecycle all|active|retired] [--name NAME] [--instance HEX64] [--issuer ID] [--scope SCOPE]\n"
        "    [--offset N --selection HEX64] [--limit 1..32] [--max-bytes 2048..60000]\n"
        "  source-subscription-reconcile --control PATH --grant ID --instance HEX64 --expected-revision N\n"
        "    --state-digest HEX64 --terminal-digest HEX64 --source-operation HEX64\n"
        "    --delivery-operation HEX64 --receipt-digest HEX64 --reason TEXT\n"
        "  source-subscription-succeed --control PATH --grant ID --successor-lease ID\n"
        "    --predecessor-grant ID --predecessor-lease ID --instance HEX64\n"
        "    --expected-revision N --predecessor-state-digest HEX64 --expected-frontier N\n"
        "    --mapping-digest HEX64 --reason TEXT [socket limits]\n"
        "  source-subscription-create --control PATH --grant ID --reason TEXT [socket limits]\n"
        "  source-subscription-step --control PATH --grant ID --instance HEX64 --expected-revision N [socket limits]\n"
        "  source-subscription-status --control PATH --grant ID [--response-format legacy|compact] [socket limits]\n"
        "    All source-subscription commands accept --response-format legacy|compact.\n"
        "    succeed: --predecessor-selector SPSC1:HEX64 instead of --predecessor-state-digest.\n"
        "    reconcile: --state-selector SPSC1:HEX64 instead of --state-digest.\n"
        "  source-subscription-retire --control PATH --grant ID --instance HEX64\n"
        "     --expected-revision N --pending require-empty|retain --reason TEXT [socket limits]\n"
        "  source-subscription-auto-enable --control PATH --grant ID --instance HEX64\n"
        "     --expected-revision N --expected-schedule-revision N\n"
        "     --expected-grant-generation N --reason TEXT\n"
        "     [--max-automatic-steps 1..10000] [--min-interval-ms 10..60000] [socket limits]\n"
        "  source-subscription-auto-pause --control PATH --grant ID --instance HEX64\n"
        "     --expected-revision N --expected-schedule-revision N\n"
        "     --expected-grant-generation N --reason TEXT [socket limits]\n"
        "  source-subscription-auto-status --control PATH --grant ID [socket limits]\n"
        "  source-subscription-request --config FILE --provider ID --grant ID\n"
        "     --request-id HEX64 --reason TEXT [--lease-generation ID] [socket limits]\n"
        "  source-subscription-remote-status --config FILE --provider ID --grant ID\n"
        "     --request-id HEX64 [--lease-generation ID] [socket limits]\n"
        "  source-subscription-withdraw --config FILE --provider ID --grant ID\n"
        "     --request-id HEX64 --lease-generation ID --instance HEX64\n"
        "     --expected-revision N --reason TEXT [socket limits]\n"
        "  source-envelope-inspect --payload-file FILE\n"
        "  control-history --control PATH [--section decisions|lifecycle] [--ordinal N] [--uid UID|--request-id HEX64|--event N]\n"
        "    [--through N --prefix-digest HEX64 --offset N] [--limit N] [--max-bytes N]\n"
        "  configuration-history --control PATH [--section events|bindings] [--ordinal N] [--event N] [--offset N]\n"
        "    [--through N --prefix-digest HEX64] [--limit 1..64] [--max-bytes 2048..60000]\n"
        "  runtime-inventory --control PATH [--section peers|routes|keys|local-control|evidence-read|evidence-author|authorization|source-disclosure|source-views|source-bindings|configuration]\n"
        "    [--peer ID] [--id EXACT] [--uid N] [--offset N --selection HEX64] [--limit N] [--max-bytes N]\n"
        "  action-result-review --control PATH --request HEX64 --provider ID --scope SCOPE --candidate-count N --candidate-root HEX64 --request-binding HEX64 --expected-configuration HEX64 --reason TEXT\n"
        "  action-result-review-status --control PATH --review HEX64\n"
        "  action-result-review-history --control PATH --request HEX64 --provider ID --scope SCOPE [--review HEX64] [--limit 1..16] [--max-bytes 2048..60000] [--offset N --through N --prefix-digest HEX64]\n"
        "  action-result-discover --control PATH --request HEX64 --provider ID --scope SCOPE [--limit N] [--max-bytes N] [--cursor TOKEN]\n"
        "  action-result-query --control PATH --operation HEX64 --request HEX64 --provider ID --scope SCOPE [--max-bytes N]\n"
        "  action-query --control PATH [--action HEX64] [--issuer ID] [--state PENDING|EXECUTED|CANCELLED|EXPIRED]\n"
        "    [--limit 1..64] [--max-bytes 2048..60000] [--cursor TOKEN]\n"
        "  outbox-query --control PATH [--operation HEX64] [--peer ID] [--state PENDING|ACKED|REJECTED|CANCELLED|EXPIRED]\n"
        "    [--limit 1..64] [--max-bytes 4096..60000] [--history-limit 0..16] [--cursor TOKEN]\n"
        "  evidence-query --control PATH [--view current|history] [--issuer ID]\n"
        "     [--scope S] [--operation HEX64] [--limit 1..128] [--max-bytes 4096..60000]\n"
        "     [--payload yes|no] [--payload-offset N] [--payload-length 1..16384]\n"
        "     [--cursor TOKEN] [socket limits]\n"
        "  status --control PATH [--logical-digest yes|no] [socket limits]\n"
        "  compact --control PATH [socket limits]\n"
        "  wake --control PATH --peer ID [socket limits]\n"
        "  rebind --control PATH --operation HEX64 --generation ID --reason TEXT\n"
        "         [socket limits]\n"
        "  retry --control PATH --operation HEX64 --reason TEXT [socket limits]\n"
        "  custody-dispatch --control PATH --activation ID --activation-generation N\n"
        "     --receiver-request HEX64 --dispatch-request HEX64 --reason TEXT [socket limits]\n"
        "  cancel --control PATH --operation HEX64 --reason TEXT [socket limits]\n"
        "  quiesce --control PATH --reason TEXT [socket limits]\n"
        "  resume --control PATH --reason TEXT [socket limits]\n"
        "  drain-shutdown --control PATH --reason TEXT --drain-deadline-ms N [--correlation TOKEN]\n"
        "                 [--final-state-head yes|no] [socket limits]\n"
        "  shutdown --control PATH [--correlation TOKEN] [--final-state-head yes|no] [socket limits]\n"
        "  serve  --state DIR --node ID --listen HOST:PORT [limits]\n"
        "  offer  --state DIR --node ID --peer ID --connect HOST:PORT\n"
        "         --scope S --operation HEX64 (--payload-text T | --payload-file F)\n"
        "  correct (offer options) --corrects HEX64\n"
        "  flush  --state DIR --node ID --peer ID --connect HOST:PORT\n"
        "         [--max-records N] [socket limits]\n"
        "  state-head --control PATH [socket limits] (bounded current INSPECT observation)\n"
        "  inspect --state DIR --node ID [--max-journal-bytes N]\n"
        "  state-auth-audit --state DIR --node ID --state-auth-key FILE [--expected-root HEX64 --expected-records N]\n"
        "  backup-correlated-stop-audit --input FILE --node ID --generation ID --state-auth-key FILE\n"
        "     --decrypt-key FILE --trusted-cert FILE (--request-id HEX64 | --correlation TOKEN\n"
        "       --stop immediate|drain --final-state-head yes|no [--drain-deadline-ms N --reason TEXT])\n"
        "     [--expected-backup-id HEX64] [--expected-state-head NASH1:...] [--max-matches 1..64]\n"
        "     [--max-bytes 4096..60000]\n"
        "  correlated-stop-audit --state DIR --node ID --state-auth-key FILE\n"
        "     (--request-id HEX64 | --correlation TOKEN --stop immediate|drain --final-state-head yes|no\n"
        "       [--drain-deadline-ms N --reason TEXT]) [--max-matches 1..64] [--max-bytes 4096..60000]\n"
        "  state-auth-recover --state DIR --node ID --state-auth-key FILE --source-sha256 HEX64 --prefix-root HEX64 --prefix-records N --prefix-bytes N --preserve-source FILE --reason TEXT\n"
        "  state-head-custody-create --record FILE --node ID --domain LABEL --generation N --head NASH1:...\n"
        "  state-head-custody-read --record FILE [--expect-node ID --expect-domain LABEL --expect-generation N\n"
        "     --expect-head NASH1:... --expect-digest HEX64]\n"
        "  state-head-custody-advance --record FILE --expect-node ID --expect-domain LABEL --expect-generation N\n"
        "     --expect-head NASH1:... --expect-digest HEX64 --new-generation N --new-head NASH1:...\n"
        "  state-head-custody-promotion-intent-create --intent FILE --record FILE --expect-node ID\n"
        "     --expect-domain LABEL --expect-generation N --expect-head NASH1:... --expect-digest HEX64\n"
        "     --new-generation N --state-auth-key FILE (--state DIR | --input BACKUP --generation ID\n"
        "       --decrypt-key FILE --trusted-cert FILE --require-signature yes --require-encryption yes)\n"
        "  state-head-custody-promote --record FILE (--intent FILE | --expect-node ID --expect-domain LABEL --expect-generation N\n"
        "     --expect-head NASH1:... --expect-digest HEX64 --new-generation N --state-auth-key FILE\n"
        "     (--state DIR | --input BACKUP --generation ID --decrypt-key FILE --trusted-cert FILE\n"
        "       --require-signature yes --require-encryption yes [--expected-backup-id HEX64]))\n"
        "  state-head-custody-promotion-audit --record FILE (--intent FILE | --expect-node ID --expect-domain LABEL\n"
        "     --expect-generation N --expect-head NASH1:... --expect-digest HEX64 --new-generation N\n"
        "     --state-auth-key FILE (--state DIR | --input BACKUP --generation ID --decrypt-key FILE\n"
        "       --trusted-cert FILE --require-signature yes --require-encryption yes\n"
        "       [--expected-backup-id HEX64]))\n"
        "  handoff-key-init --config FILE --key-directory NEWDIR --generation ID\n"
        "  handoff-export --config FILE --key-directory DIR --recipient-binding FILE --recipient-binding-sha256 HEX64\n"
        "     --operation-id HEX64 --kind operation|receipt --expires-ms UNIX_MS --output NEWFILE\n"
        "  handoff-import --config FILE --key-directory DIR --input FILE\n"
        "  custody-create --config FILE --route FILE --capsule FILE --created-ms UNIX_MS --expires-ms UNIX_MS --output NEWFILE\n"
        "  custody-offer --config FILE --input FILE --output NEWFILE\n"
        "  custody-accept --config FILE --input FILE --output NEWFILE\n"
        "  custody-uncertain --config FILE --envelope-sha256 HEX64 --code CODE --detail TEXT\n"
        "  custody-expire --config FILE --envelope-sha256 HEX64\n"
        "  custody-status --config FILE\n"
        "  custody-final-import --config FILE --key-directory DIR --input FILE\n"
        "  custody-service-v1-send --config FILE --rule ID --rule-generation N --route ID --bundle FILE\n"
        "  custody-service-v1-serve --config FILE --rule ID --rule-generation N [--once yes|no]\n"
        "  custody-service-v1-status --config FILE --rule ID --rule-generation N [--bundle FILE]\n"
        "  custody-service-v1-export --config FILE --rule ID --rule-generation N --request HEX64 --output NEWFILE\n"
        "  custody-service-v1-version\n"
        "  Handoff and custody commands require the daemon stopped and exclusive owner state access. Export is not delivery.\n"
        "  state-auth-key-init --output FILE --generation ID\n"
        "  state-auth-migrate --state DIR --node ID --new-key FILE --reason TEXT\n"
        "  state-auth-rotate --state DIR --node ID --state-auth-key OLD --new-key NEW --reason TEXT\n"
        "  State-opening commands accept --state-auth-key FILE (requires keyed state).\n"
        "  Keyed state-opening commands also accept --expected-state-head NASH1:... (exact external input head).\n"
        "  Or use the complete detached alternative: --expected-state-head-custody FILE\n"
        "     --expected-custody-domain LABEL --expected-custody-generation N\n"
        "     --expected-custody-digest HEX64 (mutually exclusive with raw expectations).\n"
        "  Audit/recovery compare the maximal verified prefix; backup readers compare the embedded checkpoint.\n"
        "  version\n"
        "\n"
        "Socket limits: --deadline-ms --read-quantum --write-quantum --receive-limit\n"
        "Server limits: --workers --queue-capacity --max-connections --idle-timeout-ms\n";
}

}  // namespace
}  // namespace natrav_overlay

int main(int argc, char* argv[]) {
    using namespace natrav_overlay;
    try {
        if (std::signal(SIGPIPE, SIG_IGN) == SIG_ERR) {
            app_fail("SIGNAL_SETUP_FAILED", "could not ignore SIGPIPE");
        }
        if (argc < 2) {
            usage(std::cerr);
            return 2;
        }
        const std::string command = argv[1];
        if (command == "serial-packet-adapter") { return run_serial_packet_adapter(argc, argv); }
        if (command == "removable-media-packet-adapter") {
            return run_removable_media_packet_adapter(argc, argv);
        }
        if (command == "--help" || command == "help") {
            usage(std::cout);
            return 0;
        }
        if (command == "custody-service-v1-version") {
            if (argc != 2) {
                app_fail("INVALID_ARGUMENT",
                    "custody-service-v1-version takes no options");
            }
            std::cout << custody_session_service_version_json() << '\n';
            return 0;
        }
        if (command == "custody-service-v1-help") {
            if (argc != 2) {
                app_fail("INVALID_ARGUMENT",
                    "custody-service-v1-help takes no options");
            }
            std::cout
                << "Native durable custody session service (explicit route; no discovery or relay)\n"
                << "  custody-service-v1-send --config FILE --rule ID --rule-generation N --route ID --bundle FILE\n"
                << "  custody-service-v1-serve --config FILE --rule ID --rule-generation N [--once yes|no]\n"
                << "  custody-service-v1-status --config FILE --rule ID --rule-generation N [--bundle FILE]\n"
                << "  custody-service-v1-export --config FILE --rule ID --rule-generation N --request HEX64 --output NEWFILE\n"
                << "  custody-service-v1-version\n";
            return 0;
        }
        if (command == "version") {
            if (argc != 2) {
                app_fail("INVALID_ARGUMENT", "version takes no options");
            }
            std::cout << "{\"format\":\"NATRAV_OVERLAY_VERSION_V1\","
                         "\"version\":\"0613\",\"runtime\":\"C++20\","
                         "\"handoff_key_policy\":\"V20_DURABLE_HANDOFF_KEY_POLICY_V1\","
                         "\"custody_envelope_model\":\"PRIVATE_FINITE_CUSTODY_ENVELOPE_MODEL_V1\","
                         "\"custody_relay_policy\":\"V21_DURABLE_CUSTODY_RELAY_POLICY_V1\","
                         "\"custody_session_policy\":\"V22_EXACT_CUSTODY_SESSION_AUTHORITY_V1\","
                         "\"custody_receiver_policy\":\"V23_PASSIVE_DAEMON_CUSTODY_RECEIVER_V1\","
                         "\"custody_dispatch_policy\":\"V24_EXPLICIT_OWNER_CUSTODY_DISPATCH_V1\","
                         "\"passive_daemon_custody_receiver\":true,"
                         "\"explicit_owner_custody_dispatch\":true,\"custody_dispatch_reconciliation\":\"READ_ONLY_STATUS_AND_CURSOR_INVENTORY_V1\","
                         "\"native_custody_session\":\"NATIVE_DURABLE_CUSTODY_SESSION_SERVICE_V1\","
                         "\"custody_retained_export\":\"EXPLICIT_CURRENT_CUSTODIAN_BUNDLE_EXPORT_V1\","
                         "\"custody_session_transport\":\"NOS1_BOUNDED_REUSE_V1\","
                         "\"durable_custody_evidence\":\"DURABLE_CUSTODY_EVIDENCE_V1\","
                         "\"custody_bundle\":\"FINITE_CUSTODY_BUNDLE_V1\","
                         "\"configured_custody_relay\":true,"
                         "\"automatic_custody_sender\":false,"
                         "\"automatic_route_relay\":false,"
                         "\"open_relay\":false,"
                         "\"handoff_capsule\":\"ONE_HOP_AUTHENTICATED_CAPSULE_V1\",\"handoff_mode\":\"OFFLINE_OWNER_ONLY\","
                         "\"live_state_head\":\"NOC1_KIND41_NASH1_OBSERVATION_V1\","
                         "\"state_head_expectation\":\"NASH1_EXACT_AUTHENTICATED_INPUT_V1\","
                         "\"outbox_query\":\"OBQ1_INDEXED_ADMIN_METADATA_V1\","
                         "\"import_review\":\"NIR2_EXACT_DECISION_RETRY_V1\","
                         "\"local_authorship\":\"NLA1_EXACT_UID_SCOPE_V1\","
                         "\"persistent_transport\":\"TLS1.3_MTLS_KEY_GENERATION_V1\","
                         "\"transport_extraction\":\"TCP_ORDERED_BYTE_STREAM_BOUNDARY_V1\","
                         "\"tls_byte_channel\":\"OPENSSL_BYTE_CHANNEL_BIO_V1\","
                         "\"virtual_carrier\":\"DETERMINISTIC_VIRTUAL_ORDERED_BYTE_STREAM_V1\","
                         "\"serial_transport\":\"POSIX_SERIAL_TTY_ORDERED_BYTE_STREAM_V1\","
                         "\"udp_transport\":\"NUMERIC_POINT_TO_POINT_UDP_PACKET_CARRIER_V1\","
                         "\"unix_datagram_transport\":\"OWNER_CONTROLLED_UNIX_DATAGRAM_PACKET_CARRIER_V1\","
                         "\"packet_link_core\":\"FINITE_PACKET_LINK_SERVICE_V1\","
                         "\"packet_port\":\"OWNED_COMPLETE_DATAGRAM_PACKET_PORT_V1\","
                         "\"packet_link_stream\":\"PACKET_LINK_ORDERED_BYTE_STREAM_ADAPTER_V1\","
                         "\"external_packet_adapter\":\"SUPERVISED_EXTERNAL_PACKET_ADAPTER_V1\","
                         "\"adapter_configuration\":\"V19_DURABLE_ADAPTER_CONFIGURATION_V1\","
                         "\"configured_adapter_transport\":true,"
                         "\"configured_adapter_execution\":\"V19_EXACT_CONFIGURED_ADAPTER_TRANSPORT_V1\","
                         "\"configured_adapter_adversity\":\"DETERMINISTIC_CONFIGURED_ADAPTER_ADVERSITY_V1\","
                         "\"serial_packet_adapter\":\"FRAMED_SERIAL_PACKET_ADAPTER_V1\","
                         "\"serial_packet_timing\":\"BOUNDED_LINE_RATE_FRAME_BUDGET_V1\","
                         "\"removable_media_packet_adapter\":\"REMOVABLE_MEDIA_PACKET_ADAPTER_V1\","
                         "\"removable_media_bundle\":\"REMOVABLE_MEDIA_PACKET_BUNDLE_V1\","
                         "\"packet_epoch_binding\":\"FRESH_CONNECTOR_BOUND_LISTENER_PACKET_EPOCH_V1\","
                         "\"authorization\":\"PEER_SCOPE_POLICY_V1\","
                         "\"action_sink\":\"DURABLE_COUNTER_V1\","
                         "\"action_selection\":\"INDEXED_READINESS_EXPIRY_V1\","
                         "\"action_administration\":\"CONDITIONAL_CANCEL_RECEIPT_V1\","
                         "\"action_results\":\"NAC1_ATOMIC_DURABLE_OUTBOX_V1\","
                         "\"storage_schema\":2,\"state_authentication\":\"NOAUTH01_HMAC_SHA256_CHAIN_V1\","
                         "\"state_recovery\":\"EXPLICIT_VERIFIED_PREFIX_V1\","
                         "\"evidence_query\":\"NEQ1_BOUNDED_AUTHORIZED_READS\","
                         "\"projection_scheduling\":\"DURABLE_OPT_IN_FAIR_V1\","
                         "\"evidence_projections\":\"DOMAIN_SUMMARY_V1,NUMERIC_SUMMARY_V1\","
                         "\"projection_publication\":\"NPP1_DURABLE_OUTBOX_V1\","
                         "\"publication_channels\":\"NPC2_EXPLICIT_CHANNEL_EPOCHS_V1\","
                         "\"evidence_consumers\":\"NCR1_DURABLE_UID_CHECKPOINTS\","
                         "\"evidence_feed\":\"NEF1_SCOPED_INCREMENTAL_ADMISSIONS\", "
                         "\"maintenance\":\"CHECKPOINT_COMPACTION_BACKUP_V1\","
                         "\"delivery_outcomes\":\"AUTHENTICATED_REJECTION_V1\","
                         "\"queue_governance\":\"RESERVED_OUTBOX_QUOTAS_V1\","
                         "\"peer_sessions\":\"NOS1_BOUNDED_REUSE_V1\","
                         "\"peer_routes\":\"V13_BOUNDED_MULTI_ROUTE_V1\","
                         "\"source_subscriptions\":\"NSS6_TERMINAL_RECEIPT_RECONCILIATION_V1\","
                         "\"source_progress_journal\":\"NST3_COMPACT_EXACT_TRANSITIONS_V1\","
                         "\"configuration\":\"DURABLE_LIVE_GENERATIONS_V1\","
                         "\"state_relocation\":\"OFFLINE_OWNER_PATH_TRANSITION_V1\","
                         "\"local_control\":\"SO_PEERCRED_UID_CLASSES_V1\","
                         "\"backup_encryption\":\"NOBENC01_AES256GCM_HKDF_V1\",\"correlated_stopping\":\"NOC1_KINDS44_45_REQUEST_ID_V1\",\"correlated_terminal_head\":\"NOC1_KINDS46_47_NASH1_REQUEST_ID_V1\",\"offline_correlated_stop_audit\":\"AUTHENTICATED_READ_ONLY_REQUEST_PROVENANCE_V1\",\"backup_correlated_stop_audit\":\"SIGNED_ENCRYPTED_CHECKPOINT_REQUEST_PROVENANCE_V1\",\"detached_state_head_custody\":\"EXPLICIT_COMPARE_AND_SWAP_RECORD_V1\",\"custody_constrained_state_opening\":\"EXPLICIT_NHCUST01_TO_NASH1_V1\",\"custody_promotion\":\"AUTHENTICATED_INPUT_DERIVED_CAS_V1\",\"custody_promotion_intent\":\"NHCPI001_EXPLICIT_REVALIDATED_INPUT_V1\",\"custody_promotion_outcome_audit\":\"READ_ONLY_AUTHENTICATED_EVIDENCE_CLASSIFICATION_V1\",\"service_lifecycle\":\"QUIESCE_DRAIN_V1\"}\n";
            return 0;
        }
        Arguments args(argc, argv, 2);
        const auto canonical_custody_generation = [&](const std::string& key) {
            const auto& text = args.require(key);
            const auto value = parse_u64(text, key, 1U,
                std::numeric_limits<std::uint64_t>::max());
            if (std::to_string(value) != text) {
                app_fail("STATE_HEAD_CUSTODY_GENERATION_INVALID",
                    "custody generations require canonical positive decimal integers");
            }
            return value;
        };
        if (args.contains("--state-auth-key")) {
            const std::set<std::string> state_commands{"run", "serve", "offer", "correct", "flush", "inspect", "handoff-key-init", "handoff-export", "handoff-import", "custody-create", "custody-offer", "custody-accept", "custody-uncertain", "custody-expire", "custody-status", "custody-final-import",
                "custody-service-v1-send", "custody-service-v1-serve", "custody-service-v1-status", "custody-service-v1-export",
                "backup-export", "backup-verify", "backup-restore", "backup-reencrypt", "state-relocate", "state-auth-rotate", "state-auth-audit", "state-auth-recover", "correlated-stop-audit", "backup-correlated-stop-audit", "state-head-custody-promotion-intent-create", "state-head-custody-promote", "state-head-custody-promotion-audit"};
            if (!state_commands.contains(command)) { app_fail("UNKNOWN_ARGUMENT", "--state-auth-key is not valid for this command"); }
            configure_process_state_auth_key(args.require("--state-auth-key"));
            args.erase("--state-auth-key");
        }
        const std::set<std::string> expectation_commands{"run", "serve", "offer", "correct", "flush", "inspect", "handoff-key-init", "handoff-export", "handoff-import", "custody-create", "custody-offer", "custody-accept", "custody-uncertain", "custody-expire", "custody-status", "custody-final-import",
                "custody-service-v1-send", "custody-service-v1-serve", "custody-service-v1-status", "custody-service-v1-export",
            "backup-export", "backup-verify", "backup-restore", "backup-reencrypt", "state-relocate",
            "state-auth-rotate", "state-auth-audit", "state-auth-recover", "correlated-stop-audit", "backup-correlated-stop-audit"};
        const std::array<std::string, 4U> custody_expectation_keys{
            "--expected-state-head-custody", "--expected-custody-domain",
            "--expected-custody-generation", "--expected-custody-digest",
        };
        const bool has_raw_expectation = args.contains("--expected-state-head");
        const bool has_any_custody_expectation = std::any_of(
            custody_expectation_keys.begin(), custody_expectation_keys.end(),
            [&](const auto& key) { return args.contains(key); });
        if (has_raw_expectation || has_any_custody_expectation) {
            if (!expectation_commands.contains(command)) {
                app_fail("UNKNOWN_ARGUMENT",
                    has_any_custody_expectation ?
                        "detached custody expectations are not valid for this command" :
                        "--expected-state-head is not valid for this command");
            }
            if (args.contains("--expected-root") || args.contains("--expected-records")) {
                app_fail("STATE_HEAD_EXPECTATION_INVALID", "typed and legacy expected-head alternatives cannot be mixed");
            }
            if (has_raw_expectation && has_any_custody_expectation) {
                app_fail("STATE_HEAD_EXPECTATION_INVALID",
                    "raw and detached-custody expected-head alternatives cannot be mixed");
            }
            if (has_any_custody_expectation) {
                const bool complete = std::all_of(
                    custody_expectation_keys.begin(), custody_expectation_keys.end(),
                    [&](const auto& key) { return args.contains(key); });
                if (!complete) {
                    app_fail("STATE_HEAD_CUSTODY_EXPECTATION_REQUIRED",
                        "custody-constrained opening requires file, domain, generation, and record digest");
                }
                configure_process_state_head_custody_constraint(
                    StateHeadCustodyConstraintOptions{
                        .record_file = args.require("--expected-state-head-custody"),
                        .expected_domain = args.require("--expected-custody-domain"),
                        .expected_generation = canonical_custody_generation(
                            "--expected-custody-generation"),
                        .expected_record_digest = parse_operation_id(
                            args.require("--expected-custody-digest")),
                    });
                for (const auto& key : custody_expectation_keys) { args.erase(key); }
            } else {
                configure_process_state_head_expectation(args.require("--expected-state-head"));
                args.erase("--expected-state-head");
            }
        }
        if (command == "custody-service-v1-send" ||
            command == "custody-service-v1-serve" ||
            command == "custody-service-v1-status" ||
            command == "custody-service-v1-export") {
            CustodySessionServiceOptions options;
            options.config = args.require("--config");
            options.rule_id = args.require("--rule");
            options.rule_generation = parse_u64(args.require("--rule-generation"),
                "rule-generation", 1U,
                std::numeric_limits<std::uint64_t>::max());
            if (command == "custody-service-v1-send") {
                options.route_id = args.require("--route");
                options.bundle = args.require("--bundle");
                args.require_only({"--config", "--rule", "--rule-generation",
                    "--route", "--bundle"});
                const auto result = run_custody_session_send(options);
                std::cout << result.json << '\n';
                return result.status;
            }
            if (command == "custody-service-v1-serve") {
                options.once = yes_no_option(args, "--once", false);
                args.require_only({"--config", "--rule", "--rule-generation",
                    "--once"});
                return run_custody_session_server(options);
            }
            if (command == "custody-service-v1-export") {
                options.request_id = parse_operation_id(args.require("--request"));
                options.has_request_id = true;
                options.output = args.require("--output");
                args.require_only({"--config", "--rule", "--rule-generation",
                    "--request", "--output"});
                const auto result = run_custody_session_export(options);
                std::cout << result.json << '\n';
                return result.status;
            }
            if (args.contains("--bundle")) {
                options.bundle = args.require("--bundle");
            }
            args.require_only({"--config", "--rule", "--rule-generation",
                "--bundle"});
            const auto result = run_custody_session_status(options);
            std::cout << result.json << '\n';
            return result.status;
        }
        if (command == "state-head-custody-promotion-intent-create") {
            const bool state_source = args.contains("--state");
            const bool backup_source = args.contains("--input");
            if (state_source == backup_source) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_SOURCE_REQUIRED",
                    "provide exactly one of --state or --input");
            }
            StateHeadCustodyExpectation expected;
            expected.node = args.require("--expect-node");
            expected.domain = args.require("--expect-domain");
            expected.generation = canonical_custody_generation("--expect-generation");
            static_cast<void>(parse_state_head_expectation(args.require("--expect-head")));
            expected.state_head = args.require("--expect-head");
            expected.record_digest = parse_operation_id(args.require("--expect-digest"));
            const std::string expected_node = *expected.node;
            StateHeadCustodyPromotionIntentCreateOptions intent{
                .intent_file = args.require("--intent"),
                .record_file = args.require("--record"),
                .expected = std::move(expected),
                .new_generation = canonical_custody_generation("--new-generation"),
            };
            if (state_source) {
                args.require_only({"--intent", "--record", "--expect-node",
                    "--expect-domain", "--expect-generation", "--expect-head",
                    "--expect-digest", "--new-generation", "--state",
                    "--max-journal-bytes"});
                std::cout << create_state_head_custody_promotion_intent_from_state(
                    StateDirectoryCustodyPromotionIntentCreateOptions{
                        .intent = std::move(intent),
                        .source = StateAuditOptions{
                            .directory = args.require("--state"),
                            .node = expected_node,
                            .maximum_bytes = journal_limit(args),
                            .expected_root = std::nullopt,
                            .expected_records = std::nullopt,
                        },
                    }) << '\n';
                return 0;
            }
            args.require_only({"--intent", "--record", "--expect-node",
                "--expect-domain", "--expect-generation", "--expect-head",
                "--expect-digest", "--new-generation", "--input", "--generation",
                "--decrypt-key", "--trusted-cert", "--require-signature",
                "--require-encryption", "--expected-backup-id", "--max-journal-bytes"});
            if (!yes_no_option(args, "--require-signature", true) ||
                !yes_no_option(args, "--require-encryption", true)) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_BACKUP_TRUST_REQUIRED",
                    "backup promotion intent creation requires signature and encryption");
            }
            const auto expected_backup_id = args.contains("--expected-backup-id") ?
                std::optional<datacube::Digest32>(parse_operation_id(
                    args.require("--expected-backup-id"))) : std::nullopt;
            std::cout << create_state_head_custody_promotion_intent_from_backup(
                BackupCustodyPromotionIntentCreateOptions{
                    .intent = std::move(intent),
                    .source = BackupVerifyOptions{
                        .input_file = args.require("--input"),
                        .expected_node_id = expected_node,
                        .expected_identity_generation = args.require("--generation"),
                        .trusted_certificate = args.require("--trusted-cert"),
                        .require_signature = true,
                        .maximum_journal_bytes = journal_limit(args),
                        .decryption_key = args.require("--decrypt-key"),
                        .require_encryption = true,
                        .expected_backup_id = expected_backup_id,
                    },
                }) << '\n';
            return 0;
        }
        if (command == "state-head-custody-promote") {
            const bool state_source = args.contains("--state");
            const bool backup_source = args.contains("--input");
            if (state_source == backup_source) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_SOURCE_REQUIRED",
                    "provide exactly one of --state or --input");
            }
            const bool detached_intent = args.contains("--intent");
            const std::array<std::string, 6U> inline_keys{
                "--expect-node", "--expect-domain", "--expect-generation",
                "--expect-head", "--expect-digest", "--new-generation",
            };
            const bool any_inline = std::any_of(inline_keys.begin(), inline_keys.end(),
                [&](const auto& key) { return args.contains(key); });
            if (detached_intent && any_inline) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_ARGUMENT_CONFLICT",
                    "--intent cannot be combined with inline custody expectations");
            }
            if (detached_intent) {
                const StateHeadCustodyPromotionIntentUseOptions intent{
                    .intent_file = args.require("--intent"),
                    .record_file = args.require("--record"),
                };
                if (state_source) {
                    args.require_only({"--intent", "--record", "--state",
                        "--max-journal-bytes"});
                    std::cout << promote_state_head_custody_from_state_with_intent(
                        StateDirectoryCustodyPromotionIntentUseOptions{
                            .intent = intent,
                            .source = StateAuditOptions{
                                .directory = args.require("--state"),
                                .node = {},
                                .maximum_bytes = journal_limit(args),
                                .expected_root = std::nullopt,
                                .expected_records = std::nullopt,
                            },
                        }) << '\n';
                    return 0;
                }
                args.require_only({"--intent", "--record", "--input", "--generation",
                    "--decrypt-key", "--trusted-cert", "--require-signature",
                    "--require-encryption", "--expected-backup-id", "--max-journal-bytes"});
                if (!yes_no_option(args, "--require-signature", true) ||
                    !yes_no_option(args, "--require-encryption", true)) {
                    app_fail("STATE_HEAD_CUSTODY_PROMOTION_BACKUP_TRUST_REQUIRED",
                        "backup promotion requires signature and encryption");
                }
                const auto expected_backup_id = args.contains("--expected-backup-id") ?
                    std::optional<datacube::Digest32>(parse_operation_id(
                        args.require("--expected-backup-id"))) : std::nullopt;
                const auto expected_identity_generation = args.contains("--generation") ?
                    std::optional<std::string>(args.require("--generation")) : std::nullopt;
                std::cout << promote_state_head_custody_from_backup_with_intent(
                    BackupCustodyPromotionIntentUseOptions{
                        .intent = intent,
                        .source = BackupVerifyOptions{
                            .input_file = args.require("--input"),
                            .expected_node_id = std::nullopt,
                            .expected_identity_generation = expected_identity_generation,
                            .trusted_certificate = args.require("--trusted-cert"),
                            .require_signature = true,
                            .maximum_journal_bytes = journal_limit(args),
                            .decryption_key = args.require("--decrypt-key"),
                            .require_encryption = true,
                            .expected_backup_id = expected_backup_id,
                        },
                    }) << '\n';
                return 0;
            }
            const bool complete_inline = std::all_of(inline_keys.begin(), inline_keys.end(),
                [&](const auto& key) { return args.contains(key); });
            if (!complete_inline) {
                app_fail("STATE_HEAD_CUSTODY_EXPECTATION_REQUIRED",
                    "inline promotion requires exact old custody fields and --new-generation, or use --intent");
            }
            StateHeadCustodyExpectation expected;
            expected.node = args.require("--expect-node");
            expected.domain = args.require("--expect-domain");
            expected.generation = canonical_custody_generation("--expect-generation");
            static_cast<void>(parse_state_head_expectation(args.require("--expect-head")));
            expected.state_head = args.require("--expect-head");
            expected.record_digest = parse_operation_id(args.require("--expect-digest"));
            const std::string expected_node = *expected.node;
            StateHeadCustodyPromotionOptions custody{
                .record_file = args.require("--record"),
                .expected = std::move(expected),
                .new_generation = canonical_custody_generation("--new-generation"),
            };
            if (state_source) {
                args.require_only({"--record", "--expect-node", "--expect-domain",
                    "--expect-generation", "--expect-head", "--expect-digest",
                    "--new-generation", "--state", "--max-journal-bytes"});
                std::cout << promote_state_head_custody_from_state(
                    StateDirectoryCustodyPromotionOptions{
                        .custody = std::move(custody),
                        .source = StateAuditOptions{
                            .directory = args.require("--state"),
                            .node = expected_node,
                            .maximum_bytes = journal_limit(args),
                            .expected_root = std::nullopt,
                            .expected_records = std::nullopt,
                        },
                    }) << '\n';
                return 0;
            }
            args.require_only({"--record", "--expect-node", "--expect-domain",
                "--expect-generation", "--expect-head", "--expect-digest",
                "--new-generation", "--input", "--generation", "--decrypt-key",
                "--trusted-cert", "--require-signature", "--require-encryption",
                "--expected-backup-id", "--max-journal-bytes"});
            if (!yes_no_option(args, "--require-signature", true) ||
                !yes_no_option(args, "--require-encryption", true)) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_BACKUP_TRUST_REQUIRED",
                    "backup promotion requires signature and encryption");
            }
            const auto expected_backup_id = args.contains("--expected-backup-id") ?
                std::optional<datacube::Digest32>(parse_operation_id(
                    args.require("--expected-backup-id"))) : std::nullopt;
            std::cout << promote_state_head_custody_from_backup(
                BackupCustodyPromotionOptions{
                    .custody = std::move(custody),
                    .source = BackupVerifyOptions{
                        .input_file = args.require("--input"),
                        .expected_node_id = expected_node,
                        .expected_identity_generation = args.require("--generation"),
                        .trusted_certificate = args.require("--trusted-cert"),
                        .require_signature = true,
                        .maximum_journal_bytes = journal_limit(args),
                        .decryption_key = args.require("--decrypt-key"),
                        .require_encryption = true,
                        .expected_backup_id = expected_backup_id,
                    },
                }) << '\n';
            return 0;
        }
        if (command == "state-head-custody-promotion-audit") {
            const bool state_source = args.contains("--state");
            const bool backup_source = args.contains("--input");
            if (state_source == backup_source) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_SOURCE_REQUIRED",
                    "provide exactly one of --state or --input");
            }
            const bool detached_intent = args.contains("--intent");
            const std::array<std::string, 6U> inline_keys{
                "--expect-node", "--expect-domain", "--expect-generation",
                "--expect-head", "--expect-digest", "--new-generation",
            };
            const bool any_inline = std::any_of(inline_keys.begin(), inline_keys.end(),
                [&](const auto& key) { return args.contains(key); });
            if (detached_intent && any_inline) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_INTENT_ARGUMENT_CONFLICT",
                    "--intent cannot be combined with inline custody expectations");
            }
            if (detached_intent) {
                const StateHeadCustodyPromotionIntentUseOptions intent{
                    .intent_file = args.require("--intent"),
                    .record_file = args.require("--record"),
                };
                if (state_source) {
                    args.require_only({"--intent", "--record", "--state",
                        "--max-journal-bytes"});
                    std::cout << audit_state_head_custody_promotion_from_state_with_intent(
                        StateDirectoryCustodyPromotionIntentUseOptions{
                            .intent = intent,
                            .source = StateAuditOptions{
                                .directory = args.require("--state"),
                                .node = {},
                                .maximum_bytes = journal_limit(args),
                                .expected_root = std::nullopt,
                                .expected_records = std::nullopt,
                            },
                        }) << '\n';
                    return 0;
                }
                args.require_only({"--intent", "--record", "--input", "--generation",
                    "--decrypt-key", "--trusted-cert", "--require-signature",
                    "--require-encryption", "--expected-backup-id", "--max-journal-bytes"});
                if (!yes_no_option(args, "--require-signature", true) ||
                    !yes_no_option(args, "--require-encryption", true)) {
                    app_fail("STATE_HEAD_CUSTODY_PROMOTION_BACKUP_TRUST_REQUIRED",
                        "backup promotion outcome audit requires signature and encryption");
                }
                const auto expected_backup_id = args.contains("--expected-backup-id") ?
                    std::optional<datacube::Digest32>(parse_operation_id(
                        args.require("--expected-backup-id"))) : std::nullopt;
                const auto expected_identity_generation = args.contains("--generation") ?
                    std::optional<std::string>(args.require("--generation")) : std::nullopt;
                std::cout << audit_state_head_custody_promotion_from_backup_with_intent(
                    BackupCustodyPromotionIntentUseOptions{
                        .intent = intent,
                        .source = BackupVerifyOptions{
                            .input_file = args.require("--input"),
                            .expected_node_id = std::nullopt,
                            .expected_identity_generation = expected_identity_generation,
                            .trusted_certificate = args.require("--trusted-cert"),
                            .require_signature = true,
                            .maximum_journal_bytes = journal_limit(args),
                            .decryption_key = args.require("--decrypt-key"),
                            .require_encryption = true,
                            .expected_backup_id = expected_backup_id,
                        },
                    }) << '\n';
                return 0;
            }
            const bool complete_inline = std::all_of(inline_keys.begin(), inline_keys.end(),
                [&](const auto& key) { return args.contains(key); });
            if (!complete_inline) {
                app_fail("STATE_HEAD_CUSTODY_EXPECTATION_REQUIRED",
                    "inline outcome audit requires exact old custody fields and --new-generation, or use --intent");
            }
            StateHeadCustodyExpectation intended_old;
            intended_old.node = args.require("--expect-node");
            intended_old.domain = args.require("--expect-domain");
            intended_old.generation = canonical_custody_generation("--expect-generation");
            static_cast<void>(parse_state_head_expectation(args.require("--expect-head")));
            intended_old.state_head = args.require("--expect-head");
            intended_old.record_digest = parse_operation_id(args.require("--expect-digest"));
            const std::string expected_node = *intended_old.node;
            StateHeadCustodyPromotionAuditOptions custody{
                .record_file = args.require("--record"),
                .intended_old = std::move(intended_old),
                .intended_new_generation = canonical_custody_generation("--new-generation"),
            };
            if (state_source) {
                args.require_only({"--record", "--expect-node", "--expect-domain",
                    "--expect-generation", "--expect-head", "--expect-digest",
                    "--new-generation", "--state", "--max-journal-bytes"});
                std::cout << audit_state_head_custody_promotion_from_state(
                    StateDirectoryCustodyPromotionAuditOptions{
                        .custody = std::move(custody),
                        .source = StateAuditOptions{
                            .directory = args.require("--state"),
                            .node = expected_node,
                            .maximum_bytes = journal_limit(args),
                            .expected_root = std::nullopt,
                            .expected_records = std::nullopt,
                        },
                    }) << '\n';
                return 0;
            }
            args.require_only({"--record", "--expect-node", "--expect-domain",
                "--expect-generation", "--expect-head", "--expect-digest",
                "--new-generation", "--input", "--generation", "--decrypt-key",
                "--trusted-cert", "--require-signature", "--require-encryption",
                "--expected-backup-id", "--max-journal-bytes"});
            if (!yes_no_option(args, "--require-signature", true) ||
                !yes_no_option(args, "--require-encryption", true)) {
                app_fail("STATE_HEAD_CUSTODY_PROMOTION_BACKUP_TRUST_REQUIRED",
                    "backup promotion outcome audit requires signature and encryption");
            }
            const auto expected_backup_id = args.contains("--expected-backup-id") ?
                std::optional<datacube::Digest32>(parse_operation_id(
                    args.require("--expected-backup-id"))) : std::nullopt;
            std::cout << audit_state_head_custody_promotion_from_backup(
                BackupCustodyPromotionAuditOptions{
                    .custody = std::move(custody),
                    .source = BackupVerifyOptions{
                        .input_file = args.require("--input"),
                        .expected_node_id = expected_node,
                        .expected_identity_generation = args.require("--generation"),
                        .trusted_certificate = args.require("--trusted-cert"),
                        .require_signature = true,
                        .maximum_journal_bytes = journal_limit(args),
                        .decryption_key = args.require("--decrypt-key"),
                        .require_encryption = true,
                        .expected_backup_id = expected_backup_id,
                    },
                }) << '\n';
            return 0;
        }
        if (command == "state-head-custody-create" ||
            command == "state-head-custody-read" ||
            command == "state-head-custody-advance") {
            if (command == "state-head-custody-create") {
                args.require_only({"--record", "--node", "--domain",
                    "--generation", "--head"});
                static_cast<void>(parse_state_head_expectation(args.require("--head")));
                std::cout << create_state_head_custody_record(
                    StateHeadCustodyCreateOptions{
                        .record_file = args.require("--record"),
                        .node = args.require("--node"),
                        .domain = args.require("--domain"),
                        .generation = canonical_custody_generation("--generation"),
                        .state_head = args.require("--head"),
                    }) << '\n';
                return 0;
            }
            const auto expectation = [&] {
                StateHeadCustodyExpectation value;
                if (args.contains("--expect-node")) {
                    value.node = args.require("--expect-node");
                }
                if (args.contains("--expect-domain")) {
                    value.domain = args.require("--expect-domain");
                }
                if (args.contains("--expect-generation")) {
                    value.generation = canonical_custody_generation("--expect-generation");
                }
                if (args.contains("--expect-head")) {
                    static_cast<void>(parse_state_head_expectation(
                        args.require("--expect-head")));
                    value.state_head = args.require("--expect-head");
                }
                if (args.contains("--expect-digest")) {
                    value.record_digest = parse_operation_id(
                        args.require("--expect-digest"));
                }
                return value;
            }();
            if (command == "state-head-custody-read") {
                args.require_only({"--record", "--expect-node",
                    "--expect-domain", "--expect-generation", "--expect-head",
                    "--expect-digest"});
                std::cout << read_state_head_custody_record(
                    StateHeadCustodyReadOptions{
                        .record_file = args.require("--record"),
                        .expected = expectation,
                    }) << '\n';
                return 0;
            }
            args.require_only({"--record", "--expect-node", "--expect-domain",
                "--expect-generation", "--expect-head", "--expect-digest",
                "--new-generation", "--new-head"});
            static_cast<void>(parse_state_head_expectation(args.require("--new-head")));
            std::cout << advance_state_head_custody_record(
                StateHeadCustodyAdvanceOptions{
                    .record_file = args.require("--record"),
                    .expected = expectation,
                    .new_generation = canonical_custody_generation("--new-generation"),
                    .new_state_head = args.require("--new-head"),
                }) << '\n';
            return 0;
        }
        if (command == "correlated-stop-audit") {
            args.require_only({"--state", "--node", "--max-journal-bytes",
                "--request-id", "--correlation", "--stop",
                "--final-state-head", "--drain-deadline-ms", "--reason",
                "--max-matches", "--max-bytes"});
            auto options = correlated_stop_audit_options(args, StateAuditOptions{
                .directory = args.require("--state"),
                .node = args.require("--node"),
                .maximum_bytes = journal_limit(args),
                .expected_root = std::nullopt,
                .expected_records = std::nullopt,
            });
            return print_state_conditioned_response(
                audit_correlated_stop(options));
        }
        if (command == "backup-correlated-stop-audit") {
            args.require_only({"--input", "--node", "--generation",
                "--decrypt-key", "--trusted-cert", "--require-signature",
                "--require-encryption", "--max-journal-bytes",
                "--expected-backup-id", "--request-id", "--correlation",
                "--stop", "--final-state-head", "--drain-deadline-ms",
                "--reason", "--max-matches", "--max-bytes"});
            if (!yes_no_option(args, "--require-signature", true) ||
                !yes_no_option(args, "--require-encryption", true)) {
                app_fail("BACKUP_CORRELATED_STOP_AUDIT_TRUST_REQUIRED",
                    "direct backup audit requires signature and encryption");
            }
            const auto node = args.require("--node");
            auto audit = correlated_stop_audit_options(args, StateAuditOptions{
                .directory = {},
                .node = node,
                .maximum_bytes = journal_limit(args),
                .expected_root = std::nullopt,
                .expected_records = std::nullopt,
            });
            const auto expected_backup_id = args.contains("--expected-backup-id") ?
                std::optional<datacube::Digest32>(parse_operation_id(
                    args.require("--expected-backup-id"))) : std::nullopt;
            return print_state_conditioned_response(audit_backup_correlated_stop(
                BackupCorrelatedStopAuditOptions{
                    .verification = BackupVerifyOptions{
                        .input_file = args.require("--input"),
                        .expected_node_id = node,
                        .expected_identity_generation = args.require("--generation"),
                        .trusted_certificate = args.require("--trusted-cert"),
                        .require_signature = true,
                        .maximum_journal_bytes = journal_limit(args),
                        .decryption_key = args.require("--decrypt-key"),
                        .require_encryption = true,
                        .expected_backup_id = expected_backup_id,
                    },
                    .audit = std::move(audit),
                }));
        }
        if (command == "state-auth-audit" || command == "state-auth-recover") {
            const bool recovering = command == "state-auth-recover";
            if (recovering) {
                args.require_only({"--state", "--node", "--max-journal-bytes", "--source-sha256", "--prefix-root",
                    "--prefix-records", "--prefix-bytes", "--preserve-source", "--reason"});
            } else {
                args.require_only({"--state", "--node", "--max-journal-bytes", "--expected-root", "--expected-records"});
            }
            StateAuditOptions options{.directory = args.require("--state"), .node = args.require("--node"),
                .maximum_bytes = journal_limit(args), .expected_root = std::nullopt, .expected_records = std::nullopt};
            if (!recovering) {
                if (args.contains("--expected-root")) { options.expected_root = parse_operation_id(args.require("--expected-root")); }
                if (args.contains("--expected-records")) {
                    options.expected_records = parse_u64(args.require("--expected-records"), "expected records", 1U, 1'000'000'000U);
                }
                const auto result = audit_authenticated_state(options);
                return print_state_conditioned_response(
                    result.json, result.complete ? 0 : 3);
            }
            const StateRecoveryOptions recovery{.source = std::move(options),
                .source_digest = parse_operation_id(args.require("--source-sha256")),
                .prefix_root = parse_operation_id(args.require("--prefix-root")),
                .prefix_records = parse_u64(args.require("--prefix-records"), "prefix records", 1U, 1'000'000'000U),
                .prefix_bytes = parse_u64(args.require("--prefix-bytes"), "prefix bytes", 1U, 1'073'741'824U),
                .preserve_source = args.require("--preserve-source"), .reason = args.require("--reason")};
            return print_state_conditioned_response(
                recover_authenticated_state(recovery));
        }
        if (command == "state-auth-key-init") {
            args.require_only({"--output", "--generation"});
            std::cout << initialize_state_auth_key(args.require("--output"), args.require("--generation")) << '\n';
            return 0;
        }
        if (command == "state-auth-migrate" || command == "state-auth-rotate") {
            args.require_only({"--state", "--node", "--new-key", "--reason", "--max-journal-bytes"});
            const bool migrating = command == "state-auth-migrate";
            if (!migrating && !process_state_auth_key()) {
                app_fail("STATE_AUTH_KEY_REQUIRED", "rotation requires the current --state-auth-key");
            }
            const auto directory = std::filesystem::path(args.require("--state"));
            if (!std::filesystem::is_regular_file(directory / "node.meta") ||
                !std::filesystem::is_regular_file(directory / "state.journal")) {
                app_fail("STATE_AUTH_SOURCE_REQUIRED", "initialize or restore an existing state before explicit migration");
            }
            const auto next_key = load_state_auth_key(args.require("--new-key"));
            NodeState state(directory, args.require("--node"), journal_limit(args), {}, migrating);
            return print_state_conditioned_response(
                state.authenticate_state(next_key, args.require("--reason")));
        }
        if (command == "custody-create" || command == "custody-offer" ||
            command == "custody-accept" || command == "custody-uncertain" ||
            command == "custody-expire" || command == "custody-status" ||
            command == "custody-final-import") {
            CustodyCommand options;
            options.command = command;
            options.config = args.require("--config");
            if (command == "custody-create") {
                args.require_only({"--config", "--route", "--capsule",
                    "--created-ms", "--expires-ms", "--output"});
                options.route = args.require("--route");
                options.capsule = args.require("--capsule");
                options.created_ms = parse_u64(args.require("--created-ms"),
                    "created-ms", 1U, std::numeric_limits<std::uint64_t>::max());
                options.expires_ms = parse_u64(args.require("--expires-ms"),
                    "expires-ms", 1U, std::numeric_limits<std::uint64_t>::max());
                options.output = args.require("--output");
            } else if (command == "custody-offer" ||
                command == "custody-accept") {
                args.require_only({"--config", "--input", "--output"});
                options.input = args.require("--input");
                options.output = args.require("--output");
            } else if (command == "custody-final-import") {
                args.require_only({"--config", "--key-directory", "--input"});
                options.key_directory = args.require("--key-directory");
                options.input = args.require("--input");
            } else if (command == "custody-uncertain") {
                args.require_only({"--config", "--envelope-sha256",
                    "--code", "--detail"});
                options.envelope_sha256 = parse_operation_id(
                    args.require("--envelope-sha256"));
                options.has_envelope_sha256 = true;
                options.code = args.require("--code");
                options.detail = args.require("--detail");
            } else if (command == "custody-expire") {
                args.require_only({"--config", "--envelope-sha256"});
                options.envelope_sha256 = parse_operation_id(
                    args.require("--envelope-sha256"));
                options.has_envelope_sha256 = true;
            } else {
                args.require_only({"--config"});
            }
            std::cout << run_custody_command(options) << '\n';
            return 0;
        }
        if (command == "handoff-key-init" || command == "handoff-export" || command == "handoff-import") {
            HandoffCommand options;
            options.command = command;
            options.config = args.require("--config");
            options.key_directory = args.require("--key-directory");
            if (command == "handoff-key-init") {
                args.require_only({"--config", "--key-directory", "--generation"});
                options.generation = args.require("--generation");
            } else if (command == "handoff-export") {
                args.require_only({"--config", "--key-directory", "--recipient-binding", "--recipient-binding-sha256",
                    "--operation-id", "--kind", "--expires-ms", "--output"});
                options.recipient_binding = args.require("--recipient-binding");
                options.recipient_binding_digest = parse_operation_id(args.require("--recipient-binding-sha256"));
                options.operation = parse_operation_id(args.require("--operation-id"));
                options.kind = args.require("--kind");
                options.expires_ms = parse_u64(args.require("--expires-ms"), "expires-ms", 1U, std::numeric_limits<std::uint64_t>::max());
                options.output = args.require("--output");
            } else {
                args.require_only({"--config", "--key-directory", "--input"});
                options.input = args.require("--input");
            }
            std::cout << run_handoff_command(options) << '\n';
            return 0;
        }
        if (command == "run") {
            args.require_only({"--config"});
            return run_persistent_node(load_runtime_config(args.require("--config")));
        }
        if (command == "config-check") {
            args.require_only({"--config"});
            std::cout << runtime_config_json(
                load_runtime_config(args.require("--config"))) << '\n';
            return 0;
        }
        if (command == "identity-init") {
            args.require_only({
                "--directory", "--node", "--generation", "--validity-days",
            });
            const auto validity_days = static_cast<std::uint32_t>(parse_u64(
                args.get("--validity-days", "3650"),
                "validity-days", 1U, 36'500U));
            const auto result = create_identity(IdentityCreateOptions{
                .directory = std::filesystem::path(args.require("--directory")),
                .node_id = args.require("--node"),
                .generation = args.require("--generation"),
                .validity_days = validity_days,
            });
            std::cout << identity_create_result_json(result) << '\n';
            return 0;
        }
        if (command == "backup-key-init") {
            args.require_only({"--output", "--generation"});
            const auto key = initialize_backup_key(args.require("--output"), args.require("--generation"));
            std::cout << backup_key_json(key) << '\n';
            return 0;
        }
        if (command == "backup-reencrypt") {
            args.require_only({"--input", "--output", "--decrypt-key", "--encrypt-key",
                "--node", "--generation", "--trusted-cert", "--require-signature", "--max-journal-bytes"});
            BackupReencryptOptions options;
            options.verification.input_file = args.require("--input");
            options.verification.decryption_key = args.require("--decrypt-key");
            options.verification.require_encryption = true;
            if (args.contains("--node")) { options.verification.expected_node_id = args.require("--node"); }
            if (args.contains("--generation")) { options.verification.expected_identity_generation = args.require("--generation"); }
            if (args.contains("--trusted-cert")) { options.verification.trusted_certificate = args.require("--trusted-cert"); }
            options.verification.require_signature = yes_no_option(args, "--require-signature", false);
            options.verification.maximum_journal_bytes = journal_limit(args);
            options.output_file = args.require("--output");
            options.encryption_key = args.require("--encrypt-key");
            return print_state_conditioned_response(
                backup_result_json(reencrypt_backup(options), "reencrypt"));
        }
        if (command == "backup-export") {
            args.require_only({
                "--state", "--node", "--generation", "--output",
                "--sign-key", "--sign-cert", "--max-journal-bytes", "--encrypt-key",
            });
            const auto result = export_backup(BackupExportOptions{
                .state_directory = std::filesystem::path(args.require("--state")),
                .node_id = args.require("--node"),
                .identity_generation = args.require("--generation"),
                .output_file = std::filesystem::path(args.require("--output")),
                .signing_private_key = args.contains("--sign-key") ?
                    std::optional<std::filesystem::path>(
                        std::filesystem::path(args.require("--sign-key"))) :
                    std::nullopt,
                .signing_certificate = args.contains("--sign-cert") ?
                    std::optional<std::filesystem::path>(
                        std::filesystem::path(args.require("--sign-cert"))) :
                    std::nullopt,
                .maximum_journal_bytes = journal_limit(args),
                .encryption_key = args.contains("--encrypt-key") ?
                    std::optional<std::filesystem::path>(args.require("--encrypt-key")) : std::nullopt,
            });
            return print_state_conditioned_response(
                backup_result_json(result, "export"));
        }
        if (command == "backup-verify") {
            args.require_only({
                "--input", "--node", "--generation", "--trusted-cert",
                "--require-signature", "--max-journal-bytes", "--decrypt-key", "--require-encryption",
            });
            const auto result = verify_backup(BackupVerifyOptions{
                .input_file = std::filesystem::path(args.require("--input")),
                .expected_node_id = args.contains("--node") ?
                    std::optional<std::string>(args.require("--node")) :
                    std::nullopt,
                .expected_identity_generation = args.contains("--generation") ?
                    std::optional<std::string>(args.require("--generation")) :
                    std::nullopt,
                .trusted_certificate = args.contains("--trusted-cert") ?
                    std::optional<std::filesystem::path>(
                        std::filesystem::path(args.require("--trusted-cert"))) :
                    std::nullopt,
                .require_signature = yes_no_option(
                    args, "--require-signature", false),
                .maximum_journal_bytes = journal_limit(args),
                .decryption_key = args.contains("--decrypt-key") ?
                    std::optional<std::filesystem::path>(args.require("--decrypt-key")) : std::nullopt,
                .require_encryption = yes_no_option(args, "--require-encryption", false),
                .expected_backup_id = std::nullopt,
            });
            return print_state_conditioned_response(
                backup_result_json(result, "verify"));
        }
        if (command == "backup-restore") {
            args.require_only({
                "--input", "--destination", "--node", "--generation",
                "--trusted-cert", "--require-signature",
                "--max-journal-bytes", "--decrypt-key", "--require-encryption",
            });
            const auto result = restore_backup(BackupRestoreOptions{
                .input_file = std::filesystem::path(args.require("--input")),
                .destination_directory =
                    std::filesystem::path(args.require("--destination")),
                .expected_node_id = args.require("--node"),
                .expected_identity_generation = args.require("--generation"),
                .trusted_certificate = args.contains("--trusted-cert") ?
                    std::optional<std::filesystem::path>(
                        std::filesystem::path(args.require("--trusted-cert"))) :
                    std::nullopt,
                .require_signature = yes_no_option(
                    args, "--require-signature", false),
                .maximum_journal_bytes = journal_limit(args),
                .decryption_key = args.contains("--decrypt-key") ?
                    std::optional<std::filesystem::path>(args.require("--decrypt-key")) : std::nullopt,
                .require_encryption = yes_no_option(args, "--require-encryption", false),
            });
            return print_state_conditioned_response(
                backup_restore_result_json(result));
        }
        if (command == "state-relocate") {
            args.require_only({
                "--state", "--node", "--candidate", "--reason",
                "--max-journal-bytes",
            });
            const auto result = relocate_state(StateRelocationOptions{
                .state_directory =
                    std::filesystem::path(args.require("--state")),
                .node_id = args.require("--node"),
                .candidate_config =
                    std::filesystem::path(args.require("--candidate")),
                .reason = args.require("--reason"),
                .maximum_journal_bytes = journal_limit(args),
            });
            return print_state_conditioned_response(
                state_relocation_result_json(result));
        }
        if(command=="source-view-retire"||command=="source-view-retirement-status") {
            const bool status=command=="source-view-retirement-status";
            if(status)args.require_only({"--control","--view","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            else args.require_only({"--control","--view","--expected-revision","--view-digest","--configuration-digest","--final-state-digest","--deferred","--reason","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            ImportAutoRequest request;request.command=status?ImportAutoCommand::retirement_status:ImportAutoCommand::retire;request.view=args.require("--view");
            if(!status) {
                request.revision=parse_u64(args.require("--expected-revision"),"schedule revision",0U,kImportHistoryLimit);
                request.view_digest=parse_operation_id(args.require("--view-digest"));
                request.configuration_digest=parse_operation_id(args.require("--configuration-digest"));
                request.final_state_digest=parse_operation_id(args.require("--final-state-digest"));
                request.reason=args.require("--reason");const auto disposition=args.require("--deferred");
                if(disposition!="require-empty"&&disposition!="retain")app_fail("INVALID_ARGUMENT","deferred disposition must be require-empty or retain");
                request.deferred_disposition=disposition=="retain"?"RETAIN_UNPROCESSED":"REQUIRE_EMPTY";
            }
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),request,io_options(args)));
        }
        if (command == "source-view-bindings") {
            args.require_only({"--control","--view","--presence","--grant","--instance","--grant-digest",
                "--binding-digest","--lineage-digest","--envelope","--offset","--selection","--limit","--max-bytes",
                "--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            ViewBindings q; q.view=args.require("--view");q.presence=args.get("--presence","all");
            q.grant=args.get("--grant","");q.envelope=args.get("--envelope","all");
            if(args.contains("--instance"))q.instance=parse_operation_id(args.require("--instance"));
            if(args.contains("--grant-digest"))q.grant_digest=parse_operation_id(args.require("--grant-digest"));
            if(args.contains("--binding-digest"))q.binding_digest=parse_operation_id(args.require("--binding-digest"));
            if(args.contains("--lineage-digest"))q.lineage_digest=parse_operation_id(args.require("--lineage-digest"));
            q.offset=static_cast<std::uint32_t>(parse_u64(args.get("--offset","0"),"offset",0U,256U));
            q.limit=static_cast<std::uint32_t>(parse_u64(args.get("--limit","16"),"limit",1U,32U));
            q.maximum_bytes=static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes","32768"),"max-bytes",2048U,60000U));
            if(args.contains("--selection"))q.selection=parse_operation_id(args.require("--selection"));
            validate_view_bindings(q);
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),ControlRequest(q),io_options(args)));
        }
        if (command == "source-view-inventory") {
            args.require_only({"--control","--presence","--lifecycle","--schedule","--view","--provider","--generation",
                "--source-scope","--target-scope","--author-uid","--offset","--selection","--limit","--max-bytes",
                "--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            SourceViewInventory q;
            q.presence=args.get("--presence","all"); q.lifecycle=args.get("--lifecycle","all"); q.schedule=args.get("--schedule","all");
            q.view=args.get("--view",""); q.provider=args.get("--provider",""); q.generation=args.get("--generation","");
            q.source_scope=args.get("--source-scope",""); q.target_scope=args.get("--target-scope","");
            if(args.contains("--author-uid")) q.author_uid=static_cast<std::uint32_t>(parse_u64(args.require("--author-uid"),"author UID",0U,4294967295ULL));
            q.offset=static_cast<std::uint32_t>(parse_u64(args.get("--offset","0"),"offset",0U,32U));
            q.limit=static_cast<std::uint32_t>(parse_u64(args.get("--limit","16"),"limit",1U,16U));
            q.maximum_bytes=static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes","32768"),"max-bytes",2048U,60000U));
            if(args.contains("--selection")) q.selection=parse_operation_id(args.require("--selection"));
            validate_source_view_inventory(q);
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),ControlRequest(q),io_options(args)));
        }
        if (command == "source-view-decisions" || command == "source-view-retry") {
            const bool review=command=="source-view-decisions";
            if(review)args.require_only({"--control","--view","--after-revision","--through-revision","--history-digest","--limit","--max-bytes","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            else args.require_only({"--control","--view","--expected-revision","--decision-revision","--decision-digest","--operation","--view-digest","--configuration-digest","--reason","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            ImportAutoRequest request;request.command=review?ImportAutoCommand::review:ImportAutoCommand::reconsider;request.view=args.require("--view");
            if(review){
                if(args.contains("--after-revision"))request.after_revision=parse_u64(args.require("--after-revision"),"after revision",0U,kImportRetainedHistoryLimit);
                if(args.contains("--through-revision")!=args.contains("--history-digest"))app_fail("INVALID_ARGUMENT","through revision and history digest must be supplied together");
                if(args.contains("--through-revision")){request.through_revision=parse_u64(args.require("--through-revision"),"through revision",1U,kImportRetainedHistoryLimit);request.history_digest=parse_operation_id(args.require("--history-digest"));}
                if(args.contains("--limit"))request.page_limit=static_cast<std::uint32_t>(parse_u64(args.require("--limit"),"page rows",1U,32U));
                if(args.contains("--max-bytes"))request.maximum_bytes=static_cast<std::uint32_t>(parse_u64(args.require("--max-bytes"),"page bytes",2048U,60000U));
            }else{
                request.revision=parse_u64(args.require("--expected-revision"),"schedule revision",1U,1024U);
                request.decision_revision=parse_u64(args.require("--decision-revision"),"decision revision",1U,1024U);
                request.decision_digest=parse_operation_id(args.require("--decision-digest"));
                request.outer_operation=parse_operation_id(args.require("--operation"));
                request.view_digest=parse_operation_id(args.require("--view-digest"));
                request.configuration_digest=parse_operation_id(args.require("--configuration-digest"));
                request.reason=args.require("--reason");
            }
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),request,io_options(args)));
        }
        if (command == "source-view-auto-enable" || command == "source-view-auto-pause" || command == "source-view-auto-status") {
            const bool status=command=="source-view-auto-status",enable=command=="source-view-auto-enable";
            args.require_only({"--control","--view","--expected-revision","--max-imports","--max-decisions","--minimum-interval-ms","--reason","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            if(!enable&&(args.contains("--max-imports")||args.contains("--max-decisions")||args.contains("--minimum-interval-ms")))app_fail("INVALID_ARGUMENT","grant limits only apply to enable");
            if(status&&(args.contains("--expected-revision")||args.contains("--reason")))app_fail("INVALID_ARGUMENT","status has no mutation selectors");
            ImportAutoRequest request;request.command=status?ImportAutoCommand::status:(enable?ImportAutoCommand::enable:ImportAutoCommand::pause);
            request.view=args.require("--view");
            if(!status){request.revision=parse_u64(args.require("--expected-revision"),"schedule revision",0U,1024U);request.reason=args.require("--reason");}
            if(enable){request.maximum_imports=static_cast<std::uint32_t>(parse_u64(args.require("--max-imports"),"import allowance",1U,128U));
                request.maximum_decisions=static_cast<std::uint32_t>(parse_u64(args.require("--max-decisions"),"inspection allowance",1U,256U));
                request.interval_ms=static_cast<std::uint32_t>(parse_u64(args.require("--minimum-interval-ms"),"minimum interval",10U,60000U));}
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),request,io_options(args)));
        }
        if (command == "source-view-import") {
            args.require_only({"--control","--view","--operation","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),
                SourceViewRequest{.view=args.require("--view"),.operation=parse_operation_id(args.require("--operation"))},io_options(args)));
        }
        if (command == "evidence-author" || command == "evidence-amend") {
            args.require_only({"--control", "--node", "--scope", "--operation", "--corrects",
                "--payload-text", "--payload-file", "--numeric-ticks", "--numeric-unit", "--numeric-scale",
                "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
            const auto local = args.require("--node");
            EvidenceRecord record{.operation_id = parse_operation_id(args.require("--operation")),
                .issuer = local, .recipient = local, .scope = args.require("--scope"),
                .corrects = std::nullopt, .payload = payload(args)};
            if (command == "evidence-amend") {
                record.corrects = parse_operation_id(args.require("--corrects"));
            } else if (args.contains("--corrects")) {
                app_fail("INVALID_ARGUMENT", "use evidence-amend to select a predecessor");
            }
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")), ControlAuthor{.record = std::move(record)},
                io_options(args)));
        }
        if (command == "submit" || command == "revise") {
            const auto request = ControlRequest(ControlSubmit{
                .record = control_record(args, command == "revise"),
            });
            const auto response = exchange_control_request(
                std::filesystem::path(args.require("--control")),
                request,
                io_options(args));
            return print_control_response(response);
        }
        if (command == "action-submit") {
            const auto request = ControlRequest(ControlSubmit{
                .record = action_control_record(args),
            });
            const auto response = exchange_control_request(
                std::filesystem::path(args.require("--control")),
                request,
                io_options(args));
            return print_control_response(response);
        }
        if (command == "config-activate" || command == "config-rollback") {
            args.require_only({"--control", "--candidate", "--generation", "--reason",
                "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
            const bool rollback = command == "config-rollback";
            if ((rollback && args.contains("--candidate")) ||
                (!rollback && args.contains("--generation"))) {
                app_fail("INVALID_ARGUMENT", "configuration command has conflicting selectors");
            }
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlConfiguration{
                    .candidate_path = rollback ? std::string{} :
                        std::filesystem::absolute(args.require("--candidate")).lexically_normal().string(),
                    .rollback_generation = rollback ? args.require("--generation") : std::string{},
                    .reason = args.require("--reason"),
                }), io_options(args)));
        }
        if(command=="consumer-retire" || command=="consumer-retirement-status") {
            ConsumerRequest request;request.name=args.require("--consumer");
            if(command=="consumer-retire") {
                args.require_only({"--control","--consumer","--instance","--expected-revision","--schedule-revision","--pending","--reason","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
                request.command=ConsumerCommand::retire;request.expected_instance=parse_operation_id(args.require("--instance"));
                request.expected_revision=parse_u64(args.require("--expected-revision"),"consumer revision",1U,std::numeric_limits<std::uint64_t>::max());
                request.expected_schedule_revision=parse_u64(args.require("--schedule-revision"),"schedule revision",0U,std::numeric_limits<std::uint64_t>::max());
                const auto pending=args.require("--pending");
                if(pending!="require-empty" && pending!="abandon"){app_fail("CONSUMER_PENDING_DISPOSITION_REQUIRED","pending must be require-empty or abandon");}
                request.abandon_pending=pending=="abandon";request.reason=args.require("--reason");
            }else {
                args.require_only({"--control","--consumer","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
                request.command=ConsumerCommand::retirement_status;
            }
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),ControlRequest(request),io_options(args)));
        }
        if(command=="projection-enable" || command=="projection-pause" || command=="projection-schedule-status") {
            ConsumerRequest request;request.name=args.require("--consumer");
            if(command=="projection-enable") {args.require_only({"--control","--consumer","--expected-generation","--reason","--max-pages","--min-interval-ms","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});}
            else if(command=="projection-pause") {args.require_only({"--control","--consumer","--expected-generation","--reason","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});}
            else {args.require_only({"--control","--consumer","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});}
            request.command=command=="projection-enable"?ConsumerCommand::projection_enable:
                command=="projection-pause"?ConsumerCommand::projection_pause:ConsumerCommand::projection_schedule_status;
            if(command!="projection-schedule-status") {request.reason=args.require("--reason");request.expected_revision=parse_u64(args.require("--expected-generation"),"expected generation",0U,32U);}
            if(command=="projection-enable") {request.automatic_maximum_pages=static_cast<std::uint32_t>(parse_u64(args.get("--max-pages","100"),"max pages",1U,10000U));
                request.automatic_minimum_interval_ms=static_cast<std::uint32_t>(parse_u64(args.get("--min-interval-ms","100"),"minimum interval",10U,60000U));}
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),ControlRequest(request),io_options(args)));
        }
        if (command == "publication-channel-create" ||
            command == "publication-channel-publish" ||
            command == "publication-channel-status" ||
            command == "publication-channel-auto-enable" ||
            command == "publication-channel-auto-pause" ||
            command == "publication-channel-auto-status" ||
            command == "publication-channel-new-epoch" ||
            command == "publication-channel-retire") {
            PublicationChannelRequest request;
            request.name = args.require("--channel");
            if (command == "publication-channel-create") {
                args.require_only({"--control","--channel","--consumer","--projection-instance",
                    "--peer","--scope","--max-publications","--reason","--deadline-ms",
                    "--read-quantum","--write-quantum","--receive-limit"});
                request.command = PublicationChannelCommand::create;
                request.projection_name = args.require("--consumer");
                request.projection_instance = parse_operation_id(
                    args.require("--projection-instance"));
                request.recipient = args.require("--peer");
                request.scope = args.require("--scope");
                request.maximum_publications = static_cast<std::uint32_t>(parse_u64(
                    args.get("--max-publications", "128"), "maximum publications", 1U,
                    kPublicationChannelMaximumRevisions));
                request.reason = args.require("--reason");
            } else if (command == "publication-channel-publish") {
                args.require_only({"--control","--channel","--instance",
                    "--expected-channel-revision","--expected-projection-revision",
                    "--expected-position","--result-digest","--deadline-ms",
                    "--read-quantum","--write-quantum","--receive-limit"});
                request.command = PublicationChannelCommand::publish;
                request.channel_instance = parse_operation_id(args.require("--instance"));
                request.expected_channel_revision = parse_u64(
                    args.require("--expected-channel-revision"), "channel revision", 1U,
                    std::numeric_limits<std::uint64_t>::max());
                request.expected_projection_revision = parse_u64(
                    args.require("--expected-projection-revision"), "projection revision", 1U,
                    std::numeric_limits<std::uint64_t>::max());
                request.expected_position = parse_u64(args.require("--expected-position"),
                    "processed position", 0U, std::numeric_limits<std::uint64_t>::max());
                request.expected_result_digest = parse_operation_id(
                    args.require("--result-digest"));
            } else if (command == "publication-channel-auto-enable" ||
                       command == "publication-channel-auto-pause") {
                if (command == "publication-channel-auto-enable") {
                    args.require_only({"--control","--channel","--instance",
                        "--expected-channel-revision","--expected-schedule-revision",
                        "--expected-grant-generation","--max-automatic-publications",
                        "--min-interval-ms","--reason","--deadline-ms",
                        "--read-quantum","--write-quantum","--receive-limit"});
                    request.command = PublicationChannelCommand::automatic_enable;
                    request.automatic_maximum_publications =
                        static_cast<std::uint32_t>(parse_u64(
                            args.get("--max-automatic-publications", "100"),
                            "automatic publication budget", 1U, 10'000U));
                    request.automatic_minimum_interval_ms =
                        static_cast<std::uint32_t>(parse_u64(
                            args.get("--min-interval-ms", "100"),
                            "automatic minimum interval", 10U, 60'000U));
                } else {
                    args.require_only({"--control","--channel","--instance",
                        "--expected-channel-revision","--expected-schedule-revision",
                        "--expected-grant-generation","--reason","--deadline-ms",
                        "--read-quantum","--write-quantum","--receive-limit"});
                    request.command = PublicationChannelCommand::automatic_pause;
                }
                request.channel_instance = parse_operation_id(args.require("--instance"));
                request.expected_channel_revision = parse_u64(
                    args.require("--expected-channel-revision"),
                    "channel revision", 1U,
                    std::numeric_limits<std::uint64_t>::max());
                request.expected_schedule_revision = parse_u64(
                    args.require("--expected-schedule-revision"),
                    "schedule revision", 0U,
                    std::numeric_limits<std::uint64_t>::max());
                request.expected_grant_generation = parse_u64(
                    args.require("--expected-grant-generation"),
                    "grant generation", 0U,
                    kPublicationChannelAutomaticGrantLimit);
                request.reason = args.require("--reason");
            } else if (command == "publication-channel-new-epoch") {
                args.require_only({"--control","--channel","--instance",
                    "--expected-channel-revision","--expected-epoch",
                    "--terminal-operation","--terminal-outcome",
                    "--expected-projection-revision","--expected-position",
                    "--result-digest","--reason","--deadline-ms",
                    "--read-quantum","--write-quantum","--receive-limit"});
                request.command = PublicationChannelCommand::new_epoch;
                request.channel_instance = parse_operation_id(args.require("--instance"));
                request.expected_channel_revision = parse_u64(
                    args.require("--expected-channel-revision"), "channel revision", 1U,
                    std::numeric_limits<std::uint64_t>::max());
                request.expected_epoch = parse_u64(args.require("--expected-epoch"),
                    "channel epoch", 1U, kPublicationChannelMaximumEpochs);
                request.terminal_operation = parse_operation_id(
                    args.require("--terminal-operation"));
                const auto outcome = args.require("--terminal-outcome");
                if (outcome == "rejected") { request.terminal_outcome = "REJECTED"; }
                else if (outcome == "cancelled") { request.terminal_outcome = "CANCELLED"; }
                else if (outcome == "expired") { request.terminal_outcome = "EXPIRED"; }
                else {
                    app_fail("PUBLICATION_CHANNEL_EPOCH_INVALID",
                        "terminal outcome must be rejected, cancelled, or expired");
                }
                request.expected_projection_revision = parse_u64(
                    args.require("--expected-projection-revision"), "projection revision", 1U,
                    std::numeric_limits<std::uint64_t>::max());
                request.expected_position = parse_u64(args.require("--expected-position"),
                    "processed position", 0U, std::numeric_limits<std::uint64_t>::max());
                request.expected_result_digest = parse_operation_id(
                    args.require("--result-digest"));
                request.reason = args.require("--reason");
            } else if (command == "publication-channel-retire") {
                args.require_only({"--control","--channel","--instance",
                    "--expected-channel-revision","--pending","--reason","--deadline-ms",
                    "--read-quantum","--write-quantum","--receive-limit"});
                request.command = PublicationChannelCommand::retire;
                request.channel_instance = parse_operation_id(args.require("--instance"));
                request.expected_channel_revision = parse_u64(
                    args.require("--expected-channel-revision"), "channel revision", 1U,
                    std::numeric_limits<std::uint64_t>::max());
                const auto pending = args.require("--pending");
                if (pending != "require-empty" && pending != "cancel") {
                    app_fail("PUBLICATION_CHANNEL_PENDING_DISPOSITION_REQUIRED",
                        "pending must be require-empty or cancel");
                }
                request.cancel_pending = pending == "cancel";
                request.reason = args.require("--reason");
            } else {
                args.require_only({"--control","--channel","--deadline-ms",
                    "--read-quantum","--write-quantum","--receive-limit"});
                request.command = command == "publication-channel-auto-status" ?
                    PublicationChannelCommand::automatic_status :
                    PublicationChannelCommand::status;
            }
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(request), io_options(args)));
        }
        if (command == "projection-publish") {
            args.require_only({"--control","--consumer","--instance","--expected-revision",
                "--expected-position","--result-digest","--peer","--scope","--deadline-ms",
                "--read-quantum","--write-quantum","--receive-limit"});
            ConsumerRequest request;
            request.command = ConsumerCommand::projection_publish;
            request.name = args.require("--consumer");
            request.expected_instance = parse_operation_id(args.require("--instance"));
            request.expected_revision = parse_u64(args.require("--expected-revision"),
                "expected revision", 1U, std::numeric_limits<std::uint64_t>::max());
            request.expected_position = parse_u64(args.require("--expected-position"),
                "expected position", 0U, std::numeric_limits<std::uint64_t>::max());
            request.expected_result_digest = parse_operation_id(args.require("--result-digest"));
            request.publication_recipient = args.require("--peer");
            request.publication_scope = args.require("--scope");
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(request), io_options(args)));
        }
        if (command == "projection-create" || command == "projection-process" || command == "projection-status" || command == "projection-rebuild") {
            ConsumerRequest request;request.name=args.require("--consumer");
            if(command=="projection-create") {
                args.require_only({"--control","--consumer","--issuer","--scope","--reason","--limit","--max-admissions","--definition","--unit","--scale","--max-abs-sum","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
                request.command=ConsumerCommand::projection_create;request.reason=args.require("--reason");
                request.selection.issuer=args.require("--issuer");request.selection.scope=args.require("--scope");
                request.selection.maximum_records=static_cast<std::uint32_t>(parse_u64(args.get("--limit","32"),"limit",1U,128U));
                request.maximum_admissions=parse_u64(args.get("--max-admissions","100000"),"max admissions",1U,1000000U);
                const auto definition=args.get("--definition","DOMAIN_SUMMARY_V1");
                if(definition=="NUMERIC_SUMMARY_V1"){
                    NumericDefinition numeric;numeric.unit=args.require("--unit");
                    numeric.scale=static_cast<std::uint8_t>(parse_u64(args.require("--scale"),"scale",0U,9U));
                    numeric.maximum_absolute_sum=parse_u64(args.get("--max-abs-sum","1000000000000000000"),"sum budget",1U,kNumericSumLimit);
                    validate_numeric_definition(numeric);request.numeric=numeric;
                    request.selection.include_payload=true;request.selection.payload_length=46U;
                }else if(definition!="DOMAIN_SUMMARY_V1" || args.contains("--unit") || args.contains("--scale") || args.contains("--max-abs-sum")){
                    app_fail("PROJECTION_DEFINITION_INVALID","select a supported immutable definition; numeric options require NUMERIC_SUMMARY_V1");
                }
            } else if(command=="projection-process") {
                args.require_only({"--control","--consumer","--batch","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
                request.command=ConsumerCommand::projection_process;request.batch_id=parse_operation_id(args.require("--batch"));
            } else if(command=="projection-rebuild") {
                args.require_only({"--control","--consumer","--expected-revision","--reason","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
                request.command=ConsumerCommand::projection_rebuild;request.reason=args.require("--reason");
                request.expected_revision=parse_u64(args.require("--expected-revision"),"expected revision",1U,std::numeric_limits<std::uint64_t>::max());
            } else {
                args.require_only({"--control","--consumer","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
                request.command=ConsumerCommand::projection_status;
            }
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),ControlRequest(request),io_options(args)));
        }
        if (command == "consumer-create" || command == "consumer-read" || command == "consumer-ack" ||
            command == "consumer-status" || command == "consumer-reset") {
            ConsumerRequest request;
            request.name = args.require("--consumer");
            if (command == "consumer-create") {
                args.require_only({"--control", "--consumer", "--reason", "--issuer", "--scope", "--start", "--limit", "--max-bytes", "--payload", "--payload-length", "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
                request.command = ConsumerCommand::create;
                auto& feed = request.selection;
                feed.issuer = args.get("--issuer", ""); feed.scope = args.get("--scope", "");
                const auto start = args.get("--start", "beginning");
                if (start != "beginning" && start != "now") { app_fail("CONSUMER_INVALID", "start must be beginning or now"); }
                feed.from_now = start == "now";
                feed.maximum_records = static_cast<std::uint32_t>(parse_u64(args.get("--limit", "32"), "limit", 1U, 128U));
                feed.maximum_response_bytes = static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes", "60000"), "max-bytes", 4096U, 60000U));
                feed.include_payload = yes_no_option(args, "--payload", false);
                feed.payload_length = static_cast<std::uint32_t>(parse_u64(args.get("--payload-length", feed.include_payload ? "4096" : "0"), "payload-length", 0U, 16384U));
                request.reason = args.require("--reason");
            } else if (command == "consumer-ack") {
                args.require_only({"--control", "--consumer", "--batch", "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
                request.command = ConsumerCommand::acknowledge; request.batch_id = parse_operation_id(args.require("--batch"));
            } else if (command == "consumer-reset") {
                args.require_only({"--control", "--consumer", "--start", "--expected-revision", "--reason", "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
                request.command = ConsumerCommand::reset; request.reason = args.require("--reason");
                const auto start = args.require("--start");
                if (start != "beginning" && start != "now") { app_fail("CONSUMER_INVALID", "start must be beginning or now"); }
                request.selection.from_now = start == "now";
                request.expected_revision = parse_u64(args.require("--expected-revision"), "expected revision", 1U, std::numeric_limits<std::uint64_t>::max());
            } else {
                args.require_only({"--control", "--consumer", "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
                request.command = command == "consumer-read" ? ConsumerCommand::read : ConsumerCommand::status;
            }
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")), ControlRequest(request), io_options(args)));
        }
        if (command == "evidence-feed") {
            args.require_only({"--control", "--start", "--issuer", "--scope", "--limit", "--max-bytes",
                "--payload", "--payload-length", "--cursor", "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
            EvidenceFeed feed;
            const auto start = args.get("--start", "beginning");
            if (start != "beginning" && start != "now") {
                app_fail("EVIDENCE_FEED_INVALID", "start must be beginning or now");
            }
            if (args.contains("--start") && args.contains("--cursor")) {
                app_fail("EVIDENCE_FEED_INVALID", "start and cursor are mutually exclusive");
            }
            feed.from_now = start == "now";
            feed.issuer = args.get("--issuer", ""); feed.scope = args.get("--scope", "");
            feed.maximum_records = static_cast<std::uint32_t>(parse_u64(args.get("--limit", "32"), "limit", 1U, 128U));
            feed.maximum_response_bytes = static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes", "60000"), "max-bytes", 4096U, 60000U));
            feed.include_payload = yes_no_option(args, "--payload", false);
            feed.payload_length = static_cast<std::uint32_t>(parse_u64(args.get("--payload-length", feed.include_payload ? "4096" : "0"), "payload-length", 0U, 16384U));
            feed.cursor = args.get("--cursor", "");
            validate_evidence_feed(feed);
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")), ControlRequest(feed), io_options(args)));
        }
        if (command == "source-envelope-inspect") {
            args.require_only({"--payload-file"});
            std::cout << inspect_source_envelope(read_payload_file(
                std::filesystem::path(args.require("--payload-file")), kMaximumEvidencePayloadBytes)) << '\n';
            return 0;
        }
        if (command == "source-subscription-request" ||
            command == "source-subscription-remote-status" ||
            command == "source-subscription-withdraw") {
            args.require_only({"--config", "--provider", "--grant",
                "--request-id", "--reason", "--lease-generation",
                "--instance", "--expected-revision", "--deadline-ms",
                "--read-quantum", "--write-quantum", "--receive-limit"});
            auto config = load_runtime_config(args.require("--config"));
            config.io = io_options(args);
            RemoteSourceSubscriptionRequest request;
            request.request_id = parse_operation_id(args.require("--request-id"));
            request.command = command == "source-subscription-request"
                ? RemoteSourceSubscriptionCommand::request
                : command == "source-subscription-remote-status"
                    ? RemoteSourceSubscriptionCommand::status
                    : RemoteSourceSubscriptionCommand::withdraw;
            request.grant = args.require("--grant");
            request.lease_generation = args.get("--lease-generation", "");
            if (request.command == RemoteSourceSubscriptionCommand::withdraw) {
                request.instance = parse_operation_id(args.require("--instance"));
                request.expected_revision = parse_u64(args.require("--expected-revision"),
                    "subscription revision", 1U, 65'536U);
                request.reason = args.require("--reason");
            } else if (request.command == RemoteSourceSubscriptionCommand::request) {
                request.reason = args.require("--reason");
                if (args.contains("--instance") || args.contains("--expected-revision")) {
                    app_fail("SOURCE_SUBSCRIPTION_REMOTE_REQUEST_INVALID",
                        "remote request does not accept an instance or revision");
                }
            } else {
                if (args.contains("--reason") || args.contains("--instance") ||
                    args.contains("--expected-revision")) {
                    app_fail("SOURCE_SUBSCRIPTION_REMOTE_REQUEST_INVALID",
                        "remote status accepts only an optional lease generation");
                }
            }
            const auto response = request_remote_source_subscription(
                config, args.require("--provider"), request);
            std::cout << remote_source_subscription_response_json(response) << '\n';
            return 0;
        }
        if (command == "source-subscription-inventory") {
            args.require_only({"--control","--lifecycle","--lease","--schedule","--outcome","--grant","--instance","--peer","--scope","--author-uid",
                "--offset","--selection","--limit","--max-bytes","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            SubscriptionInventory q;
            q.lifecycle=args.get("--lifecycle","all"); q.lease=args.get("--lease","all");
            q.schedule=args.get("--schedule","all"); q.outcome=args.get("--outcome","all");
            q.grant=args.get("--grant",""); q.recipient=args.get("--peer",""); q.scope=args.get("--scope","");
            if(args.contains("--author-uid")) q.author_uid=static_cast<std::uint32_t>(parse_u64(args.require("--author-uid"),"author UID",0U,4294967295ULL));
            if(args.contains("--instance")) q.instance=parse_operation_id(args.require("--instance"));
            q.offset=static_cast<std::uint32_t>(parse_u64(args.get("--offset","0"),"offset",0U,16U));
            q.limit=static_cast<std::uint32_t>(parse_u64(args.get("--limit","16"),"limit",1U,16U));
            q.maximum_bytes=static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes","32768"),"max-bytes",2048U,60000U));
            if(args.contains("--selection")) q.selection=parse_operation_id(args.require("--selection"));
            validate_subscription_inventory(q);
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),ControlRequest(q),io_options(args)));
        }
        if (command.starts_with("source-subscription-")) {
            args.require_only({"--control", "--grant", "--instance", "--expected-revision",
                "--reason", "--pending", "--expected-schedule-revision", "--expected-grant-generation",
                "--max-automatic-steps", "--min-interval-ms", "--deadline-ms", "--read-quantum",
                "--write-quantum", "--receive-limit", "--predecessor-grant", "--predecessor-lease",
                "--successor-lease", "--predecessor-state-digest", "--mapping-digest", "--expected-frontier",
                "--state-digest", "--terminal-digest", "--source-operation", "--delivery-operation", "--receipt-digest",
                "--response-format", "--predecessor-selector", "--state-selector"});
            SourceSubscriptionRequest request;
            if (command == "source-subscription-reconcile") { request.command = SourceSubscriptionCommand::reconcile; }
            else if (command == "source-subscription-succeed") { request.command = SourceSubscriptionCommand::succeed; }
            else if (command == "source-subscription-create") { request.command = SourceSubscriptionCommand::create; }
            else if (command == "source-subscription-step") { request.command = SourceSubscriptionCommand::step; }
            else if (command == "source-subscription-status") { request.command = SourceSubscriptionCommand::status; }
            else if (command == "source-subscription-retire") { request.command = SourceSubscriptionCommand::retire; }
            else if (command == "source-subscription-auto-enable") { request.command = SourceSubscriptionCommand::automatic_enable; }
            else if (command == "source-subscription-auto-pause") { request.command = SourceSubscriptionCommand::automatic_pause; }
            else if (command == "source-subscription-auto-status") { request.command = SourceSubscriptionCommand::automatic_status; }
            else { app_fail("UNKNOWN_COMMAND", command); }
            request.grant = args.require("--grant");
            const auto response_format = args.get("--response-format", "legacy");
            if (response_format != "legacy" && response_format != "compact") {
                app_fail("SOURCE_SELECTOR_INVALID", "response-format must be legacy or compact");
            }
            request.compact_response = response_format == "compact";
            const auto selected_state = [&](const std::string& legacy_flag, const std::string& structural_flag) {
                if (args.contains(legacy_flag) == args.contains(structural_flag)) {
                    app_fail("SOURCE_SELECTOR_INVALID", "supply exactly one legacy digest or typed structural selector");
                }
                request.structural_selector = args.contains(structural_flag);
                return request.structural_selector ? parse_source_state_selector(args.require(structural_flag)) :
                    parse_operation_id(args.require(legacy_flag));
            };
            const bool schedule_command = request.command == SourceSubscriptionCommand::automatic_enable ||
                request.command == SourceSubscriptionCommand::automatic_pause;
            if (request.command == SourceSubscriptionCommand::step || request.command == SourceSubscriptionCommand::retire ||
                schedule_command || request.command == SourceSubscriptionCommand::succeed ||
                request.command == SourceSubscriptionCommand::reconcile) {
                request.instance = parse_operation_id(args.require("--instance"));
                request.expected_revision = parse_u64(args.require("--expected-revision"), "subscription revision", 1U, 65'536U);
            }
            if (args.contains("--instance") && !request.instance) { app_fail("SOURCE_SUBSCRIPTION_INVALID", "unexpected instance"); }
            if (args.contains("--expected-revision") && request.expected_revision == 0U) { app_fail("SOURCE_SUBSCRIPTION_INVALID", "unexpected revision"); }
            if (schedule_command) {
                request.expected_schedule_revision = parse_u64(args.require("--expected-schedule-revision"),
                    "source schedule revision", 0U, 65'536U);
                request.expected_grant_generation = parse_u64(args.require("--expected-grant-generation"),
                    "source automation generation", 0U, kSourceSubscriptionAutomaticGrantLimit);
                if (request.command == SourceSubscriptionCommand::automatic_enable) {
                    request.automatic_maximum_steps = static_cast<std::uint32_t>(parse_u64(
                        args.get("--max-automatic-steps", "100"), "automatic source steps", 1U, 10'000U));
                    request.automatic_minimum_interval_ms = static_cast<std::uint32_t>(parse_u64(
                        args.get("--min-interval-ms", "100"), "automatic source interval", 10U, 60'000U));
                }
            } else if (args.contains("--expected-schedule-revision") ||
                args.contains("--expected-grant-generation") || args.contains("--max-automatic-steps") ||
                args.contains("--min-interval-ms")) {
                app_fail("SOURCE_SUBSCRIPTION_INVALID", "automatic schedule options require enable or pause");
            }
            if (request.command == SourceSubscriptionCommand::reconcile || request.command == SourceSubscriptionCommand::succeed || request.command == SourceSubscriptionCommand::create || request.command == SourceSubscriptionCommand::retire || schedule_command) {
                request.reason = args.require("--reason");
            } else if (args.contains("--reason")) { app_fail("SOURCE_SUBSCRIPTION_INVALID", "unexpected reason"); }
            if (request.command == SourceSubscriptionCommand::succeed) {
                request.predecessor_grant = args.require("--predecessor-grant");
                request.predecessor_lease = args.require("--predecessor-lease");
                request.successor_lease = args.require("--successor-lease");
                request.predecessor_state_digest = selected_state("--predecessor-state-digest", "--predecessor-selector");
                request.predecessor_mapping_digest = parse_operation_id(args.require("--mapping-digest"));
                request.expected_frontier = parse_u64(args.require("--expected-frontier"), "source frontier", 0U,
                    kSourceSubscriptionLimit * kSourceSubscriptionRecordLimit);
            } else if (args.contains("--predecessor-grant") || args.contains("--predecessor-lease") ||
                args.contains("--successor-lease") || args.contains("--predecessor-state-digest") || args.contains("--predecessor-selector") ||
                args.contains("--mapping-digest") || args.contains("--expected-frontier")) {
                app_fail("SOURCE_SUCCESSION_INVALID", "succession selectors require the succeed command");
            }
            if (request.command == SourceSubscriptionCommand::reconcile) {
                request.reconciliation_state_digest = selected_state("--state-digest", "--state-selector");
                request.terminal_digest = parse_operation_id(args.require("--terminal-digest"));
                request.source_operation = parse_operation_id(args.require("--source-operation"));
                request.delivery_operation = parse_operation_id(args.require("--delivery-operation"));
                request.receipt_digest = parse_operation_id(args.require("--receipt-digest"));
            } else if (args.contains("--state-digest") || args.contains("--state-selector") || args.contains("--terminal-digest") ||
                args.contains("--source-operation") || args.contains("--delivery-operation") || args.contains("--receipt-digest")) {
                app_fail("SOURCE_RECONCILIATION_INVALID", "receipt selectors require the reconcile command");
            }
            if (args.contains("--pending")) {
                if (request.command != SourceSubscriptionCommand::retire) { app_fail("SOURCE_SUBSCRIPTION_INVALID", "pending disposition only for retirement"); }
                const auto disposition = args.require("--pending");
                if (disposition != "require-empty" && disposition != "retain") { app_fail("SOURCE_SUBSCRIPTION_INVALID", "pending must be require-empty or retain"); }
                request.retain_pending = disposition == "retain";
            }
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),
                ControlRequest(request), io_options(args)));
        }
        if (command == "control-history") {
            args.require_only({"--control", "--section", "--ordinal", "--uid", "--request-id", "--event", "--offset", "--through", "--prefix-digest", "--limit", "--max-bytes",
                "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
            ControlHistoryRequest r; r.section=args.get("--section","decisions");
            if(args.contains("--ordinal")) r.ordinal=parse_u64(args.require("--ordinal"),"ordinal",1U,1000000U);
            if(args.contains("--uid")) r.uid=static_cast<std::uint32_t>(parse_u64(args.require("--uid"),"UID",0U,UINT32_MAX));
            if(args.contains("--request-id")) r.request_id=parse_operation_id(args.require("--request-id"));
            if(args.contains("--event")) r.configuration_event=parse_u64(args.require("--event"),"event",1U,256U);
            if(args.contains("--through")) r.through=parse_u64(args.require("--through"),"through",0U,1000000U);
            if(args.contains("--prefix-digest")) r.prefix=parse_operation_id(args.require("--prefix-digest"));
            r.offset=parse_u64(args.get("--offset","0"),"offset",0U,1000000U);
            r.limit=static_cast<std::uint32_t>(parse_u64(args.get("--limit","16"),"limit",1U,64U));
            r.maximum_bytes=static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes","60000"),"maximum bytes",2048U,60000U));
            validate_control_history(r);
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),
                ControlRequest(r),io_options(args)));
        }
        if (command == "configuration-history") {
            args.require_only({"--control", "--section", "--ordinal", "--event", "--offset", "--through", "--prefix-digest", "--limit", "--max-bytes",
                "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
            ConfigurationHistoryRequest r; r.section=args.get("--section","events");
            if(args.contains("--ordinal")) r.ordinal=parse_u64(args.require("--ordinal"),"ordinal",1U,1000000U);
            if(args.contains("--event")) r.configuration_event=parse_u64(args.require("--event"),"event",1U,1000000U);
            if(args.contains("--through")) r.through=parse_u64(args.require("--through"),"through",0U,1000000U);
            if(args.contains("--prefix-digest")) r.prefix=parse_operation_id(args.require("--prefix-digest"));
            r.offset=parse_u64(args.get("--offset","0"),"offset",0U,1000000U);
            r.limit=static_cast<std::uint32_t>(parse_u64(args.get("--limit","16"),"limit",1U,64U));
            r.maximum_bytes=static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes","60000"),"max-bytes",2048U,60000U));
            validate_configuration_history(r);
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),ControlRequest(r),io_options(args)));
        }
        if (command == "runtime-inventory") {
            args.require_only({"--control", "--section", "--peer", "--id", "--uid", "--offset", "--limit", "--max-bytes", "--selection",
                "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
            RuntimeInventory request; request.section=args.get("--section","peers"); request.peer=args.get("--peer",""); request.id=args.get("--id","");
            if(args.contains("--uid")) request.uid=static_cast<std::uint32_t>(parse_u64(args.require("--uid"),"uid",0U,4294967295ULL));
            request.offset=static_cast<std::uint32_t>(parse_u64(args.get("--offset","0"),"offset",0U,1000000U));
            request.limit=static_cast<std::uint32_t>(parse_u64(args.get("--limit","16"),"limit",1U,64U));
            request.maximum_bytes=static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes","60000"),"max-bytes",2048U,60000U));
            if(args.contains("--selection")) request.selection=parse_operation_id(args.require("--selection"));
            validate_runtime_inventory(request);
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),ControlRequest(request),io_options(args)));
        }
        if (command == "action-result-review") {
            args.require_only({"--control","--request","--provider","--scope","--candidate-count",
                "--candidate-root","--request-binding","--expected-configuration","--reason",
                "--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            ResultReviewRequest review{
                .request_operation_id=parse_operation_id(args.require("--request")),
                .provider=args.require("--provider"),.scope=args.require("--scope"),
                .candidate_count=parse_u64(args.require("--candidate-count"),"candidate count",0U,kResultReviewCandidateLimit),
                .candidate_root=datacube::parse_hex_digest32(args.require("--candidate-root"),"candidate root"),
                .request_binding=parse_operation_id(args.require("--request-binding")),
                .configuration=parse_operation_id(args.require("--expected-configuration")),
                .reason=args.require("--reason")};
            validate_result_review(review);
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),ControlRequest(review),io_options(args)));
        }
        if (command == "publication-channel-inventory") {
            args.require_only({"--control","--lifecycle","--schedule","--outcome","--name","--instance","--projection","--peer","--scope",
                "--offset","--selection","--limit","--max-bytes","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            PublicationInventory q;q.lifecycle=args.get("--lifecycle","all");q.schedule=args.get("--schedule","all");q.outcome=args.get("--outcome","all");
            q.name=args.get("--name","");q.projection=args.get("--projection","");q.recipient=args.get("--peer","");q.scope=args.get("--scope","");
            if(args.contains("--instance"))q.instance=parse_operation_id(args.require("--instance"));
            q.offset=static_cast<std::uint32_t>(parse_u64(args.get("--offset","0"),"offset",0U,80U));
            q.limit=static_cast<std::uint32_t>(parse_u64(args.get("--limit","16"),"limit",1U,32U));
            q.maximum_bytes=static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes","32768"),"max-bytes",2048U,60000U));
            if(args.contains("--selection"))q.selection=parse_operation_id(args.require("--selection"));
            validate_publication_inventory(q);
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),ControlRequest(q),io_options(args)));
        }
        if (command == "consumer-inventory") {
            args.require_only({"--control","--kind","--lifecycle","--name","--instance","--issuer","--scope",
                "--offset","--selection","--limit","--max-bytes","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            ConsumerInventory q;q.kind=args.get("--kind","all");q.lifecycle=args.get("--lifecycle","all");
            q.name=args.get("--name","");q.issuer=args.get("--issuer","");q.scope=args.get("--scope","");
            if(args.contains("--instance"))q.instance=parse_operation_id(args.require("--instance"));
            q.offset=static_cast<std::uint32_t>(parse_u64(args.get("--offset","0"),"offset",0U,80U));
            q.limit=static_cast<std::uint32_t>(parse_u64(args.get("--limit","16"),"limit",1U,32U));
            q.maximum_bytes=static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes","32768"),"max-bytes",2048U,60000U));
            if(args.contains("--selection"))q.selection=parse_operation_id(args.require("--selection"));
            validate_consumer_inventory(q);
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),ControlRequest(q),io_options(args)));
        }
        if (command == "action-result-review-history") {
            args.require_only({"--control","--request","--provider","--scope","--review",
                "--limit","--max-bytes","--offset","--through","--prefix-digest",
                "--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            ResultReviewHistory q;
            q.request_operation_id=parse_operation_id(args.require("--request"));
            q.provider=args.require("--provider"); q.scope=args.require("--scope");
            if(args.contains("--review")) q.review_id=parse_operation_id(args.require("--review"));
            q.limit=static_cast<std::uint32_t>(parse_u64(args.get("--limit","8"),"limit",1U,16U));
            q.maximum_bytes=static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes","32768"),"max-bytes",2048U,60000U));
            q.offset=parse_u64(args.get("--offset","0"),"offset",0U,16U);
            if(args.contains("--through")) q.through=parse_u64(args.require("--through"),"through",0U,16U);
            if(args.contains("--prefix-digest")) q.prefix=parse_operation_id(args.require("--prefix-digest"));
            validate_result_review_history(q);
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),ControlRequest(q),io_options(args)));
        }
        if (command == "action-result-review-status") {
            args.require_only({"--control","--review","--deadline-ms","--read-quantum","--write-quantum","--receive-limit"});
            const ResultReviewStatus review{parse_operation_id(args.require("--review"))};
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),ControlRequest(review),io_options(args)));
        }
        if (command == "action-result-discover") {
            args.require_only({"--control", "--request", "--provider", "--scope", "--limit", "--max-bytes", "--cursor",
                "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
            ActionResultDiscovery query{
                .request_operation_id=parse_operation_id(args.require("--request")),
                .provider=args.require("--provider"), .scope=args.require("--scope"),
                .limit=static_cast<std::uint32_t>(parse_u64(args.get("--limit","8"),"limit",1U,32U)),
                .maximum_response_bytes=static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes","32768"),"max-bytes",4096U,60000U)),
                .cursor=args.get("--cursor","")};
            validate_action_result_discovery(query);
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),ControlRequest(query),io_options(args)));
        }
        if (command == "action-result-query") {
            args.require_only({"--control", "--operation", "--request", "--provider", "--scope", "--max-bytes",
                "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
            ActionResultQuery query{
                .operation_id=parse_operation_id(args.require("--operation")),
                .request_operation_id=parse_operation_id(args.require("--request")),
                .provider=args.require("--provider"), .scope=args.require("--scope"),
                .maximum_response_bytes=static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes","16384"),"max-bytes",2048U,16384U))};
            validate_action_result_query(query);
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),ControlRequest(query),io_options(args)));
        }
        if (command == "action-query") {
            args.require_only({"--control", "--action", "--issuer", "--state", "--limit", "--max-bytes", "--cursor",
                "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
            ActionQuery query;
            if(args.contains("--action"))query.action_id=parse_operation_id(args.require("--action"));
            query.issuer=args.get("--issuer", "");query.state=args.get("--state", "");
            query.maximum_records=static_cast<std::uint32_t>(parse_u64(args.get("--limit","16"),"limit",1U,64U));
            query.maximum_response_bytes=static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes","60000"),"max-bytes",2048U,60000U));
            query.cursor=args.get("--cursor","");validate_action_query(query);
            return print_control_response(exchange_control_request(std::filesystem::path(args.require("--control")),ControlRequest(query),io_options(args)));
        }
        if (command == "outbox-query") {
            args.require_only({"--control", "--operation", "--peer", "--state", "--limit", "--max-bytes",
                "--history-limit", "--cursor", "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
            OutboxQuery query;
            if (args.contains("--operation")) query.operation_id = parse_operation_id(args.require("--operation"));
            query.recipient=args.get("--peer", ""); query.state=args.get("--state", "");
            query.maximum_records=static_cast<std::uint32_t>(parse_u64(args.get("--limit","32"),"limit",1U,64U));
            query.maximum_response_bytes=static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes","60000"),"max-bytes",4096U,60000U));
            query.history_limit=static_cast<std::uint32_t>(parse_u64(args.get("--history-limit","4"),"history-limit",0U,16U));
            query.cursor=args.get("--cursor", ""); validate_outbox_query(query);
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")), ControlRequest(query), io_options(args)));
        }
        if (command == "evidence-query") {
            args.require_only({"--control", "--view", "--issuer", "--scope", "--operation",
                "--limit", "--max-bytes", "--payload", "--payload-offset", "--payload-length",
                "--cursor", "--deadline-ms", "--read-quantum", "--write-quantum", "--receive-limit"});
            EvidenceQuery query;
            const auto view = args.get("--view", "current");
            if (view != "current" && view != "history") {
                app_fail("EVIDENCE_QUERY_INVALID", "view must be current or history");
            }
            query.history = view == "history";
            query.issuer = args.get("--issuer", "");
            query.scope = args.get("--scope", "");
            if (args.contains("--operation")) { query.operation_id = parse_operation_id(args.require("--operation")); }
            query.maximum_records = static_cast<std::uint32_t>(parse_u64(args.get("--limit", "32"), "limit", 1U, 128U));
            query.maximum_response_bytes = static_cast<std::uint32_t>(parse_u64(args.get("--max-bytes", "60000"), "max-bytes", 4096U, 60000U));
            query.include_payload = yes_no_option(args, "--payload", false);
            query.payload_offset = static_cast<std::uint32_t>(parse_u64(args.get("--payload-offset", "0"), "payload-offset", 0U, 60000U));
            query.payload_length = static_cast<std::uint32_t>(parse_u64(args.get("--payload-length", query.include_payload ? "4096" : "0"), "payload-length", 0U, 16384U));
            query.cursor = args.get("--cursor", "");
            validate_evidence_query(query);
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")), ControlRequest(query), io_options(args)));
        }
        if (command == "state-head") {
            args.require_only({"--control", "--deadline-ms", "--read-quantum",
                "--write-quantum", "--receive-limit"});
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlStateHead{}), io_options(args)));
        }
        if (command == "status") {
            args.require_only({
                "--control", "--deadline-ms", "--read-quantum",
                "--write-quantum", "--receive-limit", "--logical-digest",
            });
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlSnapshot{.logical_digest = yes_no_option(args, "--logical-digest", false)}),
                io_options(args)));
        }
        if (command == "compact") {
            args.require_only({
                "--control", "--deadline-ms", "--read-quantum",
                "--write-quantum", "--receive-limit",
            });
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlCompact{}),
                io_options(args)));
        }
        if (command == "wake") {
            args.require_only({
                "--control", "--peer", "--deadline-ms", "--read-quantum",
                "--write-quantum", "--receive-limit",
            });
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlWake{.peer = args.require("--peer")}),
                io_options(args)));
        }
        if (command == "rebind") {
            args.require_only({
                "--control", "--operation", "--generation", "--reason",
                "--deadline-ms", "--read-quantum", "--write-quantum",
                "--receive-limit", "--expected-state", "--expected-configuration",
            });
            const auto expected = (args.contains("--expected-state") ? std::optional<std::string>(args.require("--expected-state")) : std::nullopt);
            const auto configuration = (args.contains("--expected-configuration") ? std::optional<std::string>(args.require("--expected-configuration")) : std::nullopt);
            if (expected.has_value() != configuration.has_value()) {
                app_fail("OUTBOX_CONDITION_INVALID", "both --expected-state and --expected-configuration are required");
            }
            if (expected) {
                OutboxAdminRequest request;
                request.kind=OutboxAdminKind::rebind;
                request.operation=parse_operation_id(args.require("--operation"));
                request.expected_state=parse_operation_id(*expected);
                request.expected_configuration=parse_operation_id(*configuration);
                request.reason=args.require("--reason");
                request.generation=args.require("--generation");
                return print_control_response(exchange_control_request(
                    std::filesystem::path(args.require("--control")), ControlRequest(request), io_options(args)));
            }
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlRebind{
                    .operation_id = parse_operation_id(args.require("--operation")),
                    .generation = args.require("--generation"),
                    .reason = args.require("--reason"),
                }),
                io_options(args)));
        }
        if (command == "retry") {
            args.require_only({
                "--control", "--operation", "--reason",
                "--deadline-ms", "--read-quantum", "--write-quantum",
                "--receive-limit", "--expected-state", "--expected-configuration",
            });
            const auto expected = (args.contains("--expected-state") ? std::optional<std::string>(args.require("--expected-state")) : std::nullopt);
            const auto configuration = (args.contains("--expected-configuration") ? std::optional<std::string>(args.require("--expected-configuration")) : std::nullopt);
            if (expected.has_value() != configuration.has_value()) {
                app_fail("OUTBOX_CONDITION_INVALID", "both --expected-state and --expected-configuration are required");
            }
            if (expected) {
                OutboxAdminRequest request;
                request.kind=OutboxAdminKind::retry;
                request.operation=parse_operation_id(args.require("--operation"));
                request.expected_state=parse_operation_id(*expected);
                request.expected_configuration=parse_operation_id(*configuration);
                request.reason=args.require("--reason");
                return print_control_response(exchange_control_request(
                    std::filesystem::path(args.require("--control")), ControlRequest(request), io_options(args)));
            }
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlRetry{
                    .operation_id = parse_operation_id(args.require("--operation")),
                    .reason = args.require("--reason"),
                }),
                io_options(args)));
        }
        if (command == "custody-dispatch") {
            args.require_only({
                "--control", "--activation", "--activation-generation",
                "--receiver-request", "--dispatch-request", "--reason",
                "--deadline-ms", "--read-quantum", "--write-quantum",
                "--receive-limit",
            });
            const auto& generation_text = args.require("--activation-generation");
            const auto generation = parse_u64(generation_text,
                "activation-generation", 1U,
                std::numeric_limits<std::uint64_t>::max());
            if (std::to_string(generation) != generation_text) {
                app_fail("INVALID_ARGUMENT",
                    "activation-generation requires a canonical positive decimal integer");
            }
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlCustodyDispatch{
                    .activation_id = args.require("--activation"),
                    .activation_generation = generation,
                    .receiver_request_digest = parse_operation_id(
                        args.require("--receiver-request")),
                    .dispatch_request_digest = parse_operation_id(
                        args.require("--dispatch-request")),
                    .reason = args.require("--reason"),
                }),
                io_options(args)));
        }
        if (command == "custody-dispatch-status") {
            args.require_only({
                "--control", "--activation", "--activation-generation",
                "--dispatch-request", "--deadline-ms", "--read-quantum",
                "--write-quantum", "--receive-limit",
            });
            const auto& generation_text = args.require("--activation-generation");
            const auto generation = parse_u64(generation_text,
                "activation-generation", 1U,
                std::numeric_limits<std::uint64_t>::max());
            if (std::to_string(generation) != generation_text) {
                app_fail("INVALID_ARGUMENT",
                    "activation-generation requires a canonical positive decimal integer");
            }
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlCustodyDispatchStatus{
                    .activation_id = args.require("--activation"),
                    .activation_generation = generation,
                    .dispatch_request_digest = parse_operation_id(
                        args.require("--dispatch-request")),
                }),
                io_options(args)));
        }
        if (command == "custody-dispatch-inventory") {
            args.require_only({
                "--control", "--activation", "--activation-generation",
                "--cursor", "--limit", "--max-bytes", "--deadline-ms",
                "--read-quantum", "--write-quantum", "--receive-limit",
            });
            const auto& generation_text = args.require("--activation-generation");
            const auto generation = parse_u64(generation_text,
                "activation-generation", 1U,
                std::numeric_limits<std::uint64_t>::max());
            if (std::to_string(generation) != generation_text) {
                app_fail("INVALID_ARGUMENT",
                    "activation-generation requires a canonical positive decimal integer");
            }
            const auto limit = static_cast<std::uint32_t>(parse_u64(
                args.get("--limit", "32"), "dispatch inventory limit",
                1U, kMaximumCustodyDispatchInventoryRecords));
            const auto maximum_bytes = static_cast<std::uint32_t>(parse_u64(
                args.get("--max-bytes", "32768"),
                "dispatch inventory maximum bytes", 2'048U,
                kMaximumCustodyDispatchInventoryJsonBytes));
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlCustodyDispatchInventory{
                    .activation_id = args.require("--activation"),
                    .activation_generation = generation,
                    .cursor = args.contains("--cursor") ?
                        std::optional<datacube::Digest32>(parse_operation_id(
                            args.require("--cursor"))) : std::nullopt,
                    .limit = limit,
                    .maximum_bytes = maximum_bytes,
                }),
                io_options(args)));
        }
        if (command == "cancel") {
            args.require_only({
                "--control", "--operation", "--reason",
                "--deadline-ms", "--read-quantum", "--write-quantum",
                "--receive-limit", "--expected-state", "--expected-configuration",
            });
            const auto expected = (args.contains("--expected-state") ? std::optional<std::string>(args.require("--expected-state")) : std::nullopt);
            const auto configuration = (args.contains("--expected-configuration") ? std::optional<std::string>(args.require("--expected-configuration")) : std::nullopt);
            if (expected.has_value() != configuration.has_value()) {
                app_fail("OUTBOX_CONDITION_INVALID", "both --expected-state and --expected-configuration are required");
            }
            if (expected) {
                OutboxAdminRequest request;
                request.kind=OutboxAdminKind::cancel;
                request.operation=parse_operation_id(args.require("--operation"));
                request.expected_state=parse_operation_id(*expected);
                request.expected_configuration=parse_operation_id(*configuration);
                request.reason=args.require("--reason");
                return print_control_response(exchange_control_request(
                    std::filesystem::path(args.require("--control")), ControlRequest(request), io_options(args)));
            }
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlCancel{
                    .operation_id = parse_operation_id(args.require("--operation")),
                    .reason = args.require("--reason"),
                }),
                io_options(args)));
        }
        if (command == "action-cancel") {
            args.require_only({
                "--control", "--action", "--reason",
                "--deadline-ms", "--read-quantum", "--write-quantum",
                "--receive-limit", "--expected-state",
                "--expected-configuration",
            });
            const auto expected = args.contains("--expected-state") ?
                std::optional<std::string>(args.require("--expected-state")) :
                std::nullopt;
            const auto configuration = args.contains("--expected-configuration") ?
                std::optional<std::string>(args.require("--expected-configuration")) :
                std::nullopt;
            if (expected.has_value() != configuration.has_value()) {
                app_fail("ACTION_CONDITION_INVALID",
                    "both --expected-state and --expected-configuration are required");
            }
            if (expected) {
                return print_control_response(exchange_control_request(
                    std::filesystem::path(args.require("--control")),
                    ControlRequest(ActionAdminRequest{
                        .action = parse_operation_id(args.require("--action")),
                        .expected_state = parse_operation_id(*expected),
                        .expected_configuration = parse_operation_id(*configuration),
                        .reason = args.require("--reason"),
                    }),
                    io_options(args)));
            }
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlActionCancel{
                    .action_id = parse_operation_id(args.require("--action")),
                    .reason = args.require("--reason"),
                }),
                io_options(args)));
        }
        if (command == "quiesce" || command == "resume") {
            args.require_only({
                "--control", "--reason", "--deadline-ms", "--read-quantum",
                "--write-quantum", "--receive-limit",
            });
            const auto request = command == "quiesce" ?
                ControlRequest(ControlQuiesce{.reason = args.require("--reason")}) :
                ControlRequest(ControlResume{.reason = args.require("--reason")});
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                request,
                io_options(args)));
        }
        if (command == "drain-shutdown") {
            args.require_only({
                "--control", "--reason", "--drain-deadline-ms", "--final-state-head",
                "--correlation", "--deadline-ms", "--read-quantum", "--write-quantum",
                "--receive-limit",
            });
            const auto drain_deadline = static_cast<std::uint32_t>(parse_u64(
                args.require("--drain-deadline-ms"),
                "drain-deadline-ms", 1U, 600'000U));
            const bool final_state_head = yes_no_option(args, "--final-state-head", false);
            const auto correlation = args.contains("--correlation") ?
                std::optional<std::string>(args.require("--correlation")) : std::nullopt;
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlDrainShutdown{
                    .deadline_ms = drain_deadline,
                    .reason = args.require("--reason"),
                    .final_state_head = final_state_head,
                    .correlation = correlation,
                }),
                io_options(args)));
        }
        if (command == "shutdown") {
            args.require_only({
                "--control", "--final-state-head", "--correlation", "--deadline-ms", "--read-quantum",
                "--write-quantum", "--receive-limit",
            });
            const bool final_state_head = yes_no_option(args, "--final-state-head", false);
            const auto correlation = args.contains("--correlation") ?
                std::optional<std::string>(args.require("--correlation")) : std::nullopt;
            return print_control_response(exchange_control_request(
                std::filesystem::path(args.require("--control")),
                ControlRequest(ControlShutdown{
                    .final_state_head = final_state_head,
                    .correlation = correlation,
                }),
                io_options(args)));
        }
        if (command == "offer" || command == "correct") {
            const auto result = send_evidence(
                send_options(args, command == "correct"));
            return print_state_conditioned_response(
                send_result_json(result));
        }
        if (command == "flush") {
            const auto result = flush_outbox(flush_options(args));
            return print_state_conditioned_response(
                flush_result_json(result));
        }
        if (command == "inspect") {
            args.require_only({"--state", "--node", "--max-journal-bytes"});
            NodeState state(
                std::filesystem::path(args.require("--state")),
                args.require("--node"),
                journal_limit(args));
            return print_state_conditioned_response(
                state_snapshot_json(state.snapshot()));
        }
        if (command == "serve") {
            args.require_only({
                "--state", "--node", "--listen", "--deadline-ms",
                "--read-quantum", "--write-quantum", "--receive-limit",
                "--max-journal-bytes", "--workers", "--queue-capacity",
                "--max-connections", "--idle-timeout-ms", "--backlog",
            });
            ServerOptions options{
                .state_directory = std::filesystem::path(args.require("--state")),
                .local_node = args.require("--node"),
                .listen_locator = parse_tcp_transport_locator(args.require("--listen"), true),
                .io = io_options(args),
                .maximum_journal_bytes = journal_limit(args),
                .workers = static_cast<std::size_t>(parse_u64(
                    args.get("--workers", "4"), "workers", 1U, 32U)),
                .queue_capacity = static_cast<std::size_t>(parse_u64(
                    args.get("--queue-capacity", "64"),
                    "queue-capacity", 1U, 4096U)),
                .maximum_connections = static_cast<std::size_t>(parse_u64(
                    args.get("--max-connections", "0"),
                    "max-connections", 0U, 1'000'000U)),
                .idle_timeout = parse_milliseconds(
                    args.get("--idle-timeout-ms", "0"),
                    "idle-timeout-ms", 0U, 3'600'000U),
                .backlog = static_cast<int>(parse_u64(
                    args.get("--backlog", "64"), "backlog", 1U, 1024U)),
            };
            return run_server(options);
        }
        app_fail("UNKNOWN_COMMAND", command);
    } catch (const AuthenticatedPeerError& error) {
        std::cout << error_json(error.code(), error.detail()) << '\n';
        return 3;
    } catch (const AppError& error) {
        std::cout << error_json(error.code(), error.what()) << '\n';
        return 3;
    } catch (const datacube::Failure& error) {
        std::cout << error_json(error.code(), error.what()) << '\n';
        return 4;
    } catch (const std::exception& error) {
        std::cout << error_json("UNEXPECTED_EXCEPTION", error.what()) << '\n';
        return 5;
    }
}

namespace natrav::packet_link {
[[nodiscard]] int finite_packet_link_revision_abi() noexcept;
}
namespace natrav_overlay {
[[nodiscard]] int owned_complete_datagram_packet_port_revision_abi() noexcept;
[[nodiscard]] int packet_link_ordered_stream_revision_abi() noexcept;
[[nodiscard]] int udp_packet_carrier_revision_abi() noexcept;
[[nodiscard]] int unix_datagram_packet_carrier_revision_abi() noexcept;
[[nodiscard]] int supervised_external_packet_adapter_revision_abi() noexcept;
}
namespace {
[[gnu::used]] constexpr char kFinitePacketLinkRevisionMarker[] =
    "FINITE_PACKET_LINK_SERVICE_V1";
[[gnu::used]] auto* const kFinitePacketLinkRevisionAbiAnchor =
    &natrav::packet_link::finite_packet_link_revision_abi;
[[gnu::used]] constexpr char kOwnedCompleteDatagramPacketPortRevisionMarker[] =
    "OWNED_COMPLETE_DATAGRAM_PACKET_PORT_V1";
[[gnu::used]] auto* const kOwnedCompleteDatagramPacketPortRevisionAbiAnchor =
    &natrav_overlay::owned_complete_datagram_packet_port_revision_abi;
[[gnu::used]] constexpr char kPacketLinkOrderedStreamRevisionMarker[] =
    "PACKET_LINK_ORDERED_BYTE_STREAM_ADAPTER_V1";
[[gnu::used]] auto* const kPacketLinkOrderedStreamRevisionAbiAnchor =
    &natrav_overlay::packet_link_ordered_stream_revision_abi;
[[gnu::used]] constexpr char kUdpPacketCarrierRevisionMarker[] =
    "NUMERIC_POINT_TO_POINT_UDP_PACKET_CARRIER_V1";
[[gnu::used]] auto* const kUdpPacketCarrierRevisionAbiAnchor =
    &natrav_overlay::udp_packet_carrier_revision_abi;
[[gnu::used]] constexpr char kUnixDatagramPacketCarrierRevisionMarker[] =
    "OWNER_CONTROLLED_UNIX_DATAGRAM_PACKET_CARRIER_V1";
[[gnu::used]] auto* const kUnixDatagramPacketCarrierRevisionAbiAnchor =
    &natrav_overlay::unix_datagram_packet_carrier_revision_abi;
[[gnu::used]] constexpr char kSupervisedExternalPacketAdapterRevisionMarker[] =
    "SUPERVISED_EXTERNAL_PACKET_ADAPTER_V1";
[[gnu::used]] auto* const kSupervisedExternalPacketAdapterRevisionAbiAnchor =
    &natrav_overlay::supervised_external_packet_adapter_revision_abi;
}

