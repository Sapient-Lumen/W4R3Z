#include "custody_authority.hpp"

namespace natrav_overlay {
namespace {

void require(const bool condition, const std::string_view code,
    const std::string_view detail) {
    if (!condition) { app_fail(code, detail); }
}

} // namespace

datacube::Digest32 custody_party_configured_pin(
    const RuntimeConfig& config, const CustodyParty& party,
    const bool require_active) {
    if (party.node == config.local_node) {
        require(party.signing_generation == config.local_identity_generation,
            "CUSTODY_PARTY_NOT_AUTHORIZED",
            "local custody party names a different signing generation");
        return config.identity.expected_spki_sha256;
    }
    const auto* generation = find_peer_generation(
        config, party.node, party.signing_generation);
    require(generation != nullptr,
        "CUSTODY_PARTY_NOT_AUTHORIZED",
        "custody party signing generation is not retained");
    require(generation->state != KeyGenerationState::revoked,
        "CUSTODY_PARTY_REVOKED",
        "custody party signing generation is revoked");
    require(!require_active || generation->state == KeyGenerationState::active,
        "CUSTODY_PARTY_RETIRED",
        "custody party signing generation is not active");
    return generation->spki_sha256;
}

void require_custody_party_authorized(
    const RuntimeConfig& config, const CustodyParty& party,
    const bool require_active) {
    const auto expected = custody_party_configured_pin(
        config, party, require_active);
    require(custody_party_signing_pin(party) == expected,
        "CUSTODY_PARTY_KEY_MISMATCH",
        "custody party key does not match accepted configuration");
}

const CustodyRelayGrant& resolve_custody_grant_reference(
    const RuntimeConfig& config, const CustodyGrantReference& reference,
    const CustodyEnvelope& envelope, const std::size_t hop_index,
    const bool require_active) {
    require(config.format_version >= 21U,
        "CUSTODY_POLICY_REQUIRED",
        "durable custody requires accepted V21 configuration");
    const auto* grant = find_custody_relay_grant(config.custody_relay,
        reference.id, reference.generation);
    require(grant != nullptr &&
            custody_relay_grant_commitment(*grant) == reference.commitment,
        "CUSTODY_GRANT_REFERENCE_REJECTED",
        "custody grant reference is absent or has different meaning");
    require_custody_relay_grant_use(
        *grant, envelope, hop_index, require_active);
    require_custody_party_authorized(
        config, envelope.route[hop_index], false);
    require_custody_party_authorized(
        config, envelope.route[hop_index + 1U], false);
    return *grant;
}

void require_custody_registration_authority(
    const RuntimeConfig& config, const CustodyEnvelope& envelope,
    const std::span<const CustodyGrantReference> grants,
    const bool require_active) {
    require(config.format_version >= 21U,
        "CUSTODY_POLICY_REQUIRED",
        "durable custody requires accepted V21 configuration");
    require(grants.size() + 1U == envelope.route.size(),
        "CUSTODY_GRANT_REFERENCE_REJECTED",
        "one exact grant reference is required per route transition");
    for (const auto& party : envelope.route) {
        require_custody_party_authorized(config, party, false);
    }
    for (std::size_t hop = 0U; hop < grants.size(); ++hop) {
        static_cast<void>(resolve_custody_grant_reference(
            config, grants[hop], envelope, hop, require_active));
    }
}

} // namespace natrav_overlay
