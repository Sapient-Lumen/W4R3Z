#include "publication_inventory.hpp"
#include "journal.hpp"
#include "config.hpp"
#include "submission_work.hpp"

#include <algorithm>
#include <chrono>
#include <vector>

namespace natrav_overlay {
namespace {
using Digest = datacube::Digest32;
using Bytes = datacube::Octets;
constexpr std::size_t kOwnerBound = kPublicationChannelUidLimit + kRetiredPublicationChannelUidLimit;
constexpr std::size_t kPrincipalReserve = 384U;
void require(bool condition, std::string_view code, std::string_view detail) {
    if (!condition) app_fail(code, detail);
}
void text(Bytes& b, std::string_view s) {
    datacube::append_be16(b, static_cast<std::uint16_t>(s.size())); datacube::append_text(b, s);
}
std::string text(datacube::Reader& r, std::size_t maximum) {
    const auto n = r.read_be16("text length");
    require(n <= maximum, "PUBLICATION_INVENTORY_INVALID", "text exceeds bound");
    return datacube::octets_text(r.read_exact(n, "text"), "text", true);
}
void digest(Bytes& b, const Digest& d) { datacube::append_octets(b, d.octets); }
Digest digest(datacube::Reader& r) {
    Digest d{}; const auto b = r.read_exact(32U, "digest");
    std::copy(b.begin(), b.end(), d.octets.begin()); return d;
}
void optional_digest(Bytes& b, const std::optional<Digest>& d) {
    datacube::append_u8(b, d ? 1U : 0U); if (d) digest(b, *d);
}
std::optional<Digest> optional_digest(datacube::Reader& r) {
    const auto flag = r.read_u8("optional");
    require(flag <= 1U, "PUBLICATION_INVENTORY_INVALID", "invalid optional marker");
    return flag ? std::optional<Digest>{digest(r)} : std::nullopt;
}
bool valid_name(std::string_view s) {
    return !s.empty() && s.size() <= 64U && s != "." && s != ".." &&
        std::all_of(s.begin(), s.end(), [](char c) {
            return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '.';
        });
}
std::string hex(const Digest& d) { return json_string(datacube::hex_lower(d)); }
std::string hex(const std::optional<Digest>& d) { return d ? hex(*d) : "null"; }
std::string number(const std::optional<std::uint64_t>& n) { return n ? std::to_string(*n) : "null"; }
std::string str(const std::optional<std::string>& s) { return s ? json_string(*s) : "null"; }
std::string lower(std::string_view s) {
    std::string out(s);
    for (auto& c : out) if (c >= 'A' && c <= 'Z') c = static_cast<char>(c - 'A' + 'a');
    return out;
}
bool visible(const DurableConsumer& p, const EvidenceReadAccess& access) {
    // The complete adopted authority must still match: old source/result
    // frontiers must not escape under newly narrowed permissions.
    const bool payload = p.selection.include_payload || p.projection->numeric.has_value();
    return !p.adoptions.empty() && p.adoptions.back().authority == access.digest &&
        access.metadata_allowed && (!payload || access.payload_allowed) &&
        evidence_read_allows(access, p.selection.issuer, p.selection.scope, payload);
}
std::string_view schedule_state(const PublicationChannel& c) {
    return c.automatic_grants.empty() ? "NONE" : std::string_view(c.automatic_grants.back().state);
}
bool matches(const PublicationChannel& c, const PublicationInventory& q, std::string_view outcome) {
    return (q.lifecycle == "all" || q.lifecycle == (c.retirement ? "retired" : "active")) &&
        (q.schedule == "all" || q.schedule == lower(schedule_state(c))) &&
        (q.outcome == "all" || q.outcome == lower(outcome)) &&
        (q.name.empty() || q.name == c.name) && (!q.instance || *q.instance == c.instance) &&
        (q.projection.empty() || q.projection == c.projection_name) &&
        (q.recipient.empty() || q.recipient == c.recipient) && (q.scope.empty() || q.scope == c.scope);
}
std::string head_json(const PublicationChannel& c, const StoredOutbound* o) {
    if (c.publications.empty()) return "null";
    const auto& h = c.publications.back();
    require(o && o->record.operation_id == h.operation_id && o->record_digest == h.record_digest &&
        o->record.recipient == c.recipient && o->record.scope == c.scope,
        "STATE_INDEX_CORRUPT", "publication head does not match its durable outbox record");
    std::string out = "{\"sequence\":" + std::to_string(h.sequence) + ",\"epoch\":" + std::to_string(h.epoch) +
        ",\"operation_id\":" + hex(h.operation_id) + ",\"record_digest\":" + hex(h.record_digest) +
        ",\"corrects\":" + hex(h.corrects) +
        ",\"published_projection_revision\":" + std::to_string(h.projection_revision) +
        ",\"published_position\":" + std::to_string(h.processed_position) +
        ",\"recipient_generation_at_publication\":" + json_string(h.recipient_generation) +
        ",\"recipient_spki_at_publication\":" + hex(h.recipient_spki_sha256) +
        ",\"prior_epoch_terminal_operation\":" + hex(h.prior_epoch_terminal_operation) +
        ",\"prior_epoch_terminal_outcome\":" + (h.prior_epoch_terminal_outcome.empty() ? "null" : json_string(h.prior_epoch_terminal_outcome)) +
        ",\"automatic\":" + (h.automatic ? "true" : "false") +
        ",\"automatic_grant_generation\":" + std::to_string(h.automatic_grant_generation) +
        ",\"configuration_event\":" + std::to_string(h.configuration_event) +
        ",\"unix_ms\":" + std::to_string(h.unix_ms) +
        ",\"outbound_status\":" + json_string(outbound_status_name(*o)) + ",\"delivery\":";
    if (o->delivery) {
        const auto& d = *o->delivery;
        out += "{\"recipient_generation\":" + str(d.policy.peer_generation) +
            ",\"recipient_spki_sha256\":" + hex(d.policy.peer_spki_sha256) +
            ",\"attempts\":" + std::to_string(d.attempts) +
            ",\"last_attempt_unix_ms\":" + number(d.last_attempt_unix_ms) +
            ",\"next_attempt_unix_ms\":" + std::to_string(d.next_attempt_unix_ms) +
            ",\"expires_unix_ms\":" + std::to_string(d.policy.expires_unix_ms) +
            ",\"last_error_code\":" + json_string(d.last_error_code) +
            ",\"cancelled_unix_ms\":" + number(d.cancelled_unix_ms) +
            ",\"expired_unix_ms\":" + number(d.expired_unix_ms) +
            ",\"transition_count\":" + std::to_string(d.transitions.size()) + "}";
    } else out += "null";
    out += ",\"receipt\":";
    if (o->receipt) {
        const auto& receipt = *o->receipt;
        out += "{\"sequence\":" + std::to_string(receipt.sequence) +
            ",\"record_digest\":" + hex(receipt.record_digest) + "}";
    } else out += "null";
    return out + "}";
}
std::string summary(const PublicationChannel& c, const DurableConsumer& p, const StoredOutbound* o,
                    std::size_t ordinal) {
    // Do not use channel_json/consumer_json or any encoder for complete
    // histories, results, source payloads or dynamic eligibility assessment.
    std::string out = "{\"ordinal\":" + std::to_string(ordinal) + ",\"name\":" + json_string(c.name) +
        ",\"owner_uid\":" + std::to_string(c.uid) + ",\"instance\":" + hex(c.instance) +
        ",\"lifecycle\":" + json_string(c.retirement ? "RETIRED" : "ACTIVE") +
        ",\"channel_revision\":" + std::to_string(c.revision) +
        ",\"epoch\":" + std::to_string(c.publications.empty() ? 1U : c.publications.back().epoch) +
        ",\"projection_name\":" + json_string(c.projection_name) +
        ",\"projection_instance\":" + hex(c.projection_instance) +
        ",\"projection_definition_digest\":" + hex(c.projection_definition_digest) +
        ",\"projection_definition\":" + json_string(p.projection->numeric ? "NUMERIC_SUMMARY_V1" : "DOMAIN_SUMMARY_V1") +
        ",\"projection_lifecycle\":" + json_string(p.retirement ? "RETIRED" : "ACTIVE") +
        ",\"projection_revision\":" + std::to_string(p.revision) +
        ",\"projection_position\":" + std::to_string(p.position) +
        ",\"recipient\":" + json_string(c.recipient) + ",\"scope\":" + json_string(c.scope) +
        ",\"key_policy\":\"ACTIVE_AT_PUBLISH\",\"maximum_publications\":" + std::to_string(c.maximum_publications) +
        ",\"publications\":" + std::to_string(c.publications.size()) +
        ",\"remaining_publications\":" + std::to_string(c.maximum_publications - c.publications.size()) +
        ",\"created_configuration_event\":" + std::to_string(c.created_configuration_event) +
        ",\"created_unix_ms\":" + std::to_string(c.created_unix_ms) +
        ",\"configuration_event\":" + std::to_string(c.configuration_event) +
        ",\"unix_ms\":" + std::to_string(c.unix_ms) + ",\"actor_uid\":" + std::to_string(c.actor_uid) +
        ",\"pid\":" + std::to_string(c.pid) + ",\"last_transition\":" + json_string(c.transition) +
        ",\"head\":" + head_json(c, o) +
        ",\"schedule_revision\":" + std::to_string(c.automatic_schedule_revision) +
        ",\"retained_grants\":" + std::to_string(c.automatic_grants.size()) +
        ",\"schedule_state\":" + json_string(schedule_state(c)) + ",\"grant\":";
    if (!c.automatic_grants.empty()) {
        const auto& g = c.automatic_grants.back();
        out += "{\"generation\":" + std::to_string(g.generation) +
            ",\"maximum_publications\":" + std::to_string(g.maximum_publications) +
            ",\"used_publications\":" + std::to_string(g.publications) +
            ",\"remaining_publications\":" + std::to_string(g.maximum_publications - g.publications) +
            ",\"minimum_interval_ms\":" + std::to_string(g.minimum_interval_ms) +
            ",\"error_code\":" + json_string(g.error) +
            ",\"configuration_event\":" + std::to_string(g.configuration_event) +
            ",\"ended_configuration_event\":" + std::to_string(g.ended_configuration_event) +
            ",\"ended_unix_ms\":" + std::to_string(g.ended_unix_ms) + "}";
    } else out += "null";
    out += ",\"retirement\":";
    if (c.retirement) {
        const auto& t = *c.retirement;
        out += "{\"revision\":" + std::to_string(t.revision) +
            ",\"configuration_event\":" + std::to_string(t.configuration_event) +
            ",\"unix_ms\":" + std::to_string(t.unix_ms) +
            ",\"pid\":" + std::to_string(t.pid) +
            ",\"cancelled_pending\":" + (t.cancelled_pending ? "true" : "false") +
            ",\"cancelled_operation\":" + hex(t.cancelled_operation) + "}";
    } else out += "null";
    return out + "}";
}
} // namespace

void validate_publication_inventory(const PublicationInventory& q) {
    require((q.lifecycle == "all" || q.lifecycle == "active" || q.lifecycle == "retired") &&
        (q.schedule == "all" || q.schedule == "none" || q.schedule == "enabled" || q.schedule == "paused" || q.schedule == "blocked" || q.schedule == "exhausted") &&
        (q.outcome == "all" || q.outcome == "none" || q.outcome == "pending" || q.outcome == "acked" || q.outcome == "rejected" || q.outcome == "cancelled" || q.outcome == "expired") &&
        (q.name.empty() || valid_name(q.name)) && (q.projection.empty() || valid_name(q.projection)) &&
        (q.recipient.empty() || valid_node_id(q.recipient)) && (q.scope.empty() || valid_scope(q.scope)) &&
        (!q.instance || !digest_is_zero(*q.instance)) && q.limit >= 1U && q.limit <= 32U &&
        q.maximum_bytes >= 2048U && q.maximum_bytes <= 60000U && q.offset <= kOwnerBound &&
        (!q.selection || !digest_is_zero(*q.selection)),
        "PUBLICATION_INVENTORY_INVALID", "invalid exact filter or page bound");
    require(q.offset == 0U || q.selection.has_value(), "PUBLICATION_INVENTORY_SELECTION_REQUIRED", "continuation requires selection digest");
}
Bytes encode_publication_inventory(const PublicationInventory& q) {
    validate_publication_inventory(q); Bytes b; datacube::append_text(b, "PIN1");
    text(b, q.lifecycle); text(b, q.schedule); text(b, q.outcome); text(b, q.name);
    text(b, q.projection); text(b, q.recipient); text(b, q.scope); optional_digest(b, q.instance);
    datacube::append_be32(b, q.offset); datacube::append_be32(b, q.limit); datacube::append_be32(b, q.maximum_bytes);
    optional_digest(b, q.selection); return b;
}
PublicationInventory decode_publication_inventory(datacube::OctetView b) {
    try {
        datacube::Reader r(b, "publication inventory");
        require(datacube::octets_text(r.read_exact(4U, "magic"), "magic", true) == "PIN1", "PUBLICATION_INVENTORY_INVALID", "unknown version");
        PublicationInventory q;
        q.lifecycle = text(r, 16U); q.schedule = text(r, 16U); q.outcome = text(r, 16U);
        q.name = text(r, 64U); q.projection = text(r, 64U); q.recipient = text(r, 64U); q.scope = text(r, 128U);
        q.instance = optional_digest(r); q.offset = r.read_be32("offset"); q.limit = r.read_be32("limit"); q.maximum_bytes = r.read_be32("max bytes");
        q.selection = optional_digest(r); r.require_eof("publication inventory"); validate_publication_inventory(q); return q;
    } catch (const datacube::Failure&) { app_fail("PUBLICATION_INVENTORY_INVALID", "malformed or truncated request"); }
}
std::string NodeState::publication_inventory(const PublicationInventory& q, const RuntimeConfig& cfg,
    std::uint32_t uid, std::chrono::steady_clock::time_point deadline) const {
    validate_publication_inventory(q);
    require(cfg.format_version >= 12U, "PUBLICATION_CHANNEL_POLICY_VERSION_REQUIRED", "inventory requires V12 or newer");
    const auto access = evidence_read_access(cfg.evidence_read, cfg.local_control, uid);
    require(local_control_allows(cfg.local_control, uid, LocalControlClass::projection) &&
        local_control_allows(cfg.local_control, uid, LocalControlClass::consumer) && access.scoped && access.metadata_allowed,
        "LOCAL_CONTROL_CLASS_DENIED", "projection, consumer and scoped metadata-read authority required");
    const auto configuration = runtime_configuration_digest(canonical_runtime_config(cfg));
    std::lock_guard<std::mutex> lock(mutex_);
    require(!poisoned_, "STATE_UNAVAILABLE", "writer requires restart");
    const auto check_time = [&]() { require(std::chrono::steady_clock::now() < deadline, "PUBLICATION_INVENTORY_DEADLINE", "inventory exceeded deadline"); };
    check_time(); SubmissionWork work; SubmissionWorkScope measure(work);
    std::vector<std::string> selected;
    std::size_t owned = 0U;
    const auto prefix = std::to_string(uid) + ":";
    const auto exact_key = publication_channel_key(uid, q.name);
    for (auto it = publication_channels_.lower_bound(q.name.empty() ? prefix : exact_key);
         it != publication_channels_.end() && it->first.starts_with(prefix); ++it) {
        if (!q.name.empty() && it->first != exact_key) break;
        check_time(); const auto& c = it->second;
        require(++owned <= kOwnerBound && c.uid == uid, "STATE_INDEX_CORRUPT", "owned channel registry bound");
        const auto p = consumers_.find(consumer_key(uid, c.projection_name));
        require(p != consumers_.end() && p->second.projection && p->second.uid == uid &&
            p->second.instance == c.projection_instance && p->second.projection->definition_digest == c.projection_definition_digest,
            "STATE_INDEX_CORRUPT", "channel projection binding missing");
        if (!visible(p->second, access)) continue;
        // Filter immutable fields before looking up a head. No hidden-domain
        // work counts, offsets or commitments are exposed to this reader.
        if ((!q.name.empty() && q.name != c.name) || (q.instance && *q.instance != c.instance) ||
            (!q.projection.empty() && q.projection != c.projection_name) ||
            (!q.recipient.empty() && q.recipient != c.recipient) || (!q.scope.empty() && q.scope != c.scope)) continue;
        const StoredOutbound* outbound = nullptr;
        if (!c.publications.empty()) {
            const auto f = outbound_index_.find(datacube::hex_lower(c.publications.back().operation_id));
            require(f != outbound_index_.end(), "STATE_INDEX_CORRUPT", "publication head missing");
            outbound = &outbound_.at(f->second);
        }
        if (!matches(c, q, outbound ? outbound_status_name(*outbound) : "NONE")) continue;
        selected.push_back(summary(c, p->second, outbound, selected.size() + 1U));
    }
    Bytes seed; datacube::append_text(seed, "NATRAV_OVERLAY_PUBLICATION_INVENTORY_SELECTION_V1"); datacube::append_u8(seed, 0U);
    text(seed, node_id_); datacube::append_be32(seed, uid); digest(seed, configuration); digest(seed, access.digest);
    text(seed, q.lifecycle); text(seed, q.schedule); text(seed, q.outcome); text(seed, q.name);
    text(seed, q.projection); text(seed, q.recipient); text(seed, q.scope); optional_digest(seed, q.instance);
    datacube::append_be32(seed, static_cast<std::uint32_t>(selected.size())); auto root = datacube::sha256(seed);
    for (const auto& row : selected) {
        Bytes link; datacube::append_text(link, "NATRAV_OVERLAY_PUBLICATION_INVENTORY_ROW_V1"); datacube::append_u8(link, 0U);
        digest(link, root); datacube::append_be32(link, static_cast<std::uint32_t>(row.size())); datacube::append_text(link, row); root = datacube::sha256(link);
    }
    require(!q.selection || *q.selection == root, "PUBLICATION_INVENTORY_SELECTION_MISMATCH", "selected metadata or context changed");
    require(q.offset <= selected.size(), "PUBLICATION_INVENTORY_INVALID", "offset exceeds selected inventory");
    std::size_t returned = 0U, visited = 0U; std::string rows;
    const auto render = [&](std::string_view content, std::size_t count) {
        const auto next = q.offset + count;
        return std::string("{\"format\":\"NATRAV_OVERLAY_PUBLICATION_INVENTORY_V1\",\"ok\":true,\"node\":") + json_string(node_id_) +
            ",\"owner_uid\":" + std::to_string(uid) + ",\"authorized_configuration_digest\":" + hex(configuration) +
            ",\"read_authority_digest\":" + hex(access.digest) + ",\"selection_digest\":" + hex(root) +
            ",\"selected_total\":" + std::to_string(selected.size()) + ",\"offset\":" + std::to_string(q.offset) +
            ",\"returned\":" + std::to_string(count) + ",\"next_offset\":" + std::to_string(next) +
            ",\"has_more\":" + (next < selected.size() ? "true" : "false") +
            ",\"sequence_semantics\":\"AUTHORIZED_OWNER_NAME_ORDER\",\"observation\":\"ONE_STATE_MUTEX_CURRENT_METADATA\"" +
            ",\"visibility\":\"CURRENT_ADOPTED_READ_AUTHORITY_ONLY\",\"scheduling_observation\":\"DURABLE_GRANT_NOT_EXECUTION_ELIGIBILITY\"" +
            ",\"projection_results_included\":false,\"history_included\":false,\"freshness\":\"NOT_ESTABLISHED\"" +
            ",\"work\":{\"scope\":\"LOCKED_PUBLICATION_INVENTORY\",\"authorized_summaries_hashed\":" + std::to_string(selected.size()) +
            ",\"page_rows_visited\":" + std::to_string(visited) +
            ",\"payload_bytes_copied\":0,\"histories_serialized\":0,\"projection_results_computed\":0" +
            ",\"snapshot_calls\":" + std::to_string(work.snapshot_calls) + ",\"snapshot_payload_bytes\":" + std::to_string(work.snapshot_evidence_payload_bytes) +
            ",\"logical_bytes_serialized\":" + std::to_string(work.snapshot_logical_bytes) + "},\"records\":[" + std::string(content) + "]}";
    };
    for (std::size_t n = q.offset; n < selected.size() && returned < q.limit; ++n) {
        check_time(); ++visited; const auto trial = rows + (rows.empty() ? "" : ",") + selected[n];
        if (render(trial, returned + 1U).size() + kPrincipalReserve > q.maximum_bytes) {
            require(returned != 0U, "PUBLICATION_INVENTORY_PAGE_TOO_SMALL", "first complete summary exceeds byte budget"); break;
        }
        rows = trial; ++returned;
    }
    auto out = render(rows, returned);
    require(out.size() + kPrincipalReserve <= q.maximum_bytes, "PUBLICATION_INVENTORY_PAGE_TOO_SMALL", "metadata exceeds byte budget");
    check_time(); return out;
}
} // namespace natrav_overlay
