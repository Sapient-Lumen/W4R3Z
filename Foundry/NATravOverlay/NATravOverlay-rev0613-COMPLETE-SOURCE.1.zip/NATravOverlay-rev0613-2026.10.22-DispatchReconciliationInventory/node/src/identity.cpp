#include "identity.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <filesystem>
#include <linux/fs.h>
#include <memory>
#include <openssl/bio.h>
#include <openssl/crypto.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rand.h>
#include <openssl/x509.h>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <utility>

namespace natrav_overlay {
namespace {

struct PkeyDeleter final {
    void operator()(EVP_PKEY* value) const noexcept { EVP_PKEY_free(value); }
};
struct PkeyContextDeleter final {
    void operator()(EVP_PKEY_CTX* value) const noexcept { EVP_PKEY_CTX_free(value); }
};
struct X509Deleter final {
    void operator()(X509* value) const noexcept { X509_free(value); }
};
struct BioDeleter final {
    void operator()(BIO* value) const noexcept { BIO_free(value); }
};
using PkeyPtr = std::unique_ptr<EVP_PKEY, PkeyDeleter>;
using PkeyContextPtr = std::unique_ptr<EVP_PKEY_CTX, PkeyContextDeleter>;
using X509Ptr = std::unique_ptr<X509, X509Deleter>;
using BioPtr = std::unique_ptr<BIO, BioDeleter>;

[[nodiscard]] std::string openssl_reason() {
    const unsigned long value = ERR_get_error();
    if (value == 0UL) { return "OpenSSL operation failed"; }
    const char* reason = ERR_reason_error_string(value);
    while (ERR_get_error() != 0UL) {}
    return reason == nullptr ? "OpenSSL operation failed" : std::string(reason);
}

[[nodiscard]] bool safe_path_name(const std::string_view value) noexcept {
    if (value.empty() || value.size() > 120U || value == "." || value == "..") {
        return false;
    }
    return std::all_of(value.begin(), value.end(), [](const char raw) {
        const auto ch = static_cast<unsigned char>(raw);
        return (ch >= static_cast<unsigned char>('A') &&
                ch <= static_cast<unsigned char>('Z')) ||
            (ch >= static_cast<unsigned char>('a') &&
             ch <= static_cast<unsigned char>('z')) ||
            (ch >= static_cast<unsigned char>('0') &&
             ch <= static_cast<unsigned char>('9')) ||
            ch == static_cast<unsigned char>('.') ||
            ch == static_cast<unsigned char>('_') ||
            ch == static_cast<unsigned char>('-');
    });
}

void validate_parent_chain(const std::filesystem::path& absolute_parent) {
    std::filesystem::path current = absolute_parent.root_path();
    for (const auto& component : absolute_parent.relative_path()) {
        current /= component;
        struct stat status {};
        if (::lstat(current.c_str(), &status) != 0) {
            app_fail("IDENTITY_PARENT_INVALID",
                datacube::errno_detail(current.string(), errno));
        }
        if (S_ISLNK(status.st_mode)) {
            app_fail("IDENTITY_PARENT_SYMLINK_REJECTED",
                "identity parent path contains a symbolic link: " +
                current.string());
        }
        if (!S_ISDIR(status.st_mode)) {
            app_fail("IDENTITY_PARENT_INVALID",
                "identity parent component is not a directory: " +
                current.string());
        }
    }
    struct stat parent_status {};
    if (::lstat(absolute_parent.c_str(), &parent_status) != 0) {
        app_fail("IDENTITY_PARENT_INVALID",
            datacube::errno_detail(absolute_parent.string(), errno));
    }
    if (parent_status.st_uid != ::geteuid()) {
        app_fail("IDENTITY_PARENT_OWNER_INVALID",
            "final identity parent directory must be owned by the effective user");
    }
    if ((parent_status.st_mode & (S_IWGRP | S_IWOTH)) != 0) {
        app_fail("IDENTITY_PARENT_PERMISSIONS_INVALID",
            "final identity parent directory must not be group- or other-writable");
    }
}

void write_all(const int fd, const datacube::OctetView bytes) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const ssize_t count = ::write(
            fd, bytes.data() + offset, bytes.size() - offset);
        if (count < 0) {
            if (errno == EINTR) { continue; }
            app_fail("IDENTITY_WRITE_FAILED",
                datacube::errno_detail("identity file", errno));
        }
        if (count == 0) {
            app_fail("IDENTITY_WRITE_FAILED", "identity write made no progress");
        }
        offset += static_cast<std::size_t>(count);
    }
}

void create_file(
    const int directory_fd,
    const char* name,
    const mode_t mode,
    const datacube::OctetView bytes) {
    const int raw = ::openat(
        directory_fd, name,
        O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW,
        mode);
    if (raw < 0) {
        app_fail("IDENTITY_FILE_CREATE_FAILED",
            datacube::errno_detail(name, errno));
    }
    datacube::Fd fd(raw);
    write_all(fd.get(), bytes);
    if (::fsync(fd.get()) != 0) {
        app_fail("IDENTITY_FILE_SYNC_FAILED",
            datacube::errno_detail(name, errno));
    }
}

[[nodiscard]] datacube::Octets bio_bytes(BIO* bio) {
    BUF_MEM* memory = nullptr;
    BIO_get_mem_ptr(bio, &memory);
    if (memory == nullptr || memory->data == nullptr || memory->length == 0U) {
        app_fail("IDENTITY_ENCODING_FAILED", "OpenSSL produced empty identity material");
    }
    const auto* begin = reinterpret_cast<const std::uint8_t*>(memory->data);
    return datacube::Octets(begin, begin + memory->length);
}

[[nodiscard]] datacube::Digest32 pkey_spki_sha256(EVP_PKEY* key) {
    const int length = i2d_PUBKEY(key, nullptr);
    if (length <= 0) {
        app_fail("IDENTITY_PUBLIC_KEY_FAILED", openssl_reason());
    }
    datacube::Octets der(static_cast<std::size_t>(length));
    unsigned char* cursor = der.data();
    if (i2d_PUBKEY(key, &cursor) != length) {
        app_fail("IDENTITY_PUBLIC_KEY_FAILED", openssl_reason());
    }
    return datacube::sha256(der);
}

[[nodiscard]] std::string stage_name() {
    std::array<unsigned char, 8> random {};
    if (RAND_bytes(random.data(), static_cast<int>(random.size())) != 1) {
        app_fail("IDENTITY_RANDOM_FAILED", openssl_reason());
    }
    static constexpr char hex[] = "0123456789abcdef";
    std::string suffix;
    suffix.reserve(random.size() * 2U);
    for (const auto byte : random) {
        suffix.push_back(hex[(byte >> 4U) & 0x0fU]);
        suffix.push_back(hex[byte & 0x0fU]);
    }
    return ".natrav-overlay-identity-" + std::to_string(::getpid()) + "-" + suffix;
}

class StageGuard final {
public:
    StageGuard(int parent_fd, std::string name)
        : parent_fd_(parent_fd), name_(std::move(name)) {}
    ~StageGuard() {
        if (published_) { return; }
        static_cast<void>(::unlinkat(parent_fd_, (name_ + "/key.pem").c_str(), 0));
        static_cast<void>(::unlinkat(parent_fd_, (name_ + "/cert.pem").c_str(), 0));
        static_cast<void>(::unlinkat(parent_fd_, (name_ + "/identity.meta").c_str(), 0));
        static_cast<void>(::unlinkat(parent_fd_, name_.c_str(), AT_REMOVEDIR));
    }
    void published() noexcept { published_ = true; }
private:
    int parent_fd_{-1};
    std::string name_;
    bool published_{false};
};

}  // namespace

IdentityCreateResult create_identity(const IdentityCreateOptions& options) {
    require_node_id(options.node_id, "identity node ID");
    require_generation_id(options.generation, "identity generation");
    if (options.validity_days < 1U || options.validity_days > 36'500U) {
        app_fail("IDENTITY_VALIDITY_INVALID",
            "identity validity must be between 1 and 36500 days");
    }
    if (options.directory.empty()) {
        app_fail("IDENTITY_PATH_INVALID", "identity directory is empty");
    }
    for (const auto& component : options.directory) {
        if (component == "..") {
            app_fail("IDENTITY_PATH_INVALID", "identity path must not contain dot-dot");
        }
    }
    const auto absolute = std::filesystem::absolute(options.directory).lexically_normal();
    const auto parent = absolute.parent_path();
    const auto final_name = absolute.filename().string();
    if (parent.empty() || !safe_path_name(final_name)) {
        app_fail("IDENTITY_PATH_INVALID",
            "identity directory final name must use safe ASCII characters");
    }
    validate_parent_chain(parent);
    struct stat existing {};
    if (::lstat(absolute.c_str(), &existing) == 0) {
        app_fail("IDENTITY_DESTINATION_EXISTS",
            "identity destination already exists; overwrite is forbidden");
    }
    if (errno != ENOENT) {
        app_fail("IDENTITY_DESTINATION_INVALID",
            datacube::errno_detail(absolute.string(), errno));
    }

    const int parent_raw = ::open(
        parent.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (parent_raw < 0) {
        app_fail("IDENTITY_PARENT_OPEN_FAILED",
            datacube::errno_detail(parent.string(), errno));
    }
    datacube::Fd parent_fd(parent_raw);
    const auto staging = stage_name();
    if (::mkdirat(parent_fd.get(), staging.c_str(), S_IRWXU) != 0) {
        app_fail("IDENTITY_STAGE_CREATE_FAILED",
            datacube::errno_detail(staging, errno));
    }
    StageGuard stage_guard(parent_fd.get(), staging);
    const int stage_raw = ::openat(
        parent_fd.get(), staging.c_str(),
        O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (stage_raw < 0) {
        app_fail("IDENTITY_STAGE_OPEN_FAILED",
            datacube::errno_detail(staging, errno));
    }
    datacube::Fd stage_fd(stage_raw);
    if (::fchmod(stage_fd.get(), S_IRWXU) != 0) {
        app_fail("IDENTITY_STAGE_MODE_FAILED",
            datacube::errno_detail(staging, errno));
    }

    ERR_clear_error();
    PkeyContextPtr key_context(EVP_PKEY_CTX_new_id(EVP_PKEY_ED25519, nullptr));
    if (!key_context || EVP_PKEY_keygen_init(key_context.get()) != 1) {
        app_fail("IDENTITY_KEYGEN_FAILED", openssl_reason());
    }
    EVP_PKEY* generated_raw = nullptr;
    if (EVP_PKEY_keygen(key_context.get(), &generated_raw) != 1 ||
        generated_raw == nullptr) {
        app_fail("IDENTITY_KEYGEN_FAILED", openssl_reason());
    }
    PkeyPtr key(generated_raw);

    X509Ptr certificate(X509_new());
    if (!certificate || X509_set_version(certificate.get(), 2L) != 1) {
        app_fail("IDENTITY_CERTIFICATE_FAILED", openssl_reason());
    }
    std::array<unsigned char, 8> serial_bytes {};
    if (RAND_bytes(serial_bytes.data(), static_cast<int>(serial_bytes.size())) != 1) {
        app_fail("IDENTITY_RANDOM_FAILED", openssl_reason());
    }
    std::uint64_t serial = 0U;
    for (const auto byte : serial_bytes) {
        serial = (serial << 8U) | static_cast<std::uint64_t>(byte);
    }
    serial &= 0x7fff'ffff'ffff'ffffULL;
    if (serial == 0U) { serial = 1U; }
    if (ASN1_INTEGER_set_uint64(X509_get_serialNumber(certificate.get()), serial) != 1 ||
        X509_gmtime_adj(X509_getm_notBefore(certificate.get()), -60L) == nullptr ||
        X509_gmtime_adj(
            X509_getm_notAfter(certificate.get()),
            static_cast<long>(options.validity_days) * 86'400L) == nullptr ||
        X509_set_pubkey(certificate.get(), key.get()) != 1) {
        app_fail("IDENTITY_CERTIFICATE_FAILED", openssl_reason());
    }
    X509_NAME* subject = X509_get_subject_name(certificate.get());
    const std::string common_name =
        "natrav-overlay-" + options.node_id + "-" + options.generation;
    if (subject == nullptr ||
        X509_NAME_add_entry_by_txt(
            subject, "CN", MBSTRING_ASC,
            reinterpret_cast<const unsigned char*>(common_name.data()),
            static_cast<int>(common_name.size()), -1, 0) != 1 ||
        X509_set_issuer_name(certificate.get(), subject) != 1 ||
        X509_sign(certificate.get(), key.get(), nullptr) <= 0) {
        app_fail("IDENTITY_CERTIFICATE_FAILED", openssl_reason());
    }

    BioPtr key_bio(BIO_new(BIO_s_mem()));
    BioPtr cert_bio(BIO_new(BIO_s_mem()));
    if (!key_bio || !cert_bio ||
        PEM_write_bio_PrivateKey(
            key_bio.get(), key.get(), nullptr, nullptr, 0, nullptr, nullptr) != 1 ||
        PEM_write_bio_X509(cert_bio.get(), certificate.get()) != 1) {
        app_fail("IDENTITY_ENCODING_FAILED", openssl_reason());
    }
    auto key_bytes = bio_bytes(key_bio.get());
    const auto cert_bytes = bio_bytes(cert_bio.get());
    const auto pin = pkey_spki_sha256(key.get());
    const std::string metadata =
        "NATRAV_OVERLAY_IDENTITY_V1\nnode=" + options.node_id +
        "\ngeneration=" + options.generation +
        "\nspki_sha256=" + spki_sha256_text(pin) +
        "\ncertificate=cert.pem\nprivate_key=key.pem\n";

    try {
        create_file(stage_fd.get(), "key.pem", S_IRUSR | S_IWUSR, key_bytes);
        OPENSSL_cleanse(key_bytes.data(), key_bytes.size());
        key_bytes.clear();
        create_file(stage_fd.get(), "cert.pem", S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH,
            cert_bytes);
        create_file(stage_fd.get(), "identity.meta",
            S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH,
            datacube::text_octets(metadata));
        if (::fsync(stage_fd.get()) != 0) {
            app_fail("IDENTITY_DIRECTORY_SYNC_FAILED",
                datacube::errno_detail(staging, errno));
        }
        const long renamed = ::syscall(
            SYS_renameat2,
            parent_fd.get(), staging.c_str(),
            parent_fd.get(), final_name.c_str(),
            RENAME_NOREPLACE);
        if (renamed != 0) {
            if (errno == EEXIST) {
                app_fail("IDENTITY_DESTINATION_EXISTS",
                    "identity destination appeared during creation");
            }
            app_fail("IDENTITY_PUBLISH_FAILED",
                datacube::errno_detail(absolute.string(), errno));
        }
        stage_guard.published();
        if (::fsync(parent_fd.get()) != 0) {
            app_fail("IDENTITY_PARENT_SYNC_FAILED",
                datacube::errno_detail(parent.string(), errno));
        }
    } catch (...) {
        if (!key_bytes.empty()) {
            OPENSSL_cleanse(key_bytes.data(), key_bytes.size());
        }
        throw;
    }

    return IdentityCreateResult{
        .directory = absolute,
        .certificate = absolute / "cert.pem",
        .private_key = absolute / "key.pem",
        .metadata = absolute / "identity.meta",
        .node_id = options.node_id,
        .generation = options.generation,
        .spki_sha256 = pin,
        .validity_days = options.validity_days,
    };
}

std::string identity_create_result_json(const IdentityCreateResult& result) {
    return std::string("{\"format\":\"NATRAV_OVERLAY_IDENTITY_V1\",\"ok\":true") +
        ",\"node\":" + json_string(result.node_id) +
        ",\"generation\":" + json_string(result.generation) +
        ",\"directory\":" + json_string(result.directory.string()) +
        ",\"certificate\":" + json_string(result.certificate.string()) +
        ",\"private_key\":" + json_string(result.private_key.string()) +
        ",\"metadata\":" + json_string(result.metadata.string()) +
        ",\"spki_sha256\":" + json_string(spki_sha256_text(result.spki_sha256)) +
        ",\"validity_days\":" + std::to_string(result.validity_days) +
        ",\"private_key_exposed\":false}";
}

}  // namespace natrav_overlay
