#include "removable_media_packet_adapter.hpp"

#include "common.hpp"
#include "finite_packet_link.hpp"
#include "socket.hpp"
#include "removable_media_bundle.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <deque>
#include <dirent.h>
#include <fcntl.h>
#include <filesystem>
#include <limits>
#include <linux/fs.h>
#include <map>
#include <optional>
#include <poll.h>
#include <set>
#include <span>
#include <string>
#include <string_view>
#include <sys/file.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/un.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace natrav_overlay {
namespace {

using Bytes = datacube::Octets;
using Clock = std::chrono::steady_clock;
using Milliseconds = std::chrono::milliseconds;

constexpr int kProtocolFd = 3;
constexpr std::size_t kNapaHeader = 36U;
constexpr std::array<std::uint8_t, 8U> kNapaMagic{
    'N', 'A', 'P', 'A', '0', '0', '0', '1'};
constexpr std::uint32_t kOk = 0U;
constexpr std::uint32_t kNoData = 1U;
constexpr std::uint32_t kBusy = 2U;
constexpr std::size_t kMaximumPathBytes = 4'096U;
constexpr std::size_t kMaximumEvidenceBytes = 1'024U;
constexpr std::string_view kPartPrefix = ".nrmb-part-";
constexpr std::string_view kTempPrefix = ".nrmb-tmp-";

struct ObjectId final {
    std::uint64_t device{0U};
    std::uint64_t inode{0U};
    friend bool operator==(const ObjectId&, const ObjectId&) = default;
};

struct Options final {
    std::filesystem::path inbound;
    ObjectId inbound_object{};
    std::filesystem::path outbound;
    ObjectId outbound_object{};
    std::filesystem::path quarantine;
    ObjectId quarantine_object{};
    removable_media::Settings bundle{};
    std::size_t queue_bytes{0U};
    std::size_t queue_files{0U};
    std::uint64_t poll_interval_ms{0U};
    std::size_t scan_entries{0U};
    std::size_t directory_entry_limit{0U};
    std::size_t quarantine_bytes{0U};
    std::size_t quarantine_files{0U};
    std::size_t duplicate_window{0U};
};

struct Frame final {
    std::uint8_t type{0U};
    std::uint64_t sequence{0U};
    std::uint32_t deadline_ms{0U};
    std::uint32_t status{kOk};
    Bytes payload{};
};

struct Directory final {
    datacube::Fd fd{};
    std::filesystem::path path{};
    ObjectId object{};
    std::string role{};
};

struct FileImage final {
    Bytes bytes{};
    ObjectId object{};
    std::uint64_t size{0U};
    std::uint64_t modified_ms{0U};
};

struct Usage final {
    std::size_t files{0U};
    std::size_t bytes{0U};
};

[[nodiscard]] std::uint64_t system_now_ms() {
    const auto count = std::chrono::duration_cast<Milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    if (count < 0) {
        app_fail("REMOVABLE_MEDIA_CLOCK_INVALID", "system clock precedes the Unix epoch");
    }
    return static_cast<std::uint64_t>(count);
}

void append(Bytes& bytes, const std::uint64_t value, const unsigned count) {
    for (unsigned index = count; index > 0U; --index) {
        bytes.push_back(static_cast<std::uint8_t>(value >> ((index - 1U) * 8U)));
    }
}

[[nodiscard]] std::uint64_t read_integer(
    const Bytes& bytes,
    const std::size_t offset,
    const std::size_t count) {
    if (offset > bytes.size() || count > bytes.size() - offset) {
        app_fail("REMOVABLE_MEDIA_ADAPTER_PROTOCOL_INVALID", "truncated integer");
    }
    std::uint64_t result = 0U;
    for (std::size_t index = 0U; index < count; ++index) {
        result = (result << 8U) | bytes[offset + index];
    }
    return result;
}

[[nodiscard]] ObjectId object_id(const struct stat& status) noexcept {
    return ObjectId{
        .device = static_cast<std::uint64_t>(status.st_dev),
        .inode = static_cast<std::uint64_t>(status.st_ino),
    };
}

[[nodiscard]] std::uint64_t modified_ms(const struct stat& status) noexcept {
    const auto seconds = static_cast<std::uint64_t>(
        std::max<time_t>(status.st_mtim.tv_sec, 0));
    const auto nanoseconds = static_cast<std::uint64_t>(
        std::max<long>(status.st_mtim.tv_nsec, 0L));
    return seconds * 1'000U + nanoseconds / 1'000'000U;
}

[[nodiscard]] bool same_file(const struct stat& left, const struct stat& right) noexcept {
    return left.st_dev == right.st_dev && left.st_ino == right.st_ino &&
        left.st_size == right.st_size && left.st_mode == right.st_mode &&
        left.st_uid == right.st_uid && left.st_nlink == right.st_nlink &&
        left.st_mtim.tv_sec == right.st_mtim.tv_sec &&
        left.st_mtim.tv_nsec == right.st_mtim.tv_nsec &&
        left.st_ctim.tv_sec == right.st_ctim.tv_sec &&
        left.st_ctim.tv_nsec == right.st_ctim.tv_nsec;
}

[[nodiscard]] std::string canonical_path_text(
    const std::string_view text,
    const std::string_view field) {
    if (text.empty() || text.size() > kMaximumPathBytes ||
        text.find('\0') != std::string_view::npos || text.front() != '/') {
        app_fail("REMOVABLE_MEDIA_DIRECTORY_INVALID", std::string(field));
    }
    const std::filesystem::path path(text);
    if (!path.is_absolute() || path == "/" || path.lexically_normal().string() != text ||
        text.ends_with('/')) {
        app_fail("REMOVABLE_MEDIA_DIRECTORY_INVALID", std::string(field));
    }
    return std::string(text);
}

[[nodiscard]] ObjectId parse_object_id(
    const std::string_view text,
    const std::string_view field) {
    const auto separator = text.find(':');
    if (separator == std::string_view::npos || separator == 0U ||
        separator + 1U >= text.size() || text.find(':', separator + 1U) != std::string_view::npos) {
        app_fail("REMOVABLE_MEDIA_OBJECT_INVALID", std::string(field));
    }
    const auto device_text = text.substr(0U, separator);
    const auto inode_text = text.substr(separator + 1U);
    const auto device = parse_u64(
        device_text, field, 0U, std::numeric_limits<std::uint64_t>::max());
    const auto inode = parse_u64(
        inode_text, field, 1U, std::numeric_limits<std::uint64_t>::max());
    if (std::to_string(device) != device_text || std::to_string(inode) != inode_text) {
        app_fail("REMOVABLE_MEDIA_OBJECT_INVALID", std::string(field));
    }
    return ObjectId{.device = device, .inode = inode};
}

[[nodiscard]] std::uint64_t parse_link(const std::string_view text) {
    if (text.size() != 16U) {
        app_fail("INVALID_ARGUMENT", "link requires sixteen lowercase hexadecimal digits");
    }
    std::uint64_t value = 0U;
    for (const char digit : text) {
        std::uint8_t nibble = 0U;
        if (digit >= '0' && digit <= '9') {
            nibble = static_cast<std::uint8_t>(digit - '0');
        } else if (digit >= 'a' && digit <= 'f') {
            nibble = static_cast<std::uint8_t>(digit - 'a' + 10);
        } else {
            app_fail("INVALID_ARGUMENT", "link is noncanonical");
        }
        value = (value << 4U) | nibble;
    }
    if (value == 0U) {
        app_fail("INVALID_ARGUMENT", "link must be nonzero");
    }
    return value;
}

[[nodiscard]] Options parse_options(const int argc, char* argv[]) {
    const std::array<std::string, 18U> keys{
        "--inbound", "--inbound-object", "--outbound", "--outbound-object",
        "--quarantine", "--quarantine-object", "--mtu", "--link", "--epoch",
        "--queue-bytes", "--queue-files", "--bundle-lifetime-ms",
        "--poll-interval-ms", "--scan-entries", "--directory-entry-limit",
        "--quarantine-bytes", "--quarantine-files", "--duplicate-window"};
    if (argc != 38) {
        app_fail("INVALID_ARGUMENT", "removable-media-packet-adapter requires exactly eighteen explicit option/value pairs");
    }
    std::map<std::string, std::string> fields;
    for (int index = 2; index < argc; index += 2) {
        const std::string key(argv[index]);
        const std::string value(argv[index + 1]);
        if (value.size() > kMaximumPathBytes ||
            std::find(keys.begin(), keys.end(), key) == keys.end() ||
            !fields.emplace(key, value).second) {
            app_fail("INVALID_ARGUMENT", "unknown, duplicate or oversized removable-media option");
        }
    }
    const auto number = [&](const std::string& key,
                            const std::uint64_t minimum,
                            const std::uint64_t maximum) {
        const auto& text = fields.at(key);
        const auto value = parse_u64(text, key, minimum, maximum);
        if (std::to_string(value) != text) {
            app_fail("INVALID_ARGUMENT", "noncanonical removable-media number");
        }
        return value;
    };
    Options options{
        .inbound = canonical_path_text(fields.at("--inbound"), "inbound"),
        .inbound_object = parse_object_id(fields.at("--inbound-object"), "inbound object"),
        .outbound = canonical_path_text(fields.at("--outbound"), "outbound"),
        .outbound_object = parse_object_id(fields.at("--outbound-object"), "outbound object"),
        .quarantine = canonical_path_text(fields.at("--quarantine"), "quarantine"),
        .quarantine_object = parse_object_id(fields.at("--quarantine-object"), "quarantine object"),
        .bundle = {
            .mtu = static_cast<std::size_t>(number("--mtu", 256U, 65'507U)),
            .link = parse_link(fields.at("--link")),
            .epoch = static_cast<std::uint32_t>(number("--epoch", 1U, 0xffffffffU)),
            .lifetime_ms = number("--bundle-lifetime-ms", 1'000U, 604'800'000U),
        },
        .queue_bytes = static_cast<std::size_t>(number("--queue-bytes", 1'024U, 67'108'864U)),
        .queue_files = static_cast<std::size_t>(number("--queue-files", 1U, 1'024U)),
        .poll_interval_ms = number("--poll-interval-ms", 1U, 10'000U),
        .scan_entries = static_cast<std::size_t>(number("--scan-entries", 1U, 256U)),
        .directory_entry_limit = static_cast<std::size_t>(number("--directory-entry-limit", 8U, 4'096U)),
        .quarantine_bytes = static_cast<std::size_t>(number("--quarantine-bytes", 1'024U, 67'108'864U)),
        .quarantine_files = static_cast<std::size_t>(number("--quarantine-files", 1U, 1'024U)),
        .duplicate_window = static_cast<std::size_t>(number("--duplicate-window", 1U, 4'096U)),
    };
    options.bundle.validate();
    if (options.inbound == options.outbound || options.inbound == options.quarantine ||
        options.outbound == options.quarantine ||
        options.inbound_object == options.outbound_object ||
        options.inbound_object == options.quarantine_object ||
        options.outbound_object == options.quarantine_object) {
        app_fail("REMOVABLE_MEDIA_DIRECTORY_INVALID", "inbound, outbound and quarantine directories must be distinct");
    }
    if (options.queue_bytes < removable_media::kBundleOverheadBytes + options.bundle.mtu ||
        options.queue_files > options.directory_entry_limit ||
        options.quarantine_files > options.directory_entry_limit ||
        options.scan_entries > options.directory_entry_limit) {
        app_fail("REMOVABLE_MEDIA_LIMIT_INVALID", "queue, scan or directory limits are inconsistent");
    }
    return options;
}

[[nodiscard]] Directory open_directory(
    const std::filesystem::path& path,
    const ObjectId expected,
    std::string role) {
    const auto text = canonical_path_text(path.string(), role);
    const int root_raw = ::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (root_raw < 0) {
        app_fail("REMOVABLE_MEDIA_DIRECTORY_OPEN_FAILED", datacube::errno_detail(role + " root", errno));
    }
    datacube::Fd current(root_raw);
    std::size_t begin = 1U;
    while (begin < text.size()) {
        const auto end = text.find('/', begin);
        const auto component = text.substr(
            begin, end == std::string::npos ? text.size() - begin : end - begin);
        const int next_raw = ::openat(
            current.get(), component.c_str(),
            O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
        if (next_raw < 0) {
            app_fail("REMOVABLE_MEDIA_DIRECTORY_OPEN_FAILED",
                datacube::errno_detail(role + " component " + component, errno));
        }
        current.reset(next_raw);
        if (end == std::string::npos) {
            break;
        }
        begin = end + 1U;
    }
    struct stat descriptor_status {};
    struct stat path_status {};
    if (::fstat(current.get(), &descriptor_status) != 0 ||
        ::lstat(text.c_str(), &path_status) != 0) {
        app_fail("REMOVABLE_MEDIA_DIRECTORY_OPEN_FAILED", datacube::errno_detail(role, errno));
    }
    if (!S_ISDIR(descriptor_status.st_mode) || !S_ISDIR(path_status.st_mode) ||
        object_id(descriptor_status) != object_id(path_status) ||
        object_id(descriptor_status) != expected ||
        descriptor_status.st_uid != ::geteuid() ||
        (descriptor_status.st_mode & (S_IRWXG | S_IRWXO)) != 0 ||
        (descriptor_status.st_mode & (S_IRUSR | S_IWUSR | S_IXUSR)) !=
            (S_IRUSR | S_IWUSR | S_IXUSR)) {
        app_fail("REMOVABLE_MEDIA_DIRECTORY_UNSAFE",
            role + " must be the exact pinned owner-only readable/writable/searchable directory");
    }
    if (::flock(current.get(), LOCK_EX | LOCK_NB) != 0) {
        app_fail("REMOVABLE_MEDIA_DIRECTORY_BUSY", role + " directory already has a cooperative owner");
    }
    return Directory{
        .fd = std::move(current),
        .path = path,
        .object = expected,
        .role = std::move(role),
    };
}

void verify_directory(const Directory& directory) {
    struct stat descriptor_status {};
    struct stat path_status {};
    if (::fstat(directory.fd.get(), &descriptor_status) != 0 ||
        ::lstat(directory.path.c_str(), &path_status) != 0 ||
        !S_ISDIR(descriptor_status.st_mode) || !S_ISDIR(path_status.st_mode) ||
        object_id(descriptor_status) != directory.object ||
        object_id(path_status) != directory.object ||
        descriptor_status.st_uid != ::geteuid() ||
        (descriptor_status.st_mode & (S_IRWXG | S_IRWXO)) != 0 ||
        (descriptor_status.st_mode & (S_IRUSR | S_IWUSR | S_IXUSR)) !=
            (S_IRUSR | S_IWUSR | S_IXUSR)) {
        app_fail("REMOVABLE_MEDIA_DIRECTORY_REPLACED",
            directory.role + " directory is absent, replaced or no longer owner-controlled");
    }
}

[[nodiscard]] std::vector<std::string> list_directory(
    const Directory& directory,
    const std::size_t entry_limit) {
    verify_directory(directory);
    // A duplicated directory descriptor shares the open-file-description offset.
    // Reopen "." beneath the pinned descriptor so every bounded scan starts from
    // an independent directory stream without changing the ownership handle.
    const int duplicate = ::openat(
        directory.fd.get(), ".", O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (duplicate < 0) {
        app_fail("REMOVABLE_MEDIA_DIRECTORY_READ_FAILED", datacube::errno_detail(directory.role, errno));
    }
    DIR* raw = ::fdopendir(duplicate);
    if (raw == nullptr) {
        const int saved = errno;
        static_cast<void>(::close(duplicate));
        app_fail("REMOVABLE_MEDIA_DIRECTORY_READ_FAILED", datacube::errno_detail(directory.role, saved));
    }
    std::vector<std::string> names;
    errno = 0;
    while (const auto* entry = ::readdir(raw)) {
        const std::string_view name(entry->d_name);
        if (name == "." || name == "..") {
            continue;
        }
        if (names.size() == entry_limit) {
            static_cast<void>(::closedir(raw));
            app_fail("REMOVABLE_MEDIA_DIRECTORY_EXHAUSTED",
                directory.role + " exceeds the explicit entry bound");
        }
        names.emplace_back(name);
    }
    const int read_error = errno;
    if (::closedir(raw) != 0 && read_error == 0) {
        app_fail("REMOVABLE_MEDIA_DIRECTORY_READ_FAILED", datacube::errno_detail(directory.role, errno));
    }
    if (read_error != 0) {
        app_fail("REMOVABLE_MEDIA_DIRECTORY_READ_FAILED", datacube::errno_detail(directory.role, read_error));
    }
    std::sort(names.begin(), names.end());
    return names;
}

[[nodiscard]] std::optional<FileImage> read_file(
    const Directory& directory,
    const std::string& name,
    const std::size_t ceiling) {
    if (name.empty() || name == "." || name == ".." || name.find('/') != std::string::npos) {
        app_fail("REMOVABLE_MEDIA_FILE_INVALID", "invalid directory entry name");
    }
    const int raw = ::openat(
        directory.fd.get(), name.c_str(),
        O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
    if (raw < 0) {
        if (errno == ENOENT) {
            return std::nullopt;
        }
        app_fail("REMOVABLE_MEDIA_FILE_UNSAFE",
            datacube::errno_detail(directory.role + "/" + name, errno));
    }
    datacube::Fd fd(raw);
    struct stat before {};
    if (::fstat(fd.get(), &before) != 0 || !S_ISREG(before.st_mode) ||
        before.st_uid != ::geteuid() || before.st_nlink != 1 ||
        (before.st_mode & (S_IRWXG | S_IRWXO)) != 0 ||
        before.st_size < 0 || static_cast<std::uint64_t>(before.st_size) > ceiling) {
        app_fail("REMOVABLE_MEDIA_FILE_UNSAFE",
            directory.role + "/" + name + " is not a bounded owner-only singly linked regular file");
    }
    Bytes bytes;
    try {
        bytes = datacube::read_all_fd(
            fd.get(), static_cast<std::uint64_t>(ceiling), directory.role + "/" + name);
    } catch (const datacube::Failure& error) {
        app_fail("REMOVABLE_MEDIA_FILE_READ_FAILED", error.what());
    }
    struct stat after {};
    struct stat path_status {};
    if (::fstat(fd.get(), &after) != 0 ||
        ::fstatat(directory.fd.get(), name.c_str(), &path_status, AT_SYMLINK_NOFOLLOW) != 0 ||
        !same_file(before, after) || !same_file(after, path_status) ||
        bytes.size() != static_cast<std::size_t>(after.st_size)) {
        app_fail("REMOVABLE_MEDIA_FILE_REPLACED",
            directory.role + "/" + name + " changed while being read");
    }
    return FileImage{
        .bytes = std::move(bytes),
        .object = object_id(after),
        .size = static_cast<std::uint64_t>(after.st_size),
        .modified_ms = modified_ms(after),
    };
}

void unlink_exact(
    const Directory& directory,
    const std::string& name,
    const ObjectId object) {
    struct stat status {};
    if (::fstatat(directory.fd.get(), name.c_str(), &status, AT_SYMLINK_NOFOLLOW) != 0) {
        if (errno == ENOENT) {
            return;
        }
        app_fail("REMOVABLE_MEDIA_FILE_REMOVE_FAILED", datacube::errno_detail(name, errno));
    }
    if (object_id(status) != object) {
        app_fail("REMOVABLE_MEDIA_FILE_REPLACED", directory.role + "/" + name);
    }
    if (::unlinkat(directory.fd.get(), name.c_str(), 0) != 0 ||
        ::fsync(directory.fd.get()) != 0) {
        app_fail("REMOVABLE_MEDIA_FILE_REMOVE_FAILED", datacube::errno_detail(name, errno));
    }
}

void write_all(const int fd, const std::span<const std::uint8_t> bytes) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto count = ::write(fd, bytes.data() + offset, bytes.size() - offset);
        if (count < 0 && errno == EINTR) {
            continue;
        }
        if (count <= 0) {
            app_fail("REMOVABLE_MEDIA_FILE_WRITE_FAILED", datacube::errno_detail("write", errno));
        }
        offset += static_cast<std::size_t>(count);
    }
}

[[nodiscard]] bool publish_atomic(
    const Directory& directory,
    const std::string& final_name,
    const std::span<const std::uint8_t> bytes,
    std::uint64_t& temporary_sequence) {
    verify_directory(directory);
    ++temporary_sequence;
    if (temporary_sequence == 0U) {
        app_fail("REMOVABLE_MEDIA_SEQUENCE_EXHAUSTED", "temporary-file sequence exhausted");
    }
    const auto temporary_name = std::string(kTempPrefix) +
        std::to_string(static_cast<unsigned long long>(::getpid())) + "-" +
        std::to_string(temporary_sequence);
    const int raw = ::openat(
        directory.fd.get(), temporary_name.c_str(),
        O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
    if (raw < 0) {
        app_fail("REMOVABLE_MEDIA_FILE_CREATE_FAILED",
            datacube::errno_detail(directory.role + " temporary file", errno));
    }
    datacube::Fd file(raw);
    bool temporary_exists = true;
    try {
        write_all(file.get(), bytes);
        if (::fchmod(file.get(), S_IRUSR | S_IWUSR) != 0 ||
            ::fsync(file.get()) != 0) {
            app_fail("REMOVABLE_MEDIA_FILE_SYNC_FAILED",
                datacube::errno_detail(directory.role + " temporary file", errno));
        }
        file.reset();
        if (::syscall(SYS_renameat2, directory.fd.get(), temporary_name.c_str(),
                      directory.fd.get(), final_name.c_str(), RENAME_NOREPLACE) != 0) {
            if (errno != EEXIST) {
                app_fail("REMOVABLE_MEDIA_FILE_PUBLISH_FAILED",
                    datacube::errno_detail(directory.role + "/" + final_name, errno));
            }
            const auto existing = read_file(directory, final_name, bytes.size());
            if (!existing.has_value() || existing->bytes != Bytes(bytes.begin(), bytes.end())) {
                app_fail("REMOVABLE_MEDIA_FILE_COLLISION",
                    directory.role + "/" + final_name + " already exists with different bytes");
            }
            if (::unlinkat(directory.fd.get(), temporary_name.c_str(), 0) != 0) {
                app_fail("REMOVABLE_MEDIA_FILE_SYNC_FAILED",
                    datacube::errno_detail(directory.role + " duplicate staging cleanup", errno));
            }
        }
        temporary_exists = false;
        if (::fsync(directory.fd.get()) != 0) {
            app_fail("REMOVABLE_MEDIA_FILE_SYNC_FAILED",
                datacube::errno_detail(directory.role + " publication", errno));
        }
        return true;
    } catch (...) {
        if (temporary_exists) {
            static_cast<void>(::unlinkat(directory.fd.get(), temporary_name.c_str(), 0));
        }
        throw;
    }
}

[[nodiscard]] std::string bytes_hex(const std::string_view text) {
    return datacube::hex_lower(std::span<const std::uint8_t>(
        reinterpret_cast<const std::uint8_t*>(text.data()), text.size()));
}

void validate_protocol_endpoint() {
    const char* fd = std::getenv("NATRAV_ADAPTER_FD");
    const char* protocol = std::getenv("NATRAV_ADAPTER_PROTOCOL");
    if (fd == nullptr || protocol == nullptr || std::string_view(fd) != "3" ||
        std::string_view(protocol) != "NAPA0001") {
        app_fail("REMOVABLE_MEDIA_ADAPTER_ENDPOINT_REQUIRED",
            "requires supervised descriptor-3 NAPA0001 endpoint");
    }
    int type = 0;
    socklen_t length = sizeof(type);
    sockaddr_un address {};
    socklen_t address_length = sizeof(address);
    if (::getsockopt(kProtocolFd, SOL_SOCKET, SO_TYPE, &type, &length) != 0 ||
        type != SOCK_SEQPACKET ||
        ::getpeername(kProtocolFd, reinterpret_cast<sockaddr*>(&address), &address_length) != 0 ||
        address.sun_family != AF_UNIX) {
        app_fail("REMOVABLE_MEDIA_ADAPTER_ENDPOINT_REQUIRED",
            "descriptor 3 must be a connected Unix SOCK_SEQPACKET");
    }
    const int flags = ::fcntl(kProtocolFd, F_GETFL);
    if (flags < 0 || ::fcntl(kProtocolFd, F_SETFL, flags | O_NONBLOCK) != 0) {
        app_fail("REMOVABLE_MEDIA_ADAPTER_ENDPOINT_REQUIRED", "nonblocking endpoint setup failed");
    }
    const int buffer_bytes = 65'536;
    if (::setsockopt(kProtocolFd, SOL_SOCKET, SO_SNDBUF, &buffer_bytes, sizeof(buffer_bytes)) != 0 ||
        ::setsockopt(kProtocolFd, SOL_SOCKET, SO_RCVBUF, &buffer_bytes, sizeof(buffer_bytes)) != 0) {
        app_fail("REMOVABLE_MEDIA_ADAPTER_ENDPOINT_REQUIRED", "socket buffer setup failed");
    }
}

[[nodiscard]] Frame decode_request(const Bytes& bytes, const std::uint64_t expected) {
    if (bytes.size() < kNapaHeader ||
        !std::equal(kNapaMagic.begin(), kNapaMagic.end(), bytes.begin()) ||
        bytes[9U] != 0U || bytes[10U] != 0U || bytes[11U] != 0U ||
        read_integer(bytes, 12U, 8U) != expected || expected == 0U ||
        read_integer(bytes, 24U, 4U) != 0U ||
        read_integer(bytes, 28U, 4U) != bytes.size() - kNapaHeader) {
        app_fail("REMOVABLE_MEDIA_ADAPTER_PROTOCOL_INVALID", "noncanonical request header");
    }
    const auto deadline = read_integer(bytes, 20U, 4U);
    if (deadline == 0U || deadline > 60'000U) {
        app_fail("REMOVABLE_MEDIA_ADAPTER_PROTOCOL_INVALID", "request deadline outside bounds");
    }
    Bytes checksum(bytes.begin(), bytes.begin() + 32);
    checksum.insert(checksum.end(), bytes.begin() + static_cast<std::ptrdiff_t>(kNapaHeader), bytes.end());
    if (natrav::packet_link::FrameCodec::crc32(checksum) != read_integer(bytes, 32U, 4U)) {
        app_fail("REMOVABLE_MEDIA_ADAPTER_PROTOCOL_INVALID", "request checksum mismatch");
    }
    return Frame{
        .type = bytes[8U],
        .sequence = expected,
        .deadline_ms = static_cast<std::uint32_t>(deadline),
        .status = kOk,
        .payload = Bytes(bytes.begin() + static_cast<std::ptrdiff_t>(kNapaHeader), bytes.end()),
    };
}

[[nodiscard]] Bytes encode_response(const Frame& frame) {
    Bytes bytes(kNapaMagic.begin(), kNapaMagic.end());
    bytes.push_back(frame.type);
    append(bytes, 0U, 3U);
    append(bytes, frame.sequence, 8U);
    append(bytes, frame.deadline_ms, 4U);
    append(bytes, frame.status, 4U);
    append(bytes, frame.payload.size(), 4U);
    Bytes checksum(bytes);
    checksum.insert(checksum.end(), frame.payload.begin(), frame.payload.end());
    append(bytes, natrav::packet_link::FrameCodec::crc32(checksum), 4U);
    bytes.insert(bytes.end(), frame.payload.begin(), frame.payload.end());
    return bytes;
}

void send_response(const Frame& frame, const Deadline deadline) {
    const auto bytes = encode_response(frame);
    while (Clock::now() < deadline) {
        const auto count = ::send(
            kProtocolFd, bytes.data(), bytes.size(), MSG_DONTWAIT | MSG_NOSIGNAL);
        if (count == static_cast<ssize_t>(bytes.size())) {
            return;
        }
        if (count >= 0) {
            app_fail("REMOVABLE_MEDIA_ADAPTER_PROTOCOL_INVALID", "partial local datagram send");
        }
        if (errno != EINTR && errno != EAGAIN && errno != EWOULDBLOCK) {
            app_fail("REMOVABLE_MEDIA_ADAPTER_PROTOCOL_CLOSED", "local response endpoint closed");
        }
        pollfd item{.fd = kProtocolFd, .events = POLLOUT, .revents = 0};
        const auto result = ::poll(&item, 1U, 1);
        if (result < 0 && errno != EINTR) {
            app_fail("REMOVABLE_MEDIA_ADAPTER_PROTOCOL_CLOSED", "local response poll failed");
        }
    }
    app_fail("REMOVABLE_MEDIA_ADAPTER_RESPONSE_TIMEOUT", "local response deadline expired");
}

class Adapter final {
public:
    explicit Adapter(Options options)
        : options_(std::move(options)),
          inbound_(open_directory(options_.inbound, options_.inbound_object, "inbound")),
          outbound_(open_directory(options_.outbound, options_.outbound_object, "outbound")),
          quarantine_(open_directory(options_.quarantine, options_.quarantine_object, "quarantine")),
          next_scan_(Clock::now()) {
        discard_prior_incarnation_files();
    }

    int run() {
        std::uint64_t sequence = 1U;
        bool hello = false;
        const auto hello_deadline = Clock::now() + Milliseconds(2'000);
        Bytes buffer(kNapaHeader + std::max(options_.bundle.mtu, std::size_t{20U}));
        while (true) {
            if (!hello && Clock::now() >= hello_deadline) {
                app_fail("REMOVABLE_MEDIA_ADAPTER_HELLO_TIMEOUT", "HELLO absent");
            }
            if (hello) {
                pump(false);
            }
            iovec io{.iov_base = buffer.data(), .iov_len = buffer.size()};
            msghdr message {};
            message.msg_iov = &io;
            message.msg_iovlen = 1U;
            const auto count = ::recvmsg(kProtocolFd, &message, MSG_DONTWAIT);
            if (count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)) {
                pollfd item{.fd = kProtocolFd, .events = POLLIN, .revents = 0};
                static_cast<void>(::poll(&item, 1U, 1));
                continue;
            }
            if (count == 0) {
                return 0;
            }
            if (count < 0 || (message.msg_flags & (MSG_TRUNC | MSG_CTRUNC)) != 0) {
                app_fail("REMOVABLE_MEDIA_ADAPTER_PROTOCOL_INVALID", "truncated or failed local datagram");
            }
            const Bytes bytes(buffer.begin(), buffer.begin() + count);
            if (!hello) {
                sequence = read_integer(bytes, 12U, 8U);
            }
            const auto request = decode_request(bytes, sequence);
            if (sequence == std::numeric_limits<std::uint64_t>::max()) {
                app_fail("REMOVABLE_MEDIA_ADAPTER_SEQUENCE_EXHAUSTED", "finite request sequence exhausted");
            }
            ++sequence;
            const auto deadline = Clock::now() + Milliseconds(std::min(request.deadline_ms, 500U));
            Frame reply{
                .type = static_cast<std::uint8_t>(request.type + 1U),
                .sequence = request.sequence,
                .deadline_ms = 0U,
                .status = kOk,
                .payload = {},
            };
            bool stop = false;
            if (!hello) {
                if (request.type != 1U || request.payload.size() != 20U ||
                    read_integer(request.payload, 0U, 4U) != 1U ||
                    read_integer(request.payload, 4U, 4U) != options_.bundle.mtu ||
                    read_integer(request.payload, 8U, 4U) < kNapaHeader + options_.bundle.mtu ||
                    read_integer(request.payload, 12U, 4U) < options_.queue_bytes ||
                    read_integer(request.payload, 16U, 4U) != 1U) {
                    app_fail("REMOVABLE_MEDIA_ADAPTER_CAPABILITY_MISMATCH",
                        "HELLO does not admit exact MTU and finite queues");
                }
                append(reply.payload, 1U, 4U);
                append(reply.payload, options_.bundle.mtu, 4U);
                append(reply.payload, kNapaHeader + options_.bundle.mtu, 4U);
                append(reply.payload, options_.queue_bytes, 4U);
                append(reply.payload, 1U, 4U);
                hello = true;
                pump(true);
            } else if (request.type == 3U) {
                if (request.payload.empty() || request.payload.size() > options_.bundle.mtu) {
                    app_fail("REMOVABLE_MEDIA_ADAPTER_PROTOCOL_INVALID", "transmit outside MTU");
                }
                reply.status = publish(request.payload) ? kOk : kBusy;
            } else if (request.type == 5U && request.payload.empty()) {
                pump(true);
                if (received_.empty()) {
                    reply.status = kNoData;
                } else {
                    received_bytes_ -= received_.front().size();
                    reply.payload = std::move(received_.front());
                    received_.pop_front();
                }
            } else if ((request.type == 7U || request.type == 9U) && request.payload.empty()) {
                pump(true);
                stop = request.type == 9U;
            } else {
                app_fail("REMOVABLE_MEDIA_ADAPTER_PROTOCOL_INVALID", "unexpected type or payload");
            }
            send_response(reply, deadline);
            if (stop) {
                return 0;
            }
        }
    }

private:
    [[nodiscard]] Usage usage(const Directory& directory, const bool quarantine_mode) {
        Usage result{};
        const auto names = list_directory(directory, options_.directory_entry_limit);
        for (const auto& name : names) {
            const bool relevant = quarantine_mode ?
                (name.starts_with("q-") && name.ends_with(".txt")) :
                removable_media::parse_filename(name).has_value();
            if (!relevant) {
                continue;
            }
            struct stat status {};
            if (::fstatat(directory.fd.get(), name.c_str(), &status, AT_SYMLINK_NOFOLLOW) != 0) {
                if (errno == ENOENT) {
                    continue;
                }
                app_fail("REMOVABLE_MEDIA_FILE_STAT_FAILED", datacube::errno_detail(name, errno));
            }
            if (!S_ISREG(status.st_mode) || status.st_uid != ::geteuid() ||
                status.st_nlink != 1 || (status.st_mode & (S_IRWXG | S_IRWXO)) != 0 ||
                status.st_size < 0) {
                app_fail("REMOVABLE_MEDIA_FILE_UNSAFE", directory.role + "/" + name);
            }
            const auto size = static_cast<std::size_t>(status.st_size);
            if (result.files == std::numeric_limits<std::size_t>::max() ||
                size > std::numeric_limits<std::size_t>::max() - result.bytes) {
                app_fail("REMOVABLE_MEDIA_LIMIT_INVALID", "directory usage overflow");
            }
            ++result.files;
            result.bytes += size;
        }
        return result;
    }

    void quarantine_evidence(
        const std::string_view source,
        const std::string& name,
        const std::string_view reason,
        const std::span<const std::uint8_t> bytes) {
        const auto content_digest = datacube::sha256(bytes);
        std::string record =
            "NATRAV_REMOVABLE_MEDIA_QUARANTINE_V1\nsource=" + std::string(source) +
            "\nreason=" + std::string(reason) +
            "\nname_hex=" + bytes_hex(name) +
            "\nbytes=" + std::to_string(bytes.size()) +
            "\nsha256=" + datacube::hex_lower(content_digest) + "\n";
        if (record.size() > kMaximumEvidenceBytes) {
            record.resize(kMaximumEvidenceBytes);
        }
        const auto record_bytes = std::span<const std::uint8_t>(
            reinterpret_cast<const std::uint8_t*>(record.data()), record.size());
        const auto evidence_digest = datacube::sha256(record_bytes);
        const auto evidence_name = "q-" + datacube::hex_lower(evidence_digest) + ".txt";
        const auto current = usage(quarantine_, true);
        if (current.files >= options_.quarantine_files ||
            record.size() > options_.quarantine_bytes - std::min(current.bytes, options_.quarantine_bytes)) {
            ++dropped_quarantine_events_;
            return;
        }
        static_cast<void>(publish_atomic(
            quarantine_, evidence_name, record_bytes, temporary_sequence_));
    }

    void discard_invalid(
        const Directory& directory,
        const std::string& name,
        const FileImage& image,
        const std::string_view reason) {
        quarantine_evidence(directory.role, name, reason, image.bytes);
        unlink_exact(directory, name, image.object);
    }

    void discard_prior_incarnation_files() {
        const auto discard = [&](const Directory& directory) {
            const auto names = list_directory(directory, options_.directory_entry_limit);
            for (const auto& name : names) {
                if (!removable_media::parse_filename(name).has_value()) {
                    // In-progress names are not stable objects.  The ordinary
                    // bounded stale-part cleanup handles them after their full
                    // lifetime without racing an active copy or publication.
                    continue;
                }
                const auto image = read_file(
                    directory, name,
                    removable_media::kBundleOverheadBytes + options_.bundle.mtu);
                if (image.has_value()) {
                    discard_invalid(
                        directory, name, *image, "STALE_ADAPTER_INCARNATION");
                }
            }
        };
        // A supervised child owns one packet-link incarnation.  Files left by
        // an earlier child cannot be attributed to the new finite stream or its
        // TLS session.  Treat them as bounded carrier loss; the durable sender
        // and finite packet layer retain responsibility for retransmission.
        discard(inbound_);
        discard(outbound_);
    }

    void remember(const std::string& digest) {
        if (recent_.contains(digest)) {
            return;
        }
        recent_.insert(digest);
        recent_order_.push_back(digest);
        while (recent_order_.size() > options_.duplicate_window) {
            recent_.erase(recent_order_.front());
            recent_order_.pop_front();
        }
    }

    void process_inbound(const std::string& name, const std::uint64_t now_ms) {
        const auto digest = removable_media::parse_filename(name);
        if (!digest.has_value()) {
            if (!name.starts_with(kPartPrefix)) {
                return;
            }
            struct stat status {};
            if (::fstatat(inbound_.fd.get(), name.c_str(), &status,
                          AT_SYMLINK_NOFOLLOW) != 0) {
                if (errno == ENOENT) {
                    return;
                }
                app_fail("REMOVABLE_MEDIA_FILE_STAT_FAILED",
                    datacube::errno_detail(inbound_.role + "/" + name, errno));
            }
            const auto changed_ms = modified_ms(status);
            if (now_ms <= changed_ms ||
                now_ms - changed_ms <= options_.bundle.lifetime_ms) {
                return;
            }
            const auto image = read_file(
                inbound_, name, removable_media::kBundleOverheadBytes + options_.bundle.mtu);
            if (image.has_value()) {
                discard_invalid(inbound_, name, *image, "INTERRUPTED_COPY_EXPIRED");
            }
            return;
        }
        const auto image = read_file(
            inbound_, name, removable_media::kBundleOverheadBytes + options_.bundle.mtu);
        if (!image.has_value()) {
            return;
        }
        removable_media::DecodedBundle bundle;
        try {
            bundle = removable_media::decode(options_.bundle, image->bytes, *digest, now_ms);
        } catch (const removable_media::BundleError& error) {
            discard_invalid(inbound_, name, *image, error.code());
            return;
        }
        const auto digest_text = datacube::hex_lower(bundle.digest);
        if (recent_.contains(digest_text)) {
            unlink_exact(inbound_, name, image->object);
            return;
        }
        if (received_.size() >= options_.queue_files ||
            bundle.payload.size() > options_.queue_bytes - received_bytes_) {
            return;
        }
        received_bytes_ += bundle.payload.size();
        received_.push_back(std::move(bundle.payload));
        remember(digest_text);
        unlink_exact(inbound_, name, image->object);
    }

    void cleanup_outbound(const std::string& name, const std::uint64_t now_ms) {
        const auto digest = removable_media::parse_filename(name);
        if (!digest.has_value()) {
            if (!name.starts_with(kTempPrefix)) {
                return;
            }
            struct stat status {};
            if (::fstatat(outbound_.fd.get(), name.c_str(), &status,
                          AT_SYMLINK_NOFOLLOW) != 0) {
                if (errno == ENOENT) {
                    return;
                }
                app_fail("REMOVABLE_MEDIA_FILE_STAT_FAILED",
                    datacube::errno_detail(outbound_.role + "/" + name, errno));
            }
            const auto changed_ms = modified_ms(status);
            if (now_ms <= changed_ms ||
                now_ms - changed_ms <= options_.bundle.lifetime_ms) {
                return;
            }
            const auto image = read_file(
                outbound_, name, removable_media::kBundleOverheadBytes + options_.bundle.mtu);
            if (image.has_value()) {
                discard_invalid(outbound_, name, *image,
                    "INTERRUPTED_PUBLICATION_EXPIRED");
            }
            return;
        }
        const auto image = read_file(
            outbound_, name, removable_media::kBundleOverheadBytes + options_.bundle.mtu);
        if (!image.has_value()) {
            return;
        }
        try {
            static_cast<void>(removable_media::decode(options_.bundle, image->bytes, *digest, now_ms));
        } catch (const removable_media::BundleError& error) {
            discard_invalid(outbound_, name, *image, error.code());
        }
    }

    void scan(const bool immediate) {
        const auto now = Clock::now();
        if (!immediate && now < next_scan_) {
            return;
        }
        next_scan_ = now + Milliseconds(options_.poll_interval_ms);
        verify_directory(inbound_);
        verify_directory(outbound_);
        verify_directory(quarantine_);
        const auto now_ms = system_now_ms();
        auto inbound_names = list_directory(inbound_, options_.directory_entry_limit);
        auto outbound_names = list_directory(outbound_, options_.directory_entry_limit);
        const auto process_rotating = [&](const std::vector<std::string>& names,
                                          std::size_t& cursor,
                                          const auto& operation) {
            if (names.empty()) {
                cursor = 0U;
                return;
            }
            const auto count = std::min(options_.scan_entries, names.size());
            const auto start = cursor % names.size();
            for (std::size_t index = 0U; index < count; ++index) {
                operation(names[(start + index) % names.size()]);
            }
            cursor = (start + count) % names.size();
        };
        process_rotating(inbound_names, inbound_cursor_, [&](const std::string& name) {
            process_inbound(name, now_ms);
        });
        process_rotating(outbound_names, outbound_cursor_, [&](const std::string& name) {
            cleanup_outbound(name, now_ms);
        });
    }

    void pump(const bool immediate) { scan(immediate); }

    [[nodiscard]] bool publish(const Bytes& payload) {
        scan(true);
        const auto now_ms = system_now_ms();
        const auto bytes = removable_media::encode(options_.bundle, payload, now_ms);
        const auto digest = datacube::sha256(
            std::span<const std::uint8_t>(bytes).first(
                bytes.size() - removable_media::kBundleDigestBytes));
        const auto name = removable_media::filename(digest);
        const auto existing = read_file(outbound_, name, bytes.size());
        if (existing.has_value()) {
            if (existing->bytes != bytes) {
                app_fail("REMOVABLE_MEDIA_FILE_COLLISION", "content-addressed outbound name collision");
            }
            return true;
        }
        const auto current = usage(outbound_, false);
        if (current.files >= options_.queue_files ||
            bytes.size() > options_.queue_bytes - std::min(current.bytes, options_.queue_bytes)) {
            return false;
        }
        return publish_atomic(outbound_, name, bytes, temporary_sequence_);
    }

    Options options_;
    Directory inbound_;
    Directory outbound_;
    Directory quarantine_;
    std::deque<Bytes> received_{};
    std::size_t received_bytes_{0U};
    std::set<std::string> recent_{};
    std::deque<std::string> recent_order_{};
    Deadline next_scan_{};
    std::size_t inbound_cursor_{0U};
    std::size_t outbound_cursor_{0U};
    std::uint64_t temporary_sequence_{0U};
    std::size_t dropped_quarantine_events_{0U};
};

}  // namespace

int run_removable_media_packet_adapter(const int argc, char* argv[]) {
    auto options = parse_options(argc, argv);
    validate_protocol_endpoint();
    return Adapter(std::move(options)).run();
}

}  // namespace natrav_overlay
