#pragma once

#include "transport.hpp"

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <string_view>
#include <vector>

namespace natrav_overlay {

inline constexpr std::size_t kMaximumVirtualScheduleEvents = 4096U;
inline constexpr std::uint32_t kMaximumVirtualQueueBytes = 1'048'576U;
inline constexpr std::uint32_t kMaximumVirtualChunkBytes = 65'536U;
inline constexpr std::uint32_t kMaximumVirtualDelaySteps = 1'000'000U;

enum class VirtualEndpoint : std::uint8_t {
    first = 1U,
    second = 2U,
};

enum class VirtualOperation : std::uint8_t {
    read = 1U,
    write = 2U,
    shutdown_write = 3U,
};

enum class VirtualFault : std::uint8_t {
    none = 0U,
    timeout = 1U,
    reset = 2U,
    disconnect = 3U,
    drop = 4U,
    duplicate = 5U,
    corrupt = 6U,
    reorder = 7U,
};

enum class VirtualTraceOutcome : std::uint8_t {
    progress = 1U,
    eof = 2U,
    timeout = 3U,
    reset = 4U,
    disconnected = 5U,
    write_closed = 6U,
};

struct VirtualScheduleEvent final {
    VirtualEndpoint endpoint{VirtualEndpoint::first};
    VirtualOperation operation{VirtualOperation::read};
    VirtualFault fault{VirtualFault::none};
    std::uint32_t operation_index{1U};
    std::uint32_t delay_steps{0U};
    std::uint32_t maximum_bytes{0U};
    std::uint32_t parameter{0U};

    bool operator==(const VirtualScheduleEvent&) const = default;
};

struct VirtualCarrierSchedule final {
    std::uint64_t seed{0U};
    std::uint32_t queue_capacity{65'536U};
    std::uint32_t default_read_chunk{4096U};
    std::uint32_t default_write_chunk{4096U};
    std::uint32_t mtu{4096U};
    bool half_duplex{false};
    std::optional<VirtualEndpoint> initial_grant;
    std::vector<VirtualScheduleEvent> events;

    bool operator==(const VirtualCarrierSchedule&) const = default;
};

struct VirtualTraceRecord final {
    VirtualEndpoint endpoint{VirtualEndpoint::first};
    VirtualOperation operation{VirtualOperation::read};
    std::uint32_t operation_index{0U};
    std::optional<std::uint32_t> event_index;
    std::uint32_t delay_steps{0U};
    std::size_t requested_bytes{0U};
    std::size_t result_bytes{0U};
    VirtualTraceOutcome outcome{VirtualTraceOutcome::progress};

    bool operator==(const VirtualTraceRecord&) const = default;
};

struct VirtualLinkSnapshot final {
    datacube::Digest32 schedule_digest;
    std::uint64_t seed{0U};
    std::size_t first_to_second_queued{0U};
    std::size_t second_to_first_queued{0U};
    bool first_alive{false};
    bool second_alive{false};
    bool reset{false};
    std::vector<VirtualTraceRecord> trace;

    bool operator==(const VirtualLinkSnapshot&) const = default;
};

struct VirtualLinkPair;
class VirtualLinkControl final {
public:
    struct State;
    VirtualLinkControl(const VirtualLinkControl&) = delete;
    VirtualLinkControl& operator=(const VirtualLinkControl&) = delete;
    ~VirtualLinkControl();

    [[nodiscard]] const datacube::Octets& canonical_schedule() const noexcept;
    [[nodiscard]] const datacube::Digest32& schedule_digest() const noexcept;
    [[nodiscard]] VirtualLinkSnapshot snapshot() const;

    // Explicit deterministic fixture controls. They carry no product routing,
    // identity, discovery, or persisted-state authority.
    void reset_link();
    void disconnect_endpoint(VirtualEndpoint endpoint);

private:
    explicit VirtualLinkControl(std::shared_ptr<State> state) noexcept;
    std::shared_ptr<State> state_;

    friend struct VirtualLinkPair;
    friend VirtualLinkPair make_virtual_link(const VirtualCarrierSchedule& schedule);
};

struct VirtualLinkPair final {
    std::unique_ptr<OrderedByteStream> first;
    std::unique_ptr<OrderedByteStream> second;
    std::shared_ptr<VirtualLinkControl> control;
};

[[nodiscard]] std::string_view virtual_endpoint_name(
    VirtualEndpoint endpoint) noexcept;
[[nodiscard]] std::string_view virtual_operation_name(
    VirtualOperation operation) noexcept;
[[nodiscard]] std::string_view virtual_fault_name(VirtualFault fault) noexcept;
[[nodiscard]] std::string_view virtual_trace_outcome_name(
    VirtualTraceOutcome outcome) noexcept;

[[nodiscard]] datacube::Octets encode_virtual_carrier_schedule(
    const VirtualCarrierSchedule& schedule);
[[nodiscard]] VirtualCarrierSchedule decode_virtual_carrier_schedule(
    datacube::OctetView bytes);
[[nodiscard]] datacube::Digest32 virtual_carrier_schedule_digest(
    const VirtualCarrierSchedule& schedule);
[[nodiscard]] datacube::Octets encode_virtual_trace(
    const std::vector<VirtualTraceRecord>& trace);

[[nodiscard]] VirtualLinkPair make_virtual_link(
    const VirtualCarrierSchedule& schedule);

}  // namespace natrav_overlay
