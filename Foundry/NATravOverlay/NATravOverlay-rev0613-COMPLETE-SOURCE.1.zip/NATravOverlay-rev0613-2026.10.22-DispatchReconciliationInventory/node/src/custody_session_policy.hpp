#pragma once

#include "custody_policy.hpp"

#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

inline constexpr std::string_view kCustodySessionPolicyFeature =
    "V22_NATIVE_CUSTODY_SESSION_POLICY_V1";
inline constexpr std::size_t kCustodySessionRuleLimit = 128U;
inline constexpr std::size_t kCustodySessionRulePerIdLimit = 16U;
inline constexpr std::uint32_t kCustodySessionMaximumPendingCases = 4'096U;
inline constexpr std::uint32_t kCustodySessionMaximumBundleBytes = 60'000U;
inline constexpr std::uint32_t kCustodySessionMaximumAttempts = 32U;
inline constexpr std::uint64_t kCustodySessionMaximumTransferWindowMs =
    7U * 24U * 60U * 60U * 1'000U;

enum class CustodySessionRuleState : std::uint8_t {
    active = 1U,
    retired = 2U,
    revoked = 3U,
};

// One shared, immutable transition authority. Both endpoint configurations
// retain the same rule commitment; each derives its sender/receiver role from
// the referenced V21 grant and its own accepted local identity. Carrier choice
// remains an explicit invocation input and is not relay authority.
struct CustodySessionRule final {
    std::string id;
    std::uint64_t generation{1U};
    datacube::Digest32 predecessor;
    CustodySessionRuleState state{CustodySessionRuleState::active};
    CustodyGrantReference grant;
    datacube::Digest32 custodian_certificate_sha256;
    datacube::Digest32 next_hop_certificate_sha256;
    std::uint32_t maximum_pending_cases{0U};
    std::uint32_t maximum_bundle_bytes{0U};
    std::uint32_t maximum_attempts{0U};
    std::uint64_t maximum_transfer_window_ms{0U};
    std::uint64_t authority_expires_unix_ms{0U};
};

using CustodySessionPolicy = std::vector<CustodySessionRule>;

[[nodiscard]] std::string_view custody_session_rule_state_name(
    CustodySessionRuleState state);
[[nodiscard]] std::string custody_session_rule_commitment_text(
    const CustodySessionRule& rule);
[[nodiscard]] datacube::Digest32 custody_session_rule_commitment(
    const CustodySessionRule& rule);
[[nodiscard]] std::string custody_session_rule_text(
    const CustodySessionRule& rule);
[[nodiscard]] CustodySessionRule parse_custody_session_rule(
    std::string_view hex);
void normalize_custody_session_policy(CustodySessionPolicy& rules);
void require_custody_session_history_preserved(
    const CustodySessionPolicy& historical,
    const CustodySessionPolicy& candidate);
[[nodiscard]] const CustodySessionRule* find_custody_session_rule(
    const CustodySessionPolicy& policy,
    std::string_view id,
    std::uint64_t generation) noexcept;
[[nodiscard]] const CustodyRelayGrant& resolve_custody_session_grant(
    const CustodyRelayPolicy& grants,
    const CustodySessionRule& rule,
    bool require_active);
[[nodiscard]] std::string custody_session_policy_json(
    const CustodySessionPolicy& rules);

} // namespace natrav_overlay
