#include "common.hpp"

#include <algorithm>
#include <array>
#include <charconv>
#include <cerrno>
#include <fcntl.h>
#include <limits>
#include <string>
#include <sys/stat.h>
#include <unistd.h>

namespace natrav_overlay {
namespace {

[[nodiscard]] bool ascii_alnum(const unsigned char ch) noexcept {
    return (ch >= static_cast<unsigned char>('A') &&
            ch <= static_cast<unsigned char>('Z')) ||
        (ch >= static_cast<unsigned char>('a') &&
         ch <= static_cast<unsigned char>('z')) ||
        (ch >= static_cast<unsigned char>('0') &&
         ch <= static_cast<unsigned char>('9'));
}

[[nodiscard]] datacube::Octets domain_input(
    const std::string_view domain,
    const std::string_view value) {
    datacube::Octets out;
    out.reserve(domain.size() + 1U + value.size());
    datacube::append_text(out, domain);
    datacube::append_u8(out, 0U);
    datacube::append_text(out, value);
    return out;
}

}  // namespace

AppError::AppError(std::string code, std::string detail)
    : std::runtime_error(code + ": " + detail), code_(std::move(code)) {}

const std::string& AppError::code() const noexcept { return code_; }

AuthenticatedPeerError::AuthenticatedPeerError(
    std::string code,
    std::string detail,
    const bool terminal)
    : std::runtime_error(code + ": " + detail),
      code_(std::move(code)),
      detail_(std::move(detail)),
      terminal_(terminal) {}

const std::string& AuthenticatedPeerError::code() const noexcept {
    return code_;
}

const std::string& AuthenticatedPeerError::detail() const noexcept {
    return detail_;
}

bool AuthenticatedPeerError::terminal() const noexcept { return terminal_; }

[[noreturn]] void app_fail(
    const std::string_view code,
    const std::string_view detail) {
    throw AppError(std::string(code), std::string(detail));
}

bool valid_node_id(const std::string_view value) noexcept {
    if (value.empty() || value.size() > 64U) {
        return false;
    }
    return std::all_of(value.begin(), value.end(), [](const char raw) {
        const auto ch = static_cast<unsigned char>(raw);
        return ascii_alnum(ch) || ch == static_cast<unsigned char>('.') ||
            ch == static_cast<unsigned char>('_') ||
            ch == static_cast<unsigned char>('-');
    });
}


bool valid_generation_id(const std::string_view value) noexcept {
    return valid_node_id(value) && value != "." && value != "..";
}

bool valid_scope(const std::string_view value) noexcept {
    if (value.empty() || value.size() > 128U) {
        return false;
    }
    return std::all_of(value.begin(), value.end(), [](const char raw) {
        const auto ch = static_cast<unsigned char>(raw);
        return ascii_alnum(ch) || ch == static_cast<unsigned char>('.') ||
            ch == static_cast<unsigned char>('_') ||
            ch == static_cast<unsigned char>('-') ||
            ch == static_cast<unsigned char>(':') ||
            ch == static_cast<unsigned char>('/');
    });
}

bool valid_error_code(const std::string_view value) noexcept {
    if (value.empty() || value.size() > 64U) {
        return false;
    }
    return std::all_of(value.begin(), value.end(), [](const char raw) {
        const auto ch = static_cast<unsigned char>(raw);
        return (ch >= static_cast<unsigned char>('A') &&
                ch <= static_cast<unsigned char>('Z')) ||
            (ch >= static_cast<unsigned char>('0') &&
             ch <= static_cast<unsigned char>('9')) ||
            ch == static_cast<unsigned char>('_');
    });
}

bool authenticated_peer_error_is_terminal(
    const std::string_view code) noexcept {
    // Only exact, operation-bound application decisions belong here. Capacity,
    // ordering, storage, timeout, and transport failures remain retryable.
    return code == "AUTHORIZATION_DENIED" ||
        code == "WRONG_RECIPIENT" ||
        code == "AUTHENTICATED_ISSUER_MISMATCH" ||
        code == "INBOUND_OPERATION_CONFLICT" ||
        code == "CORRECTION_ANCESTRY_MISMATCH" ||
        code == "CORRECTION_BRANCH_REJECTED" ||
        code == "ACTION_REQUEST_INVALID" ||
        code == "ACTION_REQUIRES_AUTHENTICATED_POLICY" ||
        code == "ACTION_CORRECTION_REJECTED" ||
        code == "ACTION_INCREMENT_LIMIT" ||
        code == "ACTION_DEFER_LIMIT" ||
        code == "ACTION_RESULT_POLICY_REQUIRED" ||
        code == "APPLICATION_KIND_REJECTED";
}

void require_node_id(
    const std::string_view value,
    const std::string_view field) {
    if (!valid_node_id(value)) {
        app_fail("INVALID_NODE_ID", std::string(field) +
            " must be 1..64 ASCII letters, digits, dot, underscore, or hyphen");
    }
}


void require_generation_id(
    const std::string_view value,
    const std::string_view field) {
    if (!valid_generation_id(value)) {
        app_fail("INVALID_KEY_GENERATION", std::string(field) +
            " must be 1..64 ASCII letters, digits, dot, underscore, or hyphen and not dot/dot-dot");
    }
}

void require_scope(const std::string_view value) {
    if (!valid_scope(value)) {
        app_fail("INVALID_SCOPE",
            "scope must be 1..128 ASCII letters, digits, dot, underscore, hyphen, colon, or slash");
    }
}

datacube::Digest32 parse_operation_id(const std::string_view value) {
    if (value.size() != 64U ||
        !std::all_of(value.begin(), value.end(), [](const char ch) {
            return (ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f');
        })) {
        app_fail("INVALID_OPERATION_ID",
            "operation ID must be exactly 64 lowercase hexadecimal characters");
    }
    const auto digest = datacube::parse_hex_digest32(value, "operation-id");
    if (digest_is_zero(digest)) {
        app_fail("INVALID_OPERATION_ID", "all-zero operation ID is reserved");
    }
    return digest;
}

std::string operation_id_text(const datacube::Digest32& value) {
    return datacube::hex_lower(value);
}

bool digest_is_zero(const datacube::Digest32& value) noexcept {
    return std::all_of(value.octets.begin(), value.octets.end(),
        [](const std::uint8_t byte) { return byte == 0U; });
}

datacube::Digest32 node_artifact_digest(const std::string_view node_id) {
    require_node_id(node_id, "node ID");
    const auto bytes = domain_input("NATRAV_OVERLAY_NODE_ARTIFACT_V1", node_id);
    return datacube::sha256(bytes);
}

datacube::NATravPeerArtifactIdentity node_artifact_identity(
    const std::string_view node_id) {
    return datacube::NATravPeerArtifactIdentity{
        .sha256 = datacube::hex_lower(node_artifact_digest(node_id)),
        .target = "x86_64-unknown-linux-gnu",
        .version = "natrav-overlay-node-0502",
    };
}

std::vector<std::string> node_capabilities() {
    return {
        "AUTHORIZATION_POLICY_V1",
        "BOUNDED_PEER_SESSIONS_V1",
        "CANONICAL_CHECKPOINT_V2",
        "CORRECTION_CHAIN_V1",
        "DURABLE_COUNTER_ACTION_V1",
        "DURABLE_OBLIGATION_RESOLUTION_V1",
        "DURABLE_RECEIPT_V1",
        "DURABLE_REJECTION_V1",
        "KEY_GENERATIONS_V1",
        "LIVE_COMPACTION_V1",
        "NATIVE_TCP_V1",
        "OFFLINE_STATE_RELOCATION_V1",
        "RECIPIENT_SCOPED_EVIDENCE_V1",
        "RESERVED_OUTBOX_QUOTAS_V1",
        "STORAGE_SCHEMA_V2",
        "TLS13_MUTUAL_SPKI_PIN_V1",
        "VERIFIABLE_BACKUP_V1",
    };
}

std::string json_string(const std::string_view value) {
    return "\"" + datacube::json_escape(value) + "\"";
}

std::string hex_bytes(const datacube::OctetView value) {
    return datacube::hex_lower(value);
}

datacube::Octets read_payload_file(
    const std::filesystem::path& path,
    const std::size_t ceiling) {
    const int raw = ::open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (raw < 0) {
        app_fail("PAYLOAD_FILE_OPEN_FAILED",
            datacube::errno_detail(path.string(), errno));
    }
    datacube::Fd fd(raw);
    struct stat status {};
    if (::fstat(fd.get(), &status) != 0) {
        app_fail("PAYLOAD_FILE_STAT_FAILED",
            datacube::errno_detail(path.string(), errno));
    }
    if (!S_ISREG(status.st_mode)) {
        app_fail("PAYLOAD_FILE_NOT_REGULAR", path.string());
    }
    if (status.st_size < 0 ||
        static_cast<std::uint64_t>(status.st_size) >
            static_cast<std::uint64_t>(ceiling)) {
        app_fail("PAYLOAD_TOO_LARGE", path.string());
    }
    return datacube::read_all_fd(
        fd.get(), static_cast<std::uint64_t>(ceiling), path.string());
}

std::uint64_t parse_u64(
    const std::string_view value,
    const std::string_view field,
    const std::uint64_t minimum,
    const std::uint64_t maximum) {
    std::uint64_t parsed = 0U;
    const auto result = std::from_chars(
        value.data(), value.data() + value.size(), parsed);
    if (result.ec != std::errc{} ||
        result.ptr != value.data() + value.size() ||
        parsed < minimum || parsed > maximum) {
        app_fail("INVALID_ARGUMENT", std::string(field) +
            " must be an integer in [" + std::to_string(minimum) + "," +
            std::to_string(maximum) + "]");
    }
    return parsed;
}

std::chrono::milliseconds parse_milliseconds(
    const std::string_view value,
    const std::string_view field,
    const std::uint64_t minimum,
    const std::uint64_t maximum) {
    const auto parsed = parse_u64(value, field, minimum, maximum);
    if (parsed > static_cast<std::uint64_t>(
            std::numeric_limits<std::chrono::milliseconds::rep>::max())) {
        app_fail("INVALID_ARGUMENT", std::string(field) + " is too large");
    }
    return std::chrono::milliseconds(
        static_cast<std::chrono::milliseconds::rep>(parsed));
}

}  // namespace natrav_overlay
