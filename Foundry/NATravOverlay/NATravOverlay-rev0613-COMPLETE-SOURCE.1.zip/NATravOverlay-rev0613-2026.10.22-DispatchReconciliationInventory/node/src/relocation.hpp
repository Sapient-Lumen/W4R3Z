#pragma once

#include "journal.hpp"

#include <cstdint>
#include <filesystem>
#include <string>

namespace natrav_overlay {

struct StateRelocationOptions final {
    std::filesystem::path state_directory;
    std::string node_id;
    std::filesystem::path candidate_config;
    std::string reason;
    std::uint64_t maximum_journal_bytes{67'108'864U};
};

struct StateRelocationResult final {
    std::filesystem::path state_directory;
    std::string from_generation;
    datacube::Digest32 from_digest;
    std::string to_generation;
    datacube::Digest32 to_digest;
    std::filesystem::path old_state_directory;
    std::filesystem::path new_state_directory;
    std::filesystem::path old_control_socket;
    std::filesystem::path new_control_socket;
    std::filesystem::path old_certificate;
    std::filesystem::path new_certificate;
    std::filesystem::path old_private_key;
    std::filesystem::path new_private_key;
    datacube::Digest32 identity_spki_sha256;
    std::uint64_t relocated_unix_ms{0U};
    std::uint64_t configuration_event{0U};
    datacube::Digest32 logical_state_before;
    datacube::Digest32 logical_state_after;
    std::string input_state_head;
    std::string result_state_head;
};

[[nodiscard]] StateRelocationResult relocate_state(
    const StateRelocationOptions& options);
[[nodiscard]] std::string state_relocation_result_json(
    const StateRelocationResult& result);

}  // namespace natrav_overlay
