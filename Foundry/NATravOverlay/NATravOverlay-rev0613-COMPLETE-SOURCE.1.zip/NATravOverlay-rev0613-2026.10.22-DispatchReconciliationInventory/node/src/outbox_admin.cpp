#include "outbox_admin.hpp"
#include "identity.hpp"
#include <algorithm>

namespace natrav_overlay {
namespace {
void need(bool b,std::string_view message){if(!b)app_fail("OUTBOX_CONDITION_INVALID",message);}
void text(datacube::Octets& out,std::string_view v){datacube::append_be16(out,static_cast<std::uint16_t>(v.size()));datacube::append_text(out,v);}
std::string text(datacube::Reader& r,std::size_t limit){const auto n=r.read_be16("text");need(n<=limit,"text exceeds bound");return datacube::octets_text(r.read_exact(n,"text"),"text",true);}
void put(datacube::Octets& b,const datacube::Digest32& d){datacube::append_octets(b,d.octets);}
datacube::Digest32 get(datacube::Reader& r){datacube::Digest32 d{};const auto b=r.read_exact(32U,"digest");std::copy(b.begin(),b.end(),d.octets.begin());return d;}
bool reason_ok(std::string_view s){return !s.empty()&&s.size()<=256U&&std::all_of(s.begin(),s.end(),[](unsigned char c){return c>=32U&&c<=126U;});}
std::string hx(const datacube::Digest32& d){return json_string(datacube::hex_lower(d));}
}
std::string_view outbox_admin_kind_name(OutboxAdminKind k){switch(k){case OutboxAdminKind::cancel:return "CANCEL";case OutboxAdminKind::retry:return "RETRY";case OutboxAdminKind::rebind:return "REBIND";}return "UNKNOWN";}
void validate_outbox_admin_request(const OutboxAdminRequest& r){
 need(r.kind>=OutboxAdminKind::cancel&&r.kind<=OutboxAdminKind::rebind,"unknown conditional action");
 need(!digest_is_zero(r.operation)&&!digest_is_zero(r.expected_state)&&!digest_is_zero(r.expected_configuration),"nonzero operation, semantic state and configuration digests required");
 need(reason_ok(r.reason),"reason must be 1..256 printable ASCII bytes");
 need(r.kind==OutboxAdminKind::rebind?valid_generation_id(r.generation):r.generation.empty(),"target generation is required only for rebind");
}
datacube::Octets encode_outbox_admin_request(const OutboxAdminRequest& r){validate_outbox_admin_request(r);datacube::Octets b;datacube::append_text(b,"OCA1");datacube::append_u8(b,static_cast<std::uint8_t>(r.kind));put(b,r.operation);put(b,r.expected_state);put(b,r.expected_configuration);text(b,r.generation);text(b,r.reason);return b;}
OutboxAdminRequest decode_outbox_admin_request(datacube::OctetView b){datacube::Reader r(b,"conditional outbox request");need(datacube::octets_text(r.read_exact(4U,"magic"),"magic",true)=="OCA1","unknown request version");OutboxAdminRequest q;q.kind=static_cast<OutboxAdminKind>(r.read_u8("action"));q.operation=get(r);q.expected_state=get(r);q.expected_configuration=get(r);q.generation=text(r,64U);q.reason=text(r,256U);r.require_eof("conditional request");validate_outbox_admin_request(q);return q;}
datacube::Digest32 outbox_admin_request_digest(const OutboxAdminRequest& r,std::uint32_t uid){datacube::Octets b;datacube::append_text(b,"NATRAV_OVERLAY_OUTBOX_ADMIN_REQUEST_V1");datacube::append_u8(b,0U);datacube::append_be32(b,uid);datacube::append_octets(b,encode_outbox_admin_request(r));return datacube::sha256(b);}
datacube::Digest32 outbox_selected_digest(datacube::OctetView metadata,std::uint8_t restrictions,const datacube::Digest32& root){datacube::Octets b;datacube::append_text(b,"NATRAV_OVERLAY_OUTBOX_SELECTION_V1");datacube::append_u8(b,0U);datacube::append_be32(b,static_cast<std::uint32_t>(metadata.size()));datacube::append_octets(b,metadata);datacube::append_u8(b,restrictions);put(b,root);return datacube::sha256(b);}
datacube::Octets encode_outbox_admin_record(const OutboxAdminRecord& r){
 const auto q=encode_outbox_admin_request(r.request);need(r.before_metadata.size()<=kOutboxAdminMetadataLimit,"conditional metadata bound");
 datacube::Octets b;datacube::append_text(b,"OAT1");datacube::append_be32(b,static_cast<std::uint32_t>(q.size()));datacube::append_octets(b,q);
 datacube::append_be32(b,r.uid);datacube::append_be32(b,r.gid);datacube::append_be32(b,r.pid);datacube::append_be64(b,r.unix_ms);datacube::append_be64(b,r.configuration_event);
 put(b,r.request_digest);put(b,r.prior_admin_root);put(b,r.resulting_metadata_digest);datacube::append_u8(b,r.restrictions);datacube::append_be32(b,static_cast<std::uint32_t>(r.before_metadata.size()));datacube::append_octets(b,r.before_metadata);return b;
}
OutboxAdminRecord decode_outbox_admin_record(datacube::OctetView b){
 datacube::Reader r(b,"outbox administration event");need(datacube::octets_text(r.read_exact(4U,"magic"),"magic",true)=="OAT1","unknown event version");const auto n=r.read_be32("request size");need(n<=512U,"request size bound");OutboxAdminRecord a;a.request=decode_outbox_admin_request(r.read_exact(n,"request"));a.uid=r.read_be32("uid");a.gid=r.read_be32("gid");a.pid=r.read_be32("pid");a.unix_ms=r.read_be64("time");a.configuration_event=r.read_be64("configuration");a.request_digest=get(r);a.prior_admin_root=get(r);a.resulting_metadata_digest=get(r);a.restrictions=r.read_u8("restrictions");const auto size=r.read_be32("metadata size");need(size<=kOutboxAdminMetadataLimit,"metadata size bound");const auto bytes=r.read_exact(size,"metadata");a.before_metadata.assign(bytes.begin(),bytes.end());r.require_eof("conditional event");need(a.unix_ms!=0U&&a.pid!=0U&&a.configuration_event!=0U&&a.restrictions<=15U,"invalid event provenance");need(a.request_digest==outbox_admin_request_digest(a.request,a.uid),"conditional request digest mismatch");return a;
}
std::string outbox_admin_record_json(const OutboxAdminRecord& a){
 return "{\"operation_id\":"+hx(a.request.operation)+",\"request_digest\":"+hx(a.request_digest)+",\"action\":"+json_string(outbox_admin_kind_name(a.request.kind))+",\"uid\":"+std::to_string(a.uid)+",\"gid\":"+std::to_string(a.gid)+",\"pid\":"+std::to_string(a.pid)+",\"unix_ms\":"+std::to_string(a.unix_ms)+",\"configuration_event\":"+std::to_string(a.configuration_event)+",\"configuration_digest\":"+hx(a.request.expected_configuration)+",\"selected_state_digest\":"+hx(a.request.expected_state)+",\"resulting_metadata_digest\":"+hx(a.resulting_metadata_digest)+",\"target_generation\":"+json_string(a.request.generation)+",\"reason_bytes\":"+std::to_string(a.request.reason.size())+",\"reason_sha256\":"+hx(datacube::sha256(datacube::text_octets(a.request.reason)))+"}";
}
} // namespace natrav_overlay
