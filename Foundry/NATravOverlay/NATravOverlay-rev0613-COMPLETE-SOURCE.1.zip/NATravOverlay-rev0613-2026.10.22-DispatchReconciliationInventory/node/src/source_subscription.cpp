#include "source_subscription.hpp"
#include "config.hpp"
#include "journal.hpp"
#include "peer_session.hpp"
#include "source_validation_work.hpp"

#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <limits>
#include <mutex>
#include <set>
#include <thread>
#include <utility>
#include <unistd.h>

namespace natrav_overlay {
namespace {
using Bytes = datacube::Octets;
using View = datacube::OctetView;
using Digest = datacube::Digest32;
void check(bool ok, std::string_view detail) {
    if (!ok) { app_fail("JOURNAL_CORRUPT", std::string(detail)); }
}
void text(Bytes& out, std::string_view value) {
    if (value.size() > 256U) { app_fail("SOURCE_SUBSCRIPTION_INVALID", "text exceeds bound"); }
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}
std::string text(datacube::Reader& r, std::size_t maximum = 256U) {
    const auto length = r.read_be16("source text length");
    check(length <= maximum, "source text bound");
    return datacube::octets_text(r.read_exact(length, "source text"), "source text", true);
}
void digest(Bytes& out, const Digest& value) { datacube::append_octets(out, value.octets); }
Digest digest(datacube::Reader& r) {
    Digest out{};
    const auto data = r.read_exact(32U, "source digest");
    std::copy(data.begin(), data.end(), out.octets.begin());
    return out;
}
bool boolean(datacube::Reader& r) {
    const auto v = r.read_u8("source marker"); check(v <= 1U, "source boolean marker"); return v != 0U;
}
Digest hash(std::string_view domain, View bytes) {
    Bytes out; datacube::append_text(out, domain); datacube::append_u8(out, 0U);
    datacube::append_octets(out, bytes); return datacube::sha256(out);
}
bool reason_ok(std::string_view value) {
    return !value.empty() && value.size() <= 256U && std::all_of(value.begin(), value.end(), [](char c) {
        const auto v = static_cast<unsigned char>(c); return v >= 32U && v <= 126U;
    });
}
Bytes grant_bytes(const SourceDisclosureGrant& g) {
    Bytes out; text(out, g.id); datacube::append_be32(out, g.uid); datacube::append_be32(out, g.author_uid);
    text(out, g.peer); text(out, g.generation); text(out, g.scope);
    datacube::append_be32(out, g.maximum_records); datacube::append_be64(out, g.maximum_payload_bytes);
    if (!g.lease_generation.empty()) {
        text(out, g.lease_generation);
        datacube::append_be64(out, g.lease_duration_ms);
        datacube::append_u8(out, static_cast<std::uint8_t>(g.withdrawal_pending));
    }
    return out;
}
Digest grant_digest(const SourceDisclosureGrant& g) {
    return hash(g.lease_generation.empty() ?
        "NATRAV_OVERLAY_SOURCE_DISCLOSURE_GRANT_V1" :
        "NATRAV_OVERLAY_SOURCE_DISCLOSURE_GRANT_V2", grant_bytes(g));
}
void validate_grant(const SourceDisclosureGrant& g) {
    const bool leased = !g.lease_generation.empty();
    const bool lease_valid = leased ?
        (valid_generation_id(g.lease_generation) && g.lease_duration_ms >= 100U &&
         g.lease_duration_ms <= 604'800'000U &&
         (g.withdrawal_pending == SourcePendingDisposition::retain ||
          g.withdrawal_pending == SourcePendingDisposition::cancel)) :
        (g.lease_duration_ms == 0U && g.withdrawal_pending == SourcePendingDisposition::retain);
    if (!valid_generation_id(g.id) || !valid_node_id(g.peer) || !valid_generation_id(g.generation) ||
        !valid_scope(g.scope) || g.scope.starts_with("actions/") || g.maximum_records == 0U ||
        g.maximum_records > kSourceSubscriptionRecordLimit || g.maximum_payload_bytes == 0U ||
        g.maximum_payload_bytes > 7'680'000U || !lease_valid || g.digest != grant_digest(g)) {
        app_fail("SOURCE_DISCLOSURE_INVALID", "exact identifiers, non-action scope, finite budgets, and valid lease policy required");
    }
}
SourceDisclosureGrant read_grant(datacube::Reader& r, const bool leased) {
    SourceDisclosureGrant g;
    g.id = text(r, 64U); g.uid = r.read_be32("owner"); g.author_uid = r.read_be32("source author");
    g.peer = text(r, 64U); g.generation = text(r, 64U); g.scope = text(r, 128U);
    g.maximum_records = r.read_be32("source record limit"); g.maximum_payload_bytes = r.read_be64("source byte limit");
    if (leased) {
        g.lease_generation = text(r, 64U);
        g.lease_duration_ms = r.read_be64("source lease duration");
        const auto pending = r.read_u8("source withdrawal policy");
        check(pending == static_cast<std::uint8_t>(SourcePendingDisposition::retain) ||
              pending == static_cast<std::uint8_t>(SourcePendingDisposition::cancel),
              "source withdrawal policy rejected");
        g.withdrawal_pending = static_cast<SourcePendingDisposition>(pending);
    }
    g.digest = digest(r); validate_grant(g); return g;
}
Digest instance_id(std::string_view node, const SourceDisclosureGrant& g) {
    Bytes b; text(b, node); digest(b, g.digest);
    return hash("NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_INSTANCE_V1", b);
}
Digest request_digest(const SourceSubscriptionRequest& r) {
    auto semantic = r;
    semantic.compact_response = false;
    return hash("NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_REQUEST_V1", encode_source_subscription_request(semantic));
}
Digest remote_request_digest(const RemoteSourceSubscriptionRequest& r) {
    return hash("NATRAV_OVERLAY_REMOTE_SOURCE_SUBSCRIPTION_REQUEST_V1",
        encode_application_message(r));
}
void pause_at(const char* name) {
    if (const auto* value = std::getenv(name)) {
        const auto duration = parse_u64(value, "source subscription test pause", 1U, 30'000U);
        std::this_thread::sleep_for(std::chrono::milliseconds(duration));
    }
}
std::uint64_t now_ms() {
    return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count());
}
bool automatic_enabled(const SourceSubscription& value) {
    return !value.automatic_grants.empty() &&
        value.automatic_grants.back().state == "ENABLED";
}
void finish_automatic_grant(SourceSubscriptionAutomaticGrant& grant,
    const SourceSubscription& value, const std::string_view state,
    const std::string_view error, const std::string_view reason,
    const std::uint32_t uid, const std::uint32_t pid) {
    grant.state = std::string(state);
    grant.error = std::string(error);
    grant.end_reason = std::string(reason);
    grant.ended_event = value.configuration_event;
    grant.ended_unix_ms = value.unix_ms;
    grant.ended_uid = uid;
    grant.ended_pid = pid;
}
std::string automatic_grant_json(const SourceSubscriptionAutomaticGrant& grant) {
    return "{\"generation\":" + std::to_string(grant.generation) +
        ",\"observed_subscription_revision\":" +
            std::to_string(grant.observed_subscription_revision) +
        ",\"configuration_event\":" + std::to_string(grant.configuration_event) +
        ",\"unix_ms\":" + std::to_string(grant.unix_ms) +
        ",\"actor_uid\":" + std::to_string(grant.actor_uid) +
        ",\"pid\":" + std::to_string(grant.pid) +
        ",\"maximum_steps\":" + std::to_string(grant.maximum_steps) +
        ",\"minimum_interval_ms\":" + std::to_string(grant.minimum_interval_ms) +
        ",\"disclosure_digest\":" + json_string(datacube::hex_lower(grant.disclosure_digest)) +
        ",\"reason\":" + json_string(grant.reason) +
        ",\"start_issued\":" + std::to_string(grant.start_issued) +
        ",\"start_acknowledged\":" + std::to_string(grant.start_acknowledged) +
        ",\"steps\":" + std::to_string(grant.steps) +
        ",\"state\":" + json_string(grant.state) +
        ",\"error\":" + json_string(grant.error) +
        ",\"end_reason\":" + json_string(grant.end_reason) +
        ",\"last_step_event\":" + std::to_string(grant.last_step_event) +
        ",\"last_step_unix_ms\":" + std::to_string(grant.last_step_unix_ms) +
        ",\"last_executor_uid\":" + std::to_string(grant.last_executor_uid) +
        ",\"last_executor_pid\":" + std::to_string(grant.last_executor_pid) +
        ",\"ended_event\":" + std::to_string(grant.ended_event) +
        ",\"ended_unix_ms\":" + std::to_string(grant.ended_unix_ms) +
        ",\"ended_uid\":" + std::to_string(grant.ended_uid) +
        ",\"ended_pid\":" + std::to_string(grant.ended_pid) + "}";
}
bool automatic_terminal_state(const std::string_view state) {
    return state == "PAUSED" || state == "BLOCKED" ||
        state == "EXHAUSTED" || state == "RETIRED";
}
std::uint64_t automatic_schedule_revision(const SourceSubscription& value) {
    std::uint64_t revision = value.automatic_grants.size();
    for (const auto& grant : value.automatic_grants) {
        revision += grant.steps;
        if (grant.state == "PAUSED" || grant.state == "BLOCKED" ||
            grant.state == "RETIRED") {
            ++revision;
        }
    }
    return revision;
}
std::uint64_t source_revision_expected(const SourceSubscription& value) {
    std::uint64_t result = 1U + value.deliveries.size() + value.acknowledged +
        (value.retired ? 1U : 0U) + value.automatic_grants.size();
    for (const auto& grant : value.automatic_grants) {
        if (grant.state == "PAUSED" || grant.state == "BLOCKED") { ++result; }
    }
    return result;
}
RuntimeConfig event_config(const std::vector<RuntimeConfigurationEvent>& history, std::uint64_t event) {
    check(event != 0U && event <= history.size() && history[static_cast<std::size_t>(event - 1U)].kind != "REJECTED",
        "source subscription configuration event missing");
    if (active_source_validation_work) {
        ++active_source_validation_work->configuration_parses;
        active_source_validation_work->configuration_bytes +=
            history[static_cast<std::size_t>(event - 1U)].canonical.size();
    }
    return parse_runtime_config(history[static_cast<std::size_t>(event - 1U)].canonical,
        "/source-subscription-history", IdentityFileValidation::deferred);
}
// Memoize parsing only within one locked semantic validation. These objects
// come from exact already accepted canonical events; they are never persisted
// and cannot survive a caller, mutation or state-owner change. Nested full
// checks (reconciliation) and one checkpoint registry pass share the scope.
struct SourceConfigurationMemo final {
    const std::vector<RuntimeConfigurationEvent>* history;
    std::map<std::uint64_t, RuntimeConfig> parsed;
};
thread_local SourceConfigurationMemo* active_source_configuration_memo = nullptr;
class SourceConfigurationScope final {
public:
    explicit SourceConfigurationScope(const std::vector<RuntimeConfigurationEvent>& history)
        : local_{&history, {}}, previous_(active_source_configuration_memo) {
        active_source_configuration_memo = previous_ && previous_->history == &history ? previous_ : &local_;
    }
    ~SourceConfigurationScope() { active_source_configuration_memo = previous_; }
    SourceConfigurationScope(const SourceConfigurationScope&) = delete;
    SourceConfigurationScope& operator=(const SourceConfigurationScope&) = delete;
    const RuntimeConfig& get(const std::uint64_t ordinal) const {
        auto& memo = *active_source_configuration_memo;
#ifndef NATRAV_SOURCE_SUBSCRIPTION_UNCACHED_CONFIG
        const auto found = memo.parsed.find(ordinal);
        if (found != memo.parsed.end()) {
            if (active_source_validation_work) { ++active_source_validation_work->configuration_memo_hits; }
            return found->second;
        }
#endif
        // Event bounds, rejection state and the full normal parser are checked
        // on first use. std::map preserves references as other events are added.
        return memo.parsed.insert_or_assign(ordinal, event_config(*memo.history, ordinal)).first->second;
    }
private:
    SourceConfigurationMemo local_;
    SourceConfigurationMemo* previous_;
};
std::uint64_t source_base(const SourceSubscription& s) noexcept {
    return s.succession ? s.succession->inherited_acknowledged : 0U;
}
std::uint64_t source_frontier(const SourceSubscription& s) noexcept {
    return source_base(s) + s.acknowledged;
}
SourceSubscription copy_subscription(const SourceSubscription& s) {
    if (active_source_validation_work) {
        active_source_validation_work->copied_delivery_entries += s.deliveries.size();
    }
    return s;
}
Digest source_state_digest(const SourceSubscription& s) {
    return hash("NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_STATE_V1",
        encode_source_subscription(s));
}
Digest source_mapping_append(const Digest& previous, const std::uint64_t ordinal,
    const SourceSubscriptionDelivery& d) {
    if (active_source_validation_work) { ++active_source_validation_work->mapping_digest_entries_hashed; }
    Bytes entry; digest(entry, previous);
    datacube::append_be64(entry, ordinal);
    digest(entry, d.source_operation); digest(entry, d.operation);
    digest(entry, d.record_digest); datacube::append_be32(entry, d.payload_bytes);
    datacube::append_be64(entry, d.configuration_event);
    datacube::append_be64(entry, d.unix_ms); datacube::append_be32(entry, d.pid);
    datacube::append_be64(entry, d.acknowledged_event);
    datacube::append_be64(entry, d.acknowledged_unix_ms);
    datacube::append_be32(entry, d.acknowledged_pid);
    datacube::append_be64(entry, d.issue_automatic_generation);
    datacube::append_be64(entry, d.acknowledge_automatic_generation);
    return hash("NATRAV_OVERLAY_SOURCE_MAPPING_LINK_V1", entry);
}
Digest source_mapping_digest(const SourceSubscription& s) {
    Bytes seed;
    text(seed, s.grant.peer); text(seed, s.grant.generation);
    digest(seed, s.peer_spki); datacube::append_be32(seed, s.grant.author_uid);
    text(seed, s.grant.scope);
    auto root = s.succession ? s.succession->mapping_digest :
        hash("NATRAV_OVERLAY_SOURCE_MAPPING_ROOT_V1", seed);
    check(s.acknowledged <= s.deliveries.size(), "source mapping frontier invalid");
    for (std::size_t i = 0U; i < static_cast<std::size_t>(s.acknowledged); ++i) {
        root = source_mapping_append(root, source_base(s) + i + 1U, s.deliveries[i]);
    }
    return root;
}
SourceSubscriptionRequest succession_request(const SourceSubscription& s) {
    check(s.succession.has_value(), "source successor provenance absent");
    const auto& x = *s.succession;
    SourceSubscriptionRequest r;
    r.command = SourceSubscriptionCommand::succeed; r.grant = s.grant.id;
    r.instance = x.predecessor_instance; r.expected_revision = x.predecessor_revision;
    r.reason = s.creation_reason; r.predecessor_grant = x.predecessor_grant;
    r.predecessor_lease = x.predecessor_lease; r.successor_lease = s.grant.lease_generation;
    r.predecessor_state_digest = x.predecessor_state_digest;
    r.predecessor_mapping_digest = x.mapping_digest;
    r.expected_frontier = x.inherited_acknowledged;
    return r;
}
Digest terminal_digest(const SourceSubscriptionTermination& t) {
    Bytes b; text(b, t.kind); text(b, t.lease_generation);
    datacube::append_be64(b, t.configuration_event); datacube::append_be64(b, t.unix_ms);
    text(b, t.pending_disposition); datacube::append_u8(b, t.cancelled_operation ? 1U : 0U);
    if (t.cancelled_operation) { digest(b, *t.cancelled_operation); }
    text(b, t.actor_peer); text(b, t.actor_generation); digest(b, t.actor_spki);
    datacube::append_u8(b, t.request_id ? 1U : 0U);
    if (t.request_id) { digest(b, *t.request_id); }
    digest(b, t.request_digest); text(b, t.reason);
    return hash("NATRAV_OVERLAY_SOURCE_TERMINAL_ACCOUNT_V1", b);
}
Digest receipt_digest(const DeliveryReceipt& receipt) {
    return hash("NATRAV_OVERLAY_SOURCE_DURABLE_RECEIPT_V1", encode_application_message(receipt));
}
Digest source_commitment_chain_seed(const std::string_view domain) {
    Bytes bytes;
    datacube::append_u8(bytes, 0U);
    return hash(domain, bytes);
}
Digest source_commitment_chain_append(const std::string_view domain,
    const Digest& previous, const std::uint64_t index, const Digest& value) {
    Bytes bytes;
    digest(bytes, previous);
    datacube::append_be64(bytes, index);
    digest(bytes, value);
    return hash(domain, bytes);
}
Digest source_delivery_commitment(const SourceSubscriptionDelivery& value) {
    Bytes bytes;
    digest(bytes, value.source_operation);
    digest(bytes, value.operation);
    digest(bytes, value.record_digest);
    datacube::append_be32(bytes, value.payload_bytes);
    datacube::append_be64(bytes, value.configuration_event);
    datacube::append_be64(bytes, value.unix_ms);
    datacube::append_be32(bytes, value.pid);
    datacube::append_be64(bytes, value.acknowledged_event);
    datacube::append_be64(bytes, value.acknowledged_unix_ms);
    datacube::append_be32(bytes, value.acknowledged_pid);
    datacube::append_be64(bytes, value.issue_automatic_generation);
    datacube::append_be64(bytes, value.acknowledge_automatic_generation);
    return hash("NATRAV_OVERLAY_SOURCE_PROGRESS_DELIVERY_V1", bytes);
}
Digest source_automatic_commitment(const SourceSubscriptionAutomaticGrant& value) {
    Bytes bytes;
    datacube::append_be64(bytes, value.generation);
    datacube::append_be64(bytes, value.observed_subscription_revision);
    datacube::append_be64(bytes, value.configuration_event);
    datacube::append_be64(bytes, value.unix_ms);
    datacube::append_be32(bytes, value.actor_uid);
    datacube::append_be32(bytes, value.pid);
    datacube::append_be32(bytes, value.maximum_steps);
    datacube::append_be32(bytes, value.minimum_interval_ms);
    digest(bytes, value.disclosure_digest);
    text(bytes, value.reason);
    datacube::append_be64(bytes, value.start_issued);
    datacube::append_be64(bytes, value.start_acknowledged);
    datacube::append_be64(bytes, value.steps);
    text(bytes, value.state);
    text(bytes, value.error);
    text(bytes, value.end_reason);
    datacube::append_be64(bytes, value.last_step_event);
    datacube::append_be64(bytes, value.last_step_unix_ms);
    datacube::append_be32(bytes, value.last_executor_uid);
    datacube::append_be32(bytes, value.last_executor_pid);
    datacube::append_be64(bytes, value.ended_event);
    datacube::append_be64(bytes, value.ended_unix_ms);
    datacube::append_be32(bytes, value.ended_uid);
    datacube::append_be32(bytes, value.ended_pid);
    return hash("NATRAV_OVERLAY_SOURCE_PROGRESS_AUTOMATIC_GRANT_V1", bytes);
}
Digest source_progress_base_commitment(const SourceSubscription& value) {
    Bytes bytes;
    datacube::append_octets(bytes, grant_bytes(value.grant));
    digest(bytes, value.grant.digest);
    digest(bytes, value.instance);
    digest(bytes, value.peer_spki);
    datacube::append_be64(bytes, value.created_event);
    datacube::append_be64(bytes, value.created_unix_ms);
    datacube::append_be32(bytes, value.created_pid);
    text(bytes, value.creation_reason);
    datacube::append_u8(bytes, value.remote_admission ? 1U : 0U);
    if (value.remote_admission) {
        const auto& remote = *value.remote_admission;
        digest(bytes, remote.request_id);
        text(bytes, remote.peer);
        text(bytes, remote.generation);
        digest(bytes, remote.peer_spki);
        datacube::append_be64(bytes, remote.configuration_event);
        datacube::append_be64(bytes, remote.unix_ms);
        text(bytes, remote.reason);
        digest(bytes, remote.request_digest);
    }
    datacube::append_be64(bytes, value.lease_started_unix_ms);
    datacube::append_be64(bytes, value.lease_expires_unix_ms);
    datacube::append_u8(bytes, value.termination ? 1U : 0U);
    if (value.termination) {
        const auto& terminal = *value.termination;
        text(bytes, terminal.kind);
        text(bytes, terminal.lease_generation);
        datacube::append_be64(bytes, terminal.configuration_event);
        datacube::append_be64(bytes, terminal.unix_ms);
        text(bytes, terminal.pending_disposition);
        datacube::append_u8(bytes, terminal.cancelled_operation ? 1U : 0U);
        if (terminal.cancelled_operation) { digest(bytes, *terminal.cancelled_operation); }
        text(bytes, terminal.actor_peer);
        text(bytes, terminal.actor_generation);
        digest(bytes, terminal.actor_spki);
        datacube::append_u8(bytes, terminal.request_id ? 1U : 0U);
        if (terminal.request_id) { digest(bytes, *terminal.request_id); }
        digest(bytes, terminal.request_digest);
        text(bytes, terminal.reason);
    }
    datacube::append_u8(bytes, value.succession ? 1U : 0U);
    if (value.succession) {
        const auto& succession = *value.succession;
        text(bytes, succession.predecessor_grant);
        text(bytes, succession.predecessor_lease);
        digest(bytes, succession.predecessor_instance);
        datacube::append_be64(bytes, succession.predecessor_revision);
        digest(bytes, succession.predecessor_state_digest);
        datacube::append_be64(bytes, succession.inherited_acknowledged);
        digest(bytes, succession.mapping_digest);
        digest(bytes, succession.creation_request_digest);
    }
    datacube::append_u8(bytes, value.reconciliation ? 1U : 0U);
    if (value.reconciliation) {
        const auto& reconciliation = *value.reconciliation;
        datacube::append_be64(bytes, reconciliation.preceding_revision);
        datacube::append_be32(bytes, reconciliation.preceding_pid);
        digest(bytes, reconciliation.preceding_state_digest);
        digest(bytes, reconciliation.terminal_digest);
        digest(bytes, reconciliation.source_operation);
        digest(bytes, reconciliation.delivery_operation);
        digest(bytes, reconciliation.receipt_digest);
    }
    datacube::append_u8(bytes, value.retired ? 1U : 0U);
    datacube::append_u8(bytes, value.retained_unacknowledged ? 1U : 0U);
    return hash("NATRAV_OVERLAY_SOURCE_PROGRESS_BASE_V1", bytes);
}
Digest source_progress_root(const SourceSubscription& value,
    const SourceSubscriptionCommitment& commitment) {
    check(commitment.delivery_count == static_cast<std::uint64_t>(value.deliveries.size()) &&
        commitment.automatic_count == static_cast<std::uint64_t>(value.automatic_grants.size()) &&
        commitment.has_delivery_tail == !value.deliveries.empty() &&
        commitment.has_automatic_tail == !value.automatic_grants.empty(),
        "source progress commitment shape mismatch");
    Bytes bytes;
    digest(bytes, commitment.base);
    datacube::append_be64(bytes, value.revision);
    datacube::append_be64(bytes, commitment.delivery_count);
    digest(bytes, commitment.delivery_prefix);
    datacube::append_u8(bytes, commitment.has_delivery_tail ? 1U : 0U);
    if (commitment.has_delivery_tail) { digest(bytes, commitment.delivery_tail); }
    datacube::append_be64(bytes, value.acknowledged);
    datacube::append_be64(bytes, value.used_payload_bytes);
    text(bytes, value.transition);
    text(bytes, value.reason);
    datacube::append_be64(bytes, value.configuration_event);
    datacube::append_be64(bytes, value.unix_ms);
    datacube::append_be32(bytes, value.pid);
    digest(bytes, value.request_digest);
    datacube::append_be64(bytes, value.automatic_schedule_revision);
    datacube::append_be64(bytes, commitment.automatic_count);
    digest(bytes, commitment.automatic_prefix);
    datacube::append_u8(bytes, commitment.has_automatic_tail ? 1U : 0U);
    if (commitment.has_automatic_tail) { digest(bytes, commitment.automatic_tail); }
    return hash("NATRAV_OVERLAY_SOURCE_PROGRESS_STATE_V1", bytes);
}
SourceSubscriptionCommitment source_progress_commitment(const SourceSubscription& value) {
    if (active_source_validation_work) {
        ++active_source_validation_work->commitment_full_rebuilds;
        active_source_validation_work->commitment_delivery_entries += value.deliveries.size();
        active_source_validation_work->commitment_automatic_entries += value.automatic_grants.size();
    }
    SourceSubscriptionCommitment commitment;
    commitment.base = source_progress_base_commitment(value);
    commitment.delivery_prefix = source_commitment_chain_seed(
        "NATRAV_OVERLAY_SOURCE_PROGRESS_DELIVERY_CHAIN_SEED_V1");
    commitment.delivery_count = static_cast<std::uint64_t>(value.deliveries.size());
    if (!value.deliveries.empty()) {
        for (std::size_t index = 0U; index + 1U < value.deliveries.size(); ++index) {
            commitment.delivery_prefix = source_commitment_chain_append(
                "NATRAV_OVERLAY_SOURCE_PROGRESS_DELIVERY_CHAIN_LINK_V1",
                commitment.delivery_prefix, static_cast<std::uint64_t>(index),
                source_delivery_commitment(value.deliveries[index]));
        }
        commitment.has_delivery_tail = true;
        commitment.delivery_tail = source_delivery_commitment(value.deliveries.back());
    }
    commitment.automatic_prefix = source_commitment_chain_seed(
        "NATRAV_OVERLAY_SOURCE_PROGRESS_AUTOMATIC_CHAIN_SEED_V1");
    commitment.automatic_count = static_cast<std::uint64_t>(value.automatic_grants.size());
    if (!value.automatic_grants.empty()) {
        for (std::size_t index = 0U; index + 1U < value.automatic_grants.size(); ++index) {
            commitment.automatic_prefix = source_commitment_chain_append(
                "NATRAV_OVERLAY_SOURCE_PROGRESS_AUTOMATIC_CHAIN_LINK_V1",
                commitment.automatic_prefix, static_cast<std::uint64_t>(index),
                source_automatic_commitment(value.automatic_grants[index]));
        }
        commitment.has_automatic_tail = true;
        commitment.automatic_tail = source_automatic_commitment(value.automatic_grants.back());
    }
    commitment.root = source_progress_root(value, commitment);
    return commitment;
}
// Persisted predecessor_state_digest / preceding_state_digest remain canonical
// NSS commitments. The actual request digest binds either the legacy selector
// or the explicitly versioned structural selector; it never substitutes one
// type for the other. Reconstruction needs no cache or persisted selector flag.
bool source_selection_request_matches(SourceSubscriptionRequest request,
    const SourceSubscription& selected, const Digest& expected) {
    if (request_digest(request) == expected) { return true; }
    request.structural_selector = true;
    const auto structural = source_progress_commitment(selected).root;
    if (request.command == SourceSubscriptionCommand::succeed) {
        request.predecessor_state_digest = structural;
    } else {
        check(request.command == SourceSubscriptionCommand::reconcile,
            "structural source selection command invalid");
        request.reconciliation_state_digest = structural;
    }
    return request_digest(request) == expected;
}
SourceSubscriptionCommitment source_progress_commitment_after(
    const SourceSubscription& value, const SourceSubscriptionCommitment& previous,
    const bool issue, const bool automatic) {
    SourceSubscriptionCommitment commitment = previous;
    if (issue) {
        if (commitment.has_delivery_tail) {
            check(commitment.delivery_count != 0U,
                "source progress delivery tail lacks count");
            commitment.delivery_prefix = source_commitment_chain_append(
                "NATRAV_OVERLAY_SOURCE_PROGRESS_DELIVERY_CHAIN_LINK_V1",
                commitment.delivery_prefix, commitment.delivery_count - 1U,
                commitment.delivery_tail);
        }
        ++commitment.delivery_count;
        commitment.has_delivery_tail = true;
        commitment.delivery_tail = source_delivery_commitment(value.deliveries.back());
    } else {
        check(commitment.has_delivery_tail && commitment.delivery_count != 0U,
            "source acknowledgment commitment lacks delivery tail");
        commitment.delivery_tail = source_delivery_commitment(value.deliveries.back());
    }
    if (automatic) {
        check(commitment.has_automatic_tail && commitment.automatic_count != 0U,
            "automatic source progress commitment lacks grant tail");
        commitment.automatic_tail = source_automatic_commitment(value.automatic_grants.back());
    }
    commitment.root = source_progress_root(value, commitment);
    if (active_source_validation_work) { ++active_source_validation_work->commitment_updates; }
    return commitment;
}
SourceSubscriptionRequest reconciliation_request(const SourceSubscription& s) {
    check(s.reconciliation.has_value(), "receipt reconciliation account absent");
    const auto& x = *s.reconciliation;
    SourceSubscriptionRequest r;
    r.command = SourceSubscriptionCommand::reconcile; r.grant = s.grant.id;
    r.instance = s.instance; r.expected_revision = x.preceding_revision; r.reason = s.reason;
    r.reconciliation_state_digest = x.preceding_state_digest; r.terminal_digest = x.terminal_digest;
    r.source_operation = x.source_operation; r.delivery_operation = x.delivery_operation;
    r.receipt_digest = x.receipt_digest;
    return r;
}
// Recover the complete exact terminal account for checkpoint validation. The
// old account is checked recursively with the unchanged legacy semantics.
SourceSubscription before_reconciliation(const SourceSubscription& s) {
    check(s.reconciliation && s.termination && s.retired && s.acknowledged > 0U &&
        s.acknowledged == s.deliveries.size() && !s.retained_unacknowledged &&
        s.transition == "RECONCILE_RECEIPT", "receipt reconciliation structural invariant");
    auto old = copy_subscription(s);
    old.revision = s.reconciliation->preceding_revision;
    old.pid = s.reconciliation->preceding_pid;
    old.configuration_event = s.termination->configuration_event;
    old.unix_ms = s.termination->unix_ms;
    old.transition = s.termination->kind == "WITHDRAWN" ? "REMOTE_WITHDRAW" : "LEASE_EXPIRE";
    old.reason = s.termination->reason; old.request_digest = s.termination->request_digest;
    --old.acknowledged; old.retained_unacknowledged = true;
    auto& d = old.deliveries.back();
    d.acknowledged_event = 0U; d.acknowledged_unix_ms = 0U;
    d.acknowledged_pid = 0U; d.acknowledge_automatic_generation = 0U;
    old.reconciliation.reset();
    return old;
}
void adopt_receipt(SourceSubscription& s) {
    ++s.acknowledged; s.retained_unacknowledged = false;
    auto& d = s.deliveries.back();
    d.acknowledged_event = s.configuration_event; d.acknowledged_unix_ms = s.unix_ms;
    d.acknowledged_pid = s.pid; d.acknowledge_automatic_generation = 0U;
}
bool rule_current(const SourceSubscription& s, const RuntimeConfig& c) {
    const auto* rule = source_disclosure_grant(c.source_disclosure, s.grant.id);
    return c.format_version >= 15U && rule && *rule == s.grant &&
        local_control_allows(c.local_control, s.grant.uid, LocalControlClass::source_disclose);
}
bool source_subscription_is_leased(const SourceSubscription& value) noexcept {
    return !value.grant.lease_generation.empty();
}
bool source_subscription_lease_expired(const SourceSubscription& value,
    const std::uint64_t now) noexcept {
    return source_subscription_is_leased(value) && value.lease_expires_unix_ms != 0U &&
        now >= value.lease_expires_unix_ms;
}
std::string termination_json(const std::optional<SourceSubscriptionTermination>& terminal) {
    if (!terminal) { return "null"; }
    return "{\"kind\":" + json_string(terminal->kind) +
        ",\"lease_generation\":" + json_string(terminal->lease_generation) +
        ",\"configuration_event\":" + std::to_string(terminal->configuration_event) +
        ",\"unix_ms\":" + std::to_string(terminal->unix_ms) +
        ",\"pending_disposition\":" + json_string(terminal->pending_disposition) +
        ",\"cancelled_operation\":" + (terminal->cancelled_operation ?
            json_string(datacube::hex_lower(*terminal->cancelled_operation)) : std::string("null")) +
        ",\"actor_peer\":" + json_string(terminal->actor_peer) +
        ",\"actor_generation\":" + json_string(terminal->actor_generation) +
        ",\"actor_spki_sha256\":" + (digest_is_zero(terminal->actor_spki) ?
            std::string("null") : json_string(datacube::hex_lower(terminal->actor_spki))) +
        ",\"request_id\":" + (terminal->request_id ?
            json_string(datacube::hex_lower(*terminal->request_id)) : std::string("null")) +
        ",\"request_digest\":" + (digest_is_zero(terminal->request_digest) ?
            std::string("null") : json_string(datacube::hex_lower(terminal->request_digest))) +
        ",\"reason\":" + json_string(terminal->reason) + "}";
}
OutboundPolicy policy_for_source(const SourceSubscription& s, const RuntimeConfig& c, std::uint64_t now) {
    const auto* peer = find_peer(c, s.grant.peer);
    const auto* key = find_peer_generation(c, s.grant.peer, s.grant.generation);
    if (!peer) { app_fail("SOURCE_SUBSCRIPTION_ROUTE_UNAVAILABLE", "no current route for subscriber"); }
    if (!key || key->state != KeyGenerationState::active || key->spki_sha256 != s.peer_spki ||
        peer->active_generation != s.grant.generation) {
        app_fail("SOURCE_SUBSCRIPTION_KEY_INACTIVE", "grant requires its exact active subscriber generation");
    }
    if (now == 0U || peer->delivery.expiry_ms > std::numeric_limits<std::uint64_t>::max() - now) {
        app_fail("SOURCE_SUBSCRIPTION_INVALID", "delivery clock overflow");
    }
    return OutboundPolicy{.created_unix_ms = now, .expires_unix_ms = now + peer->delivery.expiry_ms,
        .maximum_attempts = peer->delivery.maximum_attempts,
        .initial_backoff_ms = peer->delivery.initial_backoff_ms,
        .maximum_backoff_ms = peer->delivery.maximum_backoff_ms,
        .peer_spki_sha256 = s.peer_spki, .peer_generation = s.grant.generation};
}
// This is the existing kind-24 encoding, not a new independent outbox.
Bytes composite(const EvidenceRecord& record, const OutboundPolicy& p) {
    const auto encoded = encode_application_message(record); Bytes out;
    digest(out, record.operation_id); datacube::append_be32(out, static_cast<std::uint32_t>(encoded.size()));
    datacube::append_octets(out, encoded); digest(out, record.operation_id);
    datacube::append_be64(out, p.created_unix_ms); datacube::append_be64(out, p.expires_unix_ms);
    datacube::append_be32(out, p.maximum_attempts); datacube::append_be32(out, p.initial_backoff_ms);
    datacube::append_be32(out, p.maximum_backoff_ms);
    check(p.peer_generation.has_value() && p.peer_spki_sha256.has_value(), "source delivery key binding absent");
    digest(out, *p.peer_spki_sha256); text(out, *p.peer_generation); return out;
}
struct DecodedSourceComposite final {
    EvidenceRecord record;
    OutboundPolicy policy;

    DecodedSourceComposite(EvidenceRecord&& decoded_record,
        OutboundPolicy&& decoded_policy) noexcept
        : record(std::move(decoded_record)), policy(std::move(decoded_policy)) {}
    DecodedSourceComposite(const DecodedSourceComposite&) = delete;
    DecodedSourceComposite& operator=(const DecodedSourceComposite&) = delete;
    DecodedSourceComposite(DecodedSourceComposite&&) noexcept = default;
    DecodedSourceComposite& operator=(DecodedSourceComposite&&) noexcept = default;
};
DecodedSourceComposite read_composite(View bytes) {
    datacube::Reader r(bytes, "source outbox transaction"); const auto id = digest(r);
    const auto size = r.read_be32("source outbox size"); check(size <= kMaximumApplicationPayloadBytes, "source outbox size bound");
    auto message = decode_application_message(r.read_exact(size, "source outgoing record"));
    auto* record = std::get_if<EvidenceRecord>(&message);
    check(record && record->operation_id == id && digest(r) == id, "source outbox operation binding");
    OutboundPolicy p;
    p.created_unix_ms = r.read_be64("created"); p.expires_unix_ms = r.read_be64("expires");
    p.maximum_attempts = r.read_be32("attempts"); p.initial_backoff_ms = r.read_be32("backoff");
    p.maximum_backoff_ms = r.read_be32("maximum backoff"); p.peer_spki_sha256 = digest(r); p.peer_generation = text(r, 64U);
    r.require_eof("source outbox");
#ifdef NATRAV_SOURCE_COMPOSITE_COPY_RETURN
    auto copied_record = *record;
    auto copied_policy = p;
    if (active_source_validation_work) {
        active_source_validation_work->source_composite_return_payload_bytes_copied +=
            copied_record.payload.size();
    }
    return DecodedSourceComposite(std::move(copied_record), std::move(copied_policy));
#else
    if (active_source_validation_work) {
        ++active_source_validation_work->source_composite_return_ownership_transfers;
        active_source_validation_work->source_composite_return_payload_bytes_transferred +=
            record->payload.size();
    }
    return DecodedSourceComposite(std::move(*record), std::move(p));
#endif
}
Bytes source_cancellation_payload(const Digest& operation,
    const std::uint64_t at, const std::string_view actor,
    const std::string_view reason, const OutboundPolicy& policy) {
    check(policy.peer_generation.has_value() && policy.peer_spki_sha256.has_value(),
        "source cancellation key binding absent");
    Bytes out;
    digest(out, operation);
    datacube::append_be64(out, at);
    text(out, actor);
    text(out, reason);
    text(out, *policy.peer_generation);
    digest(out, *policy.peer_spki_sha256);
    return out;
}
struct DecodedSourceCancellation final {
    Digest operation{};
    std::uint64_t unix_ms{0U};
    std::string actor;
    std::string reason;
    std::string generation;
    Digest spki{};
};
DecodedSourceCancellation read_source_cancellation(const View bytes) {
    datacube::Reader r(bytes, "source cancellation transaction");
    DecodedSourceCancellation value{
        .operation = digest(r),
        .unix_ms = r.read_be64("source cancellation time"),
        .actor = text(r, 64U),
        .reason = text(r, 256U),
        .generation = text(r, 64U),
        .spki = digest(r),
    };
    r.require_eof("source cancellation transaction");
    return value;
}
enum class SourceProgressKind : std::uint8_t {
    issue = 1U,
    acknowledge = 2U,
    automatic_issue = 3U,
    automatic_acknowledge = 4U,
};
bool source_progress_issue(const SourceProgressKind kind) noexcept {
    return kind == SourceProgressKind::issue ||
        kind == SourceProgressKind::automatic_issue;
}
bool source_progress_automatic(const SourceProgressKind kind) noexcept {
    return kind == SourceProgressKind::automatic_issue ||
        kind == SourceProgressKind::automatic_acknowledge;
}
std::string_view source_progress_transition(const SourceProgressKind kind) {
    switch (kind) {
    case SourceProgressKind::issue: return "ISSUE";
    case SourceProgressKind::acknowledge: return "ACK";
    case SourceProgressKind::automatic_issue: return "AUTO_ISSUE";
    case SourceProgressKind::automatic_acknowledge: return "AUTO_ACK";
    }
    app_fail("JOURNAL_CORRUPT", "source progress kind rejected");
}
struct SourceProgressTransaction final {
    SourceProgressKind kind{SourceProgressKind::issue};
    std::string grant;
    Digest instance{};
    std::uint64_t preceding_revision{0U};
    Digest preceding_commitment{};
    std::uint64_t configuration_event{0U};
    std::uint64_t unix_ms{0U};
    std::uint32_t pid{0U};
    Digest request_digest{};
    std::uint64_t automatic_generation{0U};
    std::uint64_t automatic_steps_after{0U};
    std::uint64_t automatic_schedule_revision_after{0U};
    std::uint32_t automatic_executor_uid{0U};
    std::uint8_t automatic_state_after{0U}; // 1 ENABLED, 2 EXHAUSTED
    SourceSubscriptionDelivery delivery{};
    Digest durable_receipt_digest{};
    std::optional<EvidenceRecord> record;
    std::optional<OutboundPolicy> policy;
    Bytes outgoing;
};
void validate_source_progress_shape(const SourceProgressTransaction& value) {
    const auto raw = static_cast<std::uint8_t>(value.kind);
    check(raw >= static_cast<std::uint8_t>(SourceProgressKind::issue) &&
        raw <= static_cast<std::uint8_t>(SourceProgressKind::automatic_acknowledge) &&
        valid_generation_id(value.grant) && !digest_is_zero(value.instance) &&
        value.preceding_revision != 0U && !digest_is_zero(value.preceding_commitment) &&
        value.configuration_event != 0U && value.unix_ms != 0U && value.pid != 0U,
        "source progress transaction header invalid");
    const bool issue = source_progress_issue(value.kind);
    const bool automatic = source_progress_automatic(value.kind);
    if (automatic) {
        check(digest_is_zero(value.request_digest) && value.automatic_generation != 0U &&
            value.automatic_steps_after != 0U &&
            value.automatic_schedule_revision_after != 0U &&
            (value.automatic_state_after == 1U || value.automatic_state_after == 2U),
            "automatic source progress account invalid");
    } else {
        check(!digest_is_zero(value.request_digest) && value.automatic_generation == 0U &&
            value.automatic_steps_after == 0U &&
            value.automatic_schedule_revision_after == 0U &&
            value.automatic_executor_uid == 0U && value.automatic_state_after == 0U,
            "manual source progress carries automatic account");
    }
    if (issue) {
        check(value.record.has_value() && value.policy.has_value() &&
            !digest_is_zero(value.delivery.source_operation) &&
            !digest_is_zero(value.delivery.operation) &&
            !digest_is_zero(value.delivery.record_digest) &&
            value.delivery.acknowledged_event == 0U &&
            value.delivery.acknowledged_unix_ms == 0U &&
            value.delivery.acknowledged_pid == 0U &&
            value.delivery.acknowledge_automatic_generation == 0U &&
            digest_is_zero(value.durable_receipt_digest),
            "source issue progress account invalid");
    } else {
        check(!value.record && !value.policy && value.outgoing.empty() &&
            !digest_is_zero(value.delivery.operation) &&
            !digest_is_zero(value.delivery.record_digest) &&
            !digest_is_zero(value.durable_receipt_digest) &&
            digest_is_zero(value.delivery.source_operation) &&
            value.delivery.payload_bytes == 0U &&
            value.delivery.issue_automatic_generation == 0U,
            "source acknowledgment progress account invalid");
    }
}
[[maybe_unused]] Bytes progress_transaction(SourceProgressTransaction value) {
    if (source_progress_issue(value.kind)) {
        check(value.record.has_value() && value.policy.has_value(),
            "source progress outbox account absent");
        value.outgoing = composite(*value.record, *value.policy);
    }
    validate_source_progress_shape(value);
    Bytes out;
    datacube::append_text(out, "NST3");
    datacube::append_u8(out, static_cast<std::uint8_t>(value.kind));
    text(out, value.grant);
    digest(out, value.instance);
    datacube::append_be64(out, value.preceding_revision);
    digest(out, value.preceding_commitment);
    datacube::append_be64(out, value.configuration_event);
    datacube::append_be64(out, value.unix_ms);
    datacube::append_be32(out, value.pid);
    digest(out, value.request_digest);
    if (source_progress_automatic(value.kind)) {
        datacube::append_be64(out, value.automatic_generation);
        datacube::append_be64(out, value.automatic_steps_after);
        datacube::append_be64(out, value.automatic_schedule_revision_after);
        datacube::append_be32(out, value.automatic_executor_uid);
        datacube::append_u8(out, value.automatic_state_after);
    }
    if (source_progress_issue(value.kind)) {
        digest(out, value.delivery.source_operation);
        digest(out, value.delivery.operation);
        digest(out, value.delivery.record_digest);
        datacube::append_be32(out, value.delivery.payload_bytes);
        datacube::append_be32(out, static_cast<std::uint32_t>(value.outgoing.size()));
        datacube::append_octets(out, value.outgoing);
    } else {
        digest(out, value.delivery.operation);
        digest(out, value.delivery.record_digest);
        digest(out, value.durable_receipt_digest);
    }
    check(out.size() <= 67'000U, "source progress transaction size bound");
    if (active_source_validation_work) {
        ++active_source_validation_work->progress_transaction_encodes;
        active_source_validation_work->progress_transaction_bytes_encoded += out.size();
    }
    return out;
}
enum class SourceProgressOutgoingStorage : std::uint8_t {
    owned,
    command_slice,
};
struct DecodedSourceProgressTransaction final {
    SourceProgressTransaction transaction;
    std::size_t outgoing_offset{0U};
    std::size_t outgoing_size{0U};
    bool outgoing_owned{false};
};
DecodedSourceProgressTransaction decode_source_progress_transaction_impl(
    const View bytes, const SourceProgressOutgoingStorage storage) {
    if (active_source_validation_work) {
        ++active_source_validation_work->progress_transaction_decodes;
        active_source_validation_work->progress_transaction_bytes_decoded += bytes.size();
    }
    check(bytes.size() <= 67'000U, "source progress transaction size bound");
    datacube::Reader r(bytes, "source progress transaction");
    const auto version = datacube::octets_text(r.read_exact(4U,
        "source progress magic"), "source progress magic", true);
    check(version == "NST3", "source progress transaction version rejected");
    const auto raw = r.read_u8("source progress kind");
    check(raw >= static_cast<std::uint8_t>(SourceProgressKind::issue) &&
        raw <= static_cast<std::uint8_t>(SourceProgressKind::automatic_acknowledge),
        "source progress kind rejected");
    DecodedSourceProgressTransaction decoded;
    auto& value = decoded.transaction;
    value.kind = static_cast<SourceProgressKind>(raw);
    value.grant = text(r, 64U);
    value.instance = digest(r);
    value.preceding_revision = r.read_be64("source preceding revision");
    value.preceding_commitment = digest(r);
    value.configuration_event = r.read_be64("source progress configuration event");
    value.unix_ms = r.read_be64("source progress time");
    value.pid = r.read_be32("source progress PID");
    value.request_digest = digest(r);
    if (source_progress_automatic(value.kind)) {
        value.automatic_generation = r.read_be64("source automatic generation");
        value.automatic_steps_after = r.read_be64("source automatic steps after");
        value.automatic_schedule_revision_after = r.read_be64(
            "source automatic schedule revision after");
        value.automatic_executor_uid = r.read_be32("source automatic executor UID");
        value.automatic_state_after = r.read_u8("source automatic state after");
    }
    if (source_progress_issue(value.kind)) {
        value.delivery.source_operation = digest(r);
        value.delivery.operation = digest(r);
        value.delivery.record_digest = digest(r);
        value.delivery.payload_bytes = r.read_be32("source progress payload bytes");
        const auto size = r.read_be32("source progress outbox length");
        check(size <= 66'000U, "source progress composite bound");
        decoded.outgoing_offset = r.offset();
        const auto outgoing = r.read_exact(size, "source progress outbox");
        decoded.outgoing_size = outgoing.size();
        bool own_outgoing = storage == SourceProgressOutgoingStorage::owned;
#ifdef NATRAV_SOURCE_PROGRESS_OWNED_OUTGOING
        if (storage == SourceProgressOutgoingStorage::command_slice) {
            own_outgoing = true;
        }
#endif
        View strict_outgoing = outgoing;
        if (own_outgoing) {
            value.outgoing.assign(outgoing.begin(), outgoing.end());
            strict_outgoing = value.outgoing;
            decoded.outgoing_owned = true;
            if (active_source_validation_work) {
                ++active_source_validation_work->progress_outgoing_owned_copies;
                active_source_validation_work->progress_outgoing_bytes_copied += outgoing.size();
            }
        } else if (active_source_validation_work) {
            ++active_source_validation_work->progress_outgoing_slices;
            active_source_validation_work->progress_outgoing_slice_bytes += outgoing.size();
        }
        auto composite_value = read_composite(strict_outgoing);
        value.record = std::move(composite_value.record);
        value.policy = std::move(composite_value.policy);
        if (active_source_validation_work) {
            active_source_validation_work->progress_record_payload_bytes_decoded +=
                value.record->payload.size();
        }
    } else {
        value.delivery.operation = digest(r);
        value.delivery.record_digest = digest(r);
        value.durable_receipt_digest = digest(r);
    }
    r.require_eof("source progress transaction");
    validate_source_progress_shape(value);
    if (source_progress_issue(value.kind)) {
        check(decoded.outgoing_size != 0U &&
            decoded.outgoing_offset <= bytes.size() &&
            decoded.outgoing_size <= bytes.size() - decoded.outgoing_offset &&
            decoded.outgoing_offset + decoded.outgoing_size == bytes.size() &&
            (decoded.outgoing_owned ?
                value.outgoing.size() == decoded.outgoing_size : value.outgoing.empty()),
            "source progress outgoing storage invalid");
    } else {
        check(decoded.outgoing_offset == 0U && decoded.outgoing_size == 0U &&
            !decoded.outgoing_owned && value.outgoing.empty(),
            "source acknowledgment carries outgoing storage");
    }
    return decoded;
}
[[nodiscard]] View source_progress_outgoing_view(
    const View bytes, const DecodedSourceProgressTransaction& decoded) {
    const auto& value = decoded.transaction;
    if (!source_progress_issue(value.kind)) {
        check(decoded.outgoing_offset == 0U && decoded.outgoing_size == 0U &&
            !decoded.outgoing_owned && value.outgoing.empty(),
            "source acknowledgment outgoing slice invalid");
        return {};
    }
    check(decoded.outgoing_size != 0U &&
        decoded.outgoing_offset <= bytes.size() &&
        decoded.outgoing_size <= bytes.size() - decoded.outgoing_offset &&
        decoded.outgoing_offset + decoded.outgoing_size == bytes.size(),
        "source progress outgoing slice bounds invalid");
    const auto exact = bytes.subspan(decoded.outgoing_offset, decoded.outgoing_size);
    if (!decoded.outgoing_owned) {
        check(value.outgoing.empty(),
            "source progress command slice unexpectedly owns outgoing bytes");
        return exact;
    }
    check(value.outgoing.size() == exact.size() &&
        std::equal(value.outgoing.begin(), value.outgoing.end(), exact.begin()),
        "source progress owned outgoing bytes disagree with strict slice");
    return value.outgoing;
}
SourceProgressTransaction decode_source_progress_transaction(const View bytes) {
    auto decoded = decode_source_progress_transaction_impl(
        bytes, SourceProgressOutgoingStorage::owned);
    return std::move(decoded.transaction);
}
DecodedSourceProgressTransaction decode_command_source_progress_transaction(
    const View bytes) {
    return decode_source_progress_transaction_impl(
        bytes, SourceProgressOutgoingStorage::command_slice);
}
void apply_source_progress_state(SourceSubscription& value,
    const SourceProgressTransaction& progress) {
    const bool issue = source_progress_issue(progress.kind);
    const bool automatic = source_progress_automatic(progress.kind);
    ++value.revision;
    value.transition = std::string(source_progress_transition(progress.kind));
    value.reason.clear();
    value.configuration_event = progress.configuration_event;
    value.unix_ms = progress.unix_ms;
    value.pid = progress.pid;
    value.request_digest = progress.request_digest;
    if (issue) {
        auto delivery = progress.delivery;
        delivery.configuration_event = progress.configuration_event;
        delivery.unix_ms = progress.unix_ms;
        delivery.pid = progress.pid;
        delivery.issue_automatic_generation = automatic ?
            progress.automatic_generation : 0U;
        value.deliveries.push_back(std::move(delivery));
        value.used_payload_bytes += progress.delivery.payload_bytes;
    } else {
        ++value.acknowledged;
        auto& delivery = value.deliveries.back();
        delivery.acknowledged_event = progress.configuration_event;
        delivery.acknowledged_unix_ms = progress.unix_ms;
        delivery.acknowledged_pid = progress.pid;
        delivery.acknowledge_automatic_generation = automatic ?
            progress.automatic_generation : 0U;
    }
    if (automatic) {
        value.automatic_schedule_revision =
            progress.automatic_schedule_revision_after;
        auto& grant = value.automatic_grants.back();
        grant.steps = progress.automatic_steps_after;
        grant.last_step_event = progress.configuration_event;
        grant.last_step_unix_ms = progress.unix_ms;
        grant.last_executor_uid = progress.automatic_executor_uid;
        grant.last_executor_pid = progress.pid;
        if (progress.automatic_state_after == 2U) {
            finish_automatic_grant(grant, value, "EXHAUSTED",
                "SOURCE_SUBSCRIPTION_AUTOMATION_BUDGET_EXHAUSTED",
                "finite automatic source-step allowance consumed",
                progress.automatic_executor_uid, progress.pid);
        }
    }
}
Bytes transaction(const SourceSubscription& s, const std::optional<EvidenceRecord>& record,
    const std::optional<OutboundPolicy>& policy,
    const std::optional<Bytes>& cancellation = std::nullopt) {
    Bytes out;
    datacube::append_text(out, cancellation ? "NST2" : "NST1");
    const auto state = encode_source_subscription(s);
    datacube::append_be32(out, static_cast<std::uint32_t>(state.size()));
    datacube::append_octets(out, state);
    datacube::append_u8(out, record ? 1U : 0U);
    if (record) {
        check(policy.has_value(), "source transaction policy absent");
        const auto b = composite(*record, *policy);
        datacube::append_be32(out, static_cast<std::uint32_t>(b.size()));
        datacube::append_octets(out, b);
    }
    if (cancellation) {
        datacube::append_u8(out, 1U);
        datacube::append_be32(out, static_cast<std::uint32_t>(cancellation->size()));
        datacube::append_octets(out, *cancellation);
    } else if (out.size() >= 4U && std::equal(out.begin(), out.begin() + 4, std::string_view("NST2").begin())) {
        datacube::append_u8(out, 0U);
    }
    return out;
}
std::string delivery_json(const SourceSubscriptionDelivery& d) {
    return "{\"source_operation\":" + json_string(operation_id_text(d.source_operation)) +
        ",\"operation_id\":" + json_string(operation_id_text(d.operation)) +
        ",\"record_digest\":" + json_string(datacube::hex_lower(d.record_digest)) +
        ",\"source_payload_bytes\":" + std::to_string(d.payload_bytes) +
        ",\"configuration_event\":" + std::to_string(d.configuration_event) +
        ",\"queued_unix_ms\":" + std::to_string(d.unix_ms) + ",\"pid\":" + std::to_string(d.pid) +
        ",\"acknowledged_event\":" + std::to_string(d.acknowledged_event) +
        ",\"acknowledged_unix_ms\":" + std::to_string(d.acknowledged_unix_ms) +
        ",\"acknowledged_pid\":" + std::to_string(d.acknowledged_pid) +
        ",\"issue_automatic_generation\":" + std::to_string(d.issue_automatic_generation) +
        ",\"acknowledge_automatic_generation\":" + std::to_string(d.acknowledge_automatic_generation) + "}";
}
} // namespace

// Produced only by the automatic worker's permanent-block classifier and
// consumed, at most once, by preparation in the same locked iteration. It is
// an exact selected envelope plus origin bindings, never a generic validated
// flag and never retained by NodeState, a caller, status, replay or persistence.
struct NodeState::AutomaticSourceEligibility final {
    bool available{false};
    const NodeState* owner{nullptr};
    const SourceSubscription* predecessor{nullptr};
    std::string grant;
    Digest instance;
    std::uint64_t revision{0U};
    Digest commitment;
    std::uint64_t configuration_event{0U};
    Digest configuration_digest;
    std::size_t position{0U};
    std::size_t inbound_position{0U};
    Digest source_record_digest;
    LocalAuthorship authorship;
    Digest source_operation;
    std::uint32_t source_payload_bytes{0U};
    Digest envelope_digest;
    EvidenceRecord record;
};

// Constructed only by prepare_source_progress_locked, consumed through const
// pointers while its originating command holds mutex_. It carries one parsed
// accepted configuration and at most one bounded envelope, not validated flags.
// Nothing owns or retains this object beyond that command's stack frame.
struct NodeState::SourceProgressPreparation final {
    struct Issue final {
        std::size_t position;
        std::size_t inbound_position;
        Digest source_record_digest;
        LocalAuthorship authorship;
        EvidenceRecord record;
        OutboundPolicy policy;
    };
    const NodeState* owner;
    const SourceSubscription* predecessor;
    std::string grant;
    Digest instance;
    std::uint64_t revision;
    Digest commitment;
    std::uint64_t configuration_event;
    Digest configuration_digest;
    std::uint64_t unix_ms;
    RuntimeConfig configuration;
    std::optional<Issue> issue;
};


// Immutable, noncopyable, command-local ownership of the exact NST3 bytes and
// their normal decoder result. No borrowed mutable storage or decoded-value
// constructor exists. This stores syntax, never a successful semantic verdict.
struct NodeState::ParsedSourceProgress final {
    const Bytes bytes;
    const Digest bytes_digest;
    // Syntax is immutable until the one permitted post-publication transfer.
    // Only the decoded evidence-record owner is mutable; exact source bytes,
    // policy, offsets and every semantic account remain unchanged.
    mutable DecodedSourceProgressTransaction decoded;
    const SourceProgressTransaction& transaction;
    // Strict decoder-produced slices into this object's immutable NST3 bytes.
    // The forced-owned diagnostic control instead points outgoing_bytes at the
    // decoder's private owned copy after verifying it against the same offsets.
    const View outgoing_bytes;
    const View outbound_record_bytes;
    const NodeState* const owner;
    const SourceSubscription* const predecessor;
    const Digest configuration_digest;
    const std::uint64_t preceding_journal_bytes;
    const QueueLimits queue_limits;
    mutable std::optional<std::uint64_t> published_journal_bytes;
    mutable bool outbound_record_transferred{false};

    ParsedSourceProgress(const NodeState& state, Bytes payload, const bool automatic)
        : bytes(std::move(payload)), bytes_digest(datacube::sha256(bytes)),
          decoded(decode_command_source_progress_transaction(bytes)),
          transaction(decoded.transaction),
          outgoing_bytes(source_progress_outgoing_view(bytes, decoded)),
          outbound_record_bytes([&]() -> View {
#ifndef NATRAV_SOURCE_OUTBOUND_INDEPENDENT_DECODING
              if (source_progress_issue(transaction.kind)) {
                  datacube::Reader reader(outgoing_bytes, "prepared source outbound slice");
                  (void)digest(reader);
                  const auto length = reader.read_be32("prepared source record length");
                  const auto record = reader.read_exact(length, "prepared source record");
                  if (active_source_validation_work) {
                      ++active_source_validation_work->outbound_prepared_slices;
                      active_source_validation_work->outbound_slice_header_bytes_read += 36U;
                  }
                  return record;
              }
#endif
              return {};
          }()), owner(&state),
          predecessor([&]() {
              const auto found = state.source_subscriptions_.find(transaction.grant);
              check(found != state.source_subscriptions_.end(),
                  "parsed source progress predecessor absent");
              return &found->second;
          }()),
          configuration_digest([&]() {
              check(transaction.configuration_event != 0U &&
                  transaction.configuration_event ==
                      active_configuration_event(state.configuration_events_),
                  "parsed source progress configuration is not active");
              return state.configuration_events_.at(static_cast<std::size_t>(
                  transaction.configuration_event - 1U)).digest;
          }()), preceding_journal_bytes(state.journal_bytes_),
          queue_limits(state.queue_limits_), published_journal_bytes(std::nullopt) {
        check(source_progress_automatic(transaction.kind) == automatic,
            "parsed source progress manual/automatic origin mismatch");
        if (active_source_validation_work) {
            ++active_source_validation_work->transaction_preparations_created;
        }
    }
    ParsedSourceProgress(const ParsedSourceProgress&) = delete;
    ParsedSourceProgress& operator=(const ParsedSourceProgress&) = delete;
    ParsedSourceProgress(ParsedSourceProgress&&) = delete;
    ParsedSourceProgress& operator=(ParsedSourceProgress&&) = delete;
};

void NodeState::validate_parsed_source_progress_locked(const View bytes,
    const ParsedSourceProgress& parsed, const bool before_append) const {
    // Exact equality is intentional in addition to the digest. A changed,
    // truncated, extended or substituted input cannot select the saved parse.
    check(bytes.size() == parsed.bytes.size() &&
        std::equal(bytes.begin(), bytes.end(), parsed.bytes.begin()) &&
        datacube::sha256(bytes) == parsed.bytes_digest,
        "parsed source progress byte binding mismatch");
    validate_parsed_source_progress_origin_locked(parsed, before_append);
    if (active_source_validation_work) {
        ++active_source_validation_work->transaction_byte_binding_checks;
        active_source_validation_work->transaction_binding_bytes_compared += bytes.size();
        active_source_validation_work->transaction_binding_bytes_hashed += bytes.size();
    }
}

void NodeState::validate_parsed_source_progress_origin_locked(
    const ParsedSourceProgress& parsed, const bool before_append) const {
    const auto& progress = parsed.transaction;
    const auto found = source_subscriptions_.find(progress.grant);
    const auto commitment = source_subscription_commitments_.find(progress.grant);
    check(parsed.owner == this && found != source_subscriptions_.end() &&
        parsed.predecessor == &found->second &&
        found->second.instance == progress.instance &&
        found->second.revision == progress.preceding_revision &&
        commitment != source_subscription_commitments_.end() &&
        commitment->second.root == progress.preceding_commitment &&
        progress.configuration_event == active_configuration_event(configuration_events_) &&
        parsed.configuration_digest == configuration_events_.at(
            static_cast<std::size_t>(progress.configuration_event - 1U)).digest &&
        parsed.queue_limits == queue_limits_ &&
        (!before_append || parsed.preceding_journal_bytes == journal_bytes_),
        "parsed source progress command origin changed");
}

const EvidenceRecord& NodeState::source_outbound_record_locked(const View bytes,
    const ParsedSourceProgress& parsed, const SourceOutboundPart part,
    const bool replaying) const {
    check(!replaying && source_progress_issue(parsed.transaction.kind) &&
        parsed.transaction.record.has_value() && parsed.transaction.policy.has_value() &&
        !parsed.outbound_record_bytes.empty() && !parsed.outbound_record_transferred &&
        (part == SourceOutboundPart::composite || part == SourceOutboundPart::record),
        "source outbound preparation outside live issuance");
    validate_parsed_source_progress_origin_locked(parsed, false);
    const View expected = part == SourceOutboundPart::composite ?
        parsed.outgoing_bytes : parsed.outbound_record_bytes;
    // Exact bytes, not a hash or pointer-identity surrogate. The strictly
    // decoded value and this slice have one immutable owner. No additional
    // snapshot, re-encoding or payload hash is needed to establish equality.
    check(bytes.size() == expected.size() &&
        std::equal(bytes.begin(), bytes.end(), expected.begin()),
        "source outbound bytes do not bind the owned decoded record");
    if (active_source_validation_work) {
        ++active_source_validation_work->outbound_binding_checks;
        active_source_validation_work->outbound_binding_bytes_compared += bytes.size();
        ++active_source_validation_work->outbound_record_reuses;
    }
    return *parsed.transaction.record;
}

void NodeState::mark_parsed_source_progress_published_locked(
    const ParsedSourceProgress& parsed) const {
    // append_entry calls this only after the exact frame has been written and
    // fdatasync has succeeded. The marker is process-local and single-use; it
    // is neither persisted nor accepted from a caller.
    check(parsed.owner == this && !parsed.published_journal_bytes.has_value() &&
        parsed.preceding_journal_bytes < journal_bytes_,
        "parsed source progress publication boundary invalid");
    parsed.published_journal_bytes = journal_bytes_;
}

EvidenceRecord NodeState::take_source_outbound_record_locked(const View bytes,
    const ParsedSourceProgress& parsed, const bool replaying) const {
    // Re-run the exact record-slice binding at the point of ownership transfer.
    // This is the second independent nested admission check, not a remembered
    // preflight verdict.
    const auto& record = source_outbound_record_locked(
        bytes, parsed, SourceOutboundPart::record, replaying);
    check(parsed.published_journal_bytes.has_value() &&
        *parsed.published_journal_bytes == journal_bytes_ &&
        !parsed.outbound_record_transferred,
        "source outbound ownership transfer before durable publication");
    const auto payload_bytes = record.payload.size();
    auto owned = std::move(*parsed.decoded.transaction.record);
    parsed.outbound_record_transferred = true;
    if (active_source_validation_work) {
        ++active_source_validation_work->outbound_store_ownership_transfers;
        active_source_validation_work->outbound_store_payload_bytes_transferred +=
            payload_bytes;
        ++active_source_validation_work->outbound_store_publication_checks;
    }
    return owned;
}

void NodeState::validate_parsed_source_progress_applied_locked(
    const ParsedSourceProgress& parsed) const {
    check(parsed.published_journal_bytes.has_value() &&
        *parsed.published_journal_bytes == journal_bytes_,
        "parsed source progress publication marker changed during application");
    if (!source_progress_issue(parsed.transaction.kind)) {
        check(!parsed.outbound_record_transferred,
            "source acknowledgment transferred an outbound record");
        return;
    }
#if defined(NATRAV_SOURCE_PROGRESS_INDEPENDENT_DECODING) || \
    defined(NATRAV_SOURCE_OUTBOUND_INDEPENDENT_DECODING) || \
    defined(NATRAV_SOURCE_OUTBOUND_COPY_STORE)
    check(!parsed.outbound_record_transferred,
        "source control path unexpectedly transferred command-local record");
#else
    check(parsed.outbound_record_transferred,
        "live source issuance did not transfer its published record exactly once");
#endif
}

void NodeState::commit_source_progress_locked(Bytes bytes,
    const SourceProgressPreparation* prepared, const bool automatic) {
    // A post-publication application failure can leave deliberately partial
    // in-memory indexes while the durable frame remains authoritative. Never
    // re-enter semantic preflight against that poisoned memory; restart must
    // reconstruct the synchronized journal first.
    if (poisoned_) {
        app_fail("STATE_RESTART_REQUIRED",
            "source progress writer requires restart after a failed mutation");
    }
    // Both callers still hold mutex_. All exits (including preflight failure,
    // capacity failure and append failure) destroy this command's parse.
    // The diagnostic variant preserves two independent parses of the same
    // writer bytes; ordinary replay always uses that independent parser too.
#ifndef NATRAV_SOURCE_PROGRESS_INDEPENDENT_DECODING
    const ParsedSourceProgress parsed(*this, std::move(bytes), automatic);
    const auto payload = View(parsed.bytes);
    const auto* decoded = &parsed;
#else
    const auto payload = View(bytes);
    const ParsedSourceProgress* decoded = nullptr;
#endif
    apply_source_subscription(payload, false, true, prepared, decoded);
    pause_at(automatic ? "NATRAV_OVERLAY_TEST_AUTOMATIC_SOURCE_BEFORE_COMMIT_MS" :
                         "NATRAV_OVERLAY_TEST_SOURCE_SUBSCRIPTION_BEFORE_COMMIT_MS");
    append_entry(EntryKind::source_subscription, payload, prepared, decoded);
    pause_at(automatic ? "NATRAV_OVERLAY_TEST_AUTOMATIC_SOURCE_AFTER_COMMIT_MS" :
                         "NATRAV_OVERLAY_TEST_SOURCE_SUBSCRIPTION_AFTER_COMMIT_MS");
}

std::string inspect_source_envelope(View payload) {
    if (payload.size() > kMaximumEvidencePayloadBytes) {
        app_fail("SOURCE_ENVELOPE_INVALID", "source envelope exceeds one evidence payload");
    }
    datacube::Reader r(payload, "source envelope"); const auto version = datacube::octets_text(r.read_exact(4U, "source envelope version"), "source envelope version", true);
    check(version == "NSE1" || version == "NSE2", "source envelope version rejected");
    const bool successor = version == "NSE2";
    const auto grant = text(r, 64U); const auto instance = digest(r); const auto rule = digest(r);
    const auto peer = text(r, 64U); const auto generation = text(r, 64U); const auto pin = digest(r);
    const auto ordinal = r.read_be64("eligible ordinal"); const auto author_uid = r.read_be32("claimed author UID");
    const auto authored = r.read_be64("claimed author time"); const auto source_digest = digest(r);
    std::optional<Digest> parent; if (boolean(r)) { parent = digest(r); }
    const auto length = r.read_be32("embedded source length");
    const auto message = decode_application_message(r.read_exact(length, "embedded source"));
    const auto* source = std::get_if<EvidenceRecord>(&message);
    std::uint64_t inherited = 0U;
    std::string lineage = "null";
    std::string lineage_digest = "null";
    if (successor) {
        lineage_digest = json_string(datacube::hex_lower(hash("NATRAV_OVERLAY_SOURCE_VIEW_LINEAGE_V1", payload.last(r.remaining()))));
        const auto previous_grant = text(r, 64U), previous_lease = text(r, 64U);
        const auto previous_instance = digest(r), previous_state = digest(r), mapping = digest(r);
        inherited = r.read_be64("inherited acknowledged position");
        check(valid_generation_id(previous_grant) && valid_generation_id(previous_lease) &&
            previous_grant != grant && !digest_is_zero(previous_instance) &&
            !digest_is_zero(previous_state) && !digest_is_zero(mapping) &&
            inherited <= kSourceSubscriptionLimit * kSourceSubscriptionRecordLimit,
            "source successor envelope lineage invalid");
        lineage = "{\"predecessor_grant\":" + json_string(previous_grant) +
            ",\"predecessor_lease\":" + json_string(previous_lease) +
            ",\"predecessor_instance\":" + json_string(datacube::hex_lower(previous_instance)) +
            ",\"predecessor_state_digest\":" + json_string(datacube::hex_lower(previous_state)) +
            ",\"mapping_digest\":" + json_string(datacube::hex_lower(mapping)) +
            ",\"inherited_acknowledged\":" + std::to_string(inherited) + "}";
    }
    r.require_eof("source envelope");
    if (!source || !valid_generation_id(grant) || digest_is_zero(instance) || digest_is_zero(rule) ||
        !valid_node_id(peer) || !valid_generation_id(generation) || digest_is_zero(pin) ||
        ordinal <= inherited || ordinal - inherited > kSourceSubscriptionRecordLimit || authored == 0U ||
        source->issuer != source->recipient || source->issuer == peer || source->scope.starts_with("actions/") ||
        source->corrects.has_value() != parent.has_value() || (parent && digest_is_zero(*parent)) ||
        evidence_record_digest(*source) != source_digest) {
        app_fail("SOURCE_ENVELOPE_INVALID", "source envelope structure or commitment mismatch");
    }
    return "{\"format\":" + json_string(successor ? "NATRAV_OVERLAY_SOURCE_ENVELOPE_V2" : "NATRAV_OVERLAY_SOURCE_ENVELOPE_V1") +
        ",\"verification\":\"STRUCTURAL_ONLY\",\"succession\":" + lineage + ",\"lineage_digest\":" + lineage_digest + ",\"grant\":" +
        json_string(grant) + ",\"instance\":" + json_string(datacube::hex_lower(instance)) +
        ",\"grant_digest\":" + json_string(datacube::hex_lower(rule)) + ",\"recipient\":" + json_string(peer) +
        ",\"recipient_generation\":" + json_string(generation) + ",\"recipient_spki\":" + json_string(datacube::hex_lower(pin)) +
        ",\"ordinal\":" + std::to_string(ordinal) + ",\"claimed_author_uid\":" + std::to_string(author_uid) +
        ",\"claimed_authored_unix_ms\":" + std::to_string(authored) +
        ",\"operation_id\":" + json_string(datacube::hex_lower(hash(successor ? "NATRAV_OVERLAY_SOURCE_DELIVERY_V2" : "NATRAV_OVERLAY_SOURCE_DELIVERY_V1", payload))) +
        ",\"mapped_corrects\":" + (parent ? json_string(datacube::hex_lower(*parent)) : std::string("null")) +
        ",\"source_operation\":" + json_string(datacube::hex_lower(source->operation_id)) +
        ",\"source_issuer\":" + json_string(source->issuer) + ",\"scope\":" + json_string(source->scope) +
        ",\"source_corrects\":" + (source->corrects ? json_string(datacube::hex_lower(*source->corrects)) : std::string("null")) +
        ",\"source_record_digest\":" + json_string(datacube::hex_lower(source_digest)) +
        ",\"source_payload_bytes\":" + std::to_string(source->payload.size()) +
        ",\"source_payload_hex\":" + json_string(datacube::hex_lower(source->payload)) + "}";
}

SourceDisclosurePolicy make_source_disclosure_policy(const std::vector<std::string>& values,
    const LocalControlPolicy& control, const std::uint32_t format_version) {
    SourceDisclosurePolicy p;
    if (format_version < 15U && (!values.empty() || std::any_of(control.grants.begin(), control.grants.end(), [&](const auto& g) {
        return local_control_allows(control, g.uid, LocalControlClass::source_disclose);
    }))) { app_fail("CONFIG_VERSION_REJECTED", "SOURCE_DISCLOSE and source_disclosure require V15"); }
    if (values.size() > kSourceSubscriptionLimit) { app_fail("SOURCE_DISCLOSURE_LIMIT", "at most 64 disclosure grants"); }
    for (const auto& value : values) {
        std::vector<std::string> fields; std::size_t start = 0U;
        for (;;) { const auto comma = value.find(',', start); fields.push_back(value.substr(start, comma - start));
            if (comma == std::string::npos) { break; } start = comma + 1U; }
        const std::size_t expected_fields = format_version >= 16U ? 11U : 8U;
        if (fields.size() != expected_fields) {
            app_fail("SOURCE_DISCLOSURE_INVALID", format_version >= 16U ?
                "grant,manager UID,author UID,peer,generation,scope,records,bytes,lease generation,lease ms,withdrawal policy required" :
                "grant,manager UID,author UID,peer,generation,scope,records,bytes required");
        }
        auto number = [&](std::size_t i, std::uint64_t lo, std::uint64_t hi) {
            const auto n = parse_u64(fields[i], "disclosure value", lo, hi);
            if (fields[i] != std::to_string(n)) { app_fail("SOURCE_DISCLOSURE_INVALID", "canonical decimal required"); } return n;
        };
        SourceDisclosureGrant g{.id = fields[0],
            .uid = static_cast<std::uint32_t>(number(1U, 0U, std::numeric_limits<std::uint32_t>::max())),
            .author_uid = static_cast<std::uint32_t>(number(2U, 0U, std::numeric_limits<std::uint32_t>::max())),
            .peer = fields[3], .generation = fields[4], .scope = fields[5],
            .maximum_records = static_cast<std::uint32_t>(number(6U, 1U, kSourceSubscriptionRecordLimit)),
            .maximum_payload_bytes = number(7U, 1U, 7'680'000U),
            .lease_generation = {},
            .lease_duration_ms = 0U,
            .withdrawal_pending = SourcePendingDisposition::retain,
            .digest = {},
        };
        if (format_version >= 16U) {
            g.lease_generation = fields[8];
            g.lease_duration_ms = number(9U, 100U, 604'800'000U);
            if (fields[10] == "RETAIN") {
                g.withdrawal_pending = SourcePendingDisposition::retain;
            } else if (fields[10] == "CANCEL") {
                g.withdrawal_pending = SourcePendingDisposition::cancel;
            } else {
                app_fail("SOURCE_DISCLOSURE_INVALID", "withdrawal policy must be RETAIN or CANCEL");
            }
        }
        g.digest = grant_digest(g); validate_grant(g);
        if (!local_control_allows(control, g.uid, LocalControlClass::source_disclose)) {
            app_fail("SOURCE_DISCLOSURE_CLASS_REQUIRED", "manager requires explicit SOURCE_DISCLOSE");
        }
        p.grants.push_back(g);
    }
    std::sort(p.grants.begin(), p.grants.end(), [](const auto& a, const auto& b) { return a.id < b.id; });
    std::set<std::string> lease_generations;
    for (std::size_t i = 0U; i < p.grants.size(); ++i) {
        if (i != 0U && p.grants[i - 1U].id == p.grants[i].id) {
            app_fail("SOURCE_DISCLOSURE_DUPLICATE", "grant IDs must be unique");
        }
        if (!p.grants[i].lease_generation.empty() &&
            !lease_generations.emplace(p.grants[i].lease_generation).second) {
            app_fail("SOURCE_DISCLOSURE_DUPLICATE", "lease generations must be unique in one accepted policy");
        }
    }
    return p;
}
const SourceDisclosureGrant* source_disclosure_grant(const SourceDisclosurePolicy& p, std::string_view id) {
    const auto i = std::lower_bound(p.grants.begin(), p.grants.end(), id, [](const auto& g, std::string_view v) { return g.id < v; });
    return i == p.grants.end() || i->id != id ? nullptr : &*i;
}
std::string_view source_pending_disposition_name(const SourcePendingDisposition value) noexcept {
    return value == SourcePendingDisposition::cancel ? "CANCEL" : "RETAIN";
}
std::string source_disclosure_grant_text(const SourceDisclosureGrant& g) {
    auto value = g.id + "," + std::to_string(g.uid) + "," + std::to_string(g.author_uid) + "," + g.peer + "," +
        g.generation + "," + g.scope + "," + std::to_string(g.maximum_records) + "," + std::to_string(g.maximum_payload_bytes);
    if (!g.lease_generation.empty()) {
        value += "," + g.lease_generation + "," + std::to_string(g.lease_duration_ms) + "," +
            std::string(source_pending_disposition_name(g.withdrawal_pending));
    }
    return value;
}
std::string source_disclosure_policy_json(const SourceDisclosurePolicy& p) {
    const bool leased = std::any_of(p.grants.begin(), p.grants.end(), [](const auto& grant) {
        return !grant.lease_generation.empty();
    });
    std::string out = std::string("{\"format\":\"") +
        (leased ? "NATRAV_OVERLAY_SOURCE_DISCLOSURE_POLICY_V2" :
                  "NATRAV_OVERLAY_SOURCE_DISCLOSURE_POLICY_V1") +
        "\",\"grants\":[";
    for (std::size_t i = 0U; i < p.grants.size(); ++i) { if (i) { out += ','; }
        out += "{\"definition\":" + json_string(source_disclosure_grant_text(p.grants[i])) +
            ",\"digest\":" + json_string(datacube::hex_lower(p.grants[i].digest)) + "}"; }
    return out + "]}";
}
Bytes encode_source_subscription_request(const SourceSubscriptionRequest& r) {
    if (r.compact_response) {
        auto inner = r;
        inner.compact_response = false;
        const auto encoded = encode_source_subscription_request(inner);
        Bytes out;
        datacube::append_text(out, "NSR5");
        datacube::append_be32(out, static_cast<std::uint32_t>(encoded.size()));
        datacube::append_octets(out, encoded);
        return out;
    }
    if (r.structural_selector && r.command != SourceSubscriptionCommand::succeed &&
        r.command != SourceSubscriptionCommand::reconcile) {
        app_fail("SOURCE_SELECTOR_INVALID", "structural selection requires succession or reconciliation");
    }
    if (!valid_generation_id(r.grant) || r.command < SourceSubscriptionCommand::create ||
        r.command > SourceSubscriptionCommand::reconcile) {
        app_fail("SOURCE_SUBSCRIPTION_INVALID", "invalid grant or command");
    }
    const bool succession = r.command == SourceSubscriptionCommand::succeed;
    const bool reconcile = r.command == SourceSubscriptionCommand::reconcile;
    const bool selected = reconcile || succession || r.command == SourceSubscriptionCommand::step ||
        r.command == SourceSubscriptionCommand::retire ||
        r.command == SourceSubscriptionCommand::automatic_enable ||
        r.command == SourceSubscriptionCommand::automatic_pause;
    const bool schedule = r.command == SourceSubscriptionCommand::automatic_enable ||
        r.command == SourceSubscriptionCommand::automatic_pause;
    const bool needs_reason = reconcile || succession || r.command == SourceSubscriptionCommand::create ||
        r.command == SourceSubscriptionCommand::retire || schedule;
    if (selected != r.instance.has_value() || (r.instance && digest_is_zero(*r.instance)) ||
        (selected ? (r.expected_revision == 0U || r.expected_revision > 65'536U) : r.expected_revision != 0U) ||
        (needs_reason ? !reason_ok(r.reason) : !r.reason.empty()) ||
        (r.retain_pending && r.command != SourceSubscriptionCommand::retire) ||
        (schedule ? (r.expected_schedule_revision > 65'536U ||
             r.expected_grant_generation > kSourceSubscriptionAutomaticGrantLimit) :
             (r.expected_schedule_revision != 0U || r.expected_grant_generation != 0U)) ||
        (r.command == SourceSubscriptionCommand::automatic_enable ?
            (r.automatic_maximum_steps == 0U || r.automatic_maximum_steps > 10'000U ||
             r.automatic_minimum_interval_ms < 10U || r.automatic_minimum_interval_ms > 60'000U) :
            (r.automatic_maximum_steps != 100U || r.automatic_minimum_interval_ms != 100U))) {
        app_fail("SOURCE_SUBSCRIPTION_INVALID", "exact instance/revision and bounded reason required");
    }
    if (succession ?
        (!valid_generation_id(r.predecessor_grant) || r.predecessor_grant == r.grant ||
         !valid_generation_id(r.predecessor_lease) || !valid_generation_id(r.successor_lease) ||
         r.predecessor_lease == r.successor_lease ||
         !r.predecessor_state_digest || digest_is_zero(*r.predecessor_state_digest) ||
         !r.predecessor_mapping_digest || digest_is_zero(*r.predecessor_mapping_digest) ||
         r.expected_frontier > kSourceSubscriptionLimit * kSourceSubscriptionRecordLimit) :
        (!r.predecessor_grant.empty() || !r.predecessor_lease.empty() ||
         !r.successor_lease.empty() || r.predecessor_state_digest ||
         r.predecessor_mapping_digest || r.expected_frontier != 0U)) {
        app_fail("SOURCE_SUCCESSION_INVALID", "exact bounded predecessor and successor selectors required");
    }
    const auto selected_digest = [](const std::optional<Digest>& d) {
        return d.has_value() && !digest_is_zero(*d);
    };
    if (reconcile ?
        (!selected_digest(r.reconciliation_state_digest) || !selected_digest(r.terminal_digest) ||
         !selected_digest(r.source_operation) || !selected_digest(r.delivery_operation) ||
         !selected_digest(r.receipt_digest)) :
        (r.reconciliation_state_digest || r.terminal_digest || r.source_operation ||
         r.delivery_operation || r.receipt_digest)) {
        app_fail("SOURCE_RECONCILIATION_INVALID", "exact state, terminal, source, delivery and receipt digests required");
    }
    const bool legacy = r.command <= SourceSubscriptionCommand::retire;
    Bytes out; datacube::append_text(out, r.structural_selector ? "NSR6" : reconcile ? "NSR4" : succession ? "NSR3" : (legacy ? "NSR1" : "NSR2"));
    datacube::append_u8(out, static_cast<std::uint8_t>(r.command)); text(out, r.grant);
    if (selected) { digest(out, *r.instance); datacube::append_be64(out, r.expected_revision); }
    if (r.command == SourceSubscriptionCommand::retire) { datacube::append_u8(out, r.retain_pending ? 1U : 0U); }
    if (schedule) {
        datacube::append_be64(out, r.expected_schedule_revision);
        datacube::append_be64(out, r.expected_grant_generation);
        if (r.command == SourceSubscriptionCommand::automatic_enable) {
            datacube::append_be32(out, r.automatic_maximum_steps);
            datacube::append_be32(out, r.automatic_minimum_interval_ms);
        }
    }
    if (succession) {
        text(out, r.predecessor_grant); text(out, r.predecessor_lease); text(out, r.successor_lease);
        digest(out, *r.predecessor_state_digest); digest(out, *r.predecessor_mapping_digest);
        datacube::append_be64(out, r.expected_frontier);
    }
    if (reconcile) {
        digest(out, *r.reconciliation_state_digest); digest(out, *r.terminal_digest);
        digest(out, *r.source_operation); digest(out, *r.delivery_operation); digest(out, *r.receipt_digest);
    }
    if (needs_reason) { text(out, r.reason); } return out;
}
SourceSubscriptionRequest decode_source_subscription_request(View bytes) {
    datacube::Reader r(bytes, "source subscription request");
    const auto version = datacube::octets_text(r.read_exact(4U, "source request magic"),
        "source request magic", true);
    if (version == "NSR5") {
        const auto inner = r.read_blob32(2'048U, "compact response request");
        r.require_eof("compact response request");
        check(inner.size() >= 4U && !std::equal(inner.begin(), inner.begin() + 4,
            std::string_view("NSR5").begin()), "nested compact response request rejected");
        auto q = decode_source_subscription_request(inner);
        q.compact_response = true;
        return q;
    }
    check(version == "NSR1" || version == "NSR2" || version == "NSR3" ||
        version == "NSR4" || version == "NSR6", "source request version rejected");
    SourceSubscriptionRequest q;
    q.structural_selector = version == "NSR6";
    q.command = static_cast<SourceSubscriptionCommand>(r.read_u8("source command")); q.grant = text(r, 64U);
    if (q.command == SourceSubscriptionCommand::reconcile || q.command == SourceSubscriptionCommand::succeed || q.command == SourceSubscriptionCommand::step || q.command == SourceSubscriptionCommand::retire ||
        q.command == SourceSubscriptionCommand::automatic_enable ||
        q.command == SourceSubscriptionCommand::automatic_pause) {
        q.instance = digest(r); q.expected_revision = r.read_be64("source expected revision");
    }
    if (q.command == SourceSubscriptionCommand::retire) { q.retain_pending = boolean(r); }
    if (q.command == SourceSubscriptionCommand::automatic_enable ||
        q.command == SourceSubscriptionCommand::automatic_pause) {
        check(version == "NSR2", "automatic source commands require NSR2");
        q.expected_schedule_revision = r.read_be64("source schedule revision");
        q.expected_grant_generation = r.read_be64("source grant generation");
        if (q.command == SourceSubscriptionCommand::automatic_enable) {
            q.automatic_maximum_steps = r.read_be32("source automatic step budget");
            q.automatic_minimum_interval_ms = r.read_be32("source automatic interval");
        }
    }
    check((version == "NSR3" || (q.structural_selector &&
        q.command == SourceSubscriptionCommand::succeed)) == (q.command == SourceSubscriptionCommand::succeed),
        "source succession requires exact NSR3 version");
    if (q.command == SourceSubscriptionCommand::succeed) {
        q.predecessor_grant = text(r, 64U); q.predecessor_lease = text(r, 64U);
        q.successor_lease = text(r, 64U); q.predecessor_state_digest = digest(r);
        q.predecessor_mapping_digest = digest(r); q.expected_frontier = r.read_be64("adopted source frontier");
    }
    check((version == "NSR4" || (q.structural_selector &&
        q.command == SourceSubscriptionCommand::reconcile)) == (q.command == SourceSubscriptionCommand::reconcile),
        "source reconciliation requires exact NSR4 version");
    if (q.command == SourceSubscriptionCommand::reconcile) {
        q.reconciliation_state_digest = digest(r); q.terminal_digest = digest(r);
        q.source_operation = digest(r); q.delivery_operation = digest(r); q.receipt_digest = digest(r);
    }
    if (q.command == SourceSubscriptionCommand::reconcile || q.command == SourceSubscriptionCommand::succeed || q.command == SourceSubscriptionCommand::create || q.command == SourceSubscriptionCommand::retire ||
        q.command == SourceSubscriptionCommand::automatic_enable ||
        q.command == SourceSubscriptionCommand::automatic_pause) { q.reason = text(r); }
    r.require_eof("source subscription request"); static_cast<void>(encode_source_subscription_request(q)); return q;
}
Bytes encode_source_subscription(const SourceSubscription& s) {
    const bool scheduled = !s.automatic_grants.empty() ||
        s.automatic_schedule_revision != 0U;
    const bool leased = !s.grant.lease_generation.empty() ||
        s.lease_started_unix_ms != 0U || s.lease_expires_unix_ms != 0U ||
        s.termination.has_value();
    const bool extended = scheduled || leased;
    Bytes out;
    datacube::append_text(out, s.reconciliation ? "NSS6" : s.succession ? "NSS5" : leased ? "NSS4" :
        (scheduled ? "NSS3" : (s.remote_admission ? "NSS2" : "NSS1")));
    datacube::append_octets(out, grant_bytes(s.grant));
    digest(out, s.grant.digest);
    digest(out, s.instance);
    digest(out, s.peer_spki);
    datacube::append_be64(out, s.created_event);
    datacube::append_be64(out, s.created_unix_ms);
    datacube::append_be32(out, s.created_pid);
    text(out, s.creation_reason);
    if (extended) { datacube::append_u8(out, s.remote_admission ? 1U : 0U); }
    if (s.remote_admission) {
        const auto& remote = *s.remote_admission;
        digest(out, remote.request_id);
        text(out, remote.peer);
        text(out, remote.generation);
        digest(out, remote.peer_spki);
        datacube::append_be64(out, remote.configuration_event);
        datacube::append_be64(out, remote.unix_ms);
        text(out, remote.reason);
        digest(out, remote.request_digest);
    }
    datacube::append_be64(out, s.revision);
    datacube::append_be32(out, static_cast<std::uint32_t>(s.deliveries.size()));
    for (const auto& d : s.deliveries) {
        digest(out, d.source_operation);
        digest(out, d.operation);
        digest(out, d.record_digest);
        datacube::append_be32(out, d.payload_bytes);
        datacube::append_be64(out, d.configuration_event);
        datacube::append_be64(out, d.unix_ms);
        datacube::append_be32(out, d.pid);
        datacube::append_be64(out, d.acknowledged_event);
        datacube::append_be64(out, d.acknowledged_unix_ms);
        datacube::append_be32(out, d.acknowledged_pid);
        if (extended) {
            datacube::append_be64(out, d.issue_automatic_generation);
            datacube::append_be64(out, d.acknowledge_automatic_generation);
        }
    }
    datacube::append_be64(out, s.acknowledged);
    datacube::append_be64(out, s.used_payload_bytes);
    datacube::append_u8(out, s.retired ? 1U : 0U);
    datacube::append_u8(out, s.retained_unacknowledged ? 1U : 0U);
    text(out, s.transition);
    text(out, s.reason);
    datacube::append_be64(out, s.configuration_event);
    datacube::append_be64(out, s.unix_ms);
    datacube::append_be32(out, s.pid);
    digest(out, s.request_digest);
    if (extended) {
        datacube::append_be64(out, s.automatic_schedule_revision);
        datacube::append_be32(out,
            static_cast<std::uint32_t>(s.automatic_grants.size()));
        for (const auto& grant : s.automatic_grants) {
            datacube::append_be64(out, grant.generation);
            datacube::append_be64(out, grant.observed_subscription_revision);
            datacube::append_be64(out, grant.configuration_event);
            datacube::append_be64(out, grant.unix_ms);
            datacube::append_be32(out, grant.actor_uid);
            datacube::append_be32(out, grant.pid);
            datacube::append_be32(out, grant.maximum_steps);
            datacube::append_be32(out, grant.minimum_interval_ms);
            digest(out, grant.disclosure_digest);
            text(out, grant.reason);
            datacube::append_be64(out, grant.start_issued);
            datacube::append_be64(out, grant.start_acknowledged);
            datacube::append_be64(out, grant.steps);
            text(out, grant.state);
            text(out, grant.error);
            text(out, grant.end_reason);
            datacube::append_be64(out, grant.last_step_event);
            datacube::append_be64(out, grant.last_step_unix_ms);
            datacube::append_be32(out, grant.last_executor_uid);
            datacube::append_be32(out, grant.last_executor_pid);
            datacube::append_be64(out, grant.ended_event);
            datacube::append_be64(out, grant.ended_unix_ms);
            datacube::append_be32(out, grant.ended_uid);
            datacube::append_be32(out, grant.ended_pid);
        }
    }
    if (leased) {
        datacube::append_be64(out, s.lease_started_unix_ms);
        datacube::append_be64(out, s.lease_expires_unix_ms);
        datacube::append_u8(out, s.termination ? 1U : 0U);
        if (s.termination) {
            const auto& terminal = *s.termination;
            text(out, terminal.kind);
            text(out, terminal.lease_generation);
            datacube::append_be64(out, terminal.configuration_event);
            datacube::append_be64(out, terminal.unix_ms);
            text(out, terminal.pending_disposition);
            datacube::append_u8(out,
                terminal.cancelled_operation ? 1U : 0U);
            if (terminal.cancelled_operation) {
                digest(out, *terminal.cancelled_operation);
            }
            text(out, terminal.actor_peer);
            text(out, terminal.actor_generation);
            digest(out, terminal.actor_spki);
            datacube::append_u8(out, terminal.request_id ? 1U : 0U);
            if (terminal.request_id) { digest(out, *terminal.request_id); }
            digest(out, terminal.request_digest);
            text(out, terminal.reason);
        }
    }
    if (s.reconciliation) { datacube::append_u8(out, s.succession ? 1U : 0U); }
    if (s.succession) {
        const auto& x = *s.succession;
        text(out, x.predecessor_grant); text(out, x.predecessor_lease);
        digest(out, x.predecessor_instance); datacube::append_be64(out, x.predecessor_revision);
        digest(out, x.predecessor_state_digest); datacube::append_be64(out, x.inherited_acknowledged);
        digest(out, x.mapping_digest); digest(out, x.creation_request_digest);
    }
    if (s.reconciliation) {
        const auto& x = *s.reconciliation;
        datacube::append_be64(out, x.preceding_revision); datacube::append_be32(out, x.preceding_pid);
        digest(out, x.preceding_state_digest); digest(out, x.terminal_digest);
        digest(out, x.source_operation); digest(out, x.delivery_operation); digest(out, x.receipt_digest);
    }
    if (out.size() > kSourceSubscriptionEncodedLimit) {
        app_fail("SOURCE_SUBSCRIPTION_LIMIT",
            "subscription encoding exceeds bound");
    }
    if (active_source_validation_work) {
        ++active_source_validation_work->state_encodes;
        active_source_validation_work->state_bytes_encoded += out.size();
    }
    return out;
}

SourceSubscription decode_source_subscription(View bytes) {
    if (active_source_validation_work) {
        ++active_source_validation_work->state_decodes;
        active_source_validation_work->state_bytes_decoded += bytes.size();
    }
    check(bytes.size() <= kSourceSubscriptionEncodedLimit,
        "source subscription size bound");
    datacube::Reader r(bytes, "source subscription state");
    const auto version = datacube::octets_text(
        r.read_exact(4U, "source subscription magic"),
        "source subscription magic", true);
    check(version == "NSS1" || version == "NSS2" ||
          version == "NSS3" || version == "NSS4" || version == "NSS5" || version == "NSS6",
        "source subscription format version rejected");
    const bool leased = version == "NSS4" || version == "NSS5" || version == "NSS6";
    const bool extended = version == "NSS3" || leased;
    SourceSubscription s;
    s.grant = read_grant(r, leased);
    s.instance = digest(r);
    s.peer_spki = digest(r);
    s.created_event = r.read_be64("source created event");
    s.created_unix_ms = r.read_be64("source created time");
    s.created_pid = r.read_be32("source created PID");
    s.creation_reason = text(r);
    const bool has_remote = extended ? boolean(r) : version == "NSS2";
    if (has_remote) {
        SourceSubscriptionRemoteAdmission remote;
        remote.request_id = digest(r);
        remote.peer = text(r, 64U);
        remote.generation = text(r, 64U);
        remote.peer_spki = digest(r);
        remote.configuration_event = r.read_be64(
            "remote request configuration event");
        remote.unix_ms = r.read_be64("remote request time");
        remote.reason = text(r);
        remote.request_digest = digest(r);
        s.remote_admission = std::move(remote);
    }
    s.revision = r.read_be64("source revision");
    const auto count = r.read_be32("source count");
    check(count <= kSourceSubscriptionRecordLimit,
        "source record count bound");
    for (std::uint32_t i = 0U; i < count; ++i) {
        SourceSubscriptionDelivery d;
        d.source_operation = digest(r);
        d.operation = digest(r);
        d.record_digest = digest(r);
        d.payload_bytes = r.read_be32("source payload bytes");
        d.configuration_event = r.read_be64("source issue event");
        d.unix_ms = r.read_be64("source issue time");
        d.pid = r.read_be32("source issuer PID");
        d.acknowledged_event = r.read_be64("source ack event");
        d.acknowledged_unix_ms = r.read_be64("source ack time");
        d.acknowledged_pid = r.read_be32("source ack PID");
        if (extended) {
            d.issue_automatic_generation = r.read_be64(
                "source automatic issue generation");
            d.acknowledge_automatic_generation = r.read_be64(
                "source automatic ack generation");
        }
        s.deliveries.push_back(std::move(d));
    }
    s.acknowledged = r.read_be64("source acknowledged");
    s.used_payload_bytes = r.read_be64("source used bytes");
    s.retired = boolean(r);
    s.retained_unacknowledged = boolean(r);
    s.transition = text(r, 32U);
    s.reason = text(r);
    s.configuration_event = r.read_be64("source event");
    s.unix_ms = r.read_be64("source time");
    s.pid = r.read_be32("source PID");
    s.request_digest = digest(r);
    if (extended) {
        s.automatic_schedule_revision = r.read_be64(
            "source schedule revision");
        const auto grants = r.read_be32("source automatic grant count");
        check(grants <= kSourceSubscriptionAutomaticGrantLimit &&
            (version != "NSS3" || grants > 0U),
            "source automatic grant count bound");
        for (std::uint32_t i = 0U; i < grants; ++i) {
            SourceSubscriptionAutomaticGrant grant;
            grant.generation = r.read_be64("source automatic generation");
            grant.observed_subscription_revision = r.read_be64(
                "source observed revision");
            grant.configuration_event = r.read_be64(
                "source grant configuration event");
            grant.unix_ms = r.read_be64("source grant time");
            grant.actor_uid = r.read_be32("source grant actor UID");
            grant.pid = r.read_be32("source grant PID");
            grant.maximum_steps = r.read_be32(
                "source automatic step limit");
            grant.minimum_interval_ms = r.read_be32(
                "source automatic interval");
            grant.disclosure_digest = digest(r);
            grant.reason = text(r);
            grant.start_issued = r.read_be64(
                "source automatic starting issued");
            grant.start_acknowledged = r.read_be64(
                "source automatic starting acknowledged");
            grant.steps = r.read_be64("source automatic steps");
            grant.state = text(r, 16U);
            grant.error = text(r, 64U);
            grant.end_reason = text(r);
            grant.last_step_event = r.read_be64(
                "source automatic last event");
            grant.last_step_unix_ms = r.read_be64(
                "source automatic last time");
            grant.last_executor_uid = r.read_be32(
                "source automatic last executor UID");
            grant.last_executor_pid = r.read_be32(
                "source automatic last executor PID");
            grant.ended_event = r.read_be64(
                "source automatic end event");
            grant.ended_unix_ms = r.read_be64(
                "source automatic end time");
            grant.ended_uid = r.read_be32("source automatic end UID");
            grant.ended_pid = r.read_be32("source automatic end PID");
            s.automatic_grants.push_back(std::move(grant));
        }
    }
    if (leased) {
        s.lease_started_unix_ms = r.read_be64("source lease start");
        s.lease_expires_unix_ms = r.read_be64("source lease expiry");
        if (boolean(r)) {
            SourceSubscriptionTermination terminal;
            terminal.kind = text(r, 16U);
            terminal.lease_generation = text(r, 64U);
            terminal.configuration_event = r.read_be64(
                "source terminal configuration event");
            terminal.unix_ms = r.read_be64("source terminal time");
            terminal.pending_disposition = text(r, 16U);
            if (boolean(r)) { terminal.cancelled_operation = digest(r); }
            terminal.actor_peer = text(r, 64U);
            terminal.actor_generation = text(r, 64U);
            terminal.actor_spki = digest(r);
            if (boolean(r)) { terminal.request_id = digest(r); }
            terminal.request_digest = digest(r);
            terminal.reason = text(r);
            s.termination = std::move(terminal);
        }
    }
    if (version == "NSS5" || (version == "NSS6" && boolean(r))) {
        SourceSubscriptionSuccession x;
        x.predecessor_grant = text(r, 64U); x.predecessor_lease = text(r, 64U);
        x.predecessor_instance = digest(r); x.predecessor_revision = r.read_be64("predecessor revision");
        x.predecessor_state_digest = digest(r); x.inherited_acknowledged = r.read_be64("inherited frontier");
        x.mapping_digest = digest(r); x.creation_request_digest = digest(r);
        s.succession = std::move(x);
    }
    if (version == "NSS6") {
        SourceReceiptReconciliation x;
        x.preceding_revision = r.read_be64("reconciled preceding revision");
        x.preceding_pid = r.read_be32("reconciled preceding PID");
        x.preceding_state_digest = digest(r); x.terminal_digest = digest(r);
        x.source_operation = digest(r); x.delivery_operation = digest(r); x.receipt_digest = digest(r);
        s.reconciliation = std::move(x);
    }
    r.require_eof("source subscription state");
    return s;
}

Digest parse_source_state_selector(const std::string_view value) {
    if (!value.starts_with(kSourceStateSelectorPrefix) ||
        value.size() != kSourceStateSelectorPrefix.size() + 64U) {
        app_fail("SOURCE_SELECTOR_INVALID", "expected SPSC1: followed by 64 hexadecimal digits");
    }
    const auto result = parse_operation_id(value.substr(kSourceStateSelectorPrefix.size()));
    if (digest_is_zero(result)) { app_fail("SOURCE_SELECTOR_INVALID", "zero structural selector rejected"); }
    return result;
}
Digest source_subscription_structural_digest(const SourceSubscription& value) {
    return source_progress_commitment(value).root;
}
std::string source_subscription_json(const SourceSubscription& s, bool history, std::string_view delivery_status,
    std::string_view disposition, bool policy_current, std::string_view automatic_observation,
    const SourceSubscriptionCommitment* compact, const Digest* mapping) {
    std::string out = std::string("{\"format\":\"") +
        (compact ? "NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_COMPACT_V1" :
         source_subscription_is_leased(s) ?
            "NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_V2" :
            "NATRAV_OVERLAY_SOURCE_SUBSCRIPTION_V1") +
        "\",\"grant\":" + json_string(s.grant.id) +
        ",\"instance\":" + json_string(datacube::hex_lower(s.instance)) + ",\"uid\":" + std::to_string(s.grant.uid) +
        ",\"source_author_uid\":" + std::to_string(s.grant.author_uid) + ",\"peer\":" + json_string(s.grant.peer) +
        ",\"generation\":" + json_string(s.grant.generation) + ",\"peer_spki_sha256\":" + json_string(datacube::hex_lower(s.peer_spki)) +
        ",\"scope\":" + json_string(s.grant.scope) + ",\"revision\":" + std::to_string(s.revision) +
        ",\"state\":" + json_string(s.retired ? "RETIRED" : "ACTIVE") +
        ",\"issued\":" + std::to_string(s.deliveries.size()) + ",\"acknowledged\":" + std::to_string(s.acknowledged) +
        ",\"used_payload_bytes\":" + std::to_string(s.used_payload_bytes) +
        ",\"maximum_records\":" + std::to_string(s.grant.maximum_records) +
        ",\"maximum_payload_bytes\":" + std::to_string(s.grant.maximum_payload_bytes) +
        ",\"retained_unacknowledged\":" + (s.retained_unacknowledged ? std::string("true") : std::string("false")) +
        ",\"policy_current\":" + (policy_current ? std::string("true") : std::string("false")) +
        ",\"disposition\":" + json_string(disposition) + ",\"delivery_status\":" + json_string(delivery_status) +
        ",\"grant_digest\":" + json_string(datacube::hex_lower(s.grant.digest)) +
        ",\"lease_generation\":" + json_string(s.grant.lease_generation) +
        ",\"lease_duration_ms\":" + std::to_string(s.grant.lease_duration_ms) +
        ",\"lease_started_unix_ms\":" + std::to_string(s.lease_started_unix_ms) +
        ",\"lease_expires_unix_ms\":" + std::to_string(s.lease_expires_unix_ms) +
        ",\"withdrawal_policy\":" + (source_subscription_is_leased(s) ?
            json_string(source_pending_disposition_name(s.grant.withdrawal_pending)) :
            json_string("")) +
        ",\"termination\":" + termination_json(s.termination) +
        ",\"created_event\":" + std::to_string(s.created_event) + ",\"creation_reason\":" + json_string(s.creation_reason) +
        ",\"remote_admission\":" + (s.remote_admission ?
            (std::string("{\"request_id\":") + json_string(datacube::hex_lower(s.remote_admission->request_id)) +
             ",\"peer\":" + json_string(s.remote_admission->peer) +
             ",\"generation\":" + json_string(s.remote_admission->generation) +
             ",\"peer_spki_sha256\":" + json_string(datacube::hex_lower(s.remote_admission->peer_spki)) +
             ",\"configuration_event\":" + std::to_string(s.remote_admission->configuration_event) +
             ",\"unix_ms\":" + std::to_string(s.remote_admission->unix_ms) +
             ",\"reason\":" + json_string(s.remote_admission->reason) + "}") : std::string("null")) +
        ",\"transition\":" + json_string(s.transition) + ",\"reason\":" + json_string(s.reason) +
        ",\"configuration_event\":" + std::to_string(s.configuration_event) + ",\"unix_ms\":" + std::to_string(s.unix_ms) +
        ",\"pid\":" + std::to_string(s.pid) +
        ",\"automatic_schedule_revision\":" + std::to_string(s.automatic_schedule_revision) +
        ",\"automatic_generation\":" + std::to_string(s.automatic_grants.size()) +
        ",\"automatic_observation\":" + json_string(automatic_observation) +
        ",\"automatic_current\":" + (s.automatic_grants.empty() ? std::string("null") :
            automatic_grant_json(s.automatic_grants.back())) +
        ",\"latest\":" +
        (s.deliveries.empty() ? std::string("null") : delivery_json(s.deliveries.back()));
    if (compact) {
        check(mapping != nullptr && !history, "compact source response requires derived mapping and no full history");
        out += ",\"state_selector\":" + json_string(std::string(kSourceStateSelectorPrefix) +
            datacube::hex_lower(compact->root)) +
            ",\"state_selector_kind\":\"NATRAV_OVERLAY_SOURCE_PROGRESS_STATE_V1\"" +
            ",\"freshness\":\"NOT_ESTABLISHED\"";
    } else {
        out += ",\"state_digest\":" + json_string(datacube::hex_lower(source_state_digest(s)));
    }
    out += ",\"acknowledged_mapping_digest\":" + json_string(datacube::hex_lower(
            mapping ? *mapping : source_mapping_digest(s))) +
        ",\"inherited_acknowledged\":" + std::to_string(source_base(s)) +
        ",\"acknowledged_source_position\":" + std::to_string(source_frontier(s)) +
        ",\"succession\":";
    if (s.succession) {
        const auto& x = *s.succession;
        out += "{\"actor\":\"LOCAL_SOURCE_MANAGER\",\"manager_uid\":" + std::to_string(s.grant.uid) +
            ",\"actor_pid\":" + std::to_string(s.created_pid) +
            ",\"configuration_event\":" + std::to_string(s.created_event) +
            ",\"unix_ms\":" + std::to_string(s.created_unix_ms) +
            ",\"predecessor_grant\":" + json_string(x.predecessor_grant) +
            ",\"predecessor_lease\":" + json_string(x.predecessor_lease) +
            ",\"predecessor_instance\":" + json_string(datacube::hex_lower(x.predecessor_instance)) +
            ",\"predecessor_revision\":" + std::to_string(x.predecessor_revision) +
            ",\"predecessor_state_digest\":" + json_string(datacube::hex_lower(x.predecessor_state_digest)) +
            ",\"inherited_acknowledged\":" + std::to_string(x.inherited_acknowledged) +
            ",\"mapping_digest\":" + json_string(datacube::hex_lower(x.mapping_digest)) +
            ",\"creation_request_digest\":" + json_string(datacube::hex_lower(x.creation_request_digest)) + "}";
    } else { out += "null"; }
    out += ",\"terminal_digest\":" + (s.termination ?
        json_string(datacube::hex_lower(terminal_digest(*s.termination))) : std::string("null"));
    out += ",\"reconciliation\":";
    if (s.reconciliation) {
        const auto& x = *s.reconciliation;
        out += "{\"actor\":\"LOCAL_SOURCE_MANAGER\",\"uid\":" + std::to_string(s.grant.uid) +
            ",\"pid\":" + std::to_string(s.pid) + ",\"configuration_event\":" + std::to_string(s.configuration_event) +
            ",\"unix_ms\":" + std::to_string(s.unix_ms) + ",\"reason\":" + json_string(s.reason) +
            ",\"preceding_revision\":" + std::to_string(x.preceding_revision) +
            ",\"preceding_state_digest\":" + json_string(datacube::hex_lower(x.preceding_state_digest)) +
            ",\"terminal_digest\":" + json_string(datacube::hex_lower(x.terminal_digest)) +
            ",\"source_operation\":" + json_string(datacube::hex_lower(x.source_operation)) +
            ",\"delivery_operation\":" + json_string(datacube::hex_lower(x.delivery_operation)) +
            ",\"receipt_digest\":" + json_string(datacube::hex_lower(x.receipt_digest)) +
            ",\"request_digest\":" + json_string(datacube::hex_lower(s.request_digest)) + "}";
    } else { out += "null"; }
    if (history) { out += ",\"deliveries\":["; for (std::size_t i = 0U; i < s.deliveries.size(); ++i) {
        if (i) { out += ','; } out += delivery_json(s.deliveries[i]); } out += ']'; }
    if (history) { out += ",\"automatic_grants\":["; for (std::size_t i = 0U; i < s.automatic_grants.size(); ++i) {
        if (i) { out += ','; } out += automatic_grant_json(s.automatic_grants[i]); } out += ']'; }
    return out + "}";
}

std::string remote_source_subscription_response_json(
    const RemoteSourceSubscriptionResponse& response) {
    validate_remote_source_subscription_response(response);
    const bool leased = !response.lease_generation.empty();
    return std::string("{\"format\":\"") +
        (leased ? "NATRAV_OVERLAY_REMOTE_SOURCE_SUBSCRIPTION_RESPONSE_V2" :
                  "NATRAV_OVERLAY_REMOTE_SOURCE_SUBSCRIPTION_RESPONSE_V1") +
        "\",\"request_id\":" + json_string(datacube::hex_lower(response.request_id)) +
        ",\"provider\":" + json_string(response.provider) +
        ",\"grant\":" + json_string(response.grant) +
        ",\"instance\":" + json_string(datacube::hex_lower(response.instance)) +
        ",\"revision\":" + std::to_string(response.revision) +
        ",\"state\":" + json_string(response.retired ? "RETIRED" : "ACTIVE") +
        ",\"disposition\":" + json_string(response.disposition) +
        ",\"issued\":" + std::to_string(response.issued) +
        ",\"acknowledged\":" + std::to_string(response.acknowledged) +
        ",\"used_payload_bytes\":" + std::to_string(response.used_payload_bytes) +
        ",\"maximum_records\":" + std::to_string(response.maximum_records) +
        ",\"maximum_payload_bytes\":" + std::to_string(response.maximum_payload_bytes) +
        ",\"grant_digest\":" + json_string(datacube::hex_lower(response.grant_digest)) +
        ",\"subscriber_generation\":" + json_string(response.subscriber_generation) +
        ",\"subscriber_spki_sha256\":" + json_string(datacube::hex_lower(response.subscriber_spki)) +
        ",\"accepted_request_id\":" + json_string(datacube::hex_lower(response.accepted_request_id)) +
        ",\"accepted_configuration_event\":" + std::to_string(response.accepted_configuration_event) +
        ",\"accepted_unix_ms\":" + std::to_string(response.accepted_unix_ms) +
        ",\"lease_generation\":" + json_string(response.lease_generation) +
        ",\"lease_expires_unix_ms\":" + std::to_string(response.lease_expires_unix_ms) +
        ",\"withdrawal_policy\":" + json_string(response.withdrawal_policy) +
        ",\"terminal_kind\":" + json_string(response.terminal_kind) +
        ",\"terminal_pending_disposition\":" + json_string(response.terminal_pending_disposition) +
        ",\"terminal_cancelled_operation\":" +
            (response.terminal_cancelled_operation ?
                json_string(datacube::hex_lower(*response.terminal_cancelled_operation)) :
                std::string("null")) +
        ",\"terminal_reason\":" + json_string(response.terminal_reason) + "}";
}
EvidenceRecord NodeState::source_subscription_record_locked(const SourceSubscription& s,
    std::size_t position, const bool indexed) const {
    if (active_source_validation_work) { ++active_source_validation_work->source_records_reconstructed; }
    const auto domain = authored_source_index_.find({s.grant.author_uid, s.grant.scope});
    const auto absolute_position = source_base(s) + position;
    check(domain != authored_source_index_.end() && absolute_position < domain->second.size(), "source frontier missing");
    const auto& source = inbound_[domain->second[static_cast<std::size_t>(absolute_position)]];
    check(source.local_authorship && source.local_authorship->uid == s.grant.author_uid &&
        source.record.issuer == node_id_ && source.record.recipient == node_id_ && source.record.scope == s.grant.scope,
        "source disclosure requires exact validated local authorship");
    std::optional<Digest> corrects;
    if (source.record.corrects) {
        const auto retained = source_subscriptions_.find(s.grant.id);
        // Full validation of untrusted/candidate canonical states never consumes
        // this index. Only an exact retained, already validated predecessor does.
        const bool use_index = indexed && retained != source_subscriptions_.end() &&
            &retained->second == &s;
        if (use_index) {
            if (active_source_validation_work) { ++active_source_validation_work->mapping_index_lookups; }
            const auto cached = source_subscription_indexes_.find(s.grant.id);
            check(cached != source_subscription_indexes_.end() &&
                cached->second.instance == s.instance && cached->second.frontier == source_frontier(s),
                "source ancestry index boundary mismatch");
            const auto parent = cached->second.ancestry.find(source.record.corrects->octets);
            check(parent != cached->second.ancestry.end(), "source correction lacks indexed acknowledged parent");
            const auto owner = source_subscriptions_.find(parent->second.grant);
            check(owner != source_subscriptions_.end(), "indexed source parent owner absent");
            const auto& ancestor = owner->second;
            const auto index = parent->second.position;
            check(ancestor.instance == parent->second.instance && index < ancestor.acknowledged &&
                index < ancestor.deliveries.size() && source_base(ancestor) + index < absolute_position &&
                ancestor.grant.uid == s.grant.uid && ancestor.grant.author_uid == s.grant.author_uid &&
                ancestor.grant.scope == s.grant.scope && ancestor.grant.peer == s.grant.peer &&
                ancestor.grant.generation == s.grant.generation && ancestor.peer_spki == s.peer_spki,
                "indexed source parent identity/frontier mismatch");
            const auto& entry = ancestor.deliveries[index];
            check(entry.source_operation == *source.record.corrects && entry.acknowledged_event != 0U,
                "indexed source parent acknowledgment mismatch");
            corrects = entry.operation;
            if (active_source_validation_work) { ++active_source_validation_work->mapping_index_hits; }
        } else {
        const auto end = s.deliveries.begin() + static_cast<std::ptrdiff_t>(std::min(position, s.deliveries.size()));
        const auto parent = std::find_if(s.deliveries.begin(), end, [&](const auto& d) { if (active_source_validation_work) { ++active_source_validation_work->mapping_entries_visited; }
            return d.source_operation == *source.record.corrects; });
        if (parent != end && parent->acknowledged_event != 0U) { corrects = parent->operation; }
        // Immutable terminal ancestors retain the recipient-specific mappings.
        // Bound the walk even when examining untrusted checkpoint material.
        const SourceSubscription* ancestor = &s;
        std::set<std::string> visited{s.grant.id};
        while (!corrects && ancestor->succession) {
            const auto& predecessor_id = ancestor->succession->predecessor_grant;
            check(visited.insert(predecessor_id).second && visited.size() <= kSourceSubscriptionLimit,
                "source succession ancestry cycle or depth limit");
            const auto found = source_subscriptions_.find(predecessor_id);
            check(found != source_subscriptions_.end(), "source succession ancestor absent");
            ancestor = &found->second;
            check(ancestor->acknowledged <= ancestor->deliveries.size(), "source ancestor frontier bound");
            const auto acknowledged_end = ancestor->deliveries.begin() +
                static_cast<std::ptrdiff_t>(ancestor->acknowledged);
            const auto prior = std::find_if(ancestor->deliveries.begin(), acknowledged_end,
                [&](const auto& d) { if (active_source_validation_work) { ++active_source_validation_work->mapping_entries_visited; }
            return d.source_operation == *source.record.corrects; });
            if (prior != acknowledged_end && prior->acknowledged_event != 0U) { corrects = prior->operation; }
        }
        check(corrects.has_value(), "source correction lacks acknowledged mapped parent");
        }
    }
    Bytes payload; datacube::append_text(payload, s.succession ? "NSE2" : "NSE1"); text(payload, s.grant.id);
    digest(payload, s.instance); digest(payload, s.grant.digest); text(payload, s.grant.peer); text(payload, s.grant.generation);
    digest(payload, s.peer_spki); datacube::append_be64(payload, absolute_position + 1U);
    datacube::append_be32(payload, s.grant.author_uid); datacube::append_be64(payload, source.local_authorship->authored_unix_ms);
    digest(payload, source.record_digest); datacube::append_u8(payload, corrects ? 1U : 0U); if (corrects) { digest(payload, *corrects); }
    if (active_source_validation_work) {
        active_source_validation_work->source_payload_bytes_encoded += source.record.payload.size();
    }
    const auto encoded = encode_application_message(source.record); datacube::append_be32(payload, static_cast<std::uint32_t>(encoded.size()));
    datacube::append_octets(payload, encoded);
    if (s.succession) {
        const auto& x = *s.succession;
        text(payload, x.predecessor_grant); text(payload, x.predecessor_lease);
        digest(payload, x.predecessor_instance); digest(payload, x.predecessor_state_digest);
        digest(payload, x.mapping_digest); datacube::append_be64(payload, x.inherited_acknowledged);
    }
    if (payload.size() > kMaximumEvidencePayloadBytes) {
        app_fail("SOURCE_SUBSCRIPTION_ENVELOPE_TOO_LARGE", "whole source plus provenance does not fit one evidence payload; nothing consumed");
    }
    if (active_source_validation_work) { active_source_validation_work->envelope_bytes_constructed += payload.size(); }
    EvidenceRecord record{.operation_id = hash(s.succession ? "NATRAV_OVERLAY_SOURCE_DELIVERY_V2" : "NATRAV_OVERLAY_SOURCE_DELIVERY_V1", payload), .issuer = node_id_,
        .recipient = s.grant.peer, .scope = s.grant.scope, .corrects = corrects, .payload = std::move(payload)};
    validate_evidence_record(record); return record;
}

void NodeState::validate_source_subscription_registry_locked() const {
    check(source_subscriptions_.size() <= kSourceSubscriptionLimit, "subscription registry bound");
    std::map<std::uint32_t, std::size_t> counts;
    std::set<std::string> adopted;
    for (const auto& [id, s] : source_subscriptions_) {
        check(id == s.grant.id && ++counts[s.grant.uid] <= kSourceSubscriptionUidLimit, "subscription owner registry bound");
        if (s.succession) {
            check(adopted.insert(s.succession->predecessor_grant).second,
                "terminal source subscription adopted twice");
        }
    }
}
void NodeState::validate_source_succession_locked(const SourceSubscription& value) const {
    const SourceSubscription* current = &value;
    std::set<std::string> visited{value.grant.id};
    while (current->succession) {
        const auto& x = *current->succession;
        check(current->revision != 1U || (current->transition == "SUCCEED" &&
            current->configuration_event == current->created_event &&
            current->unix_ms == current->created_unix_ms && current->pid == current->created_pid),
            "source initial successor transition provenance");
        check(visited.insert(x.predecessor_grant).second &&
            visited.size() <= kSourceSubscriptionLimit,
            "source succession cycle or retained registry limit");
        const auto found = source_subscriptions_.find(x.predecessor_grant);
        check(found != source_subscriptions_.end(), "source successor predecessor absent");
        const auto& old = found->second;
        check(old.retired && old.termination &&
            (old.termination->kind == "WITHDRAWN" || old.termination->kind == "EXPIRED") &&
            old.acknowledged == old.deliveries.size() && !old.retained_unacknowledged,
            "source succession requires a fully acknowledged terminal finite lease");
        check(!current->remote_admission && !current->grant.lease_generation.empty() &&
            current->grant.lease_generation != old.grant.lease_generation &&
            current->grant.uid == old.grant.uid && current->grant.author_uid == old.grant.author_uid &&
            current->grant.peer == old.grant.peer && current->grant.scope == old.grant.scope &&
            current->grant.generation == old.grant.generation && current->peer_spki == old.peer_spki,
            "source successor cannot reinterpret manager, author, recipient, key or scope");
        check(x.predecessor_lease == old.grant.lease_generation &&
            x.predecessor_instance == old.instance && x.predecessor_revision == old.revision &&
            x.predecessor_state_digest == source_state_digest(old) &&
            x.inherited_acknowledged == source_frontier(old) &&
            x.inherited_acknowledged <= kSourceSubscriptionLimit * kSourceSubscriptionRecordLimit &&
            x.mapping_digest == source_mapping_digest(old) &&
            current->created_event >= old.configuration_event &&
            current->created_unix_ms >= old.unix_ms &&
            source_selection_request_matches(succession_request(*current), old,
                x.creation_request_digest),
            "source successor predecessor/frontier commitment mismatch");
        for (const auto& [id, other] : source_subscriptions_) {
            check(id == current->grant.id || !other.succession ||
                other.succession->predecessor_grant != x.predecessor_grant,
                "terminal source predecessor already adopted");
        }
        current = &old;
    }
}

std::string NodeState::automatic_source_subscription_block_error_locked(
    const SourceSubscription& value, const RuntimeConfig& config,
    const std::uint64_t configuration_event,
    AutomaticSourceEligibility* eligibility) const {
    if (eligibility) {
        *eligibility = AutomaticSourceEligibility{};
        const auto retained = source_subscriptions_.find(value.grant.id);
        const auto commitment = source_subscription_commitments_.find(
            value.grant.id);
        check(retained != source_subscriptions_.end() &&
            &retained->second == &value &&
            commitment != source_subscription_commitments_.end() &&
            configuration_event != 0U &&
            configuration_event == active_configuration_event(
                configuration_events_),
            "automatic source eligibility requires exact retained predecessor and active configuration");
    }
    if (value.retired) { return "SOURCE_SUBSCRIPTION_RETIRED"; }
    if (source_subscription_lease_expired(value, now_ms())) {
        return "SOURCE_SUBSCRIPTION_LEASE_EXPIRED";
    }
    if (!automatic_enabled(value)) {
        return "SOURCE_SUBSCRIPTION_AUTOMATION_NOT_ENABLED";
    }
    if (!rule_current(value, config)) { return "SOURCE_DISCLOSURE_DENIED"; }
    const auto* peer = find_peer(config, value.grant.peer);
    if (peer == nullptr) { return "SOURCE_SUBSCRIPTION_ROUTE_REMOVED"; }
    const auto* key = find_peer_generation(
        config, value.grant.peer, value.grant.generation);
    if (key == nullptr || key->state != KeyGenerationState::active ||
        key->spki_sha256 != value.peer_spki ||
        peer->active_generation != value.grant.generation ||
        peer->active_spki_sha256 != value.peer_spki) {
        return "SOURCE_SUBSCRIPTION_KEY_INACTIVE";
    }
    if (value.deliveries.size() != value.acknowledged) {
        const auto found = outbound_index_.find(
            operation_id_text(value.deliveries.back().operation));
        if (found == outbound_index_.end()) {
            return "SOURCE_SUBSCRIPTION_HEAD_MISSING";
        }
        const auto& outbound = outbound_[found->second];
        if (outbound.receipt) { return {}; }
        if (active_outbound_rejection(outbound)) {
            return "SOURCE_SUBSCRIPTION_DELIVERY_REJECTED";
        }
        if (outbound.delivery && outbound.delivery->cancelled_unix_ms) {
            return "SOURCE_SUBSCRIPTION_DELIVERY_CANCELLED";
        }
        if (outbound.delivery && outbound.delivery->expired_unix_ms) {
            return "SOURCE_SUBSCRIPTION_DELIVERY_EXPIRED";
        }
        return {};
    }
    if (value.deliveries.size() >= value.grant.maximum_records) {
        return "SOURCE_SUBSCRIPTION_RECORD_BUDGET_EXHAUSTED";
    }
    const auto domain = authored_source_index_.find(
        {value.grant.author_uid, value.grant.scope});
    const auto absolute = source_frontier(value);
    if (domain == authored_source_index_.end() ||
        absolute >= domain->second.size()) {
        return {};
    }
    const auto input = domain->second.at(static_cast<std::size_t>(absolute));
    const auto& source = inbound_.at(input);
    if (source.record.payload.size() >
        value.grant.maximum_payload_bytes - value.used_payload_bytes) {
        return "SOURCE_SUBSCRIPTION_BYTE_BUDGET_EXHAUSTED";
    }
    std::optional<EvidenceRecord> record;
    try {
        record.emplace(source_subscription_record_locked(
            value, value.deliveries.size(), true));
    } catch (const AppError& error) {
        if (error.code() == "SOURCE_SUBSCRIPTION_ENVELOPE_TOO_LARGE") {
            return error.code();
        }
        throw;
    }
    if (eligibility) {
        const auto commitment = source_subscription_commitments_.find(
            value.grant.id);
        check(commitment != source_subscription_commitments_.end() &&
            source.local_authorship &&
            source.record.payload.size() <=
                std::numeric_limits<std::uint32_t>::max(),
            "automatic source eligibility selected input invalid");
        *eligibility = AutomaticSourceEligibility{
            .available = true,
            .owner = this,
            .predecessor = &value,
            .grant = value.grant.id,
            .instance = value.instance,
            .revision = value.revision,
            .commitment = commitment->second.root,
            .configuration_event = configuration_event,
            .configuration_digest = configuration_events_.at(
                static_cast<std::size_t>(configuration_event - 1U)).digest,
            .position = value.deliveries.size(),
            .inbound_position = input,
            .source_record_digest = source.record_digest,
            .authorship = *source.local_authorship,
            .source_operation = source.record.operation_id,
            .source_payload_bytes = static_cast<std::uint32_t>(
                source.record.payload.size()),
            .envelope_digest = evidence_record_digest(*record),
            .record = std::move(*record),
        };
        if (active_source_validation_work) {
            ++active_source_validation_work->automatic_eligibility_candidates;
            ++active_source_validation_work->automatic_eligibility_source_reconstructions;
            active_source_validation_work->automatic_eligibility_envelope_bytes +=
                eligibility->record.payload.size();
        }
    }
    return {};
}
void NodeState::validate_source_subscription_locked(const SourceSubscription& s, const std::optional<EvidenceRecord>& candidate) const {
    if (active_source_validation_work) { ++active_source_validation_work->full_validations; }
    SourceConfigurationScope configurations(configuration_events_);
    if (s.reconciliation) {
        check(!candidate, "reconciliation cannot enqueue evidence");
        const auto old = before_reconciliation(s);
        const auto& x = *s.reconciliation;
        check(old.revision + 1U == s.revision && old.pid != 0U && s.pid != 0U &&
            s.configuration_event >= old.configuration_event && s.unix_ms >= old.unix_ms &&
            reason_ok(s.reason) && !automatic_enabled(s) &&
            source_state_digest(old) == x.preceding_state_digest &&
            terminal_digest(*old.termination) == x.terminal_digest &&
            old.deliveries.back().source_operation == x.source_operation &&
            old.deliveries.back().operation == x.delivery_operation,
            "receipt reconciliation prior-state or source binding mismatch");
        validate_source_subscription_locked(old, std::nullopt);
        const auto& active = configurations.get(s.configuration_event);
        const auto* key = find_peer_generation(active, s.grant.peer, s.grant.generation);
        check(rule_current(s, active) && key && key->spki_sha256 == s.peer_spki &&
            key->state != KeyGenerationState::revoked,
            "receipt reconciliation current manager or key authority missing");
        const auto found = outbound_index_.find(operation_id_text(x.delivery_operation));
        check(found != outbound_index_.end(), "receipt reconciliation outbox missing");
        const auto& queued = outbound_[found->second];
        check(queued.receipt && queued.delivery &&
            queued.delivery->policy.peer_generation == s.grant.generation &&
            queued.delivery->policy.peer_spki_sha256 == s.peer_spki &&
            queued.receipt->operation_id == x.delivery_operation &&
            queued.receipt->recipient == s.grant.peer && queued.receipt->recorder == s.grant.peer &&
            queued.receipt->record_digest == s.deliveries.back().record_digest &&
            receipt_digest(*queued.receipt) == x.receipt_digest,
            "receipt reconciliation requires the exact durable recipient receipt");
        check(source_selection_request_matches(reconciliation_request(s), old, s.request_digest),
            "receipt reconciliation request commitment mismatch");
        auto expected = copy_subscription(old);
        expected.revision = s.revision; expected.transition = s.transition;
        expected.configuration_event = s.configuration_event; expected.unix_ms = s.unix_ms;
        expected.pid = s.pid; expected.reason = s.reason; expected.request_digest = s.request_digest;
        expected.reconciliation = s.reconciliation; adopt_receipt(expected);
        check(expected == s, "receipt reconciliation changed unrelated state");
        return;
    }
    check(s.transition != "RECONCILE_RECEIPT", "receipt reconciliation provenance missing");
    validate_grant(s.grant);
    validate_source_succession_locked(s);
    const bool remote_created = s.remote_admission.has_value();
    const bool remote_creation_transition =
        s.transition == "REMOTE_REQUEST";
    const bool remote_withdrawal_transition =
        s.transition == "REMOTE_WITHDRAW";
    const bool lease_expiry_transition =
        s.transition == "LEASE_EXPIRE";
    const bool leased = source_subscription_is_leased(s);
    check(s.instance == instance_id(node_id_, s.grant) && !digest_is_zero(s.peer_spki) && s.grant.peer != node_id_ &&
        reason_ok(s.creation_reason) && s.created_unix_ms != 0U &&
        (remote_created ? s.created_pid == 0U : s.created_pid != 0U) &&
        (remote_creation_transition ? s.pid == 0U : s.pid != 0U) &&
        s.unix_ms >= s.created_unix_ms && s.created_event <= s.configuration_event &&
        s.acknowledged <= s.deliveries.size() && s.deliveries.size() - s.acknowledged <= 1U &&
        s.deliveries.size() <= s.grant.maximum_records &&
        s.automatic_grants.size() <= kSourceSubscriptionAutomaticGrantLimit &&
        s.revision == source_revision_expected(s) &&
        s.automatic_schedule_revision == automatic_schedule_revision(s),
        "source subscription structural invariant");
    if (leased) {
        check(s.lease_started_unix_ms == s.created_unix_ms &&
            s.grant.lease_duration_ms <=
                std::numeric_limits<std::uint64_t>::max() - s.lease_started_unix_ms &&
            s.lease_expires_unix_ms ==
                s.lease_started_unix_ms + s.grant.lease_duration_ms,
            "source lease lifetime binding");
    } else {
        check(s.lease_started_unix_ms == 0U && s.lease_expires_unix_ms == 0U &&
            !s.termination, "legacy source subscription carries lease state");
    }
    if (s.termination) {
        const auto& terminal = *s.termination;
        check(leased && s.retired &&
            (terminal.kind == "WITHDRAWN" || terminal.kind == "EXPIRED") &&
            terminal.lease_generation == s.grant.lease_generation &&
            terminal.configuration_event == s.configuration_event &&
            terminal.unix_ms == s.unix_ms && reason_ok(terminal.reason) &&
            (terminal.pending_disposition == "NONE" ||
             terminal.pending_disposition == "RETAIN" ||
             terminal.pending_disposition == "CANCEL") &&
            (terminal.pending_disposition == "CANCEL") ==
                terminal.cancelled_operation.has_value(),
            "source terminal lease account");
        if (terminal.kind == "WITHDRAWN") {
            check(remote_withdrawal_transition && remote_created &&
                terminal.actor_peer == s.grant.peer &&
                terminal.actor_generation == s.grant.generation &&
                terminal.actor_spki == s.peer_spki && terminal.request_id &&
                !digest_is_zero(terminal.request_digest),
                "remote withdrawal actor binding");
        } else {
            check(lease_expiry_transition && terminal.actor_peer == node_id_ &&
                terminal.actor_generation.empty() &&
                digest_is_zero(terminal.actor_spki) && !terminal.request_id &&
                digest_is_zero(terminal.request_digest) &&
                s.unix_ms >= s.lease_expires_unix_ms,
                "lease expiry actor or time binding");
        }
    } else {
        check(!remote_withdrawal_transition && !lease_expiry_transition,
            "leased terminal transition lacks terminal account");
    }
    std::map<std::uint64_t, std::uint64_t> automatic_steps;
    for (const auto& delivery : s.deliveries) {
        if (delivery.issue_automatic_generation != 0U) {
            ++automatic_steps[delivery.issue_automatic_generation];
        }
        if (delivery.acknowledge_automatic_generation != 0U) {
            ++automatic_steps[delivery.acknowledge_automatic_generation];
        }
    }
    bool seen_enabled = false;
    for (std::size_t i = 0U; i < s.automatic_grants.size(); ++i) {
        const auto& grant = s.automatic_grants[i];
        const bool enabled = grant.state == "ENABLED";
        check(grant.generation == i + 1U &&
            grant.observed_subscription_revision != 0U &&
            grant.observed_subscription_revision < s.revision &&
            grant.configuration_event != 0U && grant.configuration_event <= s.configuration_event &&
            grant.unix_ms >= s.created_unix_ms && grant.unix_ms <= s.unix_ms &&
            grant.actor_uid == s.grant.uid && grant.pid != 0U &&
            grant.maximum_steps >= 1U && grant.maximum_steps <= 10'000U &&
            grant.minimum_interval_ms >= 10U && grant.minimum_interval_ms <= 60'000U &&
            grant.disclosure_digest == s.grant.digest && reason_ok(grant.reason) &&
            grant.start_issued <= s.deliveries.size() &&
            grant.start_acknowledged <= s.acknowledged &&
            grant.start_acknowledged <= grant.start_issued &&
            grant.steps == automatic_steps[grant.generation] &&
            grant.steps <= grant.maximum_steps &&
            (enabled || automatic_terminal_state(grant.state)),
            "source automatic grant invariant");
        if (enabled) {
            check(!seen_enabled && i + 1U == s.automatic_grants.size() && !s.retired &&
                grant.error.empty() && grant.end_reason.empty() &&
                grant.ended_event == 0U && grant.ended_unix_ms == 0U &&
                grant.ended_uid == 0U && grant.ended_pid == 0U &&
                grant.steps < grant.maximum_steps,
                "enabled source automation grant invariant");
            seen_enabled = true;
        } else {
            check(grant.ended_event >= grant.configuration_event &&
                grant.ended_event <= s.configuration_event &&
                grant.ended_unix_ms >= grant.unix_ms &&
                grant.ended_unix_ms <= s.unix_ms &&
                grant.ended_pid != 0U &&
                !grant.error.empty() && !grant.end_reason.empty(),
                "terminal source automation grant invariant");
            if (grant.state == "EXHAUSTED") {
                check(grant.steps == grant.maximum_steps,
                    "exhausted source automation grant allowance");
            }
            check(i + 1U == s.automatic_grants.size() ||
                grant.state != "ENABLED", "historical source automation grant state");
        }
        if (grant.steps == 0U) {
            check(grant.last_step_event == 0U && grant.last_step_unix_ms == 0U &&
                grant.last_executor_uid == 0U && grant.last_executor_pid == 0U,
                "unused source automation grant executor account");
        } else {
            check(grant.last_step_event >= grant.configuration_event &&
                grant.last_step_event <= s.configuration_event &&
                grant.last_step_unix_ms >= grant.unix_ms &&
                grant.last_step_unix_ms <= s.unix_ms &&
                grant.last_executor_pid != 0U,
                "source automation executor account");
        }
    }
    const auto& created = configurations.get(s.created_event);
    check(rule_current(s, created), "source creation lacks historical disclosure authority");
    const auto* key = find_peer_generation(created, s.grant.peer, s.grant.generation);
    check(key && key->state == KeyGenerationState::active && key->spki_sha256 == s.peer_spki && find_peer(created, s.grant.peer),
        "source creation key or route invalid");
    if (remote_created) {
        const auto& remote = *s.remote_admission;
        check(!digest_is_zero(remote.request_id) &&
            remote.peer == s.grant.peer &&
            remote.generation == s.grant.generation &&
            remote.peer_spki == s.peer_spki &&
            remote.configuration_event == s.created_event &&
            remote.unix_ms == s.created_unix_ms &&
            remote.reason == s.creation_reason,
            "remote source request actor or creation binding mismatch");
        RemoteSourceSubscriptionRequest accepted{
            .request_id = remote.request_id,
            .command = RemoteSourceSubscriptionCommand::request,
            .grant = s.grant.id,
            .lease_generation = s.grant.lease_generation,
            .instance = std::nullopt,
            .expected_revision = 0U,
            .reason = remote.reason,
        };
        check(remote.request_digest == remote_request_digest(accepted),
            "remote source request commitment mismatch");
    }
    const auto& latest = configurations.get(s.configuration_event);
    const bool automatic_block = s.transition == "AUTO_BLOCK";
    const bool scheduled_command = s.transition == "AUTO_ENABLE" ||
        s.transition == "AUTO_PAUSE";
    const bool automatic_progress = s.transition == "AUTO_ISSUE" ||
        s.transition == "AUTO_ACK";
    check(automatic_block || lease_expiry_transition ||
        local_control_allows(latest.local_control,
            s.grant.uid, LocalControlClass::source_disclose),
        "source transition owner authority absent");
    check(s.retired ?
        (s.transition == "RETIRE" || remote_withdrawal_transition ||
            lease_expiry_transition) :
        (automatic_block || rule_current(s, latest)),
        "source transition grant absent");
    check(s.retired ? reason_ok(s.reason) :
        ((s.transition == "CREATE" || s.transition == "SUCCEED" || remote_creation_transition) ?
            s.reason == s.creation_reason :
            (scheduled_command ? reason_ok(s.reason) : s.reason.empty())),
        "source transition reason");
    check(!automatic_progress || automatic_enabled(s) ||
        (!s.automatic_grants.empty() &&
            s.automatic_grants.back().state == "EXHAUSTED"),
        "automatic source progress lacks one current grant");
    check(!remote_creation_transition || (remote_created && s.revision == 1U &&
        s.created_event == s.configuration_event &&
        s.created_unix_ms == s.unix_ms),
        "remote request is valid only as the initial source transition");
    check(s.retained_unacknowledged == (s.retired && s.deliveries.size() != s.acknowledged), "source retirement disposition");
    std::uint64_t used = 0U;
    for (std::size_t i = 0U; i < s.deliveries.size(); ++i) {
        if (active_source_validation_work) { ++active_source_validation_work->delivery_validations; }
        const auto& d = s.deliveries[i]; const auto record = source_subscription_record_locked(s, i);
        const auto source_found = inbound_index_.find(operation_id_text(d.source_operation));
        check(source_found != inbound_index_.end(), "source operation missing");
        const auto& source = inbound_[source_found->second];
        check(record.operation_id == d.operation && evidence_record_digest(record) == d.record_digest &&
            source.local_authorship && source.local_authorship->uid == s.grant.author_uid && source.record.scope == s.grant.scope &&
            source.record.payload.size() == d.payload_bytes && d.pid != 0U && d.unix_ms >= s.created_unix_ms &&
            d.configuration_event >= s.created_event && d.configuration_event <= s.configuration_event,
            "source publication binding");
        if (d.issue_automatic_generation != 0U) {
            check(d.issue_automatic_generation <= s.automatic_grants.size(),
                "source issue automatic generation bound");
            const auto& grant = s.automatic_grants[
                static_cast<std::size_t>(d.issue_automatic_generation - 1U)];
            check(grant.configuration_event <= d.configuration_event &&
                grant.unix_ms <= d.unix_ms,
                "source issue automatic grant provenance");
        }
        const auto& ordered = authored_source_index_.at({s.grant.author_uid, s.grant.scope});
        check(inbound_[ordered[static_cast<std::size_t>(source_base(s)) + i]].record.operation_id == d.source_operation, "source frontier skips an eligible record");
        const auto& issue_config = configurations.get(d.configuration_event);
        check(rule_current(s, issue_config), "source publication lacks disclosure policy");
        const auto expected_policy = policy_for_source(s, issue_config, d.unix_ms);
        const auto found = outbound_index_.find(operation_id_text(d.operation));
        const bool is_candidate = candidate && candidate->operation_id == d.operation;
        if (is_candidate) { check(i + 1U == s.deliveries.size() && *candidate == record && found == outbound_index_.end(), "source candidate binding"); }
        else {
            check(found != outbound_index_.end(), "source outbox obligation missing");
            const auto& queued = outbound_[found->second];
            check(queued.record == record && queued.delivery && queued.delivery->policy == expected_policy,
                "source outbox identity or immutable policy mismatch");
        }
        if (i < s.acknowledged) {
            check(!is_candidate && d.acknowledged_event >= d.configuration_event &&
                d.acknowledged_event <= s.configuration_event && d.acknowledged_unix_ms >= d.unix_ms && d.acknowledged_pid != 0U,
                "source acknowledgment account absent");
            if (active_source_validation_work) { ++active_source_validation_work->receipt_checks; }
            check(outbound_[found->second].receipt.has_value(), "source progress requires durable receipt");
            check(rule_current(s, configurations.get(d.acknowledged_event)), "source ack lacks current disclosure policy");
            if (d.acknowledge_automatic_generation != 0U) {
                check(d.acknowledge_automatic_generation <= s.automatic_grants.size(),
                    "source acknowledgment automatic generation bound");
                const auto& grant = s.automatic_grants[
                    static_cast<std::size_t>(d.acknowledge_automatic_generation - 1U)];
                check(grant.configuration_event <= d.acknowledged_event &&
                    grant.unix_ms <= d.acknowledged_unix_ms,
                    "source acknowledgment automatic grant provenance");
            }
        } else { check(d.acknowledged_event == 0U && d.acknowledged_unix_ms == 0U && d.acknowledged_pid == 0U &&
            d.acknowledge_automatic_generation == 0U, "unacknowledged source has receipt account"); }
        used += d.payload_bytes;
    }
    check(used == s.used_payload_bytes && used <= s.grant.maximum_payload_bytes, "source byte allowance mismatch");
    if (remote_creation_transition) {
        check(s.remote_admission &&
            s.request_digest == s.remote_admission->request_digest,
            "remote creation request commitment mismatch");
    } else if (remote_withdrawal_transition) {
        check(s.termination && s.termination->request_id &&
            s.request_digest == s.termination->request_digest,
            "remote withdrawal request commitment mismatch");
        RemoteSourceSubscriptionRequest withdrawn{
            .request_id = *s.termination->request_id,
            .command = RemoteSourceSubscriptionCommand::withdraw,
            .grant = s.grant.id,
            .lease_generation = s.grant.lease_generation,
            .instance = s.instance,
            .expected_revision = s.revision - 1U,
            .reason = s.reason,
        };
        check(remote_request_digest(withdrawn) == s.request_digest,
            "remote withdrawal request reconstruction mismatch");
    } else if (s.transition == "SUCCEED") {
        check(s.succession && s.revision == 1U &&
            s.request_digest == s.succession->creation_request_digest,
            "source successor request binding");
    } else if (lease_expiry_transition) {
        check(digest_is_zero(s.request_digest),
            "lease expiry cannot impersonate a request");
    } else if (automatic_progress || automatic_block) {
        check(digest_is_zero(s.request_digest),
            "automatic source transition cannot impersonate a control request");
    } else {
        SourceSubscriptionRequest request;
        request.command = s.retired ? SourceSubscriptionCommand::retire :
            (s.transition == "CREATE" ? SourceSubscriptionCommand::create :
             s.transition == "AUTO_ENABLE" ? SourceSubscriptionCommand::automatic_enable :
             s.transition == "AUTO_PAUSE" ? SourceSubscriptionCommand::automatic_pause :
             SourceSubscriptionCommand::step);
        request.grant = s.grant.id;
        if (request.command != SourceSubscriptionCommand::create) { request.instance = s.instance; request.expected_revision = s.revision - 1U; }
        request.retain_pending = s.retained_unacknowledged;
        if (request.command == SourceSubscriptionCommand::automatic_enable ||
            request.command == SourceSubscriptionCommand::automatic_pause) {
            request.expected_schedule_revision = s.automatic_schedule_revision - 1U;
            request.expected_grant_generation = request.command == SourceSubscriptionCommand::automatic_enable ?
                s.automatic_grants.size() - 1U : s.automatic_grants.size();
            if (request.command == SourceSubscriptionCommand::automatic_enable) {
                const auto& grant = s.automatic_grants.back();
                request.automatic_maximum_steps = grant.maximum_steps;
                request.automatic_minimum_interval_ms = grant.minimum_interval_ms;
            }
        }
        if (request.command == SourceSubscriptionCommand::create ||
            request.command == SourceSubscriptionCommand::retire || scheduled_command) { request.reason = s.reason; }
        check(request_digest(request) == s.request_digest, "source request commitment mismatch");
    }
}

void NodeState::validate_source_subscriptions_locked() const {
    SourceConfigurationScope configurations(configuration_events_);
    for (const auto& [id, subscription] : source_subscriptions_) {
        static_cast<void>(id);
        validate_source_subscription_locked(subscription);
    }
}

// Inductive semantic validation for the four progress transitions. apply_source_subscription
// has already constructed expected from the validated map entry and compared EVERY
// field with next. Thus old deliveries, grants, authorship and immutable ancestry
// cannot change here; only the appended issue or acknowledged head needs source work.
// Full validation is still mandatory for creation, succession, reconciliation,
// termination, scheduling changes, and all checkpoint imports. Journal replay takes
// this same checked path, never a "trusted bytes" or skip-validation path.
void NodeState::validate_source_subscription_progress_locked(
    const SourceSubscription& old, const SourceSubscription& next,
    const std::optional<EvidenceRecord>& candidate, const RuntimeConfig& latest) const {
    if (active_source_validation_work) { ++active_source_validation_work->delta_validations; }
    const bool issue = next.transition == "ISSUE" || next.transition == "AUTO_ISSUE";
    const bool automatic = next.transition == "AUTO_ISSUE" || next.transition == "AUTO_ACK";
    check(!old.retired && !old.reconciliation && !next.termination && !next.reconciliation &&
        next.pid != 0U && next.reason.empty() &&
        next.acknowledged <= next.deliveries.size() &&
        next.deliveries.size() - next.acknowledged <= 1U &&
        next.deliveries.size() <= next.grant.maximum_records &&
        next.used_payload_bytes <= next.grant.maximum_payload_bytes &&
        next.revision == source_revision_expected(next) &&
        next.automatic_schedule_revision == automatic_schedule_revision(next),
        "source progress structural invariant");
    check(rule_current(next, latest), "source progress lacks current disclosure authority");
    if (automatic) {
        check(!next.automatic_grants.empty() &&
            (automatic_enabled(next) || next.automatic_grants.back().state == "EXHAUSTED"),
            "automatic source progress grant missing");
        const auto& grant = next.automatic_grants.back();
        check(grant.steps <= grant.maximum_steps && next.unix_ms >= grant.unix_ms &&
            next.configuration_event >= grant.configuration_event &&
            grant.last_executor_pid == next.pid,
            "automatic source progress exceeds grant or regresses provenance");
        check(digest_is_zero(next.request_digest),
            "automatic source progress cannot impersonate a local request");
    } else {
        SourceSubscriptionRequest request;
        request.command = SourceSubscriptionCommand::step;
        request.grant = next.grant.id; request.instance = next.instance;
        request.expected_revision = old.revision;
        check(request_digest(request) == next.request_digest,
            "source progress request commitment mismatch");
    }
    check(!next.deliveries.empty(), "source progress has no changed delivery");
    const auto& d = next.deliveries.back();
    if (active_source_validation_work) { ++active_source_validation_work->delivery_validations; }
    if (issue) {
        const auto position = old.deliveries.size();
        const auto record = source_subscription_record_locked(next, position);
        const auto found = inbound_index_.find(operation_id_text(d.source_operation));
        check(found != inbound_index_.end(), "source progress operation missing");
        const auto& source = inbound_.at(found->second);
        const auto& ordered = authored_source_index_.at({next.grant.author_uid, next.grant.scope});
        check(candidate && *candidate == record && record.operation_id == d.operation &&
            evidence_record_digest(record) == d.record_digest &&
            !outbound_index_.contains(operation_id_text(d.operation)) &&
            source.local_authorship && source.local_authorship->uid == next.grant.author_uid &&
            source.record.scope == next.grant.scope &&
            source.record.payload.size() == d.payload_bytes &&
            inbound_.at(ordered.at(static_cast<std::size_t>(source_base(next)) + position)).record.operation_id == d.source_operation &&
            d.acknowledged_event == 0U && d.acknowledged_unix_ms == 0U &&
            d.acknowledged_pid == 0U && d.acknowledge_automatic_generation == 0U,
            "source changed issuance binding mismatch");
    } else {
        check(!candidate && old.deliveries.size() == old.acknowledged + 1U,
            "source acknowledgment must select its outstanding head");
        const auto found = outbound_index_.find(operation_id_text(d.operation));
        check(found != outbound_index_.end(), "source acknowledgment outbox absent");
        const auto& queued = outbound_.at(found->second);
        if (active_source_validation_work) { ++active_source_validation_work->receipt_checks; }
        check(queued.receipt.has_value(), "source acknowledgment requires durable receipt");
        const auto& receipt = *queued.receipt;
        check(queued.record_digest == d.record_digest && queued.delivery &&
            queued.delivery->policy.peer_generation == next.grant.generation &&
            queued.delivery->policy.peer_spki_sha256 == next.peer_spki &&
            receipt.operation_id == d.operation && receipt.record_digest == d.record_digest &&
            receipt.recipient == next.grant.peer && receipt.recorder == next.grant.peer &&
            d.acknowledged_event >= d.configuration_event &&
            d.acknowledged_unix_ms >= d.unix_ms && d.acknowledged_pid != 0U,
            "source acknowledgment receipt or provenance binding mismatch");
    }
}

SourceSubscriptionIndex NodeState::build_source_subscription_index_locked(
    const SourceSubscription& value) const {
    if (active_source_validation_work) { ++active_source_validation_work->mapping_index_full_rebuilds; }
    SourceSubscriptionIndex result;
    result.instance = value.instance;
    result.frontier = source_frontier(value);
    result.mapping = source_mapping_digest(value);
    const SourceSubscription* current = &value;
    std::set<std::string> visited;
    for (;;) {
        check(visited.insert(current->grant.id).second && visited.size() <= kSourceSubscriptionLimit,
            "source ancestry index cycle or depth limit");
        check(current->acknowledged <= current->deliveries.size(), "source ancestry index frontier bound");
        for (std::size_t index = 0U; index < static_cast<std::size_t>(current->acknowledged); ++index) {
            const auto& entry = current->deliveries[index];
            check(entry.acknowledged_event != 0U, "source ancestry index requires acknowledged delivery");
            check(result.ancestry.emplace(entry.source_operation.octets,
                SourceAncestryReference{current->grant.id, current->instance, index}).second,
                "duplicate source ancestry index entry");
            if (active_source_validation_work) { ++active_source_validation_work->mapping_index_entries_rebuilt; }
        }
        if (!current->succession) { break; }
        const auto& selected = *current->succession;
        const auto found = source_subscriptions_.find(selected.predecessor_grant);
        check(found != source_subscriptions_.end() && found->second.instance == selected.predecessor_instance,
            "source ancestry index predecessor absent");
        current = &found->second;
    }
    check(result.ancestry.size() == result.frontier &&
        result.ancestry.size() <= kSourceSubscriptionLimit * kSourceSubscriptionRecordLimit,
        "source ancestry index count mismatch");
    return result;
}
void NodeState::acknowledge_source_subscription_index_locked(const SourceSubscription& value) {
    const auto found = source_subscription_indexes_.find(value.grant.id);
    check(found != source_subscription_indexes_.end(), "source acknowledgment index absent");
    auto& index = found->second;
    check(index.instance == value.instance && value.acknowledged != 0U &&
        value.acknowledged == value.deliveries.size() && index.frontier + 1U == source_frontier(value),
        "source acknowledgment index boundary mismatch");
    const auto& head = value.deliveries.back();
    check(head.acknowledged_event != 0U && index.ancestry.emplace(head.source_operation.octets,
        SourceAncestryReference{value.grant.id, value.instance, value.deliveries.size() - 1U}).second,
        "source acknowledgment index append mismatch");
    ++index.frontier;
    index.mapping = source_mapping_append(index.mapping, index.frontier, head);
    check(index.ancestry.size() == index.frontier, "source acknowledgment index count mismatch");
}
void NodeState::rebuild_source_subscription_commitments_locked() {
    source_subscription_commitments_.clear();
    source_subscription_indexes_.clear();
    for (const auto& [id, value] : source_subscriptions_) {
        const auto inserted = source_subscription_commitments_.emplace(
            id, source_progress_commitment(value));
        check(inserted.second, "duplicate source progress commitment");
        check(source_subscription_indexes_.emplace(id, build_source_subscription_index_locked(value)).second,
            "duplicate source ancestry index");
    }
    check(source_subscription_commitments_.size() == source_subscriptions_.size(),
        "source progress commitment registry mismatch");
}

NodeState::SourceProgressPreparation NodeState::prepare_source_progress_locked(
    const SourceSubscription& old, const std::uint64_t event,
    const std::uint64_t at, const bool issue,
    AutomaticSourceEligibility* eligibility) const {
    const auto retained = source_subscriptions_.find(old.grant.id);
    const auto commitment = source_subscription_commitments_.find(old.grant.id);
    check(retained != source_subscriptions_.end() && &retained->second == &old &&
        commitment != source_subscription_commitments_.end() &&
        event != 0U && event == active_configuration_event(configuration_events_),
        "source preparation requires exact retained predecessor and active configuration");
    check(!eligibility || issue,
        "automatic source eligibility cannot prepare acknowledgment");
    SourceProgressPreparation prepared{
        this, &old, old.grant.id, old.instance, old.revision,
        commitment->second.root, event,
        configuration_events_.at(static_cast<std::size_t>(event - 1U)).digest,
        at, event_config(configuration_events_, event), std::nullopt};
    check(rule_current(old, prepared.configuration),
        "source preparation lacks current disclosure authority");
    if (active_source_validation_work) {
        ++active_source_validation_work->preparations_created;
    }
    if (issue) {
        const auto position = old.deliveries.size();
        const auto domain = authored_source_index_.find({old.grant.author_uid, old.grant.scope});
        const auto absolute = source_base(old) + position;
        check(old.acknowledged == position && domain != authored_source_index_.end() &&
            absolute < domain->second.size(), "source preparation frontier missing");
        const auto input = domain->second.at(static_cast<std::size_t>(absolute));
        const auto& source = inbound_.at(input);
        auto policy = policy_for_source(old, prepared.configuration, at);
        EvidenceRecord record;
        if (eligibility) {
            check(eligibility->available && eligibility->owner == this &&
                eligibility->predecessor == &old &&
                eligibility->grant == old.grant.id &&
                eligibility->instance == old.instance &&
                eligibility->revision == old.revision &&
                eligibility->commitment == commitment->second.root &&
                eligibility->configuration_event == event &&
                eligibility->configuration_digest == prepared.configuration_digest &&
                eligibility->position == position &&
                eligibility->inbound_position == input &&
                eligibility->source_record_digest == source.record_digest &&
                evidence_record_digest(source.record) == source.record_digest &&
                source.local_authorship &&
                eligibility->authorship == *source.local_authorship &&
                eligibility->source_operation == source.record.operation_id &&
                eligibility->source_payload_bytes == source.record.payload.size() &&
                eligibility->record.issuer == node_id_ &&
                eligibility->record.recipient == old.grant.peer &&
                eligibility->record.scope == old.grant.scope &&
                eligibility->record.corrects.has_value() ==
                    source.record.corrects.has_value() &&
                eligibility->record.operation_id == hash(
                    old.succession ? "NATRAV_OVERLAY_SOURCE_DELIVERY_V2" :
                                     "NATRAV_OVERLAY_SOURCE_DELIVERY_V1",
                    eligibility->record.payload) &&
                eligibility->envelope_digest ==
                    evidence_record_digest(eligibility->record),
                "automatic source eligibility boundary changed");
            record = std::move(eligibility->record);
            eligibility->available = false;
            if (active_source_validation_work) {
                ++active_source_validation_work->automatic_eligibility_reuses;
                ++active_source_validation_work->automatic_eligibility_binding_checks;
            }
        } else {
            record = source_subscription_record_locked(old, position, true);
            if (active_source_validation_work) {
                ++active_source_validation_work->preparation_source_reconstructions;
            }
        }
        validate_new_outbound_locked(record, policy);
        // Eligibility and direct reconstruction both retain exact local
        // authorship; semantic preflight and application recheck this binding.
        prepared.issue.emplace(SourceProgressPreparation::Issue{
            position, input, source.record_digest, *source.local_authorship,
            std::move(record), std::move(policy)});
        if (active_source_validation_work) {
            active_source_validation_work->preparation_envelope_bytes +=
                prepared.issue->record.payload.size();
        }
    }
    return prepared;
}
void NodeState::apply_source_subscription_progress(
    const View bytes, const bool replaying, const bool validate_only,
    const SourceProgressPreparation* prepared, const ParsedSourceProgress* parsed) {
    check(!replaying || (!prepared && !parsed),
        "source preparation cannot enter replay");
    std::optional<SourceProgressTransaction> independent_transaction;
    if (parsed) {
        validate_parsed_source_progress_locked(bytes, *parsed, validate_only);
        if (active_source_validation_work) {
            if (validate_only) { ++active_source_validation_work->preflight_transaction_uses; }
            else { ++active_source_validation_work->application_transaction_uses; }
        }
    } else {
        independent_transaction.emplace(decode_source_progress_transaction(bytes));
        if (active_source_validation_work) {
            if (replaying) { ++active_source_validation_work->replay_progress_decodes; }
            else if (validate_only) { ++active_source_validation_work->preflight_progress_decodes; }
            else { ++active_source_validation_work->application_progress_decodes; }
        }
    }
    const auto& progress = parsed ? parsed->transaction : *independent_transaction;
    const auto found = source_subscriptions_.find(progress.grant);
    check(found != source_subscriptions_.end(),
        "source progress predecessor absent");
    const auto commitment_found = source_subscription_commitments_.find(progress.grant);
    check(commitment_found != source_subscription_commitments_.end(),
        "source progress predecessor commitment absent");
    const auto& old = found->second;
    const auto& predecessor = commitment_found->second;
    check(old.grant.id == progress.grant && old.instance == progress.instance &&
        old.revision == progress.preceding_revision &&
        predecessor.base == source_progress_base_commitment(old) &&
        predecessor.root == source_progress_root(old, predecessor) &&
        predecessor.root == progress.preceding_commitment,
        "source progress predecessor commitment mismatch");
    check(!old.retired && !old.termination && !old.reconciliation &&
        old.acknowledged <= old.deliveries.size() &&
        old.deliveries.size() - old.acknowledged <= 1U &&
        old.deliveries.size() <= old.grant.maximum_records &&
        old.used_payload_bytes <= old.grant.maximum_payload_bytes &&
        progress.configuration_event >= old.configuration_event &&
        progress.unix_ms >= old.unix_ms,
        "source progress predecessor or provenance invalid");

    check(progress.configuration_event ==
            active_configuration_event(configuration_events_),
        "source progress configuration is not active at commit");
    // Replay never accepts a preparation, even a perfectly matching one.
    // A live preparation must still name this exact state owner, predecessor,
    // accepted event, timestamp and transition shape on every use.
    if (prepared) {
        check(!replaying && prepared->owner == this && prepared->predecessor == &old &&
            prepared->grant == old.grant.id && prepared->instance == old.instance &&
            prepared->revision == old.revision && prepared->commitment == predecessor.root &&
            prepared->configuration_event == progress.configuration_event &&
            prepared->configuration_digest == configuration_events_.at(
                static_cast<std::size_t>(progress.configuration_event - 1U)).digest &&
            prepared->unix_ms == progress.unix_ms &&
            prepared->issue.has_value() == source_progress_issue(progress.kind),
            "source preparation boundary mismatch");
        if (active_source_validation_work) {
            if (validate_only) { ++active_source_validation_work->preflight_preparation_uses; }
            else { ++active_source_validation_work->application_preparation_uses; }
        }
    }
    // The optional object owns independently parsed replay policy. A private
    // preparation instead owns the same parser's result for this live command.
    std::optional<RuntimeConfig> independent_configuration;
    if (!prepared) {
        independent_configuration.emplace(event_config(
            configuration_events_, progress.configuration_event));
    }
    const auto& latest = prepared ? prepared->configuration : *independent_configuration;
    check(rule_current(old, latest),
        "source progress lacks current disclosure authority");
    const bool issue = source_progress_issue(progress.kind);
    const bool automatic = source_progress_automatic(progress.kind);
#ifndef NATRAV_SOURCE_SUBSCRIPTION_FORCE_FULL
    if (active_source_validation_work) {
        ++active_source_validation_work->delta_validations;
    }
#endif

    if (automatic) {
        check(automatic_enabled(old) && !old.automatic_grants.empty(),
            "automatic source progress grant missing");
        const auto& grant = old.automatic_grants.back();
        check(grant.generation == progress.automatic_generation &&
            grant.steps < grant.maximum_steps &&
            progress.automatic_steps_after == grant.steps + 1U &&
            progress.automatic_schedule_revision_after ==
                old.automatic_schedule_revision + 1U &&
            progress.automatic_state_after ==
                (progress.automatic_steps_after == grant.maximum_steps ? 2U : 1U),
            "automatic source progress allowance mismatch");
    } else {
        SourceSubscriptionRequest request;
        request.command = SourceSubscriptionCommand::step;
        request.grant = old.grant.id;
        request.instance = old.instance;
        request.expected_revision = old.revision;
        check(request_digest(request) == progress.request_digest,
            "source progress request commitment mismatch");
    }

    if (active_source_validation_work) {
        ++active_source_validation_work->delivery_validations;
    }
    if (issue) {
        check(progress.record.has_value() && progress.policy.has_value() &&
            old.acknowledged == old.deliveries.size() &&
            old.deliveries.size() < old.grant.maximum_records &&
            progress.delivery.payload_bytes <=
                old.grant.maximum_payload_bytes - old.used_payload_bytes,
            "source issuance predecessor or budget invalid");
        const auto position = old.deliveries.size();
        std::optional<EvidenceRecord> reconstructed;
        if (!prepared) {
            reconstructed.emplace(source_subscription_record_locked(old, position, true));
            if (active_source_validation_work) {
                if (replaying) { ++active_source_validation_work->replay_source_reconstructions; }
                else if (validate_only) { ++active_source_validation_work->preflight_source_reconstructions; }
                else { ++active_source_validation_work->application_source_reconstructions; }
            }
        }
        const auto& expected_record = prepared ? prepared->issue->record : *reconstructed;
        const auto domain = authored_source_index_.find(
            {old.grant.author_uid, old.grant.scope});
        const auto absolute = source_base(old) + position;
        check(domain != authored_source_index_.end() &&
            absolute < domain->second.size(),
            "source issuance frontier missing");
        const auto& source = inbound_.at(
            domain->second.at(static_cast<std::size_t>(absolute)));
        const auto expected_policy = policy_for_source(
            old, latest, progress.unix_ms);
        if (prepared) {
            const auto& selected = *prepared->issue;
            check(selected.position == position && selected.inbound_position ==
                    domain->second.at(static_cast<std::size_t>(absolute)) &&
                selected.source_record_digest == source.record_digest &&
                source.local_authorship && selected.authorship == *source.local_authorship &&
                selected.policy == expected_policy,
                "source preparation selected input or policy changed");
            if (active_source_validation_work) {
                ++active_source_validation_work->preparation_source_binding_checks;
            }
        }
        check(*progress.record == expected_record &&
            *progress.policy == expected_policy &&
            progress.delivery.source_operation == source.record.operation_id &&
            progress.delivery.operation == expected_record.operation_id &&
            progress.delivery.record_digest ==
                evidence_record_digest(expected_record) &&
            source.local_authorship &&
            source.local_authorship->uid == old.grant.author_uid &&
            source.record.scope == old.grant.scope &&
            source.record.payload.size() == progress.delivery.payload_bytes,
            "source changed issuance binding mismatch");
        validate_new_outbound_locked(expected_record, expected_policy);
    } else {
        check(!progress.record && !progress.policy && progress.outgoing.empty() &&
            old.deliveries.size() == old.acknowledged + 1U,
            "source acknowledgment must select its outstanding head");
        const auto& head = old.deliveries.back();
        check(progress.delivery.operation == head.operation &&
            progress.delivery.record_digest == head.record_digest,
            "source acknowledgment head mismatch");
        const auto queued_found = outbound_index_.find(
            operation_id_text(head.operation));
        check(queued_found != outbound_index_.end(),
            "source acknowledgment outbox absent");
        const auto& queued = outbound_.at(queued_found->second);
        if (active_source_validation_work) {
            ++active_source_validation_work->receipt_checks;
        }
        check(queued.receipt.has_value() && queued.delivery.has_value(),
            "source acknowledgment requires durable receipt");
        const auto& receipt = *queued.receipt;
        check(queued.record.operation_id == head.operation &&
            queued.record_digest == head.record_digest &&
            queued.delivery->policy.peer_generation == old.grant.generation &&
            queued.delivery->policy.peer_spki_sha256 == old.peer_spki &&
            receipt.operation_id == head.operation &&
            receipt.record_digest == head.record_digest &&
            receipt.recipient == old.grant.peer &&
            receipt.recorder == old.grant.peer &&
            receipt_digest(receipt) == progress.durable_receipt_digest,
            "source acknowledgment receipt or provenance binding mismatch");
    }

#if defined(NATRAV_SOURCE_SUBSCRIPTION_FORCE_FULL) || \
    defined(NATRAV_SOURCE_SUBSCRIPTION_REFERENCE_VALIDATE)
    auto reference = copy_subscription(old);
    apply_source_progress_state(reference, progress);
#ifdef NATRAV_SOURCE_SUBSCRIPTION_FORCE_FULL
    validate_source_subscription_locked(reference, progress.record);
#else
    if (active_source_validation_work) {
        ++active_source_validation_work->reference_validations;
    }
    validate_source_subscription_locked(reference, progress.record);
#endif
#endif
    if (validate_only) { return; }

    const bool previous_binding = applying_runtime_bound_mutation_;
    applying_runtime_bound_mutation_ = true;
    try {
        if (issue) {
#ifdef NATRAV_SOURCE_OUTBOUND_INDEPENDENT_DECODING
            const ParsedSourceProgress* admission = nullptr;
#else
            const auto* admission = parsed;
#endif
            const View outgoing = parsed ? parsed->outgoing_bytes : View(progress.outgoing);
            check(!outgoing.empty(), "source issuance outgoing composite absent");
            apply_outbound_admission_locked(outgoing, replaying, admission);
        }
        applying_runtime_bound_mutation_ = previous_binding;
    } catch (...) {
        applying_runtime_bound_mutation_ = previous_binding;
        throw;
    }

    const auto previous_commitment = predecessor;
    auto& current = found->second;
    apply_source_progress_state(current, progress);
    check(current.revision == source_revision_expected(current) &&
        current.automatic_schedule_revision ==
            automatic_schedule_revision(current) &&
        current.acknowledged <= current.deliveries.size() &&
        current.deliveries.size() - current.acknowledged <= 1U,
        "source progress resulting state invalid");
    commitment_found->second = source_progress_commitment_after(
        current, previous_commitment, issue, automatic);
    if (!issue) { acknowledge_source_subscription_index_locked(current); }
#if defined(NATRAV_SOURCE_SUBSCRIPTION_REFERENCE_VALIDATE) || defined(NATRAV_SOURCE_SUBSCRIPTION_FORCE_FULL)
    check(commitment_found->second == source_progress_commitment(current),
        "incremental source commitment disagrees with full canonical reconstruction");
    check(source_subscription_indexes_.at(current.grant.id) == build_source_subscription_index_locked(current),
        "incremental source ancestry disagrees with full canonical reconstruction");
#endif
    index_outbound_associations(current);
    validate_source_subscription_registry_locked();
}

void NodeState::apply_source_subscription(View bytes, bool replaying, bool validate_only,
    const SourceProgressPreparation* prepared, const ParsedSourceProgress* parsed) {
    if (bytes.size() >= 4U &&
        std::equal(bytes.begin(), bytes.begin() + 4, std::string_view("NST3").begin())) {
        apply_source_subscription_progress(bytes, replaying, validate_only, prepared, parsed);
        return;
    }
    check(prepared == nullptr && parsed == nullptr, "source preparation on complete-state transition");
    datacube::Reader r(bytes, "source subscription transaction");
    const auto version = datacube::octets_text(
        r.read_exact(4U, "source transaction magic"),
        "source transaction magic", true);
    check(version == "NST1" || version == "NST2",
        "source subscription transaction version rejected");
    const auto n = r.read_be32("state length");
    check(n <= kSourceSubscriptionEncodedLimit, "source state envelope bound");
    auto next = decode_source_subscription(r.read_exact(n, "source state"));
    std::optional<EvidenceRecord> record;
    std::optional<OutboundPolicy> policy;
    Bytes outgoing;
    if (boolean(r)) {
        const auto size = r.read_be32("outbox length");
        check(size <= 66'000U, "source composite bound");
        const auto view = r.read_exact(size, "outbox");
        outgoing.assign(view.begin(), view.end());
        auto decoded = read_composite(outgoing);
        record = std::move(decoded.record);
        policy = std::move(decoded.policy);
    }
    std::optional<Bytes> cancellation;
    if (version == "NST2") {
        if (boolean(r)) {
            const auto size = r.read_be32("cancellation length");
            check(size <= 1'024U, "source cancellation bound");
            const auto view = r.read_exact(size, "cancellation");
            cancellation = Bytes(view.begin(), view.end());
        }
    }
    r.require_eof("source transaction");

    const auto before = source_subscriptions_.find(next.grant.id);
    const bool progress = next.transition == "ISSUE" || next.transition == "ACK" ||
        next.transition == "AUTO_ISSUE" || next.transition == "AUTO_ACK";
    // Accepted prior state is reached only through semantic apply or a completely
    // validated checkpoint. No process-local version supplied by a caller is proof.
    std::optional<RuntimeConfig> progress_config;
    if (progress) { progress_config = event_config(configuration_events_, next.configuration_event); }
    if (next.transition == "CREATE" || next.transition == "REMOTE_REQUEST" || next.transition == "SUCCEED") {
        check(before == source_subscriptions_.end() && !record && !cancellation &&
            next.revision == 1U && next.deliveries.empty() && !next.retired &&
            next.created_event == next.configuration_event &&
            next.created_unix_ms == next.unix_ms && next.created_pid == next.pid,
            "source creation invalid");
        check((next.transition == "SUCCEED") == next.succession.has_value(),
            "source creation must declare succession exactly");
        std::size_t count = 0U;
        for (const auto& [id, s] : source_subscriptions_) {
            static_cast<void>(id);
            if (s.grant.uid == next.grant.uid) { ++count; }
        }
        check(source_subscriptions_.size() < kSourceSubscriptionLimit &&
            count < kSourceSubscriptionUidLimit, "source registry exhausted");
    } else {
        check(before != source_subscriptions_.end() &&
            (!before->second.retired || next.transition == "RECONCILE_RECEIPT"),
            "source predecessor absent or retired");
        const auto& old = before->second;
        // Validate vector shape before any .back() used during derivation. This
        // also applies to untrusted sequential replay, not only command inputs.
        check(next.automatic_grants.size() == old.automatic_grants.size() +
            (next.transition == "AUTO_ENABLE" ? 1U : 0U),
            "source automatic grant count transition mismatch");
        auto expected = copy_subscription(old);
        expected.revision++;
        expected.transition = next.transition;
        expected.configuration_event = next.configuration_event;
        expected.unix_ms = next.unix_ms;
        expected.pid = next.pid;
        expected.reason = next.reason;
        expected.request_digest = next.request_digest;
        check(next.configuration_event >= old.configuration_event &&
            next.unix_ms >= old.unix_ms, "source transition time regresses");
        const bool automatic_issue = next.transition == "AUTO_ISSUE";
        const bool automatic_ack = next.transition == "AUTO_ACK";
        if (next.transition == "RECONCILE_RECEIPT") {
            check(!record && !cancellation && old.retired && old.termination && !old.reconciliation &&
                old.deliveries.size() == old.acknowledged + 1U && next.reconciliation,
                "receipt reconciliation needs one terminal unacknowledged head");
            for (const auto& [id, other] : source_subscriptions_) {
                static_cast<void>(id);
                check(!other.succession || other.succession->predecessor_grant != old.grant.id,
                    "receipt reconciliation after successor adoption");
            }
            check(next.reconciliation->preceding_state_digest == source_state_digest(old) &&
                next.reconciliation->preceding_revision == old.revision &&
                next.reconciliation->preceding_pid == old.pid,
                "receipt reconciliation preceding state mismatch");
            expected.reconciliation = next.reconciliation;
            adopt_receipt(expected);
        } else if (next.transition == "ISSUE" || automatic_issue) {
            check(record && policy && !cancellation &&
                old.acknowledged == old.deliveries.size() &&
                next.deliveries.size() == old.deliveries.size() + 1U,
                "source issuance requires acknowledged predecessor and one obligation");
            const auto& d = next.deliveries.back();
            expected.deliveries.push_back(d);
            expected.used_payload_bytes += d.payload_bytes;
            check(d.configuration_event == next.configuration_event &&
                d.unix_ms == next.unix_ms && d.pid == next.pid &&
                *policy == policy_for_source(next,
                    *progress_config,
                    next.unix_ms),
                "source issue policy/provenance mismatch");
            if (automatic_issue) {
                check(automatic_enabled(old) &&
                    d.issue_automatic_generation == old.automatic_grants.back().generation,
                    "automatic source issuance requires the enabled grant");
                expected.automatic_schedule_revision++;
                auto& grant = expected.automatic_grants.back();
                ++grant.steps;
                grant.last_step_event = next.configuration_event;
                grant.last_step_unix_ms = next.unix_ms;
                grant.last_executor_uid = next.automatic_grants.back().last_executor_uid;
                grant.last_executor_pid = next.pid;
                if (grant.steps == grant.maximum_steps) {
                    finish_automatic_grant(grant, expected, "EXHAUSTED",
                        "SOURCE_SUBSCRIPTION_AUTOMATION_BUDGET_EXHAUSTED",
                        "finite automatic source-step allowance consumed",
                        grant.last_executor_uid, next.pid);
                }
            } else {
                check(d.issue_automatic_generation == 0U,
                    "manual source issuance cannot spend automatic allowance");
            }
            validate_new_outbound_locked(*record, *policy);
        } else if (next.transition == "ACK" || automatic_ack) {
            check(!record && !cancellation &&
                old.deliveries.size() == old.acknowledged + 1U &&
                next.deliveries.size() == old.deliveries.size(),
                "source ack requires one outstanding record");
            expected.acknowledged++;
            auto& d = expected.deliveries.back();
            d.acknowledged_event = next.configuration_event;
            d.acknowledged_unix_ms = next.unix_ms;
            d.acknowledged_pid = next.pid;
            d.acknowledge_automatic_generation =
                next.deliveries.back().acknowledge_automatic_generation;
            if (automatic_ack) {
                check(automatic_enabled(old) &&
                    d.acknowledge_automatic_generation ==
                        old.automatic_grants.back().generation,
                    "automatic source acknowledgment requires the enabled grant");
                expected.automatic_schedule_revision++;
                auto& grant = expected.automatic_grants.back();
                ++grant.steps;
                grant.last_step_event = next.configuration_event;
                grant.last_step_unix_ms = next.unix_ms;
                grant.last_executor_uid = next.automatic_grants.back().last_executor_uid;
                grant.last_executor_pid = next.pid;
                if (grant.steps == grant.maximum_steps) {
                    finish_automatic_grant(grant, expected, "EXHAUSTED",
                        "SOURCE_SUBSCRIPTION_AUTOMATION_BUDGET_EXHAUSTED",
                        "finite automatic source-step allowance consumed",
                        grant.last_executor_uid, next.pid);
                }
            } else {
                check(d.acknowledge_automatic_generation == 0U,
                    "manual source acknowledgment cannot spend automatic allowance");
            }
        } else if (next.transition == "AUTO_ENABLE") {
            check(!record && !cancellation && !automatic_enabled(old) &&
                old.automatic_grants.size() < kSourceSubscriptionAutomaticGrantLimit &&
                next.automatic_grants.size() == old.automatic_grants.size() + 1U,
                "automatic source enable transition invalid");
            expected.automatic_schedule_revision++;
            const auto& supplied = next.automatic_grants.back();
            expected.automatic_grants.push_back(SourceSubscriptionAutomaticGrant{
                .generation = old.automatic_grants.size() + 1U,
                .observed_subscription_revision = old.revision,
                .configuration_event = next.configuration_event,
                .unix_ms = next.unix_ms,
                .actor_uid = old.grant.uid,
                .pid = next.pid,
                .maximum_steps = supplied.maximum_steps,
                .minimum_interval_ms = supplied.minimum_interval_ms,
                .disclosure_digest = old.grant.digest,
                .reason = next.reason,
                .start_issued = old.deliveries.size(),
                .start_acknowledged = old.acknowledged,
                .error = {},
                .end_reason = {},
            });
        } else if (next.transition == "AUTO_PAUSE") {
            check(!record && !cancellation && automatic_enabled(old),
                "automatic source pause requires one enabled grant");
            expected.automatic_schedule_revision++;
            finish_automatic_grant(expected.automatic_grants.back(), expected,
                "PAUSED", "SOURCE_SUBSCRIPTION_AUTOMATION_PAUSED", next.reason,
                old.grant.uid, next.pid);
        } else if (next.transition == "AUTO_BLOCK") {
            check(!record && !cancellation && automatic_enabled(old),
                "automatic source block requires one enabled grant");
            const auto active = event_config(
                configuration_events_, next.configuration_event);
            const auto error = automatic_source_subscription_block_error_locked(old, active);
            check(!error.empty() && error == next.automatic_grants.back().error,
                "automatic source block reason is not source-derived");
            expected.automatic_schedule_revision++;
            finish_automatic_grant(expected.automatic_grants.back(), expected,
                "BLOCKED", error, error,
                next.automatic_grants.back().ended_uid, next.pid);
        } else if (next.transition == "RETIRE") {
            check(!record && !cancellation && !next.termination,
                "local source retirement cannot queue evidence, cancellation, or lease termination");
            expected.retired = true;
            expected.retained_unacknowledged =
                old.deliveries.size() != old.acknowledged;
            if (automatic_enabled(old)) {
                expected.automatic_schedule_revision++;
                finish_automatic_grant(expected.automatic_grants.back(), expected,
                    "RETIRED", "SOURCE_SUBSCRIPTION_RETIRED", next.reason,
                    old.grant.uid, next.pid);
            }
        } else if (next.transition == "REMOTE_WITHDRAW" ||
                   next.transition == "LEASE_EXPIRE") {
            check(!record && source_subscription_is_leased(old) &&
                next.retired && next.termination.has_value(),
                "leased terminal transition requires one terminal account");
            const auto& terminal = *next.termination;
            expected.retired = true;
            expected.retained_unacknowledged =
                old.deliveries.size() != old.acknowledged;
            expected.termination = terminal;
            if (automatic_enabled(old)) {
                expected.automatic_schedule_revision++;
                finish_automatic_grant(expected.automatic_grants.back(), expected,
                    "RETIRED",
                    next.transition == "REMOTE_WITHDRAW" ?
                        "SOURCE_SUBSCRIPTION_WITHDRAWN" :
                        "SOURCE_SUBSCRIPTION_LEASE_EXPIRED",
                    next.reason,
                    next.automatic_grants.back().ended_uid,
                    next.pid);
            }
            const bool should_cancel = terminal.pending_disposition == "CANCEL";
            check(cancellation.has_value() == should_cancel,
                "leased terminal cancellation marker mismatch");
            if (terminal.pending_disposition == "RETAIN") {
                check(old.deliveries.size() != old.acknowledged,
                    "retained terminal transition lacks an outstanding delivery");
            } else if (terminal.pending_disposition == "NONE") {
                check(!terminal.cancelled_operation,
                    "empty terminal disposition cannot name cancellation");
            } else {
                check(terminal.pending_disposition == "CANCEL" &&
                    terminal.cancelled_operation.has_value(),
                    "unknown leased terminal pending disposition");
            }
            if (cancellation) {
                check(!old.deliveries.empty() &&
                    terminal.cancelled_operation == old.deliveries.back().operation,
                    "leased terminal cancellation does not name the exact source head");
                const auto found_outbound = outbound_index_.find(
                    operation_id_text(*terminal.cancelled_operation));
                check(found_outbound != outbound_index_.end() &&
                    outbound_is_pending(outbound_[found_outbound->second]) &&
                    outbound_[found_outbound->second].delivery.has_value() &&
                    outbound_[found_outbound->second].delivery->policy.peer_generation.has_value() &&
                    outbound_[found_outbound->second].delivery->policy.peer_spki_sha256.has_value(),
                    "leased terminal cancellation is not pending or key-bound");
                const auto decoded = read_source_cancellation(*cancellation);
                const auto& queued = outbound_[found_outbound->second];
                check(decoded.operation == *terminal.cancelled_operation &&
                    decoded.unix_ms == terminal.unix_ms &&
                    decoded.reason == terminal.reason &&
                    decoded.generation == *queued.delivery->policy.peer_generation &&
                    decoded.spki == *queued.delivery->policy.peer_spki_sha256 &&
                    decoded.actor == (next.transition == "REMOTE_WITHDRAW" ?
                        "REMOTE_SOURCE_SUBSCRIBER" : "SOURCE_SUBSCRIPTION_LEASE"),
                    "leased terminal cancellation binding mismatch");
            }
        } else {
            app_fail("JOURNAL_CORRUPT", "unknown source transition");
        }
        if (active_source_validation_work) {
            active_source_validation_work->compared_delivery_entries += expected.deliveries.size();
        }
        check(expected == next, "source prior-state transition mismatch");
    }
    if (progress) {
        check(before != source_subscriptions_.end() && progress_config.has_value(),
            "source progress requires a validated predecessor");
        check(next.configuration_event ==
                active_configuration_event(configuration_events_),
            "source progress configuration is not active at commit");
#ifndef NATRAV_SOURCE_SUBSCRIPTION_FORCE_FULL
        validate_source_subscription_progress_locked(before->second, next, record, *progress_config);
#ifdef NATRAV_SOURCE_SUBSCRIPTION_REFERENCE_VALIDATE
        if (active_source_validation_work) { ++active_source_validation_work->reference_validations; }
        validate_source_subscription_locked(next, record);
#endif
#else
        // Test-only counterfactual: identical transition derivation, original
        // full-history validator. Never enable in the delivered normal build.
        validate_source_subscription_locked(next, record);
#endif
    } else {
        validate_source_subscription_locked(next, record);
    }
    if (validate_only) { return; }
    const auto next_commitment = source_progress_commitment(next);
    const auto next_id = next.grant.id;
    const bool previous_binding = applying_runtime_bound_mutation_;
    applying_runtime_bound_mutation_ = true;
    try {
        if (record) {
            apply_entry(EntryKind::outbound_queued_with_policy, outgoing, replaying);
        }
        if (cancellation) {
            apply_entry(EntryKind::outbound_cancelled, *cancellation, replaying);
        }
        applying_runtime_bound_mutation_ = previous_binding;
    } catch (...) {
        applying_runtime_bound_mutation_ = previous_binding;
        throw;
    }
    index_outbound_associations(next);
    source_subscriptions_[next_id] = std::move(next);
    source_subscription_commitments_[next_id] = next_commitment;
    source_subscription_indexes_[next_id] = build_source_subscription_index_locked(source_subscriptions_.at(next_id));
    validate_source_subscription_registry_locked();
}
std::string NodeState::source_subscription_command(const SourceSubscriptionRequest& request, const RuntimeConfig& config,
    std::uint32_t uid, std::uint32_t pid, std::uint64_t event, std::uint64_t now) {
    SourceValidationWork work;
    SourceValidationWorkScope work_scope(work);
    static_cast<void>(encode_source_subscription_request(request));
    if (config.format_version < 15U || !local_control_allows(config.local_control, uid, LocalControlClass::source_disclose)) {
        app_fail("SOURCE_DISCLOSURE_DENIED", "explicit current SOURCE_DISCLOSE authority required");
    }
    std::lock_guard<std::mutex> lock(mutex_);
    auto found = source_subscriptions_.find(request.grant);
    const auto* grant = source_disclosure_grant(config.source_disclosure, request.grant);
    const auto observation = [&](const SourceSubscription& value) -> std::string {
        if (value.automatic_grants.empty()) { return "DISABLED"; }
        const auto& automatic = value.automatic_grants.back();
        if (automatic.state != "ENABLED") {
            return automatic.error.empty() ? automatic.state : automatic.error;
        }
        const auto terminal = automatic_source_subscription_block_error_locked(value, config);
        if (!terminal.empty()) { return terminal; }
        if (value.deliveries.size() != value.acknowledged) {
            const auto queued = outbound_index_.find(operation_id_text(value.deliveries.back().operation));
            check(queued != outbound_index_.end(), "source head not queued");
            return outbound_[queued->second].receipt ? "ACK_READY" : "PENDING";
        }
        const auto domain = authored_source_index_.find({value.grant.author_uid, value.grant.scope});
        if (domain == authored_source_index_.end() || source_frontier(value) >= domain->second.size()) {
            return "CAUGHT_UP";
        }
        const auto* peer = find_peer(config, value.grant.peer);
        if (peer == nullptr || std::none_of(peer->routes.begin(), peer->routes.end(), [](const auto& route) {
                return route.state == PeerRouteState::enabled;
            })) {
            return "ROUTE_UNAVAILABLE";
        }
        try {
            const auto policy = policy_for_source(value, config, now);
            const auto record = source_subscription_record_locked(value,
                static_cast<std::size_t>(value.acknowledged), true);
            validate_new_outbound_locked(record, policy);
        } catch (const AppError& error) {
            return error.code();
        }
        return "ELIGIBLE";
    };
    const auto response = [&](const SourceSubscription& value, std::string_view disposition) {
        std::string_view status;
        if (!value.deliveries.empty()) {
            const auto queued = outbound_index_.find(operation_id_text(value.deliveries.back().operation));
            check(queued != outbound_index_.end(), "source head not queued");
            status = outbound_status_name(outbound_[queued->second]);
        }
        const SourceSubscriptionCommitment* compact = nullptr;
        const Digest* mapping = nullptr;
        if (request.compact_response) {
            const auto commitment = source_subscription_commitments_.find(value.grant.id);
            const auto index = source_subscription_indexes_.find(value.grant.id);
            check(commitment != source_subscription_commitments_.end() &&
                index != source_subscription_indexes_.end() && index->second.instance == value.instance &&
                index->second.frontier == source_frontier(value), "compact source response index absent");
            compact = &commitment->second;
            mapping = &index->second.mapping;
            work.response_index_entries = index->second.ancestry.size();
            work.response_index_fixed_bytes = sizeof(SourceSubscriptionIndex) +
                index->second.ancestry.size() * sizeof(decltype(index->second.ancestry)::value_type);
        }
        auto result = source_subscription_json(value, false, status, disposition,
            rule_current(value, config), observation(value), compact, mapping);
        std::string adopted_by = "null";
        for (const auto& [id, candidate] : source_subscriptions_) {
            if (candidate.succession && candidate.succession->predecessor_grant == value.grant.id) {
                adopted_by = json_string(id); break;
            }
        }
        result.pop_back(); result += ",\"adopted_by\":" + adopted_by;
        result += ",\"head_receipt\":";
        if (!value.deliveries.empty()) {
            const auto& queued = outbound_[outbound_index_.at(operation_id_text(value.deliveries.back().operation))];
            if (queued.receipt) {
                const auto& rc = *queued.receipt;
                result += "{\"digest\":" + json_string(datacube::hex_lower(receipt_digest(rc))) +
                    ",\"operation_id\":" + json_string(datacube::hex_lower(rc.operation_id)) +
                    ",\"recipient\":" + json_string(rc.recipient) + ",\"recorder\":" + json_string(rc.recorder) +
                    ",\"sequence\":" + std::to_string(rc.sequence) +
                    ",\"disposition\":" + json_string(receipt_disposition_name(rc.disposition)) +
                    ",\"record_digest\":" + json_string(datacube::hex_lower(rc.record_digest)) + "}";
            } else { result += "null"; }
        } else { result += "null"; }
        if (local_control_allows(config.local_control, uid, LocalControlClass::inspect)) {
            result += ",\"validation_work\":" + source_validation_work_json(work);
        }
        result += "}";
        return result;
    };
    if (found != source_subscriptions_.end() && found->second.grant.uid != uid) {
        app_fail("SOURCE_SUBSCRIPTION_NOT_FOUND", "owner subscription absent");
    }
    if (request.command == SourceSubscriptionCommand::status ||
        request.command == SourceSubscriptionCommand::automatic_status) {
        if (found == source_subscriptions_.end()) {
            app_fail("SOURCE_SUBSCRIPTION_NOT_FOUND", "owner subscription absent");
        }
        return response(found->second,
            request.command == SourceSubscriptionCommand::automatic_status ? "AUTOMATIC_STATUS" : "STATUS");
    }

    if (request.command == SourceSubscriptionCommand::reconcile) {
        if (found == source_subscriptions_.end()) {
            app_fail("SOURCE_SUBSCRIPTION_NOT_FOUND", "owner subscription absent");
        }
        const auto& old = found->second;
        if (!rule_current(old, config)) {
            app_fail("SOURCE_DISCLOSURE_DENIED", "current exact disclosure grant required for reconciliation");
        }
        const auto* key = find_peer_generation(config, old.grant.peer, old.grant.generation);
        if (!key || key->spki_sha256 != old.peer_spki || key->state == KeyGenerationState::revoked) {
            app_fail("SOURCE_RECONCILIATION_KEY_POLICY", "exact retained non-revoked subscriber generation required");
        }
        for (const auto& [id, other] : source_subscriptions_) {
            static_cast<void>(id);
            if (other.succession && other.succession->predecessor_grant == old.grant.id) {
                app_fail("SOURCE_RECONCILIATION_ADOPTED", "predecessor already adopted; historical state is immutable");
            }
        }
        const auto commitment = request_digest(request);
        if (old.reconciliation) {
            if (old.request_digest == commitment) { return response(old, "ALREADY_RECONCILED"); }
            app_fail("SOURCE_RECONCILIATION_CONFLICT", "terminal head already reconciled by a different request");
        }
        if (!old.retired || !old.termination ||
            (old.termination->kind != "WITHDRAWN" && old.termination->kind != "EXPIRED")) {
            app_fail("SOURCE_RECONCILIATION_TERMINAL_REQUIRED", "committed withdrawn or expired finite lease required");
        }
        if (old.deliveries.size() != old.acknowledged + 1U) {
            app_fail("SOURCE_RECONCILIATION_NO_HEAD", "exactly one terminal unacknowledged source is required");
        }
        const auto& head = old.deliveries.back();
        if (*request.instance != old.instance || request.expected_revision != old.revision ||
            *request.reconciliation_state_digest != (request.structural_selector ?
                source_subscription_commitments_.at(old.grant.id).root : source_state_digest(old)) ||
            *request.terminal_digest != terminal_digest(*old.termination) ||
            *request.source_operation != head.source_operation || *request.delivery_operation != head.operation) {
            app_fail("SOURCE_RECONCILIATION_CONFLICT", "exact instance, revision, state, terminal and source mapping required");
        }
        const auto queued = outbound_index_.find(operation_id_text(head.operation));
        if (queued == outbound_index_.end() || !outbound_[queued->second].receipt) {
            app_fail("SOURCE_RECONCILIATION_RECEIPT_REQUIRED", "pending, rejected, cancelled or expired delivery is not acknowledgment");
        }
        if (receipt_digest(*outbound_[queued->second].receipt) != *request.receipt_digest) {
            app_fail("SOURCE_RECONCILIATION_RECEIPT_MISMATCH", "select the exact durable receipt, not a claimed remote outcome");
        }
        auto next = copy_subscription(old);
        next.reconciliation = SourceReceiptReconciliation{
            .preceding_revision = old.revision, .preceding_pid = old.pid,
            .preceding_state_digest = source_state_digest(old), .terminal_digest = terminal_digest(*old.termination),
            .source_operation = head.source_operation, .delivery_operation = head.operation,
            .receipt_digest = *request.receipt_digest,
        };
        ++next.revision; next.transition = "RECONCILE_RECEIPT";
        next.configuration_event = event; next.unix_ms = now; next.pid = pid;
        next.reason = request.reason; next.request_digest = commitment;
        adopt_receipt(next);
        const auto bytes = transaction(next, std::nullopt, std::nullopt);
        apply_source_subscription(bytes, false, true);
        pause_at("NATRAV_OVERLAY_TEST_SOURCE_RECONCILE_BEFORE_COMMIT_MS");
        append_entry(EntryKind::source_subscription, bytes);
        pause_at("NATRAV_OVERLAY_TEST_SOURCE_RECONCILE_AFTER_COMMIT_MS");
        return response(source_subscriptions_.at(request.grant), "RECONCILED");
    }

    if (request.command == SourceSubscriptionCommand::succeed) {
        if (config.format_version < 16U || grant == nullptr || grant->uid != uid) {
            app_fail("SOURCE_DISCLOSURE_DENIED", "one currently accepted finite successor grant required");
        }
        if (grant->lease_generation.empty() || grant->lease_generation != request.successor_lease) {
            app_fail("SOURCE_SUCCESSION_LEASE_MISMATCH", "select the exact finite successor lease generation");
        }
        const auto commitment = request_digest(request);
        if (found != source_subscriptions_.end()) {
            if (found->second.succession && found->second.grant == *grant &&
                found->second.succession->creation_request_digest == commitment) {
                return response(found->second, "ALREADY_SUCCEEDED");
            }
            app_fail("SOURCE_SUCCESSION_CONFLICT", "successor grant is already reserved by another admission");
        }
        const auto previous = source_subscriptions_.find(request.predecessor_grant);
        if (previous == source_subscriptions_.end() || previous->second.grant.uid != uid) {
            app_fail("SOURCE_SUBSCRIPTION_NOT_FOUND", "owner predecessor absent");
        }
        const auto& old = previous->second;
        if (!old.retired || !old.termination ||
            (old.termination->kind != "WITHDRAWN" && old.termination->kind != "EXPIRED")) {
            app_fail("SOURCE_SUCCESSION_TERMINAL_REQUIRED", "predecessor must be a committed withdrawn or expired finite lease");
        }
        if (old.acknowledged != old.deliveries.size()) {
            app_fail("SOURCE_SUCCESSION_UNACKNOWLEDGED", "every predecessor issue must have subscription-acknowledged progress; no implicit skip or cancellation");
        }
        if (*request.instance != old.instance || request.expected_revision != old.revision ||
            request.predecessor_lease != old.grant.lease_generation ||
            *request.predecessor_state_digest != (request.structural_selector ?
                source_subscription_commitments_.at(old.grant.id).root : source_state_digest(old)) ||
            request.expected_frontier != source_frontier(old) ||
            *request.predecessor_mapping_digest != source_mapping_digest(old)) {
            app_fail("SOURCE_SUCCESSION_CONFLICT", "exact terminal instance, revision, state and acknowledged mapping required");
        }
        if (grant->uid != old.grant.uid || grant->author_uid != old.grant.author_uid ||
            grant->peer != old.grant.peer || grant->scope != old.grant.scope ||
            grant->generation != old.grant.generation) {
            app_fail("SOURCE_SUCCESSION_IDENTITY_MISMATCH", "succession cannot change the source domain or subscriber key policy");
        }
        std::size_t owned = 0U;
        for (const auto& [id, value] : source_subscriptions_) {
            static_cast<void>(id);
            if (value.grant.uid == uid) { ++owned; }
            if (value.succession && value.succession->predecessor_grant == old.grant.id) {
                app_fail("SOURCE_SUCCESSION_PREDECESSOR_ADOPTED", "a terminal instance has at most one successor");
            }
        }
        if (source_subscriptions_.size() >= kSourceSubscriptionLimit || owned >= kSourceSubscriptionUidLimit) {
            app_fail("SOURCE_SUBSCRIPTION_LIMIT", "retained subscription registry full");
        }
        const auto* key = find_peer_generation(config, grant->peer, grant->generation);
        if (key == nullptr || key->spki_sha256 != old.peer_spki) {
            app_fail("SOURCE_SUCCESSION_IDENTITY_MISMATCH", "successor must retain exact acknowledged recipient SPKI");
        }
        SourceSubscription next;
        next.grant = *grant; next.instance = instance_id(node_id_, *grant);
        next.peer_spki = old.peer_spki;
        static_cast<void>(policy_for_source(next, config, now));
        if (grant->lease_duration_ms > std::numeric_limits<std::uint64_t>::max() - now) {
            app_fail("SOURCE_SUBSCRIPTION_INVALID", "successor lease expiry overflows");
        }
        next.created_event = event; next.created_unix_ms = now; next.created_pid = pid;
        next.creation_reason = request.reason;
        next.lease_started_unix_ms = now; next.lease_expires_unix_ms = now + grant->lease_duration_ms;
        next.revision = 1U; next.transition = "SUCCEED"; next.reason = request.reason;
        next.configuration_event = event; next.unix_ms = now; next.pid = pid;
        next.request_digest = commitment;
        next.succession = SourceSubscriptionSuccession{
            .predecessor_grant = old.grant.id, .predecessor_lease = old.grant.lease_generation,
            .predecessor_instance = old.instance, .predecessor_revision = old.revision,
            .predecessor_state_digest = source_state_digest(old),
            .inherited_acknowledged = source_frontier(old), .mapping_digest = source_mapping_digest(old),
            .creation_request_digest = commitment,
        };
        const auto bytes = transaction(next, std::nullopt, std::nullopt);
        apply_source_subscription(bytes, false, true);
        pause_at("NATRAV_OVERLAY_TEST_SOURCE_SUCCESSION_BEFORE_COMMIT_MS");
        append_entry(EntryKind::source_subscription, bytes);
        pause_at("NATRAV_OVERLAY_TEST_SOURCE_SUCCESSION_AFTER_COMMIT_MS");
        return response(source_subscriptions_.at(request.grant), "SUCCEEDED");
    }

    if (found != source_subscriptions_.end() && !found->second.retired &&
        source_subscription_lease_expired(found->second, now)) {
        const auto& old = found->second;
        auto expired = copy_subscription(old);
        ++expired.revision;
        expired.retired = true;
        expired.retained_unacknowledged =
            old.deliveries.size() != old.acknowledged;
        expired.transition = "LEASE_EXPIRE";
        expired.reason = "finite source-subscription lease expired";
        expired.configuration_event = event;
        expired.unix_ms = now;
        expired.pid = pid;
        expired.request_digest = {};
        SourceSubscriptionTermination terminal;
        terminal.kind = "EXPIRED";
        terminal.lease_generation = old.grant.lease_generation;
        terminal.configuration_event = event;
        terminal.unix_ms = now;
        terminal.actor_peer = node_id_;
        terminal.pending_disposition = "NONE";
        terminal.reason = expired.reason;
        std::optional<Bytes> cancellation;
        if (old.deliveries.size() != old.acknowledged) {
            const auto operation = old.deliveries.back().operation;
            const auto outbound_found = outbound_index_.find(
                operation_id_text(operation));
            check(outbound_found != outbound_index_.end(),
                "lease expiry lacks its outbox head");
            const auto& queued = outbound_[outbound_found->second];
            if (outbound_is_pending(queued)) {
                if (old.grant.withdrawal_pending ==
                    SourcePendingDisposition::cancel) {
                    check(queued.delivery.has_value(),
                        "lease expiry pending head lacks policy");
                    terminal.pending_disposition = "CANCEL";
                    terminal.cancelled_operation = operation;
                    cancellation = source_cancellation_payload(
                        operation, now, "SOURCE_SUBSCRIPTION_LEASE",
                        expired.reason, queued.delivery->policy);
                } else {
                    terminal.pending_disposition = "RETAIN";
                }
            }
        }
        expired.termination = std::move(terminal);
        if (automatic_enabled(old)) {
            ++expired.automatic_schedule_revision;
            finish_automatic_grant(expired.automatic_grants.back(), expired,
                "RETIRED", "SOURCE_SUBSCRIPTION_LEASE_EXPIRED",
                expired.reason, static_cast<std::uint32_t>(::geteuid()), pid);
        }
        const auto bytes = transaction(
            expired, std::nullopt, std::nullopt, cancellation);
        apply_source_subscription(bytes, false, true);
        append_entry(EntryKind::source_subscription, bytes);
        found = source_subscriptions_.find(request.grant);
        return response(found->second, "LEASE_EXPIRED");
    }

    SourceSubscription next;
    std::optional<EvidenceRecord> record;
    std::optional<OutboundPolicy> policy;
    const auto request_hash = request_digest(request);
    if (request.command == SourceSubscriptionCommand::create) {
        if (!grant || grant->uid != uid) {
            app_fail("SOURCE_DISCLOSURE_DENIED", "no exact current disclosure grant");
        }
        if (found != source_subscriptions_.end()) {
            if (found->second.grant != *grant) {
                app_fail("SOURCE_SUBSCRIPTION_CONFLICT", "creation does not match reserved grant");
            }
            if (!found->second.remote_admission && found->second.creation_reason != request.reason) {
                app_fail("SOURCE_SUBSCRIPTION_CONFLICT", "creation reason does not match the existing provider-managed instance");
            }
            return response(found->second, found->second.retired ? "ALREADY_RETIRED" :
                (found->second.remote_admission ? "ALREADY_REMOTE_REQUESTED" : "ALREADY_CREATED"));
        }
        std::size_t owned = 0U;
        for (const auto& [id, value] : source_subscriptions_) {
            static_cast<void>(id);
            if (value.grant.uid == uid) { ++owned; }
        }
        if (source_subscriptions_.size() >= kSourceSubscriptionLimit ||
            owned >= kSourceSubscriptionUidLimit) {
            app_fail("SOURCE_SUBSCRIPTION_LIMIT", "retained subscription registry full");
        }
        const auto* key = find_peer_generation(config, grant->peer, grant->generation);
        if (!key) { app_fail("SOURCE_SUBSCRIPTION_KEY_INACTIVE", "subscriber key absent"); }
        next.grant = *grant;
        next.instance = instance_id(node_id_, *grant);
        next.peer_spki = key->spki_sha256;
        static_cast<void>(policy_for_source(next, config, now));
        next.created_event = event;
        next.created_unix_ms = now;
        next.created_pid = pid;
        next.creation_reason = request.reason;
        if (!grant->lease_generation.empty()) {
            if (grant->lease_duration_ms >
                std::numeric_limits<std::uint64_t>::max() - now) {
                app_fail("SOURCE_SUBSCRIPTION_INVALID", "lease expiry overflows time");
            }
            next.lease_started_unix_ms = now;
            next.lease_expires_unix_ms = now + grant->lease_duration_ms;
        }
        next.reason = request.reason;
        next.revision = 1U;
        next.transition = "CREATE";
    } else {
        if (found == source_subscriptions_.end()) {
            app_fail("SOURCE_SUBSCRIPTION_NOT_FOUND", "owner subscription absent");
        }
        const auto& old = found->second;
        if (*request.instance != old.instance) {
            app_fail("SOURCE_SUBSCRIPTION_CONFLICT", "instance mismatch");
        }
        const bool schedule_command = request.command == SourceSubscriptionCommand::automatic_enable ||
            request.command == SourceSubscriptionCommand::automatic_pause;
        if (request.command != SourceSubscriptionCommand::retire && !rule_current(old, config)) {
            app_fail("SOURCE_DISCLOSURE_DENIED", "accepted source grant removed or changed");
        }
        if (request.command == SourceSubscriptionCommand::automatic_enable &&
            automatic_enabled(old)) {
            const auto& current = old.automatic_grants.back();
            if (current.generation == request.expected_grant_generation + 1U &&
                current.observed_subscription_revision == request.expected_revision &&
                current.maximum_steps == request.automatic_maximum_steps &&
                current.minimum_interval_ms == request.automatic_minimum_interval_ms &&
                current.reason == request.reason) {
                return response(old, "ALREADY_ENABLED");
            }
            app_fail("SOURCE_SUBSCRIPTION_AUTOMATION_ALREADY_ENABLED",
                "pause the current finite grant before enabling another");
        }
        if (request.command == SourceSubscriptionCommand::automatic_pause &&
            !automatic_enabled(old)) {
            if (!old.automatic_grants.empty() &&
                old.automatic_grants.back().state == "PAUSED" &&
                old.automatic_grants.back().generation == request.expected_grant_generation &&
                old.automatic_grants.back().end_reason == request.reason) {
                return response(old, "ALREADY_PAUSED");
            }
            return response(old, "ALREADY_STOPPED");
        }
        if (!schedule_command && old.request_digest == request_hash &&
            request.expected_revision + 1U == old.revision) {
            return response(old, "ALREADY_COMMITTED");
        }
        if (old.retired) {
            app_fail("SOURCE_SUBSCRIPTION_RETIRED", "subscription is terminal");
        }
        if (request.expected_revision != old.revision) {
            app_fail("SOURCE_SUBSCRIPTION_CONFLICT", "revision mismatch");
        }
        if (schedule_command &&
            (request.expected_schedule_revision != old.automatic_schedule_revision ||
             request.expected_grant_generation != old.automatic_grants.size())) {
            app_fail("SOURCE_SUBSCRIPTION_AUTOMATION_CONFLICT",
                "automatic schedule changed before the requested transition");
        }
#ifndef NATRAV_SOURCE_SUBSCRIPTION_LEGACY_PROGRESS
        if (request.command == SourceSubscriptionCommand::step) {
            if (automatic_enabled(old)) {
                app_fail("SOURCE_SUBSCRIPTION_AUTOMATION_ENABLED",
                    "pause automatic source delivery before a manual step");
            }
            const auto commitment = source_subscription_commitments_.find(
                old.grant.id);
            check(commitment != source_subscription_commitments_.end(),
                "source progress predecessor commitment absent");
            std::optional<SourceProgressPreparation> prepared;
            SourceProgressTransaction progress{
                .kind = SourceProgressKind::issue,
                .grant = old.grant.id,
                .instance = old.instance,
                .preceding_revision = old.revision,
                .preceding_commitment = commitment->second.root,
                .configuration_event = event,
                .unix_ms = now,
                .pid = pid,
                .request_digest = request_hash,
                .automatic_generation = 0U,
                .automatic_steps_after = 0U,
                .automatic_schedule_revision_after = 0U,
                .automatic_executor_uid = 0U,
                .automatic_state_after = 0U,
                .delivery = {},
                .durable_receipt_digest = {},
                .record = std::nullopt,
                .policy = std::nullopt,
                .outgoing = {},
            };
            if (old.deliveries.size() != old.acknowledged) {
                const auto& head = old.deliveries.back();
                const auto& queued = outbound_.at(outbound_index_.at(
                    operation_id_text(head.operation)));
                if (!queued.receipt) {
                    return response(old, outbound_is_pending(queued) ?
                        "PENDING" : "BLOCKED_TERMINAL");
                }
                progress.kind = SourceProgressKind::acknowledge;
                progress.delivery.operation = head.operation;
                progress.delivery.record_digest = head.record_digest;
                progress.durable_receipt_digest = receipt_digest(*queued.receipt);
            } else {
                if (old.deliveries.size() >= old.grant.maximum_records) {
                    return response(old, "RECORD_BUDGET_EXHAUSTED");
                }
                const auto domain = authored_source_index_.find(
                    {old.grant.author_uid, old.grant.scope});
                if (domain == authored_source_index_.end() ||
                    source_frontier(old) >= domain->second.size()) {
                    return response(old, "CAUGHT_UP");
                }
                const auto index = static_cast<std::size_t>(old.acknowledged);
                const auto& source = inbound_.at(domain->second.at(
                    static_cast<std::size_t>(source_base(old)) + index));
                if (source.record.payload.size() >
                    old.grant.maximum_payload_bytes - old.used_payload_bytes) {
                    return response(old, "BYTE_BUDGET_EXHAUSTED");
                }
#ifndef NATRAV_SOURCE_SUBSCRIPTION_INDEPENDENT_PREPARATION
                prepared.emplace(prepare_source_progress_locked(old, event, now, true));
                progress.policy = prepared->issue->policy;
                progress.record = prepared->issue->record;
#else
                progress.policy = policy_for_source(old, config, now);
                progress.record = source_subscription_record_locked(old, index, true);
                validate_new_outbound_locked(*progress.record, *progress.policy);
#endif
                progress.delivery.source_operation = source.record.operation_id;
                progress.delivery.operation = progress.record->operation_id;
                progress.delivery.record_digest =
                    evidence_record_digest(*progress.record);
                progress.delivery.payload_bytes =
                    static_cast<std::uint32_t>(source.record.payload.size());
            }
#ifndef NATRAV_SOURCE_SUBSCRIPTION_INDEPENDENT_PREPARATION
            if (!prepared) { prepared.emplace(prepare_source_progress_locked(old, event, now, false)); }
#endif
            const auto* preparation = prepared ? &*prepared : nullptr;
            const auto transition = source_progress_transition(progress.kind);
            commit_source_progress_locked(progress_transaction(std::move(progress)),
                preparation, false);
            return response(source_subscriptions_.at(request.grant), transition);
        }
#endif
        next = copy_subscription(old);
        next.revision++;
        next.reason = request.reason;
        if (request.command == SourceSubscriptionCommand::automatic_enable) {
            if (old.automatic_grants.size() >= kSourceSubscriptionAutomaticGrantLimit) {
                app_fail("SOURCE_SUBSCRIPTION_AUTOMATION_HISTORY_LIMIT",
                    "32 finite source automation grants are retained");
            }
            static_cast<void>(policy_for_source(old, config, now));
            next.automatic_schedule_revision++;
            next.automatic_grants.push_back(SourceSubscriptionAutomaticGrant{
                .generation = old.automatic_grants.size() + 1U,
                .observed_subscription_revision = old.revision,
                .configuration_event = event,
                .unix_ms = now,
                .actor_uid = uid,
                .pid = pid,
                .maximum_steps = request.automatic_maximum_steps,
                .minimum_interval_ms = request.automatic_minimum_interval_ms,
                .disclosure_digest = old.grant.digest,
                .reason = request.reason,
                .start_issued = old.deliveries.size(),
                .start_acknowledged = old.acknowledged,
                .error = {},
                .end_reason = {},
            });
            next.transition = "AUTO_ENABLE";
        } else if (request.command == SourceSubscriptionCommand::automatic_pause) {
            next.automatic_schedule_revision++;
            next.transition = "AUTO_PAUSE";
            next.configuration_event = event;
            next.unix_ms = now;
            next.pid = pid;
            finish_automatic_grant(next.automatic_grants.back(), next,
                "PAUSED", "SOURCE_SUBSCRIPTION_AUTOMATION_PAUSED", request.reason,
                uid, pid);
        } else if (request.command == SourceSubscriptionCommand::retire) {
            const bool outstanding = old.deliveries.size() != old.acknowledged;
            if (outstanding != request.retain_pending) {
                app_fail("SOURCE_SUBSCRIPTION_PENDING", "retirement must explicitly retain exactly one unacknowledged delivery, or require empty");
            }
            next.retired = true;
            next.retained_unacknowledged = outstanding;
            next.transition = "RETIRE";
            if (automatic_enabled(old)) {
                next.automatic_schedule_revision++;
                next.configuration_event = event;
                next.unix_ms = now;
                next.pid = pid;
                finish_automatic_grant(next.automatic_grants.back(), next,
                    "RETIRED", "SOURCE_SUBSCRIPTION_RETIRED", request.reason,
                    uid, pid);
            }
        } else {
            if (automatic_enabled(old)) {
                app_fail("SOURCE_SUBSCRIPTION_AUTOMATION_ENABLED",
                    "pause automatic source delivery before a manual step");
            }
            if (old.deliveries.size() != old.acknowledged) {
                const auto& queued = outbound_.at(outbound_index_.at(
                    operation_id_text(old.deliveries.back().operation)));
                if (!queued.receipt) {
                    return response(old, outbound_is_pending(queued) ? "PENDING" : "BLOCKED_TERMINAL");
                }
                next.acknowledged++;
                next.transition = "ACK";
                auto& delivery = next.deliveries.back();
                delivery.acknowledged_event = event;
                delivery.acknowledged_unix_ms = now;
                delivery.acknowledged_pid = pid;
            } else {
                if (old.deliveries.size() >= old.grant.maximum_records) {
                    return response(old, "RECORD_BUDGET_EXHAUSTED");
                }
                const auto domain = authored_source_index_.find({old.grant.author_uid, old.grant.scope});
                if (domain == authored_source_index_.end() ||
                    source_frontier(old) >= domain->second.size()) {
                    return response(old, "CAUGHT_UP");
                }
                const auto index = static_cast<std::size_t>(old.acknowledged);
                const auto& source = inbound_[domain->second[static_cast<std::size_t>(source_base(old)) + index]];
                if (source.record.payload.size() >
                    old.grant.maximum_payload_bytes - old.used_payload_bytes) {
                    return response(old, "BYTE_BUDGET_EXHAUSTED");
                }
                policy = policy_for_source(old, config, now);
                record = source_subscription_record_locked(old, index, true);
                validate_new_outbound_locked(*record, *policy);
                next.deliveries.push_back(SourceSubscriptionDelivery{
                    .source_operation = source.record.operation_id,
                    .operation = record->operation_id,
                    .record_digest = evidence_record_digest(*record),
                    .payload_bytes = static_cast<std::uint32_t>(source.record.payload.size()),
                    .configuration_event = event,
                    .unix_ms = now,
                    .pid = pid,
                });
                next.used_payload_bytes += source.record.payload.size();
                next.transition = "ISSUE";
            }
        }
    }
    next.configuration_event = event;
    next.unix_ms = now;
    next.pid = pid;
    next.request_digest = request_hash;
    const auto bytes = transaction(next, record, policy);
    apply_source_subscription(bytes, false, true);
    pause_at("NATRAV_OVERLAY_TEST_SOURCE_SUBSCRIPTION_BEFORE_COMMIT_MS");
    append_entry(EntryKind::source_subscription, bytes);
    pause_at("NATRAV_OVERLAY_TEST_SOURCE_SUBSCRIPTION_AFTER_COMMIT_MS");
    return response(source_subscriptions_.at(request.grant), next.transition);
}

std::vector<SourceSubscriptionCandidate>
NodeState::automatic_source_subscription_candidates() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<SourceSubscriptionCandidate> result;
    result.reserve(source_subscriptions_.size());
    for (const auto& [grant, value] : source_subscriptions_) {
        if (!value.retired && automatic_enabled(value)) {
            result.push_back(SourceSubscriptionCandidate{
                .grant = grant,
                .generation = value.automatic_grants.back().generation,
                .minimum_interval_ms = value.automatic_grants.back().minimum_interval_ms,
            });
        }
    }
    return result;
}

bool NodeState::automatic_source_subscription_step(
    const std::string_view grant_name,
    const RuntimeConfig& config,
    const std::uint64_t configuration_event,
    const std::uint32_t executor_uid,
    const std::uint32_t executor_pid) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (poisoned_) {
        app_fail("STATE_RESTART_REQUIRED", "automatic source writer requires restart");
    }
    if (configuration_event == 0U ||
        configuration_event != active_configuration_event(configuration_events_)) {
        app_fail("SOURCE_SUBSCRIPTION_CONFIGURATION_MISMATCH",
            "automatic source delivery must retain the active configuration");
    }
    const auto found = source_subscriptions_.find(std::string(grant_name));
    if (found == source_subscriptions_.end() || found->second.retired ||
        !automatic_enabled(found->second)) {
        return false;
    }
    const auto& old = found->second;
    if (source_subscription_lease_expired(old, now_ms())) {
        const auto timestamp = now_ms();
        auto expired = copy_subscription(old);
        ++expired.revision;
        expired.retired = true;
        expired.retained_unacknowledged =
            old.deliveries.size() != old.acknowledged;
        expired.transition = "LEASE_EXPIRE";
        expired.reason = "finite source-subscription lease expired";
        expired.configuration_event = configuration_event;
        expired.unix_ms = timestamp;
        expired.pid = executor_pid;
        expired.request_digest = {};
        SourceSubscriptionTermination terminal;
        terminal.kind = "EXPIRED";
        terminal.lease_generation = old.grant.lease_generation;
        terminal.configuration_event = configuration_event;
        terminal.unix_ms = timestamp;
        terminal.pending_disposition = "NONE";
        terminal.actor_peer = node_id_;
        terminal.reason = expired.reason;
        std::optional<Bytes> cancellation;
        if (old.deliveries.size() != old.acknowledged) {
            const auto operation = old.deliveries.back().operation;
            const auto outbound_found = outbound_index_.find(
                operation_id_text(operation));
            check(outbound_found != outbound_index_.end(),
                "lease expiry lacks its outbox head");
            const auto& queued = outbound_[outbound_found->second];
            if (outbound_is_pending(queued)) {
                if (old.grant.withdrawal_pending ==
                    SourcePendingDisposition::cancel) {
                    check(queued.delivery.has_value(),
                        "lease expiry pending head lacks policy");
                    terminal.pending_disposition = "CANCEL";
                    terminal.cancelled_operation = operation;
                    cancellation = source_cancellation_payload(
                        operation, timestamp, "SOURCE_SUBSCRIPTION_LEASE",
                        expired.reason, queued.delivery->policy);
                } else {
                    terminal.pending_disposition = "RETAIN";
                }
            }
        }
        expired.termination = std::move(terminal);
        ++expired.automatic_schedule_revision;
        finish_automatic_grant(expired.automatic_grants.back(), expired,
            "RETIRED", "SOURCE_SUBSCRIPTION_LEASE_EXPIRED",
            expired.reason, static_cast<std::uint32_t>(::geteuid()), executor_pid);
        const auto bytes = transaction(
            expired, std::nullopt, std::nullopt, cancellation);
        apply_source_subscription(bytes, false, true);
        append_entry(EntryKind::source_subscription, bytes);
        return true;
    }
    const auto commit_block = [&](const std::string_view error) {
        auto next = copy_subscription(old);
        ++next.revision;
        ++next.automatic_schedule_revision;
        next.transition = "AUTO_BLOCK";
        next.reason.clear();
        next.configuration_event = configuration_event;
        next.unix_ms = now_ms();
        next.pid = executor_pid;
        next.request_digest = {};
        finish_automatic_grant(next.automatic_grants.back(), next,
            "BLOCKED", error, error, executor_uid, executor_pid);
        append_entry(EntryKind::source_subscription,
            transaction(next, std::nullopt, std::nullopt));
        return true;
    };

#if !defined(NATRAV_SOURCE_SUBSCRIPTION_LEGACY_PROGRESS) && \
    !defined(NATRAV_SOURCE_SUBSCRIPTION_INDEPENDENT_PREPARATION)
    AutomaticSourceEligibility eligibility;
    const auto block = automatic_source_subscription_block_error_locked(
        old, config, configuration_event, &eligibility);
#else
    const auto block = automatic_source_subscription_block_error_locked(old, config);
#endif
    if (!block.empty()) { return commit_block(block); }
    const auto timestamp = now_ms();
#ifndef NATRAV_SOURCE_SUBSCRIPTION_LEGACY_PROGRESS
    {
        const auto commitment = source_subscription_commitments_.find(
            old.grant.id);
        check(commitment != source_subscription_commitments_.end(),
            "source progress predecessor commitment absent");
        const auto& automatic = old.automatic_grants.back();
        std::optional<SourceProgressPreparation> prepared;
        SourceProgressTransaction progress{
            .kind = SourceProgressKind::automatic_issue,
            .grant = old.grant.id,
            .instance = old.instance,
            .preceding_revision = old.revision,
            .preceding_commitment = commitment->second.root,
            .configuration_event = configuration_event,
            .unix_ms = timestamp,
            .pid = executor_pid,
            .request_digest = {},
            .automatic_generation = automatic.generation,
            .automatic_steps_after = automatic.steps + 1U,
            .automatic_schedule_revision_after =
                old.automatic_schedule_revision + 1U,
            .automatic_executor_uid = executor_uid,
            .automatic_state_after = static_cast<std::uint8_t>(
                automatic.steps + 1U == automatic.maximum_steps ? 2U : 1U),
            .delivery = {},
            .durable_receipt_digest = {},
            .record = std::nullopt,
            .policy = std::nullopt,
            .outgoing = {},
        };
        if (old.deliveries.size() != old.acknowledged) {
            const auto& head = old.deliveries.back();
            const auto& queued = outbound_.at(outbound_index_.at(
                operation_id_text(head.operation)));
            if (!queued.receipt) { return false; }
            progress.kind = SourceProgressKind::automatic_acknowledge;
            progress.delivery.operation = head.operation;
            progress.delivery.record_digest = head.record_digest;
            progress.durable_receipt_digest = receipt_digest(*queued.receipt);
        } else {
            const auto domain = authored_source_index_.find(
                {old.grant.author_uid, old.grant.scope});
            if (domain == authored_source_index_.end() ||
                source_frontier(old) >= domain->second.size()) {
                return false;
            }
            const auto* peer = find_peer(config, old.grant.peer);
            if (peer == nullptr || std::none_of(peer->routes.begin(),
                    peer->routes.end(), [](const auto& route) {
                        return route.state == PeerRouteState::enabled;
                    })) {
                return false;
            }
            const auto index = static_cast<std::size_t>(old.acknowledged);
            try {
#ifndef NATRAV_SOURCE_SUBSCRIPTION_INDEPENDENT_PREPARATION
                check(eligibility.available,
                    "automatic source issuance lacks same-iteration eligibility");
                prepared.emplace(prepare_source_progress_locked(
                    old, configuration_event, timestamp, true, &eligibility));
                progress.policy = prepared->issue->policy;
                progress.record = prepared->issue->record;
#else
                progress.policy = policy_for_source(old, config, timestamp);
                progress.record = source_subscription_record_locked(old, index, true);
                validate_new_outbound_locked(*progress.record, *progress.policy);
#endif
            } catch (const AppError& error) {
                if (error.code() == "OUTBOX_GLOBAL_RECORD_LIMIT" ||
                    error.code() == "OUTBOX_GLOBAL_PAYLOAD_LIMIT" ||
                    error.code() == "OUTBOX_PEER_RECORD_LIMIT" ||
                    error.code() == "OUTBOX_PEER_PAYLOAD_LIMIT" ||
                    error.code() == "STATE_CAPACITY_EXCEEDED") {
                    return false;
                }
                throw;
            }
            const auto& source = inbound_.at(domain->second.at(
                static_cast<std::size_t>(source_base(old)) + index));
            progress.delivery.source_operation = source.record.operation_id;
            progress.delivery.operation = progress.record->operation_id;
            progress.delivery.record_digest =
                evidence_record_digest(*progress.record);
            progress.delivery.payload_bytes =
                static_cast<std::uint32_t>(source.record.payload.size());
        }
#ifndef NATRAV_SOURCE_SUBSCRIPTION_INDEPENDENT_PREPARATION
        if (!prepared) {
            prepared.emplace(prepare_source_progress_locked(old, configuration_event, timestamp, false));
        }
#endif
        const auto* preparation = prepared ? &*prepared : nullptr;
        commit_source_progress_locked(progress_transaction(std::move(progress)),
            preparation, true);
        return true;
    }
#endif
    auto next = copy_subscription(old);
    ++next.revision;
    ++next.automatic_schedule_revision;
    next.configuration_event = configuration_event;
    next.unix_ms = timestamp;
    next.pid = executor_pid;
    next.reason.clear();
    next.request_digest = {};
    auto& automatic = next.automatic_grants.back();
    ++automatic.steps;
    automatic.last_step_event = configuration_event;
    automatic.last_step_unix_ms = timestamp;
    automatic.last_executor_uid = executor_uid;
    automatic.last_executor_pid = executor_pid;

    std::optional<EvidenceRecord> record;
    std::optional<OutboundPolicy> policy;
    if (old.deliveries.size() != old.acknowledged) {
        const auto& queued = outbound_.at(outbound_index_.at(
            operation_id_text(old.deliveries.back().operation)));
        if (!queued.receipt) { return false; }
        next.acknowledged++;
        next.transition = "AUTO_ACK";
        auto& delivery = next.deliveries.back();
        delivery.acknowledged_event = configuration_event;
        delivery.acknowledged_unix_ms = timestamp;
        delivery.acknowledged_pid = executor_pid;
        delivery.acknowledge_automatic_generation = automatic.generation;
    } else {
        const auto domain = authored_source_index_.find({old.grant.author_uid, old.grant.scope});
        if (domain == authored_source_index_.end() ||
            source_frontier(old) >= domain->second.size()) {
            return false;
        }
        const auto* peer = find_peer(config, old.grant.peer);
        if (peer == nullptr || std::none_of(peer->routes.begin(), peer->routes.end(), [](const auto& route) {
                return route.state == PeerRouteState::enabled;
            })) {
            return false;
        }
        policy = policy_for_source(old, config, timestamp);
        const auto index = static_cast<std::size_t>(old.acknowledged);
        record = source_subscription_record_locked(old, index, true);
        try {
            validate_new_outbound_locked(*record, *policy);
        } catch (const AppError& error) {
            if (error.code() == "OUTBOX_GLOBAL_RECORD_LIMIT" ||
                error.code() == "OUTBOX_GLOBAL_PAYLOAD_LIMIT" ||
                error.code() == "OUTBOX_PEER_RECORD_LIMIT" ||
                error.code() == "OUTBOX_PEER_PAYLOAD_LIMIT" ||
                error.code() == "STATE_CAPACITY_EXCEEDED") {
                return false;
            }
            throw;
        }
        const auto& source = inbound_[domain->second[static_cast<std::size_t>(source_base(old)) + index]];
        next.deliveries.push_back(SourceSubscriptionDelivery{
            .source_operation = source.record.operation_id,
            .operation = record->operation_id,
            .record_digest = evidence_record_digest(*record),
            .payload_bytes = static_cast<std::uint32_t>(source.record.payload.size()),
            .configuration_event = configuration_event,
            .unix_ms = timestamp,
            .pid = executor_pid,
            .issue_automatic_generation = automatic.generation,
        });
        next.used_payload_bytes += source.record.payload.size();
        next.transition = "AUTO_ISSUE";
    }
    if (automatic.steps == automatic.maximum_steps) {
        finish_automatic_grant(automatic, next, "EXHAUSTED",
            "SOURCE_SUBSCRIPTION_AUTOMATION_BUDGET_EXHAUSTED",
            "finite automatic source-step allowance consumed",
            executor_uid, executor_pid);
    }
    const auto bytes = transaction(next, record, policy);
    apply_source_subscription(bytes, false, true);
    pause_at("NATRAV_OVERLAY_TEST_AUTOMATIC_SOURCE_BEFORE_COMMIT_MS");
    append_entry(EntryKind::source_subscription, bytes);
    pause_at("NATRAV_OVERLAY_TEST_AUTOMATIC_SOURCE_AFTER_COMMIT_MS");
    return true;
}

RemoteSourceSubscriptionResponse NodeState::source_subscription_remote_command(
    const RemoteSourceSubscriptionRequest& request,
    const RuntimeConfig& config,
    const TlsSessionInfo& peer,
    const std::uint64_t event,
    const std::uint64_t now) {
    validate_remote_source_subscription_request(request);
    const auto* grant = source_disclosure_grant(
        config.source_disclosure, request.grant);
    const auto* key = grant ? find_peer_generation(
        config, grant->peer, grant->generation) : nullptr;
    const bool exact_actor = config.format_version >= 15U && grant != nullptr &&
        grant->peer == peer.peer_node &&
        grant->generation == peer.peer_generation &&
        key != nullptr && key->state == KeyGenerationState::active &&
        peer.peer_key_state == KeyGenerationState::active &&
        key->spki_sha256 == peer.peer_spki_sha256 &&
        local_control_allows(config.local_control, grant->uid,
            LocalControlClass::source_disclose);
    if (!exact_actor) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_DENIED",
            "authenticated peer does not match one current exact disclosure grant");
    }
    const bool leased = !grant->lease_generation.empty();
    if (leased != !request.lease_generation.empty() ||
        (leased && request.lease_generation != grant->lease_generation)) {
        app_fail("SOURCE_SUBSCRIPTION_LEASE_GENERATION_MISMATCH",
            "remote command must select the exact accepted lease generation");
    }
    if (request.command == RemoteSourceSubscriptionCommand::withdraw && !leased) {
        app_fail("SOURCE_SUBSCRIPTION_WITHDRAWAL_UNAVAILABLE",
            "only a finite V16 lease can be withdrawn remotely");
    }
    if (event == 0U || now == 0U) {
        app_fail("CONFIG_PROVENANCE_MISSING",
            "remote subscription request requires one accepted provider configuration");
    }

    std::lock_guard<std::mutex> lock(mutex_);
    const auto response_for = [&](const SourceSubscription& value,
                                  const std::string_view disposition) {
        check(value.remote_admission.has_value(),
            "remote subscription response lacks request provenance");
        const auto& accepted = *value.remote_admission;
        RemoteSourceSubscriptionResponse response{
            .request_id = request.request_id,
            .provider = node_id_,
            .grant = value.grant.id,
            .instance = value.instance,
            .revision = value.revision,
            .retired = value.retired,
            .disposition = std::string(disposition),
            .issued = static_cast<std::uint32_t>(value.deliveries.size()),
            .acknowledged = static_cast<std::uint32_t>(value.acknowledged),
            .used_payload_bytes = value.used_payload_bytes,
            .maximum_records = value.grant.maximum_records,
            .maximum_payload_bytes = value.grant.maximum_payload_bytes,
            .grant_digest = value.grant.digest,
            .subscriber_generation = value.grant.generation,
            .subscriber_spki = value.peer_spki,
            .accepted_request_id = accepted.request_id,
            .accepted_configuration_event = accepted.configuration_event,
            .accepted_unix_ms = accepted.unix_ms,
            .lease_generation = value.grant.lease_generation,
            .lease_expires_unix_ms = value.lease_expires_unix_ms,
            .withdrawal_policy = value.grant.lease_generation.empty() ?
                std::string() :
                std::string(source_pending_disposition_name(
                    value.grant.withdrawal_pending)),
            .terminal_kind = value.termination ? value.termination->kind : std::string(),
            .terminal_pending_disposition = value.termination ?
                value.termination->pending_disposition : std::string(),
            .terminal_cancelled_operation = value.termination ?
                value.termination->cancelled_operation :
                std::optional<Digest>{},
            .terminal_reason = value.termination ?
                value.termination->reason : std::string(),
        };
        return response;
    };

    const auto commit_terminal = [&](const SourceSubscription& old,
                                     const std::string_view transition,
                                     const std::string_view reason,
                                     const std::optional<RemoteSourceSubscriptionRequest>& remote_request) {
        check(source_subscription_is_leased(old) && !old.retired,
            "lease terminal transition requires one active leased subscription");
        auto next = copy_subscription(old);
        ++next.revision;
        next.retired = true;
        next.retained_unacknowledged =
            old.deliveries.size() != old.acknowledged;
        next.transition = std::string(transition);
        next.reason = std::string(reason);
        next.configuration_event = event;
        next.unix_ms = now;
        next.pid = static_cast<std::uint32_t>(::getpid());
        next.request_digest = remote_request ?
            remote_request_digest(*remote_request) : Digest{};
        SourceSubscriptionTermination terminal;
        terminal.kind = transition == "REMOTE_WITHDRAW" ?
            "WITHDRAWN" : "EXPIRED";
        terminal.lease_generation = old.grant.lease_generation;
        terminal.configuration_event = event;
        terminal.unix_ms = now;
        terminal.actor_peer = remote_request ? peer.peer_node : node_id_;
        terminal.actor_generation = remote_request ? peer.peer_generation : std::string();
        terminal.actor_spki = remote_request ? peer.peer_spki_sha256 : Digest{};
        terminal.request_id = remote_request ?
            std::optional<Digest>{remote_request->request_id} :
            std::optional<Digest>{};
        terminal.request_digest = remote_request ?
            remote_request_digest(*remote_request) : Digest{};
        terminal.reason = std::string(reason);
        std::optional<Bytes> cancellation;
        if (old.deliveries.size() != old.acknowledged) {
            const auto operation = old.deliveries.back().operation;
            const auto found_outbound = outbound_index_.find(
                operation_id_text(operation));
            check(found_outbound != outbound_index_.end(),
                "source terminal transition lacks its outbox head");
            const auto& queued = outbound_[found_outbound->second];
            if (outbound_is_pending(queued)) {
                if (old.grant.withdrawal_pending ==
                    SourcePendingDisposition::cancel) {
                    check(queued.delivery.has_value(),
                        "pending source head lacks its delivery policy");
                    terminal.pending_disposition = "CANCEL";
                    terminal.cancelled_operation = operation;
                    cancellation = source_cancellation_payload(
                        operation, now,
                        transition == "REMOTE_WITHDRAW" ?
                            "REMOTE_SOURCE_SUBSCRIBER" :
                            "SOURCE_SUBSCRIPTION_LEASE",
                        reason, queued.delivery->policy);
                } else {
                    terminal.pending_disposition = "RETAIN";
                }
            } else {
                terminal.pending_disposition = "NONE";
            }
        } else {
            terminal.pending_disposition = "NONE";
        }
        next.termination = std::move(terminal);
        if (automatic_enabled(old)) {
            ++next.automatic_schedule_revision;
            finish_automatic_grant(next.automatic_grants.back(), next,
                "RETIRED",
                transition == "REMOTE_WITHDRAW" ?
                    "SOURCE_SUBSCRIPTION_WITHDRAWN" :
                    "SOURCE_SUBSCRIPTION_LEASE_EXPIRED",
                reason,
                static_cast<std::uint32_t>(::geteuid()),
                static_cast<std::uint32_t>(::getpid()));
        }
        const auto bytes = transaction(
            next, std::nullopt, std::nullopt, cancellation);
        apply_source_subscription(bytes, false, true);
        pause_at(transition == "REMOTE_WITHDRAW" ?
            "NATRAV_OVERLAY_TEST_REMOTE_SOURCE_WITHDRAW_BEFORE_COMMIT_MS" :
            "NATRAV_OVERLAY_TEST_SOURCE_LEASE_EXPIRE_BEFORE_COMMIT_MS");
        append_entry(EntryKind::source_subscription, bytes);
        pause_at(transition == "REMOTE_WITHDRAW" ?
            "NATRAV_OVERLAY_TEST_REMOTE_SOURCE_WITHDRAW_AFTER_COMMIT_MS" :
            "NATRAV_OVERLAY_TEST_SOURCE_LEASE_EXPIRE_AFTER_COMMIT_MS");
    };

    auto found = source_subscriptions_.find(request.grant);
    if (found != source_subscriptions_.end() && !found->second.retired &&
        source_subscription_lease_expired(found->second, now)) {
        commit_terminal(found->second, "LEASE_EXPIRE",
            "finite source-subscription lease expired", std::nullopt);
        found = source_subscriptions_.find(request.grant);
    }

    if (request.command == RemoteSourceSubscriptionCommand::status) {
        if (found == source_subscriptions_.end() ||
            !found->second.remote_admission.has_value()) {
            app_fail("SOURCE_SUBSCRIPTION_REMOTE_NOT_FOUND",
                "no remotely requested subscription exists for this exact grant");
        }
        if (found->second.grant.lease_generation != request.lease_generation) {
            app_fail("SOURCE_SUBSCRIPTION_LEASE_GENERATION_MISMATCH",
                "status selected another retained lease generation");
        }
        return response_for(found->second, "STATUS");
    }

    if (request.command == RemoteSourceSubscriptionCommand::withdraw) {
        if (found == source_subscriptions_.end() ||
            !found->second.remote_admission.has_value()) {
            app_fail("SOURCE_SUBSCRIPTION_REMOTE_NOT_FOUND",
                "no remotely requested subscription exists for withdrawal");
        }
        const auto& old = found->second;
        if (old.instance != *request.instance ||
            old.grant.lease_generation != request.lease_generation) {
            app_fail("SOURCE_SUBSCRIPTION_WITHDRAWAL_CONFLICT",
                "withdrawal selected another subscription instance or lease");
        }
        if (old.retired) {
            if (old.termination && old.termination->kind == "WITHDRAWN" &&
                old.termination->request_id == request.request_id &&
                old.termination->request_digest == remote_request_digest(request)) {
                return response_for(old, "ALREADY_WITHDRAWN");
            }
            return response_for(old,
                old.termination && old.termination->kind == "EXPIRED" ?
                    "EXPIRED" : "ALREADY_WITHDRAWN");
        }
        if (old.revision != request.expected_revision) {
            app_fail("SOURCE_SUBSCRIPTION_WITHDRAWAL_CONFLICT",
                "subscription changed before withdrawal");
        }
        commit_terminal(old, "REMOTE_WITHDRAW", request.reason, request);
        return response_for(source_subscriptions_.at(request.grant), "WITHDRAWN");
    }

    if (found != source_subscriptions_.end()) {
        if (!found->second.remote_admission.has_value()) {
            app_fail("SOURCE_SUBSCRIPTION_PROVIDER_MANAGED",
                "the grant is already reserved by a provider-managed subscription");
        }
        if (found->second.grant.lease_generation != request.lease_generation) {
            app_fail("SOURCE_SUBSCRIPTION_LEASE_GENERATION_MISMATCH",
                "request selected another retained lease generation");
        }
        const auto& accepted = *found->second.remote_admission;
        if (accepted.request_id == request.request_id &&
            accepted.request_digest != remote_request_digest(request)) {
            app_fail("SOURCE_SUBSCRIPTION_REMOTE_REQUEST_CONFLICT",
                "one remote request identity cannot name different request content");
        }
        const bool exact_retry = accepted.request_id == request.request_id;
        return response_for(found->second,
            exact_retry ? "ALREADY_ACCEPTED" : "ALREADY_REQUESTED");
    }

    std::size_t owned = 0U;
    for (const auto& [id, value] : source_subscriptions_) {
        static_cast<void>(id);
        if (value.grant.uid == grant->uid) { ++owned; }
    }
    if (source_subscriptions_.size() >= kSourceSubscriptionLimit ||
        owned >= kSourceSubscriptionUidLimit) {
        app_fail("SOURCE_SUBSCRIPTION_LIMIT",
            "retained subscription registry full");
    }

    SourceSubscription next;
    next.grant = *grant;
    next.instance = instance_id(node_id_, *grant);
    next.peer_spki = key->spki_sha256;
    static_cast<void>(policy_for_source(next, config, now));
    const auto commitment = remote_request_digest(request);
    next.created_event = event;
    next.created_unix_ms = now;
    next.created_pid = 0U;
    next.creation_reason = request.reason;
    if (leased) {
        if (grant->lease_duration_ms >
            std::numeric_limits<std::uint64_t>::max() - now) {
            app_fail("SOURCE_SUBSCRIPTION_INVALID", "lease expiry overflows time");
        }
        next.lease_started_unix_ms = now;
        next.lease_expires_unix_ms = now + grant->lease_duration_ms;
    }
    next.remote_admission = SourceSubscriptionRemoteAdmission{
        .request_id = request.request_id,
        .peer = peer.peer_node,
        .generation = peer.peer_generation,
        .peer_spki = peer.peer_spki_sha256,
        .configuration_event = event,
        .unix_ms = now,
        .reason = request.reason,
        .request_digest = commitment,
    };
    next.revision = 1U;
    next.transition = "REMOTE_REQUEST";
    next.reason = request.reason;
    next.configuration_event = event;
    next.unix_ms = now;
    next.pid = 0U;
    next.request_digest = commitment;
    const auto bytes = transaction(next, std::nullopt, std::nullopt);
    apply_source_subscription(bytes, false, true);
    pause_at("NATRAV_OVERLAY_TEST_REMOTE_SOURCE_REQUEST_BEFORE_COMMIT_MS");
    append_entry(EntryKind::source_subscription, bytes);
    pause_at("NATRAV_OVERLAY_TEST_REMOTE_SOURCE_REQUEST_AFTER_COMMIT_MS");
    return response_for(source_subscriptions_.at(request.grant), "ACCEPTED");
}
RemoteSourceSubscriptionResponse request_remote_source_subscription(
    const RuntimeConfig& config,
    const std::string_view provider,
    const RemoteSourceSubscriptionRequest& request) {
    validate_remote_source_subscription_request(request);
    require_node_id(provider, "remote subscription provider");
    const auto* peer = find_peer(config, provider);
    if (peer == nullptr) {
        app_fail("PEER_NOT_CONFIGURED",
            "remote subscription provider has no configured route");
    }
    const auto* key = find_peer_generation(
        config, provider, peer->active_generation);
    if (key == nullptr || key->state != KeyGenerationState::active ||
        key->spki_sha256 != peer->active_spki_sha256) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_KEY_INVALID",
            "provider requires one exact active key generation");
    }

    TlsContext tls(config.identity);
    std::string last_code = "NO_ENABLED_ROUTE";
    std::string last_detail = "provider has no enabled numeric route";
    for (const auto& route : peer->routes) {
        if (route.state != PeerRouteState::enabled) { continue; }
        try {
            auto session = OutboundPeerSession::open(
                tls,
                config.local_node,
                provider,
                key->generation,
                key->state,
                key->spki_sha256,
                route.locator,
                request.request_id,
                config.io,
                config.sessions);
            const auto message = session.exchange_message(
                request.request_id, ApplicationMessage(request), config.io);
            static_cast<void>(session.close_cleanly(config.io));
            if (const auto* error = std::get_if<ProtocolError>(&message)) {
                if (!error->operation_id.has_value() ||
                    *error->operation_id != request.request_id) {
                    app_fail("REMOTE_ERROR_BINDING_REJECTED",
                        "provider error does not bind the exact request");
                }
                throw AuthenticatedPeerError(
                    error->code, error->detail,
                    authenticated_peer_error_is_terminal(error->code));
            }
            const auto* response =
                std::get_if<RemoteSourceSubscriptionResponse>(&message);
            if (response == nullptr ||
                response->request_id != request.request_id ||
                response->provider != provider ||
                response->grant != request.grant ||
                response->subscriber_generation !=
                    config.local_identity_generation ||
                response->subscriber_spki !=
                    tls.identity_spki_sha256() ||
                response->lease_generation != request.lease_generation) {
                app_fail("SOURCE_SUBSCRIPTION_REMOTE_RESPONSE_BINDING_REJECTED",
                    "provider response does not bind request, provider, grant, and subscriber identity");
            }
            return *response;
        } catch (const AuthenticatedPeerError&) {
            throw;
        } catch (const AppError& error) {
            last_code = error.code();
            last_detail = error.what();
        }
    }
    app_fail("SOURCE_SUBSCRIPTION_REMOTE_UNAVAILABLE",
        "all configured provider routes failed before a bound response: " +
            last_code + ": " + last_detail);
}
} // namespace natrav_overlay
