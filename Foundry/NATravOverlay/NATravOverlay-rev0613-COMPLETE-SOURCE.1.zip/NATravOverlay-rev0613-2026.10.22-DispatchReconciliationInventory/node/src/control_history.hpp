#pragma once
#include "common.hpp"
#include <array>
#include <chrono>
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace natrav_overlay {
// Retained-prefix selections are content comparisons, never permissions.
struct ControlHistoryRequest final {
    std::string section{"decisions"};
    std::optional<std::uint64_t> ordinal;
    std::optional<std::uint32_t> uid;
    std::optional<datacube::Digest32> request_id;
    std::optional<std::uint64_t> configuration_event;
    std::uint64_t offset{0U};
    std::uint32_t limit{16U};
    std::uint32_t maximum_bytes{60'000U};
    std::optional<std::uint64_t> through;
    std::optional<datacube::Digest32> prefix;
};
struct ControlHistoryIndex final {
    std::vector<datacube::Digest32> prefixes;
    std::map<std::uint32_t, std::vector<std::uint32_t>> by_uid;
    std::map<std::array<std::uint8_t,32U>, std::vector<std::uint32_t>> by_request;
    std::map<std::uint64_t, std::vector<std::uint32_t>> by_configuration;
};
void validate_control_history(const ControlHistoryRequest& request);
[[nodiscard]] datacube::Octets encode_control_history(const ControlHistoryRequest& request);
[[nodiscard]] ControlHistoryRequest decode_control_history(datacube::OctetView bytes);
} // namespace natrav_overlay
