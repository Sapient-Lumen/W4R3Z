#include "state_auth.hpp"
#include "state_head_custody.hpp"

#include <algorithm>
#include <charconv>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cerrno>
#include <fcntl.h>
#include <limits>
#include <linux/fs.h>
#include <openssl/core_names.h>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/params.h>
#include <openssl/rand.h>
#include <set>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <thread>
#include <unistd.h>

namespace natrav_overlay {
namespace {
constexpr std::string_view kKeyMagic = "NOSKEY01";
constexpr std::string_view kKeyIdDomain = "NATRAV_OVERLAY_STATE_AUTH_KEY_ID_V1";
constexpr std::string_view kMagic = "NOAUTH01";
constexpr std::string_view kHeaderDomain = "NATRAV_OVERLAY_STATE_AUTH_HEADER_V1";
constexpr std::string_view kRecordDomain = "NATRAV_OVERLAY_STATE_AUTH_RECORD_V1";
constexpr std::size_t kMaximumHeader = 65'536U;
StateAuthKeyPtr configured_key;
std::optional<StateHeadExpectation> configured_expected_head;

struct WipeGuard final {
    datacube::Octets& bytes;
    explicit WipeGuard(datacube::Octets& value) : bytes(value) {}
    ~WipeGuard() { if (!bytes.empty()) { OPENSSL_cleanse(bytes.data(), bytes.size()); } }
};
void crypto_check(int result) {
    if (result != 1) { app_fail("STATE_AUTH_CRYPTO_FAILED", "OpenSSL state authentication operation failed"); }
}
struct KeyLocation final {
    datacube::Fd parent;
    std::string name;
};
KeyLocation key_location(const std::filesystem::path& path) {
    if (path.empty()) { app_fail("STATE_AUTH_KEY_PATH_INVALID", "key path is empty"); }
    for (const auto& part : path) {
        if (part == "..") {
            app_fail("STATE_AUTH_KEY_PATH_INVALID", "dot-dot is forbidden in key paths");
        }
    }
    const auto absolute = std::filesystem::absolute(path).lexically_normal();
    const auto name = absolute.filename().string();
    if (name.empty() || name == "." || name == ".." || name.size() > 160U) {
        app_fail("STATE_AUTH_KEY_PATH_INVALID", "invalid key filename");
    }
    for (const char raw : name) {
        const auto ch = static_cast<unsigned char>(raw);
        if (!((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') ||
              (ch >= '0' && ch <= '9') || ch == '-' || ch == '_' || ch == '.')) {
            app_fail("STATE_AUTH_KEY_PATH_INVALID", "key filename must use safe ASCII");
        }
    }
    datacube::Fd parent(::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC));
    if (!parent) { app_fail("STATE_AUTH_KEY_PATH_INVALID", "cannot open root directory"); }
    for (const auto& part : absolute.parent_path().relative_path()) {
        const int raw = ::openat(parent.get(), part.c_str(),
            O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
        if (raw < 0) {
            app_fail("STATE_AUTH_KEY_PATH_INVALID", "key parent must be a real directory without symlinks");
        }
        parent.reset(raw);
    }
    struct stat status{};
    if (::fstat(parent.get(), &status) != 0 || status.st_uid != ::geteuid() ||
        (status.st_mode & (S_IWGRP | S_IWOTH)) != 0) {
        app_fail("STATE_AUTH_KEY_PARENT_UNSAFE", "key parent must be effective-user owned and not writable by others");
    }
    return {.parent = std::move(parent), .name = name};
}

void text16(datacube::Octets& bytes, std::string_view text) {
    datacube::append_be16(bytes, static_cast<std::uint16_t>(text.size()));
    datacube::append_text(bytes, text);
}
std::string read_generation(datacube::Reader& reader) {
    const auto count = reader.read_be16("state authentication key generation size");
    if (count == 0U || count > 64U) {
        app_fail("STATE_AUTH_KEY_FORMAT_INVALID", "generation size is invalid");
    }
    const auto generation = datacube::octets_text(
        reader.read_exact(count, "state authentication key generation"), "generation", true);
    require_generation_id(generation, "state authentication key generation");
    return generation;
}

datacube::Digest32 key_id(std::string_view generation, datacube::OctetView secret) {
    datacube::Octets input;
    WipeGuard wipe(input);
    datacube::append_text(input, kKeyIdDomain);
    text16(input, generation);
    datacube::append_octets(input, secret);
    return datacube::sha256(input);
}

std::shared_ptr<StateAuthKey> read_key(const std::filesystem::path& path) {
    auto location = key_location(path);
    const int raw = ::openat(location.parent.get(), location.name.c_str(),
        O_RDONLY | O_NONBLOCK | O_CLOEXEC | O_NOFOLLOW);
    if (raw < 0) { app_fail("STATE_AUTH_KEY_OPEN_FAILED", "cannot open state authentication key"); }
    datacube::Fd fd(raw);
    struct stat status{};
    if (::fstat(fd.get(), &status) != 0 || !S_ISREG(status.st_mode) ||
        status.st_uid != ::geteuid() || (status.st_mode & 07777U) != 0600U ||
        status.st_nlink != 1 || status.st_size < 47 || status.st_size > 110) {
        app_fail("STATE_AUTH_KEY_FILE_UNSAFE", "key must be single-link, effective-user-owned, exact mode 0600, and bounded");
    }
    auto bytes = datacube::read_all_fd(fd.get(), 110U, "state authentication key");
    WipeGuard wipe(bytes);
    if (bytes.size() != static_cast<std::size_t>(status.st_size)) {
        app_fail("STATE_AUTH_KEY_FILE_UNSAFE", "key size changed while reading");
    }
    try {
    datacube::Reader reader(bytes, "state authentication key");
    if (datacube::octets_text(reader.read_exact(8U, "key magic"), "magic", true) != kKeyMagic ||
        reader.read_be32("key version") != 1U) {
        app_fail("STATE_AUTH_KEY_FORMAT_INVALID", "unsupported state authentication key format");
    }
    auto key = std::make_shared<StateAuthKey>();
    key->generation = read_generation(reader);
    const auto raw_key = reader.read_exact(32U, "key material");
    std::copy(raw_key.begin(), raw_key.end(), key->secret.begin());
    reader.require_eof("state authentication key");
    key->id = key_id(key->generation, key->secret);
    return key;
    } catch (const datacube::Failure&) {
        app_fail("STATE_AUTH_KEY_FORMAT_INVALID", "malformed or trailing state authentication key material");
    }
}

void write_key(const KeyLocation& location, datacube::OctetView bytes) {
    std::array<std::uint8_t, 16> random{};
    crypto_check(RAND_bytes(random.data(), static_cast<int>(random.size())));
    const std::string stage = ".natrav-state-key-" + hex_bytes(random) + ".tmp";
    bool published = false;
    try {
        datacube::Fd fd(::openat(location.parent.get(), stage.c_str(),
            O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600));
        if (!fd || ::fchmod(fd.get(), 0600) != 0) {
            app_fail("STATE_AUTH_KEY_WRITE_FAILED", "cannot create owner-only key staging file");
        }
        std::size_t offset = 0U;
        while (offset < bytes.size()) {
            const auto n = ::write(fd.get(), bytes.data() + offset, bytes.size() - offset);
            if (n < 0 && errno == EINTR) { continue; }
            if (n <= 0) { app_fail("STATE_AUTH_KEY_WRITE_FAILED", "key write failed"); }
            offset += static_cast<std::size_t>(n);
        }
        if (::fsync(fd.get()) != 0) { app_fail("STATE_AUTH_KEY_WRITE_FAILED", "key sync failed"); }
        state_auth_test_pause("KEY_BEFORE_PUBLISH");
        if (::syscall(SYS_renameat2, location.parent.get(), stage.c_str(),
                location.parent.get(), location.name.c_str(), RENAME_NOREPLACE) != 0) {
            app_fail(errno == EEXIST ? "STATE_AUTH_KEY_EXISTS" : "STATE_AUTH_KEY_WRITE_FAILED",
                "key publication failed; no overwrite is permitted");
        }
        published = true;
        if (::fsync(location.parent.get()) != 0) {
            app_fail("STATE_AUTH_KEY_SYNC_FAILED", "key published but parent sync failed; inspect destination");
        }
        state_auth_test_pause("KEY_AFTER_PUBLISH");
    } catch (...) {
        if (!published) { static_cast<void>(::unlinkat(location.parent.get(), stage.c_str(), 0)); }
        throw;
    }
}

std::uint64_t now_ms() {
    const auto n = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    if (n <= 0) { app_fail("CLOCK_INVALID", "state authentication requires a valid clock"); }
    return static_cast<std::uint64_t>(n);
}
void digest(datacube::Octets& out, const datacube::Digest32& d) {
    datacube::append_octets(out, d.octets);
}
datacube::Digest32 read_digest(datacube::Reader& r) {
    datacube::Digest32 d;
    const auto v = r.read_exact(32U, "digest");
    std::copy(v.begin(), v.end(), d.octets.begin());
    return d;
}
std::string read_text(datacube::Reader& r, std::size_t maximum) {
    const auto n = r.read_be16("text length");
    if (n == 0U || n > maximum) { app_fail("STATE_AUTH_FORMAT_INVALID", "invalid bounded text length"); }
    return datacube::octets_text(r.read_exact(n, "text"), "text", true);
}
void require_reason(std::string_view reason) {
    if (reason.empty() || reason.size() > 512U ||
        !std::all_of(reason.begin(), reason.end(), [](char c) { return c >= 32 && c <= 126; })) {
        app_fail("STATE_AUTH_REASON_INVALID", "reason must be 1..512 printable ASCII bytes");
    }
}
datacube::Digest32 mac(const StateAuthKeyPtr& key, std::string_view domain,
                      datacube::OctetView anchor, datacube::OctetView bytes) {
    if (!key) { app_fail("STATE_AUTH_KEY_REQUIRED", "an explicit state authentication key is required"); }
    std::unique_ptr<EVP_MAC, decltype(&EVP_MAC_free)> algorithm(
        EVP_MAC_fetch(nullptr, "HMAC", nullptr), EVP_MAC_free);
    if (!algorithm) { app_fail("STATE_AUTH_CRYPTO_FAILED", "HMAC unavailable"); }
    std::unique_ptr<EVP_MAC_CTX, decltype(&EVP_MAC_CTX_free)> ctx(
        EVP_MAC_CTX_new(algorithm.get()), EVP_MAC_CTX_free);
    if (!ctx) { app_fail("STATE_AUTH_CRYPTO_FAILED", "HMAC context unavailable"); }
    char name[] = "SHA256";
    OSSL_PARAM params[] = {
        OSSL_PARAM_construct_utf8_string(OSSL_MAC_PARAM_DIGEST, name, 0U),
        OSSL_PARAM_construct_end()
    };
    crypto_check(EVP_MAC_init(ctx.get(), key->secret.data(), key->secret.size(), params));
    crypto_check(EVP_MAC_update(ctx.get(), reinterpret_cast<const unsigned char*>(domain.data()), domain.size()));
    const unsigned char zero = 0;
    crypto_check(EVP_MAC_update(ctx.get(), &zero, 1U));
    if (!anchor.empty()) { crypto_check(EVP_MAC_update(ctx.get(), anchor.data(), anchor.size())); }
    crypto_check(EVP_MAC_update(ctx.get(), bytes.data(), bytes.size()));
    datacube::Digest32 result;
    std::size_t n = 0U;
    crypto_check(EVP_MAC_final(ctx.get(), result.octets.data(), &n, result.octets.size()));
    if (n != result.octets.size()) { app_fail("STATE_AUTH_CRYPTO_FAILED", "unexpected HMAC size"); }
    return result;
}
void verify_mac(const datacube::Digest32& expected, const datacube::Digest32& actual) {
    if (CRYPTO_memcmp(expected.octets.data(), actual.octets.data(), 32U) != 0) {
        app_fail("STATE_AUTH_TAG_MISMATCH", "authenticated state verification failed");
    }
}
void validate_history(const StateAuthentication& info) {
    if (info.history.empty() || info.history.size() > 64U) {
        app_fail("STATE_AUTH_HISTORY_INVALID", "authentication history must contain 1..64 transitions");
    }
    std::set<std::string> generations;
    std::set<std::string> keys;
    for (std::size_t i = 0; i < info.history.size(); ++i) {
        const auto& h = info.history[i];
        require_generation_id(h.generation, "state key generation");
        require_reason(h.reason);
        if (h.kind != (i == 0U ? "MIGRATE" : "ROTATE") || h.unix_ms == 0U ||
            digest_is_zero(h.key_id) || digest_is_zero(h.source_root) ||
            !generations.insert(h.generation).second || !keys.insert(datacube::hex_lower(h.key_id)).second) {
            app_fail("STATE_AUTH_HISTORY_INVALID", "invalid or reused authentication generation");
        }
    }
    if (info.history.back().generation != info.generation || info.history.back().key_id != info.key_id ||
        digest_is_zero(info.epoch) || digest_is_zero(info.checkpoint_logical_digest)) {
        app_fail("STATE_AUTH_HISTORY_INVALID", "active key does not match authentication history");
    }
    if (info.purpose != "MIGRATE" && info.purpose != "ROTATE" &&
        info.purpose != "COMPACT" && info.purpose != "BACKUP" && info.purpose != "RECOVER") {
        app_fail("STATE_AUTH_FORMAT_INVALID", "unknown authenticated checkpoint purpose");
    }
    if (info.recoveries.size() > 64U || (info.purpose == "RECOVER" && info.recoveries.empty())) {
        app_fail("STATE_AUTH_RECOVERY_HISTORY_INVALID", "invalid recovery history size");
    }
    for (const auto& r : info.recoveries) {
        require_reason(r.reason);
        const auto generation = std::find_if(info.history.begin(), info.history.end(),
            [&r](const StateAuthTransition& t) { return t.generation == r.generation && t.key_id == r.key_id; });
        if (generation == info.history.end() || r.unix_ms == 0U || r.pid == 0U || r.selected_records == 0U ||
            r.prefix_bytes == 0U || r.source_bytes <= r.prefix_bytes ||
            r.source_bytes > 1'073'741'824U || digest_is_zero(r.source_digest) ||
            digest_is_zero(r.discarded_digest) || digest_is_zero(r.prefix_digest) ||
            digest_is_zero(r.selected_root) || digest_is_zero(r.selected_epoch)) {
            app_fail("STATE_AUTH_RECOVERY_HISTORY_INVALID", "invalid selected-prefix recovery provenance");
        }
    }
    if (info.purpose == "RECOVER" && (info.parent_root != info.recoveries.back().selected_root ||
        info.generation != info.recoveries.back().generation || info.key_id != info.recoveries.back().key_id)) {
        app_fail("STATE_AUTH_RECOVERY_HISTORY_INVALID", "recovery predecessor does not match selection");
    }
}

} // namespace

StateAuthKey::~StateAuthKey() { OPENSSL_cleanse(secret.data(), secret.size()); }
StateAuthKeyPtr load_state_auth_key(const std::filesystem::path& path) { return read_key(path); }
void configure_process_state_auth_key(const std::filesystem::path& path) {
    if (configured_key) { app_fail("STATE_AUTH_CONFIGURATION_INVALID", "process key may only be set once before service starts"); }
    configured_key = load_state_auth_key(path);
}
StateAuthKeyPtr process_state_auth_key() { return configured_key; }

std::string initialize_state_auth_key(const std::filesystem::path& path, std::string_view generation) {
    require_generation_id(generation, "state authentication generation");
    auto location = key_location(path);
    StateAuthKey key;
    key.generation = generation;
    crypto_check(RAND_priv_bytes(key.secret.data(), static_cast<int>(key.secret.size())));
    key.id = key_id(generation, key.secret);
    datacube::Octets bytes;
    WipeGuard wipe(bytes);
    datacube::append_text(bytes, kKeyMagic);
    datacube::append_be32(bytes, 1U);
    text16(bytes, generation);
    datacube::append_octets(bytes, key.secret);
    write_key(location, bytes);
    return "{\"format\":\"NATRAV_OVERLAY_STATE_AUTH_KEY_V1\",\"ok\":true,\"generation\":" +
        json_string(key.generation) + ",\"key_id\":" + json_string(datacube::hex_lower(key.id)) +
        ",\"purpose\":\"STATE_AUTHENTICATION\",\"key_bits\":256}";
}

bool is_authenticated_journal(datacube::OctetView bytes) noexcept {
    return bytes.size() >= kMagic.size() && std::equal(kMagic.begin(), kMagic.end(), bytes.begin());
}

datacube::Octets authenticate_next_frame(datacube::OctetView frame,
                                        const StateAuthKeyPtr& key,
                                        StateAuthentication& next) {
    if (frame.size() < 41U || frame.size() > 1'073'741'824U ||
        next.records == std::numeric_limits<std::uint64_t>::max()) {
        app_fail("STATE_AUTH_LIMIT", "authenticated frame or sequence exceeds its bound");
    }
    datacube::Octets out;
    out.reserve(frame.size() + 80U);
    datacube::append_text(out, "NAR1");
    datacube::append_be32(out, static_cast<std::uint32_t>(frame.size()));
    datacube::append_be64(out, next.records + 1U);
    digest(out, next.root);
    datacube::append_octets(out, frame);
    const auto tag = mac(key, kRecordDomain, next.header_tag.octets, out);
    digest(out, tag);
    next.root = tag;
    ++next.records;
    return out;
}

AuthenticatedJournal authenticate_checkpoint(
    datacube::OctetView frame, std::string_view node, const StateAuthKeyPtr& key,
    const StateAuthentication* previous, const datacube::Digest32& logical,
    std::string_view purpose, std::string_view reason,
    const datacube::Digest32& unkeyed_source) {
    if (!key) { app_fail("STATE_AUTH_KEY_REQUIRED", "checkpoint authentication requires an explicit key"); }
    StateAuthentication info;
    info.generation = key->generation;
    info.key_id = key->id;
    crypto_check(RAND_bytes(info.epoch.octets.data(), 32));
    info.parent_root = previous ? previous->root : unkeyed_source;
    info.checkpoint_logical_digest = logical;
    info.purpose = purpose;
    if (previous) { info.history = previous->history; info.recoveries = previous->recoveries; }
    if (purpose == "MIGRATE" || purpose == "ROTATE") {
        require_reason(reason);
        if ((purpose == "MIGRATE") != (previous == nullptr)) {
            app_fail("STATE_AUTH_TRANSITION_INVALID", "migration or rotation predecessor mismatch");
        }
        info.history.push_back(StateAuthTransition{
            .kind = std::string(purpose), .generation = key->generation, .key_id = key->id,
            .unix_ms = now_ms(), .uid = static_cast<std::uint32_t>(::geteuid()),
            .reason = std::string(reason), .source_root = info.parent_root,
        });
    } else if (!previous || previous->key_id != key->id || previous->generation != key->generation) {
        app_fail("STATE_AUTH_TRANSITION_INVALID", "representation rewrite cannot silently rekey");
    }
    validate_history(info);
    datacube::Octets body;
    datacube::append_be32(body, info.recoveries.empty() ? 1U : 2U); // V2 adds bounded recovery provenance
    datacube::append_be32(body, 2U); // storage schema bound into MAC
    text16(body, node);
    text16(body, info.generation);
    digest(body, info.key_id);
    digest(body, info.epoch);
    digest(body, info.parent_root);
    digest(body, logical);
    text16(body, purpose);
    datacube::append_be16(body, static_cast<std::uint16_t>(info.history.size()));
    for (const auto& h : info.history) {
        datacube::append_u8(body, h.kind == "MIGRATE" ? 1U : 2U);
        text16(body, h.generation);
        digest(body, h.key_id);
        datacube::append_be64(body, h.unix_ms);
        datacube::append_be32(body, h.uid);
        text16(body, h.reason);
        digest(body, h.source_root);
    }
    if (!info.recoveries.empty()) {
        datacube::append_be16(body, static_cast<std::uint16_t>(info.recoveries.size()));
        for (const auto& r : info.recoveries) {
            digest(body, r.source_digest); digest(body, r.discarded_digest);
            digest(body, r.prefix_digest); digest(body, r.selected_root); digest(body, r.selected_epoch);
            text16(body, r.generation); digest(body, r.key_id);
            datacube::append_be64(body, r.selected_records);
            datacube::append_be64(body, r.source_bytes); datacube::append_be64(body, r.prefix_bytes);
            datacube::append_be64(body, r.unix_ms);
            datacube::append_be32(body, r.uid); datacube::append_be32(body, r.pid);
            text16(body, r.reason);
        }
    }
    if (body.size() > kMaximumHeader) { app_fail("STATE_AUTH_HISTORY_LIMIT", "authentication header is full"); }
    datacube::Octets out;
    datacube::append_text(out, kMagic);
    datacube::append_be32(out, static_cast<std::uint32_t>(body.size()));
    datacube::append_octets(out, body);
    info.header_tag = mac(key, kHeaderDomain, {}, out);
    digest(out, info.header_tag);
    info.root = info.header_tag;
    info.checkpoint_overhead = out.size() + 80U;
    const auto record = authenticate_next_frame(frame, key, info);
    datacube::append_octets(out, record);
    return {.bytes = std::move(out), .authentication = std::move(info)};
}

AuthenticatedScan scan_authenticated_journal(datacube::OctetView bytes, std::string_view node,
                                               const StateAuthKeyPtr& key, std::uint64_t maximum_bytes) {
    AuthenticatedScan result;
    try {
        if (!key) { app_fail("STATE_AUTH_KEY_REQUIRED", "supply an explicit state key"); }
        if (bytes.size() > maximum_bytes) { app_fail("STATE_AUTH_LIMIT", "journal exceeds configured size"); }
        if (!is_authenticated_journal(bytes)) { app_fail("STATE_AUTH_REQUIRED", "authenticated header required"); }
        datacube::Reader reader(bytes, "authenticated journal");
        if (datacube::octets_text(reader.read_exact(8U, "magic"), "magic", true) != kMagic) {
            app_fail("STATE_AUTH_REQUIRED", "keyed launch never falls back to an unkeyed journal");
        }
        const auto n = reader.read_be32("header length");
        if (n == 0U || n > kMaximumHeader) { app_fail("STATE_AUTH_FORMAT_INVALID", "invalid header length"); }
        const auto body = reader.read_exact(n, "header");
        const auto actual_tag = read_digest(reader);
        const auto expected_tag = mac(key, kHeaderDomain, {}, bytes.first(12U + n));
        verify_mac(expected_tag, actual_tag); // Verify before parsing any header fields.
        datacube::Reader h(body, "authenticated header");
        const auto version = h.read_be32("version");
        if ((version != 1U && version != 2U) || h.read_be32("schema") != 2U || read_text(h, 64U) != node) {
            app_fail("STATE_AUTH_BINDING_MISMATCH", "authenticated schema or node mismatch");
        }
        auto& info = result.verified.authentication;
        info.generation = read_text(h, 64U);
        info.key_id = read_digest(h);
        info.epoch = read_digest(h);
        info.parent_root = read_digest(h);
        info.checkpoint_logical_digest = read_digest(h);
        info.purpose = read_text(h, 16U);
        info.header_tag = actual_tag;
        info.root = actual_tag;
        info.checkpoint_overhead = 12U + n + 32U + 80U;
        if (info.generation != key->generation || info.key_id != key->id) {
            app_fail("STATE_AUTH_KEY_MISMATCH", "authenticated key identity mismatch");
        }
        const auto count = h.read_be16("history count");
        if (count == 0U || count > 64U) { app_fail("STATE_AUTH_HISTORY_INVALID", "history count is invalid"); }
        for (std::size_t i = 0U; i < count; ++i) {
            StateAuthTransition t;
            const auto kind = h.read_u8("transition kind");
            if (kind != 1U && kind != 2U) { app_fail("STATE_AUTH_HISTORY_INVALID", "unknown transition"); }
            t.kind = kind == 1U ? "MIGRATE" : "ROTATE";
            t.generation = read_text(h, 64U);
            t.key_id = read_digest(h);
            t.unix_ms = h.read_be64("transition time");
            t.uid = h.read_be32("transition uid");
            t.reason = read_text(h, 512U);
            t.source_root = read_digest(h);
            info.history.push_back(std::move(t));
        }
        if (version == 2U) {
            const auto recovery_count = h.read_be16("recovery count");
            if (recovery_count == 0U || recovery_count > 64U) {
                app_fail("STATE_AUTH_RECOVERY_HISTORY_INVALID", "invalid recovery history count");
            }
            for (std::size_t i = 0; i < recovery_count; ++i) {
                StateAuthRecovery r;
                r.source_digest = read_digest(h); r.discarded_digest = read_digest(h);
                r.prefix_digest = read_digest(h); r.selected_root = read_digest(h); r.selected_epoch = read_digest(h);
                r.generation = read_text(h, 64U); r.key_id = read_digest(h);
                r.selected_records = h.read_be64("selected sequence");
                r.source_bytes = h.read_be64("source size"); r.prefix_bytes = h.read_be64("prefix size");
                r.unix_ms = h.read_be64("recovery time");
                r.uid = h.read_be32("recovery uid"); r.pid = h.read_be32("recovery pid");
                r.reason = read_text(h, 512U);
                info.recoveries.push_back(std::move(r));
            }
        }
        h.require_eof("authentication header");
        validate_history(info);

        result.header_authenticated = true;
        result.verified_bytes = bytes.size() - reader.remaining();
        auto& plain = result.verified.plain_frames;
        while (reader.remaining() != 0U) {
            const auto begin = bytes.size() - reader.remaining();
            const auto tail = bytes.subspan(begin);
            constexpr std::string_view magic = "NAR1";
            if (!std::equal(tail.begin(), tail.begin() + static_cast<std::ptrdiff_t>(std::min<std::size_t>(4U, tail.size())), magic.begin())) {
                app_fail("STATE_AUTH_FORMAT_INVALID", "record magic mismatch");
            }
            const auto incomplete = [&]() {
                result.status = info.records > 0U ? "INCOMPLETE_TAIL" : "INVALID";
                result.code = "STATE_AUTH_TRUNCATED";
            };
            if (tail.size() < 8U) { incomplete(); return result; }
            datacube::Reader record(tail, "authenticated record");
            static_cast<void>(record.read_exact(4U, "magic"));
            const auto length = record.read_be32("frame size");
            if (length < 41U || length > maximum_bytes || info.records == std::numeric_limits<std::uint64_t>::max()) {
                app_fail("STATE_AUTH_CHAIN_MISMATCH", "record length or sequence exceeds bounds");
            }
            // Check every available byte of sequence and predecessor, even in a
            // truncated record. Clearly malformed material is never a torn tail.
            datacube::Octets expected;
            datacube::append_be64(expected, info.records + 1U); digest(expected, info.root);
            const auto available = std::min<std::size_t>(40U, tail.size() - 8U);
            if (!std::equal(tail.begin() + 8, tail.begin() + 8 + static_cast<std::ptrdiff_t>(available), expected.begin())) {
                app_fail("STATE_AUTH_CHAIN_MISMATCH", "record sequence or predecessor mismatch");
            }
            if (tail.size() < 80U + static_cast<std::uint64_t>(length)) {
                if (tail.size() > 48U) {
                    constexpr std::string_view inner_magic = "NOJ1";
                    const auto nmagic = std::min<std::size_t>(4U, tail.size() - 48U);
                    if (!std::equal(tail.begin() + 48, tail.begin() + 48 + static_cast<std::ptrdiff_t>(nmagic), inner_magic.begin())) {
                        app_fail("STATE_AUTH_FORMAT_INVALID", "incomplete inner magic mismatch");
                    }
                    if (tail.size() >= 56U) {
                        datacube::Reader inner(tail.subspan(52U, 4U), "inner length");
                        if (static_cast<std::uint64_t>(inner.read_be32("length")) + 40U != length) {
                            app_fail("STATE_AUTH_FORMAT_INVALID", "incomplete inner and outer lengths disagree");
                        }
                    }
                }
                incomplete(); return result;
            }
            static_cast<void>(record.read_exact(40U, "sequence and predecessor"));
            const auto frame = record.read_exact(length, "journal frame");
            const auto tag = read_digest(record);
            verify_mac(mac(key, kRecordDomain, info.header_tag.octets, tail.first(48U + length)), tag);
            if (frame[0] != 'N' || frame[1] != 'O' || frame[2] != 'J' || frame[3] != '1' ||
                (info.records == 0U && frame[8] != 18U)) {
                app_fail("STATE_AUTH_FORMAT_INVALID", "authenticated stream must begin with a checkpoint");
            }
            datacube::Reader inner(frame.subspan(4U, 4U), "inner length");
            if (static_cast<std::uint64_t>(inner.read_be32("length")) + 40U != frame.size()) {
                app_fail("STATE_AUTH_FORMAT_INVALID", "tag must cover exactly one journal frame");
            }
            datacube::append_octets(plain, frame);
            info.root = tag; ++info.records;
            result.verified_bytes = begin + 80U + length;
            static_cast<void>(reader.read_exact(80U + length, "verified record"));
        }
        if (info.records == 0U) { app_fail("STATE_AUTH_TRUNCATED", "header has no complete checkpoint"); }
        result.status = "COMPLETE";
        return result;
    } catch (const AppError& error) {
        result.code = error.code();
    } catch (const datacube::Failure&) {
        result.code = "STATE_AUTH_TRUNCATED";
    }
    result.status = "INVALID";
    return result;
}

VerifiedJournal verify_authenticated_journal(datacube::OctetView bytes, std::string_view node,
                                             const StateAuthKeyPtr& key, std::uint64_t maximum_bytes) {
    auto scanned = scan_authenticated_journal(bytes, node, key, maximum_bytes);
    if (scanned.status != "COMPLETE") {
        app_fail(scanned.code, "authenticated journal rejected; no tail was discarded");
    }
    return std::move(scanned.verified);
}

StateHeadExpectation parse_state_head_expectation(const std::string_view selector) {
    // Bounded canonical text, not a pathname, key, signed assertion, or permission.
    constexpr std::size_t maximum_selector = 512U;
    if (selector.empty() || selector.size() > maximum_selector) {
        app_fail("STATE_HEAD_EXPECTATION_INVALID", "expected NASH1 selector is empty or oversized");
    }
    std::array<std::string_view, 8U> fields{};
    std::size_t start = 0U;
    for (std::size_t i = 0U; i < fields.size(); ++i) {
        const auto end = selector.find(':', start);
        if ((i + 1U == fields.size()) != (end == std::string_view::npos)) {
            app_fail("STATE_HEAD_EXPECTATION_INVALID", "expected exactly eight NASH1 fields");
        }
        fields[i] = selector.substr(start, end == std::string_view::npos ? end : end - start);
        start = end == std::string_view::npos ? selector.size() : end + 1U;
    }
    const auto number = [](const std::string_view field, const std::uint64_t maximum) {
        std::uint64_t result = 0U;
        const auto parsed = std::from_chars(field.data(), field.data() + field.size(), result);
        if (field.empty() || parsed.ec != std::errc{} || parsed.ptr != field.data() + field.size() ||
            result == 0U || result > maximum || std::to_string(result) != field) {
            app_fail("STATE_HEAD_EXPECTATION_INVALID", "head counts require positive bounded canonical decimal integers");
        }
        return result;
    };
    if (fields[0] != "NASH1") {
        app_fail("STATE_HEAD_EXPECTATION_INVALID", "unknown expected-state-head selector version");
    }
    try {
        require_node_id(fields[1], "expected node");
        require_generation_id(fields[2], "expected authentication generation");
        return StateHeadExpectation{std::string(fields[1]), std::string(fields[2]),
            parse_operation_id(fields[3]), parse_operation_id(fields[4]), parse_operation_id(fields[5]),
            number(fields[6], 1'073'741'824U), number(fields[7], 1'073'741'824U)};
    } catch (const AppError&) {
        app_fail("STATE_HEAD_EXPECTATION_INVALID", "invalid expected authenticated-state head");
    } catch (const datacube::Failure&) {
        app_fail("STATE_HEAD_EXPECTATION_INVALID", "invalid expected authenticated-state head");
    }
}

void configure_process_state_head_expectation(const std::string_view selector) {
    if (configured_expected_head) {
        app_fail("STATE_HEAD_EXPECTATION_INVALID", "state expectation can be configured only once");
    }
    auto parsed = parse_state_head_expectation(selector);
    if (!process_state_auth_key()) {
        app_fail("STATE_AUTH_KEY_REQUIRED", "an expected state head requires an explicit state authentication key");
    }
    configured_expected_head = std::move(parsed);
}

const std::optional<StateHeadExpectation>& process_state_head_expectation() {
    return configured_expected_head;
}

bool matches_state_head(const StateHeadExpectation& expected, const std::string_view node,
    const StateAuthentication& authentication, const std::uint64_t bytes) {
    return expected.node == node && expected.generation == authentication.generation &&
        expected.key_id == authentication.key_id && expected.epoch == authentication.epoch &&
        expected.root == authentication.root && expected.records == authentication.records &&
        expected.journal_bytes == bytes;
}

std::string state_head_selector(const std::string_view node,
    const StateAuthentication& authentication, const std::uint64_t bytes) {
    require_node_id(node, "state-head node");
    if (authentication.records == 0U || bytes == 0U) {
        app_fail("STATE_AUTH_REQUIRED",
            "an authenticated nonempty representation is required for a state-head selector");
    }
    return "NASH1:" + std::string(node) + ":" + authentication.generation + ":" +
        datacube::hex_lower(authentication.key_id) + ":" +
        datacube::hex_lower(authentication.epoch) + ":" +
        datacube::hex_lower(authentication.root) + ":" +
        std::to_string(authentication.records) + ":" + std::to_string(bytes);
}

void enforce_expected_state_head(const std::string_view node,
    const std::optional<StateAuthentication>& authentication, const std::uint64_t bytes) {
    const auto& expected = process_state_head_expectation();
    if (!expected) { return; }
    if (!authentication) {
        app_fail("STATE_AUTH_REQUIRED", "an expected head cannot authenticate unkeyed state");
    }
    if (!matches_state_head(*expected, node, *authentication, bytes)) {
        app_fail("STATE_HEAD_EXPECTATION_MISMATCH", "authenticated input differs from the explicitly supplied exact head");
    }
    recheck_process_state_head_custody_constraint(
        StateHeadCustodyRecheckPoint::authenticated_input);
}

std::string state_head_json(const std::string_view node,
    const std::optional<StateAuthentication>& authentication, const std::uint64_t bytes,
    const bool compare_expectation) {
    const auto& expected = process_state_head_expectation();
    const bool match = compare_expectation && expected && authentication &&
        matches_state_head(*expected, node, *authentication, bytes);
    std::string selector;
    if (authentication && authentication->records > 0U) {
        selector = state_head_selector(node, *authentication, bytes);
    }
    const std::string_view comparison = !compare_expectation ? "NOT_CHECKED_HERE" :
        !expected ? "NOT_SUPPLIED" : match ? "MATCH" : "MISMATCH";
    return "{\"format\":\"NATRAV_OVERLAY_STATE_HEAD_V1\",\"selector\":" +
        (selector.empty() ? "null" : json_string(selector)) +
        ",\"expectation\":" + json_string(comparison) +
        ",\"freshness\":" + json_string(match ? "MATCHED_SUPPLIED_EXPECTATION" : "NOT_ESTABLISHED") +
        ",\"trust\":\"CALLER_MUST_PROTECT_EXPECTATION_SEPARATELY\",\"automatic_update\":false}";
}

std::string state_authentication_json(const std::optional<StateAuthentication>& value, const bool bounded) {
    if (!value) { return "{\"mode\":\"UNKEYED\"}"; }
    const auto& v = *value;
    std::string out = "{\"mode\":\"HMAC_SHA256_CHAIN_V1\",\"generation\":" + json_string(v.generation) +
        ",\"key_id\":" + json_string(datacube::hex_lower(v.key_id)) +
        ",\"epoch\":" + json_string(datacube::hex_lower(v.epoch)) +
        ",\"root\":" + json_string(datacube::hex_lower(v.root)) +
        ",\"parent_root\":" + json_string(datacube::hex_lower(v.parent_root)) +
        ",\"records\":" + std::to_string(v.records) + ",\"purpose\":" + json_string(v.purpose) +
        ",\"freshness\":\"NOT_ESTABLISHED\",\"history\":[";
    bool first = true;
    const auto history_start = bounded && v.history.size() > 4U ? v.history.size() - 4U : 0U;
    for (std::size_t index = history_start; index < v.history.size(); ++index) {
        const auto& h = v.history[index];
        if (!first) { out += ','; } first = false;
        out += "{\"kind\":" + json_string(h.kind) + ",\"generation\":" + json_string(h.generation) +
            ",\"key_id\":" + json_string(datacube::hex_lower(h.key_id)) +
            ",\"state\":" + json_string(h.generation == v.generation ? "ACTIVE" : "RETIRED") +
            ",\"unix_ms\":" + std::to_string(h.unix_ms) + ",\"uid\":" + std::to_string(h.uid) +
            ",\"reason\":" + json_string(h.reason) +
            ",\"source_root\":" + json_string(datacube::hex_lower(h.source_root)) + "}";
    }
    out += "],\"recoveries\":[";
    first = true;
    const auto recovery_start = bounded && v.recoveries.size() > 4U ? v.recoveries.size() - 4U : 0U;
    for (std::size_t index = recovery_start; index < v.recoveries.size(); ++index) {
        const auto& r = v.recoveries[index];
        if (!first) { out += ','; } first = false;
        out += "{\"source_sha256\":" + json_string(datacube::hex_lower(r.source_digest)) +
            ",\"discarded_sha256\":" + json_string(datacube::hex_lower(r.discarded_digest)) +
            ",\"prefix_sha256\":" + json_string(datacube::hex_lower(r.prefix_digest)) +
            ",\"selected_root\":" + json_string(datacube::hex_lower(r.selected_root)) +
            ",\"selected_epoch\":" + json_string(datacube::hex_lower(r.selected_epoch)) +
            ",\"generation\":" + json_string(r.generation) + ",\"key_id\":" + json_string(datacube::hex_lower(r.key_id)) +
            ",\"selected_records\":" + std::to_string(r.selected_records) +
            ",\"source_bytes\":" + std::to_string(r.source_bytes) +
            ",\"prefix_bytes\":" + std::to_string(r.prefix_bytes) +
            ",\"discarded_bytes\":" + std::to_string(r.source_bytes - r.prefix_bytes) +
            ",\"unix_ms\":" + std::to_string(r.unix_ms) +
            ",\"uid\":" + std::to_string(r.uid) + ",\"pid\":" + std::to_string(r.pid) +
            ",\"reason\":" + json_string(r.reason) +
            ",\"decision\":\"EXPLICIT_PREFIX_ADOPTION\",\"cause\":\"NOT_ESTABLISHED\"}";
    }
    if (bounded) return out + "],\"history_count\":" + std::to_string(v.history.size()) +
        ",\"history_truncated\":" + (history_start ? "true" : "false") +
        ",\"recovery_count\":" + std::to_string(v.recoveries.size()) +
        ",\"recoveries_truncated\":" + (recovery_start ? "true" : "false") + "}";
    return out + "]}";
}

void state_auth_test_pause(std::string_view point) {
    const auto name = "NATRAV_OVERLAY_TEST_STATE_AUTH_" + std::string(point) + "_MS";
    const char* raw = std::getenv(name.c_str());
    if (!raw) { return; }
    const auto duration = parse_milliseconds(raw, name, 1U, 10'000U);
    const auto marker = "STATE_AUTH_TEST_PAUSE " + std::string(point) + "\n";
    static_cast<void>(std::fwrite(marker.data(), 1U, marker.size(), stderr));
    static_cast<void>(std::fflush(stderr));
    std::this_thread::sleep_for(duration);
}
} // namespace natrav_overlay
