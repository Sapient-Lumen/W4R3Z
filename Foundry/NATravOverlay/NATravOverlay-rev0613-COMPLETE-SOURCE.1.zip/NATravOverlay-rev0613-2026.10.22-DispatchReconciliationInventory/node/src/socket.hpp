#pragma once

#include "protocol.hpp"

#include "datacube/natrav_peer_session.hpp"
#include "datacube/natrav_peer_stream.hpp"

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <filesystem>
#include <span>
#include <string>
#include <string_view>

namespace natrav_overlay {

struct IoOptions final {
    std::chrono::milliseconds timeout{3000};
    std::size_t read_quantum{4096U};
    std::size_t write_quantum{4096U};
    std::size_t maximum_received_bytes{131'080U};
};

struct IoCounters final {
    std::size_t poll_calls{0U};
    std::size_t read_calls{0U};
    std::size_t write_calls{0U};
    std::size_t read_bytes{0U};
    std::size_t write_bytes{0U};
    std::size_t short_reads{0U};
    std::size_t short_writes{0U};
    std::size_t interrupted{0U};
    std::size_t would_block{0U};
    std::size_t frames_read{0U};
};

using Deadline = std::chrono::steady_clock::time_point;
[[nodiscard]] Deadline deadline_after(std::chrono::milliseconds duration);
void validate_io_options(const IoOptions& options);

class ByteChannel {
public:
    virtual ~ByteChannel() = default;
    ByteChannel(const ByteChannel&) = delete;
    ByteChannel& operator=(const ByteChannel&) = delete;

    [[nodiscard]] virtual std::size_t read_some(
        std::span<std::uint8_t> buffer,
        Deadline deadline,
        IoCounters& counters,
        std::string_view operation) = 0;
    [[nodiscard]] virtual std::size_t write_some(
        datacube::OctetView bytes,
        Deadline deadline,
        IoCounters& counters,
        std::string_view operation) = 0;

protected:
    ByteChannel() = default;
    ByteChannel(ByteChannel&&) noexcept = default;
    ByteChannel& operator=(ByteChannel&&) noexcept = default;
};

class PlainChannel final : public ByteChannel {
public:
    explicit PlainChannel(int fd) noexcept;
    [[nodiscard]] std::size_t read_some(
        std::span<std::uint8_t> buffer,
        Deadline deadline,
        IoCounters& counters,
        std::string_view operation) override;
    [[nodiscard]] std::size_t write_some(
        datacube::OctetView bytes,
        Deadline deadline,
        IoCounters& counters,
        std::string_view operation) override;
private:
    int fd_{-1};
};

[[nodiscard]] datacube::Fd connect_unix(
    const std::filesystem::path& path,
    Deadline deadline,
    IoCounters& counters);
[[nodiscard]] datacube::Fd listen_unix(
    const std::filesystem::path& path,
    int backlog);
void make_nonblocking(int fd);

void write_bytes(
    int fd,
    datacube::OctetView bytes,
    Deadline deadline,
    const IoOptions& options,
    IoCounters& counters);
void write_bytes(
    ByteChannel& channel,
    datacube::OctetView bytes,
    Deadline deadline,
    const IoOptions& options,
    IoCounters& counters);
void write_frame(
    int fd,
    datacube::OctetView payload,
    Deadline deadline,
    const IoOptions& options,
    IoCounters& counters);
void write_frame(
    ByteChannel& channel,
    datacube::OctetView payload,
    Deadline deadline,
    const IoOptions& options,
    IoCounters& counters);

class FramedReader final {
public:
    explicit FramedReader(IoOptions options);
    [[nodiscard]] datacube::Octets read_frame(
        int fd,
        Deadline deadline,
        IoCounters& counters);
    [[nodiscard]] datacube::Octets read_frame(
        ByteChannel& channel,
        Deadline deadline,
        IoCounters& counters);
    [[nodiscard]] std::size_t queued_frames() const noexcept;
private:
    IoOptions options_;
    datacube::NATravPeerStreamDecoder decoder_;
    std::deque<datacube::Octets> queued_;
    std::size_t observed_bytes_{0U};
};

struct ClientHandshakeResult final {
    datacube::NATravPeerClientExchangeObservation observation;
    IoCounters counters;
};

[[nodiscard]] ClientHandshakeResult perform_client_handshake(
    int fd,
    std::string_view local_node,
    std::string_view expected_peer,
    std::string request_id,
    Deadline deadline,
    const IoOptions& options);
[[nodiscard]] ClientHandshakeResult perform_client_handshake(
    ByteChannel& channel,
    std::string_view local_node,
    std::string_view expected_peer,
    std::string request_id,
    Deadline deadline,
    const IoOptions& options);

struct ServerHandshakeResult final {
    datacube::Digest32 remote_artifact_digest;
    std::string request_id;
    IoCounters counters;
};

[[nodiscard]] ServerHandshakeResult perform_server_handshake(
    int fd,
    std::string_view local_node,
    FramedReader& reader,
    Deadline deadline,
    const IoOptions& options);
[[nodiscard]] ServerHandshakeResult perform_server_handshake(
    ByteChannel& channel,
    std::string_view local_node,
    FramedReader& reader,
    Deadline deadline,
    const IoOptions& options);

}  // namespace natrav_overlay
