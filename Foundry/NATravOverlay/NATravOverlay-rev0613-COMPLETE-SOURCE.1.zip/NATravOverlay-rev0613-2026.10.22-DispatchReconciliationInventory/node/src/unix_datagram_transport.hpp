#pragma once

#include "transport.hpp"

#include <memory>
#include <string>

namespace natrav_overlay {

inline constexpr char kUnixDatagramPacketCarrierMarker[] =
    "OWNER_CONTROLLED_UNIX_DATAGRAM_PACKET_CARRIER_V1";
[[nodiscard]] int unix_datagram_packet_carrier_revision_abi() noexcept;

[[nodiscard]] std::string unix_datagram_transport_locator_text(
    const UnixDatagramTransportLocator& locator);
[[nodiscard]] const TransportConnector& unix_datagram_transport_connector();
[[nodiscard]] std::unique_ptr<TransportListener> listen_unix_datagram_transport(
    const TransportLocator& locator,
    int backlog);

}  // namespace natrav_overlay
