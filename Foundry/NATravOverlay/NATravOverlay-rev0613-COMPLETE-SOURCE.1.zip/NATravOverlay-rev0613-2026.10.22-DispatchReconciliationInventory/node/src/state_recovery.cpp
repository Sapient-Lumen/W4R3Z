#include "state_recovery.hpp"

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <fcntl.h>
#include <linux/fs.h>
#include <openssl/rand.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

namespace natrav_overlay {
namespace {
// Audit deliberately does NOT construct a filesystem NodeState: that normal
// constructor may create locks or clean stale candidates. Every read here is
// descriptor-relative, noncreating, no-follow and no-atime on owned files.
datacube::Fd directory_without_links(const std::filesystem::path& path) {
    if (path.empty()) { app_fail("STATE_AUTH_SOURCE_UNSAFE", "empty directory path"); }
    for (const auto& component : path) {
        if (component == "..") { app_fail("STATE_AUTH_SOURCE_UNSAFE", "dot-dot path is forbidden"); }
    }
    const auto absolute = std::filesystem::absolute(path).lexically_normal();
    datacube::Fd fd(::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC));
    if (!fd) { app_fail("STATE_AUTH_SOURCE_UNSAFE", "cannot open root directory"); }
    for (const auto& component : absolute.relative_path()) {
        const int raw = ::openat(fd.get(), component.c_str(), O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
        if (raw < 0) { app_fail("STATE_AUTH_SOURCE_UNSAFE", "directory ancestry must exist without symbolic links"); }
        fd.reset(raw);
    }
    return fd;
}
void private_file(int fd) {
    struct stat st{};
    if (::fstat(fd, &st) != 0 || !S_ISREG(st.st_mode) || st.st_uid != ::geteuid() ||
        st.st_nlink != 1 || (st.st_mode & 07777U) != 0600U) {
        app_fail("STATE_AUTH_SOURCE_UNSAFE", "expected an owned mode-0600 single-link regular file");
    }
}
datacube::Fd open_private(int parent, const char* name) {
    datacube::Fd fd(::openat(parent, name, O_RDONLY | O_NONBLOCK | O_NOFOLLOW | O_NOATIME | O_CLOEXEC));
    if (!fd) { app_fail("STATE_AUTH_SOURCE_UNSAFE", "required existing state file cannot be opened safely"); }
    private_file(fd.get());
    return fd;
}
void exclusive(int fd) {
    if (::flock(fd, LOCK_EX | LOCK_NB) != 0) {
        app_fail(errno == EWOULDBLOCK ? "STATE_BUSY" : "STATE_LOCK_FAILED", "exclusive existing-state ownership required");
    }
}
datacube::Octets read_source(int fd, std::uint64_t maximum) {
    if (::lseek(fd, 0, SEEK_SET) < 0) { app_fail("STATE_AUTH_READ_FAILED", "cannot seek state file"); }
    return datacube::read_all_fd(fd, maximum, "authenticated recovery source");
}
struct LockedSource final {
    datacube::Fd directory;
    datacube::Fd lock;
    datacube::Fd journal;
    datacube::Octets bytes;
    struct stat identity{};
    explicit LockedSource(const StateAuditOptions& o) {
        require_node_id(o.node, "node");
        if (o.maximum_bytes < 1024U || o.maximum_bytes > 1'073'741'824U) {
            app_fail("INVALID_JOURNAL_LIMIT", "journal limit is outside 1024..1GiB");
        }
        if (!process_state_auth_key()) { app_fail("STATE_AUTH_KEY_REQUIRED", "an explicit state key is required"); }
        directory = directory_without_links(o.directory);
        struct stat st{};
        if (::fstat(directory.get(), &st) != 0 || st.st_uid != ::geteuid() || (st.st_mode & 07777U) != 0700U) {
            app_fail("STATE_AUTH_SOURCE_UNSAFE", "state directory must be owned and exact mode 0700");
        }
        lock = open_private(directory.get(), "state.lock"); exclusive(lock.get());
        const auto meta = open_private(directory.get(), "node.meta");
        const auto meta_bytes = read_source(meta.get(), 512U);
        const std::string expected = "NATRAV_OVERLAY_NODE_STATE_V2\nnode=" + o.node + "\nstorage_schema=2\n";
        if (meta_bytes != datacube::text_octets(expected)) {
            app_fail("STATE_AUTH_SCHEMA_REQUIRED", "schema-2 metadata for the exact node is required");
        }
        journal = open_private(directory.get(), "state.journal"); exclusive(journal.get());
        if (::fstat(journal.get(), &identity) != 0 || identity.st_size < 0 ||
            static_cast<std::uint64_t>(identity.st_size) > o.maximum_bytes) {
            app_fail("STATE_AUTH_LIMIT", "source journal exceeds limit");
        }
        bytes = read_source(journal.get(), o.maximum_bytes);
        if (bytes.size() != static_cast<std::uint64_t>(identity.st_size)) {
            app_fail("STATE_AUTH_SOURCE_CHANGED", "source size changed during read");
        }
    }
    void unchanged(std::uint64_t maximum) const {
        struct stat st{};
        if (::fstatat(directory.get(), "state.journal", &st, AT_SYMLINK_NOFOLLOW) != 0 ||
            st.st_dev != identity.st_dev || st.st_ino != identity.st_ino || st.st_size != identity.st_size ||
            st.st_uid != ::geteuid() || !S_ISREG(st.st_mode) || st.st_nlink != 1 || (st.st_mode & 07777U) != 0600U ||
            read_source(journal.get(), maximum) != bytes) {
            app_fail("STATE_AUTH_SOURCE_CHANGED", "source changed while exclusively owned");
        }
    }
};

struct Analysis final {
    AuthenticatedScan scan;
    std::optional<CheckpointImage> checkpoint;
    std::string expected{"NOT_SUPPLIED"};
};
Analysis analyze(const LockedSource& source, const StateAuditOptions& o) {
    Analysis a;
    a.scan = scan_authenticated_journal(source.bytes, o.node, process_state_auth_key(), o.maximum_bytes);
    if (a.scan.header_authenticated && a.scan.verified.authentication.records > 0U) {
        try {
            a.checkpoint = NodeState::checkpoint_authenticated_prefix(
                datacube::OctetView(source.bytes).first(static_cast<std::size_t>(a.scan.verified_bytes)),
                o.node, o.maximum_bytes, process_state_auth_key());
        } catch (const AppError& e) {
            a.scan.status = "INVALID"; a.scan.code = e.code();
        } catch (const datacube::Failure&) {
            a.scan.status = "INVALID"; a.scan.code = "JOURNAL_CORRUPT";
        }
    }
    if (o.expected_root.has_value() != o.expected_records.has_value()) {
        app_fail("STATE_AUTH_EXPECTED_HEAD_INVALID", "expected root and record count must be supplied together");
    }
    if (o.expected_root) {
        a.expected = a.scan.header_authenticated && a.scan.verified.authentication.records == *o.expected_records &&
            a.scan.verified.authentication.root == *o.expected_root ? "MATCH" : "MISMATCH";
    }
    if (const auto& expected = process_state_head_expectation()) {
        a.expected = a.checkpoint && a.scan.header_authenticated &&
            matches_state_head(*expected, o.node, a.scan.verified.authentication, a.scan.verified_bytes) ? "MATCH" : "MISMATCH";
    }
    return a;
}
std::string audit_json(const LockedSource& s, const StateAuditOptions& o, const Analysis& a) {
    const auto& scan = a.scan;
    const bool complete = scan.status == "COMPLETE" && a.checkpoint && a.expected != "MISMATCH";
    const auto prefix = static_cast<std::size_t>(scan.verified_bytes);
    const auto span = datacube::OctetView(s.bytes);
    const auto code = process_state_head_expectation() && scan.status == "INVALID" ? scan.code : a.expected == "MISMATCH" ?
        (process_state_head_expectation() ? "STATE_HEAD_EXPECTATION_MISMATCH" : "STATE_AUTH_EXPECTED_HEAD_MISMATCH") : scan.code;
    return "{\"format\":\"NATRAV_OVERLAY_STATE_AUTH_AUDIT_V1\",\"ok\":" + std::string(complete ? "true" : "false") +
        ",\"node\":" + json_string(o.node) + ",\"status\":" + json_string(scan.status) +
        ",\"code\":" + json_string(code) + ",\"source_bytes\":" + std::to_string(s.bytes.size()) +
        ",\"source_sha256\":" + json_string(datacube::hex_lower(datacube::sha256(span))) +
        ",\"verified_bytes\":" + std::to_string(prefix) +
        ",\"prefix_sha256\":" + json_string(datacube::hex_lower(datacube::sha256(span.first(prefix)))) +
        ",\"unverified_bytes\":" + std::to_string(s.bytes.size() - prefix) +
        ",\"unverified_sha256\":" + json_string(datacube::hex_lower(datacube::sha256(span.subspan(prefix)))) +
        ",\"prefix_semantics_valid\":" + std::string(a.checkpoint ? "true" : "false") +
        ",\"logical_state_digest\":" + (a.checkpoint ? json_string(datacube::hex_lower(a.checkpoint->logical_state_digest)) : "null") +
        ",\"recovery_eligible\":" + std::string(scan.status == "INCOMPLETE_TAIL" && a.checkpoint && a.expected != "MISMATCH" ? "true" : "false") +
        ",\"expected_head\":" + json_string(a.expected) +
        ",\"state_head_scope\":" + json_string(scan.status == "COMPLETE" && a.checkpoint ? "COMPLETE_SOURCE" : "VERIFIED_PREFIX_ONLY") +
        ",\"state_head\":" + (a.checkpoint ? state_head_json(o.node, scan.verified.authentication,
            scan.verified_bytes, scan.status == "COMPLETE") : "null") +
        ",\"freshness\":\"NOT_ESTABLISHED\",\"cause\":\"NOT_ESTABLISHED\",\"state_authentication\":" +
        (scan.header_authenticated ? state_authentication_json(scan.verified.authentication) : "null") + "}";
}

std::string digest_json(const datacube::Digest32& value) {
    return json_string(datacube::hex_lower(value));
}

datacube::Digest32 lifecycle_reason_digest(const std::string_view reason) {
    datacube::Octets material;
    datacube::append_text(material, "NATRAV_OVERLAY_LIFECYCLE_REASON_V1");
    datacube::append_u8(material, 0U);
    datacube::append_text(material, reason);
    return datacube::sha256(material);
}

bool canonical_stop_correlation(const std::string_view token) {
    if (token.empty() || token.size() > 64U) { return false; }
    const auto alnum = [](const char c) {
        return (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9');
    };
    if (!alnum(token.front()) || !alnum(token.back())) { return false; }
    return std::all_of(token.begin(), token.end(), [&](const char c) {
        return alnum(c) || c == '.' || c == '_' || c == '-';
    });
}

bool correlated_stop_command(const std::string_view command) {
    return command == "SHUTDOWN_CORRELATED" ||
        command == "DRAIN_SHUTDOWN_CORRELATED" ||
        command == "SHUTDOWN_TERMINAL_CORRELATED" ||
        command == "DRAIN_SHUTDOWN_TERMINAL_CORRELATED";
}

std::string configuration_reference_json(
    const OfflineConfigurationReference& value) {
    return "{\"event\":" + std::to_string(value.event) +
        ",\"generation\":" + json_string(value.generation) +
        ",\"digest\":" + digest_json(value.digest) +
        ",\"prefix_digest\":" + digest_json(value.prefix) + "}";
}

std::string decision_match_json(const OfflineControlDecisionMatch& value) {
    return "{\"ordinal\":" + std::to_string(value.ordinal) +
        ",\"configuration\":" +
        configuration_reference_json(value.configuration) +
        ",\"history_prefix_digest\":" + digest_json(value.history_prefix) +
        ",\"request_id\":" + digest_json(value.request_id) +
        ",\"uid\":" + std::to_string(value.uid) +
        ",\"gid\":" + std::to_string(value.gid) +
        ",\"pid\":" + std::to_string(value.pid) +
        ",\"unix_ms\":" + std::to_string(value.unix_ms) +
        ",\"command\":" + json_string(value.command) +
        ",\"command_class\":" + json_string(value.command_class) +
        ",\"decision\":" +
        json_string(local_control_decision_kind_name(value.decision)) +
        ",\"error_code\":" +
        (value.error_code.empty() ? std::string("null") :
            json_string(value.error_code)) + "}";
}

std::string lifecycle_match_json(const OfflineLifecycleMatch& value) {
    return "{\"ordinal\":" + std::to_string(value.ordinal) +
        ",\"configuration\":" +
        configuration_reference_json(value.configuration) +
        ",\"history_prefix_digest\":" + digest_json(value.history_prefix) +
        ",\"request_id\":" + digest_json(value.request_id) +
        ",\"uid\":" + std::to_string(value.uid) +
        ",\"gid\":null,\"gid_semantics\":\"NOT_RECORDED\"" +
        ",\"pid\":" + std::to_string(value.pid) +
        ",\"unix_ms\":" + std::to_string(value.unix_ms) +
        ",\"kind\":" +
        json_string(lifecycle_transition_kind_name(value.kind)) +
        ",\"deadline_ms\":" + std::to_string(value.deadline_ms) +
        ",\"pending_outbound\":" +
        std::to_string(value.pending_outbound) +
        ",\"pending_actions\":" +
        std::to_string(value.pending_actions) +
        ",\"reason_text\":null,\"reason_bytes\":" +
        std::to_string(value.reason_bytes) +
        ",\"reason_digest\":" + digest_json(value.reason_digest) + "}";
}

std::string join_decisions(
    const std::vector<OfflineControlDecisionMatch>& rows) {
    std::string out{"["};
    for (std::size_t index = 0U; index < rows.size(); ++index) {
        if (index != 0U) { out += ','; }
        out += decision_match_json(rows[index]);
    }
    return out + ']';
}

std::string join_lifecycle(const std::vector<OfflineLifecycleMatch>& rows) {
    std::string out{"["};
    for (std::size_t index = 0U; index < rows.size(); ++index) {
        if (index != 0U) { out += ','; }
        out += lifecycle_match_json(rows[index]);
    }
    return out + ']';
}

std::string random_stage() {
    std::array<std::uint8_t, 16> bytes{};
    if (RAND_bytes(bytes.data(), static_cast<int>(bytes.size())) != 1) {
        app_fail("STATE_AUTH_CRYPTO_FAILED", "cannot generate staging identifier");
    }
    return ".natrav-recovery-" + hex_bytes(bytes) + ".tmp";
}
void write_all(int fd, datacube::OctetView bytes) {
    std::size_t at = 0U;
    while (at < bytes.size()) {
        const auto n = ::write(fd, bytes.data() + at, bytes.size() - at);
        if (n < 0 && errno == EINTR) { continue; }
        if (n <= 0) { app_fail("STATE_AUTH_RECOVERY_WRITE_FAILED", "write made no progress"); }
        at += static_cast<std::size_t>(n);
    }
    if (::fsync(fd) != 0) { app_fail("STATE_AUTH_RECOVERY_SYNC_FAILED", "file synchronization failed"); }
}
// Stages never overwrite an existing file. Destruction cleans only this process's
// unpublished staging name. A hard kill may leave owner-only staging; never auto-adopt it.
struct StagedFile final {
    int parent;
    std::string name{random_stage()};
    datacube::Fd fd;
    bool published{false};
    explicit StagedFile(int p, datacube::OctetView bytes) : parent(p) {
        fd.reset(::openat(parent, name.c_str(), O_RDWR | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600));
        if (!fd) { app_fail("STATE_AUTH_RECOVERY_WRITE_FAILED", "cannot create recovery sibling"); }
        try {
            if (::fchmod(fd.get(), 0600) != 0) { app_fail("STATE_AUTH_RECOVERY_WRITE_FAILED", "cannot set sibling mode"); }
            write_all(fd.get(), bytes);
        } catch (...) { static_cast<void>(::unlinkat(parent, name.c_str(), 0)); throw; }
    }
    ~StagedFile() { if (!published) { static_cast<void>(::unlinkat(parent, name.c_str(), 0)); } }
    void no_replace(const std::string& target) {
        if (::syscall(SYS_renameat2, parent, name.c_str(), parent, target.c_str(), RENAME_NOREPLACE) != 0) {
            app_fail(errno == EEXIST ? "STATE_AUTH_EVIDENCE_EXISTS" : "STATE_AUTH_EVIDENCE_PUBLISH_FAILED", "source preservation never overwrites");
        }
        published = true;
        if (::fsync(parent) != 0) { app_fail("STATE_AUTH_EVIDENCE_SYNC_FAILED", "evidence published; directory sync failed"); }
    }
};
void preserve_source(const std::filesystem::path& path, datacube::OctetView bytes) {
    if (path.empty()) { app_fail("STATE_AUTH_EVIDENCE_PATH_INVALID", "source evidence destination required"); }
    for (const auto& c : path) {
        if (c == "..") { app_fail("STATE_AUTH_EVIDENCE_PATH_INVALID", "dot-dot evidence path rejected"); }
    }
    const auto absolute = std::filesystem::absolute(path).lexically_normal();
    const auto name = absolute.filename().string();
    if (name.empty() || name.size() > 160U || name == "." || name == ".." ||
        !std::all_of(name.begin(), name.end(), [](char ch) { return (ch >= 'a' && ch <= 'z') ||
            (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') || ch == '-' || ch == '_' || ch == '.'; })) {
        app_fail("STATE_AUTH_EVIDENCE_PATH_INVALID", "evidence filename must be safe ASCII");
    }
    auto parent = directory_without_links(absolute.parent_path());
    struct stat st{};
    if (::fstat(parent.get(), &st) != 0 || st.st_uid != ::geteuid() || (st.st_mode & 0022U) != 0U) {
        app_fail("STATE_AUTH_EVIDENCE_PATH_INVALID", "evidence parent must be owned and not writable by others");
    }
    StagedFile evidence(parent.get(), bytes);
    if (read_source(evidence.fd.get(), bytes.size()) != datacube::Octets(bytes.begin(), bytes.end())) {
        app_fail("STATE_AUTH_EVIDENCE_MISMATCH", "evidence differs from original source");
    }
    evidence.no_replace(name);
}
} // namespace

StateAuditResult audit_authenticated_state(const StateAuditOptions& o) {
    LockedSource source(o);
    const auto a = analyze(source, o);
    source.unchanged(o.maximum_bytes);
    return {a.scan.status == "COMPLETE" && a.checkpoint.has_value() && a.expected != "MISMATCH", audit_json(source, o, a)};
}

void validate_correlated_stop_audit_options(const CorrelatedStopAuditOptions& o) {
    if (digest_is_zero(o.request_id) || o.maximum_matches == 0U ||
        o.maximum_matches > 64U || o.maximum_json_bytes < 4'096U ||
        o.maximum_json_bytes > 60'000U || o.source.expected_root ||
        o.source.expected_records) {
        app_fail("CORRELATED_STOP_AUDIT_SELECTION_INVALID",
            "invalid request ID, report bound, or legacy expectation option");
    }
    if (o.request_shape) {
        const auto& shape = *o.request_shape;
        const bool immediate = shape.operation == "IMMEDIATE";
        const bool drain = shape.operation == "DRAIN";
        const std::string expected_command = immediate ?
            (shape.final_state_head ? "SHUTDOWN_TERMINAL_CORRELATED" :
                "SHUTDOWN_CORRELATED") :
            (shape.final_state_head ? "DRAIN_SHUTDOWN_TERMINAL_CORRELATED" :
                "DRAIN_SHUTDOWN_CORRELATED");
        if ((!immediate && !drain) ||
            !canonical_stop_correlation(shape.correlation) ||
            shape.request_bytes == 0U || shape.request_bytes > 333U ||
            shape.expected_command != expected_command ||
            (immediate && (shape.drain_deadline_ms || shape.drain_reason)) ||
            (drain && (!shape.drain_deadline_ms || !shape.drain_reason ||
                *shape.drain_deadline_ms == 0U ||
                *shape.drain_deadline_ms > 600'000U ||
                shape.drain_reason->empty() ||
                shape.drain_reason->size() > 256U))) {
            app_fail("CORRELATED_STOP_AUDIT_SELECTION_INVALID",
                "explicit correlated-stop request shape is invalid");
        }
    }
}

std::string render_correlated_stop_audit_report(
    const CorrelatedStopAuditOptions& o,
    const OfflineCorrelatedStopReplay& replay,
    const std::string_view format,
    const std::string_view source_json) {
    validate_correlated_stop_audit_options(o);
    if (format.empty() || source_json.empty() || source_json.front() != '{' ||
        source_json.back() != '}') {
        app_fail("CORRELATED_STOP_AUDIT_SOURCE_INVALID",
            "authenticated audit source account is invalid");
    }

    std::uint64_t authorized = 0U;
    std::uint64_t denied = 0U;
    std::uint64_t correlated_decisions = 0U;
    std::uint64_t other_decisions = 0U;
    bool decision_shape_conflict = false;
    for (const auto& row : replay.decisions) {
        if (row.decision == LocalControlDecisionKind::authorized) {
            ++authorized;
        } else {
            ++denied;
        }
        if (correlated_stop_command(row.command) &&
            row.command_class == "SHUTDOWN") {
            ++correlated_decisions;
        } else {
            ++other_decisions;
        }
        if (o.request_shape &&
            (row.command != o.request_shape->expected_command ||
                row.command_class != "SHUTDOWN")) {
            decision_shape_conflict = true;
        }
    }

    std::uint64_t shutdown_requested = 0U;
    std::uint64_t drain_started = 0U;
    std::uint64_t drain_completed = 0U;
    std::uint64_t drain_deadline = 0U;
    std::uint64_t other_lifecycle = 0U;
    bool lifecycle_shape_conflict = false;
    std::optional<datacube::Digest32> expected_reason_digest;
    std::optional<std::uint64_t> expected_reason_bytes;
    if (o.request_shape && o.request_shape->drain_reason) {
        expected_reason_digest = lifecycle_reason_digest(
            *o.request_shape->drain_reason);
        expected_reason_bytes = o.request_shape->drain_reason->size();
    }
    for (const auto& row : replay.lifecycle) {
        switch (row.kind) {
            case LifecycleTransitionKind::shutdown_requested:
                ++shutdown_requested;
                break;
            case LifecycleTransitionKind::drain_started:
                ++drain_started;
                break;
            case LifecycleTransitionKind::drain_completed:
                ++drain_completed;
                break;
            case LifecycleTransitionKind::drain_deadline:
                ++drain_deadline;
                break;
            case LifecycleTransitionKind::quiesced:
            case LifecycleTransitionKind::resumed:
                ++other_lifecycle;
                break;
        }
        if (!o.request_shape) { continue; }
        if (o.request_shape->operation == "IMMEDIATE") {
            if (row.kind != LifecycleTransitionKind::shutdown_requested) {
                lifecycle_shape_conflict = true;
            }
        } else {
            if (row.kind != LifecycleTransitionKind::drain_started &&
                row.kind != LifecycleTransitionKind::drain_completed &&
                row.kind != LifecycleTransitionKind::drain_deadline) {
                lifecycle_shape_conflict = true;
            }
            if (row.deadline_ms != *o.request_shape->drain_deadline_ms ||
                row.reason_bytes != *expected_reason_bytes ||
                row.reason_digest != *expected_reason_digest) {
                lifecycle_shape_conflict = true;
            }
        }
    }

    const auto matched_rows = replay.decisions.size() + replay.lifecycle.size();
    const bool stop_boundary = shutdown_requested > 0U ||
        drain_completed > 0U || drain_deadline > 0U;
    std::string classification;
    if (matched_rows == 0U) {
        classification = "NOT_FOUND";
    } else if (other_decisions != 0U || other_lifecycle != 0U) {
        classification = "REQUEST_ID_MATCHES_NON_CORRELATED_STOP_HISTORY";
    } else if (decision_shape_conflict || lifecycle_shape_conflict) {
        classification = "EXPLICIT_REQUEST_SHAPE_CONFLICT";
    } else if (authorized == 0U && denied > 0U && replay.lifecycle.empty()) {
        classification = "DENIED";
    } else if (shutdown_requested > 0U && drain_started == 0U &&
        drain_completed == 0U && drain_deadline == 0U) {
        classification = "ACCEPTED_IMMEDIATE";
    } else if (drain_completed > 0U && drain_deadline == 0U &&
        shutdown_requested == 0U) {
        classification = "ACCEPTED_DRAIN_COMPLETED";
    } else if (drain_deadline > 0U && drain_completed == 0U &&
        shutdown_requested == 0U) {
        classification = "ACCEPTED_DRAIN_DEADLINE";
    } else if (drain_started > 0U && drain_completed == 0U &&
        drain_deadline == 0U && shutdown_requested == 0U) {
        classification = "DRAIN_STARTED_WITHOUT_TERMINAL_BOUNDARY";
    } else if (authorized > 0U && replay.lifecycle.empty()) {
        classification = "AUTHORIZED_WITHOUT_LIFECYCLE_BOUNDARY";
    } else {
        classification = "MIXED_DUPLICATE_OUTCOMES";
    }

    std::string shape_json{"null"};
    std::string selection_method{"EXACT_REQUEST_ID"};
    if (o.request_shape) {
        selection_method = "EXPLICIT_REQUEST_SHAPE";
        const auto& shape = *o.request_shape;
        shape_json = "{\"operation\":" + json_string(shape.operation) +
            ",\"final_state_head\":" +
            std::string(shape.final_state_head ? "true" : "false") +
            ",\"correlation_token\":" + json_string(shape.correlation) +
            ",\"token_source\":\"CALLER_SUPPLIED_NOT_RECOVERED_FROM_STATE\"" +
            ",\"request_bytes\":" + std::to_string(shape.request_bytes) +
            ",\"expected_command\":" +
            json_string(shape.expected_command);
        if (shape.operation == "DRAIN") {
            shape_json += ",\"drain_deadline_ms\":" +
                std::to_string(*shape.drain_deadline_ms) +
                ",\"reason_text\":null,\"reason_bytes\":" +
                std::to_string(*expected_reason_bytes) +
                ",\"reason_digest\":" +
                digest_json(*expected_reason_digest);
        } else {
            shape_json +=
                ",\"drain_deadline_ms\":null,\"reason_text\":null," +
                std::string("\"reason_bytes\":null,\"reason_digest\":null");
        }
        shape_json += '}';
    }

    const auto& authentication = replay.authentication;
    std::string out =
        "{\"format\":" + json_string(format) +
        ",\"ok\":true,\"node\":" + json_string(o.source.node) +
        ",\"source\":" + std::string(source_json) +
        ",\"state_head\":" + state_head_json(o.source.node,
            replay.authentication, replay.journal_bytes, true) +
        ",\"authentication\":{\"mode\":\"HMAC_SHA256_CHAIN_V1\"," +
        std::string("\"generation\":") + json_string(authentication.generation) +
        ",\"key_id\":" + digest_json(authentication.key_id) +
        ",\"epoch\":" + digest_json(authentication.epoch) +
        ",\"root\":" + digest_json(authentication.root) +
        ",\"records\":" + std::to_string(authentication.records) +
        ",\"purpose\":" + json_string(authentication.purpose) + "}" +
        ",\"selection\":{\"method\":" + json_string(selection_method) +
        ",\"request_id\":" + digest_json(o.request_id) +
        ",\"shape\":" + shape_json +
        ",\"semantics\":\"PROVENANCE_ONLY_NOT_PERMISSION_IDEMPOTENCY_RECEIPT_RECOVERY_OR_FRESHNESS\"}" +
        ",\"matches\":{\"decision_count\":" +
        std::to_string(replay.decisions.size()) +
        ",\"lifecycle_count\":" +
        std::to_string(replay.lifecycle.size()) +
        ",\"retained_decision_count\":" +
        std::to_string(replay.retained_decisions) +
        ",\"retained_lifecycle_count\":" +
        std::to_string(replay.retained_lifecycle_events) +
        ",\"decisions\":" + join_decisions(replay.decisions) +
        ",\"lifecycle\":" + join_lifecycle(replay.lifecycle) + "}" +
        ",\"outcome\":{\"classification\":" +
        json_string(classification) +
        ",\"stop_boundary_observed\":" +
        std::string(stop_boundary ? "true" : "false") +
        ",\"authorized_decisions\":" + std::to_string(authorized) +
        ",\"denied_decisions\":" + std::to_string(denied) +
        ",\"correlated_stop_decisions\":" +
        std::to_string(correlated_decisions) +
        ",\"other_decisions\":" + std::to_string(other_decisions) +
        ",\"shutdown_requested\":" +
        std::to_string(shutdown_requested) +
        ",\"drain_started\":" + std::to_string(drain_started) +
        ",\"drain_completed\":" + std::to_string(drain_completed) +
        ",\"drain_deadline\":" + std::to_string(drain_deadline) +
        ",\"response_receipt\":\"NOT_ESTABLISHED\"," +
        std::string("\"idempotency\":\"NOT_ESTABLISHED\"}") +
        ",\"retained_obligations\":{\"pending_outbound\":" +
        std::to_string(replay.pending.pending_outbound) +
        ",\"pending_actions\":" +
        std::to_string(replay.pending.pending_actions) +
        ",\"complete\":" +
        std::string(replay.pending.pending_outbound == 0U &&
            replay.pending.pending_actions == 0U ? "true" : "false") +
        ",\"scope\":\"CURRENT_AUTHENTICATED_REPLAY\"}" +
        ",\"redaction\":\"NO_PAYLOADS_SECRETS_REASON_TEXT_OR_IDENTITY_PATHS\"," +
        std::string("\"freshness\":\"NOT_ESTABLISHED\",") +
        "\"automatic_expectation_update\":false," +
        "\"mutation\":\"NONE\",\"limits\":{\"maximum_matches\":" +
        std::to_string(o.maximum_matches) +
        ",\"matched_rows\":" + std::to_string(matched_rows) +
        ",\"maximum_json_bytes\":" +
        std::to_string(o.maximum_json_bytes) + "}}";
    if (out.size() > o.maximum_json_bytes) {
        app_fail("CORRELATED_STOP_AUDIT_RESPONSE_TOO_LARGE",
            "complete bounded report exceeds the requested JSON limit");
    }
    return out;
}

std::string audit_correlated_stop(const CorrelatedStopAuditOptions& o) {
    validate_correlated_stop_audit_options(o);
    LockedSource source(o.source);
    const auto replay = NodeState::replay_correlated_stop_audit(
        source.bytes, o.source.node, o.source.maximum_bytes,
        process_state_auth_key(), o.request_id, o.maximum_matches);
    enforce_expected_state_head(
        o.source.node, replay.authentication, replay.journal_bytes);
    const auto source_digest = datacube::sha256(source.bytes);
    const std::string source_json =
        "{\"status\":\"COMPLETE_AUTHENTICATED_SEMANTIC_REPLAY\"," +
        std::string("\"exclusive_existing_state_lock\":true,") +
        "\"writer_opened\":false,\"workers_started\":false," +
        "\"state_mutated\":false,\"journal_bytes\":" +
        std::to_string(source.bytes.size()) +
        ",\"source_sha256\":" + digest_json(source_digest) + "}";
    auto out = render_correlated_stop_audit_report(o, replay,
        "NATRAV_OVERLAY_OFFLINE_CORRELATED_STOP_AUDIT_V1", source_json);
    source.unchanged(o.source.maximum_bytes);
    return out;
}

std::string recover_authenticated_state(const StateRecoveryOptions& o) {
    if (o.reason.empty() || o.reason.size() > 512U ||
        !std::all_of(o.reason.begin(), o.reason.end(), [](char c) { return c >= 32 && c <= 126; })) {
        app_fail("STATE_AUTH_REASON_INVALID", "reason requires 1..512 printable ASCII bytes");
    }
    // Keep original evidence outside the live state tree: normal maintenance
    // must never mistake it for a stale compaction/metadata/control object.
    const auto state_path = std::filesystem::absolute(o.source.directory).lexically_normal();
    const auto evidence_path = std::filesystem::absolute(o.preserve_source).lexically_normal();
    const auto relative = evidence_path.lexically_relative(state_path);
    if (!relative.empty() && *relative.begin() != "..") {
        app_fail("STATE_AUTH_EVIDENCE_PATH_INVALID", "source evidence must be outside the state directory tree");
    }
    LockedSource source(o.source);
    auto a = analyze(source, o.source);
    // Critical recovery policy: never drop complete invalid records or silently
    // truncate to an earlier valid point. Only the maximal verified prefix of a
    // structurally plausible incomplete final record is selectable.
    if (a.scan.status != "INCOMPLETE_TAIL" || !a.checkpoint) {
        app_fail("STATE_AUTH_RECOVERY_NOT_ELIGIBLE", "only a semantically valid prefix with incomplete terminal framing is recoverable");
    }
    // The external expectation constrains the selected maximal prefix. It cannot
    // authorize recovery, suppress source preservation, or select an older prefix.
    enforce_expected_state_head(o.source.node, a.scan.verified.authentication, a.scan.verified_bytes);
    auto previous = a.scan.verified.authentication;
    if (datacube::sha256(source.bytes) != o.source_digest || a.scan.verified_bytes != o.prefix_bytes ||
        previous.records != o.prefix_records || previous.root != o.prefix_root) {
        app_fail("STATE_AUTH_RECOVERY_SELECTION_MISMATCH", "source digest, maximal prefix bytes, sequence and root must match the explicit selection");
    }
    const auto now = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    if (now <= 0) { app_fail("CLOCK_INVALID", "valid recovery time required"); }
    const auto view = datacube::OctetView(source.bytes);
    previous.recoveries.push_back(StateAuthRecovery{
        .source_digest = o.source_digest,
        .discarded_digest = datacube::sha256(view.subspan(static_cast<std::size_t>(o.prefix_bytes))),
        .prefix_digest = datacube::sha256(view.first(static_cast<std::size_t>(o.prefix_bytes))),
        .selected_root = previous.root, .selected_epoch = previous.epoch,
        .generation = previous.generation, .key_id = previous.key_id,
        .selected_records = o.prefix_records, .source_bytes = source.bytes.size(), .prefix_bytes = o.prefix_bytes,
        .unix_ms = static_cast<std::uint64_t>(now), .uid = static_cast<std::uint32_t>(::geteuid()),
        .pid = static_cast<std::uint32_t>(::getpid()), .reason = o.reason,
    });
    auto image = authenticate_checkpoint(a.checkpoint->journal_bytes, o.source.node, process_state_auth_key(),
        &previous, a.checkpoint->logical_state_digest, "RECOVER");
    if (image.bytes.size() > o.source.maximum_bytes) { app_fail("STATE_AUTH_LIMIT", "recovery checkpoint exceeds limit"); }
    StagedFile candidate(source.directory.get(), image.bytes);
    const char* corrupt = std::getenv("NATRAV_OVERLAY_TEST_STATE_AUTH_RECOVERY_CORRUPT_CANDIDATE");
    if (corrupt && std::string_view(corrupt) == "1") {
        const auto value = static_cast<std::uint8_t>(image.bytes.back() ^ 1U);
        if (::pwrite(candidate.fd.get(), &value, 1U, static_cast<off_t>(image.bytes.size() - 1U)) != 1 || ::fsync(candidate.fd.get()) != 0) {
            app_fail("STATE_AUTH_TEST_HOOK_FAILED", "candidate corruption hook failed");
        }
    }
    const auto on_disk = read_source(candidate.fd.get(), o.source.maximum_bytes);
    const auto checked = NodeState::validate_checkpoint_image(on_disk, o.source.node, o.source.maximum_bytes, process_state_auth_key());
    if (!checked.authentication || checked.authentication->root != image.authentication.root ||
        checked.logical_state_digest != a.checkpoint->logical_state_digest) {
        app_fail("STATE_AUTH_RECOVERY_CANDIDATE_REJECTED", "candidate changed state or authentication root");
    }
    source.unchanged(o.source.maximum_bytes);
    // Source evidence is a mandatory, complete, owner-only no-overwrite copy.
    // Once published it is deliberately retained even if recovery later fails.
    preserve_source(o.preserve_source, source.bytes);
    state_auth_test_pause("RECOVERY_BEFORE_PUBLISH");
    source.unchanged(o.source.maximum_bytes);
    if (::renameat(source.directory.get(), candidate.name.c_str(), source.directory.get(), "state.journal") != 0) {
        app_fail("STATE_AUTH_RECOVERY_PUBLISH_FAILED", "cannot atomically publish recovery");
    }
    candidate.published = true;
    if (::fsync(source.directory.get()) != 0) {
        app_fail("STATE_AUTH_RECOVERY_SYNC_FAILED", "checkpoint published but directory sync failed; audit before retry");
    }
    state_auth_test_pause("RECOVERY_AFTER_PUBLISH");
    return "{\"format\":\"NATRAV_OVERLAY_STATE_AUTH_RECOVERY_V1\",\"ok\":true,\"decision\":\"EXPLICIT_PREFIX_ADOPTION\","
        "\"source_preserved\":true,\"cause\":\"NOT_ESTABLISHED\",\"logical_state_digest\":" +
        json_string(datacube::hex_lower(a.checkpoint->logical_state_digest)) + ",\"state_authentication\":" +
        state_authentication_json(image.authentication) +
        ",\"state_head\":" + state_head_json(o.source.node, image.authentication, image.bytes.size(), false) +
        ",\"input_expectation\":" + json_string(process_state_head_expectation() ? "MATCHED_VERIFIED_PREFIX" : "NOT_SUPPLIED") + "}";
}
} // namespace natrav_overlay
