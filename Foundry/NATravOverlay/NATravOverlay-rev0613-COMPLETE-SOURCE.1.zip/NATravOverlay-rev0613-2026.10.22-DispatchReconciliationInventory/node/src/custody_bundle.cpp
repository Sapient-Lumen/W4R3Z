#include "custody_bundle.hpp"

#include <algorithm>
#include <set>

namespace natrav_overlay {
namespace {

constexpr std::string_view kMagic = "NHCB0001";

void require(const bool condition, const std::string_view code,
    const std::string_view detail) {
    if (!condition) { app_fail(code, detail); }
}

void append_digest(datacube::Octets& out, const datacube::Digest32& value) {
    datacube::append_octets(out,
        datacube::OctetView(value.octets.data(), value.octets.size()));
}

void append_text8(datacube::Octets& out, const std::string_view text) {
    require(valid_generation_id(text), "CUSTODY_BUNDLE_REJECTED",
        "grant identifier is invalid");
    datacube::append_u8(out, static_cast<std::uint8_t>(text.size()));
    datacube::append_text(out, text);
}

std::string read_text8(datacube::Reader& reader) {
    const auto size = reader.read_u8("grant id size");
    require(size > 0U && size <= 64U, "CUSTODY_BUNDLE_REJECTED",
        "grant identifier size");
    const auto result = datacube::octets_text(
        reader.read_exact(size, "grant id"), "grant id", true);
    require(valid_generation_id(result), "CUSTODY_BUNDLE_REJECTED",
        "grant identifier is invalid");
    return result;
}

datacube::Digest32 read_digest(datacube::Reader& reader,
    const std::string_view field) {
    datacube::Digest32 result;
    const auto bytes = reader.read_exact(result.octets.size(), field);
    std::copy(bytes.begin(), bytes.end(), result.octets.begin());
    return result;
}

void validate_bundle(const CustodyBundle& bundle) {
    require(!bundle.envelope.canonical.empty() &&
            bundle.envelope.canonical.size() <= kCustodyEnvelopeLimit &&
            !bundle.capsule.empty() &&
            bundle.capsule.size() <= kHandoffCapsuleLimit &&
            bundle.grants.size() + 1U == bundle.envelope.route.size() &&
            bundle.records.size() <=
                2U * (kCustodyRoutePartyLimit - 1U),
        "CUSTODY_BUNDLE_REJECTED", "bundle bounds");
    require_custody_capsule(bundle.envelope, bundle.capsule);
    std::set<std::pair<std::string, std::uint64_t>> grants;
    for (const auto& reference : bundle.grants) {
        require(valid_generation_id(reference.id) &&
                reference.generation > 0U &&
                !digest_is_zero(reference.commitment) &&
                grants.emplace(reference.id, reference.generation).second,
            "CUSTODY_BUNDLE_REJECTED",
            "invalid or duplicate grant reference");
    }
    static_cast<void>(reconstruct_custody_progress(
        bundle.envelope, bundle.records));
}

} // namespace

datacube::Octets encode_custody_bundle(const CustodyBundle& bundle) {
    validate_bundle(bundle);
    datacube::Octets out;
    datacube::append_text(out, kMagic);
    datacube::append_be32(out,
        static_cast<std::uint32_t>(bundle.envelope.canonical.size()));
    datacube::append_octets(out, bundle.envelope.canonical);
    datacube::append_be32(out,
        static_cast<std::uint32_t>(bundle.capsule.size()));
    datacube::append_octets(out, bundle.capsule);
    datacube::append_u8(out,
        static_cast<std::uint8_t>(bundle.grants.size()));
    for (const auto& reference : bundle.grants) {
        append_text8(out, reference.id);
        datacube::append_be64(out, reference.generation);
        append_digest(out, reference.commitment);
    }
    datacube::append_u8(out,
        static_cast<std::uint8_t>(bundle.records.size()));
    for (const auto& record : bundle.records) {
        require(!record.empty() && record.size() <= kCustodyRecordLimit,
            "CUSTODY_BUNDLE_REJECTED", "custody record size");
        datacube::append_be16(out,
            static_cast<std::uint16_t>(record.size()));
        datacube::append_octets(out, record);
    }
    require(out.size() <= kCustodyBundleLimit,
        "CUSTODY_BUNDLE_REJECTED", "encoded bundle size");
    return out;
}

CustodyBundle decode_custody_bundle(const datacube::OctetView bytes) {
    require(!bytes.empty() && bytes.size() <= kCustodyBundleLimit,
        "CUSTODY_BUNDLE_REJECTED", "bundle byte bound");
    datacube::Reader reader(bytes, "custody bundle");
    require(datacube::octets_text(reader.read_exact(kMagic.size(), "magic"),
                "custody bundle magic", true) == kMagic,
        "CUSTODY_BUNDLE_REJECTED", "bundle magic");
    const auto envelope_size = reader.read_be32("envelope size");
    require(envelope_size > 0U && envelope_size <= kCustodyEnvelopeLimit,
        "CUSTODY_BUNDLE_REJECTED", "envelope size");
    const auto envelope_bytes = reader.read_exact(envelope_size, "envelope");
    CustodyBundle result;
    result.envelope = decode_custody_envelope(envelope_bytes);
    const auto capsule_size = reader.read_be32("capsule size");
    require(capsule_size > 0U && capsule_size <= kHandoffCapsuleLimit,
        "CUSTODY_BUNDLE_REJECTED", "capsule size");
    const auto capsule = reader.read_exact(capsule_size, "capsule");
    result.capsule.assign(capsule.begin(), capsule.end());
    const auto grant_count = reader.read_u8("grant count");
    require(grant_count > 0U && grant_count < kCustodyRoutePartyLimit,
        "CUSTODY_BUNDLE_REJECTED", "grant count");
    result.grants.reserve(grant_count);
    for (std::size_t index = 0U; index < grant_count; ++index) {
        result.grants.push_back(CustodyGrantReference{
            .id = read_text8(reader),
            .generation = reader.read_be64("grant generation"),
            .commitment = read_digest(reader, "grant commitment"),
        });
    }
    const auto record_count = reader.read_u8("record count");
    require(record_count <= 2U * (kCustodyRoutePartyLimit - 1U),
        "CUSTODY_BUNDLE_REJECTED", "record count");
    result.records.reserve(record_count);
    for (std::size_t index = 0U; index < record_count; ++index) {
        const auto size = reader.read_be16("record size");
        require(size > 0U && size <= kCustodyRecordLimit,
            "CUSTODY_BUNDLE_REJECTED", "record size");
        const auto record = reader.read_exact(size, "custody record");
        result.records.emplace_back(record.begin(), record.end());
    }
    reader.require_eof("custody bundle");
    validate_bundle(result);
    require(encode_custody_bundle(result) ==
            datacube::Octets(bytes.begin(), bytes.end()),
        "CUSTODY_BUNDLE_REJECTED", "noncanonical custody bundle");
    return result;
}

datacube::Digest32 custody_bundle_envelope_sha256(
    const CustodyBundle& bundle) {
    validate_bundle(bundle);
    return custody_envelope_sha256(bundle.envelope);
}

} // namespace natrav_overlay
