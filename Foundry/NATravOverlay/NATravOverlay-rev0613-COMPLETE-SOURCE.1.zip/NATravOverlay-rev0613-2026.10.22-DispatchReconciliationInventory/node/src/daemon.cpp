#include "adapter_transport.hpp"
#include "daemon.hpp"
#include "custody_session_service.hpp"
#include "peer_session.hpp"
#include "runtime.hpp"
#include "state_head_custody.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <condition_variable>
#include <csignal>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <deque>
#include <exception>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <poll.h>
#include <string>
#include <string_view>
#include <sys/socket.h>
#include <thread>
#include <system_error>
#include <unistd.h>
#include <utility>
#include <vector>

namespace natrav_overlay {
namespace {

volatile sig_atomic_t persistent_signal_stop = 0;

void persistent_stop_handler(int) { persistent_signal_stop = 1; }

[[nodiscard]] std::uint64_t unix_milliseconds() {
    const auto now = std::chrono::system_clock::now().time_since_epoch();
    const auto value = std::chrono::duration_cast<std::chrono::milliseconds>(now).count();
    if (value <= 0) {
        app_fail("CLOCK_INVALID", "system clock is not after the Unix epoch");
    }
    return static_cast<std::uint64_t>(value);
}

[[nodiscard]] std::uint64_t saturating_add(
    const std::uint64_t left,
    const std::uint64_t right) noexcept {
    if (right > std::numeric_limits<std::uint64_t>::max() - left) {
        return std::numeric_limits<std::uint64_t>::max();
    }
    return left + right;
}

[[nodiscard]] std::uint64_t retry_backoff(
    const OutboundPolicy& policy,
    const std::uint32_t attempt) noexcept {
    std::uint64_t value = policy.initial_backoff_ms;
    for (std::uint32_t index = 1U; index < attempt; ++index) {
        if (value >= policy.maximum_backoff_ms) {
            return policy.maximum_backoff_ms;
        }
        value = std::min<std::uint64_t>(
            value * 2U, policy.maximum_backoff_ms);
    }
    return std::min<std::uint64_t>(value, policy.maximum_backoff_ms);
}

[[nodiscard]] std::string safe_detail(const std::string_view value) {
    std::string out;
    out.reserve(std::min<std::size_t>(value.size(), 512U));
    for (const char raw : value) {
        if (out.size() == 512U) { break; }
        const auto ch = static_cast<unsigned char>(raw);
        out.push_back(ch == 9U || (ch >= 32U && ch <= 126U) ? raw : '?');
    }
    return out;
}

template <typename T>
class BoundedQueue final {
public:
    explicit BoundedQueue(const std::size_t capacity) : capacity_(capacity) {}

    [[nodiscard]] bool push(T value) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (closed_ || values_.size() >= capacity_) {
            return false;
        }
        values_.push_back(std::move(value));
        condition_.notify_one();
        return true;
    }

    [[nodiscard]] std::optional<T> pop() {
        std::unique_lock<std::mutex> lock(mutex_);
        condition_.wait(lock, [this] { return closed_ || !values_.empty(); });
        if (values_.empty()) {
            return std::nullopt;
        }
        auto value = std::move(values_.front());
        values_.pop_front();
        return value;
    }

    void close() {
        std::lock_guard<std::mutex> lock(mutex_);
        closed_ = true;
        condition_.notify_all();
    }

    [[nodiscard]] std::size_t size() {
        std::lock_guard<std::mutex> lock(mutex_);
        return values_.size();
    }

private:
    std::size_t capacity_{0U};
    std::deque<T> values_;
    bool closed_{false};
    std::mutex mutex_;
    std::condition_variable condition_;
};

using FdQueue = BoundedQueue<datacube::Fd>;
using TransportStreamQueue =
    BoundedQueue<std::unique_ptr<OrderedByteStream>>;

class SchedulerSignal final {
public:
    void record_failure() noexcept { failed_.store(true); }
    [[nodiscard]] bool failed() const noexcept { return failed_.load(); }
    void notify() {
        std::lock_guard<std::mutex> lock(mutex_);
        ++generation_;
        condition_.notify_all();
    }

    void wait_for(
        const std::chrono::milliseconds duration,
        const std::atomic<bool>& stopping) {
        std::unique_lock<std::mutex> lock(mutex_);
        const auto observed = generation_;
        condition_.wait_for(lock, duration, [&] {
            return stopping.load() || generation_ != observed;
        });
    }

private:
    std::uint64_t generation_{0U};
    std::atomic<bool> failed_{false}; // not a normal stop request
    std::mutex mutex_;
    std::condition_variable condition_;
};

class UnixPathGuard final {
public:
    explicit UnixPathGuard(std::filesystem::path path) : path_(std::move(path)) {}
    ~UnixPathGuard() {
        if (!path_.empty()) {
            static_cast<void>(::unlink(path_.c_str()));
        }
    }
    UnixPathGuard(const UnixPathGuard&) = delete;
    UnixPathGuard& operator=(const UnixPathGuard&) = delete;
private:
    std::filesystem::path path_;
};

struct PeerRouteRuntimeObservation final {
    std::string route_id;
    std::string locator;
    std::uint32_t priority{0U};
    PeerRouteState configured_state{PeerRouteState::enabled};
    std::uint64_t selections{0U};
    std::uint64_t connection_attempts{0U};
    std::uint64_t connection_successes{0U};
    std::uint64_t consecutive_failures{0U};
    std::uint64_t last_failure_unix_ms{0U};
    std::uint64_t last_success_unix_ms{0U};
    std::uint64_t cooldown_until_unix_ms{0U};
    std::string last_failure_code;
    bool active_session{false};
    bool telemetry_available{true};
};

struct PeerRuntimeStats final {
    std::string node_id;  // immutable registered scheduler identity
    mutable std::mutex route_mutex;
    std::vector<PeerRouteRuntimeObservation> route_observations;
    std::string active_route_id;
    std::atomic<std::uint64_t> configuration_drains{0U};
    std::atomic<std::uint64_t> opened_configuration_event{0U};
    // Serializes a recipient's scheduler attempt with explicit rebind and
    // cancellation transitions. The lock is held across one bounded network
    // attempt so a control transition has a deterministic before/after order.
    std::mutex transition_mutex;
    std::atomic<std::uint64_t> selection_calls{0U};
    std::atomic<std::uint64_t> selection_tree_nodes{0U};
    std::atomic<std::uint64_t> selection_key_buckets{0U};
    std::atomic<std::uint64_t> selection_metadata_records{0U};
    std::atomic<std::uint64_t> selection_payload_records{0U};
    std::atomic<std::uint64_t> selection_payload_bytes{0U};
    std::atomic<std::uint64_t> selection_stale{0U};
    std::atomic<std::uint64_t> selection_maintenance{0U};
    std::atomic<std::uint64_t> attempts{0U};
    std::atomic<std::uint64_t> acknowledged{0U};
    std::atomic<std::uint64_t> failures{0U};
    std::atomic<std::uint64_t> rejected{0U};
    std::atomic<std::uint64_t> expired{0U};
    std::atomic<std::uint64_t> sessions_opened{0U};
    std::atomic<std::uint64_t> sessions_reused{0U};
    std::atomic<std::uint64_t> sessions_retired{0U};
    std::atomic<std::uint64_t> sessions_failed{0U};
    std::atomic<std::uint64_t> session_operations{0U};
    std::atomic<std::uint64_t> current_session_operations{0U};
    std::atomic<std::uint64_t> current_session_bytes{0U};
    std::atomic<std::uint8_t> session_state{0U};
};

[[nodiscard]] std::uint64_t route_backoff(
    const DeliveryPolicy& policy,
    const std::uint64_t consecutive_failures) noexcept {
    std::uint64_t value = policy.initial_backoff_ms;
    for (std::uint64_t index = 1U; index < consecutive_failures; ++index) {
        if (value >= policy.maximum_backoff_ms) {
            return policy.maximum_backoff_ms;
        }
        value = std::min<std::uint64_t>(
            value * 2U, policy.maximum_backoff_ms);
    }
    return std::min<std::uint64_t>(value, policy.maximum_backoff_ms);
}

void synchronize_route_observations(
    PeerRuntimeStats& stats,
    const PeerConfig& peer) {
    std::lock_guard<std::mutex> lock(stats.route_mutex);
    std::vector<PeerRouteRuntimeObservation> next;
    next.reserve(peer.routes.size());
    for (const auto& route : peer.routes) {
        const auto endpoint = transport_locator_text(route.locator);
        const auto found = std::find_if(
            stats.route_observations.begin(), stats.route_observations.end(),
            [&](const PeerRouteRuntimeObservation& observation) {
                return observation.route_id == route.route_id &&
                    observation.locator == endpoint;
            });
        PeerRouteRuntimeObservation observation;
        if (found != stats.route_observations.end()) {
            observation = *found;
        } else {
            observation.route_id = route.route_id;
            observation.locator = endpoint;
        }
        observation.priority = route.priority;
        observation.configured_state = route.state;
        observation.active_session = stats.active_route_id == route.route_id;
        next.push_back(std::move(observation));
    }
    if (!stats.active_route_id.empty() &&
        std::none_of(next.begin(), next.end(), [&](const auto& route) {
            return route.route_id == stats.active_route_id;
        })) {
        stats.active_route_id.clear();
    }
    stats.route_observations = std::move(next);
}

[[nodiscard]] std::vector<PeerRouteRuntimeObservation> route_observations(
    const PeerRuntimeStats& stats) {
    std::lock_guard<std::mutex> lock(stats.route_mutex);
    return stats.route_observations;
}

[[nodiscard]] std::string active_route_id(const PeerRuntimeStats& stats) {
    std::lock_guard<std::mutex> lock(stats.route_mutex);
    return stats.active_route_id;
}

void clear_active_route(PeerRuntimeStats& stats) {
    std::lock_guard<std::mutex> lock(stats.route_mutex);
    stats.active_route_id.clear();
    for (auto& route : stats.route_observations) {
        route.active_session = false;
    }
}

void mark_route_selected(
    PeerRuntimeStats& stats,
    const PeerRouteConfig& route) {
    std::lock_guard<std::mutex> lock(stats.route_mutex);
    const auto endpoint = transport_locator_text(route.locator);
    const auto found = std::find_if(
        stats.route_observations.begin(), stats.route_observations.end(),
        [&](const PeerRouteRuntimeObservation& observation) {
            return observation.route_id == route.route_id &&
                observation.locator == endpoint;
        });
    if (found == stats.route_observations.end()) {
        app_fail("ROUTE_OBSERVATION_MISSING", route.route_id);
    }
    ++found->selections;
    ++found->connection_attempts;
}

void mark_route_open_success(
    PeerRuntimeStats& stats,
    const PeerRouteConfig& route,
    const std::uint64_t now) {
    std::lock_guard<std::mutex> lock(stats.route_mutex);
    const auto endpoint = transport_locator_text(route.locator);
    const auto found = std::find_if(
        stats.route_observations.begin(), stats.route_observations.end(),
        [&](const PeerRouteRuntimeObservation& observation) {
            return observation.route_id == route.route_id &&
                observation.locator == endpoint;
        });
    if (found == stats.route_observations.end()) {
        app_fail("ROUTE_OBSERVATION_MISSING", route.route_id);
    }
    ++found->connection_successes;
    found->consecutive_failures = 0U;
    found->last_success_unix_ms = now;
    found->cooldown_until_unix_ms = 0U;
    found->last_failure_code.clear();
    stats.active_route_id = route.route_id;
    for (auto& observed : stats.route_observations) {
        observed.active_session = observed.route_id == route.route_id;
    }
}

void mark_route_application_success(
    PeerRuntimeStats& stats,
    const std::string_view route_id,
    const std::uint64_t now) {
    std::lock_guard<std::mutex> lock(stats.route_mutex);
    const auto found = std::find_if(
        stats.route_observations.begin(), stats.route_observations.end(),
        [&](const PeerRouteRuntimeObservation& observation) {
            return observation.route_id == route_id;
        });
    if (found != stats.route_observations.end()) {
        found->last_success_unix_ms = now;
        found->consecutive_failures = 0U;
        found->cooldown_until_unix_ms = 0U;
        found->last_failure_code.clear();
    }
}

void mark_route_failure(
    PeerRuntimeStats& stats,
    const PeerConfig& peer,
    const PeerRouteConfig& route,
    const std::string_view code,
    const std::uint64_t now) {
    std::lock_guard<std::mutex> lock(stats.route_mutex);
    const auto endpoint = transport_locator_text(route.locator);
    const auto found = std::find_if(
        stats.route_observations.begin(), stats.route_observations.end(),
        [&](const PeerRouteRuntimeObservation& observation) {
            return observation.route_id == route.route_id &&
                observation.locator == endpoint;
        });
    if (found == stats.route_observations.end()) {
        app_fail("ROUTE_OBSERVATION_MISSING", route.route_id);
    }
    ++found->consecutive_failures;
    found->last_failure_unix_ms = now;
    found->last_failure_code = valid_error_code(code) ?
        std::string(code) : std::string("ROUTE_CONNECT_FAILED");
    found->cooldown_until_unix_ms = saturating_add(
        now, route_backoff(peer.delivery, found->consecutive_failures));
    if (stats.active_route_id == route.route_id) {
        stats.active_route_id.clear();
    }
    found->active_session = false;
}

[[nodiscard]] std::vector<PeerRouteConfig> eligible_routes(
    PeerRuntimeStats& stats,
    const PeerConfig& peer,
    const std::uint64_t now,
    std::optional<std::uint64_t>& earliest_cooldown) {
    synchronize_route_observations(stats, peer);
    const auto observations = route_observations(stats);
    std::vector<PeerRouteConfig> result;
    for (const auto& route : peer.routes) {
        if (route.state != PeerRouteState::enabled) { continue; }
        const auto endpoint = transport_locator_text(route.locator);
        const auto observed = std::find_if(
            observations.begin(), observations.end(),
            [&](const PeerRouteRuntimeObservation& value) {
                return value.route_id == route.route_id &&
                    value.locator == endpoint;
            });
        if (observed == observations.end() ||
            observed->cooldown_until_unix_ms <= now) {
            result.push_back(route);
            continue;
        }
        if (!earliest_cooldown.has_value() ||
            observed->cooldown_until_unix_ms < *earliest_cooldown) {
            earliest_cooldown = observed->cooldown_until_unix_ms;
        }
    }
    return result;
}

void scheduler_loop(
    NodeState& state, TlsContext& tls, RuntimeConfiguration& runtime,
    PeerRuntimeStats& stats, SchedulerSignal& signal, std::atomic<bool>& stopping);

// Published pointees never move or disappear. Container access is protected by
// RuntimeConfiguration's generation gate; existing workers only keep pointees.
// The append-only registry counts historical and inbound-only identities too.
class PeerSchedulerRegistry final {
    struct ParkedWorker final {
        std::atomic<unsigned> decision{0U}; // 0 prepared, 1 published, 2 cancelled
        std::thread thread;
        void decide(const unsigned value) noexcept {
            decision.store(value, std::memory_order_release);
            decision.notify_one();
        }
        ~ParkedWorker() {
            if (decision.load(std::memory_order_acquire) == 0U) { decide(2U); }
            if (thread.joinable()) { thread.join(); }
        }
    };

    class Preparation final : public PreparedPeerRegistryChange {
    public:
        explicit Preparation(PeerSchedulerRegistry& owner) : owner_(owner) {}
        ~Preparation() override {
            // Signal all before joining any. No worker takes the generation gate
            // on abort; cleanup cannot deadlock a rejecting activation writer.
            for (auto& worker : workers) { worker->decide(2U); }
            workers.clear();
        }
        void publish() noexcept override {
            // Capacity was reserved at registry construction, before workers
            // existed. unique_ptr moves and atomic release/notify cannot throw.
            for (std::size_t i = 0U; i < workers.size(); ++i) {
                owner_.stats_.push_back(std::move(stats[i]));
                owner_.workers_.push_back(std::move(workers[i]));
                owner_.workers_.back()->decide(1U);
            }
            workers.clear();
            stats.clear();
        }
        std::vector<std::unique_ptr<PeerRuntimeStats>> stats;
        std::vector<std::unique_ptr<ParkedWorker>> workers;
    private:
        PeerSchedulerRegistry& owner_;
    };

public:
    PeerSchedulerRegistry(NodeState& state, TlsContext& tls,
        RuntimeConfiguration& runtime, SchedulerSignal& signal,
        std::atomic<bool>& stopping)
        : state_(state), tls_(tls), runtime_(runtime), signal_(signal), stopping_(stopping) {
        stats_.reserve(maximum_peer_registry_size);
        workers_.reserve(maximum_peer_registry_size);
    }
    ~PeerSchedulerRegistry() { stop_and_join(); }
    PeerSchedulerRegistry(const PeerSchedulerRegistry&) = delete;
    PeerSchedulerRegistry& operator=(const PeerSchedulerRegistry&) = delete;

    // Called only during single-threaded startup or a serialized activation.
    // Preparation does not modify any published vector or activate a scheduler.
    [[nodiscard]] std::unique_ptr<PreparedPeerRegistryChange> prepare(
        const std::vector<std::string>& nodes, const bool startup = false) {
        if (stopping_.load()) { app_fail("CONFIG_RUNTIME_STOPPING", "runtime is shutting down"); }
        if (nodes.size() > maximum_peer_registry_size - stats_.size()) {
            app_fail("CONFIG_PEER_REGISTRY_LIMIT", "historical scheduler capacity is exhausted");
        }
        try {
            auto result = std::make_unique<Preparation>(*this);
            result->stats.reserve(nodes.size());
            result->workers.reserve(nodes.size());
            for (const auto& node : nodes) {
                if (std::any_of(stats_.begin(), stats_.end(), [&](const auto& old) { return old->node_id == node; })) {
                    app_fail("CONFIG_PEER_REGISTRY_CONFLICT", "scheduler identity already registered");
                }
                const char* fail_peer = std::getenv("NATRAV_OVERLAY_TEST_REGISTRY_FAIL_PEER");
                if (!startup && fail_peer != nullptr && node == fail_peer) {
                    throw std::system_error(std::make_error_code(std::errc::resource_unavailable_try_again));
                }
                auto entry = std::make_unique<PeerRuntimeStats>();
                entry->node_id = node;
                auto worker = std::make_unique<ParkedWorker>();
                auto* const entry_ptr = entry.get();
                auto* const worker_ptr = worker.get();
                worker->thread = std::thread([this, entry_ptr, worker_ptr] {
                    worker_ptr->decision.wait(0U, std::memory_order_acquire);
                    if (worker_ptr->decision.load(std::memory_order_acquire) != 1U) { return; }
                    try {
                        scheduler_loop(state_, tls_, runtime_, *entry_ptr, signal_, stopping_);
                    } catch (const std::exception& error) {
                        std::cerr << error_json("SCHEDULER_FATAL", error.what()) << '\n';
                        signal_.record_failure();
                        stopping_.store(true);
                        signal_.notify();
                    }
                });
                result->stats.push_back(std::move(entry));
                result->workers.push_back(std::move(worker));
            }
            return result;
        } catch (const std::system_error&) {
            app_fail("CONFIG_PEER_PREPARATION_FAILED", "could not prepare peer scheduler threads; no membership published");
        } catch (const std::bad_alloc&) {
            app_fail("CONFIG_PEER_PREPARATION_FAILED", "could not allocate peer scheduler resources; no membership published");
        }
    }
    [[nodiscard]] const std::vector<std::unique_ptr<PeerRuntimeStats>>& stats() const noexcept { return stats_; }

    // Control workers (the only membership writers) must be joined first.
    void stop_and_join() {
        stopping_.store(true);
        signal_.notify();
        workers_.clear();
    }
private:
    NodeState& state_;
    TlsContext& tls_;
    RuntimeConfiguration& runtime_;
    SchedulerSignal& signal_;
    std::atomic<bool>& stopping_;
    std::vector<std::unique_ptr<PeerRuntimeStats>> stats_;
    std::vector<std::unique_ptr<ParkedWorker>> workers_;
};

struct ActionRuntimeStats final {
    // Serializes the durable begin/complete boundary with local cancellation.
    std::mutex transition_mutex;
    std::atomic<std::uint64_t> attempts{0U};
    std::atomic<std::uint64_t> executed{0U};
    std::atomic<std::uint64_t> cancelled{0U};
    std::atomic<std::uint64_t> expired{0U};
    std::atomic<std::uint64_t> failures{0U};
    std::atomic<std::uint64_t> selections{0U};
    std::atomic<std::uint64_t> index_nodes_visited{0U};
    std::atomic<std::uint64_t> metadata_records_read{0U};
    std::atomic<std::uint64_t> stale_selections{0U};
};

struct RuntimeStats final {
    std::atomic<std::uint64_t> peer_accepted{0U};
    std::atomic<std::uint64_t> peer_queued{0U};
    std::atomic<std::uint64_t> peer_busy{0U};
    std::atomic<std::uint64_t> peer_completed{0U};
    std::atomic<std::uint64_t> peer_committed{0U};
    std::atomic<std::uint64_t> peer_duplicate{0U};
    std::atomic<std::uint64_t> peer_rejected{0U};
    std::atomic<std::uint64_t> peer_authenticated{0U};
    std::atomic<std::uint64_t> peer_transport_errors{0U};
    std::atomic<std::uint64_t> peer_authorization_denied{0U};
    std::atomic<std::uint64_t> peer_actions_queued{0U};
    std::atomic<std::uint64_t> peer_session_connections{0U};
    std::atomic<std::uint64_t> peer_legacy_connections{0U};
    std::atomic<std::uint64_t> peer_session_operations{0U};
    std::atomic<std::uint64_t> peer_session_clean_closes{0U};
    std::atomic<std::uint64_t> peer_session_retirements{0U};
    std::atomic<std::uint64_t> control_accepted{0U};
    std::atomic<std::uint64_t> control_queued{0U};
    std::atomic<std::uint64_t> control_busy{0U};
    std::atomic<std::uint64_t> control_completed{0U};
    std::atomic<std::uint64_t> control_errors{0U};
    std::atomic<std::uint64_t> control_authorized{0U};
    std::atomic<std::uint64_t> control_denied{0U};
    std::atomic<std::uint64_t> peer_active{0U};
};

class AtomicActivityGuard final {
public:
    explicit AtomicActivityGuard(std::atomic<std::uint64_t>& counter)
        : counter_(counter) { ++counter_; }
    ~AtomicActivityGuard() { --counter_; }
    AtomicActivityGuard(const AtomicActivityGuard&) = delete;
    AtomicActivityGuard& operator=(const AtomicActivityGuard&) = delete;
private:
    std::atomic<std::uint64_t>& counter_;
};

enum class RuntimeServiceMode : std::uint8_t {
    running = 0U,
    quiesced = 1U,
    draining = 2U,
};

[[nodiscard]] std::string_view runtime_service_mode_name(
    const RuntimeServiceMode mode) noexcept {
    switch (mode) {
        case RuntimeServiceMode::running: return "RUNNING";
        case RuntimeServiceMode::quiesced: return "QUIESCED";
        case RuntimeServiceMode::draining: return "DRAINING";
    }
    return "UNKNOWN";
}

class ServiceLifecycle final {
public:
    explicit ServiceLifecycle(const std::vector<LifecycleEvent>& history) {
        RuntimeServiceMode reconstructed = RuntimeServiceMode::running;
        bool interrupted = false;
        for (const auto& event : history) {
            switch (event.kind) {
                case LifecycleTransitionKind::quiesced:
                    reconstructed = RuntimeServiceMode::quiesced;
                    interrupted = false;
                    break;
                case LifecycleTransitionKind::resumed:
                    reconstructed = RuntimeServiceMode::running;
                    interrupted = false;
                    break;
                case LifecycleTransitionKind::drain_started:
                    // A process that disappears after this synchronized account
                    // must not silently begin accepting local mutations again.
                    reconstructed = RuntimeServiceMode::quiesced;
                    interrupted = true;
                    break;
                case LifecycleTransitionKind::drain_completed:
                case LifecycleTransitionKind::drain_deadline:
                    // A completed drain is a bounded stop, not persistent
                    // quiescence. A later start returns to ordinary service.
                    reconstructed = RuntimeServiceMode::running;
                    interrupted = false;
                    break;
                case LifecycleTransitionKind::shutdown_requested:
                    // Ordinary shutdown records provenance without implicitly
                    // resuming a deliberately quiesced service.
                    break;
            }
        }
        mode_.store(static_cast<std::uint8_t>(reconstructed));
        interrupted_drain_.store(interrupted);
    }

    [[nodiscard]] RuntimeServiceMode mode() const noexcept {
        return static_cast<RuntimeServiceMode>(mode_.load());
    }
    [[nodiscard]] bool interrupted_drain() const noexcept {
        return interrupted_drain_.load();
    }
    [[nodiscard]] bool local_submissions_accepted() const noexcept {
        return mode() == RuntimeServiceMode::running;
    }
    [[nodiscard]] bool peer_admissions_accepted() const noexcept {
        return mode() != RuntimeServiceMode::draining;
    }
    [[nodiscard]] bool ready() const noexcept {
        return mode() != RuntimeServiceMode::draining;
    }
    std::mutex& transition_mutex() noexcept { return transition_mutex_; }
    void publish(const RuntimeServiceMode mode, const bool interrupted = false) noexcept {
        interrupted_drain_.store(interrupted);
        mode_.store(static_cast<std::uint8_t>(mode));
    }

private:
    std::atomic<std::uint8_t> mode_{static_cast<std::uint8_t>(RuntimeServiceMode::running)};
    std::atomic<bool> interrupted_drain_{false};
    std::mutex transition_mutex_;
};

struct LocalPrincipal final {
    std::uint32_t uid{0U};
    std::uint32_t gid{0U};
    std::uint32_t pid{0U};
};

// Exactly one owned connection may be deferred. Control workers access this
// slot only under ServiceLifecycle::transition_mutex(). The coordinator reads
// it only after joining every control worker. No generation lease crosses a
// join: a queued configuration publisher must be allowed to finish or reject.
struct TerminalHeadHandoff final {
    datacube::Fd connection;
    LocalPrincipal principal;
    datacube::Digest32 request_id;
    IoOptions io;
    std::optional<LifecycleEvent> drain_terminal;
    std::optional<std::string> correlation;
};

[[nodiscard]] bool requests_terminal_head(const ControlRequest& request) noexcept {
    if (const auto* stop = std::get_if<ControlShutdown>(&request)) return stop->final_state_head;
    if (const auto* drain = std::get_if<ControlDrainShutdown>(&request)) return drain->final_state_head;
    return false;
}

[[nodiscard]] bool terminal_head_inspection_allowed(
    const RuntimeConfig& config, const std::uint32_t uid) {
    return local_control_allows(config.local_control, uid, LocalControlClass::inspect);
}


[[nodiscard]] LocalPrincipal local_principal(const int fd) {
    struct ucred credentials {};
    socklen_t size = static_cast<socklen_t>(sizeof(credentials));
    if (::getsockopt(fd, SOL_SOCKET, SO_PEERCRED, &credentials, &size) != 0 ||
        size != sizeof(credentials) || credentials.pid <= 0) {
        app_fail("LOCAL_CONTROL_CREDENTIALS_UNAVAILABLE",
            datacube::errno_detail("SO_PEERCRED", errno));
    }
    if (static_cast<std::uint64_t>(credentials.uid) >
            std::numeric_limits<std::uint32_t>::max() ||
        static_cast<std::uint64_t>(credentials.gid) >
            std::numeric_limits<std::uint32_t>::max() ||
        static_cast<std::uint64_t>(credentials.pid) >
            std::numeric_limits<std::uint32_t>::max()) {
        app_fail("LOCAL_CONTROL_CREDENTIALS_INVALID",
            "kernel peer credentials exceed the supported account envelope");
    }
    return LocalPrincipal{
        .uid = static_cast<std::uint32_t>(credentials.uid),
        .gid = static_cast<std::uint32_t>(credentials.gid),
        .pid = static_cast<std::uint32_t>(credentials.pid),
    };
}

[[nodiscard]] bool local_policy_mentions_uid(
    const LocalControlPolicy& policy,
    const std::uint32_t uid) noexcept {
    return std::any_of(policy.grants.begin(), policy.grants.end(),
        [uid](const LocalControlGrant& grant) { return grant.uid == uid; });
}

struct ControlMetadata final {
    std::string command;
    LocalControlClass command_class{LocalControlClass::inspect};
    bool mutating{false};
};

[[nodiscard]] ControlMetadata control_metadata(const ControlRequest& request) {
    if(const auto* a=std::get_if<ImportAutoRequest>(&request)) {
        return ControlMetadata{.command=a->command==ImportAutoCommand::retire?"SOURCE_VIEW_RETIRE":a->command==ImportAutoCommand::retirement_status?"SOURCE_VIEW_RETIREMENT_STATUS":a->command==ImportAutoCommand::enable?"SOURCE_VIEW_AUTO_ENABLE":a->command==ImportAutoCommand::pause?"SOURCE_VIEW_AUTO_PAUSE":a->command==ImportAutoCommand::review?"SOURCE_VIEW_DECISIONS":a->command==ImportAutoCommand::reconsider?"SOURCE_VIEW_RETRY":"SOURCE_VIEW_AUTO_STATUS",.command_class=LocalControlClass::source_import,.mutating=!import_observational(a->command)};
    }
    if (std::holds_alternative<SourceViewRequest>(request)) {
        return ControlMetadata{.command="SOURCE_VIEW_IMPORT",.command_class=LocalControlClass::source_import,.mutating=true};
    }
    if (const auto* subscription = std::get_if<SourceSubscriptionRequest>(&request)) {
        return ControlMetadata{.command = subscription->command == SourceSubscriptionCommand::reconcile ? "SOURCE_SUBSCRIPTION_RECONCILE" :
            subscription->command == SourceSubscriptionCommand::succeed ? "SOURCE_SUBSCRIPTION_SUCCEED" :
            subscription->command == SourceSubscriptionCommand::create ? "SOURCE_SUBSCRIPTION_CREATE" :
            subscription->command == SourceSubscriptionCommand::step ? "SOURCE_SUBSCRIPTION_STEP" :
            subscription->command == SourceSubscriptionCommand::retire ? "SOURCE_SUBSCRIPTION_RETIRE" :
            subscription->command == SourceSubscriptionCommand::automatic_enable ? "SOURCE_SUBSCRIPTION_AUTO_ENABLE" :
            subscription->command == SourceSubscriptionCommand::automatic_pause ? "SOURCE_SUBSCRIPTION_AUTO_PAUSE" :
            subscription->command == SourceSubscriptionCommand::automatic_status ? "SOURCE_SUBSCRIPTION_AUTO_STATUS" :
            "SOURCE_SUBSCRIPTION_STATUS",
            .command_class = LocalControlClass::source_disclose,
            .mutating = subscription->command != SourceSubscriptionCommand::status &&
                subscription->command != SourceSubscriptionCommand::automatic_status};
    }
    if (std::holds_alternative<ControlAuthor>(request)) {
        return ControlMetadata{.command = "EVIDENCE_AUTHOR",
            .command_class = LocalControlClass::evidence_author, .mutating = true};
    }
    if (const auto* submit = std::get_if<ControlSubmit>(&request)) {
        const bool action = operation_class_for(submit->record) ==
            AuthorizedOperationClass::counter_action;
        return ControlMetadata{
            .command = action ? "ACTION_SUBMIT" : "SUBMIT",
            .command_class = action ? LocalControlClass::action : LocalControlClass::submit,
            .mutating = true,
        };
    }
    if (const auto* channel = std::get_if<PublicationChannelRequest>(&request)) {
        return ControlMetadata{
            .command = channel->command == PublicationChannelCommand::create ? "PUBLICATION_CHANNEL_CREATE" :
                channel->command == PublicationChannelCommand::publish ? "PUBLICATION_CHANNEL_PUBLISH" :
                channel->command == PublicationChannelCommand::retire ? "PUBLICATION_CHANNEL_RETIRE" :
                channel->command == PublicationChannelCommand::automatic_enable ? "PUBLICATION_CHANNEL_AUTO_ENABLE" :
                channel->command == PublicationChannelCommand::automatic_pause ? "PUBLICATION_CHANNEL_AUTO_PAUSE" :
                channel->command == PublicationChannelCommand::automatic_status ? "PUBLICATION_CHANNEL_AUTO_STATUS" :
                channel->command == PublicationChannelCommand::new_epoch ? "PUBLICATION_CHANNEL_NEW_EPOCH" :
                "PUBLICATION_CHANNEL_STATUS",
            .command_class = LocalControlClass::projection,
            .mutating = channel->command != PublicationChannelCommand::status &&
                channel->command != PublicationChannelCommand::automatic_status,
        };
    }
    if (const auto* consumer = std::get_if<ConsumerRequest>(&request)) {
        const auto command = consumer->command;
        return ControlMetadata{
            .command = command == ConsumerCommand::projection_publish ? "PROJECTION_PUBLISH" :
                command == ConsumerCommand::retire ? "CONSUMER_RETIRE" :
                command == ConsumerCommand::retirement_status ? "CONSUMER_RETIREMENT_STATUS" :
                command == ConsumerCommand::projection_enable ? "PROJECTION_ENABLE" :
                command == ConsumerCommand::projection_pause ? "PROJECTION_PAUSE" :
                command == ConsumerCommand::projection_schedule_status ? "PROJECTION_SCHEDULE_STATUS" :
                command == ConsumerCommand::projection_create ? "PROJECTION_CREATE" :
                command == ConsumerCommand::projection_process ? "PROJECTION_PROCESS" :
                command == ConsumerCommand::projection_status ? "PROJECTION_STATUS" :
                command == ConsumerCommand::projection_rebuild ? "PROJECTION_REBUILD" :
                command == ConsumerCommand::create ? "CONSUMER_CREATE" :
                command == ConsumerCommand::read ? "CONSUMER_READ" :
                command == ConsumerCommand::acknowledge ? "CONSUMER_ACK" :
                command == ConsumerCommand::reset ? "CONSUMER_RESET" : "CONSUMER_STATUS",
            .command_class = (consumer_reset(command)||schedule_command(command)||retirement_command(command)) ? LocalControlClass::consumer_admin : (projection_command(command) ? LocalControlClass::projection : LocalControlClass::consumer),
            .mutating = !consumer_status(command)};
    }
    if (const auto* feed = std::get_if<EvidenceFeed>(&request)) {
        return ControlMetadata{.command = "EVIDENCE_FEED",
            .command_class = feed->include_payload ? LocalControlClass::evidence_payload : LocalControlClass::evidence_read};
    }
    if (const auto* query = std::get_if<EvidenceQuery>(&request)) {
        return ControlMetadata{.command = "EVIDENCE_QUERY",
            .command_class = query->include_payload ? LocalControlClass::evidence_payload : LocalControlClass::evidence_read};
    }
    if (std::holds_alternative<ControlHistoryRequest>(request)) {
        return ControlMetadata{.command="CONTROL_HISTORY", .command_class=LocalControlClass::inspect};
    }
    if (std::holds_alternative<ConfigurationHistoryRequest>(request)) {
        return ControlMetadata{.command="CONFIGURATION_HISTORY", .command_class=LocalControlClass::inspect};
    }
    if (std::holds_alternative<RuntimeInventory>(request)) {
        return ControlMetadata{.command="RUNTIME_INVENTORY", .command_class=LocalControlClass::inspect};
    }
    if (std::holds_alternative<ResultReviewRequest>(request)) {
        return ControlMetadata{.command="ACTION_RESULT_REVIEW", .command_class=LocalControlClass::maintenance, .mutating=true};
    }
    if (std::holds_alternative<ResultReviewStatus>(request)) {
        return ControlMetadata{.command="ACTION_RESULT_REVIEW_STATUS", .command_class=LocalControlClass::inspect};
    }
    if (std::holds_alternative<ViewBindings>(request)) {
        return ControlMetadata{.command="SOURCE_VIEW_BINDINGS", .command_class=LocalControlClass::source_import};
    }
    if (std::holds_alternative<SourceViewInventory>(request)) {
        return ControlMetadata{.command="SOURCE_VIEW_INVENTORY", .command_class=LocalControlClass::source_import};
    }
    if (std::holds_alternative<SubscriptionInventory>(request)) {
        return ControlMetadata{.command="SOURCE_SUBSCRIPTION_INVENTORY", .command_class=LocalControlClass::source_disclose};
    }
    if (std::holds_alternative<PublicationInventory>(request)) {
        return ControlMetadata{.command="PUBLICATION_CHANNEL_INVENTORY", .command_class=LocalControlClass::projection};
    }
    if (std::holds_alternative<ConsumerInventory>(request)) {
        return ControlMetadata{.command="CONSUMER_INVENTORY", .command_class=LocalControlClass::consumer};
    }
    if (std::holds_alternative<ResultReviewHistory>(request)) {
        return ControlMetadata{.command="ACTION_RESULT_REVIEW_HISTORY", .command_class=LocalControlClass::inspect};
    }
    if (std::holds_alternative<ActionResultDiscovery>(request)) {
        return ControlMetadata{.command="ACTION_RESULT_DISCOVER", .command_class=LocalControlClass::inspect};
    }
    if (std::holds_alternative<ActionResultQuery>(request)) {
        return ControlMetadata{.command="ACTION_RESULT_QUERY", .command_class=LocalControlClass::inspect};
    }
    if (std::holds_alternative<ActionQuery>(request)) {
        return ControlMetadata{.command="ACTION_QUERY", .command_class=LocalControlClass::inspect};
    }
    if (std::holds_alternative<OutboxQuery>(request)) {
        return ControlMetadata{.command = "OUTBOX_QUERY", .command_class = LocalControlClass::inspect};
    }
    if (std::holds_alternative<ControlStateHead>(request)) {
        return ControlMetadata{.command = "STATE_HEAD", .command_class = LocalControlClass::inspect};
    }
    if (std::holds_alternative<ControlSnapshot>(request)) {
        return ControlMetadata{.command = "STATUS", .command_class = LocalControlClass::inspect};
    }
    if (std::holds_alternative<ControlWake>(request)) {
        return ControlMetadata{.command = "WAKE", .command_class = LocalControlClass::maintenance, .mutating = true};
    }
    if (const auto* shutdown = std::get_if<ControlShutdown>(&request)) {
        return ControlMetadata{
            .command = shutdown->correlation.has_value() ?
                (shutdown->final_state_head ? "SHUTDOWN_TERMINAL_CORRELATED" :
                    "SHUTDOWN_CORRELATED") : "SHUTDOWN",
            .command_class = LocalControlClass::shutdown,
            .mutating = true,
        };
    }
    if (const auto* action = std::get_if<OutboxAdminRequest>(&request)) {
        return ControlMetadata{.command="CONDITIONAL_"+std::string(outbox_admin_kind_name(action->kind)),.command_class=LocalControlClass::maintenance,.mutating=true};
    }
    if (std::holds_alternative<ActionAdminRequest>(request)) {
        return ControlMetadata{.command="CONDITIONAL_ACTION_CANCEL",
            .command_class=LocalControlClass::action,.mutating=true};
    }
    if (std::holds_alternative<ControlRebind>(request)) {
        return ControlMetadata{.command = "REBIND", .command_class = LocalControlClass::maintenance, .mutating = true};
    }
    if (std::holds_alternative<ControlCancel>(request)) {
        return ControlMetadata{.command = "CANCEL", .command_class = LocalControlClass::maintenance, .mutating = true};
    }
    if (std::holds_alternative<ControlRetry>(request)) {
        return ControlMetadata{.command = "RETRY", .command_class = LocalControlClass::maintenance, .mutating = true};
    }
    if (std::holds_alternative<ControlCustodyDispatchStatus>(request)) {
        return ControlMetadata{.command = "CUSTODY_DISPATCH_STATUS",
            .command_class = LocalControlClass::maintenance, .mutating = false};
    }
    if (std::holds_alternative<ControlCustodyDispatchInventory>(request)) {
        return ControlMetadata{.command = "CUSTODY_DISPATCH_INVENTORY",
            .command_class = LocalControlClass::maintenance, .mutating = false};
    }
    if (std::holds_alternative<ControlCustodyDispatch>(request)) {
        return ControlMetadata{.command = "CUSTODY_DISPATCH",
            .command_class = LocalControlClass::maintenance, .mutating = true};
    }
    if (std::holds_alternative<ControlActionCancel>(request)) {
        return ControlMetadata{.command = "ACTION_CANCEL", .command_class = LocalControlClass::action, .mutating = true};
    }
    if (std::holds_alternative<ControlCompact>(request)) {
        return ControlMetadata{.command = "COMPACT", .command_class = LocalControlClass::maintenance, .mutating = true};
    }
    if (const auto* configuration = std::get_if<ControlConfiguration>(&request)) {
        return ControlMetadata{
            .command = configuration->rollback_generation.empty() ? "CONFIG_ACTIVATE" : "CONFIG_ROLLBACK",
            .command_class = LocalControlClass::configuration,
            .mutating = true,
        };
    }
    if (std::holds_alternative<ControlQuiesce>(request)) {
        return ControlMetadata{.command = "QUIESCE", .command_class = LocalControlClass::shutdown, .mutating = true};
    }
    if (std::holds_alternative<ControlResume>(request)) {
        return ControlMetadata{.command = "RESUME", .command_class = LocalControlClass::shutdown, .mutating = true};
    }
    const auto& drain = std::get<ControlDrainShutdown>(request);
    return ControlMetadata{
        .command = drain.correlation.has_value() ?
            (drain.final_state_head ? "DRAIN_SHUTDOWN_TERMINAL_CORRELATED" :
                "DRAIN_SHUTDOWN_CORRELATED") : "DRAIN_SHUTDOWN",
        .command_class = LocalControlClass::shutdown,
        .mutating = true,
    };
}

[[nodiscard]] std::uint64_t configuration_event_for(
    const NodeState& state,
    const RuntimeConfig& config) {
    if (config.runtime_generation.empty()) { return 0U; }
    const auto canonical = canonical_runtime_config(config);
    return state.configuration_event_reference(config.runtime_generation,
        runtime_configuration_digest(canonical), canonical);
}

[[nodiscard]] datacube::Digest32 synthetic_control_request_id(
    const LocalPrincipal& principal,
    const std::uint64_t unix_ms,
    const std::string_view purpose) {
    datacube::Octets material;
    datacube::append_text(material, "NATRAV_OVERLAY_SYNTHETIC_CONTROL_REQUEST_V1");
    datacube::append_u8(material, 0U);
    datacube::append_be32(material, principal.uid);
    datacube::append_be32(material, principal.gid);
    datacube::append_be32(material, principal.pid);
    datacube::append_be64(material, unix_ms);
    datacube::append_text(material, purpose);
    return datacube::sha256(material);
}

void record_control_decision(
    NodeState& state,
    RuntimeStats& stats,
    const LocalPrincipal& principal,
    const datacube::Digest32& request_id,
    const ControlMetadata& metadata,
    const std::uint64_t configuration_event,
    const LocalControlDecisionKind decision,
    const std::string_view error_code = {}) {
    if (decision == LocalControlDecisionKind::authorized) {
        ++stats.control_authorized;
    } else {
        ++stats.control_denied;
    }
    // V6 and V7 predate explicit local-principal policy. Their owner-only
    // compatibility behavior remains process-local; V8 decisions are durable.
    if (configuration_event == 0U) { return; }
    state.record_local_control_event(LocalControlEvent{
        .request_id = request_id,
        .uid = principal.uid,
        .gid = principal.gid,
        .pid = principal.pid,
        .command = metadata.command,
        .command_class = std::string(local_control_class_name(metadata.command_class)),
        .configuration_event = configuration_event,
        .unix_ms = unix_milliseconds(),
        .decision = decision,
        .error_code = std::string(error_code),
    });
}

[[nodiscard]] std::string annotate_control_json(
    std::string json,
    const LocalPrincipal& principal,
    const datacube::Digest32& request_id,
    const std::string_view command_class) {
    if (json.empty() || json.back() != '}') { return json; }
    json.pop_back();
    json += ",\"request_id\":" + json_string(datacube::hex_lower(request_id)) +
        ",\"principal_uid\":" + std::to_string(principal.uid) +
        ",\"principal_gid\":" + std::to_string(principal.gid) +
        ",\"principal_pid\":" + std::to_string(principal.pid) +
        ",\"command_class\":" + json_string(command_class) + "}";
    return json;
}

[[nodiscard]] std::string_view outbound_session_state_name(
    const std::uint8_t state) noexcept {
    switch (state) {
        case 0U: return "DISCONNECTED";
        case 1U: return "OPENING";
        case 2U: return "ACTIVE";
        case 3U: return "RETIRING";
    }
    return "UNKNOWN";
}

[[nodiscard]] OutboundPolicy policy_for(
    const PeerConfig& peer,
    const std::uint64_t now) {
    return OutboundPolicy{
        .created_unix_ms = now,
        .expires_unix_ms = saturating_add(now, peer.delivery.expiry_ms),
        .maximum_attempts = peer.delivery.maximum_attempts,
        .initial_backoff_ms = peer.delivery.initial_backoff_ms,
        .maximum_backoff_ms = peer.delivery.maximum_backoff_ms,
        .peer_spki_sha256 = peer.active_spki_sha256,
        .peer_generation = peer.active_generation,
    };
}

void validate_durable_peer_bindings(
    const RuntimeConfig& config,
    const StateSnapshot& snapshot) {
    for (const auto& entry : snapshot.outbound) {
        if (!outbound_is_pending(entry) || !entry.delivery.has_value()) {
            continue;
        }
        const auto* peer = find_peer(config, entry.record.recipient);
        if (peer == nullptr) {
            app_fail("OUTBOUND_PEER_NOT_CONFIGURED",
                "pending operation recipient is not present in the runtime configuration: " +
                entry.record.recipient);
        }
        const auto& pin = entry.delivery->policy.peer_spki_sha256;
        const auto& generation = entry.delivery->policy.peer_generation;
        if (!pin.has_value() || !generation.has_value()) {
            app_fail("OUTBOUND_GENERATION_BINDING_REQUIRED",
                "pending operation predates durable generation binding: " +
                operation_id_text(entry.record.operation_id));
        }
        const auto* configured = find_peer_generation(
            config, peer->node_id, *generation);
        if (configured == nullptr) {
            app_fail("OUTBOUND_GENERATION_NOT_CONFIGURED",
                "pending operation names an absent peer generation: " +
                operation_id_text(entry.record.operation_id));
        }
        if (configured->spki_sha256 != *pin) {
            app_fail("OUTBOUND_GENERATION_PIN_MISMATCH",
                "pending operation generation and durable key pin disagree: " +
                operation_id_text(entry.record.operation_id));
        }
    }
}

[[nodiscard]] const PeerKeyGeneration* bound_generation(
    const RuntimeConfig& config,
    const StoredOutbound& entry) noexcept {
    if (!entry.delivery.has_value() ||
        !entry.delivery->policy.peer_generation.has_value() ||
        !entry.delivery->policy.peer_spki_sha256.has_value()) {
        return nullptr;
    }
    const auto* generation = find_peer_generation(
        config,
        entry.record.recipient,
        *entry.delivery->policy.peer_generation);
    if (generation == nullptr ||
        generation->spki_sha256 != *entry.delivery->policy.peer_spki_sha256) {
        return nullptr;
    }
    return generation;
}

// Observation must never synchronize (and thereby mutate) route state using a
// captured configuration that may already have been superseded.
[[nodiscard]] std::vector<PeerRouteRuntimeObservation> configured_route_observations(
    const PeerRuntimeStats& stats, const PeerConfig& peer) {
    const auto observed = route_observations(stats);
    std::vector<PeerRouteRuntimeObservation> result;
    result.reserve(peer.routes.size());
    for (const auto& route : peer.routes) {
        const auto endpoint = transport_locator_text(route.locator);
        const auto found = std::find_if(observed.begin(), observed.end(), [&](const auto& value) {
            return value.route_id == route.route_id && value.locator == endpoint &&
                value.priority == route.priority && value.configured_state == route.state;
        });
        if (found != observed.end()) result.push_back(*found);
        else {
            PeerRouteRuntimeObservation value;
            value.route_id = route.route_id; value.locator = endpoint;
            value.priority = route.priority; value.configured_state = route.state;
            value.telemetry_available = false;
            result.push_back(std::move(value));
        }
    }
    return result;
}

[[nodiscard]] std::string inventory_telemetry(const RuntimeConfig& config,
    const std::vector<std::unique_ptr<PeerRuntimeStats>>& registry,
    const std::string_view node, const std::string_view route) {
    const auto found = std::find_if(registry.begin(), registry.end(),
        [&](const auto& v) { return v->node_id == node; });
    if (found == registry.end()) app_fail("CONFIG_PEER_REGISTRY_INCOMPLETE", "inventory registry mismatch");
    const auto& run = **found;
    if (route.empty()) {
        return "{\"state\":" + json_string(outbound_session_state_name(run.session_state.load())) +
            ",\"attempts_this_run\":" + std::to_string(run.attempts.load()) +
            ",\"acknowledged_this_run\":" + std::to_string(run.acknowledged.load()) +
            ",\"failures_this_run\":" + std::to_string(run.failures.load()) +
            ",\"sessions_opened\":" + std::to_string(run.sessions_opened.load()) +
            ",\"sessions_reused\":" + std::to_string(run.sessions_reused.load()) +
            ",\"sessions_retired\":" + std::to_string(run.sessions_retired.load()) +
            ",\"sessions_failed\":" + std::to_string(run.sessions_failed.load()) +
            ",\"configuration_drains\":" + std::to_string(run.configuration_drains.load()) + "}";
    }
    const auto* peer = find_peer(config, node);
    const auto* selected = peer ? find_peer_route(*peer, route) : nullptr;
    if (!selected) app_fail("CONFIG_PEER_REGISTRY_INCOMPLETE", "route inventory mismatch");
    const auto endpoint = transport_locator_text(selected->locator);
    // Copy no other routes and retain no reference after unlocking.
    std::lock_guard<std::mutex> lock(run.route_mutex);
    const auto observation = std::find_if(run.route_observations.begin(), run.route_observations.end(), [&](const auto& v) {
        return v.route_id == route && v.locator == endpoint && v.priority == selected->priority && v.configured_state == selected->state;
    });
    if (observation == run.route_observations.end()) return "null";
    const auto& v = *observation; const auto now = unix_milliseconds();
    return "{\"sampled_unix_ms\":" + std::to_string(now) + ",\"active_session\":" + (v.active_session ? "true" : "false") +
        ",\"selections_this_run\":" + std::to_string(v.selections) +
        ",\"connection_attempts_this_run\":" + std::to_string(v.connection_attempts) +
        ",\"connection_successes_this_run\":" + std::to_string(v.connection_successes) +
        ",\"consecutive_failures\":" + std::to_string(v.consecutive_failures) +
        ",\"last_failure_code\":" + (v.last_failure_code.empty() ? "null" : json_string(v.last_failure_code)) +
        ",\"last_failure_unix_ms\":" + std::to_string(v.last_failure_unix_ms) +
        ",\"last_success_unix_ms\":" + std::to_string(v.last_success_unix_ms) +
        ",\"cooldown_until_unix_ms\":" + std::to_string(v.cooldown_until_unix_ms) +
        ",\"cooldown_remaining_ms\":" + std::to_string(v.cooldown_until_unix_ms > now ? v.cooldown_until_unix_ms-now : 0U) + "}";
}

[[nodiscard]] std::string local_policy_preview(const LocalControlPolicy& policy) {
    LocalControlPolicy limited; limited.digest=policy.digest; limited.legacy_owner_default=policy.legacy_owner_default;
    for (const auto& grant : policy.grants) {
        if (limited.grants.size()==8U) break;
        limited.grants.push_back(grant);
        if (local_control_policy_json(limited).size()>2048U) { limited.grants.pop_back(); break; }
    }
    auto out=local_control_policy_json(limited); out.pop_back();
    return out+",\"total\":"+std::to_string(policy.grants.size())+",\"returned\":"+std::to_string(limited.grants.size())+
        ",\"truncated\":"+(limited.grants.size()!=policy.grants.size()?"true":"false")+"}";
}
[[nodiscard]] std::string read_policy_preview(const EvidenceReadPolicy& policy) {
    EvidenceReadPolicy limited; limited.digest=policy.digest; limited.scoped=policy.scoped;
    for (const auto& grant : policy.grants) {
        if (limited.grants.size()==8U) break;
        limited.grants.push_back(grant);
        if (evidence_read_policy_json(limited).size()>2048U) { limited.grants.pop_back(); break; }
    }
    auto out=evidence_read_policy_json(limited); out.pop_back();
    return out+",\"total\":"+std::to_string(policy.grants.size())+",\"returned\":"+std::to_string(limited.grants.size())+
        ",\"truncated\":"+(limited.grants.size()!=policy.grants.size()?"true":"false")+"}";
}

[[nodiscard]] std::string compact_runtime_status_json(
    const RuntimeConfig& config,
    const NodeState& state,
    const RuntimeStats& stats,
    const std::vector<PeerRuntimeStats*>& peer_stats,
    const ActionRuntimeStats& action_stats,
    const ServiceLifecycle& lifecycle,
    const TransportLocator& bound_listen_locator,
    const bool stopping, const bool logical_digest, const bool counters_only = false) {
    std::vector<std::string> nodes; nodes.reserve(peer_stats.size());
    for (const auto* peer : peer_stats) nodes.push_back(peer->node_id);
    const auto snapshot = state.runtime_status_metadata(config, nodes, logical_digest, counters_only);
    std::string out = "{\"format\":\"NATRAV_OVERLAY_RUNTIME_STATUS_V14\",\"ok\":true";
    out += ",\"node\":" + json_string(config.local_node);
    out += ",\"transport\":\"TLS1.3_MTLS_KEY_GENERATION_V1\"";
    out += ",\"identity_generation\":" +
        json_string(config.local_identity_generation);
    out += ",\"identity_spki_sha256\":" +
        json_string(spki_sha256_text(config.identity.expected_spki_sha256));
    out += ",\"stopping\":" + std::string(stopping ? "true" : "false");
    const auto service_mode = lifecycle.mode();
    out += ",\"lifecycle\":{\"mode\":" +
        json_string(runtime_service_mode_name(service_mode)) +
        ",\"live\":true" +
        ",\"ready\":" + std::string(lifecycle.ready() ? "true" : "false") +
        ",\"state_owned\":true" +
        ",\"local_mutations_accepted\":" +
        std::string(lifecycle.local_submissions_accepted() ? "true" : "false") +
        ",\"local_submissions_accepted\":" +
        std::string(lifecycle.local_submissions_accepted() ? "true" : "false") +
        ",\"peer_admissions_accepted\":" +
        std::string(lifecycle.peer_admissions_accepted() ? "true" : "false") +
        ",\"draining\":" +
        std::string(service_mode == RuntimeServiceMode::draining ? "true" : "false") +
        ",\"quiesced\":" +
        std::string(service_mode == RuntimeServiceMode::quiesced ? "true" : "false") +
        ",\"interrupted_drain\":" +
        std::string(lifecycle.interrupted_drain() ? "true" : "false") +
        ",\"events\":" + std::to_string(snapshot.lifecycle_events) + "}";
    out += ",\"local_control\":" + local_policy_preview(config.local_control);
    out.pop_back();
    out += ",\"authorized_this_run\":" +
        std::to_string(stats.control_authorized.load()) +
        ",\"denied_this_run\":" +
        std::to_string(stats.control_denied.load()) +
        ",\"durable_events\":" +
        std::to_string(snapshot.local_control_events) + "}";
    out += ",\"evidence_read_policy\":" + read_policy_preview(config.evidence_read);
    out += ",\"listen\":" + json_string(
        transport_locator_text(bound_listen_locator));
    out += ",\"control\":" + json_string(config.control_socket.string());
    out += snapshot.fields;
    out += ",\"projection_scheduling\":{\"registered\":" + std::to_string(snapshot.projection_schedules) +
        ",\"worker_threads\":1,\"service_suspended\":" + (service_mode == RuntimeServiceMode::running ? "false" : "true") + "}";
    out += ",\"publication_channels\":{\"registered\":" + std::to_string(snapshot.publication_channels) + "}";
    out += ",\"actions\":" + snapshot.actions;
    out.pop_back();
    out += ",\"attempts_this_run\":" + std::to_string(action_stats.attempts.load()) +
        ",\"executed_this_run\":" + std::to_string(action_stats.executed.load()) +
        ",\"cancelled_this_run\":" + std::to_string(action_stats.cancelled.load()) +
        ",\"expired_this_run\":" + std::to_string(action_stats.expired.load()) +
        ",\"failures_this_run\":" + std::to_string(action_stats.failures.load()) +
        ",\"selection_work\":{\"calls\":" + std::to_string(action_stats.selections.load()) +
        ",\"index_nodes_visited\":" + std::to_string(action_stats.index_nodes_visited.load()) +
        ",\"metadata_records_read\":" + std::to_string(action_stats.metadata_records_read.load()) +
        ",\"pending_vector_copies\":0,\"stale_selections\":" +
        std::to_string(action_stats.stale_selections.load()) + "}}";
    out += ",\"observation\":{\"state\":\"ONE_STATE_MUTEX_OBSERVATION\","
        "\"configuration\":\"AUTHORIZED_POST_DECODE_SNAPSHOT\","
        "\"runtime_counters\":\"INDEPENDENT_RUN_OBSERVATIONS\",\"work_scope\":\"FINAL_STATE_OBSERVATION\","
        "\"configuration_state_match\":" + std::string(snapshot.configuration_state_match ? "true" : "false") +
        ",\"authorized_configuration_digest\":" + json_string(snapshot.authorized_configuration_digest) + "}";
    out += ",\"status_work\":" + runtime_status_work_json(snapshot.work);
    out += ",\"inventory_api\":\"runtime-inventory\",\"summary_detail_mode\":" +
        json_string(counters_only ? "COUNTERS_ONLY_SIZE_FALLBACK" : "BOUNDED_PREVIEWS");
    out += ",\"peer_registry\":{\"capacity\":" + std::to_string(maximum_peer_registry_size) +
        ",\"registered\":" + std::to_string(peer_stats.size()) +
        ",\"remaining\":" + std::to_string(maximum_peer_registry_size - peer_stats.size()) +
        ",\"entries\":[";
    for (std::size_t index = 0U; index < std::min<std::size_t>(peer_stats.size(), 8U); ++index) {
        if (index != 0U) { out += ','; }
        const auto& node = peer_stats[index]->node_id;
        const bool routed = find_peer(config, node) != nullptr;
        const bool known_key = std::any_of(config.peer_generations.begin(), config.peer_generations.end(),
            [&](const auto& key) { return key.node_id == node; });
        const auto pending_for_peer = snapshot.peers.at(node).pending;
        out += "{\"node\":" + json_string(node) + ",\"role\":" +
            json_string(routed ? "ROUTED" : (known_key ? "INBOUND_ONLY" : "HISTORICAL")) +
            ",\"pending_records\":" + std::to_string(pending_for_peer) + "}";
    }
    out += "],\"returned\":" + std::to_string(std::min<std::size_t>(peer_stats.size(),8U)) +
        ",\"truncated\":" + (peer_stats.size()>8U?"true":"false") + "}";
    out += ",\"peers\":[";
    const auto peer_rows_begin=out.size();
    std::size_t peers_returned=0U;

    for (std::size_t index = 0U; index < std::min<std::size_t>(config.peers.size(), 8U); ++index) {
        const auto row_begin=out.size();
        if (index != 0U) { out += ','; }
        const auto& peer = config.peers[index];
        const auto found_run = std::find_if(peer_stats.begin(), peer_stats.end(),
            [&](const auto& run) { return run->node_id == peer.node_id; });
        if (found_run == peer_stats.end()) {
            app_fail("CONFIG_PEER_REGISTRY_INCOMPLETE", "active route has no published scheduler");
        }
        auto& run = **found_run;
        const auto route_status = configured_route_observations(run, peer);
        const auto selected_route = active_route_id(run);
        const auto& c = snapshot.peers.at(peer.node_id);
        const auto peer_pending = c.pending, peer_acked = c.acked, peer_expired = c.expired;
        const auto peer_cancelled = c.cancelled, peer_rejected = c.rejected, peer_unresolved = c.unresolved;
        const auto peer_reserved_records = c.reserved_records, peer_reserved_payload_bytes = c.reserved_payload_bytes;
        out += "{\"node\":" + json_string(peer.node_id) +
            ",\"endpoint\":" + (peer.routes.empty() ? std::string("null") :
                json_string(transport_locator_text(peer.routes.front().locator))) +
            ",\"active_generation\":" + json_string(peer.active_generation) +
            ",\"active_spki_sha256\":" +
            json_string(spki_sha256_text(peer.active_spki_sha256)) +
            ",\"pending\":" + std::to_string(peer_pending) +
            ",\"unresolved\":" + std::to_string(peer_unresolved) +
            ",\"acked\":" + std::to_string(peer_acked) +
            ",\"rejected\":" + std::to_string(peer_rejected) +
            ",\"expired\":" + std::to_string(peer_expired) +
            ",\"cancelled\":" + std::to_string(peer_cancelled) +
            ",\"reserved_records\":" +
            std::to_string(peer_reserved_records) +
            ",\"reserved_payload_bytes\":" +
            std::to_string(peer_reserved_payload_bytes) +
            ",\"future_result_records\":" + std::to_string(c.future_result_records) +
            ",\"future_result_payload_bytes\":" + std::to_string(c.future_result_payload_bytes) +
            ",\"selected_route\":" +
            (selected_route.empty() ? std::string("null") : json_string(selected_route)) +
            ",\"routes\":[";
        const auto route_now = unix_milliseconds();
        for (std::size_t route_index = 0U; route_index < route_status.size(); ++route_index) {
            if (route_index != 0U) { out += ','; }
            const auto& route = route_status[route_index];
            const auto cooldown_remaining = route.cooldown_until_unix_ms > route_now ?
                route.cooldown_until_unix_ms - route_now : 0U;
            out += "{\"id\":" + json_string(route.route_id) +
                ",\"endpoint\":" + json_string(route.locator) +
                ",\"priority\":" + std::to_string(route.priority) +
                ",\"state\":" + json_string(peer_route_state_name(route.configured_state)) +
                ",\"telemetry_available\":" + std::string(route.telemetry_available ? "true" : "false") +
                ",\"active_session\":" + std::string(route.active_session ? "true" : "false") +
                ",\"selections_this_run\":" + std::to_string(route.selections) +
                ",\"connection_attempts_this_run\":" + std::to_string(route.connection_attempts) +
                ",\"connection_successes_this_run\":" + std::to_string(route.connection_successes) +
                ",\"consecutive_failures\":" + std::to_string(route.consecutive_failures) +
                ",\"last_failure_code\":" +
                (route.last_failure_code.empty() ? std::string("null") : json_string(route.last_failure_code)) +
                ",\"last_failure_unix_ms\":" +
                (route.last_failure_unix_ms == 0U ? std::string("null") : std::to_string(route.last_failure_unix_ms)) +
                ",\"last_success_unix_ms\":" +
                (route.last_success_unix_ms == 0U ? std::string("null") : std::to_string(route.last_success_unix_ms)) +
                ",\"cooldown_until_unix_ms\":" +
                (route.cooldown_until_unix_ms == 0U ? std::string("null") : std::to_string(route.cooldown_until_unix_ms)) +
                ",\"cooldown_remaining_ms\":" + std::to_string(cooldown_remaining) + "}";
        }
        out += "],\"attempts_this_run\":" + std::to_string(run.attempts.load()) +
            ",\"acknowledged_this_run\":" +
            std::to_string(run.acknowledged.load()) +
            ",\"failures_this_run\":" + std::to_string(run.failures.load()) +
            ",\"rejected_this_run\":" + std::to_string(run.rejected.load()) +
            ",\"expired_this_run\":" + std::to_string(run.expired.load()) +
            ",\"configuration_drains\":" + std::to_string(run.configuration_drains.load()) +
            ",\"opened_configuration_event\":" + std::to_string(run.opened_configuration_event.load()) +
            ",\"delivery_selection\":{\"calls\":" + std::to_string(run.selection_calls.load()) +
            ",\"tree_nodes_visited\":" + std::to_string(run.selection_tree_nodes.load()) +
            ",\"key_buckets_checked\":" + std::to_string(run.selection_key_buckets.load()) +
            ",\"metadata_records_read\":" + std::to_string(run.selection_metadata_records.load()) +
            ",\"payload_records_copied\":" + std::to_string(run.selection_payload_records.load()) +
            ",\"payload_bytes_copied\":" + std::to_string(run.selection_payload_bytes.load()) +
            ",\"stale_selections\":" + std::to_string(run.selection_stale.load()) +
            ",\"maintenance_transitions\":" + std::to_string(run.selection_maintenance.load()) + "}" +
            ",\"session\":{\"protocol\":\"NOS1\"" +
            std::string(",\"state\":") +
            json_string(outbound_session_state_name(run.session_state.load())) +
            ",\"route_id\":" +
            (selected_route.empty() ? std::string("null") : json_string(selected_route)) +
            ",\"opened\":" + std::to_string(run.sessions_opened.load()) +
            ",\"reused\":" + std::to_string(run.sessions_reused.load()) +
            ",\"retired\":" + std::to_string(run.sessions_retired.load()) +
            ",\"failed\":" + std::to_string(run.sessions_failed.load()) +
            ",\"operations\":" +
            std::to_string(run.session_operations.load()) +
            ",\"current_operations\":" +
            std::to_string(run.current_session_operations.load()) +
            ",\"current_bytes\":" +
            std::to_string(run.current_session_bytes.load()) +
            ",\"maximum_operations\":" +
            std::to_string(config.sessions.maximum_operations) +
            ",\"maximum_bytes\":" +
            std::to_string(config.sessions.maximum_bytes) +
            ",\"maximum_lifetime_ms\":" +
            std::to_string(config.sessions.maximum_lifetime_ms) +
            ",\"idle_timeout_ms\":" +
            std::to_string(config.sessions.idle_timeout_ms) + "}" +
            ",\"generations\":[";
        bool first_generation = true;
        std::size_t generations_returned=0U, generations_total=0U;
        for (const auto& generation : config.peer_generations) {
            if (generation.node_id != peer.node_id) { continue; }
            ++generations_total;
            if(generations_returned==8U) continue;
            ++generations_returned;
            if (!first_generation) { out += ','; }
            first_generation = false;
            out += "{\"id\":" + json_string(generation.generation) +
                ",\"state\":" +
                json_string(key_generation_state_name(generation.state)) +
                ",\"spki_sha256\":" +
                json_string(spki_sha256_text(generation.spki_sha256)) + "}";
        }
        out += "],\"generations_total\":"+std::to_string(generations_total)+
            ",\"generations_returned\":"+std::to_string(generations_returned)+
            ",\"generations_truncated\":"+(generations_returned!=generations_total?"true":"false")+"}";
        if(out.size()-peer_rows_begin>12'288U){out.resize(row_begin);break;}
        ++peers_returned;
    }
    out += "],\"peers_total\":"+std::to_string(config.peers.size())+",\"peers_returned\":"+std::to_string(peers_returned)+
        ",\"peers_truncated\":"+(peers_returned!=config.peers.size()?"true":"false");
    out += ",\"peer_generations\":[";
    for (std::size_t index = 0U; index < std::min<std::size_t>(config.peer_generations.size(),8U); ++index) {
        if (index != 0U) { out += ','; }
        const auto& generation = config.peer_generations[index];
        out += "{\"node\":" + json_string(generation.node_id) +
            ",\"id\":" + json_string(generation.generation) +
            ",\"state\":" +
            json_string(key_generation_state_name(generation.state)) +
            ",\"spki_sha256\":" +
            json_string(spki_sha256_text(generation.spki_sha256)) + "}";
    }
    out += "],\"peer_generations_total\":"+std::to_string(config.peer_generations.size())+
        ",\"peer_generations_returned\":"+std::to_string(std::min<std::size_t>(config.peer_generations.size(),8U))+
        ",\"peer_generations_truncated\":"+(config.peer_generations.size()>8U?"true":"false");
    out += ",\"service\":{\"peer_accepted\":" +
        std::to_string(stats.peer_accepted.load()) +
        ",\"peer_completed\":" + std::to_string(stats.peer_completed.load()) +
        ",\"peer_busy\":" + std::to_string(stats.peer_busy.load()) +
        ",\"peer_authenticated\":" +
        std::to_string(stats.peer_authenticated.load()) +
        ",\"peer_committed\":" +
        std::to_string(stats.peer_committed.load()) +
        ",\"peer_duplicate\":" +
        std::to_string(stats.peer_duplicate.load()) +
        ",\"peer_rejected\":" +
        std::to_string(stats.peer_rejected.load()) +
        ",\"peer_transport_errors\":" +
        std::to_string(stats.peer_transport_errors.load()) +
        ",\"peer_authorization_denied\":" +
        std::to_string(stats.peer_authorization_denied.load()) +
        ",\"peer_actions_queued\":" +
        std::to_string(stats.peer_actions_queued.load()) +
        ",\"peer_session_connections\":" +
        std::to_string(stats.peer_session_connections.load()) +
        ",\"peer_legacy_connections\":" +
        std::to_string(stats.peer_legacy_connections.load()) +
        ",\"peer_session_operations\":" +
        std::to_string(stats.peer_session_operations.load()) +
        ",\"peer_session_clean_closes\":" +
        std::to_string(stats.peer_session_clean_closes.load()) +
        ",\"peer_session_retirements\":" +
        std::to_string(stats.peer_session_retirements.load()) +
        ",\"control_accepted\":" + std::to_string(stats.control_accepted.load()) +
        ",\"control_completed\":" + std::to_string(stats.control_completed.load()) +
        ",\"control_errors\":" + std::to_string(stats.control_errors.load()) +
        ",\"control_authorized\":" + std::to_string(stats.control_authorized.load()) +
        ",\"control_denied\":" + std::to_string(stats.control_denied.load()) +
        ",\"peer_active\":" + std::to_string(stats.peer_active.load()) + "}}";
    if (out.size() > 64'000U) {
        if(!counters_only) return compact_runtime_status_json(config,state,stats,peer_stats,
            action_stats,lifecycle,bound_listen_locator,stopping,logical_digest,true);
        app_fail("STATUS_RESPONSE_LIMIT", "counter metadata exceeds control response budget");
    }
    return out;
}

[[nodiscard]] std::string control_submit_json(
    const QueueResult& queued,
    const SubmissionObservation& current,
    const SubmissionWork& work,
    const bool expose_work) {
    if (queued.operation_id != current.operation_id || queued.record_digest != current.record_digest) {
        app_fail("SUBMISSION_OBSERVATION_CONFLICT", "reply must bind enqueue and observation to one record");
    }
    return std::string("{\"format\":\"NATRAV_OVERLAY_CONTROL_SUBMIT_V1\",\"ok\":true") +
        ",\"queue_disposition\":" + json_string(queue_disposition_name(queued.disposition)) +
        ",\"operation_id\":" + json_string(operation_id_text(current.operation_id)) +
        ",\"recipient\":" + json_string(current.recipient) +
        ",\"operation_class\":" + json_string(authorized_operation_class_name(current.operation_class)) +
        ",\"resource\":" + json_string(current.resource) +
        ",\"status\":" + json_string(current.status) +
        ",\"status_basis\":\"POST_ENQUEUE_OBSERVATION\"" +
        (expose_work ? ",\"work\":" + submission_work_json(work) : std::string()) + "}";
}

[[nodiscard]] StoredOutbound find_outbound(
    const StateSnapshot& snapshot,
    const datacube::Digest32& operation_id) {
    const auto key = operation_id_text(operation_id);
    const auto found = std::find_if(
        snapshot.outbound.begin(), snapshot.outbound.end(),
        [&](const StoredOutbound& entry) {
            return operation_id_text(entry.record.operation_id) == key;
        });
    if (found == snapshot.outbound.end()) {
        app_fail("OUTBOUND_NOT_FOUND", "operation is not present in the outbox");
    }
    return *found;
}

void record_lifecycle_transition(
    NodeState& state,
    const std::uint64_t configuration_event,
    LifecycleEvent event) {
    // V6 has no accepted configuration history and therefore cannot provide a
    // V6 and V7 have no explicit durable local-principal policy. Their
    // lifecycle remains process-local; V8 transitions are checkpointed.
    if (configuration_event == 0U) { return; }
    state.record_lifecycle_event(event);
}

[[nodiscard]] PeerRuntimeStats& peer_runtime_stats_for(
    const RuntimeConfig& config,
    const std::vector<std::unique_ptr<PeerRuntimeStats>>& peer_stats,
    const std::string_view node_id) {
    static_cast<void>(config);
    for (std::size_t index = 0U; index < peer_stats.size(); ++index) {
        if (peer_stats[index]->node_id == node_id) {
            return *peer_stats[index];
        }
    }
    app_fail("PEER_NOT_CONFIGURED", std::string(node_id));
}

[[nodiscard]] bool handle_control_connection(
    datacube::Fd& connection,
    NodeState& state,
    RuntimeConfiguration& runtime,
    CustodyOwnerDispatcher& custody_dispatcher,
    RuntimeStats& stats,
    PeerSchedulerRegistry& registry,
    ActionRuntimeStats& action_stats,
    SchedulerSignal& scheduler_signal,
    ServiceLifecycle& lifecycle,
    TransportStreamQueue& peer_queue,
    const TransportLocator& bound_listen_locator,
    const std::atomic<bool>& stopping,
    std::optional<TerminalHeadHandoff>& terminal_handoff) {
    const int fd = connection.get();
    const auto initial_config = runtime.snapshot();
    auto deadline = deadline_after(initial_config->io.timeout);
    IoCounters counters;
    bool stop_intent_committed = false;
    bool decision_recorded = false;
    std::optional<LocalPrincipal> principal;
    datacube::Digest32 request_id {};
    ControlMetadata metadata{
        .command = "MALFORMED",
        .command_class = LocalControlClass::inspect,
        .mutating = false,
    };
    std::uint64_t policy_configuration_event = 0U;
    ControlResponse response;
    std::shared_ptr<RuntimeConfiguration::Lease> query_lease;
    std::optional<std::uint32_t> query_response_limit;
    try {
        // Linux captures these credentials at Unix-domain connect time. Obtain
        // them before reading even the bounded control frame.
        principal = local_principal(fd);
        request_id = synthetic_control_request_id(
            *principal, unix_milliseconds(), "PRE_DECODE");
        policy_configuration_event = initial_config->format_version >= 8U ?
            configuration_event_for(state, *initial_config) : 0U;
        if (!local_policy_mentions_uid(
                initial_config->local_control, principal->uid)) {
            metadata.command = "CONNECTION";
            record_control_decision(
                state, stats, *principal, request_id, metadata,
                policy_configuration_event, LocalControlDecisionKind::denied,
                "LOCAL_CONTROL_UID_DENIED");
            decision_recorded = true;
            app_fail("LOCAL_CONTROL_UID_DENIED",
                "the connected UID is absent from the accepted local-control policy");
        }

        if (std::getenv("NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER")) {
            std::cerr << "CONTROL_READ_READY " << principal->uid << std::endl;
        }
        FramedReader reader(initial_config->io);
        const auto payload = reader.read_frame(fd, deadline, counters);
        request_id = control_request_id(payload);
        if (reader.queued_frames() != 0U) {
            app_fail("CONTROL_PROTOCOL_REJECTED", "one control request is allowed per connection");
        }
        const auto request = decode_control_request(payload);
        metadata = control_metadata(request);
        // All decoded controls use one current policy generation, not the
        // pre-read connection snapshot. Ordinary commands retain this lease
        // through authorization, audit and effect. Publication has an explicit
        // exclusive-gate handoff below instead of recursively acquiring gate_.
        query_lease = runtime.lease();
        const auto* authorization_config = query_lease->config.get();
        policy_configuration_event = authorization_config->format_version >= 8U ?
            configuration_event_for(state, *authorization_config) : 0U;
        if ((std::holds_alternative<SourceViewRequest>(request) ||
             std::holds_alternative<ImportAutoRequest>(request) ||
             std::holds_alternative<SourceViewInventory>(request) ||
             std::holds_alternative<ViewBindings>(request)) &&
            authorization_config->format_version < 17U) {
            app_fail("SOURCE_VIEW_POLICY_VERSION_REQUIRED", "import requires V17");
        }
        if ((std::holds_alternative<SourceSubscriptionRequest>(request) || std::holds_alternative<SubscriptionInventory>(request)) &&
            authorization_config->format_version < 15U) {
            app_fail("SOURCE_DISCLOSURE_POLICY_VERSION_REQUIRED", "source subscriptions require V15");
        }
        if (std::holds_alternative<ControlAuthor>(request) &&
            authorization_config->format_version < 14U) {
            app_fail("LOCAL_AUTHOR_POLICY_VERSION_REQUIRED", "local authorship requires V14");
        }
        if ((std::holds_alternative<ControlCustodyDispatch>(request) ||
             std::holds_alternative<ControlCustodyDispatchStatus>(request) ||
             std::holds_alternative<ControlCustodyDispatchInventory>(request)) &&
            authorization_config->format_version < 24U) {
            app_fail("CUSTODY_DISPATCH_POLICY_VERSION_REQUIRED",
                "ordinary-daemon owner dispatch and reconciliation require V24");
        }
        if (std::holds_alternative<ControlStateHead>(request)) {
            query_response_limit = kMaximumLiveStateHeadJsonBytes;
        }
        if (const auto* audit = std::get_if<ControlHistoryRequest>(&request)) {
            query_response_limit = audit->maximum_bytes;
        }
        if (const auto* history = std::get_if<ConfigurationHistoryRequest>(&request)) {
            query_response_limit = history->maximum_bytes;
        }
        if (const auto* inventory = std::get_if<RuntimeInventory>(&request)) {
            query_response_limit = inventory->maximum_bytes;
        }
        if (std::holds_alternative<ControlCustodyDispatchStatus>(request)) {
            query_response_limit = kMaximumCustodyDispatchStatusJsonBytes;
        }
        if (const auto* inventory =
                std::get_if<ControlCustodyDispatchInventory>(&request)) {
            query_response_limit = inventory->maximum_bytes;
        }
        if (const auto* bindings = std::get_if<ViewBindings>(&request)) {
            query_response_limit = bindings->maximum_bytes;
        }
        if (const auto* inventory = std::get_if<SourceViewInventory>(&request)) {
            query_response_limit = inventory->maximum_bytes;
        }
        if (const auto* inventory = std::get_if<SubscriptionInventory>(&request)) {
            query_response_limit = inventory->maximum_bytes;
        }
        if (const auto* inventory = std::get_if<PublicationInventory>(&request)) {
            query_response_limit = inventory->maximum_bytes;
        }
        if (const auto* inventory = std::get_if<ConsumerInventory>(&request)) {
            query_response_limit = inventory->maximum_bytes;
        }
        if (const auto* history = std::get_if<ResultReviewHistory>(&request)) {
            query_response_limit = history->maximum_bytes;
        }
        if (const auto* query = std::get_if<ActionResultDiscovery>(&request)) {
            query_response_limit = query->maximum_response_bytes;
        }
        if (const auto* query = std::get_if<ActionResultQuery>(&request)) {
            query_response_limit = query->maximum_response_bytes;
        }
        if (const auto* query = std::get_if<ActionQuery>(&request)) {
            query_response_limit = query->maximum_response_bytes;
        }
        if (const auto* query = std::get_if<OutboxQuery>(&request)) {
            query_response_limit = query->maximum_response_bytes;
        }
        if (const auto* query = std::get_if<EvidenceQuery>(&request)) {
            query_response_limit = query->maximum_response_bytes;
        }
        if (const auto* feed = std::get_if<EvidenceFeed>(&request)) {
            query_response_limit = feed->maximum_response_bytes;
        }
        if ((std::holds_alternative<ConsumerRequest>(request) || std::holds_alternative<ConsumerInventory>(request)) &&
            authorization_config->format_version < 11U) {
            app_fail("CONSUMER_POLICY_VERSION_REQUIRED", "durable consumers require explicit V11 grants");
        }
        if ((std::holds_alternative<PublicationChannelRequest>(request) || std::holds_alternative<PublicationInventory>(request)) &&
            authorization_config->format_version < 12U) {
            app_fail("PUBLICATION_CHANNEL_POLICY_VERSION_REQUIRED",
                "publication channels require explicit V12 grants");
        }
        // Read authority belongs to read/projection operations, not to the
        // implementation detail of whether the handler owns a generation lease.
        const auto* consumer_read = std::get_if<ConsumerRequest>(&request);
        const auto* channel_read = std::get_if<PublicationChannelRequest>(&request);
        const bool requires_result_payload = std::holds_alternative<ActionResultQuery>(request) ||
            std::holds_alternative<ActionResultDiscovery>(request) ||
            std::holds_alternative<ResultReviewStatus>(request) ||
            std::holds_alternative<ResultReviewRequest>(request) || std::holds_alternative<ResultReviewHistory>(request);
        const bool requires_evidence_read = requires_result_payload || std::holds_alternative<PublicationInventory>(request) || std::holds_alternative<ConsumerInventory>(request) ||
            std::holds_alternative<EvidenceQuery>(request) ||
            std::holds_alternative<EvidenceFeed>(request) ||
            (consumer_read && !schedule_command(consumer_read->command) &&
                !retirement_command(consumer_read->command)) ||
            (channel_read && channel_read->command != PublicationChannelCommand::retire &&
                channel_read->command != PublicationChannelCommand::automatic_pause &&
                channel_read->command != PublicationChannelCommand::automatic_status);
        if (!local_control_allows(
                authorization_config->local_control,
                principal->uid,
                metadata.command_class) ||
            (requests_terminal_head(request) &&
                !terminal_head_inspection_allowed(*authorization_config, principal->uid)) ||
            (requires_result_payload &&
                !local_control_allows(authorization_config->local_control,
                    principal->uid, LocalControlClass::evidence_payload)) ||
            (requires_evidence_read &&
                !local_control_allows(authorization_config->local_control,
                    principal->uid, LocalControlClass::evidence_read))) {
            record_control_decision(
                state, stats, *principal, request_id, metadata,
                policy_configuration_event, LocalControlDecisionKind::denied,
                "LOCAL_CONTROL_CLASS_DENIED");
            decision_recorded = true;
            app_fail("LOCAL_CONTROL_CLASS_DENIED",
                "the connected UID is not authorized for this command class");
        }

        // Disabled normally; coordinate owned regression clients after the
        // actual accepted-policy check, without releasing the generation lease.
        if (const char* command = std::getenv("NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_COMMAND");
            command && metadata.command == command) {
            if (const char* delay = std::getenv("NATRAV_OVERLAY_TEST_CONTROL_AUTHORIZED_PAUSE_MS")) {
                const auto ms = parse_u64(delay, "control authorization test pause", 0U, 1500U);
                std::cerr << "CONTROL_AUTHORIZED " << metadata.command << ' ' << principal->uid << std::endl;
                std::this_thread::sleep_for(std::chrono::milliseconds(
                    static_cast<std::chrono::milliseconds::rep>(ms)));
            }
        }
        const auto service_mode = lifecycle.mode();
        const bool status_request =
            (std::holds_alternative<ImportAutoRequest>(request) && import_observational(std::get<ImportAutoRequest>(request).command)) ||
            (std::holds_alternative<SourceSubscriptionRequest>(request) &&
                (std::get<SourceSubscriptionRequest>(request).command == SourceSubscriptionCommand::status ||
                 std::get<SourceSubscriptionRequest>(request).command == SourceSubscriptionCommand::automatic_status)) ||
            std::holds_alternative<ControlSnapshot>(request) ||
            std::holds_alternative<ControlStateHead>(request) ||
            std::holds_alternative<ControlCustodyDispatchStatus>(request) ||
            std::holds_alternative<ControlCustodyDispatchInventory>(request) ||
            std::holds_alternative<ConfigurationHistoryRequest>(request) ||
            std::holds_alternative<ControlHistoryRequest>(request) ||
            std::holds_alternative<RuntimeInventory>(request) ||
            std::holds_alternative<EvidenceQuery>(request) ||
            std::holds_alternative<OutboxQuery>(request) ||
            std::holds_alternative<ActionQuery>(request) ||
            std::holds_alternative<ActionResultQuery>(request) ||
            std::holds_alternative<ActionResultDiscovery>(request) ||
            std::holds_alternative<ResultReviewStatus>(request) ||
            std::holds_alternative<ResultReviewHistory>(request) ||
            std::holds_alternative<ViewBindings>(request) ||
            std::holds_alternative<SourceViewInventory>(request) ||
            std::holds_alternative<SubscriptionInventory>(request) ||
            std::holds_alternative<PublicationInventory>(request) ||
            std::holds_alternative<ConsumerInventory>(request) ||
            std::holds_alternative<EvidenceFeed>(request) ||
            (std::holds_alternative<ConsumerRequest>(request) &&
                consumer_status(std::get<ConsumerRequest>(request).command)) ||
            (std::holds_alternative<PublicationChannelRequest>(request) &&
                (std::get<PublicationChannelRequest>(request).command ==
                     PublicationChannelCommand::status ||
                 std::get<PublicationChannelRequest>(request).command ==
                     PublicationChannelCommand::automatic_status));
        const bool immediate_shutdown =
            std::holds_alternative<ControlShutdown>(request);
        if (service_mode == RuntimeServiceMode::draining &&
            !status_request && !immediate_shutdown) {
            record_control_decision(
                state, stats, *principal, request_id, metadata,
                policy_configuration_event, LocalControlDecisionKind::denied,
                "SERVICE_DRAINING");
            decision_recorded = true;
            app_fail("SERVICE_DRAINING",
                "the node is draining and accepts only status or immediate shutdown");
        }
        const bool quiesced_lifecycle_command =
            std::holds_alternative<ControlQuiesce>(request) ||
            std::holds_alternative<ControlResume>(request) ||
            std::holds_alternative<ControlDrainShutdown>(request) ||
            immediate_shutdown;
        if (service_mode == RuntimeServiceMode::quiesced &&
            metadata.mutating && !quiesced_lifecycle_command) {
            record_control_decision(
                state, stats, *principal, request_id, metadata,
                policy_configuration_event, LocalControlDecisionKind::denied,
                "SERVICE_QUIESCED");
            decision_recorded = true;
            app_fail("SERVICE_QUIESCED",
                "the node is quiesced and accepts only inspection or lifecycle commands");
        }

        const bool configuration_request = std::holds_alternative<ControlConfiguration>(request);
        if (configuration_request) {
            // Accepted audit is deferred until exclusive publication admission.
        } else if (metadata.mutating && !std::holds_alternative<OutboxAdminRequest>(request) && !std::holds_alternative<ActionAdminRequest>(request) && !std::holds_alternative<ResultReviewRequest>(request) && !std::holds_alternative<ConsumerRequest>(request) &&
            !std::holds_alternative<SourceViewRequest>(request) && !std::holds_alternative<ImportAutoRequest>(request) && !std::holds_alternative<ControlAuthor>(request) && !std::holds_alternative<SourceSubscriptionRequest>(request)) {
            record_control_decision(
                state, stats, *principal, request_id, metadata,
                policy_configuration_event, LocalControlDecisionKind::authorized);
        } else {
            ++stats.control_authorized;
        }
        // Source acceptance is recorded atomically with the record itself. Failed
        // source commands remain eligible for the ordinary bounded denial audit.
        decision_recorded = !configuration_request && !std::holds_alternative<OutboxAdminRequest>(request) && !std::holds_alternative<ActionAdminRequest>(request) && !std::holds_alternative<ResultReviewRequest>(request) && !std::holds_alternative<SourceViewRequest>(request) && !std::holds_alternative<ImportAutoRequest>(request) && !std::holds_alternative<ControlAuthor>(request) && !std::holds_alternative<SourceSubscriptionRequest>(request);
        if (const auto* change = std::get_if<ControlConfiguration>(&request)) {
            deadline = deadline_after(std::chrono::milliseconds(10000));
            // No shared generation lease may survive into activate(), which
            // serializes candidates and requires exclusive publication access.
            query_lease.reset();
            if (std::getenv("NATRAV_OVERLAY_TEST_CONTROL_READ_MARKER")) {
                std::cerr << "CONTROL_CONFIGURATION_HANDOFF " << principal->uid << std::endl;
            }
            response = ControlResponse{.ok = true, .json = runtime.activate(
                state, change->candidate_path, change->rollback_generation, change->reason,
                [&](const std::vector<std::string>& nodes) { return registry.prepare(nodes); },
                [&](const RuntimeConfig& current, const ConfigurationAdmissionPhase phase,
                    const std::string_view failure) {
                    policy_configuration_event = current.format_version >= 8U ?
                        configuration_event_for(state, current) : 0U;
                    if (phase == ConfigurationAdmissionPhase::failure) {
                        if (!decision_recorded) {
                            record_control_decision(state, stats, *principal, request_id, metadata,
                                policy_configuration_event, LocalControlDecisionKind::denied,
                                valid_error_code(failure) ? failure : std::string_view("CONTROL_REJECTED"));
                            decision_recorded = true;
                        }
                        return;
                    }
                    const std::string_view denied =
                        !local_control_allows(current.local_control, principal->uid,
                            LocalControlClass::configuration) ? "LOCAL_CONTROL_CLASS_DENIED" :
                        lifecycle.mode() == RuntimeServiceMode::draining ? "SERVICE_DRAINING" :
                        lifecycle.mode() == RuntimeServiceMode::quiesced ? "SERVICE_QUIESCED" : "";
                    if (!denied.empty()) {
                        record_control_decision(state, stats, *principal, request_id, metadata,
                            policy_configuration_event, LocalControlDecisionKind::denied, denied);
                        decision_recorded = true;
                        app_fail(std::string(denied), "configuration admission is not permitted by current policy/service state");
                    }
                    if (phase == ConfigurationAdmissionPhase::commit) {
                        record_control_decision(state, stats, *principal, request_id, metadata,
                            policy_configuration_event, LocalControlDecisionKind::authorized);
                        decision_recorded = true;
                    }
                })};
            scheduler_signal.notify();
        } else {
        // Status is observational. Snapshot the immutable configuration and
        // release the publication gate before reconstructing journal state.
        // Mutating commands retain a generation lease across their bounded
        // decision/commit boundary so they cannot straddle activation.
        std::vector<PeerRuntimeStats*> status_peers;
        std::shared_ptr<const RuntimeConfig> status_config;
        std::shared_ptr<RuntimeConfiguration::Lease> config_lease;
        if (std::holds_alternative<ControlSnapshot>(request)) {
            status_config = query_lease->config;
            status_peers.reserve(registry.stats().size());
            for (const auto& peer : registry.stats()) status_peers.push_back(peer.get());
            query_lease.reset();
            // Controlled race fixture; disabled in ordinary operation. Pointees
            // remain alive until every control worker has been joined.
            if (const char* pause = std::getenv("NATRAV_OVERLAY_TEST_STATUS_CAPTURE_PAUSE_MS")) {
                const auto ms = std::min(std::strtoull(pause, nullptr, 10), 1'000ULL);
                std::cerr << "STATUS_REGISTRY_CAPTURED " << principal->uid << std::endl;
                std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<std::int64_t>(ms)));
            }
        } else {
            config_lease = query_lease;
        }
        const auto& config = status_config ? *status_config : *config_lease->config;
        const auto& peer_stats = registry.stats();
        if (const auto* audit = std::get_if<ControlHistoryRequest>(&request)) {
            response=ControlResponse{.ok=true,.json=state.control_history_page(*audit,
                runtime_configuration_digest(canonical_runtime_config(config)),
                deadline-std::min(config.io.timeout/4,std::chrono::milliseconds(50)))};
        } else if (const auto* history = std::get_if<ConfigurationHistoryRequest>(&request)) {
            response=ControlResponse{.ok=true,.json=state.configuration_history_page(*history,
                runtime_configuration_digest(canonical_runtime_config(config)),
                deadline-std::min(config.io.timeout/4,std::chrono::milliseconds(50)))};
        } else if (const auto* inventory = std::get_if<RuntimeInventory>(&request)) {
            std::vector<std::string> nodes; nodes.reserve(peer_stats.size());
            for(const auto& peer:peer_stats) nodes.push_back(peer->node_id);
            static const std::string instance = std::to_string(::getpid())+"-"+std::to_string(
                std::chrono::steady_clock::now().time_since_epoch().count());
            response=ControlResponse{.ok=true,.json=runtime_inventory_json(config,nodes,*inventory,principal->uid,instance,
                [&](std::string_view node,std::string_view route){return inventory_telemetry(config,peer_stats,node,route);},
                deadline-std::min(config.io.timeout/4,std::chrono::milliseconds(50)))};
        } else if (const auto* channel = std::get_if<PublicationChannelRequest>(&request)) {
            const EvidenceQueryContext channel_context{
                .uid = principal->uid,
                .configuration_generation = config.runtime_generation,
                .configuration_digest = runtime_configuration_digest(
                    canonical_runtime_config(config)),
                .read_access = evidence_read_access(config.evidence_read,
                    config.local_control, principal->uid),
                .deadline = deadline - std::min(config.io.timeout / 4,
                    std::chrono::milliseconds(50))};
            std::optional<OutboundPolicy> publication_policy;
            const bool route_required =
                channel->command == PublicationChannelCommand::create ||
                channel->command == PublicationChannelCommand::publish ||
                channel->command == PublicationChannelCommand::automatic_enable;
            const bool route_observed = route_required ||
                channel->command == PublicationChannelCommand::status ||
                channel->command == PublicationChannelCommand::automatic_status ||
                channel->command == PublicationChannelCommand::new_epoch;
            if (route_observed) {
                const auto recipient = channel->command == PublicationChannelCommand::create ?
                    channel->recipient :
                    state.publication_channel_recipient(principal->uid, channel->name);
                const auto* peer = find_peer(config, recipient);
                if (peer == nullptr) {
                    if (route_required) { app_fail("PEER_NOT_CONFIGURED", recipient); }
                } else {
                    publication_policy = policy_for(*peer, unix_milliseconds());
                }
            }
            response = ControlResponse{.ok = true, .json =
                state.publication_channel_command(*channel, channel_context,
                    principal->pid, policy_configuration_event,
                    publication_policy)};
            if (channel->command != PublicationChannelCommand::status &&
                channel->command != PublicationChannelCommand::automatic_status) {
                scheduler_signal.notify();
            }
        } else if (const auto* consumer = std::get_if<ConsumerRequest>(&request)) {
            const EvidenceQueryContext consumer_context{
                .uid = principal->uid,
                .configuration_generation = config.runtime_generation,
                .configuration_digest = runtime_configuration_digest(canonical_runtime_config(config)),
                .read_access = evidence_read_access(config.evidence_read, config.local_control, principal->uid),
                .deadline = deadline - std::min(config.io.timeout / 4, std::chrono::milliseconds(50))};
            if (publication_command(consumer->command)) {
                const auto* peer = find_peer(config, consumer->publication_recipient);
                if (peer == nullptr) {
                    app_fail("PEER_NOT_CONFIGURED", consumer->publication_recipient);
                }
                if (!local_control_allows(config.local_control, principal->uid,
                        LocalControlClass::submit)) {
                    app_fail("LOCAL_CONTROL_CLASS_DENIED",
                        "projection publication also requires explicit SUBMIT authority");
                }
                response = ControlResponse{.ok = true, .json =
                    state.publish_projection_result(*consumer, consumer_context,
                        principal->pid, policy_configuration_event,
                        policy_for(*peer, unix_milliseconds()))};
            } else {
                response = ControlResponse{.ok = true, .json = state.consumer_command(*consumer,
                    consumer_context, principal->pid, policy_configuration_event)};
            }
            if(!consumer_status(consumer->command)){scheduler_signal.notify();}
        } else if (const auto* review = std::get_if<ResultReviewRequest>(&request)) {
            response=ControlResponse{.ok=true,.json=state.commit_result_review(*review,
                config,principal->uid,principal->gid,principal->pid,
                deadline-std::min(config.io.timeout/4,std::chrono::milliseconds(50)))};
        } else if (const auto* review_status = std::get_if<ResultReviewStatus>(&request)) {
            response=ControlResponse{.ok=true,.json=state.result_review_status(*review_status, config, principal->uid)};
        } else if (const auto* bindings = std::get_if<ViewBindings>(&request)) {
            response=ControlResponse{.ok=true,.json=state.view_bindings(*bindings, config, principal->uid,
                deadline-std::min(config.io.timeout/4,std::chrono::milliseconds(50)))};
        } else if (const auto* view_inventory = std::get_if<SourceViewInventory>(&request)) {
            response=ControlResponse{.ok=true,.json=state.source_view_inventory(*view_inventory, config, principal->uid,
                deadline-std::min(config.io.timeout/4,std::chrono::milliseconds(50)))};
        } else if (const auto* source_inventory = std::get_if<SubscriptionInventory>(&request)) {
            response=ControlResponse{.ok=true,.json=state.subscription_inventory(*source_inventory, config, principal->uid,
                deadline-std::min(config.io.timeout/4,std::chrono::milliseconds(50)))};
        } else if (const auto* channel_inventory = std::get_if<PublicationInventory>(&request)) {
            response=ControlResponse{.ok=true,.json=state.publication_inventory(*channel_inventory, config, principal->uid,
                deadline-std::min(config.io.timeout/4,std::chrono::milliseconds(50)))};
        } else if (const auto* owned_inventory = std::get_if<ConsumerInventory>(&request)) {
            response=ControlResponse{.ok=true,.json=state.consumer_inventory(*owned_inventory, config, principal->uid,
                deadline-std::min(config.io.timeout/4,std::chrono::milliseconds(50)))};
        } else if (const auto* review_history = std::get_if<ResultReviewHistory>(&request)) {
            response=ControlResponse{.ok=true,.json=state.result_review_history(*review_history,
                config, principal->uid,
                deadline-std::min(config.io.timeout/4,std::chrono::milliseconds(50)))};
        } else if (const auto* discovery = std::get_if<ActionResultDiscovery>(&request)) {
            response=ControlResponse{.ok=true,.json=state.discover_action_results(*discovery,
                config, principal->uid,
                deadline-std::min(config.io.timeout/4,std::chrono::milliseconds(50)))};
        } else if (const auto* result_query = std::get_if<ActionResultQuery>(&request)) {
            response=ControlResponse{.ok=true,.json=state.correlate_action_result(*result_query,
                config, principal->uid,
                deadline-std::min(config.io.timeout/4,std::chrono::milliseconds(50)))};
        } else if (const auto* action_query = std::get_if<ActionQuery>(&request)) {
            response=ControlResponse{.ok=true,.json=state.query_actions(*action_query,
                ActionQueryContext{.uid=principal->uid,
                    .configuration_digest=runtime_configuration_digest(canonical_runtime_config(config)),
                    .deadline=deadline-std::min(config.io.timeout/4,std::chrono::milliseconds(50))})};
        } else if (const auto* outbox_query = std::get_if<OutboxQuery>(&request)) {
            response = ControlResponse{.ok = true, .json = state.query_outbox(*outbox_query,
                OutboxQueryContext{.uid = principal->uid,
                    .configuration_digest = runtime_configuration_digest(canonical_runtime_config(config)),
                    .deadline = deadline - std::min(config.io.timeout / 4, std::chrono::milliseconds(50))})};
        } else if (const auto* query = std::get_if<EvidenceQuery>(&request)) {
            response = ControlResponse{.ok = true, .json = state.query_evidence(*query,
                EvidenceQueryContext{.uid = principal->uid,
                    .configuration_generation = config.runtime_generation,
                    .configuration_digest = runtime_configuration_digest(canonical_runtime_config(config)),
                    .read_access = evidence_read_access(config.evidence_read, config.local_control, principal->uid),
                    .deadline = deadline - std::min(config.io.timeout / 4, std::chrono::milliseconds(50))})};
        } else if (const auto* feed = std::get_if<EvidenceFeed>(&request)) {
            response = ControlResponse{.ok = true, .json = state.poll_evidence(*feed,
                EvidenceQueryContext{.uid = principal->uid,
                    .configuration_generation = config.runtime_generation,
                    .configuration_digest = runtime_configuration_digest(canonical_runtime_config(config)),
                    .read_access = evidence_read_access(config.evidence_read, config.local_control, principal->uid),
                    .deadline = deadline - std::min(config.io.timeout / 4, std::chrono::milliseconds(50))})};
        } else if (const auto* subscription = std::get_if<SourceSubscriptionRequest>(&request)) {
            response = ControlResponse{.ok = true, .json = state.source_subscription_command(*subscription,
                config, principal->uid, principal->pid, policy_configuration_event, unix_milliseconds())};
            if (subscription->command != SourceSubscriptionCommand::status &&
                subscription->command != SourceSubscriptionCommand::automatic_status) {
                scheduler_signal.notify();
            }
        } else if(const auto* automatic=std::get_if<ImportAutoRequest>(&request)) {
            if(automatic->command==ImportAutoCommand::review)query_response_limit=automatic->maximum_bytes;
            response=ControlResponse{.ok=true,.json=state.import_auto_command(*automatic,config,principal->uid,principal->gid,principal->pid,policy_configuration_event,unix_milliseconds())};
            if(!import_observational(automatic->command))scheduler_signal.notify();
        } else if (const auto* view = std::get_if<SourceViewRequest>(&request)) {
            response=ControlResponse{.ok=true,.json=state.import_subscribed_source(*view,config,
                principal->uid,principal->gid,principal->pid,policy_configuration_event,unix_milliseconds())};
            scheduler_signal.notify();
        } else if (const auto* author = std::get_if<ControlAuthor>(&request)) {
            response = ControlResponse{.ok = true, .json = state.author_evidence(author->record,
                config, principal->uid, principal->gid, principal->pid,
                policy_configuration_event, unix_milliseconds())};
            scheduler_signal.notify();
        } else if (const auto* submit = std::get_if<ControlSubmit>(&request)) {
            if (submit->record.issuer != config.local_node) {
                app_fail("OUTBOUND_ISSUER_MISMATCH",
                    "control submission issuer must match the configured node");
            }
            const auto* peer = find_peer(config, submit->record.recipient);
            if (peer == nullptr) {
                app_fail("PEER_NOT_CONFIGURED", submit->record.recipient);
            }
            SubmissionWork work;
            const SubmissionWorkScope work_scope(work);
            const auto queued = state.queue_outbound(
                submit->record, policy_for(*peer, unix_milliseconds()));
            scheduler_signal.notify();
            // An owned-test interleaving, disabled normally. No state mutex is
            // retained; real delivery/administration may finish before lookup.
            if (const char* pause = std::getenv("NATRAV_OVERLAY_TEST_SUBMIT_AFTER_QUEUE_PAUSE_MS")) {
                const auto ms = parse_u64(pause, "submission test pause", 0U, 1500U);
                if (ms != 0U) {
                    std::cerr << "SUBMISSION_QUEUED " << operation_id_text(queued.operation_id) << std::endl;
                    std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<std::chrono::milliseconds::rep>(ms)));
                }
            }
            const auto current = state.observe_submission(queued.operation_id, queued.record_digest);
            response = ControlResponse{
                .ok = true,
                .json = control_submit_json(queued, current, work,
                    local_control_allows(config.local_control, principal->uid, LocalControlClass::inspect)),
            };
        } else if (std::holds_alternative<ControlStateHead>(request)) {
            // Unlike aggregate status, retain the current configuration lease
            // through the locked head sample. No audit append for success.
            response = ControlResponse{.ok = true, .json = state.live_state_head_json()};
        } else if (std::holds_alternative<ControlSnapshot>(request)) {
            response = ControlResponse{
                .ok = true,
                .json = compact_runtime_status_json(
                    config, state, stats, status_peers, action_stats, lifecycle,
                    bound_listen_locator, stopping.load(), std::get<ControlSnapshot>(request).logical_digest),
            };
        } else if (const auto* wake = std::get_if<ControlWake>(&request)) {
            if (find_peer(config, wake->peer) == nullptr) {
                app_fail("PEER_NOT_CONFIGURED", wake->peer);
            }
            scheduler_signal.notify();
            response = ControlResponse{
                .ok = true,
                .json = std::string("{\"format\":\"NATRAV_OVERLAY_CONTROL_WAKE_V1\",\"ok\":true") +
                    ",\"peer\":" + json_string(wake->peer) + "}",
            };
        } else if (const auto* conditional = std::get_if<OutboxAdminRequest>(&request)) {
            auto& peer_run=peer_runtime_stats_for(config,peer_stats,state.outbound_recipient(conditional->operation));
            std::lock_guard<std::mutex> transition_lock(peer_run.transition_mutex);
            response=ControlResponse{.ok=true,.json=state.conditional_outbox_command(*conditional,config,
                principal->uid,principal->gid,principal->pid,policy_configuration_event)};
            decision_recorded=true;scheduler_signal.notify();
        } else if (const auto* rebind = std::get_if<ControlRebind>(&request)) {
            const auto initial = find_outbound(state.snapshot(), rebind->operation_id);
            auto& peer_run = peer_runtime_stats_for(
                config, peer_stats, initial.record.recipient);
            std::lock_guard<std::mutex> transition_lock(peer_run.transition_mutex);
            const auto before = find_outbound(state.snapshot(), rebind->operation_id);
            const auto* generation = find_peer_generation(
                config, before.record.recipient, rebind->generation);
            if (generation == nullptr) {
                app_fail("OUTBOUND_GENERATION_NOT_CONFIGURED",
                    "target generation is not configured for operation recipient");
            }
            if (generation->state != KeyGenerationState::active) {
                app_fail("OUTBOUND_REBIND_TARGET_NOT_ACTIVE",
                    "rebind target generation must be ACTIVE");
            }
            state.rebind_outbound(
                rebind->operation_id,
                generation->generation,
                generation->spki_sha256,
                unix_milliseconds(),
                "LOCAL_CONTROL",
                rebind->reason);
            const auto current = find_outbound(state.snapshot(), rebind->operation_id);
            scheduler_signal.notify();
            response = ControlResponse{
                .ok = true,
                .json = std::string(
                    "{\"format\":\"NATRAV_OVERLAY_CONTROL_REBIND_V1\",\"ok\":true") +
                    ",\"operation_id\":" +
                    json_string(operation_id_text(current.record.operation_id)) +
                    ",\"recipient\":" + json_string(current.record.recipient) +
                    ",\"generation\":" + json_string(generation->generation) +
                    ",\"spki_sha256\":" +
                    json_string(spki_sha256_text(generation->spki_sha256)) +
                    ",\"status\":" + json_string(outbound_status_name(current)) + "}",
            };
        } else if (const auto* retry = std::get_if<ControlRetry>(&request)) {
            const auto initial = find_outbound(state.snapshot(), retry->operation_id);
            auto& peer_run = peer_runtime_stats_for(
                config, peer_stats, initial.record.recipient);
            std::lock_guard<std::mutex> transition_lock(peer_run.transition_mutex);
            state.retry_outbound(
                retry->operation_id,
                unix_milliseconds(),
                "LOCAL_CONTROL",
                retry->reason);
            const auto current = find_outbound(
                state.snapshot(), retry->operation_id);
            scheduler_signal.notify();
            response = ControlResponse{
                .ok = true,
                .json = std::string(
                    "{\"format\":\"NATRAV_OVERLAY_CONTROL_RETRY_V1\",\"ok\":true") +
                    ",\"operation_id\":" +
                    json_string(operation_id_text(current.record.operation_id)) +
                    ",\"recipient\":" + json_string(current.record.recipient) +
                    ",\"status\":" + json_string(outbound_status_name(current)) +
                    ",\"reason\":" + json_string(retry->reason) + "}",
            };
        } else if (const auto* status =
                       std::get_if<ControlCustodyDispatchStatus>(&request)) {
            const auto result = custody_dispatcher.reconcile_status(
                config,
                CustodyOwnerDispatchStatusRequest{
                    .activation_id = status->activation_id,
                    .activation_generation = status->activation_generation,
                    .dispatch_request_id = status->dispatch_request_digest,
                });
            response = ControlResponse{.ok = true, .json = result};
        } else if (const auto* dispatch_inventory =
                       std::get_if<ControlCustodyDispatchInventory>(&request)) {
            const auto result = custody_dispatcher.reconcile_inventory(
                config,
                CustodyOwnerDispatchInventoryRequest{
                    .activation_id = dispatch_inventory->activation_id,
                    .activation_generation = dispatch_inventory->activation_generation,
                    .cursor = dispatch_inventory->cursor,
                    .limit = dispatch_inventory->limit,
                    .maximum_bytes = dispatch_inventory->maximum_bytes,
                });
            response = ControlResponse{.ok = true, .json = result};
        } else if (const auto* dispatch =
                       std::get_if<ControlCustodyDispatch>(&request)) {
            const auto result = custody_dispatcher.dispatch_once(
                config, CustodyOwnerDispatchRequest{
                    .activation_id = dispatch->activation_id,
                    .activation_generation = dispatch->activation_generation,
                    .receiver_request_id = dispatch->receiver_request_digest,
                    .dispatch_request_id = dispatch->dispatch_request_digest,
                    .reason = dispatch->reason,
                });
            response = ControlResponse{.ok = true, .json = result.json};
        } else if (const auto* cancel = std::get_if<ControlCancel>(&request)) {
            const auto initial = find_outbound(state.snapshot(), cancel->operation_id);
            auto& peer_run = peer_runtime_stats_for(
                config, peer_stats, initial.record.recipient);
            std::lock_guard<std::mutex> transition_lock(peer_run.transition_mutex);
            state.cancel_outbound(
                cancel->operation_id,
                unix_milliseconds(),
                "LOCAL_CONTROL",
                cancel->reason);
            const auto current = find_outbound(state.snapshot(), cancel->operation_id);
            scheduler_signal.notify();
            response = ControlResponse{
                .ok = true,
                .json = std::string(
                    "{\"format\":\"NATRAV_OVERLAY_CONTROL_CANCEL_V1\",\"ok\":true") +
                    ",\"operation_id\":" +
                    json_string(operation_id_text(current.record.operation_id)) +
                    ",\"recipient\":" + json_string(current.record.recipient) +
                    ",\"status\":" + json_string(outbound_status_name(current)) +
                    ",\"reason\":" + json_string(cancel->reason) + "}",
            };
        } else if (const auto* conditional_action =
                       std::get_if<ActionAdminRequest>(&request)) {
            std::lock_guard<std::mutex> transition_lock(
                action_stats.transition_mutex);
            bool applied = false;
            response = ControlResponse{
                .ok = true,
                .json = state.conditional_action_cancel(
                    *conditional_action, config, principal->uid,
                    principal->gid, principal->pid,
                    policy_configuration_event, &applied),
            };
            if (applied) { ++action_stats.cancelled; }
            decision_recorded = true;
            scheduler_signal.notify();
        } else if (const auto* action_cancel =
                       std::get_if<ControlActionCancel>(&request)) {
            std::lock_guard<std::mutex> transition_lock(
                action_stats.transition_mutex);
            state.cancel_action(
                action_cancel->action_id,
                unix_milliseconds(),
                action_cancel->reason);
            const auto observation = state.action_cancel_observation_json(
                action_cancel->action_id);
            ++action_stats.cancelled;
            scheduler_signal.notify();
            // A successful legacy cancellation has one exact terminal outcome.
            // Keep its historical top-level fields while adding the bounded
            // exact observation used by newer clients.
            response = ControlResponse{
                .ok = true,
                .json = std::string(
                    "{\"format\":\"NATRAV_OVERLAY_CONTROL_ACTION_CANCEL_V2\",\"ok\":true") +
                    ",\"action_id\":" +
                    json_string(operation_id_text(action_cancel->action_id)) +
                    ",\"status\":\"CANCELLED\"" +
                    ",\"observation\":" + observation +
                    ",\"reason\":" +
                    json_string(action_cancel->reason) + "}",
            };
        } else if (std::holds_alternative<ControlCompact>(request)) {
            const auto compacted = state.compact();
            const auto reclaimed = compacted.before_bytes > compacted.after_bytes ?
                compacted.before_bytes - compacted.after_bytes : 0U;
            response = ControlResponse{
                .ok = true,
                .json = std::string(
                    "{\"format\":\"NATRAV_OVERLAY_CONTROL_COMPACT_V1\",\"ok\":true") +
                    ",\"generation\":" +
                    std::to_string(compacted.generation) +
                    ",\"compacted_unix_ms\":" +
                    std::to_string(compacted.compacted_unix_ms) +
                    ",\"before_bytes\":" +
                    std::to_string(compacted.before_bytes) +
                    ",\"after_bytes\":" +
                    std::to_string(compacted.after_bytes) +
                    ",\"reclaimed_bytes\":" +
                    std::to_string(reclaimed) +
                    ",\"grew\":" +
                    std::string(compacted.after_bytes > compacted.before_bytes ?
                        "true" : "false") +
                    ",\"retained_records\":" +
                    std::to_string(compacted.retained_records) +
                    ",\"logical_state_digest\":" +
                    json_string(datacube::hex_lower(
                        compacted.logical_state_digest)) + "}",
            };
        } else if (const auto* quiesce = std::get_if<ControlQuiesce>(&request)) {
            std::lock_guard<std::mutex> transition_lock(
                lifecycle.transition_mutex());
            if (lifecycle.mode() != RuntimeServiceMode::running) {
                app_fail("SERVICE_ALREADY_QUIESCED",
                    "quiesce requires the RUNNING service state");
            }
            const auto counts = state.pending_work_counts();
            record_lifecycle_transition(state, policy_configuration_event, LifecycleEvent{
                .kind = LifecycleTransitionKind::quiesced,
                .request_id = request_id,
                .uid = principal->uid,
                .pid = principal->pid,
                .configuration_event = policy_configuration_event,
                .unix_ms = unix_milliseconds(),
                .deadline_ms = 0U,
                .pending_outbound = counts.pending_outbound,
                .pending_actions = counts.pending_actions,
                .reason = quiesce->reason,
            });
            lifecycle.publish(RuntimeServiceMode::quiesced);
            response = ControlResponse{
                .ok = true,
                .json = std::string(
                    "{\"format\":\"NATRAV_OVERLAY_CONTROL_QUIESCE_V1\",\"ok\":true") +
                    ",\"service_mode\":\"QUIESCED\"" +
                    ",\"pending_outbound\":" +
                    std::to_string(counts.pending_outbound) +
                    ",\"pending_actions\":" +
                    std::to_string(counts.pending_actions) + "}",
            };
        } else if (const auto* resume = std::get_if<ControlResume>(&request)) {
            std::lock_guard<std::mutex> transition_lock(
                lifecycle.transition_mutex());
            if (lifecycle.mode() != RuntimeServiceMode::quiesced) {
                app_fail("SERVICE_NOT_QUIESCED",
                    "resume requires the QUIESCED service state");
            }
            const auto counts = state.pending_work_counts();
            record_lifecycle_transition(state, policy_configuration_event, LifecycleEvent{
                .kind = LifecycleTransitionKind::resumed,
                .request_id = request_id,
                .uid = principal->uid,
                .pid = principal->pid,
                .configuration_event = policy_configuration_event,
                .unix_ms = unix_milliseconds(),
                .deadline_ms = 0U,
                .pending_outbound = counts.pending_outbound,
                .pending_actions = counts.pending_actions,
                .reason = resume->reason,
            });
            lifecycle.publish(RuntimeServiceMode::running);
            scheduler_signal.notify();
            response = ControlResponse{
                .ok = true,
                .json = std::string(
                    "{\"format\":\"NATRAV_OVERLAY_CONTROL_RESUME_V1\",\"ok\":true") +
                    ",\"service_mode\":\"RUNNING\"" +
                    ",\"pending_outbound\":" +
                    std::to_string(counts.pending_outbound) +
                    ",\"pending_actions\":" +
                    std::to_string(counts.pending_actions) + "}",
            };
        } else if (const auto* drain =
                       std::get_if<ControlDrainShutdown>(&request)) {
            std::unique_lock<std::mutex> transition_lock(
                lifecycle.transition_mutex());
            if (drain->final_state_head && terminal_handoff) {
                app_fail("TERMINAL_HEAD_ALREADY_REQUESTED", "one terminal handoff per process stop");
            }
            if (lifecycle.mode() == RuntimeServiceMode::draining) {
                app_fail("SERVICE_ALREADY_DRAINING",
                    "a drain-shutdown is already in progress");
            }
            const auto started = state.pending_work_counts();
            record_lifecycle_transition(state, policy_configuration_event, LifecycleEvent{
                .kind = LifecycleTransitionKind::drain_started,
                .request_id = request_id,
                .uid = principal->uid,
                .pid = principal->pid,
                .configuration_event = policy_configuration_event,
                .unix_ms = unix_milliseconds(),
                .deadline_ms = drain->deadline_ms,
                .pending_outbound = started.pending_outbound,
                .pending_actions = started.pending_actions,
                .reason = drain->reason,
            });
            lifecycle.publish(RuntimeServiceMode::draining);
            scheduler_signal.notify();
            const char* pause_raw = std::getenv(
                "NATRAV_OVERLAY_TEST_DRAIN_AFTER_START_MS");
            if (pause_raw != nullptr && *pause_raw != '\0') {
                const auto pause_ms = parse_u64(
                    pause_raw,
                    "NATRAV_OVERLAY_TEST_DRAIN_AFTER_START_MS",
                    0U,
                    60'000U);
                std::this_thread::sleep_for(std::chrono::milliseconds(
                    static_cast<std::chrono::milliseconds::rep>(pause_ms)));
            }
            const auto drain_deadline = std::chrono::steady_clock::now() +
                std::chrono::milliseconds(drain->deadline_ms);
            PendingWorkCounts final_counts = started;
            bool completed = false;
            while (true) {
                final_counts = state.pending_work_counts();
                if (final_counts.pending_outbound == 0U &&
                    final_counts.pending_actions == 0U &&
                    peer_queue.size() == 0U &&
                    stats.peer_active.load() == 0U) {
                    completed = true;
                    break;
                }
                if (std::chrono::steady_clock::now() >= drain_deadline) {
                    break;
                }
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
            }
            const LifecycleEvent terminal_event{
                .kind = completed ? LifecycleTransitionKind::drain_completed :
                    LifecycleTransitionKind::drain_deadline,
                .request_id = request_id,
                .uid = principal->uid,
                .pid = principal->pid,
                .configuration_event = policy_configuration_event,
                .unix_ms = unix_milliseconds(),
                .deadline_ms = drain->deadline_ms,
                .pending_outbound = final_counts.pending_outbound,
                .pending_actions = final_counts.pending_actions,
                .reason = drain->reason,
            };
            if (drain->final_state_head) {
                // The terminal lifecycle account belongs AFTER all writer joins.
                // Socket ownership moves; this worker must not wait for itself.
                terminal_handoff.emplace(TerminalHeadHandoff{
                    .connection = std::move(connection), .principal = *principal,
                    .request_id = request_id, .io = initial_config->io,
                    .drain_terminal = terminal_event,
                    .correlation = drain->correlation});
                return true; // committed stop survives client loss
            }
            record_lifecycle_transition(state, policy_configuration_event, terminal_event);
            // The terminal drain account is the durable stop boundary. Reply
            // construction and delivery occur afterward and cannot revoke it.
            stop_intent_committed = true;
            deadline = deadline_after(std::chrono::milliseconds(5000));
            const bool correlated = drain->correlation.has_value();
            response = ControlResponse{
                .ok = true,
                .json = std::string(
                    correlated ?
                        "{\"format\":\"NATRAV_OVERLAY_CONTROL_CORRELATED_DRAIN_SHUTDOWN_V1\",\"ok\":true" :
                        "{\"format\":\"NATRAV_OVERLAY_CONTROL_DRAIN_SHUTDOWN_V1\",\"ok\":true") +
                    (correlated ? ",\"correlation_token\":" + json_string(*drain->correlation) +
                        ",\"correlation_semantics\":\"PROVENANCE_ONLY_NOT_IDEMPOTENCY_OR_RECEIPT\"" : std::string()) +
                    ",\"completed\":" +
                    std::string(completed ? "true" : "false") +
                    ",\"deadline_reached\":" +
                    std::string(completed ? "false" : "true") +
                    ",\"pending_outbound\":" +
                    std::to_string(final_counts.pending_outbound) +
                    ",\"pending_actions\":" +
                    std::to_string(final_counts.pending_actions) +
                    ",\"active_peer_connections\":" +
                    std::to_string(stats.peer_active.load()) + "}",
            };
        } else {
            std::lock_guard<std::mutex> transition_lock(
                lifecycle.transition_mutex());
            const bool final_head = std::get<ControlShutdown>(request).final_state_head;
            if (final_head && terminal_handoff) {
                app_fail("TERMINAL_HEAD_ALREADY_REQUESTED", "one terminal handoff per process stop");
            }
            const auto counts = state.pending_work_counts();
            record_lifecycle_transition(state, policy_configuration_event, LifecycleEvent{
                .kind = LifecycleTransitionKind::shutdown_requested,
                .request_id = request_id,
                .uid = principal->uid,
                .pid = principal->pid,
                .configuration_event = policy_configuration_event,
                .unix_ms = unix_milliseconds(),
                .deadline_ms = 0U,
                .pending_outbound = counts.pending_outbound,
                .pending_actions = counts.pending_actions,
                .reason = "immediate local shutdown",
            });
            lifecycle.publish(RuntimeServiceMode::draining);
            if (final_head) {
                terminal_handoff.emplace(TerminalHeadHandoff{
                    .connection = std::move(connection), .principal = *principal,
                    .request_id = request_id, .io = initial_config->io,
                    .drain_terminal = std::nullopt,
                    .correlation = std::get<ControlShutdown>(request).correlation});
                return true; // no response-dependent cancellation of accepted stop
            }
            // The durable SHUTDOWN_REQUESTED account and DRAINING publication
            // precede every fallible response-construction or transport step.
            stop_intent_committed = true;
            const auto& stop = std::get<ControlShutdown>(request);
            response = ControlResponse{
                .ok = true,
                .json = stop.correlation.has_value() ?
                    std::string("{\"format\":\"NATRAV_OVERLAY_CONTROL_CORRELATED_SHUTDOWN_V1\",\"ok\":true") +
                        ",\"correlation_token\":" + json_string(*stop.correlation) +
                        ",\"correlation_semantics\":\"PROVENANCE_ONLY_NOT_IDEMPOTENCY_OR_RECEIPT\"}" :
                    "{\"format\":\"NATRAV_OVERLAY_CONTROL_SHUTDOWN_V2\",\"ok\":true}",
            };
        }
        }
    } catch (const AppError& error) {
        ++stats.control_errors;
        if (principal.has_value() && !decision_recorded) {
            try {
                const auto denial_lease = query_lease ? query_lease : runtime.lease();
                policy_configuration_event = denial_lease->config->format_version >= 8U ?
                    configuration_event_for(state, *denial_lease->config) : 0U;
                record_control_decision(
                    state, stats, *principal, request_id, metadata,
                    policy_configuration_event, LocalControlDecisionKind::denied,
                    valid_error_code(error.code()) ? error.code() :
                        std::string_view("CONTROL_REJECTED"));
                decision_recorded = true;
            } catch (const std::exception&) {
                // Preserve the original typed failure when the audit journal is
                // itself unavailable. No command mutation has occurred.
            }
        }
        response = ControlResponse{.ok = false, .json = error_json(error.code(), error.what())};
    } catch (const datacube::Failure& error) {
        ++stats.control_errors;
        if (principal.has_value() && !decision_recorded) {
            try {
                const auto denial_lease = query_lease ? query_lease : runtime.lease();
                policy_configuration_event = denial_lease->config->format_version >= 8U ?
                    configuration_event_for(state, *denial_lease->config) : 0U;
                record_control_decision(
                    state, stats, *principal, request_id, metadata,
                    policy_configuration_event, LocalControlDecisionKind::denied,
                    valid_error_code(error.code()) ? error.code() :
                        std::string_view("CONTROL_PROTOCOL_REJECTED"));
                decision_recorded = true;
            } catch (const std::exception&) {}
        }
        response = ControlResponse{.ok = false, .json = error_json(error.code(), error.what())};
    } catch (const std::exception& error) {
        ++stats.control_errors;
        if (principal.has_value() && !decision_recorded) {
            try {
                const auto denial_lease = query_lease ? query_lease : runtime.lease();
                policy_configuration_event = denial_lease->config->format_version >= 8U ?
                    configuration_event_for(state, *denial_lease->config) : 0U;
                record_control_decision(
                    state, stats, *principal, request_id, metadata,
                    policy_configuration_event, LocalControlDecisionKind::denied,
                    "CONTROL_EXCEPTION");
                decision_recorded = true;
            } catch (const std::exception&) {}
        }
        response = ControlResponse{
            .ok = false,
            .json = error_json("CONTROL_EXCEPTION", error.what()),
        };
    }
    if (principal.has_value()) {
        response.json = annotate_control_json(
            std::move(response.json), *principal, request_id,
            local_control_class_name(metadata.command_class));
    }
    if (query_response_limit && response.json.size() > *query_response_limit) {
        response = ControlResponse{.ok = false, .json = error_json(
            (metadata.command == "STATE_HEAD" ? "STATE_HEAD_RESPONSE_LIMIT" : metadata.command == "ACTION_RESULT_REVIEW_HISTORY" ? "RESULT_REVIEW_HISTORY_RESPONSE_LIMIT" : metadata.command == "ACTION_RESULT_QUERY" ? "ACTION_RESULT_RESPONSE_LIMIT" : metadata.command == "CONFIGURATION_HISTORY" ? "CONFIGURATION_HISTORY_RESPONSE_LIMIT" : "EVIDENCE_QUERY_RESPONSE_LIMIT"), "complete annotated response exceeds selected limit")};
    }
    // Release before socket writes: already-authorized bounded bytes may finish
    // transmitting after publication, but a later query rechecks active grants.
    query_lease.reset();
    try {
        const auto encoded = encode_control_response(response);
        write_frame(fd, encoded, deadline, initial_config->io, counters);
        static_cast<void>(::shutdown(fd, SHUT_WR));
    } catch (const std::exception&) {
        ++stats.control_errors;
        // Reply delivery is not part of stop acceptance. Once the authorized
        // lifecycle transition has committed and stop intent is set, a client
        // disconnect must not return this process to service.
    }
    return stop_intent_committed;
}

// No runtime writer remains when this is called. Do not append an audit or
// lifecycle event after sealing/sampling, including on response loss.
struct TerminalHeadDelivery final {
    std::string_view status{"NOT_REQUESTED"};
    bool failed{false};
};

[[nodiscard]] TerminalHeadDelivery finish_terminal_head(
    TerminalHeadHandoff& handoff, NodeState& state,
    RuntimeConfiguration& runtime, RuntimeStats& stats, const bool runtime_failed) {
    ControlResponse response;
    bool failed = false;
    try {
        if (runtime_failed) {
            app_fail("TERMINAL_HEAD_RUNTIME_FAILED", "a runtime worker failed; no healthy terminal handoff");
        }
        // Drain's stopping classification was selected at its existing deadline;
        // its remainder account is now sampled after late outcomes have ceased.
        if (handoff.drain_terminal) {
            auto event = *handoff.drain_terminal;
            const auto pending = state.pending_work_counts();
            event.pending_outbound = pending.pending_outbound;
            event.pending_actions = pending.pending_actions;
            event.unix_ms = unix_milliseconds();
            record_lifecycle_transition(state, event.configuration_event, std::move(event));
        }
        const auto lease = runtime.lease();
        // Stop authority was checked when committing the stop. Head disclosure
        // additionally requires INSPECT in the FINAL accepted configuration.
        if (!terminal_head_inspection_allowed(*lease->config, handoff.principal.uid)) {
            app_fail("LOCAL_CONTROL_CLASS_DENIED", "terminal head requires current INSPECT authority");
        }
        auto json = state.seal_terminal_state_head_json();
        if (handoff.correlation.has_value()) {
            constexpr std::string_view ordinary =
                "{\"format\":\"NATRAV_OVERLAY_TERMINAL_STATE_HEAD_V1\"";
            constexpr std::string_view correlated =
                "{\"format\":\"NATRAV_OVERLAY_CORRELATED_TERMINAL_STATE_HEAD_V1\"";
            if (!json.starts_with(ordinary)) {
                app_fail("TERMINAL_HEAD_FAILED",
                    "terminal state-head response has an unexpected format");
            }
            json.replace(0U, ordinary.size(), correlated);
        }
        json.pop_back();
        if (handoff.correlation.has_value()) {
            json += ",\"correlation_token\":" + json_string(*handoff.correlation) +
                ",\"correlation_semantics\":\"PROVENANCE_ONLY_NOT_IDEMPOTENCY_OR_RECEIPT\"";
        }
        const bool drain = handoff.drain_terminal.has_value();
        const bool complete = drain &&
            handoff.drain_terminal->kind == LifecycleTransitionKind::drain_completed;
        json += ",\"shutdown\":{\"requested\":" + json_string(drain ? "DRAIN" : "IMMEDIATE") +
            ",\"writers_joined\":true,\"final_lifecycle_accounting\":\"COMPLETE\","
            "\"drain_completed_at_wait_boundary\":" + std::string(drain ? (complete ? "true" : "false") : "null") +
            ",\"drain_deadline_reached\":" + std::string(drain ? (complete ? "false" : "true") : "null") +
            ",\"delivery_confirmation\":\"NOT_ESTABLISHED\",\"required_head_class\":\"INSPECT\"}}";
        response = ControlResponse{.ok = true, .json = std::move(json)};
    } catch (const AppError& error) {
        failed = true;
        response = ControlResponse{.ok = false, .json = error_json(error.code(), error.what())};
    } catch (const std::exception& error) {
        failed = true;
        response = ControlResponse{.ok = false, .json = error_json("TERMINAL_HEAD_FAILED", error.what())};
    }
    response.json = annotate_control_json(std::move(response.json), handoff.principal,
        handoff.request_id, "SHUTDOWN");
    if (response.json.size() > kMaximumTerminalStateHeadJsonBytes) {
        failed = true;
        response = ControlResponse{.ok = false, .json = error_json(
            "TERMINAL_HEAD_RESPONSE_LIMIT", "complete terminal handoff exceeds fixed bound")};
    }
    try {
        IoCounters counters;
        write_frame(handoff.connection.get(), encode_control_response(response),
            deadline_after(std::chrono::milliseconds(5000)), handoff.io, counters);
        static_cast<void>(::shutdown(handoff.connection.get(), SHUT_WR));
    } catch (const std::exception&) {
        ++stats.control_errors;
        handoff.connection.reset();
        return {.status = failed ? "FAILED_RESPONSE_LOST" : "RESPONSE_LOST", .failed = failed};
    }
    handoff.connection.reset();
    // A successful write is deliberately not a client receipt or anchor update.
    return {.status = failed ? "FAILED" : "SENT_UNCONFIRMED", .failed = failed};
}

void scheduler_loop(
    NodeState& state,
    TlsContext& tls,
    RuntimeConfiguration& runtime,
    PeerRuntimeStats& stats,
    SchedulerSignal& signal,
    std::atomic<bool>& stopping) {
    std::optional<OutboundPeerSession> session;
    std::string session_contract;
    std::string session_route_id;
    const auto initial_io = runtime.snapshot()->io;
    bool selection_pause_used = false;

    const auto publish_session = [&] {
        if (!session.has_value()) {
            stats.current_session_operations.store(0U);
            stats.current_session_bytes.store(0U);
            stats.session_state.store(0U);
            return;
        }
        stats.current_session_operations.store(session->operations());
        stats.current_session_bytes.store(session->session_bytes());
        stats.session_state.store(2U);
    };
    const auto retire_session = [&](const bool clean_close) {
        if (!session.has_value()) { return; }
        stats.session_state.store(3U);
        const bool clean = !clean_close || session->close_cleanly(initial_io);
        ++stats.sessions_retired;
        if (!clean) { ++stats.sessions_failed; }
        session.reset();
        session_contract.clear();
        session_route_id.clear();
        clear_active_route(stats);
        publish_session();
    };
    const auto fail_session = [&] {
        ++stats.sessions_failed;
        session.reset();
        session_contract.clear();
        session_route_id.clear();
        clear_active_route(stats);
        publish_session();
    };
    const auto record_session_operation = [&](const std::uint64_t before) {
        if (!session.has_value()) { return; }
        const auto after = session->operations();
        if (after > before) {
            stats.session_operations.fetch_add(after - before);
        }
        publish_session();
    };
    const auto wait_for_route_cooldown = [&](
        const PeerConfig& peer,
        const std::uint64_t now) {
        std::optional<std::uint64_t> earliest;
        static_cast<void>(eligible_routes(stats, peer, now, earliest));
        std::uint64_t wait_ms = 500U;
        if (earliest.has_value()) {
            wait_ms = std::min<std::uint64_t>(
                *earliest > now ? *earliest - now : 1U, 1'000U);
        }
        return std::chrono::milliseconds(
            static_cast<std::chrono::milliseconds::rep>(wait_ms));
    };

    try {
        while (!stopping.load()) {
            auto generation_lease = runtime.lease();
            const auto& config = *generation_lease->config;
            std::unique_lock<std::mutex> transition_lock(stats.transition_mutex);
            const bool has_pending = state.has_pending_outbound_for(stats.node_id);
            if (!has_pending && !session.has_value()) {
                transition_lock.unlock();
                generation_lease.reset();
                signal.wait_for(std::chrono::milliseconds(500), stopping);
                continue;
            }

            if (session.has_value()) {
                const auto* configured_peer = find_peer(config, stats.node_id);
                const auto* configured_route = configured_peer == nullptr ? nullptr :
                    find_peer_route(*configured_peer, session_route_id);
                const bool route_usable = configured_route != nullptr &&
                    configured_route->state == PeerRouteState::enabled;
                const bool contract_matches = route_usable &&
                    peer_route_runtime_contract(
                        config, stats.node_id, session_route_id) == session_contract;
                if (!contract_matches) {
                    retire_session(false);
                    ++stats.configuration_drains;
                }
            }

            if (!has_pending) {
                if (session.has_value() && !session->reusable()) {
                    retire_session(true);
                }
                std::uint64_t wait_ms = 500U;
                if (session.has_value()) {
                    wait_ms = std::min<std::uint64_t>(
                        wait_ms,
                        static_cast<std::uint64_t>(std::max<std::int64_t>(
                            1, session->retirement_delay().count())));
                }
                transition_lock.unlock();
                generation_lease.reset();
                signal.wait_for(
                    std::chrono::milliseconds(
                        static_cast<std::chrono::milliseconds::rep>(wait_ms)),
                    stopping);
                continue;
            }

            const auto* routed_peer = find_peer(config, stats.node_id);
            if (routed_peer != nullptr) synchronize_route_observations(stats, *routed_peer);
            const auto now = unix_milliseconds();
            auto selected = state.select_delivery(config, stats.node_id, now);
            ++stats.selection_calls;
            stats.selection_tree_nodes.fetch_add(selected.tree_nodes_visited);
            stats.selection_key_buckets.fetch_add(selected.key_buckets_checked);
            stats.selection_metadata_records.fetch_add(selected.metadata_records_read);
            const auto earliest_next_attempt = selected.next_wake;
            if (selected.kind != DeliveryChoiceKind::none && selected.kind != DeliveryChoiceKind::ready) {
                const auto initial = routed_peer != nullptr ?
                    std::optional(policy_for(*routed_peer, now)) : std::nullopt;
                if (state.maintain_selected_delivery(selected, now, initial)) {
                    ++stats.selection_maintenance;
                    if (selected.kind != DeliveryChoiceKind::initialize_policy) ++stats.expired;
                } else ++stats.selection_stale;
                signal.notify();
                // One maintenance mutation per turn, including removed routes.
                // Lock destructors release both gates before the next turn.
                std::this_thread::yield();
                continue;
            }
            if (selected.kind == DeliveryChoiceKind::none) {
                if (session.has_value() && !session->reusable()) {
                    retire_session(true);
                }
                std::uint64_t wait_ms = 500U;
                if (earliest_next_attempt.has_value()) {
                    wait_ms = std::min<std::uint64_t>(
                        *earliest_next_attempt > now ?
                            *earliest_next_attempt - now : 1U,
                        1'000U);
                }
                if (session.has_value()) {
                    wait_ms = std::min<std::uint64_t>(
                        wait_ms,
                        static_cast<std::uint64_t>(std::max<std::int64_t>(
                            1, session->retirement_delay().count())));
                }
                transition_lock.unlock();
                generation_lease.reset();
                signal.wait_for(
                    std::chrono::milliseconds(
                        static_cast<std::chrono::milliseconds::rep>(wait_ms)),
                    stopping);
                continue;
            }

            if (routed_peer == nullptr || !selected.policy) {
                app_fail("DELIVERY_SELECTION_INVALID", "ready selection has no configured peer or policy");
            }
            const auto& peer = *routed_peer;
            const auto policy = *selected.policy;
            if (!policy.peer_spki_sha256 || !policy.peer_generation) {
                app_fail("OUTBOUND_GENERATION_BINDING_REQUIRED", "pending operation has no durable generation binding");
            }
            const auto* generation = find_peer_generation(config, peer.node_id, *policy.peer_generation);
            if (generation == nullptr || generation->state == KeyGenerationState::revoked ||
                generation->spki_sha256 != *policy.peer_spki_sha256) {
                app_fail("OUTBOUND_GENERATION_BINDING_INVALID", "selected binding is not currently deliverable");
            }
            // Explicit laboratory interleaving hook, disabled in ordinary runs.
            if (!selection_pause_used) {
                const char* raw = std::getenv("NATRAV_OVERLAY_TEST_DELIVERY_SELECTION_PAUSE_MS");
                if (raw != nullptr && *raw != '\0') {
                    selection_pause_used = true;
                    const auto pause = parse_milliseconds(raw, "selection pause", 1U, 10'000U);
                    transition_lock.unlock();
                    std::cerr << "DELIVERY_SELECTED " << operation_id_text(selected.operation_id) << '\n';
                    std::this_thread::sleep_for(pause);
                    transition_lock.lock();
                }
            }

            if (!state.selected_delivery_is_current(selected, unix_milliseconds())) {
                ++stats.selection_stale; signal.notify(); continue;
            }
            if (session.has_value() && !session->usable_for_encoded_size(
                    generation->generation,
                    generation->spki_sha256,
                    selected.encoded_bytes)) {
                retire_session(true);
            }

            const bool legacy_attempt_accounting = config.format_version < 13U;
            bool durable_attempt_started = false;
            std::uint64_t attempt_time = unix_milliseconds();
            std::uint64_t next_attempt = saturating_add(
                attempt_time,
                retry_backoff(policy, selected.attempts + 1U));
            if (legacy_attempt_accounting) {
                if (!state.begin_selected_delivery(selected, attempt_time, next_attempt)) {
                    ++stats.selection_stale; signal.notify(); continue;
                }
                ++stats.attempts;
                durable_attempt_started = true;
            }

            std::string last_open_code = "ROUTE_SET_UNAVAILABLE";
            std::string last_open_detail = "no configured route completed TCP/TLS/HELLO";
            if (!session.has_value()) {
                std::optional<std::uint64_t> earliest_route_cooldown;
                auto candidates = legacy_attempt_accounting ? peer.routes :
                    eligible_routes(
                        stats, peer, attempt_time, earliest_route_cooldown);
                if (legacy_attempt_accounting) {
                    candidates.erase(std::remove_if(
                        candidates.begin(), candidates.end(),
                        [](const PeerRouteConfig& route) {
                            return route.state != PeerRouteState::enabled;
                        }), candidates.end());
                }
                for (const auto& route : candidates) {
                    mark_route_selected(stats, route);
                    stats.session_state.store(1U);
                    try {
                        auto adapter_connector = route.locator.kind == TransportKind::adapter ?
                            make_configured_adapter_connector(config, route.locator) : nullptr;
                        session.emplace(OutboundPeerSession::open(
                            tls,
                            config.local_node,
                            peer.node_id,
                            generation->generation,
                            generation->state,
                            generation->spki_sha256,
                            route.locator,
                            selected.operation_id,
                            config.io,
                            config.sessions, adapter_connector.get()));
                        session_route_id = route.route_id;
                        session_contract = peer_route_runtime_contract(
                            config, peer.node_id, route.route_id);
                        mark_route_open_success(
                            stats, route, unix_milliseconds());
                        stats.opened_configuration_event.store(selected.configuration_event);
                        ++stats.sessions_opened;
                        publish_session();
                        break;
                    } catch (const AppError& error) {
                        last_open_code = valid_error_code(error.code()) ?
                            error.code() : "ROUTE_CONNECT_FAILED";
                        last_open_detail = safe_detail(error.what());
                        mark_route_failure(
                            stats, peer, route, last_open_code,
                            unix_milliseconds());
                        ++stats.sessions_failed;
                        session.reset();
                        session_contract.clear();
                        session_route_id.clear();
                        publish_session();
                    } catch (const datacube::Failure& error) {
                        last_open_code = valid_error_code(error.code()) ?
                            error.code() : "ROUTE_CONNECT_FAILED";
                        last_open_detail = safe_detail(error.what());
                        mark_route_failure(
                            stats, peer, route, last_open_code,
                            unix_milliseconds());
                        ++stats.sessions_failed;
                        session.reset();
                        session_contract.clear();
                        session_route_id.clear();
                        publish_session();
                    } catch (const std::exception& error) {
                        last_open_code = "ROUTE_CONNECT_FAILED";
                        last_open_detail = safe_detail(error.what());
                        mark_route_failure(
                            stats, peer, route, last_open_code,
                            unix_milliseconds());
                        ++stats.sessions_failed;
                        session.reset();
                        session_contract.clear();
                        session_route_id.clear();
                        publish_session();
                    }
                }
                if (!session.has_value()) {
                    if (legacy_attempt_accounting) {
                        state.record_outbound_failure(
                            selected.operation_id,
                            last_open_code,
                            last_open_detail,
                            next_attempt);
                        ++stats.failures;
                        signal.notify();
                        continue;
                    }
                    const auto delay = wait_for_route_cooldown(
                        peer, unix_milliseconds());
                    transition_lock.unlock();
                    generation_lease.reset();
                    signal.wait_for(delay, stopping);
                    continue;
                }
            } else {
                ++stats.sessions_reused;
            }

            if (!durable_attempt_started) {
                attempt_time = unix_milliseconds();
                if (attempt_time >= policy.expires_unix_ms) {
                    if (state.maintain_selected_delivery(selected, attempt_time)) {
                        ++stats.expired; ++stats.selection_maintenance;
                    } else ++stats.selection_stale;
                    retire_session(true);
                    signal.notify();
                    continue;
                }
                next_attempt = saturating_add(
                    attempt_time,
                    retry_backoff(policy, selected.attempts + 1U));
                if (!state.begin_selected_delivery(selected, attempt_time, next_attempt)) {
                    ++stats.selection_stale; signal.notify(); continue;
                }
                ++stats.attempts;
                durable_attempt_started = true;
            }

            auto wire_record = state.copy_selected_delivery(selected);
            if (!wire_record) {
                ++stats.selection_stale; retire_session(false); signal.notify(); continue;
            }
            ++stats.selection_payload_records;
            stats.selection_payload_bytes.fetch_add(static_cast<std::uint64_t>(wire_record->payload.size()));
            const auto route_for_attempt = session_route_id;
            try {
                const auto before_operations = session->operations();
                const auto receipt = session->exchange(*wire_record, config.io);
                record_session_operation(before_operations);
                state.record_outbound_receipt(receipt);
                mark_route_application_success(
                    stats, route_for_attempt, unix_milliseconds());
                ++stats.acknowledged;
                if (session->peer_requested_retirement() ||
                    !session->reusable()) {
                    retire_session(true);
                }
            } catch (const AuthenticatedPeerError& error) {
                if (session.has_value()) {
                    ++stats.session_operations;
                    publish_session();
                }
                if (error.terminal()) {
                    state.record_outbound_rejection(
                        selected.operation_id,
                        error.code(),
                        safe_detail(error.detail()),
                        unix_milliseconds(),
                        *policy.peer_generation,
                        *policy.peer_spki_sha256);
                    ++stats.rejected;
                } else {
                    const std::string code = valid_error_code(error.code()) ?
                        error.code() : "DELIVERY_FAILED";
                    state.record_outbound_failure(
                        selected.operation_id,
                        code,
                        safe_detail(error.detail()),
                        next_attempt);
                    ++stats.failures;
                }
                if (session.has_value() &&
                    (session->peer_requested_retirement() ||
                     !session->reusable())) {
                    retire_session(true);
                }
            } catch (const AppError& error) {
                const auto* route = find_peer_route(peer, route_for_attempt);
                if (route != nullptr) {
                    mark_route_failure(
                        stats, peer, *route, error.code(), unix_milliseconds());
                }
                fail_session();
                const std::string code = valid_error_code(error.code()) ?
                    error.code() : "DELIVERY_FAILED";
                state.record_outbound_failure(
                    selected.operation_id,
                    code,
                    safe_detail(error.what()),
                    next_attempt);
                ++stats.failures;
            } catch (const datacube::Failure& error) {
                const auto* route = find_peer_route(peer, route_for_attempt);
                if (route != nullptr) {
                    mark_route_failure(
                        stats, peer, *route, error.code(), unix_milliseconds());
                }
                fail_session();
                const std::string code = valid_error_code(error.code()) ?
                    error.code() : "DELIVERY_FAILED";
                state.record_outbound_failure(
                    selected.operation_id,
                    code,
                    safe_detail(error.what()),
                    next_attempt);
                ++stats.failures;
            } catch (const std::exception& error) {
                const auto* route = find_peer_route(peer, route_for_attempt);
                if (route != nullptr) {
                    mark_route_failure(
                        stats, peer, *route,
                        "DELIVERY_FAILED", unix_milliseconds());
                }
                fail_session();
                state.record_outbound_failure(
                    selected.operation_id,
                    "DELIVERY_FAILED",
                    safe_detail(error.what()),
                    next_attempt);
                ++stats.failures;
            }
            signal.notify();
        }
        if (session.has_value()) {
            retire_session(true);
        }
    } catch (const std::exception& error) {
        if (session.has_value()) {
            fail_session();
        }
        std::cerr << error_json("SCHEDULER_FATAL", error.what()) << '\n';
        signal.record_failure();
        stopping.store(true);
        signal.notify();
    }
}

[[nodiscard]] std::chrono::milliseconds action_pause_after_begin() {
    const char* raw = std::getenv(
        "NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS");
    if (raw == nullptr || *raw == '\0') {
        return std::chrono::milliseconds(0);
    }
    const auto value = parse_u64(
        raw,
        "NATRAV_OVERLAY_TEST_ACTION_PAUSE_AFTER_BEGIN_MS",
        0U,
        60'000U);
    return std::chrono::milliseconds(
        static_cast<std::chrono::milliseconds::rep>(value));
}

[[nodiscard]] bool action_result_capacity_waitable(
    const AppError& error) noexcept {
    return error.code() == "OUTBOX_GLOBAL_RECORD_LIMIT" ||
        error.code() == "OUTBOX_GLOBAL_PAYLOAD_LIMIT" ||
        error.code() == "OUTBOX_PEER_RECORD_LIMIT" ||
        error.code() == "OUTBOX_PEER_PAYLOAD_LIMIT" ||
        error.code() == "STATE_CAPACITY_EXCEEDED";
}

void action_scheduler_loop(
    NodeState& state,
    ActionRuntimeStats& stats,
    SchedulerSignal& signal,
    std::atomic<bool>& stopping) {
    const auto pause = action_pause_after_begin();
    std::optional<ActionSelection> awaiting_result_capacity;
    try {
        while (!stopping.load()) {
            std::unique_lock<std::mutex> transition_lock(stats.transition_mutex);

            if (awaiting_result_capacity.has_value()) {
                try {
                    if (!state.complete_selected_counter_action(
                            *awaiting_result_capacity, unix_milliseconds())) {
                        ++stats.stale_selections;
                    } else {
                        ++stats.executed;
                    }
                    awaiting_result_capacity.reset();
                    transition_lock.unlock();
                    signal.notify();
                } catch (const AppError& error) {
                    if (!action_result_capacity_waitable(error)) {
                        throw;
                    }
                    transition_lock.unlock();
                    signal.wait_for(std::chrono::milliseconds(250), stopping);
                }
                continue;
            }

            const auto now = unix_milliseconds();
            auto selected = state.select_action(now);
            ++stats.selections;
            stats.index_nodes_visited += selected.tree_nodes_visited;
            stats.metadata_records_read += selected.metadata_records_read;

            if (selected.kind == ActionSelectionKind::none) {
                std::uint64_t wait_ms = 500U;
                if (selected.next_wake_unix_ms.has_value()) {
                    wait_ms = std::min<std::uint64_t>(
                        *selected.next_wake_unix_ms > now ?
                            *selected.next_wake_unix_ms - now : 1U,
                        1'000U);
                }
                transition_lock.unlock();
                signal.wait_for(
                    std::chrono::milliseconds(
                        static_cast<std::chrono::milliseconds::rep>(wait_ms)),
                    stopping);
                continue;
            }

            if (selected.kind == ActionSelectionKind::expired) {
                try {
                    if (state.expire_selected_action(
                            selected, now, "ACTION_DEADLINE_ELAPSED")) {
                        ++stats.expired;
                    } else {
                        ++stats.stale_selections;
                    }
                    transition_lock.unlock();
                    signal.notify();
                } catch (const AppError& error) {
                    if (!action_result_capacity_waitable(error)) {
                        throw;
                    }
                    transition_lock.unlock();
                    signal.wait_for(std::chrono::milliseconds(250), stopping);
                }
                continue;
            }

            if (!state.begin_selected_action(selected, now)) {
                ++stats.stale_selections;
                transition_lock.unlock();
                signal.notify();
                continue;
            }
            ++stats.attempts;
            if (pause.count() != 0) {
                std::this_thread::sleep_for(pause);
            }
            try {
                if (!state.complete_selected_counter_action(
                        selected, unix_milliseconds())) {
                    app_fail("ACTION_SELECTION_STALE",
                        "begun action changed before synchronized completion");
                }
                ++stats.executed;
                transition_lock.unlock();
                signal.notify();
            } catch (const AppError& error) {
                if (!action_result_capacity_waitable(error)) {
                    throw;
                }
                awaiting_result_capacity = selected;
                transition_lock.unlock();
                signal.wait_for(std::chrono::milliseconds(250), stopping);
            }
        }
    } catch (const std::exception& error) {
        ++stats.failures;
        std::cerr << error_json("ACTION_SCHEDULER_FATAL", error.what()) << '\n';
        signal.record_failure();
        stopping.store(true);
        signal.notify();
    }
}

// One bounded page per rotating turn. No per-projection thread, no synthetic
// SO_PEERCRED, no full-state snapshot to poll caught-up/disabled processors.
void projection_scheduler_loop(NodeState& state, RuntimeConfiguration& runtime,
    ServiceLifecycle& lifecycle, SchedulerSignal& signal, std::atomic<bool>& stopping) {
    struct Wait {std::uint64_t generation;std::chrono::steady_clock::time_point until;};
    std::map<std::string,Wait> waits;
    std::string last;
    try {
        while(!stopping.load()) {
            bool attempted=false;
            auto candidates=state.automatic_projection_candidates();
            // Historical registry is bounded to 128; prune all inactive timers.
            for(auto it=waits.begin();it!=waits.end();) {
                if(std::none_of(candidates.begin(),candidates.end(),[&](const auto& c){return c.key==it->first;})){it=waits.erase(it);}else{++it;}
            }
            const auto pivot=std::upper_bound(candidates.begin(),candidates.end(),last,
                [](const auto& key,const auto& c){return key<c.key;});
            std::rotate(candidates.begin(),pivot,candidates.end());
            for(const auto& c:candidates) {
                if(stopping.load()){break;}
                const auto now=std::chrono::steady_clock::now();
                const auto previous=waits.find(c.key);
                if(previous!=waits.end()&&previous->second.generation==c.generation&&now<previous->second.until){continue;}
                // Same lock order as control lifecycle: configuration -> lifecycle -> state.
                const auto lease=runtime.lease();
                std::lock_guard<std::mutex> life(lifecycle.transition_mutex());
                if(lifecycle.mode()!=RuntimeServiceMode::running){break;}
                if(state.automatic_projection_step(c.key,*lease->config,
                        configuration_event_for(state,*lease->config),
                        static_cast<std::uint32_t>(::geteuid()),static_cast<std::uint32_t>(::getpid()))) {
                    last=c.key;waits[c.key]=Wait{c.generation,std::chrono::steady_clock::now()+std::chrono::milliseconds(c.minimum_interval_ms)};
                    attempted=true;break;
                }
            }
            // Actual peer admission, enable, configuration change and resume
            // notify this condition. Periodic bounded fallback covers lost wakeups.
            auto wait=std::chrono::milliseconds(500);
            const auto now=std::chrono::steady_clock::now();
            for(const auto& [key,value]:waits){static_cast<void>(key);if(value.until>now){
                wait=std::min(wait,std::max(std::chrono::milliseconds(10),std::chrono::duration_cast<std::chrono::milliseconds>(value.until-now)));}}
            signal.wait_for(attempted?std::chrono::milliseconds(10):wait,stopping);
        }
    } catch(const std::exception& e) {
        std::cerr<<error_json("PROJECTION_SCHEDULER_FATAL",e.what())<<'\n';signal.record_failure();stopping.store(true);signal.notify();
    }
}

// One bounded disclosure per rotating turn. The publication grant is
// independent of the internal projection-processing grant and no channel owns
// a dedicated thread.
void publication_channel_scheduler_loop(
    NodeState& state,
    RuntimeConfiguration& runtime,
    ServiceLifecycle& lifecycle,
    SchedulerSignal& signal,
    std::atomic<bool>& stopping) {
    struct Wait final {
        std::uint64_t generation{0U};
        std::chrono::steady_clock::time_point until{};
    };
    std::map<std::string, Wait> waits;
    std::string last;
    try {
        while (!stopping.load()) {
            bool changed = false;
            auto candidates = state.automatic_publication_channel_candidates();
            for (auto it = waits.begin(); it != waits.end();) {
                if (std::none_of(candidates.begin(), candidates.end(),
                        [&](const auto& candidate) {
                            return candidate.key == it->first;
                        })) {
                    it = waits.erase(it);
                } else {
                    ++it;
                }
            }
            const auto pivot = std::upper_bound(
                candidates.begin(), candidates.end(), last,
                [](const auto& key, const auto& candidate) {
                    return key < candidate.key;
                });
            std::rotate(candidates.begin(), pivot, candidates.end());
            for (const auto& candidate : candidates) {
                if (stopping.load()) { break; }
                const auto now = std::chrono::steady_clock::now();
                const auto previous = waits.find(candidate.key);
                if (previous != waits.end() &&
                    previous->second.generation == candidate.generation &&
                    now < previous->second.until) {
                    continue;
                }
                const auto lease = runtime.lease();
                std::lock_guard<std::mutex> life(lifecycle.transition_mutex());
                if (lifecycle.mode() != RuntimeServiceMode::running) { break; }
                std::optional<OutboundPolicy> policy;
                if (const auto* peer = find_peer(
                        *lease->config, candidate.recipient); peer != nullptr) {
                    policy = policy_for(*peer, unix_milliseconds());
                }
                if (state.automatic_publication_channel_step(
                        candidate.key, *lease->config,
                        configuration_event_for(state, *lease->config),
                        static_cast<std::uint32_t>(::geteuid()),
                        static_cast<std::uint32_t>(::getpid()), policy)) {
                    last = candidate.key;
                    waits[candidate.key] = Wait{
                        .generation = candidate.generation,
                        .until = std::chrono::steady_clock::now() +
                            std::chrono::milliseconds(
                                candidate.minimum_interval_ms),
                    };
                    changed = true;
                    break;
                }
            }
            auto wait = std::chrono::milliseconds(500);
            const auto now = std::chrono::steady_clock::now();
            for (const auto& [key, value] : waits) {
                static_cast<void>(key);
                if (value.until > now) {
                    wait = std::min(wait, std::max(
                        std::chrono::milliseconds(10),
                        std::chrono::duration_cast<std::chrono::milliseconds>(
                            value.until - now)));
                }
            }
            signal.wait_for(changed ? std::chrono::milliseconds(10) : wait,
                            stopping);
        }
    } catch (const std::exception& error) {
        std::cerr << error_json(
            "PUBLICATION_CHANNEL_SCHEDULER_FATAL", error.what()) << '\n';
        signal.record_failure();
        stopping.store(true);
        signal.notify();
    }
}


// One bounded source-subscription semantic step per rotating turn. A provider
// has one worker for the finite registry rather than one thread per grant.
// Network delivery remains the ordinary durable outbox scheduler's work.
void source_subscription_scheduler_loop(
    NodeState& state,
    RuntimeConfiguration& runtime,
    ServiceLifecycle& lifecycle,
    SchedulerSignal& signal,
    std::atomic<bool>& stopping) {
    struct Wait final {
        std::uint64_t generation{0U};
        std::chrono::steady_clock::time_point until{};
    };
    std::map<std::string, Wait> waits;
    std::string last;
    try {
        while (!stopping.load()) {
            bool changed = false;
            auto candidates = state.automatic_source_subscription_candidates();
            for (auto it = waits.begin(); it != waits.end();) {
                if (std::none_of(candidates.begin(), candidates.end(),
                        [&](const auto& candidate) {
                            return candidate.grant == it->first;
                        })) {
                    it = waits.erase(it);
                } else {
                    ++it;
                }
            }
            const auto pivot = std::upper_bound(
                candidates.begin(), candidates.end(), last,
                [](const auto& key, const auto& candidate) {
                    return key < candidate.grant;
                });
            std::rotate(candidates.begin(), pivot, candidates.end());
            for (const auto& candidate : candidates) {
                if (stopping.load()) { break; }
                const auto now = std::chrono::steady_clock::now();
                const auto previous = waits.find(candidate.grant);
                if (previous != waits.end() &&
                    previous->second.generation == candidate.generation &&
                    now < previous->second.until) {
                    continue;
                }
                const auto lease = runtime.lease();
                std::lock_guard<std::mutex> life(lifecycle.transition_mutex());
                if (lifecycle.mode() != RuntimeServiceMode::running) { break; }
                if (state.automatic_source_subscription_step(
                        candidate.grant, *lease->config,
                        configuration_event_for(state, *lease->config),
                        static_cast<std::uint32_t>(::geteuid()),
                        static_cast<std::uint32_t>(::getpid()))) {
                    last = candidate.grant;
                    waits[candidate.grant] = Wait{
                        .generation = candidate.generation,
                        .until = std::chrono::steady_clock::now() +
                            std::chrono::milliseconds(candidate.minimum_interval_ms),
                    };
                    changed = true;
                    break;
                }
            }
            auto wait = std::chrono::milliseconds(500);
            const auto now = std::chrono::steady_clock::now();
            for (const auto& [key, value] : waits) {
                static_cast<void>(key);
                if (value.until > now) {
                    wait = std::min(wait, std::max(
                        std::chrono::milliseconds(10),
                        std::chrono::duration_cast<std::chrono::milliseconds>(
                            value.until - now)));
                }
            }
            signal.wait_for(changed ? std::chrono::milliseconds(10) : wait,
                            stopping);
        }
    } catch (const std::exception& error) {
        std::cerr << error_json(
            "SOURCE_SUBSCRIPTION_SCHEDULER_FATAL", error.what()) << '\n';
        signal.record_failure();
        stopping.store(true);
        signal.notify();
    }
}

void import_scheduler_loop(
    NodeState& state,
    RuntimeConfiguration& runtime,
    ServiceLifecycle& lifecycle,
    SchedulerSignal& signal,
    std::atomic<bool>& stopping) {
    struct Wait final {
        std::uint64_t generation{0U};
        std::chrono::steady_clock::time_point until{};
    };
    std::map<std::string, Wait> waits;
    std::string last;
    try {
        while (!stopping.load()) {
            bool changed = false;
            auto candidates = state.automatic_import_candidates();
            for (auto it = waits.begin(); it != waits.end();) {
                if (std::none_of(candidates.begin(), candidates.end(),
                        [&](const auto& candidate) {
                            return candidate.view == it->first;
                        })) {
                    it = waits.erase(it);
                } else {
                    ++it;
                }
            }
            const auto pivot = std::upper_bound(
                candidates.begin(), candidates.end(), last,
                [](const auto& key, const auto& candidate) {
                    return key < candidate.view;
                });
            std::rotate(candidates.begin(), pivot, candidates.end());
            for (const auto& candidate : candidates) {
                if (stopping.load()) { break; }
                const auto now = std::chrono::steady_clock::now();
                const auto previous = waits.find(candidate.view);
                if (previous != waits.end() &&
                    previous->second.generation == candidate.generation &&
                    now < previous->second.until) {
                    continue;
                }
                const auto lease = runtime.lease();
                std::lock_guard<std::mutex> life(lifecycle.transition_mutex());
                if (lifecycle.mode() != RuntimeServiceMode::running) { break; }
                if (state.automatic_import_step(
                        candidate.view, *lease->config,
                        configuration_event_for(state, *lease->config),
                        static_cast<std::uint32_t>(::geteuid()),
                        static_cast<std::uint32_t>(::getegid()),
                        static_cast<std::uint32_t>(::getpid()))) {
                    last = candidate.view;
                    waits[candidate.view] = Wait{
                        .generation = candidate.generation,
                        .until = std::chrono::steady_clock::now() +
                            std::chrono::milliseconds(candidate.interval_ms),
                    };
                    changed = true;
                    break;
                }
            }
            auto wait = std::chrono::milliseconds(500);
            const auto now = std::chrono::steady_clock::now();
            for (const auto& [key, value] : waits) {
                static_cast<void>(key);
                if (value.until > now) {
                    wait = std::min(wait, std::max(
                        std::chrono::milliseconds(10),
                        std::chrono::duration_cast<std::chrono::milliseconds>(
                            value.until - now)));
                }
            }
            if(changed)signal.notify();
            signal.wait_for(changed ? std::chrono::milliseconds(10) : wait,
                            stopping);
        }
    } catch (const std::exception& error) {
        std::cerr << error_json(
            "IMPORT_SCHEDULER_FATAL", error.what()) << '\n';
        signal.record_failure();
        stopping.store(true);
        signal.notify();
    }
}

void install_signals() {
    struct sigaction action {};
    action.sa_handler = persistent_stop_handler;
    ::sigemptyset(&action.sa_mask);
    action.sa_flags = 0;
    if (::sigaction(SIGTERM, &action, nullptr) != 0 ||
        ::sigaction(SIGINT, &action, nullptr) != 0) {
        app_fail("SIGNAL_SETUP_FAILED", datacube::errno_detail("sigaction", errno));
    }
    persistent_signal_stop = 0;
}

void accept_transport_ready(
    TransportListener& listener,
    TransportStreamQueue& queue,
    std::atomic<std::uint64_t>& accepted,
    std::atomic<std::uint64_t>& queued,
    std::atomic<std::uint64_t>& busy) {
    while (true) {
        auto connection = listener.accept_ready();
        if (!connection) {
            return;
        }
        ++accepted;
        if (queue.push(std::move(connection))) {
            ++queued;
        } else {
            ++busy;
        }
    }
}

void accept_control_ready(
    const int listener,
    FdQueue& queue,
    std::atomic<std::uint64_t>& accepted,
    std::atomic<std::uint64_t>& queued,
    std::atomic<std::uint64_t>& busy) {
    while (true) {
        const int raw = ::accept4(
            listener, nullptr, nullptr, SOCK_CLOEXEC | SOCK_NONBLOCK);
        if (raw < 0) {
            if (errno == EINTR) { continue; }
            if (errno == EAGAIN || errno == EWOULDBLOCK) { return; }
            app_fail("ACCEPT_FAILED", datacube::errno_detail("accept4", errno));
        }
        datacube::Fd connection(raw);
        ++accepted;
        if (queue.push(std::move(connection))) {
            ++queued;
        } else {
            ++busy;
        }
    }
}

}  // namespace

ControlResponse exchange_control_request(
    const std::filesystem::path& control_socket,
    const ControlRequest& request,
    const IoOptions& io) {
    validate_io_options(io);
    IoCounters counters;
    const auto deadline = deadline_after(io.timeout);
    auto socket = connect_unix(control_socket, deadline, counters);
    const auto payload = encode_control_request(request);
    std::exception_ptr early_write_failure;
    try {
        write_frame(socket.get(), payload, deadline, io, counters);
    } catch (const AppError& error) {
        if (error.code() != "SOCKET_WRITE_CLOSED") { throw; }
        // An unlisted SO_PEERCRED UID is denied before any request is read.
        // The server may queue its denial and close before this write finishes.
        // Never resend a partial command; only recover a complete negative reply
        // from the same connection, within the original byte/time bounds.
        early_write_failure = std::current_exception();
    }
    if (!early_write_failure &&
        ::shutdown(socket.get(), SHUT_WR) != 0 && errno != ENOTCONN) {
        app_fail("CONTROL_SHUTDOWN_FAILED",
            datacube::errno_detail("control shutdown write", errno));
    }
    try {
        FramedReader reader(io);
        const auto response_payload = reader.read_frame(socket.get(), deadline, counters);
        if (reader.queued_frames() != 0U) {
            app_fail("CONTROL_PROTOCOL_REJECTED", "multiple control responses received");
        }
        auto response = decode_control_response(response_payload);
        if (early_write_failure && response.ok) {
            std::rethrow_exception(early_write_failure);
        }
        return response;
    } catch (...) {
        if (early_write_failure) { std::rethrow_exception(early_write_failure); }
        throw;
    }
}

int run_persistent_node(const RuntimeConfig& seed) {
    validate_io_options(seed.io);
    require_node_id(seed.local_node, "configured node");
    NodeState state(
        seed.state_directory,
        seed.local_node,
        seed.maximum_journal_bytes,
        seed.queue_limits);
    RuntimeConfiguration runtime(seed, state);
    ServiceLifecycle lifecycle(state.lifecycle_history());
    PassiveCustodyReceiver passive_custody_receiver(state);
    const auto initial_configuration = runtime.snapshot();
    const auto& config = *initial_configuration;
    if (config.runtime_generation.empty()) { validate_durable_peer_bindings(config, state.snapshot()); }
    TlsContext tls(config.identity);
    CustodyOwnerDispatcher custody_owner_dispatcher(state, tls);
    auto peer_listener = config.listen_locator.kind == TransportKind::adapter ?
        listen_configured_adapter_transport(config, config.listen_locator) :
        listen_transport(config.listen_locator, config.backlog);
    const auto bound_peer_locator = peer_listener->bound_locator();
    const std::uint16_t peer_port =
        bound_peer_locator.kind == TransportKind::tcp
            ? tcp_transport_locator(bound_peer_locator).service
            : bound_peer_locator.kind == TransportKind::udp
                ? udp_transport_locator(bound_peer_locator).local.service
                : 0U;
    const std::string listen_host_json =
        bound_peer_locator.kind == TransportKind::tcp
            ? json_string(tcp_transport_locator(bound_peer_locator).host)
            : bound_peer_locator.kind == TransportKind::udp
                ? json_string(udp_transport_locator(bound_peer_locator).local.host)
                : std::string("null");
    auto control_listener = listen_unix(config.control_socket, config.backlog);
    UnixPathGuard control_path_guard(config.control_socket);
    install_signals();
    recheck_process_state_head_custody_constraint(
        StateHeadCustodyRecheckPoint::startup_acceptance);
    release_process_state_head_custody_constraint();

    RuntimeStats stats;
    ActionRuntimeStats action_stats;
    SchedulerSignal scheduler_signal;
    std::atomic<bool> stopping{false};
    TransportStreamQueue peer_queue(config.peer_queue_capacity);
    FdQueue control_queue(config.control_queue_capacity);

    PeerSchedulerRegistry registry(state, tls, runtime, scheduler_signal, stopping);
    auto initial_registry = registry.prepare(runtime.scheduler_nodes(), true);
    initial_registry->publish();
    initial_registry.reset();

    std::thread action_scheduler(
        action_scheduler_loop,
        std::ref(state),
        std::ref(action_stats),
        std::ref(scheduler_signal),
        std::ref(stopping));

    std::thread projection_scheduler(projection_scheduler_loop,std::ref(state),std::ref(runtime),
        std::ref(lifecycle),std::ref(scheduler_signal),std::ref(stopping));
    std::thread publication_channel_scheduler(
        publication_channel_scheduler_loop, std::ref(state), std::ref(runtime),
        std::ref(lifecycle), std::ref(scheduler_signal), std::ref(stopping));
    std::thread source_subscription_scheduler(
        source_subscription_scheduler_loop, std::ref(state), std::ref(runtime),
        std::ref(lifecycle), std::ref(scheduler_signal), std::ref(stopping));
    std::thread import_scheduler(import_scheduler_loop,std::ref(state),std::ref(runtime),
        std::ref(lifecycle),std::ref(scheduler_signal),std::ref(stopping));
    std::vector<std::thread> peer_workers;
    peer_workers.reserve(config.peer_workers);
    for (std::size_t index = 0U; index < config.peer_workers; ++index) {
        peer_workers.emplace_back([&] {
            while (true) {
                auto connection = peer_queue.pop();
                if (!connection.has_value()) { return; }
                AtomicActivityGuard active(stats.peer_active);
                const PeerConnectionObserver observer = [&](const PeerConnectionEvent event) {
                    switch (event) {
                        case PeerConnectionEvent::authenticated:
                            ++stats.peer_authenticated;
                            break;
                        case PeerConnectionEvent::legacy_connection:
                            ++stats.peer_legacy_connections;
                            break;
                        case PeerConnectionEvent::session_connection:
                            ++stats.peer_session_connections;
                            break;
                        case PeerConnectionEvent::operation:
                            ++stats.peer_session_operations;
                            break;
                        case PeerConnectionEvent::committed:
                            ++stats.peer_committed;
                            scheduler_signal.notify();
                            break;
                        case PeerConnectionEvent::duplicate:
                            ++stats.peer_duplicate;
                            break;
                        case PeerConnectionEvent::authorization_denied:
                            ++stats.peer_authorization_denied;
                            break;
                        case PeerConnectionEvent::action_queued:
                            ++stats.peer_actions_queued;
                            // The connection may remain open for many more NOS1
                            // operations. Wake the durable action scheduler at
                            // admission, not when this session eventually exits.
                            scheduler_signal.notify();
                            break;
                        case PeerConnectionEvent::session_clean_close:
                            ++stats.peer_session_clean_closes;
                            break;
                        case PeerConnectionEvent::session_retired:
                            ++stats.peer_session_retirements;
                            break;
                    }
                };
                const auto opening_config = runtime.snapshot();
                const PeerAdmissionGuard admission_guard = [&](const TlsSessionInfo& peer) {
                    if (!lifecycle.peer_admissions_accepted()) {
                        app_fail("SERVICE_DRAINING",
                            "peer admissions are disabled while the node drains");
                    }
                    auto held = runtime.lease();
                    const auto& current = *held->config;
                    const auto* key = find_peer_generation(current, peer.peer_node, peer.peer_generation);
                    if (key == nullptr || key->state == KeyGenerationState::revoked ||
                        key->spki_sha256 != peer.peer_spki_sha256 ||
                        peer_runtime_contract(current, peer.peer_node) !=
                            peer_runtime_contract(*opening_config, peer.peer_node)) {
                        app_fail("CONFIG_SESSION_RETIRED", "peer session contract changed; reconnect under the active configuration");
                    }
                    return PeerAdmissionLease{.guard = held,
                        .authorization = &current.authorization,
                        .config = &current};
                };
                const CustodySessionHandler custody_handler =
                    [&](const TlsSessionInfo& session,
                        const CustodyTransferOffer& offer) {
                        if (!lifecycle.peer_admissions_accepted()) {
                            app_fail("SERVICE_DRAINING",
                                "custody receipt is disabled while the node drains");
                        }
                        auto held = runtime.lease();
                        return passive_custody_receiver.receive(
                            *held->config, session, offer);
                    };
                const auto outcome = handle_secure_peer_connection(
                    **connection,
                    state,
                    tls,
                    opening_config->trusted_peers,
                    opening_config->authorization,
                    opening_config->local_node,
                    opening_config->io,
                    opening_config->sessions,
                    observer, admission_guard, custody_handler);
                ++stats.peer_completed;
                if (outcome.rejected) { ++stats.peer_rejected; }
                if (outcome.transport_error) { ++stats.peer_transport_errors; }
                if (outcome.actions_queued != 0U) {
                    scheduler_signal.notify();
                }
            }
        });
    }

    std::optional<TerminalHeadHandoff> terminal_handoff;
    std::vector<std::thread> control_workers;
    control_workers.reserve(config.control_workers);
    for (std::size_t index = 0U; index < config.control_workers; ++index) {
        control_workers.emplace_back([&] {
            while (true) {
                auto connection = control_queue.pop();
                if (!connection.has_value()) { return; }
                const bool requested = handle_control_connection(
                    *connection, state, runtime, custody_owner_dispatcher,
                    stats, registry, action_stats,
                    scheduler_signal, lifecycle, peer_queue, bound_peer_locator,
                    stopping, terminal_handoff);
                ++stats.control_completed;
                if (requested) {
                    stopping.store(true);
                    scheduler_signal.notify();
                }
            }
        });
    }

    std::cout << "{\"format\":\"NATRAV_OVERLAY_RUNTIME_READY_V8\""
              << ",\"node\":" << json_string(config.local_node)
              << ",\"transport\":\"TLS1.3_MTLS_KEY_GENERATION_V1\""
              << ",\"peer_session_protocol\":\"NOS1\""
              << ",\"session_max_operations\":"
              << config.sessions.maximum_operations
              << ",\"identity_generation\":"
              << json_string(config.local_identity_generation)
              << ",\"identity_spki_sha256\":"
              << json_string(spki_sha256_text(config.identity.expected_spki_sha256))
              << ",\"carrier\":"
              << json_string(transport_kind_name(bound_peer_locator.kind))
              << ",\"listen\":"
              << json_string(transport_locator_text(bound_peer_locator))
              << ",\"host\":" << listen_host_json
              << ",\"port\":" << peer_port
              << ",\"control\":" << json_string(config.control_socket.string())
              << ",\"configured_peers\":" << config.peers.size()
              << ",\"authorization_policy_digest\":"
              << json_string(datacube::hex_lower(config.authorization.digest))
              << ",\"authorization_rules\":"
              << config.authorization.rules.size()
              << ",\"local_control_policy_digest\":"
              << json_string(datacube::hex_lower(config.local_control.digest))
              << ",\"service_mode\":"
              << json_string(runtime_service_mode_name(lifecycle.mode()))
              << ",\"interrupted_drain\":"
              << (lifecycle.interrupted_drain() ? "true" : "false")
              << ",\"action_sink\":\"DURABLE_COUNTER_V1\""
              << ",\"pid\":" << ::getpid() << "}" << std::endl;

    try {
        while (!stopping.load()) {
            if (persistent_signal_stop != 0) {
                stopping.store(true);
                scheduler_signal.notify();
                break;
            }
            std::array<pollfd, 2> items{
                pollfd{
                    .fd = lifecycle.peer_admissions_accepted() ?
                        peer_listener->readiness_handle() : -1,
                    .events = POLLIN,
                    .revents = 0,
                },
                pollfd{.fd = control_listener.get(), .events = POLLIN, .revents = 0},
            };
            const int result = ::poll(items.data(), items.size(), 100);
            if (result < 0) {
                if (errno == EINTR) { continue; }
                app_fail("RUNTIME_POLL_FAILED", datacube::errno_detail("poll", errno));
            }
            if (result == 0) { continue; }
            if ((items[0].revents & POLLIN) != 0) {
                accept_transport_ready(
                    *peer_listener, peer_queue,
                    stats.peer_accepted, stats.peer_queued, stats.peer_busy);
            }
            if ((items[1].revents & POLLIN) != 0) {
                accept_control_ready(
                    control_listener.get(), control_queue,
                    stats.control_accepted, stats.control_queued, stats.control_busy);
            }
            if ((items[0].revents & (POLLERR | POLLNVAL)) != 0 ||
                (items[1].revents & (POLLERR | POLLNVAL)) != 0) {
                app_fail("RUNTIME_LISTENER_FAILED", "listener poll error");
            }
        }
    } catch (...) {
        stopping.store(true);
        scheduler_signal.notify();
        peer_queue.close();
        control_queue.close();
        for (auto& thread : control_workers) { thread.join(); }
        registry.stop_and_join();
        action_scheduler.join();
        projection_scheduler.join();
        publication_channel_scheduler.join();
        source_subscription_scheduler.join();
        import_scheduler.join();
        for (auto& thread : peer_workers) { thread.join(); }
        throw;
    }

    stopping.store(true);
    scheduler_signal.notify();
    peer_queue.close();
    control_queue.close();
    for (auto& thread : control_workers) { thread.join(); }
    registry.stop_and_join();
    action_scheduler.join();
    projection_scheduler.join();
    publication_channel_scheduler.join();
    source_subscription_scheduler.join();
    import_scheduler.join();
    for (auto& thread : peer_workers) { thread.join(); }

    // All queued controls (including denied/partial requests), inbound workers,
    // peer schedulers and local schedulers have ceased. Only the coordinator can
    // now append the final lifecycle account and seal/sample this process.
    peer_listener.reset();
    control_listener.reset();
    const auto terminal_delivery = terminal_handoff ?
        finish_terminal_head(*terminal_handoff, state, runtime, stats, scheduler_signal.failed()) : TerminalHeadDelivery{};

    const auto snapshot = state.snapshot();
    const auto final_configuration = runtime.snapshot();
    std::size_t rejected = 0U;
    std::size_t pending = 0U;
    std::size_t acknowledged = 0U;
    std::size_t expired = 0U;
    std::size_t cancelled = 0U;
    std::size_t unresolved = 0U;
    for (const auto& entry : snapshot.outbound) {
        if (entry.receipt.has_value()) { ++acknowledged; }
        else if (entry.delivery.has_value() &&
                 entry.delivery->cancelled_unix_ms.has_value()) { ++cancelled; }
        else if (entry.delivery.has_value() &&
                 entry.delivery->expired_unix_ms.has_value()) { ++expired; }
        else if (active_outbound_rejection(entry).has_value()) { ++rejected; }
        else {
            ++pending;
            const auto* generation = bound_generation(*final_configuration, entry);
            if (generation == nullptr ||
                generation->state == KeyGenerationState::revoked ||
                find_peer(*final_configuration, entry.record.recipient) == nullptr) {
                ++unresolved;
            }
        }
    }
    std::size_t action_pending = 0U;
    std::size_t action_executed = 0U;
    std::size_t action_expired = 0U;
    std::size_t action_cancelled = 0U;
    for (const auto& action : snapshot.actions) {
        if (action.completed_unix_ms.has_value()) { ++action_executed; }
        else if (action.cancelled_unix_ms.has_value()) { ++action_cancelled; }
        else if (action.expired_unix_ms.has_value()) { ++action_expired; }
        else { ++action_pending; }
    }
    std::cout << "{\"format\":\"NATRAV_OVERLAY_RUNTIME_STOP_V8\""
              << ",\"node\":" << json_string(config.local_node)
              << ",\"carrier\":"
              << json_string(transport_kind_name(bound_peer_locator.kind))
              << ",\"listen\":"
              << json_string(transport_locator_text(bound_peer_locator))
              << ",\"port\":" << peer_port
              << ",\"peer_accepted\":" << stats.peer_accepted.load()
              << ",\"peer_completed\":" << stats.peer_completed.load()
              << ",\"control_completed\":" << stats.control_completed.load()
              << ",\"inbound_records\":" << snapshot.inbound.size()
              << ",\"outbox_pending\":" << pending
              << ",\"outbox_unresolved\":" << unresolved
              << ",\"runtime_generation\":" << json_string(final_configuration->runtime_generation)
              << ",\"outbox_rejected\":" << rejected
              << ",\"outbox_acked\":" << acknowledged
              << ",\"outbox_expired\":" << expired
              << ",\"outbox_cancelled\":" << cancelled
              << ",\"authorization_denials\":"
              << snapshot.authorization_denials.size()
              << ",\"action_counter_value\":"
              << snapshot.action_counter_value
              << ",\"actions_pending\":" << action_pending
              << ",\"actions_executed\":" << action_executed
              << ",\"actions_expired\":" << action_expired
              << ",\"actions_cancelled\":" << action_cancelled
              << ",\"journal_bytes\":" << snapshot.journal_bytes
              << ",\"service_mode\":"
              << json_string(runtime_service_mode_name(lifecycle.mode()))
              << ",\"local_control_events\":"
              << snapshot.local_control_events.size()
              << ",\"lifecycle_events\":"
              << snapshot.lifecycle_events.size()
              << ",\"terminal_head_handoff\":" << json_string(terminal_delivery.status)
              << "}" << std::endl;
    return terminal_delivery.failed ? 3 : 0;
}

}  // namespace natrav_overlay
