#pragma once

#include "state_auth.hpp"

#include <cstdint>
#include <filesystem>
#include <functional>
#include <memory>
#include <optional>
#include <string>

namespace natrav_overlay {

struct StateHeadCustodyExpectation final {
    std::optional<std::string> node;
    std::optional<std::string> domain;
    std::optional<std::uint64_t> generation;
    std::optional<std::string> state_head;
    std::optional<datacube::Digest32> record_digest;
};

struct StateHeadCustodyCreateOptions final {
    std::filesystem::path record_file;
    std::string node;
    std::string domain;
    std::uint64_t generation{0U};
    std::string state_head;
};

struct StateHeadCustodyReadOptions final {
    std::filesystem::path record_file;
    StateHeadCustodyExpectation expected;
};

struct StateHeadCustodyAdvanceOptions final {
    std::filesystem::path record_file;
    StateHeadCustodyExpectation expected;
    std::uint64_t new_generation{0U};
    std::string new_state_head;
};

struct StateHeadCustodyPromotionOptions final {
    std::filesystem::path record_file;
    StateHeadCustodyExpectation expected;
    std::uint64_t new_generation{0U};
};

struct StateHeadCustodyPromotionAuditOptions final {
    std::filesystem::path record_file;
    StateHeadCustodyExpectation intended_old;
    std::uint64_t intended_new_generation{0U};
};

enum class StateHeadCustodyPromotionSourceKind : std::uint8_t {
    state_directory = 1U,
    signed_encrypted_backup = 2U,
};

// Exact representation and trust identity of the source authenticated for one
// promotion attempt.  This account is evidence, not authority: every consumer
// must authenticate the explicitly supplied source again and reproduce it.
struct StateHeadCustodyPromotionSourceAccount final {
    StateHeadCustodyPromotionSourceKind kind{
        StateHeadCustodyPromotionSourceKind::state_directory};
    std::filesystem::path canonical_path;
    std::uint64_t representation_bytes{0U};
    datacube::Digest32 representation_digest;
    std::uint64_t authenticated_bytes{0U};
    datacube::Digest32 authenticated_digest;
    datacube::Digest32 logical_state_digest;
    std::optional<std::string> identity_generation;
    std::optional<datacube::Digest32> backup_id;
    std::optional<datacube::Digest32> signer_spki_sha256;
    std::optional<std::string> encryption_key_generation;
    std::optional<datacube::Digest32> encryption_key_id;
};

struct StateHeadCustodyPromotionIntentCreateOptions final {
    std::filesystem::path intent_file;
    std::filesystem::path record_file;
    StateHeadCustodyExpectation expected;
    std::uint64_t new_generation{0U};
};

struct StateHeadCustodyPromotionIntentUseOptions final {
    std::filesystem::path intent_file;
    std::filesystem::path record_file;
};

// The source-specific validator owns every descriptor and lock needed to keep
// the authenticated input stable until the custody exchange.  No caller can
// supply the new selector: it is derived from authentication below.
struct StateHeadCustodyPromotionCandidate final {
    StateAuthentication authentication;
    std::uint64_t journal_bytes{0U};
    std::string relationship;
    StateHeadCustodyPromotionSourceAccount source_account;
    std::string source_json;
    std::function<void()> prepublication_recheck;
    std::shared_ptr<void> source_lifetime;
};

using StateHeadCustodyPromotionValidator =
    std::function<StateHeadCustodyPromotionCandidate(const StateHeadExpectation&)>;

struct StateHeadCustodyPromotionAuditCandidate final {
    StateAuthentication authentication;
    std::uint64_t journal_bytes{0U};
    bool eligible{false};
    std::string relationship;
    std::string ineligibility_code;
    std::string ineligibility_detail;
    StateHeadCustodyPromotionSourceAccount source_account;
    std::string source_json;
    std::function<void()> final_recheck;
    std::shared_ptr<void> source_lifetime;
};

using StateHeadCustodyPromotionAuditValidator =
    std::function<StateHeadCustodyPromotionAuditCandidate(const StateHeadExpectation&)>;

// Strict, read-only adapter from one explicitly named detached custody record
// into the existing process-wide exact NASH1 input condition.  The record is
// never discovered, created, advanced, or treated as permission by this path.
struct StateHeadCustodyConstraintOptions final {
    std::filesystem::path record_file;
    std::string expected_domain;
    std::uint64_t expected_generation{0U};
    datacube::Digest32 expected_record_digest;
};

enum class StateHeadCustodyRecheckPoint {
    authenticated_input,
    successful_command,
    startup_acceptance,
};

[[nodiscard]] std::string create_state_head_custody_record(
    const StateHeadCustodyCreateOptions& options);
[[nodiscard]] std::string read_state_head_custody_record(
    const StateHeadCustodyReadOptions& options);
[[nodiscard]] std::string advance_state_head_custody_record(
    const StateHeadCustodyAdvanceOptions& options);
[[nodiscard]] std::string promote_state_head_custody_record(
    const StateHeadCustodyPromotionOptions& options,
    const StateHeadCustodyPromotionValidator& validator);
[[nodiscard]] std::string audit_state_head_custody_promotion_outcome(
    const StateHeadCustodyPromotionAuditOptions& options,
    const StateHeadCustodyPromotionAuditValidator& validator);
[[nodiscard]] std::string create_state_head_custody_promotion_intent(
    const StateHeadCustodyPromotionIntentCreateOptions& options,
    const StateHeadCustodyPromotionValidator& validator);
[[nodiscard]] std::string promote_state_head_custody_record_with_intent(
    const StateHeadCustodyPromotionIntentUseOptions& options,
    const StateHeadCustodyPromotionValidator& validator);
[[nodiscard]] std::string audit_state_head_custody_promotion_outcome_with_intent(
    const StateHeadCustodyPromotionIntentUseOptions& options,
    const StateHeadCustodyPromotionAuditValidator& validator);

void configure_process_state_head_custody_constraint(
    const StateHeadCustodyConstraintOptions& options);
void recheck_process_state_head_custody_constraint(
    StateHeadCustodyRecheckPoint point);
void release_process_state_head_custody_constraint() noexcept;
[[nodiscard]] bool process_state_head_custody_constraint_active() noexcept;

}  // namespace natrav_overlay
