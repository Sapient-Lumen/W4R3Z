#pragma once
#include "common.hpp"
#include <chrono>
#include <cstdint>
#include <functional>
#include <optional>
#include <string>
#include <vector>
namespace natrav_overlay {
struct RuntimeConfig;
// Stateless, reauthorized observational positions. A selection digest is a
// context check, never a capability, signature, or conditional-mutation token.
struct RuntimeInventory final {
    std::string section{"peers"};
    std::string peer;
    std::string id;
    std::optional<std::uint32_t> uid;
    std::uint32_t offset{0U};
    std::uint32_t limit{16U};
    std::uint32_t maximum_bytes{60'000U};
    std::optional<datacube::Digest32> selection;
};
void validate_runtime_inventory(const RuntimeInventory& request);
[[nodiscard]] datacube::Octets encode_runtime_inventory(const RuntimeInventory& request);
[[nodiscard]] RuntimeInventory decode_runtime_inventory(datacube::OctetView bytes);
[[nodiscard]] std::string runtime_registry_digest(const std::vector<std::string>& registry);
// Invoked only for selected peer/route rows, under a stable configuration lease.
using InventoryTelemetry = std::function<std::string(std::string_view, std::string_view)>;
[[nodiscard]] std::string runtime_inventory_json(const RuntimeConfig& config,
    const std::vector<std::string>& registry, const RuntimeInventory& request,
    std::uint32_t principal_uid, std::string_view process_instance,
    const InventoryTelemetry& telemetry, std::chrono::steady_clock::time_point deadline);
} // namespace natrav_overlay
