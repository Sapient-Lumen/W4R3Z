#pragma once

#include "protocol.hpp"
#include <array>
#include <openssl/evp.h>

namespace natrav_overlay {

// This is a separate offline protocol; it does not replace TLS or add routing.
inline constexpr std::string_view kHandoffCapsuleFeature = "ONE_HOP_AUTHENTICATED_CAPSULE_V1";
inline constexpr std::size_t kHandoffBindingLimit = 512U;
inline constexpr std::size_t kHandoffCapsuleLimit = 68'000U;
inline constexpr std::uint64_t kHandoffLifetimeLimitMs = 2'592'000'000ULL; // 30 days
using HandoffKeyBytes = std::array<std::uint8_t, 32U>;

struct HandoffBinding final {
    std::string node;
    std::string signing_generation;
    std::string handoff_generation;
    HandoffKeyBytes signing_public{};
    HandoffKeyBytes encryption_public{};
    datacube::Octets canonical;
};

struct HandoffOpened final {
    HandoffBinding origin;
    HandoffBinding recipient;
    ApplicationMessage message;
    datacube::Digest32 capsule_id;
    std::uint64_t created_ms{0U};
    std::uint64_t expires_ms{0U};
};

// The caller supplies current configuration trust, never a pin from the capsule.
[[nodiscard]] HandoffBinding decode_handoff_binding(datacube::OctetView bytes);
[[nodiscard]] HandoffBinding make_handoff_binding(std::string_view node,
    std::string_view signing_generation, std::string_view handoff_generation,
    EVP_PKEY* signing_private, const HandoffKeyBytes& encryption_public);
[[nodiscard]] datacube::Digest32 handoff_signing_pin(const HandoffBinding& binding);
void require_handoff_binding(const HandoffBinding& binding, std::string_view node,
    std::string_view signing_generation, const datacube::Digest32& signing_pin);
[[nodiscard]] HandoffKeyBytes handoff_x25519_public(const HandoffKeyBytes& secret);
void generate_handoff_secret(HandoffKeyBytes& secret);

[[nodiscard]] datacube::Octets seal_handoff_capsule(
    const HandoffBinding& origin, EVP_PKEY* signing_private,
    const HandoffBinding& recipient, const ApplicationMessage& message,
    std::uint64_t now_ms, std::uint64_t expires_ms);
[[nodiscard]] HandoffOpened open_handoff_capsule(datacube::OctetView capsule,
    const HandoffBinding& local_binding, const HandoffKeyBytes& local_secret,
    std::string_view expected_origin, std::string_view expected_origin_generation,
    const datacube::Digest32& expected_origin_pin, std::uint64_t now_ms);
// Only bounded metadata parsing; returned identities are UNTRUSTED until open succeeds.
[[nodiscard]] HandoffBinding peek_handoff_origin(datacube::OctetView capsule);
[[nodiscard]] HandoffBinding peek_handoff_recipient(datacube::OctetView capsule);

} // namespace natrav_overlay
