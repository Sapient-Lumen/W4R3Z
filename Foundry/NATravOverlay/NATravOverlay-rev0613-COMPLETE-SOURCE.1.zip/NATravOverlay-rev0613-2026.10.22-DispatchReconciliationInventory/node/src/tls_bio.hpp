#pragma once

#include "socket.hpp"

#include <exception>
#include <string_view>

#include <openssl/bio.h>

namespace natrav_overlay {

// TlsByteChannelBio is the bounded ownership adapter between OpenSSL and the
// carrier-neutral ByteChannel contract. The BIO never owns the backing
// channel. The caller must destroy the SSL/BIO object before the channel.
//
// One operation is active at a time. The active operation supplies the exact
// deadline, the externally visible TLS counters, and a bounded operation
// label. C++ exceptions are retained inside the callback state and are
// rethrown only after control has returned from OpenSSL to C++.
class TlsByteChannelBio final {
public:
    explicit TlsByteChannelBio(ByteChannel& channel);
    ~TlsByteChannelBio();

    TlsByteChannelBio(const TlsByteChannelBio&) = delete;
    TlsByteChannelBio& operator=(const TlsByteChannelBio&) = delete;
    TlsByteChannelBio(TlsByteChannelBio&&) = delete;
    TlsByteChannelBio& operator=(TlsByteChannelBio&&) = delete;

    [[nodiscard]] BIO* get() const noexcept;
    [[nodiscard]] BIO* release() noexcept;

    void begin_operation(
        Deadline deadline,
        IoCounters& exposed_counters,
        std::string_view operation);
    void complete_operation();
    void cancel_operation() noexcept;

private:
    struct CallbackState final {
        ByteChannel* channel{nullptr};
        Deadline deadline{};
        IoCounters* counters{nullptr};
        std::string_view operation;
        std::exception_ptr failure;
    };

    static BIO_METHOD* method();
    static int create_callback(BIO* bio) noexcept;
    static int destroy_callback(BIO* bio) noexcept;
    static int read_callback(BIO* bio, char* data, int length) noexcept;
    static int read_ex_callback(
        BIO* bio,
        char* data,
        std::size_t length,
        std::size_t* read_bytes) noexcept;
    static int write_callback(
        BIO* bio,
        const char* data,
        int length) noexcept;
    static int write_ex_callback(
        BIO* bio,
        const char* data,
        std::size_t length,
        std::size_t* written_bytes) noexcept;
    static long control_callback(
        BIO* bio,
        int command,
        long argument,
        void* pointer) noexcept;
    static long callback_control_callback(
        BIO* bio,
        int command,
        BIO_info_cb* callback) noexcept;

    static CallbackState* callback_state(BIO* bio) noexcept;
    static void retain_current_exception(CallbackState* state) noexcept;
    static bool read_once(
        BIO* bio,
        char* data,
        std::size_t length,
        std::size_t& count) noexcept;
    static bool write_once(
        BIO* bio,
        const char* data,
        std::size_t length,
        std::size_t& count) noexcept;

    void merge_transport_counters() noexcept;
    void clear_operation() noexcept;

    CallbackState callback_;
    BIO* bio_{nullptr};
    IoCounters transport_counters_;
    IoCounters* exposed_counters_{nullptr};
};

}  // namespace natrav_overlay
