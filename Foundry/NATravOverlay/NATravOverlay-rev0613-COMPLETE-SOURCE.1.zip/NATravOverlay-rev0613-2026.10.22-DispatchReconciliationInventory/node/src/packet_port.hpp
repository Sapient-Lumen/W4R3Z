#pragma once

#include "finite_packet_link.hpp"
#include "transport.hpp"

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <string_view>

namespace natrav_overlay {

inline constexpr char kOwnedCompleteDatagramPacketPortMarker[] =
    "OWNED_COMPLETE_DATAGRAM_PACKET_PORT_V1";
inline constexpr char kFreshConnectorBoundListenerPacketEpochMarker[] =
    "FRESH_CONNECTOR_BOUND_LISTENER_PACKET_EPOCH_V1";
[[nodiscard]] int owned_complete_datagram_packet_port_revision_abi() noexcept;

// OwnedCompleteDatagramPacketPort is the narrow carrier boundary required by
// FinitePacketStream. Implementations own one complete-datagram endpoint and
// retain their carrier-specific addressing, readiness, timing, and failure
// behavior. Peer identity and authority remain above this boundary.
class OwnedCompleteDatagramPacketPort : public natrav::packet_link::PacketPort {
public:
    ~OwnedCompleteDatagramPacketPort() override = default;
    OwnedCompleteDatagramPacketPort(const OwnedCompleteDatagramPacketPort&) = delete;
    OwnedCompleteDatagramPacketPort& operator=(
        const OwnedCompleteDatagramPacketPort&) = delete;

    [[nodiscard]] virtual TransportKind transport_kind() const noexcept = 0;
    [[nodiscard]] virtual std::size_t mtu() const noexcept = 0;

    // Wait until carrier progress is possible or the scheduled packet clock
    // must advance. Both arguments are absolute steady-clock deadlines. The
    // implementation must never wait beyond operation_deadline.
    // Synchronous ports must clamp EVERY packet RPC performed by a finite
    // pump to this outer byte-operation deadline. Socket ports are nonblocking.
    virtual void set_operation_deadline(Deadline) noexcept {}
    virtual void wait_for_progress(
        Deadline wake_deadline,
        Deadline operation_deadline,
        IoCounters& counters,
        std::string_view operation) = 0;

protected:
    OwnedCompleteDatagramPacketPort() = default;
};

struct PacketPortOrderedStreamOptions final {
    natrav::packet_link::Limits limits{};
    std::uint64_t stream_id{0U};
    std::uint32_t epoch{0U};
    std::chrono::milliseconds tick_interval{10};
    std::chrono::milliseconds shutdown_budget{2'000};
    std::string invalid_stream_code{"PACKET_PORT_STREAM_INVALID"};
    std::string logical_clock_invalid_code{"PACKET_PORT_LOGICAL_CLOCK_INVALID"};
    std::string logical_clock_exhausted_code{"PACKET_PORT_LOGICAL_CLOCK_EXHAUSTED"};
    std::string shutdown_operation{"packet-port shutdown"};
    // Opt-in for blocking process RPCs. Legacy private fixture ports retain
    // their per-request timeout semantics; configured adapters MUST enable it.
    bool propagate_operation_deadline{false};
    // A connector supplies a fresh nonzero epoch. A listener may instead use
    // epoch zero with this flag and bind exactly once to the first valid frame
    // for its configured stream identifier.
    bool bind_epoch_from_first_packet{false};
};

// Takes exclusive ownership of the complete-datagram port and reconstructs an
// OrderedByteStream through the finite packet service. Packet framing,
// retransmission, duplicate suppression, expiry, fragmentation, reassembly,
// and ordered delivery remain above the concrete carrier.
[[nodiscard]] std::unique_ptr<OrderedByteStream>
make_packet_port_ordered_byte_stream(
    std::unique_ptr<OwnedCompleteDatagramPacketPort> port,
    PacketPortOrderedStreamOptions options);

}  // namespace natrav_overlay
