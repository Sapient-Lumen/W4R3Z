#include "local_author.hpp"
#include "config.hpp"
#include "journal.hpp"

#include <algorithm>
#include <limits>
#include <mutex>
#include <set>
#include <utility>
#include <chrono>
#include <cstdlib>
#include <thread>
#include <tuple>

namespace natrav_overlay {
namespace {
void text(datacube::Octets& out, std::string_view value) {
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}
datacube::Digest32 read_digest(datacube::Reader& reader) {
    datacube::Digest32 value{};
    const auto bytes = reader.read_exact(value.octets.size(), "local authorship digest");
    std::copy(bytes.begin(), bytes.end(), value.octets.begin());
    return value;
}
datacube::Digest32 grant_digest(std::uint32_t uid, std::string_view scope) {
    datacube::Octets bytes;
    datacube::append_text(bytes, "NATRAV_OVERLAY_LOCAL_AUTHOR_RULE_V1");
    datacube::append_u8(bytes, 0U);
    datacube::append_be32(bytes, uid);
    text(bytes, scope);
    return datacube::sha256(bytes);
}
void test_boundary(const char* name) {
    // Explicit disposable-test stop only; never changes normal durability.
    if (const auto* value = std::getenv(name)) {
        const auto ms = parse_u64(value, "local author test pause", 1U, 30'000U);
        std::this_thread::sleep_for(std::chrono::milliseconds(ms));
    }
}
} // namespace

LocalAuthorPolicy make_local_author_policy(const std::vector<std::string>& values,
    const LocalControlPolicy& control, bool enabled) {
    LocalAuthorPolicy policy;
    std::set<std::uint32_t> authors;
    if (!enabled && (!values.empty() || std::any_of(control.grants.begin(), control.grants.end(),
        [](const auto& grant) {
            return (grant.permissions & local_control_permission(LocalControlClass::evidence_author)) != 0U;
        }))) {
        app_fail("CONFIG_VERSION_REJECTED", "EVIDENCE_AUTHOR and evidence_author require V14");
    }
    if (values.size() > 256U) {
        app_fail("CONFIG_AUTHOR_LIMIT", "at most 256 exact UID/scope authoring rules");
    }
    for (const auto& value : values) {
        const auto comma = value.find(',');
        if (comma == std::string::npos || value.find(',', comma + 1U) != std::string::npos) {
            app_fail("CONFIG_AUTHOR_INVALID", "evidence_author requires exact UID,scope");
        }
        const auto uid_text = value.substr(0U, comma);
        const auto uid = static_cast<std::uint32_t>(parse_u64(uid_text, "author UID", 0U,
            std::numeric_limits<std::uint32_t>::max()));
        const auto scope = value.substr(comma + 1U);
        if (std::to_string(uid) != uid_text || !valid_scope(scope) || scope.starts_with("actions/")) {
            app_fail("CONFIG_AUTHOR_INVALID", "canonical numeric UID and exact non-action scope required");
        }
        if (!local_control_allows(control, uid, LocalControlClass::evidence_author)) {
            app_fail("CONFIG_AUTHOR_CLASS_REQUIRED", "authoring domain needs explicit EVIDENCE_AUTHOR");
        }
        policy.grants.push_back(LocalAuthorGrant{.uid = uid, .scope = scope,
            .digest = grant_digest(uid, scope)});
        authors.insert(uid);
    }
    std::sort(policy.grants.begin(), policy.grants.end(), [](const auto& a, const auto& b) {
        return std::tie(a.uid, a.scope) < std::tie(b.uid, b.scope);
    });
    for (std::size_t i = 1U; i < policy.grants.size(); ++i) {
        if (policy.grants[i].uid == policy.grants[i - 1U].uid &&
            policy.grants[i].scope == policy.grants[i - 1U].scope) {
            app_fail("CONFIG_AUTHOR_DUPLICATE", "duplicate exact UID/scope grant");
        }
    }
    for (const auto& grant : control.grants) {
        if (local_control_allows(control, grant.uid, LocalControlClass::evidence_author) &&
            !authors.contains(grant.uid)) {
            app_fail("CONFIG_AUTHOR_DOMAIN_REQUIRED", "authoring principal requires an exact scope grant");
        }
    }
    datacube::Octets canonical;
    datacube::append_text(canonical, "NATRAV_OVERLAY_LOCAL_AUTHOR_POLICY_V1");
    datacube::append_u8(canonical, 0U);
    datacube::append_be32(canonical, static_cast<std::uint32_t>(policy.grants.size()));
    for (const auto& grant : policy.grants) { datacube::append_octets(canonical, grant.digest.octets); }
    policy.digest = datacube::sha256(canonical);
    return policy;
}

const LocalAuthorGrant* local_author_grant(const LocalAuthorPolicy& policy,
    std::uint32_t uid, std::string_view scope) {
    const auto it = std::find_if(policy.grants.begin(), policy.grants.end(), [&](const auto& rule) {
        return rule.uid == uid && rule.scope == scope;
    });
    return it == policy.grants.end() ? nullptr : &*it;
}

datacube::Octets encode_local_authorship(const LocalAuthorship& value) {
    datacube::Octets out;
    datacube::append_text(out, "NLA1");
    datacube::append_be32(out, value.uid);
    datacube::append_be32(out, value.gid);
    datacube::append_be32(out, value.pid);
    datacube::append_be64(out, value.authored_unix_ms);
    datacube::append_be64(out, value.configuration_event);
    datacube::append_octets(out, value.configuration_digest.octets);
    datacube::append_octets(out, value.policy_digest.octets);
    datacube::append_octets(out, value.rule_digest.octets);
    datacube::append_octets(out, value.request_digest.octets);
    return out;
}
LocalAuthorship decode_local_authorship(datacube::Reader& reader) {
    if (datacube::octets_text(reader.read_exact(4U, "authorship magic"), "authorship magic", true) != "NLA1") {
        app_fail("JOURNAL_CORRUPT", "unknown local authorship format");
    }
    LocalAuthorship out;
    out.uid = reader.read_be32("author UID");
    out.gid = reader.read_be32("author GID");
    out.pid = reader.read_be32("author PID");
    out.authored_unix_ms = reader.read_be64("author time");
    out.configuration_event = reader.read_be64("author configuration event");
    out.configuration_digest = read_digest(reader);
    out.policy_digest = read_digest(reader);
    out.rule_digest = read_digest(reader);
    out.request_digest = read_digest(reader);
    return out;
}
datacube::Digest32 local_author_request_digest(const EvidenceRecord& record) {
    datacube::Octets bytes;
    datacube::append_text(bytes, "NATRAV_OVERLAY_LOCAL_AUTHOR_REQUEST_V1");
    datacube::append_u8(bytes, 0U);
    datacube::append_octets(bytes, encode_application_message(record));
    return datacube::sha256(bytes);
}
std::string local_authorship_json(const LocalAuthorship& value) {
    return "{\"format\":\"NATRAV_OVERLAY_LOCAL_AUTHORSHIP_V1\",\"origin\":\"LOCAL_AUTHORED\""
        ",\"uid\":" + std::to_string(value.uid) + ",\"gid\":" + std::to_string(value.gid) +
        ",\"pid\":" + std::to_string(value.pid) + ",\"authored_unix_ms\":" +
        std::to_string(value.authored_unix_ms) + ",\"configuration_event\":" +
        std::to_string(value.configuration_event) + ",\"configuration_digest\":" +
        json_string(datacube::hex_lower(value.configuration_digest)) + ",\"policy_digest\":" +
        json_string(datacube::hex_lower(value.policy_digest)) + ",\"rule_digest\":" +
        json_string(datacube::hex_lower(value.rule_digest)) + ",\"request_digest\":" +
        json_string(datacube::hex_lower(value.request_digest)) + "}";
}
std::string local_author_policy_json(const LocalAuthorPolicy& policy) {
    std::string out = "{\"format\":\"NATRAV_OVERLAY_LOCAL_AUTHOR_POLICY_V1\",\"digest\":" +
        json_string(datacube::hex_lower(policy.digest)) + ",\"grants\":[";
    for (std::size_t i = 0U; i < policy.grants.size(); ++i) {
        if (i != 0U) { out += ','; }
        out += "{\"uid\":" + std::to_string(policy.grants[i].uid) + ",\"scope\":" +
            json_string(policy.grants[i].scope) + ",\"digest\":" +
            json_string(datacube::hex_lower(policy.grants[i].digest)) + "}";
    }
    return out + "]}";
}

void NodeState::validate_local_authorship_locked(const EvidenceRecord& record,
    const LocalAuthorship& account, bool active_policy) const {
    const auto event = account.configuration_event;
    if (event == 0U || event > configuration_events_.size() || account.pid == 0U ||
        account.authored_unix_ms == 0U || record.issuer != node_id_ || record.recipient != node_id_ ||
        record.scope.starts_with("actions/") ||
        (active_policy && event != active_configuration_event(configuration_events_))) {
        app_fail("JOURNAL_CORRUPT", "invalid local authorship identity or policy event");
    }
    const auto& accepted = configuration_events_[static_cast<std::size_t>(event - 1U)];
    if (accepted.kind == "REJECTED" || accepted.digest != account.configuration_digest) {
        app_fail("JOURNAL_CORRUPT", "local authorship requires its accepted configuration");
    }
    const auto config = parse_runtime_config(accepted.canonical, "/durable-configuration",
        IdentityFileValidation::deferred);
    const auto* grant = local_author_grant(config.evidence_author, account.uid, record.scope);
    if (config.format_version < 14U || config.local_node != node_id_ || grant == nullptr ||
        !local_control_allows(config.local_control, account.uid, LocalControlClass::evidence_author) ||
        account.rule_digest != grant->digest || account.policy_digest != config.evidence_author.digest ||
        account.request_digest != local_author_request_digest(record)) {
        app_fail("JOURNAL_CORRUPT", "local authorship is not justified by its exact UID/scope policy");
    }
    if (record.corrects) {
        const auto it = inbound_index_.find(operation_id_text(*record.corrects));
        if (it == inbound_index_.end() || !inbound_[it->second].local_authorship ||
            inbound_[it->second].local_authorship->uid != account.uid) {
            app_fail("JOURNAL_CORRUPT", "local correction has no same-owner authored predecessor");
        }
    }
}

std::string NodeState::author_evidence(const EvidenceRecord& record,
    const RuntimeConfig& config, std::uint32_t uid, std::uint32_t gid, std::uint32_t pid,
    std::uint64_t configuration_event, std::uint64_t unix_ms) {
    validate_evidence_record(record);
    if (config.format_version < 14U) {
        app_fail("LOCAL_AUTHOR_POLICY_VERSION_REQUIRED", "local authorship requires V14");
    }
    const auto* grant = local_author_grant(config.evidence_author, uid, record.scope);
    if (!local_control_allows(config.local_control, uid, LocalControlClass::evidence_author) || !grant) {
        app_fail("LOCAL_AUTHOR_SCOPE_DENIED", "the connected UID cannot author this exact scope");
    }
    if (record.issuer != node_id_ || record.recipient != node_id_ || record.scope.starts_with("actions/")) {
        app_fail("LOCAL_AUTHOR_IDENTITY_REJECTED", "local originals and corrections must name this node as issuer and recipient and cannot invoke actions");
    }
    std::lock_guard<std::mutex> lock(mutex_);
    const auto digest = evidence_record_digest(record);
    const auto key = operation_id_text(record.operation_id);
    const auto result = [&](std::string_view disposition, const LocalAuthorship& account) {
        return "{\"format\":\"NATRAV_OVERLAY_LOCAL_AUTHOR_RESULT_V1\",\"disposition\":" +
            json_string(disposition) + ",\"operation_id\":" + json_string(key) +
            ",\"record_digest\":" + json_string(datacube::hex_lower(digest)) +
            ",\"network_used\":false,\"local_authorship\":" + local_authorship_json(account) + "}";
    };
    const auto found = inbound_index_.find(key);
    if (found != inbound_index_.end()) {
        const auto& existing = inbound_[found->second];
        if (!existing.local_authorship || existing.local_authorship->uid != uid ||
            existing.record_digest != digest) {
            app_fail("LOCAL_AUTHOR_OPERATION_CONFLICT", "operation is unavailable for this author and content");
        }
        return result("ALREADY_AUTHORED", *existing.local_authorship);
    }
    if (inbound_.size() >= 1'000'000U) {
        app_fail("LOCAL_AUTHOR_CAPACITY", "retained evidence admission ceiling reached");
    }
    if (record.corrects) {
        const auto parent_key = operation_id_text(*record.corrects);
        const auto parent = inbound_index_.find(parent_key);
        if (parent == inbound_index_.end() || !inbound_[parent->second].local_authorship ||
            inbound_[parent->second].local_authorship->uid != uid ||
            inbound_[parent->second].record.scope != record.scope) {
            app_fail("LOCAL_AUTHOR_PARENT_REJECTED", "predecessor must be same-owner authored evidence in the same scope");
        }
        if (correction_child_.contains(parent_key)) {
            app_fail("LOCAL_AUTHOR_BRANCH_REJECTED", "predecessor already has a correction");
        }
    }
    const LocalAuthorship account{.uid = uid, .gid = gid, .pid = pid,
        .authored_unix_ms = unix_ms, .configuration_event = configuration_event,
        .configuration_digest = runtime_configuration_digest(canonical_runtime_config(config)),
        .policy_digest = config.evidence_author.digest, .rule_digest = grant->digest,
        .request_digest = local_author_request_digest(record)};
    validate_local_authorship_locked(record, account, true);
    auto bytes = encode_local_authorship(account);
    datacube::append_octets(bytes, encode_application_message(record));
    test_boundary("NATRAV_OVERLAY_TEST_LOCAL_AUTHOR_BEFORE_COMMIT_MS");
    append_entry(EntryKind::local_authored, bytes);
    test_boundary("NATRAV_OVERLAY_TEST_LOCAL_AUTHOR_AFTER_COMMIT_MS");
    return result("AUTHORED", account);
}
} // namespace natrav_overlay
