#include "subscription_inventory.hpp"
#include "journal.hpp"
#include "config.hpp"
#include "submission_work.hpp"

#include <algorithm>
#include <chrono>
#include <map>
#include <vector>

namespace natrav_overlay {
namespace {
using Digest = datacube::Digest32;
using Bytes = datacube::Octets;
constexpr std::size_t kPrincipalReserve = 384U;
void require(bool condition, std::string_view code, std::string_view detail) {
    if (!condition) app_fail(code, detail);
}
void text(Bytes& b, std::string_view s) {
    datacube::append_be16(b, static_cast<std::uint16_t>(s.size())); datacube::append_text(b, s);
}
std::string text(datacube::Reader& r, std::size_t maximum) {
    const auto n = r.read_be16("text length");
    require(n <= maximum, "SUBSCRIPTION_INVENTORY_INVALID", "text exceeds bound");
    return datacube::octets_text(r.read_exact(n, "text"), "text", true);
}
void digest(Bytes& b, const Digest& d) { datacube::append_octets(b, d.octets); }
Digest digest(datacube::Reader& r) {
    Digest d{}; const auto b = r.read_exact(32U, "digest");
    std::copy(b.begin(), b.end(), d.octets.begin()); return d;
}
void optional_digest(Bytes& b, const std::optional<Digest>& d) {
    datacube::append_u8(b, d ? 1U : 0U); if (d) digest(b, *d);
}
std::optional<Digest> optional_digest(datacube::Reader& r) {
    const auto flag = r.read_u8("optional");
    require(flag <= 1U, "SUBSCRIPTION_INVENTORY_INVALID", "invalid optional marker");
    return flag ? std::optional<Digest>{digest(r)} : std::nullopt;
}
void optional_uid(Bytes& b, std::optional<std::uint32_t> uid) {
    datacube::append_u8(b, uid ? 1U : 0U); if (uid) datacube::append_be32(b, *uid);
}
std::string hex(const Digest& d) { return json_string(datacube::hex_lower(d)); }
std::string hex(const std::optional<Digest>& d) { return d ? hex(*d) : "null"; }
std::string number(const std::optional<std::uint64_t>& n) { return n ? std::to_string(*n) : "null"; }
std::string str(const std::optional<std::string>& s) { return s ? json_string(*s) : "null"; }
std::string lower(std::string_view s) {
    std::string out(s);
    for (auto& c : out) if (c >= 'A' && c <= 'Z') c = static_cast<char>(c - 'A' + 'a');
    return out;
}
std::string_view lease_state(const SourceSubscription& s) {
    if (s.grant.lease_generation.empty()) return "UNLEASED";
    return s.termination ? std::string_view(s.termination->kind) : "OPEN";
}
std::string_view schedule_state(const SourceSubscription& s) {
    return s.automatic_grants.empty() ? "NONE" : std::string_view(s.automatic_grants.back().state);
}
bool matches(const SourceSubscription& s, const SubscriptionInventory& q, std::string_view outcome) {
    return (q.lifecycle == "all" || q.lifecycle == (s.retired ? "retired" : "active")) &&
        (q.lease == "all" || q.lease == lower(lease_state(s))) &&
        (q.schedule == "all" || q.schedule == lower(schedule_state(s))) &&
        (q.outcome == "all" || q.outcome == lower(outcome));
}
std::string head_json(const SourceSubscription& s, const StoredOutbound* o) {
    if (s.deliveries.empty()) return "null";
    const auto& h = s.deliveries.back();
    require(o && o->record.operation_id == h.operation && o->record_digest == h.record_digest &&
        o->record.recipient == s.grant.peer && o->record.scope == s.grant.scope,
        "STATE_INDEX_CORRUPT", "source head does not match durable outbox record");
    std::string out = "{\"source_operation_id\":" + hex(h.source_operation) +
        ",\"operation_id\":" + hex(h.operation) + ",\"record_digest\":" + hex(h.record_digest) +
        ",\"source_payload_bytes\":" + std::to_string(h.payload_bytes) +
        ",\"configuration_event\":" + std::to_string(h.configuration_event) +
        ",\"issued_unix_ms\":" + std::to_string(h.unix_ms) +
        ",\"issue_executor_pid\":" + std::to_string(h.pid) +
        ",\"issue_automatic_generation\":" + std::to_string(h.issue_automatic_generation) +
        ",\"acknowledged_by_subscription\":" + (s.acknowledged == s.deliveries.size() ? "true" : "false") +
        ",\"acknowledged_configuration_event\":" + std::to_string(h.acknowledged_event) +
        ",\"acknowledged_unix_ms\":" + std::to_string(h.acknowledged_unix_ms) +
        ",\"acknowledge_automatic_generation\":" + std::to_string(h.acknowledge_automatic_generation) +
        ",\"outbound_status\":" + json_string(outbound_status_name(*o)) + ",\"delivery\":";
    if (o->delivery) {
        const auto& d = *o->delivery;
        out += "{\"recipient_generation\":" + str(d.policy.peer_generation) +
            ",\"recipient_spki_sha256\":" + hex(d.policy.peer_spki_sha256) +
            ",\"attempts\":" + std::to_string(d.attempts) +
            ",\"last_attempt_unix_ms\":" + number(d.last_attempt_unix_ms) +
            ",\"next_attempt_unix_ms\":" + std::to_string(d.next_attempt_unix_ms) +
            ",\"expires_unix_ms\":" + std::to_string(d.policy.expires_unix_ms) +
            ",\"last_error_code\":" + json_string(d.last_error_code) +
            ",\"cancelled_unix_ms\":" + number(d.cancelled_unix_ms) +
            ",\"expired_unix_ms\":" + number(d.expired_unix_ms) +
            ",\"transition_count\":" + std::to_string(d.transitions.size()) + "}";
    } else out += "null";
    out += ",\"receipt\":";
    if (o->receipt) {
        const auto& receipt = *o->receipt;
        out += "{\"operation_id\":" + hex(receipt.operation_id) +
            ",\"recipient\":" + json_string(receipt.recipient) +
            ",\"recorder\":" + json_string(receipt.recorder) +
            ",\"sequence\":" + std::to_string(receipt.sequence) +
            ",\"record_digest\":" + hex(receipt.record_digest) + "}";
    } else out += "null";
    return out + "}";
}
std::string summary(const SourceSubscription& s, const RuntimeConfig& cfg, const StoredOutbound* o,
    const SourceSubscription* successor, std::size_t ordinal) {
    // Read scalar summaries only: no source record, full-state digest, mapping
    // reconstruction, encoding of a subscription, or eligibility side effects.
    const auto* rule = source_disclosure_grant(cfg.source_disclosure, s.grant.id);
    const auto* key = find_peer_generation(cfg, s.grant.peer, s.grant.generation);
    const auto base = s.succession ? s.succession->inherited_acknowledged : 0U;
    require(s.acknowledged <= s.deliveries.size() && s.deliveries.size() <= s.grant.maximum_records &&
        s.used_payload_bytes <= s.grant.maximum_payload_bytes,
        "STATE_INDEX_CORRUPT", "invalid source subscription counters");
    std::string out = "{\"ordinal\":" + std::to_string(ordinal) + ",\"grant\":" + json_string(s.grant.id) +
        ",\"manager_uid\":" + std::to_string(s.grant.uid) + ",\"instance\":" + hex(s.instance) +
        ",\"revision\":" + std::to_string(s.revision) + ",\"lifecycle\":" + json_string(s.retired ? "RETIRED" : "ACTIVE") +
        ",\"source_author_uid\":" + std::to_string(s.grant.author_uid) +
        ",\"subscriber\":" + json_string(s.grant.peer) + ",\"subscriber_generation\":" + json_string(s.grant.generation) +
        ",\"subscriber_spki_sha256\":" + hex(s.peer_spki) + ",\"scope\":" + json_string(s.grant.scope) +
        ",\"grant_digest\":" + hex(s.grant.digest) +
        ",\"policy_current\":" + (rule && *rule == s.grant ? "true" : "false") +
        ",\"subscriber_generation_state\":" + (key ? json_string(key_generation_state_name(key->state)) : "null") +
        ",\"subscriber_pin_matches\":" + (key && key->spki_sha256 == s.peer_spki ? "true" : "false") +
        ",\"maximum_records\":" + std::to_string(s.grant.maximum_records) +
        ",\"issued\":" + std::to_string(s.deliveries.size()) +
        ",\"acknowledged\":" + std::to_string(s.acknowledged) +
        ",\"inherited_acknowledged\":" + std::to_string(base) +
        ",\"acknowledged_source_position\":" + std::to_string(base + s.acknowledged) +
        ",\"remaining_records\":" + std::to_string(s.grant.maximum_records - s.deliveries.size()) +
        ",\"maximum_payload_bytes\":" + std::to_string(s.grant.maximum_payload_bytes) +
        ",\"used_payload_bytes\":" + std::to_string(s.used_payload_bytes) +
        ",\"remaining_payload_bytes\":" + std::to_string(s.grant.maximum_payload_bytes - s.used_payload_bytes) +
        ",\"retained_unacknowledged\":" + (s.retained_unacknowledged ? "true" : "false") +
        ",\"lease_state\":" + json_string(lease_state(s)) +
        ",\"lease_generation\":" + json_string(s.grant.lease_generation) +
        ",\"lease_started_unix_ms\":" + std::to_string(s.lease_started_unix_ms) +
        ",\"lease_expires_unix_ms\":" + std::to_string(s.lease_expires_unix_ms) +
        ",\"withdrawal_policy\":" + (s.grant.lease_generation.empty() ? "null" : json_string(source_pending_disposition_name(s.grant.withdrawal_pending))) +
        ",\"created_configuration_event\":" + std::to_string(s.created_event) +
        ",\"created_unix_ms\":" + std::to_string(s.created_unix_ms) +
        ",\"creation_actor_kind\":" + json_string(s.remote_admission ? "AUTHENTICATED_SUBSCRIBER" : "LOCAL_SOURCE_MANAGER") +
        ",\"creation_manager_pid\":" + (s.remote_admission ? "null" : std::to_string(s.created_pid)) +
        ",\"configuration_event\":" + std::to_string(s.configuration_event) +
        ",\"unix_ms\":" + std::to_string(s.unix_ms) +
        ",\"last_transition\":" + json_string(s.transition) + ",\"remote_admission\":";
    if (s.remote_admission) {
        const auto& r = *s.remote_admission;
        out += "{\"request_id\":" + hex(r.request_id) + ",\"peer\":" + json_string(r.peer) +
            ",\"generation\":" + json_string(r.generation) + ",\"spki_sha256\":" + hex(r.peer_spki) +
            ",\"configuration_event\":" + std::to_string(r.configuration_event) +
            ",\"unix_ms\":" + std::to_string(r.unix_ms) + ",\"request_digest\":" + hex(r.request_digest) + "}";
    } else out += "null";
    out += ",\"termination\":";
    if (s.termination) {
        const auto& t = *s.termination;
        out += "{\"kind\":" + json_string(t.kind) + ",\"lease_generation\":" + json_string(t.lease_generation) +
            ",\"configuration_event\":" + std::to_string(t.configuration_event) +
            ",\"unix_ms\":" + std::to_string(t.unix_ms) + ",\"pending_disposition\":" + json_string(t.pending_disposition) +
            ",\"cancelled_operation\":" + hex(t.cancelled_operation) + ",\"actor_peer\":" + json_string(t.actor_peer) +
            ",\"actor_generation\":" + json_string(t.actor_generation) +
            ",\"actor_spki_sha256\":" + (digest_is_zero(t.actor_spki) ? "null" : hex(t.actor_spki)) +
            ",\"request_id\":" + hex(t.request_id) + "}";
    } else out += "null";
    out += ",\"succession\":";
    if (s.succession) {
        const auto& x = *s.succession;
        out += "{\"predecessor_grant\":" + json_string(x.predecessor_grant) +
            ",\"predecessor_lease\":" + json_string(x.predecessor_lease) +
            ",\"predecessor_instance\":" + hex(x.predecessor_instance) +
            ",\"predecessor_revision\":" + std::to_string(x.predecessor_revision) +
            ",\"predecessor_state_digest\":" + hex(x.predecessor_state_digest) +
            ",\"inherited_acknowledged\":" + std::to_string(x.inherited_acknowledged) +
            ",\"mapping_digest\":" + hex(x.mapping_digest) + "}";
    } else out += "null";
    out += ",\"adopted_by\":";
    if (successor) out += "{\"grant\":" + json_string(successor->grant.id) + ",\"instance\":" + hex(successor->instance) + "}";
    else out += "null";
    out += ",\"reconciliation\":";
    if (s.reconciliation) {
        const auto& x = *s.reconciliation;
        out += "{\"preceding_revision\":" + std::to_string(x.preceding_revision) +
            ",\"preceding_state_digest\":" + hex(x.preceding_state_digest) +
            ",\"terminal_digest\":" + hex(x.terminal_digest) +
            ",\"source_operation\":" + hex(x.source_operation) +
            ",\"delivery_operation\":" + hex(x.delivery_operation) +
            ",\"receipt_digest\":" + hex(x.receipt_digest) + "}";
    } else out += "null";
    out += ",\"head\":" + head_json(s, o) +
        ",\"schedule_revision\":" + std::to_string(s.automatic_schedule_revision) +
        ",\"retained_grants\":" + std::to_string(s.automatic_grants.size()) +
        ",\"schedule_state\":" + json_string(schedule_state(s)) + ",\"automatic_grant\":";
    if (!s.automatic_grants.empty()) {
        const auto& g = s.automatic_grants.back();
        require(g.steps <= g.maximum_steps, "STATE_INDEX_CORRUPT", "invalid automatic step account");
        out += "{\"generation\":" + std::to_string(g.generation) +
            ",\"state\":" + json_string(g.state) + ",\"maximum_steps\":" + std::to_string(g.maximum_steps) +
            ",\"steps\":" + std::to_string(g.steps) + ",\"remaining_steps\":" + std::to_string(g.maximum_steps - g.steps) +
            ",\"minimum_interval_ms\":" + std::to_string(g.minimum_interval_ms) +
            ",\"error_code\":" + json_string(g.error) +
            ",\"configuration_event\":" + std::to_string(g.configuration_event) +
            ",\"actor_uid\":" + std::to_string(g.actor_uid) + ",\"pid\":" + std::to_string(g.pid) +
            ",\"last_step_event\":" + std::to_string(g.last_step_event) +
            ",\"last_step_unix_ms\":" + std::to_string(g.last_step_unix_ms) +
            ",\"last_executor_uid\":" + std::to_string(g.last_executor_uid) +
            ",\"last_executor_pid\":" + std::to_string(g.last_executor_pid) +
            ",\"ended_event\":" + std::to_string(g.ended_event) +
            ",\"ended_unix_ms\":" + std::to_string(g.ended_unix_ms) + "}";
    } else out += "null";
    return out + "}";
}
} // namespace

void validate_subscription_inventory(const SubscriptionInventory& q) {
    require((q.lifecycle == "all" || q.lifecycle == "active" || q.lifecycle == "retired") &&
        (q.lease == "all" || q.lease == "unleased" || q.lease == "open" || q.lease == "withdrawn" || q.lease == "expired") &&
        (q.schedule == "all" || q.schedule == "none" || q.schedule == "enabled" || q.schedule == "paused" || q.schedule == "blocked" || q.schedule == "exhausted") &&
        (q.outcome == "all" || q.outcome == "none" || q.outcome == "pending" || q.outcome == "acked" || q.outcome == "rejected" || q.outcome == "cancelled" || q.outcome == "expired") &&
        (q.grant.empty() || valid_generation_id(q.grant)) && (q.recipient.empty() || valid_node_id(q.recipient)) &&
        (q.scope.empty() || valid_scope(q.scope)) && (!q.instance || !digest_is_zero(*q.instance)) &&
        q.limit >= 1U && q.limit <= 16U && q.maximum_bytes >= 2048U && q.maximum_bytes <= 60000U &&
        q.offset <= kSourceSubscriptionUidLimit && (!q.selection || !digest_is_zero(*q.selection)),
        "SUBSCRIPTION_INVENTORY_INVALID", "invalid exact filter or page bound");
    require(q.offset == 0U || q.selection, "SUBSCRIPTION_INVENTORY_SELECTION_REQUIRED", "continuation requires selection digest");
}
Bytes encode_subscription_inventory(const SubscriptionInventory& q) {
    validate_subscription_inventory(q); Bytes b; datacube::append_text(b, "SIN1");
    text(b, q.lifecycle); text(b, q.lease); text(b, q.schedule); text(b, q.outcome);
    text(b, q.grant); text(b, q.recipient); text(b, q.scope); optional_uid(b, q.author_uid); optional_digest(b, q.instance);
    datacube::append_be32(b, q.offset); datacube::append_be32(b, q.limit); datacube::append_be32(b, q.maximum_bytes);
    optional_digest(b, q.selection); return b;
}
SubscriptionInventory decode_subscription_inventory(datacube::OctetView b) {
    try {
        datacube::Reader r(b, "subscription inventory");
        require(datacube::octets_text(r.read_exact(4U, "magic"), "magic", true) == "SIN1", "SUBSCRIPTION_INVENTORY_INVALID", "unknown version");
        SubscriptionInventory q;
        q.lifecycle = text(r, 16U); q.lease = text(r, 16U); q.schedule = text(r, 16U); q.outcome = text(r, 16U);
        q.grant = text(r, 64U); q.recipient = text(r, 64U); q.scope = text(r, 128U);
        const auto flag = r.read_u8("optional UID");
        require(flag <= 1U, "SUBSCRIPTION_INVENTORY_INVALID", "invalid UID marker");
        if (flag) q.author_uid = r.read_be32("author UID");
        q.instance = optional_digest(r); q.offset = r.read_be32("offset"); q.limit = r.read_be32("limit");
        q.maximum_bytes = r.read_be32("max bytes"); q.selection = optional_digest(r);
        r.require_eof("subscription inventory"); validate_subscription_inventory(q); return q;
    } catch (const datacube::Failure&) { app_fail("SUBSCRIPTION_INVENTORY_INVALID", "malformed or truncated request"); }
}
std::string NodeState::subscription_inventory(const SubscriptionInventory& q, const RuntimeConfig& cfg,
    std::uint32_t uid, std::chrono::steady_clock::time_point deadline) const {
    validate_subscription_inventory(q);
    require(cfg.format_version >= 15U, "SOURCE_DISCLOSURE_POLICY_VERSION_REQUIRED", "inventory requires V15 or newer");
    require(local_control_allows(cfg.local_control, uid, LocalControlClass::source_disclose),
        "LOCAL_CONTROL_CLASS_DENIED", "current explicit SOURCE_DISCLOSE authority required");
    const auto configuration = runtime_configuration_digest(canonical_runtime_config(cfg));
    std::lock_guard<std::mutex> lock(mutex_);
    require(!poisoned_, "STATE_UNAVAILABLE", "writer requires restart");
    const auto check_time = [&]() { require(std::chrono::steady_clock::now() < deadline,
        "SUBSCRIPTION_INVENTORY_DEADLINE", "inventory exceeded deadline"); };
    check_time(); SubmissionWork work; SubmissionWorkScope measure(work);
    require(source_subscriptions_.size() <= kSourceSubscriptionLimit, "STATE_INDEX_CORRUPT", "subscription registry bound");
    // At most 64 identities inspected; no unowned source or head is dereferenced.
    // Do not expose how many other managers' slots were scanned.
    std::vector<const SourceSubscription*> owned;
    std::map<std::string, const SourceSubscription*> successors;
    for (const auto& [id, s] : source_subscriptions_) {
        static_cast<void>(id);
        if (s.grant.uid != uid) continue;
        owned.push_back(&s);
        if (s.succession) require(successors.emplace(s.succession->predecessor_grant, &s).second,
            "STATE_INDEX_CORRUPT", "duplicate retained successor");
    }
    require(owned.size() <= kSourceSubscriptionUidLimit, "STATE_INDEX_CORRUPT", "manager subscription registry bound");
    std::vector<std::string> selected;
    for (const auto* pointer : owned) {
        check_time(); const auto& s = *pointer;
        if ((!q.grant.empty() && q.grant != s.grant.id) || (q.instance && *q.instance != s.instance) ||
            (!q.recipient.empty() && q.recipient != s.grant.peer) || (!q.scope.empty() && q.scope != s.grant.scope) ||
            (q.author_uid && *q.author_uid != s.grant.author_uid)) continue;
        const StoredOutbound* head = nullptr;
        if (!s.deliveries.empty()) {
            const auto found = outbound_index_.find(datacube::hex_lower(s.deliveries.back().operation));
            require(found != outbound_index_.end(), "STATE_INDEX_CORRUPT", "source subscription head missing");
            head = &outbound_.at(found->second);
        }
        if (!matches(s, q, head ? outbound_status_name(*head) : "NONE")) continue;
        const auto next = successors.find(s.grant.id);
        selected.push_back(summary(s, cfg, head, next == successors.end() ? nullptr : next->second, selected.size() + 1U));
    }
    Bytes seed; datacube::append_text(seed, "NATRAV_OVERLAY_SUBSCRIPTION_INVENTORY_SELECTION_V1"); datacube::append_u8(seed, 0U);
    text(seed, node_id_); datacube::append_be32(seed, uid); digest(seed, configuration);
    text(seed, q.lifecycle); text(seed, q.lease); text(seed, q.schedule); text(seed, q.outcome);
    text(seed, q.grant); text(seed, q.recipient); text(seed, q.scope); optional_uid(seed, q.author_uid); optional_digest(seed, q.instance);
    datacube::append_be32(seed, static_cast<std::uint32_t>(selected.size())); auto root = datacube::sha256(seed);
    for (const auto& row : selected) {
        Bytes link; datacube::append_text(link, "NATRAV_OVERLAY_SUBSCRIPTION_INVENTORY_ROW_V1"); datacube::append_u8(link, 0U);
        digest(link, root); datacube::append_be32(link, static_cast<std::uint32_t>(row.size())); datacube::append_text(link, row); root = datacube::sha256(link);
    }
    require(!q.selection || *q.selection == root, "SUBSCRIPTION_INVENTORY_SELECTION_MISMATCH", "selected metadata or context changed");
    require(q.offset <= selected.size(), "SUBSCRIPTION_INVENTORY_INVALID", "offset exceeds selected inventory");
    const auto now = static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count()); // Separate observation: never terminalize an elapsed lease.
    std::size_t returned = 0U, visited = 0U; std::string rows;
    const auto render = [&](std::string_view content, std::size_t count) {
        const auto next = q.offset + count;
        return std::string("{\"format\":\"NATRAV_OVERLAY_SUBSCRIPTION_INVENTORY_V1\",\"ok\":true,\"node\":") + json_string(node_id_) +
            ",\"manager_uid\":" + std::to_string(uid) + ",\"authorized_configuration_digest\":" + hex(configuration) +
            ",\"selection_digest\":" + hex(root) + ",\"selected_total\":" + std::to_string(selected.size()) +
            ",\"offset\":" + std::to_string(q.offset) + ",\"returned\":" + std::to_string(count) +
            ",\"next_offset\":" + std::to_string(next) + ",\"has_more\":" + (next < selected.size() ? "true" : "false") +
            ",\"observed_unix_ms\":" + std::to_string(now) +
            ",\"sequence_semantics\":\"OWNED_FILTERED_GRANT_ORDER\",\"observation\":\"ONE_STATE_MUTEX_CURRENT_METADATA\"" +
            ",\"lease_observation\":\"STORED_TERMINATION_ONLY_COMPARE_DEADLINE_SEPARATELY\"" +
            ",\"scheduling_observation\":\"DURABLE_GRANT_NOT_EXECUTION_ELIGIBILITY\"" +
            ",\"visibility\":\"CURRENT_MANAGER_CLASS_WITH_HISTORICAL_GRANTS\"" +
            ",\"history_included\":false,\"source_payloads_included\":false,\"reason_text_included\":false,\"freshness\":\"NOT_ESTABLISHED\"" +
            ",\"work\":{\"scope\":\"LOCKED_SUBSCRIPTION_INVENTORY\",\"owned_summaries_hashed\":" + std::to_string(selected.size()) +
            ",\"page_rows_visited\":" + std::to_string(visited) +
            ",\"payload_bytes_copied\":0,\"histories_serialized\":0,\"source_records_read\":0" +
            ",\"snapshot_calls\":" + std::to_string(work.snapshot_calls) +
            ",\"snapshot_payload_bytes\":" + std::to_string(work.snapshot_evidence_payload_bytes) +
            ",\"logical_bytes_serialized\":" + std::to_string(work.snapshot_logical_bytes) + "},\"records\":[" + std::string(content) + "]}";
    };
    for (std::size_t n = q.offset; n < selected.size() && returned < q.limit; ++n) {
        check_time(); ++visited; const auto candidate = rows + (returned ? "," : "") + selected[n];
        if (render(candidate, returned + 1U).size() + kPrincipalReserve > q.maximum_bytes) {
            require(returned != 0U, "SUBSCRIPTION_INVENTORY_PAGE_TOO_SMALL", "first complete row exceeds byte budget"); break;
        }
        rows = candidate; ++returned;
    }
    auto out = render(rows, returned);
    require(out.size() + kPrincipalReserve <= q.maximum_bytes, "SUBSCRIPTION_INVENTORY_PAGE_TOO_SMALL", "metadata exceeds byte budget");
    check_time(); return out;
}
} // namespace natrav_overlay
