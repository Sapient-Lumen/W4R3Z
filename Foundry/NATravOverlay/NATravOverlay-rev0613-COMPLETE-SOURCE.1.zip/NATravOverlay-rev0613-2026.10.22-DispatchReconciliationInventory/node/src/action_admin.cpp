#include "action_admin.hpp"
#include <algorithm>

namespace natrav_overlay {
namespace {
void need(const bool value, const std::string_view message) {
    if (!value) { app_fail("ACTION_CONDITION_INVALID", message); }
}
void append_text16(datacube::Octets& out, const std::string_view value) {
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}
std::string read_text16(datacube::Reader& reader, const std::size_t maximum) {
    const auto size = reader.read_be16("text size");
    need(size <= maximum, "text exceeds bound");
    return datacube::octets_text(reader.read_exact(size, "text"), "text", true);
}
void append_digest(datacube::Octets& out, const datacube::Digest32& digest) {
    datacube::append_octets(out, digest.octets);
}
datacube::Digest32 read_digest(datacube::Reader& reader) {
    datacube::Digest32 digest{};
    const auto bytes = reader.read_exact(32U, "digest");
    std::copy(bytes.begin(), bytes.end(), digest.octets.begin());
    return digest;
}
bool valid_reason(const std::string_view value) {
    return !value.empty() && value.size() <= 256U &&
        std::all_of(value.begin(), value.end(), [](const unsigned char c) {
            return c >= 32U && c <= 126U;
        });
}
std::string digest_json(const datacube::Digest32& digest) {
    return json_string(datacube::hex_lower(digest));
}
}  // namespace

void validate_action_admin_request(const ActionAdminRequest& request) {
    need(!digest_is_zero(request.action), "nonzero action ID required");
    need(!digest_is_zero(request.expected_state),
        "nonzero semantic state digest required");
    need(!digest_is_zero(request.expected_configuration),
        "nonzero configuration digest required");
    need(valid_reason(request.reason),
        "reason must be 1..256 printable ASCII bytes");
}

datacube::Octets encode_action_admin_request(
    const ActionAdminRequest& request) {
    validate_action_admin_request(request);
    datacube::Octets out;
    datacube::append_text(out, "ACA1");
    append_digest(out, request.action);
    append_digest(out, request.expected_state);
    append_digest(out, request.expected_configuration);
    append_text16(out, request.reason);
    return out;
}

ActionAdminRequest decode_action_admin_request(const datacube::OctetView bytes) {
    datacube::Reader reader(bytes, "conditional action request");
    need(datacube::octets_text(reader.read_exact(4U, "magic"), "magic", true) ==
            "ACA1",
        "unknown request version");
    ActionAdminRequest request;
    request.action = read_digest(reader);
    request.expected_state = read_digest(reader);
    request.expected_configuration = read_digest(reader);
    request.reason = read_text16(reader, 256U);
    reader.require_eof("conditional action request");
    validate_action_admin_request(request);
    return request;
}

datacube::Digest32 action_admin_request_digest(
    const ActionAdminRequest& request,
    const std::uint32_t uid) {
    datacube::Octets material;
    datacube::append_text(material,
        "NATRAV_OVERLAY_ACTION_ADMIN_REQUEST_V1");
    datacube::append_u8(material, 0U);
    datacube::append_be32(material, uid);
    datacube::append_octets(material, encode_action_admin_request(request));
    return datacube::sha256(material);
}

datacube::Digest32 action_selected_digest(
    const datacube::OctetView metadata,
    const datacube::Digest32& previous_admin_root) {
    datacube::Octets material;
    datacube::append_text(material,
        "NATRAV_OVERLAY_ACTION_SELECTION_V1");
    datacube::append_u8(material, 0U);
    datacube::append_be32(material,
        static_cast<std::uint32_t>(metadata.size()));
    datacube::append_octets(material, metadata);
    append_digest(material, previous_admin_root);
    return datacube::sha256(material);
}

datacube::Octets encode_action_admin_record(
    const ActionAdminRecord& record) {
    const auto request = encode_action_admin_request(record.request);
    need(record.before_metadata.size() <= kActionAdminMetadataLimit,
        "conditional metadata bound");
    datacube::Octets out;
    datacube::append_text(out, "AAT1");
    datacube::append_be32(out,
        static_cast<std::uint32_t>(request.size()));
    datacube::append_octets(out, request);
    datacube::append_be32(out, record.uid);
    datacube::append_be32(out, record.gid);
    datacube::append_be32(out, record.pid);
    datacube::append_be64(out, record.unix_ms);
    datacube::append_be64(out, record.configuration_event);
    append_digest(out, record.request_digest);
    append_digest(out, record.prior_admin_root);
    append_digest(out, record.resulting_metadata_digest);
    datacube::append_be32(out,
        static_cast<std::uint32_t>(record.before_metadata.size()));
    datacube::append_octets(out, record.before_metadata);
    return out;
}

ActionAdminRecord decode_action_admin_record(const datacube::OctetView bytes) {
    datacube::Reader reader(bytes, "action administration event");
    need(datacube::octets_text(reader.read_exact(4U, "magic"), "magic", true) ==
            "AAT1",
        "unknown event version");
    const auto request_size = reader.read_be32("request size");
    need(request_size <= 512U, "request size bound");
    ActionAdminRecord record;
    record.request = decode_action_admin_request(
        reader.read_exact(request_size, "request"));
    record.uid = reader.read_be32("uid");
    record.gid = reader.read_be32("gid");
    record.pid = reader.read_be32("pid");
    record.unix_ms = reader.read_be64("time");
    record.configuration_event = reader.read_be64("configuration event");
    record.request_digest = read_digest(reader);
    record.prior_admin_root = read_digest(reader);
    record.resulting_metadata_digest = read_digest(reader);
    const auto metadata_size = reader.read_be32("metadata size");
    need(metadata_size <= kActionAdminMetadataLimit, "metadata size bound");
    const auto metadata = reader.read_exact(metadata_size, "metadata");
    record.before_metadata.assign(metadata.begin(), metadata.end());
    reader.require_eof("action administration event");
    need(record.unix_ms != 0U && record.pid != 0U &&
            record.configuration_event != 0U,
        "invalid event provenance");
    need(record.request_digest ==
            action_admin_request_digest(record.request, record.uid),
        "request digest mismatch");
    return record;
}

std::string action_admin_record_json(const ActionAdminRecord& record) {
    return std::string("{\"action_id\":") + digest_json(record.request.action) +
        ",\"request_digest\":" + digest_json(record.request_digest) +
        ",\"action\":\"CANCEL\",\"uid\":" +
        std::to_string(record.uid) + ",\"gid\":" +
        std::to_string(record.gid) + ",\"pid\":" +
        std::to_string(record.pid) + ",\"unix_ms\":" +
        std::to_string(record.unix_ms) + ",\"configuration_event\":" +
        std::to_string(record.configuration_event) +
        ",\"configuration_digest\":" +
        digest_json(record.request.expected_configuration) +
        ",\"selected_state_digest\":" +
        digest_json(record.request.expected_state) +
        ",\"resulting_metadata_digest\":" +
        digest_json(record.resulting_metadata_digest) +
        ",\"reason_bytes\":" + std::to_string(record.request.reason.size()) +
        ",\"reason_sha256\":" +
        digest_json(datacube::sha256(datacube::text_octets(record.request.reason))) +
        "}";
}

}  // namespace natrav_overlay
