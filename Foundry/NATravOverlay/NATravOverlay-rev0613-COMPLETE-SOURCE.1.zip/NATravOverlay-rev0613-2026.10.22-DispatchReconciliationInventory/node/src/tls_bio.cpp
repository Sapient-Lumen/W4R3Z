#include "tls_bio.hpp"

#include <algorithm>
#include <climits>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>
#include <string>
#include <utility>

namespace natrav_overlay {
namespace {

struct BioMethodDeleter final {
    void operator()(BIO_METHOD* value) const noexcept {
        BIO_meth_free(value);
    }
};

using BioMethodPtr = std::unique_ptr<BIO_METHOD, BioMethodDeleter>;

}  // namespace

BIO_METHOD* TlsByteChannelBio::method() {
    static const BioMethodPtr value = [] {
        const int type = BIO_get_new_index() | BIO_TYPE_SOURCE_SINK;
        BioMethodPtr result(BIO_meth_new(type, "NATravOverlay ByteChannel BIO"));
        if (!result) {
            app_fail("TLS_BIO_SETUP_FAILED", "OpenSSL BIO method allocation failed");
        }
        if (BIO_meth_set_create(result.get(), create_callback) != 1 ||
            BIO_meth_set_destroy(result.get(), destroy_callback) != 1 ||
            BIO_meth_set_read(result.get(), read_callback) != 1 ||
            BIO_meth_set_read_ex(result.get(), read_ex_callback) != 1 ||
            BIO_meth_set_write(result.get(), write_callback) != 1 ||
            BIO_meth_set_write_ex(result.get(), write_ex_callback) != 1 ||
            BIO_meth_set_ctrl(result.get(), control_callback) != 1 ||
            BIO_meth_set_callback_ctrl(
                result.get(), callback_control_callback) != 1) {
            app_fail("TLS_BIO_SETUP_FAILED", "OpenSSL BIO method configuration failed");
        }
        return result;
    }();
    return value.get();
}

TlsByteChannelBio::TlsByteChannelBio(ByteChannel& channel) {
    callback_.channel = &channel;
    bio_ = BIO_new(method());
    if (bio_ == nullptr) {
        app_fail("TLS_BIO_SETUP_FAILED", "OpenSSL BIO allocation failed");
    }
    BIO_set_data(bio_, &callback_);
    BIO_set_init(bio_, 1);
    BIO_set_shutdown(bio_, BIO_NOCLOSE);
}

TlsByteChannelBio::~TlsByteChannelBio() {
    cancel_operation();
    BIO_free(bio_);
}

BIO* TlsByteChannelBio::get() const noexcept {
    return bio_;
}

BIO* TlsByteChannelBio::release() noexcept {
    return std::exchange(bio_, nullptr);
}

void TlsByteChannelBio::begin_operation(
    const Deadline deadline,
    IoCounters& exposed_counters,
    const std::string_view operation) {
    if (exposed_counters_ != nullptr || callback_.counters != nullptr) {
        app_fail("TLS_BIO_STATE_INVALID", "a TLS BIO operation is already active");
    }
    transport_counters_ = IoCounters{};
    callback_.deadline = deadline;
    callback_.counters = &transport_counters_;
    callback_.operation = operation;
    callback_.failure = nullptr;
    exposed_counters_ = &exposed_counters;
}

void TlsByteChannelBio::merge_transport_counters() noexcept {
    if (exposed_counters_ == nullptr) {
        return;
    }
    // Preserve the pre-BIO public meaning of TLS read/write calls and plaintext
    // byte counts. The backing channel contributes only wait/interruption facts;
    // its record-level calls and encrypted byte counts remain internal.
    exposed_counters_->poll_calls += transport_counters_.poll_calls;
    exposed_counters_->interrupted += transport_counters_.interrupted;
    exposed_counters_->would_block += transport_counters_.would_block;
}

void TlsByteChannelBio::clear_operation() noexcept {
    callback_.counters = nullptr;
    callback_.operation = {};
    callback_.failure = nullptr;
    transport_counters_ = IoCounters{};
    exposed_counters_ = nullptr;
}

void TlsByteChannelBio::complete_operation() {
    if (exposed_counters_ == nullptr || callback_.counters == nullptr) {
        app_fail("TLS_BIO_STATE_INVALID", "no TLS BIO operation is active");
    }
    merge_transport_counters();
    const auto failure = callback_.failure;
    clear_operation();
    if (failure) {
        std::rethrow_exception(failure);
    }
}

void TlsByteChannelBio::cancel_operation() noexcept {
    merge_transport_counters();
    clear_operation();
}

int TlsByteChannelBio::create_callback(BIO* bio) noexcept {
    if (bio == nullptr) {
        return 0;
    }
    BIO_set_data(bio, nullptr);
    BIO_set_init(bio, 0);
    BIO_set_shutdown(bio, BIO_NOCLOSE);
    return 1;
}

int TlsByteChannelBio::destroy_callback(BIO* bio) noexcept {
    if (bio == nullptr) {
        return 0;
    }
    BIO_set_data(bio, nullptr);
    BIO_set_init(bio, 0);
    return 1;
}

TlsByteChannelBio::CallbackState* TlsByteChannelBio::callback_state(
    BIO* bio) noexcept {
    if (bio == nullptr || BIO_get_init(bio) == 0) {
        return nullptr;
    }
    return static_cast<CallbackState*>(BIO_get_data(bio));
}

void TlsByteChannelBio::retain_current_exception(
    CallbackState* state) noexcept {
    if (state != nullptr && !state->failure) {
        state->failure = std::current_exception();
    }
}

bool TlsByteChannelBio::read_once(
    BIO* bio,
    char* data,
    const std::size_t length,
    std::size_t& count) noexcept {
    count = 0U;
    BIO_clear_retry_flags(bio);
    auto* state = callback_state(bio);
    try {
        if (state == nullptr || state->channel == nullptr ||
            state->counters == nullptr) {
            app_fail("TLS_BIO_STATE_INVALID", "TLS BIO read has no active channel operation");
        }
        if (length == 0U) {
            return true;
        }
        if (data == nullptr) {
            app_fail("TLS_BIO_READ_FAILED", "TLS BIO read buffer is null");
        }
        auto bytes = std::span<std::uint8_t>(
            reinterpret_cast<std::uint8_t*>(data), length);
        count = state->channel->read_some(
            bytes, state->deadline, *state->counters, state->operation);
        if (count > length) {
            app_fail("TLS_BIO_READ_FAILED", "backing channel exceeded the BIO read request");
        }
        return count != 0U;
    } catch (...) {
        retain_current_exception(state);
        count = 0U;
        return false;
    }
}

bool TlsByteChannelBio::write_once(
    BIO* bio,
    const char* data,
    const std::size_t length,
    std::size_t& count) noexcept {
    count = 0U;
    BIO_clear_retry_flags(bio);
    auto* state = callback_state(bio);
    try {
        if (state == nullptr || state->channel == nullptr ||
            state->counters == nullptr) {
            app_fail("TLS_BIO_STATE_INVALID", "TLS BIO write has no active channel operation");
        }
        if (length == 0U) {
            return true;
        }
        if (data == nullptr) {
            app_fail("TLS_BIO_WRITE_FAILED", "TLS BIO write buffer is null");
        }
        const auto* begin = reinterpret_cast<const std::uint8_t*>(data);
        count = state->channel->write_some(
            datacube::OctetView(begin, length),
            state->deadline,
            *state->counters,
            state->operation);
        if (count == 0U || count > length) {
            app_fail("TLS_BIO_WRITE_FAILED", "backing channel made invalid BIO write progress");
        }
        return true;
    } catch (...) {
        retain_current_exception(state);
        count = 0U;
        return false;
    }
}

int TlsByteChannelBio::read_callback(
    BIO* bio,
    char* data,
    const int length) noexcept {
    if (length < 0) {
        auto* state = callback_state(bio);
        try {
            app_fail("TLS_BIO_READ_FAILED", "TLS BIO read length is negative");
        } catch (...) {
            retain_current_exception(state);
        }
        return -1;
    }
    std::size_t count = 0U;
    if (!read_once(bio, data, static_cast<std::size_t>(length), count)) {
        auto* state = callback_state(bio);
        return state != nullptr && state->failure ? -1 : 0;
    }
    if (count > static_cast<std::size_t>(INT_MAX)) {
        auto* state = callback_state(bio);
        try {
            app_fail("TLS_BIO_READ_FAILED", "TLS BIO read progress exceeds int");
        } catch (...) {
            retain_current_exception(state);
        }
        return -1;
    }
    return static_cast<int>(count);
}

int TlsByteChannelBio::read_ex_callback(
    BIO* bio,
    char* data,
    const std::size_t length,
    std::size_t* read_bytes) noexcept {
    if (read_bytes == nullptr) {
        auto* state = callback_state(bio);
        try {
            app_fail("TLS_BIO_READ_FAILED", "TLS BIO read result pointer is null");
        } catch (...) {
            retain_current_exception(state);
        }
        return 0;
    }
    return read_once(bio, data, length, *read_bytes) ? 1 : 0;
}

int TlsByteChannelBio::write_callback(
    BIO* bio,
    const char* data,
    const int length) noexcept {
    if (length < 0) {
        auto* state = callback_state(bio);
        try {
            app_fail("TLS_BIO_WRITE_FAILED", "TLS BIO write length is negative");
        } catch (...) {
            retain_current_exception(state);
        }
        return -1;
    }
    std::size_t count = 0U;
    if (!write_once(bio, data, static_cast<std::size_t>(length), count)) {
        return -1;
    }
    if (count > static_cast<std::size_t>(INT_MAX)) {
        auto* state = callback_state(bio);
        try {
            app_fail("TLS_BIO_WRITE_FAILED", "TLS BIO write progress exceeds int");
        } catch (...) {
            retain_current_exception(state);
        }
        return -1;
    }
    return static_cast<int>(count);
}

int TlsByteChannelBio::write_ex_callback(
    BIO* bio,
    const char* data,
    const std::size_t length,
    std::size_t* written_bytes) noexcept {
    if (written_bytes == nullptr) {
        auto* state = callback_state(bio);
        try {
            app_fail("TLS_BIO_WRITE_FAILED", "TLS BIO write result pointer is null");
        } catch (...) {
            retain_current_exception(state);
        }
        return 0;
    }
    return write_once(bio, data, length, *written_bytes) ? 1 : 0;
}

long TlsByteChannelBio::control_callback(
    BIO*,
    const int command,
    const long,
    void*) noexcept {
    switch (command) {
        case BIO_CTRL_FLUSH:
            return 1L;
        case BIO_CTRL_GET_CLOSE:
            return static_cast<long>(BIO_NOCLOSE);
        case BIO_CTRL_SET_CLOSE:
            // The BIO never owns or closes the backing ByteChannel.
            return 1L;
        case BIO_CTRL_EOF:
        case BIO_CTRL_PENDING:
        case BIO_CTRL_WPENDING:
            return 0L;
        default:
            return 0L;
    }
}

long TlsByteChannelBio::callback_control_callback(
    BIO*,
    int,
    BIO_info_cb*) noexcept {
    return 0L;
}

}  // namespace natrav_overlay
