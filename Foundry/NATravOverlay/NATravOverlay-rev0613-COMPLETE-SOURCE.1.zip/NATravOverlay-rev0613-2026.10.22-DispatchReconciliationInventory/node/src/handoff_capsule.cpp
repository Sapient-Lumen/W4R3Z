#include "handoff_capsule.hpp"

#include <algorithm>
#include <cstring>
#include <limits>
#include <memory>
#include <openssl/crypto.h>
#include <openssl/kdf.h>
#include <openssl/rand.h>
#include <openssl/x509.h>

namespace natrav_overlay {
namespace {
using Bytes = datacube::Octets;
using View = datacube::OctetView;
template<class T, void (*Destroy)(T*)> using Ptr = std::unique_ptr<T, decltype(Destroy)>;
using Key = Ptr<EVP_PKEY, EVP_PKEY_free>;
constexpr std::string_view binding_magic = "NHKB0001";
constexpr std::string_view capsule_magic = "NHCP0001";
constexpr std::string_view binding_domain = "NATravOverlay/handoff-binding/v1";
constexpr std::string_view signature_domain = "NATravOverlay/handoff-signature/v1";
constexpr std::string_view kdf_domain = "NATravOverlay/handoff-key/v1";

void require(bool condition, std::string_view code, std::string_view detail) {
    if (!condition) { app_fail(code, detail); }
}
void crypto(bool condition) {
    require(condition, "HANDOFF_CRYPTO_FAILED", "cryptographic operation failed");
}
struct Clean final {
    std::uint8_t* p; std::size_t n;
    ~Clean() { if (p != nullptr && n != 0U) { OPENSSL_cleanse(p, n); } }
};
struct W final {
    Bytes b;
    void raw(View v) { b.insert(b.end(), v.begin(), v.end()); }
    void text(std::string_view v) {
        b.insert(b.end(), reinterpret_cast<const std::uint8_t*>(v.data()),
            reinterpret_cast<const std::uint8_t*>(v.data()) + v.size());
    }
    void u8(std::uint8_t v) { b.push_back(v); }
    void u16(std::uint16_t v) { datacube::append_be16(b, v); }
    void u32(std::uint32_t v) { datacube::append_be32(b, v); }
    void u64(std::uint64_t v) { datacube::append_be64(b, v); }
    void str(std::string_view v) { u16(static_cast<std::uint16_t>(v.size())); text(v); }
    void blob(View v) { u16(static_cast<std::uint16_t>(v.size())); raw(v); }
};
struct R final {
    View b; std::size_t pos{0U};
    View take(std::size_t n) {
        require(n <= b.size() - pos, "HANDOFF_ENCODING_REJECTED", "truncated field");
        auto v = b.subspan(pos, n); pos += n; return v;
    }
    std::uint64_t number(std::size_t n) {
        std::uint64_t v = 0U; for (auto x : take(n)) { v = (v << 8U) | x; } return v;
    }
    std::string str() {
        const auto n = number(2U);
        require(n > 0U && n <= 64U, "HANDOFF_ENCODING_REJECTED", "identifier bound");
        const auto v = take(static_cast<std::size_t>(n));
        return {reinterpret_cast<const char*>(v.data()), v.size()};
    }
    View blob() {
        const auto n = number(2U);
        require(n <= kHandoffBindingLimit, "HANDOFF_ENCODING_REJECTED", "binding bound");
        return take(static_cast<std::size_t>(n));
    }
    void magic(std::string_view expected) {
        auto v = take(expected.size());
        require(std::equal(v.begin(), v.end(), expected.begin()),
            "HANDOFF_ENCODING_REJECTED", "unknown format");
    }
    HandoffKeyBytes key() {
        HandoffKeyBytes k{}; auto v = take(k.size()); std::copy(v.begin(), v.end(), k.begin()); return k;
    }
    void end() { require(pos == b.size(), "HANDOFF_ENCODING_REJECTED", "trailing bytes"); }
};
Bytes domain_bytes(std::string_view domain, View message) {
    W w; w.text(domain); w.u8(0U); w.raw(message); return std::move(w.b);
}
Key raw_key(int type, const HandoffKeyBytes& bytes, bool private_key) {
    EVP_PKEY* key = private_key ? EVP_PKEY_new_raw_private_key(type, nullptr, bytes.data(), bytes.size()) :
        EVP_PKEY_new_raw_public_key(type, nullptr, bytes.data(), bytes.size());
    crypto(key != nullptr); return Key(key, EVP_PKEY_free);
}
HandoffKeyBytes public_bytes(EVP_PKEY* key) {
    HandoffKeyBytes result{}; auto size = result.size();
    crypto(EVP_PKEY_get_raw_public_key(key, result.data(), &size) == 1 && size == result.size());
    return result;
}
Bytes signature(EVP_PKEY* key, std::string_view domain, View message) {
    require(key != nullptr && EVP_PKEY_id(key) == EVP_PKEY_ED25519,
        "HANDOFF_SIGNING_KEY_REJECTED", "Ed25519 identity required");
    auto input = domain_bytes(domain, message);
    Ptr<EVP_MD_CTX, EVP_MD_CTX_free> ctx(EVP_MD_CTX_new(), EVP_MD_CTX_free);
    crypto(ctx != nullptr && EVP_DigestSignInit(ctx.get(), nullptr, nullptr, nullptr, key) == 1);
    Bytes result(64U); std::size_t n = result.size();
    crypto(EVP_DigestSign(ctx.get(), result.data(), &n, input.data(), input.size()) == 1 && n == result.size());
    return result;
}
void verify(const HandoffKeyBytes& public_key, std::string_view domain, View message, View sig) {
    auto key = raw_key(EVP_PKEY_ED25519, public_key, false);
    auto input = domain_bytes(domain, message);
    Ptr<EVP_MD_CTX, EVP_MD_CTX_free> ctx(EVP_MD_CTX_new(), EVP_MD_CTX_free);
    crypto(ctx != nullptr && EVP_DigestVerifyInit(ctx.get(), nullptr, nullptr, nullptr, key.get()) == 1);
    require(sig.size() == 64U && EVP_DigestVerify(ctx.get(), sig.data(), sig.size(), input.data(), input.size()) == 1,
        "HANDOFF_SIGNATURE_REJECTED", "signature did not verify");
}
void canonical_x(const HandoffKeyBytes& k) {
    // RFC7748 permits aliases; this wire format intentionally permits only u < p.
    HandoffKeyBytes p{}; p.fill(255U); p[0] = 237U; p[31] = 127U;
    const bool canonical = std::lexicographical_compare(k.rbegin(), k.rend(), p.rbegin(), p.rend());
    const bool nonzero = std::any_of(k.begin(), k.end(), [](auto b) { return b != 0U; });
    require(canonical && nonzero, "HANDOFF_KEY_REJECTED", "noncanonical X25519 coordinate");
}
W binding_prefix(const HandoffBinding& b) {
    require_node_id(b.node, "handoff node");
    require_generation_id(b.signing_generation, "handoff signing generation");
    require_generation_id(b.handoff_generation, "handoff generation");
    require(b.node.size() <= 64U && b.signing_generation.size() <= 64U && b.handoff_generation.size() <= 64U,
        "HANDOFF_ENCODING_REJECTED", "identifier bound");
    canonical_x(b.encryption_public);
    W w; w.text(binding_magic); w.str(b.node); w.str(b.signing_generation); w.str(b.handoff_generation);
    w.raw(b.signing_public); w.raw(b.encryption_public); return w;
}
void time_bounds(std::uint64_t created, std::uint64_t expires, std::uint64_t now) {
    require(created != 0U && expires > created && expires - created <= kHandoffLifetimeLimitMs,
        "HANDOFF_TIME_REJECTED", "invalid capsule lifetime");
    require(created <= now, "HANDOFF_NOT_YET_VALID", "creation time is in the future");
    require(now < expires, "HANDOFF_EXPIRED", "capsule has expired");
}
void payload_binding(const ApplicationMessage& m, std::uint8_t kind,
    const HandoffBinding& origin, const HandoffBinding& recipient) {
    if (const auto* op = std::get_if<EvidenceRecord>(&m)) {
        require(kind == 1U && op->issuer == origin.node && op->recipient == recipient.node,
            "HANDOFF_PAYLOAD_REJECTED", "operation identity binding differs");
    } else if (const auto* receipt = std::get_if<DeliveryReceipt>(&m)) {
        require(kind == 2U && receipt->recorder == origin.node && receipt->recipient == origin.node &&
                origin.node != recipient.node,
            "HANDOFF_PAYLOAD_REJECTED", "receipt origin binding differs");
    } else {
        app_fail("HANDOFF_PAYLOAD_REJECTED", "only one operation or receipt is permitted");
    }
}
HandoffKeyBytes derive(EVP_PKEY* local, const HandoffKeyBytes& peer_bytes, View header) {
    canonical_x(peer_bytes);
    auto peer = raw_key(EVP_PKEY_X25519, peer_bytes, false);
    Ptr<EVP_PKEY_CTX, EVP_PKEY_CTX_free> ctx(EVP_PKEY_CTX_new(local, nullptr), EVP_PKEY_CTX_free);
    crypto(ctx != nullptr && EVP_PKEY_derive_init(ctx.get()) == 1 && EVP_PKEY_derive_set_peer(ctx.get(), peer.get()) == 1);
    HandoffKeyBytes secret{}; Clean wipe{secret.data(), secret.size()}; auto n = secret.size();
    require(EVP_PKEY_derive(ctx.get(), secret.data(), &n) == 1 && n == secret.size() &&
        std::any_of(secret.begin(), secret.end(), [](auto b) { return b != 0U; }),
        "HANDOFF_KEY_REJECTED", "invalid X25519 shared secret");
    const auto salt = datacube::sha256(header);
    auto info = domain_bytes(kdf_domain, {});
    Ptr<EVP_PKEY_CTX, EVP_PKEY_CTX_free> hkdf(EVP_PKEY_CTX_new_id(EVP_PKEY_HKDF, nullptr), EVP_PKEY_CTX_free);
    crypto(hkdf != nullptr && EVP_PKEY_derive_init(hkdf.get()) == 1 &&
        EVP_PKEY_CTX_set_hkdf_md(hkdf.get(), EVP_sha256()) == 1 &&
        EVP_PKEY_CTX_set1_hkdf_salt(hkdf.get(), salt.octets.data(), static_cast<int>(salt.octets.size())) == 1 &&
        EVP_PKEY_CTX_set1_hkdf_key(hkdf.get(), secret.data(), static_cast<int>(secret.size())) == 1 &&
        EVP_PKEY_CTX_add1_hkdf_info(hkdf.get(), info.data(), static_cast<int>(info.size())) == 1);
    HandoffKeyBytes result{}; n = result.size();
    crypto(EVP_PKEY_derive(hkdf.get(), result.data(), &n) == 1 && n == result.size()); return result;
}
struct Parsed final {
    HandoffBinding origin, recipient;
    std::uint8_t kind{0U}; std::uint64_t created{0U}, expires{0U};
    HandoffKeyBytes ephemeral{}; std::array<std::uint8_t, 12U> nonce{};
    View header, ciphertext, tag, signed_part, sig;
};
Parsed parse(View capsule) {
    require(capsule.size() <= kHandoffCapsuleLimit, "HANDOFF_SIZE_REJECTED", "capsule size bound");
    R r{capsule}; r.magic(capsule_magic); Parsed p;
    p.kind = static_cast<std::uint8_t>(r.number(1U));
    require((p.kind == 1U || p.kind == 2U) && r.number(1U) == 0U && r.number(2U) == 0U,
        "HANDOFF_ENCODING_REJECTED", "unknown kind or reserved flags");
    p.created = r.number(8U); p.expires = r.number(8U);
    (void)r.take(32U); // fresh random capsule nonce, covered by KDF/AAD/signature
    p.ephemeral = r.key(); canonical_x(p.ephemeral);
    const auto nonce = r.take(p.nonce.size()); std::copy(nonce.begin(), nonce.end(), p.nonce.begin());
    p.origin = decode_handoff_binding(r.blob()); p.recipient = decode_handoff_binding(r.blob());
    const auto n = r.number(4U);
    require(n > 32U && n <= kMaximumApplicationPayloadBytes + 32U,
        "HANDOFF_SIZE_REJECTED", "plaintext bound");
    p.header = capsule.first(r.pos); p.ciphertext = r.take(static_cast<std::size_t>(n));
    p.tag = r.take(16U); p.signed_part = capsule.first(r.pos); p.sig = r.take(64U); r.end();
    return p;
}
} // namespace

HandoffBinding decode_handoff_binding(const datacube::OctetView bytes) {
    require(bytes.size() <= kHandoffBindingLimit, "HANDOFF_SIZE_REJECTED", "binding size bound");
    R r{bytes}; r.magic(binding_magic); HandoffBinding b;
    b.node = r.str(); b.signing_generation = r.str(); b.handoff_generation = r.str();
    b.signing_public = r.key(); b.encryption_public = r.key();
    const auto prefix = bytes.first(r.pos); const auto sig = r.take(64U); r.end();
    auto canonical = binding_prefix(b);
    require(std::equal(canonical.b.begin(), canonical.b.end(), prefix.begin(), prefix.end()),
        "HANDOFF_ENCODING_REJECTED", "noncanonical binding");
    verify(b.signing_public, binding_domain, prefix, sig);
    b.canonical.assign(bytes.begin(), bytes.end()); return b;
}
HandoffBinding make_handoff_binding(std::string_view node, std::string_view signing_generation,
    std::string_view handoff_generation, EVP_PKEY* signing_private, const HandoffKeyBytes& encryption_public) {
    HandoffBinding b{std::string(node), std::string(signing_generation), std::string(handoff_generation),
        public_bytes(signing_private), encryption_public, {}};
    auto w = binding_prefix(b); w.raw(signature(signing_private, binding_domain, w.b));
    return decode_handoff_binding(w.b);
}
datacube::Digest32 handoff_signing_pin(const HandoffBinding& binding) {
    auto key = raw_key(EVP_PKEY_ED25519, binding.signing_public, false);
    const int n = i2d_PUBKEY(key.get(), nullptr); crypto(n > 0);
    Bytes encoded(static_cast<std::size_t>(n)); auto* out = encoded.data();
    crypto(i2d_PUBKEY(key.get(), &out) == n); return datacube::sha256(encoded);
}
void require_handoff_binding(const HandoffBinding& binding, std::string_view node,
    std::string_view generation, const datacube::Digest32& pin) {
    // Reparse the signed representation to prevent drift in an in-memory object.
    const auto b = decode_handoff_binding(binding.canonical);
    require(b.node == binding.node && b.signing_generation == binding.signing_generation &&
        b.handoff_generation == binding.handoff_generation && b.encryption_public == binding.encryption_public &&
        b.signing_public == binding.signing_public && b.node == node && b.signing_generation == generation &&
        handoff_signing_pin(b) == pin,
        "HANDOFF_IDENTITY_REJECTED", "binding differs from the exact trusted identity generation");
}
HandoffKeyBytes handoff_x25519_public(const HandoffKeyBytes& secret) {
    auto key = raw_key(EVP_PKEY_X25519, secret, true); return public_bytes(key.get());
}
void generate_handoff_secret(HandoffKeyBytes& secret) {
    crypto(RAND_priv_bytes(secret.data(), static_cast<int>(secret.size())) == 1);
}
datacube::Octets seal_handoff_capsule(const HandoffBinding& origin, EVP_PKEY* signing_private,
    const HandoffBinding& recipient, const ApplicationMessage& message,
    const std::uint64_t now_ms, const std::uint64_t expires_ms) {
    time_bounds(now_ms, expires_ms, now_ms);
    require_handoff_binding(origin, origin.node, origin.signing_generation, handoff_signing_pin(origin));
    require_handoff_binding(recipient, recipient.node, recipient.signing_generation, handoff_signing_pin(recipient));
    require(signing_private != nullptr && EVP_PKEY_id(signing_private) == EVP_PKEY_ED25519 &&
        public_bytes(signing_private) == origin.signing_public && origin.node != recipient.node,
        "HANDOFF_IDENTITY_REJECTED", "signer mismatch or self capsule");
    const std::uint8_t kind = std::holds_alternative<EvidenceRecord>(message) ? 1U : 2U;
    payload_binding(message, kind, origin, recipient);
    auto payload = encode_application_message(message); Clean payload_wipe{payload.data(), payload.size()};
    require(payload.size() <= kMaximumApplicationPayloadBytes, "HANDOFF_SIZE_REJECTED", "application bound");
    W plain; plain.raw(datacube::sha256(payload).octets); plain.raw(payload);
    Clean plain_wipe{plain.b.data(), plain.b.size()};
    HandoffKeyBytes ephemeral_secret{}; Clean ephemeral_wipe{ephemeral_secret.data(), ephemeral_secret.size()};
    generate_handoff_secret(ephemeral_secret); auto ephemeral = raw_key(EVP_PKEY_X25519, ephemeral_secret, true);
    std::array<std::uint8_t, 12U> nonce{}; HandoffKeyBytes capsule_nonce{};
    crypto(RAND_bytes(nonce.data(), static_cast<int>(nonce.size())) == 1 &&
        RAND_bytes(capsule_nonce.data(), static_cast<int>(capsule_nonce.size())) == 1);
    W w; w.text(capsule_magic); w.u8(kind); w.u8(0U); w.u16(0U); w.u64(now_ms); w.u64(expires_ms);
    w.raw(capsule_nonce); w.raw(public_bytes(ephemeral.get())); w.raw(nonce);
    w.blob(origin.canonical); w.blob(recipient.canonical); w.u32(static_cast<std::uint32_t>(plain.b.size()));
    auto key = derive(ephemeral.get(), recipient.encryption_public, w.b); Clean key_wipe{key.data(), key.size()};
    Ptr<EVP_CIPHER_CTX, EVP_CIPHER_CTX_free> ctx(EVP_CIPHER_CTX_new(), EVP_CIPHER_CTX_free);
    crypto(ctx != nullptr && EVP_EncryptInit_ex(ctx.get(), EVP_aes_256_gcm(), nullptr, key.data(), nonce.data()) == 1);
    int n = 0; crypto(EVP_EncryptUpdate(ctx.get(), nullptr, &n, w.b.data(), static_cast<int>(w.b.size())) == 1);
    Bytes encrypted(plain.b.size() + 16U);
    crypto(EVP_EncryptUpdate(ctx.get(), encrypted.data(), &n, plain.b.data(), static_cast<int>(plain.b.size())) == 1);
    std::size_t used = static_cast<std::size_t>(n);
    crypto(EVP_EncryptFinal_ex(ctx.get(), encrypted.data() + used, &n) == 1);
    used += static_cast<std::size_t>(n); crypto(used == plain.b.size()); encrypted.resize(used);
    std::array<std::uint8_t, 16U> tag{}; crypto(EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_GET_TAG, 16, tag.data()) == 1);
    w.raw(encrypted); w.raw(tag); w.raw(signature(signing_private, signature_domain, w.b));
    require(w.b.size() <= kHandoffCapsuleLimit, "HANDOFF_SIZE_REJECTED", "encoded capsule bound");
    return std::move(w.b);
}
HandoffBinding peek_handoff_origin(datacube::OctetView capsule) { return parse(capsule).origin; }
HandoffBinding peek_handoff_recipient(datacube::OctetView capsule) { return parse(capsule).recipient; }
HandoffOpened open_handoff_capsule(datacube::OctetView capsule, const HandoffBinding& local_binding,
    const HandoffKeyBytes& local_secret, std::string_view expected_origin,
    std::string_view expected_origin_generation, const datacube::Digest32& expected_origin_pin,
    std::uint64_t now_ms) {
    const auto p = parse(capsule);
    require(p.recipient.canonical == local_binding.canonical &&
        p.recipient.encryption_public == handoff_x25519_public(local_secret) && p.origin.node != p.recipient.node,
        "HANDOFF_RECIPIENT_REJECTED", "capsule does not name the exact local handoff key");
    require_handoff_binding(p.origin, expected_origin, expected_origin_generation, expected_origin_pin);
    verify(p.origin.signing_public, signature_domain, p.signed_part, p.sig);
    time_bounds(p.created, p.expires, now_ms);
    auto local = raw_key(EVP_PKEY_X25519, local_secret, true);
    auto key = derive(local.get(), p.ephemeral, p.header); Clean key_wipe{key.data(), key.size()};
    Ptr<EVP_CIPHER_CTX, EVP_CIPHER_CTX_free> ctx(EVP_CIPHER_CTX_new(), EVP_CIPHER_CTX_free);
    crypto(ctx != nullptr && EVP_DecryptInit_ex(ctx.get(), EVP_aes_256_gcm(), nullptr, key.data(), p.nonce.data()) == 1);
    int n = 0; crypto(EVP_DecryptUpdate(ctx.get(), nullptr, &n, p.header.data(), static_cast<int>(p.header.size())) == 1);
    Bytes plain(p.ciphertext.size() + 16U); Clean plain_wipe{plain.data(), plain.size()};
    crypto(EVP_DecryptUpdate(ctx.get(), plain.data(), &n, p.ciphertext.data(), static_cast<int>(p.ciphertext.size())) == 1);
    const auto used = static_cast<std::size_t>(n); std::array<std::uint8_t, 16U> tag{};
    std::copy(p.tag.begin(), p.tag.end(), tag.begin());
    crypto(EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_SET_TAG, 16, tag.data()) == 1);
    require(EVP_DecryptFinal_ex(ctx.get(), plain.data() + used, &n) == 1,
        "HANDOFF_AEAD_REJECTED", "ciphertext authentication failed");
    require(used + static_cast<std::size_t>(n) == p.ciphertext.size(), "HANDOFF_AEAD_REJECTED", "plaintext size differs");
    auto payload = View(plain).subspan(32U, p.ciphertext.size() - 32U);
    const auto digest = datacube::sha256(payload);
    require(CRYPTO_memcmp(digest.octets.data(), plain.data(), digest.octets.size()) == 0,
        "HANDOFF_PAYLOAD_REJECTED", "payload digest differs");
    auto message = decode_application_message(payload);
    const auto canonical = encode_application_message(message);
    require(std::equal(canonical.begin(), canonical.end(), payload.begin(), payload.end()),
        "HANDOFF_PAYLOAD_REJECTED", "noncanonical application encoding");
    payload_binding(message, p.kind, p.origin, p.recipient);
    return {p.origin, p.recipient, std::move(message), datacube::sha256(capsule), p.created, p.expires};
}
} // namespace natrav_overlay
