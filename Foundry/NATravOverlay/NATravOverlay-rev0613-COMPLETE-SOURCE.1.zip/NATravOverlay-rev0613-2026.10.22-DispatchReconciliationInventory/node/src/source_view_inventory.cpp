#include "source_view_inventory.hpp"
#include "journal.hpp"
#include "config.hpp"
#include "submission_work.hpp"

#include <algorithm>
#include <chrono>
#include <map>
#include <vector>

namespace natrav_overlay {
namespace {
using Digest = datacube::Digest32;
using Bytes = datacube::Octets;
constexpr std::size_t kPrincipalReserve = 384U;
void require(bool condition, std::string_view code, std::string_view detail) {
    if (!condition) app_fail(code, detail);
}
void text(Bytes& b, std::string_view s) {
    datacube::append_be16(b, static_cast<std::uint16_t>(s.size())); datacube::append_text(b, s);
}
std::string text(datacube::Reader& r, std::size_t maximum) {
    const auto n=r.read_be16("text length");
    require(n<=maximum,"SOURCE_VIEW_INVENTORY_INVALID","text exceeds bound");
    return datacube::octets_text(r.read_exact(n,"text"),"text",true);
}
void digest(Bytes& b, const Digest& d) { datacube::append_octets(b,d.octets); }
Digest digest(datacube::Reader& r) {
    Digest d{}; const auto b=r.read_exact(32U,"digest"); std::copy(b.begin(),b.end(),d.octets.begin()); return d;
}
void uid_bytes(Bytes& b, std::optional<std::uint32_t> uid) {
    datacube::append_u8(b,uid?1U:0U); if(uid)datacube::append_be32(b,*uid);
}
void filters(Bytes& b, const SourceViewInventory& q) {
    for(const auto* s:{&q.presence,&q.lifecycle,&q.schedule,&q.view,&q.provider,&q.generation,&q.source_scope,&q.target_scope})text(b,*s);
    uid_bytes(b,q.author_uid);
}
std::string hex(const Digest& d) { return json_string(datacube::hex_lower(d)); }
std::string boolean(bool b) { return b?"true":"false"; }
std::string lower(std::string s) {
    for(auto& c:s){if(c>='A'&&c<='Z')c=static_cast<char>(c-'A'+'a');if(c=='_')c='-';}return s;
}
Digest binding_root(const std::map<std::string,SourceViewBinding>& bindings) {
    Bytes b;datacube::append_text(b,"NATRAV_OVERLAY_VIEW_INVENTORY_BINDINGS_V1");datacube::append_u8(b,0U);
    datacube::append_be32(b,static_cast<std::uint32_t>(bindings.size()));
    for(const auto& [grant,binding]:bindings){text(b,grant);digest(b,binding.digest);}return datacube::sha256(b);
}
Digest current_binding_root(const SourceViewPolicy& policy,std::string_view view,std::size_t& count) {
    // The parser canonically sorts by view/grant. Read only this view's bounded
    // policy metadata, never source bytes or historical configurations.
    Bytes b;datacube::append_text(b,"NATRAV_OVERLAY_VIEW_INVENTORY_BINDINGS_V1");datacube::append_u8(b,0U);
    count=static_cast<std::size_t>(std::count_if(policy.bindings.begin(),policy.bindings.end(),
        [&](const auto& item){return item.view==view;}));
    datacube::append_be32(b,static_cast<std::uint32_t>(count));
    for(const auto& item:policy.bindings)if(item.view==view){text(b,item.grant);digest(b,item.digest);}
    return datacube::sha256(b);
}
std::string event_summary(const ImportAutoEvent& e) {
    return "{\"revision\":"+std::to_string(e.revision+1U)+",\"action\":"+json_string(e.action)+
        ",\"outcome\":"+json_string(e.outcome)+",\"configuration_event\":"+std::to_string(e.configuration_event)+
        ",\"unix_ms\":"+std::to_string(e.unix_ms)+",\"actor_uid\":"+std::to_string(e.uid)+
        ",\"actor_gid\":"+std::to_string(e.gid)+",\"actor_pid\":"+std::to_string(e.pid)+"}";
}
std::string summary(const RetainedSourceView& retained,const SourceViewRule* active,
    const RuntimeConfig& cfg,const ImportAutoState* schedule,
    std::uint64_t records,std::uint64_t bytes,std::size_t ordinal) {
    const auto& r=retained.rule;
    require(records<=r.maximum_records&&bytes<=r.maximum_payload_bytes,"STATE_INDEX_CORRUPT","view retention counters exceed immutable limits");
    const auto* key=find_peer_generation(cfg,r.provider,r.generation);
    const bool terminal=schedule&&schedule->state=="RETIRED";
    const auto state=schedule?std::string_view(schedule->state):std::string_view("NEVER_ENABLED");
    if(schedule)require(schedule->uid==r.uid&&schedule->rule_digest==r.digest&&schedule->history.size()<=kImportRetainedHistoryLimit&&
        schedule->deferred.size()<=64U&&schedule->imports<=schedule->maximum_imports&&schedule->decisions<=schedule->maximum_decisions&&
        schedule->manual_retries<=kImportManualRetryLimit,"STATE_INDEX_CORRUPT","inconsistent import schedule");
    if(terminal)require(!schedule->history.empty()&&schedule->history.back().action=="RETIRE"&&
        records==schedule->retired_records&&bytes==schedule->retired_payload_bytes,
        "STATE_INDEX_CORRUPT","retired view usage differs from terminal account");
    std::size_t current_count=0U;
    const auto current_root=current_binding_root(cfg.source_views,r.id,current_count);
    std::string out="{\"ordinal\":"+std::to_string(ordinal)+",\"view\":"+json_string(r.id)+
        ",\"manager_uid\":"+std::to_string(r.uid)+",\"view_digest\":"+hex(r.digest)+
        ",\"first_configuration_event\":"+std::to_string(retained.first_configuration_event)+
        ",\"presence\":"+json_string(active?"CONFIGURED":"HISTORICAL")+
        ",\"policy_current\":"+boolean(active&&active->digest==r.digest)+
        ",\"lifecycle\":"+json_string(terminal?"RETIRED":"ACTIVE")+
        ",\"provider\":"+json_string(r.provider)+",\"provider_generation\":"+json_string(r.generation)+
        ",\"provider_spki_sha256\":"+hex(retained.provider_spki)+
        ",\"provider_generation_state\":"+(key?json_string(key_generation_state_name(key->state)):"null")+
        ",\"provider_pin_matches\":"+boolean(key&&key->spki_sha256==retained.provider_spki)+
        ",\"source_author_uid\":"+std::to_string(r.author_uid)+",\"source_scope\":"+json_string(r.source_scope)+
        ",\"target_scope\":"+json_string(r.target_scope)+",\"target_reserved\":true"+
        ",\"maximum_records\":"+std::to_string(r.maximum_records)+",\"retained_records\":"+std::to_string(records)+
        ",\"remaining_records\":"+std::to_string(r.maximum_records-records)+
        ",\"maximum_payload_bytes\":"+std::to_string(r.maximum_payload_bytes)+",\"retained_payload_bytes\":"+std::to_string(bytes)+
        ",\"remaining_payload_bytes\":"+std::to_string(r.maximum_payload_bytes-bytes)+
        ",\"current_binding_count\":"+std::to_string(current_count)+",\"current_bindings_digest\":"+hex(current_root)+
        ",\"retained_binding_count\":"+std::to_string(retained.bindings.size())+",\"retained_bindings_digest\":"+hex(retained.bindings_digest)+
        ",\"schedule_state\":"+json_string(state)+",\"schedule\":";
    if(schedule) {
        out+="{\"revision\":"+std::to_string(schedule->history.size())+",\"history_digest\":"+hex(schedule->head_digest)+
            ",\"adopted_authority_digest\":"+hex(schedule->authority_digest)+
            ",\"generation\":"+std::to_string(schedule->generation)+",\"next_position\":"+std::to_string(schedule->next_position)+
            ",\"imports\":"+std::to_string(schedule->imports)+",\"maximum_imports\":"+std::to_string(schedule->maximum_imports)+
            ",\"decisions\":"+std::to_string(schedule->decisions)+",\"maximum_decisions\":"+std::to_string(schedule->maximum_decisions)+
            ",\"interval_ms\":"+std::to_string(schedule->interval_ms)+",\"manual_retries\":"+std::to_string(schedule->manual_retries)+
            ",\"manual_retry_limit\":"+std::to_string(kImportManualRetryLimit)+
            ",\"deferred_count\":"+std::to_string(schedule->deferred.size())+
            ",\"last_error_code\":"+json_string(schedule->error)+",\"latest_decision\":"+
            (schedule->history.empty()?"null":event_summary(schedule->history.back()))+"}";
    } else out+="null";
    out+=",\"retirement\":";
    if(terminal) {
        const auto& e=schedule->history.back();
        out+="{\"selected_revision\":"+std::to_string(e.revision)+",\"final_state_digest\":"+hex(e.final_state_digest)+
            ",\"configuration_event\":"+std::to_string(e.configuration_event)+",\"configuration_digest\":"+hex(e.configuration_digest)+
            ",\"unix_ms\":"+std::to_string(e.unix_ms)+",\"actor_uid\":"+std::to_string(e.uid)+
            ",\"actor_gid\":"+std::to_string(e.gid)+",\"actor_pid\":"+std::to_string(e.pid)+
            ",\"previous_schedule_state\":"+json_string(schedule->retired_from_state)+
            ",\"deferred_disposition\":"+json_string(e.deferred_disposition)+
            ",\"retained_records_digest\":"+hex(schedule->retired_records_digest)+
            ",\"remaining_work\":\"RETAINED_UNPROCESSED\"}";
    } else out+="null";
    return out+"}";
}
} // namespace

void NodeState::index_source_view_configuration_locked(const RuntimeConfig& cfg) {
    // Called only on application of an accepted configuration, before it is
    // appended to configuration_events_. Preflight with commit=false never calls
    // this. Checkpoint replay invokes the identical hook in historical order.
    for(const auto& rule:cfg.source_views.rules) {
        const auto* key=find_peer_generation(cfg,rule.provider,rule.generation);
        require(key!=nullptr,"STATE_INDEX_CORRUPT","accepted view provider key absent");
        const auto id=std::make_pair(rule.uid,rule.id);
        auto found=retained_source_views_.find(id);
        if(found==retained_source_views_.end()) {
            RetainedSourceView value;value.rule=rule;value.provider_spki=key->spki_sha256;
            value.first_configuration_event=configuration_events_.size()+1U;
            value.bindings_digest=binding_root(value.bindings);
            found=retained_source_views_.emplace(id,std::move(value)).first;
        } else require(found->second.rule.digest==rule.digest&&found->second.provider_spki==key->spki_sha256,
            "STATE_INDEX_CORRUPT","accepted view identity changed");
        auto& item=found->second;
        for(const auto& binding:cfg.source_views.bindings)if(binding.view==rule.id) {
            const auto [it,added]=item.bindings.emplace(binding.grant,binding);
            require(added||it->second.digest==binding.digest,"STATE_INDEX_CORRUPT","historical view pin changed");
            if(added)item.binding_first_events.emplace(binding.grant,configuration_events_.size()+1U);
        }
        item.bindings_digest=binding_root(item.bindings);
    }
    require(retained_source_views_.size()<=32U,"STATE_INDEX_CORRUPT","historical view bound");
    std::size_t pins=0U;for(const auto& [id,item]:retained_source_views_){static_cast<void>(id);pins+=item.bindings.size();}
    require(pins<=256U,"STATE_INDEX_CORRUPT","historical view binding bound");
}
void validate_source_view_inventory(const SourceViewInventory& q) {
    require((q.presence=="all"||q.presence=="configured"||q.presence=="historical")&&
        (q.lifecycle=="all"||q.lifecycle=="active"||q.lifecycle=="retired")&&
        (q.schedule=="all"||q.schedule=="never-enabled"||q.schedule=="enabled"||q.schedule=="paused"||q.schedule=="blocked"||q.schedule=="exhausted"||q.schedule=="retired")&&
        (q.view.empty()||valid_generation_id(q.view))&&(q.provider.empty()||valid_node_id(q.provider))&&
        (q.generation.empty()||valid_generation_id(q.generation))&&(q.source_scope.empty()||valid_scope(q.source_scope))&&
        (q.target_scope.empty()||valid_scope(q.target_scope))&&q.limit>=1U&&q.limit<=16U&&
        q.maximum_bytes>=2048U&&q.maximum_bytes<=60000U&&q.offset<=32U&&(!q.selection||!digest_is_zero(*q.selection)),
        "SOURCE_VIEW_INVENTORY_INVALID","invalid exact selector or page bound");
    require(q.offset==0U||q.selection,"SOURCE_VIEW_INVENTORY_SELECTION_REQUIRED","continuation requires selection digest");
}
Bytes encode_source_view_inventory(const SourceViewInventory& q) {
    validate_source_view_inventory(q);Bytes b;datacube::append_text(b,"VIN1");filters(b,q);
    datacube::append_be32(b,q.offset);datacube::append_be32(b,q.limit);datacube::append_be32(b,q.maximum_bytes);
    datacube::append_u8(b,q.selection?1U:0U);if(q.selection)digest(b,*q.selection);return b;
}
SourceViewInventory decode_source_view_inventory(datacube::OctetView b) {
    try {
        datacube::Reader r(b,"source view inventory");
        require(datacube::octets_text(r.read_exact(4U,"magic"),"magic",true)=="VIN1","SOURCE_VIEW_INVENTORY_INVALID","unknown version");
        SourceViewInventory q;q.presence=text(r,16U);q.lifecycle=text(r,16U);q.schedule=text(r,16U);
        q.view=text(r,64U);q.provider=text(r,64U);q.generation=text(r,64U);q.source_scope=text(r,128U);q.target_scope=text(r,128U);
        const auto u=r.read_u8("optional UID");require(u<=1U,"SOURCE_VIEW_INVENTORY_INVALID","invalid UID marker");if(u)q.author_uid=r.read_be32("UID");
        q.offset=r.read_be32("offset");q.limit=r.read_be32("limit");q.maximum_bytes=r.read_be32("maximum bytes");
        const auto s=r.read_u8("optional selection");require(s<=1U,"SOURCE_VIEW_INVENTORY_INVALID","invalid selection marker");if(s)q.selection=digest(r);
        r.require_eof("source view inventory");validate_source_view_inventory(q);return q;
    } catch(const datacube::Failure&){app_fail("SOURCE_VIEW_INVENTORY_INVALID","malformed or truncated request");}
}
std::string NodeState::source_view_inventory(const SourceViewInventory& q,const RuntimeConfig& cfg,
    std::uint32_t uid,std::chrono::steady_clock::time_point deadline) const {
    validate_source_view_inventory(q);
    require(cfg.format_version>=17U,"SOURCE_VIEW_POLICY_VERSION_REQUIRED","inventory requires V17 or newer");
    require(local_control_allows(cfg.local_control,uid,LocalControlClass::source_import),"LOCAL_CONTROL_CLASS_DENIED","current explicit SOURCE_IMPORT required");
    const auto configuration=runtime_configuration_digest(canonical_runtime_config(cfg));
    std::lock_guard<std::mutex> lock(mutex_);
    require(!poisoned_,"STATE_UNAVAILABLE","writer requires restart");
    const auto check_time=[&](){require(std::chrono::steady_clock::now()<deadline,"SOURCE_VIEW_INVENTORY_DEADLINE","inventory deadline exceeded");};
    check_time();SubmissionWork work;SubmissionWorkScope measured(work);
    std::vector<std::string> selected;
    for(auto it=retained_source_views_.lower_bound({uid,std::string{}});it!=retained_source_views_.end()&&it->first.first==uid;++it) {
        check_time();const auto& retained=it->second;const auto& r=retained.rule;
        if((!q.view.empty()&&q.view!=r.id)||(!q.provider.empty()&&q.provider!=r.provider)||
            (!q.generation.empty()&&q.generation!=r.generation)||(!q.source_scope.empty()&&q.source_scope!=r.source_scope)||
            (!q.target_scope.empty()&&q.target_scope!=r.target_scope)||(q.author_uid&&*q.author_uid!=r.author_uid))continue;
        const auto current=std::find_if(cfg.source_views.rules.begin(),cfg.source_views.rules.end(),[&](const auto& rule){return rule.id==r.id;});
        const auto* active=current==cfg.source_views.rules.end()?nullptr:&*current;
        const auto sched=import_schedules_.find(r.id);const auto* schedule=sched==import_schedules_.end()?nullptr:&sched->second;
        const bool retired=schedule&&schedule->state=="RETIRED";
        if((q.presence!="all"&&q.presence!=(active?"configured":"historical"))||
            (q.lifecycle!="all"&&q.lifecycle!=(retired?"retired":"active"))||
            (q.schedule!="all"&&q.schedule!=lower(schedule?schedule->state:"NEVER_ENABLED")))continue;
        require(source_view_domains_.contains({r.provider,r.target_scope}),"STATE_INDEX_CORRUPT","historical target reservation absent");
        const auto usage=source_view_usage_.find(r.id);
        selected.push_back(summary(retained,active,cfg,schedule,usage==source_view_usage_.end()?0U:usage->second.first,
            usage==source_view_usage_.end()?0U:usage->second.second,selected.size()+1U));
    }
    Bytes b;datacube::append_text(b,"NATRAV_OVERLAY_SOURCE_VIEW_INVENTORY_SELECTION_V1");datacube::append_u8(b,0U);
    text(b,node_id_);datacube::append_be32(b,uid);digest(b,configuration);filters(b,q);
    datacube::append_be32(b,static_cast<std::uint32_t>(selected.size()));auto root=datacube::sha256(b);
    for(const auto& row:selected) {
        Bytes link;datacube::append_text(link,"NATRAV_OVERLAY_SOURCE_VIEW_INVENTORY_ROW_V1");datacube::append_u8(link,0U);
        digest(link,root);datacube::append_be32(link,static_cast<std::uint32_t>(row.size()));datacube::append_text(link,row);root=datacube::sha256(link);
    }
    require(!q.selection||*q.selection==root,"SOURCE_VIEW_INVENTORY_SELECTION_MISMATCH","selected metadata or context changed");
    require(q.offset<=selected.size(),"SOURCE_VIEW_INVENTORY_INVALID","offset exceeds selected inventory");
    std::size_t returned=0U,visited=0U;std::string rows;
    const auto render=[&](std::string_view content,std::size_t count) {
        const auto next=q.offset+count;
        return std::string("{\"format\":\"NATRAV_OVERLAY_SOURCE_VIEW_INVENTORY_V1\",\"ok\":true,\"node\":")+json_string(node_id_)+
            ",\"manager_uid\":"+std::to_string(uid)+",\"authorized_configuration_digest\":"+hex(configuration)+
            ",\"selection_digest\":"+hex(root)+",\"selected_total\":"+std::to_string(selected.size())+
            ",\"offset\":"+std::to_string(q.offset)+",\"returned\":"+std::to_string(count)+",\"next_offset\":"+std::to_string(next)+
            ",\"has_more\":"+boolean(next<selected.size())+",\"sequence_semantics\":\"OWNED_FILTERED_VIEW_ORDER\""+
            ",\"observation\":\"ONE_STATE_MUTEX_CURRENT_METADATA\",\"visibility\":\"CURRENT_MANAGER_CLASS_WITH_HISTORICAL_VIEWS\""+
            ",\"scheduling_observation\":\"STORED_STATE_NOT_WORKER_ELIGIBILITY\""+
            ",\"payloads_included\":false,\"histories_included\":false,\"reason_text_included\":false,\"freshness\":\"NOT_ESTABLISHED\""+
            ",\"work\":{\"scope\":\"LOCKED_SOURCE_VIEW_INVENTORY\",\"owned_summaries_hashed\":"+std::to_string(selected.size())+
            ",\"page_rows_visited\":"+std::to_string(visited)+",\"source_records_read\":0,\"payload_bytes_copied\":0"+
            ",\"histories_serialized\":0,\"deferred_entries_serialized\":0,\"historical_configurations_parsed\":0,\"final_accounts_computed\":0"+
            ",\"snapshot_calls\":"+std::to_string(work.snapshot_calls)+",\"snapshot_payload_bytes\":"+std::to_string(work.snapshot_evidence_payload_bytes)+
            ",\"logical_bytes_serialized\":"+std::to_string(work.snapshot_logical_bytes)+"},\"records\":["+std::string(content)+"]}";
    };
    for(std::size_t n=q.offset;n<selected.size()&&returned<q.limit;++n) {
        check_time();++visited;const auto candidate=rows+(returned?",":"")+selected[n];
        if(render(candidate,returned+1U).size()+kPrincipalReserve>q.maximum_bytes) {
            require(returned!=0U,"SOURCE_VIEW_INVENTORY_PAGE_TOO_SMALL","first complete row exceeds byte budget");break;
        }
        rows=candidate;++returned;
    }
    auto out=render(rows,returned);
    require(out.size()+kPrincipalReserve<=q.maximum_bytes,"SOURCE_VIEW_INVENTORY_PAGE_TOO_SMALL","metadata exceeds byte budget");
    check_time();return out;
}
} // namespace natrav_overlay
