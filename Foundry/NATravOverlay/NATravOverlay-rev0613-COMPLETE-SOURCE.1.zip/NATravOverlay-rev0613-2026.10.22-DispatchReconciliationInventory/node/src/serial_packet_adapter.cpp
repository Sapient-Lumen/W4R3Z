#include "serial_packet_adapter.hpp"
#include "serial_packet_framing.hpp"
#include "serial_transport.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <deque>
#include <fcntl.h>
#include <limits>
#include <map>
#include <poll.h>
#include <span>
#include <string>
#include <string_view>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <utility>

namespace natrav_overlay {
namespace {
using Bytes = serial_packet::Bytes;
using Clock = std::chrono::steady_clock;
using Milliseconds = std::chrono::milliseconds;
constexpr int kProtocolFd = 3;
constexpr std::size_t kNapaHeader = 36U;
constexpr std::array<std::uint8_t, 8U> kMagic{'N','A','P','A','0','0','0','1'};
constexpr std::uint32_t kOk = 0U;
constexpr std::uint32_t kNoData = 1U;
constexpr std::uint32_t kBusy = 2U;

struct Options final {
    SerialTransportLocator serial;
    serial_packet::Settings wire;
    std::size_t queue_bytes{0U};
    std::size_t queue_frames{0U};
    std::size_t io_quantum{0U};
};
struct Frame final {
    std::uint8_t type{0U};
    std::uint64_t sequence{0U};
    std::uint32_t deadline_ms{0U};
    std::uint32_t status{kOk};
    Bytes payload{};
};
std::uint64_t now_ms() {
    return static_cast<std::uint64_t>(std::chrono::duration_cast<Milliseconds>(
        Clock::now().time_since_epoch()).count());
}
void append(Bytes& bytes, const std::uint64_t value, const unsigned count) {
    for (unsigned i = count; i > 0U; --i) {
        bytes.push_back(static_cast<std::uint8_t>(value >> ((i - 1U) * 8U)));
    }
}
std::uint64_t read(const Bytes& bytes, const std::size_t offset, const std::size_t count) {
    if (offset > bytes.size() || count > bytes.size() - offset) {
        app_fail("SERIAL_ADAPTER_PROTOCOL_INVALID", "truncated integer");
    }
    std::uint64_t result = 0U;
    for (std::size_t i = 0U; i < count; ++i) { result = (result << 8U) | bytes[offset + i]; }
    return result;
}
Options parse_options(const int argc, char* argv[]) {
    const std::array<std::string, 8U> keys{
        "--serial", "--mtu", "--link", "--epoch", "--queue-bytes",
        "--queue-frames", "--frame-timeout-ms", "--io-quantum"};
    if (argc != 18) { app_fail("INVALID_ARGUMENT", "serial-packet-adapter requires exactly eight explicit option/value pairs"); }
    std::map<std::string, std::string> fields;
    for (int i = 2; i < argc; i += 2) {
        const std::string key(argv[i]);
        const std::string value(argv[i + 1]);
        if (value.size() > 4096U || std::find(keys.begin(), keys.end(), key) == keys.end() ||
            !fields.emplace(key, value).second) {
            app_fail("INVALID_ARGUMENT", "unknown, duplicate or oversized serial adapter option");
        }
    }
    auto number = [&](const std::string& key, const std::uint64_t low, const std::uint64_t high) {
        const auto& text = fields.at(key);
        const auto value = parse_u64(text, key, low, high);
        if (std::to_string(value) != text) { app_fail("INVALID_ARGUMENT", "noncanonical serial adapter number"); }
        return value;
    };
    const auto locator = parse_serial_transport_locator(fields.at("--serial"));
    const auto& serial = serial_transport_locator(locator);
    if (serial.data_bits != 8U) {
        app_fail("SERIAL_PACKET_SETTING_UNSUPPORTED", "NSP1 requires eight data bits");
    }
    const auto& link_text = fields.at("--link");
    if (link_text.size() != 16U) { app_fail("INVALID_ARGUMENT", "link requires sixteen lowercase hexadecimal digits"); }
    std::uint64_t link = 0U;
    for (const char c : link_text) {
        if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) {
            app_fail("INVALID_ARGUMENT", "noncanonical link");
        }
        link = (link << 4U) | static_cast<std::uint64_t>(c <= '9' ? c - '0' : c - 'a' + 10);
    }
    Options options{
        .serial = serial,
        .wire = {.mtu = static_cast<std::size_t>(number("--mtu", 256U, 4096U)),
                 .link = link,
                 .epoch = static_cast<std::uint32_t>(number("--epoch", 1U, 0xffffffffU)),
                 .frame_timeout_ms = number("--frame-timeout-ms", 100U, 60000U)},
        .queue_bytes = static_cast<std::size_t>(number("--queue-bytes", 1024U, 1'048'576U)),
        .queue_frames = static_cast<std::size_t>(number("--queue-frames", 1U, 256U)),
        .io_quantum = static_cast<std::size_t>(number("--io-quantum", 1U, serial_packet::kPumpBytes)),
    };
    options.wire.validate();
    const auto parity_bits = serial.parity == SerialParity::none ? 0U : 1U;
    const auto bits_per_character = static_cast<std::uint8_t>(
        1U + static_cast<unsigned>(serial.data_bits) + parity_bits +
        static_cast<unsigned>(serial.stop_bits));
    const auto minimum_frame_time_ms = serial_packet::minimum_transmit_time_ms(
        options.wire.mtu, serial.baud, bits_per_character);
    if (options.wire.frame_timeout_ms < minimum_frame_time_ms) {
        app_fail("SERIAL_PACKET_TIMEOUT_TOO_SHORT",
            "frame timeout " + std::to_string(options.wire.frame_timeout_ms) +
            "ms is shorter than the worst-case line serialization budget " +
            std::to_string(minimum_frame_time_ms) + "ms");
    }
    if (options.queue_bytes < serial_packet::maximum_wire_bytes(options.wire.mtu)) {
        app_fail("INVALID_ARGUMENT", "queue cannot hold one worst-case escaped frame");
    }
    return options;
}

void validate_protocol_endpoint() {
    const char* fd = std::getenv("NATRAV_ADAPTER_FD");
    const char* protocol = std::getenv("NATRAV_ADAPTER_PROTOCOL");
    if (fd == nullptr || protocol == nullptr || std::string_view(fd) != "3" ||
        std::string_view(protocol) != "NAPA0001") {
        app_fail("SERIAL_ADAPTER_ENDPOINT_REQUIRED", "requires supervised descriptor-3 NAPA0001 endpoint");
    }
    int type = 0;
    socklen_t length = sizeof(type);
    sockaddr_un address{};
    socklen_t address_length = sizeof(address);
    if (::getsockopt(kProtocolFd, SOL_SOCKET, SO_TYPE, &type, &length) != 0 ||
        type != SOCK_SEQPACKET ||
        ::getpeername(kProtocolFd, reinterpret_cast<sockaddr*>(&address), &address_length) != 0 ||
        address.sun_family != AF_UNIX) {
        app_fail("SERIAL_ADAPTER_ENDPOINT_REQUIRED", "descriptor 3 must be a connected Unix SOCK_SEQPACKET");
    }
    const int flags = ::fcntl(kProtocolFd, F_GETFL);
    if (flags < 0 || ::fcntl(kProtocolFd, F_SETFL, flags | O_NONBLOCK) != 0) {
        app_fail("SERIAL_ADAPTER_ENDPOINT_REQUIRED", "nonblocking endpoint setup failed");
    }
    const int buffer_bytes = 65536;
    if (::setsockopt(kProtocolFd, SOL_SOCKET, SO_SNDBUF, &buffer_bytes, sizeof(buffer_bytes)) != 0 ||
        ::setsockopt(kProtocolFd, SOL_SOCKET, SO_RCVBUF, &buffer_bytes, sizeof(buffer_bytes)) != 0) {
        app_fail("SERIAL_ADAPTER_ENDPOINT_REQUIRED", "socket buffer setup failed");
    }
}

Frame decode(const Bytes& bytes, const std::uint64_t expected) {
    if (bytes.size() < kNapaHeader || !std::equal(kMagic.begin(), kMagic.end(), bytes.begin()) ||
        bytes[9U] != 0U || bytes[10U] != 0U || bytes[11U] != 0U ||
        read(bytes, 12U, 8U) != expected || expected == 0U ||
        read(bytes, 24U, 4U) != 0U || read(bytes, 28U, 4U) != bytes.size() - kNapaHeader) {
        app_fail("SERIAL_ADAPTER_PROTOCOL_INVALID", "noncanonical request header");
    }
    const auto deadline = read(bytes, 20U, 4U);
    if (deadline == 0U || deadline > 60000U) {
        app_fail("SERIAL_ADAPTER_PROTOCOL_INVALID", "request deadline outside bounds");
    }
    Bytes checksum(bytes.begin(), bytes.begin() + 32);
    checksum.insert(checksum.end(), bytes.begin() + static_cast<std::ptrdiff_t>(kNapaHeader), bytes.end());
    if (serial_packet::crc32(checksum) != read(bytes, 32U, 4U)) {
        app_fail("SERIAL_ADAPTER_PROTOCOL_INVALID", "request checksum mismatch");
    }
    return Frame{.type = bytes[8U], .sequence = expected,
        .deadline_ms = static_cast<std::uint32_t>(deadline), .status = kOk,
        .payload = Bytes(bytes.begin() + static_cast<std::ptrdiff_t>(kNapaHeader), bytes.end())};
}
Bytes encode(const Frame& frame) {
    Bytes bytes(kMagic.begin(), kMagic.end());
    bytes.push_back(frame.type);
    append(bytes, 0U, 3U);
    append(bytes, frame.sequence, 8U);
    append(bytes, frame.deadline_ms, 4U);
    append(bytes, frame.status, 4U);
    append(bytes, frame.payload.size(), 4U);
    Bytes checksum(bytes);
    checksum.insert(checksum.end(), frame.payload.begin(), frame.payload.end());
    append(bytes, serial_packet::crc32(checksum), 4U);
    bytes.insert(bytes.end(), frame.payload.begin(), frame.payload.end());
    return bytes;
}
void send_response(const Frame& frame, const Deadline deadline) {
    const auto bytes = encode(frame);
    while (Clock::now() < deadline) {
        const auto count = ::send(kProtocolFd, bytes.data(), bytes.size(), MSG_DONTWAIT | MSG_NOSIGNAL);
        if (count == static_cast<ssize_t>(bytes.size())) { return; }
        if (count >= 0) { app_fail("SERIAL_ADAPTER_PROTOCOL_INVALID", "partial datagram send"); }
        if (errno != EINTR && errno != EAGAIN && errno != EWOULDBLOCK) {
            app_fail("SERIAL_ADAPTER_PROTOCOL_CLOSED", "local response endpoint closed");
        }
        pollfd item{.fd = kProtocolFd, .events = POLLOUT, .revents = 0};
        const auto result = ::poll(&item, 1U, 1);
        if (result < 0 && errno != EINTR) { app_fail("SERIAL_ADAPTER_PROTOCOL_CLOSED", "local endpoint poll failed"); }
    }
    app_fail("SERIAL_ADAPTER_RESPONSE_TIMEOUT", "local response deadline expired");
}

struct Pending final {
    Bytes bytes;
    std::size_t offset{0U};
    Deadline expiry;
};
class Adapter final {
public:
    explicit Adapter(Options options)
        : options_(std::move(options)), decoder_(options_.wire),
          serial_(open_serial_packet_stream(options_.serial, Clock::now() + Milliseconds(2000))) {}
    int run() {
        std::uint64_t sequence = 1U;
        bool hello = false;
        const Deadline hello_deadline = Clock::now() + Milliseconds(2000);
        Bytes buffer(kNapaHeader + std::max(options_.wire.mtu, std::size_t{20U}));
        while (true) {
            if (!hello && Clock::now() >= hello_deadline) { app_fail("SERIAL_ADAPTER_HELLO_TIMEOUT", "HELLO absent"); }
            // Progress is independent of RECEIVE requests. No worker, signal
            // handler, thread, unbounded queue, retransmitter or peer protocol
            // is hidden in this child. Each turn performs two bounded TTY ops.
            if (hello) { pump(); }
            iovec io{.iov_base = buffer.data(), .iov_len = buffer.size()};
            msghdr message{};
            message.msg_iov = &io;
            message.msg_iovlen = 1U;
            const auto count = ::recvmsg(kProtocolFd, &message, MSG_DONTWAIT);
            if (count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)) {
                if (!hello) { pollfd item{.fd=kProtocolFd, .events=POLLIN, .revents=0}; static_cast<void>(::poll(&item, 1U, 1)); }
                continue;
            }
            if (count == 0) { return 0; }
            if (count < 0 || (message.msg_flags & (MSG_TRUNC | MSG_CTRUNC)) != 0) {
                app_fail("SERIAL_ADAPTER_PROTOCOL_INVALID", "truncated/failed local datagram");
            }
            const Bytes bytes(buffer.begin(), buffer.begin() + count);
            // The supervisor sequence survives bounded startup retries. A new
            // child accepts its first nonzero sequence, then requires exact
            // succession; it must not assume the supervisor restarted at one.
            if (!hello) { sequence = read(bytes, 12U, 8U); }
            const auto request = decode(bytes, sequence);
            if (sequence == std::numeric_limits<std::uint64_t>::max()) {
                app_fail("SERIAL_ADAPTER_SEQUENCE_EXHAUSTED", "finite request sequence exhausted");
            }
            ++sequence;
            const auto deadline = Clock::now() + Milliseconds(std::min(request.deadline_ms, 500U));
            Frame reply{.type = static_cast<std::uint8_t>(request.type + 1U),
                .sequence = request.sequence, .deadline_ms = 0U, .status = kOk, .payload = {}};
            bool stop = false;
            if (!hello) {
                if (request.type != 1U || request.payload.size() != 20U ||
                    read(request.payload, 0U, 4U) != 1U ||
                    read(request.payload, 4U, 4U) != options_.wire.mtu ||
                    read(request.payload, 8U, 4U) < kNapaHeader + options_.wire.mtu ||
                    read(request.payload, 12U, 4U) < options_.queue_bytes ||
                    read(request.payload, 16U, 4U) != 1U) {
                    app_fail("SERIAL_ADAPTER_CAPABILITY_MISMATCH", "HELLO does not admit exact MTU and finite queues");
                }
                append(reply.payload, 1U, 4U);
                append(reply.payload, options_.wire.mtu, 4U);
                append(reply.payload, kNapaHeader + options_.wire.mtu, 4U);
                append(reply.payload, options_.queue_bytes, 4U);
                append(reply.payload, 1U, 4U);
                hello = true;
            } else if (request.type == 3U) {
                if (request.payload.empty() || request.payload.size() > options_.wire.mtu) {
                    app_fail("SERIAL_ADAPTER_PROTOCOL_INVALID", "transmit outside MTU");
                }
                auto wire = serial_packet::encode(options_.wire, request.payload);
                if (tx_.size() + rx_.size() == options_.queue_frames || wire.size() > options_.queue_bytes - queued_) {
                    reply.status = kBusy;
                } else {
                    queued_ += wire.size();
                    tx_.push_back(Pending{.bytes=std::move(wire), .offset=0U,
                        .expiry=Clock::now() + Milliseconds(options_.wire.frame_timeout_ms)});
                }
            } else if (request.type == 5U && request.payload.empty()) {
                if (rx_.empty()) { reply.status = kNoData; }
                else {
                    queued_ -= rx_.front().size();
                    reply.payload = std::move(rx_.front());
                    rx_.pop_front();
                }
            } else if ((request.type == 7U || request.type == 9U) && request.payload.empty()) {
                stop = request.type == 9U;
            } else { app_fail("SERIAL_ADAPTER_PROTOCOL_INVALID", "unexpected type or payload"); }
            send_response(reply, deadline);
            // This is local endpoint release, not a remote delivery assertion.
            // Finite packet FIN, TLS and NOS1 close remain above the adapter.
            if (stop) { return 0; }
        }
    }
private:
    void pump() {
        decoder_.expire(now_ms());
        if (!tx_.empty()) {
            auto& front = tx_.front();
            if (Clock::now() >= front.expiry) {
                app_fail("SERIAL_ADAPTER_TRANSMIT_TIMEOUT", "queued serial frame expired");
            }
            const auto bytes = std::span<const std::uint8_t>(front.bytes).subspan(front.offset);
            try {
                const auto n = serial_->write_some(bytes.first(std::min(bytes.size(), options_.io_quantum)),
                    Clock::now() + Milliseconds(1), counters_, "serial packet write");
                front.offset += n;
                // Count complete backing buffers, not just unsent tails.
                if (front.offset == front.bytes.size()) { queued_ -= front.bytes.size(); tx_.pop_front(); }
            } catch (const AppError& e) { if (e.code() != "IO_TIMEOUT") { throw; } }
        }
        std::array<std::uint8_t, serial_packet::kPumpBytes> bytes{};
        try {
            const auto n = serial_->read_some(std::span<std::uint8_t>(bytes).first(options_.io_quantum),
                Clock::now() + Milliseconds(1), counters_, "serial packet read");
            if (n == 0U) { app_fail("SERIAL_DISCONNECTED", "serial EOF"); }
            const auto tick = now_ms();
            for (std::size_t i = 0U; i < n; ++i) {
                auto packet = decoder_.consume(bytes[i], tick);
                if (!packet) { continue; }
                if (tx_.size() + rx_.size() == options_.queue_frames || packet->size() > options_.queue_bytes - queued_) {
                    // Whole datagram loss under declared receive pressure. The
                    // finite packet service above owns retransmission, not us.
                    continue;
                }
                queued_ += packet->size();
                rx_.push_back(std::move(*packet));
            }
        } catch (const AppError& e) { if (e.code() != "IO_TIMEOUT") { throw; } }
    }
    Options options_;
    serial_packet::Decoder decoder_;
    std::unique_ptr<OrderedByteStream> serial_;
    IoCounters counters_{};
    std::deque<Pending> tx_{};
    std::deque<Bytes> rx_{};
    std::size_t queued_{0U};
};
}  // namespace
int run_serial_packet_adapter(const int argc, char* argv[]) {
    auto options = parse_options(argc, argv);
    validate_protocol_endpoint();
    return Adapter(std::move(options)).run();
}
}  // namespace natrav_overlay
