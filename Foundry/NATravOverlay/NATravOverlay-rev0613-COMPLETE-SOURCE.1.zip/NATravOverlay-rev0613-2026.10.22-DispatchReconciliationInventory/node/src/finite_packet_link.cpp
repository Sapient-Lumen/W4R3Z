#include "finite_packet_link.hpp"

#include <algorithm>
#include <array>
#include <limits>
#include <tuple>

namespace natrav::packet_link {

int finite_packet_link_revision_abi() noexcept { return 1; }

namespace {

constexpr std::array<std::uint8_t, 4U> kFrameMagic{'N', 'P', 'L', '1'};
constexpr std::array<std::uint8_t, 8U> kScheduleMagic{'N', 'P', 'L', 'S', '0', '0', '0', '1'};
constexpr std::array<std::uint8_t, 8U> kTraceMagic{'N', 'P', 'L', 'T', '0', '0', '0', '1'};
constexpr std::uint8_t kFrameVersion = 1U;

void put_u16(Bytes& out, std::size_t offset, std::uint16_t value) {
    out.at(offset) = static_cast<std::uint8_t>((value >> 8U) & 0xffU);
    out.at(offset + 1U) = static_cast<std::uint8_t>(value & 0xffU);
}

void put_u32(Bytes& out, std::size_t offset, std::uint32_t value) {
    out.at(offset) = static_cast<std::uint8_t>((value >> 24U) & 0xffU);
    out.at(offset + 1U) = static_cast<std::uint8_t>((value >> 16U) & 0xffU);
    out.at(offset + 2U) = static_cast<std::uint8_t>((value >> 8U) & 0xffU);
    out.at(offset + 3U) = static_cast<std::uint8_t>(value & 0xffU);
}

void put_u64(Bytes& out, std::size_t offset, std::uint64_t value) {
    for (std::size_t i = 0U; i < 8U; ++i) {
        const auto shift = static_cast<unsigned>((7U - i) * 8U);
        out.at(offset + i) = static_cast<std::uint8_t>((value >> shift) & 0xffU);
    }
}

[[nodiscard]] std::uint16_t get_u16(std::span<const std::uint8_t> in,
                                    std::size_t offset) noexcept {
    return static_cast<std::uint16_t>((static_cast<std::uint16_t>(in[offset]) << 8U) |
                                      static_cast<std::uint16_t>(in[offset + 1U]));
}

[[nodiscard]] std::uint32_t get_u32(std::span<const std::uint8_t> in,
                                    std::size_t offset) noexcept {
    return (static_cast<std::uint32_t>(in[offset]) << 24U) |
           (static_cast<std::uint32_t>(in[offset + 1U]) << 16U) |
           (static_cast<std::uint32_t>(in[offset + 2U]) << 8U) |
           static_cast<std::uint32_t>(in[offset + 3U]);
}

[[nodiscard]] std::uint64_t get_u64(std::span<const std::uint8_t> in,
                                    std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t i = 0U; i < 8U; ++i) {
        value = (value << 8U) | static_cast<std::uint64_t>(in[offset + i]);
    }
    return value;
}

[[nodiscard]] bool frame_is_canonical(const Frame& frame) noexcept {
    if (frame.stream_id == 0U || frame.epoch == 0U || frame.sequence == 0U) {
        return false;
    }
    if (frame.payload.size() > std::numeric_limits<std::uint16_t>::max()) {
        return false;
    }
    switch (frame.kind) {
        case FrameKind::data:
            return frame.message_id != 0U && frame.fragment_count != 0U &&
                   frame.fragment_index < frame.fragment_count && !frame.payload.empty();
        case FrameKind::acknowledgement:
            return frame.message_id == 0U && frame.fragment_index == 0U &&
                   frame.fragment_count == 0U && frame.payload.empty();
        case FrameKind::finish:
            return frame.message_id != 0U && frame.fragment_index == 0U &&
                   frame.fragment_count == 0U && frame.payload.empty();
        case FrameKind::reset:
            return frame.message_id == 0U && frame.fragment_index == 0U &&
                   frame.fragment_count == 0U && frame.payload.empty();
    }
    return false;
}

[[nodiscard]] std::uint8_t disposition_for(FaultAction action) noexcept {
    return static_cast<std::uint8_t>(action);
}

}  // namespace

std::uint32_t FrameCodec::crc32(std::span<const std::uint8_t> bytes) noexcept {
    std::uint32_t crc = 0xffffffffU;
    for (const auto byte : bytes) {
        crc ^= static_cast<std::uint32_t>(byte);
        for (unsigned bit = 0U; bit < 8U; ++bit) {
            const std::uint32_t mask = 0U - (crc & 1U);
            crc = (crc >> 1U) ^ (0xedb88320U & mask);
        }
    }
    return ~crc;
}

Bytes FrameCodec::encode(const Frame& frame) {
    if (!frame_is_canonical(frame)) {
        throw std::invalid_argument("packet-link frame is not canonical");
    }
    Bytes out(kFrameHeaderSize + frame.payload.size(), 0U);
    std::copy(kFrameMagic.begin(), kFrameMagic.end(), out.begin());
    out[4U] = kFrameVersion;
    out[5U] = static_cast<std::uint8_t>(frame.kind);
    out[6U] = 0U;
    out[7U] = 0U;
    put_u64(out, 8U, frame.stream_id);
    put_u32(out, 16U, frame.epoch);
    put_u32(out, 20U, frame.sequence);
    put_u32(out, 24U, frame.message_id);
    put_u16(out, 28U, frame.fragment_index);
    put_u16(out, 30U, frame.fragment_count);
    put_u16(out, 32U, static_cast<std::uint16_t>(frame.payload.size()));
    put_u16(out, 34U, 0U);
    std::copy(frame.payload.begin(), frame.payload.end(), out.begin() +
              static_cast<std::ptrdiff_t>(kFrameHeaderSize));
    put_u32(out, 36U, crc32(out));
    return out;
}

DecodeResult FrameCodec::decode(std::span<const std::uint8_t> bytes) noexcept {
    DecodeResult result{};
    if (bytes.size() < kFrameHeaderSize) {
        result.error = DecodeError::too_short;
        return result;
    }
    if (!std::equal(kFrameMagic.begin(), kFrameMagic.end(), bytes.begin())) {
        result.error = DecodeError::wrong_magic;
        return result;
    }
    if (bytes[4U] != kFrameVersion) {
        result.error = DecodeError::wrong_version;
        return result;
    }
    if (bytes[6U] != 0U || bytes[7U] != 0U || get_u16(bytes, 34U) != 0U) {
        result.error = DecodeError::noncanonical;
        return result;
    }
    const auto payload_size = static_cast<std::size_t>(get_u16(bytes, 32U));
    if (bytes.size() != kFrameHeaderSize + payload_size) {
        result.error = DecodeError::length_mismatch;
        return result;
    }
    Bytes for_crc(bytes.begin(), bytes.end());
    const auto supplied_crc = get_u32(bytes, 36U);
    std::fill(for_crc.begin() + 36, for_crc.begin() + 40, 0U);
    if (crc32(for_crc) != supplied_crc) {
        result.error = DecodeError::integrity_failure;
        return result;
    }
    const auto raw_kind = bytes[5U];
    if (raw_kind < static_cast<std::uint8_t>(FrameKind::data) ||
        raw_kind > static_cast<std::uint8_t>(FrameKind::reset)) {
        result.error = DecodeError::noncanonical;
        return result;
    }
    Frame frame{};
    frame.kind = static_cast<FrameKind>(raw_kind);
    frame.stream_id = get_u64(bytes, 8U);
    frame.epoch = get_u32(bytes, 16U);
    frame.sequence = get_u32(bytes, 20U);
    frame.message_id = get_u32(bytes, 24U);
    frame.fragment_index = get_u16(bytes, 28U);
    frame.fragment_count = get_u16(bytes, 30U);
    frame.payload.assign(bytes.begin() + static_cast<std::ptrdiff_t>(kFrameHeaderSize),
                         bytes.end());
    if (!frame_is_canonical(frame)) {
        result.error = DecodeError::noncanonical;
        return result;
    }
    result.frame = std::move(frame);
    return result;
}

void Limits::validate() const {
    if (mtu <= kFrameHeaderSize || mtu > 65535U) {
        throw std::invalid_argument("packet-link MTU is outside the finite canonical range");
    }
    if (max_message_bytes == 0U || max_message_bytes > 16U * 1024U * 1024U) {
        throw std::invalid_argument("packet-link maximum message size is invalid");
    }
    if (max_reassembly_bytes < max_message_bytes ||
        max_reassembly_bytes > 64U * 1024U * 1024U) {
        throw std::invalid_argument("packet-link reassembly bound is invalid");
    }
    if (max_delivery_bytes == 0U || max_delivery_bytes > 64U * 1024U * 1024U) {
        throw std::invalid_argument("packet-link delivery bound is invalid");
    }
    if (max_inflight_frames == 0U || max_inflight_frames > 65535U ||
        max_control_frames == 0U || max_control_frames > 65535U ||
        max_receive_packets_per_pump == 0U || max_receive_packets_per_pump > 65535U) {
        throw std::invalid_argument("packet-link queue bound is invalid");
    }
    if (retransmit_after_ticks == 0U || retry_limit == 0U ||
        message_expiry_ticks == 0U) {
        throw std::invalid_argument("packet-link time/retry bound is invalid");
    }
}

FinitePacketStream::FinitePacketStream(PacketPort& port,
                                       std::uint64_t stream_id,
                                       std::uint32_t epoch,
                                       Limits limits)
    : port_(port), stream_id_(stream_id), epoch_(epoch), limits_(limits) {
    limits_.validate();
    if (stream_id_ == 0U) {
        throw std::invalid_argument("packet-link stream identifier must be nonzero");
    }
}

bool FinitePacketStream::queue_message(std::span<const std::uint8_t> message,
                                       std::uint64_t now_tick) {
    if (failed_ || epoch_ == 0U || local_finish_queued_ || message.empty() ||
        message.size() > limits_.max_message_bytes) {
        return false;
    }
    const auto payload_limit = limits_.max_payload_bytes();
    const auto fragment_count_size =
        (message.size() + payload_limit - 1U) / payload_limit;
    if (fragment_count_size == 0U ||
        fragment_count_size > std::numeric_limits<std::uint16_t>::max() ||
        fragment_count_size > limits_.max_inflight_frames -
                                  std::min(limits_.max_inflight_frames, outbound_.size())) {
        return false;
    }
    if (next_tx_message_ == 0U || next_tx_sequence_ == 0U ||
        fragment_count_size >
            static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max() -
                                     next_tx_sequence_) + 1U) {
        return false;
    }
    const auto message_id = next_tx_message_++;
    const auto fragment_count = static_cast<std::uint16_t>(fragment_count_size);
    std::size_t offset = 0U;
    for (std::uint16_t index = 0U; index < fragment_count; ++index) {
        const auto amount = std::min(payload_limit, message.size() - offset);
        Frame frame{};
        frame.kind = FrameKind::data;
        frame.stream_id = stream_id_;
        frame.epoch = epoch_;
        frame.sequence = next_tx_sequence_++;
        frame.message_id = message_id;
        frame.fragment_index = index;
        frame.fragment_count = fragment_count;
        frame.payload.assign(message.begin() + static_cast<std::ptrdiff_t>(offset),
                             message.begin() + static_cast<std::ptrdiff_t>(offset + amount));
        OutboundFrame outbound{};
        outbound.frame = frame;
        outbound.encoded = FrameCodec::encode(frame);
        outbound.created_tick = now_tick;
        outbound_.emplace(frame.sequence, std::move(outbound));
        offset += amount;
    }
    stats_.accepted_application_bytes += message.size();
    return true;
}

bool FinitePacketStream::queue_finish(std::uint64_t now_tick) {
    if (failed_ || epoch_ == 0U || local_finish_queued_ || outbound_.size() >= limits_.max_inflight_frames ||
        next_tx_sequence_ == 0U || next_tx_message_ == 0U) {
        return false;
    }
    Frame frame{};
    frame.kind = FrameKind::finish;
    frame.stream_id = stream_id_;
    frame.epoch = epoch_;
    frame.sequence = next_tx_sequence_++;
    frame.message_id = next_tx_message_;
    OutboundFrame outbound{};
    outbound.frame = frame;
    outbound.encoded = FrameCodec::encode(frame);
    outbound.created_tick = now_tick;
    outbound.finish = true;
    outbound_.emplace(frame.sequence, std::move(outbound));
    local_finish_queued_ = true;
    return true;
}

void FinitePacketStream::pump(std::uint64_t now_tick) {
    if (tick_seen_ && now_tick < last_tick_) {
        throw std::invalid_argument("packet-link time cannot move backward");
    }
    tick_seen_ = true;
    last_tick_ = now_tick;
    if (failed_) {
        return;
    }
    process_received(now_tick);
    expire_reassembly(now_tick);
    send_control_frames();
    send_due_frames(now_tick);
}

std::size_t FinitePacketStream::read_some(std::span<std::uint8_t> destination) {
    const auto amount = std::min(destination.size(), delivered_bytes_.size());
    for (std::size_t i = 0U; i < amount; ++i) {
        destination[i] = delivered_bytes_.front();
        delivered_bytes_.pop_front();
    }
    deliver_completed_in_order();
    return amount;
}

bool FinitePacketStream::read_eof() const noexcept {
    return remote_finish_after_message_.has_value() &&
           next_rx_message_ >= *remote_finish_after_message_ &&
           delivered_bytes_.empty() && completed_messages_.empty() && reassembly_.empty();
}

void FinitePacketStream::process_received(std::uint64_t now_tick) {
    for (std::size_t count = 0U; count < limits_.max_receive_packets_per_pump; ++count) {
        auto packet = port_.receive_packet();
        if (!packet.has_value()) {
            break;
        }
        ++stats_.packets_received;
        if (packet->size() > limits_.mtu) {
            ++stats_.malformed_packets;
            continue;
        }
        const auto decoded = FrameCodec::decode(*packet);
        if (!decoded.ok()) {
            ++stats_.malformed_packets;
            if (decoded.error == DecodeError::integrity_failure) {
                ++stats_.integrity_failures;
            }
            continue;
        }
        if (!same_link(decoded.frame)) {
            ++stats_.wrong_stream_packets;
            continue;
        }
        process_frame(decoded.frame, now_tick);
        if (failed_) {
            return;
        }
    }
}

void FinitePacketStream::process_frame(const Frame& frame, std::uint64_t now_tick) {
    switch (frame.kind) {
        case FrameKind::acknowledgement: {
            ++stats_.acknowledgements_received;
            const auto found = outbound_.find(frame.sequence);
            if (found != outbound_.end()) {
                if (found->second.finish) {
                    local_finish_acknowledged_ = true;
                }
                outbound_.erase(found);
            }
            return;
        }
        case FrameKind::reset:
            ++stats_.resets_received;
            fail("remote packet-link reset");
            return;
        case FrameKind::finish:
            queue_ack(frame.sequence);
            if (!remote_finish_after_message_.has_value()) {
                remote_finish_after_message_ = frame.message_id;
            } else if (*remote_finish_after_message_ != frame.message_id) {
                queue_reset();
                fail("conflicting remote finish boundary");
            }
            return;
        case FrameKind::data:
            break;
    }

    if (seen_data_sequences_.contains(frame.sequence)) {
        queue_ack(frame.sequence);
        ++stats_.duplicate_data_packets;
        return;
    }
    if (frame.message_id < next_rx_message_ || completed_messages_.contains(frame.message_id)) {
        queue_ack(frame.sequence);
        ++stats_.duplicate_data_packets;
        return;
    }
    if (remote_finish_after_message_.has_value() &&
        frame.message_id >= *remote_finish_after_message_) {
        queue_reset();
        fail("data arrived at or beyond remote finish boundary");
        return;
    }
    auto found = reassembly_.find(frame.message_id);
    if (found == reassembly_.end()) {
        Reassembly state{};
        state.fragment_count = frame.fragment_count;
        state.fragments.resize(frame.fragment_count);
        state.created_tick = now_tick;
        found = reassembly_.emplace(frame.message_id, std::move(state)).first;
    }
    auto& state = found->second;
    if (state.fragment_count != frame.fragment_count ||
        frame.fragment_index >= state.fragments.size()) {
        queue_reset();
        fail("conflicting packet-link fragmentation metadata");
        return;
    }
    auto& slot = state.fragments[frame.fragment_index];
    if (slot.has_value()) {
        if (*slot != frame.payload) {
            queue_reset();
            fail("conflicting duplicate packet-link fragment");
        } else {
            queue_ack(frame.sequence);
            ++stats_.duplicate_data_packets;
        }
        return;
    }
    if (frame.payload.size() > limits_.max_message_bytes -
                                   std::min(limits_.max_message_bytes, state.bytes)) {
        queue_reset();
        fail("packet-link message size bound exceeded");
        return;
    }
    if (frame.payload.size() > limits_.max_reassembly_bytes -
                                   std::min(limits_.max_reassembly_bytes,
                                            reassembly_bytes_)) {
        queue_reset();
        fail("packet-link reassembly memory bound exceeded");
        return;
    }
    seen_data_sequences_.insert(frame.sequence);
    seen_data_order_.push_back(frame.sequence);
    const auto seen_limit = limits_.max_inflight_frames + limits_.max_control_frames;
    while (seen_data_order_.size() > seen_limit) {
        seen_data_sequences_.erase(seen_data_order_.front());
        seen_data_order_.pop_front();
    }
    slot = frame.payload;
    state.bytes += frame.payload.size();
    reassembly_bytes_ += frame.payload.size();
    queue_ack(frame.sequence);
    const bool complete = std::all_of(state.fragments.begin(), state.fragments.end(),
                                      [](const auto& fragment) { return fragment.has_value(); });
    if (!complete) {
        return;
    }
    Bytes message{};
    message.reserve(state.bytes);
    for (const auto& fragment : state.fragments) {
        message.insert(message.end(), fragment->begin(), fragment->end());
    }
    reassembly_.erase(found);
    completed_messages_.emplace(frame.message_id, std::move(message));
    deliver_completed_in_order();
}

void FinitePacketStream::expire_reassembly(std::uint64_t now_tick) {
    for (auto it = reassembly_.begin(); it != reassembly_.end();) {
        if (now_tick - it->second.created_tick >= limits_.message_expiry_ticks) {
            reassembly_bytes_ -= it->second.bytes;
            it = reassembly_.erase(it);
            ++stats_.expired_messages;
        } else {
            ++it;
        }
    }
}

void FinitePacketStream::send_control_frames() {
    std::size_t remaining = control_frames_.size();
    while (remaining-- > 0U && !control_frames_.empty()) {
        const Frame frame = control_frames_.front();
        const auto encoded = FrameCodec::encode(frame);
        if (!port_.send_packet(encoded)) {
            ++stats_.backpressure_events;
            break;
        }
        control_frames_.pop_front();
        ++stats_.packets_sent;
        if (frame.kind == FrameKind::acknowledgement) {
            queued_ack_sequences_.erase(frame.sequence);
            ++stats_.acknowledgements_sent;
        }
    }
}

void FinitePacketStream::send_due_frames(std::uint64_t now_tick) {
    for (auto& [sequence, outbound] : outbound_) {
        (void)sequence;
        if (now_tick < outbound.created_tick) {
            continue;
        }
        if (outbound.attempts != 0U &&
            now_tick - outbound.last_attempt_tick < limits_.retransmit_after_ticks) {
            continue;
        }
        if (now_tick - outbound.created_tick >= limits_.message_expiry_ticks ||
            outbound.attempts >= limits_.retry_limit) {
            ++stats_.expired_messages;
            queue_reset();
            fail("packet-link retransmission budget exhausted");
            return;
        }
        if (!port_.send_packet(outbound.encoded)) {
            ++stats_.backpressure_events;
            continue;
        }
        if (outbound.attempts != 0U) {
            ++stats_.retransmissions;
        }
        ++outbound.attempts;
        outbound.last_attempt_tick = now_tick;
        ++stats_.packets_sent;
    }
}

void FinitePacketStream::queue_ack(std::uint32_t sequence) {
    if (queued_ack_sequences_.contains(sequence)) {
        return;
    }
    if (control_frames_.size() >= limits_.max_control_frames) {
        fail("packet-link control queue bound exceeded");
        return;
    }
    Frame ack{};
    ack.kind = FrameKind::acknowledgement;
    ack.stream_id = stream_id_;
    ack.epoch = epoch_;
    ack.sequence = sequence;
    control_frames_.push_back(ack);
    queued_ack_sequences_.insert(sequence);
}

void FinitePacketStream::queue_reset() {
    if (control_frames_.size() >= limits_.max_control_frames) {
        return;
    }
    Frame reset{};
    reset.kind = FrameKind::reset;
    reset.stream_id = stream_id_;
    reset.epoch = epoch_;
    reset.sequence = next_tx_sequence_ == 0U ? 1U : next_tx_sequence_++;
    control_frames_.push_back(reset);
}

void FinitePacketStream::deliver_completed_in_order() {
    while (true) {
        auto found = completed_messages_.find(next_rx_message_);
        if (found == completed_messages_.end()) {
            break;
        }
        if (found->second.size() > limits_.max_delivery_bytes -
                                      std::min(limits_.max_delivery_bytes,
                                               delivered_bytes_.size())) {
            break;
        }
        for (const auto byte : found->second) {
            delivered_bytes_.push_back(byte);
        }
        stats_.delivered_application_bytes += found->second.size();
        reassembly_bytes_ -= found->second.size();
        completed_messages_.erase(found);
        ++next_rx_message_;
        if (next_rx_message_ == 0U) {
            fail("packet-link receive message sequence exhausted");
            return;
        }
    }
}

void FinitePacketStream::fail(std::string reason) {
    if (!failed_) {
        failed_ = true;
        failure_reason_ = std::move(reason);
    }
}

bool FinitePacketStream::same_link(const Frame& frame) noexcept {
    if (frame.stream_id != stream_id_ || frame.epoch == 0U) {
        return false;
    }
    if (epoch_ == 0U) {
        epoch_ = frame.epoch;
        return true;
    }
    return frame.epoch == epoch_;
}

FaultSchedule::FaultSchedule(std::vector<FaultRule> rules) : rules_(std::move(rules)) {
    if (rules_.size() > 65535U) {
        throw std::invalid_argument("packet-link fault schedule bound exceeded");
    }
    std::sort(rules_.begin(), rules_.end(), [](const auto& left, const auto& right) {
        return std::tie(left.direction, left.ordinal) <
               std::tie(right.direction, right.ordinal);
    });
    for (std::size_t i = 0U; i < rules_.size(); ++i) {
        const auto& rule = rules_[i];
        if (rule.ordinal == 0U ||
            static_cast<std::uint8_t>(rule.action) <
                static_cast<std::uint8_t>(FaultAction::drop) ||
            static_cast<std::uint8_t>(rule.action) >
                static_cast<std::uint8_t>(FaultAction::reorder)) {
            throw std::invalid_argument("invalid packet-link fault rule");
        }
        if (i != 0U && rules_[i - 1U].direction == rule.direction &&
            rules_[i - 1U].ordinal == rule.ordinal) {
            throw std::invalid_argument("duplicate packet-link fault rule");
        }
    }
}

std::optional<FaultRule> FaultSchedule::find(Direction direction,
                                             std::uint64_t ordinal) const noexcept {
    const auto found = std::lower_bound(
        rules_.begin(), rules_.end(), std::pair{direction, ordinal},
        [](const FaultRule& rule, const auto& key) {
            return std::pair{rule.direction, rule.ordinal} < key;
        });
    if (found != rules_.end() && found->direction == direction && found->ordinal == ordinal) {
        return *found;
    }
    return std::nullopt;
}

Bytes FaultSchedule::encode() const {
    if (rules_.size() > std::numeric_limits<std::uint32_t>::max()) {
        throw std::length_error("packet-link schedule too large");
    }
    Bytes out(12U + rules_.size() * 16U + 4U, 0U);
    std::copy(kScheduleMagic.begin(), kScheduleMagic.end(), out.begin());
    put_u32(out, 8U, static_cast<std::uint32_t>(rules_.size()));
    std::size_t offset = 12U;
    for (const auto& rule : rules_) {
        out[offset] = static_cast<std::uint8_t>(rule.direction);
        out[offset + 1U] = static_cast<std::uint8_t>(rule.action);
        put_u16(out, offset + 2U, 0U);
        put_u64(out, offset + 4U, rule.ordinal);
        put_u32(out, offset + 12U, rule.argument);
        offset += 16U;
    }
    put_u32(out, out.size() - 4U,
            FrameCodec::crc32(std::span<const std::uint8_t>(out).first(out.size() - 4U)));
    return out;
}

std::optional<FaultSchedule> FaultSchedule::decode(
    std::span<const std::uint8_t> bytes) noexcept {
    try {
        if (bytes.size() < 16U ||
            !std::equal(kScheduleMagic.begin(), kScheduleMagic.end(), bytes.begin())) {
            return std::nullopt;
        }
        const auto count = static_cast<std::size_t>(get_u32(bytes, 8U));
        if (count > (std::numeric_limits<std::size_t>::max() - 16U) / 16U ||
            bytes.size() != 12U + count * 16U + 4U) {
            return std::nullopt;
        }
        if (FrameCodec::crc32(bytes.first(bytes.size() - 4U)) !=
            get_u32(bytes, bytes.size() - 4U)) {
            return std::nullopt;
        }
        std::vector<FaultRule> rules{};
        rules.reserve(count);
        std::size_t offset = 12U;
        for (std::size_t i = 0U; i < count; ++i) {
            if (get_u16(bytes, offset + 2U) != 0U || bytes[offset] > 1U ||
                bytes[offset + 1U] < static_cast<std::uint8_t>(FaultAction::drop) ||
                bytes[offset + 1U] > static_cast<std::uint8_t>(FaultAction::reorder)) {
                return std::nullopt;
            }
            FaultRule rule{};
            rule.direction = static_cast<Direction>(bytes[offset]);
            rule.action = static_cast<FaultAction>(bytes[offset + 1U]);
            rule.ordinal = get_u64(bytes, offset + 4U);
            rule.argument = get_u32(bytes, offset + 12U);
            rules.push_back(rule);
            offset += 16U;
        }
        FaultSchedule schedule{std::move(rules)};
        const auto canonical = schedule.encode();
        if (canonical.size() != bytes.size() ||
            !std::equal(canonical.begin(), canonical.end(), bytes.begin())) {
            return std::nullopt;
        }
        return schedule;
    } catch (...) {
        return std::nullopt;
    }
}

DeterministicPacketNetwork::Endpoint::Endpoint(DeterministicPacketNetwork& network,
                                                bool side_a) noexcept
    : network_(network), side_a_(side_a) {}

bool DeterministicPacketNetwork::Endpoint::send_packet(const Bytes& packet) {
    return network_.send(side_a_, packet);
}

std::optional<Bytes> DeterministicPacketNetwork::Endpoint::receive_packet() {
    return network_.receive(side_a_);
}

DeterministicPacketNetwork::DeterministicPacketNetwork(FaultSchedule schedule,
                                                         std::size_t queue_capacity_packets,
                                                         std::size_t trace_capacity_events)
    : schedule_(std::move(schedule)),
      capacity_(queue_capacity_packets),
      trace_capacity_(trace_capacity_events),
      endpoint_a_(*this, true),
      endpoint_b_(*this, false) {
    if (capacity_ == 0U || capacity_ > 1'000'000U ||
        trace_capacity_ == 0U || trace_capacity_ > 10'000'000U) {
        throw std::invalid_argument("invalid deterministic packet/trace capacity");
    }
}

void DeterministicPacketNetwork::advance_to(std::uint64_t tick) {
    if (tick < now_tick_) {
        throw std::invalid_argument("deterministic packet time cannot move backward");
    }
    now_tick_ = tick;
    release_due();
}

std::size_t DeterministicPacketNetwork::queued_packets() const noexcept {
    return scheduled_.size() + ready_for_a_.size() + ready_for_b_.size() +
           (held_a_to_b_.has_value() ? 1U : 0U) +
           (held_b_to_a_.has_value() ? 1U : 0U);
}

bool DeterministicPacketNetwork::send(bool from_a, const Bytes& packet) {
    if (packet.empty()) {
        return false;
    }
    const auto direction = from_a ? Direction::a_to_b : Direction::b_to_a;
    auto& ordinal_counter = from_a ? a_to_b_ordinal_ : b_to_a_ordinal_;
    const auto ordinal = ++ordinal_counter;
    const auto rule = schedule_.find(direction, ordinal);
    const auto action = rule.has_value() ? rule->action : FaultAction::delay;
    const auto argument = rule.has_value() ? rule->argument : 0U;
    auto& held_slot = direction == Direction::a_to_b ? held_a_to_b_ : held_b_to_a_;
    const bool had_held = held_slot.has_value();
    const std::size_t produced = action == FaultAction::drop ? 0U :
                                 action == FaultAction::duplicate ? 2U : 1U;
    if (produced > capacity_ - std::min(capacity_, queued_packets())) {
        return false;
    }

    std::optional<ScheduledPacket> prior_held{};
    if (had_held) {
        prior_held = std::move(held_slot);
        held_slot.reset();
    }
    std::uint64_t release_tick = now_tick_;

    if (action == FaultAction::drop) {
        record_trace(TraceEvent{direction, disposition_for(action), ordinal, now_tick_,
                                    static_cast<std::uint32_t>(packet.size()),
                                    FrameCodec::crc32(packet)});
    } else if (action == FaultAction::duplicate) {
        enqueue(direction, packet, now_tick_, disposition_for(action), ordinal);
        enqueue(direction, packet, now_tick_, disposition_for(action), ordinal);
    } else if (action == FaultAction::corrupt) {
        Bytes corrupted = packet;
        const auto index = static_cast<std::size_t>(argument) % corrupted.size();
        corrupted[index] ^= 0x01U;
        enqueue(direction, std::move(corrupted), now_tick_, disposition_for(action), ordinal);
    } else if (action == FaultAction::delay) {
        release_tick = now_tick_ + argument;
        enqueue(direction, packet, release_tick, disposition_for(action), ordinal);
    } else if (!had_held) {
        ScheduledPacket pending{};
        pending.direction = direction;
        pending.due_tick = now_tick_;
        pending.insertion_order = ++insertion_counter_;
        pending.bytes = packet;
        held_slot = std::move(pending);
        record_trace(TraceEvent{direction, disposition_for(action), ordinal, now_tick_,
                                    static_cast<std::uint32_t>(packet.size()),
                                    FrameCodec::crc32(packet)});
    } else {
        enqueue(direction, packet, now_tick_, disposition_for(action), ordinal);
    }

    if (prior_held.has_value()) {
        prior_held->due_tick = release_tick;
        prior_held->insertion_order = ++insertion_counter_;
        scheduled_.push_back(std::move(*prior_held));
    }
    release_due();
    return true;
}

std::optional<Bytes> DeterministicPacketNetwork::receive(bool for_a) {
    release_due();
    auto& queue = for_a ? ready_for_a_ : ready_for_b_;
    if (queue.empty()) {
        return std::nullopt;
    }
    Bytes packet = std::move(queue.front());
    queue.pop_front();
    return packet;
}

void DeterministicPacketNetwork::enqueue(Direction direction, Bytes packet,
                                         std::uint64_t due_tick,
                                         std::uint8_t disposition,
                                         std::uint64_t ordinal) {
    record_trace(TraceEvent{direction, disposition, ordinal, due_tick,
                                static_cast<std::uint32_t>(packet.size()),
                                FrameCodec::crc32(packet)});
    scheduled_.push_back(ScheduledPacket{direction, due_tick, ++insertion_counter_,
                                         std::move(packet)});
}

void DeterministicPacketNetwork::record_trace(TraceEvent event) {
    if (trace_.size() >= trace_capacity_) {
        throw std::length_error("deterministic packet trace bound exceeded");
    }
    trace_.push_back(std::move(event));
}

void DeterministicPacketNetwork::release_due() {
    std::stable_sort(scheduled_.begin(), scheduled_.end(),
                     [](const auto& left, const auto& right) {
                         return std::tie(left.due_tick, left.insertion_order) <
                                std::tie(right.due_tick, right.insertion_order);
                     });
    auto it = scheduled_.begin();
    while (it != scheduled_.end() && it->due_tick <= now_tick_) {
        auto& queue = it->direction == Direction::a_to_b ? ready_for_b_ : ready_for_a_;
        queue.push_back(std::move(it->bytes));
        ++it;
    }
    scheduled_.erase(scheduled_.begin(), it);
}

Bytes DeterministicPacketNetwork::encode_trace() const {
    if (trace_.size() > std::numeric_limits<std::uint32_t>::max()) {
        throw std::length_error("packet-link trace too large");
    }
    constexpr std::size_t event_size = 28U;
    Bytes out(12U + trace_.size() * event_size + 4U, 0U);
    std::copy(kTraceMagic.begin(), kTraceMagic.end(), out.begin());
    put_u32(out, 8U, static_cast<std::uint32_t>(trace_.size()));
    std::size_t offset = 12U;
    for (const auto& event : trace_) {
        out[offset] = static_cast<std::uint8_t>(event.direction);
        out[offset + 1U] = event.disposition;
        put_u16(out, offset + 2U, 0U);
        put_u64(out, offset + 4U, event.ordinal);
        put_u64(out, offset + 12U, event.due_tick);
        put_u32(out, offset + 20U, event.packet_size);
        put_u32(out, offset + 24U, event.packet_crc32);
        offset += event_size;
    }
    put_u32(out, out.size() - 4U,
            FrameCodec::crc32(std::span<const std::uint8_t>(out).first(out.size() - 4U)));
    return out;
}

}  // namespace natrav::packet_link
