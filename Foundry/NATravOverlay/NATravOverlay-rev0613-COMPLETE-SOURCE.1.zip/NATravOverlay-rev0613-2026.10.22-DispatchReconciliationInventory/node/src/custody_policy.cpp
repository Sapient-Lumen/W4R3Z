#include "custody_policy.hpp"

#include "adapter_configuration.hpp"

#include <algorithm>
#include <set>
#include <tuple>

namespace natrav_overlay {
namespace {

constexpr std::size_t kGrantTextLimit = 2'048U;

void require(bool condition, std::string_view code, std::string_view detail) {
    if (!condition) { app_fail(code, detail); }
}

void validate_grant(const CustodyRelayGrant& grant) {
    require(valid_generation_id(grant.id),
        "CONFIG_CUSTODY_GRANT_INVALID", "grant id is invalid");
    require(grant.generation > 0U &&
            grant.generation <= kCustodyRelayGrantPerIdLimit,
        "CONFIG_CUSTODY_GRANT_GENERATION",
        "grant generation is outside the retained bound");
    require(grant.state == CustodyRelayGrantState::active ||
            grant.state == CustodyRelayGrantState::retired ||
            grant.state == CustodyRelayGrantState::revoked,
        "CONFIG_CUSTODY_GRANT_STATE", "unknown grant lifecycle state");
    require(valid_node_id(grant.origin) &&
            valid_generation_id(grant.origin_signing_generation) &&
            valid_node_id(grant.final_recipient) &&
            valid_generation_id(grant.final_signing_generation) &&
            valid_node_id(grant.custodian) &&
            valid_generation_id(grant.custodian_signing_generation) &&
            valid_node_id(grant.next_hop) &&
            valid_generation_id(grant.next_hop_signing_generation),
        "CONFIG_CUSTODY_GRANT_INVALID",
        "grant identities and signing generations must be exact identifiers");
    require(grant.origin != grant.final_recipient &&
            grant.custodian != grant.next_hop,
        "CONFIG_CUSTODY_GRANT_INVALID",
        "grant endpoints must be distinct");
    require(grant.maximum_envelope_lifetime_ms > 0U &&
            grant.maximum_envelope_lifetime_ms <=
                kCustodyEnvelopeLifetimeLimitMs,
        "CONFIG_CUSTODY_GRANT_LIMIT",
        "grant lifetime is outside the custody-envelope bound");
    require(grant.maximum_hops > 0U &&
            grant.maximum_hops < kCustodyRoutePartyLimit,
        "CONFIG_CUSTODY_GRANT_LIMIT",
        "grant hop limit is outside the route bound");
    require(grant.maximum_active_envelopes > 0U &&
            grant.maximum_active_envelopes <=
                kCustodyRelayMaximumActiveLimit,
        "CONFIG_CUSTODY_GRANT_LIMIT",
        "grant active-envelope quota is outside bounds");
    require(grant.maximum_capsule_bytes > 0U &&
            grant.maximum_capsule_bytes <=
                kCustodyRelayMaximumBytesLimit,
        "CONFIG_CUSTODY_GRANT_LIMIT",
        "grant capsule-byte quota is outside bounds");
}

std::string field_value(
    const std::string& text,
    std::size_t& offset,
    std::string_view prefix) {
    const auto end = text.find('\n', offset);
    require(end != std::string::npos,
        "CONFIG_CUSTODY_GRANT_NONCANONICAL",
        "complete canonical line required");
    const auto line = std::string_view(text).substr(offset, end - offset);
    require(line.starts_with(prefix),
        "CONFIG_CUSTODY_GRANT_NONCANONICAL",
        "canonical field order required");
    offset = end + 1U;
    return std::string(line.substr(prefix.size()));
}

const CustodyRelayGrant* find_exact(
    const CustodyRelayPolicy& policy,
    std::string_view id,
    std::uint64_t generation) noexcept {
    const auto found = std::find_if(policy.begin(), policy.end(),
        [&](const CustodyRelayGrant& grant) {
            return grant.id == id && grant.generation == generation;
        });
    return found == policy.end() ? nullptr : &*found;
}

} // namespace

std::string_view custody_relay_grant_state_name(
    const CustodyRelayGrantState state) {
    switch (state) {
        case CustodyRelayGrantState::active: return "ACTIVE";
        case CustodyRelayGrantState::retired: return "RETIRED";
        case CustodyRelayGrantState::revoked: return "REVOKED";
    }
    app_fail("CONFIG_CUSTODY_GRANT_STATE", "unknown grant lifecycle state");
}

std::string custody_relay_grant_commitment_text(
    const CustodyRelayGrant& grant) {
    validate_grant(grant);
    return "NATRAV_CUSTODY_RELAY_GRANT_COMMITMENT_V1\n"
        "id=" + grant.id +
        "\ngeneration=" + std::to_string(grant.generation) +
        "\npredecessor_sha256=" + operation_id_text(grant.predecessor) +
        "\norigin=" + grant.origin +
        "\norigin_signing_generation=" + grant.origin_signing_generation +
        "\nfinal_recipient=" + grant.final_recipient +
        "\nfinal_signing_generation=" + grant.final_signing_generation +
        "\ncustodian=" + grant.custodian +
        "\ncustodian_signing_generation=" +
            grant.custodian_signing_generation +
        "\nnext_hop=" + grant.next_hop +
        "\nnext_hop_signing_generation=" +
            grant.next_hop_signing_generation +
        "\nmaximum_envelope_lifetime_ms=" +
            std::to_string(grant.maximum_envelope_lifetime_ms) +
        "\nmaximum_hops=" + std::to_string(grant.maximum_hops) +
        "\nmaximum_active_envelopes=" +
            std::to_string(grant.maximum_active_envelopes) +
        "\nmaximum_capsule_bytes=" +
            std::to_string(grant.maximum_capsule_bytes) + "\n";
}

datacube::Digest32 custody_relay_grant_commitment(
    const CustodyRelayGrant& grant) {
    const auto text = custody_relay_grant_commitment_text(grant);
    return datacube::sha256(datacube::OctetView(
        reinterpret_cast<const std::uint8_t*>(text.data()), text.size()));
}

std::string custody_relay_grant_text(const CustodyRelayGrant& grant) {
    const auto immutable = custody_relay_grant_commitment_text(grant);
    return "NATRAV_CUSTODY_RELAY_GRANT_V1\n" +
        immutable.substr(immutable.find('\n') + 1U) +
        "state=" + std::string(custody_relay_grant_state_name(grant.state)) +
        "\n";
}

CustodyRelayGrant parse_custody_relay_grant(const std::string_view hex) {
    require(hex.size() <= 2U * kGrantTextLimit,
        "CONFIG_CUSTODY_GRANT_INVALID", "grant record byte bound");
    const auto raw = decode_adapter_configuration_record_hex(hex);
    require(raw.size() <= kGrantTextLimit &&
            std::all_of(raw.begin(), raw.end(), [](const char c) {
                const auto value = static_cast<unsigned char>(c);
                return value > 0U && value < 128U;
            }),
        "CONFIG_CUSTODY_GRANT_NONCANONICAL",
        "canonical grant text requires ASCII without NUL");
    const std::string text(raw.begin(), raw.end());
    std::size_t offset = 0U;
    require(field_value(text, offset,
                "NATRAV_CUSTODY_RELAY_GRANT_V1").empty(),
        "CONFIG_CUSTODY_GRANT_NONCANONICAL", "grant header");
    CustodyRelayGrant grant;
    grant.id = field_value(text, offset, "id=");
    grant.generation = parse_u64(
        field_value(text, offset, "generation="),
        "custody grant generation", 1U,
        kCustodyRelayGrantPerIdLimit);
    const auto predecessor = field_value(
        text, offset, "predecessor_sha256=");
    grant.predecessor = predecessor == std::string(64U, '0') ?
        datacube::Digest32{} : parse_operation_id(predecessor);
    grant.origin = field_value(text, offset, "origin=");
    grant.origin_signing_generation = field_value(
        text, offset, "origin_signing_generation=");
    grant.final_recipient = field_value(
        text, offset, "final_recipient=");
    grant.final_signing_generation = field_value(
        text, offset, "final_signing_generation=");
    grant.custodian = field_value(text, offset, "custodian=");
    grant.custodian_signing_generation = field_value(
        text, offset, "custodian_signing_generation=");
    grant.next_hop = field_value(text, offset, "next_hop=");
    grant.next_hop_signing_generation = field_value(
        text, offset, "next_hop_signing_generation=");
    grant.maximum_envelope_lifetime_ms = parse_u64(
        field_value(text, offset, "maximum_envelope_lifetime_ms="),
        "custody grant lifetime", 1U, kCustodyEnvelopeLifetimeLimitMs);
    grant.maximum_hops = static_cast<std::uint8_t>(parse_u64(
        field_value(text, offset, "maximum_hops="),
        "custody grant hop limit", 1U, kCustodyRoutePartyLimit - 1U));
    grant.maximum_active_envelopes = static_cast<std::uint32_t>(parse_u64(
        field_value(text, offset, "maximum_active_envelopes="),
        "custody grant active envelope quota", 1U,
        kCustodyRelayMaximumActiveLimit));
    grant.maximum_capsule_bytes = parse_u64(
        field_value(text, offset, "maximum_capsule_bytes="),
        "custody grant capsule byte quota", 1U,
        kCustodyRelayMaximumBytesLimit);
    const auto state = field_value(text, offset, "state=");
    if (state == "ACTIVE") {
        grant.state = CustodyRelayGrantState::active;
    } else if (state == "RETIRED") {
        grant.state = CustodyRelayGrantState::retired;
    } else if (state == "REVOKED") {
        grant.state = CustodyRelayGrantState::revoked;
    } else {
        app_fail("CONFIG_CUSTODY_GRANT_STATE",
            "expected ACTIVE, RETIRED or REVOKED");
    }
    require(offset == text.size() && custody_relay_grant_text(grant) == text,
        "CONFIG_CUSTODY_GRANT_NONCANONICAL",
        "noncanonical or trailing grant data");
    return grant;
}

void normalize_custody_relay_policy(CustodyRelayPolicy& grants) {
    require(grants.size() <= kCustodyRelayGrantLimit,
        "CONFIG_CUSTODY_GRANT_CAPACITY", "retained custody grant bound");
    std::sort(grants.begin(), grants.end(),
        [](const CustodyRelayGrant& left, const CustodyRelayGrant& right) {
            return std::tie(left.id, left.generation) <
                std::tie(right.id, right.generation);
        });
    std::set<std::pair<std::string, std::uint64_t>> identities;
    std::set<std::tuple<std::string, std::string, std::string, std::string,
        std::string, std::string, std::string, std::string, std::uint64_t>>
        exact_meanings;
    const CustodyRelayGrant* previous = nullptr;
    for (const auto& grant : grants) {
        validate_grant(grant);
        require(identities.emplace(grant.id, grant.generation).second,
            "CONFIG_CUSTODY_GRANT_CONFLICT",
            "duplicate grant id and generation");
        const auto meaning = std::make_tuple(
            grant.origin, grant.origin_signing_generation,
            grant.final_recipient, grant.final_signing_generation,
            grant.custodian, grant.custodian_signing_generation,
            grant.next_hop, grant.next_hop_signing_generation,
            grant.generation);
        require(exact_meanings.insert(meaning).second,
            "CONFIG_CUSTODY_GRANT_CONFLICT",
            "same transition generation cannot be assigned to several grant ids");
        if (previous == nullptr || previous->id != grant.id) {
            require(grant.generation == 1U && digest_is_zero(grant.predecessor),
                "CONFIG_CUSTODY_GRANT_PREDECESSOR",
                "first grant generation requires zero predecessor");
        } else {
            require(grant.generation == previous->generation + 1U &&
                    grant.predecessor ==
                        custody_relay_grant_commitment(*previous),
                "CONFIG_CUSTODY_GRANT_PREDECESSOR",
                "exact consecutive immutable predecessor required");
            require(previous->state != CustodyRelayGrantState::active,
                "CONFIG_CUSTODY_GRANT_ACTIVE_CONFLICT",
                "superseded grant must first be retired or revoked");
        }
        previous = &grant;
    }
}

void require_custody_relay_history_preserved(
    const CustodyRelayPolicy& historical,
    const CustodyRelayPolicy& candidate) {
    for (const auto& prior : historical) {
        const auto* next = find_exact(candidate, prior.id, prior.generation);
        require(next != nullptr,
            "CONFIG_CUSTODY_GRANT_HISTORY_REMOVED",
            "accepted custody grant generation must remain present");
        require(custody_relay_grant_commitment(*next) ==
                    custody_relay_grant_commitment(prior),
            "CONFIG_CUSTODY_GRANT_CONFLICT",
            "accepted custody grant meaning cannot be redefined");
        require(static_cast<unsigned>(next->state) >=
                    static_cast<unsigned>(prior.state),
            "CONFIG_CUSTODY_GRANT_STATE_ROLLBACK",
            "retirement and revocation are monotonic");
    }
}

const CustodyRelayGrant* find_custody_relay_grant(
    const CustodyRelayPolicy& policy,
    const std::string_view id,
    const std::uint64_t generation) noexcept {
    return find_exact(policy, id, generation);
}

void require_custody_relay_grant_use(
    const CustodyRelayGrant& grant,
    const CustodyEnvelope& envelope,
    const std::size_t hop_index,
    const bool require_active) {
    validate_grant(grant);
    require(hop_index + 1U < envelope.route.size(),
        "CUSTODY_GRANT_MISMATCH", "hop index is outside the route");
    const auto& origin = envelope.route.front();
    const auto& final = envelope.route.back();
    const auto& custodian = envelope.route[hop_index];
    const auto& next = envelope.route[hop_index + 1U];
    require(grant.origin == origin.node &&
            grant.origin_signing_generation == origin.signing_generation &&
            grant.final_recipient == final.node &&
            grant.final_signing_generation == final.signing_generation &&
            grant.custodian == custodian.node &&
            grant.custodian_signing_generation ==
                custodian.signing_generation &&
            grant.next_hop == next.node &&
            grant.next_hop_signing_generation == next.signing_generation,
        "CUSTODY_GRANT_MISMATCH",
        "grant does not authorize this exact route transition");
    require(envelope.expires_ms > envelope.created_ms &&
            envelope.expires_ms - envelope.created_ms <=
                grant.maximum_envelope_lifetime_ms &&
            envelope.hop_limit <= grant.maximum_hops &&
            envelope.capsule_bytes <= grant.maximum_capsule_bytes,
        "CUSTODY_GRANT_LIMIT",
        "envelope exceeds the exact grant bounds");
    require(grant.state != CustodyRelayGrantState::revoked,
        "CUSTODY_GRANT_REVOKED", "custody grant is revoked");
    require(!require_active || grant.state == CustodyRelayGrantState::active,
        "CUSTODY_GRANT_RETIRED",
        "retired custody grant cannot originate a new transfer offer");
}

const CustodyRelayGrant* find_matching_custody_relay_grant(
    const CustodyRelayPolicy& policy,
    const CustodyEnvelope& envelope,
    const std::size_t hop_index,
    const bool require_active) {
    const CustodyRelayGrant* result = nullptr;
    for (const auto& grant : policy) {
        try {
            require_custody_relay_grant_use(
                grant, envelope, hop_index, require_active);
        } catch (const AppError& error) {
            if (error.code() == "CUSTODY_GRANT_MISMATCH") { continue; }
            if (error.code() == "CUSTODY_GRANT_RETIRED" ||
                error.code() == "CUSTODY_GRANT_REVOKED" ||
                error.code() == "CUSTODY_GRANT_LIMIT") {
                continue;
            }
            throw;
        }
        require(result == nullptr,
            "CUSTODY_GRANT_AMBIGUOUS",
            "several accepted grants authorize the same transition");
        result = &grant;
    }
    require(result != nullptr,
        "CUSTODY_GRANT_NOT_AUTHORIZED",
        "no accepted grant authorizes the exact route transition");
    return result;
}

CustodyGrantReference custody_grant_reference(
    const CustodyRelayGrant& grant) {
    return CustodyGrantReference{
        .id = grant.id,
        .generation = grant.generation,
        .commitment = custody_relay_grant_commitment(grant),
    };
}

std::string custody_relay_policy_json(const CustodyRelayPolicy& grants) {
    std::string out =
        "{\"format\":\"V21_DURABLE_CUSTODY_RELAY_POLICY_V1\",\"grants\":[";
    bool first = true;
    for (const auto& grant : grants) {
        if (!first) { out += ','; }
        first = false;
        out += "{\"id\":" + json_string(grant.id) +
            ",\"generation\":" + std::to_string(grant.generation) +
            ",\"state\":" +
                json_string(custody_relay_grant_state_name(grant.state)) +
            ",\"origin\":" + json_string(grant.origin) +
            ",\"origin_signing_generation\":" +
                json_string(grant.origin_signing_generation) +
            ",\"final_recipient\":" +
                json_string(grant.final_recipient) +
            ",\"final_signing_generation\":" +
                json_string(grant.final_signing_generation) +
            ",\"custodian\":" + json_string(grant.custodian) +
            ",\"custodian_signing_generation\":" +
                json_string(grant.custodian_signing_generation) +
            ",\"next_hop\":" + json_string(grant.next_hop) +
            ",\"next_hop_signing_generation\":" +
                json_string(grant.next_hop_signing_generation) +
            ",\"maximum_envelope_lifetime_ms\":" +
                std::to_string(grant.maximum_envelope_lifetime_ms) +
            ",\"maximum_hops\":" +
                std::to_string(grant.maximum_hops) +
            ",\"maximum_active_envelopes\":" +
                std::to_string(grant.maximum_active_envelopes) +
            ",\"maximum_capsule_bytes\":" +
                std::to_string(grant.maximum_capsule_bytes) +
            ",\"commitment_sha256\":" +
                json_string(operation_id_text(
                    custody_relay_grant_commitment(grant))) +
            ",\"predecessor_sha256\":" +
                json_string(operation_id_text(grant.predecessor)) + "}";
    }
    return out + "]}";
}

} // namespace natrav_overlay
