#pragma once
#include "protocol.hpp"
#include "local_control.hpp"
#include <memory>
#include <vector>
#include <string>
#include <utility>

namespace natrav_overlay {
struct RuntimeConfig;
struct SourceViewRule final {
    std::string id;
    std::uint32_t uid{0U};
    std::string provider;
    std::string generation;
    std::uint32_t author_uid{0U};
    std::string source_scope;
    std::string target_scope;
    std::uint32_t maximum_records{0U};
    std::uint64_t maximum_payload_bytes{0U};
    datacube::Digest32 digest{};
};
struct SourceViewBinding final {
    std::string view;
    std::string grant;
    datacube::Digest32 instance{};
    datacube::Digest32 grant_digest{};
    // NSE1 uses no lineage; NSE2 pins the exact encoded succession suffix.
    std::optional<datacube::Digest32> lineage_digest;
    datacube::Digest32 digest{};
};
struct SourceViewPolicy final {
    std::vector<SourceViewRule> rules;
    std::vector<SourceViewBinding> bindings;
};
struct SourceViewRequest final {
    std::string view;
    datacube::Digest32 operation{}; // Exact authenticated outer admission.
};
struct SubscribedSource final {
    std::optional<std::uint32_t> executor_uid;
    bool selective_retry{false};
    std::uint64_t automation_revision{0U};
    std::string view;
    datacube::Digest32 view_digest{};
    datacube::Digest32 binding_digest{};
    std::uint32_t uid{0U}, gid{0U}, pid{0U};
    std::uint64_t unix_ms{0U}, configuration_event{0U};
    datacube::Digest32 configuration_digest{};
    datacube::Digest32 outer_operation{}, outer_digest{};
    std::uint64_t outer_configuration_event{0U};
    std::string provider_generation;
    datacube::Digest32 provider_spki{};
    datacube::Digest32 source_operation{}, source_digest{};
    std::optional<datacube::Digest32> source_corrects;
    std::uint32_t claimed_author_uid{0U};
    std::uint64_t claimed_authored_unix_ms{0U};
    std::string source_scope, grant;
    datacube::Digest32 subscription_instance{};
    std::uint64_t ordinal{0U};
    std::optional<datacube::Digest32> lineage_digest;
};
[[nodiscard]] SourceViewPolicy make_source_view_policy(const std::vector<std::string>& rules,
    const std::vector<std::string>& bindings, const RuntimeConfig& config);
[[nodiscard]] std::string source_view_rule_text(const SourceViewRule& rule);
[[nodiscard]] std::string source_view_binding_text(const SourceViewBinding& binding);
[[nodiscard]] std::string source_view_policy_json(const SourceViewPolicy& policy);
[[nodiscard]] datacube::Octets encode_source_view_request(const SourceViewRequest& request);
[[nodiscard]] SourceViewRequest decode_source_view_request(datacube::OctetView bytes);
[[nodiscard]] datacube::Octets encode_subscribed_source(const SubscribedSource& account);
[[nodiscard]] SubscribedSource decode_subscribed_source(datacube::Reader& reader);
[[nodiscard]] std::string subscribed_source_json(const SubscribedSource& account);
} // namespace natrav_overlay
