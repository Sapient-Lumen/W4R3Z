#pragma once

#include "local_control.hpp"
#include "protocol.hpp"

#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace natrav_overlay {
struct RuntimeConfig;
enum class SourcePendingDisposition : std::uint8_t {
    retain = 1U,
    cancel = 2U,
};
[[nodiscard]] std::string_view source_pending_disposition_name(
    SourcePendingDisposition value) noexcept;
// Grant IDs are durable generations: accepting another definition for the
// same ID is prohibited, even after removal or retirement.
struct SourceDisclosureGrant final {
    std::string id;
    std::uint32_t uid{0U};
    std::uint32_t author_uid{0U};
    std::string peer;
    std::string generation;
    std::string scope;
    std::uint32_t maximum_records{0U};
    std::uint64_t maximum_payload_bytes{0U};
    // Empty/zero retain the V15 indefinitely retained grant semantics.
    // V16 grants use an immutable lease generation, finite lifetime, and one
    // provider-selected pending-delivery withdrawal policy.
    std::string lease_generation;
    std::uint64_t lease_duration_ms{0U};
    SourcePendingDisposition withdrawal_pending{SourcePendingDisposition::retain};
    datacube::Digest32 digest{};
    bool operator==(const SourceDisclosureGrant&) const = default;
};
struct SourceDisclosurePolicy final { std::vector<SourceDisclosureGrant> grants; };
enum class SourceSubscriptionCommand : std::uint8_t {
    create = 1U,
    step = 2U,
    status = 3U,
    retire = 4U,
    automatic_enable = 5U,
    automatic_pause = 6U,
    automatic_status = 7U,
    succeed = 8U,
    reconcile = 9U,
};
struct SourceSubscriptionRequest final {
    SourceSubscriptionCommand command{SourceSubscriptionCommand::status};
    // Response preference is transport-only and excluded from durable request
    // commitments. Structural selection, unlike formatting, is committed.
    bool compact_response{false};
    bool structural_selector{false};
    std::string grant;
    std::optional<datacube::Digest32> instance;
    std::uint64_t expected_revision{0U};
    bool retain_pending{false};
    std::uint64_t expected_schedule_revision{0U};
    std::uint64_t expected_grant_generation{0U};
    std::uint32_t automatic_maximum_steps{100U};
    std::uint32_t automatic_minimum_interval_ms{100U};
    std::string reason;
    // Succession selects a terminal predecessor, never the new instance.
    std::string predecessor_grant;
    std::string predecessor_lease;
    std::string successor_lease;
    std::optional<datacube::Digest32> predecessor_state_digest;
    std::optional<datacube::Digest32> predecessor_mapping_digest;
    std::uint64_t expected_frontier{0U};
    // Reconciliation adopts only a selected, already durable head receipt.
    std::optional<datacube::Digest32> reconciliation_state_digest;
    std::optional<datacube::Digest32> terminal_digest;
    std::optional<datacube::Digest32> source_operation;
    std::optional<datacube::Digest32> delivery_operation;
    std::optional<datacube::Digest32> receipt_digest;
};
struct SourceSubscriptionDelivery final {
    datacube::Digest32 source_operation{};
    datacube::Digest32 operation{};
    datacube::Digest32 record_digest{};
    std::uint32_t payload_bytes{0U};
    std::uint64_t configuration_event{0U};
    std::uint64_t unix_ms{0U};
    std::uint32_t pid{0U};
    std::uint64_t acknowledged_event{0U};
    std::uint64_t acknowledged_unix_ms{0U};
    std::uint32_t acknowledged_pid{0U};
    std::uint64_t issue_automatic_generation{0U};
    std::uint64_t acknowledge_automatic_generation{0U};
    bool operator==(const SourceSubscriptionDelivery&) const = default;
};
struct SourceSubscriptionRemoteAdmission final {
    datacube::Digest32 request_id{};
    std::string peer;
    std::string generation;
    datacube::Digest32 peer_spki{};
    std::uint64_t configuration_event{0U};
    std::uint64_t unix_ms{0U};
    std::string reason;
    datacube::Digest32 request_digest{};
    bool operator==(const SourceSubscriptionRemoteAdmission&) const = default;
};
struct SourceSubscriptionTermination final {
    std::string kind; // WITHDRAWN or EXPIRED
    std::string lease_generation;
    std::uint64_t configuration_event{0U};
    std::uint64_t unix_ms{0U};
    std::string pending_disposition; // NONE, RETAIN, or CANCEL
    std::optional<datacube::Digest32> cancelled_operation;
    std::string actor_peer;
    std::string actor_generation;
    datacube::Digest32 actor_spki{};
    std::optional<datacube::Digest32> request_id;
    datacube::Digest32 request_digest{};
    std::string reason;
    bool operator==(const SourceSubscriptionTermination&) const = default;
};
struct SourceSubscriptionAutomaticGrant final {
    std::uint64_t generation{0U};
    std::uint64_t observed_subscription_revision{0U};
    std::uint64_t configuration_event{0U};
    std::uint64_t unix_ms{0U};
    std::uint32_t actor_uid{0U};
    std::uint32_t pid{0U};
    std::uint32_t maximum_steps{0U};
    std::uint32_t minimum_interval_ms{0U};
    datacube::Digest32 disclosure_digest{};
    std::string reason;
    std::uint64_t start_issued{0U};
    std::uint64_t start_acknowledged{0U};
    std::uint64_t steps{0U};
    std::string state{"ENABLED"};
    std::string error;
    std::string end_reason;
    std::uint64_t last_step_event{0U};
    std::uint64_t last_step_unix_ms{0U};
    std::uint32_t last_executor_uid{0U};
    std::uint32_t last_executor_pid{0U};
    std::uint64_t ended_event{0U};
    std::uint64_t ended_unix_ms{0U};
    std::uint32_t ended_uid{0U};
    std::uint32_t ended_pid{0U};
    bool operator==(const SourceSubscriptionAutomaticGrant&) const = default;
};
struct SourceSubscriptionSuccession final {
    std::string predecessor_grant;
    std::string predecessor_lease;
    datacube::Digest32 predecessor_instance{};
    std::uint64_t predecessor_revision{0U};
    datacube::Digest32 predecessor_state_digest{};
    std::uint64_t inherited_acknowledged{0U};
    datacube::Digest32 mapping_digest{};
    datacube::Digest32 creation_request_digest{};
    bool operator==(const SourceSubscriptionSuccession&) const = default;
};
// A terminal lease can have at most one outstanding source. One immutable
// reconciliation account suffices; there is no reset, loop, or budget renewal.
struct SourceReceiptReconciliation final {
    std::uint64_t preceding_revision{0U};
    std::uint32_t preceding_pid{0U};
    datacube::Digest32 preceding_state_digest{};
    datacube::Digest32 terminal_digest{};
    datacube::Digest32 source_operation{};
    datacube::Digest32 delivery_operation{};
    datacube::Digest32 receipt_digest{};
    bool operator==(const SourceReceiptReconciliation&) const = default;
};
struct SourceSubscription final {
    SourceDisclosureGrant grant;
    datacube::Digest32 instance{};
    datacube::Digest32 peer_spki{};
    std::uint64_t created_event{0U};
    std::uint64_t created_unix_ms{0U};
    std::uint32_t created_pid{0U};
    std::string creation_reason;
    std::optional<SourceSubscriptionRemoteAdmission> remote_admission;
    std::uint64_t lease_started_unix_ms{0U};
    std::uint64_t lease_expires_unix_ms{0U};
    std::optional<SourceSubscriptionTermination> termination;
    std::optional<SourceSubscriptionSuccession> succession;
    std::optional<SourceReceiptReconciliation> reconciliation;
    std::uint64_t revision{0U};
    std::vector<SourceSubscriptionDelivery> deliveries;
    std::uint64_t acknowledged{0U};
    std::uint64_t used_payload_bytes{0U};
    bool retired{false};
    bool retained_unacknowledged{false};
    std::string transition;
    std::string reason;
    std::uint64_t configuration_event{0U};
    std::uint64_t unix_ms{0U};
    std::uint32_t pid{0U};
    datacube::Digest32 request_digest{};
    std::uint64_t automatic_schedule_revision{0U};
    std::vector<SourceSubscriptionAutomaticGrant> automatic_grants;
    bool operator==(const SourceSubscription&) const = default;
};
// Process-local exact commitment components for compact progress records. They
// are rebuilt from a fully validated canonical state at creation/checkpoint
// boundaries and then updated only by validated append/ack transitions. They
// are never serialized as an independent authority.
struct SourceSubscriptionCommitment final {
    datacube::Digest32 base{};
    datacube::Digest32 delivery_prefix{};
    datacube::Digest32 delivery_tail{};
    datacube::Digest32 automatic_prefix{};
    datacube::Digest32 automatic_tail{};
    datacube::Digest32 root{};
    std::uint64_t delivery_count{0U};
    std::uint64_t automatic_count{0U};
    bool has_delivery_tail{false};
    bool has_automatic_tail{false};
    bool operator==(const SourceSubscriptionCommitment&) const = default;
};
// References, not duplicate delivery accounts or caller-provided attestations.
// Rebuilt only after canonical history validation. Local progress appends a
// reference only when the actual receipt has been durably acknowledged.
struct SourceAncestryReference final {
    std::string grant;
    datacube::Digest32 instance{};
    std::size_t position{0U};
    bool operator==(const SourceAncestryReference&) const = default;
};
struct SourceSubscriptionIndex final {
    datacube::Digest32 instance{};
    std::uint64_t frontier{0U};
    datacube::Digest32 mapping{};
    std::map<std::array<std::uint8_t, 32>, SourceAncestryReference> ancestry;
    bool operator==(const SourceSubscriptionIndex&) const = default;
};
struct SourceSubscriptionCandidate final {
    std::string grant;
    std::uint64_t generation{0U};
    std::uint32_t minimum_interval_ms{0U};
};
inline constexpr std::size_t kSourceSubscriptionLimit = 64U;
inline constexpr std::size_t kSourceSubscriptionUidLimit = 16U;
inline constexpr std::size_t kSourceSubscriptionRecordLimit = 128U;
inline constexpr std::size_t kSourceSubscriptionAutomaticGrantLimit = 32U;
inline constexpr std::size_t kSourceSubscriptionEncodedLimit = 65'536U;

[[nodiscard]] std::string inspect_source_envelope(datacube::OctetView payload);
[[nodiscard]] SourceDisclosurePolicy make_source_disclosure_policy(
    const std::vector<std::string>& values, const LocalControlPolicy& control, std::uint32_t format_version);
[[nodiscard]] const SourceDisclosureGrant* source_disclosure_grant(
    const SourceDisclosurePolicy& policy, std::string_view id);
[[nodiscard]] std::string source_disclosure_grant_text(const SourceDisclosureGrant& grant);
[[nodiscard]] std::string source_disclosure_policy_json(const SourceDisclosurePolicy& policy);
[[nodiscard]] datacube::Octets encode_source_subscription_request(const SourceSubscriptionRequest& value);
[[nodiscard]] SourceSubscriptionRequest decode_source_subscription_request(datacube::OctetView bytes);
[[nodiscard]] datacube::Octets encode_source_subscription(const SourceSubscription& value);
[[nodiscard]] SourceSubscription decode_source_subscription(datacube::OctetView bytes);
inline constexpr std::string_view kSourceStateSelectorPrefix = "SPSC1:";
[[nodiscard]] datacube::Digest32 parse_source_state_selector(std::string_view value);
// Full canonical reconstruction, independent of the incremental update path.
[[nodiscard]] datacube::Digest32 source_subscription_structural_digest(const SourceSubscription& value);
[[nodiscard]] std::string source_subscription_json(const SourceSubscription& value, bool history,
    std::string_view delivery_status = {}, std::string_view disposition = {}, bool policy_current = false,
    std::string_view automatic_observation = {},
    const SourceSubscriptionCommitment* compact = nullptr,
    const datacube::Digest32* mapping = nullptr);
[[nodiscard]] std::string remote_source_subscription_response_json(
    const RemoteSourceSubscriptionResponse& response);
[[nodiscard]] RemoteSourceSubscriptionResponse
request_remote_source_subscription(
    const RuntimeConfig& config,
    std::string_view provider,
    const RemoteSourceSubscriptionRequest& request);
} // namespace natrav_overlay
