#pragma once

#include "local_control.hpp"
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {
struct EvidenceReadGrant final {
    std::uint32_t uid{0U};
    std::string issuer;
    std::string scope;
    bool payload{false}; // PAYLOAD includes METADATA, never the reverse.
    bool operator==(const EvidenceReadGrant&) const = default;
};
struct EvidenceReadPolicy final {
    bool scoped{false}; // V6..V9 retain their explicit node-wide semantics.
    std::vector<EvidenceReadGrant> grants;
    datacube::Digest32 digest{};
};
struct EvidenceReadAccess final {
    bool scoped{false};
    bool metadata_allowed{false};
    bool payload_allowed{false};
    std::vector<EvidenceReadGrant> grants; // Only the authenticated UID's domains.
    datacube::Digest32 digest{};
};
[[nodiscard]] EvidenceReadPolicy make_evidence_read_policy(
    const std::vector<std::string>& values, const LocalControlPolicy& local, bool scoped);
[[nodiscard]] EvidenceReadAccess evidence_read_access(
    const EvidenceReadPolicy& policy, const LocalControlPolicy& local, std::uint32_t uid);
[[nodiscard]] bool evidence_read_allows(const EvidenceReadAccess& access,
    std::string_view issuer, std::string_view scope, bool payload) noexcept;
[[nodiscard]] std::string evidence_read_grant_text(const EvidenceReadGrant& grant);
[[nodiscard]] std::string evidence_read_policy_json(const EvidenceReadPolicy& policy);
} // namespace natrav_overlay
