#include "control_history.hpp"
#include "journal.hpp"
#include <algorithm>

namespace natrav_overlay {
namespace {
using Digest = datacube::Digest32;
Digest hash(std::string_view domain, datacube::OctetView material) {
    datacube::Octets bytes;
    datacube::append_text(bytes, domain); datacube::append_u8(bytes, 0U);
    datacube::append_octets(bytes, material); return datacube::sha256(bytes);
}
Digest seed(std::string_view node, bool decisions) {
    datacube::Octets bytes;
    datacube::append_be16(bytes, static_cast<std::uint16_t>(node.size()));
    datacube::append_text(bytes, node); datacube::append_u8(bytes, decisions ? 1U : 2U);
    return hash("NATRAV_OVERLAY_CONTROL_HISTORY_SEED_V1", bytes);
}
Digest link(const Digest& previous, std::uint64_t ordinal, const Digest& item) {
    datacube::Octets bytes; datacube::append_octets(bytes, previous.octets);
    datacube::append_be64(bytes, ordinal); datacube::append_octets(bytes, item.octets);
    return hash("NATRAV_OVERLAY_CONTROL_HISTORY_LINK_V1", bytes);
}
std::string dj(const Digest& d) { return json_string(datacube::hex_lower(d)); }
void put_optional(datacube::Octets& bytes, const std::optional<std::uint64_t>& n) {
    datacube::append_u8(bytes,n ? 1U : 0U); if(n) datacube::append_be64(bytes,*n);
}
std::optional<std::uint64_t> get_optional(datacube::Reader& rd) {
    const auto flag=rd.read_u8("optional flag");
    if(flag>1U) app_fail("CONTROL_HISTORY_INVALID","invalid optional flag");
    if(flag) return rd.read_be64("optional integer");
    return {};
}
Digest get_digest(datacube::Reader& rd) {
    Digest d{}; auto b=rd.read_exact(32U,"digest");
    std::copy(b.begin(),b.end(),d.octets.begin()); return d;
}
} // namespace

void validate_control_history(const ControlHistoryRequest& r) {
    if(r.section!="decisions" && r.section!="lifecycle")
        app_fail("CONTROL_HISTORY_INVALID","section must be decisions or lifecycle");
    if(r.limit<1U || r.limit>64U || r.maximum_bytes<2048U || r.maximum_bytes>60000U ||
       r.offset>1'000'000U || (r.ordinal && (*r.ordinal==0U || *r.ordinal>1'000'000U)) ||
       (r.configuration_event && (*r.configuration_event==0U || *r.configuration_event>256U)) ||
       (r.through && *r.through>1'000'000U) || (r.prefix && digest_is_zero(*r.prefix)) ||
       (r.request_id && digest_is_zero(*r.request_id)))
        app_fail("CONTROL_HISTORY_INVALID","invalid ordinal, filter or page bound");
    const auto filters=static_cast<unsigned>(r.uid.has_value())+static_cast<unsigned>(r.request_id.has_value())+
        static_cast<unsigned>(r.configuration_event.has_value());
    if(filters>1U || (r.ordinal && r.offset!=0U))
        app_fail("CONTROL_HISTORY_INVALID","use one indexed filter; ordinal cannot combine with offset");
    if(r.through.has_value()!=r.prefix.has_value() || (r.offset!=0U && !r.through))
        app_fail("CONTROL_HISTORY_PREFIX_REQUIRED","continuation requires through and prefix digest");
}
datacube::Octets encode_control_history(const ControlHistoryRequest& r) {
    validate_control_history(r); datacube::Octets bytes;
    datacube::append_text(bytes,"NHA1"); datacube::append_u8(bytes,r.section=="decisions"?1U:2U);
    put_optional(bytes,r.ordinal);
    put_optional(bytes,r.uid ? std::optional<std::uint64_t>(*r.uid) : std::nullopt);
    datacube::append_u8(bytes,r.request_id?1U:0U);
    if(r.request_id) datacube::append_octets(bytes,r.request_id->octets);
    put_optional(bytes,r.configuration_event);
    datacube::append_be64(bytes,r.offset); datacube::append_be32(bytes,r.limit);
    datacube::append_be32(bytes,r.maximum_bytes); put_optional(bytes,r.through);
    if(r.prefix) datacube::append_octets(bytes,r.prefix->octets);
    return bytes;
}
ControlHistoryRequest decode_control_history(datacube::OctetView bytes) {
    datacube::Reader rd(bytes,"control history");
    if(datacube::octets_text(rd.read_exact(4U,"magic"),"magic",true)!="NHA1")
        app_fail("CONTROL_HISTORY_INVALID","wrong magic");
    const auto section=rd.read_u8("section");
    if(section!=1U && section!=2U) app_fail("CONTROL_HISTORY_INVALID","invalid section");
    ControlHistoryRequest r; r.section=section==1U?"decisions":"lifecycle";
    r.ordinal=get_optional(rd); const auto uid=get_optional(rd);
    if(uid) {
        if(*uid>UINT32_MAX) app_fail("CONTROL_HISTORY_INVALID","UID exceeds uint32");
        r.uid=static_cast<std::uint32_t>(*uid);
    }
    const auto flag=rd.read_u8("request flag");
    if(flag>1U) app_fail("CONTROL_HISTORY_INVALID","invalid request flag");
    if(flag) r.request_id=get_digest(rd);
    r.configuration_event=get_optional(rd);
    r.offset=rd.read_be64("offset"); r.limit=rd.read_be32("limit");
    r.maximum_bytes=rd.read_be32("maximum bytes"); r.through=get_optional(rd);
    if(r.through) r.prefix=get_digest(rd);
    rd.require_eof("control history"); validate_control_history(r); return r;
}

// The normal decoder calls this only after accepting an actual durable row.
// No derived index or prefix is serialized into application state.
void NodeState::index_control_history_locked(bool decisions, datacube::OctetView payload) {
    auto& index=decisions?control_history_index_:lifecycle_history_index_;
    const auto count=decisions?local_control_events_.size():lifecycle_events_.size();
    if(count!=index.prefixes.size()+1U)
        app_fail("JOURNAL_CORRUPT","control history derivative mismatch");
    const auto uid=decisions?local_control_events_.back().uid:lifecycle_events_.back().uid;
    const auto& request=decisions?local_control_events_.back().request_id:lifecycle_events_.back().request_id;
    const auto event=decisions?local_control_events_.back().configuration_event:lifecycle_events_.back().configuration_event;
    datacube::Octets material;
    datacube::append_octets(material,configuration_history_index_.at(static_cast<std::size_t>(event-1U)).prefix.octets);
    datacube::append_octets(material,payload);
    const auto item=hash(decisions?"NATRAV_OVERLAY_CONTROL_DECISION_ITEM_V1":"NATRAV_OVERLAY_LIFECYCLE_ITEM_V1",material);
    const auto previous=index.prefixes.empty()?seed(node_id_,decisions):index.prefixes.back();
    const auto ordinal=static_cast<std::uint32_t>(count);
    index.prefixes.push_back(link(previous,ordinal,item));
    index.by_uid[uid].push_back(ordinal);
    index.by_request[request.octets].push_back(ordinal);
    index.by_configuration[event].push_back(ordinal);
}

std::string NodeState::control_history_page(const ControlHistoryRequest& r,
    const Digest& authorized_configuration, std::chrono::steady_clock::time_point deadline) const {
    validate_control_history(r);
    const auto check_time=[&] {
        if(std::chrono::steady_clock::now()>=deadline)
            app_fail("CONTROL_HISTORY_DEADLINE","history page deadline reached");
    };
    check_time(); std::lock_guard<std::mutex> lock(mutex_); check_time();
    if(poisoned_) app_fail("STATE_RESTART_REQUIRED","restart to reconstruct failed writer");
    SubmissionWork work; SubmissionWorkScope scope(work);
    const bool decisions=r.section=="decisions";
    const auto& idx=decisions?control_history_index_:lifecycle_history_index_;
    const auto count=decisions?local_control_events_.size():lifecycle_events_.size();
    if(count!=idx.prefixes.size()) app_fail("JOURNAL_CORRUPT","history index size mismatch");
    const auto through=r.through.value_or(count);
    if(through>count) app_fail("CONTROL_HISTORY_PREFIX_UNAVAILABLE","selected prefix not retained");
    const auto prefix=through?idx.prefixes.at(static_cast<std::size_t>(through-1U)):seed(node_id_,decisions);
    if(r.prefix && *r.prefix!=prefix)
        app_fail("CONTROL_HISTORY_PREFIX_MISMATCH","selected historical prefix differs");
    std::size_t comparisons=0U,visited=0U;
    const std::vector<std::uint32_t> empty;
    const std::vector<std::uint32_t>* matches=nullptr;
    if(r.uid) { const auto it=idx.by_uid.find(*r.uid); matches=it==idx.by_uid.end()?&empty:&it->second; }
    if(r.request_id) { const auto it=idx.by_request.find(r.request_id->octets); matches=it==idx.by_request.end()?&empty:&it->second; }
    if(r.configuration_event) { const auto it=idx.by_configuration.find(*r.configuration_event); matches=it==idx.by_configuration.end()?&empty:&it->second; }
    std::size_t selected=static_cast<std::size_t>(through);
    std::uint32_t exact=0U;
    if(r.ordinal) {
        bool found=*r.ordinal<=through;
        if(found && matches) found=std::binary_search(matches->begin(),matches->end(),static_cast<std::uint32_t>(*r.ordinal),
            [&](std::uint32_t a,std::uint32_t b){++comparisons;return a<b;});
        selected=found?1U:0U; exact=found?static_cast<std::uint32_t>(*r.ordinal):0U;
    } else if(matches) {
        selected=static_cast<std::size_t>(std::upper_bound(matches->begin(),matches->end(),static_cast<std::uint32_t>(through),
            [&](std::uint32_t a,std::uint32_t b){++comparisons;return a<b;})-matches->begin());
    }
    if(r.offset>selected) app_fail("CONTROL_HISTORY_OFFSET_INVALID","offset exceeds selected total");
    const auto active=configuration_history_index_.empty()?0U:configuration_history_index_.back().active_event;
    const auto header=std::string("{\"format\":\"NATRAV_OVERLAY_CONTROL_HISTORY_V1\",\"node\":")+json_string(node_id_)+
        ",\"section\":"+json_string(r.section)+",\"authorized_configuration_digest\":"+dj(authorized_configuration)+
        ",\"retained_count_observed\":"+std::to_string(count)+",\"active_event_observed\":"+std::to_string(active)+
        ",\"through\":"+std::to_string(through)+",\"prefix_digest\":"+dj(prefix)+
        ",\"selected_total\":"+std::to_string(selected)+",\"offset\":"+std::to_string(r.offset)+
        ",\"observation\":\"ONE_STATE_MUTEX_OBSERVATION\",\"coverage\":\"RETAINED_V8_LOCAL_ACCOUNTS_NOT_ALL_EFFECTS\""+
        ",\"request_semantics\":\"RECORDED_ID_NOT_UNIQUE_INVOCATION_OR_EFFECT_PROOF\""+
        ",\"redaction\":\"NO_REQUEST_BYTES_PRIVATE_PATHS_OR_REASON_TEXT\",\"rows\":[";
    const auto finish=[&](std::size_t returned) {
        const auto next=r.offset+returned;
        return std::string("],\"returned\":")+std::to_string(returned)+",\"next_offset\":"+std::to_string(next)+
            ",\"more\":"+(next<selected?"true":"false")+
            ",\"work\":{\"scope\":\"LOCKED_CONTROL_HISTORY_PAGE\",\"rows_visited\":"+std::to_string(visited)+
            ",\"ordinal_search_comparisons\":"+std::to_string(comparisons)+
            ",\"prefix_reads\":1,\"canonical_bytes_read\":0,\"payload_bytes_read\":0,\"historical_configurations_parsed\":0,"+
            "\"state_snapshots\":"+std::to_string(work.snapshot_calls)+",\"snapshot_logical_bytes\":"+std::to_string(work.snapshot_logical_bytes)+"}}";
    };
    std::string rows; std::size_t returned=0U;
    const auto number=std::min<std::size_t>(r.limit,selected-static_cast<std::size_t>(r.offset));
    for(std::size_t n=0U;n<number;++n) {
        check_time();++visited;
        const auto pos=static_cast<std::size_t>(r.offset)+n;
        const auto ordinal=r.ordinal?exact:matches?matches->at(pos):static_cast<std::uint32_t>(pos+1U);
        const auto i=static_cast<std::size_t>(ordinal-1U);
        const auto event=decisions?local_control_events_[i].configuration_event:lifecycle_events_[i].configuration_event;
        const auto& cfg=configuration_events_.at(static_cast<std::size_t>(event-1U));
        const auto& cfg_prefix=configuration_history_index_.at(static_cast<std::size_t>(event-1U)).prefix;
        std::string row="{\"ordinal\":"+std::to_string(ordinal)+",\"configuration_event\":"+std::to_string(event)+
            ",\"configuration_generation\":"+json_string(cfg.generation)+",\"configuration_digest\":"+dj(cfg.digest)+
            ",\"configuration_prefix_digest\":"+dj(cfg_prefix)+",\"prefix_digest\":"+dj(idx.prefixes[i]);
        if(decisions) {
            const auto& e=local_control_events_[i];
            row+=",\"request_id\":"+dj(e.request_id)+",\"uid\":"+std::to_string(e.uid)+",\"gid\":"+std::to_string(e.gid)+
                ",\"pid\":"+std::to_string(e.pid)+",\"unix_ms\":"+std::to_string(e.unix_ms)+
                ",\"command\":"+json_string(e.command)+",\"command_class\":"+json_string(e.command_class)+
                ",\"decision\":"+json_string(local_control_decision_kind_name(e.decision))+
                ",\"error_code\":"+json_string(e.error_code)+",\"effect_completed\":null";
        } else {
            const auto& e=lifecycle_events_[i];
            const auto reason=hash("NATRAV_OVERLAY_LIFECYCLE_REASON_V1",datacube::OctetView(reinterpret_cast<const std::uint8_t*>(e.reason.data()),e.reason.size()));
            row+=",\"request_id\":"+dj(e.request_id)+",\"uid\":"+std::to_string(e.uid)+",\"gid\":null,\"gid_semantics\":\"NOT_RECORDED\""+
                ",\"pid\":"+std::to_string(e.pid)+",\"unix_ms\":"+std::to_string(e.unix_ms)+
                ",\"kind\":"+json_string(lifecycle_transition_kind_name(e.kind))+
                ",\"deadline_ms\":"+std::to_string(e.deadline_ms)+",\"pending_outbound\":"+std::to_string(e.pending_outbound)+
                ",\"pending_actions\":"+std::to_string(e.pending_actions)+",\"reason_text\":null,\"reason_bytes\":"+std::to_string(e.reason.size())+
                ",\"reason_digest\":"+dj(reason);
        }
        row+='}';
        if(header.size()+rows.size()+(returned?1U:0U)+row.size()+finish(returned+1U).size()+256U>r.maximum_bytes) {
            if(returned==0U) app_fail("CONTROL_HISTORY_PAGE_TOO_SMALL","first whole row exceeds reply budget");
            break;
        }
        if(returned) rows+=',';
        rows+=row;++returned;
    }
    check_time();return header+rows+finish(returned);
}
} // namespace natrav_overlay
