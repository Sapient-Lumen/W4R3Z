#pragma once

#include "protocol.hpp"
#include "runtime_inventory.hpp"
#include "configuration_history.hpp"
#include "control_history.hpp"
#include "evidence_query.hpp"
#include "outbox_query.hpp"
#include "action_query.hpp"
#include "action_result_query.hpp"
#include "result_review.hpp"
#include "action_admin.hpp"
#include "outbox_admin.hpp"
#include "evidence_feed.hpp"
#include "consumer.hpp"
#include "consumer_inventory.hpp"
#include "publication_inventory.hpp"
#include "subscription_inventory.hpp"
#include "source_view_inventory.hpp"
#include "view_bindings.hpp"
#include "publication_channel.hpp"
#include "source_subscription.hpp"
#include "subscribed_source.hpp"
#include "import_scheduler.hpp"

#include <cstdint>
#include <optional>
#include <string>
#include <variant>

namespace natrav_overlay {

enum class ControlKind : std::uint8_t {
    submit = 1U,
    snapshot = 2U,
    wake = 3U,
    shutdown = 4U,
    rebind = 5U,
    cancel = 6U,
    action_cancel = 7U,
    compact = 8U,
    retry = 9U,
    config_activate = 10U,
    config_rollback = 11U,
    quiesce = 12U,
    resume = 13U,
    drain_shutdown = 14U,
    evidence_query = 15U,
    evidence_feed = 16U,
    consumer = 17U,
    publication_channel = 18U,
    author = 19U,
    source_subscription = 20U,
    source_import = 21U,
    import_auto = 22U,
    outbox_query = 23U,
    outbox_conditional = 24U,
    snapshot_with_digest = 25U,
    runtime_inventory = 26U,
    configuration_history = 27U,
    control_history = 28U,
    action_query = 29U,
    action_conditional = 30U,
    action_result_query = 31U,
    action_result_discovery = 32U,
    result_review = 33U,
    result_review_status = 34U,
    result_review_history = 35U,
    consumer_inventory = 36U,
    publication_inventory = 37U,
    subscription_inventory = 38U,
    source_view_inventory = 39U,
    view_bindings = 40U,
    state_head = 41U,
    shutdown_final_head = 42U,
    drain_shutdown_final_head = 43U,
    shutdown_correlated = 44U,
    drain_shutdown_correlated = 45U,
    shutdown_final_head_correlated = 46U,
    drain_shutdown_final_head_correlated = 47U,
    custody_dispatch = 48U,
    custody_dispatch_status = 49U,
    custody_dispatch_inventory = 50U,
};

struct ControlAuthor final { EvidenceRecord record; };

struct ControlSubmit final {
    EvidenceRecord record;
};

struct ControlSnapshot final { bool logical_digest{false}; };

// Empty, strict request. No caller-supplied key, selector, UID, or state path.
struct ControlStateHead final {};
inline constexpr std::size_t kMaximumLiveStateHeadJsonBytes = 4096U;

struct ControlWake final {
    std::string peer;
};

struct ControlShutdown final {
    bool final_state_head{false};
    std::optional<std::string> correlation;
};
inline constexpr std::size_t kMaximumTerminalStateHeadJsonBytes = 4096U;
inline constexpr std::size_t kMaximumStopCorrelationBytes = 64U;

struct ControlRebind final {
    datacube::Digest32 operation_id;
    std::string generation;
    std::string reason;
};

struct ControlCancel final {
    datacube::Digest32 operation_id;
    std::string reason;
};

struct ControlRetry final {
    datacube::Digest32 operation_id;
    std::string reason;
};

struct ControlCustodyDispatch final {
    std::string activation_id;
    std::uint64_t activation_generation{0U};
    datacube::Digest32 receiver_request_digest;
    datacube::Digest32 dispatch_request_digest;
    std::string reason;
};

struct ControlCustodyDispatchStatus final {
    std::string activation_id;
    std::uint64_t activation_generation{0U};
    datacube::Digest32 dispatch_request_digest;
};

struct ControlCustodyDispatchInventory final {
    std::string activation_id;
    std::uint64_t activation_generation{0U};
    std::optional<datacube::Digest32> cursor;
    std::uint32_t limit{32U};
    std::uint32_t maximum_bytes{32'768U};
};

struct ControlCompact final {};
struct ControlConfiguration final {
    std::string candidate_path;
    std::string rollback_generation;
    std::string reason;
};

struct ControlActionCancel final {
    datacube::Digest32 action_id;
    std::string reason;
};

struct ControlQuiesce final {
    std::string reason;
};

struct ControlResume final {
    std::string reason;
};

struct ControlDrainShutdown final {
    std::uint32_t deadline_ms{0U};
    std::string reason;
    bool final_state_head{false};
    std::optional<std::string> correlation;
};

using ControlRequest = std::variant<
    ControlSubmit,
    ControlAuthor,
    ControlSnapshot,
    ControlStateHead,
    RuntimeInventory,
    ConfigurationHistoryRequest,
    ControlHistoryRequest,
    ControlWake,
    ControlShutdown,
    ControlRebind,
    ControlCancel,
    ControlRetry,
    ControlCustodyDispatch,
    ControlCustodyDispatchStatus,
    ControlCustodyDispatchInventory,
    ControlActionCancel,
    ControlCompact,
    ControlConfiguration,
    ControlQuiesce,
    ControlResume,
    ControlDrainShutdown,
    EvidenceQuery,
    OutboxQuery,
    ActionQuery,
    ActionResultQuery,
    ActionResultDiscovery,
    ResultReviewRequest,
    ResultReviewStatus,
    ResultReviewHistory,
    ConsumerInventory,
    PublicationInventory,
    SubscriptionInventory,
    SourceViewInventory,
    ViewBindings,
    ActionAdminRequest,
    OutboxAdminRequest,
    EvidenceFeed,
    ConsumerRequest,
    PublicationChannelRequest,
    SourceSubscriptionRequest,
    SourceViewRequest, ImportAutoRequest>;

struct ControlResponse final {
    bool ok{false};
    std::string json;
};

[[nodiscard]] datacube::Octets encode_control_request(
    const ControlRequest& request);
[[nodiscard]] ControlRequest decode_control_request(
    datacube::OctetView payload);
[[nodiscard]] datacube::Octets encode_control_response(
    const ControlResponse& response);
[[nodiscard]] ControlResponse decode_control_response(
    datacube::OctetView payload);
[[nodiscard]] datacube::Digest32 control_request_id(datacube::OctetView payload);

}  // namespace natrav_overlay
