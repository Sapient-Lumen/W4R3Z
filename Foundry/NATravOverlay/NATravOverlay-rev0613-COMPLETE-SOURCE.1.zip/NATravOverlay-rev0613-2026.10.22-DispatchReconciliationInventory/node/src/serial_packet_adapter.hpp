#pragma once
namespace natrav_overlay {
// The existing product executable, in an explicitly pinned adapter role. No
// node configuration, identity file, journal or local-control state is opened.
[[nodiscard]] int run_serial_packet_adapter(int argc, char* argv[]);
}
