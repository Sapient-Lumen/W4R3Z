#include "serial_transport.hpp"

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cstddef>
#include <cstdint>
#include <fcntl.h>
#include <memory>
#include <mutex>
#include <optional>
#include <poll.h>
#include <span>
#include <string>
#include <string_view>
#include <sys/ioctl.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include <termios.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace natrav_overlay {
namespace {

inline constexpr std::string_view kSerialPrefix = "serial-v1|";
inline constexpr std::size_t kMaximumSerialPathBytes = 1024U;
inline constexpr std::size_t kMaximumSerialIoQuantum = 4096U;
inline constexpr std::chrono::milliseconds kListenerReopenDelay{100};

[[nodiscard]] int remaining_poll_ms(const Deadline deadline) {
    const auto now = std::chrono::steady_clock::now();
    if (now >= deadline) {
        return 0;
    }
    const auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(
        deadline - now);
    const auto count = std::max<std::chrono::milliseconds::rep>(
        remaining.count(), 1);
    return static_cast<int>(std::min<std::chrono::milliseconds::rep>(
        count, static_cast<std::chrono::milliseconds::rep>(INT_MAX)));
}

[[nodiscard]] short wait_serial_fd(
    const int fd,
    const short events,
    const Deadline deadline,
    IoCounters& counters,
    const std::string_view operation) {
    while (true) {
        const int timeout = remaining_poll_ms(deadline);
        if (timeout == 0) {
            app_fail("IO_TIMEOUT", std::string(operation));
        }
        pollfd item{.fd = fd, .events = events, .revents = 0};
        ++counters.poll_calls;
        const int result = ::poll(&item, 1U, timeout);
        if (result < 0) {
            if (errno == EINTR) {
                ++counters.interrupted;
                continue;
            }
            app_fail(
                "SERIAL_POLL_FAILED",
                datacube::errno_detail(operation, errno));
        }
        if (result == 0) {
            app_fail("IO_TIMEOUT", std::string(operation));
        }
        if ((item.revents & POLLNVAL) != 0) {
            app_fail("SERIAL_DEVICE_INVALID", std::string(operation));
        }
        return item.revents;
    }
}

[[nodiscard]] bool unreserved_path_byte(const unsigned char value) noexcept {
    return (value >= static_cast<unsigned char>('A') &&
            value <= static_cast<unsigned char>('Z')) ||
        (value >= static_cast<unsigned char>('a') &&
         value <= static_cast<unsigned char>('z')) ||
        (value >= static_cast<unsigned char>('0') &&
         value <= static_cast<unsigned char>('9')) ||
        value == static_cast<unsigned char>('/') ||
        value == static_cast<unsigned char>('.') ||
        value == static_cast<unsigned char>('_') ||
        value == static_cast<unsigned char>('-') ||
        value == static_cast<unsigned char>('~');
}

[[nodiscard]] std::string encode_serial_path(const std::string_view path) {
    static constexpr char kHex[] = "0123456789ABCDEF";
    std::string encoded;
    encoded.reserve(path.size());
    for (const char raw : path) {
        const auto value = static_cast<unsigned char>(raw);
        if (unreserved_path_byte(value)) {
            encoded.push_back(static_cast<char>(value));
        } else {
            encoded.push_back('%');
            encoded.push_back(kHex[(value >> 4U) & 0x0fU]);
            encoded.push_back(kHex[value & 0x0fU]);
        }
    }
    return encoded;
}

[[nodiscard]] std::optional<unsigned char> hex_value(const char value) noexcept {
    if (value >= '0' && value <= '9') {
        return static_cast<unsigned char>(value - '0');
    }
    if (value >= 'A' && value <= 'F') {
        return static_cast<unsigned char>(10 + value - 'A');
    }
    if (value >= 'a' && value <= 'f') {
        return static_cast<unsigned char>(10 + value - 'a');
    }
    return std::nullopt;
}

[[nodiscard]] std::string decode_serial_path(const std::string_view encoded) {
    std::string path;
    path.reserve(encoded.size());
    for (std::size_t offset = 0U; offset < encoded.size();) {
        if (encoded[offset] != '%') {
            path.push_back(encoded[offset]);
            ++offset;
            continue;
        }
        if (offset + 2U >= encoded.size()) {
            app_fail("SERIAL_LOCATOR_INVALID", "truncated path escape");
        }
        const auto high = hex_value(encoded[offset + 1U]);
        const auto low = hex_value(encoded[offset + 2U]);
        if (!high.has_value() || !low.has_value()) {
            app_fail("SERIAL_LOCATOR_INVALID", "invalid path escape");
        }
        const auto value = static_cast<unsigned char>(
            static_cast<unsigned>(*high) * 16U + static_cast<unsigned>(*low));
        if (value < 0x20U || value == 0x7fU) {
            app_fail("SERIAL_LOCATOR_INVALID", "path contains a control byte");
        }
        path.push_back(static_cast<char>(value));
        offset += 3U;
    }
    if (path.empty() || path.size() > kMaximumSerialPathBytes ||
        path.front() != '/') {
        app_fail(
            "SERIAL_LOCATOR_INVALID",
            "serial path must be an absolute path of 1..1024 bytes");
    }
    return path;
}

[[nodiscard]] std::vector<std::string_view> split_fields(
    const std::string_view text) {
    std::vector<std::string_view> fields;
    std::size_t begin = 0U;
    while (begin <= text.size()) {
        const auto separator = text.find('|', begin);
        if (separator == std::string_view::npos) {
            fields.push_back(text.substr(begin));
            break;
        }
        fields.push_back(text.substr(begin, separator - begin));
        begin = separator + 1U;
    }
    return fields;
}

[[nodiscard]] std::string_view field_value(
    const std::string_view field,
    const std::string_view name) {
    const std::string prefix = std::string(name) + "=";
    if (!field.starts_with(prefix) || field.size() == prefix.size()) {
        app_fail(
            "SERIAL_LOCATOR_INVALID",
            "expected nonempty field " + std::string(name));
    }
    return field.substr(prefix.size());
}

[[nodiscard]] speed_t serial_speed(const std::uint32_t baud) {
    switch (baud) {
        case 1'200U: return B1200;
        case 2'400U: return B2400;
        case 4'800U: return B4800;
        case 9'600U: return B9600;
        case 19'200U: return B19200;
        case 38'400U: return B38400;
#ifdef B57600
        case 57'600U: return B57600;
#endif
#ifdef B115200
        case 115'200U: return B115200;
#endif
#ifdef B230400
        case 230'400U: return B230400;
#endif
        default:
            app_fail(
                "SERIAL_SETTING_UNSUPPORTED",
                "unsupported serial baud rate " + std::to_string(baud));
    }
}

[[nodiscard]] bool disconnected_errno(const int value) noexcept {
    return value == EIO || value == ENXIO || value == ENODEV ||
        value == EBADF;
}

[[nodiscard]] std::string device_observation(
    const SerialTransportLocator& locator,
    const struct stat& status) {
    return "path=" + locator.path + ";rdev=" +
        std::to_string(static_cast<unsigned long long>(major(status.st_rdev))) +
        ":" +
        std::to_string(static_cast<unsigned long long>(minor(status.st_rdev))) +
        ";inode=" +
        std::to_string(static_cast<unsigned long long>(status.st_ino));
}

class SerialExclusiveGuard final {
public:
    explicit SerialExclusiveGuard(const int fd, const bool armed = true) noexcept : fd_(fd), armed_(armed) {}
    ~SerialExclusiveGuard() {
#ifdef TIOCNXCL
        if (armed_) {
            static_cast<void>(::ioctl(fd_, TIOCNXCL));
        }
#endif
    }
    SerialExclusiveGuard(const SerialExclusiveGuard&) = delete;
    SerialExclusiveGuard& operator=(const SerialExclusiveGuard&) = delete;
    void dismiss() noexcept { armed_ = false; }

private:
    int fd_{-1};
    bool armed_{true};
};

class SerialDevice final {
public:
    SerialDevice(
        datacube::Fd fd,
        const termios& original,
        std::string observation, const bool exclusive = true) noexcept
        : fd_(std::move(fd)),
          original_(original),
          restore_(true),
          exclusive_(exclusive),
          observation_(std::move(observation)) {}

    ~SerialDevice() { restore(); }
    SerialDevice(const SerialDevice&) = delete;
    SerialDevice& operator=(const SerialDevice&) = delete;
    SerialDevice(SerialDevice&&) = delete;
    SerialDevice& operator=(SerialDevice&&) = delete;

    [[nodiscard]] int fd() const noexcept { return fd_.get(); }
    [[nodiscard]] const std::string& observation() const noexcept {
        return observation_;
    }

private:
    void restore() noexcept {
        if (restore_ && fd_.get() >= 0) {
            static_cast<void>(::tcsetattr(fd_.get(), TCSANOW, &original_));
#ifdef TIOCNXCL
            if (exclusive_) { static_cast<void>(::ioctl(fd_.get(), TIOCNXCL)); }
#endif
            restore_ = false;
        }
    }

    datacube::Fd fd_;
    termios original_{};
    bool restore_{false};
    bool exclusive_{true};
    std::string observation_;
};

// Packet-adapter opening rejects aliases at every component; the older direct
// stream carrier retains its original path policy for compatibility.
[[nodiscard]] int open_packet_tty_path(const std::string& path) {
    if (path.empty() || path.front() != '/' || path.back() == '/') {
        app_fail("SERIAL_PACKET_PATH_INVALID", "canonical absolute TTY path required");
    }
    datacube::Fd parent(::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC));
    if (parent.get() < 0) { app_fail("SERIAL_OPEN_FAILED", "open root directory"); }
    std::size_t begin = 1U;
    while (begin < path.size()) {
        const auto end = path.find('/', begin);
        const auto part = path.substr(begin, end == std::string::npos ? end : end - begin);
        if (part.empty() || part == "." || part == "..") {
            app_fail("SERIAL_PACKET_PATH_INVALID", "noncanonical path component");
        }
        if (end == std::string::npos) {
            return ::openat(parent.get(), part.c_str(),
                O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC | O_NOFOLLOW);
        }
        datacube::Fd next(::openat(parent.get(), part.c_str(),
            O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW));
        if (next.get() < 0) { app_fail("SERIAL_PACKET_PATH_INVALID", "parent traversal rejected"); }
        parent = std::move(next);
        begin = end + 1U;
    }
    app_fail("SERIAL_PACKET_PATH_INVALID", "missing TTY name");
}

[[nodiscard]] std::unique_ptr<SerialDevice> open_serial_device(
    const SerialTransportLocator& locator, const bool packet_path = false) {
    const int raw = packet_path ? open_packet_tty_path(locator.path) : ::open(
        locator.path.c_str(),
        O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC | O_NOFOLLOW);
    if (raw < 0) {
        if (errno == ELOOP) {
            app_fail(
                "SERIAL_PATH_SYMLINK_REJECTED",
                "serial path final component must not be a symlink: " +
                    locator.path);
        }
        if (errno == EBUSY) {
            app_fail(
                "SERIAL_DEVICE_BUSY",
                datacube::errno_detail(locator.path, errno));
        }
        app_fail(
            "SERIAL_OPEN_FAILED",
            datacube::errno_detail(locator.path, errno));
    }
    datacube::Fd fd(raw);
    struct stat status {};
    if (::fstat(fd.get(), &status) != 0) {
        app_fail(
            "SERIAL_STAT_FAILED",
            datacube::errno_detail(locator.path, errno));
    }
    if (!S_ISCHR(status.st_mode)) {
        app_fail(
            "SERIAL_DEVICE_NOT_CHARACTER",
            "serial locator is not a character device: " + locator.path);
    }

    if (packet_path) {
        if ((status.st_uid != ::geteuid() && status.st_uid != 0U) ||
            (status.st_mode & S_IWOTH) != 0U || status.st_nlink != 1U) {
            app_fail("SERIAL_PACKET_DEVICE_UNSAFE", "TTY owner, mode or link count rejected");
        }
        // TIOCEXCL can outlive a killed child while a PTY/master or driver
        // still owns the tty. Use a crash-released flock lease in this role;
        // never clear a TIOCEXCL flag belonging to another user of the device.
        // This is cooperative ownership, not a hostile same-UID sandbox.
        if (::flock(fd.get(), LOCK_EX | LOCK_NB) != 0) {
            app_fail("SERIAL_DEVICE_BUSY", "packet TTY lease unavailable");
        }
    }
    termios original {};
    if (::tcgetattr(fd.get(), &original) != 0) {
        app_fail(
            "SERIAL_TERMIOS_UNAVAILABLE",
            datacube::errno_detail(locator.path, errno));
    }
    if (!packet_path && ::ioctl(fd.get(), TIOCEXCL) != 0) {
        app_fail(
            "SERIAL_EXCLUSIVE_FAILED",
            datacube::errno_detail(locator.path, errno));
    }
    SerialExclusiveGuard exclusive_guard(fd.get(), !packet_path);

    termios configured = original;
    configured.c_iflag &= static_cast<tcflag_t>(~(
        IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL |
        INPCK | IXON | IXOFF | IXANY));
    configured.c_oflag &= static_cast<tcflag_t>(~OPOST);
    configured.c_lflag &= static_cast<tcflag_t>(~(
        ECHO | ECHONL | ICANON | ISIG | IEXTEN));
    configured.c_cflag &= static_cast<tcflag_t>(~(
        CSIZE | PARENB | PARODD | CSTOPB));
#ifdef CRTSCTS
    configured.c_cflag &= static_cast<tcflag_t>(~CRTSCTS);
#endif
    configured.c_cflag |= static_cast<tcflag_t>(CLOCAL | CREAD);
    configured.c_cflag |= locator.data_bits == 7U ? CS7 : CS8;
    if (locator.parity != SerialParity::none) {
        configured.c_iflag |= INPCK;
        configured.c_cflag |= PARENB;
        if (locator.parity == SerialParity::odd) {
            configured.c_cflag |= PARODD;
        }
    }
    if (locator.stop_bits == 2U) {
        configured.c_cflag |= CSTOPB;
    }
    if (locator.flow_control == SerialFlowControl::software) {
        configured.c_iflag |= static_cast<tcflag_t>(IXON | IXOFF);
    } else if (locator.flow_control == SerialFlowControl::hardware) {
#ifdef CRTSCTS
        configured.c_cflag |= CRTSCTS;
#else
        app_fail(
            "SERIAL_SETTING_UNSUPPORTED",
            "hardware flow control is unavailable on this platform");
#endif
    }
    configured.c_cc[VMIN] = 1;
    configured.c_cc[VTIME] = 0;
    const speed_t speed = serial_speed(locator.baud);
    if (::cfsetispeed(&configured, speed) != 0 ||
        ::cfsetospeed(&configured, speed) != 0) {
        app_fail(
            "SERIAL_SETTING_UNSUPPORTED",
            datacube::errno_detail("serial speed", errno));
    }
    if (::tcsetattr(fd.get(), TCSANOW, &configured) != 0) {
        app_fail(
            "SERIAL_CONFIGURATION_FAILED",
            datacube::errno_detail(locator.path, errno));
    }
    auto device = std::make_unique<SerialDevice>(
        std::move(fd), original, device_observation(locator, status), !packet_path);
    exclusive_guard.dismiss();
    return device;
}

struct SerialListenerLease final {
    std::atomic<bool> active{false};
};

class SerialOrderedByteStream final : public OrderedByteStream {
public:
    SerialOrderedByteStream(
        std::unique_ptr<SerialDevice> device,
        std::shared_ptr<SerialListenerLease> listener_lease = {}) noexcept
        : device_(std::move(device)), listener_lease_(std::move(listener_lease)) {}

    ~SerialOrderedByteStream() override {
        device_.reset();
        if (listener_lease_) {
            listener_lease_->active.store(false, std::memory_order_release);
        }
    }

    [[nodiscard]] TransportKind transport_kind() const noexcept override {
        return TransportKind::serial;
    }

    [[nodiscard]] std::size_t read_some(
        const std::span<std::uint8_t> buffer,
        const Deadline deadline,
        IoCounters& counters,
        const std::string_view operation) override {
        if (!device_ || device_->fd() < 0 || buffer.empty()) {
            app_fail("SERIAL_DEVICE_INVALID", std::string(operation));
        }
        const auto limited = buffer.first(std::min(
            buffer.size(), kMaximumSerialIoQuantum));
        while (true) {
            const short events = wait_serial_fd(
                device_->fd(), POLLIN, deadline, counters, operation);
            if ((events & (POLLIN | POLLHUP | POLLERR)) == 0) {
                continue;
            }
            ++counters.read_calls;
            const ssize_t count = ::read(
                device_->fd(), limited.data(), limited.size());
            if (count >= 0) {
                return static_cast<std::size_t>(count);
            }
            if (errno == EINTR) {
                ++counters.interrupted;
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                ++counters.would_block;
                continue;
            }
            if (disconnected_errno(errno)) {
                app_fail(
                    "SERIAL_DISCONNECTED",
                    datacube::errno_detail(device_->observation(), errno));
            }
            app_fail(
                "SERIAL_READ_FAILED",
                datacube::errno_detail(operation, errno));
        }
    }

    [[nodiscard]] std::size_t write_some(
        const datacube::OctetView bytes,
        const Deadline deadline,
        IoCounters& counters,
        const std::string_view operation) override {
        if (!device_ || device_->fd() < 0 || bytes.empty()) {
            app_fail("SERIAL_DEVICE_INVALID", std::string(operation));
        }
        const auto limited = bytes.first(std::min(
            bytes.size(), kMaximumSerialIoQuantum));
        while (true) {
            const short events = wait_serial_fd(
                device_->fd(), POLLOUT, deadline, counters, operation);
            if ((events & (POLLHUP | POLLERR)) != 0 &&
                (events & POLLOUT) == 0) {
                app_fail(
                    "SERIAL_DISCONNECTED",
                    device_->observation());
            }
            ++counters.write_calls;
            const ssize_t count = ::write(
                device_->fd(), limited.data(), limited.size());
            if (count > 0) {
                return static_cast<std::size_t>(count);
            }
            if (count == 0) {
                app_fail("SERIAL_WRITE_CLOSED", "serial write made no progress");
            }
            if (errno == EINTR) {
                ++counters.interrupted;
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                ++counters.would_block;
                continue;
            }
            if (disconnected_errno(errno) || errno == EPIPE) {
                app_fail(
                    "SERIAL_DISCONNECTED",
                    datacube::errno_detail(device_->observation(), errno));
            }
            app_fail(
                "SERIAL_WRITE_FAILED",
                datacube::errno_detail(operation, errno));
        }
    }

    void shutdown_write() override {
        app_fail(
            "TRANSPORT_HALF_CLOSE_UNSUPPORTED",
            "POSIX serial/TTY streams have no TCP-style write half-close");
    }

private:
    std::unique_ptr<SerialDevice> device_;
    std::shared_ptr<SerialListenerLease> listener_lease_;
};

class SerialTransportConnector final : public TransportConnector {
public:
    [[nodiscard]] std::unique_ptr<OrderedByteStream> connect(
        const TransportLocator& locator,
        const Deadline deadline,
        IoCounters& counters) const override {
        static_cast<void>(counters);
        if (std::chrono::steady_clock::now() >= deadline) {
            app_fail("IO_TIMEOUT", "serial connect");
        }
        auto device = open_serial_device(serial_transport_locator(locator));
        if (std::chrono::steady_clock::now() >= deadline) {
            app_fail("IO_TIMEOUT", "serial connect");
        }
        return std::make_unique<SerialOrderedByteStream>(std::move(device));
    }
};

class SerialTransportListener final : public TransportListener {
public:
    explicit SerialTransportListener(TransportLocator locator)
        : locator_(std::move(locator)),
          lease_(std::make_shared<SerialListenerLease>()),
          pending_(open_serial_device(serial_transport_locator(locator_))) {}

    [[nodiscard]] TransportKind transport_kind() const noexcept override {
        return TransportKind::serial;
    }

    [[nodiscard]] int readiness_handle() const noexcept override {
        std::lock_guard<std::mutex> lock(mutex_);
        if (lease_->active.load(std::memory_order_acquire)) {
            return -1;
        }
        if (!pending_) {
            const auto now = std::chrono::steady_clock::now();
            if (now < reopen_after_) {
                return -1;
            }
            try {
                pending_ = open_serial_device(
                    serial_transport_locator(locator_));
            } catch (...) {
                reopen_after_ = now + kListenerReopenDelay;
                return -1;
            }
        }
        return pending_->fd();
    }

    [[nodiscard]] TransportLocator bound_locator() const override {
        return locator_;
    }

    [[nodiscard]] std::unique_ptr<OrderedByteStream> accept_ready() override {
        std::lock_guard<std::mutex> lock(mutex_);
        if (lease_->active.load(std::memory_order_acquire)) {
            return nullptr;
        }
        if (!pending_) {
            pending_ = open_serial_device(serial_transport_locator(locator_));
        }
        pollfd item{.fd = pending_->fd(), .events = POLLIN, .revents = 0};
        int result = 0;
        do {
            result = ::poll(&item, 1U, 0);
        } while (result < 0 && errno == EINTR);
        if (result < 0) {
            app_fail(
                "SERIAL_POLL_FAILED",
                datacube::errno_detail("serial listener readiness", errno));
        }
        if (result == 0 ||
            (item.revents & (POLLIN | POLLHUP | POLLERR)) == 0) {
            return nullptr;
        }
        if ((item.revents & POLLNVAL) != 0) {
            app_fail("SERIAL_DEVICE_INVALID", "serial listener descriptor");
        }
        auto accepted = std::move(pending_);
        lease_->active.store(true, std::memory_order_release);
        return std::make_unique<SerialOrderedByteStream>(
            std::move(accepted), lease_);
    }

private:
    TransportLocator locator_;
    std::shared_ptr<SerialListenerLease> lease_;
    mutable std::mutex mutex_;
    mutable std::unique_ptr<SerialDevice> pending_;
    mutable std::chrono::steady_clock::time_point reopen_after_{};
};

}  // namespace

std::unique_ptr<OrderedByteStream> open_serial_packet_stream(
    const SerialTransportLocator& locator, const Deadline deadline) {
    if (locator.data_bits != 8U) {
        app_fail("SERIAL_PACKET_SETTING_UNSUPPORTED", "NSP1 requires eight data bits");
    }
    if (std::chrono::steady_clock::now() >= deadline) { app_fail("IO_TIMEOUT", "packet TTY open"); }
    auto device = open_serial_device(locator, true);
    if (std::chrono::steady_clock::now() >= deadline) { app_fail("IO_TIMEOUT", "packet TTY configure"); }
    return std::make_unique<SerialOrderedByteStream>(std::move(device));
}

std::string_view serial_parity_name(const SerialParity parity) {
    switch (parity) {
        case SerialParity::none: return "none";
        case SerialParity::even: return "even";
        case SerialParity::odd: return "odd";
    }
    app_fail("SERIAL_SETTING_UNSUPPORTED", "unknown serial parity");
}

std::string_view serial_flow_control_name(
    const SerialFlowControl flow_control) {
    switch (flow_control) {
        case SerialFlowControl::none: return "none";
        case SerialFlowControl::software: return "software";
        case SerialFlowControl::hardware: return "hardware";
    }
    app_fail("SERIAL_SETTING_UNSUPPORTED", "unknown serial flow control");
}

std::string serial_transport_locator_text(
    const SerialTransportLocator& locator) {
    static_cast<void>(serial_speed(locator.baud));
    const bool has_control = std::any_of(
        locator.path.begin(), locator.path.end(), [](const char raw) {
            const auto value = static_cast<unsigned char>(raw);
            return value < 0x20U || value == 0x7fU;
        });
    if (locator.path.empty() || locator.path.size() > kMaximumSerialPathBytes ||
        locator.path.front() != '/' || has_control) {
        app_fail("SERIAL_LOCATOR_INVALID", "invalid serial device path");
    }
    if (locator.data_bits != 7U && locator.data_bits != 8U) {
        app_fail("SERIAL_SETTING_UNSUPPORTED", "data bits must be 7 or 8");
    }
    if (locator.stop_bits != 1U && locator.stop_bits != 2U) {
        app_fail("SERIAL_SETTING_UNSUPPORTED", "stop bits must be 1 or 2");
    }
    return std::string(kSerialPrefix) +
        "path=" + encode_serial_path(locator.path) +
        "|baud=" + std::to_string(locator.baud) +
        "|data=" + std::to_string(locator.data_bits) +
        "|parity=" + std::string(serial_parity_name(locator.parity)) +
        "|stop=" + std::to_string(locator.stop_bits) +
        "|flow=" +
            std::string(serial_flow_control_name(locator.flow_control));
}

TransportLocator parse_serial_transport_locator(const std::string_view text) {
    const auto fields = split_fields(text);
    if (fields.size() != 7U || fields[0U] != "serial-v1") {
        app_fail(
            "SERIAL_LOCATOR_INVALID",
            "serial locator must use canonical serial-v1 fields");
    }
    const auto path = decode_serial_path(field_value(fields[1U], "path"));
    const auto baud = static_cast<std::uint32_t>(parse_u64(
        field_value(fields[2U], "baud"),
        "serial baud", 1U, 4'000'000U));
    static_cast<void>(serial_speed(baud));
    const auto data_bits = static_cast<std::uint8_t>(parse_u64(
        field_value(fields[3U], "data"),
        "serial data bits", 7U, 8U));
    const auto parity_text = field_value(fields[4U], "parity");
    SerialParity parity = SerialParity::none;
    if (parity_text == "none") {
        parity = SerialParity::none;
    } else if (parity_text == "even") {
        parity = SerialParity::even;
    } else if (parity_text == "odd") {
        parity = SerialParity::odd;
    } else {
        app_fail(
            "SERIAL_SETTING_UNSUPPORTED",
            "parity must be none, even, or odd");
    }
    const auto stop_bits = static_cast<std::uint8_t>(parse_u64(
        field_value(fields[5U], "stop"),
        "serial stop bits", 1U, 2U));
    const auto flow_text = field_value(fields[6U], "flow");
    SerialFlowControl flow = SerialFlowControl::none;
    if (flow_text == "none") {
        flow = SerialFlowControl::none;
    } else if (flow_text == "software") {
        flow = SerialFlowControl::software;
    } else if (flow_text == "hardware") {
#ifdef CRTSCTS
        flow = SerialFlowControl::hardware;
#else
        app_fail(
            "SERIAL_SETTING_UNSUPPORTED",
            "hardware flow control is unavailable on this platform");
#endif
    } else {
        app_fail(
            "SERIAL_SETTING_UNSUPPORTED",
            "flow must be none, software, or hardware");
    }
    TransportLocator locator{
        .kind = TransportKind::serial,
        .tcp = {},
        .serial = SerialTransportLocator{
            .path = path,
            .baud = baud,
            .data_bits = data_bits,
            .parity = parity,
            .stop_bits = stop_bits,
            .flow_control = flow,
        },
        .udp = {},
        .unix_datagram = {},
    };
    if (serial_transport_locator_text(locator.serial) != text) {
        app_fail(
            "SERIAL_LOCATOR_NONCANONICAL",
            "serial locator must use the exact canonical spelling");
    }
    return locator;
}

const TransportConnector& serial_transport_connector() {
    static const SerialTransportConnector connector;
    return connector;
}

std::unique_ptr<TransportListener> listen_serial_transport(
    const TransportLocator& locator,
    const int backlog) {
    if (backlog < 1 || backlog > 1024) {
        app_fail("INVALID_LISTEN_BACKLOG", "backlog outside 1..1024");
    }
    static_cast<void>(serial_transport_locator(locator));
    return std::make_unique<SerialTransportListener>(locator);
}

}  // namespace natrav_overlay
