#pragma once
#include "common.hpp"
#include <optional>
#include <string>

namespace natrav_overlay {
// Current metadata, never a historical snapshot or a mutation precondition.
struct ConsumerInventory final {
    std::string kind{"all"}, lifecycle{"all"}, name, issuer, scope;
    std::optional<datacube::Digest32> instance;
    std::uint32_t offset{0U}, limit{16U}, maximum_bytes{32768U};
    std::optional<datacube::Digest32> selection;
};
void validate_consumer_inventory(const ConsumerInventory&);
[[nodiscard]] datacube::Octets encode_consumer_inventory(const ConsumerInventory&);
[[nodiscard]] ConsumerInventory decode_consumer_inventory(datacube::OctetView);
} // namespace natrav_overlay
