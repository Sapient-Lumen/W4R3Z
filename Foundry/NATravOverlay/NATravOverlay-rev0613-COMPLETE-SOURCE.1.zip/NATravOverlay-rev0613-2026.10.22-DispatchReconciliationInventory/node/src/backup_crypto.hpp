#pragma once

#include "common.hpp"

namespace natrav_overlay {

// Best-effort cleansing of the named byte vector on every scope exit, including
// exceptions. Not a claim that the whole process is immune to swap/core dumps.
class BackupWipeGuard final {
public:
    explicit BackupWipeGuard(datacube::Octets& bytes) noexcept : bytes_(bytes) {}
    ~BackupWipeGuard();
    BackupWipeGuard(const BackupWipeGuard&) = delete;
    BackupWipeGuard& operator=(const BackupWipeGuard&) = delete;
private:
    datacube::Octets& bytes_;
};

struct BackupKeyIdentity final {
    std::string generation;
    datacube::Digest32 id;
};

struct BackupCryptResult final {
    datacube::Octets bytes;
    BackupKeyIdentity key;
};

void backup_publication_test_pause(std::string_view point);

[[nodiscard]] BackupKeyIdentity initialize_backup_key(
    const std::filesystem::path& destination, std::string_view generation);
[[nodiscard]] BackupKeyIdentity check_backup_key(
    const std::filesystem::path& path);
[[nodiscard]] std::string backup_key_json(const BackupKeyIdentity& key);
[[nodiscard]] bool is_encrypted_backup(datacube::OctetView bytes) noexcept;
[[nodiscard]] BackupCryptResult encrypt_backup_bytes(
    datacube::OctetView plaintext, const std::filesystem::path& key_path);
[[nodiscard]] BackupCryptResult decrypt_backup_bytes(
    datacube::OctetView envelope, const std::filesystem::path& key_path,
    std::uint64_t maximum_plaintext_bytes);

}  // namespace natrav_overlay
