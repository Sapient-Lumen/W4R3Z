#pragma once

#include "journal.hpp"
#include "backup_crypto.hpp"
#include "state_recovery.hpp"

#include <cstdint>
#include <filesystem>
#include <optional>
#include <string>

namespace natrav_overlay {

struct BackupExportOptions final {
    std::filesystem::path state_directory;
    std::string node_id;
    std::string identity_generation;
    std::filesystem::path output_file;
    std::optional<std::filesystem::path> signing_private_key;
    std::optional<std::filesystem::path> signing_certificate;
    std::uint64_t maximum_journal_bytes{67'108'864U};
    std::optional<std::filesystem::path> encryption_key;
};

struct BackupVerifyOptions final {
    std::filesystem::path input_file;
    std::optional<std::string> expected_node_id;
    std::optional<std::string> expected_identity_generation;
    std::optional<std::filesystem::path> trusted_certificate;
    bool require_signature{false};
    std::uint64_t maximum_journal_bytes{67'108'864U};
    std::optional<std::filesystem::path> decryption_key;
    bool require_encryption{false};
    std::optional<datacube::Digest32> expected_backup_id;
};

struct BackupCorrelatedStopAuditOptions final {
    BackupVerifyOptions verification;
    CorrelatedStopAuditOptions audit;
};

struct BackupRestoreOptions final {
    std::filesystem::path input_file;
    std::filesystem::path destination_directory;
    std::string expected_node_id;
    std::string expected_identity_generation;
    std::optional<std::filesystem::path> trusted_certificate;
    bool require_signature{false};
    std::uint64_t maximum_journal_bytes{67'108'864U};
    std::optional<std::filesystem::path> decryption_key;
    bool require_encryption{false};
};

struct BackupReencryptOptions final {
    BackupVerifyOptions verification;
    std::filesystem::path output_file;
    std::filesystem::path encryption_key;
};

struct BackupResult final {
    std::filesystem::path path;
    std::string node_id;
    std::string identity_generation;
    std::uint32_t storage_schema_version{0U};
    std::uint64_t created_unix_ms{0U};
    std::uint64_t maintenance_generation{0U};
    std::uint64_t checkpoint_bytes{0U};
    std::uint64_t file_bytes{0U};
    datacube::Digest32 logical_state_digest;
    datacube::Digest32 checkpoint_digest;
    datacube::Digest32 backup_id;
    bool signed_backup{false};
    bool signature_valid{false};
    bool trusted_signer{false};
    std::optional<datacube::Digest32> signer_spki_sha256;
    bool encrypted{false};
    bool encryption_authenticated{false};
    std::uint64_t inner_file_bytes{0U};
    std::optional<BackupKeyIdentity> encryption_key;
    std::optional<BackupKeyIdentity> previous_encryption_key;
    std::optional<StateAuthentication> state_authentication;
};

struct BackupRestoreResult final {
    BackupResult backup;
    std::filesystem::path destination_directory;
    std::uint64_t restored_unix_ms{0U};
    std::uint64_t restored_journal_bytes{0U};
    std::optional<StateAuthentication> restored_authentication;
};

[[nodiscard]] BackupResult export_backup(const BackupExportOptions& options);
[[nodiscard]] BackupResult reencrypt_backup(const BackupReencryptOptions& options);
[[nodiscard]] BackupResult verify_backup(const BackupVerifyOptions& options);
[[nodiscard]] BackupResult verify_backup_exact_input(
    const BackupVerifyOptions& options,
    std::uint64_t expected_file_bytes,
    const datacube::Digest32& expected_file_digest);
[[nodiscard]] std::string audit_backup_correlated_stop(
    const BackupCorrelatedStopAuditOptions& options);
[[nodiscard]] BackupRestoreResult restore_backup(
    const BackupRestoreOptions& options);
[[nodiscard]] std::string backup_result_json(
    const BackupResult& result,
    std::string_view operation);
[[nodiscard]] std::string backup_restore_result_json(
    const BackupRestoreResult& result);

}  // namespace natrav_overlay
