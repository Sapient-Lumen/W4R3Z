#include "socket.hpp"

#include "datacube/natrav_peer_message.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <filesystem>
#include <poll.h>
#include <string>
#include <string_view>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <sys/types.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace natrav_overlay {
namespace {

using Exchange = datacube::NATravPeerClientHandshakeExchange;
using ExchangeStatus = datacube::NATravPeerClientExchangeStatus;
using ReportKind = datacube::NATravPeerTransportReportKind;
using HandshakeEvent = datacube::NATravPeerHandshakeEvent;

struct Coordinates final {
    datacube::Digest32 exchange;
    datacube::Digest32 transport;
    datacube::Digest32 process;
    datacube::Digest32 report;
    std::size_t ordinal{0U};
    std::size_t request_offset{0U};
    std::size_t response_offset{0U};

    explicit Coordinates(const Exchange& value)
        : exchange(value.exchange_binding_sha256().value()),
          transport(value.transport_binding_sha256().value()),
          process(value.process_binding_sha256().value()),
          report(value.report_binding_sha256().value()),
          ordinal(value.next_report_ordinal().value()),
          request_offset(value.pending_request_offset().value()),
          response_offset(value.next_response_offset().value()) {}
};

[[nodiscard]] int remaining_poll_ms(const Deadline deadline) {
    const auto now = std::chrono::steady_clock::now();
    if (now >= deadline) {
        return 0;
    }
    const auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(
        deadline - now);
    const auto count = std::max<std::chrono::milliseconds::rep>(
        remaining.count(), 1);
    return static_cast<int>(std::min<std::chrono::milliseconds::rep>(
        count, static_cast<std::chrono::milliseconds::rep>(INT_MAX)));
}

[[nodiscard]] short wait_fd(
    const int fd,
    const short events,
    const Deadline deadline,
    IoCounters& counters,
    const std::string_view operation) {
    while (true) {
        const int timeout = remaining_poll_ms(deadline);
        if (timeout == 0) {
            app_fail("IO_TIMEOUT", std::string(operation));
        }
        pollfd item{.fd = fd, .events = events, .revents = 0};
        ++counters.poll_calls;
        const int result = ::poll(&item, 1U, timeout);
        if (result < 0) {
            if (errno == EINTR) {
                ++counters.interrupted;
                continue;
            }
            app_fail("POLL_FAILED", datacube::errno_detail(operation, errno));
        }
        if (result == 0) {
            app_fail("IO_TIMEOUT", std::string(operation));
        }
        if ((item.revents & POLLNVAL) != 0) {
            app_fail("SOCKET_INVALID", std::string(operation));
        }
        return item.revents;
    }
}

[[nodiscard]] datacube::Digest32 instance_digest(
    const std::string_view domain,
    const std::string_view request_id) {
    datacube::Octets bytes;
    bytes.reserve(domain.size() + 1U + request_id.size());
    datacube::append_text(bytes, domain);
    datacube::append_u8(bytes, 0U);
    datacube::append_text(bytes, request_id);
    return datacube::sha256(bytes);
}

void report_unavailable(Exchange& exchange, const HandshakeEvent event) {
    Coordinates coordinates(exchange);
    const auto kind = event == HandshakeEvent::timeout ?
        ReportKind::timeout : ReportKind::early_eof;
    static_cast<void>(exchange.observe_unavailability(
        coordinates.exchange,
        coordinates.transport,
        coordinates.process,
        kind,
        coordinates.report,
        coordinates.ordinal,
        coordinates.request_offset,
        coordinates.response_offset,
        event));
}

[[nodiscard]] bool accepted(const Exchange& exchange) {
    const auto status = exchange.observation().status;
    return status.has_value() && *status == ExchangeStatus::accepted;
}

[[nodiscard]] bool awaiting(const Exchange& exchange) {
    const auto status = exchange.observation().status;
    return status.has_value() &&
        (*status == ExchangeStatus::awaiting_request_write ||
         *status == ExchangeStatus::awaiting_response);
}

[[nodiscard]] datacube::Octets encode_handshake_message(
    const datacube::NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    if (encoded.status != datacube::NATravPeerMessageEncodeStatus::accepted ||
        !encoded.payload.has_value()) {
        app_fail("HANDSHAKE_ENCODING_FAILED", encoded.classification);
    }
    return datacube::natrav_peer_encode_frame(*encoded.payload);
}

void send_handshake_error(
    ByteChannel& channel,
    const datacube::NATravPeerProtocolVersion& protocol,
    const std::string_view request_id,
    const std::string_view code,
    const std::string_view detail,
    const Deadline deadline,
    const IoOptions& options,
    IoCounters& counters) {
    datacube::NATravPeerHandshakeMessage response;
    response.kind = datacube::NATravPeerHandshakeMessageKind::error;
    response.protocol = protocol;
    response.request_id = std::string(request_id);
    response.error_code = std::string(code);
    response.error_message = std::string(detail);
    const auto frame = encode_handshake_message(response);
    write_bytes(channel, frame, deadline, options, counters);
}

}  // namespace

Deadline deadline_after(const std::chrono::milliseconds duration) {
    return std::chrono::steady_clock::now() + duration;
}

void validate_io_options(const IoOptions& options) {
    if (options.timeout.count() < 1 || options.timeout.count() > 60'000 ||
        options.read_quantum < 1U || options.read_quantum > 65'536U ||
        options.write_quantum < 1U || options.write_quantum > 65'536U ||
        options.maximum_received_bytes < 4U ||
        options.maximum_received_bytes >
            static_cast<std::size_t>(kMaximumPeerSessionBytes + 1'048'576U)) {
        app_fail("INVALID_IO_OPTIONS", "bounded socket options violated");
    }
}

PlainChannel::PlainChannel(const int fd) noexcept : fd_(fd) {}

std::size_t PlainChannel::read_some(
    const std::span<std::uint8_t> buffer,
    const Deadline deadline,
    IoCounters& counters,
    const std::string_view operation) {
    if (fd_ < 0 || buffer.empty()) {
        app_fail("SOCKET_INVALID", std::string(operation));
    }
    while (true) {
        const short events = wait_fd(fd_, POLLIN, deadline, counters, operation);
        if ((events & (POLLIN | POLLHUP | POLLERR)) == 0) {
            continue;
        }
        ++counters.read_calls;
        const ssize_t count = ::recv(fd_, buffer.data(), buffer.size(), 0);
        if (count >= 0) {
            return static_cast<std::size_t>(count);
        }
        if (errno == EINTR) {
            ++counters.interrupted;
            continue;
        }
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            ++counters.would_block;
            continue;
        }
        if (errno == ECONNRESET) {
            app_fail("PEER_RESET", datacube::errno_detail(operation, errno));
        }
        app_fail("SOCKET_READ_FAILED", datacube::errno_detail(operation, errno));
    }
}

std::size_t PlainChannel::write_some(
    const datacube::OctetView bytes,
    const Deadline deadline,
    IoCounters& counters,
    const std::string_view operation) {
    if (fd_ < 0 || bytes.empty()) {
        app_fail("SOCKET_INVALID", std::string(operation));
    }
    while (true) {
        static_cast<void>(wait_fd(fd_, POLLOUT, deadline, counters, operation));
        ++counters.write_calls;
        const ssize_t count = ::send(
            fd_, bytes.data(), bytes.size(), MSG_NOSIGNAL);
        if (count > 0) {
            return static_cast<std::size_t>(count);
        }
        if (count == 0) {
            app_fail("SOCKET_WRITE_CLOSED", "send made no progress");
        }
        if (errno == EINTR) {
            ++counters.interrupted;
            continue;
        }
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            ++counters.would_block;
            continue;
        }
        if (errno == EPIPE || errno == ECONNRESET) {
            app_fail("SOCKET_WRITE_CLOSED",
                datacube::errno_detail(operation, errno));
        }
        app_fail("SOCKET_WRITE_FAILED",
            datacube::errno_detail(operation, errno));
    }
}

void make_nonblocking(const int fd) {
    const int flags = ::fcntl(fd, F_GETFL);
    if (flags < 0 || ::fcntl(fd, F_SETFL, flags | O_NONBLOCK) != 0) {
        app_fail("SOCKET_CONFIGURATION_FAILED",
            datacube::errno_detail("nonblocking socket", errno));
    }
}

datacube::Fd connect_unix(
    const std::filesystem::path& path,
    const Deadline deadline,
    IoCounters& counters) {
    const std::string text = path.string();
    if (text.empty() || text.size() >= sizeof(sockaddr_un::sun_path)) {
        app_fail("CONTROL_PATH_INVALID", "Unix socket path is empty or too long");
    }
    sockaddr_un address{};
    address.sun_family = AF_UNIX;
    std::memcpy(address.sun_path, text.c_str(), text.size() + 1U);
    const int raw = ::socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
    if (raw < 0) {
        app_fail("CONTROL_CONNECT_FAILED", datacube::errno_detail(text, errno));
    }
    datacube::Fd candidate(raw);
    const int result = ::connect(
        candidate.get(), reinterpret_cast<const sockaddr*>(&address),
        static_cast<socklen_t>(sizeof(address)));
    if (result == 0) {
        return candidate;
    }
    if (errno != EINPROGRESS) {
        app_fail("CONTROL_CONNECT_FAILED", datacube::errno_detail(text, errno));
    }
    const short events = wait_fd(
        candidate.get(), POLLOUT, deadline, counters, "control connect");
    if ((events & (POLLOUT | POLLERR | POLLHUP)) == 0) {
        app_fail("CONTROL_CONNECT_FAILED", text);
    }
    int socket_error = 0;
    socklen_t length = sizeof(socket_error);
    if (::getsockopt(
            candidate.get(), SOL_SOCKET, SO_ERROR,
            &socket_error, &length) != 0) {
        app_fail("CONTROL_CONNECT_FAILED",
            datacube::errno_detail("getsockopt SO_ERROR", errno));
    }
    if (socket_error != 0) {
        app_fail("CONTROL_CONNECT_FAILED", datacube::errno_detail(text, socket_error));
    }
    return candidate;
}

datacube::Fd listen_unix(
    const std::filesystem::path& path,
    const int backlog) {
    if (backlog < 1 || backlog > 1024) {
        app_fail("INVALID_LISTEN_BACKLOG", "backlog outside 1..1024");
    }
    const std::string text = path.string();
    if (text.empty() || text.size() >= sizeof(sockaddr_un::sun_path)) {
        app_fail("CONTROL_PATH_INVALID", "Unix socket path is empty or too long");
    }
    struct stat existing {};
    if (::lstat(text.c_str(), &existing) == 0) {
        if (!S_ISSOCK(existing.st_mode) || existing.st_uid != ::geteuid()) {
            app_fail("CONTROL_PATH_OCCUPIED",
                "existing control path is not an owned Unix socket");
        }
        if (::unlink(text.c_str()) != 0) {
            app_fail("CONTROL_UNLINK_FAILED", datacube::errno_detail(text, errno));
        }
    } else if (errno != ENOENT) {
        app_fail("CONTROL_PATH_FAILED", datacube::errno_detail(text, errno));
    }

    sockaddr_un address{};
    address.sun_family = AF_UNIX;
    std::memcpy(address.sun_path, text.c_str(), text.size() + 1U);
    const int raw = ::socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
    if (raw < 0) {
        app_fail("CONTROL_LISTEN_FAILED", datacube::errno_detail(text, errno));
    }
    datacube::Fd candidate(raw);
    if (::bind(
            candidate.get(), reinterpret_cast<const sockaddr*>(&address),
            static_cast<socklen_t>(sizeof(address))) != 0) {
        app_fail("CONTROL_LISTEN_FAILED", datacube::errno_detail(text, errno));
    }
    if (::chmod(text.c_str(), S_IRUSR | S_IWUSR) != 0) {
        const int saved = errno;
        static_cast<void>(::unlink(text.c_str()));
        app_fail("CONTROL_PERMISSION_FAILED", datacube::errno_detail(text, saved));
    }
    if (::listen(candidate.get(), backlog) != 0) {
        const int saved = errno;
        static_cast<void>(::unlink(text.c_str()));
        app_fail("CONTROL_LISTEN_FAILED", datacube::errno_detail(text, saved));
    }
    return candidate;
}

void write_bytes(
    const int fd,
    const datacube::OctetView bytes,
    const Deadline deadline,
    const IoOptions& options,
    IoCounters& counters) {
    PlainChannel channel(fd);
    write_bytes(channel, bytes, deadline, options, counters);
}

void write_bytes(
    ByteChannel& channel,
    const datacube::OctetView bytes,
    const Deadline deadline,
    const IoOptions& options,
    IoCounters& counters) {
    validate_io_options(options);
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const std::size_t request = std::min(
            options.write_quantum, bytes.size() - offset);
        const auto progress = channel.write_some(
            bytes.subspan(offset, request), deadline, counters, "socket write");
        if (progress == 0U || progress > request) {
            app_fail("SOCKET_WRITE_CLOSED", "channel write made invalid progress");
        }
        if (progress < request) {
            ++counters.short_writes;
        }
        offset += progress;
        counters.write_bytes += progress;
    }
}

void write_frame(
    const int fd,
    const datacube::OctetView payload,
    const Deadline deadline,
    const IoOptions& options,
    IoCounters& counters) {
    const auto frame = datacube::natrav_peer_encode_frame(payload);
    write_bytes(fd, frame, deadline, options, counters);
}

void write_frame(
    ByteChannel& channel,
    const datacube::OctetView payload,
    const Deadline deadline,
    const IoOptions& options,
    IoCounters& counters) {
    const auto frame = datacube::natrav_peer_encode_frame(payload);
    write_bytes(channel, frame, deadline, options, counters);
}

FramedReader::FramedReader(IoOptions options) : options_(std::move(options)) {
    validate_io_options(options_);
}

datacube::Octets FramedReader::read_frame(
    const int fd,
    const Deadline deadline,
    IoCounters& counters) {
    PlainChannel channel(fd);
    return read_frame(channel, deadline, counters);
}

datacube::Octets FramedReader::read_frame(
    ByteChannel& channel,
    const Deadline deadline,
    IoCounters& counters) {
    if (!queued_.empty()) {
        auto result = std::move(queued_.front());
        queued_.pop_front();
        ++counters.frames_read;
        return result;
    }
    std::vector<std::uint8_t> buffer(options_.read_quantum);
    while (queued_.empty()) {
        const auto progress = channel.read_some(
            buffer, deadline, counters, "socket read frame");
        if (progress > 0U) {
            if (progress < buffer.size()) {
                ++counters.short_reads;
            }
            if (progress > options_.maximum_received_bytes - observed_bytes_) {
                app_fail("RESPONSE_LIMIT_EXCEEDED",
                    "socket received-byte limit exceeded");
            }
            observed_bytes_ += progress;
            counters.read_bytes += progress;
            std::vector<datacube::Octets> emitted;
            const auto observation = decoder_.feed(
                datacube::OctetView(buffer.data(), progress), emitted);
            if (observation.status ==
                datacube::NATravPeerStreamStatus::malformed_frame) {
                app_fail("MALFORMED_FRAME", "frame header is outside envelope");
            }
            for (auto& frame : emitted) {
                queued_.push_back(std::move(frame));
                if (queued_.size() > 4U) {
                    app_fail("TOO_MANY_QUEUED_FRAMES",
                        "connection exceeded four staged frames");
                }
            }
            continue;
        }
        std::vector<datacube::Octets> emitted;
        const auto observation = decoder_.finish(emitted);
        if (observation.status ==
            datacube::NATravPeerStreamStatus::peer_unavailable) {
            app_fail("INCOMPLETE_FRAME_EOF", "peer closed during a frame");
        }
        app_fail("PEER_CLOSED", "peer closed before the next frame");
    }
    auto result = std::move(queued_.front());
    queued_.pop_front();
    ++counters.frames_read;
    return result;
}

std::size_t FramedReader::queued_frames() const noexcept {
    return queued_.size();
}

ClientHandshakeResult perform_client_handshake(
    const int fd,
    const std::string_view local_node,
    const std::string_view expected_peer,
    std::string request_id,
    const Deadline deadline,
    const IoOptions& options) {
    PlainChannel channel(fd);
    return perform_client_handshake(
        channel, local_node, expected_peer, std::move(request_id), deadline, options);
}

ClientHandshakeResult perform_client_handshake(
    ByteChannel& channel,
    const std::string_view local_node,
    const std::string_view expected_peer,
    std::string request_id,
    const Deadline deadline,
    const IoOptions& options) {
    validate_io_options(options);
    require_node_id(local_node, "local node");
    require_node_id(expected_peer, "expected peer");
    datacube::NATravPeerClientHandshakeInput input;
    input.protocol = {"NATRAV_OVERLAY_PEER", 1, 0};
    input.request_id = std::move(request_id);
    input.local_artifact = node_artifact_identity(local_node);
    input.expected_peer_artifact = node_artifact_identity(expected_peer);
    input.required_capabilities = node_capabilities();
    const auto preparation = datacube::natrav_peer_prepare_client_handshake(input);
    if (preparation.status !=
            datacube::NATravPeerClientPreparationStatus::prepared ||
        !preparation.prepared.has_value()) {
        app_fail("HANDSHAKE_PREPARATION_FAILED", preparation.classification);
    }
    const auto& prepared = *preparation.prepared;
    const auto exchange_id = instance_digest("NATIVE_SOCKET_EXCHANGE_V1", input.request_id);
    const auto transport_id = instance_digest("NATIVE_SOCKET_TRANSPORT_V1", input.request_id);
    const auto process_id = instance_digest("NATIVE_SOCKET_PROCESS_V1", input.request_id);
    auto owner = Exchange::create(
        prepared, exchange_id, transport_id, process_id);
    if (!owner.has_value()) {
        app_fail("HANDSHAKE_PLAN_REJECTED", "exchange construction rejected");
    }
    Exchange& exchange = *owner;
    IoCounters counters;

    while (true) {
        const auto pending = exchange.pending_request_bytes();
        if (!pending.has_value() || pending->empty()) {
            break;
        }
        const auto requested = std::min(options.write_quantum, pending->size());
        std::size_t progress = 0U;
        try {
            progress = channel.write_some(
                pending->first(requested), deadline, counters, "handshake write");
        } catch (const AppError& error) {
            if (error.code() == "IO_TIMEOUT") {
                report_unavailable(exchange, HandshakeEvent::timeout);
            } else {
                report_unavailable(exchange, HandshakeEvent::early_eof);
            }
            throw;
        }
        if (progress == 0U || progress > requested) {
            report_unavailable(exchange, HandshakeEvent::early_eof);
            app_fail("HANDSHAKE_WRITE_CLOSED", "channel write made invalid progress");
        }
        if (progress < requested) {
            ++counters.short_writes;
        }
        counters.write_bytes += progress;
        Coordinates coordinates(exchange);
        static_cast<void>(exchange.observe_write(
            coordinates.exchange,
            coordinates.transport,
            coordinates.process,
            ReportKind::write,
            coordinates.report,
            coordinates.ordinal,
            coordinates.request_offset,
            coordinates.response_offset,
            pending->first(progress)));
        if (!awaiting(exchange)) {
            app_fail("HANDSHAKE_REJECTED",
                exchange.observation().classification.value_or("UNKNOWN"));
        }
    }

    std::vector<std::uint8_t> buffer(options.read_quantum);
    std::size_t response_bytes = 0U;
    while (!accepted(exchange)) {
        if (!awaiting(exchange)) {
            app_fail("HANDSHAKE_REJECTED",
                exchange.observation().classification.value_or("UNKNOWN"));
        }
        std::size_t progress = 0U;
        try {
            progress = channel.read_some(
                buffer, deadline, counters, "handshake response");
        } catch (const AppError& error) {
            if (error.code() == "IO_TIMEOUT") {
                report_unavailable(exchange, HandshakeEvent::timeout);
            } else {
                report_unavailable(exchange, HandshakeEvent::early_eof);
            }
            throw;
        }
        if (progress > 0U) {
            if (progress < buffer.size()) {
                ++counters.short_reads;
            }
            if (progress > options.maximum_received_bytes - response_bytes) {
                app_fail("RESPONSE_LIMIT_EXCEEDED", "handshake response limit exceeded");
            }
            response_bytes += progress;
            counters.read_bytes += progress;
            Coordinates coordinates(exchange);
            static_cast<void>(exchange.feed_response(
                coordinates.exchange,
                coordinates.transport,
                coordinates.process,
                ReportKind::response_chunk,
                coordinates.report,
                coordinates.ordinal,
                coordinates.request_offset,
                coordinates.response_offset,
                datacube::OctetView(buffer.data(), progress)));
            continue;
        }
        Coordinates coordinates(exchange);
        static_cast<void>(exchange.finish_response(
            coordinates.exchange,
            coordinates.transport,
            coordinates.process,
            ReportKind::response_finish,
            coordinates.report,
            coordinates.ordinal,
            coordinates.request_offset,
            coordinates.response_offset));
        app_fail("HANDSHAKE_EOF",
            exchange.observation().classification.value_or("PEER_UNAVAILABLE"));
    }
    return ClientHandshakeResult{
        .observation = exchange.observation(),
        .counters = counters,
    };
}

ServerHandshakeResult perform_server_handshake(
    const int fd,
    const std::string_view local_node,
    FramedReader& reader,
    const Deadline deadline,
    const IoOptions& options) {
    PlainChannel channel(fd);
    return perform_server_handshake(
        channel, local_node, reader, deadline, options);
}

ServerHandshakeResult perform_server_handshake(
    ByteChannel& channel,
    const std::string_view local_node,
    FramedReader& reader,
    const Deadline deadline,
    const IoOptions& options) {
    require_node_id(local_node, "local node");
    IoCounters counters;
    const auto payload = reader.read_frame(channel, deadline, counters);
    const auto decoded = datacube::natrav_peer_decode_message(payload);
    if (decoded.status != datacube::NATravPeerMessageDecodeStatus::accepted ||
        !decoded.message.has_value()) {
        app_fail("HANDSHAKE_DECODE_REJECTED", decoded.classification);
    }
    const auto& hello = *decoded.message;
    if (hello.kind != datacube::NATravPeerHandshakeMessageKind::hello) {
        send_handshake_error(
            channel, hello.protocol, hello.request_id,
            "MESSAGE_KIND_REJECTED", "expected HELLO",
            deadline, options, counters);
        app_fail("HANDSHAKE_KIND_REJECTED", "expected HELLO");
    }
    if (hello.protocol.id != "NATRAV_OVERLAY_PEER" ||
        hello.protocol.major != 1 || hello.protocol.minor != 0) {
        send_handshake_error(
            channel, hello.protocol, hello.request_id,
            "PROTOCOL_MISMATCH", "unsupported protocol version",
            deadline, options, counters);
        app_fail("HANDSHAKE_PROTOCOL_MISMATCH", "unsupported protocol version");
    }
    const auto available = node_capabilities();
    for (const auto& required : hello.required_capabilities) {
        if (!std::binary_search(available.begin(), available.end(), required)) {
            send_handshake_error(
                channel, hello.protocol, hello.request_id,
                "CAPABILITY_MISMATCH", "required capability is unavailable",
                deadline, options, counters);
            app_fail("HANDSHAKE_CAPABILITY_MISMATCH", required);
        }
    }
    datacube::NATravPeerHandshakeMessage response;
    response.kind = datacube::NATravPeerHandshakeMessageKind::hello_ack;
    response.protocol = hello.protocol;
    response.request_id = hello.request_id;
    response.artifact = node_artifact_identity(local_node);
    response.available_capabilities = available;
    const auto frame = encode_handshake_message(response);
    write_bytes(channel, frame, deadline, options, counters);
    return ServerHandshakeResult{
        .remote_artifact_digest = datacube::parse_hex_digest32(
            hello.artifact.sha256, "HELLO artifact sha256"),
        .request_id = hello.request_id,
        .counters = counters,
    };
}

}  // namespace natrav_overlay
