#pragma once

#include "datacube/core.hpp"
#include "datacube/natrav_peer_handshake.hpp"

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

class AppError final : public std::runtime_error {
public:
    AppError(std::string code, std::string detail);
    [[nodiscard]] const std::string& code() const noexcept;
private:
    std::string code_;
};

class AuthenticatedPeerError final : public std::runtime_error {
public:
    AuthenticatedPeerError(
        std::string code,
        std::string detail,
        bool terminal);
    [[nodiscard]] const std::string& code() const noexcept;
    [[nodiscard]] const std::string& detail() const noexcept;
    [[nodiscard]] bool terminal() const noexcept;
private:
    std::string code_;
    std::string detail_;
    bool terminal_{false};
};

[[noreturn]] void app_fail(std::string_view code, std::string_view detail);

[[nodiscard]] bool valid_node_id(std::string_view value) noexcept;
[[nodiscard]] bool valid_scope(std::string_view value) noexcept;
[[nodiscard]] bool valid_generation_id(std::string_view value) noexcept;
[[nodiscard]] bool valid_error_code(std::string_view value) noexcept;
[[nodiscard]] bool authenticated_peer_error_is_terminal(
    std::string_view code) noexcept;
void require_node_id(std::string_view value, std::string_view field);
void require_scope(std::string_view value);
void require_generation_id(std::string_view value, std::string_view field);

[[nodiscard]] datacube::Digest32 parse_operation_id(std::string_view value);
[[nodiscard]] std::string operation_id_text(const datacube::Digest32& value);
[[nodiscard]] bool digest_is_zero(const datacube::Digest32& value) noexcept;
[[nodiscard]] datacube::Digest32 node_artifact_digest(std::string_view node_id);
[[nodiscard]] datacube::NATravPeerArtifactIdentity node_artifact_identity(
    std::string_view node_id);
[[nodiscard]] std::vector<std::string> node_capabilities();

[[nodiscard]] std::string json_string(std::string_view value);
[[nodiscard]] std::string hex_bytes(datacube::OctetView value);
[[nodiscard]] datacube::Octets read_payload_file(
    const std::filesystem::path& path,
    std::size_t ceiling);

[[nodiscard]] std::uint64_t parse_u64(
    std::string_view value,
    std::string_view field,
    std::uint64_t minimum,
    std::uint64_t maximum);

[[nodiscard]] std::chrono::milliseconds parse_milliseconds(
    std::string_view value,
    std::string_view field,
    std::uint64_t minimum,
    std::uint64_t maximum);

}  // namespace natrav_overlay
