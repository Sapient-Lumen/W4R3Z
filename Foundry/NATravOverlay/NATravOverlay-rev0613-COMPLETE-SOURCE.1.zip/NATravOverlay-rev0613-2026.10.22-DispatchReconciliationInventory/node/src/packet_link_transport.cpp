#include "packet_link_transport.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <mutex>
#include <span>
#include <string>
#include <string_view>
#include <utility>

namespace natrav_overlay {

int packet_link_ordered_stream_revision_abi() noexcept { return 1; }

namespace {

[[nodiscard]] std::size_t endpoint_index(const PacketLinkEndpoint endpoint) {
    switch (endpoint) {
        case PacketLinkEndpoint::first:
            return 0U;
        case PacketLinkEndpoint::second:
            return 1U;
    }
    app_fail("PACKET_LINK_ENDPOINT_INVALID", "unknown packet-link endpoint");
}

[[nodiscard]] PacketLinkEndpoint opposite_endpoint(
    const PacketLinkEndpoint endpoint) noexcept {
    return endpoint == PacketLinkEndpoint::first ?
        PacketLinkEndpoint::second : PacketLinkEndpoint::first;
}

[[nodiscard]] std::size_t maximum_write_bytes(
    const natrav::packet_link::Limits& limits) noexcept {
    const auto payload = limits.max_payload_bytes();
    if (payload == 0U || limits.max_inflight_frames == 0U) {
        return 0U;
    }
    const auto bounded_frames = std::min(
        limits.max_inflight_frames,
        std::numeric_limits<std::size_t>::max() / payload);
    return std::min(limits.max_message_bytes, payload * bounded_frames);
}

}  // namespace

struct PacketLinkControl::State final {
    explicit State(PacketLinkStreamOptions options)
        : limits(options.limits),
          progress_interval(options.progress_interval),
          canonical_schedule(options.schedule.encode()),
          network(
              std::move(options.schedule),
              options.queue_capacity_packets,
              options.trace_capacity_events),
          first_stream(network.endpoint_a(), options.stream_id, options.epoch, limits),
          second_stream(network.endpoint_b(), options.stream_id, options.epoch, limits),
          maximum_write_chunk(maximum_write_bytes(limits)) {
        if (progress_interval < std::chrono::milliseconds(1) ||
            progress_interval > std::chrono::milliseconds(100) ||
            maximum_write_chunk == 0U) {
            throw std::invalid_argument("invalid packet-link stream adapter options");
        }
    }

    mutable std::mutex mutex;
    std::condition_variable condition;
    natrav::packet_link::Limits limits;
    std::chrono::milliseconds progress_interval;
    natrav::packet_link::Bytes canonical_schedule;
    natrav::packet_link::DeterministicPacketNetwork network;
    natrav::packet_link::FinitePacketStream first_stream;
    natrav::packet_link::FinitePacketStream second_stream;
    std::size_t maximum_write_chunk{0U};
    std::uint64_t logical_tick{0U};
    std::array<bool, 2U> alive{true, true};
    std::array<bool, 2U> write_shutdown{false, false};
    bool reset{false};
    std::string fixture_failure{};
};

namespace {

[[nodiscard]] natrav::packet_link::FinitePacketStream& endpoint_stream(
    PacketLinkControl::State& state,
    const PacketLinkEndpoint endpoint) noexcept {
    return endpoint == PacketLinkEndpoint::first ?
        state.first_stream : state.second_stream;
}

[[nodiscard]] const natrav::packet_link::FinitePacketStream& endpoint_stream(
    const PacketLinkControl::State& state,
    const PacketLinkEndpoint endpoint) noexcept {
    return endpoint == PacketLinkEndpoint::first ?
        state.first_stream : state.second_stream;
}

void mark_fixture_failure(
    PacketLinkControl::State& state,
    const std::string_view detail) noexcept {
    if (state.fixture_failure.empty()) {
        try {
            state.fixture_failure.assign(detail);
        } catch (...) {
            state.fixture_failure = "packet-link fixture failed";
        }
    }
    state.reset = true;
    state.condition.notify_all();
}

void advance_locked(PacketLinkControl::State& state) noexcept {
    if (state.reset) {
        return;
    }
    if (state.logical_tick == std::numeric_limits<std::uint64_t>::max()) {
        mark_fixture_failure(state, "packet-link logical clock exhausted");
        return;
    }
    ++state.logical_tick;
    try {
        state.network.advance_to(state.logical_tick);
        state.first_stream.pump(state.logical_tick);
        state.second_stream.pump(state.logical_tick);
        if (state.first_stream.failed()) {
            mark_fixture_failure(state, state.first_stream.failure_reason());
        } else if (state.second_stream.failed()) {
            mark_fixture_failure(state, state.second_stream.failure_reason());
        }
    } catch (const std::exception& error) {
        mark_fixture_failure(state, error.what());
        return;
    } catch (...) {
        mark_fixture_failure(state, "unknown packet-link fixture failure");
        return;
    }
    state.condition.notify_all();
}

[[noreturn]] void fail_read_state(
    const PacketLinkControl::State& state,
    const PacketLinkEndpoint endpoint,
    const std::string_view operation) {
    const auto& stream = endpoint_stream(state, endpoint);
    if (!state.fixture_failure.empty()) {
        app_fail("PEER_RESET", state.fixture_failure);
    }
    if (stream.failed()) {
        app_fail("PEER_RESET", stream.failure_reason());
    }
    app_fail("PEER_RESET", std::string(operation));
}

[[noreturn]] void fail_write_state(
    const PacketLinkControl::State& state,
    const PacketLinkEndpoint endpoint,
    const std::string_view operation) {
    const auto& stream = endpoint_stream(state, endpoint);
    if (!state.fixture_failure.empty()) {
        app_fail("SOCKET_WRITE_CLOSED", state.fixture_failure);
    }
    if (stream.failed()) {
        app_fail("SOCKET_WRITE_CLOSED", stream.failure_reason());
    }
    app_fail("SOCKET_WRITE_CLOSED", std::string(operation));
}

void wait_for_progress(
    PacketLinkControl::State& state,
    std::unique_lock<std::mutex>& lock,
    const Deadline deadline,
    IoCounters& counters,
    const std::string_view operation) {
    const auto now = std::chrono::steady_clock::now();
    if (now >= deadline) {
        lock.unlock();
        app_fail("IO_TIMEOUT", std::string(operation));
    }
    const auto wake = std::min(deadline, now + state.progress_interval);
    ++counters.poll_calls;
    if (state.condition.wait_until(lock, wake) == std::cv_status::timeout) {
        ++counters.would_block;
    }
    if (std::chrono::steady_clock::now() >= deadline) {
        lock.unlock();
        app_fail("IO_TIMEOUT", std::string(operation));
    }
}

class PacketLinkOrderedByteStream final : public OrderedByteStream {
public:
    PacketLinkOrderedByteStream(
        std::shared_ptr<PacketLinkControl::State> state,
        const PacketLinkEndpoint endpoint) noexcept
        : state_(std::move(state)), endpoint_(endpoint) {}

    ~PacketLinkOrderedByteStream() override {
        if (!state_) {
            return;
        }
        std::lock_guard<std::mutex> lock(state_->mutex);
        state_->alive[endpoint_index(endpoint_)] = false;
        state_->condition.notify_all();
    }

    [[nodiscard]] TransportKind transport_kind() const noexcept override {
        return TransportKind::packet_link;
    }

    [[nodiscard]] std::size_t read_some(
        const std::span<std::uint8_t> buffer,
        const Deadline deadline,
        IoCounters& counters,
        const std::string_view operation) override {
        if (!state_ || buffer.empty()) {
            app_fail("SOCKET_INVALID", std::string(operation));
        }
        std::unique_lock<std::mutex> lock(state_->mutex);
        const auto own = endpoint_index(endpoint_);
        const auto peer = endpoint_index(opposite_endpoint(endpoint_));
        if (!state_->alive[own]) {
            app_fail("SOCKET_INVALID", std::string(operation));
        }
        while (true) {
            advance_locked(*state_);
            auto& stream = endpoint_stream(*state_, endpoint_);
            if (state_->reset || stream.failed()) {
                fail_read_state(*state_, endpoint_, operation);
            }
            const auto progress = stream.read_some(buffer);
            if (progress != 0U) {
                ++counters.read_calls;
                state_->condition.notify_all();
                return progress;
            }
            if (stream.read_eof()) {
                ++counters.read_calls;
                return 0U;
            }
            if (!state_->alive[peer]) {
                fail_read_state(*state_, endpoint_, operation);
            }
            wait_for_progress(*state_, lock, deadline, counters, operation);
        }
    }

    [[nodiscard]] std::size_t write_some(
        const datacube::OctetView bytes,
        const Deadline deadline,
        IoCounters& counters,
        const std::string_view operation) override {
        if (!state_ || bytes.empty()) {
            app_fail("SOCKET_INVALID", std::string(operation));
        }
        std::unique_lock<std::mutex> lock(state_->mutex);
        const auto own = endpoint_index(endpoint_);
        const auto peer = endpoint_index(opposite_endpoint(endpoint_));
        if (!state_->alive[own]) {
            app_fail("SOCKET_INVALID", std::string(operation));
        }
        if (state_->write_shutdown[own]) {
            app_fail("SOCKET_WRITE_CLOSED", std::string(operation));
        }
        const auto amount = std::min(bytes.size(), state_->maximum_write_chunk);
        while (true) {
            advance_locked(*state_);
            auto& stream = endpoint_stream(*state_, endpoint_);
            if (state_->reset || stream.failed()) {
                fail_write_state(*state_, endpoint_, operation);
            }
            if (!state_->alive[peer]) {
                fail_write_state(*state_, endpoint_, operation);
            }
            if (stream.queue_message(bytes.first(amount), state_->logical_tick)) {
                ++counters.write_calls;
                advance_locked(*state_);
                state_->condition.notify_all();
                return amount;
            }
            wait_for_progress(*state_, lock, deadline, counters, operation);
        }
    }

    void shutdown_write() override {
        if (!state_) {
            return;
        }
        std::unique_lock<std::mutex> lock(state_->mutex);
        const auto own = endpoint_index(endpoint_);
        const auto peer = endpoint_index(opposite_endpoint(endpoint_));
        if (!state_->alive[own] || state_->write_shutdown[own]) {
            return;
        }
        const auto max_steps = std::min<std::uint64_t>(
            1'000'000U,
            state_->limits.message_expiry_ticks +
                static_cast<std::uint64_t>(state_->limits.retry_limit) *
                    static_cast<std::uint64_t>(state_->limits.retransmit_after_ticks) +
                16U);
        for (std::uint64_t step = 0U; step < max_steps; ++step) {
            advance_locked(*state_);
            auto& stream = endpoint_stream(*state_, endpoint_);
            if (state_->reset || stream.failed() || !state_->alive[peer]) {
                fail_write_state(*state_, endpoint_, "packet-link shutdown write");
            }
            if (stream.queue_finish(state_->logical_tick)) {
                state_->write_shutdown[own] = true;
                advance_locked(*state_);
                state_->condition.notify_all();
                return;
            }
        }
        lock.unlock();
        app_fail(
            "SOCKET_SHUTDOWN_FAILED",
            "packet-link finish could not enter the bounded transmit window");
    }

private:
    std::shared_ptr<PacketLinkControl::State> state_;
    PacketLinkEndpoint endpoint_{PacketLinkEndpoint::first};
};

}  // namespace

PacketLinkControl::PacketLinkControl(std::shared_ptr<State> state) noexcept
    : state_(std::move(state)) {}

PacketLinkControl::~PacketLinkControl() = default;

PacketLinkSnapshot PacketLinkControl::snapshot() const {
    std::lock_guard<std::mutex> lock(state_->mutex);
    return PacketLinkSnapshot{
        .logical_tick = state_->logical_tick,
        .first_alive = state_->alive[0U],
        .second_alive = state_->alive[1U],
        .reset = state_->reset,
        .queued_packets = state_->network.queued_packets(),
        .first_stats = state_->first_stream.stats(),
        .second_stats = state_->second_stream.stats(),
        .canonical_schedule = state_->canonical_schedule,
        .canonical_trace = state_->network.encode_trace(),
    };
}

void PacketLinkControl::reset_link() {
    std::lock_guard<std::mutex> lock(state_->mutex);
    state_->reset = true;
    state_->condition.notify_all();
}

void PacketLinkControl::disconnect_endpoint(const PacketLinkEndpoint endpoint) {
    std::lock_guard<std::mutex> lock(state_->mutex);
    state_->alive[endpoint_index(endpoint)] = false;
    state_->condition.notify_all();
}

PacketLinkStreamPair make_packet_link_stream_pair(PacketLinkStreamOptions options) {
    auto state = std::make_shared<PacketLinkControl::State>(std::move(options));
    auto control = std::shared_ptr<PacketLinkControl>(
        new PacketLinkControl(state));
    return PacketLinkStreamPair{
        .first = std::make_unique<PacketLinkOrderedByteStream>(
            state, PacketLinkEndpoint::first),
        .second = std::make_unique<PacketLinkOrderedByteStream>(
            state, PacketLinkEndpoint::second),
        .control = std::move(control),
    };
}

}  // namespace natrav_overlay
