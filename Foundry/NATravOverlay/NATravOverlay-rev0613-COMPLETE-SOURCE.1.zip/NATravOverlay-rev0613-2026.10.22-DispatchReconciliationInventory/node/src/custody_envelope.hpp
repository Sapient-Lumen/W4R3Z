#pragma once

#include "handoff_capsule.hpp"

#include <array>
#include <cstdint>
#include <openssl/evp.h>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

// Private model only. This does not register a route, listener, relay, or
// durable custody authority.
inline constexpr std::string_view kCustodyEnvelopeFeature =
    "PRIVATE_FINITE_CUSTODY_ENVELOPE_MODEL_V1";
inline constexpr std::size_t kCustodyRoutePartyLimit = 16U;
inline constexpr std::size_t kCustodyEnvelopeLimit = 4'096U;
inline constexpr std::size_t kCustodyRecordLimit = 512U;
inline constexpr std::uint64_t kCustodyEnvelopeLifetimeLimitMs =
    2'592'000'000ULL; // 30 days
using CustodySigningKey = std::array<std::uint8_t, 32U>;

struct CustodyParty final {
    std::string node;
    std::string signing_generation;
    CustodySigningKey signing_public{};

    bool operator==(const CustodyParty&) const = default;
};

struct CustodyEnvelope final {
    std::uint64_t created_ms{0U};
    std::uint64_t expires_ms{0U};
    std::uint8_t hop_limit{0U};
    std::uint32_t capsule_bytes{0U};
    datacube::Digest32 capsule_sha256;
    std::vector<CustodyParty> route;
    datacube::Octets canonical;
};

enum class CustodyRecordKind : std::uint8_t {
    transfer = 1U,
    acceptance = 2U,
};

struct CustodyRecord final {
    CustodyRecordKind kind{CustodyRecordKind::transfer};
    std::uint16_t sequence{0U};
    std::uint8_t hop_index{0U};
    std::uint8_t actor_index{0U};
    std::uint8_t counterparty_index{0U};
    std::uint64_t event_ms{0U};
    datacube::Digest32 envelope_sha256;
    datacube::Digest32 previous_record_sha256;
    datacube::Digest32 capsule_sha256;
    datacube::Octets canonical;
};

struct CustodyProgress final {
    std::uint8_t current_party_index{0U};
    bool awaiting_acceptance{false};
    std::uint16_t next_sequence{1U};
    std::uint64_t last_event_ms{0U};
    datacube::Digest32 last_record_sha256;
    std::vector<datacube::Digest32> accepted_record_sha256;

    [[nodiscard]] bool final_custody_accepted(
        const CustodyEnvelope& envelope) const noexcept;
};

enum class CustodyApplyResult : std::uint8_t {
    applied = 1U,
    duplicate = 2U,
};

[[nodiscard]] datacube::Digest32 custody_party_signing_pin(
    const CustodyParty& party);

[[nodiscard]] CustodyParty make_custody_party(
    std::string_view node,
    std::string_view signing_generation,
    EVP_PKEY* signing_private);

// The caller must bind every party public key to existing authenticated
// configuration before this private model can become durable relay authority.
[[nodiscard]] CustodyEnvelope make_custody_envelope(
    std::span<const CustodyParty> route,
    datacube::OctetView opaque_capsule,
    std::uint64_t created_ms,
    std::uint64_t expires_ms,
    EVP_PKEY* origin_signing_private);
[[nodiscard]] CustodyEnvelope decode_custody_envelope(
    datacube::OctetView bytes);
[[nodiscard]] datacube::Digest32 custody_envelope_sha256(
    const CustodyEnvelope& envelope);
void require_custody_capsule(
    const CustodyEnvelope& envelope,
    datacube::OctetView opaque_capsule);

[[nodiscard]] CustodyProgress initial_custody_progress(
    const CustodyEnvelope& envelope);
[[nodiscard]] CustodyRecord make_custody_transfer(
    const CustodyEnvelope& envelope,
    const CustodyProgress& progress,
    std::uint64_t event_ms,
    EVP_PKEY* current_custodian_private);
[[nodiscard]] CustodyRecord make_custody_acceptance(
    const CustodyEnvelope& envelope,
    const CustodyProgress& progress,
    std::uint64_t event_ms,
    EVP_PKEY* accepting_custodian_private);
[[nodiscard]] CustodyRecord decode_custody_record(
    const CustodyEnvelope& envelope,
    datacube::OctetView bytes);
[[nodiscard]] datacube::Digest32 custody_record_sha256(
    const CustodyRecord& record);
[[nodiscard]] CustodyApplyResult apply_custody_record(
    const CustodyEnvelope& envelope,
    const CustodyRecord& record,
    CustodyProgress& progress);
[[nodiscard]] CustodyProgress reconstruct_custody_progress(
    const CustodyEnvelope& envelope,
    std::span<const datacube::Octets> records);

} // namespace natrav_overlay
