#include "journal.hpp"
#include "config.hpp"
#include <algorithm>

namespace natrav_overlay {
namespace {
using Bytes=datacube::Octets;
using Digest=datacube::Digest32;
void require(bool valid,std::string_view code,std::string_view message) {
    if(!valid)app_fail(code,message);
}
void text(Bytes& out,std::string_view value) {
    datacube::append_be32(out,static_cast<std::uint32_t>(value.size()));
    datacube::append_text(out,value);
}
std::string hex(const Digest& value) {return json_string(datacube::hex_lower(value));}
} // namespace

// Administrative stopping authority is not processing authority. Recover the
// immutable owner/definition from accepted history even after policy removal.
// The supplied event ceiling also makes checkpoint replay historical, not live.
SourceViewRule NodeState::retained_source_view_rule_locked(std::string_view view,
    std::uint64_t configuration_event) const {
    require(configuration_event>0U&&configuration_event<=configuration_events_.size(),
        "JOURNAL_CORRUPT","retirement configuration ceiling required");
    for(auto n=configuration_event;n>0U;--n) {
        const auto& e=configuration_events_[static_cast<std::size_t>(n-1U)];
        if(e.kind=="REJECTED"||e.canonical.find("source_view=")==std::string::npos)continue;
        const auto config=parse_runtime_config(e.canonical,"/view-retirement-history",IdentityFileValidation::deferred);
        const auto found=std::find_if(config.source_views.rules.begin(),config.source_views.rules.end(),
            [&](const auto& rule){return rule.id==view;});
        if(found!=config.source_views.rules.end())return *found;
    }
    app_fail("SOURCE_VIEW_RETIREMENT_DENIED","an accepted historical view is required");
}

// No payload copying: the incremental commitment uses immutable record and
// provenance digests. Only the view's target-domain index is traversed. Unrelated
// inbound arrivals cannot invalidate this account, but a concurrent direct import
// can, even though that import does not change the automation revision.
ViewFinalAccount NodeState::view_final_account_locked(const ImportAutoState& before,
    const SourceViewRule& rule,std::uint64_t inbound_count) const {
    require(inbound_count<=inbound_.size(),"JOURNAL_CORRUPT","final view prefix is absent");
    ViewFinalAccount out;
    Bytes seed;datacube::append_text(seed,"NATRAV_OVERLAY_VIEW_RECORDS_V1");datacube::append_u8(seed,0U);
    datacube::append_octets(seed,rule.digest.octets);
    datacube::Sha256State records;records.update(seed);
    const auto domain=inbound_domain_index_.find({rule.provider,rule.target_scope});
    if(domain!=inbound_domain_index_.end()) {
        const auto count=domain->second.before(static_cast<std::size_t>(inbound_count),true);
        for(std::size_t i=0U;i<count;++i) {
            const auto& item=inbound_[domain->second.at(i,true)];
            require(item.subscribed_source&&item.subscribed_source->view==rule.id&&
                item.subscribed_source->view_digest==rule.digest,"JOURNAL_CORRUPT","reserved view provenance mismatch");
            records.update(item.record.operation_id.octets);records.update(item.record_digest.octets);
            const auto proof=datacube::sha256(encode_subscribed_source(*item.subscribed_source));records.update(proof.octets);
            ++out.records;out.payload_bytes+=item.record.payload.size();
        }
    }
    out.records_digest=records.finalize();
    Bytes b;datacube::append_text(b,"NATRAV_OVERLAY_VIEW_FINAL_ACCOUNT_V1");datacube::append_u8(b,0U);
    text(b,node_id_);datacube::append_octets(b,rule.digest.octets);datacube::append_be32(b,rule.uid);
    datacube::append_octets(b,before.head_digest.octets);datacube::append_octets(b,before.authority_digest.octets);
    for(auto n:{static_cast<std::uint64_t>(before.history.size()),before.generation,before.next_position,
            before.imports,before.decisions,before.manual_retries,out.records,out.payload_bytes})datacube::append_be64(b,n);
    for(auto n:{before.maximum_imports,before.maximum_decisions,before.interval_ms})datacube::append_be32(b,n);
    text(b,before.state);text(b,before.error);
    datacube::append_be32(b,static_cast<std::uint32_t>(before.deferred.size()));
    for(const auto& [ordinal,parent]:before.deferred){datacube::append_be64(b,ordinal);datacube::append_octets(b,parent.octets);}
    datacube::append_octets(b,out.records_digest.octets);out.digest=datacube::sha256(b);return out;
}

void NodeState::require_source_view_active_locked(std::string_view view) const {
    const auto found=import_schedules_.find(std::string(view));
    require(found==import_schedules_.end()||found->second.state!="RETIRED",
        "SOURCE_VIEW_RETIRED","terminal view does not admit imports, retries or new grants");
}

void NodeState::validate_retired_import_prefixes_locked() const {
    // Checkpoint imports are reconstructed before scheduling histories. Check the
    // cross-boundary invariant afterwards as well, so a forged direct admission
    // cannot be placed behind a valid retained terminal event.
    for(const auto& [id,state]:import_schedules_) {
        if(state.state!="RETIRED")continue;
        require(!state.history.empty()&&state.history.back().action=="RETIRE",
            "JOURNAL_CORRUPT","terminal event is missing");
        const auto& e=state.history.back();
        const auto rule=retained_source_view_rule_locked(id,e.configuration_event);
        const auto domain=inbound_domain_index_.find({rule.provider,rule.target_scope});
        if(domain!=inbound_domain_index_.end())require(
            domain->second.before(static_cast<std::size_t>(e.inbound_count),true)==domain->second.size(true),
            "JOURNAL_CORRUPT","materialized admission follows view retirement");
    }
}

std::string NodeState::view_retirement_command_locked(const ImportAutoRequest& request,
    const RuntimeConfig& config,std::uint32_t uid,std::uint32_t gid,std::uint32_t pid,
    std::uint64_t event,std::uint64_t ms) {
    const auto rule=retained_source_view_rule_locked(request.view,event);
    require(config.format_version>=17U&&uid==rule.uid&&
        local_control_allows(config.local_control,uid,LocalControlClass::source_import),
        "SOURCE_VIEW_RETIREMENT_DENIED","exact historical owner and current administrative class required");
    auto found=import_schedules_.find(request.view);
    ImportAutoState empty;
    const auto& before=found==import_schedules_.end()?empty:found->second;
    std::string disposition="STATUS";
    if(request.command==ImportAutoCommand::retire) {
        if(before.state=="RETIRED") {
            const auto& e=before.history.back();
            require(e.revision==request.revision&&e.uid==uid&&e.reason==request.reason&&
                e.deferred_disposition==request.deferred_disposition&&e.view_digest==request.view_digest&&
                e.configuration_digest==request.configuration_digest&&e.final_state_digest==request.final_state_digest,
                "SOURCE_VIEW_RETIREMENT_CONFLICT","only the exact accepted terminal decision may be repeated");
            disposition="ALREADY_RETIRED";
        } else {
            require(request.revision==before.history.size()&&request.view_digest==rule.digest&&
                request.configuration_digest==configuration_events_[static_cast<std::size_t>(event-1U)].digest,
                "SOURCE_VIEW_RETIREMENT_CONFLICT","select exact view, revision and current accepted configuration");
            ImportAutoEvent e;e.view=request.view;e.action="RETIRE";e.revision=request.revision;
            e.previous_digest=before.head_digest;e.configuration_event=event;e.unix_ms=ms;e.inbound_count=inbound_.size();
            e.uid=uid;e.gid=gid;e.pid=pid;e.reason=request.reason;e.view_digest=request.view_digest;
            e.configuration_digest=request.configuration_digest;e.final_state_digest=request.final_state_digest;
            e.deferred_disposition=request.deferred_disposition;
            commit_import_auto_event(e);disposition="RETIRED";
        }
    }
    // Journal application can replace mapped state. Never retain a reference
    // across commit while constructing the response.
    found=import_schedules_.find(request.view);
    const auto& current=found==import_schedules_.end()?empty:found->second;
    const bool terminal=current.state=="RETIRED";
    ViewFinalAccount account;
    if(terminal) {
        account.digest=current.history.back().final_state_digest;
        account.records=current.retired_records;account.payload_bytes=current.retired_payload_bytes;
        account.records_digest=current.retired_records_digest;
    } else account=view_final_account_locked(current,rule,inbound_.size());
    std::string out="{\"format\":\"NATRAV_OVERLAY_VIEW_RETIREMENT_V1\",\"status\":"+json_string(disposition)+
        ",\"lifecycle\":"+json_string(terminal?"RETIRED":"ACTIVE")+",\"view\":"+json_string(rule.id)+
        ",\"owner_uid\":"+std::to_string(rule.uid)+",\"view_digest\":"+hex(rule.digest)+
        ",\"configuration_digest\":"+hex(configuration_events_[static_cast<std::size_t>(event-1U)].digest)+
        ",\"revision\":"+std::to_string(current.history.size())+",\"history_digest\":"+hex(current.head_digest)+
        ",\"final_state_digest\":"+hex(account.digest)+",\"retained_records\":"+std::to_string(account.records)+
        ",\"retained_payload_bytes\":"+std::to_string(account.payload_bytes)+",\"records_digest\":"+hex(account.records_digest)+
        ",\"deferred_count\":"+std::to_string(current.deferred.size())+
        ",\"schedule_state\":"+json_string(current.state)+",\"retirement\":";
    if(!terminal)return out+"null}";
    const auto& e=current.history.back();
    out+="{\"selected_revision\":"+std::to_string(e.revision)+",\"final_state_digest\":"+hex(e.final_state_digest)+
        ",\"configuration_digest\":"+hex(e.configuration_digest)+",\"configuration_event\":"+std::to_string(e.configuration_event)+
        ",\"unix_ms\":"+std::to_string(e.unix_ms)+",\"actor_uid\":"+std::to_string(e.uid)+
        ",\"actor_gid\":"+std::to_string(e.gid)+",\"actor_pid\":"+std::to_string(e.pid)+
        ",\"reason\":"+json_string(e.reason)+",\"previous_schedule_state\":"+json_string(current.retired_from_state)+
        ",\"deferred_disposition\":"+json_string(e.deferred_disposition)+
        ",\"remaining_work\":\"RETAINED_UNPROCESSED\"}}";
    return out;
}
} // namespace natrav_overlay
