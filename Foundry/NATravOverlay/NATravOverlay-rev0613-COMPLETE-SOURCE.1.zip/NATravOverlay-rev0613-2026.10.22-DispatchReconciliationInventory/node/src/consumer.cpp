#include "consumer.hpp"
#include "journal.hpp"
#include "config.hpp"

#include <algorithm>
#include <bit>
#include <chrono>
#include <cstdlib>
#include <cstdio>
#include <limits>
#include <thread>
#include <openssl/crypto.h>
#include <openssl/rand.h>

namespace natrav_overlay {
namespace {
void text(datacube::Octets& out, std::string_view value) {
    if (value.size()>65535U) { app_fail("CONSUMER_INVALID", "text exceeds encoding bound"); }
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size())); datacube::append_text(out,value);
}
std::string text(datacube::Reader& r, const std::size_t maximum) {
    const auto n=r.read_be16("consumer text size");
    if (n>maximum) { app_fail("CONSUMER_INVALID", "text exceeds bound"); }
    return datacube::octets_text(r.read_exact(n,"consumer text"),"consumer text",true);
}
void digest(datacube::Octets& out,const datacube::Digest32& d) { datacube::append_octets(out,d.octets); }
datacube::Digest32 digest(datacube::Reader& r) {
    datacube::Digest32 d{};const auto b=r.read_exact(32U,"consumer digest");
    std::copy(b.begin(),b.end(),d.octets.begin());return d;
}
bool flag(datacube::Reader& r) {
    const auto b=r.read_u8("consumer flag");
    if(b>1U){app_fail("CONSUMER_INVALID","noncanonical boolean");}return b!=0U;
}
void optional_digest(datacube::Octets& out,const std::optional<datacube::Digest32>& d) {
    datacube::append_u8(out,d?1U:0U);if(d){digest(out,*d);}
}
std::optional<datacube::Digest32> optional_digest(datacube::Reader& r) {
    if(flag(r)){return digest(r);}return std::nullopt;
}
void blob(datacube::Octets& out,datacube::OctetView b) {
    if(b.size()>60000U){app_fail("CONSUMER_INVALID","encoded consumer exceeds bound");}
    datacube::append_be32(out,static_cast<std::uint32_t>(b.size()));datacube::append_octets(out,b);
}
datacube::OctetView blob(datacube::Reader& r) {
    const auto n=r.read_be32("consumer blob size");
    if(n>60000U){app_fail("CONSUMER_INVALID","consumer blob exceeds bound");}
    return r.read_exact(n,"consumer blob");
}
bool nonzero(const datacube::Digest32& d){return std::any_of(d.octets.begin(),d.octets.end(),[](auto b){return b!=0U;});}
bool valid_name(std::string_view n) {
    return !n.empty()&&n.size()<=64U&&n!="."&&n!=".."&&std::all_of(n.begin(),n.end(),[](char c){
        return (c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-'||c=='.';});
}
bool reason_ok(std::string_view n) {
    return !n.empty()&&n.size()<=256U&&std::all_of(n.begin(),n.end(),[](char c){return c>=32&&c<=126;});
}
std::uint64_t now_ms(){return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
    std::chrono::system_clock::now().time_since_epoch()).count());}
datacube::Digest32 random_id(){
    datacube::Digest32 d{};
    if(RAND_priv_bytes(d.octets.data(),static_cast<int>(d.octets.size()))!=1||!nonzero(d)){
        app_fail("CONSUMER_RANDOM_FAILED","cannot generate consumer identity");
    }return d;
}
datacube::Digest32 rows_hash(const std::string& rows){
    datacube::Octets b;datacube::append_text(b,"NATRAV_OVERLAY_CONSUMER_PAGE_V1");datacube::append_u8(b,0U);datacube::append_text(b,rows);
    return datacube::sha256(b);
}
void batch(datacube::Octets& out,const std::optional<ConsumerBatch>& b){
    datacube::append_u8(out,b?1U:0U);if(!b){return;}
    digest(out,b->id);datacube::append_be64(out,b->from);datacube::append_be64(out,b->through);digest(out,b->rows_digest);
    datacube::append_be64(out,b->configuration_event);datacube::append_be64(out,b->unix_ms);datacube::append_be32(out,b->pid);
}
std::optional<ConsumerBatch> batch(datacube::Reader& r){
    if(!flag(r)){return std::nullopt;}
    ConsumerBatch b;b.id=digest(r);b.from=r.read_be64("batch from");b.through=r.read_be64("batch through");
    b.rows_digest=digest(r);b.configuration_event=r.read_be64("batch configuration");b.unix_ms=r.read_be64("batch time");b.pid=r.read_be32("batch PID");return b;
}
std::string batch_json(const std::optional<ConsumerBatch>& b){
    if(!b){return "null";}
    return "{\"id\":"+json_string(datacube::hex_lower(b->id))+",\"from\":"+std::to_string(b->from)+
        ",\"through\":"+std::to_string(b->through)+",\"rows_digest\":"+json_string(datacube::hex_lower(b->rows_digest))+
        ",\"configuration_event\":"+std::to_string(b->configuration_event)+",\"unix_ms\":"+std::to_string(b->unix_ms)+",\"pid\":"+std::to_string(b->pid)+"}";
}
void validate_consumer_selection(const EvidenceFeed& selection) {
    validate_evidence_feed(selection);
    // Registration is immutable: reserve enough room for the largest allowed
    // metadata row + consumer accounts + principal annotation + payload prefix.
    // Never create a consumer that can later get stuck on one unsendable row.
    if (selection.maximum_response_bytes < 8192U + 2U * selection.payload_length) {
        app_fail("CONSUMER_PAGE_BUDGET_INVALID", "max-bytes must cover 8192 plus twice payload-length");
    }
}
void require_access(const EvidenceFeed& feed,const EvidenceReadAccess& access){
    if(!access.scoped||!access.metadata_allowed||(feed.include_payload&&!access.payload_allowed)){
        app_fail("LOCAL_CONTROL_CLASS_DENIED","current scoped evidence read authority is required");
    }
    if(std::none_of(access.grants.begin(),access.grants.end(),[&](const auto& g){
        return (!feed.include_payload||g.payload)&&(feed.issuer.empty()||feed.issuer==g.issuer)&&(feed.scope.empty()||feed.scope==g.scope);
    })){app_fail("CONSUMER_DOMAIN_DENIED","no authorized domain matches the registered selection");}
}
void pause_test(const char* name){
    if(const auto* value=std::getenv(name); value&&*value){
        if (std::string_view(name).find("TEST_PROJECTION_") != std::string_view::npos) {
            std::fprintf(stderr,"PROJECTION_TEST_BOUNDARY %s\n",name);std::fflush(stderr);
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(parse_u64(value,name,1U,60000U)));
    }
}
} // namespace

std::string consumer_key(const std::uint32_t uid,const std::string_view name){return std::to_string(uid)+":"+std::string(name);}

datacube::Digest32 projection_result_digest(const DurableConsumer& value) {
    if (!value.projection) {
        app_fail("PROJECTION_NOT_FOUND", "consumer has no projection result");
    }
    datacube::Octets material;
    datacube::append_text(material, "NATRAV_OVERLAY_PROJECTION_RESULT_V1");
    datacube::append_u8(material, 0U);
    digest(material, value.instance);
    datacube::append_be64(material, static_cast<std::uint64_t>(value.adoptions.size()));
    datacube::append_be64(material, value.position);
    datacube::append_be64(material, value.acknowledgments);
    const auto encoded = encode_projection(*value.projection);
    datacube::append_be32(material, static_cast<std::uint32_t>(encoded.size()));
    datacube::append_octets(material, encoded);
    return datacube::sha256(material);
}

namespace {
void publication_totals(datacube::Octets& out, const ProjectionTotals& totals,
    const bool numeric) {
    datacube::append_be64(out, totals.admissions);
    datacube::append_be64(out, totals.originals);
    datacube::append_be64(out, totals.corrections);
    datacube::append_be64(out, totals.historical_payload_bytes);
    datacube::append_be64(out, totals.current_payload_bytes);
    digest(out, totals.source_digest);
    if (numeric) {
        datacube::append_be64(out, totals.numeric.accepted);
        datacube::append_be64(out, totals.numeric.rejected);
        datacube::append_be64(out, totals.numeric.valid_heads);
        datacube::append_be64(out, totals.numeric.invalid_heads);
        datacube::append_be64(out,
            std::bit_cast<std::uint64_t>(totals.numeric.sum_ticks));
        for (const auto count : totals.numeric.errors) {
            datacube::append_be64(out, count);
        }
    }
}
} // namespace

datacube::Digest32 projection_publication_authority(
    const DurableConsumer& value, const std::string_view recipient,
    const std::string_view recipient_generation,
    const datacube::Digest32& recipient_spki_sha256,
    const std::string_view scope, const EvidenceQueryContext& context) {
    datacube::Octets material;
    datacube::append_text(material,
        "NATRAV_OVERLAY_PROJECTION_PUBLICATION_AUTHORITY_V1");
    datacube::append_u8(material, 0U);
    datacube::append_be32(material, value.uid);
    digest(material, context.read_access.digest);
    text(material, recipient);
    text(material, recipient_generation);
    digest(material, recipient_spki_sha256);
    text(material, scope);
    return datacube::sha256(material);
}

datacube::Octets projection_publication_payload(
    const DurableConsumer& value, const std::string_view recipient,
    const std::string_view recipient_generation,
    const datacube::Digest32& recipient_spki_sha256,
    const std::string_view scope, const EvidenceQueryContext& context) {
    if (!value.projection || recipient_generation.empty() ||
        digest_is_zero(recipient_spki_sha256)) {
        app_fail("PROJECTION_PUBLICATION_POLICY_INVALID",
            "publication requires one exact recipient key generation");
    }
    const auto& projection = *value.projection;
    datacube::Octets out;
    datacube::append_text(out, "NPP1");
    datacube::append_u8(out, projection.numeric ? 2U : 1U);
    datacube::append_u8(out, value.retirement ? 2U : 1U);
    datacube::append_be16(out, 0U);
    datacube::append_be32(out, value.uid);
    digest(out, value.instance);
    datacube::append_be64(out, value.revision);
    datacube::append_be64(out, static_cast<std::uint64_t>(value.adoptions.size()));
    datacube::append_be64(out, value.position);
    datacube::append_be64(out, value.acknowledgments);
    digest(out, projection.definition_digest);
    digest(out, projection_result_digest(value));
    digest(out, projection.totals.source_digest);
    digest(out, context.read_access.digest);
    digest(out, projection_publication_authority(
        value, recipient, recipient_generation, recipient_spki_sha256, scope, context));
    text(out, value.name);
    text(out, value.selection.issuer);
    text(out, value.selection.scope);
    text(out, recipient);
    text(out, recipient_generation);
    digest(out, recipient_spki_sha256);
    text(out, scope);
    datacube::append_be64(out, projection.maximum_admissions);
    publication_totals(out, projection.totals, projection.numeric.has_value());
    if (projection.numeric) {
        const auto encoded = encode_numeric_definition(*projection.numeric);
        datacube::append_be32(out, static_cast<std::uint32_t>(encoded.size()));
        datacube::append_octets(out, encoded);
    }
    if (value.retirement) {
        datacube::append_be64(out, value.retirement->revision);
        datacube::append_be64(out, value.retirement->unix_ms);
        digest(out, value.retirement->final_consumer_digest);
        digest(out, value.retirement->final_schedule_digest);
    }
    if (out.size() > kMaximumEvidencePayloadBytes) {
        app_fail("PROJECTION_PUBLICATION_SIZE_LIMIT",
            "canonical projection result exceeds the evidence payload bound");
    }
    return out;
}

datacube::Digest32 projection_publication_operation(
    const datacube::OctetView payload) {
    datacube::Octets material;
    datacube::append_text(material,
        "NATRAV_OVERLAY_PROJECTION_PUBLICATION_OPERATION_V1");
    datacube::append_u8(material, 0U);
    datacube::append_octets(material, payload);
    return datacube::sha256(material);
}
void validate_consumer_request(const ConsumerRequest& r){
    if(!valid_name(r.name)){app_fail("CONSUMER_NAME_INVALID","consumer name requires 1..64 ASCII name characters");}
    if(r.command<ConsumerCommand::create||r.command>ConsumerCommand::projection_publish){app_fail("CONSUMER_INVALID","unknown command");}
    if(retirement_command(r.command)) {
        if(r.command==ConsumerCommand::retire && (!r.expected_instance || !nonzero(*r.expected_instance) ||
            r.expected_revision==0U || !reason_ok(r.reason))) {
            app_fail("CONSUMER_RETIREMENT_SELECTION_REQUIRED","retirement requires exact instance, revision and printable reason");
        }
    }
    if(publication_command(r.command)) {
        if(!r.expected_instance || !nonzero(*r.expected_instance) || !r.expected_result_digest ||
            !nonzero(*r.expected_result_digest) || r.expected_revision==0U ||
            r.publication_recipient.empty() || r.publication_scope.empty()) {
            app_fail("PROJECTION_PUBLICATION_SELECTION_REQUIRED",
                "publication requires exact instance, revision, result digest, recipient and scope");
        }
        require_node_id(r.publication_recipient, "publication recipient");
        require_scope(r.publication_scope);
        if(r.publication_scope==kCounterAddActionScope) {
            app_fail("PROJECTION_PUBLICATION_SCOPE_REJECTED",
                "projection results cannot be published as an action request");
        }
    }
    if(schedule_command(r.command)) {
        if(r.command!=ConsumerCommand::projection_schedule_status && !reason_ok(r.reason)) {
            app_fail("PROJECTION_SCHEDULE_REASON_REQUIRED","bounded printable reason required");
        }
        if(r.automatic_maximum_pages==0U || r.automatic_maximum_pages>10000U ||
            r.automatic_minimum_interval_ms<10U || r.automatic_minimum_interval_ms>60000U) {
            app_fail("PROJECTION_SCHEDULE_LIMIT","page budget 1..10000 and interval 10..60000 ms required");
        }
    }
    if(consumer_create(r.command)){validate_consumer_selection(r.selection);if(!r.selection.cursor.empty()){app_fail("CONSUMER_INVALID","registration cannot adopt an ephemeral token");}}
    if((consumer_create(r.command)||consumer_reset(r.command))&&!reason_ok(r.reason)){
        app_fail("CONSUMER_REASON_REQUIRED","creation/reset requires a bounded printable reason");
    }
    if(r.numeric && r.command!=ConsumerCommand::projection_create){app_fail("CONSUMER_INVALID","numeric definition only belongs to projection creation");}
    if(r.numeric){validate_numeric_definition(*r.numeric);}
    if(r.command==ConsumerCommand::projection_create && (r.selection.issuer.empty() || r.selection.scope.empty() ||
        r.selection.include_payload!=r.numeric.has_value() || r.selection.payload_length!=(r.numeric?46U:0U) || r.selection.from_now || r.selection.maximum_response_bytes!=60000U || r.maximum_admissions==0U || r.maximum_admissions>1000000U)) {
        app_fail("PROJECTION_DEFINITION_INVALID", "projection requires one exact domain, correct payload authority mode, beginning, and 1..1000000 admissions");
    }
    if(r.command==ConsumerCommand::projection_rebuild && r.selection.from_now) { app_fail("PROJECTION_REBUILD_INVALID", "rebuild always starts at the beginning"); }
    if((consumer_ack(r.command))!=r.batch_id.has_value()||(r.batch_id&&!nonzero(*r.batch_id))){app_fail("CONSUMER_INVALID","acknowledgment requires an issued batch ID");}
    if(consumer_reset(r.command)&&r.expected_revision==0U){app_fail("CONSUMER_INVALID","reset requires exact expected revision");}
}
datacube::Octets encode_consumer_request(const ConsumerRequest& r){
    validate_consumer_request(r);datacube::Octets out;datacube::append_text(out,publication_command(r.command)?"NCR5":(retirement_command(r.command)?"NCR4":(schedule_command(r.command)?"NCR3":(r.numeric?"NCR2":"NCR1"))));datacube::append_u8(out,static_cast<std::uint8_t>(r.command));text(out,r.name);
    if(publication_command(r.command)) {
        digest(out,*r.expected_instance);datacube::append_be64(out,r.expected_revision);
        datacube::append_be64(out,r.expected_position);digest(out,*r.expected_result_digest);
        text(out,r.publication_recipient);text(out,r.publication_scope);
    }
    else if(retirement_command(r.command)) {
        if(r.command==ConsumerCommand::retire) {digest(out,*r.expected_instance);datacube::append_be64(out,r.expected_revision);
            datacube::append_be64(out,r.expected_schedule_revision);datacube::append_u8(out,r.abandon_pending?1U:0U);text(out,r.reason);}
    }
    else if(schedule_command(r.command)) {
        if(r.command!=ConsumerCommand::projection_schedule_status) {datacube::append_be64(out,r.expected_revision);text(out,r.reason);}
        if(r.command==ConsumerCommand::projection_enable) {datacube::append_be32(out,r.automatic_maximum_pages);datacube::append_be32(out,r.automatic_minimum_interval_ms);}
    }
    else if(consumer_create(r.command)){blob(out,encode_evidence_feed(r.selection));text(out,r.reason);if(r.command==ConsumerCommand::projection_create){datacube::append_be64(out,r.maximum_admissions);if(r.numeric){datacube::append_octets(out,encode_numeric_definition(*r.numeric));}}}
    else if(consumer_ack(r.command)){digest(out,*r.batch_id);}
    else if(consumer_reset(r.command)){datacube::append_u8(out,r.selection.from_now?1U:0U);datacube::append_be64(out,r.expected_revision);text(out,r.reason);}
    return out;
}
ConsumerRequest decode_consumer_request(const datacube::OctetView bytes){
    datacube::Reader r(bytes,"consumer request");const auto magic=datacube::octets_text(r.read_exact(4U,"magic"),"magic",true);if(magic!="NCR1"&&magic!="NCR2"&&magic!="NCR3"&&magic!="NCR4"&&magic!="NCR5"){app_fail("CONSUMER_INVALID","unknown wire version");}
    ConsumerRequest v;v.command=static_cast<ConsumerCommand>(r.read_u8("command"));v.name=text(r,64U);
    if(magic=="NCR2"&&v.command!=ConsumerCommand::projection_create){app_fail("CONSUMER_INVALID","NCR2 is exact numeric projection registration");}
    if((magic=="NCR3")!=schedule_command(v.command)){app_fail("CONSUMER_INVALID","schedule command requires exact NCR3 envelope");}
    if((magic=="NCR4")!=retirement_command(v.command)){app_fail("CONSUMER_INVALID","retirement command requires exact NCR4 envelope");}
    if((magic=="NCR5")!=publication_command(v.command)){app_fail("CONSUMER_INVALID","publication command requires exact NCR5 envelope");}
    if(publication_command(v.command)) {
        v.expected_instance=digest(r);v.expected_revision=r.read_be64("publication revision");
        v.expected_position=r.read_be64("publication position");v.expected_result_digest=digest(r);
        v.publication_recipient=text(r,64U);v.publication_scope=text(r,128U);
    }
    else if(retirement_command(v.command)) {
        if(v.command==ConsumerCommand::retire){v.expected_instance=digest(r);v.expected_revision=r.read_be64("retirement revision");
            v.expected_schedule_revision=r.read_be64("schedule revision");v.abandon_pending=flag(r);v.reason=text(r,256U);}
    }
    else if(schedule_command(v.command)) {
        if(v.command!=ConsumerCommand::projection_schedule_status) {v.expected_revision=r.read_be64("expected grant generation");v.reason=text(r,256U);}
        if(v.command==ConsumerCommand::projection_enable) {v.automatic_maximum_pages=r.read_be32("automatic page budget");v.automatic_minimum_interval_ms=r.read_be32("minimum interval");}
    }
    else if(consumer_create(v.command)){v.selection=decode_evidence_feed(blob(r));v.reason=text(r,256U);if(v.command==ConsumerCommand::projection_create){v.maximum_admissions=r.read_be64("projection budget");if(magic=="NCR2"){v.numeric=decode_numeric_definition(r);}}}
    else if(consumer_ack(v.command)){v.batch_id=digest(r);}
    else if(consumer_reset(v.command)){v.selection.from_now=flag(r);v.expected_revision=r.read_be64("expected revision");v.reason=text(r,256U);}
    r.require_eof("consumer request");validate_consumer_request(v);return v;
}
datacube::Octets encode_consumer(const DurableConsumer& v){
    if(v.retirement) {
        auto frozen=v;frozen.retirement.reset();const auto base=encode_consumer(frozen);
        datacube::Octets out;datacube::append_text(out,"NCS3");blob(out,base);
        const auto& t=*v.retirement;datacube::append_be64(out,t.revision);datacube::append_be64(out,t.configuration_event);
        datacube::append_be64(out,t.unix_ms);datacube::append_be32(out,t.pid);datacube::append_be64(out,t.previous_schedule_revision);
        datacube::append_u8(out,t.abandoned_pending?1U:0U);digest(out,t.final_consumer_digest);digest(out,t.final_schedule_digest);text(out,t.reason);
        if(out.size()>kConsumerEncodedLimit){app_fail("CONSUMER_RETIREMENT_SIZE_LIMIT","retirement encoding exceeds bounded archive");}return out;
    }
    datacube::Octets out;datacube::append_text(out,v.projection?"NCS2":"NCS1");text(out,v.name);datacube::append_be32(out,v.uid);digest(out,v.instance);blob(out,encode_evidence_feed(v.selection));
    datacube::append_be64(out,v.revision);datacube::append_be64(out,v.position);datacube::append_be64(out,v.acknowledgments);batch(out,v.pending);batch(out,v.last_ack);
    datacube::append_be32(out,static_cast<std::uint32_t>(v.adoptions.size()));
    for(const auto& a:v.adoptions){
        datacube::append_be64(out,a.epoch);datacube::append_be64(out,a.from);datacube::append_be64(out,a.to);datacube::append_u8(out,a.from_now?1U:0U);
        datacube::append_be64(out,a.configuration_event);datacube::append_be64(out,a.unix_ms);datacube::append_be32(out,a.pid);digest(out,a.authority);optional_digest(out,a.abandoned_batch);text(out,a.reason);
    }
    text(out,v.transition);datacube::append_be64(out,v.configuration_event);datacube::append_be64(out,v.unix_ms);datacube::append_be32(out,v.pid);if(v.projection){blob(out,encode_projection(*v.projection));}return out;
}
DurableConsumer decode_consumer(const datacube::OctetView bytes){
    datacube::Reader r(bytes,"consumer state");const auto magic=datacube::octets_text(r.read_exact(4U,"magic"),"magic",true);if(magic=="NCS3") {
        const auto base=blob(r);
        if(base.size()<4U || (datacube::octets_text(base.first(4U),"base version",true)!="NCS1" &&
            datacube::octets_text(base.first(4U),"base version",true)!="NCS2")){app_fail("JOURNAL_CORRUPT","retirement wraps exactly one active consumer");}
        auto v=decode_consumer(base);ConsumerRetirement t;t.revision=r.read_be64("retirement revision");t.configuration_event=r.read_be64("retirement configuration");
        t.unix_ms=r.read_be64("retirement time");t.pid=r.read_be32("retirement PID");t.previous_schedule_revision=r.read_be64("previous schedule revision");
        t.abandoned_pending=flag(r);t.final_consumer_digest=digest(r);t.final_schedule_digest=digest(r);t.reason=text(r,256U);
        r.require_eof("consumer retirement");v.retirement=t;return v;
    }
    if(magic!="NCS1"&&magic!="NCS2"){app_fail("CONSUMER_INVALID","unknown durable version");}
    DurableConsumer v;v.name=text(r,64U);v.uid=r.read_be32("UID");v.instance=digest(r);v.selection=decode_evidence_feed(blob(r));
    v.revision=r.read_be64("revision");v.position=r.read_be64("position");v.acknowledgments=r.read_be64("acks");v.pending=batch(r);v.last_ack=batch(r);
    const auto count=r.read_be32("adoption count");if(count==0U||count>kConsumerAdoptionLimit){app_fail("CONSUMER_INVALID","adoption history bound");}
    for(std::uint32_t i=0;i<count;++i){ConsumerAdoption a;a.epoch=r.read_be64("epoch");a.from=r.read_be64("from");a.to=r.read_be64("to");a.from_now=flag(r);
        a.configuration_event=r.read_be64("configuration");a.unix_ms=r.read_be64("time");a.pid=r.read_be32("PID");a.authority=digest(r);a.abandoned_batch=optional_digest(r);a.reason=text(r,256U);v.adoptions.push_back(std::move(a));}
    v.transition=text(r,16U);v.configuration_event=r.read_be64("configuration");v.unix_ms=r.read_be64("time");v.pid=r.read_be32("PID");if(magic=="NCS2"){v.projection=decode_projection(blob(r));}r.require_eof("consumer state");return v;
}
std::string consumer_json(const DurableConsumer& v,const bool history){
    std::string out="{\"name\":"+json_string(v.name)+",\"owner_uid\":"+std::to_string(v.uid)+",\"instance\":"+json_string(datacube::hex_lower(v.instance))+
        ",\"revision\":"+std::to_string(v.revision)+",\"epoch\":"+std::to_string(v.adoptions.size())+",\"acknowledged_sequence\":"+std::to_string(v.position)+
        ",\"acknowledgments\":"+std::to_string(v.acknowledgments)+",\"authority_digest\":"+json_string(datacube::hex_lower(v.adoptions.back().authority))+
        ",\"issuer_filter\":"+(v.selection.issuer.empty()?"null":json_string(v.selection.issuer))+",\"scope_filter\":"+(v.selection.scope.empty()?"null":json_string(v.selection.scope))+
        ",\"payload_included\":"+(v.selection.include_payload?"true":"false")+",\"limit\":"+std::to_string(v.selection.maximum_records)+
        ",\"max_bytes\":"+std::to_string(v.selection.maximum_response_bytes)+",\"payload_length\":"+std::to_string(v.selection.payload_length)+
        ",\"pending_batch\":"+batch_json(v.pending)+",\"last_acknowledged_batch\":"+batch_json(v.last_ack)+
        ",\"last_transition\":"+json_string(v.transition)+",\"configuration_event\":"+std::to_string(v.configuration_event)+",\"unix_ms\":"+std::to_string(v.unix_ms)+",\"pid\":"+std::to_string(v.pid);
    if(history){out+=",\"adoptions\":[";bool first=true;for(const auto& a:v.adoptions){if(!first){out+=',';}first=false;
        out+="{\"epoch\":"+std::to_string(a.epoch)+",\"from\":"+std::to_string(a.from)+",\"to\":"+std::to_string(a.to)+",\"start\":"+json_string(a.from_now?"now":"beginning")+
            ",\"configuration_event\":"+std::to_string(a.configuration_event)+",\"unix_ms\":"+std::to_string(a.unix_ms)+",\"pid\":"+std::to_string(a.pid)+
            ",\"authority_digest\":"+json_string(datacube::hex_lower(a.authority))+",\"abandoned_batch\":"+(a.abandoned_batch?json_string(datacube::hex_lower(*a.abandoned_batch)):"null")+
            ",\"reason\":"+json_string(a.reason)+"}";}out+=']';}
    if(v.projection){out+=",\"projection_result_digest\":"+json_string(datacube::hex_lower(projection_result_digest(v)))+",\"projection\":"+projection_json(*v.projection,history);}
    out+=",\"lifecycle\":"+json_string(v.retirement?"RETIRED":"ACTIVE");
    if(v.retirement){out+=",\"retirement\":"+consumer_retirement_json(*v.retirement);}
    return out+"}";
}

EvidenceFeedSlice NodeState::consumer_slice_locked(const DurableConsumer& consumer,
    const EvidenceQueryContext& context, const std::uint64_t after, const std::uint64_t through) const {
    auto selection=consumer.selection;
    if(consumer.projection) {
        // 128 previous source IDs plus the result and definition have to fit in
        // the same response. Do not discover this only after ISSUE is durable.
        if(selection.maximum_response_bytes!=60000U){app_fail("JOURNAL_CORRUPT","projection response contract");}
        selection.maximum_response_bytes-=consumer.projection->numeric?24576U:12288U;
    }
    return evidence_feed_slice_locked(selection,context,after,through);
}
void NodeState::validate_consumer_locked(const DurableConsumer& v) const {
    const auto bad=[](){app_fail("JOURNAL_CORRUPT","invalid durable consumer identity, authority, boundary or provenance");};
    if(!valid_name(v.name)||!nonzero(v.instance)||v.revision==0U||v.unix_ms==0U||v.pid==0U||v.adoptions.empty()||v.adoptions.size()>kConsumerAdoptionLimit||
        v.selection.from_now||!v.selection.cursor.empty()||v.acknowledgments>v.revision){bad();}
    validate_consumer_selection(v.selection);
    const auto config_at=[&](const std::uint64_t event){
        if(event==0U||event>configuration_events_.size()||configuration_events_[event-1U].kind=="REJECTED"){bad();}
        auto c=parse_runtime_config(configuration_events_[event-1U].canonical,"/durable-configuration",IdentityFileValidation::deferred);
        if(c.format_version<11U||!local_control_allows(c.local_control,v.uid,LocalControlClass::consumer)){bad();}
        if(v.projection && (c.format_version<12U || !local_control_allows(c.local_control,v.uid,LocalControlClass::projection))) { bad(); }
        return c;
    };
    std::uint64_t prior_event=0U, prior_total=0U;
    for(std::size_t i=0;i<v.adoptions.size();++i){const auto& a=v.adoptions[i];auto cfg=config_at(a.configuration_event);
        if(a.epoch!=i+1U||a.unix_ms==0U||a.pid==0U||!reason_ok(a.reason)||a.configuration_event<prior_event||
            (!a.from_now&&a.to!=0U)||(i==0U&&(a.from!=0U||a.abandoned_batch))||
            (i!=0U&&!local_control_allows(cfg.local_control,v.uid,LocalControlClass::consumer_admin))){bad();}
        const auto access=evidence_read_access(cfg.evidence_read,cfg.local_control,v.uid);require_access(v.selection,access);
        if(access.digest!=a.authority){bad();}
        const auto total=evidence_feed_total_locked(v.selection,[&]() { EvidenceQueryContext c; c.read_access=access; return c; }());
        if(a.to>total||(i!=0U&&a.from>prior_total)){bad();}
        prior_event=a.configuration_event;prior_total=total;
    }
    auto cfg=config_at(v.configuration_event);const auto access=evidence_read_access(cfg.evidence_read,cfg.local_control,v.uid);
    if(v.configuration_event<prior_event||access.digest!=v.adoptions.back().authority||v.position<v.adoptions.back().to||v.position>prior_total){bad();}
    const auto check_batch=[&](const std::optional<ConsumerBatch>& b){if(!b){return;}
        auto issue_cfg=config_at(b->configuration_event);const auto issue_access=evidence_read_access(issue_cfg.evidence_read,issue_cfg.local_control,v.uid);
        if(!nonzero(b->id)||!nonzero(b->rows_digest)||b->from>=b->through||b->through>prior_total||
            b->through-b->from>v.selection.maximum_records||b->from<v.adoptions.back().to||b->configuration_event<prior_event||
            b->configuration_event>v.configuration_event||b->unix_ms==0U||b->pid==0U||issue_access.digest!=v.adoptions.back().authority){bad();}
        const auto page=consumer_slice_locked(v,[&]() { EvidenceQueryContext c; c.read_access=issue_access; return c; }(),b->from,b->through);
        consumer_validation_records_ += static_cast<std::uint64_t>(page.visited);
        if(page.next!=b->through||rows_hash(page.rows)!=b->rows_digest){bad();}
    };
    check_batch(v.pending);check_batch(v.last_ack);
    if((v.pending&&v.pending->from!=v.position)||(v.last_ack&&(v.last_ack->through!=v.position||v.acknowledgments==0U))||
        (!v.last_ack&&v.position!=v.adoptions.back().to)){bad();}
    validate_projection_locked(v,false);
    if(v.transition!="CREATE"&&v.transition!="ISSUE"&&v.transition!="ACK"&&v.transition!="RESET"&&v.transition!="PROJECT"&&v.transition!="REBUILD"&&v.transition!="AUTO_PROJECT"){bad();}
}
void NodeState::apply_consumer_update(const datacube::OctetView bytes, const bool automatic, const bool validate_only){
    auto next=decode_consumer(bytes);if(next.retirement){app_fail("JOURNAL_CORRUPT","retirement requires its atomic transition");}validate_consumer_locked(next);
    if((next.transition=="AUTO_PROJECT")!=automatic){app_fail("JOURNAL_CORRUPT","automatic result requires its schedule transaction");}
    if(next.configuration_event!=active_configuration_event(configuration_events_)){
        app_fail("JOURNAL_CORRUPT","consumer mutation must bind the active configuration");
    }
    const auto key=consumer_key(next.uid,next.name);const auto found=consumers_.find(key);
    const auto bad=[](){app_fail("JOURNAL_CORRUPT","consumer transition violated exact prior state");};
    if(found==consumers_.end()){
        const auto own=std::count_if(consumers_.begin(),consumers_.end(),[&](const auto& p){return !p.second.retirement && p.second.uid==next.uid;});
        if(std::count_if(consumers_.begin(),consumers_.end(),[](const auto& p){return !p.second.retirement;})>=static_cast<std::ptrdiff_t>(kConsumerLimit)||own>=static_cast<std::ptrdiff_t>(kConsumerUidLimit)){app_fail("CONSUMER_LIMIT","durable consumer capacity exhausted");}
        if(next.transition!="CREATE"||next.revision!=1U||next.pending||next.last_ack||next.acknowledgments!=0U||next.adoptions.size()!=1U||
            next.position!=next.adoptions.back().to||next.adoptions.back().configuration_event!=next.configuration_event||
            next.adoptions.back().unix_ms!=next.unix_ms||next.adoptions.back().pid!=next.pid){bad();}
    }else{
        const auto& old=found->second;if(old.retirement){app_fail("JOURNAL_CORRUPT","retired consumer is immutable");}if(old.revision==std::numeric_limits<std::uint64_t>::max()||next.revision!=old.revision+1U){bad();}
        auto expected=old;expected.revision=next.revision;expected.transition=next.transition;expected.configuration_event=next.configuration_event;expected.unix_ms=next.unix_ms;expected.pid=next.pid;
        if(next.transition=="ISSUE"){
            if(old.pending||!next.pending||next.pending->from!=old.position||next.pending->configuration_event!=next.configuration_event||
                next.pending->unix_ms!=next.unix_ms||next.pending->pid!=next.pid){bad();}expected.pending=next.pending;
        }else if(next.transition=="AUTO_PROJECT") {
            if(!old.projection || !next.last_ack || next.last_ack->from!=old.position ||
                (old.pending && batch_json(old.pending)!=batch_json(next.last_ack))) {bad();}
            if(!old.pending && (next.last_ack->configuration_event!=next.configuration_event || next.last_ack->pid!=next.pid || next.last_ack->unix_ms!=next.unix_ms)) {bad();}
            expected.projection=advance_projection_locked(old,*next.last_ack);
            expected.last_ack=next.last_ack;expected.pending.reset();expected.position=next.last_ack->through;
            expected.acknowledgments=old.acknowledgments+1U;
        }else if(next.transition=="ACK"||next.transition=="PROJECT"){
            if(!old.pending || (old.projection.has_value() != (next.transition=="PROJECT"))){bad();}
            if(old.projection){expected.projection=advance_projection_locked(old,*old.pending);}
            expected.last_ack=old.pending;expected.pending.reset();expected.position=old.pending->through;expected.acknowledgments=old.acknowledgments+1U;
        }else if(next.transition=="RESET"||next.transition=="REBUILD"){
            if(next.adoptions.size()!=old.adoptions.size()+1U || (old.projection.has_value() != (next.transition=="REBUILD"))){bad();}
            if(old.projection){
                expected.projection=initial_projection_locked(old,old.projection->maximum_admissions,old.projection->numeric);
                expected.projection->retired_results=old.projection->retired_results;
                expected.projection->retired_results.push_back(old.projection->totals);
            }const auto& a=next.adoptions.back();
            if(a.from!=old.position||a.configuration_event!=next.configuration_event||a.unix_ms!=next.unix_ms||a.pid!=next.pid||
                a.abandoned_batch!=(old.pending?std::optional(old.pending->id):std::nullopt)){bad();}
            expected.adoptions.push_back(a);expected.position=a.to;expected.pending.reset();expected.last_ack.reset();
        }else{bad();}
        if(encode_consumer(expected)!=encode_consumer(next)){bad();}
    }
    if(!validate_only){consumers_[key]=std::move(next);}
}
void NodeState::commit_consumer_locked(const DurableConsumer& value){
    // The normal writer synchronizes and applies exactly this complete state transition.
    // Validation is repeated by apply_consumer_update after commit and on all replay paths.
    validate_consumer_locked(value);
    if(value.transition=="ACK"){pause_test("NATRAV_OVERLAY_TEST_CONSUMER_ACK_BEFORE_COMMIT_MS");}
    if(value.transition=="PROJECT"){pause_test("NATRAV_OVERLAY_TEST_PROJECTION_BEFORE_COMMIT_MS");}
    append_entry(EntryKind::consumer_update,encode_consumer(value));
    if(value.transition=="ACK"){pause_test("NATRAV_OVERLAY_TEST_CONSUMER_ACK_AFTER_COMMIT_MS");}
    if(value.transition=="PROJECT"){pause_test("NATRAV_OVERLAY_TEST_PROJECTION_AFTER_COMMIT_MS");}
}
std::string NodeState::publish_projection_result(
    const ConsumerRequest& request,
    const EvidenceQueryContext& context,
    const std::uint32_t pid,
    const std::uint64_t configuration_event,
    const OutboundPolicy& policy) {
    validate_consumer_request(request);
    if (!publication_command(request.command)) {
        app_fail("PROJECTION_PUBLICATION_COMMAND_INVALID",
            "projection publication requires the exact publication command");
    }
    std::unique_lock<std::mutex> lock(mutex_);
    if (poisoned_) {
        app_fail("STATE_UNAVAILABLE", "state writer requires restart");
    }
    if (std::chrono::steady_clock::now() >= context.deadline) {
        app_fail("PROJECTION_PUBLICATION_DEADLINE",
            "projection publication exceeded its deadline");
    }
    if (configuration_event == 0U ||
        configuration_event != active_configuration_event(configuration_events_)) {
        app_fail("PROJECTION_PUBLICATION_CONFIGURATION_MISMATCH",
            "publication requires one accepted active configuration");
    }
    const auto active_cfg = parse_runtime_config(
        configuration_events_.at(configuration_event - 1U).canonical,
        "/projection-publication-authority",
        IdentityFileValidation::deferred);
    if (active_cfg.format_version < 12U ||
        !local_control_allows(active_cfg.local_control, context.uid,
            LocalControlClass::projection) ||
        !local_control_allows(active_cfg.local_control, context.uid,
            LocalControlClass::consumer) ||
        !local_control_allows(active_cfg.local_control, context.uid,
            LocalControlClass::submit)) {
        app_fail("LOCAL_CONTROL_CLASS_DENIED",
            "publication requires explicit V12 PROJECTION, CONSUMER, and SUBMIT authority");
    }
    const auto found = consumers_.find(consumer_key(context.uid, request.name));
    if (found == consumers_.end()) {
        app_fail("CONSUMER_NOT_FOUND",
            "no projection with this name is owned by the connected UID");
    }
    const auto& value = found->second;
    if (!value.projection) {
        app_fail("PROJECTION_NOT_FOUND", "consumer has no projection result");
    }
    require_access(value.selection, context.read_access);
    if (value.instance != *request.expected_instance) {
        app_fail("PROJECTION_PUBLICATION_INSTANCE_CONFLICT",
            "publication must select the exact immutable projection instance");
    }
    if (value.revision != request.expected_revision) {
        app_fail("PROJECTION_PUBLICATION_REVISION_CONFLICT",
            "projection revision changed before publication");
    }
    if (value.position != request.expected_position) {
        app_fail("PROJECTION_PUBLICATION_FRONTIER_CONFLICT",
            "processed projection frontier changed before publication");
    }
    const auto result_digest = projection_result_digest(value);
    if (result_digest != *request.expected_result_digest) {
        app_fail("PROJECTION_PUBLICATION_RESULT_CONFLICT",
            "projection result changed before publication");
    }
    if (!policy.peer_generation || !policy.peer_spki_sha256) {
        app_fail("PROJECTION_PUBLICATION_POLICY_INVALID",
            "recipient delivery policy lacks an exact key generation");
    }
    const auto publication_authority = projection_publication_authority(
        value, request.publication_recipient, *policy.peer_generation,
        *policy.peer_spki_sha256, request.publication_scope, context);
    const auto payload = projection_publication_payload(
        value, request.publication_recipient, *policy.peer_generation,
        *policy.peer_spki_sha256, request.publication_scope, context);
    const auto operation_id = projection_publication_operation(payload);
    EvidenceRecord record{
        .operation_id = operation_id,
        .issuer = node_id_,
        .recipient = request.publication_recipient,
        .scope = request.publication_scope,
        .corrects = std::nullopt,
        .payload = payload,
    };
    validate_evidence_record(record);
    pause_test("NATRAV_OVERLAY_TEST_PROJECTION_PUBLICATION_BEFORE_COMMIT_MS");
    const auto queued = queue_outbound_locked(record, policy);
    pause_test("NATRAV_OVERLAY_TEST_PROJECTION_PUBLICATION_AFTER_COMMIT_MS");
    const auto payload_digest = datacube::sha256(payload);
    const auto record_digest = evidence_record_digest(record);
    return std::string(
        "{\"format\":\"NATRAV_OVERLAY_PROJECTION_PUBLICATION_V1\",\"ok\":true") +
        ",\"queue_disposition\":" +
        json_string(queue_disposition_name(queued.disposition)) +
        ",\"operation_id\":" + json_string(datacube::hex_lower(operation_id)) +
        ",\"record_digest\":" + json_string(datacube::hex_lower(record_digest)) +
        ",\"payload_format\":\"NPP1\"" +
        ",\"payload_digest\":" + json_string(datacube::hex_lower(payload_digest)) +
        ",\"consumer\":" + json_string(value.name) +
        ",\"owner_uid\":" + std::to_string(value.uid) +
        ",\"request_pid\":" + std::to_string(pid) +
        ",\"instance\":" + json_string(datacube::hex_lower(value.instance)) +
        ",\"revision\":" + std::to_string(value.revision) +
        ",\"epoch\":" + std::to_string(value.adoptions.size()) +
        ",\"processed_frontier\":" + std::to_string(value.position) +
        ",\"result_digest\":" + json_string(datacube::hex_lower(result_digest)) +
        ",\"source_commitment\":" +
            json_string(datacube::hex_lower(value.projection->totals.source_digest)) +
        ",\"definition\":" +
            json_string(value.projection->numeric ? "NUMERIC_SUMMARY_V1" : "DOMAIN_SUMMARY_V1") +
        ",\"lifecycle\":" + json_string(value.retirement ? "RETIRED" : "ACTIVE") +
        ",\"recipient\":" + json_string(request.publication_recipient) +
        ",\"recipient_generation\":" + json_string(*policy.peer_generation) +
        ",\"recipient_spki_sha256\":" +
            json_string(datacube::hex_lower(*policy.peer_spki_sha256)) +
        ",\"scope\":" + json_string(request.publication_scope) +
        ",\"read_authority_digest\":" +
            json_string(datacube::hex_lower(context.read_access.digest)) +
        ",\"publication_authority_digest\":" +
            json_string(datacube::hex_lower(publication_authority)) +
        ",\"configuration_event\":" + std::to_string(configuration_event) +
        ",\"configuration_digest\":" +
            json_string(datacube::hex_lower(context.configuration_digest)) +
        ",\"status\":" + json_string(queued.status) + "}";
}

std::string NodeState::consumer_command(const ConsumerRequest& r,const EvidenceQueryContext& context,
    const std::uint32_t pid,const std::uint64_t configuration_event){
    validate_consumer_request(r);std::unique_lock<std::mutex> lock(mutex_);
    const auto validation_before = consumer_validation_records_;
    const auto projection_before = projection_records_visited_;
    if(poisoned_){app_fail("STATE_UNAVAILABLE","state writer requires restart");}
    if(std::chrono::steady_clock::now()>=context.deadline){app_fail("CONSUMER_DEADLINE","consumer request exceeded deadline");}
    if(configuration_event==0U||configuration_event!=active_configuration_event(configuration_events_)){app_fail("CONSUMER_CONFIGURATION_MISMATCH","consumer requires one accepted configuration");}
    const auto key=consumer_key(context.uid,r.name);auto found=consumers_.find(key);bool replayed=false;std::string disposition;
    if(publication_command(r.command)){app_fail("PROJECTION_PUBLICATION_DISPATCH_INVALID","publication requires the atomic outbox dispatch path");}
    if(retirement_command(r.command)){return consumer_retirement_command_locked(r,context,pid,configuration_event);}
    if(found!=consumers_.end() && found->second.retirement && !consumer_status(r.command)) {
        app_fail("CONSUMER_RETIRED","name is permanently retired; use a fresh name, never reuse this instance");
    }
    if(schedule_command(r.command)) {return projection_schedule_command_locked(r,context,pid,configuration_event);}
    if(!consumer_status(r.command) && !consumer_create(r.command) && projection_schedules_.contains(key) &&
        projection_schedules_.at(key).grants.back().state=="ENABLED") {
        app_fail("PROJECTION_AUTOMATION_ENABLED","pause the durable schedule before manual consumer mutation");
    }
    if(projection_command(r.command)||(found!=consumers_.end()&&found->second.projection)) {
        const auto active_cfg=parse_runtime_config(configuration_events_.at(configuration_event-1U).canonical,"/projection-authority",IdentityFileValidation::deferred);
        if(active_cfg.format_version<12U || !local_control_allows(active_cfg.local_control,context.uid,LocalControlClass::projection) ||
            !local_control_allows(active_cfg.local_control,context.uid,LocalControlClass::consumer)) {
            app_fail("LOCAL_CONTROL_CLASS_DENIED", "projection requires explicit V12 PROJECTION and CONSUMER authority");
        }
    }
    EvidenceFeedSlice page;bool has_page=false;
    const auto stamp=[&](DurableConsumer& v,std::string_view transition){
        if(v.revision==std::numeric_limits<std::uint64_t>::max()){app_fail("CONSUMER_REVISION_LIMIT","consumer revision exhausted");}
        ++v.revision;v.transition=transition;v.configuration_event=configuration_event;v.unix_ms=now_ms();v.pid=pid;
    };
    if(consumer_create(r.command)){
        require_access(r.selection,context.read_access);auto selection=r.selection;selection.from_now=false;
        if(found!=consumers_.end()){
            if(found->second.projection.has_value()!=(r.command==ConsumerCommand::projection_create) ||
                (found->second.projection && (found->second.projection->maximum_admissions!=r.maximum_admissions || found->second.projection->numeric!=r.numeric)) ||
                encode_evidence_feed(found->second.selection)!=encode_evidence_feed(selection)){
                app_fail("CONSUMER_EXISTS","name already has a different immutable selection");
            }
            if(found->second.adoptions.back().authority!=context.read_access.digest){app_fail("CONSUMER_POLICY_CHANGED","explicit reset is required to adopt changed read authority");}
            disposition="ALREADY_EXISTS";replayed=true;
        }else{
            const auto own=std::count_if(consumers_.begin(),consumers_.end(),[&](const auto& p){return !p.second.retirement && p.second.uid==context.uid;});
            if(std::count_if(consumers_.begin(),consumers_.end(),[](const auto& p){return !p.second.retirement;})>=static_cast<std::ptrdiff_t>(kConsumerLimit)||own>=static_cast<std::ptrdiff_t>(kConsumerUidLimit)){app_fail("CONSUMER_LIMIT","bounded durable consumer registry is full");}
            DurableConsumer v;v.name=r.name;v.uid=context.uid;v.instance=random_id();v.selection=selection;stamp(v,"CREATE");
            v.position=r.selection.from_now?evidence_feed_total_locked(selection,context):0U;
            v.adoptions.push_back(ConsumerAdoption{.epoch=1U,.from=0U,.to=v.position,.from_now=r.selection.from_now,
                .configuration_event=configuration_event,.unix_ms=v.unix_ms,.pid=pid,.authority=context.read_access.digest,.abandoned_batch=std::nullopt,.reason=r.reason});
            if(r.command==ConsumerCommand::projection_create){v.projection=initial_projection_locked(v,r.maximum_admissions,r.numeric);}
            commit_consumer_locked(v);disposition="CREATED";
        }
    }else{
        if(found==consumers_.end()){app_fail("CONSUMER_NOT_FOUND","no consumer with this name is owned by the connected UID");}
        const auto& current=found->second;
        if(projection_command(r.command)&&!current.projection){app_fail("PROJECTION_NOT_FOUND","consumer has no projection");}
        if(current.projection&&(r.command==ConsumerCommand::acknowledge||r.command==ConsumerCommand::reset)){
            app_fail("PROJECTION_ATOMIC_TRANSITION_REQUIRED","projected consumers require projection-process or projection-rebuild");
        }
        if(current.projection&&!consumer_reset(r.command)&&current.adoptions.back().authority!=context.read_access.digest){
            app_fail("CONSUMER_POLICY_CHANGED","projection result access requires the adopted authority; explicitly rebuild after policy change");
        }
        // Ownership is the map namespace, not a caller-supplied UID or possession of a batch ID.
        require_access(current.selection,context.read_access);
        if(!consumer_reset(r.command)&&!consumer_status(r.command)&&current.adoptions.back().authority!=context.read_access.digest){
            app_fail("CONSUMER_POLICY_CHANGED","effective read authority changed; explicit reset must adopt a new epoch");
        }
        if(consumer_status(r.command)){disposition="STATUS";}
        else if(r.command==ConsumerCommand::read){
            const auto total=evidence_feed_total_locked(current.selection,context);
            page=consumer_slice_locked(current,context,current.position,current.pending?current.pending->through:total);has_page=true;
            if(current.pending){
                if(page.next!=current.pending->through||rows_hash(page.rows)!=current.pending->rows_digest){app_fail("CONSUMER_HISTORY_MISMATCH","issued page is no longer reconstructable");}
                disposition="REPLAY";replayed=true;
            }else if(page.count!=0U){
                auto next=current;stamp(next,"ISSUE");
                next.pending=ConsumerBatch{.id=random_id(),.from=current.position,.through=page.next,.rows_digest=rows_hash(page.rows),
                    .configuration_event=configuration_event,.unix_ms=next.unix_ms,.pid=pid};commit_consumer_locked(next);disposition="ISSUED";
            }else{disposition="EMPTY";}
        }else if(consumer_ack(r.command)){
            if(current.last_ack&&current.last_ack->id==*r.batch_id){disposition="ALREADY_ACKNOWLEDGED";replayed=true;}
            else{
                if(!current.pending||CRYPTO_memcmp(current.pending->id.octets.data(),r.batch_id->octets.data(),32U)!=0){
                    app_fail("CONSUMER_ACK_INVALID","acknowledgment does not match this consumer's outstanding issued page");
                }
                auto next=current;stamp(next,current.projection?"PROJECT":"ACK");
                if(current.projection){next.projection=advance_projection_locked(current,*current.pending);}
                next.position=current.pending->through;next.last_ack=current.pending;next.pending.reset();++next.acknowledgments;
                commit_consumer_locked(next);disposition=current.projection?"PROJECTED":"ACKNOWLEDGED";
            }
        }else if(consumer_reset(r.command)){
            if(r.expected_revision!=current.revision){app_fail("CONSUMER_REVISION_CONFLICT","reset must select the exact current revision");}
            if(current.adoptions.size()>=kConsumerAdoptionLimit){app_fail("CONSUMER_HISTORY_LIMIT","bounded adoption/reset history is full");}
            auto next=current;stamp(next,current.projection?"REBUILD":"RESET");next.position=r.selection.from_now?evidence_feed_total_locked(current.selection,context):0U;
            next.adoptions.push_back(ConsumerAdoption{.epoch=current.adoptions.size()+1U,.from=current.position,.to=next.position,.from_now=r.selection.from_now,
                .configuration_event=configuration_event,.unix_ms=next.unix_ms,.pid=pid,.authority=context.read_access.digest,
                .abandoned_batch=current.pending?std::optional(current.pending->id):std::nullopt,.reason=r.reason});
            next.pending.reset();next.last_ack.reset();
            if(current.projection){next.projection=initial_projection_locked(current,current.projection->maximum_admissions,current.projection->numeric);
                next.projection->retired_results=current.projection->retired_results;next.projection->retired_results.push_back(current.projection->totals);}
            commit_consumer_locked(next);disposition=current.projection?"REBUILT":"RESET";
        }
    }
    const auto& value=consumers_.at(key);
    const bool frozen=value.adoptions.back().authority!=context.read_access.digest;
    auto out=std::string("{\"format\":\"NATRAV_OVERLAY_CONSUMER_V1\",\"ok\":true,\"node\":")+json_string(node_id_)+
        ",\"disposition\":"+json_string(disposition)+",\"replayed\":"+(replayed?"true":"false")+",\"policy_changed\":"+(frozen?"true":"false")+
        ",\"sequence_semantics\":\"AUTHORIZED_ADMISSION_ORDINAL\",\"consumer\":"+consumer_json(value,consumer_status(r.command));
    if(has_page){out+=",\"returned_records\":"+std::to_string(page.count)+",\"caught_up\":"+(page.next==page.total?"true":"false")+
        ",\"remaining_records\":"+std::to_string(page.total-page.next)+",\"records\":["+page.rows+"]"+
        ",\"feed_work\":{\"index_records_visited\":"+std::to_string(page.visited)+",\"selection_records_hashed\":0}";}
    out += ",\"consumer_work\":{\"page_index_records_visited\":" + std::to_string(page.visited) +
        ",\"validation_records_visited\":" + std::to_string(consumer_validation_records_ - validation_before) + "}";
    if(value.projection){out+=",\"projection_work\":{\"source_records_visited\":"+std::to_string(projection_records_visited_-projection_before)+"}";}
    out+="}";
    const auto bound=consumer_status(r.command)?60000U:value.selection.maximum_response_bytes;
    if(out.size()+512U>bound){app_fail("CONSUMER_RESPONSE_LIMIT","bounded result exceeds response limit; issued state remains replayable");}
    return out;
}
} // namespace natrav_overlay
