#pragma once

#include "common.hpp"
#include "read_policy.hpp"
#include <cstdint>
#include <chrono>
#include <optional>
#include <string>

namespace natrav_overlay {

// Exact conjunctive filters. Empty issuer/scope and absent operation mean any.
// This reads recipient-admitted evidence only, never pending outbound material.
struct EvidenceQuery final {
    bool history{false};
    bool include_payload{false};
    std::string issuer;
    std::string scope;
    std::optional<datacube::Digest32> operation_id;
    std::uint32_t maximum_records{32U};
    std::uint32_t maximum_response_bytes{60'000U};
    std::uint32_t payload_offset{0U};
    std::uint32_t payload_length{0U};
    std::string cursor;
};

struct EvidenceQueryContext final {
    std::uint32_t uid{0U};
    std::string configuration_generation;
    datacube::Digest32 configuration_digest;
    EvidenceReadAccess read_access;
    std::chrono::steady_clock::time_point deadline{std::chrono::steady_clock::time_point::max()};
};

void validate_evidence_query(const EvidenceQuery& query);
[[nodiscard]] datacube::Octets encode_evidence_query(const EvidenceQuery& query);
[[nodiscard]] EvidenceQuery decode_evidence_query(datacube::OctetView bytes);

} // namespace natrav_overlay
