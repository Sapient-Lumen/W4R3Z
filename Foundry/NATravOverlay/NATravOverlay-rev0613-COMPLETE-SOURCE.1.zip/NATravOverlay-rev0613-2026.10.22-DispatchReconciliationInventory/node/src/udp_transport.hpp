#pragma once

#include "transport.hpp"

#include <memory>
#include <string>

namespace natrav_overlay {

inline constexpr char kUdpPacketCarrierMarker[] =
    "NUMERIC_POINT_TO_POINT_UDP_PACKET_CARRIER_V1";
[[nodiscard]] int udp_packet_carrier_revision_abi() noexcept;

[[nodiscard]] std::string udp_transport_endpoint_text(
    const UdpTransportEndpoint& endpoint);
[[nodiscard]] std::string udp_transport_locator_text(
    const UdpTransportLocator& locator);
[[nodiscard]] const TransportConnector& udp_transport_connector();
[[nodiscard]] std::unique_ptr<TransportListener> listen_udp_transport(
    const TransportLocator& locator,
    int backlog);

}  // namespace natrav_overlay
