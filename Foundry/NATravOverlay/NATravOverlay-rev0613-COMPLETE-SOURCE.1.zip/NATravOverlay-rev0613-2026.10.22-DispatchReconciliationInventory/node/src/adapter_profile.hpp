#pragma once

#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

inline constexpr char kOperatorPinnedAdapterProfileMarker[] =
    "OPERATOR_PINNED_ADAPTER_PROFILE_V1";
[[nodiscard]] int operator_pinned_adapter_profile_revision_abi() noexcept;

using AdapterSha256 = std::array<std::uint8_t, 32U>;

class AdapterProfileError final : public std::runtime_error {
public:
    AdapterProfileError(std::string code, std::string detail);

    [[nodiscard]] const std::string& code() const noexcept;

private:
    std::string code_;
};

struct OperatorPinnedAdapterProfile final {
    std::string profile_id;
    std::uint64_t generation{0U};
    AdapterSha256 previous_profile_sha256{};
    std::filesystem::path executable;
    AdapterSha256 executable_sha256{};
    std::vector<std::string> arguments{};
    std::size_t mtu{512U};
    std::uint32_t capability_profile{1U};
    std::size_t max_frame_bytes{65'536U};
    std::size_t max_queued_bytes{1'048'576U};
    std::uint32_t max_outstanding_requests{1U};
    std::size_t max_evidence_events{256U};
    std::uint32_t max_launch_attempts{3U};
    std::chrono::milliseconds startup_timeout{2'000};
    std::chrono::milliseconds request_timeout{500};
    std::chrono::milliseconds shutdown_timeout{500};
    std::chrono::milliseconds initial_restart_backoff{10};
    std::chrono::milliseconds maximum_restart_backoff{250};

    friend bool operator==(
        const OperatorPinnedAdapterProfile&,
        const OperatorPinnedAdapterProfile&) = default;
};

struct AdapterTransportLocator final {
    std::string profile_id;
    std::uint64_t profile_generation{0U};
    std::uint64_t link_id{0U};
    std::uint32_t epoch{0U};

    friend bool operator==(
        const AdapterTransportLocator&,
        const AdapterTransportLocator&) = default;
};

[[nodiscard]] std::string adapter_sha256_hex(const AdapterSha256& digest);
[[nodiscard]] AdapterSha256 parse_adapter_sha256(std::string_view text);
[[nodiscard]] AdapterSha256 adapter_sha256(std::span<const std::uint8_t> bytes);

void validate_operator_pinned_adapter_profile(
    const OperatorPinnedAdapterProfile& profile);
[[nodiscard]] std::string operator_pinned_adapter_profile_text(
    const OperatorPinnedAdapterProfile& profile);
[[nodiscard]] OperatorPinnedAdapterProfile
parse_operator_pinned_adapter_profile(std::string_view text);
[[nodiscard]] AdapterSha256 operator_pinned_adapter_profile_sha256(
    const OperatorPinnedAdapterProfile& profile);

// Creation requires generation one and an all-zero predecessor. Replacement
// requires the same stable identifier, the immediately following generation,
// and the exact SHA-256 of the predecessor's canonical record.
void validate_operator_pinned_adapter_profile_transition(
    const OperatorPinnedAdapterProfile* current,
    const OperatorPinnedAdapterProfile& proposed);

[[nodiscard]] std::string adapter_transport_locator_text(
    const AdapterTransportLocator& locator);
[[nodiscard]] AdapterTransportLocator parse_adapter_transport_locator(
    std::string_view text);
[[nodiscard]] const OperatorPinnedAdapterProfile& resolve_adapter_profile(
    std::span<const OperatorPinnedAdapterProfile> profiles,
    const AdapterTransportLocator& locator);

[[nodiscard]] std::chrono::milliseconds adapter_restart_backoff(
    const OperatorPinnedAdapterProfile& profile,
    std::uint32_t attempt);

class VerifiedAdapterExecutable final {
public:
    VerifiedAdapterExecutable(const VerifiedAdapterExecutable&) = delete;
    VerifiedAdapterExecutable& operator=(const VerifiedAdapterExecutable&) = delete;
    VerifiedAdapterExecutable(VerifiedAdapterExecutable&& other) noexcept;
    VerifiedAdapterExecutable& operator=(VerifiedAdapterExecutable&& other) noexcept;
    ~VerifiedAdapterExecutable();

    [[nodiscard]] const std::filesystem::path& configured_path() const noexcept;
    [[nodiscard]] const AdapterSha256& sha256() const noexcept;
    [[nodiscard]] std::uint64_t source_device() const noexcept;
    [[nodiscard]] std::uint64_t source_inode() const noexcept;
    [[nodiscard]] std::uint64_t size() const noexcept;

    // Returns a CLOEXEC duplicate at or above minimum_descriptor. The caller
    // owns the returned descriptor.
    [[nodiscard]] int duplicate_for_exec(int minimum_descriptor = 4) const;

private:
    VerifiedAdapterExecutable(
        int descriptor,
        std::filesystem::path configured_path,
        AdapterSha256 digest,
        std::uint64_t source_device,
        std::uint64_t source_inode,
        std::uint64_t size) noexcept;

    int descriptor_{-1};
    std::filesystem::path configured_path_{};
    AdapterSha256 digest_{};
    std::uint64_t source_device_{0U};
    std::uint64_t source_inode_{0U};
    std::uint64_t size_{0U};

    friend VerifiedAdapterExecutable open_verified_adapter_executable(
        const OperatorPinnedAdapterProfile& profile);
};

// Opens the canonical path without following any symlink component, verifies
// ownership and mode, hashes the exact bytes, copies the approved ELF image to
// a sealed memfd, and returns only the sealed executable. Later path replacement
// or mutation therefore cannot change the bytes that will execute.
[[nodiscard]] VerifiedAdapterExecutable open_verified_adapter_executable(
    const OperatorPinnedAdapterProfile& profile);

// Executes a sealed image descriptor without re-resolving the configured path.
// This function returns only on failure and leaves errno from execveat/fexecve.
[[nodiscard]] int execute_verified_adapter_image(
    int executable_descriptor,
    char* const arguments[],
    char* const environment[]) noexcept;

}  // namespace natrav_overlay
