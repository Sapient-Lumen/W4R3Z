#include "projection.hpp"
#include "journal.hpp"

#include <algorithm>
#include <bit>
#include <limits>

namespace natrav_overlay {
namespace {
void put_digest(datacube::Octets& out, const datacube::Digest32& value) {
    datacube::append_octets(out, value.octets);
}
datacube::Digest32 get_digest(datacube::Reader& reader) {
    datacube::Digest32 value{};
    const auto bytes = reader.read_exact(32U, "projection digest");
    std::copy(bytes.begin(), bytes.end(), value.octets.begin());
    return value;
}
void put_totals(datacube::Octets& out, const ProjectionTotals& value, const bool numeric) {
    datacube::append_be64(out, value.admissions);
    datacube::append_be64(out, value.originals);
    datacube::append_be64(out, value.corrections);
    datacube::append_be64(out, value.historical_payload_bytes);
    datacube::append_be64(out, value.current_payload_bytes);
    put_digest(out, value.source_digest);
    if(numeric){
        const auto& n=value.numeric;
        datacube::append_be64(out,n.accepted);datacube::append_be64(out,n.rejected);
        datacube::append_be64(out,n.valid_heads);datacube::append_be64(out,n.invalid_heads);
        datacube::append_be64(out,std::bit_cast<std::uint64_t>(n.sum_ticks));
        for(const auto count:n.errors){datacube::append_be64(out,count);}
    }
}
ProjectionTotals get_totals(datacube::Reader& reader, const bool numeric) {
    ProjectionTotals value;
    value.admissions = reader.read_be64("projection admissions");
    value.originals = reader.read_be64("projection originals");
    value.corrections = reader.read_be64("projection corrections");
    value.historical_payload_bytes = reader.read_be64("projection historical bytes");
    value.current_payload_bytes = reader.read_be64("projection current bytes");
    value.source_digest = get_digest(reader);
    if(numeric){
        auto& n=value.numeric;n.accepted=reader.read_be64("numeric accepted");n.rejected=reader.read_be64("numeric rejected");
        n.valid_heads=reader.read_be64("numeric valid heads");n.invalid_heads=reader.read_be64("numeric invalid heads");
        n.sum_ticks=std::bit_cast<std::int64_t>(reader.read_be64("numeric signed sum"));
        for(auto& count:n.errors){count=reader.read_be64("numeric error count");}
    }
    return value;
}
std::string totals_json(const ProjectionTotals& value, const bool numeric) {
    auto out = "{\"admissions\":" + std::to_string(value.admissions) +
        ",\"originals\":" + std::to_string(value.originals) +
        ",\"corrections\":" + std::to_string(value.corrections) +
        ",\"current_heads\":" + std::to_string(value.originals) +
        ",\"historical_payload_bytes\":" + std::to_string(value.historical_payload_bytes) +
        ",\"current_payload_bytes\":" + std::to_string(value.current_payload_bytes) +
        ",\"source_digest\":" + json_string(datacube::hex_lower(value.source_digest));
    if(numeric){
        const auto& n=value.numeric;
        out+=",\"numeric\":{\"accepted_admissions\":"+std::to_string(n.accepted)+",\"rejected_admissions\":"+std::to_string(n.rejected)+
            ",\"valid_heads\":"+std::to_string(n.valid_heads)+",\"invalid_heads\":"+std::to_string(n.invalid_heads)+
            ",\"sum_ticks\":"+json_string(std::to_string(n.sum_ticks))+",\"rejections\":{";
        for(std::size_t i=0;i<n.errors.size();++i){if(i!=0U){out+=',';}out+=json_string(numeric_outcome_name(static_cast<NumericOutcome>(i+1U)))+":"+std::to_string(n.errors[i]);}
        out+="}}";
    }
    return out+"}";
}
void add_checked(std::uint64_t& value, const std::uint64_t increment) {
    if (increment > std::numeric_limits<std::uint64_t>::max() - value) {
        app_fail("PROJECTION_ARITHMETIC_LIMIT", "projection counter overflow");
    }
    value += increment;
}
void apply_source(ProjectionTotals& totals, const StoredInbound& source,
    const StoredInbound* parent) {
    const auto bytes = static_cast<std::uint64_t>(source.record.payload.size());
    if (parent != nullptr) {
        const auto old_bytes = static_cast<std::uint64_t>(parent->record.payload.size());
        if (totals.current_payload_bytes < old_bytes) {
            app_fail("JOURNAL_CORRUPT", "projection correction lacks its previously consumed head");
        }
        totals.current_payload_bytes -= old_bytes;
        add_checked(totals.corrections, 1U);
    } else { add_checked(totals.originals, 1U); }
    add_checked(totals.admissions, 1U);
    add_checked(totals.historical_payload_bytes, bytes);
    add_checked(totals.current_payload_bytes, bytes);
    datacube::Octets chain;
    datacube::append_text(chain, "NATRAV_OVERLAY_PROJECTION_SOURCE_V1");
    datacube::append_u8(chain, 0U);
    put_digest(chain, totals.source_digest);
    datacube::append_be64(chain, totals.admissions);
    put_digest(chain, source.record.operation_id);
    put_digest(chain, source.record_digest);
    totals.source_digest = datacube::sha256(chain);
}
} // namespace

datacube::Octets encode_projection(const EvidenceProjection& value) {
    datacube::Octets out;
    datacube::append_text(out, value.numeric ? "NPR2" : "NPR1");
    if(value.numeric){datacube::append_octets(out,encode_numeric_definition(*value.numeric));}
    datacube::append_be64(out, value.maximum_admissions);
    put_digest(out, value.definition_digest);
    put_totals(out, value.totals, value.numeric.has_value());
    datacube::append_be32(out, static_cast<std::uint32_t>(value.retired_results.size()));
    for (const auto& totals : value.retired_results) { put_totals(out, totals, value.numeric.has_value()); }
    datacube::append_be32(out, static_cast<std::uint32_t>(value.last_sources.size()));
    for (const auto& id : value.last_sources) { put_digest(out, id); }
    if(value.numeric){
        datacube::append_be32(out,static_cast<std::uint32_t>(value.last_outcomes.size()));
        for(const auto outcome:value.last_outcomes){datacube::append_u8(out,static_cast<std::uint8_t>(outcome));}
    }
    return out;
}
EvidenceProjection decode_projection(const datacube::OctetView bytes) {
    datacube::Reader reader(bytes, "projection state");
    const auto magic=datacube::octets_text(reader.read_exact(4U, "magic"), "magic", true);
    if (magic != "NPR1" && magic != "NPR2") {
        app_fail("JOURNAL_CORRUPT", "unknown projection format");
    }
    EvidenceProjection value;
    if(magic=="NPR2"){value.numeric=decode_numeric_definition(reader);}
    value.maximum_admissions = reader.read_be64("projection admission budget");
    value.definition_digest = get_digest(reader);
    value.totals = get_totals(reader, value.numeric.has_value());
    const auto history = reader.read_be32("retired result count");
    if (history >= kConsumerAdoptionLimit) { app_fail("JOURNAL_CORRUPT", "projection history bound"); }
    for (std::uint32_t i=0U; i<history; ++i) { value.retired_results.push_back(get_totals(reader, value.numeric.has_value())); }
    const auto sources = reader.read_be32("last sources count");
    if (sources > 128U) { app_fail("JOURNAL_CORRUPT", "projection source page bound"); }
    for (std::uint32_t i=0U; i<sources; ++i) { value.last_sources.push_back(get_digest(reader)); }
    if(value.numeric){
        const auto count=reader.read_be32("numeric outcome count");
        if(count>128U){app_fail("JOURNAL_CORRUPT","numeric outcome page bound");}
        for(std::uint32_t i=0;i<count;++i){
            const auto outcome=reader.read_u8("numeric outcome");
            if(outcome>4U){app_fail("JOURNAL_CORRUPT","numeric outcome type");}
            value.last_outcomes.push_back(static_cast<NumericOutcome>(outcome));
        }
    }
    reader.require_eof("projection state");
    return value;
}
std::string projection_json(const EvidenceProjection& value, const bool history) {
    auto out = std::string("{\"definition\":") + json_string(value.numeric?"NUMERIC_SUMMARY_V1":"DOMAIN_SUMMARY_V1")+",\"definition_digest\":" +
        json_string(datacube::hex_lower(value.definition_digest)) +
        ",\"maximum_admissions\":" + std::to_string(value.maximum_admissions) +
        ",\"result\":" + totals_json(value.totals, value.numeric.has_value()) + ",\"last_source_operations\":[";
    bool first = true;
    for (const auto& id : value.last_sources) {
        if (!first) { out += ','; } first=false;
        out += json_string(datacube::hex_lower(id));
    }
    out += "]";
    if(value.numeric){
        const auto& d=*value.numeric;
        out+=",\"numeric_definition\":{\"payload_format\":\"NNO1\",\"unit\":"+json_string(d.unit)+
            ",\"scale\":"+std::to_string(d.scale)+",\"maximum_absolute_sum_ticks\":"+json_string(std::to_string(d.maximum_absolute_sum))+
            ",\"maximum_absolute_value_ticks\":\"1000000000000\"},\"last_numeric_outcomes\":[";
        first=true;for(const auto outcome:value.last_outcomes){if(!first){out+=',';}first=false;out+=json_string(numeric_outcome_name(outcome));}out+=']';
    }
    if (history) {
        out += ",\"retired_results\":["; first=true;
        for (const auto& totals : value.retired_results) {
            if (!first) { out += ','; } first=false;out += totals_json(totals, value.numeric.has_value());
        }
        out += "]";
    }
    return out + "}";
}

EvidenceProjection NodeState::initial_projection_locked(const DurableConsumer& value,
    const std::uint64_t maximum_admissions, const std::optional<NumericDefinition>& numeric) const {
    EvidenceProjection projection;
    projection.maximum_admissions = maximum_admissions;
    projection.numeric = numeric;
    datacube::Octets definition;
    datacube::append_text(definition, numeric ? "NATRAV_OVERLAY_NUMERIC_SUMMARY_V1" : "NATRAV_OVERLAY_DOMAIN_SUMMARY_V1");
    datacube::append_u8(definition, 0U);
    datacube::append_be32(definition, value.uid);
    put_digest(definition, value.instance);
    datacube::append_be64(definition, maximum_admissions);
    datacube::append_octets(definition, encode_evidence_feed(value.selection));
    if(numeric){datacube::append_octets(definition,encode_numeric_definition(*numeric));}
    projection.definition_digest = datacube::sha256(definition);
    projection.totals.source_digest = projection.definition_digest;
    return projection;
}

EvidenceProjection NodeState::advance_projection_locked(const DurableConsumer& value,
    const ConsumerBatch& batch) const {
    if (!value.projection || batch.from != value.position || batch.through <= batch.from ||
        batch.through - batch.from > value.selection.maximum_records) {
        app_fail("JOURNAL_CORRUPT", "projection must consume its exact outstanding bounded page");
    }
    if (batch.through > value.projection->maximum_admissions) {
        app_fail("PROJECTION_ADMISSION_LIMIT", "immutable projection admission budget exhausted; page remains outstanding");
    }
    auto next = *value.projection;
    next.last_sources.clear();
    next.last_outcomes.clear();
    const auto found = inbound_domain_index_.find({value.selection.issuer, value.selection.scope});
    if (found == inbound_domain_index_.end() || batch.through > found->second.size(true)) {
        app_fail("JOURNAL_CORRUPT", "projection source domain is unavailable");
    }
    for (auto ordinal=batch.from; ordinal<batch.through; ++ordinal) {
        const auto index = found->second.at(static_cast<std::size_t>(ordinal), true);
        const auto& source = inbound_.at(index);
        const StoredInbound* parent = nullptr;
        if (source.record.corrects) {
            const auto previous = inbound_index_.find(datacube::hex_lower(*source.record.corrects));
            if (previous == inbound_index_.end() || previous->second >= index) {
                app_fail("JOURNAL_CORRUPT", "projection correction predecessor unavailable");
            }
            parent = &inbound_.at(previous->second);
            if (parent->record.issuer != value.selection.issuer || parent->record.scope != value.selection.scope) {
                app_fail("JOURNAL_CORRUPT", "projection cannot cross source domains");
            }
        }
        apply_source(next.totals, source, parent);
        if(next.numeric){
            const auto decoded=decode_numeric_observation(source.record.payload,*next.numeric);
            const auto old=parent?decode_numeric_observation(parent->record.payload,*next.numeric):NumericObservation{};
            apply_numeric_observation(next.totals.numeric,decoded,parent?&old:nullptr,*next.numeric);
            next.last_outcomes.push_back(decoded.outcome);
        }
        next.last_sources.push_back(source.record.operation_id);
        ++projection_records_visited_;
    }
    return next;
}

void NodeState::validate_projection_locked(const DurableConsumer& value, const bool full_replay) const {
    if (!value.projection) { return; }
    const auto& projection = *value.projection;
    const auto bad=[](){app_fail("JOURNAL_CORRUPT", "projection result/checkpoint/definition coupling violated");};
    if (value.selection.issuer.empty() || value.selection.scope.empty() || value.selection.include_payload != projection.numeric.has_value() ||
        value.selection.payload_length != (projection.numeric?46U:0U) || value.selection.maximum_response_bytes != 60000U || projection.maximum_admissions==0U || projection.maximum_admissions>1000000U ||
        projection.retired_results.size()+1U != value.adoptions.size() || value.position!=projection.totals.admissions) { bad(); }
    if(value.transition!="CREATE" && value.transition!="ISSUE" && value.transition!="PROJECT" && value.transition!="REBUILD" && value.transition!="AUTO_PROJECT") { bad(); }
    const auto initial=initial_projection_locked(value, projection.maximum_admissions, projection.numeric);
    if (projection.definition_digest!=initial.definition_digest) { bad(); }
    if(projection.numeric){validate_numeric_definition(*projection.numeric);
        if(projection.last_outcomes.size()!=projection.last_sources.size()){bad();}
    }else if(!projection.last_outcomes.empty()){bad();}
    const auto check_totals=[&](const ProjectionTotals& totals) {
        if (totals.admissions>projection.maximum_admissions || totals.originals>totals.admissions ||
            totals.corrections!=totals.admissions-totals.originals ||
            totals.historical_payload_bytes>totals.admissions*static_cast<std::uint64_t>(kMaximumEvidencePayloadBytes) ||
            totals.current_payload_bytes>totals.historical_payload_bytes ||
            (totals.admissions==0U && totals!=initial.totals)) { bad(); }
        const auto& n=totals.numeric;
        if(projection.numeric){
            if(n.accepted>totals.admissions || n.rejected!=totals.admissions-n.accepted ||
                n.valid_heads>totals.originals || n.invalid_heads!=totals.originals-n.valid_heads || n.valid_heads>n.accepted || n.invalid_heads>n.rejected){bad();}
            std::uint64_t count=0U;
            for(const auto v:n.errors){if(v>n.rejected-count){bad();}count+=v;}
            const auto bound=static_cast<std::int64_t>(projection.numeric->maximum_absolute_sum);
            if(count!=n.rejected||n.sum_ticks>bound||n.sum_ticks < -bound || (n.valid_heads==0U&&n.sum_ticks!=0)){bad();}
        }else if(n!=NumericTotals{}){bad();}
    };
    check_totals(projection.totals);
    for (std::size_t i=0U; i<value.adoptions.size(); ++i) {
        const auto& adoption=value.adoptions[i];
        if (adoption.from_now || adoption.to!=0U) { bad(); }
        if (i!=0U) {
            const auto& prior=projection.retired_results[i-1U];check_totals(prior);
            if (prior.admissions!=adoption.from) { bad(); }
        }
    }
    if (value.last_ack) {
        if (projection.last_sources.size()!=value.last_ack->through-value.last_ack->from) { bad(); }
        const auto domain=inbound_domain_index_.find({value.selection.issuer,value.selection.scope});
        if (domain==inbound_domain_index_.end() || value.last_ack->through>domain->second.size(true)) { bad(); }
        for (std::size_t i=0U;i<projection.last_sources.size();++i) {
            if (projection.last_sources[i]!=inbound_.at(domain->second.at(static_cast<std::size_t>(value.last_ack->from)+i,true)).record.operation_id) { bad(); }
            if(projection.numeric){
                const auto& source=inbound_.at(domain->second.at(static_cast<std::size_t>(value.last_ack->from)+i,true));
                if(decode_numeric_observation(source.record.payload,*projection.numeric).outcome!=projection.last_outcomes[i]){bad();}
            }
            ++projection_records_visited_;
        }
    } else if (!projection.last_sources.empty()) { bad(); }
    if (!full_replay) { return; }
    // One forward source pass validates all retained rebuild frontiers and the
    // current result. No O(history_count * prefix_length) checkpoint scan.
    std::vector<const ProjectionTotals*> targets;
    for (const auto& prior:projection.retired_results) { targets.push_back(&prior); }
    targets.push_back(&projection.totals);
    std::sort(targets.begin(),targets.end(),[](const auto* a,const auto* b){return a->admissions<b->admissions;});
    auto replay=value;
    replay.projection=initial;
    replay.position=0U;
    for (const auto* target:targets) {
        while (replay.position<target->admissions) {
            ConsumerBatch page;page.from=replay.position;
            page.through=std::min(target->admissions,replay.position+value.selection.maximum_records);
            replay.projection=advance_projection_locked(replay,page);replay.position=page.through;
        }
        if (replay.projection->totals!=*target) { bad(); }
    }
}
} // namespace natrav_overlay
