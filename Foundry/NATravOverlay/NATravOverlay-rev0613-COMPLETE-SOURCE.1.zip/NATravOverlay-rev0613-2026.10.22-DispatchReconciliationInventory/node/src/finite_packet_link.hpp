#pragma once

#include <cstddef>
#include <cstdint>
#include <deque>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace natrav::packet_link {

inline constexpr char kFinitePacketLinkServiceMarker[] =
    "FINITE_PACKET_LINK_SERVICE_V1";
inline constexpr std::size_t kFrameHeaderSize = 40U;
[[nodiscard]] int finite_packet_link_revision_abi() noexcept;

using Bytes = std::vector<std::uint8_t>;

enum class FrameKind : std::uint8_t {
    data = 1U,
    acknowledgement = 2U,
    finish = 3U,
    reset = 4U,
};

struct Frame {
    FrameKind kind{FrameKind::data};
    std::uint64_t stream_id{0U};
    std::uint32_t epoch{0U};
    std::uint32_t sequence{0U};
    std::uint32_t message_id{0U};
    std::uint16_t fragment_index{0U};
    std::uint16_t fragment_count{0U};
    Bytes payload{};

    friend bool operator==(const Frame&, const Frame&) = default;
};

enum class DecodeError : std::uint8_t {
    none = 0U,
    too_short,
    wrong_magic,
    wrong_version,
    noncanonical,
    length_mismatch,
    integrity_failure,
};

struct DecodeResult {
    DecodeError error{DecodeError::none};
    Frame frame{};

    [[nodiscard]] bool ok() const noexcept { return error == DecodeError::none; }
};

class FrameCodec final {
public:
    [[nodiscard]] static Bytes encode(const Frame& frame);
    [[nodiscard]] static DecodeResult decode(std::span<const std::uint8_t> bytes) noexcept;
    [[nodiscard]] static std::uint32_t crc32(std::span<const std::uint8_t> bytes) noexcept;
};

struct Limits {
    std::size_t mtu{256U};
    std::size_t max_message_bytes{64U * 1024U};
    std::size_t max_reassembly_bytes{256U * 1024U};
    std::size_t max_delivery_bytes{256U * 1024U};
    std::size_t max_inflight_frames{64U};
    std::size_t max_control_frames{64U};
    std::size_t max_receive_packets_per_pump{256U};
    std::uint32_t retransmit_after_ticks{3U};
    std::uint32_t retry_limit{8U};
    std::uint64_t message_expiry_ticks{128U};

    void validate() const;
    [[nodiscard]] std::size_t max_payload_bytes() const noexcept {
        return mtu > kFrameHeaderSize ? mtu - kFrameHeaderSize : 0U;
    }
};

class PacketPort {
public:
    virtual ~PacketPort() = default;
    [[nodiscard]] virtual bool send_packet(const Bytes& packet) = 0;
    [[nodiscard]] virtual std::optional<Bytes> receive_packet() = 0;
};

struct StreamStats {
    std::uint64_t accepted_application_bytes{0U};
    std::uint64_t delivered_application_bytes{0U};
    std::uint64_t packets_sent{0U};
    std::uint64_t packets_received{0U};
    std::uint64_t retransmissions{0U};
    std::uint64_t acknowledgements_sent{0U};
    std::uint64_t acknowledgements_received{0U};
    std::uint64_t duplicate_data_packets{0U};
    std::uint64_t malformed_packets{0U};
    std::uint64_t integrity_failures{0U};
    std::uint64_t wrong_stream_packets{0U};
    std::uint64_t backpressure_events{0U};
    std::uint64_t expired_messages{0U};
    std::uint64_t resets_received{0U};

    friend bool operator==(const StreamStats&, const StreamStats&) = default;
};

class FinitePacketStream final {
public:
    FinitePacketStream(PacketPort& port,
                       std::uint64_t stream_id,
                       std::uint32_t epoch,
                       Limits limits = {});

    FinitePacketStream(const FinitePacketStream&) = delete;
    FinitePacketStream& operator=(const FinitePacketStream&) = delete;

    [[nodiscard]] bool queue_message(std::span<const std::uint8_t> message,
                                     std::uint64_t now_tick);
    [[nodiscard]] bool queue_finish(std::uint64_t now_tick);
    void pump(std::uint64_t now_tick);
    [[nodiscard]] std::size_t read_some(std::span<std::uint8_t> destination);

    [[nodiscard]] bool read_eof() const noexcept;
    [[nodiscard]] bool write_finished() const noexcept { return local_finish_queued_; }
    [[nodiscard]] bool write_finish_acknowledged() const noexcept {
        return local_finish_acknowledged_;
    }
    [[nodiscard]] bool failed() const noexcept { return failed_; }
    [[nodiscard]] const std::string& failure_reason() const noexcept { return failure_reason_; }
    [[nodiscard]] const StreamStats& stats() const noexcept { return stats_; }
    [[nodiscard]] std::size_t pending_frames() const noexcept { return outbound_.size(); }
    [[nodiscard]] std::size_t buffered_application_bytes() const noexcept {
        return delivered_bytes_.size();
    }
    [[nodiscard]] std::size_t reassembly_bytes() const noexcept { return reassembly_bytes_; }

private:
    struct OutboundFrame {
        Frame frame{};
        Bytes encoded{};
        std::uint64_t created_tick{0U};
        std::uint64_t last_attempt_tick{0U};
        std::uint32_t attempts{0U};
        bool finish{false};
    };

    struct Reassembly {
        std::uint16_t fragment_count{0U};
        std::vector<std::optional<Bytes>> fragments{};
        std::size_t bytes{0U};
        std::uint64_t created_tick{0U};
    };

    void process_received(std::uint64_t now_tick);
    void process_frame(const Frame& frame, std::uint64_t now_tick);
    void expire_reassembly(std::uint64_t now_tick);
    void send_control_frames();
    void send_due_frames(std::uint64_t now_tick);
    void queue_ack(std::uint32_t sequence);
    void queue_reset();
    void deliver_completed_in_order();
    void fail(std::string reason);
    [[nodiscard]] bool same_link(const Frame& frame) noexcept;

    PacketPort& port_;
    const std::uint64_t stream_id_;
    std::uint32_t epoch_;
    const Limits limits_;
    std::uint64_t last_tick_{0U};
    bool tick_seen_{false};
    std::uint32_t next_tx_sequence_{1U};
    std::uint32_t next_tx_message_{1U};
    std::uint32_t next_rx_message_{1U};
    std::map<std::uint32_t, OutboundFrame> outbound_{};
    std::deque<Frame> control_frames_{};
    std::set<std::uint32_t> queued_ack_sequences_{};
    std::set<std::uint32_t> seen_data_sequences_{};
    std::deque<std::uint32_t> seen_data_order_{};
    std::map<std::uint32_t, Reassembly> reassembly_{};
    std::map<std::uint32_t, Bytes> completed_messages_{};
    std::deque<std::uint8_t> delivered_bytes_{};
    std::size_t reassembly_bytes_{0U};
    bool local_finish_queued_{false};
    bool local_finish_acknowledged_{false};
    std::optional<std::uint32_t> remote_finish_after_message_{};
    bool failed_{false};
    std::string failure_reason_{};
    StreamStats stats_{};
};

enum class Direction : std::uint8_t { a_to_b = 0U, b_to_a = 1U };
enum class FaultAction : std::uint8_t {
    drop = 1U,
    duplicate = 2U,
    corrupt = 3U,
    delay = 4U,
    reorder = 5U,
};

struct FaultRule {
    Direction direction{Direction::a_to_b};
    FaultAction action{FaultAction::drop};
    std::uint64_t ordinal{0U};
    std::uint32_t argument{0U};

    friend bool operator==(const FaultRule&, const FaultRule&) = default;
};

class FaultSchedule final {
public:
    FaultSchedule() = default;
    explicit FaultSchedule(std::vector<FaultRule> rules);
    [[nodiscard]] const std::vector<FaultRule>& rules() const noexcept { return rules_; }
    [[nodiscard]] std::optional<FaultRule> find(Direction direction,
                                                std::uint64_t ordinal) const noexcept;
    [[nodiscard]] Bytes encode() const;
    [[nodiscard]] static std::optional<FaultSchedule> decode(
        std::span<const std::uint8_t> bytes) noexcept;

private:
    std::vector<FaultRule> rules_{};
};

struct TraceEvent {
    Direction direction{Direction::a_to_b};
    std::uint8_t disposition{0U};
    std::uint64_t ordinal{0U};
    std::uint64_t due_tick{0U};
    std::uint32_t packet_size{0U};
    std::uint32_t packet_crc32{0U};

    friend bool operator==(const TraceEvent&, const TraceEvent&) = default;
};

class DeterministicPacketNetwork final {
public:
    class Endpoint final : public PacketPort {
    public:
        Endpoint(DeterministicPacketNetwork& network, bool side_a) noexcept;
        [[nodiscard]] bool send_packet(const Bytes& packet) override;
        [[nodiscard]] std::optional<Bytes> receive_packet() override;

    private:
        DeterministicPacketNetwork& network_;
        bool side_a_;
    };

    explicit DeterministicPacketNetwork(FaultSchedule schedule = {},
                                        std::size_t queue_capacity_packets = 256U,
                                        std::size_t trace_capacity_events = 1'000'000U);
    void advance_to(std::uint64_t tick);
    [[nodiscard]] Endpoint& endpoint_a() noexcept { return endpoint_a_; }
    [[nodiscard]] Endpoint& endpoint_b() noexcept { return endpoint_b_; }
    [[nodiscard]] const std::vector<TraceEvent>& trace() const noexcept { return trace_; }
    [[nodiscard]] Bytes encode_trace() const;
    [[nodiscard]] std::size_t queued_packets() const noexcept;

private:
    struct ScheduledPacket {
        Direction direction{Direction::a_to_b};
        std::uint64_t due_tick{0U};
        std::uint64_t insertion_order{0U};
        Bytes bytes{};
    };

    [[nodiscard]] bool send(bool from_a, const Bytes& packet);
    [[nodiscard]] std::optional<Bytes> receive(bool for_a);
    void enqueue(Direction direction, Bytes packet, std::uint64_t due_tick,
                 std::uint8_t disposition, std::uint64_t ordinal);
    void record_trace(TraceEvent event);
    void release_due();

    FaultSchedule schedule_{};
    std::size_t capacity_{0U};
    std::size_t trace_capacity_{0U};
    std::uint64_t now_tick_{0U};
    std::uint64_t insertion_counter_{0U};
    std::uint64_t a_to_b_ordinal_{0U};
    std::uint64_t b_to_a_ordinal_{0U};
    std::vector<ScheduledPacket> scheduled_{};
    std::deque<Bytes> ready_for_a_{};
    std::deque<Bytes> ready_for_b_{};
    std::optional<ScheduledPacket> held_a_to_b_{};
    std::optional<ScheduledPacket> held_b_to_a_{};
    std::vector<TraceEvent> trace_{};
    Endpoint endpoint_a_;
    Endpoint endpoint_b_;
};

}  // namespace natrav::packet_link
