#pragma once

#include "socket.hpp"

#include <cstdint>
#include <memory>
#include <string>
#include <string_view>

namespace natrav_overlay {

enum class TransportKind : std::uint8_t {
    tcp = 1U,
    serial = 2U,
    udp = 3U,
    unix_datagram = 4U,
    adapter = 5U,
    // Internal packet-link and deterministic test carriers. They are
    // deliberately absent from parse_transport_kind() and all normal
    // route/listener configuration.
    packet_link = 254U,
    virtual_link = 255U,
};

struct TcpTransportLocator final {
    std::string host;
    std::uint16_t service{0U};
};

enum class SerialParity : std::uint8_t {
    none = 1U,
    even = 2U,
    odd = 3U,
};

enum class SerialFlowControl : std::uint8_t {
    none = 1U,
    software = 2U,
    hardware = 3U,
};

struct SerialTransportLocator final {
    std::string path;
    std::uint32_t baud{115'200U};
    std::uint8_t data_bits{8U};
    SerialParity parity{SerialParity::none};
    std::uint8_t stop_bits{1U};
    SerialFlowControl flow_control{SerialFlowControl::none};
};

struct UdpTransportEndpoint final {
    std::string host;
    std::uint16_t service{0U};
};

struct UdpTransportLocator final {
    UdpTransportEndpoint local;
    UdpTransportEndpoint remote;
    std::uint16_t mtu{1200U};
    std::uint64_t link_id{0U};
    std::uint32_t epoch{1U};
    std::uint8_t profile{1U};
};

struct UnixDatagramTransportLocator final {
    std::string local_path;
    std::string remote_path;
    std::uint16_t mtu{1200U};
    std::uint64_t link_id{0U};
    std::uint32_t epoch{1U};
    std::uint8_t profile{1U};
};

struct AdapterEndpointTransportLocator final {
    std::string endpoint_id;
    std::uint64_t generation{0U};
};

struct TransportLocator final {
    TransportKind kind{TransportKind::tcp};
    TcpTransportLocator tcp;
    SerialTransportLocator serial;
    UdpTransportLocator udp;
    UnixDatagramTransportLocator unix_datagram;
    AdapterEndpointTransportLocator adapter{};
};

struct TransportCapabilities final {
    bool reliable_stream{true};
    bool ordered{true};
    bool full_duplex{true};
    bool can_dial{true};
    bool can_listen{true};
    bool can_shutdown_write{true};
};

[[nodiscard]] TransportKind parse_transport_kind(std::string_view text);
[[nodiscard]] std::string_view transport_kind_name(TransportKind kind);
[[nodiscard]] TransportCapabilities transport_capabilities(TransportKind kind);
[[nodiscard]] TransportLocator parse_transport_locator(
    TransportKind kind,
    std::string_view text,
    bool allow_zero_service);
[[nodiscard]] TransportLocator parse_tcp_transport_locator(
    std::string_view text,
    bool allow_zero_service);
[[nodiscard]] TransportLocator parse_serial_transport_locator(
    std::string_view text);
[[nodiscard]] TransportLocator parse_udp_transport_locator(
    std::string_view text);
[[nodiscard]] TransportLocator parse_unix_datagram_transport_locator(
    std::string_view text);
// Configuration locators retain the predecessor TCP spelling. A locator that
// begins with the exact self-describing `serial-v1|`, `udp-v1|`, or
// `unix-dgram-v1|` or `adapter-endpoint-v1|` prefix is parsed as that carrier;
// every other value remains the predecessor numeric TCP form.
[[nodiscard]] TransportLocator parse_adapter_endpoint_transport_locator(std::string_view text);
[[nodiscard]] TransportLocator parse_configured_transport_locator(
    std::string_view text,
    bool allow_zero_service);
[[nodiscard]] std::string transport_locator_text(
    const TransportLocator& locator);
[[nodiscard]] const TcpTransportLocator& tcp_transport_locator(
    const TransportLocator& locator);
[[nodiscard]] const SerialTransportLocator& serial_transport_locator(
    const TransportLocator& locator);
[[nodiscard]] const UdpTransportLocator& udp_transport_locator(
    const TransportLocator& locator);
[[nodiscard]] const UnixDatagramTransportLocator& unix_datagram_transport_locator(
    const TransportLocator& locator);

// OrderedByteStream is the carrier-neutral ownership boundary used by the
// peer stack. TLS consumes the inherited ByteChannel contract directly; no
// native descriptor is exposed above the concrete transport implementation.
class OrderedByteStream : public ByteChannel {
public:
    ~OrderedByteStream() override = default;
    OrderedByteStream(const OrderedByteStream&) = delete;
    OrderedByteStream& operator=(const OrderedByteStream&) = delete;

    [[nodiscard]] virtual TransportKind transport_kind() const noexcept = 0;
    virtual void shutdown_write() = 0;

protected:
    OrderedByteStream() = default;
};

class TransportConnector {
public:
    virtual ~TransportConnector() = default;
    TransportConnector(const TransportConnector&) = delete;
    TransportConnector& operator=(const TransportConnector&) = delete;

    [[nodiscard]] virtual std::unique_ptr<OrderedByteStream> connect(
        const TransportLocator& locator,
        Deadline deadline,
        IoCounters& counters) const = 0;

protected:
    TransportConnector() = default;
};

class TransportListener {
public:
    virtual ~TransportListener() = default;
    TransportListener(const TransportListener&) = delete;
    TransportListener& operator=(const TransportListener&) = delete;

    [[nodiscard]] virtual TransportKind transport_kind() const noexcept = 0;
    [[nodiscard]] virtual int readiness_handle() const noexcept = 0;
    [[nodiscard]] virtual TransportLocator bound_locator() const = 0;

    // Returns null when the nonblocking listener has been drained. Any other
    // failure is reported through the existing ACCEPT_FAILED classification.
    [[nodiscard]] virtual std::unique_ptr<OrderedByteStream> accept_ready() = 0;

protected:
    TransportListener() = default;
};

[[nodiscard]] const TransportConnector& transport_connector(
    TransportKind kind);
[[nodiscard]] std::unique_ptr<OrderedByteStream> connect_transport(
    const TransportLocator& locator,
    Deadline deadline,
    IoCounters& counters);
[[nodiscard]] std::unique_ptr<TransportListener> listen_transport(
    const TransportLocator& locator,
    int backlog);

}  // namespace natrav_overlay
