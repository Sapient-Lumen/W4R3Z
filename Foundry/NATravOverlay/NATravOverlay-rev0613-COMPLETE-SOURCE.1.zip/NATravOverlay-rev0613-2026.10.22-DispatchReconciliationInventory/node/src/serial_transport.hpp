#pragma once

#include "transport.hpp"

#include <memory>
#include <string>
#include <string_view>

namespace natrav_overlay {

[[nodiscard]] std::string_view serial_parity_name(SerialParity parity);
[[nodiscard]] std::string_view serial_flow_control_name(
    SerialFlowControl flow_control);
[[nodiscard]] std::string serial_transport_locator_text(
    const SerialTransportLocator& locator);

// Stronger no-follow path and cooperative lease for the pinned packet role.
[[nodiscard]] std::unique_ptr<OrderedByteStream> open_serial_packet_stream(
    const SerialTransportLocator& locator, Deadline deadline);

[[nodiscard]] const TransportConnector& serial_transport_connector();
[[nodiscard]] std::unique_ptr<TransportListener> listen_serial_transport(
    const TransportLocator& locator,
    int backlog);

}  // namespace natrav_overlay
