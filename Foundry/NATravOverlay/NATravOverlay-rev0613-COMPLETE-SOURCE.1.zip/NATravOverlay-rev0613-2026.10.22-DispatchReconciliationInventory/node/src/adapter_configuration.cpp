#include "adapter_configuration.hpp"
#include "common.hpp"
#include <algorithm>
#include <cstdint>
#include <tuple>

namespace natrav_overlay {
namespace {
inline constexpr std::size_t kMaximumEmbeddedRecordBytes = 32'768U;
[[nodiscard]] std::uint8_t nibble(const char value) {
    if (value >= '0' && value <= '9') { return static_cast<std::uint8_t>(value - '0'); }
    if (value >= 'a' && value <= 'f') { return static_cast<std::uint8_t>(value - 'a' + 10); }
    app_fail("CONFIG_ADAPTER_RECORD_NONCANONICAL", "expected lowercase hexadecimal record");
}
template <typename Function>
auto profile_errors(Function&& function) -> decltype(function()) {
    try { return function(); }
    catch (const AdapterProfileError& error) { app_fail(error.code(), "adapter profile policy rejected"); }
    catch (const AdapterCatalogError& error) { app_fail(error.code(), "adapter endpoint policy rejected"); }
}
}  // namespace
std::string adapter_configuration_record_hex(const std::string_view record) {
    if (record.empty() || record.size() > kMaximumEmbeddedRecordBytes) {
        app_fail("CONFIG_ADAPTER_RECORD_TOO_LARGE", "embedded record byte limit");
    }
    return hex_bytes(datacube::OctetView(
        reinterpret_cast<const std::uint8_t*>(record.data()), record.size()));
}
std::string decode_adapter_configuration_record_hex(const std::string_view hex) {
    if (hex.empty() || hex.size() > kMaximumEmbeddedRecordBytes * 2U || hex.size() % 2U != 0U) {
        app_fail("CONFIG_ADAPTER_RECORD_INVALID", "embedded record length");
    }
    std::string record;
    record.reserve(hex.size() / 2U);
    for (std::size_t i = 0U; i < hex.size(); i += 2U) {
        const auto byte = static_cast<std::uint8_t>(
            static_cast<unsigned int>(nibble(hex[i])) * 16U + nibble(hex[i + 1U]));
        if (byte == 0U || byte > 127U) {
            app_fail("CONFIG_ADAPTER_RECORD_NONCANONICAL", "canonical records contain ASCII without NUL");
        }
        record.push_back(static_cast<char>(byte));
    }
    return record;
}
OperatorPinnedAdapterProfile parse_runtime_adapter_profile(const std::string_view hex) {
    return profile_errors([&] {
        return parse_operator_pinned_adapter_profile(decode_adapter_configuration_record_hex(hex));
    });
}
ConfiguredAdapterEndpoint parse_runtime_adapter_endpoint(const std::string_view hex) {
    return profile_errors([&] {
        return parse_configured_adapter_endpoint(decode_adapter_configuration_record_hex(hex));
    });
}
void normalize_runtime_adapter_configuration(RuntimeAdapterConfiguration& configuration) {
    if (configuration.profiles.size() > kMaximumRuntimeAdapterProfiles ||
        configuration.endpoints.size() > kMaximumRuntimeAdapterEndpoints) {
        app_fail("CONFIG_ADAPTER_CAPACITY", "at most 64 retained profiles and 64 retained endpoints");
    }
    profile_errors([&] {
        auto& profiles = configuration.profiles;
        auto& endpoints = configuration.endpoints;
        std::sort(profiles.begin(), profiles.end(), [](const auto& a, const auto& b) {
            return std::tie(a.profile_id, a.generation) < std::tie(b.profile_id, b.generation);
        });
        std::sort(endpoints.begin(), endpoints.end(), [](const auto& a, const auto& b) {
            return std::tie(a.endpoint_id, a.generation) < std::tie(b.endpoint_id, b.generation);
        });
        const OperatorPinnedAdapterProfile* previous_profile = nullptr;
        for (const auto& profile : profiles) {
            if (previous_profile != nullptr && previous_profile->profile_id != profile.profile_id) {
                previous_profile = nullptr;
            }
            if (previous_profile != nullptr && previous_profile->generation == profile.generation) {
                app_fail("CONFIG_ADAPTER_DUPLICATE_GENERATION", "duplicate profile generation");
            }
            validate_operator_pinned_adapter_profile_transition(previous_profile, profile);
            previous_profile = &profile;
        }
        const ConfiguredAdapterEndpoint* previous_endpoint = nullptr;
        for (const auto& endpoint : endpoints) {
            if (previous_endpoint != nullptr && previous_endpoint->endpoint_id != endpoint.endpoint_id) {
                previous_endpoint = nullptr;
            }
            if (previous_endpoint != nullptr && previous_endpoint->generation == endpoint.generation) {
                app_fail("CONFIG_ADAPTER_DUPLICATE_GENERATION", "duplicate endpoint generation");
            }
            validate_configured_adapter_endpoint_transition(previous_endpoint, endpoint);
            const auto& profile = resolve_adapter_profile(profiles, endpoint.locator);
            if (operator_pinned_adapter_profile_sha256(profile) != endpoint.profile_sha256) {
                app_fail("CONFIG_ADAPTER_PROFILE_DIGEST_MISMATCH", "endpoint must bind its exact retained profile");
            }
            previous_endpoint = &endpoint;
        }
    });
}
void require_runtime_adapter_history_preserved(
    const RuntimeAdapterConfiguration& historical,
    const RuntimeAdapterConfiguration& candidate) {
    // Every accepted generation remains immutable, including during explicit
    // rollback. Rejected proposals do not reserve an identity or generation.
    for (const auto& prior : historical.profiles) {
        const auto found = std::find_if(candidate.profiles.begin(), candidate.profiles.end(),
            [&](const auto& item) {
                return item.profile_id == prior.profile_id && item.generation == prior.generation;
            });
        if (found == candidate.profiles.end()) {
            app_fail("CONFIG_ADAPTER_HISTORY_REMOVED", "accepted profile history must be retained");
        }
        if (*found != prior) {
            app_fail("CONFIG_ADAPTER_GENERATION_CONFLICT", "accepted profile generation is immutable");
        }
    }
    for (const auto& prior : historical.endpoints) {
        const auto found = std::find_if(candidate.endpoints.begin(), candidate.endpoints.end(),
            [&](const auto& item) {
                return item.endpoint_id == prior.endpoint_id && item.generation == prior.generation;
            });
        if (found == candidate.endpoints.end()) {
            app_fail("CONFIG_ADAPTER_HISTORY_REMOVED", "accepted endpoint history must be retained");
        }
        if (*found != prior) {
            app_fail("CONFIG_ADAPTER_GENERATION_CONFLICT", "accepted endpoint generation is immutable");
        }
    }
}
ResolvedConfiguredAdapterEndpoint resolve_runtime_adapter_endpoint(
    const RuntimeAdapterConfiguration& configuration,
    const TransportLocator& locator, const AdapterEndpointRole role) {
    if (locator.kind != TransportKind::adapter) {
        app_fail("ADAPTER_ENDPOINT_LOCATOR_INVALID", "not an adapter endpoint reference");
    }
    // Enforce finite input and independently validate retained exact history.
    auto policy = configuration;
    normalize_runtime_adapter_configuration(policy);
    const auto found = std::find_if(policy.endpoints.begin(), policy.endpoints.end(),
        [&](const auto& endpoint) {
            return endpoint.endpoint_id == locator.adapter.endpoint_id &&
                endpoint.generation == locator.adapter.generation;
        });
    if (found == policy.endpoints.end()) {
        app_fail("CONFIG_ADAPTER_ENDPOINT_NOT_FOUND", "exact retained endpoint generation is absent");
    }
    if (found->role != role) {
        app_fail("CONFIG_ADAPTER_ENDPOINT_ROLE", "endpoint role does not match its configured use");
    }
    return profile_errors([&] {
        const auto& profile = resolve_adapter_profile(policy.profiles, found->locator);
        const auto digest = operator_pinned_adapter_profile_sha256(profile);
        if (digest != found->profile_sha256) {
            app_fail("CONFIG_ADAPTER_PROFILE_DIGEST_MISMATCH", "exact profile digest mismatch");
        }
        return ResolvedConfiguredAdapterEndpoint{*found, profile, digest,
            configured_adapter_endpoint_sha256(*found)};
    });
}
std::string runtime_adapter_configuration_json(const RuntimeAdapterConfiguration& configuration) {
    // Commitments only: do not expose executable paths or argument vectors.
    std::string out = "{\"format\":\"V19_DURABLE_ADAPTER_CONFIGURATION_V1\","
        "\"configured_transport_enabled\":true,\"profiles\":[";
    bool first = true;
    for (const auto& profile : configuration.profiles) {
        if (!first) { out += ','; } first = false;
        out += "{\"id\":" + json_string(profile.profile_id) +
            ",\"generation\":" + std::to_string(profile.generation) +
            ",\"sha256\":" + json_string(adapter_sha256_hex(operator_pinned_adapter_profile_sha256(profile))) + "}";
    }
    out += "],\"endpoints\":["; first = true;
    for (const auto& endpoint : configuration.endpoints) {
        if (!first) { out += ','; } first = false;
        out += "{\"id\":" + json_string(endpoint.endpoint_id) +
            ",\"generation\":" + std::to_string(endpoint.generation) +
            ",\"sha256\":" + json_string(adapter_sha256_hex(configured_adapter_endpoint_sha256(endpoint))) +
            ",\"profile_sha256\":" + json_string(adapter_sha256_hex(endpoint.profile_sha256)) + "}";
    }
    return out + "]}";
}
}  // namespace natrav_overlay
