#pragma once
#include "common.hpp"
namespace natrav_overlay {
class NodeState;
struct RuntimeConfig;
struct HandoffLocalKey;
struct HandoffImportResult final {
    std::string status;
    datacube::Digest32 capsule_id;
    datacube::Digest32 operation_id;
    std::string kind;
};
struct HandoffCommand final {
    std::string command;
    std::filesystem::path config, key_directory, recipient_binding, input, output;
    std::string generation, kind;
    datacube::Digest32 operation{}, recipient_binding_digest{};
    std::uint64_t expires_ms{0U};
};
[[nodiscard]] HandoffImportResult import_handoff_capsule(
    NodeState& state, const RuntimeConfig& config,
    const HandoffLocalKey& local, datacube::OctetView encoded,
    std::uint64_t now_ms);
[[nodiscard]] std::string handoff_import_result_json(
    const HandoffImportResult& result);
[[nodiscard]] std::string run_handoff_command(const HandoffCommand& options);
} // namespace natrav_overlay
