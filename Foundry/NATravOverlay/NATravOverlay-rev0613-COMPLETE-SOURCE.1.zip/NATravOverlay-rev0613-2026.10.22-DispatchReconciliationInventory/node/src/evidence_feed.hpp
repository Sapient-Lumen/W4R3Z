#pragma once
#include "evidence_query.hpp"

namespace natrav_overlay {
// Observational, append-only polling. No server cursor table or delivery ACK.
// New callers explicitly adopt either all retained history or the current tail.
struct EvidenceFeedSlice final {
    std::string rows;
    std::uint64_t next{0U}, total{0U};
    std::size_t count{0U}, visited{0U};
};
struct EvidenceFeed final {
    bool from_now{false};
    bool include_payload{false};
    std::string issuer;
    std::string scope;
    std::uint32_t maximum_records{32U};
    std::uint32_t maximum_response_bytes{60'000U};
    std::uint32_t payload_length{0U};
    std::string cursor;
};
void validate_evidence_feed(const EvidenceFeed& feed);
[[nodiscard]] datacube::Octets encode_evidence_feed(const EvidenceFeed& feed);
[[nodiscard]] EvidenceFeed decode_evidence_feed(datacube::OctetView bytes);
} // namespace natrav_overlay
