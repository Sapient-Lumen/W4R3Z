#pragma once

#include "socket.hpp"

#include <cstdint>
#include <filesystem>
#include <memory>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

struct TlsIdentityFiles final {
    std::filesystem::path certificate;
    std::filesystem::path private_key;
    datacube::Digest32 expected_spki_sha256;
};

enum class KeyGenerationState : std::uint8_t {
    active = 1U,
    retired = 2U,
    revoked = 3U,
};

struct TlsTrustedGeneration final {
    std::string generation;
    datacube::Digest32 spki_sha256;
    KeyGenerationState state{KeyGenerationState::retired};
};

struct TlsTrustedIdentity final {
    std::string node_id;
    std::vector<TlsTrustedGeneration> generations;
};

struct TlsSessionInfo final {
    std::string peer_node;
    std::string peer_generation;
    KeyGenerationState peer_key_state{KeyGenerationState::retired};
    datacube::Digest32 peer_spki_sha256;
    datacube::Digest32 peer_certificate_sha256;
    std::string protocol;
    std::string cipher;
};

[[nodiscard]] datacube::Digest32 parse_spki_sha256(std::string_view value);
[[nodiscard]] std::string spki_sha256_text(const datacube::Digest32& value);
[[nodiscard]] bool spki_sha256_is_zero(
    const datacube::Digest32& value) noexcept;
[[nodiscard]] datacube::Digest32 tls_certificate_sha256(
    const std::filesystem::path& certificate_file);
[[nodiscard]] std::string_view key_generation_state_name(
    KeyGenerationState state) noexcept;

class TlsContext final {
public:
    explicit TlsContext(const TlsIdentityFiles& identity);
    ~TlsContext();

    TlsContext(const TlsContext&) = delete;
    TlsContext& operator=(const TlsContext&) = delete;
    TlsContext(TlsContext&&) noexcept;
    TlsContext& operator=(TlsContext&&) noexcept;

    [[nodiscard]] const datacube::Digest32& identity_spki_sha256() const noexcept;

private:
    struct State;
    std::unique_ptr<State> state_;
    friend class TlsChannel;
};

class TlsChannel final : public ByteChannel {
public:
    ~TlsChannel() override;
    TlsChannel(const TlsChannel&) = delete;
    TlsChannel& operator=(const TlsChannel&) = delete;
    TlsChannel(TlsChannel&&) noexcept;
    TlsChannel& operator=(TlsChannel&&) noexcept;

    [[nodiscard]] static TlsChannel connect(
        TlsContext& context,
        ByteChannel& channel,
        std::string_view expected_peer_node,
        std::string_view expected_peer_generation,
        KeyGenerationState expected_peer_key_state,
        const datacube::Digest32& expected_peer_spki_sha256,
        Deadline deadline,
        IoCounters& counters);

    [[nodiscard]] static TlsChannel accept(
        TlsContext& context,
        ByteChannel& channel,
        const std::vector<TlsTrustedIdentity>& trusted_peers,
        Deadline deadline,
        IoCounters& counters);

    [[nodiscard]] const TlsSessionInfo& session() const noexcept;

    [[nodiscard]] std::size_t read_some(
        std::span<std::uint8_t> buffer,
        Deadline deadline,
        IoCounters& counters,
        std::string_view operation) override;
    [[nodiscard]] std::size_t write_some(
        datacube::OctetView bytes,
        Deadline deadline,
        IoCounters& counters,
        std::string_view operation) override;

    void close_notify(Deadline deadline, IoCounters& counters) noexcept;

private:
    struct State;
    explicit TlsChannel(std::unique_ptr<State> state) noexcept;
    std::unique_ptr<State> state_;
};

[[nodiscard]] std::string tls_session_json(const TlsSessionInfo& session);

}  // namespace natrav_overlay
