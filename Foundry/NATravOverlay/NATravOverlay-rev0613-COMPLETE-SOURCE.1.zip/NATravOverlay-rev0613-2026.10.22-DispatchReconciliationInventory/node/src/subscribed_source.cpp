#include "subscribed_source.hpp"
#include "config.hpp"
#include "journal.hpp"

#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <limits>
#include <mutex>
#include <set>
#include <thread>
#include <tuple>

namespace natrav_overlay {
namespace {
using Bytes = datacube::Octets;
using View = datacube::OctetView;
using Digest = datacube::Digest32;
void require(bool ok, std::string_view code, std::string_view detail) {
    if (!ok) { app_fail(std::string(code), std::string(detail)); }
}
void text(Bytes& b, std::string_view s) {
    require(s.size() <= 256U, "SOURCE_VIEW_INVALID", "bounded text required");
    datacube::append_be16(b, static_cast<std::uint16_t>(s.size())); datacube::append_text(b, s);
}
std::string text(datacube::Reader& r, std::size_t maximum = 64U) {
    const auto n = r.read_be16("source view text length");
    require(n <= maximum, "SOURCE_VIEW_INVALID", "text exceeds bound");
    return datacube::octets_text(r.read_exact(n, "source view text"), "source view text", true);
}
Digest digest(datacube::Reader& r) {
    Digest d{}; const auto b = r.read_exact(32U, "source view digest");
    std::copy(b.begin(), b.end(), d.octets.begin()); return d;
}
void digest(Bytes& b, const Digest& d) { datacube::append_octets(b, d.octets); }
std::optional<Digest> optional_digest(datacube::Reader& r) {
    const auto m = r.read_u8("source view optional digest");
    require(m <= 1U, "SOURCE_VIEW_INVALID", "invalid optional marker");
    return m ? std::optional<Digest>(digest(r)) : std::nullopt;
}
void optional_digest(Bytes& b, const std::optional<Digest>& d) {
    datacube::append_u8(b, d ? 1U : 0U); if (d) { digest(b, *d); }
}
Digest hash(std::string_view domain, View value) {
    Bytes b; datacube::append_text(b, domain); datacube::append_u8(b, 0U);
    datacube::append_octets(b, value); return datacube::sha256(b);
}
Digest hash_text(std::string_view domain, std::string_view value) {
    Bytes b; datacube::append_text(b, value); return hash(domain, b);
}
std::vector<std::string> split(std::string_view s) {
    std::vector<std::string> result; std::size_t start = 0U;
    for (;;) {
        const auto at = s.find(',', start); result.emplace_back(s.substr(start, at - start));
        if (at == std::string_view::npos) { break; } start = at + 1U;
    }
    return result;
}
std::uint64_t number(const std::string& s, std::uint64_t low, std::uint64_t high) {
    const auto n = parse_u64(s, "source view number", low, high);
    require(s == std::to_string(n), "CONFIG_SOURCE_VIEW_INVALID", "canonical decimal required"); return n;
}
struct Envelope final {
    std::string grant, recipient, generation;
    Digest instance{}, rule{}, pin{}, source_digest{}, operation{};
    std::uint64_t ordinal{0U}, authored{0U};
    std::uint32_t author_uid{0U};
    std::optional<Digest> mapped_parent, lineage;
    EvidenceRecord source;
};
Envelope envelope(View bytes) {
    require(bytes.size() <= kMaximumEvidencePayloadBytes, "SOURCE_VIEW_ENVELOPE_INVALID", "envelope exceeds ordinary evidence bound");
    datacube::Reader r(bytes, "source view envelope");
    const auto version = datacube::octets_text(r.read_exact(4U, "NSE version"), "NSE version", true);
    require(version == "NSE1" || version == "NSE2", "SOURCE_VIEW_ENVELOPE_INVALID", "only NSE1 and NSE2 supported");
    Envelope e; e.grant = text(r); e.instance = digest(r); e.rule = digest(r);
    e.recipient = text(r); e.generation = text(r); e.pin = digest(r);
    e.ordinal = r.read_be64("source ordinal"); e.author_uid = r.read_be32("claimed author UID");
    e.authored = r.read_be64("claimed author time"); e.source_digest = digest(r);
    e.mapped_parent = optional_digest(r);
    const auto n = r.read_be32("embedded source bytes");
    require(n <= kMaximumEvidencePayloadBytes, "SOURCE_VIEW_ENVELOPE_INVALID", "embedded source bound");
    const auto message = decode_application_message(r.read_exact(n, "embedded source"));
    const auto* source = std::get_if<EvidenceRecord>(&message);
    require(source != nullptr, "SOURCE_VIEW_ENVELOPE_INVALID", "embedded evidence required"); e.source = *source;
    std::uint64_t inherited = 0U;
    if (version == "NSE2") {
        const auto suffix = bytes.last(r.remaining());
        const auto prior_grant = text(r), prior_lease = text(r);
        const auto prior_instance = digest(r), prior_state = digest(r), mapping = digest(r);
        inherited = r.read_be64("inherited frontier");
        require(valid_generation_id(prior_grant) && valid_generation_id(prior_lease) && prior_grant != e.grant &&
            !digest_is_zero(prior_instance) && !digest_is_zero(prior_state) && !digest_is_zero(mapping) && inherited <= 8192U,
            "SOURCE_VIEW_ENVELOPE_INVALID", "invalid succession lineage");
        e.lineage = hash("NATRAV_OVERLAY_SOURCE_VIEW_LINEAGE_V1", suffix);
    }
    r.require_eof("source view envelope");
    require(valid_generation_id(e.grant) && !digest_is_zero(e.instance) && !digest_is_zero(e.rule) &&
        valid_node_id(e.recipient) && valid_generation_id(e.generation) && !digest_is_zero(e.pin) &&
        e.ordinal > inherited && e.ordinal - inherited <= 128U && e.authored != 0U &&
        e.source.issuer == e.source.recipient && e.source.issuer != e.recipient &&
        !e.source.scope.starts_with("actions/") && e.source.corrects.has_value() == e.mapped_parent.has_value() &&
        (!e.mapped_parent || !digest_is_zero(*e.mapped_parent)) && evidence_record_digest(e.source) == e.source_digest,
        "SOURCE_VIEW_ENVELOPE_INVALID", "source structure or digest mismatch");
    e.operation = hash(version == "NSE1" ? "NATRAV_OVERLAY_SOURCE_DELIVERY_V1" : "NATRAV_OVERLAY_SOURCE_DELIVERY_V2", bytes);
    return e;
}
Digest materialized_id(const SourceViewRule& rule, const Digest& source_operation) {
    Bytes b; digest(b, rule.digest); digest(b, source_operation);
    return hash("NATRAV_OVERLAY_SOURCE_VIEW_OPERATION_V1", b);
}
void boundary(const char* name) {
    if (const auto* v = std::getenv(name)) {
        const auto ms = parse_u64(v, "source view test pause", 1U, 30000U);
        std::this_thread::sleep_for(std::chrono::milliseconds(ms));
    }
}
} // namespace

std::string source_view_rule_text(const SourceViewRule& r) {
    return r.id + "," + std::to_string(r.uid) + "," + r.provider + "," + r.generation + "," +
        std::to_string(r.author_uid) + "," + r.source_scope + "," + r.target_scope + "," +
        std::to_string(r.maximum_records) + "," + std::to_string(r.maximum_payload_bytes);
}
std::string source_view_binding_text(const SourceViewBinding& b) {
    return b.view + "," + b.grant + "," + datacube::hex_lower(b.instance) + "," + datacube::hex_lower(b.grant_digest) + "," +
        (b.lineage_digest ? datacube::hex_lower(*b.lineage_digest) : "-");
}
SourceViewPolicy make_source_view_policy(const std::vector<std::string>& rules,
    const std::vector<std::string>& bindings, const RuntimeConfig& config) {
    SourceViewPolicy p;
    const bool has_class = std::any_of(config.local_control.grants.begin(), config.local_control.grants.end(), [&](const auto& g) {
        return local_control_allows(config.local_control, g.uid, LocalControlClass::source_import);
    });
    require(config.format_version >= 17U || (rules.empty() && bindings.empty() && !has_class),
        "CONFIG_VERSION_REJECTED", "SOURCE_IMPORT and source_view require V17");
    require(rules.size() <= 32U && bindings.size() <= 256U, "CONFIG_SOURCE_VIEW_LIMIT", "32 views and 256 exact bindings maximum");
    std::set<std::string> ids; std::set<std::pair<std::string,std::string>> domains;
    std::set<std::uint32_t> managers;
    for (const auto& line : rules) {
        const auto f = split(line);
        require(f.size() == 9U, "CONFIG_SOURCE_VIEW_INVALID", "id,manager UID,provider,generation,author UID,source scope,target scope,records,bytes required");
        SourceViewRule g{.id=f[0], .uid=static_cast<std::uint32_t>(number(f[1],0U,UINT32_MAX)),
            .provider=f[2], .generation=f[3], .author_uid=static_cast<std::uint32_t>(number(f[4],0U,UINT32_MAX)),
            .source_scope=f[5], .target_scope=f[6], .maximum_records=static_cast<std::uint32_t>(number(f[7],1U,65536U)),
            .maximum_payload_bytes=number(f[8],1U,67108864U), .digest={}};
        require(valid_generation_id(g.id) && valid_node_id(g.provider) && g.provider != config.local_node &&
            valid_generation_id(g.generation) && valid_scope(g.source_scope) && valid_scope(g.target_scope) &&
            g.source_scope != g.target_scope && !g.source_scope.starts_with("actions/") && !g.target_scope.starts_with("actions/"),
            "CONFIG_SOURCE_VIEW_INVALID", "exact provider and distinct non-action scopes required");
        require(ids.insert(g.id).second && domains.emplace(g.provider,g.target_scope).second,
            "CONFIG_SOURCE_VIEW_DUPLICATE", "view ID and target domain must be unique");
        require(local_control_allows(config.local_control,g.uid,LocalControlClass::source_import),
            "CONFIG_SOURCE_VIEW_CLASS_REQUIRED", "manager requires explicit SOURCE_IMPORT");
        require(find_peer_generation(config,g.provider,g.generation) != nullptr,
            "CONFIG_SOURCE_VIEW_KEY_REQUIRED", "view provider must have a configured exact key generation");
        g.digest=hash_text("NATRAV_OVERLAY_SOURCE_VIEW_RULE_V1",source_view_rule_text(g));
        managers.insert(g.uid); p.rules.push_back(std::move(g));
    }
    std::set<std::pair<std::string,std::string>> seen; std::set<std::string> bound;
    for (const auto& line : bindings) {
        const auto f=split(line);
        require(f.size()==5U && ids.contains(f[0]) && valid_generation_id(f[1]),
            "CONFIG_SOURCE_VIEW_BINDING_INVALID", "view,grant,instance,grant digest,lineage digest or - required");
        SourceViewBinding b{.view=f[0], .grant=f[1], .instance=parse_operation_id(f[2]),
            .grant_digest=parse_operation_id(f[3]), .lineage_digest=std::nullopt, .digest={}};
        if (f[4] != "-") { b.lineage_digest=parse_operation_id(f[4]); }
        require(seen.emplace(b.view,b.grant).second, "CONFIG_SOURCE_VIEW_DUPLICATE", "one binding per view/grant");
        b.digest=hash_text("NATRAV_OVERLAY_SOURCE_VIEW_BINDING_V1",source_view_binding_text(b));
        bound.insert(b.view); p.bindings.push_back(std::move(b));
    }
    for (const auto& g:p.rules) {
        require(bound.contains(g.id),"CONFIG_SOURCE_VIEW_BINDING_REQUIRED","each view requires an exact subscription binding");
        for (const auto& other:p.rules) {
            require(g.provider != other.provider || g.target_scope != other.source_scope,
                "CONFIG_SOURCE_VIEW_SCOPE_COLLISION","materialized scopes cannot also be envelope source scopes");
        }
    }
    for (const auto& g:config.local_control.grants) {
        require(!local_control_allows(config.local_control,g.uid,LocalControlClass::source_import) || managers.contains(g.uid),
            "CONFIG_SOURCE_VIEW_DOMAIN_REQUIRED","import principal requires an exact view");
    }
    std::sort(p.rules.begin(),p.rules.end(),[](const auto& a,const auto& b){return a.id<b.id;});
    std::sort(p.bindings.begin(),p.bindings.end(),[](const auto& a,const auto& b){return std::tie(a.view,a.grant)<std::tie(b.view,b.grant);});
    return p;
}
std::string source_view_policy_json(const SourceViewPolicy& p) {
    std::string out="{\"format\":\"NATRAV_OVERLAY_SOURCE_VIEW_POLICY_V1\",\"views\":[";
    for (std::size_t i=0U;i<p.rules.size();++i) {
        if (i) { out+=','; } const auto& r=p.rules[i];
        out+="{\"id\":"+json_string(r.id)+",\"rule\":"+json_string(source_view_rule_text(r))+",\"digest\":"+json_string(datacube::hex_lower(r.digest))+"}";
    }
    out+="],\"bindings\":[";
    for (std::size_t i=0U;i<p.bindings.size();++i) {
        if(i){out+=',';} const auto& b=p.bindings[i];
        out+="{\"binding\":"+json_string(source_view_binding_text(b))+",\"digest\":"+json_string(datacube::hex_lower(b.digest))+"}";
    }
    return out+"]}";
}
Bytes encode_source_view_request(const SourceViewRequest& q) {
    require(valid_generation_id(q.view) && !digest_is_zero(q.operation),"SOURCE_VIEW_INVALID","exact view and outer operation required");
    Bytes b; datacube::append_text(b,"NVI1");text(b,q.view);digest(b,q.operation);return b;
}
SourceViewRequest decode_source_view_request(View b) {
    datacube::Reader r(b,"source import request");
    require(datacube::octets_text(r.read_exact(4U,"request magic"),"request magic",true)=="NVI1",
        "SOURCE_VIEW_INVALID","unknown import request");
    SourceViewRequest q{.view=text(r),.operation=digest(r)};r.require_eof("source import request");
    static_cast<void>(encode_source_view_request(q));return q;
}
Bytes encode_subscribed_source(const SubscribedSource& a) {
    Bytes b;datacube::append_text(b,a.selective_retry?"NSV3":a.executor_uid?"NSV2":"NSV1");text(b,a.view);digest(b,a.view_digest);digest(b,a.binding_digest);
    datacube::append_be32(b,a.uid);datacube::append_be32(b,a.gid);datacube::append_be32(b,a.pid);
    datacube::append_be64(b,a.unix_ms);datacube::append_be64(b,a.configuration_event);digest(b,a.configuration_digest);
    digest(b,a.outer_operation);digest(b,a.outer_digest);datacube::append_be64(b,a.outer_configuration_event);
    text(b,a.provider_generation);digest(b,a.provider_spki);digest(b,a.source_operation);digest(b,a.source_digest);
    optional_digest(b,a.source_corrects);datacube::append_be32(b,a.claimed_author_uid);datacube::append_be64(b,a.claimed_authored_unix_ms);
    text(b,a.source_scope);text(b,a.grant);digest(b,a.subscription_instance);datacube::append_be64(b,a.ordinal);
    optional_digest(b,a.lineage_digest);if(a.executor_uid){datacube::append_be32(b,*a.executor_uid);datacube::append_be64(b,a.automation_revision);}return b;
}
SubscribedSource decode_subscribed_source(datacube::Reader& r) {
    const auto version=datacube::octets_text(r.read_exact(4U,"source view provenance magic"),"source view provenance magic",true);
    require(version=="NSV1"||version=="NSV2"||version=="NSV3","JOURNAL_CORRUPT","unknown source view provenance");
    SubscribedSource a;a.view=text(r);a.view_digest=digest(r);a.binding_digest=digest(r);
    a.uid=r.read_be32("import UID");a.gid=r.read_be32("import GID");a.pid=r.read_be32("import PID");
    a.unix_ms=r.read_be64("import time");a.configuration_event=r.read_be64("import config event");a.configuration_digest=digest(r);
    a.outer_operation=digest(r);a.outer_digest=digest(r);a.outer_configuration_event=r.read_be64("outer config event");
    a.provider_generation=text(r);a.provider_spki=digest(r);a.source_operation=digest(r);a.source_digest=digest(r);
    a.source_corrects=optional_digest(r);a.claimed_author_uid=r.read_be32("claimed author UID");a.claimed_authored_unix_ms=r.read_be64("claimed author time");
    a.source_scope=text(r,128U);a.grant=text(r);a.subscription_instance=digest(r);a.ordinal=r.read_be64("eligible ordinal");
    a.lineage_digest=optional_digest(r);if(version=="NSV2"||version=="NSV3"){a.selective_retry=version=="NSV3";a.executor_uid=r.read_be32("worker UID");a.automation_revision=r.read_be64("automation revision");require(a.automation_revision>0U,"JOURNAL_CORRUPT","automation revision required");}return a;
}
std::string subscribed_source_json(const SubscribedSource& a) {
    const auto hex=[](const Digest& d){return json_string(datacube::hex_lower(d));};
    return "{\"format\":\"NATRAV_OVERLAY_SUBSCRIBED_SOURCE_V1\",\"origin\":\"SUBSCRIBED_SOURCE\",\"view\":"+json_string(a.view)+
        ",\"execution_actor\":"+json_string(a.selective_retry?"LOCAL_IMPORT_RETRY":a.executor_uid?"DAEMON_IMPORT_WORKER":"LOCAL_PRINCIPAL")+
        ",\"executor_uid\":"+std::to_string(a.executor_uid.value_or(a.uid))+",\"automation_revision\":"+std::to_string(a.automation_revision)+
        ",\"view_digest\":"+hex(a.view_digest)+",\"binding_digest\":"+hex(a.binding_digest)+
        ",\"import_uid\":"+std::to_string(a.uid)+",\"import_gid\":"+std::to_string(a.gid)+",\"import_pid\":"+std::to_string(a.pid)+
        ",\"imported_unix_ms\":"+std::to_string(a.unix_ms)+",\"configuration_event\":"+std::to_string(a.configuration_event)+
        ",\"configuration_digest\":"+hex(a.configuration_digest)+",\"outer_operation\":"+hex(a.outer_operation)+
        ",\"outer_record_digest\":"+hex(a.outer_digest)+",\"outer_configuration_event\":"+std::to_string(a.outer_configuration_event)+
        ",\"provider_generation\":"+json_string(a.provider_generation)+",\"provider_spki\":"+hex(a.provider_spki)+
        ",\"source_operation\":"+hex(a.source_operation)+",\"source_record_digest\":"+hex(a.source_digest)+
        ",\"source_corrects\":"+(a.source_corrects?hex(*a.source_corrects):"null")+
        ",\"claimed_author_uid\":"+std::to_string(a.claimed_author_uid)+",\"claimed_authored_unix_ms\":"+std::to_string(a.claimed_authored_unix_ms)+
        ",\"source_scope\":"+json_string(a.source_scope)+",\"grant\":"+json_string(a.grant)+
        ",\"subscription_instance\":"+hex(a.subscription_instance)+",\"source_ordinal\":"+std::to_string(a.ordinal)+
        ",\"lineage_digest\":"+(a.lineage_digest?hex(*a.lineage_digest):"null")+"}";
}

void NodeState::reserve_source_view_domains_locked(const RuntimeConfig& c, const bool commit) {
    for (const auto& r:c.source_views.rules) {
        const auto domain=std::make_pair(r.provider,r.target_scope);
        if (!source_view_domains_.contains(domain)) {
            const auto it=inbound_domain_index_.find(domain);
            if (it!=inbound_domain_index_.end()) {
                // New policy cannot reinterpret previously admitted raw data.
                for (std::size_t position=0U; position<it->second.size(true); ++position) {
                    const auto index=it->second.at(position,true);
                    require(inbound_[index].subscribed_source != nullptr,"SOURCE_VIEW_SCOPE_OCCUPIED","target scope already contains ordinary evidence");
                }
            }
        }
    }
    if (commit) {
        for (const auto& r:c.source_views.rules) { source_view_domains_.emplace(r.provider,r.target_scope); }
        index_source_view_configuration_locked(c);
    }
}

std::pair<EvidenceRecord,SubscribedSource> NodeState::derive_subscribed_source_locked(
    const SubscribedSource& selected, bool current_policy, std::uint64_t input_limit) const {
    require_source_view_active_locked(selected.view);
    auto a=selected;
    require(a.configuration_event>0U && a.configuration_event<=configuration_events_.size() && a.pid>0U && a.unix_ms>0U &&
        (!current_policy || a.configuration_event==active_configuration_event(configuration_events_)),
        "SOURCE_VIEW_POLICY_DENIED","accepted import configuration required");
    const auto& event=configuration_events_[static_cast<std::size_t>(a.configuration_event-1U)];
    require(event.kind!="REJECTED" && event.digest==a.configuration_digest,"SOURCE_VIEW_POLICY_DENIED","import config mismatch");
    const auto config=parse_runtime_config(event.canonical,"/source-view-import-history",IdentityFileValidation::deferred);
    const auto rule_it=std::find_if(config.source_views.rules.begin(),config.source_views.rules.end(),[&](const auto& r){return r.id==a.view;});
    require(config.format_version>=17U && rule_it!=config.source_views.rules.end() && rule_it->uid==a.uid &&
        local_control_allows(config.local_control,a.uid,LocalControlClass::source_import),
        "SOURCE_VIEW_POLICY_DENIED","exact manager and view grant required");
    const auto& rule=*rule_it;
    const auto found=inbound_index_.find(operation_id_text(a.outer_operation));
    require(found!=inbound_index_.end() && found->second<input_limit,"SOURCE_VIEW_OUTER_REJECTED","authenticated outer evidence required");
    const auto& outer=inbound_[found->second];
    require(outer.authorization && !outer.local_authorship && !outer.subscribed_source &&
        outer.record.issuer==rule.provider && outer.record.recipient==node_id_ && outer.record.scope==rule.source_scope &&
        outer.authorization->peer_node==rule.provider && outer.authorization->peer_generation==rule.generation &&
        outer.authorization->decision==AuthorizationDecisionKind::admitted &&
        outer.authorization->operation_id==outer.record.operation_id && outer.authorization->record_digest==outer.record_digest,
        "SOURCE_VIEW_OUTER_REJECTED","outer record must be independently peer-authorized for the exact provider domain");
    const auto binding=std::find_if(configuration_bindings_.begin(),configuration_bindings_.end(),[&](const auto& b){
        return b.journal_kind==static_cast<std::uint8_t>(EntryKind::inbound_authorized) && b.operation_id && *b.operation_id==a.outer_operation;
    });
    require(binding!=configuration_bindings_.end() && binding->configuration_event>0U && binding->configuration_event<=a.configuration_event,
        "SOURCE_VIEW_OUTER_REJECTED","historical authenticated admission binding required");
    const auto& admission_event=configuration_events_[static_cast<std::size_t>(binding->configuration_event-1U)];
    require(admission_event.kind!="REJECTED","SOURCE_VIEW_OUTER_REJECTED","rejected outer config event");
    const auto admission_config=parse_runtime_config(admission_event.canonical,"/source-view-peer-admission",IdentityFileValidation::deferred);
    const auto admitted=evaluate_authorization(admission_config.authorization,rule.provider,rule.generation,outer.record);
    require(admitted.allowed && admitted.policy_digest==outer.authorization->policy_digest &&
        admitted.rule_digest==outer.authorization->rule_digest,
        "SOURCE_VIEW_OUTER_REJECTED","outer policy account must match its accepted historical configuration");
    const auto* old_key=find_peer_generation(admission_config,rule.provider,rule.generation);
    const auto* current_key=find_peer_generation(config,rule.provider,rule.generation);
    require(old_key && current_key && old_key->state!=KeyGenerationState::revoked && current_key->state!=KeyGenerationState::revoked &&
        old_key->spki_sha256==current_key->spki_sha256,"SOURCE_VIEW_KEY_REJECTED","historical and current exact provider key required");
    const auto e=envelope(outer.record.payload);
    require(e.operation==outer.record.operation_id && e.mapped_parent==outer.record.corrects &&
        e.source.issuer==rule.provider && e.source.scope==rule.source_scope && e.author_uid==rule.author_uid &&
        e.recipient==node_id_ && e.generation==config.local_identity_generation && e.pin==config.identity.expected_spki_sha256,
        "SOURCE_VIEW_ENVELOPE_BINDING_REJECTED","envelope must agree with authenticated outer record and exact local/source identities");
    const auto allowed=std::find_if(config.source_views.bindings.begin(),config.source_views.bindings.end(),[&](const auto& b){
        return b.view==rule.id && b.grant==e.grant && b.instance==e.instance && b.grant_digest==e.rule && b.lineage_digest==e.lineage;
    });
    require(allowed!=config.source_views.bindings.end(),"SOURCE_VIEW_SUBSCRIPTION_DENIED","exact accepted grant, instance and lineage pins required");
    a.view_digest=rule.digest;a.binding_digest=allowed->digest;a.outer_digest=outer.record_digest;
    a.outer_configuration_event=binding->configuration_event;a.provider_generation=rule.generation;a.provider_spki=current_key->spki_sha256;
    a.source_operation=e.source.operation_id;a.source_digest=e.source_digest;a.source_corrects=e.source.corrects;
    a.claimed_author_uid=e.author_uid;a.claimed_authored_unix_ms=e.authored;a.source_scope=e.source.scope;
    a.grant=e.grant;a.subscription_instance=e.instance;a.ordinal=e.ordinal;a.lineage_digest=e.lineage;
    EvidenceRecord result{.operation_id=materialized_id(rule,e.source.operation_id),.issuer=rule.provider,.recipient=node_id_,
        .scope=rule.target_scope,.corrects=std::nullopt,.payload=e.source.payload};
    if(e.source.corrects) {
        result.corrects=materialized_id(rule,*e.source.corrects);
        const auto parent=inbound_index_.find(operation_id_text(*result.corrects));
        require(parent!=inbound_index_.end() && parent->second<input_limit,
            "SOURCE_VIEW_PARENT_REQUIRED","import the exact mapped predecessor before its correction");
        require(inbound_[parent->second].subscribed_source &&
            inbound_[parent->second].subscribed_source->view==a.view &&
            inbound_[parent->second].subscribed_source->source_operation==*e.source.corrects &&
            inbound_[parent->second].subscribed_source->outer_operation==*e.mapped_parent,
            "SOURCE_VIEW_PARENT_BINDING_REJECTED","existing imported predecessor differs from recipient mapping");
    }
    validate_evidence_record(result);return {std::move(result),std::move(a)};
}

void NodeState::validate_subscribed_source_locked(const EvidenceRecord& record,
    const SubscribedSource& a,bool current_policy) const {
    const auto expected=derive_subscribed_source_locked(a,current_policy);
    require(encode_application_message(expected.first)==encode_application_message(record) &&
        encode_subscribed_source(expected.second)==encode_subscribed_source(a),
        "JOURNAL_CORRUPT","materialized record or provenance differs from authenticated source");
    const auto config=parse_runtime_config(configuration_events_[static_cast<std::size_t>(a.configuration_event-1U)].canonical,
        "/source-view-budget",IdentityFileValidation::deferred);
    const auto& rule=*std::find_if(config.source_views.rules.begin(),config.source_views.rules.end(),[&](const auto& r){return r.id==a.view;});
    const auto use=source_view_usage_.find(a.view);
    const auto count=use==source_view_usage_.end()?0U:use->second.first;
    const auto bytes=use==source_view_usage_.end()?0U:use->second.second;
    require(count<rule.maximum_records,"SOURCE_VIEW_RECORD_LIMIT","retained import record budget exhausted");
    require(bytes<=rule.maximum_payload_bytes && record.payload.size()<=rule.maximum_payload_bytes-bytes,
        "SOURCE_VIEW_BYTE_LIMIT","retained source payload budget exhausted");
    const auto ordinal=std::make_tuple(a.view,datacube::hex_lower(a.subscription_instance),a.ordinal);
    require(!source_view_ordinals_.contains(ordinal),"SOURCE_VIEW_ORDINAL_CONFLICT","subscription ordinal already materialized");
}


ImportAttempt NodeState::prepare_import_locked(const SubscribedSource& selected, const std::uint64_t limit) const {
    ImportAttempt result;
    try {
        auto derived=derive_subscribed_source_locked(selected,false,limit);
        const auto& record=derived.first; const auto& account=derived.second;
        const auto existing=inbound_index_.find(operation_id_text(record.operation_id));
        if(existing!=inbound_index_.end() && existing->second<limit) {
            const auto& old=inbound_[existing->second];
            require(old.subscribed_source && old.subscribed_source->outer_operation==account.outer_operation &&
                old.record_digest==evidence_record_digest(record),"SOURCE_VIEW_SOURCE_CONFLICT","different source materialization exists");
            result.outcome="DUPLICATE";return result;
        }
        require(limit<1'000'000U,"SOURCE_VIEW_CAPACITY","retained evidence ceiling");
        if(record.corrects) {
            const auto child=correction_child_.find(operation_id_text(*record.corrects));
            if(child!=correction_child_.end()) {
                const auto index=inbound_index_.find(child->second);
                require(index==inbound_index_.end() || index->second>=limit,"SOURCE_VIEW_BRANCH_REJECTED","predecessor already corrected");
            }
        }
        const auto config=parse_runtime_config(configuration_events_[static_cast<std::size_t>(account.configuration_event-1U)].canonical,
            "/import-history-budget",IdentityFileValidation::deferred);
        const auto& rule=*std::find_if(config.source_views.rules.begin(),config.source_views.rules.end(),[&](const auto& v){return v.id==account.view;});
        const auto domain=inbound_domain_index_.find({rule.provider,rule.target_scope});
        std::uint64_t count=0U,bytes=0U;
        if(domain!=inbound_domain_index_.end()) {
            const auto n=domain->second.before(static_cast<std::size_t>(limit),true);
            count=n;
            // Prefix accounting is used only for replay. Live usage is already derived.
            if(limit==inbound_.size()) {
                const auto use=source_view_usage_.find(account.view);
                if(use!=source_view_usage_.end())bytes=use->second.second;
            } else {
                for(std::size_t i=0U;i<n;++i) bytes+=inbound_[domain->second.at(i,true)].record.payload.size();
            }
            if(limit==inbound_.size()) {
                require(!source_view_ordinals_.contains(std::make_tuple(account.view,datacube::hex_lower(account.subscription_instance),account.ordinal)),"SOURCE_VIEW_ORDINAL_CONFLICT","ordinal already imported");
            } else for(std::size_t i=0U;i<n;++i) {
                const auto& proof=inbound_[domain->second.at(i,true)].subscribed_source;
                require(!proof || proof->subscription_instance!=account.subscription_instance || proof->ordinal!=account.ordinal,
                    "SOURCE_VIEW_ORDINAL_CONFLICT","ordinal already imported");
            }
        }
        require(count<rule.maximum_records,"SOURCE_VIEW_RECORD_LIMIT","record budget exhausted");
        require(bytes<=rule.maximum_payload_bytes && record.payload.size()<=rule.maximum_payload_bytes-bytes,
            "SOURCE_VIEW_BYTE_LIMIT","payload budget exhausted");
        result.outcome="IMPORTED";result.imported=std::move(derived);return result;
    } catch(const AppError& e) {
        result.outcome=e.code();
        if(result.outcome=="SOURCE_VIEW_PARENT_REQUIRED") {
            const auto& config_event=configuration_events_.at(static_cast<std::size_t>(selected.configuration_event-1U));
            const auto config=parse_runtime_config(config_event.canonical,"/import-parent-history",IdentityFileValidation::deferred);
            const auto rule=std::find_if(config.source_views.rules.begin(),config.source_views.rules.end(),[&](const auto& v){return v.id==selected.view;});
            const auto outer=inbound_index_.find(operation_id_text(selected.outer_operation));
            if(rule!=config.source_views.rules.end() && outer!=inbound_index_.end()) {
                const auto parsed=envelope(inbound_[outer->second].record.payload);
                if(parsed.source.corrects) result.parent=materialized_id(*rule,*parsed.source.corrects);
            }
        }
        return result;
    } catch(const std::bad_alloc&) { throw; }
      catch(const datacube::Failure&) {
        result.outcome="SOURCE_VIEW_ENVELOPE_INVALID";return result;
    }
}

std::string NodeState::import_subscribed_source(const SourceViewRequest& request,const RuntimeConfig& config,
    std::uint32_t uid,std::uint32_t gid,std::uint32_t pid,std::uint64_t configuration_event,std::uint64_t unix_ms) {
    const auto rule=std::find_if(config.source_views.rules.begin(),config.source_views.rules.end(),[&](const auto& r){return r.id==request.view;});
    require(config.format_version>=17U && rule!=config.source_views.rules.end() && rule->uid==uid &&
        local_control_allows(config.local_control,uid,LocalControlClass::source_import),
        "SOURCE_VIEW_POLICY_DENIED","current exact UID/view policy required");
    std::lock_guard<std::mutex> lock(mutex_);
    SubscribedSource selected;selected.view=request.view;selected.uid=uid;selected.gid=gid;selected.pid=pid;
    selected.configuration_event=configuration_event;selected.configuration_digest=runtime_configuration_digest(canonical_runtime_config(config));
    selected.unix_ms=unix_ms;selected.outer_operation=request.operation;
    const auto [record,account]=derive_subscribed_source_locked(selected,true);
    const auto key=operation_id_text(record.operation_id);
    const auto response=[&](std::string_view disposition,const SubscribedSource& proof) {
        return "{\"format\":\"NATRAV_OVERLAY_SOURCE_IMPORT_RESULT_V1\",\"disposition\":"+json_string(disposition)+
            ",\"operation_id\":"+json_string(key)+",\"record_digest\":"+json_string(datacube::hex_lower(evidence_record_digest(record)))+
            ",\"scope\":"+json_string(record.scope)+",\"network_used\":false,\"subscribed_source\":"+subscribed_source_json(proof)+"}";
    };
    const auto found=inbound_index_.find(key);
    if(found!=inbound_index_.end()) {
        const auto& prior=inbound_[found->second];
        require(prior.subscribed_source && prior.subscribed_source->outer_operation==account.outer_operation &&
            prior.record_digest==evidence_record_digest(record),"SOURCE_VIEW_SOURCE_CONFLICT","source identity already has another materialization");
        return response("ALREADY_IMPORTED",*prior.subscribed_source);
    }
    require(inbound_.size()<1'000'000U,"SOURCE_VIEW_CAPACITY","retained evidence admission ceiling reached");
    if(record.corrects) {
        require(!correction_child_.contains(operation_id_text(*record.corrects)),"SOURCE_VIEW_BRANCH_REJECTED","materialized predecessor already corrected");
    }
    validate_subscribed_source_locked(record,account,true);
    auto encoded=encode_subscribed_source(account);datacube::append_octets(encoded,encode_application_message(record));
    boundary("NATRAV_OVERLAY_TEST_SOURCE_IMPORT_BEFORE_COMMIT_MS");
    append_entry(EntryKind::subscribed_source,encoded);
    boundary("NATRAV_OVERLAY_TEST_SOURCE_IMPORT_AFTER_COMMIT_MS");
    return response("IMPORTED",account);
}
} // namespace natrav_overlay
