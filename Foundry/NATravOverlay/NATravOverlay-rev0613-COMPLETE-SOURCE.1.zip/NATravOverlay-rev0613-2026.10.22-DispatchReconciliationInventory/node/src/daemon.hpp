#pragma once

#include "config.hpp"
#include "control.hpp"
#include "node.hpp"

#include <filesystem>

namespace natrav_overlay {

int run_persistent_node(const RuntimeConfig& config);

[[nodiscard]] ControlResponse exchange_control_request(
    const std::filesystem::path& control_socket,
    const ControlRequest& request,
    const IoOptions& io);

}  // namespace natrav_overlay
