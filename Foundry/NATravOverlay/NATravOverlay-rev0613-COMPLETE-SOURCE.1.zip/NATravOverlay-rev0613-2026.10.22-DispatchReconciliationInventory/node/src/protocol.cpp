#include "protocol.hpp"

#include "datacube/natrav_peer_stream.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <string>
#include <utility>

namespace natrav_overlay {
namespace {

inline constexpr std::array<std::uint8_t, 4> kMagic{
    static_cast<std::uint8_t>('N'),
    static_cast<std::uint8_t>('O'),
    static_cast<std::uint8_t>('A'),
    static_cast<std::uint8_t>('1'),
};
inline constexpr std::uint8_t kEvidenceKind = 1U;
inline constexpr std::uint8_t kCorrectionKind = 2U;
inline constexpr std::uint8_t kReceiptKind = 3U;
inline constexpr std::uint8_t kErrorKind = 4U;
inline constexpr std::uint8_t kRemoteSourceRequestKind = 5U;
inline constexpr std::uint8_t kRemoteSourceResponseKind = 6U;
inline constexpr std::uint8_t kRemoteSourceLeaseRequestKind = 7U;
inline constexpr std::uint8_t kRemoteSourceLeaseResponseKind = 8U;
inline constexpr std::uint8_t kCustodyTransferOfferKind = 9U;
inline constexpr std::uint8_t kCustodyTransferAcceptanceKind = 10U;
inline constexpr std::array<std::uint8_t, 4> kSessionMagic{
    static_cast<std::uint8_t>('N'),
    static_cast<std::uint8_t>('O'),
    static_cast<std::uint8_t>('S'),
    static_cast<std::uint8_t>('1'),
};
inline constexpr std::uint8_t kSessionVersion = 1U;
inline constexpr std::array<std::uint8_t, 4> kCounterActionMagic{
    static_cast<std::uint8_t>('N'),
    static_cast<std::uint8_t>('C'),
    static_cast<std::uint8_t>('A'),
    static_cast<std::uint8_t>('1'),
};

class Writer final {
public:
    void fixed(const datacube::OctetView value) {
        datacube::append_octets(bytes_, value);
    }
    void u8(const std::uint8_t value) { datacube::append_u8(bytes_, value); }
    void u16(const std::uint16_t value) { datacube::append_be16(bytes_, value); }
    void u32(const std::uint32_t value) { datacube::append_be32(bytes_, value); }
    void u64(const std::uint64_t value) { datacube::append_be64(bytes_, value); }
    void digest(const datacube::Digest32& value) { fixed(value.octets); }
    void text16(const std::string_view value) {
        if (value.size() > static_cast<std::size_t>(
                std::numeric_limits<std::uint16_t>::max())) {
            app_fail("APPLICATION_ENCODING_FAILED", "text field exceeds u16 envelope");
        }
        u16(static_cast<std::uint16_t>(value.size()));
        datacube::append_text(bytes_, value);
    }
    void blob32(const datacube::OctetView value) {
        if (value.size() > static_cast<std::size_t>(
                std::numeric_limits<std::uint32_t>::max())) {
            app_fail("APPLICATION_ENCODING_FAILED", "blob exceeds u32 envelope");
        }
        u32(static_cast<std::uint32_t>(value.size()));
        fixed(value);
    }
    [[nodiscard]] datacube::Octets take() && { return std::move(bytes_); }
private:
    datacube::Octets bytes_;
};

class Reader final {
public:
    explicit Reader(const datacube::OctetView value) : value_(value) {}

    [[nodiscard]] std::uint8_t u8(const std::string_view field) {
        return exact(1U, field)[0];
    }
    [[nodiscard]] std::uint16_t u16(const std::string_view field) {
        const auto bytes = exact(2U, field);
        return static_cast<std::uint16_t>(
            (static_cast<std::uint16_t>(bytes[0]) << 8U) |
            static_cast<std::uint16_t>(bytes[1]));
    }
    [[nodiscard]] std::uint32_t u32(const std::string_view field) {
        const auto bytes = exact(4U, field);
        return (static_cast<std::uint32_t>(bytes[0]) << 24U) |
            (static_cast<std::uint32_t>(bytes[1]) << 16U) |
            (static_cast<std::uint32_t>(bytes[2]) << 8U) |
            static_cast<std::uint32_t>(bytes[3]);
    }
    [[nodiscard]] std::uint64_t u64(const std::string_view field) {
        const auto bytes = exact(8U, field);
        std::uint64_t result = 0U;
        for (const auto byte : bytes) {
            result = (result << 8U) | static_cast<std::uint64_t>(byte);
        }
        return result;
    }
    [[nodiscard]] datacube::Digest32 digest(const std::string_view field) {
        datacube::Digest32 result;
        const auto bytes = exact(result.octets.size(), field);
        std::copy(bytes.begin(), bytes.end(), result.octets.begin());
        return result;
    }
    [[nodiscard]] std::string text16(
        const std::string_view field,
        const std::size_t ceiling) {
        const auto length = static_cast<std::size_t>(u16(field));
        if (length > ceiling) {
            app_fail("APPLICATION_SCHEMA_REJECTED",
                std::string(field) + " exceeds configured ceiling");
        }
        const auto bytes = exact(length, field);
        return std::string(
            reinterpret_cast<const char*>(bytes.data()), bytes.size());
    }
    [[nodiscard]] datacube::Octets blob32(
        const std::string_view field,
        const std::size_t ceiling) {
        const auto length = static_cast<std::size_t>(u32(field));
        if (length > ceiling) {
            app_fail("APPLICATION_SCHEMA_REJECTED",
                std::string(field) + " exceeds configured ceiling");
        }
        const auto bytes = exact(length, field);
        return datacube::Octets(bytes.begin(), bytes.end());
    }
    void magic() {
        const auto actual = exact(kMagic.size(), "application magic");
        if (!std::equal(actual.begin(), actual.end(), kMagic.begin())) {
            app_fail("APPLICATION_MAGIC_REJECTED", "expected NOA1");
        }
    }
    void session_magic() {
        const auto actual = exact(kSessionMagic.size(), "session magic");
        if (!std::equal(actual.begin(), actual.end(), kSessionMagic.begin())) {
            app_fail("SESSION_MAGIC_REJECTED", "expected NOS1");
        }
    }
    void eof() const {
        if (offset_ != value_.size()) {
            app_fail("APPLICATION_SCHEMA_REJECTED", "trailing application bytes");
        }
    }
private:
    [[nodiscard]] datacube::OctetView exact(
        const std::size_t count,
        const std::string_view field) {
        if (count > value_.size() - offset_) {
            app_fail("APPLICATION_TRUNCATED",
                std::string(field) + " is incomplete");
        }
        const auto out = value_.subspan(offset_, count);
        offset_ += count;
        return out;
    }

    datacube::OctetView value_;
    std::size_t offset_{0U};
};

[[nodiscard]] bool valid_detail(const std::string_view value) noexcept {
    if (value.size() > 512U) {
        return false;
    }
    return std::all_of(value.begin(), value.end(), [](const char raw) {
        const auto ch = static_cast<unsigned char>(raw);
        return ch == 9U || (ch >= 32U && ch <= 126U);
    });
}

[[nodiscard]] bool session_limits_zero(const PeerSessionLimits& limits) noexcept {
    return limits.maximum_operations == 0U && limits.maximum_bytes == 0U &&
        limits.maximum_lifetime_ms == 0U && limits.idle_timeout_ms == 0U;
}

void validate_peer_session_frame(const PeerSessionFrame& frame) {
    if (digest_is_zero(frame.session_id)) {
        app_fail("SESSION_ID_INVALID", "all-zero session ID is reserved");
    }
    const bool operation_present = !digest_is_zero(frame.operation_id);
    switch (frame.kind) {
        case PeerSessionFrameKind::open:
        case PeerSessionFrameKind::open_ack:
            if (frame.flags != 0U || frame.sequence != 0U || operation_present ||
                !frame.limits.has_value() || !frame.payload.empty()) {
                app_fail("SESSION_FRAME_REJECTED",
                    "session open frames require limits and no operation payload");
            }
            validate_peer_session_limits(*frame.limits);
            return;
        case PeerSessionFrameKind::request:
            if (frame.flags != 0U || frame.sequence == 0U || !operation_present ||
                frame.limits.has_value() || frame.payload.empty() ||
                frame.payload.size() > kMaximumApplicationPayloadBytes) {
                app_fail("SESSION_FRAME_REJECTED",
                    "session request envelope is invalid");
            }
            return;
        case PeerSessionFrameKind::response:
            if ((frame.flags & ~kPeerSessionRetireAfterResponse) != 0U ||
                frame.sequence == 0U || !operation_present ||
                frame.limits.has_value() || frame.payload.empty() ||
                frame.payload.size() > kMaximumApplicationPayloadBytes) {
                app_fail("SESSION_FRAME_REJECTED",
                    "session response envelope is invalid");
            }
            return;
        case PeerSessionFrameKind::close:
        case PeerSessionFrameKind::close_ack:
            if (frame.flags != 0U || frame.sequence == 0U || operation_present ||
                frame.limits.has_value() || !frame.payload.empty()) {
                app_fail("SESSION_FRAME_REJECTED",
                    "session close frames cannot carry an operation or payload");
            }
            return;
    }
    app_fail("SESSION_KIND_REJECTED", "unknown session frame kind");
}

[[nodiscard]] datacube::Octets encode_record(const EvidenceRecord& record) {
    validate_evidence_record(record);
    Writer writer;
    writer.fixed(kMagic);
    writer.u8(record.corrects.has_value() ? kCorrectionKind : kEvidenceKind);
    writer.digest(record.operation_id);
    writer.text16(record.issuer);
    writer.text16(record.recipient);
    writer.text16(record.scope);
    if (record.corrects.has_value()) {
        writer.digest(*record.corrects);
    }
    writer.blob32(record.payload);
    auto result = std::move(writer).take();
    if (result.size() > kMaximumApplicationPayloadBytes) {
        app_fail("APPLICATION_PAYLOAD_TOO_LARGE",
            "encoded evidence exceeds the 65536-byte frame envelope");
    }
    return result;
}

}  // namespace

void validate_peer_session_limits(const PeerSessionLimits& limits) {
    constexpr std::uint64_t minimum_bytes =
        2U * static_cast<std::uint64_t>(
            kPeerFramePrefixBytes + kPeerSessionHeaderBytes +
            kMaximumApplicationPayloadBytes);
    if (limits.maximum_operations < 1U || limits.maximum_operations > 1'024U) {
        app_fail("SESSION_LIMIT_INVALID",
            "maximum session operations must be between 1 and 1024");
    }
    if (limits.maximum_bytes < minimum_bytes ||
        limits.maximum_bytes > kMaximumPeerSessionBytes) {
        app_fail("SESSION_LIMIT_INVALID",
            "maximum session bytes are outside the bounded envelope");
    }
    if (limits.maximum_lifetime_ms < 100U ||
        limits.maximum_lifetime_ms > 600'000U) {
        app_fail("SESSION_LIMIT_INVALID",
            "maximum session lifetime must be between 100 and 600000 ms");
    }
    if (limits.idle_timeout_ms < 10U ||
        limits.idle_timeout_ms > 60'000U ||
        limits.idle_timeout_ms > limits.maximum_lifetime_ms) {
        app_fail("SESSION_LIMIT_INVALID",
            "session idle timeout must fit within the session lifetime");
    }
}

bool looks_like_peer_session_frame(const datacube::OctetView payload) noexcept {
    return payload.size() >= kSessionMagic.size() &&
        std::equal(kSessionMagic.begin(), kSessionMagic.end(), payload.begin());
}

datacube::Octets encode_peer_session_frame(const PeerSessionFrame& frame) {
    validate_peer_session_frame(frame);
    Writer writer;
    writer.fixed(kSessionMagic);
    writer.u8(kSessionVersion);
    writer.u8(static_cast<std::uint8_t>(frame.kind));
    writer.u16(frame.flags);
    writer.digest(frame.session_id);
    writer.u32(frame.sequence);
    writer.digest(frame.operation_id);
    if (frame.limits.has_value()) {
        writer.u32(frame.limits->maximum_operations);
        writer.u64(frame.limits->maximum_bytes);
        writer.u32(frame.limits->maximum_lifetime_ms);
        writer.u32(frame.limits->idle_timeout_ms);
    } else {
        writer.u32(0U);
        writer.u64(0U);
        writer.u32(0U);
        writer.u32(0U);
    }
    writer.blob32(frame.payload);
    auto encoded = std::move(writer).take();
    if (encoded.size() != kPeerSessionHeaderBytes + frame.payload.size()) {
        app_fail("SESSION_ENCODING_FAILED", "session envelope size mismatch");
    }
    return encoded;
}

PeerSessionFrame decode_peer_session_frame(const datacube::OctetView payload) {
    if (payload.size() < kPeerSessionHeaderBytes ||
        payload.size() > kPeerSessionHeaderBytes + kMaximumApplicationPayloadBytes) {
        app_fail("SESSION_PAYLOAD_SIZE_REJECTED",
            "session frame is outside the bounded envelope");
    }
    Reader reader(payload);
    reader.session_magic();
    if (reader.u8("session version") != kSessionVersion) {
        app_fail("SESSION_VERSION_REJECTED", "unsupported NOS1 version");
    }
    const auto raw_kind = reader.u8("session frame kind");
    if (raw_kind < static_cast<std::uint8_t>(PeerSessionFrameKind::open) ||
        raw_kind > static_cast<std::uint8_t>(PeerSessionFrameKind::close_ack)) {
        app_fail("SESSION_KIND_REJECTED", "unknown session frame kind");
    }
    PeerSessionFrame frame;
    frame.kind = static_cast<PeerSessionFrameKind>(raw_kind);
    frame.flags = reader.u16("session flags");
    frame.session_id = reader.digest("session ID");
    frame.sequence = reader.u32("session sequence");
    frame.operation_id = reader.digest("session operation ID");
    const PeerSessionLimits limits{
        .maximum_operations = reader.u32("session maximum operations"),
        .maximum_bytes = reader.u64("session maximum bytes"),
        .maximum_lifetime_ms = reader.u32("session maximum lifetime"),
        .idle_timeout_ms = reader.u32("session idle timeout"),
    };
    if (!session_limits_zero(limits)) {
        frame.limits = limits;
    }
    frame.payload = reader.blob32(
        "session application payload", kMaximumApplicationPayloadBytes);
    reader.eof();
    validate_peer_session_frame(frame);
    return frame;
}

std::string_view peer_session_frame_kind_name(
    const PeerSessionFrameKind kind) noexcept {
    switch (kind) {
        case PeerSessionFrameKind::open: return "OPEN";
        case PeerSessionFrameKind::open_ack: return "OPEN_ACK";
        case PeerSessionFrameKind::request: return "REQUEST";
        case PeerSessionFrameKind::response: return "RESPONSE";
        case PeerSessionFrameKind::close: return "CLOSE";
        case PeerSessionFrameKind::close_ack: return "CLOSE_ACK";
    }
    return "UNKNOWN";
}

void validate_evidence_record(const EvidenceRecord& record) {
    if (digest_is_zero(record.operation_id)) {
        app_fail("INVALID_OPERATION_ID", "all-zero operation ID is reserved");
    }
    require_node_id(record.issuer, "issuer");
    require_node_id(record.recipient, "recipient");
    require_scope(record.scope);
    if (record.payload.size() > kMaximumEvidencePayloadBytes) {
        app_fail("PAYLOAD_TOO_LARGE", "evidence payload exceeds 60000 bytes");
    }
    if (record.corrects.has_value()) {
        if (digest_is_zero(*record.corrects)) {
            app_fail("INVALID_CORRECTION_PARENT", "all-zero parent is reserved");
        }
        if (*record.corrects == record.operation_id) {
            app_fail("INVALID_CORRECTION_PARENT", "a correction cannot name itself");
        }
    }
}

void validate_delivery_receipt(const DeliveryReceipt& receipt) {
    if (digest_is_zero(receipt.operation_id) ||
        digest_is_zero(receipt.record_digest)) {
        app_fail("INVALID_RECEIPT", "receipt digests must be nonzero");
    }
    require_node_id(receipt.recipient, "receipt recipient");
    require_node_id(receipt.recorder, "receipt recorder");
    if (receipt.sequence == 0U) {
        app_fail("INVALID_RECEIPT", "receipt sequence must be nonzero");
    }
    if (receipt.disposition != ReceiptDisposition::committed &&
        receipt.disposition != ReceiptDisposition::duplicate) {
        app_fail("INVALID_RECEIPT", "unknown receipt disposition");
    }
}

void validate_protocol_error(const ProtocolError& error) {
    if (error.operation_id.has_value() && digest_is_zero(*error.operation_id)) {
        app_fail("INVALID_PROTOCOL_ERROR", "error operation ID is all zero");
    }
    if (!valid_error_code(error.code)) {
        app_fail("INVALID_PROTOCOL_ERROR", "invalid error code");
    }
    if (!valid_detail(error.detail)) {
        app_fail("INVALID_PROTOCOL_ERROR", "invalid error detail");
    }
}

void validate_remote_source_subscription_request(
    const RemoteSourceSubscriptionRequest& request) {
    if (digest_is_zero(request.request_id)) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_INVALID",
            "remote request ID must be nonzero");
    }
    if (request.command != RemoteSourceSubscriptionCommand::request &&
        request.command != RemoteSourceSubscriptionCommand::status &&
        request.command != RemoteSourceSubscriptionCommand::withdraw) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_INVALID",
            "unknown remote subscription command");
    }
    if (!valid_generation_id(request.grant)) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_INVALID",
            "grant ID is outside the bounded identifier grammar");
    }
    const bool leased = !request.lease_generation.empty();
    if (leased && !valid_generation_id(request.lease_generation)) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_INVALID",
            "lease generation is outside the bounded identifier grammar");
    }
    const bool withdrawing =
        request.command == RemoteSourceSubscriptionCommand::withdraw;
    if (withdrawing != request.instance.has_value() ||
        (request.instance && digest_is_zero(*request.instance)) ||
        (withdrawing ? (request.expected_revision == 0U ||
            request.expected_revision > 65'536U || !leased) :
            request.expected_revision != 0U)) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_INVALID",
            "withdrawal requires one exact leased instance and revision");
    }
    const bool needs_reason =
        request.command == RemoteSourceSubscriptionCommand::request || withdrawing;
    if ((needs_reason && (request.reason.empty() ||
            !valid_detail(request.reason) || request.reason.size() > 256U)) ||
        (!needs_reason && !request.reason.empty())) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_INVALID",
            "request and withdrawal require one bounded printable reason; status requires none");
    }
}

void validate_remote_source_subscription_response(
    const RemoteSourceSubscriptionResponse& response) {
    if (digest_is_zero(response.request_id) ||
        digest_is_zero(response.instance) ||
        digest_is_zero(response.grant_digest) ||
        digest_is_zero(response.subscriber_spki) ||
        digest_is_zero(response.accepted_request_id)) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_RESPONSE_INVALID",
            "response digests must be nonzero");
    }
    require_node_id(response.provider, "remote subscription provider");
    require_generation_id(response.grant, "remote subscription grant");
    require_generation_id(response.subscriber_generation,
        "remote subscription generation");
    if (response.revision == 0U || response.revision > 65'536U ||
        response.issued > 128U || response.acknowledged > response.issued ||
        response.maximum_records == 0U || response.maximum_records > 128U ||
        response.issued > response.maximum_records ||
        response.maximum_payload_bytes == 0U ||
        response.maximum_payload_bytes > 7'680'000U ||
        response.used_payload_bytes > response.maximum_payload_bytes ||
        response.accepted_configuration_event == 0U ||
        response.accepted_unix_ms == 0U) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_RESPONSE_INVALID",
            "response counters or provenance are outside their envelope");
    }
    const bool leased = !response.lease_generation.empty();
    if (leased) {
        require_generation_id(response.lease_generation,
            "remote subscription lease generation");
        if (response.lease_expires_unix_ms == 0U ||
            (response.withdrawal_policy != "RETAIN" &&
             response.withdrawal_policy != "CANCEL") ||
            (!response.terminal_kind.empty() &&
             response.terminal_kind != "WITHDRAWN" &&
             response.terminal_kind != "EXPIRED") ||
            (!response.terminal_pending_disposition.empty() &&
             response.terminal_pending_disposition != "NONE" &&
             response.terminal_pending_disposition != "RETAIN" &&
             response.terminal_pending_disposition != "CANCEL") ||
            (!response.terminal_kind.empty() && response.terminal_reason.empty()) ||
            ((response.terminal_pending_disposition == "CANCEL") !=
                response.terminal_cancelled_operation.has_value())) {
            app_fail("SOURCE_SUBSCRIPTION_REMOTE_RESPONSE_INVALID",
                "leased response has invalid lifetime or terminal account");
        }
    } else if (response.lease_expires_unix_ms != 0U ||
        !response.withdrawal_policy.empty() || !response.terminal_kind.empty() ||
        !response.terminal_pending_disposition.empty() ||
        response.terminal_cancelled_operation.has_value() ||
        !response.terminal_reason.empty()) {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_RESPONSE_INVALID",
            "legacy response cannot carry leased fields");
    }
    if (response.disposition != "ACCEPTED" &&
        response.disposition != "ALREADY_ACCEPTED" &&
        response.disposition != "ALREADY_REQUESTED" &&
        response.disposition != "STATUS" &&
        response.disposition != "WITHDRAWN" &&
        response.disposition != "ALREADY_WITHDRAWN" &&
        response.disposition != "EXPIRED") {
        app_fail("SOURCE_SUBSCRIPTION_REMOTE_RESPONSE_INVALID",
            "unknown remote subscription disposition");
    }
}

void validate_custody_transfer_offer(const CustodyTransferOffer& offer) {
    if (digest_is_zero(offer.request_id) || offer.signed_offer.empty() ||
        offer.signed_offer.size() > kMaximumCustodySessionWireBytes) {
        app_fail("CUSTODY_SESSION_OFFER_INVALID",
            "custody offer requires a nonzero request ID and bounded signed bytes");
    }
}

void validate_custody_transfer_acceptance(
    const CustodyTransferAcceptance& acceptance) {
    if (digest_is_zero(acceptance.request_id) ||
        acceptance.signed_acceptance.empty() ||
        acceptance.signed_acceptance.size() > kMaximumCustodySessionWireBytes) {
        app_fail("CUSTODY_SESSION_ACCEPTANCE_INVALID",
            "custody acceptance requires a nonzero request ID and bounded signed bytes");
    }
}

datacube::Octets encode_application_message(const ApplicationMessage& message) {
    if (const auto* record = std::get_if<EvidenceRecord>(&message)) {
        return encode_record(*record);
    }
    Writer writer;
    writer.fixed(kMagic);
    if (const auto* receipt = std::get_if<DeliveryReceipt>(&message)) {
        validate_delivery_receipt(*receipt);
        writer.u8(kReceiptKind);
        writer.digest(receipt->operation_id);
        writer.text16(receipt->recipient);
        writer.text16(receipt->recorder);
        writer.u8(static_cast<std::uint8_t>(receipt->disposition));
        writer.u64(receipt->sequence);
        writer.digest(receipt->record_digest);
    } else if (const auto* error = std::get_if<ProtocolError>(&message)) {
        validate_protocol_error(*error);
        writer.u8(kErrorKind);
        writer.u8(error->operation_id.has_value() ? 1U : 0U);
        if (error->operation_id.has_value()) {
            writer.digest(*error->operation_id);
        }
        writer.text16(error->code);
        writer.text16(error->detail);
    } else if (const auto* request =
            std::get_if<RemoteSourceSubscriptionRequest>(&message)) {
        validate_remote_source_subscription_request(*request);
        const bool leased = !request->lease_generation.empty() ||
            request->command == RemoteSourceSubscriptionCommand::withdraw;
        writer.u8(leased ? kRemoteSourceLeaseRequestKind :
            kRemoteSourceRequestKind);
        writer.digest(request->request_id);
        writer.u8(static_cast<std::uint8_t>(request->command));
        writer.text16(request->grant);
        writer.text16(request->reason);
        if (leased) {
            writer.text16(request->lease_generation);
            writer.u8(request->instance.has_value() ? 1U : 0U);
            if (request->instance) { writer.digest(*request->instance); }
            writer.u64(request->expected_revision);
        }
    } else if (const auto* offer =
            std::get_if<CustodyTransferOffer>(&message)) {
        validate_custody_transfer_offer(*offer);
        writer.u8(kCustodyTransferOfferKind);
        writer.digest(offer->request_id);
        writer.blob32(offer->signed_offer);
    } else if (const auto* acceptance =
            std::get_if<CustodyTransferAcceptance>(&message)) {
        validate_custody_transfer_acceptance(*acceptance);
        writer.u8(kCustodyTransferAcceptanceKind);
        writer.digest(acceptance->request_id);
        writer.blob32(acceptance->signed_acceptance);
    } else {
        const auto& response =
            std::get<RemoteSourceSubscriptionResponse>(message);
        validate_remote_source_subscription_response(response);
        const bool leased = !response.lease_generation.empty();
        writer.u8(leased ? kRemoteSourceLeaseResponseKind :
            kRemoteSourceResponseKind);
        writer.digest(response.request_id);
        writer.text16(response.provider);
        writer.text16(response.grant);
        writer.digest(response.instance);
        writer.u64(response.revision);
        writer.u8(response.retired ? 1U : 0U);
        writer.text16(response.disposition);
        writer.u32(response.issued);
        writer.u32(response.acknowledged);
        writer.u64(response.used_payload_bytes);
        writer.u32(response.maximum_records);
        writer.u64(response.maximum_payload_bytes);
        writer.digest(response.grant_digest);
        writer.text16(response.subscriber_generation);
        writer.digest(response.subscriber_spki);
        writer.digest(response.accepted_request_id);
        writer.u64(response.accepted_configuration_event);
        writer.u64(response.accepted_unix_ms);
        if (leased) {
            writer.text16(response.lease_generation);
            writer.u64(response.lease_expires_unix_ms);
            writer.text16(response.withdrawal_policy);
            writer.text16(response.terminal_kind);
            writer.text16(response.terminal_pending_disposition);
            writer.u8(response.terminal_cancelled_operation ? 1U : 0U);
            if (response.terminal_cancelled_operation) {
                writer.digest(*response.terminal_cancelled_operation);
            }
            writer.text16(response.terminal_reason);
        }
    }
    auto result = std::move(writer).take();
    if (result.size() > kMaximumApplicationPayloadBytes) {
        app_fail("APPLICATION_PAYLOAD_TOO_LARGE", "encoded response exceeds frame envelope");
    }
    return result;
}

ApplicationMessage decode_application_message(const datacube::OctetView payload) {
    if (payload.size() < 5U || payload.size() > kMaximumApplicationPayloadBytes) {
        app_fail("APPLICATION_PAYLOAD_SIZE_REJECTED", "outside application envelope");
    }
    Reader reader(payload);
    reader.magic();
    const auto kind = reader.u8("application kind");
    if (kind == kEvidenceKind || kind == kCorrectionKind) {
        EvidenceRecord record;
        record.operation_id = reader.digest("operation ID");
        record.issuer = reader.text16("issuer", 64U);
        record.recipient = reader.text16("recipient", 64U);
        record.scope = reader.text16("scope", 128U);
        if (kind == kCorrectionKind) {
            record.corrects = reader.digest("correction parent");
        }
        record.payload = reader.blob32("evidence payload", kMaximumEvidencePayloadBytes);
        reader.eof();
        validate_evidence_record(record);
        return record;
    }
    if (kind == kReceiptKind) {
        DeliveryReceipt receipt;
        receipt.operation_id = reader.digest("receipt operation ID");
        receipt.recipient = reader.text16("receipt recipient", 64U);
        receipt.recorder = reader.text16("receipt recorder", 64U);
        const auto disposition = reader.u8("receipt disposition");
        if (disposition != static_cast<std::uint8_t>(ReceiptDisposition::committed) &&
            disposition != static_cast<std::uint8_t>(ReceiptDisposition::duplicate)) {
            app_fail("INVALID_RECEIPT", "unknown receipt disposition");
        }
        receipt.disposition = static_cast<ReceiptDisposition>(disposition);
        receipt.sequence = reader.u64("receipt sequence");
        receipt.record_digest = reader.digest("receipt record digest");
        reader.eof();
        validate_delivery_receipt(receipt);
        return receipt;
    }
    if (kind == kErrorKind) {
        ProtocolError error;
        const auto has_operation = reader.u8("error operation presence");
        if (has_operation > 1U) {
            app_fail("INVALID_PROTOCOL_ERROR", "invalid operation presence flag");
        }
        if (has_operation == 1U) {
            error.operation_id = reader.digest("error operation ID");
        }
        error.code = reader.text16("error code", 64U);
        error.detail = reader.text16("error detail", 512U);
        reader.eof();
        validate_protocol_error(error);
        return error;
    }
    if (kind == kRemoteSourceRequestKind ||
        kind == kRemoteSourceLeaseRequestKind) {
        RemoteSourceSubscriptionRequest request;
        request.request_id = reader.digest("remote subscription request ID");
        const auto raw_command = reader.u8("remote subscription command");
        if (raw_command < static_cast<std::uint8_t>(
                RemoteSourceSubscriptionCommand::request) ||
            raw_command > static_cast<std::uint8_t>(
                RemoteSourceSubscriptionCommand::withdraw)) {
            app_fail("SOURCE_SUBSCRIPTION_REMOTE_INVALID",
                "unknown remote subscription command");
        }
        request.command =
            static_cast<RemoteSourceSubscriptionCommand>(raw_command);
        request.grant = reader.text16("remote subscription grant", 64U);
        request.reason = reader.text16("remote subscription reason", 256U);
        if (kind == kRemoteSourceLeaseRequestKind) {
            request.lease_generation = reader.text16(
                "remote subscription lease generation", 64U);
            const auto has_instance = reader.u8(
                "remote subscription instance marker");
            if (has_instance > 1U) {
                app_fail("SOURCE_SUBSCRIPTION_REMOTE_INVALID",
                    "remote subscription instance marker rejected");
            }
            if (has_instance == 1U) {
                request.instance = reader.digest(
                    "remote subscription instance");
            }
            request.expected_revision = reader.u64(
                "remote subscription expected revision");
        }
        reader.eof();
        validate_remote_source_subscription_request(request);
        return request;
    }
    if (kind == kRemoteSourceResponseKind ||
        kind == kRemoteSourceLeaseResponseKind) {
        RemoteSourceSubscriptionResponse response;
        response.request_id = reader.digest("remote response request ID");
        response.provider = reader.text16("remote response provider", 64U);
        response.grant = reader.text16("remote response grant", 64U);
        response.instance = reader.digest("remote response instance");
        response.revision = reader.u64("remote response revision");
        const auto retired = reader.u8("remote response retired marker");
        if (retired > 1U) {
            app_fail("SOURCE_SUBSCRIPTION_REMOTE_RESPONSE_INVALID",
                "retired marker must be zero or one");
        }
        response.retired = retired != 0U;
        response.disposition =
            reader.text16("remote response disposition", 32U);
        response.issued = reader.u32("remote response issued count");
        response.acknowledged =
            reader.u32("remote response acknowledged count");
        response.used_payload_bytes =
            reader.u64("remote response used payload bytes");
        response.maximum_records =
            reader.u32("remote response record budget");
        response.maximum_payload_bytes =
            reader.u64("remote response byte budget");
        response.grant_digest = reader.digest("remote response grant digest");
        response.subscriber_generation =
            reader.text16("remote response subscriber generation", 64U);
        response.subscriber_spki =
            reader.digest("remote response subscriber SPKI");
        response.accepted_request_id =
            reader.digest("remote response accepted request ID");
        response.accepted_configuration_event =
            reader.u64("remote response accepted configuration event");
        response.accepted_unix_ms =
            reader.u64("remote response accepted time");
        if (kind == kRemoteSourceLeaseResponseKind) {
            response.lease_generation = reader.text16(
                "remote response lease generation", 64U);
            response.lease_expires_unix_ms = reader.u64(
                "remote response lease expiry");
            response.withdrawal_policy = reader.text16(
                "remote response withdrawal policy", 16U);
            response.terminal_kind = reader.text16(
                "remote response terminal kind", 16U);
            response.terminal_pending_disposition = reader.text16(
                "remote response terminal pending disposition", 16U);
            const auto has_cancelled = reader.u8(
                "remote response cancellation marker");
            if (has_cancelled > 1U) {
                app_fail("SOURCE_SUBSCRIPTION_REMOTE_RESPONSE_INVALID",
                    "remote response cancellation marker rejected");
            }
            if (has_cancelled == 1U) {
                response.terminal_cancelled_operation = reader.digest(
                    "remote response cancelled operation");
            }
            response.terminal_reason = reader.text16(
                "remote response terminal reason", 256U);
        }
        reader.eof();
        validate_remote_source_subscription_response(response);
        return response;
    }
    if (kind == kCustodyTransferOfferKind) {
        CustodyTransferOffer offer;
        offer.request_id = reader.digest("custody offer request ID");
        offer.signed_offer = reader.blob32(
            "custody signed offer", kMaximumCustodySessionWireBytes);
        reader.eof();
        validate_custody_transfer_offer(offer);
        return offer;
    }
    if (kind == kCustodyTransferAcceptanceKind) {
        CustodyTransferAcceptance acceptance;
        acceptance.request_id = reader.digest("custody acceptance request ID");
        acceptance.signed_acceptance = reader.blob32(
            "custody signed acceptance", kMaximumCustodySessionWireBytes);
        reader.eof();
        validate_custody_transfer_acceptance(acceptance);
        return acceptance;
    }
    app_fail("APPLICATION_KIND_REJECTED", "unknown application message kind");
}

std::optional<datacube::Digest32> application_message_operation_id(
    const ApplicationMessage& message) noexcept {
    if (const auto* record = std::get_if<EvidenceRecord>(&message)) {
        return record->operation_id;
    }
    if (const auto* receipt = std::get_if<DeliveryReceipt>(&message)) {
        return receipt->operation_id;
    }
    if (const auto* error = std::get_if<ProtocolError>(&message)) {
        return error->operation_id;
    }
    if (const auto* request =
            std::get_if<RemoteSourceSubscriptionRequest>(&message)) {
        return request->request_id;
    }
    if (const auto* response =
            std::get_if<RemoteSourceSubscriptionResponse>(&message)) {
        return response->request_id;
    }
    if (const auto* offer = std::get_if<CustodyTransferOffer>(&message)) {
        return offer->request_id;
    }
    if (const auto* acceptance =
            std::get_if<CustodyTransferAcceptance>(&message)) {
        return acceptance->request_id;
    }
    return std::nullopt;
}

datacube::Digest32 evidence_record_digest(const EvidenceRecord& record) {
    const auto encoded = encode_record(record);
    datacube::Octets input;
    constexpr std::string_view domain = "NATRAV_OVERLAY_EVIDENCE_RECORD_V1";
    input.reserve(domain.size() + 1U + encoded.size());
    datacube::append_text(input, domain);
    datacube::append_u8(input, 0U);
    datacube::append_octets(input, encoded);
    return datacube::sha256(input);
}

std::string_view receipt_disposition_name(
    const ReceiptDisposition disposition) noexcept {
    switch (disposition) {
        case ReceiptDisposition::committed: return "COMMITTED";
        case ReceiptDisposition::duplicate: return "DUPLICATE";
    }
    return "UNKNOWN";
}

datacube::Octets encode_counter_add_request(
    const CounterAddRequest& request) {
    if (request.amount < 1U || request.amount > 1'000'000'000'000ULL ||
        request.defer_ms > 2'592'000'000U) {
        app_fail("ACTION_REQUEST_INVALID",
            "counter action amount or defer interval is outside the envelope");
    }
    datacube::Octets payload;
    payload.reserve(16U);
    datacube::append_octets(payload, kCounterActionMagic);
    datacube::append_be64(payload, request.amount);
    datacube::append_be32(payload, request.defer_ms);
    return payload;
}

CounterAddRequest decode_counter_add_request(
    const datacube::OctetView payload) {
    if (payload.size() != 16U ||
        !std::equal(kCounterActionMagic.begin(), kCounterActionMagic.end(),
            payload.begin())) {
        app_fail("ACTION_REQUEST_INVALID",
            "counter action payload must be the exact NCA1 binary schema");
    }
    Reader reader(payload.subspan(4U));
    const CounterAddRequest request{
        .amount = reader.u64("counter amount"),
        .defer_ms = reader.u32("counter defer interval"),
    };
    reader.eof();
    if (request.amount < 1U || request.amount > 1'000'000'000'000ULL ||
        request.defer_ms > 2'592'000'000U) {
        app_fail("ACTION_REQUEST_INVALID",
            "counter action amount or defer interval is outside the envelope");
    }
    return request;
}

bool is_counter_add_record(const EvidenceRecord& record) noexcept {
    return record.scope == kCounterAddActionScope;
}

}  // namespace natrav_overlay
