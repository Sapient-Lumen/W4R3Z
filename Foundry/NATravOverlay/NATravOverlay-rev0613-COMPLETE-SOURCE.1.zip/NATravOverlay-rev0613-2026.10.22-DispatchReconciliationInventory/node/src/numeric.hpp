#pragma once
#include "common.hpp"
#include <array>

namespace natrav_overlay {
// Exact decimal ticks. No floating point, locale, unit conversion or expressions.
inline constexpr std::int64_t kNumericValueLimit = 1'000'000'000'000LL;
inline constexpr std::uint64_t kNumericSumLimit = 1'000'000'000'000'000'000ULL;
struct NumericDefinition final {
    std::string unit;
    std::uint8_t scale{0U};
    std::uint64_t maximum_absolute_sum{kNumericSumLimit};
    bool operator==(const NumericDefinition&) const = default;
};
enum class NumericOutcome : std::uint8_t { accepted=0U, malformed=1U, unit_mismatch=2U, scale_mismatch=3U, value_range=4U };
struct NumericObservation final {
    NumericOutcome outcome{NumericOutcome::malformed};
    std::int64_t ticks{0};
};
struct NumericTotals final {
    std::uint64_t accepted{0U}, rejected{0U}, valid_heads{0U}, invalid_heads{0U};
    std::int64_t sum_ticks{0};
    std::array<std::uint64_t,4U> errors{};
    bool operator==(const NumericTotals&) const = default;
};
[[nodiscard]] bool valid_numeric_unit(std::string_view unit) noexcept;
void validate_numeric_definition(const NumericDefinition& definition);
[[nodiscard]] std::string_view numeric_outcome_name(NumericOutcome outcome);
[[nodiscard]] NumericObservation decode_numeric_observation(datacube::OctetView bytes,
    const NumericDefinition& definition) noexcept;
[[nodiscard]] datacube::Octets encode_numeric_observation(const NumericDefinition& definition, std::int64_t ticks);
// Updates a local candidate only; caller commits candidate+progress atomically.
void apply_numeric_observation(NumericTotals& totals, const NumericObservation& source,
    const NumericObservation* parent, const NumericDefinition& definition);
[[nodiscard]] datacube::Octets encode_numeric_definition(const NumericDefinition& definition);
[[nodiscard]] NumericDefinition decode_numeric_definition(datacube::Reader& reader);
} // namespace natrav_overlay
