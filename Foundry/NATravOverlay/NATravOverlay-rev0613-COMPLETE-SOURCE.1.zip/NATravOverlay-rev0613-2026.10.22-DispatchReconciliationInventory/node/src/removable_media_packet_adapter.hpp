#pragma once

namespace natrav_overlay {

inline constexpr char kRemovableMediaPacketAdapterMarker[] =
    "REMOVABLE_MEDIA_PACKET_ADAPTER_V1";

// Runs one explicitly pinned removable-media adapter role inside the existing
// product executable. The role opens no node state, peer identity, journal, or
// local-control endpoint; it exchanges bounded complete datagrams only over
// the inherited descriptor-3 NAPA0001 supervision channel.
[[nodiscard]] int run_removable_media_packet_adapter(int argc, char* argv[]);

}  // namespace natrav_overlay
