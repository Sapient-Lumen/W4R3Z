#pragma once

#include "backup.hpp"
#include "state_head_custody.hpp"
#include "state_recovery.hpp"

#include <string>

namespace natrav_overlay {

struct StateDirectoryCustodyPromotionOptions final {
    StateHeadCustodyPromotionOptions custody;
    StateAuditOptions source;
};

struct BackupCustodyPromotionOptions final {
    StateHeadCustodyPromotionOptions custody;
    BackupVerifyOptions source;
};

struct StateDirectoryCustodyPromotionAuditOptions final {
    StateHeadCustodyPromotionAuditOptions custody;
    StateAuditOptions source;
};

struct BackupCustodyPromotionAuditOptions final {
    StateHeadCustodyPromotionAuditOptions custody;
    BackupVerifyOptions source;
};

struct StateDirectoryCustodyPromotionIntentCreateOptions final {
    StateHeadCustodyPromotionIntentCreateOptions intent;
    StateAuditOptions source;
};

struct BackupCustodyPromotionIntentCreateOptions final {
    StateHeadCustodyPromotionIntentCreateOptions intent;
    BackupVerifyOptions source;
};

struct StateDirectoryCustodyPromotionIntentUseOptions final {
    StateHeadCustodyPromotionIntentUseOptions intent;
    StateAuditOptions source;
};

struct BackupCustodyPromotionIntentUseOptions final {
    StateHeadCustodyPromotionIntentUseOptions intent;
    BackupVerifyOptions source;
};

[[nodiscard]] std::string promote_state_head_custody_from_state(
    const StateDirectoryCustodyPromotionOptions& options);
[[nodiscard]] std::string promote_state_head_custody_from_backup(
    const BackupCustodyPromotionOptions& options);
[[nodiscard]] std::string audit_state_head_custody_promotion_from_state(
    const StateDirectoryCustodyPromotionAuditOptions& options);
[[nodiscard]] std::string audit_state_head_custody_promotion_from_backup(
    const BackupCustodyPromotionAuditOptions& options);
[[nodiscard]] std::string create_state_head_custody_promotion_intent_from_state(
    const StateDirectoryCustodyPromotionIntentCreateOptions& options);
[[nodiscard]] std::string create_state_head_custody_promotion_intent_from_backup(
    const BackupCustodyPromotionIntentCreateOptions& options);
[[nodiscard]] std::string promote_state_head_custody_from_state_with_intent(
    const StateDirectoryCustodyPromotionIntentUseOptions& options);
[[nodiscard]] std::string promote_state_head_custody_from_backup_with_intent(
    const BackupCustodyPromotionIntentUseOptions& options);
[[nodiscard]] std::string audit_state_head_custody_promotion_from_state_with_intent(
    const StateDirectoryCustodyPromotionIntentUseOptions& options);
[[nodiscard]] std::string audit_state_head_custody_promotion_from_backup_with_intent(
    const BackupCustodyPromotionIntentUseOptions& options);

}  // namespace natrav_overlay
