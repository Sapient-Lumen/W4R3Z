#pragma once
#include "protocol.hpp"
#include <cstdint>
#include <string>
#include <vector>

namespace natrav_overlay {
inline constexpr std::size_t kResultReviewLimit = 128U;
inline constexpr std::size_t kResultReviewUidLimit = 16U;
inline constexpr std::size_t kResultReviewCandidateLimit = 128U;
inline constexpr std::size_t kResultReviewEncodedLimit = 32768U;
// Conditions describe observations, not authority. The server recomputes every
// candidate classification; a discovery cursor is never accepted as evidence.
struct ResultReviewRequest final {
    datacube::Digest32 request_operation_id{};
    std::string provider, scope;
    std::uint64_t candidate_count{0U};
    datacube::Digest32 candidate_root{}, request_binding{}, configuration{};
    std::string reason;
};
struct ResultReviewStatus final { datacube::Digest32 review_id{}; };
struct ResultReviewCandidate final {
    datacube::Digest32 operation{}, record_digest{};
    std::string rejection; // empty means the shared validator accepted it
    bool operator==(const ResultReviewCandidate&) const = default;
};
struct ResultReviewRecord final {
    ResultReviewRequest request;
    datacube::Digest32 id{};
    std::uint32_t uid{0U}, gid{0U}, pid{0U};
    std::uint64_t unix_ms{0U}, configuration_event{0U};
    std::uint64_t inbound_through{0U}, mutation_through{0U};
    datacube::Digest32 mutation_prefix{};
    std::uint64_t original_transition_count{0U};
    std::string original_generation;
    datacube::Digest32 original_spki{};
    std::optional<DeliveryReceipt> original_receipt;
    std::vector<ResultReviewCandidate> candidates;
};
// Listing is an observational exact-domain operation. Its prefix is a content
// commitment, not authorization, a newest-state witness, or a mutation selector.
struct ResultReviewHistory final {
    datacube::Digest32 request_operation_id{};
    std::string provider, scope;
    std::optional<datacube::Digest32> review_id;
    std::uint64_t offset{0U};
    std::uint32_t limit{8U}, maximum_bytes{32768U};
    std::optional<std::uint64_t> through;
    std::optional<datacube::Digest32> prefix;
};
struct ResultReviewHistoryEntry final {
    std::size_t record_index{0U};
    datacube::Digest32 record_digest{}, reason_digest{}, prefix{};
    std::uint64_t consistent{0U};
    std::optional<datacube::Digest32> unique_operation;
};
void validate_result_review_history(const ResultReviewHistory&);
[[nodiscard]] datacube::Octets encode_result_review_history(const ResultReviewHistory&);
[[nodiscard]] ResultReviewHistory decode_result_review_history(datacube::OctetView);
void validate_result_review(const ResultReviewRequest&);
[[nodiscard]] datacube::Octets encode_result_review(const ResultReviewRequest&);
[[nodiscard]] ResultReviewRequest decode_result_review(datacube::OctetView);
[[nodiscard]] datacube::Octets encode_result_review_status(const ResultReviewStatus&);
[[nodiscard]] ResultReviewStatus decode_result_review_status(datacube::OctetView);
[[nodiscard]] datacube::Digest32 result_review_id(const ResultReviewRequest&, std::uint32_t uid);
[[nodiscard]] datacube::Octets encode_result_review_record(const ResultReviewRecord&);
[[nodiscard]] ResultReviewRecord decode_result_review_record(datacube::OctetView);
} // namespace natrav_overlay
