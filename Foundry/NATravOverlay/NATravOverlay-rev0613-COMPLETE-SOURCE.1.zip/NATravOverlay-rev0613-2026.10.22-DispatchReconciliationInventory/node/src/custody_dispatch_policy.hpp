#pragma once

#include "custody_receiver_policy.hpp"

#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

inline constexpr std::string_view kCustodyDispatchActivationFeature =
    "V24_EXPLICIT_OWNER_CUSTODY_DISPATCH_V1";
inline constexpr std::size_t kCustodyDispatchActivationLimit = 128U;
inline constexpr std::size_t kCustodyDispatchActivationPerIdLimit = 16U;
inline constexpr std::uint32_t kCustodyDispatchMaximumConcurrent = 64U;
inline constexpr std::uint32_t kCustodyDispatchMaximumAttempts = 64U;

enum class CustodyDispatchActivationState : std::uint8_t {
    active = 1U,
    retired = 2U,
    revoked = 3U,
};

// Default-off authority for one synchronous owner-requested custody attempt.
// This record grants no queue, timer, discovery, route search, fallback,
// background retry, onward-forwarding, export, or delivery-inference power.
struct CustodyDispatchActivation final {
    std::string id;
    std::uint64_t generation{1U};
    datacube::Digest32 predecessor;
    CustodyDispatchActivationState state{
        CustodyDispatchActivationState::active};
    std::string receiver_activation_id;
    std::uint64_t receiver_activation_generation{1U};
    datacube::Digest32 receiver_activation_commitment;
    std::string outbound_session_rule_id;
    std::uint64_t outbound_session_rule_generation{1U};
    datacube::Digest32 outbound_session_rule_commitment;
    std::string route_id;
    datacube::Digest32 route_commitment;
    std::uint32_t maximum_concurrent_dispatches{1U};
    std::uint32_t maximum_dispatch_attempts{1U};
    std::uint64_t activation_expires_unix_ms{0U};
};

using CustodyDispatchPolicy = std::vector<CustodyDispatchActivation>;

[[nodiscard]] std::string_view custody_dispatch_activation_state_name(
    CustodyDispatchActivationState state);
[[nodiscard]] std::string custody_dispatch_route_commitment_text(
    std::string_view peer_node,
    std::string_view route_id,
    std::string_view locator,
    std::uint32_t priority);
[[nodiscard]] datacube::Digest32 custody_dispatch_route_commitment(
    std::string_view peer_node,
    std::string_view route_id,
    std::string_view locator,
    std::uint32_t priority);
[[nodiscard]] std::string custody_dispatch_activation_commitment_text(
    const CustodyDispatchActivation& activation);
[[nodiscard]] datacube::Digest32 custody_dispatch_activation_commitment(
    const CustodyDispatchActivation& activation);
[[nodiscard]] std::string custody_dispatch_activation_text(
    const CustodyDispatchActivation& activation);
[[nodiscard]] CustodyDispatchActivation parse_custody_dispatch_activation(
    std::string_view hex);
void normalize_custody_dispatch_policy(CustodyDispatchPolicy& activations);
void require_custody_dispatch_history_preserved(
    const CustodyDispatchPolicy& historical,
    const CustodyDispatchPolicy& candidate);
[[nodiscard]] const CustodyDispatchActivation*
find_custody_dispatch_activation(
    const CustodyDispatchPolicy& policy,
    std::string_view id,
    std::uint64_t generation) noexcept;
[[nodiscard]] const CustodyReceiverActivation&
resolve_custody_dispatch_receiver_activation(
    const CustodyReceiverPolicy& receivers,
    const CustodyDispatchActivation& activation,
    bool require_active);
[[nodiscard]] const CustodySessionRule&
resolve_custody_dispatch_outbound_rule(
    const CustodySessionPolicy& rules,
    const CustodyDispatchActivation& activation,
    bool require_active);
[[nodiscard]] std::string custody_dispatch_policy_json(
    const CustodyDispatchPolicy& policy);

} // namespace natrav_overlay
