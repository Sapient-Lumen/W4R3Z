#include "removable_media_bundle.hpp"

#include <algorithm>
#include <array>
#include <limits>
#include <utility>

namespace natrav_overlay::removable_media {
namespace {

constexpr std::array<std::uint8_t, 8U> kMagic{
    'N', 'R', 'M', 'B', '0', '0', '0', '1'};

[[noreturn]] void fail(std::string code, std::string detail) {
    throw BundleError(std::move(code), std::move(detail));
}

[[nodiscard]] bool equal_digest(
    const datacube::Digest32& left,
    const datacube::Digest32& right) noexcept {
    return left == right;
}

}  // namespace

BundleError::BundleError(std::string code, std::string detail)
    : std::runtime_error(std::move(detail)), code_(std::move(code)) {}

const std::string& BundleError::code() const noexcept { return code_; }

void Settings::validate() const {
    if (mtu < 256U || mtu > 65'507U) {
        fail("REMOVABLE_MEDIA_SETTINGS_INVALID", "MTU is outside 256..65507");
    }
    if (link == 0U || epoch == 0U) {
        fail("REMOVABLE_MEDIA_SETTINGS_INVALID", "link and epoch must be nonzero");
    }
    if (lifetime_ms < 1'000U || lifetime_ms > 604'800'000U) {
        fail("REMOVABLE_MEDIA_SETTINGS_INVALID", "bundle lifetime is outside 1 second..7 days");
    }
}

datacube::Octets encode(
    const Settings& settings,
    const std::span<const std::uint8_t> payload,
    const std::uint64_t created_ms) {
    settings.validate();
    if (payload.empty() || payload.size() > settings.mtu) {
        fail("REMOVABLE_MEDIA_PAYLOAD_INVALID", "payload is empty or exceeds the MTU");
    }
    if (created_ms > std::numeric_limits<std::uint64_t>::max() - settings.lifetime_ms) {
        fail("REMOVABLE_MEDIA_TIME_INVALID", "bundle expiry overflows");
    }
    const auto expires_ms = created_ms + settings.lifetime_ms;
    datacube::Octets output;
    output.reserve(kBundleOverheadBytes + payload.size());
    output.insert(output.end(), kMagic.begin(), kMagic.end());
    datacube::append_be32(output, 0U);
    datacube::append_be64(output, settings.link);
    datacube::append_be32(output, settings.epoch);
    datacube::append_be64(output, created_ms);
    datacube::append_be64(output, expires_ms);
    datacube::append_be32(output, static_cast<std::uint32_t>(payload.size()));
    output.insert(output.end(), payload.begin(), payload.end());
    const auto digest = datacube::sha256(output);
    output.insert(output.end(), digest.octets.begin(), digest.octets.end());
    return output;
}

DecodedBundle decode(
    const Settings& settings,
    const std::span<const std::uint8_t> bytes,
    const datacube::Digest32& filename_digest,
    const std::uint64_t now_ms) {
    settings.validate();
    if (bytes.size() < kBundleOverheadBytes ||
        bytes.size() > kBundleOverheadBytes + settings.mtu) {
        fail("REMOVABLE_MEDIA_BUNDLE_INVALID", "bundle size is outside bounds");
    }
    datacube::Reader reader(bytes, "removable-media bundle");
    const auto magic = reader.read_exact(kMagic.size(), "magic");
    if (!std::equal(kMagic.begin(), kMagic.end(), magic.begin())) {
        fail("REMOVABLE_MEDIA_BUNDLE_INVALID", "bundle magic mismatch");
    }
    if (reader.read_be32("reserved") != 0U) {
        fail("REMOVABLE_MEDIA_BUNDLE_INVALID", "reserved field is nonzero");
    }
    if (reader.read_be64("link") != settings.link ||
        reader.read_be32("epoch") != settings.epoch) {
        fail("REMOVABLE_MEDIA_BUNDLE_WRONG_LINK", "bundle link or epoch does not match this adapter");
    }
    const auto created_ms = reader.read_be64("created milliseconds");
    const auto expires_ms = reader.read_be64("expiry milliseconds");
    const auto payload_bytes = reader.read_be32("payload bytes");
    if (payload_bytes == 0U || payload_bytes > settings.mtu ||
        reader.remaining() != static_cast<std::size_t>(payload_bytes) + kBundleDigestBytes) {
        fail("REMOVABLE_MEDIA_BUNDLE_INVALID", "payload length is noncanonical");
    }
    if (created_ms > std::numeric_limits<std::uint64_t>::max() - settings.lifetime_ms ||
        expires_ms != created_ms + settings.lifetime_ms) {
        fail("REMOVABLE_MEDIA_BUNDLE_INVALID", "bundle lifetime is noncanonical");
    }
    if (created_ms > now_ms && created_ms - now_ms > kMaximumClockSkewMs) {
        fail("REMOVABLE_MEDIA_BUNDLE_FUTURE", "bundle creation time is too far in the future");
    }
    if (now_ms > expires_ms) {
        fail("REMOVABLE_MEDIA_BUNDLE_EXPIRED", "bundle expired before admission");
    }
    const auto payload = reader.read_exact(payload_bytes, "payload");
    const auto trailer = reader.read_exact(kBundleDigestBytes, "bundle digest");
    reader.require_eof("bundle");
    datacube::Digest32 trailer_digest{};
    std::copy(trailer.begin(), trailer.end(), trailer_digest.octets.begin());
    const auto computed = datacube::sha256(bytes.first(bytes.size() - kBundleDigestBytes));
    if (!equal_digest(computed, trailer_digest) ||
        !equal_digest(computed, filename_digest)) {
        fail("REMOVABLE_MEDIA_BUNDLE_DIGEST_MISMATCH", "bundle content and filename digest differ");
    }
    return DecodedBundle{
        .payload = datacube::Octets(payload.begin(), payload.end()),
        .digest = computed,
        .created_ms = created_ms,
        .expires_ms = expires_ms,
    };
}

std::string filename(const datacube::Digest32& digest) {
    return datacube::hex_lower(digest) + ".nrmb";
}

std::optional<datacube::Digest32> parse_filename(
    const std::string_view name) noexcept {
    if (name.size() != 69U || !name.ends_with(".nrmb")) {
        return std::nullopt;
    }
    try {
        return datacube::parse_hex_digest32(name.substr(0U, 64U), "removable-media filename");
    } catch (...) {
        return std::nullopt;
    }
}

}  // namespace natrav_overlay::removable_media
