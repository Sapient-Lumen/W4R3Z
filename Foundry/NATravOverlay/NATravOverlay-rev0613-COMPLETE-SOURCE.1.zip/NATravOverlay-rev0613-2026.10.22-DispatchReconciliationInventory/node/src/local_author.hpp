#pragma once

#include "protocol.hpp"
#include "local_control.hpp"
#include <cstdint>
#include <string>
#include <vector>

namespace natrav_overlay {
struct LocalAuthorGrant final {
    std::uint32_t uid{0U};
    std::string scope;
    datacube::Digest32 digest;
    bool operator==(const LocalAuthorGrant&) const = default;
};
struct LocalAuthorPolicy final {
    std::vector<LocalAuthorGrant> grants;
    datacube::Digest32 digest;
};
struct LocalAuthorship final {
    std::uint32_t uid{0U};
    std::uint32_t gid{0U};
    std::uint32_t pid{0U};
    std::uint64_t authored_unix_ms{0U};
    std::uint64_t configuration_event{0U};
    datacube::Digest32 configuration_digest;
    datacube::Digest32 policy_digest;
    datacube::Digest32 rule_digest;
    datacube::Digest32 request_digest;
    bool operator==(const LocalAuthorship&) const = default;
};
[[nodiscard]] LocalAuthorPolicy make_local_author_policy(
    const std::vector<std::string>& values, const LocalControlPolicy& control,
    bool enabled);
[[nodiscard]] const LocalAuthorGrant* local_author_grant(
    const LocalAuthorPolicy& policy, std::uint32_t uid, std::string_view scope);
[[nodiscard]] datacube::Octets encode_local_authorship(const LocalAuthorship& value);
[[nodiscard]] LocalAuthorship decode_local_authorship(datacube::Reader& reader);
[[nodiscard]] datacube::Digest32 local_author_request_digest(const EvidenceRecord& record);
[[nodiscard]] std::string local_authorship_json(const LocalAuthorship& value);
[[nodiscard]] std::string local_author_policy_json(const LocalAuthorPolicy& policy);
} // namespace natrav_overlay
