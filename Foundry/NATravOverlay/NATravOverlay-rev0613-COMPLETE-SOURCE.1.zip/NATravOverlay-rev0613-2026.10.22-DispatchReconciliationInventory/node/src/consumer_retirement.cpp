#include "journal.hpp"
#include "config.hpp"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <thread>

namespace natrav_overlay {
namespace {
bool printable(std::string_view text) {
    return !text.empty() && text.size()<=256U &&
        std::all_of(text.begin(),text.end(),[](char c){return c>=32 && c<=126;});
}
[[noreturn]] void corrupt() {
    app_fail("JOURNAL_CORRUPT","retirement violated immutable final state, authority, schedule or capacity");
}
void require_admin(const RuntimeConfig& cfg,std::uint32_t uid) {
    // Retirement is an owner-administrative stop, not a payload read or a grant
    // to execute the old definition. It remains usable after read revocation.
    if(cfg.format_version<11U || !local_control_allows(cfg.local_control,uid,LocalControlClass::consumer_admin)) {
        app_fail("LOCAL_CONTROL_CLASS_DENIED","retirement requires explicit CONSUMER_ADMIN for this exact owner");
    }
}
datacube::Digest32 commitment(std::string_view domain,datacube::OctetView bytes) {
    datacube::Octets input;datacube::append_text(input,domain);datacube::append_u8(input,0U);
    datacube::append_octets(input,bytes);return datacube::sha256(input);
}
datacube::Digest32 frozen_digest(const DurableConsumer& value) {
    auto base=value;base.retirement.reset();return commitment("NATRAV_OVERLAY_RETIRED_CONSUMER_V1",encode_consumer(base));
}
datacube::Digest32 schedule_digest(const std::optional<ProjectionSchedule>& value) {
    return value?commitment("NATRAV_OVERLAY_RETIRED_SCHEDULE_V1",encode_projection_schedule(*value)):datacube::Digest32{};
}
std::optional<ProjectionSchedule> retire_schedule(std::optional<ProjectionSchedule> value,const ConsumerRetirement& r,std::uint32_t uid) {
    if(value && value->grants.back().state=="ENABLED") {
        if(value->revision==std::numeric_limits<std::uint64_t>::max()){app_fail("PROJECTION_SCHEDULE_LIMIT","schedule revision exhausted");}
        ++value->revision;value->transition="RETIRE";value->configuration_event=r.configuration_event;
        value->unix_ms=r.unix_ms;value->pid=r.pid;value->executor_uid=uid;
        auto& grant=value->grants.back();grant.state="RETIRED";grant.error=r.reason;
        grant.ended_event=r.configuration_event;grant.ended_unix_ms=r.unix_ms;grant.ended_uid=uid;grant.ended_pid=r.pid;
    }
    return value;
}
void validate_retirement(const DurableConsumer& c,const std::optional<ProjectionSchedule>& schedule,const RuntimeConfig& cfg) {
    if(!c.retirement){corrupt();}
    const auto& r=*c.retirement;require_admin(cfg,c.uid);
    if(c.revision==std::numeric_limits<std::uint64_t>::max() || r.revision!=c.revision+1U ||
        r.configuration_event<c.configuration_event || r.unix_ms==0U || r.pid==0U || !printable(r.reason) ||
        r.abandoned_pending!=c.pending.has_value() || r.final_consumer_digest!=frozen_digest(c) ||
        r.final_schedule_digest!=schedule_digest(schedule)) {corrupt();}
    if(!schedule){if(r.previous_schedule_revision!=0U){corrupt();}return;}
    const auto& s=*schedule;
    if(s.uid!=c.uid || s.name!=c.name || s.instance!=c.instance || s.grants.empty() || s.configuration_event>r.configuration_event || s.grants.back().state=="ENABLED"){corrupt();}
    if(s.transition=="RETIRE") {
        const auto& g=s.grants.back();
        if(r.previous_schedule_revision==std::numeric_limits<std::uint64_t>::max() || s.revision!=r.previous_schedule_revision+1U ||
            s.configuration_event!=r.configuration_event || s.unix_ms!=r.unix_ms || s.pid!=r.pid || s.executor_uid!=c.uid ||
            g.state!="RETIRED" || g.error!=r.reason || g.ended_event!=r.configuration_event || g.ended_unix_ms!=r.unix_ms ||
            g.ended_pid!=r.pid || g.ended_uid!=c.uid) {corrupt();}
    }else if(s.revision!=r.previous_schedule_revision || s.grants.back().state=="RETIRED"){corrupt();}
}
void pause_test(const char* name) {
    if(const char* value=std::getenv(name);value && *value) {
        std::fprintf(stderr,"RETIREMENT_TEST_BOUNDARY %s\n",name);std::fflush(stderr);
        std::this_thread::sleep_for(std::chrono::milliseconds(parse_u64(value,name,1U,60000U)));
    }
}
std::uint64_t now_ms() {
    return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count());
}
} // namespace

std::string consumer_retirement_json(const ConsumerRetirement& r) {
    return "{\"lifecycle_revision\":"+std::to_string(r.revision)+",\"configuration_event\":"+std::to_string(r.configuration_event)+
        ",\"unix_ms\":"+std::to_string(r.unix_ms)+",\"pid\":"+std::to_string(r.pid)+
        ",\"actor\":\"KERNEL_AUTHENTICATED_OWNER\",\"reason\":"+json_string(r.reason)+
        ",\"pending_disposition\":"+json_string(r.abandoned_pending?"ABANDONED_UNACKNOWLEDGED":"NO_ISSUED_PAGE")+
        ",\"unread_disposition\":\"NOT_ACKNOWLEDGED\",\"name_reuse\":\"FORBIDDEN\",\"previous_schedule_revision\":"+std::to_string(r.previous_schedule_revision)+
        ",\"final_consumer_digest\":"+json_string(datacube::hex_lower(r.final_consumer_digest))+
        ",\"final_schedule_digest\":"+json_string(datacube::hex_lower(r.final_schedule_digest))+"}";
}
void NodeState::validate_consumer_registry_locked() const {
    std::size_t active=0U,retired=0U;std::map<std::uint32_t,std::pair<std::size_t,std::size_t>> owners;
    for(const auto& [key,c]:consumers_) {
        if(key!=consumer_key(c.uid,c.name)){corrupt();}
        auto& own=owners[c.uid];
        if(c.retirement){++retired;++own.second;}else{++active;++own.first;}
        if(own.first>kConsumerUidLimit || own.second>kRetiredConsumerUidLimit){corrupt();}
    }
    if(active>kConsumerLimit || retired>kRetiredConsumerLimit){corrupt();}
}
void NodeState::validate_consumer_retirement_locked(const DurableConsumer& c) const {
    if(!c.retirement){return;}
    const auto event=c.retirement->configuration_event;
    if(event==0U || event>configuration_events_.size() || configuration_events_[event-1U].kind=="REJECTED"){corrupt();}
    const auto cfg=parse_runtime_config(configuration_events_[event-1U].canonical,"/retirement-history",IdentityFileValidation::deferred);
    const auto found=projection_schedules_.find(consumer_key(c.uid,c.name));
    validate_retirement(c,found==projection_schedules_.end()?std::nullopt:std::optional(found->second),cfg);
}
void NodeState::apply_consumer_retirement(datacube::OctetView bytes,const bool validate_only) {
    datacube::Reader r(bytes,"consumer retirement transaction");
    if(datacube::octets_text(r.read_exact(4U,"magic"),"magic",true)!="NRT1"){corrupt();}
    const auto n=r.read_be32("retired consumer size");if(n>kConsumerEncodedLimit){corrupt();}
    auto next=decode_consumer(r.read_exact(n,"retired consumer"));
    const auto m=r.read_be32("final schedule size");if(m>32000U){corrupt();}
    std::optional<ProjectionSchedule> schedule;if(m){schedule=decode_projection_schedule(r.read_exact(m,"final schedule"));}
    r.require_eof("retirement transaction");
    if(!next.retirement){corrupt();}const auto& t=*next.retirement;
    if(t.configuration_event==0U || t.configuration_event!=active_configuration_event(configuration_events_)){corrupt();}
    const auto key=consumer_key(next.uid,next.name);const auto it=consumers_.find(key);
    if(it==consumers_.end() || it->second.retirement){corrupt();}
    auto base=next;base.retirement.reset();
    if(encode_consumer(base)!=encode_consumer(it->second)){corrupt();}
    const auto prev=projection_schedules_.find(key);
    const auto old=prev==projection_schedules_.end()?std::nullopt:std::optional(prev->second);
    if(t.previous_schedule_revision!=(old?old->revision:0U)){corrupt();}
    const auto expected=retire_schedule(old,t,next.uid);
    if(schedule!=expected){corrupt();}
    const auto cfg=parse_runtime_config(configuration_events_[t.configuration_event-1U].canonical,"/retirement-commit",IdentityFileValidation::deferred);
    validate_consumer_locked(next);validate_retirement(next,schedule,cfg);
    std::size_t count=0U,own=0U;
    for(const auto& [name,c]:consumers_){static_cast<void>(name);if(c.retirement){++count;if(c.uid==next.uid){++own;}}}
    if(count>=kRetiredConsumerLimit || own>=kRetiredConsumerUidLimit){app_fail("CONSUMER_RETIREMENT_LIMIT","bounded retired-state archive is full; nothing discarded");}
    if(!validate_only){consumers_[key]=std::move(next);if(schedule){projection_schedules_[key]=std::move(*schedule);}}
}
std::string NodeState::consumer_retirement_command_locked(const ConsumerRequest& request,const EvidenceQueryContext& context,std::uint32_t pid,std::uint64_t event) {
    const auto cfg=parse_runtime_config(configuration_events_.at(event-1U).canonical,"/retirement-command",IdentityFileValidation::deferred);
    require_admin(cfg,context.uid);
    const auto key=consumer_key(context.uid,request.name);const auto it=consumers_.find(key);
    if(it==consumers_.end()){app_fail("CONSUMER_NOT_FOUND","no consumer with this name is owned by the connected UID");}
    auto disposition=std::string("STATUS");
    if(request.command==ConsumerCommand::retire) {
        const auto& current=it->second;const auto previous=projection_schedules_.find(key);
        const auto schedule=previous==projection_schedules_.end()?std::nullopt:std::optional(previous->second);
        const auto observed_schedule=current.retirement?current.retirement->previous_schedule_revision:(schedule?schedule->revision:0U);
        if(!request.expected_instance || *request.expected_instance!=current.instance || request.expected_revision!=current.revision || request.expected_schedule_revision!=observed_schedule) {
            app_fail("CONSUMER_RETIREMENT_CONFLICT","select exact instance, consumer revision and schedule revision");
        }
        if(current.retirement) {
            if(request.abandon_pending!=current.retirement->abandoned_pending || request.reason!=current.retirement->reason) {
                app_fail("CONSUMER_RETIREMENT_CONFLICT","retired name cannot accept a different terminal decision");
            }
            disposition="ALREADY_RETIRED";
        }else {
            if(request.abandon_pending!=current.pending.has_value()) {
                app_fail("CONSUMER_PENDING_DISPOSITION_REQUIRED","choose abandon for an issued page, require-empty otherwise; retirement never acknowledges it");
            }
            if(current.revision==std::numeric_limits<std::uint64_t>::max()){app_fail("CONSUMER_REVISION_LIMIT","retirement revision exhausted");}
            ConsumerRetirement t;t.revision=current.revision+1U;t.configuration_event=event;t.unix_ms=now_ms();t.pid=pid;
            t.previous_schedule_revision=observed_schedule;t.abandoned_pending=request.abandon_pending;t.reason=request.reason;
            t.final_consumer_digest=frozen_digest(current);auto final_schedule=retire_schedule(schedule,t,current.uid);t.final_schedule_digest=schedule_digest(final_schedule);
            auto next=current;next.retirement=t;const auto consumer=encode_consumer(next);
            const auto encoded_schedule=final_schedule?encode_projection_schedule(*final_schedule):datacube::Octets{};
            datacube::Octets record;datacube::append_text(record,"NRT1");datacube::append_be32(record,static_cast<std::uint32_t>(consumer.size()));datacube::append_octets(record,consumer);
            datacube::append_be32(record,static_cast<std::uint32_t>(encoded_schedule.size()));datacube::append_octets(record,encoded_schedule);
            apply_consumer_retirement(record,true);
            pause_test("NATRAV_OVERLAY_TEST_RETIREMENT_BEFORE_COMMIT_MS");
            append_entry(EntryKind::consumer_retirement,record);
            pause_test("NATRAV_OVERLAY_TEST_RETIREMENT_AFTER_COMMIT_MS");
            disposition="RETIRED";
        }
    }
    const auto& c=consumers_.at(key);const auto s=projection_schedules_.find(key);
    std::size_t active=0U,retired=0U;
    for(const auto& [name,v]:consumers_){static_cast<void>(name);if(v.uid==context.uid){if(v.retirement){++retired;}else{++active;}}}
    // This administrative view never includes payloads, source operation IDs,
    // adopted domains or numeric results. Full status retains read checks.
    return "{\"format\":\"NATRAV_OVERLAY_CONSUMER_RETIREMENT_V1\",\"ok\":true,\"disposition\":"+json_string(disposition)+
        ",\"consumer\":{\"name\":"+json_string(c.name)+",\"owner_uid\":"+std::to_string(c.uid)+",\"instance\":"+json_string(datacube::hex_lower(c.instance))+
        ",\"state\":"+json_string(c.retirement?"RETIRED":"ACTIVE")+",\"consumer_revision\":"+std::to_string(c.revision)+
        ",\"schedule_revision\":"+std::to_string(s==projection_schedules_.end()?0U:s->second.revision)+
        ",\"acknowledged_sequence\":"+std::to_string(c.position)+",\"pending_batch_id\":"+(c.pending?json_string(datacube::hex_lower(c.pending->id)):"null")+
        ",\"retirement\":"+(c.retirement?consumer_retirement_json(*c.retirement):"null")+"},\"owner_registry\":{\"active\":"+std::to_string(active)+
        ",\"retired\":"+std::to_string(retired)+",\"active_limit\":"+std::to_string(kConsumerUidLimit)+",\"retired_limit\":"+std::to_string(kRetiredConsumerUidLimit)+
        ",\"global_active_limit\":"+std::to_string(kConsumerLimit)+",\"global_retired_limit\":"+std::to_string(kRetiredConsumerLimit)+"}}";
}
} // namespace natrav_overlay
