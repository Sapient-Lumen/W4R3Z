#pragma once
#include "common.hpp"
#include <chrono>
#include <optional>
#include <string>

namespace natrav_overlay {
// Selection of accepted pins, not subscription authority or a mutation token.
struct ViewBindings final {
    std::string view;
    std::string presence{"all"};
    std::string grant;
    std::string envelope{"all"};
    std::optional<datacube::Digest32> instance, grant_digest, binding_digest, lineage_digest;
    std::uint32_t offset{0U}, limit{16U}, maximum_bytes{32768U};
    std::optional<datacube::Digest32> selection;
};
void validate_view_bindings(const ViewBindings&);
[[nodiscard]] datacube::Octets encode_view_bindings(const ViewBindings&);
[[nodiscard]] ViewBindings decode_view_bindings(datacube::OctetView);
} // namespace natrav_overlay
