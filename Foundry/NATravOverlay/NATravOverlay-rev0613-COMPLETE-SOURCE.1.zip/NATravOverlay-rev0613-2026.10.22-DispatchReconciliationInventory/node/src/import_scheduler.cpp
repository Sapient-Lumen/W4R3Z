#include "import_scheduler.hpp"
#include "journal.hpp"
#include "config.hpp"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <thread>
#include <limits>

namespace natrav_overlay {
namespace {
using Bytes=datacube::Octets;using View=datacube::OctetView;using Digest=datacube::Digest32;
void need(bool v,std::string_view code,std::string_view why){if(!v)app_fail(code,why);}
void text(Bytes& b,std::string_view v){need(v.size()<=256U,"IMPORT_AUTO_INVALID","bounded text required");datacube::append_be16(b,static_cast<std::uint16_t>(v.size()));datacube::append_text(b,v);}
std::string text(datacube::Reader& r,std::size_t bound=256U){auto n=r.read_be16("text size");need(n<=bound,"IMPORT_AUTO_INVALID","text limit");return datacube::octets_text(r.read_exact(n,"text"),"text",true);}
Digest digest(datacube::Reader& r){Digest d{};auto bytes=r.read_exact(32U,"digest");std::copy(bytes.begin(),bytes.end(),d.octets.begin());return d;}
Digest hash(std::string_view label,View v){Bytes b;datacube::append_text(b,label);datacube::append_u8(b,0U);datacube::append_octets(b,v);return datacube::sha256(b);}
void magic(datacube::Reader& r,std::string_view v){need(datacube::octets_text(r.read_exact(4U,"magic"),"magic",true)==v,"IMPORT_AUTO_INVALID","unknown format");}
bool reason_ok(std::string_view v){return !v.empty() && v.size()<=256U && std::all_of(v.begin(),v.end(),[](unsigned char c){return c>=32U && c<=126U;});}
Digest authority(const RuntimeConfig& c,const SourceViewRule& rule){Bytes b;datacube::append_octets(b,rule.digest.octets);for(const auto& pin:c.source_views.bindings)if(pin.view==rule.id)datacube::append_octets(b,pin.digest.octets);return hash("NATRAV_OVERLAY_IMPORT_AUTOMATION_AUTHORITY_V1",b);}
void boundary(const char* name){if(const char* v=std::getenv(name)){const auto ms=parse_u64(v,"import test boundary",1U,30000U);std::this_thread::sleep_for(std::chrono::milliseconds(ms));}}
bool block_outcome(std::string_view v){return v=="SOURCE_VIEW_RECORD_LIMIT" || v=="SOURCE_VIEW_BYTE_LIMIT" || v=="SOURCE_VIEW_CAPACITY" || v=="IMPORT_AUTO_DEPENDENCY_LIMIT";}
} // namespace
Bytes encode_import_auto_request(const ImportAutoRequest& v){
    need(valid_generation_id(v.view),"IMPORT_AUTO_INVALID","exact view required");
    Bytes b;const bool extended=v.command==ImportAutoCommand::review||v.command==ImportAutoCommand::reconsider;
    const bool terminal=v.command==ImportAutoCommand::retire||v.command==ImportAutoCommand::retirement_status;
    datacube::append_text(b,terminal?"NIR3":extended?"NIR2":"NIR1");datacube::append_u8(b,static_cast<std::uint8_t>(v.command));text(b,v.view);
    if(v.command==ImportAutoCommand::retire){
        datacube::append_be64(b,v.revision);text(b,v.reason);text(b,v.deferred_disposition);
        for(const auto& d:{v.view_digest,v.configuration_digest,v.final_state_digest})datacube::append_octets(b,d.octets);
    } else if(v.command==ImportAutoCommand::retirement_status) {
        // Exact view ID is the complete observational request.
    } else if(v.command==ImportAutoCommand::review){
        datacube::append_be64(b,v.after_revision);datacube::append_be64(b,v.through_revision);
        datacube::append_octets(b,v.history_digest.octets);datacube::append_be32(b,v.page_limit);datacube::append_be32(b,v.maximum_bytes);
    } else if(v.command==ImportAutoCommand::reconsider){
        datacube::append_be64(b,v.revision);text(b,v.reason);datacube::append_be64(b,v.decision_revision);
        for(const auto& d:{v.decision_digest,v.outer_operation,v.view_digest,v.configuration_digest})datacube::append_octets(b,d.octets);
    } else {
        if(v.command!=ImportAutoCommand::status){datacube::append_be64(b,v.revision);text(b,v.reason);}
        if(v.command==ImportAutoCommand::enable){datacube::append_be32(b,v.maximum_imports);datacube::append_be32(b,v.maximum_decisions);datacube::append_be32(b,v.interval_ms);}
    }
    return b;
}
ImportAutoRequest decode_import_auto_request(View bytes){
    datacube::Reader r(bytes,"import automation request");
    const auto version=datacube::octets_text(r.read_exact(4U,"magic"),"magic",true);
    auto k=r.read_u8("command");
    need((version=="NIR1"&&k>=1U&&k<=3U)||(version=="NIR2"&&k>=4U&&k<=5U)||(version=="NIR3"&&k>=6U&&k<=7U),"IMPORT_AUTO_INVALID","version and command");
    ImportAutoRequest v;v.command=static_cast<ImportAutoCommand>(k);v.view=text(r,64U);
    if(v.command==ImportAutoCommand::retire){
        v.revision=r.read_be64("revision");v.reason=text(r);v.deferred_disposition=text(r,32U);
        v.view_digest=digest(r);v.configuration_digest=digest(r);v.final_state_digest=digest(r);
        need(v.revision<=kImportHistoryLimit&&reason_ok(v.reason)&&!digest_is_zero(v.view_digest)&&
            !digest_is_zero(v.configuration_digest)&&!digest_is_zero(v.final_state_digest)&&
            (v.deferred_disposition=="REQUIRE_EMPTY"||v.deferred_disposition=="RETAIN_UNPROCESSED"),
            "SOURCE_VIEW_RETIREMENT_INVALID","exact selectors, reason and deferred disposition required");
    } else if(v.command==ImportAutoCommand::retirement_status) {
    } else if(v.command==ImportAutoCommand::review){
        v.after_revision=r.read_be64("after revision");v.through_revision=r.read_be64("through revision");v.history_digest=digest(r);
        v.page_limit=r.read_be32("page limit");v.maximum_bytes=r.read_be32("maximum bytes");
        need(v.after_revision<=kImportRetainedHistoryLimit&&v.through_revision<=kImportRetainedHistoryLimit&&v.page_limit>=1U&&v.page_limit<=32U&&
            v.maximum_bytes>=2048U&&v.maximum_bytes<=60000U&&((v.through_revision==0U)==digest_is_zero(v.history_digest)),"IMPORT_REVIEW_INVALID","bounded page and exact prefix required");
    } else if(v.command==ImportAutoCommand::reconsider){
        v.revision=r.read_be64("schedule revision");v.reason=text(r);v.decision_revision=r.read_be64("decision revision");
        v.decision_digest=digest(r);v.outer_operation=digest(r);v.view_digest=digest(r);v.configuration_digest=digest(r);
        need(v.revision>=1U&&v.revision<=kImportHistoryLimit&&v.decision_revision>=1U&&v.decision_revision<=v.revision&&reason_ok(v.reason)&&
            !digest_is_zero(v.decision_digest)&&!digest_is_zero(v.outer_operation)&&!digest_is_zero(v.view_digest)&&!digest_is_zero(v.configuration_digest),"IMPORT_RETRY_INVALID","exact selectors and reason required");
    } else {
        if(v.command!=ImportAutoCommand::status){v.revision=r.read_be64("revision");v.reason=text(r);need(reason_ok(v.reason),"IMPORT_AUTO_INVALID","reason required");}
        if(v.command==ImportAutoCommand::enable){v.maximum_imports=r.read_be32("imports");v.maximum_decisions=r.read_be32("decisions");v.interval_ms=r.read_be32("interval");}
    }
    r.require_eof("import automation request");need(valid_generation_id(v.view),"IMPORT_AUTO_INVALID","view");return v;
}
Bytes encode_import_auto_event(const ImportAutoEvent& v){
    Bytes b;datacube::append_text(b,v.action=="RETIRE"?"NIE3":v.action=="MANUAL_RETRY"?"NIE2":"NIE1");text(b,v.view);text(b,v.action);text(b,v.reason);text(b,v.outcome);
    for(auto n:{v.revision,v.configuration_event,v.unix_ms,v.inbound_count,v.ordinal})datacube::append_be64(b,n);
    for(auto n:{v.uid,v.gid,v.pid,v.maximum_imports,v.maximum_decisions,v.interval_ms})datacube::append_be32(b,n);
    datacube::append_octets(b,v.previous_digest.octets);
    if(v.action=="RETIRE"){
        text(b,v.deferred_disposition);
        for(const auto& d:{v.view_digest,v.configuration_digest,v.final_state_digest})datacube::append_octets(b,d.octets);
    } else if(v.action=="MANUAL_RETRY"){
        datacube::append_be64(b,v.decision_revision);
        for(const auto& d:{v.decision_digest,v.outer_operation,v.view_digest,v.configuration_digest})datacube::append_octets(b,d.octets);
    }
    return b;
}
ImportAutoEvent decode_import_auto_event(View bytes){
    datacube::Reader r(bytes,"import event");const auto version=datacube::octets_text(r.read_exact(4U,"magic"),"magic",true);
    need(version=="NIE1"||version=="NIE2"||version=="NIE3","JOURNAL_CORRUPT","unknown import event");
    ImportAutoEvent v;v.view=text(r,64U);v.action=text(r,32U);v.reason=text(r);v.outcome=text(r,64U);
    need((version=="NIE2")== (v.action=="MANUAL_RETRY"),"JOURNAL_CORRUPT","manual event version mismatch");
    need((version=="NIE3")== (v.action=="RETIRE"),"JOURNAL_CORRUPT","terminal event version mismatch");
    v.revision=r.read_be64("revision");v.configuration_event=r.read_be64("configuration");v.unix_ms=r.read_be64("time");v.inbound_count=r.read_be64("inbound prefix");v.ordinal=r.read_be64("ordinal");
    v.uid=r.read_be32("uid");v.gid=r.read_be32("gid");v.pid=r.read_be32("pid");v.maximum_imports=r.read_be32("imports");v.maximum_decisions=r.read_be32("decisions");v.interval_ms=r.read_be32("interval");v.previous_digest=digest(r);
    if(version=="NIE3"){
        v.deferred_disposition=text(r,32U);v.view_digest=digest(r);v.configuration_digest=digest(r);v.final_state_digest=digest(r);
    } else if(version=="NIE2"){
        v.decision_revision=r.read_be64("selected decision revision");v.decision_digest=digest(r);v.outer_operation=digest(r);v.view_digest=digest(r);v.configuration_digest=digest(r);
    }
    r.require_eof("import event");return v;
}
Bytes encode_import_auto_history(const ImportAutoState& v){Bytes b;datacube::append_text(b,"NIH1");datacube::append_be32(b,static_cast<std::uint32_t>(v.history.size()));for(const auto& e:v.history){auto encoded=encode_import_auto_event(e);datacube::append_be32(b,static_cast<std::uint32_t>(encoded.size()));datacube::append_octets(b,encoded);}return b;}
std::vector<ImportAutoEvent> decode_import_auto_history(View bytes){datacube::Reader r(bytes,"import history");magic(r,"NIH1");auto n=r.read_be32("history count");need(n>0U&&n<=kImportRetainedHistoryLimit,"JOURNAL_CORRUPT","import history bounds");std::vector<ImportAutoEvent> result;for(std::uint32_t i=0U;i<n;++i){auto size=r.read_be32("event size");need(size<=1024U,"JOURNAL_CORRUPT","event bound");result.push_back(decode_import_auto_event(r.read_exact(size,"event")));}r.require_eof("import history");return result;}
std::string import_auto_json(const ImportAutoState& v, const bool full_history){
    auto result="{\"format\":\"NATRAV_OVERLAY_IMPORT_AUTOMATION_V1\",\"view\":"+json_string(v.view)+",\"owner_uid\":"+std::to_string(v.uid)+
        ",\"revision\":"+std::to_string(v.history.size())+",\"generation\":"+std::to_string(v.generation)+",\"state\":"+json_string(v.state)+",\"error\":"+json_string(v.error)+
        ",\"next_position\":"+std::to_string(v.next_position)+",\"imports\":"+std::to_string(v.imports)+",\"decisions\":"+std::to_string(v.decisions)+
        ",\"maximum_imports\":"+std::to_string(v.maximum_imports)+",\"maximum_decisions\":"+std::to_string(v.maximum_decisions)+",\"minimum_interval_ms\":"+std::to_string(v.interval_ms)+
        ",\"history_digest\":"+json_string(datacube::hex_lower(v.head_digest))+",\"deferred\":[";
    bool first=true;for(const auto& [ordinal,parent]:v.deferred){if(!first)result+=",";first=false;result+="{\"ordinal\":"+std::to_string(ordinal)+",\"materialized_parent\":"+json_string(datacube::hex_lower(parent))+"}";}result+="],\"last_decision\":";
    if(v.history.empty())result+="null";else{const auto& e=v.history.back();result+="{\"action\":"+json_string(e.action)+",\"outcome\":"+json_string(e.outcome)+",\"configuration_event\":"+std::to_string(e.configuration_event)+",\"unix_ms\":"+std::to_string(e.unix_ms)+",\"executor_uid\":"+std::to_string(e.uid)+",\"executor_pid\":"+std::to_string(e.pid)+",\"reason\":"+json_string(e.reason)+"}";}
    if(full_history){result+=",\"events\":[";bool first_event=true;
        for(const auto& e:v.history){if(!first_event)result+=",";first_event=false;
            result+="{\"revision\":"+std::to_string(e.revision+1U)+",\"action\":"+json_string(e.action)+",\"outcome\":"+json_string(e.outcome)+
                ",\"configuration_event\":"+std::to_string(e.configuration_event)+",\"inbound_prefix_count\":"+std::to_string(e.inbound_count)+",\"source_domain_ordinal\":"+std::to_string(e.ordinal)+
                ",\"unix_ms\":"+std::to_string(e.unix_ms)+",\"actor_uid\":"+std::to_string(e.uid)+",\"actor_gid\":"+std::to_string(e.gid)+",\"actor_pid\":"+std::to_string(e.pid)+
                ",\"maximum_imports\":"+std::to_string(e.maximum_imports)+",\"maximum_decisions\":"+std::to_string(e.maximum_decisions)+",\"interval_ms\":"+std::to_string(e.interval_ms)+",\"reason\":"+json_string(e.reason)+"}";
        }result+="]";
    }
    if(v.state=="RETIRED") {
        const auto& e=v.history.back();
        result+=",\"retirement\":{\"selected_revision\":"+std::to_string(e.revision)+
            ",\"final_state_digest\":"+json_string(datacube::hex_lower(e.final_state_digest))+
            ",\"view_digest\":"+json_string(datacube::hex_lower(e.view_digest))+
            ",\"configuration_digest\":"+json_string(datacube::hex_lower(e.configuration_digest))+
            ",\"deferred_disposition\":"+json_string(e.deferred_disposition)+
            ",\"deferred_count\":"+std::to_string(v.deferred.size())+",\"disposition\":\"RETAINED_UNPROCESSED\"}";
    }
    return result+",\"manual_retries\":"+std::to_string(v.manual_retries)+",\"maximum_manual_retries\":"+std::to_string(kImportManualRetryLimit)+"}";
}

ImportPlan NodeState::plan_import_event_locked(const ImportAutoState& before,ImportAutoEvent e,const bool checkpoint) const {
    need(valid_generation_id(e.view)&&e.revision==before.history.size()&&e.previous_digest==before.head_digest&&
        e.inbound_count<=inbound_.size()&&e.configuration_event>0U&&e.configuration_event<=configuration_events_.size()&&
        e.unix_ms>0U&&e.pid>0U&&before.history.size()<(e.action=="RETIRE"?kImportRetainedHistoryLimit:kImportHistoryLimit),"JOURNAL_CORRUPT","import event binding");
    need(before.state!="RETIRED","SOURCE_VIEW_RETIRED","terminal view cannot accept another event");
    need(checkpoint || (e.inbound_count==inbound_.size()&&e.configuration_event==active_configuration_event(configuration_events_)),"JOURNAL_CORRUPT","import event current generation or prefix");
    if(!before.history.empty())need(e.view==before.view&&e.configuration_event>=before.history.back().configuration_event&&e.inbound_count>=before.history.back().inbound_count,"JOURNAL_CORRUPT","import history ordering");
    const auto& ce=configuration_events_[static_cast<std::size_t>(e.configuration_event-1U)];need(ce.kind!="REJECTED","JOURNAL_CORRUPT","import rejected configuration");
    const auto config=parse_runtime_config(ce.canonical,"/import-automation-history",IdentityFileValidation::deferred);
    const auto rule=std::find_if(config.source_views.rules.begin(),config.source_views.rules.end(),[&](const auto& r){return r.id==e.view;});
    ImportPlan plan;plan.next=before;auto& next=plan.next;
    const bool has_rule=config.format_version>=17U&&rule!=config.source_views.rules.end();
    const auto manager=before.history.empty()?(has_rule?rule->uid:e.uid):before.uid;
    const bool permitted=has_rule&&rule->uid==manager&&local_control_allows(config.local_control,manager,LocalControlClass::source_import);
    auto policy_error=std::string{};
    if(!permitted)policy_error="IMPORT_AUTO_POLICY_DENIED";
    else if(!before.history.empty()&&(rule->digest!=before.rule_digest||authority(config,*rule)!=before.authority_digest))policy_error="IMPORT_AUTO_POLICY_CHANGED";
    else {const auto* key=find_peer_generation(config,rule->provider,rule->generation);if(!key||key->state==KeyGenerationState::revoked)policy_error="IMPORT_AUTO_PROVIDER_REVOKED";}
    std::string outcome;
    if(e.action=="RETIRE") {
        const auto historical=retained_source_view_rule_locked(e.view,e.configuration_event);
        need(config.format_version>=17U&&historical.uid==e.uid&&
            local_control_allows(config.local_control,e.uid,LocalControlClass::source_import),
            "SOURCE_VIEW_RETIREMENT_DENIED","current administrative class and historical owner required");
        need(e.view_digest==historical.digest&&e.configuration_digest==ce.digest&&reason_ok(e.reason)&&
            e.ordinal==0U&&e.maximum_imports==0U&&e.maximum_decisions==0U&&e.interval_ms==0U,
            "SOURCE_VIEW_RETIREMENT_CONFLICT","exact immutable view and accepted configuration required");
        need(e.deferred_disposition=="RETAIN_UNPROCESSED" ||
            (e.deferred_disposition=="REQUIRE_EMPTY"&&before.deferred.empty()),
            "SOURCE_VIEW_DEFERRED_PENDING","explicit retained-unprocessed disposition required");
        const auto final=view_final_account_locked(before,historical,e.inbound_count);
        need(final.digest==e.final_state_digest,
            "SOURCE_VIEW_RETIREMENT_CONFLICT","retained evidence or final scheduling account changed");
        next.retired_from_state=before.state;next.retired_records=final.records;next.retired_payload_bytes=final.payload_bytes;next.retired_records_digest=final.records_digest;
        next.view=e.view;next.uid=historical.uid;next.rule_digest=historical.digest;
        next.state="RETIRED";next.error="SOURCE_VIEW_RETIRED";outcome="RETIRED";
    } else if(e.action=="ENABLE"){
        need(e.ordinal==0U,"JOURNAL_CORRUPT","enable has no candidate ordinal");
        need(permitted&&e.uid==manager,"IMPORT_AUTO_POLICY_DENIED","exact current manager authority required");
        const auto* key=find_peer_generation(config,rule->provider,rule->generation);need(key&&key->state!=KeyGenerationState::revoked,"IMPORT_AUTO_PROVIDER_REVOKED","provider generation revoked");
        need(before.state!="ENABLED"&&before.generation<32U&&before.history.size()<kImportHistoryLimit-2U,"IMPORT_AUTO_GRANT_LIMIT","pause before enable; finite histories required");
        need(e.maximum_imports>=1U&&e.maximum_imports<=128U&&e.maximum_decisions>=1U&&e.maximum_decisions<=256U&&e.interval_ms>=10U&&e.interval_ms<=60000U&&reason_ok(e.reason),"IMPORT_AUTO_INVALID","finite grant limits and reason required");
        if(!before.history.empty())need(rule->digest==before.rule_digest,"IMPORT_AUTO_POLICY_CHANGED","immutable view identity");
        next.view=e.view;next.uid=manager;next.rule_digest=rule->digest;next.authority_digest=authority(config,*rule);++next.generation;
        next.imports=0U;next.decisions=0U;next.maximum_imports=e.maximum_imports;next.maximum_decisions=e.maximum_decisions;next.interval_ms=e.interval_ms;next.state="ENABLED";next.error.clear();outcome="ENABLED";
    } else if(e.action=="PAUSE"){
        need(e.ordinal==0U&&e.maximum_imports==0U&&e.maximum_decisions==0U&&e.interval_ms==0U,"JOURNAL_CORRUPT","pause cannot change grant parameters");
        need(!before.history.empty()&&e.uid==manager&&local_control_allows(config.local_control,manager,LocalControlClass::source_import)&&reason_ok(e.reason),"IMPORT_AUTO_POLICY_DENIED","owner authority and reason required");
        need(before.state=="ENABLED","IMPORT_AUTO_NOT_ENABLED","schedule not enabled");next.state="PAUSED";next.error.clear();outcome="PAUSED";
    } else if(e.action=="MANUAL_RETRY"){
        need(before.state!="ENABLED","IMPORT_RETRY_AUTOMATION_ENABLED","pause automatic selection before explicit reconsideration");
        need(permitted&&e.uid==manager&&rule->digest==before.rule_digest&&e.view_digest==before.rule_digest&&
            e.configuration_digest==ce.digest&&reason_ok(e.reason),"IMPORT_RETRY_POLICY_DENIED","current exact manager, view and configuration required");
        const auto* key=find_peer_generation(config,rule->provider,rule->generation);
        need(key&&key->state!=KeyGenerationState::revoked,"IMPORT_AUTO_PROVIDER_REVOKED","provider generation revoked");
        need(before.manual_retries<kImportManualRetryLimit,"IMPORT_RETRY_LIMIT","finite manual reconsideration budget exhausted");
        need(e.maximum_imports==0U&&e.maximum_decisions==0U&&e.interval_ms==0U,"JOURNAL_CORRUPT","manual retry cannot replenish automation");
        need(e.decision_revision>0U&&e.decision_revision<=before.history.size(),"IMPORT_RETRY_DECISION_CONFLICT","exact prior decision required");
        const auto& prior=before.history[static_cast<std::size_t>(e.decision_revision-1U)];
        need(hash("NATRAV_OVERLAY_IMPORT_EVENT_V1",encode_import_auto_event(prior))==e.decision_digest,
            "IMPORT_RETRY_DECISION_CONFLICT","selected decision digest mismatch");
        need((prior.action=="SCAN"||prior.action=="RETRY"||prior.action=="MANUAL_RETRY")&&prior.outcome!="IMPORTED"&&prior.outcome!="DUPLICATE"&&
            prior.ordinal<before.next_position,"IMPORT_RETRY_INELIGIBLE","only previously skipped or deferred sources can be reconsidered");
        need(e.ordinal==prior.ordinal&&import_event_operation_locked(prior)==e.outer_operation,
            "IMPORT_RETRY_OPERATION_CONFLICT","exact original outer admission required");
        SubscribedSource selected;selected.view=e.view;selected.uid=e.uid;selected.gid=e.gid;selected.pid=e.pid;selected.unix_ms=e.unix_ms;
        selected.configuration_event=e.configuration_event;selected.configuration_digest=ce.digest;selected.outer_operation=e.outer_operation;
        selected.executor_uid=e.uid;selected.automation_revision=e.revision+1U;selected.selective_retry=true;
        plan.attempt=prepare_import_locked(selected,e.inbound_count);outcome=plan.attempt.outcome;
        if(outcome=="SOURCE_VIEW_PARENT_REQUIRED"){
            if(!plan.attempt.parent||(!before.deferred.contains(e.ordinal)&&before.deferred.size()>=64U))outcome="IMPORT_AUTO_DEPENDENCY_LIMIT";
            else next.deferred[e.ordinal]=*plan.attempt.parent;
        }else if(!block_outcome(outcome)){next.deferred.erase(e.ordinal);}
        // A finite one-shot administrative attempt, separate from the paused grant.
        // No scan rewind, allowance refund, policy adoption, or automatic resume.
        ++next.manual_retries;
    } else {
        // Worker UID/PID identify the daemon, never impersonate the manager.
        // The accepted ENABLE event is the manager's delegation.
        need(before.state=="ENABLED","JOURNAL_CORRUPT","enabled grant required");
        need(e.maximum_imports==0U&&e.maximum_decisions==0U&&e.interval_ms==0U&&e.reason.empty(),"JOURNAL_CORRUPT","worker cannot create authority");
        if(e.action=="BLOCK"){
            need(e.ordinal==0U,"JOURNAL_CORRUPT","policy block has no candidate ordinal");
            need(!policy_error.empty(),"JOURNAL_CORRUPT","block requires current policy failure");next.state="BLOCKED";next.error=policy_error;outcome=policy_error;
        } else {
            need(policy_error.empty(),"IMPORT_AUTO_POLICY_DENIED","current exact grant required");
            need(e.action=="SCAN"||e.action=="RETRY","JOURNAL_CORRUPT","unknown worker transition");
            const auto domain=inbound_domain_index_.find({rule->provider,rule->source_scope});
            need(domain!=inbound_domain_index_.end(),"JOURNAL_CORRUPT","source domain missing");
            const auto total=domain->second.before(static_cast<std::size_t>(e.inbound_count),true);
            const bool retry=e.action=="RETRY";
            need(e.ordinal<total&&(retry?before.deferred.contains(e.ordinal):e.ordinal==before.next_position),"JOURNAL_CORRUPT","selection frontier mismatch");
            SubscribedSource selected;selected.view=e.view;selected.uid=manager;selected.gid=e.gid;selected.pid=e.pid;selected.unix_ms=e.unix_ms;selected.configuration_event=e.configuration_event;selected.configuration_digest=ce.digest;
            selected.executor_uid=e.uid;selected.automation_revision=e.revision+1U;
            selected.outer_operation=inbound_[domain->second.at(static_cast<std::size_t>(e.ordinal),true)].record.operation_id;
            plan.attempt=prepare_import_locked(selected,e.inbound_count);outcome=plan.attempt.outcome;
            if(outcome=="SOURCE_VIEW_PARENT_REQUIRED"&&(!plan.attempt.parent||(!retry&&before.deferred.size()>=64U)))outcome="IMPORT_AUTO_DEPENDENCY_LIMIT";
            need(!(retry&&outcome=="SOURCE_VIEW_PARENT_REQUIRED"),"IMPORT_AUTO_PARENT_WAIT","dependency remains unavailable");
            if(block_outcome(outcome)){next.state="BLOCKED";next.error=outcome;}
            else{
                if(!retry)++next.next_position;else next.deferred.erase(e.ordinal);
                if(outcome=="SOURCE_VIEW_PARENT_REQUIRED")next.deferred.emplace(e.ordinal,*plan.attempt.parent);
                ++next.decisions;
                if(outcome=="IMPORTED")++next.imports;
                if(next.imports==next.maximum_imports||next.decisions==next.maximum_decisions){next.state="EXHAUSTED";next.error=next.imports==next.maximum_imports?"IMPORT_ALLOWANCE_EXHAUSTED":"INSPECTION_ALLOWANCE_EXHAUSTED";}
            }
        }
    }
    if(next.state=="ENABLED"&&before.history.size()+1U>=kImportHistoryLimit-1U){next.state="BLOCKED";next.error="IMPORT_AUTO_HISTORY_LIMIT";}
    if(!e.outcome.empty())need(e.outcome==outcome,"JOURNAL_CORRUPT","declared import outcome differs from source-derived outcome");
    e.outcome=outcome;next.head_digest=hash("NATRAV_OVERLAY_IMPORT_EVENT_V1",encode_import_auto_event(e));next.history.push_back(e);plan.event=std::move(e);return plan;
}

void NodeState::apply_import_auto_event(View bytes,const bool checkpoint){
    const auto e=decode_import_auto_event(bytes);need(!e.outcome.empty(),"JOURNAL_CORRUPT","missing derived outcome");const auto found=import_schedules_.find(e.view);
    const auto before=found==import_schedules_.end()?ImportAutoState{}:found->second;
    const auto plan=plan_import_event_locked(before,e,checkpoint);
    if(plan.attempt.imported){
        const auto& [record,account]=*plan.attempt.imported;
        if(checkpoint){
            const auto found_record=inbound_index_.find(operation_id_text(record.operation_id));
            need(found_record!=inbound_index_.end()&&found_record->second==e.inbound_count&&inbound_[found_record->second].subscribed_source&&
                encode_subscribed_source(*inbound_[found_record->second].subscribed_source)==encode_subscribed_source(account)&&
                encode_application_message(inbound_[found_record->second].record)==encode_application_message(record),"JOURNAL_CORRUPT","checkpoint automatic import detached from exact effect");
        } else {
            auto payload=encode_subscribed_source(account);datacube::append_octets(payload,encode_application_message(record));
            applying_import_auto_=true;
            try {apply_entry(EntryKind::subscribed_source,payload,true);applying_import_auto_=false;}
            catch(...){applying_import_auto_=false;throw;}
        }
    }
    import_schedules_[e.view]=plan.next;
}
void NodeState::commit_import_auto_event(const ImportAutoEvent& event){
    const auto found=import_schedules_.find(event.view);const auto plan=plan_import_event_locked(found==import_schedules_.end()?ImportAutoState{}:found->second,event,false);
    const bool step=event.action=="SCAN" || event.action=="RETRY";
    if(event.action=="RETIRE")boundary("NATRAV_OVERLAY_TEST_VIEW_RETIRE_BEFORE_COMMIT_MS");
    if(event.action=="MANUAL_RETRY")boundary("NATRAV_OVERLAY_TEST_IMPORT_RETRY_BEFORE_COMMIT_MS");
    boundary("NATRAV_OVERLAY_TEST_IMPORT_AUTO_BEFORE_COMMIT_MS");
    if(step)boundary("NATRAV_OVERLAY_TEST_IMPORT_STEP_BEFORE_COMMIT_MS");
    append_entry(EntryKind::import_schedule,encode_import_auto_event(plan.event));
    if(event.action=="RETIRE")boundary("NATRAV_OVERLAY_TEST_VIEW_RETIRE_AFTER_COMMIT_MS");
    if(event.action=="MANUAL_RETRY")boundary("NATRAV_OVERLAY_TEST_IMPORT_RETRY_AFTER_COMMIT_MS");
    if(step)boundary("NATRAV_OVERLAY_TEST_IMPORT_STEP_AFTER_COMMIT_MS");
    boundary("NATRAV_OVERLAY_TEST_IMPORT_AUTO_AFTER_COMMIT_MS");
}
std::string NodeState::import_auto_command(const ImportAutoRequest& request,const RuntimeConfig& config,std::uint32_t uid,std::uint32_t gid,std::uint32_t pid,std::uint64_t event,std::uint64_t ms){
    std::lock_guard<std::mutex> lock(mutex_);
    if(request.command==ImportAutoCommand::retire||request.command==ImportAutoCommand::retirement_status)
        return view_retirement_command_locked(request,config,uid,gid,pid,event,ms);
    const auto found=import_schedules_.find(request.view);const auto rule=std::find_if(config.source_views.rules.begin(),config.source_views.rules.end(),[&](const auto& v){return v.id==request.view;});
    const auto owner=found!=import_schedules_.end()?found->second.uid:(rule!=config.source_views.rules.end()?rule->uid:UINT32_MAX);
    need(config.format_version>=17U&&uid==owner&&local_control_allows(config.local_control,uid,LocalControlClass::source_import),"IMPORT_AUTO_POLICY_DENIED","exact owner required");
    if(request.command==ImportAutoCommand::review){
        ImportAutoState empty;empty.view=request.view;empty.uid=owner;
        if(rule!=config.source_views.rules.end())empty.rule_digest=rule->digest;
        return review_import_decisions_locked(request,found==import_schedules_.end()?empty:found->second,config,event);
    }
    if(!import_observational(request.command))require_source_view_active_locked(request.view);
    if(request.command==ImportAutoCommand::reconsider){
        need(found!=import_schedules_.end()&&rule!=config.source_views.rules.end()&&rule->digest==request.view_digest,
            "IMPORT_RETRY_POLICY_DENIED","existing schedule and exact current view required");
        const auto* key=find_peer_generation(config,rule->provider,rule->generation);
        need(key&&key->state!=KeyGenerationState::revoked,"IMPORT_AUTO_PROVIDER_REVOKED","provider generation revoked");
        const auto& schedule=found->second;
        const auto answer=[&](std::string_view disposition,const ImportAutoEvent& accepted){
            return "{\"format\":\"NATRAV_OVERLAY_IMPORT_RETRY_V1\",\"status\":"+json_string(disposition)+
                ",\"decision\":"+import_decision_json_locked(accepted)+",\"schedule\":"+import_auto_json(import_schedules_.at(request.view))+"}";
        };
        // Recover the exact recorded response before testing the latest revision.
        // Only current owner/class/view/key authority is accepted; this returns
        // historical metadata, never repeats an import or exposes payload bytes.
        if(request.revision<schedule.history.size()){
            const auto& old=schedule.history[static_cast<std::size_t>(request.revision)];
            if(old.action=="MANUAL_RETRY"&&old.uid==uid&&old.reason==request.reason&&old.decision_revision==request.decision_revision&&
                old.decision_digest==request.decision_digest&&old.outer_operation==request.outer_operation&&
                old.view_digest==request.view_digest&&old.configuration_digest==request.configuration_digest)return answer("ALREADY_RECONSIDERED",old);
        }
        need(request.revision==schedule.history.size(),"IMPORT_AUTO_REVISION_CONFLICT","exact schedule revision required");
        need(event>0U&&event<=configuration_events_.size()&&request.configuration_digest==configuration_events_[static_cast<std::size_t>(event-1U)].digest,
            "IMPORT_RETRY_CONFIGURATION_CONFLICT","select the currently accepted configuration");
        ImportAutoEvent e;e.view=request.view;e.action="MANUAL_RETRY";e.reason=request.reason;e.revision=request.revision;e.previous_digest=schedule.head_digest;
        e.configuration_event=event;e.unix_ms=ms;e.inbound_count=inbound_.size();e.uid=uid;e.gid=gid;e.pid=pid;e.decision_revision=request.decision_revision;
        e.decision_digest=request.decision_digest;e.outer_operation=request.outer_operation;e.view_digest=request.view_digest;e.configuration_digest=request.configuration_digest;
        need(e.decision_revision>0U&&e.decision_revision<=schedule.history.size(),"IMPORT_RETRY_DECISION_CONFLICT","exact prior decision required");
        e.ordinal=schedule.history[static_cast<std::size_t>(e.decision_revision-1U)].ordinal;
        commit_import_auto_event(e);
        return answer("RECONSIDERED",import_schedules_.at(request.view).history.back());
    }
    if(request.command==ImportAutoCommand::status){
        if(found!=import_schedules_.end())return import_auto_json(found->second);
        ImportAutoState value;value.view=request.view;value.uid=owner;return import_auto_json(value);
    }
    const auto before=found==import_schedules_.end()?ImportAutoState{}:found->second;
    need(request.revision==before.history.size(),"IMPORT_AUTO_REVISION_CONFLICT","select exact schedule revision");
    ImportAutoEvent e;e.view=request.view;e.action=request.command==ImportAutoCommand::enable?"ENABLE":"PAUSE";e.reason=request.reason;e.revision=before.history.size();e.previous_digest=before.head_digest;e.configuration_event=event;e.unix_ms=ms;e.inbound_count=inbound_.size();e.uid=uid;e.gid=gid;e.pid=pid;
    if(request.command==ImportAutoCommand::enable){e.maximum_imports=request.maximum_imports;e.maximum_decisions=request.maximum_decisions;e.interval_ms=request.interval_ms;}
    commit_import_auto_event(e);return import_auto_json(import_schedules_.at(request.view));
}
std::vector<ImportCandidate> NodeState::automatic_import_candidates() const {
    std::lock_guard<std::mutex> lock(mutex_);std::vector<ImportCandidate> result;for(const auto& [id,s]:import_schedules_)if(s.state=="ENABLED")result.push_back({id,s.generation,s.interval_ms});return result;
}
bool NodeState::automatic_import_step(std::string_view view,const RuntimeConfig& config,std::uint64_t event,std::uint32_t uid,std::uint32_t gid,std::uint32_t pid){
    std::lock_guard<std::mutex> lock(mutex_);const auto found=import_schedules_.find(std::string(view));if(found==import_schedules_.end()||found->second.state!="ENABLED")return false;
    const auto& s=found->second;const auto rule=std::find_if(config.source_views.rules.begin(),config.source_views.rules.end(),[&](const auto& v){return v.id==view;});
    const auto* key=rule==config.source_views.rules.end()?nullptr:find_peer_generation(config,rule->provider,rule->generation);
    ImportAutoEvent e;e.view=view;e.action="BLOCK";e.revision=s.history.size();e.previous_digest=s.head_digest;e.configuration_event=event;e.unix_ms=static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count());e.inbound_count=inbound_.size();e.uid=uid;e.gid=gid;e.pid=pid;
    if(rule!=config.source_views.rules.end()&&rule->uid==s.uid&&local_control_allows(config.local_control,s.uid,LocalControlClass::source_import)&&authority(config,*rule)==s.authority_digest&&key&&key->state!=KeyGenerationState::revoked){
        bool ready=false;
        for(const auto& [ordinal,parent]:s.deferred)if(inbound_index_.contains(operation_id_text(parent))){e.action="RETRY";e.ordinal=ordinal;ready=true;break;}
        if(!ready){const auto domain=inbound_domain_index_.find({rule->provider,rule->source_scope});if(domain==inbound_domain_index_.end()||s.next_position>=domain->second.size(true))return false;e.action="SCAN";e.ordinal=s.next_position;}
    }
    try { commit_import_auto_event(e);return true; }
    catch(const AppError& error){if(error.code()=="STATE_CAPACITY_EXCEEDED")return false;throw;}
}
} // namespace natrav_overlay
