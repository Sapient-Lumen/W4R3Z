#include "peer_session.hpp"

#include <algorithm>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <string>
#include <string_view>
#include <unistd.h>
#include <utility>

namespace natrav_overlay {
namespace {

[[nodiscard]] std::string session_request_id(
    const datacube::Digest32& operation_id,
    const std::string_view peer) {
    datacube::Octets bytes;
    constexpr std::string_view domain = "NATRAV_OVERLAY_SESSION_HANDSHAKE_V1";
    datacube::append_text(bytes, domain);
    datacube::append_u8(bytes, 0U);
    datacube::append_octets(bytes, operation_id.octets);
    datacube::append_u8(bytes, 0U);
    datacube::append_text(bytes, peer);
    datacube::append_be64(bytes, datacube::monotonic_nanoseconds());
    datacube::append_be64(bytes, static_cast<std::uint64_t>(::getpid()));
    return datacube::hex_lower(datacube::sha256(bytes));
}

[[nodiscard]] datacube::Digest32 session_id_for(
    const datacube::Digest32& operation_id,
    const std::string_view local_node,
    const std::string_view peer) {
    datacube::Octets bytes;
    constexpr std::string_view domain = "NATRAV_OVERLAY_NOS1_SESSION_ID_V1";
    datacube::append_text(bytes, domain);
    datacube::append_u8(bytes, 0U);
    datacube::append_text(bytes, local_node);
    datacube::append_u8(bytes, 0U);
    datacube::append_text(bytes, peer);
    datacube::append_u8(bytes, 0U);
    datacube::append_octets(bytes, operation_id.octets);
    datacube::append_be64(bytes, datacube::monotonic_nanoseconds());
    datacube::append_be64(bytes, static_cast<std::uint64_t>(::getpid()));
    return datacube::sha256(bytes);
}

[[nodiscard]] Deadline minimum_deadline(
    const Deadline left,
    const Deadline right) noexcept {
    return left < right ? left : right;
}

[[nodiscard]] std::chrono::milliseconds milliseconds(
    const std::uint32_t value) {
    return std::chrono::milliseconds(
        static_cast<std::chrono::milliseconds::rep>(value));
}

[[nodiscard]] std::uint64_t framed_bytes(const std::size_t payload_bytes) noexcept {
    return static_cast<std::uint64_t>(kPeerFramePrefixBytes) +
        static_cast<std::uint64_t>(payload_bytes);
}

[[nodiscard]] std::chrono::milliseconds retirement_guard(
    const PeerSessionLimits& limits) noexcept {
    const auto smallest = std::min(
        limits.idle_timeout_ms, limits.maximum_lifetime_ms);
    const auto guard = std::max<std::uint32_t>(
        1U, std::min<std::uint32_t>(250U, smallest / 4U));
    return milliseconds(guard);
}

void validate_receipt_binding(
    const DeliveryReceipt& receipt,
    const EvidenceRecord& record) {
    if (receipt.operation_id != record.operation_id ||
        receipt.recipient != record.recipient ||
        receipt.recorder != record.recipient ||
        receipt.record_digest != evidence_record_digest(record)) {
        app_fail("RECEIPT_BINDING_REJECTED",
            "session receipt does not bind the sent record");
    }
}

[[nodiscard]] bool limits_not_stronger_than(
    const PeerSessionLimits& selected,
    const PeerSessionLimits& requested) noexcept {
    return selected.maximum_operations <= requested.maximum_operations &&
        selected.maximum_bytes <= requested.maximum_bytes &&
        selected.maximum_lifetime_ms <= requested.maximum_lifetime_ms &&
        selected.idle_timeout_ms <= requested.idle_timeout_ms;
}

void validate_session_open_inputs(
    const std::string_view local_node,
    const std::string_view expected_peer,
    const std::string_view expected_peer_generation,
    const KeyGenerationState expected_peer_key_state,
    const datacube::Digest32& expected_peer_spki_sha256,
    const datacube::Digest32& first_operation_id,
    const IoOptions& io,
    const PeerSessionLimits& requested_limits) {
    validate_io_options(io);
    validate_peer_session_limits(requested_limits);
    require_node_id(local_node, "session local node");
    require_node_id(expected_peer, "session expected peer");
    require_generation_id(expected_peer_generation, "session peer generation");
    if (digest_is_zero(first_operation_id)) {
        app_fail("SESSION_OPERATION_INVALID",
            "session opening operation ID must be nonzero");
    }
    if (expected_peer_key_state == KeyGenerationState::revoked ||
        spki_sha256_is_zero(expected_peer_spki_sha256)) {
        app_fail("SESSION_PEER_KEY_INVALID",
            "reusable session requires one non-revoked exact peer key");
    }
}

}  // namespace

struct OutboundPeerSession::State final {
    std::unique_ptr<OrderedByteStream> stream;
    TlsChannel channel;
    FramedReader reader;
    datacube::Digest32 session_id;
    PeerSessionLimits negotiated;
    std::string peer_generation;
    datacube::Digest32 peer_spki_sha256;
    std::uint32_t next_sequence{1U};
    std::uint64_t operations{0U};
    std::uint64_t session_bytes{0U};
    bool peer_retired{false};
    bool closed{false};
    std::chrono::steady_clock::time_point opened;
    std::chrono::steady_clock::time_point last_activity;
    PeerSessionOpenCounters open_counters;
    IoCounters application_counters;

    State(
        std::unique_ptr<OrderedByteStream> stream_value,
        TlsChannel channel_value,
        FramedReader reader_value,
        const datacube::Digest32& session_id_value,
        PeerSessionLimits negotiated_value,
        std::string peer_generation_value,
        const datacube::Digest32& peer_spki_sha256_value,
        const std::uint64_t session_bytes_value,
        PeerSessionOpenCounters counters)
        : stream(std::move(stream_value)),
          channel(std::move(channel_value)),
          reader(std::move(reader_value)),
          session_id(session_id_value),
          negotiated(negotiated_value),
          peer_generation(std::move(peer_generation_value)),
          peer_spki_sha256(peer_spki_sha256_value),
          session_bytes(session_bytes_value),
          opened(std::chrono::steady_clock::now()),
          last_activity(opened),
          open_counters(std::move(counters)) {}

    [[nodiscard]] Deadline operation_deadline(const IoOptions& io) const {
        auto result = deadline_after(io.timeout);
        result = minimum_deadline(
            result, opened + milliseconds(negotiated.maximum_lifetime_ms));
        result = minimum_deadline(
            result, last_activity + milliseconds(negotiated.idle_timeout_ms));
        return result;
    }
};

OutboundPeerSession::OutboundPeerSession(std::unique_ptr<State> state) noexcept
    : state_(std::move(state)) {}
OutboundPeerSession::~OutboundPeerSession() = default;
OutboundPeerSession::OutboundPeerSession(OutboundPeerSession&&) noexcept = default;
OutboundPeerSession& OutboundPeerSession::operator=(OutboundPeerSession&&) noexcept = default;

OutboundPeerSession OutboundPeerSession::open(
    TlsContext& tls,
    const std::string_view local_node,
    const std::string_view expected_peer,
    const std::string_view expected_peer_generation,
    const KeyGenerationState expected_peer_key_state,
    const datacube::Digest32& expected_peer_spki_sha256,
    const TransportLocator& locator,
    const EvidenceRecord& first_record,
    const IoOptions& io,
    const PeerSessionLimits& requested_limits) {
    validate_evidence_record(first_record);
    return open(tls, local_node, expected_peer, expected_peer_generation,
        expected_peer_key_state, expected_peer_spki_sha256, locator,
        first_record.operation_id, io, requested_limits);
}

OutboundPeerSession OutboundPeerSession::open(
    TlsContext& tls,
    const std::string_view local_node,
    const std::string_view expected_peer,
    const std::string_view expected_peer_generation,
    const KeyGenerationState expected_peer_key_state,
    const datacube::Digest32& expected_peer_spki_sha256,
    const TransportLocator& locator,
    const datacube::Digest32& first_operation_id,
    const IoOptions& io,
    const PeerSessionLimits& requested_limits,
    const TransportConnector* const authorized_connector) {
    validate_session_open_inputs(
        local_node, expected_peer, expected_peer_generation,
        expected_peer_key_state, expected_peer_spki_sha256,
        first_operation_id, io, requested_limits);
    PeerSessionOpenCounters counters;
    const auto deadline = deadline_after(io.timeout);
    auto stream = authorized_connector != nullptr ?
        authorized_connector->connect(locator, deadline, counters.connect) :
        connect_transport(locator, deadline, counters.connect);
    return open_connected_impl(
        tls, local_node, expected_peer, expected_peer_generation,
        expected_peer_key_state, expected_peer_spki_sha256,
        std::move(stream), first_operation_id, io, requested_limits,
        deadline, std::move(counters));
}

OutboundPeerSession OutboundPeerSession::open_connected(
    TlsContext& tls,
    const std::string_view local_node,
    const std::string_view expected_peer,
    const std::string_view expected_peer_generation,
    const KeyGenerationState expected_peer_key_state,
    const datacube::Digest32& expected_peer_spki_sha256,
    std::unique_ptr<OrderedByteStream> stream,
    const datacube::Digest32& first_operation_id,
    const IoOptions& io,
    const PeerSessionLimits& requested_limits) {
    validate_session_open_inputs(
        local_node, expected_peer, expected_peer_generation,
        expected_peer_key_state, expected_peer_spki_sha256,
        first_operation_id, io, requested_limits);
    if (!stream) {
        app_fail("SESSION_STREAM_INVALID", "connected stream is null");
    }
    return open_connected_impl(
        tls, local_node, expected_peer, expected_peer_generation,
        expected_peer_key_state, expected_peer_spki_sha256,
        std::move(stream), first_operation_id, io, requested_limits,
        deadline_after(io.timeout), PeerSessionOpenCounters{});
}

OutboundPeerSession OutboundPeerSession::open_connected_impl(
    TlsContext& tls,
    const std::string_view local_node,
    const std::string_view expected_peer,
    const std::string_view expected_peer_generation,
    const KeyGenerationState expected_peer_key_state,
    const datacube::Digest32& expected_peer_spki_sha256,
    std::unique_ptr<OrderedByteStream> stream,
    const datacube::Digest32& first_operation_id,
    const IoOptions& io,
    const PeerSessionLimits& requested_limits,
    const Deadline deadline,
    PeerSessionOpenCounters counters) {
    if (!stream) {
        app_fail("SESSION_STREAM_INVALID", "connected stream is null");
    }
    auto channel = TlsChannel::connect(
        tls,
        *stream,
        expected_peer,
        expected_peer_generation,
        expected_peer_key_state,
        expected_peer_spki_sha256,
        deadline,
        counters.tls);
    const auto handshake = perform_client_handshake(
        channel,
        local_node,
        expected_peer,
        session_request_id(first_operation_id, expected_peer),
        deadline,
        io);
    counters.handshake = handshake.counters;

    IoOptions session_io = io;
    if (requested_limits.maximum_bytes >
        static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
        app_fail("SESSION_LIMIT_INVALID", "session byte bound exceeds size_t");
    }
    session_io.maximum_received_bytes =
        static_cast<std::size_t>(requested_limits.maximum_bytes);
    FramedReader reader(session_io);
    const auto session_id = session_id_for(
        first_operation_id, local_node, expected_peer);
    const PeerSessionFrame open_frame{
        .kind = PeerSessionFrameKind::open,
        .flags = 0U,
        .session_id = session_id,
        .sequence = 0U,
        .operation_id = {},
        .limits = requested_limits,
        .payload = {},
    };
    const auto encoded_open = encode_peer_session_frame(open_frame);
    write_frame(channel, encoded_open, deadline, session_io, counters.session);
    const auto encoded_ack = reader.read_frame(
        channel, deadline, counters.session);
    const auto ack = decode_peer_session_frame(encoded_ack);
    if (ack.kind != PeerSessionFrameKind::open_ack ||
        ack.session_id != session_id || ack.sequence != 0U ||
        !ack.limits.has_value()) {
        app_fail("SESSION_OPEN_BINDING_REJECTED",
            "peer session acknowledgement does not bind the session open");
    }
    if (!limits_not_stronger_than(*ack.limits, requested_limits)) {
        app_fail("SESSION_NEGOTIATION_REJECTED",
            "peer selected limits outside the requested session envelope");
    }
    validate_peer_session_limits(*ack.limits);
    const auto session_bytes = framed_bytes(encoded_open.size()) +
        framed_bytes(encoded_ack.size());
    if (session_bytes > ack.limits->maximum_bytes) {
        app_fail("SESSION_BYTE_LIMIT", "session open exceeds negotiated byte bound");
    }
    return OutboundPeerSession(std::make_unique<State>(
        std::move(stream),
        std::move(channel),
        std::move(reader),
        session_id,
        *ack.limits,
        std::string(expected_peer_generation),
        expected_peer_spki_sha256,
        session_bytes,
        std::move(counters)));
}

std::chrono::milliseconds OutboundPeerSession::retirement_delay() const noexcept {
    if (!state_ || state_->closed || state_->peer_retired ||
        state_->operations >= state_->negotiated.maximum_operations) {
        return std::chrono::milliseconds(0);
    }
    const auto deadline = std::min(
        state_->opened + milliseconds(state_->negotiated.maximum_lifetime_ms),
        state_->last_activity + milliseconds(state_->negotiated.idle_timeout_ms));
    const auto target = deadline - retirement_guard(state_->negotiated);
    const auto now = std::chrono::steady_clock::now();
    if (now >= target) {
        return std::chrono::milliseconds(0);
    }
    return std::max(
        std::chrono::milliseconds(1),
        std::chrono::duration_cast<std::chrono::milliseconds>(target - now));
}

bool OutboundPeerSession::reusable() const noexcept {
    return retirement_delay().count() > 0;
}

bool OutboundPeerSession::usable_for(
    const std::string_view expected_peer_generation,
    const datacube::Digest32& expected_peer_spki_sha256,
    const EvidenceRecord& record) const {
    const auto application = encode_application_message(record);
    return usable_for_encoded_size(expected_peer_generation, expected_peer_spki_sha256, application.size());
}

bool OutboundPeerSession::usable_for_encoded_size(
    const std::string_view expected_peer_generation,
    const datacube::Digest32& expected_peer_spki_sha256,
    const std::size_t application_bytes) const {
    if (!reusable() ||
        state_->peer_generation != expected_peer_generation ||
        state_->peer_spki_sha256 != expected_peer_spki_sha256) {
        return false;
    }
    const auto request_bytes = framed_bytes(
        kPeerSessionHeaderBytes + application_bytes);
    const auto worst_response = framed_bytes(
        kPeerSessionHeaderBytes + kMaximumApplicationPayloadBytes);
    const auto close_reserve = 2U * framed_bytes(kPeerSessionHeaderBytes);
    if (request_bytes > std::numeric_limits<std::uint64_t>::max() -
            state_->session_bytes ||
        worst_response > std::numeric_limits<std::uint64_t>::max() -
            state_->session_bytes - request_bytes ||
        close_reserve > std::numeric_limits<std::uint64_t>::max() -
            state_->session_bytes - request_bytes - worst_response) {
        return false;
    }
    return state_->session_bytes + request_bytes + worst_response + close_reserve <=
        state_->negotiated.maximum_bytes;
}

DeliveryReceipt OutboundPeerSession::exchange(
    const EvidenceRecord& record,
    const IoOptions& io) {
    validate_evidence_record(record);
    const auto response = exchange_message(
        record.operation_id, ApplicationMessage(record), io);
    if (const auto* error = std::get_if<ProtocolError>(&response)) {
        if (!error->operation_id.has_value() ||
            *error->operation_id != record.operation_id) {
            app_fail("REMOTE_ERROR_BINDING_REJECTED",
                "session peer error does not bind the exact outbound operation");
        }
        throw AuthenticatedPeerError(
            error->code,
            error->detail,
            authenticated_peer_error_is_terminal(error->code));
    }
    const auto* receipt = std::get_if<DeliveryReceipt>(&response);
    if (receipt == nullptr) {
        app_fail("APPLICATION_KIND_REJECTED",
            "session response must be a receipt or typed error");
    }
    validate_receipt_binding(*receipt, record);
    return *receipt;
}

ApplicationMessage OutboundPeerSession::exchange_message(
    const datacube::Digest32& operation_id,
    const ApplicationMessage& message,
    const IoOptions& io) {
    if (digest_is_zero(operation_id)) {
        app_fail("SESSION_OPERATION_INVALID",
            "session operation ID must be nonzero");
    }
    const auto bound = application_message_operation_id(message);
    if (!bound.has_value() || *bound != operation_id) {
        app_fail("SESSION_REQUEST_BINDING_REJECTED",
            "application message does not bind the requested operation ID");
    }
    const auto application = encode_application_message(message);
    if (!state_ || !reusable()) {
        app_fail("SESSION_RETIRED",
            "peer session cannot accept another bounded operation");
    }
    const auto request_bytes = framed_bytes(
        kPeerSessionHeaderBytes + application.size());
    const auto worst_response = framed_bytes(
        kPeerSessionHeaderBytes + kMaximumApplicationPayloadBytes);
    const auto close_reserve = 2U * framed_bytes(kPeerSessionHeaderBytes);
    if (request_bytes > std::numeric_limits<std::uint64_t>::max() -
            state_->session_bytes ||
        worst_response > std::numeric_limits<std::uint64_t>::max() -
            state_->session_bytes - request_bytes ||
        close_reserve > std::numeric_limits<std::uint64_t>::max() -
            state_->session_bytes - request_bytes - worst_response ||
        state_->session_bytes + request_bytes + worst_response + close_reserve >
            state_->negotiated.maximum_bytes) {
        app_fail("SESSION_RETIRED",
            "peer session lacks bounded capacity for another operation");
    }
    const PeerSessionFrame request{
        .kind = PeerSessionFrameKind::request,
        .flags = 0U,
        .session_id = state_->session_id,
        .sequence = state_->next_sequence,
        .operation_id = operation_id,
        .limits = std::nullopt,
        .payload = application,
    };
    const auto encoded_request = encode_peer_session_frame(request);
    const auto deadline = state_->operation_deadline(io);
    write_frame(
        state_->channel,
        encoded_request,
        deadline,
        io,
        state_->application_counters);
    state_->session_bytes += framed_bytes(encoded_request.size());

    const auto encoded_response = state_->reader.read_frame(
        state_->channel, deadline, state_->application_counters);
    const auto response = decode_peer_session_frame(encoded_response);
    if (response.kind != PeerSessionFrameKind::response ||
        response.session_id != state_->session_id ||
        response.sequence != state_->next_sequence ||
        response.operation_id != operation_id) {
        app_fail("SESSION_RESPONSE_BINDING_REJECTED",
            "session response does not bind the exact session, sequence, and operation");
    }
    if (framed_bytes(encoded_response.size()) >
        state_->negotiated.maximum_bytes - state_->session_bytes) {
        app_fail("SESSION_BYTE_LIMIT", "peer exceeded the negotiated session byte bound");
    }
    state_->session_bytes += framed_bytes(encoded_response.size());
    ++state_->operations;
    ++state_->next_sequence;
    state_->last_activity = std::chrono::steady_clock::now();
    if ((response.flags & kPeerSessionRetireAfterResponse) != 0U ||
        state_->operations >= state_->negotiated.maximum_operations) {
        state_->peer_retired = true;
    }

    const auto decoded = decode_application_message(response.payload);
    const auto response_operation = application_message_operation_id(decoded);
    if (!response_operation.has_value() || *response_operation != operation_id) {
        app_fail("SESSION_RESPONSE_BINDING_REJECTED",
            "application response does not bind the exact operation ID");
    }
    return decoded;
}

bool OutboundPeerSession::close_cleanly(const IoOptions& io) noexcept {
    if (!state_ || state_->closed) {
        return true;
    }
    state_->closed = true;
    if (state_->peer_retired) {
        state_->channel.close_notify(deadline_after(io.timeout),
            state_->application_counters);
        return true;
    }
    try {
        const PeerSessionFrame close{
            .kind = PeerSessionFrameKind::close,
            .flags = 0U,
            .session_id = state_->session_id,
            .sequence = state_->next_sequence,
            .operation_id = {},
            .limits = std::nullopt,
            .payload = {},
        };
        const auto encoded = encode_peer_session_frame(close);
        const auto deadline = state_->operation_deadline(io);
        write_frame(state_->channel, encoded, deadline, io,
            state_->application_counters);
        const auto ack_payload = state_->reader.read_frame(
            state_->channel, deadline, state_->application_counters);
        const auto ack = decode_peer_session_frame(ack_payload);
        if (ack.kind != PeerSessionFrameKind::close_ack ||
            ack.session_id != state_->session_id ||
            ack.sequence != state_->next_sequence) {
            return false;
        }
        state_->channel.close_notify(deadline, state_->application_counters);
        return true;
    } catch (...) {
        return false;
    }
}

bool OutboundPeerSession::peer_requested_retirement() const noexcept {
    return state_ && state_->peer_retired;
}

std::uint64_t OutboundPeerSession::operations() const noexcept {
    return state_ ? state_->operations : 0U;
}

std::uint64_t OutboundPeerSession::session_bytes() const noexcept {
    return state_ ? state_->session_bytes : 0U;
}

const TlsSessionInfo& OutboundPeerSession::tls_session() const noexcept {
    return state_->channel.session();
}

const PeerSessionLimits& OutboundPeerSession::negotiated_limits() const noexcept {
    return state_->negotiated;
}

const PeerSessionOpenCounters& OutboundPeerSession::open_counters() const noexcept {
    return state_->open_counters;
}

const IoCounters& OutboundPeerSession::application_counters() const noexcept {
    return state_->application_counters;
}

}  // namespace natrav_overlay
