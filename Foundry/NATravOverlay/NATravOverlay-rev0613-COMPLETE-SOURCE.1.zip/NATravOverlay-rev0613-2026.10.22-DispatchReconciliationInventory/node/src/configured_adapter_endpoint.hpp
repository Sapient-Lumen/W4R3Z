#pragma once

#include "adapter_profile_catalog.hpp"
#include "external_packet_adapter.hpp"

#include <cstdint>
#include <string_view>

namespace natrav_overlay {

inline constexpr char kConfiguredExternalAdapterEndpointMarker[] =
    "CONFIGURED_EXTERNAL_ADAPTER_ENDPOINT_V1";
[[nodiscard]] int configured_external_adapter_endpoint_revision_abi() noexcept;

struct PreparedConfiguredAdapterEndpoint final {
    ConfiguredAdapterEndpoint endpoint{};
    AdapterSha256 endpoint_sha256{};
    AdapterSha256 profile_sha256{};
    ExternalPacketAdapterOptions options{};
};

// Resolves an exact retained endpoint generation, verifies its bound profile
// digest, prepares the pinned executable image once, and derives every launch
// option only through external_packet_adapter_options_from_profile().
[[nodiscard]] PreparedConfiguredAdapterEndpoint
prepare_configured_external_adapter_endpoint(
    const DurableAdapterProfileCatalog& catalog,
    std::string_view endpoint_id,
    std::uint64_t endpoint_generation);

}  // namespace natrav_overlay
