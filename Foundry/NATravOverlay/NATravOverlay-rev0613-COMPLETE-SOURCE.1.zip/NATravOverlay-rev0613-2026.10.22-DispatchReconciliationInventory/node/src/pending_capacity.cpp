#include "pending_capacity.hpp"
#include "common.hpp"

#include <limits>

namespace natrav_overlay {
namespace {
PendingCapacityTotals added(PendingCapacityTotals old, std::uint64_t bytes) {
    constexpr auto maximum = std::numeric_limits<std::uint64_t>::max();
    if (old.records == maximum || bytes > maximum - old.payload_bytes) {
        app_fail("OUTBOX_ACCOUNTING_OVERFLOW", "pending capacity exceeds the accounting range");
    }
    return {old.records + 1U, old.payload_bytes + bytes};
}
PendingCapacityTotals removed(PendingCapacityTotals old, std::uint64_t bytes) {
    if (old.records == 0U || bytes > old.payload_bytes ||
        (old.records == 1U && old.payload_bytes != bytes)) {
        app_fail("OUTBOX_ACCOUNTING_CORRUPT", "pending reservation cannot be released exactly");
    }
    return {old.records - 1U, old.payload_bytes - bytes};
}
}

PendingCapacityChange PendingCapacityIndex::update(const std::size_t index,
    const std::string_view recipient, const std::uint64_t payload_bytes, const bool pending) {
    const auto old = entries_.find(index);
    if (old != entries_.end()) {
        if (old->second.recipient != recipient || old->second.payload_bytes != payload_bytes) {
            app_fail("OUTBOX_ACCOUNTING_CORRUPT", "queued recipient and payload length are immutable");
        }
        if (pending) return PendingCapacityChange::unchanged;
        const auto bucket = peers_.find(recipient);
        if (bucket == peers_.end()) app_fail("OUTBOX_ACCOUNTING_CORRUPT", "pending peer account is missing");
        const auto next_total = removed(total_, payload_bytes);
        const auto next_peer = removed(bucket->second, payload_bytes);
        // No allocations or throwing arithmetic below this boundary.
        total_ = next_total;
        if (next_peer.records == 0U) peers_.erase(bucket);
        else bucket->second = next_peer;
        entries_.erase(old);
        return PendingCapacityChange::released;
    }
    if (!pending) return PendingCapacityChange::unchanged;
    const auto next_total = added(total_, payload_bytes);
    const auto next_peer = added(peer(recipient), payload_bytes);
    const auto [bucket, inserted] = peers_.try_emplace(std::string(recipient));
    try {
        entries_.emplace(index, Entry{std::string(recipient), payload_bytes});
    } catch (...) {
        if (inserted) peers_.erase(bucket);
        throw;
    }
    total_ = next_total;
    bucket->second = next_peer;
    return PendingCapacityChange::acquired;
}

PendingCapacityTotals PendingCapacityIndex::peer(const std::string_view recipient) const {
    const auto found = peers_.find(recipient);
    return found == peers_.end() ? PendingCapacityTotals{} : found->second;
}

bool PendingCapacityIndex::matches(const std::size_t index,
    const std::string_view recipient, const std::uint64_t bytes) const {
    const auto entry = entries_.find(index);
    return entry != entries_.end() && entry->second.recipient == recipient &&
        entry->second.payload_bytes == bytes;
}

QueueUsage PendingCapacityIndex::snapshot() const {
    QueueUsage usage{.pending_records=total_.records, .pending_payload_bytes=total_.payload_bytes, .peers={}};
    usage.peers.reserve(peers_.size());
    for (const auto& [name, value] : peers_) {
        usage.peers.push_back(PeerQueueUsage{.peer=name, .pending_records=value.records,
            .pending_payload_bytes=value.payload_bytes});
    }
    return usage;
}
} // namespace natrav_overlay
