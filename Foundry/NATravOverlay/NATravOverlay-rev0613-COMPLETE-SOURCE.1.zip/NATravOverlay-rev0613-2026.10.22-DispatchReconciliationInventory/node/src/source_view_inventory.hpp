#pragma once
#include "subscribed_source.hpp"
#include <map>
#include <optional>
#include <string>

namespace natrav_overlay {
// Derived from validated accepted configuration history. Not independently persisted.
struct RetainedSourceView final {
    SourceViewRule rule;
    datacube::Digest32 provider_spki{};
    std::uint64_t first_configuration_event{0U};
    std::map<std::string, SourceViewBinding> bindings;
    // First accepted event for each immutable pin; rebuilt, never persisted separately.
    std::map<std::string, std::uint64_t> binding_first_events;
    datacube::Digest32 bindings_digest{};
};
// Manager-scoped metadata selection, never an import permission or mutation token.
struct SourceViewInventory final {
    std::string presence{"all"}, lifecycle{"all"}, schedule{"all"};
    std::string view, provider, generation, source_scope, target_scope;
    std::optional<std::uint32_t> author_uid;
    std::uint32_t offset{0U}, limit{16U}, maximum_bytes{32768U};
    std::optional<datacube::Digest32> selection;
};
void validate_source_view_inventory(const SourceViewInventory&);
[[nodiscard]] datacube::Octets encode_source_view_inventory(const SourceViewInventory&);
[[nodiscard]] SourceViewInventory decode_source_view_inventory(datacube::OctetView);
} // namespace natrav_overlay
