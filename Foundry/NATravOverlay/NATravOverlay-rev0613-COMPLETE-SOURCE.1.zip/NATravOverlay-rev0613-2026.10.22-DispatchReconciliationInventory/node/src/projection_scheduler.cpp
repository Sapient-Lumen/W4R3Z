#include "projection_scheduler.hpp"
#include "journal.hpp"
#include "config.hpp"
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <thread>
#include <openssl/rand.h>

namespace natrav_overlay {
namespace {
void put_text(datacube::Octets& out,std::string_view s) {
    if(s.size()>256U){app_fail("PROJECTION_SCHEDULE_INVALID","text bound");}
    datacube::append_be16(out,static_cast<std::uint16_t>(s.size()));datacube::append_text(out,s);
}
std::string get_text(datacube::Reader& r) {
    const auto n=r.read_be16("schedule text");if(n>256U){app_fail("JOURNAL_CORRUPT","schedule text bound");}
    return datacube::octets_text(r.read_exact(n,"schedule text"),"schedule text",true);
}
void put_digest(datacube::Octets& out,const datacube::Digest32& d){datacube::append_octets(out,d.octets);}
datacube::Digest32 get_digest(datacube::Reader& r){datacube::Digest32 d{};const auto b=r.read_exact(32U,"schedule digest");std::copy(b.begin(),b.end(),d.octets.begin());return d;}
bool printable(std::string_view s){return !s.empty()&&s.size()<=256U&&std::all_of(s.begin(),s.end(),[](char c){return c>=32&&c<=126;});}
std::uint64_t now_ms(){return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count());}
void stamp(ProjectionSchedule& s,std::string_view transition,std::uint64_t event,std::uint32_t uid,std::uint32_t pid){
    if(s.revision==std::numeric_limits<std::uint64_t>::max()){app_fail("PROJECTION_SCHEDULE_LIMIT","schedule revision exhausted");}
    ++s.revision;s.transition=transition;s.configuration_event=event;s.unix_ms=now_ms();s.executor_uid=uid;s.pid=pid;
}
void finish(ProjectionGrant& g,const ProjectionSchedule& s,std::string_view phase,std::string_view reason){
    g.state=phase;g.error=reason;g.ended_event=s.configuration_event;g.ended_unix_ms=s.unix_ms;g.ended_pid=s.pid;g.ended_uid=s.executor_uid;
}
void require_admin(const RuntimeConfig& c,std::uint32_t uid){
    if(c.format_version<12U||!local_control_allows(c.local_control,uid,LocalControlClass::consumer_admin)){
        app_fail("LOCAL_CONTROL_CLASS_DENIED","explicit V12 CONSUMER_ADMIN authority required for own schedules");}
}
std::string authority_error(const RuntimeConfig& cfg,const DurableConsumer& c,const ProjectionGrant* grant=nullptr) {
    if(cfg.format_version<12U||!local_control_allows(cfg.local_control,c.uid,LocalControlClass::projection)||
       !local_control_allows(cfg.local_control,c.uid,LocalControlClass::consumer)||
       !local_control_allows(cfg.local_control,c.uid,LocalControlClass::consumer_admin)) {
        return "LOCAL_CONTROL_CLASS_DENIED";
    }
    const auto access=evidence_read_access(cfg.evidence_read,cfg.local_control,c.uid);
    if(!evidence_read_allows(access,c.selection.issuer,c.selection.scope,c.selection.include_payload)) {
        return "PROJECTION_READ_AUTHORITY_DENIED";
    }
    if(access.digest!=c.adoptions.back().authority ||
        (grant&&(grant->authority!=access.digest||grant->epoch!=c.adoptions.size()))) {
        return "CONSUMER_POLICY_CHANGED";
    }
    return {};
}
EvidenceQueryContext context_for(const RuntimeConfig& cfg,const DurableConsumer& c){
    EvidenceQueryContext context;context.uid=c.uid;
    context.read_access=evidence_read_access(cfg.evidence_read,cfg.local_control,c.uid);return context;
}
datacube::Digest32 page_digest(std::string_view rows){datacube::Octets b;datacube::append_text(b,"NATRAV_OVERLAY_CONSUMER_PAGE_V1");datacube::append_u8(b,0U);datacube::append_text(b,rows);return datacube::sha256(b);}
datacube::Digest32 random_batch(){datacube::Digest32 d{};if(RAND_priv_bytes(d.octets.data(),static_cast<int>(d.octets.size()))!=1){app_fail("CONSUMER_RANDOM_FAILED","automatic batch identity unavailable");}return d;}
void pause_test(const char* name){
    if(const char* p=std::getenv(name);p&&*p){std::fprintf(stderr,"PROJECTION_AUTO_BOUNDARY %s\n",name);std::fflush(stderr);
        std::this_thread::sleep_for(std::chrono::milliseconds(parse_u64(p,name,1U,60000U)));}
}
bool isolatable(std::string_view code){
    return code=="PROJECTION_NUMERIC_SUM_LIMIT"||code=="PROJECTION_ADMISSION_LIMIT"||code=="PROJECTION_BUDGET_EXHAUSTED"||
        code=="PROJECTION_ARITHMETIC_LIMIT"||code=="EVIDENCE_FEED_PAGE_TOO_SMALL"||code=="CONSUMER_RESPONSE_LIMIT"||
        code=="CONSUMER_REVISION_LIMIT";
}
std::string grant_json(const ProjectionGrant& g){
    return "{\"state\":"+json_string(g.state)+",\"reason\":"+json_string(g.reason)+",\"error\":"+json_string(g.error)+
        ",\"consumer_epoch\":"+std::to_string(g.epoch)+",\"configuration_event\":"+std::to_string(g.configuration_event)+
        ",\"authority_digest\":"+json_string(datacube::hex_lower(g.authority))+",\"grant_unix_ms\":"+std::to_string(g.unix_ms)+",\"grant_pid\":"+std::to_string(g.pid)+
        ",\"maximum_pages\":"+std::to_string(g.maximum_pages)+",\"minimum_interval_ms\":"+std::to_string(g.minimum_interval_ms)+
        ",\"pages_completed\":"+std::to_string(g.pages)+",\"from\":"+std::to_string(g.start_position)+",\"through\":"+std::to_string(g.position)+
        ",\"ended_configuration_event\":"+std::to_string(g.ended_event)+",\"ended_unix_ms\":"+std::to_string(g.ended_unix_ms)+
        ",\"ended_executor_uid\":"+std::to_string(g.ended_uid)+",\"ended_pid\":"+std::to_string(g.ended_pid)+"}";
}
}

datacube::Octets encode_projection_schedule(const ProjectionSchedule& s){
    datacube::Octets b;datacube::append_text(b,"NAS1");put_text(b,s.name);datacube::append_be32(b,s.uid);put_digest(b,s.instance);
    datacube::append_be64(b,s.revision);put_text(b,s.transition);datacube::append_be64(b,s.configuration_event);datacube::append_be64(b,s.unix_ms);
    datacube::append_be32(b,s.executor_uid);datacube::append_be32(b,s.pid);datacube::append_be32(b,static_cast<std::uint32_t>(s.grants.size()));
    for(const auto& g:s.grants){
        datacube::append_be64(b,g.epoch);datacube::append_be64(b,g.configuration_event);datacube::append_be64(b,g.unix_ms);datacube::append_be32(b,g.pid);
        datacube::append_be32(b,g.maximum_pages);datacube::append_be32(b,g.minimum_interval_ms);put_digest(b,g.authority);put_text(b,g.reason);
        datacube::append_be64(b,g.start_position);datacube::append_be64(b,g.position);datacube::append_be64(b,g.pages);put_text(b,g.state);put_text(b,g.error);
        datacube::append_be64(b,g.ended_event);datacube::append_be64(b,g.ended_unix_ms);datacube::append_be32(b,g.ended_uid);datacube::append_be32(b,g.ended_pid);
    }return b;
}
ProjectionSchedule decode_projection_schedule(datacube::OctetView bytes){
    datacube::Reader r(bytes,"projection schedule");if(datacube::octets_text(r.read_exact(4U,"magic"),"magic",true)!="NAS1"){app_fail("JOURNAL_CORRUPT","unknown schedule format");}
    ProjectionSchedule s;s.name=get_text(r);s.uid=r.read_be32("owner UID");s.instance=get_digest(r);s.revision=r.read_be64("schedule revision");s.transition=get_text(r);
    s.configuration_event=r.read_be64("configuration event");s.unix_ms=r.read_be64("schedule time");s.executor_uid=r.read_be32("executor UID");s.pid=r.read_be32("executor PID");
    const auto n=r.read_be32("grant count");if(n==0U||n>kProjectionGrantLimit){app_fail("JOURNAL_CORRUPT","schedule grant bound");}
    for(std::uint32_t i=0;i<n;++i){ProjectionGrant g;g.epoch=r.read_be64("epoch");g.configuration_event=r.read_be64("grant configuration");g.unix_ms=r.read_be64("grant time");g.pid=r.read_be32("grant PID");
        g.maximum_pages=r.read_be32("page budget");g.minimum_interval_ms=r.read_be32("minimum interval");g.authority=get_digest(r);g.reason=get_text(r);
        g.start_position=r.read_be64("from");g.position=r.read_be64("through");g.pages=r.read_be64("completed pages");g.state=get_text(r);g.error=get_text(r);
        g.ended_event=r.read_be64("end configuration");g.ended_unix_ms=r.read_be64("end time");g.ended_uid=r.read_be32("end UID");g.ended_pid=r.read_be32("end PID");s.grants.push_back(std::move(g));}
    r.require_eof("schedule");return s;
}
std::string projection_schedule_json(const ProjectionSchedule& s,bool history){
    auto out="{\"name\":"+json_string(s.name)+",\"owner_uid\":"+std::to_string(s.uid)+",\"generation\":"+std::to_string(s.grants.size())+
        ",\"revision\":"+std::to_string(s.revision)+",\"last_transition\":"+json_string(s.transition)+
        ",\"actor\":"+json_string(s.transition=="STEP"||s.transition=="BLOCK"?"DAEMON_PROJECTION_WORKER":"KERNEL_AUTHENTICATED_OWNER")+
        ",\"executor_uid\":"+std::to_string(s.executor_uid)+",\"executor_pid\":"+std::to_string(s.pid)+
        ",\"configuration_event\":"+std::to_string(s.configuration_event)+",\"unix_ms\":"+std::to_string(s.unix_ms)+",\"active\":"+grant_json(s.grants.back());
    if(history){out+=",\"grants\":[";for(std::size_t i=0;i<s.grants.size();++i){if(i){out+=',';}out+=grant_json(s.grants[i]);}out+=']';}return out+"}";
}

void NodeState::validate_projection_schedule_locked(const ProjectionSchedule& s) const {
    const auto bad=[](){app_fail("JOURNAL_CORRUPT","invalid projection scheduling grant, bounds or provenance");};
    const auto it=consumers_.find(consumer_key(s.uid,s.name));
    if(it==consumers_.end()||!it->second.projection||it->second.instance!=s.instance||s.revision==0U||s.grants.empty()||s.grants.size()>kProjectionGrantLimit||s.unix_ms==0U||s.pid==0U){bad();}
    const auto& c=it->second;
    const auto cfg_at=[&](std::uint64_t event){if(event==0U||event>configuration_events_.size()||configuration_events_[event-1U].kind=="REJECTED"){bad();}
        return parse_runtime_config(configuration_events_[event-1U].canonical,"/schedule-history",IdentityFileValidation::deferred);};
    static_cast<void>(cfg_at(s.configuration_event));
    std::uint64_t previous=0U, steps=0U;
    for(std::size_t i=0;i<s.grants.size();++i){const auto& g=s.grants[i];
        if(g.epoch==0U||g.epoch>c.adoptions.size()||g.configuration_event<previous||g.configuration_event>s.configuration_event||
            g.unix_ms==0U||g.pid==0U||g.maximum_pages==0U||g.maximum_pages>10000U||g.minimum_interval_ms<10U||g.minimum_interval_ms>60000U||
            !printable(g.reason)||g.pages>g.maximum_pages||g.position<g.start_position||g.position-g.start_position<g.pages||
            g.position-g.start_position>g.pages*c.selection.maximum_records){bad();}
        const auto cfg=cfg_at(g.configuration_event);require_admin(cfg,c.uid);
        const auto access=evidence_read_access(cfg.evidence_read,cfg.local_control,c.uid);
        if(!local_control_allows(cfg.local_control,c.uid,LocalControlClass::consumer)||!local_control_allows(cfg.local_control,c.uid,LocalControlClass::projection)||
            !evidence_read_allows(access,c.selection.issuer,c.selection.scope,c.selection.include_payload)||access.digest!=g.authority||
            c.adoptions[g.epoch-1U].authority!=g.authority||g.configuration_event<c.adoptions[g.epoch-1U].configuration_event){bad();}
        const auto frontier=g.epoch==c.adoptions.size()?c.position:c.projection->retired_results.at(g.epoch-1U).admissions;
        if(g.position>frontier){bad();}
        if(g.state=="ENABLED"){
            if(c.retirement){bad();}
            if(i+1U!=s.grants.size()||g.pages==g.maximum_pages||!g.error.empty()||g.ended_event||g.ended_unix_ms||g.ended_pid||g.ended_uid){bad();}
            if(g.epoch!=c.adoptions.size()||g.position!=c.position){bad();}
        }else{
            if((g.state!="PAUSED"&&g.state!="BLOCKED"&&g.state!="EXHAUSTED"&&g.state!="RETIRED")||!printable(g.error)||g.ended_event<g.configuration_event||g.ended_event>s.configuration_event||g.ended_unix_ms==0U||g.ended_pid==0U){bad();}
            const auto end_cfg=cfg_at(g.ended_event);
            if(g.state=="PAUSED"){require_admin(end_cfg,c.uid);if(g.ended_uid!=c.uid){bad();}}
            if(g.state=="RETIRED") {
                require_admin(end_cfg,c.uid);
                if(!c.retirement || i+1U!=s.grants.size() || g.ended_uid!=c.uid ||
                    g.ended_event!=c.retirement->configuration_event || g.ended_pid!=c.retirement->pid ||
                    g.ended_unix_ms!=c.retirement->unix_ms || g.error!=c.retirement->reason || s.transition!="RETIRE"){bad();}
            }
            if((g.state=="EXHAUSTED")!=(g.pages==g.maximum_pages)){bad();}
        }
        previous=g.ended_event?g.ended_event:g.configuration_event;steps+=g.pages;
    }
    if(s.revision<s.grants.size()+steps||(s.transition!="ENABLE"&&s.transition!="PAUSE"&&s.transition!="BLOCK"&&s.transition!="STEP"&&s.transition!="RETIRE")){bad();}
}

void NodeState::apply_projection_schedule_update(datacube::OctetView bytes,const bool validate_only){
    datacube::Reader r(bytes,"schedule transaction");
    if(datacube::octets_text(r.read_exact(4U,"magic"),"magic",true)!="NAU1"){app_fail("JOURNAL_CORRUPT","unknown automation transition");}
    const auto n=r.read_be32("schedule size");if(n>32000U){app_fail("JOURNAL_CORRUPT","schedule bound");}
    auto next=decode_projection_schedule(r.read_exact(n,"schedule"));
    const auto length=r.read_be32("consumer size");if(length>60000U){app_fail("JOURNAL_CORRUPT","consumer bound");}
    const auto consumer_bytes=r.read_exact(length,"automatic consumer");r.require_eof("schedule transition");
    const auto bad=[](){app_fail("JOURNAL_CORRUPT","schedule transition violated prior state or authority");};
    if(next.configuration_event!=active_configuration_event(configuration_events_)||next.configuration_event==0U){bad();}
    const auto key=consumer_key(next.uid,next.name);const auto cit=consumers_.find(key);
    if(cit==consumers_.end()||cit->second.retirement||!cit->second.projection||cit->second.instance!=next.instance||next.pid==0U||next.unix_ms==0U){bad();}
    const auto& c=cit->second;const auto previous=projection_schedules_.find(key);
    ProjectionSchedule expected;
    if(previous!=projection_schedules_.end()){expected=previous->second;}
    else {expected.name=c.name;expected.uid=c.uid;expected.instance=c.instance;}
    if(expected.revision==std::numeric_limits<std::uint64_t>::max()||next.revision!=expected.revision+1U){bad();}
    expected.revision=next.revision;expected.transition=next.transition;expected.configuration_event=next.configuration_event;
    expected.unix_ms=next.unix_ms;expected.executor_uid=next.executor_uid;expected.pid=next.pid;
    const auto cfg=parse_runtime_config(configuration_events_[next.configuration_event-1U].canonical,"/schedule-activation",IdentityFileValidation::deferred);
    if(next.transition=="ENABLE") {
        require_admin(cfg,c.uid);
        if(next.executor_uid!=c.uid||length||(!expected.grants.empty()&&expected.grants.back().state=="ENABLED")||
            next.grants.size()!=expected.grants.size()+1U||next.grants.size()>kProjectionGrantLimit||!authority_error(cfg,c).empty()){bad();}
        auto grant=next.grants.back();auto required=grant;
        required.epoch=c.adoptions.size();required.configuration_event=next.configuration_event;required.unix_ms=next.unix_ms;required.pid=next.pid;
        required.authority=c.adoptions.back().authority;required.start_position=c.position;required.position=c.position;required.pages=0U;
        required.state="ENABLED";required.error.clear();required.ended_event=0U;required.ended_unix_ms=0U;required.ended_pid=0U;required.ended_uid=0U;
        if(required!=grant){bad();}expected.grants.push_back(grant);
    }else {
        if(previous==projection_schedules_.end()||expected.grants.back().state!="ENABLED"||next.grants.size()!=expected.grants.size()){bad();}
        auto& grant=expected.grants.back();
        if(next.transition=="PAUSE"){
            require_admin(cfg,c.uid);if(next.executor_uid!=c.uid||length||!printable(next.grants.back().error)){bad();}
            finish(grant,next,"PAUSED",next.grants.back().error);
        }else if(next.transition=="STEP"){
            if(length==0U||!authority_error(cfg,c,&grant).empty()||c.position!=grant.position){bad();}
            const auto updated=decode_consumer(consumer_bytes);
            if(updated.uid!=c.uid||updated.name!=c.name||updated.pid!=next.pid||updated.unix_ms!=next.unix_ms||updated.configuration_event!=next.configuration_event||updated.transition!="AUTO_PROJECT"){bad();}
            apply_consumer_update(consumer_bytes,true,true);
            ++grant.pages;grant.position=updated.position;
            if(grant.pages==grant.maximum_pages){finish(grant,next,"EXHAUSTED","PROJECTION_PAGE_BUDGET_EXHAUSTED");}
        }else if(next.transition=="BLOCK"){
            if(length){bad();}
            auto error=authority_error(cfg,c,&grant);
            if(error.empty()) {
                try {
                    auto batch=c.pending;
                    if(!batch){const auto context=context_for(cfg,c);const auto total=evidence_feed_total_locked(c.selection,context);
                        const auto page=consumer_slice_locked(c,context,c.position,total);
                        if(page.count){ConsumerBatch b;b.from=c.position;b.through=page.next;batch=b;}}
                    if(!batch){bad();}
                    static_cast<void>(advance_projection_locked(c,*batch));
                }catch(const AppError& e){if(!isolatable(e.code())){throw;}error=e.code();}
            }
            if(error.empty()||next.grants.back().error!=error){bad();}finish(grant,next,"BLOCKED",error);
        }else{bad();}
    }
    if(encode_projection_schedule(expected)!=encode_projection_schedule(next)){bad();}
    // Validation of grant/frontier pairs uses the proposed consumer without
    // mutating persistent state. Only STEP advances the frontier; its exact
    // transition was verified above and the remaining bounds are checked here.
    if(next.grants.empty()||next.grants.back().maximum_pages==0U||next.grants.back().maximum_pages>10000U||
        next.grants.back().minimum_interval_ms<10U||next.grants.back().minimum_interval_ms>60000U||!printable(next.grants.back().reason)||
        next.grants.back().pages>next.grants.back().maximum_pages){bad();}
    if(!validate_only){
        if(length){apply_consumer_update(consumer_bytes,true);}
        projection_schedules_[key]=std::move(next);
        validate_projection_schedule_locked(projection_schedules_.at(key));
    }
}
void NodeState::commit_projection_schedule_locked(const ProjectionSchedule& s,const std::optional<DurableConsumer>& c){
    auto b=encode_projection_schedule(s);datacube::Octets record;datacube::append_text(record,"NAU1");datacube::append_be32(record,static_cast<std::uint32_t>(b.size()));datacube::append_octets(record,b);
    const auto encoded=c?encode_consumer(*c):datacube::Octets{};datacube::append_be32(record,static_cast<std::uint32_t>(encoded.size()));datacube::append_octets(record,encoded);
    apply_projection_schedule_update(record,true);
    if(s.transition=="STEP"){pause_test("NATRAV_OVERLAY_TEST_AUTO_BEFORE_COMMIT_MS");}
    append_entry(EntryKind::projection_schedule,record);
    if(s.transition=="STEP"){pause_test("NATRAV_OVERLAY_TEST_AUTO_AFTER_COMMIT_MS");}
}
std::string NodeState::projection_schedule_command_locked(const ConsumerRequest& r,const EvidenceQueryContext& context,std::uint32_t pid,std::uint64_t event){
    const auto key=consumer_key(context.uid,r.name);const auto cit=consumers_.find(key);
    if(cit==consumers_.end()||!cit->second.projection){app_fail("PROJECTION_NOT_FOUND","no projection owned by this connected UID");}
    const auto cfg=parse_runtime_config(configuration_events_[event-1U].canonical,"/schedule-command",IdentityFileValidation::deferred);require_admin(cfg,context.uid);
    const auto it=projection_schedules_.find(key);const std::size_t generation=it==projection_schedules_.end()?0U:it->second.grants.size();
    std::string disposition="STATUS";
    if(r.command!=ConsumerCommand::projection_schedule_status){
        if(r.expected_revision!=generation){app_fail("PROJECTION_SCHEDULE_GENERATION_CONFLICT","select the exact observed grant generation");}
        if(r.command==ConsumerCommand::projection_enable){
            const auto error=authority_error(cfg,cit->second);if(!error.empty()){app_fail(error,"current adopted payload/metadata and processing authority required");}
            if(it!=projection_schedules_.end()&&it->second.grants.back().state=="ENABLED"){app_fail("PROJECTION_SCHEDULE_ALREADY_ENABLED","pause before granting a new bounded run");}
            if(generation>=kProjectionGrantLimit){app_fail("PROJECTION_SCHEDULE_HISTORY_LIMIT","32 durable grants retained; pause remains available");}
            ProjectionSchedule next;if(it!=projection_schedules_.end()){next=it->second;}
            else{next.uid=context.uid;next.name=r.name;next.instance=cit->second.instance;}
            stamp(next,"ENABLE",event,context.uid,pid);
            ProjectionGrant g;g.epoch=cit->second.adoptions.size();g.configuration_event=event;g.unix_ms=next.unix_ms;g.pid=pid;
            g.maximum_pages=r.automatic_maximum_pages;g.minimum_interval_ms=r.automatic_minimum_interval_ms;g.authority=context.read_access.digest;g.reason=r.reason;
            g.start_position=cit->second.position;g.position=cit->second.position;next.grants.push_back(g);
            commit_projection_schedule_locked(next,std::nullopt);disposition="ENABLED";
        }else if(it!=projection_schedules_.end()&&it->second.grants.back().state=="ENABLED"){
            auto next=it->second;stamp(next,"PAUSE",event,context.uid,pid);finish(next.grants.back(),next,"PAUSED",r.reason);
            commit_projection_schedule_locked(next,std::nullopt);disposition="PAUSED";
        }else{disposition="ALREADY_STOPPED";}
    }
    const auto found=projection_schedules_.find(key);
    return "{\"format\":\"NATRAV_OVERLAY_PROJECTION_SCHEDULE_V1\",\"ok\":true,\"disposition\":"+json_string(disposition)+
        ",\"schedule\":"+(found==projection_schedules_.end()?"null":projection_schedule_json(found->second,true))+"}";
}
std::vector<ProjectionCandidate> NodeState::automatic_projection_candidates() const {
    std::lock_guard<std::mutex> lock(mutex_);std::vector<ProjectionCandidate> out;
    for(const auto& [key,s]:projection_schedules_){if(!consumers_.at(key).retirement && s.grants.back().state=="ENABLED"){
        out.push_back({key,s.grants.size(),s.grants.back().minimum_interval_ms});}}
    return out;
}
bool NodeState::automatic_projection_step(std::string_view key,const RuntimeConfig& cfg,std::uint64_t event,std::uint32_t executor_uid,std::uint32_t executor_pid){
    std::lock_guard<std::mutex> lock(mutex_);
    if(poisoned_){app_fail("STATE_RESTART_REQUIRED","automatic writer requires restart");}
    if(event==0U||event!=active_configuration_event(configuration_events_)){app_fail("CONSUMER_CONFIGURATION_MISMATCH","automatic step must retain active generation");}
    const auto it=projection_schedules_.find(std::string(key));if(it==projection_schedules_.end()||consumers_.at(std::string(key)).retirement||it->second.grants.back().state!="ENABLED"){return false;}
    const auto& current=consumers_.at(std::string(key));auto schedule=it->second;auto& grant=schedule.grants.back();
    auto error=authority_error(cfg,current,&grant);
    if(error.empty()) {
        const auto context=context_for(cfg,current);const auto total=evidence_feed_total_locked(current.selection,context);
        if(!current.pending&&current.position==total){return false;}
        try {
            auto batch=current.pending;
            const auto time=now_ms();
            if(!batch){const auto page=consumer_slice_locked(current,context,current.position,total);ConsumerBatch b;
                b.id=random_batch();b.from=current.position;b.through=page.next;b.rows_digest=page_digest(page.rows);b.configuration_event=event;b.unix_ms=time;b.pid=executor_pid;batch=b;}
            auto updated=current;
            if(updated.revision==std::numeric_limits<std::uint64_t>::max()){app_fail("CONSUMER_REVISION_LIMIT","revision exhausted");}
            updated.projection=advance_projection_locked(current,*batch);++updated.revision;updated.transition="AUTO_PROJECT";updated.configuration_event=event;updated.unix_ms=time;updated.pid=executor_pid;
            updated.position=batch->through;updated.last_ack=batch;updated.pending.reset();++updated.acknowledgments;
            stamp(schedule,"STEP",event,executor_uid,executor_pid);schedule.unix_ms=time;
            ++grant.pages;grant.position=updated.position;
            if(grant.pages==grant.maximum_pages){finish(grant,schedule,"EXHAUSTED","PROJECTION_PAGE_BUDGET_EXHAUSTED");}
            commit_projection_schedule_locked(schedule,updated);return true;
        }catch(const AppError& e){if(!isolatable(e.code())){throw;}error=e.code();}
    }
    schedule=it->second;stamp(schedule,"BLOCK",event,executor_uid,executor_pid);finish(schedule.grants.back(),schedule,"BLOCKED",error);
    commit_projection_schedule_locked(schedule,std::nullopt);return true;
}
} // namespace natrav_overlay
