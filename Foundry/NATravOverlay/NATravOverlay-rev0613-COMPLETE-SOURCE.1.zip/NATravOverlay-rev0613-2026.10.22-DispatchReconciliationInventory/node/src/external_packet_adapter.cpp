#include "external_packet_adapter.hpp"

#include "common.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <climits>
#include <csignal>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <deque>
#include <fcntl.h>
#include <limits>
#include <mutex>
#include <optional>
#include <poll.h>
#include <sys/prctl.h>
#include <span>
#include <string>
#include <string_view>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <thread>
#include <unistd.h>
#include <utility>
#include <vector>

namespace natrav_overlay {

int supervised_external_packet_adapter_revision_abi() noexcept { return 1; }

namespace {

using Bytes = natrav::packet_link::Bytes;

inline constexpr std::array<std::uint8_t, 8U> kProtocolMagic{
    'N', 'A', 'P', 'A', '0', '0', '0', '1'};
inline constexpr std::size_t kFrameHeaderBytes = 36U;
inline constexpr std::uint32_t kProtocolProfile = 1U;
inline constexpr int kAdapterDescriptor = 3;
inline constexpr std::size_t kMaximumArguments = 64U;
inline constexpr std::size_t kMaximumArgumentBytes = 4'096U;
inline constexpr std::size_t kMaximumTotalArgumentBytes = 16'384U;
inline constexpr std::size_t kMinimumMtu = 256U;
inline constexpr std::size_t kMaximumMtu = 65'507U;
inline constexpr std::size_t kAbsoluteMaximumFrameBytes = 1'048'576U;
inline constexpr std::size_t kAbsoluteMaximumQueuedBytes = 64U * 1'048'576U;
inline constexpr std::uint32_t kMaximumLaunchAttempts = 8U;
inline constexpr std::uint32_t kUnknownChildStatus =
    std::numeric_limits<std::uint32_t>::max();

[[nodiscard]] bool duration_in_range(
    const std::chrono::milliseconds value,
    const std::chrono::milliseconds minimum,
    const std::chrono::milliseconds maximum) noexcept {
    return value >= minimum && value <= maximum;
}

[[nodiscard]] int poll_timeout_ms(const Deadline deadline) {
    const auto now = std::chrono::steady_clock::now();
    if (now >= deadline) {
        return 0;
    }
    const auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(
        deadline - now);
    const auto count = std::max<std::chrono::milliseconds::rep>(
        remaining.count(), 1);
    return static_cast<int>(std::min<std::chrono::milliseconds::rep>(
        count, static_cast<std::chrono::milliseconds::rep>(INT_MAX)));
}

[[nodiscard]] std::uint32_t deadline_budget_ms(const Deadline deadline) {
    const auto now = std::chrono::steady_clock::now();
    if (now >= deadline) {
        return 0U;
    }
    const auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(
        deadline - now);
    const auto count = std::max<std::chrono::milliseconds::rep>(
        remaining.count(), 1);
    return static_cast<std::uint32_t>(std::min<std::chrono::milliseconds::rep>(
        count,
        static_cast<std::chrono::milliseconds::rep>(
            std::numeric_limits<std::uint32_t>::max())));
}

[[nodiscard]] std::uint32_t checked_u32(
    const std::size_t value,
    const std::string_view field) {
    if (value > std::numeric_limits<std::uint32_t>::max()) {
        app_fail("ADAPTER_OPTIONS_INVALID", std::string(field));
    }
    return static_cast<std::uint32_t>(value);
}

enum class FrameType : std::uint8_t {
    hello_request = 1U,
    hello_response = 2U,
    transmit_request = 3U,
    transmit_response = 4U,
    receive_request = 5U,
    receive_response = 6U,
    ping_request = 7U,
    ping_response = 8U,
    shutdown_request = 9U,
    shutdown_response = 10U,
    fault = 11U,
};

enum class AdapterStatus : std::uint32_t {
    ok = 0U,
    no_data = 1U,
    busy = 2U,
    malformed = 3U,
    resource_exhausted = 4U,
    reset = 5U,
    deadline_exceeded = 6U,
    unsupported = 7U,
};

struct ProtocolFrame final {
    FrameType type{FrameType::fault};
    std::uint64_t sequence{0U};
    std::uint32_t deadline_ms{0U};
    AdapterStatus status{AdapterStatus::ok};
    Bytes payload{};
};

[[nodiscard]] bool valid_frame_type(const std::uint8_t value) noexcept {
    return value >= static_cast<std::uint8_t>(FrameType::hello_request) &&
        value <= static_cast<std::uint8_t>(FrameType::fault);
}

[[nodiscard]] bool valid_status(const std::uint32_t value) noexcept {
    return value <= static_cast<std::uint32_t>(AdapterStatus::unsupported);
}

[[nodiscard]] Bytes checksum_input(
    const std::span<const std::uint8_t> prefix,
    const std::span<const std::uint8_t> payload) {
    Bytes input;
    input.reserve(prefix.size() + payload.size());
    input.insert(input.end(), prefix.begin(), prefix.end());
    input.insert(input.end(), payload.begin(), payload.end());
    return input;
}

[[nodiscard]] Bytes encode_frame(const ProtocolFrame& frame) {
    if (frame.sequence == 0U || frame.payload.size() >
            std::numeric_limits<std::uint32_t>::max()) {
        app_fail("ADAPTER_PROTOCOL_INVALID", "invalid adapter frame fields");
    }
    Bytes output;
    output.reserve(kFrameHeaderBytes + frame.payload.size());
    output.insert(output.end(), kProtocolMagic.begin(), kProtocolMagic.end());
    datacube::append_u8(output, static_cast<std::uint8_t>(frame.type));
    datacube::append_u8(output, 0U);
    datacube::append_be16(output, 0U);
    datacube::append_be64(output, frame.sequence);
    datacube::append_be32(output, frame.deadline_ms);
    datacube::append_be32(output, static_cast<std::uint32_t>(frame.status));
    datacube::append_be32(output, static_cast<std::uint32_t>(frame.payload.size()));
    const auto checksum_bytes = checksum_input(output, frame.payload);
    datacube::append_be32(
        output,
        natrav::packet_link::FrameCodec::crc32(checksum_bytes));
    output.insert(output.end(), frame.payload.begin(), frame.payload.end());
    return output;
}

[[nodiscard]] ProtocolFrame decode_frame(
    const std::span<const std::uint8_t> bytes,
    const std::size_t maximum_frame_bytes) {
    if (bytes.size() < kFrameHeaderBytes || bytes.size() > maximum_frame_bytes) {
        app_fail("ADAPTER_PROTOCOL_INVALID", "adapter frame size is outside bounds");
    }
    datacube::Reader reader(bytes, "external packet adapter frame");
    const auto magic = reader.read_exact(kProtocolMagic.size(), "magic");
    if (!std::equal(kProtocolMagic.begin(), kProtocolMagic.end(), magic.begin())) {
        app_fail("ADAPTER_PROTOCOL_INVALID", "adapter frame magic mismatch");
    }
    const auto raw_type = reader.read_u8("type");
    const auto flags = reader.read_u8("flags");
    const auto reserved = reader.read_be16("reserved");
    const auto sequence = reader.read_be64("sequence");
    const auto deadline_ms = reader.read_be32("deadline");
    const auto raw_status = reader.read_be32("status");
    const auto payload_bytes = reader.read_be32("payload bytes");
    const auto expected_crc = reader.read_be32("crc32");
    if (!valid_frame_type(raw_type) || flags != 0U || reserved != 0U ||
        sequence == 0U || !valid_status(raw_status) ||
        static_cast<std::size_t>(payload_bytes) != reader.remaining()) {
        app_fail("ADAPTER_PROTOCOL_INVALID", "adapter frame is noncanonical");
    }
    const auto payload_view = reader.read_exact(payload_bytes, "payload");
    reader.require_eof("adapter frame");
    const auto checksum_bytes = checksum_input(
        bytes.first(32U), payload_view);
    if (natrav::packet_link::FrameCodec::crc32(checksum_bytes) != expected_crc) {
        app_fail("ADAPTER_PROTOCOL_INVALID", "adapter frame checksum mismatch");
    }
    return ProtocolFrame{
        .type = static_cast<FrameType>(raw_type),
        .sequence = sequence,
        .deadline_ms = deadline_ms,
        .status = static_cast<AdapterStatus>(raw_status),
        .payload = Bytes(payload_view.begin(), payload_view.end()),
    };
}

[[nodiscard]] std::string bounded_fault_detail(const Bytes& payload) {
    if (payload.empty()) {
        return "adapter reported a fault";
    }
    if (payload.size() > 256U ||
        !std::all_of(payload.begin(), payload.end(), [](const std::uint8_t value) {
            return value >= 0x20U && value <= 0x7eU;
        })) {
        return "adapter reported a noncanonical fault detail";
    }
    return std::string(payload.begin(), payload.end());
}

[[noreturn]] void throw_adapter_status(
    const AdapterStatus status,
    const Bytes& detail) {
    const auto text = bounded_fault_detail(detail);
    switch (status) {
        case AdapterStatus::resource_exhausted:
            app_fail("ADAPTER_RESOURCE_EXHAUSTED", text);
        case AdapterStatus::reset:
            app_fail("PEER_RESET", text);
        case AdapterStatus::deadline_exceeded:
            app_fail("ADAPTER_TIMEOUT", text);
        case AdapterStatus::malformed:
        case AdapterStatus::unsupported:
            app_fail("ADAPTER_PROTOCOL_VIOLATION", text);
        case AdapterStatus::busy:
            app_fail("ADAPTER_BUSY_INVALID", text);
        case AdapterStatus::no_data:
            app_fail("ADAPTER_STATUS_INVALID", text);
        case AdapterStatus::ok:
            app_fail("ADAPTER_STATUS_INVALID", "unexpected successful fault status");
    }
    app_fail("ADAPTER_STATUS_INVALID", "unknown adapter status");
}

[[nodiscard]] std::string child_status_text(const int status) {
    if (WIFEXITED(status)) {
        return "exit=" + std::to_string(WEXITSTATUS(status));
    }
    if (WIFSIGNALED(status)) {
        return "signal=" + std::to_string(WTERMSIG(status));
    }
    return "status=" + std::to_string(status);
}

void validate_executable(const std::filesystem::path& executable) {
    const auto text = executable.string();
    if (text.empty() || text.size() > 4'096U || text.find('\0') != std::string::npos ||
        !executable.is_absolute() || executable.lexically_normal() != executable) {
        app_fail(
            "ADAPTER_EXECUTABLE_INVALID",
            "adapter executable must be one canonical absolute path");
    }
    struct stat status {};
    if (::lstat(text.c_str(), &status) != 0 || !S_ISREG(status.st_mode) ||
        (status.st_mode & (S_IWGRP | S_IWOTH)) != 0 ||
        (status.st_uid != ::geteuid() && status.st_uid != 0U) ||
        ::access(text.c_str(), X_OK) != 0) {
        app_fail(
            "ADAPTER_EXECUTABLE_INVALID",
            "adapter executable must be a stable non-writable executable file owned by the effective user or root");
    }
}

void validate_options(const ExternalPacketAdapterOptions& options) {
    const bool has_profile = options.pinned_profile.has_value();
    const bool has_image = static_cast<bool>(options.verified_executable);
    if (has_profile != has_image) {
        app_fail(
            "ADAPTER_PROFILE_INVALID",
            "pinned profile and verified executable must be supplied together");
    }
    if (has_profile) {
        const auto& profile = *options.pinned_profile;
        try {
            validate_operator_pinned_adapter_profile(profile);
        } catch (const AdapterProfileError& error) {
            app_fail(error.code(), error.what());
        }
        AdapterSha256 canonical_profile_sha256{};
        try {
            canonical_profile_sha256 =
                operator_pinned_adapter_profile_sha256(profile);
        } catch (const AdapterProfileError& error) {
            app_fail(error.code(), error.what());
        }
        if (options.pinned_profile_sha256 != canonical_profile_sha256 ||
            options.verified_executable->configured_path() != profile.executable ||
            options.verified_executable->sha256() != profile.executable_sha256 ||
            options.executable != profile.executable ||
            options.arguments != profile.arguments ||
            options.requested_mtu != profile.mtu ||
            options.profile != profile.capability_profile ||
            options.max_frame_bytes != profile.max_frame_bytes ||
            options.max_queued_bytes != profile.max_queued_bytes ||
            options.max_outstanding_requests !=
                profile.max_outstanding_requests ||
            options.max_evidence_events != profile.max_evidence_events ||
            options.max_launch_attempts != profile.max_launch_attempts ||
            options.startup_timeout != profile.startup_timeout ||
            options.request_timeout != profile.request_timeout ||
            options.shutdown_timeout != profile.shutdown_timeout ||
            options.initial_restart_backoff !=
                profile.initial_restart_backoff ||
            options.maximum_restart_backoff !=
                profile.maximum_restart_backoff) {
            app_fail(
                "ADAPTER_PROFILE_DRIFT",
                "launch options differ from the operator-authorized profile");
        }
    } else {
        validate_executable(options.executable);
    }
    if (options.requested_mtu < kMinimumMtu ||
        options.requested_mtu > kMaximumMtu ||
        options.profile != kProtocolProfile ||
        options.max_frame_bytes < kFrameHeaderBytes + options.requested_mtu ||
        options.max_frame_bytes > kAbsoluteMaximumFrameBytes ||
        options.max_queued_bytes < options.requested_mtu ||
        options.max_queued_bytes > kAbsoluteMaximumQueuedBytes ||
        options.max_outstanding_requests != 1U ||
        options.max_evidence_events < 16U ||
        options.max_evidence_events > 4'096U ||
        options.max_launch_attempts == 0U ||
        options.max_launch_attempts > kMaximumLaunchAttempts ||
        !duration_in_range(options.startup_timeout,
                           std::chrono::milliseconds(10),
                           std::chrono::seconds(60)) ||
        !duration_in_range(options.request_timeout,
                           std::chrono::milliseconds(1),
                           std::chrono::seconds(30)) ||
        !duration_in_range(options.shutdown_timeout,
                           std::chrono::milliseconds(1),
                           std::chrono::seconds(30)) ||
        !duration_in_range(options.initial_restart_backoff,
                           std::chrono::milliseconds(1),
                           std::chrono::seconds(10)) ||
        !duration_in_range(options.maximum_restart_backoff,
                           options.initial_restart_backoff,
                           std::chrono::seconds(30))) {
        app_fail("ADAPTER_OPTIONS_INVALID", "external adapter bounds are invalid");
    }
    if (options.arguments.size() > kMaximumArguments) {
        app_fail("ADAPTER_OPTIONS_INVALID", "too many adapter arguments");
    }
    std::size_t total = options.executable.string().size() + 1U;
    for (const auto& argument : options.arguments) {
        if (argument.size() > kMaximumArgumentBytes ||
            argument.find('\0') != std::string::npos ||
            argument.size() > std::numeric_limits<std::size_t>::max() - total - 1U) {
            app_fail("ADAPTER_OPTIONS_INVALID", "adapter argument is invalid");
        }
        total += argument.size() + 1U;
    }
    if (total > kMaximumTotalArgumentBytes) {
        app_fail("ADAPTER_OPTIONS_INVALID", "adapter argument vector is too large");
    }
}

}  // namespace

struct SupervisedExternalPacketAdapterControl::State final {
    explicit State(const std::size_t event_limit)
        : maximum_events(event_limit) {}

    void record(const ExternalPacketAdapterEvent event) {
        std::lock_guard lock(mutex);
        if (snapshot.events.size() < maximum_events) {
            snapshot.events.push_back(event);
        } else {
            ++snapshot.dropped_evidence_events;
        }
    }

    mutable std::mutex mutex;
    ExternalPacketAdapterSnapshot snapshot{};
    std::size_t maximum_events{0U};
};

namespace {

void mutate_snapshot(
    const std::shared_ptr<SupervisedExternalPacketAdapterControl::State>& state,
    const auto& mutation) {
    std::lock_guard lock(state->mutex);
    mutation(state->snapshot);
}

class SupervisedAdapterPacketPort final : public OwnedCompleteDatagramPacketPort {
public:
    SupervisedAdapterPacketPort(
        ExternalPacketAdapterOptions options,
        std::shared_ptr<SupervisedExternalPacketAdapterControl::State> state)
        : options_(std::move(options)), state_(std::move(state)) {
        validate_options(options_);
        const long configured_max = ::sysconf(_SC_OPEN_MAX);
        maximum_descriptor_ = configured_max < 4L ? 1'024 :
            static_cast<int>(std::min<long>(configured_max, INT_MAX));
        launch_bounded();
    }

    ~SupervisedAdapterPacketPort() override { shutdown_noexcept(); }

    [[nodiscard]] TransportKind transport_kind() const noexcept override {
        return TransportKind::packet_link;
    }

    [[nodiscard]] std::size_t mtu() const noexcept override {
        return capabilities_.mtu;
    }

    void set_operation_deadline(const Deadline deadline) noexcept override { operation_deadline_ = deadline; }

    [[nodiscard]] bool send_packet(const Bytes& packet) override {
        std::lock_guard lock(io_mutex_);
        if (packet.empty() || packet.size() > capabilities_.mtu) {
            app_fail("ADAPTER_PACKET_INVALID", "outbound adapter datagram is invalid");
        }
        const auto response = transact(
            FrameType::transmit_request,
            FrameType::transmit_response,
            packet,
            std::min(operation_deadline_, std::chrono::steady_clock::now() + options_.request_timeout));
        if (response.status == AdapterStatus::busy) {
            mutate_snapshot(state_, [](ExternalPacketAdapterSnapshot& snapshot) {
                ++snapshot.busy_responses;
            });
            return false;
        }
        require_success(response, "transmit");
        if (!response.payload.empty()) {
            protocol_failure("transmit response carried an unexpected payload");
        }
        mutate_snapshot(state_, [](ExternalPacketAdapterSnapshot& snapshot) {
            ++snapshot.transmitted_packets;
        });
        return true;
    }

    [[nodiscard]] std::optional<Bytes> receive_packet() override {
        std::lock_guard lock(io_mutex_);
        const auto response = transact(
            FrameType::receive_request,
            FrameType::receive_response,
            {},
            std::min(operation_deadline_, std::chrono::steady_clock::now() + options_.request_timeout));
        if (response.status == AdapterStatus::no_data) {
            if (!response.payload.empty()) {
                protocol_failure("no-data response carried an unexpected payload");
            }
            return std::nullopt;
        }
        require_success(response, "receive");
        if (response.payload.empty() || response.payload.size() > capabilities_.mtu) {
            protocol_failure("received adapter datagram is outside negotiated bounds");
        }
        mutate_snapshot(state_, [](ExternalPacketAdapterSnapshot& snapshot) {
            ++snapshot.received_packets;
        });
        return response.payload;
    }

    void wait_for_progress(
        const Deadline wake_deadline,
        const Deadline operation_deadline,
        IoCounters& counters,
        const std::string_view operation) override {
        std::lock_guard lock(io_mutex_);
        ensure_running();
        if (std::chrono::steady_clock::now() >= operation_deadline) {
            app_fail("IO_TIMEOUT", std::string(operation));
        }
        pollfd item{
            .fd = descriptor_.get(),
            .events = static_cast<short>(POLLIN | POLLERR | POLLHUP),
            .revents = 0,
        };
        ++counters.poll_calls;
        int result = 0;
        do {
            result = ::poll(&item, 1U, poll_timeout_ms(std::min(wake_deadline, operation_deadline)));
            if (result < 0 && errno == EINTR) {
                ++counters.interrupted;
            }
        } while (result < 0 && errno == EINTR);
        if (result < 0) {
            app_fail(
                "ADAPTER_POLL_FAILED",
                datacube::errno_detail(operation, errno));
        }
        if (result == 0) {
            ++counters.would_block;
            if (std::chrono::steady_clock::now() >= operation_deadline) {
                app_fail("IO_TIMEOUT", std::string(operation));
            }
            ensure_running();
            return;
        }
        ensure_running();
        if ((item.revents & POLLNVAL) != 0) {
            app_fail("ADAPTER_SOCKET_INVALID", std::string(operation));
        }
        if ((item.revents & POLLIN) != 0) {
            protocol_failure("adapter sent an unsolicited frame");
        }
        if ((item.revents & (POLLERR | POLLHUP)) != 0) {
            runtime_reset("external packet adapter disconnected");
        }
    }

private:
    void launch_bounded() {
        std::string last_code;
        std::string last_detail;
        auto backoff = options_.initial_restart_backoff;
        for (std::uint32_t attempt = 1U;
             attempt <= options_.max_launch_attempts;
             ++attempt) {
            if (attempt != 1U) {
                std::this_thread::sleep_until(std::min(options_.launch_deadline,
                    std::chrono::steady_clock::now() + backoff));
                const auto doubled = backoff * 2;
                backoff = std::min(doubled, options_.maximum_restart_backoff);
                mutate_snapshot(state_, [](ExternalPacketAdapterSnapshot& snapshot) {
                    ++snapshot.restarts;
                });
            }
            if (std::chrono::steady_clock::now() >= options_.launch_deadline) {
                app_fail("IO_TIMEOUT", "external adapter startup deadline");
            }
            mutate_snapshot(state_, [](ExternalPacketAdapterSnapshot& snapshot) {
                ++snapshot.launch_attempts;
            });
            state_->record(ExternalPacketAdapterEvent{
                .kind = ExternalPacketAdapterEventKind::launch_attempt,
                .process_id = 0,
            });
            try {
                launch_once();
                perform_hello();
                state_->record(ExternalPacketAdapterEvent{
                    .kind = ExternalPacketAdapterEventKind::launch_ready,
                    .process_id = static_cast<std::int64_t>(process_id_),
                });
                return;
            } catch (const AppError& error) {
                last_code = error.code();
                last_detail = error.what();
                terminate_current_noexcept(true);
            }
        }
        app_fail(
            "ADAPTER_START_FAILED",
            last_code + ": " + last_detail);
    }

    void launch_once() {
        std::array<int, 2U> descriptors{-1, -1};
        if (::socketpair(
                AF_UNIX,
                SOCK_SEQPACKET | SOCK_CLOEXEC | SOCK_NONBLOCK,
                0,
                descriptors.data()) != 0) {
            app_fail(
                "ADAPTER_SOCKET_FAILED",
                datacube::errno_detail("adapter socketpair", errno));
        }
        datacube::Fd parent(descriptors[0U]);
        datacube::Fd child(descriptors[1U]);
        std::vector<std::string> argument_storage;
        argument_storage.reserve(options_.arguments.size() + 1U);
        argument_storage.push_back(options_.executable.string());
        argument_storage.insert(
            argument_storage.end(),
            options_.arguments.begin(),
            options_.arguments.end());
        std::vector<char*> arguments;
        arguments.reserve(argument_storage.size() + 1U);
        for (auto& argument : argument_storage) {
            arguments.push_back(argument.data());
        }
        arguments.push_back(nullptr);

        std::array<char*, 6U> environment{
            const_cast<char*>("NATRAV_ADAPTER_FD=3"),
            const_cast<char*>("NATRAV_ADAPTER_PROTOCOL=NAPA0001"),
            const_cast<char*>("LANG=C"),
            const_cast<char*>("LC_ALL=C"),
            const_cast<char*>("PYTHONDONTWRITEBYTECODE=1"),
            nullptr,
        };

        int verified_image_descriptor = -1;
        if (options_.verified_executable) {
            try {
                verified_image_descriptor =
                    options_.verified_executable->duplicate_for_exec(
                        kAdapterDescriptor + 1);
            } catch (const AdapterProfileError& error) {
                app_fail(error.code(), error.what());
            }
        }

        const pid_t parent_process_id = ::getpid();
        const pid_t child_id = ::fork();
        if (child_id < 0) {
            const int fork_errno = errno;
            if (verified_image_descriptor >= 0) {
                static_cast<void>(::close(verified_image_descriptor));
            }
            app_fail(
                "ADAPTER_FORK_FAILED",
                datacube::errno_detail("adapter fork", fork_errno));
        }
        if (child_id == 0) {
            if (::prctl(PR_SET_PDEATHSIG, SIGKILL) != 0 ||
                ::getppid() != parent_process_id ||
                ::prctl(PR_SET_NO_NEW_PRIVS, 1L, 0L, 0L, 0L) != 0) {
                _exit(125);
            }
            static_cast<void>(::umask(S_IRWXG | S_IRWXO));
            const int parent_raw = parent.get();
            const int child_raw = child.get();
            if (parent_raw >= 0) {
                static_cast<void>(::close(parent_raw));
            }
            if (child_raw != kAdapterDescriptor) {
                if (::dup2(child_raw, kAdapterDescriptor) < 0) {
                    _exit(125);
                }
                static_cast<void>(::close(child_raw));
            }
            const int descriptor_flags = ::fcntl(kAdapterDescriptor, F_GETFD, 0);
            if (descriptor_flags < 0 ||
                ::fcntl(
                    kAdapterDescriptor,
                    F_SETFD,
                    descriptor_flags & ~FD_CLOEXEC) != 0) {
                _exit(125);
            }
            const int status_flags = ::fcntl(kAdapterDescriptor, F_GETFL, 0);
            if (status_flags < 0 ||
                ::fcntl(
                    kAdapterDescriptor,
                    F_SETFL,
                    status_flags & ~O_NONBLOCK) != 0) {
                _exit(125);
            }
            int executable_descriptor = verified_image_descriptor;
            if (executable_descriptor >= 0 &&
                executable_descriptor != kAdapterDescriptor + 1) {
                if (::dup3(
                        executable_descriptor,
                        kAdapterDescriptor + 1,
                        O_CLOEXEC) < 0) {
                    _exit(125);
                }
                static_cast<void>(::close(executable_descriptor));
                executable_descriptor = kAdapterDescriptor + 1;
            }
            if (executable_descriptor >= 0) {
                const int image_flags =
                    ::fcntl(executable_descriptor, F_GETFD, 0);
                if (image_flags < 0 ||
                    ::fcntl(
                        executable_descriptor,
                        F_SETFD,
                        image_flags | FD_CLOEXEC) != 0) {
                    _exit(125);
                }
            }
            const int null_descriptor = ::open("/dev/null", O_RDWR | O_CLOEXEC);
            if (null_descriptor < 0) {
                _exit(125);
            }
            for (int target = 0; target <= 2; ++target) {
                if (::dup2(null_descriptor, target) < 0) {
                    _exit(125);
                }
            }
            if (null_descriptor > kAdapterDescriptor +
                    (executable_descriptor >= 0 ? 1 : 0)) {
                static_cast<void>(::close(null_descriptor));
            }
            const int first_unrelated_descriptor =
                executable_descriptor >= 0 ? kAdapterDescriptor + 2 :
                    kAdapterDescriptor + 1;
            bool unrelated_descriptors_closed = false;
#if defined(SYS_close_range)
            if (::syscall(
                    SYS_close_range,
                    static_cast<unsigned int>(first_unrelated_descriptor),
                    ~0U,
                    0U) == 0) {
                unrelated_descriptors_closed = true;
            } else if (errno != ENOSYS && errno != EINVAL) {
                _exit(125);
            }
#endif
            if (!unrelated_descriptors_closed) {
                for (int descriptor = first_unrelated_descriptor;
                     descriptor < maximum_descriptor_;
                     ++descriptor) {
                    static_cast<void>(::close(descriptor));
                }
            }
            if (executable_descriptor >= 0) {
                static_cast<void>(execute_verified_adapter_image(
                    executable_descriptor,
                    arguments.data(),
                    environment.data()));
            } else {
                ::execve(
                    options_.executable.c_str(),
                    arguments.data(),
                    environment.data());
            }
            _exit(126);
        }

        if (verified_image_descriptor >= 0) {
            static_cast<void>(::close(verified_image_descriptor));
        }
        child.reset();
        descriptor_ = std::move(parent);
        process_id_ = child_id;
        child_exit_recorded_ = false;
        mutate_snapshot(state_, [&](ExternalPacketAdapterSnapshot& snapshot) {
            snapshot.running = true;
            snapshot.process_id = static_cast<std::int64_t>(process_id_);
        });
    }

    void perform_hello() {
        Bytes payload;
        payload.reserve(20U);
        datacube::append_be32(payload, options_.profile);
        datacube::append_be32(payload, checked_u32(options_.requested_mtu, "MTU"));
        datacube::append_be32(
            payload,
            checked_u32(options_.max_frame_bytes, "frame bound"));
        datacube::append_be32(
            payload,
            checked_u32(options_.max_queued_bytes, "queue bound"));
        datacube::append_be32(payload, options_.max_outstanding_requests);
        const auto response = transact(
            FrameType::hello_request,
            FrameType::hello_response,
            payload,
            std::min(options_.launch_deadline, std::chrono::steady_clock::now() + options_.startup_timeout));
        require_success(response, "hello");
        if (response.payload.size() != 20U) {
            protocol_failure("hello response capability size is invalid");
        }
        datacube::Reader reader(response.payload, "adapter capabilities");
        const auto profile = reader.read_be32("profile");
        const auto mtu = reader.read_be32("MTU");
        const auto max_frame = reader.read_be32("frame bound");
        const auto max_queue = reader.read_be32("queue bound");
        const auto max_outstanding = reader.read_be32("outstanding requests");
        reader.require_eof("adapter capabilities");
        if (profile != options_.profile ||
            mtu < kMinimumMtu || mtu > options_.requested_mtu ||
            max_frame < kFrameHeaderBytes + mtu ||
            max_frame > options_.max_frame_bytes ||
            max_queue < mtu || max_queue > options_.max_queued_bytes ||
            max_outstanding == 0U ||
            max_outstanding > options_.max_outstanding_requests) {
            protocol_failure("adapter capabilities exceed or violate requested bounds");
        }
        capabilities_ = ExternalPacketAdapterCapabilities{
            .profile = profile,
            .mtu = static_cast<std::size_t>(mtu),
            .max_frame_bytes = static_cast<std::size_t>(max_frame),
            .max_queued_bytes = static_cast<std::size_t>(max_queue),
            .max_outstanding_requests = max_outstanding,
        };
        mutate_snapshot(state_, [&](ExternalPacketAdapterSnapshot& snapshot) {
            snapshot.capabilities = capabilities_;
        });
    }

    [[nodiscard]] ProtocolFrame transact(
        const FrameType request_type,
        const FrameType response_type,
        const Bytes& payload,
        const Deadline deadline) {
        ensure_running();
        if (std::chrono::steady_clock::now() >= deadline) {
            app_fail("ADAPTER_TIMEOUT", "adapter request deadline expired");
        }
        if (next_sequence_ == 0U) {
            app_fail("ADAPTER_SEQUENCE_EXHAUSTED", "adapter request sequence exhausted");
        }
        const auto sequence = next_sequence_++;
        const ProtocolFrame request{
            .type = request_type,
            .sequence = sequence,
            .deadline_ms = deadline_budget_ms(deadline),
            .status = AdapterStatus::ok,
            .payload = payload,
        };
        send_protocol_frame(request, deadline);
        mutate_snapshot(state_, [](ExternalPacketAdapterSnapshot& snapshot) {
            ++snapshot.requests_sent;
        });
        state_->record(ExternalPacketAdapterEvent{
            .kind = ExternalPacketAdapterEventKind::request_sent,
            .sequence = sequence,
            .frame_type = static_cast<std::uint32_t>(request_type),
            .status = 0U,
            .payload_bytes = checked_u32(payload.size(), "event payload"),
            .process_id = static_cast<std::int64_t>(process_id_),
        });
        auto response = receive_protocol_frame(deadline);
        if (response.sequence != sequence || response.deadline_ms != 0U ||
            (response.type != response_type && response.type != FrameType::fault)) {
            protocol_failure("adapter response does not match the outstanding request");
        }
        mutate_snapshot(state_, [](ExternalPacketAdapterSnapshot& snapshot) {
            ++snapshot.responses_received;
        });
        state_->record(ExternalPacketAdapterEvent{
            .kind = ExternalPacketAdapterEventKind::response_received,
            .sequence = response.sequence,
            .frame_type = static_cast<std::uint32_t>(response.type),
            .status = static_cast<std::uint32_t>(response.status),
            .payload_bytes = checked_u32(response.payload.size(), "event payload"),
            .process_id = static_cast<std::int64_t>(process_id_),
        });
        if (response.type == FrameType::fault) {
            throw_adapter_status(response.status, response.payload);
        }
        return response;
    }

    [[nodiscard]] std::size_t active_frame_limit() const noexcept {
        return capabilities_.max_frame_bytes == 0U ?
            options_.max_frame_bytes : capabilities_.max_frame_bytes;
    }

    void send_protocol_frame(
        const ProtocolFrame& frame,
        const Deadline deadline) {
        const auto encoded = encode_frame(frame);
        if (encoded.size() > active_frame_limit()) {
            app_fail("ADAPTER_FRAME_TOO_LARGE", "adapter request exceeds frame bound");
        }
        while (true) {
            ensure_running();
            const ssize_t count = ::send(
                descriptor_.get(),
                encoded.data(),
                encoded.size(),
                MSG_DONTWAIT | MSG_NOSIGNAL);
            if (count >= 0) {
                if (static_cast<std::size_t>(count) != encoded.size()) {
                    protocol_failure("SOCK_SEQPACKET request was partially written");
                }
                return;
            }
            if (errno == EINTR) {
                continue;
            }
            if (errno != EAGAIN && errno != EWOULDBLOCK) {
                const int error = errno;
                if (error == EPIPE || error == ECONNRESET || error == ENOTCONN) {
                    runtime_reset("external packet adapter disconnected during send");
                }
                app_fail(
                    "ADAPTER_SEND_FAILED",
                    datacube::errno_detail("adapter send", error));
            }
            wait_descriptor(POLLOUT, deadline, "adapter send");
        }
    }

    [[nodiscard]] ProtocolFrame receive_protocol_frame(const Deadline deadline) {
        const auto frame_limit = active_frame_limit();
        Bytes encoded(frame_limit);
        while (true) {
            ensure_running();
            iovec vector{
                .iov_base = encoded.data(),
                .iov_len = encoded.size(),
            };
            msghdr message{};
            message.msg_iov = &vector;
            message.msg_iovlen = 1U;
            const ssize_t count = ::recvmsg(
                descriptor_.get(),
                &message,
                MSG_DONTWAIT | MSG_TRUNC);
            if (count > 0) {
                if ((message.msg_flags & MSG_TRUNC) != 0 ||
                    static_cast<std::size_t>(count) > frame_limit) {
                    protocol_failure("adapter response exceeded the frame bound");
                }
                encoded.resize(static_cast<std::size_t>(count));
                try {
                    return decode_frame(encoded, frame_limit);
                } catch (const AppError&) {
                    record_protocol_failure();
                    throw;
                }
            }
            if (count == 0) {
                runtime_reset("external packet adapter closed its protocol socket");
            }
            if (errno == EINTR) {
                continue;
            }
            if (errno != EAGAIN && errno != EWOULDBLOCK) {
                const int error = errno;
                if (error == ECONNRESET || error == ENOTCONN) {
                    runtime_reset("external packet adapter disconnected during receive");
                }
                app_fail(
                    "ADAPTER_RECEIVE_FAILED",
                    datacube::errno_detail("adapter receive", error));
            }
            wait_descriptor(POLLIN, deadline, "adapter receive");
        }
    }

    void wait_descriptor(
        const short events,
        const Deadline deadline,
        const std::string_view operation) {
        while (true) {
            ensure_running();
            const int timeout = poll_timeout_ms(deadline);
            if (timeout == 0) {
                app_fail("ADAPTER_TIMEOUT", std::string(operation));
            }
            pollfd item{
                .fd = descriptor_.get(),
                .events = static_cast<short>(events | POLLERR | POLLHUP),
                .revents = 0,
            };
            const int result = ::poll(&item, 1U, timeout);
            if (result < 0) {
                if (errno == EINTR) {
                    continue;
                }
                app_fail(
                    "ADAPTER_POLL_FAILED",
                    datacube::errno_detail(operation, errno));
            }
            if (result == 0) {
                app_fail("ADAPTER_TIMEOUT", std::string(operation));
            }
            ensure_running();
            if ((item.revents & POLLNVAL) != 0) {
                app_fail("ADAPTER_SOCKET_INVALID", std::string(operation));
            }
            if ((item.revents & events) != 0) {
                return;
            }
            if ((item.revents & (POLLERR | POLLHUP)) != 0) {
                runtime_reset("external packet adapter disconnected");
            }
        }
    }

    void record_child_exit_once(
        const pid_t process,
        const std::optional<int> status) {
        if (child_exit_recorded_ || process <= 0) {
            return;
        }
        child_exit_recorded_ = true;
        mutate_snapshot(state_, [](ExternalPacketAdapterSnapshot& snapshot) {
            snapshot.running = false;
            snapshot.process_id = 0;
            ++snapshot.child_exits;
        });
        state_->record(ExternalPacketAdapterEvent{
            .kind = ExternalPacketAdapterEventKind::child_exit,
            .status = status.has_value() ?
                static_cast<std::uint32_t>(*status) : kUnknownChildStatus,
            .process_id = static_cast<std::int64_t>(process),
        });
    }

    [[noreturn]] void runtime_reset(const std::string_view detail) {
        const pid_t process = process_id_;
        std::optional<int> status;
        if (process > 0) {
            int observed_status = 0;
            pid_t result = -1;
            do {
                result = ::waitpid(process, &observed_status, WNOHANG);
            } while (result < 0 && errno == EINTR);
            if (result == process) {
                status = observed_status;
                process_id_ = -1;
            } else if (result < 0 && errno == ECHILD) {
                process_id_ = -1;
            }
        }
        descriptor_.reset();
        record_child_exit_once(process, status);
        std::string message(detail);
        if (status.has_value()) {
            message += " (" + child_status_text(*status) + ")";
        }
        app_fail("PEER_RESET", message);
    }

    void ensure_running() {
        if (process_id_ <= 0 || descriptor_.get() < 0) {
            app_fail("PEER_RESET", "external packet adapter is not running");
        }
        int status = 0;
        pid_t result = -1;
        do {
            result = ::waitpid(process_id_, &status, WNOHANG);
        } while (result < 0 && errno == EINTR);
        if (result == 0) {
            return;
        }
        if (result == process_id_) {
            const auto exited = process_id_;
            process_id_ = -1;
            descriptor_.reset();
            record_child_exit_once(exited, status);
            app_fail(
                "PEER_RESET",
                "external packet adapter exited (" + child_status_text(status) + ")");
        }
        if (result < 0) {
            const auto unreapable = process_id_;
            process_id_ = -1;
            descriptor_.reset();
            record_child_exit_once(unreapable, std::nullopt);
            app_fail("PEER_RESET", "external packet adapter could not be reaped");
        }
    }

    void require_success(
        const ProtocolFrame& response,
        const std::string_view operation) {
        if (response.status == AdapterStatus::ok) {
            return;
        }
        if (response.status == AdapterStatus::busy &&
            operation == "transmit") {
            return;
        }
        throw_adapter_status(response.status, response.payload);
    }

    [[noreturn]] void protocol_failure(const std::string_view detail) {
        record_protocol_failure();
        app_fail("ADAPTER_PROTOCOL_VIOLATION", detail);
    }

    void record_protocol_failure() {
        mutate_snapshot(state_, [](ExternalPacketAdapterSnapshot& snapshot) {
            ++snapshot.protocol_failures;
        });
        state_->record(ExternalPacketAdapterEvent{
            .kind = ExternalPacketAdapterEventKind::protocol_failure,
            .process_id = static_cast<std::int64_t>(process_id_),
        });
    }

    void shutdown_noexcept() noexcept {
        std::lock_guard lock(io_mutex_);
        if (process_id_ <= 0) {
            descriptor_.reset();
            return;
        }
        try {
            const auto response = transact(
                FrameType::shutdown_request,
                FrameType::shutdown_response,
                {},
                std::chrono::steady_clock::now() + options_.shutdown_timeout);
            require_success(response, "shutdown");
            if (!response.payload.empty()) {
                protocol_failure("shutdown response carried an unexpected payload");
            }
            state_->record(ExternalPacketAdapterEvent{
                .kind = ExternalPacketAdapterEventKind::graceful_shutdown,
                .process_id = static_cast<std::int64_t>(process_id_),
            });
        } catch (...) {
        }
        terminate_current_noexcept(false);
    }

    void terminate_current_noexcept(const bool immediate) noexcept {
        descriptor_.reset();
        if (process_id_ <= 0) {
            mutate_snapshot(state_, [](ExternalPacketAdapterSnapshot& snapshot) {
                snapshot.running = false;
                snapshot.process_id = 0;
            });
            return;
        }
        const pid_t process = process_id_;
        process_id_ = -1;
        int status = 0;
        pid_t result = ::waitpid(process, &status, WNOHANG);
        if (result == 0 && !immediate) {
            const auto deadline =
                std::chrono::steady_clock::now() + options_.shutdown_timeout;
            while (std::chrono::steady_clock::now() < deadline) {
                std::this_thread::sleep_for(std::chrono::milliseconds(5));
                result = ::waitpid(process, &status, WNOHANG);
                if (result == process || result < 0) {
                    break;
                }
            }
        }
        if (result == 0) {
            static_cast<void>(::kill(process, immediate ? SIGKILL : SIGTERM));
            const auto term_deadline =
                std::chrono::steady_clock::now() + std::chrono::milliseconds(100);
            while (std::chrono::steady_clock::now() < term_deadline) {
                std::this_thread::sleep_for(std::chrono::milliseconds(5));
                result = ::waitpid(process, &status, WNOHANG);
                if (result == process || result < 0) {
                    break;
                }
            }
            if (result == 0) {
                static_cast<void>(::kill(process, SIGKILL));
                do {
                    result = ::waitpid(process, &status, 0);
                } while (result < 0 && errno == EINTR);
            }
            state_->record(ExternalPacketAdapterEvent{
                .kind = ExternalPacketAdapterEventKind::forced_termination,
                .process_id = static_cast<std::int64_t>(process),
            });
        }
        mutate_snapshot(state_, [](ExternalPacketAdapterSnapshot& snapshot) {
            snapshot.running = false;
            snapshot.process_id = 0;
        });
    }

    Deadline operation_deadline_{Deadline::max()};
    ExternalPacketAdapterOptions options_;
    std::shared_ptr<SupervisedExternalPacketAdapterControl::State> state_;
    datacube::Fd descriptor_{};
    pid_t process_id_{-1};
    int maximum_descriptor_{1'024};
    ExternalPacketAdapterCapabilities capabilities_{};
    std::uint64_t next_sequence_{1U};
    bool child_exit_recorded_{false};
    std::mutex io_mutex_{};
};

}  // namespace

SupervisedExternalPacketAdapterControl::SupervisedExternalPacketAdapterControl(
    std::shared_ptr<State> state) noexcept
    : state_(std::move(state)) {}

SupervisedExternalPacketAdapterControl::~SupervisedExternalPacketAdapterControl() = default;

ExternalPacketAdapterSnapshot
SupervisedExternalPacketAdapterControl::snapshot() const {
    std::lock_guard lock(state_->mutex);
    return state_->snapshot;
}

ExternalPacketAdapterOptions external_packet_adapter_options_from_profile(
    const OperatorPinnedAdapterProfile& profile) {
    try {
        validate_operator_pinned_adapter_profile(profile);
        auto image = std::make_shared<VerifiedAdapterExecutable>(
            open_verified_adapter_executable(profile));
        ExternalPacketAdapterOptions options;
        options.pinned_profile = profile;
        options.pinned_profile_sha256 =
            operator_pinned_adapter_profile_sha256(profile);
        options.verified_executable = std::move(image);
        options.executable = profile.executable;
        options.arguments = profile.arguments;
        options.requested_mtu = profile.mtu;
        options.profile = profile.capability_profile;
        options.max_frame_bytes = profile.max_frame_bytes;
        options.max_queued_bytes = profile.max_queued_bytes;
        options.max_outstanding_requests = profile.max_outstanding_requests;
        options.max_evidence_events = profile.max_evidence_events;
        options.max_launch_attempts = profile.max_launch_attempts;
        options.startup_timeout = profile.startup_timeout;
        options.request_timeout = profile.request_timeout;
        options.shutdown_timeout = profile.shutdown_timeout;
        options.initial_restart_backoff = profile.initial_restart_backoff;
        options.maximum_restart_backoff = profile.maximum_restart_backoff;
        return options;
    } catch (const AdapterProfileError& error) {
        app_fail(error.code(), error.what());
    }
}

SupervisedExternalPacketAdapter make_supervised_external_packet_adapter(
    ExternalPacketAdapterOptions options) {
    auto state = std::make_shared<SupervisedExternalPacketAdapterControl::State>(
        options.max_evidence_events);
    if (options.pinned_profile.has_value()) {
        state->snapshot.pinned_profile_id =
            options.pinned_profile->profile_id;
        state->snapshot.pinned_profile_generation =
            options.pinned_profile->generation;
        state->snapshot.pinned_profile_sha256 =
            options.pinned_profile_sha256;
        state->snapshot.executable_sha256 =
            options.pinned_profile->executable_sha256;
    }
    auto control = std::shared_ptr<SupervisedExternalPacketAdapterControl>(
        new SupervisedExternalPacketAdapterControl(state));
    auto port = std::make_unique<SupervisedAdapterPacketPort>(
        std::move(options), std::move(state));
    return SupervisedExternalPacketAdapter{
        .port = std::move(port),
        .control = std::move(control),
    };
}

}  // namespace natrav_overlay
