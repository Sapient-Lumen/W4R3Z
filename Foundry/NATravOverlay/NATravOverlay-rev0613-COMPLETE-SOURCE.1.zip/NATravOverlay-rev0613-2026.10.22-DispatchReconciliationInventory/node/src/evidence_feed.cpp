#include "evidence_feed.hpp"
#include "journal.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <memory>
#include <queue>
#include <openssl/core_names.h>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/params.h>
#include <openssl/rand.h>

namespace natrav_overlay {
namespace {
constexpr std::size_t kTokenBytes = 152U;
constexpr std::uint64_t kLifetimeMs = 300'000U;
constexpr std::size_t kResponseReserve = 3'072U;

void checked(const int result) {
    if (result != 1) { app_fail("EVIDENCE_FEED_CRYPTO_FAILED", "feed token cryptography failed"); }
}
std::uint64_t monotonic_ms() {
    const auto value = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
    if (value < 0) { app_fail("EVIDENCE_FEED_CLOCK_FAILED", "negative monotonic clock"); }
    return static_cast<std::uint64_t>(value);
}
struct FeedSecret final {
    std::array<unsigned char, 32U> bytes{};
    FeedSecret() { checked(RAND_priv_bytes(bytes.data(), static_cast<int>(bytes.size()))); }
    ~FeedSecret() { OPENSSL_cleanse(bytes.data(), bytes.size()); }
    FeedSecret(const FeedSecret&) = delete;
    FeedSecret& operator=(const FeedSecret&) = delete;
};
datacube::Digest32 token_mac(const datacube::OctetView bytes) {
    // Separate process-local secret, not a state, TLS, backup, or query key.
    static const FeedSecret secret;
    std::unique_ptr<EVP_MAC, decltype(&EVP_MAC_free)> algorithm(
        EVP_MAC_fetch(nullptr, "HMAC", nullptr), EVP_MAC_free);
    if (!algorithm) { app_fail("EVIDENCE_FEED_CRYPTO_FAILED", "HMAC unavailable"); }
    std::unique_ptr<EVP_MAC_CTX, decltype(&EVP_MAC_CTX_free)> ctx(
        EVP_MAC_CTX_new(algorithm.get()), EVP_MAC_CTX_free);
    if (!ctx) { app_fail("EVIDENCE_FEED_CRYPTO_FAILED", "HMAC context unavailable"); }
    char digest[] = "SHA256";
    OSSL_PARAM params[] = {OSSL_PARAM_construct_utf8_string(OSSL_MAC_PARAM_DIGEST, digest, 0U),
        OSSL_PARAM_construct_end()};
    checked(EVP_MAC_init(ctx.get(), secret.bytes.data(), secret.bytes.size(), params));
    constexpr std::string_view domain = "NATRAV_OVERLAY_EVIDENCE_FEED_TOKEN_V1";
    checked(EVP_MAC_update(ctx.get(), reinterpret_cast<const unsigned char*>(domain.data()), domain.size()));
    checked(EVP_MAC_update(ctx.get(), bytes.data(), bytes.size()));
    datacube::Digest32 tag{};
    std::size_t length = 0U;
    checked(EVP_MAC_final(ctx.get(), tag.octets.data(), &length, tag.octets.size()));
    if (length != tag.octets.size()) { app_fail("EVIDENCE_FEED_CRYPTO_FAILED", "wrong HMAC length"); }
    return tag;
}
void text16(datacube::Octets& out, const std::string_view value) {
    datacube::append_be16(out, static_cast<std::uint16_t>(value.size()));
    datacube::append_text(out, value);
}
std::string text16(datacube::Reader& reader, const std::size_t maximum) {
    const auto size = reader.read_be16("feed text length");
    if (size > maximum) { app_fail("EVIDENCE_FEED_INVALID", "feed string exceeds bound"); }
    return datacube::octets_text(reader.read_exact(size, "feed text"), "feed text", true);
}
datacube::Digest32 digest32(datacube::Reader& reader) {
    datacube::Digest32 value{};
    const auto bytes = reader.read_exact(32U, "feed digest");
    std::copy(bytes.begin(), bytes.end(), value.octets.begin());
    return value;
}
// Initialization mode is not part of the continuing selection. It may only be
// specified without a token; subsequent polls always use the token's position.
datacube::Octets selection_spec(const EvidenceFeed& feed) {
    datacube::Octets out;
    datacube::append_text(out, "NEF1");
    datacube::append_u8(out, feed.include_payload ? 1U : 0U);
    text16(out, feed.issuer); text16(out, feed.scope);
    datacube::append_be32(out, feed.maximum_records);
    datacube::append_be32(out, feed.maximum_response_bytes);
    datacube::append_be32(out, feed.payload_length);
    return out;
}
struct Position final { std::uint64_t after{0U}; std::uint64_t expires{0U}; };
Position open_token(const EvidenceFeed& feed, const EvidenceQueryContext& context,
    const datacube::Digest32& specification) {
    datacube::Octets bytes;
    bytes.reserve(kTokenBytes);
    const auto nibble = [](const char ch) -> std::uint8_t {
        if (ch >= '0' && ch <= '9') { return static_cast<std::uint8_t>(ch - '0'); }
        if (ch >= 'a' && ch <= 'f') { return static_cast<std::uint8_t>(ch - 'a' + 10); }
        app_fail("EVIDENCE_FEED_CURSOR_INVALID", "token must be lowercase hexadecimal");
    };
    for (std::size_t i = 0U; i < feed.cursor.size(); i += 2U) {
        bytes.push_back(static_cast<std::uint8_t>(nibble(feed.cursor[i]) * 16U + nibble(feed.cursor[i + 1U])));
    }
    const auto body_size = kTokenBytes - 32U;
    const auto expected = token_mac(datacube::OctetView(bytes).first(body_size));
    if (CRYPTO_memcmp(expected.octets.data(), bytes.data() + body_size, 32U) != 0) {
        app_fail("EVIDENCE_FEED_CURSOR_INVALID", "token authentication failed or issuing process restarted");
    }
    datacube::Reader reader(datacube::OctetView(bytes).first(body_size), "feed token");
    if (datacube::octets_text(reader.read_exact(4U, "feed token magic"), "feed token magic", true) != "NET1") {
        app_fail("EVIDENCE_FEED_CURSOR_INVALID", "unsupported token version");
    }
    const auto uid = reader.read_be32("feed token UID");
    const auto spec = digest32(reader);
    const auto config = digest32(reader);
    const auto access = digest32(reader);
    const auto after = reader.read_be64("feed position");
    const auto expires = reader.read_be64("feed expiry");
    reader.require_eof("feed token");
    if (uid != context.uid || spec != specification || config != context.configuration_digest ||
        access != context.read_access.digest) {
        app_fail("EVIDENCE_FEED_CONTEXT_MISMATCH", "principal, selection, or accepted policy changed; explicitly restart feed");
    }
    if (monotonic_ms() >= expires) {
        app_fail("EVIDENCE_FEED_CURSOR_EXPIRED", "token expired; explicitly restart feed");
    }
    return Position{.after = after, .expires = expires};
}
std::string seal_token(const EvidenceQueryContext& context, const datacube::Digest32& spec,
    const Position& position) {
    datacube::Octets bytes;
    bytes.reserve(kTokenBytes);
    datacube::append_text(bytes, "NET1");
    datacube::append_be32(bytes, context.uid);
    datacube::append_octets(bytes, spec.octets);
    datacube::append_octets(bytes, context.configuration_digest.octets);
    datacube::append_octets(bytes, context.read_access.digest.octets);
    datacube::append_be64(bytes, position.after);
    datacube::append_be64(bytes, position.expires);
    const auto tag = token_mac(bytes);
    datacube::append_octets(bytes, tag.octets);
    return hex_bytes(bytes);
}
std::string event_metadata(const StoredInbound& entry, const std::uint64_t sequence) {
    const auto& record = entry.record;
    std::string out = "{\"sequence\":" + std::to_string(sequence) +
        ",\"event\":" + json_string(record.corrects ? "CORRECTION_ADMITTED" : "EVIDENCE_ADMITTED") +
        ",\"operation_id\":" + json_string(operation_id_text(record.operation_id)) +
        ",\"issuer\":" + json_string(record.issuer) + ",\"recipient\":" + json_string(record.recipient) +
        ",\"scope\":" + json_string(record.scope) +
        ",\"record_digest\":" + json_string(datacube::hex_lower(entry.record_digest)) +
        ",\"payload_size\":" + std::to_string(record.payload.size()) +
        ",\"corrects\":" + (record.corrects ? json_string(operation_id_text(*record.corrects)) : "null") +
        ",\"authorization\":";
    // Deliberately omit mutable superseded_by/current status. Later corrections
    // are new feed events, not retroactive mutations of previously read events.
    if (entry.authorization) {
        const auto& auth = *entry.authorization;
        out += "{\"peer_node\":" + json_string(auth.peer_node) +
            ",\"peer_generation\":" + json_string(auth.peer_generation) +
            ",\"policy_digest\":" + json_string(datacube::hex_lower(auth.policy_digest)) +
            ",\"rule_digest\":" + (auth.rule_digest ? json_string(datacube::hex_lower(*auth.rule_digest)) : "null") +
            ",\"decided_unix_ms\":" + std::to_string(auth.decided_unix_ms) + "}";
    } else { out += "null"; }
    if (entry.local_authorship) { out += ",\"local_authorship\":" + local_authorship_json(*entry.local_authorship); }
    if (entry.subscribed_source) { out += ",\"subscribed_source\":" + subscribed_source_json(*entry.subscribed_source); }
    return out + "}";
}
} // namespace

void validate_evidence_feed(const EvidenceFeed& feed) {
    if ((!feed.issuer.empty() && !valid_node_id(feed.issuer)) ||
        (!feed.scope.empty() && !valid_scope(feed.scope)) ||
        feed.maximum_records == 0U || feed.maximum_records > 128U ||
        feed.maximum_response_bytes < 4'096U || feed.maximum_response_bytes > 60'000U ||
        feed.payload_length > 16'384U || (feed.include_payload && feed.payload_length == 0U) ||
        (!feed.include_payload && feed.payload_length != 0U) ||
        (feed.from_now && !feed.cursor.empty())) {
        app_fail("EVIDENCE_FEED_INVALID", "invalid feed selection, start mode, or resource bound");
    }
    if (!feed.cursor.empty() && feed.cursor.size() != kTokenBytes * 2U) {
        app_fail("EVIDENCE_FEED_CURSOR_INVALID", "invalid token length");
    }
}
datacube::Octets encode_evidence_feed(const EvidenceFeed& feed) {
    validate_evidence_feed(feed);
    auto out = selection_spec(feed);
    datacube::append_u8(out, feed.from_now ? 1U : 0U);
    text16(out, feed.cursor);
    return out;
}
EvidenceFeed decode_evidence_feed(const datacube::OctetView bytes) {
    datacube::Reader reader(bytes, "evidence feed");
    if (datacube::octets_text(reader.read_exact(4U, "feed magic"), "feed magic", true) != "NEF1") {
        app_fail("EVIDENCE_FEED_INVALID", "unknown feed version");
    }
    const auto payload = reader.read_u8("feed payload mode");
    if (payload > 1U) { app_fail("EVIDENCE_FEED_INVALID", "unknown payload mode"); }
    EvidenceFeed feed;
    feed.include_payload = payload != 0U;
    feed.issuer = text16(reader, 64U); feed.scope = text16(reader, 128U);
    feed.maximum_records = reader.read_be32("feed row limit");
    feed.maximum_response_bytes = reader.read_be32("feed response limit");
    feed.payload_length = reader.read_be32("feed payload length");
    const auto start = reader.read_u8("feed start mode");
    if (start > 1U) { app_fail("EVIDENCE_FEED_INVALID", "unknown start mode"); }
    feed.from_now = start != 0U;
    feed.cursor = text16(reader, kTokenBytes * 2U);
    reader.require_eof("evidence feed");
    validate_evidence_feed(feed);
    return feed;
}

std::string NodeState::poll_evidence(const EvidenceFeed& feed, const EvidenceQueryContext& context) const {
    validate_evidence_feed(feed);
    if (!context.read_access.metadata_allowed || (feed.include_payload && !context.read_access.payload_allowed)) {
        app_fail("LOCAL_CONTROL_CLASS_DENIED", "feed read class is not authorized");
    }
    // This new command starts at the exact-domain boundary. Earlier node-wide
    // configurations keep evidence-query unchanged, not implicit feed access.
    if (!context.read_access.scoped) {
        app_fail("EVIDENCE_FEED_SCOPED_POLICY_REQUIRED", "adopt explicit V10 evidence domains before using this feed");
    }
    auto material = selection_spec(feed);
    text16(material, node_id_);
    const auto spec = datacube::sha256(material);
    std::optional<Position> token;
    if (!feed.cursor.empty()) { token = open_token(feed, context, spec); }
    std::unique_lock<std::mutex> lock(mutex_);
    const auto ready = [&]() {
        if (poisoned_) { app_fail("STATE_UNAVAILABLE", "state writer requires restart"); }
        if (std::chrono::steady_clock::now() >= context.deadline) {
            app_fail("EVIDENCE_FEED_DEADLINE", "feed construction exceeded control deadline; no position advanced");
        }
    };
    ready();
    const auto total = evidence_feed_total_locked(feed, context);
    const auto after = token ? token->after : (feed.from_now ? total : 0U);
    if (after > total) {
        app_fail("EVIDENCE_FEED_RESET_REQUIRED", "selected retained history no longer contains the continuation position");
    }
    const auto page = evidence_feed_slice_locked(feed, context, after, total);
    const auto last = page.next;
    const auto count = page.count;
    const auto visited = page.visited;
    const auto& rows = page.rows;
    // Renew after a successful poll, including an empty one. Old tokens remain
    // replayable until their own expiry; no durable consumer ACK is invented.
    const auto next = seal_token(context, spec, Position{.after = last, .expires = monotonic_ms() + kLifetimeMs});
    auto out = std::string("{\"format\":\"NATRAV_OVERLAY_EVIDENCE_FEED_V1\",\"ok\":true,\"node\":") + json_string(node_id_) +
        ",\"issuer_filter\":" + (feed.issuer.empty() ? "null" : json_string(feed.issuer)) +
        ",\"scope_filter\":" + (feed.scope.empty() ? "null" : json_string(feed.scope)) +
        ",\"configuration_generation\":" + json_string(context.configuration_generation) +
        ",\"configuration_digest\":" + json_string(datacube::hex_lower(context.configuration_digest)) +
        ",\"read_policy_digest\":" + json_string(datacube::hex_lower(context.read_access.digest)) +
        ",\"feed_digest\":" + json_string(datacube::hex_lower(spec)) +
        ",\"sequence_semantics\":\"AUTHORIZED_ADMISSION_ORDINAL\",\"event_semantics\":\"IMMUTABLE_ADMISSION\"" +
        ",\"after_sequence\":" + std::to_string(after) + ",\"next_sequence\":" + std::to_string(last) +
        ",\"returned_records\":" + std::to_string(count) + ",\"remaining_records\":" + std::to_string(total - last) +
        ",\"caught_up\":" + (last == total ? "true" : "false") +
        ",\"payload_included\":" + (feed.include_payload ? "true" : "false") +
        ",\"cursor_scope\":\"PROCESS_LOCAL_RENEWABLE_300_SECONDS\",\"next_cursor\":" + json_string(next) +
        ",\"records\":[" + rows + "]" +
        ",\"feed_work\":{\"index_records_visited\":" + std::to_string(visited) +
        ",\"selection_records_hashed\":0,\"retained_server_cursors\":0}}";
    if (out.size() + 512U > feed.maximum_response_bytes) {
        app_fail("EVIDENCE_FEED_RESPONSE_LIMIT", "encoded feed exceeded its response bound");
    }
    return out;
}

std::uint64_t NodeState::evidence_feed_total_locked(const EvidenceFeed& feed,
    const EvidenceQueryContext& context) const {
    std::vector<const EvidenceOrderedIndex*> domains;
    domains.reserve(context.read_access.grants.size());
    std::uint64_t total = 0U;
    for (const auto& grant : context.read_access.grants) {
        if ((feed.include_payload && !grant.payload) ||
            (!feed.issuer.empty() && feed.issuer != grant.issuer) ||
            (!feed.scope.empty() && feed.scope != grant.scope)) { continue; }
        const auto found = inbound_domain_index_.find({grant.issuer, grant.scope});
        if (found != inbound_domain_index_.end()) {
            domains.push_back(&found->second);
            total += static_cast<std::uint64_t>(found->second.size(true));
        }
    }
    return total;
}
EvidenceFeedSlice NodeState::evidence_feed_slice_locked(const EvidenceFeed& feed,
    const EvidenceQueryContext& context, const std::uint64_t after,
    const std::uint64_t through) const {
    const auto ready = [&]() {
        if (poisoned_) { app_fail("STATE_UNAVAILABLE", "state writer requires restart"); }
        if (std::chrono::steady_clock::now() >= context.deadline) {
            app_fail("EVIDENCE_FEED_DEADLINE", "bounded evidence selection exceeded deadline");
        }
    };
    ready();
    std::vector<const EvidenceOrderedIndex*> domains;
    domains.reserve(context.read_access.grants.size());
    std::uint64_t total = 0U;
    for (const auto& grant : context.read_access.grants) {
        if ((feed.include_payload && !grant.payload) ||
            (!feed.issuer.empty() && feed.issuer != grant.issuer) ||
            (!feed.scope.empty() && feed.scope != grant.scope)) { continue; }
        const auto found = inbound_domain_index_.find({grant.issuer, grant.scope});
        if (found != inbound_domain_index_.end()) {
            domains.push_back(&found->second);
            total += static_cast<std::uint64_t>(found->second.size(true));
        }
    }

    if (after > through || through > total) {
        app_fail("CONSUMER_HISTORY_MISMATCH", "retained selection does not contain the issued boundary");
    }
    // Seek in the union by authorized rank, not by walking earlier records.
    // The global index used internally is never serialized, hashed, or counted
    // in reported work. Empty polling does not seek or read any record.
    std::size_t offset = 0U;
    if (after != 0U && after != total) {
        if (domains.size() == 1U) {
            offset = domains.front()->at(static_cast<std::size_t>(after - 1U), true) + 1U;
        } else {
            std::size_t low = 0U, high = inbound_.size();
            while (low < high) {
                const auto middle = low + (high - low) / 2U;
                std::uint64_t rank = 0U;
                for (const auto* domain : domains) { rank += domain->before(middle + 1U, true); }
                if (rank < after) { low = middle + 1U; } else { high = middle; }
            }
            offset = low + 1U;
        }
    }
    struct Head final { std::size_t index; std::size_t domain; std::size_t ordinal; };
    const auto greater = [](const Head& a, const Head& b) { return a.index > b.index; };
    std::priority_queue<Head, std::vector<Head>, decltype(greater)> heads(greater);
    if (after != total) {
        for (std::size_t i = 0U; i < domains.size(); ++i) {
            const auto ordinal = domains[i]->before(offset, true);
            if (ordinal < domains[i]->size(true)) {
                heads.push(Head{.index = domains[i]->at(ordinal, true), .domain = i, .ordinal = ordinal});
            }
        }
    }
    std::size_t count = 0U, visited = 0U;
    auto last = after;
    std::string rows;
    const auto budget = static_cast<std::size_t>(feed.maximum_response_bytes) - kResponseReserve;
    while (!heads.empty() && count < feed.maximum_records && last < through) {
        ready();
        auto head = heads.top(); heads.pop(); ++visited;
        const auto& entry = inbound_[head.index];
        if (!evidence_read_allows(context.read_access, entry.record.issuer, entry.record.scope, feed.include_payload)) {
            app_fail("EVIDENCE_FEED_INDEX_INVALID", "selected index violated read authority");
        }
        auto row = event_metadata(entry, last + 1U);
        const auto payload_count = feed.include_payload ? std::min<std::size_t>(feed.payload_length, entry.record.payload.size()) : 0U;
        const auto estimate = row.size() + (feed.include_payload ? payload_count * 2U + 160U : 0U) + 1U;
        if (estimate > budget - rows.size()) {
            if (count == 0U) {
                app_fail("EVIDENCE_FEED_PAGE_TOO_SMALL", "row does not fit; explicitly restart with larger max-bytes or smaller payload-length");
            }
            break;
        }
        if (feed.include_payload) {
            row.pop_back();
            row += ",\"payload_offset\":0,\"payload_returned_bytes\":" + std::to_string(payload_count) +
                ",\"payload_more\":" + (payload_count < entry.record.payload.size() ? "true" : "false") +
                ",\"payload_hex\":" + json_string(hex_bytes(datacube::OctetView(entry.record.payload).first(payload_count))) + "}";
        }
        if (count != 0U) { rows += ','; }
        rows += row; ++count; ++last;
        ++head.ordinal;
        if (head.ordinal < domains[head.domain]->size(true)) {
            head.index = domains[head.domain]->at(head.ordinal, true); heads.push(head);
        }
    }
    ready();
    return EvidenceFeedSlice{.rows=std::move(rows), .next=last,
        .total=total, .count=count, .visited=visited};
}
} // namespace natrav_overlay
