#pragma once
#include "common.hpp"
#include <chrono>
#include <cstdint>
#include <optional>
#include <string>

namespace natrav_overlay {
// Immutable-prefix positions, not capabilities or mutation preconditions.
struct ConfigurationHistoryRequest final {
    std::string section{"events"};
    std::optional<std::uint64_t> ordinal;
    std::optional<std::uint64_t> configuration_event;
    std::uint64_t offset{0U};
    std::uint32_t limit{16U};
    std::uint32_t maximum_bytes{60'000U};
    std::optional<std::uint64_t> through;
    std::optional<datacube::Digest32> prefix;
};
struct ConfigurationHistoryCommitment final {
    datacube::Digest32 item;
    datacube::Digest32 prefix;
    std::uint64_t active_event{0U};
};
void validate_configuration_history(const ConfigurationHistoryRequest& request);
[[nodiscard]] datacube::Octets encode_configuration_history(const ConfigurationHistoryRequest& request);
[[nodiscard]] ConfigurationHistoryRequest decode_configuration_history(datacube::OctetView bytes);
} // namespace natrav_overlay
