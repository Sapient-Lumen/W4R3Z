#pragma once

#include <cstdint>
#include <string>

namespace natrav_overlay {
// Exact call-site counters, scoped to one calling thread. They exclude TLS,
// unrelated threads, general journal encoding and allocations not named here.
// There is no persisted telemetry or cache-authority state.
struct SourceValidationWork final {
    std::uint64_t automatic_eligibility_candidates{0U};
    std::uint64_t automatic_eligibility_source_reconstructions{0U};
    std::uint64_t automatic_eligibility_envelope_bytes{0U};
    std::uint64_t automatic_eligibility_reuses{0U};
    std::uint64_t automatic_eligibility_binding_checks{0U};
    std::uint64_t preparations_created{0U};
    std::uint64_t preparation_source_reconstructions{0U};
    std::uint64_t preparation_envelope_bytes{0U};
    std::uint64_t preflight_preparation_uses{0U};
    std::uint64_t application_preparation_uses{0U};
    std::uint64_t preparation_source_binding_checks{0U};
    std::uint64_t preflight_source_reconstructions{0U};
    std::uint64_t application_source_reconstructions{0U};
    std::uint64_t replay_source_reconstructions{0U};
    std::uint64_t full_validations{0U};
    std::uint64_t delta_validations{0U};
    std::uint64_t reference_validations{0U};
    std::uint64_t configuration_parses{0U};
    std::uint64_t configuration_memo_hits{0U};
    std::uint64_t configuration_bytes{0U};
    std::uint64_t delivery_validations{0U};
    std::uint64_t receipt_checks{0U};
    std::uint64_t source_records_reconstructed{0U};
    std::uint64_t source_payload_bytes_encoded{0U};
    std::uint64_t envelope_bytes_constructed{0U};
    std::uint64_t mapping_entries_visited{0U};
    std::uint64_t mapping_digest_entries_hashed{0U};
    std::uint64_t mapping_index_lookups{0U};
    std::uint64_t mapping_index_hits{0U};
    std::uint64_t mapping_index_full_rebuilds{0U};
    std::uint64_t mapping_index_entries_rebuilt{0U};
    std::uint64_t response_index_entries{0U};
    std::uint64_t response_index_fixed_bytes{0U};
    std::uint64_t state_encodes{0U};
    std::uint64_t state_bytes_encoded{0U};
    std::uint64_t state_decodes{0U};
    std::uint64_t state_bytes_decoded{0U};
    std::uint64_t copied_delivery_entries{0U};
    std::uint64_t compared_delivery_entries{0U};
    std::uint64_t transaction_preparations_created{0U};
    std::uint64_t preflight_transaction_uses{0U};
    std::uint64_t application_transaction_uses{0U};
    std::uint64_t transaction_byte_binding_checks{0U};
    std::uint64_t transaction_binding_bytes_compared{0U};
    std::uint64_t transaction_binding_bytes_hashed{0U};
    std::uint64_t preflight_progress_decodes{0U};
    std::uint64_t application_progress_decodes{0U};
    std::uint64_t replay_progress_decodes{0U};
    std::uint64_t progress_outgoing_owned_copies{0U};
    std::uint64_t progress_outgoing_bytes_copied{0U};
    std::uint64_t progress_outgoing_slices{0U};
    std::uint64_t progress_outgoing_slice_bytes{0U};
    std::uint64_t progress_record_payload_bytes_decoded{0U};
    std::uint64_t progress_transaction_encodes{0U};
    std::uint64_t progress_transaction_bytes_encoded{0U};
    std::uint64_t progress_transaction_decodes{0U};
    std::uint64_t progress_transaction_bytes_decoded{0U};
    std::uint64_t outbound_prepared_slices{0U};
    std::uint64_t outbound_slice_header_bytes_read{0U};
    std::uint64_t outbound_composite_frames{0U};
    std::uint64_t outbound_record_decodes{0U};
    std::uint64_t outbound_record_bytes_decoded{0U};
    std::uint64_t outbound_record_payload_bytes_decoded{0U};
    std::uint64_t outbound_record_reuses{0U};
    std::uint64_t outbound_record_validations{0U};
    std::uint64_t outbound_binding_checks{0U};
    std::uint64_t outbound_binding_bytes_compared{0U};
    std::uint64_t outbound_store_payload_bytes_copied{0U};
    std::uint64_t outbound_store_ownership_transfers{0U};
    std::uint64_t outbound_store_payload_bytes_transferred{0U};
    std::uint64_t outbound_store_publication_checks{0U};
    std::uint64_t outbound_store_digest_calls{0U};
    std::uint64_t outbound_store_digest_payload_bytes{0U};
    std::uint64_t outbound_policy_decodes{0U};
    std::uint64_t outbound_policy_bytes_decoded{0U};
    std::uint64_t source_composite_return_payload_bytes_copied{0U};
    std::uint64_t source_composite_return_ownership_transfers{0U};
    std::uint64_t source_composite_return_payload_bytes_transferred{0U};
    std::uint64_t commitment_full_rebuilds{0U};
    std::uint64_t commitment_updates{0U};
    std::uint64_t commitment_delivery_entries{0U};
    std::uint64_t commitment_automatic_entries{0U};
};
inline thread_local SourceValidationWork* active_source_validation_work = nullptr;
class SourceValidationWorkScope final {
public:
    explicit SourceValidationWorkScope(SourceValidationWork& work) noexcept
        : previous_(active_source_validation_work) { active_source_validation_work = &work; }
    ~SourceValidationWorkScope() { active_source_validation_work = previous_; }
    SourceValidationWorkScope(const SourceValidationWorkScope&) = delete;
    SourceValidationWorkScope& operator=(const SourceValidationWorkScope&) = delete;
private:
    SourceValidationWork* previous_;
};
[[nodiscard]] inline std::string source_validation_work_json(const SourceValidationWork& w) {
    std::string out = "{\"scope\":\"CALLING_THREAD_SOURCE_COMMAND\"";
#define SOURCE_WORK_FIELD(name) out += ",\"" #name "\":" + std::to_string(w.name)
    SOURCE_WORK_FIELD(automatic_eligibility_candidates);
    SOURCE_WORK_FIELD(automatic_eligibility_source_reconstructions);
    SOURCE_WORK_FIELD(automatic_eligibility_envelope_bytes);
    SOURCE_WORK_FIELD(automatic_eligibility_reuses);
    SOURCE_WORK_FIELD(automatic_eligibility_binding_checks);
    SOURCE_WORK_FIELD(preparations_created);
    SOURCE_WORK_FIELD(preparation_source_reconstructions);
    SOURCE_WORK_FIELD(preparation_envelope_bytes);
    SOURCE_WORK_FIELD(preflight_preparation_uses);
    SOURCE_WORK_FIELD(application_preparation_uses);
    SOURCE_WORK_FIELD(preparation_source_binding_checks);
    SOURCE_WORK_FIELD(preflight_source_reconstructions);
    SOURCE_WORK_FIELD(application_source_reconstructions);
    SOURCE_WORK_FIELD(replay_source_reconstructions);
    SOURCE_WORK_FIELD(full_validations);
    SOURCE_WORK_FIELD(delta_validations);
    SOURCE_WORK_FIELD(reference_validations);
    SOURCE_WORK_FIELD(configuration_parses);
    SOURCE_WORK_FIELD(configuration_memo_hits);
    SOURCE_WORK_FIELD(configuration_bytes);
    SOURCE_WORK_FIELD(delivery_validations);
    SOURCE_WORK_FIELD(receipt_checks);
    SOURCE_WORK_FIELD(source_records_reconstructed);
    SOURCE_WORK_FIELD(source_payload_bytes_encoded);
    SOURCE_WORK_FIELD(envelope_bytes_constructed);
    SOURCE_WORK_FIELD(mapping_entries_visited);
    SOURCE_WORK_FIELD(mapping_digest_entries_hashed);
    SOURCE_WORK_FIELD(mapping_index_lookups);
    SOURCE_WORK_FIELD(mapping_index_hits);
    SOURCE_WORK_FIELD(mapping_index_full_rebuilds);
    SOURCE_WORK_FIELD(mapping_index_entries_rebuilt);
    SOURCE_WORK_FIELD(response_index_entries);
    SOURCE_WORK_FIELD(response_index_fixed_bytes);
    SOURCE_WORK_FIELD(state_encodes);
    SOURCE_WORK_FIELD(state_bytes_encoded);
    SOURCE_WORK_FIELD(state_decodes);
    SOURCE_WORK_FIELD(state_bytes_decoded);
    SOURCE_WORK_FIELD(copied_delivery_entries);
    SOURCE_WORK_FIELD(compared_delivery_entries);
    SOURCE_WORK_FIELD(transaction_preparations_created);
    SOURCE_WORK_FIELD(preflight_transaction_uses);
    SOURCE_WORK_FIELD(application_transaction_uses);
    SOURCE_WORK_FIELD(transaction_byte_binding_checks);
    SOURCE_WORK_FIELD(transaction_binding_bytes_compared);
    SOURCE_WORK_FIELD(transaction_binding_bytes_hashed);
    SOURCE_WORK_FIELD(preflight_progress_decodes);
    SOURCE_WORK_FIELD(application_progress_decodes);
    SOURCE_WORK_FIELD(replay_progress_decodes);
    SOURCE_WORK_FIELD(progress_outgoing_owned_copies);
    SOURCE_WORK_FIELD(progress_outgoing_bytes_copied);
    SOURCE_WORK_FIELD(progress_outgoing_slices);
    SOURCE_WORK_FIELD(progress_outgoing_slice_bytes);
    SOURCE_WORK_FIELD(progress_record_payload_bytes_decoded);
    SOURCE_WORK_FIELD(progress_transaction_encodes);
    SOURCE_WORK_FIELD(progress_transaction_bytes_encoded);
    SOURCE_WORK_FIELD(progress_transaction_decodes);
    SOURCE_WORK_FIELD(progress_transaction_bytes_decoded);
    SOURCE_WORK_FIELD(outbound_prepared_slices);
    SOURCE_WORK_FIELD(outbound_slice_header_bytes_read);
    SOURCE_WORK_FIELD(outbound_composite_frames);
    SOURCE_WORK_FIELD(outbound_record_decodes);
    SOURCE_WORK_FIELD(outbound_record_bytes_decoded);
    SOURCE_WORK_FIELD(outbound_record_payload_bytes_decoded);
    SOURCE_WORK_FIELD(outbound_record_reuses);
    SOURCE_WORK_FIELD(outbound_record_validations);
    SOURCE_WORK_FIELD(outbound_binding_checks);
    SOURCE_WORK_FIELD(outbound_binding_bytes_compared);
    SOURCE_WORK_FIELD(outbound_store_payload_bytes_copied);
    SOURCE_WORK_FIELD(outbound_store_ownership_transfers);
    SOURCE_WORK_FIELD(outbound_store_payload_bytes_transferred);
    SOURCE_WORK_FIELD(outbound_store_publication_checks);
    SOURCE_WORK_FIELD(outbound_store_digest_calls);
    SOURCE_WORK_FIELD(outbound_store_digest_payload_bytes);
    SOURCE_WORK_FIELD(outbound_policy_decodes);
    SOURCE_WORK_FIELD(outbound_policy_bytes_decoded);
    SOURCE_WORK_FIELD(source_composite_return_payload_bytes_copied);
    SOURCE_WORK_FIELD(source_composite_return_ownership_transfers);
    SOURCE_WORK_FIELD(source_composite_return_payload_bytes_transferred);
    SOURCE_WORK_FIELD(commitment_full_rebuilds);
    SOURCE_WORK_FIELD(commitment_updates);
    SOURCE_WORK_FIELD(commitment_delivery_entries);
    SOURCE_WORK_FIELD(commitment_automatic_entries);
#undef SOURCE_WORK_FIELD
    return out + "}";
}
} // namespace natrav_overlay
