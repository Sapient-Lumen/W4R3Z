#include "transport.hpp"
#include "serial_transport.hpp"
#include "udp_transport.hpp"
#include "unix_datagram_transport.hpp"

#include <algorithm>
#include <arpa/inet.h>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <string>
#include <string_view>
#include <sys/socket.h>
#include <utility>

namespace natrav_overlay {
namespace {

struct ResolvedTcpAddress final {
    sockaddr_storage storage{};
    socklen_t length{0};
    int family{AF_UNSPEC};
};

[[nodiscard]] int remaining_poll_ms(const Deadline deadline) {
    const auto now = std::chrono::steady_clock::now();
    if (now >= deadline) {
        return 0;
    }
    const auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(
        deadline - now);
    const auto count = std::max<std::chrono::milliseconds::rep>(
        remaining.count(), 1);
    return static_cast<int>(std::min<std::chrono::milliseconds::rep>(
        count, static_cast<std::chrono::milliseconds::rep>(INT_MAX)));
}

[[nodiscard]] short wait_tcp_fd(
    const int fd,
    const short events,
    const Deadline deadline,
    IoCounters& counters,
    const std::string_view operation) {
    while (true) {
        const int timeout = remaining_poll_ms(deadline);
        if (timeout == 0) {
            app_fail("IO_TIMEOUT", std::string(operation));
        }
        pollfd item{.fd = fd, .events = events, .revents = 0};
        ++counters.poll_calls;
        const int result = ::poll(&item, 1U, timeout);
        if (result < 0) {
            if (errno == EINTR) {
                ++counters.interrupted;
                continue;
            }
            app_fail("POLL_FAILED", datacube::errno_detail(operation, errno));
        }
        if (result == 0) {
            app_fail("IO_TIMEOUT", std::string(operation));
        }
        if ((item.revents & POLLNVAL) != 0) {
            app_fail("SOCKET_INVALID", std::string(operation));
        }
        return item.revents;
    }
}

[[nodiscard]] ResolvedTcpAddress resolve_numeric_tcp(
    const TcpTransportLocator& locator) {
    ResolvedTcpAddress resolved;
    sockaddr_in ipv4{};
    ipv4.sin_family = AF_INET;
    ipv4.sin_port = htons(locator.service);
    if (::inet_pton(AF_INET, locator.host.c_str(), &ipv4.sin_addr) == 1) {
        std::memcpy(&resolved.storage, &ipv4, sizeof(ipv4));
        resolved.length = static_cast<socklen_t>(sizeof(ipv4));
        resolved.family = AF_INET;
        return resolved;
    }
    sockaddr_in6 ipv6{};
    ipv6.sin6_family = AF_INET6;
    ipv6.sin6_port = htons(locator.service);
    if (::inet_pton(AF_INET6, locator.host.c_str(), &ipv6.sin6_addr) == 1) {
        std::memcpy(&resolved.storage, &ipv6, sizeof(ipv6));
        resolved.length = static_cast<socklen_t>(sizeof(ipv6));
        resolved.family = AF_INET6;
        return resolved;
    }
    app_fail(
        "ENDPOINT_RESOLUTION_FAILED",
        "host must be a numeric IPv4 or IPv6 address");
}

void configure_tcp_stream(const int fd) noexcept {
    const int enabled = 1;
    static_cast<void>(::setsockopt(
        fd, IPPROTO_TCP, TCP_NODELAY, &enabled, sizeof(enabled)));
}

class TcpOrderedByteStream final : public OrderedByteStream {
public:
    explicit TcpOrderedByteStream(datacube::Fd fd) noexcept
        : fd_(std::move(fd)) {}

    [[nodiscard]] TransportKind transport_kind() const noexcept override {
        return TransportKind::tcp;
    }

    [[nodiscard]] std::size_t read_some(
        const std::span<std::uint8_t> buffer,
        const Deadline deadline,
        IoCounters& counters,
        const std::string_view operation) override {
        if (fd_.get() < 0 || buffer.empty()) {
            app_fail("SOCKET_INVALID", std::string(operation));
        }
        while (true) {
            const short events = wait_tcp_fd(
                fd_.get(), POLLIN, deadline, counters, operation);
            if ((events & (POLLIN | POLLHUP | POLLERR)) == 0) {
                continue;
            }
            ++counters.read_calls;
            const ssize_t count = ::recv(
                fd_.get(), buffer.data(), buffer.size(), 0);
            if (count >= 0) {
                return static_cast<std::size_t>(count);
            }
            if (errno == EINTR) {
                ++counters.interrupted;
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                ++counters.would_block;
                continue;
            }
            if (errno == ECONNRESET) {
                app_fail("PEER_RESET", datacube::errno_detail(operation, errno));
            }
            app_fail(
                "SOCKET_READ_FAILED",
                datacube::errno_detail(operation, errno));
        }
    }

    [[nodiscard]] std::size_t write_some(
        const datacube::OctetView bytes,
        const Deadline deadline,
        IoCounters& counters,
        const std::string_view operation) override {
        if (fd_.get() < 0 || bytes.empty()) {
            app_fail("SOCKET_INVALID", std::string(operation));
        }
        while (true) {
            static_cast<void>(wait_tcp_fd(
                fd_.get(), POLLOUT, deadline, counters, operation));
            ++counters.write_calls;
            const ssize_t count = ::send(
                fd_.get(), bytes.data(), bytes.size(), MSG_NOSIGNAL);
            if (count > 0) {
                return static_cast<std::size_t>(count);
            }
            if (count == 0) {
                app_fail("SOCKET_WRITE_CLOSED", "send made no progress");
            }
            if (errno == EINTR) {
                ++counters.interrupted;
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                ++counters.would_block;
                continue;
            }
            if (errno == EPIPE || errno == ECONNRESET) {
                app_fail(
                    "SOCKET_WRITE_CLOSED",
                    datacube::errno_detail(operation, errno));
            }
            app_fail(
                "SOCKET_WRITE_FAILED",
                datacube::errno_detail(operation, errno));
        }
    }

    void shutdown_write() override {
        if (::shutdown(fd_.get(), SHUT_WR) != 0 && errno != ENOTCONN) {
            app_fail(
                "SOCKET_SHUTDOWN_FAILED",
                datacube::errno_detail("shutdown write", errno));
        }
    }

private:
    datacube::Fd fd_;
};

class TcpTransportConnector final : public TransportConnector {
public:
    [[nodiscard]] std::unique_ptr<OrderedByteStream> connect(
        const TransportLocator& locator,
        const Deadline deadline,
        IoCounters& counters) const override {
        const auto& tcp = tcp_transport_locator(locator);
        if (tcp.service == 0U) {
            app_fail("INVALID_ENDPOINT", "connect port cannot be zero");
        }
        const auto address = resolve_numeric_tcp(tcp);
        const int raw = ::socket(
            address.family,
            SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK,
            IPPROTO_TCP);
        if (raw < 0) {
            app_fail(
                "CONNECT_FAILED",
                datacube::errno_detail(transport_locator_text(locator), errno));
        }
        datacube::Fd candidate(raw);
        configure_tcp_stream(candidate.get());
        const int result = ::connect(
            candidate.get(),
            reinterpret_cast<const sockaddr*>(&address.storage),
            address.length);
        if (result != 0) {
            if (errno != EINPROGRESS) {
                app_fail(
                    "CONNECT_FAILED",
                    datacube::errno_detail(
                        transport_locator_text(locator), errno));
            }
            const short events = wait_tcp_fd(
                candidate.get(), POLLOUT, deadline, counters, "connect");
            if ((events & (POLLOUT | POLLERR | POLLHUP)) == 0) {
                app_fail("CONNECT_FAILED", transport_locator_text(locator));
            }
            int socket_error = 0;
            socklen_t length = sizeof(socket_error);
            if (::getsockopt(
                    candidate.get(), SOL_SOCKET, SO_ERROR,
                    &socket_error, &length) != 0) {
                app_fail(
                    "CONNECT_FAILED",
                    datacube::errno_detail("getsockopt SO_ERROR", errno));
            }
            if (socket_error != 0) {
                app_fail(
                    "CONNECT_FAILED",
                    datacube::errno_detail(
                        transport_locator_text(locator), socket_error));
            }
        }
        return std::make_unique<TcpOrderedByteStream>(std::move(candidate));
    }
};

class TcpTransportListener final : public TransportListener {
public:
    TcpTransportListener(
        TransportLocator configured,
        datacube::Fd listener) noexcept
        : configured_(std::move(configured)), listener_(std::move(listener)) {}

    [[nodiscard]] TransportKind transport_kind() const noexcept override {
        return TransportKind::tcp;
    }

    [[nodiscard]] int readiness_handle() const noexcept override {
        return listener_.get();
    }

    [[nodiscard]] TransportLocator bound_locator() const override {
        sockaddr_storage address{};
        socklen_t length = sizeof(address);
        if (::getsockname(
                listener_.get(),
                reinterpret_cast<sockaddr*>(&address),
                &length) != 0) {
            app_fail(
                "SOCKET_NAME_FAILED",
                datacube::errno_detail("getsockname", errno));
        }
        std::uint16_t service = 0U;
        if (address.ss_family == AF_INET) {
            const auto* value = reinterpret_cast<const sockaddr_in*>(&address);
            service = ntohs(value->sin_port);
        } else if (address.ss_family == AF_INET6) {
            const auto* value = reinterpret_cast<const sockaddr_in6*>(&address);
            service = ntohs(value->sin6_port);
        } else {
            app_fail("SOCKET_NAME_FAILED", "unexpected socket family");
        }
        auto result = configured_;
        result.tcp.service = service;
        return result;
    }

    [[nodiscard]] std::unique_ptr<OrderedByteStream> accept_ready() override {
        while (true) {
            const int raw = ::accept4(
                listener_.get(), nullptr, nullptr,
                SOCK_CLOEXEC | SOCK_NONBLOCK);
            if (raw < 0) {
                if (errno == EINTR) {
                    continue;
                }
                if (errno == EAGAIN || errno == EWOULDBLOCK) {
                    return nullptr;
                }
                app_fail(
                    "ACCEPT_FAILED",
                    datacube::errno_detail("accept4", errno));
            }
            datacube::Fd connection(raw);
            configure_tcp_stream(connection.get());
            return std::make_unique<TcpOrderedByteStream>(
                std::move(connection));
        }
    }

private:
    TransportLocator configured_;
    datacube::Fd listener_;
};

[[nodiscard]] std::unique_ptr<TransportListener> listen_tcp_transport(
    const TransportLocator& locator,
    const int backlog) {
    if (backlog < 1 || backlog > 1024) {
        app_fail("INVALID_LISTEN_BACKLOG", "backlog outside 1..1024");
    }
    const auto& tcp = tcp_transport_locator(locator);
    const auto address = resolve_numeric_tcp(tcp);
    const int raw = ::socket(
        address.family,
        SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK,
        IPPROTO_TCP);
    if (raw < 0) {
        app_fail(
            "LISTEN_FAILED",
            datacube::errno_detail(transport_locator_text(locator), errno));
    }
    datacube::Fd candidate(raw);
    const int enabled = 1;
    static_cast<void>(::setsockopt(
        candidate.get(), SOL_SOCKET, SO_REUSEADDR,
        &enabled, sizeof(enabled)));
    configure_tcp_stream(candidate.get());
    if (::bind(
            candidate.get(),
            reinterpret_cast<const sockaddr*>(&address.storage),
            address.length) != 0) {
        app_fail(
            "LISTEN_FAILED",
            datacube::errno_detail(transport_locator_text(locator), errno));
    }
    if (::listen(candidate.get(), backlog) != 0) {
        app_fail(
            "LISTEN_FAILED",
            datacube::errno_detail(transport_locator_text(locator), errno));
    }
    return std::make_unique<TcpTransportListener>(
        locator, std::move(candidate));
}

}  // namespace

TransportKind parse_transport_kind(const std::string_view text) {
    if (text == "tcp") {
        return TransportKind::tcp;
    }
    if (text == "serial") {
        return TransportKind::serial;
    }
    if (text == "udp") {
        return TransportKind::udp;
    }
    if (text == "adapter") { return TransportKind::adapter; }
    if (text == "unix-dgram") {
        return TransportKind::unix_datagram;
    }
    app_fail(
        "TRANSPORT_KIND_UNSUPPORTED",
        "only the canonical transport kinds 'tcp', 'serial', 'udp', 'unix-dgram', and 'adapter' are supported");
}

std::string_view transport_kind_name(const TransportKind kind) {
    switch (kind) {
        case TransportKind::tcp:
            return "tcp";
        case TransportKind::serial:
            return "serial";
        case TransportKind::udp:
            return "udp";
        case TransportKind::unix_datagram:
            return "unix-dgram";
        case TransportKind::adapter:
            return "adapter";
        case TransportKind::packet_link:
            return "packet-link-private";
        case TransportKind::virtual_link:
            return "virtual-link-private";
    }
    app_fail(
        "TRANSPORT_KIND_UNSUPPORTED",
        "unknown internal transport kind");
}

TransportCapabilities transport_capabilities(const TransportKind kind) {
    switch (kind) {
        case TransportKind::tcp:
            return TransportCapabilities{};
        case TransportKind::serial:
            return TransportCapabilities{
                .reliable_stream = false,
                .ordered = true,
                .full_duplex = true,
                .can_dial = true,
                .can_listen = true,
                .can_shutdown_write = false,
            };
        case TransportKind::udp:
            return TransportCapabilities{};
        case TransportKind::unix_datagram:
        case TransportKind::adapter:
            return TransportCapabilities{};
        case TransportKind::packet_link:
            return TransportCapabilities{
                .reliable_stream = true,
                .ordered = true,
                .full_duplex = true,
                .can_dial = false,
                .can_listen = false,
                .can_shutdown_write = true,
            };
        case TransportKind::virtual_link:
            return TransportCapabilities{};
    }
    app_fail(
        "TRANSPORT_KIND_UNSUPPORTED",
        "unknown internal transport kind");
}

TransportLocator parse_transport_locator(
    const TransportKind kind,
    const std::string_view text,
    const bool allow_zero_service) {
    switch (kind) {
        case TransportKind::tcp:
            return parse_tcp_transport_locator(text, allow_zero_service);
        case TransportKind::serial:
            static_cast<void>(allow_zero_service);
            return parse_serial_transport_locator(text);
        case TransportKind::udp:
            static_cast<void>(allow_zero_service);
            return parse_udp_transport_locator(text);
        case TransportKind::adapter:
            return parse_adapter_endpoint_transport_locator(text);
        case TransportKind::unix_datagram:
            static_cast<void>(allow_zero_service);
            return parse_unix_datagram_transport_locator(text);
        case TransportKind::packet_link:
            app_fail(
                "TRANSPORT_KIND_UNSUPPORTED",
                "the private packet link has no configured locator");
        case TransportKind::virtual_link:
            app_fail(
                "TRANSPORT_KIND_UNSUPPORTED",
                "the private virtual link has no configured locator");
    }
    app_fail(
        "TRANSPORT_KIND_UNSUPPORTED",
        "unknown internal transport kind");
}

TransportLocator parse_tcp_transport_locator(
    const std::string_view text,
    const bool allow_zero_service) {
    if (text.empty()) {
        app_fail("INVALID_ENDPOINT", "endpoint is empty");
    }
    std::string_view host;
    std::string_view service_text;
    if (text.front() == '[') {
        const auto close = text.find(']');
        if (close == std::string_view::npos ||
            close + 1U >= text.size() || text[close + 1U] != ':') {
            app_fail("INVALID_ENDPOINT", "invalid bracketed endpoint");
        }
        host = text.substr(1U, close - 1U);
        service_text = text.substr(close + 2U);
    } else {
        const auto colon = text.rfind(':');
        if (colon == std::string_view::npos || colon == 0U ||
            colon + 1U >= text.size()) {
            app_fail("INVALID_ENDPOINT", "expected numeric-host:port");
        }
        host = text.substr(0U, colon);
        service_text = text.substr(colon + 1U);
    }
    const auto minimum = allow_zero_service ? 0U : 1U;
    const auto service = parse_u64(
        service_text, "port", minimum, 65'535U);
    TransportLocator locator{
        .kind = TransportKind::tcp,
        .tcp = TcpTransportLocator{
            .host = std::string(host),
            .service = static_cast<std::uint16_t>(service),
        },
        .serial = {},
        .udp = {},
        .unix_datagram = {},
    };
    static_cast<void>(resolve_numeric_tcp(locator.tcp));
    return locator;
}

std::string transport_locator_text(const TransportLocator& locator) {
    switch (locator.kind) {
        case TransportKind::tcp: {
            const auto& tcp = tcp_transport_locator(locator);
            const bool bracket = tcp.host.find(':') != std::string::npos;
            return (bracket ? "[" + tcp.host + "]" : tcp.host) +
                ":" + std::to_string(tcp.service);
        }
        case TransportKind::serial:
            return serial_transport_locator_text(
                serial_transport_locator(locator));
        case TransportKind::udp:
            return udp_transport_locator_text(udp_transport_locator(locator));
        case TransportKind::adapter: {
            const auto text = "adapter-endpoint-v1|id=" + locator.adapter.endpoint_id +
                "|generation=" + std::to_string(locator.adapter.generation);
            static_cast<void>(parse_adapter_endpoint_transport_locator(text));
            return text;
        }
        case TransportKind::unix_datagram:
            return unix_datagram_transport_locator_text(
                unix_datagram_transport_locator(locator));
        case TransportKind::packet_link:
            app_fail(
                "TRANSPORT_KIND_UNSUPPORTED",
                "the private packet link has no configured locator");
        case TransportKind::virtual_link:
            app_fail(
                "TRANSPORT_KIND_UNSUPPORTED",
                "the private virtual link has no configured locator");
    }
    app_fail(
        "TRANSPORT_KIND_UNSUPPORTED",
        "unknown internal transport kind");
}

const TcpTransportLocator& tcp_transport_locator(
    const TransportLocator& locator) {
    if (locator.kind != TransportKind::tcp) {
        app_fail(
            "TRANSPORT_KIND_UNSUPPORTED",
            "locator is not a TCP locator");
    }
    return locator.tcp;
}

const SerialTransportLocator& serial_transport_locator(
    const TransportLocator& locator) {
    if (locator.kind != TransportKind::serial) {
        app_fail(
            "TRANSPORT_KIND_UNSUPPORTED",
            "locator is not a serial locator");
    }
    return locator.serial;
}

const UdpTransportLocator& udp_transport_locator(
    const TransportLocator& locator) {
    if (locator.kind != TransportKind::udp) {
        app_fail(
            "TRANSPORT_KIND_UNSUPPORTED",
            "locator is not a UDP locator");
    }
    return locator.udp;
}

const UnixDatagramTransportLocator& unix_datagram_transport_locator(
    const TransportLocator& locator) {
    if (locator.kind != TransportKind::unix_datagram) {
        app_fail(
            "TRANSPORT_KIND_UNSUPPORTED",
            "locator is not a Unix datagram locator");
    }
    return locator.unix_datagram;
}

TransportLocator parse_adapter_endpoint_transport_locator(const std::string_view text) {
    constexpr std::string_view prefix = "adapter-endpoint-v1|id=";
    constexpr std::string_view generation_field = "|generation=";
    const auto split = text.find(generation_field, prefix.size());
    if (!text.starts_with(prefix) || split == std::string_view::npos || text.size() > 160U) {
        app_fail("ADAPTER_ENDPOINT_LOCATOR_INVALID", "expected canonical exact endpoint reference");
    }
    const auto id = text.substr(prefix.size(), split - prefix.size());
    const auto number = text.substr(split + generation_field.size());
    if (id.empty() || id.size() > 64U || id.front() < 'a' || id.front() > 'z' ||
        !std::all_of(id.begin(), id.end(), [](const char ch) {
            return (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '-' || ch == '_';
        }) || number.empty() || number.front() == '0' ||
        !std::all_of(number.begin(), number.end(), [](const char ch) {return ch >= '0' && ch <= '9';})) {
        app_fail("ADAPTER_ENDPOINT_LOCATOR_INVALID", "invalid endpoint identifier or canonical generation");
    }
    TransportLocator result;
    result.kind = TransportKind::adapter;
    result.adapter.endpoint_id = std::string(id);
    result.adapter.generation = parse_u64(number, "endpoint generation", 1U, UINT64_MAX);
    return result;
}

TransportLocator parse_configured_transport_locator(
    const std::string_view text,
    const bool allow_zero_service) {
    if (text.starts_with("adapter-endpoint-v1|")) {
        return parse_adapter_endpoint_transport_locator(text);
    }
    if (text.starts_with("serial-v1|")) {
        return parse_serial_transport_locator(text);
    }
    if (text.starts_with("udp-v1|")) {
        return parse_udp_transport_locator(text);
    }
    if (text.starts_with("unix-dgram-v1|")) {
        return parse_unix_datagram_transport_locator(text);
    }
    return parse_tcp_transport_locator(text, allow_zero_service);
}

const TransportConnector& transport_connector(const TransportKind kind) {
    static const TcpTransportConnector tcp;
    switch (kind) {
        case TransportKind::tcp:
            return tcp;
        case TransportKind::serial:
            return serial_transport_connector();
        case TransportKind::udp:
            return udp_transport_connector();
        case TransportKind::unix_datagram:
            return unix_datagram_transport_connector();
        case TransportKind::adapter:
            app_fail("ADAPTER_AUTHORIZED_CONTEXT_REQUIRED", "adapter execution requires an accepted V19 snapshot");
        case TransportKind::packet_link:
            app_fail(
                "TRANSPORT_KIND_UNSUPPORTED",
                "the private packet link is fixture-owned and cannot dial routes");
        case TransportKind::virtual_link:
            app_fail(
                "TRANSPORT_KIND_UNSUPPORTED",
                "the private virtual link is fixture-owned and cannot dial routes");
    }
    app_fail(
        "TRANSPORT_KIND_UNSUPPORTED",
        "unknown internal transport kind");
}

std::unique_ptr<OrderedByteStream> connect_transport(
    const TransportLocator& locator,
    const Deadline deadline,
    IoCounters& counters) {
    return transport_connector(locator.kind).connect(locator, deadline, counters);
}

std::unique_ptr<TransportListener> listen_transport(
    const TransportLocator& locator,
    const int backlog) {
    switch (locator.kind) {
        case TransportKind::tcp:
            return listen_tcp_transport(locator, backlog);
        case TransportKind::serial:
            return listen_serial_transport(locator, backlog);
        case TransportKind::udp:
            return listen_udp_transport(locator, backlog);
        case TransportKind::unix_datagram:
            return listen_unix_datagram_transport(locator, backlog);
        case TransportKind::adapter:
            app_fail("ADAPTER_AUTHORIZED_CONTEXT_REQUIRED", "adapter listener requires an accepted V19 snapshot");
        case TransportKind::packet_link:
            app_fail(
                "TRANSPORT_KIND_UNSUPPORTED",
                "the private packet link is fixture-owned and cannot listen");
        case TransportKind::virtual_link:
            app_fail(
                "TRANSPORT_KIND_UNSUPPORTED",
                "the private virtual link is fixture-owned and cannot listen");
    }
    app_fail(
        "TRANSPORT_KIND_UNSUPPORTED",
        "unknown internal transport kind");
}

}  // namespace natrav_overlay
