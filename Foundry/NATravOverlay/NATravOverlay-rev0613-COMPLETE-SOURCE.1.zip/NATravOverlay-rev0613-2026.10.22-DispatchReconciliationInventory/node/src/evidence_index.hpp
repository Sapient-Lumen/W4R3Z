#pragma once

#include "common.hpp"
#include <cstddef>
#include <cstdint>
#include <optional>
#include <vector>

namespace natrav_overlay {
// Derived admission-order index. A Fenwick tree of live bits supplies rank and
// select for plural current heads without scanning superseded history. It is
// rebuilt by ordinary replay; it is neither a second authority nor persisted.
class EvidenceOrderedIndex final {
public:
    void append(std::size_t index, std::optional<std::size_t> parent);
    [[nodiscard]] std::size_t size(bool history) const noexcept;
    [[nodiscard]] std::size_t before(std::size_t exclusive, bool history) const;
    [[nodiscard]] std::size_t at(std::size_t ordinal, bool history) const;
    [[nodiscard]] std::size_t allocated_bytes() const noexcept;
private:
    [[nodiscard]] std::size_t prefix(std::size_t count) const noexcept;
    std::vector<std::size_t> history_;
    std::vector<std::size_t> live_tree_; // zero-based storage for a one-based tree
    std::size_t current_size_{0U};
};

struct EvidenceRootCacheEntry final {
    datacube::Digest32 key;
    std::uint64_t version{0U};
    datacube::Digest32 root;
    std::uint64_t selected{0U};
    std::uint64_t used{0U};
};

// At most 32 fixed-size roots, never snapshots, record arrays, payloads or
// authority grants. Every lookup rechecks the current caller and index version.
class EvidenceRootCache final {
public:
    static constexpr std::size_t capacity = 32U;
    [[nodiscard]] std::optional<EvidenceRootCacheEntry> get(
        const datacube::Digest32& key, std::uint64_t version);
    void put(EvidenceRootCacheEntry value);
    [[nodiscard]] std::size_t allocated_bytes() const noexcept;
private:
    [[nodiscard]] std::uint64_t tick() noexcept;
    std::vector<EvidenceRootCacheEntry> entries_;
    std::uint64_t clock_{0U};
};
} // namespace natrav_overlay
