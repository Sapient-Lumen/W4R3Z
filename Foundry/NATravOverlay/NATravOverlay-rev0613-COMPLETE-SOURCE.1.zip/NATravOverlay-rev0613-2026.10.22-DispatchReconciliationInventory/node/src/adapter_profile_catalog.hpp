#pragma once

#include "adapter_profile.hpp"

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace natrav_overlay {

inline constexpr char kDurableAdapterProfileCatalogMarker[] =
    "DURABLE_ADAPTER_PROFILE_CATALOG_V1";
[[nodiscard]] int durable_adapter_profile_catalog_revision_abi() noexcept;

class AdapterCatalogError final : public std::runtime_error {
public:
    AdapterCatalogError(std::string code, std::string detail);

    [[nodiscard]] const std::string& code() const noexcept;

private:
    std::string code_;
};

enum class AdapterEndpointRole : std::uint8_t {
    route = 1U,
    listener = 2U,
};

struct ConfiguredAdapterEndpoint final {
    std::string endpoint_id;
    std::uint64_t generation{0U};
    AdapterSha256 previous_endpoint_sha256{};
    AdapterEndpointRole role{AdapterEndpointRole::route};
    AdapterTransportLocator locator{};
    AdapterSha256 profile_sha256{};

    friend bool operator==(
        const ConfiguredAdapterEndpoint&,
        const ConfiguredAdapterEndpoint&) = default;
};

void validate_configured_adapter_endpoint(
    const ConfiguredAdapterEndpoint& endpoint);
[[nodiscard]] std::string configured_adapter_endpoint_text(
    const ConfiguredAdapterEndpoint& endpoint);
[[nodiscard]] ConfiguredAdapterEndpoint parse_configured_adapter_endpoint(
    std::string_view text);
[[nodiscard]] AdapterSha256 configured_adapter_endpoint_sha256(
    const ConfiguredAdapterEndpoint& endpoint);
void validate_configured_adapter_endpoint_transition(
    const ConfiguredAdapterEndpoint* current,
    const ConfiguredAdapterEndpoint& proposed);

enum class AdapterCatalogOperation : std::uint8_t {
    profile_create = 1U,
    profile_replace = 2U,
    endpoint_create = 3U,
    endpoint_replace = 4U,
};

[[nodiscard]] std::string_view adapter_catalog_operation_text(
    AdapterCatalogOperation operation) noexcept;

struct AdapterCatalogAuthorityDecision final {
    bool authorized{false};
    // Required when authorized is false. It is retained as bounded evidence,
    // and must be an uppercase token containing only A-Z, 0-9, and '_'.
    std::string rejection_code{};
};

using AdapterCatalogAuthorityVerifier = std::function<
    AdapterCatalogAuthorityDecision(
        AdapterCatalogOperation operation,
        std::span<const std::uint8_t> canonical_object,
        std::span<const std::uint8_t> opaque_authority_evidence)>;

struct AdapterCatalogLimits final {
    std::size_t maximum_file_bytes{16U * 1'048'576U};
    std::size_t maximum_records{4'096U};
    std::size_t maximum_profiles{512U};
    std::size_t maximum_endpoints{1'024U};
    std::size_t maximum_rejections{256U};
    std::size_t maximum_authority_evidence_bytes{4'096U};
};

struct AuthorizedAdapterProfileRecord final {
    OperatorPinnedAdapterProfile profile{};
    AdapterSha256 authority_evidence_sha256{};
    std::uint64_t sequence{0U};
    AdapterSha256 catalog_record_sha256{};

    friend bool operator==(
        const AuthorizedAdapterProfileRecord&,
        const AuthorizedAdapterProfileRecord&) = default;
};

struct AuthorizedAdapterEndpointRecord final {
    ConfiguredAdapterEndpoint endpoint{};
    AdapterSha256 authority_evidence_sha256{};
    std::uint64_t sequence{0U};
    AdapterSha256 catalog_record_sha256{};

    friend bool operator==(
        const AuthorizedAdapterEndpointRecord&,
        const AuthorizedAdapterEndpointRecord&) = default;
};

struct AdapterCatalogRejection final {
    AdapterCatalogOperation operation{AdapterCatalogOperation::profile_create};
    AdapterSha256 object_sha256{};
    AdapterSha256 authority_evidence_sha256{};
    std::string code{};
    std::uint64_t sequence{0U};
    AdapterSha256 catalog_record_sha256{};

    friend bool operator==(
        const AdapterCatalogRejection&,
        const AdapterCatalogRejection&) = default;
};

struct AdapterCatalogRecovery final {
    std::size_t discarded_bytes{0U};
    AdapterSha256 discarded_sha256{};
    std::uint64_t sequence{0U};
    AdapterSha256 catalog_record_sha256{};

    friend bool operator==(
        const AdapterCatalogRecovery&,
        const AdapterCatalogRecovery&) = default;
};

struct AdapterProfileCatalogSnapshot final {
    std::uint64_t last_sequence{0U};
    AdapterSha256 last_record_sha256{};
    std::vector<AuthorizedAdapterProfileRecord> profiles{};
    std::vector<AuthorizedAdapterEndpointRecord> endpoints{};
    std::vector<AdapterCatalogRejection> rejections{};
    std::vector<AdapterCatalogRecovery> recoveries{};

    friend bool operator==(
        const AdapterProfileCatalogSnapshot&,
        const AdapterProfileCatalogSnapshot&) = default;
};

struct ResolvedConfiguredAdapterEndpoint final {
    ConfiguredAdapterEndpoint endpoint{};
    OperatorPinnedAdapterProfile profile{};
    AdapterSha256 profile_sha256{};
    AdapterSha256 endpoint_sha256{};

    friend bool operator==(
        const ResolvedConfiguredAdapterEndpoint&,
        const ResolvedConfiguredAdapterEndpoint&) = default;
};

class DurableAdapterProfileCatalog final {
public:
    explicit DurableAdapterProfileCatalog(
        std::filesystem::path path,
        AdapterCatalogLimits limits = {});

    [[nodiscard]] const std::filesystem::path& path() const noexcept;
    [[nodiscard]] const AdapterCatalogLimits& limits() const noexcept;

    // Creates an empty owner-private catalog if absent, then returns the exact
    // replayed state. A partial final frame from an interrupted append is
    // deterministically truncated and represented by a recovery record.
    [[nodiscard]] AdapterProfileCatalogSnapshot snapshot() const;

    // Reads without repairing an incomplete tail. This is used by negative
    // controls and offline auditing.
    [[nodiscard]] AdapterProfileCatalogSnapshot snapshot_strict() const;

    [[nodiscard]] AuthorizedAdapterProfileRecord commit_profile(
        const OperatorPinnedAdapterProfile& profile,
        std::span<const std::uint8_t> opaque_authority_evidence,
        const AdapterCatalogAuthorityVerifier& verifier) const;

    [[nodiscard]] AuthorizedAdapterEndpointRecord commit_endpoint(
        const ConfiguredAdapterEndpoint& endpoint,
        std::span<const std::uint8_t> opaque_authority_evidence,
        const AdapterCatalogAuthorityVerifier& verifier) const;

    [[nodiscard]] ResolvedConfiguredAdapterEndpoint resolve_endpoint(
        std::string_view endpoint_id,
        std::uint64_t endpoint_generation) const;

private:
    std::filesystem::path path_{};
    AdapterCatalogLimits limits_{};
};

[[nodiscard]] ResolvedConfiguredAdapterEndpoint resolve_configured_adapter_endpoint(
    const AdapterProfileCatalogSnapshot& snapshot,
    std::string_view endpoint_id,
    std::uint64_t endpoint_generation);

}  // namespace natrav_overlay
