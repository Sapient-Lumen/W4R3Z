#pragma once

#include "finite_packet_link.hpp"
#include "transport.hpp"

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <memory>

namespace natrav_overlay {

inline constexpr char kPacketLinkOrderedByteStreamMarker[] =
    "PACKET_LINK_ORDERED_BYTE_STREAM_ADAPTER_V1";
[[nodiscard]] int packet_link_ordered_stream_revision_abi() noexcept;

enum class PacketLinkEndpoint : std::uint8_t {
    first = 1U,
    second = 2U,
};

struct PacketLinkStreamOptions final {
    natrav::packet_link::Limits limits{};
    natrav::packet_link::FaultSchedule schedule{};
    std::uint64_t stream_id{0x4e4154524156504cULL};
    std::uint32_t epoch{1U};
    std::size_t queue_capacity_packets{4096U};
    std::size_t trace_capacity_events{1'000'000U};
    std::chrono::milliseconds progress_interval{1};
};

struct PacketLinkSnapshot final {
    std::uint64_t logical_tick{0U};
    bool first_alive{false};
    bool second_alive{false};
    bool reset{false};
    std::size_t queued_packets{0U};
    natrav::packet_link::StreamStats first_stats{};
    natrav::packet_link::StreamStats second_stats{};
    natrav::packet_link::Bytes canonical_schedule{};
    natrav::packet_link::Bytes canonical_trace{};
};

struct PacketLinkStreamPair;

class PacketLinkControl final {
public:
    struct State;

    PacketLinkControl(const PacketLinkControl&) = delete;
    PacketLinkControl& operator=(const PacketLinkControl&) = delete;
    ~PacketLinkControl();

    [[nodiscard]] PacketLinkSnapshot snapshot() const;
    void reset_link();
    void disconnect_endpoint(PacketLinkEndpoint endpoint);

private:
    explicit PacketLinkControl(std::shared_ptr<State> state) noexcept;
    std::shared_ptr<State> state_;

    friend struct PacketLinkStreamPair;
    friend PacketLinkStreamPair make_packet_link_stream_pair(
        PacketLinkStreamOptions options);
};

struct PacketLinkStreamPair final {
    std::unique_ptr<OrderedByteStream> first;
    std::unique_ptr<OrderedByteStream> second;
    std::shared_ptr<PacketLinkControl> control;
};

[[nodiscard]] PacketLinkStreamPair make_packet_link_stream_pair(
    PacketLinkStreamOptions options = {});

}  // namespace natrav_overlay
