# Current validation — revision 0613

The authoritative in-tree product account is `revision-0613/STATUS.json`. It
records the strict static build, 162 source-authority checks, focused static and
ASan/UBSan custody/reconciliation runs, the risk-adjacent matrix, the complete
registered matrix, the source-tree audit, and the assurance boundary. External
sidecars verify exact rev0612 patch reconstruction, the frozen complete-source
archive, byte-identical clean extracted rebuilding, the canonical two-file
product, and delivery integrity. Older revision directories are retained
provenance only.
