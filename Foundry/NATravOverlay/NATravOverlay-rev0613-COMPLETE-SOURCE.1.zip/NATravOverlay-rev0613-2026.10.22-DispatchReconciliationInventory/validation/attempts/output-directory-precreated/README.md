# Retained attempt: pre-created output directory

The first release-focal wrapper created the runner output directory before invoking the runner. The runner deliberately requires a new output path and rejected the invocation before testing. This is orchestration evidence, not a product failure and not release evidence.
