# Retained attempt

The first focal run used an early binary whose version JSON omitted the retained finite packet-core marker. Product metadata was repaired and rebuilt.
