# Retained patch attempt

The first textual-patch wrapper used `git diff` without intent-to-add entries. Git therefore omitted five newly added UDP files; reconstruction correctly failed. The wrapper was repaired to add explicit intent-to-add index entries before regenerating the patch.
