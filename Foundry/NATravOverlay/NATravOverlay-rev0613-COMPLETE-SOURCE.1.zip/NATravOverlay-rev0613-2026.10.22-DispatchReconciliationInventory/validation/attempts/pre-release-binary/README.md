# Retained attempt

This focal run passed against a preliminary binary. A later constant-work logical-clock repair changed the release digest, so this is retained but is not release evidence.
