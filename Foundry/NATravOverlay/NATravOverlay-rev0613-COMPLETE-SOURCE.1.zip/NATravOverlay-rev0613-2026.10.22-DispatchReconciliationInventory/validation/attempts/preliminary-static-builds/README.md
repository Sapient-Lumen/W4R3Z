# Retained preliminary builds

Two successful preliminary builds preceded the constant-work logical-clock repair. Their digests are retained but are not release evidence.
