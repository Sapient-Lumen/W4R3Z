# Retained attempt

A source-contract predicate required one spelling of nonblocking setup and failed although the UDP module owned O_NONBLOCK correctly. The predicate was repaired to test the owned behavior.
