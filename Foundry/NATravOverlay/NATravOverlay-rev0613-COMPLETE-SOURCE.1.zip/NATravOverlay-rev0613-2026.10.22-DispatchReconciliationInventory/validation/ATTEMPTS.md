# Retained attempts — revision 0599

See `revision-0599/RETAINED-ATTEMPTS.json`. Failed or interrupted wrappers are not counted as passing evidence. Historical attempt records remain provenance.
