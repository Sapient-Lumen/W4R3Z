# Reused foundation protocol subset

This directory contains only the upstream C++ files compiled by
[`node/build.sh`](../node/build.sh): five headers and five translation units for the
core utilities, peer framing, typed handshake/messages, stream decoding, and session
state. They are byte-for-byte copies of the corresponding revision-0488 sources.

The rest of the historical carrier source is intentionally absent. It remains in the
owner-retained predecessor ZIP and is not required to build, run, test, or continue
the native node.

## Active dependency

The node includes:

- `datacube/core.hpp` / `src/core.cpp`;
- `datacube/natrav_peer_handshake.hpp` / matching source;
- `datacube/natrav_peer_message.hpp` / matching source;
- `datacube/natrav_peer_session.hpp` / matching source;
- `datacube/natrav_peer_stream.hpp` / matching source.

Native sockets, application records, authorization, durable actions, storage, recovery, and operator commands live
in [`../node/src/`](../node/src/). The root
[`BOOTSTRAPROSE.md`](../BOOTSTRAPROSE.md) and current
[`BUILD-PLAN`](../docs/BUILD-PLAN.md) govern development; historical carrier
workflows and receipts do not.

## Build and component tests

Build the product from the workspace root:

```sh
./node/build.sh static
```

[`BUILD.txt`](BUILD.txt) records a focused recipe for the opt-in regressions embedded
in these upstream files. Run the relevant selector when changing this subset. There
is no reason to reconstruct the former sealed carrier before extending the product.
