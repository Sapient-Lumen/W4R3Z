#include "datacube/core.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cstring>
#include <fcntl.h>
#include <iomanip>
#include <limits>
#include <sstream>
#include <utility>

#include <sys/types.h>
#include <unistd.h>

namespace datacube {
namespace {

[[nodiscard]] std::size_t checked_size(
    const std::uint64_t value,
    const std::string_view locator,
    const std::string_view field) {
    if (value > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
        fail("integer-overflow", std::string(locator) + ": " + std::string(field));
    }
    return static_cast<std::size_t>(value);
}

[[nodiscard]] std::uint32_t rotate_right(
    const std::uint32_t value,
    const unsigned int bits) noexcept {
    return (value >> bits) | (value << (32U - bits));
}

[[nodiscard]] std::uint32_t load_be32(const std::uint8_t* input) noexcept {
    return (static_cast<std::uint32_t>(input[0]) << 24U) |
           (static_cast<std::uint32_t>(input[1]) << 16U) |
           (static_cast<std::uint32_t>(input[2]) << 8U) |
           static_cast<std::uint32_t>(input[3]);
}

void store_be32(std::uint8_t* output, const std::uint32_t value) noexcept {
    output[0] = static_cast<std::uint8_t>(value >> 24U);
    output[1] = static_cast<std::uint8_t>(value >> 16U);
    output[2] = static_cast<std::uint8_t>(value >> 8U);
    output[3] = static_cast<std::uint8_t>(value);
}

constexpr std::array<std::uint32_t, 64> kSha256Round = {
    0x428a2f98U, 0x71374491U, 0xb5c0fbcfU, 0xe9b5dba5U,
    0x3956c25bU, 0x59f111f1U, 0x923f82a4U, 0xab1c5ed5U,
    0xd807aa98U, 0x12835b01U, 0x243185beU, 0x550c7dc3U,
    0x72be5d74U, 0x80deb1feU, 0x9bdc06a7U, 0xc19bf174U,
    0xe49b69c1U, 0xefbe4786U, 0x0fc19dc6U, 0x240ca1ccU,
    0x2de92c6fU, 0x4a7484aaU, 0x5cb0a9dcU, 0x76f988daU,
    0x983e5152U, 0xa831c66dU, 0xb00327c8U, 0xbf597fc7U,
    0xc6e00bf3U, 0xd5a79147U, 0x06ca6351U, 0x14292967U,
    0x27b70a85U, 0x2e1b2138U, 0x4d2c6dfcU, 0x53380d13U,
    0x650a7354U, 0x766a0abbU, 0x81c2c92eU, 0x92722c85U,
    0xa2bfe8a1U, 0xa81a664bU, 0xc24b8b70U, 0xc76c51a3U,
    0xd192e819U, 0xd6990624U, 0xf40e3585U, 0x106aa070U,
    0x19a4c116U, 0x1e376c08U, 0x2748774cU, 0x34b0bcb5U,
    0x391c0cb3U, 0x4ed8aa4aU, 0x5b9cca4fU, 0x682e6ff3U,
    0x748f82eeU, 0x78a5636fU, 0x84c87814U, 0x8cc70208U,
    0x90befffaU, 0xa4506cebU, 0xbef9a3f7U, 0xc67178f2U,
};

void sha256_transform(
    std::array<std::uint32_t, 8>& state,
    const std::uint8_t* block) noexcept {
    std::array<std::uint32_t, 64> words{};
    for (std::size_t i = 0U; i < 16U; ++i) {
        words[i] = load_be32(block + (i * 4U));
    }
    for (std::size_t i = 16U; i < words.size(); ++i) {
        const std::uint32_t s0 = rotate_right(words[i - 15U], 7U) ^
                                 rotate_right(words[i - 15U], 18U) ^
                                 (words[i - 15U] >> 3U);
        const std::uint32_t s1 = rotate_right(words[i - 2U], 17U) ^
                                 rotate_right(words[i - 2U], 19U) ^
                                 (words[i - 2U] >> 10U);
        words[i] = words[i - 16U] + s0 + words[i - 7U] + s1;
    }

    std::uint32_t a = state[0];
    std::uint32_t b = state[1];
    std::uint32_t c = state[2];
    std::uint32_t d = state[3];
    std::uint32_t e = state[4];
    std::uint32_t f = state[5];
    std::uint32_t g = state[6];
    std::uint32_t h = state[7];

    for (std::size_t i = 0U; i < words.size(); ++i) {
        const std::uint32_t sum1 = rotate_right(e, 6U) ^
                                   rotate_right(e, 11U) ^
                                   rotate_right(e, 25U);
        const std::uint32_t choose = (e & f) ^ ((~e) & g);
        const std::uint32_t temp1 = h + sum1 + choose + kSha256Round[i] + words[i];
        const std::uint32_t sum0 = rotate_right(a, 2U) ^
                                   rotate_right(a, 13U) ^
                                   rotate_right(a, 22U);
        const std::uint32_t majority = (a & b) ^ (a & c) ^ (b & c);
        const std::uint32_t temp2 = sum0 + majority;
        h = g;
        g = f;
        f = e;
        e = d + temp1;
        d = c;
        c = b;
        b = a;
        a = temp1 + temp2;
    }

    state[0] += a;
    state[1] += b;
    state[2] += c;
    state[3] += d;
    state[4] += e;
    state[5] += f;
    state[6] += g;
    state[7] += h;
}

[[nodiscard]] int hex_value(const char ch) noexcept {
    if (ch >= '0' && ch <= '9') {
        return ch - '0';
    }
    if (ch >= 'a' && ch <= 'f') {
        return ch - 'a' + 10;
    }
    return -1;
}

}  // namespace

Failure::Failure(std::string code, std::string detail)
    : std::runtime_error(std::move(detail)), code_(std::move(code)) {}

const std::string& Failure::code() const noexcept { return code_; }

[[noreturn]] void fail(const std::string_view code, const std::string_view detail) {
    throw Failure(std::string(code), std::string(detail));
}

Fd::Fd(const int fd) noexcept : fd_(fd) {}
Fd::~Fd() { reset(); }
Fd::Fd(Fd&& other) noexcept : fd_(other.release()) {}
Fd& Fd::operator=(Fd&& other) noexcept {
    if (this != &other) {
        reset(other.release());
    }
    return *this;
}
int Fd::get() const noexcept { return fd_; }
Fd::operator bool() const noexcept { return fd_ >= 0; }
int Fd::release() noexcept {
    const int value = fd_;
    fd_ = -1;
    return value;
}
void Fd::reset(const int fd) noexcept {
    if (fd_ >= 0) {
        const int ignored = ::close(fd_);
        (void)ignored;
    }
    fd_ = fd;
}

FileObservation observe_fd(const int fd, const std::string_view locator) {
    struct stat state {};
    if (::fstat(fd, &state) != 0) {
        fail("fstat-failed", errno_detail(locator, errno));
    }
    if (state.st_size < 0) {
        fail("negative-size", std::string(locator));
    }
    return FileObservation{
        .device = static_cast<std::uint64_t>(state.st_dev),
        .inode = static_cast<std::uint64_t>(state.st_ino),
        .size = static_cast<std::uint64_t>(state.st_size),
        .links = static_cast<std::uint64_t>(state.st_nlink),
        .mode = static_cast<std::uint32_t>(state.st_mode),
        .uid = static_cast<std::uint64_t>(state.st_uid),
        .gid = static_cast<std::uint64_t>(state.st_gid),
    };
}

bool same_file_observation(
    const FileObservation& left,
    const FileObservation& right) noexcept {
    return left.device == right.device &&
           left.inode == right.inode &&
           left.size == right.size &&
           left.links == right.links &&
           left.mode == right.mode &&
           left.uid == right.uid &&
           left.gid == right.gid;
}

Octets read_all_fd(
    const int fd,
    const std::uint64_t ceiling,
    const std::string_view locator) {
    const FileObservation observed = observe_fd(fd, locator);
    if ((observed.mode & static_cast<std::uint32_t>(S_IFMT)) !=
        static_cast<std::uint32_t>(S_IFREG)) {
        fail("not-regular-file", std::string(locator));
    }
    if (observed.size > ceiling) {
        fail("file-ceiling", std::string(locator));
    }
    const std::size_t size = checked_size(observed.size, locator, "file-size");
    Octets output(size);
    std::size_t offset = 0U;
    while (offset < output.size()) {
        const std::size_t remaining = output.size() - offset;
        const std::size_t request = std::min(
            remaining,
            static_cast<std::size_t>(SSIZE_MAX));
        const ssize_t count = ::pread(
            fd,
            output.data() + offset,
            request,
            static_cast<off_t>(offset));
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            fail("pread-failed", errno_detail(locator, errno));
        }
        if (count == 0) {
            fail("unexpected-eof", std::string(locator));
        }
        offset += static_cast<std::size_t>(count);
    }
    return output;
}

Octets read_file_at(
    const int directory_fd,
    const std::string_view leaf,
    const std::uint64_t ceiling,
    const std::string_view locator) {
    if (leaf.empty() || leaf.find('/') != std::string_view::npos ||
        leaf == "." || leaf == "..") {
        fail("invalid-leaf", std::string(locator));
    }
    const std::string path(leaf);
    Fd fd(::openat(directory_fd, path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW));
    if (!fd) {
        fail("open-file-failed", errno_detail(locator, errno));
    }
    return read_all_fd(fd.get(), ceiling, locator);
}

void write_all_fd(const int fd, const OctetView bytes, const std::string_view locator) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const std::size_t request = std::min(
            bytes.size() - offset,
            static_cast<std::size_t>(SSIZE_MAX));
        const ssize_t count = ::write(fd, bytes.data() + offset, request);
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            fail("write-failed", errno_detail(locator, errno));
        }
        if (count == 0) {
            fail("short-write", std::string(locator));
        }
        offset += static_cast<std::size_t>(count);
    }
}

void pwrite_all_fd(
    const int fd,
    const OctetView bytes,
    const std::uint64_t offset_value,
    const std::string_view locator) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const std::uint64_t position_u64 = offset_value + static_cast<std::uint64_t>(offset);
        if (position_u64 > static_cast<std::uint64_t>(std::numeric_limits<off_t>::max())) {
            fail("offset-overflow", std::string(locator));
        }
        const std::size_t request = std::min(
            bytes.size() - offset,
            static_cast<std::size_t>(SSIZE_MAX));
        const ssize_t count = ::pwrite(
            fd,
            bytes.data() + offset,
            request,
            static_cast<off_t>(position_u64));
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            fail("pwrite-failed", errno_detail(locator, errno));
        }
        if (count == 0) {
            fail("short-pwrite", std::string(locator));
        }
        offset += static_cast<std::size_t>(count);
    }
}

void fsync_fd(const int fd, const std::string_view locator) {
    if (::fsync(fd) != 0) {
        fail("fsync-failed", errno_detail(locator, errno));
    }
}

Fd open_self_readonly() {
    const int fd = ::open("/proc/self/exe", O_RDONLY | O_CLOEXEC);
    if (fd < 0) {
        fail("self-open-failed", errno_detail("/proc/self/exe", errno));
    }
    return Fd(fd);
}

OperationRoot open_operation_root(const std::string_view locator) {
    if (locator.empty()) {
        fail("operation-root-empty", "--operation-root");
    }
    if (locator.front() != '/') {
        fail("operation-root-not-absolute", std::string(locator));
    }
    if (locator.find('\0') != std::string_view::npos) {
        fail("operation-root-embedded-nul", "--operation-root");
    }

    const std::string requested(locator);
#ifdef DATACUBE_NEGATIVE_CONTROL_OPERATION_ROOT
    const std::string acquired(DATACUBE_NEGATIVE_CONTROL_OPERATION_ROOT);
#else
    const std::string acquired(requested);
#endif
    if (acquired.empty() || acquired.front() != '/') {
        fail("operation-root-internal-locator", acquired);
    }

    Fd fd(::open(
        acquired.c_str(),
        O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW));
    if (!fd) {
        fail("operation-root-open-failed", errno_detail(acquired, errno));
    }
    const FileObservation observed = observe_fd(fd.get(), acquired);
    if ((observed.mode & static_cast<std::uint32_t>(S_IFMT)) !=
        static_cast<std::uint32_t>(S_IFDIR)) {
        fail("operation-root-not-directory", acquired);
    }
    return OperationRoot{
        .fd = std::move(fd),
        .requested_locator = requested,
        .acquired_locator = acquired,
        .observation = observed,
    };
}

bool is_valid_relative_path(const std::string_view path) noexcept {
    if (path.empty() || path.front() == '/' || path.back() == '/') {
        return false;
    }
    std::size_t component_start = 0U;
    for (std::size_t index = 0U; index <= path.size(); ++index) {
        if (index == path.size() || path[index] == '/') {
            const std::string_view component = path.substr(
                component_start,
                index - component_start);
            if (component.empty() || component == "." || component == ".." ||
                component.size() > 255U) {
                return false;
            }
            for (const char ch : component) {
                const bool allowed = (ch >= 'A' && ch <= 'Z') ||
                                     (ch >= 'a' && ch <= 'z') ||
                                     (ch >= '0' && ch <= '9') ||
                                     ch == '.' || ch == '_' || ch == '-';
                if (!allowed) {
                    return false;
                }
            }
            component_start = index + 1U;
        }
    }
    return path.size() <= 1024U;
}

std::vector<std::string> split_relative_path(
    const std::string_view path,
    const std::string_view locator) {
    if (!is_valid_relative_path(path)) {
        fail("invalid-relative-path", std::string(locator));
    }
    std::vector<std::string> output;
    std::size_t start = 0U;
    while (start < path.size()) {
        const std::size_t slash = path.find('/', start);
        const std::size_t end = slash == std::string_view::npos ? path.size() : slash;
        output.emplace_back(path.substr(start, end - start));
        if (slash == std::string_view::npos) {
            break;
        }
        start = slash + 1U;
    }
    return output;
}

Fd open_relative_directory_beneath(
    const int root_fd,
    const std::string_view relative_path,
    const std::string_view locator) {
    const std::vector<std::string> components = split_relative_path(relative_path, locator);
    const int duplicated = ::fcntl(root_fd, F_DUPFD_CLOEXEC, 3);
    if (duplicated < 0) {
        fail("dup-root-failed", errno_detail(locator, errno));
    }
    Fd current(duplicated);
    for (const std::string& component : components) {
        const int next = ::openat(
            current.get(),
            component.c_str(),
            O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
        if (next < 0) {
            fail("open-relative-directory-failed", errno_detail(locator, errno));
        }
        current.reset(next);
    }
    return current;
}

bool leaf_exists_nofollow(
    const int directory_fd,
    const std::string_view leaf,
    struct stat* const observation) {
    if (leaf.empty() || leaf.find('/') != std::string_view::npos ||
        leaf == "." || leaf == "..") {
        fail("invalid-leaf", std::string(leaf));
    }
    struct stat state {};
    const std::string name(leaf);
    if (::fstatat(directory_fd, name.c_str(), &state, AT_SYMLINK_NOFOLLOW) == 0) {
        if (observation != nullptr) {
            *observation = state;
        }
        return true;
    }
    if (errno == ENOENT) {
        return false;
    }
    fail("fstatat-failed", errno_detail(leaf, errno));
}

void append_u8(Octets& out, const std::uint8_t value) { out.push_back(value); }
void append_be16(Octets& out, const std::uint16_t value) {
    out.push_back(static_cast<std::uint8_t>(value >> 8U));
    out.push_back(static_cast<std::uint8_t>(value));
}
void append_be32(Octets& out, const std::uint32_t value) {
    out.push_back(static_cast<std::uint8_t>(value >> 24U));
    out.push_back(static_cast<std::uint8_t>(value >> 16U));
    out.push_back(static_cast<std::uint8_t>(value >> 8U));
    out.push_back(static_cast<std::uint8_t>(value));
}
void append_be64(Octets& out, const std::uint64_t value) {
    for (unsigned int shift = 56U;; shift -= 8U) {
        out.push_back(static_cast<std::uint8_t>(value >> shift));
        if (shift == 0U) {
            break;
        }
    }
}
void append_octets(Octets& out, const OctetView value) {
    out.insert(out.end(), value.begin(), value.end());
}
void append_text(Octets& out, const std::string_view value) {
    for (const char ch : value) {
        out.push_back(static_cast<std::uint8_t>(static_cast<unsigned char>(ch)));
    }
}
void append_blob32(Octets& out, const OctetView value) {
    if (value.size() > static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max())) {
        fail("blob32-too-large", "append_blob32");
    }
    append_be32(out, static_cast<std::uint32_t>(value.size()));
    append_octets(out, value);
}
void append_blob64(Octets& out, const OctetView value) {
    append_be64(out, static_cast<std::uint64_t>(value.size()));
    append_octets(out, value);
}
void append_path16(Octets& out, const std::string_view value) {
    if (value.size() > static_cast<std::size_t>(std::numeric_limits<std::uint16_t>::max())) {
        fail("path16-too-large", "append_path16");
    }
    append_be16(out, static_cast<std::uint16_t>(value.size()));
    append_text(out, value);
}

Reader::Reader(OctetView bytes, std::string locator)
    : bytes_(bytes), locator_(std::move(locator)) {}
std::size_t Reader::offset() const noexcept { return offset_; }
std::size_t Reader::remaining() const noexcept { return bytes_.size() - offset_; }
bool Reader::eof() const noexcept { return offset_ == bytes_.size(); }
std::uint8_t Reader::read_u8(const std::string_view field) {
    return read_exact(1U, field)[0];
}
std::uint16_t Reader::read_be16(const std::string_view field) {
    const OctetView value = read_exact(2U, field);
    return static_cast<std::uint16_t>(
        (static_cast<std::uint16_t>(value[0]) << 8U) |
        static_cast<std::uint16_t>(value[1]));
}
std::uint32_t Reader::read_be32(const std::string_view field) {
    const OctetView value = read_exact(4U, field);
    return (static_cast<std::uint32_t>(value[0]) << 24U) |
           (static_cast<std::uint32_t>(value[1]) << 16U) |
           (static_cast<std::uint32_t>(value[2]) << 8U) |
           static_cast<std::uint32_t>(value[3]);
}
std::uint64_t Reader::read_be64(const std::string_view field) {
    const OctetView value = read_exact(8U, field);
    std::uint64_t output = 0U;
    for (const std::uint8_t octet : value) {
        output = (output << 8U) | static_cast<std::uint64_t>(octet);
    }
    return output;
}
OctetView Reader::read_exact(
    const std::uint64_t length,
    const std::string_view field) {
    const std::size_t count = checked_size(length, locator_, field);
    if (count > remaining()) {
        fail(
            "truncated-field",
            locator_ + "#" + std::string(field) + ": need " +
                std::to_string(count) + ", have " + std::to_string(remaining()));
    }
    const OctetView output = bytes_.subspan(offset_, count);
    offset_ += count;
    return output;
}
OctetView Reader::read_blob32(
    const std::uint64_t ceiling,
    const std::string_view field) {
    const std::uint32_t length = read_be32(std::string(field) + ".length");
    if (static_cast<std::uint64_t>(length) > ceiling) {
        fail("blob32-ceiling", locator_ + "#" + std::string(field));
    }
    return read_exact(length, field);
}
OctetView Reader::read_blob64(
    const std::uint64_t ceiling,
    const std::string_view field) {
    const std::uint64_t length = read_be64(std::string(field) + ".length");
    if (length > ceiling) {
        fail("blob64-ceiling", locator_ + "#" + std::string(field));
    }
    return read_exact(length, field);
}
std::string_view Reader::read_path16(
    const std::uint64_t ceiling,
    const std::string_view field) {
    const std::uint16_t length = read_be16(std::string(field) + ".length");
    if (static_cast<std::uint64_t>(length) > ceiling) {
        fail("path16-ceiling", locator_ + "#" + std::string(field));
    }
    const OctetView value = read_exact(length, field);
    return std::string_view(
        reinterpret_cast<const char*>(value.data()),
        value.size());
}
void Reader::require_eof(const std::string_view field) const {
    if (!eof()) {
        fail(
            "trailing-material",
            locator_ + "#" + std::string(field) + ": " +
                std::to_string(remaining()) + " bytes");
    }
}

Sha256State::Sha256State() noexcept
    : state_({
        0x6a09e667U, 0xbb67ae85U, 0x3c6ef372U, 0xa54ff53aU,
        0x510e527fU, 0x9b05688cU, 0x1f83d9abU, 0x5be0cd19U,
    }) {}

void Sha256State::update(const OctetView bytes) noexcept {
    if (bytes.empty()) {
        return;
    }
    total_bytes_ += static_cast<std::uint64_t>(bytes.size());
    std::size_t cursor = 0U;
    if (buffered_bytes_ != 0U) {
        const std::size_t available = buffered_.size() - buffered_bytes_;
        const std::size_t take = std::min(available, bytes.size());
        std::copy_n(bytes.begin(), take, buffered_.begin() +
            static_cast<std::ptrdiff_t>(buffered_bytes_));
        buffered_bytes_ += take;
        cursor += take;
        if (buffered_bytes_ == buffered_.size()) {
            sha256_transform(state_, buffered_.data());
            buffered_bytes_ = 0U;
        }
    }
    while (bytes.size() - cursor >= 64U) {
        sha256_transform(state_, bytes.data() + cursor);
        cursor += 64U;
    }
    const std::size_t remainder = bytes.size() - cursor;
    if (remainder != 0U) {
        std::copy_n(bytes.begin() + static_cast<std::ptrdiff_t>(cursor),
                    remainder, buffered_.begin());
        buffered_bytes_ = remainder;
    }
}

Digest32 Sha256State::finalize() const noexcept {
    std::array<std::uint32_t, 8> state = state_;
    std::array<std::uint8_t, 128> tail{};
    const std::size_t remainder = buffered_bytes_ & 63U;
    std::copy_n(buffered_.begin(), remainder, tail.begin());
    tail[remainder] = 0x80U;
    const std::size_t tail_bytes = remainder < 56U ? 64U : 128U;
    const std::uint64_t bit_length = total_bytes_ * 8U;
    for (std::size_t i = 0U; i < 8U; ++i) {
        tail[tail_bytes - 1U - i] = static_cast<std::uint8_t>(bit_length >> (i * 8U));
    }
    sha256_transform(state, tail.data());
    if (tail_bytes == 128U) {
        sha256_transform(state, tail.data() + 64U);
    }

    Digest32 output;
    for (std::size_t i = 0U; i < state.size(); ++i) {
        store_be32(output.octets.data() + (i * 4U), state[i]);
    }
    return output;
}

std::uint64_t Sha256State::byte_count() const noexcept { return total_bytes_; }

Digest32 sha256(const OctetView bytes) noexcept {
    Sha256State state;
    state.update(bytes);
    return state.finalize();
}

std::string hex_lower(const OctetView bytes) {
    static constexpr char digits[] = "0123456789abcdef";
    std::string output;
    output.reserve(bytes.size() * 2U);
    for (const std::uint8_t value : bytes) {
        output.push_back(digits[value >> 4U]);
        output.push_back(digits[value & 0x0fU]);
    }
    return output;
}
std::string hex_lower(const Digest32& digest) {
    return hex_lower(OctetView(digest.octets));
}
Digest32 parse_hex_digest32(
    const std::string_view text,
    const std::string_view locator) {
    if (text.size() != 64U) {
        fail("digest-length", std::string(locator));
    }
    Digest32 output;
    for (std::size_t i = 0U; i < output.octets.size(); ++i) {
        const int high = hex_value(text[i * 2U]);
        const int low = hex_value(text[(i * 2U) + 1U]);
        if (high < 0 || low < 0) {
            fail("digest-character", std::string(locator));
        }
        output.octets[i] = static_cast<std::uint8_t>((high << 4) | low);
    }
    return output;
}
Octets text_octets(const std::string_view text) {
    Octets output;
    output.reserve(text.size());
    append_text(output, text);
    return output;
}
std::string octets_text(
    const OctetView bytes,
    const std::string_view locator,
    const bool require_printable) {
    std::string output;
    output.reserve(bytes.size());
    for (const std::uint8_t value : bytes) {
        if (value == 0U || value == 13U ||
            (require_printable && value != 10U && (value < 32U || value > 126U))) {
            fail("invalid-text-octet", std::string(locator));
        }
        output.push_back(static_cast<char>(value));
    }
    return output;
}
std::string json_escape(const std::string_view text) {
    std::ostringstream out;
    // Never turn a stream-buffer allocation failure into truncated JSON.
    // Insertion rethrows the original exception when badbit is enabled.
    out.exceptions(std::ios::badbit | std::ios::failbit);
    for (const char raw : text) {
        const auto ch = static_cast<unsigned char>(raw);
        switch (ch) {
            case '"': out << "\\\""; break;
            case '\\': out << "\\\\"; break;
            case '\b': out << "\\b"; break;
            case '\f': out << "\\f"; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default:
                if (ch < 0x20U) {
                    out << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                        << static_cast<unsigned int>(ch) << std::dec;
                } else {
                    out << static_cast<char>(ch);
                }
        }
    }
    return out.str();
}
std::string errno_detail(
    const std::string_view operation,
    const int error_number) {
    return std::string(operation) + ": errno=" + std::to_string(error_number) +
           " (" + std::strerror(error_number) + ")";
}
std::uint64_t monotonic_nanoseconds() {
    const auto now = std::chrono::steady_clock::now().time_since_epoch();
    return static_cast<std::uint64_t>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(now).count());
}

}  // namespace datacube
