#include "datacube/natrav_peer_stream.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <string_view>
#include <vector>
#include <utility>

namespace datacube {
namespace {

[[nodiscard]] std::uint32_t decode_u32be_header(
    const OctetView header) noexcept {
    return (static_cast<std::uint32_t>(header[0]) << 24U) |
        (static_cast<std::uint32_t>(header[1]) << 16U) |
        (static_cast<std::uint32_t>(header[2]) << 8U) |
        static_cast<std::uint32_t>(header[3]);
}

}  // namespace

NATravPeerStreamDecoder::NATravPeerStreamDecoder(
    NATravPeerStreamDecoder&& other) noexcept {
    // Exchange the entire correlated state; the donor receives an explicit
    // inert state rather than a moved vector paired with stale frame scalars.
    terminal_ = true;
    terminal_status_ = NATravPeerStreamStatus::moved_from;
    swap(other);
}

NATravPeerStreamDecoder& NATravPeerStreamDecoder::operator=(
    NATravPeerStreamDecoder&& other) noexcept {
    if (this != &other) {
        NATravPeerStreamDecoder replacement(std::move(other));
        swap(replacement);
    }
    return *this;
}

NATravPeerStreamDecoder& NATravPeerStreamDecoder::operator=(
    const NATravPeerStreamDecoder& other) {
    if (this != &other) {
        // The temporary owns every potentially throwing copy. Once it exists,
        // commit and destruction cannot throw or partially replace metadata.
        NATravPeerStreamDecoder replacement(other);
        swap(replacement);
    }
    return *this;
}

void NATravPeerStreamDecoder::swap(NATravPeerStreamDecoder& other) noexcept {
    using std::swap;
    buffered_.swap(other.buffered_);
    swap(expected_payload_bytes_, other.expected_payload_bytes_);
    swap(expected_payload_known_, other.expected_payload_known_);
    swap(terminal_, other.terminal_);
    swap(terminal_status_, other.terminal_status_);
}

bool NATravPeerStreamDecoder::moved_from() const noexcept {
    return terminal_status_ == NATravPeerStreamStatus::moved_from;
}

NATravPeerStreamObservation NATravPeerStreamDecoder::observe(
    const NATravPeerStreamStatus status,
    const std::size_t emitted_frames) const noexcept {
    return NATravPeerStreamObservation{
        .status = status,
        .emitted_frames = emitted_frames,
        .buffered_bytes = buffered_.size(),
        .expected_payload_bytes =
            expected_payload_known_ ? expected_payload_bytes_ : 0U,
    };
}

NATravPeerStreamObservation NATravPeerStreamDecoder::feed(
    const OctetView chunk,
    std::vector<Octets>& emitted) {
    const std::size_t emitted_before = emitted.size();
    if (terminal_) {
        return observe(terminal_status_, 0U);
    }

    try {
        std::size_t offset = 0U;
        while (offset < chunk.size()) {
            if (!expected_payload_known_) {
                const std::size_t header_needed =
                    kNATravPeerFrameHeaderBytes - buffered_.size();
                const std::size_t header_take = std::min(
                    header_needed, chunk.size() - offset);
                buffered_.insert(
                    buffered_.end(),
                    chunk.begin() + static_cast<std::ptrdiff_t>(offset),
                    chunk.begin() + static_cast<std::ptrdiff_t>(offset + header_take));
                offset += header_take;
                if (buffered_.size() < kNATravPeerFrameHeaderBytes) {
                    break;
                }
                expected_payload_bytes_ = decode_u32be_header(
                    OctetView(buffered_.data(), kNATravPeerFrameHeaderBytes));
                expected_payload_known_ = true;
                if (expected_payload_bytes_ < kNATravPeerMinimumPayloadBytes ||
                    expected_payload_bytes_ > kNATravPeerMaximumPayloadBytes) {
                    terminal_ = true;
                    terminal_status_ = NATravPeerStreamStatus::malformed_frame;
                    return observe(
                        terminal_status_, emitted.size() - emitted_before);
                }
            }

            const std::size_t frame_bytes = kNATravPeerFrameHeaderBytes +
                static_cast<std::size_t>(expected_payload_bytes_);
            const std::size_t frame_needed = frame_bytes - buffered_.size();
            const std::size_t frame_take = std::min(
                frame_needed, chunk.size() - offset);
            buffered_.insert(
                buffered_.end(),
                chunk.begin() + static_cast<std::ptrdiff_t>(offset),
                chunk.begin() + static_cast<std::ptrdiff_t>(offset + frame_take));
            offset += frame_take;
            if (buffered_.size() < frame_bytes) {
                break;
            }

            emitted.emplace_back(
                buffered_.begin() +
                    static_cast<std::ptrdiff_t>(kNATravPeerFrameHeaderBytes),
                buffered_.end());
            buffered_.clear();
            expected_payload_bytes_ = 0U;
            expected_payload_known_ = false;
        }

        const std::size_t emitted_now = emitted.size() - emitted_before;
        return observe(
            emitted_now == 0U ? NATravPeerStreamStatus::need_more :
                                NATravPeerStreamStatus::frame_ready,
            emitted_now);
    } catch (...) {
        // Do not allocate, clear committed output, or replace the exception.
        // buffered_ may already hold a complete, not-yet-emitted frame.
        terminal_status_ = NATravPeerStreamStatus::operation_failed;
        terminal_ = true;
        throw;
    }
}

NATravPeerStreamObservation NATravPeerStreamDecoder::finish(
    std::vector<Octets>& emitted) noexcept {
    static_cast<void>(emitted);
    if (terminal_) {
        return observe(terminal_status_, 0U);
    }
    // Healthy feed emits every complete frame before returning. There is
    // nothing to drain on EOF, and a failed feed is caught by the terminal
    // guard above. EOF therefore requires neither output access nor allocation.
    terminal_ = true;
    terminal_status_ = buffered_.empty() ?
        NATravPeerStreamStatus::stream_closed :
        NATravPeerStreamStatus::peer_unavailable;
    return observe(terminal_status_, 0U);
}

bool NATravPeerStreamDecoder::operation_failed() const noexcept {
    return terminal_status_ == NATravPeerStreamStatus::operation_failed;
}

bool NATravPeerStreamDecoder::terminal() const noexcept {
    return terminal_;
}

std::size_t NATravPeerStreamDecoder::buffered_bytes() const noexcept {
    return buffered_.size();
}

std::uint32_t NATravPeerStreamDecoder::expected_payload_bytes() const noexcept {
    return expected_payload_known_ ? expected_payload_bytes_ : 0U;
}

Octets natrav_peer_encode_frame(const OctetView payload) {
    if (payload.size() <
            static_cast<std::size_t>(kNATravPeerMinimumPayloadBytes) ||
        payload.size() >
            static_cast<std::size_t>(kNATravPeerMaximumPayloadBytes)) {
        fail(
            "natrav-peer-frame-payload-size",
            "outside 2-through-65536-byte envelope");
    }
    Octets frame;
    frame.reserve(kNATravPeerFrameHeaderBytes + payload.size());
    append_be32(frame, static_cast<std::uint32_t>(payload.size()));
    append_octets(frame, payload);
    return frame;
}

std::string_view natrav_peer_stream_status_name(
    const NATravPeerStreamStatus status) noexcept {
    switch (status) {
        case NATravPeerStreamStatus::need_more: return "NEED_MORE";
        case NATravPeerStreamStatus::frame_ready: return "FRAME_READY";
        case NATravPeerStreamStatus::malformed_frame: return "MALFORMED_FRAME";
        case NATravPeerStreamStatus::stream_closed: return "STREAM_CLOSED";
        case NATravPeerStreamStatus::peer_unavailable: return "PEER_UNAVAILABLE";
        case NATravPeerStreamStatus::operation_failed: return "OPERATION_FAILED";
        case NATravPeerStreamStatus::moved_from: return "MOVED_FROM";
    }
    return "UNKNOWN";
}

}  // namespace datacube
