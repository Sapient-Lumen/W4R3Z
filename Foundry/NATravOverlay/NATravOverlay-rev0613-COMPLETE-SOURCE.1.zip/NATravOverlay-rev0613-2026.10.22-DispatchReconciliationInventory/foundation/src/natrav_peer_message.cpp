#include "datacube/natrav_peer_message.hpp"

#include "datacube/core.hpp"
#include "datacube/natrav_peer_stream.hpp"

#include <algorithm>
#include <array>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <map>
#include <memory>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <vector>

namespace datacube {
namespace {

struct JsonValue final {
    enum class Kind {
        null_value,
        boolean,
        integer,
        string,
        array,
        object,
    };

    Kind kind{Kind::null_value};
    bool boolean_value{false};
    std::int64_t integer_value{0};
    std::string string_value;
    std::vector<JsonValue> array_values;
    std::map<std::string, JsonValue, std::less<>> object_values;
};

// The wire schema itself never nests containers more than two levels deep.
// A 16,384-value tree budget still admits every schema-valid message in the
// 65,536-byte envelope: each capability value consumes at least four canonical
// payload bytes after the first, while the fixed HELLO/HELLO_ACK structure
// consumes substantially more than the remaining value-count margin.
constexpr std::size_t kNATravPeerMaximumJsonTreeDepth = 64U;
constexpr std::size_t kNATravPeerMaximumJsonConstructionUnits = 16384U;
constexpr std::size_t kNATravPeerMaximumJsonTreeValues =
    kNATravPeerMaximumJsonConstructionUnits;
// The common typed message carries only a handful of capabilities. Keep the
// first 64 retained spans inside the preflight object, then spill explicitly to
// bounded dynamic storage. Even the spill path remains capped by the existing
// 16,384-construction-unit profile.
constexpr std::size_t kNATravPeerInlineCapabilitySpanCapacity = 64U;
// Revision 0485 preserved the first 64-entry spill allocation, followed by
// eight uniform 2,032-entry tail chunks. Keep that schedule available to the
// inherited regression and as the exact historical oracle for revision 0486.
constexpr std::size_t kNATravPeerFirstCapabilitySpanChunkCapacity = 64U;
constexpr std::size_t kNATravPeerCapabilitySpanTailChunkCount = 8U;
constexpr std::size_t kNATravPeerCapabilitySpanTailChunkCapacity = 2032U;
constexpr std::size_t kNATravPeerRevision0485CapabilitySpanChunkCount =
    1U + kNATravPeerCapabilitySpanTailChunkCount;

// Production preserves revision 0486's bounded tier capacities but no longer
// embeds all twelve chunk owners in every decoder object. The first five owners
// cover the 64-, 128-, 256-, 512-, and 1,136-entry early chunks. A bounded
// seven-owner directory for the uniform 2,032-entry tail is materialized only
// after 2,160 total capability spans have been retained. The schedule never
// relocates an accepted span and still covers exactly 16,384 construction units.
constexpr std::array<std::size_t, 12U>
    kNATravPeerCapabilitySpanChunkCapacities{
        64U,
        128U,
        256U,
        512U,
        1136U,
        2032U,
        2032U,
        2032U,
        2032U,
        2032U,
        2032U,
        2032U,
    };
constexpr std::size_t kNATravPeerCapabilitySpanTierChunkCount = 4U;
constexpr std::size_t kNATravPeerCapabilitySpanUniformTailChunkCount = 7U;
constexpr std::size_t kNATravPeerCapabilitySpanEarlyOwnerCount = 5U;
constexpr std::size_t kNATravPeerCapabilitySpanLazyTailOwnerCount =
    kNATravPeerCapabilitySpanUniformTailChunkCount;
constexpr std::size_t kNATravPeerTieredCapabilitySpanChunkCount =
    kNATravPeerCapabilitySpanChunkCapacities.size();
constexpr std::size_t kNATravPeerTieredCapabilitySpanCapacity = []() {
    std::size_t total = 0U;
    for (const std::size_t capacity :
         kNATravPeerCapabilitySpanChunkCapacities) {
        total += capacity;
    }
    return total;
}();
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST)
constexpr std::size_t kNATravPeerCapabilitySpanChunkCount =
    kNATravPeerRevision0485CapabilitySpanChunkCount;
#else
constexpr std::size_t kNATravPeerCapabilitySpanChunkCount =
    kNATravPeerTieredCapabilitySpanChunkCount;
#endif
static_assert(
    kNATravPeerInlineCapabilitySpanCapacity <
    kNATravPeerMaximumJsonConstructionUnits);
static_assert(
    kNATravPeerFirstCapabilitySpanChunkCapacity +
        kNATravPeerCapabilitySpanTailChunkCount *
            kNATravPeerCapabilitySpanTailChunkCapacity ==
    kNATravPeerMaximumJsonConstructionUnits -
        kNATravPeerInlineCapabilitySpanCapacity);
static_assert(
    1U + kNATravPeerCapabilitySpanTierChunkCount +
        kNATravPeerCapabilitySpanUniformTailChunkCount ==
    kNATravPeerTieredCapabilitySpanChunkCount);
static_assert(
    kNATravPeerCapabilitySpanEarlyOwnerCount +
        kNATravPeerCapabilitySpanLazyTailOwnerCount ==
    kNATravPeerTieredCapabilitySpanChunkCount);
static_assert(
    kNATravPeerTieredCapabilitySpanCapacity ==
    kNATravPeerMaximumJsonConstructionUnits -
        kNATravPeerInlineCapabilitySpanCapacity);

#if defined(DATACUBE_NATRAV_MESSAGE_CANONICAL_STRING_CODEC_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_PROJECTION_STRING_DECODER_TEST)
struct CanonicalJsonStringCodecCounters final {
    std::size_t raw_scalar_decode_calls{0U};
    std::size_t canonical_fragment_calls{0U};
    std::size_t json_scalar_parse_calls{0U};
    std::size_t encoder_string_calls{0U};
};

thread_local CanonicalJsonStringCodecCounters canonical_string_codec_counters;

void reset_canonical_string_codec_counters() noexcept {
    canonical_string_codec_counters = {};
}

[[nodiscard]] CanonicalJsonStringCodecCounters
read_canonical_string_codec_counters() noexcept {
    return canonical_string_codec_counters;
}

void note_raw_scalar_decode() noexcept {
    ++canonical_string_codec_counters.raw_scalar_decode_calls;
}
void note_canonical_fragment() noexcept {
    ++canonical_string_codec_counters.canonical_fragment_calls;
}
void note_json_scalar_parse() noexcept {
    ++canonical_string_codec_counters.json_scalar_parse_calls;
}
void note_encoder_string() noexcept {
    ++canonical_string_codec_counters.encoder_string_calls;
}
#else
void note_raw_scalar_decode() noexcept {}
void note_canonical_fragment() noexcept {}
void note_json_scalar_parse() noexcept {}
void note_encoder_string() noexcept {}
#endif

#if defined(DATACUBE_NATRAV_MESSAGE_CANONICAL_INTEGER_CODEC_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_PREFLIGHT_INTEGER_RETENTION_TEST)
struct CanonicalJsonIntegerCodecCounters final {
    std::size_t canonical_fragment_calls{0U};
    std::size_t json_integer_parse_calls{0U};
    std::size_t encoder_integer_calls{0U};
    std::size_t preflight_protocol_integer_captures{0U};
    std::size_t retained_protocol_integer_reads{0U};
};

thread_local CanonicalJsonIntegerCodecCounters canonical_integer_codec_counters;

void reset_canonical_integer_codec_counters() noexcept {
    canonical_integer_codec_counters = {};
}

[[nodiscard]] CanonicalJsonIntegerCodecCounters
read_canonical_integer_codec_counters() noexcept {
    return canonical_integer_codec_counters;
}

void note_canonical_integer_fragment() noexcept {
    ++canonical_integer_codec_counters.canonical_fragment_calls;
}
void note_json_integer_parse() noexcept {
    ++canonical_integer_codec_counters.json_integer_parse_calls;
}
void note_encoder_integer() noexcept {
    ++canonical_integer_codec_counters.encoder_integer_calls;
}
void note_preflight_protocol_integer_capture() noexcept {
    ++canonical_integer_codec_counters.preflight_protocol_integer_captures;
}
void note_retained_protocol_integer_read() noexcept {
    ++canonical_integer_codec_counters.retained_protocol_integer_reads;
}
#else
void note_canonical_integer_fragment() noexcept {}
void note_json_integer_parse() noexcept {}
void note_encoder_integer() noexcept {}
void note_preflight_protocol_integer_capture() noexcept {}
void note_retained_protocol_integer_read() noexcept {}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_PREFLIGHT_STRING_LENGTH_RETENTION_TEST
struct CanonicalJsonStringLengthRetentionCounters final {
    std::size_t preflight_typed_string_length_captures{0U};
    std::size_t retained_string_length_reads{0U};
    std::size_t retained_string_reserve_bytes{0U};
    std::size_t historical_string_length_reads{0U};
    std::size_t historical_string_reserve_bytes{0U};
};

thread_local CanonicalJsonStringLengthRetentionCounters
    canonical_string_length_retention_counters;

void reset_canonical_string_length_retention_counters() noexcept {
    canonical_string_length_retention_counters = {};
}

[[nodiscard]] CanonicalJsonStringLengthRetentionCounters
read_canonical_string_length_retention_counters() noexcept {
    return canonical_string_length_retention_counters;
}

void note_preflight_typed_string_length_capture() noexcept {
    ++canonical_string_length_retention_counters
        .preflight_typed_string_length_captures;
}
void note_retained_string_length_read(const std::size_t bytes) noexcept {
    ++canonical_string_length_retention_counters.retained_string_length_reads;
    canonical_string_length_retention_counters.retained_string_reserve_bytes +=
        bytes;
}
void note_historical_string_length_read(const std::size_t bytes) noexcept {
    ++canonical_string_length_retention_counters.historical_string_length_reads;
    canonical_string_length_retention_counters
        .historical_string_reserve_bytes += bytes;
}
#else
void note_preflight_typed_string_length_capture() noexcept {}
void note_retained_string_length_read(const std::size_t) noexcept {}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_RETENTION_TEST
struct CanonicalCapabilitySpanRetentionCounters final {
    std::size_t preflight_span_captures{0U};
    std::size_t retained_projection_reads{0U};
    std::size_t historical_array_reparse_entries{0U};
};

thread_local CanonicalCapabilitySpanRetentionCounters
    canonical_capability_span_retention_counters;

void reset_canonical_capability_span_retention_counters() noexcept {
    canonical_capability_span_retention_counters = {};
}

[[nodiscard]] CanonicalCapabilitySpanRetentionCounters
read_canonical_capability_span_retention_counters() noexcept {
    return canonical_capability_span_retention_counters;
}

void note_preflight_capability_span_capture() noexcept {
    ++canonical_capability_span_retention_counters.preflight_span_captures;
}
void note_retained_capability_span_read() noexcept {
    ++canonical_capability_span_retention_counters.retained_projection_reads;
}
void note_historical_capability_array_reparse_entry() noexcept {
    ++canonical_capability_span_retention_counters
        .historical_array_reparse_entries;
}
#else
void note_preflight_capability_span_capture() noexcept {}
void note_retained_capability_span_read() noexcept {}
void note_historical_capability_array_reparse_entry() noexcept {}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_READINESS_RETENTION_TEST
struct CanonicalCapabilityReadinessRetentionCounters final {
    std::size_t preflight_available_readiness_captures{0U};
    std::size_t preflight_required_readiness_captures{0U};
    std::size_t retained_projection_readiness_reads{0U};
    std::size_t retained_construction_readiness_reads{0U};
    std::size_t historical_projection_array_presence_checks{0U};
    std::size_t historical_projection_validity_checks{0U};
    std::size_t historical_projection_span_completeness_checks{0U};
    std::size_t historical_projection_count_consistency_checks{0U};
    std::size_t historical_construction_array_presence_checks{0U};
    std::size_t historical_construction_validity_checks{0U};
    std::size_t historical_construction_span_completeness_checks{0U};
    std::size_t historical_construction_count_consistency_checks{0U};
};

thread_local CanonicalCapabilityReadinessRetentionCounters
    canonical_capability_readiness_retention_counters;

void reset_canonical_capability_readiness_retention_counters() noexcept {
    canonical_capability_readiness_retention_counters = {};
}

[[nodiscard]] CanonicalCapabilityReadinessRetentionCounters
read_canonical_capability_readiness_retention_counters() noexcept {
    return canonical_capability_readiness_retention_counters;
}

void note_preflight_capability_readiness_capture(
    const bool available) noexcept {
    if (available) {
        ++canonical_capability_readiness_retention_counters
            .preflight_available_readiness_captures;
    } else {
        ++canonical_capability_readiness_retention_counters
            .preflight_required_readiness_captures;
    }
}
void note_retained_capability_projection_readiness() noexcept {
    ++canonical_capability_readiness_retention_counters
        .retained_projection_readiness_reads;
}
void note_retained_capability_construction_readiness() noexcept {
    ++canonical_capability_readiness_retention_counters
        .retained_construction_readiness_reads;
}
void note_historical_capability_projection_checks() noexcept {
    ++canonical_capability_readiness_retention_counters
        .historical_projection_array_presence_checks;
    ++canonical_capability_readiness_retention_counters
        .historical_projection_validity_checks;
    ++canonical_capability_readiness_retention_counters
        .historical_projection_span_completeness_checks;
    ++canonical_capability_readiness_retention_counters
        .historical_projection_count_consistency_checks;
}
void note_historical_capability_construction_checks() noexcept {
    ++canonical_capability_readiness_retention_counters
        .historical_construction_array_presence_checks;
    ++canonical_capability_readiness_retention_counters
        .historical_construction_validity_checks;
    ++canonical_capability_readiness_retention_counters
        .historical_construction_span_completeness_checks;
    ++canonical_capability_readiness_retention_counters
        .historical_construction_count_consistency_checks;
}
#else
void note_preflight_capability_readiness_capture(const bool) noexcept {}
void note_retained_capability_projection_readiness() noexcept {}
void note_retained_capability_construction_readiness() noexcept {}
void note_historical_capability_projection_checks() noexcept {}
void note_historical_capability_construction_checks() noexcept {}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_STORAGE_TEST
struct CanonicalCapabilitySpanStorageCounters final {
    std::size_t storage_instances{0U};
    std::size_t inline_appends{0U};
    std::size_t spill_appends{0U};
    std::size_t spill_activations{0U};
    std::size_t spill_reservations{0U};
    std::size_t spill_reserved_capacity{0U};
    std::size_t maximum_spill_capacity{0U};
    std::size_t inline_reads{0U};
    std::size_t spill_reads{0U};
    std::size_t historical_appends{0U};
    std::size_t historical_reads{0U};
};

thread_local CanonicalCapabilitySpanStorageCounters
    canonical_capability_span_storage_counters;

void reset_canonical_capability_span_storage_counters() noexcept {
    canonical_capability_span_storage_counters = {};
}

[[nodiscard]] CanonicalCapabilitySpanStorageCounters
read_canonical_capability_span_storage_counters() noexcept {
    return canonical_capability_span_storage_counters;
}

void note_capability_span_storage_instance() noexcept {
    ++canonical_capability_span_storage_counters.storage_instances;
}
void note_capability_span_inline_append() noexcept {
    ++canonical_capability_span_storage_counters.inline_appends;
}
void note_capability_span_spill_append() noexcept {
    ++canonical_capability_span_storage_counters.spill_appends;
}
void note_capability_span_spill_activation() noexcept {
    ++canonical_capability_span_storage_counters.spill_activations;
}
void note_capability_span_spill_reservation(
    const std::size_t capacity) noexcept {
    ++canonical_capability_span_storage_counters.spill_reservations;
    canonical_capability_span_storage_counters.spill_reserved_capacity +=
        capacity;
    canonical_capability_span_storage_counters.maximum_spill_capacity =
        std::max(
            canonical_capability_span_storage_counters
                .maximum_spill_capacity,
            capacity);
}
void note_capability_span_inline_read() noexcept {
    ++canonical_capability_span_storage_counters.inline_reads;
}
void note_capability_span_spill_read() noexcept {
    ++canonical_capability_span_storage_counters.spill_reads;
}
void note_historical_capability_span_append() noexcept {
    ++canonical_capability_span_storage_counters.historical_appends;
}
void note_historical_capability_span_read() noexcept {
    ++canonical_capability_span_storage_counters.historical_reads;
}
#else
[[maybe_unused]] void note_capability_span_storage_instance() noexcept {}
[[maybe_unused]] void note_capability_span_inline_append() noexcept {}
[[maybe_unused]] void note_capability_span_spill_append() noexcept {}
[[maybe_unused]] void note_capability_span_spill_activation() noexcept {}
[[maybe_unused]] void note_capability_span_spill_reservation(const std::size_t) noexcept {}
[[maybe_unused]] void note_capability_span_inline_read() noexcept {}
[[maybe_unused]] void note_capability_span_spill_read() noexcept {}
[[maybe_unused]] void note_historical_capability_span_append() noexcept {}
[[maybe_unused]] void note_historical_capability_span_read() noexcept {}
#endif

#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_FUSED_TAIL_TEST)
struct CanonicalCapabilitySpanChunkStorageCounters final {
    std::size_t storage_instances{0U};
    std::size_t inline_appends{0U};
    std::size_t spill_appends{0U};
    std::size_t spill_activations{0U};
    std::size_t spill_reservations{0U};
    std::size_t spill_reserved_capacity{0U};
    std::size_t maximum_spill_capacity{0U};
    std::size_t inline_reads{0U};
    std::size_t spill_reads{0U};
    std::size_t tail_directory_allocations{0U};
    std::size_t current_relocated_spans{0U};
    std::size_t historical_appends{0U};
    std::size_t historical_reads{0U};
    std::size_t historical_reservations{0U};
    std::size_t historical_reserved_capacity{0U};
    std::size_t historical_maximum_capacity{0U};
    std::size_t historical_relocated_spans{0U};
};

thread_local CanonicalCapabilitySpanChunkStorageCounters
    canonical_capability_span_chunk_storage_counters;

void reset_canonical_capability_span_chunk_storage_counters() noexcept {
    canonical_capability_span_chunk_storage_counters = {};
}

[[nodiscard]] CanonicalCapabilitySpanChunkStorageCounters
read_canonical_capability_span_chunk_storage_counters() noexcept {
    return canonical_capability_span_chunk_storage_counters;
}

void note_current_capability_span_storage_instance() noexcept {
    ++canonical_capability_span_chunk_storage_counters.storage_instances;
}
void note_current_capability_span_inline_append() noexcept {
    ++canonical_capability_span_chunk_storage_counters.inline_appends;
}
void note_current_capability_span_chunk_append() noexcept {
    ++canonical_capability_span_chunk_storage_counters.spill_appends;
}
void note_current_capability_span_chunk_activation() noexcept {
    ++canonical_capability_span_chunk_storage_counters.spill_activations;
}
void note_current_capability_span_chunk_allocation(
    const std::size_t capacity) noexcept {
    ++canonical_capability_span_chunk_storage_counters.spill_reservations;
    canonical_capability_span_chunk_storage_counters
        .spill_reserved_capacity += capacity;
    canonical_capability_span_chunk_storage_counters
        .maximum_spill_capacity =
        std::max(
            canonical_capability_span_chunk_storage_counters
                .maximum_spill_capacity,
            capacity);
}
void note_current_capability_span_inline_read() noexcept {
    ++canonical_capability_span_chunk_storage_counters.inline_reads;
}
void note_current_capability_span_chunk_read() noexcept {
    ++canonical_capability_span_chunk_storage_counters.spill_reads;
}
[[maybe_unused]] void note_current_capability_span_tail_directory_allocation() noexcept {
    ++canonical_capability_span_chunk_storage_counters
        .tail_directory_allocations;
}
[[maybe_unused]] void note_historical_capability_span_storage_instance() noexcept {
    ++canonical_capability_span_chunk_storage_counters.storage_instances;
}
[[maybe_unused]] void note_historical_chunk_storage_append() noexcept {
    ++canonical_capability_span_chunk_storage_counters.historical_appends;
}
[[maybe_unused]] void note_historical_chunk_storage_read() noexcept {
    ++canonical_capability_span_chunk_storage_counters.historical_reads;
}
[[maybe_unused]] void note_historical_chunk_storage_reservation(
    const std::size_t capacity,
    const std::size_t relocated_spans) noexcept {
    ++canonical_capability_span_chunk_storage_counters
        .historical_reservations;
    canonical_capability_span_chunk_storage_counters
        .historical_reserved_capacity += capacity;
    canonical_capability_span_chunk_storage_counters
        .historical_maximum_capacity =
        std::max(
            canonical_capability_span_chunk_storage_counters
                .historical_maximum_capacity,
            capacity);
    canonical_capability_span_chunk_storage_counters
        .historical_relocated_spans += relocated_spans;
}
#else
[[maybe_unused]] void note_current_capability_span_storage_instance() noexcept {}
[[maybe_unused]] void note_current_capability_span_inline_append() noexcept {}
[[maybe_unused]] void note_current_capability_span_chunk_append() noexcept {}
[[maybe_unused]] void note_current_capability_span_chunk_activation() noexcept {}
[[maybe_unused]] void note_current_capability_span_chunk_allocation(
    const std::size_t) noexcept {}
[[maybe_unused]] void note_current_capability_span_inline_read() noexcept {}
[[maybe_unused]] void note_current_capability_span_chunk_read() noexcept {}
[[maybe_unused]] void note_current_capability_span_tail_directory_allocation() noexcept {}
[[maybe_unused]] void note_historical_capability_span_storage_instance() noexcept {}
[[maybe_unused]] void note_historical_chunk_storage_append() noexcept {}
[[maybe_unused]] void note_historical_chunk_storage_read() noexcept {}
[[maybe_unused]] void note_historical_chunk_storage_reservation(
    const std::size_t,
    const std::size_t) noexcept {}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_FIXED_ASCII_PREDICATE_RETENTION_TEST
struct CanonicalFixedAsciiPredicateRetentionCounters final {
    std::size_t preflight_request_id_captures{0U};
    std::size_t preflight_artifact_sha256_captures{0U};
    std::size_t preflight_peer_error_code_captures{0U};
    std::size_t retained_request_id_reads{0U};
    std::size_t retained_artifact_sha256_reads{0U};
    std::size_t retained_peer_error_code_reads{0U};
    std::size_t historical_request_id_rescans{0U};
    std::size_t historical_artifact_sha256_rescans{0U};
    std::size_t historical_peer_error_code_rescans{0U};
};

thread_local CanonicalFixedAsciiPredicateRetentionCounters
    canonical_fixed_ascii_predicate_retention_counters;

void reset_canonical_fixed_ascii_predicate_retention_counters() noexcept {
    canonical_fixed_ascii_predicate_retention_counters = {};
}

[[nodiscard]] CanonicalFixedAsciiPredicateRetentionCounters
read_canonical_fixed_ascii_predicate_retention_counters() noexcept {
    return canonical_fixed_ascii_predicate_retention_counters;
}

void note_preflight_request_id_predicate_capture() noexcept {
    ++canonical_fixed_ascii_predicate_retention_counters
        .preflight_request_id_captures;
}
void note_preflight_artifact_sha256_predicate_capture() noexcept {
    ++canonical_fixed_ascii_predicate_retention_counters
        .preflight_artifact_sha256_captures;
}
void note_preflight_peer_error_code_predicate_capture() noexcept {
    ++canonical_fixed_ascii_predicate_retention_counters
        .preflight_peer_error_code_captures;
}
void note_retained_request_id_predicate_read() noexcept {
    ++canonical_fixed_ascii_predicate_retention_counters
        .retained_request_id_reads;
}
void note_retained_artifact_sha256_predicate_read() noexcept {
    ++canonical_fixed_ascii_predicate_retention_counters
        .retained_artifact_sha256_reads;
}
void note_retained_peer_error_code_predicate_read() noexcept {
    ++canonical_fixed_ascii_predicate_retention_counters
        .retained_peer_error_code_reads;
}
void note_historical_request_id_predicate_rescan() noexcept {
    ++canonical_fixed_ascii_predicate_retention_counters
        .historical_request_id_rescans;
}
void note_historical_artifact_sha256_predicate_rescan() noexcept {
    ++canonical_fixed_ascii_predicate_retention_counters
        .historical_artifact_sha256_rescans;
}
void note_historical_peer_error_code_predicate_rescan() noexcept {
    ++canonical_fixed_ascii_predicate_retention_counters
        .historical_peer_error_code_rescans;
}
#else
void note_preflight_request_id_predicate_capture() noexcept {}
void note_preflight_artifact_sha256_predicate_capture() noexcept {}
void note_preflight_peer_error_code_predicate_capture() noexcept {}
void note_retained_request_id_predicate_read() noexcept {}
void note_retained_artifact_sha256_predicate_read() noexcept {}
void note_retained_peer_error_code_predicate_read() noexcept {}
void note_historical_request_id_predicate_rescan() noexcept {}
void note_historical_artifact_sha256_predicate_rescan() noexcept {}
void note_historical_peer_error_code_predicate_rescan() noexcept {}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_STRING_DISCRIMINANT_RETENTION_TEST
struct CanonicalStringDiscriminantRetentionCounters final {
    std::size_t preflight_message_kind_captures{0U};
    std::size_t preflight_protocol_id_captures{0U};
    std::size_t retained_message_kind_reads{0U};
    std::size_t retained_protocol_id_reads{0U};
    std::size_t historical_message_kind_rescans{0U};
    std::size_t historical_protocol_id_rescans{0U};
    std::size_t historical_message_kind_rescan_bytes{0U};
    std::size_t historical_protocol_id_rescan_bytes{0U};
};

thread_local CanonicalStringDiscriminantRetentionCounters
    canonical_string_discriminant_retention_counters;

void reset_canonical_string_discriminant_retention_counters() noexcept {
    canonical_string_discriminant_retention_counters = {};
}

[[nodiscard]] CanonicalStringDiscriminantRetentionCounters
read_canonical_string_discriminant_retention_counters() noexcept {
    return canonical_string_discriminant_retention_counters;
}

void note_preflight_message_kind_discriminant_capture() noexcept {
    ++canonical_string_discriminant_retention_counters
        .preflight_message_kind_captures;
}
void note_preflight_protocol_id_discriminant_capture() noexcept {
    ++canonical_string_discriminant_retention_counters
        .preflight_protocol_id_captures;
}
void note_retained_message_kind_discriminant_read() noexcept {
    ++canonical_string_discriminant_retention_counters
        .retained_message_kind_reads;
}
void note_retained_protocol_id_discriminant_read() noexcept {
    ++canonical_string_discriminant_retention_counters
        .retained_protocol_id_reads;
}
void note_historical_message_kind_discriminant_rescan(
    const std::size_t bytes) noexcept {
    ++canonical_string_discriminant_retention_counters
        .historical_message_kind_rescans;
    canonical_string_discriminant_retention_counters
        .historical_message_kind_rescan_bytes += bytes;
}
void note_historical_protocol_id_discriminant_rescan(
    const std::size_t bytes) noexcept {
    ++canonical_string_discriminant_retention_counters
        .historical_protocol_id_rescans;
    canonical_string_discriminant_retention_counters
        .historical_protocol_id_rescan_bytes += bytes;
}
#else
void note_preflight_message_kind_discriminant_capture() noexcept {}
void note_preflight_protocol_id_discriminant_capture() noexcept {}
void note_retained_message_kind_discriminant_read() noexcept {}
void note_retained_protocol_id_discriminant_read() noexcept {}
void note_historical_message_kind_discriminant_rescan(
    const std::size_t) noexcept {}
void note_historical_protocol_id_discriminant_rescan(
    const std::size_t) noexcept {}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_NONEMPTY_STRING_PREDICATE_RETENTION_TEST
struct CanonicalNonemptyStringPredicateRetentionCounters final {
    std::size_t preflight_artifact_target_captures{0U};
    std::size_t preflight_artifact_version_captures{0U};
    std::size_t preflight_peer_error_message_captures{0U};
    std::size_t retained_artifact_target_reads{0U};
    std::size_t retained_artifact_version_reads{0U};
    std::size_t retained_peer_error_message_reads{0U};
    std::size_t historical_artifact_target_token_size_checks{0U};
    std::size_t historical_artifact_version_token_size_checks{0U};
    std::size_t historical_peer_error_message_token_size_checks{0U};
};

thread_local CanonicalNonemptyStringPredicateRetentionCounters
    canonical_nonempty_string_predicate_retention_counters;

void reset_canonical_nonempty_string_predicate_retention_counters() noexcept {
    canonical_nonempty_string_predicate_retention_counters = {};
}

[[nodiscard]] CanonicalNonemptyStringPredicateRetentionCounters
read_canonical_nonempty_string_predicate_retention_counters() noexcept {
    return canonical_nonempty_string_predicate_retention_counters;
}

void note_preflight_artifact_target_nonempty_capture() noexcept {
    ++canonical_nonempty_string_predicate_retention_counters
        .preflight_artifact_target_captures;
}
void note_preflight_artifact_version_nonempty_capture() noexcept {
    ++canonical_nonempty_string_predicate_retention_counters
        .preflight_artifact_version_captures;
}
void note_preflight_peer_error_message_nonempty_capture() noexcept {
    ++canonical_nonempty_string_predicate_retention_counters
        .preflight_peer_error_message_captures;
}
void note_retained_artifact_target_nonempty_read() noexcept {
    ++canonical_nonempty_string_predicate_retention_counters
        .retained_artifact_target_reads;
}
void note_retained_artifact_version_nonempty_read() noexcept {
    ++canonical_nonempty_string_predicate_retention_counters
        .retained_artifact_version_reads;
}
void note_retained_peer_error_message_nonempty_read() noexcept {
    ++canonical_nonempty_string_predicate_retention_counters
        .retained_peer_error_message_reads;
}
void note_historical_artifact_target_token_size_check() noexcept {
    ++canonical_nonempty_string_predicate_retention_counters
        .historical_artifact_target_token_size_checks;
}
void note_historical_artifact_version_token_size_check() noexcept {
    ++canonical_nonempty_string_predicate_retention_counters
        .historical_artifact_version_token_size_checks;
}
void note_historical_peer_error_message_token_size_check() noexcept {
    ++canonical_nonempty_string_predicate_retention_counters
        .historical_peer_error_message_token_size_checks;
}
#else
void note_preflight_artifact_target_nonempty_capture() noexcept {}
void note_preflight_artifact_version_nonempty_capture() noexcept {}
void note_preflight_peer_error_message_nonempty_capture() noexcept {}
void note_retained_artifact_target_nonempty_read() noexcept {}
void note_retained_artifact_version_nonempty_read() noexcept {}
void note_retained_peer_error_message_nonempty_read() noexcept {}
void note_historical_artifact_target_token_size_check() noexcept {}
void note_historical_artifact_version_token_size_check() noexcept {}
void note_historical_peer_error_message_token_size_check() noexcept {}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_SHAPE_MASK_RETENTION_TEST
struct CanonicalShapeMaskRetentionCounters final {
    std::size_t preflight_top_level_member_updates{0U};
    std::size_t preflight_protocol_member_updates{0U};
    std::size_t preflight_artifact_member_updates{0U};
    std::size_t preflight_top_level_kind_updates{0U};
    std::size_t preflight_protocol_kind_updates{0U};
    std::size_t preflight_artifact_kind_updates{0U};
    std::size_t retained_top_level_member_reads{0U};
    std::size_t retained_top_level_kind_reads{0U};
    std::size_t retained_protocol_shape_reads{0U};
    std::size_t retained_artifact_shape_reads{0U};
    std::size_t historical_top_level_member_checks{0U};
    std::size_t historical_top_level_kind_checks{0U};
    std::size_t historical_protocol_member_checks{0U};
    std::size_t historical_protocol_kind_checks{0U};
    std::size_t historical_artifact_member_checks{0U};
    std::size_t historical_artifact_kind_checks{0U};
};

thread_local CanonicalShapeMaskRetentionCounters
    canonical_shape_mask_retention_counters;

void reset_canonical_shape_mask_retention_counters() noexcept {
    canonical_shape_mask_retention_counters = {};
}

[[nodiscard]] CanonicalShapeMaskRetentionCounters
read_canonical_shape_mask_retention_counters() noexcept {
    return canonical_shape_mask_retention_counters;
}

void note_preflight_top_level_member_update() noexcept {
    ++canonical_shape_mask_retention_counters
        .preflight_top_level_member_updates;
}
void note_preflight_protocol_member_update() noexcept {
    ++canonical_shape_mask_retention_counters
        .preflight_protocol_member_updates;
}
void note_preflight_artifact_member_update() noexcept {
    ++canonical_shape_mask_retention_counters
        .preflight_artifact_member_updates;
}
void note_preflight_top_level_kind_update() noexcept {
    ++canonical_shape_mask_retention_counters
        .preflight_top_level_kind_updates;
}
void note_preflight_protocol_kind_update() noexcept {
    ++canonical_shape_mask_retention_counters
        .preflight_protocol_kind_updates;
}
void note_preflight_artifact_kind_update() noexcept {
    ++canonical_shape_mask_retention_counters
        .preflight_artifact_kind_updates;
}
void note_retained_top_level_member_read() noexcept {
    ++canonical_shape_mask_retention_counters
        .retained_top_level_member_reads;
}
void note_retained_top_level_kind_read() noexcept {
    ++canonical_shape_mask_retention_counters
        .retained_top_level_kind_reads;
}
void note_retained_protocol_shape_read() noexcept {
    ++canonical_shape_mask_retention_counters.retained_protocol_shape_reads;
}
void note_retained_artifact_shape_read() noexcept {
    ++canonical_shape_mask_retention_counters.retained_artifact_shape_reads;
}
void note_historical_top_level_member_check() noexcept {
    ++canonical_shape_mask_retention_counters
        .historical_top_level_member_checks;
}
void note_historical_top_level_kind_check() noexcept {
    ++canonical_shape_mask_retention_counters
        .historical_top_level_kind_checks;
}
void note_historical_protocol_member_check() noexcept {
    ++canonical_shape_mask_retention_counters
        .historical_protocol_member_checks;
}
void note_historical_protocol_kind_check() noexcept {
    ++canonical_shape_mask_retention_counters
        .historical_protocol_kind_checks;
}
void note_historical_artifact_member_check() noexcept {
    ++canonical_shape_mask_retention_counters
        .historical_artifact_member_checks;
}
void note_historical_artifact_kind_check() noexcept {
    ++canonical_shape_mask_retention_counters
        .historical_artifact_kind_checks;
}
#else
void note_preflight_top_level_member_update() noexcept {}
void note_preflight_protocol_member_update() noexcept {}
void note_preflight_artifact_member_update() noexcept {}
void note_preflight_top_level_kind_update() noexcept {}
void note_preflight_protocol_kind_update() noexcept {}
void note_preflight_artifact_kind_update() noexcept {}
void note_retained_top_level_member_read() noexcept {}
void note_retained_top_level_kind_read() noexcept {}
void note_retained_protocol_shape_read() noexcept {}
void note_retained_artifact_shape_read() noexcept {}
void note_historical_top_level_member_check() noexcept {}
void note_historical_top_level_kind_check() noexcept {}
void note_historical_protocol_member_check() noexcept {}
void note_historical_protocol_kind_check() noexcept {}
void note_historical_artifact_member_check() noexcept {}
void note_historical_artifact_kind_check() noexcept {}
#endif

struct Utf8Scalar final {
    std::uint32_t code_point{0U};
    std::size_t width{0U};
};

[[nodiscard]] bool decode_utf8_scalar(
    const std::string_view text,
    const std::size_t start,
    Utf8Scalar& scalar) noexcept {
    note_raw_scalar_decode();
    if (start >= text.size()) {
        return false;
    }
    const std::uint8_t first = static_cast<std::uint8_t>(
        static_cast<unsigned char>(text[start]));
    if (first <= 0x7FU) {
        scalar = Utf8Scalar{
            .code_point = static_cast<std::uint32_t>(first),
            .width = 1U,
        };
        return true;
    }

    std::size_t length = 0U;
    std::uint32_t code_point = 0U;
    std::uint32_t minimum = 0U;
    if ((first & 0xE0U) == 0xC0U) {
        length = 2U;
        code_point = static_cast<std::uint32_t>(first & 0x1FU);
        minimum = 0x80U;
    } else if ((first & 0xF0U) == 0xE0U) {
        length = 3U;
        code_point = static_cast<std::uint32_t>(first & 0x0FU);
        minimum = 0x800U;
    } else if ((first & 0xF8U) == 0xF0U) {
        length = 4U;
        code_point = static_cast<std::uint32_t>(first & 0x07U);
        minimum = 0x10000U;
    } else {
        return false;
    }
    if (start + length > text.size()) {
        return false;
    }
    for (std::size_t index = 1U; index < length; ++index) {
        const std::uint8_t continuation = static_cast<std::uint8_t>(
            static_cast<unsigned char>(text[start + index]));
        if ((continuation & 0xC0U) != 0x80U) {
            return false;
        }
        code_point = (code_point << 6U) |
            static_cast<std::uint32_t>(continuation & 0x3FU);
    }
    if (code_point < minimum || code_point > 0x10FFFFU ||
        (code_point >= 0xD800U && code_point <= 0xDFFFU)) {
        return false;
    }
    scalar = Utf8Scalar{
        .code_point = code_point,
        .width = length,
    };
    return true;
}

[[nodiscard]] std::size_t encode_utf8_scalar(
    const std::uint32_t code_point,
    unsigned char* const output) noexcept {
    if (code_point <= 0x7FU) {
        output[0U] = static_cast<unsigned char>(code_point);
        return 1U;
    }
    if (code_point <= 0x7FFU) {
        output[0U] = static_cast<unsigned char>(
            0xC0U | ((code_point >> 6U) & 0x1FU));
        output[1U] = static_cast<unsigned char>(
            0x80U | (code_point & 0x3FU));
        return 2U;
    }
    if (code_point <= 0xFFFFU) {
        output[0U] = static_cast<unsigned char>(
            0xE0U | ((code_point >> 12U) & 0x0FU));
        output[1U] = static_cast<unsigned char>(
            0x80U | ((code_point >> 6U) & 0x3FU));
        output[2U] = static_cast<unsigned char>(
            0x80U | (code_point & 0x3FU));
        return 3U;
    }
    output[0U] = static_cast<unsigned char>(
        0xF0U | ((code_point >> 18U) & 0x07U));
    output[1U] = static_cast<unsigned char>(
        0x80U | ((code_point >> 12U) & 0x3FU));
    output[2U] = static_cast<unsigned char>(
        0x80U | ((code_point >> 6U) & 0x3FU));
    output[3U] = static_cast<unsigned char>(
        0x80U | (code_point & 0x3FU));
    return 4U;
}

[[nodiscard]] bool utf8_scalar_sequence(const std::string_view text) noexcept {
    std::size_t offset = 0U;
    while (offset < text.size()) {
        Utf8Scalar scalar;
        if (!decode_utf8_scalar(text, offset, scalar)) {
            return false;
        }
        offset += scalar.width;
    }
    return true;
}

[[nodiscard]] bool utf8_payload_scalar_values(
    const std::string_view text) noexcept {
    return !(text.size() >= 3U &&
             static_cast<unsigned char>(text[0]) == 0xEFU &&
             static_cast<unsigned char>(text[1]) == 0xBBU &&
             static_cast<unsigned char>(text[2]) == 0xBFU) &&
        utf8_scalar_sequence(text);
}

void append_utf8(std::string& output, const std::uint32_t code_point) {
    std::array<unsigned char, 4U> bytes{};
    const std::size_t size = encode_utf8_scalar(code_point, bytes.data());
    for (std::size_t index = 0U; index < size; ++index) {
        output.push_back(static_cast<char>(bytes[index]));
    }
}

[[nodiscard]] std::uint32_t json_hex_nibble(const char character) {
    if (character >= '0' && character <= '9') {
        return static_cast<std::uint32_t>(character - '0');
    }
    if (character >= 'a' && character <= 'f') {
        return 10U + static_cast<std::uint32_t>(character - 'a');
    }
    if (character >= 'A' && character <= 'F') {
        return 10U + static_cast<std::uint32_t>(character - 'A');
    }
    fail("natrav-peer-message-json-hex", "payload");
}

[[nodiscard]] std::uint32_t parse_json_hex_quad(
    const std::string_view text,
    std::size_t& offset) {
    if (offset + 4U > text.size()) {
        fail("natrav-peer-message-json-unicode-short", "payload");
    }
    std::uint32_t value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
        value = (value << 4U) | json_hex_nibble(text[offset + index]);
    }
    offset += 4U;
    return value;
}

struct CanonicalJsonStringFragment final {
    std::array<char, 6U> bytes{};
    std::size_t size{0U};

    [[nodiscard]] std::string_view view() const noexcept {
        return std::string_view(bytes.data(), size);
    }
};

[[nodiscard]] CanonicalJsonStringFragment canonical_json_string_fragment(
    const std::uint32_t code_point) noexcept {
    note_canonical_fragment();
    CanonicalJsonStringFragment result;
    switch (code_point) {
        case static_cast<std::uint32_t>('"'):
            result.bytes[0U] = '\\';
            result.bytes[1U] = '"';
            result.size = 2U;
            return result;
        case static_cast<std::uint32_t>('\\'):
            result.bytes[0U] = '\\';
            result.bytes[1U] = '\\';
            result.size = 2U;
            return result;
        case 0x08U:
            result.bytes[0U] = '\\';
            result.bytes[1U] = 'b';
            result.size = 2U;
            return result;
        case 0x0CU:
            result.bytes[0U] = '\\';
            result.bytes[1U] = 'f';
            result.size = 2U;
            return result;
        case 0x0AU:
            result.bytes[0U] = '\\';
            result.bytes[1U] = 'n';
            result.size = 2U;
            return result;
        case 0x0DU:
            result.bytes[0U] = '\\';
            result.bytes[1U] = 'r';
            result.size = 2U;
            return result;
        case 0x09U:
            result.bytes[0U] = '\\';
            result.bytes[1U] = 't';
            result.size = 2U;
            return result;
        default:
            break;
    }
    if (code_point < 0x20U) {
        static constexpr std::string_view hex = "0123456789abcdef";
        result.bytes[0U] = '\\';
        result.bytes[1U] = 'u';
        result.bytes[2U] = '0';
        result.bytes[3U] = '0';
        result.bytes[4U] = hex[static_cast<std::size_t>(code_point >> 4U)];
        result.bytes[5U] = hex[static_cast<std::size_t>(code_point & 0x0FU)];
        result.size = 6U;
        return result;
    }
    std::array<unsigned char, 4U> encoded{};
    result.size = encode_utf8_scalar(code_point, encoded.data());
    for (std::size_t index = 0U; index < result.size; ++index) {
        result.bytes[index] = static_cast<char>(encoded[index]);
    }
    return result;
}

struct JsonStringScalar final {
    std::uint32_t code_point{0U};
    std::size_t source_begin{0U};
    std::size_t source_end{0U};
    bool end{false};
};

[[nodiscard]] JsonStringScalar parse_json_string_scalar(
    const std::string_view text,
    std::size_t& offset) {
    note_json_scalar_parse();
    if (offset >= text.size()) {
        fail("natrav-peer-message-json-string-unclosed", "payload");
    }
    const std::size_t begin = offset;
    const char raw = text[offset++];
    const unsigned char character = static_cast<unsigned char>(raw);
    if (raw == '"') {
        return JsonStringScalar{
            .source_begin = begin,
            .source_end = offset,
            .end = true,
        };
    }
    if (raw != '\\') {
        if (character < 0x20U) {
            fail("natrav-peer-message-json-string-control", "payload");
        }
        if (character < 0x80U) {
            return JsonStringScalar{
                .code_point = static_cast<std::uint32_t>(character),
                .source_begin = begin,
                .source_end = offset,
                .end = false,
            };
        }
        Utf8Scalar scalar;
        if (!decode_utf8_scalar(text, begin, scalar)) {
            fail("natrav-peer-message-json-utf8", "payload");
        }
        offset = begin + scalar.width;
        return JsonStringScalar{
            .code_point = scalar.code_point,
            .source_begin = begin,
            .source_end = offset,
            .end = false,
        };
    }
    if (offset >= text.size()) {
        fail("natrav-peer-message-json-string-escape", "payload");
    }
    const char escape = text[offset++];
    std::uint32_t code_point = 0U;
    switch (escape) {
        case '"': code_point = static_cast<std::uint32_t>('"'); break;
        case '\\': code_point = static_cast<std::uint32_t>('\\'); break;
        case '/': code_point = static_cast<std::uint32_t>('/'); break;
        case 'b': code_point = 0x08U; break;
        case 'f': code_point = 0x0CU; break;
        case 'n': code_point = 0x0AU; break;
        case 'r': code_point = 0x0DU; break;
        case 't': code_point = 0x09U; break;
        case 'u': {
            const std::uint32_t first = parse_json_hex_quad(text, offset);
            code_point = first;
            if (first >= 0xD800U && first <= 0xDBFFU) {
                if (offset + 6U > text.size() || text[offset] != '\\' ||
                    text[offset + 1U] != 'u') {
                    fail(
                        "natrav-peer-message-json-unpaired-high-surrogate",
                        "payload");
                }
                offset += 2U;
                const std::uint32_t second =
                    parse_json_hex_quad(text, offset);
                if (second < 0xDC00U || second > 0xDFFFU) {
                    fail(
                        "natrav-peer-message-json-unpaired-high-surrogate",
                        "payload");
                }
                code_point = 0x10000U +
                    ((first - 0xD800U) << 10U) +
                    (second - 0xDC00U);
            } else if (first >= 0xDC00U && first <= 0xDFFFU) {
                fail(
                    "natrav-peer-message-json-unpaired-low-surrogate",
                    "payload");
            }
            break;
        }
        default:
            fail("natrav-peer-message-json-string-escape", "payload");
    }
    return JsonStringScalar{
        .code_point = code_point,
        .source_begin = begin,
        .source_end = offset,
        .end = false,
    };
}

[[nodiscard]] bool json_string_scalar_is_canonical(
    const std::string_view text,
    const JsonStringScalar& scalar) noexcept {
    const CanonicalJsonStringFragment canonical =
        canonical_json_string_fragment(scalar.code_point);
    return text.substr(
        scalar.source_begin,
        scalar.source_end - scalar.source_begin) == canonical.view();
}

template <typename Emit>
[[nodiscard]] bool emit_canonical_json_string(
    const std::string_view value,
    Emit&& emit) {
    note_encoder_string();
    if (!emit(std::string_view("\""))) {
        return false;
    }
    std::size_t offset = 0U;
    while (offset < value.size()) {
        Utf8Scalar scalar;
        if (!decode_utf8_scalar(value, offset, scalar)) {
            return false;
        }
        const CanonicalJsonStringFragment fragment =
            canonical_json_string_fragment(scalar.code_point);
        if (!emit(fragment.view())) {
            return false;
        }
        offset += scalar.width;
    }
    return emit(std::string_view("\""));
}

struct JsonStringParseResult final {
    std::string value;
    bool canonical{true};
};

[[nodiscard]] JsonStringParseResult parse_json_string(
    const std::string_view text,
    std::size_t& offset,
    const bool capture,
    const std::size_t reserve_hint = 0U) {
    if (offset >= text.size() || text[offset] != '"') {
        fail("natrav-peer-message-json-character", "payload");
    }
    ++offset;
    JsonStringParseResult result;
    if (capture && reserve_hint > result.value.capacity()) {
        result.value.reserve(reserve_hint);
    }
    while (true) {
        const JsonStringScalar scalar =
            parse_json_string_scalar(text, offset);
        if (scalar.end) {
            return result;
        }
        result.canonical = result.canonical &&
            json_string_scalar_is_canonical(text, scalar);
        if (capture) {
            append_utf8(result.value, scalar.code_point);
        }
    }
}

struct CanonicalJsonIntegerFragment final {
    // INT64_MIN is the longest supported spelling: -9223372036854775808.
    std::array<char, 20U> bytes{};
    std::size_t size{0U};

    [[nodiscard]] std::string_view view() const noexcept {
        return std::string_view(bytes.data(), size);
    }
};

[[nodiscard]] CanonicalJsonIntegerFragment canonical_json_integer_fragment(
    const std::int64_t value) noexcept {
    note_canonical_integer_fragment();
    CanonicalJsonIntegerFragment result;
    const auto conversion = std::to_chars(
        result.bytes.data(), result.bytes.data() + result.bytes.size(), value);
    if (conversion.ec == std::errc{}) {
        result.size = static_cast<std::size_t>(
            conversion.ptr - result.bytes.data());
    }
    return result;
}

template <typename Emit>
[[nodiscard]] bool emit_canonical_json_integer(
    const std::int64_t value,
    Emit&& emit) {
    note_encoder_integer();
    const CanonicalJsonIntegerFragment fragment =
        canonical_json_integer_fragment(value);
    return fragment.size != 0U && emit(fragment.view());
}

struct JsonIntegerParseResult final {
    std::int64_t value{0};
    bool canonical{true};
};

[[nodiscard]] JsonIntegerParseResult parse_json_integer(
    const std::string_view text,
    std::size_t& offset) {
    note_json_integer_parse();
    const std::size_t start = offset;
    if (offset < text.size() && text[offset] == '-') {
        ++offset;
    }
    if (offset >= text.size()) {
        fail("natrav-peer-message-json-integer", "payload");
    }
    if (text[offset] == '0') {
        ++offset;
        if (offset < text.size() && text[offset] >= '0' &&
            text[offset] <= '9') {
            fail("natrav-peer-message-json-leading-zero", "payload");
        }
    } else {
        if (text[offset] < '1' || text[offset] > '9') {
            fail("natrav-peer-message-json-integer", "payload");
        }
        while (offset < text.size() && text[offset] >= '0' &&
               text[offset] <= '9') {
            ++offset;
        }
    }
    if (offset < text.size() &&
        (text[offset] == '.' || text[offset] == 'e' ||
         text[offset] == 'E')) {
        fail("natrav-peer-message-json-floating-point", "payload");
    }
    JsonIntegerParseResult result;
    const char* const begin = text.data() + start;
    const char* const end = text.data() + offset;
    const auto conversion = std::from_chars(begin, end, result.value);
    if (conversion.ec != std::errc{} || conversion.ptr != end) {
        fail("natrav-peer-message-json-integer", "payload");
    }
    const CanonicalJsonIntegerFragment canonical =
        canonical_json_integer_fragment(result.value);
    result.canonical = canonical.size == offset - start &&
        canonical.view() == text.substr(start, offset - start);
    return result;
}

class JsonParser final {
public:
    explicit JsonParser(
        const std::string_view text,
        const std::size_t maximum_depth =
            std::numeric_limits<std::size_t>::max(),
        const std::size_t maximum_values =
            std::numeric_limits<std::size_t>::max()) :
        text_(text),
        maximum_depth_(maximum_depth),
        maximum_values_(maximum_values) {}

    [[nodiscard]] JsonValue parse() {
        if (!utf8_payload_scalar_values(text_)) {
            fail("natrav-peer-message-json-utf8", "payload");
        }
        skip_whitespace();
        JsonValue result = parse_value();
        skip_whitespace();
        if (offset_ != text_.size()) {
            fail("natrav-peer-message-json-trailing", "payload");
        }
        return result;
    }

private:
    class DepthGuard final {
    public:
        explicit DepthGuard(std::size_t& depth) noexcept : depth_(depth) {
            ++depth_;
        }
        ~DepthGuard() { --depth_; }
        DepthGuard(const DepthGuard&) = delete;
        DepthGuard& operator=(const DepthGuard&) = delete;

    private:
        std::size_t& depth_;
    };

    [[nodiscard]] bool at_end() const noexcept {
        return offset_ >= text_.size();
    }

    void skip_whitespace() noexcept {
        while (!at_end()) {
            const char character = text_[offset_];
            if (character != ' ' && character != '\t' &&
                character != '\n' && character != '\r') {
                break;
            }
            ++offset_;
        }
    }

    void expect_character(const char expected) {
        if (at_end() || text_[offset_] != expected) {
            fail("natrav-peer-message-json-character", "payload");
        }
        ++offset_;
    }

    [[nodiscard]] std::string parse_string() {
        return parse_json_string(text_, offset_, true).value;
    }

    [[nodiscard]] JsonValue parse_integer() {
        const JsonIntegerParseResult integer =
            parse_json_integer(text_, offset_);
        JsonValue result;
        result.kind = JsonValue::Kind::integer;
        result.integer_value = integer.value;
        return result;
    }

    [[nodiscard]] JsonValue parse_array() {
        if (depth_ >= maximum_depth_) {
            fail("natrav-peer-message-json-tree-depth", "payload");
        }
        const DepthGuard depth_guard(depth_);
        expect_character('[');
        JsonValue result;
        result.kind = JsonValue::Kind::array;
        skip_whitespace();
        if (!at_end() && text_[offset_] == ']') {
            ++offset_;
            return result;
        }
        while (true) {
            skip_whitespace();
            result.array_values.push_back(parse_value());
            skip_whitespace();
            if (!at_end() && text_[offset_] == ']') {
                ++offset_;
                return result;
            }
            expect_character(',');
            skip_whitespace();
            if (!at_end() && text_[offset_] == ']') {
                fail("natrav-peer-message-json-array-trailing-comma", "payload");
            }
        }
    }

    [[nodiscard]] JsonValue parse_object() {
        if (depth_ >= maximum_depth_) {
            fail("natrav-peer-message-json-tree-depth", "payload");
        }
        const DepthGuard depth_guard(depth_);
        expect_character('{');
        JsonValue result;
        result.kind = JsonValue::Kind::object;
        skip_whitespace();
        if (!at_end() && text_[offset_] == '}') {
            ++offset_;
            return result;
        }
        while (true) {
            skip_whitespace();
            if (at_end() || text_[offset_] != '"') {
                fail("natrav-peer-message-json-object-key", "payload");
            }
            std::string key = parse_string();
            skip_whitespace();
            expect_character(':');
            skip_whitespace();
            JsonValue member_value = parse_value();
            if (!result.object_values.emplace(
                    std::move(key), std::move(member_value)).second) {
                fail("natrav-peer-message-json-duplicate-key", "payload");
            }
            skip_whitespace();
            if (!at_end() && text_[offset_] == '}') {
                ++offset_;
                return result;
            }
            expect_character(',');
            skip_whitespace();
            if (!at_end() && text_[offset_] == '}') {
                fail("natrav-peer-message-json-object-trailing-comma", "payload");
            }
        }
    }

    [[nodiscard]] JsonValue parse_literal(
        const std::string_view literal,
        const JsonValue::Kind kind,
        const bool boolean_value) {
        if (!text_.substr(offset_).starts_with(literal)) {
            fail("natrav-peer-message-json-literal", "payload");
        }
        offset_ += literal.size();
        JsonValue result;
        result.kind = kind;
        result.boolean_value = boolean_value;
        return result;
    }

    [[nodiscard]] JsonValue parse_value() {
        if (at_end()) {
            fail("natrav-peer-message-json-value", "payload");
        }
        if (value_count_ >= maximum_values_) {
            fail("natrav-peer-message-json-tree-values", "payload");
        }
        ++value_count_;
        switch (text_[offset_]) {
            case '{': return parse_object();
            case '[': return parse_array();
            case '"': {
                JsonValue result;
                result.kind = JsonValue::Kind::string;
                result.string_value = parse_string();
                return result;
            }
            case 't':
                return parse_literal("true", JsonValue::Kind::boolean, true);
            case 'f':
                return parse_literal("false", JsonValue::Kind::boolean, false);
            case 'n':
                return parse_literal("null", JsonValue::Kind::null_value, false);
            default:
                if (text_[offset_] == '-' ||
                    (text_[offset_] >= '0' && text_[offset_] <= '9')) {
                    return parse_integer();
                }
                fail("natrav-peer-message-json-value", "payload");
        }
    }

    std::string_view text_;
    std::size_t offset_{0U};
    std::size_t maximum_depth_;
    std::size_t maximum_values_;
    std::size_t depth_{0U};
    std::size_t value_count_{0U};
};

struct JsonComplexityProbe final {
    std::size_t maximum_depth{0U};
    std::size_t construction_units{0U};

    [[nodiscard]] bool requires_bounded_preflight() const noexcept {
        return maximum_depth > kNATravPeerMaximumJsonTreeDepth ||
            construction_units >
                kNATravPeerMaximumJsonConstructionUnits;
    }
};

// This allocation-free lexical probe is deliberately conservative for invalid
// JSON and exact for the container/value/key units of valid JSON. Ordinary
// admitted messages therefore retain the predecessor's parser and allocation
// sequence. Only a potentially excessive input is routed through the iterative
// grammar/canonicality preflight below.
[[maybe_unused]] [[nodiscard]] JsonComplexityProbe probe_json_complexity(
    const std::string_view text) noexcept {
    JsonComplexityProbe result;
    std::size_t depth = 0U;
    std::size_t offset = 0U;
    while (offset < text.size()) {
        const char character = text[offset];
        if (character == '"') {
            ++result.construction_units;
            ++offset;
            while (offset < text.size()) {
                if (text[offset] == '\\') {
                    offset += std::min<std::size_t>(2U, text.size() - offset);
                    continue;
                }
                if (text[offset] == '"') {
                    ++offset;
                    break;
                }
                ++offset;
            }
            continue;
        }
        if (character == '{' || character == '[') {
            ++result.construction_units;
            ++depth;
            result.maximum_depth = std::max(result.maximum_depth, depth);
            ++offset;
            continue;
        }
        if (character == '}' || character == ']') {
            if (depth != 0U) {
                --depth;
            }
            ++offset;
            continue;
        }
        if (character == '-' ||
            (character >= '0' && character <= '9')) {
            ++result.construction_units;
            ++offset;
            while (offset < text.size()) {
                const char numeric = text[offset];
                if (!((numeric >= '0' && numeric <= '9') ||
                      numeric == '.' || numeric == 'e' || numeric == 'E' ||
                      numeric == '+' || numeric == '-')) {
                    break;
                }
                ++offset;
            }
            continue;
        }
        if (character == 't') {
            ++result.construction_units;
            offset += std::min<std::size_t>(4U, text.size() - offset);
            continue;
        }
        if (character == 'f') {
            ++result.construction_units;
            offset += std::min<std::size_t>(5U, text.size() - offset);
            continue;
        }
        if (character == 'n') {
            ++result.construction_units;
            offset += std::min<std::size_t>(4U, text.size() - offset);
            continue;
        }
        ++offset;
    }
    return result;
}

struct JsonPreflightObservation final {
    JsonValue::Kind root_kind{JsonValue::Kind::null_value};
    bool canonical{true};
    std::size_t maximum_depth{0U};
    std::size_t value_count{0U};
    std::size_t object_key_count{0U};

    [[nodiscard]] bool tree_admissible() const noexcept {
        return maximum_depth <= kNATravPeerMaximumJsonTreeDepth &&
            value_count <= kNATravPeerMaximumJsonTreeValues &&
            object_key_count <=
                kNATravPeerMaximumJsonConstructionUnits - value_count;
    }
};

// Validate the complete JSON grammar and exact canonical spelling without
// recursive calls or construction of a JsonValue tree. Object keys are retained
// only long enough to preserve duplicate-key MALFORMED_JSON priority and to
// check the canonical decoded-key ordering used by std::map serialization.
class JsonPreflight final {
public:
    explicit JsonPreflight(const std::string_view text) : text_(text) {}

    [[nodiscard]] JsonPreflightObservation inspect() {
        if (!utf8_payload_scalar_values(text_)) {
            fail("natrav-peer-message-json-utf8", "payload");
        }
        skip_whitespace();
        parse_value();
        while (!root_complete_) {
            if (frames_.empty()) {
                fail("natrav-peer-message-json-preflight-state", "payload");
            }
            process_frame();
        }
        skip_whitespace();
        if (offset_ != text_.size()) {
            fail("natrav-peer-message-json-trailing", "payload");
        }
        return JsonPreflightObservation{
            .root_kind = root_kind_,
            .canonical = canonical_,
            .maximum_depth = maximum_depth_,
            .value_count = value_count_,
            .object_key_count = object_key_count_,
        };
    }

private:
    enum class FrameKind {
        array,
        object,
    };

    enum class FrameState {
        array_value_or_end,
        array_comma_or_end,
        object_key_or_end,
        object_colon,
        object_value,
        object_comma_or_end,
    };

    struct Frame final {
        FrameKind kind{FrameKind::array};
        FrameState state{FrameState::array_value_or_end};
        std::vector<std::string> object_keys;
    };

    [[nodiscard]] bool at_end() const noexcept {
        return offset_ >= text_.size();
    }

    void skip_whitespace() noexcept {
        const std::size_t before = offset_;
        while (!at_end()) {
            const char character = text_[offset_];
            if (character != ' ' && character != '\t' &&
                character != '\n' && character != '\r') {
                break;
            }
            ++offset_;
        }
        if (offset_ != before) {
            canonical_ = false;
        }
    }

    void expect_character(const char expected) {
        if (at_end() || text_[offset_] != expected) {
            fail("natrav-peer-message-json-character", "payload");
        }
        ++offset_;
    }

    void note_root_kind(const JsonValue::Kind kind) noexcept {
        if (!root_started_) {
            root_started_ = true;
            root_kind_ = kind;
        }
    }

    void note_value(const JsonValue::Kind kind) noexcept {
        note_root_kind(kind);
        ++value_count_;
    }

    void push_container(
        const FrameKind frame_kind,
        const FrameState state,
        const JsonValue::Kind value_kind) {
        note_value(value_kind);
        frames_.push_back(Frame{
            .kind = frame_kind,
            .state = state,
            .object_keys = {},
        });
        maximum_depth_ = std::max(maximum_depth_, frames_.size());
    }

    void complete_value() noexcept {
        if (frames_.empty()) {
            root_complete_ = true;
        }
    }

    void parse_literal(
        const std::string_view literal,
        const JsonValue::Kind kind) {
        if (!text_.substr(offset_).starts_with(literal)) {
            fail("natrav-peer-message-json-literal", "payload");
        }
        offset_ += literal.size();
        note_value(kind);
        complete_value();
    }

    void parse_value() {
        if (at_end()) {
            fail("natrav-peer-message-json-value", "payload");
        }
        switch (text_[offset_]) {
            case '{':
                ++offset_;
                push_container(
                    FrameKind::object,
                    FrameState::object_key_or_end,
                    JsonValue::Kind::object);
                return;
            case '[':
                ++offset_;
                push_container(
                    FrameKind::array,
                    FrameState::array_value_or_end,
                    JsonValue::Kind::array);
                return;
            case '"': {
                const JsonStringParseResult string =
                    parse_json_string(text_, offset_, false);
                canonical_ = canonical_ && string.canonical;
                note_value(JsonValue::Kind::string);
                complete_value();
                return;
            }
            case 't':
                parse_literal("true", JsonValue::Kind::boolean);
                return;
            case 'f':
                parse_literal("false", JsonValue::Kind::boolean);
                return;
            case 'n':
                parse_literal("null", JsonValue::Kind::null_value);
                return;
            default:
                if (text_[offset_] == '-' ||
                    (text_[offset_] >= '0' && text_[offset_] <= '9')) {
                    const JsonIntegerParseResult integer =
                        parse_json_integer(text_, offset_);
                    canonical_ = canonical_ && integer.canonical;
                    note_value(JsonValue::Kind::integer);
                    complete_value();
                    return;
                }
                fail("natrav-peer-message-json-value", "payload");
        }
    }

    void parse_object_key(Frame& frame) {
        if (at_end() || text_[offset_] != '"') {
            fail("natrav-peer-message-json-object-key", "payload");
        }
        JsonStringParseResult key = parse_json_string(text_, offset_, true);
        ++object_key_count_;
        canonical_ = canonical_ && key.canonical;
        if (!frame.object_keys.empty() &&
            !(frame.object_keys.back() < key.value)) {
            canonical_ = false;
        }
        frame.object_keys.push_back(std::move(key.value));
        frame.state = FrameState::object_colon;
    }

    void close_object() {
        Frame& frame = frames_.back();
        std::sort(frame.object_keys.begin(), frame.object_keys.end());
        for (std::size_t index = 1U;
             index < frame.object_keys.size(); ++index) {
            if (frame.object_keys[index - 1U] == frame.object_keys[index]) {
                fail("natrav-peer-message-json-duplicate-key", "payload");
            }
        }
        frames_.pop_back();
        complete_value();
    }

    void close_array() noexcept {
        frames_.pop_back();
        complete_value();
    }

    void process_array(Frame& frame) {
        if (frame.state == FrameState::array_value_or_end) {
            skip_whitespace();
            if (!at_end() && text_[offset_] == ']') {
                ++offset_;
                close_array();
                return;
            }
            frame.state = FrameState::array_comma_or_end;
            parse_value();
            return;
        }

        skip_whitespace();
        if (!at_end() && text_[offset_] == ']') {
            ++offset_;
            close_array();
            return;
        }
        expect_character(',');
        skip_whitespace();
        if (!at_end() && text_[offset_] == ']') {
            fail("natrav-peer-message-json-array-trailing-comma", "payload");
        }
        frame.state = FrameState::array_comma_or_end;
        parse_value();
    }

    void process_object(Frame& frame) {
        switch (frame.state) {
            case FrameState::object_key_or_end:
                skip_whitespace();
                if (!at_end() && text_[offset_] == '}') {
                    ++offset_;
                    close_object();
                    return;
                }
                parse_object_key(frame);
                return;
            case FrameState::object_colon:
                skip_whitespace();
                expect_character(':');
                frame.state = FrameState::object_value;
                return;
            case FrameState::object_value:
                skip_whitespace();
                frame.state = FrameState::object_comma_or_end;
                parse_value();
                return;
            case FrameState::object_comma_or_end:
                skip_whitespace();
                if (!at_end() && text_[offset_] == '}') {
                    ++offset_;
                    close_object();
                    return;
                }
                expect_character(',');
                skip_whitespace();
                if (!at_end() && text_[offset_] == '}') {
                    fail(
                        "natrav-peer-message-json-object-trailing-comma",
                        "payload");
                }
                parse_object_key(frame);
                return;
            case FrameState::array_value_or_end:
            case FrameState::array_comma_or_end:
                fail("natrav-peer-message-json-preflight-state", "payload");
        }
    }

    void process_frame() {
        Frame& frame = frames_.back();
        if (frame.kind == FrameKind::array) {
            process_array(frame);
        } else {
            process_object(frame);
        }
    }

    std::string_view text_;
    std::size_t offset_{0U};
    std::vector<Frame> frames_;
    bool root_started_{false};
    bool root_complete_{false};
    bool canonical_{true};
    JsonValue::Kind root_kind_{JsonValue::Kind::null_value};
    std::size_t maximum_depth_{0U};
    std::size_t value_count_{0U};
    std::size_t object_key_count_{0U};
};

[[nodiscard]] bool lower_hex_sha256(std::string_view value) noexcept;
[[nodiscard]] bool capability_token(std::string_view token) noexcept;

struct CanonicalJsonSpan final {
    JsonValue::Kind kind{JsonValue::Kind::null_value};
    std::string_view bytes;
    std::optional<std::size_t> decoded_string_bytes;
};

// A non-owning second-pass cursor used only after JsonPreflight has established
// complete UTF-8, JSON grammar, duplicate-key, canonical-spelling and bounded-
// structure validity. It therefore needs no general value tree and allocates no
// storage while locating the typed handshake fields.
class CanonicalJsonCursor final {
public:
    explicit CanonicalJsonCursor(const std::string_view text) noexcept :
        text_(text) {}

    [[nodiscard]] bool at_end() const noexcept {
        return offset_ == text_.size();
    }

    [[nodiscard]] char peek() const noexcept {
        return offset_ < text_.size() ? text_[offset_] : '\0';
    }

    [[nodiscard]] bool take(const char expected) noexcept {
        if (offset_ >= text_.size() || text_[offset_] != expected) {
            return false;
        }
        ++offset_;
        return true;
    }

    [[nodiscard]] std::string_view string_token() {
        const std::size_t begin = offset_;
        static_cast<void>(parse_json_string(text_, offset_, false));
        return text_.substr(begin, offset_ - begin);
    }

    [[nodiscard]] CanonicalJsonSpan value_span() {
        const std::size_t begin = offset_;
        const JsonValue::Kind kind = skip_value(0U);
        return CanonicalJsonSpan{
            .kind = kind,
            .bytes = text_.substr(begin, offset_ - begin),
            .decoded_string_bytes = std::nullopt,
        };
    }

private:
    [[nodiscard]] JsonValue::Kind skip_value(const std::size_t depth) {
        if (offset_ >= text_.size() ||
            depth > kNATravPeerMaximumJsonTreeDepth) {
            fail("natrav-peer-message-canonical-cursor-value", "payload");
        }
        switch (text_[offset_]) {
            case '{': {
                ++offset_;
                if (take('}')) {
                    return JsonValue::Kind::object;
                }
                while (true) {
                    if (peek() != '"') {
                        fail(
                            "natrav-peer-message-canonical-cursor-object-key",
                            "payload");
                    }
                    static_cast<void>(string_token());
                    if (!take(':')) {
                        fail(
                            "natrav-peer-message-canonical-cursor-colon",
                            "payload");
                    }
                    static_cast<void>(skip_value(depth + 1U));
                    if (take('}')) {
                        return JsonValue::Kind::object;
                    }
                    if (!take(',')) {
                        fail(
                            "natrav-peer-message-canonical-cursor-object-comma",
                            "payload");
                    }
                }
            }
            case '[': {
                ++offset_;
                if (take(']')) {
                    return JsonValue::Kind::array;
                }
                while (true) {
                    static_cast<void>(skip_value(depth + 1U));
                    if (take(']')) {
                        return JsonValue::Kind::array;
                    }
                    if (!take(',')) {
                        fail(
                            "natrav-peer-message-canonical-cursor-array-comma",
                            "payload");
                    }
                }
            }
            case '"':
                static_cast<void>(string_token());
                return JsonValue::Kind::string;
            case 't':
                if (!text_.substr(offset_).starts_with("true")) {
                    fail(
                        "natrav-peer-message-canonical-cursor-literal",
                        "payload");
                }
                offset_ += 4U;
                return JsonValue::Kind::boolean;
            case 'f':
                if (!text_.substr(offset_).starts_with("false")) {
                    fail(
                        "natrav-peer-message-canonical-cursor-literal",
                        "payload");
                }
                offset_ += 5U;
                return JsonValue::Kind::boolean;
            case 'n':
                if (!text_.substr(offset_).starts_with("null")) {
                    fail(
                        "natrav-peer-message-canonical-cursor-literal",
                        "payload");
                }
                offset_ += 4U;
                return JsonValue::Kind::null_value;
            default:
                if (text_[offset_] == '-' ||
                    (text_[offset_] >= '0' && text_[offset_] <= '9')) {
                    static_cast<void>(parse_json_integer(text_, offset_));
                    return JsonValue::Kind::integer;
                }
                fail("natrav-peer-message-canonical-cursor-value", "payload");
        }
    }

    std::string_view text_;
    std::size_t offset_{0U};
};

template <typename Consumer>
[[nodiscard]] bool for_each_canonical_object_member(
    const CanonicalJsonSpan object,
    Consumer&& consumer) {
    if (object.kind != JsonValue::Kind::object) {
        return false;
    }
    CanonicalJsonCursor cursor(object.bytes);
    if (!cursor.take('{')) {
        fail("natrav-peer-message-canonical-object-open", "payload");
    }
    if (cursor.take('}')) {
        return cursor.at_end();
    }
    while (true) {
        if (cursor.peek() != '"') {
            fail("natrav-peer-message-canonical-object-key", "payload");
        }
        const std::string_view key = cursor.string_token();
        if (!cursor.take(':')) {
            fail("natrav-peer-message-canonical-object-colon", "payload");
        }
        consumer(key, cursor.value_span());
        if (cursor.take('}')) {
            return cursor.at_end();
        }
        if (!cursor.take(',')) {
            fail("natrav-peer-message-canonical-object-comma", "payload");
        }
    }
}

template <typename Consumer>
[[nodiscard]] bool for_each_canonical_array_value(
    const CanonicalJsonSpan array,
    Consumer&& consumer) {
    if (array.kind != JsonValue::Kind::array) {
        return false;
    }
    CanonicalJsonCursor cursor(array.bytes);
    if (!cursor.take('[')) {
        fail("natrav-peer-message-canonical-array-open", "payload");
    }
    if (cursor.take(']')) {
        return cursor.at_end();
    }
    while (true) {
        consumer(cursor.value_span());
        if (cursor.take(']')) {
            return cursor.at_end();
        }
        if (!cursor.take(',')) {
            fail("natrav-peer-message-canonical-array-comma", "payload");
        }
    }
}

[[nodiscard]] std::optional<std::int64_t> canonical_integer_value(
    const CanonicalJsonSpan value) {
    if (value.kind != JsonValue::Kind::integer) {
        return std::nullopt;
    }
    std::size_t offset = 0U;
    const JsonIntegerParseResult integer =
        parse_json_integer(value.bytes, offset);
    if (offset != value.bytes.size()) {
        fail("natrav-peer-message-canonical-integer-span", "payload");
    }
    return integer.value;
}

#ifdef DATACUBE_NATRAV_MESSAGE_PROJECTION_STRING_DECODER_TEST
thread_local bool use_revision_0476_projection_string_decoder = false;

[[nodiscard]] std::string decode_canonical_string_revision_0476(
    const CanonicalJsonSpan value) {
    if (value.kind != JsonValue::Kind::string) {
        fail("natrav-peer-message-canonical-string-kind", "payload");
    }
    const std::size_t reserve_hint = value.decoded_string_bytes.value_or(
        value.bytes.size() - 2U);
    if (value.decoded_string_bytes) {
        note_retained_string_length_read(reserve_hint);
    }
    std::size_t offset = 0U;
    JsonStringParseResult parsed = parse_json_string(
        value.bytes,
        offset,
        true,
        reserve_hint);
    if (offset != value.bytes.size() || !parsed.canonical ||
        (value.decoded_string_bytes &&
         parsed.value.size() != *value.decoded_string_bytes)) {
        fail("natrav-peer-message-canonical-string-span", "payload");
    }
    return std::move(parsed.value);
}
#endif

[[nodiscard]] std::string decode_canonical_string(
    const CanonicalJsonSpan value) {
#ifdef DATACUBE_NATRAV_MESSAGE_PROJECTION_STRING_DECODER_TEST
    if (use_revision_0476_projection_string_decoder) {
        return decode_canonical_string_revision_0476(value);
    }
#endif
    if (value.kind != JsonValue::Kind::string || value.bytes.size() < 2U ||
        value.bytes.front() != '"') {
        fail("natrav-peer-message-canonical-string-kind", "payload");
    }
    const std::size_t reserve_hint = value.decoded_string_bytes.value_or(
        value.bytes.size() - 2U);
    if (value.decoded_string_bytes) {
        note_retained_string_length_read(reserve_hint);
    }

    std::string decoded;
    if (reserve_hint > decoded.capacity()) {
        decoded.reserve(reserve_hint);
    }
    std::size_t offset = 1U;
    while (true) {
        const JsonStringScalar scalar =
            parse_json_string_scalar(value.bytes, offset);
        if (scalar.end) {
            break;
        }
        // Canonical spelling was established for this exact caller-owned span
        // by CanonicalMessagePreflight. Projection therefore decodes the
        // already validated scalar without regenerating and comparing its
        // canonical fragment a second time.
        append_utf8(decoded, scalar.code_point);
    }
    if (offset != value.bytes.size() ||
        (value.decoded_string_bytes &&
         decoded.size() != *value.decoded_string_bytes)) {
        fail("natrav-peer-message-canonical-string-span", "payload");
    }
    return decoded;
}

#ifdef DATACUBE_NATRAV_MESSAGE_PREFLIGHT_STRING_LENGTH_RETENTION_TEST
[[nodiscard]] std::string decode_canonical_string_revision_0475(
    const CanonicalJsonSpan value) {
    if (value.kind != JsonValue::Kind::string) {
        fail("natrav-peer-message-canonical-string-kind", "payload");
    }
    const std::size_t reserve_hint = value.bytes.size() - 2U;
    note_historical_string_length_read(reserve_hint);
    std::size_t offset = 0U;
    JsonStringParseResult parsed = parse_json_string(
        value.bytes,
        offset,
        true,
        reserve_hint);
    if (offset != value.bytes.size() || !parsed.canonical) {
        fail("natrav-peer-message-canonical-string-span", "payload");
    }
    return std::move(parsed.value);
}
#endif

[[nodiscard]] std::string_view canonical_ascii_string_contents(
    const CanonicalJsonSpan value) noexcept {
    if (value.kind != JsonValue::Kind::string || value.bytes.size() < 2U ||
        value.bytes.front() != '"' || value.bytes.back() != '"') {
        return {};
    }
    return value.bytes.substr(1U, value.bytes.size() - 2U);
}

struct CanonicalObjectShapeMasks final {
    std::uint16_t member_mask{0U};
    std::uint16_t expected_kind_mask{0U};
    bool unknown_member_seen{false};
};

constexpr std::uint16_t kCanonicalMessageArtifactBit =
    static_cast<std::uint16_t>(1U << 0U);
constexpr std::uint16_t kCanonicalMessageAvailableCapabilitiesBit =
    static_cast<std::uint16_t>(1U << 1U);
constexpr std::uint16_t kCanonicalMessageCodeBit =
    static_cast<std::uint16_t>(1U << 2U);
constexpr std::uint16_t kCanonicalMessageKindBit =
    static_cast<std::uint16_t>(1U << 3U);
constexpr std::uint16_t kCanonicalMessageMessageBit =
    static_cast<std::uint16_t>(1U << 4U);
constexpr std::uint16_t kCanonicalMessageProtocolBit =
    static_cast<std::uint16_t>(1U << 5U);
constexpr std::uint16_t kCanonicalMessageRequestIdBit =
    static_cast<std::uint16_t>(1U << 6U);
constexpr std::uint16_t kCanonicalMessageRequiredCapabilitiesBit =
    static_cast<std::uint16_t>(1U << 7U);

constexpr std::uint16_t kCanonicalProtocolIdBit =
    static_cast<std::uint16_t>(1U << 0U);
constexpr std::uint16_t kCanonicalProtocolMajorBit =
    static_cast<std::uint16_t>(1U << 1U);
constexpr std::uint16_t kCanonicalProtocolMinorBit =
    static_cast<std::uint16_t>(1U << 2U);
constexpr std::uint16_t kCanonicalProtocolExactMask =
    static_cast<std::uint16_t>(
        kCanonicalProtocolIdBit |
        kCanonicalProtocolMajorBit |
        kCanonicalProtocolMinorBit);

constexpr std::uint16_t kCanonicalArtifactSha256Bit =
    static_cast<std::uint16_t>(1U << 0U);
constexpr std::uint16_t kCanonicalArtifactTargetBit =
    static_cast<std::uint16_t>(1U << 1U);
constexpr std::uint16_t kCanonicalArtifactVersionBit =
    static_cast<std::uint16_t>(1U << 2U);
constexpr std::uint16_t kCanonicalArtifactExactMask =
    static_cast<std::uint16_t>(
        kCanonicalArtifactSha256Bit |
        kCanonicalArtifactTargetBit |
        kCanonicalArtifactVersionBit);

struct CanonicalMessageFieldSpans final {
    CanonicalObjectShapeMasks shape;
    std::size_t member_count{0U};
    std::size_t unknown_count{0U};
    std::optional<CanonicalJsonSpan> artifact;
    std::optional<CanonicalJsonSpan> available_capabilities;
    std::optional<CanonicalJsonSpan> code;
    std::optional<CanonicalJsonSpan> kind;
    std::optional<CanonicalJsonSpan> message;
    std::optional<CanonicalJsonSpan> protocol;
    std::optional<CanonicalJsonSpan> request_id;
    std::optional<CanonicalJsonSpan> required_capabilities;
    std::optional<bool> request_id_lower_hex_sha256;
    std::optional<bool> peer_error_code_capability_token;
    std::optional<bool> peer_error_message_nonempty;
    std::optional<NATravPeerHandshakeMessageKind> kind_discriminant;
};

template <typename OptionalSpan>
void set_canonical_field(
    OptionalSpan& destination,
    const CanonicalJsonSpan value) {
    if (destination.has_value()) {
        fail("natrav-peer-message-canonical-field-duplicate", "payload");
    }
    destination = value;
}

[[maybe_unused]] [[nodiscard]] CanonicalMessageFieldSpans scan_canonical_message_fields(
    const std::string_view text) {
    CanonicalMessageFieldSpans fields;
    const CanonicalJsonSpan root{
        .kind = JsonValue::Kind::object,
        .bytes = text,
        .decoded_string_bytes = std::nullopt,
    };
    const bool complete = for_each_canonical_object_member(
        root,
        [&fields](
            const std::string_view key,
            const CanonicalJsonSpan value) {
            ++fields.member_count;
            if (key == "\"artifact\"") {
                set_canonical_field(fields.artifact, value);
            } else if (key == "\"available_capabilities\"") {
                set_canonical_field(fields.available_capabilities, value);
            } else if (key == "\"code\"") {
                set_canonical_field(fields.code, value);
            } else if (key == "\"kind\"") {
                set_canonical_field(fields.kind, value);
            } else if (key == "\"message\"") {
                set_canonical_field(fields.message, value);
            } else if (key == "\"protocol\"") {
                set_canonical_field(fields.protocol, value);
            } else if (key == "\"request_id\"") {
                set_canonical_field(fields.request_id, value);
            } else if (key == "\"required_capabilities\"") {
                set_canonical_field(fields.required_capabilities, value);
            } else {
                ++fields.unknown_count;
            }
        });
    if (!complete) {
        fail("natrav-peer-message-canonical-root-span", "payload");
    }
    return fields;
}

struct CanonicalProtocolProjection final {
    std::int64_t minor{0};
};

[[maybe_unused]] [[nodiscard]] bool project_canonical_protocol(
    const CanonicalJsonSpan value,
    CanonicalProtocolProjection& projection) {
    std::size_t count = 0U;
    std::size_t unknown = 0U;
    std::optional<CanonicalJsonSpan> id;
    std::optional<CanonicalJsonSpan> major;
    std::optional<CanonicalJsonSpan> minor;
    if (!for_each_canonical_object_member(
            value,
            [&](const std::string_view key, const CanonicalJsonSpan member_value) {
                ++count;
                if (key == "\"id\"") {
                    set_canonical_field(id, member_value);
                } else if (key == "\"major\"") {
                    set_canonical_field(major, member_value);
                } else if (key == "\"minor\"") {
                    set_canonical_field(minor, member_value);
                } else {
                    ++unknown;
                }
            })) {
        return false;
    }
    if (count != 3U || unknown != 0U || !id || !major || !minor ||
        id->kind != JsonValue::Kind::string ||
        id->bytes != "\"NATRAV_OVERLAY_PEER\"") {
        return false;
    }
    const std::optional<std::int64_t> major_value =
        canonical_integer_value(*major);
    const std::optional<std::int64_t> minor_value =
        canonical_integer_value(*minor);
    if (!major_value || *major_value != 1 || !minor_value ||
        *minor_value < 0) {
        return false;
    }
    projection.minor = *minor_value;
    return true;
}

struct CanonicalArtifactProjection final {
    CanonicalJsonSpan sha256;
    CanonicalJsonSpan target;
    CanonicalJsonSpan version;
};

[[maybe_unused]] [[nodiscard]] bool project_canonical_artifact(
    const CanonicalJsonSpan value,
    CanonicalArtifactProjection& projection) {
    std::size_t count = 0U;
    std::size_t unknown = 0U;
    std::optional<CanonicalJsonSpan> sha256;
    std::optional<CanonicalJsonSpan> target;
    std::optional<CanonicalJsonSpan> version;
    if (!for_each_canonical_object_member(
            value,
            [&](const std::string_view key, const CanonicalJsonSpan member_value) {
                ++count;
                if (key == "\"sha256\"") {
                    set_canonical_field(sha256, member_value);
                } else if (key == "\"target\"") {
                    set_canonical_field(target, member_value);
                } else if (key == "\"version\"") {
                    set_canonical_field(version, member_value);
                } else {
                    ++unknown;
                }
            })) {
        return false;
    }
    if (count != 3U || unknown != 0U || !sha256 || !target || !version ||
        sha256->kind != JsonValue::Kind::string ||
        target->kind != JsonValue::Kind::string ||
        version->kind != JsonValue::Kind::string) {
        return false;
    }
    const std::string_view sha = canonical_ascii_string_contents(*sha256);
    if (!lower_hex_sha256(sha) || target->bytes.size() == 2U ||
        version->bytes.size() == 2U) {
        return false;
    }
    projection = CanonicalArtifactProjection{
        .sha256 = *sha256,
        .target = *target,
        .version = *version,
    };
    return true;
}

struct CanonicalCapabilityProjection final {
    std::size_t count{0U};
};

[[maybe_unused]] [[nodiscard]] bool project_canonical_capabilities(
    const CanonicalJsonSpan value,
    CanonicalCapabilityProjection& projection) {
    std::string_view previous;
    bool first = true;
    bool valid = true;
    std::size_t count = 0U;
    if (!for_each_canonical_array_value(
            value,
            [&](const CanonicalJsonSpan entry) {
                ++count;
                const std::string_view token =
                    canonical_ascii_string_contents(entry);
                if (entry.kind != JsonValue::Kind::string ||
                    !capability_token(token) ||
                    (!first && !(previous < token))) {
                    valid = false;
                    return;
                }
                first = false;
                previous = token;
            })) {
        return false;
    }
    if (!valid) {
        return false;
    }
    projection.count = count;
    return true;
}

[[maybe_unused]] [[nodiscard]] std::vector<std::string> decode_canonical_capabilities(
    const CanonicalJsonSpan value,
    const std::size_t count) {
    std::vector<std::string> result;
    result.reserve(count);
    const bool complete = for_each_canonical_array_value(
        value,
        [&result](const CanonicalJsonSpan entry) {
            note_historical_capability_array_reparse_entry();
            const std::string_view token =
                canonical_ascii_string_contents(entry);
            result.emplace_back(token);
        });
    if (!complete || result.size() != count) {
        fail("natrav-peer-message-canonical-capability-span", "payload");
    }
    return result;
}

[[nodiscard]] bool canonical_message_shape_exact_revision_0480(
    const CanonicalMessageFieldSpans& fields,
    const NATravPeerHandshakeMessageKind kind) noexcept {
    if (fields.member_count != 5U || fields.unknown_count != 0U ||
        !fields.kind || !fields.protocol || !fields.request_id) {
        return false;
    }
    switch (kind) {
        case NATravPeerHandshakeMessageKind::hello:
            return fields.artifact.has_value() &&
                fields.required_capabilities.has_value() &&
                !fields.available_capabilities && !fields.code &&
                !fields.message;
        case NATravPeerHandshakeMessageKind::hello_ack:
            return fields.artifact.has_value() &&
                fields.available_capabilities.has_value() &&
                !fields.required_capabilities && !fields.code &&
                !fields.message;
        case NATravPeerHandshakeMessageKind::error:
            return fields.code.has_value() && fields.message.has_value() &&
                !fields.artifact && !fields.available_capabilities &&
                !fields.required_capabilities;
        case NATravPeerHandshakeMessageKind::unknown:
            return false;
    }
    return false;
}

// A schema-aware preflight that validates each admitted payload in one
// structural pass while indexing the typed message fields encountered along
// that pass. Accepted schema objects use fixed in-place frame and key storage;
// generic or structurally excessive JSON spills to bounded dynamic storage only
// when the input itself requires it. Typed output strings remain deferred until
// malformed, root-shape, canonical-spelling and structural-profile priority has
// been established for the complete payload.
struct CanonicalProtocolFieldSpans final {
    CanonicalObjectShapeMasks shape;
    std::size_t member_count{0U};
    std::size_t unknown_count{0U};
    std::optional<CanonicalJsonSpan> id;
    std::optional<CanonicalJsonSpan> major;
    std::optional<CanonicalJsonSpan> minor;
    std::optional<std::int64_t> major_value;
    std::optional<std::int64_t> minor_value;
    std::optional<bool> id_matches_natrav_overlay_peer;
};

struct CanonicalArtifactFieldSpans final {
    CanonicalObjectShapeMasks shape;
    std::size_t member_count{0U};
    std::size_t unknown_count{0U};
    std::optional<CanonicalJsonSpan> sha256;
    std::optional<CanonicalJsonSpan> target;
    std::optional<CanonicalJsonSpan> version;
    std::optional<bool> sha256_lower_hex;
    std::optional<bool> target_nonempty;
    std::optional<bool> version_nonempty;
};

struct CanonicalCapabilityEntrySpan final {
    std::uint16_t content_offset;
    std::uint16_t content_size;
};

static_assert(
    kNATravPeerMaximumPayloadBytes <=
    static_cast<std::size_t>(std::numeric_limits<std::uint16_t>::max()) + 1U);
static_assert(sizeof(CanonicalCapabilityEntrySpan) == 4U);

// Revision 0488: the first uniform-tail chunk and the remaining six owners
// share one lazily allocated block. Its inline array never relocates; there is
// deliberately no owning pointer to that array. The outer unique_ptr owns the
// entire activation block and the six later chunks retain independent owners.
struct CanonicalCapabilitySpanTailActivationBlock final {
    std::array<CanonicalCapabilityEntrySpan,
        kNATravPeerCapabilitySpanTailChunkCapacity> first_chunk;
    std::array<std::unique_ptr<CanonicalCapabilityEntrySpan[]>,
        kNATravPeerCapabilitySpanLazyTailOwnerCount - 1U> later_chunks{};
};

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_FUSED_TAIL_TEST
thread_local bool use_revision_0487_unfused_tail_activation = false;
[[nodiscard]] bool use_historical_unfused_tail_activation() noexcept {
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_FUSED_TAIL_SENSITIVITY
    return true;
#else
    return use_revision_0487_unfused_tail_activation;
#endif
}
#endif


#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_STORAGE_TEST
thread_local bool use_revision_0483_fixed_capability_span_storage = false;
thread_local std::array<
    CanonicalCapabilityEntrySpan,
    kNATravPeerMaximumJsonConstructionUnits>
    revision_0483_fixed_capability_span_storage;
thread_local std::size_t revision_0483_fixed_capability_span_count{0U};
#endif

#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST)
thread_local bool use_revision_0484_geometric_capability_span_storage = false;
#endif
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
thread_local bool use_revision_0485_uniform_capability_span_storage = false;
#endif
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
thread_local bool use_revision_0486_eager_capability_span_directory = false;
#endif

void begin_capability_span_storage_decode() noexcept {
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_STORAGE_TEST
    if (use_revision_0483_fixed_capability_span_storage) {
        revision_0483_fixed_capability_span_count = 0U;
    }
#endif
}

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_STORAGE_TEST
[[nodiscard]] bool force_capability_span_spill_for_test() noexcept {
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_STORAGE_SENSITIVITY
    return true;
#else
    return false;
#endif
}
#endif

#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST)
[[nodiscard]] bool use_historical_geometric_capability_span_storage() noexcept {
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_SENSITIVITY
    return true;
#else
    return use_revision_0484_geometric_capability_span_storage;
#endif
}
#endif

#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
[[nodiscard]] bool use_historical_uniform_capability_span_storage() noexcept {
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_SENSITIVITY
    return true;
#else
    return use_revision_0485_uniform_capability_span_storage;
#endif
}
#endif

#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
[[nodiscard]] bool use_historical_eager_capability_span_directory() noexcept {
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_SENSITIVITY
    return true;
#else
    return use_revision_0486_eager_capability_span_directory;
#endif
}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_STORAGE_TEST
// Exact revision-0484 implementation retained for its inherited opt-in
// regression. Production and the revision-0485 regression use the chunked
// implementation below.
class CanonicalCapabilityEntrySpanStorage final {
public:
    CanonicalCapabilityEntrySpanStorage() noexcept {
        note_capability_span_storage_instance();
    }

    [[nodiscard]] bool append(const CanonicalCapabilityEntrySpan value) {
        if (use_revision_0483_fixed_capability_span_storage) {
            if (revision_0483_fixed_capability_span_count >=
                revision_0483_fixed_capability_span_storage.size()) {
                return false;
            }
            revision_0483_fixed_capability_span_storage[
                revision_0483_fixed_capability_span_count++] = value;
            note_historical_capability_span_append();
            return true;
        }
        if (size() >= kNATravPeerMaximumJsonConstructionUnits) {
            return false;
        }
        if (spill_.empty() &&
            !force_capability_span_spill_for_test() &&
            inline_size_ < inline_.size()) {
            inline_[inline_size_++] = value;
            note_capability_span_inline_append();
            return true;
        }
        if (spill_.empty()) {
            note_capability_span_spill_activation();
        }
        if (spill_.size() == spill_.capacity()) {
            const std::size_t maximum_spill =
                kNATravPeerMaximumJsonConstructionUnits - inline_size_;
            const std::size_t doubled = spill_.capacity() == 0U ?
                kNATravPeerInlineCapabilitySpanCapacity :
                spill_.capacity() * 2U;
            const std::size_t next_capacity =
                std::min(maximum_spill, doubled);
            spill_.reserve(next_capacity);
            note_capability_span_spill_reservation(next_capacity);
        }
        spill_.push_back(value);
        note_capability_span_spill_append();
        return true;
    }

    [[nodiscard]] std::size_t size() const noexcept {
        if (use_revision_0483_fixed_capability_span_storage) {
            return revision_0483_fixed_capability_span_count;
        }
        return inline_size_ + spill_.size();
    }

    [[nodiscard]] CanonicalCapabilityEntrySpan at(
        const std::size_t index) const noexcept {
        if (use_revision_0483_fixed_capability_span_storage) {
            note_historical_capability_span_read();
            return revision_0483_fixed_capability_span_storage[index];
        }
        if (index < inline_size_) {
            note_capability_span_inline_read();
            return inline_[index];
        }
        note_capability_span_spill_read();
        return spill_[index - inline_size_];
    }

    [[nodiscard]] std::size_t inline_size() const noexcept {
        return inline_size_;
    }

    [[nodiscard]] std::size_t spill_size() const noexcept {
        return spill_.size();
    }

    [[nodiscard]] std::size_t spill_capacity() const noexcept {
        return spill_.capacity();
    }

private:
    std::array<
        CanonicalCapabilityEntrySpan,
        kNATravPeerInlineCapabilitySpanCapacity> inline_{};
    std::size_t inline_size_{0U};
    std::vector<CanonicalCapabilityEntrySpan> spill_;
};
#else
class CanonicalCapabilityEntrySpanStorage final {
private:
    using ChunkOwner = std::unique_ptr<CanonicalCapabilityEntrySpan[]>;
    using TailOwnerDirectory = std::array<
        ChunkOwner,
        kNATravPeerCapabilitySpanLazyTailOwnerCount>;

public:
    CanonicalCapabilityEntrySpanStorage() noexcept
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
        : historical_(historical_mode())
#endif
    {
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
        if (historical_) {
            note_historical_capability_span_storage_instance();
        } else {
            note_current_capability_span_storage_instance();
        }
#else
        note_current_capability_span_storage_instance();
#endif
    }

    [[nodiscard]] bool append(const CanonicalCapabilityEntrySpan value) {
        if (size() >= kNATravPeerMaximumJsonConstructionUnits) {
            return false;
        }
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
        if (historical_) {
            return append_historical(value);
        }
#endif
        if (spill_size_ == 0U && inline_size_ < inline_.size()) {
            inline_[inline_size_++] = value;
            note_current_capability_span_inline_append();
            return true;
        }
        if (spill_size_ == 0U) {
            note_current_capability_span_chunk_activation();
        }
        const auto location = spill_location(spill_size_);
        const std::size_t chunk_index = location.first;
        const std::size_t chunk_offset = location.second;
        ensure_current_chunk(chunk_index);
        current_chunk(chunk_index)[chunk_offset] = value;
        ++spill_size_;
        note_current_capability_span_chunk_append();
        return true;
    }

    [[nodiscard]] std::size_t size() const noexcept {
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST)
        if (historical_) {
            return inline_size_ + historical_spill_.size();
        }
#elif defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
        if (historical_) {
            return inline_size_ + historical_spill_size_;
        }
#endif
        return inline_size_ + spill_size_;
    }

    [[nodiscard]] CanonicalCapabilityEntrySpan at(
        const std::size_t index) const noexcept {
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST)
        if (historical_) {
            note_historical_chunk_storage_read();
            if (index < inline_size_) {
                return inline_[index];
            }
            return historical_spill_[index - inline_size_];
        }
#elif defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
        if (historical_) {
            note_historical_chunk_storage_read();
            if (index < inline_size_) {
                return inline_[index];
            }
            const auto location = revision_0485_spill_location(
                index - inline_size_);
            return historical_spill_chunks_[location.first][location.second];
        }
#elif defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
        if (historical_) {
            note_historical_chunk_storage_read();
            if (index < inline_size_) {
                return inline_[index];
            }
            const auto location = spill_location(index - inline_size_);
            return historical_spill_chunks_[location.first][location.second];
        }
#endif
        if (index < inline_size_) {
            note_current_capability_span_inline_read();
            return inline_[index];
        }
        note_current_capability_span_chunk_read();
        const auto location = spill_location(index - inline_size_);
        return current_chunk(location.first)[location.second];
    }

    [[nodiscard]] std::size_t inline_size() const noexcept {
        return inline_size_;
    }

    [[nodiscard]] std::size_t spill_size() const noexcept {
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST)
        if (historical_) {
            return historical_spill_.size();
        }
#elif defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
        if (historical_) {
            return historical_spill_size_;
        }
#endif
        return spill_size_;
    }

    [[nodiscard]] std::size_t spill_chunk_count() const noexcept {
        const std::size_t entries = spill_size();
        if (entries == 0U) {
            return 0U;
        }
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
        if (historical_) {
            return revision_0485_chunk_count_for(entries);
        }
#endif
        return chunk_count_for(entries);
    }

    [[nodiscard]] std::size_t spill_allocated_capacity() const noexcept {
        const std::size_t chunks = spill_chunk_count();
        std::size_t capacity = 0U;
        for (std::size_t index = 0U; index < chunks; ++index) {
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
            capacity += historical_ ?
                revision_0485_chunk_capacity(index) : chunk_capacity(index);
#else
            capacity += chunk_capacity(index);
#endif
        }
        return capacity;
    }

    [[nodiscard]] std::size_t maximum_chunk_capacity() const noexcept {
        const std::size_t chunks = spill_chunk_count();
        std::size_t maximum = 0U;
        for (std::size_t index = 0U; index < chunks; ++index) {
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
            const std::size_t capacity = historical_ ?
                revision_0485_chunk_capacity(index) : chunk_capacity(index);
#else
            const std::size_t capacity = chunk_capacity(index);
#endif
            maximum = std::max(maximum, capacity);
        }
        return maximum;
    }

    [[nodiscard]] bool tail_owner_directory_materialized() const noexcept {
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
        return false;
#else
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_FUSED_TAIL_TEST
        if (unfused_tail_for_test_) {
            return static_cast<bool>(unfused_tail_spill_chunks_);
        }
#endif
        return static_cast<bool>(tail_spill_chunks_);
#endif
    }

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_FUSED_TAIL_TEST
    // Test-only address observation: prove nonrelocation, not just value equality.
    [[nodiscard]] const CanonicalCapabilityEntrySpan* address_for_test(
        const std::size_t index) const noexcept {
        if (index < inline_size_) {
            return &inline_[index];
        }
        const auto location = spill_location(index - inline_size_);
        return current_chunk(location.first) + location.second;
    }
#endif

private:
    [[nodiscard]] static bool historical_mode() noexcept {
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST)
        return use_historical_geometric_capability_span_storage();
#elif defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
        return use_historical_uniform_capability_span_storage();
#elif defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
        return use_historical_eager_capability_span_directory();
#else
        return false;
#endif
    }

    [[nodiscard]] static constexpr std::size_t chunk_capacity(
        const std::size_t chunk_index) noexcept {
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST)
        return chunk_index == 0U ?
            kNATravPeerFirstCapabilitySpanChunkCapacity :
            kNATravPeerCapabilitySpanTailChunkCapacity;
#else
        return kNATravPeerCapabilitySpanChunkCapacities[chunk_index];
#endif
    }

    [[nodiscard]] static constexpr std::size_t chunk_count_for(
        const std::size_t entries) noexcept {
        std::size_t remaining = entries;
        std::size_t chunks = 0U;
        while (remaining > 0U && chunks < kNATravPeerCapabilitySpanChunkCount) {
            const std::size_t capacity = chunk_capacity(chunks);
            remaining = remaining > capacity ? remaining - capacity : 0U;
            ++chunks;
        }
        return chunks;
    }

    [[nodiscard]] static constexpr std::pair<std::size_t, std::size_t>
    spill_location(const std::size_t spill_index) noexcept {
        std::size_t remaining = spill_index;
        for (std::size_t chunk_index = 0U;
             chunk_index < kNATravPeerCapabilitySpanChunkCount;
             ++chunk_index) {
            const std::size_t capacity = chunk_capacity(chunk_index);
            if (remaining < capacity) {
                return {chunk_index, remaining};
            }
            remaining -= capacity;
        }
        return {kNATravPeerCapabilitySpanChunkCount, 0U};
    }

    [[nodiscard]] CanonicalCapabilityEntrySpan* current_chunk(
        const std::size_t chunk_index) noexcept {
        return const_cast<CanonicalCapabilityEntrySpan*>(
            std::as_const(*this).current_chunk(chunk_index));
    }

    [[nodiscard]] const CanonicalCapabilityEntrySpan* current_chunk(
        const std::size_t chunk_index) const noexcept {
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
        return spill_chunks_[chunk_index].get();
#else
        if (chunk_index < kNATravPeerCapabilitySpanEarlyOwnerCount) {
            return early_spill_chunks_[chunk_index].get();
        }
        const std::size_t tail_index =
            chunk_index - kNATravPeerCapabilitySpanEarlyOwnerCount;
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
        return (*tail_spill_chunks_)[tail_index].get();
#else
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_FUSED_TAIL_TEST
        if (unfused_tail_for_test_) {
            return (*unfused_tail_spill_chunks_)[tail_index].get();
        }
#endif
        return tail_index == 0U ? tail_spill_chunks_->first_chunk.data() :
            tail_spill_chunks_->later_chunks[tail_index - 1U].get();
#endif
#endif
    }

    void ensure_current_chunk(const std::size_t chunk_index) {
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
        ChunkOwner& owner = spill_chunks_[chunk_index];
        if (!owner) {
            const std::size_t capacity = chunk_capacity(chunk_index);
            ChunkOwner chunk(new CanonicalCapabilityEntrySpan[capacity]);
            owner = std::move(chunk);
            note_current_capability_span_chunk_allocation(capacity);
        }
#else
        const std::size_t capacity = chunk_capacity(chunk_index);
        if (chunk_index < kNATravPeerCapabilitySpanEarlyOwnerCount) {
            ChunkOwner& owner = early_spill_chunks_[chunk_index];
            if (!owner) {
                ChunkOwner chunk(new CanonicalCapabilityEntrySpan[capacity]);
                owner = std::move(chunk);
                note_current_capability_span_chunk_allocation(capacity);
            }
            return;
        }

#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
        const std::size_t tail_index =
            chunk_index - kNATravPeerCapabilitySpanEarlyOwnerCount;
        if (!tail_spill_chunks_) {
            std::unique_ptr<TailOwnerDirectory> directory(
                new TailOwnerDirectory{});
            ChunkOwner chunk(new CanonicalCapabilityEntrySpan[capacity]);
            (*directory)[tail_index] = std::move(chunk);
            tail_spill_chunks_ = std::move(directory);
            note_current_capability_span_tail_directory_allocation();
            note_current_capability_span_chunk_allocation(capacity);
            return;
        }
        ChunkOwner& owner = (*tail_spill_chunks_)[tail_index];
        if (!owner) {
            ChunkOwner chunk(new CanonicalCapabilityEntrySpan[capacity]);
            owner = std::move(chunk);
            note_current_capability_span_chunk_allocation(capacity);
        }
#else
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_FUSED_TAIL_TEST
        if (unfused_tail_for_test_) {
            const std::size_t tail_index =
                chunk_index - kNATravPeerCapabilitySpanEarlyOwnerCount;
            if (!unfused_tail_spill_chunks_) {
                std::unique_ptr<TailOwnerDirectory> directory(
                    new TailOwnerDirectory{});
                ChunkOwner chunk(new CanonicalCapabilityEntrySpan[capacity]);
                (*directory)[tail_index] = std::move(chunk);
                unfused_tail_spill_chunks_ = std::move(directory);
                note_current_capability_span_tail_directory_allocation();
                note_current_capability_span_chunk_allocation(capacity);
                return;
            }
            ChunkOwner& owner = (*unfused_tail_spill_chunks_)[tail_index];
            if (!owner) {
                ChunkOwner chunk(new CanonicalCapabilityEntrySpan[capacity]);
                owner = std::move(chunk);
                note_current_capability_span_chunk_allocation(capacity);
            }
            return;
        }
#endif
        if (!tail_spill_chunks_) {
            // Construct locally, then commit once. A failed allocation leaves
            // all sizes, prior spans, and ownership unchanged. Append is
            // sequential, so this branch activates exactly the first tail.
            auto block = std::unique_ptr<CanonicalCapabilitySpanTailActivationBlock>(
                new CanonicalCapabilitySpanTailActivationBlock);
            tail_spill_chunks_ = std::move(block);
            note_current_capability_span_tail_directory_allocation();
            note_current_capability_span_chunk_allocation(capacity);
            return;
        }
        const std::size_t tail_index =
            chunk_index - kNATravPeerCapabilitySpanEarlyOwnerCount;
        if (tail_index == 0U) {
            return;
        }
        ChunkOwner& owner = tail_spill_chunks_->later_chunks[tail_index - 1U];
        if (!owner) {
            ChunkOwner chunk(new CanonicalCapabilityEntrySpan[capacity]);
            owner = std::move(chunk);
            note_current_capability_span_chunk_allocation(capacity);
        }
#endif
#endif
    }

#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
    [[nodiscard]] static constexpr std::size_t revision_0485_chunk_capacity(
        const std::size_t chunk_index) noexcept {
        return chunk_index == 0U ?
            kNATravPeerFirstCapabilitySpanChunkCapacity :
            kNATravPeerCapabilitySpanTailChunkCapacity;
    }

    [[nodiscard]] static constexpr std::size_t revision_0485_chunk_count_for(
        const std::size_t entries) noexcept {
        if (entries == 0U) {
            return 0U;
        }
        if (entries <= kNATravPeerFirstCapabilitySpanChunkCapacity) {
            return 1U;
        }
        const std::size_t tail_entries =
            entries - kNATravPeerFirstCapabilitySpanChunkCapacity;
        return 1U +
            (tail_entries + kNATravPeerCapabilitySpanTailChunkCapacity - 1U) /
                kNATravPeerCapabilitySpanTailChunkCapacity;
    }

    [[nodiscard]] static constexpr std::pair<std::size_t, std::size_t>
    revision_0485_spill_location(const std::size_t spill_index) noexcept {
        if (spill_index < kNATravPeerFirstCapabilitySpanChunkCapacity) {
            return {0U, spill_index};
        }
        const std::size_t tail_index =
            spill_index - kNATravPeerFirstCapabilitySpanChunkCapacity;
        return {
            1U + tail_index / kNATravPeerCapabilitySpanTailChunkCapacity,
            tail_index % kNATravPeerCapabilitySpanTailChunkCapacity,
        };
    }
#endif

#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST)
    [[nodiscard]] bool append_historical(
        const CanonicalCapabilityEntrySpan value) {
        if (historical_spill_.empty() && inline_size_ < inline_.size()) {
            inline_[inline_size_++] = value;
            note_historical_chunk_storage_append();
            return true;
        }
        if (historical_spill_.size() == historical_spill_.capacity()) {
            const std::size_t maximum_spill =
                kNATravPeerMaximumJsonConstructionUnits - inline_size_;
            const std::size_t doubled = historical_spill_.capacity() == 0U ?
                kNATravPeerInlineCapabilitySpanCapacity :
                historical_spill_.capacity() * 2U;
            const std::size_t next_capacity =
                std::min(maximum_spill, doubled);
            const std::size_t relocated = historical_spill_.size();
            historical_spill_.reserve(next_capacity);
            note_historical_chunk_storage_reservation(
                next_capacity, relocated);
        }
        historical_spill_.push_back(value);
        note_historical_chunk_storage_append();
        return true;
    }
#elif defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
    [[nodiscard]] bool append_historical(
        const CanonicalCapabilityEntrySpan value) {
        if (historical_spill_size_ == 0U && inline_size_ < inline_.size()) {
            inline_[inline_size_++] = value;
            note_historical_chunk_storage_append();
            return true;
        }
        const auto location = revision_0485_spill_location(
            historical_spill_size_);
        const std::size_t chunk_index = location.first;
        const std::size_t chunk_offset = location.second;
        if (!historical_spill_chunks_[chunk_index]) {
            const std::size_t capacity =
                revision_0485_chunk_capacity(chunk_index);
            ChunkOwner chunk(new CanonicalCapabilityEntrySpan[capacity]);
            historical_spill_chunks_[chunk_index] = std::move(chunk);
            note_historical_chunk_storage_reservation(capacity, 0U);
        }
        historical_spill_chunks_[chunk_index][chunk_offset] = value;
        ++historical_spill_size_;
        note_historical_chunk_storage_append();
        return true;
    }
#elif defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
    [[nodiscard]] bool append_historical(
        const CanonicalCapabilityEntrySpan value) {
        if (historical_spill_size_ == 0U && inline_size_ < inline_.size()) {
            inline_[inline_size_++] = value;
            note_historical_chunk_storage_append();
            return true;
        }
        const auto location = spill_location(historical_spill_size_);
        const std::size_t chunk_index = location.first;
        const std::size_t chunk_offset = location.second;
        if (!historical_spill_chunks_[chunk_index]) {
            const std::size_t capacity = chunk_capacity(chunk_index);
            ChunkOwner chunk(new CanonicalCapabilityEntrySpan[capacity]);
            historical_spill_chunks_[chunk_index] = std::move(chunk);
            note_historical_chunk_storage_reservation(capacity, 0U);
        }
        historical_spill_chunks_[chunk_index][chunk_offset] = value;
        ++historical_spill_size_;
        note_historical_chunk_storage_append();
        return true;
    }
#endif

#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
    bool historical_{false};
#endif
    std::array<
        CanonicalCapabilityEntrySpan,
        kNATravPeerInlineCapabilitySpanCapacity> inline_{};
    std::size_t inline_size_{0U};
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST) || \
    defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
    std::array<ChunkOwner, kNATravPeerCapabilitySpanChunkCount> spill_chunks_{};
#else
    std::array<ChunkOwner, kNATravPeerCapabilitySpanEarlyOwnerCount>
        early_spill_chunks_{};
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
    std::unique_ptr<TailOwnerDirectory> tail_spill_chunks_;
#else
    std::unique_ptr<CanonicalCapabilitySpanTailActivationBlock> tail_spill_chunks_;
#endif
#endif
    std::size_t spill_size_{0U};
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_FUSED_TAIL_TEST
    bool unfused_tail_for_test_{use_historical_unfused_tail_activation()};
    std::unique_ptr<TailOwnerDirectory> unfused_tail_spill_chunks_;
#endif
#if defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST)
    std::vector<CanonicalCapabilityEntrySpan> historical_spill_;
#elif defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST)
    std::array<
        ChunkOwner,
        kNATravPeerRevision0485CapabilitySpanChunkCount>
        historical_spill_chunks_{};
    std::size_t historical_spill_size_{0U};
#elif defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST)
    std::array<ChunkOwner, kNATravPeerTieredCapabilitySpanChunkCount>
        historical_spill_chunks_{};
    std::size_t historical_spill_size_{0U};
#endif
};
#endif

struct CanonicalCapabilityFieldIndex final {
    bool array_seen{false};
    bool valid{true};
    bool spans_complete{true};
    std::size_t count{0U};
    std::size_t span_begin{0U};
    std::size_t span_count{0U};
    std::string_view previous;
    std::optional<bool> ready;
};

struct CanonicalMessagePreflightObservation final {
    JsonValue::Kind root_kind{JsonValue::Kind::null_value};
    bool canonical{true};
    std::size_t maximum_depth{0U};
    std::size_t value_count{0U};
    std::size_t object_key_count{0U};
    CanonicalMessageFieldSpans fields;
    CanonicalProtocolFieldSpans protocol;
    CanonicalArtifactFieldSpans artifact;
    CanonicalCapabilityFieldIndex available_capabilities;
    CanonicalCapabilityFieldIndex required_capabilities;
    CanonicalCapabilityEntrySpanStorage capability_entry_spans;

    [[nodiscard]] bool tree_admissible() const noexcept {
        return maximum_depth <= kNATravPeerMaximumJsonTreeDepth &&
            value_count <= kNATravPeerMaximumJsonTreeValues &&
            object_key_count <=
                kNATravPeerMaximumJsonConstructionUnits - value_count;
    }
};

#if !defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_STORAGE_TEST) && \
    !defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST) && \
    !defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST) && \
    !defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST) && \
    !defined(DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_FUSED_TAIL_TEST)
static_assert(sizeof(CanonicalCapabilityEntrySpanStorage) == 320U);
static_assert(sizeof(CanonicalMessagePreflightObservation) == 1272U);
static_assert(sizeof(CanonicalCapabilitySpanTailActivationBlock) == 8176U);
#endif


struct JsonStringTokenParseResult final {
    std::string_view token;
    bool canonical{true};
    std::size_t decoded_bytes{0U};
    std::optional<bool> fixed_ascii_predicate;
    std::optional<NATravPeerHandshakeMessageKind> message_kind_discriminant;
    std::optional<bool> protocol_id_discriminant;
};

enum class CanonicalFixedAsciiPredicate {
    none,
    lower_hex_sha256,
    capability_token,
};

class CanonicalFixedAsciiPredicateAccumulator final {
public:
    explicit CanonicalFixedAsciiPredicateAccumulator(
        const CanonicalFixedAsciiPredicate predicate) noexcept :
        predicate_(predicate) {}

    void observe(const std::uint32_t code_point) noexcept {
        if (predicate_ == CanonicalFixedAsciiPredicate::none) {
            return;
        }
        ++characters_;
        if (code_point > 0x7FU) {
            valid_ = false;
            previous_underscore_ = false;
            last_underscore_ = false;
            return;
        }
        const char character = static_cast<char>(code_point);
        if (predicate_ == CanonicalFixedAsciiPredicate::lower_hex_sha256) {
            const bool digit = character >= '0' && character <= '9';
            const bool lower_hex = character >= 'a' && character <= 'f';
            valid_ = valid_ && (digit || lower_hex);
            return;
        }

        const bool uppercase = character >= 'A' && character <= 'Z';
        const bool digit = character >= '0' && character <= '9';
        const bool underscore = character == '_';
        if (!uppercase && !digit && !underscore) {
            valid_ = false;
        }
        if (characters_ == 1U && !uppercase) {
            valid_ = false;
        }
        if (underscore && previous_underscore_) {
            valid_ = false;
        }
        previous_underscore_ = underscore;
        last_underscore_ = underscore;
    }

    [[nodiscard]] std::optional<bool> result() const noexcept {
        switch (predicate_) {
            case CanonicalFixedAsciiPredicate::none:
                return std::nullopt;
            case CanonicalFixedAsciiPredicate::lower_hex_sha256:
                return valid_ && characters_ == 64U;
            case CanonicalFixedAsciiPredicate::capability_token:
                return valid_ && characters_ != 0U && characters_ <= 64U &&
                    !last_underscore_;
        }
        return false;
    }

private:
    CanonicalFixedAsciiPredicate predicate_;
    std::size_t characters_{0U};
    bool valid_{true};
    bool previous_underscore_{false};
    bool last_underscore_{false};
};

enum class CanonicalStringDiscriminant {
    none,
    message_kind,
    protocol_id,
};

class CanonicalStringDiscriminantAccumulator final {
public:
    explicit CanonicalStringDiscriminantAccumulator(
        const CanonicalStringDiscriminant discriminant) noexcept :
        discriminant_(discriminant) {}

    void observe(const std::uint32_t code_point) noexcept {
        if (discriminant_ == CanonicalStringDiscriminant::none) {
            return;
        }
        const std::size_t index = characters_++;
        if (discriminant_ == CanonicalStringDiscriminant::message_kind) {
            hello_ = hello_ && matches("HELLO", index, code_point);
            hello_ack_ = hello_ack_ &&
                matches("HELLO_ACK", index, code_point);
            error_ = error_ && matches("ERROR", index, code_point);
            return;
        }
        protocol_id_ = protocol_id_ &&
            matches("NATRAV_OVERLAY_PEER", index, code_point);
    }

    [[nodiscard]] std::optional<NATravPeerHandshakeMessageKind>
    message_kind_result() const noexcept {
        if (discriminant_ != CanonicalStringDiscriminant::message_kind) {
            return std::nullopt;
        }
        if (hello_ && characters_ == std::string_view("HELLO").size()) {
            return NATravPeerHandshakeMessageKind::hello;
        }
        if (hello_ack_ &&
            characters_ == std::string_view("HELLO_ACK").size()) {
            return NATravPeerHandshakeMessageKind::hello_ack;
        }
        if (error_ && characters_ == std::string_view("ERROR").size()) {
            return NATravPeerHandshakeMessageKind::error;
        }
        return NATravPeerHandshakeMessageKind::unknown;
    }

    [[nodiscard]] std::optional<bool> protocol_id_result() const noexcept {
        if (discriminant_ != CanonicalStringDiscriminant::protocol_id) {
            return std::nullopt;
        }
        return protocol_id_ &&
            characters_ == std::string_view("NATRAV_OVERLAY_PEER").size();
    }

private:
    [[nodiscard]] static bool matches(
        const std::string_view expected,
        const std::size_t index,
        const std::uint32_t code_point) noexcept {
        return index < expected.size() && code_point <= 0x7FU &&
            static_cast<unsigned char>(expected[index]) ==
                static_cast<unsigned char>(code_point);
    }

    CanonicalStringDiscriminant discriminant_;
    std::size_t characters_{0U};
    bool hello_{true};
    bool hello_ack_{true};
    bool error_{true};
    bool protocol_id_{true};
};

[[nodiscard]] JsonStringTokenParseResult parse_json_string_token_checked(
    const std::string_view text,
    std::size_t& offset,
    const CanonicalFixedAsciiPredicate fixed_ascii_predicate =
        CanonicalFixedAsciiPredicate::none,
    const CanonicalStringDiscriminant string_discriminant =
        CanonicalStringDiscriminant::none) {
    if (offset >= text.size() || text[offset] != '"') {
        fail("natrav-peer-message-json-character", "payload");
    }
    const std::size_t begin = offset++;
    bool canonical = true;
    std::size_t decoded_bytes = 0U;
    CanonicalFixedAsciiPredicateAccumulator predicate(
        fixed_ascii_predicate);
    CanonicalStringDiscriminantAccumulator discriminant(
        string_discriminant);
    while (true) {
        const JsonStringScalar scalar =
            parse_json_string_scalar(text, offset);
        if (scalar.end) {
            return JsonStringTokenParseResult{
                .token = text.substr(begin, offset - begin),
                .canonical = canonical,
                .decoded_bytes = decoded_bytes,
                .fixed_ascii_predicate = predicate.result(),
                .message_kind_discriminant =
                    discriminant.message_kind_result(),
                .protocol_id_discriminant =
                    discriminant.protocol_id_result(),
            };
        }
        predicate.observe(scalar.code_point);
        discriminant.observe(scalar.code_point);
        canonical = canonical &&
            json_string_scalar_is_canonical(text, scalar);
        std::array<unsigned char, 4U> encoded{};
        decoded_bytes += encode_utf8_scalar(
            scalar.code_point, encoded.data());
    }
}

class DecodedJsonStringByteCursor final {
public:
    explicit DecodedJsonStringByteCursor(
        const std::string_view token) noexcept :
        token_(token), offset_(1U) {}

    [[nodiscard]] bool next(unsigned char& output) {
        if (pending_offset_ < pending_size_) {
            output = pending_[pending_offset_++];
            return true;
        }
        const JsonStringScalar scalar =
            parse_json_string_scalar(token_, offset_);
        if (scalar.end) {
            return false;
        }
        pending_size_ = encode_utf8_scalar(
            scalar.code_point, pending_.data());
        output = pending_[0U];
        pending_offset_ = 1U;
        return true;
    }

private:
    std::string_view token_;
    std::size_t offset_{0U};
    std::array<unsigned char, 4U> pending_{};
    std::size_t pending_offset_{0U};
    std::size_t pending_size_{0U};
};

[[nodiscard]] int compare_decoded_json_string_tokens(
    const std::string_view left,
    const std::string_view right) {
    DecodedJsonStringByteCursor left_cursor(left);
    DecodedJsonStringByteCursor right_cursor(right);
    while (true) {
        unsigned char left_byte = 0U;
        unsigned char right_byte = 0U;
        const bool has_left = left_cursor.next(left_byte);
        const bool has_right = right_cursor.next(right_byte);
        if (!has_left || !has_right) {
            if (has_left == has_right) {
                return 0;
            }
            return has_left ? 1 : -1;
        }
        if (left_byte < right_byte) {
            return -1;
        }
        if (left_byte > right_byte) {
            return 1;
        }
    }
}

class CanonicalMessagePreflight final {
public:
    explicit CanonicalMessagePreflight(const std::string_view text) noexcept :
        text_(text) {
        begin_capability_span_storage_decode();
    }

    [[nodiscard]] const CanonicalMessagePreflightObservation& inspect() {
        skip_whitespace();
        parse_value(ValueCapture::none);
        while (!root_complete_) {
            if (frames_empty()) {
                fail("natrav-peer-message-json-preflight-state", "payload");
            }
            process_frame();
        }
        skip_whitespace();
        if (offset_ != text_.size()) {
            fail("natrav-peer-message-json-trailing", "payload");
        }
        observation_.root_kind = root_kind_;
        observation_.canonical = canonical_;
        observation_.maximum_depth = maximum_depth_;
        observation_.value_count = value_count_;
        observation_.object_key_count = object_key_count_;
        return observation_;
    }

private:
    enum class FrameKind {
        array,
        object,
    };

    enum class FrameState {
        array_value_or_end,
        array_comma_or_end,
        object_key_or_end,
        object_colon,
        object_value,
        object_comma_or_end,
    };

    enum class ObjectRole {
        generic,
        root,
        protocol,
        artifact,
    };

    enum class ArrayRole {
        generic,
        available_capabilities,
        required_capabilities,
    };

    enum class ValueCapture {
        none,
        root_artifact,
        root_available_capabilities,
        root_code,
        root_kind,
        root_message,
        root_protocol,
        root_request_id,
        root_required_capabilities,
        protocol_id,
        protocol_major,
        protocol_minor,
        artifact_sha256,
        artifact_target,
        artifact_version,
        available_capability_entry,
        required_capability_entry,
    };

    struct Frame final {
        FrameKind kind{FrameKind::array};
        FrameState state{FrameState::array_value_or_end};
        ValueCapture completion_capture{ValueCapture::none};
        ObjectRole object_role{ObjectRole::generic};
        ArrayRole array_role{ArrayRole::generic};
        std::size_t begin{0U};
    };

    class KeyCollection final {
    public:
        void reset(
            std::string_view* const inline_data,
            const std::size_t inline_capacity) {
            inline_data_ = inline_data;
            inline_capacity_ = inline_capacity;
            size_ = 0U;
            overflow_.clear();
        }

        void push(const std::string_view key) {
            if (overflow_.empty() && size_ < inline_capacity_) {
                inline_data_[size_++] = key;
                return;
            }
            if (overflow_.empty()) {
                const std::size_t initial_capacity =
                    std::max<std::size_t>(inline_capacity_ * 2U, 8U);
                overflow_.reserve(initial_capacity);
                for (std::size_t index = 0U; index < size_; ++index) {
                    overflow_.push_back(inline_data_[index]);
                }
            }
            overflow_.push_back(key);
            size_ = overflow_.size();
        }

        [[nodiscard]] bool has_duplicate() {
            const auto less = [](
                const std::string_view left,
                const std::string_view right) {
                return compare_decoded_json_string_tokens(left, right) < 0;
            };
            if (overflow_.empty()) {
                std::sort(inline_data_, inline_data_ + size_, less);
                for (std::size_t index = 1U; index < size_; ++index) {
                    if (compare_decoded_json_string_tokens(
                            inline_data_[index - 1U], inline_data_[index]) == 0) {
                        return true;
                    }
                }
                return false;
            }
            std::sort(overflow_.begin(), overflow_.end(), less);
            for (std::size_t index = 1U;
                 index < overflow_.size(); ++index) {
                if (compare_decoded_json_string_tokens(
                        overflow_[index - 1U], overflow_[index]) == 0) {
                    return true;
                }
            }
            return false;
        }

    private:
        std::string_view* inline_data_{nullptr};
        std::size_t inline_capacity_{0U};
        std::size_t size_{0U};
        std::vector<std::string_view> overflow_;
    };

    struct ObjectState final {
        ObjectRole role{ObjectRole::generic};
        ValueCapture pending_capture{ValueCapture::none};
        std::string_view previous_key;
        KeyCollection keys;
    };

    [[nodiscard]] bool at_end() const noexcept {
        return offset_ >= text_.size();
    }

    void skip_whitespace() noexcept {
        const std::size_t before = offset_;
        while (!at_end()) {
            const char character = text_[offset_];
            if (character != ' ' && character != '\t' &&
                character != '\n' && character != '\r') {
                break;
            }
            ++offset_;
        }
        if (offset_ != before) {
            canonical_ = false;
        }
    }

    void expect_character(const char expected) {
        if (at_end() || text_[offset_] != expected) {
            fail("natrav-peer-message-json-character", "payload");
        }
        ++offset_;
    }

    void note_root_kind(const JsonValue::Kind kind) noexcept {
        if (!root_started_) {
            root_started_ = true;
            root_kind_ = kind;
        }
    }

    void note_value(const JsonValue::Kind kind) noexcept {
        note_root_kind(kind);
        ++value_count_;
    }

    template <typename OptionalSpan>
    static bool assign_first(
        OptionalSpan& destination,
        const CanonicalJsonSpan value) noexcept {
        if (!destination) {
            destination = value;
            if (value.kind == JsonValue::Kind::string &&
                value.decoded_string_bytes) {
                note_preflight_typed_string_length_capture();
            }
            return true;
        }
        return false;
    }

    void record_capability_entry(
        CanonicalCapabilityFieldIndex& index,
        const CanonicalJsonSpan value) {
        ++index.count;
        if (value.kind == JsonValue::Kind::string &&
            value.decoded_string_bytes) {
            note_preflight_typed_string_length_capture();
        }
        const std::string_view token =
            canonical_ascii_string_contents(value);
        const bool entry_valid =
            value.kind == JsonValue::Kind::string &&
            capability_token(token) &&
            (index.previous.empty() || index.previous < token);
        if (!entry_valid) {
            index.valid = false;
            index.spans_complete = false;
        } else if (index.valid) {
            const std::ptrdiff_t relative = token.data() - text_.data();
            const bool representable = relative >= 0 &&
                static_cast<std::size_t>(relative) <=
                    static_cast<std::size_t>(
                        std::numeric_limits<std::uint16_t>::max()) &&
                token.size() <= static_cast<std::size_t>(
                    std::numeric_limits<std::uint16_t>::max());
            if (!representable ||
                !observation_.capability_entry_spans.append(
                    CanonicalCapabilityEntrySpan{
                        .content_offset = static_cast<std::uint16_t>(relative),
                        .content_size = static_cast<std::uint16_t>(token.size()),
                    })) {
                index.spans_complete = false;
            } else {
                ++index.span_count;
                note_preflight_capability_span_capture();
            }
        }
        index.previous = token;
    }

    void record_shape_kind(
        const ValueCapture capture,
        const JsonValue::Kind kind) noexcept {
        switch (capture) {
            case ValueCapture::root_artifact:
                note_preflight_top_level_kind_update();
                if (kind == JsonValue::Kind::object) {
                    observation_.fields.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.fields.shape.expected_kind_mask |
                            kCanonicalMessageArtifactBit);
                }
                return;
            case ValueCapture::root_available_capabilities:
                note_preflight_top_level_kind_update();
                if (kind == JsonValue::Kind::array) {
                    observation_.fields.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.fields.shape.expected_kind_mask |
                            kCanonicalMessageAvailableCapabilitiesBit);
                }
                return;
            case ValueCapture::root_code:
                note_preflight_top_level_kind_update();
                if (kind == JsonValue::Kind::string) {
                    observation_.fields.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.fields.shape.expected_kind_mask |
                            kCanonicalMessageCodeBit);
                }
                return;
            case ValueCapture::root_kind:
                note_preflight_top_level_kind_update();
                if (kind == JsonValue::Kind::string) {
                    observation_.fields.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.fields.shape.expected_kind_mask |
                            kCanonicalMessageKindBit);
                }
                return;
            case ValueCapture::root_message:
                note_preflight_top_level_kind_update();
                if (kind == JsonValue::Kind::string) {
                    observation_.fields.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.fields.shape.expected_kind_mask |
                            kCanonicalMessageMessageBit);
                }
                return;
            case ValueCapture::root_protocol:
                note_preflight_top_level_kind_update();
                if (kind == JsonValue::Kind::object) {
                    observation_.fields.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.fields.shape.expected_kind_mask |
                            kCanonicalMessageProtocolBit);
                }
                return;
            case ValueCapture::root_request_id:
                note_preflight_top_level_kind_update();
                if (kind == JsonValue::Kind::string) {
                    observation_.fields.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.fields.shape.expected_kind_mask |
                            kCanonicalMessageRequestIdBit);
                }
                return;
            case ValueCapture::root_required_capabilities:
                note_preflight_top_level_kind_update();
                if (kind == JsonValue::Kind::array) {
                    observation_.fields.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.fields.shape.expected_kind_mask |
                            kCanonicalMessageRequiredCapabilitiesBit);
                }
                return;
            case ValueCapture::protocol_id:
                note_preflight_protocol_kind_update();
                if (kind == JsonValue::Kind::string) {
                    observation_.protocol.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.protocol.shape.expected_kind_mask |
                            kCanonicalProtocolIdBit);
                }
                return;
            case ValueCapture::protocol_major:
                note_preflight_protocol_kind_update();
                if (kind == JsonValue::Kind::integer) {
                    observation_.protocol.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.protocol.shape.expected_kind_mask |
                            kCanonicalProtocolMajorBit);
                }
                return;
            case ValueCapture::protocol_minor:
                note_preflight_protocol_kind_update();
                if (kind == JsonValue::Kind::integer) {
                    observation_.protocol.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.protocol.shape.expected_kind_mask |
                            kCanonicalProtocolMinorBit);
                }
                return;
            case ValueCapture::artifact_sha256:
                note_preflight_artifact_kind_update();
                if (kind == JsonValue::Kind::string) {
                    observation_.artifact.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.artifact.shape.expected_kind_mask |
                            kCanonicalArtifactSha256Bit);
                }
                return;
            case ValueCapture::artifact_target:
                note_preflight_artifact_kind_update();
                if (kind == JsonValue::Kind::string) {
                    observation_.artifact.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.artifact.shape.expected_kind_mask |
                            kCanonicalArtifactTargetBit);
                }
                return;
            case ValueCapture::artifact_version:
                note_preflight_artifact_kind_update();
                if (kind == JsonValue::Kind::string) {
                    observation_.artifact.shape.expected_kind_mask =
                        static_cast<std::uint16_t>(
                            observation_.artifact.shape.expected_kind_mask |
                            kCanonicalArtifactVersionBit);
                }
                return;
            case ValueCapture::none:
            case ValueCapture::available_capability_entry:
            case ValueCapture::required_capability_entry:
                return;
        }
    }

    void record_capture(
        const ValueCapture capture,
        const CanonicalJsonSpan value,
        const std::optional<std::int64_t> integer_value = std::nullopt,
        const std::optional<bool> fixed_ascii_predicate = std::nullopt,
        const std::optional<NATravPeerHandshakeMessageKind>
            message_kind_discriminant = std::nullopt,
        const std::optional<bool> protocol_id_discriminant =
            std::nullopt) {
        record_shape_kind(capture, value.kind);
        switch (capture) {
            case ValueCapture::none:
                return;
            case ValueCapture::root_artifact:
                assign_first(observation_.fields.artifact, value);
                return;
            case ValueCapture::root_available_capabilities:
                assign_first(
                    observation_.fields.available_capabilities, value);
                return;
            case ValueCapture::root_code:
                if (assign_first(observation_.fields.code, value)) {
                    observation_.fields.peer_error_code_capability_token =
                        fixed_ascii_predicate.value_or(false);
                    note_preflight_peer_error_code_predicate_capture();
                }
                return;
            case ValueCapture::root_kind:
                if (assign_first(observation_.fields.kind, value)) {
                    observation_.fields.kind_discriminant =
                        message_kind_discriminant;
                    if (message_kind_discriminant) {
                        note_preflight_message_kind_discriminant_capture();
                    }
                }
                return;
            case ValueCapture::root_message:
                if (assign_first(observation_.fields.message, value) &&
                    value.decoded_string_bytes) {
                    observation_.fields.peer_error_message_nonempty =
                        *value.decoded_string_bytes != 0U;
                    note_preflight_peer_error_message_nonempty_capture();
                }
                return;
            case ValueCapture::root_protocol:
                assign_first(observation_.fields.protocol, value);
                return;
            case ValueCapture::root_request_id:
                if (assign_first(observation_.fields.request_id, value)) {
                    observation_.fields.request_id_lower_hex_sha256 =
                        fixed_ascii_predicate.value_or(false);
                    note_preflight_request_id_predicate_capture();
                }
                return;
            case ValueCapture::root_required_capabilities:
                assign_first(
                    observation_.fields.required_capabilities, value);
                return;
            case ValueCapture::protocol_id:
                if (assign_first(observation_.protocol.id, value)) {
                    observation_.protocol.id_matches_natrav_overlay_peer =
                        protocol_id_discriminant;
                    if (protocol_id_discriminant) {
                        note_preflight_protocol_id_discriminant_capture();
                    }
                }
                return;
            case ValueCapture::protocol_major:
                if (!observation_.protocol.major) {
                    observation_.protocol.major = value;
                    observation_.protocol.major_value = integer_value;
                    if (integer_value) {
                        note_preflight_protocol_integer_capture();
                    }
                }
                return;
            case ValueCapture::protocol_minor:
                if (!observation_.protocol.minor) {
                    observation_.protocol.minor = value;
                    observation_.protocol.minor_value = integer_value;
                    if (integer_value) {
                        note_preflight_protocol_integer_capture();
                    }
                }
                return;
            case ValueCapture::artifact_sha256:
                if (assign_first(observation_.artifact.sha256, value)) {
                    observation_.artifact.sha256_lower_hex =
                        fixed_ascii_predicate.value_or(false);
                    note_preflight_artifact_sha256_predicate_capture();
                }
                return;
            case ValueCapture::artifact_target:
                if (assign_first(observation_.artifact.target, value) &&
                    value.decoded_string_bytes) {
                    observation_.artifact.target_nonempty =
                        *value.decoded_string_bytes != 0U;
                    note_preflight_artifact_target_nonempty_capture();
                }
                return;
            case ValueCapture::artifact_version:
                if (assign_first(observation_.artifact.version, value) &&
                    value.decoded_string_bytes) {
                    observation_.artifact.version_nonempty =
                        *value.decoded_string_bytes != 0U;
                    note_preflight_artifact_version_nonempty_capture();
                }
                return;
            case ValueCapture::available_capability_entry:
                record_capability_entry(
                    observation_.available_capabilities, value);
                return;
            case ValueCapture::required_capability_entry:
                record_capability_entry(
                    observation_.required_capabilities, value);
                return;
        }
    }

    void complete_value(
        const ValueCapture capture,
        const JsonValue::Kind kind,
        const std::size_t begin,
        const std::optional<std::int64_t> integer_value = std::nullopt,
        const std::optional<std::size_t> decoded_string_bytes =
            std::nullopt,
        const std::optional<bool> fixed_ascii_predicate = std::nullopt,
        const std::optional<NATravPeerHandshakeMessageKind>
            message_kind_discriminant = std::nullopt,
        const std::optional<bool> protocol_id_discriminant =
            std::nullopt) {
        record_capture(capture, CanonicalJsonSpan{
            .kind = kind,
            .bytes = text_.substr(begin, offset_ - begin),
            .decoded_string_bytes = decoded_string_bytes,
        }, integer_value, fixed_ascii_predicate,
            message_kind_discriminant, protocol_id_discriminant);
        if (frames_empty()) {
            root_complete_ = true;
        }
    }

    [[nodiscard]] ObjectRole object_role_for(
        const ValueCapture capture,
        const bool root) const noexcept {
        if (root) {
            return ObjectRole::root;
        }
        if (capture == ValueCapture::root_protocol) {
            return ObjectRole::protocol;
        }
        if (capture == ValueCapture::root_artifact) {
            return ObjectRole::artifact;
        }
        return ObjectRole::generic;
    }

    [[nodiscard]] ArrayRole array_role_for(
        const ValueCapture capture) const noexcept {
        if (capture == ValueCapture::root_available_capabilities) {
            return ArrayRole::available_capabilities;
        }
        if (capture == ValueCapture::root_required_capabilities) {
            return ArrayRole::required_capabilities;
        }
        return ArrayRole::generic;
    }

    [[nodiscard]] static CanonicalFixedAsciiPredicate
    fixed_ascii_predicate_for(
        const ValueCapture capture) noexcept {
        switch (capture) {
            case ValueCapture::root_request_id:
            case ValueCapture::artifact_sha256:
                return CanonicalFixedAsciiPredicate::lower_hex_sha256;
            case ValueCapture::root_code:
                return CanonicalFixedAsciiPredicate::capability_token;
            case ValueCapture::none:
            case ValueCapture::root_artifact:
            case ValueCapture::root_available_capabilities:
            case ValueCapture::root_kind:
            case ValueCapture::root_message:
            case ValueCapture::root_protocol:
            case ValueCapture::root_required_capabilities:
            case ValueCapture::protocol_id:
            case ValueCapture::protocol_major:
            case ValueCapture::protocol_minor:
            case ValueCapture::artifact_target:
            case ValueCapture::artifact_version:
            case ValueCapture::available_capability_entry:
            case ValueCapture::required_capability_entry:
                return CanonicalFixedAsciiPredicate::none;
        }
        return CanonicalFixedAsciiPredicate::none;
    }

    [[nodiscard]] static CanonicalStringDiscriminant
    string_discriminant_for(const ValueCapture capture) noexcept {
        if (capture == ValueCapture::root_kind) {
            return CanonicalStringDiscriminant::message_kind;
        }
        if (capture == ValueCapture::protocol_id) {
            return CanonicalStringDiscriminant::protocol_id;
        }
        return CanonicalStringDiscriminant::none;
    }

    void begin_capability_array(const ArrayRole role) noexcept {
        CanonicalCapabilityFieldIndex* index = nullptr;
        if (role == ArrayRole::available_capabilities) {
            index = &observation_.available_capabilities;
        } else if (role == ArrayRole::required_capabilities) {
            index = &observation_.required_capabilities;
        }
        if (index != nullptr && !index->array_seen) {
            index->array_seen = true;
            index->valid = true;
            index->spans_complete = true;
            index->count = 0U;
            index->span_begin = observation_.capability_entry_spans.size();
            index->span_count = 0U;
            index->previous = {};
            index->ready.reset();
        }
    }

    void finalize_capability_array(const ArrayRole role) noexcept {
        CanonicalCapabilityFieldIndex* index = nullptr;
        bool available = false;
        if (role == ArrayRole::available_capabilities) {
            index = &observation_.available_capabilities;
            available = true;
        } else if (role == ArrayRole::required_capabilities) {
            index = &observation_.required_capabilities;
        }
        if (index == nullptr || !index->array_seen) {
            return;
        }
        index->ready = index->valid && index->spans_complete &&
            index->span_count == index->count;
        note_preflight_capability_readiness_capture(available);
    }

    [[nodiscard]] ValueCapture capability_entry_capture(
        const ArrayRole role) const noexcept {
        if (role == ArrayRole::available_capabilities) {
            return ValueCapture::available_capability_entry;
        }
        if (role == ArrayRole::required_capabilities) {
            return ValueCapture::required_capability_entry;
        }
        return ValueCapture::none;
    }

    void record_shape_member(
        const ObjectRole role,
        const std::uint16_t bit) noexcept {
        switch (role) {
            case ObjectRole::root:
                observation_.fields.shape.member_mask =
                    static_cast<std::uint16_t>(
                        observation_.fields.shape.member_mask | bit);
                note_preflight_top_level_member_update();
                return;
            case ObjectRole::protocol:
                observation_.protocol.shape.member_mask =
                    static_cast<std::uint16_t>(
                        observation_.protocol.shape.member_mask | bit);
                note_preflight_protocol_member_update();
                return;
            case ObjectRole::artifact:
                observation_.artifact.shape.member_mask =
                    static_cast<std::uint16_t>(
                        observation_.artifact.shape.member_mask | bit);
                note_preflight_artifact_member_update();
                return;
            case ObjectRole::generic:
                return;
        }
    }

    void record_unknown_shape_member(const ObjectRole role) noexcept {
        switch (role) {
            case ObjectRole::root:
                observation_.fields.shape.unknown_member_seen = true;
                return;
            case ObjectRole::protocol:
                observation_.protocol.shape.unknown_member_seen = true;
                return;
            case ObjectRole::artifact:
                observation_.artifact.shape.unknown_member_seen = true;
                return;
            case ObjectRole::generic:
                return;
        }
    }

    [[nodiscard]] ValueCapture capture_for_key(
        const ObjectRole role,
        const std::string_view key) noexcept {
        switch (role) {
            case ObjectRole::root:
                ++observation_.fields.member_count;
                if (key == "\"artifact\"") {
                    record_shape_member(role, kCanonicalMessageArtifactBit);
                    return ValueCapture::root_artifact;
                }
                if (key == "\"available_capabilities\"") {
                    record_shape_member(
                        role, kCanonicalMessageAvailableCapabilitiesBit);
                    return ValueCapture::root_available_capabilities;
                }
                if (key == "\"code\"") {
                    record_shape_member(role, kCanonicalMessageCodeBit);
                    return ValueCapture::root_code;
                }
                if (key == "\"kind\"") {
                    record_shape_member(role, kCanonicalMessageKindBit);
                    return ValueCapture::root_kind;
                }
                if (key == "\"message\"") {
                    record_shape_member(role, kCanonicalMessageMessageBit);
                    return ValueCapture::root_message;
                }
                if (key == "\"protocol\"") {
                    record_shape_member(role, kCanonicalMessageProtocolBit);
                    return ValueCapture::root_protocol;
                }
                if (key == "\"request_id\"") {
                    record_shape_member(role, kCanonicalMessageRequestIdBit);
                    return ValueCapture::root_request_id;
                }
                if (key == "\"required_capabilities\"") {
                    record_shape_member(
                        role, kCanonicalMessageRequiredCapabilitiesBit);
                    return ValueCapture::root_required_capabilities;
                }
                ++observation_.fields.unknown_count;
                record_unknown_shape_member(role);
                return ValueCapture::none;
            case ObjectRole::protocol:
                ++observation_.protocol.member_count;
                if (key == "\"id\"") {
                    record_shape_member(role, kCanonicalProtocolIdBit);
                    return ValueCapture::protocol_id;
                }
                if (key == "\"major\"") {
                    record_shape_member(role, kCanonicalProtocolMajorBit);
                    return ValueCapture::protocol_major;
                }
                if (key == "\"minor\"") {
                    record_shape_member(role, kCanonicalProtocolMinorBit);
                    return ValueCapture::protocol_minor;
                }
                ++observation_.protocol.unknown_count;
                record_unknown_shape_member(role);
                return ValueCapture::none;
            case ObjectRole::artifact:
                ++observation_.artifact.member_count;
                if (key == "\"sha256\"") {
                    record_shape_member(role, kCanonicalArtifactSha256Bit);
                    return ValueCapture::artifact_sha256;
                }
                if (key == "\"target\"") {
                    record_shape_member(role, kCanonicalArtifactTargetBit);
                    return ValueCapture::artifact_target;
                }
                if (key == "\"version\"") {
                    record_shape_member(role, kCanonicalArtifactVersionBit);
                    return ValueCapture::artifact_version;
                }
                ++observation_.artifact.unknown_count;
                record_unknown_shape_member(role);
                return ValueCapture::none;
            case ObjectRole::generic:
                return ValueCapture::none;
        }
        return ValueCapture::none;
    }

    void parse_literal(
        const std::string_view literal,
        const JsonValue::Kind kind,
        const ValueCapture capture,
        const std::size_t begin) {
        if (!text_.substr(offset_).starts_with(literal)) {
            fail("natrav-peer-message-json-literal", "payload");
        }
        offset_ += literal.size();
        note_value(kind);
        complete_value(capture, kind, begin);
    }

    void push_container(
        const Frame frame,
        std::string_view* const key_buffer,
        const std::size_t key_capacity) {
        push_frame(frame);
        if (frame.kind == FrameKind::object) {
            push_object_state(frame.object_role, key_buffer, key_capacity);
        }
        maximum_depth_ = std::max(maximum_depth_, frames_size());
    }

    void parse_value(const ValueCapture capture) {
        if (at_end()) {
            fail("natrav-peer-message-json-value", "payload");
        }
        const std::size_t begin = offset_;
        const bool root = !root_started_;
        switch (text_[offset_]) {
            case '{': {
                ++offset_;
                note_value(JsonValue::Kind::object);
                const ObjectRole role = object_role_for(capture, root);
                std::string_view* key_buffer = nullptr;
                std::size_t key_capacity = 0U;
                if (role == ObjectRole::root) {
                    key_buffer = root_keys_.data();
                    key_capacity = root_keys_.size();
                } else if (role == ObjectRole::protocol) {
                    key_buffer = protocol_keys_.data();
                    key_capacity = protocol_keys_.size();
                } else if (role == ObjectRole::artifact) {
                    key_buffer = artifact_keys_.data();
                    key_capacity = artifact_keys_.size();
                }
                push_container(Frame{
                    .kind = FrameKind::object,
                    .state = FrameState::object_key_or_end,
                    .completion_capture = capture,
                    .object_role = role,
                    .array_role = ArrayRole::generic,
                    .begin = begin,
                }, key_buffer, key_capacity);
                return;
            }
            case '[': {
                ++offset_;
                note_value(JsonValue::Kind::array);
                const ArrayRole role = array_role_for(capture);
                begin_capability_array(role);
                push_container(Frame{
                    .kind = FrameKind::array,
                    .state = FrameState::array_value_or_end,
                    .completion_capture = capture,
                    .object_role = ObjectRole::generic,
                    .array_role = role,
                    .begin = begin,
                }, nullptr, 0U);
                return;
            }
            case '"': {
                const JsonStringTokenParseResult string =
                    parse_json_string_token_checked(
                        text_,
                        offset_,
                        fixed_ascii_predicate_for(capture),
                        string_discriminant_for(capture));
                canonical_ = canonical_ && string.canonical;
                note_value(JsonValue::Kind::string);
                complete_value(
                    capture,
                    JsonValue::Kind::string,
                    begin,
                    std::nullopt,
                    string.decoded_bytes,
                    string.fixed_ascii_predicate,
                    string.message_kind_discriminant,
                    string.protocol_id_discriminant);
                return;
            }
            case 't':
                parse_literal(
                    "true", JsonValue::Kind::boolean, capture, begin);
                return;
            case 'f':
                parse_literal(
                    "false", JsonValue::Kind::boolean, capture, begin);
                return;
            case 'n':
                parse_literal(
                    "null", JsonValue::Kind::null_value, capture, begin);
                return;
            default:
                if (text_[offset_] == '-' ||
                    (text_[offset_] >= '0' && text_[offset_] <= '9')) {
                    const JsonIntegerParseResult integer =
                        parse_json_integer(text_, offset_);
                    canonical_ = canonical_ && integer.canonical;
                    note_value(JsonValue::Kind::integer);
                    complete_value(
                        capture,
                        JsonValue::Kind::integer,
                        begin,
                        integer.value);
                    return;
                }
                fail("natrav-peer-message-json-value", "payload");
        }
    }

    void parse_object_key(ObjectState& state) {
        if (at_end() || text_[offset_] != '"') {
            fail("natrav-peer-message-json-object-key", "payload");
        }
        const JsonStringTokenParseResult key =
            parse_json_string_token_checked(text_, offset_);
        ++object_key_count_;
        canonical_ = canonical_ && key.canonical;
        if (!state.previous_key.empty() &&
            compare_decoded_json_string_tokens(
                state.previous_key, key.token) >= 0) {
            canonical_ = false;
        }
        state.previous_key = key.token;
        state.keys.push(key.token);
        state.pending_capture = capture_for_key(state.role, key.token);
    }

    void close_object() {
        ObjectState& state = object_state_back();
        if (state.keys.has_duplicate()) {
            fail("natrav-peer-message-json-duplicate-key", "payload");
        }
        const Frame completed = frame_back();
        pop_object_state();
        pop_frame();
        complete_value(
            completed.completion_capture,
            JsonValue::Kind::object,
            completed.begin);
    }

    void close_array() noexcept {
        const Frame completed = frame_back();
        finalize_capability_array(completed.array_role);
        pop_frame();
        complete_value(
            completed.completion_capture,
            JsonValue::Kind::array,
            completed.begin);
    }

    void process_array(Frame& frame) {
        if (frame.state == FrameState::array_value_or_end) {
            skip_whitespace();
            if (!at_end() && text_[offset_] == ']') {
                ++offset_;
                close_array();
                return;
            }
            const ValueCapture capture =
                capability_entry_capture(frame.array_role);
            frame.state = FrameState::array_comma_or_end;
            parse_value(capture);
            return;
        }

        skip_whitespace();
        if (!at_end() && text_[offset_] == ']') {
            ++offset_;
            close_array();
            return;
        }
        expect_character(',');
        skip_whitespace();
        if (!at_end() && text_[offset_] == ']') {
            fail("natrav-peer-message-json-array-trailing-comma", "payload");
        }
        const ValueCapture capture =
            capability_entry_capture(frame.array_role);
        frame.state = FrameState::array_comma_or_end;
        parse_value(capture);
    }

    void process_object(Frame& frame) {
        ObjectState& state = object_state_back();
        switch (frame.state) {
            case FrameState::object_key_or_end:
                skip_whitespace();
                if (!at_end() && text_[offset_] == '}') {
                    ++offset_;
                    close_object();
                    return;
                }
                parse_object_key(state);
                frame.state = FrameState::object_colon;
                return;
            case FrameState::object_colon:
                skip_whitespace();
                expect_character(':');
                frame.state = FrameState::object_value;
                return;
            case FrameState::object_value: {
                skip_whitespace();
                const ValueCapture capture = state.pending_capture;
                frame.state = FrameState::object_comma_or_end;
                parse_value(capture);
                return;
            }
            case FrameState::object_comma_or_end:
                skip_whitespace();
                if (!at_end() && text_[offset_] == '}') {
                    ++offset_;
                    close_object();
                    return;
                }
                expect_character(',');
                skip_whitespace();
                if (!at_end() && text_[offset_] == '}') {
                    fail(
                        "natrav-peer-message-json-object-trailing-comma",
                        "payload");
                }
                parse_object_key(state);
                frame.state = FrameState::object_colon;
                return;
            case FrameState::array_value_or_end:
            case FrameState::array_comma_or_end:
                fail("natrav-peer-message-json-preflight-state", "payload");
        }
    }

    void process_frame() {
        Frame& frame = frame_back();
        if (frame.kind == FrameKind::array) {
            process_array(frame);
        } else {
            process_object(frame);
        }
    }

    void push_frame(const Frame frame) {
        if (!frame_overflow_.empty()) {
            frame_overflow_.push_back(frame);
            return;
        }
        if (frame_inline_size_ < frame_inline_.size()) {
            frame_inline_[frame_inline_size_++] = frame;
            return;
        }
        frame_overflow_.reserve(frame_inline_.size() * 2U);
        for (std::size_t index = 0U;
             index < frame_inline_size_; ++index) {
            frame_overflow_.push_back(frame_inline_[index]);
        }
        frame_inline_size_ = 0U;
        frame_overflow_.push_back(frame);
    }

    [[nodiscard]] Frame& frame_back() noexcept {
        return frame_overflow_.empty() ?
            frame_inline_[frame_inline_size_ - 1U] :
            frame_overflow_.back();
    }

    [[nodiscard]] std::size_t frames_size() const noexcept {
        return frame_overflow_.empty() ?
            frame_inline_size_ : frame_overflow_.size();
    }

    [[nodiscard]] bool frames_empty() const noexcept {
        return frames_size() == 0U;
    }

    void pop_frame() noexcept {
        if (!frame_overflow_.empty()) {
            frame_overflow_.pop_back();
        } else {
            --frame_inline_size_;
        }
    }

    void push_object_state(
        const ObjectRole role,
        std::string_view* const key_buffer,
        const std::size_t key_capacity) {
        ObjectState state;
        state.role = role;
        state.keys.reset(key_buffer, key_capacity);
        if (!object_overflow_.empty()) {
            object_overflow_.push_back(std::move(state));
            return;
        }
        if (object_inline_size_ < object_inline_.size()) {
            object_inline_[object_inline_size_++] = std::move(state);
            return;
        }
        object_overflow_.reserve(object_inline_.size() * 2U);
        for (std::size_t index = 0U;
             index < object_inline_size_; ++index) {
            object_overflow_.push_back(std::move(object_inline_[index]));
        }
        object_inline_size_ = 0U;
        object_overflow_.push_back(std::move(state));
    }

    [[nodiscard]] ObjectState& object_state_back() noexcept {
        return object_overflow_.empty() ?
            object_inline_[object_inline_size_ - 1U] :
            object_overflow_.back();
    }

    void pop_object_state() noexcept {
        if (!object_overflow_.empty()) {
            object_overflow_.pop_back();
        } else {
            --object_inline_size_;
        }
    }

    std::string_view text_;
    std::size_t offset_{0U};
    std::array<Frame, 4U> frame_inline_{};
    std::size_t frame_inline_size_{0U};
    std::vector<Frame> frame_overflow_;
    std::array<ObjectState, 4U> object_inline_{};
    std::size_t object_inline_size_{0U};
    std::vector<ObjectState> object_overflow_;
    std::array<std::string_view, 8U> root_keys_{};
    std::array<std::string_view, 4U> protocol_keys_{};
    std::array<std::string_view, 4U> artifact_keys_{};
    bool root_started_{false};
    bool root_complete_{false};
    bool canonical_{true};
    JsonValue::Kind root_kind_{JsonValue::Kind::null_value};
    std::size_t maximum_depth_{0U};
    std::size_t value_count_{0U};
    std::size_t object_key_count_{0U};
    CanonicalMessagePreflightObservation observation_;
};

// Test-only switch for the exact revision-0480 projection policy. The current
// preflight still runs so semantic and allocation comparisons isolate the
// removed projection-time member-count, unknown-member, and indexed-kind checks.
#ifdef DATACUBE_NATRAV_MESSAGE_SHAPE_MASK_RETENTION_TEST
thread_local bool use_revision_0480_shape_rechecks = false;
#endif

[[nodiscard]] bool use_historical_shape_rechecks() noexcept {
#ifdef DATACUBE_NATRAV_MESSAGE_SHAPE_MASK_RETENTION_TEST
#ifdef DATACUBE_NATRAV_MESSAGE_SHAPE_MASK_RETENTION_SENSITIVITY
    return true;
#else
    return use_revision_0480_shape_rechecks;
#endif
#else
    return false;
#endif
}

[[nodiscard]] bool message_field_kind_matches(
    const CanonicalMessageFieldSpans& fields,
    const std::uint16_t bit,
    const std::optional<CanonicalJsonSpan>& span,
    const JsonValue::Kind expected) noexcept {
    if (use_historical_shape_rechecks()) {
        note_historical_top_level_kind_check();
        return span && span->kind == expected;
    }
    note_retained_top_level_kind_read();
    return (fields.shape.expected_kind_mask & bit) != 0U;
}

[[nodiscard]] bool canonical_message_shape_exact(
    const CanonicalMessageFieldSpans& fields,
    const NATravPeerHandshakeMessageKind kind) noexcept {
    if (use_historical_shape_rechecks()) {
        note_historical_top_level_member_check();
        return canonical_message_shape_exact_revision_0480(fields, kind);
    }

    std::uint16_t expected = static_cast<std::uint16_t>(
        kCanonicalMessageKindBit |
        kCanonicalMessageProtocolBit |
        kCanonicalMessageRequestIdBit);
    switch (kind) {
        case NATravPeerHandshakeMessageKind::hello:
            expected = static_cast<std::uint16_t>(
                expected |
                kCanonicalMessageArtifactBit |
                kCanonicalMessageRequiredCapabilitiesBit);
            break;
        case NATravPeerHandshakeMessageKind::hello_ack:
            expected = static_cast<std::uint16_t>(
                expected |
                kCanonicalMessageArtifactBit |
                kCanonicalMessageAvailableCapabilitiesBit);
            break;
        case NATravPeerHandshakeMessageKind::error:
            expected = static_cast<std::uint16_t>(
                expected |
                kCanonicalMessageCodeBit |
                kCanonicalMessageMessageBit);
            break;
        case NATravPeerHandshakeMessageKind::unknown:
            return false;
    }
    note_retained_top_level_member_read();
    return !fields.shape.unknown_member_seen &&
        fields.shape.member_mask == expected;
}

[[nodiscard]] bool indexed_protocol_shape_exact(
    const CanonicalMessageFieldSpans& message_fields,
    const CanonicalProtocolFieldSpans& fields) noexcept {
    if (use_historical_shape_rechecks()) {
        note_historical_protocol_member_check();
        note_historical_protocol_kind_check();
        return fields.member_count == 3U && fields.unknown_count == 0U &&
            fields.id && fields.major && fields.minor &&
            fields.id->kind == JsonValue::Kind::string &&
            fields.major->kind == JsonValue::Kind::integer &&
            fields.minor->kind == JsonValue::Kind::integer;
    }
    note_retained_top_level_kind_read();
    note_retained_protocol_shape_read();
    return (message_fields.shape.expected_kind_mask &
                kCanonicalMessageProtocolBit) != 0U &&
        !fields.shape.unknown_member_seen &&
        fields.shape.member_mask == kCanonicalProtocolExactMask &&
        fields.shape.expected_kind_mask == kCanonicalProtocolExactMask;
}

[[nodiscard]] bool indexed_artifact_shape_exact(
    const CanonicalMessageFieldSpans& message_fields,
    const CanonicalArtifactFieldSpans& fields) noexcept {
    if (use_historical_shape_rechecks()) {
        note_historical_artifact_member_check();
        note_historical_artifact_kind_check();
        return fields.member_count == 3U && fields.unknown_count == 0U &&
            fields.sha256 && fields.target && fields.version &&
            fields.sha256->kind == JsonValue::Kind::string &&
            fields.target->kind == JsonValue::Kind::string &&
            fields.version->kind == JsonValue::Kind::string;
    }
    note_retained_top_level_kind_read();
    note_retained_artifact_shape_read();
    return (message_fields.shape.expected_kind_mask &
                kCanonicalMessageArtifactBit) != 0U &&
        !fields.shape.unknown_member_seen &&
        fields.shape.member_mask == kCanonicalArtifactExactMask &&
        fields.shape.expected_kind_mask == kCanonicalArtifactExactMask;
}

// Test-only switch for the exact revision-0479 projection policy. The current
// preflight still runs so semantic and allocation comparisons isolate the
// removed projection-time message-kind and protocol-ID token comparisons.
#ifdef DATACUBE_NATRAV_MESSAGE_STRING_DISCRIMINANT_RETENTION_TEST
thread_local bool use_revision_0479_string_discriminant_rescans = false;
#endif

[[nodiscard]] bool use_historical_string_discriminant_rescans() noexcept {
#ifdef DATACUBE_NATRAV_MESSAGE_STRING_DISCRIMINANT_RETENTION_TEST
#ifdef DATACUBE_NATRAV_MESSAGE_STRING_DISCRIMINANT_RETENTION_SENSITIVITY
    return true;
#else
    return use_revision_0479_string_discriminant_rescans;
#endif
#else
    return false;
#endif
}

[[nodiscard]] NATravPeerHandshakeMessageKind retained_message_kind_discriminant(
    const CanonicalMessageFieldSpans& fields) noexcept {
    if (use_historical_string_discriminant_rescans()) {
        const std::size_t bytes = fields.kind ? fields.kind->bytes.size() : 0U;
        note_historical_message_kind_discriminant_rescan(bytes);
        if (fields.kind && fields.kind->bytes == "\"HELLO\"") {
            return NATravPeerHandshakeMessageKind::hello;
        }
        if (fields.kind && fields.kind->bytes == "\"HELLO_ACK\"") {
            return NATravPeerHandshakeMessageKind::hello_ack;
        }
        if (fields.kind && fields.kind->bytes == "\"ERROR\"") {
            return NATravPeerHandshakeMessageKind::error;
        }
        return NATravPeerHandshakeMessageKind::unknown;
    }
    note_retained_message_kind_discriminant_read();
    return fields.kind_discriminant.value_or(
        NATravPeerHandshakeMessageKind::unknown);
}

[[nodiscard]] bool retained_protocol_id_discriminant(
    const CanonicalProtocolFieldSpans& fields) noexcept {
    if (use_historical_string_discriminant_rescans()) {
        const std::size_t bytes = fields.id ? fields.id->bytes.size() : 0U;
        note_historical_protocol_id_discriminant_rescan(bytes);
        return fields.id &&
            fields.id->bytes == "\"NATRAV_OVERLAY_PEER\"";
    }
    note_retained_protocol_id_discriminant_read();
    return fields.id_matches_natrav_overlay_peer.value_or(false);
}

[[maybe_unused]] [[nodiscard]] bool project_indexed_protocol(
    const CanonicalMessageFieldSpans& message_fields,
    const CanonicalProtocolFieldSpans& fields,
    CanonicalProtocolProjection& projection) {
    if (!indexed_protocol_shape_exact(message_fields, fields) ||
        !retained_protocol_id_discriminant(fields) ||
        !fields.major_value || !fields.minor_value) {
        return false;
    }
    note_retained_protocol_integer_read();
    note_retained_protocol_integer_read();
    if (*fields.major_value != 1 || *fields.minor_value < 0) {
        return false;
    }
    projection.minor = *fields.minor_value;
    return true;
}

#ifdef DATACUBE_NATRAV_MESSAGE_PREFLIGHT_INTEGER_RETENTION_TEST
[[nodiscard]] bool project_indexed_protocol_revision_0474(
    const CanonicalProtocolFieldSpans& fields,
    CanonicalProtocolProjection& projection) {
    if (fields.member_count != 3U || fields.unknown_count != 0U ||
        !fields.id || !fields.major || !fields.minor ||
        fields.id->kind != JsonValue::Kind::string ||
        fields.id->bytes != "\"NATRAV_OVERLAY_PEER\"") {
        return false;
    }
    const std::optional<std::int64_t> major_value =
        canonical_integer_value(*fields.major);
    const std::optional<std::int64_t> minor_value =
        canonical_integer_value(*fields.minor);
    if (!major_value || *major_value != 1 || !minor_value ||
        *minor_value < 0) {
        return false;
    }
    projection.minor = *minor_value;
    return true;
}
#endif

// Test-only switch for the exact revision-0478 projection policy. The current
// preflight still runs so semantic and allocation comparisons isolate the
// removed projection-time fixed-ASCII predicate rescans.
#ifdef DATACUBE_NATRAV_MESSAGE_FIXED_ASCII_PREDICATE_RETENTION_TEST
thread_local bool use_revision_0478_fixed_ascii_predicate_rescans = false;
#endif

[[nodiscard]] bool use_historical_fixed_ascii_predicate_rescans() noexcept {
#ifdef DATACUBE_NATRAV_MESSAGE_FIXED_ASCII_PREDICATE_RETENTION_TEST
#ifdef DATACUBE_NATRAV_MESSAGE_FIXED_ASCII_PREDICATE_RETENTION_SENSITIVITY
    return true;
#else
    return use_revision_0478_fixed_ascii_predicate_rescans;
#endif
#else
    return false;
#endif
}

[[nodiscard]] bool retained_request_id_predicate(
    const CanonicalMessageFieldSpans& fields) noexcept {
    if (use_historical_fixed_ascii_predicate_rescans()) {
        note_historical_request_id_predicate_rescan();
        return fields.request_id &&
            lower_hex_sha256(
                canonical_ascii_string_contents(*fields.request_id));
    }
    note_retained_request_id_predicate_read();
    return fields.request_id_lower_hex_sha256.value_or(false);
}

[[nodiscard]] bool retained_artifact_sha256_predicate(
    const CanonicalArtifactFieldSpans& fields) noexcept {
    if (use_historical_fixed_ascii_predicate_rescans()) {
        note_historical_artifact_sha256_predicate_rescan();
        return fields.sha256 &&
            lower_hex_sha256(
                canonical_ascii_string_contents(*fields.sha256));
    }
    note_retained_artifact_sha256_predicate_read();
    return fields.sha256_lower_hex.value_or(false);
}

[[nodiscard]] bool retained_peer_error_code_predicate(
    const CanonicalMessageFieldSpans& fields) noexcept {
    if (use_historical_fixed_ascii_predicate_rescans()) {
        note_historical_peer_error_code_predicate_rescan();
        return fields.code && capability_token(
            canonical_ascii_string_contents(*fields.code));
    }
    note_retained_peer_error_code_predicate_read();
    return fields.peer_error_code_capability_token.value_or(false);
}

// Test-only switch for the exact revision-0481 projection policy. The current
// preflight still runs so semantic and allocation comparisons isolate the
// removed projection-time encoded-token-size checks for typed nonempty strings.
#ifdef DATACUBE_NATRAV_MESSAGE_NONEMPTY_STRING_PREDICATE_RETENTION_TEST
thread_local bool use_revision_0481_nonempty_string_token_size_checks = false;
#endif

[[nodiscard]] bool use_historical_nonempty_string_token_size_checks() noexcept {
#ifdef DATACUBE_NATRAV_MESSAGE_NONEMPTY_STRING_PREDICATE_RETENTION_TEST
#ifdef DATACUBE_NATRAV_MESSAGE_NONEMPTY_STRING_PREDICATE_RETENTION_SENSITIVITY
    return true;
#else
    return use_revision_0481_nonempty_string_token_size_checks;
#endif
#else
    return false;
#endif
}

[[nodiscard]] bool retained_artifact_target_nonempty(
    const CanonicalArtifactFieldSpans& fields) noexcept {
    if (use_historical_nonempty_string_token_size_checks()) {
        note_historical_artifact_target_token_size_check();
        return fields.target && fields.target->bytes.size() != 2U;
    }
    note_retained_artifact_target_nonempty_read();
    return fields.target_nonempty.value_or(false);
}

[[nodiscard]] bool retained_artifact_version_nonempty(
    const CanonicalArtifactFieldSpans& fields) noexcept {
    if (use_historical_nonempty_string_token_size_checks()) {
        note_historical_artifact_version_token_size_check();
        return fields.version && fields.version->bytes.size() != 2U;
    }
    note_retained_artifact_version_nonempty_read();
    return fields.version_nonempty.value_or(false);
}

[[nodiscard]] bool retained_peer_error_message_nonempty(
    const CanonicalMessageFieldSpans& fields) noexcept {
    if (use_historical_nonempty_string_token_size_checks()) {
        note_historical_peer_error_message_token_size_check();
        return fields.message && fields.message->bytes.size() != 2U;
    }
    note_retained_peer_error_message_nonempty_read();
    return fields.peer_error_message_nonempty.value_or(false);
}

[[maybe_unused]] [[nodiscard]] bool project_indexed_artifact(
    const CanonicalMessageFieldSpans& message_fields,
    const CanonicalArtifactFieldSpans& fields,
    CanonicalArtifactProjection& projection) {
    if (!indexed_artifact_shape_exact(message_fields, fields)) {
        return false;
    }
    if (!retained_artifact_sha256_predicate(fields) ||
        !retained_artifact_target_nonempty(fields) ||
        !retained_artifact_version_nonempty(fields)) {
        return false;
    }
    projection = CanonicalArtifactProjection{
        .sha256 = *fields.sha256,
        .target = *fields.target,
        .version = *fields.version,
    };
    return true;
}

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_READINESS_RETENTION_TEST
thread_local bool use_revision_0482_capability_readiness_rechecks = false;
#endif

[[nodiscard]] bool use_historical_capability_readiness_rechecks() noexcept {
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_READINESS_RETENTION_TEST
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_READINESS_RETENTION_SENSITIVITY
    return true;
#else
    return use_revision_0482_capability_readiness_rechecks;
#endif
#else
    return false;
#endif
}

[[nodiscard]] bool capability_projection_ready(
    const CanonicalCapabilityFieldIndex& index) noexcept {
    if (use_historical_capability_readiness_rechecks()) {
        note_historical_capability_projection_checks();
        const bool array_seen = index.array_seen;
        const bool valid = index.valid;
        const bool spans_complete = index.spans_complete;
        const bool count_consistent = index.span_count == index.count;
        return array_seen && valid && spans_complete && count_consistent;
    }
    note_retained_capability_projection_readiness();
    return index.ready.value_or(false);
}

[[nodiscard]] bool capability_construction_ready(
    const CanonicalCapabilityFieldIndex& index) noexcept {
    if (use_historical_capability_readiness_rechecks()) {
        note_historical_capability_construction_checks();
        const bool array_seen = index.array_seen;
        const bool valid = index.valid;
        const bool spans_complete = index.spans_complete;
        const bool count_consistent = index.span_count == index.count;
        return array_seen && valid && spans_complete && count_consistent;
    }
    note_retained_capability_construction_readiness();
    return index.ready.value_or(false);
}

[[maybe_unused]] [[nodiscard]] bool project_indexed_capabilities(
    const CanonicalMessageFieldSpans& message_fields,
    const std::uint16_t field_bit,
    const std::optional<CanonicalJsonSpan>& value,
    const CanonicalCapabilityFieldIndex& index,
    CanonicalCapabilityProjection& projection) noexcept {
    if (!message_field_kind_matches(
            message_fields, field_bit, value, JsonValue::Kind::array) ||
        !capability_projection_ready(index)) {
        return false;
    }
    projection.count = index.count;
    return true;
}

[[nodiscard]] std::vector<std::string> decode_indexed_capabilities(
    const std::string_view text,
    const CanonicalJsonSpan array_value,
    const CanonicalCapabilityFieldIndex& index,
    const CanonicalCapabilityEntrySpanStorage& spans) {
    const std::size_t span_storage_count = spans.size();
    if (array_value.kind != JsonValue::Kind::array ||
        !capability_construction_ready(index) ||
        index.span_begin > span_storage_count ||
        index.span_count > span_storage_count - index.span_begin ||
        array_value.bytes.data() < text.data() ||
        array_value.bytes.data() > text.data() + text.size()) {
        fail("natrav-peer-message-indexed-capability-span", "payload");
    }

    const std::size_t array_begin = static_cast<std::size_t>(
        array_value.bytes.data() - text.data());
    if (array_begin > text.size() ||
        array_value.bytes.size() > text.size() - array_begin ||
        array_value.bytes.size() < 2U) {
        fail("natrav-peer-message-indexed-capability-span", "payload");
    }
    const std::size_t array_end = array_begin + array_value.bytes.size();

    std::vector<std::string> result;
    result.reserve(index.count);
    std::size_t previous_end = array_begin + 1U;
    for (std::size_t offset = 0U; offset < index.span_count; ++offset) {
        const CanonicalCapabilityEntrySpan retained =
            spans.at(index.span_begin + offset);
        const std::size_t content_begin = retained.content_offset;
        const std::size_t content_size = retained.content_size;
        if (content_begin == 0U || content_begin < previous_end ||
            content_begin > text.size() ||
            content_size > text.size() - content_begin ||
            content_begin + content_size >= array_end ||
            content_begin <= array_begin ||
            text[content_begin - 1U] != '"' ||
            text[content_begin + content_size] != '"') {
            fail("natrav-peer-message-indexed-capability-span", "payload");
        }
        note_retained_capability_span_read();
        result.emplace_back(text.substr(content_begin, content_size));
        previous_end = content_begin + content_size + 1U;
    }
    if (result.size() != index.count) {
        fail("natrav-peer-message-indexed-capability-span", "payload");
    }
    return result;
}

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_RETENTION_TEST
thread_local bool use_revision_0477_capability_array_reparse = false;
#endif



[[maybe_unused]] [[nodiscard]] const JsonValue* member(
    const JsonValue& object,
    const std::string_view key) noexcept {
    if (object.kind != JsonValue::Kind::object) {
        return nullptr;
    }
    const auto found = object.object_values.find(key);
    return found == object.object_values.end() ? nullptr : &found->second;
}

[[maybe_unused]] [[nodiscard]] bool object_keys_exact(
    const JsonValue* const value,
    const std::initializer_list<std::string_view> keys) noexcept {
    if (value == nullptr || value->kind != JsonValue::Kind::object ||
        value->object_values.size() != keys.size()) {
        return false;
    }
    for (const std::string_view key : keys) {
        if (value->object_values.find(key) == value->object_values.end()) {
            return false;
        }
    }
    return true;
}

[[maybe_unused]] [[nodiscard]] bool lower_hex_sha256(const JsonValue* const value) noexcept {
    if (value == nullptr || value->kind != JsonValue::Kind::string ||
        value->string_value.size() != 64U) {
        return false;
    }
    for (const char character : value->string_value) {
        if (!((character >= '0' && character <= '9') ||
              (character >= 'a' && character <= 'f'))) {
            return false;
        }
    }
    return true;
}

[[maybe_unused]] [[nodiscard]] bool nonempty_string(const JsonValue* const value) noexcept {
    return value != nullptr && value->kind == JsonValue::Kind::string &&
        !value->string_value.empty();
}

[[nodiscard]] bool capability_token(const std::string_view token) noexcept {
    if (token.empty() || token.size() > 64U || token.front() < 'A' ||
        token.front() > 'Z' || token.back() == '_') {
        return false;
    }
    bool previous_underscore = false;
    for (const char character : token) {
        const bool uppercase = character >= 'A' && character <= 'Z';
        const bool digit = character >= '0' && character <= '9';
        const bool underscore = character == '_';
        if (!uppercase && !digit && !underscore) {
            return false;
        }
        if (underscore && previous_underscore) {
            return false;
        }
        previous_underscore = underscore;
    }
    return true;
}

[[maybe_unused]] [[nodiscard]] bool capability_array_exact(
    const JsonValue* const value) noexcept {
    if (value == nullptr || value->kind != JsonValue::Kind::array) {
        return false;
    }
    std::string_view previous;
    bool first = true;
    for (const JsonValue& entry : value->array_values) {
        if (entry.kind != JsonValue::Kind::string ||
            !capability_token(entry.string_value) ||
            (!first && !(previous < entry.string_value))) {
            return false;
        }
        first = false;
        previous = entry.string_value;
    }
    return true;
}

[[maybe_unused]] void append_canonical_json(const JsonValue& value, std::string& output) {
    switch (value.kind) {
        case JsonValue::Kind::null_value:
            output.append("null");
            return;
        case JsonValue::Kind::boolean:
            output.append(value.boolean_value ? "true" : "false");
            return;
        case JsonValue::Kind::integer:
            output.append(std::to_string(value.integer_value));
            return;
        case JsonValue::Kind::string:
            output.push_back('"');
            output.append(json_escape(value.string_value));
            output.push_back('"');
            return;
        case JsonValue::Kind::array:
            output.push_back('[');
            for (std::size_t index = 0U;
                 index < value.array_values.size(); ++index) {
                if (index != 0U) {
                    output.push_back(',');
                }
                append_canonical_json(value.array_values[index], output);
            }
            output.push_back(']');
            return;
        case JsonValue::Kind::object: {
            output.push_back('{');
            bool first = true;
            for (const auto& entry : value.object_values) {
                if (!first) {
                    output.push_back(',');
                }
                first = false;
                output.push_back('"');
                output.append(json_escape(entry.first));
                output.append("\":");
                append_canonical_json(entry.second, output);
            }
            output.push_back('}');
            return;
        }
    }
}

[[maybe_unused]] [[nodiscard]] bool protocol_object_exact(
    const JsonValue* const protocol) noexcept {
    return object_keys_exact(protocol, {"id", "major", "minor"}) &&
        member(*protocol, "id") != nullptr &&
        member(*protocol, "id")->kind == JsonValue::Kind::string &&
        member(*protocol, "id")->string_value == "NATRAV_OVERLAY_PEER" &&
        member(*protocol, "major") != nullptr &&
        member(*protocol, "major")->kind == JsonValue::Kind::integer &&
        member(*protocol, "major")->integer_value == 1 &&
        member(*protocol, "minor") != nullptr &&
        member(*protocol, "minor")->kind == JsonValue::Kind::integer &&
        member(*protocol, "minor")->integer_value >= 0;
}

[[maybe_unused]] [[nodiscard]] bool artifact_object_exact(
    const JsonValue* const artifact) noexcept {
    return object_keys_exact(artifact, {"sha256", "target", "version"}) &&
        lower_hex_sha256(member(*artifact, "sha256")) &&
        nonempty_string(member(*artifact, "target")) &&
        nonempty_string(member(*artifact, "version"));
}

[[maybe_unused]] [[nodiscard]] NATravPeerProtocolVersion protocol_value(
    const JsonValue& root) {
    const JsonValue* const protocol = member(root, "protocol");
    return NATravPeerProtocolVersion{
        .id = member(*protocol, "id")->string_value,
        .major = member(*protocol, "major")->integer_value,
        .minor = member(*protocol, "minor")->integer_value,
    };
}

[[maybe_unused]] [[nodiscard]] NATravPeerArtifactIdentity artifact_value(
    const JsonValue& root) {
    const JsonValue* const artifact = member(root, "artifact");
    return NATravPeerArtifactIdentity{
        .sha256 = member(*artifact, "sha256")->string_value,
        .target = member(*artifact, "target")->string_value,
        .version = member(*artifact, "version")->string_value,
    };
}

[[maybe_unused]] [[nodiscard]] std::vector<std::string> capability_values(
    const JsonValue& root,
    const std::string_view key) {
    const JsonValue* const capabilities = member(root, key);
    std::vector<std::string> result;
    result.reserve(capabilities->array_values.size());
    for (const JsonValue& capability : capabilities->array_values) {
        result.push_back(capability.string_value);
    }
    return result;
}

[[nodiscard]] bool lower_hex_sha256(const std::string_view value) noexcept {
    if (value.size() != 64U) {
        return false;
    }
    for (const char character : value) {
        if (!((character >= '0' && character <= '9') ||
              (character >= 'a' && character <= 'f'))) {
            return false;
        }
    }
    return true;
}

[[nodiscard]] bool capability_array_exact(
    const std::vector<std::string>& values) noexcept {
    std::string_view previous;
    bool first = true;
    for (const std::string& value : values) {
        if (!capability_token(value) ||
            (!first && !(previous < std::string_view(value)))) {
            return false;
        }
        first = false;
        previous = value;
    }
    return true;
}

[[nodiscard]] bool protocol_value_exact(
    const NATravPeerProtocolVersion& protocol) noexcept {
    return protocol.id == "NATRAV_OVERLAY_PEER" && protocol.major == 1 &&
        protocol.minor >= 0;
}

[[nodiscard]] bool artifact_value_exact(
    const NATravPeerArtifactIdentity& artifact) noexcept {
    return lower_hex_sha256(artifact.sha256) && !artifact.target.empty() &&
        !artifact.version.empty() && utf8_scalar_sequence(artifact.target) &&
        utf8_scalar_sequence(artifact.version);
}

[[nodiscard]] bool artifact_value_empty(
    const NATravPeerArtifactIdentity& artifact) noexcept {
    return artifact.sha256.empty() && artifact.target.empty() &&
        artifact.version.empty();
}

class NATravPeerPayloadSizeSink final {
public:
    [[nodiscard]] bool text(const std::string_view value) noexcept {
        return add(value.size());
    }

    [[nodiscard]] bool json_string(const std::string_view value) noexcept {
        return emit_canonical_json_string(
            value,
            [this](const std::string_view fragment) noexcept {
                return add(fragment.size());
            });
    }

    [[nodiscard]] bool integer(const std::int64_t value) noexcept {
        return emit_canonical_json_integer(
            value,
            [this](const std::string_view fragment) noexcept {
                return add(fragment.size());
            });
    }

    [[nodiscard]] std::size_t size() const noexcept { return size_; }

private:
    [[nodiscard]] bool add(const std::size_t bytes) noexcept {
        constexpr std::size_t limit =
            static_cast<std::size_t>(kNATravPeerMaximumPayloadBytes);
        if (bytes > limit - size_) {
            return false;
        }
        size_ += bytes;
        return true;
    }

    std::size_t size_{0U};
};

class NATravPeerPayloadOctetSink final {
public:
    explicit NATravPeerPayloadOctetSink(Octets& output) noexcept :
        output_(output) {}

    [[nodiscard]] bool text(const std::string_view value) {
        append_text(output_, value);
        return true;
    }

    [[nodiscard]] bool json_string(const std::string_view value) {
        return emit_canonical_json_string(
            value,
            [this](const std::string_view fragment) {
                append_text(output_, fragment);
                return true;
            });
    }

    [[nodiscard]] bool integer(const std::int64_t value) {
        return emit_canonical_json_integer(
            value,
            [this](const std::string_view fragment) {
                append_text(output_, fragment);
                return true;
            });
    }

private:
    Octets& output_;
};

template <typename Sink>
[[nodiscard]] bool append_protocol_value(
    Sink& sink,
    const NATravPeerProtocolVersion& protocol) {
    return sink.text("{\"id\":") && sink.json_string(protocol.id) &&
        sink.text(",\"major\":") && sink.integer(protocol.major) &&
        sink.text(",\"minor\":") && sink.integer(protocol.minor) &&
        sink.text("}");
}

template <typename Sink>
[[nodiscard]] bool append_artifact_value(
    Sink& sink,
    const NATravPeerArtifactIdentity& artifact) {
    return sink.text("{\"sha256\":") &&
        sink.json_string(artifact.sha256) && sink.text(",\"target\":") &&
        sink.json_string(artifact.target) && sink.text(",\"version\":") &&
        sink.json_string(artifact.version) && sink.text("}");
}

template <typename Sink>
[[nodiscard]] bool append_capability_values(
    Sink& sink,
    const std::vector<std::string>& capabilities) {
    if (!sink.text("[")) {
        return false;
    }
    for (std::size_t index = 0U; index < capabilities.size(); ++index) {
        if (index != 0U && !sink.text(",")) {
            return false;
        }
        if (!sink.json_string(capabilities[index])) {
            return false;
        }
    }
    return sink.text("]");
}

template <typename Sink>
[[nodiscard]] bool append_message_value(
    Sink& sink,
    const NATravPeerHandshakeMessage& message) {
    if (message.kind == NATravPeerHandshakeMessageKind::hello) {
        return sink.text("{\"artifact\":") &&
            append_artifact_value(sink, message.artifact) &&
            sink.text(",\"kind\":\"HELLO\",\"protocol\":") &&
            append_protocol_value(sink, message.protocol) &&
            sink.text(",\"request_id\":") &&
            sink.json_string(message.request_id) &&
            sink.text(",\"required_capabilities\":") &&
            append_capability_values(sink, message.required_capabilities) &&
            sink.text("}");
    }
    if (message.kind == NATravPeerHandshakeMessageKind::hello_ack) {
        return sink.text("{\"artifact\":") &&
            append_artifact_value(sink, message.artifact) &&
            sink.text(",\"available_capabilities\":") &&
            append_capability_values(sink, message.available_capabilities) &&
            sink.text(",\"kind\":\"HELLO_ACK\",\"protocol\":") &&
            append_protocol_value(sink, message.protocol) &&
            sink.text(",\"request_id\":") &&
            sink.json_string(message.request_id) && sink.text("}");
    }
    return sink.text("{\"code\":") && sink.json_string(message.error_code) &&
        sink.text(",\"kind\":\"ERROR\",\"message\":") &&
        sink.json_string(message.error_message) &&
        sink.text(",\"protocol\":") &&
        append_protocol_value(sink, message.protocol) &&
        sink.text(",\"request_id\":") &&
        sink.json_string(message.request_id) && sink.text("}");
}

[[nodiscard]] NATravPeerMessageEncodeObservation encode_observation(
    const NATravPeerMessageEncodeStatus status) {
    return NATravPeerMessageEncodeObservation{
        .status = status,
        .classification =
            std::string(natrav_peer_message_encode_status_name(status)),
        .payload = std::nullopt,
    };
}

[[nodiscard]] NATravPeerMessageDecodeObservation observation(
    const NATravPeerMessageDecodeStatus status) {
    return NATravPeerMessageDecodeObservation{
        .status = status,
        .classification =
            std::string(natrav_peer_message_decode_status_name(status)),
        .message = std::nullopt,
    };
}

}  // namespace

NATravPeerMessageEncodeObservation natrav_peer_encode_message(
    const NATravPeerHandshakeMessage& message) {
    switch (message.kind) {
        case NATravPeerHandshakeMessageKind::hello:
            if (!message.available_capabilities.empty() ||
                !message.error_code.empty() || !message.error_message.empty()) {
                return encode_observation(
                    NATravPeerMessageEncodeStatus::schema_rejected);
            }
            break;
        case NATravPeerHandshakeMessageKind::hello_ack:
            if (!message.required_capabilities.empty() ||
                !message.error_code.empty() || !message.error_message.empty()) {
                return encode_observation(
                    NATravPeerMessageEncodeStatus::schema_rejected);
            }
            break;
        case NATravPeerHandshakeMessageKind::error:
            if (!artifact_value_empty(message.artifact) ||
                !message.required_capabilities.empty() ||
                !message.available_capabilities.empty()) {
                return encode_observation(
                    NATravPeerMessageEncodeStatus::schema_rejected);
            }
            break;
        case NATravPeerHandshakeMessageKind::unknown:
            return encode_observation(
                NATravPeerMessageEncodeStatus::message_kind_rejected);
    }

    if (!protocol_value_exact(message.protocol)) {
        return encode_observation(
            NATravPeerMessageEncodeStatus::protocol_mismatch);
    }
    if (!lower_hex_sha256(message.request_id)) {
        return encode_observation(
            NATravPeerMessageEncodeStatus::request_id_rejected);
    }

    if (message.kind == NATravPeerHandshakeMessageKind::hello ||
        message.kind == NATravPeerHandshakeMessageKind::hello_ack) {
        if (!artifact_value_exact(message.artifact)) {
            return encode_observation(
                NATravPeerMessageEncodeStatus::artifact_identity_rejected);
        }
        const std::vector<std::string>& capabilities =
            message.kind == NATravPeerHandshakeMessageKind::hello ?
                message.required_capabilities :
                message.available_capabilities;
        if (!capability_array_exact(capabilities)) {
            return encode_observation(
                NATravPeerMessageEncodeStatus::capability_declaration_rejected);
        }
    } else if (!capability_token(message.error_code) ||
               message.error_message.empty() ||
               !utf8_scalar_sequence(message.error_message)) {
        return encode_observation(
            NATravPeerMessageEncodeStatus::schema_rejected);
    }

    // Count the exact canonical payload before allocating its storage. The
    // complete typed schema has already been validated, so an oversized valid
    // value is rejected without constructing either an output-sized string or
    // any escaped-field temporary.
    NATravPeerPayloadSizeSink size_sink;
    if (!append_message_value(size_sink, message) ||
        size_sink.size() <
            static_cast<std::size_t>(kNATravPeerMinimumPayloadBytes)) {
        return encode_observation(
            NATravPeerMessageEncodeStatus::payload_size_rejected);
    }

    Octets payload;
    payload.reserve(size_sink.size());
    NATravPeerPayloadOctetSink payload_sink(payload);
    if (!append_message_value(payload_sink, message) ||
        payload.size() != size_sink.size()) {
        fail("natrav-peer-message-encode-size-drift", "payload");
    }
    return NATravPeerMessageEncodeObservation{
        .status = NATravPeerMessageEncodeStatus::accepted,
        .classification = "ACCEPTED",
        .payload = std::move(payload),
    };
}

std::string_view natrav_peer_message_encode_status_name(
    const NATravPeerMessageEncodeStatus status) noexcept {
    switch (status) {
        case NATravPeerMessageEncodeStatus::accepted: return "ACCEPTED";
        case NATravPeerMessageEncodeStatus::schema_rejected:
            return "SCHEMA_REJECTED";
        case NATravPeerMessageEncodeStatus::message_kind_rejected:
            return "MESSAGE_KIND_REJECTED";
        case NATravPeerMessageEncodeStatus::protocol_mismatch:
            return "PROTOCOL_MISMATCH";
        case NATravPeerMessageEncodeStatus::request_id_rejected:
            return "REQUEST_ID_REJECTED";
        case NATravPeerMessageEncodeStatus::artifact_identity_rejected:
            return "ARTIFACT_IDENTITY_REJECTED";
        case NATravPeerMessageEncodeStatus::capability_declaration_rejected:
            return "CAPABILITY_DECLARATION_REJECTED";
        case NATravPeerMessageEncodeStatus::payload_size_rejected:
            return "PAYLOAD_SIZE_REJECTED";
    }
    return "UNKNOWN";
}

NATravPeerMessageDecodeObservation natrav_peer_decode_message(
    const OctetView payload) {
    // The direct codec has the same byte envelope as its encoder and frame
    // layer. Reject before constructing input-sized storage or inspecting JSON.
    if (payload.size() < kNATravPeerMinimumPayloadBytes ||
        payload.size() > kNATravPeerMaximumPayloadBytes) {
        return observation(NATravPeerMessageDecodeStatus::payload_size_rejected);
    }

    // The payload remains caller-owned for the duration of this stateless call.
    // One schema-aware iterative pass establishes malformed, root-shape,
    // canonical-spelling and structural-profile priority while indexing the
    // canonical typed fields. Accepted messages therefore need no separate root,
    // protocol, artifact, or capability-validation traversal and no general
    // JsonValue tree or canonical reconstruction.
    const std::string_view text(
        reinterpret_cast<const char*>(payload.data()), payload.size());
    CanonicalMessagePreflight preflight_parser(text);
    const CanonicalMessagePreflightObservation* preflight_pointer = nullptr;
    try {
        preflight_pointer = &preflight_parser.inspect();
    } catch (const Failure&) {
        return observation(NATravPeerMessageDecodeStatus::malformed_json);
    }
    const CanonicalMessagePreflightObservation& preflight =
        *preflight_pointer;
    if (preflight.root_kind != JsonValue::Kind::object) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }
    if (!preflight.canonical) {
        return observation(NATravPeerMessageDecodeStatus::noncanonical_json);
    }
    if (!preflight.tree_admissible()) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }

    const CanonicalMessageFieldSpans& fields = preflight.fields;
    if (!message_field_kind_matches(
            fields,
            kCanonicalMessageKindBit,
            fields.kind,
            JsonValue::Kind::string)) {
        return observation(NATravPeerMessageDecodeStatus::message_kind_rejected);
    }

    const NATravPeerHandshakeMessageKind kind =
        retained_message_kind_discriminant(fields);
    if (kind == NATravPeerHandshakeMessageKind::unknown) {
        return observation(NATravPeerMessageDecodeStatus::message_kind_rejected);
    }

    if (!canonical_message_shape_exact(fields, kind)) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }

    CanonicalProtocolProjection protocol;
    if (!project_indexed_protocol(fields, preflight.protocol, protocol)) {
        return observation(NATravPeerMessageDecodeStatus::protocol_mismatch);
    }

    if (!message_field_kind_matches(
            fields,
            kCanonicalMessageRequestIdBit,
            fields.request_id,
            JsonValue::Kind::string) ||
        !retained_request_id_predicate(fields)) {
        return observation(NATravPeerMessageDecodeStatus::request_id_rejected);
    }
    const std::string_view request_id =
        canonical_ascii_string_contents(*fields.request_id);

    CanonicalArtifactProjection artifact;
    CanonicalCapabilityProjection capabilities;
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        if (!project_indexed_artifact(fields, preflight.artifact, artifact)) {
            return observation(
                NATravPeerMessageDecodeStatus::artifact_identity_rejected);
        }
        const CanonicalCapabilityFieldIndex& capability_index =
            kind == NATravPeerHandshakeMessageKind::hello ?
                preflight.required_capabilities :
                preflight.available_capabilities;
        if (!project_indexed_capabilities(
                fields,
                kind == NATravPeerHandshakeMessageKind::hello ?
                    kCanonicalMessageRequiredCapabilitiesBit :
                    kCanonicalMessageAvailableCapabilitiesBit,
                kind == NATravPeerHandshakeMessageKind::hello ?
                    fields.required_capabilities :
                    fields.available_capabilities,
                capability_index,
                capabilities)) {
            return observation(
                NATravPeerMessageDecodeStatus::capability_declaration_rejected);
        }
    } else {
        if (!message_field_kind_matches(
                fields,
                kCanonicalMessageCodeBit,
                fields.code,
                JsonValue::Kind::string) ||
            !retained_peer_error_code_predicate(fields) ||
            !message_field_kind_matches(
                fields,
                kCanonicalMessageMessageBit,
                fields.message,
                JsonValue::Kind::string) ||
            !retained_peer_error_message_nonempty(fields)) {
            return observation(NATravPeerMessageDecodeStatus::schema_rejected);
        }
    }

    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = protocol.minor,
    };
    message.request_id.assign(request_id);
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = NATravPeerArtifactIdentity{
            .sha256 = std::string(
                canonical_ascii_string_contents(artifact.sha256)),
            .target = decode_canonical_string(artifact.target),
            .version = decode_canonical_string(artifact.version),
        };
        const CanonicalJsonSpan capability_span =
            kind == NATravPeerHandshakeMessageKind::hello ?
                *fields.required_capabilities :
                *fields.available_capabilities;
        const CanonicalCapabilityFieldIndex& capability_index =
            kind == NATravPeerHandshakeMessageKind::hello ?
                preflight.required_capabilities :
                preflight.available_capabilities;
        std::vector<std::string> decoded_capabilities;
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_RETENTION_TEST
        const bool historical_projection =
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_RETENTION_SENSITIVITY
            true;
#else
            use_revision_0477_capability_array_reparse;
#endif
        if (historical_projection) {
            decoded_capabilities = decode_canonical_capabilities(
                capability_span, capabilities.count);
        } else {
            decoded_capabilities = decode_indexed_capabilities(
                text,
                capability_span,
                capability_index,
                preflight.capability_entry_spans);
        }
#else
        decoded_capabilities = decode_indexed_capabilities(
            text,
            capability_span,
            capability_index,
            preflight.capability_entry_spans);
#endif
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            message.required_capabilities =
                std::move(decoded_capabilities);
        } else {
            message.available_capabilities =
                std::move(decoded_capabilities);
        }
    } else {
        message.error_code.assign(
            canonical_ascii_string_contents(*fields.code));
        message.error_message = decode_canonical_string(*fields.message);
    }

    return NATravPeerMessageDecodeObservation{
        .status = NATravPeerMessageDecodeStatus::accepted,
        .classification = "ACCEPTED",
        .message = std::move(message),
    };
}

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_STORAGE_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0483(
    const OctetView payload) {
    struct HistoricalStorageGuard final {
        bool previous;
        HistoricalStorageGuard() noexcept :
            previous(use_revision_0483_fixed_capability_span_storage) {
            use_revision_0483_fixed_capability_span_storage = true;
        }
        ~HistoricalStorageGuard() {
            use_revision_0483_fixed_capability_span_storage = previous;
        }
    } guard;
    return natrav_peer_decode_message(payload);
}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0484(
    const OctetView payload) {
    struct HistoricalStorageGuard final {
        bool previous;
        HistoricalStorageGuard() noexcept :
            previous(use_revision_0484_geometric_capability_span_storage) {
            use_revision_0484_geometric_capability_span_storage = true;
        }
        ~HistoricalStorageGuard() {
            use_revision_0484_geometric_capability_span_storage = previous;
        }
    } guard;
    return natrav_peer_decode_message(payload);
}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0485(
    const OctetView payload) {
    struct HistoricalStorageGuard final {
        bool previous;
        HistoricalStorageGuard() noexcept :
            previous(use_revision_0485_uniform_capability_span_storage) {
            use_revision_0485_uniform_capability_span_storage = true;
        }
        ~HistoricalStorageGuard() {
            use_revision_0485_uniform_capability_span_storage = previous;
        }
    } guard;
    return natrav_peer_decode_message(payload);
}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0486(
    const OctetView payload) {
    struct HistoricalStorageGuard final {
        bool previous;
        HistoricalStorageGuard() noexcept :
            previous(use_revision_0486_eager_capability_span_directory) {
            use_revision_0486_eager_capability_span_directory = true;
        }
        ~HistoricalStorageGuard() {
            use_revision_0486_eager_capability_span_directory = previous;
        }
    } guard;
    return natrav_peer_decode_message(payload);
}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_FUSED_TAIL_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0487(
    const OctetView payload) {
    struct HistoricalStorageGuard final {
        bool previous;
        HistoricalStorageGuard() noexcept :
            previous(use_revision_0487_unfused_tail_activation) {
            use_revision_0487_unfused_tail_activation = true;
        }
        ~HistoricalStorageGuard() {
            use_revision_0487_unfused_tail_activation = previous;
        }
    } guard;
    return natrav_peer_decode_message(payload);
}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_READINESS_RETENTION_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0482(
    const OctetView payload) {
    struct ReadinessModeGuard final {
        ReadinessModeGuard() noexcept :
            previous(use_revision_0482_capability_readiness_rechecks) {
            use_revision_0482_capability_readiness_rechecks = true;
        }
        ~ReadinessModeGuard() {
            use_revision_0482_capability_readiness_rechecks = previous;
        }
        bool previous;
    } guard;
    return natrav_peer_decode_message(payload);
}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_NONEMPTY_STRING_PREDICATE_RETENTION_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0481(
    const OctetView payload) {
    struct ProjectionModeGuard final {
        ProjectionModeGuard() noexcept :
            previous(use_revision_0481_nonempty_string_token_size_checks) {
            use_revision_0481_nonempty_string_token_size_checks = true;
        }
        ~ProjectionModeGuard() {
            use_revision_0481_nonempty_string_token_size_checks = previous;
        }
        bool previous;
    } guard;
    return natrav_peer_decode_message(payload);
}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_SHAPE_MASK_RETENTION_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0480(
    const OctetView payload) {
    struct ProjectionModeGuard final {
        ProjectionModeGuard() noexcept :
            previous(use_revision_0480_shape_rechecks) {
            use_revision_0480_shape_rechecks = true;
        }
        ~ProjectionModeGuard() {
            use_revision_0480_shape_rechecks = previous;
        }
        bool previous;
    } guard;
    return natrav_peer_decode_message(payload);
}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_STRING_DISCRIMINANT_RETENTION_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0479(
    const OctetView payload) {
    struct ProjectionModeGuard final {
        ProjectionModeGuard() noexcept :
            previous(use_revision_0479_string_discriminant_rescans) {
            use_revision_0479_string_discriminant_rescans = true;
        }
        ~ProjectionModeGuard() {
            use_revision_0479_string_discriminant_rescans = previous;
        }
        bool previous;
    } guard;
    return natrav_peer_decode_message(payload);
}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_FIXED_ASCII_PREDICATE_RETENTION_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0478(
    const OctetView payload) {
    struct ProjectionModeGuard final {
        ProjectionModeGuard() noexcept :
            previous(use_revision_0478_fixed_ascii_predicate_rescans) {
            use_revision_0478_fixed_ascii_predicate_rescans = true;
        }
        ~ProjectionModeGuard() {
            use_revision_0478_fixed_ascii_predicate_rescans = previous;
        }
        bool previous;
    } guard;
    return natrav_peer_decode_message(payload);
}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_RETENTION_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0477(
    const OctetView payload) {
    struct CapabilityProjectionModeGuard final {
        CapabilityProjectionModeGuard() noexcept :
            previous(use_revision_0477_capability_array_reparse) {
            use_revision_0477_capability_array_reparse = true;
        }
        ~CapabilityProjectionModeGuard() {
            use_revision_0477_capability_array_reparse = previous;
        }
        bool previous;
    } guard;
    return natrav_peer_decode_message(payload);
}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_PROJECTION_STRING_DECODER_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0476(
    const OctetView payload) {
    struct ProjectionModeGuard final {
        ProjectionModeGuard() noexcept :
            previous(use_revision_0476_projection_string_decoder) {
            use_revision_0476_projection_string_decoder = true;
        }
        ~ProjectionModeGuard() {
            use_revision_0476_projection_string_decoder = previous;
        }
        bool previous;
    } guard;
    return natrav_peer_decode_message(payload);
}
#endif

#ifdef DATACUBE_NATRAV_MESSAGE_PREFLIGHT_STRING_LENGTH_RETENTION_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0475(
    const OctetView payload) {
    // The direct codec has the same byte envelope as its encoder and frame
    // layer. Reject before constructing input-sized storage or inspecting JSON.
    if (payload.size() < kNATravPeerMinimumPayloadBytes ||
        payload.size() > kNATravPeerMaximumPayloadBytes) {
        return observation(NATravPeerMessageDecodeStatus::payload_size_rejected);
    }

    // The payload remains caller-owned for the duration of this stateless call.
    // One schema-aware iterative pass establishes malformed, root-shape,
    // canonical-spelling and structural-profile priority while indexing the
    // canonical typed fields. Accepted messages therefore need no separate root,
    // protocol, artifact, or capability-validation traversal and no general
    // JsonValue tree or canonical reconstruction.
    const std::string_view text(
        reinterpret_cast<const char*>(payload.data()), payload.size());
    CanonicalMessagePreflight preflight_parser(text);
    const CanonicalMessagePreflightObservation* preflight_pointer = nullptr;
    try {
        preflight_pointer = &preflight_parser.inspect();
    } catch (const Failure&) {
        return observation(NATravPeerMessageDecodeStatus::malformed_json);
    }
    const CanonicalMessagePreflightObservation& preflight =
        *preflight_pointer;
    if (preflight.root_kind != JsonValue::Kind::object) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }
    if (!preflight.canonical) {
        return observation(NATravPeerMessageDecodeStatus::noncanonical_json);
    }
    if (!preflight.tree_admissible()) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }

    const CanonicalMessageFieldSpans& fields = preflight.fields;
    if (!fields.kind || fields.kind->kind != JsonValue::Kind::string) {
        return observation(NATravPeerMessageDecodeStatus::message_kind_rejected);
    }

    NATravPeerHandshakeMessageKind kind =
        NATravPeerHandshakeMessageKind::unknown;
    if (fields.kind->bytes == "\"HELLO\"") {
        kind = NATravPeerHandshakeMessageKind::hello;
    } else if (fields.kind->bytes == "\"HELLO_ACK\"") {
        kind = NATravPeerHandshakeMessageKind::hello_ack;
    } else if (fields.kind->bytes == "\"ERROR\"") {
        kind = NATravPeerHandshakeMessageKind::error;
    } else {
        return observation(NATravPeerMessageDecodeStatus::message_kind_rejected);
    }

    if (!canonical_message_shape_exact(fields, kind)) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }

    CanonicalProtocolProjection protocol;
    if (!project_indexed_protocol(fields, preflight.protocol, protocol)) {
        return observation(NATravPeerMessageDecodeStatus::protocol_mismatch);
    }

    const std::string_view request_id =
        canonical_ascii_string_contents(*fields.request_id);
    if (fields.request_id->kind != JsonValue::Kind::string ||
        !lower_hex_sha256(request_id)) {
        return observation(NATravPeerMessageDecodeStatus::request_id_rejected);
    }

    CanonicalArtifactProjection artifact;
    CanonicalCapabilityProjection capabilities;
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        if (!project_indexed_artifact(fields, preflight.artifact, artifact)) {
            return observation(
                NATravPeerMessageDecodeStatus::artifact_identity_rejected);
        }
        const CanonicalCapabilityFieldIndex& capability_index =
            kind == NATravPeerHandshakeMessageKind::hello ?
                preflight.required_capabilities :
                preflight.available_capabilities;
        if (!project_indexed_capabilities(
                fields,
                kind == NATravPeerHandshakeMessageKind::hello ?
                    kCanonicalMessageRequiredCapabilitiesBit :
                    kCanonicalMessageAvailableCapabilitiesBit,
                kind == NATravPeerHandshakeMessageKind::hello ?
                    fields.required_capabilities :
                    fields.available_capabilities,
                capability_index,
                capabilities)) {
            return observation(
                NATravPeerMessageDecodeStatus::capability_declaration_rejected);
        }
    } else {
        const std::string_view code =
            canonical_ascii_string_contents(*fields.code);
        if (fields.code->kind != JsonValue::Kind::string ||
            !capability_token(code) ||
            fields.message->kind != JsonValue::Kind::string ||
            fields.message->bytes.size() == 2U) {
            return observation(NATravPeerMessageDecodeStatus::schema_rejected);
        }
    }

    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = protocol.minor,
    };
    message.request_id.assign(request_id);
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = NATravPeerArtifactIdentity{
            .sha256 = std::string(
                canonical_ascii_string_contents(artifact.sha256)),
            .target = decode_canonical_string_revision_0475(artifact.target),
            .version = decode_canonical_string_revision_0475(artifact.version),
        };
        const CanonicalJsonSpan capability_span =
            kind == NATravPeerHandshakeMessageKind::hello ?
                *fields.required_capabilities :
                *fields.available_capabilities;
        std::vector<std::string> decoded_capabilities =
            decode_canonical_capabilities(
                capability_span, capabilities.count);
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            message.required_capabilities =
                std::move(decoded_capabilities);
        } else {
            message.available_capabilities =
                std::move(decoded_capabilities);
        }
    } else {
        message.error_code.assign(
            canonical_ascii_string_contents(*fields.code));
        message.error_message = decode_canonical_string_revision_0475(*fields.message);
    }

    return NATravPeerMessageDecodeObservation{
        .status = NATravPeerMessageDecodeStatus::accepted,
        .classification = "ACCEPTED",
        .message = std::move(message),
    };
}

#endif  // DATACUBE_NATRAV_MESSAGE_PREFLIGHT_STRING_LENGTH_RETENTION_TEST

#ifdef DATACUBE_NATRAV_MESSAGE_PREFLIGHT_INTEGER_RETENTION_TEST
NATravPeerMessageDecodeObservation natrav_peer_decode_message_revision_0474(
    const OctetView payload) {
    // The direct codec has the same byte envelope as its encoder and frame
    // layer. Reject before constructing input-sized storage or inspecting JSON.
    if (payload.size() < kNATravPeerMinimumPayloadBytes ||
        payload.size() > kNATravPeerMaximumPayloadBytes) {
        return observation(NATravPeerMessageDecodeStatus::payload_size_rejected);
    }

    // The payload remains caller-owned for the duration of this stateless call.
    // One schema-aware iterative pass establishes malformed, root-shape,
    // canonical-spelling and structural-profile priority while indexing the
    // canonical typed fields. Accepted messages therefore need no separate root,
    // protocol, artifact, or capability-validation traversal and no general
    // JsonValue tree or canonical reconstruction.
    const std::string_view text(
        reinterpret_cast<const char*>(payload.data()), payload.size());
    CanonicalMessagePreflight preflight_parser(text);
    const CanonicalMessagePreflightObservation* preflight_pointer = nullptr;
    try {
        preflight_pointer = &preflight_parser.inspect();
    } catch (const Failure&) {
        return observation(NATravPeerMessageDecodeStatus::malformed_json);
    }
    const CanonicalMessagePreflightObservation& preflight =
        *preflight_pointer;
    if (preflight.root_kind != JsonValue::Kind::object) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }
    if (!preflight.canonical) {
        return observation(NATravPeerMessageDecodeStatus::noncanonical_json);
    }
    if (!preflight.tree_admissible()) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }

    const CanonicalMessageFieldSpans& fields = preflight.fields;
    if (!fields.kind || fields.kind->kind != JsonValue::Kind::string) {
        return observation(NATravPeerMessageDecodeStatus::message_kind_rejected);
    }

    NATravPeerHandshakeMessageKind kind =
        NATravPeerHandshakeMessageKind::unknown;
    if (fields.kind->bytes == "\"HELLO\"") {
        kind = NATravPeerHandshakeMessageKind::hello;
    } else if (fields.kind->bytes == "\"HELLO_ACK\"") {
        kind = NATravPeerHandshakeMessageKind::hello_ack;
    } else if (fields.kind->bytes == "\"ERROR\"") {
        kind = NATravPeerHandshakeMessageKind::error;
    } else {
        return observation(NATravPeerMessageDecodeStatus::message_kind_rejected);
    }

    if (!canonical_message_shape_exact(fields, kind)) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }

    CanonicalProtocolProjection protocol;
    if (!project_indexed_protocol_revision_0474(preflight.protocol, protocol)) {
        return observation(NATravPeerMessageDecodeStatus::protocol_mismatch);
    }

    const std::string_view request_id =
        canonical_ascii_string_contents(*fields.request_id);
    if (fields.request_id->kind != JsonValue::Kind::string ||
        !lower_hex_sha256(request_id)) {
        return observation(NATravPeerMessageDecodeStatus::request_id_rejected);
    }

    CanonicalArtifactProjection artifact;
    CanonicalCapabilityProjection capabilities;
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        if (!project_indexed_artifact(fields, preflight.artifact, artifact)) {
            return observation(
                NATravPeerMessageDecodeStatus::artifact_identity_rejected);
        }
        const CanonicalCapabilityFieldIndex& capability_index =
            kind == NATravPeerHandshakeMessageKind::hello ?
                preflight.required_capabilities :
                preflight.available_capabilities;
        if (!project_indexed_capabilities(
                fields,
                kind == NATravPeerHandshakeMessageKind::hello ?
                    kCanonicalMessageRequiredCapabilitiesBit :
                    kCanonicalMessageAvailableCapabilitiesBit,
                kind == NATravPeerHandshakeMessageKind::hello ?
                    fields.required_capabilities :
                    fields.available_capabilities,
                capability_index,
                capabilities)) {
            return observation(
                NATravPeerMessageDecodeStatus::capability_declaration_rejected);
        }
    } else {
        const std::string_view code =
            canonical_ascii_string_contents(*fields.code);
        if (fields.code->kind != JsonValue::Kind::string ||
            !capability_token(code) ||
            fields.message->kind != JsonValue::Kind::string ||
            fields.message->bytes.size() == 2U) {
            return observation(NATravPeerMessageDecodeStatus::schema_rejected);
        }
    }

    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = protocol.minor,
    };
    message.request_id.assign(request_id);
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = NATravPeerArtifactIdentity{
            .sha256 = std::string(
                canonical_ascii_string_contents(artifact.sha256)),
            .target = decode_canonical_string(artifact.target),
            .version = decode_canonical_string(artifact.version),
        };
        const CanonicalJsonSpan capability_span =
            kind == NATravPeerHandshakeMessageKind::hello ?
                *fields.required_capabilities :
                *fields.available_capabilities;
        std::vector<std::string> decoded_capabilities =
            decode_canonical_capabilities(
                capability_span, capabilities.count);
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            message.required_capabilities =
                std::move(decoded_capabilities);
        } else {
            message.available_capabilities =
                std::move(decoded_capabilities);
        }
    } else {
        message.error_code.assign(
            canonical_ascii_string_contents(*fields.code));
        message.error_message = decode_canonical_string(*fields.message);
    }

    return NATravPeerMessageDecodeObservation{
        .status = NATravPeerMessageDecodeStatus::accepted,
        .classification = "ACCEPTED",
        .message = std::move(message),
    };
}

#endif

std::string_view natrav_peer_message_decode_status_name(
    const NATravPeerMessageDecodeStatus status) noexcept {
    switch (status) {
        case NATravPeerMessageDecodeStatus::accepted: return "ACCEPTED";
        case NATravPeerMessageDecodeStatus::malformed_json:
            return "MALFORMED_JSON";
        case NATravPeerMessageDecodeStatus::noncanonical_json:
            return "NONCANONICAL_JSON";
        case NATravPeerMessageDecodeStatus::schema_rejected:
            return "SCHEMA_REJECTED";
        case NATravPeerMessageDecodeStatus::message_kind_rejected:
            return "MESSAGE_KIND_REJECTED";
        case NATravPeerMessageDecodeStatus::protocol_mismatch:
            return "PROTOCOL_MISMATCH";
        case NATravPeerMessageDecodeStatus::request_id_rejected:
            return "REQUEST_ID_REJECTED";
        case NATravPeerMessageDecodeStatus::artifact_identity_rejected:
            return "ARTIFACT_IDENTITY_REJECTED";
        case NATravPeerMessageDecodeStatus::capability_declaration_rejected:
            return "CAPABILITY_DECLARATION_REJECTED";
        case NATravPeerMessageDecodeStatus::payload_size_rejected:
            return "PAYLOAD_SIZE_REJECTED";
    }
    return "UNKNOWN";
}

}  // namespace datacube
// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_PAYLOAD_BOUNDARY_TEST
#include "datacube/natrav_peer_session.hpp"
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_payload_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(std::size_t value) noexcept : point(value) {}
    const char* what() const noexcept override { return "NATRAV_PAYLOAD_TEST_BAD_ALLOC"; }
    std::size_t point;
};
struct State final {
    bool armed{false};
    bool persistent{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    std::size_t attempts{0U};
    std::size_t maximum{0U};
    std::size_t total{0U};
};
thread_local State state;
void arm(std::size_t point = std::numeric_limits<std::size_t>::max(),
         bool persistent = false) noexcept {
    state = {true, persistent, point, 0U, 0U, 0U};
}
void disarm() noexcept { state.armed = false; }
void allocation(std::size_t size) {
    if (!state.armed) { return; }
    const auto point = state.attempts++;
    state.maximum = std::max(state.maximum, size);
    state.total += size;
    if (point == state.point || (state.persistent && point > state.point)) {
        throw InjectedBadAlloc(point);
    }
}
void* allocate(std::size_t size) {
    allocation(size);
    void* result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) { throw std::bad_alloc(); }
    return result;
}
void* aligned(std::size_t size, std::align_val_t alignment) {
    allocation(size);
    void* result = nullptr;
    if (posix_memalign(&result, static_cast<std::size_t>(alignment),
                      size == 0U ? 1U : size) != 0) { throw std::bad_alloc(); }
    return result;
}
[[gnu::noinline]] void release(void* pointer) noexcept { std::free(pointer); }
}
void* operator new(std::size_t size) { return natrav_payload_allocation_test::allocate(size); }
void* operator new[](std::size_t size) { return natrav_payload_allocation_test::allocate(size); }
void operator delete(void* pointer) noexcept { natrav_payload_allocation_test::release(pointer); }
void operator delete[](void* pointer) noexcept { natrav_payload_allocation_test::release(pointer); }
void operator delete(void* pointer, std::size_t) noexcept { natrav_payload_allocation_test::release(pointer); }
void operator delete[](void* pointer, std::size_t) noexcept { natrav_payload_allocation_test::release(pointer); }
void* operator new(std::size_t size, std::align_val_t alignment) {
    return natrav_payload_allocation_test::aligned(size, alignment);
}
void* operator new[](std::size_t size, std::align_val_t alignment) {
    return natrav_payload_allocation_test::aligned(size, alignment);
}
void operator delete(void* pointer, std::align_val_t) noexcept { natrav_payload_allocation_test::release(pointer); }
void operator delete[](void* pointer, std::align_val_t) noexcept { natrav_payload_allocation_test::release(pointer); }
void operator delete(void* pointer, std::size_t, std::align_val_t) noexcept { natrav_payload_allocation_test::release(pointer); }
void operator delete[](void* pointer, std::size_t, std::align_val_t) noexcept { natrav_payload_allocation_test::release(pointer); }

namespace datacube {
// Exact revision-0467 decoder body below; only the function name is changed.
// It shares the unchanged parser/schema helpers, and is not part of the runtime.
NATravPeerMessageDecodeObservation historical_decode_message_0467(
    const OctetView payload) {
    if (payload.empty()) {
        return observation(NATravPeerMessageDecodeStatus::malformed_json);
    }
    const std::string text(
        reinterpret_cast<const char*>(payload.data()), payload.size());
    JsonValue parsed;
    try {
        parsed = JsonParser(text).parse();
    } catch (const Failure&) {
        return observation(NATravPeerMessageDecodeStatus::malformed_json);
    }
    if (parsed.kind != JsonValue::Kind::object) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }
    std::string canonical;
    append_canonical_json(parsed, canonical);
    if (canonical != text) {
        return observation(NATravPeerMessageDecodeStatus::noncanonical_json);
    }

    const JsonValue* const kind = member(parsed, "kind");
    if (kind == nullptr || kind->kind != JsonValue::Kind::string ||
        (kind->string_value != "HELLO" &&
         kind->string_value != "HELLO_ACK" &&
         kind->string_value != "ERROR")) {
        return observation(NATravPeerMessageDecodeStatus::message_kind_rejected);
    }

    bool shape_exact = false;
    if (kind->string_value == "HELLO") {
        shape_exact = object_keys_exact(
            &parsed,
            {"artifact", "kind", "protocol", "request_id",
             "required_capabilities"});
    } else if (kind->string_value == "HELLO_ACK") {
        shape_exact = object_keys_exact(
            &parsed,
            {"artifact", "available_capabilities", "kind", "protocol",
             "request_id"});
    } else {
        shape_exact = object_keys_exact(
            &parsed, {"code", "kind", "message", "protocol", "request_id"});
    }
    if (!shape_exact) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }
    if (!protocol_object_exact(member(parsed, "protocol"))) {
        return observation(NATravPeerMessageDecodeStatus::protocol_mismatch);
    }
    if (!lower_hex_sha256(member(parsed, "request_id"))) {
        return observation(NATravPeerMessageDecodeStatus::request_id_rejected);
    }

    NATravPeerHandshakeMessage message;
    message.protocol = protocol_value(parsed);
    message.request_id = member(parsed, "request_id")->string_value;
    if (kind->string_value == "HELLO" || kind->string_value == "HELLO_ACK") {
        if (!artifact_object_exact(member(parsed, "artifact"))) {
            return observation(
                NATravPeerMessageDecodeStatus::artifact_identity_rejected);
        }
        const std::string_view capability_member =
            kind->string_value == "HELLO" ?
                "required_capabilities" : "available_capabilities";
        if (!capability_array_exact(member(parsed, capability_member))) {
            return observation(
                NATravPeerMessageDecodeStatus::capability_declaration_rejected);
        }
        message.artifact = artifact_value(parsed);
        if (kind->string_value == "HELLO") {
            message.kind = NATravPeerHandshakeMessageKind::hello;
            message.required_capabilities =
                capability_values(parsed, capability_member);
        } else {
            message.kind = NATravPeerHandshakeMessageKind::hello_ack;
            message.available_capabilities =
                capability_values(parsed, capability_member);
        }
    } else {
        const JsonValue* const code = member(parsed, "code");
        const JsonValue* const error_message = member(parsed, "message");
        if (!nonempty_string(code) || !capability_token(code->string_value) ||
            !nonempty_string(error_message)) {
            return observation(NATravPeerMessageDecodeStatus::schema_rejected);
        }
        message.kind = NATravPeerHandshakeMessageKind::error;
        message.error_code = code->string_value;
        message.error_message = error_message->string_value;
    }

    return NATravPeerMessageDecodeObservation{
        .status = NATravPeerMessageDecodeStatus::accepted,
        .classification = "ACCEPTED",
        .message = std::move(message),
    };
}
}  // namespace datacube

namespace natrav_payload_boundary_test {
using namespace datacube;
using namespace natrav_payload_allocation_test;
using Status = NATravPeerMessageDecodeStatus;
using Message = NATravPeerHandshakeMessage;
using Observation = NATravPeerMessageDecodeObservation;
struct Results final {
    std::size_t canonical_cases{0U}, decoder_cases{0U}, historical_comparisons{0U};
    std::size_t historical_oversize_acceptances{0U}, roundtrips{0U}, encoder_checks{0U};
    std::size_t factory_checks{0U}, frame_checks{0U}, session_checks{0U};
    std::size_t fragmentation_cases{0U}, header_cases{0U}, input_checks{0U};
    std::size_t size_rejections{0U}, bounded_allocation_checks{0U};
    std::size_t rejection_maximum_allocation{0U}, rejection_allocation_count{0U};
    std::size_t historical_maximum_allocation{0U}, historical_allocation_count{0U};
    std::size_t fault_cases{0U}, faults{0U}, original_exceptions{0U};
    std::size_t exception_attempt_checks{0U}, success_boundaries{0U};
    std::size_t stateless_retry_checks{0U}, historical_fault_checks{0U}, failures{0U};
};
void check(Results& r, bool okay, const char* label) {
    if (!okay) {
        ++r.failures;
        if (r.failures <= 24U) { std::fprintf(stderr, "FAIL %s\n", label); }
    }
}
bool envelope(std::size_t bytes) noexcept { return bytes >= 2U && bytes <= 65536U; }
bool same(const Message& a, const Message& b) {
    return a.kind == b.kind && a.protocol.id == b.protocol.id &&
        a.protocol.major == b.protocol.major && a.protocol.minor == b.protocol.minor &&
        a.request_id == b.request_id && a.artifact.sha256 == b.artifact.sha256 &&
        a.artifact.target == b.artifact.target && a.artifact.version == b.artifact.version &&
        a.required_capabilities == b.required_capabilities &&
        a.available_capabilities == b.available_capabilities &&
        a.error_code == b.error_code && a.error_message == b.error_message;
}
bool same(const Observation& a, const Observation& b) {
    return a.status == b.status && a.classification == b.classification &&
        a.message.has_value() == b.message.has_value() &&
        (!a.message || same(*a.message, *b.message));
}
// Independent serializer for these bounded fixtures; no production JSON helpers.
std::string quote(std::string_view input) {
    constexpr std::string_view hex = "0123456789abcdef";
    std::string result = "\"";
    for (char raw : input) {
        const auto c = static_cast<unsigned char>(raw);
        switch (c) {
            case '"': result += "\\\""; break;
            case '\\': result += "\\\\"; break;
            case '\b': result += "\\b"; break;
            case '\f': result += "\\f"; break;
            case '\n': result += "\\n"; break;
            case '\r': result += "\\r"; break;
            case '\t': result += "\\t"; break;
            default:
                if (c < 32U) {
                    result += "\\u00"; result += hex[c >> 4U]; result += hex[c & 15U];
                } else { result += raw; }
        }
    }
    result += '"';
    return result;
}
std::string array(const std::vector<std::string>& values) {
    std::string result = "[";
    for (std::size_t i = 0U; i < values.size(); ++i) {
        if (i != 0U) { result += ','; }
        result += quote(values[i]);
    }
    return result + ']';
}
std::string serialize(const Message& m) {
    const auto protocol = "{\"id\":" + quote(m.protocol.id) +
        ",\"major\":" + std::to_string(m.protocol.major) + ",\"minor\":" +
        std::to_string(m.protocol.minor) + '}';
    if (m.kind == NATravPeerHandshakeMessageKind::error) {
        return "{\"code\":" + quote(m.error_code) + ",\"kind\":\"ERROR\",\"message\":" +
            quote(m.error_message) + ",\"protocol\":" + protocol +
            ",\"request_id\":" + quote(m.request_id) + '}';
    }
    const auto artifact = "{\"sha256\":" + quote(m.artifact.sha256) +
        ",\"target\":" + quote(m.artifact.target) + ",\"version\":" + quote(m.artifact.version) + '}';
    if (m.kind == NATravPeerHandshakeMessageKind::hello) {
        return "{\"artifact\":" + artifact + ",\"kind\":\"HELLO\",\"protocol\":" + protocol +
            ",\"request_id\":" + quote(m.request_id) +
            ",\"required_capabilities\":" + array(m.required_capabilities) + '}';
    }
    return "{\"artifact\":" + artifact + ",\"available_capabilities\":" + array(m.available_capabilities) +
        ",\"kind\":\"HELLO_ACK\",\"protocol\":" + protocol + ",\"request_id\":" + quote(m.request_id) + '}';
}
Message base(unsigned variant) {
    Message m;
    m.kind = variant < 2U ? NATravPeerHandshakeMessageKind::hello :
        variant < 4U ? NATravPeerHandshakeMessageKind::hello_ack : NATravPeerHandshakeMessageKind::error;
    m.protocol = {"NATRAV_OVERLAY_PEER", 1, 0};
    m.request_id = std::string(64U, '1');
    if (variant < 4U) {
        m.artifact = {std::string(64U, 'a'), "target", "version"};
        if (variant < 2U) { m.required_capabilities = {"PING", "STATUS"}; }
        else { m.available_capabilities = {"PING", "STATUS"}; }
    } else { m.error_code = "TEST"; m.error_message = "message"; }
    return m;
}
std::string& field(Message& m, unsigned variant) {
    if (variant == 4U) { return m.error_message; }
    return variant % 2U == 0U ? m.artifact.target : m.artifact.version;
}
Message sized(unsigned variant, std::size_t bytes, std::string_view unit) {
    auto m = base(variant);
    auto& value = field(m, variant);
    value.clear();
    const auto overhead = serialize(m).size();
    if (bytes <= overhead) { throw std::runtime_error("bad fixture size"); }
    const auto width = quote(unit).size() - 2U;
    const auto available = bytes - overhead;
    for (std::size_t i = 0U; i < available / width; ++i) { value += unit; }
    value.append(available % width, 'x');
    return m;
}
Observation decode_check(Results& r, const Octets& payload, bool canonical = false) {
    const auto before = payload;
    const auto actual = natrav_peer_decode_message(payload);
    ++r.decoder_cases;
    if (envelope(payload.size())) {
        const auto old = historical_decode_message_0467(payload);
        ++r.historical_comparisons;
        check(r, same(actual, old), "in_envelope_predecessor_equivalence");
        if (actual.message) {
            const auto encoded = natrav_peer_encode_message(*actual.message);
            ++r.roundtrips;
            check(r, encoded.status == NATravPeerMessageEncodeStatus::accepted &&
                encoded.payload && *encoded.payload == payload, "accepted_roundtrip");
        }
    } else {
        ++r.size_rejections;
        check(r, actual.status == Status::payload_size_rejected && !actual.message &&
            actual.classification == "PAYLOAD_SIZE_REJECTED", "envelope_rejection");
        arm();
        const auto rejection = natrav_peer_decode_message(payload);
        const auto measured = state; disarm();
        ++r.bounded_allocation_checks;
        r.rejection_maximum_allocation = std::max(r.rejection_maximum_allocation, measured.maximum);
        r.rejection_allocation_count = std::max(r.rejection_allocation_count, measured.attempts);
        check(r, same(rejection, actual) && measured.maximum <= 64U && measured.attempts <= 2U,
              "reject_without_input_sized_storage");
        if (canonical) {
            arm();
            const auto old = historical_decode_message_0467(payload);
            const auto old_measured = state; disarm();
            ++r.historical_oversize_acceptances;
            r.historical_maximum_allocation = std::max(r.historical_maximum_allocation, old_measured.maximum);
            r.historical_allocation_count = std::max(r.historical_allocation_count, old_measured.attempts);
            check(r, old.status == Status::accepted && old.message &&
                natrav_peer_encode_message(*old.message).status == NATravPeerMessageEncodeStatus::payload_size_rejected,
                "historical_roundtrip_gap");
        }
    }
    ++r.input_checks;
    check(r, payload == before, "decode_input_preserved");
    return actual;
}
Octets raw_frame(const Octets& payload) {
    const auto size = static_cast<std::uint32_t>(payload.size());
    Octets result = {static_cast<std::uint8_t>(size >> 24U), static_cast<std::uint8_t>(size >> 16U),
                    static_cast<std::uint8_t>(size >> 8U), static_cast<std::uint8_t>(size)};
    result.insert(result.end(), payload.begin(), payload.end());
    return result;
}
NATravPeerHandshakeExpectation expectation(const Message& m) {
    return {m.protocol, m.request_id, m.artifact, {"PING", "STATUS"}};
}
void frames(Results& r, const Octets& payload, const Message* m, bool fragmented) {
    const auto bytes = raw_frame(payload);
    bool rejected = false;
    try { const auto encoded = natrav_peer_encode_frame(payload);
        check(r, encoded == bytes, "frame_header_and_payload"); }
    catch (const Failure&) { rejected = true; }
    ++r.frame_checks;
    check(r, rejected == !envelope(payload.size()), "frame_encoder_admission");
    std::vector<std::size_t> splits = {bytes.size()};
    if (fragmented) {
        splits = {0U, 1U, 2U, 3U, 4U, bytes.size() / 2U, bytes.size() - 1U, bytes.size()};
    }
    const auto small = base(2U);
    const auto e = expectation(m == nullptr ? small : *m);
    for (const auto split : splits) {
        NATravPeerStreamDecoder stream;
        std::vector<Octets> output = {text_octets("sentinel")};
        NATravPeerHandshakeStreamSession session(e);
        const auto head = OctetView(bytes).first(split), tail = OctetView(bytes).subspan(split);
        static_cast<void>(stream.feed(head, output));
        auto raw = stream.feed(tail, output);
        static_cast<void>(session.feed(head));
        auto obs = session.feed(tail);
        ++r.fragmentation_cases; ++r.frame_checks; ++r.session_checks;
        if (!envelope(payload.size())) {
            check(r, raw.status == NATravPeerStreamStatus::malformed_frame && output.size() == 1U &&
                stream.buffered_bytes() == 4U && stream.expected_payload_bytes() == payload.size(), "raw_bad_length");
            check(r, obs.status == NATravPeerSessionStatus::malformed_frame &&
                obs.frames_observed == 0U && obs.messages_decoded == 0U &&
                obs.handshake_transitions == 0U, "session_bad_length_before_decode");
            const auto count = obs.chunks_observed;
            static_cast<void>(session.feed(bytes)); obs = session.finish();
            check(r, obs.status == NATravPeerSessionStatus::malformed_frame && obs.chunks_observed == count,
                  "bad_length_session_quiescence");
        } else {
            check(r, output.size() == 2U && output.back() == payload && stream.buffered_bytes() == 0U,
                  "frame_exact_emission");
            if (m != nullptr) {
                const auto expected = m->kind == NATravPeerHandshakeMessageKind::hello ?
                    NATravPeerSessionStatus::message_kind_rejected : m->kind == NATravPeerHandshakeMessageKind::hello_ack ?
                    NATravPeerSessionStatus::accepted : NATravPeerSessionStatus::peer_error;
                check(r, obs.status == expected && obs.frames_observed == 1U &&
                    obs.messages_decoded == 1U && obs.handshake_transitions == 1U,
                    "layered_canonical_message_admission");
            } else {
                check(r, obs.frames_observed == 1U && obs.messages_decoded == 0U, "framing_is_not_schema_admission");
            }
        }
        const auto final_raw = stream.finish(output);
        ++r.frame_checks;
        check(r, output.front() == text_octets("sentinel") && final_raw.emitted_frames == 0U &&
            final_raw.status == (envelope(payload.size()) ? NATravPeerStreamStatus::stream_closed :
                                                          NATravPeerStreamStatus::malformed_frame), "eof_and_output_prefix");
    }
}
void factory(Results& r, const Message& m, unsigned variant, const Octets& payload) {
    if (variant == 4U) { return; }
    const auto small = base(0U);
    NATravPeerClientHandshakeInput input{m.protocol, m.request_id, small.artifact, small.artifact, {"PING", "STATUS"}};
    if (variant < 2U) { input.local_artifact = m.artifact; }
    else { input.expected_peer_artifact = m.artifact; }
    const auto result = natrav_peer_prepare_client_handshake(input);
    ++r.factory_checks;
    const auto expected = envelope(payload.size()) ? NATravPeerClientPreparationStatus::prepared :
        variant < 2U ? NATravPeerClientPreparationStatus::outbound_payload_size_rejected :
                       NATravPeerClientPreparationStatus::expected_response_payload_size_rejected;
    check(r, result.status == expected && result.prepared.has_value() == envelope(payload.size()), "factory_boundary");
    if (result.prepared && variant < 2U) {
        check(r, result.prepared->payload == payload, "factory_exact_outbound");
    }
}
void faults(Results& r, const Octets& payload) {
    const auto before = payload;
    arm(); const auto success = natrav_peer_decode_message(payload);
    const auto points = state.attempts; disarm();
    for (bool persistent : {false, true}) {
        for (std::size_t point = 0U; point <= points; ++point) {
            ++r.fault_cases;
            std::optional<Observation> actual;
            bool caught = false;
            arm(point, persistent);
            try { actual.emplace(natrav_peer_decode_message(payload)); }
            catch (const InjectedBadAlloc& error) { caught = error.point == point; }
            const auto measured = state; disarm();
            ++r.input_checks;
            check(r, payload == before, "allocation_input_preserved");
            if (point < points) {
                ++r.faults; r.original_exceptions += caught ? 1U : 0U;
                ++r.exception_attempt_checks;
                check(r, caught && !actual && measured.attempts == point + 1U, "unchanged_exception_no_extra_allocation");
            } else {
                ++r.success_boundaries;
                check(r, !caught && actual && same(*actual, success), "allocation_success_boundary");
            }
            ++r.stateless_retry_checks;
            check(r, same(natrav_peer_decode_message(payload), success), "stateless_retry_after_recovery");
        }
    }

    // Revision 0471 intentionally changes the accepted-path allocation graph.
    // Retain the revision-0468 historical fault contract independently rather
    // than requiring the two implementations to allocate at identical ordinals.
    if (envelope(payload.size())) {
        arm(); const auto old_success = historical_decode_message_0467(payload);
        const auto old_points = state.attempts; disarm();
        for (bool persistent : {false, true}) {
            for (std::size_t point = 0U; point <= old_points; ++point) {
                std::optional<Observation> old;
                bool old_caught = false;
                arm(point, persistent);
                try { old.emplace(historical_decode_message_0467(payload)); }
                catch (const InjectedBadAlloc& error) {
                    old_caught = error.point == point;
                }
                const auto measured = state; disarm();
                ++r.historical_fault_checks;
                ++r.input_checks;
                check(r, payload == before, "historical_allocation_input_preserved");
                if (point < old_points) {
                    check(r, old_caught && !old && measured.attempts == point + 1U,
                          "historical_original_exception_no_extra_allocation");
                } else {
                    check(r, !old_caught && old && same(*old, old_success) &&
                          measured.attempts == old_points,
                          "historical_allocation_success_boundary");
                }
            }
        }
    }
}

void headers(Results& r) {
    for (std::uint32_t length : {0U, 1U, 2U, 65535U, 65536U, 65537U, 0x7fffffffU, 0x80000000U, 0xffffffffU}) {
        const Octets header = {static_cast<std::uint8_t>(length >> 24U), static_cast<std::uint8_t>(length >> 16U),
                              static_cast<std::uint8_t>(length >> 8U), static_cast<std::uint8_t>(length)};
        for (std::size_t prefix = 0U; prefix <= 4U; ++prefix) {
            NATravPeerStreamDecoder d;
            std::vector<Octets> out;
            static_cast<void>(d.feed(OctetView(header).first(prefix), out));
            const auto result = d.finish(out);
            ++r.header_cases;
            const auto expected = prefix == 0U ? NATravPeerStreamStatus::stream_closed :
                prefix == 4U && !envelope(length) ? NATravPeerStreamStatus::malformed_frame :
                                                  NATravPeerStreamStatus::peer_unavailable;
            check(r, result.status == expected && out.empty() && d.buffered_bytes() == prefix,
                  "bounded_header_only_eof");
        }
    }
}
int run() {
    static_assert(kNATravPeerMinimumPayloadBytes == 2U && kNATravPeerMaximumPayloadBytes == 65536U);
    static_assert(kNATravPeerFrameHeaderBytes == 4U);
    static_assert(static_cast<int>(Status::accepted) == 0 && static_cast<int>(Status::capability_declaration_rejected) == 8);
    static_assert(static_cast<int>(Status::payload_size_rejected) == 9);
    Results r;
    check(r, natrav_peer_message_decode_status_name(Status::payload_size_rejected) == "PAYLOAD_SIZE_REJECTED", "status_name");
    const std::vector<std::string> units = {"x", "\"", "\\", "\n", std::string(1U, '\0'),
        std::string(1U, '\x1f'), "\xc2\xa2", "\xe2\x82\xac", "\xf0\x9f\x98\x80", "x\n\"\xe2\x82\xac"};
    const std::vector<std::size_t> sizes = {1024U, 65532U, 65533U, 65534U, 65535U, 65536U,
                                          65537U, 65538U, 65539U, 65540U, 131072U};
    std::vector<Octets> fault_inputs;
    for (unsigned variant = 0U; variant < 5U; ++variant) {
        for (std::size_t unit = 0U; unit < units.size(); ++unit) {
            for (const auto size : sizes) {
                const auto m = sized(variant, size, units[unit]);
                const auto payload = text_octets(serialize(m));
                ++r.canonical_cases;
                check(r, payload.size() == size, "independent_exact_size_fixture");
                const auto decoded = decode_check(r, payload, true);
                const auto before = m;
                const auto encoded = natrav_peer_encode_message(m);
                ++r.encoder_checks; ++r.input_checks;
                check(r, same(m, before), "typed_input_preserved");
                check(r, encoded.status == (envelope(size) ? NATravPeerMessageEncodeStatus::accepted :
                    NATravPeerMessageEncodeStatus::payload_size_rejected) && encoded.payload.has_value() == envelope(size),
                    "encoder_canonical_byte_count");
                if (envelope(size)) { check(r, *encoded.payload == payload && decoded.message && same(*decoded.message, m), "independent_wire_bytes"); }
                frames(r, payload, &m, unit % 3U == 0U && size >= 65535U && size <= 65537U);
                factory(r, m, variant, payload);
                if (unit == 0U && (size == 1024U || size == 65536U || size == 65537U)) { fault_inputs.push_back(payload); }
            }
        }
    }
    // Every one-byte input, plus empty input: envelope rejection precedes all JSON classifications.
    static_cast<void>(decode_check(r, {}));
    frames(r, {}, nullptr, true); fault_inputs.push_back({});
    for (unsigned byte = 0U; byte < 256U; ++byte) {
        const Octets payload = {static_cast<std::uint8_t>(byte)};
        static_cast<void>(decode_check(r, payload));
        if (byte == 0U || byte == 123U || byte == 255U) { frames(r, payload, nullptr, true); fault_inputs.push_back(payload); }
    }
    const std::vector<std::string> tiny = {"{}", "[]", "0 ", "00", "42", "-1", "null", "true", "\"\"", " { } ", "{\"a\":1,\"a\":2}", "{\"a\":1.5}", "{\"a\":\"\\ud800\"}"};
    for (const auto& text : tiny) {
        const auto payload = text_octets(text); static_cast<void>(decode_check(r, payload));
        frames(r, payload, nullptr, true); fault_inputs.push_back(payload);
    }
    // Exact in-envelope invalid/noncanonical priority equivalence, including wire-schema mutations.
    const auto valid = serialize(base(2U));
    std::vector<std::string> malformed = {" " + valid, valid + " ", "[" + valid + "]",
        "{\"extra\":0," + valid.substr(1U), "\xef\xbb\xbf" + valid};
    for (const auto& entry : std::vector<std::pair<std::string, std::string>>{
            {"HELLO_ACK", "OTHER"}, {"NATRAV_OVERLAY_PEER", "WRONG"},
            {"\"major\":1", "\"major\":2"}, {"\"minor\":0", "\"minor\":-1"},
            {std::string(64U, '1'), "bad"}, {std::string(64U, 'a'), "bad"},
            {"[\"PING\",\"STATUS\"]", "[\"STATUS\",\"PING\"]"}}) {
        auto text = valid; text.replace(text.find(entry.first), entry.first.size(), entry.second); malformed.push_back(text);
    }
    for (const auto& text : malformed) { const auto bytes = text_octets(text); static_cast<void>(decode_check(r, bytes)); fault_inputs.push_back(bytes); }
    for (std::size_t size : {65535U, 65536U, 65537U, 65540U, 131072U, 262144U}) {
        for (unsigned variant = 0U; variant < 5U; ++variant) {
            std::string text(size, variant == 0U ? ' ' : variant == 1U ? '\xff' : 'x');
            if (variant >= 2U) {
                text[0] = '{'; text[text.size() - 1U] = '}';
                if (variant == 3U) { text.replace(0U, valid.size(), valid); }
                if (variant == 4U) { text.replace(0U, 3U, "\xef\xbb\xbf"); }
            }
            const auto bytes = text_octets(text); static_cast<void>(decode_check(r, bytes));
            if (!envelope(size)) { fault_inputs.push_back(bytes); }
        }
    }
    std::uint32_t random = 0x468U;
    for (std::size_t i = 0U; i < 256U; ++i) {
        Octets bytes(2U + i);
        for (auto& byte : bytes) {
            random ^= random << 13U; random ^= random >> 17U; random ^= random << 5U;
            byte = static_cast<std::uint8_t>(random);
        }
        static_cast<void>(decode_check(r, bytes));
    }
    for (const auto& input : fault_inputs) { faults(r, input); }
    headers(r);
    auto peer = base(4U); peer.error_code = "PAYLOAD_SIZE_REJECTED";
    const auto peer_payload = text_octets(serialize(peer));
    static_cast<void>(decode_check(r, peer_payload, true)); frames(r, peer_payload, &peer, true);
    check(r, r.historical_oversize_acceptances != 0U && r.roundtrips != 0U && r.faults != 0U &&
        r.original_exceptions == r.faults && r.historical_fault_checks != 0U &&
        r.rejection_maximum_allocation < r.historical_maximum_allocation, "coverage");
#define PRINT_RESULT(name) std::printf(#name "=%zu\n", r.name)
    PRINT_RESULT(canonical_cases); PRINT_RESULT(decoder_cases); PRINT_RESULT(historical_comparisons);
    PRINT_RESULT(historical_oversize_acceptances); PRINT_RESULT(roundtrips); PRINT_RESULT(encoder_checks);
    PRINT_RESULT(factory_checks); PRINT_RESULT(frame_checks); PRINT_RESULT(session_checks);
    PRINT_RESULT(fragmentation_cases); PRINT_RESULT(header_cases); PRINT_RESULT(input_checks);
    PRINT_RESULT(size_rejections); PRINT_RESULT(bounded_allocation_checks);
    PRINT_RESULT(rejection_maximum_allocation); PRINT_RESULT(rejection_allocation_count);
    PRINT_RESULT(historical_maximum_allocation); PRINT_RESULT(historical_allocation_count);
    PRINT_RESULT(fault_cases); PRINT_RESULT(faults); PRINT_RESULT(original_exceptions);
    PRINT_RESULT(exception_attempt_checks); PRINT_RESULT(success_boundaries);
    PRINT_RESULT(stateless_retry_checks); PRINT_RESULT(historical_fault_checks); PRINT_RESULT(failures);
#undef PRINT_RESULT
    return r.failures == 0U ? 0 : 1;
}
}  // namespace natrav_payload_boundary_test
int main() {
    try { return natrav_payload_boundary_test::run(); }
    catch (const std::exception& e) {
        natrav_payload_allocation_test::disarm();
        std::fprintf(stderr, "UNEXPECTED %s\n", e.what()); return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_PAYLOAD_BOUNDARY_TEST

// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_ENCODER_BOUND_TEST
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_encoder_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t value) noexcept : point(value) {}
    const char* what() const noexcept override {
        return "NATRAV_ENCODER_TEST_BAD_ALLOC";
    }
    std::size_t point;
};

struct State final {
    bool armed{false};
    bool persistent{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    std::size_t attempts{0U};
    std::size_t maximum{0U};
    std::size_t total{0U};
};

thread_local State state;

void arm(
    const std::size_t point = std::numeric_limits<std::size_t>::max(),
    const bool persistent = false) noexcept {
    state = {true, persistent, point, 0U, 0U, 0U};
}

void disarm() noexcept { state.armed = false; }

void allocation(const std::size_t size) {
    if (!state.armed) {
        return;
    }
    const std::size_t point = state.attempts++;
    state.maximum = std::max(state.maximum, size);
    state.total += size;
    if (point == state.point || (state.persistent && point > state.point)) {
        throw InjectedBadAlloc(point);
    }
}

void* allocate(const std::size_t size) {
    allocation(size);
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned(const std::size_t size, const std::align_val_t alignment) {
    allocation(size);
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

[[gnu::noinline]] void release(void* const pointer) noexcept {
    std::free(pointer);
}
}  // namespace natrav_encoder_allocation_test

void* operator new(const std::size_t size) {
    return natrav_encoder_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_encoder_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_encoder_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_encoder_allocation_test::release(pointer);
}
void operator delete(void* const pointer, std::size_t) noexcept {
    natrav_encoder_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, std::size_t) noexcept {
    natrav_encoder_allocation_test::release(pointer);
}
void* operator new(const std::size_t size, const std::align_val_t alignment) {
    return natrav_encoder_allocation_test::aligned(size, alignment);
}
void* operator new[](const std::size_t size, const std::align_val_t alignment) {
    return natrav_encoder_allocation_test::aligned(size, alignment);
}
void operator delete(void* const pointer, std::align_val_t) noexcept {
    natrav_encoder_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, std::align_val_t) noexcept {
    natrav_encoder_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    std::size_t,
    std::align_val_t) noexcept {
    natrav_encoder_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    std::size_t,
    std::align_val_t) noexcept {
    natrav_encoder_allocation_test::release(pointer);
}

namespace datacube {
namespace {

// Exact revision-0468 serialization helpers and encoder body. Names only are
// changed; this oracle is excluded from runtime and forge builds.
void historical_append_json_string_0468(
    std::string& output,
    const std::string_view value) {
    output.push_back('"');
    output.append(json_escape(value));
    output.push_back('"');
}

void historical_append_protocol_value_0468(
    std::string& output,
    const NATravPeerProtocolVersion& protocol) {
    output.append("{\"id\":");
    historical_append_json_string_0468(output, protocol.id);
    output.append(",\"major\":");
    output.append(std::to_string(protocol.major));
    output.append(",\"minor\":");
    output.append(std::to_string(protocol.minor));
    output.push_back('}');
}

void historical_append_artifact_value_0468(
    std::string& output,
    const NATravPeerArtifactIdentity& artifact) {
    output.append("{\"sha256\":");
    historical_append_json_string_0468(output, artifact.sha256);
    output.append(",\"target\":");
    historical_append_json_string_0468(output, artifact.target);
    output.append(",\"version\":");
    historical_append_json_string_0468(output, artifact.version);
    output.push_back('}');
}

void historical_append_capability_values_0468(
    std::string& output,
    const std::vector<std::string>& capabilities) {
    output.push_back('[');
    for (std::size_t index = 0U; index < capabilities.size(); ++index) {
        if (index != 0U) {
            output.push_back(',');
        }
        historical_append_json_string_0468(output, capabilities[index]);
    }
    output.push_back(']');
}

}  // namespace

NATravPeerMessageEncodeObservation historical_encode_message_0468(
    const NATravPeerHandshakeMessage& message) {
    switch (message.kind) {
        case NATravPeerHandshakeMessageKind::hello:
            if (!message.available_capabilities.empty() ||
                !message.error_code.empty() || !message.error_message.empty()) {
                return encode_observation(
                    NATravPeerMessageEncodeStatus::schema_rejected);
            }
            break;
        case NATravPeerHandshakeMessageKind::hello_ack:
            if (!message.required_capabilities.empty() ||
                !message.error_code.empty() || !message.error_message.empty()) {
                return encode_observation(
                    NATravPeerMessageEncodeStatus::schema_rejected);
            }
            break;
        case NATravPeerHandshakeMessageKind::error:
            if (!artifact_value_empty(message.artifact) ||
                !message.required_capabilities.empty() ||
                !message.available_capabilities.empty()) {
                return encode_observation(
                    NATravPeerMessageEncodeStatus::schema_rejected);
            }
            break;
        case NATravPeerHandshakeMessageKind::unknown:
            return encode_observation(
                NATravPeerMessageEncodeStatus::message_kind_rejected);
    }

    if (!protocol_value_exact(message.protocol)) {
        return encode_observation(
            NATravPeerMessageEncodeStatus::protocol_mismatch);
    }
    if (!lower_hex_sha256(message.request_id)) {
        return encode_observation(
            NATravPeerMessageEncodeStatus::request_id_rejected);
    }

    if (message.kind == NATravPeerHandshakeMessageKind::hello ||
        message.kind == NATravPeerHandshakeMessageKind::hello_ack) {
        if (!artifact_value_exact(message.artifact)) {
            return encode_observation(
                NATravPeerMessageEncodeStatus::artifact_identity_rejected);
        }
        const std::vector<std::string>& capabilities =
            message.kind == NATravPeerHandshakeMessageKind::hello ?
                message.required_capabilities :
                message.available_capabilities;
        if (!capability_array_exact(capabilities)) {
            return encode_observation(
                NATravPeerMessageEncodeStatus::capability_declaration_rejected);
        }
    } else if (!capability_token(message.error_code) ||
               message.error_message.empty() ||
               !utf8_scalar_sequence(message.error_message)) {
        return encode_observation(
            NATravPeerMessageEncodeStatus::schema_rejected);
    }

    std::string output;
    if (message.kind == NATravPeerHandshakeMessageKind::hello) {
        output.append("{\"artifact\":");
        historical_append_artifact_value_0468(output, message.artifact);
        output.append(",\"kind\":\"HELLO\",\"protocol\":");
        historical_append_protocol_value_0468(output, message.protocol);
        output.append(",\"request_id\":");
        historical_append_json_string_0468(output, message.request_id);
        output.append(",\"required_capabilities\":");
        historical_append_capability_values_0468(
            output, message.required_capabilities);
        output.push_back('}');
    } else if (message.kind == NATravPeerHandshakeMessageKind::hello_ack) {
        output.append("{\"artifact\":");
        historical_append_artifact_value_0468(output, message.artifact);
        output.append(",\"available_capabilities\":");
        historical_append_capability_values_0468(
            output, message.available_capabilities);
        output.append(",\"kind\":\"HELLO_ACK\",\"protocol\":");
        historical_append_protocol_value_0468(output, message.protocol);
        output.append(",\"request_id\":");
        historical_append_json_string_0468(output, message.request_id);
        output.push_back('}');
    } else {
        output.append("{\"code\":");
        historical_append_json_string_0468(output, message.error_code);
        output.append(",\"kind\":\"ERROR\",\"message\":");
        historical_append_json_string_0468(output, message.error_message);
        output.append(",\"protocol\":");
        historical_append_protocol_value_0468(output, message.protocol);
        output.append(",\"request_id\":");
        historical_append_json_string_0468(output, message.request_id);
        output.push_back('}');
    }

    if (output.size() < kNATravPeerMinimumPayloadBytes ||
        output.size() > kNATravPeerMaximumPayloadBytes) {
        return encode_observation(
            NATravPeerMessageEncodeStatus::payload_size_rejected);
    }
    return NATravPeerMessageEncodeObservation{
        .status = NATravPeerMessageEncodeStatus::accepted,
        .classification = "ACCEPTED",
        .payload = text_octets(output),
    };
}

}  // namespace datacube

namespace natrav_encoder_bound_test {
using namespace datacube;
using namespace natrav_encoder_allocation_test;
using Message = NATravPeerHandshakeMessage;
using Observation = NATravPeerMessageEncodeObservation;
using Status = NATravPeerMessageEncodeStatus;

struct Results final {
    std::size_t canonical_cases{0U};
    std::size_t boundary_cases{0U};
    std::size_t historical_comparisons{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejected_cases{0U};
    std::size_t exact_payload_checks{0U};
    std::size_t roundtrip_checks{0U};
    std::size_t schema_priority_cases{0U};
    std::size_t schema_priority_comparisons{0U};
    std::size_t capability_cases{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t allocation_measurements{0U};
    std::size_t bounded_rejection_checks{0U};
    std::size_t rejection_maximum_allocation{0U};
    std::size_t rejection_allocation_count{0U};
    std::size_t rejection_total_allocation{0U};
    std::size_t historical_rejection_maximum_allocation{0U};
    std::size_t historical_rejection_allocation_count{0U};
    std::size_t historical_rejection_total_allocation{0U};
    std::size_t accepted_allocation_checks{0U};
    std::size_t accepted_maximum_allocation{0U};
    std::size_t accepted_allocation_count{0U};
    std::size_t huge_input_cases{0U};
    std::size_t huge_input_bytes{0U};
    std::size_t fault_scenarios{0U};
    std::size_t faults{0U};
    std::size_t original_exceptions{0U};
    std::size_t exception_attempt_checks{0U};
    std::size_t success_boundaries{0U};
    std::size_t persistent_fault_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(Results& results, const bool okay, const char* const label) {
    if (!okay) {
        ++results.failures;
        if (results.failures <= 32U) {
            std::fprintf(stderr, "FAIL %s\n", label);
        }
    }
}

[[nodiscard]] bool same_message(const Message& left, const Message& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const Observation& left,
    const Observation& right) {
    return left.status == right.status &&
        left.classification == right.classification &&
        left.payload.has_value() == right.payload.has_value() &&
        (!left.payload || *left.payload == *right.payload);
}

[[nodiscard]] bool envelope(const std::size_t bytes) noexcept {
    return bytes >= static_cast<std::size_t>(kNATravPeerMinimumPayloadBytes) &&
        bytes <= static_cast<std::size_t>(kNATravPeerMaximumPayloadBytes);
}

// Independent fixture serializer; it does not call production size or emission
// helpers and is used only while allocation injection is disarmed.
[[nodiscard]] std::string quote(const std::string_view input) {
    static constexpr std::string_view hex = "0123456789abcdef";
    std::string result = "\"";
    for (const char raw : input) {
        const auto byte = static_cast<unsigned char>(raw);
        switch (byte) {
            case '"': result += "\\\""; break;
            case '\\': result += "\\\\"; break;
            case '\b': result += "\\b"; break;
            case '\f': result += "\\f"; break;
            case '\n': result += "\\n"; break;
            case '\r': result += "\\r"; break;
            case '\t': result += "\\t"; break;
            default:
                if (byte < 0x20U) {
                    result += "\\u00";
                    result += hex[byte >> 4U];
                    result += hex[byte & 0x0FU];
                } else {
                    result += raw;
                }
        }
    }
    result += '"';
    return result;
}

[[nodiscard]] std::string array(
    const std::vector<std::string>& values) {
    std::string result = "[";
    for (std::size_t index = 0U; index < values.size(); ++index) {
        if (index != 0U) {
            result += ',';
        }
        result += quote(values[index]);
    }
    result += ']';
    return result;
}

[[nodiscard]] std::string serialize(const Message& message) {
    const std::string protocol =
        "{\"id\":" + quote(message.protocol.id) +
        ",\"major\":" + std::to_string(message.protocol.major) +
        ",\"minor\":" + std::to_string(message.protocol.minor) + '}';
    if (message.kind == NATravPeerHandshakeMessageKind::error) {
        return "{\"code\":" + quote(message.error_code) +
            ",\"kind\":\"ERROR\",\"message\":" +
            quote(message.error_message) + ",\"protocol\":" + protocol +
            ",\"request_id\":" + quote(message.request_id) + '}';
    }
    const std::string artifact =
        "{\"sha256\":" + quote(message.artifact.sha256) +
        ",\"target\":" + quote(message.artifact.target) +
        ",\"version\":" + quote(message.artifact.version) + '}';
    if (message.kind == NATravPeerHandshakeMessageKind::hello) {
        return "{\"artifact\":" + artifact +
            ",\"kind\":\"HELLO\",\"protocol\":" + protocol +
            ",\"request_id\":" + quote(message.request_id) +
            ",\"required_capabilities\":" +
            array(message.required_capabilities) + '}';
    }
    return "{\"artifact\":" + artifact +
        ",\"available_capabilities\":" +
        array(message.available_capabilities) +
        ",\"kind\":\"HELLO_ACK\",\"protocol\":" + protocol +
        ",\"request_id\":" + quote(message.request_id) + '}';
}

[[nodiscard]] Message base(const unsigned int variant) {
    Message message;
    message.kind = variant < 2U ?
        NATravPeerHandshakeMessageKind::hello :
        variant < 4U ? NATravPeerHandshakeMessageKind::hello_ack :
                       NATravPeerHandshakeMessageKind::error;
    message.protocol = {"NATRAV_OVERLAY_PEER", 1, 0};
    message.request_id = std::string(64U, '1');
    if (variant < 4U) {
        message.artifact = {std::string(64U, 'a'), "target", "version"};
        if (variant < 2U) {
            message.required_capabilities = {"PING", "STATUS"};
        } else {
            message.available_capabilities = {"PING", "STATUS"};
        }
    } else {
        message.error_code = "TEST";
        message.error_message = "message";
    }
    return message;
}

[[nodiscard]] std::string& variable_field(
    Message& message,
    const unsigned int variant) {
    if (variant == 4U) {
        return message.error_message;
    }
    return variant % 2U == 0U ?
        message.artifact.target : message.artifact.version;
}

[[nodiscard]] Message sized(
    const unsigned int variant,
    const std::size_t bytes,
    const std::string_view unit) {
    Message message = base(variant);
    std::string& value = variable_field(message, variant);
    value.clear();
    const std::size_t overhead = serialize(message).size();
    if (bytes <= overhead) {
        throw std::runtime_error("bad encoder fixture size");
    }
    const std::size_t width = quote(unit).size() - 2U;
    const std::size_t available = bytes - overhead;
    for (std::size_t index = 0U; index < available / width; ++index) {
        value.append(unit);
    }
    value.append(available % width, 'x');
    return message;
}

struct MeasuredObservation final {
    Observation observation;
    State measurement;
};

[[nodiscard]] MeasuredObservation measured_current(const Message& message) {
    arm();
    Observation observation = natrav_peer_encode_message(message);
    const State measurement = state;
    disarm();
    return {std::move(observation), measurement};
}

[[nodiscard]] MeasuredObservation measured_historical(const Message& message) {
    arm();
    Observation observation = historical_encode_message_0468(message);
    const State measurement = state;
    disarm();
    return {std::move(observation), measurement};
}

void canonical_case(
    Results& results,
    const Message& message,
    const std::size_t expected_bytes,
    const bool boundary,
    const bool huge) {
    const Message before = message;
    const Octets expected = text_octets(serialize(message));
    ++results.canonical_cases;
    results.boundary_cases += boundary ? 1U : 0U;
    results.huge_input_cases += huge ? 1U : 0U;
    results.huge_input_bytes += huge ? expected_bytes : 0U;
    check(
        results,
        expected.size() == expected_bytes,
        "independent_exact_payload_size");

    const MeasuredObservation current = measured_current(message);
    ++results.allocation_measurements;
    ++results.input_preservation_checks;
    check(results, same_message(message, before), "current_input_preserved");

    const MeasuredObservation historical = measured_historical(message);
    ++results.allocation_measurements;
    ++results.input_preservation_checks;
    check(results, same_message(message, before), "historical_input_preserved");
    ++results.historical_comparisons;
    check(
        results,
        same_observation(current.observation, historical.observation),
        "predecessor_semantic_equivalence");

    if (envelope(expected_bytes)) {
        ++results.accepted_cases;
        ++results.exact_payload_checks;
        check(
            results,
            current.observation.status == Status::accepted &&
                current.observation.classification == "ACCEPTED" &&
                current.observation.payload &&
                *current.observation.payload == expected,
            "accepted_exact_payload");
        ++results.accepted_allocation_checks;
        results.accepted_maximum_allocation = std::max(
            results.accepted_maximum_allocation,
            current.measurement.maximum);
        results.accepted_allocation_count = std::max(
            results.accepted_allocation_count,
            current.measurement.attempts);
        check(
            results,
            current.measurement.attempts == 1U &&
                current.measurement.maximum == expected_bytes &&
                current.measurement.total == expected_bytes,
            "accepted_single_exact_payload_allocation");
        const auto decoded = natrav_peer_decode_message(expected);
        ++results.roundtrip_checks;
        check(
            results,
            decoded.status == NATravPeerMessageDecodeStatus::accepted &&
                decoded.message.has_value() &&
                same_message(*decoded.message, message),
            "accepted_direct_roundtrip");
    } else {
        ++results.rejected_cases;
        ++results.bounded_rejection_checks;
        results.rejection_maximum_allocation = std::max(
            results.rejection_maximum_allocation,
            current.measurement.maximum);
        results.rejection_allocation_count = std::max(
            results.rejection_allocation_count,
            current.measurement.attempts);
        results.rejection_total_allocation = std::max(
            results.rejection_total_allocation,
            current.measurement.total);
        results.historical_rejection_maximum_allocation = std::max(
            results.historical_rejection_maximum_allocation,
            historical.measurement.maximum);
        results.historical_rejection_allocation_count = std::max(
            results.historical_rejection_allocation_count,
            historical.measurement.attempts);
        results.historical_rejection_total_allocation = std::max(
            results.historical_rejection_total_allocation,
            historical.measurement.total);
        check(
            results,
            current.observation.status == Status::payload_size_rejected &&
                !current.observation.payload &&
                current.measurement.attempts == 1U &&
                current.measurement.maximum == 22U &&
                current.measurement.total == 22U,
            "oversize_rejection_bounded_to_classification");
        check(
            results,
            historical.measurement.maximum > current.measurement.maximum &&
                historical.measurement.total > current.measurement.total,
            "historical_full_output_allocation_observed");
    }
}

void schema_priority_case(
    Results& results,
    const Message& message,
    const Status expected_status) {
    const Message before = message;
    const Observation current = natrav_peer_encode_message(message);
    const Observation historical = historical_encode_message_0468(message);
    ++results.schema_priority_cases;
    ++results.schema_priority_comparisons;
    ++results.input_preservation_checks;
    check(results, same_message(message, before), "schema_input_preserved");
    check(
        results,
        same_observation(current, historical),
        "schema_predecessor_priority_equivalence");
    check(
        results,
        current.status == expected_status && !current.payload,
        "schema_expected_priority");
}

void schema_priority(Results& results) {
    Message message = sized(4U, 131072U, "x");
    message.kind = NATravPeerHandshakeMessageKind::unknown;
    schema_priority_case(results, message, Status::message_kind_rejected);

    message = sized(0U, 131072U, "x");
    message.available_capabilities = {"PING"};
    schema_priority_case(results, message, Status::schema_rejected);

    message = sized(2U, 131072U, "x");
    message.required_capabilities = {"PING"};
    schema_priority_case(results, message, Status::schema_rejected);

    message = sized(4U, 131072U, "x");
    message.artifact = {std::string(64U, 'a'), "target", "version"};
    schema_priority_case(results, message, Status::schema_rejected);

    message = sized(4U, 131072U, "x");
    message.protocol.id = "WRONG";
    schema_priority_case(results, message, Status::protocol_mismatch);

    message = sized(4U, 131072U, "x");
    message.protocol.major = 2;
    schema_priority_case(results, message, Status::protocol_mismatch);

    message = sized(4U, 131072U, "x");
    message.protocol.minor = -1;
    schema_priority_case(results, message, Status::protocol_mismatch);

    message = sized(4U, 131072U, "x");
    message.request_id = "bad";
    schema_priority_case(results, message, Status::request_id_rejected);

    message = sized(0U, 131072U, "x");
    message.artifact.sha256 = "bad";
    schema_priority_case(results, message, Status::artifact_identity_rejected);

    message = sized(0U, 131072U, "x");
    message.artifact.target.clear();
    schema_priority_case(results, message, Status::artifact_identity_rejected);

    message = sized(0U, 131072U, "x");
    message.artifact.target = std::string(1U, static_cast<char>(0xFF));
    schema_priority_case(results, message, Status::artifact_identity_rejected);

    message = sized(0U, 131072U, "x");
    message.required_capabilities = {"PING", "PING"};
    schema_priority_case(
        results, message, Status::capability_declaration_rejected);

    message = sized(0U, 131072U, "x");
    message.required_capabilities = {"STATUS", "PING"};
    schema_priority_case(
        results, message, Status::capability_declaration_rejected);

    message = sized(0U, 131072U, "x");
    message.required_capabilities = {"bad"};
    schema_priority_case(
        results, message, Status::capability_declaration_rejected);

    message = sized(4U, 131072U, "x");
    message.error_code = "bad";
    schema_priority_case(results, message, Status::schema_rejected);

    message = base(4U);
    message.error_message.clear();
    schema_priority_case(results, message, Status::schema_rejected);

    message = base(4U);
    message.error_message = std::string(1U, static_cast<char>(0xFF));
    schema_priority_case(results, message, Status::schema_rejected);
}

[[nodiscard]] std::string capability_token_for(const std::size_t index) {
    char digits[7] = {};
    const auto conversion = std::to_chars(
        digits, digits + sizeof(digits), index);
    if (conversion.ec != std::errc{}) {
        throw std::runtime_error("capability index conversion");
    }
    std::string result = "C";
    result.append(6U - static_cast<std::size_t>(conversion.ptr - digits), '0');
    result.append(
        digits,
        static_cast<std::size_t>(conversion.ptr - digits));
    return result;
}

void capability_cases(Results& results) {
    for (const std::size_t count : {4000U, 8000U}) {
        Message message = base(count == 4000U ? 0U : 2U);
        std::vector<std::string>& capabilities =
            message.kind == NATravPeerHandshakeMessageKind::hello ?
                message.required_capabilities :
                message.available_capabilities;
        capabilities.clear();
        capabilities.reserve(count);
        for (std::size_t index = 0U; index < count; ++index) {
            capabilities.push_back(capability_token_for(index));
        }
        const std::size_t bytes = serialize(message).size();
        ++results.capability_cases;
        canonical_case(
            results,
            message,
            bytes,
            bytes >= 65535U && bytes <= 65537U,
            false);
    }
}

void fault_scenario(Results& results, const Message& message) {
    const Message before = message;
    arm();
    const Observation expected = natrav_peer_encode_message(message);
    const State baseline = state;
    disarm();
    ++results.fault_scenarios;
    ++results.input_preservation_checks;
    check(results, same_message(message, before), "fault_baseline_input_preserved");

    for (const bool persistent : {false, true}) {
        for (std::size_t point = 0U; point <= baseline.attempts; ++point) {
            std::optional<Observation> actual;
            bool caught = false;
            arm(point, persistent);
            try {
                actual.emplace(natrav_peer_encode_message(message));
            } catch (const InjectedBadAlloc& error) {
                caught = error.point == point;
            }
            const State measured = state;
            disarm();
            ++results.input_preservation_checks;
            check(results, same_message(message, before), "fault_input_preserved");
            if (point < baseline.attempts) {
                ++results.faults;
                results.original_exceptions += caught ? 1U : 0U;
                ++results.exception_attempt_checks;
                results.persistent_fault_checks += persistent ? 1U : 0U;
                check(
                    results,
                    caught && !actual && measured.attempts == point + 1U,
                    "original_exception_without_extra_allocation");
            } else {
                ++results.success_boundaries;
                check(
                    results,
                    !caught && actual && same_observation(*actual, expected) &&
                        measured.attempts == baseline.attempts,
                    "fault_success_boundary");
            }
            const Observation retry = natrav_peer_encode_message(message);
            ++results.retry_checks;
            check(
                results,
                same_observation(retry, expected),
                "stateless_retry_after_recovery");
        }
    }
}

int run() {
    static_assert(kNATravPeerMinimumPayloadBytes == 2U);
    static_assert(kNATravPeerMaximumPayloadBytes == 65536U);
    static_assert(static_cast<int>(Status::accepted) == 0);
    static_assert(static_cast<int>(Status::payload_size_rejected) == 7);

    Results results;
    const std::vector<std::string> units = {
        "x",
        "\"",
        "\\",
        "\n",
        std::string(1U, '\0'),
        std::string(1U, '\x1f'),
        "\xc2\xa2",
        "\xe2\x82\xac",
        "\xf0\x9f\x98\x80",
        "x\n\"\xe2\x82\xac",
    };
    const std::vector<std::size_t> sizes = {
        1024U,
        65532U,
        65533U,
        65534U,
        65535U,
        65536U,
        65537U,
        65538U,
        65539U,
        65540U,
        131072U,
    };

    for (unsigned int variant = 0U; variant < 5U; ++variant) {
        for (const std::string& unit : units) {
            for (const std::size_t bytes : sizes) {
                canonical_case(
                    results,
                    sized(variant, bytes, unit),
                    bytes,
                    bytes >= 65532U && bytes <= 65540U,
                    false);
            }
        }
    }

    // Large controls demonstrate that rejection storage is independent of the
    // caller-owned field size, including escaping expansion.
    for (const auto& fixture : std::vector<std::pair<std::size_t, std::string>>{
             {1048576U, "x"},
             {1048576U, "\n"},
             {4194304U, "x"},
             {4194304U, std::string(1U, '\0')},
         }) {
        canonical_case(
            results,
            sized(4U, fixture.first, fixture.second),
            fixture.first,
            false,
            true);
    }

    // Integer text width participates in exact size accounting.
    for (const std::int64_t minor : {
             std::int64_t{0},
             std::int64_t{9},
             std::int64_t{10},
             std::numeric_limits<std::int64_t>::max(),
         }) {
        Message message = base(4U);
        message.protocol.minor = minor;
        canonical_case(
            results,
            message,
            serialize(message).size(),
            false,
            false);
    }

    schema_priority(results);
    capability_cases(results);

    fault_scenario(results, sized(4U, 1024U, "x"));
    fault_scenario(results, sized(0U, 65536U, "\n"));
    fault_scenario(results, sized(4U, 65537U, "x"));
    fault_scenario(results, sized(4U, 4194304U, "\n"));
    Message invalid = sized(4U, 131072U, "x");
    invalid.error_code = "bad";
    fault_scenario(results, invalid);

    check(
        results,
        results.rejected_cases != 0U && results.accepted_cases != 0U &&
            results.huge_input_cases == 4U &&
            results.rejection_maximum_allocation == 22U &&
            results.rejection_allocation_count == 1U &&
            results.rejection_total_allocation == 22U &&
            results.historical_rejection_maximum_allocation >
                kNATravPeerMaximumPayloadBytes &&
            results.historical_rejection_total_allocation >
                results.historical_rejection_maximum_allocation &&
            results.accepted_maximum_allocation ==
                kNATravPeerMaximumPayloadBytes &&
            results.accepted_allocation_count == 1U &&
            results.original_exceptions == results.faults,
        "coverage_and_bounds");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(canonical_cases);
    PRINT_RESULT(boundary_cases);
    PRINT_RESULT(historical_comparisons);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejected_cases);
    PRINT_RESULT(exact_payload_checks);
    PRINT_RESULT(roundtrip_checks);
    PRINT_RESULT(schema_priority_cases);
    PRINT_RESULT(schema_priority_comparisons);
    PRINT_RESULT(capability_cases);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(allocation_measurements);
    PRINT_RESULT(bounded_rejection_checks);
    PRINT_RESULT(rejection_maximum_allocation);
    PRINT_RESULT(rejection_allocation_count);
    PRINT_RESULT(rejection_total_allocation);
    PRINT_RESULT(historical_rejection_maximum_allocation);
    PRINT_RESULT(historical_rejection_allocation_count);
    PRINT_RESULT(historical_rejection_total_allocation);
    PRINT_RESULT(accepted_allocation_checks);
    PRINT_RESULT(accepted_maximum_allocation);
    PRINT_RESULT(accepted_allocation_count);
    PRINT_RESULT(huge_input_cases);
    PRINT_RESULT(huge_input_bytes);
    PRINT_RESULT(fault_scenarios);
    PRINT_RESULT(faults);
    PRINT_RESULT(original_exceptions);
    PRINT_RESULT(exception_attempt_checks);
    PRINT_RESULT(success_boundaries);
    PRINT_RESULT(persistent_fault_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT

    return results.failures == 0U ? 0 : 1;
}

}  // namespace natrav_encoder_bound_test

int main() {
    try {
        return natrav_encoder_bound_test::run();
    } catch (const std::exception& error) {
        natrav_encoder_allocation_test::disarm();
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_ENCODER_BOUND_TEST

// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_DECODER_COMPLEXITY_TEST
#include <cstdio>
#include <cstdlib>
#include <new>
#include <stdexcept>

namespace natrav_decoder_complexity_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t value) noexcept : point(value) {}
    const char* what() const noexcept override {
        return "NATRAV_DECODER_COMPLEXITY_TEST_BAD_ALLOC";
    }
    std::size_t point;
};

struct State final {
    bool armed{false};
    bool persistent{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    std::size_t attempts{0U};
    std::size_t maximum{0U};
    std::size_t total{0U};
};

thread_local State state;

void arm(
    const std::size_t point = std::numeric_limits<std::size_t>::max(),
    const bool persistent = false) noexcept {
    state = State{
        .armed = true,
        .persistent = persistent,
        .point = point,
        .attempts = 0U,
        .maximum = 0U,
        .total = 0U,
    };
}

void disarm() noexcept { state.armed = false; }

void allocation(const std::size_t size) {
    if (!state.armed) {
        return;
    }
    const std::size_t point = state.attempts++;
    state.maximum = std::max(state.maximum, size);
    state.total += size;
    if (point == state.point || (state.persistent && point > state.point)) {
        throw InjectedBadAlloc(point);
    }
}

void* allocate(const std::size_t size) {
    allocation(size);
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned(const std::size_t size, const std::align_val_t alignment) {
    allocation(size);
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

[[gnu::noinline]] void release(void* const pointer) noexcept {
    std::free(pointer);
}
}  // namespace natrav_decoder_complexity_allocation_test

void* operator new(const std::size_t size) {
    return natrav_decoder_complexity_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_decoder_complexity_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_decoder_complexity_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_decoder_complexity_allocation_test::release(pointer);
}
void operator delete(void* const pointer, std::size_t) noexcept {
    natrav_decoder_complexity_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, std::size_t) noexcept {
    natrav_decoder_complexity_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_decoder_complexity_allocation_test::aligned(size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_decoder_complexity_allocation_test::aligned(size, alignment);
}
void operator delete(void* const pointer, std::align_val_t) noexcept {
    natrav_decoder_complexity_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, std::align_val_t) noexcept {
    natrav_decoder_complexity_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    std::size_t,
    std::align_val_t) noexcept {
    natrav_decoder_complexity_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    std::size_t,
    std::align_val_t) noexcept {
    natrav_decoder_complexity_allocation_test::release(pointer);
}

namespace datacube {
// Exact revision-0469 decoder body under a renamed test symbol. The parser and
// schema helpers are shared; the new complexity probe/preflight is not called.
NATravPeerMessageDecodeObservation historical_decode_message_0469(
    const OctetView payload) {
    if (payload.size() < kNATravPeerMinimumPayloadBytes ||
        payload.size() > kNATravPeerMaximumPayloadBytes) {
        return observation(NATravPeerMessageDecodeStatus::payload_size_rejected);
    }
    const std::string text(
        reinterpret_cast<const char*>(payload.data()), payload.size());
    JsonValue parsed;
    try {
        parsed = JsonParser(text).parse();
    } catch (const Failure&) {
        return observation(NATravPeerMessageDecodeStatus::malformed_json);
    }
    if (parsed.kind != JsonValue::Kind::object) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }
    std::string canonical;
    append_canonical_json(parsed, canonical);
    if (canonical != text) {
        return observation(NATravPeerMessageDecodeStatus::noncanonical_json);
    }

    const JsonValue* const kind = member(parsed, "kind");
    if (kind == nullptr || kind->kind != JsonValue::Kind::string ||
        (kind->string_value != "HELLO" &&
         kind->string_value != "HELLO_ACK" &&
         kind->string_value != "ERROR")) {
        return observation(NATravPeerMessageDecodeStatus::message_kind_rejected);
    }

    bool shape_exact = false;
    if (kind->string_value == "HELLO") {
        shape_exact = object_keys_exact(
            &parsed,
            {"artifact", "kind", "protocol", "request_id",
             "required_capabilities"});
    } else if (kind->string_value == "HELLO_ACK") {
        shape_exact = object_keys_exact(
            &parsed,
            {"artifact", "available_capabilities", "kind", "protocol",
             "request_id"});
    } else {
        shape_exact = object_keys_exact(
            &parsed, {"code", "kind", "message", "protocol", "request_id"});
    }
    if (!shape_exact) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }
    if (!protocol_object_exact(member(parsed, "protocol"))) {
        return observation(NATravPeerMessageDecodeStatus::protocol_mismatch);
    }
    if (!lower_hex_sha256(member(parsed, "request_id"))) {
        return observation(NATravPeerMessageDecodeStatus::request_id_rejected);
    }

    NATravPeerHandshakeMessage message;
    message.protocol = protocol_value(parsed);
    message.request_id = member(parsed, "request_id")->string_value;
    if (kind->string_value == "HELLO" || kind->string_value == "HELLO_ACK") {
        if (!artifact_object_exact(member(parsed, "artifact"))) {
            return observation(
                NATravPeerMessageDecodeStatus::artifact_identity_rejected);
        }
        const std::string_view capability_member =
            kind->string_value == "HELLO" ?
                "required_capabilities" : "available_capabilities";
        if (!capability_array_exact(member(parsed, capability_member))) {
            return observation(
                NATravPeerMessageDecodeStatus::capability_declaration_rejected);
        }
        message.artifact = artifact_value(parsed);
        if (kind->string_value == "HELLO") {
            message.kind = NATravPeerHandshakeMessageKind::hello;
            message.required_capabilities =
                capability_values(parsed, capability_member);
        } else {
            message.kind = NATravPeerHandshakeMessageKind::hello_ack;
            message.available_capabilities =
                capability_values(parsed, capability_member);
        }
    } else {
        const JsonValue* const code = member(parsed, "code");
        const JsonValue* const error_message = member(parsed, "message");
        if (!nonempty_string(code) || !capability_token(code->string_value) ||
            !nonempty_string(error_message)) {
            return observation(NATravPeerMessageDecodeStatus::schema_rejected);
        }
        message.kind = NATravPeerHandshakeMessageKind::error;
        message.error_code = code->string_value;
        message.error_message = error_message->string_value;
    }

    return NATravPeerMessageDecodeObservation{
        .status = NATravPeerMessageDecodeStatus::accepted,
        .classification = "ACCEPTED",
        .message = std::move(message),
    };
}
}  // namespace datacube

namespace natrav_decoder_complexity_test {
using datacube::NATravPeerArtifactIdentity;
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerProtocolVersion;
using datacube::Octets;
using natrav_decoder_complexity_allocation_test::InjectedBadAlloc;
using natrav_decoder_complexity_allocation_test::State;
using natrav_decoder_complexity_allocation_test::arm;
using natrav_decoder_complexity_allocation_test::disarm;
using natrav_decoder_complexity_allocation_test::state;

struct Results final {
    std::size_t ordinary_comparisons{0U};
    std::size_t depth_boundary_checks{0U};
    std::size_t construction_boundary_checks{0U};
    std::size_t priority_cases{0U};
    std::size_t extreme_depth_cases{0U};
    std::size_t extreme_depth_bytes{0U};
    std::size_t valid_capability_count{0U};
    std::size_t valid_payload_bytes{0U};
    std::size_t allocation_measurements{0U};
    std::size_t corrected_wide_maximum_allocation{0U};
    std::size_t corrected_wide_allocation_count{0U};
    std::size_t corrected_wide_total_allocation{0U};
    std::size_t historical_wide_maximum_allocation{0U};
    std::size_t historical_wide_allocation_count{0U};
    std::size_t historical_wide_total_allocation{0U};
    std::size_t extreme_depth_maximum_allocation{0U};
    std::size_t extreme_depth_allocation_count{0U};
    std::size_t extreme_depth_total_allocation{0U};
    std::size_t fault_scenarios{0U};
    std::size_t faults{0U};
    std::size_t original_exceptions{0U};
    std::size_t exception_attempt_checks{0U};
    std::size_t success_boundaries{0U};
    std::size_t persistent_fault_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t failures{0U};
};

void check(Results& results, const bool condition, const char* const label) {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] Octets octets(const std::string_view text) {
    return Octets(text.begin(), text.end());
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    return left.status == right.status &&
        left.classification == right.classification &&
        left.message.has_value() == right.message.has_value() &&
        (!left.message || same_message(*left.message, *right.message));
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = 0,
    };
    message.request_id = std::string(64U, 'a');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = NATravPeerArtifactIdentity{
            .sha256 = std::string(64U, 'b'),
            .target = "linux-x86_64",
            .version = "0470",
        };
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            message.required_capabilities = {"PING", "STATUS"};
        } else {
            message.available_capabilities = {"PING", "STATUS"};
        }
    } else {
        message.error_code = "PEER_ERROR";
        message.error_message = "fixture";
    }
    return message;
}

[[nodiscard]] std::string nested_object(
    const std::size_t array_depth,
    const bool whitespace,
    const bool complete) {
    std::string result = "{\"a\":";
    if (whitespace) {
        result.push_back(' ');
    }
    result.append(array_depth, '[');
    result.push_back('0');
    result.append(array_depth - (complete ? 0U : 1U), ']');
    result.push_back('}');
    return result;
}

[[nodiscard]] std::string wide_object(
    const std::size_t values,
    const bool whitespace = false,
    const bool trailing_comma = false) {
    std::string result = "{\"a\":";
    if (whitespace) {
        result.push_back(' ');
    }
    result.push_back('[');
    for (std::size_t index = 0U; index < values; ++index) {
        if (index != 0U) {
            result.push_back(',');
        }
        result.push_back('0');
    }
    if (trailing_comma) {
        result.push_back(',');
    }
    result.append("]}");
    return result;
}

[[nodiscard]] std::string capability_token(const std::size_t index) {
    static constexpr std::string_view alphabet =
        "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    std::size_t value = index;
    std::string token = "A000";
    for (std::size_t position = 3U; position > 0U; --position) {
        token[position] = alphabet[value % alphabet.size()];
        value /= alphabet.size();
    }
    return token;
}

void ordinary_compatibility(Results& results) {
    std::vector<Octets> fixtures = {
        octets("{}"),
        octets("[]"),
        octets("{\"kind\":\"NOPE\"}"),
        octets("{\"a\":-0}"),
        octets("{\"b\":0,\"a\":0}"),
        octets("{\"a\":0,\"a\":1}"),
        octets("{\"a\":}"),
    };
    for (const NATravPeerHandshakeMessageKind kind : {
             NATravPeerHandshakeMessageKind::hello,
             NATravPeerHandshakeMessageKind::hello_ack,
             NATravPeerHandshakeMessageKind::error,
         }) {
        const auto encoded = datacube::natrav_peer_encode_message(
            base_message(kind));
        if (encoded.payload) {
            fixtures.push_back(*encoded.payload);
        }
    }
    for (const Octets& fixture : fixtures) {
        const auto current = datacube::natrav_peer_decode_message(fixture);
        const auto historical = datacube::historical_decode_message_0469(
            fixture);
        ++results.ordinary_comparisons;
        check(
            results,
            same_observation(current, historical),
            "ordinary_predecessor_compatibility");
    }
}

void boundary_and_priority(Results& results) {
    const Octets depth_at_limit = octets(nested_object(63U, false, true));
    const Octets depth_over_limit = octets(nested_object(64U, false, true));
    const auto at_limit = datacube::natrav_peer_decode_message(depth_at_limit);
    const auto at_limit_historical =
        datacube::historical_decode_message_0469(depth_at_limit);
    const auto over_limit =
        datacube::natrav_peer_decode_message(depth_over_limit);
    const auto over_limit_historical =
        datacube::historical_decode_message_0469(depth_over_limit);
    results.depth_boundary_checks += 4U;
    check(
        results,
        same_observation(at_limit, at_limit_historical) &&
            at_limit.status ==
                NATravPeerMessageDecodeStatus::message_kind_rejected,
        "depth_limit_inclusive");
    check(
        results,
        over_limit.status == NATravPeerMessageDecodeStatus::schema_rejected &&
            over_limit_historical.status ==
                NATravPeerMessageDecodeStatus::message_kind_rejected,
        "depth_limit_rejects_before_tree");

    const Octets units_at_limit = octets(wide_object(16381U));
    const Octets units_over_limit = octets(wide_object(16382U));
    const auto units_at = datacube::natrav_peer_decode_message(units_at_limit);
    const auto units_at_historical =
        datacube::historical_decode_message_0469(units_at_limit);
    const auto units_over =
        datacube::natrav_peer_decode_message(units_over_limit);
    const auto units_over_historical =
        datacube::historical_decode_message_0469(units_over_limit);
    results.construction_boundary_checks += 4U;
    check(
        results,
        same_observation(units_at, units_at_historical) &&
            units_at.status ==
                NATravPeerMessageDecodeStatus::message_kind_rejected,
        "construction_unit_limit_inclusive");
    check(
        results,
        units_over.status == NATravPeerMessageDecodeStatus::schema_rejected &&
            units_over_historical.status ==
                NATravPeerMessageDecodeStatus::message_kind_rejected,
        "construction_unit_limit_rejects_before_tree");

    const std::vector<std::pair<Octets, NATravPeerMessageDecodeStatus>>
        priority_fixtures = {
            {octets(wide_object(16382U, true, false)),
             NATravPeerMessageDecodeStatus::noncanonical_json},
            {octets(wide_object(16382U, false, true)),
             NATravPeerMessageDecodeStatus::malformed_json},
            {octets("{\"a\":[" + std::string(32760U, '0') + "]}"),
             NATravPeerMessageDecodeStatus::malformed_json},
        };
    for (const auto& fixture : priority_fixtures) {
        const auto current = datacube::natrav_peer_decode_message(fixture.first);
        const auto historical = datacube::historical_decode_message_0469(
            fixture.first);
        ++results.priority_cases;
        check(
            results,
            current.status == fixture.second &&
                current.status == historical.status,
            "malformed_noncanonical_priority");
    }

    std::string duplicate = wide_object(16382U);
    duplicate.pop_back();
    duplicate.append(",\"a\":0}");
    const auto duplicate_result =
        datacube::natrav_peer_decode_message(octets(duplicate));
    ++results.priority_cases;
    check(
        results,
        duplicate_result.status ==
            NATravPeerMessageDecodeStatus::malformed_json,
        "duplicate_key_remains_malformed");
}

void extreme_depth(Results& results) {
    constexpr std::size_t depth = 32760U;
    const Octets canonical = octets(nested_object(depth, false, true));
    const Octets noncanonical = octets(nested_object(depth, true, true));
    const Octets malformed = octets(nested_object(depth, false, false));
    results.extreme_depth_bytes = canonical.size();

    arm();
    const auto canonical_result =
        datacube::natrav_peer_decode_message(canonical);
    const State measured = state;
    disarm();
    ++results.allocation_measurements;
    results.extreme_depth_maximum_allocation = measured.maximum;
    results.extreme_depth_allocation_count = measured.attempts;
    results.extreme_depth_total_allocation = measured.total;

    const auto noncanonical_result =
        datacube::natrav_peer_decode_message(noncanonical);
    const auto malformed_result =
        datacube::natrav_peer_decode_message(malformed);
    results.extreme_depth_cases += 3U;
    check(
        results,
        canonical_result.status ==
            NATravPeerMessageDecodeStatus::schema_rejected,
        "maximum_envelope_depth_is_iterative");
    check(
        results,
        noncanonical_result.status ==
            NATravPeerMessageDecodeStatus::noncanonical_json,
        "maximum_envelope_depth_noncanonical_priority");
    check(
        results,
        malformed_result.status ==
            NATravPeerMessageDecodeStatus::malformed_json,
        "maximum_envelope_depth_malformed_priority");
    check(
        results,
        canonical.size() <= datacube::kNATravPeerMaximumPayloadBytes &&
            measured.maximum <= 4194304U && measured.total <= 8388608U,
        "explicit_stack_allocation_bound");
}

void valid_capability_envelope(Results& results) {
    NATravPeerHandshakeMessage message =
        base_message(NATravPeerHandshakeMessageKind::hello);
    message.required_capabilities.clear();
    constexpr std::size_t count = 8500U;
    message.required_capabilities.reserve(count);
    for (std::size_t index = 0U; index < count; ++index) {
        message.required_capabilities.push_back(capability_token(index));
    }
    const auto encoded = datacube::natrav_peer_encode_message(message);
    results.valid_capability_count = count;
    results.valid_payload_bytes = encoded.payload ? encoded.payload->size() : 0U;
    check(
        results,
        encoded.status == datacube::NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "large_valid_capability_fixture_encoded");
    if (encoded.payload) {
        const auto decoded =
            datacube::natrav_peer_decode_message(*encoded.payload);
        check(
            results,
            decoded.status == NATravPeerMessageDecodeStatus::accepted &&
                decoded.message &&
                decoded.message->required_capabilities.size() == count,
            "all_schema_valid_capabilities_remain_admitted");
    }
}

void allocation_comparison(Results& results, const Octets& payload) {
    arm();
    const auto corrected = datacube::natrav_peer_decode_message(payload);
    const State corrected_state = state;
    disarm();
    arm();
    const auto historical = datacube::historical_decode_message_0469(payload);
    const State historical_state = state;
    disarm();
    results.allocation_measurements += 2U;
    results.corrected_wide_maximum_allocation = corrected_state.maximum;
    results.corrected_wide_allocation_count = corrected_state.attempts;
    results.corrected_wide_total_allocation = corrected_state.total;
    results.historical_wide_maximum_allocation = historical_state.maximum;
    results.historical_wide_allocation_count = historical_state.attempts;
    results.historical_wide_total_allocation = historical_state.total;
    check(
        results,
        corrected.status == NATravPeerMessageDecodeStatus::schema_rejected &&
            historical.status ==
                NATravPeerMessageDecodeStatus::message_kind_rejected,
        "wide_fixture_exposes_predecessor_tree_construction");
    check(
        results,
        corrected_state.maximum <= payload.size() + 1U &&
            historical_state.maximum > payload.size() * 8U &&
            historical_state.total > corrected_state.total * 8U,
        "wide_tree_allocation_is_bounded_before_construction");
}

void fault_scenario(Results& results, const Octets& payload) {
    const Octets before = payload;
    arm();
    const auto expected = datacube::natrav_peer_decode_message(payload);
    const std::size_t attempts = state.attempts;
    disarm();
    ++results.fault_scenarios;
    for (const bool persistent : {false, true}) {
        for (std::size_t point = 0U; point <= attempts; ++point) {
            std::optional<NATravPeerMessageDecodeObservation> actual;
            bool caught = false;
            arm(point, persistent);
            try {
                actual.emplace(datacube::natrav_peer_decode_message(payload));
            } catch (const InjectedBadAlloc& error) {
                caught = error.point == point;
            }
            const State measured = state;
            disarm();
            ++results.input_preservation_checks;
            check(
                results,
                payload == before,
                "fault_input_preserved");
            if (point < attempts) {
                ++results.faults;
                results.original_exceptions += caught ? 1U : 0U;
                ++results.exception_attempt_checks;
                results.persistent_fault_checks += persistent ? 1U : 0U;
                check(
                    results,
                    caught && !actual && measured.attempts == point + 1U,
                    "original_exception_without_followup_allocation");
            } else {
                ++results.success_boundaries;
                check(
                    results,
                    !caught && actual && same_observation(*actual, expected) &&
                        measured.attempts == attempts,
                    "fault_success_boundary");
            }
            ++results.retry_checks;
            check(
                results,
                same_observation(
                    datacube::natrav_peer_decode_message(payload),
                    expected),
                "stateless_retry_after_recovery");
        }
    }
}

int run() {
    static_assert(datacube::kNATravPeerMinimumPayloadBytes == 2U);
    static_assert(datacube::kNATravPeerMaximumPayloadBytes == 65536U);
    static_assert(datacube::kNATravPeerMaximumJsonTreeDepth == 64U);
    static_assert(
        datacube::kNATravPeerMaximumJsonConstructionUnits == 16384U);

    Results results;
    ordinary_compatibility(results);
    boundary_and_priority(results);
    extreme_depth(results);
    valid_capability_envelope(results);

    const Octets wide = octets(wide_object(16382U));
    allocation_comparison(results, wide);
    fault_scenario(results, wide);
    fault_scenario(results, octets(nested_object(64U, false, true)));

    check(
        results,
        results.ordinary_comparisons == 10U &&
            results.depth_boundary_checks == 4U &&
            results.construction_boundary_checks == 4U &&
            results.priority_cases == 4U &&
            results.extreme_depth_cases == 3U &&
            results.extreme_depth_bytes >= 65520U &&
            results.valid_capability_count == 8500U &&
            results.valid_payload_bytes <=
                datacube::kNATravPeerMaximumPayloadBytes &&
            results.historical_wide_maximum_allocation >
                results.corrected_wide_maximum_allocation &&
            results.original_exceptions == results.faults,
        "coverage_and_bounds");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(ordinary_comparisons);
    PRINT_RESULT(depth_boundary_checks);
    PRINT_RESULT(construction_boundary_checks);
    PRINT_RESULT(priority_cases);
    PRINT_RESULT(extreme_depth_cases);
    PRINT_RESULT(extreme_depth_bytes);
    PRINT_RESULT(valid_capability_count);
    PRINT_RESULT(valid_payload_bytes);
    PRINT_RESULT(allocation_measurements);
    PRINT_RESULT(corrected_wide_maximum_allocation);
    PRINT_RESULT(corrected_wide_allocation_count);
    PRINT_RESULT(corrected_wide_total_allocation);
    PRINT_RESULT(historical_wide_maximum_allocation);
    PRINT_RESULT(historical_wide_allocation_count);
    PRINT_RESULT(historical_wide_total_allocation);
    PRINT_RESULT(extreme_depth_maximum_allocation);
    PRINT_RESULT(extreme_depth_allocation_count);
    PRINT_RESULT(extreme_depth_total_allocation);
    PRINT_RESULT(fault_scenarios);
    PRINT_RESULT(faults);
    PRINT_RESULT(original_exceptions);
    PRINT_RESULT(exception_attempt_checks);
    PRINT_RESULT(success_boundaries);
    PRINT_RESULT(persistent_fault_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT

    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_decoder_complexity_test

int main() {
    try {
        return natrav_decoder_complexity_test::run();
    } catch (const std::exception& error) {
        natrav_decoder_complexity_allocation_test::disarm();
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_DECODER_COMPLEXITY_TEST


// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_SCHEMA_DIRECTED_DECODER_TEST
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_schema_decoder_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t value) noexcept : point(value) {}
    const char* what() const noexcept override {
        return "NATRAV_SCHEMA_DECODER_TEST_BAD_ALLOC";
    }
    std::size_t point;
};

struct State final {
    bool armed{false};
    bool persistent{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    std::size_t attempts{0U};
    std::size_t maximum{0U};
    std::size_t total{0U};
};

thread_local State state;

void arm(
    const std::size_t point = std::numeric_limits<std::size_t>::max(),
    const bool persistent = false) noexcept {
    state = {true, persistent, point, 0U, 0U, 0U};
}

void disarm() noexcept { state.armed = false; }

void allocation(const std::size_t size) {
    if (!state.armed) {
        return;
    }
    const std::size_t point = state.attempts++;
    state.maximum = std::max(state.maximum, size);
    state.total += size;
    if (point == state.point || (state.persistent && point > state.point)) {
        throw InjectedBadAlloc(point);
    }
}

void* allocate(const std::size_t size) {
    allocation(size);
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned(const std::size_t size, const std::align_val_t alignment) {
    allocation(size);
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

[[gnu::noinline]] void release(void* const pointer) noexcept {
    std::free(pointer);
}
}  // namespace natrav_schema_decoder_allocation_test

void* operator new(const std::size_t size) {
    return natrav_schema_decoder_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_schema_decoder_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_schema_decoder_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_schema_decoder_allocation_test::release(pointer);
}
void operator delete(void* const pointer, std::size_t) noexcept {
    natrav_schema_decoder_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, std::size_t) noexcept {
    natrav_schema_decoder_allocation_test::release(pointer);
}
void* operator new(const std::size_t size, const std::align_val_t alignment) {
    return natrav_schema_decoder_allocation_test::aligned(size, alignment);
}
void* operator new[](const std::size_t size, const std::align_val_t alignment) {
    return natrav_schema_decoder_allocation_test::aligned(size, alignment);
}
void operator delete(void* const pointer, std::align_val_t) noexcept {
    natrav_schema_decoder_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, std::align_val_t) noexcept {
    natrav_schema_decoder_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    std::size_t,
    std::align_val_t) noexcept {
    natrav_schema_decoder_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    std::size_t,
    std::align_val_t) noexcept {
    natrav_schema_decoder_allocation_test::release(pointer);
}

namespace datacube {
// Exact revision-0470 decoder body below; only the function name is changed.
// It shares the retained parser/schema helpers and is test-only.
NATravPeerMessageDecodeObservation historical_decode_message_0470(
    const OctetView payload) {
    // The direct codec has the same byte envelope as its encoder and frame
    // layer. Reject before constructing input-sized storage or inspecting JSON.
    if (payload.size() < kNATravPeerMinimumPayloadBytes ||
        payload.size() > kNATravPeerMaximumPayloadBytes) {
        return observation(NATravPeerMessageDecodeStatus::payload_size_rejected);
    }
    const std::string text(
        reinterpret_cast<const char*>(payload.data()), payload.size());
    const JsonComplexityProbe complexity = probe_json_complexity(text);
    if (complexity.requires_bounded_preflight()) {
        JsonPreflightObservation preflight;
        try {
            preflight = JsonPreflight(text).inspect();
        } catch (const Failure&) {
            return observation(NATravPeerMessageDecodeStatus::malformed_json);
        }
        // Preserve the historical root-shape priority: a syntactically valid
        // non-object is schema-rejected before canonical spelling is considered.
        if (preflight.root_kind != JsonValue::Kind::object) {
            return observation(NATravPeerMessageDecodeStatus::schema_rejected);
        }
        if (!preflight.canonical) {
            return observation(NATravPeerMessageDecodeStatus::noncanonical_json);
        }
        // Canonical but structurally excessive JSON is outside the typed
        // message schema. The iterative preflight establishes malformed and
        // noncanonical priority before this allocation-bounded rejection.
        if (!preflight.tree_admissible()) {
            return observation(NATravPeerMessageDecodeStatus::schema_rejected);
        }
    }
    JsonValue parsed;
    try {
        parsed = JsonParser(
            text,
            kNATravPeerMaximumJsonTreeDepth,
            kNATravPeerMaximumJsonTreeValues).parse();
    } catch (const Failure&) {
        return observation(NATravPeerMessageDecodeStatus::malformed_json);
    }
    if (parsed.kind != JsonValue::Kind::object) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }
    std::string canonical;
    append_canonical_json(parsed, canonical);
    if (canonical != text) {
        return observation(NATravPeerMessageDecodeStatus::noncanonical_json);
    }

    const JsonValue* const kind = member(parsed, "kind");
    if (kind == nullptr || kind->kind != JsonValue::Kind::string ||
        (kind->string_value != "HELLO" &&
         kind->string_value != "HELLO_ACK" &&
         kind->string_value != "ERROR")) {
        return observation(NATravPeerMessageDecodeStatus::message_kind_rejected);
    }

    bool shape_exact = false;
    if (kind->string_value == "HELLO") {
        shape_exact = object_keys_exact(
            &parsed,
            {"artifact", "kind", "protocol", "request_id",
             "required_capabilities"});
    } else if (kind->string_value == "HELLO_ACK") {
        shape_exact = object_keys_exact(
            &parsed,
            {"artifact", "available_capabilities", "kind", "protocol",
             "request_id"});
    } else {
        shape_exact = object_keys_exact(
            &parsed, {"code", "kind", "message", "protocol", "request_id"});
    }
    if (!shape_exact) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }
    if (!protocol_object_exact(member(parsed, "protocol"))) {
        return observation(NATravPeerMessageDecodeStatus::protocol_mismatch);
    }
    if (!lower_hex_sha256(member(parsed, "request_id"))) {
        return observation(NATravPeerMessageDecodeStatus::request_id_rejected);
    }

    NATravPeerHandshakeMessage message;
    message.protocol = protocol_value(parsed);
    message.request_id = member(parsed, "request_id")->string_value;
    if (kind->string_value == "HELLO" || kind->string_value == "HELLO_ACK") {
        if (!artifact_object_exact(member(parsed, "artifact"))) {
            return observation(
                NATravPeerMessageDecodeStatus::artifact_identity_rejected);
        }
        const std::string_view capability_member =
            kind->string_value == "HELLO" ?
                "required_capabilities" : "available_capabilities";
        if (!capability_array_exact(member(parsed, capability_member))) {
            return observation(
                NATravPeerMessageDecodeStatus::capability_declaration_rejected);
        }
        message.artifact = artifact_value(parsed);
        if (kind->string_value == "HELLO") {
            message.kind = NATravPeerHandshakeMessageKind::hello;
            message.required_capabilities =
                capability_values(parsed, capability_member);
        } else {
            message.kind = NATravPeerHandshakeMessageKind::hello_ack;
            message.available_capabilities =
                capability_values(parsed, capability_member);
        }
    } else {
        const JsonValue* const code = member(parsed, "code");
        const JsonValue* const error_message = member(parsed, "message");
        if (!nonempty_string(code) || !capability_token(code->string_value) ||
            !nonempty_string(error_message)) {
            return observation(NATravPeerMessageDecodeStatus::schema_rejected);
        }
        message.kind = NATravPeerHandshakeMessageKind::error;
        message.error_code = code->string_value;
        message.error_message = error_message->string_value;
    }

    return NATravPeerMessageDecodeObservation{
        .status = NATravPeerMessageDecodeStatus::accepted,
        .classification = "ACCEPTED",
        .message = std::move(message),
    };
}

}  // namespace datacube

namespace natrav_schema_directed_decoder_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_schema_decoder_allocation_test::InjectedBadAlloc;
using natrav_schema_decoder_allocation_test::State;
using natrav_schema_decoder_allocation_test::arm;
using natrav_schema_decoder_allocation_test::disarm;
using natrav_schema_decoder_allocation_test::state;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t allocation_measurements{0U};
    std::size_t large_capability_count{0U};
    std::size_t large_capability_payload_bytes{0U};
    std::size_t current_capability_maximum_allocation{0U};
    std::size_t current_capability_allocation_count{0U};
    std::size_t current_capability_total_allocation{0U};
    std::size_t historical_capability_maximum_allocation{0U};
    std::size_t historical_capability_allocation_count{0U};
    std::size_t historical_capability_total_allocation{0U};
    std::size_t large_error_payload_bytes{0U};
    std::size_t current_error_maximum_allocation{0U};
    std::size_t current_error_allocation_count{0U};
    std::size_t current_error_total_allocation{0U};
    std::size_t historical_error_maximum_allocation{0U};
    std::size_t historical_error_allocation_count{0U};
    std::size_t historical_error_total_allocation{0U};
    std::size_t fault_scenarios{0U};
    std::size_t faults{0U};
    std::size_t original_exceptions{0U};
    std::size_t exception_attempt_checks{0U};
    std::size_t success_boundaries{0U};
    std::size_t persistent_fault_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(Results& results, const bool okay, const char* const label) {
    if (!okay) {
        ++results.failures;
        if (results.failures <= 32U) {
            std::fprintf(stderr, "FAIL %s\n", label);
        }
    }
}

[[nodiscard]] Octets octets(const std::string_view text) {
    return Octets(text.begin(), text.end());
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    return left.status == right.status &&
        left.classification == right.classification &&
        left.message.has_value() == right.message.has_value() &&
        (!left.message || same_message(*left.message, *right.message));
}

[[nodiscard]] std::string quote(const std::string_view input) {
    static constexpr std::string_view hex = "0123456789abcdef";
    std::string result;
    result.push_back('"');
    for (const char raw : input) {
        const auto value = static_cast<unsigned char>(raw);
        switch (value) {
            case '"': result.append("\\\""); break;
            case '\\': result.append("\\\\"); break;
            case '\b': result.append("\\b"); break;
            case '\f': result.append("\\f"); break;
            case '\n': result.append("\\n"); break;
            case '\r': result.append("\\r"); break;
            case '\t': result.append("\\t"); break;
            default:
                if (value < 0x20U) {
                    result.append("\\u00");
                    result.push_back(hex[value >> 4U]);
                    result.push_back(hex[value & 0x0FU]);
                } else {
                    result.push_back(raw);
                }
        }
    }
    result.push_back('"');
    return result;
}

[[nodiscard]] std::string capability_array(
    const std::vector<std::string>& values) {
    std::string result{"["};
    for (std::size_t index = 0U; index < values.size(); ++index) {
        if (index != 0U) {
            result.push_back(',');
        }
        result.append(quote(values[index]));
    }
    result.push_back(']');
    return result;
}

[[nodiscard]] std::string serialize(
    const NATravPeerHandshakeMessage& message) {
    const std::string protocol =
        "{\"id\":" + quote(message.protocol.id) +
        ",\"major\":" + std::to_string(message.protocol.major) +
        ",\"minor\":" + std::to_string(message.protocol.minor) + "}";
    if (message.kind == NATravPeerHandshakeMessageKind::hello) {
        const std::string artifact =
            "{\"sha256\":" + quote(message.artifact.sha256) +
            ",\"target\":" + quote(message.artifact.target) +
            ",\"version\":" + quote(message.artifact.version) + "}";
        return "{\"artifact\":" + artifact +
            ",\"kind\":\"HELLO\",\"protocol\":" + protocol +
            ",\"request_id\":" + quote(message.request_id) +
            ",\"required_capabilities\":" +
            capability_array(message.required_capabilities) + "}";
    }
    if (message.kind == NATravPeerHandshakeMessageKind::hello_ack) {
        const std::string artifact =
            "{\"sha256\":" + quote(message.artifact.sha256) +
            ",\"target\":" + quote(message.artifact.target) +
            ",\"version\":" + quote(message.artifact.version) + "}";
        return "{\"artifact\":" + artifact +
            ",\"available_capabilities\":" +
            capability_array(message.available_capabilities) +
            ",\"kind\":\"HELLO_ACK\",\"protocol\":" + protocol +
            ",\"request_id\":" + quote(message.request_id) + "}";
    }
    return "{\"code\":" + quote(message.error_code) +
        ",\"kind\":\"ERROR\",\"message\":" +
        quote(message.error_message) + ",\"protocol\":" + protocol +
        ",\"request_id\":" + quote(message.request_id) + "}";
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = {"NATRAV_OVERLAY_PEER", 1, 0};
    message.request_id = std::string(64U, '1');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = {
            std::string(64U, 'a'),
            "target",
            "version",
        };
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            message.required_capabilities = {"PING", "STATUS"};
        } else {
            message.available_capabilities = {"PING", "STATUS"};
        }
    } else {
        message.error_code = "TEST_ERROR";
        message.error_message = "message";
    }
    return message;
}

[[nodiscard]] char base36(const std::size_t value) noexcept {
    return value < 10U ? static_cast<char>('0' + value) :
        static_cast<char>('A' + (value - 10U));
}

[[nodiscard]] std::string capability_name(const std::size_t value) {
    return std::string{
        'A',
        base36((value / (36U * 36U)) % 36U),
        base36((value / 36U) % 36U),
        base36(value % 36U),
    };
}

void compare_case(
    Results& results,
    const Octets& payload,
    const bool accepted_expected) {
    const Octets before = payload;
    const auto current = datacube::natrav_peer_decode_message(payload);
    const auto historical = datacube::historical_decode_message_0470(payload);
    ++results.semantic_cases;
    ++results.exact_observation_comparisons;
    check(
        results,
        same_observation(current, historical),
        "historical_observation_equivalence");
    ++results.input_preservation_checks;
    check(results, payload == before, "input_preserved");
    if (current.status == NATravPeerMessageDecodeStatus::accepted) {
        ++results.accepted_cases;
        check(results, accepted_expected && current.message.has_value(),
              "accepted_expected");
        const auto encoded = datacube::natrav_peer_encode_message(*current.message);
        ++results.exact_roundtrips;
        check(
            results,
            encoded.status == NATravPeerMessageEncodeStatus::accepted &&
                encoded.payload && *encoded.payload == payload,
            "exact_roundtrip");
    } else {
        ++results.rejection_cases;
        check(results, !accepted_expected, "rejection_expected");
    }
}

void accepted_fixtures(Results& results) {
    std::vector<NATravPeerHandshakeMessage> messages;
    messages.push_back(base_message(NATravPeerHandshakeMessageKind::hello));
    messages.push_back(base_message(NATravPeerHandshakeMessageKind::hello_ack));
    messages.push_back(base_message(NATravPeerHandshakeMessageKind::error));

    auto escaped = base_message(NATravPeerHandshakeMessageKind::hello);
    escaped.artifact.target = "target\n\"\\";
    escaped.artifact.version =
        std::string("v\0", 2U) + "\x1f" + "\xe2\x82\xac";
    messages.push_back(std::move(escaped));

    auto error = base_message(NATravPeerHandshakeMessageKind::error);
    error.error_message =
        std::string("line\nquote\"slash\\nul\0", 22U) +
        "\xe2\x82\xac\xf0\x9f\x98\x80";
    messages.push_back(std::move(error));

    for (const auto& message : messages) {
        compare_case(results, octets(serialize(message)), true);
    }
}

void rejection_fixtures(Results& results) {
    const std::string valid =
        serialize(base_message(NATravPeerHandshakeMessageKind::hello_ack));
    const std::string request_id(64U, '1');
    const std::string artifact_sha(64U, 'a');
    const std::vector<std::string> fixtures = {
        "{}",
        "[]",
        "null",
        " " + valid,
        valid + " ",
        "{\"a\":1,\"a\":2}",
        "{\"kind\":\"OTHER\"}",
        "{\"kind\":1}",
        "{\"artifact\":{},\"kind\":\"HELLO\",\"protocol\":{},\"request_id\":\"" +
            request_id + "\",\"required_capabilities\":[]}",
        "{\"artifact\":{\"sha256\":\"" + artifact_sha +
            "\",\"target\":\"target\",\"version\":\"version\"},\"kind\":\"HELLO\",\"protocol\":{\"id\":\"WRONG\",\"major\":1,\"minor\":0},\"request_id\":\"" +
            request_id + "\",\"required_capabilities\":[]}",
        "{\"artifact\":{\"sha256\":\"" + artifact_sha +
            "\",\"target\":\"target\",\"version\":\"version\"},\"kind\":\"HELLO\",\"protocol\":{\"id\":\"NATRAV_OVERLAY_PEER\",\"major\":1,\"minor\":0},\"request_id\":\"bad\",\"required_capabilities\":[]}",
        "{\"artifact\":{\"sha256\":\"bad\",\"target\":\"target\",\"version\":\"version\"},\"kind\":\"HELLO\",\"protocol\":{\"id\":\"NATRAV_OVERLAY_PEER\",\"major\":1,\"minor\":0},\"request_id\":\"" +
            request_id + "\",\"required_capabilities\":[]}",
        "{\"artifact\":{\"sha256\":\"" + artifact_sha +
            "\",\"target\":\"target\",\"version\":\"version\"},\"kind\":\"HELLO\",\"protocol\":{\"id\":\"NATRAV_OVERLAY_PEER\",\"major\":1,\"minor\":0},\"request_id\":\"" +
            request_id + "\",\"required_capabilities\":[\"STATUS\",\"PING\"]}",
        "{\"code\":\"TEST\",\"kind\":\"ERROR\",\"message\":\"\",\"protocol\":{\"id\":\"NATRAV_OVERLAY_PEER\",\"major\":1,\"minor\":0},\"request_id\":\"" +
            request_id + "\"}",
        "{\"kind\":\"HELLO\",\"z\":[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[0]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]}",
    };
    for (const auto& fixture : fixtures) {
        compare_case(results, octets(fixture), false);
    }

    const Octets empty;
    compare_case(results, empty, false);
    compare_case(results, Octets{static_cast<std::uint8_t>('{')}, false);
    compare_case(results, Octets(65537U, static_cast<std::uint8_t>('x')), false);
}

void deterministic_random(Results& results) {
    std::uint32_t state_value = 0x0471C0DEU;
    for (std::size_t case_index = 0U; case_index < 4096U; ++case_index) {
        const std::size_t size = 2U + (case_index % 511U);
        Octets payload(size);
        for (std::uint8_t& byte : payload) {
            state_value ^= state_value << 13U;
            state_value ^= state_value >> 17U;
            state_value ^= state_value << 5U;
            byte = static_cast<std::uint8_t>(state_value & 0xFFU);
        }
        compare_case(results, payload, false);
        ++results.random_cases;
    }
}

struct Measurement final {
    NATravPeerMessageDecodeObservation observation;
    State allocation;
};

[[nodiscard]] Measurement measure_current(const Octets& payload) {
    arm();
    auto observation = datacube::natrav_peer_decode_message(payload);
    const State measured = state;
    disarm();
    return Measurement{
        .observation = std::move(observation),
        .allocation = measured,
    };
}

[[nodiscard]] Measurement measure_historical(const Octets& payload) {
    arm();
    auto observation = datacube::historical_decode_message_0470(payload);
    const State measured = state;
    disarm();
    return Measurement{
        .observation = std::move(observation),
        .allocation = measured,
    };
}

void allocation_measurements(Results& results) {
    auto capabilities = base_message(NATravPeerHandshakeMessageKind::hello);
    capabilities.required_capabilities.clear();
    for (std::size_t index = 0U; index < 8500U; ++index) {
        capabilities.required_capabilities.push_back(capability_name(index));
    }
    const Octets capability_payload = octets(serialize(capabilities));
    results.large_capability_count = capabilities.required_capabilities.size();
    results.large_capability_payload_bytes = capability_payload.size();
    const Measurement current_capability = measure_current(capability_payload);
    const Measurement historical_capability =
        measure_historical(capability_payload);
    ++results.allocation_measurements;
    results.current_capability_maximum_allocation =
        current_capability.allocation.maximum;
    results.current_capability_allocation_count =
        current_capability.allocation.attempts;
    results.current_capability_total_allocation =
        current_capability.allocation.total;
    results.historical_capability_maximum_allocation =
        historical_capability.allocation.maximum;
    results.historical_capability_allocation_count =
        historical_capability.allocation.attempts;
    results.historical_capability_total_allocation =
        historical_capability.allocation.total;
    check(
        results,
        same_observation(
            current_capability.observation,
            historical_capability.observation) &&
            current_capability.observation.status ==
                NATravPeerMessageDecodeStatus::accepted &&
            capability_payload.size() <= 65536U &&
            current_capability.allocation.maximum <
                historical_capability.allocation.maximum &&
            current_capability.allocation.total * 2U <
                historical_capability.allocation.total,
        "large_capability_storage_reduction");

    auto error = base_message(NATravPeerHandshakeMessageKind::error);
    error.error_message.assign(64000U, 'x');
    error.error_message[17U] = '\n';
    error.error_message[300U] = '\"';
    error.error_message[4096U] = '\\';
    const Octets error_payload = octets(serialize(error));
    results.large_error_payload_bytes = error_payload.size();
    const Measurement current_error = measure_current(error_payload);
    const Measurement historical_error = measure_historical(error_payload);
    ++results.allocation_measurements;
    results.current_error_maximum_allocation =
        current_error.allocation.maximum;
    results.current_error_allocation_count =
        current_error.allocation.attempts;
    results.current_error_total_allocation =
        current_error.allocation.total;
    results.historical_error_maximum_allocation =
        historical_error.allocation.maximum;
    results.historical_error_allocation_count =
        historical_error.allocation.attempts;
    results.historical_error_total_allocation =
        historical_error.allocation.total;
    check(
        results,
        same_observation(current_error.observation, historical_error.observation) &&
            current_error.observation.status ==
                NATravPeerMessageDecodeStatus::accepted &&
            error_payload.size() <= 65536U &&
            current_error.allocation.total * 2U <
                historical_error.allocation.total,
        "large_error_storage_reduction");
}

void fault_scenario(Results& results, const Octets& payload) {
    const Octets before = payload;
    arm();
    const auto expected = datacube::natrav_peer_decode_message(payload);
    const std::size_t attempts = state.attempts;
    disarm();
    ++results.fault_scenarios;
    for (const bool persistent : {false, true}) {
        for (std::size_t point = 0U; point <= attempts; ++point) {
            std::optional<NATravPeerMessageDecodeObservation> actual;
            bool caught = false;
            arm(point, persistent);
            try {
                actual.emplace(datacube::natrav_peer_decode_message(payload));
            } catch (const InjectedBadAlloc& error) {
                caught = error.point == point;
            }
            const State measured = state;
            disarm();
            ++results.input_preservation_checks;
            check(results, payload == before, "fault_input_preserved");
            if (point < attempts) {
                ++results.faults;
                results.original_exceptions += caught ? 1U : 0U;
                ++results.exception_attempt_checks;
                check(
                    results,
                    caught && !actual && measured.attempts == point + 1U,
                    "original_exception_without_followup_allocation");
                if (persistent) {
                    ++results.persistent_fault_checks;
                }
            } else {
                ++results.success_boundaries;
                check(
                    results,
                    !caught && actual &&
                        same_observation(*actual, expected) &&
                        measured.attempts == attempts,
                    "fault_success_boundary");
            }
            ++results.retry_checks;
            check(
                results,
                same_observation(
                    datacube::natrav_peer_decode_message(payload), expected),
                "stateless_retry_after_recovery");
        }
    }
}

int run() {
    static_assert(datacube::kNATravPeerMinimumPayloadBytes == 2U);
    static_assert(datacube::kNATravPeerMaximumPayloadBytes == 65536U);
    static_assert(datacube::kNATravPeerMaximumJsonTreeDepth == 64U);
    static_assert(
        datacube::kNATravPeerMaximumJsonConstructionUnits == 16384U);

    Results results;
    accepted_fixtures(results);
    rejection_fixtures(results);
    deterministic_random(results);
    allocation_measurements(results);

    const auto fault_hello =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fault_scenario(results, octets(serialize(fault_hello)));
    auto fault_error = base_message(NATravPeerHandshakeMessageKind::error);
    fault_error.error_message = "fault\n\"\\\xe2\x82\xac";
    fault_scenario(results, octets(serialize(fault_error)));

    check(
        results,
        results.semantic_cases >= 4100U &&
            results.random_cases == 4096U &&
            results.accepted_cases >= 5U &&
            results.rejection_cases >= 4096U &&
            results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.large_capability_count == 8500U &&
            results.large_capability_payload_bytes <= 65536U &&
            results.large_error_payload_bytes <= 65536U &&
            results.allocation_measurements == 2U &&
            results.original_exceptions == results.faults,
        "coverage_and_bounds");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(allocation_measurements);
    PRINT_RESULT(large_capability_count);
    PRINT_RESULT(large_capability_payload_bytes);
    PRINT_RESULT(current_capability_maximum_allocation);
    PRINT_RESULT(current_capability_allocation_count);
    PRINT_RESULT(current_capability_total_allocation);
    PRINT_RESULT(historical_capability_maximum_allocation);
    PRINT_RESULT(historical_capability_allocation_count);
    PRINT_RESULT(historical_capability_total_allocation);
    PRINT_RESULT(large_error_payload_bytes);
    PRINT_RESULT(current_error_maximum_allocation);
    PRINT_RESULT(current_error_allocation_count);
    PRINT_RESULT(current_error_total_allocation);
    PRINT_RESULT(historical_error_maximum_allocation);
    PRINT_RESULT(historical_error_allocation_count);
    PRINT_RESULT(historical_error_total_allocation);
    PRINT_RESULT(fault_scenarios);
    PRINT_RESULT(faults);
    PRINT_RESULT(original_exceptions);
    PRINT_RESULT(exception_attempt_checks);
    PRINT_RESULT(success_boundaries);
    PRINT_RESULT(persistent_fault_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT

    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_schema_directed_decoder_test

int main() {
    try {
        return natrav_schema_directed_decoder_test::run();
    } catch (const std::exception& error) {
        natrav_schema_decoder_allocation_test::disarm();
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_SCHEMA_DIRECTED_DECODER_TEST


#ifdef DATACUBE_NATRAV_MESSAGE_SCHEMA_SINGLE_PASS_DECODER_TEST
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_single_pass_decoder_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t value) noexcept : point(value) {}
    const char* what() const noexcept override {
        return "NATRAV_SINGLE_PASS_DECODER_TEST_BAD_ALLOC";
    }
    std::size_t point;
};

struct State final {
    bool armed{false};
    bool persistent{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    std::size_t attempts{0U};
    std::size_t maximum{0U};
    std::size_t total{0U};
};

thread_local State state;

void arm(
    const std::size_t point = std::numeric_limits<std::size_t>::max(),
    const bool persistent = false) noexcept {
    state = {true, persistent, point, 0U, 0U, 0U};
}

void disarm() noexcept { state.armed = false; }

void allocation(const std::size_t size) {
    if (!state.armed) {
        return;
    }
    const std::size_t point = state.attempts++;
    state.maximum = std::max(state.maximum, size);
    state.total += size;
    if (point == state.point || (state.persistent && point > state.point)) {
        throw InjectedBadAlloc(point);
    }
}

void* allocate(const std::size_t size) {
    allocation(size);
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned(const std::size_t size, const std::align_val_t alignment) {
    allocation(size);
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

[[gnu::noinline]] void release(void* const pointer) noexcept {
    std::free(pointer);
}
}  // namespace natrav_single_pass_decoder_allocation_test

void* operator new(const std::size_t size) {
    return natrav_single_pass_decoder_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_single_pass_decoder_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_single_pass_decoder_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_single_pass_decoder_allocation_test::release(pointer);
}
void operator delete(void* const pointer, std::size_t) noexcept {
    natrav_single_pass_decoder_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, std::size_t) noexcept {
    natrav_single_pass_decoder_allocation_test::release(pointer);
}
void* operator new(const std::size_t size, const std::align_val_t alignment) {
    return natrav_single_pass_decoder_allocation_test::aligned(size, alignment);
}
void* operator new[](const std::size_t size, const std::align_val_t alignment) {
    return natrav_single_pass_decoder_allocation_test::aligned(size, alignment);
}
void operator delete(void* const pointer, std::align_val_t) noexcept {
    natrav_single_pass_decoder_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, std::align_val_t) noexcept {
    natrav_single_pass_decoder_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    std::size_t,
    std::align_val_t) noexcept {
    natrav_single_pass_decoder_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    std::size_t,
    std::align_val_t) noexcept {
    natrav_single_pass_decoder_allocation_test::release(pointer);
}

namespace datacube {
// Exact revision-0471 decoder body below; only the function name is changed.
// It shares the retained preflight and schema-cursor helpers and is test-only.
NATravPeerMessageDecodeObservation historical_decode_message_0471(
    const OctetView payload) {
    // The direct codec has the same byte envelope as its encoder and frame
    // layer. Reject before constructing input-sized storage or inspecting JSON.
    if (payload.size() < kNATravPeerMinimumPayloadBytes ||
        payload.size() > kNATravPeerMaximumPayloadBytes) {
        return observation(NATravPeerMessageDecodeStatus::payload_size_rejected);
    }

    // The payload remains caller-owned for the duration of this stateless call.
    // A complete iterative preflight establishes malformed, root-shape,
    // canonical-spelling and structural-profile priority before any typed field
    // is projected. Accepted messages then bypass the general JsonValue tree and
    // canonical reconstruction entirely.
    const std::string_view text(
        reinterpret_cast<const char*>(payload.data()), payload.size());
    JsonPreflightObservation preflight;
    try {
        preflight = JsonPreflight(text).inspect();
    } catch (const Failure&) {
        return observation(NATravPeerMessageDecodeStatus::malformed_json);
    }
    if (preflight.root_kind != JsonValue::Kind::object) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }
    if (!preflight.canonical) {
        return observation(NATravPeerMessageDecodeStatus::noncanonical_json);
    }
    if (!preflight.tree_admissible()) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }

    const CanonicalMessageFieldSpans fields =
        scan_canonical_message_fields(text);
    if (!fields.kind || fields.kind->kind != JsonValue::Kind::string) {
        return observation(NATravPeerMessageDecodeStatus::message_kind_rejected);
    }

    NATravPeerHandshakeMessageKind kind =
        NATravPeerHandshakeMessageKind::unknown;
    if (fields.kind->bytes == "\"HELLO\"") {
        kind = NATravPeerHandshakeMessageKind::hello;
    } else if (fields.kind->bytes == "\"HELLO_ACK\"") {
        kind = NATravPeerHandshakeMessageKind::hello_ack;
    } else if (fields.kind->bytes == "\"ERROR\"") {
        kind = NATravPeerHandshakeMessageKind::error;
    } else {
        return observation(NATravPeerMessageDecodeStatus::message_kind_rejected);
    }

    if (!canonical_message_shape_exact_revision_0480(fields, kind)) {
        return observation(NATravPeerMessageDecodeStatus::schema_rejected);
    }

    CanonicalProtocolProjection protocol;
    if (!project_canonical_protocol(*fields.protocol, protocol)) {
        return observation(NATravPeerMessageDecodeStatus::protocol_mismatch);
    }

    const std::string_view request_id =
        canonical_ascii_string_contents(*fields.request_id);
    if (fields.request_id->kind != JsonValue::Kind::string ||
        !lower_hex_sha256(request_id)) {
        return observation(NATravPeerMessageDecodeStatus::request_id_rejected);
    }

    CanonicalArtifactProjection artifact;
    CanonicalCapabilityProjection capabilities;
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        if (!project_canonical_artifact(*fields.artifact, artifact)) {
            return observation(
                NATravPeerMessageDecodeStatus::artifact_identity_rejected);
        }
        const CanonicalJsonSpan capability_span =
            kind == NATravPeerHandshakeMessageKind::hello ?
                *fields.required_capabilities :
                *fields.available_capabilities;
        if (!project_canonical_capabilities(
                capability_span, capabilities)) {
            return observation(
                NATravPeerMessageDecodeStatus::capability_declaration_rejected);
        }
    } else {
        const std::string_view code =
            canonical_ascii_string_contents(*fields.code);
        if (fields.code->kind != JsonValue::Kind::string ||
            !capability_token(code) ||
            fields.message->kind != JsonValue::Kind::string ||
            fields.message->bytes.size() == 2U) {
            return observation(NATravPeerMessageDecodeStatus::schema_rejected);
        }
    }

    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = protocol.minor,
    };
    message.request_id.assign(request_id);
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = NATravPeerArtifactIdentity{
            .sha256 = std::string(
                canonical_ascii_string_contents(artifact.sha256)),
            .target = decode_canonical_string(artifact.target),
            .version = decode_canonical_string(artifact.version),
        };
        const CanonicalJsonSpan capability_span =
            kind == NATravPeerHandshakeMessageKind::hello ?
                *fields.required_capabilities :
                *fields.available_capabilities;
        std::vector<std::string> decoded_capabilities =
            decode_canonical_capabilities(
                capability_span, capabilities.count);
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            message.required_capabilities =
                std::move(decoded_capabilities);
        } else {
            message.available_capabilities =
                std::move(decoded_capabilities);
        }
    } else {
        message.error_code.assign(
            canonical_ascii_string_contents(*fields.code));
        message.error_message = decode_canonical_string(*fields.message);
    }

    return NATravPeerMessageDecodeObservation{
        .status = NATravPeerMessageDecodeStatus::accepted,
        .classification = "ACCEPTED",
        .message = std::move(message),
    };
}


}  // namespace datacube

namespace natrav_single_pass_decoder_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_single_pass_decoder_allocation_test::InjectedBadAlloc;
using natrav_single_pass_decoder_allocation_test::State;
using natrav_single_pass_decoder_allocation_test::arm;
using natrav_single_pass_decoder_allocation_test::disarm;
using natrav_single_pass_decoder_allocation_test::state;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t allocation_measurements{0U};
    std::size_t large_capability_count{0U};
    std::size_t large_capability_payload_bytes{0U};
    std::size_t current_capability_maximum_allocation{0U};
    std::size_t current_capability_allocation_count{0U};
    std::size_t current_capability_total_allocation{0U};
    std::size_t historical_capability_maximum_allocation{0U};
    std::size_t historical_capability_allocation_count{0U};
    std::size_t historical_capability_total_allocation{0U};
    std::size_t large_error_payload_bytes{0U};
    std::size_t current_error_maximum_allocation{0U};
    std::size_t current_error_allocation_count{0U};
    std::size_t current_error_total_allocation{0U};
    std::size_t historical_error_maximum_allocation{0U};
    std::size_t historical_error_allocation_count{0U};
    std::size_t historical_error_total_allocation{0U};
    std::size_t fault_scenarios{0U};
    std::size_t faults{0U};
    std::size_t original_exceptions{0U};
    std::size_t exception_attempt_checks{0U};
    std::size_t success_boundaries{0U};
    std::size_t persistent_fault_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(Results& results, const bool okay, const char* const label) {
    if (!okay) {
        ++results.failures;
        if (results.failures <= 32U) {
            std::fprintf(stderr, "FAIL %s\n", label);
        }
    }
}

[[nodiscard]] Octets octets(const std::string_view text) {
    return Octets(text.begin(), text.end());
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    return left.status == right.status &&
        left.classification == right.classification &&
        left.message.has_value() == right.message.has_value() &&
        (!left.message || same_message(*left.message, *right.message));
}

[[nodiscard]] std::string quote(const std::string_view input) {
    static constexpr std::string_view hex = "0123456789abcdef";
    std::string result;
    result.push_back('"');
    for (const char raw : input) {
        const auto value = static_cast<unsigned char>(raw);
        switch (value) {
            case '"': result.append("\\\""); break;
            case '\\': result.append("\\\\"); break;
            case '\b': result.append("\\b"); break;
            case '\f': result.append("\\f"); break;
            case '\n': result.append("\\n"); break;
            case '\r': result.append("\\r"); break;
            case '\t': result.append("\\t"); break;
            default:
                if (value < 0x20U) {
                    result.append("\\u00");
                    result.push_back(hex[value >> 4U]);
                    result.push_back(hex[value & 0x0FU]);
                } else {
                    result.push_back(raw);
                }
        }
    }
    result.push_back('"');
    return result;
}

[[nodiscard]] std::string capability_array(
    const std::vector<std::string>& values) {
    std::string result{"["};
    for (std::size_t index = 0U; index < values.size(); ++index) {
        if (index != 0U) {
            result.push_back(',');
        }
        result.append(quote(values[index]));
    }
    result.push_back(']');
    return result;
}

[[nodiscard]] std::string serialize(
    const NATravPeerHandshakeMessage& message) {
    const std::string protocol =
        "{\"id\":" + quote(message.protocol.id) +
        ",\"major\":" + std::to_string(message.protocol.major) +
        ",\"minor\":" + std::to_string(message.protocol.minor) + "}";
    if (message.kind == NATravPeerHandshakeMessageKind::hello) {
        const std::string artifact =
            "{\"sha256\":" + quote(message.artifact.sha256) +
            ",\"target\":" + quote(message.artifact.target) +
            ",\"version\":" + quote(message.artifact.version) + "}";
        return "{\"artifact\":" + artifact +
            ",\"kind\":\"HELLO\",\"protocol\":" + protocol +
            ",\"request_id\":" + quote(message.request_id) +
            ",\"required_capabilities\":" +
            capability_array(message.required_capabilities) + "}";
    }
    if (message.kind == NATravPeerHandshakeMessageKind::hello_ack) {
        const std::string artifact =
            "{\"sha256\":" + quote(message.artifact.sha256) +
            ",\"target\":" + quote(message.artifact.target) +
            ",\"version\":" + quote(message.artifact.version) + "}";
        return "{\"artifact\":" + artifact +
            ",\"available_capabilities\":" +
            capability_array(message.available_capabilities) +
            ",\"kind\":\"HELLO_ACK\",\"protocol\":" + protocol +
            ",\"request_id\":" + quote(message.request_id) + "}";
    }
    return "{\"code\":" + quote(message.error_code) +
        ",\"kind\":\"ERROR\",\"message\":" +
        quote(message.error_message) + ",\"protocol\":" + protocol +
        ",\"request_id\":" + quote(message.request_id) + "}";
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = {"NATRAV_OVERLAY_PEER", 1, 0};
    message.request_id = std::string(64U, '1');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = {
            std::string(64U, 'a'),
            "target",
            "version",
        };
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            message.required_capabilities = {"PING", "STATUS"};
        } else {
            message.available_capabilities = {"PING", "STATUS"};
        }
    } else {
        message.error_code = "TEST_ERROR";
        message.error_message = "message";
    }
    return message;
}

[[nodiscard]] char base36(const std::size_t value) noexcept {
    return value < 10U ? static_cast<char>('0' + value) :
        static_cast<char>('A' + (value - 10U));
}

[[nodiscard]] std::string capability_name(const std::size_t value) {
    return std::string{
        'A',
        base36((value / (36U * 36U)) % 36U),
        base36((value / 36U) % 36U),
        base36(value % 36U),
    };
}

void compare_case(
    Results& results,
    const Octets& payload,
    const bool accepted_expected) {
    const Octets before = payload;
    const auto current = datacube::natrav_peer_decode_message(payload);
    const auto historical = datacube::historical_decode_message_0471(payload);
    ++results.semantic_cases;
    ++results.exact_observation_comparisons;
    check(
        results,
        same_observation(current, historical),
        "historical_observation_equivalence");
    ++results.input_preservation_checks;
    check(results, payload == before, "input_preserved");
    if (current.status == NATravPeerMessageDecodeStatus::accepted) {
        ++results.accepted_cases;
        check(results, accepted_expected && current.message.has_value(),
              "accepted_expected");
        const auto encoded = datacube::natrav_peer_encode_message(*current.message);
        ++results.exact_roundtrips;
        check(
            results,
            encoded.status == NATravPeerMessageEncodeStatus::accepted &&
                encoded.payload && *encoded.payload == payload,
            "exact_roundtrip");
    } else {
        ++results.rejection_cases;
        check(results, !accepted_expected, "rejection_expected");
    }
}

void accepted_fixtures(Results& results) {
    std::vector<NATravPeerHandshakeMessage> messages;
    messages.push_back(base_message(NATravPeerHandshakeMessageKind::hello));
    messages.push_back(base_message(NATravPeerHandshakeMessageKind::hello_ack));
    messages.push_back(base_message(NATravPeerHandshakeMessageKind::error));

    auto escaped = base_message(NATravPeerHandshakeMessageKind::hello);
    escaped.artifact.target = "target\n\"\\";
    escaped.artifact.version =
        std::string("v\0", 2U) + "\x1f" + "\xe2\x82\xac";
    messages.push_back(std::move(escaped));

    auto error = base_message(NATravPeerHandshakeMessageKind::error);
    error.error_message =
        std::string("line\nquote\"slash\\nul\0", 22U) +
        "\xe2\x82\xac\xf0\x9f\x98\x80";
    messages.push_back(std::move(error));

    for (const auto& message : messages) {
        compare_case(results, octets(serialize(message)), true);
    }
}

void rejection_fixtures(Results& results) {
    const std::string valid =
        serialize(base_message(NATravPeerHandshakeMessageKind::hello_ack));
    const std::string request_id(64U, '1');
    const std::string artifact_sha(64U, 'a');
    const std::vector<std::string> fixtures = {
        "{}",
        "[]",
        "null",
        " " + valid,
        valid + " ",
        "{\"a\":1,\"a\":2}",
        "{\"kind\":\"OTHER\"}",
        "{\"kind\":1}",
        "{\"artifact\":{},\"kind\":\"HELLO\",\"protocol\":{},\"request_id\":\"" +
            request_id + "\",\"required_capabilities\":[]}",
        "{\"artifact\":{\"sha256\":\"" + artifact_sha +
            "\",\"target\":\"target\",\"version\":\"version\"},\"kind\":\"HELLO\",\"protocol\":{\"id\":\"WRONG\",\"major\":1,\"minor\":0},\"request_id\":\"" +
            request_id + "\",\"required_capabilities\":[]}",
        "{\"artifact\":{\"sha256\":\"" + artifact_sha +
            "\",\"target\":\"target\",\"version\":\"version\"},\"kind\":\"HELLO\",\"protocol\":{\"id\":\"NATRAV_OVERLAY_PEER\",\"major\":1,\"minor\":0},\"request_id\":\"bad\",\"required_capabilities\":[]}",
        "{\"artifact\":{\"sha256\":\"bad\",\"target\":\"target\",\"version\":\"version\"},\"kind\":\"HELLO\",\"protocol\":{\"id\":\"NATRAV_OVERLAY_PEER\",\"major\":1,\"minor\":0},\"request_id\":\"" +
            request_id + "\",\"required_capabilities\":[]}",
        "{\"artifact\":{\"sha256\":\"" + artifact_sha +
            "\",\"target\":\"target\",\"version\":\"version\"},\"kind\":\"HELLO\",\"protocol\":{\"id\":\"NATRAV_OVERLAY_PEER\",\"major\":1,\"minor\":0},\"request_id\":\"" +
            request_id + "\",\"required_capabilities\":[\"STATUS\",\"PING\"]}",
        "{\"code\":\"TEST\",\"kind\":\"ERROR\",\"message\":\"\",\"protocol\":{\"id\":\"NATRAV_OVERLAY_PEER\",\"major\":1,\"minor\":0},\"request_id\":\"" +
            request_id + "\"}",
        "{\"kind\":\"HELLO\",\"z\":[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[0]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]}",
    };
    for (const auto& fixture : fixtures) {
        compare_case(results, octets(fixture), false);
    }

    const Octets empty;
    compare_case(results, empty, false);
    compare_case(results, Octets{static_cast<std::uint8_t>('{')}, false);
    compare_case(results, Octets(65537U, static_cast<std::uint8_t>('x')), false);
}

void deterministic_random(Results& results) {
    std::uint32_t state_value = 0x0471C0DEU;
    for (std::size_t case_index = 0U; case_index < 4096U; ++case_index) {
        const std::size_t size = 2U + (case_index % 511U);
        Octets payload(size);
        for (std::uint8_t& byte : payload) {
            state_value ^= state_value << 13U;
            state_value ^= state_value >> 17U;
            state_value ^= state_value << 5U;
            byte = static_cast<std::uint8_t>(state_value & 0xFFU);
        }
        compare_case(results, payload, false);
        ++results.random_cases;
    }
}

struct Measurement final {
    NATravPeerMessageDecodeObservation observation;
    State allocation;
};

[[nodiscard]] Measurement measure_current(const Octets& payload) {
    arm();
    auto observation = datacube::natrav_peer_decode_message(payload);
    const State measured = state;
    disarm();
    return Measurement{
        .observation = std::move(observation),
        .allocation = measured,
    };
}

[[nodiscard]] Measurement measure_historical(const Octets& payload) {
    arm();
    auto observation = datacube::historical_decode_message_0471(payload);
    const State measured = state;
    disarm();
    return Measurement{
        .observation = std::move(observation),
        .allocation = measured,
    };
}

void allocation_measurements(Results& results) {
    auto capabilities = base_message(NATravPeerHandshakeMessageKind::hello);
    capabilities.required_capabilities.clear();
    for (std::size_t index = 0U; index < 8500U; ++index) {
        capabilities.required_capabilities.push_back(capability_name(index));
    }
    const Octets capability_payload = octets(serialize(capabilities));
    results.large_capability_count = capabilities.required_capabilities.size();
    results.large_capability_payload_bytes = capability_payload.size();
    const Measurement current_capability = measure_current(capability_payload);
    const Measurement historical_capability =
        measure_historical(capability_payload);
    ++results.allocation_measurements;
    results.current_capability_maximum_allocation =
        current_capability.allocation.maximum;
    results.current_capability_allocation_count =
        current_capability.allocation.attempts;
    results.current_capability_total_allocation =
        current_capability.allocation.total;
    results.historical_capability_maximum_allocation =
        historical_capability.allocation.maximum;
    results.historical_capability_allocation_count =
        historical_capability.allocation.attempts;
    results.historical_capability_total_allocation =
        historical_capability.allocation.total;
    // Revision 0485 uses one 64-entry spill chunk and five 2,032-entry
    // tail chunks for this 8,500-entry declaration. Remove those explicit
    // retained-span costs before keeping the revision-0472 parser-bookkeeping
    // comparison against the historical tree.
    constexpr std::size_t capability_span_spill_allocations = 6U;
    constexpr std::size_t capability_span_spill_bytes = 40896U;
    check(
        results,
        same_observation(
            current_capability.observation,
            historical_capability.observation) &&
            current_capability.observation.status ==
                NATravPeerMessageDecodeStatus::accepted &&
            capability_payload.size() <= 65536U &&
            current_capability.allocation.maximum <=
                historical_capability.allocation.maximum &&
            current_capability.allocation.attempts >=
                capability_span_spill_allocations &&
            current_capability.allocation.attempts -
                    capability_span_spill_allocations + 8U <=
                historical_capability.allocation.attempts &&
            current_capability.allocation.total >=
                capability_span_spill_bytes +
                    current_capability.allocation.maximum &&
            (current_capability.allocation.total -
                 capability_span_spill_bytes -
                 current_capability.allocation.maximum) * 4U <
                historical_capability.allocation.total -
                    historical_capability.allocation.maximum,
        "large_capability_preflight_storage_reduction");

    auto error = base_message(NATravPeerHandshakeMessageKind::error);
    error.error_message.assign(64000U, 'x');
    error.error_message[17U] = '\n';
    error.error_message[300U] = '\"';
    error.error_message[4096U] = '\\';
    const Octets error_payload = octets(serialize(error));
    results.large_error_payload_bytes = error_payload.size();
    const Measurement current_error = measure_current(error_payload);
    const Measurement historical_error = measure_historical(error_payload);
    ++results.allocation_measurements;
    results.current_error_maximum_allocation =
        current_error.allocation.maximum;
    results.current_error_allocation_count =
        current_error.allocation.attempts;
    results.current_error_total_allocation =
        current_error.allocation.total;
    results.historical_error_maximum_allocation =
        historical_error.allocation.maximum;
    results.historical_error_allocation_count =
        historical_error.allocation.attempts;
    results.historical_error_total_allocation =
        historical_error.allocation.total;
    check(
        results,
        same_observation(current_error.observation, historical_error.observation) &&
            current_error.observation.status ==
                NATravPeerMessageDecodeStatus::accepted &&
            error_payload.size() <= 65536U &&
            current_error.allocation.maximum <=
                historical_error.allocation.maximum &&
            current_error.allocation.attempts + 6U <=
                historical_error.allocation.attempts &&
            (current_error.allocation.total -
                 current_error.allocation.maximum) * 4U <
                historical_error.allocation.total -
                    historical_error.allocation.maximum,
        "large_error_preflight_storage_reduction");
}

void fault_scenario(Results& results, const Octets& payload) {
    const Octets before = payload;
    arm();
    const auto expected = datacube::natrav_peer_decode_message(payload);
    const std::size_t attempts = state.attempts;
    disarm();
    ++results.fault_scenarios;
    for (const bool persistent : {false, true}) {
        for (std::size_t point = 0U; point <= attempts; ++point) {
            std::optional<NATravPeerMessageDecodeObservation> actual;
            bool caught = false;
            arm(point, persistent);
            try {
                actual.emplace(datacube::natrav_peer_decode_message(payload));
            } catch (const InjectedBadAlloc& error) {
                caught = error.point == point;
            }
            const State measured = state;
            disarm();
            ++results.input_preservation_checks;
            check(results, payload == before, "fault_input_preserved");
            if (point < attempts) {
                ++results.faults;
                results.original_exceptions += caught ? 1U : 0U;
                ++results.exception_attempt_checks;
                check(
                    results,
                    caught && !actual && measured.attempts == point + 1U,
                    "original_exception_without_followup_allocation");
                if (persistent) {
                    ++results.persistent_fault_checks;
                }
            } else {
                ++results.success_boundaries;
                check(
                    results,
                    !caught && actual &&
                        same_observation(*actual, expected) &&
                        measured.attempts == attempts,
                    "fault_success_boundary");
            }
            ++results.retry_checks;
            check(
                results,
                same_observation(
                    datacube::natrav_peer_decode_message(payload), expected),
                "stateless_retry_after_recovery");
        }
    }
}

int run() {
    static_assert(datacube::kNATravPeerMinimumPayloadBytes == 2U);
    static_assert(datacube::kNATravPeerMaximumPayloadBytes == 65536U);
    static_assert(datacube::kNATravPeerMaximumJsonTreeDepth == 64U);
    static_assert(
        datacube::kNATravPeerMaximumJsonConstructionUnits == 16384U);

    Results results;
    accepted_fixtures(results);
    rejection_fixtures(results);
    deterministic_random(results);
    allocation_measurements(results);

    const auto fault_hello =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fault_scenario(results, octets(serialize(fault_hello)));
    auto fault_error = base_message(NATravPeerHandshakeMessageKind::error);
    fault_error.error_message = "fault\n\"\\\xe2\x82\xac";
    fault_scenario(results, octets(serialize(fault_error)));

    check(
        results,
        results.semantic_cases >= 4100U &&
            results.random_cases == 4096U &&
            results.accepted_cases >= 5U &&
            results.rejection_cases >= 4096U &&
            results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.large_capability_count == 8500U &&
            results.large_capability_payload_bytes <= 65536U &&
            results.large_error_payload_bytes <= 65536U &&
            results.allocation_measurements == 2U &&
            results.original_exceptions == results.faults,
        "coverage_and_bounds");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(allocation_measurements);
    PRINT_RESULT(large_capability_count);
    PRINT_RESULT(large_capability_payload_bytes);
    PRINT_RESULT(current_capability_maximum_allocation);
    PRINT_RESULT(current_capability_allocation_count);
    PRINT_RESULT(current_capability_total_allocation);
    PRINT_RESULT(historical_capability_maximum_allocation);
    PRINT_RESULT(historical_capability_allocation_count);
    PRINT_RESULT(historical_capability_total_allocation);
    PRINT_RESULT(large_error_payload_bytes);
    PRINT_RESULT(current_error_maximum_allocation);
    PRINT_RESULT(current_error_allocation_count);
    PRINT_RESULT(current_error_total_allocation);
    PRINT_RESULT(historical_error_maximum_allocation);
    PRINT_RESULT(historical_error_allocation_count);
    PRINT_RESULT(historical_error_total_allocation);
    PRINT_RESULT(fault_scenarios);
    PRINT_RESULT(faults);
    PRINT_RESULT(original_exceptions);
    PRINT_RESULT(exception_attempt_checks);
    PRINT_RESULT(success_boundaries);
    PRINT_RESULT(persistent_fault_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT

    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_single_pass_decoder_test

int main() {
    try {
        return natrav_single_pass_decoder_test::run();
    } catch (const std::exception& error) {
        natrav_single_pass_decoder_allocation_test::disarm();
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_SCHEMA_SINGLE_PASS_DECODER_TEST


// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_CANONICAL_STRING_CODEC_TEST
#include <cstdio>
#include <cstdlib>
#include <new>

namespace natrav_canonical_string_codec_allocation_test {
thread_local bool armed = false;
thread_local std::size_t attempts = 0U;

void arm() noexcept {
    attempts = 0U;
    armed = true;
}
void disarm() noexcept { armed = false; }
void note() noexcept {
    if (armed) {
        ++attempts;
    }
}
void* allocate(const std::size_t size) {
    note();
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}
void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    note();
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}
void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_canonical_string_codec_allocation_test

void* operator new(const std::size_t size) {
    return natrav_canonical_string_codec_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_canonical_string_codec_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_canonical_string_codec_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_canonical_string_codec_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_canonical_string_codec_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_canonical_string_codec_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_canonical_string_codec_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_canonical_string_codec_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_canonical_string_codec_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_canonical_string_codec_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_canonical_string_codec_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_canonical_string_codec_allocation_test::release(pointer);
}

namespace natrav_canonical_string_codec_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;

struct Results final {
    std::size_t unicode_scalar_cases{0U};
    std::size_t utf8_roundtrip_checks{0U};
    std::size_t canonical_fragment_comparisons{0U};
    std::size_t canonical_token_checks{0U};
    std::size_t decoded_byte_checks{0U};
    std::size_t primitive_allocation_attempts{0U};
    std::size_t spelling_cases{0U};
    std::size_t canonical_spelling_cases{0U};
    std::size_t noncanonical_spelling_cases{0U};
    std::size_t malformed_cases{0U};
    std::size_t exact_failure_codes{0U};
    std::size_t end_to_end_messages{0U};
    std::size_t exact_message_roundtrips{0U};
    std::size_t encoder_integration_checks{0U};
    std::size_t decoder_integration_checks{0U};
    std::size_t failures{0U};
};

void check(Results& results, const bool condition, const char* const label) {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

struct FixedBuffer final {
    std::array<char, 32U> bytes{};
    std::size_t size{0U};

    [[nodiscard]] bool append(const std::string_view value) noexcept {
        if (value.size() > bytes.size() - size) {
            return false;
        }
        for (const char character : value) {
            bytes[size++] = character;
        }
        return true;
    }

    [[nodiscard]] std::string_view view() const noexcept {
        return std::string_view(bytes.data(), size);
    }
};

[[nodiscard]] bool historical_emit_0472(
    const std::string_view value,
    FixedBuffer& output) noexcept {
    static constexpr std::string_view hex = "0123456789abcdef";
    if (!output.append("\"")) {
        return false;
    }
    for (const char raw : value) {
        const auto byte = static_cast<unsigned char>(raw);
        switch (byte) {
            case '"':
                if (!output.append("\\\"")) { return false; }
                break;
            case '\\':
                if (!output.append("\\\\")) { return false; }
                break;
            case '\b':
                if (!output.append("\\b")) { return false; }
                break;
            case '\f':
                if (!output.append("\\f")) { return false; }
                break;
            case '\n':
                if (!output.append("\\n")) { return false; }
                break;
            case '\r':
                if (!output.append("\\r")) { return false; }
                break;
            case '\t':
                if (!output.append("\\t")) { return false; }
                break;
            default:
                if (byte < 0x20U) {
                    const std::array<char, 6U> escaped{
                        '\\', 'u', '0', '0',
                        hex[static_cast<std::size_t>(byte >> 4U)],
                        hex[static_cast<std::size_t>(byte & 0x0FU)],
                    };
                    if (!output.append(std::string_view(
                            escaped.data(), escaped.size()))) {
                        return false;
                    }
                } else if (!output.append(std::string_view(&raw, 1U))) {
                    return false;
                }
        }
    }
    return output.append("\"");
}

void exhaustive_scalars(Results& results) {
    datacube::reset_canonical_string_codec_counters();
    natrav_canonical_string_codec_allocation_test::arm();
    bool all_valid = true;
    for (std::uint32_t code_point = 0U;
         code_point <= 0x10FFFFU;
         ++code_point) {
        if (code_point >= 0xD800U && code_point <= 0xDFFFU) {
            continue;
        }
        ++results.unicode_scalar_cases;
        std::array<unsigned char, 4U> raw_bytes{};
        const std::size_t raw_size = datacube::encode_utf8_scalar(
            code_point, raw_bytes.data());
        const std::string_view raw(
            reinterpret_cast<const char*>(raw_bytes.data()), raw_size);

        datacube::Utf8Scalar decoded;
        const bool decoded_ok =
            datacube::decode_utf8_scalar(raw, 0U, decoded);
        ++results.utf8_roundtrip_checks;
        if (!decoded_ok || decoded.code_point != code_point ||
            decoded.width != raw_size) {
            all_valid = false;
            continue;
        }

        FixedBuffer current;
        const bool current_ok = datacube::emit_canonical_json_string(
            raw,
            [&current](const std::string_view fragment) noexcept {
                return current.append(fragment);
            });
        FixedBuffer historical;
        const bool historical_ok = historical_emit_0472(raw, historical);
        ++results.canonical_fragment_comparisons;
        if (!current_ok || !historical_ok ||
            current.view() != historical.view()) {
            all_valid = false;
            continue;
        }

        std::size_t token_offset = 0U;
        const datacube::JsonStringTokenParseResult token =
            datacube::parse_json_string_token_checked(
                current.view(), token_offset);
        ++results.canonical_token_checks;
        if (!token.canonical || token.token != current.view() ||
            token_offset != current.size) {
            all_valid = false;
            continue;
        }

        datacube::DecodedJsonStringByteCursor cursor(current.view());
        std::array<unsigned char, 4U> observed{};
        std::size_t observed_size = 0U;
        unsigned char byte = 0U;
        while (cursor.next(byte)) {
            if (observed_size >= observed.size()) {
                all_valid = false;
                break;
            }
            observed[observed_size++] = byte;
        }
        results.decoded_byte_checks += observed_size;
        if (observed_size != raw_size ||
            !std::equal(
                observed.begin(),
                observed.begin() + static_cast<std::ptrdiff_t>(observed_size),
                raw_bytes.begin())) {
            all_valid = false;
        }
    }
    results.primitive_allocation_attempts =
        natrav_canonical_string_codec_allocation_test::attempts;
    natrav_canonical_string_codec_allocation_test::disarm();
    check(results, all_valid, "exhaustive_unicode_scalar_equivalence");
    check(
        results,
        results.unicode_scalar_cases == 1112064U,
        "complete_unicode_scalar_count");
    check(
        results,
        results.primitive_allocation_attempts == 0U,
        "allocation_free_scalar_primitive");
}

struct SpellingCase final {
    std::string_view token;
    std::string_view decoded;
    bool canonical{false};
};

void spelling_cases(Results& results) {
    static constexpr std::array<SpellingCase, 19U> cases{{
        {"\"/\"", "/", true},
        {"\"\\/\"", "/", false},
        {"\"\\u002f\"", "/", false},
        {"\"\\u002F\"", "/", false},
        {"\"A\"", "A", true},
        {"\"\\u0041\"", "A", false},
        {"\"\\b\"", "\b", true},
        {"\"\\u0008\"", "\b", false},
        {"\"\\t\"", "\t", true},
        {"\"\\u0009\"", "\t", false},
        {"\"\\n\"", "\n", true},
        {"\"\\u000a\"", "\n", false},
        {"\"\\u0000\"", std::string_view("\0", 1U), true},
        {"\"\\u001f\"", std::string_view("\x1f", 1U), true},
        {"\"\\u001F\"", std::string_view("\x1f", 1U), false},
        {"\"é\"", "é", true},
        {"\"\\u00e9\"", "é", false},
        {"\"😀\"", "😀", true},
        {"\"\\ud83d\\ude00\"", "😀", false},
    }};
    for (const SpellingCase& test : cases) {
        ++results.spelling_cases;
        results.canonical_spelling_cases += test.canonical ? 1U : 0U;
        results.noncanonical_spelling_cases += test.canonical ? 0U : 1U;
        std::size_t offset = 0U;
        const datacube::JsonStringTokenParseResult parsed =
            datacube::parse_json_string_token_checked(test.token, offset);
        std::size_t capture_offset = 0U;
        const datacube::JsonStringParseResult captured =
            datacube::parse_json_string(
                test.token, capture_offset, true, test.decoded.size());
        check(
            results,
            offset == test.token.size() &&
                capture_offset == test.token.size() &&
                parsed.token == test.token &&
                parsed.canonical == test.canonical &&
                captured.canonical == test.canonical &&
                captured.value == test.decoded,
            "canonical_and_noncanonical_spelling");
    }
}

struct MalformedCase final {
    std::string token;
    std::string_view code;
};

void malformed_cases(Results& results) {
    std::array<MalformedCase, 10U> cases{{
        {"\"\\x\"", "natrav-peer-message-json-string-escape"},
        {"\"\\u12\"", "natrav-peer-message-json-unicode-short"},
        {"\"\\ud800\"", "natrav-peer-message-json-unpaired-high-surrogate"},
        {"\"\\ud800\\u0041\"", "natrav-peer-message-json-unpaired-high-surrogate"},
        {"\"\\udc00\"", "natrav-peer-message-json-unpaired-low-surrogate"},
        {"\"abc", "natrav-peer-message-json-string-unclosed"},
        {std::string("\"a\x01" "b\"", 5U), "natrav-peer-message-json-string-control"},
        {std::string("\"\xc0\x80\"", 4U), "natrav-peer-message-json-utf8"},
        {std::string("\"\xe2\x82\"", 4U), "natrav-peer-message-json-utf8"},
        {std::string("\"\xe2" "A" "\xa1\"", 5U), "natrav-peer-message-json-utf8"},
    }};
    for (const MalformedCase& test : cases) {
        ++results.malformed_cases;
        std::size_t offset = 0U;
        bool matched = false;
        try {
            static_cast<void>(
                datacube::parse_json_string_token_checked(test.token, offset));
        } catch (const datacube::Failure& error) {
            matched = error.code() == test.code;
        }
        results.exact_failure_codes += matched ? 1U : 0U;
        check(results, matched, "malformed_exact_failure_code");
    }
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = 0,
    };
    message.request_id.assign(64U, 'a');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = std::string(64U, 'b'),
            .target = "linux-😀",
            .version = "v1-é",
        };
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            message.required_capabilities = {"ALPHA", "OMEGA_2"};
        } else {
            message.available_capabilities = {"ALPHA", "OMEGA_2"};
        }
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "prefix";
        for (std::uint32_t code_point = 0U; code_point < 0x20U; ++code_point) {
            datacube::append_utf8(message.error_message, code_point);
        }
        message.error_message.append("\"/\\");
        for (const std::uint32_t code_point :
             {0x7FU, 0x80U, 0x7FFU, 0x800U, 0xD7FFU,
              0xE000U, 0xFFFFU, 0x10000U, 0x10FFFFU}) {
            datacube::append_utf8(message.error_message, code_point);
        }
    }
    return message;
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

void end_to_end(Results& results) {
    for (const NATravPeerHandshakeMessageKind kind :
         {NATravPeerHandshakeMessageKind::hello,
          NATravPeerHandshakeMessageKind::hello_ack,
          NATravPeerHandshakeMessageKind::error}) {
        ++results.end_to_end_messages;
        const NATravPeerHandshakeMessage message = base_message(kind);
        datacube::reset_canonical_string_codec_counters();
        const auto encoded = datacube::natrav_peer_encode_message(message);
        const datacube::CanonicalJsonStringCodecCounters encoder_counters =
            datacube::read_canonical_string_codec_counters();
        const bool encoder_integrated =
            encoder_counters.encoder_string_calls > 0U &&
            encoder_counters.canonical_fragment_calls > 0U &&
            encoder_counters.raw_scalar_decode_calls > 0U;
        results.encoder_integration_checks += encoder_integrated ? 1U : 0U;
        check(
            results,
            encoded.status == NATravPeerMessageEncodeStatus::accepted &&
                encoded.payload.has_value() && encoder_integrated,
            "encoder_shared_codec_integration");
        if (!encoded.payload) {
            continue;
        }

        datacube::reset_canonical_string_codec_counters();
        const auto decoded = datacube::natrav_peer_decode_message(
            *encoded.payload);
        const datacube::CanonicalJsonStringCodecCounters decoder_counters =
            datacube::read_canonical_string_codec_counters();
        const bool decoder_integrated =
            decoder_counters.json_scalar_parse_calls > 0U &&
            decoder_counters.canonical_fragment_calls > 0U &&
            decoder_counters.raw_scalar_decode_calls > 0U;
        results.decoder_integration_checks += decoder_integrated ? 1U : 0U;
        check(
            results,
            decoded.status == NATravPeerMessageDecodeStatus::accepted &&
                decoded.message.has_value() && decoder_integrated,
            "decoder_shared_codec_integration");
        const bool exact = decoded.message &&
            same_message(*decoded.message, message);
        results.exact_message_roundtrips += exact ? 1U : 0U;
        check(results, exact, "end_to_end_exact_message_roundtrip");
    }
}

int run() {
    Results results;
    exhaustive_scalars(results);
    spelling_cases(results);
    malformed_cases(results);
    end_to_end(results);
    check(
        results,
        results.canonical_fragment_comparisons ==
            results.unicode_scalar_cases &&
            results.canonical_token_checks == results.unicode_scalar_cases &&
            results.exact_failure_codes == results.malformed_cases &&
            results.exact_message_roundtrips == results.end_to_end_messages &&
            results.encoder_integration_checks == results.end_to_end_messages &&
            results.decoder_integration_checks == results.end_to_end_messages,
        "coverage_and_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(unicode_scalar_cases);
    PRINT_RESULT(utf8_roundtrip_checks);
    PRINT_RESULT(canonical_fragment_comparisons);
    PRINT_RESULT(canonical_token_checks);
    PRINT_RESULT(decoded_byte_checks);
    PRINT_RESULT(primitive_allocation_attempts);
    PRINT_RESULT(spelling_cases);
    PRINT_RESULT(canonical_spelling_cases);
    PRINT_RESULT(noncanonical_spelling_cases);
    PRINT_RESULT(malformed_cases);
    PRINT_RESULT(exact_failure_codes);
    PRINT_RESULT(end_to_end_messages);
    PRINT_RESULT(exact_message_roundtrips);
    PRINT_RESULT(encoder_integration_checks);
    PRINT_RESULT(decoder_integration_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_canonical_string_codec_test

int main() {
    try {
        return natrav_canonical_string_codec_test::run();
    } catch (const std::exception& error) {
        natrav_canonical_string_codec_allocation_test::disarm();
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_CANONICAL_STRING_CODEC_TEST

// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_CANONICAL_INTEGER_CODEC_TEST
#include <cstdio>
#include <cstdlib>
#include <new>

namespace natrav_canonical_integer_codec_allocation_test {
thread_local bool armed = false;
thread_local std::size_t attempts = 0U;

void arm() noexcept {
    attempts = 0U;
    armed = true;
}
void disarm() noexcept { armed = false; }
void note() noexcept {
    if (armed) {
        ++attempts;
    }
}
void* allocate(const std::size_t size) {
    note();
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}
void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    note();
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}
void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_canonical_integer_codec_allocation_test

void* operator new(const std::size_t size) {
    return natrav_canonical_integer_codec_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_canonical_integer_codec_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_canonical_integer_codec_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_canonical_integer_codec_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_canonical_integer_codec_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_canonical_integer_codec_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_canonical_integer_codec_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_canonical_integer_codec_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_canonical_integer_codec_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_canonical_integer_codec_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_canonical_integer_codec_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_canonical_integer_codec_allocation_test::release(pointer);
}

namespace natrav_canonical_integer_codec_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;

struct Results final {
    std::size_t integer_cases{0U};
    std::size_t boundary_cases{0U};
    std::size_t deterministic_cases{0U};
    std::size_t format_comparisons{0U};
    std::size_t parse_roundtrips{0U};
    std::size_t canonical_token_checks{0U};
    std::size_t primitive_allocation_attempts{0U};
    std::size_t noncanonical_cases{0U};
    std::size_t noncanonical_checks{0U};
    std::size_t malformed_cases{0U};
    std::size_t exact_failure_codes{0U};
    std::size_t classification_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t exception_checks{0U};
    std::size_t end_to_end_messages{0U};
    std::size_t exact_message_roundtrips{0U};
    std::size_t encoder_integration_checks{0U};
    std::size_t decoder_integration_checks{0U};
    std::size_t failures{0U};
};

void check(Results& results, const bool condition, const char* const label) {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

struct ReferenceInteger final {
    std::array<char, 20U> bytes{};
    std::size_t begin{bytes.size()};

    [[nodiscard]] std::string_view view() const noexcept {
        return std::string_view(bytes.data() + begin, bytes.size() - begin);
    }
};

[[nodiscard]] ReferenceInteger reference_integer(
    const std::int64_t value) noexcept {
    ReferenceInteger result;
    const bool negative = value < 0;
    std::uint64_t magnitude = negative ?
        std::uint64_t{0} - static_cast<std::uint64_t>(value) :
        static_cast<std::uint64_t>(value);
    do {
        const std::uint64_t digit = magnitude % 10U;
        --result.begin;
        result.bytes[result.begin] = static_cast<char>('0' + digit);
        magnitude /= 10U;
    } while (magnitude != 0U);
    if (negative) {
        --result.begin;
        result.bytes[result.begin] = '-';
    }
    return result;
}

void exercise_integer(
    Results& results,
    const std::int64_t value,
    const bool boundary) {
    ++results.integer_cases;
    results.boundary_cases += boundary ? 1U : 0U;
    results.deterministic_cases += boundary ? 0U : 1U;
    const ReferenceInteger reference = reference_integer(value);

    natrav_canonical_integer_codec_allocation_test::arm();
    const datacube::CanonicalJsonIntegerFragment fragment =
        datacube::canonical_json_integer_fragment(value);
    std::size_t offset = 0U;
    const datacube::JsonIntegerParseResult parsed =
        datacube::parse_json_integer(reference.view(), offset);
    const std::size_t attempts =
        natrav_canonical_integer_codec_allocation_test::attempts;
    natrav_canonical_integer_codec_allocation_test::disarm();

    results.primitive_allocation_attempts += attempts;
    const bool format_exact = fragment.view() == reference.view();
    const bool roundtrip = offset == reference.view().size() &&
        parsed.value == value;
    const bool canonical = parsed.canonical;
    results.format_comparisons += format_exact ? 1U : 0U;
    results.parse_roundtrips += roundtrip ? 1U : 0U;
    results.canonical_token_checks += canonical ? 1U : 0U;
    check(results, format_exact, "independent_integer_spelling");
    check(results, roundtrip, "integer_parse_roundtrip");
    check(results, canonical, "canonical_integer_token");
    check(results, attempts == 0U, "allocation_free_integer_primitive");
}

void integer_corpus(Results& results) {
    static constexpr std::array<std::int64_t, 9U> fixed{{
        std::numeric_limits<std::int64_t>::min(),
        std::numeric_limits<std::int64_t>::min() + 1,
        -1,
        0,
        1,
        9,
        10,
        std::numeric_limits<std::int64_t>::max() - 1,
        std::numeric_limits<std::int64_t>::max(),
    }};
    for (const std::int64_t value : fixed) {
        exercise_integer(results, value, true);
    }

    std::int64_t power = 1;
    while (true) {
        for (const std::int64_t delta : {-1, 0, 1}) {
            const std::int64_t positive = power + delta;
            exercise_integer(results, positive, true);
            if (positive != 0) {
                exercise_integer(results, -positive, true);
            }
        }
        if (power > std::numeric_limits<std::int64_t>::max() / 10) {
            break;
        }
        power *= 10;
    }

    std::uint64_t state = 0x8f3a'12d4'6b7c'9051ULL;
    for (std::size_t index = 0U; index < 131072U; ++index) {
        state = state * 6364136223846793005ULL + 1442695040888963407ULL;
        const std::uint64_t magnitude_bits = state &
            static_cast<std::uint64_t>(
                std::numeric_limits<std::int64_t>::max());
        const std::int64_t magnitude =
            static_cast<std::int64_t>(magnitude_bits);
        const std::int64_t value =
            (state & (std::uint64_t{1} << 63U)) != 0U && magnitude != 0 ?
                -magnitude : magnitude;
        exercise_integer(results, value, false);
    }
}

void noncanonical_cases(Results& results) {
    static constexpr std::array<std::string_view, 2U> cases{{"-0", "-0x"}};
    for (const std::string_view token : cases) {
        ++results.noncanonical_cases;
        std::size_t offset = 0U;
        const datacube::JsonIntegerParseResult parsed =
            datacube::parse_json_integer(token, offset);
        const bool exact = parsed.value == 0 && !parsed.canonical &&
            offset == 2U;
        results.noncanonical_checks += exact ? 1U : 0U;
        check(results, exact, "negative_zero_is_noncanonical");
    }
}

struct MalformedCase final {
    std::string_view token;
    std::string_view code;
};

void malformed_cases(Results& results) {
    static constexpr std::array<MalformedCase, 13U> cases{{
        {"", "natrav-peer-message-json-integer"},
        {"-", "natrav-peer-message-json-integer"},
        {"+1", "natrav-peer-message-json-integer"},
        {"00", "natrav-peer-message-json-leading-zero"},
        {"-00", "natrav-peer-message-json-leading-zero"},
        {"01", "natrav-peer-message-json-leading-zero"},
        {"1.0", "natrav-peer-message-json-floating-point"},
        {"-1e0", "natrav-peer-message-json-floating-point"},
        {"1E0", "natrav-peer-message-json-floating-point"},
        {"9223372036854775808", "natrav-peer-message-json-integer"},
        {"-9223372036854775809", "natrav-peer-message-json-integer"},
        {"18446744073709551615", "natrav-peer-message-json-integer"},
        {"9999999999999999999999999999999999999999",
         "natrav-peer-message-json-integer"},
    }};
    for (const MalformedCase& test : cases) {
        ++results.malformed_cases;
        std::size_t offset = 0U;
        bool matched = false;
        try {
            static_cast<void>(
                datacube::parse_json_integer(test.token, offset));
        } catch (const datacube::Failure& error) {
            matched = error.code() == test.code;
        }
        results.exact_failure_codes += matched ? 1U : 0U;
        check(results, matched, "integer_exact_failure_code");
    }
}

[[nodiscard]] Octets octets(const std::string_view text) {
    Octets output;
    output.reserve(text.size());
    for (const char character : text) {
        output.push_back(static_cast<std::uint8_t>(
            static_cast<unsigned char>(character)));
    }
    return output;
}

[[nodiscard]] std::string error_payload_with_minor(
    const std::string_view minor) {
    std::string result =
        "{\"code\":\"OPERATION_FAILED\",\"kind\":\"ERROR\","
        "\"message\":\"m\",\"protocol\":{\"id\":"
        "\"NATRAV_OVERLAY_PEER\",\"major\":1,\"minor\":";
    result.append(minor);
    result.append(
        "},\"request_id\":"
        "\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"}");
    return result;
}

void classify(
    Results& results,
    const std::string_view payload,
    const NATravPeerMessageDecodeStatus expected) {
    ++results.classification_cases;
    const auto observed = datacube::natrav_peer_decode_message(octets(payload));
    const bool exact = observed.status == expected;
    results.exact_classifications += exact ? 1U : 0U;
    check(results, exact, "integer_classification_priority");
}

void classification_cases(Results& results) {
    classify(
        results,
        error_payload_with_minor("9223372036854775807"),
        NATravPeerMessageDecodeStatus::accepted);
    classify(
        results,
        error_payload_with_minor("-1"),
        NATravPeerMessageDecodeStatus::protocol_mismatch);
    classify(
        results,
        error_payload_with_minor("-9223372036854775808"),
        NATravPeerMessageDecodeStatus::protocol_mismatch);
    classify(
        results,
        error_payload_with_minor("-0"),
        NATravPeerMessageDecodeStatus::noncanonical_json);
    classify(
        results,
        error_payload_with_minor("00"),
        NATravPeerMessageDecodeStatus::malformed_json);
    classify(
        results,
        error_payload_with_minor("9223372036854775808"),
        NATravPeerMessageDecodeStatus::malformed_json);
    classify(
        results,
        error_payload_with_minor("-9223372036854775809"),
        NATravPeerMessageDecodeStatus::malformed_json);
    classify(
        results,
        error_payload_with_minor("1.0"),
        NATravPeerMessageDecodeStatus::malformed_json);
    classify(
        results,
        error_payload_with_minor("1e0"),
        NATravPeerMessageDecodeStatus::malformed_json);
    classify(
        results,
        "-0",
        NATravPeerMessageDecodeStatus::schema_rejected);
    classify(
        results,
        "{\"x\":-0}",
        NATravPeerMessageDecodeStatus::noncanonical_json);
    classify(
        results,
        "{\"x\":00}",
        NATravPeerMessageDecodeStatus::malformed_json);
}

void exception_behavior(Results& results) {
    static_assert(noexcept(
        datacube::canonical_json_integer_fragment(std::int64_t{0})));

    const bool stopped = !datacube::emit_canonical_json_integer(
        std::int64_t{42},
        [](const std::string_view) noexcept { return false; });
    ++results.exception_checks;
    check(results, stopped, "integer_emitter_stop_propagation");

    struct Marker final {};
    bool marker_propagated = false;
    try {
        static_cast<void>(datacube::emit_canonical_json_integer(
            std::numeric_limits<std::int64_t>::min(),
            [](const std::string_view) -> bool { throw Marker{}; }));
    } catch (const Marker&) {
        marker_propagated = true;
    }
    ++results.exception_checks;
    check(results, marker_propagated, "integer_emitter_exception_propagation");
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::int64_t minor) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = minor,
    };
    message.request_id.assign(64U, 'a');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = std::string(64U, 'b'),
            .target = "linux-x86_64",
            .version = "v1",
        };
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            message.required_capabilities = {"ALPHA", "OMEGA_2"};
        } else {
            message.available_capabilities = {"ALPHA", "OMEGA_2"};
        }
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "integer-codec";
    }
    return message;
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

void end_to_end(Results& results) {
    static constexpr std::array<std::int64_t, 3U> minors{{
        0,
        10,
        std::numeric_limits<std::int64_t>::max(),
    }};
    static constexpr std::array<NATravPeerHandshakeMessageKind, 3U> kinds{{
        NATravPeerHandshakeMessageKind::hello,
        NATravPeerHandshakeMessageKind::hello_ack,
        NATravPeerHandshakeMessageKind::error,
    }};
    for (std::size_t index = 0U; index < kinds.size(); ++index) {
        ++results.end_to_end_messages;
        const NATravPeerHandshakeMessage message =
            base_message(kinds[index], minors[index]);

        datacube::reset_canonical_integer_codec_counters();
        const auto encoded = datacube::natrav_peer_encode_message(message);
        const datacube::CanonicalJsonIntegerCodecCounters encoder_counters =
            datacube::read_canonical_integer_codec_counters();
        const bool encoder_integrated =
            encoder_counters.encoder_integer_calls == 4U &&
            encoder_counters.canonical_fragment_calls ==
                encoder_counters.encoder_integer_calls &&
            encoder_counters.json_integer_parse_calls == 0U;
        results.encoder_integration_checks += encoder_integrated ? 1U : 0U;
        check(
            results,
            encoded.status == NATravPeerMessageEncodeStatus::accepted &&
                encoded.payload.has_value() && encoder_integrated,
            "encoder_shared_integer_codec_integration");
        if (!encoded.payload) {
            continue;
        }

        const ReferenceInteger minor = reference_integer(minors[index]);
        const std::string protocol_fragment =
            std::string("\"major\":1,\"minor\":") +
            std::string(minor.view());
        const std::string_view encoded_text(
            reinterpret_cast<const char*>(encoded.payload->data()),
            encoded.payload->size());
        check(
            results,
            encoded_text.find(protocol_fragment) != std::string_view::npos,
            "encoder_exact_integer_spelling");

        datacube::reset_canonical_integer_codec_counters();
        const auto decoded = datacube::natrav_peer_decode_message(
            *encoded.payload);
        const datacube::CanonicalJsonIntegerCodecCounters decoder_counters =
            datacube::read_canonical_integer_codec_counters();
        const bool decoder_integrated =
            decoder_counters.json_integer_parse_calls > 0U &&
            decoder_counters.canonical_fragment_calls ==
                decoder_counters.json_integer_parse_calls &&
            decoder_counters.encoder_integer_calls == 0U;
        results.decoder_integration_checks += decoder_integrated ? 1U : 0U;
        check(
            results,
            decoded.status == NATravPeerMessageDecodeStatus::accepted &&
                decoded.message.has_value() && decoder_integrated,
            "decoder_shared_integer_codec_integration");
        const bool exact = decoded.message &&
            same_message(*decoded.message, message);
        results.exact_message_roundtrips += exact ? 1U : 0U;
        check(results, exact, "end_to_end_integer_message_roundtrip");
    }
}

int run() {
    Results results;
    integer_corpus(results);
    noncanonical_cases(results);
    malformed_cases(results);
    classification_cases(results);
    exception_behavior(results);
    end_to_end(results);
    check(
        results,
        results.format_comparisons == results.integer_cases &&
            results.parse_roundtrips == results.integer_cases &&
            results.canonical_token_checks == results.integer_cases &&
            results.primitive_allocation_attempts == 0U &&
            results.noncanonical_checks == results.noncanonical_cases &&
            results.exact_failure_codes == results.malformed_cases &&
            results.exact_classifications == results.classification_cases &&
            results.exception_checks == 2U &&
            results.exact_message_roundtrips == results.end_to_end_messages &&
            results.encoder_integration_checks == results.end_to_end_messages &&
            results.decoder_integration_checks == results.end_to_end_messages,
        "coverage_and_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(integer_cases);
    PRINT_RESULT(boundary_cases);
    PRINT_RESULT(deterministic_cases);
    PRINT_RESULT(format_comparisons);
    PRINT_RESULT(parse_roundtrips);
    PRINT_RESULT(canonical_token_checks);
    PRINT_RESULT(primitive_allocation_attempts);
    PRINT_RESULT(noncanonical_cases);
    PRINT_RESULT(noncanonical_checks);
    PRINT_RESULT(malformed_cases);
    PRINT_RESULT(exact_failure_codes);
    PRINT_RESULT(classification_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(exception_checks);
    PRINT_RESULT(end_to_end_messages);
    PRINT_RESULT(exact_message_roundtrips);
    PRINT_RESULT(encoder_integration_checks);
    PRINT_RESULT(decoder_integration_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_canonical_integer_codec_test

int main() {
    try {
        return natrav_canonical_integer_codec_test::run();
    } catch (const std::exception& error) {
        natrav_canonical_integer_codec_allocation_test::disarm();
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_CANONICAL_INTEGER_CODEC_TEST

// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_PREFLIGHT_INTEGER_RETENTION_TEST
#include <cstdio>
#include <cstdlib>
#include <new>

namespace natrav_preflight_integer_retention_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t value) noexcept : point(value) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_PREFLIGHT_INTEGER_RETENTION_BAD_ALLOC";
    }
    std::size_t point;
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    std::size_t attempts{0U};
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .attempts = 0U,
    };
}

[[nodiscard]] std::size_t disarm() noexcept {
    const std::size_t attempts = state.attempts;
    state.armed = false;
    return attempts;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.attempts++;
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.attempts++;
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_preflight_integer_retention_allocation_test

void* operator new(const std::size_t size) {
    return natrav_preflight_integer_retention_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_preflight_integer_retention_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_preflight_integer_retention_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_preflight_integer_retention_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_preflight_integer_retention_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_preflight_integer_retention_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_preflight_integer_retention_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_preflight_integer_retention_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_preflight_integer_retention_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_preflight_integer_retention_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_preflight_integer_retention_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_preflight_integer_retention_allocation_test::release(pointer);
}

namespace natrav_preflight_integer_retention_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t current_integer_parse_calls{0U};
    std::size_t historical_integer_parse_calls{0U};
    std::size_t retained_capture_checks{0U};
    std::size_t retained_projection_checks{0U};
    std::size_t historical_reparse_checks{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t allocation_attempts_current{0U};
    std::size_t allocation_attempts_historical{0U};
    std::size_t injected_failure_pairs{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::int64_t minor) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = minor,
    };
    message.request_id.assign(64U, 'a');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = std::string(64U, 'b'),
            .target = "linux-x86_64",
            .version = "v1",
        };
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            message.required_capabilities = {"ALPHA", "OMEGA_2"};
        } else {
            message.available_capabilities = {"ALPHA", "OMEGA_2"};
        }
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "preflight-integer-retention";
    }
    return message;
}

[[nodiscard]] std::string error_payload(
    const std::string_view major,
    const std::string_view minor,
    const std::string_view request_id =
        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa") {
    std::string result =
        "{\"code\":\"TEST\",\"kind\":\"ERROR\",\"message\":\"message\","
        "\"protocol\":{\"id\":\"NATRAV_OVERLAY_PEER\",\"major\":";
    result.append(major);
    result.append(",\"minor\":");
    result.append(minor);
    result.append("},\"request_id\":\"");
    result.append(request_id);
    result.append("\"}");
    return result;
}

void compare_semantics(
    Results& results,
    const Octets& payload,
    const std::optional<NATravPeerMessageDecodeStatus> expected = std::nullopt) {
    const NATravPeerMessageDecodeObservation current =
        datacube::natrav_peer_decode_message(payload);
    const NATravPeerMessageDecodeObservation historical =
        datacube::natrav_peer_decode_message_revision_0474(payload);
    ++results.semantic_cases;
    const bool exact = same_observation(current, historical);
    results.exact_observation_comparisons += exact ? 1U : 0U;
    check(results, exact, "revision_0474_semantic_equivalence");
    results.accepted_cases +=
        current.status == NATravPeerMessageDecodeStatus::accepted ? 1U : 0U;
    results.rejection_cases +=
        current.status == NATravPeerMessageDecodeStatus::accepted ? 0U : 1U;
    if (expected) {
        ++results.classification_priority_cases;
        const bool matched = current.status == *expected &&
            historical.status == *expected;
        results.exact_classifications += matched ? 1U : 0U;
        check(results, matched, "classification_priority_preserved");
    }
}

void accepted_corpus(Results& results) {
    std::vector<std::int64_t> minors{
        0,
        1,
        9,
        10,
        99,
        100,
        999,
        1000,
        9999,
        10000,
        std::numeric_limits<std::int32_t>::max(),
        std::numeric_limits<std::int64_t>::max(),
    };
    std::uint64_t state = 0x6a09e667f3bcc909ULL;
    for (std::size_t index = 0U; index < 256U; ++index) {
        state ^= state << 7U;
        state ^= state >> 9U;
        state ^= state << 8U;
        minors.push_back(static_cast<std::int64_t>(
            state & 0x7fffffffffffffffULL));
    }

    for (const NATravPeerHandshakeMessageKind kind :
         {NATravPeerHandshakeMessageKind::hello,
          NATravPeerHandshakeMessageKind::hello_ack,
          NATravPeerHandshakeMessageKind::error}) {
        for (const std::int64_t minor : minors) {
            const NATravPeerHandshakeMessage message =
                base_message(kind, minor);
            const auto encoded = datacube::natrav_peer_encode_message(message);
            check(
                results,
                encoded.status == NATravPeerMessageEncodeStatus::accepted &&
                    encoded.payload.has_value(),
                "accepted_fixture_encoding");
            if (!encoded.payload) {
                continue;
            }

            datacube::reset_canonical_integer_codec_counters();
            const NATravPeerMessageDecodeObservation current =
                datacube::natrav_peer_decode_message(*encoded.payload);
            const datacube::CanonicalJsonIntegerCodecCounters current_counts =
                datacube::read_canonical_integer_codec_counters();

            datacube::reset_canonical_integer_codec_counters();
            const NATravPeerMessageDecodeObservation historical =
                datacube::natrav_peer_decode_message_revision_0474(
                    *encoded.payload);
            const datacube::CanonicalJsonIntegerCodecCounters historical_counts =
                datacube::read_canonical_integer_codec_counters();

            ++results.semantic_cases;
            ++results.accepted_cases;
            const bool exact = same_observation(current, historical);
            results.exact_observation_comparisons += exact ? 1U : 0U;
            check(results, exact, "accepted_revision_0474_equivalence");

            const bool roundtrip = current.message &&
                same_message(*current.message, message);
            results.exact_roundtrips += roundtrip ? 1U : 0U;
            check(results, roundtrip, "accepted_exact_roundtrip");

            results.current_integer_parse_calls +=
                current_counts.json_integer_parse_calls;
            results.historical_integer_parse_calls +=
                historical_counts.json_integer_parse_calls;

            const bool capture_exact =
                current_counts.preflight_protocol_integer_captures == 2U &&
                historical_counts.preflight_protocol_integer_captures == 2U;
            results.retained_capture_checks += capture_exact ? 1U : 0U;
            check(results, capture_exact, "preflight_integer_capture_exact");

            const bool projection_exact =
                current_counts.json_integer_parse_calls == 2U &&
                current_counts.retained_protocol_integer_reads == 2U;
            results.retained_projection_checks += projection_exact ? 1U : 0U;
            check(results, projection_exact, "retained_integer_projection_exact");

            const bool historical_exact =
                historical_counts.json_integer_parse_calls == 4U &&
                historical_counts.retained_protocol_integer_reads == 0U;
            results.historical_reparse_checks += historical_exact ? 1U : 0U;
            check(results, historical_exact, "historical_integer_reparse_observed");
        }
    }
}

void priority_cases(Results& results) {
    struct Case final {
        std::string payload;
        NATravPeerMessageDecodeStatus status;
    };
    const std::string request_id(64U, 'a');
    std::vector<Case> cases;
    cases.push_back(Case{
        .payload = error_payload("1", "0"),
        .status = NATravPeerMessageDecodeStatus::accepted,
    });
    cases.push_back(Case{
        .payload = error_payload("2", "0"),
        .status = NATravPeerMessageDecodeStatus::protocol_mismatch,
    });
    cases.push_back(Case{
        .payload = error_payload("1", "-1"),
        .status = NATravPeerMessageDecodeStatus::protocol_mismatch,
    });
    cases.push_back(Case{
        .payload = error_payload("\"1\"", "0"),
        .status = NATravPeerMessageDecodeStatus::protocol_mismatch,
    });
    cases.push_back(Case{
        .payload = error_payload("1", "null"),
        .status = NATravPeerMessageDecodeStatus::protocol_mismatch,
    });
    cases.push_back(Case{
        .payload = error_payload("1", "-0"),
        .status = NATravPeerMessageDecodeStatus::noncanonical_json,
    });
    cases.push_back(Case{
        .payload = error_payload("1", "00"),
        .status = NATravPeerMessageDecodeStatus::malformed_json,
    });
    cases.push_back(Case{
        .payload = error_payload("1", "9223372036854775808"),
        .status = NATravPeerMessageDecodeStatus::malformed_json,
    });
    cases.push_back(Case{
        .payload = "[]",
        .status = NATravPeerMessageDecodeStatus::schema_rejected,
    });
    cases.push_back(Case{
        .payload = "{\"x\":0}",
        .status = NATravPeerMessageDecodeStatus::message_kind_rejected,
    });
    cases.push_back(Case{
        .payload = " " + error_payload("1", "0"),
        .status = NATravPeerMessageDecodeStatus::noncanonical_json,
    });
    cases.push_back(Case{
        .payload =
            "{\"code\":\"TEST\",\"kind\":\"ERROR\",\"message\":\"message\","
            "\"protocol\":{\"id\":\"NATRAV_OVERLAY_PEER\",\"major\":1,"
            "\"major\":1,\"minor\":0},\"request_id\":\"" +
            request_id + "\"}",
        .status = NATravPeerMessageDecodeStatus::malformed_json,
    });
    cases.push_back(Case{
        .payload =
            "{\"code\":\"TEST\",\"kind\":\"ERROR\",\"message\":\"message\","
            "\"protocol\":{\"id\":\"NATRAV_OVERLAY_PEER\",\"major\":1,"
            "\"minor\":0,\"zzz\":0},\"request_id\":\"" +
            request_id + "\"}",
        .status = NATravPeerMessageDecodeStatus::protocol_mismatch,
    });
    cases.push_back(Case{
        .payload = error_payload("1", "0", "bad"),
        .status = NATravPeerMessageDecodeStatus::request_id_rejected,
    });

    for (const Case& test : cases) {
        compare_semantics(
            results,
            datacube::text_octets(test.payload),
            test.status);
    }
}

void random_corpus(Results& results) {
    static constexpr std::string_view alphabet =
        "{}[],:\"-0123456789truefalsenull abcdefghijklmnopqrstuvwxyz";
    std::uint64_t state = 0xbb67ae8584caa73bULL;
    for (std::size_t case_index = 0U; case_index < 4096U; ++case_index) {
        state ^= state << 13U;
        state ^= state >> 7U;
        state ^= state << 17U;
        const std::size_t length = 2U +
            static_cast<std::size_t>(state % 127U);
        std::string payload(length, ' ');
        for (char& character : payload) {
            state ^= state << 13U;
            state ^= state >> 7U;
            state ^= state << 17U;
            character = alphabet[static_cast<std::size_t>(
                state % alphabet.size())];
        }
        ++results.random_cases;
        compare_semantics(results, datacube::text_octets(payload));
    }
}

using Decoder = NATravPeerMessageDecodeObservation (*)(datacube::OctetView);

[[nodiscard]] std::size_t measure_allocations(
    const Decoder decoder,
    const Octets& payload,
    NATravPeerMessageDecodeObservation& observation) {
    natrav_preflight_integer_retention_allocation_test::arm();
    observation = decoder(payload);
    return natrav_preflight_integer_retention_allocation_test::disarm();
}

void allocation_scenario(
    Results& results,
    const Octets& payload) {
    ++results.allocation_scenarios;
    NATravPeerMessageDecodeObservation current_baseline;
    NATravPeerMessageDecodeObservation historical_baseline;
    const std::size_t current_attempts = measure_allocations(
        datacube::natrav_peer_decode_message,
        payload,
        current_baseline);
    const std::size_t historical_attempts = measure_allocations(
        datacube::natrav_peer_decode_message_revision_0474,
        payload,
        historical_baseline);
    results.allocation_attempts_current += current_attempts;
    results.allocation_attempts_historical += historical_attempts;
    check(
        results,
        current_attempts == historical_attempts &&
            same_observation(current_baseline, historical_baseline),
        "allocation_baseline_equivalence");

    for (std::size_t point = 0U; point < current_attempts; ++point) {
        const Octets before = payload;
        bool current_type = false;
        bool historical_type = false;
        bool current_ordinal = false;
        bool historical_ordinal = false;

        natrav_preflight_integer_retention_allocation_test::arm(point);
        try {
            static_cast<void>(datacube::natrav_peer_decode_message(payload));
        } catch (const natrav_preflight_integer_retention_allocation_test::InjectedBadAlloc& error) {
            current_type = true;
            current_ordinal = error.point == point;
        } catch (...) {
        }
        static_cast<void>(
            natrav_preflight_integer_retention_allocation_test::disarm());

        natrav_preflight_integer_retention_allocation_test::arm(point);
        try {
            static_cast<void>(
                datacube::natrav_peer_decode_message_revision_0474(payload));
        } catch (const natrav_preflight_integer_retention_allocation_test::InjectedBadAlloc& error) {
            historical_type = true;
            historical_ordinal = error.point == point;
        } catch (...) {
        }
        static_cast<void>(
            natrav_preflight_integer_retention_allocation_test::disarm());

        ++results.injected_failure_pairs;
        results.exception_type_checks +=
            current_type && historical_type ? 1U : 0U;
        results.exception_ordinal_checks +=
            current_ordinal && historical_ordinal ? 1U : 0U;
        check(
            results,
            current_type && historical_type,
            "allocation_exception_type_preserved");
        check(
            results,
            current_ordinal && historical_ordinal,
            "allocation_exception_ordinal_preserved");

        const bool input_preserved = payload == before;
        results.input_preservation_checks += input_preserved ? 2U : 0U;
        check(results, input_preserved, "allocation_input_preserved");

        const NATravPeerMessageDecodeObservation current_retry =
            datacube::natrav_peer_decode_message(payload);
        const NATravPeerMessageDecodeObservation historical_retry =
            datacube::natrav_peer_decode_message_revision_0474(payload);
        const bool retry_exact =
            same_observation(current_retry, current_baseline) &&
            same_observation(historical_retry, historical_baseline) &&
            same_observation(current_retry, historical_retry);
        results.retry_checks += retry_exact ? 2U : 0U;
        check(results, retry_exact, "allocation_retry_exact");
    }
}

void allocation_failures(Results& results) {
    for (const auto& fixture : {
             base_message(NATravPeerHandshakeMessageKind::hello, 0),
             base_message(
                 NATravPeerHandshakeMessageKind::hello_ack,
                 std::numeric_limits<std::int64_t>::max()),
             base_message(NATravPeerHandshakeMessageKind::error, 10)}) {
        const auto encoded = datacube::natrav_peer_encode_message(fixture);
        check(
            results,
            encoded.status == NATravPeerMessageEncodeStatus::accepted &&
                encoded.payload.has_value(),
            "allocation_fixture_encoding");
        if (encoded.payload) {
            allocation_scenario(results, *encoded.payload);
        }
    }
    allocation_scenario(
        results,
        datacube::text_octets(error_payload("2", "0")));
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    random_corpus(results);
    allocation_failures(results);

    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases - 1U &&
            results.retained_capture_checks == results.exact_roundtrips &&
            results.retained_projection_checks == results.exact_roundtrips &&
            results.historical_reparse_checks == results.exact_roundtrips &&
            results.current_integer_parse_calls ==
                results.exact_roundtrips * 2U &&
            results.historical_integer_parse_calls ==
                results.exact_roundtrips * 4U &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.allocation_attempts_current ==
                results.allocation_attempts_historical &&
            results.exception_type_checks == results.injected_failure_pairs &&
            results.exception_ordinal_checks == results.injected_failure_pairs &&
            results.input_preservation_checks ==
                results.injected_failure_pairs * 2U &&
            results.retry_checks == results.injected_failure_pairs * 2U,
        "coverage_and_retention_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(current_integer_parse_calls);
    PRINT_RESULT(historical_integer_parse_calls);
    PRINT_RESULT(retained_capture_checks);
    PRINT_RESULT(retained_projection_checks);
    PRINT_RESULT(historical_reparse_checks);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(allocation_attempts_current);
    PRINT_RESULT(allocation_attempts_historical);
    PRINT_RESULT(injected_failure_pairs);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_preflight_integer_retention_test

int main() {
    try {
        return natrav_preflight_integer_retention_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(
            natrav_preflight_integer_retention_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_PREFLIGHT_INTEGER_RETENTION_TEST

// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_PREFLIGHT_STRING_LENGTH_RETENTION_TEST
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_preflight_string_length_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t injection_point) noexcept :
        point(injection_point) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_PREFLIGHT_STRING_LENGTH_BAD_ALLOC";
    }
    std::size_t point;
};

struct Stats final {
    std::size_t attempts{0U};
    std::size_t total_bytes{0U};
    std::size_t maximum_bytes{0U};
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    Stats stats;
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .stats = {},
    };
}

[[nodiscard]] Stats disarm() noexcept {
    const Stats stats = state.stats;
    state.armed = false;
    return stats;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_preflight_string_length_allocation_test

void* operator new(const std::size_t size) {
    return natrav_preflight_string_length_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_preflight_string_length_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_preflight_string_length_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_preflight_string_length_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_preflight_string_length_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_preflight_string_length_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_preflight_string_length_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_preflight_string_length_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_preflight_string_length_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_preflight_string_length_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_preflight_string_length_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_preflight_string_length_allocation_test::release(pointer);
}

namespace natrav_preflight_string_length_retention_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_preflight_string_length_allocation_test::Stats;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t typed_string_length_capture_checks{0U};
    std::size_t exact_reserve_read_checks{0U};
    std::size_t exact_reserve_byte_checks{0U};
    std::size_t historical_upper_bound_checks{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t current_allocation_attempts{0U};
    std::size_t historical_allocation_attempts{0U};
    std::size_t current_allocated_bytes{0U};
    std::size_t historical_allocated_bytes{0U};
    std::size_t current_maximum_allocation{0U};
    std::size_t historical_maximum_allocation{0U};
    std::size_t allocation_reduction_checks{0U};
    std::size_t injected_current_failures{0U};
    std::size_t injected_historical_failures{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::int64_t minor = 0) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = minor,
    };
    message.request_id.assign(64U, 'a');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = std::string(64U, 'b'),
            .target = "linux-x86_64",
            .version = "v1",
        };
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            message.required_capabilities = {"ALPHA", "OMEGA_2"};
        } else {
            message.available_capabilities = {"ALPHA", "OMEGA_2"};
        }
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "preflight-string-length-retention";
    }
    return message;
}

[[nodiscard]] Octets encode_message(
    Results& results,
    const NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    check(
        results,
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "fixture_encoding");
    return encoded.payload.value_or(Octets{});
}

[[nodiscard]] std::size_t expected_capture_count(
    const NATravPeerHandshakeMessage& message) noexcept {
    if (message.kind == NATravPeerHandshakeMessageKind::error) {
        return 5U;
    }
    const std::size_t capability_count =
        message.kind == NATravPeerHandshakeMessageKind::hello ?
            message.required_capabilities.size() :
            message.available_capabilities.size();
    return 6U + capability_count;
}

[[nodiscard]] std::size_t expected_projection_string_count(
    const NATravPeerHandshakeMessage& message) noexcept {
    return message.kind == NATravPeerHandshakeMessageKind::error ? 1U : 2U;
}

[[nodiscard]] std::size_t expected_projection_decoded_bytes(
    const NATravPeerHandshakeMessage& message) noexcept {
    if (message.kind == NATravPeerHandshakeMessageKind::error) {
        return message.error_message.size();
    }
    return message.artifact.target.size() + message.artifact.version.size();
}

void compare_semantics(
    Results& results,
    const Octets& payload,
    const std::optional<NATravPeerMessageDecodeStatus> expected = std::nullopt) {
    datacube::reset_canonical_string_length_retention_counters();
    const NATravPeerMessageDecodeObservation current =
        datacube::natrav_peer_decode_message(payload);
    const auto current_counters =
        datacube::read_canonical_string_length_retention_counters();

    datacube::reset_canonical_string_length_retention_counters();
    const NATravPeerMessageDecodeObservation historical =
        datacube::natrav_peer_decode_message_revision_0475(payload);
    const auto historical_counters =
        datacube::read_canonical_string_length_retention_counters();

    ++results.semantic_cases;
    const bool equal = same_observation(current, historical);
    results.exact_observation_comparisons += equal ? 1U : 0U;
    check(results, equal, "exact_observation_match");
    if (expected) {
        ++results.classification_priority_cases;
        const bool exact = current.status == *expected;
        results.exact_classifications += exact ? 1U : 0U;
        check(results, exact, "exact_expected_classification");
    }

    if (current.status != NATravPeerMessageDecodeStatus::accepted ||
        !current.message) {
        ++results.rejection_cases;
        check(
            results,
            current_counters.retained_string_length_reads == 0U &&
                historical_counters.historical_string_length_reads == 0U,
            "rejection_no_projection_string_reads");
        return;
    }

    ++results.accepted_cases;
    const NATravPeerHandshakeMessage& message = *current.message;
    const std::size_t captures = expected_capture_count(message);
    const bool capture_ok =
        current_counters.preflight_typed_string_length_captures == captures &&
        historical_counters.preflight_typed_string_length_captures == captures;
    results.typed_string_length_capture_checks += capture_ok ? 1U : 0U;
    check(results, capture_ok, "typed_string_length_capture");

    const std::size_t projection_count =
        expected_projection_string_count(message);
    const bool read_ok =
        current_counters.retained_string_length_reads == projection_count &&
        historical_counters.historical_string_length_reads == projection_count;
    results.exact_reserve_read_checks += read_ok ? 1U : 0U;
    check(results, read_ok, "exact_reserve_read_count");

    const std::size_t decoded_bytes =
        expected_projection_decoded_bytes(message);
    const bool exact_bytes =
        current_counters.retained_string_reserve_bytes == decoded_bytes;
    results.exact_reserve_byte_checks += exact_bytes ? 1U : 0U;
    check(results, exact_bytes, "exact_reserve_bytes");

    const bool historical_bound =
        historical_counters.historical_string_reserve_bytes >= decoded_bytes;
    results.historical_upper_bound_checks += historical_bound ? 1U : 0U;
    check(results, historical_bound, "historical_upper_bound_bytes");

    const auto encoded = datacube::natrav_peer_encode_message(message);
    const bool roundtrip =
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
        encoded.payload && *encoded.payload == payload;
    results.exact_roundtrips += roundtrip ? 1U : 0U;
    check(results, roundtrip, "exact_roundtrip");
}

void accepted_corpus(Results& results) {
    for (const NATravPeerHandshakeMessageKind kind : {
             NATravPeerHandshakeMessageKind::hello,
             NATravPeerHandshakeMessageKind::hello_ack,
             NATravPeerHandshakeMessageKind::error}) {
        compare_semantics(results, encode_message(results, base_message(kind)));
    }

    NATravPeerHandshakeMessage escaped_hello =
        base_message(NATravPeerHandshakeMessageKind::hello, 7);
    escaped_hello.artifact.target = "target\n\"\\\x01\xe2\x82\xac";
    escaped_hello.artifact.version = "version\t\r\x02\xf0\x9f\x98\x80";
    compare_semantics(results, encode_message(results, escaped_hello));

    NATravPeerHandshakeMessage escaped_error =
        base_message(NATravPeerHandshakeMessageKind::error, 19);
    escaped_error.error_message = "message\n\"\\\x01\x02\xe2\x82\xac";
    compare_semantics(results, encode_message(results, escaped_error));

    std::uint64_t state = 0x8d12f3a4b5c697e1ULL;
    for (std::size_t index = 0U; index < 256U; ++index) {
        state ^= state << 13U;
        state ^= state >> 7U;
        state ^= state << 17U;
        NATravPeerHandshakeMessage message = base_message(
            index % 3U == 0U ? NATravPeerHandshakeMessageKind::hello :
            (index % 3U == 1U ? NATravPeerHandshakeMessageKind::hello_ack :
                               NATravPeerHandshakeMessageKind::error),
            static_cast<std::int64_t>(state & 0x7FFFFFFFULL));
        std::string value;
        const std::size_t length = 1U + (index % 127U);
        value.reserve(length * 2U);
        for (std::size_t byte = 0U; byte < length; ++byte) {
            const unsigned selector = static_cast<unsigned>(
                (state + byte * 17U + index * 31U) % 9U);
            switch (selector) {
                case 0U: value.push_back('\x01'); break;
                case 1U: value.push_back('\n'); break;
                case 2U: value.push_back('"'); break;
                case 3U: value.push_back('\\'); break;
                case 4U: value.append("\xe2\x82\xac"); break;
                case 5U: value.append("\xf0\x9f\x98\x80"); break;
                default:
                    value.push_back(static_cast<char>(
                        'a' + static_cast<char>(selector)));
                    break;
            }
        }
        if (message.kind == NATravPeerHandshakeMessageKind::error) {
            message.error_message = value;
        } else {
            message.artifact.target = value;
            message.artifact.version = value + "-v";
        }
        compare_semantics(results, encode_message(results, message));
    }
}

[[nodiscard]] std::string replace_once(
    std::string text,
    const std::string_view from,
    const std::string_view to) {
    const std::size_t position = text.find(from);
    if (position == std::string::npos) {
        throw std::runtime_error("replacement-source-absent");
    }
    text.replace(position, from.size(), to);
    return text;
}

void priority_cases(Results& results) {
    const NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error);
    const Octets base_bytes = encode_message(results, error);
    const std::string base(
        reinterpret_cast<const char*>(base_bytes.data()), base_bytes.size());
    const std::string request_id(64U, 'a');

    const std::vector<std::pair<std::string, NATravPeerMessageDecodeStatus>> cases{
        {"{]", NATravPeerMessageDecodeStatus::malformed_json},
        {"\"root\"", NATravPeerMessageDecodeStatus::schema_rejected},
        {" " + base, NATravPeerMessageDecodeStatus::noncanonical_json},
        {replace_once(base, "preflight-string-length-retention", "bad\\x"),
         NATravPeerMessageDecodeStatus::malformed_json},
        {replace_once(base, "\"ERROR\"", "\"UNKNOWN\""),
         NATravPeerMessageDecodeStatus::message_kind_rejected},
        {replace_once(base, "\"major\":1", "\"major\":2"),
         NATravPeerMessageDecodeStatus::protocol_mismatch},
        {replace_once(base, request_id, std::string(64U, 'g')),
         NATravPeerMessageDecodeStatus::request_id_rejected},
        {replace_once(base, "\"message\":\"preflight-string-length-retention\"",
                            "\"message\":\"\""),
         NATravPeerMessageDecodeStatus::schema_rejected},
        {replace_once(base, "\"minor\":0", "\"minor\":00"),
         NATravPeerMessageDecodeStatus::malformed_json},
        {replace_once(base, ",\"kind\"", ",\"extra\":0,\"kind\""),
         NATravPeerMessageDecodeStatus::schema_rejected},
    };
    for (const auto& item : cases) {
        compare_semantics(
            results, datacube::text_octets(item.first), item.second);
    }

    NATravPeerHandshakeMessage hello =
        base_message(NATravPeerHandshakeMessageKind::hello);
    std::string hello_text;
    {
        const Octets bytes = encode_message(results, hello);
        hello_text.assign(
            reinterpret_cast<const char*>(bytes.data()), bytes.size());
    }
    compare_semantics(
        results,
        datacube::text_octets(replace_once(
            hello_text, std::string(64U, 'b'), std::string(64U, 'g'))),
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);
    compare_semantics(
        results,
        datacube::text_octets(replace_once(
            hello_text, "[\"ALPHA\",\"OMEGA_2\"]",
            "[\"ALPHA\",\"ALPHA\"]")),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected);
}

void random_corpus(Results& results) {
    static constexpr std::string_view alphabet =
        "{}[],:\\\"-0123456789truefalsenullABCDEFGHIJKLMNOPQRSTUVWXYZ_ abcdef";
    std::uint64_t state = 0x4a7c159e3779b97fULL;
    for (std::size_t index = 0U; index < 4096U; ++index) {
        state ^= state << 13U;
        state ^= state >> 7U;
        state ^= state << 17U;
        const std::size_t length = 2U +
            static_cast<std::size_t>(state % 255U);
        std::string payload;
        payload.reserve(length);
        for (std::size_t byte = 0U; byte < length; ++byte) {
            state ^= state << 13U;
            state ^= state >> 7U;
            state ^= state << 17U;
            payload.push_back(alphabet[static_cast<std::size_t>(
                state % alphabet.size())]);
        }
        compare_semantics(results, datacube::text_octets(payload));
        ++results.random_cases;
    }
}

struct Baseline final {
    NATravPeerMessageDecodeObservation observation;
    Stats stats;
};

template <typename Decode>
[[nodiscard]] Baseline baseline_decode(
    const Octets& payload,
    Decode&& decode) {
    natrav_preflight_string_length_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation;
    try {
        observation = decode(payload);
    } catch (...) {
        static_cast<void>(
            natrav_preflight_string_length_allocation_test::disarm());
        throw;
    }
    const Stats stats =
        natrav_preflight_string_length_allocation_test::disarm();
    return Baseline{
        .observation = std::move(observation),
        .stats = stats,
    };
}

template <typename Decode>
void inject_allocation_failures(
    Results& results,
    const Octets& payload,
    const Baseline& baseline,
    Decode&& decode,
    const bool current) {
    for (std::size_t point = 0U; point < baseline.stats.attempts; ++point) {
        const Octets before = payload;
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_preflight_string_length_allocation_test::arm(point);
        try {
            static_cast<void>(decode(payload));
        } catch (const natrav_preflight_string_length_allocation_test::
                     InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        } catch (...) {
        }
        static_cast<void>(
            natrav_preflight_string_length_allocation_test::disarm());
        if (current) {
            ++results.injected_current_failures;
        } else {
            ++results.injected_historical_failures;
        }
        results.exception_type_checks += caught ? 1U : 0U;
        check(results, caught, "allocation_exception_type");
        const bool ordinal = caught_point == point;
        results.exception_ordinal_checks += ordinal ? 1U : 0U;
        check(results, ordinal, "allocation_exception_ordinal");
        const bool preserved = payload == before;
        results.input_preservation_checks += preserved ? 1U : 0U;
        check(results, preserved, "allocation_input_preserved");
        const NATravPeerMessageDecodeObservation retry = decode(payload);
        const bool retry_equal = same_observation(retry, baseline.observation);
        results.retry_checks += retry_equal ? 1U : 0U;
        check(results, retry_equal, "allocation_retry");
    }
}

void allocation_scenario(
    Results& results,
    const Octets& payload,
    const bool require_attempt_reduction,
    const bool require_byte_reduction) {
    ++results.allocation_scenarios;
    const Baseline current = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        });
    const Baseline historical = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0475(bytes);
        });
    check(
        results,
        same_observation(current.observation, historical.observation),
        "allocation_baseline_semantics");
    results.current_allocation_attempts += current.stats.attempts;
    results.historical_allocation_attempts += historical.stats.attempts;
    results.current_allocated_bytes += current.stats.total_bytes;
    results.historical_allocated_bytes += historical.stats.total_bytes;
    results.current_maximum_allocation = std::max(
        results.current_maximum_allocation, current.stats.maximum_bytes);
    results.historical_maximum_allocation = std::max(
        results.historical_maximum_allocation,
        historical.stats.maximum_bytes);

    const bool attempts_ok = !require_attempt_reduction ||
        current.stats.attempts < historical.stats.attempts;
    results.allocation_reduction_checks += attempts_ok ? 1U : 0U;
    check(results, attempts_ok, "allocation_attempt_reduction");
    const bool bytes_ok = !require_byte_reduction ||
        current.stats.total_bytes < historical.stats.total_bytes;
    results.allocation_reduction_checks += bytes_ok ? 1U : 0U;
    check(results, bytes_ok, "allocation_byte_reduction");

    inject_allocation_failures(
        results,
        payload,
        current,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        },
        true);
    inject_allocation_failures(
        results,
        payload,
        historical,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0475(bytes);
        },
        false);
}

void allocation_cases(Results& results) {
    NATravPeerHandshakeMessage small =
        base_message(NATravPeerHandshakeMessageKind::error);
    small.error_message.assign(10U, '\x01');
    allocation_scenario(
        results, encode_message(results, small), true, true);

    NATravPeerHandshakeMessage large =
        base_message(NATravPeerHandshakeMessageKind::error);
    large.error_message.assign(10000U, '\x01');
    allocation_scenario(
        results, encode_message(results, large), false, true);

    NATravPeerHandshakeMessage hello =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    hello.artifact.target.assign(3000U, '\x01');
    hello.artifact.version.assign(2000U, '\n');
    allocation_scenario(
        results, encode_message(results, hello), false, true);
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    random_corpus(results);
    allocation_cases(results);

    const std::size_t injected_total =
        results.injected_current_failures +
        results.injected_historical_failures;
    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.typed_string_length_capture_checks ==
                results.accepted_cases &&
            results.exact_reserve_read_checks == results.accepted_cases &&
            results.exact_reserve_byte_checks == results.accepted_cases &&
            results.historical_upper_bound_checks == results.accepted_cases &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.allocation_reduction_checks ==
                results.allocation_scenarios * 2U &&
            results.exception_type_checks == injected_total &&
            results.exception_ordinal_checks == injected_total &&
            results.input_preservation_checks == injected_total &&
            results.retry_checks == injected_total,
        "coverage_and_string_length_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(typed_string_length_capture_checks);
    PRINT_RESULT(exact_reserve_read_checks);
    PRINT_RESULT(exact_reserve_byte_checks);
    PRINT_RESULT(historical_upper_bound_checks);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(current_allocation_attempts);
    PRINT_RESULT(historical_allocation_attempts);
    PRINT_RESULT(current_allocated_bytes);
    PRINT_RESULT(historical_allocated_bytes);
    PRINT_RESULT(current_maximum_allocation);
    PRINT_RESULT(historical_maximum_allocation);
    PRINT_RESULT(allocation_reduction_checks);
    PRINT_RESULT(injected_current_failures);
    PRINT_RESULT(injected_historical_failures);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_preflight_string_length_retention_test

int main() {
    try {
        return natrav_preflight_string_length_retention_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(
            natrav_preflight_string_length_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_PREFLIGHT_STRING_LENGTH_RETENTION_TEST

// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_PROJECTION_STRING_DECODER_TEST
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_projection_string_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t injection_point) noexcept :
        point(injection_point) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_PROJECTION_STRING_BAD_ALLOC";
    }
    std::size_t point;
};

struct Stats final {
    std::size_t attempts{0U};
    std::size_t total_bytes{0U};
    std::size_t maximum_bytes{0U};
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    Stats stats;
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .stats = {},
    };
}

[[nodiscard]] Stats disarm() noexcept {
    const Stats stats = state.stats;
    state.armed = false;
    return stats;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_projection_string_allocation_test

void* operator new(const std::size_t size) {
    return natrav_projection_string_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_projection_string_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_projection_string_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_projection_string_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_projection_string_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_projection_string_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_projection_string_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_projection_string_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_projection_string_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_projection_string_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_projection_string_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_projection_string_allocation_test::release(pointer);
}

namespace natrav_projection_string_decoder_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_projection_string_allocation_test::Stats;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t projection_fragment_checks{0U};
    std::size_t projection_scalar_parse_checks{0U};
    std::size_t projection_raw_decode_checks{0U};
    std::size_t expected_eliminated_fragment_comparisons{0U};
    std::size_t eliminated_fragment_comparisons{0U};
    std::size_t current_canonical_fragment_calls{0U};
    std::size_t historical_canonical_fragment_calls{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t span_integrity_cases{0U};
    std::size_t span_integrity_checks{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t current_allocation_attempts{0U};
    std::size_t historical_allocation_attempts{0U};
    std::size_t current_allocated_bytes{0U};
    std::size_t historical_allocated_bytes{0U};
    std::size_t current_maximum_allocation{0U};
    std::size_t historical_maximum_allocation{0U};
    std::size_t allocation_equivalence_checks{0U};
    std::size_t injected_current_failures{0U};
    std::size_t injected_historical_failures{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] std::size_t utf8_scalar_count(const std::string_view value) {
    std::size_t count = 0U;
    std::size_t offset = 0U;
    while (offset < value.size()) {
        const unsigned char first =
            static_cast<unsigned char>(value[offset]);
        std::size_t width = 0U;
        if (first <= 0x7FU) {
            width = 1U;
        } else if ((first & 0xE0U) == 0xC0U) {
            width = 2U;
        } else if ((first & 0xF0U) == 0xE0U) {
            width = 3U;
        } else if ((first & 0xF8U) == 0xF0U) {
            width = 4U;
        } else {
            throw std::runtime_error("invalid-fixture-utf8");
        }
        if (offset + width > value.size()) {
            throw std::runtime_error("short-fixture-utf8");
        }
        for (std::size_t index = 1U; index < width; ++index) {
            const unsigned char continuation =
                static_cast<unsigned char>(value[offset + index]);
            if ((continuation & 0xC0U) != 0x80U) {
                throw std::runtime_error("invalid-fixture-continuation");
            }
        }
        offset += width;
        ++count;
    }
    return count;
}

[[nodiscard]] std::size_t projected_scalar_count(
    const NATravPeerHandshakeMessage& message) {
    if (message.kind == NATravPeerHandshakeMessageKind::error) {
        return utf8_scalar_count(message.error_message);
    }
    return utf8_scalar_count(message.artifact.target) +
        utf8_scalar_count(message.artifact.version);
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::int64_t minor = 0) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = minor,
    };
    message.request_id.assign(64U, 'a');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = std::string(64U, 'b'),
            .target = "linux-x86_64",
            .version = "v1",
        };
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            message.required_capabilities = {"ALPHA", "OMEGA_2"};
        } else {
            message.available_capabilities = {"ALPHA", "OMEGA_2"};
        }
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "projection-string-decoder";
    }
    return message;
}

[[nodiscard]] Octets encode_message(
    Results& results,
    const NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    check(
        results,
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "fixture_encoding");
    return encoded.payload.value_or(Octets{});
}

struct CountedDecode final {
    NATravPeerMessageDecodeObservation observation;
    datacube::CanonicalJsonStringCodecCounters counters;
};

[[nodiscard]] CountedDecode current_decode(const Octets& payload) {
    datacube::reset_canonical_string_codec_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters = datacube::read_canonical_string_codec_counters(),
    };
}

[[nodiscard]] CountedDecode historical_decode(const Octets& payload) {
    datacube::reset_canonical_string_codec_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0476(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters = datacube::read_canonical_string_codec_counters(),
    };
}

void compare_semantics(
    Results& results,
    const Octets& payload,
    const std::optional<NATravPeerMessageDecodeStatus> expected = std::nullopt) {
    const CountedDecode current = current_decode(payload);
    const CountedDecode historical = historical_decode(payload);

    ++results.semantic_cases;
    const bool equal = same_observation(
        current.observation, historical.observation);
    results.exact_observation_comparisons += equal ? 1U : 0U;
    check(results, equal, "exact_observation_match");

    if (expected) {
        ++results.classification_priority_cases;
        const bool exact = current.observation.status == *expected;
        results.exact_classifications += exact ? 1U : 0U;
        check(results, exact, "exact_expected_classification");
    }

    results.current_canonical_fragment_calls +=
        current.counters.canonical_fragment_calls;
    results.historical_canonical_fragment_calls +=
        historical.counters.canonical_fragment_calls;

    const bool scalar_parse_equal =
        current.counters.json_scalar_parse_calls ==
        historical.counters.json_scalar_parse_calls;
    results.projection_scalar_parse_checks += scalar_parse_equal ? 1U : 0U;
    check(results, scalar_parse_equal, "projection_scalar_parse_count");

    const bool raw_decode_equal =
        current.counters.raw_scalar_decode_calls ==
        historical.counters.raw_scalar_decode_calls;
    results.projection_raw_decode_checks += raw_decode_equal ? 1U : 0U;
    check(results, raw_decode_equal, "projection_raw_decode_count");

    if (current.observation.status != NATravPeerMessageDecodeStatus::accepted ||
        !current.observation.message) {
        ++results.rejection_cases;
        const bool no_projection_delta =
            current.counters.canonical_fragment_calls ==
            historical.counters.canonical_fragment_calls;
        results.projection_fragment_checks += no_projection_delta ? 1U : 0U;
        check(results, no_projection_delta, "rejection_fragment_equivalence");
        return;
    }

    ++results.accepted_cases;
    const NATravPeerHandshakeMessage& message =
        *current.observation.message;
    const std::size_t expected_delta = projected_scalar_count(message);
    const std::size_t actual_delta =
        historical.counters.canonical_fragment_calls -
        current.counters.canonical_fragment_calls;
    results.expected_eliminated_fragment_comparisons += expected_delta;
    results.eliminated_fragment_comparisons += actual_delta;
    const bool fragment_delta = actual_delta == expected_delta &&
        expected_delta > 0U;
    results.projection_fragment_checks += fragment_delta ? 1U : 0U;
    check(results, fragment_delta, "projection_fragment_elimination");

    const auto encoded = datacube::natrav_peer_encode_message(message);
    const bool roundtrip =
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
        encoded.payload && *encoded.payload == payload;
    results.exact_roundtrips += roundtrip ? 1U : 0U;
    check(results, roundtrip, "exact_roundtrip");
}

void accepted_corpus(Results& results) {
    for (const NATravPeerHandshakeMessageKind kind : {
             NATravPeerHandshakeMessageKind::hello,
             NATravPeerHandshakeMessageKind::hello_ack,
             NATravPeerHandshakeMessageKind::error}) {
        compare_semantics(results, encode_message(results, base_message(kind)));
    }

    NATravPeerHandshakeMessage escaped_hello =
        base_message(NATravPeerHandshakeMessageKind::hello, 7);
    escaped_hello.artifact.target = "target\n\"\\\x01\xe2\x82\xac";
    escaped_hello.artifact.version = "version\t\r\x02\xf0\x9f\x98\x80";
    compare_semantics(results, encode_message(results, escaped_hello));

    NATravPeerHandshakeMessage escaped_error =
        base_message(NATravPeerHandshakeMessageKind::error, 19);
    escaped_error.error_message = "message\n\"\\\x01\x02\xe2\x82\xac";
    compare_semantics(results, encode_message(results, escaped_error));

    std::uint64_t state = 0x6a09e667f3bcc909ULL;
    for (std::size_t index = 0U; index < 256U; ++index) {
        state ^= state << 13U;
        state ^= state >> 7U;
        state ^= state << 17U;
        NATravPeerHandshakeMessage message = base_message(
            index % 3U == 0U ? NATravPeerHandshakeMessageKind::hello :
            (index % 3U == 1U ? NATravPeerHandshakeMessageKind::hello_ack :
                               NATravPeerHandshakeMessageKind::error),
            static_cast<std::int64_t>(state & 0x7FFFFFFFULL));
        std::string value;
        const std::size_t length = 1U + (index % 127U);
        value.reserve(length * 2U);
        for (std::size_t byte = 0U; byte < length; ++byte) {
            const unsigned selector = static_cast<unsigned>(
                (state + byte * 17U + index * 31U) % 9U);
            switch (selector) {
                case 0U: value.push_back('\x01'); break;
                case 1U: value.push_back('\n'); break;
                case 2U: value.push_back('"'); break;
                case 3U: value.push_back('\\'); break;
                case 4U: value.append("\xe2\x82\xac"); break;
                case 5U: value.append("\xf0\x9f\x98\x80"); break;
                default:
                    value.push_back(static_cast<char>(
                        'a' + static_cast<char>(selector)));
                    break;
            }
        }
        if (message.kind == NATravPeerHandshakeMessageKind::error) {
            message.error_message = value;
        } else {
            message.artifact.target = value;
            message.artifact.version = value + "-v";
        }
        compare_semantics(results, encode_message(results, message));
    }
}

[[nodiscard]] std::string replace_once(
    std::string text,
    const std::string_view from,
    const std::string_view to) {
    const std::size_t position = text.find(from);
    if (position == std::string::npos) {
        throw std::runtime_error("replacement-source-absent");
    }
    text.replace(position, from.size(), to);
    return text;
}

void priority_cases(Results& results) {
    const NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error);
    const Octets base_bytes = encode_message(results, error);
    const std::string base(
        reinterpret_cast<const char*>(base_bytes.data()), base_bytes.size());
    const std::string request_id(64U, 'a');

    const std::vector<std::pair<std::string, NATravPeerMessageDecodeStatus>> cases{
        {"{]", NATravPeerMessageDecodeStatus::malformed_json},
        {"\"root\"", NATravPeerMessageDecodeStatus::schema_rejected},
        {" " + base, NATravPeerMessageDecodeStatus::noncanonical_json},
        {replace_once(base, "projection-string-decoder", "bad\\x"),
         NATravPeerMessageDecodeStatus::malformed_json},
        {replace_once(base, "\"ERROR\"", "\"UNKNOWN\""),
         NATravPeerMessageDecodeStatus::message_kind_rejected},
        {replace_once(base, "\"major\":1", "\"major\":2"),
         NATravPeerMessageDecodeStatus::protocol_mismatch},
        {replace_once(base, request_id, std::string(64U, 'g')),
         NATravPeerMessageDecodeStatus::request_id_rejected},
        {replace_once(base, "\"message\":\"projection-string-decoder\"",
                            "\"message\":\"\""),
         NATravPeerMessageDecodeStatus::schema_rejected},
        {replace_once(base, "\"minor\":0", "\"minor\":00"),
         NATravPeerMessageDecodeStatus::malformed_json},
        {replace_once(base, ",\"kind\"", ",\"extra\":0,\"kind\""),
         NATravPeerMessageDecodeStatus::schema_rejected},
    };
    for (const auto& item : cases) {
        compare_semantics(
            results, datacube::text_octets(item.first), item.second);
    }

    NATravPeerHandshakeMessage hello =
        base_message(NATravPeerHandshakeMessageKind::hello);
    std::string hello_text;
    {
        const Octets bytes = encode_message(results, hello);
        hello_text.assign(
            reinterpret_cast<const char*>(bytes.data()), bytes.size());
    }
    compare_semantics(
        results,
        datacube::text_octets(replace_once(
            hello_text, std::string(64U, 'b'), std::string(64U, 'g'))),
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);
    compare_semantics(
        results,
        datacube::text_octets(replace_once(
            hello_text, "[\"ALPHA\",\"OMEGA_2\"]",
            "[\"ALPHA\",\"ALPHA\"]")),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected);
}

void random_corpus(Results& results) {
    static constexpr std::string_view alphabet =
        "{}[],:\\\"-0123456789truefalsenullABCDEFGHIJKLMNOPQRSTUVWXYZ_ abcdef";
    std::uint64_t state = 0xbb67ae8584caa73bULL;
    for (std::size_t index = 0U; index < 4096U; ++index) {
        state ^= state << 13U;
        state ^= state >> 7U;
        state ^= state << 17U;
        const std::size_t length = 2U +
            static_cast<std::size_t>(state % 255U);
        std::string payload;
        payload.reserve(length);
        for (std::size_t byte = 0U; byte < length; ++byte) {
            state ^= state << 13U;
            state ^= state >> 7U;
            state ^= state << 17U;
            payload.push_back(alphabet[static_cast<std::size_t>(
                state % alphabet.size())]);
        }
        compare_semantics(results, datacube::text_octets(payload));
        ++results.random_cases;
    }
}

[[nodiscard]] std::optional<std::string> failure_code(
    const datacube::CanonicalJsonSpan span,
    const bool historical) {
    try {
        if (historical) {
            static_cast<void>(
                datacube::decode_canonical_string_revision_0476(span));
        } else {
            static_cast<void>(datacube::decode_canonical_string(span));
        }
    } catch (const datacube::Failure& error) {
        return error.code();
    }
    return std::nullopt;
}

void span_integrity_cases(Results& results) {
    const std::string token = "\"A\\n\\u0001\xe2\x82\xac\"";
    const std::string expected = "A\n\x01\xe2\x82\xac";
    const datacube::CanonicalJsonSpan valid{
        .kind = datacube::JsonValue::Kind::string,
        .bytes = token,
        .decoded_string_bytes = expected.size(),
    };
    datacube::reset_canonical_string_codec_counters();
    const std::string current = datacube::decode_canonical_string(valid);
    const auto current_counters =
        datacube::read_canonical_string_codec_counters();
    datacube::reset_canonical_string_codec_counters();
    const std::string historical =
        datacube::decode_canonical_string_revision_0476(valid);
    const auto historical_counters =
        datacube::read_canonical_string_codec_counters();
    ++results.span_integrity_cases;
    const bool valid_output = current == expected && historical == expected;
    results.span_integrity_checks += valid_output ? 1U : 0U;
    check(results, valid_output, "direct_projection_output");
    const std::size_t scalar_count = utf8_scalar_count(expected);
    const bool direct_fragments =
        current_counters.canonical_fragment_calls == 0U &&
        historical_counters.canonical_fragment_calls == scalar_count;
    results.span_integrity_checks += direct_fragments ? 1U : 0U;
    check(results, direct_fragments, "direct_projection_fragments");
    const bool direct_parses =
        current_counters.json_scalar_parse_calls ==
        historical_counters.json_scalar_parse_calls;
    results.span_integrity_checks += direct_parses ? 1U : 0U;
    check(results, direct_parses, "direct_projection_parses");

    const std::array<datacube::CanonicalJsonSpan, 3U> invalid{
        datacube::CanonicalJsonSpan{
            .kind = datacube::JsonValue::Kind::string,
            .bytes = "\"ok\"x",
            .decoded_string_bytes = 2U,
        },
        datacube::CanonicalJsonSpan{
            .kind = datacube::JsonValue::Kind::string,
            .bytes = "\"ok\"",
            .decoded_string_bytes = 3U,
        },
        datacube::CanonicalJsonSpan{
            .kind = datacube::JsonValue::Kind::string,
            .bytes = "\"bad\\x\"",
            .decoded_string_bytes = 3U,
        },
    };
    const std::array<std::string_view, 3U> expected_codes{
        "natrav-peer-message-canonical-string-span",
        "natrav-peer-message-canonical-string-span",
        "natrav-peer-message-json-string-escape",
    };
    for (std::size_t index = 0U; index < invalid.size(); ++index) {
        ++results.span_integrity_cases;
        const auto current_code = failure_code(invalid[index], false);
        const auto historical_code = failure_code(invalid[index], true);
        const bool exact = current_code && historical_code &&
            *current_code == expected_codes[index] &&
            *historical_code == expected_codes[index];
        results.span_integrity_checks += exact ? 1U : 0U;
        check(results, exact, "span_integrity_failure_code");
    }
}

struct Baseline final {
    NATravPeerMessageDecodeObservation observation;
    Stats stats;
};

template <typename Decode>
[[nodiscard]] Baseline baseline_decode(
    const Octets& payload,
    Decode&& decode) {
    natrav_projection_string_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation;
    try {
        observation = decode(payload);
    } catch (...) {
        static_cast<void>(
            natrav_projection_string_allocation_test::disarm());
        throw;
    }
    const Stats stats = natrav_projection_string_allocation_test::disarm();
    return Baseline{
        .observation = std::move(observation),
        .stats = stats,
    };
}

template <typename Decode>
void inject_allocation_failures(
    Results& results,
    const Octets& payload,
    const Baseline& baseline,
    Decode&& decode,
    const bool current) {
    for (std::size_t point = 0U; point < baseline.stats.attempts; ++point) {
        const Octets before = payload;
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_projection_string_allocation_test::arm(point);
        try {
            static_cast<void>(decode(payload));
        } catch (const natrav_projection_string_allocation_test::
                     InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        } catch (...) {
        }
        static_cast<void>(natrav_projection_string_allocation_test::disarm());
        if (current) {
            ++results.injected_current_failures;
        } else {
            ++results.injected_historical_failures;
        }
        results.exception_type_checks += caught ? 1U : 0U;
        check(results, caught, "allocation_exception_type");
        const bool ordinal = caught_point == point;
        results.exception_ordinal_checks += ordinal ? 1U : 0U;
        check(results, ordinal, "allocation_exception_ordinal");
        const bool preserved = payload == before;
        results.input_preservation_checks += preserved ? 1U : 0U;
        check(results, preserved, "allocation_input_preserved");
        const NATravPeerMessageDecodeObservation retry = decode(payload);
        const bool retry_equal = same_observation(retry, baseline.observation);
        results.retry_checks += retry_equal ? 1U : 0U;
        check(results, retry_equal, "allocation_retry");
    }
}

void allocation_scenario(Results& results, const Octets& payload) {
    ++results.allocation_scenarios;
    const Baseline current = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        });
    const Baseline historical = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0476(bytes);
        });
    check(
        results,
        same_observation(current.observation, historical.observation),
        "allocation_baseline_semantics");
    results.current_allocation_attempts += current.stats.attempts;
    results.historical_allocation_attempts += historical.stats.attempts;
    results.current_allocated_bytes += current.stats.total_bytes;
    results.historical_allocated_bytes += historical.stats.total_bytes;
    results.current_maximum_allocation = std::max(
        results.current_maximum_allocation, current.stats.maximum_bytes);
    results.historical_maximum_allocation = std::max(
        results.historical_maximum_allocation,
        historical.stats.maximum_bytes);

    const bool attempts_equal =
        current.stats.attempts == historical.stats.attempts;
    results.allocation_equivalence_checks += attempts_equal ? 1U : 0U;
    check(results, attempts_equal, "allocation_attempt_equivalence");
    const bool bytes_equal =
        current.stats.total_bytes == historical.stats.total_bytes;
    results.allocation_equivalence_checks += bytes_equal ? 1U : 0U;
    check(results, bytes_equal, "allocation_byte_equivalence");
    const bool maximum_equal =
        current.stats.maximum_bytes == historical.stats.maximum_bytes;
    results.allocation_equivalence_checks += maximum_equal ? 1U : 0U;
    check(results, maximum_equal, "allocation_maximum_equivalence");

    inject_allocation_failures(
        results,
        payload,
        current,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        },
        true);
    inject_allocation_failures(
        results,
        payload,
        historical,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0476(bytes);
        },
        false);
}

void allocation_cases(Results& results) {
    NATravPeerHandshakeMessage escaped =
        base_message(NATravPeerHandshakeMessageKind::error);
    escaped.error_message.assign(10000U, '\x01');
    allocation_scenario(results, encode_message(results, escaped));

    NATravPeerHandshakeMessage unicode =
        base_message(NATravPeerHandshakeMessageKind::error);
    unicode.error_message.clear();
    for (std::size_t index = 0U; index < 2000U; ++index) {
        unicode.error_message.append("\xe2\x82\xac");
    }
    allocation_scenario(results, encode_message(results, unicode));

    NATravPeerHandshakeMessage hello =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    hello.artifact.target.assign(3000U, '\x01');
    hello.artifact.version.assign(2000U, '\n');
    allocation_scenario(results, encode_message(results, hello));
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    random_corpus(results);
    span_integrity_cases(results);
    allocation_cases(results);

    const std::size_t injected_total =
        results.injected_current_failures +
        results.injected_historical_failures;
    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.projection_fragment_checks == results.semantic_cases &&
            results.projection_scalar_parse_checks == results.semantic_cases &&
            results.projection_raw_decode_checks == results.semantic_cases &&
            results.eliminated_fragment_comparisons ==
                results.expected_eliminated_fragment_comparisons &&
            results.eliminated_fragment_comparisons > 0U &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.span_integrity_cases == 4U &&
            results.span_integrity_checks == 6U &&
            results.allocation_equivalence_checks ==
                results.allocation_scenarios * 3U &&
            results.exception_type_checks == injected_total &&
            results.exception_ordinal_checks == injected_total &&
            results.input_preservation_checks == injected_total &&
            results.retry_checks == injected_total,
        "coverage_and_projection_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(projection_fragment_checks);
    PRINT_RESULT(projection_scalar_parse_checks);
    PRINT_RESULT(projection_raw_decode_checks);
    PRINT_RESULT(expected_eliminated_fragment_comparisons);
    PRINT_RESULT(eliminated_fragment_comparisons);
    PRINT_RESULT(current_canonical_fragment_calls);
    PRINT_RESULT(historical_canonical_fragment_calls);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(span_integrity_cases);
    PRINT_RESULT(span_integrity_checks);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(current_allocation_attempts);
    PRINT_RESULT(historical_allocation_attempts);
    PRINT_RESULT(current_allocated_bytes);
    PRINT_RESULT(historical_allocated_bytes);
    PRINT_RESULT(current_maximum_allocation);
    PRINT_RESULT(historical_maximum_allocation);
    PRINT_RESULT(allocation_equivalence_checks);
    PRINT_RESULT(injected_current_failures);
    PRINT_RESULT(injected_historical_failures);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_projection_string_decoder_test

int main() {
    try {
        return natrav_projection_string_decoder_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(natrav_projection_string_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_PROJECTION_STRING_DECODER_TEST

// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_RETENTION_TEST
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_capability_span_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t injection_point) noexcept :
        point(injection_point) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_CAPABILITY_SPAN_BAD_ALLOC";
    }
    std::size_t point;
};

struct Stats final {
    std::size_t attempts{0U};
    std::size_t total_bytes{0U};
    std::size_t maximum_bytes{0U};
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    Stats stats;
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .stats = {},
    };
}

[[nodiscard]] Stats disarm() noexcept {
    const Stats stats = state.stats;
    state.armed = false;
    return stats;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_capability_span_allocation_test

void* operator new(const std::size_t size) {
    return natrav_capability_span_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_capability_span_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_capability_span_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_capability_span_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_capability_span_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_capability_span_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_span_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_span_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_span_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_span_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_span_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_span_allocation_test::release(pointer);
}

namespace natrav_capability_span_retention_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_capability_span_allocation_test::Stats;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t expected_capability_entries{0U};
    std::size_t retained_capability_reads{0U};
    std::size_t eliminated_array_reparse_entries{0U};
    std::size_t preflight_capture_checks{0U};
    std::size_t retained_projection_checks{0U};
    std::size_t historical_reparse_checks{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t span_integrity_cases{0U};
    std::size_t span_integrity_checks{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t current_allocation_attempts{0U};
    std::size_t historical_allocation_attempts{0U};
    std::size_t current_allocated_bytes{0U};
    std::size_t historical_allocated_bytes{0U};
    std::size_t current_maximum_allocation{0U};
    std::size_t historical_maximum_allocation{0U};
    std::size_t allocation_equivalence_checks{0U};
    std::size_t injected_current_failures{0U};
    std::size_t injected_historical_failures{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::int64_t minor = 0) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = minor,
    };
    message.request_id.assign(64U, 'a');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = std::string(64U, 'b'),
            .target = "linux-x86_64",
            .version = "v1",
        };
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "capability-span-retention";
    }
    return message;
}

[[nodiscard]] std::string capability_name(
    const std::size_t index,
    const bool long_form = false) {
    std::string digits = std::to_string(index);
    if (digits.size() > 4U) {
        throw std::runtime_error("capability-index-range");
    }
    std::string token = "C";
    token.append(4U - digits.size(), '0');
    token.append(digits);
    if (long_form) {
        token.append(64U - token.size(), 'X');
    }
    return token;
}

[[nodiscard]] Octets encode_message(
    Results& results,
    const NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    check(
        results,
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "fixture_encoding");
    return encoded.payload.value_or(Octets{});
}

[[nodiscard]] std::size_t capability_count(
    const NATravPeerHandshakeMessage& message) noexcept {
    if (message.kind == NATravPeerHandshakeMessageKind::hello) {
        return message.required_capabilities.size();
    }
    if (message.kind == NATravPeerHandshakeMessageKind::hello_ack) {
        return message.available_capabilities.size();
    }
    return 0U;
}

struct CountedDecode final {
    NATravPeerMessageDecodeObservation observation;
    datacube::CanonicalCapabilitySpanRetentionCounters counters;
};

[[nodiscard]] CountedDecode current_decode(const Octets& payload) {
    datacube::reset_canonical_capability_span_retention_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_capability_span_retention_counters(),
    };
}

[[nodiscard]] CountedDecode historical_decode(const Octets& payload) {
    datacube::reset_canonical_capability_span_retention_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0477(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_capability_span_retention_counters(),
    };
}

void compare_semantics(
    Results& results,
    const Octets& payload,
    const std::optional<NATravPeerMessageDecodeStatus> expected = std::nullopt) {
    const CountedDecode current = current_decode(payload);
    const CountedDecode historical = historical_decode(payload);
    ++results.semantic_cases;
    const bool equal = same_observation(
        current.observation, historical.observation);
    results.exact_observation_comparisons += equal ? 1U : 0U;
    check(results, equal, "exact_observation_match");

    if (expected) {
        ++results.classification_priority_cases;
        const bool exact = current.observation.status == *expected;
        results.exact_classifications += exact ? 1U : 0U;
        check(results, exact, "exact_expected_classification");
    }

    if (current.observation.status != NATravPeerMessageDecodeStatus::accepted ||
        !current.observation.message) {
        ++results.rejection_cases;
        return;
    }

    ++results.accepted_cases;
    const std::size_t expected_entries =
        capability_count(*current.observation.message);
    results.expected_capability_entries += expected_entries;
    results.retained_capability_reads +=
        current.counters.retained_projection_reads;
    results.eliminated_array_reparse_entries +=
        historical.counters.historical_array_reparse_entries;

    const bool capture_exact =
        current.counters.preflight_span_captures == expected_entries &&
        historical.counters.preflight_span_captures == expected_entries;
    results.preflight_capture_checks += capture_exact ? 1U : 0U;
    check(results, capture_exact, "preflight_span_capture");

    const bool retained_exact =
        current.counters.retained_projection_reads == expected_entries &&
        current.counters.historical_array_reparse_entries == 0U;
    results.retained_projection_checks += retained_exact ? 1U : 0U;
    check(results, retained_exact, "retained_projection");

    const bool historical_exact =
        historical.counters.retained_projection_reads == 0U &&
        historical.counters.historical_array_reparse_entries ==
            expected_entries;
    results.historical_reparse_checks += historical_exact ? 1U : 0U;
    check(results, historical_exact, "historical_array_reparse");

    const auto encoded = datacube::natrav_peer_encode_message(
        *current.observation.message);
    const bool roundtrip =
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
        encoded.payload && *encoded.payload == payload;
    results.exact_roundtrips += roundtrip ? 1U : 0U;
    check(results, roundtrip, "exact_roundtrip");
}

void accepted_corpus(Results& results) {
    NATravPeerHandshakeMessage hello =
        base_message(NATravPeerHandshakeMessageKind::hello);
    compare_semantics(results, encode_message(results, hello));

    hello.required_capabilities = {"A", "B_2", "OMEGA"};
    compare_semantics(results, encode_message(results, hello));

    NATravPeerHandshakeMessage ack =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 7);
    ack.available_capabilities = {"A", "B_2", "OMEGA"};
    compare_semantics(results, encode_message(results, ack));

    NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error, 19);
    compare_semantics(results, encode_message(results, error));

    NATravPeerHandshakeMessage large =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 23);
    large.available_capabilities.reserve(7000U);
    for (std::size_t index = 0U; index < 7000U; ++index) {
        large.available_capabilities.push_back(capability_name(index));
    }
    compare_semantics(results, encode_message(results, large));

    for (std::size_t fixture = 0U; fixture < 128U; ++fixture) {
        const NATravPeerHandshakeMessageKind kind = fixture % 2U == 0U ?
            NATravPeerHandshakeMessageKind::hello :
            NATravPeerHandshakeMessageKind::hello_ack;
        NATravPeerHandshakeMessage message = base_message(
            kind, static_cast<std::int64_t>(fixture));
        const std::size_t count = fixture % 33U;
        std::vector<std::string>& capabilities =
            kind == NATravPeerHandshakeMessageKind::hello ?
                message.required_capabilities :
                message.available_capabilities;
        capabilities.reserve(count);
        for (std::size_t index = 0U; index < count; ++index) {
            capabilities.push_back(capability_name(index));
        }
        compare_semantics(results, encode_message(results, message));
    }
}

[[nodiscard]] std::string payload_text(const Octets& payload) {
    std::string text;
    text.reserve(payload.size());
    for (const std::uint8_t byte : payload) {
        text.push_back(static_cast<char>(byte));
    }
    return text;
}

[[nodiscard]] Octets payload_bytes(const std::string_view text) {
    Octets payload;
    payload.reserve(text.size());
    for (const char character : text) {
        payload.push_back(static_cast<std::uint8_t>(
            static_cast<unsigned char>(character)));
    }
    return payload;
}

[[nodiscard]] Octets replace_once(
    const Octets& payload,
    const std::string_view before,
    const std::string_view after) {
    std::string text = payload_text(payload);
    const std::size_t offset = text.find(before);
    if (offset == std::string::npos) {
        throw std::runtime_error("fixture-replacement-missing");
    }
    text.replace(offset, before.size(), after);
    return payload_bytes(text);
}

void priority_cases(Results& results) {
    NATravPeerHandshakeMessage message =
        base_message(NATravPeerHandshakeMessageKind::hello);
    message.required_capabilities = {"A", "B"};
    const Octets valid = encode_message(results, message);

    compare_semantics(
        results,
        replace_once(valid, "[\"A\",\"B\"]", "[\"B\",\"A\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected);
    compare_semantics(
        results,
        replace_once(valid, "[\"A\",\"B\"]", "[\"A\",\"A\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected);
    compare_semantics(
        results,
        replace_once(valid, "[\"A\",\"B\"]", "[\"A\",1]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected);
    compare_semantics(
        results,
        replace_once(valid, "\"major\":1", "\"major\":2"),
        NATravPeerMessageDecodeStatus::protocol_mismatch);
    compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'a'), std::string(64U, 'z')),
        NATravPeerMessageDecodeStatus::request_id_rejected);
    compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'b'),
                     std::string("z") + std::string(63U, 'b')),
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);
    compare_semantics(
        results,
        replace_once(valid, "\"HELLO\"", "\"OTHER\""),
        NATravPeerMessageDecodeStatus::message_kind_rejected);
    compare_semantics(
        results,
        replace_once(valid, "},\"kind\":", "},\"extra\":0,\"kind\":"),
        NATravPeerMessageDecodeStatus::schema_rejected);

    std::string malformed = payload_text(valid);
    malformed.pop_back();
    compare_semantics(
        results,
        payload_bytes(malformed),
        NATravPeerMessageDecodeStatus::malformed_json);
    compare_semantics(
        results,
        payload_bytes(std::string(" ") + payload_text(valid)),
        NATravPeerMessageDecodeStatus::noncanonical_json);
    compare_semantics(
        results,
        payload_bytes("[]"),
        NATravPeerMessageDecodeStatus::schema_rejected);
}

void random_corpus(Results& results) {
    std::uint64_t state = 0x9e3779b97f4a7c15ULL;
    for (std::size_t fixture = 0U; fixture < 4096U; ++fixture) {
        state ^= state << 13U;
        state ^= state >> 7U;
        state ^= state << 17U;
        const std::size_t length = 2U +
            static_cast<std::size_t>(state % 191U);
        Octets payload;
        payload.reserve(length);
        for (std::size_t index = 0U; index < length; ++index) {
            state ^= state << 13U;
            state ^= state >> 7U;
            state ^= state << 17U;
            payload.push_back(static_cast<std::uint8_t>(state & 0xFFU));
        }
        compare_semantics(results, payload);
        ++results.random_cases;
    }
}

void span_integrity_cases(Results& results) {
    const std::string text = "[\"A\",\"B\"]";
    const datacube::CanonicalJsonSpan array_value{
        .kind = datacube::JsonValue::Kind::array,
        .bytes = text,
        .decoded_string_bytes = std::nullopt,
    };
    datacube::CanonicalCapabilityFieldIndex index{
        .array_seen = true,
        .valid = true,
        .spans_complete = true,
        .count = 2U,
        .span_begin = 0U,
        .span_count = 2U,
        .previous = "B",
        .ready = true,
    };
    datacube::CanonicalCapabilityEntrySpanStorage spans;
    static_cast<void>(spans.append(datacube::CanonicalCapabilityEntrySpan{
        .content_offset = 2U,
        .content_size = 1U,
    }));
    static_cast<void>(spans.append(datacube::CanonicalCapabilityEntrySpan{
        .content_offset = 6U,
        .content_size = 1U,
    }));

    ++results.span_integrity_cases;
    const std::vector<std::string> decoded =
        datacube::decode_indexed_capabilities(
            text, array_value, index, spans);
    const bool valid = decoded == std::vector<std::string>{"A", "B"};
    results.span_integrity_checks += valid ? 1U : 0U;
    check(results, valid, "direct_span_projection");

    const std::array<std::uint16_t, 3U> invalid_offsets{1U, 5U, 9U};
    for (const std::uint16_t invalid_offset : invalid_offsets) {
        ++results.span_integrity_cases;
        datacube::CanonicalCapabilityEntrySpanStorage invalid;
        static_cast<void>(invalid.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = 2U,
                .content_size = 1U,
            }));
        static_cast<void>(invalid.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = invalid_offset,
                .content_size = 1U,
            }));
        bool exact = false;
        try {
            static_cast<void>(datacube::decode_indexed_capabilities(
                text, array_value, index, invalid));
        } catch (const datacube::Failure& error) {
            exact = error.code() ==
                "natrav-peer-message-indexed-capability-span";
        }
        results.span_integrity_checks += exact ? 1U : 0U;
        check(results, exact, "direct_span_integrity_failure");
    }
}

struct Baseline final {
    NATravPeerMessageDecodeObservation observation;
    Stats stats;
};

template <typename Decode>
[[nodiscard]] Baseline baseline_decode(
    const Octets& payload,
    Decode&& decode) {
    natrav_capability_span_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation;
    try {
        observation = decode(payload);
    } catch (...) {
        static_cast<void>(
            natrav_capability_span_allocation_test::disarm());
        throw;
    }
    const Stats stats = natrav_capability_span_allocation_test::disarm();
    return Baseline{
        .observation = std::move(observation),
        .stats = stats,
    };
}

template <typename Decode>
void inject_allocation_failures(
    Results& results,
    const Octets& payload,
    const Baseline& baseline,
    Decode&& decode,
    const bool current) {
    for (std::size_t point = 0U; point < baseline.stats.attempts; ++point) {
        const Octets before = payload;
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_capability_span_allocation_test::arm(point);
        try {
            static_cast<void>(decode(payload));
        } catch (const natrav_capability_span_allocation_test::
                     InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        } catch (...) {
        }
        static_cast<void>(
            natrav_capability_span_allocation_test::disarm());
        if (current) {
            ++results.injected_current_failures;
        } else {
            ++results.injected_historical_failures;
        }
        results.exception_type_checks += caught ? 1U : 0U;
        check(results, caught, "allocation_exception_type");
        const bool ordinal = caught_point == point;
        results.exception_ordinal_checks += ordinal ? 1U : 0U;
        check(results, ordinal, "allocation_exception_ordinal");
        const bool preserved = payload == before;
        results.input_preservation_checks += preserved ? 1U : 0U;
        check(results, preserved, "allocation_input_preserved");
        const NATravPeerMessageDecodeObservation retry = decode(payload);
        const bool retry_equal = same_observation(retry, baseline.observation);
        results.retry_checks += retry_equal ? 1U : 0U;
        check(results, retry_equal, "allocation_retry");
    }
}

void allocation_scenario(Results& results, const Octets& payload) {
    ++results.allocation_scenarios;
    const Baseline current = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        });
    const Baseline historical = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0477(bytes);
        });
    check(
        results,
        same_observation(current.observation, historical.observation),
        "allocation_baseline_semantics");
    results.current_allocation_attempts += current.stats.attempts;
    results.historical_allocation_attempts += historical.stats.attempts;
    results.current_allocated_bytes += current.stats.total_bytes;
    results.historical_allocated_bytes += historical.stats.total_bytes;
    results.current_maximum_allocation = std::max(
        results.current_maximum_allocation, current.stats.maximum_bytes);
    results.historical_maximum_allocation = std::max(
        results.historical_maximum_allocation,
        historical.stats.maximum_bytes);

    const bool attempts_equal =
        current.stats.attempts == historical.stats.attempts;
    results.allocation_equivalence_checks += attempts_equal ? 1U : 0U;
    check(results, attempts_equal, "allocation_attempt_equivalence");
    const bool bytes_equal =
        current.stats.total_bytes == historical.stats.total_bytes;
    results.allocation_equivalence_checks += bytes_equal ? 1U : 0U;
    check(results, bytes_equal, "allocation_byte_equivalence");
    const bool maximum_equal =
        current.stats.maximum_bytes == historical.stats.maximum_bytes;
    results.allocation_equivalence_checks += maximum_equal ? 1U : 0U;
    check(results, maximum_equal, "allocation_maximum_equivalence");

    inject_allocation_failures(
        results,
        payload,
        current,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        },
        true);
    inject_allocation_failures(
        results,
        payload,
        historical,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0477(bytes);
        },
        false);
}

void allocation_cases(Results& results) {
    NATravPeerHandshakeMessage message =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 31);
    message.available_capabilities.reserve(100U);
    for (std::size_t index = 0U; index < 100U; ++index) {
        message.available_capabilities.push_back(
            capability_name(index, true));
    }
    allocation_scenario(results, encode_message(results, message));

    NATravPeerHandshakeMessage empty =
        base_message(NATravPeerHandshakeMessageKind::hello);
    allocation_scenario(results, encode_message(results, empty));
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    random_corpus(results);
    span_integrity_cases(results);
    allocation_cases(results);

    const std::size_t injected_total =
        results.injected_current_failures +
        results.injected_historical_failures;
    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.retained_capability_reads ==
                results.expected_capability_entries &&
            results.eliminated_array_reparse_entries ==
                results.expected_capability_entries &&
            results.expected_capability_entries > 7000U &&
            results.preflight_capture_checks == results.accepted_cases &&
            results.retained_projection_checks == results.accepted_cases &&
            results.historical_reparse_checks == results.accepted_cases &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.span_integrity_cases == 4U &&
            results.span_integrity_checks == 4U &&
            results.allocation_equivalence_checks ==
                results.allocation_scenarios * 3U &&
            results.exception_type_checks == injected_total &&
            results.exception_ordinal_checks == injected_total &&
            results.input_preservation_checks == injected_total &&
            results.retry_checks == injected_total,
        "coverage_and_span_retention_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(expected_capability_entries);
    PRINT_RESULT(retained_capability_reads);
    PRINT_RESULT(eliminated_array_reparse_entries);
    PRINT_RESULT(preflight_capture_checks);
    PRINT_RESULT(retained_projection_checks);
    PRINT_RESULT(historical_reparse_checks);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(span_integrity_cases);
    PRINT_RESULT(span_integrity_checks);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(current_allocation_attempts);
    PRINT_RESULT(historical_allocation_attempts);
    PRINT_RESULT(current_allocated_bytes);
    PRINT_RESULT(historical_allocated_bytes);
    PRINT_RESULT(current_maximum_allocation);
    PRINT_RESULT(historical_maximum_allocation);
    PRINT_RESULT(allocation_equivalence_checks);
    PRINT_RESULT(injected_current_failures);
    PRINT_RESULT(injected_historical_failures);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_capability_span_retention_test

int main() {
    try {
        return natrav_capability_span_retention_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(
            natrav_capability_span_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_RETENTION_TEST

// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_FIXED_ASCII_PREDICATE_RETENTION_TEST
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_fixed_ascii_predicate_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t injection_point) noexcept :
        point(injection_point) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_FIXED_ASCII_PREDICATE_BAD_ALLOC";
    }
    std::size_t point;
};

struct Stats final {
    std::size_t attempts{0U};
    std::size_t total_bytes{0U};
    std::size_t maximum_bytes{0U};
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    Stats stats;
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .stats = {},
    };
}

[[nodiscard]] Stats disarm() noexcept {
    const Stats stats = state.stats;
    state.armed = false;
    return stats;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_fixed_ascii_predicate_allocation_test

void* operator new(const std::size_t size) {
    return natrav_fixed_ascii_predicate_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_fixed_ascii_predicate_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_fixed_ascii_predicate_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_fixed_ascii_predicate_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_fixed_ascii_predicate_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_fixed_ascii_predicate_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_fixed_ascii_predicate_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_fixed_ascii_predicate_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_fixed_ascii_predicate_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_fixed_ascii_predicate_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_fixed_ascii_predicate_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_fixed_ascii_predicate_allocation_test::release(pointer);
}

namespace natrav_fixed_ascii_predicate_retention_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_fixed_ascii_predicate_allocation_test::Stats;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t expected_request_id_predicates{0U};
    std::size_t expected_artifact_sha256_predicates{0U};
    std::size_t expected_peer_error_code_predicates{0U};
    std::size_t preflight_request_id_captures{0U};
    std::size_t preflight_artifact_sha256_captures{0U};
    std::size_t preflight_peer_error_code_captures{0U};
    std::size_t retained_request_id_reads{0U};
    std::size_t retained_artifact_sha256_reads{0U};
    std::size_t retained_peer_error_code_reads{0U};
    std::size_t eliminated_request_id_rescans{0U};
    std::size_t eliminated_artifact_sha256_rescans{0U};
    std::size_t eliminated_peer_error_code_rescans{0U};
    std::size_t predicate_path_checks{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t predicate_boundary_cases{0U};
    std::size_t predicate_boundary_checks{0U};
    std::size_t predicate_model_cases{0U};
    std::size_t predicate_model_checks{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t current_allocation_attempts{0U};
    std::size_t historical_allocation_attempts{0U};
    std::size_t current_allocated_bytes{0U};
    std::size_t historical_allocated_bytes{0U};
    std::size_t current_maximum_allocation{0U};
    std::size_t historical_maximum_allocation{0U};
    std::size_t allocation_equivalence_checks{0U};
    std::size_t injected_current_failures{0U};
    std::size_t injected_historical_failures{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] Octets bytes(const std::string_view text) {
    Octets result;
    result.reserve(text.size());
    for (const char character : text) {
        result.push_back(static_cast<std::uint8_t>(
            static_cast<unsigned char>(character)));
    }
    return result;
}

[[nodiscard]] std::string hex64(const std::uint64_t seed) {
    constexpr std::string_view digits = "0123456789abcdef";
    std::string result(64U, '0');
    std::uint64_t state = seed ^ 0x9E3779B97F4A7C15ULL;
    for (char& character : result) {
        state ^= state << 7U;
        state ^= state >> 9U;
        state ^= state << 8U;
        character = digits[static_cast<std::size_t>(state & 0x0FULL)];
    }
    return result;
}

[[nodiscard]] std::string capability_name(const std::size_t index) {
    const std::string digits = std::to_string(index);
    if (digits.size() > 4U) {
        throw std::runtime_error("capability-index-range");
    }
    std::string result = "C";
    result.append(4U - digits.size(), '0');
    result.append(digits);
    return result;
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::uint64_t seed) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = static_cast<std::int64_t>(seed % 97U),
    };
    message.request_id = hex64(seed);
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = hex64(seed ^ 0xA5A5A5A5A5A5A5A5ULL),
            .target = "linux-x86_64",
            .version = "v1",
        };
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "fixed-ascii-predicate-retention";
    }
    return message;
}

[[nodiscard]] Octets encode_message(
    Results& results,
    const NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    check(
        results,
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "fixture_encoding");
    return encoded.payload.value_or(Octets{});
}

struct CountedDecode final {
    NATravPeerMessageDecodeObservation observation;
    datacube::CanonicalFixedAsciiPredicateRetentionCounters counters;
};

[[nodiscard]] CountedDecode current_decode(const Octets& payload) {
    datacube::reset_canonical_fixed_ascii_predicate_retention_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters = datacube::
            read_canonical_fixed_ascii_predicate_retention_counters(),
    };
}

[[nodiscard]] CountedDecode historical_decode(const Octets& payload) {
    datacube::reset_canonical_fixed_ascii_predicate_retention_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0478(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters = datacube::
            read_canonical_fixed_ascii_predicate_retention_counters(),
    };
}

void compare_case(
    Results& results,
    const Octets& payload,
    const bool random_case = false) {
    const CountedDecode current = current_decode(payload);
    const CountedDecode historical = historical_decode(payload);
    ++results.semantic_cases;
    results.random_cases += random_case ? 1U : 0U;
    const bool same = same_observation(
        current.observation, historical.observation);
    results.exact_observation_comparisons += same ? 1U : 0U;
    check(results, same, "semantic_equivalence");

    const auto& current_counters = current.counters;
    const auto& historical_counters = historical.counters;
    const bool captures_equal =
        current_counters.preflight_request_id_captures ==
            historical_counters.preflight_request_id_captures &&
        current_counters.preflight_artifact_sha256_captures ==
            historical_counters.preflight_artifact_sha256_captures &&
        current_counters.preflight_peer_error_code_captures ==
            historical_counters.preflight_peer_error_code_captures;
    results.predicate_path_checks += captures_equal ? 1U : 0U;
    check(results, captures_equal, "preflight_capture_equivalence");

    const bool request_path =
        current_counters.historical_request_id_rescans == 0U &&
        historical_counters.retained_request_id_reads == 0U &&
        current_counters.retained_request_id_reads ==
            historical_counters.historical_request_id_rescans;
    results.predicate_path_checks += request_path ? 1U : 0U;
    check(results, request_path, "request_predicate_path");
    const bool artifact_path =
        current_counters.historical_artifact_sha256_rescans == 0U &&
        historical_counters.retained_artifact_sha256_reads == 0U &&
        current_counters.retained_artifact_sha256_reads ==
            historical_counters.historical_artifact_sha256_rescans;
    results.predicate_path_checks += artifact_path ? 1U : 0U;
    check(results, artifact_path, "artifact_predicate_path");
    const bool code_path =
        current_counters.historical_peer_error_code_rescans == 0U &&
        historical_counters.retained_peer_error_code_reads == 0U &&
        current_counters.retained_peer_error_code_reads ==
            historical_counters.historical_peer_error_code_rescans;
    results.predicate_path_checks += code_path ? 1U : 0U;
    check(results, code_path, "error_code_predicate_path");

    results.preflight_request_id_captures +=
        current_counters.preflight_request_id_captures;
    results.preflight_artifact_sha256_captures +=
        current_counters.preflight_artifact_sha256_captures;
    results.preflight_peer_error_code_captures +=
        current_counters.preflight_peer_error_code_captures;
    results.retained_request_id_reads +=
        current_counters.retained_request_id_reads;
    results.retained_artifact_sha256_reads +=
        current_counters.retained_artifact_sha256_reads;
    results.retained_peer_error_code_reads +=
        current_counters.retained_peer_error_code_reads;
    results.eliminated_request_id_rescans +=
        historical_counters.historical_request_id_rescans;
    results.eliminated_artifact_sha256_rescans +=
        historical_counters.historical_artifact_sha256_rescans;
    results.eliminated_peer_error_code_rescans +=
        historical_counters.historical_peer_error_code_rescans;

    if (current.observation.status ==
        NATravPeerMessageDecodeStatus::accepted) {
        ++results.accepted_cases;
        check(results, current.observation.message.has_value(),
            "accepted_message_present");
        if (current.observation.message) {
            ++results.expected_request_id_predicates;
            if (current.observation.message->kind ==
                    NATravPeerHandshakeMessageKind::error) {
                ++results.expected_peer_error_code_predicates;
            } else {
                ++results.expected_artifact_sha256_predicates;
            }
            const auto encoded = datacube::natrav_peer_encode_message(
                *current.observation.message);
            const bool roundtrip =
                encoded.status == NATravPeerMessageEncodeStatus::accepted &&
                encoded.payload && *encoded.payload == payload;
            results.exact_roundtrips += roundtrip ? 1U : 0U;
            check(results, roundtrip, "accepted_roundtrip");
        }
    } else {
        ++results.rejection_cases;
    }
}

void accepted_corpus(Results& results) {
    for (std::size_t index = 0U; index < 256U; ++index) {
        const auto kind = static_cast<NATravPeerHandshakeMessageKind>(
            index % 3U);
        NATravPeerHandshakeMessage message = base_message(
            kind, static_cast<std::uint64_t>(index + 1U));
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            const std::size_t count = index % 4U;
            for (std::size_t entry = 0U; entry < count; ++entry) {
                message.required_capabilities.push_back(
                    capability_name(entry));
            }
        } else if (kind == NATravPeerHandshakeMessageKind::hello_ack) {
            const std::size_t count = index % 5U;
            for (std::size_t entry = 0U; entry < count; ++entry) {
                message.available_capabilities.push_back(
                    capability_name(entry));
            }
        } else {
            message.error_code = index % 2U == 0U ?
                "A" : "ERROR_CODE_9";
            message.error_message = index % 2U == 0U ?
                "error" : "error\nmessage";
        }
        compare_case(results, encode_message(results, message));
    }

    NATravPeerHandshakeMessage hello = base_message(
        NATravPeerHandshakeMessageKind::hello, 1001U);
    hello.request_id.assign(64U, '0');
    hello.artifact.sha256.assign(64U, 'f');
    hello.artifact.target = "target\nwith\tescapes";
    hello.artifact.version = "v\xF0\x9F\x98\x80";
    compare_case(results, encode_message(results, hello));

    NATravPeerHandshakeMessage ack = base_message(
        NATravPeerHandshakeMessageKind::hello_ack, 1002U);
    ack.request_id.assign(64U, 'f');
    ack.artifact.sha256.assign(64U, '0');
    ack.available_capabilities = {"A", "A_B", "Z9"};
    compare_case(results, encode_message(results, ack));

    NATravPeerHandshakeMessage error = base_message(
        NATravPeerHandshakeMessageKind::error, 1003U);
    error.error_code.assign(64U, 'A');
    error.error_message = "boundary";
    compare_case(results, encode_message(results, error));
}

[[nodiscard]] std::string hello_json(
    const std::string_view request_id,
    const std::string_view artifact_sha,
    const std::string_view capabilities = "[]") {
    return std::string("{\"artifact\":{\"sha256\":\"") +
        std::string(artifact_sha) +
        "\",\"target\":\"t\",\"version\":\"v\"},\"kind\":\"HELLO\","
        "\"protocol\":{\"id\":\"NATRAV_OVERLAY_PEER\",\"major\":1,"
        "\"minor\":0},\"request_id\":\"" + std::string(request_id) +
        "\",\"required_capabilities\":" + std::string(capabilities) + "}";
}

[[nodiscard]] std::string error_json(
    const std::string_view code,
    const std::string_view request_id,
    const std::string_view message = "m") {
    return std::string("{\"code\":\"") + std::string(code) +
        "\",\"kind\":\"ERROR\",\"message\":\"" +
        std::string(message) +
        "\",\"protocol\":{\"id\":\"NATRAV_OVERLAY_PEER\","
        "\"major\":1,\"minor\":0},\"request_id\":\"" +
        std::string(request_id) + "\"}";
}

void priority_case(
    Results& results,
    const std::string& text,
    const NATravPeerMessageDecodeStatus expected) {
    ++results.classification_priority_cases;
    const Octets payload = bytes(text);
    const CountedDecode current = current_decode(payload);
    const bool exact = current.observation.status == expected;
    results.exact_classifications += exact ? 1U : 0U;
    check(results, exact, "classification_priority");
    compare_case(results, payload);
}

void priority_cases(Results& results) {
    const std::string request(64U, 'a');
    const std::string sha(64U, 'b');
    priority_case(
        results,
        hello_json(request, sha).substr(0U, 37U),
        NATravPeerMessageDecodeStatus::malformed_json);
    priority_case(
        results,
        "[]",
        NATravPeerMessageDecodeStatus::schema_rejected);
    std::string whitespace = hello_json(request, sha);
    whitespace.insert(1U, " ");
    priority_case(
        results,
        whitespace,
        NATravPeerMessageDecodeStatus::noncanonical_json);
    std::string unknown_kind = hello_json(request, sha);
    const std::size_t kind_position = unknown_kind.find("HELLO");
    unknown_kind.replace(kind_position, 5U, "OTHER");
    priority_case(
        results,
        unknown_kind,
        NATravPeerMessageDecodeStatus::message_kind_rejected);
    std::string bad_protocol = hello_json(request, sha);
    const std::size_t protocol_position =
        bad_protocol.find("NATRAV_OVERLAY_PEER");
    bad_protocol.replace(
        protocol_position,
        std::string_view("NATRAV_OVERLAY_PEER").size(),
        "OTHER");
    priority_case(
        results,
        bad_protocol,
        NATravPeerMessageDecodeStatus::protocol_mismatch);
    std::string bad_request = request;
    bad_request[17U] = 'g';
    priority_case(
        results,
        hello_json(bad_request, sha),
        NATravPeerMessageDecodeStatus::request_id_rejected);
    std::string bad_sha = sha;
    bad_sha[23U] = 'G';
    priority_case(
        results,
        hello_json(request, bad_sha),
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);
    priority_case(
        results,
        hello_json(request, sha, "[\"B\",\"A\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected);
    priority_case(
        results,
        error_json("bad", request),
        NATravPeerMessageDecodeStatus::schema_rejected);
    priority_case(
        results,
        error_json("ERROR_", request),
        NATravPeerMessageDecodeStatus::schema_rejected);
    priority_case(
        results,
        error_json("ERROR", request, ""),
        NATravPeerMessageDecodeStatus::schema_rejected);

    std::string escaped_request = request;
    escaped_request.replace(0U, 1U, "\\u0061");
    priority_case(
        results,
        hello_json(escaped_request, sha),
        NATravPeerMessageDecodeStatus::noncanonical_json);

    std::string request_number = hello_json(request, sha);
    const std::string request_token = "\"request_id\":\"" + request + "\"";
    request_number.replace(
        request_number.find(request_token),
        request_token.size(),
        "\"request_id\":1");
    priority_case(
        results,
        request_number,
        NATravPeerMessageDecodeStatus::request_id_rejected);

    std::string sha_number = hello_json(request, sha);
    const std::string sha_token = "\"sha256\":\"" + sha + "\"";
    sha_number.replace(
        sha_number.find(sha_token),
        sha_token.size(),
        "\"sha256\":1");
    priority_case(
        results,
        sha_number,
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);

    std::string code_number = error_json("ERROR", request);
    code_number.replace(
        code_number.find("\"code\":\"ERROR\""),
        std::string_view("\"code\":\"ERROR\"").size(),
        "\"code\":1");
    priority_case(
        results,
        code_number,
        NATravPeerMessageDecodeStatus::schema_rejected);
}

void random_corpus(Results& results) {
    std::uint64_t state = 0xD6E8FEB86659FD93ULL;
    for (std::size_t index = 0U; index < 4096U; ++index) {
        state ^= state << 7U;
        state ^= state >> 9U;
        state ^= state << 8U;
        const std::size_t size = 2U +
            static_cast<std::size_t>(state % 127U);
        Octets payload(size);
        for (std::size_t offset = 0U; offset < size; ++offset) {
            state ^= state << 7U;
            state ^= state >> 9U;
            state ^= state << 8U;
            payload[offset] = static_cast<std::uint8_t>(state & 0xFFU);
        }
        compare_case(results, payload, true);
    }
}

void predicate_boundary_case(
    Results& results,
    const std::string& token,
    const datacube::CanonicalFixedAsciiPredicate predicate,
    const bool expected_predicate,
    const bool expected_canonical = true) {
    ++results.predicate_boundary_cases;
    std::size_t offset = 0U;
    const datacube::JsonStringTokenParseResult parsed =
        datacube::parse_json_string_token_checked(
            token, offset, predicate);
    const bool exact = offset == token.size() &&
        parsed.fixed_ascii_predicate.has_value() &&
        *parsed.fixed_ascii_predicate == expected_predicate &&
        parsed.canonical == expected_canonical;
    results.predicate_boundary_checks += exact ? 1U : 0U;
    check(results, exact, "predicate_boundary");
}

void predicate_boundary_cases(Results& results) {
    const auto hex = datacube::CanonicalFixedAsciiPredicate::lower_hex_sha256;
    const auto capability =
        datacube::CanonicalFixedAsciiPredicate::capability_token;
    predicate_boundary_case(
        results, "\"" + std::string(64U, '0') + "\"", hex, true);
    predicate_boundary_case(
        results, "\"" + std::string(64U, 'f') + "\"", hex, true);
    predicate_boundary_case(
        results, "\"" + std::string(63U, 'a') + "\"", hex, false);
    predicate_boundary_case(
        results, "\"" + std::string(65U, 'a') + "\"", hex, false);
    predicate_boundary_case(
        results, "\"" + std::string(63U, 'a') + "G\"", hex, false);
    predicate_boundary_case(
        results,
        "\"\\u0061" + std::string(63U, 'a') + "\"",
        hex,
        true,
        false);
    predicate_boundary_case(results, "\"A\"", capability, true);
    predicate_boundary_case(results, "\"A_B2\"", capability, true);
    predicate_boundary_case(
        results, "\"" + std::string(64U, 'Z') + "\"", capability, true);
    predicate_boundary_case(results, "\"\"", capability, false);
    predicate_boundary_case(results, "\"a\"", capability, false);
    predicate_boundary_case(results, "\"1A\"", capability, false);
    predicate_boundary_case(results, "\"A__B\"", capability, false);
    predicate_boundary_case(results, "\"A_\"", capability, false);
    predicate_boundary_case(
        results, "\"" + std::string(65U, 'Z') + "\"", capability, false);
    predicate_boundary_case(
        results, "\"\\u0041\"", capability, true, false);
    predicate_boundary_case(
        results, "\"A\\u00E9\"", capability, false, false);
}

void predicate_model_cases(Results& results) {
    constexpr std::string_view alphabet =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_abcdefghijklmnopqrstuvwxyz-";
    std::uint64_t state = 0xA0761D6478BD642FULL;
    for (std::size_t case_index = 0U; case_index < 65536U; ++case_index) {
        state ^= state << 7U;
        state ^= state >> 9U;
        state ^= state << 8U;
        const std::size_t length = static_cast<std::size_t>(state % 71U);
        std::string candidate;
        candidate.reserve(length);
        for (std::size_t offset = 0U; offset < length; ++offset) {
            state ^= state << 7U;
            state ^= state >> 9U;
            state ^= state << 8U;
            candidate.push_back(alphabet[
                static_cast<std::size_t>(state % alphabet.size())]);
        }

        datacube::CanonicalFixedAsciiPredicateAccumulator hex(
            datacube::CanonicalFixedAsciiPredicate::lower_hex_sha256);
        datacube::CanonicalFixedAsciiPredicateAccumulator capability(
            datacube::CanonicalFixedAsciiPredicate::capability_token);
        for (const char character : candidate) {
            const std::uint32_t scalar = static_cast<std::uint32_t>(
                static_cast<unsigned char>(character));
            hex.observe(scalar);
            capability.observe(scalar);
        }

        ++results.predicate_model_cases;
        const bool hex_exact = hex.result().value_or(false) ==
            datacube::lower_hex_sha256(candidate);
        results.predicate_model_checks += hex_exact ? 1U : 0U;
        check(results, hex_exact, "lower_hex_predicate_model");

        ++results.predicate_model_cases;
        const bool capability_exact =
            capability.result().value_or(false) ==
                datacube::capability_token(candidate);
        results.predicate_model_checks += capability_exact ? 1U : 0U;
        check(results, capability_exact, "capability_predicate_model");
    }
}

struct Baseline final {
    NATravPeerMessageDecodeObservation observation;
    Stats stats;
};

template <typename Decode>
[[nodiscard]] Baseline baseline_decode(
    const Octets& payload,
    Decode&& decode) {
    natrav_fixed_ascii_predicate_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation;
    try {
        observation = decode(payload);
    } catch (...) {
        static_cast<void>(
            natrav_fixed_ascii_predicate_allocation_test::disarm());
        throw;
    }
    const Stats stats =
        natrav_fixed_ascii_predicate_allocation_test::disarm();
    return Baseline{
        .observation = std::move(observation),
        .stats = stats,
    };
}

template <typename Decode>
void inject_allocation_failures(
    Results& results,
    const Octets& payload,
    const Baseline& baseline,
    Decode&& decode,
    const bool current) {
    for (std::size_t point = 0U; point < baseline.stats.attempts; ++point) {
        const Octets before = payload;
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_fixed_ascii_predicate_allocation_test::arm(point);
        try {
            static_cast<void>(decode(payload));
        } catch (const natrav_fixed_ascii_predicate_allocation_test::
                     InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        } catch (...) {
        }
        static_cast<void>(
            natrav_fixed_ascii_predicate_allocation_test::disarm());
        if (current) {
            ++results.injected_current_failures;
        } else {
            ++results.injected_historical_failures;
        }
        results.exception_type_checks += caught ? 1U : 0U;
        check(results, caught, "allocation_exception_type");
        const bool ordinal = caught_point == point;
        results.exception_ordinal_checks += ordinal ? 1U : 0U;
        check(results, ordinal, "allocation_exception_ordinal");
        const bool preserved = payload == before;
        results.input_preservation_checks += preserved ? 1U : 0U;
        check(results, preserved, "allocation_input_preserved");
        const NATravPeerMessageDecodeObservation retry = decode(payload);
        const bool retry_equal = same_observation(retry, baseline.observation);
        results.retry_checks += retry_equal ? 1U : 0U;
        check(results, retry_equal, "allocation_retry");
    }
}

void allocation_scenario(Results& results, const Octets& payload) {
    ++results.allocation_scenarios;
    const Baseline current = baseline_decode(
        payload,
        [](const Octets& value) {
            return datacube::natrav_peer_decode_message(value);
        });
    const Baseline historical = baseline_decode(
        payload,
        [](const Octets& value) {
            return datacube::natrav_peer_decode_message_revision_0478(value);
        });
    check(
        results,
        same_observation(current.observation, historical.observation),
        "allocation_baseline_semantics");
    results.current_allocation_attempts += current.stats.attempts;
    results.historical_allocation_attempts += historical.stats.attempts;
    results.current_allocated_bytes += current.stats.total_bytes;
    results.historical_allocated_bytes += historical.stats.total_bytes;
    results.current_maximum_allocation = std::max(
        results.current_maximum_allocation, current.stats.maximum_bytes);
    results.historical_maximum_allocation = std::max(
        results.historical_maximum_allocation,
        historical.stats.maximum_bytes);

    const bool attempts_equal =
        current.stats.attempts == historical.stats.attempts;
    results.allocation_equivalence_checks += attempts_equal ? 1U : 0U;
    check(results, attempts_equal, "allocation_attempt_equivalence");
    const bool bytes_equal =
        current.stats.total_bytes == historical.stats.total_bytes;
    results.allocation_equivalence_checks += bytes_equal ? 1U : 0U;
    check(results, bytes_equal, "allocation_byte_equivalence");
    const bool maximum_equal =
        current.stats.maximum_bytes == historical.stats.maximum_bytes;
    results.allocation_equivalence_checks += maximum_equal ? 1U : 0U;
    check(results, maximum_equal, "allocation_maximum_equivalence");

    inject_allocation_failures(
        results,
        payload,
        current,
        [](const Octets& value) {
            return datacube::natrav_peer_decode_message(value);
        },
        true);
    inject_allocation_failures(
        results,
        payload,
        historical,
        [](const Octets& value) {
            return datacube::natrav_peer_decode_message_revision_0478(value);
        },
        false);
}

void allocation_cases(Results& results) {
    NATravPeerHandshakeMessage hello = base_message(
        NATravPeerHandshakeMessageKind::hello, 2001U);
    hello.artifact.target.assign(4000U, 't');
    hello.artifact.version.assign(3000U, 'v');
    for (std::size_t index = 0U; index < 80U; ++index) {
        hello.required_capabilities.push_back(capability_name(index));
    }
    allocation_scenario(results, encode_message(results, hello));

    NATravPeerHandshakeMessage ack = base_message(
        NATravPeerHandshakeMessageKind::hello_ack, 2002U);
    for (std::size_t index = 0U; index < 100U; ++index) {
        ack.available_capabilities.push_back(capability_name(index));
    }
    allocation_scenario(results, encode_message(results, ack));

    NATravPeerHandshakeMessage error = base_message(
        NATravPeerHandshakeMessageKind::error, 2003U);
    error.error_message.assign(10000U, 'e');
    allocation_scenario(results, encode_message(results, error));
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    random_corpus(results);
    predicate_boundary_cases(results);
    predicate_model_cases(results);
    allocation_cases(results);

    const std::size_t injected_total =
        results.injected_current_failures +
        results.injected_historical_failures;
    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.retained_request_id_reads ==
                results.eliminated_request_id_rescans &&
            results.retained_artifact_sha256_reads ==
                results.eliminated_artifact_sha256_rescans &&
            results.retained_peer_error_code_reads ==
                results.eliminated_peer_error_code_rescans &&
            results.retained_request_id_reads >=
                results.expected_request_id_predicates &&
            results.retained_artifact_sha256_reads >=
                results.expected_artifact_sha256_predicates &&
            results.retained_peer_error_code_reads >=
                results.expected_peer_error_code_predicates &&
            results.eliminated_request_id_rescans != 0U &&
            results.eliminated_artifact_sha256_rescans != 0U &&
            results.eliminated_peer_error_code_rescans != 0U &&
            results.predicate_path_checks == results.semantic_cases * 4U &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.predicate_boundary_cases == 17U &&
            results.predicate_boundary_checks == 17U &&
            results.predicate_model_cases == 131072U &&
            results.predicate_model_checks == 131072U &&
            results.allocation_equivalence_checks ==
                results.allocation_scenarios * 3U &&
            results.exception_type_checks == injected_total &&
            results.exception_ordinal_checks == injected_total &&
            results.input_preservation_checks == injected_total &&
            results.retry_checks == injected_total,
        "coverage_and_predicate_retention_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(expected_request_id_predicates);
    PRINT_RESULT(expected_artifact_sha256_predicates);
    PRINT_RESULT(expected_peer_error_code_predicates);
    PRINT_RESULT(preflight_request_id_captures);
    PRINT_RESULT(preflight_artifact_sha256_captures);
    PRINT_RESULT(preflight_peer_error_code_captures);
    PRINT_RESULT(retained_request_id_reads);
    PRINT_RESULT(retained_artifact_sha256_reads);
    PRINT_RESULT(retained_peer_error_code_reads);
    PRINT_RESULT(eliminated_request_id_rescans);
    PRINT_RESULT(eliminated_artifact_sha256_rescans);
    PRINT_RESULT(eliminated_peer_error_code_rescans);
    PRINT_RESULT(predicate_path_checks);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(predicate_boundary_cases);
    PRINT_RESULT(predicate_boundary_checks);
    PRINT_RESULT(predicate_model_cases);
    PRINT_RESULT(predicate_model_checks);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(current_allocation_attempts);
    PRINT_RESULT(historical_allocation_attempts);
    PRINT_RESULT(current_allocated_bytes);
    PRINT_RESULT(historical_allocated_bytes);
    PRINT_RESULT(current_maximum_allocation);
    PRINT_RESULT(historical_maximum_allocation);
    PRINT_RESULT(allocation_equivalence_checks);
    PRINT_RESULT(injected_current_failures);
    PRINT_RESULT(injected_historical_failures);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_fixed_ascii_predicate_retention_test

int main() {
    try {
        return natrav_fixed_ascii_predicate_retention_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(
            natrav_fixed_ascii_predicate_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_FIXED_ASCII_PREDICATE_RETENTION_TEST

// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_STRING_DISCRIMINANT_RETENTION_TEST
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_string_discriminant_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t injection_point) noexcept :
        point(injection_point) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_STRING_DISCRIMINANT_BAD_ALLOC";
    }
    std::size_t point;
};

struct Stats final {
    std::size_t attempts{0U};
    std::size_t total_bytes{0U};
    std::size_t maximum_bytes{0U};
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    Stats stats;
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .stats = {},
    };
}

[[nodiscard]] Stats disarm() noexcept {
    const Stats stats = state.stats;
    state.armed = false;
    return stats;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_string_discriminant_allocation_test

void* operator new(const std::size_t size) {
    return natrav_string_discriminant_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_string_discriminant_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_string_discriminant_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_string_discriminant_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_string_discriminant_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_string_discriminant_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_string_discriminant_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_string_discriminant_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_string_discriminant_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_string_discriminant_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_string_discriminant_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_string_discriminant_allocation_test::release(pointer);
}

namespace natrav_string_discriminant_retention_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_string_discriminant_allocation_test::Stats;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t preflight_message_kind_captures{0U};
    std::size_t preflight_protocol_id_captures{0U};
    std::size_t retained_message_kind_reads{0U};
    std::size_t retained_protocol_id_reads{0U};
    std::size_t eliminated_message_kind_rescans{0U};
    std::size_t eliminated_protocol_id_rescans{0U};
    std::size_t eliminated_message_kind_rescan_bytes{0U};
    std::size_t eliminated_protocol_id_rescan_bytes{0U};
    std::size_t discriminant_path_checks{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t discriminant_boundary_cases{0U};
    std::size_t discriminant_boundary_checks{0U};
    std::size_t discriminant_model_cases{0U};
    std::size_t discriminant_model_checks{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t current_allocation_attempts{0U};
    std::size_t historical_allocation_attempts{0U};
    std::size_t current_allocated_bytes{0U};
    std::size_t historical_allocated_bytes{0U};
    std::size_t current_maximum_allocation{0U};
    std::size_t historical_maximum_allocation{0U};
    std::size_t allocation_equivalence_checks{0U};
    std::size_t injected_current_failures{0U};
    std::size_t injected_historical_failures{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] Octets bytes(const std::string_view text) {
    Octets result;
    result.reserve(text.size());
    for (const char character : text) {
        result.push_back(static_cast<std::uint8_t>(
            static_cast<unsigned char>(character)));
    }
    return result;
}

[[nodiscard]] std::string hex64(const std::uint64_t seed) {
    constexpr std::string_view digits = "0123456789abcdef";
    std::string result(64U, '0');
    std::uint64_t state = seed ^ 0x9E3779B97F4A7C15ULL;
    for (char& character : result) {
        state ^= state << 7U;
        state ^= state >> 9U;
        state ^= state << 8U;
        character = digits[static_cast<std::size_t>(state & 0x0FULL)];
    }
    return result;
}

[[nodiscard]] std::string capability_name(const std::size_t index) {
    const std::string digits = std::to_string(index);
    if (digits.size() > 4U) {
        throw std::runtime_error("capability-index-range");
    }
    std::string result = "C";
    result.append(4U - digits.size(), '0');
    result.append(digits);
    return result;
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::uint64_t seed) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = static_cast<std::int64_t>(seed % 97U),
    };
    message.request_id = hex64(seed);
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = hex64(seed ^ 0xA5A5A5A5A5A5A5A5ULL),
            .target = "linux-x86_64",
            .version = "v1",
        };
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "string-discriminant-retention";
    }
    return message;
}

[[nodiscard]] Octets encode_message(
    Results& results,
    const NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    check(
        results,
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "fixture_encoding");
    return encoded.payload.value_or(Octets{});
}

struct CountedDecode final {
    NATravPeerMessageDecodeObservation observation;
    datacube::CanonicalStringDiscriminantRetentionCounters counters;
};

[[nodiscard]] CountedDecode current_decode(const Octets& payload) {
    datacube::reset_canonical_string_discriminant_retention_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters = datacube::
            read_canonical_string_discriminant_retention_counters(),
    };
}

[[nodiscard]] CountedDecode historical_decode(const Octets& payload) {
    datacube::reset_canonical_string_discriminant_retention_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0479(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters = datacube::
            read_canonical_string_discriminant_retention_counters(),
    };
}

void compare_case(
    Results& results,
    const Octets& payload,
    const bool random_case = false) {
    const CountedDecode current = current_decode(payload);
    const CountedDecode historical = historical_decode(payload);
    ++results.semantic_cases;
    results.random_cases += random_case ? 1U : 0U;

    const bool same = same_observation(
        current.observation, historical.observation);
    results.exact_observation_comparisons += same ? 1U : 0U;
    check(results, same, "semantic_equivalence");

    const auto& current_counters = current.counters;
    const auto& historical_counters = historical.counters;
    const bool captures_equal =
        current_counters.preflight_message_kind_captures ==
            historical_counters.preflight_message_kind_captures &&
        current_counters.preflight_protocol_id_captures ==
            historical_counters.preflight_protocol_id_captures;
    results.discriminant_path_checks += captures_equal ? 1U : 0U;
    check(results, captures_equal, "preflight_capture_equivalence");

    const bool kind_path =
        current_counters.historical_message_kind_rescans == 0U &&
        historical_counters.retained_message_kind_reads == 0U &&
        current_counters.retained_message_kind_reads ==
            historical_counters.historical_message_kind_rescans;
    results.discriminant_path_checks += kind_path ? 1U : 0U;
    check(results, kind_path, "message_kind_discriminant_path");

    const bool protocol_path =
        current_counters.historical_protocol_id_rescans == 0U &&
        historical_counters.retained_protocol_id_reads == 0U &&
        current_counters.retained_protocol_id_reads ==
            historical_counters.historical_protocol_id_rescans;
    results.discriminant_path_checks += protocol_path ? 1U : 0U;
    check(results, protocol_path, "protocol_id_discriminant_path");

    const bool rescan_bytes_exact =
        historical_counters.historical_message_kind_rescan_bytes >=
            historical_counters.historical_message_kind_rescans * 2U &&
        historical_counters.historical_protocol_id_rescan_bytes >=
            historical_counters.historical_protocol_id_rescans * 2U;
    results.discriminant_path_checks += rescan_bytes_exact ? 1U : 0U;
    check(results, rescan_bytes_exact, "historical_rescan_byte_accounting");

    results.preflight_message_kind_captures +=
        current_counters.preflight_message_kind_captures;
    results.preflight_protocol_id_captures +=
        current_counters.preflight_protocol_id_captures;
    results.retained_message_kind_reads +=
        current_counters.retained_message_kind_reads;
    results.retained_protocol_id_reads +=
        current_counters.retained_protocol_id_reads;
    results.eliminated_message_kind_rescans +=
        historical_counters.historical_message_kind_rescans;
    results.eliminated_protocol_id_rescans +=
        historical_counters.historical_protocol_id_rescans;
    results.eliminated_message_kind_rescan_bytes +=
        historical_counters.historical_message_kind_rescan_bytes;
    results.eliminated_protocol_id_rescan_bytes +=
        historical_counters.historical_protocol_id_rescan_bytes;

    if (current.observation.status ==
        NATravPeerMessageDecodeStatus::accepted) {
        ++results.accepted_cases;
        check(
            results,
            current.observation.message.has_value(),
            "accepted_message_present");
        if (current.observation.message) {
            const auto encoded = datacube::natrav_peer_encode_message(
                *current.observation.message);
            const bool roundtrip =
                encoded.status == NATravPeerMessageEncodeStatus::accepted &&
                encoded.payload && *encoded.payload == payload;
            results.exact_roundtrips += roundtrip ? 1U : 0U;
            check(results, roundtrip, "accepted_roundtrip");
        }
    } else {
        ++results.rejection_cases;
    }
}

void accepted_corpus(Results& results) {
    for (std::size_t index = 0U; index < 256U; ++index) {
        const auto kind = static_cast<NATravPeerHandshakeMessageKind>(
            index % 3U);
        NATravPeerHandshakeMessage message = base_message(
            kind, static_cast<std::uint64_t>(index + 1U));
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            const std::size_t count = index % 4U;
            for (std::size_t entry = 0U; entry < count; ++entry) {
                message.required_capabilities.push_back(
                    capability_name(entry));
            }
        } else if (kind == NATravPeerHandshakeMessageKind::hello_ack) {
            const std::size_t count = index % 5U;
            for (std::size_t entry = 0U; entry < count; ++entry) {
                message.available_capabilities.push_back(
                    capability_name(entry));
            }
        } else {
            message.error_code = index % 2U == 0U ?
                "A" : "ERROR_CODE_9";
            message.error_message = index % 2U == 0U ?
                "error" : "error\nmessage";
        }
        compare_case(results, encode_message(results, message));
    }

    NATravPeerHandshakeMessage hello = base_message(
        NATravPeerHandshakeMessageKind::hello, 1001U);
    hello.artifact.target = "target\nwith\tescapes";
    hello.artifact.version = "v\xF0\x9F\x98\x80";
    compare_case(results, encode_message(results, hello));

    NATravPeerHandshakeMessage ack = base_message(
        NATravPeerHandshakeMessageKind::hello_ack, 1002U);
    ack.available_capabilities = {"A", "A_B", "Z9"};
    compare_case(results, encode_message(results, ack));

    NATravPeerHandshakeMessage error = base_message(
        NATravPeerHandshakeMessageKind::error, 1003U);
    error.error_code.assign(64U, 'A');
    error.error_message = "boundary";
    compare_case(results, encode_message(results, error));
}

[[nodiscard]] std::string hello_json(
    const std::string_view kind,
    const std::string_view protocol_id,
    const std::string_view request_id,
    const std::string_view artifact_sha,
    const std::string_view capabilities = "[]") {
    return std::string("{\"artifact\":{\"sha256\":\"") +
        std::string(artifact_sha) +
        "\",\"target\":\"t\",\"version\":\"v\"},\"kind\":\"" +
        std::string(kind) + "\",\"protocol\":{\"id\":\"" +
        std::string(protocol_id) +
        "\",\"major\":1,\"minor\":0},\"request_id\":\"" +
        std::string(request_id) +
        "\",\"required_capabilities\":" +
        std::string(capabilities) + "}";
}

[[nodiscard]] std::string error_json(
    const std::string_view kind,
    const std::string_view protocol_id,
    const std::string_view code,
    const std::string_view request_id,
    const std::string_view message = "m") {
    return std::string("{\"code\":\"") + std::string(code) +
        "\",\"kind\":\"" + std::string(kind) +
        "\",\"message\":\"" + std::string(message) +
        "\",\"protocol\":{\"id\":\"" + std::string(protocol_id) +
        "\",\"major\":1,\"minor\":0},\"request_id\":\"" +
        std::string(request_id) + "\"}";
}

void priority_case(
    Results& results,
    const std::string& text,
    const NATravPeerMessageDecodeStatus expected) {
    ++results.classification_priority_cases;
    const Octets payload = bytes(text);
    const CountedDecode current = current_decode(payload);
    const bool exact = current.observation.status == expected;
    results.exact_classifications += exact ? 1U : 0U;
    check(results, exact, "classification_priority");
    compare_case(results, payload);
}

void priority_cases(Results& results) {
    const std::string request(64U, 'a');
    const std::string sha(64U, 'b');
    const std::string canonical = hello_json(
        "HELLO", "NATRAV_OVERLAY_PEER", request, sha);
    priority_case(
        results,
        canonical.substr(0U, 37U),
        NATravPeerMessageDecodeStatus::malformed_json);
    priority_case(
        results,
        "[]",
        NATravPeerMessageDecodeStatus::schema_rejected);

    std::string whitespace = canonical;
    whitespace.insert(1U, " ");
    priority_case(
        results,
        whitespace,
        NATravPeerMessageDecodeStatus::noncanonical_json);

    priority_case(
        results,
        hello_json("\\u0048ELLO", "NATRAV_OVERLAY_PEER", request, sha),
        NATravPeerMessageDecodeStatus::noncanonical_json);
    priority_case(
        results,
        hello_json("HELLO", "NATRAV_OVERLAY_\\u0050EER", request, sha),
        NATravPeerMessageDecodeStatus::noncanonical_json);
    priority_case(
        results,
        hello_json("OTHER", "NATRAV_OVERLAY_PEER", request, sha),
        NATravPeerMessageDecodeStatus::message_kind_rejected);
    priority_case(
        results,
        hello_json("HELLO", "OTHER", request, sha),
        NATravPeerMessageDecodeStatus::protocol_mismatch);

    std::string kind_number = canonical;
    kind_number.replace(
        kind_number.find("\"kind\":\"HELLO\""),
        std::string_view("\"kind\":\"HELLO\"").size(),
        "\"kind\":1");
    priority_case(
        results,
        kind_number,
        NATravPeerMessageDecodeStatus::message_kind_rejected);

    std::string protocol_number = canonical;
    protocol_number.replace(
        protocol_number.find("\"id\":\"NATRAV_OVERLAY_PEER\""),
        std::string_view("\"id\":\"NATRAV_OVERLAY_PEER\"").size(),
        "\"id\":1");
    priority_case(
        results,
        protocol_number,
        NATravPeerMessageDecodeStatus::protocol_mismatch);

    std::string bad_request = request;
    bad_request[17U] = 'g';
    priority_case(
        results,
        hello_json(
            "HELLO", "NATRAV_OVERLAY_PEER", bad_request, sha),
        NATravPeerMessageDecodeStatus::request_id_rejected);

    std::string bad_sha = sha;
    bad_sha[23U] = 'G';
    priority_case(
        results,
        hello_json(
            "HELLO", "NATRAV_OVERLAY_PEER", request, bad_sha),
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);

    priority_case(
        results,
        hello_json(
            "HELLO", "NATRAV_OVERLAY_PEER", request, sha,
            "[\"B\",\"A\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected);

    priority_case(
        results,
        error_json(
            "ERROR", "NATRAV_OVERLAY_PEER", "bad", request),
        NATravPeerMessageDecodeStatus::schema_rejected);
    priority_case(
        results,
        error_json(
            "ERROR", "OTHER", "ERROR", request),
        NATravPeerMessageDecodeStatus::protocol_mismatch);
    priority_case(
        results,
        error_json(
            "ERROR", "NATRAV_OVERLAY_PEER", "ERROR", request, ""),
        NATravPeerMessageDecodeStatus::schema_rejected);
}

void random_corpus(Results& results) {
    std::uint64_t state = 0xD6E8FEB86659FD93ULL;
    for (std::size_t index = 0U; index < 4096U; ++index) {
        state ^= state << 7U;
        state ^= state >> 9U;
        state ^= state << 8U;
        const std::size_t size = 2U +
            static_cast<std::size_t>(state % 127U);
        Octets payload(size);
        for (std::size_t offset = 0U; offset < size; ++offset) {
            state ^= state << 7U;
            state ^= state >> 9U;
            state ^= state << 8U;
            payload[offset] = static_cast<std::uint8_t>(state & 0xFFU);
        }
        compare_case(results, payload, true);
    }
}

void kind_boundary_case(
    Results& results,
    const std::string& token,
    const NATravPeerHandshakeMessageKind expected,
    const bool expected_canonical = true) {
    ++results.discriminant_boundary_cases;
    std::size_t offset = 0U;
    const datacube::JsonStringTokenParseResult parsed =
        datacube::parse_json_string_token_checked(
            token,
            offset,
            datacube::CanonicalFixedAsciiPredicate::none,
            datacube::CanonicalStringDiscriminant::message_kind);
    const bool exact = offset == token.size() &&
        parsed.message_kind_discriminant.has_value() &&
        *parsed.message_kind_discriminant == expected &&
        parsed.canonical == expected_canonical &&
        !parsed.protocol_id_discriminant.has_value();
    results.discriminant_boundary_checks += exact ? 1U : 0U;
    check(results, exact, "message_kind_boundary");
}

void protocol_boundary_case(
    Results& results,
    const std::string& token,
    const bool expected,
    const bool expected_canonical = true) {
    ++results.discriminant_boundary_cases;
    std::size_t offset = 0U;
    const datacube::JsonStringTokenParseResult parsed =
        datacube::parse_json_string_token_checked(
            token,
            offset,
            datacube::CanonicalFixedAsciiPredicate::none,
            datacube::CanonicalStringDiscriminant::protocol_id);
    const bool exact = offset == token.size() &&
        parsed.protocol_id_discriminant.has_value() &&
        *parsed.protocol_id_discriminant == expected &&
        parsed.canonical == expected_canonical &&
        !parsed.message_kind_discriminant.has_value();
    results.discriminant_boundary_checks += exact ? 1U : 0U;
    check(results, exact, "protocol_id_boundary");
}

void discriminant_boundary_cases(Results& results) {
    kind_boundary_case(
        results, "\"HELLO\"", NATravPeerHandshakeMessageKind::hello);
    kind_boundary_case(
        results,
        "\"HELLO_ACK\"",
        NATravPeerHandshakeMessageKind::hello_ack);
    kind_boundary_case(
        results, "\"ERROR\"", NATravPeerHandshakeMessageKind::error);
    kind_boundary_case(
        results, "\"OTHER\"", NATravPeerHandshakeMessageKind::unknown);
    kind_boundary_case(
        results, "\"\"", NATravPeerHandshakeMessageKind::unknown);
    kind_boundary_case(
        results,
        "\"HELLO_ACKX\"",
        NATravPeerHandshakeMessageKind::unknown);
    kind_boundary_case(
        results,
        "\"\\u0048ELLO\"",
        NATravPeerHandshakeMessageKind::hello,
        false);
    kind_boundary_case(
        results,
        "\"HELL\\u004F\"",
        NATravPeerHandshakeMessageKind::hello,
        false);
    kind_boundary_case(
        results,
        "\"H\\u00E9LLO\"",
        NATravPeerHandshakeMessageKind::unknown,
        false);

    protocol_boundary_case(results, "\"NATRAV_OVERLAY_PEER\"", true);
    protocol_boundary_case(results, "\"OTHER\"", false);
    protocol_boundary_case(results, "\"NATRAV_OVERLAY_PEE\"", false);
    protocol_boundary_case(results, "\"NATRAV_OVERLAY_PEERX\"", false);
    protocol_boundary_case(
        results, "\"NATRAV_OVERLAY_\\u0050EER\"", true, false);
    protocol_boundary_case(
        results, "\"\\u004EATRAV_OVERLAY_PEER\"", true, false);
    protocol_boundary_case(
        results, "\"NATRAV_OVERLAY_P\\u00C9ER\"", false, false);
}

[[nodiscard]] NATravPeerHandshakeMessageKind expected_kind(
    const std::string_view candidate) noexcept {
    if (candidate == "HELLO") {
        return NATravPeerHandshakeMessageKind::hello;
    }
    if (candidate == "HELLO_ACK") {
        return NATravPeerHandshakeMessageKind::hello_ack;
    }
    if (candidate == "ERROR") {
        return NATravPeerHandshakeMessageKind::error;
    }
    return NATravPeerHandshakeMessageKind::unknown;
}

void discriminant_model_cases(Results& results) {
    constexpr std::string_view alphabet =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz0123456789";
    std::uint64_t state = 0xA0761D6478BD642FULL;
    for (std::size_t case_index = 0U; case_index < 65536U; ++case_index) {
        std::string candidate;
        switch (case_index % 8192U) {
            case 0U: candidate = "HELLO"; break;
            case 1U: candidate = "HELLO_ACK"; break;
            case 2U: candidate = "ERROR"; break;
            case 3U: candidate = "NATRAV_OVERLAY_PEER"; break;
            default: {
                state ^= state << 7U;
                state ^= state >> 9U;
                state ^= state << 8U;
                const std::size_t length =
                    static_cast<std::size_t>(state % 29U);
                candidate.reserve(length);
                for (std::size_t offset = 0U; offset < length; ++offset) {
                    state ^= state << 7U;
                    state ^= state >> 9U;
                    state ^= state << 8U;
                    candidate.push_back(alphabet[
                        static_cast<std::size_t>(state % alphabet.size())]);
                }
                break;
            }
        }

        datacube::CanonicalStringDiscriminantAccumulator kind(
            datacube::CanonicalStringDiscriminant::message_kind);
        datacube::CanonicalStringDiscriminantAccumulator protocol(
            datacube::CanonicalStringDiscriminant::protocol_id);
        for (const char character : candidate) {
            const std::uint32_t scalar = static_cast<std::uint32_t>(
                static_cast<unsigned char>(character));
            kind.observe(scalar);
            protocol.observe(scalar);
        }

        ++results.discriminant_model_cases;
        const bool kind_exact =
            kind.message_kind_result().value_or(
                NATravPeerHandshakeMessageKind::unknown) ==
            expected_kind(candidate);
        results.discriminant_model_checks += kind_exact ? 1U : 0U;
        check(results, kind_exact, "message_kind_discriminant_model");

        ++results.discriminant_model_cases;
        const bool protocol_exact =
            protocol.protocol_id_result().value_or(false) ==
                (candidate == "NATRAV_OVERLAY_PEER");
        results.discriminant_model_checks += protocol_exact ? 1U : 0U;
        check(results, protocol_exact, "protocol_id_discriminant_model");
    }
}

struct Baseline final {
    NATravPeerMessageDecodeObservation observation;
    Stats stats;
};

template <typename Decode>
[[nodiscard]] Baseline baseline_decode(
    const Octets& payload,
    Decode&& decode) {
    natrav_string_discriminant_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation;
    try {
        observation = decode(payload);
    } catch (...) {
        static_cast<void>(
            natrav_string_discriminant_allocation_test::disarm());
        throw;
    }
    const Stats stats =
        natrav_string_discriminant_allocation_test::disarm();
    return Baseline{
        .observation = std::move(observation),
        .stats = stats,
    };
}

template <typename Decode>
void inject_allocation_failures(
    Results& results,
    const Octets& payload,
    const Baseline& baseline,
    Decode&& decode,
    const bool current) {
    for (std::size_t point = 0U; point < baseline.stats.attempts; ++point) {
        const Octets before = payload;
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_string_discriminant_allocation_test::arm(point);
        try {
            static_cast<void>(decode(payload));
        } catch (const natrav_string_discriminant_allocation_test::
                     InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        } catch (...) {
        }
        static_cast<void>(
            natrav_string_discriminant_allocation_test::disarm());
        if (current) {
            ++results.injected_current_failures;
        } else {
            ++results.injected_historical_failures;
        }
        results.exception_type_checks += caught ? 1U : 0U;
        check(results, caught, "allocation_exception_type");
        const bool ordinal = caught_point == point;
        results.exception_ordinal_checks += ordinal ? 1U : 0U;
        check(results, ordinal, "allocation_exception_ordinal");
        const bool preserved = payload == before;
        results.input_preservation_checks += preserved ? 1U : 0U;
        check(results, preserved, "allocation_input_preserved");
        const NATravPeerMessageDecodeObservation retry = decode(payload);
        const bool retry_equal = same_observation(retry, baseline.observation);
        results.retry_checks += retry_equal ? 1U : 0U;
        check(results, retry_equal, "allocation_retry");
    }
}

void allocation_scenario(Results& results, const Octets& payload) {
    ++results.allocation_scenarios;
    const Baseline current = baseline_decode(
        payload,
        [](const Octets& value) {
            return datacube::natrav_peer_decode_message(value);
        });
    const Baseline historical = baseline_decode(
        payload,
        [](const Octets& value) {
            return datacube::natrav_peer_decode_message_revision_0479(value);
        });
    check(
        results,
        same_observation(current.observation, historical.observation),
        "allocation_baseline_semantics");
    results.current_allocation_attempts += current.stats.attempts;
    results.historical_allocation_attempts += historical.stats.attempts;
    results.current_allocated_bytes += current.stats.total_bytes;
    results.historical_allocated_bytes += historical.stats.total_bytes;
    results.current_maximum_allocation = std::max(
        results.current_maximum_allocation,
        current.stats.maximum_bytes);
    results.historical_maximum_allocation = std::max(
        results.historical_maximum_allocation,
        historical.stats.maximum_bytes);

    const bool attempts_equal =
        current.stats.attempts == historical.stats.attempts;
    results.allocation_equivalence_checks += attempts_equal ? 1U : 0U;
    check(results, attempts_equal, "allocation_attempt_equivalence");
    const bool bytes_equal =
        current.stats.total_bytes == historical.stats.total_bytes;
    results.allocation_equivalence_checks += bytes_equal ? 1U : 0U;
    check(results, bytes_equal, "allocation_byte_equivalence");
    const bool maximum_equal =
        current.stats.maximum_bytes == historical.stats.maximum_bytes;
    results.allocation_equivalence_checks += maximum_equal ? 1U : 0U;
    check(results, maximum_equal, "allocation_maximum_equivalence");

    inject_allocation_failures(
        results,
        payload,
        current,
        [](const Octets& value) {
            return datacube::natrav_peer_decode_message(value);
        },
        true);
    inject_allocation_failures(
        results,
        payload,
        historical,
        [](const Octets& value) {
            return datacube::natrav_peer_decode_message_revision_0479(value);
        },
        false);
}

void allocation_cases(Results& results) {
    NATravPeerHandshakeMessage hello = base_message(
        NATravPeerHandshakeMessageKind::hello, 2001U);
    hello.artifact.target.assign(4000U, 't');
    hello.artifact.version.assign(3000U, 'v');
    for (std::size_t index = 0U; index < 80U; ++index) {
        hello.required_capabilities.push_back(capability_name(index));
    }
    allocation_scenario(results, encode_message(results, hello));

    NATravPeerHandshakeMessage ack = base_message(
        NATravPeerHandshakeMessageKind::hello_ack, 2002U);
    for (std::size_t index = 0U; index < 100U; ++index) {
        ack.available_capabilities.push_back(capability_name(index));
    }
    allocation_scenario(results, encode_message(results, ack));

    NATravPeerHandshakeMessage error = base_message(
        NATravPeerHandshakeMessageKind::error, 2003U);
    error.error_message.assign(10000U, 'e');
    allocation_scenario(results, encode_message(results, error));
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    random_corpus(results);
    discriminant_boundary_cases(results);
    discriminant_model_cases(results);
    allocation_cases(results);

    const std::size_t injected_total =
        results.injected_current_failures +
        results.injected_historical_failures;
    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.retained_message_kind_reads ==
                results.eliminated_message_kind_rescans &&
            results.retained_protocol_id_reads ==
                results.eliminated_protocol_id_rescans &&
            results.eliminated_message_kind_rescans != 0U &&
            results.eliminated_protocol_id_rescans != 0U &&
            results.eliminated_message_kind_rescan_bytes != 0U &&
            results.eliminated_protocol_id_rescan_bytes != 0U &&
            results.discriminant_path_checks ==
                results.semantic_cases * 4U &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.discriminant_boundary_cases == 16U &&
            results.discriminant_boundary_checks == 16U &&
            results.discriminant_model_cases == 131072U &&
            results.discriminant_model_checks == 131072U &&
            results.allocation_equivalence_checks ==
                results.allocation_scenarios * 3U &&
            results.exception_type_checks == injected_total &&
            results.exception_ordinal_checks == injected_total &&
            results.input_preservation_checks == injected_total &&
            results.retry_checks == injected_total,
        "coverage_and_string_discriminant_retention_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(preflight_message_kind_captures);
    PRINT_RESULT(preflight_protocol_id_captures);
    PRINT_RESULT(retained_message_kind_reads);
    PRINT_RESULT(retained_protocol_id_reads);
    PRINT_RESULT(eliminated_message_kind_rescans);
    PRINT_RESULT(eliminated_protocol_id_rescans);
    PRINT_RESULT(eliminated_message_kind_rescan_bytes);
    PRINT_RESULT(eliminated_protocol_id_rescan_bytes);
    PRINT_RESULT(discriminant_path_checks);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(discriminant_boundary_cases);
    PRINT_RESULT(discriminant_boundary_checks);
    PRINT_RESULT(discriminant_model_cases);
    PRINT_RESULT(discriminant_model_checks);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(current_allocation_attempts);
    PRINT_RESULT(historical_allocation_attempts);
    PRINT_RESULT(current_allocated_bytes);
    PRINT_RESULT(historical_allocated_bytes);
    PRINT_RESULT(current_maximum_allocation);
    PRINT_RESULT(historical_maximum_allocation);
    PRINT_RESULT(allocation_equivalence_checks);
    PRINT_RESULT(injected_current_failures);
    PRINT_RESULT(injected_historical_failures);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_string_discriminant_retention_test

int main() {
    try {
        return natrav_string_discriminant_retention_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(
            natrav_string_discriminant_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_STRING_DISCRIMINANT_RETENTION_TEST

// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_SHAPE_MASK_RETENTION_TEST
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_shape_mask_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t injection_point) noexcept :
        point(injection_point) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_SHAPE_MASK_BAD_ALLOC";
    }
    std::size_t point;
};

struct Stats final {
    std::size_t attempts{0U};
    std::size_t total_bytes{0U};
    std::size_t maximum_bytes{0U};
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    Stats stats;
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .stats = {},
    };
}

[[nodiscard]] Stats disarm() noexcept {
    const Stats stats = state.stats;
    state.armed = false;
    return stats;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_shape_mask_allocation_test

void* operator new(const std::size_t size) {
    return natrav_shape_mask_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_shape_mask_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_shape_mask_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_shape_mask_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_shape_mask_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_shape_mask_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_shape_mask_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_shape_mask_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_shape_mask_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_shape_mask_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_shape_mask_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_shape_mask_allocation_test::release(pointer);
}


namespace natrav_shape_mask_retention_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_shape_mask_allocation_test::Stats;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t preflight_top_level_member_updates{0U};
    std::size_t preflight_protocol_member_updates{0U};
    std::size_t preflight_artifact_member_updates{0U};
    std::size_t preflight_top_level_kind_updates{0U};
    std::size_t preflight_protocol_kind_updates{0U};
    std::size_t preflight_artifact_kind_updates{0U};
    std::size_t retained_top_level_member_reads{0U};
    std::size_t retained_top_level_kind_reads{0U};
    std::size_t retained_protocol_shape_reads{0U};
    std::size_t retained_artifact_shape_reads{0U};
    std::size_t eliminated_top_level_member_checks{0U};
    std::size_t eliminated_top_level_kind_checks{0U};
    std::size_t eliminated_protocol_member_checks{0U};
    std::size_t eliminated_protocol_kind_checks{0U};
    std::size_t eliminated_artifact_member_checks{0U};
    std::size_t eliminated_artifact_kind_checks{0U};
    std::size_t shape_path_checks{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t current_allocation_attempts{0U};
    std::size_t historical_allocation_attempts{0U};
    std::size_t current_allocated_bytes{0U};
    std::size_t historical_allocated_bytes{0U};
    std::size_t current_maximum_allocation{0U};
    std::size_t historical_maximum_allocation{0U};
    std::size_t allocation_equivalence_checks{0U};
    std::size_t injected_current_failures{0U};
    std::size_t injected_historical_failures{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] Octets bytes(const std::string_view text) {
    Octets result;
    result.reserve(text.size());
    for (const char character : text) {
        result.push_back(static_cast<std::uint8_t>(
            static_cast<unsigned char>(character)));
    }
    return result;
}

[[nodiscard]] std::string text(const Octets& value) {
    return std::string(
        reinterpret_cast<const char*>(value.data()), value.size());
}

[[nodiscard]] std::string hex64(const std::uint64_t seed) {
    constexpr std::string_view digits = "0123456789abcdef";
    std::string result(64U, '0');
    std::uint64_t state = seed ^ 0x9E3779B97F4A7C15ULL;
    for (char& character : result) {
        state ^= state << 7U;
        state ^= state >> 9U;
        state ^= state << 8U;
        character = digits[static_cast<std::size_t>(state & 0x0FULL)];
    }
    return result;
}

[[nodiscard]] std::string capability_name(const std::size_t index) {
    const std::string digits = std::to_string(index);
    if (digits.size() > 4U) {
        throw std::runtime_error("capability-index-range");
    }
    std::string result = "C";
    result.append(4U - digits.size(), '0');
    result.append(digits);
    return result;
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::uint64_t seed) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = static_cast<std::int64_t>(seed % 97U),
    };
    message.request_id = hex64(seed);
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = hex64(seed ^ 0xA5A5A5A5A5A5A5A5ULL),
            .target = "linux-x86_64",
            .version = "v1",
        };
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "shape-mask-retention";
    }
    return message;
}

[[nodiscard]] Octets encode_message(
    Results& results,
    const NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    check(
        results,
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "fixture_encoding");
    return encoded.payload.value_or(Octets{});
}

struct CountedDecode final {
    NATravPeerMessageDecodeObservation observation;
    datacube::CanonicalShapeMaskRetentionCounters counters;
};

[[nodiscard]] CountedDecode current_decode(const Octets& payload) {
    datacube::reset_canonical_shape_mask_retention_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters = datacube::read_canonical_shape_mask_retention_counters(),
    };
}

[[nodiscard]] CountedDecode historical_decode(const Octets& payload) {
    datacube::reset_canonical_shape_mask_retention_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0480(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters = datacube::read_canonical_shape_mask_retention_counters(),
    };
}

void compare_case(
    Results& results,
    const Octets& payload,
    const bool random_case = false) {
    const CountedDecode current = current_decode(payload);
    const CountedDecode historical = historical_decode(payload);
    ++results.semantic_cases;
    results.random_cases += random_case ? 1U : 0U;

    const bool same = same_observation(
        current.observation, historical.observation);
    results.exact_observation_comparisons += same ? 1U : 0U;
    check(results, same, "semantic_equivalence");

    const auto& c = current.counters;
    const auto& h = historical.counters;
    const bool preflight_equal =
        c.preflight_top_level_member_updates ==
            h.preflight_top_level_member_updates &&
        c.preflight_protocol_member_updates ==
            h.preflight_protocol_member_updates &&
        c.preflight_artifact_member_updates ==
            h.preflight_artifact_member_updates &&
        c.preflight_top_level_kind_updates ==
            h.preflight_top_level_kind_updates &&
        c.preflight_protocol_kind_updates ==
            h.preflight_protocol_kind_updates &&
        c.preflight_artifact_kind_updates ==
            h.preflight_artifact_kind_updates;
    results.shape_path_checks += preflight_equal ? 1U : 0U;
    check(results, preflight_equal, "preflight_shape_capture_equivalence");

    const bool current_exclusive =
        c.historical_top_level_member_checks == 0U &&
        c.historical_top_level_kind_checks == 0U &&
        c.historical_protocol_member_checks == 0U &&
        c.historical_protocol_kind_checks == 0U &&
        c.historical_artifact_member_checks == 0U &&
        c.historical_artifact_kind_checks == 0U;
    results.shape_path_checks += current_exclusive ? 1U : 0U;
    check(results, current_exclusive, "current_uses_retained_shapes_only");

    const bool historical_exclusive =
        h.retained_top_level_member_reads == 0U &&
        h.retained_top_level_kind_reads == 0U &&
        h.retained_protocol_shape_reads == 0U &&
        h.retained_artifact_shape_reads == 0U;
    results.shape_path_checks += historical_exclusive ? 1U : 0U;
    check(results, historical_exclusive, "historical_uses_rechecks_only");

    const bool path_counts_exact =
        c.retained_top_level_member_reads ==
            h.historical_top_level_member_checks &&
        c.retained_protocol_shape_reads ==
            h.historical_protocol_member_checks &&
        c.retained_protocol_shape_reads ==
            h.historical_protocol_kind_checks &&
        c.retained_artifact_shape_reads ==
            h.historical_artifact_member_checks &&
        c.retained_artifact_shape_reads ==
            h.historical_artifact_kind_checks &&
        c.retained_top_level_kind_reads ==
            h.historical_top_level_kind_checks +
            h.historical_protocol_kind_checks +
            h.historical_artifact_kind_checks;
    results.shape_path_checks += path_counts_exact ? 1U : 0U;
    check(results, path_counts_exact, "retained_and_historical_path_counts");

    results.preflight_top_level_member_updates +=
        c.preflight_top_level_member_updates;
    results.preflight_protocol_member_updates +=
        c.preflight_protocol_member_updates;
    results.preflight_artifact_member_updates +=
        c.preflight_artifact_member_updates;
    results.preflight_top_level_kind_updates +=
        c.preflight_top_level_kind_updates;
    results.preflight_protocol_kind_updates +=
        c.preflight_protocol_kind_updates;
    results.preflight_artifact_kind_updates +=
        c.preflight_artifact_kind_updates;
    results.retained_top_level_member_reads +=
        c.retained_top_level_member_reads;
    results.retained_top_level_kind_reads +=
        c.retained_top_level_kind_reads;
    results.retained_protocol_shape_reads +=
        c.retained_protocol_shape_reads;
    results.retained_artifact_shape_reads +=
        c.retained_artifact_shape_reads;
    results.eliminated_top_level_member_checks +=
        h.historical_top_level_member_checks;
    results.eliminated_top_level_kind_checks +=
        h.historical_top_level_kind_checks;
    results.eliminated_protocol_member_checks +=
        h.historical_protocol_member_checks;
    results.eliminated_protocol_kind_checks +=
        h.historical_protocol_kind_checks;
    results.eliminated_artifact_member_checks +=
        h.historical_artifact_member_checks;
    results.eliminated_artifact_kind_checks +=
        h.historical_artifact_kind_checks;

    if (current.observation.status ==
        NATravPeerMessageDecodeStatus::accepted) {
        ++results.accepted_cases;
        check(results, current.observation.message.has_value(),
            "accepted_message_present");
        if (current.observation.message) {
            const auto encoded = datacube::natrav_peer_encode_message(
                *current.observation.message);
            const bool roundtrip =
                encoded.status == NATravPeerMessageEncodeStatus::accepted &&
                encoded.payload && *encoded.payload == payload;
            results.exact_roundtrips += roundtrip ? 1U : 0U;
            check(results, roundtrip, "accepted_roundtrip");
        }
    } else {
        ++results.rejection_cases;
    }
}

void accepted_corpus(Results& results) {
    for (std::size_t index = 0U; index < 256U; ++index) {
        const auto kind = static_cast<NATravPeerHandshakeMessageKind>(
            index % 3U);
        NATravPeerHandshakeMessage message = base_message(
            kind, static_cast<std::uint64_t>(index + 1U));
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            for (std::size_t entry = 0U; entry < index % 4U; ++entry) {
                message.required_capabilities.push_back(
                    capability_name(entry));
            }
        } else if (kind == NATravPeerHandshakeMessageKind::hello_ack) {
            for (std::size_t entry = 0U; entry < index % 5U; ++entry) {
                message.available_capabilities.push_back(
                    capability_name(entry));
            }
        } else {
            message.error_code = index % 2U == 0U ? "A" : "ERROR_CODE_9";
            message.error_message = index % 2U == 0U ?
                "error" : "error\nmessage";
        }
        compare_case(results, encode_message(results, message));
    }

    NATravPeerHandshakeMessage hello = base_message(
        NATravPeerHandshakeMessageKind::hello, 1001U);
    hello.artifact.target = "target\nwith\tescapes";
    hello.artifact.version = "v\xF0\x9F\x98\x80";
    compare_case(results, encode_message(results, hello));

    NATravPeerHandshakeMessage ack = base_message(
        NATravPeerHandshakeMessageKind::hello_ack, 1002U);
    ack.available_capabilities = {"A", "A_B", "Z9"};
    compare_case(results, encode_message(results, ack));

    NATravPeerHandshakeMessage error = base_message(
        NATravPeerHandshakeMessageKind::error, 1003U);
    error.error_code.assign(64U, 'A');
    error.error_message = "boundary";
    compare_case(results, encode_message(results, error));
}

void replace_once(
    std::string& value,
    const std::string_view before,
    const std::string_view after) {
    const std::size_t offset = value.find(before);
    if (offset == std::string::npos) {
        throw std::runtime_error("shape-mutation-source");
    }
    value.replace(offset, before.size(), after);
}

void priority_case(
    Results& results,
    const std::string& value,
    const NATravPeerMessageDecodeStatus expected) {
    ++results.classification_priority_cases;
    const Octets payload = bytes(value);
    const CountedDecode current = current_decode(payload);
    const bool exact = current.observation.status == expected;
    results.exact_classifications += exact ? 1U : 0U;
    check(results, exact, "classification_priority");
    compare_case(results, payload);
}

void priority_cases(Results& results) {
    NATravPeerHandshakeMessage hello_message = base_message(
        NATravPeerHandshakeMessageKind::hello, 7001U);
    hello_message.required_capabilities = {"A", "B"};
    const std::string hello = text(encode_message(results, hello_message));

    priority_case(results, hello.substr(0U, hello.size() - 1U),
        NATravPeerMessageDecodeStatus::malformed_json);
    priority_case(results, "[]",
        NATravPeerMessageDecodeStatus::schema_rejected);

    std::string value = hello;
    value.insert(1U, " ");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::noncanonical_json);

    value = hello;
    value.insert(value.size() - 1U, ",\"zzz\":0");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::schema_rejected);

    value = hello;
    const std::size_t artifact_end = value.find("},\"kind\"");
    if (artifact_end == std::string::npos) {
        throw std::runtime_error("artifact-boundary");
    }
    value.erase(1U, artifact_end + 2U - 1U);
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::schema_rejected);

    value = hello;
    const std::size_t artifact_start = value.find("\"artifact\":");
    const std::size_t artifact_close = value.find("},\"kind\"", artifact_start);
    if (artifact_start == std::string::npos ||
        artifact_close == std::string::npos) {
        throw std::runtime_error("artifact-shape");
    }
    value.replace(
        artifact_start,
        artifact_close + 1U - artifact_start,
        "\"artifact\":1");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);

    value = hello;
    replace_once(value, "\"kind\":\"HELLO\"", "\"kind\":1");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::message_kind_rejected);

    value = hello;
    const std::size_t protocol_start = value.find("\"protocol\":");
    const std::size_t protocol_close = value.find("},\"request_id\"", protocol_start);
    if (protocol_start == std::string::npos ||
        protocol_close == std::string::npos) {
        throw std::runtime_error("protocol-shape");
    }
    value.replace(
        protocol_start,
        protocol_close + 1U - protocol_start,
        "\"protocol\":1");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::protocol_mismatch);

    const std::string minor_field =
        std::string("\"minor\":") +
        std::to_string(hello_message.protocol.minor);
    value = hello;
    replace_once(value, minor_field, minor_field + ",\"zzz\":0");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::protocol_mismatch);

    value = hello;
    replace_once(value, std::string(",") + minor_field, "");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::protocol_mismatch);

    value = hello;
    replace_once(value, "\"major\":1", "\"major\":\"1\"");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::protocol_mismatch);

    value = hello;
    const std::string request = hello_message.request_id;
    replace_once(
        value,
        std::string("\"request_id\":\"") + request + "\"",
        "\"request_id\":1");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::request_id_rejected);

    value = hello;
    replace_once(value, "\"target\":\"linux-x86_64\"",
        "\"target\":1");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);

    value = hello;
    replace_once(value, ",\"version\":\"v1\"", "");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);

    value = hello;
    replace_once(value, "\"version\":\"v1\"",
        "\"version\":\"v1\",\"zzz\":0");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);

    value = hello;
    replace_once(value, "\"required_capabilities\":[\"A\",\"B\"]",
        "\"required_capabilities\":{}");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::capability_declaration_rejected);

    NATravPeerHandshakeMessage error_message = base_message(
        NATravPeerHandshakeMessageKind::error, 7002U);
    const std::string error = text(encode_message(results, error_message));

    value = error;
    replace_once(value, "\"code\":\"OPERATION_FAILED\"", "\"code\":1");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::schema_rejected);

    value = error;
    replace_once(value, "\"message\":\"shape-mask-retention\"",
        "\"message\":1");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::schema_rejected);
}

void random_corpus(Results& results) {
    std::uint64_t state = 0xD6E8FEB86659FD93ULL;
    for (std::size_t index = 0U; index < 4096U; ++index) {
        state ^= state << 7U;
        state ^= state >> 9U;
        state ^= state << 8U;
        const std::size_t size = 2U +
            static_cast<std::size_t>(state % 127U);
        Octets payload(size);
        for (std::size_t offset = 0U; offset < size; ++offset) {
            state ^= state << 7U;
            state ^= state >> 9U;
            state ^= state << 8U;
            payload[offset] = static_cast<std::uint8_t>(state & 0xFFU);
        }
        compare_case(results, payload, true);
    }
}

struct AllocationDecode final {
    NATravPeerMessageDecodeObservation observation;
    Stats stats;
};

[[nodiscard]] AllocationDecode measured_current(const Octets& payload) {
    natrav_shape_mask_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    const Stats stats = natrav_shape_mask_allocation_test::disarm();
    return AllocationDecode{
        .observation = std::move(observation),
        .stats = stats,
    };
}

[[nodiscard]] AllocationDecode measured_historical(const Octets& payload) {
    natrav_shape_mask_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0480(payload);
    const Stats stats = natrav_shape_mask_allocation_test::disarm();
    return AllocationDecode{
        .observation = std::move(observation),
        .stats = stats,
    };
}

void inject_path(
    Results& results,
    const Octets& payload,
    const NATravPeerMessageDecodeObservation& baseline,
    const std::size_t attempts,
    const bool historical) {
    for (std::size_t point = 0U; point < attempts; ++point) {
        const Octets before = payload;
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_shape_mask_allocation_test::arm(point);
        try {
            if (historical) {
                static_cast<void>(
                    datacube::natrav_peer_decode_message_revision_0480(payload));
            } else {
                static_cast<void>(datacube::natrav_peer_decode_message(payload));
            }
        } catch (const natrav_shape_mask_allocation_test::InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        }
        static_cast<void>(natrav_shape_mask_allocation_test::disarm());
        if (historical) {
            results.injected_historical_failures += caught ? 1U : 0U;
        } else {
            results.injected_current_failures += caught ? 1U : 0U;
        }
        results.exception_type_checks += caught ? 1U : 0U;
        check(results, caught, "allocation_exception_type");
        const bool ordinal = caught_point == point;
        results.exception_ordinal_checks += ordinal ? 1U : 0U;
        check(results, ordinal, "allocation_exception_ordinal");
        const bool preserved = payload == before;
        results.input_preservation_checks += preserved ? 1U : 0U;
        check(results, preserved, "allocation_input_preservation");
        const NATravPeerMessageDecodeObservation retry = historical ?
            datacube::natrav_peer_decode_message_revision_0480(payload) :
            datacube::natrav_peer_decode_message(payload);
        const bool retry_equal = same_observation(retry, baseline);
        results.retry_checks += retry_equal ? 1U : 0U;
        check(results, retry_equal, "allocation_retry");
    }
}

void allocation_scenario(Results& results, const Octets& payload) {
    ++results.allocation_scenarios;
    const AllocationDecode current = measured_current(payload);
    const AllocationDecode historical = measured_historical(payload);
    check(results, same_observation(current.observation, historical.observation),
        "allocation_semantic_equivalence");

    results.current_allocation_attempts += current.stats.attempts;
    results.historical_allocation_attempts += historical.stats.attempts;
    results.current_allocated_bytes += current.stats.total_bytes;
    results.historical_allocated_bytes += historical.stats.total_bytes;
    results.current_maximum_allocation = std::max(
        results.current_maximum_allocation, current.stats.maximum_bytes);
    results.historical_maximum_allocation = std::max(
        results.historical_maximum_allocation, historical.stats.maximum_bytes);

    const bool attempts_equal =
        current.stats.attempts == historical.stats.attempts;
    const bool bytes_equal =
        current.stats.total_bytes == historical.stats.total_bytes;
    const bool maximum_equal =
        current.stats.maximum_bytes == historical.stats.maximum_bytes;
    results.allocation_equivalence_checks += attempts_equal ? 1U : 0U;
    results.allocation_equivalence_checks += bytes_equal ? 1U : 0U;
    results.allocation_equivalence_checks += maximum_equal ? 1U : 0U;
    check(results, attempts_equal, "allocation_attempt_equivalence");
    check(results, bytes_equal, "allocation_byte_equivalence");
    check(results, maximum_equal, "allocation_maximum_equivalence");

    inject_path(
        results, payload, current.observation,
        current.stats.attempts, false);
    inject_path(
        results, payload, historical.observation,
        historical.stats.attempts, true);
}

void allocation_cases(Results& results) {
    NATravPeerHandshakeMessage hello = base_message(
        NATravPeerHandshakeMessageKind::hello, 8001U);
    hello.artifact.target.assign(4000U, 't');
    hello.artifact.version.assign(3000U, 'v');
    for (std::size_t index = 0U; index < 80U; ++index) {
        hello.required_capabilities.push_back(capability_name(index));
    }
    allocation_scenario(results, encode_message(results, hello));

    NATravPeerHandshakeMessage ack = base_message(
        NATravPeerHandshakeMessageKind::hello_ack, 8002U);
    for (std::size_t index = 0U; index < 100U; ++index) {
        ack.available_capabilities.push_back(capability_name(index));
    }
    allocation_scenario(results, encode_message(results, ack));

    NATravPeerHandshakeMessage error = base_message(
        NATravPeerHandshakeMessageKind::error, 8003U);
    error.error_message.assign(10000U, 'e');
    allocation_scenario(results, encode_message(results, error));
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    random_corpus(results);
    allocation_cases(results);

    const std::size_t injected_total =
        results.injected_current_failures +
        results.injected_historical_failures;
    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.preflight_top_level_member_updates != 0U &&
            results.preflight_protocol_member_updates != 0U &&
            results.preflight_artifact_member_updates != 0U &&
            results.preflight_top_level_kind_updates != 0U &&
            results.preflight_protocol_kind_updates != 0U &&
            results.preflight_artifact_kind_updates != 0U &&
            results.retained_top_level_member_reads ==
                results.eliminated_top_level_member_checks &&
            results.retained_protocol_shape_reads ==
                results.eliminated_protocol_member_checks &&
            results.retained_protocol_shape_reads ==
                results.eliminated_protocol_kind_checks &&
            results.retained_artifact_shape_reads ==
                results.eliminated_artifact_member_checks &&
            results.retained_artifact_shape_reads ==
                results.eliminated_artifact_kind_checks &&
            results.retained_top_level_kind_reads ==
                results.eliminated_top_level_kind_checks +
                results.eliminated_protocol_kind_checks +
                results.eliminated_artifact_kind_checks &&
            results.shape_path_checks == results.semantic_cases * 4U &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.allocation_equivalence_checks ==
                results.allocation_scenarios * 3U &&
            results.exception_type_checks == injected_total &&
            results.exception_ordinal_checks == injected_total &&
            results.input_preservation_checks == injected_total &&
            results.retry_checks == injected_total,
        "coverage_and_shape_mask_retention_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(preflight_top_level_member_updates);
    PRINT_RESULT(preflight_protocol_member_updates);
    PRINT_RESULT(preflight_artifact_member_updates);
    PRINT_RESULT(preflight_top_level_kind_updates);
    PRINT_RESULT(preflight_protocol_kind_updates);
    PRINT_RESULT(preflight_artifact_kind_updates);
    PRINT_RESULT(retained_top_level_member_reads);
    PRINT_RESULT(retained_top_level_kind_reads);
    PRINT_RESULT(retained_protocol_shape_reads);
    PRINT_RESULT(retained_artifact_shape_reads);
    PRINT_RESULT(eliminated_top_level_member_checks);
    PRINT_RESULT(eliminated_top_level_kind_checks);
    PRINT_RESULT(eliminated_protocol_member_checks);
    PRINT_RESULT(eliminated_protocol_kind_checks);
    PRINT_RESULT(eliminated_artifact_member_checks);
    PRINT_RESULT(eliminated_artifact_kind_checks);
    PRINT_RESULT(shape_path_checks);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(current_allocation_attempts);
    PRINT_RESULT(historical_allocation_attempts);
    PRINT_RESULT(current_allocated_bytes);
    PRINT_RESULT(historical_allocated_bytes);
    PRINT_RESULT(current_maximum_allocation);
    PRINT_RESULT(historical_maximum_allocation);
    PRINT_RESULT(allocation_equivalence_checks);
    PRINT_RESULT(injected_current_failures);
    PRINT_RESULT(injected_historical_failures);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_shape_mask_retention_test

int main() {
    try {
        return natrav_shape_mask_retention_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(natrav_shape_mask_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_SHAPE_MASK_RETENTION_TEST
#ifdef DATACUBE_NATRAV_MESSAGE_NONEMPTY_STRING_PREDICATE_RETENTION_TEST
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_nonempty_string_predicate_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t injection_point) noexcept :
        point(injection_point) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_NONEMPTY_STRING_PREDICATE_BAD_ALLOC";
    }
    std::size_t point;
};

struct Stats final {
    std::size_t attempts{0U};
    std::size_t total_bytes{0U};
    std::size_t maximum_bytes{0U};
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    Stats stats;
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .stats = {},
    };
}

[[nodiscard]] Stats disarm() noexcept {
    const Stats stats = state.stats;
    state.armed = false;
    return stats;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_nonempty_string_predicate_allocation_test

void* operator new(const std::size_t size) {
    return natrav_nonempty_string_predicate_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_nonempty_string_predicate_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_nonempty_string_predicate_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_nonempty_string_predicate_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_nonempty_string_predicate_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_nonempty_string_predicate_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_nonempty_string_predicate_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_nonempty_string_predicate_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_nonempty_string_predicate_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_nonempty_string_predicate_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_nonempty_string_predicate_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_nonempty_string_predicate_allocation_test::release(pointer);
}


namespace natrav_nonempty_string_predicate_retention_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_nonempty_string_predicate_allocation_test::Stats;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t preflight_artifact_target_captures{0U};
    std::size_t preflight_artifact_version_captures{0U};
    std::size_t preflight_peer_error_message_captures{0U};
    std::size_t retained_artifact_target_reads{0U};
    std::size_t retained_artifact_version_reads{0U};
    std::size_t retained_peer_error_message_reads{0U};
    std::size_t eliminated_artifact_target_token_size_checks{0U};
    std::size_t eliminated_artifact_version_token_size_checks{0U};
    std::size_t eliminated_peer_error_message_token_size_checks{0U};
    std::size_t predicate_path_checks{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t predicate_boundary_cases{0U};
    std::size_t predicate_boundary_checks{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t current_allocation_attempts{0U};
    std::size_t historical_allocation_attempts{0U};
    std::size_t current_allocated_bytes{0U};
    std::size_t historical_allocated_bytes{0U};
    std::size_t current_maximum_allocation{0U};
    std::size_t historical_maximum_allocation{0U};
    std::size_t allocation_equivalence_checks{0U};
    std::size_t injected_current_failures{0U};
    std::size_t injected_historical_failures{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] Octets bytes(const std::string_view text) {
    Octets result;
    result.reserve(text.size());
    for (const char character : text) {
        result.push_back(static_cast<std::uint8_t>(
            static_cast<unsigned char>(character)));
    }
    return result;
}

[[nodiscard]] std::string text(const Octets& value) {
    return std::string(
        reinterpret_cast<const char*>(value.data()), value.size());
}

[[nodiscard]] std::string hex64(const std::uint64_t seed) {
    constexpr std::string_view digits = "0123456789abcdef";
    std::string result(64U, '0');
    std::uint64_t state = seed ^ 0x9E3779B97F4A7C15ULL;
    for (char& character : result) {
        state ^= state << 7U;
        state ^= state >> 9U;
        state ^= state << 8U;
        character = digits[static_cast<std::size_t>(state & 0x0FULL)];
    }
    return result;
}

[[nodiscard]] std::string capability_name(const std::size_t index) {
    const std::string digits = std::to_string(index);
    if (digits.size() > 4U) {
        throw std::runtime_error("capability-index-range");
    }
    std::string result = "C";
    result.append(4U - digits.size(), '0');
    result.append(digits);
    return result;
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::uint64_t seed) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = static_cast<std::int64_t>(seed % 97U),
    };
    message.request_id = hex64(seed);
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = hex64(seed ^ 0xA5A5A5A5A5A5A5A5ULL),
            .target = "linux-x86_64",
            .version = "v1",
        };
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "nonempty-string-predicate-retention";
    }
    return message;
}

[[nodiscard]] Octets encode_message(
    Results& results,
    const NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    check(
        results,
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "fixture_encoding");
    return encoded.payload.value_or(Octets{});
}

struct CountedDecode final {
    NATravPeerMessageDecodeObservation observation;
    datacube::CanonicalNonemptyStringPredicateRetentionCounters counters;
};

[[nodiscard]] CountedDecode current_decode(const Octets& payload) {
    datacube::reset_canonical_nonempty_string_predicate_retention_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_nonempty_string_predicate_retention_counters(),
    };
}

[[nodiscard]] CountedDecode historical_decode(const Octets& payload) {
    datacube::reset_canonical_nonempty_string_predicate_retention_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0481(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_nonempty_string_predicate_retention_counters(),
    };
}

void compare_case(
    Results& results,
    const Octets& payload,
    const bool random_case = false) {
    const CountedDecode current = current_decode(payload);
    const CountedDecode historical = historical_decode(payload);
    ++results.semantic_cases;
    results.random_cases += random_case ? 1U : 0U;

    const bool same = same_observation(
        current.observation, historical.observation);
    results.exact_observation_comparisons += same ? 1U : 0U;
    check(results, same, "semantic_equivalence");

    const auto& c = current.counters;
    const auto& h = historical.counters;
    const bool preflight_equal =
        c.preflight_artifact_target_captures ==
            h.preflight_artifact_target_captures &&
        c.preflight_artifact_version_captures ==
            h.preflight_artifact_version_captures &&
        c.preflight_peer_error_message_captures ==
            h.preflight_peer_error_message_captures;
    results.predicate_path_checks += preflight_equal ? 1U : 0U;
    check(results, preflight_equal, "preflight_predicate_capture_equivalence");

    const bool current_exclusive =
        c.historical_artifact_target_token_size_checks == 0U &&
        c.historical_artifact_version_token_size_checks == 0U &&
        c.historical_peer_error_message_token_size_checks == 0U;
    results.predicate_path_checks += current_exclusive ? 1U : 0U;
    check(results, current_exclusive, "current_uses_retained_predicates_only");

    const bool historical_exclusive =
        h.retained_artifact_target_reads == 0U &&
        h.retained_artifact_version_reads == 0U &&
        h.retained_peer_error_message_reads == 0U;
    results.predicate_path_checks += historical_exclusive ? 1U : 0U;
    check(results, historical_exclusive, "historical_uses_token_size_checks_only");

    const bool path_counts_exact =
        c.retained_artifact_target_reads ==
            h.historical_artifact_target_token_size_checks &&
        c.retained_artifact_version_reads ==
            h.historical_artifact_version_token_size_checks &&
        c.retained_peer_error_message_reads ==
            h.historical_peer_error_message_token_size_checks;
    results.predicate_path_checks += path_counts_exact ? 1U : 0U;
    check(results, path_counts_exact, "retained_and_historical_path_counts");

    results.preflight_artifact_target_captures +=
        c.preflight_artifact_target_captures;
    results.preflight_artifact_version_captures +=
        c.preflight_artifact_version_captures;
    results.preflight_peer_error_message_captures +=
        c.preflight_peer_error_message_captures;
    results.retained_artifact_target_reads +=
        c.retained_artifact_target_reads;
    results.retained_artifact_version_reads +=
        c.retained_artifact_version_reads;
    results.retained_peer_error_message_reads +=
        c.retained_peer_error_message_reads;
    results.eliminated_artifact_target_token_size_checks +=
        h.historical_artifact_target_token_size_checks;
    results.eliminated_artifact_version_token_size_checks +=
        h.historical_artifact_version_token_size_checks;
    results.eliminated_peer_error_message_token_size_checks +=
        h.historical_peer_error_message_token_size_checks;

    if (current.observation.status ==
        NATravPeerMessageDecodeStatus::accepted) {
        ++results.accepted_cases;
        check(results, current.observation.message.has_value(),
            "accepted_message_present");
        if (current.observation.message) {
            const auto encoded = datacube::natrav_peer_encode_message(
                *current.observation.message);
            const bool roundtrip =
                encoded.status == NATravPeerMessageEncodeStatus::accepted &&
                encoded.payload && *encoded.payload == payload;
            results.exact_roundtrips += roundtrip ? 1U : 0U;
            check(results, roundtrip, "accepted_roundtrip");
        }
    } else {
        ++results.rejection_cases;
    }
}

void accepted_corpus(Results& results) {
    for (std::size_t index = 0U; index < 256U; ++index) {
        const auto kind = static_cast<NATravPeerHandshakeMessageKind>(
            index % 3U);
        NATravPeerHandshakeMessage message = base_message(
            kind, static_cast<std::uint64_t>(index + 1U));
        if (kind == NATravPeerHandshakeMessageKind::hello) {
            message.artifact.target = index % 2U == 0U ?
                "target" : "target\nwith\tescapes";
            message.artifact.version = index % 3U == 0U ?
                "v\xF0\x9F\x98\x80" : "v1";
            for (std::size_t entry = 0U; entry < index % 4U; ++entry) {
                message.required_capabilities.push_back(
                    capability_name(entry));
            }
        } else if (kind == NATravPeerHandshakeMessageKind::hello_ack) {
            message.artifact.target = index % 2U == 0U ?
                "ack-target" : "ack/target";
            message.artifact.version = index % 3U == 0U ?
                "release\n1" : "v2";
            for (std::size_t entry = 0U; entry < index % 5U; ++entry) {
                message.available_capabilities.push_back(
                    capability_name(entry));
            }
        } else {
            message.error_code = index % 2U == 0U ?
                "A" : "ERROR_CODE_9";
            message.error_message = index % 2U == 0U ?
                "error" : "error\nmessage";
        }
        compare_case(results, encode_message(results, message));
    }

    NATravPeerHandshakeMessage hello = base_message(
        NATravPeerHandshakeMessageKind::hello, 1001U);
    hello.artifact.target = "x";
    hello.artifact.version = "y";
    compare_case(results, encode_message(results, hello));

    NATravPeerHandshakeMessage ack = base_message(
        NATravPeerHandshakeMessageKind::hello_ack, 1002U);
    ack.artifact.target = "\xF0\x9F\x98\x80";
    ack.artifact.version = "\n";
    ack.available_capabilities = {"A", "A_B", "Z9"};
    compare_case(results, encode_message(results, ack));

    NATravPeerHandshakeMessage error = base_message(
        NATravPeerHandshakeMessageKind::error, 1003U);
    error.error_code.assign(64U, 'A');
    error.error_message = "z";
    compare_case(results, encode_message(results, error));
}

void replace_once(
    std::string& value,
    const std::string_view before,
    const std::string_view after) {
    const std::size_t offset = value.find(before);
    if (offset == std::string::npos) {
        throw std::runtime_error("nonempty-predicate-mutation-source");
    }
    value.replace(offset, before.size(), after);
}

void priority_case(
    Results& results,
    const std::string& value,
    const NATravPeerMessageDecodeStatus expected) {
    ++results.classification_priority_cases;
    const Octets payload = bytes(value);
    const CountedDecode current = current_decode(payload);
    const bool exact = current.observation.status == expected;
    results.exact_classifications += exact ? 1U : 0U;
    check(results, exact, "classification_priority");
    compare_case(results, payload);
}

void priority_cases(Results& results) {
    NATravPeerHandshakeMessage hello_message = base_message(
        NATravPeerHandshakeMessageKind::hello, 7001U);
    hello_message.required_capabilities = {"A", "B"};
    const std::string hello = text(encode_message(results, hello_message));

    priority_case(results, hello.substr(0U, hello.size() - 1U),
        NATravPeerMessageDecodeStatus::malformed_json);
    priority_case(results, "[]",
        NATravPeerMessageDecodeStatus::schema_rejected);

    std::string value = hello;
    value.insert(1U, " ");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::noncanonical_json);

    value = hello;
    replace_once(value, "\"target\":\"linux-x86_64\"",
        "\"target\":\"\\u006cinux-x86_64\"");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::noncanonical_json);

    value = hello;
    replace_once(value, "\"kind\":\"HELLO\"", "\"kind\":1");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::message_kind_rejected);

    value = hello;
    replace_once(value, "\"id\":\"NATRAV_OVERLAY_PEER\"",
        "\"id\":\"OTHER\"");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::protocol_mismatch);

    value = hello;
    const std::string request = hello_message.request_id;
    replace_once(value,
        std::string("\"request_id\":\"") + request + "\"",
        "\"request_id\":\"bad\"");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::request_id_rejected);

    value = hello;
    replace_once(value, "\"target\":\"linux-x86_64\"",
        "\"target\":\"\"");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);

    value = hello;
    replace_once(value, "\"version\":\"v1\"",
        "\"version\":\"\"");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);

    value = hello;
    replace_once(value, "\"target\":\"linux-x86_64\"",
        "\"target\":1");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);

    value = hello;
    replace_once(value, "\"version\":\"v1\"",
        "\"version\":1");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::artifact_identity_rejected);

    value = hello;
    replace_once(value, "\"required_capabilities\":[\"A\",\"B\"]",
        "\"required_capabilities\":[\"B\",\"A\"]");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::capability_declaration_rejected);

    NATravPeerHandshakeMessage error_message = base_message(
        NATravPeerHandshakeMessageKind::error, 7002U);
    const std::string error = text(encode_message(results, error_message));

    value = error;
    replace_once(value, "\"code\":\"OPERATION_FAILED\"",
        "\"code\":\"bad-code\"");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::schema_rejected);

    value = error;
    replace_once(value,
        "\"message\":\"nonempty-string-predicate-retention\"",
        "\"message\":\"\"");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::schema_rejected);

    value = error;
    replace_once(value,
        "\"message\":\"nonempty-string-predicate-retention\"",
        "\"message\":1");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::schema_rejected);

    value = error;
    replace_once(value,
        "\"message\":\"nonempty-string-predicate-retention\"",
        "\"message\":\"\\u006eonempty-string-predicate-retention\"");
    priority_case(results, value,
        NATravPeerMessageDecodeStatus::noncanonical_json);
}

void predicate_boundary_case(
    Results& results,
    NATravPeerHandshakeMessage message,
    const NATravPeerMessageDecodeStatus expected) {
    ++results.predicate_boundary_cases;
    const Octets payload = encode_message(results, message);
    const CountedDecode current = current_decode(payload);
    const bool exact = current.observation.status == expected;
    results.predicate_boundary_checks += exact ? 1U : 0U;
    check(results, exact, "predicate_boundary_status");
    compare_case(results, payload);
}

void predicate_boundary_cases(Results& results) {
    NATravPeerHandshakeMessage hello = base_message(
        NATravPeerHandshakeMessageKind::hello, 7101U);
    hello.artifact.target = "a";
    hello.artifact.version = "b";
    predicate_boundary_case(
        results, hello, NATravPeerMessageDecodeStatus::accepted);

    hello = base_message(NATravPeerHandshakeMessageKind::hello, 7102U);
    std::string empty_target = text(encode_message(results, hello));
    replace_once(
        empty_target,
        "\"target\":\"linux-x86_64\"",
        "\"target\":\"\"");
    ++results.predicate_boundary_cases;
    const Octets empty_target_payload = bytes(empty_target);
    const CountedDecode empty_target_decode =
        current_decode(empty_target_payload);
    const bool empty_target_exact =
        empty_target_decode.observation.status ==
        NATravPeerMessageDecodeStatus::artifact_identity_rejected;
    results.predicate_boundary_checks += empty_target_exact ? 1U : 0U;
    check(results, empty_target_exact, "empty_target_boundary_status");
    compare_case(results, empty_target_payload);

    NATravPeerHandshakeMessage ack = base_message(
        NATravPeerHandshakeMessageKind::hello_ack, 7103U);
    ack.artifact.target = "t";
    ack.artifact.version = "\xF0\x9F\x98\x80";
    predicate_boundary_case(
        results, ack, NATravPeerMessageDecodeStatus::accepted);

    NATravPeerHandshakeMessage error = base_message(
        NATravPeerHandshakeMessageKind::error, 7104U);
    error.error_message = "m";
    predicate_boundary_case(
        results, error, NATravPeerMessageDecodeStatus::accepted);
}

void random_corpus(Results& results) {
    std::uint64_t state = 0xA24BAED4963EE407ULL;
    for (std::size_t index = 0U; index < 4096U; ++index) {
        state ^= state << 7U;
        state ^= state >> 9U;
        state ^= state << 8U;
        const std::size_t size = 2U +
            static_cast<std::size_t>(state % 127U);
        Octets payload(size);
        for (std::size_t offset = 0U; offset < size; ++offset) {
            state ^= state << 7U;
            state ^= state >> 9U;
            state ^= state << 8U;
            payload[offset] = static_cast<std::uint8_t>(state & 0xFFU);
        }
        compare_case(results, payload, true);
    }
}

struct AllocationDecode final {
    NATravPeerMessageDecodeObservation observation;
    Stats stats;
};

[[nodiscard]] AllocationDecode measured_current(const Octets& payload) {
    natrav_nonempty_string_predicate_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    const Stats stats =
        natrav_nonempty_string_predicate_allocation_test::disarm();
    return AllocationDecode{
        .observation = std::move(observation),
        .stats = stats,
    };
}

[[nodiscard]] AllocationDecode measured_historical(const Octets& payload) {
    natrav_nonempty_string_predicate_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0481(payload);
    const Stats stats =
        natrav_nonempty_string_predicate_allocation_test::disarm();
    return AllocationDecode{
        .observation = std::move(observation),
        .stats = stats,
    };
}

void inject_path(
    Results& results,
    const Octets& payload,
    const NATravPeerMessageDecodeObservation& baseline,
    const std::size_t attempts,
    const bool historical) {
    for (std::size_t point = 0U; point < attempts; ++point) {
        const Octets before = payload;
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_nonempty_string_predicate_allocation_test::arm(point);
        try {
            if (historical) {
                static_cast<void>(
                    datacube::natrav_peer_decode_message_revision_0481(payload));
            } else {
                static_cast<void>(datacube::natrav_peer_decode_message(payload));
            }
        } catch (const natrav_nonempty_string_predicate_allocation_test::InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        }
        static_cast<void>(
            natrav_nonempty_string_predicate_allocation_test::disarm());
        if (historical) {
            results.injected_historical_failures += caught ? 1U : 0U;
        } else {
            results.injected_current_failures += caught ? 1U : 0U;
        }
        results.exception_type_checks += caught ? 1U : 0U;
        check(results, caught, "allocation_exception_type");
        const bool ordinal = caught_point == point;
        results.exception_ordinal_checks += ordinal ? 1U : 0U;
        check(results, ordinal, "allocation_exception_ordinal");
        const bool preserved = payload == before;
        results.input_preservation_checks += preserved ? 1U : 0U;
        check(results, preserved, "allocation_input_preservation");
        const NATravPeerMessageDecodeObservation retry = historical ?
            datacube::natrav_peer_decode_message_revision_0481(payload) :
            datacube::natrav_peer_decode_message(payload);
        const bool retry_equal = same_observation(retry, baseline);
        results.retry_checks += retry_equal ? 1U : 0U;
        check(results, retry_equal, "allocation_retry");
    }
}

void allocation_scenario(Results& results, const Octets& payload) {
    ++results.allocation_scenarios;
    const AllocationDecode current = measured_current(payload);
    const AllocationDecode historical = measured_historical(payload);
    check(results, same_observation(current.observation, historical.observation),
        "allocation_semantic_equivalence");

    results.current_allocation_attempts += current.stats.attempts;
    results.historical_allocation_attempts += historical.stats.attempts;
    results.current_allocated_bytes += current.stats.total_bytes;
    results.historical_allocated_bytes += historical.stats.total_bytes;
    results.current_maximum_allocation = std::max(
        results.current_maximum_allocation, current.stats.maximum_bytes);
    results.historical_maximum_allocation = std::max(
        results.historical_maximum_allocation, historical.stats.maximum_bytes);

    const bool attempts_equal =
        current.stats.attempts == historical.stats.attempts;
    const bool bytes_equal =
        current.stats.total_bytes == historical.stats.total_bytes;
    const bool maximum_equal =
        current.stats.maximum_bytes == historical.stats.maximum_bytes;
    results.allocation_equivalence_checks += attempts_equal ? 1U : 0U;
    results.allocation_equivalence_checks += bytes_equal ? 1U : 0U;
    results.allocation_equivalence_checks += maximum_equal ? 1U : 0U;
    check(results, attempts_equal, "allocation_attempt_equivalence");
    check(results, bytes_equal, "allocation_byte_equivalence");
    check(results, maximum_equal, "allocation_maximum_equivalence");

    inject_path(
        results, payload, current.observation,
        current.stats.attempts, false);
    inject_path(
        results, payload, historical.observation,
        historical.stats.attempts, true);
}

void allocation_cases(Results& results) {
    NATravPeerHandshakeMessage hello = base_message(
        NATravPeerHandshakeMessageKind::hello, 8001U);
    hello.artifact.target.assign(4000U, 't');
    hello.artifact.version.assign(3000U, 'v');
    for (std::size_t index = 0U; index < 80U; ++index) {
        hello.required_capabilities.push_back(capability_name(index));
    }
    allocation_scenario(results, encode_message(results, hello));

    NATravPeerHandshakeMessage ack = base_message(
        NATravPeerHandshakeMessageKind::hello_ack, 8002U);
    ack.artifact.target.assign(2000U, 'a');
    ack.artifact.version.assign(1000U, 'b');
    for (std::size_t index = 0U; index < 100U; ++index) {
        ack.available_capabilities.push_back(capability_name(index));
    }
    allocation_scenario(results, encode_message(results, ack));

    NATravPeerHandshakeMessage error = base_message(
        NATravPeerHandshakeMessageKind::error, 8003U);
    error.error_message.assign(10000U, 'e');
    allocation_scenario(results, encode_message(results, error));
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    predicate_boundary_cases(results);
    random_corpus(results);
    allocation_cases(results);

    const std::size_t injected_total =
        results.injected_current_failures +
        results.injected_historical_failures;
    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.preflight_artifact_target_captures != 0U &&
            results.preflight_artifact_version_captures != 0U &&
            results.preflight_peer_error_message_captures != 0U &&
            results.retained_artifact_target_reads ==
                results.eliminated_artifact_target_token_size_checks &&
            results.retained_artifact_version_reads ==
                results.eliminated_artifact_version_token_size_checks &&
            results.retained_peer_error_message_reads ==
                results.eliminated_peer_error_message_token_size_checks &&
            results.retained_artifact_target_reads != 0U &&
            results.retained_artifact_version_reads != 0U &&
            results.retained_peer_error_message_reads != 0U &&
            results.predicate_path_checks == results.semantic_cases * 4U &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.predicate_boundary_cases == 4U &&
            results.predicate_boundary_checks == 4U &&
            results.allocation_equivalence_checks ==
                results.allocation_scenarios * 3U &&
            results.exception_type_checks == injected_total &&
            results.exception_ordinal_checks == injected_total &&
            results.input_preservation_checks == injected_total &&
            results.retry_checks == injected_total,
        "coverage_and_nonempty_string_predicate_retention_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(preflight_artifact_target_captures);
    PRINT_RESULT(preflight_artifact_version_captures);
    PRINT_RESULT(preflight_peer_error_message_captures);
    PRINT_RESULT(retained_artifact_target_reads);
    PRINT_RESULT(retained_artifact_version_reads);
    PRINT_RESULT(retained_peer_error_message_reads);
    PRINT_RESULT(eliminated_artifact_target_token_size_checks);
    PRINT_RESULT(eliminated_artifact_version_token_size_checks);
    PRINT_RESULT(eliminated_peer_error_message_token_size_checks);
    PRINT_RESULT(predicate_path_checks);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(predicate_boundary_cases);
    PRINT_RESULT(predicate_boundary_checks);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(current_allocation_attempts);
    PRINT_RESULT(historical_allocation_attempts);
    PRINT_RESULT(current_allocated_bytes);
    PRINT_RESULT(historical_allocated_bytes);
    PRINT_RESULT(current_maximum_allocation);
    PRINT_RESULT(historical_maximum_allocation);
    PRINT_RESULT(allocation_equivalence_checks);
    PRINT_RESULT(injected_current_failures);
    PRINT_RESULT(injected_historical_failures);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_nonempty_string_predicate_retention_test

int main() {
    try {
        return natrav_nonempty_string_predicate_retention_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(
            natrav_nonempty_string_predicate_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_NONEMPTY_STRING_PREDICATE_RETENTION_TEST
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_READINESS_RETENTION_TEST
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_capability_readiness_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t injection_point) noexcept :
        point(injection_point) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_CAPABILITY_READINESS_BAD_ALLOC";
    }
    std::size_t point;
};

struct Stats final {
    std::size_t attempts{0U};
    std::size_t total_bytes{0U};
    std::size_t maximum_bytes{0U};
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    Stats stats;
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .stats = {},
    };
}

[[nodiscard]] Stats disarm() noexcept {
    const Stats stats = state.stats;
    state.armed = false;
    return stats;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_capability_readiness_allocation_test

void* operator new(const std::size_t size) {
    return natrav_capability_readiness_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_capability_readiness_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_capability_readiness_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_capability_readiness_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_capability_readiness_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_capability_readiness_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_readiness_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_readiness_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_readiness_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_readiness_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_readiness_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_readiness_allocation_test::release(pointer);
}

namespace natrav_capability_readiness_retention_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_capability_readiness_allocation_test::Stats;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t preflight_available_readiness_captures{0U};
    std::size_t preflight_required_readiness_captures{0U};
    std::size_t retained_projection_readiness_reads{0U};
    std::size_t retained_construction_readiness_reads{0U};
    std::size_t eliminated_projection_array_presence_checks{0U};
    std::size_t eliminated_projection_validity_checks{0U};
    std::size_t eliminated_projection_span_completeness_checks{0U};
    std::size_t eliminated_projection_count_consistency_checks{0U};
    std::size_t eliminated_construction_array_presence_checks{0U};
    std::size_t eliminated_construction_validity_checks{0U};
    std::size_t eliminated_construction_span_completeness_checks{0U};
    std::size_t eliminated_construction_count_consistency_checks{0U};
    std::size_t readiness_path_cases{0U};
    std::size_t readiness_counter_checks{0U};
    std::size_t readiness_counter_matches{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t readiness_boundary_cases{0U};
    std::size_t readiness_boundary_checks{0U};
    std::size_t span_integrity_cases{0U};
    std::size_t span_integrity_checks{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t current_allocation_attempts{0U};
    std::size_t historical_allocation_attempts{0U};
    std::size_t current_allocated_bytes{0U};
    std::size_t historical_allocated_bytes{0U};
    std::size_t current_maximum_allocation{0U};
    std::size_t historical_maximum_allocation{0U};
    std::size_t allocation_equivalence_checks{0U};
    std::size_t injected_current_failures{0U};
    std::size_t injected_historical_failures{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

struct ReadinessExpectation final {
    bool enabled{false};
    std::size_t available_captures{0U};
    std::size_t required_captures{0U};
    std::size_t projection_reads{0U};
    std::size_t construction_reads{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::int64_t minor = 0) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = minor,
    };
    message.request_id.assign(64U, 'a');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = std::string(64U, 'b'),
            .target = "linux-x86_64",
            .version = "v1",
        };
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "capability-readiness-retention";
    }
    return message;
}

[[nodiscard]] std::string capability_name(
    const std::size_t index,
    const bool long_form = false) {
    std::string digits = std::to_string(index);
    if (digits.size() > 4U) {
        throw std::runtime_error("capability-index-range");
    }
    std::string token = "C";
    token.append(4U - digits.size(), '0');
    token.append(digits);
    if (long_form) {
        token.append(64U - token.size(), 'X');
    }
    return token;
}

[[nodiscard]] Octets encode_message(
    Results& results,
    const NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    check(
        results,
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "fixture_encoding");
    return encoded.payload.value_or(Octets{});
}

[[nodiscard]] std::size_t capability_count(
    const NATravPeerHandshakeMessage& message) noexcept {
    if (message.kind == NATravPeerHandshakeMessageKind::hello) {
        return message.required_capabilities.size();
    }
    if (message.kind == NATravPeerHandshakeMessageKind::hello_ack) {
        return message.available_capabilities.size();
    }
    return 0U;
}

struct CountedDecode final {
    NATravPeerMessageDecodeObservation observation;
    datacube::CanonicalCapabilityReadinessRetentionCounters counters;
};

[[nodiscard]] CountedDecode current_decode(const Octets& payload) {
    datacube::reset_canonical_capability_readiness_retention_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters = datacube::
            read_canonical_capability_readiness_retention_counters(),
    };
}

[[nodiscard]] CountedDecode historical_decode(const Octets& payload) {
    datacube::reset_canonical_capability_readiness_retention_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0482(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters = datacube::
            read_canonical_capability_readiness_retention_counters(),
    };
}

void check_counter(
    Results& results,
    const std::size_t actual,
    const std::size_t expected,
    const char* const label) noexcept {
    ++results.readiness_counter_checks;
    const bool exact = actual == expected;
    results.readiness_counter_matches += exact ? 1U : 0U;
    check(results, exact, label);
}

[[nodiscard]] ReadinessExpectation accepted_readiness(
    const NATravPeerHandshakeMessageKind kind) noexcept {
    if (kind == NATravPeerHandshakeMessageKind::hello) {
        return ReadinessExpectation{
            .enabled = true,
            .available_captures = 0U,
            .required_captures = 1U,
            .projection_reads = 1U,
            .construction_reads = 1U,
        };
    }
    if (kind == NATravPeerHandshakeMessageKind::hello_ack) {
        return ReadinessExpectation{
            .enabled = true,
            .available_captures = 1U,
            .required_captures = 0U,
            .projection_reads = 1U,
            .construction_reads = 1U,
        };
    }
    return ReadinessExpectation{.enabled = true};
}

void check_readiness_path(
    Results& results,
    const CountedDecode& current,
    const CountedDecode& historical,
    const ReadinessExpectation expectation) noexcept {
    if (!expectation.enabled) {
        return;
    }
    ++results.readiness_path_cases;

    check_counter(
        results,
        current.counters.preflight_available_readiness_captures,
        expectation.available_captures,
        "current_available_capture");
    check_counter(
        results,
        current.counters.preflight_required_readiness_captures,
        expectation.required_captures,
        "current_required_capture");
    check_counter(
        results,
        current.counters.retained_projection_readiness_reads,
        expectation.projection_reads,
        "current_projection_read");
    check_counter(
        results,
        current.counters.retained_construction_readiness_reads,
        expectation.construction_reads,
        "current_construction_read");
    check_counter(
        results,
        current.counters.historical_projection_array_presence_checks,
        0U,
        "current_no_historical_projection_presence");
    check_counter(
        results,
        current.counters.historical_projection_validity_checks,
        0U,
        "current_no_historical_projection_validity");
    check_counter(
        results,
        current.counters.historical_projection_span_completeness_checks,
        0U,
        "current_no_historical_projection_spans");
    check_counter(
        results,
        current.counters.historical_projection_count_consistency_checks,
        0U,
        "current_no_historical_projection_count");
    check_counter(
        results,
        current.counters.historical_construction_array_presence_checks,
        0U,
        "current_no_historical_construction_presence");
    check_counter(
        results,
        current.counters.historical_construction_validity_checks,
        0U,
        "current_no_historical_construction_validity");
    check_counter(
        results,
        current.counters.historical_construction_span_completeness_checks,
        0U,
        "current_no_historical_construction_spans");
    check_counter(
        results,
        current.counters.historical_construction_count_consistency_checks,
        0U,
        "current_no_historical_construction_count");

    check_counter(
        results,
        historical.counters.preflight_available_readiness_captures,
        expectation.available_captures,
        "historical_available_capture");
    check_counter(
        results,
        historical.counters.preflight_required_readiness_captures,
        expectation.required_captures,
        "historical_required_capture");
    check_counter(
        results,
        historical.counters.retained_projection_readiness_reads,
        0U,
        "historical_no_retained_projection");
    check_counter(
        results,
        historical.counters.retained_construction_readiness_reads,
        0U,
        "historical_no_retained_construction");
    check_counter(
        results,
        historical.counters.historical_projection_array_presence_checks,
        expectation.projection_reads,
        "historical_projection_presence");
    check_counter(
        results,
        historical.counters.historical_projection_validity_checks,
        expectation.projection_reads,
        "historical_projection_validity");
    check_counter(
        results,
        historical.counters.historical_projection_span_completeness_checks,
        expectation.projection_reads,
        "historical_projection_spans");
    check_counter(
        results,
        historical.counters.historical_projection_count_consistency_checks,
        expectation.projection_reads,
        "historical_projection_count");
    check_counter(
        results,
        historical.counters.historical_construction_array_presence_checks,
        expectation.construction_reads,
        "historical_construction_presence");
    check_counter(
        results,
        historical.counters.historical_construction_validity_checks,
        expectation.construction_reads,
        "historical_construction_validity");
    check_counter(
        results,
        historical.counters.historical_construction_span_completeness_checks,
        expectation.construction_reads,
        "historical_construction_spans");
    check_counter(
        results,
        historical.counters.historical_construction_count_consistency_checks,
        expectation.construction_reads,
        "historical_construction_count");
}

void compare_semantics(
    Results& results,
    const Octets& payload,
    const std::optional<NATravPeerMessageDecodeStatus> expected = std::nullopt,
    const ReadinessExpectation readiness = {}) {
    const CountedDecode current = current_decode(payload);
    const CountedDecode historical = historical_decode(payload);
    ++results.semantic_cases;
    const bool equal = same_observation(
        current.observation, historical.observation);
    results.exact_observation_comparisons += equal ? 1U : 0U;
    check(results, equal, "exact_observation_match");

    results.preflight_available_readiness_captures +=
        current.counters.preflight_available_readiness_captures;
    results.preflight_required_readiness_captures +=
        current.counters.preflight_required_readiness_captures;
    results.retained_projection_readiness_reads +=
        current.counters.retained_projection_readiness_reads;
    results.retained_construction_readiness_reads +=
        current.counters.retained_construction_readiness_reads;
    results.eliminated_projection_array_presence_checks +=
        historical.counters.historical_projection_array_presence_checks;
    results.eliminated_projection_validity_checks +=
        historical.counters.historical_projection_validity_checks;
    results.eliminated_projection_span_completeness_checks +=
        historical.counters.historical_projection_span_completeness_checks;
    results.eliminated_projection_count_consistency_checks +=
        historical.counters.historical_projection_count_consistency_checks;
    results.eliminated_construction_array_presence_checks +=
        historical.counters.historical_construction_array_presence_checks;
    results.eliminated_construction_validity_checks +=
        historical.counters.historical_construction_validity_checks;
    results.eliminated_construction_span_completeness_checks +=
        historical.counters.historical_construction_span_completeness_checks;
    results.eliminated_construction_count_consistency_checks +=
        historical.counters.historical_construction_count_consistency_checks;

    check_readiness_path(results, current, historical, readiness);

    if (expected) {
        ++results.classification_priority_cases;
        const bool exact = current.observation.status == *expected;
        results.exact_classifications += exact ? 1U : 0U;
        check(results, exact, "exact_expected_classification");
    }

    if (current.observation.status != NATravPeerMessageDecodeStatus::accepted ||
        !current.observation.message) {
        ++results.rejection_cases;
        return;
    }

    ++results.accepted_cases;
    const auto encoded = datacube::natrav_peer_encode_message(
        *current.observation.message);
    const bool roundtrip =
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
        encoded.payload && *encoded.payload == payload;
    results.exact_roundtrips += roundtrip ? 1U : 0U;
    check(results, roundtrip, "exact_roundtrip");
}

void accepted_corpus(Results& results) {
    NATravPeerHandshakeMessage hello =
        base_message(NATravPeerHandshakeMessageKind::hello);
    compare_semantics(
        results,
        encode_message(results, hello),
        std::nullopt,
        accepted_readiness(hello.kind));

    hello.required_capabilities = {"A", "B_2", "OMEGA"};
    compare_semantics(
        results,
        encode_message(results, hello),
        std::nullopt,
        accepted_readiness(hello.kind));

    NATravPeerHandshakeMessage ack =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 7);
    ack.available_capabilities = {"A", "B_2", "OMEGA"};
    compare_semantics(
        results,
        encode_message(results, ack),
        std::nullopt,
        accepted_readiness(ack.kind));

    NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error, 19);
    compare_semantics(
        results,
        encode_message(results, error),
        std::nullopt,
        accepted_readiness(error.kind));

    NATravPeerHandshakeMessage large =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 23);
    large.available_capabilities.reserve(7000U);
    for (std::size_t index = 0U; index < 7000U; ++index) {
        large.available_capabilities.push_back(capability_name(index));
    }
    compare_semantics(
        results,
        encode_message(results, large),
        std::nullopt,
        accepted_readiness(large.kind));

    for (std::size_t fixture = 0U; fixture < 128U; ++fixture) {
        const NATravPeerHandshakeMessageKind kind = fixture % 2U == 0U ?
            NATravPeerHandshakeMessageKind::hello :
            NATravPeerHandshakeMessageKind::hello_ack;
        NATravPeerHandshakeMessage message = base_message(
            kind, static_cast<std::int64_t>(fixture));
        const std::size_t count = fixture % 33U;
        std::vector<std::string>& capabilities =
            kind == NATravPeerHandshakeMessageKind::hello ?
                message.required_capabilities :
                message.available_capabilities;
        capabilities.reserve(count);
        for (std::size_t index = 0U; index < count; ++index) {
            capabilities.push_back(capability_name(index));
        }
        compare_semantics(
            results,
            encode_message(results, message),
            std::nullopt,
            accepted_readiness(kind));
    }
}

[[nodiscard]] std::string payload_text(const Octets& payload) {
    std::string text;
    text.reserve(payload.size());
    for (const std::uint8_t byte : payload) {
        text.push_back(static_cast<char>(byte));
    }
    return text;
}

[[nodiscard]] Octets payload_bytes(const std::string_view text) {
    Octets payload;
    payload.reserve(text.size());
    for (const char character : text) {
        payload.push_back(static_cast<std::uint8_t>(
            static_cast<unsigned char>(character)));
    }
    return payload;
}

[[nodiscard]] Octets replace_once(
    const Octets& payload,
    const std::string_view before,
    const std::string_view after) {
    std::string text = payload_text(payload);
    const std::size_t offset = text.find(before);
    if (offset == std::string::npos) {
        throw std::runtime_error("fixture-replacement-missing");
    }
    text.replace(offset, before.size(), after);
    return payload_bytes(text);
}

void priority_cases(Results& results) {
    NATravPeerHandshakeMessage message =
        base_message(NATravPeerHandshakeMessageKind::hello);
    message.required_capabilities = {"A", "B"};
    const Octets valid = encode_message(results, message);
    const ReadinessExpectation invalid_array{
        .enabled = true,
        .available_captures = 0U,
        .required_captures = 1U,
        .projection_reads = 1U,
        .construction_reads = 0U,
    };
    const ReadinessExpectation captured_but_not_projected{
        .enabled = true,
        .available_captures = 0U,
        .required_captures = 1U,
        .projection_reads = 0U,
        .construction_reads = 0U,
    };
    const ReadinessExpectation no_capability_array{.enabled = true};

    compare_semantics(
        results,
        replace_once(valid, "[\"A\",\"B\"]", "[\"B\",\"A\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected,
        invalid_array);
    compare_semantics(
        results,
        replace_once(valid, "[\"A\",\"B\"]", "[\"A\",\"A\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected,
        invalid_array);
    compare_semantics(
        results,
        replace_once(valid, "[\"A\",\"B\"]", "[\"A\",1]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected,
        invalid_array);
    compare_semantics(
        results,
        replace_once(valid, "[\"A\",\"B\"]", "{}"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected,
        no_capability_array);
    compare_semantics(
        results,
        replace_once(valid, "\"major\":1", "\"major\":2"),
        NATravPeerMessageDecodeStatus::protocol_mismatch,
        captured_but_not_projected);
    compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'a'), std::string(64U, 'z')),
        NATravPeerMessageDecodeStatus::request_id_rejected,
        captured_but_not_projected);
    compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'b'),
                     std::string("z") + std::string(63U, 'b')),
        NATravPeerMessageDecodeStatus::artifact_identity_rejected,
        captured_but_not_projected);
    compare_semantics(
        results,
        replace_once(valid, "\"HELLO\"", "\"OTHER\""),
        NATravPeerMessageDecodeStatus::message_kind_rejected,
        captured_but_not_projected);
    compare_semantics(
        results,
        replace_once(valid, "},\"kind\":", "},\"extra\":0,\"kind\":"),
        NATravPeerMessageDecodeStatus::schema_rejected,
        captured_but_not_projected);

    std::string malformed = payload_text(valid);
    malformed.pop_back();
    compare_semantics(
        results,
        payload_bytes(malformed),
        NATravPeerMessageDecodeStatus::malformed_json);
    compare_semantics(
        results,
        payload_bytes(std::string(" ") + payload_text(valid)),
        NATravPeerMessageDecodeStatus::noncanonical_json,
        captured_but_not_projected);
    compare_semantics(
        results,
        payload_bytes("[]"),
        NATravPeerMessageDecodeStatus::schema_rejected,
        no_capability_array);
}

void random_corpus(Results& results) {
    std::uint64_t state = 0x9e3779b97f4a7c15ULL;
    for (std::size_t fixture = 0U; fixture < 4096U; ++fixture) {
        state ^= state << 13U;
        state ^= state >> 7U;
        state ^= state << 17U;
        const std::size_t length = 2U +
            static_cast<std::size_t>(state % 191U);
        Octets payload;
        payload.reserve(length);
        for (std::size_t index = 0U; index < length; ++index) {
            state ^= state << 13U;
            state ^= state >> 7U;
            state ^= state << 17U;
            payload.push_back(static_cast<std::uint8_t>(state & 0xFFU));
        }
        compare_semantics(results, payload);
        ++results.random_cases;
    }
}

void readiness_and_span_integrity_cases(Results& results) {
    datacube::CanonicalCapabilityFieldIndex index{
        .array_seen = true,
        .valid = true,
        .spans_complete = true,
        .count = 2U,
        .span_begin = 0U,
        .span_count = 2U,
        .previous = "B",
        .ready = true,
    };

    ++results.readiness_boundary_cases;
    const bool ready = datacube::capability_projection_ready(index);
    results.readiness_boundary_checks += ready ? 1U : 0U;
    check(results, ready, "direct_ready_true");

    ++results.readiness_boundary_cases;
    index.ready = false;
    const bool retained_false = !datacube::capability_projection_ready(index);
    results.readiness_boundary_checks += retained_false ? 1U : 0U;
    check(results, retained_false, "direct_ready_false");

    ++results.readiness_boundary_cases;
    index.ready.reset();
    const bool retained_absent = !datacube::capability_projection_ready(index);
    results.readiness_boundary_checks += retained_absent ? 1U : 0U;
    check(results, retained_absent, "direct_ready_absent");

    index.ready = true;
    const std::string text = "[\"A\",\"B\"]";
    const datacube::CanonicalJsonSpan array_value{
        .kind = datacube::JsonValue::Kind::array,
        .bytes = text,
        .decoded_string_bytes = std::nullopt,
    };
    datacube::CanonicalCapabilityEntrySpanStorage spans;
    static_cast<void>(spans.append(datacube::CanonicalCapabilityEntrySpan{
        .content_offset = 2U,
        .content_size = 1U,
    }));
    static_cast<void>(spans.append(datacube::CanonicalCapabilityEntrySpan{
        .content_offset = 6U,
        .content_size = 1U,
    }));

    ++results.span_integrity_cases;
    const std::vector<std::string> decoded =
        datacube::decode_indexed_capabilities(
            text, array_value, index, spans);
    const bool valid = decoded == std::vector<std::string>{"A", "B"};
    results.span_integrity_checks += valid ? 1U : 0U;
    check(results, valid, "direct_span_projection");

    ++results.readiness_boundary_cases;
    index.ready = false;
    bool readiness_rejected = false;
    try {
        static_cast<void>(datacube::decode_indexed_capabilities(
            text, array_value, index, spans));
    } catch (const datacube::Failure& error) {
        readiness_rejected = error.code() ==
            "natrav-peer-message-indexed-capability-span";
    }
    results.readiness_boundary_checks += readiness_rejected ? 1U : 0U;
    check(results, readiness_rejected, "construction_ready_false");
    index.ready = true;

    ++results.span_integrity_cases;
    datacube::CanonicalCapabilityFieldIndex inconsistent = index;
    inconsistent.count = 3U;
    bool count_integrity = false;
    try {
        static_cast<void>(datacube::decode_indexed_capabilities(
            text, array_value, inconsistent, spans));
    } catch (const datacube::Failure& error) {
        count_integrity = error.code() ==
            "natrav-peer-message-indexed-capability-span";
    }
    results.span_integrity_checks += count_integrity ? 1U : 0U;
    check(results, count_integrity, "retained_count_integrity");

    const std::array<std::uint16_t, 3U> invalid_offsets{1U, 5U, 9U};
    for (const std::uint16_t invalid_offset : invalid_offsets) {
        ++results.span_integrity_cases;
        datacube::CanonicalCapabilityEntrySpanStorage invalid;
        static_cast<void>(invalid.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = 2U,
                .content_size = 1U,
            }));
        static_cast<void>(invalid.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = invalid_offset,
                .content_size = 1U,
            }));
        bool exact = false;
        try {
            static_cast<void>(datacube::decode_indexed_capabilities(
                text, array_value, index, invalid));
        } catch (const datacube::Failure& error) {
            exact = error.code() ==
                "natrav-peer-message-indexed-capability-span";
        }
        results.span_integrity_checks += exact ? 1U : 0U;
        check(results, exact, "direct_span_integrity_failure");
    }
}

struct Baseline final {
    NATravPeerMessageDecodeObservation observation;
    Stats stats;
};

template <typename Decode>
[[nodiscard]] Baseline baseline_decode(
    const Octets& payload,
    Decode&& decode) {
    natrav_capability_readiness_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation;
    try {
        observation = decode(payload);
    } catch (...) {
        static_cast<void>(
            natrav_capability_readiness_allocation_test::disarm());
        throw;
    }
    const Stats stats = natrav_capability_readiness_allocation_test::disarm();
    return Baseline{
        .observation = std::move(observation),
        .stats = stats,
    };
}

template <typename Decode>
void inject_allocation_failures(
    Results& results,
    const Octets& payload,
    const Baseline& baseline,
    Decode&& decode,
    const bool current) {
    for (std::size_t point = 0U; point < baseline.stats.attempts; ++point) {
        const Octets before = payload;
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_capability_readiness_allocation_test::arm(point);
        try {
            static_cast<void>(decode(payload));
        } catch (const natrav_capability_readiness_allocation_test::
                     InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        } catch (...) {
        }
        static_cast<void>(
            natrav_capability_readiness_allocation_test::disarm());
        if (current) {
            ++results.injected_current_failures;
        } else {
            ++results.injected_historical_failures;
        }
        results.exception_type_checks += caught ? 1U : 0U;
        check(results, caught, "allocation_exception_type");
        const bool ordinal = caught_point == point;
        results.exception_ordinal_checks += ordinal ? 1U : 0U;
        check(results, ordinal, "allocation_exception_ordinal");
        const bool preserved = payload == before;
        results.input_preservation_checks += preserved ? 1U : 0U;
        check(results, preserved, "allocation_input_preserved");
        const NATravPeerMessageDecodeObservation retry = decode(payload);
        const bool retry_equal = same_observation(retry, baseline.observation);
        results.retry_checks += retry_equal ? 1U : 0U;
        check(results, retry_equal, "allocation_retry");
    }
}

void allocation_scenario(Results& results, const Octets& payload) {
    ++results.allocation_scenarios;
    const Baseline current = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        });
    const Baseline historical = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0482(bytes);
        });
    check(
        results,
        same_observation(current.observation, historical.observation),
        "allocation_baseline_semantics");
    results.current_allocation_attempts += current.stats.attempts;
    results.historical_allocation_attempts += historical.stats.attempts;
    results.current_allocated_bytes += current.stats.total_bytes;
    results.historical_allocated_bytes += historical.stats.total_bytes;
    results.current_maximum_allocation = std::max(
        results.current_maximum_allocation, current.stats.maximum_bytes);
    results.historical_maximum_allocation = std::max(
        results.historical_maximum_allocation,
        historical.stats.maximum_bytes);

    const bool attempts_equal =
        current.stats.attempts == historical.stats.attempts;
    results.allocation_equivalence_checks += attempts_equal ? 1U : 0U;
    check(results, attempts_equal, "allocation_attempt_equivalence");
    const bool bytes_equal =
        current.stats.total_bytes == historical.stats.total_bytes;
    results.allocation_equivalence_checks += bytes_equal ? 1U : 0U;
    check(results, bytes_equal, "allocation_byte_equivalence");
    const bool maximum_equal =
        current.stats.maximum_bytes == historical.stats.maximum_bytes;
    results.allocation_equivalence_checks += maximum_equal ? 1U : 0U;
    check(results, maximum_equal, "allocation_maximum_equivalence");

    inject_allocation_failures(
        results,
        payload,
        current,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        },
        true);
    inject_allocation_failures(
        results,
        payload,
        historical,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0482(bytes);
        },
        false);
}

void allocation_cases(Results& results) {
    NATravPeerHandshakeMessage message =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 31);
    message.available_capabilities.reserve(100U);
    for (std::size_t index = 0U; index < 100U; ++index) {
        message.available_capabilities.push_back(
            capability_name(index, true));
    }
    allocation_scenario(results, encode_message(results, message));

    NATravPeerHandshakeMessage empty =
        base_message(NATravPeerHandshakeMessageKind::hello);
    allocation_scenario(results, encode_message(results, empty));
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    random_corpus(results);
    readiness_and_span_integrity_cases(results);
    allocation_cases(results);

    const std::size_t injected_total =
        results.injected_current_failures +
        results.injected_historical_failures;
    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.readiness_counter_matches ==
                results.readiness_counter_checks &&
            results.readiness_path_cases > 130U &&
            results.retained_projection_readiness_reads > 130U &&
            results.retained_construction_readiness_reads > 125U &&
            results.eliminated_projection_array_presence_checks ==
                results.eliminated_projection_validity_checks &&
            results.eliminated_projection_array_presence_checks ==
                results.eliminated_projection_span_completeness_checks &&
            results.eliminated_projection_array_presence_checks ==
                results.eliminated_projection_count_consistency_checks &&
            results.eliminated_construction_array_presence_checks ==
                results.eliminated_construction_validity_checks &&
            results.eliminated_construction_array_presence_checks ==
                results.eliminated_construction_span_completeness_checks &&
            results.eliminated_construction_array_presence_checks ==
                results.eliminated_construction_count_consistency_checks &&
            results.readiness_boundary_cases ==
                results.readiness_boundary_checks &&
            results.span_integrity_cases == results.span_integrity_checks &&
            results.span_integrity_cases == 5U &&
            results.allocation_equivalence_checks ==
                results.allocation_scenarios * 3U &&
            results.exception_type_checks == injected_total &&
            results.exception_ordinal_checks == injected_total &&
            results.input_preservation_checks == injected_total &&
            results.retry_checks == injected_total,
        "coverage_and_readiness_retention_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(preflight_available_readiness_captures);
    PRINT_RESULT(preflight_required_readiness_captures);
    PRINT_RESULT(retained_projection_readiness_reads);
    PRINT_RESULT(retained_construction_readiness_reads);
    PRINT_RESULT(eliminated_projection_array_presence_checks);
    PRINT_RESULT(eliminated_projection_validity_checks);
    PRINT_RESULT(eliminated_projection_span_completeness_checks);
    PRINT_RESULT(eliminated_projection_count_consistency_checks);
    PRINT_RESULT(eliminated_construction_array_presence_checks);
    PRINT_RESULT(eliminated_construction_validity_checks);
    PRINT_RESULT(eliminated_construction_span_completeness_checks);
    PRINT_RESULT(eliminated_construction_count_consistency_checks);
    PRINT_RESULT(readiness_path_cases);
    PRINT_RESULT(readiness_counter_checks);
    PRINT_RESULT(readiness_counter_matches);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(readiness_boundary_cases);
    PRINT_RESULT(readiness_boundary_checks);
    PRINT_RESULT(span_integrity_cases);
    PRINT_RESULT(span_integrity_checks);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(current_allocation_attempts);
    PRINT_RESULT(historical_allocation_attempts);
    PRINT_RESULT(current_allocated_bytes);
    PRINT_RESULT(historical_allocated_bytes);
    PRINT_RESULT(current_maximum_allocation);
    PRINT_RESULT(historical_maximum_allocation);
    PRINT_RESULT(allocation_equivalence_checks);
    PRINT_RESULT(injected_current_failures);
    PRINT_RESULT(injected_historical_failures);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_capability_readiness_retention_test

int main() {
    try {
        return natrav_capability_readiness_retention_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(
            natrav_capability_readiness_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_CAPABILITY_READINESS_RETENTION_TEST

// Opt-in local regression only: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_STORAGE_TEST
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_capability_span_storage_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t injection_point) noexcept :
        point(injection_point) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_CAPABILITY_SPAN_STORAGE_BAD_ALLOC";
    }
    std::size_t point;
};

struct Stats final {
    std::size_t attempts{0U};
    std::size_t total_bytes{0U};
    std::size_t maximum_bytes{0U};
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    Stats stats;
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .stats = {},
    };
}

[[nodiscard]] Stats disarm() noexcept {
    const Stats stats = state.stats;
    state.armed = false;
    return stats;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_capability_span_storage_allocation_test

void* operator new(const std::size_t size) {
    return natrav_capability_span_storage_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_capability_span_storage_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_capability_span_storage_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_capability_span_storage_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_capability_span_storage_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_capability_span_storage_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_span_storage_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_span_storage_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_span_storage_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_span_storage_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_span_storage_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_span_storage_allocation_test::release(pointer);
}

namespace natrav_capability_span_storage_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_capability_span_storage_allocation_test::Stats;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t current_storage_instances{0U};
    std::size_t current_inline_appends{0U};
    std::size_t current_spill_appends{0U};
    std::size_t current_spill_activations{0U};
    std::size_t current_spill_reservations{0U};
    std::size_t current_spill_reserved_capacity{0U};
    std::size_t current_maximum_spill_capacity{0U};
    std::size_t current_inline_reads{0U};
    std::size_t current_spill_reads{0U};
    std::size_t historical_storage_instances{0U};
    std::size_t historical_appends{0U};
    std::size_t historical_reads{0U};
    std::size_t common_case_zero_spill_cases{0U};
    std::size_t common_case_zero_spill_checks{0U};
    std::size_t spill_path_cases{0U};
    std::size_t spill_path_checks{0U};
    std::size_t storage_boundary_cases{0U};
    std::size_t storage_boundary_checks{0U};
    std::size_t inline_capacity{0U};
    std::size_t current_storage_bytes{0U};
    std::size_t historical_fixed_storage_bytes{0U};
    std::size_t storage_bytes_reduced{0U};
    std::size_t current_preflight_observation_bytes{0U};
    std::size_t historical_estimated_preflight_observation_bytes{0U};
    std::size_t preflight_bytes_reduced{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t current_allocation_attempts{0U};
    std::size_t historical_allocation_attempts{0U};
    std::size_t current_allocated_bytes{0U};
    std::size_t historical_allocated_bytes{0U};
    std::size_t current_maximum_allocation{0U};
    std::size_t historical_maximum_allocation{0U};
    std::size_t measured_extra_spill_allocations{0U};
    std::size_t measured_extra_spill_bytes{0U};
    std::size_t allocation_relation_checks{0U};
    std::size_t injected_current_failures{0U};
    std::size_t injected_historical_failures{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::int64_t minor = 0) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = minor,
    };
    message.request_id.assign(64U, 'a');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = std::string(64U, 'b'),
            .target = "linux-x86_64",
            .version = "v1",
        };
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "capability-span-storage";
    }
    return message;
}

[[nodiscard]] std::string capability_name(const std::size_t index) {
    std::string digits = std::to_string(index);
    if (digits.size() > 4U) {
        throw std::runtime_error("capability-index-range");
    }
    std::string token = "C";
    token.append(4U - digits.size(), '0');
    token.append(digits);
    return token;
}

void fill_capabilities(
    NATravPeerHandshakeMessage& message,
    const std::size_t count) {
    std::vector<std::string>& capabilities =
        message.kind == NATravPeerHandshakeMessageKind::hello ?
            message.required_capabilities :
            message.available_capabilities;
    capabilities.reserve(count);
    for (std::size_t index = 0U; index < count; ++index) {
        capabilities.push_back(capability_name(index));
    }
}

[[nodiscard]] Octets encode_message(
    Results& results,
    const NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    check(
        results,
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "fixture_encoding");
    return encoded.payload.value_or(Octets{});
}

struct CountedDecode final {
    NATravPeerMessageDecodeObservation observation;
    datacube::CanonicalCapabilitySpanStorageCounters counters;
};

[[nodiscard]] CountedDecode current_decode(const Octets& payload) {
    datacube::reset_canonical_capability_span_storage_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_capability_span_storage_counters(),
    };
}

[[nodiscard]] CountedDecode historical_decode(const Octets& payload) {
    datacube::reset_canonical_capability_span_storage_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0483(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_capability_span_storage_counters(),
    };
}

void accumulate_current(
    Results& results,
    const datacube::CanonicalCapabilitySpanStorageCounters& counters) {
    results.current_storage_instances += counters.storage_instances;
    results.current_inline_appends += counters.inline_appends;
    results.current_spill_appends += counters.spill_appends;
    results.current_spill_activations += counters.spill_activations;
    results.current_spill_reservations += counters.spill_reservations;
    results.current_spill_reserved_capacity +=
        counters.spill_reserved_capacity;
    results.current_maximum_spill_capacity = std::max(
        results.current_maximum_spill_capacity,
        counters.maximum_spill_capacity);
    results.current_inline_reads += counters.inline_reads;
    results.current_spill_reads += counters.spill_reads;
}

void accumulate_historical(
    Results& results,
    const datacube::CanonicalCapabilitySpanStorageCounters& counters) {
    results.historical_storage_instances += counters.storage_instances;
    results.historical_appends += counters.historical_appends;
    results.historical_reads += counters.historical_reads;
}

[[nodiscard]] CountedDecode compare_semantics(
    Results& results,
    const Octets& payload,
    const std::optional<NATravPeerMessageDecodeStatus> expected =
        std::nullopt) {
    CountedDecode current = current_decode(payload);
    const CountedDecode historical = historical_decode(payload);
    ++results.semantic_cases;
    accumulate_current(results, current.counters);
    accumulate_historical(results, historical.counters);

    const bool equal = same_observation(
        current.observation, historical.observation);
    results.exact_observation_comparisons += equal ? 1U : 0U;
    check(results, equal, "exact_observation_match");

    if (expected) {
        ++results.classification_priority_cases;
        const bool exact = current.observation.status == *expected;
        results.exact_classifications += exact ? 1U : 0U;
        check(results, exact, "exact_expected_classification");
    }

    if (current.observation.status != NATravPeerMessageDecodeStatus::accepted ||
        !current.observation.message) {
        ++results.rejection_cases;
        return current;
    }

    ++results.accepted_cases;
    const auto encoded = datacube::natrav_peer_encode_message(
        *current.observation.message);
    const bool roundtrip =
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
        encoded.payload && *encoded.payload == payload;
    results.exact_roundtrips += roundtrip ? 1U : 0U;
    check(results, roundtrip, "exact_roundtrip");
    return current;
}

void check_zero_spill_case(
    Results& results,
    const CountedDecode& decoded,
    const std::size_t expected_inline) {
    ++results.common_case_zero_spill_cases;
    const bool exact =
        decoded.counters.inline_appends == expected_inline &&
        decoded.counters.spill_appends == 0U &&
        decoded.counters.spill_activations == 0U &&
        decoded.counters.spill_reservations == 0U &&
        decoded.counters.maximum_spill_capacity == 0U;
    results.common_case_zero_spill_checks += exact ? 1U : 0U;
    check(results, exact, "common_case_zero_spill");
}

void check_spill_case(
    Results& results,
    const CountedDecode& decoded,
    const std::size_t expected_spill,
    const std::size_t expected_reservations,
    const std::size_t expected_maximum_capacity) {
    ++results.spill_path_cases;
    const bool exact =
        decoded.counters.inline_appends ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        decoded.counters.spill_appends == expected_spill &&
        decoded.counters.spill_activations == 1U &&
        decoded.counters.spill_reservations == expected_reservations &&
        decoded.counters.maximum_spill_capacity ==
            expected_maximum_capacity &&
        decoded.counters.inline_reads ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        decoded.counters.spill_reads == expected_spill;
    results.spill_path_checks += exact ? 1U : 0U;
    check(results, exact, "spill_path_exact");
}

void accepted_corpus(Results& results) {
    NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error, 1);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, error)),
        0U);

    NATravPeerHandshakeMessage empty =
        base_message(NATravPeerHandshakeMessageKind::hello, 2);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, empty)),
        0U);

    NATravPeerHandshakeMessage one =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 3);
    fill_capabilities(one, 1U);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, one)),
        1U);

    NATravPeerHandshakeMessage inline_boundary =
        base_message(NATravPeerHandshakeMessageKind::hello, 4);
    fill_capabilities(
        inline_boundary,
        datacube::kNATravPeerInlineCapabilitySpanCapacity);
    check_zero_spill_case(
        results,
        compare_semantics(
            results, encode_message(results, inline_boundary)),
        datacube::kNATravPeerInlineCapabilitySpanCapacity);

    NATravPeerHandshakeMessage first_spill =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 5);
    fill_capabilities(
        first_spill,
        datacube::kNATravPeerInlineCapabilitySpanCapacity + 1U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, first_spill)),
        1U,
        1U,
        datacube::kNATravPeerInlineCapabilitySpanCapacity);

    NATravPeerHandshakeMessage large =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 6);
    fill_capabilities(large, 7000U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, large)),
        7000U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        8U,
        8192U);

    for (std::size_t fixture = 0U; fixture < 128U; ++fixture) {
        const NATravPeerHandshakeMessageKind kind = fixture % 2U == 0U ?
            NATravPeerHandshakeMessageKind::hello :
            NATravPeerHandshakeMessageKind::hello_ack;
        NATravPeerHandshakeMessage message = base_message(
            kind, static_cast<std::int64_t>(fixture + 10U));
        fill_capabilities(message, fixture % 96U);
        static_cast<void>(compare_semantics(
            results, encode_message(results, message)));
    }
}

[[nodiscard]] std::string payload_text(const Octets& payload) {
    std::string text;
    text.reserve(payload.size());
    for (const std::uint8_t byte : payload) {
        text.push_back(static_cast<char>(byte));
    }
    return text;
}

[[nodiscard]] Octets payload_bytes(const std::string_view text) {
    Octets payload;
    payload.reserve(text.size());
    for (const char character : text) {
        payload.push_back(static_cast<std::uint8_t>(
            static_cast<unsigned char>(character)));
    }
    return payload;
}

[[nodiscard]] Octets replace_once(
    const Octets& payload,
    const std::string_view before,
    const std::string_view after) {
    std::string text = payload_text(payload);
    const std::size_t offset = text.find(before);
    if (offset == std::string::npos) {
        throw std::runtime_error("fixture-replacement-missing");
    }
    text.replace(offset, before.size(), after);
    return payload_bytes(text);
}

void priority_cases(Results& results) {
    NATravPeerHandshakeMessage message =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(message, 2U);
    const Octets valid = encode_message(results, message);

    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0001\",\"C0000\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0000\",\"C0000\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0000\",1]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "\"major\":1", "\"major\":2"),
        NATravPeerMessageDecodeStatus::protocol_mismatch));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'a'), std::string(64U, 'z')),
        NATravPeerMessageDecodeStatus::request_id_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'b'),
                     std::string("z") + std::string(63U, 'b')),
        NATravPeerMessageDecodeStatus::artifact_identity_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "\"HELLO\"", "\"OTHER\""),
        NATravPeerMessageDecodeStatus::message_kind_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "},\"kind\":", "},\"extra\":0,\"kind\":"),
        NATravPeerMessageDecodeStatus::schema_rejected));

    std::string malformed = payload_text(valid);
    malformed.pop_back();
    static_cast<void>(compare_semantics(
        results,
        payload_bytes(malformed),
        NATravPeerMessageDecodeStatus::malformed_json));
    static_cast<void>(compare_semantics(
        results,
        payload_bytes(std::string(" ") + payload_text(valid)),
        NATravPeerMessageDecodeStatus::noncanonical_json));
    static_cast<void>(compare_semantics(
        results,
        payload_bytes("[]"),
        NATravPeerMessageDecodeStatus::schema_rejected));
}

void random_corpus(Results& results) {
    std::uint64_t state = 0xd1b54a32d192ed03ULL;
    for (std::size_t fixture = 0U; fixture < 4096U; ++fixture) {
        state ^= state << 13U;
        state ^= state >> 7U;
        state ^= state << 17U;
        const std::size_t length = 2U +
            static_cast<std::size_t>(state % 191U);
        Octets payload;
        payload.reserve(length);
        for (std::size_t index = 0U; index < length; ++index) {
            state ^= state << 13U;
            state ^= state >> 7U;
            state ^= state << 17U;
            payload.push_back(static_cast<std::uint8_t>(state & 0xFFU));
        }
        static_cast<void>(compare_semantics(results, payload));
        ++results.random_cases;
    }
}

void direct_storage_boundaries(Results& results) {
    results.inline_capacity =
        datacube::kNATravPeerInlineCapabilitySpanCapacity;
    results.current_storage_bytes =
        sizeof(datacube::CanonicalCapabilityEntrySpanStorage);
    results.historical_fixed_storage_bytes = sizeof(std::array<
        datacube::CanonicalCapabilityEntrySpan,
        datacube::kNATravPeerMaximumJsonConstructionUnits>);
    results.storage_bytes_reduced =
        results.historical_fixed_storage_bytes - results.current_storage_bytes;
    results.current_preflight_observation_bytes =
        sizeof(datacube::CanonicalMessagePreflightObservation);
    results.historical_estimated_preflight_observation_bytes =
        results.current_preflight_observation_bytes +
        results.storage_bytes_reduced;
    results.preflight_bytes_reduced = results.storage_bytes_reduced;

    ++results.storage_boundary_cases;
    const bool footprint =
        results.inline_capacity == 64U &&
        results.current_storage_bytes <= 320U &&
        results.historical_fixed_storage_bytes == 65536U &&
        results.storage_bytes_reduced >= 65000U;
    results.storage_boundary_checks += footprint ? 1U : 0U;
    check(results, footprint, "storage_footprint");

    datacube::reset_canonical_capability_span_storage_counters();
    datacube::CanonicalCapabilityEntrySpanStorage storage;
    bool appended = true;
    for (std::size_t index = 0U;
         index < datacube::kNATravPeerMaximumJsonConstructionUnits;
         ++index) {
        appended = appended && storage.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = static_cast<std::uint16_t>(index),
                .content_size = 1U,
            });
    }
    const bool rejected_extra = !storage.append(
        datacube::CanonicalCapabilityEntrySpan{
            .content_offset = 0U,
            .content_size = 0U,
        });
    const auto counters =
        datacube::read_canonical_capability_span_storage_counters();

    ++results.storage_boundary_cases;
    const bool maximum_exact =
        appended && rejected_extra &&
        storage.size() == datacube::kNATravPeerMaximumJsonConstructionUnits &&
        storage.inline_size() ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        storage.spill_size() ==
            datacube::kNATravPeerMaximumJsonConstructionUnits -
                datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        storage.spill_capacity() == storage.spill_size() &&
        counters.spill_activations == 1U &&
        counters.spill_reservations == 9U &&
        counters.maximum_spill_capacity == storage.spill_size();
    results.storage_boundary_checks += maximum_exact ? 1U : 0U;
    check(results, maximum_exact, "storage_maximum_boundary");

    ++results.storage_boundary_cases;
    const bool reads_exact =
        storage.at(0U).content_offset == 0U &&
        storage.at(datacube::kNATravPeerInlineCapabilitySpanCapacity - 1U)
                .content_offset ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity - 1U &&
        storage.at(datacube::kNATravPeerInlineCapabilitySpanCapacity)
                .content_offset ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        storage.at(datacube::kNATravPeerMaximumJsonConstructionUnits - 1U)
                .content_offset ==
            datacube::kNATravPeerMaximumJsonConstructionUnits - 1U;
    results.storage_boundary_checks += reads_exact ? 1U : 0U;
    check(results, reads_exact, "storage_boundary_reads");
}

struct Baseline final {
    NATravPeerMessageDecodeObservation observation;
    Stats stats;
};

template <typename Decode>
[[nodiscard]] Baseline baseline_decode(
    const Octets& payload,
    Decode&& decode) {
    natrav_capability_span_storage_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation;
    try {
        observation = decode(payload);
    } catch (...) {
        static_cast<void>(
            natrav_capability_span_storage_allocation_test::disarm());
        throw;
    }
    const Stats stats =
        natrav_capability_span_storage_allocation_test::disarm();
    return Baseline{
        .observation = std::move(observation),
        .stats = stats,
    };
}

template <typename Decode>
void inject_allocation_failures(
    Results& results,
    const Octets& payload,
    const Baseline& baseline,
    Decode&& decode,
    const bool current) {
    for (std::size_t point = 0U; point < baseline.stats.attempts; ++point) {
        const Octets before = payload;
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_capability_span_storage_allocation_test::arm(point);
        try {
            static_cast<void>(decode(payload));
        } catch (const natrav_capability_span_storage_allocation_test::
                     InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        } catch (...) {
        }
        static_cast<void>(
            natrav_capability_span_storage_allocation_test::disarm());
        if (current) {
            ++results.injected_current_failures;
        } else {
            ++results.injected_historical_failures;
        }
        results.exception_type_checks += caught ? 1U : 0U;
        check(results, caught, "allocation_exception_type");
        const bool ordinal = caught_point == point;
        results.exception_ordinal_checks += ordinal ? 1U : 0U;
        check(results, ordinal, "allocation_exception_ordinal");
        const bool preserved = payload == before;
        results.input_preservation_checks += preserved ? 1U : 0U;
        check(results, preserved, "allocation_input_preserved");
        const NATravPeerMessageDecodeObservation retry = decode(payload);
        const bool retry_equal = same_observation(retry, baseline.observation);
        results.retry_checks += retry_equal ? 1U : 0U;
        check(results, retry_equal, "allocation_retry");
    }
}

void allocation_scenario(
    Results& results,
    const Octets& payload,
    const std::size_t expected_extra_attempts,
    const std::size_t expected_extra_bytes) {
    ++results.allocation_scenarios;
    const Baseline current = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        });
    const Baseline historical = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0483(bytes);
        });
    check(
        results,
        same_observation(current.observation, historical.observation),
        "allocation_baseline_semantics");
    results.current_allocation_attempts += current.stats.attempts;
    results.historical_allocation_attempts += historical.stats.attempts;
    results.current_allocated_bytes += current.stats.total_bytes;
    results.historical_allocated_bytes += historical.stats.total_bytes;
    results.current_maximum_allocation = std::max(
        results.current_maximum_allocation, current.stats.maximum_bytes);
    results.historical_maximum_allocation = std::max(
        results.historical_maximum_allocation,
        historical.stats.maximum_bytes);

    const std::size_t attempt_delta =
        current.stats.attempts - historical.stats.attempts;
    const std::size_t byte_delta =
        current.stats.total_bytes - historical.stats.total_bytes;
    results.measured_extra_spill_allocations += attempt_delta;
    results.measured_extra_spill_bytes += byte_delta;
    const bool attempts_exact = attempt_delta == expected_extra_attempts;
    results.allocation_relation_checks += attempts_exact ? 1U : 0U;
    check(results, attempts_exact, "allocation_attempt_delta");
    const bool bytes_exact = byte_delta == expected_extra_bytes;
    results.allocation_relation_checks += bytes_exact ? 1U : 0U;
    check(results, bytes_exact, "allocation_byte_delta");
    const bool maximum_not_increased =
        current.stats.maximum_bytes == historical.stats.maximum_bytes;
    results.allocation_relation_checks += maximum_not_increased ? 1U : 0U;
    check(results, maximum_not_increased, "allocation_maximum_relation");

    inject_allocation_failures(
        results,
        payload,
        current,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        },
        true);
    inject_allocation_failures(
        results,
        payload,
        historical,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0483(bytes);
        },
        false);
}

void allocation_cases(Results& results) {
    NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error);
    allocation_scenario(results, encode_message(results, error), 0U, 0U);

    NATravPeerHandshakeMessage inline_boundary =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(
        inline_boundary,
        datacube::kNATravPeerInlineCapabilitySpanCapacity);
    allocation_scenario(
        results, encode_message(results, inline_boundary), 0U, 0U);

    NATravPeerHandshakeMessage first_spill =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fill_capabilities(
        first_spill,
        datacube::kNATravPeerInlineCapabilitySpanCapacity + 1U);
    allocation_scenario(
        results,
        encode_message(results, first_spill),
        1U,
        datacube::kNATravPeerInlineCapabilitySpanCapacity *
            sizeof(datacube::CanonicalCapabilityEntrySpan));

    NATravPeerHandshakeMessage large =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fill_capabilities(large, 7000U);
    allocation_scenario(results, encode_message(results, large), 8U, 65280U);
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    random_corpus(results);
    direct_storage_boundaries(results);
    allocation_cases(results);

    const std::size_t injected_total =
        results.injected_current_failures +
        results.injected_historical_failures;
    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.common_case_zero_spill_cases ==
                results.common_case_zero_spill_checks &&
            results.spill_path_cases == results.spill_path_checks &&
            results.storage_boundary_cases ==
                results.storage_boundary_checks &&
            results.current_storage_instances == results.semantic_cases &&
            results.historical_storage_instances == results.semantic_cases &&
            results.current_inline_appends + results.current_spill_appends ==
                results.historical_appends &&
            results.current_inline_reads + results.current_spill_reads ==
                results.historical_reads &&
            results.current_spill_activations > 0U &&
            results.current_spill_reservations > 0U &&
            results.allocation_relation_checks ==
                results.allocation_scenarios * 3U &&
            results.measured_extra_spill_allocations == 9U &&
            results.measured_extra_spill_bytes == 65536U &&
            results.exception_type_checks == injected_total &&
            results.exception_ordinal_checks == injected_total &&
            results.input_preservation_checks == injected_total &&
            results.retry_checks == injected_total,
        "coverage_and_span_storage_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(current_storage_instances);
    PRINT_RESULT(current_inline_appends);
    PRINT_RESULT(current_spill_appends);
    PRINT_RESULT(current_spill_activations);
    PRINT_RESULT(current_spill_reservations);
    PRINT_RESULT(current_spill_reserved_capacity);
    PRINT_RESULT(current_maximum_spill_capacity);
    PRINT_RESULT(current_inline_reads);
    PRINT_RESULT(current_spill_reads);
    PRINT_RESULT(historical_storage_instances);
    PRINT_RESULT(historical_appends);
    PRINT_RESULT(historical_reads);
    PRINT_RESULT(common_case_zero_spill_cases);
    PRINT_RESULT(common_case_zero_spill_checks);
    PRINT_RESULT(spill_path_cases);
    PRINT_RESULT(spill_path_checks);
    PRINT_RESULT(storage_boundary_cases);
    PRINT_RESULT(storage_boundary_checks);
    PRINT_RESULT(inline_capacity);
    PRINT_RESULT(current_storage_bytes);
    PRINT_RESULT(historical_fixed_storage_bytes);
    PRINT_RESULT(storage_bytes_reduced);
    PRINT_RESULT(current_preflight_observation_bytes);
    PRINT_RESULT(historical_estimated_preflight_observation_bytes);
    PRINT_RESULT(preflight_bytes_reduced);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(current_allocation_attempts);
    PRINT_RESULT(historical_allocation_attempts);
    PRINT_RESULT(current_allocated_bytes);
    PRINT_RESULT(historical_allocated_bytes);
    PRINT_RESULT(current_maximum_allocation);
    PRINT_RESULT(historical_maximum_allocation);
    PRINT_RESULT(measured_extra_spill_allocations);
    PRINT_RESULT(measured_extra_spill_bytes);
    PRINT_RESULT(allocation_relation_checks);
    PRINT_RESULT(injected_current_failures);
    PRINT_RESULT(injected_historical_failures);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_capability_span_storage_test

int main() {
    try {
        return natrav_capability_span_storage_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(
            natrav_capability_span_storage_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_STORAGE_TEST


// Revision 0485 opt-in local regression: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_capability_span_chunk_storage_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t injection_point) noexcept :
        point(injection_point) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_CAPABILITY_SPAN_CHUNK_STORAGE_BAD_ALLOC";
    }
    std::size_t point;
};

struct Stats final {
    std::size_t attempts{0U};
    std::size_t total_bytes{0U};
    std::size_t maximum_bytes{0U};
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    Stats stats;
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .stats = {},
    };
}

[[nodiscard]] Stats disarm() noexcept {
    const Stats stats = state.stats;
    state.armed = false;
    return stats;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_capability_span_chunk_storage_allocation_test

void* operator new(const std::size_t size) {
    return natrav_capability_span_chunk_storage_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_capability_span_chunk_storage_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_capability_span_chunk_storage_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_capability_span_chunk_storage_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_capability_span_chunk_storage_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_capability_span_chunk_storage_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_span_chunk_storage_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_span_chunk_storage_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_span_chunk_storage_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_span_chunk_storage_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_span_chunk_storage_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_span_chunk_storage_allocation_test::release(pointer);
}

namespace natrav_capability_span_chunk_storage_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_capability_span_chunk_storage_allocation_test::Stats;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t current_storage_instances{0U};
    std::size_t current_inline_appends{0U};
    std::size_t current_spill_appends{0U};
    std::size_t current_spill_activations{0U};
    std::size_t current_spill_reservations{0U};
    std::size_t current_spill_reserved_capacity{0U};
    std::size_t current_maximum_spill_capacity{0U};
    std::size_t current_inline_reads{0U};
    std::size_t current_spill_reads{0U};
    std::size_t current_relocated_spans{0U};
    std::size_t historical_storage_instances{0U};
    std::size_t historical_appends{0U};
    std::size_t historical_reads{0U};
    std::size_t historical_spill_reservations{0U};
    std::size_t historical_spill_reserved_capacity{0U};
    std::size_t historical_maximum_spill_capacity{0U};
    std::size_t historical_relocated_spans{0U};
    std::size_t common_case_zero_spill_cases{0U};
    std::size_t common_case_zero_spill_checks{0U};
    std::size_t spill_path_cases{0U};
    std::size_t spill_path_checks{0U};
    std::size_t storage_boundary_cases{0U};
    std::size_t storage_boundary_checks{0U};
    std::size_t inline_capacity{0U};
    std::size_t first_spill_chunk_capacity{0U};
    std::size_t tail_chunk_capacity{0U};
    std::size_t tail_chunk_count{0U};
    std::size_t maximum_chunk_count{0U};
    std::size_t production_storage_bytes{0U};
    std::size_t revision_0484_production_storage_bytes{0U};
    std::size_t production_storage_bytes_added{0U};
    std::size_t production_preflight_observation_bytes{0U};
    std::size_t instrumented_storage_bytes{0U};
    std::size_t instrumented_preflight_observation_bytes{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t current_allocation_attempts{0U};
    std::size_t historical_allocation_attempts{0U};
    std::size_t current_allocated_bytes{0U};
    std::size_t historical_allocated_bytes{0U};
    std::size_t current_maximum_allocation{0U};
    std::size_t historical_maximum_allocation{0U};
    std::size_t measured_allocation_attempts_reduced{0U};
    std::size_t measured_allocated_bytes_reduced{0U};
    std::size_t allocation_relation_checks{0U};
    std::size_t injected_current_failures{0U};
    std::size_t injected_historical_failures{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::int64_t minor = 0) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = minor,
    };
    message.request_id.assign(64U, 'a');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = std::string(64U, 'b'),
            .target = "linux-x86_64",
            .version = "v1",
        };
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "capability-span-chunk-storage";
    }
    return message;
}

[[nodiscard]] std::string capability_name(const std::size_t index) {
    std::string digits = std::to_string(index);
    if (digits.size() > 4U) {
        throw std::runtime_error("capability-index-range");
    }
    std::string token = "C";
    token.append(4U - digits.size(), '0');
    token.append(digits);
    return token;
}

void fill_capabilities(
    NATravPeerHandshakeMessage& message,
    const std::size_t count) {
    std::vector<std::string>& capabilities =
        message.kind == NATravPeerHandshakeMessageKind::hello ?
            message.required_capabilities :
            message.available_capabilities;
    capabilities.reserve(count);
    for (std::size_t index = 0U; index < count; ++index) {
        capabilities.push_back(capability_name(index));
    }
}

[[nodiscard]] Octets encode_message(
    Results& results,
    const NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    check(
        results,
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "fixture_encoding");
    return encoded.payload.value_or(Octets{});
}

struct CountedDecode final {
    NATravPeerMessageDecodeObservation observation;
    datacube::CanonicalCapabilitySpanChunkStorageCounters counters;
};

[[nodiscard]] CountedDecode current_decode(const Octets& payload) {
    datacube::reset_canonical_capability_span_chunk_storage_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_capability_span_chunk_storage_counters(),
    };
}

[[nodiscard]] CountedDecode historical_decode(const Octets& payload) {
    datacube::reset_canonical_capability_span_chunk_storage_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0484(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_capability_span_chunk_storage_counters(),
    };
}

void accumulate_current(
    Results& results,
    const datacube::CanonicalCapabilitySpanChunkStorageCounters& counters) {
    results.current_storage_instances += counters.storage_instances;
    results.current_inline_appends += counters.inline_appends;
    results.current_spill_appends += counters.spill_appends;
    results.current_spill_activations += counters.spill_activations;
    results.current_spill_reservations += counters.spill_reservations;
    results.current_spill_reserved_capacity +=
        counters.spill_reserved_capacity;
    results.current_maximum_spill_capacity = std::max(
        results.current_maximum_spill_capacity,
        counters.maximum_spill_capacity);
    results.current_inline_reads += counters.inline_reads;
    results.current_spill_reads += counters.spill_reads;
    results.current_relocated_spans += counters.current_relocated_spans;
}

void accumulate_historical(
    Results& results,
    const datacube::CanonicalCapabilitySpanChunkStorageCounters& counters) {
    results.historical_storage_instances += counters.storage_instances;
    results.historical_appends += counters.historical_appends;
    results.historical_reads += counters.historical_reads;
    results.historical_spill_reservations += counters.historical_reservations;
    results.historical_spill_reserved_capacity +=
        counters.historical_reserved_capacity;
    results.historical_maximum_spill_capacity = std::max(
        results.historical_maximum_spill_capacity,
        counters.historical_maximum_capacity);
    results.historical_relocated_spans += counters.historical_relocated_spans;
}

[[nodiscard]] CountedDecode compare_semantics(
    Results& results,
    const Octets& payload,
    const std::optional<NATravPeerMessageDecodeStatus> expected =
        std::nullopt) {
    CountedDecode current = current_decode(payload);
    const CountedDecode historical = historical_decode(payload);
    ++results.semantic_cases;
    accumulate_current(results, current.counters);
    accumulate_historical(results, historical.counters);

    const bool equal = same_observation(
        current.observation, historical.observation);
    results.exact_observation_comparisons += equal ? 1U : 0U;
    check(results, equal, "exact_observation_match");

    if (expected) {
        ++results.classification_priority_cases;
        const bool exact = current.observation.status == *expected;
        results.exact_classifications += exact ? 1U : 0U;
        check(results, exact, "exact_expected_classification");
    }

    if (current.observation.status != NATravPeerMessageDecodeStatus::accepted ||
        !current.observation.message) {
        ++results.rejection_cases;
        return current;
    }

    ++results.accepted_cases;
    const auto encoded = datacube::natrav_peer_encode_message(
        *current.observation.message);
    const bool roundtrip =
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
        encoded.payload && *encoded.payload == payload;
    results.exact_roundtrips += roundtrip ? 1U : 0U;
    check(results, roundtrip, "exact_roundtrip");
    return current;
}

void check_zero_spill_case(
    Results& results,
    const CountedDecode& decoded,
    const std::size_t expected_inline) {
    ++results.common_case_zero_spill_cases;
    const bool exact =
        decoded.counters.inline_appends == expected_inline &&
        decoded.counters.spill_appends == 0U &&
        decoded.counters.spill_activations == 0U &&
        decoded.counters.spill_reservations == 0U &&
        decoded.counters.maximum_spill_capacity == 0U;
    results.common_case_zero_spill_checks += exact ? 1U : 0U;
    check(results, exact, "common_case_zero_spill");
}

void check_spill_case(
    Results& results,
    const CountedDecode& decoded,
    const std::size_t expected_spill,
    const std::size_t expected_reservations,
    const std::size_t expected_maximum_capacity) {
    ++results.spill_path_cases;
    const bool exact =
        decoded.counters.inline_appends ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        decoded.counters.spill_appends == expected_spill &&
        decoded.counters.spill_activations == 1U &&
        decoded.counters.spill_reservations == expected_reservations &&
        decoded.counters.maximum_spill_capacity ==
            expected_maximum_capacity &&
        decoded.counters.inline_reads ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        decoded.counters.spill_reads == expected_spill;
    results.spill_path_checks += exact ? 1U : 0U;
    check(results, exact, "spill_path_exact");
}

void accepted_corpus(Results& results) {
    NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error, 1);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, error)),
        0U);

    NATravPeerHandshakeMessage empty =
        base_message(NATravPeerHandshakeMessageKind::hello, 2);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, empty)),
        0U);

    NATravPeerHandshakeMessage one =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 3);
    fill_capabilities(one, 1U);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, one)),
        1U);

    NATravPeerHandshakeMessage inline_boundary =
        base_message(NATravPeerHandshakeMessageKind::hello, 4);
    fill_capabilities(
        inline_boundary,
        datacube::kNATravPeerInlineCapabilitySpanCapacity);
    check_zero_spill_case(
        results,
        compare_semantics(
            results, encode_message(results, inline_boundary)),
        datacube::kNATravPeerInlineCapabilitySpanCapacity);

    NATravPeerHandshakeMessage first_spill =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 5);
    fill_capabilities(
        first_spill,
        datacube::kNATravPeerInlineCapabilitySpanCapacity + 1U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, first_spill)),
        1U,
        1U,
        datacube::kNATravPeerInlineCapabilitySpanCapacity);

    NATravPeerHandshakeMessage large =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 6);
    fill_capabilities(large, 7000U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, large)),
        7000U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        5U,
        datacube::kNATravPeerCapabilitySpanTailChunkCapacity);

    for (std::size_t fixture = 0U; fixture < 128U; ++fixture) {
        const NATravPeerHandshakeMessageKind kind = fixture % 2U == 0U ?
            NATravPeerHandshakeMessageKind::hello :
            NATravPeerHandshakeMessageKind::hello_ack;
        NATravPeerHandshakeMessage message = base_message(
            kind, static_cast<std::int64_t>(fixture + 10U));
        fill_capabilities(message, fixture % 96U);
        static_cast<void>(compare_semantics(
            results, encode_message(results, message)));
    }
}

[[nodiscard]] std::string payload_text(const Octets& payload) {
    std::string text;
    text.reserve(payload.size());
    for (const std::uint8_t byte : payload) {
        text.push_back(static_cast<char>(byte));
    }
    return text;
}

[[nodiscard]] Octets payload_bytes(const std::string_view text) {
    Octets payload;
    payload.reserve(text.size());
    for (const char character : text) {
        payload.push_back(static_cast<std::uint8_t>(
            static_cast<unsigned char>(character)));
    }
    return payload;
}

[[nodiscard]] Octets replace_once(
    const Octets& payload,
    const std::string_view before,
    const std::string_view after) {
    std::string text = payload_text(payload);
    const std::size_t offset = text.find(before);
    if (offset == std::string::npos) {
        throw std::runtime_error("fixture-replacement-missing");
    }
    text.replace(offset, before.size(), after);
    return payload_bytes(text);
}

void priority_cases(Results& results) {
    NATravPeerHandshakeMessage message =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(message, 2U);
    const Octets valid = encode_message(results, message);

    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0001\",\"C0000\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0000\",\"C0000\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0000\",1]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "\"major\":1", "\"major\":2"),
        NATravPeerMessageDecodeStatus::protocol_mismatch));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'a'), std::string(64U, 'z')),
        NATravPeerMessageDecodeStatus::request_id_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'b'),
                     std::string("z") + std::string(63U, 'b')),
        NATravPeerMessageDecodeStatus::artifact_identity_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "\"HELLO\"", "\"OTHER\""),
        NATravPeerMessageDecodeStatus::message_kind_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "},\"kind\":", "},\"extra\":0,\"kind\":"),
        NATravPeerMessageDecodeStatus::schema_rejected));

    std::string malformed = payload_text(valid);
    malformed.pop_back();
    static_cast<void>(compare_semantics(
        results,
        payload_bytes(malformed),
        NATravPeerMessageDecodeStatus::malformed_json));
    static_cast<void>(compare_semantics(
        results,
        payload_bytes(std::string(" ") + payload_text(valid)),
        NATravPeerMessageDecodeStatus::noncanonical_json));
    static_cast<void>(compare_semantics(
        results,
        payload_bytes("[]"),
        NATravPeerMessageDecodeStatus::schema_rejected));
}

void random_corpus(Results& results) {
    std::uint64_t state = 0xd1b54a32d192ed03ULL;
    for (std::size_t fixture = 0U; fixture < 4096U; ++fixture) {
        state ^= state << 13U;
        state ^= state >> 7U;
        state ^= state << 17U;
        const std::size_t length = 2U +
            static_cast<std::size_t>(state % 191U);
        Octets payload;
        payload.reserve(length);
        for (std::size_t index = 0U; index < length; ++index) {
            state ^= state << 13U;
            state ^= state >> 7U;
            state ^= state << 17U;
            payload.push_back(static_cast<std::uint8_t>(state & 0xFFU));
        }
        static_cast<void>(compare_semantics(results, payload));
        ++results.random_cases;
    }
}

struct ProductionCapabilitySpanStorageLayout final {
    std::array<
        datacube::CanonicalCapabilityEntrySpan,
        datacube::kNATravPeerInlineCapabilitySpanCapacity> inline_storage{};
    std::size_t inline_size{0U};
    std::array<
        std::unique_ptr<datacube::CanonicalCapabilityEntrySpan[]>,
        datacube::kNATravPeerCapabilitySpanChunkCount> spill_chunks{};
    std::size_t spill_size{0U};
};

void direct_storage_boundaries(Results& results) {
    results.inline_capacity =
        datacube::kNATravPeerInlineCapabilitySpanCapacity;
    results.first_spill_chunk_capacity =
        datacube::kNATravPeerFirstCapabilitySpanChunkCapacity;
    results.tail_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanTailChunkCapacity;
    results.tail_chunk_count =
        datacube::kNATravPeerCapabilitySpanTailChunkCount;
    results.maximum_chunk_count =
        datacube::kNATravPeerCapabilitySpanChunkCount;
    results.production_storage_bytes =
        sizeof(ProductionCapabilitySpanStorageLayout);
    results.revision_0484_production_storage_bytes = 288U;
    results.production_storage_bytes_added =
        results.production_storage_bytes -
        results.revision_0484_production_storage_bytes;
    results.instrumented_storage_bytes =
        sizeof(datacube::CanonicalCapabilityEntrySpanStorage);
    results.instrumented_preflight_observation_bytes =
        sizeof(datacube::CanonicalMessagePreflightObservation);
    results.production_preflight_observation_bytes =
        results.instrumented_preflight_observation_bytes -
        (results.instrumented_storage_bytes -
         results.production_storage_bytes);

    ++results.storage_boundary_cases;
    const bool footprint =
        results.inline_capacity == 64U &&
        results.first_spill_chunk_capacity == 64U &&
        results.tail_chunk_capacity == 2032U &&
        results.tail_chunk_count == 8U &&
        results.maximum_chunk_count == 9U &&
        results.production_storage_bytes == 344U &&
        results.revision_0484_production_storage_bytes == 288U &&
        results.production_storage_bytes_added == 56U &&
        results.production_preflight_observation_bytes == 1296U &&
        results.instrumented_storage_bytes == 376U &&
        results.instrumented_preflight_observation_bytes == 1328U;
    results.storage_boundary_checks += footprint ? 1U : 0U;
    check(results, footprint, "storage_footprint");

    datacube::reset_canonical_capability_span_chunk_storage_counters();
    datacube::CanonicalCapabilityEntrySpanStorage storage;
    bool appended = true;
    for (std::size_t index = 0U;
         index < datacube::kNATravPeerMaximumJsonConstructionUnits;
         ++index) {
        appended = appended && storage.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = static_cast<std::uint16_t>(index),
                .content_size = 1U,
            });
    }
    const bool rejected_extra = !storage.append(
        datacube::CanonicalCapabilityEntrySpan{
            .content_offset = 0U,
            .content_size = 0U,
        });
    const auto counters =
        datacube::read_canonical_capability_span_chunk_storage_counters();

    ++results.storage_boundary_cases;
    const bool maximum_exact =
        appended && rejected_extra &&
        storage.size() == datacube::kNATravPeerMaximumJsonConstructionUnits &&
        storage.inline_size() ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        storage.spill_size() ==
            datacube::kNATravPeerMaximumJsonConstructionUnits -
                datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        storage.spill_chunk_count() ==
            datacube::kNATravPeerCapabilitySpanChunkCount &&
        storage.spill_allocated_capacity() == storage.spill_size() &&
        storage.maximum_chunk_capacity() ==
            datacube::kNATravPeerCapabilitySpanTailChunkCapacity &&
        counters.spill_activations == 1U &&
        counters.spill_reservations ==
            datacube::kNATravPeerCapabilitySpanChunkCount &&
        counters.spill_reserved_capacity == storage.spill_size() &&
        counters.maximum_spill_capacity ==
            datacube::kNATravPeerCapabilitySpanTailChunkCapacity &&
        counters.current_relocated_spans == 0U;
    results.storage_boundary_checks += maximum_exact ? 1U : 0U;
    check(results, maximum_exact, "storage_maximum_boundary");

    ++results.storage_boundary_cases;
    const bool reads_exact =
        storage.at(0U).content_offset == 0U &&
        storage.at(datacube::kNATravPeerInlineCapabilitySpanCapacity - 1U)
                .content_offset ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity - 1U &&
        storage.at(datacube::kNATravPeerInlineCapabilitySpanCapacity)
                .content_offset ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        storage.at(
            datacube::kNATravPeerInlineCapabilitySpanCapacity +
            datacube::kNATravPeerFirstCapabilitySpanChunkCapacity)
                .content_offset ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity +
                datacube::kNATravPeerFirstCapabilitySpanChunkCapacity &&
        storage.at(datacube::kNATravPeerMaximumJsonConstructionUnits - 1U)
                .content_offset ==
            datacube::kNATravPeerMaximumJsonConstructionUnits - 1U;
    results.storage_boundary_checks += reads_exact ? 1U : 0U;
    check(results, reads_exact, "storage_boundary_reads");
}

struct Baseline final {
    NATravPeerMessageDecodeObservation observation;
    Stats stats;
};

template <typename Decode>
[[nodiscard]] Baseline baseline_decode(
    const Octets& payload,
    Decode&& decode) {
    natrav_capability_span_chunk_storage_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation;
    try {
        observation = decode(payload);
    } catch (...) {
        static_cast<void>(
            natrav_capability_span_chunk_storage_allocation_test::disarm());
        throw;
    }
    const Stats stats =
        natrav_capability_span_chunk_storage_allocation_test::disarm();
    return Baseline{
        .observation = std::move(observation),
        .stats = stats,
    };
}

template <typename Decode>
void inject_allocation_failures(
    Results& results,
    const Octets& payload,
    const Baseline& baseline,
    Decode&& decode,
    const bool current) {
    for (std::size_t point = 0U; point < baseline.stats.attempts; ++point) {
        const Octets before = payload;
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_capability_span_chunk_storage_allocation_test::arm(point);
        try {
            static_cast<void>(decode(payload));
        } catch (const natrav_capability_span_chunk_storage_allocation_test::
                     InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        } catch (...) {
        }
        static_cast<void>(
            natrav_capability_span_chunk_storage_allocation_test::disarm());
        if (current) {
            ++results.injected_current_failures;
        } else {
            ++results.injected_historical_failures;
        }
        results.exception_type_checks += caught ? 1U : 0U;
        check(results, caught, "allocation_exception_type");
        const bool ordinal = caught_point == point;
        results.exception_ordinal_checks += ordinal ? 1U : 0U;
        check(results, ordinal, "allocation_exception_ordinal");
        const bool preserved = payload == before;
        results.input_preservation_checks += preserved ? 1U : 0U;
        check(results, preserved, "allocation_input_preserved");
        const NATravPeerMessageDecodeObservation retry = decode(payload);
        const bool retry_equal = same_observation(retry, baseline.observation);
        results.retry_checks += retry_equal ? 1U : 0U;
        check(results, retry_equal, "allocation_retry");
    }
}

void allocation_scenario(
    Results& results,
    const Octets& payload,
    const std::size_t expected_attempt_reduction,
    const std::size_t expected_byte_reduction) {
    ++results.allocation_scenarios;
    const Baseline current = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        });
    const Baseline historical = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0484(bytes);
        });
    check(
        results,
        same_observation(current.observation, historical.observation),
        "allocation_baseline_semantics");
    results.current_allocation_attempts += current.stats.attempts;
    results.historical_allocation_attempts += historical.stats.attempts;
    results.current_allocated_bytes += current.stats.total_bytes;
    results.historical_allocated_bytes += historical.stats.total_bytes;
    results.current_maximum_allocation = std::max(
        results.current_maximum_allocation, current.stats.maximum_bytes);
    results.historical_maximum_allocation = std::max(
        results.historical_maximum_allocation,
        historical.stats.maximum_bytes);

    const bool attempts_ordered =
        current.stats.attempts <= historical.stats.attempts;
    check(results, attempts_ordered, "allocation_attempt_order");
    const std::size_t attempt_reduction = attempts_ordered ?
        historical.stats.attempts - current.stats.attempts : 0U;
    const bool bytes_ordered =
        current.stats.total_bytes <= historical.stats.total_bytes;
    check(results, bytes_ordered, "allocation_byte_order");
    const std::size_t byte_reduction = bytes_ordered ?
        historical.stats.total_bytes - current.stats.total_bytes : 0U;
    results.measured_allocation_attempts_reduced += attempt_reduction;
    results.measured_allocated_bytes_reduced += byte_reduction;
    const bool attempts_exact =
        attempt_reduction == expected_attempt_reduction;
    results.allocation_relation_checks += attempts_exact ? 1U : 0U;
    check(results, attempts_exact, "allocation_attempt_reduction");
    const bool bytes_exact = byte_reduction == expected_byte_reduction;
    results.allocation_relation_checks += bytes_exact ? 1U : 0U;
    check(results, bytes_exact, "allocation_byte_reduction");
    const bool maximum_not_increased =
        current.stats.maximum_bytes == historical.stats.maximum_bytes;
    results.allocation_relation_checks += maximum_not_increased ? 1U : 0U;
    check(results, maximum_not_increased, "allocation_maximum_relation");

    inject_allocation_failures(
        results,
        payload,
        current,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        },
        true);
    inject_allocation_failures(
        results,
        payload,
        historical,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0484(bytes);
        },
        false);
}

void allocation_cases(Results& results) {
    NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error);
    allocation_scenario(results, encode_message(results, error), 0U, 0U);

    NATravPeerHandshakeMessage inline_boundary =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(
        inline_boundary,
        datacube::kNATravPeerInlineCapabilitySpanCapacity);
    allocation_scenario(
        results, encode_message(results, inline_boundary), 0U, 0U);

    NATravPeerHandshakeMessage first_spill =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fill_capabilities(
        first_spill,
        datacube::kNATravPeerInlineCapabilitySpanCapacity + 1U);
    allocation_scenario(
        results,
        encode_message(results, first_spill),
        0U,
        0U);

    NATravPeerHandshakeMessage large =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fill_capabilities(large, 7000U);
    allocation_scenario(
        results,
        encode_message(results, large),
        3U,
        32512U);
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    random_corpus(results);
    direct_storage_boundaries(results);
    allocation_cases(results);

    const std::size_t injected_total =
        results.injected_current_failures +
        results.injected_historical_failures;
    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.common_case_zero_spill_cases ==
                results.common_case_zero_spill_checks &&
            results.spill_path_cases == results.spill_path_checks &&
            results.storage_boundary_cases ==
                results.storage_boundary_checks &&
            results.current_storage_instances == results.semantic_cases &&
            results.historical_storage_instances == results.semantic_cases &&
            results.current_inline_appends + results.current_spill_appends ==
                results.historical_appends &&
            results.current_inline_reads + results.current_spill_reads ==
                results.historical_reads &&
            results.current_spill_activations > 0U &&
            results.current_spill_reservations > 0U &&
            results.current_relocated_spans == 0U &&
            results.historical_spill_reservations >
                results.current_spill_reservations &&
            results.historical_relocated_spans > 0U &&
            results.allocation_relation_checks ==
                results.allocation_scenarios * 3U &&
            results.measured_allocation_attempts_reduced == 3U &&
            results.measured_allocated_bytes_reduced == 32512U &&
            results.exception_type_checks == injected_total &&
            results.exception_ordinal_checks == injected_total &&
            results.input_preservation_checks == injected_total &&
            results.retry_checks == injected_total,
        "coverage_and_span_storage_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(current_storage_instances);
    PRINT_RESULT(current_inline_appends);
    PRINT_RESULT(current_spill_appends);
    PRINT_RESULT(current_spill_activations);
    PRINT_RESULT(current_spill_reservations);
    PRINT_RESULT(current_spill_reserved_capacity);
    PRINT_RESULT(current_maximum_spill_capacity);
    PRINT_RESULT(current_inline_reads);
    PRINT_RESULT(current_spill_reads);
    PRINT_RESULT(current_relocated_spans);
    PRINT_RESULT(historical_storage_instances);
    PRINT_RESULT(historical_appends);
    PRINT_RESULT(historical_reads);
    PRINT_RESULT(historical_spill_reservations);
    PRINT_RESULT(historical_spill_reserved_capacity);
    PRINT_RESULT(historical_maximum_spill_capacity);
    PRINT_RESULT(historical_relocated_spans);
    PRINT_RESULT(common_case_zero_spill_cases);
    PRINT_RESULT(common_case_zero_spill_checks);
    PRINT_RESULT(spill_path_cases);
    PRINT_RESULT(spill_path_checks);
    PRINT_RESULT(storage_boundary_cases);
    PRINT_RESULT(storage_boundary_checks);
    PRINT_RESULT(inline_capacity);
    PRINT_RESULT(first_spill_chunk_capacity);
    PRINT_RESULT(tail_chunk_capacity);
    PRINT_RESULT(tail_chunk_count);
    PRINT_RESULT(maximum_chunk_count);
    PRINT_RESULT(production_storage_bytes);
    PRINT_RESULT(revision_0484_production_storage_bytes);
    PRINT_RESULT(production_storage_bytes_added);
    PRINT_RESULT(production_preflight_observation_bytes);
    PRINT_RESULT(instrumented_storage_bytes);
    PRINT_RESULT(instrumented_preflight_observation_bytes);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(current_allocation_attempts);
    PRINT_RESULT(historical_allocation_attempts);
    PRINT_RESULT(current_allocated_bytes);
    PRINT_RESULT(historical_allocated_bytes);
    PRINT_RESULT(current_maximum_allocation);
    PRINT_RESULT(historical_maximum_allocation);
    PRINT_RESULT(measured_allocation_attempts_reduced);
    PRINT_RESULT(measured_allocated_bytes_reduced);
    PRINT_RESULT(allocation_relation_checks);
    PRINT_RESULT(injected_current_failures);
    PRINT_RESULT(injected_historical_failures);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_capability_span_chunk_storage_test

int main() {
    try {
        return natrav_capability_span_chunk_storage_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(
            natrav_capability_span_chunk_storage_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_CHUNK_STORAGE_TEST

// Revision 0486 opt-in local regression: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_capability_span_tiered_storage_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t injection_point) noexcept :
        point(injection_point) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_CAPABILITY_SPAN_TIERED_STORAGE_BAD_ALLOC";
    }
    std::size_t point;
};

struct Stats final {
    std::size_t attempts{0U};
    std::size_t total_bytes{0U};
    std::size_t maximum_bytes{0U};
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    Stats stats;
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .stats = {},
    };
}

[[nodiscard]] Stats disarm() noexcept {
    const Stats stats = state.stats;
    state.armed = false;
    return stats;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_capability_span_tiered_storage_allocation_test

void* operator new(const std::size_t size) {
    return natrav_capability_span_tiered_storage_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_capability_span_tiered_storage_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_capability_span_tiered_storage_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_capability_span_tiered_storage_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_capability_span_tiered_storage_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_capability_span_tiered_storage_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_span_tiered_storage_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_span_tiered_storage_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_span_tiered_storage_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_span_tiered_storage_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_span_tiered_storage_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_span_tiered_storage_allocation_test::release(pointer);
}

namespace natrav_capability_span_tiered_storage_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_capability_span_tiered_storage_allocation_test::Stats;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t current_storage_instances{0U};
    std::size_t current_inline_appends{0U};
    std::size_t current_spill_appends{0U};
    std::size_t current_spill_activations{0U};
    std::size_t current_spill_reservations{0U};
    std::size_t current_spill_reserved_capacity{0U};
    std::size_t current_maximum_spill_capacity{0U};
    std::size_t current_inline_reads{0U};
    std::size_t current_spill_reads{0U};
    std::size_t current_relocated_spans{0U};
    std::size_t historical_storage_instances{0U};
    std::size_t historical_appends{0U};
    std::size_t historical_reads{0U};
    std::size_t historical_spill_reservations{0U};
    std::size_t historical_spill_reserved_capacity{0U};
    std::size_t historical_maximum_spill_capacity{0U};
    std::size_t historical_relocated_spans{0U};
    std::size_t common_case_zero_spill_cases{0U};
    std::size_t common_case_zero_spill_checks{0U};
    std::size_t spill_path_cases{0U};
    std::size_t spill_path_checks{0U};
    std::size_t storage_boundary_cases{0U};
    std::size_t storage_boundary_checks{0U};
    std::size_t inline_capacity{0U};
    std::size_t first_spill_chunk_capacity{0U};
    std::size_t tier_one_chunk_capacity{0U};
    std::size_t tier_two_chunk_capacity{0U};
    std::size_t tier_three_chunk_capacity{0U};
    std::size_t tier_four_chunk_capacity{0U};
    std::size_t tier_chunk_count{0U};
    std::size_t uniform_tail_chunk_capacity{0U};
    std::size_t uniform_tail_chunk_count{0U};
    std::size_t maximum_chunk_count{0U};
    std::size_t production_storage_bytes{0U};
    std::size_t revision_0485_production_storage_bytes{0U};
    std::size_t production_storage_bytes_added{0U};
    std::size_t production_preflight_observation_bytes{0U};
    std::size_t instrumented_storage_bytes{0U};
    std::size_t instrumented_preflight_observation_bytes{0U};
    std::size_t medium_reservation_cases{0U};
    std::size_t medium_reservation_checks{0U};
    std::size_t current_medium_reserved_capacity{0U};
    std::size_t historical_medium_reserved_capacity{0U};
    std::size_t medium_reserved_capacity_reduced{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t current_allocation_attempts{0U};
    std::size_t historical_allocation_attempts{0U};
    std::size_t current_allocated_bytes{0U};
    std::size_t historical_allocated_bytes{0U};
    std::size_t current_maximum_allocation{0U};
    std::size_t historical_maximum_allocation{0U};
    std::size_t measured_allocation_attempts_added{0U};
    std::size_t measured_allocated_bytes_reduced{0U};
    std::size_t allocation_relation_checks{0U};
    std::size_t injected_current_failures{0U};
    std::size_t injected_historical_failures{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::int64_t minor = 0) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = minor,
    };
    message.request_id.assign(64U, 'a');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = std::string(64U, 'b'),
            .target = "linux-x86_64",
            .version = "v1",
        };
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "capability-span-tiered-storage";
    }
    return message;
}

[[nodiscard]] std::string capability_name(const std::size_t index) {
    std::string digits = std::to_string(index);
    if (digits.size() > 4U) {
        throw std::runtime_error("capability-index-range");
    }
    std::string token = "C";
    token.append(4U - digits.size(), '0');
    token.append(digits);
    return token;
}

void fill_capabilities(
    NATravPeerHandshakeMessage& message,
    const std::size_t count) {
    std::vector<std::string>& capabilities =
        message.kind == NATravPeerHandshakeMessageKind::hello ?
            message.required_capabilities :
            message.available_capabilities;
    capabilities.reserve(count);
    for (std::size_t index = 0U; index < count; ++index) {
        capabilities.push_back(capability_name(index));
    }
}

[[nodiscard]] Octets encode_message(
    Results& results,
    const NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    check(
        results,
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "fixture_encoding");
    return encoded.payload.value_or(Octets{});
}

struct CountedDecode final {
    NATravPeerMessageDecodeObservation observation;
    datacube::CanonicalCapabilitySpanChunkStorageCounters counters;
};

[[nodiscard]] CountedDecode current_decode(const Octets& payload) {
    datacube::reset_canonical_capability_span_chunk_storage_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_capability_span_chunk_storage_counters(),
    };
}

[[nodiscard]] CountedDecode historical_decode(const Octets& payload) {
    datacube::reset_canonical_capability_span_chunk_storage_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0485(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_capability_span_chunk_storage_counters(),
    };
}

void accumulate_current(
    Results& results,
    const datacube::CanonicalCapabilitySpanChunkStorageCounters& counters) {
    results.current_storage_instances += counters.storage_instances;
    results.current_inline_appends += counters.inline_appends;
    results.current_spill_appends += counters.spill_appends;
    results.current_spill_activations += counters.spill_activations;
    results.current_spill_reservations += counters.spill_reservations;
    results.current_spill_reserved_capacity +=
        counters.spill_reserved_capacity;
    results.current_maximum_spill_capacity = std::max(
        results.current_maximum_spill_capacity,
        counters.maximum_spill_capacity);
    results.current_inline_reads += counters.inline_reads;
    results.current_spill_reads += counters.spill_reads;
    results.current_relocated_spans += counters.current_relocated_spans;
}

void accumulate_historical(
    Results& results,
    const datacube::CanonicalCapabilitySpanChunkStorageCounters& counters) {
    results.historical_storage_instances += counters.storage_instances;
    results.historical_appends += counters.historical_appends;
    results.historical_reads += counters.historical_reads;
    results.historical_spill_reservations += counters.historical_reservations;
    results.historical_spill_reserved_capacity +=
        counters.historical_reserved_capacity;
    results.historical_maximum_spill_capacity = std::max(
        results.historical_maximum_spill_capacity,
        counters.historical_maximum_capacity);
    results.historical_relocated_spans += counters.historical_relocated_spans;
}

[[nodiscard]] CountedDecode compare_semantics(
    Results& results,
    const Octets& payload,
    const std::optional<NATravPeerMessageDecodeStatus> expected =
        std::nullopt) {
    CountedDecode current = current_decode(payload);
    const CountedDecode historical = historical_decode(payload);
    ++results.semantic_cases;
    accumulate_current(results, current.counters);
    accumulate_historical(results, historical.counters);

    const bool equal = same_observation(
        current.observation, historical.observation);
    results.exact_observation_comparisons += equal ? 1U : 0U;
    check(results, equal, "exact_observation_match");

    if (expected) {
        ++results.classification_priority_cases;
        const bool exact = current.observation.status == *expected;
        results.exact_classifications += exact ? 1U : 0U;
        check(results, exact, "exact_expected_classification");
    }

    if (current.observation.status != NATravPeerMessageDecodeStatus::accepted ||
        !current.observation.message) {
        ++results.rejection_cases;
        return current;
    }

    ++results.accepted_cases;
    const auto encoded = datacube::natrav_peer_encode_message(
        *current.observation.message);
    const bool roundtrip =
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
        encoded.payload && *encoded.payload == payload;
    results.exact_roundtrips += roundtrip ? 1U : 0U;
    check(results, roundtrip, "exact_roundtrip");
    return current;
}

void check_zero_spill_case(
    Results& results,
    const CountedDecode& decoded,
    const std::size_t expected_inline) {
    ++results.common_case_zero_spill_cases;
    const bool exact =
        decoded.counters.inline_appends == expected_inline &&
        decoded.counters.spill_appends == 0U &&
        decoded.counters.spill_activations == 0U &&
        decoded.counters.spill_reservations == 0U &&
        decoded.counters.maximum_spill_capacity == 0U;
    results.common_case_zero_spill_checks += exact ? 1U : 0U;
    check(results, exact, "common_case_zero_spill");
}

void check_spill_case(
    Results& results,
    const CountedDecode& decoded,
    const std::size_t expected_spill,
    const std::size_t expected_reservations,
    const std::size_t expected_maximum_capacity) {
    ++results.spill_path_cases;
    const bool exact =
        decoded.counters.inline_appends ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        decoded.counters.spill_appends == expected_spill &&
        decoded.counters.spill_activations == 1U &&
        decoded.counters.spill_reservations == expected_reservations &&
        decoded.counters.maximum_spill_capacity ==
            expected_maximum_capacity &&
        decoded.counters.inline_reads ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        decoded.counters.spill_reads == expected_spill;
    results.spill_path_checks += exact ? 1U : 0U;
    check(results, exact, "spill_path_exact");
}

void accepted_corpus(Results& results) {
    NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error, 1);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, error)),
        0U);

    NATravPeerHandshakeMessage empty =
        base_message(NATravPeerHandshakeMessageKind::hello, 2);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, empty)),
        0U);

    NATravPeerHandshakeMessage one =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 3);
    fill_capabilities(one, 1U);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, one)),
        1U);

    NATravPeerHandshakeMessage inline_boundary =
        base_message(NATravPeerHandshakeMessageKind::hello, 4);
    fill_capabilities(
        inline_boundary,
        datacube::kNATravPeerInlineCapabilitySpanCapacity);
    check_zero_spill_case(
        results,
        compare_semantics(
            results, encode_message(results, inline_boundary)),
        datacube::kNATravPeerInlineCapabilitySpanCapacity);

    NATravPeerHandshakeMessage first_spill =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 5);
    fill_capabilities(
        first_spill,
        datacube::kNATravPeerInlineCapabilitySpanCapacity + 1U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, first_spill)),
        1U,
        1U,
        datacube::kNATravPeerInlineCapabilitySpanCapacity);

    NATravPeerHandshakeMessage medium_129 =
        base_message(NATravPeerHandshakeMessageKind::hello, 6);
    fill_capabilities(medium_129, 129U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, medium_129)),
        129U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        2U,
        datacube::kNATravPeerCapabilitySpanChunkCapacities[1U]);

    NATravPeerHandshakeMessage medium_512 =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 7);
    fill_capabilities(medium_512, 512U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, medium_512)),
        512U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        3U,
        datacube::kNATravPeerCapabilitySpanChunkCapacities[2U]);

    NATravPeerHandshakeMessage medium_1024 =
        base_message(NATravPeerHandshakeMessageKind::hello, 8);
    fill_capabilities(medium_1024, 1024U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, medium_1024)),
        1024U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        4U,
        datacube::kNATravPeerCapabilitySpanChunkCapacities[3U]);

    NATravPeerHandshakeMessage large =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 9);
    fill_capabilities(large, 7000U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, large)),
        7000U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        8U,
        datacube::kNATravPeerCapabilitySpanTailChunkCapacity);

    for (std::size_t fixture = 0U; fixture < 128U; ++fixture) {
        const NATravPeerHandshakeMessageKind kind = fixture % 2U == 0U ?
            NATravPeerHandshakeMessageKind::hello :
            NATravPeerHandshakeMessageKind::hello_ack;
        NATravPeerHandshakeMessage message = base_message(
            kind, static_cast<std::int64_t>(fixture + 10U));
        fill_capabilities(message, fixture % 96U);
        static_cast<void>(compare_semantics(
            results, encode_message(results, message)));
    }
}

[[nodiscard]] std::string payload_text(const Octets& payload) {
    std::string text;
    text.reserve(payload.size());
    for (const std::uint8_t byte : payload) {
        text.push_back(static_cast<char>(byte));
    }
    return text;
}

[[nodiscard]] Octets payload_bytes(const std::string_view text) {
    Octets payload;
    payload.reserve(text.size());
    for (const char character : text) {
        payload.push_back(static_cast<std::uint8_t>(
            static_cast<unsigned char>(character)));
    }
    return payload;
}

[[nodiscard]] Octets replace_once(
    const Octets& payload,
    const std::string_view before,
    const std::string_view after) {
    std::string text = payload_text(payload);
    const std::size_t offset = text.find(before);
    if (offset == std::string::npos) {
        throw std::runtime_error("fixture-replacement-missing");
    }
    text.replace(offset, before.size(), after);
    return payload_bytes(text);
}

void priority_cases(Results& results) {
    NATravPeerHandshakeMessage message =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(message, 2U);
    const Octets valid = encode_message(results, message);

    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0001\",\"C0000\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0000\",\"C0000\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0000\",1]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "\"major\":1", "\"major\":2"),
        NATravPeerMessageDecodeStatus::protocol_mismatch));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'a'), std::string(64U, 'z')),
        NATravPeerMessageDecodeStatus::request_id_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'b'),
                     std::string("z") + std::string(63U, 'b')),
        NATravPeerMessageDecodeStatus::artifact_identity_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "\"HELLO\"", "\"OTHER\""),
        NATravPeerMessageDecodeStatus::message_kind_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "},\"kind\":", "},\"extra\":0,\"kind\":"),
        NATravPeerMessageDecodeStatus::schema_rejected));

    std::string malformed = payload_text(valid);
    malformed.pop_back();
    static_cast<void>(compare_semantics(
        results,
        payload_bytes(malformed),
        NATravPeerMessageDecodeStatus::malformed_json));
    static_cast<void>(compare_semantics(
        results,
        payload_bytes(std::string(" ") + payload_text(valid)),
        NATravPeerMessageDecodeStatus::noncanonical_json));
    static_cast<void>(compare_semantics(
        results,
        payload_bytes("[]"),
        NATravPeerMessageDecodeStatus::schema_rejected));
}

void random_corpus(Results& results) {
    std::uint64_t state = 0xd1b54a32d192ed03ULL;
    for (std::size_t fixture = 0U; fixture < 4096U; ++fixture) {
        state ^= state << 13U;
        state ^= state >> 7U;
        state ^= state << 17U;
        const std::size_t length = 2U +
            static_cast<std::size_t>(state % 191U);
        Octets payload;
        payload.reserve(length);
        for (std::size_t index = 0U; index < length; ++index) {
            state ^= state << 13U;
            state ^= state >> 7U;
            state ^= state << 17U;
            payload.push_back(static_cast<std::uint8_t>(state & 0xFFU));
        }
        static_cast<void>(compare_semantics(results, payload));
        ++results.random_cases;
    }
}

struct ProductionCapabilitySpanStorageLayout final {
    std::array<
        datacube::CanonicalCapabilityEntrySpan,
        datacube::kNATravPeerInlineCapabilitySpanCapacity> inline_storage{};
    std::size_t inline_size{0U};
    std::array<
        std::unique_ptr<datacube::CanonicalCapabilityEntrySpan[]>,
        datacube::kNATravPeerCapabilitySpanChunkCount> spill_chunks{};
    std::size_t spill_size{0U};
};

void check_medium_reservation(
    Results& results,
    const std::size_t retained_count,
    const std::size_t expected_current_capacity,
    const std::size_t expected_current_chunks) {
    datacube::reset_canonical_capability_span_chunk_storage_counters();
    datacube::CanonicalCapabilityEntrySpanStorage storage;
    bool appended = true;
    for (std::size_t index = 0U; index < retained_count; ++index) {
        appended = appended && storage.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = static_cast<std::uint16_t>(index),
                .content_size = 1U,
            });
    }
    const auto counters =
        datacube::read_canonical_capability_span_chunk_storage_counters();
    const std::size_t historical_capacity =
        datacube::kNATravPeerFirstCapabilitySpanChunkCapacity +
        datacube::kNATravPeerCapabilitySpanTailChunkCapacity;
    ++results.medium_reservation_cases;
    const bool exact =
        appended && storage.size() == retained_count &&
        storage.spill_chunk_count() == expected_current_chunks &&
        storage.spill_allocated_capacity() == expected_current_capacity &&
        counters.spill_reservations == expected_current_chunks &&
        counters.spill_reserved_capacity == expected_current_capacity &&
        expected_current_capacity < historical_capacity;
    results.medium_reservation_checks += exact ? 1U : 0U;
    check(results, exact, "medium_reservation_exact");
    results.current_medium_reserved_capacity += expected_current_capacity;
    results.historical_medium_reserved_capacity += historical_capacity;
    results.medium_reserved_capacity_reduced +=
        historical_capacity - expected_current_capacity;
}

void direct_storage_boundaries(Results& results) {
    results.inline_capacity =
        datacube::kNATravPeerInlineCapabilitySpanCapacity;
    results.first_spill_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[0U];
    results.tier_one_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[1U];
    results.tier_two_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[2U];
    results.tier_three_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[3U];
    results.tier_four_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[4U];
    results.tier_chunk_count =
        datacube::kNATravPeerCapabilitySpanTierChunkCount;
    results.uniform_tail_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[5U];
    results.uniform_tail_chunk_count =
        datacube::kNATravPeerCapabilitySpanUniformTailChunkCount;
    results.maximum_chunk_count =
        datacube::kNATravPeerCapabilitySpanChunkCount;
    results.production_storage_bytes =
        sizeof(ProductionCapabilitySpanStorageLayout);
    results.revision_0485_production_storage_bytes = 344U;
    results.production_storage_bytes_added =
        results.production_storage_bytes -
        results.revision_0485_production_storage_bytes;
    results.instrumented_storage_bytes =
        sizeof(datacube::CanonicalCapabilityEntrySpanStorage);
    results.instrumented_preflight_observation_bytes =
        sizeof(datacube::CanonicalMessagePreflightObservation);
    results.production_preflight_observation_bytes =
        results.instrumented_preflight_observation_bytes -
        (results.instrumented_storage_bytes -
         results.production_storage_bytes);

    ++results.storage_boundary_cases;
    const bool footprint =
        results.inline_capacity == 64U &&
        results.first_spill_chunk_capacity == 64U &&
        results.tier_one_chunk_capacity == 128U &&
        results.tier_two_chunk_capacity == 256U &&
        results.tier_three_chunk_capacity == 512U &&
        results.tier_four_chunk_capacity == 1136U &&
        results.tier_chunk_count == 4U &&
        results.uniform_tail_chunk_capacity == 2032U &&
        results.uniform_tail_chunk_count == 7U &&
        results.maximum_chunk_count == 12U &&
        results.production_storage_bytes == 368U &&
        results.revision_0485_production_storage_bytes == 344U &&
        results.production_storage_bytes_added == 24U &&
        results.production_preflight_observation_bytes == 1320U &&
        results.instrumented_storage_bytes == 456U &&
        results.instrumented_preflight_observation_bytes == 1408U;
    results.storage_boundary_checks += footprint ? 1U : 0U;
    check(results, footprint, "storage_footprint");

    check_medium_reservation(results, 129U, 192U, 2U);
    check_medium_reservation(results, 512U, 448U, 3U);
    check_medium_reservation(results, 1024U, 960U, 4U);

    datacube::reset_canonical_capability_span_chunk_storage_counters();
    datacube::CanonicalCapabilityEntrySpanStorage storage;
    bool appended = true;
    for (std::size_t index = 0U;
         index < datacube::kNATravPeerMaximumJsonConstructionUnits;
         ++index) {
        appended = appended && storage.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = static_cast<std::uint16_t>(index),
                .content_size = 1U,
            });
    }
    const bool rejected_extra = !storage.append(
        datacube::CanonicalCapabilityEntrySpan{
            .content_offset = 0U,
            .content_size = 0U,
        });
    const auto counters =
        datacube::read_canonical_capability_span_chunk_storage_counters();

    ++results.storage_boundary_cases;
    const bool maximum_exact =
        appended && rejected_extra &&
        storage.size() == datacube::kNATravPeerMaximumJsonConstructionUnits &&
        storage.inline_size() ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        storage.spill_size() ==
            datacube::kNATravPeerMaximumJsonConstructionUnits -
                datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        storage.spill_chunk_count() ==
            datacube::kNATravPeerCapabilitySpanChunkCount &&
        storage.spill_allocated_capacity() == storage.spill_size() &&
        storage.maximum_chunk_capacity() ==
            datacube::kNATravPeerCapabilitySpanTailChunkCapacity &&
        counters.spill_activations == 1U &&
        counters.spill_reservations ==
            datacube::kNATravPeerCapabilitySpanChunkCount &&
        counters.spill_reserved_capacity == storage.spill_size() &&
        counters.maximum_spill_capacity ==
            datacube::kNATravPeerCapabilitySpanTailChunkCapacity &&
        counters.current_relocated_spans == 0U;
    results.storage_boundary_checks += maximum_exact ? 1U : 0U;
    check(results, maximum_exact, "storage_maximum_boundary");

    ++results.storage_boundary_cases;
    const bool reads_exact =
        storage.at(0U).content_offset == 0U &&
        storage.at(63U).content_offset == 63U &&
        storage.at(64U).content_offset == 64U &&
        storage.at(127U).content_offset == 127U &&
        storage.at(128U).content_offset == 128U &&
        storage.at(255U).content_offset == 255U &&
        storage.at(256U).content_offset == 256U &&
        storage.at(511U).content_offset == 511U &&
        storage.at(512U).content_offset == 512U &&
        storage.at(1023U).content_offset == 1023U &&
        storage.at(1024U).content_offset == 1024U &&
        storage.at(2159U).content_offset == 2159U &&
        storage.at(2160U).content_offset == 2160U &&
        storage.at(datacube::kNATravPeerMaximumJsonConstructionUnits - 1U)
                .content_offset ==
            datacube::kNATravPeerMaximumJsonConstructionUnits - 1U;
    results.storage_boundary_checks += reads_exact ? 1U : 0U;
    check(results, reads_exact, "storage_boundary_reads");
}

struct Baseline final {
    NATravPeerMessageDecodeObservation observation;
    Stats stats;
};

template <typename Decode>
[[nodiscard]] Baseline baseline_decode(
    const Octets& payload,
    Decode&& decode) {
    natrav_capability_span_tiered_storage_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation;
    try {
        observation = decode(payload);
    } catch (...) {
        static_cast<void>(
            natrav_capability_span_tiered_storage_allocation_test::disarm());
        throw;
    }
    const Stats stats =
        natrav_capability_span_tiered_storage_allocation_test::disarm();
    return Baseline{
        .observation = std::move(observation),
        .stats = stats,
    };
}

template <typename Decode>
void inject_allocation_failures(
    Results& results,
    const Octets& payload,
    const Baseline& baseline,
    Decode&& decode,
    const bool current) {
    for (std::size_t point = 0U; point < baseline.stats.attempts; ++point) {
        const Octets before = payload;
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_capability_span_tiered_storage_allocation_test::arm(point);
        try {
            static_cast<void>(decode(payload));
        } catch (const natrav_capability_span_tiered_storage_allocation_test::
                     InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        } catch (...) {
        }
        static_cast<void>(
            natrav_capability_span_tiered_storage_allocation_test::disarm());
        if (current) {
            ++results.injected_current_failures;
        } else {
            ++results.injected_historical_failures;
        }
        results.exception_type_checks += caught ? 1U : 0U;
        check(results, caught, "allocation_exception_type");
        const bool ordinal = caught_point == point;
        results.exception_ordinal_checks += ordinal ? 1U : 0U;
        check(results, ordinal, "allocation_exception_ordinal");
        const bool preserved = payload == before;
        results.input_preservation_checks += preserved ? 1U : 0U;
        check(results, preserved, "allocation_input_preserved");
        const NATravPeerMessageDecodeObservation retry = decode(payload);
        const bool retry_equal = same_observation(retry, baseline.observation);
        results.retry_checks += retry_equal ? 1U : 0U;
        check(results, retry_equal, "allocation_retry");
    }
}

void allocation_scenario(
    Results& results,
    const Octets& payload,
    const std::size_t expected_attempt_addition,
    const std::size_t expected_byte_reduction) {
    ++results.allocation_scenarios;
    const Baseline current = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        });
    const Baseline historical = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0485(bytes);
        });
    check(
        results,
        same_observation(current.observation, historical.observation),
        "allocation_baseline_semantics");
    results.current_allocation_attempts += current.stats.attempts;
    results.historical_allocation_attempts += historical.stats.attempts;
    results.current_allocated_bytes += current.stats.total_bytes;
    results.historical_allocated_bytes += historical.stats.total_bytes;
    results.current_maximum_allocation = std::max(
        results.current_maximum_allocation, current.stats.maximum_bytes);
    results.historical_maximum_allocation = std::max(
        results.historical_maximum_allocation,
        historical.stats.maximum_bytes);

    const bool attempts_ordered =
        current.stats.attempts >= historical.stats.attempts;
    check(results, attempts_ordered, "allocation_attempt_order");
    const std::size_t attempt_addition = attempts_ordered ?
        current.stats.attempts - historical.stats.attempts : 0U;
    const bool bytes_ordered =
        current.stats.total_bytes <= historical.stats.total_bytes;
    check(results, bytes_ordered, "allocation_byte_order");
    const std::size_t byte_reduction = bytes_ordered ?
        historical.stats.total_bytes - current.stats.total_bytes : 0U;
    results.measured_allocation_attempts_added += attempt_addition;
    results.measured_allocated_bytes_reduced += byte_reduction;
    const bool attempts_exact =
        attempt_addition == expected_attempt_addition;
    results.allocation_relation_checks += attempts_exact ? 1U : 0U;
    check(results, attempts_exact, "allocation_attempt_addition");
    const bool bytes_exact = byte_reduction == expected_byte_reduction;
    results.allocation_relation_checks += bytes_exact ? 1U : 0U;
    check(results, bytes_exact, "allocation_byte_reduction");
    const bool maximum_not_increased =
        current.stats.maximum_bytes <= historical.stats.maximum_bytes;
    results.allocation_relation_checks += maximum_not_increased ? 1U : 0U;
    check(results, maximum_not_increased, "allocation_maximum_relation");

    inject_allocation_failures(
        results,
        payload,
        current,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        },
        true);
    inject_allocation_failures(
        results,
        payload,
        historical,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0485(bytes);
        },
        false);
}

void allocation_cases(Results& results) {
    NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error);
    allocation_scenario(results, encode_message(results, error), 0U, 0U);

    NATravPeerHandshakeMessage inline_boundary =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(
        inline_boundary,
        datacube::kNATravPeerInlineCapabilitySpanCapacity);
    allocation_scenario(
        results, encode_message(results, inline_boundary), 0U, 0U);

    NATravPeerHandshakeMessage first_spill =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fill_capabilities(
        first_spill,
        datacube::kNATravPeerInlineCapabilitySpanCapacity + 1U);
    allocation_scenario(
        results,
        encode_message(results, first_spill),
        0U,
        0U);

    NATravPeerHandshakeMessage medium_129 =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(medium_129, 129U);
    allocation_scenario(
        results,
        encode_message(results, medium_129),
        0U,
        7616U);

    NATravPeerHandshakeMessage medium_512 =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fill_capabilities(medium_512, 512U);
    allocation_scenario(
        results,
        encode_message(results, medium_512),
        1U,
        6592U);

    NATravPeerHandshakeMessage medium_1024 =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(medium_1024, 1024U);
    allocation_scenario(
        results,
        encode_message(results, medium_1024),
        2U,
        4544U);

    NATravPeerHandshakeMessage large =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fill_capabilities(large, 7000U);
    allocation_scenario(
        results,
        encode_message(results, large),
        3U,
        0U);
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    random_corpus(results);
    direct_storage_boundaries(results);
    allocation_cases(results);

    const std::size_t injected_total =
        results.injected_current_failures +
        results.injected_historical_failures;
    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.common_case_zero_spill_cases ==
                results.common_case_zero_spill_checks &&
            results.spill_path_cases == results.spill_path_checks &&
            results.storage_boundary_cases ==
                results.storage_boundary_checks &&
            results.current_storage_instances == results.semantic_cases &&
            results.historical_storage_instances == results.semantic_cases &&
            results.current_inline_appends + results.current_spill_appends ==
                results.historical_appends &&
            results.current_inline_reads + results.current_spill_reads ==
                results.historical_reads &&
            results.current_spill_activations > 0U &&
            results.current_spill_reservations >
                results.historical_spill_reservations &&
            results.current_spill_reserved_capacity <
                results.historical_spill_reserved_capacity &&
            results.current_relocated_spans == 0U &&
            results.historical_relocated_spans == 0U &&
            results.medium_reservation_cases ==
                results.medium_reservation_checks &&
            results.current_medium_reserved_capacity == 1600U &&
            results.historical_medium_reserved_capacity == 6288U &&
            results.medium_reserved_capacity_reduced == 4688U &&
            results.allocation_relation_checks ==
                results.allocation_scenarios * 3U &&
            results.measured_allocation_attempts_added == 6U &&
            results.measured_allocated_bytes_reduced == 18752U &&
            results.exception_type_checks == injected_total &&
            results.exception_ordinal_checks == injected_total &&
            results.input_preservation_checks == injected_total &&
            results.retry_checks == injected_total,
        "coverage_and_span_storage_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(current_storage_instances);
    PRINT_RESULT(current_inline_appends);
    PRINT_RESULT(current_spill_appends);
    PRINT_RESULT(current_spill_activations);
    PRINT_RESULT(current_spill_reservations);
    PRINT_RESULT(current_spill_reserved_capacity);
    PRINT_RESULT(current_maximum_spill_capacity);
    PRINT_RESULT(current_inline_reads);
    PRINT_RESULT(current_spill_reads);
    PRINT_RESULT(current_relocated_spans);
    PRINT_RESULT(historical_storage_instances);
    PRINT_RESULT(historical_appends);
    PRINT_RESULT(historical_reads);
    PRINT_RESULT(historical_spill_reservations);
    PRINT_RESULT(historical_spill_reserved_capacity);
    PRINT_RESULT(historical_maximum_spill_capacity);
    PRINT_RESULT(historical_relocated_spans);
    PRINT_RESULT(common_case_zero_spill_cases);
    PRINT_RESULT(common_case_zero_spill_checks);
    PRINT_RESULT(spill_path_cases);
    PRINT_RESULT(spill_path_checks);
    PRINT_RESULT(storage_boundary_cases);
    PRINT_RESULT(storage_boundary_checks);
    PRINT_RESULT(inline_capacity);
    PRINT_RESULT(first_spill_chunk_capacity);
    PRINT_RESULT(tier_one_chunk_capacity);
    PRINT_RESULT(tier_two_chunk_capacity);
    PRINT_RESULT(tier_three_chunk_capacity);
    PRINT_RESULT(tier_four_chunk_capacity);
    PRINT_RESULT(tier_chunk_count);
    PRINT_RESULT(uniform_tail_chunk_capacity);
    PRINT_RESULT(uniform_tail_chunk_count);
    PRINT_RESULT(maximum_chunk_count);
    PRINT_RESULT(production_storage_bytes);
    PRINT_RESULT(revision_0485_production_storage_bytes);
    PRINT_RESULT(production_storage_bytes_added);
    PRINT_RESULT(production_preflight_observation_bytes);
    PRINT_RESULT(instrumented_storage_bytes);
    PRINT_RESULT(instrumented_preflight_observation_bytes);
    PRINT_RESULT(medium_reservation_cases);
    PRINT_RESULT(medium_reservation_checks);
    PRINT_RESULT(current_medium_reserved_capacity);
    PRINT_RESULT(historical_medium_reserved_capacity);
    PRINT_RESULT(medium_reserved_capacity_reduced);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(current_allocation_attempts);
    PRINT_RESULT(historical_allocation_attempts);
    PRINT_RESULT(current_allocated_bytes);
    PRINT_RESULT(historical_allocated_bytes);
    PRINT_RESULT(current_maximum_allocation);
    PRINT_RESULT(historical_maximum_allocation);
    PRINT_RESULT(measured_allocation_attempts_added);
    PRINT_RESULT(measured_allocated_bytes_reduced);
    PRINT_RESULT(allocation_relation_checks);
    PRINT_RESULT(injected_current_failures);
    PRINT_RESULT(injected_historical_failures);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_capability_span_tiered_storage_test

int main() {
    try {
        return natrav_capability_span_tiered_storage_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(
            natrav_capability_span_tiered_storage_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_TIERED_STORAGE_TEST

// Revision 0487 opt-in local regression: excluded from normal runtime/forge builds.
#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_capability_span_lazy_tail_directory_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t injection_point) noexcept :
        point(injection_point) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_BAD_ALLOC";
    }
    std::size_t point;
};

struct Stats final {
    std::size_t attempts{0U};
    std::size_t total_bytes{0U};
    std::size_t maximum_bytes{0U};
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    Stats stats;
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .stats = {},
    };
}

[[nodiscard]] Stats disarm() noexcept {
    const Stats stats = state.stats;
    state.armed = false;
    return stats;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_capability_span_lazy_tail_directory_allocation_test

void* operator new(const std::size_t size) {
    return natrav_capability_span_lazy_tail_directory_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_capability_span_lazy_tail_directory_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_capability_span_lazy_tail_directory_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_capability_span_lazy_tail_directory_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_capability_span_lazy_tail_directory_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_capability_span_lazy_tail_directory_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_span_lazy_tail_directory_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_span_lazy_tail_directory_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_span_lazy_tail_directory_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_span_lazy_tail_directory_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_span_lazy_tail_directory_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_span_lazy_tail_directory_allocation_test::release(pointer);
}

namespace natrav_capability_span_lazy_tail_directory_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_capability_span_lazy_tail_directory_allocation_test::Stats;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t current_storage_instances{0U};
    std::size_t current_inline_appends{0U};
    std::size_t current_spill_appends{0U};
    std::size_t current_spill_activations{0U};
    std::size_t current_spill_reservations{0U};
    std::size_t current_spill_reserved_capacity{0U};
    std::size_t current_maximum_spill_capacity{0U};
    std::size_t current_inline_reads{0U};
    std::size_t current_spill_reads{0U};
    std::size_t current_tail_directory_allocations{0U};
    std::size_t current_relocated_spans{0U};
    std::size_t historical_storage_instances{0U};
    std::size_t historical_appends{0U};
    std::size_t historical_reads{0U};
    std::size_t historical_spill_reservations{0U};
    std::size_t historical_spill_reserved_capacity{0U};
    std::size_t historical_maximum_spill_capacity{0U};
    std::size_t historical_relocated_spans{0U};
    std::size_t common_case_zero_spill_cases{0U};
    std::size_t common_case_zero_spill_checks{0U};
    std::size_t spill_path_cases{0U};
    std::size_t spill_path_checks{0U};
    std::size_t storage_boundary_cases{0U};
    std::size_t storage_boundary_checks{0U};
    std::size_t tail_directory_boundary_cases{0U};
    std::size_t tail_directory_boundary_checks{0U};
    std::size_t transactional_failure_cases{0U};
    std::size_t transactional_failure_checks{0U};
    std::size_t inline_capacity{0U};
    std::size_t first_spill_chunk_capacity{0U};
    std::size_t tier_one_chunk_capacity{0U};
    std::size_t tier_two_chunk_capacity{0U};
    std::size_t tier_three_chunk_capacity{0U};
    std::size_t tier_four_chunk_capacity{0U};
    std::size_t tier_chunk_count{0U};
    std::size_t uniform_tail_chunk_capacity{0U};
    std::size_t uniform_tail_chunk_count{0U};
    std::size_t maximum_chunk_count{0U};
    std::size_t early_owner_count{0U};
    std::size_t lazy_tail_owner_count{0U};
    std::size_t tail_directory_activation_span_count{0U};
    std::size_t production_storage_bytes{0U};
    std::size_t revision_0486_production_storage_bytes{0U};
    std::size_t production_storage_bytes_reduced{0U};
    std::size_t production_preflight_observation_bytes{0U};
    std::size_t revision_0486_preflight_observation_bytes{0U};
    std::size_t preflight_observation_bytes_reduced{0U};
    std::size_t instrumented_storage_bytes{0U};
    std::size_t instrumented_preflight_observation_bytes{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t current_allocation_attempts{0U};
    std::size_t historical_allocation_attempts{0U};
    std::size_t current_allocated_bytes{0U};
    std::size_t historical_allocated_bytes{0U};
    std::size_t current_maximum_allocation{0U};
    std::size_t historical_maximum_allocation{0U};
    std::size_t measured_allocation_attempts_added{0U};
    std::size_t measured_allocated_bytes_added{0U};
    std::size_t allocation_relation_checks{0U};
    std::size_t injected_current_failures{0U};
    std::size_t injected_historical_failures{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t failures{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::int64_t minor = 0) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = minor,
    };
    message.request_id.assign(64U, 'a');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = std::string(64U, 'b'),
            .target = "linux-x86_64",
            .version = "v1",
        };
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "capability-span-tiered-storage";
    }
    return message;
}

[[nodiscard]] std::string capability_name(const std::size_t index) {
    std::string digits = std::to_string(index);
    if (digits.size() > 4U) {
        throw std::runtime_error("capability-index-range");
    }
    std::string token = "C";
    token.append(4U - digits.size(), '0');
    token.append(digits);
    return token;
}

void fill_capabilities(
    NATravPeerHandshakeMessage& message,
    const std::size_t count) {
    std::vector<std::string>& capabilities =
        message.kind == NATravPeerHandshakeMessageKind::hello ?
            message.required_capabilities :
            message.available_capabilities;
    capabilities.reserve(count);
    for (std::size_t index = 0U; index < count; ++index) {
        capabilities.push_back(capability_name(index));
    }
}

[[nodiscard]] Octets encode_message(
    Results& results,
    const NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    check(
        results,
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "fixture_encoding");
    return encoded.payload.value_or(Octets{});
}

struct CountedDecode final {
    NATravPeerMessageDecodeObservation observation;
    datacube::CanonicalCapabilitySpanChunkStorageCounters counters;
};

[[nodiscard]] CountedDecode current_decode(const Octets& payload) {
    datacube::reset_canonical_capability_span_chunk_storage_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_capability_span_chunk_storage_counters(),
    };
}

[[nodiscard]] CountedDecode historical_decode(const Octets& payload) {
    datacube::reset_canonical_capability_span_chunk_storage_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0486(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_capability_span_chunk_storage_counters(),
    };
}

void accumulate_current(
    Results& results,
    const datacube::CanonicalCapabilitySpanChunkStorageCounters& counters) {
    results.current_storage_instances += counters.storage_instances;
    results.current_inline_appends += counters.inline_appends;
    results.current_spill_appends += counters.spill_appends;
    results.current_spill_activations += counters.spill_activations;
    results.current_spill_reservations += counters.spill_reservations;
    results.current_spill_reserved_capacity +=
        counters.spill_reserved_capacity;
    results.current_maximum_spill_capacity = std::max(
        results.current_maximum_spill_capacity,
        counters.maximum_spill_capacity);
    results.current_inline_reads += counters.inline_reads;
    results.current_spill_reads += counters.spill_reads;
    results.current_tail_directory_allocations +=
        counters.tail_directory_allocations;
    results.current_relocated_spans += counters.current_relocated_spans;
}

void accumulate_historical(
    Results& results,
    const datacube::CanonicalCapabilitySpanChunkStorageCounters& counters) {
    results.historical_storage_instances += counters.storage_instances;
    results.historical_appends += counters.historical_appends;
    results.historical_reads += counters.historical_reads;
    results.historical_spill_reservations += counters.historical_reservations;
    results.historical_spill_reserved_capacity +=
        counters.historical_reserved_capacity;
    results.historical_maximum_spill_capacity = std::max(
        results.historical_maximum_spill_capacity,
        counters.historical_maximum_capacity);
    results.historical_relocated_spans += counters.historical_relocated_spans;
}

[[nodiscard]] CountedDecode compare_semantics(
    Results& results,
    const Octets& payload,
    const std::optional<NATravPeerMessageDecodeStatus> expected =
        std::nullopt) {
    CountedDecode current = current_decode(payload);
    const CountedDecode historical = historical_decode(payload);
    ++results.semantic_cases;
    accumulate_current(results, current.counters);
    accumulate_historical(results, historical.counters);

    const bool equal = same_observation(
        current.observation, historical.observation);
    results.exact_observation_comparisons += equal ? 1U : 0U;
    check(results, equal, "exact_observation_match");

    if (expected) {
        ++results.classification_priority_cases;
        const bool exact = current.observation.status == *expected;
        results.exact_classifications += exact ? 1U : 0U;
        check(results, exact, "exact_expected_classification");
    }

    if (current.observation.status != NATravPeerMessageDecodeStatus::accepted ||
        !current.observation.message) {
        ++results.rejection_cases;
        return current;
    }

    ++results.accepted_cases;
    const auto encoded = datacube::natrav_peer_encode_message(
        *current.observation.message);
    const bool roundtrip =
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
        encoded.payload && *encoded.payload == payload;
    results.exact_roundtrips += roundtrip ? 1U : 0U;
    check(results, roundtrip, "exact_roundtrip");
    return current;
}

void check_zero_spill_case(
    Results& results,
    const CountedDecode& decoded,
    const std::size_t expected_inline) {
    ++results.common_case_zero_spill_cases;
    const bool exact =
        decoded.counters.inline_appends == expected_inline &&
        decoded.counters.spill_appends == 0U &&
        decoded.counters.spill_activations == 0U &&
        decoded.counters.spill_reservations == 0U &&
        decoded.counters.tail_directory_allocations == 0U &&
        decoded.counters.maximum_spill_capacity == 0U;
    results.common_case_zero_spill_checks += exact ? 1U : 0U;
    check(results, exact, "common_case_zero_spill");
}

void check_spill_case(
    Results& results,
    const CountedDecode& decoded,
    const std::size_t expected_spill,
    const std::size_t expected_reservations,
    const std::size_t expected_maximum_capacity,
    const std::size_t expected_tail_directory_allocations) {
    ++results.spill_path_cases;
    const bool exact =
        decoded.counters.inline_appends ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        decoded.counters.spill_appends == expected_spill &&
        decoded.counters.spill_activations == 1U &&
        decoded.counters.spill_reservations == expected_reservations &&
        decoded.counters.maximum_spill_capacity ==
            expected_maximum_capacity &&
        decoded.counters.tail_directory_allocations ==
            expected_tail_directory_allocations &&
        decoded.counters.inline_reads ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        decoded.counters.spill_reads == expected_spill;
    results.spill_path_checks += exact ? 1U : 0U;
    check(results, exact, "spill_path_exact");
}

void accepted_corpus(Results& results) {
    NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error, 1);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, error)),
        0U);

    NATravPeerHandshakeMessage empty =
        base_message(NATravPeerHandshakeMessageKind::hello, 2);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, empty)),
        0U);

    NATravPeerHandshakeMessage one =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 3);
    fill_capabilities(one, 1U);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, one)),
        1U);

    NATravPeerHandshakeMessage inline_boundary =
        base_message(NATravPeerHandshakeMessageKind::hello, 4);
    fill_capabilities(
        inline_boundary,
        datacube::kNATravPeerInlineCapabilitySpanCapacity);
    check_zero_spill_case(
        results,
        compare_semantics(
            results, encode_message(results, inline_boundary)),
        datacube::kNATravPeerInlineCapabilitySpanCapacity);

    NATravPeerHandshakeMessage first_spill =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 5);
    fill_capabilities(
        first_spill,
        datacube::kNATravPeerInlineCapabilitySpanCapacity + 1U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, first_spill)),
        1U,
        1U,
        datacube::kNATravPeerInlineCapabilitySpanCapacity,
        0U);

    NATravPeerHandshakeMessage medium_129 =
        base_message(NATravPeerHandshakeMessageKind::hello, 6);
    fill_capabilities(medium_129, 129U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, medium_129)),
        129U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        2U,
        datacube::kNATravPeerCapabilitySpanChunkCapacities[1U],
        0U);

    NATravPeerHandshakeMessage medium_512 =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 7);
    fill_capabilities(medium_512, 512U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, medium_512)),
        512U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        3U,
        datacube::kNATravPeerCapabilitySpanChunkCapacities[2U],
        0U);

    NATravPeerHandshakeMessage medium_1024 =
        base_message(NATravPeerHandshakeMessageKind::hello, 8);
    fill_capabilities(medium_1024, 1024U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, medium_1024)),
        1024U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        4U,
        datacube::kNATravPeerCapabilitySpanChunkCapacities[3U],
        0U);

    NATravPeerHandshakeMessage large =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 9);
    fill_capabilities(large, 7000U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, large)),
        7000U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        8U,
        datacube::kNATravPeerCapabilitySpanTailChunkCapacity,
        1U);

    for (std::size_t fixture = 0U; fixture < 128U; ++fixture) {
        const NATravPeerHandshakeMessageKind kind = fixture % 2U == 0U ?
            NATravPeerHandshakeMessageKind::hello :
            NATravPeerHandshakeMessageKind::hello_ack;
        NATravPeerHandshakeMessage message = base_message(
            kind, static_cast<std::int64_t>(fixture + 10U));
        fill_capabilities(message, fixture % 96U);
        static_cast<void>(compare_semantics(
            results, encode_message(results, message)));
    }
}

[[nodiscard]] std::string payload_text(const Octets& payload) {
    std::string text;
    text.reserve(payload.size());
    for (const std::uint8_t byte : payload) {
        text.push_back(static_cast<char>(byte));
    }
    return text;
}

[[nodiscard]] Octets payload_bytes(const std::string_view text) {
    Octets payload;
    payload.reserve(text.size());
    for (const char character : text) {
        payload.push_back(static_cast<std::uint8_t>(
            static_cast<unsigned char>(character)));
    }
    return payload;
}

[[nodiscard]] Octets replace_once(
    const Octets& payload,
    const std::string_view before,
    const std::string_view after) {
    std::string text = payload_text(payload);
    const std::size_t offset = text.find(before);
    if (offset == std::string::npos) {
        throw std::runtime_error("fixture-replacement-missing");
    }
    text.replace(offset, before.size(), after);
    return payload_bytes(text);
}

void priority_cases(Results& results) {
    NATravPeerHandshakeMessage message =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(message, 2U);
    const Octets valid = encode_message(results, message);

    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0001\",\"C0000\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0000\",\"C0000\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0000\",1]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "\"major\":1", "\"major\":2"),
        NATravPeerMessageDecodeStatus::protocol_mismatch));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'a'), std::string(64U, 'z')),
        NATravPeerMessageDecodeStatus::request_id_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'b'),
                     std::string("z") + std::string(63U, 'b')),
        NATravPeerMessageDecodeStatus::artifact_identity_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "\"HELLO\"", "\"OTHER\""),
        NATravPeerMessageDecodeStatus::message_kind_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "},\"kind\":", "},\"extra\":0,\"kind\":"),
        NATravPeerMessageDecodeStatus::schema_rejected));

    std::string malformed = payload_text(valid);
    malformed.pop_back();
    static_cast<void>(compare_semantics(
        results,
        payload_bytes(malformed),
        NATravPeerMessageDecodeStatus::malformed_json));
    static_cast<void>(compare_semantics(
        results,
        payload_bytes(std::string(" ") + payload_text(valid)),
        NATravPeerMessageDecodeStatus::noncanonical_json));
    static_cast<void>(compare_semantics(
        results,
        payload_bytes("[]"),
        NATravPeerMessageDecodeStatus::schema_rejected));
}

void random_corpus(Results& results) {
    std::uint64_t state = 0xd1b54a32d192ed03ULL;
    for (std::size_t fixture = 0U; fixture < 4096U; ++fixture) {
        state ^= state << 13U;
        state ^= state >> 7U;
        state ^= state << 17U;
        const std::size_t length = 2U +
            static_cast<std::size_t>(state % 191U);
        Octets payload;
        payload.reserve(length);
        for (std::size_t index = 0U; index < length; ++index) {
            state ^= state << 13U;
            state ^= state >> 7U;
            state ^= state << 17U;
            payload.push_back(static_cast<std::uint8_t>(state & 0xFFU));
        }
        static_cast<void>(compare_semantics(results, payload));
        ++results.random_cases;
    }
}

using CapabilitySpanChunkOwner =
    std::unique_ptr<datacube::CanonicalCapabilityEntrySpan[]>;
using CapabilitySpanTailOwnerDirectory = std::array<
    CapabilitySpanChunkOwner,
    datacube::kNATravPeerCapabilitySpanLazyTailOwnerCount>;

struct ProductionCapabilitySpanStorageLayout final {
    std::array<
        datacube::CanonicalCapabilityEntrySpan,
        datacube::kNATravPeerInlineCapabilitySpanCapacity> inline_storage{};
    std::size_t inline_size{0U};
    std::array<
        CapabilitySpanChunkOwner,
        datacube::kNATravPeerCapabilitySpanEarlyOwnerCount>
        early_spill_chunks{};
    std::unique_ptr<CapabilitySpanTailOwnerDirectory> tail_spill_chunks;
    std::size_t spill_size{0U};
};

struct Revision0486CapabilitySpanStorageLayout final {
    std::array<
        datacube::CanonicalCapabilityEntrySpan,
        datacube::kNATravPeerInlineCapabilitySpanCapacity> inline_storage{};
    std::size_t inline_size{0U};
    std::array<
        CapabilitySpanChunkOwner,
        datacube::kNATravPeerTieredCapabilitySpanChunkCount> spill_chunks{};
    std::size_t spill_size{0U};
};

[[nodiscard]] constexpr std::size_t tail_directory_activation_span_count() {
    std::size_t count = datacube::kNATravPeerInlineCapabilitySpanCapacity;
    for (std::size_t index = 0U;
         index < datacube::kNATravPeerCapabilitySpanEarlyOwnerCount;
         ++index) {
        count += datacube::kNATravPeerCapabilitySpanChunkCapacities[index];
    }
    return count;
}

void direct_storage_boundaries(Results& results) {
    results.inline_capacity =
        datacube::kNATravPeerInlineCapabilitySpanCapacity;
    results.first_spill_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[0U];
    results.tier_one_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[1U];
    results.tier_two_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[2U];
    results.tier_three_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[3U];
    results.tier_four_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[4U];
    results.tier_chunk_count =
        datacube::kNATravPeerCapabilitySpanTierChunkCount;
    results.uniform_tail_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[5U];
    results.uniform_tail_chunk_count =
        datacube::kNATravPeerCapabilitySpanUniformTailChunkCount;
    results.maximum_chunk_count =
        datacube::kNATravPeerCapabilitySpanChunkCount;
    results.early_owner_count =
        datacube::kNATravPeerCapabilitySpanEarlyOwnerCount;
    results.lazy_tail_owner_count =
        datacube::kNATravPeerCapabilitySpanLazyTailOwnerCount;
    results.tail_directory_activation_span_count =
        tail_directory_activation_span_count();
    results.production_storage_bytes =
        sizeof(ProductionCapabilitySpanStorageLayout);
    results.revision_0486_production_storage_bytes =
        sizeof(Revision0486CapabilitySpanStorageLayout);
    results.production_storage_bytes_reduced =
        results.revision_0486_production_storage_bytes -
        results.production_storage_bytes;
    results.instrumented_storage_bytes =
        sizeof(datacube::CanonicalCapabilityEntrySpanStorage);
    results.instrumented_preflight_observation_bytes =
        sizeof(datacube::CanonicalMessagePreflightObservation);
    results.production_preflight_observation_bytes =
        results.instrumented_preflight_observation_bytes -
        (results.instrumented_storage_bytes -
         results.production_storage_bytes);
    results.revision_0486_preflight_observation_bytes = 1320U;
    results.preflight_observation_bytes_reduced =
        results.revision_0486_preflight_observation_bytes -
        results.production_preflight_observation_bytes;

    ++results.storage_boundary_cases;
    const bool footprint =
        results.inline_capacity == 64U &&
        results.first_spill_chunk_capacity == 64U &&
        results.tier_one_chunk_capacity == 128U &&
        results.tier_two_chunk_capacity == 256U &&
        results.tier_three_chunk_capacity == 512U &&
        results.tier_four_chunk_capacity == 1136U &&
        results.tier_chunk_count == 4U &&
        results.uniform_tail_chunk_capacity == 2032U &&
        results.uniform_tail_chunk_count == 7U &&
        results.maximum_chunk_count == 12U &&
        results.early_owner_count == 5U &&
        results.lazy_tail_owner_count == 7U &&
        results.tail_directory_activation_span_count == 2160U &&
        results.production_storage_bytes == 320U &&
        results.revision_0486_production_storage_bytes == 368U &&
        results.production_storage_bytes_reduced == 48U &&
        results.production_preflight_observation_bytes == 1272U &&
        results.revision_0486_preflight_observation_bytes == 1320U &&
        results.preflight_observation_bytes_reduced == 48U &&
        results.instrumented_storage_bytes == 432U &&
        results.instrumented_preflight_observation_bytes == 1384U;
    results.storage_boundary_checks += footprint ? 1U : 0U;
    check(results, footprint, "storage_footprint");

    datacube::reset_canonical_capability_span_chunk_storage_counters();
    datacube::CanonicalCapabilityEntrySpanStorage threshold_storage;
    bool threshold_appended = true;
    for (std::size_t index = 0U;
         index < results.tail_directory_activation_span_count;
         ++index) {
        threshold_appended = threshold_appended && threshold_storage.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = static_cast<std::uint16_t>(index),
                .content_size = 1U,
            });
    }
    const auto before_tail =
        datacube::read_canonical_capability_span_chunk_storage_counters();
    ++results.tail_directory_boundary_cases;
    const bool before_tail_exact =
        threshold_appended &&
        threshold_storage.size() ==
            results.tail_directory_activation_span_count &&
        threshold_storage.spill_chunk_count() ==
            datacube::kNATravPeerCapabilitySpanEarlyOwnerCount &&
        !threshold_storage.tail_owner_directory_materialized() &&
        before_tail.tail_directory_allocations == 0U &&
        before_tail.spill_reservations ==
            datacube::kNATravPeerCapabilitySpanEarlyOwnerCount;
    results.tail_directory_boundary_checks += before_tail_exact ? 1U : 0U;
    check(results, before_tail_exact, "tail_directory_not_materialized_early");

    const bool first_tail_appended = threshold_storage.append(
        datacube::CanonicalCapabilityEntrySpan{
            .content_offset = static_cast<std::uint16_t>(
                results.tail_directory_activation_span_count),
            .content_size = 1U,
        });
    const auto after_tail =
        datacube::read_canonical_capability_span_chunk_storage_counters();
    ++results.tail_directory_boundary_cases;
    const bool after_tail_exact =
        first_tail_appended &&
        threshold_storage.size() ==
            results.tail_directory_activation_span_count + 1U &&
        threshold_storage.spill_chunk_count() ==
            datacube::kNATravPeerCapabilitySpanEarlyOwnerCount + 1U &&
        threshold_storage.tail_owner_directory_materialized() &&
        after_tail.tail_directory_allocations == 1U &&
        after_tail.spill_reservations ==
            datacube::kNATravPeerCapabilitySpanEarlyOwnerCount + 1U;
    results.tail_directory_boundary_checks += after_tail_exact ? 1U : 0U;
    check(results, after_tail_exact, "tail_directory_materialized_at_boundary");

    for (std::size_t injection_point = 0U;
         injection_point < 2U;
         ++injection_point) {
        datacube::CanonicalCapabilityEntrySpanStorage storage;
        bool prepared = true;
        for (std::size_t index = 0U;
             index < results.tail_directory_activation_span_count;
             ++index) {
            prepared = prepared && storage.append(
                datacube::CanonicalCapabilityEntrySpan{
                    .content_offset = static_cast<std::uint16_t>(index),
                    .content_size = 1U,
                });
        }
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_capability_span_lazy_tail_directory_allocation_test::arm(
            injection_point);
        try {
            static_cast<void>(storage.append(
                datacube::CanonicalCapabilityEntrySpan{
                    .content_offset = static_cast<std::uint16_t>(
                        results.tail_directory_activation_span_count),
                    .content_size = 1U,
                }));
        } catch (const natrav_capability_span_lazy_tail_directory_allocation_test::
                     InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        } catch (...) {
        }
        const Stats failed_stats =
            natrav_capability_span_lazy_tail_directory_allocation_test::disarm();
        const bool preserved =
            prepared && caught && caught_point == injection_point &&
            failed_stats.attempts == injection_point + 1U &&
            storage.size() == results.tail_directory_activation_span_count &&
            !storage.tail_owner_directory_materialized() &&
            storage.at(results.tail_directory_activation_span_count - 1U)
                    .content_offset ==
                results.tail_directory_activation_span_count - 1U;
        const bool retry = storage.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = static_cast<std::uint16_t>(
                    results.tail_directory_activation_span_count),
                .content_size = 1U,
            });
        ++results.transactional_failure_cases;
        const bool exact =
            preserved && retry &&
            storage.size() ==
                results.tail_directory_activation_span_count + 1U &&
            storage.tail_owner_directory_materialized() &&
            storage.at(results.tail_directory_activation_span_count)
                    .content_offset ==
                results.tail_directory_activation_span_count;
        results.transactional_failure_checks += exact ? 1U : 0U;
        check(results, exact, "transactional_tail_directory_failure");
    }

    datacube::reset_canonical_capability_span_chunk_storage_counters();
    datacube::CanonicalCapabilityEntrySpanStorage storage;
    bool appended = true;
    for (std::size_t index = 0U;
         index < datacube::kNATravPeerMaximumJsonConstructionUnits;
         ++index) {
        appended = appended && storage.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = static_cast<std::uint16_t>(index),
                .content_size = 1U,
            });
    }
    const bool rejected_extra = !storage.append(
        datacube::CanonicalCapabilityEntrySpan{
            .content_offset = 0U,
            .content_size = 0U,
        });
    const auto counters =
        datacube::read_canonical_capability_span_chunk_storage_counters();

    ++results.storage_boundary_cases;
    const bool maximum_exact =
        appended && rejected_extra &&
        storage.size() == datacube::kNATravPeerMaximumJsonConstructionUnits &&
        storage.inline_size() ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        storage.spill_size() ==
            datacube::kNATravPeerMaximumJsonConstructionUnits -
                datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        storage.spill_chunk_count() ==
            datacube::kNATravPeerCapabilitySpanChunkCount &&
        storage.spill_allocated_capacity() == storage.spill_size() &&
        storage.maximum_chunk_capacity() ==
            datacube::kNATravPeerCapabilitySpanTailChunkCapacity &&
        storage.tail_owner_directory_materialized() &&
        counters.spill_activations == 1U &&
        counters.spill_reservations ==
            datacube::kNATravPeerCapabilitySpanChunkCount &&
        counters.tail_directory_allocations == 1U &&
        counters.spill_reserved_capacity == storage.spill_size() &&
        counters.maximum_spill_capacity ==
            datacube::kNATravPeerCapabilitySpanTailChunkCapacity &&
        counters.current_relocated_spans == 0U;
    results.storage_boundary_checks += maximum_exact ? 1U : 0U;
    check(results, maximum_exact, "storage_maximum_boundary");

    ++results.storage_boundary_cases;
    const bool reads_exact =
        storage.at(0U).content_offset == 0U &&
        storage.at(63U).content_offset == 63U &&
        storage.at(64U).content_offset == 64U &&
        storage.at(127U).content_offset == 127U &&
        storage.at(128U).content_offset == 128U &&
        storage.at(255U).content_offset == 255U &&
        storage.at(256U).content_offset == 256U &&
        storage.at(511U).content_offset == 511U &&
        storage.at(512U).content_offset == 512U &&
        storage.at(1023U).content_offset == 1023U &&
        storage.at(1024U).content_offset == 1024U &&
        storage.at(2159U).content_offset == 2159U &&
        storage.at(2160U).content_offset == 2160U &&
        storage.at(datacube::kNATravPeerMaximumJsonConstructionUnits - 1U)
                .content_offset ==
            datacube::kNATravPeerMaximumJsonConstructionUnits - 1U;
    results.storage_boundary_checks += reads_exact ? 1U : 0U;
    check(results, reads_exact, "storage_boundary_reads");
}

struct Baseline final {
    NATravPeerMessageDecodeObservation observation;
    Stats stats;
};

template <typename Decode>
[[nodiscard]] Baseline baseline_decode(
    const Octets& payload,
    Decode&& decode) {
    natrav_capability_span_lazy_tail_directory_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation;
    try {
        observation = decode(payload);
    } catch (...) {
        static_cast<void>(
            natrav_capability_span_lazy_tail_directory_allocation_test::disarm());
        throw;
    }
    const Stats stats =
        natrav_capability_span_lazy_tail_directory_allocation_test::disarm();
    return Baseline{
        .observation = std::move(observation),
        .stats = stats,
    };
}

template <typename Decode>
void inject_allocation_failures(
    Results& results,
    const Octets& payload,
    const Baseline& baseline,
    Decode&& decode,
    const bool current) {
    for (std::size_t point = 0U; point < baseline.stats.attempts; ++point) {
        const Octets before = payload;
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_capability_span_lazy_tail_directory_allocation_test::arm(point);
        try {
            static_cast<void>(decode(payload));
        } catch (const natrav_capability_span_lazy_tail_directory_allocation_test::
                     InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        } catch (...) {
        }
        static_cast<void>(
            natrav_capability_span_lazy_tail_directory_allocation_test::disarm());
        if (current) {
            ++results.injected_current_failures;
        } else {
            ++results.injected_historical_failures;
        }
        results.exception_type_checks += caught ? 1U : 0U;
        check(results, caught, "allocation_exception_type");
        const bool ordinal = caught_point == point;
        results.exception_ordinal_checks += ordinal ? 1U : 0U;
        check(results, ordinal, "allocation_exception_ordinal");
        const bool preserved = payload == before;
        results.input_preservation_checks += preserved ? 1U : 0U;
        check(results, preserved, "allocation_input_preserved");
        const NATravPeerMessageDecodeObservation retry = decode(payload);
        const bool retry_equal = same_observation(retry, baseline.observation);
        results.retry_checks += retry_equal ? 1U : 0U;
        check(results, retry_equal, "allocation_retry");
    }
}

void allocation_scenario(
    Results& results,
    const Octets& payload,
    const std::size_t expected_attempt_addition,
    const std::size_t expected_byte_addition) {
    ++results.allocation_scenarios;
    const Baseline current = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        });
    const Baseline historical = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0486(bytes);
        });
    check(
        results,
        same_observation(current.observation, historical.observation),
        "allocation_baseline_semantics");
    results.current_allocation_attempts += current.stats.attempts;
    results.historical_allocation_attempts += historical.stats.attempts;
    results.current_allocated_bytes += current.stats.total_bytes;
    results.historical_allocated_bytes += historical.stats.total_bytes;
    results.current_maximum_allocation = std::max(
        results.current_maximum_allocation, current.stats.maximum_bytes);
    results.historical_maximum_allocation = std::max(
        results.historical_maximum_allocation,
        historical.stats.maximum_bytes);

    const bool attempts_ordered =
        current.stats.attempts >= historical.stats.attempts;
    check(results, attempts_ordered, "allocation_attempt_order");
    const std::size_t attempt_addition = attempts_ordered ?
        current.stats.attempts - historical.stats.attempts : 0U;
    const bool bytes_ordered =
        current.stats.total_bytes >= historical.stats.total_bytes;
    check(results, bytes_ordered, "allocation_byte_order");
    const std::size_t byte_addition = bytes_ordered ?
        current.stats.total_bytes - historical.stats.total_bytes : 0U;
    results.measured_allocation_attempts_added += attempt_addition;
    results.measured_allocated_bytes_added += byte_addition;
    const bool attempts_exact =
        attempt_addition == expected_attempt_addition;
    results.allocation_relation_checks += attempts_exact ? 1U : 0U;
    check(results, attempts_exact, "allocation_attempt_addition");
    const bool bytes_exact = byte_addition == expected_byte_addition;
    results.allocation_relation_checks += bytes_exact ? 1U : 0U;
    check(results, bytes_exact, "allocation_byte_addition");
    const bool maximum_not_increased =
        current.stats.maximum_bytes <= historical.stats.maximum_bytes;
    results.allocation_relation_checks += maximum_not_increased ? 1U : 0U;
    check(results, maximum_not_increased, "allocation_maximum_relation");

    inject_allocation_failures(
        results,
        payload,
        current,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        },
        true);
    inject_allocation_failures(
        results,
        payload,
        historical,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0486(bytes);
        },
        false);
}

void allocation_cases(Results& results) {
    NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error);
    allocation_scenario(results, encode_message(results, error), 0U, 0U);

    NATravPeerHandshakeMessage inline_boundary =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(
        inline_boundary,
        datacube::kNATravPeerInlineCapabilitySpanCapacity);
    allocation_scenario(
        results, encode_message(results, inline_boundary), 0U, 0U);

    NATravPeerHandshakeMessage first_spill =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fill_capabilities(
        first_spill,
        datacube::kNATravPeerInlineCapabilitySpanCapacity + 1U);
    allocation_scenario(
        results,
        encode_message(results, first_spill),
        0U,
        0U);

    NATravPeerHandshakeMessage medium_129 =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(medium_129, 129U);
    allocation_scenario(
        results,
        encode_message(results, medium_129),
        0U,
        0U);

    NATravPeerHandshakeMessage medium_512 =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fill_capabilities(medium_512, 512U);
    allocation_scenario(
        results,
        encode_message(results, medium_512),
        0U,
        0U);

    NATravPeerHandshakeMessage medium_1024 =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(medium_1024, 1024U);
    allocation_scenario(
        results,
        encode_message(results, medium_1024),
        0U,
        0U);

    NATravPeerHandshakeMessage large =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fill_capabilities(large, 7000U);
    allocation_scenario(
        results,
        encode_message(results, large),
        1U,
        sizeof(CapabilitySpanTailOwnerDirectory));
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    random_corpus(results);
    direct_storage_boundaries(results);
    allocation_cases(results);

    const std::size_t injected_total =
        results.injected_current_failures +
        results.injected_historical_failures;
    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.common_case_zero_spill_cases ==
                results.common_case_zero_spill_checks &&
            results.spill_path_cases == results.spill_path_checks &&
            results.storage_boundary_cases ==
                results.storage_boundary_checks &&
            results.current_storage_instances == results.semantic_cases &&
            results.historical_storage_instances == results.semantic_cases &&
            results.current_inline_appends + results.current_spill_appends ==
                results.historical_appends &&
            results.current_inline_reads + results.current_spill_reads ==
                results.historical_reads &&
            results.current_spill_activations > 0U &&
            results.current_spill_reservations ==
                results.historical_spill_reservations &&
            results.current_spill_reserved_capacity ==
                results.historical_spill_reserved_capacity &&
            results.current_maximum_spill_capacity ==
                results.historical_maximum_spill_capacity &&
            results.current_tail_directory_allocations == 1U &&
            results.current_relocated_spans == 0U &&
            results.historical_relocated_spans == 0U &&
            results.tail_directory_boundary_cases ==
                results.tail_directory_boundary_checks &&
            results.transactional_failure_cases ==
                results.transactional_failure_checks &&
            results.transactional_failure_cases == 2U &&
            results.production_storage_bytes_reduced == 48U &&
            results.preflight_observation_bytes_reduced == 48U &&
            results.allocation_relation_checks ==
                results.allocation_scenarios * 3U &&
            results.measured_allocation_attempts_added == 1U &&
            results.measured_allocated_bytes_added ==
                sizeof(CapabilitySpanTailOwnerDirectory) &&
            results.exception_type_checks == injected_total &&
            results.exception_ordinal_checks == injected_total &&
            results.input_preservation_checks == injected_total &&
            results.retry_checks == injected_total,
        "coverage_and_span_storage_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(current_storage_instances);
    PRINT_RESULT(current_inline_appends);
    PRINT_RESULT(current_spill_appends);
    PRINT_RESULT(current_spill_activations);
    PRINT_RESULT(current_spill_reservations);
    PRINT_RESULT(current_spill_reserved_capacity);
    PRINT_RESULT(current_maximum_spill_capacity);
    PRINT_RESULT(current_inline_reads);
    PRINT_RESULT(current_spill_reads);
    PRINT_RESULT(current_tail_directory_allocations);
    PRINT_RESULT(current_relocated_spans);
    PRINT_RESULT(historical_storage_instances);
    PRINT_RESULT(historical_appends);
    PRINT_RESULT(historical_reads);
    PRINT_RESULT(historical_spill_reservations);
    PRINT_RESULT(historical_spill_reserved_capacity);
    PRINT_RESULT(historical_maximum_spill_capacity);
    PRINT_RESULT(historical_relocated_spans);
    PRINT_RESULT(common_case_zero_spill_cases);
    PRINT_RESULT(common_case_zero_spill_checks);
    PRINT_RESULT(spill_path_cases);
    PRINT_RESULT(spill_path_checks);
    PRINT_RESULT(storage_boundary_cases);
    PRINT_RESULT(storage_boundary_checks);
    PRINT_RESULT(tail_directory_boundary_cases);
    PRINT_RESULT(tail_directory_boundary_checks);
    PRINT_RESULT(transactional_failure_cases);
    PRINT_RESULT(transactional_failure_checks);
    PRINT_RESULT(inline_capacity);
    PRINT_RESULT(first_spill_chunk_capacity);
    PRINT_RESULT(tier_one_chunk_capacity);
    PRINT_RESULT(tier_two_chunk_capacity);
    PRINT_RESULT(tier_three_chunk_capacity);
    PRINT_RESULT(tier_four_chunk_capacity);
    PRINT_RESULT(tier_chunk_count);
    PRINT_RESULT(uniform_tail_chunk_capacity);
    PRINT_RESULT(uniform_tail_chunk_count);
    PRINT_RESULT(maximum_chunk_count);
    PRINT_RESULT(early_owner_count);
    PRINT_RESULT(lazy_tail_owner_count);
    PRINT_RESULT(tail_directory_activation_span_count);
    PRINT_RESULT(production_storage_bytes);
    PRINT_RESULT(revision_0486_production_storage_bytes);
    PRINT_RESULT(production_storage_bytes_reduced);
    PRINT_RESULT(production_preflight_observation_bytes);
    PRINT_RESULT(revision_0486_preflight_observation_bytes);
    PRINT_RESULT(preflight_observation_bytes_reduced);
    PRINT_RESULT(instrumented_storage_bytes);
    PRINT_RESULT(instrumented_preflight_observation_bytes);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(current_allocation_attempts);
    PRINT_RESULT(historical_allocation_attempts);
    PRINT_RESULT(current_allocated_bytes);
    PRINT_RESULT(historical_allocated_bytes);
    PRINT_RESULT(current_maximum_allocation);
    PRINT_RESULT(historical_maximum_allocation);
    PRINT_RESULT(measured_allocation_attempts_added);
    PRINT_RESULT(measured_allocated_bytes_added);
    PRINT_RESULT(allocation_relation_checks);
    PRINT_RESULT(injected_current_failures);
    PRINT_RESULT(injected_historical_failures);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_capability_span_lazy_tail_directory_test

int main() {
    try {
        return natrav_capability_span_lazy_tail_directory_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(
            natrav_capability_span_lazy_tail_directory_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_LAZY_TAIL_DIRECTORY_TEST


#ifdef DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_FUSED_TAIL_TEST
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>
#include <stdexcept>

namespace natrav_capability_span_fused_tail_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t injection_point) noexcept :
        point(injection_point) {}
    [[nodiscard]] const char* what() const noexcept override {
        return "NATRAV_CAPABILITY_SPAN_FUSED_TAIL_BAD_ALLOC";
    }
    std::size_t point;
};

struct Stats final {
    std::size_t attempts{0U};
    std::size_t total_bytes{0U};
    std::size_t maximum_bytes{0U};
};

struct State final {
    bool armed{false};
    std::size_t point{std::numeric_limits<std::size_t>::max()};
    Stats stats;
};

thread_local State state;

void arm(
    const std::size_t point =
        std::numeric_limits<std::size_t>::max()) noexcept {
    state = State{
        .armed = true,
        .point = point,
        .stats = {},
    };
}

[[nodiscard]] Stats disarm() noexcept {
    const Stats stats = state.stats;
    state.armed = false;
    return stats;
}

void* allocate(const std::size_t size) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* const result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) {
        throw std::bad_alloc();
    }
    return result;
}

void* aligned_allocate(
    const std::size_t size,
    const std::align_val_t alignment) {
    if (state.armed) {
        const std::size_t attempt = state.stats.attempts++;
        state.stats.total_bytes += size;
        state.stats.maximum_bytes =
            std::max(state.stats.maximum_bytes, size);
        if (attempt == state.point) {
            throw InjectedBadAlloc(attempt);
        }
    }
    void* result = nullptr;
    if (posix_memalign(
            &result,
            static_cast<std::size_t>(alignment),
            size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}

void release(void* const pointer) noexcept { std::free(pointer); }
}  // namespace natrav_capability_span_fused_tail_allocation_test

void* operator new(const std::size_t size) {
    return natrav_capability_span_fused_tail_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_capability_span_fused_tail_allocation_test::allocate(size);
}
void operator delete(void* const pointer) noexcept {
    natrav_capability_span_fused_tail_allocation_test::release(pointer);
}
void operator delete[](void* const pointer) noexcept {
    natrav_capability_span_fused_tail_allocation_test::release(pointer);
}
void operator delete(void* const pointer, const std::size_t) noexcept {
    natrav_capability_span_fused_tail_allocation_test::release(pointer);
}
void operator delete[](void* const pointer, const std::size_t) noexcept {
    natrav_capability_span_fused_tail_allocation_test::release(pointer);
}
void* operator new(
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_span_fused_tail_allocation_test::aligned_allocate(
        size, alignment);
}
void* operator new[](
    const std::size_t size,
    const std::align_val_t alignment) {
    return natrav_capability_span_fused_tail_allocation_test::aligned_allocate(
        size, alignment);
}
void operator delete(
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_span_fused_tail_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::align_val_t) noexcept {
    natrav_capability_span_fused_tail_allocation_test::release(pointer);
}
void operator delete(
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_span_fused_tail_allocation_test::release(pointer);
}
void operator delete[](
    void* const pointer,
    const std::size_t,
    const std::align_val_t) noexcept {
    natrav_capability_span_fused_tail_allocation_test::release(pointer);
}

namespace natrav_capability_span_fused_tail_test {
using datacube::NATravPeerHandshakeMessage;
using datacube::NATravPeerHandshakeMessageKind;
using datacube::NATravPeerMessageDecodeObservation;
using datacube::NATravPeerMessageDecodeStatus;
using datacube::NATravPeerMessageEncodeStatus;
using datacube::Octets;
using natrav_capability_span_fused_tail_allocation_test::Stats;

struct Results final {
    std::size_t semantic_cases{0U};
    std::size_t accepted_cases{0U};
    std::size_t rejection_cases{0U};
    std::size_t random_cases{0U};
    std::size_t exact_observation_comparisons{0U};
    std::size_t exact_roundtrips{0U};
    std::size_t classification_priority_cases{0U};
    std::size_t exact_classifications{0U};
    std::size_t current_storage_instances{0U};
    std::size_t current_inline_appends{0U};
    std::size_t current_spill_appends{0U};
    std::size_t current_spill_activations{0U};
    std::size_t current_spill_reservations{0U};
    std::size_t current_spill_reserved_capacity{0U};
    std::size_t current_maximum_spill_capacity{0U};
    std::size_t current_inline_reads{0U};
    std::size_t current_spill_reads{0U};
    std::size_t current_tail_directory_allocations{0U};
    std::size_t current_relocated_spans{0U};
    std::size_t historical_storage_instances{0U};
    std::size_t historical_appends{0U};
    std::size_t historical_reads{0U};
    std::size_t historical_spill_reservations{0U};
    std::size_t historical_spill_reserved_capacity{0U};
    std::size_t historical_maximum_spill_capacity{0U};
    std::size_t historical_relocated_spans{0U};
    std::size_t common_case_zero_spill_cases{0U};
    std::size_t common_case_zero_spill_checks{0U};
    std::size_t spill_path_cases{0U};
    std::size_t spill_path_checks{0U};
    std::size_t storage_boundary_cases{0U};
    std::size_t storage_boundary_checks{0U};
    std::size_t tail_directory_boundary_cases{0U};
    std::size_t tail_directory_boundary_checks{0U};
    std::size_t transactional_failure_cases{0U};
    std::size_t transactional_failure_checks{0U};
    std::size_t inline_capacity{0U};
    std::size_t first_spill_chunk_capacity{0U};
    std::size_t tier_one_chunk_capacity{0U};
    std::size_t tier_two_chunk_capacity{0U};
    std::size_t tier_three_chunk_capacity{0U};
    std::size_t tier_four_chunk_capacity{0U};
    std::size_t tier_chunk_count{0U};
    std::size_t uniform_tail_chunk_capacity{0U};
    std::size_t uniform_tail_chunk_count{0U};
    std::size_t maximum_chunk_count{0U};
    std::size_t early_owner_count{0U};
    std::size_t lazy_tail_owner_count{0U};
    std::size_t tail_directory_activation_span_count{0U};
    std::size_t production_storage_bytes{0U};
    std::size_t revision_0486_production_storage_bytes{0U};
    std::size_t production_storage_bytes_reduced{0U};
    std::size_t production_preflight_observation_bytes{0U};
    std::size_t revision_0486_preflight_observation_bytes{0U};
    std::size_t preflight_observation_bytes_reduced{0U};
    std::size_t instrumented_storage_bytes{0U};
    std::size_t instrumented_preflight_observation_bytes{0U};
    std::size_t allocation_scenarios{0U};
    std::size_t current_allocation_attempts{0U};
    std::size_t historical_allocation_attempts{0U};
    std::size_t current_allocated_bytes{0U};
    std::size_t historical_allocated_bytes{0U};
    std::size_t current_maximum_allocation{0U};
    std::size_t historical_maximum_allocation{0U};
    std::size_t measured_allocation_attempts_removed{0U};
    std::size_t measured_allocated_bytes_removed{0U};
    std::size_t allocation_relation_checks{0U};
    std::size_t injected_current_failures{0U};
    std::size_t injected_historical_failures{0U};
    std::size_t exception_type_checks{0U};
    std::size_t exception_ordinal_checks{0U};
    std::size_t input_preservation_checks{0U};
    std::size_t retry_checks{0U};
    std::size_t allocation_boundary_cases{0U};
    std::size_t allocation_boundary_checks{0U};
    std::size_t retained_address_checks{0U};
    std::size_t retained_address_verified{0U};
    std::size_t fused_activation_block_bytes{0U};
    std::size_t failures{0U};
};

void check(
    Results& results,
    const bool condition,
    const char* const label) noexcept {
    if (!condition) {
        ++results.failures;
        std::fprintf(stderr, "FAIL %s\n", label);
    }
}

[[nodiscard]] bool same_message(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) {
    return left.kind == right.kind &&
        left.protocol.id == right.protocol.id &&
        left.protocol.major == right.protocol.major &&
        left.protocol.minor == right.protocol.minor &&
        left.request_id == right.request_id &&
        left.artifact.sha256 == right.artifact.sha256 &&
        left.artifact.target == right.artifact.target &&
        left.artifact.version == right.artifact.version &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] bool same_observation(
    const NATravPeerMessageDecodeObservation& left,
    const NATravPeerMessageDecodeObservation& right) {
    if (left.status != right.status ||
        left.classification != right.classification ||
        left.message.has_value() != right.message.has_value()) {
        return false;
    }
    return !left.message || same_message(*left.message, *right.message);
}

[[nodiscard]] NATravPeerHandshakeMessage base_message(
    const NATravPeerHandshakeMessageKind kind,
    const std::int64_t minor = 0) {
    NATravPeerHandshakeMessage message;
    message.kind = kind;
    message.protocol = datacube::NATravPeerProtocolVersion{
        .id = "NATRAV_OVERLAY_PEER",
        .major = 1,
        .minor = minor,
    };
    message.request_id.assign(64U, 'a');
    if (kind == NATravPeerHandshakeMessageKind::hello ||
        kind == NATravPeerHandshakeMessageKind::hello_ack) {
        message.artifact = datacube::NATravPeerArtifactIdentity{
            .sha256 = std::string(64U, 'b'),
            .target = "linux-x86_64",
            .version = "v1",
        };
    } else {
        message.error_code = "OPERATION_FAILED";
        message.error_message = "capability-span-tiered-storage";
    }
    return message;
}

[[nodiscard]] std::string capability_name(const std::size_t index) {
    std::string digits = std::to_string(index);
    if (digits.size() > 4U) {
        throw std::runtime_error("capability-index-range");
    }
    std::string token = "C";
    token.append(4U - digits.size(), '0');
    token.append(digits);
    return token;
}

void fill_capabilities(
    NATravPeerHandshakeMessage& message,
    const std::size_t count) {
    std::vector<std::string>& capabilities =
        message.kind == NATravPeerHandshakeMessageKind::hello ?
            message.required_capabilities :
            message.available_capabilities;
    capabilities.reserve(count);
    for (std::size_t index = 0U; index < count; ++index) {
        capabilities.push_back(capability_name(index));
    }
}

[[nodiscard]] Octets encode_message(
    Results& results,
    const NATravPeerHandshakeMessage& message) {
    const auto encoded = datacube::natrav_peer_encode_message(message);
    check(
        results,
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
            encoded.payload.has_value(),
        "fixture_encoding");
    return encoded.payload.value_or(Octets{});
}

struct CountedDecode final {
    NATravPeerMessageDecodeObservation observation;
    datacube::CanonicalCapabilitySpanChunkStorageCounters counters;
};

[[nodiscard]] CountedDecode current_decode(const Octets& payload) {
    datacube::reset_canonical_capability_span_chunk_storage_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_capability_span_chunk_storage_counters(),
    };
}

[[nodiscard]] CountedDecode historical_decode(const Octets& payload) {
    datacube::reset_canonical_capability_span_chunk_storage_counters();
    NATravPeerMessageDecodeObservation observation =
        datacube::natrav_peer_decode_message_revision_0487(payload);
    return CountedDecode{
        .observation = std::move(observation),
        .counters =
            datacube::read_canonical_capability_span_chunk_storage_counters(),
    };
}

void accumulate_current(
    Results& results,
    const datacube::CanonicalCapabilitySpanChunkStorageCounters& counters) {
    results.current_storage_instances += counters.storage_instances;
    results.current_inline_appends += counters.inline_appends;
    results.current_spill_appends += counters.spill_appends;
    results.current_spill_activations += counters.spill_activations;
    results.current_spill_reservations += counters.spill_reservations;
    results.current_spill_reserved_capacity +=
        counters.spill_reserved_capacity;
    results.current_maximum_spill_capacity = std::max(
        results.current_maximum_spill_capacity,
        counters.maximum_spill_capacity);
    results.current_inline_reads += counters.inline_reads;
    results.current_spill_reads += counters.spill_reads;
    results.current_tail_directory_allocations +=
        counters.tail_directory_allocations;
    results.current_relocated_spans += counters.current_relocated_spans;
}

void accumulate_historical(
    Results& results,
    const datacube::CanonicalCapabilitySpanChunkStorageCounters& counters) {
    results.historical_storage_instances += counters.storage_instances;
    results.historical_appends += counters.inline_appends + counters.spill_appends;
    results.historical_reads += counters.inline_reads + counters.spill_reads;
    results.historical_spill_reservations += counters.spill_reservations;
    results.historical_spill_reserved_capacity +=
        counters.spill_reserved_capacity;
    results.historical_maximum_spill_capacity = std::max(
        results.historical_maximum_spill_capacity,
        counters.maximum_spill_capacity);
    results.historical_relocated_spans += counters.current_relocated_spans;
}

[[nodiscard]] CountedDecode compare_semantics(
    Results& results,
    const Octets& payload,
    const std::optional<NATravPeerMessageDecodeStatus> expected =
        std::nullopt) {
    CountedDecode current = current_decode(payload);
    const CountedDecode historical = historical_decode(payload);
    ++results.semantic_cases;
    accumulate_current(results, current.counters);
    accumulate_historical(results, historical.counters);

    const bool equal = same_observation(
        current.observation, historical.observation);
    results.exact_observation_comparisons += equal ? 1U : 0U;
    check(results, equal, "exact_observation_match");

    if (expected) {
        ++results.classification_priority_cases;
        const bool exact = current.observation.status == *expected;
        results.exact_classifications += exact ? 1U : 0U;
        check(results, exact, "exact_expected_classification");
    }

    if (current.observation.status != NATravPeerMessageDecodeStatus::accepted ||
        !current.observation.message) {
        ++results.rejection_cases;
        return current;
    }

    ++results.accepted_cases;
    const auto encoded = datacube::natrav_peer_encode_message(
        *current.observation.message);
    const bool roundtrip =
        encoded.status == NATravPeerMessageEncodeStatus::accepted &&
        encoded.payload && *encoded.payload == payload;
    results.exact_roundtrips += roundtrip ? 1U : 0U;
    check(results, roundtrip, "exact_roundtrip");
    return current;
}

void check_zero_spill_case(
    Results& results,
    const CountedDecode& decoded,
    const std::size_t expected_inline) {
    ++results.common_case_zero_spill_cases;
    const bool exact =
        decoded.counters.inline_appends == expected_inline &&
        decoded.counters.spill_appends == 0U &&
        decoded.counters.spill_activations == 0U &&
        decoded.counters.spill_reservations == 0U &&
        decoded.counters.tail_directory_allocations == 0U &&
        decoded.counters.maximum_spill_capacity == 0U;
    results.common_case_zero_spill_checks += exact ? 1U : 0U;
    check(results, exact, "common_case_zero_spill");
}

void check_spill_case(
    Results& results,
    const CountedDecode& decoded,
    const std::size_t expected_spill,
    const std::size_t expected_reservations,
    const std::size_t expected_maximum_capacity,
    const std::size_t expected_tail_directory_allocations) {
    ++results.spill_path_cases;
    const bool exact =
        decoded.counters.inline_appends ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        decoded.counters.spill_appends == expected_spill &&
        decoded.counters.spill_activations == 1U &&
        decoded.counters.spill_reservations == expected_reservations &&
        decoded.counters.maximum_spill_capacity ==
            expected_maximum_capacity &&
        decoded.counters.tail_directory_allocations ==
            expected_tail_directory_allocations &&
        decoded.counters.inline_reads ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        decoded.counters.spill_reads == expected_spill;
    results.spill_path_checks += exact ? 1U : 0U;
    check(results, exact, "spill_path_exact");
}

void accepted_corpus(Results& results) {
    NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error, 1);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, error)),
        0U);

    NATravPeerHandshakeMessage empty =
        base_message(NATravPeerHandshakeMessageKind::hello, 2);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, empty)),
        0U);

    NATravPeerHandshakeMessage one =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 3);
    fill_capabilities(one, 1U);
    check_zero_spill_case(
        results,
        compare_semantics(results, encode_message(results, one)),
        1U);

    NATravPeerHandshakeMessage inline_boundary =
        base_message(NATravPeerHandshakeMessageKind::hello, 4);
    fill_capabilities(
        inline_boundary,
        datacube::kNATravPeerInlineCapabilitySpanCapacity);
    check_zero_spill_case(
        results,
        compare_semantics(
            results, encode_message(results, inline_boundary)),
        datacube::kNATravPeerInlineCapabilitySpanCapacity);

    NATravPeerHandshakeMessage first_spill =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 5);
    fill_capabilities(
        first_spill,
        datacube::kNATravPeerInlineCapabilitySpanCapacity + 1U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, first_spill)),
        1U,
        1U,
        datacube::kNATravPeerInlineCapabilitySpanCapacity,
        0U);

    NATravPeerHandshakeMessage medium_129 =
        base_message(NATravPeerHandshakeMessageKind::hello, 6);
    fill_capabilities(medium_129, 129U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, medium_129)),
        129U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        2U,
        datacube::kNATravPeerCapabilitySpanChunkCapacities[1U],
        0U);

    NATravPeerHandshakeMessage medium_512 =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 7);
    fill_capabilities(medium_512, 512U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, medium_512)),
        512U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        3U,
        datacube::kNATravPeerCapabilitySpanChunkCapacities[2U],
        0U);

    NATravPeerHandshakeMessage medium_1024 =
        base_message(NATravPeerHandshakeMessageKind::hello, 8);
    fill_capabilities(medium_1024, 1024U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, medium_1024)),
        1024U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        4U,
        datacube::kNATravPeerCapabilitySpanChunkCapacities[3U],
        0U);

    NATravPeerHandshakeMessage large =
        base_message(NATravPeerHandshakeMessageKind::hello_ack, 9);
    fill_capabilities(large, 7000U);
    check_spill_case(
        results,
        compare_semantics(results, encode_message(results, large)),
        7000U - datacube::kNATravPeerInlineCapabilitySpanCapacity,
        8U,
        datacube::kNATravPeerCapabilitySpanTailChunkCapacity,
        1U);

    for (std::size_t fixture = 0U; fixture < 128U; ++fixture) {
        const NATravPeerHandshakeMessageKind kind = fixture % 2U == 0U ?
            NATravPeerHandshakeMessageKind::hello :
            NATravPeerHandshakeMessageKind::hello_ack;
        NATravPeerHandshakeMessage message = base_message(
            kind, static_cast<std::int64_t>(fixture + 10U));
        fill_capabilities(message, fixture % 96U);
        static_cast<void>(compare_semantics(
            results, encode_message(results, message)));
    }
}

[[nodiscard]] std::string payload_text(const Octets& payload) {
    std::string text;
    text.reserve(payload.size());
    for (const std::uint8_t byte : payload) {
        text.push_back(static_cast<char>(byte));
    }
    return text;
}

[[nodiscard]] Octets payload_bytes(const std::string_view text) {
    Octets payload;
    payload.reserve(text.size());
    for (const char character : text) {
        payload.push_back(static_cast<std::uint8_t>(
            static_cast<unsigned char>(character)));
    }
    return payload;
}

[[nodiscard]] Octets replace_once(
    const Octets& payload,
    const std::string_view before,
    const std::string_view after) {
    std::string text = payload_text(payload);
    const std::size_t offset = text.find(before);
    if (offset == std::string::npos) {
        throw std::runtime_error("fixture-replacement-missing");
    }
    text.replace(offset, before.size(), after);
    return payload_bytes(text);
}

void priority_cases(Results& results) {
    NATravPeerHandshakeMessage message =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(message, 2U);
    const Octets valid = encode_message(results, message);

    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0001\",\"C0000\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0000\",\"C0000\"]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "[\"C0000\",\"C0001\"]",
                     "[\"C0000\",1]"),
        NATravPeerMessageDecodeStatus::capability_declaration_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "\"major\":1", "\"major\":2"),
        NATravPeerMessageDecodeStatus::protocol_mismatch));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'a'), std::string(64U, 'z')),
        NATravPeerMessageDecodeStatus::request_id_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, std::string(64U, 'b'),
                     std::string("z") + std::string(63U, 'b')),
        NATravPeerMessageDecodeStatus::artifact_identity_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "\"HELLO\"", "\"OTHER\""),
        NATravPeerMessageDecodeStatus::message_kind_rejected));
    static_cast<void>(compare_semantics(
        results,
        replace_once(valid, "},\"kind\":", "},\"extra\":0,\"kind\":"),
        NATravPeerMessageDecodeStatus::schema_rejected));

    std::string malformed = payload_text(valid);
    malformed.pop_back();
    static_cast<void>(compare_semantics(
        results,
        payload_bytes(malformed),
        NATravPeerMessageDecodeStatus::malformed_json));
    static_cast<void>(compare_semantics(
        results,
        payload_bytes(std::string(" ") + payload_text(valid)),
        NATravPeerMessageDecodeStatus::noncanonical_json));
    static_cast<void>(compare_semantics(
        results,
        payload_bytes("[]"),
        NATravPeerMessageDecodeStatus::schema_rejected));
}

void random_corpus(Results& results) {
    std::uint64_t state = 0xd1b54a32d192ed03ULL;
    for (std::size_t fixture = 0U; fixture < 4096U; ++fixture) {
        state ^= state << 13U;
        state ^= state >> 7U;
        state ^= state << 17U;
        const std::size_t length = 2U +
            static_cast<std::size_t>(state % 191U);
        Octets payload;
        payload.reserve(length);
        for (std::size_t index = 0U; index < length; ++index) {
            state ^= state << 13U;
            state ^= state >> 7U;
            state ^= state << 17U;
            payload.push_back(static_cast<std::uint8_t>(state & 0xFFU));
        }
        static_cast<void>(compare_semantics(results, payload));
        ++results.random_cases;
    }
}

using CapabilitySpanChunkOwner =
    std::unique_ptr<datacube::CanonicalCapabilityEntrySpan[]>;
using CapabilitySpanTailOwnerDirectory = std::array<
    CapabilitySpanChunkOwner,
    datacube::kNATravPeerCapabilitySpanLazyTailOwnerCount>;

struct ProductionCapabilitySpanStorageLayout final {
    std::array<
        datacube::CanonicalCapabilityEntrySpan,
        datacube::kNATravPeerInlineCapabilitySpanCapacity> inline_storage{};
    std::size_t inline_size{0U};
    std::array<
        CapabilitySpanChunkOwner,
        datacube::kNATravPeerCapabilitySpanEarlyOwnerCount>
        early_spill_chunks{};
    std::unique_ptr<datacube::CanonicalCapabilitySpanTailActivationBlock> tail_spill_chunks;
    std::size_t spill_size{0U};
};

struct Revision0486CapabilitySpanStorageLayout final {
    std::array<
        datacube::CanonicalCapabilityEntrySpan,
        datacube::kNATravPeerInlineCapabilitySpanCapacity> inline_storage{};
    std::size_t inline_size{0U};
    std::array<
        CapabilitySpanChunkOwner,
        datacube::kNATravPeerTieredCapabilitySpanChunkCount> spill_chunks{};
    std::size_t spill_size{0U};
};

[[nodiscard]] constexpr std::size_t tail_directory_activation_span_count() {
    std::size_t count = datacube::kNATravPeerInlineCapabilitySpanCapacity;
    for (std::size_t index = 0U;
         index < datacube::kNATravPeerCapabilitySpanEarlyOwnerCount;
         ++index) {
        count += datacube::kNATravPeerCapabilitySpanChunkCapacities[index];
    }
    return count;
}

void direct_storage_boundaries(Results& results) {
    results.inline_capacity =
        datacube::kNATravPeerInlineCapabilitySpanCapacity;
    results.first_spill_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[0U];
    results.tier_one_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[1U];
    results.tier_two_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[2U];
    results.tier_three_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[3U];
    results.tier_four_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[4U];
    results.tier_chunk_count =
        datacube::kNATravPeerCapabilitySpanTierChunkCount;
    results.uniform_tail_chunk_capacity =
        datacube::kNATravPeerCapabilitySpanChunkCapacities[5U];
    results.uniform_tail_chunk_count =
        datacube::kNATravPeerCapabilitySpanUniformTailChunkCount;
    results.maximum_chunk_count =
        datacube::kNATravPeerCapabilitySpanChunkCount;
    results.early_owner_count =
        datacube::kNATravPeerCapabilitySpanEarlyOwnerCount;
    results.lazy_tail_owner_count =
        datacube::kNATravPeerCapabilitySpanLazyTailOwnerCount;
    results.tail_directory_activation_span_count =
        tail_directory_activation_span_count();
    results.production_storage_bytes =
        sizeof(ProductionCapabilitySpanStorageLayout);
    results.revision_0486_production_storage_bytes =
        sizeof(Revision0486CapabilitySpanStorageLayout);
    results.production_storage_bytes_reduced =
        results.revision_0486_production_storage_bytes -
        results.production_storage_bytes;
    results.instrumented_storage_bytes =
        sizeof(datacube::CanonicalCapabilityEntrySpanStorage);
    results.instrumented_preflight_observation_bytes =
        sizeof(datacube::CanonicalMessagePreflightObservation);
    results.production_preflight_observation_bytes =
        results.instrumented_preflight_observation_bytes -
        (results.instrumented_storage_bytes -
         results.production_storage_bytes);
    results.revision_0486_preflight_observation_bytes = 1320U;
    results.preflight_observation_bytes_reduced =
        results.revision_0486_preflight_observation_bytes -
        results.production_preflight_observation_bytes;

    ++results.storage_boundary_cases;
    const bool footprint =
        results.inline_capacity == 64U &&
        results.first_spill_chunk_capacity == 64U &&
        results.tier_one_chunk_capacity == 128U &&
        results.tier_two_chunk_capacity == 256U &&
        results.tier_three_chunk_capacity == 512U &&
        results.tier_four_chunk_capacity == 1136U &&
        results.tier_chunk_count == 4U &&
        results.uniform_tail_chunk_capacity == 2032U &&
        results.uniform_tail_chunk_count == 7U &&
        results.maximum_chunk_count == 12U &&
        results.early_owner_count == 5U &&
        results.lazy_tail_owner_count == 7U &&
        results.tail_directory_activation_span_count == 2160U &&
        results.production_storage_bytes == 320U &&
        results.revision_0486_production_storage_bytes == 368U &&
        results.production_storage_bytes_reduced == 48U &&
        results.production_preflight_observation_bytes == 1272U &&
        results.revision_0486_preflight_observation_bytes == 1320U &&
        results.preflight_observation_bytes_reduced == 48U &&
        results.instrumented_storage_bytes == 336U &&
        results.instrumented_preflight_observation_bytes == 1288U;
    results.storage_boundary_checks += footprint ? 1U : 0U;
    check(results, footprint, "storage_footprint");

    datacube::reset_canonical_capability_span_chunk_storage_counters();
    datacube::CanonicalCapabilityEntrySpanStorage threshold_storage;
    bool threshold_appended = true;
    for (std::size_t index = 0U;
         index < results.tail_directory_activation_span_count;
         ++index) {
        threshold_appended = threshold_appended && threshold_storage.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = static_cast<std::uint16_t>(index),
                .content_size = 1U,
            });
    }
    const auto before_tail =
        datacube::read_canonical_capability_span_chunk_storage_counters();
    ++results.tail_directory_boundary_cases;
    const bool before_tail_exact =
        threshold_appended &&
        threshold_storage.size() ==
            results.tail_directory_activation_span_count &&
        threshold_storage.spill_chunk_count() ==
            datacube::kNATravPeerCapabilitySpanEarlyOwnerCount &&
        !threshold_storage.tail_owner_directory_materialized() &&
        before_tail.tail_directory_allocations == 0U &&
        before_tail.spill_reservations ==
            datacube::kNATravPeerCapabilitySpanEarlyOwnerCount;
    results.tail_directory_boundary_checks += before_tail_exact ? 1U : 0U;
    check(results, before_tail_exact, "tail_directory_not_materialized_early");

    const bool first_tail_appended = threshold_storage.append(
        datacube::CanonicalCapabilityEntrySpan{
            .content_offset = static_cast<std::uint16_t>(
                results.tail_directory_activation_span_count),
            .content_size = 1U,
        });
    const auto after_tail =
        datacube::read_canonical_capability_span_chunk_storage_counters();
    ++results.tail_directory_boundary_cases;
    const bool after_tail_exact =
        first_tail_appended &&
        threshold_storage.size() ==
            results.tail_directory_activation_span_count + 1U &&
        threshold_storage.spill_chunk_count() ==
            datacube::kNATravPeerCapabilitySpanEarlyOwnerCount + 1U &&
        threshold_storage.tail_owner_directory_materialized() &&
        after_tail.tail_directory_allocations == 1U &&
        after_tail.spill_reservations ==
            datacube::kNATravPeerCapabilitySpanEarlyOwnerCount + 1U;
    results.tail_directory_boundary_checks += after_tail_exact ? 1U : 0U;
    check(results, after_tail_exact, "tail_directory_materialized_at_boundary");

    for (std::size_t injection_point = 0U;
         injection_point < 1U;
         ++injection_point) {
        datacube::CanonicalCapabilityEntrySpanStorage storage;
        bool prepared = true;
        for (std::size_t index = 0U;
             index < results.tail_directory_activation_span_count;
             ++index) {
            prepared = prepared && storage.append(
                datacube::CanonicalCapabilityEntrySpan{
                    .content_offset = static_cast<std::uint16_t>(index),
                    .content_size = 1U,
                });
        }
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_capability_span_fused_tail_allocation_test::arm(
            injection_point);
        try {
            static_cast<void>(storage.append(
                datacube::CanonicalCapabilityEntrySpan{
                    .content_offset = static_cast<std::uint16_t>(
                        results.tail_directory_activation_span_count),
                    .content_size = 1U,
                }));
        } catch (const natrav_capability_span_fused_tail_allocation_test::
                     InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        } catch (...) {
        }
        const Stats failed_stats =
            natrav_capability_span_fused_tail_allocation_test::disarm();
        const bool preserved =
            prepared && caught && caught_point == injection_point &&
            failed_stats.attempts == injection_point + 1U &&
            storage.size() == results.tail_directory_activation_span_count &&
            !storage.tail_owner_directory_materialized() &&
            storage.at(results.tail_directory_activation_span_count - 1U)
                    .content_offset ==
                results.tail_directory_activation_span_count - 1U;
        const bool retry = storage.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = static_cast<std::uint16_t>(
                    results.tail_directory_activation_span_count),
                .content_size = 1U,
            });
        ++results.transactional_failure_cases;
        const bool exact =
            preserved && retry &&
            storage.size() ==
                results.tail_directory_activation_span_count + 1U &&
            storage.tail_owner_directory_materialized() &&
            storage.at(results.tail_directory_activation_span_count)
                    .content_offset ==
                results.tail_directory_activation_span_count;
        results.transactional_failure_checks += exact ? 1U : 0U;
        check(results, exact, "transactional_tail_directory_failure");
    }

    datacube::reset_canonical_capability_span_chunk_storage_counters();
    datacube::CanonicalCapabilityEntrySpanStorage storage;
    bool appended = true;
    for (std::size_t index = 0U;
         index < datacube::kNATravPeerMaximumJsonConstructionUnits;
         ++index) {
        appended = appended && storage.append(
            datacube::CanonicalCapabilityEntrySpan{
                .content_offset = static_cast<std::uint16_t>(index),
                .content_size = 1U,
            });
    }
    const bool rejected_extra = !storage.append(
        datacube::CanonicalCapabilityEntrySpan{
            .content_offset = 0U,
            .content_size = 0U,
        });
    const auto counters =
        datacube::read_canonical_capability_span_chunk_storage_counters();

    ++results.storage_boundary_cases;
    const bool maximum_exact =
        appended && rejected_extra &&
        storage.size() == datacube::kNATravPeerMaximumJsonConstructionUnits &&
        storage.inline_size() ==
            datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        storage.spill_size() ==
            datacube::kNATravPeerMaximumJsonConstructionUnits -
                datacube::kNATravPeerInlineCapabilitySpanCapacity &&
        storage.spill_chunk_count() ==
            datacube::kNATravPeerCapabilitySpanChunkCount &&
        storage.spill_allocated_capacity() == storage.spill_size() &&
        storage.maximum_chunk_capacity() ==
            datacube::kNATravPeerCapabilitySpanTailChunkCapacity &&
        storage.tail_owner_directory_materialized() &&
        counters.spill_activations == 1U &&
        counters.spill_reservations ==
            datacube::kNATravPeerCapabilitySpanChunkCount &&
        counters.tail_directory_allocations == 1U &&
        counters.spill_reserved_capacity == storage.spill_size() &&
        counters.maximum_spill_capacity ==
            datacube::kNATravPeerCapabilitySpanTailChunkCapacity &&
        counters.current_relocated_spans == 0U;
    results.storage_boundary_checks += maximum_exact ? 1U : 0U;
    check(results, maximum_exact, "storage_maximum_boundary");

    ++results.storage_boundary_cases;
    const bool reads_exact =
        storage.at(0U).content_offset == 0U &&
        storage.at(63U).content_offset == 63U &&
        storage.at(64U).content_offset == 64U &&
        storage.at(127U).content_offset == 127U &&
        storage.at(128U).content_offset == 128U &&
        storage.at(255U).content_offset == 255U &&
        storage.at(256U).content_offset == 256U &&
        storage.at(511U).content_offset == 511U &&
        storage.at(512U).content_offset == 512U &&
        storage.at(1023U).content_offset == 1023U &&
        storage.at(1024U).content_offset == 1024U &&
        storage.at(2159U).content_offset == 2159U &&
        storage.at(2160U).content_offset == 2160U &&
        storage.at(datacube::kNATravPeerMaximumJsonConstructionUnits - 1U)
                .content_offset ==
            datacube::kNATravPeerMaximumJsonConstructionUnits - 1U;
    results.storage_boundary_checks += reads_exact ? 1U : 0U;
    check(results, reads_exact, "storage_boundary_reads");
}

struct Baseline final {
    NATravPeerMessageDecodeObservation observation;
    Stats stats;
};

template <typename Decode>
[[nodiscard]] Baseline baseline_decode(
    const Octets& payload,
    Decode&& decode) {
    natrav_capability_span_fused_tail_allocation_test::arm();
    NATravPeerMessageDecodeObservation observation;
    try {
        observation = decode(payload);
    } catch (...) {
        static_cast<void>(
            natrav_capability_span_fused_tail_allocation_test::disarm());
        throw;
    }
    const Stats stats =
        natrav_capability_span_fused_tail_allocation_test::disarm();
    return Baseline{
        .observation = std::move(observation),
        .stats = stats,
    };
}

template <typename Decode>
void inject_allocation_failures(
    Results& results,
    const Octets& payload,
    const Baseline& baseline,
    Decode&& decode,
    const bool current) {
    for (std::size_t point = 0U; point < baseline.stats.attempts; ++point) {
        const Octets before = payload;
        bool caught = false;
        std::size_t caught_point = std::numeric_limits<std::size_t>::max();
        natrav_capability_span_fused_tail_allocation_test::arm(point);
        try {
            static_cast<void>(decode(payload));
        } catch (const natrav_capability_span_fused_tail_allocation_test::
                     InjectedBadAlloc& error) {
            caught = true;
            caught_point = error.point;
        } catch (...) {
        }
        static_cast<void>(
            natrav_capability_span_fused_tail_allocation_test::disarm());
        if (current) {
            ++results.injected_current_failures;
        } else {
            ++results.injected_historical_failures;
        }
        results.exception_type_checks += caught ? 1U : 0U;
        check(results, caught, "allocation_exception_type");
        const bool ordinal = caught_point == point;
        results.exception_ordinal_checks += ordinal ? 1U : 0U;
        check(results, ordinal, "allocation_exception_ordinal");
        const bool preserved = payload == before;
        results.input_preservation_checks += preserved ? 1U : 0U;
        check(results, preserved, "allocation_input_preserved");
        const NATravPeerMessageDecodeObservation retry = decode(payload);
        const bool retry_equal = same_observation(retry, baseline.observation);
        results.retry_checks += retry_equal ? 1U : 0U;
        check(results, retry_equal, "allocation_retry");
    }
}

void allocation_scenario(
    Results& results,
    const Octets& payload,
    const std::size_t expected_attempt_reduction,
    const std::size_t expected_byte_reduction) {
    ++results.allocation_scenarios;
    const Baseline current = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        });
    const Baseline historical = baseline_decode(
        payload,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0487(bytes);
        });
    check(
        results,
        same_observation(current.observation, historical.observation),
        "allocation_baseline_semantics");
    results.current_allocation_attempts += current.stats.attempts;
    results.historical_allocation_attempts += historical.stats.attempts;
    results.current_allocated_bytes += current.stats.total_bytes;
    results.historical_allocated_bytes += historical.stats.total_bytes;
    results.current_maximum_allocation = std::max(
        results.current_maximum_allocation, current.stats.maximum_bytes);
    results.historical_maximum_allocation = std::max(
        results.historical_maximum_allocation,
        historical.stats.maximum_bytes);

    const bool attempts_ordered =
        historical.stats.attempts >= current.stats.attempts;
    check(results, attempts_ordered, "allocation_attempt_order");
    const std::size_t attempt_reduction = attempts_ordered ?
        historical.stats.attempts - current.stats.attempts : 0U;
    const bool bytes_ordered =
        historical.stats.total_bytes >= current.stats.total_bytes;
    check(results, bytes_ordered, "allocation_byte_order");
    const std::size_t byte_reduction = bytes_ordered ?
        historical.stats.total_bytes - current.stats.total_bytes : 0U;
    results.measured_allocation_attempts_removed += attempt_reduction;
    results.measured_allocated_bytes_removed += byte_reduction;
    const bool attempts_exact =
        attempt_reduction == expected_attempt_reduction;
    results.allocation_relation_checks += attempts_exact ? 1U : 0U;
    check(results, attempts_exact, "allocation_attempt_reduction");
    const bool bytes_exact = byte_reduction == expected_byte_reduction;
    results.allocation_relation_checks += bytes_exact ? 1U : 0U;
    check(results, bytes_exact, "allocation_byte_reduction");
    const bool maximum_not_increased =
        current.stats.maximum_bytes <= historical.stats.maximum_bytes;
    results.allocation_relation_checks += maximum_not_increased ? 1U : 0U;
    check(results, maximum_not_increased, "allocation_maximum_relation");

    inject_allocation_failures(
        results,
        payload,
        current,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message(bytes);
        },
        true);
    inject_allocation_failures(
        results,
        payload,
        historical,
        [](const Octets& bytes) {
            return datacube::natrav_peer_decode_message_revision_0487(bytes);
        },
        false);
}

void allocation_cases(Results& results) {
    NATravPeerHandshakeMessage error =
        base_message(NATravPeerHandshakeMessageKind::error);
    allocation_scenario(results, encode_message(results, error), 0U, 0U);

    NATravPeerHandshakeMessage inline_boundary =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(
        inline_boundary,
        datacube::kNATravPeerInlineCapabilitySpanCapacity);
    allocation_scenario(
        results, encode_message(results, inline_boundary), 0U, 0U);

    NATravPeerHandshakeMessage first_spill =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fill_capabilities(
        first_spill,
        datacube::kNATravPeerInlineCapabilitySpanCapacity + 1U);
    allocation_scenario(
        results,
        encode_message(results, first_spill),
        0U,
        0U);

    NATravPeerHandshakeMessage medium_129 =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(medium_129, 129U);
    allocation_scenario(
        results,
        encode_message(results, medium_129),
        0U,
        0U);

    NATravPeerHandshakeMessage medium_512 =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fill_capabilities(medium_512, 512U);
    allocation_scenario(
        results,
        encode_message(results, medium_512),
        0U,
        0U);

    NATravPeerHandshakeMessage medium_1024 =
        base_message(NATravPeerHandshakeMessageKind::hello);
    fill_capabilities(medium_1024, 1024U);
    allocation_scenario(
        results,
        encode_message(results, medium_1024),
        0U,
        0U);

    NATravPeerHandshakeMessage large =
        base_message(NATravPeerHandshakeMessageKind::hello_ack);
    fill_capabilities(large, 7000U);
    allocation_scenario(
        results,
        encode_message(results, large),
        1U,
        sizeof(CapabilitySpanChunkOwner));
}


// A full-capacity direct-storage sweep checks every early/tail allocation,
// including the fused activation and each later tail. Before each allocation
// fails, retain the exact addresses and values of every existing span.
void address_and_allocation_boundaries(Results& results) {
    using Storage = datacube::CanonicalCapabilityEntrySpanStorage;
    using Span = datacube::CanonicalCapabilityEntrySpan;
    results.fused_activation_block_bytes =
        sizeof(datacube::CanonicalCapabilitySpanTailActivationBlock);
    check(results, results.fused_activation_block_bytes == 8176U,
        "exact_fused_block_footprint");
    Storage storage;
    std::array<const Span*, datacube::kNATravPeerMaximumJsonConstructionUnits>
        addresses{};
    std::size_t target = datacube::kNATravPeerInlineCapabilitySpanCapacity;
    for (std::size_t chunk = 0U;
         chunk < datacube::kNATravPeerCapabilitySpanChunkCount; ++chunk) {
        while (storage.size() < target) {
            const std::size_t index = storage.size();
            check(results, storage.append(Span{
                static_cast<std::uint16_t>(index),
                static_cast<std::uint16_t>(index % 251U + 1U)}),
                "prepare_allocation_boundary");
            addresses[index] = storage.address_for_test(index);
        }
        const bool materialized_before = storage.tail_owner_directory_materialized();
        const auto count_before = storage.spill_chunk_count();
        const auto capacity_before = storage.spill_allocated_capacity();
        natrav_capability_span_fused_tail_allocation_test::arm(0U);
        bool caught = false;
        try {
            static_cast<void>(storage.append(Span{
                static_cast<std::uint16_t>(target),
                static_cast<std::uint16_t>(target % 251U + 1U)}));
        } catch (const natrav_capability_span_fused_tail_allocation_test::
                     InjectedBadAlloc& error) {
            caught = error.point == 0U;
        } catch (...) {}
        const Stats failed = natrav_capability_span_fused_tail_allocation_test::disarm();
        bool preserved = caught && failed.attempts == 1U &&
            storage.size() == target &&
            storage.spill_chunk_count() == count_before &&
            storage.spill_allocated_capacity() == capacity_before &&
            storage.tail_owner_directory_materialized() == materialized_before;
        for (std::size_t index = 0U; index < target; ++index) {
            ++results.retained_address_checks;
            const bool exact = storage.address_for_test(index) == addresses[index] &&
                storage.at(index).content_offset == index &&
                storage.at(index).content_size == index % 251U + 1U;
            results.retained_address_verified += exact ? 1U : 0U;
            preserved = preserved && exact;
        }
        natrav_capability_span_fused_tail_allocation_test::arm();
        const bool appended = storage.append(Span{
            static_cast<std::uint16_t>(target),
            static_cast<std::uint16_t>(target % 251U + 1U)});
        const Stats retry = natrav_capability_span_fused_tail_allocation_test::disarm();
        const std::size_t expected_bytes =
            chunk == datacube::kNATravPeerCapabilitySpanEarlyOwnerCount ?
                sizeof(datacube::CanonicalCapabilitySpanTailActivationBlock) :
                datacube::kNATravPeerCapabilitySpanChunkCapacities[chunk] * sizeof(Span);
        bool exact = preserved && appended && retry.attempts == 1U &&
            retry.total_bytes == expected_bytes && storage.size() == target + 1U &&
            storage.spill_chunk_count() == chunk + 1U;
        for (std::size_t index = 0U; index < target; ++index) {
            ++results.retained_address_checks;
            const bool stable = storage.address_for_test(index) == addresses[index] &&
                storage.at(index).content_offset == index &&
                storage.at(index).content_size == index % 251U + 1U;
            results.retained_address_verified += stable ? 1U : 0U;
            exact = exact && stable;
        }
        addresses[target] = storage.address_for_test(target);
        ++results.allocation_boundary_cases;
        results.allocation_boundary_checks += exact ? 1U : 0U;
        check(results, exact, "allocation_boundary_transaction_and_addresses");
        target += datacube::kNATravPeerCapabilitySpanChunkCapacities[chunk];
    }
    while (storage.size() < target) {
        const std::size_t index = storage.size();
        check(results, storage.append(Span{static_cast<std::uint16_t>(index),
            static_cast<std::uint16_t>(index % 251U + 1U)}), "fill_final_chunk");
        addresses[index] = storage.address_for_test(index);
    }
    natrav_capability_span_fused_tail_allocation_test::arm(0U);
    const bool rejected = !storage.append(Span{0U, 0U});
    const Stats overflow = natrav_capability_span_fused_tail_allocation_test::disarm();
    check(results, rejected && overflow.attempts == 0U && storage.size() == 16384U,
        "capacity_rejection_without_allocation");
    for (std::size_t index = 0U; index < target; ++index) {
        ++results.retained_address_checks;
        const bool exact = storage.address_for_test(index) == addresses[index] &&
            storage.at(index).content_offset == index &&
            storage.at(index).content_size == index % 251U + 1U;
        results.retained_address_verified += exact ? 1U : 0U;
        check(results, exact, "full_capacity_address_and_value");
    }
}

int run() {
    Results results;
    accepted_corpus(results);
    priority_cases(results);
    random_corpus(results);
    direct_storage_boundaries(results);
    allocation_cases(results);
    address_and_allocation_boundaries(results);

    const std::size_t injected_total =
        results.injected_current_failures +
        results.injected_historical_failures;
    check(
        results,
        results.exact_observation_comparisons == results.semantic_cases &&
            results.exact_roundtrips == results.accepted_cases &&
            results.exact_classifications ==
                results.classification_priority_cases &&
            results.common_case_zero_spill_cases ==
                results.common_case_zero_spill_checks &&
            results.spill_path_cases == results.spill_path_checks &&
            results.storage_boundary_cases ==
                results.storage_boundary_checks &&
            results.current_storage_instances == results.semantic_cases &&
            results.historical_storage_instances == results.semantic_cases &&
            results.current_inline_appends + results.current_spill_appends ==
                results.historical_appends &&
            results.current_inline_reads + results.current_spill_reads ==
                results.historical_reads &&
            results.current_spill_activations > 0U &&
            results.current_spill_reservations ==
                results.historical_spill_reservations &&
            results.current_spill_reserved_capacity ==
                results.historical_spill_reserved_capacity &&
            results.current_maximum_spill_capacity ==
                results.historical_maximum_spill_capacity &&
            results.current_tail_directory_allocations == 1U &&
            results.current_relocated_spans == 0U &&
            results.historical_relocated_spans == 0U &&
            results.tail_directory_boundary_cases ==
                results.tail_directory_boundary_checks &&
            results.transactional_failure_cases ==
                results.transactional_failure_checks &&
            results.transactional_failure_cases == 1U &&
            results.production_storage_bytes_reduced == 48U &&
            results.preflight_observation_bytes_reduced == 48U &&
            results.allocation_relation_checks ==
                results.allocation_scenarios * 3U &&
            results.measured_allocation_attempts_removed == 1U &&
            results.measured_allocated_bytes_removed ==
                sizeof(CapabilitySpanChunkOwner) &&
            results.exception_type_checks == injected_total &&
            results.exception_ordinal_checks == injected_total &&
            results.input_preservation_checks == injected_total &&
            results.retry_checks == injected_total &&
            results.allocation_boundary_cases == 12U &&
            results.allocation_boundary_checks == results.allocation_boundary_cases &&
            results.retained_address_checks == results.retained_address_verified,
        "coverage_and_span_storage_integration");

#define PRINT_RESULT(name) std::printf(#name "=%zu\n", results.name)
    PRINT_RESULT(semantic_cases);
    PRINT_RESULT(accepted_cases);
    PRINT_RESULT(rejection_cases);
    PRINT_RESULT(random_cases);
    PRINT_RESULT(exact_observation_comparisons);
    PRINT_RESULT(exact_roundtrips);
    PRINT_RESULT(classification_priority_cases);
    PRINT_RESULT(exact_classifications);
    PRINT_RESULT(current_storage_instances);
    PRINT_RESULT(current_inline_appends);
    PRINT_RESULT(current_spill_appends);
    PRINT_RESULT(current_spill_activations);
    PRINT_RESULT(current_spill_reservations);
    PRINT_RESULT(current_spill_reserved_capacity);
    PRINT_RESULT(current_maximum_spill_capacity);
    PRINT_RESULT(current_inline_reads);
    PRINT_RESULT(current_spill_reads);
    PRINT_RESULT(current_tail_directory_allocations);
    PRINT_RESULT(current_relocated_spans);
    PRINT_RESULT(historical_storage_instances);
    PRINT_RESULT(historical_appends);
    PRINT_RESULT(historical_reads);
    PRINT_RESULT(historical_spill_reservations);
    PRINT_RESULT(historical_spill_reserved_capacity);
    PRINT_RESULT(historical_maximum_spill_capacity);
    PRINT_RESULT(historical_relocated_spans);
    PRINT_RESULT(common_case_zero_spill_cases);
    PRINT_RESULT(common_case_zero_spill_checks);
    PRINT_RESULT(spill_path_cases);
    PRINT_RESULT(spill_path_checks);
    PRINT_RESULT(storage_boundary_cases);
    PRINT_RESULT(storage_boundary_checks);
    PRINT_RESULT(tail_directory_boundary_cases);
    PRINT_RESULT(tail_directory_boundary_checks);
    PRINT_RESULT(transactional_failure_cases);
    PRINT_RESULT(transactional_failure_checks);
    PRINT_RESULT(inline_capacity);
    PRINT_RESULT(first_spill_chunk_capacity);
    PRINT_RESULT(tier_one_chunk_capacity);
    PRINT_RESULT(tier_two_chunk_capacity);
    PRINT_RESULT(tier_three_chunk_capacity);
    PRINT_RESULT(tier_four_chunk_capacity);
    PRINT_RESULT(tier_chunk_count);
    PRINT_RESULT(uniform_tail_chunk_capacity);
    PRINT_RESULT(uniform_tail_chunk_count);
    PRINT_RESULT(maximum_chunk_count);
    PRINT_RESULT(early_owner_count);
    PRINT_RESULT(lazy_tail_owner_count);
    PRINT_RESULT(tail_directory_activation_span_count);
    PRINT_RESULT(production_storage_bytes);
    PRINT_RESULT(revision_0486_production_storage_bytes);
    PRINT_RESULT(production_storage_bytes_reduced);
    PRINT_RESULT(production_preflight_observation_bytes);
    PRINT_RESULT(revision_0486_preflight_observation_bytes);
    PRINT_RESULT(preflight_observation_bytes_reduced);
    PRINT_RESULT(instrumented_storage_bytes);
    PRINT_RESULT(instrumented_preflight_observation_bytes);
    PRINT_RESULT(allocation_scenarios);
    PRINT_RESULT(current_allocation_attempts);
    PRINT_RESULT(historical_allocation_attempts);
    PRINT_RESULT(current_allocated_bytes);
    PRINT_RESULT(historical_allocated_bytes);
    PRINT_RESULT(current_maximum_allocation);
    PRINT_RESULT(historical_maximum_allocation);
    PRINT_RESULT(measured_allocation_attempts_removed);
    PRINT_RESULT(measured_allocated_bytes_removed);
    PRINT_RESULT(allocation_relation_checks);
    PRINT_RESULT(injected_current_failures);
    PRINT_RESULT(injected_historical_failures);
    PRINT_RESULT(exception_type_checks);
    PRINT_RESULT(exception_ordinal_checks);
    PRINT_RESULT(input_preservation_checks);
    PRINT_RESULT(retry_checks);
    PRINT_RESULT(allocation_boundary_cases);
    PRINT_RESULT(allocation_boundary_checks);
    PRINT_RESULT(retained_address_checks);
    PRINT_RESULT(retained_address_verified);
    PRINT_RESULT(fused_activation_block_bytes);
    PRINT_RESULT(failures);
#undef PRINT_RESULT
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_capability_span_fused_tail_test

int main() {
    try {
        return natrav_capability_span_fused_tail_test::run();
    } catch (const std::exception& error) {
        static_cast<void>(
            natrav_capability_span_fused_tail_allocation_test::disarm());
        std::fprintf(stderr, "UNEXPECTED %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_MESSAGE_CAPABILITY_SPAN_FUSED_TAIL_TEST
