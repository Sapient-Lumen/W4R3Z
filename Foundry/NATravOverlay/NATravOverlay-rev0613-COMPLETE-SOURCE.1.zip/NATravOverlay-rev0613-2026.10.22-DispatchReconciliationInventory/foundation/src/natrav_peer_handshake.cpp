#include "datacube/natrav_peer_handshake.hpp"

#include <algorithm>
#include <cstddef>
#include <string>
#include <string_view>
#include <utility>
#include <type_traits>

namespace datacube {
namespace {

// Enforce the sorted-input contract before std::includes; strict increase
// also excludes duplicate declarations. Empty sequences are valid sets. This
// allocation-free check deliberately does not claim wire token validation.
[[nodiscard]] bool capabilities_strictly_increasing(
    const std::vector<std::string>& values) noexcept {
    for (std::size_t index = 1U; index < values.size(); ++index) {
        if (!(values[index - 1U] < values[index])) { return false; }
    }
    return true;
}

[[nodiscard]] bool required_capabilities_available(
    const std::vector<std::string>& required,
    const std::vector<std::string>& available) noexcept {
    return std::includes(
        available.begin(), available.end(), required.begin(), required.end());
}

}  // namespace

NATravPeerHandshakeSession::NATravPeerHandshakeSession(
    NATravPeerHandshakeExpectation expectation)
    : expectation_(std::move(expectation)) {}

NATravPeerHandshakeSession::NATravPeerHandshakeSession(
    NATravPeerHandshakeSession&& other) noexcept
    : expectation_(std::move(other.expectation_)),
      status_(other.status_),
      classification_(std::move(other.classification_)),
      responses_observed_(other.responses_observed_),
      terminal_(other.terminal_) {
    static_assert(std::is_nothrow_move_constructible_v<NATravPeerHandshakeExpectation>);
    static_assert(std::is_nothrow_move_constructible_v<std::string>);
    // Retire the donor without constructing a classification or allocating.
    // Clear correlated identity metadata as well as all public accounting.
    other.expectation_.protocol.id.clear();
    other.expectation_.protocol.major = 0;
    other.expectation_.protocol.minor = 0;
    other.expectation_.request_id.clear();
    other.expectation_.expected_artifact.sha256.clear();
    other.expectation_.expected_artifact.target.clear();
    other.expectation_.expected_artifact.version.clear();
    other.expectation_.required_capabilities.clear();
    other.status_ = NATravPeerHandshakeStatus::moved_from;
    other.classification_.clear();
    other.responses_observed_ = 0U;
    other.terminal_ = true;
}

NATravPeerHandshakeSession& NATravPeerHandshakeSession::operator=(
    NATravPeerHandshakeSession&& other) noexcept {
    if (this != &other) {
        NATravPeerHandshakeSession replacement(std::move(other));
        swap(replacement);
    }
    return *this;
}

NATravPeerHandshakeSession& NATravPeerHandshakeSession::operator=(
    const NATravPeerHandshakeSession& other) {
    if (this != &other) {
        // Commit only after every identity, capability and classification has
        // been copied. Partial assignment of this aggregate is not safe.
        NATravPeerHandshakeSession replacement(other);
        swap(replacement);
    }
    return *this;
}

void NATravPeerHandshakeSession::swap(NATravPeerHandshakeSession& other) noexcept {
    if (this == &other) { return; }
    static_assert(std::is_nothrow_swappable_v<NATravPeerHandshakeExpectation>);
    using std::swap;
    swap(expectation_, other.expectation_);
    swap(status_, other.status_);
    classification_.swap(other.classification_);
    swap(responses_observed_, other.responses_observed_);
    swap(terminal_, other.terminal_);
}

bool NATravPeerHandshakeSession::moved_from() const noexcept {
    return status_ == NATravPeerHandshakeStatus::moved_from;
}

NATravPeerHandshakeObservation NATravPeerHandshakeSession::terminate(
    const NATravPeerHandshakeStatus status,
    std::string classification) {
    status_ = status;
    classification_ = std::move(classification);
    terminal_ = true;
    return observation();
}

NATravPeerHandshakeObservation NATravPeerHandshakeSession::observe_response(
    const NATravPeerHandshakeMessage& response) {
    if (operation_failed() || moved_from()) { return observation(); }
    try {
        if (terminal_) {
            ++responses_observed_;
            return terminate(
                NATravPeerHandshakeStatus::replay_rejected,
                "REPLAY_REJECTED");
        }
        ++responses_observed_;

        if (response.request_id != expectation_.request_id) {
            return terminate(
                NATravPeerHandshakeStatus::correlation_rejected,
                "CORRELATION_REJECTED");
        }
        if (response.protocol.id != expectation_.protocol.id ||
            response.protocol.major != expectation_.protocol.major ||
            response.protocol.minor < expectation_.protocol.minor) {
            return terminate(
                NATravPeerHandshakeStatus::protocol_mismatch,
                "PROTOCOL_MISMATCH");
        }
        if (response.kind == NATravPeerHandshakeMessageKind::error) {
            return terminate(
                NATravPeerHandshakeStatus::peer_error,
                response.error_code);
        }
        if (response.kind != NATravPeerHandshakeMessageKind::hello_ack) {
            return terminate(
                NATravPeerHandshakeStatus::message_kind_rejected,
                "MESSAGE_KIND_REJECTED");
        }
        if (response.artifact.sha256 != expectation_.expected_artifact.sha256 ||
            response.artifact.target != expectation_.expected_artifact.target ||
            response.artifact.version != expectation_.expected_artifact.version) {
            return terminate(
                NATravPeerHandshakeStatus::artifact_identity_mismatch,
                "ARTIFACT_IDENTITY_MISMATCH");
        }
        if (!capabilities_strictly_increasing(expectation_.required_capabilities) ||
            !capabilities_strictly_increasing(response.available_capabilities)) {
            return terminate(
                NATravPeerHandshakeStatus::capability_declaration_rejected,
                "CAPABILITY_DECLARATION_REJECTED");
        }
        if (!required_capabilities_available(
                expectation_.required_capabilities,
                response.available_capabilities)) {
            return terminate(
                NATravPeerHandshakeStatus::capability_mismatch,
                "CAPABILITY_MISMATCH");
        }
        return terminate(NATravPeerHandshakeStatus::accepted, "ACCEPTED");
    } catch (...) {
        // Scalar writes only: a persistent allocation failure must not prevent
        // the latch or replace the original exception. Retain partial counts.
        status_ = NATravPeerHandshakeStatus::operation_failed;
        terminal_ = true;
        throw;
    }
}

NATravPeerHandshakeObservation
NATravPeerHandshakeSession::observe_unavailability(
    const NATravPeerHandshakeEvent event) {
    static_cast<void>(event);
    if (terminal_) {
        return observation();
    }
    try {
        return terminate(
            NATravPeerHandshakeStatus::peer_unavailable,
            "PEER_UNAVAILABLE");
    } catch (...) {
        // Already-terminal calls above are snapshots, not active operations.
        status_ = NATravPeerHandshakeStatus::operation_failed;
        terminal_ = true;
        throw;
    }
}

NATravPeerHandshakeObservation NATravPeerHandshakeSession::observation() const {
    return NATravPeerHandshakeObservation{
        .status = status_,
        .classification = (operation_failed() || moved_from())
            ? std::string(natrav_peer_handshake_status_name(status_))
            : classification_,
        .responses_observed = responses_observed_,
        .terminal = terminal_,
    };
}

bool NATravPeerHandshakeSession::operation_failed() const noexcept {
    return status_ == NATravPeerHandshakeStatus::operation_failed;
}

std::string_view natrav_peer_handshake_status_name(
    const NATravPeerHandshakeStatus status) noexcept {
    switch (status) {
        case NATravPeerHandshakeStatus::awaiting_response:
            return "AWAITING_RESPONSE";
        case NATravPeerHandshakeStatus::accepted: return "ACCEPTED";
        case NATravPeerHandshakeStatus::peer_error: return "PEER_ERROR";
        case NATravPeerHandshakeStatus::protocol_mismatch:
            return "PROTOCOL_MISMATCH";
        case NATravPeerHandshakeStatus::correlation_rejected:
            return "CORRELATION_REJECTED";
        case NATravPeerHandshakeStatus::artifact_identity_mismatch:
            return "ARTIFACT_IDENTITY_MISMATCH";
        case NATravPeerHandshakeStatus::capability_mismatch:
            return "CAPABILITY_MISMATCH";
        case NATravPeerHandshakeStatus::message_kind_rejected:
            return "MESSAGE_KIND_REJECTED";
        case NATravPeerHandshakeStatus::peer_unavailable:
            return "PEER_UNAVAILABLE";
        case NATravPeerHandshakeStatus::replay_rejected:
            return "REPLAY_REJECTED";
        case NATravPeerHandshakeStatus::operation_failed:
            return "OPERATION_FAILED";
        case NATravPeerHandshakeStatus::moved_from:
            return "MOVED_FROM";
        case NATravPeerHandshakeStatus::capability_declaration_rejected:
            return "CAPABILITY_DECLARATION_REJECTED";
    }
    return "UNKNOWN";
}

std::string_view natrav_peer_handshake_event_name(
    const NATravPeerHandshakeEvent event) noexcept {
    switch (event) {
        case NATravPeerHandshakeEvent::timeout: return "TIMEOUT";
        case NATravPeerHandshakeEvent::early_eof: return "EARLY_EOF";
        case NATravPeerHandshakeEvent::spawn_failure: return "SPAWN_FAILURE";
    }
    return "UNKNOWN";
}

}  // namespace datacube
