#include "datacube/natrav_peer_session.hpp"

#include "datacube/natrav_peer_message.hpp"

#include <algorithm>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

namespace datacube {
namespace {

[[nodiscard]] NATravPeerClientPreparationObservation preparation_observation(
    const NATravPeerClientPreparationStatus status) {
    return NATravPeerClientPreparationObservation{
        .status = status,
        .classification =
            std::string(natrav_peer_client_preparation_status_name(status)),
        .prepared = std::nullopt,
    };
}

constexpr std::string_view kPreparedClientHandshakeBindingDomain =
    "NATRAV-PEER-PREPARED-CLIENT-HANDSHAKE-BINDING-1";
constexpr std::string_view kClientExchangeBindingDomain =
    "NATRAV-PEER-CLIENT-EXCHANGE-BINDING-1";
constexpr std::string_view kClientTransportBindingDomain =
    "NATRAV-PEER-CLIENT-TRANSPORT-BINDING-1";
constexpr std::string_view kClientProcessBindingDomain =
    "NATRAV-PEER-CLIENT-PROCESS-BINDING-1";

[[nodiscard]] bool protocol_equal(
    const NATravPeerProtocolVersion& left,
    const NATravPeerProtocolVersion& right) noexcept {
    return left.id == right.id && left.major == right.major &&
        left.minor == right.minor;
}

[[nodiscard]] bool artifact_equal(
    const NATravPeerArtifactIdentity& left,
    const NATravPeerArtifactIdentity& right) noexcept {
    return left.sha256 == right.sha256 && left.target == right.target &&
        left.version == right.version;
}

[[nodiscard]] bool message_equal(
    const NATravPeerHandshakeMessage& left,
    const NATravPeerHandshakeMessage& right) noexcept {
    return left.kind == right.kind &&
        protocol_equal(left.protocol, right.protocol) &&
        left.request_id == right.request_id &&
        artifact_equal(left.artifact, right.artifact) &&
        left.required_capabilities == right.required_capabilities &&
        left.available_capabilities == right.available_capabilities &&
        left.error_code == right.error_code &&
        left.error_message == right.error_message;
}

[[nodiscard]] NATravPeerHandshakeMessage minimum_expected_response(
    const NATravPeerHandshakeExpectation& expectation) {
    return NATravPeerHandshakeMessage{
        .kind = NATravPeerHandshakeMessageKind::hello_ack,
        .protocol = expectation.protocol,
        .request_id = expectation.request_id,
        .artifact = expectation.expected_artifact,
        .required_capabilities = {},
        .available_capabilities = expectation.required_capabilities,
        .error_code = {},
        .error_message = {},
    };
}

[[nodiscard]] Digest32 prepared_client_handshake_binding(
    const OctetView payload,
    const OctetView frame,
    const OctetView minimum_response_payload) {
    Octets record;
    append_text(record, kPreparedClientHandshakeBindingDomain);
    append_blob64(record, payload);
    append_blob64(record, frame);
    append_blob64(record, minimum_response_payload);
    return sha256(record);
}

[[nodiscard]] bool prepared_client_handshake_exact(
    const NATravPeerPreparedClientHandshake& prepared) {
    if (prepared.hello.kind != NATravPeerHandshakeMessageKind::hello ||
        !protocol_equal(prepared.expectation.protocol, prepared.hello.protocol) ||
        prepared.expectation.request_id != prepared.hello.request_id ||
        prepared.expectation.required_capabilities !=
            prepared.hello.required_capabilities) {
        return false;
    }

    const NATravPeerMessageEncodeObservation encoded =
        natrav_peer_encode_message(prepared.hello);
    if (encoded.status != NATravPeerMessageEncodeStatus::accepted ||
        !encoded.payload.has_value() || *encoded.payload != prepared.payload) {
        return false;
    }
    const NATravPeerMessageDecodeObservation decoded =
        natrav_peer_decode_message(prepared.payload);
    if (decoded.status != NATravPeerMessageDecodeStatus::accepted ||
        !decoded.message.has_value() ||
        !message_equal(*decoded.message, prepared.hello)) {
        return false;
    }
    if (natrav_peer_encode_frame(prepared.payload) != prepared.frame) {
        return false;
    }

    const NATravPeerMessageEncodeObservation expected_response =
        natrav_peer_encode_message(
            minimum_expected_response(prepared.expectation));
    if (expected_response.status != NATravPeerMessageEncodeStatus::accepted ||
        !expected_response.payload.has_value()) {
        return false;
    }
    return prepared_client_handshake_binding(
               prepared.payload, prepared.frame, *expected_response.payload) ==
        prepared.binding_sha256;
}

[[nodiscard]] NATravPeerClientPreparationStatus outbound_failure_status(
    const NATravPeerMessageEncodeStatus status) noexcept {
    switch (status) {
        case NATravPeerMessageEncodeStatus::protocol_mismatch:
            return NATravPeerClientPreparationStatus::protocol_mismatch;
        case NATravPeerMessageEncodeStatus::request_id_rejected:
            return NATravPeerClientPreparationStatus::request_id_rejected;
        case NATravPeerMessageEncodeStatus::artifact_identity_rejected:
            return NATravPeerClientPreparationStatus::
                local_artifact_identity_rejected;
        case NATravPeerMessageEncodeStatus::capability_declaration_rejected:
            return NATravPeerClientPreparationStatus::
                capability_declaration_rejected;
        case NATravPeerMessageEncodeStatus::payload_size_rejected:
            return NATravPeerClientPreparationStatus::
                outbound_payload_size_rejected;
        case NATravPeerMessageEncodeStatus::accepted:
        case NATravPeerMessageEncodeStatus::schema_rejected:
        case NATravPeerMessageEncodeStatus::message_kind_rejected:
            return NATravPeerClientPreparationStatus::codec_invariant_rejected;
    }
    return NATravPeerClientPreparationStatus::codec_invariant_rejected;
}

[[nodiscard]] NATravPeerSessionStatus session_status(
    const NATravPeerHandshakeStatus status) noexcept {
    switch (status) {
        case NATravPeerHandshakeStatus::awaiting_response:
            return NATravPeerSessionStatus::awaiting_response;
        case NATravPeerHandshakeStatus::accepted:
            return NATravPeerSessionStatus::accepted;
        case NATravPeerHandshakeStatus::peer_error:
            return NATravPeerSessionStatus::peer_error;
        case NATravPeerHandshakeStatus::protocol_mismatch:
            return NATravPeerSessionStatus::protocol_mismatch;
        case NATravPeerHandshakeStatus::correlation_rejected:
            return NATravPeerSessionStatus::correlation_rejected;
        case NATravPeerHandshakeStatus::artifact_identity_mismatch:
            return NATravPeerSessionStatus::artifact_identity_mismatch;
        case NATravPeerHandshakeStatus::capability_mismatch:
            return NATravPeerSessionStatus::capability_mismatch;
        case NATravPeerHandshakeStatus::capability_declaration_rejected:
            return NATravPeerSessionStatus::capability_declaration_rejected;
        case NATravPeerHandshakeStatus::message_kind_rejected:
            return NATravPeerSessionStatus::message_kind_rejected;
        case NATravPeerHandshakeStatus::peer_unavailable:
            return NATravPeerSessionStatus::peer_unavailable;
        case NATravPeerHandshakeStatus::replay_rejected:
            return NATravPeerSessionStatus::replay_rejected;
        case NATravPeerHandshakeStatus::moved_from:
        case NATravPeerHandshakeStatus::operation_failed:
            return NATravPeerSessionStatus::operation_failed;
    }
    return NATravPeerSessionStatus::peer_unavailable;
}

[[nodiscard]] NATravPeerSessionStatus session_status(
    const NATravPeerMessageDecodeStatus status) noexcept {
    switch (status) {
        case NATravPeerMessageDecodeStatus::payload_size_rejected:
            // The frame decoder normally rejects this envelope first.
            return NATravPeerSessionStatus::malformed_frame;
        case NATravPeerMessageDecodeStatus::accepted:
            return NATravPeerSessionStatus::awaiting_response;
        case NATravPeerMessageDecodeStatus::malformed_json:
            return NATravPeerSessionStatus::malformed_json;
        case NATravPeerMessageDecodeStatus::noncanonical_json:
            return NATravPeerSessionStatus::noncanonical_json;
        case NATravPeerMessageDecodeStatus::schema_rejected:
            return NATravPeerSessionStatus::schema_rejected;
        case NATravPeerMessageDecodeStatus::message_kind_rejected:
            return NATravPeerSessionStatus::message_kind_rejected;
        case NATravPeerMessageDecodeStatus::protocol_mismatch:
            return NATravPeerSessionStatus::protocol_mismatch;
        case NATravPeerMessageDecodeStatus::request_id_rejected:
            return NATravPeerSessionStatus::request_id_rejected;
        case NATravPeerMessageDecodeStatus::artifact_identity_rejected:
            return NATravPeerSessionStatus::artifact_identity_rejected;
        case NATravPeerMessageDecodeStatus::capability_declaration_rejected:
            return NATravPeerSessionStatus::capability_declaration_rejected;
    }
    return NATravPeerSessionStatus::schema_rejected;
}

[[nodiscard]] NATravPeerTransportReportKind unavailability_report_kind(
    const NATravPeerHandshakeEvent event) noexcept {
    switch (event) {
        case NATravPeerHandshakeEvent::early_eof:
            return NATravPeerTransportReportKind::early_eof;
        case NATravPeerHandshakeEvent::timeout:
            return NATravPeerTransportReportKind::timeout;
        case NATravPeerHandshakeEvent::spawn_failure:
            return NATravPeerTransportReportKind::spawn_failure;
    }
    return NATravPeerTransportReportKind::early_eof;
}

[[nodiscard]] NATravPeerClientExchangeStatus client_exchange_status(
    const NATravPeerSessionStatus status) noexcept {
    switch (status) {
        case NATravPeerSessionStatus::awaiting_response:
            return NATravPeerClientExchangeStatus::awaiting_response;
        case NATravPeerSessionStatus::accepted:
            return NATravPeerClientExchangeStatus::accepted;
        case NATravPeerSessionStatus::peer_error:
            return NATravPeerClientExchangeStatus::peer_error;
        case NATravPeerSessionStatus::protocol_mismatch:
            return NATravPeerClientExchangeStatus::protocol_mismatch;
        case NATravPeerSessionStatus::correlation_rejected:
            return NATravPeerClientExchangeStatus::correlation_rejected;
        case NATravPeerSessionStatus::artifact_identity_mismatch:
            return NATravPeerClientExchangeStatus::artifact_identity_mismatch;
        case NATravPeerSessionStatus::capability_mismatch:
            return NATravPeerClientExchangeStatus::capability_mismatch;
        case NATravPeerSessionStatus::message_kind_rejected:
            return NATravPeerClientExchangeStatus::message_kind_rejected;
        case NATravPeerSessionStatus::peer_unavailable:
            return NATravPeerClientExchangeStatus::peer_unavailable;
        case NATravPeerSessionStatus::replay_rejected:
            return NATravPeerClientExchangeStatus::replay_rejected;
        case NATravPeerSessionStatus::malformed_frame:
            return NATravPeerClientExchangeStatus::malformed_frame;
        case NATravPeerSessionStatus::malformed_json:
            return NATravPeerClientExchangeStatus::malformed_json;
        case NATravPeerSessionStatus::noncanonical_json:
            return NATravPeerClientExchangeStatus::noncanonical_json;
        case NATravPeerSessionStatus::schema_rejected:
            return NATravPeerClientExchangeStatus::schema_rejected;
        case NATravPeerSessionStatus::request_id_rejected:
            return NATravPeerClientExchangeStatus::request_id_rejected;
        case NATravPeerSessionStatus::artifact_identity_rejected:
            return NATravPeerClientExchangeStatus::artifact_identity_rejected;
        case NATravPeerSessionStatus::capability_declaration_rejected:
            return NATravPeerClientExchangeStatus::
                capability_declaration_rejected;
        case NATravPeerSessionStatus::moved_from:
            // Public exchange moves transfer its owning pointer, not this
            // embedded session. Treat any internal inert session as failed,
            // never as an unavailable peer or a successful exchange.
        case NATravPeerSessionStatus::operation_failed:
            return NATravPeerClientExchangeStatus::operation_failed;
    }
    return NATravPeerClientExchangeStatus::peer_unavailable;
}

}  // namespace

Digest32 natrav_peer_client_exchange_binding(
    const Digest32& exchange_instance_id,
    const Digest32& prepared_plan_binding_sha256) {
    Octets record;
    append_text(record, kClientExchangeBindingDomain);
    append_blob32(record, exchange_instance_id.octets);
    append_blob32(record, prepared_plan_binding_sha256.octets);
    return sha256(record);
}

Digest32 natrav_peer_client_transport_binding(
    const Digest32& transport_instance_id,
    const Digest32& exchange_binding_sha256) {
    Octets record;
    append_text(record, kClientTransportBindingDomain);
    append_blob32(record, transport_instance_id.octets);
    append_blob32(record, exchange_binding_sha256.octets);
    return sha256(record);
}

Digest32 natrav_peer_client_process_binding(
    const Digest32& process_instance_id,
    const Digest32& transport_binding_sha256) {
    Octets record;
    append_text(record, kClientProcessBindingDomain);
    append_blob32(record, process_instance_id.octets);
    append_blob32(record, transport_binding_sha256.octets);
    return sha256(record);
}

NATravPeerClientPreparationObservation natrav_peer_prepare_client_handshake(
    const NATravPeerClientHandshakeInput& input) {
    const NATravPeerHandshakeMessage hello{
        .kind = NATravPeerHandshakeMessageKind::hello,
        .protocol = input.protocol,
        .request_id = input.request_id,
        .artifact = input.local_artifact,
        .required_capabilities = input.required_capabilities,
        .available_capabilities = {},
        .error_code = {},
        .error_message = {},
    };
    const NATravPeerMessageEncodeObservation encoded =
        natrav_peer_encode_message(hello);
    if (encoded.status != NATravPeerMessageEncodeStatus::accepted ||
        !encoded.payload.has_value()) {
        return preparation_observation(outbound_failure_status(encoded.status));
    }

    const NATravPeerMessageDecodeObservation decoded =
        natrav_peer_decode_message(*encoded.payload);
    if (decoded.status != NATravPeerMessageDecodeStatus::accepted ||
        !decoded.message.has_value() ||
        decoded.message->kind != NATravPeerHandshakeMessageKind::hello) {
        return preparation_observation(
            NATravPeerClientPreparationStatus::codec_invariant_rejected);
    }

    const NATravPeerHandshakeExpectation expectation{
        .protocol = decoded.message->protocol,
        .request_id = decoded.message->request_id,
        .expected_artifact = input.expected_peer_artifact,
        .required_capabilities = decoded.message->required_capabilities,
    };
    const NATravPeerMessageEncodeObservation expected_response =
        natrav_peer_encode_message(minimum_expected_response(expectation));
    if (expected_response.status ==
        NATravPeerMessageEncodeStatus::artifact_identity_rejected) {
        return preparation_observation(
            NATravPeerClientPreparationStatus::
                expected_artifact_identity_rejected);
    }
    if (expected_response.status ==
        NATravPeerMessageEncodeStatus::payload_size_rejected) {
        return preparation_observation(
            NATravPeerClientPreparationStatus::
                expected_response_payload_size_rejected);
    }
    if (expected_response.status != NATravPeerMessageEncodeStatus::accepted ||
        !expected_response.payload.has_value()) {
        return preparation_observation(
            NATravPeerClientPreparationStatus::codec_invariant_rejected);
    }

    Octets frame = natrav_peer_encode_frame(*encoded.payload);
    if (frame.size() !=
        encoded.payload->size() + kNATravPeerFrameHeaderBytes) {
        return preparation_observation(
            NATravPeerClientPreparationStatus::codec_invariant_rejected);
    }

    const Digest32 binding_sha256 = prepared_client_handshake_binding(
        *encoded.payload, frame, *expected_response.payload);
    return NATravPeerClientPreparationObservation{
        .status = NATravPeerClientPreparationStatus::prepared,
        .classification = "PREPARED",
        .prepared = NATravPeerPreparedClientHandshake{
            .hello = *decoded.message,
            .expectation = expectation,
            .payload = *encoded.payload,
            .frame = std::move(frame),
            .binding_sha256 = binding_sha256,
        },
    };
}

std::string_view natrav_peer_client_preparation_status_name(
    const NATravPeerClientPreparationStatus status) noexcept {
    switch (status) {
        case NATravPeerClientPreparationStatus::prepared: return "PREPARED";
        case NATravPeerClientPreparationStatus::protocol_mismatch:
            return "PROTOCOL_MISMATCH";
        case NATravPeerClientPreparationStatus::request_id_rejected:
            return "REQUEST_ID_REJECTED";
        case NATravPeerClientPreparationStatus::
                local_artifact_identity_rejected:
            return "LOCAL_ARTIFACT_IDENTITY_REJECTED";
        case NATravPeerClientPreparationStatus::
                expected_artifact_identity_rejected:
            return "EXPECTED_ARTIFACT_IDENTITY_REJECTED";
        case NATravPeerClientPreparationStatus::
                capability_declaration_rejected:
            return "CAPABILITY_DECLARATION_REJECTED";
        case NATravPeerClientPreparationStatus::outbound_payload_size_rejected:
            return "OUTBOUND_PAYLOAD_SIZE_REJECTED";
        case NATravPeerClientPreparationStatus::
                expected_response_payload_size_rejected:
            return "EXPECTED_RESPONSE_PAYLOAD_SIZE_REJECTED";
        case NATravPeerClientPreparationStatus::codec_invariant_rejected:
            return "CODEC_INVARIANT_REJECTED";
    }
    return "UNKNOWN";
}

NATravPeerHandshakeStreamSession::NATravPeerHandshakeStreamSession(
    NATravPeerHandshakeExpectation expectation)
    : handshake_(std::move(expectation)) {}

NATravPeerHandshakeStreamSession::NATravPeerHandshakeStreamSession(
    NATravPeerHandshakeStreamSession&& other) noexcept
    : stream_(std::move(other.stream_)),
      handshake_(std::move(other.handshake_)),
      status_(other.status_),
      classification_(std::move(other.classification_)),
      chunks_observed_(other.chunks_observed_),
      peak_staged_frames_(other.peak_staged_frames_),
      frames_observed_(other.frames_observed_),
      messages_decoded_(other.messages_decoded_),
      handshake_transitions_(other.handshake_transitions_),
      fatal_terminal_(other.fatal_terminal_),
      input_closed_(other.input_closed_) {
    static_assert(std::is_nothrow_move_constructible_v<NATravPeerStreamDecoder>);
    static_assert(std::is_nothrow_move_constructible_v<NATravPeerHandshakeSession>);
    static_assert(std::is_nothrow_move_constructible_v<std::string>);
    // Never allocate a classification while retiring an owner. observation()
    // supplies the canonical status spelling without consulting its handshake.
    other.status_ = NATravPeerSessionStatus::moved_from;
    other.classification_.clear();
    other.chunks_observed_ = 0U;
    other.peak_staged_frames_ = 0U;
    other.frames_observed_ = 0U;
    other.messages_decoded_ = 0U;
    other.handshake_transitions_ = 0U;
    other.fatal_terminal_ = true;
    other.input_closed_ = true;
}

NATravPeerHandshakeStreamSession& NATravPeerHandshakeStreamSession::operator=(
    NATravPeerHandshakeStreamSession&& other) noexcept {
    if (this != &other) {
        NATravPeerHandshakeStreamSession replacement(std::move(other));
        swap(replacement);
    }
    return *this;
}

NATravPeerHandshakeStreamSession& NATravPeerHandshakeStreamSession::operator=(
    const NATravPeerHandshakeStreamSession& other) {
    if (this != &other) {
        // No constituent of *this is touched before the complete correlated
        // replacement exists. A throwing nested copy cannot mix expectations,
        // buffered bytes, accounting or classifications from two owners.
        NATravPeerHandshakeStreamSession replacement(other);
        swap(replacement);
    }
    return *this;
}

void NATravPeerHandshakeStreamSession::swap(
    NATravPeerHandshakeStreamSession& other) noexcept {
    if (this == &other) { return; }
    static_assert(std::is_nothrow_swappable_v<NATravPeerHandshakeSession>);
    using std::swap;
    stream_.swap(other.stream_);
    swap(handshake_, other.handshake_);
    classification_.swap(other.classification_);
    swap(status_, other.status_);
    swap(chunks_observed_, other.chunks_observed_);
    swap(peak_staged_frames_, other.peak_staged_frames_);
    swap(frames_observed_, other.frames_observed_);
    swap(messages_decoded_, other.messages_decoded_);
    swap(handshake_transitions_, other.handshake_transitions_);
    swap(fatal_terminal_, other.fatal_terminal_);
    swap(input_closed_, other.input_closed_);
}

bool NATravPeerHandshakeStreamSession::moved_from() const noexcept {
    return status_ == NATravPeerSessionStatus::moved_from;
}

void NATravPeerHandshakeStreamSession::terminate(
    const NATravPeerSessionStatus status,
    std::string classification) {
    status_ = status;
    classification_ = std::move(classification);
    fatal_terminal_ = true;
}

void NATravPeerHandshakeStreamSession::apply_handshake_observation(
    const NATravPeerHandshakeObservation& observation) {
    status_ = session_status(observation.status);
    if (observation.status == NATravPeerHandshakeStatus::operation_failed ||
        observation.status == NATravPeerHandshakeStatus::moved_from) {
        fatal_terminal_ = true;
    }
    classification_ = observation.classification;
}

void NATravPeerHandshakeStreamSession::process_frames(
    const std::vector<Octets>& frames) {
    for (const Octets& payload : frames) {
        if (fatal_terminal_ || input_closed_) {
            break;
        }
        ++frames_observed_;
        const NATravPeerMessageDecodeObservation decoded =
            natrav_peer_decode_message(payload);
        if (decoded.status != NATravPeerMessageDecodeStatus::accepted ||
            !decoded.message.has_value()) {
            terminate(session_status(decoded.status), decoded.classification);
            break;
        }
        ++messages_decoded_;
        const NATravPeerHandshakeObservation handshake_observation =
            handshake_.observe_response(*decoded.message);
        ++handshake_transitions_;
        apply_handshake_observation(handshake_observation);
    }
}

NATravPeerSessionObservation NATravPeerHandshakeStreamSession::feed(
    const OctetView chunk) {
    if (fatal_terminal_ || input_closed_) {
        return observation();
    }
    try {
        ++chunks_observed_;
        // Bound completed-payload staging independently of the size of a caller's
        // coalesced chunk. Stop each decoder feed at the next header or payload
        // boundary, so at most one completed payload can be retained here.
        std::vector<Octets> frames;
        std::size_t offset = 0U;
        do {
            const std::size_t boundary = kNATravPeerFrameHeaderBytes +
                static_cast<std::size_t>(stream_.expected_payload_bytes());
            const std::size_t take = std::min(
                boundary - stream_.buffered_bytes(), chunk.size() - offset);
            const NATravPeerStreamObservation stream_observation =
                stream_.feed(chunk.subspan(offset, take), frames);
            offset += take;
            peak_staged_frames_ = std::max(peak_staged_frames_, frames.size());
            process_frames(frames);
            frames.clear();
            if (stream_observation.status ==
                NATravPeerStreamStatus::malformed_frame) {
                if (!fatal_terminal_) {
                    terminate(NATravPeerSessionStatus::malformed_frame,
                              "MALFORMED_FRAME");
                }
                break;
            }
            // Even after a message error, drain the current chunk's framing (not
            // its messages), as the previous bulk decoder did. This preserves
            // first-failure precedence, trailing partial-frame observations and
            // stream terminality. Later caller feeds remain quiescent as before.
        } while (offset < chunk.size());
        return observation();
    } catch (...) {
        // Only scalar writes are permitted here: even persistent allocation
        // failure must not prevent the latch or replace the original exception.
        status_ = NATravPeerSessionStatus::operation_failed;
        fatal_terminal_ = true;
        throw;
    }
}

NATravPeerSessionObservation NATravPeerHandshakeStreamSession::finish() {
    if (fatal_terminal_ || input_closed_) {
        return observation();
    }
    try {
        std::vector<Octets> frames;
        const NATravPeerStreamObservation stream_observation = stream_.finish(frames);
        process_frames(frames);
        input_closed_ = true;
        if (fatal_terminal_) {
            return observation();
        }
        if (stream_observation.status == NATravPeerStreamStatus::malformed_frame) {
            terminate(NATravPeerSessionStatus::malformed_frame, "MALFORMED_FRAME");
            return observation();
        }
        if (stream_observation.status == NATravPeerStreamStatus::peer_unavailable) {
            status_ = NATravPeerSessionStatus::peer_unavailable;
            classification_ = "PEER_UNAVAILABLE";
            return observation();
        }
        const NATravPeerHandshakeObservation current = handshake_.observation();
        if (!current.terminal) {
            const NATravPeerHandshakeObservation unavailable =
                handshake_.observe_unavailability(NATravPeerHandshakeEvent::early_eof);
            ++handshake_transitions_;
            apply_handshake_observation(unavailable);
        }
        return observation();
    } catch (...) {
        // Only scalar writes are permitted here: even persistent allocation
        // failure must not prevent the latch or replace the original exception.
        status_ = NATravPeerSessionStatus::operation_failed;
        fatal_terminal_ = true;
        throw;
    }
}

NATravPeerSessionObservation
NATravPeerHandshakeStreamSession::observe_unavailability(
    const NATravPeerHandshakeEvent event) {
    if (fatal_terminal_ || input_closed_) {
        return observation();
    }
    try {
        input_closed_ = true;
        const NATravPeerHandshakeObservation handshake_observation =
            handshake_.observe_unavailability(event);
        ++handshake_transitions_;
        apply_handshake_observation(handshake_observation);
        return observation();
    } catch (...) {
        // Only scalar writes are permitted here: even persistent allocation
        // failure must not prevent the latch or replace the original exception.
        status_ = NATravPeerSessionStatus::operation_failed;
        fatal_terminal_ = true;
        throw;
    }
}

NATravPeerSessionObservation
NATravPeerHandshakeStreamSession::observation() const {
    return NATravPeerSessionObservation{
        .status = status_,
        .classification = moved_from() ? std::string("MOVED_FROM") :
            operation_failed() ? std::string("OPERATION_FAILED") : classification_,
        .chunks_observed = chunks_observed_,
        .peak_staged_frames = peak_staged_frames_,
        .frames_observed = frames_observed_,
        .messages_decoded = messages_decoded_,
        .handshake_transitions = handshake_transitions_,
        .buffered_bytes = stream_.buffered_bytes(),
        .expected_payload_bytes = stream_.expected_payload_bytes(),
        .stream_terminal = stream_.terminal(),
        .terminal = fatal_terminal_ || input_closed_ ||
            handshake_.observation().terminal,
    };
}

bool NATravPeerHandshakeStreamSession::operation_failed() const noexcept {
    return status_ == NATravPeerSessionStatus::operation_failed;
}

std::string_view natrav_peer_session_status_name(
    const NATravPeerSessionStatus status) noexcept {
    switch (status) {
        case NATravPeerSessionStatus::awaiting_response:
            return "AWAITING_RESPONSE";
        case NATravPeerSessionStatus::accepted: return "ACCEPTED";
        case NATravPeerSessionStatus::peer_error: return "PEER_ERROR";
        case NATravPeerSessionStatus::protocol_mismatch:
            return "PROTOCOL_MISMATCH";
        case NATravPeerSessionStatus::correlation_rejected:
            return "CORRELATION_REJECTED";
        case NATravPeerSessionStatus::artifact_identity_mismatch:
            return "ARTIFACT_IDENTITY_MISMATCH";
        case NATravPeerSessionStatus::capability_mismatch:
            return "CAPABILITY_MISMATCH";
        case NATravPeerSessionStatus::message_kind_rejected:
            return "MESSAGE_KIND_REJECTED";
        case NATravPeerSessionStatus::peer_unavailable:
            return "PEER_UNAVAILABLE";
        case NATravPeerSessionStatus::replay_rejected:
            return "REPLAY_REJECTED";
        case NATravPeerSessionStatus::malformed_frame:
            return "MALFORMED_FRAME";
        case NATravPeerSessionStatus::malformed_json:
            return "MALFORMED_JSON";
        case NATravPeerSessionStatus::noncanonical_json:
            return "NONCANONICAL_JSON";
        case NATravPeerSessionStatus::schema_rejected:
            return "SCHEMA_REJECTED";
        case NATravPeerSessionStatus::request_id_rejected:
            return "REQUEST_ID_REJECTED";
        case NATravPeerSessionStatus::artifact_identity_rejected:
            return "ARTIFACT_IDENTITY_REJECTED";
        case NATravPeerSessionStatus::capability_declaration_rejected:
            return "CAPABILITY_DECLARATION_REJECTED";
        case NATravPeerSessionStatus::operation_failed:
            return "OPERATION_FAILED";
        case NATravPeerSessionStatus::moved_from:
            return "MOVED_FROM";
    }
    return "UNKNOWN";
}

std::optional<NATravPeerClientHandshakeExchange>
NATravPeerClientHandshakeExchange::create(
    const NATravPeerPreparedClientHandshake& prepared,
    const Digest32& exchange_instance_id,
    const Digest32& transport_instance_id,
    const Digest32& process_instance_id) {
    if (!prepared_client_handshake_exact(prepared)) {
        return std::nullopt;
    }
    const Digest32 report_binding_sha256 = prepared.binding_sha256;
    const Digest32 exchange_binding_sha256 = natrav_peer_client_exchange_binding(
        exchange_instance_id, report_binding_sha256);
    const Digest32 transport_binding_sha256 = natrav_peer_client_transport_binding(
        transport_instance_id, exchange_binding_sha256);
    const Digest32 process_binding_sha256 = natrav_peer_client_process_binding(
        process_instance_id, transport_binding_sha256);
    return NATravPeerClientHandshakeExchange(VerifiedPlanState{
        .binding_bundle = BindingBundle{
            .exchange_binding_sha256 = exchange_binding_sha256,
            .transport_binding_sha256 = transport_binding_sha256,
            .process_binding_sha256 = process_binding_sha256,
            .report_binding_sha256 = report_binding_sha256,
        },
        .lifecycle_state = LifecycleState{},
        .report_coordinates = ReportCoordinateState{},
        .report_accounting = ReportAccountingState{},
        .operation_accounting = OperationAccountingState{},
        .request_frame = prepared.frame,
        .response = NATravPeerHandshakeStreamSession(prepared.expectation),
    });
}

NATravPeerClientHandshakeExchange::NATravPeerClientHandshakeExchange(
    VerifiedPlanState state)
    : verified_plan_state_(std::move(state)) {}

NATravPeerClientHandshakeExchange::NATravPeerClientHandshakeExchange(
    NATravPeerClientHandshakeExchange&& other) noexcept
    : verified_plan_state_(std::move(other.verified_plan_state_)) {
    static_assert(std::is_nothrow_move_constructible_v<VerifiedPlanState>);
    // Moving an optional does not disengage it. Reset explicitly so the old
    // owner cannot retain verified flags/cursors alongside moved-out bytes.
    other.verified_plan_state_.reset();
}

NATravPeerClientHandshakeExchange&
NATravPeerClientHandshakeExchange::operator=(
    NATravPeerClientHandshakeExchange&& other) noexcept {
    static_assert(std::is_nothrow_move_assignable_v<VerifiedPlanState>);
    static_assert(std::is_nothrow_move_constructible_v<VerifiedPlanState>);
    if (this != &other) {
        verified_plan_state_ = std::move(other.verified_plan_state_);
        other.verified_plan_state_.reset();
    }
    return *this;
}

std::optional<std::size_t>
NATravPeerClientHandshakeExchange::pending_request_offset() const noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return verified_plan_state_->report_coordinates.request_bytes_written;
}

std::optional<OctetView>
NATravPeerClientHandshakeExchange::pending_request_bytes() const & noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    if (verified_plan_state_->lifecycle_state.fatal_terminal ||
        verified_plan_state_->lifecycle_state.response_input_closed) {
        return OctetView{};
    }
    return OctetView(verified_plan_state_->request_frame).subspan(
        verified_plan_state_->report_coordinates.request_bytes_written);
}

std::optional<Digest32>
NATravPeerClientHandshakeExchange::exchange_binding_sha256() const noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return verified_plan_state_->binding_bundle.exchange_binding_sha256;
}

std::optional<Digest32>
NATravPeerClientHandshakeExchange::transport_binding_sha256() const noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return verified_plan_state_->binding_bundle.transport_binding_sha256;
}

std::optional<Digest32>
NATravPeerClientHandshakeExchange::process_binding_sha256() const noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return verified_plan_state_->binding_bundle.process_binding_sha256;
}

std::optional<Digest32>
NATravPeerClientHandshakeExchange::report_binding_sha256() const noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return verified_plan_state_->binding_bundle.report_binding_sha256;
}

std::optional<std::size_t>
NATravPeerClientHandshakeExchange::next_report_ordinal() const noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return verified_plan_state_->report_coordinates.next_report_ordinal;
}

std::optional<bool>
NATravPeerClientHandshakeExchange::binding_bundle_constructed() const noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return true;
}

std::optional<bool>
NATravPeerClientHandshakeExchange::lifecycle_state_constructed() const noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return true;
}

std::optional<bool>
NATravPeerClientHandshakeExchange::report_coordinate_state_constructed() const
    noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return true;
}

std::optional<bool>
NATravPeerClientHandshakeExchange::report_accounting_state_constructed() const
    noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return true;
}

std::optional<bool>
NATravPeerClientHandshakeExchange::operation_accounting_state_constructed() const
    noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return true;
}

std::optional<bool>
NATravPeerClientHandshakeExchange::verified_plan_state_constructed() const
    noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return true;
}

std::optional<bool>
NATravPeerClientHandshakeExchange::request_frame_constructed() const noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return true;
}

std::optional<bool>
NATravPeerClientHandshakeExchange::response_session_constructed() const
    noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return true;
}

void NATravPeerClientHandshakeExchange::terminate(
    const NATravPeerClientExchangeStatus status,
    std::string classification) {
    if (!verified_plan_state_.has_value()) {
        return;
    }
    verified_plan_state_->lifecycle_state.status = status;
    verified_plan_state_->lifecycle_state.classification = std::move(classification);
    verified_plan_state_->lifecycle_state.fatal_terminal = true;
}

void NATravPeerClientHandshakeExchange::apply_response_observation(
    const NATravPeerSessionObservation& response_observation) {
    if (!verified_plan_state_.has_value()) {
        return;
    }
    verified_plan_state_->lifecycle_state.status = client_exchange_status(response_observation.status);
    verified_plan_state_->lifecycle_state.classification = response_observation.classification;
}

bool NATravPeerClientHandshakeExchange::verify_exchange_binding(
    const Digest32& exchange_binding_sha256) {
    ++verified_plan_state_->report_accounting.reports_observed;
    ++verified_plan_state_->report_accounting.exchange_binding_checks_observed;
    if (exchange_binding_sha256 != verified_plan_state_->binding_bundle.exchange_binding_sha256) {
        terminate(
            NATravPeerClientExchangeStatus::exchange_binding_rejected,
            "EXCHANGE_BINDING_REJECTED");
        return false;
    }
    ++verified_plan_state_->report_accounting.exchange_bindings_admitted;
    return true;
}

bool NATravPeerClientHandshakeExchange::verify_transport_binding(
    const Digest32& transport_binding_sha256) {
    ++verified_plan_state_->report_accounting.transport_binding_checks_observed;
    if (transport_binding_sha256 != verified_plan_state_->binding_bundle.transport_binding_sha256) {
        terminate(
            NATravPeerClientExchangeStatus::transport_binding_rejected,
            "TRANSPORT_BINDING_REJECTED");
        return false;
    }
    ++verified_plan_state_->report_accounting.transport_bindings_admitted;
    return true;
}

bool NATravPeerClientHandshakeExchange::verify_process_binding(
    const Digest32& process_binding_sha256) {
    ++verified_plan_state_->report_accounting.process_binding_checks_observed;
    if (process_binding_sha256 != verified_plan_state_->binding_bundle.process_binding_sha256) {
        terminate(
            NATravPeerClientExchangeStatus::process_binding_rejected,
            "PROCESS_BINDING_REJECTED");
        return false;
    }
    ++verified_plan_state_->report_accounting.process_bindings_admitted;
    return true;
}

bool NATravPeerClientHandshakeExchange::verify_report_kind(
    const NATravPeerTransportReportKind actual,
    const NATravPeerTransportReportKind expected) {
    ++verified_plan_state_->report_accounting.report_kind_checks_observed;
    if (actual != expected) {
        terminate(
            NATravPeerClientExchangeStatus::report_kind_rejected,
            "REPORT_KIND_REJECTED");
        return false;
    }
    ++verified_plan_state_->report_accounting.report_kinds_admitted;
    return true;
}

bool NATravPeerClientHandshakeExchange::verify_report_binding(
    const Digest32& report_binding_sha256) {
    ++verified_plan_state_->report_accounting.report_binding_checks_observed;
    if (report_binding_sha256 != verified_plan_state_->binding_bundle.report_binding_sha256) {
        terminate(
            NATravPeerClientExchangeStatus::report_binding_rejected,
            "REPORT_BINDING_REJECTED");
        return false;
    }
    ++verified_plan_state_->report_accounting.report_bindings_admitted;
    return true;
}

bool NATravPeerClientHandshakeExchange::verify_report_ordinal(
    const std::size_t report_ordinal) {
    ++verified_plan_state_->report_accounting.report_ordinal_checks_observed;
    if (report_ordinal != verified_plan_state_->report_coordinates.next_report_ordinal) {
        terminate(
            NATravPeerClientExchangeStatus::report_ordinal_rejected,
            "REPORT_ORDINAL_REJECTED");
        return false;
    }
    ++verified_plan_state_->report_accounting.report_ordinals_admitted;
    ++verified_plan_state_->report_coordinates.next_report_ordinal;
    return true;
}

bool NATravPeerClientHandshakeExchange::verify_report_phase(
    const NATravPeerTransportReportKind report_kind) {
    ++verified_plan_state_->report_accounting.report_phase_checks_observed;
    bool admitted = !verified_plan_state_->lifecycle_state.response_input_closed;
    if (admitted && report_kind == NATravPeerTransportReportKind::write) {
        admitted = verified_plan_state_->report_coordinates.request_bytes_written < verified_plan_state_->request_frame.size();
    } else if (
        admitted &&
        (report_kind == NATravPeerTransportReportKind::response_chunk ||
         report_kind == NATravPeerTransportReportKind::response_finish)) {
        admitted = verified_plan_state_->report_coordinates.request_bytes_written == verified_plan_state_->request_frame.size();
    } else if (
        admitted && report_kind == NATravPeerTransportReportKind::spawn_failure) {
        admitted = verified_plan_state_->report_accounting.report_ordinals_admitted == 1U &&
            verified_plan_state_->report_coordinates.request_bytes_written == 0U && verified_plan_state_->report_coordinates.response_bytes_received == 0U;
    }
    if (!admitted) {
        terminate(
            NATravPeerClientExchangeStatus::report_phase_rejected,
            "REPORT_PHASE_REJECTED");
        return false;
    }
    ++verified_plan_state_->report_accounting.report_phases_admitted;
    return true;
}

NATravPeerClientExchangeObservation
NATravPeerClientHandshakeExchange::observe_write(
    const Digest32& exchange_binding_sha256,
    const Digest32& transport_binding_sha256,
    const Digest32& process_binding_sha256,
    const NATravPeerTransportReportKind report_kind,
    const Digest32& report_binding_sha256,
    const std::size_t report_ordinal,
    const std::size_t request_offset,
    const std::size_t response_offset,
    const OctetView written_segment) {
    if (!verified_plan_state_.has_value() ||
        verified_plan_state_->lifecycle_state.fatal_terminal) {
        return observation();
    }
    try {
        ++verified_plan_state_->operation_accounting.write_reports_observed;
        if (!verify_exchange_binding(exchange_binding_sha256)) {
            return observation();
        }
        if (!verify_transport_binding(transport_binding_sha256)) {
            return observation();
        }
        if (!verify_process_binding(process_binding_sha256)) {
            return observation();
        }
        if (!verify_report_kind(
                report_kind, NATravPeerTransportReportKind::write)) {
            return observation();
        }
        if (!verify_report_binding(report_binding_sha256)) {
            return observation();
        }
        if (!verify_report_ordinal(report_ordinal)) {
            return observation();
        }
        if (!verify_report_phase(report_kind)) {
            return observation();
        }
        ++verified_plan_state_->operation_accounting.write_offset_checks_observed;
        if (request_offset != verified_plan_state_->report_coordinates.request_bytes_written) {
            terminate(
                NATravPeerClientExchangeStatus::write_offset_rejected,
                "WRITE_OFFSET_REJECTED");
            return observation();
        }
        ++verified_plan_state_->operation_accounting.write_response_offset_checks_observed;
        if (response_offset != verified_plan_state_->report_coordinates.response_bytes_received) {
            terminate(
                NATravPeerClientExchangeStatus::write_response_offset_rejected,
                "WRITE_RESPONSE_OFFSET_REJECTED");
            return observation();
        }

        const std::size_t pending = verified_plan_state_->request_frame.size() - verified_plan_state_->report_coordinates.request_bytes_written;
        if (written_segment.size() > pending) {
            terminate(
                NATravPeerClientExchangeStatus::write_progress_rejected,
                "WRITE_PROGRESS_REJECTED");
            return observation();
        }

        ++verified_plan_state_->operation_accounting.write_segment_checks_observed;
        const OctetView expected = OctetView(verified_plan_state_->request_frame).subspan(
            verified_plan_state_->report_coordinates.request_bytes_written, written_segment.size());
        if (!std::equal(
                written_segment.begin(), written_segment.end(), expected.begin())) {
            terminate(
                NATravPeerClientExchangeStatus::write_segment_rejected,
                "WRITE_SEGMENT_REJECTED");
            return observation();
        }

        verified_plan_state_->report_coordinates.request_bytes_written += written_segment.size();
        verified_plan_state_->operation_accounting.write_segment_bytes_verified += written_segment.size();
        if (verified_plan_state_->report_coordinates.request_bytes_written == verified_plan_state_->request_frame.size()) {
            verified_plan_state_->lifecycle_state.status = NATravPeerClientExchangeStatus::awaiting_response;
            verified_plan_state_->lifecycle_state.classification = "AWAITING_RESPONSE";
        }
        return observation();
    } catch (...) {
        // Do not allocate while recording failure: even a returned observation
        // can throw after report accounting or decoder progress has committed.
        verified_plan_state_->lifecycle_state.status =
            NATravPeerClientExchangeStatus::operation_failed;
        verified_plan_state_->lifecycle_state.fatal_terminal = true;
        throw;
    }
}

std::optional<std::size_t>
NATravPeerClientHandshakeExchange::next_response_offset() const noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return verified_plan_state_->report_coordinates.response_bytes_received;
}

NATravPeerClientExchangeObservation
NATravPeerClientHandshakeExchange::feed_response(
    const Digest32& exchange_binding_sha256,
    const Digest32& transport_binding_sha256,
    const Digest32& process_binding_sha256,
    const NATravPeerTransportReportKind report_kind,
    const Digest32& report_binding_sha256,
    const std::size_t report_ordinal,
    const std::size_t request_offset,
    const std::size_t response_offset,
    const OctetView chunk) {
    if (!verified_plan_state_.has_value() ||
        verified_plan_state_->lifecycle_state.fatal_terminal) {
        return observation();
    }
    try {
        ++verified_plan_state_->operation_accounting.response_reports_observed;
        if (!verify_exchange_binding(exchange_binding_sha256)) {
            return observation();
        }
        if (!verify_transport_binding(transport_binding_sha256)) {
            return observation();
        }
        if (!verify_process_binding(process_binding_sha256)) {
            return observation();
        }
        if (!verify_report_kind(
                report_kind, NATravPeerTransportReportKind::response_chunk)) {
            return observation();
        }
        if (!verify_report_binding(report_binding_sha256)) {
            return observation();
        }
        if (!verify_report_ordinal(report_ordinal)) {
            return observation();
        }
        if (!verify_report_phase(report_kind)) {
            return observation();
        }
        ++verified_plan_state_->operation_accounting.response_request_offset_checks_observed;
        if (request_offset != verified_plan_state_->report_coordinates.request_bytes_written) {
            terminate(
                NATravPeerClientExchangeStatus::response_request_offset_rejected,
                "RESPONSE_REQUEST_OFFSET_REJECTED");
            return observation();
        }
        if (verified_plan_state_->report_coordinates.request_bytes_written != verified_plan_state_->request_frame.size()) {
            terminate(
                NATravPeerClientExchangeStatus::
                    response_before_request_complete_rejected,
                "RESPONSE_BEFORE_REQUEST_COMPLETE_REJECTED");
            return observation();
        }
        ++verified_plan_state_->operation_accounting.response_offset_checks_observed;
        if (response_offset != verified_plan_state_->report_coordinates.response_bytes_received) {
            terminate(
                NATravPeerClientExchangeStatus::response_offset_rejected,
                "RESPONSE_OFFSET_REJECTED");
            return observation();
        }
        verified_plan_state_->report_coordinates.response_bytes_received += chunk.size();
        apply_response_observation(verified_plan_state_->response.feed(chunk));
        return observation();
    } catch (...) {
        // Do not allocate while recording failure: even a returned observation
        // can throw after report accounting or decoder progress has committed.
        verified_plan_state_->lifecycle_state.status =
            NATravPeerClientExchangeStatus::operation_failed;
        verified_plan_state_->lifecycle_state.fatal_terminal = true;
        throw;
    }
}

bool NATravPeerClientHandshakeExchange::verify_response_terminal_offsets(
    const std::size_t request_offset,
    const std::size_t response_offset) {
    ++verified_plan_state_->operation_accounting.response_terminal_request_offset_checks_observed;
    if (request_offset != verified_plan_state_->report_coordinates.request_bytes_written) {
        terminate(
            NATravPeerClientExchangeStatus::
                response_terminal_request_offset_rejected,
            "RESPONSE_TERMINAL_REQUEST_OFFSET_REJECTED");
        return false;
    }
    ++verified_plan_state_->operation_accounting.response_terminal_offset_checks_observed;
    if (response_offset != verified_plan_state_->report_coordinates.response_bytes_received) {
        terminate(
            NATravPeerClientExchangeStatus::response_terminal_offset_rejected,
            "RESPONSE_TERMINAL_OFFSET_REJECTED");
        return false;
    }
    return true;
}

NATravPeerClientExchangeObservation
NATravPeerClientHandshakeExchange::finish_response(
    const Digest32& exchange_binding_sha256,
    const Digest32& transport_binding_sha256,
    const Digest32& process_binding_sha256,
    const NATravPeerTransportReportKind report_kind,
    const Digest32& report_binding_sha256,
    const std::size_t report_ordinal,
    const std::size_t request_offset,
    const std::size_t response_offset) {
    if (!verified_plan_state_.has_value() ||
        verified_plan_state_->lifecycle_state.fatal_terminal) {
        return observation();
    }
    try {
        ++verified_plan_state_->operation_accounting.response_terminal_reports_observed;
        if (!verify_exchange_binding(exchange_binding_sha256)) {
            return observation();
        }
        if (!verify_transport_binding(transport_binding_sha256)) {
            return observation();
        }
        if (!verify_process_binding(process_binding_sha256)) {
            return observation();
        }
        if (!verify_report_kind(
                report_kind, NATravPeerTransportReportKind::response_finish)) {
            return observation();
        }
        if (!verify_report_binding(report_binding_sha256)) {
            return observation();
        }
        if (!verify_report_ordinal(report_ordinal)) {
            return observation();
        }
        if (!verify_report_phase(report_kind)) {
            return observation();
        }
        if (!verify_response_terminal_offsets(request_offset, response_offset)) {
            return observation();
        }
        verified_plan_state_->lifecycle_state.response_input_closed = true;
        if (verified_plan_state_->report_coordinates.request_bytes_written != verified_plan_state_->request_frame.size()) {
            terminate(
                NATravPeerClientExchangeStatus::peer_unavailable,
                "PEER_UNAVAILABLE");
            return observation();
        }
        apply_response_observation(verified_plan_state_->response.finish());
        return observation();
    } catch (...) {
        // Do not allocate while recording failure: even a returned observation
        // can throw after report accounting or decoder progress has committed.
        verified_plan_state_->lifecycle_state.status =
            NATravPeerClientExchangeStatus::operation_failed;
        verified_plan_state_->lifecycle_state.fatal_terminal = true;
        throw;
    }
}

NATravPeerClientExchangeObservation
NATravPeerClientHandshakeExchange::observe_unavailability(
    const Digest32& exchange_binding_sha256,
    const Digest32& transport_binding_sha256,
    const Digest32& process_binding_sha256,
    const NATravPeerTransportReportKind report_kind,
    const Digest32& report_binding_sha256,
    const std::size_t report_ordinal,
    const std::size_t request_offset,
    const std::size_t response_offset,
    const NATravPeerHandshakeEvent event) {
    if (!verified_plan_state_.has_value() ||
        verified_plan_state_->lifecycle_state.fatal_terminal) {
        return observation();
    }
    try {
        ++verified_plan_state_->operation_accounting.response_terminal_reports_observed;
        if (!verify_exchange_binding(exchange_binding_sha256)) {
            return observation();
        }
        if (!verify_transport_binding(transport_binding_sha256)) {
            return observation();
        }
        if (!verify_process_binding(process_binding_sha256)) {
            return observation();
        }
        if (!verify_report_kind(report_kind, unavailability_report_kind(event))) {
            return observation();
        }
        if (!verify_report_binding(report_binding_sha256)) {
            return observation();
        }
        if (!verify_report_ordinal(report_ordinal)) {
            return observation();
        }
        if (!verify_report_phase(report_kind)) {
            return observation();
        }
        if (!verify_response_terminal_offsets(request_offset, response_offset)) {
            return observation();
        }
        verified_plan_state_->lifecycle_state.response_input_closed = true;
        if (verified_plan_state_->report_coordinates.request_bytes_written != verified_plan_state_->request_frame.size()) {
            verified_plan_state_->lifecycle_state.status = NATravPeerClientExchangeStatus::peer_unavailable;
            verified_plan_state_->lifecycle_state.classification = "PEER_UNAVAILABLE";
            return observation();
        }
        apply_response_observation(verified_plan_state_->response.observe_unavailability(event));
        return observation();
    } catch (...) {
        // Do not allocate while recording failure: even a returned observation
        // can throw after report accounting or decoder progress has committed.
        verified_plan_state_->lifecycle_state.status =
            NATravPeerClientExchangeStatus::operation_failed;
        verified_plan_state_->lifecycle_state.fatal_terminal = true;
        throw;
    }
}

std::optional<bool>
NATravPeerClientHandshakeExchange::operation_failed() const noexcept {
    if (!verified_plan_state_.has_value()) {
        return std::nullopt;
    }
    return verified_plan_state_->lifecycle_state.status ==
        NATravPeerClientExchangeStatus::operation_failed;
}

NATravPeerClientExchangeObservation
NATravPeerClientHandshakeExchange::observation() const {
    const bool prepared_plan_binding_verified = verified_plan_state_.has_value();
    const NATravPeerSessionObservation response_observation =
        prepared_plan_binding_verified ? verified_plan_state_->response.observation() :
        NATravPeerSessionObservation{};
    const std::optional<OctetView> pending_request = pending_request_bytes();
    return NATravPeerClientExchangeObservation{
        .status = prepared_plan_binding_verified ?
            std::optional<NATravPeerClientExchangeStatus>{verified_plan_state_->lifecycle_state.status} :
            std::nullopt,
        .classification = prepared_plan_binding_verified ?
            std::optional<std::string>{operation_failed().value_or(false) ?
                std::string("OPERATION_FAILED") :
                verified_plan_state_->lifecycle_state.classification} : std::nullopt,
        .reports_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.reports_observed} : std::nullopt,
        .exchange_binding_checks_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.exchange_binding_checks_observed} :
            std::nullopt,
        .exchange_bindings_admitted = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.exchange_bindings_admitted} :
            std::nullopt,
        .transport_binding_checks_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.transport_binding_checks_observed} :
            std::nullopt,
        .transport_bindings_admitted = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.transport_bindings_admitted} :
            std::nullopt,
        .process_binding_checks_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.process_binding_checks_observed} :
            std::nullopt,
        .process_bindings_admitted = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.process_bindings_admitted} :
            std::nullopt,
        .report_kind_checks_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.report_kind_checks_observed} :
            std::nullopt,
        .report_kinds_admitted = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.report_kinds_admitted} : std::nullopt,
        .report_binding_checks_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.report_binding_checks_observed} :
            std::nullopt,
        .report_bindings_admitted = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.report_bindings_admitted} :
            std::nullopt,
        .report_ordinal_checks_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.report_ordinal_checks_observed} :
            std::nullopt,
        .report_ordinals_admitted = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.report_ordinals_admitted} :
            std::nullopt,
        .report_phase_checks_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.report_phase_checks_observed} :
            std::nullopt,
        .report_phases_admitted = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_accounting.report_phases_admitted} : std::nullopt,
        .next_report_ordinal = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_coordinates.next_report_ordinal} : std::nullopt,
        .write_reports_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->operation_accounting.write_reports_observed} : std::nullopt,
        .write_offset_checks_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->operation_accounting.write_offset_checks_observed} :
            std::nullopt,
        .write_response_offset_checks_observed =
            prepared_plan_binding_verified ?
            std::optional<std::size_t>{
                verified_plan_state_->operation_accounting.write_response_offset_checks_observed} : std::nullopt,
        .write_segment_checks_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->operation_accounting.write_segment_checks_observed} :
            std::nullopt,
        .write_segment_bytes_verified = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->operation_accounting.write_segment_bytes_verified} :
            std::nullopt,
        .request_frame_bytes = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->request_frame.size()} : std::nullopt,
        .request_bytes_written = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_coordinates.request_bytes_written} : std::nullopt,
        .request_bytes_pending = prepared_plan_binding_verified ?
            std::optional<std::size_t>{
                verified_plan_state_->request_frame.size() - verified_plan_state_->report_coordinates.request_bytes_written} : std::nullopt,
        .request_bytes_exposed = pending_request.has_value() ?
            std::optional<std::size_t>{pending_request->size()} : std::nullopt,
        .response_reports_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->operation_accounting.response_reports_observed} :
            std::nullopt,
        .response_request_offset_checks_observed =
            prepared_plan_binding_verified ?
            std::optional<std::size_t>{
                verified_plan_state_->operation_accounting.response_request_offset_checks_observed} : std::nullopt,
        .response_offset_checks_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->operation_accounting.response_offset_checks_observed} :
            std::nullopt,
        .response_terminal_reports_observed =
            prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->operation_accounting.response_terminal_reports_observed} :
            std::nullopt,
        .response_terminal_request_offset_checks_observed =
            prepared_plan_binding_verified ?
            std::optional<std::size_t>{
                verified_plan_state_->operation_accounting.response_terminal_request_offset_checks_observed} :
            std::nullopt,
        .response_terminal_offset_checks_observed =
            prepared_plan_binding_verified ?
            std::optional<std::size_t>{
                verified_plan_state_->operation_accounting.response_terminal_offset_checks_observed} : std::nullopt,
        .response_bytes_received = prepared_plan_binding_verified ?
            std::optional<std::size_t>{verified_plan_state_->report_coordinates.response_bytes_received} : std::nullopt,
        .response_chunks_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{response_observation.chunks_observed} :
            std::nullopt,
        .response_frames_observed = prepared_plan_binding_verified ?
            std::optional<std::size_t>{response_observation.frames_observed} :
            std::nullopt,
        .response_messages_decoded = prepared_plan_binding_verified ?
            std::optional<std::size_t>{response_observation.messages_decoded} :
            std::nullopt,
        .response_handshake_transitions = prepared_plan_binding_verified ?
            std::optional<std::size_t>{
                response_observation.handshake_transitions} : std::nullopt,
        .response_buffered_bytes = prepared_plan_binding_verified ?
            std::optional<std::size_t>{response_observation.buffered_bytes} :
            std::nullopt,
        .response_expected_payload_bytes = prepared_plan_binding_verified ?
            std::optional<std::uint32_t>{
                response_observation.expected_payload_bytes} : std::nullopt,
        .prepared_plan_binding_verified =
            prepared_plan_binding_verified,
        .request_write_complete = prepared_plan_binding_verified ?
            std::optional<bool>{
                verified_plan_state_->report_coordinates.request_bytes_written == verified_plan_state_->request_frame.size()} : std::nullopt,
        .response_stream_terminal = prepared_plan_binding_verified ?
            std::optional<bool>{response_observation.stream_terminal} :
            std::nullopt,
        .response_session_terminal = prepared_plan_binding_verified ?
            std::optional<bool>{response_observation.terminal} :
            std::nullopt,
        .response_session_status = prepared_plan_binding_verified ?
            std::optional<NATravPeerSessionStatus>{response_observation.status} :
            std::nullopt,
        .response_session_classification = prepared_plan_binding_verified ?
            std::optional<std::string>{response_observation.classification} :
            std::nullopt,
        .response_input_closed = prepared_plan_binding_verified ?
            std::optional<bool>{verified_plan_state_->lifecycle_state.response_input_closed} : std::nullopt,
        .report_processing_terminal = prepared_plan_binding_verified ?
            std::optional<bool>{verified_plan_state_->lifecycle_state.fatal_terminal} : std::nullopt,
        .terminal = prepared_plan_binding_verified ?
            std::optional<bool>{verified_plan_state_->lifecycle_state.fatal_terminal || verified_plan_state_->lifecycle_state.response_input_closed ||
                response_observation.terminal} : std::nullopt,
    };
}

std::string_view natrav_peer_transport_report_kind_name(
    const NATravPeerTransportReportKind kind) noexcept {
    switch (kind) {
        case NATravPeerTransportReportKind::write: return "WRITE";
        case NATravPeerTransportReportKind::response_chunk:
            return "RESPONSE_CHUNK";
        case NATravPeerTransportReportKind::response_finish:
            return "RESPONSE_FINISH";
        case NATravPeerTransportReportKind::early_eof: return "EARLY_EOF";
        case NATravPeerTransportReportKind::timeout: return "TIMEOUT";
        case NATravPeerTransportReportKind::spawn_failure:
            return "SPAWN_FAILURE";
    }
    return "UNKNOWN";
}

std::string_view natrav_peer_client_exchange_status_name(
    const NATravPeerClientExchangeStatus status) noexcept {
    switch (status) {
        case NATravPeerClientExchangeStatus::operation_failed:
            return "OPERATION_FAILED";
        case NATravPeerClientExchangeStatus::awaiting_request_write:
            return "AWAITING_REQUEST_WRITE";
        case NATravPeerClientExchangeStatus::awaiting_response:
            return "AWAITING_RESPONSE";
        case NATravPeerClientExchangeStatus::accepted: return "ACCEPTED";
        case NATravPeerClientExchangeStatus::peer_error: return "PEER_ERROR";
        case NATravPeerClientExchangeStatus::protocol_mismatch:
            return "PROTOCOL_MISMATCH";
        case NATravPeerClientExchangeStatus::correlation_rejected:
            return "CORRELATION_REJECTED";
        case NATravPeerClientExchangeStatus::artifact_identity_mismatch:
            return "ARTIFACT_IDENTITY_MISMATCH";
        case NATravPeerClientExchangeStatus::capability_mismatch:
            return "CAPABILITY_MISMATCH";
        case NATravPeerClientExchangeStatus::message_kind_rejected:
            return "MESSAGE_KIND_REJECTED";
        case NATravPeerClientExchangeStatus::peer_unavailable:
            return "PEER_UNAVAILABLE";
        case NATravPeerClientExchangeStatus::replay_rejected:
            return "REPLAY_REJECTED";
        case NATravPeerClientExchangeStatus::malformed_frame:
            return "MALFORMED_FRAME";
        case NATravPeerClientExchangeStatus::malformed_json:
            return "MALFORMED_JSON";
        case NATravPeerClientExchangeStatus::noncanonical_json:
            return "NONCANONICAL_JSON";
        case NATravPeerClientExchangeStatus::schema_rejected:
            return "SCHEMA_REJECTED";
        case NATravPeerClientExchangeStatus::request_id_rejected:
            return "REQUEST_ID_REJECTED";
        case NATravPeerClientExchangeStatus::artifact_identity_rejected:
            return "ARTIFACT_IDENTITY_REJECTED";
        case NATravPeerClientExchangeStatus::
                capability_declaration_rejected:
            return "CAPABILITY_DECLARATION_REJECTED";
        case NATravPeerClientExchangeStatus::write_progress_rejected:
            return "WRITE_PROGRESS_REJECTED";
        case NATravPeerClientExchangeStatus::
                response_before_request_complete_rejected:
            return "RESPONSE_BEFORE_REQUEST_COMPLETE_REJECTED";
        case NATravPeerClientExchangeStatus::prepared_plan_binding_rejected:
            return "PREPARED_PLAN_BINDING_REJECTED";
        case NATravPeerClientExchangeStatus::exchange_binding_rejected:
            return "EXCHANGE_BINDING_REJECTED";
        case NATravPeerClientExchangeStatus::transport_binding_rejected:
            return "TRANSPORT_BINDING_REJECTED";
        case NATravPeerClientExchangeStatus::process_binding_rejected:
            return "PROCESS_BINDING_REJECTED";
        case NATravPeerClientExchangeStatus::report_kind_rejected:
            return "REPORT_KIND_REJECTED";
        case NATravPeerClientExchangeStatus::report_binding_rejected:
            return "REPORT_BINDING_REJECTED";
        case NATravPeerClientExchangeStatus::report_phase_rejected:
            return "REPORT_PHASE_REJECTED";
        case NATravPeerClientExchangeStatus::report_ordinal_rejected:
            return "REPORT_ORDINAL_REJECTED";
        case NATravPeerClientExchangeStatus::write_segment_rejected:
            return "WRITE_SEGMENT_REJECTED";
        case NATravPeerClientExchangeStatus::write_offset_rejected:
            return "WRITE_OFFSET_REJECTED";
        case NATravPeerClientExchangeStatus::write_response_offset_rejected:
            return "WRITE_RESPONSE_OFFSET_REJECTED";
        case NATravPeerClientExchangeStatus::response_request_offset_rejected:
            return "RESPONSE_REQUEST_OFFSET_REJECTED";
        case NATravPeerClientExchangeStatus::response_offset_rejected:
            return "RESPONSE_OFFSET_REJECTED";
        case NATravPeerClientExchangeStatus::
                response_terminal_request_offset_rejected:
            return "RESPONSE_TERMINAL_REQUEST_OFFSET_REJECTED";
        case NATravPeerClientExchangeStatus::response_terminal_offset_rejected:
            return "RESPONSE_TERMINAL_OFFSET_REJECTED";
    }
    return "UNKNOWN";
}

}  // namespace datacube

// Standalone, opt-in regression executable. Not present in the delivered
// runtime/forge: no global allocation replacement or fault hook is enabled by
// the canonical build manifest. See BUILD.txt for the reproducible command.
#if defined(DATACUBE_NATRAV_SESSION_ALLOCATION_FAILURE_TEST) || \
    defined(DATACUBE_NATRAV_EXCHANGE_ALLOCATION_FAILURE_TEST) || \
    defined(DATACUBE_NATRAV_STREAM_ALLOCATION_FAILURE_TEST) || \
    defined(DATACUBE_NATRAV_STREAM_LIFECYCLE_TEST) || \
    defined(DATACUBE_NATRAV_SESSION_LIFECYCLE_TEST) || \
    defined(DATACUBE_NATRAV_HANDSHAKE_ALLOCATION_FAILURE_TEST) || \
    defined(DATACUBE_NATRAV_HANDSHAKE_LIFECYCLE_TEST) || \
    defined(DATACUBE_NATRAV_HANDSHAKE_CAPABILITY_TEST)
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <new>

namespace natrav_allocation_test {
struct InjectedBadAlloc final : std::bad_alloc {
    explicit InjectedBadAlloc(const std::size_t index) noexcept : point(index) {}
    const char* what() const noexcept override { return "NATRAV_TEST_BAD_ALLOC"; }
    std::size_t point;
};
struct FaultState final {
    bool armed{false};
    bool persistent{false};
    std::size_t point{0U};
    std::size_t attempts{0U};
};
thread_local FaultState fault;
void arm(const std::size_t point, const bool persistent) noexcept {
    fault = {true, persistent, point, 0U};
}
void disarm() noexcept { fault.armed = false; }
void allocation_point() {
    if (!fault.armed) { return; }
    const std::size_t current = fault.attempts++;
    if (current == fault.point || (fault.persistent && current > fault.point)) {
        throw InjectedBadAlloc(current);
    }
}
[[nodiscard]] void* allocate(const std::size_t size) {
    allocation_point();
    void* result = std::malloc(size == 0U ? 1U : size);
    if (result == nullptr) { throw std::bad_alloc(); }
    return result;
}
[[nodiscard]] void* allocate_aligned(const std::size_t size,
                                    const std::align_val_t alignment) {
    allocation_point();
    void* result = nullptr;
    if (posix_memalign(&result, static_cast<std::size_t>(alignment),
                       size == 0U ? 1U : size) != 0) {
        throw std::bad_alloc();
    }
    return result;
}
// Separate functions prevent compiler false positives about replacement-new
// ownership while retaining warnings on the production code.
[[gnu::noinline]] void release(void* const ptr) noexcept { std::free(ptr); }
}  // namespace natrav_allocation_test

void* operator new(const std::size_t size) {
    return natrav_allocation_test::allocate(size);
}
void* operator new[](const std::size_t size) {
    return natrav_allocation_test::allocate(size);
}
void operator delete(void* const ptr) noexcept { natrav_allocation_test::release(ptr); }
void operator delete[](void* const ptr) noexcept { natrav_allocation_test::release(ptr); }
void operator delete(void* const ptr, std::size_t) noexcept {
    natrav_allocation_test::release(ptr);
}
void operator delete[](void* const ptr, std::size_t) noexcept {
    natrav_allocation_test::release(ptr);
}
void* operator new(const std::size_t size, const std::align_val_t alignment) {
    return natrav_allocation_test::allocate_aligned(size, alignment);
}
void* operator new[](const std::size_t size, const std::align_val_t alignment) {
    return natrav_allocation_test::allocate_aligned(size, alignment);
}
void operator delete(void* const ptr, std::align_val_t) noexcept {
    natrav_allocation_test::release(ptr);
}
void operator delete[](void* const ptr, std::align_val_t) noexcept {
    natrav_allocation_test::release(ptr);
}
void operator delete(void* const ptr, std::size_t, std::align_val_t) noexcept {
    natrav_allocation_test::release(ptr);
}
void operator delete[](void* const ptr, std::size_t, std::align_val_t) noexcept {
    natrav_allocation_test::release(ptr);
}

#endif  // Shared test-only allocation injector.

#ifdef DATACUBE_NATRAV_SESSION_ALLOCATION_FAILURE_TEST
namespace natrav_allocation_test {
using namespace datacube;
using Session = NATravPeerHandshakeStreamSession;
using Observation = NATravPeerSessionObservation;
enum class Operation { feed, finish, timeout, early_eof, spawn_failure, observe };
struct Results final {
    std::size_t scenarios{0U};
    std::size_t allocation_points{0U};
    std::size_t faults{0U};
    std::size_t original_exceptions{0U};
    std::size_t active_faults{0U};
    std::size_t latched_faults{0U};
    std::size_t read_only_faults{0U};
    std::size_t read_only_unchanged{0U};
    std::size_t no_allocation_queries{0U};
    std::size_t quiescence_checks{0U};
    std::size_t quiescence_verified{0U};
    std::size_t persistent_snapshot_throws{0U};
    std::size_t complete_frame_faults{0U};
    std::size_t partial_progress_faults{0U};
    std::size_t failures{0U};
};
[[nodiscard]] bool equal(const Observation& a, const Observation& b) {
    return a.status == b.status && a.classification == b.classification &&
        a.chunks_observed == b.chunks_observed &&
        a.peak_staged_frames == b.peak_staged_frames &&
        a.frames_observed == b.frames_observed &&
        a.messages_decoded == b.messages_decoded &&
        a.handshake_transitions == b.handshake_transitions &&
        a.buffered_bytes == b.buffered_bytes &&
        a.expected_payload_bytes == b.expected_payload_bytes &&
        a.stream_terminal == b.stream_terminal && a.terminal == b.terminal;
}
void invoke(Session& session, const Operation operation, const OctetView bytes) {
    switch (operation) {
        case Operation::feed: static_cast<void>(session.feed(bytes)); return;
        case Operation::finish: static_cast<void>(session.finish()); return;
        case Operation::timeout:
            static_cast<void>(session.observe_unavailability(
                NATravPeerHandshakeEvent::timeout)); return;
        case Operation::early_eof:
            static_cast<void>(session.observe_unavailability(
                NATravPeerHandshakeEvent::early_eof)); return;
        case Operation::spawn_failure:
            static_cast<void>(session.observe_unavailability(
                NATravPeerHandshakeEvent::spawn_failure)); return;
        case Operation::observe: static_cast<void>(session.observation()); return;
    }
}
void check(Results& results, const bool exact, const char* const label,
           const std::size_t point) {
    if (exact) { return; }
    ++results.failures;
    if (results.failures <= 8U) {
        std::printf("FAIL label=%s allocation=%zu\n", label, point);
    }
}
void run_case(Results& results, const Session& seed, const OctetView bytes,
              const Operation operation, const bool active,
              const char* const label, const OctetView replay) {
    ++results.scenarios;
    const Observation before = seed.observation();
    Session control(seed);
    arm(std::numeric_limits<std::size_t>::max(), false);
    invoke(control, operation, bytes);
    const std::size_t points = fault.attempts;
    disarm();
    results.allocation_points += points;
    const Observation expected = control.observation();
    check(results, !control.operation_failed(), label, points);

    for (const bool persistent : {false, true}) {
        // The first out-of-range point is a success boundary control.
        for (std::size_t point = 0U; point <= points; ++point) {
            Session subject(seed);
            bool threw = false;
            bool original = false;
            arm(point, persistent);
            try {
                invoke(subject, operation, bytes);
            } catch (const InjectedBadAlloc& error) {
                threw = true;
                original = error.point == point;
            } catch (...) {
                threw = true;
            }
            const std::size_t attempts_before_query = fault.attempts;
            const bool failed = subject.operation_failed();
            const bool query_did_not_allocate =
                attempts_before_query == fault.attempts;
            disarm();
            if (point == points) {
                check(results, !threw && !failed &&
                    equal(subject.observation(), expected), label, point);
                continue;
            }
            ++results.faults;
            if (original) { ++results.original_exceptions; }
            if (query_did_not_allocate) { ++results.no_allocation_queries; }
            check(results, threw && original && query_did_not_allocate,
                  label, point);
            if (!active) {
                ++results.read_only_faults;
                const bool unchanged = !failed &&
                    equal(subject.observation(), before);
                if (unchanged) { ++results.read_only_unchanged; }
                check(results, unchanged, label, point);
                continue;
            }
            ++results.active_faults;
            if (failed) { ++results.latched_faults; }
            check(results, failed, label, point);
            // A mutation diagnostic without the latch can retain a complete
            // frame. Never re-enter it: the old bounded loop can make zero
            // progress. Missing the latch already fails the regression.
            if (!failed) { continue; }
            const Observation frozen = subject.observation();
            check(results,
                frozen.status == NATravPeerSessionStatus::operation_failed &&
                frozen.classification == "OPERATION_FAILED" && frozen.terminal &&
                frozen.peak_staged_frames <= 1U,
                label, point);
            if (frozen.expected_payload_bytes != 0U &&
                frozen.buffered_bytes == kNATravPeerFrameHeaderBytes +
                    static_cast<std::size_t>(frozen.expected_payload_bytes)) {
                ++results.complete_frame_faults;
            }
            if (frozen.frames_observed != 0U || frozen.messages_decoded != 0U ||
                frozen.handshake_transitions != 0U) {
                ++results.partial_progress_faults;
            }
            for (const Operation subsequent : {Operation::feed, Operation::finish,
                    Operation::timeout, Operation::early_eof,
                    Operation::spawn_failure, Operation::observe}) {
                ++results.quiescence_checks;
                bool snapshot_result_exact = true;
                if (persistent) {
                    arm(0U, true);
                    try {
                        invoke(subject, subsequent, replay);
                    } catch (const InjectedBadAlloc&) {
                        ++results.persistent_snapshot_throws;
                    } catch (...) {
                        snapshot_result_exact = false;
                    }
                    disarm();
                } else {
                    invoke(subject, subsequent, replay);
                }
                const bool unchanged = snapshot_result_exact &&
                    subject.operation_failed() &&
                    equal(subject.observation(), frozen);
                if (unchanged) { ++results.quiescence_verified; }
                check(results, unchanged, label, point);
            }
        }
    }
}

int run() {
    static_assert(noexcept(std::declval<const Session&>().operation_failed()));
    Results results;
    const NATravPeerHandshakeMessage reply{
        .kind = NATravPeerHandshakeMessageKind::hello_ack,
        .protocol = {.id = "NATRAV_OVERLAY_PEER", .major = 1U, .minor = 0U},
        .request_id = std::string(64U, '1'),
        .artifact = {.sha256 = std::string(64U, 'b'),
            .target = "x86_64-unknown-linux-gnu", .version = "0.1.0"},
        .required_capabilities = {},
        .available_capabilities = {"PING", "STATUS"},
        .error_code = {}, .error_message = {},
    };
    const NATravPeerHandshakeExpectation expectation{
        .protocol = reply.protocol, .request_id = reply.request_id,
        .expected_artifact = reply.artifact,
        .required_capabilities = reply.available_capabilities,
    };
    const auto encoded = natrav_peer_encode_message(reply);
    if (!encoded.payload.has_value()) { return 2; }
    const Octets frame = natrav_peer_encode_frame(*encoded.payload);
    check(results, frame.size() == 350U, "canonical_frame", 0U);
    Session fresh(expectation);
    run_case(results, fresh, {}, Operation::feed, true, "empty_feed", frame);
    run_case(results, fresh, OctetView(frame).first(1U), Operation::feed,
             true, "partial_header", frame);
    run_case(results, fresh, OctetView(frame).first(4U), Operation::feed,
             true, "complete_header", frame);
    // All 351 boundary positions, including empty first/second pieces.
    for (std::size_t split = 0U; split <= frame.size(); ++split) {
        Session seed(expectation);
        static_cast<void>(seed.feed(OctetView(frame).first(split)));
        run_case(results, seed, OctetView(frame).subspan(split), Operation::feed,
                 true, "split_response", frame);
    }
    Octets coalesced = frame;
    append_octets(coalesced, frame);
    append_octets(coalesced, OctetView(frame).first(3U));
    run_case(results, fresh, coalesced, Operation::feed,
             true, "replay_and_partial_header", frame);
    const Octets malformed_header{0U, 0U, 0U, 1U};
    const Octets malformed_json = natrav_peer_encode_frame(text_octets("xx"));
    const Octets schema_error = natrav_peer_encode_frame(text_octets("{}"));
    for (const Octets* const bytes : {&malformed_header, &malformed_json, &schema_error}) {
        run_case(results, fresh, *bytes, Operation::feed, true, "rejection", frame);
    }
    // Feed allocation failures after a protocol error while draining framing.
    Octets fatal_then_frame = schema_error;
    append_octets(fatal_then_frame, frame);
    run_case(results, fresh, fatal_then_frame, Operation::feed,
             true, "fatal_then_drain", frame);
    const Octets maximum_payload(kNATravPeerMaximumPayloadBytes, 'x');
    const Octets maximum_frame = natrav_peer_encode_frame(maximum_payload);
    run_case(results, fresh, maximum_frame, Operation::feed,
             true, "maximum_payload", frame);
    auto error = reply;
    error.kind = NATravPeerHandshakeMessageKind::error;
    error.artifact = {};
    error.available_capabilities.clear();
    error.error_code = "PEER_UNAVAILABLE";
    error.error_message = std::string(256U, 'e');
    const auto encoded_error = natrav_peer_encode_message(error);
    check(results, encoded_error.payload.has_value(), "peer_error_encoding", 0U);
    if (encoded_error.payload.has_value()) {
        const Octets error_frame = natrav_peer_encode_frame(*encoded_error.payload);
        run_case(results, fresh, error_frame, Operation::feed,
                 true, "peer_error", frame);
    }
    Session partial(expectation);
    static_cast<void>(partial.feed(OctetView(frame).first(33U)));
    Session accepted(expectation);
    static_cast<void>(accepted.feed(frame));
    for (const Session* const seed : {&fresh, &partial, &accepted}) {
        for (const Operation operation : {Operation::finish, Operation::timeout,
                Operation::early_eof, Operation::spawn_failure}) {
            run_case(results, *seed, {}, operation, true, "closure", frame);
        }
        run_case(results, *seed, {}, Operation::observe,
                 false, "read_only_snapshot", frame);
    }
    Session closed(partial);
    static_cast<void>(closed.finish());
    Session fatal(expectation);
    static_cast<void>(fatal.feed(schema_error));
    for (const Session* const seed : {&closed, &fatal}) {
        for (const Operation operation : {Operation::feed, Operation::finish,
                Operation::timeout, Operation::early_eof,
                Operation::spawn_failure, Operation::observe}) {
            run_case(results, *seed, frame, operation,
                     false, "already_quiescent", frame);
        }
    }
    check(results,
        natrav_peer_session_status_name(NATravPeerSessionStatus::operation_failed) ==
            "OPERATION_FAILED" &&
        natrav_peer_client_exchange_status_name(
            NATravPeerClientExchangeStatus::operation_failed) == "OPERATION_FAILED",
        "status_names", 0U);
    check(results, results.complete_frame_faults > 0U &&
        results.partial_progress_faults > 0U, "fault_stage_coverage", 0U);
    std::printf("scenarios=%zu\nallocation_points=%zu\nfaults=%zu\n"
        "original_exceptions=%zu\nactive_faults=%zu\nlatched_faults=%zu\n"
        "read_only_faults=%zu\nread_only_unchanged=%zu\nno_allocation_queries=%zu\n"
        "quiescence_checks=%zu\nquiescence_verified=%zu\n"
        "persistent_snapshot_throws=%zu\ncomplete_frame_faults=%zu\n"
        "partial_progress_faults=%zu\nfailures=%zu\n",
        results.scenarios, results.allocation_points, results.faults,
        results.original_exceptions, results.active_faults, results.latched_faults,
        results.read_only_faults, results.read_only_unchanged,
        results.no_allocation_queries, results.quiescence_checks,
        results.quiescence_verified, results.persistent_snapshot_throws,
        results.complete_frame_faults, results.partial_progress_faults,
        results.failures);
    return results.failures == 0U ? 0 : 1;
}
}  // namespace natrav_allocation_test

int main() {
    try {
        return natrav_allocation_test::run();
    } catch (const std::exception& error) {
        natrav_allocation_test::disarm();
        std::fprintf(stderr, "allocation regression aborted: %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_SESSION_ALLOCATION_FAILURE_TEST

#ifdef DATACUBE_NATRAV_EXCHANGE_ALLOCATION_FAILURE_TEST
#include <array>

namespace natrav_exchange_allocation_test {
using namespace datacube;
using natrav_allocation_test::arm;
using natrav_allocation_test::disarm;
using natrav_allocation_test::fault;
using natrav_allocation_test::InjectedBadAlloc;
using Exchange = NATravPeerClientHandshakeExchange;
using Observation = NATravPeerClientExchangeObservation;
using Status = NATravPeerClientExchangeStatus;
using Kind = NATravPeerTransportReportKind;
enum class Operation { write, feed, finish, timeout, early_eof, spawn_failure, observe };
constexpr std::array operations{Operation::write, Operation::feed, Operation::finish,
    Operation::timeout, Operation::early_eof, Operation::spawn_failure, Operation::observe};
enum class Prime { fresh, partial_write, waiting, buffered, accepted, replayed,
    closed, closed_partial, closed_accepted, fatal_report, fatal_session, inert };
enum class Damage { none, exchange, transport, process, kind, binding, ordinal,
    request_offset, response_offset };
struct Report final {
    Digest32 exchange{}, transport{}, process{}, binding{};
    Kind kind{Kind::write};
    std::size_t ordinal{0U}, request_offset{0U}, response_offset{0U};
    OctetView bytes{};
};
Kind kind_for(const Operation operation) {
    switch (operation) {
        case Operation::write: return Kind::write;
        case Operation::feed: return Kind::response_chunk;
        case Operation::finish: return Kind::response_finish;
        case Operation::timeout: return Kind::timeout;
        case Operation::early_eof: return Kind::early_eof;
        case Operation::spawn_failure: return Kind::spawn_failure;
        case Operation::observe: return Kind::write;
    }
    return Kind::write;
}
Report report_for(const Exchange& subject, const Operation operation,
                  const OctetView bytes = {}) {
    return {subject.exchange_binding_sha256().value_or(Digest32{}),
        subject.transport_binding_sha256().value_or(Digest32{}),
        subject.process_binding_sha256().value_or(Digest32{}),
        subject.report_binding_sha256().value_or(Digest32{}), kind_for(operation),
        subject.next_report_ordinal().value_or(0U),
        subject.pending_request_offset().value_or(0U),
        subject.next_response_offset().value_or(0U), bytes};
}
void damage(Report& report, const Damage how) {
    switch (how) {
        case Damage::none: return;
        case Damage::exchange: report.exchange.octets[0] ^= 1U; return;
        case Damage::transport: report.transport.octets[0] ^= 1U; return;
        case Damage::process: report.process.octets[0] ^= 1U; return;
        case Damage::kind:
            report.kind = report.kind == Kind::write ? Kind::response_chunk : Kind::write;
            return;
        case Damage::binding: report.binding.octets[0] ^= 1U; return;
        case Damage::ordinal: ++report.ordinal; return;
        case Damage::request_offset: ++report.request_offset; return;
        case Damage::response_offset: ++report.response_offset; return;
    }
}
Observation invoke(Exchange& subject, const Operation operation, const Report& r) {
    switch (operation) {
        case Operation::write:
            return subject.observe_write(r.exchange, r.transport, r.process, r.kind,
                r.binding, r.ordinal, r.request_offset, r.response_offset, r.bytes);
        case Operation::feed:
            return subject.feed_response(r.exchange, r.transport, r.process, r.kind,
                r.binding, r.ordinal, r.request_offset, r.response_offset, r.bytes);
        case Operation::finish:
            return subject.finish_response(r.exchange, r.transport, r.process, r.kind,
                r.binding, r.ordinal, r.request_offset, r.response_offset);
        case Operation::timeout:
        case Operation::early_eof:
        case Operation::spawn_failure:
            return subject.observe_unavailability(r.exchange, r.transport, r.process, r.kind,
                r.binding, r.ordinal, r.request_offset, r.response_offset,
                operation == Operation::timeout ? NATravPeerHandshakeEvent::timeout :
                operation == Operation::early_eof ? NATravPeerHandshakeEvent::early_eof :
                    NATravPeerHandshakeEvent::spawn_failure);
        case Operation::observe: return subject.observation();
    }
    return subject.observation();
}
struct Fixture final {
    NATravPeerPreparedClientHandshake prepared;
    Octets response;
};
Exchange seed(const Fixture& fixture, const Prime prime, const std::size_t split) {
    auto owner = Exchange::create(fixture.prepared, Digest32{}, Digest32{}, Digest32{});
    if (!owner) { throw std::runtime_error("test factory refused valid plan"); }
    Exchange subject(std::move(*owner));
    if (prime == Prime::inert) {
        Exchange moved(std::move(subject));
        return subject;
    }
    if (prime == Prime::fresh) { return subject; }
    const OctetView request(fixture.prepared.frame);
    static_cast<void>(invoke(subject, Operation::write, report_for(subject, Operation::write,
        prime == Prime::partial_write ? request.first(split) : request)));
    if (prime == Prime::partial_write || prime == Prime::waiting) { return subject; }
    if (prime == Prime::buffered || prime == Prime::closed_partial) {
        static_cast<void>(invoke(subject, Operation::feed,
            report_for(subject, Operation::feed, OctetView(fixture.response).first(split))));
    } else if (prime == Prime::accepted || prime == Prime::closed_accepted ||
               prime == Prime::replayed) {
        static_cast<void>(invoke(subject, Operation::feed,
            report_for(subject, Operation::feed, fixture.response)));
        if (prime == Prime::replayed) {
            static_cast<void>(invoke(subject, Operation::feed,
                report_for(subject, Operation::feed, fixture.response)));
        }
    } else if (prime == Prime::fatal_session) {
        const Octets malformed{0U, 0U, 0U, 2U, '{', '}'};
        static_cast<void>(invoke(subject, Operation::feed,
            report_for(subject, Operation::feed, malformed)));
    } else if (prime == Prime::fatal_report) {
        Report report = report_for(subject, Operation::feed);
        damage(report, Damage::exchange);
        static_cast<void>(invoke(subject, Operation::feed, report));
    }
    if (prime == Prime::closed || prime == Prime::closed_partial ||
        prime == Prime::closed_accepted) {
        static_cast<void>(invoke(subject, Operation::finish,
            report_for(subject, Operation::finish)));
    }
    return subject;
}
struct Snapshot final {
    Observation observation;
    std::array<std::optional<Digest32>, 4U> bindings;
    std::array<std::optional<std::size_t>, 3U> coordinates;
    std::array<std::optional<bool>, 9U> flags;
    std::optional<Octets> pending;
    bool operator==(const Snapshot&) const = default;
};
Snapshot snapshot(const Exchange& subject) {
    const auto pending = subject.pending_request_bytes();
    return {subject.observation(), {subject.exchange_binding_sha256(),
        subject.transport_binding_sha256(), subject.process_binding_sha256(),
        subject.report_binding_sha256()}, {subject.pending_request_offset(),
        subject.next_response_offset(), subject.next_report_ordinal()},
        {subject.binding_bundle_constructed(), subject.lifecycle_state_constructed(),
        subject.report_coordinate_state_constructed(), subject.report_accounting_state_constructed(),
        subject.operation_accounting_state_constructed(), subject.verified_plan_state_constructed(),
        subject.request_frame_constructed(), subject.response_session_constructed(),
        subject.operation_failed()},
        pending ? std::optional<Octets>{Octets(pending->begin(), pending->end())} : std::nullopt};
}
struct Results final {
    std::size_t scenarios{}, allocation_points{}, faults{}, original_exceptions{};
    std::size_t active_faults{}, latched_faults{}, readonly_faults{}, readonly_unchanged{};
    std::size_t query_checks{}, quiescence_checks{}, quiescence_verified{}, snapshot_throws{};
    std::size_t move_checks{}, move_verified{}, inert_checks{}, success_boundaries{};
    std::size_t inner_failures{}, outer_only_failures{}, committed_response_faults{};
    std::array<std::size_t, 7U> faults_by_operation{};
    std::size_t failures{};
};
void check(Results& result, const bool exact, const char* label, const std::size_t point) {
    if (exact) { return; }
    ++result.failures;
    if (result.failures <= 12U) {
        std::printf("FAIL label=%s allocation=%zu\n", label, point);
    }
}
void inert_checks(Results& result, Exchange& subject, const Fixture& fixture,
                  const std::size_t point) {
    const Snapshot before = snapshot(subject);
    check(result, !subject.operation_failed().has_value() &&
        !before.observation.prepared_plan_binding_verified, "inert_absence", point);
    for (const Operation operation : operations) {
        const Report report = report_for(subject, operation, fixture.response);
        static_cast<void>(invoke(subject, operation, report));
        ++result.inert_checks;
        check(result, snapshot(subject) == before, "inert_quiescence", point);
    }
}
void moves(Results& result, Exchange& subject, const Snapshot& frozen,
           const Fixture& fixture, const std::size_t point) {
    // Arm even moves: all ownership changes must be allocation-free.
    arm(0U, true);
    Exchange moved(std::move(subject));
    const bool construct_noalloc = fault.attempts == 0U;
    disarm();
    ++result.move_checks;
    const bool exact_construct = construct_noalloc && snapshot(moved) == frozen;
    result.move_verified += exact_construct ? 1U : 0U;
    check(result, exact_construct, "move_construction", point);
    inert_checks(result, subject, fixture, point);
    arm(0U, true);
    Exchange* alias = &moved;
    Exchange& self_result = (moved = std::move(*alias));
    const bool self_noalloc = fault.attempts == 0U;
    disarm();
    ++result.move_checks;
    const bool exact_self = self_noalloc && &self_result == &moved && snapshot(moved) == frozen;
    result.move_verified += exact_self ? 1U : 0U;
    check(result, exact_self, "self_move", point);
    Exchange destination = seed(fixture, Prime::buffered, 33U);
    arm(0U, true);
    Exchange& assigned = (destination = std::move(moved));
    const bool assign_noalloc = fault.attempts == 0U;
    disarm();
    ++result.move_checks;
    const bool exact_assign = assign_noalloc && &assigned == &destination && snapshot(destination) == frozen;
    result.move_verified += exact_assign ? 1U : 0U;
    check(result, exact_assign, "live_move_assignment", point);
    inert_checks(result, moved, fixture, point);
    // A failed owner can explicitly be replaced, not resumed.
    Exchange healthy = seed(fixture, Prime::waiting, 0U);
    const Snapshot healthy_before = snapshot(healthy);
    arm(0U, true);
    destination = std::move(healthy);
    const bool replacement_noalloc = fault.attempts == 0U;
    disarm();
    ++result.move_checks;
    const bool replacement = replacement_noalloc && snapshot(destination) == healthy_before &&
        destination.operation_failed() == std::optional<bool>{false};
    result.move_verified += replacement ? 1U : 0U;
    check(result, replacement, "explicit_replacement", point);
}
void run_case(Results& result, const Fixture& fixture, const Prime prime,
    const std::size_t split, const Operation operation, const OctetView bytes,
    const Damage damage_kind, const char* label, const std::optional<Status> expected_status = {}) {
    ++result.scenarios;
    Exchange control = seed(fixture, prime, split);
    const Snapshot before = snapshot(control);
    const bool active = before.observation.prepared_plan_binding_verified &&
        !before.observation.report_processing_terminal.value_or(false) && operation != Operation::observe;
    Report report = report_for(control, operation, bytes);
    damage(report, damage_kind);
    arm(std::numeric_limits<std::size_t>::max(), false);
    static_cast<void>(invoke(control, operation, report));
    const std::size_t points = fault.attempts;
    disarm();
    result.allocation_points += points;
    const Snapshot expected = snapshot(control);
    check(result, !control.operation_failed().value_or(false), "healthy_control", 0U);
    if (expected_status) {
        check(result, expected.observation.status == expected_status, label, 0U);
    }
    for (const bool persistent : {false, true}) {
        for (std::size_t point = 0U; point <= points; ++point) {
            Exchange subject = seed(fixture, prime, split);
            bool threw = false, original = false;
            arm(point, persistent);
            try {
                static_cast<void>(invoke(subject, operation, report));
            } catch (const InjectedBadAlloc& error) {
                threw = true;
                original = error.point == point;
            } catch (...) { threw = true; }
            const std::size_t attempts_before_query = fault.attempts;
            const std::optional<bool> failed = subject.operation_failed();
            const auto exposed = subject.pending_request_bytes();
            const bool query_noalloc = fault.attempts == attempts_before_query;
            ++result.query_checks;
            const auto continuation_fault = fault;
            disarm();
            check(result, query_noalloc, "query_allocated", point);
            if (point == points) {
                ++result.success_boundaries;
                check(result, !threw && snapshot(subject) == expected, "success_boundary", point);
                continue;
            }
            ++result.faults;
            ++result.faults_by_operation[static_cast<std::size_t>(operation)];
            result.original_exceptions += original ? 1U : 0U;
            check(result, threw && original, "original_exception", point);
            if (!active) {
                ++result.readonly_faults;
                const bool unchanged = snapshot(subject) == before;
                result.readonly_unchanged += unchanged ? 1U : 0U;
                check(result, unchanged, "readonly_snapshot", point);
                continue;
            }
            ++result.active_faults;
            if (failed != std::optional<bool>{true}) {
                check(result, false, "missing_exchange_latch", point);
                // Never reenter an unlatched mutation diagnostic.
                continue;
            }
            ++result.latched_faults;
            const Snapshot frozen = snapshot(subject);
            check(result, exposed.has_value() && exposed->empty() &&
                frozen.observation.status == std::optional<Status>{Status::operation_failed} &&
                frozen.observation.classification == std::optional<std::string>{"OPERATION_FAILED"} &&
                frozen.observation.report_processing_terminal == std::optional<bool>{true} &&
                frozen.observation.terminal == std::optional<bool>{true}, "failed_snapshot", point);
            const bool inner_failed = frozen.observation.response_session_status ==
                std::optional<NATravPeerSessionStatus>{NATravPeerSessionStatus::operation_failed};
            result.inner_failures += inner_failed ? 1U : 0U;
            result.outer_only_failures += inner_failed ? 0U : 1U;
            result.committed_response_faults +=
                frozen.observation.response_frames_observed.value_or(0U) >
                    before.observation.response_frames_observed.value_or(0U) ? 1U : 0U;
            auto continuing = continuation_fault;
            for (const Operation probe : operations) {
                const Report probe_report = report_for(subject, probe, fixture.response);
                fault = continuing;
                bool snapshot_threw = false;
                try {
                    static_cast<void>(invoke(subject, probe, probe_report));
                } catch (const InjectedBadAlloc&) { snapshot_threw = true; }
                catch (...) {
                    disarm(); check(result, false, "wrong_quiescent_exception", point);
                }
                const std::size_t query_start = fault.attempts;
                const auto query = subject.operation_failed();
                const bool noalloc = query_start == fault.attempts;
                continuing = fault;
                disarm();
                ++result.quiescence_checks;
                result.snapshot_throws += snapshot_threw ? 1U : 0U;
                const bool exact = snapshot(subject) == frozen && noalloc && query == failed &&
                    snapshot_threw == persistent;
                result.quiescence_verified += exact ? 1U : 0U;
                check(result, exact, "post_failure_quiescence", point);
            }
            moves(result, subject, frozen, fixture, point);
        }
    }
}
int run() {
    static_assert(noexcept(std::declval<const Exchange&>().operation_failed()));
    static_assert(std::is_same_v<decltype(std::declval<const Exchange&>().operation_failed()),
        std::optional<bool>>);
    static_assert(std::is_nothrow_move_constructible_v<Exchange>);
    static_assert(std::is_nothrow_move_assignable_v<Exchange>);
    Results result;
    const NATravPeerHandshakeMessage reply{
        .kind = NATravPeerHandshakeMessageKind::hello_ack,
        .protocol = {.id = "NATRAV_OVERLAY_PEER", .major = 1U, .minor = 0U},
        .request_id = std::string(64U, '1'),
        .artifact = {.sha256 = std::string(64U, 'b'),
            .target = "x86_64-unknown-linux-gnu", .version = "0.1.0"},
        .required_capabilities = {}, .available_capabilities = {"PING", "STATUS"},
        .error_code = {}, .error_message = {},
    };
    const auto prepared = natrav_peer_prepare_client_handshake({reply.protocol, reply.request_id,
        {.sha256 = std::string(64U, 'a'), .target = reply.artifact.target,
         .version = reply.artifact.version}, reply.artifact, reply.available_capabilities});
    const auto encoded = natrav_peer_encode_message(reply);
    if (!prepared.prepared || !encoded.payload) { return 2; }
    const Fixture fixture{*prepared.prepared, natrav_peer_encode_frame(*encoded.payload)};
    const OctetView request(fixture.prepared.frame), response(fixture.response);
    check(result, response.size() == 350U, "response_frame_size", 0U);
    // Every request and response split, including empty reports and both endpoints.
    for (std::size_t split = 0U; split <= request.size(); ++split) {
        run_case(result, fixture, Prime::fresh, 0U, Operation::write, request.first(split),
            Damage::none, "partial_write");
        run_case(result, fixture, Prime::partial_write, split, Operation::write, request.subspan(split),
            Damage::none, "write_suffix");
    }
    for (std::size_t split = 0U; split <= response.size(); ++split) {
        run_case(result, fixture, Prime::buffered, split, Operation::feed, response.subspan(split),
            Damage::none, "response_split");
    }
    const Octets malformed_header{0U, 0U, 0U, 1U};
    const Octets schema_error = natrav_peer_encode_frame(text_octets("{}"));
    const Octets malformed_json = natrav_peer_encode_frame(text_octets("xx"));
    const Octets maximum = natrav_peer_encode_frame(Octets(kNATravPeerMaximumPayloadBytes, 'x'));
    Octets replay = fixture.response;
    append_octets(replay, fixture.response);
    append_octets(replay, response.first(3U));
    for (const Octets* bytes : std::array<const Octets*, 5U>{&malformed_header, &schema_error, &malformed_json, &maximum, &replay}) {
        run_case(result, fixture, Prime::waiting, 0U, Operation::feed, *bytes,
            Damage::none, "response_diagnostic");
    }
    Octets wrong_write = fixture.prepared.frame;
    wrong_write[0] ^= 1U;
    Octets overlong = fixture.prepared.frame;
    overlong.push_back(0U);
    run_case(result, fixture, Prime::fresh, 0U, Operation::write, wrong_write,
        Damage::none, "write_segment", Status::write_segment_rejected);
    run_case(result, fixture, Prime::fresh, 0U, Operation::write, overlong,
        Damage::none, "write_progress", Status::write_progress_rejected);
    constexpr std::array damages{Damage::exchange, Damage::transport, Damage::process,
        Damage::kind, Damage::binding, Damage::ordinal, Damage::request_offset, Damage::response_offset};
    constexpr std::array statuses{Status::exchange_binding_rejected, Status::transport_binding_rejected,
        Status::process_binding_rejected, Status::report_kind_rejected, Status::report_binding_rejected,
        Status::report_ordinal_rejected};
    for (const Operation operation : operations) {
        if (operation == Operation::observe) { continue; }
        for (std::size_t index = 0U; index < damages.size(); ++index) {
            std::optional<Status> expected;
            if (index < statuses.size()) { expected = statuses[index]; }
            const Prime prime = operation == Operation::write || operation == Operation::spawn_failure ?
                Prime::fresh : Prime::waiting;
            run_case(result, fixture, prime, 0U, operation,
                operation == Operation::write ? request : response, damages[index],
                "report_gate", expected);
        }
    }
    constexpr std::array primes{Prime::fresh, Prime::partial_write, Prime::waiting, Prime::buffered,
        Prime::accepted, Prime::replayed, Prime::closed, Prime::closed_partial, Prime::closed_accepted,
        Prime::fatal_report, Prime::fatal_session, Prime::inert};
    for (const Prime prime : primes) {
        for (const Operation operation : operations) {
            run_case(result, fixture, prime, 33U, operation,
                operation == Operation::write ? request : response, Damage::none, "lifecycle");
        }
    }
    check(result, result.inner_failures > 0U && result.outer_only_failures > 0U &&
        result.committed_response_faults > 0U && result.readonly_faults > 0U &&
        result.active_faults == result.latched_faults, "coverage", 0U);
    for (std::size_t index = 0U; index < result.faults_by_operation.size(); ++index) {
        check(result, result.faults_by_operation[index] > 0U, "operation_fault_coverage", index);
    }
    std::printf("scenarios=%zu\nrequest_frame_bytes=%zu\nresponse_frame_bytes=%zu\n"
        "allocation_points=%zu\nfaults=%zu\noriginal_exceptions=%zu\n"
        "active_faults=%zu\nlatched_faults=%zu\nreadonly_faults=%zu\nreadonly_unchanged=%zu\n"
        "query_checks=%zu\nquiescence_checks=%zu\nquiescence_verified=%zu\nsnapshot_throws=%zu\n"
        "move_checks=%zu\nmove_verified=%zu\ninert_checks=%zu\nsuccess_boundaries=%zu\n"
        "inner_failures=%zu\nouter_only_failures=%zu\ncommitted_response_faults=%zu\n",
        result.scenarios, request.size(), response.size(), result.allocation_points,
        result.faults, result.original_exceptions, result.active_faults, result.latched_faults,
        result.readonly_faults, result.readonly_unchanged, result.query_checks,
        result.quiescence_checks, result.quiescence_verified, result.snapshot_throws,
        result.move_checks, result.move_verified, result.inert_checks, result.success_boundaries,
        result.inner_failures, result.outer_only_failures, result.committed_response_faults);
    for (std::size_t index = 0U; index < result.faults_by_operation.size(); ++index) {
        std::printf("operation_%zu_faults=%zu\n", index, result.faults_by_operation[index]);
    }
    std::printf("failures=%zu\n", result.failures);
    return result.failures == 0U ? 0 : 1;
}
}  // namespace natrav_exchange_allocation_test
int main() {
    try { return natrav_exchange_allocation_test::run(); }
    catch (const std::exception& error) {
        natrav_allocation_test::disarm();
        std::fprintf(stderr, "exchange allocation regression aborted: %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_EXCHANGE_ALLOCATION_FAILURE_TEST

#ifdef DATACUBE_NATRAV_STREAM_ALLOCATION_FAILURE_TEST
// Test-only historical algorithm: a byte-for-byte method-body copy from
// revision 0461, except for its class name. It supplies a normal-path oracle
// and an explicit reproduction of the old complete-buffer EOF defect.
namespace natrav_stream_allocation_test {
using namespace datacube;
using natrav_allocation_test::arm;
using natrav_allocation_test::disarm;
using natrav_allocation_test::fault;
using natrav_allocation_test::InjectedBadAlloc;
using Decoder = NATravPeerStreamDecoder;
using Observation = NATravPeerStreamObservation;
using Status = NATravPeerStreamStatus;
using Output = std::vector<Octets>;
class LegacyDecoder final {
public:
    [[nodiscard]] Observation feed(OctetView, Output&);
    [[nodiscard]] Observation finish(Output&);
    [[nodiscard]] bool terminal() const noexcept;
    [[nodiscard]] std::size_t buffered_bytes() const noexcept;
    [[nodiscard]] std::uint32_t expected_payload_bytes() const noexcept;
private:
    [[nodiscard]] Observation observe(Status, std::size_t) const noexcept;
    Octets buffered_;
    std::uint32_t expected_payload_bytes_{0U};
    bool expected_payload_known_{false};
    bool terminal_{false};
    Status terminal_status_{Status::need_more};
};
[[nodiscard]] std::uint32_t decode_u32be_header(const OctetView header) noexcept {
    return (static_cast<std::uint32_t>(header[0]) << 24U) |
        (static_cast<std::uint32_t>(header[1]) << 16U) |
        (static_cast<std::uint32_t>(header[2]) << 8U) |
        static_cast<std::uint32_t>(header[3]);
}
NATravPeerStreamObservation LegacyDecoder::observe(
    const NATravPeerStreamStatus status,
    const std::size_t emitted_frames) const noexcept {
    return NATravPeerStreamObservation{
        .status = status,
        .emitted_frames = emitted_frames,
        .buffered_bytes = buffered_.size(),
        .expected_payload_bytes =
            expected_payload_known_ ? expected_payload_bytes_ : 0U,
    };
}

NATravPeerStreamObservation LegacyDecoder::feed(
    const OctetView chunk,
    std::vector<Octets>& emitted) {
    const std::size_t emitted_before = emitted.size();
    if (terminal_) {
        return observe(terminal_status_, 0U);
    }

    std::size_t offset = 0U;
    while (offset < chunk.size()) {
        if (!expected_payload_known_) {
            const std::size_t header_needed =
                kNATravPeerFrameHeaderBytes - buffered_.size();
            const std::size_t header_take = std::min(
                header_needed, chunk.size() - offset);
            buffered_.insert(
                buffered_.end(),
                chunk.begin() + static_cast<std::ptrdiff_t>(offset),
                chunk.begin() + static_cast<std::ptrdiff_t>(offset + header_take));
            offset += header_take;
            if (buffered_.size() < kNATravPeerFrameHeaderBytes) {
                break;
            }
            expected_payload_bytes_ = decode_u32be_header(
                OctetView(buffered_.data(), kNATravPeerFrameHeaderBytes));
            expected_payload_known_ = true;
            if (expected_payload_bytes_ < kNATravPeerMinimumPayloadBytes ||
                expected_payload_bytes_ > kNATravPeerMaximumPayloadBytes) {
                terminal_ = true;
                terminal_status_ = NATravPeerStreamStatus::malformed_frame;
                return observe(
                    terminal_status_, emitted.size() - emitted_before);
            }
        }

        const std::size_t frame_bytes = kNATravPeerFrameHeaderBytes +
            static_cast<std::size_t>(expected_payload_bytes_);
        const std::size_t frame_needed = frame_bytes - buffered_.size();
        const std::size_t frame_take = std::min(
            frame_needed, chunk.size() - offset);
        buffered_.insert(
            buffered_.end(),
            chunk.begin() + static_cast<std::ptrdiff_t>(offset),
            chunk.begin() + static_cast<std::ptrdiff_t>(offset + frame_take));
        offset += frame_take;
        if (buffered_.size() < frame_bytes) {
            break;
        }

        emitted.emplace_back(
            buffered_.begin() +
                static_cast<std::ptrdiff_t>(kNATravPeerFrameHeaderBytes),
            buffered_.end());
        buffered_.clear();
        expected_payload_bytes_ = 0U;
        expected_payload_known_ = false;
    }

    const std::size_t emitted_now = emitted.size() - emitted_before;
    return observe(
        emitted_now == 0U ? NATravPeerStreamStatus::need_more :
                            NATravPeerStreamStatus::frame_ready,
        emitted_now);
}

NATravPeerStreamObservation LegacyDecoder::finish(
    std::vector<Octets>& emitted) {
    if (terminal_) {
        return observe(terminal_status_, 0U);
    }
    const NATravPeerStreamObservation drained = feed(OctetView{}, emitted);
    if (drained.status == NATravPeerStreamStatus::malformed_frame) {
        return drained;
    }
    terminal_ = true;
    terminal_status_ = buffered_.empty() ?
        NATravPeerStreamStatus::stream_closed :
        NATravPeerStreamStatus::peer_unavailable;
    return observe(terminal_status_, 0U);
}

bool LegacyDecoder::terminal() const noexcept {
    return terminal_;
}

std::size_t LegacyDecoder::buffered_bytes() const noexcept {
    return buffered_.size();
}

std::uint32_t LegacyDecoder::expected_payload_bytes() const noexcept {
    return expected_payload_known_ ? expected_payload_bytes_ : 0U;
}

enum class Operation { feed, finish };
struct State final {
    bool terminal;
    bool failed;
    std::size_t buffered;
    std::uint32_t expected;
    bool operator==(const State&) const = default;
};
[[nodiscard]] State state(const Decoder& d) noexcept {
    return {d.terminal(), d.operation_failed(), d.buffered_bytes(),
            d.expected_payload_bytes()};
}
[[nodiscard]] bool equal(const Observation& a, const Observation& b) noexcept {
    return a.status == b.status && a.emitted_frames == b.emitted_frames &&
        a.buffered_bytes == b.buffered_bytes &&
        a.expected_payload_bytes == b.expected_payload_bytes;
}
struct Results final {
    std::size_t scenarios{0U};
    std::size_t normal_comparisons{0U};
    std::size_t allocation_points{0U};
    std::size_t faults{0U};
    std::size_t original_exceptions{0U};
    std::size_t latched_faults{0U};
    std::size_t query_checks{0U};
    std::size_t success_boundaries{0U};
    std::size_t quiescence_checks{0U};
    std::size_t quiescence_verified{0U};
    std::size_t output_prefix_checks{0U};
    std::size_t committed_output_faults{0U};
    std::size_t complete_buffer_faults{0U};
    std::size_t finish_noallocation_checks{0U};
    std::size_t terminal_feed_checks{0U};
    std::size_t oracle_eof_defects{0U};
    std::size_t failures{0U};
};
void check(Results& r, const bool exact, const char* const label,
           const std::size_t point = 0U) {
    if (exact) { return; }
    ++r.failures;
    if (r.failures <= 8U) {
        std::printf("FAIL label=%s scenario=%zu allocation=%zu\n",
                    label, r.scenarios, point);
    }
}
template<class T>
[[nodiscard]] Observation invoke(T& decoder, const Operation op,
                                 const OctetView chunk, Output& output) {
    return op == Operation::feed ? decoder.feed(chunk, output) :
                                  decoder.finish(output);
}
template<class T>
void prime(T& decoder, Output& output, const OctetView prefix,
           const unsigned shape, const bool close) {
    if ((shape & 1U) != 0U) { output.push_back(Octets{91U, 37U, 255U}); }
    if ((shape & 2U) != 0U) { output.reserve(128U); }
    static_cast<void>(decoder.feed(prefix, output));
    if (close) { static_cast<void>(decoder.finish(output)); }
}
void run_case(Results& r, const OctetView prefix, const OctetView chunk,
              const Operation op, const unsigned shape, const bool close,
              const OctetView replay) {
    ++r.scenarios;
    Decoder control;
    Output expected_output;
    prime(control, expected_output, prefix, shape, close);
    const bool initially_terminal = control.terminal();
    const std::size_t initial_output_size = expected_output.size();
    arm(std::numeric_limits<std::size_t>::max(), false);
    const Observation expected = invoke(control, op, chunk, expected_output);
    const std::size_t points = fault.attempts;
    disarm();
    r.allocation_points += points;
    const State expected_state = state(control);
    check(r, !expected_state.failed, "healthy_control");
    if (op == Operation::finish) {
        ++r.finish_noallocation_checks;
        check(r, points == 0U, "finish_noallocation");
    }
    if (initially_terminal && op == Operation::feed) {
        ++r.terminal_feed_checks;
        check(r, points == 0U, "terminal_feed_noallocation");
    }

    LegacyDecoder reference;
    Output reference_output;
    prime(reference, reference_output, prefix, shape, close);
    const Observation reference_observation = invoke(reference, op, chunk, reference_output);
    ++r.normal_comparisons;
    check(r, equal(expected, reference_observation) &&
          reference_output == expected_output &&
          reference.terminal() == expected_state.terminal &&
          reference.buffered_bytes() == expected_state.buffered &&
          reference.expected_payload_bytes() == expected_state.expected,
          "legacy_normal_path");

    for (const bool persistent : {false, true}) {
        for (std::size_t point = 0U; point <= points; ++point) {
            Decoder subject;
            Output output;
            prime(subject, output, prefix, shape, close);
            bool threw = false;
            bool original = false;
            Observation observed;
            arm(point, persistent);
            try { observed = invoke(subject, op, chunk, output); }
            catch (const InjectedBadAlloc& error) {
                threw = true;
                original = error.point == point;
            }
            catch (...) { threw = true; }
            const std::size_t before_query = fault.attempts;
            const State current = state(subject);
            ++r.query_checks;
            const bool query_noallocation = before_query == fault.attempts;
            disarm();
            check(r, query_noallocation, "getter_noallocation", point);
            if (point == points) {
                ++r.success_boundaries;
                check(r, !threw && equal(observed, expected) &&
                    current == expected_state && output == expected_output,
                    "out_of_range_success", point);
                continue;
            }
            ++r.faults;
            if (original) { ++r.original_exceptions; }
            check(r, threw && original, "original_exception", point);
            if (current.failed && current.terminal) { ++r.latched_faults; }
            check(r, current.failed && current.terminal, "failure_latch", point);
            ++r.output_prefix_checks;
            check(r, output.size() >= initial_output_size &&
                output.size() <= expected_output.size() &&
                std::equal(output.begin(), output.end(), expected_output.begin()),
                "committed_output_prefix", point);
            check(r, current.buffered <= kNATravPeerMaximumBufferedFrameBytes,
                  "bounded_buffer", point);
            if (output.size() > initial_output_size) { ++r.committed_output_faults; }
            if (current.expected >= kNATravPeerMinimumPayloadBytes &&
                current.buffered == kNATravPeerFrameHeaderBytes +
                    static_cast<std::size_t>(current.expected)) {
                ++r.complete_buffer_faults;
            }
            // Sensitivity variants must not continue processing an unlatched
            // fault. Observe the missing latch and skip unsafe reentry.
            if (!current.failed || !current.terminal) { continue; }

            const Output frozen = output;
            const Octets* const output_data = output.data();
            const std::size_t output_capacity = output.capacity();
            Output alternate{Octets{53U, 0U, 19U}};
            const Output alternate_frozen = alternate;
            const Octets* const alternate_data = alternate.data();
            const std::size_t alternate_capacity = alternate.capacity();
            const Octets malformed{0U, 0U, 0U, 1U, 42U};
            arm(0U, true);
            for (unsigned probe = 0U; probe < 8U; ++probe) {
                Output& target = probe < 4U ? output : alternate;
                const unsigned action = probe % 4U;
                Observation after;
                bool probe_threw = false;
                try {
                    switch (action) {
                        case 0U: after = subject.feed(OctetView{}, target); break;
                        case 1U: after = subject.feed(replay, target); break;
                        case 2U: after = subject.feed(malformed, target); break;
                        default: after = subject.finish(target); break;
                    }
                } catch (...) { probe_threw = true; }
                const bool exact = !probe_threw && fault.attempts == 0U &&
                    state(subject) == current &&
                    after.status == Status::operation_failed &&
                    after.emitted_frames == 0U &&
                    after.buffered_bytes == current.buffered &&
                    after.expected_payload_bytes == current.expected &&
                    output == frozen && output.data() == output_data &&
                    output.capacity() == output_capacity &&
                    alternate == alternate_frozen && alternate.data() == alternate_data &&
                    alternate.capacity() == alternate_capacity;
                ++r.quiescence_checks;
                if (exact) { ++r.quiescence_verified; }
                // check prints only on failure and does not allocate via new.
                check(r, exact, "failed_decoder_quiescence", point);
            }
            disarm();
        }
    }
}
[[nodiscard]] Octets frame(const std::size_t payload_bytes) {
    Octets payload(payload_bytes);
    for (std::size_t i = 0U; i < payload.size(); ++i) {
        payload[i] = static_cast<std::uint8_t>((i * 73U + 19U) & 255U);
    }
    return natrav_peer_encode_frame(payload);
}
void demonstrate_predecessor(Results& r, const OctetView bytes) {
    LegacyDecoder control;
    Output control_output;
    arm(std::numeric_limits<std::size_t>::max(), false);
    static_cast<void>(control.feed(bytes, control_output));
    const std::size_t points = fault.attempts;
    disarm();
    for (std::size_t point = 0U; point < points; ++point) {
        LegacyDecoder old;
        Output output;
        bool threw = false;
        arm(point, false);
        try { static_cast<void>(old.feed(bytes, output)); }
        catch (const InjectedBadAlloc&) { threw = true; }
        disarm();
        if (threw && !old.terminal() && old.buffered_bytes() == bytes.size()) {
            // Empty feed does not drain; EOF misclassifies a complete frame as
            // a partial/unavailable peer instead of recording operation failure.
            const Observation empty = old.feed(OctetView{}, output);
            const Observation eof = old.finish(output);
            if (output.empty() && empty.status == Status::need_more &&
                eof.status == Status::peer_unavailable) { ++r.oracle_eof_defects; }
        }
    }
}
int run() {
    static_assert(noexcept(std::declval<const Decoder&>().operation_failed()));
    static_assert(noexcept(std::declval<const Decoder&>().terminal()));
    static_assert(noexcept(std::declval<const Decoder&>().buffered_bytes()));
    static_assert(noexcept(std::declval<const Decoder&>().expected_payload_bytes()));
    static_assert(noexcept(std::declval<Decoder&>().finish(std::declval<Output&>())));
    static_assert(static_cast<int>(Status::need_more) == 0);
    static_assert(static_cast<int>(Status::peer_unavailable) == 4);
    static_assert(static_cast<int>(Status::operation_failed) == 5);
    Results r;
    const Octets canonical = frame(346U);
    demonstrate_predecessor(r, canonical);
    for (const unsigned shape : {0U, 1U, 2U, 3U}) {
        for (const std::size_t size : {2U, 3U, 27U, 251U, 346U}) {
            const Octets bytes = frame(size);
            const OctetView view(bytes);
            for (std::size_t split = 0U; split <= bytes.size(); ++split) {
                run_case(r, view.first(split), view.subspan(split), Operation::feed,
                         shape, false, canonical);
                run_case(r, view.first(split), OctetView{}, Operation::finish,
                         shape, false, canonical);
            }
        }
        for (const std::size_t size : {65'535U, 65'536U}) {
            const Octets bytes = frame(size);
            const OctetView view(bytes);
            for (const std::size_t split : {0U, 1U, 2U, 3U, 4U, 5U, 127U, 255U,
                                           256U, 32'768U, 65'535U, 65'536U}) {
                run_case(r, view.first(split), view.subspan(split), Operation::feed,
                         shape, false, canonical);
                run_case(r, view.first(split), OctetView{}, Operation::finish,
                         shape, false, canonical);
            }
            for (std::size_t split = bytes.size() - 2U; split <= bytes.size(); ++split) {
                run_case(r, view.first(split), view.subspan(split), Operation::feed,
                         shape, false, canonical);
                run_case(r, view.first(split), OctetView{}, Operation::finish,
                         shape, false, canonical);
            }
        }
        for (const std::size_t count : {2U, 3U, 17U, 129U}) {
            Octets bytes;
            for (std::size_t i = 0U; i < count; ++i) {
                const Octets next = frame((i % 3U == 0U) ? 2U : 346U);
                bytes.insert(bytes.end(), next.begin(), next.end());
            }
            for (const std::size_t trailing : {0U, 1U, 3U, 4U, 5U, 349U}) {
                Octets trial(bytes);
                trial.insert(trial.end(), canonical.begin(),
                             canonical.begin() + static_cast<std::ptrdiff_t>(trailing));
                run_case(r, OctetView{}, trial, Operation::feed, shape, false, canonical);
                run_case(r, trial, OctetView{}, Operation::finish, shape, false, canonical);
            }
        }
        for (const std::uint32_t invalid : {0U, 1U, 65'537U, 0xFFFFFFFFU}) {
            Octets malformed;
            append_be32(malformed, invalid);
            malformed.push_back(42U);
            for (std::size_t split = 0U; split <= 5U; ++split) {
                const OctetView view(malformed);
                run_case(r, view.first(split), view.subspan(split), Operation::feed,
                         shape, false, canonical);
            }
            Octets after_good(canonical);
            after_good.insert(after_good.end(), malformed.begin(), malformed.end());
            run_case(r, OctetView{}, after_good, Operation::feed, shape, false, canonical);
            run_case(r, malformed, canonical, Operation::feed, shape, false, canonical);
            run_case(r, malformed, OctetView{}, Operation::finish, shape, false, canonical);
        }
        // Healthy closed, incomplete closed, empty feed, and already-malformed
        // owners must remain allocation-free without converting to failure.
        for (const std::size_t prefix : {0U, 1U, 3U, 4U, 5U, 349U, 350U}) {
            const OctetView bytes(canonical);
            run_case(r, bytes.first(prefix), canonical, Operation::feed, shape, true, canonical);
            run_case(r, bytes.first(prefix), OctetView{}, Operation::finish, shape, true, canonical);
            run_case(r, bytes.first(prefix), OctetView{}, Operation::feed, shape, false, canonical);
        }
    }
    check(r, r.faults != 0U && r.faults == r.original_exceptions &&
        r.faults == r.latched_faults && r.faults == r.output_prefix_checks &&
        r.complete_buffer_faults != 0U && r.committed_output_faults != 0U &&
        r.oracle_eof_defects != 0U, "fault_coverage");
    check(r, natrav_peer_stream_status_name(Status::operation_failed) ==
        "OPERATION_FAILED", "status_name");
#define NATRAV_STREAM_PRINT(name) std::printf(#name "=%zu\n", r.name)
    NATRAV_STREAM_PRINT(scenarios);
    NATRAV_STREAM_PRINT(normal_comparisons);
    NATRAV_STREAM_PRINT(allocation_points);
    NATRAV_STREAM_PRINT(faults);
    NATRAV_STREAM_PRINT(original_exceptions);
    NATRAV_STREAM_PRINT(latched_faults);
    NATRAV_STREAM_PRINT(query_checks);
    NATRAV_STREAM_PRINT(success_boundaries);
    NATRAV_STREAM_PRINT(quiescence_checks);
    NATRAV_STREAM_PRINT(quiescence_verified);
    NATRAV_STREAM_PRINT(output_prefix_checks);
    NATRAV_STREAM_PRINT(committed_output_faults);
    NATRAV_STREAM_PRINT(complete_buffer_faults);
    NATRAV_STREAM_PRINT(finish_noallocation_checks);
    NATRAV_STREAM_PRINT(terminal_feed_checks);
    NATRAV_STREAM_PRINT(oracle_eof_defects);
    NATRAV_STREAM_PRINT(failures);
#undef NATRAV_STREAM_PRINT
    return r.failures == 0U ? 0 : 1;
}
}  // namespace natrav_stream_allocation_test
int main() {
    try { return natrav_stream_allocation_test::run(); }
    catch (const std::exception& error) {
        natrav_allocation_test::disarm();
        std::fprintf(stderr, "stream-allocation-test: %s\n", error.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_STREAM_ALLOCATION_FAILURE_TEST

#ifdef DATACUBE_NATRAV_STREAM_LIFECYCLE_TEST
// Local ownership/exception regression. The injector is shared with the three
// opt-in allocation suites above and is never enabled by the runtime manifest.
namespace natrav_stream_lifecycle_test {
using namespace datacube;
using natrav_allocation_test::arm;
using natrav_allocation_test::disarm;
using natrav_allocation_test::fault;
using natrav_allocation_test::InjectedBadAlloc;
using Decoder = NATravPeerStreamDecoder;
using Status = NATravPeerStreamStatus;
using Observation = NATravPeerStreamObservation;
using Output = std::vector<Octets>;
struct Results {
    std::size_t seeds{}, move_constructions{}, copy_constructions{};
    std::size_t move_assignments{}, copy_assignments{}, swaps{}, self_operations{};
    std::size_t faults{}, original_exceptions{}, strong_guarantee_checks{};
    std::size_t inert_probes{}, noallocation_checks{}, continuation_checks{};
    std::size_t failed_seeds{}, moved_from_seeds{}, success_boundaries{}, failures{};
};
void check(Results& r, const bool good, const char* label) {
    if (good) { return; }
    ++r.failures;
    if (r.failures <= 12U) { std::fprintf(stderr, "FAILED %s\n", label); }
}
[[nodiscard]] bool same(const Observation& a, const Observation& b) noexcept {
    return a.status == b.status && a.emitted_frames == b.emitted_frames &&
        a.buffered_bytes == b.buffered_bytes &&
        a.expected_payload_bytes == b.expected_payload_bytes;
}
struct Snapshot {
    Observation observation;
    bool terminal, failed, moved;
};
[[nodiscard]] Snapshot snapshot(Decoder& decoder) {
    Output none;
    return {decoder.feed(OctetView{}, none), decoder.terminal(),
            decoder.operation_failed(), decoder.moved_from()};
}
[[nodiscard]] bool same(const Snapshot& a, const Snapshot& b) noexcept {
    return same(a.observation, b.observation) && a.terminal == b.terminal &&
        a.failed == b.failed && a.moved == b.moved;
}
void noallocation(Results& r, const char* label) {
    ++r.noallocation_checks;
    check(r, fault.attempts == 0U, label);
}
[[nodiscard]] Octets frame(const std::size_t bytes) {
    Octets payload(bytes);
    for (std::size_t i = 0U; i < bytes; ++i) {
        payload[i] = static_cast<std::uint8_t>((i * 47U + bytes * 19U) & 255U);
    }
    return natrav_peer_encode_frame(payload);
}
// Compare continuation, not only scalars: this checks exact buffered-byte
// ownership and deep-copy independence without exposing a private byte view.
void continuation(Results& r, Decoder actual, Decoder reference,
                  const OctetView suffix, const OctetView next) {
    Output a{Octets{17U, 23U}}, b(a);
    const std::size_t mid = suffix.size() / 2U;
    for (const OctetView chunk : {suffix.first(mid), suffix.subspan(mid), next}) {
        const Observation ao = actual.feed(chunk, a);
        const Observation bo = reference.feed(chunk, b);
        ++r.continuation_checks;
        check(r, same(ao, bo) && a == b && same(snapshot(actual), snapshot(reference)),
              "byte_exact_continuation");
    }
    const Observation ao = actual.finish(a), bo = reference.finish(b);
    ++r.continuation_checks;
    check(r, same(ao, bo) && a == b && same(snapshot(actual), snapshot(reference)),
          "byte_exact_eof");
}
// The output storage, not merely the payload count, must remain untouched.
void inert(Results& r, Decoder& decoder, const OctetView next) {
    const Snapshot s = snapshot(decoder);
    const bool canonical = s.moved && s.terminal && !s.failed &&
        s.observation.status == Status::moved_from &&
        s.observation.buffered_bytes == 0U &&
        s.observation.expected_payload_bytes == 0U;
    check(r, canonical, "moved_from_invariant");
    // A deliberately broken diagnostic build must not feed an inconsistent
    // active decoder after the invariant check has already found the defect.
    if (!canonical) { return; }
    for (const bool prefilled : {false, true}) {
        Output out;
        if (prefilled) { out.push_back(Octets{11U, 13U, 17U}); out.reserve(7U); }
        const Output before(out);
        const auto* storage = out.data();
        const auto capacity = out.capacity();
        const auto* payload_storage = out.empty() ? nullptr : out.front().data();
        arm(0U, true);
        for (const unsigned op : {0U, 1U, 2U, 3U}) {
            const Observation result = op == 3U ? decoder.finish(out) :
                decoder.feed(op == 0U ? OctetView{} :
                             op == 1U ? next.first(1U) : next, out);
            ++r.inert_probes;
            check(r, result.status == Status::moved_from &&
                  result.emitted_frames == 0U && out == before &&
                  out.data() == storage && out.capacity() == capacity &&
                  (out.empty() ? nullptr : out.front().data()) == payload_storage &&
                  same(snapshot(decoder), s), "inert_output_and_state");
        }
        noallocation(r, "inert_allocated");
        disarm();
    }
}
struct Seed {
    Decoder decoder;
    Octets suffix;
};
[[nodiscard]] std::vector<Seed> seeds(Results& r, const Octets& canonical) {
    std::vector<Seed> all;
    auto add = [&](const Octets& bytes, const std::size_t split, const bool close) {
        Decoder decoder;
        Output out;
        static_cast<void>(decoder.feed(OctetView(bytes).first(split), out));
        if (close) { static_cast<void>(decoder.finish(out)); }
        all.push_back({std::move(decoder), Octets(bytes.begin() +
            static_cast<std::ptrdiff_t>(split), bytes.end())});
    };
    for (const std::size_t size : {2U, 3U, 27U, 251U, 346U}) {
        const Octets bytes = frame(size);
        for (std::size_t split = 0U; split <= bytes.size(); ++split) {
            add(bytes, split, false); add(bytes, split, true);
        }
    }
    for (const std::size_t size : {65'535U, 65'536U}) {
        const Octets bytes = frame(size);
        for (const std::size_t split : {0U, 1U, 2U, 3U, 4U, 5U, 127U, 256U,
                                       32'768U, 65'535U, 65'536U}) {
            add(bytes, split, false); add(bytes, split, true);
        }
        for (std::size_t split = bytes.size() - 2U; split <= bytes.size(); ++split) {
            add(bytes, split, false); add(bytes, split, true);
        }
    }
    for (const std::uint32_t length : {0U, 1U, 65'537U, 0xFFFFFFFFU}) {
        Octets bytes;
        append_be32(bytes, length);
        add(bytes, bytes.size(), false);
    }
    Octets coalesced(canonical);
    coalesced.insert(coalesced.end(), canonical.begin(), canonical.end());
    coalesced.insert(coalesced.end(), canonical.begin(), canonical.begin() + 7);
    for (const std::size_t split : {349U, 350U, 351U, 353U, 354U, 699U, 700U, 707U}) {
        add(coalesced, split, false); add(coalesced, split, true);
    }
    Decoder control;
    Output control_output;
    arm(std::numeric_limits<std::size_t>::max(), false);
    static_cast<void>(control.feed(coalesced, control_output));
    const std::size_t points = fault.attempts;
    disarm();
    for (std::size_t point = 0U; point < points; ++point) {
        Decoder failed;
        Output out;
        bool caught = false;
        arm(point, true);
        try { static_cast<void>(failed.feed(coalesced, out)); }
        catch (const InjectedBadAlloc& e) { caught = e.point == point; }
        disarm();
        check(r, caught && failed.operation_failed(), "failed_seed");
        ++r.failed_seeds;
        all.push_back({std::move(failed), canonical});
    }
    Decoder donor;
    Output out;
    static_cast<void>(donor.feed(OctetView(canonical).first(7U), out));
    Decoder owner(std::move(donor));
    static_cast<void>(owner);
    all.push_back({std::move(donor), canonical});
    ++r.moved_from_seeds;
    r.seeds = all.size();
    return all;
}
void construction(Results& r, const Seed& seed, const OctetView next) {
    Decoder donor(seed.decoder);
    const Snapshot before = snapshot(donor);
    arm(0U, true);
    Decoder owner(std::move(donor));
    noallocation(r, "move_construction_allocated");
    check(r, same(snapshot(owner), before), "move_construction_snapshot");
    disarm();
    ++r.move_constructions;
    inert(r, donor, next);
    continuation(r, owner, seed.decoder, seed.suffix, next);
    // Relocating a source that is already inert must keep both objects inert.
    arm(0U, true);
    Decoder empty(std::move(donor));
    noallocation(r, "inert_move_construction_allocated");
    disarm();
    ++r.move_constructions;
    inert(r, empty, next); inert(r, donor, next);

    Decoder source(seed.decoder);
    arm(std::numeric_limits<std::size_t>::max(), false);
    Decoder copy(source);
    const auto points = fault.attempts;
    disarm();
    ++r.copy_constructions;
    check(r, same(snapshot(copy), before) && same(snapshot(source), before),
          "copy_construction_snapshot");
    continuation(r, copy, seed.decoder, seed.suffix, next);
    // Mutating one independently owned copy must not affect the source.
    Output sink;
    static_cast<void>(copy.finish(sink));
    continuation(r, source, seed.decoder, seed.suffix, next);
    for (const bool persistent : {false, true}) {
        for (std::size_t point = 0U; point < points; ++point) {
            bool caught = false;
            arm(point, persistent);
            try { Decoder bad(source); static_cast<void>(bad); }
            catch (const InjectedBadAlloc& e) { caught = e.point == point; }
            ++r.faults;
            r.original_exceptions += caught ? 1U : 0U;
            check(r, caught && same(snapshot(source), before), "copy_ctor_fault");
            disarm();
            ++r.strong_guarantee_checks;
            continuation(r, source, seed.decoder, seed.suffix, next);
        }
        arm(points, persistent);
        Decoder boundary(source);
        check(r, fault.attempts == points && same(snapshot(boundary), before),
              "copy_ctor_boundary");
        disarm();
        ++r.success_boundaries;
    }
    // All forms of aliasing must be allocation-free identity operations.
    Decoder self(seed.decoder);
    Decoder& alias = self;
    const Decoder& const_alias = self;
    for (const unsigned operation : {0U, 1U, 2U, 3U, 4U}) {
        arm(0U, true);
        switch (operation) {
            case 0U: self = std::move(alias); break;
            case 1U: self = const_alias; break;
            case 2U: self.swap(alias); break;
            case 3U: swap(self, alias); break;
            default: std::swap(self, alias); break;
        }
        noallocation(r, "self_operation_allocated");
        check(r, same(snapshot(self), before), "self_operation_identity");
        disarm();
        ++r.self_operations;
    }
    continuation(r, self, seed.decoder, seed.suffix, next);
}
void assignment(Results& r, const Seed& source_seed, const Seed& dest_seed,
                const OctetView next) {
    const Decoder& source_model = source_seed.decoder;
    const Decoder& dest_model = dest_seed.decoder;
    Decoder source(source_model), dest(dest_model);
    const Snapshot source_before = snapshot(source), dest_before = snapshot(dest);
    arm(0U, true);
    Decoder* const returned = &(dest = std::move(source));
    noallocation(r, "move_assignment_allocated");
    check(r, returned == &dest && same(snapshot(dest), source_before),
          "move_assignment_transfer");
    disarm();
    ++r.move_assignments;
    inert(r, source, next);
    continuation(r, dest, source_model, source_seed.suffix, next);
    // Explicitly replace the inert source by a healthy, empty decoder.
    Decoder fresh;
    const Snapshot fresh_before = snapshot(fresh);
    arm(0U, true);
    source = std::move(fresh);
    noallocation(r, "explicit_replacement_allocated");
    check(r, same(snapshot(source), fresh_before), "explicit_replacement");
    disarm();
    ++r.move_assignments;
    inert(r, fresh, next);
    continuation(r, source, Decoder{}, OctetView{}, next);

    source = source_model;
    dest = dest_model;
    arm(std::numeric_limits<std::size_t>::max(), false);
    Decoder* const copied = &(dest = source);
    const std::size_t points = fault.attempts;
    disarm();
    ++r.copy_assignments;
    check(r, copied == &dest && same(snapshot(dest), source_before) &&
          same(snapshot(source), source_before), "copy_assignment_transfer");
    continuation(r, dest, source_model, source_seed.suffix, next);
    for (const bool persistent : {false, true}) {
        for (std::size_t point = 0U; point < points; ++point) {
            Decoder s(source_model), d(dest_model);
            bool caught = false;
            arm(point, persistent);
            try { d = s; }
            catch (const InjectedBadAlloc& e) { caught = e.point == point; }
            ++r.faults;
            r.original_exceptions += caught ? 1U : 0U;
            check(r, caught && same(snapshot(s), source_before) &&
                  same(snapshot(d), dest_before), "copy_assignment_strong_guarantee");
            disarm();
            r.strong_guarantee_checks += 2U;
            continuation(r, s, source_model, source_seed.suffix, next);
            continuation(r, d, dest_model, dest_seed.suffix, next);
            d = s;  // Retry is sound here: copy failure did not consume input.
            continuation(r, d, source_model, source_seed.suffix, next);
        }
        Decoder d(dest_model);
        arm(points, persistent);
        d = source;
        check(r, fault.attempts == points && same(snapshot(d), source_before),
              "copy_assignment_boundary");
        disarm();
        ++r.success_boundaries;
    }
    for (const unsigned operation : {0U, 1U, 2U}) {
        Decoder a(source_model), b(dest_model);
        arm(0U, true);
        switch (operation) {
            case 0U: a.swap(b); break;
            case 1U: swap(a, b); break;
            default: std::swap(a, b); break;
        }
        noallocation(r, "distinct_swap_allocated");
        check(r, same(snapshot(a), dest_before) && same(snapshot(b), source_before),
              "distinct_swap_transfer");
        disarm();
        ++r.swaps;
        continuation(r, a, dest_model, dest_seed.suffix, next);
        continuation(r, b, source_model, source_seed.suffix, next);
    }
}
int run() {
    static_assert(std::is_nothrow_move_constructible_v<Decoder>);
    static_assert(std::is_nothrow_move_assignable_v<Decoder>);
    static_assert(std::is_nothrow_swappable_v<Decoder>);
    static_assert(std::is_copy_constructible_v<Decoder>);
    static_assert(std::is_copy_assignable_v<Decoder>);
    static_assert(noexcept(std::declval<const Decoder&>().moved_from()));
    static_assert(static_cast<int>(Status::operation_failed) == 5);
    static_assert(static_cast<int>(Status::moved_from) == 6);
    Results r;
    check(r, natrav_peer_stream_status_name(Status::moved_from) == "MOVED_FROM",
          "moved_status_name");
    const Octets canonical = frame(346U), next = frame(27U);
    const auto all = seeds(r, canonical);
    // Destinations exercise every terminal kind, partial header/payload, a
    // maximum buffered payload, prior committed output, failure and inertness.
    const std::vector<std::size_t> destination_indices{
        0U, 1U, 2U, 8U, 10U, 11U, 12U, 13U,
        1308U + 22U, 1308U + 23U,
        all.size() - r.failed_seeds - 1U - 20U,
        all.size() - 2U, all.size() - 1U};
    for (const auto& seed : all) {
        construction(r, seed, next);
        for (const auto index : destination_indices) {
            check(r, index < all.size(), "destination_index");
            if (index < all.size()) { assignment(r, seed, all[index], next); }
        }
    }
    check(r, r.faults != 0U && r.original_exceptions == r.faults &&
          r.failed_seeds != 0U && r.moved_from_seeds != 0U, "coverage");
#define NATRAV_LIFECYCLE_PRINT(name) std::printf(#name "=%zu\n", r.name)
    NATRAV_LIFECYCLE_PRINT(seeds);
    NATRAV_LIFECYCLE_PRINT(move_constructions);
    NATRAV_LIFECYCLE_PRINT(copy_constructions);
    NATRAV_LIFECYCLE_PRINT(move_assignments);
    NATRAV_LIFECYCLE_PRINT(copy_assignments);
    NATRAV_LIFECYCLE_PRINT(swaps);
    NATRAV_LIFECYCLE_PRINT(self_operations);
    NATRAV_LIFECYCLE_PRINT(faults);
    NATRAV_LIFECYCLE_PRINT(original_exceptions);
    NATRAV_LIFECYCLE_PRINT(strong_guarantee_checks);
    NATRAV_LIFECYCLE_PRINT(inert_probes);
    NATRAV_LIFECYCLE_PRINT(noallocation_checks);
    NATRAV_LIFECYCLE_PRINT(continuation_checks);
    NATRAV_LIFECYCLE_PRINT(failed_seeds);
    NATRAV_LIFECYCLE_PRINT(moved_from_seeds);
    NATRAV_LIFECYCLE_PRINT(success_boundaries);
    NATRAV_LIFECYCLE_PRINT(failures);
#undef NATRAV_LIFECYCLE_PRINT
    return r.failures == 0U ? 0 : 1;
}
}  // namespace natrav_stream_lifecycle_test
int main() {
    try { return natrav_stream_lifecycle_test::run(); }
    catch (const std::exception& e) {
        natrav_allocation_test::disarm();
        std::fprintf(stderr, "UNEXPECTED %s\n", e.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_STREAM_LIFECYCLE_TEST

#ifdef DATACUBE_NATRAV_SESSION_LIFECYCLE_TEST
#include <initializer_list>
#include <stdexcept>
namespace natrav_session_lifecycle_test {
using namespace datacube;
using namespace natrav_allocation_test;
using Session = NATravPeerHandshakeStreamSession;
using Status = NATravPeerSessionStatus;
using Observation = NATravPeerSessionObservation;
struct Results {
    std::size_t seeds{}, destinations{}, move_constructions{}, copy_constructions{};
    std::size_t move_assignments{}, copy_assignments{}, swaps{}, self_operations{};
    std::size_t faults{}, original_exceptions{}, strong_guarantee_checks{};
    std::size_t inert_probes{}, inert_snapshot_throws{}, noallocation_checks{};
    std::size_t continuation_checks{}, failed_seeds{}, success_boundaries{}, failures{};
};
void check(Results& r, const bool good, const char* label) {
    if (good) { return; }
    ++r.failures;
    if (r.failures <= 12U) { std::fprintf(stderr, "FAILED %s\n", label); }
}
[[nodiscard]] bool same(const Observation& a, const Observation& b) noexcept {
    return a.status == b.status && a.classification == b.classification &&
        a.chunks_observed == b.chunks_observed &&
        a.peak_staged_frames == b.peak_staged_frames &&
        a.frames_observed == b.frames_observed &&
        a.messages_decoded == b.messages_decoded &&
        a.handshake_transitions == b.handshake_transitions &&
        a.buffered_bytes == b.buffered_bytes &&
        a.expected_payload_bytes == b.expected_payload_bytes &&
        a.stream_terminal == b.stream_terminal && a.terminal == b.terminal;
}
void noallocation(Results& r, const Session& a, const Session& b,
                  const char* label) {
    static_cast<void>(a.moved_from()); static_cast<void>(a.operation_failed());
    static_cast<void>(b.moved_from()); static_cast<void>(b.operation_failed());
    ++r.noallocation_checks;
    check(r, fault.attempts == 0U, label);
    disarm();
}
struct Fixture {
    NATravPeerHandshakeMessage message;
    NATravPeerHandshakeExpectation expectation;
    Octets frame;
};
[[nodiscard]] Fixture fixture(const unsigned variant) {
    Fixture f;
    f.message = NATravPeerHandshakeMessage{
        .kind = NATravPeerHandshakeMessageKind::hello_ack,
        .protocol = {.id = "NATRAV_OVERLAY_PEER", .major = 1, .minor = 0},
        .request_id = std::string(64U, variant == 0U ? '1' : '2'),
        .artifact = {.sha256 = std::string(64U, variant == 0U ? 'b' : 'c'),
            .target = variant == 0U ? "x86_64-unknown-linux-gnu" :
                "aarch64-unknown-linux-gnu",
            .version = variant == 0U ? "0.1.0" : "1.2.3"},
        .required_capabilities = {},
        .available_capabilities = variant == 0U ?
            std::vector<std::string>{"PING", "STATUS"} :
            std::vector<std::string>{"PING"},
        .error_code = {}, .error_message = {},
    };
    f.expectation = {f.message.protocol, f.message.request_id,
        f.message.artifact, f.message.available_capabilities};
    const auto encoded = natrav_peer_encode_message(f.message);
    if (!encoded.payload) { throw std::runtime_error("fixture encoding"); }
    f.frame = natrav_peer_encode_frame(*encoded.payload);
    return f;
}
struct Seed {
    Session session;
    Octets suffix;
    Octets next;
};
// Use independent deep copies of pre-operation values as the continuation
// oracle. Suffixes differ by source/destination identity and framing position.
// Comparing only counters would miss a copied/moved handshake expectation.
void continuation(Results& r, const Session& actual, const Seed& reference) {
    Session a(actual), b(reference.session);
    auto compare = [&](const Observation& ao, const Observation& bo) {
        ++r.continuation_checks;
        check(r, same(ao, bo) && same(a.observation(), b.observation()) &&
            a.moved_from() == b.moved_from() &&
            a.operation_failed() == b.operation_failed(), "exact_continuation");
    };
    compare(a.observation(), b.observation());
    // A diagnostic memberwise-copy build can expose a terminal raw decoder
    // inside an active outer session. Once scalar incoherence is detected,
    // do not feed that known-broken control (its framing loop may not advance).
    // Hidden byte/expectation differences with equal scalars still continue.
    if (!same(a.observation(), b.observation()) ||
        a.moved_from() != b.moved_from() ||
        a.operation_failed() != b.operation_failed()) { return; }
    const OctetView suffix(reference.suffix);
    const std::size_t split = suffix.size() / 2U;
    for (const OctetView bytes : {OctetView{}, suffix.first(split),
            suffix.subspan(split), OctetView(reference.next)}) {
        const auto ao = a.feed(bytes), bo = b.feed(bytes);
        compare(ao, bo);
    }
    const auto af = a.finish(), bf = b.finish(); compare(af, bf);
    const auto ae = a.observe_unavailability(NATravPeerHandshakeEvent::timeout);
    const auto be = b.observe_unavailability(NATravPeerHandshakeEvent::timeout);
    compare(ae, be);
    // Independent EOF and event branches before completing a partial frame.
    for (const unsigned branch : {0U, 1U, 2U, 3U}) {
        Session x(actual), y(reference.session);
        const auto xo = branch == 3U ? x.finish() : x.observe_unavailability(
            static_cast<NATravPeerHandshakeEvent>(branch));
        const auto yo = branch == 3U ? y.finish() : y.observe_unavailability(
            static_cast<NATravPeerHandshakeEvent>(branch));
        ++r.continuation_checks;
        check(r, same(xo, yo) && same(x.feed(reference.next), y.feed(reference.next)),
              "exact_early_closure");
    }
}
void inert(Results& r, Session& s, const OctetView bytes) {
    const auto before = s.observation();
    const bool canonical = s.moved_from() && !s.operation_failed() &&
        before.status == Status::moved_from && before.classification == "MOVED_FROM" &&
        before.chunks_observed == 0U && before.peak_staged_frames == 0U &&
        before.frames_observed == 0U && before.messages_decoded == 0U &&
        before.handshake_transitions == 0U && before.buffered_bytes == 0U &&
        before.expected_payload_bytes == 0U && before.stream_terminal && before.terminal;
    check(r, canonical, "inert_aggregate_invariant");
    if (!canonical) { return; }  // Do not exercise a known-broken control state.
    for (const unsigned op : {0U, 1U, 2U, 3U, 4U, 5U, 6U}) {
        bool returned_exact = true;
        arm(0U, true);
        try {
            const Observation observed = op == 0U ? s.feed({}) :
                op == 1U ? s.feed(bytes) : op == 2U ? s.finish() :
                op == 6U ? s.observation() : s.observe_unavailability(
                    static_cast<NATravPeerHandshakeEvent>(op - 3U));
            returned_exact = same(observed, before);
        } catch (const InjectedBadAlloc&) {
            // Public snapshots are allowed to allocate; only state and the
            // two noexcept queries have an allocation-independent contract.
            ++r.inert_snapshot_throws;
        }
        const std::size_t attempts = fault.attempts;
        const bool queries = s.moved_from() && !s.operation_failed();
        check(r, fault.attempts == attempts && queries, "inert_queries_allocate");
        disarm();
        ++r.inert_probes;
        check(r, returned_exact && same(s.observation(), before), "inert_quiescence");
    }
}
[[nodiscard]] std::vector<Seed> seeds(Results& r, std::vector<std::size_t>& dest) {
    std::vector<Seed> out;
    const Fixture a = fixture(0U), b = fixture(1U);
    auto add = [&](const Fixture& f, const std::size_t split, const bool closed) {
        Session s(f.expectation);
        static_cast<void>(s.feed(OctetView(f.frame).first(split)));
        if (closed) { static_cast<void>(s.finish()); }
        out.push_back({std::move(s), Octets(f.frame.begin() +
            static_cast<std::ptrdiff_t>(split), f.frame.end()), f.frame});
    };
    for (std::size_t split = 0U; split <= a.frame.size(); ++split) {
        add(a, split, false); add(a, split, true);
    }
    dest = {0U, 1U, 2U, 8U, 14U, 66U, a.frame.size() * 2U,
            a.frame.size() * 2U + 1U};
    for (const std::size_t split : std::initializer_list<std::size_t>{0U, 1U, 3U, 4U, 7U, 33U,
            b.frame.size() / 2U, b.frame.size() - 1U, b.frame.size()}) {
        if (split == 7U || split == b.frame.size()) { dest.push_back(out.size()); }
        add(b, split, false); add(b, split, true);
    }
    auto special = [&](Session s, const Octets& bytes, const bool select) {
        static_cast<void>(s.feed(bytes));
        if (select) { dest.push_back(out.size()); }
        out.push_back({std::move(s), {}, a.frame});
    };
    const Octets malformed{0U, 0U, 0U, 1U};
    special(Session(a.expectation), malformed, true);
    for (const std::string_view text : {"xx", "{}", "{ }", "[]"}) {
        special(Session(a.expectation), natrav_peer_encode_frame(text_octets(text)), false);
    }
    auto replay = a.frame; append_octets(replay, a.frame);
    append_octets(replay, OctetView(a.frame).first(7U));
    special(Session(a.expectation), replay, true);
    // Long custom error classification is not the same as the PEER_ERROR
    // status name. Preserve it, not a reconstructed generic classification.
    auto error = a.message;
    error.kind = NATravPeerHandshakeMessageKind::error;
    error.artifact = {}; error.available_capabilities.clear();
    error.error_code = "PEER_UNAVAILABLE";
    error.error_message = std::string(256U, 'e');
    const auto encoded_error = natrav_peer_encode_message(error);
    if (!encoded_error.payload) { throw std::runtime_error("error encoding"); }
    special(Session(a.expectation), natrav_peer_encode_frame(*encoded_error.payload), true);
    // Directly vary one expectation dimension, holding response bytes fixed.
    for (const unsigned dimension : {0U, 1U, 2U, 3U, 4U, 5U, 6U}) {
        auto expectation = a.expectation;
        switch (dimension) {
            case 0U: expectation.request_id = b.expectation.request_id; break;
            case 1U: expectation.protocol.id = "OTHER_PROTOCOL_ID_LONG"; break;
            case 2U: expectation.protocol.minor = 1; break;
            case 3U: expectation.expected_artifact.sha256 = b.expectation.expected_artifact.sha256; break;
            case 4U: expectation.expected_artifact.target = b.expectation.expected_artifact.target; break;
            case 5U: expectation.expected_artifact.version = b.expectation.expected_artifact.version; break;
            default: expectation.required_capabilities = {"MISSING", "PING", "STATUS"}; break;
        }
        special(Session(std::move(expectation)), a.frame, false);
    }
    for (const unsigned event : {0U, 1U, 2U}) {
        Session s(a.expectation);
        static_cast<void>(s.feed(OctetView(a.frame).first(33U)));
        static_cast<void>(s.observe_unavailability(static_cast<NATravPeerHandshakeEvent>(event)));
        out.push_back({std::move(s), {}, a.frame});
    }
    // Large buffers and counters, including framing drained after schema error.
    const Octets maximum = natrav_peer_encode_frame(Octets(kNATravPeerMaximumPayloadBytes, 'x'));
    for (const std::size_t split : {4U, 7U, 32768U, 65539U, 65540U}) {
        Session s(a.expectation);
        static_cast<void>(s.feed(OctetView(maximum).first(split)));
        out.push_back({std::move(s), Octets(maximum.begin() +
            static_cast<std::ptrdiff_t>(split), maximum.end()), a.frame});
    }
    auto drain = natrav_peer_encode_frame(text_octets("{}"));
    append_octets(drain, OctetView(a.frame).first(33U));
    special(Session(a.expectation), drain, true);
    // Sample active-operation failures across the successful feed allocation
    // sequence, including early decoder and later message-processing work.
    Session successful(a.expectation);
    arm(std::numeric_limits<std::size_t>::max(), false);
    static_cast<void>(successful.feed(a.frame));
    const auto points = fault.attempts; disarm();
    check(r, points > 8U, "active_fault_coverage");
    for (const std::size_t point : std::initializer_list<std::size_t>{0U, 1U, 2U, 3U, points / 3U,
            points / 2U, points - 2U, points - 1U}) {
        Session s(a.expectation);
        bool caught = false;
        arm(point, true);
        try { static_cast<void>(s.feed(a.frame)); }
        catch (const InjectedBadAlloc& e) { caught = e.point == point; }
        disarm();
        check(r, caught && s.operation_failed(), "failed_seed");
        if (r.failed_seeds == 0U || point == points - 1U) { dest.push_back(out.size()); }
        ++r.failed_seeds;
        out.push_back({std::move(s), {}, a.frame});
    }
    Session donor(a.expectation);
    static_cast<void>(donor.feed(OctetView(a.frame).first(7U)));
    Session owner(std::move(donor));
    dest.push_back(out.size());
    // Copy the already inert object so seed construction does not depend on a
    // second move to manufacture the expected moved-from state.
    out.push_back({donor, {}, a.frame});
    r.seeds = out.size(); r.destinations = dest.size();
    return out;
}
void construction(Results& r, const Seed& seed) {
    const auto before = seed.session.observation();
    Session source(seed.session);
    arm(0U, true);
    Session moved(std::move(source));
    noallocation(r, moved, source, "move_construction_allocated");
    ++r.move_constructions;
    check(r, same(moved.observation(), before), "move_constructor_transfer");
    inert(r, source, seed.next);
    continuation(r, moved, seed);
    // Explicit moves preserve ownership when the source lifetime ends.
    Session surviving = [&]() {
        Session temporary(seed.session);
        arm(0U, true);
        Session result(std::move(temporary));
        noallocation(r, result, temporary, "short_lived_donor_allocated");
        return result;
    }();
    ++r.move_constructions;
    continuation(r, surviving, seed);

    arm(std::numeric_limits<std::size_t>::max(), false);
    Session copied(seed.session);
    const auto points = fault.attempts; disarm();
    ++r.copy_constructions;
    continuation(r, copied, seed);
    for (const bool persistent : {false, true}) {
        for (std::size_t point = 0U; point <= points; ++point) {
            bool caught = false;
            arm(point, persistent);
            try { Session trial(seed.session); }
            catch (const InjectedBadAlloc& e) { caught = e.point == point; }
            disarm();
            if (point == points) {
                ++r.success_boundaries;
                check(r, !caught, "copy_constructor_success_boundary");
            } else {
                ++r.faults; r.original_exceptions += caught ? 1U : 0U;
                ++r.strong_guarantee_checks;
                check(r, caught && same(seed.session.observation(), before),
                      "copy_constructor_source_preserved");
                continuation(r, seed.session, seed);
            }
        }
    }
    for (const unsigned op : {0U, 1U, 2U, 3U, 4U}) {
        Session self(seed.session);
        auto& alias = self; const auto& const_alias = self;
        arm(0U, true);
        switch (op) {
            case 0U: self = std::move(alias); break;
            case 1U: self = const_alias; break;
            case 2U: self.swap(alias); break;
            case 3U: swap(self, alias); break;
            default: std::swap(self, alias); break;
        }
        noallocation(r, self, self, "self_operation_allocated");
        ++r.self_operations;
        check(r, same(self.observation(), before), "self_operation_identity");
        continuation(r, self, seed);
    }
}
void assignment(Results& r, const Seed& source_seed, const Seed& dest_seed,
                const bool inject) {
    const auto source_before = source_seed.session.observation();
    const auto dest_before = dest_seed.session.observation();
    Session source(source_seed.session), dest(dest_seed.session);
    arm(0U, true);
    Session* returned = &(dest = std::move(source));
    noallocation(r, source, dest, "move_assignment_allocated");
    ++r.move_assignments;
    check(r, returned == &dest && same(dest.observation(), source_before),
          "move_assignment_transfer");
    inert(r, source, source_seed.next);
    continuation(r, dest, source_seed);
    // Replacing an inert source by an independently prepared healthy owner is
    // a new object value, not a retry of consumed protocol input.
    Session replacement(dest_seed.session);
    arm(0U, true);
    source = std::move(replacement);
    noallocation(r, source, replacement, "explicit_replacement_allocated");
    ++r.move_assignments;
    continuation(r, source, dest_seed);
    inert(r, replacement, dest_seed.next);

    Session copy_source(source_seed.session), copy_dest(dest_seed.session);
    arm(std::numeric_limits<std::size_t>::max(), false);
    returned = &(copy_dest = copy_source);
    const auto points = fault.attempts; disarm();
    ++r.copy_assignments;
    check(r, returned == &copy_dest && same(copy_dest.observation(), source_before) &&
        same(copy_source.observation(), source_before), "copy_assignment_transfer");
    continuation(r, copy_dest, source_seed);
    if (inject) {
        for (const bool persistent : {false, true}) {
            for (std::size_t point = 0U; point <= points; ++point) {
                Session s(source_seed.session), d(dest_seed.session);
                bool caught = false;
                arm(point, persistent);
                try { d = s; }
                catch (const InjectedBadAlloc& e) { caught = e.point == point; }
                disarm();
                if (point == points) {
                    ++r.success_boundaries;
                    check(r, !caught && same(d.observation(), source_before),
                          "copy_assignment_success_boundary");
                    continuation(r, d, source_seed);
                } else {
                    ++r.faults; r.original_exceptions += caught ? 1U : 0U;
                    r.strong_guarantee_checks += 2U;
                    check(r, caught && same(s.observation(), source_before) &&
                        same(d.observation(), dest_before), "copy_assignment_strong_guarantee");
                    continuation(r, s, source_seed);
                    continuation(r, d, dest_seed);
                    d = s;
                    continuation(r, d, source_seed);
                }
            }
        }
    }
    for (const unsigned op : {0U, 1U, 2U}) {
        Session a(source_seed.session), b(dest_seed.session);
        arm(0U, true);
        switch (op) {
            case 0U: a.swap(b); break;
            case 1U: swap(a, b); break;
            default: std::swap(a, b); break;
        }
        noallocation(r, a, b, "swap_allocated");
        ++r.swaps;
        check(r, same(a.observation(), dest_before) && same(b.observation(), source_before),
              "swap_transfer");
        continuation(r, a, dest_seed); continuation(r, b, source_seed);
    }
}
int run() {
    static_assert(std::is_nothrow_move_constructible_v<Session>);
    static_assert(std::is_nothrow_move_assignable_v<Session>);
    static_assert(std::is_nothrow_swappable_v<Session>);
    static_assert(std::is_copy_constructible_v<Session>);
    static_assert(std::is_copy_assignable_v<Session>);
    static_assert(noexcept(std::declval<const Session&>().moved_from()));
    static_assert(noexcept(std::declval<const Session&>().operation_failed()));
    static_assert(static_cast<int>(Status::operation_failed) == 17);
    static_assert(static_cast<int>(Status::moved_from) == 18);
    Results r;
    check(r, natrav_peer_session_status_name(Status::moved_from) == "MOVED_FROM",
          "moved_status_name");
    std::vector<std::size_t> destinations;
    const auto all = seeds(r, destinations);
    for (const auto& seed : all) {
        construction(r, seed);
        for (std::size_t i = 0U; i < destinations.size(); ++i) {
            const auto index = destinations[i];
            check(r, index < all.size(), "destination_index");
            // Sweep each allocation for five destination shapes. All other
            // pairs still exercise moves, normal copying and all three swaps.
            const bool inject = i == 0U || i == 4U || i == 8U ||
                i + 2U == destinations.size() || i + 1U == destinations.size();
            assignment(r, seed, all[index], inject);
        }
    }
    check(r, r.faults != 0U && r.original_exceptions == r.faults &&
        r.failed_seeds != 0U && r.inert_probes != 0U, "coverage");
#define NATRAV_SESSION_LIFECYCLE_PRINT(name) std::printf(#name "=%zu\n", r.name)
    NATRAV_SESSION_LIFECYCLE_PRINT(seeds);
    NATRAV_SESSION_LIFECYCLE_PRINT(destinations);
    NATRAV_SESSION_LIFECYCLE_PRINT(move_constructions);
    NATRAV_SESSION_LIFECYCLE_PRINT(copy_constructions);
    NATRAV_SESSION_LIFECYCLE_PRINT(move_assignments);
    NATRAV_SESSION_LIFECYCLE_PRINT(copy_assignments);
    NATRAV_SESSION_LIFECYCLE_PRINT(swaps);
    NATRAV_SESSION_LIFECYCLE_PRINT(self_operations);
    NATRAV_SESSION_LIFECYCLE_PRINT(faults);
    NATRAV_SESSION_LIFECYCLE_PRINT(original_exceptions);
    NATRAV_SESSION_LIFECYCLE_PRINT(strong_guarantee_checks);
    NATRAV_SESSION_LIFECYCLE_PRINT(inert_probes);
    NATRAV_SESSION_LIFECYCLE_PRINT(inert_snapshot_throws);
    NATRAV_SESSION_LIFECYCLE_PRINT(noallocation_checks);
    NATRAV_SESSION_LIFECYCLE_PRINT(continuation_checks);
    NATRAV_SESSION_LIFECYCLE_PRINT(failed_seeds);
    NATRAV_SESSION_LIFECYCLE_PRINT(success_boundaries);
    NATRAV_SESSION_LIFECYCLE_PRINT(failures);
#undef NATRAV_SESSION_LIFECYCLE_PRINT
    return r.failures == 0U ? 0 : 1;
}
}  // namespace natrav_session_lifecycle_test
int main() {
    try { return natrav_session_lifecycle_test::run(); }
    catch (const std::exception& e) {
        natrav_allocation_test::disarm();
        std::fprintf(stderr, "UNEXPECTED %s\n", e.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_SESSION_LIFECYCLE_TEST

#ifdef DATACUBE_NATRAV_HANDSHAKE_ALLOCATION_FAILURE_TEST
#include <stdexcept>
namespace natrav_handshake_allocation_test {
using namespace datacube;
using namespace natrav_allocation_test;
// Exact revision-0464 standalone method-body oracle, isolated from production.
// Its enum types and input/observation records remain shared for comparison.
class HistoricalSession final {
public:
    explicit HistoricalSession(
        NATravPeerHandshakeExpectation expectation);

    [[nodiscard]] NATravPeerHandshakeObservation observe_response(
        const NATravPeerHandshakeMessage& response);
    [[nodiscard]] NATravPeerHandshakeObservation observe_unavailability(
        NATravPeerHandshakeEvent event);
    [[nodiscard]] NATravPeerHandshakeObservation observation() const;

private:
    [[nodiscard]] NATravPeerHandshakeObservation terminate(
        NATravPeerHandshakeStatus status,
        std::string classification);

    NATravPeerHandshakeExpectation expectation_;
    NATravPeerHandshakeStatus status_{NATravPeerHandshakeStatus::awaiting_response};
    std::string classification_{"AWAITING_RESPONSE"};
    std::size_t responses_observed_{0U};
    bool terminal_{false};
};

[[nodiscard]] bool required_capabilities_available(
    const std::vector<std::string>& required,
    const std::vector<std::string>& available) noexcept {
    return std::includes(
        available.begin(), available.end(), required.begin(), required.end());
}

HistoricalSession::HistoricalSession(
    NATravPeerHandshakeExpectation expectation)
    : expectation_(std::move(expectation)) {}

NATravPeerHandshakeObservation HistoricalSession::terminate(
    const NATravPeerHandshakeStatus status,
    std::string classification) {
    status_ = status;
    classification_ = std::move(classification);
    terminal_ = true;
    return observation();
}

NATravPeerHandshakeObservation HistoricalSession::observe_response(
    const NATravPeerHandshakeMessage& response) {
    if (terminal_) {
        ++responses_observed_;
        return terminate(
            NATravPeerHandshakeStatus::replay_rejected,
            "REPLAY_REJECTED");
    }
    ++responses_observed_;

    if (response.request_id != expectation_.request_id) {
        return terminate(
            NATravPeerHandshakeStatus::correlation_rejected,
            "CORRELATION_REJECTED");
    }
    if (response.protocol.id != expectation_.protocol.id ||
        response.protocol.major != expectation_.protocol.major ||
        response.protocol.minor < expectation_.protocol.minor) {
        return terminate(
            NATravPeerHandshakeStatus::protocol_mismatch,
            "PROTOCOL_MISMATCH");
    }
    if (response.kind == NATravPeerHandshakeMessageKind::error) {
        return terminate(
            NATravPeerHandshakeStatus::peer_error,
            response.error_code);
    }
    if (response.kind != NATravPeerHandshakeMessageKind::hello_ack) {
        return terminate(
            NATravPeerHandshakeStatus::message_kind_rejected,
            "MESSAGE_KIND_REJECTED");
    }
    if (response.artifact.sha256 != expectation_.expected_artifact.sha256 ||
        response.artifact.target != expectation_.expected_artifact.target ||
        response.artifact.version != expectation_.expected_artifact.version) {
        return terminate(
            NATravPeerHandshakeStatus::artifact_identity_mismatch,
            "ARTIFACT_IDENTITY_MISMATCH");
    }
    if (!required_capabilities_available(
            expectation_.required_capabilities,
            response.available_capabilities)) {
        return terminate(
            NATravPeerHandshakeStatus::capability_mismatch,
            "CAPABILITY_MISMATCH");
    }
    return terminate(NATravPeerHandshakeStatus::accepted, "ACCEPTED");
}

NATravPeerHandshakeObservation
HistoricalSession::observe_unavailability(
    const NATravPeerHandshakeEvent event) {
    static_cast<void>(event);
    if (terminal_) {
        return observation();
    }
    return terminate(
        NATravPeerHandshakeStatus::peer_unavailable,
        "PEER_UNAVAILABLE");
}

NATravPeerHandshakeObservation HistoricalSession::observation() const {
    return NATravPeerHandshakeObservation{
        .status = status_,
        .classification = classification_,
        .responses_observed = responses_observed_,
        .terminal = terminal_,
    };
}

using Session = NATravPeerHandshakeSession;
using Observation = NATravPeerHandshakeObservation;
using Message = NATravPeerHandshakeMessage;
using Expectation = NATravPeerHandshakeExpectation;
using Status = NATravPeerHandshakeStatus;
enum class Operation { response, timeout, early_eof, spawn_failure, observe };
struct Results final {
    std::size_t expectations{0U}, responses{0U}, seeds{0U}, scenarios{0U};
    std::size_t normal_comparisons{0U}, allocation_points{0U}, faults{0U};
    std::size_t original_exceptions{0U}, latch_noallocation_checks{0U};
    std::size_t active_faults{0U}, latched_faults{0U}, read_only_faults{0U};
    std::size_t read_only_unchanged{0U}, success_boundaries{0U};
    std::size_t frozen_checks{0U}, persistent_snapshot_throws{0U};
    std::size_t query_noallocation_checks{0U}, input_preservation_checks{0U};
    std::size_t historical_precommit_faults{0U}, historical_postcommit_faults{0U};
    std::size_t historical_accepts_after_failure{0U}, historical_replays_after_failure{0U};
    std::size_t failures{0U};
};
void check(Results& r, const bool condition, const char* label) {
    if (condition) { return; }
    ++r.failures;
    if (r.failures <= 12U) { std::printf("FAIL %s\n", label); }
}
[[nodiscard]] bool equal(const Observation& a, const Observation& b) noexcept {
    return a.status == b.status && a.classification == b.classification &&
        a.responses_observed == b.responses_observed && a.terminal == b.terminal;
}
[[nodiscard]] bool input_equal(const Message& a, const Message& b) noexcept {
    return a.kind == b.kind && a.protocol.id == b.protocol.id &&
        a.protocol.major == b.protocol.major && a.protocol.minor == b.protocol.minor &&
        a.request_id == b.request_id && a.artifact.sha256 == b.artifact.sha256 &&
        a.artifact.target == b.artifact.target && a.artifact.version == b.artifact.version &&
        a.required_capabilities == b.required_capabilities &&
        a.available_capabilities == b.available_capabilities &&
        a.error_code == b.error_code && a.error_message == b.error_message;
}
template<class S>
[[nodiscard]] Observation invoke(S& s, const Operation op, const Message& m) {
    switch (op) {
        case Operation::response: return s.observe_response(m);
        case Operation::timeout:
            return s.observe_unavailability(NATravPeerHandshakeEvent::timeout);
        case Operation::early_eof:
            return s.observe_unavailability(NATravPeerHandshakeEvent::early_eof);
        case Operation::spawn_failure:
            return s.observe_unavailability(NATravPeerHandshakeEvent::spawn_failure);
        case Operation::observe: return s.observation();
    }
    throw std::logic_error("invalid test operation");
}
constexpr Operation operations[]{Operation::response, Operation::timeout,
    Operation::early_eof, Operation::spawn_failure, Operation::observe};
[[nodiscard]] Expectation expectation(const std::size_t variant) {
    const std::string suffix = std::to_string(variant) + std::string(variant * 11U, 'x');
    Expectation e{{"protocol-" + suffix, 1, 2}, "request-" + suffix,
        {std::string(64U, 'a'), "target-" + suffix, "version-" + suffix}, {}};
    for (std::size_t i = 0U; i < variant; ++i) {
        e.required_capabilities.push_back("cap-" + std::to_string(i) + suffix);
    }
    std::sort(e.required_capabilities.begin(), e.required_capabilities.end());
    return e;
}
[[nodiscard]] std::vector<Message> responses(const Expectation& e) {
    Message good;
    good.kind = NATravPeerHandshakeMessageKind::hello_ack;
    good.protocol = e.protocol; good.request_id = e.request_id;
    good.artifact = e.expected_artifact; good.available_capabilities = e.required_capabilities;
    std::vector<Message> out{good};
    auto add = [&](auto change) { Message m(good); change(m); out.push_back(std::move(m)); };
    add([](Message& m) { m.request_id += "-different"; });
    add([](Message& m) { m.protocol.id += "-different"; });
    add([](Message& m) { ++m.protocol.major; });
    add([](Message& m) { --m.protocol.major; });
    add([](Message& m) { --m.protocol.minor; });
    add([](Message& m) { ++m.protocol.minor; });
    add([](Message& m) { m.kind = NATravPeerHandshakeMessageKind::hello; });
    add([](Message& m) { m.kind = NATravPeerHandshakeMessageKind::unknown; });
    add([](Message& m) { m.artifact.sha256[0] = 'b'; });
    add([](Message& m) { m.artifact.target += "-different"; });
    add([](Message& m) { m.artifact.version += "-different"; });
    add([](Message& m) { m.available_capabilities.clear(); });
    add([](Message& m) {
        if (!m.available_capabilities.empty()) { m.available_capabilities.pop_back(); }
    });
    add([](Message& m) {
        m.available_capabilities.push_back("zz-extra");
        std::sort(m.available_capabilities.begin(), m.available_capabilities.end());
    });
    for (const std::size_t length : {0U, 1U, 14U, 15U, 16U, 17U, 31U, 32U,
                                   63U, 64U, 255U, 4096U}) {
        add([&](Message& m) {
            m.kind = NATravPeerHandshakeMessageKind::error;
            m.error_code = std::string(length, 'E');
            m.error_message = std::string(length + 20U, 'D');
        });
    }
    // Multi-defect priority controls: correlation before protocol before kind,
    // artifact and capability. ERROR still retains its exact code bytes.
    add([](Message& m) {
        m.request_id += "bad"; ++m.protocol.major;
        m.kind = NATravPeerHandshakeMessageKind::error;
        m.error_code = "ERROR_WITH_WRONG_CORRELATION";
    });
    add([](Message& m) {
        ++m.protocol.major; m.kind = NATravPeerHandshakeMessageKind::error;
        m.error_code = "ERROR_WITH_WRONG_PROTOCOL";
    });
    add([](Message& m) {
        m.kind = NATravPeerHandshakeMessageKind::error;
        m.error_code = "ERROR_WITH_WRONG_ARTIFACT";
        m.artifact.sha256[0] = 'b'; m.available_capabilities.clear();
    });
    add([](Message& m) {
        m.kind = NATravPeerHandshakeMessageKind::hello;
        m.artifact.sha256[0] = 'b'; m.available_capabilities.clear();
    });
    add([](Message& m) {
        m.artifact.sha256[0] = 'b'; m.available_capabilities.clear();
    });
    add([](Message& m) {
        m.kind = NATravPeerHandshakeMessageKind::error;
        m.error_code = std::string("EMBEDDED\0CODE", 13U);
    });
    add([](Message& m) {
        m.kind = NATravPeerHandshakeMessageKind::error;
        m.error_code = "OPERATION_FAILED";  // A peer string is NOT a local fault.
    });
    return out;
}
void compare_continuation(Results& r, Session subject, HistoricalSession historical,
                          const Message& good) {
    for (const Operation op : operations) {
        const auto actual = invoke(subject, op, good);
        const auto expected = invoke(historical, op, good);
        ++r.normal_comparisons;
        check(r, equal(actual, expected) && !subject.operation_failed(),
              "continuation-compatible");
    }
}
void frozen_probes(Results& r, Session& subject, const std::vector<Message>& inputs) {
    const Observation frozen = subject.observation();
    check(r, frozen.status == Status::operation_failed && frozen.terminal &&
          frozen.classification == "OPERATION_FAILED", "failed-observation");
    // First verify exact observations with allocation available. Then keep
    // failure armed across each operation and its allocation-free query.
    for (const bool persistent : {false, true}) {
        for (const std::size_t index : {0U, 1U, 9U, 15U, 26U, 33U}) {
            for (const Operation op : operations) {
                if (persistent) { arm(0U, true); }
                bool threw = false;
                bool exact = false;
                try { exact = equal(invoke(subject, op, inputs.at(index)), frozen); }
                catch (const InjectedBadAlloc&) { threw = true; }
                catch (...) { disarm(); check(r, false, "wrong-probe-exception"); }
                const auto before_query = fault.attempts;
                const bool failed = subject.operation_failed();
                const bool noalloc = fault.attempts == before_query;
                disarm();
                ++r.query_noallocation_checks;
                check(r, failed && noalloc && (exact || (persistent && threw)),
                      "frozen-probe-or-snapshot-throw");
                if (threw) { ++r.persistent_snapshot_throws; }
                ++r.frozen_checks;
                check(r, equal(subject.observation(), frozen), "frozen-state");
            }
        }
    }
}
void run_case(Results& r, const Session& seed, const HistoricalSession& old_seed,
              const Operation op, const Message& input,
              const std::vector<Message>& inputs) {
    ++r.scenarios;
    const Observation before = seed.observation();
    const Message input_before(input);
    const bool active = op == Operation::response ||
        (op != Operation::observe && !before.terminal);
    Session control(seed);
    arm(std::numeric_limits<std::size_t>::max(), false);
    const Observation expected = invoke(control, op, input);
    const std::size_t points = fault.attempts;
    disarm();
    r.allocation_points += points;
    HistoricalSession old_control(old_seed);
    const Observation old_expected = invoke(old_control, op, input);
    ++r.normal_comparisons;
    check(r, equal(expected, old_expected) && !control.operation_failed(),
          "normal-observation-compatible");
    compare_continuation(r, control, old_control, inputs.front());
    for (const bool persistent : {false, true}) {
        for (std::size_t point = 0U; point <= points; ++point) {
            Session subject(seed);
            bool threw = false, original = false, returned_exact = false;
            arm(point, persistent);
            try { returned_exact = equal(invoke(subject, op, input), expected); }
            catch (const InjectedBadAlloc& error) {
                threw = true; original = error.point == point;
            } catch (...) { threw = true; }
            const auto attempts = fault.attempts;
            const bool failed = subject.operation_failed();
            const bool noalloc = attempts == fault.attempts;
            disarm();
            ++r.query_noallocation_checks;
            check(r, noalloc, "allocation-free-query");
            ++r.input_preservation_checks;
            check(r, input_equal(input, input_before), "input-unchanged");
            if (point == points) {
                ++r.success_boundaries;
                check(r, !threw && !failed && returned_exact &&
                      equal(subject.observation(), expected), "success-boundary");
                continue;
            }
            ++r.faults;
            if (original) { ++r.original_exceptions; }
            ++r.latch_noallocation_checks;
            check(r, threw && original && attempts == point + 1U,
                  "original-exception-and-noalloc-latch");
            if (!active) {
                ++r.read_only_faults;
                const bool unchanged = !failed && equal(subject.observation(), before);
                if (unchanged) { ++r.read_only_unchanged; }
                check(r, unchanged, "snapshot-failure-no-state-change");
                compare_continuation(r, subject, old_seed, inputs.front());
                continue;
            }
            ++r.active_faults;
            if (failed) { ++r.latched_faults; }
            check(r, failed, "active-failure-latched");
            check(r, subject.observation().responses_observed ==
                  before.responses_observed + (op == Operation::response ? 1U : 0U),
                  "partial-response-accounting-retained");
            HistoricalSession historical(old_seed);
            bool historical_original = false;
            arm(point, persistent);
            try { static_cast<void>(invoke(historical, op, input)); }
            catch (const InjectedBadAlloc& error) {
                historical_original = error.point == point;
            } catch (...) {}
            disarm();
            check(r, historical_original, "historical-same-allocation-point");
            const auto old_after = historical.observation();
            if (old_after.terminal) { ++r.historical_postcommit_faults; }
            else { ++r.historical_precommit_faults; }
            const auto old_next = historical.observe_response(inputs.front());
            if (old_next.status == Status::accepted) { ++r.historical_accepts_after_failure; }
            if (old_next.status == Status::replay_rejected) { ++r.historical_replays_after_failure; }
            if (failed) { frozen_probes(r, subject, inputs); }
        }
    }
}
int run() {
    static_assert(noexcept(std::declval<const Session&>().operation_failed()));
    static_assert(std::is_same_v<decltype(std::declval<const Session&>().operation_failed()), bool>);
    static_assert(static_cast<int>(Status::replay_rejected) == 9);
    static_assert(static_cast<int>(Status::operation_failed) == 10);
    Results r;
    for (std::size_t variant = 0U; variant < 8U; ++variant) {
        ++r.expectations;
        const auto e = expectation(variant);
        const auto inputs = responses(e);
        r.responses += inputs.size();
        std::vector<Session> seeds;
        std::vector<HistoricalSession> old_seeds;
        seeds.emplace_back(e); old_seeds.emplace_back(e);
        for (const auto& m : inputs) {
            Session s(e); HistoricalSession old(e);
            const auto a = s.observe_response(m); const auto b = old.observe_response(m);
            ++r.normal_comparisons;
            check(r, equal(a,b) && !s.operation_failed(), "seed-compatible-not-peer-spelling");
            seeds.push_back(s); old_seeds.push_back(old);
        }
        for (const auto event : {NATravPeerHandshakeEvent::timeout,
             NATravPeerHandshakeEvent::early_eof, NATravPeerHandshakeEvent::spawn_failure}) {
            Session s(e); HistoricalSession old(e);
            static_cast<void>(s.observe_unavailability(event));
            static_cast<void>(old.observe_unavailability(event));
            seeds.push_back(s); old_seeds.push_back(old);
        }
        Session replay(e); HistoricalSession old_replay(e);
        for (std::size_t i = 0U; i < 7U; ++i) {
            static_cast<void>(replay.observe_response(inputs.front()));
            static_cast<void>(old_replay.observe_response(inputs.front()));
        }
        seeds.push_back(replay); old_seeds.push_back(old_replay);
        r.seeds += seeds.size();
        for (std::size_t i = 0U; i < seeds.size(); ++i) {
            for (const auto& m : inputs) {
                run_case(r, seeds[i], old_seeds[i], Operation::response, m, inputs);
            }
            for (const Operation op : {Operation::timeout, Operation::early_eof,
                                      Operation::spawn_failure, Operation::observe}) {
                run_case(r, seeds[i], old_seeds[i], op, inputs.front(), inputs);
            }
        }
    }
    check(r, r.active_faults != 0U && r.read_only_faults != 0U &&
          r.historical_accepts_after_failure != 0U &&
          r.historical_replays_after_failure != 0U, "coverage");
#define REPORT(field) std::printf(#field "=%zu\n", r.field)
    REPORT(expectations); REPORT(responses); REPORT(seeds); REPORT(scenarios);
    REPORT(normal_comparisons); REPORT(allocation_points); REPORT(faults);
    REPORT(original_exceptions); REPORT(latch_noallocation_checks);
    REPORT(active_faults); REPORT(latched_faults); REPORT(read_only_faults);
    REPORT(read_only_unchanged); REPORT(success_boundaries); REPORT(frozen_checks);
    REPORT(persistent_snapshot_throws); REPORT(query_noallocation_checks);
    REPORT(input_preservation_checks); REPORT(historical_precommit_faults);
    REPORT(historical_postcommit_faults); REPORT(historical_accepts_after_failure);
    REPORT(historical_replays_after_failure); REPORT(failures);
#undef REPORT
    return r.failures == 0U ? 0 : 1;
}
}  // namespace natrav_handshake_allocation_test
int main() {
    try { return natrav_handshake_allocation_test::run(); }
    catch (const std::exception& error) {
        natrav_allocation_test::disarm();
        std::fprintf(stderr, "unexpected: %s\n", error.what()); return 2;
    }
}
#endif  // DATACUBE_NATRAV_HANDSHAKE_ALLOCATION_FAILURE_TEST

#ifdef DATACUBE_NATRAV_HANDSHAKE_LIFECYCLE_TEST
#include <stdexcept>
namespace natrav_handshake_lifecycle_test {
using namespace datacube;
using namespace natrav_allocation_test;
// Exact revision-0465 class and method-body oracle, isolated from production.
// Its implicit assignment is intentionally retained to measure partial-copy
// behavior. Shared input and enum types do not supply the new special members.
class HistoricalSession final {
public:
    explicit HistoricalSession(
        NATravPeerHandshakeExpectation expectation);

    [[nodiscard]] NATravPeerHandshakeObservation observe_response(
        const NATravPeerHandshakeMessage& response);
    [[nodiscard]] NATravPeerHandshakeObservation observe_unavailability(
        NATravPeerHandshakeEvent event);
    [[nodiscard]] NATravPeerHandshakeObservation observation() const;

    // Active-operation exceptions latch a terminal, discard-and-reconstruct
    // state before propagating unchanged. No rollback or retry is promised.
    // This query never allocates, even while observation snapshots may throw.
    [[nodiscard]] bool operation_failed() const noexcept;

private:
    [[nodiscard]] NATravPeerHandshakeObservation terminate(
        NATravPeerHandshakeStatus status,
        std::string classification);

    NATravPeerHandshakeExpectation expectation_;
    NATravPeerHandshakeStatus status_{NATravPeerHandshakeStatus::awaiting_response};
    std::string classification_{"AWAITING_RESPONSE"};
    std::size_t responses_observed_{0U};
    bool terminal_{false};
};

[[nodiscard]] bool required_capabilities_available(
    const std::vector<std::string>& required,
    const std::vector<std::string>& available) noexcept {
    return std::includes(
        available.begin(), available.end(), required.begin(), required.end());
}

HistoricalSession::HistoricalSession(
    NATravPeerHandshakeExpectation expectation)
    : expectation_(std::move(expectation)) {}

NATravPeerHandshakeObservation HistoricalSession::terminate(
    const NATravPeerHandshakeStatus status,
    std::string classification) {
    status_ = status;
    classification_ = std::move(classification);
    terminal_ = true;
    return observation();
}

NATravPeerHandshakeObservation HistoricalSession::observe_response(
    const NATravPeerHandshakeMessage& response) {
    if (operation_failed()) { return observation(); }
    try {
        if (terminal_) {
            ++responses_observed_;
            return terminate(
                NATravPeerHandshakeStatus::replay_rejected,
                "REPLAY_REJECTED");
        }
        ++responses_observed_;

        if (response.request_id != expectation_.request_id) {
            return terminate(
                NATravPeerHandshakeStatus::correlation_rejected,
                "CORRELATION_REJECTED");
        }
        if (response.protocol.id != expectation_.protocol.id ||
            response.protocol.major != expectation_.protocol.major ||
            response.protocol.minor < expectation_.protocol.minor) {
            return terminate(
                NATravPeerHandshakeStatus::protocol_mismatch,
                "PROTOCOL_MISMATCH");
        }
        if (response.kind == NATravPeerHandshakeMessageKind::error) {
            return terminate(
                NATravPeerHandshakeStatus::peer_error,
                response.error_code);
        }
        if (response.kind != NATravPeerHandshakeMessageKind::hello_ack) {
            return terminate(
                NATravPeerHandshakeStatus::message_kind_rejected,
                "MESSAGE_KIND_REJECTED");
        }
        if (response.artifact.sha256 != expectation_.expected_artifact.sha256 ||
            response.artifact.target != expectation_.expected_artifact.target ||
            response.artifact.version != expectation_.expected_artifact.version) {
            return terminate(
                NATravPeerHandshakeStatus::artifact_identity_mismatch,
                "ARTIFACT_IDENTITY_MISMATCH");
        }
        if (!required_capabilities_available(
                expectation_.required_capabilities,
                response.available_capabilities)) {
            return terminate(
                NATravPeerHandshakeStatus::capability_mismatch,
                "CAPABILITY_MISMATCH");
        }
        return terminate(NATravPeerHandshakeStatus::accepted, "ACCEPTED");
    } catch (...) {
        // Scalar writes only: a persistent allocation failure must not prevent
        // the latch or replace the original exception. Retain partial counts.
        status_ = NATravPeerHandshakeStatus::operation_failed;
        terminal_ = true;
        throw;
    }
}

NATravPeerHandshakeObservation
HistoricalSession::observe_unavailability(
    const NATravPeerHandshakeEvent event) {
    static_cast<void>(event);
    if (terminal_) {
        return observation();
    }
    try {
        return terminate(
            NATravPeerHandshakeStatus::peer_unavailable,
            "PEER_UNAVAILABLE");
    } catch (...) {
        // Already-terminal calls above are snapshots, not active operations.
        status_ = NATravPeerHandshakeStatus::operation_failed;
        terminal_ = true;
        throw;
    }
}

NATravPeerHandshakeObservation HistoricalSession::observation() const {
    return NATravPeerHandshakeObservation{
        .status = status_,
        .classification = operation_failed()
            ? std::string(natrav_peer_handshake_status_name(status_))
            : classification_,
        .responses_observed = responses_observed_,
        .terminal = terminal_,
    };
}

bool HistoricalSession::operation_failed() const noexcept {
    return status_ == NATravPeerHandshakeStatus::operation_failed;
}


using Session = NATravPeerHandshakeSession;
using Status = NATravPeerHandshakeStatus;
using Observation = NATravPeerHandshakeObservation;
using Message = NATravPeerHandshakeMessage;
using Expectation = NATravPeerHandshakeExpectation;
struct Results {
    std::size_t seeds{}, destinations{}, move_constructions{}, copy_constructions{};
    std::size_t move_assignments{}, copy_assignments{}, swaps{}, self_operations{};
    std::size_t faults{}, original_exceptions{}, strong_guarantee_checks{};
    std::size_t inert_probes{}, inert_snapshot_throws{}, noallocation_checks{};
    std::size_t continuation_checks{}, failed_seeds{}, success_boundaries{}, failures{};
    std::size_t exception_allocation_checks{}, historical_copy_faults{};
    std::size_t historical_partial_copies{}, historical_hidden_changes{};
};
void check(Results& r, const bool good, const char* label) {
    if (good) { return; }
    ++r.failures;
    if (r.failures <= 12U) { std::fprintf(stderr, "FAILED %s\n", label); }
}
[[nodiscard]] bool same(const Observation& a, const Observation& b) noexcept {
    return a.status == b.status && a.classification == b.classification &&
        a.responses_observed == b.responses_observed && a.terminal == b.terminal;
}
void noallocation(Results& r, const Session& a, const Session& b,
                  const char* label) {
    static_cast<void>(a.moved_from()); static_cast<void>(a.operation_failed());
    static_cast<void>(b.moved_from()); static_cast<void>(b.operation_failed());
    ++r.noallocation_checks;
    check(r, fault.attempts == 0U, label);
    disarm();
}
[[nodiscard]] Expectation expectation(const std::size_t variant) {
    const std::string suffix = std::to_string(variant) + std::string(variant * 11U, 'x');
    Expectation e{{"protocol-" + suffix, 1, 2}, "request-" + suffix,
        {std::string(64U, 'a'), "target-" + suffix, "version-" + suffix}, {}};
    for (std::size_t i = 0U; i < variant; ++i) {
        e.required_capabilities.push_back("cap-" + std::to_string(i) + suffix);
    }
    std::sort(e.required_capabilities.begin(), e.required_capabilities.end());
    return e;
}
[[nodiscard]] std::vector<Message> responses(const Expectation& e) {
    Message good;
    good.kind = NATravPeerHandshakeMessageKind::hello_ack;
    good.protocol = e.protocol; good.request_id = e.request_id;
    good.artifact = e.expected_artifact; good.available_capabilities = e.required_capabilities;
    std::vector<Message> out{good};
    auto add = [&](auto change) { Message m(good); change(m); out.push_back(std::move(m)); };
    add([](Message& m) { m.request_id += "-different"; });
    add([](Message& m) { m.protocol.id += "-different"; });
    add([](Message& m) { ++m.protocol.major; });
    add([](Message& m) { --m.protocol.major; });
    add([](Message& m) { --m.protocol.minor; });
    add([](Message& m) { ++m.protocol.minor; });
    add([](Message& m) { m.kind = NATravPeerHandshakeMessageKind::hello; });
    add([](Message& m) { m.kind = NATravPeerHandshakeMessageKind::unknown; });
    add([](Message& m) { m.artifact.sha256[0] = 'b'; });
    add([](Message& m) { m.artifact.target += "-different"; });
    add([](Message& m) { m.artifact.version += "-different"; });
    add([](Message& m) { m.available_capabilities.clear(); });
    add([](Message& m) {
        if (!m.available_capabilities.empty()) { m.available_capabilities.pop_back(); }
    });
    add([](Message& m) {
        m.available_capabilities.push_back("zz-extra");
        std::sort(m.available_capabilities.begin(), m.available_capabilities.end());
    });
    for (const std::size_t length : {0U, 1U, 14U, 15U, 16U, 17U, 31U, 32U,
                                   63U, 64U, 255U, 4096U}) {
        add([&](Message& m) {
            m.kind = NATravPeerHandshakeMessageKind::error;
            m.error_code = std::string(length, 'E');
            m.error_message = std::string(length + 20U, 'D');
        });
    }
    // Multi-defect priority controls: correlation before protocol before kind,
    // artifact and capability. ERROR still retains its exact code bytes.
    add([](Message& m) {
        m.request_id += "bad"; ++m.protocol.major;
        m.kind = NATravPeerHandshakeMessageKind::error;
        m.error_code = "ERROR_WITH_WRONG_CORRELATION";
    });
    add([](Message& m) {
        ++m.protocol.major; m.kind = NATravPeerHandshakeMessageKind::error;
        m.error_code = "ERROR_WITH_WRONG_PROTOCOL";
    });
    add([](Message& m) {
        m.kind = NATravPeerHandshakeMessageKind::error;
        m.error_code = "ERROR_WITH_WRONG_ARTIFACT";
        m.artifact.sha256[0] = 'b'; m.available_capabilities.clear();
    });
    add([](Message& m) {
        m.kind = NATravPeerHandshakeMessageKind::hello;
        m.artifact.sha256[0] = 'b'; m.available_capabilities.clear();
    });
    add([](Message& m) {
        m.artifact.sha256[0] = 'b'; m.available_capabilities.clear();
    });
    add([](Message& m) {
        m.kind = NATravPeerHandshakeMessageKind::error;
        m.error_code = std::string("EMBEDDED\0CODE", 13U);
    });
    add([](Message& m) {
        m.kind = NATravPeerHandshakeMessageKind::error;
        m.error_code = "OPERATION_FAILED";  // A peer string is NOT a local fault.
    });
    return out;
}
struct Fixture {
    Expectation expectation;
    std::vector<Message> messages;
};
struct Seed {
    Session session;
    std::optional<HistoricalSession> historical;
    const std::vector<Message>* messages;
};
// The preserved pre-operation historical object owns an independent expected
// identity. Branch separately for every response so a first rejection cannot
// hide a later mismatch in protocol, artifact or capability ownership.
void continuation(Results& r, const Session& actual, const Seed& reference) {
    const Observation initial = actual.observation();
    const auto& messages = *reference.messages;
    if (!reference.historical) {
        check(r, actual.moved_from() && !actual.operation_failed() &&
            initial.status == Status::moved_from && initial.classification == "MOVED_FROM" &&
            initial.responses_observed == 0U && initial.terminal, "inert_continuation_seed");
        for (const auto& message : messages) {
            Session s(actual);
            ++r.continuation_checks;
            check(r, same(s.observe_response(message), initial) &&
                same(s.observe_unavailability(NATravPeerHandshakeEvent::early_eof), initial),
                "inert_continuation");
        }
        return;
    }
    auto compare = [&](const Observation& ao, const Observation& bo) {
        ++r.continuation_checks;
        check(r, same(ao, bo), "historical_exact_continuation");
    };
    compare(initial, reference.historical->observation());
    check(r, !actual.moved_from() && actual.operation_failed() ==
        reference.historical->operation_failed(), "ownership_flags");
    for (const auto& message : messages) {
        Session a(actual); HistoricalSession b(*reference.historical);
        compare(a.observe_response(message), b.observe_response(message));
        compare(a.observe_response(messages.front()), b.observe_response(messages.front()));
        compare(a.observe_unavailability(NATravPeerHandshakeEvent::timeout),
                b.observe_unavailability(NATravPeerHandshakeEvent::timeout));
    }
    for (const auto event : {NATravPeerHandshakeEvent::timeout,
            NATravPeerHandshakeEvent::early_eof, NATravPeerHandshakeEvent::spawn_failure}) {
        Session a(actual); HistoricalSession b(*reference.historical);
        compare(a.observe_unavailability(event), b.observe_unavailability(event));
        compare(a.observe_response(messages.front()), b.observe_response(messages.front()));
    }
}
void inert(Results& r, Session& s, const Message& message) {
    const auto before = s.observation();
    const bool canonical = s.moved_from() && !s.operation_failed() &&
        before.status == Status::moved_from && before.classification == "MOVED_FROM" &&
        before.responses_observed == 0U && before.terminal;
    check(r, canonical, "inert_handshake_invariant");
    if (!canonical) { return; }
    // Both normally returning and persistent-failure snapshots must be inert;
    // snapshots may allocate. Do not promise allocation-free std::string copies.
    for (const bool persistent : {false, true}) {
        for (const unsigned op : {0U, 1U, 2U, 3U, 4U}) {
            bool exact = true;
            arm(persistent ? 0U : std::numeric_limits<std::size_t>::max(), persistent);
            try {
                const auto observed = op == 0U ? s.observe_response(message) :
                    op == 4U ? s.observation() : s.observe_unavailability(
                        static_cast<NATravPeerHandshakeEvent>(op - 1U));
                exact = same(observed, before);
            } catch (const InjectedBadAlloc&) { ++r.inert_snapshot_throws; }
            const auto attempts = fault.attempts;
            const bool flags = s.moved_from() && !s.operation_failed();
            check(r, flags && fault.attempts == attempts, "inert_flags_noallocation");
            disarm();
            ++r.inert_probes;
            check(r, exact && same(s.observation(), before), "inert_state_frozen");
        }
    }
}
[[nodiscard]] std::vector<Seed> seeds(Results& r, const std::vector<Fixture>& fixtures,
                                     std::vector<std::size_t>& dest) {
    std::vector<Seed> out;
    for (const auto& f : fixtures) {
        auto add = [&](Session s, HistoricalSession h, const bool selected) {
            if (selected) { dest.push_back(out.size()); }
            check(r, same(s.observation(), h.observation()), "initial_historical_state");
            out.push_back({std::move(s), std::move(h), &f.messages});
        };
        add(Session(f.expectation), HistoricalSession(f.expectation), true);
        for (std::size_t i = 0U; i < f.messages.size(); ++i) {
            Session s(f.expectation); HistoricalSession h(f.expectation);
            static_cast<void>(s.observe_response(f.messages[i]));
            static_cast<void>(h.observe_response(f.messages[i]));
            add(std::move(s), std::move(h), (&f == &fixtures.front() &&
                (i == 0U || i == 1U || i == 26U || i + 1U == f.messages.size())));
        }
        for (const std::size_t count : {2U, 7U}) {
            Session s(f.expectation); HistoricalSession h(f.expectation);
            for (std::size_t i = 0U; i < count; ++i) {
                static_cast<void>(s.observe_response(f.messages.front()));
                static_cast<void>(h.observe_response(f.messages.front()));
            }
            add(std::move(s), std::move(h), false);
        }
        for (const auto event : {NATravPeerHandshakeEvent::timeout,
                NATravPeerHandshakeEvent::early_eof, NATravPeerHandshakeEvent::spawn_failure}) {
            Session s(f.expectation); HistoricalSession h(f.expectation);
            static_cast<void>(s.observe_unavailability(event));
            static_cast<void>(h.observe_unavailability(event));
            add(std::move(s), std::move(h), &f == &fixtures.front());
        }
        // First and second allocations of a long correlation classification
        // exercise precommit and returned-snapshot failure states.
        for (const std::size_t point : {0U, 1U}) {
            Session s(f.expectation); HistoricalSession h(f.expectation);
            bool sc = false, hc = false;
            arm(point, true);
            try { static_cast<void>(s.observe_response(f.messages[1U])); }
            catch (const InjectedBadAlloc& e) { sc = e.point == point; }
            disarm(); arm(point, true);
            try { static_cast<void>(h.observe_response(f.messages[1U])); }
            catch (const InjectedBadAlloc& e) { hc = e.point == point; }
            disarm();
            check(r, sc && hc && s.operation_failed() && h.operation_failed(), "failed_seed");
            ++r.failed_seeds;
            add(std::move(s), std::move(h), &f == &fixtures.front());
        }
        Session donor(f.expectation); Session owner(std::move(donor));
        if (&f == &fixtures.front()) { dest.push_back(out.size()); }
        out.push_back({donor, std::nullopt, &f.messages});
    }
    r.seeds = out.size(); r.destinations = dest.size();
    return out;
}
// Run the exact predecessor's memberwise assignment independently. Some
// failed assignments preserve all public scalars while changing hidden identity;
// a valid old-destination response then differs from its untouched oracle.
void historical_copy(Results& r, const Fixture& source, const Fixture& destination) {
    HistoricalSession s(source.expectation), d(destination.expectation);
    arm(std::numeric_limits<std::size_t>::max(), false);
    d = s;
    const auto points = fault.attempts; disarm();
    for (const bool persistent : {false, true}) {
        for (std::size_t point = 0U; point < points; ++point) {
            HistoricalSession a(source.expectation), b(destination.expectation);
            HistoricalSession untouched(b);
            bool caught = false;
            arm(point, persistent);
            try { b = a; }
            catch (const InjectedBadAlloc& e) { caught = e.point == point; }
            disarm();
            check(r, caught, "historical_copy_injection");
            ++r.historical_copy_faults;
            const bool same_snapshot = same(b.observation(), untouched.observation());
            bool changed = false;
            for (const auto& message : destination.messages) {
                HistoricalSession x(b), y(untouched);
                changed = !same(x.observe_response(message), y.observe_response(message)) || changed;
            }
            if (changed) {
                ++r.historical_partial_copies;
                if (same_snapshot) { ++r.historical_hidden_changes; }
            }
        }
    }
}
void construction(Results& r, const Seed& seed) {
    const auto before = seed.session.observation();
    Session source(seed.session);
    arm(0U, true);
    Session moved(std::move(source));
    noallocation(r, moved, source, "move_construction_allocated");
    ++r.move_constructions;
    check(r, same(moved.observation(), before), "move_constructor_transfer");
    inert(r, source, seed.messages->front());
    continuation(r, moved, seed);
    // Explicit moves preserve ownership when the source lifetime ends.
    Session surviving = [&]() {
        Session temporary(seed.session);
        arm(0U, true);
        Session result(std::move(temporary));
        noallocation(r, result, temporary, "short_lived_donor_allocated");
        return result;
    }();
    ++r.move_constructions;
    continuation(r, surviving, seed);

    arm(std::numeric_limits<std::size_t>::max(), false);
    Session copied(seed.session);
    const auto points = fault.attempts; disarm();
    ++r.copy_constructions;
    continuation(r, copied, seed);
    for (const bool persistent : {false, true}) {
        for (std::size_t point = 0U; point <= points; ++point) {
            bool caught = false;
            arm(point, persistent);
            try { Session trial(seed.session); }
            catch (const InjectedBadAlloc& e) {
                caught = e.point == point;
                ++r.exception_allocation_checks;
                check(r, fault.attempts == point + 1U, "copy_exception_attempts");
            }
            disarm();
            if (point == points) {
                ++r.success_boundaries;
                check(r, !caught, "copy_constructor_success_boundary");
            } else {
                ++r.faults; r.original_exceptions += caught ? 1U : 0U;
                ++r.strong_guarantee_checks;
                check(r, caught && same(seed.session.observation(), before),
                      "copy_constructor_source_preserved");
                continuation(r, seed.session, seed);
            }
        }
    }
    for (const unsigned op : {0U, 1U, 2U, 3U, 4U}) {
        Session self(seed.session);
        auto& alias = self; const auto& const_alias = self;
        arm(0U, true);
        switch (op) {
            case 0U: self = std::move(alias); break;
            case 1U: self = const_alias; break;
            case 2U: self.swap(alias); break;
            case 3U: swap(self, alias); break;
            default: std::swap(self, alias); break;
        }
        noallocation(r, self, self, "self_operation_allocated");
        ++r.self_operations;
        check(r, same(self.observation(), before), "self_operation_identity");
        continuation(r, self, seed);
    }
}
void assignment(Results& r, const Seed& source_seed, const Seed& dest_seed,
                const bool inject) {
    const auto source_before = source_seed.session.observation();
    const auto dest_before = dest_seed.session.observation();
    Session source(source_seed.session), dest(dest_seed.session);
    arm(0U, true);
    Session* returned = &(dest = std::move(source));
    noallocation(r, source, dest, "move_assignment_allocated");
    ++r.move_assignments;
    check(r, returned == &dest && same(dest.observation(), source_before),
          "move_assignment_transfer");
    inert(r, source, source_seed.messages->front());
    continuation(r, dest, source_seed);
    // Replacing an inert source by an independently prepared healthy owner is
    // a new object value, not a retry of consumed protocol input.
    Session replacement(dest_seed.session);
    arm(0U, true);
    source = std::move(replacement);
    noallocation(r, source, replacement, "explicit_replacement_allocated");
    ++r.move_assignments;
    continuation(r, source, dest_seed);
    inert(r, replacement, dest_seed.messages->front());

    Session copy_source(source_seed.session), copy_dest(dest_seed.session);
    arm(std::numeric_limits<std::size_t>::max(), false);
    returned = &(copy_dest = copy_source);
    const auto points = fault.attempts; disarm();
    ++r.copy_assignments;
    check(r, returned == &copy_dest && same(copy_dest.observation(), source_before) &&
        same(copy_source.observation(), source_before), "copy_assignment_transfer");
    continuation(r, copy_dest, source_seed);
    if (inject) {
        for (const bool persistent : {false, true}) {
            for (std::size_t point = 0U; point <= points; ++point) {
                Session s(source_seed.session), d(dest_seed.session);
                bool caught = false;
                arm(point, persistent);
                try { d = s; }
                catch (const InjectedBadAlloc& e) {
                caught = e.point == point;
                ++r.exception_allocation_checks;
                check(r, fault.attempts == point + 1U, "copy_exception_attempts");
            }
                disarm();
                if (point == points) {
                    ++r.success_boundaries;
                    check(r, !caught && same(d.observation(), source_before),
                          "copy_assignment_success_boundary");
                    continuation(r, d, source_seed);
                } else {
                    ++r.faults; r.original_exceptions += caught ? 1U : 0U;
                    r.strong_guarantee_checks += 2U;
                    check(r, caught && same(s.observation(), source_before) &&
                        same(d.observation(), dest_before), "copy_assignment_strong_guarantee");
                    continuation(r, s, source_seed);
                    continuation(r, d, dest_seed);
                    d = s;
                    continuation(r, d, source_seed);
                }
            }
        }
    }
    for (const unsigned op : {0U, 1U, 2U}) {
        Session a(source_seed.session), b(dest_seed.session);
        arm(0U, true);
        switch (op) {
            case 0U: a.swap(b); break;
            case 1U: swap(a, b); break;
            default: std::swap(a, b); break;
        }
        noallocation(r, a, b, "swap_allocated");
        ++r.swaps;
        check(r, same(a.observation(), dest_before) && same(b.observation(), source_before),
              "swap_transfer");
        continuation(r, a, dest_seed); continuation(r, b, source_seed);
    }
}

int run() {
    static_assert(std::is_nothrow_move_constructible_v<Session>);
    static_assert(std::is_nothrow_move_assignable_v<Session>);
    static_assert(std::is_nothrow_swappable_v<Session>);
    static_assert(std::is_copy_constructible_v<Session>);
    static_assert(std::is_copy_assignable_v<Session>);
    static_assert(noexcept(std::declval<const Session&>().moved_from()));
    static_assert(noexcept(std::declval<const Session&>().operation_failed()));
    static_assert(static_cast<int>(Status::operation_failed) == 10);
    static_assert(static_cast<int>(Status::moved_from) == 11);
    Results r;
    check(r, natrav_peer_handshake_status_name(Status::moved_from) == "MOVED_FROM", "status_name");
    std::vector<Fixture> fixtures;
    fixtures.reserve(6U);
    for (const std::size_t variant : {0U, 1U, 2U, 3U, 4U, 7U}) {
        const auto e = expectation(variant);
        auto m = responses(e);
        auto reserved = m.front();
        reserved.kind = NATravPeerHandshakeMessageKind::error;
        reserved.error_code = "MOVED_FROM";
        m.push_back(std::move(reserved));
        fixtures.push_back({e, std::move(m)});
    }
    std::vector<std::size_t> destinations;
    const auto all = seeds(r, fixtures, destinations);
    for (const auto& seed : all) {
        continuation(r, seed.session, seed);
        construction(r, seed);
        for (std::size_t i = 0U; i < destinations.size(); ++i) {
            const auto index = destinations[i];
            check(r, index < all.size(), "destination_index");
            // Sweep every allocation for every selected destination, not only
            // successful scalar replacements or a subset of failure ordinals.
            assignment(r, seed, all[index], true);
        }
    }
    for (const auto& a : fixtures) {
        for (const auto& b : fixtures) { historical_copy(r, a, b); }
    }
    check(r, r.faults != 0U && r.original_exceptions == r.faults &&
        r.exception_allocation_checks == r.faults && r.failed_seeds != 0U &&
        r.inert_probes != 0U && r.historical_hidden_changes != 0U, "coverage");
#define NATRAV_HANDSHAKE_LIFECYCLE_PRINT(name) std::printf(#name "=%zu\n", r.name)
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(seeds);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(destinations);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(move_constructions);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(copy_constructions);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(move_assignments);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(copy_assignments);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(swaps);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(self_operations);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(faults);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(original_exceptions);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(strong_guarantee_checks);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(inert_probes);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(inert_snapshot_throws);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(noallocation_checks);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(continuation_checks);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(failed_seeds);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(success_boundaries);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(exception_allocation_checks);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(historical_copy_faults);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(historical_partial_copies);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(historical_hidden_changes);
    NATRAV_HANDSHAKE_LIFECYCLE_PRINT(failures);
#undef NATRAV_HANDSHAKE_LIFECYCLE_PRINT
    return r.failures == 0U ? 0 : 1;
}
}  // namespace natrav_handshake_lifecycle_test
int main() {
    try { return natrav_handshake_lifecycle_test::run(); }
    catch (const std::exception& e) {
        natrav_allocation_test::disarm();
        std::fprintf(stderr, "UNEXPECTED %s\n", e.what());
        return 2;
    }
}
#endif  // DATACUBE_NATRAV_HANDSHAKE_LIFECYCLE_TEST

#ifdef DATACUBE_NATRAV_HANDSHAKE_CAPABILITY_TEST
#include <stdexcept>
namespace natrav_handshake_capability_test {
using namespace datacube;
using namespace natrav_allocation_test;
// Exact revision-0466 class and method bodies, with a local class name only.
// Its sorted-input algorithm is NEVER used as an oracle for malformed order.
class HistoricalSession final {
public:
    explicit HistoricalSession(
        NATravPeerHandshakeExpectation expectation);

    // Value copying is deep. Assignment stages the whole correlated value;
    // a throwing copy leaves both operands (and their continuations) unchanged.
    HistoricalSession(const HistoricalSession&) = default;
    HistoricalSession& operator=(const HistoricalSession& other);
    // Distinct moves transfer all state and leave a terminal, inert donor.
    // Self-copy, self-move and self-swap preserve the value without allocation.
    HistoricalSession(HistoricalSession&& other) noexcept;
    HistoricalSession& operator=(HistoricalSession&& other) noexcept;
    ~HistoricalSession() = default;
    void swap(HistoricalSession& other) noexcept;
    friend void swap(HistoricalSession& left,
                     HistoricalSession& right) noexcept {
        left.swap(right);
    }

    [[nodiscard]] NATravPeerHandshakeObservation observe_response(
        const NATravPeerHandshakeMessage& response);
    [[nodiscard]] NATravPeerHandshakeObservation observe_unavailability(
        NATravPeerHandshakeEvent event);
    [[nodiscard]] NATravPeerHandshakeObservation observation() const;

    // Active-operation exceptions latch a terminal, discard-and-reconstruct
    // state before propagating unchanged. No rollback or retry is promised.
    // This query never allocates, even while observation snapshots may throw.
    [[nodiscard]] bool operation_failed() const noexcept;
    [[nodiscard]] bool moved_from() const noexcept;

private:
    [[nodiscard]] NATravPeerHandshakeObservation terminate(
        NATravPeerHandshakeStatus status,
        std::string classification);

    NATravPeerHandshakeExpectation expectation_;
    NATravPeerHandshakeStatus status_{NATravPeerHandshakeStatus::awaiting_response};
    std::string classification_{"AWAITING_RESPONSE"};
    std::size_t responses_observed_{0U};
    bool terminal_{false};
};

[[nodiscard]] bool required_capabilities_available(
    const std::vector<std::string>& required,
    const std::vector<std::string>& available) noexcept {
    return std::includes(
        available.begin(), available.end(), required.begin(), required.end());
}

HistoricalSession::HistoricalSession(
    NATravPeerHandshakeExpectation expectation)
    : expectation_(std::move(expectation)) {}

HistoricalSession::HistoricalSession(
    HistoricalSession&& other) noexcept
    : expectation_(std::move(other.expectation_)),
      status_(other.status_),
      classification_(std::move(other.classification_)),
      responses_observed_(other.responses_observed_),
      terminal_(other.terminal_) {
    static_assert(std::is_nothrow_move_constructible_v<NATravPeerHandshakeExpectation>);
    static_assert(std::is_nothrow_move_constructible_v<std::string>);
    // Retire the donor without constructing a classification or allocating.
    // Clear correlated identity metadata as well as all public accounting.
    other.expectation_.protocol.id.clear();
    other.expectation_.protocol.major = 0;
    other.expectation_.protocol.minor = 0;
    other.expectation_.request_id.clear();
    other.expectation_.expected_artifact.sha256.clear();
    other.expectation_.expected_artifact.target.clear();
    other.expectation_.expected_artifact.version.clear();
    other.expectation_.required_capabilities.clear();
    other.status_ = NATravPeerHandshakeStatus::moved_from;
    other.classification_.clear();
    other.responses_observed_ = 0U;
    other.terminal_ = true;
}

HistoricalSession& HistoricalSession::operator=(
    HistoricalSession&& other) noexcept {
    if (this != &other) {
        HistoricalSession replacement(std::move(other));
        swap(replacement);
    }
    return *this;
}

HistoricalSession& HistoricalSession::operator=(
    const HistoricalSession& other) {
    if (this != &other) {
        // Commit only after every identity, capability and classification has
        // been copied. Partial assignment of this aggregate is not safe.
        HistoricalSession replacement(other);
        swap(replacement);
    }
    return *this;
}

void HistoricalSession::swap(HistoricalSession& other) noexcept {
    if (this == &other) { return; }
    static_assert(std::is_nothrow_swappable_v<NATravPeerHandshakeExpectation>);
    using std::swap;
    swap(expectation_, other.expectation_);
    swap(status_, other.status_);
    classification_.swap(other.classification_);
    swap(responses_observed_, other.responses_observed_);
    swap(terminal_, other.terminal_);
}

bool HistoricalSession::moved_from() const noexcept {
    return status_ == NATravPeerHandshakeStatus::moved_from;
}

NATravPeerHandshakeObservation HistoricalSession::terminate(
    const NATravPeerHandshakeStatus status,
    std::string classification) {
    status_ = status;
    classification_ = std::move(classification);
    terminal_ = true;
    return observation();
}

NATravPeerHandshakeObservation HistoricalSession::observe_response(
    const NATravPeerHandshakeMessage& response) {
    if (operation_failed() || moved_from()) { return observation(); }
    try {
        if (terminal_) {
            ++responses_observed_;
            return terminate(
                NATravPeerHandshakeStatus::replay_rejected,
                "REPLAY_REJECTED");
        }
        ++responses_observed_;

        if (response.request_id != expectation_.request_id) {
            return terminate(
                NATravPeerHandshakeStatus::correlation_rejected,
                "CORRELATION_REJECTED");
        }
        if (response.protocol.id != expectation_.protocol.id ||
            response.protocol.major != expectation_.protocol.major ||
            response.protocol.minor < expectation_.protocol.minor) {
            return terminate(
                NATravPeerHandshakeStatus::protocol_mismatch,
                "PROTOCOL_MISMATCH");
        }
        if (response.kind == NATravPeerHandshakeMessageKind::error) {
            return terminate(
                NATravPeerHandshakeStatus::peer_error,
                response.error_code);
        }
        if (response.kind != NATravPeerHandshakeMessageKind::hello_ack) {
            return terminate(
                NATravPeerHandshakeStatus::message_kind_rejected,
                "MESSAGE_KIND_REJECTED");
        }
        if (response.artifact.sha256 != expectation_.expected_artifact.sha256 ||
            response.artifact.target != expectation_.expected_artifact.target ||
            response.artifact.version != expectation_.expected_artifact.version) {
            return terminate(
                NATravPeerHandshakeStatus::artifact_identity_mismatch,
                "ARTIFACT_IDENTITY_MISMATCH");
        }
        if (!required_capabilities_available(
                expectation_.required_capabilities,
                response.available_capabilities)) {
            return terminate(
                NATravPeerHandshakeStatus::capability_mismatch,
                "CAPABILITY_MISMATCH");
        }
        return terminate(NATravPeerHandshakeStatus::accepted, "ACCEPTED");
    } catch (...) {
        // Scalar writes only: a persistent allocation failure must not prevent
        // the latch or replace the original exception. Retain partial counts.
        status_ = NATravPeerHandshakeStatus::operation_failed;
        terminal_ = true;
        throw;
    }
}

NATravPeerHandshakeObservation
HistoricalSession::observe_unavailability(
    const NATravPeerHandshakeEvent event) {
    static_cast<void>(event);
    if (terminal_) {
        return observation();
    }
    try {
        return terminate(
            NATravPeerHandshakeStatus::peer_unavailable,
            "PEER_UNAVAILABLE");
    } catch (...) {
        // Already-terminal calls above are snapshots, not active operations.
        status_ = NATravPeerHandshakeStatus::operation_failed;
        terminal_ = true;
        throw;
    }
}

NATravPeerHandshakeObservation HistoricalSession::observation() const {
    return NATravPeerHandshakeObservation{
        .status = status_,
        .classification = (operation_failed() || moved_from())
            ? std::string(natrav_peer_handshake_status_name(status_))
            : classification_,
        .responses_observed = responses_observed_,
        .terminal = terminal_,
    };
}

bool HistoricalSession::operation_failed() const noexcept {
    return status_ == NATravPeerHandshakeStatus::operation_failed;
}

using Session = NATravPeerHandshakeSession;
using Status = NATravPeerHandshakeStatus;
using Observation = NATravPeerHandshakeObservation;
using Message = NATravPeerHandshakeMessage;
using Expectation = NATravPeerHandshakeExpectation;
using Capabilities = std::vector<std::string>;
struct Results {
    std::size_t vectors{}, pairs{}, decisions{}, declaration_rejections{};
    std::size_t accepted{}, missing{}, historical_comparisons{}, priority_checks{};
    std::size_t replay_checks{}, input_preservation_checks{}, wire_checks{};
    std::size_t stream_checks{}, opaque_string_checks{}, lifecycle_checks{};
    std::size_t faults{}, original_exceptions{}, active_faults{}, snapshot_faults{}, copy_faults{};
    std::size_t frozen_checks{}, strong_guarantee_checks{}, noallocation_checks{};
    std::size_t success_boundaries{}, failures{};
};
void check(Results& r, const bool pass, const char* label) {
    if (pass) { return; }
    ++r.failures;
    if (r.failures <= 16U) { std::fprintf(stderr, "FAILED %s\n", label); }
}
[[nodiscard]] bool same(const Observation& a, const Observation& b) noexcept {
    return a.status == b.status && a.classification == b.classification &&
        a.responses_observed == b.responses_observed && a.terminal == b.terminal;
}
// Independent all-pairs order/uniqueness oracle, not the adjacent production
// check. Membership uses linear search and has no sorted-range precondition.
[[nodiscard]] bool valid_order(const Capabilities& c) {
    for (std::size_t i = 0U; i < c.size(); ++i) {
        for (std::size_t j = i + 1U; j < c.size(); ++j) {
            if (c[i].compare(c[j]) >= 0) { return false; }
        }
    }
    return true;
}
[[nodiscard]] bool contains_all(const Capabilities& required,
                                 const Capabilities& available) {
    for (const auto& value : required) {
        if (std::find(available.begin(), available.end(), value) == available.end()) {
            return false;
        }
    }
    return true;
}
[[nodiscard]] Status result_for(const Capabilities& required,
                                const Capabilities& available) {
    if (!valid_order(required) || !valid_order(available)) {
        return Status::capability_declaration_rejected;
    }
    return contains_all(required, available) ? Status::accepted : Status::capability_mismatch;
}
[[nodiscard]] Expectation expectation(const Capabilities& required) {
    return {{"NATRAV_OVERLAY_PEER", 1, 0}, std::string(64U, 'a'),
        {std::string(64U, 'b'), "x86_64-unknown-linux-gnu", "0.1.0"}, required};
}
[[nodiscard]] Message response(const Expectation& e, const Capabilities& available) {
    Message m;
    m.kind = NATravPeerHandshakeMessageKind::hello_ack;
    m.protocol = e.protocol; m.request_id = e.request_id;
    m.artifact = e.expected_artifact; m.available_capabilities = available;
    return m;
}
void observed(Results& r, const Observation& o, const Status status,
              const std::size_t count, const char* label) {
    check(r, o.status == status && o.classification == natrav_peer_handshake_status_name(status) &&
        o.terminal && o.responses_observed == count, label);
}
[[nodiscard]] std::vector<Capabilities> all_vectors() {
    std::vector<Capabilities> out{{}};
    std::size_t start = 0U, stop = 1U;
    for (std::size_t length = 1U; length <= 4U; ++length) {
        for (std::size_t i = start; i < stop; ++i) {
            for (const char* token : {"A", "B", "C"}) {
                Capabilities c(out[i]); c.emplace_back(token); out.push_back(std::move(c));
            }
        }
        start = stop; stop = out.size();
    }
    return out;
}
constexpr NATravPeerHandshakeEvent events[]{NATravPeerHandshakeEvent::timeout,
    NATravPeerHandshakeEvent::early_eof, NATravPeerHandshakeEvent::spawn_failure};
void pair_test(Results& r, const Capabilities& required, const Capabilities& available) {
    const auto e = expectation(required);
    const auto m = response(e, available);
    const auto saved_e = e; const auto saved_m = m;
    const Status expected = result_for(required, available);
    Session s(e);
    const auto initial = s.observe_response(m);
    observed(r, initial, expected, 1U, "capability-decision");
    ++r.decisions; ++r.pairs;
    if (expected == Status::accepted) { ++r.accepted; }
    else if (expected == Status::capability_mismatch) { ++r.missing; }
    else { ++r.declaration_rejections; }
    // Do not run the predecessor's std::includes outside its sorted contract.
    if (valid_order(required) && valid_order(available)) {
        HistoricalSession old(e);
        check(r, same(initial, old.observe_response(m)), "exact-predecessor-canonical");
        ++r.historical_comparisons;
    }
    for (const auto event : events) {
        check(r, same(initial, s.observe_unavailability(event)), "terminal-unavailability");
        ++r.replay_checks;
    }
    for (std::size_t count = 2U; count <= 3U; ++count) {
        observed(r, s.observe_response(m), Status::replay_rejected, count, "replay-priority");
        ++r.replay_checks;
    }
    // Capability shape must not override the established earlier decisions.
    for (std::size_t variant = 0U; variant < 10U; ++variant) {
        Message changed(m); Status priority = Status::protocol_mismatch;
        switch (variant) {
            case 0U: changed.request_id += "x"; ++changed.protocol.major;
                priority = Status::correlation_rejected; break;
            case 1U: changed.protocol.id += "x"; break;
            case 2U: ++changed.protocol.major; break;
            case 3U: --changed.protocol.minor; break;
            case 4U: changed.kind = NATravPeerHandshakeMessageKind::hello;
                priority = Status::message_kind_rejected; break;
            case 5U: changed.kind = NATravPeerHandshakeMessageKind::unknown;
                priority = Status::message_kind_rejected; break;
            case 6U: changed.artifact.sha256[0] = 'c';
                priority = Status::artifact_identity_mismatch; break;
            case 7U: changed.artifact.target += "x";
                priority = Status::artifact_identity_mismatch; break;
            case 8U: changed.artifact.version += "x";
                priority = Status::artifact_identity_mismatch; break;
            default: changed.kind = NATravPeerHandshakeMessageKind::error;
                changed.error_code = "CAPABILITY_DECLARATION_REJECTED";
                priority = Status::peer_error; break;
        }
        Session subject(e); HistoricalSession old(e);
        const auto got = subject.observe_response(changed);
        const auto prior = old.observe_response(changed);
        check(r, got.status == priority && same(got, prior), "predecessor-priority");
        ++r.priority_checks; ++r.historical_comparisons;
    }
    check(r, e.required_capabilities == saved_e.required_capabilities &&
        m.available_capabilities == saved_m.available_capabilities &&
        m.required_capabilities == saved_m.required_capabilities &&
        m.request_id == saved_m.request_id && m.protocol.id == saved_m.protocol.id &&
        m.artifact.sha256 == saved_m.artifact.sha256, "caller-input-unchanged");
    ++r.input_preservation_checks;
}
// Construct canonical JSON spelling even for deliberately unsorted arrays;
// the wire decoder must reject declaration shape, not normalize it.
[[nodiscard]] Octets raw_payload(const Message& input, const Capabilities& caps) {
    Message base(input);
    base.available_capabilities.clear(); base.required_capabilities.clear();
    const auto encoded = natrav_peer_encode_message(base);
    if (!encoded.payload) { throw std::logic_error("invalid wire test template"); }
    std::string text(reinterpret_cast<const char*>(encoded.payload->data()), encoded.payload->size());
    const std::string key = input.kind == NATravPeerHandshakeMessageKind::hello ?
        "\"required_capabilities\":[]" : "\"available_capabilities\":[]";
    const auto at = text.find(key);
    if (at == std::string::npos) { throw std::logic_error("missing wire test array"); }
    std::string array("[");
    for (std::size_t i = 0U; i < caps.size(); ++i) {
        if (i != 0U) { array += ','; }
        array += '"'; array += json_escape(caps[i]); array += '"';
    }
    array += ']';
    text.replace(at + key.size() - 2U, 2U, array);
    return text_octets(text);
}
void wire_test(Results& r, const Capabilities& caps) {
    const bool valid = valid_order(caps);  // Alphabet A/B/C is always token-valid.
    const auto e = expectation({"A"});
    auto m = response(e, caps);
    for (const auto kind : {NATravPeerHandshakeMessageKind::hello,
                            NATravPeerHandshakeMessageKind::hello_ack}) {
        m.kind = kind; m.available_capabilities.clear(); m.required_capabilities.clear();
        if (kind == NATravPeerHandshakeMessageKind::hello) { m.required_capabilities = caps; }
        else { m.available_capabilities = caps; }
        const auto encoded = natrav_peer_encode_message(m);
        check(r, encoded.status == (valid ? NATravPeerMessageEncodeStatus::accepted :
            NATravPeerMessageEncodeStatus::capability_declaration_rejected) &&
            encoded.payload.has_value() == valid, "wire-encoder-not-widened");
        ++r.wire_checks;
        const auto raw = raw_payload(m, caps);
        const auto decoded = natrav_peer_decode_message(raw);
        check(r, decoded.status == (valid ? NATravPeerMessageDecodeStatus::accepted :
            NATravPeerMessageDecodeStatus::capability_declaration_rejected) &&
            decoded.message.has_value() == valid, "wire-decoder-not-widened");
        ++r.wire_checks;
        if (valid) {
            check(r, *encoded.payload == raw, "exact-wire-spelling"); ++r.wire_checks;
        }
        if (kind == NATravPeerHandshakeMessageKind::hello_ack) {
            NATravPeerHandshakeStreamSession stream(e);
            const auto got = stream.feed(natrav_peer_encode_frame(raw));
            const auto expected = valid ? (contains_all(e.required_capabilities, caps) ?
                NATravPeerSessionStatus::accepted : NATravPeerSessionStatus::capability_mismatch) :
                NATravPeerSessionStatus::capability_declaration_rejected;
            check(r, got.status == expected && got.frames_observed == 1U &&
                got.messages_decoded == (valid ? 1U : 0U) &&
                got.handshake_transitions == (valid ? 1U : 0U), "wire-before-handshake");
            ++r.stream_checks;
        }
    }
    const NATravPeerClientHandshakeInput input{e.protocol, e.request_id,
        e.expected_artifact, e.expected_artifact, caps};
    const auto prepared = natrav_peer_prepare_client_handshake(input);
    check(r, prepared.status == (valid ? NATravPeerClientPreparationStatus::prepared :
        NATravPeerClientPreparationStatus::capability_declaration_rejected) &&
        prepared.prepared.has_value() == valid, "factory-not-widened"); ++r.wire_checks;
    // A malformed local expectation reaches typed admission only after a valid
    // wire message has decoded. Its rejection maps through the stream layer.
    const auto local = expectation(caps);
    const auto good = natrav_peer_encode_message(response(local, {"A", "B", "C"}));
    if (!good.payload) { throw std::logic_error("valid response not encoded"); }
    NATravPeerHandshakeStreamSession stream(local);
    const auto got = stream.feed(natrav_peer_encode_frame(*good.payload));
    check(r, got.status == (valid ? NATravPeerSessionStatus::accepted :
        NATravPeerSessionStatus::capability_declaration_rejected) &&
        got.classification == (valid ? "ACCEPTED" : "CAPABILITY_DECLARATION_REJECTED") &&
        got.frames_observed == 1U && got.messages_decoded == 1U &&
        got.handshake_transitions == 1U, "typed-expectation-stream-mapping");
    ++r.stream_checks;
}
void opaque_test(Results& r) {
    for (const std::string& token : std::vector<std::string>{"", "lower", "A-1", "A__B", "A_",
            "1A", std::string(65U, 'A'), std::string("A\0B", 3U), std::string(1U, '\xff')}) {
        const auto e = expectation({token}); const auto m = response(e, {token});
        Session s(e); HistoricalSession old(e);
        const auto got = s.observe_response(m);
        check(r, got.status == Status::accepted && same(got, old.observe_response(m)),
            "opaque-typed-string-preserved"); ++r.opaque_string_checks;
        check(r, natrav_peer_encode_message(m).status ==
            NATravPeerMessageEncodeStatus::capability_declaration_rejected,
            "opaque-string-not-wire-admission"); ++r.opaque_string_checks;
    }
}
void frozen(Results& r, const Session& failed, const Message& m) {
    const auto expected = failed.observation();
    for (const bool persistent : {false, true}) {
        for (std::size_t op = 0U; op < 5U; ++op) {
            Session probe(failed); arm(0U, persistent);
            try {
                if (op == 0U) { static_cast<void>(probe.observe_response(m)); }
                else if (op == 4U) { static_cast<void>(probe.observation()); }
                else { static_cast<void>(probe.observe_unavailability(events[op - 1U])); }
            } catch (const InjectedBadAlloc&) {} catch (...) { disarm(); throw; }
            disarm(); check(r, same(probe.observation(), expected), "failed-owner-frozen");
            ++r.frozen_checks;
        }
    }
}
void ownership_and_faults(Results& r, const Capabilities& caps) {
    const auto e = expectation(caps); const auto m = response(e, {"A", "B", "C"});
    Session rejected(e); const auto state = rejected.observe_response(m);
    observed(r, state, Status::capability_declaration_rejected, 1U, "rejected-seed");
    Session copied(rejected); check(r, same(copied.observation(), state), "copy-new-state");
    Session target(expectation({"C"})); target = rejected;
    check(r, same(target.observation(), state), "assignment-new-state");
    Session donor(rejected); arm(0U, true);
    Session moved(std::move(donor)); target = std::move(moved);
    Session& self = target;
    target = std::move(self); target = self; target.swap(self);
    const bool flags = donor.moved_from() && moved.moved_from() && !target.moved_from() &&
        !target.operation_failed();
    const auto attempted = fault.attempts; disarm();
    check(r, flags && attempted == 0U, "allocation-free-new-state-ownership");
    ++r.noallocation_checks;
    check(r, same(target.observation(), state), "complete-rejected-state-transfer");
    observed(r, target.observe_response(m), Status::replay_rejected, 2U, "copied-state-replay");
    r.lifecycle_checks += 5U;
    // Four operations: active declaration rejection; read-only terminal
    // snapshot; replay rejection; and transactional copy replacement.
    for (std::size_t op = 0U; op < 4U; ++op) {
        Session baseline(op == 3U ? Session(expectation({"C"})) :
            (op == 0U ? Session(e) : rejected));
        Session source(rejected);
        auto invoke = [&](Session& owner) {
            if (op == 1U) { static_cast<void>(owner.observe_unavailability(events[0])); }
            else if (op == 3U) { owner = source; }
            else { static_cast<void>(owner.observe_response(m)); }
        };
        arm(std::numeric_limits<std::size_t>::max(), false);
        invoke(baseline); const auto allocations = fault.attempts; disarm();
        const auto success = baseline.observation();
        for (const bool persistent : {false, true}) {
            for (std::size_t point = 0U; point <= allocations; ++point) {
                Session subject(op == 3U ? Session(expectation({"C"})) :
                    (op == 0U ? Session(e) : rejected));
                const auto before = subject.observation(); const auto source_before = source.observation();
                bool caught = false, original = false;
                arm(point, persistent);
                try { invoke(subject); }
                catch (const InjectedBadAlloc& error) { caught = true; original = error.point == point; }
                catch (...) { disarm(); throw; }
                const auto attempts = fault.attempts; disarm();
                if (!caught) {
                    check(r, point == allocations && same(subject.observation(), success), "fault-success-boundary");
                    ++r.success_boundaries; continue;
                }
                ++r.faults;
                check(r, original && attempts == point + 1U, "original-exception-noallocation");
                if (original) { ++r.original_exceptions; }
                if (op == 0U || op == 2U) {
                    ++r.active_faults;
                    check(r, subject.operation_failed() && subject.observation().terminal &&
                        subject.observation().responses_observed == (op == 0U ? 1U : 2U), "new-path-fail-stop");
                    frozen(r, subject, m);
                } else {
                    if (op == 3U) { ++r.copy_faults; }
                    else { ++r.snapshot_faults; }
                    check(r, same(subject.observation(), before) &&
                        same(source.observation(), source_before), "snapshot-or-assignment-preserved");
                    if (op == 3U) {
                        r.strong_guarantee_checks += 2U;
                        Session continuation(subject);
                        const auto own = expectation({"C"});
                        observed(r, continuation.observe_response(response(own, {"C"})),
                            Status::accepted, 1U, "copy-fault-hidden-expectation");
                        ++r.strong_guarantee_checks;
                    }
                }
                arm(0U, true); static_cast<void>(subject.operation_failed());
                static_cast<void>(subject.moved_from());
                const auto query_attempts = fault.attempts; disarm();
                check(r, query_attempts == 0U, "queries-noallocation"); ++r.noallocation_checks;
            }
        }
    }
}
int run() {
    Results r;
    static_assert(static_cast<int>(Status::moved_from) == 11);
    static_assert(static_cast<int>(Status::capability_declaration_rejected) == 12);
    const auto vectors = all_vectors(); r.vectors = vectors.size();
    for (const auto& a : vectors) {
        wire_test(r, a);
        for (const auto& b : vectors) { pair_test(r, a, b); }
        if (!valid_order(a)) { ownership_and_faults(r, a); }
    }
    opaque_test(r);
    // Larger declarations, late inversions and duplicates, string boundaries,
    // and opaque string ordering exercise more than the three-token matrix.
    Capabilities large;
    for (std::size_t i = 0U; i < 128U; ++i) { large.push_back("CAP" + std::to_string(i)); }
    std::sort(large.begin(), large.end());
    Capabilities reversed(large); std::reverse(reversed.begin(), reversed.end());
    Capabilities duplicate(large); duplicate.push_back(large.back());
    Capabilities late(large); std::swap(late[126U], late[127U]);
    for (const auto& a : std::vector<Capabilities>{{}, {"CAP1"}, large, reversed, duplicate, late,
            {std::string(15U, 'A'), std::string(16U, 'A'), std::string(64U, 'A')},
            {"", std::string("A\0", 2U), "B"}}) {
        for (const auto& b : std::vector<Capabilities>{large, reversed, duplicate, late, a}) {
            pair_test(r, a, b);
        }
    }
    check(r, r.vectors == 121U && r.pairs == 14681U && r.declaration_rejections != 0U &&
        r.accepted != 0U && r.missing != 0U && r.faults != 0U &&
        r.active_faults != 0U && r.strong_guarantee_checks != 0U, "coverage");
#define NATRAV_CAP_PRINT(name) std::printf(#name "=%zu\n", r.name)
    NATRAV_CAP_PRINT(vectors); NATRAV_CAP_PRINT(pairs); NATRAV_CAP_PRINT(decisions);
    NATRAV_CAP_PRINT(declaration_rejections); NATRAV_CAP_PRINT(accepted); NATRAV_CAP_PRINT(missing);
    NATRAV_CAP_PRINT(historical_comparisons); NATRAV_CAP_PRINT(priority_checks);
    NATRAV_CAP_PRINT(replay_checks); NATRAV_CAP_PRINT(input_preservation_checks);
    NATRAV_CAP_PRINT(wire_checks); NATRAV_CAP_PRINT(stream_checks); NATRAV_CAP_PRINT(opaque_string_checks);
    NATRAV_CAP_PRINT(lifecycle_checks); NATRAV_CAP_PRINT(faults); NATRAV_CAP_PRINT(original_exceptions);
    NATRAV_CAP_PRINT(active_faults); NATRAV_CAP_PRINT(snapshot_faults); NATRAV_CAP_PRINT(copy_faults); NATRAV_CAP_PRINT(frozen_checks);
    NATRAV_CAP_PRINT(strong_guarantee_checks); NATRAV_CAP_PRINT(noallocation_checks);
    NATRAV_CAP_PRINT(success_boundaries); NATRAV_CAP_PRINT(failures);
#undef NATRAV_CAP_PRINT
    return r.failures == 0U ? 0 : 1;
}
}  // namespace natrav_handshake_capability_test
int main() {
    try { return natrav_handshake_capability_test::run(); }
    catch (const std::exception& error) {
        natrav_allocation_test::disarm(); std::fprintf(stderr, "FAILED exception %s\n", error.what()); return 2;
    }
}
#endif  // DATACUBE_NATRAV_HANDSHAKE_CAPABILITY_TEST
