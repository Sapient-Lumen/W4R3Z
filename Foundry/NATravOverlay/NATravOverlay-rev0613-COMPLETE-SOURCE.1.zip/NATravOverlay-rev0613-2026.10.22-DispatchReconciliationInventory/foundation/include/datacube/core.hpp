#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

#include <sys/stat.h>

namespace datacube {

using Octets = std::vector<std::uint8_t>;
using OctetView = std::span<const std::uint8_t>;

class Failure final : public std::runtime_error {
public:
    Failure(std::string code, std::string detail);
    [[nodiscard]] const std::string& code() const noexcept;
private:
    std::string code_;
};

[[noreturn]] void fail(std::string_view code, std::string_view detail);

class Fd final {
public:
    Fd() noexcept = default;
    explicit Fd(int fd) noexcept;
    ~Fd();
    Fd(const Fd&) = delete;
    Fd& operator=(const Fd&) = delete;
    Fd(Fd&& other) noexcept;
    Fd& operator=(Fd&& other) noexcept;
    [[nodiscard]] int get() const noexcept;
    [[nodiscard]] explicit operator bool() const noexcept;
    [[nodiscard]] int release() noexcept;
    void reset(int fd = -1) noexcept;
private:
    int fd_{-1};
};

struct FileObservation {
    std::uint64_t device{0U};
    std::uint64_t inode{0U};
    std::uint64_t size{0U};
    std::uint64_t links{0U};
    std::uint32_t mode{0U};
    std::uint64_t uid{0U};
    std::uint64_t gid{0U};
};

struct OperationRoot {
    Fd fd;
    std::string requested_locator;
    std::string acquired_locator;
    FileObservation observation;
};

[[nodiscard]] FileObservation observe_fd(int fd, std::string_view locator);
[[nodiscard]] bool same_file_observation(
    const FileObservation& left,
    const FileObservation& right) noexcept;

[[nodiscard]] Octets read_all_fd(
    int fd,
    std::uint64_t ceiling,
    std::string_view locator);
[[nodiscard]] Octets read_file_at(
    int directory_fd,
    std::string_view leaf,
    std::uint64_t ceiling,
    std::string_view locator);
void write_all_fd(int fd, OctetView bytes, std::string_view locator);
void pwrite_all_fd(
    int fd,
    OctetView bytes,
    std::uint64_t offset,
    std::string_view locator);
void fsync_fd(int fd, std::string_view locator);

[[nodiscard]] Fd open_self_readonly();
[[nodiscard]] OperationRoot open_operation_root(std::string_view locator);
[[nodiscard]] Fd open_relative_directory_beneath(
    int root_fd,
    std::string_view relative_path,
    std::string_view locator);
[[nodiscard]] bool leaf_exists_nofollow(
    int directory_fd,
    std::string_view leaf,
    struct stat* observation = nullptr);

[[nodiscard]] bool is_valid_relative_path(std::string_view path) noexcept;
[[nodiscard]] std::vector<std::string> split_relative_path(
    std::string_view path,
    std::string_view locator);

void append_u8(Octets& out, std::uint8_t value);
void append_be16(Octets& out, std::uint16_t value);
void append_be32(Octets& out, std::uint32_t value);
void append_be64(Octets& out, std::uint64_t value);
void append_octets(Octets& out, OctetView value);
void append_text(Octets& out, std::string_view value);
void append_blob32(Octets& out, OctetView value);
void append_blob64(Octets& out, OctetView value);
void append_path16(Octets& out, std::string_view value);

class Reader final {
public:
    Reader(OctetView bytes, std::string locator);
    [[nodiscard]] std::size_t offset() const noexcept;
    [[nodiscard]] std::size_t remaining() const noexcept;
    [[nodiscard]] bool eof() const noexcept;
    [[nodiscard]] std::uint8_t read_u8(std::string_view field);
    [[nodiscard]] std::uint16_t read_be16(std::string_view field);
    [[nodiscard]] std::uint32_t read_be32(std::string_view field);
    [[nodiscard]] std::uint64_t read_be64(std::string_view field);
    [[nodiscard]] OctetView read_exact(std::uint64_t length, std::string_view field);
    [[nodiscard]] OctetView read_blob32(std::uint64_t ceiling, std::string_view field);
    [[nodiscard]] OctetView read_blob64(std::uint64_t ceiling, std::string_view field);
    [[nodiscard]] std::string_view read_path16(std::uint64_t ceiling, std::string_view field);
    void require_eof(std::string_view field) const;
private:
    OctetView bytes_;
    std::size_t offset_{0U};
    std::string locator_;
};

struct Digest32 {
    std::array<std::uint8_t, 32> octets{};
    [[nodiscard]] bool operator==(const Digest32&) const noexcept = default;
};

class Sha256State final {
public:
    Sha256State() noexcept;
    void update(OctetView bytes) noexcept;
    [[nodiscard]] Digest32 finalize() const noexcept;
    [[nodiscard]] std::uint64_t byte_count() const noexcept;
private:
    std::array<std::uint32_t, 8> state_{};
    std::array<std::uint8_t, 64> buffered_{};
    std::size_t buffered_bytes_{0U};
    std::uint64_t total_bytes_{0U};
};

[[nodiscard]] Digest32 sha256(OctetView bytes) noexcept;
[[nodiscard]] std::string hex_lower(OctetView bytes);
[[nodiscard]] std::string hex_lower(const Digest32& digest);
[[nodiscard]] Digest32 parse_hex_digest32(
    std::string_view text,
    std::string_view locator);
[[nodiscard]] Octets text_octets(std::string_view text);
[[nodiscard]] std::string octets_text(
    OctetView bytes,
    std::string_view locator,
    bool require_printable = false);
// Propagates stream allocation errors instead of returning truncated escapes.
[[nodiscard]] std::string json_escape(std::string_view text);
[[nodiscard]] std::string errno_detail(std::string_view operation, int error_number);
[[nodiscard]] std::uint64_t monotonic_nanoseconds();

}  // namespace datacube
