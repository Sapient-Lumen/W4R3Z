#pragma once

#include "datacube/core.hpp"

#include <cstddef>
#include <cstdint>
#include <string_view>
#include <vector>

namespace datacube {

inline constexpr std::size_t kNATravPeerFrameHeaderBytes = 4U;
inline constexpr std::uint32_t kNATravPeerMinimumPayloadBytes = 2U;
inline constexpr std::uint32_t kNATravPeerMaximumPayloadBytes = 65'536U;
inline constexpr std::size_t kNATravPeerMaximumBufferedFrameBytes =
    kNATravPeerFrameHeaderBytes +
    static_cast<std::size_t>(kNATravPeerMaximumPayloadBytes);

enum class NATravPeerStreamStatus {
    need_more,
    frame_ready,
    malformed_frame,
    stream_closed,
    peer_unavailable,
    operation_failed,
    moved_from,
};

struct NATravPeerStreamObservation {
    NATravPeerStreamStatus status{NATravPeerStreamStatus::need_more};
    std::size_t emitted_frames{0U};
    std::size_t buffered_bytes{0U};
    std::uint32_t expected_payload_bytes{0U};
};

class NATravPeerStreamDecoder final {
public:
    NATravPeerStreamDecoder() = default;
    NATravPeerStreamDecoder(const NATravPeerStreamDecoder&) = default;
    NATravPeerStreamDecoder& operator=(const NATravPeerStreamDecoder& other);
    NATravPeerStreamDecoder(NATravPeerStreamDecoder&& other) noexcept;
    NATravPeerStreamDecoder& operator=(NATravPeerStreamDecoder&& other) noexcept;

    // Moves transfer all decoder state without allocation. A distinct source
    // becomes terminal MOVED_FROM with empty framing metadata; feed/finish on
    // that source are allocation-free and leave caller output untouched.
    // Self-move, self-copy and self-swap preserve state. Copy assignment stages
    // a complete copy before committing, so failure preserves both operands.
    // Assigning a healthy decoder is the explicit way to reuse an inert owner.
    void swap(NATravPeerStreamDecoder& other) noexcept;
    friend void swap(NATravPeerStreamDecoder& left,
                     NATravPeerStreamDecoder& right) noexcept {
        left.swap(right);
    }
    [[nodiscard]] bool moved_from() const noexcept;

    // Active feed failures latch OPERATION_FAILED without allocating and
    // rethrow the original exception. Earlier output frames remain valid,
    // but consumed input is unspecified: discard/reconstruct, never retry.
    // Once failed, later feeds and all finish calls leave output unchanged.
    // Caller-owned output must be valid; no synchronization is provided.
    [[nodiscard]] NATravPeerStreamObservation feed(
        OctetView chunk,
        std::vector<Octets>& emitted);
    [[nodiscard]] NATravPeerStreamObservation finish(
        std::vector<Octets>& emitted) noexcept;
    [[nodiscard]] bool operation_failed() const noexcept;
    [[nodiscard]] bool terminal() const noexcept;
    [[nodiscard]] std::size_t buffered_bytes() const noexcept;
    [[nodiscard]] std::uint32_t expected_payload_bytes() const noexcept;

private:
    [[nodiscard]] NATravPeerStreamObservation observe(
        NATravPeerStreamStatus status,
        std::size_t emitted_frames) const noexcept;

    Octets buffered_;
    std::uint32_t expected_payload_bytes_{0U};
    bool expected_payload_known_{false};
    bool terminal_{false};
    NATravPeerStreamStatus terminal_status_{NATravPeerStreamStatus::need_more};
};

[[nodiscard]] Octets natrav_peer_encode_frame(OctetView payload);
[[nodiscard]] std::string_view natrav_peer_stream_status_name(
    NATravPeerStreamStatus status) noexcept;

}  // namespace datacube
