#pragma once

#include "datacube/core.hpp"
#include "datacube/natrav_peer_handshake.hpp"

#include <optional>
#include <string>
#include <string_view>

namespace datacube {

enum class NATravPeerMessageEncodeStatus {
    accepted,
    schema_rejected,
    message_kind_rejected,
    protocol_mismatch,
    request_id_rejected,
    artifact_identity_rejected,
    capability_declaration_rejected,
    payload_size_rejected,
};

struct NATravPeerMessageEncodeObservation final {
    NATravPeerMessageEncodeStatus status{
        NATravPeerMessageEncodeStatus::schema_rejected};
    std::string classification{"SCHEMA_REJECTED"};
    std::optional<Octets> payload;
};

enum class NATravPeerMessageDecodeStatus {
    accepted,
    malformed_json,
    noncanonical_json,
    schema_rejected,
    message_kind_rejected,
    protocol_mismatch,
    request_id_rejected,
    artifact_identity_rejected,
    capability_declaration_rejected,
    payload_size_rejected,
};

struct NATravPeerMessageDecodeObservation final {
    NATravPeerMessageDecodeStatus status{
        NATravPeerMessageDecodeStatus::malformed_json};
    std::string classification{"MALFORMED_JSON"};
    std::optional<NATravPeerHandshakeMessage> message;
};

// Validate the complete typed schema first, then count the exact canonical
// payload without allocation. Oversized valid values return
// PAYLOAD_SIZE_REJECTED without constructing output-sized storage. Accepted
// values serialize directly into the returned Octets after one exact reserve.
// Classification and payload allocation failures propagate unchanged.
[[nodiscard]] NATravPeerMessageEncodeObservation natrav_peer_encode_message(
    const NATravPeerHandshakeMessage& message);
[[nodiscard]] std::string_view natrav_peer_message_encode_status_name(
    NATravPeerMessageEncodeStatus status) noexcept;

// Admit only the shared inclusive 2..65536-byte payload envelope before
// inspecting JSON. A schema-aware iterative pass validates complete JSON and
// canonical spelling, enforces the 64-container and 16384-construction-unit
// profile, and indexes recognized message fields while traversing caller-owned
// bytes. Validated protocol major/minor integer values are retained in that
// preflight index, so accepted objects are projected without reparsing those
// tokens or performing a second generic scan, payload copy, JsonValue tree, or
// canonical reconstruction. Valid capability-entry spans are retained during
// that pass, so accepted projection constructs the capability vector without
// reparsing its array. Fixed-ASCII predicates for request ID, artifact SHA-256,
// and peer-error code are also retained while their string scalars are first
// validated. Message-kind and protocol-ID discriminants are retained in that
// same pass, so typed projection does not compare their complete token spans
// again. The bounded in-place indexes, predicates, and discriminants add no heap
// allocation.
// Classification and bounded parsing/typed-output allocations may throw;
// original exceptions propagate and caller-owned input remains untouched.
[[nodiscard]] NATravPeerMessageDecodeObservation natrav_peer_decode_message(
    OctetView payload);
[[nodiscard]] std::string_view natrav_peer_message_decode_status_name(
    NATravPeerMessageDecodeStatus status) noexcept;

}  // namespace datacube
