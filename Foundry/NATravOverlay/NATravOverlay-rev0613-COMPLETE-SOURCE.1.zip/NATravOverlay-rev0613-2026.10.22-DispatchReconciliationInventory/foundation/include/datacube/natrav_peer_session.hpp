#pragma once

#include "datacube/core.hpp"
#include "datacube/natrav_peer_handshake.hpp"
#include "datacube/natrav_peer_stream.hpp"

#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace datacube {

struct NATravPeerClientHandshakeInput final {
    NATravPeerProtocolVersion protocol;
    std::string request_id;
    NATravPeerArtifactIdentity local_artifact;
    NATravPeerArtifactIdentity expected_peer_artifact;
    std::vector<std::string> required_capabilities;
};

enum class NATravPeerClientPreparationStatus {
    prepared,
    protocol_mismatch,
    request_id_rejected,
    local_artifact_identity_rejected,
    expected_artifact_identity_rejected,
    capability_declaration_rejected,
    outbound_payload_size_rejected,
    expected_response_payload_size_rejected,
    codec_invariant_rejected,
};

struct NATravPeerPreparedClientHandshake final {
    NATravPeerHandshakeMessage hello;
    NATravPeerHandshakeExpectation expectation;
    Octets payload;
    Octets frame;
    Digest32 binding_sha256;
};

struct NATravPeerClientPreparationObservation final {
    NATravPeerClientPreparationStatus status{
        NATravPeerClientPreparationStatus::codec_invariant_rejected};
    std::string classification{"CODEC_INVARIANT_REJECTED"};
    std::optional<NATravPeerPreparedClientHandshake> prepared;
};

[[nodiscard]] NATravPeerClientPreparationObservation
natrav_peer_prepare_client_handshake(
    const NATravPeerClientHandshakeInput& input);
[[nodiscard]] std::string_view natrav_peer_client_preparation_status_name(
    NATravPeerClientPreparationStatus status) noexcept;

[[nodiscard]] Digest32 natrav_peer_client_exchange_binding(
    const Digest32& exchange_instance_id,
    const Digest32& prepared_plan_binding_sha256);
[[nodiscard]] Digest32 natrav_peer_client_transport_binding(
    const Digest32& transport_instance_id,
    const Digest32& exchange_binding_sha256);
[[nodiscard]] Digest32 natrav_peer_client_process_binding(
    const Digest32& process_instance_id,
    const Digest32& transport_binding_sha256);

enum class NATravPeerSessionStatus {
    awaiting_response,
    accepted,
    peer_error,
    protocol_mismatch,
    correlation_rejected,
    artifact_identity_mismatch,
    capability_mismatch,
    message_kind_rejected,
    peer_unavailable,
    replay_rejected,
    malformed_frame,
    malformed_json,
    noncanonical_json,
    schema_rejected,
    request_id_rejected,
    artifact_identity_rejected,
    capability_declaration_rejected,
    operation_failed,
    moved_from,
};

struct NATravPeerSessionObservation final {
    NATravPeerSessionStatus status{NATravPeerSessionStatus::awaiting_response};
    std::string classification{"AWAITING_RESPONSE"};
    std::size_t chunks_observed{0U};
    // Maximum completed payloads staged at once by this session, excluding
    // caller-owned input and the stream decoder's single in-progress frame.
    std::size_t peak_staged_frames{0U};
    std::size_t frames_observed{0U};
    std::size_t messages_decoded{0U};
    std::size_t handshake_transitions{0U};
    std::size_t buffered_bytes{0U};
    std::uint32_t expected_payload_bytes{0U};
    bool stream_terminal{false};
    bool terminal{false};
};

class NATravPeerHandshakeStreamSession final {
public:
    explicit NATravPeerHandshakeStreamSession(
        NATravPeerHandshakeExpectation expectation);

    NATravPeerHandshakeStreamSession(
        const NATravPeerHandshakeStreamSession&) = default;
    NATravPeerHandshakeStreamSession& operator=(
        const NATravPeerHandshakeStreamSession& other);
    NATravPeerHandshakeStreamSession(
        NATravPeerHandshakeStreamSession&& other) noexcept;
    NATravPeerHandshakeStreamSession& operator=(
        NATravPeerHandshakeStreamSession&& other) noexcept;

    // Distinct moves transfer the complete aggregate without allocating. The
    // donor becomes terminal MOVED_FROM with zero counters and empty framing
    // metadata. Its report methods are quiescent; snapshots may still throw.
    // Self-move/copy/swap preserve value. Copy assignment stages an entire copy
    // before a nonthrowing commit, so an exception preserves both operands.
    // Assignment from a healthy owner explicitly replaces an inert/failed one;
    // it does not resume input consumed by a failed active operation.
    void swap(NATravPeerHandshakeStreamSession& other) noexcept;
    friend void swap(NATravPeerHandshakeStreamSession& left,
                     NATravPeerHandshakeStreamSession& right) noexcept {
        left.swap(right);
    }
    [[nodiscard]] bool moved_from() const noexcept;

    // An exception escaping an active mutating operation is rethrown unchanged
    // after latching OPERATION_FAILED without allocating. No rollback or input
    // consumption guarantee is made: discard/reconstruct the session, do not
    // retry the failed chunk. Prefix counters/buffer metadata are diagnostic.
    // Once latched, all mutating calls are quiescent. Their returned snapshots
    // may still allocate and throw; operation_failed() is the no-allocation
    // query usable while allocation failure persists. A standalone observation
    // failure, or snapshot failure on an already-closed/fatal session, does not
    // change state. This active-operation contract is separate from the
    // aggregate ownership contract above and does not specify standalone
    // handshake-session operations or enclosing client-exchange report APIs.
    [[nodiscard]] NATravPeerSessionObservation feed(OctetView chunk);
    [[nodiscard]] NATravPeerSessionObservation finish();
    [[nodiscard]] NATravPeerSessionObservation observe_unavailability(
        NATravPeerHandshakeEvent event);
    [[nodiscard]] NATravPeerSessionObservation observation() const;
    [[nodiscard]] bool operation_failed() const noexcept;

private:
    void process_frames(const std::vector<Octets>& frames);
    void apply_handshake_observation(
        const NATravPeerHandshakeObservation& observation);
    void terminate(
        NATravPeerSessionStatus status,
        std::string classification);

    NATravPeerStreamDecoder stream_;
    NATravPeerHandshakeSession handshake_;
    NATravPeerSessionStatus status_{NATravPeerSessionStatus::awaiting_response};
    std::string classification_{"AWAITING_RESPONSE"};
    std::size_t chunks_observed_{0U};
    std::size_t peak_staged_frames_{0U};
    std::size_t frames_observed_{0U};
    std::size_t messages_decoded_{0U};
    std::size_t handshake_transitions_{0U};
    bool fatal_terminal_{false};
    bool input_closed_{false};
};

[[nodiscard]] std::string_view natrav_peer_session_status_name(
    NATravPeerSessionStatus status) noexcept;

enum class NATravPeerTransportReportKind {
    write,
    response_chunk,
    response_finish,
    early_eof,
    timeout,
    spawn_failure,
};

[[nodiscard]] std::string_view natrav_peer_transport_report_kind_name(
    NATravPeerTransportReportKind kind) noexcept;

enum class NATravPeerClientExchangeStatus {
    awaiting_request_write,
    awaiting_response,
    accepted,
    peer_error,
    protocol_mismatch,
    correlation_rejected,
    artifact_identity_mismatch,
    capability_mismatch,
    message_kind_rejected,
    peer_unavailable,
    replay_rejected,
    malformed_frame,
    malformed_json,
    noncanonical_json,
    schema_rejected,
    request_id_rejected,
    artifact_identity_rejected,
    capability_declaration_rejected,
    write_progress_rejected,
    response_before_request_complete_rejected,
    prepared_plan_binding_rejected,
    exchange_binding_rejected,
    transport_binding_rejected,
    process_binding_rejected,
    report_kind_rejected,
    report_binding_rejected,
    report_phase_rejected,
    report_ordinal_rejected,
    write_segment_rejected,
    write_offset_rejected,
    write_response_offset_rejected,
    response_request_offset_rejected,
    response_offset_rejected,
    response_terminal_request_offset_rejected,
    response_terminal_offset_rejected,
    operation_failed,
};

struct NATravPeerClientExchangeObservation final {
    std::optional<NATravPeerClientExchangeStatus> status;
    std::optional<std::string> classification;
    std::optional<std::size_t> reports_observed;
    std::optional<std::size_t> exchange_binding_checks_observed;
    std::optional<std::size_t> exchange_bindings_admitted;
    std::optional<std::size_t> transport_binding_checks_observed;
    std::optional<std::size_t> transport_bindings_admitted;
    std::optional<std::size_t> process_binding_checks_observed;
    std::optional<std::size_t> process_bindings_admitted;
    std::optional<std::size_t> report_kind_checks_observed;
    std::optional<std::size_t> report_kinds_admitted;
    std::optional<std::size_t> report_binding_checks_observed;
    std::optional<std::size_t> report_bindings_admitted;
    std::optional<std::size_t> report_ordinal_checks_observed;
    std::optional<std::size_t> report_ordinals_admitted;
    std::optional<std::size_t> report_phase_checks_observed;
    std::optional<std::size_t> report_phases_admitted;
    std::optional<std::size_t> next_report_ordinal;
    std::optional<std::size_t> write_reports_observed;
    std::optional<std::size_t> write_offset_checks_observed;
    std::optional<std::size_t> write_response_offset_checks_observed;
    std::optional<std::size_t> write_segment_checks_observed;
    std::optional<std::size_t> write_segment_bytes_verified;
    std::optional<std::size_t> request_frame_bytes;
    std::optional<std::size_t> request_bytes_written;
    std::optional<std::size_t> request_bytes_pending;
    std::optional<std::size_t> request_bytes_exposed;
    std::optional<std::size_t> response_reports_observed;
    std::optional<std::size_t> response_request_offset_checks_observed;
    std::optional<std::size_t> response_offset_checks_observed;
    std::optional<std::size_t> response_terminal_reports_observed;
    std::optional<std::size_t> response_terminal_request_offset_checks_observed;
    std::optional<std::size_t> response_terminal_offset_checks_observed;
    std::optional<std::size_t> response_bytes_received;
    std::optional<std::size_t> response_chunks_observed;
    std::optional<std::size_t> response_frames_observed;
    std::optional<std::size_t> response_messages_decoded;
    std::optional<std::size_t> response_handshake_transitions;
    std::optional<std::size_t> response_buffered_bytes;
    std::optional<std::uint32_t> response_expected_payload_bytes;
    bool prepared_plan_binding_verified{false};
    std::optional<bool> request_write_complete;
    std::optional<bool> response_stream_terminal;
    std::optional<bool> response_session_terminal;
    std::optional<NATravPeerSessionStatus> response_session_status;
    std::optional<std::string> response_session_classification;
    std::optional<bool> response_input_closed;
    std::optional<bool> report_processing_terminal;
    std::optional<bool> terminal;

    bool operator==(const NATravPeerClientExchangeObservation&) const = default;
};

class NATravPeerClientHandshakeExchange final {
public:
    // An exchange owns mutable report/decoder state. Copying that state would
    // fork its bindings and cursors; only explicit ownership transfer is allowed.
    NATravPeerClientHandshakeExchange(
        const NATravPeerClientHandshakeExchange&) = delete;
    NATravPeerClientHandshakeExchange& operator=(
        const NATravPeerClientHandshakeExchange&) = delete;
    NATravPeerClientHandshakeExchange(
        NATravPeerClientHandshakeExchange&& other) noexcept;
    NATravPeerClientHandshakeExchange& operator=(
        NATravPeerClientHandshakeExchange&& other) noexcept;

    // A moved-from object is inert: it holds no verified state, exposes no
    // optional observation/getter values, and admits no reports. Self-move is
    // a no-op. Reacquire all borrowed pending-request views after any move.
    [[nodiscard]] static
    std::optional<NATravPeerClientHandshakeExchange> create(
        const NATravPeerPreparedClientHandshake& prepared,
        const Digest32& exchange_instance_id,
        const Digest32& transport_instance_id,
        const Digest32& process_instance_id);

    [[nodiscard]] std::optional<std::size_t> pending_request_offset() const
        noexcept;
    // This is a borrowed view, not owned storage. Retain the lvalue owner and
    // reacquire after reports, moves, assignments, or resets. A receiver value-
    // category check cannot track aliases or temporary wrappers' operator->.
    [[nodiscard]] std::optional<OctetView> pending_request_bytes() const &
        noexcept;
    [[nodiscard]] std::optional<OctetView> pending_request_bytes() const &&
        noexcept = delete;
    [[nodiscard]] std::optional<Digest32> exchange_binding_sha256() const
        noexcept;
    [[nodiscard]] std::optional<Digest32> transport_binding_sha256() const
        noexcept;
    [[nodiscard]] std::optional<Digest32> process_binding_sha256() const
        noexcept;
    [[nodiscard]] std::optional<Digest32> report_binding_sha256() const
        noexcept;
    [[nodiscard]] std::optional<std::size_t> next_report_ordinal() const
        noexcept;
    [[nodiscard]] std::optional<bool> binding_bundle_constructed() const noexcept;
    [[nodiscard]] std::optional<bool> lifecycle_state_constructed() const noexcept;
    [[nodiscard]] std::optional<bool> report_coordinate_state_constructed() const noexcept;
    [[nodiscard]] std::optional<bool> report_accounting_state_constructed() const noexcept;
    [[nodiscard]] std::optional<bool> operation_accounting_state_constructed() const noexcept;
    [[nodiscard]] std::optional<bool> verified_plan_state_constructed() const noexcept;
    [[nodiscard]] std::optional<bool> request_frame_constructed() const noexcept;
    [[nodiscard]] std::optional<bool> response_session_constructed() const noexcept;
    // An exception escaping a report method on a present, non-fatal exchange
    // latches OPERATION_FAILED using scalar writes and is rethrown unchanged.
    // This includes rejection paths and the final allocating observation.
    // Subsequent reports are quiescent; their snapshots may still throw.
    // Discard/reconstruct after failure. Counters/cursors may have advanced;
    // they are diagnostics, not a retry cursor or a report-completion receipt.
    // No rollback, input-consumption, thread-safety, or process recovery is
    // promised. Standalone observations and already-fatal/inert entry guards
    // never latch. Construction is excluded; noexcept moves transfer the latch
    // with owned state, and replacement by a different owner remains allowed.
    // A closed but non-fatal exchange still runs report-admission checks, so
    // exceptions from those checks are covered by the report-method contract.
    [[nodiscard]] std::optional<bool> operation_failed() const noexcept;
    // No allocation; nullopt on an inert moved-from owner, false on a healthy
    // present owner, true after failure. Snapshot strings allocate separately.
    [[nodiscard]] NATravPeerClientExchangeObservation observe_write(
        const Digest32& exchange_binding_sha256,
        const Digest32& transport_binding_sha256,
        const Digest32& process_binding_sha256,
        NATravPeerTransportReportKind report_kind,
        const Digest32& report_binding_sha256,
        std::size_t report_ordinal,
        std::size_t request_offset,
        std::size_t response_offset,
        OctetView written_segment);
    [[nodiscard]] std::optional<std::size_t> next_response_offset() const
        noexcept;
    [[nodiscard]] NATravPeerClientExchangeObservation feed_response(
        const Digest32& exchange_binding_sha256,
        const Digest32& transport_binding_sha256,
        const Digest32& process_binding_sha256,
        NATravPeerTransportReportKind report_kind,
        const Digest32& report_binding_sha256,
        std::size_t report_ordinal,
        std::size_t request_offset,
        std::size_t response_offset,
        OctetView chunk);
    [[nodiscard]] NATravPeerClientExchangeObservation finish_response(
        const Digest32& exchange_binding_sha256,
        const Digest32& transport_binding_sha256,
        const Digest32& process_binding_sha256,
        NATravPeerTransportReportKind report_kind,
        const Digest32& report_binding_sha256,
        std::size_t report_ordinal,
        std::size_t request_offset,
        std::size_t response_offset);
    [[nodiscard]] NATravPeerClientExchangeObservation observe_unavailability(
        const Digest32& exchange_binding_sha256,
        const Digest32& transport_binding_sha256,
        const Digest32& process_binding_sha256,
        NATravPeerTransportReportKind report_kind,
        const Digest32& report_binding_sha256,
        std::size_t report_ordinal,
        std::size_t request_offset,
        std::size_t response_offset,
        NATravPeerHandshakeEvent event);
    [[nodiscard]] NATravPeerClientExchangeObservation observation() const;

private:
    [[nodiscard]] bool verify_exchange_binding(
        const Digest32& exchange_binding_sha256);
    [[nodiscard]] bool verify_transport_binding(
        const Digest32& transport_binding_sha256);
    [[nodiscard]] bool verify_process_binding(
        const Digest32& process_binding_sha256);
    [[nodiscard]] bool verify_report_kind(
        NATravPeerTransportReportKind actual,
        NATravPeerTransportReportKind expected);
    [[nodiscard]] bool verify_report_binding(
        const Digest32& report_binding_sha256);
    [[nodiscard]] bool verify_report_ordinal(std::size_t report_ordinal);
    [[nodiscard]] bool verify_report_phase(
        NATravPeerTransportReportKind report_kind);
    [[nodiscard]] bool verify_response_terminal_offsets(
        std::size_t request_offset,
        std::size_t response_offset);
    void apply_response_observation(
        const NATravPeerSessionObservation& observation);
    void terminate(
        NATravPeerClientExchangeStatus status,
        std::string classification);

    struct BindingBundle final {
        Digest32 exchange_binding_sha256;
        Digest32 transport_binding_sha256;
        Digest32 process_binding_sha256;
        Digest32 report_binding_sha256;
    };

    struct LifecycleState final {
        NATravPeerClientExchangeStatus status{
            NATravPeerClientExchangeStatus::awaiting_request_write};
        std::string classification{"AWAITING_REQUEST_WRITE"};
        bool response_input_closed{false};
        bool fatal_terminal{false};
    };

    struct ReportCoordinateState final {
        std::size_t request_bytes_written{0U};
        std::size_t response_bytes_received{0U};
        std::size_t next_report_ordinal{0U};
    };

    struct ReportAccountingState final {
        std::size_t reports_observed{0U};
        std::size_t exchange_binding_checks_observed{0U};
        std::size_t exchange_bindings_admitted{0U};
        std::size_t transport_binding_checks_observed{0U};
        std::size_t transport_bindings_admitted{0U};
        std::size_t process_binding_checks_observed{0U};
        std::size_t process_bindings_admitted{0U};
        std::size_t report_kind_checks_observed{0U};
        std::size_t report_kinds_admitted{0U};
        std::size_t report_binding_checks_observed{0U};
        std::size_t report_bindings_admitted{0U};
        std::size_t report_ordinal_checks_observed{0U};
        std::size_t report_ordinals_admitted{0U};
        std::size_t report_phase_checks_observed{0U};
        std::size_t report_phases_admitted{0U};
    };

    struct OperationAccountingState final {
        std::size_t write_reports_observed{0U};
        std::size_t write_offset_checks_observed{0U};
        std::size_t write_response_offset_checks_observed{0U};
        std::size_t write_segment_checks_observed{0U};
        std::size_t write_segment_bytes_verified{0U};
        std::size_t response_reports_observed{0U};
        std::size_t response_request_offset_checks_observed{0U};
        std::size_t response_offset_checks_observed{0U};
        std::size_t response_terminal_reports_observed{0U};
        std::size_t response_terminal_request_offset_checks_observed{0U};
        std::size_t response_terminal_offset_checks_observed{0U};
    };

    struct VerifiedPlanState final {
        BindingBundle binding_bundle;
        LifecycleState lifecycle_state;
        ReportCoordinateState report_coordinates;
        ReportAccountingState report_accounting;
        OperationAccountingState operation_accounting;
        Octets request_frame;
        NATravPeerHandshakeStreamSession response;
    };

    explicit NATravPeerClientHandshakeExchange(VerifiedPlanState state);

    std::optional<VerifiedPlanState> verified_plan_state_;
};

[[nodiscard]] std::string_view natrav_peer_client_exchange_status_name(
    NATravPeerClientExchangeStatus status) noexcept;

}  // namespace datacube
