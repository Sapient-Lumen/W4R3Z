#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace datacube {

struct NATravPeerProtocolVersion final {
    std::string id;
    std::int64_t major{0};
    std::int64_t minor{0};
};

struct NATravPeerArtifactIdentity final {
    std::string sha256;
    std::string target;
    std::string version;
};

struct NATravPeerHandshakeExpectation final {
    NATravPeerProtocolVersion protocol;
    std::string request_id;
    NATravPeerArtifactIdentity expected_artifact;
    std::vector<std::string> required_capabilities;
};

enum class NATravPeerHandshakeMessageKind {
    hello,
    hello_ack,
    error,
    unknown,
};

struct NATravPeerHandshakeMessage final {
    NATravPeerHandshakeMessageKind kind{NATravPeerHandshakeMessageKind::unknown};
    NATravPeerProtocolVersion protocol;
    std::string request_id;
    NATravPeerArtifactIdentity artifact;
    std::vector<std::string> required_capabilities;
    std::vector<std::string> available_capabilities;
    std::string error_code;
    std::string error_message;
};

enum class NATravPeerHandshakeEvent {
    timeout,
    early_eof,
    spawn_failure,
};

enum class NATravPeerHandshakeStatus {
    awaiting_response,
    accepted,
    peer_error,
    protocol_mismatch,
    correlation_rejected,
    artifact_identity_mismatch,
    capability_mismatch,
    message_kind_rejected,
    peer_unavailable,
    replay_rejected,
    operation_failed,
    moved_from,
    capability_declaration_rejected,
};

struct NATravPeerHandshakeObservation final {
    NATravPeerHandshakeStatus status{NATravPeerHandshakeStatus::awaiting_response};
    std::string classification{"AWAITING_RESPONSE"};
    std::size_t responses_observed{0U};
    bool terminal{false};
};

class NATravPeerHandshakeSession final {
public:
    explicit NATravPeerHandshakeSession(
        NATravPeerHandshakeExpectation expectation);

    // Value copying is deep. Assignment stages the whole correlated value;
    // a throwing copy leaves both operands (and their continuations) unchanged.
    NATravPeerHandshakeSession(const NATravPeerHandshakeSession&) = default;
    NATravPeerHandshakeSession& operator=(const NATravPeerHandshakeSession& other);
    // Distinct moves transfer all state and leave a terminal, inert donor.
    // Self-copy, self-move and self-swap preserve the value without allocation.
    NATravPeerHandshakeSession(NATravPeerHandshakeSession&& other) noexcept;
    NATravPeerHandshakeSession& operator=(NATravPeerHandshakeSession&& other) noexcept;
    ~NATravPeerHandshakeSession() = default;
    void swap(NATravPeerHandshakeSession& other) noexcept;
    friend void swap(NATravPeerHandshakeSession& left,
                     NATravPeerHandshakeSession& right) noexcept {
        left.swap(right);
    }

    // Typed HELLO_ACK capability admission requires strictly increasing
    // required/available sequences (no duplicates), including when requirements
    // are empty. Malformed order is CAPABILITY_DECLARATION_REJECTED, not a
    // missing capability; neither sequence is sorted, deduplicated or mutated.
    // This check follows correlation/protocol/kind/artifact checks. ERROR and
    // replay keep their existing priority. Strings here remain opaque values:
    // this API is not a substitute for wire codec token/schema validation.
    [[nodiscard]] NATravPeerHandshakeObservation observe_response(
        const NATravPeerHandshakeMessage& response);
    [[nodiscard]] NATravPeerHandshakeObservation observe_unavailability(
        NATravPeerHandshakeEvent event);
    [[nodiscard]] NATravPeerHandshakeObservation observation() const;

    // Active-operation exceptions latch a terminal, discard-and-reconstruct
    // state before propagating unchanged. No rollback or retry is promised.
    // This query never allocates, even while observation snapshots may throw.
    [[nodiscard]] bool operation_failed() const noexcept;
    [[nodiscard]] bool moved_from() const noexcept;

private:
    [[nodiscard]] NATravPeerHandshakeObservation terminate(
        NATravPeerHandshakeStatus status,
        std::string classification);

    NATravPeerHandshakeExpectation expectation_;
    NATravPeerHandshakeStatus status_{NATravPeerHandshakeStatus::awaiting_response};
    std::string classification_{"AWAITING_RESPONSE"};
    std::size_t responses_observed_{0U};
    bool terminal_{false};
};

[[nodiscard]] std::string_view natrav_peer_handshake_status_name(
    NATravPeerHandshakeStatus status) noexcept;
[[nodiscard]] std::string_view natrav_peer_handshake_event_name(
    NATravPeerHandshakeEvent event) noexcept;

}  // namespace datacube
