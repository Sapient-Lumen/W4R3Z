"""Strict or instrumented offline-capsule native probe. Output must be new."""
from pathlib import Path
import argparse
import subprocess,json,sys,time,os
r=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--mode',choices=['strict','sanitize'],default='strict')
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();mode=args.mode;out=args.output.resolve()
if out.exists() or out==r or r in out.parents: parser.error('output must be new and outside source')
out.mkdir(parents=True)
flags=['g++','-D_GNU_SOURCE','-std=c++20','-O1','-g0','-Wall','-Wextra','-Wpedantic','-Wconversion','-Wsign-conversion','-Wshadow','-Wformat=2','-Werror','-pthread','-I'+str(r/'foundation/include'),'-I'+str(r/'node/src')]
if mode=='sanitize': flags+=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie']
sources=['node/tests/handoff_capsule_probe.cpp','node/src/handoff_capsule.cpp','node/src/common.cpp','node/src/protocol.cpp','foundation/src/core.cpp','foundation/src/natrav_peer_session.cpp','foundation/src/natrav_peer_stream.cpp','foundation/src/natrav_peer_message.cpp','foundation/src/natrav_peer_handshake.cpp']
command=flags+[str(r/p) for p in sources]+['-lssl','-lcrypto','-lz','-lzstd','-o',str(out/'probe')]
(out/'command.json').write_text(json.dumps(command,indent=2));start=time.monotonic()
with (out/'compile.stdout').open('w') as so,(out/'compile.stderr').open('w') as se:
 c=subprocess.run(command,stdout=so,stderr=se,timeout=120)
result={'compile_rc':c.returncode,'compile_elapsed':time.monotonic()-start}
if c.returncode==0:
 with (out/'stdout.txt').open('w') as so,(out/'stderr.txt').open('w') as se:
  p=subprocess.run([str(out/'probe')],stdout=so,stderr=se,timeout=30,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'))
 result['probe_rc']=p.returncode
 if p.returncode==0: result['probe']=json.loads((out/'stdout.txt').read_text())
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(result)

sys.exit(0 if result.get('probe',{}).get('status')=='PASS' else 1)
