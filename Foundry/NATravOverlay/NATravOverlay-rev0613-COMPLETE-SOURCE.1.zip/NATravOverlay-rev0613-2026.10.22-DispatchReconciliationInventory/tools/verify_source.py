#!/usr/bin/env python3
"""Verify every file against the release source manifest, without dependencies."""
from __future__ import annotations
import hashlib
from pathlib import Path, PurePosixPath
import sys


def verify(root: Path) -> tuple[int, list[str]]:
    manifest = root / "SHA256SUMS"
    expected: dict[str, str] = {}
    errors: list[str] = []
    for line in manifest.read_text(encoding="ascii").splitlines():
        digest, sep, name = line.partition("  ")
        part = PurePosixPath(name)
        if (not sep or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest)
                or not name or part.is_absolute() or ".." in part.parts
                or name != part.as_posix() or name in expected or name == "SHA256SUMS"):
            raise ValueError("invalid or duplicate manifest entry: " + repr(line))
        expected[name] = digest
    actual: set[str] = set()
    for path in sorted(root.rglob("*")):
        name = path.relative_to(root).as_posix()
        if path.is_symlink():
            errors.append("symlink: " + name)
        elif path.is_file() and name != "SHA256SUMS":
            actual.add(name)
            hasher = hashlib.sha256()
            with path.open("rb") as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    hasher.update(block)
            digest = hasher.hexdigest()
            if name in expected and digest != expected[name]:
                errors.append("digest mismatch: " + name)
    errors.extend("missing: " + n for n in sorted(expected.keys() - actual))
    errors.extend("unlisted: " + n for n in sorted(actual - expected.keys()))
    return len(expected), errors


if __name__ == "__main__":
    try:
        count, errors = verify(Path(__file__).resolve().parents[1])
    except (OSError, UnicodeError, ValueError) as exc:
        print("FAIL: " + str(exc), file=sys.stderr)
        raise SystemExit(1)
    for error in errors:
        print(error, file=sys.stderr)
    print(("FAIL" if errors else "PASS") + f": {count} manifest entries; {len(errors)} errors")
    raise SystemExit(bool(errors))
