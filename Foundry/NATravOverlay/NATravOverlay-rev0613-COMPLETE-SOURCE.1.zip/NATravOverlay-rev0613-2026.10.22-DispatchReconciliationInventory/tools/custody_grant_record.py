#!/usr/bin/env python3
"""Draft one canonical V21 custody-grant record and immutable commitment.

This helper never authorizes or activates a grant.  Feed its lowercase
``custody_grant_hex`` output through normal config-check/config-activate.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re

TOKEN = re.compile(r"[a-z0-9][a-z0-9._-]{0,63}\Z")
NODE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}\Z")
ZERO = "0" * 64


def token(value: str, label: str, pattern: re.Pattern[str]) -> str:
    if not pattern.fullmatch(value):
        raise argparse.ArgumentTypeError(f"invalid {label}")
    return value


def sha(value: str) -> str:
    return hashlib.sha256(value.encode("ascii")).hexdigest()


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--id", required=True)
    p.add_argument("--generation", type=int, required=True)
    p.add_argument("--predecessor-sha256", default=ZERO)
    for name in ("origin", "final-recipient", "custodian", "next-hop"):
        p.add_argument("--" + name, required=True)
    for name in ("origin-signing-generation", "final-signing-generation",
                 "custodian-signing-generation", "next-hop-signing-generation"):
        p.add_argument("--" + name, required=True)
    p.add_argument("--maximum-envelope-lifetime-ms", type=int, required=True)
    p.add_argument("--maximum-hops", type=int, required=True)
    p.add_argument("--maximum-active-envelopes", type=int, required=True)
    p.add_argument("--maximum-capsule-bytes", type=int, required=True)
    p.add_argument("--state", choices=("ACTIVE", "RETIRED", "REVOKED"),
                   default="ACTIVE")
    a = p.parse_args()
    identifier = token(a.id, "grant id", TOKEN)
    nodes = {
        "origin": token(a.origin, "origin", NODE),
        "final_recipient": token(a.final_recipient, "final recipient", NODE),
        "custodian": token(a.custodian, "custodian", NODE),
        "next_hop": token(a.next_hop, "next hop", NODE),
    }
    generations = {
        "origin_signing_generation": token(a.origin_signing_generation,
            "origin signing generation", TOKEN),
        "final_signing_generation": token(a.final_signing_generation,
            "final signing generation", TOKEN),
        "custodian_signing_generation": token(a.custodian_signing_generation,
            "custodian signing generation", TOKEN),
        "next_hop_signing_generation": token(a.next_hop_signing_generation,
            "next-hop signing generation", TOKEN),
    }
    if a.generation < 1 or a.generation > 16:
        p.error("generation must be 1..16")
    predecessor = a.predecessor_sha256
    if not re.fullmatch(r"[0-9a-f]{64}", predecessor):
        p.error("predecessor SHA-256 must be 64 lowercase hexadecimal digits")
    if not 1 <= a.maximum_envelope_lifetime_ms <= 604_800_000:
        p.error("maximum envelope lifetime is outside product bounds")
    if not 1 <= a.maximum_hops <= 15:
        p.error("maximum hops must be 1..15")
    if not 1 <= a.maximum_active_envelopes <= 256:
        p.error("maximum active envelopes must be 1..256")
    if not 1 <= a.maximum_capsule_bytes <= 68_000:
        p.error("maximum capsule bytes must be 1..68000")
    fields = [
        f"id={identifier}", f"generation={a.generation}",
        f"predecessor_sha256={predecessor}",
        f"origin={nodes['origin']}",
        f"origin_signing_generation={generations['origin_signing_generation']}",
        f"final_recipient={nodes['final_recipient']}",
        f"final_signing_generation={generations['final_signing_generation']}",
        f"custodian={nodes['custodian']}",
        f"custodian_signing_generation={generations['custodian_signing_generation']}",
        f"next_hop={nodes['next_hop']}",
        f"next_hop_signing_generation={generations['next_hop_signing_generation']}",
        f"maximum_envelope_lifetime_ms={a.maximum_envelope_lifetime_ms}",
        f"maximum_hops={a.maximum_hops}",
        f"maximum_active_envelopes={a.maximum_active_envelopes}",
        f"maximum_capsule_bytes={a.maximum_capsule_bytes}",
    ]
    commitment_text = "NATRAV_CUSTODY_RELAY_GRANT_COMMITMENT_V1\n" + \
        "\n".join(fields) + "\n"
    record = "NATRAV_CUSTODY_RELAY_GRANT_V1\n" + \
        "\n".join(fields) + f"\nstate={a.state}\n"
    result = {
        "format": "NATRAV_CUSTODY_GRANT_DRAFT_V1",
        "record": record,
        "custody_grant_hex": record.encode("ascii").hex(),
        "commitment_sha256": sha(commitment_text),
        "authorized": False,
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
