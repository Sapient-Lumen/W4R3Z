#!/usr/bin/env python3
"""Print one public V20 policy line and its immutable predecessor commitment.

This helper does NOT authorize a transition or verify an identity. Review the
record, use config-check, then submit the candidate through config-activate.
The product verifies its signed public binding and accepted configuration history.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binding', type=Path, required=True)
    parser.add_argument('--sequence', type=int, required=True, choices=range(1, 17))
    parser.add_argument('--predecessor-sha256', default='0'*64)
    parser.add_argument('--state', choices=('ACTIVE', 'RETIRED', 'REVOKED'), default='ACTIVE')
    args = parser.parse_args()
    if not re.fullmatch('[0-9a-f]{64}', args.predecessor_sha256):
        parser.error('predecessor must be 64 lowercase hexadecimal digits')
    if (args.sequence == 1) != (args.predecessor_sha256 == '0'*64):
        parser.error('only sequence one has a zero predecessor')
    try:
        fd = os.open(args.binding, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, 'rb') as f:
            info = os.fstat(f.fileno())
            if not stat.S_ISREG(info.st_mode) or not 1 <= info.st_size <= 512:
                raise ValueError('binding must be a bounded regular public file')
            raw = f.read(513)
        if len(raw) > 512 or not raw.startswith(b'NHKB0001'):
            raise ValueError('expected public NHKB0001 binding, not private key material')
        fields = f'sequence={args.sequence}\npredecessor_sha256={args.predecessor_sha256}\nbinding_hex={raw.hex()}\n'
        immutable = ('NATRAV_HANDOFF_KEY_COMMITMENT_V1\n'+fields).encode('ascii')
        policy = ('NATRAV_HANDOFF_KEY_POLICY_V1\n'+fields+'state='+args.state+'\n').encode('ascii')
        print(json.dumps({'binding_sha256':hashlib.sha256(raw).hexdigest(),
                          'commitment_sha256':hashlib.sha256(immutable).hexdigest(),
                          'config_line':'handoff_key_hex='+policy.hex()}, indent=2))
        return 0
    except (OSError, ValueError) as error:
        print(f'policy record not produced: {error}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
