# Current verified whole-tree handoff: revision 0613

Revision 0613 adds [read-only owner dispatch reconciliation](docs/DISPATCH-RECONCILIATION.md)
through the ordinary daemon's existing authenticated local-control channel. An
owner can query one exact V24 dispatch identity or page through the finite
existing dispatch index without resubmitting the mutating dispatch command.
Every result validates the current V24→V23→V22→V21 authority chain and the exact
retained index, request, offer, envelope, attempt, result, and acceptance
bindings.

The observation path returns bounded metadata only. It performs no filesystem
mutation, index repair, network exchange, attempt reservation, retry, route
search, fallback, export, import, forwarding, or delivery inference. The single
normal executable still reports `automatic_custody_sender: false`,
`automatic_route_relay: false`, and `open_relay: false`.

Start with [the handoff](HANDOFF.md), [BOOTSTRAPROSE](BOOTSTRAPROSE.md),
[the reconciliation contract](docs/DISPATCH-RECONCILIATION.md), and
[the revision-0613 validation account](validation/revision-0613/STATUS.json).
Complete source custody and verification evidence remain separate from the
canonical two-file product handoff.

Earlier release descriptions below are retained provenance.

---

# Current verified whole-tree handoff: revision 0612

Revision 0612 adds a default-off, explicitly owner-invoked custody dispatch to
the ordinary daemon. Canonical V24 authority binds one exact local V23 receiver,
one exact outbound V22 rule, one enabled route commitment, finite concurrency
and attempt limits, expiry, and monotonic lifecycle. The authenticated local
control request names one retained receiver request and one fresh dispatch
request identity; it can commit at most one outbound NOS1 attempt.

The dispatcher proves exact current nonterminal custody from the authenticated
journal and reuses the retained bundle, V22 sender state machine, signed offer
and acceptance, peer authentication, attempt counter, configuration lease, and
response-loss uncertainty. Exact duplicate control requests recover one durable
result without another connection. Receipt still never triggers dispatch, and
the executable reports `automatic_custody_sender: false`,
`automatic_route_relay: false`, and `open_relay: false`.

Start with [the handoff](HANDOFF.md), [BOOTSTRAPROSE](BOOTSTRAPROSE.md),
[the native custody-session contract](docs/NATIVE-DURABLE-CUSTODY-SESSION-SERVICE.md),
and [the revision-0612 validation account](validation/revision-0612/STATUS.json).
Complete source custody and verification evidence remain separate from the
canonical two-file product handoff.

Earlier release descriptions below are retained provenance.

---

# Current verified whole-tree handoff: revision 0611

Revision 0611 adds an explicitly configured, default-off passive custody
receiver to the ordinary daemon's existing authenticated NOS1 listener. A
canonical V23 activation binds one exact local V22 rule, finite concurrency,
expiry, and monotonic lifecycle. Per-operation configuration leases make live
activation visible on an already-open authenticated session while preserving
in-flight durability and subsequent retirement or revocation.

The receiver can admit one exact authorized offer or replay one exact retained
acceptance. It cannot originate an offer, export a bundle, select or discover a
route, retry, fail over, schedule onward custody, import final application
evidence, or infer delivery. The single normal executable reports
`automatic_custody_sender: false`, `automatic_route_relay: false`, and
`open_relay: false`.

Start with [the handoff](HANDOFF.md), [BOOTSTRAPROSE](BOOTSTRAPROSE.md),
[the native custody-session contract](docs/NATIVE-DURABLE-CUSTODY-SESSION-SERVICE.md),
and [the revision-0611 validation account](validation/revision-0611/STATUS.json).
Complete source custody and verification evidence remain separate from the
canonical two-file product handoff.

Earlier release descriptions below are retained provenance.

---

# Current verified whole-tree handoff: revision 0610

Revision 0610 adds deterministic external durability cutpoints and an explicit,
owner-controlled composition of two custody transitions. One read-only retained
bundle export requires that the local node is still the exact current
nonterminal custodian in the authenticated custody journal. It preserves the
canonical envelope and capsule bytes and creates no queue, scheduler, route
choice, or parallel authority ledger.

The focused construction proves `A → R → B` only through two separate V22/V21
authorities, certificate commitments, signed offers, signed acceptances,
explicit routes, and owner invocations. Acceptance of `A → R` never initiates
`R → B`. The single normal executable still reports
`automatic_route_relay: false` and `open_relay: false`; custody acceptance is
not application import or delivery.

Start with [the handoff](HANDOFF.md), [BOOTSTRAPROSE](BOOTSTRAPROSE.md),
[the native custody-session contract](docs/NATIVE-DURABLE-CUSTODY-SESSION-SERVICE.md),
and [the revision-0610 validation account](validation/revision-0610/STATUS.json).
Complete source custody and verification evidence remain separate from the
canonical two-file product handoff.

Earlier release descriptions below are retained provenance.

---

# Current verified whole-tree handoff: revision 0609

Revision 0609 adds the [native durable custody-session service](docs/NATIVE-DURABLE-CUSTODY-SESSION-SERVICE.md). One explicitly named V22/V21 transition now uses the existing authenticated reusable NOS1 peer session, exact DER-certificate commitments, crash-safe signed offer and acceptance bytes, and the existing authenticated custody journal. The obsolete custody-only TLS/frame transport is removed.

The single normal executable reports `configured_custody_relay: true` because the service is explicitly invokable. It also reports `automatic_route_relay: false` and `open_relay: false`: ordinary routes do not discover, fail over, forward, or import application evidence. Custody acceptance remains distinct from delivery.

Start with [the handoff](HANDOFF.md), [BOOTSTRAPROSE](BOOTSTRAPROSE.md), [the native custody-session contract](docs/NATIVE-DURABLE-CUSTODY-SESSION-SERVICE.md), and [the revision-0609 validation account](validation/revision-0609/STATUS.json). Complete source custody remains separate from the two-file product handoff.

Earlier release descriptions below are retained provenance.

# Current whole-tree handoff: revision 0606

Revision 0606 adds [V21 durable custody authority and evidence](docs/DURABLE-CUSTODY-AUTHORITY.md). Exact origin, final-recipient, custodian, next-hop and signing-generation grants are admitted through the existing authenticated configuration history. Signed custody offers, acceptances, uncertainty, expiry and final import are retained in the existing owner-private journal and checkpoint. Final custody acceptance remains distinct from capsule import, application admission and exact receipt completion.

The normal executable provides explicit owner-only custody commands and canonical finite `NHCB0001` bundles. Ordinary configured routes remain non-relaying: `configured_custody_relay` is false. No discovery, opportunistic forwarding, parallel authority ledger or second executable is introduced.

Start with [the handoff](HANDOFF.md), [BOOTSTRAPROSE](BOOTSTRAPROSE.md), [the V21 custody contract](docs/DURABLE-CUSTODY-AUTHORITY.md), and [the current source gate account](validation/revision-0606/STATUS.json). The complete source tree is the handoff; patches are supplementary reconstruction evidence.

Earlier release descriptions below are retained provenance.

# Current whole-tree handoff: revision 0605

Revision 0605 adds a [private finite custody-envelope model](docs/CUSTODY-ENVELOPE-MODEL.md) around one opaque unchanged `NHCP0001` capsule. The origin signs an explicit loop-free route; exact custodians sign alternating transfer and acceptance records with finite expiry, hop, history, duplicate, and sequence bounds. Final custody acceptance is not application delivery.

The model translation unit is compiled by the ordinary product build, and the one normal executable reports its marker, but it remains unavailable to configuration, transports, the daemon, and durable state. `configured_custody_relay` is false. No node becomes a relay in this revision.

Start with [the handoff](HANDOFF.md), [BOOTSTRAPROSE](BOOTSTRAPROSE.md), [the custody model](docs/CUSTODY-ENVELOPE-MODEL.md), and [the current source gate account](validation/revision-0605/STATUS.json). The complete source tree is the handoff; patches are supplementary reconstruction evidence.

Earlier release descriptions below are retained provenance.

# Current whole-tree handoff: revision 0604

Revision 0604 adds [durable handoff-key lifecycle](docs/HANDOFF-KEY-POLICY.md)
under the existing authenticated configuration authority. Exact signed bindings,
consecutive immutable commitments, explicit retirement and revocation are V20
policy. Export requires ACTIVE keys; delayed import may use RETIRED keys; REVOKED
keys are rejected. Old accepted history cannot be erased, redefined or downgraded.
No new crypto construction, application ledger, second executable or relay is added.

Start with [the handoff](HANDOFF.md), [BOOTSTRAPROSE](BOOTSTRAPROSE.md), and
[the current source gate account](validation/revision-0604/STATUS.json). The source
ZIP contains the complete tree. External archive/rebuild and delivery records
close the frozen-package gates without a self-referential checksum.

Earlier release descriptions below are provenance, not current feature or test claims.

# Current whole-tree handoff: revision 0602

NATravOverlay now carries one existing operation or exact receipt in an offline,
one-hop authenticated encrypted capsule. The commands are part of the same
`node/bin/natrav-overlay` executable. They require exclusive owner state access,
reconstruct accepted configuration and reuse ordinary authorization, journal,
action admission, duplicate suppression and receipt reconciliation.

Start with [the custodian handoff](HANDOFF.md), [BOOTSTRAPROSE](BOOTSTRAPROSE.md),
[the offline capsule contract](docs/OFFLINE-HANDOFF.md), and
[the current gate record](validation/revision-0602/STATUS.json).
No prior patch or delta is needed: this is the whole source tree. The failed
source-less 0601 package is provenance, not an implemented predecessor.

Capsule export is not delivery, decryption is not action execution, and current
scope authority is still required. Dedicated handoff keys are external identity
material and are not automatically included in state backups. The custom capsule
is not HPKE, has no independent security audit, and does not add relay or live
route selection. The earlier carrier implementations remain intact.

The historical release descriptions below are retained context, not the current
revision or current verification record.

# NATravOverlay — revision 0597

NATravOverlay is a source-first Linux C++20 product with one normal executable,
`node/bin/natrav-overlay`. It is building toward a sovereign,
carrier-independent, delay-tolerant fabric for authenticated evidence, durable
obligations, and explicitly authorized action.

Revision 0597 verifies those exact configured adapters under deterministic,
bounded packet and process adversity. Two complete persistent nodes retain the
same accepted V19 endpoint/profile authority while fixture-only schedules inject
packet loss, duplication, corruption, delay and reordering, exhausted startup
budgets, silent NAPA responses and runtime process death. Pending obligations,
attempt accounting, fresh TLS/HELLO sessions and exact receipts remain product
responsibilities above the untrusted adapter.

This is the complete source tree, not a selected-file delta. Start with
[the handoff](HANDOFF.md), [BOOTSTRAPROSE](BOOTSTRAPROSE.md), and
[configured adapter execution](docs/CONFIGURED-ADAPTER-EXECUTION.md), and
[configured-adapter adversity](docs/CONFIGURED-ADAPTER-ADVERSITY.md).
Current product gates are in `validation/revision-0597/STATUS.json`; older
validation records are retained provenance. The delivery's archive-verification
sidecar records the final frozen-source extraction and rebuild.

## Current carrier-neutral stack

Direct ordered carriers use:

```text
configured TCP or serial-v1 stream
→ TransportConnector / TransportListener
→ OrderedByteStream / ByteChannel
→ OpenSSL BIO
→ TLS 1.3 mutual authentication
→ HELLO → NOS1 → application operations and receipts
```

Packet carriers reconstruct that same ordered boundary:

```text
configured udp-v1, unix-dgram-v1 or authorized adapter-endpoint-v1 carrier
→ OwnedCompleteDatagramPacketPort
→ finite NPL1 packet service
→ bounded fragmentation/reassembly, acknowledgment, retry, duplicate suppression, expiry
→ PacketPortOrderedByteStream / ByteChannel
→ the unchanged authenticated stack
```

Carrier coordinates remain locators only. IP addresses, UDP ports, serial
paths, Unix socket paths, link identifiers, epochs, and readiness descriptors
are not peer identity, trust, authority, or evidence of authorship. Pinned TLS
identity and overlay policy remain above every carrier.

## Supervised external packet adapters

The revision-0589 private boundary is now reachable through exact accepted V19
endpoints. Its unprepared standalone API is still not route authority. See the
[current execution contract](docs/CONFIGURED-ADAPTER-EXECUTION.md); descriptions
of earlier private-only milestones below are historical.


The private revision-0589 marker is:

```text
SUPERVISED_EXTERNAL_PACKET_ADAPTER_V1
```

The core launches one explicitly selected absolute executable with an exact
argument vector, descriptor 3, a minimal environment, closed unrelated file
descriptors, finite startup attempts, and bounded exponential backoff. The
canonical `NAPA0001` protocol negotiates one finite MTU/profile and carries
complete datagrams through the existing `OwnedCompleteDatagramPacketPort`.
Runtime death or protocol violation fails the carrier; it does not silently
recreate an authenticated stream.

Before revision 0596 this boundary was private-only. The configured path now
requires accepted V19 endpoint/profile authority. The unprepared connector and
listener registries still reject adapter execution. TCP, serial, UDP and Unix
datagrams retain their existing configured behavior.


## Deterministic configured-adapter adversity

The revision-0597 marker is:

```text
DETERMINISTIC_CONFIGURED_ADAPTER_ADVERSITY_V1
```

The product does not parse a fault schedule. The independently compiled pinned
ELF fixture consumes canonical bounded process schedules and writes canonical
bounded process traces. The existing fixture-owned UDP relay supplies canonical
packet schedules and traces. They remain outside the product build and cannot
assert identity, authority, application completion, custody or relay permission.

The focal lifecycle distinguishes startup failure before authentication from a
failed application write after authentication. Startup-budget exhaustion leaves
an obligation pending with zero application attempts. A silent NAPA response or
process death on an authenticated write can consume an attempt, but the
obligation remains pending and can complete only after a new process, carrier,
TLS/HELLO session and exact authenticated receipt. Fixed packet fault signatures
remain structurally stable under bounded CPU contention without comparing TLS
ciphertext hashes.

## Owner-controlled Unix datagrams

The production marker is:

```text
OWNER_CONTROLLED_UNIX_DATAGRAM_PACKET_CARRIER_V1
```

The canonical locator is:

```text
unix-dgram-v1|local=<percent-encoded-absolute-path>|remote=<percent-encoded-absolute-path>|mtu=<256..65507>|link=<16-lowercase-hex>|epoch=<nonzero-u32>|profile=1
```

The carrier:

- accepts only canonical absolute filesystem paths;
- traverses parent components without following symlinks;
- requires the final parent directories to be owned by the effective user and
  inaccessible to group and other users;
- refuses every pre-existing local path rather than guessing that it is stale;
- binds a nonblocking `AF_UNIX` datagram socket with owner-only permissions;
- remembers the exact parent and socket device/inode observations;
- filters received datagrams by the exact configured source path and effective
  user credentials;
- rejects truncation, unsafe ownership, unauthorized senders, and path
  replacement;
- releases one listener lease at a time with bounded reopen behavior; and
- removes only the exact socket object it created and still observes.

The finite packet service above it continues to own framing, integrity,
fragmentation, reassembly, retransmission, duplicate suppression, expiry,
backpressure, logical packet time, and semantic stream finish.

The available POSIX interfaces leave a residual same-UID race between a final
path check and `unlinkat`. Revision 0588 narrows that interval and uses exact
object checks, but records the remaining race as verification debt rather than
claiming it is impossible.

## Retained revision-0587 failure

Revision 0587 remains `REPAIR_REQUIRED`. Its wrapper invoked
`bash node/build.sh static` from the wrong directory, exited `127`, and produced
no product binary or source archive. Revision 0588 reconstructs from the
verified revision-0586 source and preserves the failed run as provenance.

## Build and verification

```sh
sh node/build.sh static
./node/bin/natrav-overlay version

python3 -B node/tests/run_configured_adapter_adversary.py \
  --binary node/bin/natrav-overlay \
  --output /tmp/natrav-0597-configured-adapter-adversity

python3 node/tests/run_matrix.py \
  --binary node/bin/natrav-overlay \
  --output /tmp/natrav-0597-full \
  --native-profile focused --timeout 600

sha256sum -c SHA256SUMS
```

Exact counts, hashes, retained attempts, and assurance claims belong in the
revision verification ledger and machine-readable delivery status.

Same-host Unix datagrams, loopback UDP, deterministic fixtures,
pseudoterminals, and local processes are useful model evidence. They are not
independent-host, Bluetooth, radio, USB-device, driver, electrical, power,
range, interference, or physical power-loss verification. Those debts do not
veto construction.

- [Autonomous continuation instructions](BOOTSTRAPROSE.md)
- [Configured-adapter deterministic adversity](docs/CONFIGURED-ADAPTER-ADVERSITY.md)
- [Supervised external packet adapter](docs/EXTERNAL-PACKET-ADAPTER.md)
- [Unix-domain datagram packet carrier](docs/UNIX-DATAGRAM-PACKET-CARRIER.md)
- [Owned complete-datagram packet port](docs/PACKET-PORT.md)
- [UDP adversary and persistent lifecycle](docs/UDP-DATAGRAM-ADVERSARY.md)
- [UDP packet carrier](docs/UDP-PACKET-CARRIER.md)
- [Packet ordered-stream design](docs/PACKET-LINK-ORDERED-STREAM.md)
- [Finite packet-link design](docs/PRIVATE_FINITE_PACKET_LINK.md)
- [Serial/TTY carrier](docs/SERIAL-TRANSPORT.md)
- [TLS over `ByteChannel`](docs/TLS-BYTE-CHANNEL.md)
- [Product status](docs/STATUS.md)
- [Next construction](docs/BUILD-PLAN.md)
- [Testing](docs/TESTING.md)
- [Provenance](docs/PROVENANCE.json)
