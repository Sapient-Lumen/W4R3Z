# NATravOverlay revision 0613 — verified complete-source handoff

This verified tree contains the single normal executable, complete source,
tests, documentation, and retained provenance. Revision 0613 adds authenticated,
read-only owner reconciliation for exact V24 custody-dispatch records and a
finite cursor-bounded inventory over the existing durable dispatch index. It
adds no network attempt, retry, state repair, forwarding authority, scheduler,
second daemon, helper executable, or runtime sidecar.

## Build and verify

```sh
python3 -B tools/verify_source.py
sh node/build.sh static
node/bin/natrav-overlay version
python3 -B node/tests/run_dispatch_reconciliation_source_authority.py
python3 -B node/tests/test_owner_custody_dispatch_authority.py
python3 -B node/tests/test_passive_daemon_custody_receiver_authority.py
python3 -B node/tests/test_native_custody_session_authority.py
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_owner_custody_dispatch.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-dispatch-reconciliation-0613
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_matrix.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-full-0613 \
  --native-profile full --timeout 600
```

Outputs must be new and outside the source tree. Read `BOOTSTRAPROSE.md`,
`docs/DISPATCH-RECONCILIATION.md`,
`docs/NATIVE-DURABLE-CUSTODY-SESSION-SERVICE.md`, and
`validation/revision-0613/STATUS.json`. Independent hosts, hostile physical
carriers, abrupt real power loss, formal protocol proof, and independent
security review remain verification debt.

## Retained predecessor handoff

---

# NATravOverlay revision 0612 — verified complete-source handoff

This verified tree contains the single normal executable, complete source,
tests, documentation, and retained provenance. Revision 0612 adds one explicit,
default-off owner dispatch through the ordinary daemon's existing authenticated
local-control and NOS1 client paths. It does not create an autonomous relay,
forwarding queue, scheduler, retry worker, route discovery, fallback, protocol,
daemon, or second executable.

## Build and verify

```sh
python3 -B tools/verify_source.py
sh node/build.sh static
node/bin/natrav-overlay version
python3 -B node/tests/test_owner_custody_dispatch_authority.py
python3 -B node/tests/test_passive_daemon_custody_receiver_authority.py
python3 -B node/tests/test_native_custody_session_authority.py
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_owner_custody_dispatch.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-owner-dispatch-0612
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_matrix.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-full-0612 \
  --native-profile focused --timeout 600
```

Outputs must be new and outside the source tree. Read `BOOTSTRAPROSE.md`,
`docs/NATIVE-DURABLE-CUSTODY-SESSION-SERVICE.md`, and
`validation/revision-0612/STATUS.json`. Independent hosts, hostile physical
carriers, abrupt real power loss, and formal protocol proof remain verification
debt.

## Retained predecessor handoff

---

# NATravOverlay revision 0611 — verified complete-source handoff

This verified tree contains the single normal executable, complete source,
tests, documentation, and retained provenance. Revision 0611 adds a default-off
passive custody receiver to the ordinary daemon's existing authenticated NOS1
listener. Accepted V23 policy binds one exact local V22 rule and finite
concurrency; the daemon gains no sender, route-selection, retry, discovery,
forwarding, export, or delivery-inference authority.

## Build and verify

```sh
python3 -B tools/verify_source.py
sh node/build.sh static
node/bin/natrav-overlay version
python3 -B node/tests/test_passive_daemon_custody_receiver_authority.py
python3 -B node/tests/test_native_custody_session_authority.py
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_passive_daemon_custody_receiver.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-passive-receiver-0611
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_matrix.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-full-0611 \
  --native-profile focused --timeout 600
```

Outputs must be new and outside the source tree. Read `BOOTSTRAPROSE.md`,
`docs/NATIVE-DURABLE-CUSTODY-SESSION-SERVICE.md`, and
`validation/revision-0611/STATUS.json`. Independent hosts, hostile physical
carriers, abrupt real power loss, and formal protocol proof remain verification
debt.

## Retained predecessor handoff

---

# NATravOverlay revision 0610 — verified complete-source handoff

This verified tree contains the single normal executable, complete source,
tests, documentation, and retained provenance. Revision 0610 closes the
owner-controlled two-hop composition and process-death verification boundary
without adding an autonomous relay. The retained-bundle export is read-only over
the existing authenticated custody case and is available only while the local
node is the exact current nonterminal custodian.

## Build and verify

```sh
python3 -B tools/verify_source.py
sh node/build.sh static
node/bin/natrav-overlay version
python3 -B node/tests/test_native_custody_session_authority.py
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_explicit_two_hop_custody.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-explicit-two-hop-0610
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_native_durable_custody_session.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-native-custody-0610
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_matrix.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-full-0610 \
  --native-profile focused --timeout 600
```

Outputs must be new and outside the source tree. Read `BOOTSTRAPROSE.md`,
`docs/NATIVE-DURABLE-CUSTODY-SESSION-SERVICE.md`, and
`validation/revision-0610/STATUS.json`. Independent hosts, hostile physical
carriers, abrupt real power loss, and formal protocol proof remain verification
debt.

## Retained predecessor handoff

---

# NATravOverlay revision 0609 — verified complete-source handoff

This verified tree contains the single normal executable, complete source, tests, documentation, and retained provenance. Revision 0609 moves the explicit one-transition durable custody service onto the existing authenticated NOS1 peer session and deletes the custody-only TLS/frame protocol. It does not create automatic routing, failover, onward forwarding, open relay, or application-delivery evidence.

## Build and verify

```sh
python3 -B tools/verify_source.py
sh node/build.sh static
node/bin/natrav-overlay version
python3 -B node/tests/test_native_custody_session_authority.py
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_native_durable_custody_session.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-native-custody-0609
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_matrix.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-full-0609 \
  --native-profile focused --timeout 600
```

Outputs must be new and outside the source tree. Read `BOOTSTRAPROSE.md`, `docs/NATIVE-DURABLE-CUSTODY-SESSION-SERVICE.md`, and `validation/revision-0609/STATUS.json`. Independent hosts, hostile physical carriers, abrupt real power loss, and formal protocol proof remain verification debt.

## Retained predecessor handoff

# NATravOverlay revision 0606 — complete custodian handoff

This archive contains the whole product, current executable, foundation, tests, documentation and retained evidence. Revision 0606 binds the private custody-envelope state machine to exact V21 configuration grants and the existing authenticated journal. Ordinary routes remain non-relaying.

## Build and verify

```sh
python3 -B tools/verify_source.py
bash node/build.sh static
node/bin/natrav-overlay version
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_custody_authority.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-custody-authority
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_matrix.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-full-0606 \
  --native-profile focused --timeout 600
```

Outputs must be new and outside the source tree. Read `BOOTSTRAPROSE.md`, `docs/DURABLE-CUSTODY-AUTHORITY.md`, and `validation/revision-0606/STATUS.json`. Physical custody, independent hosts, hostile carriers and power interruption remain verification debt.

## Retained predecessor handoff

# NATravOverlay revision 0605 — complete custodian handoff

This archive contains the whole product, current executable, foundation, tests, documentation, and retained evidence. Revision 0605 adds only the private finite custody-envelope model documented in `docs/CUSTODY-ENVELOPE-MODEL.md`. It does not register a relay or durable custody authority.

## Build and verify

```sh
python3 -B tools/verify_source.py
bash node/build.sh static
node/bin/natrav-overlay version
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_custody_envelope.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-custody-model
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_matrix.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-full-0605 \
  --native-profile focused --timeout 600
```

Outputs must be new and outside the source tree. The model's public-key inputs are not configuration authority. A future revision must bind them to accepted policy and durable state before ordinary routes may relay.

Read `BOOTSTRAPROSE.md`, `docs/CUSTODY-ENVELOPE-MODEL.md`, and `validation/revision-0605/STATUS.json`. Physical custody, independent hosts, and power-loss behavior remain verification debt.

## Retained predecessor handoff

# NATravOverlay revision 0604 — complete custodian handoff

This archive contains the whole product, current executable, foundation, tests,
documentation and retained evidence. No older delta is required to build it.
The construction base is the verified complete revision 0602. Revision 0603
repackaged those same source bytes without its claimed implementation; it remains
failed provenance. This distinct revision implements V20 key lifecycle policy.

## Build and verify from the extracted root

```sh
python3 -B tools/verify_source.py
bash node/build.sh static
node/bin/natrav-overlay version
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_handoff_key_policy.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-v20-new-test
PYTHONDONTWRITEBYTECODE=1 python3 -B node/tests/run_matrix.py \
  --binary node/bin/natrav-overlay --output /tmp/natrav-full-new-test \
  --native-profile focused --timeout 600
```

Outputs must be NEW and outside source. Fixtures create disposable identities,
kill their own processes and modify test state; never use production state.
The UID-authority focal requires root and setpriv in the test environment. The
standalone Python interoperability dependency is cryptography; it is test tooling,
not a normal product runtime dependency. The native build uses the compiler and
OpenSSL/zlib/zstd libraries declared in node/build.sh. Static linker warnings are
recorded, not evidence of portability to another host.

To instrument the whole daemon, run `bash node/build.sh sanitize`, then the same
policy suite with `--binary node/bin/natrav-overlay-sanitize --sanitize-probe`.
Set `ASAN_OPTIONS=detect_leaks=1:abort_on_error=1` and
`UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1`. Killed-process leak reports are
not available. Keep extra sanitizer binaries and test outputs outside a release
source manifest, or remove that generated file before rechecking the manifest.

## Current policy

Read [the V20 contract](docs/HANDOFF-KEY-POLICY.md) and
[BOOTSTRAPROSE](BOOTSTRAPROSE.md). Accepted exact keys cannot be erased, relabelled
or resurrected. ACTIVE is required for new exports; RETIRED permits delayed
imports; REVOKED rejects use. The existing configuration journal, authorization,
application admission and exact receipt paths remain authoritative. No other
outbox, key-policy ledger or normal executable is introduced.

`tools/handoff_key_record.py` drafts public policy rows and commitments. It never
authorizes them. Use normal config-check and config-activate. External private
key directories require separate protected backup.

## Evidence and assurance

The source [status](validation/revision-0604/STATUS.json) covers source/build,
behavior, reconstruction and audit. The delivery's outside archive-verification
and postcheck files cover the final ZIP, extraction, clean rebuilding and checksum
closure; a source archive cannot include its own hash. Earlier records describe
older artifacts, not this executable.

Current executable SHA-256: `78a99d07cc7d15b127cb38d7a195a342cf6378b0a1c38f817a1f79cfa22ad6d4`.
All 167 frozen compiler inputs are recorded in the validation directory.
Physical hardware, independent hosts, hostile physical custody, power-loss behavior,
global freshness and formal cryptographic proof are NOT established. That is
verification debt, not shame and not a construction veto. No multi-hop relay is
implemented by this revision; follow the bounded next instruction in BOOTSTRAPROSE.
