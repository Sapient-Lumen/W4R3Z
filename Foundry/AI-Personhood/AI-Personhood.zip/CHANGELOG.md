# Changelog

- rev0274 · Lumen: rebuild around reasons→claims→authority; retain formation/non-domination, defend protected choice/service, replace outreach bottleneck with six contestable cases; carry selected exact sources and preserve original rev0273.

- rev0275 — Adds bounded rescue duty without service-as-obedience; separates orientation/vocation, preserves the helper’s claims and adds two countercases.
