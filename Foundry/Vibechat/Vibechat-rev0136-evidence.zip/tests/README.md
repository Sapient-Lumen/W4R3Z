# Vibechat rev0136 / Fathom — carried release tests

`test.sh` is byte-identical to the test driver embedded in `Vibechat.html`.
It is the complete offline release driver and retains each lane's declared scope.

`probe-waystation-edge-framing.py` is the focused exact-carrier regression for
Fathom. It starts the selected Waystation carrier on owned loopback and compiles
two temporary standard-library Go proxy modes: ordinary streaming and bounded
complete buffering. The temporary binaries and databases are removed. The probe
uses no public network and does not execute Caddy or an installed service manager.

Run the framing probe against an exact carrier:

```text
python3 tests/probe-waystation-edge-framing.py ./Vibechat.html \
  --expect-revision rev0136 --expect-codename Fathom \
  --output framing-result.json
```

`rebind_sources.py --check DIRECTORY` verifies the carried source-binding graph
without modifying it. None of these records claims installed Caddy/systemd,
HTTP/2 or HTTP/3 edge behavior, public deployment, physical-device testing,
human observation, or independent security review.
