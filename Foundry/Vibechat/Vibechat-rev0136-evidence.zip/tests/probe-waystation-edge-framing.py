#!/usr/bin/env python3
"""Probe Waystation request framing through a source-coupled Go reverse proxy.

The unbuffered mode models Caddy's ordinary HTTP reverse-proxy path. The buffered
mode models Caddy v2.11.7 request_buffers after a bounded body-size gate: a fully
buffered body is forwarded with a known Content-Length. This does not execute the
Caddy binary or an installed service manager.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import pathlib
import socket
import sqlite3
import subprocess
import tempfile
import time
import urllib.request
from typing import Any

TOPIC = "vc_" + "e" * 48
EDGE_LIMIT = 20_000
GO_PROXY = r'''package main
import (
    "bytes"
    "encoding/json"
    "flag"
    "fmt"
    "io"
    "log"
    "net"
    "net/http"
    "net/http/httputil"
    "net/url"
    "os"
    "strconv"
)
func main() {
    upstreamFlag := flag.String("upstream", "", "upstream origin")
    bufferFlag := flag.Bool("buffer", false, "fully buffer bounded request bodies")
    limitFlag := flag.Int64("limit", 20000, "maximum client body bytes")
    flag.Parse()
    if *upstreamFlag == "" { log.Fatal("--upstream is required") }
    upstream, err := url.Parse(*upstreamFlag); if err != nil { log.Fatal(err) }
    proxy := httputil.NewSingleHostReverseProxy(upstream)
    proxy.Transport = &http.Transport{Proxy: nil, DisableKeepAlives: true}
    proxy.ErrorHandler = func(w http.ResponseWriter, r *http.Request, err error) {
        w.Header().Set("Content-Type", "application/json")
        w.WriteHeader(http.StatusBadGateway)
        _, _ = w.Write([]byte(`{"error":"upstream framing failure"}`))
    }
    handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        r.Body = http.MaxBytesReader(w, r.Body, *limitFlag)
        if *bufferFlag && r.Body != nil {
            body, err := io.ReadAll(r.Body)
            if err != nil {
                http.Error(w, "request body too large", http.StatusRequestEntityTooLarge)
                return
            }
            _ = r.Body.Close()
            r.Body = io.NopCloser(bytes.NewReader(body))
            r.ContentLength = int64(len(body))
            r.TransferEncoding = nil
            r.Header.Del("Transfer-Encoding")
            r.Header.Set("Content-Length", strconv.Itoa(len(body)))
        }
        proxy.ServeHTTP(w, r)
    })
    listener, err := net.Listen("tcp", "127.0.0.1:0"); if err != nil { log.Fatal(err) }
    ready := map[string]any{
        "listen": "http://"+listener.Addr().String(),
        "upstream": upstream.String(),
        "buffer": *bufferFlag,
        "request_body_limit_bytes": *limitFlag,
        "framing": map[bool]string{true:"content-length-after-complete-buffer", false:"stream-client-framing"}[*bufferFlag],
    }
    if err := json.NewEncoder(os.Stdout).Encode(ready); err != nil { log.Fatal(err) }
    if err := http.Serve(listener, handler); err != nil { log.Fatal(fmt.Errorf("serve: %w", err)) }
}
'''


def sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_json(command: list[str], timeout: float = 30) -> dict[str, Any]:
    completed = subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    return json.loads(completed.stdout)


def wait_json(path: pathlib.Path, process: subprocess.Popen[bytes], timeout: float = 15) -> dict[str, Any]:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if path.exists():
            return json.loads(path.read_text())
        if process.poll() is not None:
            out, err = process.communicate(timeout=1)
            raise RuntimeError((process.returncode, out.decode(errors="replace"), err.decode(errors="replace")))
        time.sleep(0.05)
    raise TimeoutError(path)


def stop(process: subprocess.Popen[Any] | None) -> tuple[str, str]:
    if process is None:
        return "", ""
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=8)
        except subprocess.TimeoutExpired:
            process.kill(); process.wait(timeout=5)
    out, err = process.communicate(timeout=2)
    if isinstance(out, bytes): out = out.decode(errors="replace")
    if isinstance(err, bytes): err = err.decode(errors="replace")
    return out or "", err or ""


def raw_request(origin: str, path: str, body: bytes, *, chunked: bool) -> dict[str, Any]:
    host_port = origin.removeprefix("http://")
    host, port_text = host_port.rsplit(":", 1)
    if chunked:
        framing = b"Transfer-Encoding: chunked\r\n"
        encoded = f"{len(body):x}\r\n".encode() + body + b"\r\n0\r\n\r\n"
    else:
        framing = f"Content-Length: {len(body)}\r\n".encode()
        encoded = body
    request = (
        f"POST {path} HTTP/1.1\r\nHost: {host_port}\r\n".encode()
        + b"Content-Type: text/plain\r\n"
        + framing
        + b"Connection: close\r\n\r\n"
        + encoded
    )
    started = time.monotonic()
    with socket.create_connection((host, int(port_text)), timeout=8) as conn:
        conn.settimeout(15)
        conn.sendall(request)
        chunks: list[bytes] = []
        while True:
            try: data = conn.recv(65536)
            except socket.timeout: break
            if not data: break
            chunks.append(data)
    raw = b"".join(chunks)
    head, _, payload = raw.partition(b"\r\n\r\n")
    status_line = head.split(b"\r\n", 1)[0].decode("ascii", "replace") if head else ""
    parts = status_line.split()
    status = int(parts[1]) if len(parts) >= 2 and parts[1].isdigit() else None
    return {
        "status": status,
        "status_line": status_line,
        "body": payload.decode("utf-8", "replace"),
        "request_framing": "chunked" if chunked else "content-length",
        "elapsed_seconds": round(time.monotonic() - started, 3),
    }


def mailbox(url: str) -> list[dict[str, Any]]:
    with urllib.request.urlopen(url + f"/{TOPIC}/json?poll=1&since=all", timeout=10) as response:
        return [json.loads(line) for line in response.read().decode().splitlines() if line.strip()]


def check(name: str, condition: bool, checks: list[dict[str, Any]]) -> None:
    checks.append({"name": name, "passed": bool(condition)})
    if not condition:
        raise AssertionError(name)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("carrier", type=pathlib.Path)
    parser.add_argument("--output", required=True, type=pathlib.Path)
    parser.add_argument("--expected-sha256")
    parser.add_argument("--expected-revision", required=True)
    parser.add_argument("--expected-codename", required=True)
    parser.add_argument("--expect-request-buffers", choices=("yes", "no"), required=True)
    args = parser.parse_args()
    carrier = args.carrier.resolve(); output = args.output.resolve(); carrier_hash = sha256(carrier)
    if args.expected_sha256 and carrier_hash != args.expected_sha256:
        raise SystemExit("carrier SHA-256 does not match --expected-sha256")
    verification = run_json(["bash", str(carrier), "verify"])
    checks: list[dict[str, Any]] = []
    check("carrier identity matches expectation", verification.get("verified") is True and verification.get("revision") == args.expected_revision, checks)
    result: dict[str, Any] = {
        "format": "vibechat-edge-request-framing-probe-v1",
        "revision": args.expected_revision,
        "codename": args.expected_codename,
        "carrier_sha256": carrier_hash,
        "carrier_bytes": carrier.stat().st_size,
        "scope": (
            "Exact Waystation carrier plus two standard-library Go reverse-proxy modes. The streaming mode "
            "models ordinary HTTP proxying of an unknown-length client body; the bounded-buffer mode models "
            "Caddy v2.11.7 request_buffers after a 20 KB request-body gate. This is not execution of the Caddy "
            "binary, systemd/cgroup, a public edge, HTTP/2 or HTTP/3."
        ),
        "checks": checks,
    }
    waystation: subprocess.Popen[bytes] | None = None
    stream_proxy: subprocess.Popen[str] | None = None
    buffer_proxy: subprocess.Popen[str] | None = None
    with tempfile.TemporaryDirectory(prefix="vibechat-edge-framing-") as temporary:
        root = pathlib.Path(temporary)
        kit = root / "kit"
        kit_result = run_json([
            "bash", str(carrier), "waystation-kit", "--url", "https://example.test/vibe",
            "--directory", str(kit), "--port", "49136", "--request-timeout", "5", "--max-connections", "8",
        ])
        caddyfile = (kit / "Caddyfile").read_text(); manifest = json.loads((kit / "manifest.json").read_text())
        has_buffers = "request_buffers 20KB" in caddyfile
        result["kit"] = {
            "carrier_revision": kit_result.get("carrier_revision"),
            "carrier_codename": kit_result.get("carrier_codename"),
            "request_buffers_20KB": has_buffers,
            "request_body_max_size_20KB": "max_size 20KB" in caddyfile,
            "manifest_edge_request_buffer": manifest.get("edge_request_buffer"),
            "manifest_edge_request_buffer_bytes": manifest.get("edge_request_buffer_bytes"),
            "manifest_edge_upstream_request_framing": manifest.get("edge_upstream_request_framing"),
            "manifest_edge_request_framing_scope": manifest.get("edge_request_framing_scope"),
        }
        check("kit binds exact carrier identity", kit_result.get("carrier_revision") == args.expected_revision and kit_result.get("carrier_codename") == args.expected_codename and kit_result.get("carrier_sha256") == carrier_hash, checks)
        check("generated edge retains 20 KB body-size gate", "max_size 20KB" in caddyfile, checks)
        check("generated request-buffer expectation matches", has_buffers is (args.expect_request_buffers == "yes"), checks)
        check("kit and manifest publish the exact 20 KB per-request buffer", all(value.get("edge_request_buffer") == "20KB" and value.get("edge_request_buffer_bytes") == 20000 for value in (kit_result, manifest)), checks)
        check("kit and manifest publish definite upstream Content-Length framing", all(value.get("edge_upstream_request_framing") == "content-length-after-complete-buffer" for value in (kit_result, manifest)), checks)
        check("published framing scope keeps 16 KiB below the buffer and rejects aggregate-capacity claims", all("16 KiB" in value.get("edge_request_framing_scope", "") and "definite Content-Length" in value.get("edge_request_framing_scope", "") and "per-request framing buffer" in value.get("edge_request_framing_scope", "") and "aggregate edge-memory" in value.get("edge_request_framing_scope", "") for value in (kit_result, manifest)), checks)

        go_source = root / "proxy.go"; go_binary = root / "proxy"
        go_source.write_text(GO_PROXY)
        subprocess.run(["go", "build", "-trimpath", "-o", str(go_binary), str(go_source)], check=True, timeout=90)
        ready_file = root / "ready.json"; data = root / "data"
        try:
            waystation = subprocess.Popen([
                "bash", str(carrier), "waystation", "--host", "127.0.0.1", "--port", "0",
                "--data-dir", str(data), "--ready-file", str(ready_file), "--request-timeout", "5", "--max-connections", "8",
            ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            ready = wait_json(ready_file, waystation)
            result["waystation"] = {"url": ready["waystation_url"], "message_limit": 16 * 1024}

            def start_proxy(buffered: bool) -> tuple[subprocess.Popen[str], dict[str, Any]]:
                process = subprocess.Popen([
                    str(go_binary), "--upstream", ready["waystation_url"], "--limit", str(EDGE_LIMIT),
                    *( ["--buffer"] if buffered else [] ),
                ], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                line = process.stdout.readline() if process.stdout else ""
                if not line: raise RuntimeError(process.stderr.read() if process.stderr else "proxy did not publish readiness")
                return process, json.loads(line)

            stream_proxy, stream_ready = start_proxy(False)
            known_body = b"known-length-control"
            known = raw_request(stream_ready["listen"], f"/{TOPIC}", known_body, chunked=False)
            chunked_body = b"unknown-length-streamed-body"
            streamed = raw_request(stream_ready["listen"], f"/{TOPIC}", chunked_body, chunked=True)
            _stream_out, stream_err = stop(stream_proxy); stream_proxy = None

            buffer_proxy, buffer_ready = start_proxy(True)
            buffered_body = b"unknown-length-buffered-body"
            buffered = raw_request(buffer_ready["listen"], f"/{TOPIC}", buffered_body, chunked=True)
            _buffer_out, buffer_err = stop(buffer_proxy); buffer_proxy = None
            time.sleep(0.2)
            retained_rows = mailbox(ready["waystation_url"])
            retained = [row.get("message") for row in retained_rows]
            db = sqlite3.connect(data / "waystation.sqlite3")
            try: integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
            finally: db.close()
            result.update(
                stream_proxy=stream_ready,
                buffer_proxy=buffer_ready,
                known_length_response=known,
                unbuffered_unknown_length_response=streamed,
                buffered_unknown_length_response=buffered,
                retained_messages=retained,
                database_integrity=integrity,
                stream_proxy_stderr=stream_err[-2000:],
                buffer_proxy_stderr=buffer_err[-2000:],
            )
            check("known-length control succeeds through ordinary proxying", known.get("status") == 200, checks)
            check("unknown-length ordinary proxying reaches strict backend as transfer-coded and is refused", streamed.get("status") == 400 and "Chunked request bodies are not accepted" in streamed.get("body", ""), checks)
            check("bounded complete buffering converts the same client framing into an accepted publication", buffered.get("status") == 200, checks)
            check("only successful publications are retained", retained == [known_body.decode(), buffered_body.decode()], checks)
            check("unbuffered refused body is absent", chunked_body.decode() not in retained, checks)
            check("SQLite integrity remains ok", integrity == "ok", checks)
            check("proxy analogue emits no traceback or request body", "Traceback" not in stream_err + buffer_err and chunked_body.decode() not in stream_err + buffer_err, checks)
        finally:
            stream_out, stream_err2 = stop(stream_proxy)
            buffer_out, buffer_err2 = stop(buffer_proxy)
            way_out, way_err = stop(waystation)
            result["cleanup_stderr"] = (stream_err2 + buffer_err2 + way_err)[-3000:]
            check("expected framing exercise emits no Waystation traceback", "Traceback" not in way_err, checks)

    result["passed"] = sum(1 for row in checks if row["passed"])
    result["tests"] = len(checks)
    result["status"] = "passed-scoped" if result["passed"] == result["tests"] else "failed"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
