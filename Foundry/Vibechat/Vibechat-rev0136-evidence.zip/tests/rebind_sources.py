#!/usr/bin/env python3
"""Rebind a Vibechat extracted worktree, preserving each declared digest convention.

Only source-bound JSON documents are changed. No code is executed, installed or
fetched. Refuses cycles, unsafe paths, or an unrecognized existing body digest.
Usage: python rebind_sources.py EXTRACTED_DIRECTORY [--check]
"""
from __future__ import annotations
import argparse,hashlib,json,pathlib

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('directory',type=pathlib.Path);ap.add_argument('--check',action='store_true');args=ap.parse_args();root=args.directory.resolve()
    documents={};modes={}
    for path in sorted(root.glob('*.json')):
        value=json.loads(path.read_text())
        if not isinstance(value,dict) or 'source_bindings' not in value:continue
        assert not path.is_symlink(),path
        keys=[key for key in value if key.endswith('_body_sha256')]
        assert len(keys)==1,(path,keys)
        key=keys[0];choices=[]
        for excluded in ([key],[key,'source_bindings']):
            if sha(canonical({k:v for k,v in value.items() if k not in excluded}))==value[key]:choices.append(excluded)
        assert len(choices)==1,('Unknown or inconsistent digest convention',path)
        documents[path.name]=value;modes[path.name]=(key,choices[0])
    done=set();visiting=set();changed=[];mismatches=[]
    def refresh(name):
        if name in done:return
        if name in visiting:raise ValueError('Source binding cycle: '+name)
        visiting.add(name);value=documents[name]
        for record in value['source_bindings']:
            rel=pathlib.PurePosixPath(record['path'])
            if rel.is_absolute() or '..' in rel.parts:raise ValueError('Unsafe source path')
            path=root/rel
            if path.is_symlink() or not path.is_file():raise ValueError('Missing or symlink source: '+str(path))
            if str(rel) in documents:refresh(str(rel))
            data=path.read_bytes();actual={'bytes':len(data),'sha256':sha(data)}
            if any(record[k]!=actual[k] for k in actual):mismatches.append(name+':'+str(rel))
            if not args.check:record.update(actual)
        if not args.check:
            key,excluded=modes[name];value[key]=sha(canonical({k:v for k,v in value.items() if k not in excluded}))
            data=(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
            path=root/name
            if path.read_bytes()!=data:path.write_bytes(data);changed.append(name)
        visiting.remove(name);done.add(name)
    for name in documents:refresh(name)
    report={'source_documents':len(documents),'bindings':sum(len(v['source_bindings']) for v in documents.values()),'digest_conventions_verified':len(modes),'changed_documents':changed,'mismatches_before_update':mismatches,'mode':'check' if args.check else 'rebind'}
    print(json.dumps(report,indent=2))
    if args.check and mismatches:raise SystemExit(1)
if __name__=='__main__':main()
