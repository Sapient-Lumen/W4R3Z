# Vibechat rev0136 / Fathom — release receipt

Date: 2026-10-22 (America/New_York). Product: `Vibechat.html`, **10,933,910 bytes**, SHA-256 `e48f115825f5b35b4e2b749813da028b5dadea4e6321cd71f59a5bb755897a7e`.

Predecessor: rev0135 / Longwatch, 10,923,213 bytes, SHA-256 `8acca0ecf53a641c78e2df0d3469c9094932a6981e3ab6ecf4859a5b7452459c`.

## Reproduced request-framing defect

Longwatch generated a 20 KB public request-body size gate, but its Caddy `reverse_proxy` block did not buffer request bodies. The strict Waystation rejects `Transfer-Encoding`, requires `Content-Length`, and accepts at most 16 KiB.

The exact predecessor was started on owned loopback. A small standard-library Go proxy sent three bounded publications:

1. known-length ordinary proxying — HTTP 200;
2. unknown-length ordinary proxying — transfer-coded upstream request and HTTP 400; and
3. unknown-length complete buffering with a 20,000-byte ceiling — definite upstream length and HTTP 200.

The two successful publications were retained, the refused body was absent, SQLite integrity was `ok`, and no traceback or request text appeared in diagnostics. `verification/rev0135-edge-request-framing-probe.json` binds the predecessor hash and records 12/12 scoped assertions.

## Implementation

Fathom retains the public size gate and adds this inside the generated reverse proxy:

```caddyfile
request_buffers 20KB
```

The generated edge now reads at most 20,000 bytes before the loopback round trip. Every backend-admissible Waystation body is at most 16,384 bytes, so it fits completely below that bound and reaches the strict backend with a definite `Content-Length`.

Deployment-kit output and the kit manifest publish:

```text
edge_request_body_max_size = 20KB
edge_request_body_max_bytes = 20000
edge_request_buffer = 20KB
edge_request_buffer_bytes = 20000
edge_upstream_request_framing = content-length-after-complete-buffer
```

The published scope says this is a bounded per-request framing buffer, not aggregate edge memory, client connections, queueing, rate limiting, host capacity, or denial-of-service resistance. Incremental request bodies remain outside the Waystation protocol.

Longwatch's no-fixed-response-header-timeout behavior and every Splice request/connection/no-retry/no-keepalive/no-ambient-proxy control remain. No browser workflow, invitation, cryptographic primitive, successful message format, storage schema, retention algorithm, retry behavior, or delivery claim changed.

## Exact-current-carrier regression

`verification/rev0136-edge-request-framing.json` records 15/15 scoped assertions against the exact final carrier:

- exact carrier and deployment-kit identity;
- both 20 KB generated controls;
- exact buffer and framing fields in kit output and manifest;
- per-request/non-capacity scope;
- known-length ordinary success;
- unknown-length ordinary transfer-coding refusal;
- unknown-length bounded-buffer success;
- exact retained-state result;
- refused body absent;
- SQLite integrity `ok`; and
- no traceback or request-sensitive diagnostic.

`tests/probe-waystation-edge-framing.py` is the executable reproducer. Temporary compiled proxies and runtime databases are not packaged.

## Exact-carrier evidence

Every enclosing release receipt binds the final product hash above.

| Lane | Passed |
|---|---:|
| Native API and relay transport | 20/20 |
| Diagnostic, Waystation, storage, TLS, worker, edge, shutdown, and terminal | 68/68 |
| Courier transport | 16/16 |
| Combined transport | 104/104 |
| Deterministic protocol review | 28/28 |
| Malformed-input corpus | 49/49 |
| Raw-JSON admission corpus | 96/96 |
| Prekey composition | 31/31 |
| Exhaustive carrier contract | 212/212 |
| External edge-request-framing probe | 15/15 scoped |

The external probe is separate from the 104 transport checks and is not counted twice.

## Static, build, and compatibility checks

The carrier has 150 named members. All 99 top-level Python files compile; all 42 top-level JSON files parse. Client and worker JavaScript syntax and test-driver shell syntax pass. All 296 bindings across 32 source-bound documents match, including all 32 digest conventions.

The current-status response is 32,711 bytes including its newline, 57 bytes below the fixed 32 KiB boundary. Offline TypeScript/Clang rebuilding reproduces `worker.js` and `vendor.json` byte-for-byte. Fresh extraction and unchanged repacking reproduce the carrier exactly. The external `tests/test.sh` is byte-identical to the carried driver.

Comparison with rev0135 records 43 changed members, zero additions, and zero removals. Self-comparison records no changes. Browser-client changes are release-identity-only; the functional change is in native deployment-kit generation and exact-carrier evidence.

## Qualification boundary

The environment contained no Caddy binary. PID 1 was Supervisor, `systemctl is-system-running` returned `offline`, and cgroup v2 was read-only. No administrator policy or host configuration was changed or bypassed.

Fathom therefore does not claim actual Caddy parsing or runtime behavior, installed systemd/cgroup enforcement, HTTP/2 or HTTP/3 request framing, public certificates, hostile traffic, aggregate edge capacity, physical storage, physical-browser testing, human observation, or independent review. It adds no exactly-once publication, deduplication, automatic retry, durable peer receipt, or recovery-time promise.

## Rejected and excluded evidence

A preseal carrier candidate exposed five Longwatch-era status substrings in one historical current-status assertion. The assertion was updated to the equivalent Fathom semantics, the 32-document source graph was rebound, and the carrier was resealed. One initial enclosing transport run then encountered a timing-sensitive silent-TLS assertion while other heavy lanes were active. Its partial receipt was discarded. Every credited lane was rerun against the final product hash. Candidate-hash, failed, partial, interrupted, and superseded results are not packaged as passing evidence.

## Package contract

Only `BOOTSTRAPROSE.md` and `Vibechat.html` are regular root files. Every ancillary artifact is beneath `reports/` or `tests/`. The complete 12,360,896-byte Longwatch bootstrap, SHA-256 `e3457abd4df830dec1b721bf9736f447455260703d9bdf985e7957cdc6e78374`, is retained unchanged as the suffix of the revised bootstrap.

The manifest and checksum inventory bind delivered bytes. Content hashes are not publisher authentication, provenance attestation, or independent security review. Deterministic-archive and fresh-extraction results are recorded in the external final package-verification record.
