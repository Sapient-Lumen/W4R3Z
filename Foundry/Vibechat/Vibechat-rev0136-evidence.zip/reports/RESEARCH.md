# Rev0136 / Fathom — primary-source research receipt

Checked: 2026-10-22 (America/New_York)

## Question

Longwatch generated a 20 KB public request-body size gate but did not buffer the reverse-proxy request body. The strict Waystation accepts one explicit `Content-Length`, rejects `Transfer-Encoding`, and limits messages to 16 KiB. The research question was whether an otherwise valid unknown-length request could reach the loopback HTTP/1.1 backend as transfer-coded, and whether a bounded Caddy request buffer could provide the required framing without claiming aggregate capacity.

## Primary sources reviewed

1. **Caddy `reverse_proxy` documentation** — https://caddyserver.com/docs/caddyfile/directives/reverse_proxy
   - `request_buffers <size>` reads up to the configured amount before proxying.
   - When the entire body is buffered, Caddy sets upstream `Content-Length`.
   - The documentation warns that buffering is inefficient, so Fathom uses the existing finite 20 KB public body gate and does not use `unlimited`.
   - Requests marked `Incremental: ?1` are not buffered and are outside the Waystation publication protocol.

2. **Caddy v2.11.7 exact source** — https://github.com/caddyserver/caddy/blob/v2.11.7/modules/caddyhttp/reverseproxy/reverseproxy.go
   - The reverse-proxy handler reads at most `RequestBuffers` bytes.
   - If the buffer contains the complete body, the source sets both the request content-length field and the `Content-Length` header before the upstream round trip.
   - This is the exact Caddy version targeted by the generated deployment kit.

3. **Go `net/http.Request.Write` documentation** — https://pkg.go.dev/net/http#Request.Write
   - For HTTP/1.1, a present body with non-positive `ContentLength` and no identity transfer setting is written with `Transfer-Encoding: chunked`.
   - This supplies the framing mechanism used by the ordinary streaming proxy mode in the controlled predecessor probe.

4. **Caddy v2.11.7 release identity** — https://github.com/caddyserver/caddy/releases/tag/v2.11.7
   - The reviewed source and documentation target remain pinned to the official v2.11.7 release rather than an unversioned local implementation.

## Measured predecessor finding

Exact rev0135 was started on owned loopback. A known-length control succeeded through an ordinary Go reverse proxy. An unknown-length request with valid media type and body size reached the strict backend with transfer coding and received HTTP 400. A second unknown-length request through a 20,000-byte complete-buffer mode reached the backend with definite length and received HTTP 200.

The successful control and buffered publication were retained, the refused body was absent, SQLite integrity was `ok`, and no traceback or request text appeared in diagnostics. The structured predecessor receipt is `verification/rev0135-edge-request-framing-probe.json`.

## Measured current result

Exact rev0136 generates both:

```text
request_body { max_size 20KB }
request_buffers 20KB
```

Kit output and manifest publish the exact 20,000-byte limit, definite upstream framing, and a per-request/non-capacity scope. The same 15-check controlled regression passes: known-length HTTP 200, ordinary unknown-length HTTP 400, bounded-buffer unknown-length HTTP 200, exact retained-state result, and SQLite integrity `ok`.

The current structured receipt is `verification/rev0136-edge-request-framing.json`; the executable probe is `tests/probe-waystation-edge-framing.py`.

## Qualification boundary

This environment contained no Caddy binary. PID 1 was Supervisor, `systemctl is-system-running` returned `offline`, and cgroup v2 was mounted read-only. No administrator policy or host configuration was changed or bypassed.

The evidence therefore covers the exact Waystation carrier, generated Caddy source contract, exact Caddy v2.11.7 source semantics, and standard-library HTTP/1.1 framing behavior. It does not claim actual Caddy parsing or execution, installed systemd/cgroup enforcement, HTTP/2 or HTTP/3 behavior, public certificates, hostile traffic, aggregate edge memory, portable queue behavior, denial-of-service resistance, physical storage, physical browsers, human observation, or independent review.
