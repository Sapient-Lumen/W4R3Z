# Vibechat running checklist — rev0136 / Fathom

## Completed and removed from the active queue

- [x] Reproduce the exact rev0135 unknown-length request-framing mismatch against the strict Waystation backend.
- [x] Preserve the generated 20 KB public request-body size gate.
- [x] Add `request_buffers 20KB` inside the generated Caddy reverse proxy.
- [x] Keep the complete buffer above Waystation's 16 KiB message ceiling and publish both exact byte values.
- [x] Publish definite upstream `Content-Length` framing and a bounded per-request/non-capacity scope through kit output, manifest, status, evidence, and operator documentation.
- [x] Verify known-length success, ordinary transfer-coding refusal, bounded-buffer success, retained-state correctness, and SQLite integrity.
- [x] Preserve Longwatch's no-fixed-response-deadline rule and all Splice, Keel, Berth, Gatehouse, and earlier boundaries.
- [x] Rebind all 296 source declarations across 32 documents and verify all 32 digest conventions.
- [x] Complete final-hash transport, protocol, parser, composition, carrier, compiler, extraction, repacking, checksum, suffix, and deterministic-package gates.
- [x] Preserve the two-core-file ZIP root and directory-only ancillary layout.

## Active queue

- [ ] **P0 — installed Caddy/systemd/cgroup execution.** Run the exact generated Fathom contract under an authorized installed manager. Confirm Caddy parsing and request buffering; enforce backend slots, upstream request/connection limits, `TasksMax`, `LimitNOFILE`, `TimeoutStopSec`, client-edge limits, pre-header/TLS admission, kernel queues, reload, clean stop, and forced stop. Include unknown-length HTTP/1.1 plus HTTP/2 and HTTP/3 request-body framing. Preserve an unavailable receipt rather than substituting source inspection or a proxy analogue.
- [ ] **P1 — physical clipboard and lifecycle qualification.** Current Chromium, Firefox, and Safari across desktop, Android, and iOS; permission outcomes, delayed or unresolved reads, backgrounding, freeze/resume, screen lock, navigation, and close/reopen.
- [ ] **P2 — uncoached beginner and assistive-technology observation.** Recovery and ambiguity comprehension, focus, keyboard-only use, screen readers, switch and voice control, Braille, zoom, and constrained layouts.
- [ ] **P3 — ordinary browser navigation and encrypted-storage qualification.** Reload, history/BFCache, independent tabs, restart, termination, memory pressure, eviction, and re-unlock in an authorized browser environment.
- [ ] **P4 — public and physical deployment qualification.** Public certificates, hostile traffic, physical storage and power failure, capacity controls, TURN, and physical cross-network journeys.
- [ ] **P5 — independent security, privacy, and accessibility review.**
- [ ] Keep exactly-once publication, durable peer receipt, durable outbox, multi-device membership, synchronization, conflict resolution, account recovery, and remote deletion as separate protocol projects.
