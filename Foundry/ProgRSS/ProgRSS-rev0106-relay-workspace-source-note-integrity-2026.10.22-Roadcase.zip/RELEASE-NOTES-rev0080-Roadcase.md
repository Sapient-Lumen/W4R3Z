# ProgRSS rev0080 — Roadcase

**Bring the exact build. Verify it there. Leave no mystery behind.**

Roadcase packages the exact Chromium Extension, generated Firefox sibling, CLI and Node runtime, synthetic fixtures, private Fieldbook and Debrief workflow, installation instructions, verification, preparation, and cleanup into one deterministic local fieldwork packet.

It adds no reader permission, pairing authority, network fetch, remote research service, telemetry, participant account, operating-system service, or automatic report upload.

## Chain of custody

The earlier file delivered under the rev0080 Roadcase name was 22 bytes and contained no ZIP members. Its published SHA-256 correctly authenticated that empty file. This release reconstructs Roadcase from the last valid rev0079 Dispatch archive and records both facts under `Evidence/`.

## Packet boundary

The separate packet contains:

- exact `release/Extension/` Chromium bytes;
- exact `release/Extension/Firefox/` bytes;
- exact `release/CLI/` runtime;
- synthetic private library and literal-loopback page fixture;
- `START.html`;
- Chromium and Firefox temporary-install instructions;
- self-verification and optional executable-mode restoration;
- offline preparation and preflight;
- explicit cleanup;
- no native or human acceptance claim.

The packet's mutable `work/` directory is excluded from immutable-member verification. All other unexpected files are refused.

## New CLI command

```sh
./progrss node roadcase --output ProgRSS-Roadcase-rev0080.zip
```

The command is offline, deterministic, and new-file-only.
