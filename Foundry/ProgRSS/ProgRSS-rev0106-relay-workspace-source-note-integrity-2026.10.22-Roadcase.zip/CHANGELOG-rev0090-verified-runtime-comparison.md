# rev0090 — verified runtime comparison

Parent: rev0089. Product lineage: rev0080 / 0.80.0. No recovery of rev0081/82.

## Reproduced defects and correction

The old comparator consumed unverified standalone statements and trusted supplied
semantic hashes. Its test could invent Firefox by editing JSON; a text log could
be labeled a native artifact. The pre-patch proof is retained in
`evidence/rev0090/parent-comparison-reproduction.json`.

The comparator now requires evidence ZIPs and the immutable Roadcase. Every input
is reverified. The shipped native reader validates actual artifacts and derives
comparison digests; independently selected legacy branches remain explicitly
without embedded integrity. Missing artifact roles, forged hashes, duplicate
sessions, resealed missing/unreferenced evidence, duplicate metadata, and oversized
archive headers are covered by the 40-test evidence-boundary suite.

Independent verification repeats finalization's semantic checks. Artifact/case
unions retain missing evidence. Triad coverage is distinct from acceptance.
Current metadata uses session v4, result v2, and predicate v2; reprepare old sessions.
The old standalone-comparison API fails with migration guidance instead of silently
retaining its trust assumptions.

## Non-changes and checks

112 CLI and 202 Extension files/modes are unchanged. All 11 CLI test modules and
the complete Extension runner (60 Python tests plus harnesses/managed DOM smoke)
passed. No product, browser permission, pairing, scheduling, policy, network, or
private-state expansion. No current-browser, participant, or real AT run claimed.

The accumulated checklist is preserved in `history/BOOTSTRAPROSE-through-rev0089.md`.
The root `BOOTSTRAPROSE.md` is now a single current authority with reprioritized gates.
