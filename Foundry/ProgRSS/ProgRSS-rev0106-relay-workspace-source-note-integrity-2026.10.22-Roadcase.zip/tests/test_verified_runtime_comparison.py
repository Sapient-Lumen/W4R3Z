#!/usr/bin/env python3
"""Synthetic, offline comparison boundary tests; never browser field evidence."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest import mock
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from tests.test_source_notes_runtime_evidence import prepare_session, complete_result, zip_info
import source_notes_runtime_evidence as runtime
from runtime_native_artifacts import derive_native_artifact, NativeArtifactError
from CLI import relay


class VerifiedRuntimeComparisonTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.verifier = ROOT / "VERIFY-ROADCASE.py"

    def prepare(self, label="a", family="chromium", channel=None):
        directory = self.base / label
        directory.mkdir()
        version = "1.0esr" if channel == "esr" else "1.0"
        roadcase, session = prepare_session(directory, family, version=version, channel=channel)
        result_path = complete_result(session)
        return roadcase, session, result_path

    def finalize(self, roadcase, session, result_path):
        return runtime.finalize_evidence(session_dir=session, roadcase=roadcase,
                                        result_path=result_path, verifier=self.verifier)

    def bundle(self, label="a", family="chromium", channel=None, mutate=None):
        roadcase, session, result_path = self.prepare(label, family, channel)
        if mutate:
            result = runtime.read_json(result_path)
            mutate(session, result)
            result_path.write_bytes(runtime.canonical_json_bytes(result))
        finalized = self.finalize(roadcase, session, result_path)
        bundle = self.base / f"{label}.zip"
        runtime.write_evidence_bundle(session_dir=session, result_path=result_path,
                                     finalized=finalized, output=bundle)
        return roadcase, bundle

    def compare(self, roadcase, bundles, **kw):
        return runtime.compare_evidence_bundles(bundles, roadcase=roadcase, verifier=self.verifier, **kw)

    def rewrite_bundle(self, bundle, mutate):
        with zipfile.ZipFile(bundle) as archive:
            members = {name: archive.read(name) for name in archive.namelist()}
        mutate(members)
        with zipfile.ZipFile(bundle, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for name, data in sorted(members.items()):
                archive.writestr(zip_info(name), data)

    def reseal_metadata(self, members):
        """Untrusted attacker recomputes hashes; verifier must still check meaning."""
        manifest = json.loads(members["EVIDENCE-MANIFEST.json"])
        manifest["files"] = [
            {"path": name, "bytes": len(data), "sha256": runtime.sha256_bytes(data)}
            for name, data in sorted(members.items())
            if name not in {"EVIDENCE-MANIFEST.json", "ATTESTATION.json"}
        ]
        members["EVIDENCE-MANIFEST.json"] = runtime.canonical_json_bytes(manifest)
        statement = json.loads(members["ATTESTATION.json"])
        statement["predicate"]["evidence"]["manifestSha256"] = runtime.sha256_bytes(members["EVIDENCE-MANIFEST.json"])
        statement["predicate"]["evidence"]["files"] = [r for r in manifest["files"] if r["path"].startswith("evidence/")]
        result = json.loads(members["RESULT.json"])
        statement["predicate"]["cases"] = result["cases"]
        members["ATTESTATION.json"] = runtime.canonical_json_bytes(statement)

    def test_real_bundles_are_reverified_and_native_hashes_are_derived(self):
        roadcase, chrome = self.bundle()
        _, firefox = self.bundle("b", "firefox")
        result = self.compare(roadcase, [chrome, firefox])
        self.assertTrue(result["inputsVerifiedAgainstRoadcase"])
        self.assertTrue(result["sameRoadcase"])
        self.assertTrue(result["sameFixture"])
        self.assertTrue(result["nativeArtifactComparison"]["completeRoute"]["semanticProjectionEqual"])
        self.assertTrue(result["nativeArtifactComparison"]["selectedBranch"]["semanticProjectionEqual"])
        branch = result["sessions"][0]["nativeArtifacts"]["selectedBranch"]
        self.assertEqual(branch["nativeIntegrity"], "absent-legacy-excerpt")
        self.assertIsNone(branch["nativeContentDigest"])
        self.assertFalse(result["interpretation"]["comparisonClosesRuntimeRow"])

    def test_raw_serialization_difference_does_not_hide_semantic_equality(self):
        roadcase, chrome = self.bundle()
        def whitespace(session, result):
            path = session / result["nativeArtifacts"]["completeRoute"]["evidencePath"]
            path.write_text(json.dumps(json.loads(path.read_text()), indent=4) + "\n")
            result["nativeArtifacts"]["completeRoute"] = {"evidencePath": "evidence/completeRoute.json"}
        _, firefox = self.bundle("b", "firefox", mutate=whitespace)
        row = self.compare(roadcase, [chrome, firefox])["nativeArtifactComparison"]["completeRoute"]
        self.assertTrue(row["semanticProjectionEqual"])
        self.assertFalse(row["rawSha256Equal"])

    def test_changed_reason_is_a_semantic_difference(self):
        roadcase, chrome = self.bundle()
        def changed(session, result):
            path = session / "evidence/completeRoute.json"
            native = json.loads(path.read_text())
            native["collections"][0]["members"][0]["reason"] = "Changed reason"
            native["integrity"]["digest"] = relay.bundle_content_digest(native)
            path.write_bytes(runtime.canonical_json_bytes(native))
            result["nativeArtifacts"]["completeRoute"] = {"evidencePath": "evidence/completeRoute.json"}
        _, firefox = self.bundle("b", "firefox", mutate=changed)
        self.assertFalse(self.compare(roadcase, [chrome, firefox])["nativeArtifactComparison"]["completeRoute"]["semanticProjectionEqual"])

    def test_forged_semantic_hash_is_refused(self):
        roadcase, session, path = self.prepare()
        result = runtime.read_json(path)
        result["nativeArtifacts"]["completeRoute"]["semanticProjectionSha256"] = "1" * 64
        path.write_bytes(runtime.canonical_json_bytes(result))
        with self.assertRaisesRegex(runtime.EvidenceError, "semanticProjectionSha256 does not match"):
            self.finalize(roadcase, session, path)

    def test_log_masquerading_as_native_artifact_is_refused(self):
        roadcase, session, path = self.prepare()
        result = runtime.read_json(path)
        (session / "evidence/completeRoute.json").write_text("synthetic runtime evidence\n")
        result["nativeArtifacts"]["completeRoute"] = {"evidencePath": "evidence/completeRoute.json"}
        path.write_bytes(runtime.canonical_json_bytes(result))
        with self.assertRaisesRegex(runtime.EvidenceError, "invalid native artifact"):
            self.finalize(roadcase, session, path)

    def test_reason_mutation_without_native_digest_is_refused(self):
        roadcase, session, path = self.prepare()
        native_path = session / "evidence/completeRoute.json"
        native = json.loads(native_path.read_text())
        native["collections"][0]["members"][0]["reason"] = "Unsealed change"
        native_path.write_bytes(runtime.canonical_json_bytes(native))
        with self.assertRaisesRegex(runtime.EvidenceError, "content digest does not match"):
            self.finalize(roadcase, session, path)

    def test_pass_requires_complete_and_branch_native_artifacts(self):
        roadcase, session, path = self.prepare()
        for name in ("completeRoute", "selectedBranch"):
            with self.subTest(name=name):
                result = runtime.read_json(path)
                result["nativeArtifacts"].pop(name)
                temp_result = session / "partial.json"
                temp_result.write_bytes(runtime.canonical_json_bytes(result))
                # Keep the file referenced to isolate the missing artifact-role check.
                result["cases"][0]["evidence"].append("evidence/" + name + ".json")
                temp_result.write_bytes(runtime.canonical_json_bytes(result))
                with self.assertRaisesRegex(runtime.EvidenceError, "requires nativeArtifacts"):
                    self.finalize(roadcase, session, temp_result)

    def test_no_evidence_is_not_comparison_equality(self):
        def not_run(session, result):
            result.clear()
            result.update(runtime.read_json(session / "RESULT-TEMPLATE.json"))
            shutil.rmtree(session / "evidence")
        roadcase, chrome = self.bundle(mutate=not_run)
        _, firefox = self.bundle("b", "firefox", mutate=not_run)
        report = self.compare(roadcase, [chrome, firefox])
        self.assertFalse(report["allCaseResultsPass"])
        for row in report["nativeArtifactComparison"].values():
            self.assertEqual(row["comparisonState"], "missing-evidence")
            self.assertEqual(len(row["missingSessions"]), 2)
            self.assertIsNone(row["semanticProjectionEqual"])
            self.assertIsNone(row["rawSha256Equal"])

    def test_missing_artifact_in_one_session_is_not_dropped(self):
        def partial(session, result):
            row = next(r for r in result["cases"] if r["id"] == "selected-branch-preservation")
            row.update(status="not-run", recordedUtc="", observed="", evidence=[])
            result["status"] = "not-run"
            result["nativeArtifacts"].pop("selectedBranch")
            (session / "evidence/selectedBranch.json").unlink()
        roadcase, chrome = self.bundle()
        _, firefox = self.bundle("b", "firefox", mutate=partial)
        report = self.compare(roadcase, [chrome, firefox])
        branch = report["nativeArtifactComparison"]["selectedBranch"]
        self.assertEqual(len(branch["missingSessions"]), 1)
        self.assertIsNone(branch["semanticProjectionEqual"])

    def test_duplicate_bundle_or_session_is_refused(self):
        roadcase, chrome = self.bundle()
        with self.assertRaisesRegex(runtime.EvidenceError, "duplicate bundle or session"):
            self.compare(roadcase, [chrome, chrome])

    def test_browser_triad_requires_three_independent_channels(self):
        roadcase, chrome = self.bundle()
        _, release = self.bundle("b", "firefox")
        with self.assertRaisesRegex(runtime.EvidenceError, "browser triad requires"):
            self.compare(roadcase, [chrome, release], require_browser_triad=True)
        _, esr = self.bundle("c", "firefox", "esr")
        report = self.compare(roadcase, [chrome, release, esr], require_browser_triad=True)
        self.assertTrue(report["browserTriadPresent"])
        self.assertFalse(report["interpretation"]["currentUnmanagedAcceptance"])

    def test_edited_attestation_inside_bundle_is_refused(self):
        roadcase, chrome = self.bundle()
        def mutate(members):
            statement = json.loads(members["ATTESTATION.json"])
            statement["predicate"]["nativeArtifacts"]["completeRoute"]["semanticProjectionSha256"] = "3" * 64
            members["ATTESTATION.json"] = runtime.canonical_json_bytes(statement)
        self.rewrite_bundle(chrome, mutate)
        with self.assertRaisesRegex(runtime.EvidenceError, "ATTESTATION.json does not match"):
            runtime.verify_evidence_bundle(chrome, roadcase=roadcase, verifier=self.verifier)

    def test_independent_verifier_refuses_unreferenced_evidence_even_when_resealed(self):
        roadcase, bundle = self.bundle()
        def mutate(members):
            members["evidence/private-unreferenced.txt"] = b"not for this evidence bundle"
            self.reseal_metadata(members)
        self.rewrite_bundle(bundle, mutate)
        with self.assertRaisesRegex(runtime.EvidenceError, "unreferenced"):
            runtime.verify_evidence_bundle(bundle, roadcase=roadcase, verifier=self.verifier)

    def test_independent_verifier_refuses_missing_reference_even_when_resealed(self):
        roadcase, bundle = self.bundle()
        def mutate(members):
            result = json.loads(members["RESULT.json"])
            result["cases"][0]["evidence"].append("evidence/missing.txt")
            members["RESULT.json"] = runtime.canonical_json_bytes(result)
            self.reseal_metadata(members)
        self.rewrite_bundle(bundle, mutate)
        with self.assertRaisesRegex(runtime.EvidenceError, "missing=.*missing.txt"):
            runtime.verify_evidence_bundle(bundle, roadcase=roadcase, verifier=self.verifier)

    def test_independent_verifier_rechecks_claimed_native_hash(self):
        roadcase, bundle = self.bundle()
        def mutate(members):
            result = json.loads(members["RESULT.json"])
            result["nativeArtifacts"]["completeRoute"]["semanticProjectionSha256"] = "1" * 64
            members["RESULT.json"] = runtime.canonical_json_bytes(result)
            self.reseal_metadata(members)
        self.rewrite_bundle(bundle, mutate)
        with self.assertRaisesRegex(runtime.EvidenceError, "semanticProjectionSha256 does not match"):
            runtime.verify_evidence_bundle(bundle, roadcase=roadcase, verifier=self.verifier)

    def test_independent_verifier_refuses_duplicate_manifest_rows(self):
        roadcase, bundle = self.bundle()
        def mutate(members):
            manifest = json.loads(members["EVIDENCE-MANIFEST.json"])
            manifest["files"].append(copy.deepcopy(manifest["files"][0]))
            members["EVIDENCE-MANIFEST.json"] = runtime.canonical_json_bytes(manifest)
        self.rewrite_bundle(bundle, mutate)
        with self.assertRaisesRegex(runtime.EvidenceError, "duplicate or reserved"):
            runtime.verify_evidence_bundle(bundle, roadcase=roadcase, verifier=self.verifier)

    def test_limits_are_checked_before_decompression(self):
        roadcase, bundle = self.bundle()
        with mock.patch.object(runtime, "MAX_METADATA_FILE_BYTES", 12):
            with self.assertRaisesRegex(runtime.EvidenceError, "member exceeds"):
                runtime.verify_evidence_bundle(bundle, roadcase=roadcase, verifier=self.verifier)
        with mock.patch.object(runtime, "MAX_BUNDLE_MEMBERS", 2):
            with self.assertRaisesRegex(runtime.EvidenceError, "too many evidence-bundle"):
                runtime.verify_evidence_bundle(bundle, roadcase=roadcase, verifier=self.verifier)

    def test_json_ambiguity_is_refused(self):
        for data in (b'{"a":1,"a":2}', b'{"a":NaN}'):
            with self.subTest(data=data), self.assertRaises(runtime.EvidenceError):
                runtime.decode_json_object(data, "fixture")

    def test_changed_inputs_between_finalization_and_zip_are_refused(self):
        roadcase, session, path = self.prepare()
        finalized = self.finalize(roadcase, session, path)
        (session / "evidence/session.log").write_text("changed after review")
        with self.assertRaisesRegex(runtime.EvidenceError, "changed after finalization"):
            runtime.write_evidence_bundle(session_dir=session, result_path=path,
                                         finalized=finalized, output=self.base / "changed.zip")

    def test_independent_verifier_refuses_extra_metadata_even_when_resealed(self):
        roadcase, bundle = self.bundle()
        def mutate(members):
            members["personal-notes.txt"] = b"not an approved bundle input"
            self.reseal_metadata(members)
        self.rewrite_bundle(bundle, mutate)
        with self.assertRaisesRegex(runtime.EvidenceError, "unexpected top-level"):
            runtime.verify_evidence_bundle(bundle, roadcase=roadcase, verifier=self.verifier)

    def test_wrong_roadcase_is_refused_during_comparison(self):
        roadcase, chrome = self.bundle()
        _, firefox = self.bundle("b", "firefox")
        roadcase.write_bytes(roadcase.read_bytes() + b"altered input")
        with self.assertRaisesRegex(runtime.EvidenceError, "Roadcase bytes do not match"):
            self.compare(roadcase, [chrome, firefox])

    def test_export_times_are_excluded_by_existing_native_digest_only(self):
        roadcase, chrome = self.bundle()
        def new_time(session, result):
            path = session / "evidence/completeRoute.json"
            native = json.loads(path.read_text())
            native["exportedAt"] = native["publication"]["issuedAt"] = "2026-10-21T12:15:00.000Z"
            path.write_bytes(runtime.canonical_json_bytes(native))
            result["nativeArtifacts"]["completeRoute"] = {"evidencePath": "evidence/completeRoute.json"}
        _, firefox = self.bundle("b", "firefox", mutate=new_time)
        row = self.compare(roadcase, [chrome, firefox])["nativeArtifactComparison"]["completeRoute"]
        self.assertTrue(row["semanticProjectionEqual"])
        self.assertFalse(row["rawSha256Equal"])

    def test_not_run_does_not_assert_observed_browser_match(self):
        def not_run(session, result):
            result.clear()
            result.update(runtime.read_json(session / "RESULT-TEMPLATE.json"))
            shutil.rmtree(session / "evidence")
        roadcase, bundle = self.bundle(mutate=not_run)
        with zipfile.ZipFile(bundle) as archive:
            claims = json.loads(archive.read("ATTESTATION.json"))["predicate"]["claims"]
        self.assertTrue(claims["preparedChannelVersionMatched"])
        self.assertFalse(claims["observedChannelVersionMatched"])

    def test_generated_operator_command_uses_verified_bundles(self):
        _, session, _ = self.prepare()
        instructions = (session / "FINALIZE.md").read_text().split("For cross-browser review", 1)[1]
        self.assertIn("CHROMIUM-EVIDENCE.zip", instructions)
        self.assertIn("FIREFOX-ESR-EVIDENCE.zip", instructions)
        self.assertIn("--roadcase FROZEN-ROADCASE.zip --require-browser-triad", instructions)
        self.assertNotIn("ATTESTATION.json", instructions)

    def test_signed_claim_not_inferred_for_legacy_branch(self):
        roadcase, session, path = self.prepare()
        result = self.finalize(roadcase, session, path)
        branch = result.attestation["predicate"]["nativeArtifacts"]["selectedBranch"]
        self.assertEqual(branch["nativeIntegrity"], "absent-legacy-excerpt")
        self.assertIsNone(branch["nativeContentDigest"])
        native = json.loads((session / "evidence/selectedBranch.json").read_text())
        native["unexpected"] = "must not vanish silently"
        with self.assertRaisesRegex(NativeArtifactError, "not a canonical shipped export"):
            derive_native_artifact(runtime.canonical_json_bytes(native), name="selectedBranch", evidence_path="evidence/branch.json")


if __name__ == "__main__":
    unittest.main(verbosity=2)
