#!/usr/bin/env python3
from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / "tools"
sys.path.insert(0, str(TOOLS))

from source_notes_runtime_evidence import (  # noqa: E402
    EvidenceError,
    canonical_json_bytes,
    compare_attestations,
    finalize_evidence,
    read_json,
    sha256_bytes,
    sha256_file,
    verify_evidence_bundle,
    write_evidence_bundle,
)
from browser_channel_evidence import (  # noqa: E402
    CHANNEL_SNAPSHOT_NAME,
    CHROME_SOURCE_NAME,
    FIREFOX_SOURCE_NAME,
    build_snapshot,
)


def zip_info(name: str, mode: int = 0o644) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, (2026, 10, 21, 0, 0, 0))
    info.create_system = 3
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = (stat.S_IFREG | mode) << 16
    info.flag_bits |= 0x800
    return info


def make_mini_roadcase(path: Path) -> None:
    payloads = {
        "Extension/Firefox/background.js": b"globalThis.runtimeFixture = 'firefox';\n",
        "Extension/Firefox/manifest.json": canonical_json_bytes({
            "manifest_version": 3,
            "name": "ProgRSS fixture",
            "version": "0.80.0",
            "browser_specific_settings": {"gecko": {"id": "fixture@progrss.invalid"}},
        }),
        "Extension/background.js": b"globalThis.runtimeFixture = 'chromium';\n",
        "Extension/manifest.json": canonical_json_bytes({
            "manifest_version": 3,
            "name": "ProgRSS fixture",
            "version": "0.80.0",
        }),
        "fixtures/source-notes/native-placement-replay.json": canonical_json_bytes({
            "schema": "progrss.source-notes.native-placement-replay.v1",
            "placements": [{"folderId": "reading", "sourceId": "source", "reason": "Reason"}],
        }),
    }
    files = [
        {
            "path": name,
            "kind": "file",
            "mode": "0o644",
            "bytes": len(data),
            "sha256": sha256_bytes(data),
        }
        for name, data in sorted(payloads.items())
    ]
    manifest = {
        "format": "ProgRSS Roadcase Manifest v1",
        "revision": "rev0106-relay-workspace-source-note-integrity",
        "builtUtc": "2026-10-21T00:00:00Z",
        "productLineage": {"revision": "rev0080", "version": "0.80.0"},
        "files": files,
    }
    payloads["ROADCASE-MANIFEST.json"] = canonical_json_bytes(manifest)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(payloads.items()):
            archive.writestr(zip_info(name), data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def make_channel_evidence(base: Path) -> Path:
    directory = base / "channel-evidence"
    (directory / "channel-sources").mkdir(parents=True)
    chrome = canonical_json_bytes({
        "timestamp": "2026-10-21T11:00:00.000Z",
        "channels": {
            "Stable": {"channel": "Stable", "version": "1.0", "revision": "fixture-revision"},
        },
    })
    firefox = canonical_json_bytes({
        "LATEST_FIREFOX_VERSION": "1.0",
        "FIREFOX_ESR": "1.0esr",
        "LAST_RELEASE_DATE": "2026-10-21",
    })
    snapshot = build_snapshot(chrome, firefox, "2026-10-21T11:30:00Z")
    (directory / CHANNEL_SNAPSHOT_NAME).write_bytes(canonical_json_bytes(snapshot))
    (directory / CHROME_SOURCE_NAME).write_bytes(chrome)
    (directory / FIREFOX_SOURCE_NAME).write_bytes(firefox)
    return directory


def prepare_session(base: Path, family: str = "chromium", *, version: str = "1.0", channel: str | None = None) -> tuple[Path, Path]:
    roadcase = base / "Mini-rev0101-Roadcase.zip"
    make_mini_roadcase(roadcase)
    channel_evidence = make_channel_evidence(base)
    session_dir = base / f"session-{family}"
    channel = channel or ("stable" if family == "chromium" else "release")
    command = [
        sys.executable,
        str(TOOLS / "prepare-source-notes-runtime-session.py"),
        "--roadcase", str(roadcase),
        "--browser-family", family,
        "--channel", channel,
        "--browser-version", version,
        "--channel-evidence-dir", str(channel_evidence),
        "--os-build", "fixture-os",
        "--environment-class", "managed",
        "--profile-state", "fresh",
        "--install-method", "fixture install",
        "--permission-observation", "automated",
        "--output", str(session_dir),
    ]
    completed = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
    if completed.returncode:
        raise AssertionError(completed.stdout)
    return roadcase, session_dir


def complete_result(session_dir: Path, *, status: str = "pass") -> Path:
    result = read_json(session_dir / "RESULT-TEMPLATE.json")
    session = read_json(session_dir / "SESSION.json")
    result["startedUtc"] = "2026-10-21T12:00:00Z"
    result["finishedUtc"] = "2026-10-21T12:20:00Z"
    result["browserObserved"] = {
        "version": session["browser"]["version"],
        "channel": session["browser"]["channel"],
        "osBuild": "fixture-os",
        "profileState": "fresh",
        "installMethod": "fixture install",
        "enterprisePolicy": "none observed",
    }
    result["operatorObservation"] = {
        "mode": "automated",
        "completed": True,
        "statementAccepted": True,
        "note": "Synthetic verifier fixture only.",
    }
    permission_projection = {
        "permissions": ["storage"],
        "optional_permissions": [],
        "host_permissions": [],
        "optional_host_permissions": ["https://*/*"],
    }
    result["permissionObservation"] = {
        "mode": "automated",
        "installPrompt": "not-applicable",
        "before": permission_projection,
        "after": copy.deepcopy(permission_projection),
        "notes": "Synthetic fixture.",
    }
    result["operatorAssertions"] = {
        "exactPreparedPackageUsed": True,
        "freshProfileAtStart": True,
        "sameProfileRestarted": True,
        "unmanagedEnvironment": False,
        "currentChannelAtExecution": True,
        "humanPermissionObservation": False,
    }
    evidence_dir = session_dir / "evidence"
    evidence_dir.mkdir(exist_ok=True)
    evidence = evidence_dir / "session.log"
    evidence.write_text("synthetic runtime evidence\n", encoding="utf-8")
    for row in result["cases"]:
        row["status"] = status
        row["recordedUtc"] = "2026-10-21T12:10:00Z"
        row["observed"] = f"Synthetic {status} observation for {row['id']}."
        row["evidence"] = ["evidence/session.log"]
    result["status"] = status
    from CLI import relay
    state = {
        "sources": [{"id": "one", "title": "Source", "type": "rss", "url": "https://source.example/feed"}],
        "collections": [
            {"id": "root", "title": "Route", "mode": "union", "members": [
                {"kind": "source", "id": "one", "reason": "Root reason."},
                {"kind": "collection", "id": "child"}]},
            {"id": "child", "title": "Child", "mode": "union", "members": [
                {"kind": "source", "id": "one", "reason": "Child reason."}]},
        ],
    }
    complete = relay.make_bundle(state, "root", curator="Fixture curator", exported_at="2026-10-21T12:10:00.000Z")
    branch, _ = relay.select_bundle_section(complete, "child")
    result["nativeArtifacts"] = {}
    for name, document in (("completeRoute", complete), ("selectedBranch", branch)):
        path = evidence_dir / (name + ".json")
        path.write_bytes(canonical_json_bytes(document))
        result["nativeArtifacts"][name] = {
            "evidencePath": "evidence/" + path.name,
            "bytes": path.stat().st_size,
            "sha256": sha256_file(path),
        }
    result["events"] = [{
        "kind": "observation",
        "recordedUtc": "2026-10-21T12:10:00Z",
        "message": "Synthetic event.",
        "evidencePath": "evidence/session.log",
    }]
    path = session_dir / "RESULT-completed.json"
    path.write_bytes(canonical_json_bytes(result))
    return path


class RuntimeEvidenceTests(unittest.TestCase):
    def test_pass_round_trip_and_deterministic_bundle(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            finalized = finalize_evidence(
                session_dir=session_dir,
                roadcase=roadcase,
                result_path=result_path,
                verifier=ROOT / "VERIFY-ROADCASE.py",
            )
            self.assertEqual(finalized.status, "pass")
            claims = finalized.attestation["predicate"]["claims"]
            self.assertTrue(claims["runtimePass"])
            self.assertTrue(claims["exactRoadcaseBound"])
            self.assertFalse(claims["unmanagedBrowserAcceptance"])
            self.assertFalse(claims["currentStableAcceptance"])
            first = base / "first.zip"
            second = base / "second.zip"
            first_meta = write_evidence_bundle(
                session_dir=session_dir,
                result_path=result_path,
                finalized=finalized,
                output=first,
            )
            second_meta = write_evidence_bundle(
                session_dir=session_dir,
                result_path=result_path,
                finalized=finalized,
                output=second,
            )
            self.assertEqual(first.read_bytes(), second.read_bytes())
            self.assertEqual(first_meta["sha256"], second_meta["sha256"])
            verification = verify_evidence_bundle(first, roadcase=roadcase, verifier=ROOT / "VERIFY-ROADCASE.py")
            self.assertTrue(verification["pass"])
            self.assertEqual(verification["status"], "pass")

    def test_status_inflation_is_refused(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            result = read_json(result_path)
            result["cases"][0].update({"status": "not-run", "recordedUtc": "", "observed": "", "evidence": []})
            result_path.write_bytes(canonical_json_bytes(result))
            with self.assertRaisesRegex(EvidenceError, "status must be derived as not-run"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_missing_and_unreferenced_evidence_are_refused(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            extra = session_dir / "evidence" / "unreferenced.txt"
            extra.write_text("must be rejected\n", encoding="utf-8")
            with self.assertRaisesRegex(EvidenceError, "unreferenced"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )
            extra.unlink()
            (session_dir / "evidence" / "session.log").unlink()
            with self.assertRaisesRegex(EvidenceError, "missing"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_package_tampering_is_refused(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            package = session_dir / "package" / "Extension" / "background.js"
            package.write_text("tampered\n", encoding="utf-8")
            with self.assertRaisesRegex(EvidenceError, "byte mismatch"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_bundle_tampering_is_refused(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            finalized = finalize_evidence(
                session_dir=session_dir,
                roadcase=roadcase,
                result_path=result_path,
                verifier=ROOT / "VERIFY-ROADCASE.py",
            )
            bundle = base / "bundle.zip"
            write_evidence_bundle(session_dir=session_dir, result_path=result_path, finalized=finalized, output=bundle)
            tampered = base / "tampered.zip"
            with zipfile.ZipFile(bundle) as source, zipfile.ZipFile(tampered, "w", compression=zipfile.ZIP_DEFLATED) as target:
                for info in source.infolist():
                    data = source.read(info)
                    if info.filename == "evidence/session.log":
                        data += b"tampered"
                    target.writestr(info, data)
            with self.assertRaisesRegex(EvidenceError, "byte mismatch"):
                verify_evidence_bundle(tampered, roadcase=roadcase, verifier=ROOT / "VERIFY-ROADCASE.py")

    def test_passing_result_requires_fresh_profile_assertion(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            result = read_json(result_path)
            result["operatorAssertions"]["freshProfileAtStart"] = False
            result_path.write_bytes(canonical_json_bytes(result))
            with self.assertRaisesRegex(EvidenceError, "freshProfileAtStart"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_preparer_refuses_browser_version_not_in_bound_channel_snapshot(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            with self.assertRaisesRegex(AssertionError, "does not match bound chromium/stable"):
                prepare_session(base, version="9.9")

    def test_passing_result_requires_current_channel_assertion(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            result = read_json(result_path)
            result["operatorAssertions"]["currentChannelAtExecution"] = False
            result_path.write_bytes(canonical_json_bytes(result))
            with self.assertRaisesRegex(EvidenceError, "currentChannelAtExecution"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_passing_result_refuses_stale_channel_snapshot(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            result = read_json(result_path)
            result["startedUtc"] = "2026-10-23T12:00:00Z"
            result["finishedUtc"] = "2026-10-23T12:20:00Z"
            result_path.write_bytes(canonical_json_bytes(result))
            with self.assertRaisesRegex(EvidenceError, "channel snapshot is stale"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_passing_result_refuses_future_channel_snapshot(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            result = read_json(result_path)
            result["startedUtc"] = "2026-10-21T11:00:00Z"
            result["finishedUtc"] = "2026-10-21T11:20:00Z"
            result_path.write_bytes(canonical_json_bytes(result))
            with self.assertRaisesRegex(EvidenceError, "capturedUtc must not be later"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_channel_source_tampering_is_refused(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            source = session_dir / CHROME_SOURCE_NAME
            source.write_bytes(source.read_bytes() + b"\n")
            with self.assertRaisesRegex(EvidenceError, "channel evidence is invalid"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_not_run_case_cannot_carry_observation_or_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            result = read_json(result_path)
            result["cases"][0]["status"] = "not-run"
            result["status"] = "not-run"
            result_path.write_bytes(canonical_json_bytes(result))
            with self.assertRaisesRegex(EvidenceError, "not-run case must have no"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_coordinated_package_manifest_tampering_is_refused(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            package = session_dir / "package" / "Extension" / "background.js"
            package.write_text("coordinated tamper\n", encoding="utf-8")
            package_manifest_path = session_dir / "PACKAGE-MANIFEST.json"
            package_manifest = read_json(package_manifest_path)
            row = next(item for item in package_manifest["files"] if item["path"] == "background.js")
            row["bytes"] = package.stat().st_size
            row["sha256"] = sha256_file(package)
            package_manifest["subtreeSha256"] = sha256_bytes(canonical_json_bytes(sorted(package_manifest["files"], key=lambda item: item["path"]), pretty=False))
            package_manifest_path.write_bytes(canonical_json_bytes(package_manifest))
            session_path = session_dir / "SESSION.json"
            session = read_json(session_path)
            session["package"]["subtreeSha256"] = package_manifest["subtreeSha256"]
            session_path.write_bytes(canonical_json_bytes(session))
            with self.assertRaisesRegex(EvidenceError, "does not match the selected package inside the Roadcase"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_changed_fixed_catalog_is_refused_even_with_updated_session_digest(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            catalog_path = session_dir / "CASE-CATALOG.json"
            catalog = read_json(catalog_path)
            catalog["cases"][0]["description"] = "Changed description."
            catalog_path.write_bytes(canonical_json_bytes(catalog))
            session_path = session_dir / "SESSION.json"
            session = read_json(session_path)
            session["caseCatalogSha256"] = sha256_file(catalog_path)
            session_path.write_bytes(canonical_json_bytes(session))
            with self.assertRaisesRegex(EvidenceError, "fixed rev0106 catalog"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_runtime_timestamps_require_real_calendar_values(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            result = read_json(result_path)
            result["cases"][0]["recordedUtc"] = "2026-99-99T99:99:99Z"
            result_path.write_bytes(canonical_json_bytes(result))
            with self.assertRaisesRegex(EvidenceError, "valid UTC calendar timestamp"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_case_and_event_timestamps_must_fall_inside_runtime_interval(self) -> None:
        mutations = [
            ("case-before", lambda result: result["cases"][0].update(recordedUtc="2026-10-21T11:59:59Z"), "case package-identity"),
            ("case-after", lambda result: result["cases"][0].update(recordedUtc="2026-10-21T12:20:01Z"), "case package-identity"),
            ("event-after", lambda result: result["events"][0].update(recordedUtc="2026-10-21T12:20:01Z"), "event 0"),
        ]
        for label, mutate, expected in mutations:
            with self.subTest(label=label), tempfile.TemporaryDirectory() as name:
                base = Path(name)
                roadcase, session_dir = prepare_session(base)
                result_path = complete_result(session_dir)
                result = read_json(result_path)
                mutate(result)
                result_path.write_bytes(canonical_json_bytes(result))
                with self.assertRaisesRegex(EvidenceError, expected + ".*runtime interval"):
                    finalize_evidence(
                        session_dir=session_dir,
                        roadcase=roadcase,
                        result_path=result_path,
                        verifier=ROOT / "VERIFY-ROADCASE.py",
                    )

    def test_failed_run_still_requires_an_ordered_interval(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir, status="fail")
            result = read_json(result_path)
            result["startedUtc"] = "2026-10-21T12:20:00Z"
            result["finishedUtc"] = "2026-10-21T12:00:00Z"
            result_path.write_bytes(canonical_json_bytes(result))
            with self.assertRaisesRegex(EvidenceError, "finishedUtc must not precede"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_blocked_cases_and_events_require_a_runtime_interval(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result = read_json(session_dir / "RESULT-TEMPLATE.json")
            result["cases"][0].update(
                status="blocked",
                recordedUtc="2026-10-21T12:10:00Z",
                observed="Synthetic blocker.",
                evidence=["evidence/blocker.log"],
            )
            result["status"] = "blocked"
            evidence = session_dir / "evidence"
            evidence.mkdir(exist_ok=True)
            (evidence / "blocker.log").write_text("synthetic blocker\n")
            result_path = session_dir / "blocked-no-interval.json"
            result_path.write_bytes(canonical_json_bytes(result))
            with self.assertRaisesRegex(EvidenceError, "attempted results require startedUtc and finishedUtc"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

            template = read_json(session_dir / "RESULT-TEMPLATE.json")
            template["events"] = [{
                "kind": "observation",
                "recordedUtc": "2026-10-21T12:10:00Z",
                "message": "An event cannot float outside a case attempt.",
            }]
            event_path = session_dir / "event-without-attempt.json"
            event_path.write_bytes(canonical_json_bytes(template))
            with self.assertRaisesRegex(EvidenceError, "events require at least one attempted case"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=event_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_interval_endpoints_must_be_both_empty_or_both_present(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = session_dir / "RESULT-TEMPLATE.json"
            result = read_json(result_path)
            result["startedUtc"] = "2026-10-21T12:00:00Z"
            result_path = session_dir / "RESULT-one-endpoint.json"
            result_path.write_bytes(canonical_json_bytes(result))
            with self.assertRaisesRegex(EvidenceError, "both be empty or both be present"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_unknown_result_claim_fields_are_refused(self) -> None:
        mutations = [
            ("top", lambda result: result.__setitem__("authenticatedBrowser", True), "RESULT.json keys are invalid"),
            ("browser", lambda result: result["browserObserved"].__setitem__("signedDistribution", True), "browserObserved keys are invalid"),
            ("case", lambda result: result["cases"][0].__setitem__("humanVerified", True), "case package-identity keys are invalid"),
            ("event", lambda result: result["events"][0].__setitem__("trustedTimestamp", True), "event 0 keys are invalid"),
        ]
        for label, mutate, expected in mutations:
            with self.subTest(label=label), tempfile.TemporaryDirectory() as name:
                base = Path(name)
                roadcase, session_dir = prepare_session(base)
                result_path = complete_result(session_dir)
                result = read_json(result_path)
                mutate(result)
                result_path.write_bytes(canonical_json_bytes(result))
                with self.assertRaisesRegex(EvidenceError, expected):
                    finalize_evidence(
                        session_dir=session_dir,
                        roadcase=roadcase,
                        result_path=result_path,
                        verifier=ROOT / "VERIFY-ROADCASE.py",
                    )

    def test_unknown_session_configuration_fields_are_refused(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            session_path = session_dir / "SESSION.json"
            session = read_json(session_path)
            session["environment"]["authenticatedOperator"] = True
            session_path.write_bytes(canonical_json_bytes(session))
            with self.assertRaisesRegex(EvidenceError, "SESSION.json environment keys are invalid"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_permission_pass_requires_complete_closed_projections(self) -> None:
        mutations = [
            ("empty", lambda result: result["permissionObservation"].update(before={}, after={}), "requires complete before and after"),
            ("unknown", lambda result: result["permissionObservation"]["before"].__setitem__("authenticated", True), "permissionObservation.before keys are invalid"),
            ("duplicate", lambda result: result["permissionObservation"]["before"]["permissions"].append("storage"), "contains a duplicate value"),
        ]
        for label, mutate, expected in mutations:
            with self.subTest(label=label), tempfile.TemporaryDirectory() as name:
                base = Path(name)
                roadcase, session_dir = prepare_session(base)
                result_path = complete_result(session_dir)
                result = read_json(result_path)
                mutate(result)
                result_path.write_bytes(canonical_json_bytes(result))
                with self.assertRaisesRegex(EvidenceError, expected):
                    finalize_evidence(
                        session_dir=session_dir,
                        roadcase=roadcase,
                        result_path=result_path,
                        verifier=ROOT / "VERIFY-ROADCASE.py",
                    )

    def test_native_artifact_roles_and_fields_are_closed(self) -> None:
        mutations = [
            ("role", lambda result: result["nativeArtifacts"].__setitem__("signedByVendor", {"evidencePath": "evidence/completeRoute.json"}), "unknown roles"),
            ("field", lambda result: result["nativeArtifacts"]["completeRoute"].__setitem__("authenticated", True), "nativeArtifacts.completeRoute keys are invalid"),
            ("empty-digest", lambda result: result["nativeArtifacts"]["completeRoute"].__setitem__("sha256", ""), "nativeArtifacts.completeRoute.sha256 is invalid"),
        ]
        for label, mutate, expected in mutations:
            with self.subTest(label=label), tempfile.TemporaryDirectory() as name:
                base = Path(name)
                roadcase, session_dir = prepare_session(base)
                result_path = complete_result(session_dir)
                result = read_json(result_path)
                mutate(result)
                result_path.write_bytes(canonical_json_bytes(result))
                with self.assertRaisesRegex(EvidenceError, expected):
                    finalize_evidence(
                        session_dir=session_dir,
                        roadcase=roadcase,
                        result_path=result_path,
                        verifier=ROOT / "VERIFY-ROADCASE.py",
                    )


    def test_case_evidence_references_are_unique(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            result = read_json(result_path)
            result["cases"][0]["evidence"].append(result["cases"][0]["evidence"][0])
            result_path.write_bytes(canonical_json_bytes(result))
            with self.assertRaisesRegex(EvidenceError, "case evidence contains duplicate paths"):
                finalize_evidence(
                    session_dir=session_dir,
                    roadcase=roadcase,
                    result_path=result_path,
                    verifier=ROOT / "VERIFY-ROADCASE.py",
                )

    def test_published_result_schema_closes_claim_bearing_objects(self) -> None:
        schema = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-RESULT.schema.json").read_text())
        self.assertEqual(schema["$id"], "urn:progrss:schema:source-notes-runtime-result:v3")
        self.assertFalse(schema["additionalProperties"])
        self.assertEqual(schema["properties"]["schema"]["const"], "progrss.source-notes.runtime-result.v3")
        self.assertEqual(schema["properties"]["revision"]["const"], "rev0106-relay-workspace-source-note-integrity")
        for name in ("browserObserved", "operatorObservation", "permissionObservation", "operatorAssertions"):
            self.assertFalse(schema["properties"][name]["additionalProperties"], name)
        self.assertFalse(schema["properties"]["cases"]["items"]["additionalProperties"])
        self.assertFalse(schema["properties"]["events"]["items"]["additionalProperties"])
        native = schema["properties"]["nativeArtifacts"]
        self.assertFalse(native["additionalProperties"])
        self.assertEqual(set(native["properties"]), {"completeRoute", "selectedBranch"})
        for value in native["properties"].values():
            self.assertFalse(value["additionalProperties"])
        self.assertIn("allOf", schema)
        self.assertEqual(schema["$defs"]["utc"]["pattern"], r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")

    def test_comparison_preserves_review_boundaries(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            base = Path(name)
            roadcase, session_dir = prepare_session(base)
            result_path = complete_result(session_dir)
            finalized = finalize_evidence(
                session_dir=session_dir,
                roadcase=roadcase,
                result_path=result_path,
                verifier=ROOT / "VERIFY-ROADCASE.py",
            )
            first = base / "chromium.json"
            first.write_bytes(finalized.attestation_bytes)
            second_statement = copy.deepcopy(finalized.attestation)
            second_statement["predicate"]["sessionId"] = "firefox-session"
            for subject in second_statement["subject"]:
                if subject["name"].startswith("runtime-package/"):
                    subject["name"] = "runtime-package/firefox"
                    subject["digest"]["sha256"] = "2" * 64
            second_statement["predicate"]["nativeArtifacts"]["completeRoute"]["sha256"] = "3" * 64
            second = base / "firefox.json"
            second.write_bytes(canonical_json_bytes(second_statement))
            with self.assertRaisesRegex(EvidenceError, "standalone attestations"):
                compare_attestations([first, second])



if __name__ == "__main__":
    unittest.main(verbosity=2)
