from __future__ import annotations
import importlib.util, pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location("source_notes_native",ROOT/"CLI"/"source_notes_native.py")
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

class NativeSourceNotes(unittest.TestCase):
    def test_absence_is_preserved(self): self.assertEqual(mod.preserve_reason({"sourceId":"s"},{"sourceId":"s"}),{"sourceId":"s"})
    def test_present_reason_is_preserved(self): self.assertEqual(mod.preserve_reason({"sourceId":"s","reason":"why"},{"sourceId":"s"}),{"sourceId":"s","reason":"why"})
    def test_empty_is_omitted(self): self.assertEqual(mod.preserve_reason({"sourceId":"s","reason":""},{"sourceId":"s","reason":"old"}),{"sourceId":"s"})
    def test_code_points(self): self.assertEqual(mod.normalize_reason("😀"*280),"😀"*280)
    def test_over_limit(self):
        with self.assertRaises(mod.SourceNoteError): mod.normalize_reason("😀"*281)
    def test_unpaired_surrogate(self):
        with self.assertRaises(mod.SourceNoteError): mod.normalize_reason("\ud800")
    def test_relationship_key(self): self.assertNotEqual(mod.placement_key("a","s"),mod.placement_key("b","s"))
if __name__=="__main__": unittest.main()
