# rev0096 — Source Notes Workbench preservation

- Preserve selected direct-placement reasons by source identity when editing an existing collection in Advanced Workbench.
- Keep reasons through title, filter, mode, and subtract-base ordering edits.
- Remove only deliberately unselected placements and their reasons.
- Give newly selected sources no invented reason.
- Refuse conflicting duplicate, absence-versus-reason, invalid, over-limit, and wrong-level prior placement data without mutation.
- Add an 11-case managed shipped-UI-path corpus for Chromium-source and generated-Firefox packages.
- Keep browser permissions, CLI product behavior, and the 18-case runtime catalog count unchanged.
