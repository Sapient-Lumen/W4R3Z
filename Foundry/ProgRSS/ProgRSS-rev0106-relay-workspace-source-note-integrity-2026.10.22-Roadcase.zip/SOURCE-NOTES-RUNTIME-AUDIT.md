# Source Notes runtime-kit audit — rev0087

**Result:** PASS for the kit and managed non-current worktree preflight.

The available run used Debian Chromium 144, a fresh persistent profile, a headed virtual display, Playwright/CDP, and an explicitly declared temporary policy override. All 15 focused scenarios passed. This is useful implementation evidence, but it is neither current Stable nor unmanaged and it is not bound to the final immutable Roadcase.

## What the kit adds

- A real installed-extension Chromium scenario using two live extension views, shipped background requests, real IndexedDB, profile restart, native export/import/update, digest refusal, and screenshots.
- An exact-Roadcase session preparer that verifies the archive and extracts only the selected Chromium or Firefox package while recording package and fixture identity.
- A fail-closed checklist and result vocabulary that keep prepared, blocked, skipped, managed, temporary-install, and human evidence separate.
- An online channel snapshot that prevents Chromium 144 from being mislabeled as the current Stable reference of 156.0.8078.47.

## Still release-blocking

Exact final-Roadcase seal, unmanaged current Chromium, Firefox Release, Firefox ESR, human permission-prompt observation where applicable, unfamiliar-person comprehension, and real assistive-technology sessions remain open.
