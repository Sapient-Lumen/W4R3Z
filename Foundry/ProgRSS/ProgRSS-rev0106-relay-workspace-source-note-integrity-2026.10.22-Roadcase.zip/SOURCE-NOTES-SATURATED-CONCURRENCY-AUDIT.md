# Source Notes saturated-concurrency audit — rev0093

## Reproduced parent behavior

At folder version `10000`, rev0092 accepted both an old save and an old guarded Undo after the reviewed direct placement was removed, recreated, and restored to the same reason. Folder version and current wording matched, so the old relationship could not be distinguished from the replacement.

## Candidate rule

The public side-panel snapshot now includes the persisted vault revision. Save and Undo continue to require the reviewed folder version and reason. When the folder version is exactly `10000`, they additionally require the exact vault revision. A successful save returns its committed revision for the 12-second guarded Undo.

The revision requirement is deliberately ceiling-only. Below `10000`, an unrelated vault write does not invalidate an otherwise matching placement review.

## Scope

Eleven focused cases pass against Chromium source and generated Firefox package bytes. They cover exact save/Undo, missing and wrong revisions, replacement-placement stale save/Undo, unrelated writes at and below the ceiling, public-state exposure, side-panel forwarding, no-mutation refusal, and no network activity. This is not installed-browser evidence.
