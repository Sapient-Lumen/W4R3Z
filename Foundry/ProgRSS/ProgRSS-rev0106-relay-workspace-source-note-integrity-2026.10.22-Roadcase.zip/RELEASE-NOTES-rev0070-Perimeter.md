# ProgRSS rev0070 — Perimeter

**Version:** 0.70.0  
**Date:** 2026-10-20  
**Release maxim:** **Show the edges before saving the center.**

Perimeter advances browser-assisted Capture for sites without reliable feeds. It
separates the stability of one selected section from the completeness of the
currently rendered page.

## Delivered

The Extension can now show **What this browser view may leave outside** before a
person chooses a watched section. At most six bounded notices identify:

- apparent pagination or continuation;
- partial or virtualized rendering;
- a visible overlay or consent layer;
- a region still reporting that it is loading;
- embedded frame contents outside top-frame Capture;
- open shadow roots inspected within explicit bounds.

These notices do not alter the independent **More likely to stay put / Needs
watching / Fragile** section assessment.

New observations use:

```text
progrss.browser-capture-candidates.v3
progrss.browser-capture.v3
progrss.capture-page-context.v1
perimeter-v1
```

The Node strictly validates notice kinds, tones, bounded integer signals, and
their exact relationships. It retains page-boundary kinds and bounded counts in
the durable acquisition receipt. Version 2 and legacy version 1 artifacts remain
readable during a rolling local upgrade without synthetic evidence.

## Authority unchanged

Perimeter remains:

```text
one exact reviewed active page
top-frame only
fixed packaged isolated-world extraction
bounded JSON-safe text-and-link evidence
zero Node-side watched-site requests
no schedule
summary-only read-only Node pairing
```

It does not transfer browser cookies, credentials, storage, form values, raw
HTML, DOM nodes, screenshots, page scripts, or browser capabilities.

## Fixture garden

The delivered real-browser specimens cover:

```text
semantic repeated entries plus hidden duplicate layouts
pagination and next-page evidence
virtualized or partially declared lists
visible overlays
busy/loading state
embedded frames plus open shadow roots
right-to-left page direction
```

The fixture garden is regression evidence, not a substitute for native signed-in
pages, unfamiliar people, or assistive-technology fieldwork.

## Next boundary

Run native Chromium, Firefox, and Firefox ESR fieldwork with real public,
JavaScript-rendered, signed-in, paginated, and virtualized pages. Build direct
point-to-region selection only if that fieldwork demonstrates that the current
bounded candidates cannot express what people need. Any point-to-region design
must provide non-drag operation and preserve the same authority and evidence
boundaries.
