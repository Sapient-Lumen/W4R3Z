# ProgRSS rev0071 — Threshold

**Version:** 0.71.0  
**Date:** 2026-10-20  
**Release maxim:** **A visible boundary needs a visible decision.**

Threshold advances browser-assisted Capture for sites without reliable feeds.
Perimeter made visible when one rendered browser view might omit continuation,
virtualized records, obscured material, still-loading content, or frame content.
Threshold adds the missing consequence: such a view cannot become the page-watch
baseline until the person explicitly decides to use that limited rendering.

## Delivered

When the current page context includes any of these limiting boundaries:

```text
continuation
partial-render
overlay
loading
frames
```

the final Capture action remains disabled. The person can:

```text
Capture the page again first
```

or separately acknowledge:

```text
Use this rendered view as the baseline
```

Open-shadow evidence remains informative because bounded open roots were
inspected; it does not by itself require the limited-view acknowledgement.

A changed watched-section recipe remains a different consequence and keeps its
own **Use this new watched section** acknowledgement. When both decisions are
needed, neither substitutes for the other.

New submissions use:

```text
progrss.browser-capture.v4
progrss.capture-coverage-review.v1
```

The acknowledgement must exactly match every visible limiting notice in the
reviewed `progrss.capture-page-context.v1` object. The Node refuses missing,
partial, reordered, duplicated, contradictory, or invented acknowledgement.
Recapturing clears the earlier decision and requires review of the newly
rendered evidence.

Durable receipts retain the decision and acknowledged boundary kinds. Version
3, version 2, and legacy version 1 Capture artifacts remain readable during a
rolling local upgrade without fabricating consent that an older Extension never
requested.

## Authority unchanged

Threshold remains:

```text
one exact reviewed active page
top-frame only
fixed packaged isolated-world extraction
bounded JSON-safe text-and-link evidence
zero Node-side watched-site requests
no recurring schedule
summary-only read-only Node pairing
```

It does not follow pagination, scroll virtual lists, click or dismiss controls,
wait for loading, read frame contents, or transfer browser cookies,
credentials, storage, form values, raw HTML, DOM nodes, screenshots, page
scripts, or browser capabilities.

A browser-assisted Capture receipt still cannot authorize Pulse scheduling.
Pulse requires a successful Node-side Witness check that independently proves
the Node can reproduce the source.

## Next boundary

Run the exact Threshold decision with unfamiliar people and native current
Chromium, Firefox, and Firefox ESR. Observe whether people understand that:

- recapturing performs another local rendered-page observation;
- using the current rendering accepts a limited baseline rather than completing
  the page;
- changing the watched section is a separate decision;
- the Node receives no browser login and makes no watched-site request;
- no recurring schedule is created.

Expand the fixture garden and build direct point-to-region selection only when
fieldwork demonstrates that the current bounded candidates cannot express the
region people actually need.
