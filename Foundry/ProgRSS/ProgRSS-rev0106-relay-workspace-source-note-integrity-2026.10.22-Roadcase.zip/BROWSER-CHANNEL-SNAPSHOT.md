# Browser channel snapshot — 2026-10-21

This is a planning and evidence-binding input, not proof that any listed browser was exercised. The exact source payload bytes are retained under `runtime-channel-reference/` and validated by `tools/browser_channel_evidence.py`.

| Runtime gate | Bound official reference | Available here | Gate status |
|---|---:|---:|---|
| Chromium Stable | `156.0.8078.47` | `Chromium 144.0.7559.96` | **BLOCKED** for current managed acquisition; **NOT RUN** unmanaged |
| Firefox Release | `158.0.1` | none | **NOT RUN** |
| Firefox ESR | `153.5.1esr` | none | **NOT RUN** |

## New rev0089 boundary

A prepared session now contains the exact Chrome-for-Testing and Mozilla product-details JSON payloads, a derived `CHANNEL-SNAPSHOT.json`, their byte digests, the derived expected browser version, and a 24-hour maximum age at runtime start. A passing result must also assert `currentChannelAtExecution=true`. The final bundle carries and independently revalidates all three files.

This closes accidental/operator-entered version drift. It does **not** authenticate the network fetch, source signature, operator, human presence, or unmanaged environment. A fabricated source capture can therefore remain internally consistent; external trust still requires a reviewed acquisition path or signed provenance.

## Install-path boundary

Chromium’s documented local path remains Developer Mode plus **Load unpacked**. Firefox temporary installation remains useful for runtime behavior but ends on restart and does not fully reproduce a signed install or its installation-time permission request.
