# Source Notes checklist — rev0106

- [x] Direct-placement reason contract shared by Python and JavaScript.
- [x] Native artifacts, branch selection, OPML omission, Lineage, Workbench, Exchange, publication, repair, conflicts, and Undo retained.
- [x] Private transfer, Workbench private backup, and Node private-library paths fail closed.
- [x] Relay share, publish, import, review, explicit publication check, update, and derived workspace output fail closed.
- [ ] Exact package in unmanaged then-current Chromium Stable.
- [ ] Exact generated sibling in Firefox Release.
- [ ] Exact generated sibling in Firefox ESR.
- [ ] Unfamiliar-person, separate privacy, and real assistive-technology fieldwork.
