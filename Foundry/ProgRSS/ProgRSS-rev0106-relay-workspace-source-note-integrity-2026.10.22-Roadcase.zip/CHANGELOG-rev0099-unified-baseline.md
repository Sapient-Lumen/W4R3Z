# rev0099 — unified baseline and delivered integrity fixes

Verified the repeated rev0080 upload is identical and all its paths already exist in rev0098.
Merged the separately delivered rev0091 runtime-record-integrity branch through the common
rev0090 comparison ancestor. Retained all later product bytes and behavioral case descriptions.
Recovered calendar/interval validation, closed metadata, complete passing permission projections,
known native roles, unique evidence references, schema v5/v3, and their regression tests.
Restored the whole-product commitments in the active authority and made artifact identities
unambiguous. No product feature, permission, storage, or network authority changes.
