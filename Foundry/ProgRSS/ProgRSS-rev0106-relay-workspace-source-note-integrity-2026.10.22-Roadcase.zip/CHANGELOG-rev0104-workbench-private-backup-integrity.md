# rev0104 — Advanced Workbench private-backup Source Note integrity

- Reproduced a shipped-path validation bypass: Advanced Workbench exported a private backup containing an over-limit direct-placement Source Note.
- Added one shared `auditSourceNotes` contract in the Extension core and delegated the everyday background transfer audit to it.
- Applied the same fail-closed audit to the Workbench’s current in-memory Private backup before download.
- Preserved valid route-specific, multiline, Unicode, and absent reasons exactly.
- Refused nine malformed local Source Note forms before download, without a vault write or network request.
- Kept the browser runtime catalog at 18 cases by extending `two-folder-independence`.
- Added no permission, persistent store, network authority, account, schedule, notification, ranking, profile, reaction, comment, or messaging feature.
