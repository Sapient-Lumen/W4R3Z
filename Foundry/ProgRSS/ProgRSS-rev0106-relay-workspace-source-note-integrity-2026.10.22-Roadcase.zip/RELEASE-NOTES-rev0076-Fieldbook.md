# ProgRSS rev0076 — Fieldbook

**Release maxim:** Test the wording, not the person.

Fieldbook turns the project’s repeatedly deferred unfamiliar-person acceptance work into a private, local, reproducible facilitator workflow without claiming that the study has already happened.

## Delivered

- One Fieldbook download inside the existing advanced Trace/Bearing review.
- One offline CLI command: `progrss node fieldbook`.
- `progrss.fieldwork-kit.v1` and `progrss.fieldwork-report.v1`.
- Twelve Trace/Bearing/Anchor comprehension tasks.
- Four observational outcomes rather than a synthetic usability score.
- Per-task notes bounded to 600 characters.
- Review-before-export and explicit privacy acknowledgement.
- Local JSON and Markdown report downloads.
- Dark, light, forced-colors, reduced-motion, print, keyboard, and narrow-screen treatment.
- No telemetry, participant identity field, automatic persistence, source address, selector, snapshots, capabilities, or portable-library write.

## Unchanged

- Bearing and Trace remain read-only.
- Anchor remains the only held-baseline replacement operation.
- Fresh Capture remains a separate deliberate browser action.
- Extension pairing remains summary-only and read-only.
- No automatic repair, Pinpoint overlay, remote Node, WebRTC dependency, or new browser permission.

## Acceptance boundary

The automated browser completes all twelve tasks only to verify the generated interface. That is not represented as human comprehension. Native installed-browser, unfamiliar-person, and real assistive-technology sessions remain not run in this environment.
