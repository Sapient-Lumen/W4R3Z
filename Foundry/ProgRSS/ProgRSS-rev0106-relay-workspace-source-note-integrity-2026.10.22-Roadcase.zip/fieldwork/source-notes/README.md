# Source Notes native fieldwork harness

This is a dependency-free, local-only observation aid. It does not substitute for the actual Chromium extension, generated Firefox sibling, Firefox ESR run, assistive-technology setup, or unfamiliar participants. A successful smoke test of this page is not fieldwork evidence.

## Run

Open `index.html` directly in the browser under test. Record the exact browser and operating-system build in the page. Do not put participant names, email addresses, feed credentials, private list contents, or other identifying data into the form.

The page has a restrictive Content Security Policy, no network API calls, no local storage, no telemetry, and no service worker. State exists only in the open page. **Export evidence JSON** is an explicit local file action.

## Session order

1. Record the participant’s first explanation of the level to which each reason belongs.
2. Let the participant edit a local reason and ask whether that contacted or published to anyone.
3. Ask who wrote the reason and whether it is a ProgRSS safety or accuracy guarantee.
4. Ask what remains when one branch is shared; then show branch preview and OPML omission evidence.
5. Present a divergent later-copy conflict. Record their explanation before opening it, then observe **Keep mine**, **Use curator’s**, and leaving it unresolved.
6. Export evidence, privacy-review sender and recipient evidence separately, and compare wrong turns across independent sessions.

Do not explain the intended model until the first response has been recorded. Do not combine sender and recipient privacy review into a single “looks fine” judgment.

## Accessibility coverage

Schedule distinct sessions for screen reader, refreshable Braille, voice control, switch control, high zoom, forced colors, reduced motion, fatigue, and interruption. Record the product and exact version of assistive technology in observer notes. At high zoom, evaluate reflow rather than reducing browser zoom to make the page fit.

The harness uses native controls, visible labels, status announcements, a native dialog, visible focus, no essential animation, responsive reflow, and forced-color-safe borders. These are implementation choices to test, not proof of accessibility.

## Correction rule

A candidate correction must name the recurring wrong turn and the evidence that repeated it. Prefer the smallest wording, focus, ordering, or disclosure change that addresses that wrong turn. Re-run the affected task after any correction. Do not use fieldwork as a pretext to add comments, reactions, profiles, notifications, private labels, network discovery, or new permissions.
