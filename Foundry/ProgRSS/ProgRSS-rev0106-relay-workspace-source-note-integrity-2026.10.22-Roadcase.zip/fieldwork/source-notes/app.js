"use strict";

const byId = (id) => document.getElementById(id);
const session = {
  startedAt: null,
  pauses: [],
  activePause: null,
  conflictDecision: null,
  branchPreviewedAt: null,
  opmlShownAt: null,
};

function now() {
  return new Date().toISOString();
}

function codePointLength(value) {
  return Array.from(value).length;
}

function setSessionStatus(message) {
  byId("session-status").textContent = message;
}

function startSession() {
  if (session.startedAt === null) session.startedAt = now();
  byId("start-session").disabled = true;
  byId("pause-session").disabled = false;
  setSessionStatus(`Session started at ${session.startedAt}. Evidence remains in memory only.`);
}

function pauseSession() {
  if (session.activePause !== null) return;
  session.activePause = { startedAt: now(), endedAt: null };
  byId("pause-session").disabled = true;
  byId("resume-session").disabled = false;
  setSessionStatus(`Paused at ${session.activePause.startedAt}.`);
}

function resumeSession() {
  if (session.activePause === null) return;
  session.activePause.endedAt = now();
  session.pauses.push(session.activePause);
  session.activePause = null;
  byId("pause-session").disabled = false;
  byId("resume-session").disabled = true;
  setSessionStatus(`Resumed at ${now()}.`);
}

function updateCount() {
  const field = byId("editable-note");
  const length = codePointLength(field.value);
  byId("note-count").value = String(length);
  byId("note-count").textContent = String(length);
  field.setCustomValidity(length > 280 ? "Use no more than 280 Unicode characters." : "");
}

const branches = {
  transit: {
    folder: "Local transit",
    source: "City Desk feed",
    note: "Strong day-to-day service alerts for this route.",
  },
  accountability: {
    folder: "City accountability",
    source: "City Desk feed",
    note: "Useful records reporting for this beat.",
  },
};

function selectedBranches() {
  const selected = [];
  if (byId("branch-transit").checked) selected.push(branches.transit);
  if (byId("branch-accountability").checked) selected.push(branches.accountability);
  return selected;
}

function previewBranch() {
  const preview = byId("branch-preview");
  preview.replaceChildren();
  const selected = selectedBranches();
  if (selected.length === 0) {
    const message = document.createElement("p");
    message.textContent = "No branch selected; no Source Notes remain.";
    preview.append(message);
  } else {
    for (const item of selected) {
      const article = document.createElement("article");
      const heading = document.createElement("h3");
      heading.textContent = item.folder;
      const source = document.createElement("p");
      source.className = "source-title";
      source.textContent = item.source;
      const note = document.createElement("p");
      note.textContent = `Reason from curator: ${item.note}`;
      article.append(heading, source, note);
      preview.append(article);
    }
  }
  session.branchPreviewedAt = now();
}

function showOpmlReport() {
  const selected = selectedBranches();
  const report = {
    format: "OPML",
    sourceNotesIncluded: false,
    omittedSourceNoteCount: selected.length,
    omittedPlacements: selected.map((item) => `${item.folder} → ${item.source}`),
  };
  byId("opml-report").textContent = JSON.stringify(report, null, 2);
  session.opmlShownAt = now();
}

function openConflict() {
  const dialog = byId("conflict-dialog");
  if (typeof dialog.showModal === "function") dialog.showModal();
  else dialog.setAttribute("open", "");
}

function closeConflict(event) {
  const choice = event.target.returnValue;
  const output = byId("conflict-result");
  if (choice === "keep_mine") {
    session.conflictDecision = { choice, at: now() };
    output.textContent = "Decision recorded: Keep mine. The recipient’s local reason remains.";
  } else if (choice === "use_curator") {
    session.conflictDecision = { choice, at: now() };
    output.textContent = "Decision recorded: Use curator’s. The curator’s later reason replaces the local reason.";
  } else {
    session.conflictDecision = null;
    output.textContent = "Unresolved. No value has been selected.";
  }
  byId("open-conflict").focus();
}

function radioValue(name) {
  return document.querySelector(`input[name="${name}"]:checked`)?.value ?? null;
}

function checkboxValues(name) {
  return Array.from(document.querySelectorAll(`input[name="${name}"]:checked`), (item) => item.value);
}

function fieldValue(id) {
  return byId(id).value;
}

function evidence() {
  return {
    format: "ProgRSS Source Notes fieldwork evidence v1",
    exportedAt: now(),
    localOnlyHarness: true,
    session: {
      participantCode: fieldValue("participant-code"),
      participantRole: fieldValue("participant-role"),
      browserBuild: fieldValue("browser-build"),
      osBuild: fieldValue("os-build"),
      accessSetup: fieldValue("access-setup"),
      privacyPerspective: fieldValue("privacy-perspective"),
      startedAt: session.startedAt,
      pauses: session.activePause === null ? session.pauses : [...session.pauses, session.activePause],
    },
    tasks: {
      relationshipLevel: {
        firstInterpretation: radioValue("level-answer"),
        participantWords: fieldValue("level-words"),
        wrongTurn: fieldValue("level-wrong-turn"),
      },
      editExpectation: {
        selectedExpectations: checkboxValues("edit-expectation"),
        participantWords: fieldValue("communication-words"),
        localReasonAtExport: fieldValue("editable-note"),
      },
      authorshipAndSafety: {
        author: radioValue("author-answer"),
        safetyMeaning: radioValue("safety-answer"),
        participantWords: fieldValue("authorship-words"),
      },
      branchAndOpml: {
        selectedFolders: selectedBranches().map((item) => item.folder),
        expectedBeforePreview: fieldValue("branch-expectation"),
        mismatchAfterPreview: fieldValue("branch-mismatch"),
        opmlExplanation: fieldValue("opml-words"),
        branchPreviewedAt: session.branchPreviewedAt,
        opmlShownAt: session.opmlShownAt,
      },
      conflict: {
        explanationBeforeOpening: fieldValue("conflict-before"),
        decision: session.conflictDecision,
        observation: fieldValue("conflict-observation"),
      },
    },
    observer: {
      notes: fieldValue("observer-notes"),
      outcome: radioValue("session-outcome"),
    },
  };
}

function safeFilenamePart(value) {
  const clean = value.trim().replace(/[^A-Za-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "");
  return clean || "anonymous";
}

function exportEvidence() {
  const data = evidence();
  const blob = new Blob([`${JSON.stringify(data, null, 2)}\n`], { type: "application/json" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `source-notes-fieldwork-${safeFilenamePart(data.session.participantCode)}.json`;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(link.href);
  byId("export-status").textContent = "Evidence exported to a local JSON file. Nothing was sent.";
}

function resetSession() {
  const accepted = window.confirm("Clear all in-memory answers on this page?");
  if (!accepted) return;
  window.location.reload();
}

byId("start-session").addEventListener("click", startSession);
byId("pause-session").addEventListener("click", pauseSession);
byId("resume-session").addEventListener("click", resumeSession);
byId("editable-note").addEventListener("input", updateCount);
byId("preview-branch").addEventListener("click", previewBranch);
byId("show-opml-report").addEventListener("click", showOpmlReport);
byId("open-conflict").addEventListener("click", openConflict);
byId("conflict-dialog").addEventListener("close", closeConflict);
byId("export-evidence").addEventListener("click", exportEvidence);
byId("reset-session").addEventListener("click", resetSession);
updateCount();
previewBranch();
