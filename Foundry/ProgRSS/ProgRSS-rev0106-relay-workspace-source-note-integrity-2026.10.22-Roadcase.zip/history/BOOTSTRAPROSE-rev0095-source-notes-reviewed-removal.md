# `/run` authority — rev0095 Source Notes reviewed folder removal

This is the sole current checklist. Earlier authorities are historical under `history/` and do not establish current-candidate behavior.

## Candidate and limits

Candidate: **rev0095-source-notes-reviewed-removal**. Product lineage remains **rev0080 / 0.80.0**. Immediate parent: `ProgRSS-rev0094-source-notes-saturated-add-undo-2026.10.21-Roadcase.zip`; SHA-256 `175317ab2003577ac91c90f6befe7f34aad58b85f8cefd3567f95b123a350782`. Rev0081 and rev0082 remain unavailable and unrecovered.

**Release gate: NOT SATISFIED.** A reproduced stale destructive folder-removal action is corrected in native/managed scope, but no unmanaged then-current Chromium, Firefox Release, Firefox ESR, unfamiliar-person, real assistive-technology, or human permission-prompt session has passed these exact Extension bytes. Do not reuse older installed-browser records as acceptance for changed product bytes. No enterprise policy was changed.

## Completed: review-bound destructive folder removal

- [x] Reproduced rev0094 accepting a stale `remove-source-from-folder` action after another view changed the placement reason below the version ceiling.
- [x] Confirmed the stale action deleted the newer wording.
- [x] Reproduced the same stale action at folder version `10000` after the reviewed placement had been removed and restored with identical wording.
- [x] Confirmed rev0094 deleted the replacement relationship because the handler ignored the initiating view’s review state.
- [x] Required every removal request to carry the displayed folder version and explicit displayed reason, including explicit absence.
- [x] Required the exact persisted vault revision when the reviewed folder version is saturated at `10000`.
- [x] Refused missing review fields, version drift, reason drift, missing or ambiguous direct placement, replacement placement, and conservative ceiling revision drift without mutation.
- [x] Preserved below-ceiling behavior: unrelated writes to another folder remain nonblocking when the reviewed folder version and reason still match.
- [x] Kept whole-placement removal metadata, original position, guarded Undo, native artifact integrity, and independent nested-folder reasons intact.
- [x] Passed 14 reviewed-removal cases against Chromium source and generated Firefox bytes; shared background and side-panel files remain byte-identical.
- [x] Kept required, optional, host, and optional-host permission projections unchanged.

The persisted revision is a conservative local generation guard only at the saturated folder-version boundary. It is not a public identity, account, remote token, authorship credential, or authenticity claim.

## P0.1 — exact corrected candidate in actual browsers

Freeze and use this exact Roadcase. Capture fresh official channel payloads on each target host. Run all 18 fixed cases independently in unmanaged then-current Chromium Stable, Firefox Release, and Firefox ESR.

The existing cases now require these concrete destructive-action steps:

- `clear-and-guarded-undo`: remove one currently reviewed direct placement and prove Undo restores its complete reason-bearing relationship and original position; add one placement and prove immediate Undo removes only that unchanged placement.
- `two-view-stale-undo-refused`: below the ceiling, review a reason-bearing placement in one view, change its reason in another, and prove the first view’s stale **Remove from folder** is refused while the newer wording remains. At folder version `10000`, remove and restore or recreate the placement with matching wording and prove the old removal is still refused. Retain the separate saturated Source Note Undo and folder-add Undo replacement tests.

Retain same-source repair preservation/refusal, repair Undo, two-folder independence, stale save, restart persistence, complete-route disclosure, selected-branch preservation, OPML omission, native integrity mutation refusal, and both later-copy decisions. Preserve first failures, interruptions, retries, recovery, actual installation and permission observations, two live views, same-profile restart, and actual native JSON artifacts.

Firefox temporary loading must not be reported as signed-install permission-prompt or restart evidence. Finalize and independently verify each evidence ZIP against the same immutable Roadcase; comparison reports differences but does not approve release automatically.

Do not create another evidence layer merely because target-host access is unavailable. Make another implementation change only for a reproduced failure.

## P0.2 — unfamiliar people and real assistive technologies

After the browser triad: test unfamiliar curator and recipient comprehension of relationship level, one-source/two-folder differences, authorship, local-only consequences, absence of a safety claim, branch expectations, OPML loss, divergent later-copy decisions, add/remove whole-placement Undo, repair refusal, and stale-removal refusal. Review sender and recipient privacy evidence separately.

Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions. Apply only the smallest correction supported by recurring independent wrong turns. Managed DOM smoke, browser API doubles, digests, and unsigned records are not human or AT evidence.

## P1 — delayed re-finding and organization

Test one-week delayed route re-finding before private labels or saved views. Keep folders human-curated and shareable, Source Notes optional, and **Unfiled** legitimate. Do not use note wording for engagement ranking or opaque recommendation, and do not expand Source Notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

Remote mode remains explicit and separate from loopback: TLS, persistent identity, bounded hosts/requests/artifacts/rates, expiring invitations, durable revocation evidence, and separate public publication/private API routes. Begin with reviewed immutable-artifact retrieval. No default public bind, silent LAN discovery, or UPnP.

## Lab — bounded WebRTC courier

Transfer exactly one reviewed immutable artifact; preserve Source Notes; show signaling/STUN/TURN; refuse replay, identity/digest mismatch, timeout, and partial completion; destroy the session. Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Reproduction and packaging

Focused: `python3 tools/verify-rev0095-source-notes.py`.
Full regressions: `python3 tools/run-rev0095-regressions.py`.
Prebuild: `python3 tools/prebuild-validate-rev0095.py`.
Build: `python3 tools/build-reconstruction-roadcase.py`.

Prepared sessions, managed browser smoke, native tests, and synthetic fixtures do not close target-host runtime or human fieldwork rows.
