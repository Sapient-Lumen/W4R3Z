# Source Notes runtime and release matrix — rev0098

Candidate: `rev0098-source-notes-publication-disclosure`

Release gate closed: **FALSE**

## Status summary

- **NOT-RUN**: 5
- **PASS**: 11

## Rows

### review-bound-destructive-folder-removal — PASS

**Category:** implementation

14 reviewed-removal cases per Chromium-source and generated-Firefox variant; stale initial removal cannot delete newer wording below the ceiling or a replacement placement at folder version 10000.

**Evidence:**
- `evidence/rev0095/parent-stale-folder-remove-reproduction.log`
- `evidence/rev0095/reviewed-removal-chromium.log`
- `evidence/rev0095/reviewed-removal-firefox.log`
- `SOURCE-NOTES-REVIEWED-REMOVAL-AUDIT.json`

### saturated-folder-add-undo — PASS

**Category:** implementation

28 combined folder-Undo cases per Chromium-source and generated-Firefox variant; stale add-Undo at folder version 10000 cannot delete a removed-and-recreated placement or its replacement reason.

**Evidence:**
- `evidence/rev0096/source_notes_folder_undo_harness.log`
- `evidence/rev0096/source_notes_folder_undo_harness-firefox.log`
- `SOURCE-NOTES-SATURATED-ADD-UNDO-AUDIT.json`

### saturated-source-note-concurrency — PASS

**Category:** implementation

11 Source Note save/Undo cases per package variant; stale save and reason Undo against a replacement placement are refused at folder version 10000 without mutation.

**Evidence:**
- `evidence/rev0096/source_notes_saturated_concurrency_harness.log`
- `evidence/rev0096/source_notes_saturated_concurrency_harness-firefox.log`
- `SOURCE-NOTES-SATURATED-CONCURRENCY-AUDIT.json`

### same-source-repair-reason-collision — PASS

**Category:** implementation

14 focused production-function cases per package variant plus five CLI tests; divergent reasons refuse before mutation.

**Evidence:**
- `evidence/rev0096/source_notes_source_repair_harness.log`
- `evidence/rev0096/source_notes_source_repair_harness-firefox.log`
- `evidence/rev0096/cli-test_source_repair_notes.log`

### whole-placement-removal-undo — PASS

**Category:** implementation

The 28-case combined folder-Undo corpus restores complete reason-bearing placements, order, and independent inherited membership in both package variants.

**Evidence:**
- `evidence/rev0096/source_notes_folder_undo_harness.log`
- `evidence/rev0096/source_notes_folder_undo_harness-firefox.log`

### workbench-collection-edit-preservation — PASS

**Category:** implementation

11 managed shipped-Workbench UI-path cases per Chromium-source and generated-Firefox variant preserve selected placement reasons by source identity and refuse conflicting or invalid prior placement data without mutation.

**Evidence:**
- `evidence/rev0096/workbench-preservation-chromium.log`
- `evidence/rev0096/workbench-preservation-firefox.log`
- `SOURCE-NOTES-WORKBENCH-PRESERVATION-AUDIT.json`

### lineage-edition-preservation-and-conflicts — PASS

**Category:** implementation

11 native Lineage cases and 4 shipped Workbench UI-path cases per Chromium-source and generated-Firefox package preserve first-edition reasons, merge one-sided or identical changes, and require explicit placement-scoped decisions for divergence without an automatic winner.

**Evidence:**
- `evidence/rev0097/lineage-native-chromium.log`
- `evidence/rev0097/lineage-native-firefox.log`
- `evidence/rev0097/lineage-ui-chromium.log`
- `evidence/rev0097/lineage-ui-firefox.log`
- `SOURCE-NOTES-LINEAGE-PRESERVATION-AUDIT.json`

### native-and-managed-regressions — PASS

**Category:** regression

192 CLI tests across 13 modules, 60 Extension static tests, 19 explicit managed Node harness invocations, four shipped Workbench UI-path variants, the complete Extension runner, and managed rendering/interaction smoke passed.

**Evidence:**
- `evidence/rev0098/regression-status.json`
- `evidence/rev0098/extension-static.log`
- `evidence/rev0098/extension-complete.log`
- `evidence/rev0098/browser_smoke.log`

### browser-rendering-smoke — PASS

**Category:** managed-ui

Managed side-panel/workbench rendering and interaction smoke passed; this is not installed-browser acceptance.

**Evidence:**
- `evidence/rev0097/browser_smoke.log`

### browser-permission-boundary — PASS

**Category:** continuity

Required, optional, host, and optional-host permission projections remain unchanged.

**Evidence:**
- `BROWSER-PERMISSION-AUDIT.json`
- `SOURCE-NOTES-REVIEWED-REMOVAL-AUDIT.json`

### exact-final-roadcase-runtime-this-turn — NOT-RUN

**Category:** runtime

No installed exact-final browser execution is claimed by source-side or managed rendering tests.

### unmanaged-current-chromium — NOT-RUN

**Category:** release-gate

Actual target-host execution required.

### firefox-release — NOT-RUN

**Category:** release-gate

Actual target-host execution required.

### firefox-esr — NOT-RUN

**Category:** release-gate

Actual target-host execution required.

### unfamiliar-person-and-real-at — NOT-RUN

**Category:** release-gate

Separate participant, privacy, and assistive-technology evidence required.

### ready-to-host-publication-reason-disclosure — PASS

**Category:** implementation

CLI and Chromium-source/generated-Firefox publication generators preserve native placement reasons and render them route-by-route with curator/non-safety disclosure, escaped multiline direction-aware text, absent-value omission, and unchanged OPML omission.

**Evidence:**
- `evidence/rev0098/reproduction/cli-publication-site-before.log`
- `evidence/rev0098/reproduction/extension-publication-site-before.log`
- `evidence/rev0098/cli-test_source_notes_publication_site.log`
- `evidence/rev0098/source_notes_publication_site_harness.log`
- `evidence/rev0098/source_notes_publication_site_harness-firefox.log`
- `SOURCE-NOTES-PUBLICATION-DISCLOSURE-AUDIT.json`
