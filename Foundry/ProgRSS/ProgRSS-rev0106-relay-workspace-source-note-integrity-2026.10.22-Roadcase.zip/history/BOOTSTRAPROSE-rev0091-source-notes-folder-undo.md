# `/run` authority — rev0091 Source Notes folder-removal undo

This is the sole current checklist. Previous authorities are historical under
`history/`; do not treat their checked boxes as evidence for this candidate.

## Candidate and limits

Candidate: **rev0091-source-notes-folder-undo**. Product lineage remains **rev0080 / 0.80.0**.
Immediate parent: `ProgRSS-rev0090-verified-runtime-comparison-2026.10.21-Roadcase.zip`; SHA-256
`9245f25fcf7dc55d29e012488cfa33edf5abf49c6ac058e44419a6da3f3a4540`.
Rev0081 and rev0082 remain unavailable and unrecovered.

**Release gate: NOT SATISFIED. A reproduced product data-loss defect remains open.**
The target-host browser connector also requires its originating context. No
installed browser, current/unmanaged browser, participant, real AT, or permission-
prompt session was run. No enterprise policy was changed. Earlier installed-runtime
records remain bound to their original archives; this Extension has changed.

## Completed: whole-placement removal and undo

- [x] Reproduced rev0090 silently dropping a reason on folder-removal undo.
- [x] Reproduced undo wrongly refusing a direct placement when the source remained
  reachable through a nested folder.
- [x] Removal returns the canonical member, original index, and existing vault
  revision to the existing short-lived side-panel undo. No persistent store added.
- [x] Undo restores that direct member's reason (or absence) at the original index.
  Inherited membership is allowed; an existing newer direct placement is not.
- [x] Missing/mismatched metadata, invalid indices, invalid Unicode, and overlong
  reasons refuse without changing persisted state.
- [x] Normal folder-version guards remain. At the 10000 version cap, exact vault
  revision is additionally required; any intervening write conservatively refuses.
- [x] Shared background and side-panel changes generated into Firefox identically.
- [x] 22 focused cases pass per package variant, including the actual side-panel
  functions forwarding the complete undo payload and native integrity after undo.
- [x] All 184 CLI tests in 11 modules, 60 Extension static tests, nine Node
  harness invocations, and 40 evidence-boundary tests pass in this turn.
- [x] CLI's 112 files and modes are unchanged. Required/optional/host permission
  projections remain unchanged from rev0080. The 12-second UI undo interval remains.

These are native, offline, and mocked-API tests. They do not establish timing
adequacy, accessibility, real browser interaction, or unfamiliar-person comprehension.
The complete Extension runner (including browser rendering smoke) was not rerun.
The final archive build and clean-extraction seal are reported externally, avoiding
self-referential archive hashes in this file.

## P0.1 — next: same-source repair must not choose a reason by member order

A separate shipped preview/commit reproduction is retained in
`evidence/rev0091/source-repair-open-reproduction.json`. Two local source histories
with the same feed address appear directly in one folder with different reasons.
Preview says repair is allowed and gives no warning. Choosing the second source
as survivor still keeps the first member's reason and loses the second reason.
This is **not** the already-covered later-copy Keep mine / Use curator's update path.

1. Replay `node evidence/rev0091/reproduce-source-repair-collision.js` on this
   candidate. Also vary member order and chosen survivor.
2. Make preview and commit preserve unambiguous reasons and refuse divergent
   placement collisions without an automatic winner. A clear blocking explanation
   is preferable to silently selecting a value or building an unrelated feature.
3. Cover reason versus absence, identical and divergent reasons, separate folders,
   malformed notes, stale review, no mutation on refusal, and exact repair undo.
4. Audit the CLI equivalent; do not assume its source-combine path shares the
   Extension's reason semantics.
5. Only after this blocker is corrected, regenerate both packages and freeze new
   exact bytes for current-browser acceptance. Do not reuse rev0090 sessions.

No new evidence layer is needed. Make only the smallest correction supported by
this reproduced failure; keep the current 18-case protocol and explicit scopes.

## P0.2 — actual current target-host runtime

Obtain the real target host/browser context. Do not alter enterprise policy or
substitute a managed/non-current browser for unmanaged acceptance. Capture fresh
exact official channel payloads on that host rather than copying research version
strings or retimestamping the retained historical channel-reference files.

Run independently in unmanaged then-current Chromium, Firefox Release, and Firefox
ESR. Reconcile Firefox installation/restart methodology first: temporary installation
is not signed-install permission-prompt evidence. Retain first failures, retries,
interruption/recovery, real permission observations, two views, same-profile restart,
actual complete-route and branch JSON, and all 18 cases.

Case `clear-and-guarded-undo` now explicitly includes whole-placement removal/undo,
reason preservation, original order, inherited membership, and stale refusal. Its
ID and the case count stay fixed; prior records do not implicitly cover these steps.
Finalize and independently verify full evidence ZIPs against the same immutable
Roadcase, then compare with `--roadcase` and `--require-browser-triad`. Comparison
and three-channel coverage are not automatic release acceptance.

## P0.3 — unfamiliar people and real assistive technologies

After product and browser gates: unfamiliar curator and recipient comprehension of
relationship level, independent two-folder reasons, authorship, publication/contact/
scheduling consequences, absence of a ProgRSS safety claim, branch expectations,
OPML loss, divergent later-copy choices, and removal/undo consequences.

Run distinct screen-reader, refreshable-Braille, voice-control, switch-control,
high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
Review sender and recipient privacy evidence separately. Apply only the smallest
correction supported by recurring independent wrong turns. Do not promote mocked
functions, DOM smoke, digests, or unsigned assertions into human or AT evidence.

## P1 — delayed re-finding and organization

Test one-week delayed route re-finding before private labels or saved views. Keep
folders human-curated and shareable, Source Notes optional, and **Unfiled** legitimate.
No engagement ranking of note wording, opaque recommendations, comments, reactions,
profiles, notifications, or other social expansion.

## P2 — remote Nodes

Explicit remote mode separate from loopback; TLS, persistent identity, bounded
hosts/requests/artifacts/rates, expiring invitations, durable revocation evidence,
and separate public publication/private API routes. Start with reviewed immutable
artifact retrieval. No default public bind, silent LAN discovery, or UPnP.

## Lab — bounded WebRTC courier

Exactly one reviewed immutable artifact. Preserve notes through native artifacts;
show signaling/STUN/TURN; refuse replay, identity/digest mismatch, timeout, and
partial completion; destroy the session. Never require it for ordinary reading,
sharing, Source Notes, Capture, Witness, or Pulse.

## Reproduction and packaging

Focused: `python3 tools/verify-rev0091-source-notes.py`.
Full non-browser regressions: `python3 tools/run-rev0091-regressions.py`.
Prebuild: `python3 tools/prebuild-validate-rev0091.py`.
Build: `python3 tools/build-reconstruction-roadcase.py` (pass output/report paths on
other hosts). It performs deterministic builds, manifest and clean-extraction
byte/mode verification, focused replay, doctor, and prepared-only evidence checks.
Prepared sessions and synthetic fixtures are never browser-runtime acceptance.
