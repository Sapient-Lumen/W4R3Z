# `/run` authority — rev0090 verified runtime comparison

This file is the sole current checklist. The accumulated rev0083–rev0089 authority
and reconstruction history is retained in `history/BOOTSTRAPROSE-through-rev0089.md`;
its old “current” headings are historical, not competing instructions.

## Candidate and evidence boundary

Candidate: **rev0090-verified-runtime-comparison**. Product lineage remains
**rev0080 / 0.80.0**. Rev0081 and rev0082 remain unavailable and unrecovered.
Immediate parent: rev0089 Roadcase, SHA-256
`65df45a95bfa9d917a0053f4d81d1a4d317119945e3139746359eeb6269b58fd`.

**Release gate: NOT SATISFIED.** No current/unmanaged Chromium, Firefox Release,
Firefox ESR, unfamiliar-person, or real assistive-technology acceptance was run
this turn. Browser access lacked the originating context; official binary hosts
could not be resolved by this container. No enterprise policy was changed.

The CLI and Extension product subtrees are unchanged in every file and mode
(112 CLI files; 202 Extension files). Earlier Chromium 144 runtime evidence remains
limited to its original archive and environment. Byte continuity does not turn it
into a new exact-final-archive runtime pass or a current-channel pass.

## Completed in this turn

- [x] Verified the supplied rev0089 archive hash before extraction.
- [x] Reproduced acceptance of a text log as native-artifact evidence and an edited
  standalone Firefox statement in the old comparator. Synthetic proof retained.
- [x] Replaced standalone-statement comparison with direct evidence-ZIP plus
  immutable-Roadcase verification for every input.
- [x] Reused the shipped native reader and canonicalizer to validate actual native
  artifact bytes and derive semantic hashes. No new product serializer or store.
- [x] Complete-route evidence requires native attributed integrity. Independent
  legacy branch excerpts remain valid but explicitly have no embedded integrity.
- [x] Native artifacts are required when their corresponding cases claim pass.
  Supplied raw/semantic hashes must match the bytes; invented hashes are refused.
- [x] Missing artifacts remain visible; duplicate bundles/session identities are
  refused; an optional triad check requires all three distinct browser channels.
- [x] Independent ZIP verification now repeats evidence-reference, native-artifact,
  duplicate-manifest, and resource-limit checks. Limits apply before decompression.
- [x] Canonical evidence metadata rejects duplicate JSON keys and non-finite numbers.
- [x] Finalization-to-write input changes are refused.
- [x] 40 evidence-boundary regression tests pass. Full-suite logs and build results
  accompany this candidate; synthetic tests never count as runtime fieldwork.

## P0.1 — current target-host runtime evidence (next release blocker)

1. Obtain the actual target host/browser context; do not alter enterprise policy
   or substitute the managed Chromium 144 environment.
2. Capture fresh official channel payload bytes on that host. The 2026-10-21
   research reference is CfT Stable 156.0.8078.47, Firefox Release 158.0.1, and
   Firefox ESR 153.5.1esr; re-read the endpoints rather than hardcoding these later.
3. Prepare a new rev0090 session from the frozen Roadcase. Earlier revision
   sessions are not silently migrated. Start within 24 hours of the bound capture.
4. Run all 18 cases in unmanaged then-current Chromium. Retain actual complete-route
   and branch JSON, first failures/retries, two-view stale-save/undo observations,
   same-profile restart, install method, OS/browser identity, and permission behavior.
5. Independently repeat Firefox Release and ESR. Resolve the installation/restart
   method first: temporary installation is not signed-install prompt evidence.
6. Finalize and independently verify every evidence ZIP. Compare them with
   `--roadcase` and `--require-browser-triad`; review native and permission
   differences. Comparison is not an automatic acceptance decision.

Do not create another evidence layer merely because host runs are unavailable.
Only make further implementation changes for a reproduced failure. An unavailable
run stays blocked/not run; prepared or synthetic bundles stay non-runtime evidence.

## P0.2 — unfamiliar-person and real assistive-technology fieldwork

After the current browser triad passes, test unfamiliar curator and recipient
understanding of relationship level, one source/two folder reasons, authorship,
publication/contact/scheduling consequences, absence of a ProgRSS safety claim,
branch expectations, OPML loss, and both divergent-copy decisions.

Run distinct screen-reader, refreshable-Braille, voice-control, switch-control,
high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
Review privacy evidence for senders and recipients separately. Apply only the
smallest correction supported by recurring independent wrong turns. Automated DOM
smoke, native hashes, and unsigned assertions are not participant or AT evidence.

## P1 — delayed re-finding and organization

Test one-week delayed route re-finding before adding private labels or saved views.
Keep folders human-curated and shareable, Source Notes optional, and **Unfiled**
legitimate. Keep note wording out of engagement ranking and opaque recommendations;
no comments, reactions, profiles, notifications, or social activity expansion.

## P2 — remote Nodes

Keep remote mode explicit and separate from loopback. Require TLS, persistent Node
identity, bounded hosts/requests/artifacts/rates, expiring invitations, durable
revocation evidence, and separate public publication/private API routes. Start
with reviewed immutable-artifact retrieval. No default public bind, silent LAN
discovery, or UPnP.

## Lab — bounded WebRTC courier

One reviewed immutable artifact per session. Preserve notes through the native
artifact; show signaling/STUN/TURN; refuse replay, identity/digest mismatch,
timeout, or partial completion; destroy the session afterward. Never require
WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Verification and continuation

Run `python3 tools/verify-rev0090-source-notes.py` for the focused gate and
`python3 tools/prebuild-validate-rev0090.py` before packaging. The Roadcase builder
performs two independent constructions, clean extraction, byte/mode verification,
focused replay, CLI doctor, and prepared-only evidence self-checks. The external
build/verification reports seal the final ZIP without a circular in-archive hash.

The statement format is unsigned: no authenticated operator, browser execution,
network capture, trusted timestamp, human presence, SLSA level, privacy comprehension,
accessibility conformance, or release-readiness claim is made.
