# Current status — rev0098 Source Notes publication disclosure

Candidate: `rev0098-source-notes-publication-disclosure`.

The rev0097 native JSON preserved direct-placement reasons, while the shipped CLI and Extension ready-to-host HTML omitted them from the recipient hierarchy. rev0098 renders each reason beside its exact folder/source placement, keeps duplicate-source folder reasons distinct, omits absent notes, adds curator/non-safety disclosure, escapes and direction-isolates text, reports counts, and retains explicit OPML omission.

The complete pre-package sweep passed: 192 CLI tests across 13 modules, 60 Extension Python tests, 19 explicit managed Node harness invocations, both Workbench UI variants, the complete Extension runner, separate managed rendering/interaction smoke, 8 Python contract tests, 12 JavaScript merge fixtures with byte-identical output, and 40 evidence-boundary tests.

Release gate remains open. No unmanaged current Chromium, Firefox Release, Firefox ESR, unfamiliar-person, privacy-comprehension, human permission-prompt, or real assistive-technology session passed these exact bytes. No enterprise policy was changed.
